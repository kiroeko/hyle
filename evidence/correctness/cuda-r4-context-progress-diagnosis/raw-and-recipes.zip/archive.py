import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

repo = Path('C:/public/project-hyle/hyle')
scratch = Path(__file__).parent
target = repo / 'evidence/correctness/cuda-r4-context-progress-diagnosis'
target.mkdir(parents=True, exist_ok=True)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

paths = ['include/hyle/compute', 'include/hyle/graph']
paths += sorted(p.relative_to(repo).as_posix() for p in (repo / 'src').iterdir()
                if p.is_dir() and p.name.startswith(('compute', 'graph')))
command = ['python', 'scripts/loc-report.py', '--module', 'compute_graph',
           '--self-check', '--json', '--commit', 'HEAD']
for path in paths:
    command += ['--module-path', path]
result = subprocess.run(command, cwd=repo, check=True, capture_output=True)
(target / 'loc.json').write_bytes(result.stdout)

identity = json.loads((scratch / 'source-identity.json').read_text(encoding='utf-8'))
identity['diagnostic_executable_sha256'] = digest(scratch / 'phase.exe')
identity['libraries'] = {p.name: digest(p) for p in sorted(Path('C:/hv4d1v2/bin').glob('hyle_*.lib'))}
identity['runtime'] = {p.name: digest(p) for p in sorted(scratch.glob('*.dll'))}
(target / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')

reports = json.loads((scratch / 'intervention/results.json').read_text(encoding='utf-8'))
summary = {
    'verdict': 'BLOCKED',
    'progress': 'actual SDK API located; causal repair unproven',
    'product_changed': False, 'p1_restarted': False,
    'capture': json.loads((scratch / 'run-00/report.json').read_text(encoding='utf-8')),
    'actual_call_chain': ['cuda::create_context', 'Context::create',
                          'create_context_state', 'cuda::create_context_impl+0xba',
                          'cuDevicePrimaryCtxRetain', 'nvcuda64.dll',
                          'KERNELBASE.dll', 'ntdll.dll'],
    'call_site': {'return_rva': '0xa5ca', 'call_rva': '0xa5c5',
                  'target_rva': '0x2eeb0', 'target_symbol': 'cuDevicePrimaryCtxRetain'},
    'intervention': {'attempted_launches': len(reports),
                     'successful_exits': sum(r['exit_code'] == 0 for r in reports),
                     'applied': any('intervention' in r for r in reports),
                     'verdict': 'INCONCLUSIVE; no qualifying recurrence'},
    'limitations': [
        'This single captured diagnostic process does not prove the earlier two processes had the same phase.',
        'The stack locates the SDK call; it does not prove a driver defect or affinity causality.',
        'The recovery experiment did not reach its intervention condition and is not a PASS.',
        'No new default rule, P1 result, product repair, or route closure is claimed.'
    ],
}
(target / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')

root_names = ['prepare.py', 'phase.h', 'phase.cc', 'phase.map', 'phases.json',
              'source-identity.json', 'build.ps1', 'build.log', 'observe.py',
              'results.json', 'unwind.cc', 'unwound-stacks.txt', 'resolved-map.txt',
              'context-disasm.txt', 'cuda-imports.txt', 'intervene.py']
with zipfile.ZipFile(target / 'raw-and-recipes.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in root_names:
        archive.write(scratch / name, name)
    for name in ['selftest', 'run-00', 'intervention']:
        for path in sorted((scratch / name).rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(scratch).as_posix())
    archive.write(scratch.parent / 'qualification/affinity-probe/capture-hang.py', 'capture-hang.py')
    archive.write(Path(__file__), 'archive.py')

hashes = {path.name: digest(path) for path in sorted(target.iterdir())
          if path.is_file() and path.name != 'sha256.json'}
(target / 'sha256.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'evidence': str(target), 'raw_sha256': hashes['raw-and-recipes.zip']}))
