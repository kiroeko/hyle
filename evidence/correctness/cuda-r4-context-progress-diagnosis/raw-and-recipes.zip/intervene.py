"""One bounded intervention on a captured Context-creation delay; never P1."""
import ctypes as c
from ctypes import wintypes as w
import importlib.util
import json
import msvcrt
import os
from pathlib import Path
import struct
import subprocess
import time
import _winapi

import observe as obs

root = Path(__file__).parent
output = root / 'intervention'
output.mkdir()
if not obs.set_affinity(obs.current(), 0x40):
    raise c.WinError(c.get_last_error())
set_thread_affinity = obs.bind('SetThreadAffinityMask', [w.HANDLE, c.c_size_t], c.c_size_t)


def run(index):
    directory = output / f'run-{index:02d}'
    directory.mkdir()
    with open(os.devnull, 'rb') as inp, (directory / 'process.log').open('wb') as out:
        handles = [msvcrt.get_osfhandle(f.fileno()) for f in (inp, out)]
        for handle in handles:
            os.set_handle_inheritable(handle, True)
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESTDHANDLES
        startup.hStdInput, startup.hStdOutput, startup.hStdError = handles[0], handles[1], handles[1]
        hp, ht, pid, tid = _winapi.CreateProcess(
            str(root / 'phase.exe'), subprocess.list2cmdline([str(root / 'phase.exe')]),
            None, None, True, 0x4 | subprocess.ABOVE_NORMAL_PRIORITY_CLASS,
            obs.env, str(root), startup)
        for handle in handles:
            os.set_handle_inheritable(handle, False)
        if not obs.set_affinity(hp, 4):
            raise c.WinError(c.get_last_error())
        obs.resume(ht)
        obs.close(ht)
        started = time.monotonic()
        mapped = view = None
        history = []
        last = None
        rescued_at = None
        report = {'pid': pid, 'primary_thread': tid, 'initial_mask': '0x4',
                  'observer_mask': '0x40', 'priority': 'AboveNormal'}
        try:
            while _winapi.WaitForSingleObject(hp, 50) == 258:
                if not mapped:
                    mapped = obs.open_map(4, False, f'Local\\hyle-r4-phase-{pid}')
                    if mapped:
                        view = obs.map_view(mapped, 4, 0, 0, 24)
                phase = rows = None
                if view:
                    phase, rows, thread, count, tick = struct.unpack('<iiiiQ', c.string_at(view, 24))
                    if (phase, rows) != last:
                        history.append({'seconds': time.monotonic() - started,
                                        'phase': phase, 'rows': rows, 'count': count})
                        last = phase, rows
                elapsed = time.monotonic() - started
                if elapsed > 10 and rescued_at is None:
                    report['stopped_phase'] = {'phase': phase, 'rows': rows}
                    report['threads_before'] = obs.thread_facts(pid)
                    report['capture_exit'] = obs.capture(pid, tid, directory / 'before')
                    if phase != 100 or rows != 1 or report['capture_exit']:
                        report['intervention'] = 'NOT_APPLICABLE'
                        _winapi.TerminateProcess(hp, 124)
                        break
                    if not obs.set_affinity(hp, 0x14):
                        raise c.WinError(c.get_last_error())
                    updates = []
                    for fact in report['threads_before']:
                        handle = obs.open_thread(0x60, False, fact['id'])
                        if not handle:
                            raise c.WinError(c.get_last_error())
                        mask = 4 if fact['id'] == tid else 0x14
                        previous = set_thread_affinity(handle, mask)
                        obs.close(handle)
                        if not previous:
                            raise c.WinError(c.get_last_error())
                        updates.append({'thread': fact['id'], 'old_mask': hex(previous),
                                        'new_mask': hex(mask)})
                    report['affinity_updates'] = updates
                    rescued_at = time.monotonic()
                    report['intervention_seconds'] = rescued_at - started
                    report['intervention'] = 'APPLIED'
                elif rescued_at is not None and time.monotonic() - rescued_at > 10:
                    report['intervention'] = 'NO_PROGRESS_WITHIN_LIMIT'
                    report['threads_after'] = obs.thread_facts(pid)
                    _winapi.TerminateProcess(hp, 124)
                    break
            _winapi.WaitForSingleObject(hp, 10000)
            report['elapsed_seconds'] = time.monotonic() - started
            report['exit_code'] = _winapi.GetExitCodeProcess(hp)
            report['history'] = history
            if rescued_at is not None:
                report['seconds_after_intervention'] = time.monotonic() - rescued_at
                report['recovered'] = report['exit_code'] == 0
        finally:
            if view:
                obs.unmap(view)
            if mapped:
                obs.close(mapped)
            obs.close(hp)
    (directory / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return report


started = time.monotonic()
reports = []
for index in range(12):
    if time.monotonic() - started >= 120:
        break
    report = run(index)
    reports.append(report)
    (output / 'results.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'history'}), flush=True)
    if 'stopped_phase' in report or report['exit_code']:
        break
