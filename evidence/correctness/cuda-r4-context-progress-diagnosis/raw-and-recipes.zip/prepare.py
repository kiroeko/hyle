from pathlib import Path
import hashlib
import json

root=Path(__file__).parent
repo=Path('C:/public/project-hyle/hyle')
source=(repo/'bench/compute_route_cuda/route_p1_bench.cc').read_text(encoding='utf-8')
original=hashlib.sha256(source.encode()).hexdigest()
source='#include "phase.h"\n'+source
source=source.replace('int main() {', 'int main(int argc, char **) {\n  phase_diag::init();\n  if (argc == 2) { phase_diag::mark(8888); Sleep(5000); return 0; }')
source=source.replace('  int driver =', '  phase_diag::mark(10);\n  int driver =')
source=source.replace('  measure(1,', '  phase_diag::mark(20);\n  measure(1,')
source=source.replace('  measure(16,', '  phase_diag::mark(30);\n  measure(16,')
source=source.replace('  measure(16, peer_first, allocation_first, aa, verify_only);', '  measure(16, peer_first, allocation_first, aa, verify_only);\n  phase_diag::mark(9000);')
source=source.replace('    context = take(', '    phase_diag::mark(100);\n    context = take(')
source=source.replace('    resource =', '    phase_diag::mark(110);\n    resource =')
source=source.replace('    q.resize(', '    phase_diag::mark(120);\n    q.resize(')
source=source.replace('    quantized =', '    phase_diag::mark(130);\n    quantized =')
source=source.replace('    down.create(', '    phase_diag::mark(140);\n    down.create(')
source=source.replace('    down.write(', '    phase_diag::mark(150);\n    down.write(')
source=source.replace('  DataSet data(rows);', '  phase_diag::shared->rows=static_cast<LONG>(rows);\n  phase_diag::mark(90);\n  DataSet data(rows);\n  phase_diag::mark(200);')
source=source.replace('  const auto cold_end =', '  phase_diag::mark(250);\n  const auto cold_end =')
source=source.replace('  for (std::size_t i = 0; i < kSlots; ++i) {\n    candidate', '  phase_diag::mark(300);\n  for (std::size_t i = 0; i < kSlots; ++i) {\n    candidate')
source=source.replace('  for (std::size_t i = 0; i < 8; ++i) {', '  phase_diag::mark(400);\n  for (std::size_t i = 0; i < 8; ++i) {')
source=source.replace('  nb::Bench bench;', '  phase_diag::mark(500);\n  nb::Bench bench;')
source=source.replace('Runner{peer.get()});\n}', 'Runner{peer.get()});\n  phase_diag::mark(600);\n  peer.reset();\n  phase_diag::mark(610);\n  candidate.reset();\n  phase_diag::mark(620);\n}')
source=source.replace('    auto first = take(', '    phase_diag::mark(1000);\n    auto first = take(')
source=source.replace('    auto middle =', '    phase_diag::mark(1001);\n    auto middle =')
source=source.replace('    auto last = take(', '    phase_diag::mark(1002);\n    auto last = take(')
source=source.replace('    require(last.wait()', '    phase_diag::mark(1003);\n    require(last.wait()')
source=source.replace('    require(middle.wait()', '    phase_diag::mark(1004);\n    require(middle.wait()')
source=source.replace('    require(first.wait()', '    phase_diag::mark(1005);\n    require(first.wait()')
source=source.replace('  void run() { run_slot((next_slot_++) % kSlots); }', '  void run() { run_slot((next_slot_++) % kSlots); phase_diag::mark(1006); }')
(root/'phase.cc').write_text(source,encoding='utf-8',newline='\n')
mapping={1:'main entered',10:'CUDA inventory',20:'M1 begin',30:'M16 begin',90:'DataSet constructor',100:'Context create',110:'resource create',120:'host data allocation/fill',130:'Q4 pack',140:'down allocation/fill',150:'down upload/input generation',200:'Harness construction',250:'prepared',300:'correctness',400:'warmup',500:'nanobench preparation/calibration',600:'peer teardown',610:'candidate teardown',620:'DataSet teardown',9000:'main returned/global teardown',9999:'late atexit',1000:'gate/up submit',1001:'activation submit',1002:'down submit',1003:'down wait',1004:'activation wait',1005:'gate/up wait',1006:'complete call returned'}
(root/'phases.json').write_text(json.dumps(mapping,indent=2)+'\n',encoding='utf-8')
(root/'source-identity.json').write_text(json.dumps({'source_revision':'c2edb1c267e5555891e334011d2cde1674420edc','original_bench_sha256':original,'diagnostic_bench_sha256':hashlib.sha256(source.encode()).hexdigest(),'product_libraries':'C:/hv4d1v2/bin; immutable 7b3279c8 shipping libraries'},indent=2)+'\n',encoding='utf-8')
