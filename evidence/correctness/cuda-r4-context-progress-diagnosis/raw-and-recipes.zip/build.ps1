$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$r4DiagRoot = 'C:/hyle-scratch/r4-cuda-20260916/progress-diagnosis'
Set-Location -LiteralPath $r4DiagRoot
$r4CudaRoot = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3'
python prepare.py
if ($LASTEXITCODE -ne 0) { throw 'phase source preparation failed' }
$r4Libraries = @(Get-ChildItem -LiteralPath C:/hv4d1v2/bin -Filter 'hyle_*.lib' | ForEach-Object FullName)
& cl /nologo /O2 /Ob2 /DNDEBUG /EHsc /std:c++latest /MD /utf-8 /Zc:preprocessor /DHYLE_STATIC /DHYLE_COMPUTE_CUDA=1 /DHYLE_CUDA_GRAPH_BENCH=0 /DNOMINMAX /DWIN32_LEAN_AND_MEAN /I C:/public/project-hyle/hyle/include /I C:/public/project-hyle/hyle/bench/compute_route_cuda /I C:/public/project-hyle/hyle/third_party/nanobench "/I$r4CudaRoot/include" phase.cc /link "/LIBPATH:$r4CudaRoot/lib/x64" $r4Libraries cudart.lib cuda.lib cublasLt.lib bcrypt.lib advapi32.lib psapi.lib PowrProf.lib Synchronization.lib C:/hv4d1v2/bin/mimalloc_static.lib C:/hv4d1v2/bin/nanobench.lib /NODEFAULTLIB:LIBCMT /INCREMENTAL:NO /MAP:phase.map /OUT:phase.exe *> build.log
if ($LASTEXITCODE -ne 0) { Get-Content build.log -Tail 35; throw 'diagnostic build failed' }
foreach ($r4Dll in @('cudart64_13.dll','cublasLt64_13.dll','msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll')) {
  Copy-Item -LiteralPath "C:/hv4d1v2/bin/$r4Dll" -Destination $r4DiagRoot
}
Write-Output 'Diagnostic linked against existing immutable product libraries; DLLs adjacent.'
