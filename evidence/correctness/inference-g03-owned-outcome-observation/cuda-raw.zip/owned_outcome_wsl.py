from pathlib import Path
import hashlib, json, os, subprocess, time
canonical = Path('/mnt/c/public/project-hyle/hyle')
base = Path('/root/hyle-scratch/compute-unified')
source = base / 'source-7a7b4c3b'
parent = base / 'l-cpu-cuda/selected-graph/source-parent'
build = parent.parent / 'source-build'
out = canonical / '.scratch/inference-gaps/g03/owned-outcome-cuda'
out.mkdir(exist_ok=True)
names = ['include/hyle/compute/detail/dependent_completion.h', 'include/hyle/compute/detail/generated_result.h',
    'include/hyle/compute/detail/copy_stream_access.h', 'include/hyle/compute/result.h',
    'src/compute/retained_completion.cc', 'src/compute/batch_transfer.cc',
    'tests/compute_batch/owned_outcome_completion_fixture.h', 'tests/compute_batch/owned_outcome_cuda_consumer.cc']
inputs = []
for name in names:
    data = (canonical / name).read_bytes()
    destination = source / name
    if not destination.exists() or destination.read_bytes() != data:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    inputs.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest()})
identity = {'uname': subprocess.check_output(['uname', '-a'], text=True).strip(),
    'gpu': subprocess.check_output(['nvidia-smi', '--query-gpu=name,driver_version,memory.used,utilization.gpu', '--format=csv,noheader'], text=True).strip(),
    'compiler': subprocess.check_output(['/usr/bin/g++-14', '--version'], text=True).splitlines()[0]}
target = 'g03_owned_outcome_cuda'
body = (parent / 'CMakeLists.txt').read_text()
if f'add_executable({target} ' not in body:
    body += f'\nadd_executable({target} "{source / names[-1]}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle_compute hyle_compute_backend_cuda)\nhyle_stage_runtime({target})\n'
    (parent / 'CMakeLists.txt').write_text(body)
assert '# G03 original event observation hooks, host TU only' in body
env = os.environ.copy()
env['PATH'] = '/usr/local/cuda-13.3/bin:' + env['PATH']
env['LD_LIBRARY_PATH'] = '/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:' + env.get('LD_LIBRARY_PATH', '')
record = out / 'result.json'
rows = json.loads(record.read_bytes()).get('stages', []) if record.exists() else []
def run(stage, args):
    attempt = 1 + sum(row['stage'] == stage for row in rows)
    log = out / f'{stage}-{attempt}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.Popen(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
        (out / 'job.json').write_text(json.dumps({'state': 'RUNNING', 'pid': process.pid, 'log': str(log)}))
        print('RUN CUDA', stage, process.pid, flush=True)
        code = process.wait()
    rows.append({'stage': stage, 'command': args, 'exit_code': code, 'elapsed_seconds': time.monotonic() - start, 'log': str(log)})
    record.write_text(json.dumps({'scope': '1024-byte actual CUDA producer/F2/suffix; original completion/WriteLease result and original event-query hook; no new kernel/global build/device poisoning', 'identity': identity, 'inputs': inputs, 'stages': rows, 'cumulative_seconds': sum(row['elapsed_seconds'] for row in rows)}, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
    if code:
        print(log.read_text(errors='replace')[-5500:], flush=True)
        (out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': code}))
        raise SystemExit(code)
run('configure', ['cmake', '-S', str(parent), '-B', str(build)])
dry = subprocess.check_output(['ninja', '-C', str(build), '-n', target], env=env, text=True)
(out / 'dry-run.txt').write_text(dry)
assert '.cu.o' not in dry and 'nvcc' not in dry, 'reject unplanned CUDA kernel build before execution'
run('build', ['cmake', '--build', str(build), '--target', target, '--parallel', '4'])
run('actual-four-cases', [str(build / target)])
(out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': 0}))
