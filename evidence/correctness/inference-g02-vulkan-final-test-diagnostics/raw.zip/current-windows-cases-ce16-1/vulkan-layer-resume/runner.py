from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';prep=base/'resume-windows-3'
build=Path('C:/h7/inference-g02-impacted');out=base/'current-windows-cases-ce16-1'
assert sys.argv[1]=='vulkan' and len(sys.argv)==2
route=sys.argv[1];followup=len(sys.argv)>2 and sys.argv[2]=='fixture-skips';remaining=len(sys.argv)>2 and sys.argv[2]=='remaining';folder=out/(route+'-layer-resume');folder.mkdir(parents=True,exist_ok=False)
build_record=json.loads((base/'vulkan-phase-normal-fix-4/result.json').read_text())
assert build_record['state']=='TERMINAL_TARGETED_PASS'
build_record['product_source']=build_record['candidate']
for artifact in build_record['artifacts']:
 assert hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest()==artifact['sha256']
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
exe=build/f'bin/hyle_graph_route_{route}_test.exe'
record={'state':'SETUP','route':route,'product_source':build_record['product_source'],
 'evidence_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'original_ctest_recipe':['ctest','--test-dir',str(build),'-C','Release','--output-on-failure','--no-tests=error','-L',f'^graph_route_{route}$','-LE','headers'],
 'execution':'Complete default GTest set from the same rebuilt executable, one case per process, serial; original monolithic ctest command not claimed executed',
 'executable':{'path':str(exe),'sha256':sha(exe),'mtime_ns':exe.stat().st_mtime_ns,'bytes':exe.stat().st_size},'cases':[]}
def save():(folder/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();(folder/'runner.py').write_bytes(Path(__file__).read_bytes())
child=None
def failed(kind,error,tb):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if child and child.poll() is None else 'TERMINAL_SETUP_OR_ANALYSIS_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,tb)
sys.excepthook=failed
env={k.upper():v for k,v in os.environ.items() if not k.upper().startswith('GTEST_')}
for line in subprocess.check_output(['cmd','/d','/c',str(prep/'vs-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1)
  if not k.upper().startswith('GTEST_'):env[k.upper()]=v
fixture_proof=base/'current-model-fixture.json'
if fixture_proof.is_file():
 fixture=json.loads(fixture_proof.read_text());fixture_root=Path(fixture['root'])
 assert fixture['verdict']=='PASS_ALL_EXISTING_REAL_FIXTURE_FILE_HASHES'
 assert sha(fixture_root/'receipt.json')==fixture['receipt_sha256']
 for name,digest in fixture['files'].items():assert sha(fixture_root/name)==digest
 env['HYLE_D5_QWEN35_FIXTURE']=str(fixture_root)
 record['real_fixture']={'proof':str(fixture_proof),'sha256':sha(fixture_proof),'source_id':fixture['source_id'],'files':len(fixture['files'])};save()
env['VK_LAYER_PATH']='C:/public/tools/hyle-vulkan/1.4.357.0/Bin'
env['PATH']=env['VK_LAYER_PATH']+';'+env['PATH']
record['validation_layer_discovery']={'path':env['VK_LAYER_PATH'],'proof':str(base/'windows-validation-layer-discovery.json'),'proof_sha256':sha(base/'windows-validation-layer-discovery.json'),'required_by':'Existing private native-reference Backend explicitly requests validation=true; main default Context validation setting unchanged'}
working=build/f'tests/graph_route_{route}'
listing=subprocess.run([str(exe),'--gtest_list_tests'],cwd=working,env=env,text=True,capture_output=True)
(folder/'list.stdout.log').write_text(listing.stdout,encoding='utf-8')
(folder/'list.stderr.log').write_text(listing.stderr,encoding='utf-8')
assert listing.returncode==0,listing.stderr
names=[];disabled=[];suite=None
for line in listing.stdout.splitlines():
 name=line.split('#',1)[0].strip()
 if not name:continue
 if not line.startswith((' ','\t')) and name.endswith('.'):
  suite=name;continue
 if line.startswith((' ','\t')) and suite:
  full=suite+name
  if any(part.startswith('DISABLED_') for component in full.split('.') for part in component.split('/')):disabled.append(full)
  else:names.append(full)
assert names and len(names)==len(set(names))
if followup:
 original=json.loads((out/route/'result.json').read_text())
 assert original['state']=='TERMINAL_ALL_DEFAULT_CASES_EXECUTED'
 selected=[r['name'] for r in original['cases'] if r['verdict']=='SKIPPED' and any('HYLE_D5_QWEN35_FIXTURE' in x.get('message','') for x in r['skipped'])]
 assert selected and set(selected)<=set(names) and 'real_fixture' in record
 names=selected
 record['execution']='Only original missing-fixture skips after the complete default set; corrected environment and authenticated existing real fixture; preserve all old skip records'
 record['original_result_sha256']=sha(out/route/'result.json')
all_names=list(names)
original=json.loads((base/'remaining-windows-cases-1/vulkan/result.json').read_text())
assert all_names==original['expected_cases'] and len(all_names)==851
record['normal_build_receipt']={'path':str(base/'vulkan-phase-normal-fix-4/result.json'),'sha256':sha(base/'vulkan-phase-normal-fix-4/result.json'),'artifacts':build_record['artifacts']}
record['rerun_reason']='Current new product candidate corrects export ownership and native sin/cos; original default851 gate once on current input, includes affected old RoPE passes. No CUDA or unrelated factor replay. All original failures preserved.'
original_path=out/(route+'-batch-tail')/'last-complete-result.json'
original=json.loads(original_path.read_text())
stop_path=out/(route+'-batch-tail')/'environment-stop.json'
stop=json.loads(stop_path.read_text());assert stop['state']=='TERMINAL_ENVIRONMENT_INTERRUPTION_CHILD_DRAINED'
assert original['executable']==record['executable'] and original['expected_cases']==all_names
assert [r['name'] for r in original['cases']]==all_names[:len(original['cases'])]
pooled='VulkanGraphMoeFragments.D5GlmFlashPooledIndexerWithTail'
record['cases']=[r for r in original['cases'] if r['verdict']=='PASS' or r['name']==pooled]
names=[r['name'] for r in original['cases'] if r['verdict']!='PASS' and r['name']!=pooled]+all_names[len(original['cases']):]
assert len(set(names))==len(names) and len(names)+len(record['cases'])==851
record['inherited_evidence']={'path':str(original_path),'sha256':sha(original_path),'stop_path':str(stop_path),'stop_sha256':sha(stop_path),'actual_pass_preserved':sum(r['verdict']=='PASS' for r in record['cases']),'known_pooled_numeric_fail_preserved':1,'selected_environment_failures_and_pending':len(names)}
record['execution']='Same four fixed artifacts: preserve actual PASS and known pooled numeric FAIL; corrected process-only layer discovery, rerun observed environment failures plus originally unrun cases, one case/process serial. All earlier failures and in-flight interruption retained.'
record.update(expected_cases=all_names,disabled_default=disabled,case_count=len(all_names),list_exit=listing.returncode)
save()
for index,name in enumerate(names):
 assert exe.stat().st_mtime_ns==record['executable']['mtime_ns'] and exe.stat().st_size==record['executable']['bytes'],'test executable changed during fixed run'
 prefix=folder/f'{index:04d}';log=prefix.with_suffix('.log');xml=prefix.with_suffix('.xml')
 args=[str(exe),'--gtest_filter='+name,'--gtest_color=no','--gtest_output=xml:'+str(xml)]
 started=time.monotonic()
 with log.open('w',encoding='utf-8') as stream:
  child=subprocess.Popen(args,cwd=working,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  record.update(state='RUNNING',current_case=name,pid=child.pid);save();print(route,index+1,len(names),name,child.pid,flush=True)
  code=child.wait()
 row={'name':name,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-started,'log':str(log),'xml':str(xml)}
 if xml.is_file():
  tree=ET.parse(xml).getroot();cases=tree.findall('.//testcase')
  row['xml_tests']=tree.attrib.get('tests');row['xml_failures']=tree.attrib.get('failures');row['xml_errors']=tree.attrib.get('errors')
  row['skipped']=[{'message':s.attrib.get('message'),'text':s.text} for c in cases for s in c.findall('skipped')]
  row['verdict']='SKIPPED' if row['skipped'] else 'PASS' if code==0 and len(cases)==1 and tree.attrib.get('failures')=='0' and tree.attrib.get('errors')=='0' else 'FAIL'
 else:row['verdict']='FAIL_NO_XML'
 record['cases'].append(row);save()
 if code or row['verdict'].startswith('FAIL'):
  print('ACTUAL_FAIL',name,'exit',code,flush=True)
by_name={r['name']:r for r in record['cases']};assert len(by_name)==len(record['cases'])==851 and set(by_name)==set(all_names)
record['cases']=[by_name[n] for n in all_names]
assert sha(exe)==record['executable']['sha256'],'test executable changed during fixed run'
for artifact in build_record['artifacts']:assert sha(Path(artifact['path']))==artifact['sha256'],'artifact changed during original851 gate'
record.update(state='TERMINAL_ALL_DEFAULT_CASES_EXECUTED',pass_cases=sum(r['verdict']=='PASS' for r in record['cases']),skipped_cases=sum(r['verdict']=='SKIPPED' for r in record['cases']),failed_cases=sum(r['verdict'].startswith('FAIL') for r in record['cases']))
save();print(json.dumps({k:record[k] for k in ('state','route','case_count','pass_cases','skipped_cases','failed_cases')}),flush=True)
