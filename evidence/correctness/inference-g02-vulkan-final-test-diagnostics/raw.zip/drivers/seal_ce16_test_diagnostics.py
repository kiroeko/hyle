from pathlib import Path
import hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as ET

root=Path.cwd();base=root/'.scratch/inference-gaps/g02'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
whole=read(base/'current-windows-cases-ce16-1/vulkan-layer-resume/result.json');assert whole['state']=='TERMINAL_ALL_DEFAULT_CASES_EXECUTED' and len(whole['cases'])==851 and whole['pass_cases']==842 and whole['failed_cases']==9 and not whole['skipped_cases']
fail=[r for r in whole['cases'] if r['verdict']!='PASS'];plan=read(base/'ce16-collected-test-fixes.json');assert len(plan['iq1_catalogue_ids'])==8
assert {r['name'].rsplit('/',1)[-1] for r in fail[1:]}==set(plan['iq1_catalogue_ids'])
for row in fail[1:]:assert row['exit_code']==3 and 'GGML_ASSERT(result == nrows * row_size) failed' in Path(row['log']).read_text()
diag=read(base/'vulkan-pooled-oracle-diagnostic/result.json');t=ET.parse(base/'vulkan-pooled-oracle-diagnostic/test.xml').getroot();assert diag['state']=='TERMINAL_DIAGNOSTIC_COLLECTED' and t.attrib['tests']=='1' and t.attrib['failures']=='0' and t.attrib['errors']=='0' and not t.findall('.//skipped')
lines=[s for s in (base/'vulkan-pooled-oracle-diagnostic/test.log').read_text().splitlines() if '# G02_POOLED' in s];assert len(lines)==16 and all('bad_f32=0 ' in s for s in lines)
dest=root/'evidence/correctness/inference-g02-vulkan-final-test-diagnostics';dest.mkdir(exist_ok=False)
native=Path('C:/h7/inference-g02-impacted/src/compute_ggml_runtime/source-6ab8cd77f92e8511/src/ggml.c')
snapshots={'tests/compute_route_vulkan/catalogue_gguf_test_support.h':subprocess.check_output(['git','show','c195b2400:tests/compute_route_vulkan/catalogue_gguf_test_support.h']), 'tests/compute_models/cpu_c5_gguf_inputs.h':(root/'tests/compute_models/cpu_c5_gguf_inputs.h').read_bytes(),'tests/compute_route_vulkan/gguf_test_support.h':(root/'tests/compute_route_vulkan/gguf_test_support.h').read_bytes(),'tests/compute_route_vulkan/iq1_test_support.h':(root/'tests/compute_route_vulkan/iq1_test_support.h').read_bytes(),'native/ggml.c':native.read_bytes()}
count=0
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ('current-windows-cases-ce16-1','vulkan-pooled-oracle-diagnostic'):
  for p in sorted((base/folder).rglob('*')):
   if p.is_file() and p.suffix.lower() not in ('.exe','.obj','.lib','.pdb','.exp'):z.write(p,p.relative_to(base).as_posix());count+=1
 for name in ('windows-validation-layer-discovery.json','ce16-source-contract.log','ce16-collected-test-fixes.json','stop_missing_layer_batch.py','prepare_layer_resume.py','run_vulkan_ce16_layer_resume.py','diagnose_vulkan_pooled_oracle.py','prepare_pooled_oracle_diagnostic.py','seal_ce16_test_diagnostics.py'):
  z.write(base/name,'drivers/'+name);count+=1
 for name,data in snapshots.items():z.writestr('before-test-fix/'+name,data);count+=1
receipt={'kind':'G02_CE16_ORIGINAL_851_AND_FINITE_TEST_DEFECT_DIAGNOSIS','verdict':'DIAGNOSTIC_ORIGINAL_842_PASS_9_FAIL','product_candidate':whole['product_source'],'evidence_head_before_test_fix':'c195b24003fe363779e1f1fcee5d6ce63810b10d','normal_artifacts':whole['normal_build_receipt']['artifacts'],
 'original_gate':{'expected':851,'pass':842,'fail':9,'skipped':0,'one_case_per_process':True,'all_case_assertions_original':True,'result':'raw.zip/current-windows-cases-ce16-1/vulkan-layer-resume/result.json','result_sha256':sha(base/'current-windows-cases-ce16-1/vulkan-layer-resume/result.json')},
 'environment':{'discovery':read(base/'windows-validation-layer-discovery.json'),'interruption':read(base/'current-windows-cases-ce16-1/vulkan-batch-tail/environment-stop.json'),'correction':'Process VK_LAYER_PATH points to existing1.4.357.0 Bin, plus dependencyPATH. Normal public default Context validation unchanged. Original native reference Backend explicitly requests validation=true. Actual oldPASS retained; previous environment failures rerun, new627 cases complete. All original failures/stop/costs retained.'},
 'pooled_score':{'diagnostic':diag,'actual_independent_F32_nominal_gate':'PASS all existing profiles/four tails/four stateful replays and other outputs;16 traced official score groups, original thresholds and reference equations unchanged','traces':lines,'mechanism':'Provider Region explicitly sets F32 source precision for F32 MatMul; locked Vulkan implementation suppresses default coopmat2 F16 operand conversion. Fixture old rounded witness described different defaultnativearithmetic. Diagnostic selects original independentF32 oracle, no product mutation.'},
 'iq1':{'affected_ids':plan['iq1_catalogue_ids'],'actual_assertions':[{k:r[k] for k in ('name','exit_code','elapsed_seconds','log')} for r in fail[1:]],'mechanism':'Shared C5 demand supplies CPU extension enum64/65/66 in combinedbuild. Vulkan test Bank incorrectly feeds these to native_type→COUNT→ggml_quantize_chunk lacking matching encoder; result0 asserts expected rowbytes before HYLE GPU execution. Existing original raw IQ1 grids/byte fixture must be selected by publicquantizedformat, not foreignenum presence. No product capability inference or CPU fallback.','original_source_inputs':[{'path':n,'sha256':hashlib.sha256(data).hexdigest()} for n,data in snapshots.items()]},
 'pending':'Canonical finite test-only corrections and actual normal nineGraph+nineDirect qualification; CE15/16 affected Air source/static/shared still pending. No wholeG02/goal/registry acceptance.',
 'raw_entries':count,'raw_zip_sha256':sha(dest/'raw.zip')}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('sealed',receipt['verdict'],count)
