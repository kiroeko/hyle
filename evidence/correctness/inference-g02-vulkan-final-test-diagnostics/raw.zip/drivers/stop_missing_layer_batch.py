from pathlib import Path
import ctypes,json,subprocess,time,hashlib

base=Path('.scratch/inference-gaps/g02');folder=base/'current-windows-cases-ce16-1/vulkan-batch-tail'
snapshot=(folder/'result.json').read_bytes();d=json.loads(snapshot);assert d['state']=='RUNNING'
query="Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Where-Object { $_.CommandLine -like '*run_vulkan_ce16_batch_tail.py vulkan*' } | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"
parent=json.loads(subprocess.check_output(['powershell','-NoProfile','-Command',query],text=True));assert isinstance(parent,dict)
k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];k.OpenProcess.restype=ctypes.c_void_p;k.TerminateProcess.argtypes=[ctypes.c_void_p,ctypes.c_uint32];k.CloseHandle.argtypes=[ctypes.c_void_p]
h=k.OpenProcess(1,False,parent['ProcessId']);assert h and k.TerminateProcess(h,1);k.CloseHandle(h)
# Only terminate the parent; let its already-running test finish naturally.
record={'state':'PARENT_TERMINATED_CHILD_DRAINING','parent':parent,'reason':'Existing required validation layer missing from process discovery path. Source confirms fixture reference NativeDevice validation=true; original vkEnumerateInstanceLayerProperties missing Khronos, exact existing path discovers it. Preserve old assertions/failures; no product rebuild.','snapshot_sha256':hashlib.sha256(snapshot).hexdigest(),'snapshot_completed':len(d['cases'])}
(folder/'before-environment-stop.json').write_bytes(snapshot)
while True:
 query=f"@(Get-CimInstance Win32_Process | Where-Object {{ $_.ParentProcessId -eq {parent['ProcessId']} -and $_.Name -like 'hyle_graph_route_vulkan*' }} | Select-Object ProcessId,Name,CommandLine) | ConvertTo-Json -Compress"
 raw=subprocess.check_output(['powershell','-NoProfile','-Command',query],text=True).strip()
 children=json.loads(raw) if raw else []
 if not children:break
 record['observed_children']=children;(folder/'environment-stop.json').write_text(json.dumps(record,indent=2)+'\n')
 print('waiting for original child to finish',children,flush=True);time.sleep(1)
try:final=json.loads((folder/'result.json').read_text())
except (json.JSONDecodeError,OSError):final=d
assert final['executable']==d['executable'] and len(final['cases'])>=len(d['cases'])
(folder/'last-complete-result.json').write_text(json.dumps(final,indent=2)+'\n')
record.update(state='TERMINAL_ENVIRONMENT_INTERRUPTION_CHILD_DRAINED',completed_rows=len(final['cases']),unobserved_last_case=final.get('current_case'),last_case_note='An unrecorded in-flight child is not credited as PASS; rerun that name under corrected process environment.')
(folder/'environment-stop.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
