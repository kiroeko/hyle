from pathlib import Path

base=Path('.scratch/inference-gaps/g02')
s=(base/'run_vulkan_ce16_batch_tail.py').read_text(encoding='utf-8')
s=s.replace("folder=out/(route+'-batch-tail')","folder=out/(route+'-layer-resume')")
s=s.replace("working=build/f'tests/graph_route_{route}'", "env['VK_LAYER_PATH']='C:/public/tools/hyle-vulkan/1.4.357.0/Bin'\nenv['PATH']=env['VK_LAYER_PATH']+';'+env['PATH']\nrecord['validation_layer_discovery']={'path':env['VK_LAYER_PATH'],'proof':str(base/'windows-validation-layer-discovery.json'),'proof_sha256':sha(base/'windows-validation-layer-discovery.json'),'required_by':'Existing private native-reference Backend explicitly requests validation=true; main default Context validation setting unchanged'}\nworking=build/f'tests/graph_route_{route}'")
start=s.index("original_path=out/route/'result.json'");end=s.index('record.update(expected_cases=',start)
s=s[:start]+'''original_path=out/(route+'-batch-tail')/'last-complete-result.json'
original=json.loads(original_path.read_text())
stop_path=out/(route+'-batch-tail')/'environment-stop.json'
stop=json.loads(stop_path.read_text());assert stop['state']=='TERMINAL_ENVIRONMENT_INTERRUPTION_CHILD_DRAINED'
assert original['executable']==record['executable'] and original['expected_cases']==all_names
assert [r['name'] for r in original['cases']]==all_names[:len(original['cases'])]
pooled='VulkanGraphMoeFragments.D5GlmFlashPooledIndexerWithTail'
record['cases']=[r for r in original['cases'] if r['verdict']=='PASS' or r['name']==pooled]
names=[r['name'] for r in original['cases'] if r['verdict']!='PASS' and r['name']!=pooled]+all_names[len(original['cases']):]
assert len(set(names))==len(names) and len(names)+len(record['cases'])==851
record['inherited_evidence']={'path':str(original_path),'sha256':sha(original_path),'stop_path':str(stop_path),'stop_sha256':sha(stop_path),'actual_pass_preserved':sum(r['verdict']=='PASS' for r in record['cases']),'known_pooled_numeric_fail_preserved':1,'selected_environment_failures_and_pending':len(names)}
record['execution']='Same four fixed artifacts: preserve actual PASS and known pooled numeric FAIL; corrected process-only layer discovery, rerun observed environment failures plus originally unrun cases, one case/process serial. All earlier failures and in-flight interruption retained.'
''' + s[end:]
s=s.replace('for index,name in enumerate(names, start=102):','for index,name in enumerate(names):')
s=s.replace('print(route,index+1,len(all_names),name,child.pid,flush=True)','print(route,index+1,len(names),name,child.pid,flush=True)')
s=s.replace("assert sha(exe)==record['executable']['sha256'],'test executable changed during fixed run'", "by_name={r['name']:r for r in record['cases']};assert len(by_name)==len(record['cases'])==851 and set(by_name)==set(all_names)\nrecord['cases']=[by_name[n] for n in all_names]\nassert sha(exe)==record['executable']['sha256'],'test executable changed during fixed run'")
target=base/'run_vulkan_ce16_layer_resume.py';target.write_text(s,encoding='utf-8');compile(s,str(target),'exec');print(target)
