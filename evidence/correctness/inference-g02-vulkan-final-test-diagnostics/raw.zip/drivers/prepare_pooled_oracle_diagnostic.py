from pathlib import Path
import json,subprocess

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';out=base/'vulkan-pooled-oracle-diagnostic'
out.mkdir(exist_ok=False);build=Path('C:/h7/inference-g02-impacted')
rows=json.loads((build/'compile_commands.json').read_text())
row=next(r for r in rows if r['file'].replace('\\','/').endswith('/tests/graph_route_vulkan/d5_qwen35_execution_test.cc'))
(out/'compile-row.json').write_text(json.dumps(row,indent=2)+'\n')
commands=subprocess.check_output(['ninja','-C',str(build),'-f',str(base/'resume-windows-4/reuse-build.ninja'),'-t','commands','hyle_graph_route_vulkan_test'],text=True)
link=next(s for s in commands.splitlines() if 'vs_link_exe' in s and '/out:bin\\hyle_graph_route_vulkan_test.exe' in s)
(out/'original-link-command.txt').write_text(link,encoding='utf-8')
source=(base/'diagnose_vulkan_deepseek_outputs.py').read_text(encoding='utf-8')
source=source.replace("out=base/'vulkan-deepseek-output-diagnostic'","out=base/'vulkan-pooled-oracle-diagnostic'")
source=source.replace("old=json.loads((base/'remaining-windows-cases-1/vulkan/result.json').read_text());assert old['state']=='TERMINAL_FAIL' and len(old['cases'])==79", "old=json.loads((base/'current-windows-cases-ce16-1/vulkan/result.json').read_text());assert old['state']=='TERMINAL_FAIL' and len(old['cases'])==102")
start=source.index("probe='      if (")
end=source.index("s=s.replace(needle,probe+needle);",start)
probe='''      const bool full_f32_pool_scores = fixture.region >= 0x08030801 && fixture.region <= 0x08030804 && !fixture.quantized && std::any_of(fixture.nodes.begin(), fixture.nodes.end(), [&](const auto &node) {
        return node.operation.template get_if<c::MatMul>() && node.inputs.size()==2 && fixture.description(node.inputs[0]).data_type()==c::DataType::kFloat32 && fixture.description(node.inputs[1]).data_type()==c::DataType::kFloat32;
      });
      if (full_f32_pool_scores && output==5) {
        double max_f32=0,max_f16=0;std::size_t bad_f32=0,bad_f16=0;
        for(std::size_t i=0;i<actual.size();++i) {
          const double ref=expected.outputs[output][i],old=expected.native_outputs[output][i];
          const double e=std::abs(double(actual[i])-ref),old_e=std::abs(double(actual[i])-old);
          max_f32=std::max(max_f32,e);max_f16=std::max(max_f16,old_e);
          bad_f32+=e>fixture.absolute_tolerance+4e-5*std::abs(ref);bad_f16+=old_e>8e-5+4e-5*std::abs(old);
        }
        std::fprintf(stderr,"# G02_POOLED region=%llu step=%td output=%zu count=%zu max_f32=%.12g max_f16=%.12g bad_f32=%zu bad_f16=%zu\\n",static_cast<unsigned long long>(fixture.region),&expected-fixture.replays.data(),output,actual.size(),max_f32,max_f16,bad_f32,bad_f16);
      }
'''
source=source[:start]+'probe='+repr(probe)+'\n'+source[end:]
source=source.replace("s=s.replace(needle,probe+needle);", "s=s.replace(needle,probe+needle);s=s.replace('(full_f32_sdpa || expected.native_outputs.empty())','(full_f32_sdpa || full_f32_pool_scores || expected.native_outputs.empty())');")
source=source.replace('g02_vulkan_deepseek_output_diagnostic.exe','g02_vulkan_pooled_oracle_diagnostic.exe')
source=source.replace('VulkanGraphMoeFragments.D5DeepSeekFullAttentionChain','VulkanGraphMoeFragments.D5GlmFlashPooledIndexerWithTail')
source=source.replace("if 'G02_DEEPSEEK' in l and 'bad=0' not in l", "if 'G02_POOLED' in l")
source=source.replace("record={'state':'SETUP','scope':", "record={'state':'SETUP','scope':")
source=source.replace('One selected failed Graph fixture; scratch-only copy retains original independent F32 oracle and its stricter8e-5+4e-5 gate, prints F32/oldF16 differences.', 'One original pooled-indexer Graph case. Scratch-only select original independent F32 oracle at actual F32 MatMul boundary, nominal tolerance unchanged; compare to old F16 witness. Other outputs unchanged.')
target=base/'diagnose_vulkan_pooled_oracle.py';target.write_text(source,encoding='utf-8');compile(source,str(target),'exec')
print(target)
