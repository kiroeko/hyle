from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,time

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';out=base/'vulkan-pooled-oracle-diagnostic';build=Path('C:/h7/inference-g02-impacted')
old=json.loads((base/'current-windows-cases-ce16-1/vulkan/result.json').read_text());assert old['state']=='TERMINAL_FAIL' and len(old['cases'])==102
assert not (out/'result.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'state':'SETUP','scope':'One original pooled-indexer Graph case. Scratch-only select original independent F32 oracle at actual F32 MatMul boundary, nominal tolerance unchanged; compare to old F16 witness. Other outputs unchanged. Product, original test source, oracles, shapes and normal executable unchanged. No product verdict from this diagnostic alone.','stages':[]}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
shell32=ctypes.WinDLL('shell32',use_last_error=True)
shell32.CommandLineToArgvW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
shell32.CommandLineToArgvW.restype=ctypes.POINTER(ctypes.c_wchar_p)
kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
kernel32.LocalFree.argtypes=[ctypes.c_void_p];kernel32.LocalFree.restype=ctypes.c_void_p
def argv(s):
 count=ctypes.c_int();pointer=shell32.CommandLineToArgvW(s,ctypes.byref(count));assert pointer
 try:return [pointer[i] for i in range(count.value)]
 finally:kernel32.LocalFree(pointer)
row=json.loads((out/'compile-row.json').read_text());source=Path(row['file']);cpp=out/'diagnostic.cc';obj=out/'diagnostic.obj'
s=source.read_text(encoding='utf-8');needle='      sem::expect_output(fixture, actual, expected.outputs[output],';assert s.count(needle)==1
probe='      const bool full_f32_pool_scores = fixture.region >= 0x08030801 && fixture.region <= 0x08030804 && !fixture.quantized && std::any_of(fixture.nodes.begin(), fixture.nodes.end(), [&](const auto &node) {\n        return node.operation.template get_if<c::MatMul>() && node.inputs.size()==2 && fixture.description(node.inputs[0]).data_type()==c::DataType::kFloat32 && fixture.description(node.inputs[1]).data_type()==c::DataType::kFloat32;\n      });\n      if (full_f32_pool_scores && output==5) {\n        double max_f32=0,max_f16=0;std::size_t bad_f32=0,bad_f16=0;\n        for(std::size_t i=0;i<actual.size();++i) {\n          const double ref=expected.outputs[output][i],old=expected.native_outputs[output][i];\n          const double e=std::abs(double(actual[i])-ref),old_e=std::abs(double(actual[i])-old);\n          max_f32=std::max(max_f32,e);max_f16=std::max(max_f16,old_e);\n          bad_f32+=e>fixture.absolute_tolerance+4e-5*std::abs(ref);bad_f16+=old_e>8e-5+4e-5*std::abs(old);\n        }\n        std::fprintf(stderr,"# G02_POOLED region=%llu step=%td output=%zu count=%zu max_f32=%.12g max_f16=%.12g bad_f32=%zu bad_f16=%zu\\n",static_cast<unsigned long long>(fixture.region),&expected-fixture.replays.data(),output,actual.size(),max_f32,max_f16,bad_f32,bad_f16);\n      }\n'
s=s.replace(needle,probe+needle);s=s.replace('(full_f32_sdpa || expected.native_outputs.empty())','(full_f32_sdpa || full_f32_pool_scores || expected.native_outputs.empty())');cpp.write_text('#include <cstdio>\n'+s,encoding='utf-8')
record.update(original_test_sha256=sha(source),diagnostic_source_sha256=sha(cpp),normal_exe_sha256=sha(build/'bin/hyle_graph_route_vulkan_test.exe'))
env={k.upper():v for k,v in os.environ.items()}
for line in subprocess.check_output(['cmd','/d','/c',str(base/'resume-windows-2/vs-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
fixture=json.loads((base/'current-model-fixture.json').read_text());env['HYLE_D5_QWEN35_FIXTURE']=fixture['root']
def run(stage,args,cwd=build):
 t=time.monotonic();log=out/(stage+'.log')
 with log.open('w',encoding='utf-8') as f:
  child=subprocess.Popen(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  record.update(state='RUNNING',stage=stage,pid=child.pid);save();print(stage,child.pid,flush=True);code=child.wait()
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-t});save()
 if code and stage!='test':
  record['state']='TERMINAL_FAIL';save();print(log.read_text(errors='replace')[-5000:]);raise SystemExit(code)
args=argv(row['command']);assert str(source) in args
args[args.index(str(source))]=str(cpp)
for i,a in enumerate(args):
 if a.startswith('/Fo'):args[i]='/Fo'+str(obj)
 if a.startswith('/Fd'):args[i]='/Fd'+str(out/'compile.pdb')
args.insert(1,'/I'+str(source.parent))
run('compile',args)
link=(out/'original-link-command.txt').read_text();part=link[link.index('&& "')+3:].rsplit(' && cd .',1)[0]
args=argv(part);assert args[1:3]==['-E','vs_link_exe']
old_obj=str(Path(row['output']).relative_to(build));assert args.count(old_obj)==1
args[args.index(old_obj)]=str(obj)
binary=build/'bin/g02_vulkan_pooled_oracle_diagnostic.exe'
assert not binary.exists()
for i,a in enumerate(args):
 if a.startswith('--intdir='):args[i]='--intdir='+str(out/'link')
 if a.lower().startswith('/out:'):args[i]='/out:'+str(binary)
 if a.lower().startswith('/implib:'):args[i]='/implib:'+str(out/'diagnostic.lib')
 if a.lower().startswith('/pdb:'):args[i]='/pdb:'+str(out/'diagnostic.pdb')
(out/'link').mkdir(exist_ok=False)
run('link',args)
run('test',[str(binary),'--gtest_filter=VulkanGraphMoeFragments.D5GlmFlashPooledIndexerWithTail','--gtest_color=no','--gtest_output=xml:'+str(out/'test.xml')])
assert sha(source)==record['original_test_sha256'] and sha(build/'bin/hyle_graph_route_vulkan_test.exe')==record['normal_exe_sha256']
record.update(state='TERMINAL_DIAGNOSTIC_COLLECTED',binary_sha256=sha(binary));save()
print('\n'.join(l for l in (out/'test.log').read_text().splitlines() if 'G02_POOLED' in l),flush=True)
