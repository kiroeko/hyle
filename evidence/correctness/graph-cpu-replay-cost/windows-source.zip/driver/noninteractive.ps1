if (-not ('HyleValidationErrorMode' -as [type])) {
  Add-Type @'
using System.Runtime.InteropServices;
public static class HyleValidationErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
}
[void][HyleValidationErrorMode]::SetErrorMode(0x8003)
