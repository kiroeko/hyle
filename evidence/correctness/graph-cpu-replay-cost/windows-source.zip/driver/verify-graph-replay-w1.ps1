$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$r3Root = 'C:/hyle-scratch/r3-cpu-20260916'
$r3Source = 'C:/public/project-hyle/hyle'
$r3Build = "$r3Root/w1-source-shared"
$r3Log = "$r3Root/graph-replay-w1"
New-Item -ItemType Directory -Path $r3Log -Force | Out-Null
function Invoke-RC([string]$Name, [scriptblock]$Action) {
  & $Action *> "$r3Log/$Name.log"
  if ($LASTEXITCODE -ne 0) {
    Get-Content "$r3Log/$Name.log" -Tail 65
    exit $LASTEXITCODE
  }
}
$r3ProductPaths = @('src/graph/executable.cc', 'src/graph/plan_state.h', 'tests/graph/region_provider_test.cc')
$r3ProductPaths | ForEach-Object {
  [pscustomobject]@{Path=$_;Sha256=(Get-FileHash -LiteralPath "$r3Source/$_" -Algorithm SHA256).Hash}
} | ConvertTo-Json | Set-Content -Encoding utf8 "$r3Log/source-hashes.json"
Invoke-RC configure {
  cmake -S "$r3Root/consumer" -B $r3Build -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=ON -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON -DHYLE_COMPUTE_ONEDNN=AUTO "-DHYLE_SOURCE_DIR=$r3Source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3Source"
}
Invoke-RC build {
  cmake --build $r3Build --parallel 2 --target r3_consume_graph r3_consume_cpu_executor hyle_graph_test hyle_graph_executable_test hyle_graph_route_cpu_test hyle_graph_route_cpu_cpu_executor_test hyle_graph_provider_onednn_test
}
$r3Dlls = @(Get-ChildItem -LiteralPath "$r3Build/hyle_build/src" -Recurse -Filter '*.dll') + @(Get-ChildItem -LiteralPath "$r3Build/bin" -Filter '*.dll')
if (-not ($r3Dlls.Name -contains 'gtest.dll') -or -not ($r3Dlls.Name -contains 'gtest_main.dll')) { throw 'GoogleTest runtime DLLs are absent' }
if (@($r3Dlls | Group-Object Name | Where-Object Count -gt 1).Count -ne 0) { throw 'Ambiguous runtime DLL producer' }
$r3TestDirectories = @(Get-ChildItem -LiteralPath "$r3Build/hyle_build/tests" -Recurse -Filter '*.exe' | ForEach-Object DirectoryName | Sort-Object -Unique)
foreach ($r3Directory in $r3TestDirectories) {
  foreach ($r3Dll in $r3Dlls) {
    Copy-Item -LiteralPath $r3Dll.FullName -Destination (Join-Path $r3Directory $r3Dll.Name) -Force
  }
}
$r3Dlls | ForEach-Object { [pscustomobject]@{Path=$_.FullName;Sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash} } | ConvertTo-Json | Set-Content -Encoding utf8 "$r3Log/dll-staging.json"
Invoke-RC loader-preflight {
  & "$r3Build/hyle_build/tests/graph/hyle_graph_executable_test.exe" --gtest_list_tests
}
Invoke-RC tests {
  ctest --test-dir $r3Build --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -R '^hyle_graph_(test|executable_test)$|^hyle_graph_(provider_onednn|route_cpu)_(test|cpu_executor_test)$|^r3_consume_(graph|cpu_executor)$'
}
Copy-Item -LiteralPath "$r3Build/Testing/Temporary/LastTest.log" -Destination "$r3Log/LastTest.log"
Copy-Item -LiteralPath "$r3Build/CMakeCache.txt" -Destination "$r3Log/CMakeCache.txt"
Get-Content "$r3Log/tests.log" -Tail 18
