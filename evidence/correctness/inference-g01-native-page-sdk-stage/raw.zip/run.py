from pathlib import Path
import hashlib,json,os,subprocess,time,sys

route,mode=sys.argv[1:];assert route in ['apple','vulkan'] and mode in ['static','shared']
base=Path('/Users/kiro/hyle-scratch/compute-unified');canonical=base/'source-c8874688'
producer=base/f'a-{route}/selected-graph/{mode}-sdk-build';assert producer.is_dir()
out=base/f'g01-native-page-{route}-{mode}-sdk';out.mkdir(exist_ok=True)
source=out/'consumer-source';source.mkdir(exist_ok=True);build=out/'consumer-build'
stage=out/'staging';prefix=out/'relocated';record=out/'result.json'
rows=json.loads(record.read_text())['stages'] if record.exists() else []
identity={n:subprocess.check_output(a,text=True).strip() for n,a in [
    ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
    ('compiler',['xcrun','clang','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
candidate='520027a57ff41da96ac908ad0d35896e2dda9734'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def done(name):return next((r for r in reversed(rows) if r['stage']==name),{}).get('exit_code')==0
def run(name,args):
    number=1+sum(r['stage']==name for r in rows);log=out/f'{name}-{number}.log';start=time.monotonic()
    with log.open('w') as handle:result=subprocess.run(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
    row={'stage':name,'command':args,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)}
    rows.append(row);record.write_text(json.dumps({'candidate':candidate,'route':route,'mode':mode,'identity':identity,
        'scope':'actual relocated public compute SDK: page math, zero domain, cold allocator refusal and three standalone headers; test-only independent bit carriers, no internal targets/product headers or native fault hooks',
        'stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
    if result.returncode:
        with log.open('rb') as data:data.seek(max(0,log.stat().st_size-3500));print(data.read().decode(errors='replace'),flush=True)
        raise SystemExit(result.returncode)
if not done('producer-build'):
    run('producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target',
        f'hyle_compute_route_{route}','hyle_compute_batch','hyle_graph_batch','hyle_compute_state','--parallel','4'])
if not done('install'):
    assert not prefix.exists();run('install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
# The public compute SDK does not promise optional SIMD conversion helpers.
# These independent test-only carriers use the compiler's IEEE half encoder
# and a scalar BF16 bit encoder; the consumer retains its independent decoder.
oracle='''#pragma once
#include <bit>
#include <cstdint>
namespace page_oracle {
struct float16_t {std::uint16_t bits;};
struct bfloat16_t {std::uint16_t bits;};
inline float16_t f32_to_f16(float x){return {std::bit_cast<std::uint16_t>(static_cast<_Float16>(x))};}
inline bfloat16_t f32_to_bf16(float x){auto bits=std::bit_cast<std::uint32_t>(x);return {std::uint16_t((bits+0x7fff+((bits>>16)&1))>>16)};}
}
'''
(source/'oracle_dtype.h').write_text(oracle)
files=[f'tests/compute_batch/native_paged_{route}_consumer.cc','tests/compute_batch/native_paged_risk_fixture.h','tests/compute_batch/allocation_fault_fixture.h']
inputs=[]
for name in files:
    original=(canonical/name).read_bytes();data=original.replace(b'#include <hyle/simd/dtype.h>',b'#include "oracle_dtype.h"').replace(b'hyle::simd::',b'page_oracle::')
    path=source/Path(name).name;path.write_bytes(data)
    inputs.append({'path':name,'canonical_sha256':hashlib.sha256(original).hexdigest(),'consumer_sha256':hashlib.sha256(data).hexdigest()})
(out/'consumer-inputs.json').write_text(json.dumps({'files':inputs,'oracle_sha256':hashlib.sha256(oracle.encode()).hexdigest()},indent=2)+'\n')
apple='#define HYLE_G01_PAGE_RISK_APPLE 1\n' if route=='apple' else ''
create='n::MemoryResource::create(context)' if route=='apple' else 'n::MemoryResource::create(context,n::MemoryKind::kDevice)'
staging='n::MemoryResource::create(context)' if route=='apple' else 'n::MemoryResource::create(context,n::MemoryKind::kStaging)'
(source/'domains.cc').write_text(apple+'''#include "native_paged_risk_fixture.h"
namespace r=hyle_g01_page_risk;namespace n=r::n;
hyle::Status run(){HYLE_ASSIGN_OR_RETURN(auto context,n::Context::create());
HYLE_ASSIGN_OR_RETURN(auto device,'''+create+''');HYLE_ASSIGN_OR_RETURN(auto staging,'''+staging+''');
HYLE_ASSIGN_OR_RETURN(auto data,r::inputs(context,device,staging));
HYLE_RETURN_IF_ERROR(r::domain_checks(context,device,staging,data));return r::cold_failures(context,device,staging,data);}
int main(){auto status=run();if(!status.ok()){std::fprintf(stderr,"FAIL: %.*s\\n",int(status.message().size()),status.message().data());return 1;}return 0;}
''')
for i,header in enumerate(['batch_paged_native.h',f'{route}_batch.h','detail/materialized_native_controller.h']):
    (source/f'header-{i}.cc').write_text(f'#include <hyle/compute/{header}>\n')
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g01_native_page_public_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(paged native_paged_'''+route+'''_consumer.cc)
add_executable(domains domains.cc)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc)
foreach(t paged domains headers)
  target_compile_features(${t} PRIVATE cxx_std_23)
  target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(${t} PRIVATE hyle::compute)
endforeach()
hyle_stage_runtime(paged)
hyle_stage_runtime(domains)
''')
if not done('consumer-configure'):run('consumer-configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+str(prefix)])
if not done('consumer-build'):run('consumer-build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','paged','domains','headers','--parallel','4'])
if not done('paged-run'):run('paged-run',[str(build/'paged')])
if not done('domain-run'):run('domain-run',[str(build/'domains')])
print('TERMINAL PASS',route,mode,'relocated native page SDK',flush=True)
