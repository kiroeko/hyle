from pathlib import Path
import hashlib,json,os,subprocess,time

root=Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source=root/'native-a1329dd2'
build=root/'build-native-a1329dd2'
logs=root/'native-a1329dd2-logs'
logs.mkdir(exist_ok=False)
env=os.environ.copy()
env.update(PATH='/opt/homebrew/bin:'+env['PATH'],CMAKE_BUILD_PARALLEL_LEVEL='2',
           CTEST_PARALLEL_LEVEL='1',MACOSX_DEPLOYMENT_TARGET='14.4',
           DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib',
           VK_LAYER_PATH=str(root/'tools/vulkan-validationlayers/1.4.357.0/share/vulkan/explicit_layer.d'),
           VK_LOADER_LAYERS_DISABLE='~implicit~',HYLE_VULKAN_VALIDATION='1',
           VK_KHRONOS_VALIDATION_VALIDATE_SYNC='true',
           VK_KHRONOS_VALIDATION_DEBUG_ACTION='VK_DBG_LAYER_ACTION_LOG_MSG')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert head=='a1329dd2bbed2cf2b4e334345273b6c970052702'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
record={'candidate':head,'status':'RUNNING','started':time.time(),'environment':{k:v for k,v in env.items() if k in ('PATH','MACOSX_DEPLOYMENT_TARGET','DYLD_LIBRARY_PATH','VK_LAYER_PATH','VK_LOADER_LAYERS_DISABLE','HYLE_VULKAN_VALIDATION','VK_KHRONOS_VALIDATION_VALIDATE_SYNC')}}
def run(args,name,timeout):
    print('RUN',name,flush=True)
    start=time.time()
    with (logs/name).open('w') as f:
        p=subprocess.run([str(x) for x in args],cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    print('DONE',name,'exit',p.returncode,'seconds',round(time.time()-start,2),flush=True)
    print((logs/name).read_text()[-4000:],flush=True)
    if p.returncode: raise RuntimeError(f'{name} exit {p.returncode}')
try:
    (logs/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
    run(['/opt/homebrew/bin/cmake','-S',source,'-B',build,'-G','Ninja',
         '-DCMAKE_BUILD_TYPE=Release','-DHYLE_DEV_FACTORS=compute_route_vulkan;graph_route_vulkan',
         '-DHYLE_COMPUTE_VULKAN=ON','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF',
         '-DHYLE_STATIC=ON','-DHYLE_WERROR=ON','-DHYLE_INSTALL=OFF',
         '-DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator'], 'configure.log',240)
    run(['/opt/homebrew/bin/cmake','--build',build,'--parallel','2','--target',
         'hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests'],'build.log',600)
    run(['/opt/homebrew/bin/ctest','--test-dir',build,'--output-on-failure','--no-tests=error',
         '--timeout','120','-L','^(compute_route_vulkan|graph_route_vulkan)$'],'ctest.log',300)
    text=(build/'Testing/Temporary/LastTest.log').read_text()
    (logs/'LastTest.log').write_text(text)
    assert not any(marker in text for marker in ('Validation Error','VUID-','SYNC-HAZARD')), 'validation error: inspect LastTest.log'
    record['status']='PASS'
except Exception as error:
    record.update(status='FAIL',error=str(error))
    raise
finally:
    record['finished']=time.time()
    record['source_unchanged']=not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
    (logs/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
