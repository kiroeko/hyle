$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:PYTHONUTF8='1'
$env:PATH='C:/public/tools/glslang;'+$env:PATH
python C:/h7/continue-selected-windows-v3.py
exit $LASTEXITCODE
