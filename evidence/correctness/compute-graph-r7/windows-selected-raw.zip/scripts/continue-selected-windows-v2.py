"""Run only failed/unrun declared gates after a one-test expectation correction.

The original BLOCKED selector report is immutable. This is an explicit coverage
continuation, not a forged selector cache entry or a replacement PASS report.
"""
from pathlib import Path
import ctypes, hashlib, importlib.util, json, os, subprocess, sys, time

root=Path('C:/h7/candidate')
task=Path('C:/h7/selected-windows-continuation-02')
task.mkdir(exist_ok=False)
candidate='6bccb96b248eb5eef03240c149dbc129f0fa4875'
initial=Path('C:/h7/selected-windows/result.json')
old=json.loads(initial.read_text(encoding='utf-8'))
paths=json.loads(Path('C:/h7/selected-windows/paths.json').read_text(encoding='utf-8'))
build=Path(paths['build']); scratch=Path(paths['scratch'])
os.environ.update(PYTHONUTF8='1',HYLE_DEP_SOURCE_CACHE='C:/public/project-hyle/.deps',
                  CMAKE_BUILD_PARALLEL_LEVEL='2',CTEST_PARALLEL_LEVEL='1',
                  CTEST_INTERACTIVE_DEBUG_MODE='0',VK_LOADER_LAYERS_DISABLE='~implicit~')
ctypes.windll.kernel32.SetErrorMode(0x8003)
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==candidate and not git('status','--porcelain')
assert set(git('diff','--name-only',old['candidate_commit'],candidate).splitlines()) == {'tests/graph/executable_test.cc','tests/graph_route_apple/graph_test.cc','tests/graph_route_vulkan/graph_test.cc'}
assert all(git('rev-parse',old['candidate_commit']+':'+p)==git('rev-parse',candidate+':'+p)
           for p in ('src','include','cmake','samples','bench','scripts'))
spec=importlib.util.spec_from_file_location('selector',root/'scripts/validation-select.py')
selector=importlib.util.module_from_spec(spec); spec.loader.exec_module(selector)
plan=selector.make_plan(root,'14e78c45',candidate,context=Path(paths['context']))
assert plan['verdict']!='BLOCKED'
selector.write_json(task/'plan.json',selector.public_report(plan))
fresh={g['id']:g for g in plan['gates']}
prior_path=Path('C:/h7/selected-windows-continuation/result.json')
prior=json.loads(prior_path.read_text(encoding='utf-8'))
prior_passes={g['id'] for g in prior['gates'] if g['status']=='PASS'}
gates=[g for g in old['selected_gates'] if (g['status']!='PASS' and g['id'] not in prior_passes) or g['id'] in ('docs','closure','configure')]
record={'candidate':candidate,'verdict':'RUNNING','initial_result':str(initial),
        'initial_result_sha256':sha(initial),'initial_verdict_preserved':old['verdict'],
        'build_reuse':'same source path; only three test files changed; product/build/consumer/bench/script trees identical',
        'unchanged_product_trees':{p:git('rev-parse',candidate+':'+p) for p in ('src','include','cmake','samples','bench','scripts')},
        'inherited_passes':[{'id':g['id'],'candidate':old['candidate_commit'],'receipt':g['receipt'],
                              'receipt_sha256':sha(Path(g['receipt']))}
                            for g in old['selected_gates'] if g['status']=='PASS' and g['id'] not in ('docs','closure','configure')],
        'prior_continuation':{'path':str(prior_path),'sha256':sha(prior_path),'candidate':prior['candidate'],
                              'verdict_preserved':prior['verdict'],'pass_gates':sorted(prior_passes)},
        'gates':[]}
def save(): (task/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
replace={'{root}':str(root),'{build}':str(build),'{scratch}':str(scratch),'{python}':sys.executable}
try:
 save()
 for gate in gates:
  assert gate['commands']==fresh[gate['id']]['commands'],gate['id']
  current={'id':gate['id'],'status':'RUNNING','commands':[]};record['gates'].append(current);save()
  print('RUN '+gate['id'],flush=True)
  for n,command in enumerate(gate['commands']):
   args=list(command)
   for key,value in replace.items(): args=[x.replace(key,value) for x in args]
   log=task/(gate['id'].replace(':','-')+'-'+str(n)+'.log'); start=time.monotonic()
   with log.open('w',encoding='utf-8') as stream:
    run=subprocess.run(args,cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=3600)
   current['commands'].append({'argv':args,'exit_code':run.returncode,'seconds':time.monotonic()-start,
                               'log':str(log),'log_sha256':sha(log)});save()
   if run.returncode:
    current['status']='FAIL';save()
    print(log.read_text(encoding='utf-8',errors='replace')[-9000:],flush=True)
    run.check_returncode()
  current['status']='PASS';save()
 record['verdict']='PASS'
except Exception as error:
 record.update(verdict='BLOCKED',error=str(error));raise
finally:
 save()
