"""Resume the exact R7 Windows ON recipe; preserve OFF and the original FAIL."""
from pathlib import Path
import argparse, ctypes, hashlib, json, os, platform, shutil, subprocess, sys, time, zipfile

original = Path('C:/h7/r7-delivery.py')
root = Path('C:/h7/dw7')
old_logs = root / 'logs'
logs = root / 'logs-complete'
prior = json.loads((old_logs / 'identity.json').read_text(encoding='utf-8'))
recipe = original.read_text(encoding='utf-8')
assert prior['state'] == 'FAIL'
assert prior['commands'][-1]['label'] == 'on-source-configure'
assert prior['commands'][-1]['exit_code'] != 0
assert all(c['exit_code'] == 0 for c in prior['commands'][:-1])
assert len(prior['executables']) == 6
assert prior['off_producers_hidden']
assert prior['validation_script_sha256'] == hashlib.sha256(original.read_bytes()).hexdigest()
assert Path('C:/h7/windows-delivery-failure-01/logs/identity.json').read_bytes() == (old_logs / 'identity.json').read_bytes()
logs.mkdir(exist_ok=False)
for entry in old_logs.iterdir():
    if entry.is_file() and entry.name not in ('identity.json', 'on-source-configure.log'):
        shutil.copyfile(entry, logs / entry.name)

# Reuse the original environment and helper functions verbatim.
exec(compile(recipe[recipe.index("windows=os.name"):recipe.index("record={'candidate'")], str(original), 'exec'))
exec(compile(recipe[recipe.index('def sha(p)'):recipe.index('\ntry:\n')], str(original), 'exec'))
record = prior.copy()
record['commands'] = prior['commands'][:-1]
record.update(state='RUNNING', continuation_script_sha256=sha(Path(__file__)),
              continuation_scope='Only TRACE ON; 25 successful OFF commands and six consumers retained unchanged.',
              previous_failure={'identity_sha256': sha(old_logs / 'identity.json'),
                                'path': str(old_logs / 'identity.json'),
                                'failed_label': 'on-source-configure',
                                'reason': 'Locked Tracy dependency absent from the offline source cache; populated with the existing dependency-cache tool.'})
record.pop('error', None)
record.pop('finished', None)
extracted = root / 'source'
tree = extracted / 'hyle-0.1.0-source'
consumers = root / 'independent-consumers'
parent = root / 'parent'
source_build = root / 'source-build'
shared_build = root / 'shared-build'
assert all(p.is_dir() for p in (tree, consumers, parent, source_build, shared_build))
assert commit in (tree / 'SOURCE-MANIFEST.txt').read_text(encoding='utf-8')
assert len(record['commands']) == 25
assert sha(Path('C:/h7/dist/87ae5834/hyle-0.1.0-source.zip')) == record['archive_sha256']
assert not any(root.glob('on-*-sdk*'))
start = recipe.index("    for trace in ('OFF','ON'):")
stop = recipe.index("    record['state']='PASS'", start)
body = recipe[start:stop]
assert body.count("for trace in ('OFF','ON'):") == 1
body = body.replace("for trace in ('OFF','ON'):", "for trace in ('ON',):", 1)
body = '\n'.join(line[4:] if line.startswith('    ') else line for line in body.splitlines())
try:
    save()
    exec(compile(body, str(original), 'exec'))
    assert len(record['commands']) == 50 and len(record['executables']) == 12
    record['state'] = 'PASS'
except Exception as error:
    record.update(state='FAIL', error=str(error))
    raise
finally:
    record['finished'] = time.time()
    save()
