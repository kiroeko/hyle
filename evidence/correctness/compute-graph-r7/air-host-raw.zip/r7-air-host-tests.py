"""Finite R7 host ASan/UBSan and native report lifetime/OOM acceptance."""
from pathlib import Path
import hashlib,json,os,platform,shutil,subprocess,time

root=Path('/Users/kiro/hyle-verify/r7-e84a7ad3')
source=root/'source'; build=root/'host-report-tests'
logs=root/'host-report-tests-logs'; logs.mkdir(exist_ok=False)
candidate='87ae583407cbb5ed13108c3837b020e6e343a3ca'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==candidate
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='2',CTEST_PARALLEL_LEVEL='1',
         ASAN_OPTIONS='halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',
         DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib',VK_LOADER_LAYERS_DISABLE='~implicit~',
         HYLE_VULKAN_VALIDATION='0',MACOSX_DEPLOYMENT_TARGET='14.4')
env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
for name in ('CMAKE_TOOLCHAIN_FILE','CMAKE_PREFIX_PATH','MLX_METAL_PATH','DYLD_FALLBACK_LIBRARY_PATH'):
 env.pop(name,None)
owners=('compute','graph','compute_route_apple','graph_route_apple','compute_route_vulkan','graph_route_vulkan')
record={'candidate':candidate,'verdict':'RUNNING','commands':[],'sanitizers':[],
        'host':platform.uname()._asdict(),
        'validation_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':'HYLE host C++ correctness, cold report OOM/reset and owners released; vendor MLX/driver/GPU not instrumented; no performance samples'}
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(): (logs/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,command,timeout=3600):
 print(label,flush=True); start=time.monotonic(); log=logs/(label+'.log')
 with log.open('w') as out:
  p=subprocess.run([str(x) for x in command],cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
 record['commands'].append({'label':label,'argv':[str(x) for x in command],'exit_code':p.returncode,
                            'seconds':time.monotonic()-start,'log_sha256':sha(log)});save()
 if p.returncode: print(log.read_text()[-9000:],flush=True)
 p.check_returncode()
try:
 save()
 for sanitizer,flag in (('asan','address'),('ubsan','undefined')):
  run(sanitizer+'-configure',['cmake','-S',source,'-B',build,'-G','Ninja',
      '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
      '-DHYLE_DEV_FACTORS='+','.join((*owners,'compute_backend_cpu','compute_provider_native')),
      '-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=ON',
      '-DHYLE_COMPUTE_VULKAN=ON','-DHYLE_COMPUTE_ONEDNN=OFF',
      '-DHYLE_STATIC=ON','-DHYLE_INSTALL=OFF','-DHYLE_TRACE=OFF',
      '-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON',
      '-DHYLE_SANITIZER='+sanitizer,'-DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator',
      '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
  run(sanitizer+'-build',['cmake','--build',build,'--parallel','2','--target',
      *['hyle_'+o+'_tests' for o in owners],'hyle_graph_executable_test'])
  commands=json.loads((build/'compile_commands.json').read_text())
  own=[x for x in commands if any('/'+area+'/'+o+'/' in x['file'] for o in owners for area in ('src','tests'))]
  assert own and all('-fsanitize='+flag in x['command'] for x in own)
  (logs/(sanitizer+'-instrumented-commands.json')).write_text(json.dumps(own,indent=2)+'\n')
  shutil.copyfile(build/'CMakeCache.txt',logs/(sanitizer+'-CMakeCache.txt'))
  run(sanitizer+'-tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error',
      '--timeout','180','-L','^('+'|'.join(owners)+')$','-LE','headers'],900)
  shutil.copyfile(build/'Testing/Temporary/LastTest.log',logs/(sanitizer+'-LastTest.log'))
  if sanitizer=='asan':
   run('public-headers',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error',
       '--timeout','180','-L','^('+'|'.join(owners)+')$','-R','_header_self_contained_test$'],900)
   shutil.copyfile(build/'Testing/Temporary/LastTest.log',logs/'headers-LastTest.log')
  names=['hyle_'+o+'_test' for o in owners]+['hyle_graph_executable_test']
  record['sanitizers'].append({'sanitizer':sanitizer,'verdict':'PASS','instrumented_units':len(own),
                              'artifacts':{n:sha(build/'bin'/n) for n in names}});save()
 record['verdict']='PASS'
except Exception as error:
 record.update(verdict='BLOCKED',error=str(error));raise
finally:
 save()
