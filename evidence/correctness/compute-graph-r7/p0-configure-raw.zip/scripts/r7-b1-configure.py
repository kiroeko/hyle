"""Finite configuration tests for R7's optional TRACE contradiction."""
from pathlib import Path
import argparse, hashlib, json, subprocess

p=argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--output', required=True)
a=p.parse_args()
repo=Path(a.repo).resolve()
out=Path(a.output).resolve()
out.mkdir(parents=True, exist_ok=True)
assert not (out/'result.json').exists(), 'inspect an existing attempt before rerunning'
cases=[
 ('enabled', True, 'TRACE SOURCES hook.cc', None),
 ('enabled-missing-trace', True, 'SOURCES hook.cc', 'real target omitted TRACE'),
 ('enabled-unauthorized-trace', False, 'TRACE SOURCES hook.cc', 'not declare this trace consumer'),
 ('enabled-no-hook', True, 'TRACE SOURCES plain.cc', 'no HYLE_TRACE use exists'),
 ('enabled-undeclared-hook', False, 'SOURCES hook.cc', 'module did not declare TRACE'),
 ('absent', True, 'OPTIONAL_ABSENT', None),
 ('absent-sources', True, 'OPTIONAL_ABSENT SOURCES hook.cc', 'SOURCES are contradictory'),
 ('absent-trace', True, 'OPTIONAL_ABSENT TRACE', 'TRACE/TESTING require an implementation'),
 ('absent-testing', True, 'OPTIONAL_ABSENT TESTING', 'TRACE/TESTING require an implementation'),
]
records=[]
for name, central, args, refusal in cases:
 d=out/name
 d.mkdir()
 (d/'hook.cc').write_text('#define HYLE_TRACE_ZONE_NAMED(x) (void)0\nvoid probe() { HYLE_TRACE_ZONE_NAMED("probe"); }\n')
 (d/'plain.cc').write_text('void probe() {}\n')
 cmake=f'''cmake_minimum_required(VERSION 3.25)
project(OptionalTraceProbe VERSION 1.0 LANGUAGES CXX)
set(HYLE_STATIC ON)
set(HYLE_INSTALL_INCLUDEDIR include)
set(HYLE_KNOWN_COMPONENTS probe dep)
set(_HYLE_TRACE_PROBE {'TRUE' if central else 'FALSE'})
set(_HYLE_DEPS_PROBE dep)
set(_HYLE_PRIVATE_DEPS_PROBE dep)
set(_HYLE_PRIVATE_BUILD_DEPS_PROBE private)
add_library(hyle_dep INTERFACE)
add_library(hyle_private INTERFACE)
add_library(hyle_build_contract INTERFACE)
add_library(hyle_trace INTERFACE)
function(_hyle_component_public_headers name out)
  set(${{out}} "" PARENT_SCOPE)
endfunction()
function(hyle_apply_warnings target)
endfunction()
function(hyle_apply_sanitizer target)
endfunction()
include("{repo.as_posix()}/cmake/HyleModule.cmake")
hyle_add_module(probe {args})
get_target_property(kind hyle_probe TYPE)
get_target_property(links hyle_probe INTERFACE_LINK_LIBRARIES)
get_target_property(source hyle_probe SOURCES)
get_property(consumed GLOBAL PROPERTY HYLE_TRACE_CONSUMED)
'''
 if name=='absent':
  cmake+='''if(NOT kind STREQUAL "INTERFACE_LIBRARY" OR source OR consumed OR
   links MATCHES "hyle_(trace|dep|private)")
  message(FATAL_ERROR "absent implementation leaked sources/private/trace")
endif()
'''
 elif name=='enabled':
  cmake+='''if(NOT kind STREQUAL "STATIC_LIBRARY" OR NOT consumed OR
   NOT links MATCHES "hyle_trace")
  message(FATAL_ERROR "enabled implementation lost trace dependency")
endif()
'''
 (d/'CMakeLists.txt').write_text(cmake,encoding='utf-8')
 command=['cmake','-S',str(d),'-B',str(d/'build'),'-G','Ninja']
 run=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace')
 (d/'configure.log').write_text(run.stdout,encoding='utf-8')
 valid=(run.returncode==0) if refusal is None else (run.returncode!=0 and refusal in ' '.join(run.stdout.split()))
 records.append({'case':name,'command':command,'expected_refusal':refusal,'exit_code':run.returncode,'verdict':'PASS' if valid else 'FAIL'})
 print(name,records[-1]['verdict'],flush=True)
 if not valid:
  print(run.stdout)
helper=repo/'cmake/HyleModule.cmake'
result={'scope':'configuration semantics only; real OFF/ON runtime and delivery use R7 acceptance',
        'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),
        'cases':records,'verdict':'PASS' if all(x['verdict']=='PASS' for x in records) else 'FAIL'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(0 if result['verdict']=='PASS' else 1)
