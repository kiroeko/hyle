"""Qualify exact codegen differences without measuring time or changing code."""
from pathlib import Path
import hashlib,json,re,subprocess

root=Path('C:/public/project-hyle/hyle')
base=Path('C:/hv6/305895ce49352b4cc9bb/build-322309162a83db32cb35')
current=Path('C:/h7/s/87fe0b7160a4b659aebc/build-175032495e75411e0604')
source=Path('C:/h7/compare-off-codegen.py').read_text(encoding='utf-8').split('old=Path(')[0]
source=source.replace("'bytes':sha(data[raw:raw+size])", "'bytes':sha(data[raw:raw+size]),'hex':data[raw:raw+size].hex()")
scope={};exec(source,scope)
record=json.loads(Path('C:/h7/off-codegen-progress.json').read_text(encoding='utf-8'))
record['current_test_only_candidate']='81ed40dd558824ea9a45841fb19d35661d130bb7'
record['normalizations']=[
 'MSVC anonymous namespace TU path hash (?A0x...) is normalized; function names, relocation offsets and kinds remain exact.',
 'DelegatedInvocation::submit_after has the same fatal-assert instruction but line immediate 2104 -> 2109 and source-file string relocation changed with checkout path. No other byte is normalized.'
]
def text_at(revision,path):
 return subprocess.check_output(['git','show',revision+':'+path],cwd=root).decode('utf-8')
op='src/compute/operation.cc'
before=text_at(record['baseline_binary_candidate'],op).splitlines()
after=text_at(record['candidate'],op).splitlines()
assert before[2103].strip()==after[2108].strip()=='HYLE_FATAL_ASSERT(attached.ok());'
record['assert_source']={'file':op,'before_line':2104,'after_line':2109,'text':after[2108].strip()}
for row in record['entries']:
 assert row['verdict']!='PENDING_BUILD'
 old,_=scope['coff'](base/row['file']); new,_=scope['coff'](current/row['file'])
 name=row['symbol']; x=old[name];y=new[name]
 xb=bytearray.fromhex(x['hex']);yb=bytearray.fromhex(y['hex'])
 def normalized(relocs):
  return [(offset,re.sub(r'\?A0x[0-9a-f]+','?AnonTU',symbol),kind) for offset,symbol,kind in relocs]
 xr=normalized(x['relocations']);yr=normalized(y['relocations'])
 changes=[]
 if name.startswith('?submit_after@DelegatedInvocation@compute@hyle@@'):
  assert xb[1043:1051].hex()=='c744242038080000'
  assert yb[1043:1051].hex()=='c74424203d080000'
  changes.append({'kind':'fatal_assert_line_immediate','offset':1047,'before':2104,'after':2109})
  xb[1047:1051]=yb[1047:1051]
  for i,(u,v) in enumerate(zip(xr,yr)):
   if u!=v:
    assert u[0]==v[0]==950 and u[2]==v[2]==4
    assert 'C?3?2hyle?9scratch?' in u[1] and 'C?3?2h7?2candidate?' in v[1]
    changes.append({'kind':'assert_source_path','before':u,'after':v})
    xr[i]=(950,'<source_file_path>',4);yr[i]=(950,'<source_file_path>',4)
 assert xb==yb and xr==yr,(row['file'],name)
 row['semantic_verdict']='IDENTICAL_INSTRUCTIONS_AND_CALLEES_EXCEPT_VERIFIED_DEBUG_IDENTITY'
 row['explicit_metadata_differences']=changes
 row['instruction_bytes_identical']=x['hex']==y['hex']
record['verdict']='PASS'
record['scope']+=' This is a P0 cost proof, not an elapsed-time or profiler-ON performance claim.'
Path('C:/h7/off-codegen-final.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('PASS',len(record['entries']),'function/COMDAT bodies; only verified metadata differences')
