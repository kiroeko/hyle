"""Compare representative real MSVC Release COMDATs; no timing or recompilation."""
from pathlib import Path
import hashlib, json, struct

def sha(data): return hashlib.sha256(data).hexdigest()

def coff(path):
    data=path.read_bytes()
    big=data[:4]==b'\0\0\xff\xff'
    if big:
        section_count, symbols_at, symbol_count=struct.unpack_from('<III',data,44)
        sections_at, entry_size=56,20
    else:
        _,section_count,_,symbols_at,symbol_count,optional,_=struct.unpack_from('<HHIIIHH',data)
        sections_at,entry_size=20+optional,18
    strings_at=symbols_at+symbol_count*entry_size
    def name(raw):
        if raw[:4]==b'\0'*4:
            start=strings_at+struct.unpack_from('<I',raw,4)[0]
            return data[start:data.index(b'\0',start)].decode('ascii')
        return raw.split(b'\0',1)[0].decode('ascii')
    symbols={}
    index=0
    while index<symbol_count:
        at=symbols_at+index*entry_size
        symbol=name(data[at:at+8])
        value=struct.unpack_from('<I',data,at+8)[0]
        section=struct.unpack_from('<i' if big else '<h',data,at+12)[0]
        kind,storage,aux=struct.unpack_from('<HBB',data,at+(16 if big else 14))
        symbols[index]=(symbol,section,value,kind,storage)
        index+=1+aux
    sections={}
    for index in range(section_count):
        at=sections_at+index*40
        size,raw,relocs=struct.unpack_from('<III',data,at+16)
        count=struct.unpack_from('<H',data,at+32)[0]
        flags=struct.unpack_from('<I',data,at+36)[0]
        if not flags & 0x20: continue
        relocation=[]
        for n in range(count):
            offset,sym,kind=struct.unpack_from('<IIH',data,relocs+n*10)
            relocation.append((offset, symbols[sym][0],kind))
        sections[index+1]={'bytes':sha(data[raw:raw+size]),'size':size,'relocations':relocation}
    return {s[0]:sections[s[1]] for s in symbols.values() if s[1] in sections and s[3]&0x20 and s[2]==0},sha(data)

old=Path('C:/hv6/305895ce49352b4cc9bb/build-322309162a83db32cb35')
new=Path('C:/h7/s/87fe0b7160a4b659aebc/build-175032495e75411e0604')
entries=[]
for factor,filename,patterns in [
 ('compute','completion.cc',['?wait@Completion@compute@hyle@@']),
 ('compute','operation.cc',['?submit@OperationInvocation@compute@hyle@@','?submit_after@DelegatedInvocation@compute@hyle@@']),
 ('graph','executable.cc',['?submit@Invocation@graph@hyle@@']),
 ('compute_route_vulkan','vulkan_run.cc',['submit_locked']),
]:
    relative=f'src/{factor}/CMakeFiles/hyle_{factor}.dir/{filename}.obj'
    if not (new/relative).exists():
        entries.append({'file':relative,'verdict':'PENDING_BUILD'})
        continue
    before,old_hash=coff(old/relative)
    after,new_hash=coff(new/relative)
    matched=[name for name in before if any(p in name for p in patterns)]
    assert matched, (relative, list(before)[:8])
    for symbol in matched:
        entries.append({'file':relative,'symbol':symbol,'baseline_object_sha256':old_hash,
            'candidate_object_sha256':new_hash,'before':before[symbol],
            'after':after.get(symbol),'verdict':'IDENTICAL' if before[symbol]==after.get(symbol) else 'DIFFERENT'})
result={'baseline_binary_candidate':'3894b72e3b4fbbda9457e2c31730e48bd0d43c49',
        'candidate':'e84a7ad3950ee6d7a4fbed88a6d58a8f4c08c4ff',
        'scope':'MSVC 19.50 Release shared TRACE=OFF; real function instructions and symbolic relocation targets. No performance sampling; cold reports excluded.',
        'entries':entries}
Path('C:/h7/off-codegen-progress.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for row in entries: print(row['file'],row.get('symbol',''),row['verdict'])
