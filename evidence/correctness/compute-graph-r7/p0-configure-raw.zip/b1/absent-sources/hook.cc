#define HYLE_TRACE_ZONE_NAMED(x) (void)0
void probe() { HYLE_TRACE_ZONE_NAMED("probe"); }
