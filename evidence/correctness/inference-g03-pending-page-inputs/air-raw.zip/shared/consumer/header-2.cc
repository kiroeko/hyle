#include <hyle/compute/detail/copy_stream_access.h>
