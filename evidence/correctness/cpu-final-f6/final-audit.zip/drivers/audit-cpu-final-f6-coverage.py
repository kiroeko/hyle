import hashlib,json,re,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f6';out.mkdir(parents=True,exist_ok=True)
demand=json.loads((repo/'docs/implementation/tasks/compute/cpu-final-demand-carriers.json').read_text())
witness=json.loads((repo/'evidence/correctness/cpu-quant-mtp-c5-required/family-witness-index.json').read_text())
assert demand['counts']=={'gguf_profiles':104,'gguf_numeric':559,'packed_non_gguf':34,'plain_non_gguf':45,'gguf_parameter_role_shape':80}
sets={};inputs=[]
def read_xml(archive,member,platform,entry):
    with zipfile.ZipFile(repo/archive) as z:data=z.read(member)
    root=ET.fromstring(data);key=(platform,entry);target=sets.setdefault(key,{})
    for case in root.findall('.//testcase'):
        name=case.get('classname')+'.'+case.get('name')
        target[name]={'pass':case.find('failure') is None and case.find('skipped') is None,
                      'receipt':archive+'#'+member}
    inputs.append({'archive':archive,'member':member,'platform':platform,'entry':entry,
        'sha256':hashlib.sha256(data).hexdigest(),'tests':len(root.findall('.//testcase'))})
base='evidence/correctness/cpu-final-f3/'
for entry in ('direct','graph'):
    # Earlier complete cases, then precise ARM/fixture corrections, then the
    # final same-input complete sidecar correction. Preserve original failure
    # files in their archive; latest equal-name outcomes are the current proof.
    for member in ('mac-'+entry+'-corrected.xml','mac-c5-'+entry+'.xml', 'mac-c5-'+entry+'-t5.xml'):
        with zipfile.ZipFile(repo/base/'mac-carriers-c5.zip') as z:exists=member in z.namelist()
        if exists:read_xml(base+'mac-carriers-c5.zip',member,'mac',entry)
    for member in ('mac-remaining-'+entry+('-first' if entry=='graph' else '')+'.xml',
                   'mac-precision-'+entry+('-affected' if entry=='graph' else '')+'.xml',
                   'mac-final-numeric-'+entry+'.xml'):
        read_xml(base+'mac-precision-composition.zip',member,'mac',entry)
    with zipfile.ZipFile(repo/base/'current-isa-deltas.zip') as z:
        names=[n for n in z.namelist() if n.endswith('mac-'+entry+'-isa-delta.xml')]
    assert len(names)==1,names
    read_xml(base+'current-isa-deltas.zip',names[0],'mac',entry)
with zipfile.ZipFile(repo/base/'linux-current-carriers.zip') as z:
    print('linux xml members', [n for n in z.namelist() if n.endswith('.xml')])
    xml_names=[n for n in z.namelist() if n.endswith('.xml')]
for entry in ('direct','graph'):
    names=[n for n in xml_names if n.endswith('/'+entry+'.xml') or n==entry+'.xml']
    if entry=='graph' and not names:names=['corrected-graph.xml']
    corrections=[n for n in xml_names if entry in n and 'correct' in n]
    assert len(names)==1,(entry,names)
    read_xml(base+'linux-current-carriers.zip',names[0],'linux',entry)
    for name in corrections:read_xml(base+'linux-current-carriers.zip',name,'linux',entry)
    with zipfile.ZipFile(repo/base/'current-isa-deltas.zip') as z:
        names=[n for n in z.namelist() if n.endswith('linux/'+entry+'.xml')]
    if not names:
        with zipfile.ZipFile(repo/base/'current-isa-deltas.zip') as z:
            names=[n for n in z.namelist() if n.endswith('linux-'+entry+'.xml')]
    assert len(names)==1,names
    read_xml(base+'current-isa-deltas.zip',names[0],'linux',entry)
# Current full Windows output is archived intact. CTest truncates successful
# program XML output, so take each named program's complete raw section.
archive='evidence/correctness/cpu-final-f5/windows-correctness.zip'
with zipfile.ZipFile(repo/archive) as z:raw=z.read('raw/complete-ctest-last-test.log').decode('utf-8','replace').replace('\r\n','\n')
for entry,program in [('direct','hyle_compute_route_cpu_test'),('graph','hyle_graph_route_cpu_test')]:
    section=raw.split('Testing: '+program+'\n',1)[1].split('Test time =',1)[0]
    target=sets.setdefault(('windows',entry),{})
    for state,name in re.findall(r'^\[\s*(OK|FAILED|SKIPPED)\s*\]\s+([^\s]+)\s+\(',section,re.MULTILINE):
        target[name]={'pass':state=='OK','receipt':archive+'#raw/complete-ctest-last-test.log'}
read_xml(archive,'raw/ordinary-select-policy-corrected.xml','windows','graph')

ports={group:[x['id'] for x in demand[group]] for group in ('gguf_ports','non_gguf_ports','plain_ports')}
coverage=[];missing=[]
for platform in ('windows','linux','mac'):
    for entry in ('direct','graph'):
        tests=sets[(platform,entry)]
        ids={name.rsplit('/',1)[-1]:item for name,item in tests.items() if item['pass']}
        row={'platform':platform,'entry':entry,'port_groups':{},'families':[]}
        for group,required in ports.items():
            absent=[name for name in required if name not in ids]
            row['port_groups'][group]={'required':len(required),'passed':len(required)-len(absent),'missing':absent}
            missing.extend((platform,entry,group,name) for name in absent)
        for family in witness['families']:
            regions=[]
            for region in family['semantic_regions']:
                names={item['testcase'] for record in region['witness']['results'] if record['entry']==entry for item in record['passed']}
                matches=[{'testcase':name,**tests[name]} for name in names if name in tests and tests[name]['pass']]
                regions.append({'region':region['region'],'proof':matches})
                if not matches:missing.append((platform,entry,family['family'],region['region']))
            row['families'].append({'family':family['family'],'regions':regions})
        coverage.append(row)
report={'scope':'F6 read-only exact demand/witness join; not final acceptance',
    'counts':demand['counts'],'evidence_inputs':inputs,'coverage':coverage,'missing':missing,
    'verdict':'EXACT_REQUIRED_PORT_AND_FAMILY_WITNESS_JOIN_PASS' if not missing else 'UNPROVEN',
    'limits':['Official checkpoint, sidecar, precision/resource, source/current-product equivalence and delivery remain separately audited.','No whole-model weight residency or inference-engine claim.']}
# These sources contain the actual fixed official/sidecar loops and independent
# complete-program oracles inspected in this audit. Join exact registered test
# names in all six platform/entry records; a header identity alone is insufficient.
obligations={}
for relative,prefix in [('tests/compute_models/cpu_c4_model_branch_tests.h','branch'),
                        ('tests/compute_models/d5_cpu_torch_official_tests.h','official')]:
    text=(repo/relative).read_text(encoding='utf-8')
    names=re.findall(r'TEST\(HYLE_[A-Z0-9_]+,\s*([A-Za-z0-9_]+)\)',text)
    assert names,relative
    obligations[prefix]={'source':relative,'source_sha256':hashlib.sha256((repo/relative).read_bytes()).hexdigest(),
        'test_names':names,'proofs':[]}
    for platform in ('windows','linux','mac'):
        for entry in ('direct','graph'):
            suite=('CpuGraphC4Branches' if entry=='graph' else 'CpuC4Branches') if prefix=='branch' else ('CpuGraphTorchOfficial' if entry=='graph' else 'CpuTorchOfficial')
            matches=[]
            for name in names:
                full=suite+'.'+name;item=sets[(platform,entry)].get(full)
                if not item or not item['pass']:missing.append((platform,entry,prefix,full))
                else:matches.append({'testcase':full,**item})
            obligations[prefix]['proofs'].append({'platform':platform,'entry':entry,'passed':matches})
report['official_and_sidecar_obligations']=obligations
life_required=[
 'NativeTorchCpu.ManagedReplayReportsRealAllocationFailureAndReleasesProgram',
 'NativeTorchCpu.LowPrecisionConvolutionHasRealFailureRecoveryAndIndependentSlots',
 'NativeTorchCpu.DuplicateExpertIdsAndFailedInvocationRecovery',
 'NativeTorchCpu.ArtifactAndMlxProgramsHaveIndependentSlotsAndReleaseFailedResources',
 'CpuNativeRetirement.FourteenRedundantKindsDeclineBeforeExecution',
 'CpuNativeRetirement.MatureEdgeMathPreservesOddBytesAndChangedReplay']
life=[]
for platform,arc,member in [
 ('windows','evidence/correctness/cpu-final-f5/windows-correctness.zip','raw/owning-migration-corrected.xml'),
 ('mac','evidence/correctness/cpu-final-f5/portable-owning.zip','mac/owning.xml'),
 ('linux','evidence/correctness/cpu-final-f5/portable-owning.zip','linux/owning.xml')]:
    with zipfile.ZipFile(repo/arc) as z:root=ET.fromstring(z.read(member))
    tests={c.get('classname')+'.'+c.get('name'):c for c in root.findall('.//testcase')}
    passed=[]
    for name in life_required:
        if name not in tests or tests[name].find('failure') is not None or tests[name].find('skipped') is not None:
            missing.append((platform,'owning','lifecycle-or-retirement',name))
        else:passed.append(name)
    life.append({'platform':platform,'receipt':arc+'#'+member,'passed':passed})
report['borrowed_program_lifecycle_and_retirement']=life
report['missing']=missing
report['verdict']='EXACT_REQUIRED_PORT_FAMILY_OFFICIAL_AND_SIDECAR_JOIN_PASS' if not missing else 'UNPROVEN'
(out/'coverage-join.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'verdict':report['verdict'],'missing_count':len(missing),'first_missing':missing[:12],
       'case_counts':{str(k):len(v) for k,v in sets.items()}})
