$ErrorActionPreference = 'Stop'
$cleanupRoots = @(
  'C:\hv\cpu-final-f4-sdk',
  'C:\hv\cpu-final-f4-mixed-cuda',
  'C:\hv\cpu-final-f4-mixed-vulkan'
)
$cleanupRecords = foreach ($target in $cleanupRoots) {
  if (-not (Test-Path -LiteralPath $target)) { continue }
  $resolved = (Resolve-Path -LiteralPath $target).Path
  if (-not $resolved.StartsWith('C:\hv\', [StringComparison]::OrdinalIgnoreCase)) { throw "Unexpected cleanup root: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse root: $resolved" }
  $files = Get-ChildItem -LiteralPath $resolved -File -Recurse
  [pscustomobject]@{ path = $resolved; bytes = [long](($files | Measure-Object Length -Sum).Sum); files = $files.Count; action = 'INVENTORY_ONLY_PENDING_F5_MIXED_ACCEPTANCE' }
}
$cleanupRecords | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath '.scratch/validation/cpu-final-f6/cleanup-inventory.json' -Encoding utf8
$cleanupRecords | Select-Object path, bytes, files, action
