import hashlib,json,subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f6'
out.mkdir(parents=True,exist_ok=True)
items=[
 ('fixed-demand','docs/implementation/tasks/compute/cpu-final-demand-carriers.json'),
 ('joint-model-contract','evidence/correctness/cpu-quant-mtp-c5-required/joint-verdict.md'),
 ('joint-contract-audit','evidence/correctness/cpu-quant-mtp-c5-required/aggregate-audit.json'),
 ('family-witnesses','evidence/correctness/cpu-quant-mtp-c5-required/family-witness-index.json'),
 ('build-precompile','docs/implementation/tasks/compute/cpu-final-f1-build-contract.md'),
 ('platform-carriers','docs/implementation/tasks/compute/cpu-final-f3-platform-carriers.md'),
 ('fixed-best-of','docs/implementation/tasks/compute/cpu-final-f4-best-of.md'),
 ('best-of-original-results','evidence/performance/cpu-final-f4-p1/README.md'),
 ('physical-retirement','docs/implementation/tasks/compute/cpu-final-f5-source-ledger.json'),
 ('retirement-pending-acceptance','docs/implementation/tasks/compute/cpu-final-f5-retirement.md'),
 ('public-cpu-coverage','docs/user/cpu-model-coverage.md'),
 ('current-registry','docs/implementation/module-status.json'),
]
records=[]
for role,name in items:
    path=repo/name
    assert path.is_file(),name
    records.append({'role':role,'path':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
registry=json.loads((repo/'docs/implementation/module-status.json').read_text(encoding='utf-8'))
states={x['module']:{k:x[k] for k in ('state','record','candidate') if k in x}
        for x in registry['modules'] if x['module'] in ('compute','compute_provider_native','compute_route_cpu','graph_route_cpu','compute_provider_ggml','compute_provider_onednn')}
ledger={'purpose':'Read-only F6 audit inputs; not F6 activation or terminal acceptance',
 'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'requirements':[
  {'id':'scope','requirement':'104 fixed GGUF plus official, non-GGUF, MTP/DSpark actual mixed port contracts; no dropped formats/families.'},
  {'id':'three-platform-cpu','requirement':'Windows x86_64, Linux x86_64, MacBook Air ARM64 actual CPU execution; Metal not a CPU substitute.'},
  {'id':'two-entry-points','requirement':'Ordinary Direct and Graph; prepared binding and changed-input replay.'},
  {'id':'model-programs','requirement':'Complete required semantic/state programs at real inner widths/original storage; sharded residency limits explicit.'},
  {'id':'resource-lifetime','requirement':'Precision, state feedback, borrowed weights, OOM, accepted failure, independent slots, close and concurrency.'},
  {'id':'three-deliveries','requirement':'Source, relocated static/shared with real runtime loading, correct dependency versions and offline cache.'},
  {'id':'fixed-rules','requirement':'Qualified conditional complete choices; unknown hardware/software/linkage/thread conditions use mature engineering defaults, no runtime race.'},
  {'id':'precompile-mixed','requirement':'Precompiled selection and CPU-only/mixed envelopes do not silently change required CPU capability; no CPU WIN leak.'},
  {'id':'retirement','requirement':'Redundant self CPU math physically gone; needed exact winner branches/unique demands retained; SIMD/Mem and original borrowed programs preserved.'},
  {'id':'governance','requirement':'Legal owner state history, impact selection, docs/closure checks, immutable evidence and no fresh P1 for unchanged math.'},
  {'id':'cleanup','requirement':'Unified all Compute/Graph LOC and owned temporary artifact cleanup; preserve active producers, required caches, user edits.'},
  {'id':'final-stop','requirement':'All requirements proven, exact CPU final notice, limits, goal complete and stop without GPU/operator expansion.'},
 ],'inputs':records,'current_owner_states':states,
 'pending':['F5 Graph full batch','F5 generic Graph fixture correction','F5 source/static/shared platform and mixed deltas','F5 terminal','F6 requirement-by-requirement final audit'],
 'verdict':'UNPROVEN'}
(out/'audit-inputs.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'requirements':len(ledger['requirements']),'inputs':len(records),'verdict':ledger['verdict'],'owner_states':{k:v['state'] for k,v in states.items()}})
