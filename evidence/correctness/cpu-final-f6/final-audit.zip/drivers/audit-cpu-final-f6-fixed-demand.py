import hashlib,json
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f6'
demand=json.loads((repo/'docs/implementation/tasks/compute/cpu-final-demand-carriers.json').read_text())
coverage=json.loads((out/'coverage-join.json').read_text())
assert not coverage['missing']
hashes=[]
for name,digest in demand['source_sha256'].items():
    observed=hashlib.sha256((repo/name).read_bytes()).hexdigest()
    assert observed==digest,(name,observed,digest)
    hashes.append({'path':name,'fixed_sha256':digest,'current_sha256':observed})
families={family['name']:family for family in demand['families']}
profiles=[]
for profile in demand['profiles']:
    proofs=[]
    for row in coverage['coverage']:
        assert not row['port_groups']['gguf_ports']['missing']
        family=next(x for x in row['families'] if x['family']==profile['semantic_family'])
        assert all(region['proof'] for region in family['regions'])
        proofs.append({'platform':row['platform'],'entry':row['entry'],
            'exact_port_count':len(profile['numeric_contracts']),
            'semantic_regions':[region['region'] for region in family['regions']]})
    profiles.append({k:profile[k] for k in ('id','repository','revision','variant','header_identity_digest','numeric_contracts','parameter_classes','semantic_family')})
    profiles[-1]['proofs']=proofs
    profiles[-1]['status']='EXACT_CPU_LIBRARY_COMPUTATION_WITNESS_COMPLETE'
assert len(profiles)==104
report={'scope':'Current derived CPU computation catalogue; immutable F2 demand retained separately',
    'product_candidate':'64b454fa23404d26bead60d495eda9475c802e32',
    'fixed_demand_hashes':hashes,'counts':demand['counts'],'profiles':profiles,
    'separately_required':demand['separate_required'],
    'official_profile_identities':demand['prior_official_profiles'],
    'new_official_checkpoint_identities':demand['official_new_checkpoints'],
    'local_qwen35':demand['local_qwen35'],
    'proof':'coverage-join.json exact six-platform/entry joins, original inner widths/physical types/precision/state source, and current source-equivalence.json',
    'limitations':['No model loader/tokenizer/sampling/server engine.','Not 104 whole-model resident real-weight inference runs.','Fixed checkpoints/packing/quant-state only, no arbitrary new release inheritance.','Platform delivery, resource and final status gates remain separately authoritative.']}
(out/'current-fixed-demand.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'profiles':len(profiles),'fixed_hashes_match':len(hashes),'changed_fixed_demand':False})
