import json,shlex,subprocess,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f6';flags={'creationflags':subprocess.CREATE_NO_WINDOW}
code=r'''
import json,os,pathlib,shutil,subprocess
records=[]
for root_name in ROOTS:
 root=pathlib.Path(root_name).resolve();assert root.is_dir()
 for name in ('f4-static-relocated','f4-shared-relocated','f4-mixed-static-relocated','f4-mixed-shared-relocated'):
  target=root/name
  if not target.exists():continue
  resolved=target.resolve();assert resolved.parent==root and not target.is_symlink()
  newname=name.replace('f4-','f5-',1);replacement=root/newname
  assert replacement.is_dir() and not replacement.is_symlink(),replacement
  processes=subprocess.check_output(['ps','-eo','pid=,comm=,args='],text=True)
  for row in processes.splitlines():
   fields=row.strip().split(None,2)
   if len(fields)<3 or fields[0]==str(os.getpid()):continue
   if fields[1] in ('cmake','ninja','ctest','cpu_final_delivery') and str(target) in fields[2]:raise RuntimeError('Active retired SDK consumer: '+row)
  files=[p for p in target.rglob('*') if p.is_file() and not p.is_symlink()]
  size=sum(p.stat().st_size for p in files)
  shutil.rmtree(target)
  records.append({'path':str(target),'removed':not target.exists(),'logical_bytes':size,'files':len(files),'replacement':str(replacement),'owner':'F4/F6 superseded verification SDK','root_checked':str(root)})
print(json.dumps(records,indent=2))
'''
tasks=[('mac',['/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8','/Users/kiro/hyle-verify/cpu-final-mixed-e0388fbd']),
       ('linux',['/root/hyle-scratch/active-cpu-z'])]
for platform,roots in tasks:
    # All relevant new receipts and their raw archive hashes were checked in
    # F5 terminal acceptance; verify them again before deleting old SDKs.
    import hashlib
    names=['mac-delivery-receipt.json','mac-apple-mixed-delivery-receipt.json'] if platform=='mac' else ['linux-delivery-receipt.json','linux-cuda-mixed-delivery-receipt.json']
    for name in names:
        receipt=json.loads((repo/'evidence/correctness/cpu-final-f5'/name).read_text())
        archive=repo/'evidence/correctness/cpu-final-f5'/receipt['bundle']
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt['bundle_sha256']
    program=code.replace('ROOTS',repr(roots))
    args=['C:/Windows/System32/OpenSSH/ssh.exe','-o','BatchMode=yes','kiro@172.22.10.198','python3 -c '+shlex.quote(program)] if platform=='mac' else ['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',program]
    r=subprocess.run(args,capture_output=True,timeout=45,**flags)
    (out/('cleanup-'+platform+'.log')).write_bytes(r.stdout+r.stderr)
    r.check_returncode();records=json.loads(r.stdout.decode('utf-8'))
    (out/('cleanup-'+platform+'.json')).write_text(json.dumps(records,indent=2)+'\n')
    print({'platform':platform,'removed_roots':len(records),'logical_bytes':sum(x['logical_bytes'] for x in records)},flush=True)
