import hashlib,json,subprocess,zipfile
from pathlib import Path
repo=Path.cwd();raw=repo/'.scratch/validation/cpu-final-f6';out=repo/'evidence/correctness/cpu-final-f6';out.mkdir(parents=True,exist_ok=True)
f5=repo/'evidence/correctness/cpu-final-f5'
coverage=json.loads((raw/'coverage-join.json').read_text(encoding='utf-8'));assert not coverage['missing']
fixed=json.loads((raw/'current-fixed-demand.json').read_text(encoding='utf-8'));assert len(fixed['profiles'])==104
source=json.loads((raw/'source-equivalence.json').read_text(encoding='utf-8'))
assert all(not group['exact_product_diff'] for group in source['verified_groups'])
receipts=[]
for name in ('terminal-receipt.json','windows-correctness-receipt.json','portable-owning-receipt.json',
             'windows-delivery-receipt.json','mac-delivery-receipt.json','linux-delivery-receipt.json',
             'windows-cuda-mixed-delivery-receipt.json','windows-vulkan-mixed-delivery-receipt.json',
             'mac-apple-mixed-delivery-receipt.json','linux-cuda-mixed-delivery-receipt.json'):
    path=f5/name;item=json.loads(path.read_text(encoding='utf-8'));archive=f5/item['bundle']
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['bundle_sha256'],name
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None,name
    receipts.append({'path':path.relative_to(repo).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                     'archive':archive.relative_to(repo).as_posix(),'archive_sha256':item['bundle_sha256']})
registry=json.loads((repo/'docs/implementation/module-status.json').read_text(encoding='utf-8'))
cpu_modules=['compute','compute_provider_native','compute_provider_ggml','compute_provider_onednn','compute_ggml_runtime','graph_provider_onednn','compute_route_cpu','graph_route_cpu']
states={item['module']:item['state'] for item in registry['modules'] if item['module'] in cpu_modules}
assert len(states)==len(cpu_modules) and all(state=='CLOSED' for state in states.values()),states
cleanup=[]
for platform in ('windows','mac','linux'):
    records=json.loads((raw/('cleanup-'+platform+'.json')).read_text(encoding='utf-8-sig'))
    assert records and all(item['removed'] for item in records)
    cleanup.extend(records)
loc=json.loads((repo/'.scratch/validation/cpu-final-f5/loc-current.json').read_text(encoding='utf-8-sig'))
metric=next(item for item in loc['metrics'] if item['id']=='module');assert loc['self_check']=='pass'
assert metric['code']==60161 and metric['files']==249
p1=json.loads((repo/'evidence/performance/cpu-final-f4-p1/complete-provider-choices.json').read_text(encoding='utf-8'))
assert p1['counts']=={'ENGINEERING_DEFAULT_REQUIRED':377,'COMPLETE_QUALIFIED_CHOICE':43,'SINGLE_CARRIER':33}
requirements=[
 ('scope','PASS','Fixed 104 GGUF plus official/non-GGUF/MTP/DSpark demand and six input hashes unchanged.'),
 ('three-platform-cpu','PASS','Mac ARM64 and Windows/Linux x86_64 actual CPU witnesses, source/private runtime and delivery; Metal not substituted.'),
 ('two-entry-points','PASS','All 559/34/45 port IDs and exact complete semantic/state/official/sidecar names joined in six platform-entry sets.'),
 ('model-programs','PASS','Actual original inner widths, format/precision/state, changed replay and complete branch proofs from inspected source and qualified witnesses; sharded residency limits preserved.'),
 ('resource-lifetime','PASS','Three-platform owning144 and original qualified mature/Graph/runtime evidence prove real OOM, accepted failures, independent slots, alias/index protection, close and source lifetime.'),
 ('three-deliveries','PASS','CPU-only three-platform source/static/shared 43/48 consumers; real loader, offline cached dependency version and Windows DLL neighbour checks.'),
 ('fixed-rules','PASS','43 qualified complete choices, 377 engineering defaults, 33 single carrier; conditional W1 static/CPU2 WIN and unknown-condition mature defaults tested, no hot search/timing.'),
 ('precompile-mixed','PASS','F1 program/precompile/current versions and F4/F5 rule/CPU mixed envelopes; four actual source/static/shared 43/48 sets and no CPU-only WIN leak.'),
 ('retirement','PASS','14 redundant Native kinds physically gone, 20 qualified necessary kinds plus named Copy retained; SIMD/Mem/View and original borrowed programs preserved; strict retired domains explicit.'),
 ('governance','PASS','Legal AUDITED commits and CANDIDATE/CLOSED transitions, actual closure/docs checks, finite impact/source identities and no new P1 after unchanged math.'),
 ('cleanup','PASS','11 owned superseded SDK directories removed after path/process/replacement/archive checks; current producers/cache/sealed P1/models/canonical source retained.'),
 ('final-stop','READY_FOR_FINAL_NOTICE','All required technical work verified; final public record/push/check then mark active CPU goal complete and stop.')]
for name in ('coverage-join.json','source-equivalence.json','current-fixed-demand.json'):
    (out/name).write_bytes((raw/name).read_bytes())
bundle=out/'final-audit.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in raw.iterdir():
        if path.is_file():z.write(path,'raw/'+path.name)
    z.write(repo/'.scratch/validation/cpu-final-f5/loc-current.json','raw/loc-current.json')
    for path in repo.glob('.scratch/*cpu-final-f6*.py'):z.write(path,'drivers/'+path.name)
    for path in repo.glob('.scratch/*cpu-final-f6*.ps1'):z.write(path,'drivers/'+path.name)
report={'scope':'HYLE Compute+Graph CPU final closure of the exact original six-package goal',
    'baseline':'167cb5ff6f9edac8a9aaa77c41e6720bd3c377d2','product_candidate':source['product_candidate'],
    'current_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'requirements':[{'id':i,'verdict':v,'evidence_boundary':b} for i,v,b in requirements],
    'fixed_counts':fixed['counts'],'qualification_sources':receipts,'cpu_module_states':states,
    'best_of':p1['counts'],'loc':{'code':metric['code'],'files':metric['files'],'excludes':'tests/vendor/bench'},
    'cleanup':cleanup,'removed_logical_bytes':sum(x['logical_bytes'] for x in cleanup),
    'unresolved_required_technical_work':[],
    'limits':['Fixed checkpoint/packing/quant-state set; arbitrary new releases/vision are not automatically qualified.',
       'This is base computation/graph execution, not model loading/tokenizer/sampling/server engine or full resident large-model inference.',
       'Unknown hardware/software/thread/linkage domains use mature defaults; conditional WIN is not a universal SOTA claim.',
       'Managed private allocation upper bounds may be unknown; strict policies/capture can reject and graph failure does not roll back completed outputs.',
       'GPU states/mathematical/performance/format qualifications and old BLOCKED records unchanged.'],
    'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()}
(out/'final-receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'technical_requirements_passed':11,'final_notice_pending':True,'missing_port_or_family':len(coverage['missing']),
    'removed_logical_bytes':report['removed_logical_bytes'],'cpu_states':states,'bundle_bytes':bundle.stat().st_size})
