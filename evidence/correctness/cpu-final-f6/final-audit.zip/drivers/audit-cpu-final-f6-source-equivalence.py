import hashlib,json,subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f6';out.mkdir(parents=True,exist_ok=True)
candidate='64b454fa23404d26bead60d495eda9475c802e32'
groups=[{'base':'560eb1d2332bb69ee5148e899b000fae85d80074',
         'scope':['src/compute_provider_ggml','src/compute_provider_onednn','src/compute_ggml_runtime',
            'src/compute_ops','include/hyle','cmake/HyleDependencyLock.json','third_party'],
         'reuse':'F3 current mature codec/math/precision/lifecycle and actual model witness proof; no source/dependency/public API changes.'},
        {'base':'a7ccfc6639483aee4a76403a35fb32d1732441ec',
         'scope':['src/compute_route_cpu','src/graph_route_cpu','src/compute_provider_native/default_rules.cc',
            'src/compute_provider_native/default_rules.h'],
         'reuse':'F4 cold rule/software/hardware/thread matching and mature defaults; no added execution-time search or timing.'}]
for group in groups:
    delta=subprocess.check_output(['git','diff','--name-only',group['base'],candidate,'--',*group['scope']],text=True).splitlines()
    assert not delta,(group['scope'],delta)
    group['exact_product_diff']=delta
    group['trees']={path:{'base':subprocess.check_output(['git','rev-parse',group['base']+':'+path],text=True).strip(),
                          'candidate':subprocess.check_output(['git','rev-parse',candidate+':'+path],text=True).strip()} for path in group['scope']}
report={'product_candidate':candidate,'verified_groups':groups,
    'retirement_difference':'Native 14 kinds and unsupported instances physically deleted; required edge math connected to original ATen. Native owning/ordinary/model/delivery deltas signed separately in F5.',
    'equivalent_gcc_cleanup':json.loads((repo/'.scratch/validation/cpu-final-f5/cleanup-delta.json').read_text()),
    'limits':'Source equality is a reuse prerequisite, not a substitute for newly changed platform/runtime seams or unrun F5 gates.'}
(out/'source-equivalence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'mature_product_reuse_roots':len(groups[0]['scope']),'rule_reuse_roots':len(groups[1]['scope']),'all_equal':True})
