$ErrorActionPreference = 'Stop'
$taskRepo = 'C:\public\project-hyle\hyle'
$retiredRoots = @('C:\hv\cpu-final-f4-sdk', 'C:\hv\cpu-final-f4-mixed-cuda', 'C:\hv\cpu-final-f4-mixed-vulkan')
$replacementRoots = @('C:\hv\cpu-final-f5-sdk', 'C:\hv\cpu-final-f5-mixed-cuda', 'C:\hv\cpu-final-f5-mixed-vulkan')
$evidenceFiles = @('windows-delivery-receipt.json', 'windows-cuda-mixed-delivery-receipt.json', 'windows-vulkan-mixed-delivery-receipt.json')
$liveProcesses = @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine })
$records = @()
for ($index = 0; $index -lt $retiredRoots.Count; $index++) {
  $target = $retiredRoots[$index]
  if (-not (Test-Path -LiteralPath $target)) { continue }
  $resolved = (Resolve-Path -LiteralPath $target).Path
  if ($resolved -ne [IO.Path]::GetFullPath($target) -or -not $resolved.StartsWith('C:\hv\', [StringComparison]::OrdinalIgnoreCase)) { throw "Unexpected resolved cleanup target: $resolved" }
  if ($liveProcesses | Where-Object { $_.CommandLine.IndexOf($resolved, [StringComparison]::OrdinalIgnoreCase) -ge 0 }) { throw "Active process uses retired SDK: $resolved" }
  $items = @(Get-ChildItem -LiteralPath $resolved -Recurse -Force)
  if ((Get-Item -LiteralPath $resolved).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse cleanup root: $resolved" }
  if ($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }) { throw "Nested reparse point in SDK: $resolved" }
  foreach ($shape in @('static-relocated','shared-relocated')) {
    if (-not (Test-Path -LiteralPath (Join-Path $replacementRoots[$index] $shape))) { throw "Missing accepted replacement SDK: $shape" }
  }
  $receiptPath = Join-Path "$taskRepo\evidence\correctness\cpu-final-f5" $evidenceFiles[$index]
  $receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
  $archivePath = Join-Path "$taskRepo\evidence\correctness\cpu-final-f5" $receipt.bundle
  if ((Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.bundle_sha256) { throw "Archive hash mismatch: $archivePath" }
  $files = @($items | Where-Object { -not $_.PSIsContainer })
  $bytes = [long](($files | Measure-Object Length -Sum).Sum)
  Remove-Item -LiteralPath $resolved -Recurse -Force
  $records += [pscustomobject]@{ path=$resolved; removed= -not (Test-Path -LiteralPath $resolved); logical_bytes=$bytes; files=$files.Count; replacement=$replacementRoots[$index]; owner='F4/F6 superseded delivery SDKs'; archive_verified=$archivePath }
}
$records | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$taskRepo\.scratch\validation\cpu-final-f6\cleanup-windows.json" -Encoding utf8
$records | Select-Object path,removed,logical_bytes,files
