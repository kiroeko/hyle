from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';out=base/'common-source-5'
r=json.loads((out/'result.json').read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert r['state']=='TERMINAL_PASS' and r['candidate']==head
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert all(x['exit_code']==0 for x in r['stages'])
tests=[]
for target,expected in zip(r['targets'],[60,6,24]):
 p=out/(target+'.xml');x=E.parse(p).getroot()
 assert int(x.get('tests'))==expected and all(int(x.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
 tests.append(dict(target=target,tests=expected,failures=0,skipped=0,testcases=[t.get('classname')+'.'+t.get('name') for t in x.findall('.//testcase')]))
risks=[]
for target in r['targets'][3:]:
 log=(out/(target+'.log')).read_text();assert log.count('PASS')==9
 risks.append(dict(target=target,scenarios=9,exit_code=0))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[dict(path=name,sha256=sha(root/name)) for name in subprocess.check_output(['git','diff','--name-only','6e754f0d3',head],text=True).splitlines() if (root/name).is_file()]
artifacts=[]
for name in ['hyle_compute_batch.dll','hyle_graph_batch.dll',*[t+'.exe' for t in r['targets']]]:
 p=Path(r['build'])/'bin'/name;assert p.is_file();artifacts.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
dest=root/'evidence/correctness/inference-g06-native-pending-windows-attempt-5';dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.iterdir()):
  if p.is_file():z.write(p,'source5/'+p.name)
 for name in ['run_native_pending_source.py','seal_native_pending_source5.py']:z.write(base/name,'helpers/'+name)
 for item in inputs:z.write(root/item['path'],'source/'+item['path'])
receipt=dict(kind='G06_NATIVE_PENDING_M3_M4_D1_L2_WINDOWS_SOURCE',verdict='PASS_WINDOWS_COMMON_CPU_ONLY',candidate=head,
 total_tests=90,tests=tests,pending_risks=risks,execution=r,inputs=inputs,artifacts=artifacts,raw_zip_sha256=sha(dest/'raw.zip'),
 proven=['Lazy native index export allocation, cached concurrent export, OOM retry and original byte/lifetime tests passed.',
 'Exact block/generation ready admission distinguishes same backing blocks, deduplicates repeated subviews, preserves capacity and original closed permission gate.',
 'Original common/Graph/CPU numerical, full wire mirror, metadata sharing, paged/ragged and pending controls all passed.',
 'Plain and encoded pending receiver original success/hole/foreign/allocation/capacity/closed/old-ticket/budget/abandon journeys each passed.'],
 limits=['Native controller template runtime, actual Apple/Vulkan Direct and CPU+GPU reports/math/retirement have not been qualified by this CPU-only run.',
 'No G06 aggregate closure, runtime lengths/Q1 decode/capture verdict, new CUDA/P1, SDK, sanitizer or header verdict.',
 'Common source4 PASS and setup1/2/3 failures remain separately preserved; reused configure setup costs are not erased. Source5 outer time overlaps all its stages.'])
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=receipt['verdict'],tests=90,pending_scenarios=18,seconds_overlaps=r['outer_elapsed_seconds'],receipt=str(dest/'receipt.json'))))
