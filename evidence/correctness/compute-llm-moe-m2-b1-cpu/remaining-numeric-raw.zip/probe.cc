#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <windows.h>
#include "ggml.h"
#include "ggml-cpu.h"

static void compute(ggml_context *ctx, ggml_tensor *result) {
  auto *graph = ggml_new_graph(ctx);
  ggml_build_forward_expand(graph, result);
  if (ggml_graph_compute_with_ctx(ctx, graph, 1) != GGML_STATUS_SUCCESS)
    std::exit(2);
}
static void scatter_counterexample(ggml_type type, float base_value) {
  auto *ctx = ggml_init({1U << 20, nullptr, false});
  if (!ctx) std::exit(2);
  auto *base = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, 1, 1);
  auto *updates = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, 1, 2);
  auto *indices = ggml_new_tensor_1d(ctx, GGML_TYPE_I32, 2);
  const float data[]{1, -base_value};
  const int ids[]{0, 0};
  std::memcpy(base->data, &base_value, sizeof(base_value));
  std::memcpy(updates->data, data, sizeof(data));
  std::memcpy(indices->data, ids, sizeof(ids));
  // Exactly the proposed get_rows_back-then-base-add composition, using
  // original kernels. All inputs are representable in the declared storage.
  auto *result = ggml_add(ctx, base, ggml_get_rows_back(ctx, updates, indices, base));
  if (type != GGML_TYPE_F32) result = ggml_cast(ctx, result, type);
  compute(ctx, result);
  std::printf("scatter_add type=%s base=%.0f updates=[1,%.0f] required=0 actual=%.9g\n",
              ggml_type_name(type), base_value, -base_value, ggml_get_f32_1d(result, 0));
  ggml_free(ctx);
}
int main() {
  SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
  _set_abort_behavior(0, _WRITE_ABORT_MSG | _CALL_REPORTFAULT);
  auto *ctx = ggml_init({1U << 20, nullptr, false});
  if (!ctx) return 2;
  auto *x = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, 7, 1);
  const float data[]{-std::numeric_limits<float>::infinity(), -100, -90, -20, 0,
                     std::numeric_limits<float>::infinity(), std::numeric_limits<float>::quiet_NaN()};
  std::memcpy(x->data, data, sizeof(data));
  struct Sample { const char *name; ggml_tensor *value; };
  const Sample samples[]{{"exp", ggml_exp(ctx, x)}, {"sigmoid", ggml_sigmoid(ctx, x)},
                        {"silu", ggml_silu(ctx, x)}, {"softplus", ggml_softplus(ctx, x)},
                        {"relu", ggml_relu(ctx, x)}};
  for (const auto &sample : samples) {
    compute(ctx, sample.value);
    std::printf("%s inputs=[-inf,-100,-90,-20,0,inf,nan] outputs=", sample.name);
    for (int i = 0; i < 7; ++i) std::printf(" %.9g", ggml_get_f32_1d(sample.value, i));
    std::putchar('\n');
  }
  auto *input = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, 3, 1);
  auto *mask = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, 3, 1);
  ggml_set_f32(input, 1);
  ggml_set_f32(mask, -std::numeric_limits<float>::infinity());
  auto *probabilities = ggml_soft_max_ext(ctx, input, mask, 1.0F, 0.0F);
  compute(ctx, probabilities);
  std::printf("all_masked_softmax required=[0,0,0] actual=[%.9g,%.9g,%.9g]\n",
              ggml_get_f32_1d(probabilities, 0), ggml_get_f32_1d(probabilities, 1),
              ggml_get_f32_1d(probabilities, 2));
  ggml_free(ctx);
  scatter_counterexample(GGML_TYPE_F32, 16777216);
  scatter_counterexample(GGML_TYPE_F16, 2048);
  scatter_counterexample(GGML_TYPE_BF16, 256);
}
