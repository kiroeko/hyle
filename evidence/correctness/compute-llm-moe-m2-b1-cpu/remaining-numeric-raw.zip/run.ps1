$ErrorActionPreference = 'Stop'
$probeRoot = 'C:\public\project-hyle\hyle\.scratch\validation\m2-b1-cpu\remaining-probe'
$vsRoot = 'C:\Program Files\Microsoft Visual Studio\18\Enterprise'
$ggmlRoot = 'C:\public\tools\hyle-dependencies\v1\sources\ggml-456172ec733a-41b7e10fd424'
$libraryRoot = 'C:\hv\m2b1-cpu\bin'
Import-Module -Name (Join-Path $vsRoot 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $vsRoot -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64' | Out-Null
Push-Location -LiteralPath $probeRoot
try {
  & cl.exe /nologo /std:c++20 /EHsc /MD /O2 /DNDEBUG /DGGML_STATIC ("/I" + (Join-Path $ggmlRoot 'include')) probe.cc /Fe:probe.exe /Fo:probe.obj /link (Join-Path $libraryRoot 'ggml-cpu.lib') (Join-Path $libraryRoot 'ggml-base.lib') (Join-Path $libraryRoot 'ggml.lib') advapi32.lib
  if ($LASTEXITCODE -ne 0) { throw "Probe build failed: $LASTEXITCODE" }
  $crtRoot = Join-Path $env:VCToolsRedistDir 'x64'
  $crtDirectories = @(Get-ChildItem -LiteralPath $crtRoot -Directory -Filter 'Microsoft.VC*.CRT')
  if ($crtDirectories.Count -ne 1) { throw 'Expected exactly one matching VC CRT directory.' }
  foreach ($dll in Get-ChildItem -LiteralPath $crtDirectories[0].FullName -Filter '*.dll' -File) {
    Copy-Item -LiteralPath $dll.FullName -Destination (Join-Path $probeRoot $dll.Name) -Force
  }
  & .\probe.exe
  if ($LASTEXITCODE -ne 0) { throw "Probe returned: $LASTEXITCODE" }
} finally {
  Pop-Location
}
