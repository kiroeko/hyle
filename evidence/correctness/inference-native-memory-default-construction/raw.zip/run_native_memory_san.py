from pathlib import Path
import subprocess,time,json,sys
route,mode=sys.argv[1:];assert route in ('apple','vulkan') and mode in ('asan','ubsan','tsan');folder=Path.cwd()/'.scratch/inference-gaps/g01'
body='''from pathlib import Path
import subprocess,time,json,os,sys
route,mode=sys.argv[1:];base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';root=base/f'foundation-f5-native-host-{route}-{mode}';parent=root/'parent';build=root/'build';out=base/f'g01-native-memory-{route}-{mode}';out.mkdir(exist_ok=True);rows=[]
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
body=(parent/'CMakeLists.txt').read_text()
if 'g01_native_memory' not in body:
 body+='\\nadd_executable(g01_native_memory '+str(source/'tests/compute_batch/native_memory_owner_consumer.cc')+')\\ntarget_compile_features(g01_native_memory PRIVATE cxx_std_23)\\ntarget_link_libraries(g01_native_memory PRIVATE hyle::compute)\\nhyle_apply_sanitizer(g01_native_memory)\\nhyle_stage_runtime(g01_native_memory)\\n'
 if route=='apple':body+='target_compile_definitions(g01_native_memory PRIVATE HYLE_NATIVE_MEMORY_APPLE=1)\\n'
 (parent/'CMakeLists.txt').write_text(body)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH'];env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
def run(name,args):
 log=out/(name+'.log');start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row);(out/'result.json').write_text(json.dumps({'candidate':'a3fa6be8cf22780491e8b383ef1aafb678db1e23','route':route,'mode':mode,'stages':rows},indent=2)+'\\n');print(json.dumps(row),flush=True)
 if r.returncode:print(log.read_text()[-1800:]);raise SystemExit(r.returncode)
run('configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build)])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_native_memory','--parallel','4'])
commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],text=True));flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode];suffix=f'src/compute_route_{route}/{route}_memory.'+('mm' if route=='apple' else 'cc');checked=[]
for name in (suffix,'tests/compute_batch/native_memory_owner_consumer.cc'):
 selected=[r for r in commands if r['file'].endswith(name)];assert selected and all(flag in r['command'] for r in selected),name;checked+=selected
(out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\\n')
exe=build/'g01_native_memory'
if not exe.exists():exe=build/'bin/g01_native_memory'
run('run',[str(exe)])
'''
log=folder/f'native-memory-{route}-{mode}.log';assert not log.exists();start=time.monotonic()
with log.open('w',encoding='utf-8') as f:r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 - '+route+' '+mode],input=body,text=True,stdout=f,stderr=subprocess.STDOUT)
(folder/f'native-memory-{route}-{mode}.json').write_text(json.dumps({'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n');print(log.read_text(encoding='utf-8')[-1500:]);raise SystemExit(r.returncode)
