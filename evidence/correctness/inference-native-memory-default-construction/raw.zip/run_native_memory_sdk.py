from pathlib import Path
import subprocess,time,json,sys
route,mode=sys.argv[1:];assert route in ('apple','vulkan') and mode in ('static','shared');folder=Path.cwd()/'.scratch/inference-gaps/g01'
body='''from pathlib import Path
import subprocess,time,json,os,sys
route,mode=sys.argv[1:];base=Path('/Users/kiro/hyle-scratch/compute-unified');canonical=base/'source-c8874688';producer=base/f'a-{route}/selected-graph/{mode}-sdk-build';out=base/f'g01-native-memory-{route}-{mode}-sdk';out.mkdir(exist_ok=True);source=out/'consumer-source';source.mkdir(exist_ok=True);build=out/'consumer-build';stage=out/'staging';prefix=out/'relocated';rows=[]
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12';assert not prefix.exists()
(source/'main.cc').write_bytes((canonical/'tests/compute_batch/native_memory_owner_consumer.cc').read_bytes())
cmake='cmake_minimum_required(VERSION 3.25)\\nproject(native_memory_sdk LANGUAGES CXX)\\nfind_package(Hyle CONFIG REQUIRED COMPONENTS compute)\\nadd_executable(owner main.cc)\\ntarget_compile_features(owner PRIVATE cxx_std_23)\\ntarget_compile_options(owner PRIVATE -Wall -Wextra -Wpedantic -Werror)\\ntarget_link_libraries(owner PRIVATE hyle::compute)\\n'
if route=='apple':cmake+='target_compile_definitions(owner PRIVATE HYLE_NATIVE_MEMORY_APPLE=1)\\n'
(source/'CMakeLists.txt').write_text(cmake)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def run(name,args):
 log=out/(name+'.log');start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row);(out/'result.json').write_text(json.dumps({'candidate':'a3fa6be8cf22780491e8b383ef1aafb678db1e23','route':route,'mode':mode,'stages':rows},indent=2)+'\\n');print(json.dumps(row),flush=True)
 if r.returncode:print(log.read_text()[-1800:]);raise SystemExit(r.returncode)
run('producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target',f'hyle_compute_route_{route}','--parallel','4'])
run('install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(stage)]);stage.rename(prefix)
run('consumer-configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+str(prefix)])
run('consumer-build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','owner','--parallel','4'])
run('run',[str(build/'owner')])
'''
log=folder/f'native-memory-{route}-{mode}-sdk.log';assert not log.exists();start=time.monotonic()
with log.open('w',encoding='utf-8') as f:r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 - '+route+' '+mode],input=body,text=True,stdout=f,stderr=subprocess.STDOUT)
(folder/f'native-memory-{route}-{mode}-sdk.json').write_text(json.dumps({'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n');print(log.read_text(encoding='utf-8')[-2100:]);raise SystemExit(r.returncode)
