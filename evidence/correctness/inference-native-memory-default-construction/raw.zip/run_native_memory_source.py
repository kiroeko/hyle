from pathlib import Path
import subprocess,time,json,sys
route=sys.argv[1];assert route in ('apple','vulkan');folder=Path.cwd()/'.scratch/inference-gaps/g01'
body='''from pathlib import Path
import subprocess,time,json,os,sys
route=sys.argv[1];base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';build=base/f'a-{route}/selected-graph/static-sdk-build';out=base/f'g01-native-memory-{route}-source';out.mkdir(exist_ok=True)
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
hook=out/'project.cmake';hook.write_text('''+repr('''if(PROJECT_NAME STREQUAL "hyle")
 function(g01_native_memory)
  add_executable(g01_native_memory "{SOURCE}/tests/compute_batch/native_memory_owner_consumer.cc")
  target_compile_features(g01_native_memory PRIVATE cxx_std_23)
  target_compile_options(g01_native_memory PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(g01_native_memory PRIVATE hyle::compute)
  if(HYLE_COMPUTE_APPLE_ENABLED)
   target_compile_definitions(g01_native_memory PRIVATE HYLE_NATIVE_MEMORY_APPLE=1)
  endif()
  hyle_stage_runtime(g01_native_memory)
 endfunction()
 cmake_language(DEFER CALL g01_native_memory)
endif()
''')+'''.replace('{SOURCE}',str(source)))
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH'];rows=[]
for stage,args in [('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)]),('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_native_memory','--parallel','4']),('run',[str(build/'bin/g01_native_memory')])]:
 log=out/(stage+'.log');start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row);(out/'result.json').write_text(json.dumps({'route':route,'candidate':'a3fa6be8cf22780491e8b383ef1aafb678db1e23','stages':rows},indent=2)+'\\n');print(json.dumps(row),flush=True)
 if r.returncode:print(log.read_text()[-1800:]);raise SystemExit(r.returncode)
'''
log=folder/f'native-memory-{route}-source.log';assert not log.exists();start=time.monotonic()
with log.open('w',encoding='utf-8') as f:r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 - '+route],input=body,text=True,stdout=f,stderr=subprocess.STDOUT)
(folder/f'native-memory-{route}-source.json').write_text(json.dumps({'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n');print(log.read_text(encoding='utf-8')[-2100:]);raise SystemExit(r.returncode)
