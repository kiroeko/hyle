from pathlib import Path
import subprocess,json
folder=Path.cwd()/'.scratch/inference-gaps/g01';source=Path('tests/compute_batch/native_memory_owner_consumer.cc');remote='/Users/kiro/hyle-scratch/compute-unified/native-memory-owner-consumer.cc'
subprocess.run(['scp',str(source),'kiro@172.22.10.198:'+remote],check=True)
body='''from pathlib import Path
import subprocess,json
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688'
for route in ('apple','vulkan'):
 build=base/f'a-{route}/selected-graph/static-sdk-build';rows=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],text=True))
 row=next(r for r in rows if r['file'].endswith(f'src/compute_route_{route}/{route}_batch.cc'))
 import shlex
 args=shlex.split(row['command']);at=args.index('-o');del args[at:at+2];at=args.index('-c');args[at+1]=str(base/'native-memory-owner-consumer.cc')
 args+=['-o',str(base/f'native-memory-{route}-red.o')]
 if route=='apple':args+=['-DHYLE_NATIVE_MEMORY_APPLE=1']
 r=subprocess.run(args,cwd=str(build),capture_output=True,text=True);receipt={'route':route,'command':args,'exit_code':r.returncode,'stderr':r.stderr,'stdout':r.stdout};(base/f'native-memory-{route}-red.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps({'route':route,'exit_code':r.returncode,'tail':r.stderr[-1300:]}))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -'],input=body,text=True,capture_output=True);(folder/'native-memory-red.log').write_text(r.stdout+r.stderr,encoding='utf-8');print(r.stdout+r.stderr);raise SystemExit(r.returncode)
