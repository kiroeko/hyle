#include <hyle/graph/batch.h>
#include <hyle/graph/detail/region_access.h>
int main(){hyle::graph::batch::Invocation value;return value.valid();}
