#include <mlx/mlx.h>
#include <thread>
#include <cstdio>
#include <vector>
int main(){
  namespace mx=mlx::core;
  // Match the function-pointer deleter template emitted by instrumented host
  // headers, while linking the unchanged, uninstrumented native MLX archive.
  mx::array seed({1},mx::uint8,nullptr,{});
  seed.set_data(mx::allocator::malloc(1),mx::allocator::free);
  for(int n=0;n<24;++n){
    std::thread worker([n]{
      auto stream=mx::new_stream(mx::Device(mx::Device::gpu,0));
      auto compiled=mx::compile([stream](const std::vector<mx::array>&inputs){
        auto q=mx::reshape(mx::astype(inputs[0],mx::float32,stream),{8,1,64},stream);
        auto k=mx::reshape(mx::take(mx::astype(inputs[1],mx::float32,stream),inputs[3],0,stream),{8,4,64},stream);
        auto v=mx::reshape(mx::take(mx::astype(inputs[2],mx::float32,stream),inputs[3],0,stream),{8,4,64},stream);
        auto scores=mx::matmul(q,mx::transpose(k,{0,2,1},stream),stream);
        auto masked=mx::add(scores,inputs[4],stream);
        auto out=mx::matmul(mx::softmax(masked,-1,true,stream),v,stream);
        return std::vector<mx::array>{mx::astype(mx::reshape(out,{2,4,64},stream),inputs[0].dtype(),stream)};
      },false);
      auto dtype=n%2?mx::bfloat16:mx::float16;
      std::vector<mx::array> inputs{mx::zeros({2,4,64},dtype,stream),mx::zeros({8,64},dtype,stream),mx::zeros({8,64},dtype,stream),mx::zeros({32},mx::int32,stream),mx::zeros({8,1,4},mx::float32,stream)};
      mx::async_eval(inputs);mx::synchronize(stream);for(auto&x:inputs)x.wait();
      auto outputs=compiled(inputs);mx::async_eval(outputs);mx::synchronize(stream);for(auto&x:outputs)x.wait();
      std::printf("no-HYLE MLX cold worker %d complete\n",n);
    });worker.join();
  }
}
