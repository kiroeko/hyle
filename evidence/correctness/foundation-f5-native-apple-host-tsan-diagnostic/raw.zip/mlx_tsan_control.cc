#include <mlx/mlx.h>
#include <thread>
#include <cstdio>
#include <vector>
int main(){
  namespace mx=mlx::core;
  for(int n=0;n<12;++n){
    std::thread worker([n]{
      auto stream=mx::new_stream(mx::Device(mx::Device::gpu,0));
      auto compiled=mx::compile([stream](const std::vector<mx::array>&inputs){
        return std::vector<mx::array>{mx::square(inputs[0],stream)};
      },false);
      std::vector<mx::array> inputs{mx::zeros({2,4,64},n%2?mx::bfloat16:mx::float16,stream)};
      mx::async_eval(inputs);mx::synchronize(stream);for(auto&x:inputs)x.wait();
      auto outputs=compiled(inputs);mx::async_eval(outputs);mx::synchronize(stream);for(auto&x:outputs)x.wait();
      std::printf("no-HYLE MLX cold worker %d complete\n",n);
    });worker.join();
  }
}
