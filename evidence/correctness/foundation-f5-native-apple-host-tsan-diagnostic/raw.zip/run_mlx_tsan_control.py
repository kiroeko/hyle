from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/Users/kiro/hyle-scratch/compute-unified/foundation-f5-native-host-apple-tsan')
source=root/'mlx_tsan_control.cc';build=root/'build'
commands=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','commands','public_native'],text=True)
import shlex
consumer=shlex.split(next(l for l in commands.splitlines() if 'public_batch_native_consumer.cc' in l and ' -c ' in l))
mlx_path=consumer[consumer.index('-isystem',consumer.index('-isystem')+1)+1]
sdk='/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk'
command=['/usr/bin/clang++','-O3','-DNDEBUG','-std=c++23','-arch','arm64','-isysroot',sdk,'-mmacosx-version-min=14.4','-fsanitize=thread','-DMLX_STATIC','-I'+mlx_path,str(source),str(build/'hyle/_deps/mlx-build/libmlx.a'),'-framework','Metal','-framework','Foundation','-framework','QuartzCore','-o',str(root/'mlx-control')]
env=os.environ.copy();env['TSAN_OPTIONS']='halt_on_error=1'
record={'scope':'No HYLE links; same MLX static library, TSan consumer/Clang/Metal cold worker sequence','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'stages':[]}
for name,cmd,budget in [('control-compile',command,120),('control-run',[str(root/'mlx-control')],60)]:
    log=root/(name+'.log');start=time.monotonic()
    with log.open('w') as f:
        p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=budget)
    record['stages'].append({'name':name,'command':cmd,'elapsed':time.monotonic()-start,'exit_code':p.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    (root/'mlx-control.json').write_text(json.dumps(record,indent=2))
    print(name,p.returncode,flush=True)
    if name=='control-compile' and p.returncode:raise SystemExit(p.returncode)
