from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';out=base/'air-attempt-5'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((out/'result.json').read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert r['state']=='TERMINAL_PASS' and r['candidate']==head and len(r['stages'])==31
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert all(s['exit_code']==0 for s in r['stages'])
manifest=json.loads((out/'input-manifest.json').read_bytes());assert manifest['candidate']==head
for item in manifest['inputs']:assert sha(root/item['path'])==item['sha256'],item['path']
for route in ['apple','vulkan']:
 for name in ['g04_plain_native_control','g04_encoded_native_risks']:
  text=(out/(route+'-'+name+'.log')).read_text()
  assert 'cold create all' in text and 'exact backing cap' in text
 assert ('apple_context.cc' if route=='apple' else 'vulkan_program.cc') in (out/(route+'-build.log')).read_text()
prior=[]
for number in range(1,5):
 p=base/('air-attempt-'+str(number));d=json.loads((p/'result.json').read_bytes());assert d['state']=='TERMINAL_FAIL'
 prior.append(dict(attempt=number,candidate=d['candidate'],failed_stages=[dict(route=s['route'],stage=s['stage'],exit_code=s['exit_code']) for s in d['stages'] if s['exit_code']],outer_seconds_overlaps=d['outer_elapsed_seconds']))
cpu=json.loads((root/'evidence/correctness/inference-g06-native-pending-windows-attempt-5/receipt.json').read_bytes())
unchanged=['include/hyle/compute/batch_paged_native.h','include/hyle/compute/detail/paged_arena_access.h',
 'src/compute_batch/batch_execution.cc','src/compute_batch/batch_paged_native.cc','src/compute_batch/paged_arena.cc','src/graph_batch/batch.cc',
 'tests/compute_batch/native_paged_metadata_test.cc','tests/compute_batch/paged_arena_test.cc']
for name in unchanged:assert sha(root/name)==next(x['sha256'] for x in cpu['inputs'] if x['path']==name)
for artifact in cpu['artifacts']:assert sha(Path(artifact['path']))==artifact['sha256']
dest=root/'evidence/correctness/inference-g06-native-pending-air-attempt-5';dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for number in range(1,6):
  folder=base/('air-attempt-'+str(number))
  for p in sorted(folder.iterdir()):
   if p.is_file():z.write(p,'attempt-'+str(number)+'/'+p.name)
 for name in ['native_pending_air.py','launch_native_pending_air.py','seal_native_pending_air5.py']:z.write(base/name,'helpers-final/'+name)
 for name in subprocess.check_output(['git','diff','--name-only','6e754f0d3',head],text=True).splitlines():
  if (root/name).is_file() and name.split('/')[0] in {'include','src','tests'}:z.write(root/name,'source-final/'+name)
record=dict(kind='G06_NATIVE_PENDING_M3_M4_D1_L2_AIR_SOURCE',verdict='PASS_APPLE_VULKAN_NATIVE_AND_CPU_NATIVE_SOURCE',candidate=head,
 identity=r['identity'],execution=r,prior_failures=prior,raw_zip_sha256=sha(dest/'raw.zip'),input_manifest_sha256=sha(out/'input-manifest.json'),
 reused_windows_cpu=dict(receipt='evidence/correctness/inference-g06-native-pending-windows-attempt-5/receipt.json',candidate=cpu['candidate'],tests=90,pending_scenarios=18,unchanged_source_inputs=unchanged,original_artifacts_still_match=True),
 proven=['25 actual native/consumer binary executions, plus six configure/manifest/build stages, passed serially with max4 workers on real M4 GPU/MoltenVK; software-device rejection remains active.',
 'Apple12 and Vulkan6 Direct geometry/causal cases each run64 topology changes with same-layout second replay, exact topology reuse/zero-ID-upload assertions, original numeric tolerances and independent ID-only reordered double oracle; Apple16 long-page variants also passed.',
 'Actual CPU/native/CPU Graph64 episodes and encoded single/multi-request separate/paired producer cases passed on both routes; unchanged tables have zero metadata upload, original CPU and paged fragments and independent numeric gates remain.',
 'Original plain/encoded native allocation census, changed-tail OOM rejection/old prepared generation, no-allocation ID-only native reuse and same-topology prepare exact old-page acquire/publish all passed.',
 'Original native reference, pending Direct64 and two-node pending Graph64, exact guards, unknown/native rejection/cancel/abandon, original outcome/source recovery and multi-producer tests passed.',
 'Vulkan unchanged native plans retain sealed original output/download bridges; real replacement invalidates bridge state per successful node prepare, including partial multi-node preparation.',
 'Device metadata cold zeroing uses two original full-capacity F2 copies with actual retirement. Warm delta publication uses original retired writer and original F1 permissions, never fabricated full-range F2 coverage.'],
 limits=['Finite correctness/P0 source evidence only. Not G06 aggregate completion, four-route runtime length/Q1 planning/capture, relocated static/shared, final headers/sanitizers or new P1 qualification.',
 'No changed CUDA/FI/vendor/profile/tile/threshold run; G04/G05 CUDA prefill non-inferiority and exact residual mechanism contribution remain unresolved.',
 'Controller creation explicitly pays two full-capacity initialization copies/waits; NativePagedBatchReport bytes/waits describe that prepare, not cold creation or host table scans.',
 'Prior attempts1-4 actual failures and their costs remain in raw and prior_failures. Final helper copy identifies attempt5; earlier helper bytes were not separately captured, while actual commands/parents/manifests/results/logs were.',
 'Each outer time overlaps its stages. Runs were serial; packaging/launch/observation gaps without a captured stopwatch remain UNKNOWN rather than zero. GPU/driver private bytes remain under their original UNKNOWN limits.'])
(dest/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=record['verdict'],stages=31,binary_executions=25,outer_seconds_overlaps=r['outer_elapsed_seconds'],prior_failed_attempts=4,receipt=str(dest/'receipt.json'))))
