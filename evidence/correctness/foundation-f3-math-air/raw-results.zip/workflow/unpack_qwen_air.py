from pathlib import Path
import hashlib
import json
import zipfile

base = Path('/Users/kiro/hyle-scratch/compute-unified')
archive = base / 'qwen-air-checked-ranges.zip'
root = base / 'foundation-f3-qwen-input'
assert not root.exists()
root.mkdir()
with zipfile.ZipFile(archive) as packed:
    checked = json.loads(packed.read('checked-input.json'))
    file = root / 'model-ranges.safetensors'
    with file.open('wb') as out:
        out.truncate(checked['file_bytes'])
        out.seek(0); out.write(packed.read('header.bin'))
        for i, row in enumerate(checked['ranges']):
            data = packed.read('range-' + str(i) + '.bin')
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['payload_sha256']
            out.seek(row['file_offset']); out.write(data)
    for name in packed.namelist():
        if name.endswith('.reference.txt') or name in ['ranges.tsv', 'checked-input.json']:
            (root / name).write_bytes(packed.read(name))
with file.open('rb') as source:
    header = source.read(checked['data_base'])
    assert hashlib.sha256(header[8:]).hexdigest() == checked['header_sha256']
    for row in checked['ranges']:
        source.seek(row['file_offset']); data = source.read(row['bytes'])
        assert hashlib.sha256(data).hexdigest() == row['payload_sha256']
record = {'source': str(file), 'capacity': file.stat().st_size,
          'physical_file_bytes': file.stat().st_blocks * 512,
          'whole_model_transferred': False, 'payload_verification': 'Four exact original offset SHA256 plus original header PASS',
          'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(root / 'transfer-verification.json').write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
