from pathlib import Path
import hashlib
import json
import shutil
import zipfile

repo = Path.cwd()
root = repo / '.scratch/foundation-f3'
checked = json.loads((repo / 'evidence/correctness/foundation-f3-qwen-ranges/checked-input.json').read_text())
archive = root / 'qwen-air-checked-ranges.zip'
assert not archive.exists()
with Path(checked['source']).open('rb') as source, zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_STORED) as packed:
    header = source.read(checked['data_base'])
    assert hashlib.sha256(header[8:]).hexdigest() == checked['header_sha256']
    packed.writestr('header.bin', header)
    for i, row in enumerate(checked['ranges']):
        source.seek(row['file_offset']); data = source.read(row['bytes'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['payload_sha256']
        packed.writestr('range-' + str(i) + '.bin', data)
    packed.writestr('checked-input.json', json.dumps(checked, indent=2))
    inputs = root / 'qwen-consumer-input'
    for path in sorted(inputs.glob('*.reference.txt')):
        packed.writestr(path.name, path.read_bytes())
    lines = (inputs / 'ranges.tsv').read_text().splitlines()
    lines[1] = '/Users/kiro/hyle-scratch/compute-unified/foundation-f3-qwen-input/model-ranges.safetensors'
    packed.writestr('ranges.tsv', '\n'.join(lines) + '\n')
receipt = {'source': checked['source'], 'original_capacity': checked['file_bytes'],
           'bounded_transfer_bytes': checked['bounded_bytes_read'], 'whole_model_transfer': False,
           'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'archive_bytes': archive.stat().st_size,
           'scope': 'Verification-only sparse mirror: original header and four exact original offset payloads; all other ranges remain holes and are outside qualification.',
           'payloads': [{key: row[key] for key in ['name', 'file_offset', 'bytes', 'payload_sha256']} for row in checked['ranges']]}
(root / 'qwen-air-input-transfer.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
