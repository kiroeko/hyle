exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
route=os.environ.get('HYLE_F1_MIXED_ROUTE','cuda')
assert route in ('cuda','vulkan')
b=Path('C:/hv/m2b1-cuda' if route=='cuda' else 'C:/hv/m2vk')
out=repo/('.scratch/validation/cpu-final-f1/mixed-'+route+'-delivery')
out.mkdir(parents=True,exist_ok=True);records=[]
consumer=repo/'.scratch/validation/cpu-final-f3/delivery-final/consumer'
overlay=out/'source-overlay.cmake'
overlay.write_text('function(f1_mixed_consumer)\nadd_executable(f1_mixed_40 "'+str((consumer/'main.cc').as_posix())+'")\ntarget_compile_features(f1_mixed_40 PRIVATE cxx_std_23)\ntarget_link_libraries(f1_mixed_40 PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(f1_mixed_40)\nendfunction()\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\ncmake_language(DEFER CALL f1_mixed_consumer)\nendif()\n')
sdk_root=Path('C:/hv/cpu-final-mixed-'+route+'-'+candidate[:8]);sdk_root.mkdir(exist_ok=True)
for shape in ('shared','static'):
    prefix=sdk_root/(shape+'-staging');relocated=sdk_root/(shape+'-relocated')
    assert not prefix.exists() and not relocated.exists(), 'Refuse to replace an existing SDK'
    run(shape+'-configure',['cmake','-S',repo,'-B',b,'-DHYLE_COMPONENTS=compute,graph','-U','HYLE_DEV_FACTORS','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA='+('ON' if route=='cuda' else 'OFF'),'-DHYLE_COMPUTE_VULKAN='+('ON' if route=='vulkan' else 'OFF'),'-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_PROJECT_INCLUDE='+str(overlay),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DHYLE_DEP_SOURCE_CACHE=C:/Users/kiro/AppData/Local/hyle/dependencies/v1'])
    run(shape+'-build',['cmake','--build',b,'--parallel','2'])
    run(shape+'-source-40',[b/'bin/f1_mixed_40.exe'])
    run(shape+'-install',['cmake','--install',b])
    assert prefix.resolve().parent==sdk_root.resolve() and relocated.resolve().parent==sdk_root.resolve()
    prefix.rename(relocated)
    cb=sdk_root/(shape+'-consumer')
    run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-consumer-build',['cmake','--build',cb,'--parallel','2'])
    for name in ('torch_cpu.dll','torch.dll','c10.dll'):assert (cb/name).is_file(),name
    original_path=env['PATH'];env['PATH']=os.environ['SystemRoot']+'/System32;'+os.environ['SystemRoot']
    try:run(shape+'-consumer-40',[cb/'cpu_final_delivery.exe'])
    finally:env['PATH']=original_path
    if shape=='shared':run('shared-export',['python',repo/'scripts/check-shared-export-hygiene.py','--root',relocated])
