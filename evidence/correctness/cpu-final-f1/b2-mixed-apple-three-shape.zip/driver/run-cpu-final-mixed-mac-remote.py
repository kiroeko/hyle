import hashlib,json,os,subprocess,tarfile,time
from pathlib import Path
root=Path(__file__).resolve().parent
identity=json.loads((root/'identity.json').read_text())
archive=root/'source.tar'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==identity['archive_sha256']
source=root/'source'
if not source.exists():
    source.mkdir()
    with tarfile.open(archive) as t:
        for item in t.getmembers():
            assert not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
        t.extractall(source)
out=root/'results';out.mkdir(exist_ok=True)
cache=Path.home()/'Library/Caches/hyle/dependencies/v1'
build=root/'build'
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
env['PATH']=str(Path.home()/'hyle-verify-tools/metal-17F109/shim')+':/opt/homebrew/bin:'+env['PATH']
env['HYLE_D5_QWEN35_FIXTURE']=str(Path.home()/'hyle-verify/cpu-final-42898c37/fixture')
records=[]
def run(name,args):
    start=time.monotonic();log=out/(str(len(records)+1)+'-'+name+'.log')
    with log.open('wb') as stream:r=subprocess.run(list(map(str,args)),env=env,stdout=stream,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=list(map(str,args)),candidate=identity['candidate'],returncode=r.returncode,seconds=round(time.monotonic()-start,3),log=log.name))
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
    if r.returncode:
        print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(r.returncode)
overlay=root/'source-overlay.cmake'
overlay.write_text('function(f1_mixed_consumer)\nadd_executable(f1_mixed_40 "'+str(root/'main.cc')+'")\ntarget_compile_features(f1_mixed_40 PRIVATE cxx_std_23)\ntarget_link_libraries(f1_mixed_40 PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(f1_mixed_40)\nendfunction()\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\ncmake_language(DEFER CALL f1_mixed_consumer)\nendif()\n')
run('identity',['sh','-c','uname -m; sw_vers; /usr/bin/clang++ --version; /opt/homebrew/bin/cmake --version; xcrun -sdk macosx metal --version'])
common=['-DHYLE_COMPONENTS=compute,graph','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=ON','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=AUTO','-DHYLE_COMPUTE_TORCH_CPU=AUTO','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DHYLE_DEP_SOURCE_CACHE='+str(cache),'-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PROJECT_INCLUDE='+str(overlay)]
run('configure',['cmake','-S',source,'-B',build,'-G','Ninja',*common,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_STATIC=OFF'])
run('build',['cmake','--build',build,'--target','hyle_compute_provider_ggml_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','hyle_compute_provider_ggml_metal_tests','hyle_compute_ggml_runtime_tests','hyle_graph_tests','f1_mixed_40','--parallel','2'])
run('cpu-original-formats',['ctest','--test-dir',build,'-L','^compute_provider_ggml$','-LE','headers','--output-on-failure','--no-tests=error','-j','1','--output-junit',out/'cpu-owning.xml'])
for mode,exe in [('direct','hyle_compute_route_cpu_test'),('graph','hyle_graph_route_cpu_test')]:
    run('cpu-'+mode,[build/'bin'/exe,'--gtest_filter=CpuDefaultContext.*:CpuExpandedGgufDirect.*:CpuExpandedGgufGraph.*:CpuArtifactDecode.*','--gtest_output=xml:'+str(out/(mode+'.xml'))])
run('ordinary-cpu-40',[build/'bin/f1_mixed_40'])
run('gpu-original-and-rejection',[build/'bin/hyle_compute_provider_ggml_metal_test','--gtest_filter=GgmlMetalProgram.CpuFormatPortDoesNotQualifyGpuMatrices:GgmlMetalProgram.EveryCatalogFormatRunsPackedMatMulAndReplays:GgmlMetalProgram.PackedIq4XsGroupedExpertsUseNativeMulMatId:GgmlMetalProgram.BfloatRouterLinearRetainsNativeF32Score:GgmlMetalProgram.DeclinesUnqualifiedShapesAndMetadataOomIsRecoverable','--gtest_output=xml:'+str(out/'gpu.xml')])
run('native-program-resource-and-isa',[build/'bin/hyle_compute_ggml_runtime_test','--gtest_filter=GgmlCpuExecution.*','--gtest_output=xml:'+str(out/'runtime.xml')])
run('finite-graph-replay',[build/'bin/hyle_graph_executable_test','--gtest_filter=GraphVariants.*:GraphRules.ModelQualificationIsColdExactAndKeepsTheGenericFallback','--gtest_output=xml:'+str(out/'variants.xml')])
consumer=root/'consumer';consumer.mkdir(exist_ok=True)
(consumer/'main.cc').write_bytes((root/'main.cc').read_bytes())
(consumer/'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.25)\nproject(cpu_final_mixed_delivery LANGUAGES CXX)\nfind_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS compute graph)\nadd_executable(cpu_final_delivery main.cc)\ntarget_compile_features(cpu_final_delivery PRIVATE cxx_std_23)\ntarget_link_libraries(cpu_final_delivery PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(cpu_final_delivery)\n')
for shape in ('shared','static'):
    prefix=root/(shape+'-staging');relocated=root/(shape+'-relocated')
    assert not prefix.exists() and not relocated.exists(), 'Refuse to replace an existing SDK'
    run(shape+'-configure',['cmake','-S',source,'-B',build,*common,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+str(prefix)])
    run(shape+'-build',['cmake','--build',build,'--parallel','2'])
    run(shape+'-source-40',[build/'bin/f1_mixed_40'])
    run(shape+'-install',['cmake','--install',build])
    assert prefix.resolve().parent==root.resolve() and relocated.resolve().parent==root.resolve()
    prefix.rename(relocated)
    cb=root/(shape+'-consumer')
    run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-consumer-build',['cmake','--build',cb,'--parallel','2'])
    run(shape+'-consumer-40',[cb/'cpu_final_delivery'])
    run(shape+'-loader',['otool','-L',cb/'cpu_final_delivery'])
    if shape=='shared':run('shared-export',['python3',source/'scripts/check-shared-export-hygiene.py','--root',relocated])
