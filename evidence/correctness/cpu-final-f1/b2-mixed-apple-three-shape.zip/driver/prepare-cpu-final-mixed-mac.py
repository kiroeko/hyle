import ctypes, hashlib, json, subprocess
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(32771)
flags=dict(creationflags=subprocess.CREATE_NO_WINDOW)
repo=Path(__file__).resolve().parents[1]
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
out=repo/'.scratch/validation/cpu-final-f1/mixed-apple'
out.mkdir(parents=True,exist_ok=True)
archive=out/'source.tar'
subprocess.run(['git','archive','--format=tar','-o',str(archive),candidate],cwd=repo,**flags,check=True)
identity={'candidate':candidate,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'remote_root':'/Users/kiro/hyle-verify/cpu-final-mixed-'+candidate[:8]}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
host='kiro@172.22.10.198'
root=identity['remote_root']
subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-o','BatchMode=yes',host,'mkdir -p '+root],**flags,check=True)
inputs=[archive,out/'identity.json',repo/'.scratch/validation/cpu-final-f3/delivery-final/consumer/main.cc',repo/'.scratch/run-cpu-final-mixed-mac-remote.py']
subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe','-q',*map(str,inputs),host+':'+root+'/'],**flags,check=True)
print(json.dumps(identity),flush=True)
