import ctypes, subprocess
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(32771)
out=Path('.scratch/validation/cpu-final-f1/mixed-apple')
args=['C:/Windows/System32/OpenSSH/ssh.exe','-o','BatchMode=yes','kiro@172.22.10.198','python3 /Users/kiro/hyle-verify/cpu-final-mixed-e0388fbd/run-cpu-final-mixed-mac-remote.py']
with (out/'remote-run.log').open('wb') as log:
    r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print('Mac mixed batch exit',r.returncode,flush=True)
print((out/'remote-run.log').read_text(errors='replace')[-5000:],flush=True)
r.check_returncode()
