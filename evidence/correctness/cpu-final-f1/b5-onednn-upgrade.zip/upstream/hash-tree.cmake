cmake_minimum_required(VERSION 3.25)
include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_compute_expanded_source_tree_sha256("C:/public/project-hyle/hyle/.scratch/validation/cpu-final-f1/onednn-upgrade/source/oneDNN-c531fe1a5cd631b7f60277cdf6675c588cadbc28" digest)
file(WRITE "C:/public/project-hyle/hyle/.scratch/validation/cpu-final-f1/onednn-upgrade/expanded-tree.txt" "${digest}\n")
