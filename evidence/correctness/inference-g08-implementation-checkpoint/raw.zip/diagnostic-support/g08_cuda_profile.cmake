if(PROJECT_NAME STREQUAL "hyle")
  function(g08_cuda_profile)
    set_property(GLOBAL APPEND PROPERTY JOB_POOLS g08_cuda_compile=1)
    foreach(owner IN ITEMS compute_backend_cuda compute_provider_cuda compute_provider_flashinfer compute_provider_torch_cuda)
      set_target_properties(hyle_${owner} PROPERTIES JOB_POOL_COMPILE g08_cuda_compile)
    endforeach()
    # Retain G07's exact flags on its owners; only the two modified/new G08
    # translation units acquire split compile. This is a scratch profile.
    foreach(owner IN ITEMS compute_provider_flashinfer compute_provider_torch_cuda)
      set_target_properties(hyle_${owner} PROPERTIES CUDA_ARCHITECTURES 89-real)
      target_compile_options(hyle_${owner} PRIVATE "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
    endforeach()
    set_source_files_properties(
      "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda/collectives.cu"
      "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda/sampling_kernel.cu"
      DIRECTORY "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda"
      PROPERTIES COMPILE_OPTIONS "--split-compile=3")
    if(TARGET hyle_compute_provider_cuda_sampling_math_test)
      set_target_properties(hyle_compute_provider_cuda_sampling_math_test PROPERTIES
        JOB_POOL_COMPILE g08_cuda_compile CUDA_ARCHITECTURES 89-real)
      target_compile_options(hyle_compute_provider_cuda_sampling_math_test PRIVATE
        "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
    endif()
  endfunction()
  cmake_language(DEFER CALL g08_cuda_profile)
endif()
