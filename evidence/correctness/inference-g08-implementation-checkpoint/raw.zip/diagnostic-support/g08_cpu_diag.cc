#include "/mnt/c/public/project-hyle/hyle/tests/compute_models/sampling_common_consumer.h"
int main(int argc,char **argv) {
  try {
    namespace t=sampling_test;namespace c=hyle::compute;namespace m=hyle::mem;
    if(argc>1&&std::string(argv[1])=="alloc") {
      for(int i=0;i<10000;++i) {
        auto a=t::take(m::Buffer::create(m::system_resource(),884,256));
        auto b=t::take(m::Buffer::create(m::system_resource(),208,256));
        t::require(a.view().fill(std::byte(i%256)));t::require(b.view().fill(std::byte{0xff}));
      }
      std::puts("PASS allocation-only 884+208/alignment256 loop");return 0;
    }
    if(argc>1&&std::string(argv[1])=="prepare") {
      const std::vector<c::TensorDesc> d{t::dense(c::DataType::kFloat32,{13,17}),t::dense(c::DataType::kUInt32,{13,4})};
      t::CommonSession plain(c::sampling_ops::categorical(),d),scored(c::sampling_ops::categorical(true),d);
      plain.close();scored.close();std::puts("PASS prepare/close only; no numeric execution");return 0;
    }
    t::categorical_journey<t::CommonSession>();return 0;
  }
  catch(const std::exception &error) {std::fprintf(stderr,"FAIL %s\n",error.what());return 1;}
}
