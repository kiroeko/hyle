from pathlib import Path
import json,os,shlex,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps'
out=scratch/'g08-cpu-debug-2';out.mkdir(exist_ok=False)
build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
target='hyle_compute_route_cpu_sampling_consumer_test'
obj='tests/compute_route_cpu/CMakeFiles/'+target+'.dir/sampling_consumer.cc.o'
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],text=True).splitlines()
compile=next(x for x in commands if ' -c ' in x and x.endswith('/tests/compute_route_cpu/sampling_consumer.cc'))
args=shlex.split(compile);args=[a for a in args if a not in ['-O3','-DNDEBUG']]
args[args.index('-o')+1]=str(out/'consumer.o');args[args.index('-c')+1]=str(scratch/'g08_cpu_diag.cc')
args.extend(['-O0','-g'])
subprocess.run(args,cwd=build,check=True)
link=next(x for x in reversed(commands) if ' -o bin/'+target+' ' in x)
tokens=shlex.split(link);start=next(i for i,a in enumerate(tokens) if a.endswith('/g++-14'))
end=tokens.index('&&',start) if '&&' in tokens[start:] else len(tokens)
args=tokens[start:end];args[args.index('-o')+1]=str(out/'consumer')
assert obj in args;args[args.index(obj)]=str(out/'consumer.o')
subprocess.run(args,cwd=build,check=True)
for case in ['alloc','prepare','categorical']:
    with (out/(case+'.log')).open('w') as stream:
        code=subprocess.run(['gdb','--batch','-ex','set pagination off','-ex','run','-ex','bt',
            '--args',str(out/'consumer'),case],cwd=build,stdout=stream,stderr=subprocess.STDOUT).returncode
    print(case,(out/(case+'.log')).read_text()[-9000:])
