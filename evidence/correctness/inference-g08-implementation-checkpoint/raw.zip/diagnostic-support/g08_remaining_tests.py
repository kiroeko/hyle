from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g08-source5-remaining-tests';out.mkdir(exist_ok=False)
build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
env=os.environ.copy();env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
r=dict(snapshot='994fc6b006990f12e32dc41b8055a391732e593c',state='RUNNING',tests=[],scope='Remaining independent G08 tests on source5; CPU Direct crash retained separately. No sanitizer/delivery/P1 claim.')
for target in ['hyle_graph_route_cpu_sampling_consumer_test','hyle_compute_route_cuda_sampling_consumer_test',
    'hyle_graph_route_cuda_sampling_consumer_test','hyle_compute_provider_cuda_sampling_math_test',
    'hyle_graph_route_cpu_cuda_sampling_consumer_test']:
    started=time.monotonic();binary=build/'bin'/target
    with (out/(target+'.log')).open('w') as stream:
        code=subprocess.run([str(binary)],env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
    r['tests'].append(dict(target=target,exit_code=code,elapsed_seconds=time.monotonic()-started,
        binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
    print(target,code,flush=True)
r['state']='PASS' if all(x['exit_code']==0 for x in r['tests']) else 'FAIL_WITH_ALL_TARGETS_OBSERVED'
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(r['state'],flush=True)
