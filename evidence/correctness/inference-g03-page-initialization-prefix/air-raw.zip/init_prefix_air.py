from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';out=base/'g03-init-prefix';out.mkdir(exist_ok=True)
archive=out/sys.argv[1]
with zipfile.ZipFile(archive) as z:
 inputs=json.loads(z.read('input-manifest.json'))
 for row in inputs:
  name=row['path'];assert name.startswith(('src/','include/','tests/')) and '..' not in Path(name).parts
  data=z.read(name);assert hashlib.sha256(data).hexdigest()==row['sha256'];(source/name).write_bytes(data)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
def run(mode,stage,args):
 attempt=1+sum(r['mode']==mode and r['stage']==stage for r in rows);log=out/f'{mode}-{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT);print('RUN',mode,stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(mode=mode,stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
 if code:print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
cmake='/opt/homebrew/bin/cmake'
for mode in ['asan','ubsan','tsan']:
 folder=base/f'foundation-f5-native-host-vulkan-{mode}';parent=folder/'parent';build=folder/'build'
 body=(parent/'CMakeLists.txt').read_text()
 if 'add_executable(g03_init_prefix ' not in body:
  body+=f'\nadd_executable(g03_init_prefix "{source}/tests/compute_batch/paged_arena_test.cc")\ntarget_compile_features(g03_init_prefix PRIVATE cxx_std_23)\ntarget_compile_options(g03_init_prefix PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(g03_init_prefix PRIVATE hyle::compute GTest::gtest_main)\nhyle_apply_sanitizer(g03_init_prefix)\nhyle_stage_runtime(g03_init_prefix)\n'
  if mode=='tsan':body+=f'target_include_directories(g03_init_prefix BEFORE PRIVATE "{base}/g02-refcount-fence-probe/tsan-headers")\n'
  (parent/'CMakeLists.txt').write_text(body)
 run(mode,'configure',[cmake,'-S',str(parent),'-B',str(build)])
 run(mode,'build',[cmake,'--build',str(build),'--target','g03_init_prefix','g03_dirty_cpu','--parallel','4'])
 commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
 checked=[r for r in commands if r['file'].endswith(('src/compute_batch/paged_arena.cc','tests/compute_batch/paged_arena_test.cc'))]
 flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode];assert len(checked)==2 and all(flag in r['command'] for r in checked)
 (out/f'{mode}-instrumentation.json').write_text(json.dumps(checked,indent=2)+'\n')
 run(mode,'arena',[str(build/'g03_init_prefix')]);run(mode,'public',[str(build/'g03_dirty_cpu')])
for mode in ['static','shared']:
 producer=base/f'a-cpu-vulkan/selected-graph/{mode}-sdk-build';folder=out/mode;folder.mkdir(exist_ok=True)
 stage=folder/'staging';prefix=folder/'relocated'
 if not prefix.exists():
  run(mode,'producer-build',[cmake,'--build',str(producer),'--target','hyle_compute_batch','--parallel','4'])
  run(mode,'install',[cmake,'--install',str(producer),'--prefix',str(stage)]);stage.rename(prefix)
 assert not stage.exists();assert (prefix/'include/hyle/compute/paged_arena.h').read_bytes()==(source/'include/hyle/compute/paged_arena.h').read_bytes()
 consumer=folder/'consumer';consumer.mkdir(exist_ok=True)
 (consumer/'main.cc').write_bytes((source/'tests/compute_batch/dirty_page_public_consumer.cc').read_bytes())
 (consumer/'native.cc').write_bytes((source/'tests/compute_batch/native_paged_vulkan_consumer.cc').read_bytes())
 for index,name in enumerate(['paged_arena.h','detail/paged_arena_access.h']): (consumer/f'header-{index}.cc').write_text(f'#include <hyle/compute/{name}>\n')
 (consumer/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g03_prefix_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
add_executable(public main.cc)
add_executable(native native.cc)
add_library(headers OBJECT header-0.cc header-1.cc)
foreach(t public native headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${t} PRIVATE hyle::compute hyle::graph)
endforeach()
hyle_stage_runtime(public)
hyle_stage_runtime(native)
''')
 build=folder/'build';run(mode,'configure',[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 run(mode,'consumer-build',[cmake,'--build',str(build),'--target','public','native','headers','--parallel','4'])
 commands=json.loads((build/'compile_commands.json').read_text());assert all(str(source) not in r['command'] and str(prefix/'include') in r['command'] for r in commands)
 run(mode,'public',[str(build/'public')]);run(mode,'native',[str(build/'native')])
