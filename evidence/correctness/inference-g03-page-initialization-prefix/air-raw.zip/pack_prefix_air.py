from pathlib import Path
import hashlib,json,subprocess,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g03-init-prefix';source=base/'source-c8874688'
identity={k:subprocess.check_output(a,text=True).strip() for k,a in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['clang++','--version'])]};assert identity['model']=='Mac16,12'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
artifacts=[]
for mode in ['static','shared']:
 prefix=out/mode/'relocated'
 for p in prefix.rglob('*'):
  if p.is_file() and ('compute_batch' in p.name or p.as_posix().endswith('/include/hyle/compute/paged_arena.h')):
   artifacts.append(dict(mode=mode,path=str(p.relative_to(prefix)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size))
 commands=json.loads((out/mode/'build/compile_commands.json').read_text());assert all(str(source) not in r['command'] and str(prefix/'include') in r['command'] for r in commands)
 (out/(mode+'-compile-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
(out/'artifact-inputs.json').write_text(json.dumps(artifacts,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file() and p.name!='raw.zip':z.write(p,p.name)
 for mode in ['static','shared']:
  for p in (out/mode/'consumer').iterdir():z.write(p,str(p.relative_to(out)))
print('sealed raw',len(artifacts),'artifact identities')
