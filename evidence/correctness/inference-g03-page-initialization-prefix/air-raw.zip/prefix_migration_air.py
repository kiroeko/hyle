from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';out=base/'g03-init-prefix'
with zipfile.ZipFile(out/sys.argv[1]) as z:
 inputs=json.loads(z.read('input-manifest.json'))
 for r in inputs:
  assert r['path'].startswith(('src/','include/','tests/')) and '..' not in Path(r['path']).parts
  data=z.read(r['path']);assert hashlib.sha256(data).hexdigest()==r['sha256'];(source/r['path']).write_bytes(data)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH'];rows=json.loads((out/'migration-result.json').read_text())['stages'] if (out/'migration-result.json').exists() else []
for route in ['apple','vulkan']:
 build=base/f'foundation-f5-native-host-{route}-asan/build'
 commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
 for name in [f'native_paged_{route}_consumer.cc',f'native_paged_{route}_risks.cc','dirty_page_native_consumer.cc','materialized_native_consumer.cc','public_batch_native_consumer.cc','native_paged_joint_consumer.cc','native_paged_joint_risks.cc']+(['copy_update_vulkan_risks.cc'] if route=='vulkan' else []):
  if any(r['route']==route and r['file']==name and r['exit_code']==0 for r in rows):continue
  matching=[r for r in commands if r['file'].endswith('/'+name)];assert matching,(route,name)
  r=matching[0];args=shlex.split(r['command']);clean=[];i=0
  while i<len(args):
   if args[i] in ['-o','-MF','-MT']:i+=2;continue
   if args[i] in ['-MD','-c']:i+=1;continue
   clean.append(args[i]);i+=1
  clean+=['-fsyntax-only'];start=time.monotonic();log=out/f'{route}-{name}-syntax.log'
  with log.open('w') as f:code=subprocess.run(clean,cwd=r['directory'],env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  rows.append(dict(route=route,file=name,command=clean,exit_code=code,elapsed_seconds=time.monotonic()-start))
  (out/'migration-result.json').write_text(json.dumps(dict(inputs=inputs,scope='current dedicated route call sites: C++ syntax only, no native execution claim',stages=rows),indent=2)+'\n')
  print(route,name,code,flush=True)
  if code:print(log.read_text()[-4500:]);raise SystemExit(code)
