from pathlib import Path
import hashlib,json,os,re,struct,subprocess,sys,time,zipfile
BASE=Path('/Users/kiro/hyle-scratch/compute-unified');OUT=BASE/'g04-vulkan-encoded-page-preflight'
attempt=sys.argv[1];RUN=OUT/attempt;RUN.mkdir(exist_ok=False)
SOURCE=BASE/'source-c8874688';CACHE_BUILD=BASE/'a-cpu-vulkan/selected-graph/static-sdk-build'
BUILD=OUT/f'build-{attempt}';assert not BUILD.exists()
identity={k:subprocess.check_output(v,text=True).strip() for k,v in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
cache=(CACHE_BUILD/'CMakeCache.txt').read_text();assert 'HYLE_STATIC:BOOL=ON' in cache and 'HYLE_SANITIZER:STRING=off' in cache
generated=BASE/'g01-native-page-vulkan-preflight/reference-shaders';original=json.loads((generated/'identity.json').read_text())
peer=BASE/'g01-original-ggml-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()==original['revision']=='456172ec733a135778adcd32d00e576a58232e45'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
for name,sha in original['source_blobs_sha256'].items():
 blob=subprocess.check_output(['git','-C',str(peer),'show',original['revision']+':src/ggml-vulkan/vulkan-shaders/'+name]);assert hashlib.sha256(blob).hexdigest()==sha
header=['#pragma once','#include <cstdint>','namespace hyle::bench::resident::spirv {']
for row in original['outputs']:
 raw=(generated/(row['name']+'.spv')).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
 words=struct.unpack('<'+'I'*(len(raw)//4),raw);header+=['inline constexpr std::uint32_t '+row['name']+'[] = {']
 header += [','.join('0x%08xu'%word for word in words[i:i+8])+',' for i in range(0,len(words),8)];header+=['};']
header+=['}'];assert (generated/'reference_spirv.h').read_bytes()==('\n'.join(header)+'\n').encode()
linked=Path(next(line.split('=',1)[1] for line in cache.splitlines()
 if line.startswith('ggml_SOURCE_DIR:STATIC=')))
shader_dir='src/ggml-vulkan/vulkan-shaders/'
todo={'get_rows.comp'};checked={}
while todo:
 name=sorted(todo)[0];todo.remove(name)
 if name in checked:continue
 assert not Path(name).is_absolute() and '..' not in Path(name).parts
 blob=subprocess.check_output(['git','-C',str(peer),'show',original['revision']+':'+shader_dir+name])
 assert (linked/shader_dir/name).read_bytes()==blob,('original GetRows source changed',name)
 checked[name]=hashlib.sha256(blob).hexdigest()
 todo.update(re.findall(r'^\s*#include\s+"([^"]+)"',blob.decode(),re.M))
needle='string_to_spv("get_rows_i32",'
original_gen=subprocess.check_output(['git','-C',str(peer),'show',original['revision']+':'+shader_dir+'vulkan-shaders-gen.cpp'],text=True)
original_define=next(line.strip() for line in original_gen.splitlines() if needle in line)
linked_define=next(line.strip() for line in (linked/shader_dir/'vulkan-shaders-gen.cpp').read_text().splitlines() if needle in line)
assert linked_define==original_define and all('"'+x+'", "uint"' in linked_define for x in ('TEMP_TYPE','A_TYPE','D_TYPE'))
getrows={'linked_ggml_source':str(linked),'source_blobs_sha256':checked,'integer_pipeline_define':linked_define}
(RUN/'original-getrows-identity.json').write_text(json.dumps(getrows,indent=2)+'\n')
inputs=[]
with zipfile.ZipFile(OUT/f'input-{attempt}.zip') as archive:
 product=json.loads(archive.read('product-inputs.json'))
 sdk_identity=json.loads(archive.read('sdk-artifacts.json'))
 for item in product['inputs']:
  assert hashlib.sha256((SOURCE/item['path']).read_bytes()).hexdigest()==item['sha256'],('product source differs',item['path'])
 for name in ('reference.cc','reference.h','vulkan_encoded_page_bench.cc','vulkan_encoded_page_reference.cc','vulkan_encoded_page_reference.h'):
  raw=archive.read(name);(RUN/name).write_bytes(raw);inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()})
sdk=Path(sdk_identity['prefix'])
sdk_rows=sdk_identity['qualified_hyle_artifacts']+sdk_identity['supplemental_native_archives']+sdk_identity['qualified_sdk_recipes']
for item in sdk_rows:assert hashlib.sha256((sdk/item['path']).read_bytes()).hexdigest()==item['sha256'],('SDK artifact changed',item['path'])
for header in (sdk/'include/hyle').rglob('*.h'):
 relative=header.relative_to(sdk/'include')
 if (SOURCE/'include'/relative).is_file():assert header.read_bytes()==(SOURCE/'include'/relative).read_bytes(),('installed header changed',str(relative))
target='g04_vulkan_encoded_page_preflight'
(RUN/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g04_vulkan_encoded_page_preflight LANGUAGES C CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
if(NOT HYLE_STATIC)
 message(FATAL_ERROR "qualified static SDK required")
endif()
add_executable(@TARGET@ "@RUN@/reference.cc" "@RUN@/vulkan_encoded_page_reference.cc" "@RUN@/vulkan_encoded_page_bench.cc" "@SOURCE@/bench/nanobench_impl.cc")
target_compile_features(@TARGET@ PRIVATE cxx_std_23)
target_compile_options(@TARGET@ PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_include_directories(@TARGET@ PRIVATE "@SOURCE@/src/compute_route_vulkan" "@SOURCE@/bench/common" "@GENERATED@")
target_include_directories(@TARGET@ SYSTEM PRIVATE "@SOURCE@/third_party/nanobench")
target_compile_definitions(@TARGET@ PRIVATE HYLE_ENCODED_PAGE_PLACEMENT=0)
target_link_libraries(@TARGET@ PRIVATE hyle::compute)
hyle_stage_runtime(@TARGET@)
'''.replace('@TARGET@',target).replace('@RUN@',str(RUN)).replace('@SOURCE@',str(SOURCE)).replace('@GENERATED@',str(generated)))

env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
record={'state':'RUNNING','scope':'Actual candidate and original Q8 paged multi-request numeric/readonly/two-slot lifecycle preflight only; no A/A or P1 qualification','identity':identity,'inputs':inputs,'product_input_identity':product,'original':original,'original_getrows':getrows,'header_sha256':hashlib.sha256((generated/'reference_spirv.h').read_bytes()).hexdigest(),'stages':[],'cumulative_seconds':0,'max_jobs':4,'sdk_identity':sdk_identity,'sdk_only_build':True}
def save():(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(RUN/'runner.py').write_bytes(Path(__file__).read_bytes());save()
def run(stage,args):
 log=RUN/f'{stage}.log';start=time.monotonic()
 with log.open('w') as handle:
  p=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT);(RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':p.pid}));print(stage,p.pid,flush=True);code=p.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed;record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 record['state']='TERMINAL_FAIL' if code else 'RUNNING';save();print(stage,code,elapsed,flush=True)
 if code:
  (RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));print(log.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(code)
env['HYLE_BENCH_VERIFY_ONLY']='1'
run('configure',['/opt/homebrew/bin/cmake','-S',str(RUN),'-B',str(BUILD),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk)])
# A byte-identical external manifest avoids Ninja -n's unconditional simulation
# of the force-glob/CMake regeneration edge; the real build uses build.ninja.
manifest_copy=RUN/'exact-build.ninja'
manifest_copy.write_bytes((BUILD/'build.ninja').read_bytes())
record['dry_manifest_sha256']=hashlib.sha256(manifest_copy.read_bytes()).hexdigest()
assert manifest_copy.read_bytes()==(BUILD/'build.ninja').read_bytes()
dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-f',str(manifest_copy),'-n',target],env=env,text=True);(RUN/'dry-run.txt').write_text(dry)
assert 'Re-running CMake' not in dry
assert 'Building CXX object src/' not in dry and 'Building C object src/' not in dry and 'Generating' not in dry and 'vulkan-shaders-gen' not in dry,'unexpected product/dependency work in SDK-only preflight'
run('compile',['/opt/homebrew/bin/cmake','--build',str(BUILD),'--target',target,'--parallel','4'])
record['actual_compile_steps']=[line for line in (RUN/'compile.log').read_text().splitlines() if 'Building CXX object ' in line or 'Building C object ' in line]
record['dry_run_limit']='Read-only exact manifest copy after configure; actual compile steps retained. SDK-only project has no product build targets.'
save()
paths=[p/target for p in (BUILD/'bin',BUILD) if (p/target).is_file()];assert len(paths)==1
record['binary']={'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest()}
record['cache_sha256']=hashlib.sha256((BUILD/'CMakeCache.txt').read_bytes()).hexdigest()
save()
run('oracle',[str(paths[0])])
assert hashlib.sha256(paths[0].read_bytes()).hexdigest()==record['binary']['sha256']
assert all(hashlib.sha256((sdk/item['path']).read_bytes()).hexdigest()==item['sha256'] for item in sdk_rows)
lines=(RUN/'oracle.log').read_text().splitlines();assert sum(line.startswith('# ENCODED_PAGE_CORRECTNESS ') and 'replays=4 slots=2 readonly=PASS' in line for line in lines)==6
record['state']='TERMINAL_PASS';save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
