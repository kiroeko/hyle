from pathlib import Path
import hashlib,json,subprocess,sys,time,zipfile
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=sys.argv[1]
assert json.loads((BASE/'post-ce12-validation-job-1.json').read_text(encoding='utf-8'))['state']=='TERMINAL_PASS','CPU P1 and serial CUDA host verification must actually finish'
for job in BASE.glob('cpu-encoded-p1-job-*.json'):
 assert json.loads(job.read_text(encoding='utf-8'))['state']=='TERMINAL','CPU qualification remains active'
OUT=BASE/'vulkan-encoded-page-preflight';OUT.mkdir(exist_ok=True)
archive=OUT/f'input-{attempt}.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ('reference.cc','reference.h','vulkan_encoded_page_bench.cc','vulkan_encoded_page_reference.cc','vulkan_encoded_page_reference.h'):z.write(ROOT/'bench/inference_resident_sdpa'/name,name)
 z.write(ROOT/'bench/inference_resident_sdpa/vulkan_encoded_p1/qualified-sdk-artifacts.json','sdk-artifacts.json')
 paths=subprocess.check_output(['git','ls-files','include/hyle','src/compute','src/compute_batch','src/compute_route_vulkan','src/compute_provider_ggml_vulkan','src/compute_ggml_runtime','src/compute_state'],text=True).splitlines()
 identity={'canonical_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Exact public headers and common/Vulkan product source; CPU provider CE12 not consumed by this GPU-only preflight',
  'inputs':[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in paths]}
 z.writestr('product-inputs.json',json.dumps(identity,indent=2)+'\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g04-vulkan-encoded-page-preflight'
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp',str(archive),str(BASE/'vulkan_encoded_page_preflight_air.py'),host+':'+remote+'/'],check=True)
args=['ssh','-o','BatchMode=yes',host,'python3',remote+'/vulkan_encoded_page_preflight_air.py',attempt]
log=OUT/f'launch-{attempt}.log';start=time.monotonic()
with log.open('wb') as handle:
 p=subprocess.Popen(args,stdout=handle,stderr=subprocess.STDOUT)
 (OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'RUNNING','pid':p.pid,'command':args,'log':str(log)}))
 print('remote preflight',p.pid,flush=True);code=p.wait()
elapsed=time.monotonic()-start
subprocess.run(['scp','-r',host+':'+remote+'/'+attempt,str(OUT)],check=False)
(OUT/f'launch-{attempt}.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code,'elapsed_seconds':elapsed,'command':args,'log':str(log),'remote_stage_record_present':(OUT/attempt/'result.json').is_file()},indent=2)+'\n')
(OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code}))
print(log.read_text(errors='replace')[-4500:],flush=True)
raise SystemExit(code)
