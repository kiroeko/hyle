from pathlib import Path
import ctypes,ctypes.wintypes as wt,hashlib,json,os,subprocess,sys,time

ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.scratch/inference-gaps/g04-g05'
record_file=BASE/'queued-vulkan-encoded-page-preflight-1.json'
assert not record_file.exists(),'do not restart an existing queued job'
dependency_file=BASE/'post-ce12-validation-job-1.json'
dependency=json.loads(dependency_file.read_text(encoding='utf-8'))
paths=['reference.cc','reference.h','vulkan_encoded_page_bench.cc',
 'vulkan_encoded_page_reference.cc','vulkan_encoded_page_reference.h']
inputs={name:hashlib.sha256((ROOT/'bench/inference_resident_sdpa'/name).read_bytes()).hexdigest() for name in paths}
record={'state':'WAITING_FOR_CPU_AND_CUDA_HOST_RISKS','pid':os.getpid(),
 'dependency_pid':dependency['pid'],'dependency_record':str(dependency_file),
 'benchmark_inputs':inputs,'stages':[],'heavy_serial':True,'max_compile_jobs':4}
def save():record_file.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()
def failed(kind,error,traceback):
 record.update(state='TERMINAL_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed
if not dependency['state'].startswith('TERMINAL'):
 kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 kernel.OpenProcess.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD];kernel.OpenProcess.restype=wt.HANDLE
 kernel.WaitForSingleObject.argtypes=[wt.HANDLE,wt.DWORD];kernel.WaitForSingleObject.restype=wt.DWORD
 kernel.CloseHandle.argtypes=[wt.HANDLE]
 handle=kernel.OpenProcess(0x00100000,False,dependency['pid'])
 assert handle,'dependency handle missing; inspect actual state, never restart on observation failure'
 try:
  while True:
   result=kernel.WaitForSingleObject(handle,5000)
   if result==0:break
   assert result==258,('dependency observation failure',result)
 finally:kernel.CloseHandle(handle)
dependency=json.loads(dependency_file.read_text(encoding='utf-8'))
assert dependency['state']=='TERMINAL_PASS',dependency['state']
assert all(hashlib.sha256((ROOT/'bench/inference_resident_sdpa'/name).read_bytes()).hexdigest()==sha
 for name,sha in inputs.items()),'queued benchmark source changed; inspect without starting heavy work'
for label,args in (
 ('preflight',[sys.executable,str(BASE/'launch_vulkan_encoded_page_preflight.py'),'1']),
 ('seal',[sys.executable,str(BASE/'seal_vulkan_encoded_page_preflight.py')])):
 log=BASE/f'queued-vulkan-encoded-page-{label}-1.log';start=time.monotonic()
 with log.open('wb') as stream:
  child=subprocess.Popen(args,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',stage=label,child_pid=child.pid,log=str(log));save()
  print(label,child.pid,flush=True);code=child.wait()
 record['stages'].append({'stage':label,'command':args,'exit_code':code,
  'elapsed_seconds':time.monotonic()-start,'log':str(log)});save()
 print(label,'exit',code,flush=True)
 if code:
  record.update(state='TERMINAL_FAIL');save()
  print(log.read_text(encoding='utf-8',errors='replace')[-4000:],flush=True)
  raise SystemExit(code)
record.update(state='TERMINAL_PASS');save();print('Vulkan numeric page preflight sealed',flush=True)
