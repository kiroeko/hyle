from pathlib import Path
import hashlib,json,re,zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'vulkan-encoded-page-preflight'
attempts=sorted(OUT.glob('launch-*.json'),key=lambda p:int(p.stem.rsplit('-',1)[1]))
assert attempts
runs=[]
for launch_path in attempts:
 attempt=launch_path.stem.rsplit('-',1)[1];folder=OUT/attempt
 launch=json.loads(launch_path.read_text(encoding='utf-8'))
 result=json.loads((folder/'result.json').read_text(encoding='utf-8')) if (folder/'result.json').is_file() else None
 runs.append({'attempt':attempt,'launch':launch,'stage_result':result,
  'unknown_stage_setup_cost':result is None})
last=runs[-1];r=last['stage_result'];assert r and r['state']=='TERMINAL_PASS'
assert last['launch']['exit_code']==0
log=(OUT/last['attempt']/'oracle.log').read_text(encoding='utf-8')
rows=re.findall(r'^# ENCODED_PAGE_CORRECTNESS peer=([01]) replays=4 slots=2 readonly=PASS max_abs_error=([0-9.e+-]+) elements=([0-9]+)$',log,re.M)
assert len(rows)==6 and sum(a=='0' for a,b,c in rows)==3
assert max(float(b) for a,b,c in rows)<=2e-3
dest=ROOT/'evidence/correctness/inference-g04-g05-vulkan-encoded-page-preflight'
dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():package.write(p,p.relative_to(OUT).as_posix())
 for name in ('launch_vulkan_encoded_page_preflight.py','vulkan_encoded_page_preflight_air.py','seal_vulkan_encoded_page_preflight.py','queue_vulkan_encoded_page_preflight.py'):
  package.write(BASE/name,'runners/'+name)
 package.write(BASE/'queue_vulkan_encoded_page_preflight-1.py','runners/queue_vulkan_encoded_page_preflight-1.py')
 package.write(BASE/'queue_vulkan_encoded_page_preflight-2.py','runners/queue_vulkan_encoded_page_preflight-2.py')
 for p in sorted(BASE.glob('queued-vulkan-encoded-page-preflight-*.json')):
  package.write(p,'queue-history/'+p.name)
 for name in ('vulkan-encoded-page-validation-plan.json','vulkan-encoded-page-gather-validation-plan.json'):
  package.write(BASE/name,name)
receipt={'kind':'G04_G05_VULKAN_ENCODED_PAGE_COMPLETE_JOURNEY_PREFLIGHT',
 'verdict':'PASS_NUMERICAL_LIFECYCLE_PREFLIGHT_ONLY','identity':r['identity'],
 'inputs':r['inputs'],'product_input_identity':r['product_input_identity'],
 'original_revision':r['original']['revision'],'original_spirv_header_sha256':r['header_sha256'],
 'original_getrows':r['original_getrows'],
 'binary':r['binary'],'cache_sha256':r['cache_sha256'],
 'sdk_only_build':r.get('sdk_only_build',False),'sdk_identity':r.get('sdk_identity'),
 'original_attempt_1_limit':'Stopped before compile at force-glob dry-plan guard; actual old step PIDs confirmed missing and no worker/native child remained; old state/result bytes preserved',
 'runs':runs,'cumulative_measured_stage_seconds':sum(x['stage_result']['cumulative_seconds'] for x in runs if x['stage_result']),
 'outer_launch_seconds_separate':sum(x['launch']['elapsed_seconds'] for x in runs),
 'shapes':3,'arms':2,'replays_per_shape_per_arm':4,'slots_per_arm':2,
 'max_abs_error':max(float(b) for a,b,c in rows),'readonly_KV':'PASS_BYTE_IDENTICAL',
 'actual_compile_steps':r['actual_compile_steps'],
 'limits':['No A/A/P1/noninferiority/throughput verdict','No capture, producer/growth, G06 or whole G04/G05 qualification',
  'Original scalar non-MMQ Q8 attention; shared existing original GetRows bit-copy wrapper',
  'Both arms charge each prepare/version/F2/exact guards/native object/submit/wait/output return',
  'Peer row-index and mask uploads, normalization, gather, conversions and output copies are charged',
  'Private-pool allocation/retained bytes and hard upper remain UNKNOWN; not CPU CE12 execution proof'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('inputs','product_input_identity','runs','identity')}))
