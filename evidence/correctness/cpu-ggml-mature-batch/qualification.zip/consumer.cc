#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <span>
#include <type_traits>
#include <vector>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/cpu.h"
#include "hyle/simd/dtype.h"
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
template<class T>T take(hyle::Result<T> r){if(!r){std::fprintf(stderr,"%.*s\n",int(r.error().message().size()),r.error().message().data());std::exit(2);}return std::move(*r);}
void require(hyle::Status s){if(!s.ok()){std::fprintf(stderr,"%.*s\n",int(s.message().size()),s.message().data());std::exit(2);}}
template<class T>constexpr c::DataType dtype(){if constexpr(std::is_same_v<T,float>)return c::DataType::kFloat32;else if constexpr(std::is_same_v<T,hyle::simd::float16_t>)return c::DataType::kFloat16;else return c::DataType::kBFloat16;}
template<class T>T constant(int value){
  if constexpr(std::is_same_v<T,float>){return value==-1 ? -std::numeric_limits<float>::infinity() : value==-2 ? std::numeric_limits<float>::quiet_NaN() : float(value);}
  else {constexpr bool half=std::is_same_v<T,hyle::simd::float16_t>;
    const std::uint16_t bits=value==-1 ? (half ? 0xfc00 : 0xff80) : value==-2 ? (half ? 0x7e00 : 0x7fc0) : value==1 ? (half ? 0x3c00 : 0x3f80) : value==2 ? 0x4000 : 0;
    return T::from_bits(bits);
  }
}
template<class T>float decode(T value){
  if constexpr(std::is_same_v<T,float>)return value;
  else if constexpr(std::is_same_v<T,hyle::simd::bfloat16_t>)return std::bit_cast<float>(std::uint32_t(value.bits)<<16);
  else {const auto exponent=(value.bits>>10)&31,fraction=value.bits&1023;
    const float v=exponent==31 ? (fraction ? std::numeric_limits<float>::quiet_NaN() : std::numeric_limits<float>::infinity()) : exponent==0 ? std::ldexp(float(fraction),-24) : std::ldexp(float(1024+fraction),int(exponent)-25);
    return value.bits&0x8000 ? -v : v;
  }
}
m::Buffer buffer(const c::TensorDesc &d){return take(m::Buffer::create(m::system_resource(),take(d.required_bytes()),64));}
template<class T>void check(const m::Buffer &buffer,int seed,bool matmul){
  std::vector<T> values(buffer.size()/sizeof(T));require(buffer.view().read(std::as_writable_bytes(std::span(values))));
  for(std::size_t i=0;i<values.size();++i){const float x=decode(values[i]);
    const float expected=seed<0 ? 0.F : matmul ? float(14*(i/(3*5)+1)) : 2.F;
    if(seed==-2 ? !std::isnan(x) : x!=expected || (expected==0 && std::signbit(x))){std::fprintf(stderr,"wrong dtype=%d seed=%d i=%zu actual=%g expected=%g\n",int(dtype<T>()),seed,i,x,expected);std::exit(3);}
  }
}
template<class T>void run(){
  const auto a=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,4>{2,3,1,7}));
  const auto physical=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,4>{2,1,5,7}));
  const auto b=take(physical.transposed());
  const std::array descriptions{a,b};const auto y=take(c::infer_single_output(c::Operation(c::MatMul{}),descriptions));
  auto input=buffer(a),activation=buffer(a),weights=buffer(b),output=buffer(y);
  std::vector<T> w(70);for(std::size_t i=0;i<w.size();++i)w[i]=constant<T>(int(i/35+1));require(weights.view().write(std::as_bytes(std::span(w))));
  auto context=take(c::cpu::create_context({.native_threads=4}));auto queue=take(context.create_queue());
  auto relu=take(c::prepare(context,c::Unary{c::UnaryKind::kRelu},a));
  auto multiply=take(c::prepare(context,c::Operation(c::MatMul{}),descriptions,std::span(&y,1),m::system_resource()));
  if(relu.provider().id!=c::ggml_cpu::kProviderId || multiply.provider().id!=c::ggml_cpu::kProviderId)std::exit(4);
  auto first=take(relu.create_invocation()),second=take(multiply.create_invocation());
  const auto source=take(c::ConstTensorView::create(a,input.view())),activated=take(c::ConstTensorView::create(a,activation.view()));
  const auto target=take(c::TensorView::create(a,activation.view())),result=take(c::TensorView::create(y,output.view()));
  const std::array operands{activated,take(c::ConstTensorView::create(b,weights.view()))};
  auto builder=take(g::GraphBuilder::create());const auto x=take(builder.input(a)),weight=take(builder.input(b));
  const auto r=take(builder.add(c::Unary{c::UnaryKind::kRelu},x));const auto product=take(builder.add(c::MatMul{},r,weight));require(builder.publish(product));
  auto graph=take(std::move(builder).finish());auto graph_context=take(g::cpu::create_context({.native_threads=4}));auto compiled=take(g::compile(graph,graph_context));
  if(compiled.report.region_count()!=1 || compiled.report.step_count()!=1 || compiled.report.step(0)->provider.id!=c::ggml_cpu::kProviderId || compiled.report.step(0)->node_count!=2)std::exit(5);
  auto graph_queue=take(graph_context.create_queue());auto lane=take(compiled.executable.create_invocation());require(lane.bind(x,source));require(lane.bind(weight,operands[1]));require(lane.bind(product,result));
  const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&graph_queue}};require(lane.prepare_replay(queues));
  for(int seed:{-1,-2,2,-1}){
    const std::vector<T> data(42,constant<T>(seed));require(input.view().write(std::as_bytes(std::span(data))));
    auto done=take(first.submit(queue,source,target));require(done.wait());check<T>(activation,seed,false);
    auto mm=take(second.submit(queue,operands,std::span(&result,1)));require(mm.wait());check<T>(output,seed,true);
    auto whole=take(lane.submit(graph_queue));require(whole.wait());check<T>(output,seed,true);
  }
  require(context.close());require(graph_context.close());std::printf("dtype=%d ordinary Direct and whole ReLU-batched-MatMul region PASS\n",int(dtype<T>()));
}
int main(){run<float>();run<hyle::simd::float16_t>();run<hyle::simd::bfloat16_t>();}
