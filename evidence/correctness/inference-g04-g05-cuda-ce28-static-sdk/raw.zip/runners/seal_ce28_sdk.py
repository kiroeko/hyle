from pathlib import Path
import hashlib,json,subprocess,sys,xml.etree.ElementTree as ET,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';sdk=base/'sdk'
mode,attempt=sys.argv[1:3];assert mode in ('static','shared') and attempt.startswith('ce28-')
candidate='830dd9e01829e3e5850ddff7eaa6355ee7c8fd0d';tag=f'cuda-{mode}-{attempt}'
r=json.loads((sdk/f'result-{tag}.json').read_text())
assert r['state']=='TERMINAL_PASS' and all(s['exit_code']==0 for s in r['stages'])
assert r['native_cuda_reuse']['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
assert Path(r['native_cuda_reuse']['build']).name==mode+'-sdk-build'
tests={}
for name,expected in [('cpu_math',14),('native_math',13),('cpu',3),('native',3)]:
    x=ET.parse(sdk/f'{name}-{tag}.xml').getroot()
    assert int(x.attrib['tests'])==expected and x.attrib['failures']==x.attrib['errors']=='0'
    assert not any(c.find('skipped') is not None or c.attrib.get('status')=='notrun' for c in x.findall('.//testcase'))
    tests[name]=int(x.attrib['tests'])
for row in r['inputs']:
    if row['path'].startswith(('src/','include/','cmake/','third_party/')):
        assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
for item in json.loads((sdk/f'artifacts-{tag}.json').read_text()):
    assert subprocess.check_output(['wsl','-e','sha256sum',item['path']],text=True).split()[0]==item['sha256']
commands=json.loads((sdk/f'consumer-commands-{tag}.json').read_text());assert len(commands)==16
assert all('/source-7a7b4c3b/' not in row['command'] and r['prefix']+'/include' in row['command'] for row in commands)
proof=base/f'ce28-{mode}-native-reuse-{attempt}'
setup=None

dest=root/f'evidence/correctness/inference-g04-g05-cuda-ce28-{mode}-sdk';assert not dest.exists();dest.mkdir()
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(sdk.iterdir()):
        if p.is_file() and tag in p.name and p.suffix!='.zip':z.write(p,'sdk/'+p.name)
    for p in sorted(proof.rglob('*')):
        if p.is_file():z.write(p,'native-reuse/'+p.relative_to(proof).as_posix())
    for name in ['ce28_encoded_sdk.py','launch_ce28_sdk.py','ce28_shipping_native_reuse_wsl.py','ce19_cuda_compile.cmake','seal_ce28_sdk.py']:
        z.write(base/name,'runners/'+name)
    with zipfile.ZipFile(sdk/f'source-{tag}.zip') as package:z.writestr('source-manifest.json',package.read('source-manifest.json'))
receipt=dict(kind='G04_G05_CUDA_CE28_RELOCATED_'+mode.upper()+'_SDK',verdict='PASS_'+mode.upper()+'_SDK_ONLY',
    product_candidate=candidate,tests=tests,independent_public_headers=12,consumer_compile_commands=16,
    stages=r['stages'],measured_seconds=r['cumulative_seconds'],native_reuse=r['native_cuda_reuse'],prefix=r['prefix'],identity=r['identity'],
    original_setup_and_single_object_refresh=setup,
    limits=['Actual relocated Linux installed public consumers; no repository headers, HYLE_TESTING or sanitizers.',
        'Original native source/edge/object/Ninja freshness verified;146 unchanged native objects retained in this run. Earlier CE21 single-object refresh and costs remain in their immutable receipt.',
        'No host facet, P1 or aggregate G04/G05 verdict.'],raw_zip_sha256=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(dest),tests=tests,seconds=r['cumulative_seconds'])))
