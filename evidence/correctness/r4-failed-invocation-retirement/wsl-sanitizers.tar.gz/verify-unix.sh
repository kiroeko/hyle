#!/usr/bin/env bash
set -euo pipefail
slot_root=$1
slot_platform=$2
slot_cmake=$3
slot_old=$4
slot_mode=${5:-ordinary}
export PATH="$(dirname "$slot_cmake"):$PATH"
case "$slot_root" in
 /root/hyle-validation/r4-slot-a116280b|/Users/kiro/hyle-validation/r4-slot-a116280b) ;;
 *) echo 'unexpected validation root'; exit 2 ;;
esac
case "$slot_old" in
 /root/hyle-validation/r3-cpu-20260916|/Users/kiro/hyle-validation/r3-cpu-20260916) ;;
 *) echo 'unexpected reusable build root'; exit 2 ;;
esac
slot_source="$slot_root/source"
slot_build="$slot_old/source-shared"
slot_harness="$slot_old/consumer"
slot_logs="$slot_root/logs/$slot_mode"
mkdir -p "$slot_logs"
cd "$slot_source"
run() {
 local log=$1
 shift
 if ! "$@" >"$slot_logs/$log" 2>&1; then
  tail -n 70 "$slot_logs/$log"
  return 1
 fi
}
cmake_run() { bash scripts/hyle-unix.sh "$slot_cmake" "$@"; }
common=(-G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_WERROR=ON
 -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_ONEDNN=AUTO
 -DHYLE_BUILD_BENCH=OFF -DHYLE_TEST_INSTRUMENTATION=OFF
 "-DHYLE_SOURCE_DIR=$slot_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$slot_source")
consumer_common=(-G Ninja -DCMAKE_BUILD_TYPE=Release)
source_static=OFF
source_shared=ON
linkages=(shared static)
if [ "$slot_platform" != linux ]; then
 common+=(-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4)
 consumer_common+=(-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4)
 source_static=ON
 source_shared=OFF
 linkages=(static shared)
fi
targets=(hyle_compute_test hyle_compute_backend_cpu_test hyle_compute_provider_native_test
 hyle_graph_test hyle_graph_executable_test hyle_compute_route_cpu_test
 hyle_graph_route_cpu_test hyle_graph_route_cpu_cpu_executor_test
 r3_consume_compute r3_consume_graph r3_consume_cpu_executor)
if [ "$slot_platform" = linux ]; then
 targets+=(hyle_compute_provider_onednn_test hyle_compute_provider_onednn_composition_test
 hyle_compute_provider_onednn_graph_test hyle_graph_provider_onednn_test)
fi
slot_regex='^hyle_(compute|compute_backend_cpu|compute_provider_native|graph|compute_route_cpu|graph_route_cpu|compute_provider_onednn|graph_provider_onednn)(_header_self_contained|_composition|_graph|_cpu_executor|_executable)?_test$|^r3_consume_(compute|graph|cpu_executor)$'
if [ "$slot_mode" != ordinary ]; then
 [ "$slot_platform" = linux ]
 case "$slot_mode" in asan|ubsan|tsan) ;; *) exit 2 ;; esac
 source_static=OFF
 source_shared=ON
 # Headers/SDK have no sanitizer runtime journey; execute affected runtime consumers.
 slot_regex='^hyle_(compute|compute_backend_cpu|compute_provider_native|graph|compute_route_cpu|graph_route_cpu|compute_provider_onednn|graph_provider_onednn)(_composition|_graph|_cpu_executor|_executable)?_test$'
fi
slot_sanitizer=off
if [ "$slot_mode" != ordinary ]; then slot_sanitizer=$slot_mode; fi
run configure.log cmake_run -S "$slot_harness" -B "$slot_build" "${common[@]}" \
 "-DHYLE_STATIC=$source_static" "-DBUILD_SHARED_LIBS=$source_shared" \
 -DHYLE_BUILD_TESTS=ON -DHYLE_INSTALL=OFF "-DHYLE_SANITIZER=$slot_sanitizer"
run build.log "$slot_cmake" --build "$slot_build" --parallel 2 --target "${targets[@]}"
command=(ctest --test-dir "$slot_build" --output-on-failure --no-tests=error --timeout 120 -j 1 -R "$slot_regex")
if [ "$slot_mode" = tsan ]; then command=(setarch "$(uname -m)" -R "${command[@]}"); fi
run tests.log "${command[@]}"
cp "$slot_build/Testing/Temporary/LastTest.log" "$slot_logs/source-last-test.log"
cp "$slot_build/CMakeCache.txt" "$slot_logs/source-CMakeCache.txt"
tail -n 18 "$slot_logs/tests.log"
if [ "$slot_mode" != ordinary ]; then exit 0; fi
for linkage in "${linkages[@]}"; do
 slot_stage="$slot_root/sdk-$linkage"
 slot_sdk="$slot_root/sdk-$linkage-relocated"
 test ! -e "$slot_stage"
 test ! -e "$slot_sdk"
 slot_static=OFF
 slot_shared=ON
 if [ "$linkage" = static ]; then slot_static=ON; slot_shared=OFF; fi
 run "$linkage-configure.log" cmake_run -S "$slot_harness" -B "$slot_build" "${common[@]}" \
  "-DHYLE_STATIC=$slot_static" "-DBUILD_SHARED_LIBS=$slot_shared" \
  -DHYLE_BUILD_TESTS=OFF -DHYLE_INSTALL=ON -DHYLE_SANITIZER=off
 run "$linkage-build.log" "$slot_cmake" --build "$slot_build" --parallel 2
 run "$linkage-install.log" "$slot_cmake" --install "$slot_build" --prefix "$slot_stage"
 mv "$slot_stage" "$slot_sdk"
 slot_consumer="$slot_root/consume-$linkage"
 run "$linkage-consumer-configure.log" cmake_run -S "$slot_harness" -B "$slot_consumer" \
  "${consumer_common[@]}" "-DCMAKE_PREFIX_PATH=$slot_sdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$slot_source"
 run "$linkage-consumer-build.log" "$slot_cmake" --build "$slot_consumer" --parallel 2 \
  --target r3_consume_compute r3_consume_graph r3_consume_cpu_executor
 run "$linkage-consumer-tests.log" ctest --test-dir "$slot_consumer" --output-on-failure --no-tests=error \
  --timeout 120 -j 1 -R '^r3_consume_(compute|graph|cpu_executor)$'
 cp "$slot_consumer/Testing/Temporary/LastTest.log" "$slot_logs/$linkage-last-test.log"
 cp "$slot_build/CMakeCache.txt" "$slot_logs/$linkage-CMakeCache.txt"
 tail -n 11 "$slot_logs/$linkage-consumer-tests.log"
done
printf 'Execution-slot %s source/static/shared completed for a116280b\n' "$slot_platform"
