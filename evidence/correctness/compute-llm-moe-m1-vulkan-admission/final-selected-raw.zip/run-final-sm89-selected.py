from pathlib import Path
import ctypes
import importlib.util
import json
import subprocess
import sys
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path.cwd()
logs = root / '.scratch/validation/m1-vulkan-admission'
candidate = '0e5b276ae0894b9fc2cb88452c7ed468c4a8addc'
baseline = '31be591067ea9a1a6773cb640bc138a00cf35c39'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == candidate
assert not subprocess.check_output(['git','status','--porcelain'])
context_path = logs / 'windows-msvc-sm89-context.json'
context = json.loads((logs.parent / 'windows-msvc-context.json').read_text(encoding='utf-8'))
# This additional identity is honored by the explicit, logged seed configure.
# The stock selector still controls all gates and its two ordinary CXX flags.
context['toolchain']['factor_cmake_cache'] = {'CMAKE_CUDA_ARCHITECTURES': '89-real'}
context['toolchain']['factor_cache_scope'] = 'W1-WIN RTX4070 native correctness build only; SDK smoke keeps its declared routes'
context_path.write_bytes((json.dumps(context,indent=2)+'\n').encode())

spec = importlib.util.spec_from_file_location('hyle_validation_select',root/'scripts/validation-select.py')
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
cache = logs / 'final-sm89-selected-receipts'
plan = selector.make_plan(root,baseline,candidate,context=context_path,cache=cache)
assert plan['verdict'] == 'READY', plan.get('reason',plan['verdict'])
selected = [g for g in plan['gates'] if g['status'] == 'SELECTED']
assert len(selected) == 120
assert not any(g['id'] == 'p1' for g in selected)
identity = selector.environment_identity(context_path,native=True)
scratch = Path('C:/hv/s') / selector.digest({'tree':plan['candidate_tree'],'context':identity})[:20]
build = scratch / ('build-'+selector.digest({'tree':plan['candidate_tree'],'context':identity,'factors':plan['selected_factors']})[:20])
replacements = {'{python}':sys.executable,'{root}':str(root),'{build}':str(build),'{scratch}':str(scratch)}
configure = next(g['commands'][0] for g in selected if g['id']=='configure')
argv = []
for token in configure:
    for k,v in replacements.items(): token=token.replace(k,v)
    argv.append(token)
argv.append('-DCMAKE_CUDA_ARCHITECTURES=89-real')
binding = {'candidate':candidate,'tree':plan['candidate_tree'],'context':str(context_path),
           'build':str(build),'scratch':str(scratch),'seed_configure':argv,
           'scope':'same 120 correctness/header/delivery gates; CUDA factor compilation targets the actual SM89 device; no P1 or product change'}
(logs/'final-sm89-binding.json').write_bytes((json.dumps(binding,indent=2)+'\n').encode())
(logs/'final-sm89-plan.json').write_bytes((json.dumps(selector.public_report(plan),indent=2)+'\n').encode())
print(json.dumps(binding,indent=2),flush=True)
if '--plan-only' in sys.argv:
    raise SystemExit(0)

old = json.loads((logs/'final-selected-launch.json').read_text(encoding='utf-8'))
assert old['exit_code'] != 0
assert (logs/'final-selected-interruption.json').is_file()
assert not build.exists(), 'new explicit context must start with a fresh build'
seed_log = logs/'final-sm89-seed-configure.log'
assert not seed_log.exists()
start=time.time()
with seed_log.open('wb') as out:
    result=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT)
binding['seed_exit_code']=result.returncode
binding['seed_seconds']=time.time()-start
(logs/'final-sm89-binding.json').write_bytes((json.dumps(binding,indent=2)+'\n').encode())
assert result.returncode == 0, seed_log.read_text(errors='replace')[-5000:]
assert 'CMAKE_CUDA_ARCHITECTURES:UNINITIALIZED=89-real' in (build/'CMakeCache.txt').read_text(encoding='utf-8') or 'CMAKE_CUDA_ARCHITECTURES:STRING=89-real' in (build/'CMakeCache.txt').read_text(encoding='utf-8')
run=[sys.executable,'scripts/validation-select.py','run','--base',baseline,'--candidate',candidate,
     '--context',str(context_path),'--scratch','C:/hv/s','--cache',str(cache),
     '--output',str(logs/'final-sm89-selected-result.json')]
start=time.time()
print('RUN stock selector with explicit SM89 factor cache; progress final-sm89-selected-run.log',flush=True)
with (logs/'final-sm89-selected-run.log').open('wb') as out:
    result=subprocess.run(run,stdout=out,stderr=subprocess.STDOUT)
(logs/'final-sm89-selected-launch.json').write_bytes((json.dumps({'argv':run,'exit_code':result.returncode,'seconds':time.time()-start},indent=2)+'\n').encode())
print((logs/'final-sm89-selected-run.log').read_text(errors='replace')[-7000:],flush=True)
raise SystemExit(result.returncode)
