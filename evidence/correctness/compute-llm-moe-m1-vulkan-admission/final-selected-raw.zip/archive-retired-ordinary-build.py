from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
logs = root / '.scratch/validation/m1-vulkan-admission'
target = Path('C:/hv/selected/dd6ba9eea2aa2417e511')
build = target / 'build-605ef2324f17e5ef3df1'
candidate = '0e5b276ae0894b9fc2cb88452c7ed468c4a8addc'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'])
proof = root / 'evidence/correctness/compute-llm-moe-m1-vulkan-admission/iree-ordinary-checkpoint-raw.zip'
proof_sha = 'baac74839e82c2a2212de2d8892180f14d01f723efc68f0e2c5ba6ea1dd16741'
assert hashlib.sha256(proof.read_bytes()).hexdigest() == proof_sha
with zipfile.ZipFile(proof) as z:
    assert z.testzip() is None
prereq = logs / 'final-prerequisites-raw.zip'
assert hashlib.sha256(prereq.read_bytes()).hexdigest() == '4f330ff2d64739e91c4a1cba35eb74e117c2a9112c033408462aca5f4ee333e9'
with zipfile.ZipFile(prereq) as z:
    assert z.testzip() is None
cache = (build / 'CMakeCache.txt').read_text(encoding='utf-8')
assert 'CMAKE_HOME_DIRECTORY:INTERNAL=C:/public/project-hyle/hyle' in cache
assert 'HYLE_COMPUTE_CUDA:STRING=OFF' in cache
assert 'HYLE_DEV_FACTORS:STRING=compute_ops;compute_provider_ggml_vulkan;compute_provider_iree_vulkan;compute_route_vulkan;graph_route_vulkan' in cache
archive = logs / 'retired-ordinary-windows-build.zip'
assert not archive.exists()
items = [target / 'native-context.cmake']
items += [build / name for name in ['CMakeCache.txt', 'compile_commands.json', 'build.ninja', '.ninja_log', 'Testing/Temporary/LastTest.log', 'Testing/Temporary/LastTestsFailed.log']]
inventory = []
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for p in items:
        if not p.is_file():
            continue
        assert not p.is_symlink()
        data = p.read_bytes()
        name = p.relative_to(target).as_posix()
        z.writestr(name, data)
        inventory.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    z.writestr('inventory.json', json.dumps(inventory, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
record = {'target': str(target), 'candidate': candidate, 'retained_product_evidence': str(proof.relative_to(root)),
          'product_evidence_sha256': proof_sha, 'latest_visibility_evidence': prereq.name,
          'archive': {'path': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'bytes': archive.stat().st_size, 'files': len(inventory)}}
(logs / 'retired-ordinary-windows-archive.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record, indent=2))
