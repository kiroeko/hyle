$ErrorActionPreference = 'Stop'
$m1vLogs = 'C:\public\project-hyle\hyle\.scratch\validation\m1-vulkan-admission'
$m1vTarget = [IO.Path]::GetFullPath('C:\hv\selected\dd6ba9eea2aa2417e511')
if ($m1vTarget -ne 'C:\hv\selected\dd6ba9eea2aa2417e511') { throw 'Unexpected cleanup target' }
foreach ($m1vAncestor in @('C:\hv', 'C:\hv\selected', $m1vTarget)) {
  if ((Get-Item -LiteralPath $m1vAncestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Cleanup ancestor is a link' }
}
if ((Get-Content -LiteralPath 'C:\hv\m1v-owner.txt' -Raw).Trim() -ne 'M1-V qualification only; canonical product: C:\public\project-hyle\hyle') { throw 'Task ownership mismatch' }
$m1vProof = Get-Content -LiteralPath (Join-Path $m1vLogs 'retired-ordinary-windows-archive.json') -Raw | ConvertFrom-Json
if ($m1vProof.target -ne $m1vTarget -or $m1vProof.candidate -ne '0e5b276ae0894b9fc2cb88452c7ed468c4a8addc') { throw 'Wrong archived build' }
if ((Get-FileHash -LiteralPath (Join-Path $m1vLogs $m1vProof.archive.path) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $m1vProof.archive.sha256) { throw 'Archive mismatch' }
foreach ($m1vProcess in @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine })) {
  if ($m1vProcess.CommandLine.Replace('\','/').ToLowerInvariant().Contains($m1vTarget.Replace('\','/').ToLowerInvariant())) { throw 'Retired build still has a live process' }
}
$m1vQueue = [Collections.Generic.Queue[string]]::new()
$m1vFiles = [Collections.Generic.List[object]]::new()
$m1vQueue.Enqueue($m1vTarget)
$m1vBytes = [int64]0
while ($m1vQueue.Count -gt 0) {
  $m1vDirectory = $m1vQueue.Dequeue()
  foreach ($m1vChild in @(Get-ChildItem -LiteralPath $m1vDirectory -Force)) {
    if (-not ([IO.Path]::GetFullPath($m1vChild.FullName)).StartsWith($m1vTarget + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Child escaped owned root' }
    if ($m1vChild.Attributes -band [IO.FileAttributes]::ReparsePoint) {
      if ($m1vChild.PSIsContainer) { throw 'Refuse directory link traversal' }
      $m1vFiles.Add($m1vChild)
    } elseif ($m1vChild.PSIsContainer) {
      $m1vQueue.Enqueue($m1vChild.FullName)
    } else {
      $m1vBytes += $m1vChild.Length
    }
  }
}
foreach ($m1vLink in $m1vFiles) { Remove-Item -LiteralPath $m1vLink.FullName -Force }
Remove-Item -LiteralPath $m1vTarget -Recurse -Force
if (Test-Path -LiteralPath $m1vTarget) { throw 'Cleanup did not finish' }
[pscustomobject]@{target=$m1vTarget;removed_bytes=$m1vBytes;archive_sha256=$m1vProof.archive.sha256;preserved='current SM89 selected validation; canonical product; shared caches; local model; all product evidence'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $m1vLogs 'retired-ordinary-windows-cleanup.json') -Encoding utf8
Write-Output "Removed retired ordinary Vulkan build: $m1vBytes bytes"
