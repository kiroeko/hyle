#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-product
test "$(cat "$task/owner.txt")" = 'M1-V product db770b6fc1e46aa8d8aa86c1102d50acf26eb49f'
test ! -L "$task"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1
prefix=iree-ordinary-air-noncoherent
python3 "$task/$prefix-apply.py"
export GTEST_FILTER=VulkanLifetime.IreeNoncoherentFlagFailurePreservesCallerOutput
for mode in asan; do
  if test "$mode" = asan; then build="$task/iree-host-asan"; else build="$task/native"; fi
  logs="$task/$prefix-$mode-logs"
  mkdir "$logs"
  cmake -S "$task/source" -B "$build" '-DHYLE_DEV_FACTORS=compute_ops;compute_provider_ggml_vulkan;compute_provider_iree_vulkan;compute_route_vulkan;graph_route_vulkan' > "$logs/configure.log" 2>&1
  cmake --build "$build" --parallel 2 --target hyle_compute_route_vulkan_tests > "$logs/build.log" 2>&1
  ctest --test-dir "$build" -R '^hyle_compute_route_vulkan_test$' --output-on-failure --no-tests=error --timeout 180 > "$logs/tests.log" 2>&1
  cp "$build/Testing/Temporary/LastTest.log" "$logs/LastTest.log"
  cat "$logs/tests.log"
done
