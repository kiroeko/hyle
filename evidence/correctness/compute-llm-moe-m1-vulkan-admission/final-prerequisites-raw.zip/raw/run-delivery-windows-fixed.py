from pathlib import Path
import ctypes, hashlib, json, os, subprocess, sys, time
ctypes.windll.kernel32.SetErrorMode(0x8003)
mode=sys.argv[1]
assert mode in ('shared','static','source')
root=Path.cwd().resolve()
base=Path('C:/hv/m1v-delivery').resolve()
assert base.parent==Path('C:/hv').resolve() and not base.is_symlink()
base.mkdir(exist_ok=True)
owner=base/'owner.txt'
identity='M1-V product deliveries 27c6664c9186d89f31468e32de91596a8de3673c'
if owner.exists(): assert owner.read_text()==identity
else: owner.write_text(identity)
logs=root/'.scratch/validation/m1-vulkan-admission'
label='delivery-windows-'+mode+'-c1'
receipt=logs/(label+'.json')
assert not receipt.exists()
candidate='27c6664c9186d89f31468e32de91596a8de3673c'
assert candidate=='27c6664c9186d89f31468e32de91596a8de3673c'
paths=['src','include','cmake','third_party','samples','scripts','CMakeLists.txt']
def unchanged():
    assert not subprocess.check_output(['git','diff',candidate,'--binary','--',*paths])
unchanged()
record={'candidate':candidate,'mode':mode,'status':'RUNNING','commands':[]}
def save(): receipt.write_text(json.dumps(record,indent=2)+'\n')
def run(name,argv):
    unchanged()
    path=logs/(label+'-'+name+'.log')
    assert not path.exists()
    print('RUN',mode,name,flush=True)
    start=time.time()
    with path.open('wb') as output:
        result=subprocess.run([str(x) for x in argv],stdout=output,stderr=subprocess.STDOUT,timeout=3600)
    record['commands'].append({'label':name,'argv':[str(x) for x in argv],'exit_code':result.returncode,'seconds':time.time()-start,'log':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    save();unchanged()
    if result.returncode:
        record['status']='FAIL';save()
        print(path.read_text(errors='replace')[-10000:],flush=True)
        raise RuntimeError(name+' failed')
common=['-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
        '-DCMAKE_TOOLCHAIN_FILE=C:/hv/selected/dd6ba9eea2aa2417e511/native-context.cmake',
        '-DHYLE_COMPONENTS=compute;graph','-UHYLE_DEV_FACTORS',
        '-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF',
        '-DHYLE_SANITIZER=off','-DIREE_ENABLE_ASAN=OFF',
        '-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_ONEDNN=OFF','-DHYLE_COMPUTE_VULKAN=ON',
        '-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1']
save()
if mode=='source':
    parent=base/'source-parent';parent.mkdir(exist_ok=False)
    build=base/'source-build'
    text='cmake_minimum_required(VERSION 3.25)\nproject(m1v_source LANGUAGES CXX)\n'
    text+='add_subdirectory("'+root.as_posix()+'" hyle)\nenable_testing()\n'
    for product in ['compute','graph']:
        text+='add_executable(m1v_'+product+' "'+root.as_posix()+'/samples/package/'+product+'/cpp/main.cc")\n'
        text+='target_link_libraries(m1v_'+product+' PRIVATE hyle::'+product+')\nhyle_stage_runtime_dependencies(m1v_'+product+')\nadd_test(NAME m1v_'+product+' COMMAND m1v_'+product+')\n'
    (parent/'CMakeLists.txt').write_text(text)
    run('configure',['cmake','-S',parent,'-B',build,*common,'-DHYLE_STATIC=ON','-DHYLE_INSTALL=OFF'])
    run('build',['cmake','--build',build,'--parallel','2'])
    run('test',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','--timeout','180'])
else:
    build=Path('C:/hv/selected/dd6ba9eea2aa2417e511/build-605ef2324f17e5ef3df1') if mode=='shared' else base/'static-build'
    stage=base/(mode+'-stage');prefix=base/(mode+'-relocated')
    assert not stage.exists() and not prefix.exists()
    run('configure',['cmake','-S',root,'-B',build,*common,'-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF')])
    run('build',['cmake','--build',build,'--parallel','2'])
    run('install',['cmake','--install',build,'--prefix',stage])
    assert stage.resolve().is_relative_to(base) and prefix.resolve().is_relative_to(base) and not stage.is_symlink()
    stage.rename(prefix)
    if mode=='shared': run('exports',[sys.executable,'scripts/check-shared-export-hygiene.py','--root',prefix])
    for name in ['iree-LICENSE','iree-flatcc-LICENSE','iree-vulkan-headers-LICENSE.md','iree-vulkan-patches-NOTICE.md']:
        assert (prefix/'share/licenses/Hyle'/name).is_file(),name
    for path in (prefix/'lib/cmake').rglob('*.cmake'):
        content=path.read_text(errors='replace').replace('\\','/').lower()
        for forbidden in [root,build,stage]: assert forbidden.as_posix().lower() not in content,(path,forbidden)
    hidden=build.with_name(build.name+'.m1v-hidden')
    assert build.resolve().is_relative_to(Path('C:/hv').resolve()) and hidden.resolve().is_relative_to(Path('C:/hv').resolve())
    assert not build.is_symlink() and not hidden.exists()
    build.rename(hidden)
    try:
        for product in ['compute','graph']:
            consumer=base/(mode+'-'+product)
            run(product+'-configure',['cmake','-S',root/'samples/package'/product/'cpp','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_PREFIX_PATH='+prefix.as_posix(),'-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF','-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
            run(product+'-build',['cmake','--build',consumer,'--parallel','2'])
            run(product+'-test',['ctest','--test-dir',consumer,'--output-on-failure','--no-tests=error','--timeout','180'])
    finally:
        assert not build.exists() and hidden.resolve().is_relative_to(Path('C:/hv').resolve())
        hidden.rename(build)
record['status']='PASS';save()
print('PASS',mode,flush=True)


