from pathlib import Path
import json,subprocess,time
logs=Path('.scratch/validation/m1-vulkan-admission')
shell=logs/'delivery-air.sh'
shell.write_text('''#!/bin/bash
set -euo pipefail
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
cd /Users/kiro/hyle-m1v-product/source
for mode in static shared source; do
  python3 /Users/kiro/hyle-m1v-product/run-delivery-air.py "$mode"
done
''',encoding='utf-8',newline='\n')
host='kiro@172.22.10.198'
remote='/Users/kiro/hyle-m1v-product/'
subprocess.run(['scp',str(shell),host+':'+remote+shell.name],check=True,timeout=60)
launch=logs/'delivery-air-launch.log'
assert not launch.exists()
started=time.time()
with launch.open('wb') as out:
 result=subprocess.run(['ssh','-o','BatchMode=yes',host,'bash '+remote+shell.name],stdout=out,stderr=subprocess.STDOUT,timeout=5400)
record={'product_and_sample_candidate':'27c6664c9186d89f31468e32de91596a8de3673c','exit_code':result.returncode,'seconds':time.time()-started}
(logs/'delivery-air-result.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
subprocess.run(['ssh','-o','BatchMode=yes',host,'cd '+remote+' && tar -czf delivery-air-results.tar.gz delivery/logs delivery-air-forward.json delivery-air-inputs.json'],check=True,timeout=60)
subprocess.run(['scp',host+':'+remote+'delivery-air-results.tar.gz',str(logs)],check=True,timeout=60)
print(launch.read_text(errors='replace')[-12000:])
print(record)
raise SystemExit(result.returncode)
