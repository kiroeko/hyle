#!/bin/bash
set -euo pipefail
profile=$1
archive=$2
if test "$profile" = wsl; then
  task=/root/hyle-m1v-off-0e5b276a
  cache=/root/.cache/hyle/dependencies/v1
  compiler=-DCMAKE_CXX_COMPILER=/usr/bin/g++-14
  sanitizer=ubsan
  export PATH=/usr/bin:/bin:/usr/sbin:/sbin
else
  test "$profile" = mini
  task=/Users/kiro/hyle-m1v-off-0e5b276a
  cache=/Users/kiro/Library/Caches/hyle/dependencies/v1
  compiler=-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4
  sanitizer=off
  export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
fi
test ! -e "$task"
mkdir -p "$task/source" "$task/logs"
printf '%s' 'M1-V OFF 0e5b276ae0894b9fc2cb88452c7ed468c4a8addc' > "$task/owner.txt"
python3 - "$archive" "$task/source" <<'PY'
from pathlib import Path
import hashlib,sys,tarfile
archive=Path(sys.argv[1]);root=Path(sys.argv[2]).resolve()
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='2f09f53c877d55b08364302bc41881d228bf7a529bd923a993aab87c1debbc7c'
with tarfile.open(archive) as t:
    for member in t.getmembers(): assert (root/member.name).resolve().is_relative_to(root)
    t.extractall(root,filter='data')
print('verified OFF source 0e5b276ae0894b9fc2cb88452c7ed468c4a8addc')
PY
export HYLE_DEP_SOURCE_CACHE="$cache" CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
cmake -S "$task/source" -B "$task/build" -G Ninja -DCMAKE_BUILD_TYPE=Release "$compiler" \
 -DHYLE_DEV_FACTORS=compute_ops,compute_provider_iree_vulkan,compute_route_vulkan,graph_route_vulkan \
 -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
 -DHYLE_WERROR=ON -DHYLE_SANITIZER="$sanitizer" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
 -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF \
 -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_ONEDNN=OFF > "$task/logs/configure.log" 2>&1
cmake --build "$task/build" --parallel 2 --target hyle_compute_ops_tests hyle_compute_provider_iree_vulkan_tests \
 hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests > "$task/logs/build.log" 2>&1
ctest --test-dir "$task/build" -L '^(compute_ops|compute_provider_iree_vulkan|compute_route_vulkan|graph_route_vulkan)$' \
 --no-tests=error --output-on-failure --timeout 180 > "$task/logs/tests.log" 2>&1
cp "$task/build/Testing/Temporary/LastTest.log" "$task/logs/LastTest.log"
cp "$task/build/CMakeCache.txt" "$task/logs/CMakeCache.txt"
cp "$task/build/compile_commands.json" "$task/logs/compile_commands.json"
python3 - "$task/build/CMakeCache.txt" <<'PY'
from pathlib import Path
import sys
text=Path(sys.argv[1]).read_text()
assert 'HYLE_COMPUTE_VULKAN:STRING=OFF' in text
assert not any(x.startswith(('FETCHCONTENT_SOURCE_DIR_IREE','Vulkan_LIBRARY:','CUDAToolkit_BIN_DIR:')) for x in text.splitlines())
print('OFF: no IREE source acquisition or Vulkan/CUDA SDK discovery in cache')
PY
cat "$task/logs/tests.log"
