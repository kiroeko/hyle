from pathlib import Path
import hashlib, json, os, subprocess, sys, time
os.environ["DYLD_LIBRARY_PATH"]="/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib"
mode=sys.argv[1]
assert mode in ('shared','static','source')
root=Path('/Users/kiro/hyle-m1v-product/source').resolve()
base=Path('/Users/kiro/hyle-m1v-product/delivery').resolve()
assert base.parent==Path('/Users/kiro/hyle-m1v-product').resolve() and not base.is_symlink()
base.mkdir(exist_ok=True)
owner=base/'owner.txt'
identity='M1-V product deliveries 27c6664c9186d89f31468e32de91596a8de3673c'
if owner.exists(): assert owner.read_text()==identity
else: owner.write_text(identity)
logs=base/'logs';logs.mkdir(exist_ok=True)
label='delivery-air-'+mode+'-c1'
receipt=logs/(label+'.json')
assert not receipt.exists()
candidate='27c6664c9186d89f31468e32de91596a8de3673c'
assert candidate=='27c6664c9186d89f31468e32de91596a8de3673c'
paths=['src','include','cmake','third_party','samples','scripts','CMakeLists.txt']
def unchanged():
    for name,expected in json.loads((base.parent/'delivery-air-inputs.json').read_text()).items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
unchanged()
record={'candidate':candidate,'mode':mode,'status':'RUNNING','commands':[]}
def save(): receipt.write_text(json.dumps(record,indent=2)+'\n')
def run(name,argv):
    unchanged()
    path=logs/(label+'-'+name+'.log')
    assert not path.exists()
    print('RUN',mode,name,flush=True)
    start=time.time()
    with path.open('wb') as output:
        result=subprocess.run([str(x) for x in argv],stdout=output,stderr=subprocess.STDOUT,timeout=3600)
    record['commands'].append({'label':name,'argv':[str(x) for x in argv],'exit_code':result.returncode,'seconds':time.time()-start,'log':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    save();unchanged()
    if result.returncode:
        record['status']='FAIL';save()
        print(path.read_text(errors='replace')[-10000:],flush=True)
        raise RuntimeError(name+' failed')

assert mode=='static'
original=json.loads((logs/'delivery-air-static.json').read_text())
assert original['candidate']==candidate and original['status']=='FAIL'
for command in original['commands']:
    assert hashlib.sha256((logs/command['log']).read_bytes()).hexdigest()==command['sha256']
record['reuse']='SDK configure/build/install and compute consumer configure/build from delivery-air-static.json; same bytes; only loader search environment corrected inside Python'
prefix=base/'static-relocated'
build=base.parent/'native'
hidden=build.with_name(build.name+'.m1v-hidden')
assert build.resolve().is_relative_to(base.parent) and hidden.resolve().is_relative_to(base.parent)
assert not build.is_symlink() and not hidden.exists()
unchanged();build.rename(hidden)
try:
    run('compute-test',['ctest','--test-dir',base/'static-compute','--output-on-failure','--no-tests=error','--timeout','180'])
    consumer=base/'static-graph'
    run('graph-configure',['cmake','-S',root/'samples/package/graph/cpp','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_PREFIX_PATH='+prefix.as_posix(),'-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF','-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run('graph-build',['cmake','--build',consumer,'--parallel','2'])
    run('graph-test',['ctest','--test-dir',consumer,'--output-on-failure','--no-tests=error','--timeout','180'])
finally:
    assert not build.exists() and hidden.resolve().is_relative_to(base.parent)
    hidden.rename(build)
record['status']='PASS';save();print('PASS static c1',flush=True)
