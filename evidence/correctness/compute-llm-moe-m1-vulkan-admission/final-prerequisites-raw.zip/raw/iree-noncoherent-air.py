from pathlib import Path
import hashlib, io, json, subprocess, sys, tarfile, time

label, baseline = sys.argv[1:3]
assert label.replace('-', '').isalnum()
logs = Path('.scratch/validation/m1-vulkan-admission')
prefix = 'iree-ordinary-air-' + label
candidate = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'])
files = subprocess.check_output(['git','diff','--name-only',baseline,candidate], text=True).splitlines()
files = [name for name in files if name.startswith(('src/', 'tests/', 'cmake/', 'include/', 'third_party/'))]
manifest = {'baseline':baseline,'candidate':candidate,'files':[]}
archive = logs / (prefix + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as output:
    for name in files:
        after = subprocess.check_output(['git','show', candidate+':'+name])
        old = subprocess.run(['git','show',baseline+':'+name], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        manifest['files'].append({'path':name, 'before':hashlib.sha256(old.stdout).hexdigest() if old.returncode == 0 else None,
                                  'after':hashlib.sha256(after).hexdigest()})
        info = tarfile.TarInfo(name)
        info.size = len(after)
        output.addfile(info, io.BytesIO(after))
manifest['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
record = logs / (prefix + '.json')
record.write_text(json.dumps(manifest, indent=2)+'\n')
apply = logs / (prefix+'-apply.py')
apply.write_text('''from pathlib import Path
import hashlib,json,tarfile
task=Path('/Users/kiro/hyle-m1v-product')
prefix='''+repr(prefix)+'''
record=json.loads((task/(prefix+'.json')).read_text())
archive=task/(prefix+'.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==record['archive_sha256']
for item in record['files']:
    path=task/'source'/item['path']
    assert path.resolve().is_relative_to((task/'source').resolve()) and not path.is_symlink()
    if item['before'] is None: assert not path.exists(),item['path']
    else: assert hashlib.sha256(path.read_bytes()).hexdigest()==item['before'],item['path']
with tarfile.open(archive) as stream:
    for item in record['files']:
        data=stream.extractfile(item['path']).read()
        assert hashlib.sha256(data).hexdigest()==item['after']
        path=task/'source'/item['path']
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
(task/(prefix+'-applied.json')).write_text(json.dumps(record,indent=2))
print('verified forward candidate',record['candidate'],flush=True)
''', newline='\n')
shell = logs / (prefix+'.sh')
shell.write_text('''#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1v-product
test "$(cat "$task/owner.txt")" = 'M1-V product db770b6fc1e46aa8d8aa86c1102d50acf26eb49f'
test ! -L "$task"
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1
prefix='''+prefix+'''
python3 "$task/$prefix-apply.py"
export GTEST_FILTER=VulkanLifetime.IreeNoncoherentFlagFailurePreservesCallerOutput
for mode in asan; do
  if test "$mode" = asan; then build="$task/iree-host-asan"; else build="$task/native"; fi
  logs="$task/$prefix-$mode-logs"
  mkdir "$logs"
  cmake -S "$task/source" -B "$build" '-DHYLE_DEV_FACTORS=compute_ops;compute_provider_ggml_vulkan;compute_provider_iree_vulkan;compute_route_vulkan;graph_route_vulkan' > "$logs/configure.log" 2>&1
  cmake --build "$build" --parallel 2 --target hyle_compute_route_vulkan_tests > "$logs/build.log" 2>&1
  ctest --test-dir "$build" -R '^hyle_compute_route_vulkan_test$' --output-on-failure --no-tests=error --timeout 180 > "$logs/tests.log" 2>&1
  cp "$build/Testing/Temporary/LastTest.log" "$logs/LastTest.log"
  cat "$logs/tests.log"
done
''', newline='\n')
host = 'kiro@172.22.10.198'
remote = '/Users/kiro/hyle-m1v-product/'
for path in [archive,record,apply,shell]:
    subprocess.run(['scp',str(path),host+':'+remote+path.name], check=True, timeout=60)
started=time.time()
launch=logs/(prefix+'-launch.log')
assert not launch.exists()
with launch.open('wb') as output:
    result = subprocess.run(['ssh','-o','BatchMode=yes',host,'bash '+remote+shell.name], stdout=output,stderr=subprocess.STDOUT, timeout=1800)
receipt={'candidate':candidate,'exit_code':result.returncode,'seconds':time.time()-started,'launch_sha256':hashlib.sha256(launch.read_bytes()).hexdigest()}
(logs/(prefix+'-result.json')).write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['ssh','-o','BatchMode=yes',host,
               'cd '+remote+' && tar -czf '+prefix+'-results.tar.gz '+prefix+'-*-logs '+prefix+'-applied.json'], check=True,timeout=60)
subprocess.run(['scp',host+':'+remote+prefix+'-results.tar.gz',str(logs)],check=True,timeout=60)
print(launch.read_text(errors='replace')[-15000:])
print(receipt)
raise SystemExit(result.returncode)
