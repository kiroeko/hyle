from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');route,mode,label,package=sys.argv[1:5]
assert route in ['apple','vulkan'] and mode in ['asan','ubsan','tsan']
source=base/'source-c8874688';parent=base/f'foundation-f5-native-host-{route}-{mode}/parent';build=parent.parent/'build'
out=base/f'g08-{route}-host-{mode}-{label}';out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0',HYLE_VULKAN_VALIDATION='0')
started=time.monotonic();r=dict(state='SETUP',route=route,mode=mode,pid=os.getpid(),build=str(build),max_jobs=4,stages=[],
    scope='G08 actual Air static host sanitizer facets: modified native adapters, public Direct/Graph/joint, selected Mem/schema and original TopK. No shader/driver/private-pool/leak/SDK/P1 certificate.',
    retained_limits='Original G06 refcount final-acquire and Metal external completion TSan boundary models remain explicit; no new model or broad suppression.')
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd,required=True):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(route,mode,stage,p.pid,flush=True);code=p.wait()
    r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
    if code:
        print(log.read_text(errors='replace')[-7000:],flush=True)
        if required:r['state']='FAIL';save();raise SystemExit(code)
    return code,log.read_text(errors='replace')
try:
    r['identity']={name:subprocess.check_output(cmd,env=env,text=True).strip() for name,cmd in [
        ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
        ('compiler',['xcrun','clang','--version']),('metal',['xcrun','-sdk','macosx','metal','--version'])]}
    assert r['identity']['model']=='Mac16,12' and r['identity']['arch']=='arm64'
    cache=(build/'CMakeCache.txt').read_text();assert f'HYLE_SANITIZER:STRING={mode}' in cache and 'HYLE_STATIC:BOOL=ON' in cache
    assert 'HYLE_COMPUTE_ROUTES:STRING=cpu;'+route in cache
    with zipfile.ZipFile(base/f'g08-input-{package}.zip') as z:
        manifest=json.loads(z.read('input-manifest.json'));r['source_snapshot']=manifest['source_snapshot'];changed=[]
        for item in manifest['inputs']:
            rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
            data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
            p=source/rel
            if not p.exists() or p.read_bytes()!=data:
                p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
        (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
    r['synced_paths']=changed
    cmake=parent/'CMakeLists.txt';body=cmake.read_text();(out/'original-parent.cmake').write_text(body)
    model_dirs=[];r['models']=[]
    if mode=='tsan':
        ref=base/'g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h'
        text=ref.read_text().replace('#include <sanitizer/tsan_interface.h>\n','').replace('    __tsan_acquire(const_cast<std::atomic<std::uint32_t>*>(&value_));\n','')
        assert text.count('  void acquire_before_destroy() const noexcept {')==1 and text.count('      refcount_.acquire_before_destroy();')==2
        text=text.replace('  void acquire_before_destroy() const noexcept {','  static void acquire_before_destroy() noexcept {').replace('      refcount_.acquire_before_destroy();','      decltype(refcount_)::acquire_before_destroy();')
        assert text==(source/'include/hyle/util/ref_counted.h').read_text()
        assert hashlib.sha256(ref.read_bytes()).hexdigest()=='2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
        model_dirs.append(ref.parents[2]);r['models'].append(dict(path=str(ref),sha256=hashlib.sha256(ref.read_bytes()).hexdigest()))
        if route=='apple':
            matches=re.findall(r'target_include_directories\(mlx BEFORE PRIVATE "([^"]+)"\)',body)
            metal_root=Path([x for x in matches if 'metal-tsan-' in x][-1]);metal=metal_root/'Metal/MTLCommandBuffer.hpp'
            assert hashlib.sha256(metal.read_bytes()).hexdigest()=='4a58c6e564e3a7efcdf5c7709eeee99ec7b7c40594e2ada5ec5c91012171d504'
            product=metal_root.parent/metal_root.name.replace('metal-tsan-','metal-product-')
            assert product.is_dir() and any(product.iterdir())
            for p in product.rglob('*'):
                if p.is_file():
                    rel=p.relative_to(product)
                    assert rel.as_posix()=='Metal/MTLCommandBuffer.hpp' or (metal_root/rel).read_bytes()==p.read_bytes(),str(rel)
            model_dirs.append(metal_root);r['models'].append(dict(path=str(metal),sha256=hashlib.sha256(metal.read_bytes()).hexdigest(),unchanged_product_tree=str(product)))
    if 'add_executable(g08_host_direct ' not in body:
        body+='\n# G08 finite host adapter consumers\n'
        cases={'mem':['tests/mem/allocator_test.cc','tests/mem/buffer_resource_test.cc'],
            'schema':['tests/compute_ops/sampling_test.cc'],
            'direct':[f'tests/compute_route_{route}/sampling_consumer.cc'],
            'graph':[f'tests/compute_route_{route}/sampling_consumer.cc'],
            'joint':[f'tests/graph_route_cpu_{route}/sampling_consumer.cc'],
            'topk':[f'tests/compute_route_{route}/'+('reduction_test.cc' if route=='apple' else 'topk_test.cc'),
                    f'tests/graph_route_{route}/'+('reduction_test.cc' if route=='apple' else 'topk_test.cc')]}
        for name,files in cases.items():
            target='g08_host_'+name;body+='add_executable('+target+' '+' '.join('"'+str(source/p)+'"' for p in files)+')\n'
            body+='target_compile_features('+target+' PRIVATE cxx_std_23)\n'
            links='hyle_mem GTest::gtest_main' if name=='mem' else 'hyle_compute_ops GTest::gtest_main' if name=='schema' else 'hyle::compute hyle::graph'+(' GTest::gtest_main' if name=='topk' else '')
            body+='target_link_libraries('+target+' PRIVATE '+links+')\n'
            if name=='graph':body+='target_compile_definitions('+target+' PRIVATE HYLE_G08_GRAPH=1)\n'
            if name=='mem':body+='target_include_directories('+target+' PRIVATE "'+str(source/'src/mem')+'")\n'
            if name=='topk' and route=='vulkan':
                body+='target_include_directories('+target+' PRIVATE "'+str(source/'src/compute_route_vulkan')+'" "'+str(source/'src/compute')+'")\n'
                body+='get_target_property(g08_ggml_src ggml SOURCE_DIR)\ntarget_include_directories('+target+' SYSTEM PRIVATE "${g08_ggml_src}")\n'
                body+='target_link_libraries('+target+' PRIVATE hyle_compute_provider_ggml_vulkan hyle_compute_ggml_runtime ggml)\n'
            body+='hyle_apply_sanitizer('+target+')\nhyle_stage_runtime('+target+')\n'
            for folder in model_dirs:body+='target_include_directories('+target+' BEFORE PRIVATE "'+str(folder)+'")\n'
        cmake.write_text(body)
    (out/'parent.cmake').write_text(body)
    run('configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build)])
    commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
    flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode]
    suffixes=['src/mem/system.cc','src/compute_ops/sampling_ops.cc',f'src/compute_route_{route}/{route}_sampling.cc',
        'src/compute_route_apple/apple_tensor.cc' if route=='apple' else 'src/compute_route_vulkan/vulkan_program.cc',
        'src/compute_route_apple/apple_mature_indexing.cc' if route=='apple' else 'src/graph_route_vulkan/vulkan_lowering.cc',
        f'tests/compute_route_{route}/sampling_consumer.cc',f'tests/graph_route_cpu_{route}/sampling_consumer.cc']
    checked=[]
    for name in suffixes:
        found=[x for x in commands if x['file'].endswith('/'+name)];assert found and all(flag in x['command'] for x in found),name
        checked.extend(found)
    (out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2))
    run('manifest',['/opt/homebrew/bin/ninja','-C',str(build),'build.ninja'])
    preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
    if route=='vulkan':
        sys.path.insert(0,str(base/'g06-final-host-air'));from reuse_current_vulkan_generated import apply
        r['generated_shader_reuse']=apply(build,preview,out,f'g08-{mode}-{label}')
    targets=['g08_host_'+x for x in ['mem','schema','direct','graph','joint','topk']]
    dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
    (out/'dry-run.log').write_text(dry);r['build_edges']=len(dry.splitlines());save()
    assert 'Re-running CMake' not in dry and 'Building CUDA object' not in dry and 'Generate vulkan shaders' not in dry
    run('build',['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-j','4','-k','0',*targets])
    failed=[]
    for target in targets:
        binary=build/target;assert binary.is_file(),str(binary)
        args=[str(binary)]
        if target=='g08_host_topk' and route=='apple':args+=['--gtest_filter=AppleReduction.*TopK*:AppleReduction.EmptyResultsAndPreparationRejections:AppleGraph.*']
        code,text=run(target,args,False)
        if target in ['g08_host_mem','g08_host_schema','g08_host_topk']:
            if not re.search(r'\[==========\] Running [1-9][0-9]* tests? from',text):failed.append(target+':EMPTY')
        if code:failed.append(target)
        r.setdefault('artifacts',[]).append(dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
    r['failures']=failed;r['state']='HOST_FACET_PASS' if not failed else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save();print(route,mode,r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
