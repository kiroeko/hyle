from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path(__file__).resolve().parents[2];scratch=root/'.scratch/inference-gaps';candidate='5103c13d8ed119b06aa64e799f9768aea45ab913'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==candidate
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
out=root/'evidence/correctness/inference-g08-air-host-facets';out.mkdir(exist_ok=False)
names=[f'g08-{route}-host-{mode}-1' for route in ['apple','vulkan'] for mode in ['asan','ubsan','tsan']]
records=[]
with zipfile.ZipFile(out/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in names:
        folder=scratch/name;r=json.loads((folder/'result.json').read_text());assert r['state']=='HOST_FACET_PASS' and r['source_snapshot']==candidate
        r['selected_gtest_counts']={key:int(re.search(r'\[  PASSED  \] ([1-9][0-9]*) tests?',(folder/f'g08_host_{key}.log').read_text()).group(1)) for key in ['mem','schema','topk']}
        assert len(r['artifacts'])==6 and all(x['exit_code']==0 for x in r['stages'])
        records.append(r)
        for p in sorted(folder.iterdir()):
            if p.is_file():z.write(p,f'{name}/{p.name}')
    for name in ['g08_air_host_risks.py','g08_air_host_matrix.py','g08_air_host_inventory.py','g08-air-host-inventory.json','g08_freeze_candidate.py']:
        z.write(scratch/name,'tools/'+name)
receipt=dict(schema='hyle.g08-air-host-facets/v1',verdict='PASS_SIX_STATIC_HOST_FACETS',candidate=candidate,rows=records,
    scope='Actual Mac16,12 AppleClang21: Apple/Vulkan ASan/UBSan/TSan, six targets per configuration. Full Direct/Graph/joint sampling plus original TopK, selected Mem and schema. No shader/driver/private-pool/leak/P1 or SDK inference.',
    retained_limits='Original refcount final-acquire and Metal external-completion TSan models explicitly qualified and preserved. Models do not certify unobserved vendor or device behavior.',
    reuse='Vulkan borrows only152 generated C++ shader data files after full native GLSL inputs/configuration/commands equality. Native and product C++ retain per-mode sanitizer compilation; no compiled native object/archive is substituted.',
    measured_batch_seconds=sum(x['elapsed_seconds'] for x in records),
    raw_archive=dict(path='raw.zip',sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest()))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
p=root/'docs/implementation/module-status.json';data=p.read_bytes();registry=json.loads(data)
owners=['mem','compute_ops','compute_provider_native','compute_provider_ggml','compute_provider_cuda','compute_route_apple','compute_route_vulkan','graph_route_vulkan']
for row in registry['modules']:
    if row['module'] in owners:
        assert row['state']=='AUDITED' and row['record'].endswith('inference-g08-output-selection.md')
        row['state']='CANDIDATE';row['candidate']=candidate
        row['summary']='G08 CANDIDATE '+candidate[:9]+': finite S1-S4/M1 API and algorithms frozen; four-route numeric/distribution/65-step/independent ports, three joint consumers, actual CUDA/Metal/Vulkan device risks and CPU/CUDA/Apple/Vulkan scoped host facets PASS. Source/static/shared SDK, public headers, exact S1 P1 and terminal review pending.'
text=json.dumps(registry,indent=2,ensure_ascii=False)+'\n'
if b'\r\n' in data:text=text.replace('\n','\r\n')
p.write_bytes(text.encode('utf-8'))
print(json.dumps(dict(candidate=candidate,configs=len(records),consumers=sum(len(x['artifacts']) for x in records),known_seconds=receipt['measured_batch_seconds'])))
