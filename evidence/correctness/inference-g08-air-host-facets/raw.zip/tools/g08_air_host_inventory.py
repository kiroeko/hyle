from pathlib import Path
import hashlib,json
base=Path('/Users/kiro/hyle-scratch/compute-unified');rows=[]
for route in ['apple','vulkan']:
    for mode in ['asan','ubsan','tsan']:
        folder=base/f'foundation-f5-native-host-{route}-{mode}';cache=folder/'build/CMakeCache.txt';parent=folder/'parent/CMakeLists.txt'
        values={}
        for line in cache.read_text().splitlines():
            if line.startswith(('#','//')) or '=' not in line or ':' not in line.split('=')[0]:continue
            key,value=line.split('=',1);key=key.split(':')[0]
            if key in ['HYLE_SANITIZER','HYLE_STATIC','HYLE_COMPONENTS','HYLE_COMPUTE_ROUTES','HYLE_BUILD_TESTS','HYLE_INSTALL','CMAKE_HOME_DIRECTORY','CMAKE_CXX_COMPILER','CMAKE_PROJECT_INCLUDE','CMAKE_PROJECT_TOP_LEVEL_INCLUDES']:values[key]=value
        body=parent.read_text();models=[x.strip() for x in body.splitlines() if 'tsan' in x or 'sanitize' in x]
        rows.append(dict(route=route,mode=mode,folder=str(folder),cache=values,parent=body,parent_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),model_lines=models))
(base/'g08-air-host-inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([dict(route=x['route'],mode=x['mode'],cache=x['cache'],model_lines=x['model_lines']) for x in rows],indent=2))
