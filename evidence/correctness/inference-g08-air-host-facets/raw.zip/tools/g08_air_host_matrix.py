from pathlib import Path
import json,os,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');label,package=sys.argv[1:3]
out=base/f'g08-air-host-matrix-{label}';out.mkdir(exist_ok=False);started=time.monotonic()
r=dict(state='RUNNING',pid=os.getpid(),cases=[],serial=True,max_jobs_per_build=4)
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
for route,mode in [('apple','ubsan'),('apple','tsan'),('vulkan','asan'),('vulkan','ubsan'),('vulkan','tsan')]:
    p=subprocess.Popen([sys.executable,str(base/'g08_air_host_risks.py'),route,mode,label,package])
    r.update(active_route=route,active_mode=mode,child_pid=p.pid);save();code=p.wait()
    result=base/f'g08-{route}-host-{mode}-{label}/result.json'
    result_data=json.loads(result.read_text()) if result.is_file() else dict(state='NO_RESULT')
    r['cases'].append(dict(route=route,mode=mode,exit_code=code,state=result_data['state'],result=str(result)))
    r.pop('child_pid',None);save()
r['state']='ALL_FIVE_HOST_FACETS_PASS' if all(x['state']=='HOST_FACET_PASS' and x['exit_code']==0 for x in r['cases']) else 'FAIL_WITH_ALL_MODES_OBSERVED'
save();print(r['state'],flush=True)
