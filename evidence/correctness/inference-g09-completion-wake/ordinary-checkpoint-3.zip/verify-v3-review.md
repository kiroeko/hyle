# Ordinary v3 preparation review

This is a **draft private entry, not executed**. `verify-v2.py` is preserved byte-for-byte. Only `ast.parse` has checked the v3 Python syntax; no prepare/sync/configure/plan/build/test/device/install or benchmark stage has been invoked. Native new-test bodies and the eventual immutable product/SDK checkpoint remain root/compute-owned. The candidate argument is intentionally not prefilled.

The authorized encoded-consumer patch was applied separately and exactly: only `tests/compute_batch/encoded_page_native_consumer.cc`, UTF-8/LF, SHA256 `95f06d43181ca9a60729a7d20cfb2581f74c1af038e8c100f7ff819bab0e5e0b`, +86/-9, with `git diff --check` passing. This runner preparation makes no additional tracked change and no commit.

## Finite delta from v2

- New private target names/block marker use `g09_wake_v3_` / `G09_WAKE_CORRECTION_FINITE_V3`, preserving existing v2 targets, source and receipts. The original eight public fixtures and their numerical/oracle checks are unchanged.
- Vulkan source/sanitizer facets add one native-unit executable from the existing `tests/compute_route_vulkan/lifecycle_test.cc`. Source `test` and source `device` therefore each have eight fixture executables plus one native-unit executable. Installed static/shared consumers still have eight public fixtures plus the existing two public header probes; the private native TU is never copied into an installed SDK consumer. Static/shared producer target roots remain v2's explicit ten targets.
- Default Vulkan selection is the existing `VulkanLifetime.ManagedWaitAllowsIndependentProducerAndCancelledSlotReuse` plus the two new `VulkanRetirementPublication.*` cases, **three GTests total**. Root approved this finite set after the native owner entered AUDITED at `602614c8b`. Compute's frozen proposed names are `PermissionsRetireBeforeReadinessAndReuse` and `LateObserverErrorPrecedesPermissionRetirement`; prepare refuses a candidate whose actual Git TEST declarations do not supply the required names/count. Apple retains its existing four `AppleCompletionNotification.*` cases.
- `--native-host-filter/--native-host-tests` and `--native-device-filter/--native-device-tests` optionally select reviewed Vulkan subsets at **prepare only**. An explicit filter requires an explicit positive count, checked against the candidate's named declarations. The immutable prepared manifest stores the filter, count, exact test names and whether it is a custom subset. Non-prepare stages reject these override arguments; GTest output must have those exact names, count, no failures/disabled/errors, and every case RUN/COMPLETED. A failed receipt still stops the entry. A new directory/filter after failure is not a legal way to restart a budget or claim aggregate PASS.
- The Vulkan native-unit device invocation explicitly enables the existing fixture's `HYLE_VULKAN_VALIDATION=1`, while retaining the existing device layer/validation checks. A successful process alone still does not sign actual layer activation. Host/sanitizer here means the corresponding ordinary validation profile; these native tests still use real Vulkan mathematics/device work, not a CPU-only model.

## Existing private build seam

`tests/compute_route_vulkan/CMakeLists.txt` supplies the source-level native test contract: private includes `src/compute_route_vulkan` and `src/compute`, SYSTEM include `${HYLE_GGML_SOURCE_DIR}/src`, and private links `hyle_compute_provider_ggml_vulkan`, `hyle_compute_ggml_runtime`, `ggml`, in addition to the real GTest main.

The wrapper parent need not inherit `HYLE_GGML_SOURCE_DIR` from its Hyle subdirectory. The v3 fragment therefore gets the actual `ggml` target's `SOURCE_DIR` and checks `ggml-backend-impl.h` there. The locked target is declared in its `src/CMakeLists.txt`, so this binds the same existing private source directory without guessing a source-cache path or importing new archives. It retains v2's real `GTest::gtest_main` reuse, shipping layout, per-facet sanitizer helper/model includes and runtime staging. No public header or symbol export is added.

The future owner plan includes the source-only native-unit contract and public/native executable counts. Its requested roots remain explicit. Native-unit Windows artifact lookup now correctly includes `.exe`; Apple remains suffixless.

## Other existing lifecycle cases: applicability only

The defaults remain the approved three; this audit does not select more tests or run them. If the final native card requires a first-error or checked-status branch beyond those three, these are the finite existing choices to freeze **before execution**:

| Existing case | Relevant branch and source |
|---|---|
| `VulkanLeaseLifetime.RejectedSuffixRetainsLeasesAndFirstErrorThroughNativePrefix` | `lifecycle_test.cc:200`: real native/managed/native prefix, rejected suffix, retained imported lease, abandonment and explicit drain; checks the first ResourceExhausted status and unreclaimed owner while native retirement remains unproven. |
| `VulkanLifecycle.CheckedGatherFlushInvalidateCancelAndAbandon` | `lifecycle_test.cc:735`: real Gather output, flush/invalidate, checked OutOfRange surviving cancellation, plus abandonment. Relevant if the finalized publication change covers checked-status precedence. |
| `VulkanLifecycle.CheckedGatherMappedFailuresKeepAdmissionAndRetirementDistinct` | `lifecycle_test.cc:834`: zero-submission flush rejection versus accepted invalidation failure and a fresh successful slot. Relevant if the finalized change touches that late checked-status failure branch. |

There is no selection of the full native factor/TU test suite, unrelated IREE/descriptor/quota sweeps or extra benchmark workload. The existing 65-step joint Graph mathematical fixtures remain separately required; these source gates do not replace them.

## Preserved identity, budget and stop rules

The original source-archive export-subst mapping, exact canonical/archive file checks, actual VS helper/context binding, Air `Mac16,12` identity, cached source/compiler/flags checks, parent-CMake hash, original GTest reuse, preview Ninja identity, 200-line/broad rebuild guard, unchanged 152 DATA hashes and inner-generator freshness checks are unchanged. Installed consumer DLL/dyld provenance and all original test counts/oracles remain intact.

Preparation inherits the checkpoint-2 summary/archive and original v2 failed source receipt/device JSON/log in addition to the earlier preparation/plan/build failures. It reads the retained cumulative command total **718.4049999999697 seconds (718.405 rounded)** from `ordinary-checkpoint-2.json`, rather than adding checkpoint 2 to its already included 361.126 seconds again. Any different cumulative cost requires renewed review; it is not silently reset. New measured command time accumulates on top in the original receipt logic.

The original `--execute-reviewed`, prerequisite-stage, failure-stop and no-implicit-rerun guards remain. Heavy work stays globally serialized, child build parallelism remains two and Windows child affinity/BelowNormal handling is unchanged. Nothing authorizes P1, A/A, an old launcher, new epochs, or performance instrumentation. Root must freeze the final native tests/product and review this exact script before any stage is allowed.
