#!/usr/bin/env python3
"""Private finite M1 entry; inert without a reviewed explicit stage request."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--stage', choices=['configure', 'plan', 'build', 'query'], required=True)
p.add_argument('--execute-reviewed', action='store_true')
a = p.parse_args()
assert a.execute_reviewed, 'Preparation only; explicit reviewed stage GO required'
here = Path(__file__).resolve().parent
c = json.loads((here / 'contract.json').read_text(encoding='utf-8'))
assert here.as_posix() == c['remote_directory'], 'Wrong private entry directory'
assert os.uname().sysname == 'Darwin', 'Only original Air profile is selected'
sha = lambda x: hashlib.sha256(x).hexdigest()
digest = lambda x: sha(Path(x).read_bytes())
for item in c['entry_files'] + c['original_inputs']:
    assert digest(item['path']) == item['sha256'], 'Input identity changed: ' + item['path']
assert subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip() == 'Mac16,12'
assert subprocess.check_output(['/usr/bin/sw_vers', '-buildVersion'], text=True).strip() == '26A434'
assert 'Apple clang version 21.0.0 (clang-2100.3.34.2)' in subprocess.check_output(['/usr/bin/clang++', '--version'], text=True)
receipt = here / 'receipt.json'
r = json.loads(receipt.read_text()) if receipt.exists() else {
    'state': 'PRIVATE_QUERY_NOT_PRODUCT_VALIDATION', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'started_monotonic': time.monotonic(),
    'original_failure_preserved': True, 'budget_reset': False, 'stages': [], 'commands': [],
    'scope': 'Exact original pipeline construction and read-only resource query; no original fixture or GPU math submission.',
}
r.setdefault('contract_sha256', digest(here / 'contract.json'))
assert r['contract_sha256'] == digest(here / 'contract.json'), 'Frozen private contract changed'
assert time.monotonic() - r['started_monotonic'] < 600, 'Finite 10-minute private entry budget expired'
assert datetime.datetime.now(datetime.timezone.utc) < datetime.datetime.fromisoformat(c['global_deadline_utc']), 'Inherited overall deadline expired'
assert not r.get('failure'), 'Prior failure retained; no automatic rerun'
assert a.stage not in r['stages'], 'Each stage is one-shot'
prerequisite = {'plan': 'configure', 'build': 'plan', 'query': 'build'}
if a.stage in prerequisite:
    assert prerequisite[a.stage] in r['stages'], 'Missing reviewed prerequisite'
if 'binary' in r:
    assert digest(r['binary']['path']) == r['binary']['sha256'], 'Frozen helper binary changed'
build = here / 'build'
env = dict(os.environ)
assert not any(k.startswith(('MLX_', 'DYLD_')) for k in env), 'Unreviewed MLX/DYLD environment override'
removed = sorted(k for k in env if k.startswith('MTL_'))
for k in removed:
    del env[k]
env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
           PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
r.setdefault('removed_ambient_mtl_keys', removed)

def save():
    receipt.write_text(json.dumps(r, indent=2) + '\n')

def run(label, command, timeout, selected_env=env):
    remaining = 600 - (time.monotonic() - r['started_monotonic'])
    remaining_global = (datetime.datetime.fromisoformat(c['global_deadline_utc']) - datetime.datetime.now(datetime.timezone.utc)).total_seconds()
    assert remaining >= timeout + 10 and remaining_global >= timeout + 10, 'Insufficient inherited/private command budget'
    log = here / (label + '.log')
    assert not log.exists(), 'Existing stage output cannot be overwritten'
    item = {'label': label, 'command': command, 'timeout_seconds': timeout,
            'actual_requested_mtl_environment': {k: v for k, v in selected_env.items() if k.startswith('MTL_')}}
    r['commands'].append(item)
    save()
    started = time.monotonic()
    with log.open('wb') as out:
        child = subprocess.Popen(['/usr/bin/nice', '-n', '10'] + command,
                                 stdout=out, stderr=subprocess.STDOUT,
                                 env=selected_env, start_new_session=True)
        item['child_pid'] = child.pid
        save()
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            item['timed_out'] = True
            code = child.returncode
    item.update(exit_code=code, seconds=time.monotonic() - started,
                log=str(log), log_sha256=digest(log))
    save()
    assert not item.get('timed_out') and code == 0, (label, code)
    return log.read_text(errors='replace')

try:
    if a.stage == 'configure':
        run('configure', ['/opt/homebrew/bin/cmake', '-S', str(here), '-B', str(build),
                         '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=/usr/bin/clang++',
                         '-DCMAKE_OSX_ARCHITECTURES=arm64', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
                         '-DCMAKE_OSX_SYSROOT=/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk',
                         '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'], 45)
    elif a.stage == 'plan':
        dry = run('plan', ['/opt/homebrew/bin/ninja', '-C', str(build), '-n', '-v', 'g09_m1_pipeline_query'], 15)
        actions = [line for line in dry.splitlines() if re.match(r'\[\d+/\d+\] ', line)]
        assert len(actions) == 2 and sum(' -c ' in x and 'query.cc' in x for x in actions) == 1, actions
        assert not re.search(r'Re-running CMake|xcrun|metallib|\.metal\b', '\n'.join(actions)), 'Unexpected source/vendor/shader compile action'
        r['finite_plan'] = {'actions': actions, 'source_tus_compiled': 1, 'link_actions': 1,
                            'reused_original_string_objects': 2, 'product_vendor_compiles': 0,
                            'ninja_sha256': digest(build / 'build.ninja')}
    elif a.stage == 'build':
        assert digest(build / 'build.ninja') == r['finite_plan']['ninja_sha256']
        run('build', ['/opt/homebrew/bin/ninja', '-C', str(build), '-j', '1', '-v', 'g09_m1_pipeline_query'], 60)
        binary = build / 'g09_m1_pipeline_query'
        r['binary'] = {'path': str(binary), 'sha256': digest(binary), 'bytes': binary.stat().st_size}
        r['otool'] = run('otool', ['/usr/bin/otool', '-L', str(binary)], 10)
    else:
        results = []
        for mode in ['none', 'api', 'api_gpu']:
            selected = dict(env)
            if mode != 'none': selected['MTL_DEBUG_LAYER'] = '1'
            if mode == 'api_gpu': selected['MTL_SHADER_VALIDATION'] = '1'
            text = run('query-' + mode, [r['binary']['path'], mode], 90, selected)
            lines = [line for line in text.splitlines() if line.startswith('{')]
            assert len(lines) == 1, 'A single query JSON is required'
            result = json.loads(lines[0])
            assert result['variant'] == mode and result['msl_sha256'] == c['expected_msl_sha256']
            assert result['encoder_created_by_helper'] is False and result['gpu_dispatches_by_helper'] == 0
            activation = {'api_log_seen': 'Metal API Validation Enabled' in text,
                          'gpu_log_seen': 'Metal GPU Validation Enabled' in text,
                          'pipeline_reported_shader_validation': result['pipeline_shader_validation']}
            results.append({'requested_variant': mode, 'actual_activation_evidence': activation, 'resource_query': result})
            r['query_results'] = results
            save()
        r['interpretation_limit'] = 'These are pipeline queries. No original encoder dynamic state or encoding-time accounting was observed. Equal static values leave the original 58368-byte failure unexplained. Original combined validation remains FAIL.'
    for item in c['entry_files'] + c['original_inputs']:
        assert digest(item['path']) == item['sha256'], 'Post-stage input identity changed: ' + item['path']
    r['stages'].append(a.stage)
    save()
except BaseException as error:
    r['failure'] = {'stage': a.stage, 'error': repr(error), 'automatic_retries': 0}
    save()
    raise
print(json.dumps({'completed_stage': a.stage, 'receipt': str(receipt), 'aggregate_product_pass': False}))
