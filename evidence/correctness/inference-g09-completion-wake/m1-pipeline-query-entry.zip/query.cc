// Private G09 diagnostic. Reuses two unchanged source-string objects and libmlx.
// No command encoder, array evaluation, Metal dispatch, or queue submission.
#include <mlx/backend/metal/device.h>
#include <mlx/backend/metal/metal.h>
#include <CommonCrypto/CommonDigest.h>
#include <dlfcn.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <stdexcept>
#include <string>
#include <string_view>

namespace mlx::core::metal {
const char* utils();
const char* steel_attention();
}

namespace {
constexpr char kBase[] =
    "steel_attention_float16_bq32_bk16_bd256_wm4_wn1_maskfloat16_bv256";
constexpr char kHash[] =
    "steel_attention_float16_bq32_bk16_bd256_wm4_wn1_maskfloat16_bv256"
    "_align_Q_n_align_K_n_has_mask_n_do_causal_t_has_sinks_n_hyle_1_0_0";
// Exact get_template_definition(name, "attention", "half", 32, 16, 256,
// 4, 1, "half", "float", 256, "half") output from locked kernels.h.
constexpr char kInstantiation[] =
    "\ntemplate [[host_name(\"steel_attention_float16_bq32_bk16_bd256_wm4_wn1_maskfloat16_bv256\")]] [[kernel]] "
    "decltype(attention<half, 32, 16, 256, 4, 1, half, float, 256, half>) "
    "attention<half, 32, 16, 256, 4, 1, half, float, 256, half>;\n";
constexpr char kMslSha[] =
    "5749a119fa92574afd316b2a551577c2d95ab9f9bcf1d76605372068f022e77f";
constexpr char kUtilsSha[] =
    "b24b5dfa5c08e49e87dced0ddd481889fb46fabcd688daab655383315f6c00e3";
constexpr char kSteelSha[] =
    "9e6409d8551d5ff4a05ab2e52d041d002458fdc1e573645a459087a35ddccbf2";

std::string sha256(std::string_view input) {
  unsigned char digest[CC_SHA256_DIGEST_LENGTH];
  CC_SHA256(input.data(), static_cast<CC_LONG>(input.size()), digest);
  char output[CC_SHA256_DIGEST_LENGTH * 2 + 1];
  for (unsigned i = 0; i < CC_SHA256_DIGEST_LENGTH; ++i)
    std::snprintf(output + 2 * i, 3, "%02x", unsigned(digest[i]));
  return output;
}

std::string quote(std::string_view value) {
  std::string out = "\"";
  for (unsigned char c : value) {
    if (c == '\\' || c == '"') { out += '\\'; out += char(c); }
    else if (c >= 32) out += char(c);
    else {
      char buffer[7];
      std::snprintf(buffer, sizeof(buffer), "\\u%04x", unsigned(c));
      out += buffer;
    }
  }
  return out + '"';
}

void require(bool value, const char* message) {
  if (!value) throw std::runtime_error(message);
}

bool env_equals(const char* key, const char* expected) {
  const char* actual = std::getenv(key);
  return expected ? (actual && std::strcmp(actual, expected) == 0) : !actual;
}
}  // namespace

int main(int argc, char** argv) {
  try {
    require(argc == 2, "Exactly one predeclared variant is required");
    const std::string_view variant = argv[1];
    const bool none = variant == "none";
    const bool api = variant == "api";
    const bool gpu = variant == "api_gpu";
    require(none || api || gpu, "Unknown diagnostic variant");
    require(env_equals("MTL_DEBUG_LAYER", none ? nullptr : "1") &&
                env_equals("MTL_SHADER_VALIDATION", gpu ? "1" : nullptr),
            "Process validation environment differs from frozen variant");

    const std::string_view utils = mlx::core::metal::utils();
    const std::string_view steel = mlx::core::metal::steel_attention();
    require(sha256(utils) == kUtilsSha && sha256(steel) == kSteelSha,
            "Original embedded MSL preamble identity changed");
    std::string source(utils);
    source += steel;
    source += kInstantiation;
    require(source.size() == 123307 && sha256(source) == kMslSha,
            "Full original instantiated MSL identity changed");

    Dl_info image{};
    require(dladdr(reinterpret_cast<const void*>(&mlx::core::metal::device),
                   &image) && image.dli_fname,
            "Cannot identify actual loaded MLX image");
    require(std::strcmp(image.dli_fname,
        "/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/"
        "source-build/hyle/_deps/mlx-build/libmlx.dylib") == 0,
        "A different MLX image was loaded");
    require(mlx::core::metal::get_metallib_path().empty(),
            "Unexpected MLX default metallib override");

    auto pool = NS::AutoreleasePool::alloc()->init();
    struct ReleasePool {
      NS::AutoreleasePool* pool;
      ~ReleasePool() { pool->release(); }
    } release{pool};
    auto& device = mlx::core::metal::device(mlx::core::Device::gpu);
    // Identical constants and original Device factory calls. CompileOptions{}
    // remains selected by the same library. No custom MathMode/MSL version.
    const bool align_q = false, align_k = false, has_mask = false;
    const bool causal = true, sinks = false, paged = true;
    const bool q8 = false, window = false;
    const mlx::core::metal::MTLFCList constants = {
        {&align_q, MTL::DataType::DataTypeBool, 200},
        {&align_k, MTL::DataType::DataTypeBool, 201},
        {&has_mask, MTL::DataType::DataTypeBool, 300},
        {&causal, MTL::DataType::DataTypeBool, 301},
        {&sinks, MTL::DataType::DataTypeBool, 302},
        {&paged, MTL::DataType::DataTypeBool, 303},
        {&q8, MTL::DataType::DataTypeBool, 304},
        {&window, MTL::DataType::DataTypeBool, 305}};
    auto* library = device.get_library(kBase, [&] { return source; });
    auto* pipeline = device.get_kernel(kBase, library, kHash, constants);
    require(pipeline != nullptr, "Original pipeline factory returned null");

    // Query and report even when over limit. An over-limit value is evidence,
    // not a reason for this query helper to abort before writing the result.
    std::printf(
        "{\"variant\":%s,\"kind\":\"PIPELINE_RESOURCE_QUERY_ONLY\","
        "\"mlx_image\":%s,\"device\":%s,\"architecture\":%s,"
        "\"kernel_base\":%s,\"kernel_hash\":%s,\"msl_sha256\":\"%s\","
        "\"msl_bytes\":%zu,\"pipeline_static_threadgroup_bytes\":%llu,"
        "\"device_max_threadgroup_bytes\":%llu,"
        "\"pipeline_max_threads\":%llu,\"pipeline_thread_execution_width\":%llu,"
        "\"pipeline_shader_validation\":%llu,"
        "\"original_declared_arrays_bytes\":29184,"
        "\"encoder_created_by_helper\":false,\"gpu_dispatches_by_helper\":0,"
        "\"original_encoder_dynamic_memory\":\"NOT_OBSERVED\"}\n",
        quote(variant).c_str(), quote(image.dli_fname).c_str(),
        quote(device.mtl_device()->name()->utf8String()).c_str(),
        quote(device.get_architecture()).c_str(), quote(kBase).c_str(),
        quote(kHash).c_str(), kMslSha, source.size(),
        static_cast<unsigned long long>(pipeline->staticThreadgroupMemoryLength()),
        static_cast<unsigned long long>(device.mtl_device()->maxThreadgroupMemoryLength()),
        static_cast<unsigned long long>(pipeline->maxTotalThreadsPerThreadgroup()),
        static_cast<unsigned long long>(pipeline->threadExecutionWidth()),
        static_cast<unsigned long long>(pipeline->shaderValidation()));
    std::fflush(stdout);
    return 0;
  } catch (const std::exception& error) {
    std::fprintf(stderr, "M1 pipeline-query preparation/factory failure: %s\n",
                 error.what());
    return 2;
  }
}
