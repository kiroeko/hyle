$ErrorActionPreference = 'Stop'
$appleRoot = 'C:\public\project-hyle\hyle'
$appleBuild = 'C:\hyle-scratch\m1a-schema'
$appleLogs = Join-Path $appleRoot '.scratch\validation\m1-apple-admission'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1aErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1aErrorMode]::SetErrorMode(0x8003)
. (Join-Path $appleRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'compute_ops' -BinaryDir $appleBuild -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=ON','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') > (Join-Path $appleLogs 'schema-windows-configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& cmake --build $appleBuild --parallel 2 --target hyle_compute_ops_tests > (Join-Path $appleLogs 'schema-windows-build.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$appleBin = Join-Path $appleBuild 'bin'
foreach ($appleDll in Get-ChildItem -LiteralPath $appleBuild -Recurse -File -Filter '*.dll') {
  $appleDestination = Join-Path $appleBin $appleDll.Name
  if ($appleDll.FullName -ne $appleDestination) {
    Copy-Item -LiteralPath $appleDll.FullName -Destination $appleDestination -Force
  }
}
& ctest --test-dir $appleBuild -L '^compute_ops$' --output-on-failure --timeout 60 > (Join-Path $appleLogs 'schema-windows-tests.log') 2>&1
exit $LASTEXITCODE
