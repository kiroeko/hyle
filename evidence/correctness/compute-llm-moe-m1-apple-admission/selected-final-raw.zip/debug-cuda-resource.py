import ctypes as c
from ctypes import wintypes as w
import json
import os
from pathlib import Path
import struct
import subprocess
import time

root = Path.cwd()
out = root / '.scratch/validation/m1-apple-admission'
build = Path('C:/ha/e8e0c0e99c7b4f69d7a8/build-f3d8628afbd86b46ffc8')
exe = build / 'bin/hyle_compute_ggml_runtime_cuda_test.exe'
k = c.WinDLL('kernel32', use_last_error=True)
k.SetErrorMode(0x8003)
commands = subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', str(exe.relative_to(build)).replace('\\', '/')], text=True)
link = [line for line in commands.splitlines() if '/out:bin\\hyle_compute_ggml_runtime_cuda_test.exe ' in line][-1]
map_path = out / 'cuda-resource.map'
link = link.replace('/out:bin\\hyle_compute_ggml_runtime_cuda_test.exe ', '/MAP:' + map_path.as_posix() + ' /out:bin\\hyle_compute_ggml_runtime_cuda_test.exe ')
with (out / 'cuda-resource-map-link.log').open('wb') as log:
    subprocess.run(link, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True)

class Event(c.Structure):
    _fields_ = [('code', w.DWORD), ('pid', w.DWORD), ('tid', w.DWORD), ('data', c.c_ulonglong * 20)]

k.WaitForDebugEvent.argtypes = [c.POINTER(Event), w.DWORD]
k.ContinueDebugEvent.argtypes = [w.DWORD, w.DWORD, w.DWORD]
k.OpenThread.argtypes = [w.DWORD, w.BOOL, w.DWORD]
k.OpenThread.restype = w.HANDLE
k.GetThreadContext.argtypes = [w.HANDLE, c.c_void_p]
k.ReadProcessMemory.argtypes = [w.HANDLE, c.c_void_p, c.c_void_p, c.c_size_t, c.POINTER(c.c_size_t)]
k.K32EnumProcessModulesEx.argtypes = [w.HANDLE, c.c_void_p, w.DWORD, c.POINTER(w.DWORD), w.DWORD]
k.K32GetModuleFileNameExW.argtypes = [w.HANDLE, w.HMODULE, w.LPWSTR, w.DWORD]
k.CloseHandle.argtypes = [w.HANDLE]

with (out / 'cuda-resource-debug-native.log').open('wb') as log:
    process = subprocess.Popen([str(exe), '--gtest_catch_exceptions=0'], creationflags=2,
                               stdout=log, stderr=subprocess.STDOUT)
    result = {'exe': str(exe), 'pid': process.pid}
    try:
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            event = Event()
            if not k.WaitForDebugEvent(c.byref(event), 1000):
                continue
            disposition = 0x10002
            if event.code == 1:
                raw = bytes(event.data)
                code = struct.unpack_from('<I', raw)[0]
                if code == 0xc0000094:
                    result['exception_code'] = hex(code)
                    result['exception_address'] = hex(struct.unpack_from('<Q', raw, 16)[0])
                    storage = c.create_string_buffer(1250)
                    context = (c.addressof(storage) + 15) & ~15
                    c.c_uint32.from_address(context + 48).value = 0x10001f
                    thread = k.OpenThread(0x1fffff, False, event.tid)
                    assert thread and k.GetThreadContext(thread, context), c.get_last_error()
                    registers = {name: c.c_uint64.from_address(context + offset).value for name, offset in
                                 [('rax',120),('rcx',128),('rdx',136),('rbx',144),('rsp',152),('rbp',160),('rsi',168),('rdi',176),('r8',184),('r9',192),('r10',200),('r11',208),('r12',216),('r13',224),('r14',232),('r15',240),('rip',248)]}
                    k.CloseHandle(thread)
                    result['registers'] = {name: hex(value) for name, value in registers.items()}
                    modules = (w.HMODULE * 512)()
                    needed = w.DWORD()
                    assert k.K32EnumProcessModulesEx(process._handle, modules, c.sizeof(modules), c.byref(needed), 3)
                    result['modules'] = []
                    for module in modules[:needed.value // c.sizeof(w.HMODULE)]:
                        name = c.create_unicode_buffer(32768)
                        k.K32GetModuleFileNameExW(process._handle, module, name, len(name))
                        result['modules'].append({'base': hex(module), 'path': name.value})
                    stack = c.create_string_buffer(768)
                    read = c.c_size_t()
                    assert k.ReadProcessMemory(process._handle, registers['rsp'], stack, len(stack), c.byref(read))
                    result['stack_words'] = [hex(v[0]) for v in struct.iter_unpack('<Q', stack.raw[:read.value])]
                    code_bytes = c.create_string_buffer(64)
                    assert k.ReadProcessMemory(process._handle, registers['rip'] - 24, code_bytes, len(code_bytes), c.byref(read))
                    result['instruction_bytes'] = code_bytes.raw[:read.value].hex()
                    process.terminate()
                    k.ContinueDebugEvent(event.pid, event.tid, 0x10002)
                    break
                if code not in (0x80000003, 0x80000004):
                    disposition = 0x80010001
            if event.code == 5:
                result['exit_without_divide'] = True
                break
            k.ContinueDebugEvent(event.pid, event.tid, disposition)
    finally:
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=10)
    (out / 'cuda-resource-debug.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps({key: value for key,value in result.items() if key != 'modules'}, indent=2))
