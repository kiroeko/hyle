"""Resume unchanged selected commands after a test-only dependency correction."""
import json
from pathlib import Path
import subprocess

root = Path.cwd()
out = root / '.scratch/validation/m1-apple-admission'
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
baseline = 'b5ddc5ea25e058243f7b7093c26bf4ca2d23b02c'
changed = subprocess.check_output(['git', 'diff', '--name-only', baseline, candidate], text=True).splitlines()
allowed = {
    'tests/compute_ggml_runtime/CMakeLists.txt',
    'tests/compute_ggml_runtime/cuda_resource_test.cc',
    'docs/implementation/tasks/compute/llm-moe-m1-apple-admission.md',
    'docs/implementation/tasks/compute/llm-moe-provider-integration-ledger.md',
    'evidence/correctness/compute-llm-moe-m1-apple-admission/cross-native-delivery.json',
    'evidence/correctness/compute-llm-moe-m1-apple-admission/cross-native-delivery-raw.zip',
}
assert set(changed) == allowed
previous = json.loads((out / 'continued-result.json').read_text())
assert previous['candidate'] == baseline and previous['status'] == 'FAIL'
completed = [g['id'] for g in previous['gates'] if g['status'] == 'PASS' and g['id'] != 'configure']
script = (out / 'continue-selected.py').read_text()
script = script.replace("candidate = old['candidate_commit']", "candidate = " + repr(candidate))
script = script.replace("assert candidate == '" + baseline + "'", "assert old['candidate_commit'] == '" + baseline + "'")
script = script.replace("'source_unchanged': True,", "'product_source_unchanged': True, 'changed_paths': " + repr(changed) + ",\n    'test_only_plan': 'test-timer-plan.json',\n    'previous_native_report': 'continued-result.json',\n    'previous_native_sha256': hashlib.sha256((out / 'continued-result.json').read_bytes()).hexdigest(),")
script = script.replace("'reuse': 'Only the three completed maintenance/tool gates are retained from their original receipts. Native configure failed before native gates; all remaining gates execute.'", "'reuse': 'Prior evidence retains its original b5ddc5ea candidate identity. No product source changed; only CUDA test PRIVATE links and its private ggml timer initialization were corrected. Reconfigure incrementally, rerun that failed factor, and execute every pending original gate. This is a task evidence continuation, not new selector cache receipts.'")
script = script.replace("'skipped_gates': old['skipped_gates']", "'prior_native_pass': " + repr(completed) + ", 'skipped_gates': old['skipped_gates']")
script = script.replace("record = out / 'continued-result.json'", "record = out / 'corrected-result.json'")
script = script.replace("if gate['status'] == 'PASS':", "if gate['status'] == 'PASS' or gate['id'] in " + repr(completed) + ":")
script = script.replace("out / ('continued-'", "out / ('corrected-'")
(out / 'correct-selected.py').write_bytes(script.encode())
launcher = (out / 'continue-selected.ps1').read_text().replace('continue-selected.py', 'correct-selected.py').replace('continued-environment.log', 'corrected-environment.log').replace('continued-run.log', 'corrected-run.log')
(out / 'correct-selected.ps1').write_bytes(launcher.encode())
print(candidate)
