"""Execute the already-selected remaining gates after SDK environment correction.

This task-local runner follows the existing M1-R continuation recipe. Original
selector FAIL/PASS receipts retain their identities; no central policy changes.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path.cwd().resolve()
out = root / '.scratch/validation/m1-apple-admission'
old_path = out / 'selected-windows-result.json'
old = json.loads(old_path.read_text())
candidate = old['candidate_commit']
assert candidate == 'b5ddc5ea25e058243f7b7093c26bf4ca2d23b02c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
scratch = Path('C:/ha/e8e0c0e99c7b4f69d7a8').resolve()
build = scratch / 'build-f3d8628afbd86b46ffc8'
assert Path('C:/ha/m1a-owner.txt').is_file()
assert 'CMAKE_HOME_DIRECTORY:INTERNAL=' + root.as_posix() in (build / 'CMakeCache.txt').read_text()
ctypes.windll.kernel32.SetErrorMode(0x8003)
environment = dict(os.environ)
assert environment['VULKAN_SDK'] == 'C:\\public\\tools\\hyle-vulkan\\1.4.357.0'
native = scratch / 'native-context.cmake'
assert native.is_file()
corrected = scratch / 'native-validation.cmake'
corrected.write_bytes(('include("' + native.as_posix() + '")\n'
                      'set(CMAKE_CUDA_ARCHITECTURES 89 CACHE STRING "M1-A W1-WIN qualification domain" FORCE)\n').encode())
environment['CMAKE_TOOLCHAIN_FILE'] = str(corrected)
environment['CUDAARCHS'] = '89'
report = {
    'candidate': candidate, 'original_selector_result': old_path.name,
    'original_selector_sha256': hashlib.sha256(old_path.read_bytes()).hexdigest(),
    'source_unchanged': True,
    'environment_correction': {'VULKAN_SDK': environment['VULKAN_SDK'],
                               'CMAKE_PREFIX_PATH': environment.get('CMAKE_PREFIX_PATH'),
                               'CMAKE_CUDA_ARCHITECTURES': '89',
                               'validation_toolchain_sha256': hashlib.sha256(corrected.read_bytes()).hexdigest(),
                               'native_context_sha256': hashlib.sha256(native.read_bytes()).hexdigest()},
    'reuse': 'Only the three completed maintenance/tool gates are retained from their original receipts. Native configure failed before native gates; all remaining gates execute.',
    'prior_pass_gates': [g for g in old['selected_gates'] if g['status'] == 'PASS'],
    'skipped_gates': old['skipped_gates'], 'status': 'RUNNING', 'gates': [], 'cleaned': []}
record = out / 'continued-result.json'
def save():
    record.write_bytes((json.dumps(report, indent=2) + '\n').encode())
save()
replacement = {'{python}': sys.executable, '{root}': str(root),
               '{scratch}': str(scratch), '{build}': str(build)}
for gate in old['selected_gates']:
    if gate['status'] == 'PASS':
        continue
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    item = {'id': gate['id'], 'status': 'RUNNING', 'logs': []}
    report['gates'].append(item)
    save()
    print('RUN ' + gate['id'], flush=True)
    for index, template in enumerate(gate['commands']):
        argv = []
        for token in template:
            for source, destination in replacement.items():
                token = token.replace(source, destination)
            argv.append(token)
        if gate['id'] == 'configure':
            argv += ['-DCMAKE_CUDA_ARCHITECTURES=89', '-DCMAKE_TOOLCHAIN_FILE=' + str(corrected)]
        # Normal test targets stage dependencies already. Keep the user's
        # executable-adjacent DLL rule even for standalone test fixtures.
        if argv[0] == 'ctest':
            binary = build / 'bin'
            if binary.is_dir():
                for dll in build.rglob('*.dll'):
                    destination = binary / dll.name
                    if dll.resolve() != destination.resolve():
                        shutil.copy2(dll, destination)
        log = out / ('continued-' + gate['id'].replace(':', '-') + '-' + str(index) + '.log')
        with log.open('wb') as stream:
            result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, env=environment)
        item['logs'].append({'path': log.name, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
                             'argv': argv, 'exit_code': result.returncode})
        save()
        if result.returncode:
            item['status'] = report['status'] = 'FAIL'
            save()
            print('FAIL ' + gate['id'] + ': ' + str(log), flush=True)
            raise SystemExit(1)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    item['status'] = 'PASS'
    save()
    print('PASS ' + gate['id'], flush=True)
report['status'] = 'PASS'
save()
