$ErrorActionPreference = 'Stop'
$m1aRoot = 'C:\public\project-hyle\hyle'
$m1aLogs = Join-Path $m1aRoot '.scratch\validation\m1-apple-admission'
$m1aScratch = 'C:\ha'
# Short, task-owned build paths avoid the previously qualified MSVC path limit.
# The selector's CMake smoke removes only children beneath this explicit root.
if ((Test-Path -LiteralPath $m1aScratch) -and
    -not (Test-Path -LiteralPath (Join-Path $m1aScratch 'm1a-owner.txt'))) {
  throw 'C:\ha already exists without this task ownership marker'
}
[void](New-Item -ItemType Directory -Path $m1aScratch -Force)
Set-Content -LiteralPath (Join-Path $m1aScratch 'm1a-owner.txt') -Value 'M1-A selector validation; canonical source remains C:\public\project-hyle\hyle'
$m1aResolved = (Resolve-Path -LiteralPath $m1aScratch).Path
if ($m1aResolved -ne $m1aScratch -or
    ((Get-Item -LiteralPath $m1aScratch).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
  throw 'unexpected task scratch target'
}
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:MAX_JOBS = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1aSelectorErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1aSelectorErrorMode]::SetErrorMode(0x8003)
# The existing launcher imports the qualified MSVC environment. This is a
# prerequisite for the selected native gates, not a documentation-only rebuild.
. (Join-Path $m1aRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'compute_ggml_runtime,compute_ops,graph_route_apple,compute_provider_ggml_metal' -BinaryDir 'C:\hyle-scratch\m1a-schema' -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_STATIC=ON','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') > (Join-Path $m1aLogs 'selected-windows-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python scripts/validation-select.py run --base 6217e5663acb6825a72cc8a1a2e3d82735d8ceee --candidate b5ddc5ea --context .scratch/validation/windows-msvc-context.json --scratch $m1aScratch --cache (Join-Path $m1aLogs 'selected-receipts') --output (Join-Path $m1aLogs 'selected-windows-result.json') > (Join-Path $m1aLogs 'selected-windows-run.log') 2>&1
exit $LASTEXITCODE
