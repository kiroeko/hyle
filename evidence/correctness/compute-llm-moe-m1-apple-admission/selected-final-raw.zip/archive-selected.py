"""Archive the completed selected bundle, preserving every failed attempt."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path.cwd()
scratch = root / '.scratch/validation/m1-apple-admission'
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert candidate == '140054b13ce2515a05bc6eedac7e03e56bbc3662'
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
original = json.loads((scratch / 'selected-windows-result.json').read_text())
first = json.loads((scratch / 'continued-result.json').read_text())
middle = json.loads((scratch / 'corrected-result.json').read_text())
corrected = json.loads((scratch / 'remaining-result.json').read_text())
assert corrected['candidate'] == candidate and corrected['status'] == 'PASS'
review = json.loads((scratch / 'candidate-review.json').read_text())
assert review['candidate'] == candidate
proof = {}
for record, rows in [('selected-windows-result.json', original['selected_gates']),
                     ('continued-result.json', first['gates']),
                     ('corrected-result.json', middle['gates']),
                     ('remaining-result.json', corrected['gates'])]:
    for row in rows:
        if row['status'] == 'PASS':
            proof[row['id']] = {'verdict': 'PASS', 'record': record}
            for log in row.get('logs', []):
                assert log['exit_code'] == 0
                assert hashlib.sha256((scratch / log['path']).read_bytes()).hexdigest() == log['sha256']
assert set(proof) == {row['id'] for row in original['selected_gates']}
staging = scratch / 'final-evidence'
staging.mkdir(exist_ok=True)
inputs = set()
for pattern in ('selected-*.json', 'selected-*.log', 'selected-*.ps1',
                'continued-*', 'continue-selected.*', 'resumed-*', 'resume-selected.*',
                'corrected-*', 'correct-selected.*', 'remaining-*', 'test-*-plan.json',
                'cuda-resource-*', 'debug-cuda-resource.*', 'prepare-resume.py',
                'prepare-correction.py', 'candidate-review.json', 'cleanup-*.json',
                'cleanup-delivery-*-logs.zip', 'cleanup-completed-deliveries.ps1',
                'progress-loc.json', 'archive-selected.py'):
    inputs.update(path for path in scratch.glob(pattern) if path.is_file())
inputs.update(path for path in (scratch / 'selected-receipts').rglob('*') if path.is_file())
archive = staging / 'selected-final-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zipped:
    for path in sorted(inputs):
        zipped.write(path, path.relative_to(scratch).as_posix())
receipt = {
    'candidate': candidate, 'verdict': 'PASS',
    'scope': 'M1-A selected Windows regression; route-specific Apple acceptance is in the prior native/resource/cross receipts',
    'proof_policy': 'Original PASS evidence retains its original candidate. Product sources are identical; only three CUDA/Graph fixture inputs changed, narrowly reselected and rerun. No selector cache identity was forged.',
    'failures': [
        {'record': 'selected-windows-result.json', 'cause': 'Existing Vulkan SDK was not in the launcher environment; no native gate had run.'},
        {'record': 'continued-result.json', 'cause': 'CUDA fixture omitted its direct mem/error PRIVATE links in the shared build.'},
        {'record': 'resumed-result.json', 'cause': 'CUDA fixture initialized the metadata DLL ggml timer but not its separately embedded upstream copy; debug-event/map proved ggml_time_us divide by zero. Ordinary provider already initializes it.'},
        {'record': 'corrected-result.json', 'cause': 'Standalone Graph CUDA provider fixture omitted direct hyle_graph link; ordinary provider/product unchanged.'}],
    'gates': proof, 'skipped_gates': original['skipped_gates'],
    'review': review, 'new_coverage_cells': 0,
    'p1': 'NOT_APPLICABLE to the finite P0 integration seam; mature-path performance/coverage remains M2/M3',
    'archive': archive.name, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'retained_file_count': len(inputs),
}
(staging / 'selected-final.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps({'gates': len(proof), 'files': len(inputs), 'archive_bytes': archive.stat().st_size}))
