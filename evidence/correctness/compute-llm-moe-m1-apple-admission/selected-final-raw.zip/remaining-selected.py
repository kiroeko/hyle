"""Execute the already-selected remaining gates after SDK environment correction.

This task-local runner follows the existing M1-R continuation recipe. Original
selector FAIL/PASS receipts retain their identities; no central policy changes.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path.cwd().resolve()
out = root / '.scratch/validation/m1-apple-admission'
old_path = out / 'selected-windows-result.json'
old = json.loads(old_path.read_text())
candidate = '140054b13ce2515a05bc6eedac7e03e56bbc3662'
assert old['candidate_commit'] == 'b5ddc5ea25e058243f7b7093c26bf4ca2d23b02c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
scratch = Path('C:/ha/e8e0c0e99c7b4f69d7a8').resolve()
build = scratch / 'build-f3d8628afbd86b46ffc8'
assert Path('C:/ha/m1a-owner.txt').is_file()
assert 'CMAKE_HOME_DIRECTORY:INTERNAL=' + root.as_posix() in (build / 'CMakeCache.txt').read_text()
ctypes.windll.kernel32.SetErrorMode(0x8003)
environment = dict(os.environ)
assert environment['VULKAN_SDK'] == 'C:\\public\\tools\\hyle-vulkan\\1.4.357.0'
native = scratch / 'native-context.cmake'
assert native.is_file()
corrected = scratch / 'native-validation.cmake'
corrected.write_bytes(('include("' + native.as_posix() + '")\n'
                      'set(CMAKE_CUDA_ARCHITECTURES 89 CACHE STRING "M1-A W1-WIN qualification domain" FORCE)\n').encode())
environment['CMAKE_TOOLCHAIN_FILE'] = str(corrected)
environment['CUDAARCHS'] = '89'
report = {
    'candidate': candidate, 'original_selector_result': old_path.name,
    'original_selector_sha256': hashlib.sha256(old_path.read_bytes()).hexdigest(),
    'product_source_unchanged': True, 'changed_paths': ['docs/implementation/tasks/compute/llm-moe-m1-apple-admission.md', 'docs/implementation/tasks/compute/llm-moe-provider-integration-ledger.md', 'evidence/correctness/compute-llm-moe-m1-apple-admission/cross-native-delivery-raw.zip', 'evidence/correctness/compute-llm-moe-m1-apple-admission/cross-native-delivery.json', 'tests/compute_ggml_runtime/CMakeLists.txt', 'tests/graph_provider_ggml_cuda/CMakeLists.txt', 'tests/compute_ggml_runtime/cuda_resource_test.cc'],
    'test_only_plan': 'test-graph-link-plan.json',
    'previous_native_report': 'corrected-result.json',
    'previous_native_sha256': hashlib.sha256((out / 'corrected-result.json').read_bytes()).hexdigest(),
    'environment_correction': {'VULKAN_SDK': environment['VULKAN_SDK'],
                               'CMAKE_PREFIX_PATH': environment.get('CMAKE_PREFIX_PATH'),
                               'CMAKE_CUDA_ARCHITECTURES': '89',
                               'validation_toolchain_sha256': hashlib.sha256(corrected.read_bytes()).hexdigest(),
                               'native_context_sha256': hashlib.sha256(native.read_bytes()).hexdigest()},
    'reuse': 'Prior evidence retains its original b5ddc5ea candidate identity. No product source changed; only CUDA resource fixture PRIVATE links/timer and Graph fixture direct links were corrected. Reconfigure incrementally, retain 41 completed gates, rerun the failed Graph provider factor, and execute every pending original gate. This is a task evidence continuation, not new selector cache receipts.',
    'prior_pass_gates': [g for g in old['selected_gates'] if g['status'] == 'PASS'],
    'prior_native_pass': ['factor:compute', 'factor:compute_backend_cpu', 'factor:compute_backend_cuda', 'factor:compute_ggml_runtime', 'factor:compute_ops', 'factor:compute_provider_cublas', 'factor:compute_provider_cuda', 'factor:compute_provider_ggml_cuda', 'factor:compute_provider_ggml_vulkan', 'factor:compute_provider_marlin', 'factor:compute_provider_native', 'factor:compute_provider_onednn', 'factor:compute_route_cpu', 'factor:compute_route_cuda', 'factor:compute_route_vulkan', 'factor:container', 'factor:container_concurrent', 'factor:container_intrusive', 'factor:container_queue', 'factor:container_text', 'factor:core', 'factor:error', 'factor:graph', 'headers:compute', 'headers:compute_backend_cpu', 'headers:compute_backend_cuda', 'headers:compute_ops', 'headers:compute_provider_cublas', 'headers:compute_provider_cuda', 'headers:compute_provider_flashinfer', 'headers:compute_provider_ggml_cuda', 'headers:compute_provider_marlin', 'headers:compute_provider_native', 'headers:compute_provider_onednn', 'headers:compute_route_apple', 'headers:compute_route_cpu', 'headers:compute_route_cuda', 'headers:compute_route_vulkan', 'headers:container', 'headers:container_concurrent', 'headers:container_intrusive', 'headers:container_queue', 'headers:container_text', 'headers:core', 'headers:error', 'headers:graph'], 'skipped_gates': old['skipped_gates'], 'status': 'RUNNING', 'gates': [], 'cleaned': []}
record = out / 'remaining-result.json'
def save():
    record.write_bytes((json.dumps(report, indent=2) + '\n').encode())
save()
replacement = {'{python}': sys.executable, '{root}': str(root),
               '{scratch}': str(scratch), '{build}': str(build)}
for gate in old['selected_gates']:
    if gate['status'] == 'PASS' or gate['id'] in ['factor:compute', 'factor:compute_backend_cpu', 'factor:compute_backend_cuda', 'factor:compute_ggml_runtime', 'factor:compute_ops', 'factor:compute_provider_cublas', 'factor:compute_provider_cuda', 'factor:compute_provider_ggml_cuda', 'factor:compute_provider_ggml_vulkan', 'factor:compute_provider_marlin', 'factor:compute_provider_native', 'factor:compute_provider_onednn', 'factor:compute_route_cpu', 'factor:compute_route_cuda', 'factor:compute_route_vulkan', 'factor:container', 'factor:container_concurrent', 'factor:container_intrusive', 'factor:container_queue', 'factor:container_text', 'factor:core', 'factor:error', 'factor:graph', 'headers:compute', 'headers:compute_backend_cpu', 'headers:compute_backend_cuda', 'headers:compute_ops', 'headers:compute_provider_cublas', 'headers:compute_provider_cuda', 'headers:compute_provider_flashinfer', 'headers:compute_provider_ggml_cuda', 'headers:compute_provider_marlin', 'headers:compute_provider_native', 'headers:compute_provider_onednn', 'headers:compute_route_apple', 'headers:compute_route_cpu', 'headers:compute_route_cuda', 'headers:compute_route_vulkan', 'headers:container', 'headers:container_concurrent', 'headers:container_intrusive', 'headers:container_queue', 'headers:container_text', 'headers:core', 'headers:error', 'headers:graph']:
        continue
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    item = {'id': gate['id'], 'status': 'RUNNING', 'logs': []}
    report['gates'].append(item)
    save()
    print('RUN ' + gate['id'], flush=True)
    for index, template in enumerate(gate['commands']):
        argv = []
        for token in template:
            for source, destination in replacement.items():
                token = token.replace(source, destination)
            argv.append(token)
        if gate['id'] == 'configure':
            argv += ['-DCMAKE_CUDA_ARCHITECTURES=89', '-DCMAKE_TOOLCHAIN_FILE=' + str(corrected)]
        # Normal test targets stage dependencies already. Keep the user's
        # executable-adjacent DLL rule even for standalone test fixtures.
        if argv[0] == 'ctest':
            binary = build / 'bin'
            if binary.is_dir():
                for dll in build.rglob('*.dll'):
                    destination = binary / dll.name
                    if dll.resolve() != destination.resolve():
                        shutil.copy2(dll, destination)
        log = out / ('remaining-' + gate['id'].replace(':', '-') + '-' + str(index) + '.log')
        with log.open('wb') as stream:
            result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, env=environment)
        item['logs'].append({'path': log.name, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
                             'argv': argv, 'exit_code': result.returncode})
        save()
        if result.returncode:
            item['status'] = report['status'] = 'FAIL'
            save()
            print('FAIL ' + gate['id'] + ': ' + str(log), flush=True)
            raise SystemExit(1)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    item['status'] = 'PASS'
    save()
    print('PASS ' + gate['id'], flush=True)
report['status'] = 'PASS'
save()
