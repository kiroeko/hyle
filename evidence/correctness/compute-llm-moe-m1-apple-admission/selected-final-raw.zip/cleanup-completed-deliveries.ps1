$ErrorActionPreference = 'Stop'
$m1aRepo = 'C:\public\project-hyle\hyle'
$m1aLogs = Join-Path $m1aRepo '.scratch\validation\m1-apple-admission'
$m1aExecutionRoot = 'C:\ha\e8e0c0e99c7b4f69d7a8'
$m1aExpectedMarker = 'M1-A selector validation; canonical source remains C:\public\project-hyle\hyle'
if ((Get-Content -LiteralPath 'C:\ha\m1a-owner.txt' -Raw).Trim() -ne $m1aExpectedMarker) { throw 'Wrong task marker.' }
$m1aReport = Get-Content -LiteralPath (Join-Path $m1aLogs 'remaining-result.json') -Raw | ConvertFrom-Json
if ($m1aReport.candidate -ne '140054b13ce2515a05bc6eedac7e03e56bbc3662') { throw 'Unexpected candidate.' }
$m1aNames = @('compute','container','core','error','graph','io','math','mem','obs','platform','process','sched','simd','time','util')
foreach ($m1aName in $m1aNames) {
    $m1aGate = @($m1aReport.gates | Where-Object { $_.id -eq ('delivery:' + $m1aName) -and $_.status -eq 'PASS' })
    if ($m1aGate.Count -ne 1) { continue }
    $m1aTarget = Join-Path $m1aExecutionRoot ('delivery-' + $m1aName)
    if (-not (Test-Path -LiteralPath $m1aTarget)) { continue }
    $m1aResolved = (Resolve-Path -LiteralPath $m1aTarget).ProviderPath
    if (-not $m1aResolved.Equals($m1aTarget, [StringComparison]::OrdinalIgnoreCase) -or
        -not $m1aResolved.StartsWith($m1aExecutionRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or
        ((Get-Item -LiteralPath $m1aResolved).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected target boundary.' }
    $m1aCache = Join-Path $m1aResolved ('selected-' + $m1aName + '\static-sdk-build\CMakeCache.txt')
    if (-not (Get-Content -LiteralPath $m1aCache -Raw).Contains('CMAKE_HOME_DIRECTORY:INTERNAL=C:/public/project-hyle/hyle')) { throw 'Wrong source owner.' }
    foreach ($m1aLog in $m1aGate[0].logs) {
        $m1aLogPath = Join-Path $m1aLogs $m1aLog.path
        if ($m1aLog.exit_code -ne 0 -or (Get-FileHash -LiteralPath $m1aLogPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $m1aLog.sha256) { throw 'Invalid completed log.' }
    }
    $m1aLive = @(Get-CimInstance Win32_Process | Where-Object {
        $_.CommandLine -and ($_.CommandLine.Replace('/', '\').IndexOf($m1aResolved, [StringComparison]::OrdinalIgnoreCase) -ge 0)
    })
    if ($m1aLive.Count) { throw ('Process still uses ' + $m1aResolved) }
    $m1aArchive = Join-Path $m1aLogs ('cleanup-delivery-' + $m1aName + '-logs.zip')
    if (Test-Path -LiteralPath $m1aArchive) { throw 'Cleanup already archived; inspect before retry.' }
    $m1aLogPaths = @($m1aGate[0].logs | ForEach-Object { Join-Path $m1aLogs $_.path })
    Compress-Archive -LiteralPath $m1aLogPaths -DestinationPath $m1aArchive
    $m1aLinks = @(Get-ChildItem -LiteralPath $m1aResolved -Force -Recurse -Attributes ReparsePoint)
    foreach ($m1aLink in $m1aLinks) {
        if (-not $m1aLink.FullName.StartsWith($m1aResolved + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Link escaped task tree.' }
        Remove-Item -LiteralPath $m1aLink.FullName -Force
    }
    $m1aBytes = (Get-ChildItem -LiteralPath $m1aResolved -File -Force -Recurse | Measure-Object Length -Sum).Sum
    Remove-Item -LiteralPath $m1aResolved -Recurse -Force
    $m1aReceipt = @{ path=$m1aResolved; bytes=$m1aBytes; gate=$m1aGate[0].id; verdict='PASS'; log_archive=(Split-Path $m1aArchive -Leaf); archive_sha256=(Get-FileHash -LiteralPath $m1aArchive -Algorithm SHA256).Hash.ToLowerInvariant() }
    $m1aReceipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $m1aLogs ('cleanup-delivery-' + $m1aName + '.json')) -Encoding utf8NoBOM
    $m1aReceipt | ConvertTo-Json -Compress
}
