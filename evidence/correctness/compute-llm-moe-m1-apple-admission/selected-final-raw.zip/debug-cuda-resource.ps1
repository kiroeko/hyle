$ErrorActionPreference = 'Stop'
. .\scripts\hyle-windows.ps1 -Action Build -Preset windows-ninja -BinaryDir 'C:\hyle-scratch\m1a-schema' -ExtraArgs @('--target','help') > .scratch/validation/m1-apple-admission/debug-environment.log 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -X utf8 .scratch/validation/m1-apple-admission/debug-cuda-resource.py
exit $LASTEXITCODE
