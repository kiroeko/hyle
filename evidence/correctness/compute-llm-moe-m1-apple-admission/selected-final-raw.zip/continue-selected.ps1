$ErrorActionPreference = 'Stop'
$m1aRoot = 'C:\public\project-hyle\hyle'
$m1aLogs = Join-Path $m1aRoot '.scratch\validation\m1-apple-admission'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:MAX_JOBS = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
$env:Path = 'C:\public\tools\glslang;C:\public\tools\hyle-vulkan\1.4.357.0\Bin;' + $env:Path
. (Join-Path $m1aRoot 'scripts\hyle-windows.ps1') -Action Build -Preset windows-ninja -BinaryDir 'C:\hyle-scratch\m1a-schema' -ExtraArgs @('--target','help') > (Join-Path $m1aLogs 'continued-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python -X utf8 .scratch/validation/m1-apple-admission/continue-selected.py > (Join-Path $m1aLogs 'continued-run.log') 2>&1
exit $LASTEXITCODE
