"""M1-A only: ordinary Apple Direct/Graph source, relocated static/shared SDKs.

Adapted from the completed M1-R consumer journey; no central tooling changes.
All product and consumer files come from the canonical Windows snapshot.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

task = Path(sys.argv[1]).resolve()
machine = sys.argv[2]
assert machine in ('air', 'mini') and task == Path('/Users/kiro/hyle-m1a')
source = task / 'source'
root = task / 'sdk'
logs = root / 'logs'
logs.mkdir(parents=True, exist_ok=True)
manifest_path = task / 'product-worktree-manifest.json'
manifest = json.loads(manifest_path.read_text())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
environment = dict(os.environ)
environment.update(CMAKE_BUILD_PARALLEL_LEVEL='2', TRACY_ONLY_LOCALHOST='1')
environment['PATH'] = ('/Users/kiro/hyle-verify-tools/metal-17F109/shim:'
                       '/opt/homebrew/bin:/Users/kiro/hyle-verify-tools/bin:'
                       '/usr/bin:/bin:/usr/sbin:/sbin')
environment['HYLE_DEP_SOURCE_CACHE'] = '/Users/kiro/Library/Caches/hyle/dependencies/v1'
flags = ['-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=/usr/bin/c++',
         '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4', '-DHYLE_STATIC=ON',
         '-DHYLE_WERROR=ON', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_BUILD_TESTS=OFF',
         '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF',
         '-DHYLE_COMPUTE_APPLE=ON', '-DHYLE_COMPUTE_VULKAN=OFF',
         '-DHYLE_COMPUTE_ONEDNN=OFF', '-DFETCHCONTENT_UPDATES_DISCONNECTED=ON']
report = {'base': manifest['base'], 'snapshot_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
          'machine': machine, 'status': 'RUNNING', 'commands': [], 'cleaned': []}
record = logs / 'receipt.json'

def save():
    record.write_text(json.dumps(report, indent=2) + '\n')

def run(name, argv):
    print('RUN ' + name, flush=True)
    log = logs / (name + '.log')
    with log.open('wb') as out:
        result = subprocess.run(argv, stdout=out, stderr=subprocess.STDOUT, env=environment)
    report['commands'].append({'name': name, 'argv': argv, 'exit_code': result.returncode,
                               'log': log.name, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    if result.returncode:
        report['status'] = 'FAIL'
    save()
    if result.returncode:
        print(log.read_text(errors='replace')[-7000:], flush=True)
        raise SystemExit(result.returncode)

def safe_child(path):
    assert not path.is_symlink() and path.resolve() != root and root in path.resolve().parents
    return path

def remove_build(path):
    safe_child(path)
    shutil.copy2(path / 'CMakeCache.txt', logs / (path.name + '-CMakeCache.txt'))
    shutil.rmtree(path)
    report['cleaned'].append(str(path))
    save()

def consumer(directory, embedded):
    directory.mkdir(exist_ok=True)
    cmake = ['cmake_minimum_required(VERSION 3.25)', 'project(hyle_m1a_consumers LANGUAGES CXX)']
    if embedded:
        cmake += ['set(HYLE_COMPONENTS graph)', 'set(HYLE_INSTALL OFF)',
                  'add_subdirectory("' + source.as_posix() + '" hyle)']
    else:
        cmake += ['find_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)']
    cmake += ['enable_testing()']
    for component in ('compute', 'graph'):
        dest = directory / component / 'cpp'
        shutil.copytree(source / 'samples/package' / component / 'cpp', dest)
        name = 'm1a_' + component
        cmake += ['add_executable(' + name + ' ' + component + '/cpp/main.cc)',
                  'target_compile_features(' + name + ' PRIVATE cxx_std_23)',
                  'target_link_libraries(' + name + ' PRIVATE hyle::' + component + ')',
                  'hyle_stage_runtime_dependencies(' + name + ')',
                  'hyle_stage_apple_runtime(' + name + ')',
                  'add_test(NAME ' + name + ' COMMAND ' + name + ')']
    (directory / 'CMakeLists.txt').write_text('\n'.join(cmake) + '\n')

save()
parent, build = root / 'source-consumer', root / 'source-build'
consumer(parent, True)
run('source-configure', ['cmake', '-S', str(parent), '-B', str(build), '-G', 'Ninja', *flags])
run('source-build', ['cmake', '--build', str(build), '--parallel', '2'])
run('source-test', ['ctest', '--test-dir', str(build), '--verbose', '--no-tests=error', '--timeout', '180'])
remove_build(build)

for linkage in ('shared', 'static'):
    producer = safe_child(root / (linkage + '-producer'))
    staging = safe_child(root / (linkage + '-staging'))
    relocated = safe_child(root / (linkage + '-relocated'))
    hidden = safe_child(root / (linkage + '-producer-unavailable'))
    assert not relocated.exists() and not hidden.exists(), 'completed SDK must not be overwritten'
    run(linkage + '-configure', ['cmake', '-S', str(source), '-B', str(producer), '-G', 'Ninja', *flags,
        '-DHYLE_COMPONENTS=graph', '-DHYLE_INSTALL=ON', '-DCMAKE_INSTALL_PREFIX=' + str(staging),
        '-DHYLE_STATIC=' + ('ON' if linkage == 'static' else 'OFF')])
    run(linkage + '-build', ['cmake', '--build', str(producer), '--parallel', '2'])
    run(linkage + '-install', ['cmake', '--install', str(producer)])
    assert (staging / 'share/licenses/Hyle/ggml-runtime-LICENSE').is_file()
    assert (staging / 'include/hyle/compute/apple.h').is_file()
    assert not list((staging / 'include').rglob('native_program.h'))
    assert not list((staging / 'include').rglob('ggml-metal*.h'))
    if linkage == 'shared':
        library = staging / 'lib/libhyle_compute_ggml_runtime.dylib'
        run('shared-native-symbols', ['nm', '-gjU', str(library)])
        assert not any(line.startswith('_ggml_') for line in
                       (logs / 'shared-native-symbols.log').read_text().splitlines())
    staging.rename(relocated)
    producer.rename(hidden)
    (logs / (linkage + '-installed-files.txt')).write_text('\n'.join(sorted(
        p.relative_to(relocated).as_posix() for p in relocated.rglob('*') if p.is_file())) + '\n')
    parent, build = root / (linkage + '-consumer'), root / (linkage + '-consumer-build')
    consumer(parent, False)
    # Consumer sources are independent copies. Neither the producer's source nor
    # its original build path is available during configure/link/run.
    hidden_source = task / 'source-unavailable-for-sdk'
    assert not hidden_source.exists()
    source.rename(hidden_source)
    try:
        run(linkage + '-consumer-configure', ['cmake', '-S', str(parent), '-B', str(build), '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(relocated),
            '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4', '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
        run(linkage + '-consumer-build', ['cmake', '--build', str(build), '--parallel', '2'])
        run(linkage + '-relocated-test', ['ctest', '--test-dir', str(build), '--verbose',
            '--no-tests=error', '--timeout', '180'])
    finally:
        hidden_source.rename(source)
    remove_build(hidden)
    remove_build(build)
report['status'] = 'PASS'
save()
print('M1-A ' + machine + ' source/shared/static Direct+Graph PASS', flush=True)
