#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1a
export PATH=/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
cp "$task/logs/route-build.log" "$task/logs/resource-initial-build.log"
cp "$task/logs/route-tests.log" "$task/logs/resource-initial-tests.log"
tar -xzf "$task/product-worktree.tar.gz" -C "$task/source"
cmake --build "$task/native" --parallel 2 --target hyle_compute_provider_ggml_metal_tests \
  > "$task/logs/resource-retest-build.log" 2>&1
ctest --test-dir "$task/native" -R '^hyle_compute_provider_ggml_metal_test$' \
  --output-on-failure --no-tests=error --timeout 120 > "$task/logs/resource-retest.log" 2>&1
cat "$task/logs/resource-retest.log"
