#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1a
export PATH=/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
tar -xzf "$task/product-worktree.tar.gz" -C "$task/source"
# Reuse vendor artifacts and this small native build. Only HYLE targets and the
# original-source resource fixture gain host instrumentation, not the driver.
for sanitizer in asan ubsan; do
  cmake -S "$task/source" -B "$task/native" -DHYLE_SANITIZER="$sanitizer" \
    -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$task/logs/$sanitizer-configure.log" 2>&1
  cmake --build "$task/native" --parallel 2 --target hyle_compute_route_apple_tests \
    hyle_graph_route_apple_tests hyle_compute_provider_ggml_metal_tests hyle_compute_ops_tests \
    > "$task/logs/$sanitizer-build.log" 2>&1
  cp "$task/native/compile_commands.json" "$task/logs/$sanitizer-compile-commands.json"
  cp "$task/native/CMakeCache.txt" "$task/logs/$sanitizer-CMakeCache.txt"
  ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
    ctest --test-dir "$task/native" \
      -L '^(compute_route_apple|graph_route_apple|compute_provider_ggml_metal|compute_ops)$' \
      -LE headers --output-on-failure --no-tests=error --timeout 120 \
      > "$task/logs/$sanitizer-tests.log" 2>&1
  cp "$task/native/Testing/Temporary/LastTest.log" "$task/logs/$sanitizer-LastTest.log"
  cat "$task/logs/$sanitizer-tests.log"
done
