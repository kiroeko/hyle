$ErrorActionPreference = 'Stop'
$m1aRoot = 'C:\public\project-hyle\hyle'
$m1aBuild = 'C:\hyle-scratch\m1a-schema'
$m1aLogs = Join-Path $m1aRoot '.scratch\validation\m1-apple-admission'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1aRuntimeErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1aRuntimeErrorMode]::SetErrorMode(0x8003)
. (Join-Path $m1aRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'compute_ggml_runtime,compute_ops,graph_route_apple,compute_provider_ggml_metal' -BinaryDir $m1aBuild -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=ON','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') > (Join-Path $m1aLogs 'runtime-windows-configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& cmake --build $m1aBuild --parallel 2 --target hyle_compute_ggml_runtime_tests hyle_compute_ops_tests > (Join-Path $m1aLogs 'runtime-windows-build.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
foreach ($m1aDll in Get-ChildItem -LiteralPath $m1aBuild -Recurse -File -Filter '*.dll') {
  $m1aDestination = Join-Path (Join-Path $m1aBuild 'bin') $m1aDll.Name
  if ($m1aDll.FullName -ne $m1aDestination) {
    Copy-Item -LiteralPath $m1aDll.FullName -Destination $m1aDestination -Force
  }
}
& ctest --test-dir $m1aBuild -L '^(compute_ggml_runtime|compute_ops|compute_route_apple|graph_route_apple)$' --no-tests=error --output-on-failure --timeout 120 > (Join-Path $m1aLogs 'runtime-windows-tests.log') 2>&1
exit $LASTEXITCODE
