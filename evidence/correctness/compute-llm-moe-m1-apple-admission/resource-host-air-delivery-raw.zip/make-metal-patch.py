import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
upstream = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
files = {}

def edit(path, before, after):
    path = 'src/ggml-metal/' + path
    if path not in files:
        original = (upstream / path).read_text(encoding='utf-8')
        files[path] = [original, original, []]
    rec = files[path]
    assert rec[1].count(before) == 1, (path, before[:90], rec[1].count(before))
    rec[1] = rec[1].replace(before, after, 1)
    rec[2].append({'before': before, 'after': after})

def append(path, anchor, text):
    edit(path, anchor, text + '\n' + anchor)

# Original native buffer and pipeline wrappers; never remap a Metal heap as
# unrelated host storage, and never free an imported owner's payload.
append('ggml-metal-device.h', '//\n// MTLFunctionConstantValues wrapper',
       'struct ggml_metal_encoder;\nbool ggml_metal_encoder_failed(struct ggml_metal_encoder * encoder);')
append('ggml-metal-device.h', 'void   ggml_metal_buffer_free     (ggml_metal_buffer_t buf);',
       'ggml_metal_buffer_t ggml_metal_buffer_import(ggml_metal_device_t dev, void * metal);\nsize_t ggml_metal_buffer_get_size(ggml_metal_buffer_t buf);')
append('ggml-metal-device.m', 'void ggml_metal_buffer_free(ggml_metal_buffer_t buf) {', r'''
size_t ggml_metal_buffer_get_size(ggml_metal_buffer_t buf) { return buf->all_size; }

ggml_metal_buffer_t ggml_metal_buffer_import(ggml_metal_device_t dev, void * raw) {
    id<MTLBuffer> metal = (id<MTLBuffer>)raw;
    if (!metal || metal.device != dev->mtl_device ||
        metal.storageMode != MTLStorageModeShared || !metal.contents || !metal.length) return NULL;
    ggml_metal_buffer_t res = calloc(1, sizeof(struct ggml_metal_buffer));
    if (!res) return NULL;
    res->dev = dev;
    res->all_data = metal.contents;
    res->all_size = metal.length;
    res->is_shared = true;
    res->owned = false;
    res->n_buffers = 1;
    res->buffers[0].data = metal.contents;
    res->buffers[0].size = metal.length;
    res->buffers[0].metal = [metal retain];
    res->use_residency_sets = ggml_metal_device_get_props(dev)->use_residency_sets;
    if (!ggml_metal_buffer_rset_init(res)) {
        ggml_metal_buffer_rset_free(res);
        [res->buffers[0].metal release];
        free(res);
        return NULL;
    }
    ggml_metal_device_rsets_add(dev, res->rset);
    return res;
}
''')
edit('ggml-metal-device.m', '        NSError * error;\n        buf->rset',
     '        NSError * error = nil;\n        buf->rset')
edit('ggml-metal-device.m', '        if (error) {\n            GGML_LOG_ERROR("%s: error: %s\\n", __func__, [[error description] UTF8String]);\n            [desc release];',
     '        if (error || !buf->rset) {\n            GGML_LOG_ERROR("%s: residency set allocation failed\\n", __func__);\n            [desc release];')
edit('ggml-metal-device.m', 'struct ggml_metal_encoder {\n    id<MTLComputeCommandEncoder> obj;\n};',
     'struct ggml_metal_encoder {\n    id<MTLComputeCommandEncoder> obj;\n    bool failed;\n};\n\nbool ggml_metal_encoder_failed(ggml_metal_encoder_t encoder) { return !encoder || encoder->failed; }')
edit('ggml-metal-device.m', '    ggml_metal_encoder_t res = calloc(1, sizeof(struct ggml_metal_encoder));',
     '    ggml_metal_encoder_t res = calloc(1, sizeof(struct ggml_metal_encoder));\n    if (!res) return NULL;')
edit('ggml-metal-device.m', '    [res->obj retain];\n\n    return res;\n}\n\nvoid ggml_metal_encoder_free',
     '    if (!res->obj) { free(res); return NULL; }\n    [res->obj retain];\n\n    return res;\n}\n\nvoid ggml_metal_encoder_free')
edit('ggml-metal-device.m', '        GGML_ABORT("%s: nil Metal pipeline (missing kernel; see compile_pipeline log above)\\n", __func__);',
     '        encoder->failed = true;\n        return;')
edit('ggml-metal-device.m', '    [encoder->obj dispatchThreadgroups:',
     '    if (encoder->failed) return;\n    [encoder->obj dispatchThreadgroups:')

# Catch C++ encoding allocation failures before returning through a libdispatch
# callback. The original op encoder/fusion stays intact; only ownership moves
# after fallible vector construction so a failed constructor leaks no encoder.
edit('ggml-metal-ops.cpp', '#include <limits>', '#include <limits>\n#include <memory>\n#include <new>')
edit('ggml-metal-ops.cpp', '        this->enc             = ggml_metal_encoder_init(cmd_buf, use_concurrency);\n        this->mem_ranges      = ggml_mem_ranges_init(debug_graph);', '')
edit('ggml-metal-ops.cpp', '                idxs.push_back(i);\n            }\n        }\n    }',
     '                idxs.push_back(i);\n            }\n        }\n        mem_ranges = ggml_mem_ranges_init(debug_graph);\n        enc = ggml_metal_encoder_init(cmd_buf, use_concurrency);\n        if (!enc) { ggml_mem_ranges_free(mem_ranges); throw std::bad_alloc(); }\n    }')
decl = '''enum ggml_status ggml_metal_op_try_encode(
    ggml_metal_device_t dev, ggml_metal_cmd_buf_t cmd_buf,
    struct ggml_cgraph * gf, struct ggml_metal_fusion_info * finfo,
    int idx_start, int idx_end, bool concurrency, bool capture, int debug);'''
append('ggml-metal-ops.h', 'void ggml_metal_op_free(ggml_metal_op_t ctx);', decl)
append('ggml-metal-ops.cpp', 'void ggml_metal_op_free(ggml_metal_op_t ctx) {', r'''
enum ggml_status ggml_metal_op_try_encode(
    ggml_metal_device_t dev, ggml_metal_cmd_buf_t cmd_buf,
    ggml_cgraph * gf, ggml_metal_fusion_info * finfo,
    int idx_start, int idx_end, bool concurrency, bool capture, int debug) {
    try {
        std::unique_ptr<ggml_metal_op> op(ggml_metal_op_init(
            dev, cmd_buf, gf, finfo, idx_start, idx_end, concurrency, capture, debug));
        for (int idx = 0; idx < op->n_nodes(); ++idx) {
            const int count = ggml_metal_op_encode(op.get(), idx);
            if (ggml_metal_encoder_failed(op->enc)) return GGML_STATUS_FAILED;
            if (count == 0) break;
            idx += count - 1;
        }
        return GGML_STATUS_SUCCESS;
    } catch (const std::bad_alloc &) { return GGML_STATUS_ALLOC_FAILED; }
      catch (...) { return GGML_STATUS_FAILED; }
}
''')
edit('ggml-metal-context.m', 'struct ggml_metal_command_buffer {\n    id<MTLCommandBuffer> obj;\n};',
     'struct ggml_metal_command_buffer {\n    id<MTLCommandBuffer> obj;\n    enum ggml_status encode_status;\n};')
context = (upstream / 'src/ggml-metal/ggml-metal-context.m').read_text()
start = context.index('        ggml_metal_op_t ctx_op = ggml_metal_op_init(')
end = context.index('        ggml_metal_op_free(ctx_op);', start) + len('        ggml_metal_op_free(ctx_op);')
edit('ggml-metal-context.m', context[start:end], '''        ctx->cmd_bufs[cb_idx].encode_status = ggml_metal_op_try_encode(
            ctx->dev, cmd_buf, ctx->gf, ctx->finfo, idx_start, idx_end,
            ctx->use_concurrency, ctx->capture_compute, ctx->debug_graph);''')
edit('ggml-metal-context.m', '        dispatch_apply(n_cb, ctx->d_queue, ctx->encode_async);', '''        dispatch_apply(n_cb, ctx->d_queue, ctx->encode_async);
        for (int i = 0; i <= n_cb; ++i) {
            if (ctx->cmd_bufs[i].encode_status != GGML_STATUS_SUCCESS) {
                ctx->has_error = true;
                return ctx->cmd_bufs[i].encode_status;
            }
        }''')
edit('ggml-metal-context.m', '        ggml_metal_t res = calloc(1, sizeof(struct ggml_metal));',
     '        ggml_metal_t res = calloc(1, sizeof(struct ggml_metal));\n        if (!res) return NULL;')
edit('ggml-metal-context.m', '            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[n_cb].obj)',
     '            if (!cmd_buf) { ctx->has_error = true; return GGML_STATUS_ALLOC_FAILED; }\n            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[n_cb].obj)')
edit('ggml-metal-context.m', '            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[cb_idx].obj)',
     '            if (!cmd_buf) { ctx->has_error = true; return GGML_STATUS_ALLOC_FAILED; }\n            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[cb_idx].obj)')
append('ggml-metal-context.h', 'void ggml_metal_synchronize(ggml_metal_t ctx);',
       'int64_t ggml_metal_checked_sync(ggml_metal_t ctx);')
append('ggml-metal-context.m', 'void ggml_metal_graph_optimize(ggml_metal_t ctx, struct ggml_cgraph * gf) {', r'''
int64_t ggml_metal_checked_sync(ggml_metal_t ctx) {
    ggml_metal_synchronize(ctx);
    for (int i = 0; i <= ctx->n_cb; ++i) {
        id<MTLCommandBuffer> cb = ctx->cmd_bufs[i].obj;
        if (cb && cb.status == MTLCommandBufferStatusError) {
            const int64_t code = cb.error.code;
            return code ? code : -1;
        }
    }
    return ctx->has_error ? -1 : 0;
}
''')

# Internal C++ bridge exposes only original native resource/program boundaries.
append('ggml-metal.cpp', '// backend\n', '#include <new>\n')
needle = '    ggml_backend_t backend = (ggml_backend_t) malloc(sizeof(ggml_backend));'
metal_cpp = (upstream / 'src/ggml-metal/ggml-metal.cpp').read_text()
# Both original entry points allocate this wrapper. Qualify each by its body.
for function in ('ggml_backend_t ggml_backend_metal_init(void)',
                 'static ggml_backend_t ggml_backend_metal_device_init'):
    pos = metal_cpp.index(function)
    pos_end = metal_cpp.index(needle, pos) + len(needle)
    before = metal_cpp[pos:pos_end]
    edit('ggml-metal.cpp', before, before + '\n    if (!backend) { ggml_metal_free(ctx); return nullptr; }')
append('ggml-metal.cpp', '// backend registry\n', r'''
extern "C" ggml_backend_buffer_t ggml_hyle_metal_import(ggml_backend_t backend, void * raw) {
    auto dev = (ggml_metal_device_t)backend->device->context;
    auto buffer = ggml_metal_buffer_import(dev, raw);
    if (!buffer) return nullptr;
    try {
        auto result = ggml_backend_buffer_init(
            ggml_backend_metal_buffer_type_shared(ggml_metal_device_get_props(dev)->device),
            ggml_backend_metal_buffer_shared_i, buffer, ggml_metal_buffer_get_size(buffer));
        if (!result) ggml_metal_buffer_free(buffer);
        return result;
    } catch (...) { ggml_metal_buffer_free(buffer); throw; }
}
extern "C" int64_t ggml_hyle_metal_checked_sync(ggml_backend_t backend) {
    return ggml_metal_checked_sync((ggml_metal_t)backend->context);
}
extern "C" bool ggml_hyle_metal_prepare_gdn(ggml_backend_t backend, const ggml_tensor * tensor) {
    auto dev = (ggml_metal_device_t)backend->device->context;
    auto lib = ggml_metal_device_get_library(dev);
    ggml_backend_metal_set_n_cb(backend, 0);
    return lib && ggml_metal_library_get_pipeline_gated_delta_net(lib, tensor).pipeline;
}
''')

# A2: make pipeline-cache allocation failure distinct from a cache miss. No C++
# exception crosses the Objective-C lock, and a failed insertion owns nothing.
edit('ggml-metal-device.h', 'void                  ggml_metal_pipelines_add',
     'bool                  ggml_metal_pipelines_add')
edit('ggml-metal-device.h', 'ggml_metal_pipeline_t ggml_metal_pipelines_get(ggml_metal_pipelines_t ppls, const char * name);',
     'ggml_metal_pipeline_t ggml_metal_pipelines_get(ggml_metal_pipelines_t ppls, const char * name, bool * allocation_failed);')
edit('ggml-metal-device.h', '    bool c4;\n    bool cnt;',
     '    bool c4;\n    bool cnt;\n    bool allocation_failed;')
edit('ggml-metal-device.cpp', '#include <memory>', '#include <memory>\n#include <new>')
edit('ggml-metal-device.cpp', '    ggml_metal_pipelines_t res = new ggml_metal_pipelines();',
     '    ggml_metal_pipelines_t res = new (std::nothrow) ggml_metal_pipelines();')
edit('ggml-metal-device.cpp', '''void ggml_metal_pipelines_add(ggml_metal_pipelines_t ppls, const char * name, ggml_metal_pipeline_t pipeline) {
    ppls->data[name] = pipeline;
}''', '''bool ggml_metal_pipelines_add(ggml_metal_pipelines_t ppls, const char * name, ggml_metal_pipeline_t pipeline) {
    try { return ppls->data.emplace(name, pipeline).second; }
    catch (const std::bad_alloc &) { return false; }
}''')
edit('ggml-metal-device.cpp', '''ggml_metal_pipeline_t ggml_metal_pipelines_get(ggml_metal_pipelines_t ppls, const char * name) {
    if (ppls->data.find(name) == ppls->data.end()) {
        return nullptr;
    }

    return ppls->data[name];
}''', '''ggml_metal_pipeline_t ggml_metal_pipelines_get(ggml_metal_pipelines_t ppls, const char * name, bool * allocation_failed) {
    try {
        const auto it = ppls->data.find(name);
        return it == ppls->data.end() ? nullptr : it->second;
    } catch (const std::bad_alloc &) { *allocation_failed = true; return nullptr; }
}''')
# There are exactly two locked map reads, one for lookup and one before compile.
device_m = files['src/ggml-metal/ggml-metal-device.m'][1]
for signature in ('struct ggml_metal_pipeline_with_params ggml_metal_library_get_pipeline(',
                  'struct ggml_metal_pipeline_with_params ggml_metal_library_compile_pipeline('):
    start = device_m.index(signature)
    end = device_m.index('    res.pipeline = ggml_metal_pipelines_get(lib->pipelines, name);', start)
    before = device_m[start:end + len('    res.pipeline = ggml_metal_pipelines_get(lib->pipelines, name);')]
    after = before.replace('ggml_metal_pipelines_get(lib->pipelines, name)',
                           'ggml_metal_pipelines_get(lib->pipelines, name, &res.allocation_failed)')
    after = after.replace('        /*.cnt      =*/ false,',
                          '        /*.cnt      =*/ false,\n        /*.allocation_failed =*/ false,')
    after += '\n    if (res.allocation_failed) { [lib->lock unlock]; return res; }'
    edit('ggml-metal-device.m', before, after)
edit('ggml-metal-device.m', '    ggml_metal_pipeline_t res = calloc(1, sizeof(struct ggml_metal_pipeline));',
     '    ggml_metal_pipeline_t res = calloc(1, sizeof(struct ggml_metal_pipeline));\n    if (!res) return NULL;')
edit('ggml-metal-device.m', '''        res.pipeline = ggml_metal_pipeline_init();
        res.pipeline->obj = obj;

        ggml_metal_pipelines_add(lib->pipelines, name, res.pipeline);''', '''        res.pipeline = ggml_metal_pipeline_init();
        if (!res.pipeline) {
            [obj release]; [lib->lock unlock];
            res.allocation_failed = true;
            return res;
        }
        res.pipeline->obj = obj;
        if (!ggml_metal_pipelines_add(lib->pipelines, name, res.pipeline)) {
            ggml_metal_pipeline_free(res.pipeline);
            res.pipeline = NULL;
            res.allocation_failed = true;
        }''')
edit('ggml-metal-device.m', '    ggml_metal_cv_t res = calloc(1, sizeof(struct ggml_metal_cv));',
     '    ggml_metal_cv_t res = calloc(1, sizeof(struct ggml_metal_cv));\n    if (!res) return NULL;')
edit('ggml-metal-device.m', '    res->obj = [[MTLFunctionConstantValues alloc] init];',
     '    res->obj = [[MTLFunctionConstantValues alloc] init];\n    if (!res->obj) { free(res); return NULL; }')
gdn = (upstream / 'src/ggml-metal/ggml-metal-device.cpp').read_text()
start = gdn.index('ggml_metal_pipeline_with_params ggml_metal_library_get_pipeline_gated_delta_net(')
end = gdn.index('\nggml_metal_pipeline_with_params ggml_metal_library_get_pipeline_solve_tri(', start)
before = gdn[start:end]
after = before.replace('    if (!res.pipeline) {', '    if (res.allocation_failed) throw std::bad_alloc();\n    if (!res.pipeline) {')
after = after.replace('        ggml_metal_cv_t cv = ggml_metal_cv_init();',
                      '        ggml_metal_cv_t cv = ggml_metal_cv_init();\n        if (!cv) throw std::bad_alloc();')
after = after.replace('        ggml_metal_cv_free(cv);',
                      '        ggml_metal_cv_free(cv);\n        if (res.allocation_failed) throw std::bad_alloc();')
edit('ggml-metal-device.cpp', before, after)

# Cold native owners either finish constructing or release their accepted prefix.
edit('ggml-metal-device.m', '    ggml_metal_event_t ev = calloc(1, sizeof(struct ggml_metal_event));',
     '    ggml_metal_event_t ev = calloc(1, sizeof(struct ggml_metal_event));\n    if (!ev || !event) { [event release]; free(ev); return NULL; }')
edit('ggml-metal-device.m', 'void ggml_metal_device_event_free(ggml_metal_device_t dev, ggml_metal_event_t ev) {',
     'void ggml_metal_device_event_free(ggml_metal_device_t dev, ggml_metal_event_t ev) {\n    if (!ev) return;')
edit('ggml-metal-context.m', '        res->ev_cpy = ggml_metal_device_event_init(dev);',
     '        res->ev_cpy = ggml_metal_device_event_init(dev);\n        if (!res->ev_cpy) { free(res); return NULL; }')
edit('ggml-metal-context.m', '        res->d_queue = dispatch_queue_create("ggml-metal", DISPATCH_QUEUE_CONCURRENT);',
     '        res->d_queue = dispatch_queue_create("ggml-metal", DISPATCH_QUEUE_CONCURRENT);\n        if (!res->d_queue) { ggml_metal_device_event_free(dev, res->ev_cpy); free(res); return NULL; }')
edit('ggml-metal-context.m', '        res->pipelines_ext = ggml_metal_pipelines_init();',
     '        res->pipelines_ext = ggml_metal_pipelines_init();\n        if (!res->cmd_bufs_ext || !res->buf_refs || !res->pipelines_ext) { ggml_metal_free(res); return NULL; }')
# Check the original block acquisition without replacing its encoding work.
context_after = files['src/ggml-metal/ggml-metal-context.m'][1]
start = context_after.index('    ctx->encode_async = Block_copy(')
end = context_after.index('\n    });', start) + len('\n    });')
edit('ggml-metal-context.m', context_after[start:end],
     context_after[start:end] + '\n    if (!ctx->encode_async) ctx->has_error = true;')
edit('ggml-metal.cpp', '    return lib && ggml_metal_library_get_pipeline_gated_delta_net(lib, tensor).pipeline;',
     '    return lib && !ggml_metal_checked_sync((ggml_metal_t)backend->context) &&\n           ggml_metal_library_get_pipeline_gated_delta_net(lib, tensor).pipeline;')

# Library cold allocations are shared by each actual native invocation. Fail
# before launching parallel compilation when its bookkeeping cannot be owned.
edit('ggml-metal-device.m', '    NSError ** err_per_lib = calloc(GGML_METAL_LIB_COUNT, sizeof(NSError *));',
     '    NSError ** err_per_lib = calloc(GGML_METAL_LIB_COUNT, sizeof(NSError *));\n    if (!t_per_lib || !err_per_lib) { free(t_per_lib); free(err_per_lib); return false; }')
edit('ggml-metal-device.m', '    dispatch_group_t group = dispatch_group_create();',
     '    dispatch_group_t group = dispatch_group_create();\n    if (!group) { free(t_per_lib); free(err_per_lib); return false; }')
edit('ggml-metal-device.m', '''    ggml_metal_library_t res = calloc(1, sizeof(struct ggml_metal_library));
    res->dev''', '''    ggml_metal_library_t res = calloc(1, sizeof(struct ggml_metal_library));
    if (!res) return NULL;
    res->dev''')
edit('ggml-metal-device.m', '    res->lock      = [NSLock new];',
     '    res->lock      = [NSLock new];\n    if (!res->pipelines || !res->lock) { ggml_metal_library_free(res); return NULL; }')
edit('ggml-metal-device.m', '        GGML_LOG_ERROR("%s: calloc failed\\n", __func__);\n        return NULL;',
     '        GGML_LOG_ERROR("%s: calloc failed\\n", __func__);\n        [library release];\n        return NULL;')
edit('ggml-metal-device.m', '    res->lock           = [NSLock new];',
     '    res->lock           = [NSLock new];\n    if (!res->pipelines || !res->lock) { ggml_metal_library_free(res); return NULL; }')

# Reserve registry containers before creating their process-lifetime device.
# A failed bootstrap does not publish a partial registry or orphan an owner.
edit('ggml-metal-device.cpp', '    devs.emplace_back(ggml_metal_device_init(device, n_devices));',
     '    devs.reserve(devs.size() + 1);\n    ggml_metal_device_ptr owner(ggml_metal_device_init(device, n_devices));\n    if (!owner) throw std::bad_alloc();\n    devs.push_back(std::move(owner));')
edit('ggml-metal.cpp', '''            for (int i = 0; i < g_devices; ++i) {
                auto * dev = ggml_backend_metal_device_init(&reg, i);''', '''            devs.reserve(g_devices);
            reg_ctx->devices.reserve(g_devices);
            for (int i = 0; i < g_devices; ++i) {
                auto * dev = ggml_backend_metal_device_init(&reg, i);''')
edit('ggml-metal-device.m', '    ggml_metal_device_t dev = calloc(1, sizeof(struct ggml_metal_device));\n\n    assert(dev != NULL);',
     '    ggml_metal_device_t dev = calloc(1, sizeof(struct ggml_metal_device));\n    if (!dev) return NULL;')
edit('ggml-metal-device.m', '                    GGML_LOG_ERROR("%s: error: failed to create command queue\\n", __func__);',
     '                    GGML_LOG_ERROR("%s: error: failed to create command queue\\n", __func__);\n                    ggml_metal_device_free(dev); return NULL;')
edit('ggml-metal-device.m', '                            val ? atoi(val) : 0);\n                }',
     '                            val ? atoi(val) : 0);\n                    if (!dev->finfo) { ggml_metal_device_free(dev); return NULL; }\n                }')
edit('ggml-metal-device.m', '                    GGML_LOG_ERROR("%s: error: failed to create library\\n", __func__);',
     '                    GGML_LOG_ERROR("%s: error: failed to create library\\n", __func__);\n                    ggml_metal_device_free(dev); return NULL;')
edit('ggml-metal-device.m', '                    dev->rsets = ggml_metal_rsets_init(dev);',
     '                    dev->rsets = ggml_metal_rsets_init(dev);\n                    if (!dev->rsets) { ggml_metal_device_free(dev); return NULL; }')
edit('ggml-metal-device.m', '    ggml_metal_rsets_t res = calloc(1, sizeof(struct ggml_metal_rsets));',
     '    ggml_metal_rsets_t res = calloc(1, sizeof(struct ggml_metal_rsets));\n    if (!res) return NULL;')
edit('ggml-metal-device.m', '    res->data = [[NSMutableArray alloc] init];',
     '    res->data = [[NSMutableArray alloc] init];\n    if (!res->lock || !res->data) { [res->lock release]; [res->data release]; free(res); return NULL; }')
edit('ggml-metal-device.m', '    res->d_group = dispatch_group_create();',
     '    res->d_group = dispatch_group_create();\n    if (!res->d_group) { [res->lock release]; [res->data release]; free(res); return NULL; }')
fusion = (upstream / 'src/ggml-metal/ggml-metal-fusion.cpp').read_text()
start = fusion.index('struct ggml_metal_fusion_info * ggml_metal_fusion_info_init(bool enabled, int debug) {')
end = fusion.index('\nvoid ggml_metal_fusion_info_free(', start)
before = fusion[start:end]
after = before.replace('    ggml_metal_fusion_info * finfo = new ggml_metal_fusion_info;',
                       '    ggml_metal_fusion_info * finfo = nullptr;\n    try {\n    finfo = new ggml_metal_fusion_info;')
after = after.replace('    return finfo;\n}',
                       '    return finfo;\n    } catch (const std::bad_alloc &) { delete finfo; return nullptr; }\n}')
edit('ggml-metal-fusion.cpp', before, after)
append('ggml-metal-fusion.cpp', '#include "ggml-metal-fusion.h"', '#include <new>')

records = []
for path, (before, after, edits) in files.items():
    records.append({'path': path,
                    'before_sha256': hashlib.sha256(before.encode()).hexdigest(),
                    'after_sha256': hashlib.sha256(after.encode()).hexdigest(),
                    'edits': edits})
manifest = {'upstream_revision': '456172ec733a135778adcd32d00e576a58232e45', 'files': records}
(root / 'third_party/ggml_runtime/metal-patches.json').write_bytes(
    (json.dumps(manifest, indent=2) + '\n').encode())
print('Metal native resource patches:', len(records), 'files')
