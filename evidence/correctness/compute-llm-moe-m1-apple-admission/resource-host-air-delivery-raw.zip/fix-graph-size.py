import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
path = root / 'third_party/ggml_runtime/patches.json'
manifest = json.loads(path.read_text())
record = next(item for item in manifest['files'] if item['path'] == 'src/ggml.c')
data = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml.c').read_bytes().replace(b'\r\n', b'\n')
assert hashlib.sha256(data).hexdigest() == record['before_sha256']
for edit in record['edits']:
    assert data.count(edit['before'].encode()) == 1
    data = data.replace(edit['before'].encode(), edit['after'].encode())
assert hashlib.sha256(data).hexdigest() == record['after_sha256']
before = '    *p = (void *) ((char *) ptr + size);'
after = '    *p = (void *) ((uintptr_t) ptr + size); // also used with zero for size-only layout'
assert data.count(before.encode()) == 1
data = data.replace(before.encode(), after.encode())
record['edits'].append({'before': before, 'after': after})
record['after_sha256'] = hashlib.sha256(data).hexdigest()
path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
