import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
path = root / 'cmake/HyleDependencyLock.json'
original = path.read_text(encoding='utf-8')
lock = json.loads(original)
for dep in lock['dependencies']:
    if dep['name'] != 'ggml_runtime_patches':
        continue
    vendor = root / dep['vendored']['path']
    manifest = ''
    for item in sorted((p for p in vendor.rglob('*') if p.is_file()),
                       key=lambda p: p.relative_to(vendor).as_posix()):
        digest = hashlib.sha256(item.read_bytes().replace(b'\r\n', b'\n')).hexdigest()
        manifest += item.relative_to(vendor).as_posix() + '|' + digest + '\n'
    prior = dep['vendored']['tree_sha256']
    current = hashlib.sha256(manifest.encode()).hexdigest()
    if prior != current:
        assert original.count(prior) == 1
        original = original.replace(prior, current)
    for item in dep['license']['files']:
        current = hashlib.sha256((root / item['path']).read_bytes().replace(b'\r\n', b'\n')).hexdigest()
        if item['sha256'] != current:
            assert original.count(item['sha256']) == 1
            original = original.replace(item['sha256'], current)
path.write_bytes(original.encode())
