$ErrorActionPreference = 'Stop'
$appleRoot = 'C:\public\project-hyle\hyle'
$appleBuild = 'C:\hyle-scratch\m1a-schema'
$appleLogs = Join-Path $appleRoot '.scratch\validation\m1-apple-admission'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1aErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1aErrorMode]::SetErrorMode(0x8003)
. (Join-Path $appleRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'graph_route_apple,compute_provider_ggml_metal' -BinaryDir $appleBuild -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=ON','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') > (Join-Path $appleLogs 'off-windows-configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& ctest --test-dir $appleBuild -R '^hyle_(compute_ops|compute_route_apple|graph_route_apple)_header_self_contained_test$' --no-tests=error --output-on-failure --timeout 60 > (Join-Path $appleLogs 'off-windows-tests.log') 2>&1
exit $LASTEXITCODE
