import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
upstream = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
files = {}

def edit(path, before, after):
    path = 'src/ggml-metal/' + path
    if path not in files:
        original = (upstream / path).read_text(encoding='utf-8')
        files[path] = [original, original, []]
    rec = files[path]
    assert rec[1].count(before) == 1, (path, before[:90], rec[1].count(before))
    rec[1] = rec[1].replace(before, after, 1)
    rec[2].append({'before': before, 'after': after})

def append(path, anchor, text):
    edit(path, anchor, text + '\n' + anchor)

# Original native buffer and pipeline wrappers; never remap a Metal heap as
# unrelated host storage, and never free an imported owner's payload.
append('ggml-metal-device.h', '//\n// MTLFunctionConstantValues wrapper',
       'struct ggml_metal_encoder;\nbool ggml_metal_encoder_failed(struct ggml_metal_encoder * encoder);')
append('ggml-metal-device.h', 'void   ggml_metal_buffer_free     (ggml_metal_buffer_t buf);',
       'ggml_metal_buffer_t ggml_metal_buffer_import(ggml_metal_device_t dev, void * metal);\nsize_t ggml_metal_buffer_get_size(ggml_metal_buffer_t buf);')
append('ggml-metal-device.m', 'void ggml_metal_buffer_free(ggml_metal_buffer_t buf) {', r'''
size_t ggml_metal_buffer_get_size(ggml_metal_buffer_t buf) { return buf->all_size; }

ggml_metal_buffer_t ggml_metal_buffer_import(ggml_metal_device_t dev, void * raw) {
    id<MTLBuffer> metal = (id<MTLBuffer>)raw;
    if (!metal || metal.device != dev->mtl_device ||
        metal.storageMode != MTLStorageModeShared || !metal.contents || !metal.length) return NULL;
    ggml_metal_buffer_t res = calloc(1, sizeof(struct ggml_metal_buffer));
    if (!res) return NULL;
    res->dev = dev;
    res->all_data = metal.contents;
    res->all_size = metal.length;
    res->is_shared = true;
    res->owned = false;
    res->n_buffers = 1;
    res->buffers[0].data = metal.contents;
    res->buffers[0].size = metal.length;
    res->buffers[0].metal = [metal retain];
    res->use_residency_sets = ggml_metal_device_get_props(dev)->use_residency_sets;
    if (!ggml_metal_buffer_rset_init(res)) {
        ggml_metal_buffer_rset_free(res);
        [res->buffers[0].metal release];
        free(res);
        return NULL;
    }
    ggml_metal_device_rsets_add(dev, res->rset);
    return res;
}
''')
edit('ggml-metal-device.m', '        NSError * error;\n        buf->rset',
     '        NSError * error = nil;\n        buf->rset')
edit('ggml-metal-device.m', '        if (error) {\n            GGML_LOG_ERROR("%s: error: %s\\n", __func__, [[error description] UTF8String]);\n            [desc release];',
     '        if (error || !buf->rset) {\n            GGML_LOG_ERROR("%s: residency set allocation failed\\n", __func__);\n            [desc release];')
edit('ggml-metal-device.m', 'struct ggml_metal_encoder {\n    id<MTLComputeCommandEncoder> obj;\n};',
     'struct ggml_metal_encoder {\n    id<MTLComputeCommandEncoder> obj;\n    bool failed;\n};\n\nbool ggml_metal_encoder_failed(ggml_metal_encoder_t encoder) { return !encoder || encoder->failed; }')
edit('ggml-metal-device.m', '    ggml_metal_encoder_t res = calloc(1, sizeof(struct ggml_metal_encoder));',
     '    ggml_metal_encoder_t res = calloc(1, sizeof(struct ggml_metal_encoder));\n    if (!res) return NULL;')
edit('ggml-metal-device.m', '    [res->obj retain];\n\n    return res;\n}\n\nvoid ggml_metal_encoder_free',
     '    if (!res->obj) { free(res); return NULL; }\n    [res->obj retain];\n\n    return res;\n}\n\nvoid ggml_metal_encoder_free')
edit('ggml-metal-device.m', '        GGML_ABORT("%s: nil Metal pipeline (missing kernel; see compile_pipeline log above)\\n", __func__);',
     '        encoder->failed = true;\n        return;')
edit('ggml-metal-device.m', '    [encoder->obj dispatchThreadgroups:',
     '    if (encoder->failed) return;\n    [encoder->obj dispatchThreadgroups:')

# Catch C++ encoding allocation failures before returning through a libdispatch
# callback. The original op encoder/fusion stays intact; only ownership moves
# after fallible vector construction so a failed constructor leaks no encoder.
edit('ggml-metal-ops.cpp', '#include <limits>', '#include <limits>\n#include <memory>\n#include <new>')
edit('ggml-metal-ops.cpp', '        this->enc             = ggml_metal_encoder_init(cmd_buf, use_concurrency);\n        this->mem_ranges      = ggml_mem_ranges_init(debug_graph);', '')
edit('ggml-metal-ops.cpp', '                idxs.push_back(i);\n            }\n        }\n    }',
     '                idxs.push_back(i);\n            }\n        }\n        mem_ranges = ggml_mem_ranges_init(debug_graph);\n        enc = ggml_metal_encoder_init(cmd_buf, use_concurrency);\n        if (!enc) { ggml_mem_ranges_free(mem_ranges); throw std::bad_alloc(); }\n    }')
decl = '''enum ggml_status ggml_metal_op_try_encode(
    ggml_metal_device_t dev, ggml_metal_cmd_buf_t cmd_buf,
    struct ggml_cgraph * gf, struct ggml_metal_fusion_info * finfo,
    int idx_start, int idx_end, bool concurrency, bool capture, int debug);'''
append('ggml-metal-ops.h', 'void ggml_metal_op_free(ggml_metal_op_t ctx);', decl)
append('ggml-metal-ops.cpp', 'void ggml_metal_op_free(ggml_metal_op_t ctx) {', r'''
enum ggml_status ggml_metal_op_try_encode(
    ggml_metal_device_t dev, ggml_metal_cmd_buf_t cmd_buf,
    ggml_cgraph * gf, ggml_metal_fusion_info * finfo,
    int idx_start, int idx_end, bool concurrency, bool capture, int debug) {
    try {
        std::unique_ptr<ggml_metal_op> op(ggml_metal_op_init(
            dev, cmd_buf, gf, finfo, idx_start, idx_end, concurrency, capture, debug));
        for (int idx = 0; idx < op->n_nodes(); ++idx) {
            const int count = ggml_metal_op_encode(op.get(), idx);
            if (ggml_metal_encoder_failed(op->enc)) return GGML_STATUS_FAILED;
            if (count == 0) break;
            idx += count - 1;
        }
        return GGML_STATUS_SUCCESS;
    } catch (const std::bad_alloc &) { return GGML_STATUS_ALLOC_FAILED; }
      catch (...) { return GGML_STATUS_FAILED; }
}
''')
edit('ggml-metal-context.m', 'struct ggml_metal_command_buffer {\n    id<MTLCommandBuffer> obj;\n};',
     'struct ggml_metal_command_buffer {\n    id<MTLCommandBuffer> obj;\n    enum ggml_status encode_status;\n};')
context = (upstream / 'src/ggml-metal/ggml-metal-context.m').read_text()
start = context.index('        ggml_metal_op_t ctx_op = ggml_metal_op_init(')
end = context.index('        ggml_metal_op_free(ctx_op);', start) + len('        ggml_metal_op_free(ctx_op);')
edit('ggml-metal-context.m', context[start:end], '''        ctx->cmd_bufs[cb_idx].encode_status = ggml_metal_op_try_encode(
            ctx->dev, cmd_buf, ctx->gf, ctx->finfo, idx_start, idx_end,
            ctx->use_concurrency, ctx->capture_compute, ctx->debug_graph);''')
edit('ggml-metal-context.m', '        dispatch_apply(n_cb, ctx->d_queue, ctx->encode_async);', '''        dispatch_apply(n_cb, ctx->d_queue, ctx->encode_async);
        for (int i = 0; i <= n_cb; ++i) {
            if (ctx->cmd_bufs[i].encode_status != GGML_STATUS_SUCCESS) {
                ctx->has_error = true;
                return ctx->cmd_bufs[i].encode_status;
            }
        }''')
edit('ggml-metal-context.m', '        ggml_metal_t res = calloc(1, sizeof(struct ggml_metal));',
     '        ggml_metal_t res = calloc(1, sizeof(struct ggml_metal));\n        if (!res) return NULL;')
edit('ggml-metal-context.m', '            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[n_cb].obj)',
     '            if (!cmd_buf) { ctx->has_error = true; return GGML_STATUS_ALLOC_FAILED; }\n            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[n_cb].obj)')
edit('ggml-metal-context.m', '            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[cb_idx].obj)',
     '            if (!cmd_buf) { ctx->has_error = true; return GGML_STATUS_ALLOC_FAILED; }\n            [cmd_buf retain];\n\n            if (ctx->cmd_bufs[cb_idx].obj)')
append('ggml-metal-context.h', 'void ggml_metal_synchronize(ggml_metal_t ctx);',
       'int64_t ggml_metal_checked_sync(ggml_metal_t ctx);')
append('ggml-metal-context.m', 'void ggml_metal_graph_optimize(ggml_metal_t ctx, struct ggml_cgraph * gf) {', r'''
int64_t ggml_metal_checked_sync(ggml_metal_t ctx) {
    ggml_metal_synchronize(ctx);
    for (int i = 0; i <= ctx->n_cb; ++i) {
        id<MTLCommandBuffer> cb = ctx->cmd_bufs[i].obj;
        if (cb && cb.status == MTLCommandBufferStatusError) {
            const int64_t code = cb.error.code;
            return code ? code : -1;
        }
    }
    return ctx->has_error ? -1 : 0;
}
''')

# Internal C++ bridge exposes only original native resource/program boundaries.
append('ggml-metal.cpp', '// backend\n', '#include <new>\n')
needle = '    ggml_backend_t backend = (ggml_backend_t) malloc(sizeof(ggml_backend));'
metal_cpp = (upstream / 'src/ggml-metal/ggml-metal.cpp').read_text()
# Both original entry points allocate this wrapper. Qualify each by its body.
for function in ('ggml_backend_t ggml_backend_metal_init(void)',
                 'static ggml_backend_t ggml_backend_metal_device_init'):
    pos = metal_cpp.index(function)
    pos_end = metal_cpp.index(needle, pos) + len(needle)
    before = metal_cpp[pos:pos_end]
    edit('ggml-metal.cpp', before, before + '\n    if (!backend) { ggml_metal_free(ctx); return nullptr; }')
append('ggml-metal.cpp', '// backend registry\n', r'''
extern "C" ggml_backend_buffer_t ggml_hyle_metal_import(ggml_backend_t backend, void * raw) {
    auto dev = (ggml_metal_device_t)backend->device->context;
    auto buffer = ggml_metal_buffer_import(dev, raw);
    if (!buffer) return nullptr;
    try {
        auto result = ggml_backend_buffer_init(
            ggml_backend_metal_buffer_type_shared(ggml_metal_device_get_props(dev)->device),
            ggml_backend_metal_buffer_shared_i, buffer, ggml_metal_buffer_get_size(buffer));
        if (!result) ggml_metal_buffer_free(buffer);
        return result;
    } catch (...) { ggml_metal_buffer_free(buffer); throw; }
}
extern "C" int64_t ggml_hyle_metal_checked_sync(ggml_backend_t backend) {
    return ggml_metal_checked_sync((ggml_metal_t)backend->context);
}
extern "C" bool ggml_hyle_metal_prepare_gdn(ggml_backend_t backend, const ggml_tensor * tensor) {
    auto dev = (ggml_metal_device_t)backend->device->context;
    auto lib = ggml_metal_device_get_library(dev);
    ggml_backend_metal_set_n_cb(backend, 0);
    return lib && ggml_metal_library_get_pipeline_gated_delta_net(lib, tensor).pipeline;
}
''')

records = []
for path, (before, after, edits) in files.items():
    records.append({'path': path,
                    'before_sha256': hashlib.sha256(before.encode()).hexdigest(),
                    'after_sha256': hashlib.sha256(after.encode()).hexdigest(),
                    'edits': edits})
manifest = {'upstream_revision': '456172ec733a135778adcd32d00e576a58232e45', 'files': records}
(root / 'third_party/ggml_runtime/metal-patches.json').write_bytes(
    (json.dumps(manifest, indent=2) + '\n').encode())
print('Metal native resource patches:', len(records), 'files')
