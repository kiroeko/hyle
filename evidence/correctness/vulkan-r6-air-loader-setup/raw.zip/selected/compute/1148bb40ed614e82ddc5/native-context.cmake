set(CMAKE_CXX_COMPILER [=[/usr/bin/c++]=] CACHE STRING "selector native context" FORCE)
set(CMAKE_CXX_FLAGS [=[]=] CACHE STRING "selector native context" FORCE)
set(CMAKE_CXX_FLAGS_RELEASE [=[-O3 -DNDEBUG]=] CACHE STRING "selector native context" FORCE)
