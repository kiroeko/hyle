import argparse
import os
from pathlib import Path
import signal
import sys
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=('compute', 'graph'), required=True)
args = parser.parse_args()
root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source, selected = root / 'native-a1329dd2', root / 'selected-m1'
log = selected / (args.mode + '-run-v2.log')
assert not log.exists(), 'Previous finite attempt exists; inspect before retry'
env = dict(os.environ, PATH='/opt/homebrew/bin:' + os.environ['PATH'], MACOSX_DEPLOYMENT_TARGET='14.4',
           CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1',
           DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib', VK_LOADER_LAYERS_DISABLE='~implicit~')
command = [sys.executable, 'scripts/validation-select.py', 'run', '--base', 'e4085366',
           '--candidate', '3894b72e3b4fbbda9457e2c31730e48bd0d43c49', '--context', selected / 'context.json',
           '--p1-card', selected / (args.mode + '-p1-card.json'), '--scratch', selected / args.mode,
           '--cache', selected / 'receipts', '--output', selected / (args.mode + '-result-v2.json')]
start = time.monotonic()
with log.open('w') as stream:
    process = subprocess.Popen([str(x) for x in command], cwd=source, env=env,
                               stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=3600)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        raise RuntimeError('Finite deadline; inspect retained logs and owned leases')
print(log.read_text()[-6000:], flush=True)
print('DONE', args.mode, 'exit', code, 'seconds', round(time.monotonic() - start, 2), flush=True)
raise SystemExit(code)
