
from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';win=base/'common-source-8';air=base/'native-runtime-air-1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],text=True)
w=json.loads((win/'result.json').read_bytes());a=json.loads((air/'result.json').read_bytes())
assert w['candidate']==a['candidate']==head and w['state']==a['state']=='TERMINAL_PASS'
assert len(a['stages'])==33 and all(s['exit_code']==0 for r in [w,a] for s in r['stages'])
tests=[]
for target,count in [('hyle_compute_batch_test',60),('hyle_graph_batch_test',6),('g04_g05_encoded_common_pages',25)]:
 x=E.parse(win/(target+'.xml')).getroot();assert int(x.get('tests'))==count and all(int(x.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
 tests.append(dict(target=target,tests=count,failures=0,skipped=0))
for target in ['g04_plain_pending_control','g04_encoded_pending_risks']:assert (win/(target+'.log')).read_text().count('PASS')==9
for route in ['apple','vulkan']:
 for target in ['g04_plain_native_control','g04_encoded_native_risks']:
  s=(air/(route+'-'+target+'.log')).read_text();assert 'cold create all' in s and 'exact backing cap' in s
 assert ('apple_context.cc' if route=='apple' else 'region.cc') in (air/(route+'-build.log')).read_text()
 direct=(air/(route+'-hyle_g01_native_page_'+route+'.log')).read_text()
 assert direct.count('64 topology plus runtime KV episodes')==(12 if route=='apple' else 6)
 assert '64 topology plus runtime KV episodes' in (root/f'tests/compute_batch/native_paged_{route}_consumer.cc').read_text()
for target,count in [('ce16_provider',10),('ce16_public',2)]:
 s=(air/('vulkan-'+target+'.log')).read_text();assert f'[  PASSED  ] {count} tests.' in s and '[  FAILED  ]' not in s and '[  SKIPPED ]' not in s
manifest=json.loads((air/'input-manifest.json').read_bytes());assert manifest['candidate']==head
for item in manifest['inputs']:assert sha(root/item['path'])==item['sha256'],item['path']
inputs=[dict(path=p,sha256=sha(root/p)) for p in subprocess.check_output(['git','diff','--name-only','27475a197',head],text=True).splitlines()]
artifacts=[]
for name in ['hyle_compute_batch.dll','hyle_graph_batch.dll',*[t+'.exe' for t in w['targets']]]:
 p=Path(w['build'])/'bin'/name;assert p.is_file();artifacts.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
dest=root/'evidence/correctness/inference-g06-native-runtime-lengths-source';dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in [win,air,base/'common-source-7']:
  for p in sorted(folder.iterdir()):
   if p.is_file():z.write(p,folder.name+'/'+p.name)
 for name in ['run_native_pending_source.py','native_runtime_air.py','launch_native_runtime_air.py','seal_native_runtime_source.py','native-runtime-launch-guard.json','native-runtime-plan.json']:z.write(base/name,'helpers/'+name)
 for item in inputs:z.write(root/item['path'],'source/'+item['path'])
r=dict(kind='G06_D3_APPLE_VULKAN_RUNTIME_KV_LENGTHS_SOURCE',verdict='PASS_SELECTED_NATIVE_COMMON_AND_HYBRID_SOURCE',candidate=head,
 baseline='27475a19758a8f6b841ac1fac0005f770b9fad13',windows=dict(execution=w,tests=tests,total_tests=91,pending_scenarios=18,artifacts=artifacts),
 air=dict(execution=a,binary_executions=27,setup_build_stages=6,vulkan_provider_tests=10,vulkan_public_alias_phase_tests=2,artifacts=json.loads((air/'artifacts-after-run.json').read_bytes())),source_inputs=inputs,
 raw_zip_sha256=sha(dest/'raw.zip'),input_manifest_sha256=sha(air/'input-manifest.json'),
 proven=['Actual M4 Apple12 and Vulkan6 normal Direct configurations each run64 runtime KV episodes with unchanged mixed Q-indptr, page count/offset growth and shrink, tail/page crossing, shared and reordered page IDs, empty request and original independent double oracle tolerances. Same IDs require zero metadata upload/wait, reused_native_plan must stay true; independent other-slot old output remains valid.',
 'Original64 topology changes with same-layout second replay and independent ID-only reordered oracle still pass. Apple16 long-page configurations retain that original coverage; new64 runtime KV episodes deliberately run only the12 normal Apple configurations, not the16 long variants.',
 'Both routes actual CPU/native/CPU64, encoded single/multi separate/paired producers, original reference, pending Direct/two-node Graph64, late output/multi-source/unknown/cancel/abandon and exact page permission/retirement consumers pass.',
 'Cold allocation failure now changes actual Q topology; original prepared generation remains runnable. ID-only no-injected-allocation reuse and old exact native import release/writer reacquire checks remain unchanged and pass.',
 'Vulkan provider10 original region/metadata and public2 independent alias/phase tests pass; only fixed-Q paged operations receive the host runtime request tag. Original math/vendor/shader/runtime sources unchanged.',
 'Cold-qualified Apple compiled route remains for initial lengths; per-invocation current layout uses original pure managed builder/fast API for other lengths. Program carries no shared mutable layout. Vulkan retains original graph/storage and invalidates original recording before committing changed row/offset params.'],
 setup_failures=[json.loads((base/'common-source-7/result.json').read_bytes()),json.loads((base/'native-runtime-launch-guard.json').read_bytes())],
 limits=['Finite source correctness and P0 assertions, not full G06 closure, speedup, new P1, native capture, final sanitizer/header/relocated static/shared or Windows-native GPU qualification.',
 'reused_native_plan means C++ Program/Invocation/storage reuse, not no native graph construction/opaque allocator/driver work. Apple changed-length execution builds a managed graph; Vulkan changed params require original re-encoding. Native private allocation/cost stays UNKNOWN under its original limits.',
 'No new broad/public field, native math, vendor/runtime or build-tool changes; ordinary Apple Invocation object gains no fields. Host-known lengths cause no implicit D2H; device-produced facts still use the original checked boundary.',
 'Windows launcher wrong full SHA was rejected before build; early Air launcher rejected a still-running Windows prerequisite before archive/SSH. Both setup failures remain, with unobserved elapsed UNKNOWN. Native attempt1 passed without product failures/retries.',
 'Stage and outer durations overlap. Windows build2.484s / outer47.516s; Air Apple/Vulkan builds13.426/13.242s / outer121.073s. Packaging/launch/observation gaps without a stopwatch remain UNKNOWN.',
 'Ragged dynamic extents, FI Q1/capture and final G06 gates remain; G04/G05 CUDA prefill UNRESOLVED and old costs/failures are not replaced. No CUDA/P1/profile or global build.'])
(dest/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=r['verdict'],candidate=head,windows_tests=91,pending_scenarios=18,native_binary_executions=27,provider_tests=12,receipt=str(dest/'receipt.json'))))
