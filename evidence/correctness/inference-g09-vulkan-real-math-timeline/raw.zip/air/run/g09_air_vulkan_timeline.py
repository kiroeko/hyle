from pathlib import Path
import hashlib,json,os,re,subprocess,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g09-vulkan-timeline-check-1'
parent=base/'a-cpu-vulkan/selected-graph/source-parent';build=parent.parent/'source-build'
assert not (out/'result.json').exists()
cmake=parent/'CMakeLists.txt';text=cmake.read_text();source=Path(re.search(r'add_subdirectory\("([^"]+)" hyle\)',text)[1])
assert source.resolve().is_relative_to(base.resolve())
manifest=json.loads((out/'inputs.json').read_text());os.nice(10)
env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ.get('PATH',''),OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
identity={k:subprocess.check_output(v,text=True,env=env).strip() for k,v in {'model':['sysctl','-n','hw.model'],'chip':['sysctl','-n','machdep.cpu.brand_string'],'system':['sw_vers'],'compiler':['xcrun','clang++','--version']}.items()};assert identity['model']=='Mac16,12'
r={'state':'SETUP','stages':[],'source_tree':manifest['tree'],'canonical_head':manifest['head'],'source':str(source),'max_jobs':4,'nice':os.nice(0),'identity':identity,
   'scope':'Air original Vulkan Neg calibrated CPU/native single-DAG diagnostic plus ordinary five 2-slot 65-step consumers. No P1/aggregate risk or SDK delivery verdict.'}
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
with zipfile.ZipFile(out/'source.zip') as z:
    changed=[]
    for item in manifest['files']:
        rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
        p=source/rel;assert p.resolve().is_relative_to(source.resolve())
        data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        if not p.is_file() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
    r['changed_files']=changed
(out/'original-parent-CMakeLists.txt').write_text(text)
assert 'hyle_cpu_vulkan_pipeline_trace' not in text
text+=f'\nadd_library(hyle_g09_vulkan_trace_loader SHARED "{source}/tests/graph/vulkan_pipeline_trace_loader.cc")\n'
text+='target_compile_features(hyle_g09_vulkan_trace_loader PRIVATE cxx_std_23)\ntarget_link_libraries(hyle_g09_vulkan_trace_loader PRIVATE hyle::graph ${CMAKE_DL_LIBS})\n'
text+=f'add_executable(hyle_cpu_vulkan_pipeline_trace "{source}/tests/graph/cpu_vulkan_pipeline_trace.cc")\n'
text+='target_compile_features(hyle_cpu_vulkan_pipeline_trace PRIVATE cxx_std_23)\ntarget_link_libraries(hyle_cpu_vulkan_pipeline_trace PRIVATE hyle::graph)\nhyle_stage_runtime(hyle_cpu_vulkan_pipeline_trace)\n'
cmake.write_text(text)
shader=build/'hyle/src/compute_ggml_runtime/vendor/src/ggml-vulkan/unary.comp.cpp'
match=re.search(r'const unsigned char neg_f32_data\[(\d+)\] = \{(.*?)\};',shader.read_text(),re.S);assert match
data=bytes(int(v,16) for v in re.findall(r'0x([0-9a-fA-F]+)',match[2]));assert len(data)==int(match[1])
reference=out/'original-ggml-neg-f32.spv';reference.write_bytes(data)
r['original_shader_reference']={'generated_source':str(shader),'generated_source_sha256':hashlib.sha256(shader.read_bytes()).hexdigest(),'symbol':'neg_f32_data','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def run(stage,args,timeout=1800):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(a) for a in args],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if stage in ['manifest','build'] and p.poll() is None:r.setdefault('time_extensions',[]).append({'stage':stage,'seconds':timeout,'pid':p.pid});save();continue
                p.kill();p.wait();code=124;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-16000:],flush=True);raise SystemExit(code)
ninja='/opt/homebrew/bin/ninja';targets=['hyle_g09_vulkan_trace_loader','hyle_cpu_vulkan_pipeline_trace','hyle_cpu_vulkan_pipeline']
run('manifest',[ninja,'-C',build,'build.ninja'])
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
(out/'dry-run.log').write_text(dry);r['dry_run_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<80 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry,dry
run('build',[ninja,'-C',build,'-f',preview,'-j','4',*targets])
run('ordinary-pipeline',[build/'hyle_cpu_vulkan_pipeline'],600)
run('vulkan-real-neg-timeline',[build/'hyle_cpu_vulkan_pipeline_trace','--trace',build/'libhyle_g09_vulkan_trace_loader.dylib',reference],600)
for item in manifest['files']:assert hashlib.sha256((source/item['path']).read_bytes()).hexdigest()==item['sha256'],item
p=out/'original-ggml-neg-f32.spv.actual.spv';r['derived_shader_reference']={'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
r['binaries']=[{'path':str(build/('lib'+t+'.dylib' if 'loader' in t else t)),'sha256':hashlib.sha256((build/('lib'+t+'.dylib' if 'loader' in t else t)).read_bytes()).hexdigest()} for t in targets]
for target in targets:(out/('commands-'+target+'.txt')).write_bytes(subprocess.check_output([ninja,'-C',str(build),'-t','commands',target],env=env))
r['state']='ORIGINAL_VULKAN_NEG_CALIBRATED_TIMELINE_AND_ORDINARY_CONSUMERS_PASS';save();print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
