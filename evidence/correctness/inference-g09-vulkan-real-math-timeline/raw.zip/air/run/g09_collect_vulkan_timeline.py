from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
mac=sys.platform=='darwin'
base=Path('/Users/kiro/hyle-scratch/compute-unified') if mac else Path('C:/public/project-hyle/hyle/.scratch/inference-gaps')
out=base/'g09-vulkan-timeline-check-1';r=json.loads((out/'result.json').read_text())
assert r['state']=='ORIGINAL_VULKAN_NEG_CALIBRATED_TIMELINE_AND_ORDINARY_CONSUMERS_PASS'
source=Path(r['source']) if mac else Path('C:/public/project-hyle/hyle')
units=['tests/graph/native_joint_pipeline.cc','tests/graph/cpu_vulkan_pipeline_trace.cc','tests/graph/vulkan_pipeline_trace.h',
       'tests/graph/vulkan_pipeline_trace_loader.cc','tests/graph/cpu_vulkan_contracts/CMakeLists.txt']
archive=out/'collected.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
    for p in sorted(out.iterdir()):
        if p.is_file() and p.suffix in ['.json','.log','.txt','.py','.ninja','.spv']:z.write(p,'run/'+p.name)
    for p in units:z.write(source/p,'source/'+p)
    for item in r['binaries']:
        p=Path(item['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
        z.write(p,'binary/'+p.name)
assert zipfile.ZipFile(archive).testzip() is None
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
