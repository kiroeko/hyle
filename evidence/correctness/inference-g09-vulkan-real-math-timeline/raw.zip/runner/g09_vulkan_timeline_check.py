from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,sys,time
root=Path('C:/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g09-vulkan-timeline-check-1'
out.mkdir(exist_ok=False)
build=Path('C:/h7/w-cpu-vulkan/selected-graph/source-build');parent=build.parent/'source-parent'
units=['tests/graph/cpu_vulkan_pipeline_trace.cc','tests/graph/vulkan_pipeline_trace.h','tests/graph/vulkan_pipeline_trace_loader.cc','tests/graph/native_joint_pipeline.cc','tests/graph/cpu_vulkan_contracts/CMakeLists.txt']
inputs=json.loads((root/'.scratch/inference-gaps/g09-vulkan-timeline-source/inputs.json').read_text())
r={'state':'SETUP','stages':[],'canonical_head':inputs['head'],'source_tree':inputs['tree'],'pid':os.getpid(),'max_jobs':4,'logical_cpus':4,'priority':'BELOW_NORMAL',
   'scope':'Fixed G09 same-DAG CPU Exp/GPU original ggml Neg/join actual calibrated Vulkan timestamp diagnostic, not P1 or aggregate risk/delivery acceptance.',
   'input_hashes':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in units]}
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (s.split('=',1) for s in setup.splitlines() if '=' in s and not s.startswith('=')))
env.update(VSLANG='1033',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args,timeout=1800):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(a) for a in args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,
                           creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        kernel=ctypes.windll.kernel32;handle=ctypes.c_void_p(int(p._handle));allowed=ctypes.c_size_t();system=ctypes.c_size_t()
        kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        assert kernel.GetProcessAffinityMask(handle,ctypes.byref(allowed),ctypes.byref(system))
        mask=sum([1<<i for i in range(64) if allowed.value&(1<<i)][:4]);assert kernel.SetProcessAffinityMask(handle,mask)
        r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if stage in ['manifest','build'] and p.poll() is None:
                    r.setdefault('time_extensions',[]).append({'stage':stage,'seconds':timeout,'pid':p.pid});save();continue
                p.kill();p.wait();code=124;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-16000:],flush=True);raise SystemExit(code)
cmake=parent/'CMakeLists.txt';text=cmake.read_text();(out/'original-parent-CMakeLists.txt').write_text(text)
assert 'hyle_cpu_vulkan_pipeline_trace' not in text
text+=f'\nadd_library(hyle_g09_vulkan_trace_loader SHARED "{root.as_posix()}/tests/graph/vulkan_pipeline_trace_loader.cc")\n'
text+='target_compile_features(hyle_g09_vulkan_trace_loader PRIVATE cxx_std_23)\ntarget_link_libraries(hyle_g09_vulkan_trace_loader PRIVATE hyle::graph ${CMAKE_DL_LIBS})\n'
text+=f'add_executable(hyle_cpu_vulkan_pipeline_trace "{root.as_posix()}/tests/graph/cpu_vulkan_pipeline_trace.cc")\n'
text+='target_compile_features(hyle_cpu_vulkan_pipeline_trace PRIVATE cxx_std_23)\ntarget_link_libraries(hyle_cpu_vulkan_pipeline_trace PRIVATE hyle::graph)\nhyle_stage_runtime(hyle_cpu_vulkan_pipeline_trace)\n'
cmake.write_text(text)
shader=build/'hyle/src/compute_ggml_runtime/vendor/src/ggml-vulkan/unary.comp.cpp'
text=shader.read_text();match=re.search(r'const unsigned char neg_f32_data\[(\d+)\] = \{(.*?)\};',text,re.S);assert match
data=bytes(int(v,16) for v in re.findall(r'0x([0-9a-fA-F]+)',match[2]));assert len(data)==int(match[1])
reference=out/'original-ggml-neg-f32.spv';reference.write_bytes(data)
r['original_shader_reference']={'generated_source':str(shader),'generated_source_sha256':hashlib.sha256(shader.read_bytes()).hexdigest(),'symbol':'neg_f32_data','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
targets=['hyle_g09_vulkan_trace_loader','hyle_cpu_vulkan_pipeline_trace','hyle_cpu_vulkan_pipeline']
run('manifest',['ninja','-C',build,'build.ninja'])
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace')
(out/'dry-run.log').write_text(dry);r['dry_run_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<90 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry,dry
run('build',['ninja','-C',build,'-f',preview,'-j','4',*targets])
def binary(name,extension):
    candidates=[build/(name+extension),build/'bin'/(name+extension)]
    return next(p for p in candidates if p.is_file())
run('ordinary-pipeline',[binary('hyle_cpu_vulkan_pipeline','.exe')],600)
run('vulkan-real-neg-timeline',[binary('hyle_cpu_vulkan_pipeline_trace','.exe'),'--trace',binary('hyle_g09_vulkan_trace_loader','.dll'),reference],600)
for item in r['input_hashes']:assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['binaries']=[{'path':str(binary(t,'.dll' if 'loader' in t else '.exe')),'sha256':hashlib.sha256(binary(t,'.dll' if 'loader' in t else '.exe').read_bytes()).hexdigest()} for t in targets]
for target in targets:(out/('commands-'+target+'.txt')).write_bytes(subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],env=env))
r['state']='ORIGINAL_VULKAN_NEG_CALIBRATED_TIMELINE_AND_ORDINARY_CONSUMERS_PASS';save();print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
