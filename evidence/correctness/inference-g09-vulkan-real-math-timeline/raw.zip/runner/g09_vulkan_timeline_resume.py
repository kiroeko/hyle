from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time
root=Path('C:/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g09-vulkan-timeline-check-1'
r=json.loads((out/'result.json').read_text());assert r['state']=='FAIL' and r['stage']=='vulkan-real-neg-timeline'
assert json.loads((out/'result-original-shader-unmatched.json').read_text())==r
r['stages'].append({'stage':'fp16-reference-preflight-refused','exit_code':1,'elapsed_seconds':1.6198767,
                   'reason':'Strict <8-line guard rejected an 8-edge plan: two changed fixture CXX objects, two links, three unchanged external shader-generator metadata steps and runtime staging. No build started; guard corrected to require only the two fixture CXX objects.'})
r['elapsed_seconds']+=1.6198767
inputs=json.loads((root/'.scratch/inference-gaps/g09-vulkan-fp16-reference/inputs.json').read_text())
r['source_tree_fp16_reference']=inputs['tree'];r['retained_failure']='result-original-shader-unmatched.json'
for item in r['input_hashes']:item['sha256']=hashlib.sha256((root/item['path']).read_bytes()).hexdigest()
build=Path('C:/h7/w-cpu-vulkan/selected-graph/source-build')
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (s.split('=',1) for s in setup.splitlines() if '=' in s and not s.startswith('=')))
env.update(VSLANG='1033',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
started=time.monotonic()-r['elapsed_seconds']
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args,timeout=1800):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(a) for a in args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        kernel=ctypes.windll.kernel32;handle=ctypes.c_void_p(int(p._handle));allowed=ctypes.c_size_t();system=ctypes.c_size_t()
        kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)];kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        assert kernel.GetProcessAffinityMask(handle,ctypes.byref(allowed),ctypes.byref(system));mask=sum([1<<i for i in range(64) if allowed.value&(1<<i)][:4]);assert kernel.SetProcessAffinityMask(handle,mask)
        r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if stage=='retry1-build' and p.poll() is None:r.setdefault('time_extensions',[]).append({'stage':stage,'seconds':timeout,'pid':p.pid});save();continue
                p.kill();p.wait();code=124;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-16000:],flush=True);raise SystemExit(code)
targets=['hyle_g09_vulkan_trace_loader','hyle_cpu_vulkan_pipeline_trace'];preview=out/'preview.ninja'
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace')
(out/'dry-run-fp16-reference.log').write_text(dry)
assert len(dry.splitlines())<=10 and 'Re-running CMake' not in dry and sum('Building CXX object' in s for s in dry.splitlines())==2 and 'Building CUDA object' not in dry,dry
run('retry1-build',['ninja','-C',build,'-f',preview,'-j','4',*targets])
run('retry1-vulkan-real-neg-timeline',[build/'hyle_cpu_vulkan_pipeline_trace.exe','--trace',build/'hyle_g09_vulkan_trace_loader.dll',out/'original-ggml-neg-f32.spv'],600)
for item in r['input_hashes']:assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item
p=out/'original-ggml-neg-f32.spv.actual.spv';r['derived_shader_reference']={'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
r['binaries']=[{'path':str(build/(t+'.dll' if 'loader' in t else t+'.exe')),'sha256':hashlib.sha256((build/(t+'.dll' if 'loader' in t else t+'.exe')).read_bytes()).hexdigest()} for t in targets+['hyle_cpu_vulkan_pipeline']]
for target in targets:(out/('commands-'+target+'.txt')).write_bytes(subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],env=env))
r['state']='ORIGINAL_VULKAN_NEG_CALIBRATED_TIMELINE_AND_ORDINARY_CONSUMERS_PASS';save();print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
