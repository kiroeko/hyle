from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import shutil
import subprocess

repo = Path.cwd(); candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
parent = Path('C:/h7/w-cpu-cuda/selected-graph/source-parent')
build = parent.parent / 'source-build'
root = repo / '.scratch/foundation-f3' / ('cuda-public-fixture-' + candidate[:9]); assert not root.exists(); root.mkdir()
gtest = list(Path('C:/public/tools/hyle-dependencies/v1/sources').glob('googletest-*/CMakeLists.txt'))
assert len(gtest) == 1
target = 'hyle_f3_cuda_file_risks'
file = parent / 'CMakeLists.txt'; original = file.read_text()
if target not in original:
    file.write_text(original + '\nset(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\n'
        + 'add_subdirectory("' + gtest[0].parent.as_posix() + '" f3-gtest EXCLUDE_FROM_ALL)\n'
        + 'add_executable(' + target + ' "' + (repo / 'tests/compute_route_cuda/file_stream_test.cc').as_posix() + '")\n'
        + 'target_compile_features(' + target + ' PRIVATE cxx_std_23)\n'
        + 'target_link_libraries(' + target + ' PRIVATE hyle::graph GTest::gtest_main)\n'
        + 'hyle_stage_runtime(' + target + ')\n')
spec = importlib.util.spec_from_file_location('header_env', repo / 'scripts/header-self-contained.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
compiler = 'C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'
env = module.visual_studio_environment('', 'x64', '', compiler); env['VSLANG'] = '1033'
cmake = shutil.which('cmake', path=env['PATH'])
record = {'candidate': candidate, 'product_commit': '97858fbc88a6b5a87f109290b956eeaeee632dd2',
          'scope': 'Seven original F3 CUDA public API risk fixtures with ordinary shipping CPU/CUDA source artifacts; no SDK profile toggle or global correctness roots.',
          'build': str(build), 'compiler': compiler, 'stages': []}
class MemoryStatus(ctypes.Structure):
    _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [(str(i), ctypes.c_ulonglong) for i in range(7)]
for name, command, timeout in [
    ('configure', [cmake, '-S', str(parent), '-B', str(build)], 300),
    ('build', [cmake, '--build', str(build), '--target', target, '--parallel', '4'], 1800),
    ('files', [str(build / (target + '.exe')), '--gtest_filter=CudaFileStream.*', '--gtest_output=xml:' + str(root / 'files.xml')], 120)]:
    memory = MemoryStatus(); memory.length = ctypes.sizeof(memory)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)); free = getattr(memory, '1')
    assert free >= 4 * 1024**3
    if '--parallel' in command: command[command.index('--parallel') + 1] = str(4 if free >= 12 * 1024**3 else 2 if free >= 8 * 1024**3 else 1)
    runtime = env.copy()
    if name == 'files': runtime['PATH'] = str(build) + ';C:/Windows/System32;C:/Windows'
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=root, env=runtime, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'log': log.name, 'available_bytes': free}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            process.wait(); row.update(state='terminal', verdict='TIMEOUT'); (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
record['verdict'] = 'PASS_WINDOWS_F3_CUDA_SEVEN_PUBLIC_RISKS_ONLY'
(root / 'job.json').write_text(json.dumps(record, indent=2))
