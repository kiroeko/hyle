import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source, build = root / 'native-a1329dd2', root / 'build-native-a1329dd2'
peer = root / 'peer-ggml-456172ec'
head = '8e45b10423686a0753aaa9d461c4ef3b117412c5'
logs = root / 'f32-preflight-8e45b104'
logs.mkdir(exist_ok=False)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
subprocess.run(['git', 'bundle', 'verify', str(root / 'hyle-8e45b104.bundle')], cwd=source, check=True)
subprocess.run(['git', 'fetch', str(root / 'hyle-8e45b104.bundle'), 'HEAD'], cwd=source, check=True, timeout=180)
subprocess.run(['git', 'checkout', '--detach', head], cwd=source, check=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == head
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=peer, text=True).strip() == '456172ec733a135778adcd32d00e576a58232e45'
env = os.environ.copy()
env.update(PATH='/opt/homebrew/bin:' + env['PATH'], CMAKE_BUILD_PARALLEL_LEVEL='2',
           CTEST_PARALLEL_LEVEL='1', MACOSX_DEPLOYMENT_TARGET='14.4',
           DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib',
           VK_LAYER_PATH=str(root / 'tools/vulkan-validationlayers/1.4.357.0/share/vulkan/explicit_layer.d'),
           VK_LOADER_LAYERS_DISABLE='~implicit~', HYLE_VULKAN_VALIDATION='1',
           VK_KHRONOS_VALIDATION_VALIDATE_SYNC='true',
           VK_KHRONOS_VALIDATION_DEBUG_ACTION='VK_DBG_LAYER_ACTION_LOG_MSG')
record = {'status': 'RUNNING', 'candidate': head, 'started': time.time(), 'commands': []}

def run(command, name, timeout, environment=env):
    print('RUN', name, flush=True)
    start = time.time()
    with (logs / name).open('w') as stream:
        result = subprocess.run([str(x) for x in command], cwd=source, env=environment,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
    record['commands'].append({'command': [str(x) for x in command], 'log': name,
                               'exit': result.returncode, 'seconds': time.time() - start})
    print('DONE', name, result.returncode, round(time.time() - start, 2), flush=True)
    if result.returncode:
        print((logs / name).read_text()[-6000:], flush=True)
        raise RuntimeError(name + ' failed')

try:
    run(['/opt/homebrew/bin/cmake', '-S', source, '-B', build, '-G', 'Ninja',
         '-DHYLE_BUILD_BENCH=ON', '-DHYLE_VULKAN_REFERENCE_SOURCE_DIR=' + str(peer)], 'configure.log', 240)
    run(['/opt/homebrew/bin/cmake', '--build', build, '--parallel', '2', '--target',
         'hyle_compute_route_vulkan_tests', 'hyle_graph_route_vulkan_tests',
         'hyle_compute_route_vulkan_benches', 'hyle_graph_route_vulkan_benches'], 'build.log', 600)
    run(['/opt/homebrew/bin/ctest', '--test-dir', build, '--output-on-failure', '--no-tests=error',
         '--timeout', '120', '-L', '^(compute_route_vulkan|graph_route_vulkan)$'], 'ctest.log', 300)
    shutil.copyfile(build / 'Testing/Temporary/LastTest.log', logs / 'LastTest.log')
    text = (logs / 'LastTest.log').read_text()
    assert not any(m in text for m in ('Validation Error', 'VUID-', 'SYNC-HAZARD'))
    bench_env = dict(env, HYLE_BENCH_VERIFY_ONLY='1', HYLE_PERF_APPLE_QOS='interactive')
    record['binaries'] = {}
    for target in ('hyle_compute_route_vulkan_bench', 'hyle_compute_vulkan_native_cost_bench',
                   'hyle_graph_route_vulkan_bench', 'hyle_graph_vulkan_native_cost_bench'):
        executable = build / 'bin' / target
        record['binaries'][target] = hashlib.sha256(executable.read_bytes()).hexdigest()
        run([executable], target + '.log', 180, bench_env)
        assert (logs / (target + '.log')).read_text().count('oracle=1 ') == 8
    for path in (build / 'bench/compute_route_vulkan/reference-shaders/identity.json',
                 build / 'CMakeCache.txt', build / 'compile_commands.json'):
        shutil.copyfile(path, logs / ('reference-identity.json' if path.name == 'identity.json' else path.name))
    record['status'] = 'PASS'
except Exception as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['source_unchanged'] = not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
    record['finished'] = time.time()
    (logs / 'identity.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'status': record['status'], 'source_unchanged': record['source_unchanged']}), flush=True)
