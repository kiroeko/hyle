import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source, build = root / 'native-a1329dd2', root / 'build-native-a1329dd2'
logs = root / 'f32-preflight-8e45b104'
original = json.loads((logs / 'identity.json').read_text())
assert original['status'] == 'FAIL' and 'compile_commands.json' in original['error']
assert len(original['commands']) == 7 and all(c['exit'] == 0 for c in original['commands'])
assert original['source_unchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == original['candidate']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
for name, expected in original['binaries'].items():
    assert hashlib.sha256((build / 'bin' / name).read_bytes()).hexdigest() == expected
    assert (logs / (name + '.log')).read_text().count('oracle=1 ') == 8
env = os.environ.copy()
env['PATH'] = '/opt/homebrew/bin:' + env['PATH']
with (logs / 'export-compile-commands.log').open('w') as stream:
    subprocess.run(['/opt/homebrew/bin/cmake', '-S', str(source), '-B', str(build),
                    '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'], env=env, check=True,
                    stdout=stream, stderr=subprocess.STDOUT)
for name in ('compile_commands.json', 'CMakeCache.txt'):
    shutil.copyfile(build / name, logs / name)
for name, expected in original['binaries'].items():
    assert hashlib.sha256((build / 'bin' / name).read_bytes()).hexdigest() == expected
summary = {'status': 'PASS', 'candidate': original['candidate'],
           'scope': '17 native GTests, two public-header checks, synchronization validation and four complete FFN oracle programs',
           'controller_note': 'Original controller failed only when copying missing compile_commands.json after all seven commands succeeded. Reconfigured only to export that compile inventory; no product rebuild or retest, executable hashes unchanged. Original identity.json is retained unchanged.',
           'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in logs.iterdir() if p.is_file()}}
(logs / 'verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'candidate': summary['candidate'], 'scope': summary['scope']}))
