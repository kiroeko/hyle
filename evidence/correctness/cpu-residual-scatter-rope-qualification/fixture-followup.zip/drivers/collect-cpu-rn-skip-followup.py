import hashlib,json,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
repo=Path.cwd();folder=repo/'.scratch/validation/cpu-rn/fixture-followup'
evidence=repo/'evidence/correctness/cpu-residual-scatter-rope-qualification'
result=dict(candidate='775b2bedace019de423edc5d8a6477772b8ef3ec',cause='HYLE_D5_QWEN35_FIXTURE unset; existing Windows fixture was present',platforms={})
files=[]
for platform in ('windows','linux'):
 path=folder/platform;cases=list(ET.parse(path/'previous-skips.xml').getroot().iter('testcase'))
 assert len(cases)==2 and not any(any(c.find(n) is not None for n in ('failure','error','skipped')) for c in cases)
 identity=json.loads((path/'fixture-identity.json').read_text())
 result['platforms'][platform]=dict(passed=2,skipped=0,tests=[c.attrib.get('classname','')+'.'+c.attrib['name'] for c in cases],fixture=identity)
 files.extend((p,platform+'/'+p.name) for p in path.iterdir() if p.is_file())
for name in ('cpu-rn-skips-windows.py','cpu-rn-skips-linux.py','collect-cpu-rn-skip-followup.py'):
 files.append((repo/'.scratch'/name,'drivers/'+name))
assert result['platforms']['windows']['fixture']==result['platforms']['linux']['fixture']
archive=evidence/'fixture-followup.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for path,name in sorted(files,key=lambda r:r[1]):z.write(path,name)
result['artifact']=dict(file=archive.name,entries=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(evidence/'fixture-followup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['artifact']))
