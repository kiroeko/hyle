import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/validation/cpu-rn/fixture-followup/linux';out.mkdir(parents=True,exist_ok=True)
identity=json.loads((out.parent/'windows/fixture-identity.json').read_text())
origin=repo/'.scratch/d5-qwen35-six-profile-fixture';root=Path('/root/hyle-scratch/cpu-rn-qwen-fixture').resolve()
assert root.parent==Path('/root/hyle-scratch').resolve() and root.name=='cpu-rn-qwen-fixture'
assert not root.exists(),'Refuse to overwrite an existing validation fixture'
root.mkdir()
for name,digest in identity['files'].items():
 data=(origin/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
 target=(root/name).resolve();assert target.is_relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
(root/'fixture-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(out/'fixture-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
os.environ['HYLE_D5_QWEN35_FIXTURE']=str(root);os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
args=['/root/hyle-scratch/active-cpu-z/build/bin/hyle_compute_route_cpu_test',
 '--gtest_filter=CpuDefaultContext.D5RealQwenProjectionUsesExactProfileAndReplays:CpuDefaultDirect.D5Qwen35OfficialGqaNormRopeAndAttentionUsePreparedCalls',
 '--gtest_output=xml:'+str(out/'previous-skips.xml')]
start=time.monotonic()
with (out/'previous-skips.log').open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
receipt=dict(candidate='775b2bedace019de423edc5d8a6477772b8ef3ec',args=args,returncode=r.returncode,seconds=round(time.monotonic()-start,3))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
if r.returncode:print((out/'previous-skips.log').read_text()[-5000:]);raise SystemExit(r.returncode)
assert json.loads((root/'fixture-identity.json').read_text())==identity
entries=list(root.rglob('*'));assert not any(p.is_symlink() for p in entries)
size=sum(p.stat().st_size for p in entries if p.is_file());shutil.rmtree(root)
(out/'cleanup.json').write_text(json.dumps(dict(path=str(root),logical_bytes=size,removed=not root.exists()),indent=2)+'\n')
