import hashlib
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-rn/fixture-followup/windows';out.mkdir(parents=True,exist_ok=True)
candidate='775b2bedace019de423edc5d8a6477772b8ef3ec';records=[]
fixture=repo/'.scratch/d5-qwen35-six-profile-fixture'
receipt=json.loads((fixture/'receipt.json').read_text())
wanted={'activation_1x2048.bf16','expected_out_proj_1x2048.f32',
 'tensors/model_language_model_layers_0_linear_attn_out_proj_weight.bin',
 'tensors/model_language_model_layers_3_self_attn_q_norm_weight.bin',
 'tensors/model_language_model_layers_3_self_attn_k_norm_weight.bin'}
digests={}
def visit(value):
 if isinstance(value,dict):
  if value.get('file') in wanted and 'sha256' in value:digests[value['file']]=value['sha256']
  for x in value.values():visit(x)
 elif isinstance(value,list):
  for x in value:visit(x)
visit(receipt)
for name in wanted:
 actual=hashlib.sha256((fixture/name).read_bytes()).hexdigest()
 if name in digests:assert actual==digests[name],name
 else:digests[name]=actual
(out/'fixture-identity.json').write_text(json.dumps(dict(source_id=receipt['source_id'],files=digests,matched_manifest_hashes=sorted(set(digests)&{x['file'] for x in receipt['tensors']})),indent=2)+'\n')
env['HYLE_D5_QWEN35_FIXTURE']=str(fixture)
run('previously-skipped-real-qwen-two-tests',[build/'bin/hyle_compute_route_cpu_test.exe',
 '--gtest_filter=CpuDefaultContext.D5RealQwenProjectionUsesExactProfileAndReplays:CpuDefaultDirect.D5Qwen35OfficialGqaNormRopeAndAttentionUsePreparedCalls',
 '--gtest_output=xml:'+str(out/'previous-skips.xml')])
