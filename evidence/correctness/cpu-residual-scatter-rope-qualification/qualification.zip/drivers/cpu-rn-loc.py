import json,subprocess,sys
from pathlib import Path
root=Path.cwd();out=root/'.scratch/validation/cpu-rn';candidate=json.loads((out/'manifest.json').read_text())['candidate']
paths=json.loads((root/'.scratch/validation/cpu-aten-compilation-storage/loc.json').read_text())['module']['paths']
args=[sys.executable,'-X','utf8','scripts/loc-report.py','--commit',candidate,'--module','compute-graph','--json']
for path in paths:args.extend(['--module-path',path])
with (out/'loc.json').open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.PIPE)
assert r.returncode==0,r.stderr.decode(errors='replace')
x=json.loads((out/'loc.json').read_text());m=next(m for m in x['metrics'] if m['id']=='module')
print(json.dumps(dict(candidate=candidate,code=m['code'],files=m['files'])))
