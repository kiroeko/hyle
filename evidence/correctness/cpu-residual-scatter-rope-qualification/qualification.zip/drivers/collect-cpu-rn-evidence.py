import hashlib,json,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
root=Path.cwd();fixture=root/'.scratch/validation/cpu-rn'
evidence=root/'evidence/correctness/cpu-residual-scatter-rope-qualification'
manifest=json.loads((fixture/'manifest.json').read_text())
for name,digest in manifest['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
life_inputs=json.loads((fixture/'lifecycle-inputs.json').read_text())
assert life_inputs['candidate']==manifest['candidate']
for name,digest in life_inputs['files'].items():assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
required={'configure','batch-build','provider-tests','public-header','compute_route_cpu-affected-tests','graph_route_cpu-affected-tests','life-configure','life-build','life-execute',
 *[stage+'-'+name for stage in ('shared','static') for name in ('producer-configure','producer-build','source-ordinary','install','consumer-configure','consumer-build','installed-ordinary')]}
def xml(path):
 cases=list(ET.parse(path).getroot().iter('testcase'))
 assert not any(c.find('failure') is not None or c.find('error') is not None for c in cases),path
 skipped=[dict(name=c.attrib.get('classname','')+'.'+c.attrib['name'],reason=c.find('skipped').attrib.get('message','')) for c in cases if c.find('skipped') is not None]
 return dict(registered=len(cases),passed=len(cases)-len(skipped),skipped=skipped)
result=dict(candidate=manifest['candidate'],fixture_commit=manifest['fixture_commit'],scope='RN1/RN4; mature lowp ScatterAdd and typed ATen Double-phase RoPE; no new performance WIN/LOSS',platforms={})
for platform in ('windows','linux'):
 folder=fixture/platform;records=json.loads((folder/'receipt.json').read_text());latest={r['name']:r for r in records}
 assert required<=latest.keys(),(platform,required-latest.keys())
 assert all(latest[n]['returncode']==0 for n in required),platform
 identity=json.loads((folder/'source-identity.json').read_text())
 assert identity['candidate']==manifest['candidate'] and identity['checked']==len(manifest['files'])
 cleanup=json.loads((folder/'cleanup.json').read_text(encoding='utf-8-sig'));assert all(r['removed'] for r in cleanup)
 life_cleanup=json.loads((folder/'cleanup-life.json').read_text(encoding='utf-8-sig'))
 if isinstance(life_cleanup,dict):life_cleanup=[life_cleanup]
 assert all(r['removed'] for r in life_cleanup)
 life_text=(folder/latest['life-execute']['log']).read_text()
 assert 'PASS lowp dtype=4' in life_text and 'PASS lowp dtype=5' in life_text
 result['platforms'][platform]=dict(tests={n:xml(folder/(n+'.xml')) for n in ('provider','compute_route_cpu','graph_route_cpu','header')},commands=len(records),source_identity=identity,cleanup=cleanup+life_cleanup,lowp_lifecycle=dict(passed=True,scope='alias, empty, two independent concurrent queues, changed replay, close, supplied-allocator cold OOM; native Tensor heap not fault-injected'),nonzero_records=[r for r in records if r['returncode']])
loc=json.loads((fixture/'loc.json').read_text());m=next(m for m in loc['metrics'] if m['id']=='module')
result['loc']=dict(code=m['code'],files=m['files'],commit=loc['repository']['commit'])
result['protected']=json.loads((fixture/'mature-identity.json').read_text())
files=[(p,'qualification/'+p.relative_to(fixture).as_posix()) for p in fixture.rglob('*') if p.is_file() and p.suffix!='.obj']
for name in ('cpu-rn-windows.py','cpu-rn-linux.py','cpu-rn-lifecycle-windows.py','cpu-rn-lifecycle-linux.py','setup-cpu-rn-lifecycle.py','cpu-ggml-wsl-launch.py','setup-cpu-rn-validation.py','narrow-cpu-rn-consumers.py','cleanup-cpu-rn-windows.ps1','cleanup-cpu-rn-linux.py','cleanup-cpu-rn-life-windows.ps1','cleanup-cpu-rn-life-linux.py','prepare-cpu-rn-life-cleanup.py','prepare-cpu-rn-evidence.py','collect-cpu-rn-evidence.py','cpu-rn-loc.py'):
 files.append((root/'.scratch'/name,'drivers/'+name))
for name in ('src/compute_provider_native/indexing.cc','src/compute_provider_native/aten_cpu_provider.cc','tests/compute_provider_native/aten_transformer_test.cc','tests/compute_provider_native/provider_shape_test.cc','tests/compute_provider_native/indexing_test.cc'):
 files.append((root/name,'source/'+name))
evidence.mkdir(parents=True,exist_ok=True);archive=evidence/'qualification.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for path,name in sorted(files,key=lambda r:r[1]):z.write(path,name)
result['artifact']=dict(file=archive.name,entries=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(evidence/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(candidate=result['candidate'],loc=result['loc'],artifact=result['artifact'])))
