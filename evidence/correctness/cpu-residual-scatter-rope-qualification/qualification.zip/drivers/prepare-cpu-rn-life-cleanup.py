from pathlib import Path
import hashlib,json
root=Path.cwd();fixture=root/'.scratch/validation/cpu-rn'
text=(root/'.scratch/cleanup-cpu-rn-windows.ps1').read_text()
text=text.replace("@('cpu-rn-shared-consumer', 'cpu-rn-static-consumer')","@('cpu-rn-life-consumer')")
text=text.replace('windows\\cleanup.json','windows\\cleanup-life.json').replace("$cleanupExpected = 'cpu-rn'","$cleanupExpected = 'cpu-rn/lifecycle'")
(root/'.scratch/cleanup-cpu-rn-life-windows.ps1').write_text(text,encoding='utf-8',newline='\n')
text=(root/'.scratch/cleanup-cpu-rn-linux.py').read_text()
text=text.replace("('shared-rn-consumer', 'static-rn-consumer')","('lowp-rn-life-consumer',)")
text=text.replace('cpu-rn/consumer','cpu-rn/lifecycle').replace('linux/cleanup.json','linux/cleanup-life.json')
(root/'.scratch/cleanup-cpu-rn-life-linux.py').write_text(text,encoding='utf-8',newline='\n')
files={n:hashlib.sha256((fixture/n).read_bytes()).hexdigest() for n in ('lifecycle/lifecycle.cc','lifecycle/CMakeLists.txt','numeric_reference.h')}
(fixture/'lifecycle-inputs.json').write_text(json.dumps(dict(candidate=json.loads((fixture/'manifest.json').read_text())['candidate'],files=files),indent=2)+'\n')
