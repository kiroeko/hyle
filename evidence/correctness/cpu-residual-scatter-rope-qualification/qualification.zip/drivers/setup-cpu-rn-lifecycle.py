from pathlib import Path
root=Path.cwd();fixture=root/'.scratch/validation/cpu-rn'
helpers=(fixture/'consumer.cc').read_text().split('void compare(')[0]
helpers=helpers.replace('#include "numeric_reference.h"','#include "../numeric_reference.h"\n#include "hyle/mem/stats.h"\n#include <thread>')
fault=(root/'tests/compute_provider_native/aten_transformer_test.cc').read_text().split('struct FaultAllocator final {')[1].split('\n};',1)[0]
code=helpers+'\nstruct FaultAllocator final {'+fault+'\n};\n'+r'''
void demand(bool ok,const char *why){if(!ok){std::fprintf(stderr,"FAIL %s\n",why);std::exit(4);}}
template<class T>void lifecycle(){
 auto stats=take(m::StatsAllocator::create(m::system_allocator()));
 FaultAllocator owner{.backing=stats.get()};
 {
  const std::array bindings{c::ProviderBinding{c::aten_cpu::provider(),100}};
  auto context=take(c::Context::create(c::cpu::device(),{.metadata_allocator=owner.get(),.providers=bindings}));
  const auto d=desc(half_test::data_type<T>(),{2,6}),p=desc(c::DataType::kInt64,{2}),f=desc(c::DataType::kFloat32,{2});
  const std::array ds{d,p,f};const std::array outs{d};
  const c::Operation op(c::RoPE{.rotary_dimensions=4,.sequence_axis=0});
  const auto begin=owner.attempts;
  {auto prepared=take(c::prepare(context,op,ds,outs,m::system_resource()));demand(prepared.provider().id==c::aten_cpu::kProviderId,"provider identity");}
  const auto count=owner.attempts-begin;
  for(std::size_t fail=0;fail<count;++fail){
   const auto live=stats.snapshot().live_bytes;owner.fail=owner.attempts+fail;
   auto result=c::prepare(context,op,ds,outs,m::system_resource());demand(!result&&result.error().IsResourceExhausted(),"cold prepare OOM");
   demand(stats.snapshot().live_bytes==live,"prepare rollback");owner.fail=SIZE_MAX;
  }
  auto prepared=take(c::prepare(context,op,ds,outs,m::system_resource()));
  demand(take(prepared.alias_support(0,0)).supported,"dense input0 alias");
  const auto inv_begin=owner.attempts;{auto inv=take(prepared.create_invocation());}
  const auto inv_count=owner.attempts-inv_begin;
  for(std::size_t fail=0;fail<inv_count;++fail){
   const auto live=stats.snapshot().live_bytes;owner.fail=owner.attempts+fail;
   auto result=prepared.create_invocation();demand(!result&&result.error().IsResourceExhausted(),"cold invocation OOM");
   demand(stats.snapshot().live_bytes==live,"invocation rollback");owner.fail=SIZE_MAX;
  }
  auto position=allocate(p),frequency=allocate(f);
  write<std::int64_t>(position,p,std::array<std::int64_t,2>{0,0});
  write<float>(frequency,f,std::array<float,2>{.125F,.25F});
  const auto pv=take(c::ConstTensorView::create(p,position.view())),fv=take(c::ConstTensorView::create(f,frequency.view()));
  std::array inputs{allocate(d),allocate(d)},outputs{allocate(d),allocate(d)};
  std::array inv{take(prepared.create_invocation()),take(prepared.create_invocation())};
  std::array queues{take(context.create_queue()),take(context.create_queue())};
  for(int replay=0;replay<3;++replay){
   std::array<std::vector<T>,2> values;
   for(std::size_t slot=0;slot<2;++slot){
    for(int i=0;i<12;++i)values[slot].push_back(half_test::encode<T>(double(i+replay+int(slot))));
    values[slot][4]=T::from_bits(std::is_same_v<T,hyle::simd::float16_t>?0x7c11:0x7f81);
    values[slot][10]=T::from_bits(0x8000);write<T>(inputs[slot],d,values[slot]);
   }
   std::array<hyle::Status,2> status;std::array<std::thread,2> workers;
   for(std::size_t slot=0;slot<2;++slot)workers[slot]=std::thread([&,slot]{
    const std::array in{take(c::ConstTensorView::create(d,inputs[slot].view())),pv,fv};
    const std::array out{take(c::TensorView::create(d,outputs[slot].view()))};
    auto done=inv[slot].submit(queues[slot],in,out);if(done)status[slot]=done->wait();else status[slot]=done.error();
   });
   for(auto &worker:workers)worker.join();
   for(std::size_t slot=0;slot<2;++slot){require(status[slot]);std::vector<T> actual(12);require(outputs[slot].view().read(std::as_writable_bytes(std::span(actual))));
    for(std::size_t i=0;i<actual.size();++i)demand(actual[i].bits==values[slot][i].bits,"independent replay result and tail bits");}
  }
  const std::array in{take(c::ConstTensorView::create(d,inputs[0].view())),pv,fv};
  const std::array alias{take(c::TensorView::create(d,inputs[0].view()))};
  demand(take(inv[0].submit(queues[0],in,alias)).wait().ok(),"alias execution");
  const auto empty=desc(half_test::data_type<T>(),{0,6}),ep=desc(c::DataType::kInt64,{0});
  const std::array eds{empty,ep,f};const std::array eouts{empty};
  auto eprepared=take(c::prepare(context,op,eds,eouts,m::system_resource()));auto einv=take(eprepared.create_invocation());
  auto zero=allocate(empty),zero_pos=allocate(ep),zero_out=allocate(empty);
  const std::array ein{take(c::ConstTensorView::create(empty,zero.view())),take(c::ConstTensorView::create(ep,zero_pos.view())),fv};
  const std::array eout{take(c::TensorView::create(empty,zero_out.view()))};
  require(take(einv.submit(queues[0],ein,eout)).wait());
  require(context.close());demand(!inv[0].submit(queues[0],in,alias),"close rejects retained invocation");
 }
 demand(stats.balanced(),"supplied allocator is balanced");
 std::printf("PASS lowp dtype=%d alias/empty/two concurrent queues/three changed replays/close/cold OOM\n",int(half_test::data_type<T>()));
}
int main(){lifecycle<hyle::simd::float16_t>();lifecycle<hyle::simd::bfloat16_t>();}
'''
folder=fixture/'lifecycle';folder.mkdir(exist_ok=True)
(folder/'lifecycle.cc').write_text(code,encoding='utf-8',newline='\n')
(folder/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.28)
project(cpu_rn_lifecycle LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(cpu_rn_lifecycle lifecycle.cc)
target_compile_features(cpu_rn_lifecycle PRIVATE cxx_std_23)
target_link_libraries(cpu_rn_lifecycle PRIVATE hyle::compute)
hyle_stage_runtime_dependencies(cpu_rn_lifecycle)
''',encoding='utf-8',newline='\n')
print('Prepared the two-platform lowp lifecycle consumer; product and main manifest unchanged')
