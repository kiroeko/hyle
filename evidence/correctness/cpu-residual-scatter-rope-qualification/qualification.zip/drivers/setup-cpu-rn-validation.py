from pathlib import Path
import hashlib,json,subprocess
repo=Path.cwd();old=repo/'.scratch/validation/cpu-native-numeric-retirement'
fixture=repo/'.scratch/validation/cpu-rn';fixture.mkdir(parents=True,exist_ok=True)
def write(path,data):
 path.parent.mkdir(parents=True,exist_ok=True)
 if not path.exists() or path.read_bytes()!=data:path.write_bytes(data)
source=(old/'consumer.cc').read_text().split('double activate(')[0]
source=source.replace('#include "hyle/graph/cpu.h"','#include "hyle/graph/cpu.h"\n#include "hyle/compute/providers/ggml_cpu.h"\n#include "numeric_reference.h"')
source=source.replace('Check check) {','Check check, bool allow_ggml = false) {')
source=source.replace('prepared.provider().id != c::aten_cpu::kProviderId','prepared.provider().id != c::aten_cpu::kProviderId && !(allow_ggml && prepared.provider().id == c::ggml_cpu::kProviderId)')
source=source.replace('take(compiled.report.step(i)).provider.id == c::aten_cpu::kProviderId','take(compiled.report.step(i)).provider.id == prepared.provider().id')
main=r'''
template<class T>void compare_lowp(const m::Buffer &b,const std::vector<T>&expected){
 std::vector<T> actual(expected.size());require(b.view().read(std::as_writable_bytes(std::span(actual))));
 for(std::size_t i=0;i<actual.size();++i){
  const double a=half_test::decode(actual[i]),e=half_test::decode(expected[i]);
  const double margin=std::is_same_v<T,hyle::simd::bfloat16_t>?.008:.001;
  if(!(std::abs(a-e)<=std::abs(e)*margin+1e-8)){std::fprintf(stderr,"lowp mismatch %zu %.17g %.17g\n",i,a,e);std::exit(3);}
 }
}
template<class T>void cases(){
 const auto type=half_test::data_type<T>();
 const float increment=std::is_same_v<T,hyle::simd::float16_t>?1.F/2048:1.F/512;
 for(auto index_type:{c::DataType::kInt32,c::DataType::kInt64}){
  const std::array ds{desc(type,{1}),desc(index_type,{32}),desc(type,{32})};
  journey(c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),ds,
   [&](auto &b,int seed){write<T>(b[0],ds[0],std::vector<T>{half_test::encode<T>(float(1+seed))});write<T>(b[2],ds[2],std::vector<T>(32,half_test::encode<T>(increment)));
    if(index_type==c::DataType::kInt32)write<std::int32_t>(b[1],ds[1],std::vector<std::int32_t>(32,0));else write<std::int64_t>(b[1],ds[1],std::vector<std::int64_t>(32,0));},
   [&](const auto &b,int seed){compare_lowp(b,std::vector<T>{half_test::encode<T>(float(1+seed)+32*increment)});},index_type==c::DataType::kInt32);
 }
 const std::array ds{desc(type,{1,2,1,4}),desc(c::DataType::kInt64,{2}),desc(c::DataType::kFloat32,{2})};
 journey(c::Operation(c::RoPE{.rotary_dimensions=4,.sequence_axis=1}),ds,
  [&](auto &b,int seed){std::vector<T>x;for(int i=0;i<8;++i)x.push_back(half_test::encode<T>(float(i+1+seed)));const std::array<std::int64_t,2>p{2147483651LL,-2147483651LL};const std::array<float,2>f{.125F,.25F};write<T>(b[0],ds[0],x);write<std::int64_t>(b[1],ds[1],p);write<float>(b[2],ds[2],f);},
  [&](const auto &b,int seed){std::vector<T>x;for(int row=0;row<2;++row)for(int pair=0;pair<2;++pair){const double p=row?-2147483651.:2147483651.,phase=p*(pair?.25:.125),a=row*4+pair*2+1+seed,z=a+1;x.push_back(half_test::encode<T>(a*std::cos(phase)-z*std::sin(phase)));x.push_back(half_test::encode<T>(a*std::sin(phase)+z*std::cos(phase)));}compare_lowp(b,x);});
}
int main(){cases<hyle::simd::float16_t>();cases<hyle::simd::bfloat16_t>();std::puts("PASS ordinary lowp ScatterAdd + integer Double-phase RoPE Direct/Graph/replay/close; Native unsupported domains decline");}
'''
write(fixture/'consumer.cc',(source+main).encode())
write(fixture/'numeric_reference.h',(repo/'.scratch/validation/cpu-native-final/semantic_reference.h').read_bytes())
write(fixture/'consumer/CMakeLists.txt',(old/'consumer/CMakeLists.txt').read_bytes())
for platform in ('windows','linux'):
 write(fixture/(platform+'-overlay.cmake'),(old/(platform+'-overlay.cmake')).read_text().replace('cpu-native-numeric-retirement','cpu-rn').encode())
 text=(repo/('.scratch/cpu-nd1-'+platform+'.py')).read_text().replace('cpu-native-numeric-retirement','cpu-rn').replace('cpu-nd1-','cpu-rn-').replace("+'-nd1-consumer'","+'-rn-consumer'")
 text=text.replace('CpuGraph.*:CpuDefaultGraph.*-CpuDefaultGraph.D5*','*').replace('CpuDefaultContext.*','*')
 write(repo/('.scratch/cpu-rn-'+platform+'.py'),text.encode())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
manifest=dict(candidate=head,fixture_commit=head,files={})
for name in json.loads((old/'manifest.json').read_text())['files']:
 if not name.startswith('.scratch/'):manifest['files'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
for name in ('consumer.cc','numeric_reference.h','consumer/CMakeLists.txt','windows-overlay.cmake','linux-overlay.cmake'):
 manifest['files'][(fixture/name).relative_to(repo).as_posix()]=hashlib.sha256((fixture/name).read_bytes()).hexdigest()
write(fixture/'manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
print(json.dumps(dict(candidate=head,inputs=len(manifest['files']))))
