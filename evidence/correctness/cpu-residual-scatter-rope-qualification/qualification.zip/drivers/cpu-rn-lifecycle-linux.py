import json,os,subprocess,time
from pathlib import Path
root=Path('/mnt/c/public/project-hyle/hyle');fixture=root/'.scratch/validation/cpu-rn';out=fixture/'linux'
records=json.loads((out/'receipt.json').read_text());candidate=json.loads((fixture/'manifest.json').read_text())['candidate']
life=Path('/root/hyle-scratch/cpu-ggml-isa-delivery/lowp-rn-life-consumer')
os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
def run(name,args):
 start=time.monotonic();log=out/(str(len(records)+1)+'-'+name+'.log')
 with log.open('wb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,args=list(map(str,args)),candidate=candidate,log=log.name,returncode=r.returncode,seconds=round(time.monotonic()-start,3)))
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 if r.returncode:print(log.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(r.returncode)
run('life-configure',['cmake','-S',fixture/'lifecycle','-B',life,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_PREFIX_PATH=/root/hyle-scratch/cpu-ggml-isa-delivery/shared','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('life-build',['cmake','--build',life,'--parallel','2'])
run('life-execute',[life/'cpu_rn_lifecycle'])
