from pathlib import Path
cpu='CpuDefaultContext.*:*Rope*:*Scatter*'
graph='CpuGraph.*:CpuDefaultGraph.*:*Rope*:*Scatter*-CpuDefaultGraph.D5*'
for platform in ('windows','linux'):
 p=Path('.scratch/cpu-rn-'+platform+'.py');s=p.read_text()
 s=s.replace("'--gtest_filter=*','--gtest_output=xml:'+str(out/'compute_route_cpu.xml')",repr('--gtest_filter='+cpu)+",'--gtest_output=xml:'+str(out/'compute_route_cpu.xml')")
 s=s.replace("'--gtest_filter=*','--gtest_output=xml:'+str(out/'graph_route_cpu.xml')",repr('--gtest_filter='+graph)+",'--gtest_output=xml:'+str(out/'graph_route_cpu.xml')")
 if platform=='windows':
  marker="if '--source-only' in sys.argv:"
  block=f'''if '--affected-only' in sys.argv:
 run('compute_route_cpu-affected-tests',[build/'bin/hyle_compute_route_cpu_test.exe','--gtest_filter={cpu}','--gtest_output=xml:'+str(out/'compute_route_cpu.xml')])
 run('graph_route_cpu-affected-tests',[build/'bin/hyle_graph_route_cpu_test.exe','--gtest_filter={graph}','--gtest_output=xml:'+str(out/'graph_route_cpu.xml')])
 run('shared-source-ordinary',[build/'bin/cpu_mature_consumer.exe'])
 raise SystemExit(0)
'''
  assert marker in s;s=s.replace(marker,block+marker)
 p.write_text(s,encoding='utf-8',newline='\n')
