import json, shutil
from pathlib import Path

root = Path('/root/hyle-scratch/cpu-ggml-isa-delivery').resolve(strict=True)
rows = []
for name in ('shared-rn-consumer', 'static-rn-consumer'):
    target = (root / name).resolve(strict=True)
    assert target.parent == root and target.name == name
    assert not target.is_symlink()
    assert 'cpu-rn/consumer' in (target / 'CMakeCache.txt').read_text()
    entries = list(target.rglob('*'))
    assert not any(p.is_symlink() for p in entries)
    files = [p for p in entries if p.is_file()]
    rows.append(dict(path=str(target), files=len(files), logical_bytes=sum(p.stat().st_size for p in files)))
    shutil.rmtree(target)
    rows[-1]['removed'] = not target.exists()
Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-rn/linux/cleanup.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows))
