from pathlib import Path
import hashlib,json
root=Path.cwd();fixture=root/'.scratch/validation/cpu-rn'
for suffix in ('windows.ps1','linux.py'):
 text=(root/('.scratch/cleanup-cpu-nd1-'+suffix)).read_text(encoding='utf-8')
 text=text.replace('cpu-native-numeric-retirement','cpu-rn').replace('cpu-nd1-','cpu-rn-').replace('shared-nd1-consumer','shared-rn-consumer').replace('static-nd1-consumer','static-rn-consumer')
 (root/('.scratch/cleanup-cpu-rn-'+suffix)).write_text(text,encoding='utf-8',newline='\n')
old=json.loads((root/'.scratch/validation/cpu-native-numeric-retirement/manifest.json').read_text())
unchanged={}
for name,digest in old['files'].items():
 if name.startswith(('include/hyle/simd/','src/simd/','src/compute_provider_ggml/','src/compute_provider_onednn/','src/compute_route_cpu/','src/graph_route_cpu/','src/graph_provider_onednn/')):
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
  unchanged[name]=digest
(fixture/'mature-identity.json').write_text(json.dumps(dict(unchanged=unchanged,
 scope='SIMD, ggml, oneDNN and assemblers unchanged; ATen typed RoPE and Native half Add are the changed product scope'),indent=2)+'\n')
print(json.dumps(dict(protected_inputs=len(unchanged))))
