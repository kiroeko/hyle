exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
fixture=repo/'.scratch/validation/cpu-rn';out=fixture/'windows'
records=json.loads((out/'receipt.json').read_text());candidate=json.loads((fixture/'manifest.json').read_text())['candidate']
life=Path('C:/hv/cpu-rn-life-consumer')
import sys
if '--resume-build' not in sys.argv:
 run('life-configure',['cmake','-S',fixture/'lifecycle','-B',life,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=C:/hv/cpu-ggml-isa-shared-sdk','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('life-build',['cmake','--build',life,'--parallel','2'])
run('life-execute',[life/'cpu_rn_lifecycle.exe'])
