#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "../numeric_reference.h"
#include "hyle/mem/stats.h"
#include <thread>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> value) {
  if (!value) {
    std::fprintf(stderr, "%.*s\n", int(value.error().message().size()),
                 value.error().message().data());
    std::exit(2);
  }
  return std::move(*value);
}
void require(hyle::Status value) {
  if (!value.ok()) {
    std::fprintf(stderr, "%.*s\n", int(value.message().size()),
                 value.message().data());
    std::exit(2);
  }
}
c::TensorDesc desc(c::DataType type,
                   std::initializer_list<std::int64_t> dimensions,
                   bool odd = false) {
  if (!odd)
    return take(
        c::TensorDesc::dense(type, {dimensions.begin(), dimensions.size()}));
  std::vector<std::int64_t> strides(dimensions.size());
  auto n = std::int64_t(c::data_type_size(type) + 1);
  for (std::size_t i = dimensions.size(); i-- > 0;) {
    strides[i] = n;
    n = n * dimensions.begin()[i] + 1;
  }
  return take(c::TensorDesc::strided_bytes(
      type, {dimensions.begin(), dimensions.size()}, strides));
}
m::Buffer allocate(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
std::size_t offset(const c::TensorDesc &d, std::size_t linear) {
  std::size_t out = 0;
  for (std::size_t i = d.rank(); i-- > 0;) {
    out += linear % std::size_t(d.dimensions()[i]) *
           std::size_t(d.byte_strides()[i]);
    linear /= std::size_t(d.dimensions()[i]);
  }
  return out;
}
template <class T>
void write(m::Buffer &b, const c::TensorDesc &d, std::span<const T> values) {
  std::vector<std::byte> bytes(b.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    std::memcpy(bytes.data() + offset(d, i), &values[i], sizeof(T));
  require(b.view().write(bytes));
}

struct FaultAllocator final {
  hyle::mem::AllocatorRef backing;
  std::size_t attempts = 0, fail = SIZE_MAX;
  hyle::mem::AllocatorRef get() noexcept {
    return {[](void *self, std::size_t bytes,
               std::size_t alignment) noexcept -> void * {
              auto &owner = *static_cast<FaultAllocator *>(self);
              return owner.attempts++ == owner.fail
                         ? nullptr
                         : owner.backing.allocate(bytes, alignment);
            },
            [](void *self, void *data, std::size_t bytes,
               std::size_t alignment) noexcept {
              static_cast<FaultAllocator *>(self)->backing.deallocate(
                  data, bytes, alignment);
            },
            [](void *self, void *data, std::size_t old_bytes, std::size_t bytes,
               std::size_t alignment) noexcept -> void * {
              auto &owner = *static_cast<FaultAllocator *>(self);
              return bytes != 0 && owner.attempts++ == owner.fail
                         ? nullptr
                         : owner.backing.reallocate(data, old_bytes, bytes,
                                                    alignment);
            },
            this};
  }
};

void demand(bool ok,const char *why){if(!ok){std::fprintf(stderr,"FAIL %s\n",why);std::exit(4);}}
template<class T>void lifecycle(){
 auto stats=take(m::StatsAllocator::create(m::system_allocator()));
 FaultAllocator owner{.backing=stats.get()};
 {
  const std::array bindings{c::ProviderBinding{c::aten_cpu::provider(),100}};
  auto context=take(c::Context::create(c::cpu::device(),{.metadata_allocator=owner.get(),.providers=bindings}));
  const auto d=desc(half_test::data_type<T>(),{2,6}),p=desc(c::DataType::kInt64,{2}),f=desc(c::DataType::kFloat32,{2});
  const std::array ds{d,p,f};const std::array outs{d};
  const c::Operation op(c::RoPE{.rotary_dimensions=4,.sequence_axis=0});
  const auto begin=owner.attempts;
  {auto prepared=take(c::prepare(context,op,ds,outs,m::system_resource()));demand(prepared.provider().id==c::aten_cpu::kProviderId,"provider identity");}
  const auto count=owner.attempts-begin;
  for(std::size_t fail=0;fail<count;++fail){
   const auto live=stats.snapshot().live_bytes;owner.fail=owner.attempts+fail;
   auto result=c::prepare(context,op,ds,outs,m::system_resource());demand(!result&&result.error().IsResourceExhausted(),"cold prepare OOM");
   demand(stats.snapshot().live_bytes==live,"prepare rollback");owner.fail=SIZE_MAX;
  }
  auto prepared=take(c::prepare(context,op,ds,outs,m::system_resource()));
  demand(take(prepared.alias_support(0,0)).supported,"dense input0 alias");
  const auto inv_begin=owner.attempts;{auto inv=take(prepared.create_invocation());}
  const auto inv_count=owner.attempts-inv_begin;
  for(std::size_t fail=0;fail<inv_count;++fail){
   const auto live=stats.snapshot().live_bytes;owner.fail=owner.attempts+fail;
   auto result=prepared.create_invocation();demand(!result&&result.error().IsResourceExhausted(),"cold invocation OOM");
   demand(stats.snapshot().live_bytes==live,"invocation rollback");owner.fail=SIZE_MAX;
  }
  auto position=allocate(p),frequency=allocate(f);
  write<std::int64_t>(position,p,std::array<std::int64_t,2>{0,0});
  write<float>(frequency,f,std::array<float,2>{.125F,.25F});
  const auto pv=take(c::ConstTensorView::create(p,position.view())),fv=take(c::ConstTensorView::create(f,frequency.view()));
  std::array inputs{allocate(d),allocate(d)},outputs{allocate(d),allocate(d)};
  std::array inv{take(prepared.create_invocation()),take(prepared.create_invocation())};
  std::array queues{take(context.create_queue()),take(context.create_queue())};
  for(int replay=0;replay<3;++replay){
   std::array<std::vector<T>,2> values;
   for(std::size_t slot=0;slot<2;++slot){
    for(int i=0;i<12;++i)values[slot].push_back(half_test::encode<T>(double(i+replay+int(slot))));
    values[slot][4]=T::from_bits(std::is_same_v<T,hyle::simd::float16_t>?0x7c11:0x7f81);
    values[slot][10]=T::from_bits(0x8000);write<T>(inputs[slot],d,values[slot]);
   }
   std::array<hyle::Status,2> status;std::array<std::thread,2> workers;
   for(std::size_t slot=0;slot<2;++slot)workers[slot]=std::thread([&,slot]{
    const std::array in{take(c::ConstTensorView::create(d,inputs[slot].view())),pv,fv};
    const std::array out{take(c::TensorView::create(d,outputs[slot].view()))};
    auto done=inv[slot].submit(queues[slot],in,out);if(done)status[slot]=done->wait();else status[slot]=done.error();
   });
   for(auto &worker:workers)worker.join();
   for(std::size_t slot=0;slot<2;++slot){require(status[slot]);std::vector<T> actual(12);require(outputs[slot].view().read(std::as_writable_bytes(std::span(actual))));
    for(std::size_t i=0;i<actual.size();++i)demand(actual[i].bits==values[slot][i].bits,"independent replay result and tail bits");}
  }
  const std::array in{take(c::ConstTensorView::create(d,inputs[0].view())),pv,fv};
  const std::array alias{take(c::TensorView::create(d,inputs[0].view()))};
  demand(take(inv[0].submit(queues[0],in,alias)).wait().ok(),"alias execution");
  const auto empty=desc(half_test::data_type<T>(),{0,6}),ep=desc(c::DataType::kInt64,{0});
  const std::array eds{empty,ep,f};const std::array eouts{empty};
  auto eprepared=take(c::prepare(context,op,eds,eouts,m::system_resource()));auto einv=take(eprepared.create_invocation());
  auto zero=allocate(empty),zero_pos=allocate(ep),zero_out=allocate(empty);
  const std::array ein{take(c::ConstTensorView::create(empty,zero.view())),take(c::ConstTensorView::create(ep,zero_pos.view())),fv};
  const std::array eout{take(c::TensorView::create(empty,zero_out.view()))};
  require(take(einv.submit(queues[0],ein,eout)).wait());
  require(context.close());demand(!inv[0].submit(queues[0],in,alias),"close rejects retained invocation");
 }
 demand(stats.balanced(),"supplied allocator is balanced");
 std::printf("PASS lowp dtype=%d alias/empty/two concurrent queues/three changed replays/close/cold OOM\n",int(half_test::data_type<T>()));
}
int main(){lifecycle<hyle::simd::float16_t>();lifecycle<hyle::simd::bfloat16_t>();}
