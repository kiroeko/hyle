#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "numeric_reference.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> value) {
  if (!value) {
    std::fprintf(stderr, "%.*s\n", int(value.error().message().size()),
                 value.error().message().data());
    std::exit(2);
  }
  return std::move(*value);
}
void require(hyle::Status value) {
  if (!value.ok()) {
    std::fprintf(stderr, "%.*s\n", int(value.message().size()),
                 value.message().data());
    std::exit(2);
  }
}
c::TensorDesc desc(c::DataType type,
                   std::initializer_list<std::int64_t> dimensions,
                   bool odd = false) {
  if (!odd)
    return take(
        c::TensorDesc::dense(type, {dimensions.begin(), dimensions.size()}));
  std::vector<std::int64_t> strides(dimensions.size());
  auto n = std::int64_t(c::data_type_size(type) + 1);
  for (std::size_t i = dimensions.size(); i-- > 0;) {
    strides[i] = n;
    n = n * dimensions.begin()[i] + 1;
  }
  return take(c::TensorDesc::strided_bytes(
      type, {dimensions.begin(), dimensions.size()}, strides));
}
m::Buffer allocate(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
std::size_t offset(const c::TensorDesc &d, std::size_t linear) {
  std::size_t out = 0;
  for (std::size_t i = d.rank(); i-- > 0;) {
    out += linear % std::size_t(d.dimensions()[i]) *
           std::size_t(d.byte_strides()[i]);
    linear /= std::size_t(d.dimensions()[i]);
  }
  return out;
}
template <class T>
void write(m::Buffer &b, const c::TensorDesc &d, std::span<const T> values) {
  std::vector<std::byte> bytes(b.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    std::memcpy(bytes.data() + offset(d, i), &values[i], sizeof(T));
  require(b.view().write(bytes));
}
void compare(const m::Buffer &b, std::span<const float> expected) {
  std::vector<float> x(expected.size());
  require(b.view().read(std::as_writable_bytes(std::span(x))));
  for (std::size_t i = 0; i < x.size(); ++i) {
    bool match = std::isnan(expected[i]) ? std::isnan(x[i])
                 : std::isinf(expected[i])
                     ? x[i] == expected[i]
                     : std::abs(x[i] - expected[i]) <=
                           1e-6F + std::abs(expected[i]) * 8e-5F;
    if (!match) {
      std::fprintf(stderr, "Mismatch %zu actual=%g expected=%g\n", i, x[i],
                   expected[i]);
      std::exit(3);
    }
  }
}
template <class Fill, class Check>
void journey(c::Operation op, std::span<const c::TensorDesc> inputs, Fill fill,
             Check check, bool allow_ggml = false) {
  std::vector<m::Buffer> buffers;
  for (const auto &d : inputs)
    buffers.push_back(allocate(d));
  auto context = take(c::cpu::create_context());
  auto queue = take(context.create_queue());
  const auto output = take(c::infer_single_output(op, inputs));
  auto native_context = take(c::Context::create(c::cpu::device(), c::native::provider()));
  auto declined = c::prepare(native_context, op, inputs, std::span(&output, 1), m::system_resource());
  if (declined || !declined.error().IsUnimplemented()) std::exit(9);
  auto prepared = take(c::prepare(context, op, inputs, std::span(&output, 1),
                                  m::system_resource()));
  if (prepared.provider().id != c::aten_cpu::kProviderId && !(allow_ggml && prepared.provider().id == c::ggml_cpu::kProviderId)) {
    std::fprintf(stderr, "Unqualified default carrier %.*s\n",
                 int(prepared.provider().name.size()),
                 prepared.provider().name.data());
    std::exit(4);
  }
  auto invocation = take(prepared.create_invocation());
  auto direct = allocate(output), graph_output = allocate(output);
  std::vector<c::ConstTensorView> views;
  for (std::size_t i = 0; i < inputs.size(); ++i)
    views.push_back(
        take(c::ConstTensorView::create(inputs[i], buffers[i].view())));
  const std::array destination{
      take(c::TensorView::create(output, direct.view()))};
  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> ids;
  for (const auto &d : inputs)
    ids.push_back(take(builder.input(d)));
  auto node = take(builder.add_node(op, ids));
  auto result = take(builder.result(node));
  auto final = take(builder.add(c::Copy{}, result));
  require(builder.publish(final));
  auto logical = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto gq = take(gc.create_queue());
  auto compiled = take(g::compile(logical, gc));
  const std::array only_native{c::native::kProviderId};
  g::CompileOptions restricted{};
  restricted.allowed_providers = only_native;
  if (g::compile(logical, gc, restricted)) std::exit(10);
  auto gi = take(compiled.executable.create_invocation());
  bool aten = false;
  for (std::size_t i = 0; i < compiled.report.step_count(); ++i)
    aten |=
        take(compiled.report.step(i)).provider.id == prepared.provider().id;
  if (!aten)
    std::exit(5);
  for (std::size_t i = 0; i < ids.size(); ++i)
    require(gi.bind(ids[i], views[i]));
  require(
      gi.bind(final, take(c::TensorView::create(output, graph_output.view()))));
  const std::array lanes{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(gi.prepare_replay(lanes));
  for (int replay = 0; replay < 2; ++replay) {
    fill(buffers, replay);
    require(take(invocation.submit(queue, views, destination)).wait());
    require(take(gi.submit(gq)).wait());
    check(direct, replay);
    check(graph_output, replay);
  }
  require(context.close());
  require(gc.close());
  if (invocation.submit(queue, views, destination) || gi.submit(gq))
    std::exit(6);
}


template<class T>void compare_lowp(const m::Buffer &b,const std::vector<T>&expected){
 std::vector<T> actual(expected.size());require(b.view().read(std::as_writable_bytes(std::span(actual))));
 for(std::size_t i=0;i<actual.size();++i){
  const double a=half_test::decode(actual[i]),e=half_test::decode(expected[i]);
  const double margin=std::is_same_v<T,hyle::simd::bfloat16_t>?.008:.001;
  if(!(std::abs(a-e)<=std::abs(e)*margin+1e-8)){std::fprintf(stderr,"lowp mismatch %zu %.17g %.17g\n",i,a,e);std::exit(3);}
 }
}
template<class T>void cases(){
 const auto type=half_test::data_type<T>();
 const float increment=std::is_same_v<T,hyle::simd::float16_t>?1.F/2048:1.F/512;
 for(auto index_type:{c::DataType::kInt32,c::DataType::kInt64}){
  const std::array ds{desc(type,{1}),desc(index_type,{32}),desc(type,{32})};
  journey(c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),ds,
   [&](auto &b,int seed){write<T>(b[0],ds[0],std::vector<T>{half_test::encode<T>(float(1+seed))});write<T>(b[2],ds[2],std::vector<T>(32,half_test::encode<T>(increment)));
    if(index_type==c::DataType::kInt32)write<std::int32_t>(b[1],ds[1],std::vector<std::int32_t>(32,0));else write<std::int64_t>(b[1],ds[1],std::vector<std::int64_t>(32,0));},
   [&](const auto &b,int seed){compare_lowp(b,std::vector<T>{half_test::encode<T>(float(1+seed)+32*increment)});},index_type==c::DataType::kInt32);
 }
 const std::array ds{desc(type,{1,2,1,4}),desc(c::DataType::kInt64,{2}),desc(c::DataType::kFloat32,{2})};
 journey(c::Operation(c::RoPE{.rotary_dimensions=4,.sequence_axis=1}),ds,
  [&](auto &b,int seed){std::vector<T>x;for(int i=0;i<8;++i)x.push_back(half_test::encode<T>(float(i+1+seed)));const std::array<std::int64_t,2>p{2147483651LL,-2147483651LL};const std::array<float,2>f{.125F,.25F};write<T>(b[0],ds[0],x);write<std::int64_t>(b[1],ds[1],p);write<float>(b[2],ds[2],f);},
  [&](const auto &b,int seed){std::vector<T>x;for(int row=0;row<2;++row)for(int pair=0;pair<2;++pair){const double p=row?-2147483651.:2147483651.,phase=p*(pair?.25:.125),a=row*4+pair*2+1+seed,z=a+1;x.push_back(half_test::encode<T>(a*std::cos(phase)-z*std::sin(phase)));x.push_back(half_test::encode<T>(a*std::sin(phase)+z*std::cos(phase)));}compare_lowp(b,x);});
}
int main(){cases<hyle::simd::float16_t>();cases<hyle::simd::bfloat16_t>();std::puts("PASS ordinary lowp ScatterAdd + integer Double-phase RoPE Direct/Graph/replay/close; Native unsupported domains decline");}
