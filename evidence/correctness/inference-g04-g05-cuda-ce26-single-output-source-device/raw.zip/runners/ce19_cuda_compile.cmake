if(PROJECT_NAME STREQUAL "hyle")
  function(ce19_cuda_compile_profile)
    set_property(GLOBAL APPEND PROPERTY JOB_POOLS ce19_cuda_compile=1)
    set_target_properties(hyle_compute_provider_flashinfer PROPERTIES
      JOB_POOL_COMPILE ce19_cuda_compile CUDA_ARCHITECTURES 89-real)
    target_compile_options(hyle_compute_provider_flashinfer PRIVATE
      "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
  endfunction()
  cmake_language(DEFER CALL ce19_cuda_compile_profile)
endif()
