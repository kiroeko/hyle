from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
root=Path.cwd();archive=root/('.scratch/inference-gaps/g04-g05/ce26-source-'+sys.argv[1]+'.zip');assert not archive.exists()
paths=subprocess.check_output(['git','ls-files'],text=True).splitlines();inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for name in paths:
  if name.startswith(('evidence/','.scratch/','.git')):continue
  p=root/name
  if not p.is_file():continue
  data=p.read_bytes();inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()));package.writestr(name,data)
 package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
raise SystemExit(subprocess.run(['wsl','-e','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce26_source_wsl.py','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce26-source-'+sys.argv[1]+'.zip',sys.argv[1]]).returncode)
