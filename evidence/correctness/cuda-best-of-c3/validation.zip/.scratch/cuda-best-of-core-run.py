import ctypes
import json
import os
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
here=root/'.scratch/validation/cuda-best-of'
ctypes.windll.kernel32.SetErrorMode(32771)
setup=subprocess.run(['cmd','/d','/c',str(root/'.scratch/validation/d5-cpu-apple-official-binding/3c22b7b9f230-tests/environment.cmd')],capture_output=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
env=dict(os.environ)
for line in setup.stdout.decode(errors='replace').splitlines():
    if '=' in line:
        k,v=line.split('=',1)
        if k:env[k]=v
linux=['wsl.exe','-d','Ubuntu-24.04','--exec','env','-u','LD_LIBRARY_PATH','CC=gcc-14','CXX=g++-14',
       'PATH=/usr/local/cuda-13.3/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin']
cm=root/'.scratch/validation/cuda-best-of/core-consumer'
jobs=[
 ('core-win-configure',['cmake','-S',str(cm),'-B','C:/hv/cuda-c3-core-checks','-G','Ninja',
    '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=C:/hv/cuda-c3-shared-relocated',
    '-DCORE_SOURCE='+str(root),'-DCORE_GTEST_SOURCE=C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6']),
 ('core-win-build',['cmake','--build','C:/hv/cuda-c3-core-checks','--parallel','2']),
 ('core-win-checks',['C:/hv/cuda-c3-core-checks/core_cold_checks.exe','--gtest_output=xml:'+str(here/'logs/core-win-checks.xml')]),
 ('core-linux-configure',linux+['cmake','-S','/mnt/c/public/project-hyle/hyle/.scratch/validation/cuda-best-of/core-consumer',
  '-B','/root/hyle-scratch/active-cpu-z/cuda-c3-core-checks','-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
  '-DCMAKE_PREFIX_PATH=/root/hyle-scratch/active-cpu-z/cuda-c3-shared-relocated',
  '-DCORE_SOURCE=/root/hyle-scratch/active-cpu-z/source',
  '-DCORE_GTEST_SOURCE=/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6']),
 ('core-linux-build',linux+['cmake','--build','/root/hyle-scratch/active-cpu-z/cuda-c3-core-checks','--parallel','2']),
 ('core-linux-checks',linux+['/root/hyle-scratch/active-cpu-z/cuda-c3-core-checks/core_cold_checks',
  '--gtest_output=xml:/mnt/c/public/project-hyle/hyle/.scratch/validation/cuda-best-of/logs/core-linux-checks.xml']),
]
records=[]
for name,argv in jobs:
    log=here/'logs'/(name+'.log')
    if log.exists():raise RuntimeError('Bounded Core step already executed: '+name)
    with log.open('wb') as stream:
        p=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=300,creationflags=subprocess.CREATE_NO_WINDOW)
    records.append({'id':name,'argv':argv,'returncode':p.returncode,'log':str(log)})
    (here/'core-receipt.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
    if p.returncode:raise RuntimeError('Stopped Core checks at '+name)
