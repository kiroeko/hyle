import ctypes
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
here = root / '.scratch/validation/cuda-best-of'
ctypes.windll.kernel32.SetErrorMode(32771)
spec = importlib.util.spec_from_file_location('delivery', root / 'evidence/correctness/cuda-final-u3-joint-delivery/delivery.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
env = subprocess.run(['cmd','/d','/c',str(root / '.scratch/validation/d5-cpu-apple-official-binding/3c22b7b9f230-tests/environment.cmd')],
    capture_output=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW).stdout.decode(errors='replace')
import os
environment = dict(os.environ)
for line in env.splitlines():
    if '=' in line:
        key, value = line.split('=',1)
        if key: environment[key] = value
commands = [
 ('fixc-core-build', ['cmake','--build','C:/hv/m2b1-cuda','--target','hyle_compute','--parallel','2']),
 ('fixc-sdk-update', None),
 ('fixc-consumer-build', ['cmake','--build','C:/hv/cuda-c3-static-consumer','--parallel','2']),
 ('fixc-managed-and-offset', ['C:/hv/cuda-c3-static-consumer/cuda_c3_qualification.exe',
    '--gtest_filter=CudaBestOf.ManagedStorageRetainsFallbackWithoutMeasuredLabel:CudaBestOf.ShiftedViewsRetainCapabilityWithoutMeasuredAlignment',
    '--gtest_output=xml:' + (here/'logs/fixc-managed-and-offset.xml').as_posix()]),
 ('c4-win-static-ordinary-fixc', ['C:/hv/cuda-c3-static-consumer/cuda_c3_ordinary.exe']),
]
record = []
for name, argv in commands:
    log = here / 'logs' / (name + '.log')
    if log.exists(): raise RuntimeError('Fixed FIX-C step already ran; no automatic repeat: '+name)
    if argv is None:
        source = Path('C:/hv/m2b1-cuda/bin/hyle_compute.lib')
        target = Path('C:/hv/cuda-c3-static-relocated/lib/hyle_compute.lib')
        assert source.is_file() and target.is_file()
        shutil.copy2(source, target)
        log.write_text('Delta SDK update: hyle_compute.lib only; other libraries and package metadata unchanged.\n')
        rc = 0
    else:
        child_env = dict(environment)
        if name == 'fixc-managed-and-offset':
            # Match the C2 host contract without rerunning the 29-item batch.
            ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(), 0x14)
            child_env['HYLE_CUDA_RULE_TEST_PROFILE'] = '1'
        with log.open('wb') as stream:
            result = subprocess.run(argv, cwd=root, env=child_env, stdout=stream, stderr=subprocess.STDOUT,
                timeout=300, creationflags=subprocess.CREATE_NO_WINDOW)
        rc = result.returncode
    record.append({'id':name,'argv':argv,'returncode':rc,'log':str(log)})
    (here/'fixc-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record[-1]),flush=True)
    if rc: raise RuntimeError('FIX-C stopped at '+name)
