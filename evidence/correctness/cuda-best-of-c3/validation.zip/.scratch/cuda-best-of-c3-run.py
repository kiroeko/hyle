import ctypes
import argparse
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cuda_delivery', ROOT / 'evidence/correctness/cuda-final-u3-joint-delivery/delivery.py')
delivery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(delivery)
ctypes.windll.kernel32.SetErrorMode(32771)
here = ROOT / '.scratch/validation/cuda-best-of'
jobs = delivery.read(here / 'jobs.json')
runner = delivery.Runner(ROOT, jobs, here / 'state')
parser = argparse.ArgumentParser()
parser.add_argument('--reason')
parser.add_argument('tasks', nargs='+')
args = parser.parse_args()
with runner.locked():
    runner.seed()
    for task in args.tasks:
        print(json.dumps({'task': task, 'action': runner.perform(task, here / 'logs', args.reason)}), flush=True)
