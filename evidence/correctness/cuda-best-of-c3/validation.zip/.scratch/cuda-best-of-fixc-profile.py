import ctypes
import json
import os
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parents[1]
here = root / '.scratch/validation/cuda-best-of/logs'
ctypes.windll.kernel32.SetErrorMode(32771)
setup = subprocess.run(['cmd','/d','/c',str(root / '.scratch/validation/d5-cpu-apple-official-binding/3c22b7b9f230-tests/environment.cmd')],capture_output=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
env = dict(os.environ)
for line in setup.stdout.decode(errors='replace').splitlines():
    if '=' in line:
        k,v=line.split('=',1)
        if k: env[k]=v
for name,args in [
 ('fixc-profile-build',['cmake','--build','C:/hv/cuda-c3-static-consumer','--parallel','2']),
 ('fixc-profile-final',['C:/hv/cuda-c3-static-consumer/cuda_c3_qualification.exe',
  '--gtest_filter=CudaBestOf.ManagedStorageRetainsFallbackWithoutMeasuredLabel:CudaBestOf.ShiftedViewsRetainCapabilityWithoutMeasuredAlignment',
  '--gtest_output=xml:'+str(here/'fixc-profile-final.xml')])]:
    log=here/(name+'.log')
    if log.exists(): raise RuntimeError('Final FIX-C profile correction already executed')
    if name.endswith('final'): env['HYLE_CUDA_RULE_TEST_PROFILE']='1'
    with log.open('wb') as stream:
        p=subprocess.run(args,env=env,cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
    print(json.dumps({'id':name,'returncode':p.returncode,'log':str(log)}),flush=True)
    if p.returncode: raise RuntimeError('Final FIX-C profile check failed')
