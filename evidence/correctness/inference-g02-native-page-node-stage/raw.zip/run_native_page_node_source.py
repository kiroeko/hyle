from pathlib import Path
import json,os,subprocess,time,hashlib
root=Path.cwd();folder=root/'.scratch/inference-gaps/g02/native-page-node';folder.mkdir(exist_ok=True)
build=root/'.scratch/build-compute-v2-dev';hook=folder/'project.cmake'
hook.write_bytes(('''if(PROJECT_NAME STREQUAL "hyle")
 if(NOT TARGET GTest::gtest_main)
  set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
  add_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g02-page-node-gtest EXCLUDE_FROM_ALL)
 endif()
 function(g02_page_node_source)
  add_executable(g02_native_page_node_tests "'''+(root/'tests/graph_batch/native_paged_node_test.cc').as_posix()+'''" "'''+(root/'tests/graph_batch/materialized_graph_test.cc').as_posix()+'''")
  target_compile_features(g02_native_page_node_tests PRIVATE cxx_std_23)
  target_compile_options(g02_native_page_node_tests PRIVATE /W4 /WX /wd4324 /utf-8)
  target_link_libraries(g02_native_page_node_tests PRIVATE hyle::graph GTest::gtest_main)
  hyle_stage_runtime(g02_native_page_node_tests)
 endfunction()
 cmake_language(DEFER CALL g02_page_node_source)
endif()
''').encode())
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key,value=line.split('=',1);env[key]=value
record=folder/'result.json';rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
def run(stage,args):
    attempt=1+sum(r['stage']==stage for r in rows);log=folder/f'{stage}-{attempt}.log';start=time.monotonic()
    with log.open('w',encoding='utf-8') as stream:r=subprocess.run(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    inputs=[{'path':name,'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()} for name in ['include/hyle/graph/batch.h','src/graph_batch/native_paged_node.cc','src/graph_batch/CMakeLists.txt','tests/graph_batch/native_paged_node_test.cc','tests/graph_batch/CMakeLists.txt']]
    record.write_bytes((json.dumps({'scope':'AUDITED G02 NJ01 draft Graph node schema/source negative space only; no hybrid/native qualification','inputs':inputs,'stages':rows},indent=2)+'\n').encode());print(json.dumps(row),flush=True)
    if r.returncode:
        with log.open('rb') as stream:stream.seek(max(0,log.stat().st_size-3500));print(stream.read().decode(errors='replace'))
        raise SystemExit(r.returncode)
run('configure',['cmake','-S',str(root),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
run('build',['cmake','--build',str(build),'--target','g02_native_page_node_tests','--parallel','4'])
run('run',[str(build/'bin/g02_native_page_node_tests.exe')])
