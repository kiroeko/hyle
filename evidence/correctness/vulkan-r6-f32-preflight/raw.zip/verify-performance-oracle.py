from pathlib import Path
import ctypes
import hashlib
import json
import os
import subprocess
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path('C:/hyle-scratch/r6-vulkan-20260917')
repo = Path('C:/public/project-hyle/hyle')
build = root / 'build-native-v2'
logs = root / 'performance-oracle-01'
logs.mkdir(exist_ok=False)
paths = set(subprocess.check_output(['git', 'ls-files', '--', 'include', 'src', 'cmake',
    'CMakeLists.txt', 'third_party/ggml_vulkan_shaders'], cwd=repo, text=True).splitlines())
for directory in ('bench/compute_route_vulkan', 'bench/graph_route_vulkan'):
    paths.update(p.relative_to(repo).as_posix() for p in (repo / directory).rglob('*') if p.is_file())
inputs = {p: hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in sorted(paths)}
identity = {'state': 'RUNNING', 'head': subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(), 'inputs': inputs,
    'scope': 'mutable implementation checkpoint, correctness only; not P1 or A/A', 'runs': []}
env = {k: v for k, v in os.environ.items() if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_'))}
env.update(HYLE_BENCH_VERIFY_ONLY='1', VK_LOADER_LAYERS_DISABLE='~implicit~')
def save():
    (logs/'identity.json').write_text(json.dumps(identity, indent=2)+'\n')
try:
    save()
    for mode in ('compute', 'graph'):
        for natural in (False, True):
            stem = 'hyle_'+mode+('_vulkan_native_cost_bench' if natural else '_route_vulkan_bench')
            exe = build/'bin'/(stem+'.exe')
            print('RUN', stem, flush=True)
            start = time.time()
            with (logs/(stem+'.log')).open('w') as stream:
                result = subprocess.run([str(exe)], cwd=repo, env=env, stdout=stream,
                    stderr=subprocess.STDOUT, timeout=600)
            record = {'executable': str(exe), 'sha256': hashlib.sha256(exe.read_bytes()).hexdigest(),
                'exit_code': result.returncode, 'seconds': time.time()-start, 'natural_route': natural}
            identity['runs'].append(record)
            save()
            print('DONE', stem, result.returncode, round(record['seconds'], 2), flush=True)
            if result.returncode:
                print((logs/(stem+'.log')).read_text()[-5000:], flush=True)
                result.check_returncode()
            text = (logs/(stem+'.log')).read_text()
            assert text.count('oracle=1') == 8, 'two shapes x two slots x both arms'
            assert 'verify_only=1' in text
    unchanged = all(hashlib.sha256((repo/p).read_bytes()).hexdigest() == h for p,h in inputs.items())
    assert unchanged, 'executed source inputs changed'
    identity.update(state='PASS', source_inputs_unchanged=unchanged)
except Exception as error:
    identity.update(state='FAIL', error=str(error))
    raise
finally:
    save()
