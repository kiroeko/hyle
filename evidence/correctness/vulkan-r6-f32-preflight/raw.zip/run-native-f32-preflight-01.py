from pathlib import Path
import ctypes, hashlib, json, subprocess, time
ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path('C:/hyle-scratch/r6-vulkan-20260917')
record = root / 'native-f32-preflight-01-controller.json'
assert not record.exists()
canonical = Path('C:/public/project-hyle/hyle')
paths = subprocess.check_output(['git', 'ls-files', '--', 'CMakeLists.txt', 'cmake',
    'include', 'src', 'tests/compute_route_vulkan', 'tests/graph_route_vulkan',
    'third_party/ggml_vulkan_shaders'], cwd=canonical, text=True).splitlines()
inputs = {p: hashlib.sha256((canonical / p).read_bytes()).hexdigest() for p in paths}
start = time.time()
row = {'status': 'RUNNING', 'started_utc_seconds': start,
       'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=canonical, text=True).strip(),
       'scope': 'Mutable implementation checkpoint, native correctness/validation only; not a frozen P1 candidate.',
       'inputs': inputs}
record.write_text(json.dumps(row, indent=2) + '\n')
with (root / 'native-f32-preflight-01-controller.log').open('w') as log:
    result = subprocess.run(['pwsh', '-NoProfile', '-File', str(root / 'run-native-f32-preflight-01.ps1')],
        cwd=canonical, stdout=log, stderr=subprocess.STDOUT, timeout=900)
unchanged = all(hashlib.sha256((canonical / p).read_bytes()).hexdigest() == digest
                for p, digest in inputs.items())
row.update(status='PASS' if result.returncode == 0 and unchanged else 'FAIL',
           exit_code=result.returncode, product_inputs_unchanged=unchanged,
           finished_utc_seconds=time.time())
record.write_text(json.dumps(row, indent=2) + '\n')
print((root / 'native-f32-preflight-01-controller.log').read_text()[-10000:], flush=True)
print(row['status'], 'native checkpoint; product_inputs_unchanged=', unchanged, flush=True)
raise SystemExit(0 if row['status'] == 'PASS' else 1)
