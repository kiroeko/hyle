$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$r6Build = 'C:/hyle-scratch/r6-vulkan-20260917/build-native-v2'
$r6Logs = 'C:/hyle-scratch/r6-vulkan-20260917/performance-build-01'
New-Item -ItemType Directory -Path $r6Logs -ErrorAction Stop | Out-Null
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_PARALLEL_LEVEL = '1'
cmake -S C:/public/project-hyle/hyle -B $r6Build -G Ninja `
  '-DHYLE_BUILD_BENCH=ON' '-DHYLE_VULKAN_REFERENCE_SOURCE_DIR=C:/public/project-hyle/ggml' *> "$r6Logs/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/configure.log" -Tail 75; exit $LASTEXITCODE }
cmake --build $r6Build --parallel 2 --target hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests `
  hyle_compute_route_vulkan_benches hyle_graph_route_vulkan_benches *> "$r6Logs/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/build.log" -Tail 85; exit $LASTEXITCODE }
$env:VK_LAYER_PATH = "$r6Build/bin"
$env:VK_LOADER_LAYERS_DISABLE = '~implicit~'
$env:HYLE_VULKAN_VALIDATION = '1'
$env:VK_KHRONOS_VALIDATION_VALIDATE_SYNC = 'true'
ctest --test-dir $r6Build --output-on-failure --no-tests=error --timeout 120 `
  -L '^(compute_route_vulkan|graph_route_vulkan)$' *> "$r6Logs/ctest.log"
$testExit = $LASTEXITCODE
Copy-Item -LiteralPath "$r6Build/Testing/Temporary/LastTest.log" -Destination "$r6Logs/LastTest.log"
Get-Content "$r6Logs/ctest.log" -Tail 40
if ($testExit -ne 0) { exit $testExit }
if (Select-String -Path "$r6Logs/LastTest.log" -Pattern 'Validation Error|VUID-|SYNC-HAZARD') { exit 3 }
Write-Output 'PASS benchmark compilation and 17 native GTests; no P1 sampling.'
