#include <array>
#include <cstdint>
#include <iostream>
#include <utility>
#include "hyle/compute/operation.h"
#include "hyle/graph/graph.h"

int main() {
  using namespace hyle::compute;
  const auto matrix = [](std::int64_t m, std::int64_t n) {
    return TensorDesc::dense(DataType::kFloat32, std::array{m, n}).value();
  };
  // Description-only fixture identity; no executable carrier is claimed.
  const auto format = StorageFormat::blocked({0x54455354, 4}, 2, 1).value();
  const auto weight = TensorDesc::blocked_dense(
      DataType::kFloat32, std::array<std::int64_t, 2>{128, 256}, format).value();
  const auto scale = matrix(128, 4);
  const QuantizedMatMul affine{.mode = QuantizedWeightMode::kUnsignedAffine4};
  for (const std::int64_t m : {1, 7}) {
    const auto input = matrix(m, 256);
    const auto result = infer_single_output(
        Operation(affine), std::array{input, weight, scale, scale});
    if (!result || *result != matrix(m, 128)) return 1;
    if (infer_single_output(Operation(affine), std::array{input, weight, scale}))
      return 2;
    auto builder = hyle::graph::GraphBuilder::create().value();
    const auto x = builder.input(input).value();
    const auto w = builder.constant(weight).value();
    const auto s = builder.constant(scale).value();
    const auto b = builder.constant(scale).value();
    const auto y = builder.add(affine, x, w, s, b);
    if (!y || !builder.publish(*y).ok()) return 3;
    const auto graph = std::move(builder).finish();
    if (!graph || graph->output_description().value() != matrix(m, 128)) return 4;
    const auto node = graph->node_id(0).value();
    if (graph->node_input_count(node).value() != 4 ||
        graph->operation(node)->kind() != OperationKind::kQuantizedMatMul) return 5;
  }
  std::cout << "PASS: grouped Q4 public description and Graph consumer\n";
}
