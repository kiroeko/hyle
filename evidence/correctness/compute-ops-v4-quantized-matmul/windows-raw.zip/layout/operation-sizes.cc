#include <cstdio>
#include "hyle/compute/operation.h"
int main() {
  std::printf("Operation size=%zu alignment=%zu CustomOperationValue size=%zu\n", sizeof(hyle::compute::Operation), alignof(hyle::compute::Operation), sizeof(hyle::compute::detail::CustomOperationValue));
#ifdef HYLE_Q4_SIZE
  std::printf("QuantizedMatMul size=%zu alignment=%zu\n", sizeof(hyle::compute::QuantizedMatMul), alignof(hyle::compute::QuantizedMatMul));
#endif
}
