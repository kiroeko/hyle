$ErrorActionPreference = 'Stop'
$r2Repo = 'C:\hyle-scratch\r2-q4-20260916\windows-validation'
$r2Scratch = 'C:\hyle-scratch\r2-q4-20260916'
Set-Location -LiteralPath $r2Repo
$r2Vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$r2Vs = & $r2Vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $r2Vs) { throw 'MSVC installation missing' }
$r2Dev = Join-Path $r2Vs 'Common7\Tools\VsDevCmd.bat'
$r2Command = 'call "' + $r2Dev + '" -arch=x64 >nul && set'
$r2Environment = & $env:ComSpec /d /s /c $r2Command
if ($LASTEXITCODE -ne 0) { throw 'MSVC initialization failed' }
foreach ($r2Line in $r2Environment) {
    $r2Split = $r2Line.IndexOf('=')
    if ($r2Split -le 0) { continue }
    $r2Name = $r2Line.Substring(0, $r2Split)
    $r2Value = $r2Line.Substring($r2Split + 1)
    if ($r2Name -ieq 'Path' -and $r2Value -notlike "*$r2Vs\VC\Tools\MSVC\*") { continue }
    [Environment]::SetEnvironmentVariable($r2Name, $r2Value, 'Process')
}
$r2Delivery = 'C:\hyle-scratch\r2-q4-20260916\selector-ninja\2cdff29a78eb088aa814\delivery-graph\selected-graph'
foreach ($r2Shape in @('shared','static','source')) {
  $r2Build = "$r2Scratch\q4-windows-$r2Shape"
  $r2Args = @('-S', "$r2Scratch\q4-consumer", '-B', $r2Build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release')
  if ($r2Shape -eq 'source') { $r2Args += "-DHYLE_SOURCE_DIR=$r2Repo" }
  else { $r2Args += "-DCMAKE_PREFIX_PATH=$r2Delivery\$r2Shape-sdk-relocated" }
  cmake @r2Args *> "$r2Scratch\q4-windows-$r2Shape-configure.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$r2Scratch\q4-windows-$r2Shape-configure.log" -Tail 35; exit $LASTEXITCODE }
  cmake --build $r2Build --parallel 2 *> "$r2Scratch\q4-windows-$r2Shape-build.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$r2Scratch\q4-windows-$r2Shape-build.log" -Tail 35; exit $LASTEXITCODE }
  & "$r2Build\q4_consumer.exe" *> "$r2Scratch\q4-windows-$r2Shape-run.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$r2Scratch\q4-windows-$r2Shape-run.log" -Tail 35; exit $LASTEXITCODE }
  Write-Output "PASS Q4 Windows $r2Shape consumer"
}
