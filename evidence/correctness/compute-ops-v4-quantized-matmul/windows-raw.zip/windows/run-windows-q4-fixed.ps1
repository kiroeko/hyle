$ErrorActionPreference = 'Stop'
$r2Repo = 'C:\hyle-scratch\r2-q4-20260916\windows-validation'
$r2Scratch = 'C:\hyle-scratch\r2-q4-20260916'
Set-Location -LiteralPath $r2Repo
$r2Vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$r2Vs = & $r2Vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $r2Vs) { throw 'MSVC installation missing' }
$r2Dev = Join-Path $r2Vs 'Common7\Tools\VsDevCmd.bat'
$r2Command = 'call "' + $r2Dev + '" -arch=x64 >nul && set'
$r2Environment = & $env:ComSpec /d /s /c $r2Command
if ($LASTEXITCODE -ne 0) { throw 'MSVC initialization failed' }
foreach ($r2Line in $r2Environment) {
    $r2Split = $r2Line.IndexOf('=')
    if ($r2Split -le 0) { continue }
    $r2Name = $r2Line.Substring(0, $r2Split)
    $r2Value = $r2Line.Substring($r2Split + 1)
    if ($r2Name -ieq 'Path' -and $r2Value -notlike "*$r2Vs\VC\Tools\MSVC\*") { continue }
    [Environment]::SetEnvironmentVariable($r2Name, $r2Value, 'Process')
}
$r2Build = "$r2Scratch\q4-owners-210044ce"
cmake -S $r2Repo -B $r2Build -G Ninja -DCMAKE_BUILD_TYPE=Release '-DHYLE_DEV_FACTORS=compute_ops,graph' -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_WERROR=ON *> "$r2Scratch\q4-fixed-configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r2Scratch\q4-fixed-configure.log" -Tail 30; exit $LASTEXITCODE }
cmake --build $r2Build --parallel 2 --target hyle_compute_ops_tests hyle_graph_tests *> "$r2Scratch\q4-fixed-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r2Scratch\q4-fixed-build.log" -Tail 35; exit $LASTEXITCODE }
ctest --test-dir $r2Build --output-on-failure --no-tests=error -L '^(compute_ops|graph)$' *> "$r2Scratch\q4-fixed-tests.log"
Get-Content "$r2Scratch\q4-fixed-tests.log" -Tail 20
exit $LASTEXITCODE

