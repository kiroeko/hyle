namespace g = hyle::graph;
void check(bool ok, const char* message, const std::string& id = {}) {
  if (!ok) { std::fprintf(stderr, "FAIL %s %s\n", message, id.c_str()); std::exit(9); }
}
bool qualified_machine() {
#if defined(_WIN32) && defined(_MSC_FULL_VER) && _MSC_FULL_VER == 195035728
  const auto& id=hyle::platform::cpu_identity();
  return std::string_view(id.vendor.data())=="GenuineIntel" && id.family==6 &&
    id.model==183 && id.stepping==1 && std::string_view(id.brand.data())=="13th Gen Intel(R) Core(TM) i9-13900K";
#else
  return false;
#endif
}
template<class T> bool member(const T& values,const std::string& id) {
  return std::find(values.begin(),values.end(),std::string_view(id))!=values.end();
}
c::Context mature_context() {
  const std::array bindings{
    c::ProviderBinding{c::onednn::provider(),100},
    c::ProviderBinding{c::ggml_cpu::provider({.native_threads=1}),200},
    c::ProviderBinding{c::aten_cpu::provider(),350}};
  return take(c::Context::create(c::cpu::device(), {.providers=bindings}));
}
struct Run {
  c::Queue queue; c::PreparedOperation program; m::Buffer scratch;
  c::OperationInvocation invocation;
  Run(c::Context& context, Data& d) : queue(take(context.create_queue())),
    program(take(c::prepare(context,d.op,d.desc,std::span(&d.output,1),m::system_resource()))) {
    const auto w=program.workspace_requirement();
    if(program.runtime_properties().workspace_owner==c::ProviderWorkspaceOwner::kCaller && w.size)
      scratch=take(m::Buffer::create(m::system_resource(),w.size,w.alignment));
    invocation=take(program.create_invocation(scratch.view()));
  }
  std::vector<std::byte> execute(Data& d) {
    require(take(invocation.submit(queue,d.inputs,d.outputs)).wait()); return d.read();
  }
};
void change(Data& d) {
  for(std::size_t j=0;j<d.desc.size();++j){
    const auto t=d.desc[j].data_type();
    if(t==c::DataType::kBool || t==c::DataType::kInt32 || t==c::DataType::kInt64 ||
       (d.spec.kind==Kind::Rope && j==2)) continue;
    std::vector<std::byte> bytes(d.buffers[j].size());require(d.buffers[j].view().read(bytes));
    const auto width=c::data_type_size(t);
    for(std::size_t i=0;i<bytes.size();i+=width)
      encode(bytes.data()+i,t,float(decode(bytes.data()+i,t))+.125F);
    require(d.buffers[j].view().write(bytes));
  }
}
void mismatch(c::Context& context, c::Operation op, std::vector<c::TensorDesc> ds,
              const char* label) {
  const auto output=take(c::infer_single_output(op,ds));
  auto p=take(c::prepare(context,op,ds,std::span(&output,1),m::system_resource()));
  check(p.provider().id!=c::native::kProviderId,label);
}
} // namespace
int main() {
  const auto& identity=hyle::platform::cpu_identity();
  std::printf("IDENTITY %s %s family=%u model=%u stepping=%u qualified=%d\n",
    identity.vendor.data(),identity.brand.data(),identity.family,identity.model,identity.stepping,int(qualified_machine()));
  std::array<const hyle::platform::CpuIdentity*,8> ids{};
  std::array<std::thread,8> readers;
  for(std::size_t i=0;i<ids.size();++i)readers[i]=std::thread([&,i]{ids[i]=&hyle::platform::cpu_identity();});
  for(auto& t:readers)t.join();for(auto* p:ids)check(p==&identity,"cached identity concurrency");
  auto context=take(c::cpu::create_context({.native_threads=1}));
  auto mature=mature_context();
  auto expert=take(c::Context::create(c::cpu::device(),c::native::provider()));
  auto gc=take(g::cpu::create_context({.native_threads=1}));
  auto gq=take(gc.create_queue());
  unsigned total=0,native_wins=0,loss_rejections=0,regions=0;
  for(const auto& s:catalog()) {
    if(s.kind==Kind::MatMul)continue;
    Data d(s); Run ordinary(context,d),control(mature,d);
    const bool expected_native=qualified_machine()&&member(wins,s.id);
    check((ordinary.program.provider().id==c::native::kProviderId)==expected_native,"default binding",s.id);
    check(!expected_native || ordinary.program.route_policy().valid(),"qualified policy",s.id);
    native_wins+=expected_native;
    if(qualified_machine()&&member(losses,s.id)) {
      auto result=c::prepare(expert,d.op,d.desc,std::span(&d.output,1),m::system_resource());
      check(!result&&result.error().IsUnimplemented(),"expert cold decline",s.id);++loss_rejections;
    }
    auto builder=take(g::GraphBuilder::create());std::vector<g::ValueId> inputs;
    for(const auto& desc:d.desc)inputs.push_back(take(builder.input(desc)));
    auto node=take(builder.add_node(d.op,inputs));auto value=take(builder.result(node));
    auto final=take(builder.add(c::Copy{},value));require(builder.publish(final));
    auto logical=take(std::move(builder).finish());auto compiled=take(g::compile(logical,gc));
    auto invocation=take(compiled.executable.create_invocation());
    for(std::size_t i=0;i<inputs.size();++i)require(invocation.bind(inputs[i],d.inputs[i]));
    require(invocation.bind(final,d.outputs[0]));
    const std::array lanes{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&gq}};
    require(invocation.prepare_replay(lanes));
    unsigned mature_regions=0;
    for(std::size_t i=0;i<compiled.report.step_count();++i){
      const auto step=take(compiled.report.step(i));
      if(step.kind==g::CompileStepKind::kProviderRegion && step.node_count>=2){
        check(step.provider.id!=c::native::kProviderId,"mature region retained",s.id);
        ++mature_regions;
      }
    }
    regions+=mature_regions;
    for(int replay=0;replay<2;++replay){
      if(replay)change(d);
      auto reference=control.execute(d),actual=ordinary.execute(d);
      check(equal(d,actual,reference),"ordinary numerical replay",s.id);
      require(take(invocation.submit(gq)).wait());
      check(equal(d,d.read(),reference),"graph numerical replay",s.id);
    }
    std::printf("CASE %s direct=%.*s mature_region=%u replay=2\n",s.id.c_str(),
      int(ordinary.program.provider().name.size()),ordinary.program.provider().name.data(),mature_regions);
    ++total;
  }
  const auto f=c::DataType::kFloat32;const auto data=dense(f,{1,2048}),weight=dense(f,{2048});
  mismatch(context,c::RmsNorm{.epsilon=1e-6F},{data,weight},"epsilon fallback");
  mismatch(context,c::LayerNorm{}, {data,weight,weight},"extra bias fallback");
  mismatch(context,c::Binary{c::BinaryKind::kAdd},{data,dense(f,{1,1})},"broadcast fallback");
  mismatch(context,c::Softmax{.axis=0},{data},"axis fallback");
  mismatch(context,c::Softmax{.scale=.5F},{data},"scale fallback");
  mismatch(context,c::Softmax{.mask=c::MaskKind::kBoolean},{data,dense(c::DataType::kBool,{1,1})},"mask geometry fallback");
  mismatch(context,c::Unary{c::UnaryKind::kAbs},{dense(f,{1,1024})},"unmeasured shape fallback");
  auto shape=take(c::TensorShape::create(std::array<std::int64_t,2>{32,2048}));
  mismatch(context,c::Fill{.output_shape=shape,.output_type=f,.value=c::ScalarValue(0.F)}, {},"unmeasured fill fallback");
  auto threaded=take(c::cpu::create_context({.native_threads=2}));
  mismatch(threaded,c::Unary{c::UnaryKind::kAbs},{data},"thread contract fallback");
  require(context.close());require(mature.close());require(expert.close());require(gc.close());require(threaded.close());
  check(total==274,"complete ledger");
  check(native_wins==(qualified_machine()?187U:0U),"win count");
  check(loss_rejections==(qualified_machine()?13U:0U),"loss count");
  check(regions>0,"actual mature regions");
  std::printf("PASS cases=%u native=%u cold_rejected=%u mature_regions=%u mismatch=9 changed_replay=2\n",total,native_wins,loss_rejections,regions);
}
