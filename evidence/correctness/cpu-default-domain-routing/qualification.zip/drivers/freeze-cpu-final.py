import json,hashlib,subprocess
from pathlib import Path
repo=Path.cwd();sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
path=repo/'docs/implementation/module-status.json';j=json.loads(path.read_text())
for r in j['modules']:
 if r['module'] in ('platform','compute_provider_native','compute_route_cpu','graph_route_cpu'):
  assert r['state'] in ('AUDITED','CANDIDATE');r['state']='CANDIDATE';r['candidate']=sha
  r['summary']='CPU最终默认域规则与缓存身份已实现；不可变候选批量完成适用正确性和两平台三交付验收，未验门不签PASS。'
path.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('compute/cpu-default-domain-routing-final.md','platform/cpu-identity-route-facts.md'):
 p=repo/'docs/implementation/tasks'/name;s=p.read_text().replace('<!-- MODULE REVIEW: AUDITED -->','<!-- MODULE REVIEW: CANDIDATE -->');s+='\n## 不可变候选\n\n候选 `'+sha+'`；API/算法/有限规则已固定，适用 P0 与批量 correctness/交付验收继续，\n不重跑已结束 ND3 P1，不把新候选称为新计时比较。\n';p.write_text(s,encoding='utf-8',newline='\n')
old=json.loads((repo/'.scratch/validation/cpu-matmul-retirement/manifest.json').read_text())
names=set(old['files'])|{'src/compute_provider_native/default_rules.cc','src/compute_provider_native/default_rules.h'}
manifest={'candidate':sha,'files':{name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in sorted(names) if(repo/name).is_file()},'removed':old['removed']}
(repo/'.scratch/validation/cpu-final-routing/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
