exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-final-routing/windows';records=json.loads((out/'receipt.json').read_text());candidate=json.loads((out.parent/'manifest.json').read_text())['candidate']
consumer=Path('C:/hv/cpu-final-routing-shared-consumer')
run('resource-and-final-fixture-build',['cmake','--build',consumer,'--parallel','2'])
run('resource-domain',[consumer/'cpu_resource_probe.exe'])
run('final-fixture-identical-journal',[consumer/'cpu_final_consumer.exe'])
