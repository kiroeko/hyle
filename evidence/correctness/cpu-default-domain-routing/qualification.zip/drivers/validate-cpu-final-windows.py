exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-final-routing/windows';out.mkdir(parents=True,exist_ok=True)
records=[];candidate='WORKTREE-after-cd188343'
run('configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(out.parent/'windows-overlay.cmake')])
run('batch-build',['cmake','--build',build,'--target','cpu_final_consumer','hyle_platform_test','--parallel','2'])
run('identity',[build/'bin/hyle_platform_test.exe','--gtest_filter=CpuIdentity.*:Cpu.*','--gtest_output=xml:'+str(out/'identity-final.xml')])
run('ordinary-domain-batch',[build/'bin/cpu_final_consumer.exe'])
