from pathlib import Path
import json
repo=Path.cwd(); out=repo/'.scratch/validation/cpu-final-routing';out.mkdir(parents=True,exist_ok=True)
s=(repo/'bench/compute_provider_native/installed_p1/native_domain_bench.cc').read_text()
prefix=s[:s.index('struct Session {')]
prefix=prefix.replace('#include "../../common/perf_process.h"\n','').replace('#include <nanobench.h>\n','').replace('namespace nb = ankerl::nanobench;\n','')
prefix=prefix.replace('#include <memory>','#include <memory>\n#include <limits>\n#include <thread>\n#include "hyle/platform/cpu.h"\n#include "hyle/graph/cpu.h"\n#include "hyle/compute/providers/onednn.h"')
equal=s[s.index('bool exact(Kind k)'):s.index('bool present(')]
rows=json.loads((repo/'evidence/performance/cpu-native-domain-verdict/receipt.json').read_text())['rows']
wins=[r['id'] for r in rows if r['frozen_practical_verdict']=='WIN']; losses=[r['id'] for r in rows if r['direction_relative_to_one']=='LOSS' and not r['id'].startswith('matmul')]
tables=''
for name,ids in [('wins',wins),('losses',losses)]:
 tables+='constexpr std::array '+name+'{\n'+''.join('  std::string_view("'+i+'"),\n' for i in ids)+'};\n'
(out/'consumer.cc').write_text(prefix+equal+tables,encoding='utf-8',newline='\n')
