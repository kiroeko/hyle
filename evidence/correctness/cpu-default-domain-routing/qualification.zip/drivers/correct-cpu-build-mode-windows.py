import hashlib,re
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
fixture=repo/'.scratch/validation/cpu-final-routing';out=fixture/'windows';records=json.loads((out/'receipt.json').read_text());candidate=json.loads((fixture/'manifest.json').read_text())['candidate']
cl=Path(env['VCToolsInstallDir'])/'bin/Hostx64/x64/cl.exe'
old=fixture/'old-default-rules.cc';old.write_bytes(subprocess.check_output(['git','show','7090222a:src/compute_provider_native/default_rules.cc'],cwd=repo))
base=[cl,'/nologo','/std:c++latest','/EHsc','/DHYLE_COMPUTE_PROVIDER_NATIVE_BUILD=1','/I'+str(repo/'include'),'/I'+str(repo/'src/compute_provider_native'),'/EP']
for label,path,flag in [('old-release',old,'/DNDEBUG'),('corrected-release',repo/'src/compute_provider_native/default_rules.cc','/DNDEBUG'),('non-ndebug',repo/'src/compute_provider_native/default_rules.cc','/UNDEBUG')]:run('preprocess-'+label,[*base,flag,path])
logs={r['name']:out/r['log'] for r in records if r['name'].startswith('preprocess-')}
def body(name):
 text=logs['preprocess-'+name].read_text(errors='replace');start=text.rindex('bool qualified_default_environment() noexcept {');return text[start:text.index('\n}',start)+2]
a=body('old-release');b=body('corrected-release');c=body('non-ndebug')
assert a==b and re.search(r'\{\s*return false;\s*\}',c),c
(out/'build-mode-proof.json').write_text(json.dumps(dict(candidate=candidate,release_body_identical=True,release_body_sha256=hashlib.sha256(a.encode()).hexdigest(),non_ndebug_body=c),indent=2)+'\n')
source=Path('C:/hv/d5cd/source-tree');data=(repo/'src/compute_provider_native/default_rules.cc').read_bytes();(source/'src/compute_provider_native/default_rules.cc').write_bytes(data)
for stage,producer,exe in [('shared',repo/'.scratch/build-compute-v2-dev','bin/cpu_final_consumer.exe'),('static',Path('C:/hv/d5cp/source-build'),'cpu_final_consumer.exe')]:
 run(stage+'-mode-rebuild',['cmake','--build',producer,'--target','cpu_final_consumer','--parallel','2'])
 run(stage+'-mode-source',[producer/exe])
 run(stage+'-mode-install',['cmake','--install',producer,'--prefix','C:/hv/cpu-matmul-retirement-'+stage+'-sdk'])
 consumer=Path('C:/hv/cpu-final-routing-'+stage+'-consumer')
 run(stage+'-mode-consumer-build',['cmake','--build',consumer,'--parallel','2'])
 run(stage+'-mode-installed',[consumer/'cpu_final_consumer.exe'])
