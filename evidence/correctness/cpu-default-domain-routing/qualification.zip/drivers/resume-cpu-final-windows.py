exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-final-routing/windows';records=json.loads((out/'receipt.json').read_text());candidate='WORKTREE-after-cd188343'
run('consumer-build-correction',['cmake','--build',build,'--target','cpu_final_consumer','hyle_platform_test','--parallel','2'])
run('identity-final',[build/'bin/hyle_platform_test.exe','--gtest_filter=CpuIdentity.*:Cpu.*','--gtest_output=xml:'+str(out/'identity-final.xml')])
run('ordinary-domain-batch',[build/'bin/cpu_final_consumer.exe'])
