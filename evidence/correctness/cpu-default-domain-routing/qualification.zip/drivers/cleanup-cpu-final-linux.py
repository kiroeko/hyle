import json,pathlib,shutil
root=pathlib.Path('/root/hyle-scratch/cpu-final-routing-consumers').resolve()
expected='/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-routing/consumer'
receipts=[]
for name in ('shared','static'):
    path=root/name
    assert path.resolve()==path and path.parent==root and path.is_dir()
    files=list(path.rglob('*'));assert not path.is_symlink() and not any(p.is_symlink() for p in files)
    assert 'CMAKE_HOME_DIRECTORY:INTERNAL='+expected in (path/'CMakeCache.txt').read_text().splitlines()
    size=sum(p.stat().st_size for p in files if p.is_file())
    shutil.rmtree(path)
    receipts.append(dict(path=str(path),logical_bytes=size,removed=not path.exists()))
out=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-routing/cleanup-linux.json')
out.write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts))
