import hashlib
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
fixture=repo/'.scratch/validation/cpu-final-routing';out=fixture/'windows'
records=json.loads((out/'receipt.json').read_text());manifest=json.loads((fixture/'manifest.json').read_text());candidate=manifest['candidate']
for name,sha in manifest['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha,name
env['HYLE_D5_QWEN35_FIXTURE']=str(repo/'.scratch/d5-qwen35-six-profile-fixture')
run('final-batch-build',['cmake','--build',build,'--target','cpu_final_consumer','hyle_platform_test','hyle_compute_provider_native_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','--parallel','2'])
run('final-source-shared',[build/'bin/cpu_final_consumer.exe'])
run('final-platform-cpu',[build/'bin/hyle_platform_test.exe','--gtest_filter=CpuIdentity.*:Cpu.*','--gtest_output=xml:'+str(out/'platform.xml')])
run('final-native',[build/'bin/hyle_compute_provider_native_test.exe','--gtest_output=xml:'+str(out/'native-final.xml')])
run('final-cpu',[build/'bin/hyle_compute_route_cpu_test.exe','--gtest_filter=CpuDefaultContext.*:*MatMul*','--gtest_output=xml:'+str(out/'cpu-final.xml')])
run('final-graph',[build/'bin/hyle_graph_route_cpu_test.exe','--gtest_filter=CpuGraph.*:CpuDefaultGraph.*:*MatMul*-CpuDefaultGraph.D5*','--gtest_output=xml:'+str(out/'graph-final.xml')])
run('final-public-headers',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-R','^hyle_(platform|compute_provider_native)_header_self_contained_test$','-j','1','--output-junit',out/'headers.xml'])
source=Path('C:/hv/d5cd/source-tree').resolve();assert source.is_relative_to(Path('C:/hv/d5cd').resolve())
changed=[]
for name,sha in manifest['files'].items():
 data=(repo/name).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,name
 dest=(source/name).resolve();assert dest.is_relative_to(source)
 if not dest.exists() or dest.read_bytes()!=data:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
for name in manifest['removed']:
 dest=(source/name).resolve();assert dest.is_relative_to(source)
 if dest.exists():dest.unlink()
(out/'source-identity.json').write_text(json.dumps(dict(candidate=candidate,checked=len(manifest['files']),forward_updated=changed),indent=2)+'\n')
for stage in ('shared','static'):
 prefix=Path('C:/hv/cpu-matmul-retirement-'+stage+'-sdk')
 if stage=='shared':
  run('shared-install-configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(fixture/'windows-overlay.cmake')])
 else:
  build=Path('C:/hv/d5cp/source-build')
  run('static-source-configure',['cmake','-S','C:/hv/d5cp/consumer','-B',build,'-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(fixture/'windows-overlay.cmake')])
 run(stage+'-producer-build',['cmake','--build',build,'--target','cpu_final_consumer','hyle_time','--parallel','2'])
 run(stage+'-source-consumer',[build/('cpu_final_consumer.exe' if stage=='static' else 'bin/cpu_final_consumer.exe')])
 run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
 consumer=Path('C:/hv/cpu-final-routing-'+stage+'-consumer')
 run(stage+'-consumer-configure',['cmake','-S',fixture/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
 run(stage+'-installed-consumer',[consumer/'cpu_final_consumer.exe'])
