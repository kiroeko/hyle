#define main domain_qualification_main
#include "consumer.cc"
#undef main

int main() {
  Case s{"strict-sdpa-resource",Kind::Attention,c::DataType::kFloat32,0,1};
  Data data(s);
  auto expert=take(c::Context::create(c::cpu::device(),c::native::provider()));
  auto mature=mature_context();
  Run native(expert,data),control(mature,data);
  check(native.program.invocation_private_bytes()==0,"Native declared private invocation storage");
  check(!control.program.invocation_private_bytes().has_value(),"mature private bound remains unknown");
  check(equal(data,native.execute(data),control.execute(data)),"strict SDPA numerical correctness");
  auto context=take(g::cpu::create_context({.native_threads=1}));
  auto builder=take(g::GraphBuilder::create());std::vector<g::ValueId> inputs;
  for(const auto& d:data.desc)inputs.push_back(take(builder.input(d)));
  auto node=take(builder.add_node(data.op,inputs));auto output=take(builder.result(node));require(builder.publish(output));
  auto logical=take(std::move(builder).finish());
  g::CompileOptions options{};options.invocation_storage=g::InvocationStorageLimits{.max_bytes=1U<<20};
  auto compiled=take(g::compile(logical,context,options));
  check(compiled.report.step_count()==1,"strict single SDPA program");
  check(take(compiled.report.step(0)).provider.id==c::native::kProviderId,"strict bound selects Native resource domain");
  auto q=take(context.create_queue());auto invocation=take(compiled.executable.create_invocation());
  for(std::size_t i=0;i<inputs.size();++i)require(invocation.bind(inputs[i],data.inputs[i]));
  require(invocation.bind(output,data.outputs[0]));
  const std::array lanes{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&q}};require(invocation.prepare_replay(lanes));
  auto reference=control.execute(data);require(take(invocation.submit(q)).wait());check(equal(data,data.read(),reference),"strict Graph SDPA output");
  std::puts("PASS SDPA rows1 strict invocation<=1MiB, Native private=0, mature private unknown, actual Direct/Graph execution");
}
