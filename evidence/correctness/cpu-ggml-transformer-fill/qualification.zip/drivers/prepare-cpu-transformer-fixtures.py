import hashlib, json, subprocess
from pathlib import Path
repo = Path.cwd()
old = repo / '.scratch/validation/cpu-ggml-mature-batch'
out = repo / '.scratch/validation/cpu-ggml-transformer-fill'
out.mkdir(parents=True, exist_ok=True)
prefix = (old / 'consumer.cc').read_text(encoding='utf-8').split('template<class T>void run(){')[0]
body = r'''
template<class T>void run(){
  const auto desc=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,4>{2,2,3,7}));
  const auto mask_desc=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,4>{2,1,3,1}));
  auto input=buffer(desc),mask=buffer(mask_desc),output=buffer(desc);
  auto context=take(c::cpu::create_context({.native_threads=4}));auto queue=take(context.create_queue());
  const c::Softmax operation{.scale=.5F,.mask=c::MaskKind::kAdditive};
  const std::array descriptions{desc,mask_desc};
  auto softmax=take(c::prepare(context,c::Operation(operation),descriptions,std::span(&desc,1),m::system_resource()));
  if(softmax.provider().id!=c::ggml_cpu::kProviderId)std::exit(4);
  auto invocation=take(softmax.create_invocation());
  const auto source=take(c::ConstTensorView::create(desc,input.view())),mask_source=take(c::ConstTensorView::create(mask_desc,mask.view()));
  const auto destination=take(c::TensorView::create(desc,output.view()));const std::array sources{source,mask_source};
  auto builder=take(g::GraphBuilder::create());auto x=take(builder.input(desc)),ms=take(builder.input(mask_desc));
  auto s=take(builder.add(operation,x,ms));auto y=take(builder.add(c::Copy{},s));require(builder.publish(y));
  auto graph=take(std::move(builder).finish());auto gc=take(g::cpu::create_context({.native_threads=4}));auto compiled=take(g::compile(graph,gc));
  if(compiled.report.region_count()!=1 || compiled.report.step_count()!=1 || compiled.report.step(0)->provider.id!=c::ggml_cpu::kProviderId || compiled.report.step(0)->node_count!=2)std::exit(5);
  auto gq=take(gc.create_queue());auto lane=take(compiled.executable.create_invocation());require(lane.bind(x,source));require(lane.bind(ms,mask_source));require(lane.bind(y,destination));
  const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&gq}};require(lane.prepare_replay(queues));
  for(int seed:{1,-2,-1,2}){
    std::vector<T> data(84,constant<T>(seed)),masks(6,constant<T>(seed==-1 ? -1 : 0));
    require(input.view().write(std::as_bytes(std::span(data))));require(mask.view().write(std::as_bytes(std::span(masks))));
    const auto verify=[&]{std::vector<T> actual(84);require(output.view().read(std::as_writable_bytes(std::span(actual))));
      for(auto v:actual){float f=decode(v);if(seed<0 ? !std::isnan(f) : std::abs(f-1.F/7.F)>.002F)std::exit(6);}};
    auto done=take(invocation.submit(queue,sources,std::span(&destination,1)));require(done.wait());verify();
    auto whole=take(lane.submit(gq));require(whole.wait());verify();
  }
  for(int seed:{1,-2,-1}){
    const auto value=constant<T>(seed);std::uint64_t bits;
    if constexpr(std::is_same_v<T,float>)bits=std::bit_cast<std::uint32_t>(value);else bits=value.bits;
    const c::Fill fill{.output_shape=take(c::TensorShape::create(desc.dimensions())),.output_type=dtype<T>(),.value=c::ScalarValue::from_bits(dtype<T>(),bits)};
    auto prepared=take(c::prepare(context,fill,m::system_resource()));if(prepared.provider().id!=c::ggml_cpu::kProviderId)std::exit(7);
    auto fi=take(prepared.create_invocation());auto filled=take(fi.submit(queue,{},std::span(&destination,1)));require(filled.wait());
    std::vector<T> actual(84);require(output.view().read(std::as_writable_bytes(std::span(actual))));
    for(auto v:actual){if constexpr(std::is_same_v<T,float>){if(std::bit_cast<std::uint32_t>(v)!=bits)std::exit(8);}else if(v.bits!=bits)std::exit(8);}
    auto fb=take(g::GraphBuilder::create());auto f=take(fb.add(fill));auto cp=take(fb.add(c::Copy{},f));require(fb.publish(cp));
    auto fg=take(std::move(fb).finish());auto fc=take(g::compile(fg,gc));if(fc.report.step_count()!=1 || fc.report.step(0)->provider.id!=c::ggml_cpu::kProviderId)std::exit(9);
    auto fl=take(fc.executable.create_invocation());require(fl.bind(cp,destination));require(fl.prepare_replay(queues));auto fd=take(fl.submit(gq));require(fd.wait());
    require(output.view().read(std::as_writable_bytes(std::span(actual))));for(auto v:actual){if constexpr(std::is_same_v<T,float>){if(std::bit_cast<std::uint32_t>(v)!=bits)std::exit(10);}else if(v.bits!=bits)std::exit(10);}
  }
  const auto qd=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,4>{2,3,4,7}));
  const auto kd=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,4>{2,2,2,7}));
  auto qb=buffer(qd),kb=buffer(kd),vb=buffer(kd),yb=buffer(qd);
  const std::vector<T> qvalues(168,constant<T>(1)),kvalues(56,constant<T>(1));
  require(qb.view().write(std::as_bytes(std::span(qvalues))));require(kb.view().write(std::as_bytes(std::span(kvalues))));
  const std::array ad{qd,kd,kd};const c::ScaledDotProductAttention attention{.scale=.5F};
  auto ap=take(c::prepare(context,c::Operation(attention),ad,std::span(&qd,1),m::system_resource()));if(ap.provider().id!=c::ggml_cpu::kProviderId)std::exit(11);auto ai=take(ap.create_invocation());
  const std::array av{take(c::ConstTensorView::create(qd,qb.view())),take(c::ConstTensorView::create(kd,kb.view())),take(c::ConstTensorView::create(kd,vb.view()))};const auto ay=take(c::TensorView::create(qd,yb.view()));
  auto ab=take(g::GraphBuilder::create());auto aq=take(ab.input(qd)),ak=take(ab.input(kd)),avalue=take(ab.input(kd));auto ao=take(ab.add(attention,aq,ak,avalue));require(ab.publish(ao));
  auto ag=take(std::move(ab).finish());auto ac=take(g::compile(ag,gc));if(ac.report.step(0)->provider.id!=c::ggml_cpu::kProviderId)std::exit(12);auto al=take(ac.executable.create_invocation());require(al.bind(aq,av[0]));require(al.bind(ak,av[1]));require(al.bind(avalue,av[2]));require(al.bind(ao,ay));require(al.prepare_replay(queues));
  for(int seed:{1,2}){const std::vector<T> data(56,constant<T>(seed));require(vb.view().write(std::as_bytes(std::span(data))));
    const auto verify=[&]{std::vector<T> actual(168);require(yb.view().read(std::as_writable_bytes(std::span(actual))));for(auto v:actual)if(decode(v)!=float(seed))std::exit(13);};
    auto done=take(ai.submit(queue,av,std::span(&ay,1)));require(done.wait());verify();auto whole=take(al.submit(gq));require(whole.wait());verify();}
  require(context.close());require(gc.close());std::printf("dtype=%d ordinary Softmax/Fill/noncausal-GQA Direct and Graph replay PASS\n",int(dtype<T>()));
}
int main(){run<float>();run<hyle::simd::float16_t>();run<hyle::simd::bfloat16_t>();}
'''
(out / 'consumer.cc').write_bytes((prefix + body).encode())
for name in ('windows-overlay.cmake', 'linux-overlay.cmake'):
    (out / name).write_bytes((old / name).read_bytes().replace(b'cpu-ggml-mature-batch', b'cpu-ggml-transformer-fill'))
(out / 'consumer').mkdir(exist_ok=True)
(out / 'consumer/CMakeLists.txt').write_bytes((old / 'consumer/CMakeLists.txt').read_bytes())
for platform in ('windows', 'linux'):
    data=(repo / ('.scratch/cpu-mature-' + platform + '.py')).read_text(encoding='utf-8')
    data=data.replace('cpu-ggml-mature-batch', 'cpu-ggml-transformer-fill').replace('cpu-mature-'+"'+stage+'"+'-consumer', 'cpu-tf-'+"'+stage+'"+'-consumer').replace("stage+'-mature-consumer'", "stage+'-tf-consumer'")
    (repo / ('.scratch/cpu-tf-' + platform + '.py')).write_bytes(data.encode())
print('fixtures/drivers prepared; manifest must be frozen after product candidate')
