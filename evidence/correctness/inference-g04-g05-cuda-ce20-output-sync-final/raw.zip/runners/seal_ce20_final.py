from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';dest=root/'evidence/correctness/inference-g04-g05-cuda-ce20-output-sync-final';dest.mkdir(exist_ok=False)
source=json.loads((base/'ce19-source-5/result.json').read_text());device=json.loads((base/'ce20-device-risks-2/result.json').read_text())
assert source['state']==device['state']=='TERMINAL_PASS' and [s['exit_code'] for s in device['stages']]==[0,0,0]
for path,count in [('ce19-source-5/tests.xml',17),('ce20-device-risks-2/memcheck.xml',10),('ce20-device-risks-2/racecheck.xml',10),('ce20-device-risks-2/legacy-racecheck.xml',2)]:
 x=ET.parse(base/path).getroot();assert int(x.attrib['tests'])==count and x.attrib['failures']==x.attrib['errors']=='0'
 assert not any(c.find('skipped') is not None or c.attrib.get('status')=='notrun' for c in x.findall('.//testcase'))
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ('ce19-source-5','ce20-device-risks-2'):
  for p in sorted((base/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(base).as_posix())
 for name in ('ce19_cuda_compile.cmake','ce20_final_device_risks_wsl.py','seal_ce20_final.py'):
  z.write(base/name,'runners/'+name)
 with zipfile.ZipFile(base/'ce19-source-5.zip') as archive:z.writestr('source5-manifest.json',archive.read('source-manifest.json'))
receipt=dict(kind='G04_G05_CUDA_CE20_UNIFIED_OUTPUT_SYNC_SOURCE_DEVICE',verdict='PASS_SOURCE17_DEVICE10_AND_LEGACY2_NOT_SDK_HOST_P1_AGGREGATE',
 product_candidate=device['product_commit'],source_stages=source['stages'],source_tests=17,source_input_count=len(source['inputs']),
 source_result_raw_sha256=hashlib.sha256((base/'ce19-source-5/result.json').read_bytes()).hexdigest(),
 native_cuda_edges=source['native_cuda_edges'],device_stages=device['stages'],artifacts=device['artifacts'],
 limits=['Only actual W1-WSL RTX4070 SM89; no other GPU/OS/Formal verdict.',
 'One verified private header set across FI native routes; original0/512warnings and CE19 failures remain separate immutable evidence.',
 'SDK,three host facets,new performance qualification and whole G04-G05 remain pending.'],
 raw_zip_sha256=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(dest),candidate=receipt['product_candidate'])))
p=root/'docs/implementation/module-status.json';registry=json.loads(p.read_text(encoding='utf-8'));m=next(x for x in registry['modules'] if x['module']=='compute_provider_flashinfer');assert m['state']=='AUDITED'
m['state']='CANDIDATE';m['candidate']=device['product_commit'];m['summary']='G04/G05 CE20 CANDIDATE：所有FI native路线统一verified私有头，两处输出shared/warp同步修正，F32 partial与融合最终scale/cast保留。最终17数学、十cache mem/race和两普通case race全PASS/零warning；SDK/宿主facets/新P1待验，旧失败/成本全部保留。'
p.write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\r\n')
