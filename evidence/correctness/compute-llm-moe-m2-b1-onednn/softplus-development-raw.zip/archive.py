from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parent
destination = root.parents[2] / 'evidence/correctness/compute-llm-moe-m2-b1-onednn'
identity = json.loads((root / 'windows-identity.json').read_text(encoding='utf-8'))
selected = json.loads((root / 'final-plan.json').read_text(encoding='utf-8'))
loc = json.loads((root / 'loc.json').read_text(encoding='utf-8-sig'))
qualification = [json.loads(line) for line in
                 (root / 'qualification.jsonl').read_text(encoding='utf-8-sig').splitlines()]
log = (root / 'windows-ctest-final-full.log').read_text(
    encoding='utf-8', errors='replace')
counts = list(map(int, re.findall(r'\[  PASSED  \] (\d+) tests?', log)))
assert sum(counts) == 121
assert next(row for row in qualification if row['implementation'] == 'ref:any')['mismatches'] == 0

files = sorted(p for p in root.iterdir() if p.is_file() and
               p.suffix in ('.cc', '.ps1', '.json', '.jsonl', '.log', '.py'))
manifest = [dict(path=p.name, bytes=p.stat().st_size,
                 sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
archive_path = destination / 'softplus-development-raw.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in files:
        archive.write(p, p.name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for entry in manifest:
        content = archive.read(entry['path'])
        assert len(content) == entry['bytes']
        assert hashlib.sha256(content).hexdigest() == entry['sha256']

maintenance = {}
for name, phrase in [('docs', 'documentation contract passed'),
                     ('closure', 'module closure contract passed')]:
    p = root / f'{name}.log'
    maintenance[name] = ('PASS' if p.exists() and phrase in p.read_text(
        encoding='utf-8-sig', errors='replace')
                         else 'NOT_RUN')

receipt = {
    'schema': 1, 'card': 'docs/implementation/tasks/compute/llm-moe-m2-b1-onednn.md',
    'checkpoint': 'original oneDNN stable F32 dense Softplus',
    'candidate': identity['candidate'], 'tree': identity['tree'], 'baseline': '9e196d37',
    'owner_state': 'AUDITED', 'environment': identity,
    'onednn': {'version': '3.13.2', 'revision': '71094df45190',
               'runtime': 'THREADPOOL', 'graph_api': 'OFF',
               'primitive': 'eltwise_soft_relu(alpha=1, beta=0)',
               'fixed_implementation': 'ref:any', 'fpmath': 'strict'},
    'qualification': {
        'timing': 'NOT_RUN', 'reference': 'independent FP64 stable log1p(exp(x)) formula',
        'tolerance': 'existing stable gate: 5e-6 * abs(expected) + 1e-43; class/Inf separately',
        'samples': 'extrema/NaN/Inf/signed zero, [-120,120] step 1/64, 100003 deterministic raw F32 patterns',
        'original_results': qualification,
        'rule': 'cold name match only; absent qualified implementation is Unsupported; no submit-time selection',
    },
    'validation': {
        'ctest': {'passed': 13, 'total': 13, 'header_gates': 5,
                  'gtest_cases': 121, 'standalone_consumers': 3},
        'gtest_counts': {'compute_provider_onednn': 29,
                        'compute_provider_onednn_consumers': 2,
                        'graph_provider_onednn': 20,
                        'compute_ops': 43, 'compute_route_cpu': 9, 'graph_route_cpu': 18},
        'scope': [
            '115382 independent numeric samples through the product provider',
            'dense scalar/rank1..8 and empty tensors; explicit non-dense/half/odd-stride refusal',
            'ordinary Direct factory binds oneDNN without caller provider ordering',
            'Graph Softplus to Select, two published values, two slots, changing payload replay',
            'retained prior results, alias refusal before writes, owner close refusal',
            'no hot HYLE allocation/reallocation, HYLE allocator balanced after teardown',
            'existing original normalization/MatMul region, executor and failure consumers',
        ],
        'maintenance': maintenance, 'closure_previous_ref': identity['candidate'],
        'selected': {'factors': selected['selected_factors'],
                     'selected_gate_count': len(selected['selected_gates']),
                     'skipped_gate_count': len(selected['skipped_gates']),
                     'configure_and_factors': 'PASS'},
    },
    'retained_failures': [
        {'candidate': 'd6cb1fb8', 'log': 'windows-build.log',
         'cause': 'old descriptor iterator end enum name; corrected to pinned dnnl_last_impl_reached'},
        {'candidate': 'a93c1b6e', 'log': 'windows-ctest-initial-full.log',
         'cause': 'original ref:any rejects rank1 stride=8 input; constrain admission to dense, gap retained'},
        {'candidate': '9d7a6fbc', 'log': 'windows-ctest-layout-full.log',
         'cause': 'fixture requested host transfer with empty/null span; skip empty fixture transfers only'},
    ],
    'cost_contract': [
        'O(rank + vendor implementation count) cold descriptor matching, no timing',
        'one original O(N) primitive per accepted request, existing stream/handles/scratch/executor',
        'no new HYLE math, hot allocation, whole tensor copies or type conversion',
        'vendor private resource/allocation remains unknown and managed, never counted as zero',
        'no self-written operator comparison or performance claim',
    ],
    'pending': [
        'remaining B1 mature domains and independent full-model numeric profiles',
        'qualified non-dense and F16/BF16 Softplus, numerical Cast/min/max compositions',
        'WSL/Air/Mini applicable new-domain journeys and host instrumentation',
        'source/static/shared relocated consumer acceptance for the stable batch',
        'complete selected set inherited from earlier vendor dependency declaration',
        'qualified P1 on immutable stable batch; old Q2 is INVALID_MEASUREMENT and will not rerun',
    ],
    'full_B1_aggregate': 'INCONCLUSIVE', 'new_complete_matrix_cells': 0, 'p1': 'NOT_RUN',
    'hyle_numerical_kernels_added': 0,
    'source_design_budget_minutes': {'used': 120, 'limit': 120,
                                   'qualification_execution_and_implementation': 'separate, no new library research'},
    'loc': next(row for row in loc['metrics'] if row['id'] == 'module'),
    'loc_self_check': loc['self_check'],
    'raw_archive': {'path': archive_path.name, 'files': len(files),
                    'bytes': archive_path.stat().st_size,
                    'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
                    'integrity': 'CRC and every manifest SHA256 verified'},
}
for name in ('cleanup', 'disk'):
    path = root / f'{name}.json'
    if path.exists():
        receipt[name] = json.loads(path.read_text(encoding='utf-8-sig'))
(destination / 'softplus-development.json').write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'archive': receipt['raw_archive'], 'maintenance': maintenance,
                  'gtest_cases': sum(counts), 'loc': receipt['loc']['code']}))
