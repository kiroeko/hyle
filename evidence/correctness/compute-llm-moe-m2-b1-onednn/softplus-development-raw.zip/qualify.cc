#define NOMINMAX
#include <windows.h>
#include <immintrin.h>
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <string>
#include <vector>
#include "oneapi/dnnl/dnnl.h"
#include "oneapi/dnnl/dnnl_threadpool.h"

void check(dnnl_status_t s) { if (s != dnnl_success) throw s; }
struct Md {
  dnnl_memory_desc_t p = nullptr;
  Md(dnnl_data_type_t t, const std::vector<dnnl_dim_t>& dims,
     const std::vector<dnnl_dim_t>& strides) {
    check(dnnl_memory_desc_create_with_strides(&p, (int)dims.size(), dims.data(), t, strides.data()));
  }
  ~Md() { dnnl_memory_desc_destroy(p); }
};
struct Run {
  dnnl_engine_t e = nullptr;
  dnnl_stream_t s = nullptr;
  dnnl_primitive_desc_t pd = nullptr;
  dnnl_primitive_t p = nullptr;
  std::vector<dnnl_exec_arg_t> args;
  Run() {
    check(dnnl_engine_create(&e, dnnl_cpu, 0));
    check(dnnl_threadpool_interop_stream_create(&s,e,nullptr));
  }
  ~Run() {
    for (auto a: args) dnnl_memory_destroy(a.memory);
    dnnl_primitive_destroy(p); dnnl_primitive_desc_destroy(pd);
    dnnl_stream_destroy(s); dnnl_engine_destroy(e);
  }
  void arg(int id, void* data) {
    dnnl_memory_t m = nullptr;
    check(dnnl_memory_create(&m,dnnl_primitive_desc_query_md(pd,dnnl_query_exec_arg_md,id),e,data));
    args.push_back({id,m});
  }
  void exec() {
    check(dnnl_primitive_create(&p,pd));
    check(dnnl_primitive_execute(p,s,(int)args.size(),args.data()));
    check(dnnl_stream_wait(s));
  }
};

int main() {
  SetErrorMode(0x8003);
  check(dnnl_threadpool_interop_set_max_concurrency(1));
  std::vector<float> input{-INFINITY,-100,-90,-30,-20,-2,-1,-0.f,0,1,2,20,80,100,INFINITY,NAN,
    std::numeric_limits<float>::lowest(),std::numeric_limits<float>::max()};
  for(int i=-7680;i<=7680;++i) input.push_back(float(i)/64);
  uint32_t state=0x9e3779b9;
  for(size_t i=0;i<100003;++i) {
    state ^= state<<13; state ^= state>>17; state ^= state<<5;
    input.push_back(std::bit_cast<float>(state));
  }
  Md md(dnnl_f32,{static_cast<dnnl_dim_t>(input.size())},{1});
  Run run;
  check(dnnl_eltwise_forward_primitive_desc_create(&run.pd,run.e,dnnl_forward_inference,
       dnnl_eltwise_soft_relu,md.p,md.p,1,0,nullptr));
  for(;;) {
    const char* name=nullptr;
    check(dnnl_primitive_desc_query(run.pd,dnnl_query_impl_info_str,0,&name));
    std::vector<float> output(input.size());
    run.arg(DNNL_ARG_SRC,input.data()); run.arg(DNNL_ARG_DST,output.data()); run.exec();
    size_t wrong=0,special=0,first=0; double maxabs=0,maxrelative=0,wanted=0; float observed=0;
    for(size_t i=0;i<input.size();++i) {
      const double x=input[i];
      const double expected=x>0 ? x+std::log1p(std::exp(-x)) : std::log1p(std::exp(x));
      const float actual=output[i];
      const bool ok=std::isnan(expected) ? std::isnan(actual)
          : std::isinf(expected) ? actual==expected
          : std::abs(actual-expected)<=5e-6*std::abs(expected)+1e-43;
      if(std::isfinite(expected)&&std::isfinite(actual)) {
        maxabs=std::max(maxabs,std::abs(actual-expected));
        if(expected>1e-38) maxrelative=std::max(maxrelative,std::abs(actual-expected)/expected);
      } else if(!ok) ++special;
      if(!ok) { if(!wrong){first=i;observed=actual;wanted=expected;} ++wrong; }
    }
    std::printf("{\"implementation\":\"%s\",\"samples\":%zu,\"mismatches\":%zu,\"special_mismatches\":%zu,\"max_abs\":%.17g,\"max_rel_normal\":%.17g,\"first_index\":%zu,\"actual\":\"%.17g\",\"expected\":\"%.17g\"}\n",name,input.size(),wrong,special,maxabs,maxrelative,first,observed,wanted);
    for(auto arg:run.args) dnnl_memory_destroy(arg.memory);
    run.args.clear(); dnnl_primitive_destroy(run.p); run.p=nullptr;
    const auto status=dnnl_primitive_desc_next_impl(run.pd);
    if(status!=dnnl_success) { std::fprintf(stderr,"iteration_end=%d\n",int(status)); break; }
  }
}
