$ErrorActionPreference = 'Stop'
$probeRoot = 'C:\public\project-hyle\hyle\.scratch\validation\m2-b1-onednn-softplus'
$buildRoot = 'C:\hv\m2od'
$sourceRoot = 'C:\public\tools\hyle-dependencies\v1\sources\onednn-71094df45190-7ee703ecda81'
$vsRoot = 'C:\Program Files\Microsoft Visual Studio\18\Enterprise'
Import-Module -Name (Join-Path $vsRoot 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $vsRoot -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64' | Out-Null
$lib = @(Get-Item -LiteralPath (Join-Path $buildRoot 'bin\dnnl.lib'))
$config = @(Get-ChildItem -LiteralPath (Join-Path $buildRoot '_deps') -Filter 'dnnl_config.h' -File -Recurse)
if ($lib.Count -ne 1 -or $config.Count -ne 1) { throw 'Expected one immutable vendor artifact.' }
$include = $config[0].Directory.Parent.Parent.FullName
Push-Location -LiteralPath $probeRoot
try {
  & cl.exe /nologo /std:c++20 /EHsc- /MD /O2 /DNDEBUG /DDNNL_STATIC ("/I" + (Join-Path $sourceRoot 'include')) ("/I" + $include) qualify.cc /Fe:qualify.exe /Fo:qualify.obj /link $lib[0].FullName advapi32.lib
  if ($LASTEXITCODE -ne 0) { throw "Qualification build failed: $LASTEXITCODE" }
  $crtDirs = @(Get-ChildItem -LiteralPath (Join-Path $env:VCToolsRedistDir 'x64') -Directory -Filter 'Microsoft.VC*.CRT')
  if ($crtDirs.Count -ne 1) { throw 'Expected one CRT directory.' }
  foreach ($dll in Get-ChildItem -LiteralPath $crtDirs[0].FullName -Filter '*.dll' -File) {
    Copy-Item -LiteralPath $dll.FullName -Destination (Join-Path $probeRoot $dll.Name) -Force
  }
  & .\qualify.exe > qualification.jsonl
  if ($LASTEXITCODE -ne 0) { throw "Qualification failed: $LASTEXITCODE" }
} finally { Pop-Location }
