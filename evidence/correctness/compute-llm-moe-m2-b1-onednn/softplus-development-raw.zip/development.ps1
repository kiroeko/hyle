param([ValidateSet('Configure','Build','Test')][string]$Action = 'Configure')
$ErrorActionPreference = 'Stop'
$projectRoot = 'C:\public\project-hyle\hyle'
$buildRoot = 'C:\hv\m2od'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleM2ErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[void][HyleM2ErrorMode]::SetErrorMode(0x8003)
if (-not (Test-Path -LiteralPath $buildRoot)) {
    New-Item -ItemType Directory -Path $buildRoot | Out-Null
    Set-Content -LiteralPath (Join-Path $buildRoot '.hyle-owner') -Value 'M2-B1 oneDNN development; canonical C:\public\project-hyle\hyle; /root' -Encoding utf8
}
if ((Get-Content -LiteralPath (Join-Path $buildRoot '.hyle-owner') -Raw) -notlike 'M2-B1 oneDNN development;*') {
    throw 'The short build directory belongs to another task.'
}
$wrapper = Join-Path $projectRoot 'scripts\hyle-windows.ps1'
if ($Action -eq 'Configure') {
    & $wrapper -Action Configure -BinaryDir $buildRoot -Factor 'compute_provider_onednn,compute_route_cpu,graph_provider_onednn,graph_route_cpu,compute_provider_ggml' -DependencySourceCache 'C:\public\tools\hyle-dependencies\v1' -ExtraArgs @('-DHYLE_STATIC=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_ONEDNN=ON','-DHYLE_WERROR=ON')
} elseif ($Action -eq 'Build') {
    & $wrapper -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','hyle_compute_ops_tests','hyle_compute_provider_onednn_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','hyle_graph_provider_onednn_tests')
} else {
    $dlls = @(Get-ChildItem -LiteralPath $buildRoot -Filter '*.dll' -File -Recurse)
    $dlls += @(Get-ChildItem -LiteralPath 'C:\public\project-hyle\hyle\.scratch\validation\m2-b1-onednn' -Filter '*.dll' -File)
    $executables = @(Get-ChildItem -LiteralPath $buildRoot -Filter 'hyle_*cpu*_test.exe' -File -Recurse)
    $executables += @(Get-ChildItem -LiteralPath $buildRoot -Filter 'hyle_compute_provider_ggml_test.exe' -File -Recurse)
    foreach ($directory in @($executables.DirectoryName | Sort-Object -Unique)) {
        foreach ($dll in $dlls) {
            $destination = Join-Path $directory $dll.Name
            if ($dll.FullName -ne $destination) { Copy-Item -LiteralPath $dll.FullName -Destination $destination -Force }
        }
    }
    & $wrapper -Action Test -BinaryDir $buildRoot -ExtraArgs @('-R','^hyle_(compute_ops|compute_provider_onednn|compute_route_cpu|graph_route_cpu|graph_provider_onednn).*_test$','--output-on-failure','--parallel','1')
}
exit $LASTEXITCODE
