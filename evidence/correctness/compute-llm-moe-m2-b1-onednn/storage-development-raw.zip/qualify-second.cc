#define NOMINMAX
#include <windows.h>
#include <immintrin.h>
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <string>
#include <vector>
#include "oneapi/dnnl/dnnl.h"
#include "oneapi/dnnl/dnnl_threadpool.h"

void check(dnnl_status_t s) { if (s != dnnl_success) throw s; }
struct Md {
  dnnl_memory_desc_t p = nullptr;
  Md(dnnl_data_type_t t, const std::vector<dnnl_dim_t>& dims,
     const std::vector<dnnl_dim_t>& strides) {
    check(dnnl_memory_desc_create_with_strides(&p, (int)dims.size(), dims.data(), t, strides.data()));
  }
  ~Md() { dnnl_memory_desc_destroy(p); }
};
struct Run {
  dnnl_engine_t e = nullptr;
  dnnl_stream_t s = nullptr;
  dnnl_primitive_desc_t pd = nullptr;
  dnnl_primitive_t p = nullptr;
  std::vector<dnnl_exec_arg_t> args;
  Run() {
    check(dnnl_engine_create(&e, dnnl_cpu, 0));
    check(dnnl_threadpool_interop_stream_create(&s,e,nullptr));
  }
  ~Run() {
    for (auto a: args) dnnl_memory_destroy(a.memory);
    dnnl_primitive_destroy(p); dnnl_primitive_desc_destroy(pd);
    dnnl_stream_destroy(s); dnnl_engine_destroy(e);
  }
  void arg(int id, void* data) {
    dnnl_memory_t m = nullptr;
    check(dnnl_memory_create(&m,dnnl_primitive_desc_query_md(pd,dnnl_query_exec_arg_md,id),e,data));
    args.push_back({id,m});
  }
  void exec() {
    check(dnnl_primitive_create(&p,pd));
    check(dnnl_primitive_execute(p,s,(int)args.size(),args.data()));
    check(dnnl_stream_wait(s));
  }
};
float decode(uint16_t u, bool bf) {
  if (bf) return std::bit_cast<float>(uint32_t(u)<<16);
  int exponent=(u>>10)&31;
  float v=exponent==31 ? ((u&1023) ? std::numeric_limits<float>::quiet_NaN() : INFINITY)
                      : std::ldexp(float((u&1023)+(exponent?1024:0)),exponent?exponent-25:-24);
  return (u&0x8000)? -v:v;
}
std::vector<unsigned char> storage(const std::vector<float>& data, dnnl_data_type_t type) {
  if(type==dnnl_f32) { std::vector<unsigned char> r(data.size()*4); std::memcpy(r.data(),data.data(),r.size()); return r; }
  // Inputs use oneDNN reorder; expected arithmetic is computed from the actual stored input below.
  std::vector<unsigned char> r(data.size()*2);
  Run run; Md in(dnnl_f32,{(dnnl_dim_t)data.size()},{1}), out(type,{(dnnl_dim_t)data.size()},{1});
  check(dnnl_reorder_primitive_desc_create(&run.pd,in.p,run.e,out.p,run.e,nullptr));
  run.arg(DNNL_ARG_FROM,const_cast<float*>(data.data())); run.arg(DNNL_ARG_TO,r.data()); run.exec(); return r;
}
float value(const std::vector<unsigned char>& data, size_t i,dnnl_data_type_t type) {
  if(type==dnnl_f32) { float f; std::memcpy(&f,data.data()+i*4,4); return f; }
  uint16_t v; std::memcpy(&v,data.data()+i*2,2); return decode(v,type==dnnl_bf16);
}
void summary(const std::string& name, size_t count, size_t wrong, size_t first, float got, double expected) {
  std::printf("{\"case\":\"%s\",\"status\":\"%s\",\"count\":%zu,\"mismatches\":%zu,\"first_index\":%zu,\"actual\":\"%.17g\",\"expected\":\"%.17g\"}\n",name.c_str(),wrong?"MISMATCH":"PASS",count,wrong,first,got,expected);
}
void numeric(const std::string& label, dnnl_data_type_t t, dnnl_alg_kind_t alg) {
  std::vector<float> a{-INFINITY,-100,-90,-30,-20,-2,-1,-0.f,0,1,2,20,80,100,INFINITY,NAN};
  a.resize(257); for(size_t i=16;i<a.size();++i) a[i]=float(int(i%91)-45)*.125f;
  std::vector<float> b(a.size()); for(size_t i=0;i<b.size();++i) b[i]=a[(i+1)%a.size()];
  auto x=storage(a,t),y=storage(b,t); std::vector<unsigned char> z(x.size());
  Md md(t,{(dnnl_dim_t)a.size()},{1}); Run run;
  bool unary=alg==dnnl_eltwise_soft_relu;
  if(unary) check(dnnl_eltwise_forward_primitive_desc_create(&run.pd,run.e,dnnl_forward_inference,alg,md.p,md.p,1,0,nullptr));
  else check(dnnl_binary_primitive_desc_create(&run.pd,run.e,alg,md.p,md.p,md.p,nullptr));
  run.arg(unary?DNNL_ARG_SRC:DNNL_ARG_SRC_0,x.data()); if(!unary) run.arg(DNNL_ARG_SRC_1,y.data()); run.arg(DNNL_ARG_DST,z.data()); run.exec();
  size_t wrong=0,first=0; float got=0; double wanted=0; double maxabs=0; size_t special=0;
  for(size_t i=0;i<a.size();++i) {
    double av=value(x,i,t),bv=value(y,i,t),expect;
    if(unary) expect=av>0 ? av+std::log1p(std::exp(-av)):std::log1p(std::exp(av));
    else if(alg==dnnl_binary_min) expect=std::fmin(av,bv);
    else if(alg==dnnl_binary_max) expect=std::fmax(av,bv);
    else if(alg==dnnl_binary_eq) expect=av==bv;
    else if(alg==dnnl_binary_ne) expect=av!=bv;
    else if(alg==dnnl_binary_lt) expect=av<bv;
    else expect=av>bv;
    float actual=value(z,i,t); double tol=(t==dnnl_bf16?.008:t==dnnl_f16?.001:2e-6)*std::abs(expect);
    bool ok=std::isnan(expect)?std::isnan(actual):std::isinf(expect)?actual==expect:std::abs(actual-expect)<=tol+(t==dnnl_f16?3e-8:1e-44);
    if(std::isfinite(expect) && std::isfinite(actual)) maxabs=std::max(maxabs,std::abs(actual-expect)); else if(!ok) ++special;
    if(!ok) { if(!wrong){first=i;got=actual;wanted=expect;} ++wrong; }
  }
  summary(label,a.size(),wrong,first,got,wanted); std::fprintf(stderr,"%s max_finite_abs=%.17g special_mismatch=%zu\n",label.c_str(),maxabs,special);
}
void select_case(const std::string& label,dnnl_data_type_t t,dnnl_data_type_t masktype,bool broadcast) {
  constexpr size_t n=257;
  std::vector<float> a(n),b(n); for(size_t i=0;i<n;++i) {a[i]=float(int(i)-128);b[i]=float(192-int(i));}
  a[0]=-0.f; a[1]=std::bit_cast<float>(0x7fc12345u); a[2]=-INFINITY; b[0]=0.f; b[3]=INFINITY;
  auto x=storage(a,t),y=storage(b,t); std::vector<unsigned char> z(x.size());
  std::vector<int32_t> mask(n); std::vector<uint8_t> mask8(n);
  for(size_t i=0;i<n;++i) mask8[i]=uint8_t(mask[i]=(i%3)!=2);
  if(!broadcast) mask[0]=mask8[0]=1;
  Md lhs(t,{1,n},{n,1}),rhs(t,{1,broadcast?dnnl_dim_t(1):dnnl_dim_t(n)},{broadcast?dnnl_dim_t(1):dnnl_dim_t(n),1}),condition(masktype,{1,n},{n,1}),out(t,{1,n},{n,1});
  Run run; check(dnnl_binary_primitive_desc_create_v2(&run.pd,run.e,dnnl_binary_select,lhs.p,rhs.p,condition.p,out.p,nullptr));
  run.arg(DNNL_ARG_SRC_0,x.data()); run.arg(DNNL_ARG_SRC_1,y.data()); run.arg(DNNL_ARG_SRC_2,masktype==dnnl_s32?(void*)mask.data():(void*)mask8.data()); run.arg(DNNL_ARG_DST,z.data()); run.exec();
  size_t width=t==dnnl_f32?4:2,wrong=0,first=0;
  for(size_t i=0;i<n;++i) {auto& input=mask[i]?x:y; size_t k=mask[i]?i:(broadcast?0:i); if(std::memcmp(z.data()+i*width,input.data()+k*width,width)){if(!wrong)first=i; ++wrong;} }
  summary(label,n,wrong,first,0,0);
}
void reorder_case(const std::string& label,dnnl_data_type_t t,bool strided,bool bits=false) {
  size_t n=t==dnnl_f32?257:65536, width=t==dnnl_f32?4:2;
  std::vector<unsigned char> x(n*width*(strided?2:1)),z(n*width);
  for(size_t i=0;i<n;++i) {uint32_t bits=t==dnnl_f32?(i==0?0x80000000u:i==1?0x7fa12345u:std::bit_cast<uint32_t>(float(i)-125.f)):uint32_t(i); std::memcpy(x.data()+i*width*(strided?2:1),&bits,width);}
  Md in(bits?dnnl_u8:t,{(dnnl_dim_t)n,(dnnl_dim_t)(bits?width:1)},{(dnnl_dim_t)((strided?2:1)*(bits?width:1)),1}),out(bits?dnnl_u8:t,{(dnnl_dim_t)n,(dnnl_dim_t)(bits?width:1)},{(dnnl_dim_t)(bits?width:1),1}); Run run;
  check(dnnl_reorder_primitive_desc_create(&run.pd,in.p,run.e,out.p,run.e,nullptr)); run.arg(DNNL_ARG_FROM,x.data());run.arg(DNNL_ARG_TO,z.data());run.exec();
  size_t wrong=0,first=0; for(size_t i=0;i<n;++i) if(std::memcmp(x.data()+i*width*(strided?2:1),z.data()+i*width,width)){if(!wrong)first=i;++wrong;}
  summary(label,n,wrong,first,0,0);
}

void cast_case(const std::string& label, bool bf) {
  const auto type=bf?dnnl_bf16:dnnl_f16;
  std::vector<float> source;
  std::vector<uint16_t> expected;
  for(uint32_t i=0;i<65536;++i) {
    uint16_t u=uint16_t(i); float a=decode(u,bf);
    source.push_back(a); expected.push_back(u);
    // Every finite positive boundary, below / tie / above in F32.
    if(i>=(bf?0x7f7fu:0x7bffu)) continue;
    float b=decode(uint16_t(i+1),bf);
    double midpoint=(double(a)+b)/2;
    float middle=float(midpoint);
    if(!std::isfinite(middle)||double(middle)!=midpoint) continue;
    for(float x:{std::nextafter(middle,-INFINITY),middle,std::nextafter(middle,INFINITY)}) {
      source.push_back(x); expected.push_back(x<middle?u:x>middle?uint16_t(i+1):uint16_t(i+(i&1)));
    }
  }
  std::vector<uint16_t> result(source.size());
  Md in(dnnl_f32,{(dnnl_dim_t)source.size()},{1}),out(type,{(dnnl_dim_t)source.size()},{1});
  Run run; check(dnnl_reorder_primitive_desc_create(&run.pd,in.p,run.e,out.p,run.e,nullptr));
  run.arg(DNNL_ARG_FROM,source.data());run.arg(DNNL_ARG_TO,result.data());run.exec();
  size_t wrong=0,first=0;
  for(size_t i=0;i<source.size();++i) {
    bool ok=std::isnan(source[i])?std::isnan(decode(result[i],bf)):result[i]==expected[i];
    if(!ok) {if(!wrong)first=i;++wrong;}
  }
  summary(label,source.size(),wrong,first,wrong?decode(result[first],bf):0,wrong?decode(expected[first],bf):0);
  std::vector<float> back(source.size());
  Run up; check(dnnl_reorder_primitive_desc_create(&up.pd,out.p,up.e,in.p,up.e,nullptr));
  up.arg(DNNL_ARG_FROM,expected.data());up.arg(DNNL_ARG_TO,back.data());up.exec();
  wrong=0; first=0;
  for(size_t i=0;i<back.size();++i) {float expected_value=decode(expected[i],bf); bool ok=std::isnan(expected_value)?std::isnan(back[i]):std::bit_cast<uint32_t>(back[i])==std::bit_cast<uint32_t>(expected_value);if(!ok){if(!wrong)first=i;++wrong;}}
  summary(label+"/widen",back.size(),wrong,first,wrong?back[first]:0,wrong?decode(expected[first],bf):0);
}

template<class F> void trial(const std::string& name,F f) { try{f();}catch(dnnl_status_t code){std::printf("{\"case\":\"%s\",\"status\":\"REJECTED\",\"dnnl_status\":%d}\n",name.c_str(),int(code));} }
int main(){
 SetErrorMode(0x8003); std::fprintf(stderr,"MXCSR=%08x\n",_mm_getcsr()); check(dnnl_threadpool_interop_set_max_concurrency(1));
 for(bool bf:{false,true}) {std::string name=bf?"cast/f32-bf16":"cast/f32-f16";trial(name,[&]{cast_case(name,bf);});}
 for(auto t:{dnnl_f32,dnnl_f16,dnnl_bf16}) {
  std::string type=t==dnnl_f32?"f32":t==dnnl_f16?"f16":"bf16";
  for(auto [alg,n]:{std::pair{dnnl_eltwise_soft_relu,"softplus"}, {dnnl_binary_min,"min"},{dnnl_binary_max,"max"},{dnnl_binary_eq,"eq"},{dnnl_binary_ne,"ne"},{dnnl_binary_lt,"lt"},{dnnl_binary_gt,"gt"}}) {auto name=type+"/"+n;trial(name,[&]{numeric(name,t,alg);});}
  for(auto mask:{dnnl_s8,dnnl_u8,dnnl_s32}) for(bool broad:{false,true}) {auto name=type+"/select/"+(mask==dnnl_u8?"u8":mask==dnnl_s8?"s8":"s32")+(broad?"/broadcast":"/dense");trial(name,[&]{select_case(name,t,mask,broad);});}
  for(bool stride:{false,true}) {auto name=type+"/copy/"+(stride?"strided":"dense");trial(name,[&]{reorder_case(name,t,stride);}); auto raw=name+"/raw-bytes";trial(raw,[&]{reorder_case(raw,t,stride,true);});}
 }
}
