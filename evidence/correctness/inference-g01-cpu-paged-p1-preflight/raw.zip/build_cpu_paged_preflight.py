from pathlib import Path
import json, os, subprocess, time

root=Path.cwd();out=root/'.scratch/inference-gaps/g01';env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1);env[key]=value
native=root/'.scratch/build-compute-v2-dev/src/compute_ggml_runtime/source-8dd0d23581da1b0b/include'
assert native.is_dir()
assert b'hyle_flash_row_offset' in (native.parent/'src/ggml-cpu/ops.cpp').read_bytes()
build=Path('C:/h7/g01-cpu-paged-preflight');record=out/'cpu-paged-preflight-build-result.json'
rows=json.loads(record.read_text())['stages'] if record.exists() else []
commands=[('configure',['cmake','-S',str(root/'bench/inference_resident_sdpa/cpu_paged_p1'),'-B',str(build),'-G','Ninja',
 '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=C:/h7/g01-paged-static-sdk/relocated',
 '-DHYLE_CPU_ORIGINAL_REFERENCE_SOURCE='+str(out/'original-ggml-cpu-peer'),
 '-DHYLE_CPU_PAGED_NATIVE_INCLUDE='+str(native),
 '-DHYLE_CPU_PAGED_ORIGINAL_DLL=C:/h7/g01-cpu-paged-original-build/bin/g01_cpu_paged_original.dll']),
 ('build',['cmake','--build',str(build),'--target','g01_cpu_paged_bench','g01_cpu_paged_bench_placement','g01_cpu_paged_perf_control','--parallel','4'])]
for name,args in commands:
 if name=='configure' and next((x for x in reversed(rows) if x['stage']=='configure'),{}).get('exit_code')==0:
  continue
 attempt=1+sum(x['stage']==name for x in rows);log=out/f'cpu-paged-preflight-{name}-{attempt}.log';start=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)}
 rows.append(row);record.write_text(json.dumps({'candidate':'1e9cdfd45307ea4a15b92374377ad2b268203193','stages':rows},indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-3400));print(f.read(3400).decode(errors='replace'))
  raise SystemExit(r.returncode)
