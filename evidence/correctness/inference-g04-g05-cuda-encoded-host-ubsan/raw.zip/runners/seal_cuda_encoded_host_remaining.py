from pathlib import Path
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';SAN=BASE/'cuda-host-san'
mode=sys.argv[1];assert mode in ('ubsan','tsan')
attempts=sorted(SAN.glob(mode+'-*'),key=lambda p:int(p.name.rsplit('-',1)[1]))
assert attempts
records=[json.loads((p/'result.json').read_text()) for p in attempts]
assert records[-1]['state']=='TERMINAL_PASS'
assert all(r['state'].startswith('TERMINAL_') for r in records)
asan=json.loads((ROOT/'evidence/correctness/inference-g04-g05-cuda-encoded-host-asan/receipt.json').read_text())
assert all(r['inputs']==asan['inputs'] for r in records),'risk matrix inputs changed'
last=attempts[-1];final=records[-1]
tests=ET.parse(last/'tests.xml').getroot()
assert int(tests.attrib['tests'])==13
assert all(int(tests.attrib.get(k,0))==0 for k in ('failures','errors','disabled'))
risks=(last/'five-risk-modes.log').read_text()
assert sum(line.endswith(' PASS') for line in risks.splitlines())==5
assert all(s['exit_code']==0 for s in final['stages'])
assert set(final['binaries'])=={'g04_cuda_encoded_host_tests','g04_cuda_encoded_host_risks'}
dest=ROOT/f'evidence/correctness/inference-g04-g05-cuda-encoded-host-{mode}'
dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for folder in attempts:
  for p in sorted(folder.rglob('*')):
   if p.is_file():package.write(p,folder.name+'/'+p.relative_to(folder).as_posix())
 for name in ('encoded_cuda_host_san.py','launch_encoded_cuda_host_san.py','seal_cuda_encoded_host_remaining.py'):
  package.write(BASE/name,'runners/'+name)
receipt={'kind':f'G04_G05_CUDA_ENCODED_HOST_{mode.upper()}_STAGE',
 'verdict':'PASS_UNDEFINED_FACET' if mode=='ubsan' else 'PASS_DATA_RACE_FACET',
 'identity':final['identity'],'inputs':final['inputs'],
 'source_archive':{'path':'evidence/correctness/inference-g04-g05-cuda-encoded-host-asan/raw.zip!source-asan-1.zip',
  'sha256':hashlib.sha256((SAN/'source-asan-1.zip').read_bytes()).hexdigest()},
 'runs':[{'attempt':p.name,'state':r['state'],'stages':r['stages'],
  'cumulative_seconds':r['cumulative_seconds'],'setup_error':r.get('setup_error'),
  'setup_error_elapsed_seconds':r.get('setup_error_elapsed_seconds')} for p,r in zip(attempts,records)],
 'cumulative_measured_seconds':sum(r['cumulative_seconds'] for r in records),
 'unknown_setup_time_attempts':[p.name for p,r in zip(attempts,records)
  if r.get('setup_error') and r.get('setup_error_elapsed_seconds') is None],
 'math_and_common_tests':13,'source_risk_modes':5,'environment':final['environment'],
 'reused_archive':final['reused_ggml_cuda'],'binaries':final['binaries'],
 'limits':[s for s in final['limits'] if not s.startswith('ASan address facet')]+[
  'Original NVIDIA process LSan remains INCONCLUSIVE; no driver/shader/private-pool certificate',
  'Frozen inputs predate CPU-only CE12; no CE12 CPU runtime claim; not whole G04/G05'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('inputs','runs','identity','binaries')}))
