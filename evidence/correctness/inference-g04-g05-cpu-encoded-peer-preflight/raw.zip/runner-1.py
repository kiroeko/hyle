from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'cpu-encoded-preflight';OUT.mkdir(exist_ok=True)
attempt=sys.argv[1] if len(sys.argv)>1 else '1';result=OUT/f'result-{attempt}.json';assert not result.exists()
build=Path('C:/h7')/f'g04-cpu-encoded-check-{attempt}';assert not build.exists()
setup=subprocess.check_output(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
identity=json.loads((ROOT/'.scratch/inference-gaps/g01/cpu-paged-original-identity.json').read_text(encoding='utf-8'))
for name,sha in identity['original_dlls'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
artifacts=json.loads((BASE/'cpu-sdk/artifacts-cpu-static-1.json').read_text(encoding='utf-8'))
for row in artifacts:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
source=ROOT/'bench/inference_resident_sdpa/cpu_encoded_p1';sdk=Path('C:/h7/g04-sdk-cpu-static-1/relocated')
native=ROOT/'.scratch/build-compute-v2-dev/src/compute_ggml_runtime/source-8570887ac0d71134/include';assert (native/'ggml.h').exists()
record={'state':'RUNNING','attempt':attempt,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'product_commit':'f772fcad2f2a6a67aa605bbaee10b68f1d540708','build':str(build),'max_jobs':4,'claim':'Only adapter configure/build and independent oracle; no timing/P1','stages':[],'cumulative_seconds':0,'original_dlls':identity['original_dlls'],'candidate_sdk_artifacts':artifacts}
for name in ['bench/inference_resident_sdpa/cpu_encoded_bench.cc','bench/inference_resident_sdpa/cpu_paged_reference.cc','bench/inference_resident_sdpa/cpu_paged_original_execution.h','bench/inference_resident_sdpa/cpu_encoded_p1/CMakeLists.txt']:
 record.setdefault('inputs',[]).append({'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()})
(OUT/f'runner-{attempt}.py').write_bytes(Path(__file__).read_bytes())
def run(stage,args):
 log=OUT/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('wb') as f:
  process=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  (OUT/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}))
  print(stage,process.pid,flush=True);code=process.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed;record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 record['state']='TERMINAL_FAIL' if code else 'RUNNING';result.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
 print(stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
 if code:
  (OUT/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}))
  print(log.read_text(encoding='utf-8',errors='replace')[-6500:]);raise SystemExit(code)
run('configure',['cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DHYLE_CPU_PAGED_NATIVE_INCLUDE='+str(native),'-DHYLE_CPU_ORIGINAL_REFERENCE_SOURCE='+str(ROOT/'.scratch/inference-gaps/g01/original-ggml-cpu-peer'),'-DHYLE_CPU_PAGED_ORIGINAL_DLL=C:/h7/g01-cpu-paged-original-build/bin/g01_cpu_paged_original.dll'])
run('build',['cmake','--build',str(build),'--target','g04_cpu_encoded_bench','g04_cpu_encoded_bench_placement','g04_cpu_encoded_perf_control','--parallel','4'])
env['HYLE_BENCH_VERIFY_ONLY']='1'
for target in ('g04_cpu_encoded_bench','g04_cpu_encoded_bench_placement'):run(target,[str(build/(target+'.exe'))])
record['state']='TERMINAL_PASS';result.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');(OUT/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS'}))
print('FINITE Q8 ADAPTER ORACLES PASS; no sampling',flush=True)
