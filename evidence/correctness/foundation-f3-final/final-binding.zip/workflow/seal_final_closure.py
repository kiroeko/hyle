from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'
audit = json.loads((scratch / 'final-evidence-audit.json').read_text())
assert len(audit['reviewed_receipts']) == 37 and audit['current_sdk_cells'] == 12 and audit['actual_math_sdk_cells'] == 10
candidate = audit['product_candidate']
assert candidate == '97858fbc88a6b5a87f109290b956eeaeee632dd2'
assert not subprocess.check_output(['git', 'diff', '--name-only', candidate, 'HEAD', '--', 'src', 'include', 'cmake', 'CMakeLists.txt'])
loc = json.loads((scratch / 'loc-final-six-owners.json').read_text(encoding='utf-8-sig'))
assert loc['self_check'] == 'pass'
assert set(loc['module']['modules']) == {'compute', 'compute_stream', 'compute_route_cpu', 'compute_route_cuda', 'compute_route_apple', 'compute_route_vulkan'}
assert not subprocess.check_output(['git', 'diff', '--name-only', candidate, loc['repository']['commit'], '--', 'src', 'include', 'cmake', 'CMakeLists.txt'])
out = repo / 'evidence/correctness/foundation-f3-final'; out.mkdir(parents=True, exist_ok=True)
(out / 'evidence-audit.json').write_bytes((scratch / 'final-evidence-audit.json').read_bytes())
(out / 'loc-current.json').write_bytes((scratch / 'loc-final-six-owners.json').read_bytes())
archive = out / 'final-binding.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for name in ['final-evidence-audit.json', 'loc-final-six-owners.json', 'suffix-candidate-binding.json', 'suffix-audited-binding.json']:
        packed.writestr(name, (scratch / name).read_bytes())
    for name in ['audit_final_evidence.py', 'seal_final_closure.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1, 'product_candidate': candidate, 'product_tree': audit['product_tree'],
    'original_baseline': 'a932606ee5796328742632e392d5c6c5595ce3fb',
    'owners': loc['module']['modules'], 'scope': 'Original F3 eight FIX only; F1 eight and F2 seven remain previously CLOSED, goal total twenty-three. No F4/F5/full inference engine or original R1-R7 reopen.',
    'source_receipts': audit['reviewed_receipts'],
    'requirements': {'F3-01': 'PASS component graph/natural factories/ordinary routes/new headers/three deliveries',
                     'F3-02': 'PASS fixed capacities/owners/preflight/byte accounting/OOM',
                     'F3-03': 'PASS actual positional/mapping/early-ready/EOF/direct IO; macOS direct-data NOT_APPLICABLE with actual original refusal',
                     'F3-04': 'PASS producer->resource->file, actual short write/byte oracle/reload',
                     'F3-05': 'PASS retained results/backpressure/two groups/two slots/native actual retirement',
                     'F3-06': 'PASS cancel/deadline/close/abandon/late/unknown/suffix corrected',
                     'F3-07': 'PASS all qualified routes actual original Direct+Graph mixed dtype/math and native cost',
                     'F3-08': 'PASS official/mature format consumers/docs/new headers/relocation/absence/runtime/P0/red team'},
    'gates': {'scope': 'PASS', 'architecture': 'PASS', 'correctness': 'PASS', 'delivery': 'PASS',
              'usability_docs': 'PASS', 'red_team': 'PASS', 'engineering_performance': 'PASS_P0'},
    'native_risks': {'Windows_CUDA': 7, 'WSL_CUDA': 7, 'Air_Apple': 6, 'Windows_Vulkan': 5, 'Air_Vulkan': 5},
    'common_risks': {'Windows_CPU': 13, 'WSL_ASan': 14, 'WSL_UBSan': 14, 'WSL_TSan': 14, 'Air_CPU': 14},
    'deliveries': {'qualified_profiles_times_linkage': 10, 'actual_gpu_math': 10, 'software_vulkan_applicable_cells': 2,
                   'ordinary_source': 'All applicable qualified route/machine journeys actual; WSL software Vulkan source consumers build/ldd only, no qualified GPU math.'},
    'cost': 'Known fixed K/stage/control/backing accounting, existing Task/IO/lease/stack costs explicit; one suffix fix adds O(QGR) scan. Driver/vendor private metadata/physical residency UNKNOWN, no P1/time winner.',
    'original_failures': 'All original F3 errors/timeouts and abort6 retained; owner legally returned to AUDITED before one focused suffix correction, requalified before candidate. No raw failure replacement or budget reset.',
    'audit': {'path': (out / 'evidence-audit.json').relative_to(repo).as_posix(), 'sha256': hashlib.sha256((out / 'evidence-audit.json').read_bytes()).hexdigest()},
    'loc': {'path': (out / 'loc-current.json').relative_to(repo).as_posix(), 'sha256': hashlib.sha256((out / 'loc-current.json').read_bytes()).hexdigest(), 'self_check': 'PASS', 'product_equivalent_snapshot': loc['repository']['commit']},
    'binding_archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'limits': 'Named exact machines/routes/ranges only; no complete model/FFN/tokenizer/generation, GPU sanitizer, driver memory-zero or throughput qualification. WSL software Vulkan GPU math and macOS portable direct data are NOT_APPLICABLE.',
    'cleanup': 'Automatic review rejected removal of own extra scratch copy; preserved directory, no bypass. Product qualification unaffected.',
    'verdict': 'PASS_ORIGINAL_F3_EIGHT_FIX_AND_SEVEN_GATES_P0'}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('Original eight FIX/seven gates bound to current product, thirty-seven source receipts and immutable LOC.')
