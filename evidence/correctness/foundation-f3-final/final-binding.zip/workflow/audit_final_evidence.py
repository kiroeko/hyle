from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

repo = Path.cwd(); candidate = '97858fbc88a6b5a87f109290b956eeaeee632dd2'
assert not subprocess.check_output(['git', 'diff', '--name-only', candidate, 'HEAD', '--', 'src', 'include', 'cmake', 'CMakeLists.txt'])
sdk = list((repo / 'evidence/correctness').glob('foundation-f3-sdk-*/receipt.json'))
current = [p for p in sdk if json.loads(p.read_text())['product_commit'] == candidate]
assert len(current) == 12
actual_math = [p for p in current if not (json.loads(p.read_text())['host'] == 'wsl' and json.loads(p.read_text())['profile'] == 'vulkan')]
assert len(actual_math) == 10
reviewed = []
for file in sorted((repo / 'evidence/correctness').glob('foundation-f3*/receipt.json')):
    receipt = json.loads(file.read_text(encoding='utf-8'))
    archives = []
    def visit(value):
        if isinstance(value, dict):
            path, digest = value.get('path'), value.get('sha256')
            if isinstance(path, str) and isinstance(digest, str) and path.startswith('evidence/'):
                artifact = repo / path
                assert artifact.is_file(), path
                assert hashlib.sha256(artifact.read_bytes()).hexdigest() == digest, path
                archives.append(path)
                if artifact.suffix == '.zip':
                    with zipfile.ZipFile(artifact) as packed:
                        assert packed.testzip() is None
            for child in value.values(): visit(child)
        elif isinstance(value, list):
            for child in value: visit(child)
    visit(receipt)
    reviewed.append({'receipt': file.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
                     'verdict': receipt.get('verdict'), 'verified_artifacts': archives})
output = {'schema_version': 1, 'product_candidate': candidate,
    'product_tree': subprocess.check_output(['git', 'rev-parse', candidate + '^{tree}'], text=True).strip(),
    'product_diff_to_current_head': [], 'current_sdk_cells': len(current), 'actual_math_sdk_cells': len(actual_math),
    'software_vulkan_cells': 2, 'source_receipts': ['foundation-f3-final-source', 'foundation-f3-sdk-windows-cpu-cuda-static-f6db4d5b2'],
    'reviewed_receipts': reviewed, 'verdict': 'PASS_DECLARED_RECEIPT_AND_ARCHIVE_INTEGRITY_ONLY',
    'limit': 'Artifact integrity does not alone prove semantic coverage; final matrix and red team make the original FIX/gate dispositions.'}
(repo / '.scratch/foundation-f3/final-evidence-audit.json').write_text(json.dumps(output, indent=2))
print(len(reviewed), 'F3 receipts verified;', len(current), 'current SDK cells,', len(actual_math), 'actual math SDK cells; current product unchanged.')
