from pathlib import Path
import hashlib, json, urllib.request, zipfile
root=Path('C:/hv/m2vk-tools')
root.mkdir(exist_ok=True)
marker=root/'owner.txt'
expected='M2-B1 Vulkan original precision compiler tools; /root\n'
if marker.exists(): assert marker.read_text()==expected
else:
 assert not any(root.iterdir())
 marker.write_text(expected)
rows=json.loads(Path('.scratch/validation/m1-vulkan-admission/downloads.json').read_text())
receipt=[]
for row in rows:
 if not row['name'].endswith('win_amd64.whl'): continue
 path=root/row['name']
 if not path.exists():
  request=urllib.request.Request(row['url'],headers={'User-Agent':'HYLE-M2-precision-qualification'})
  with urllib.request.urlopen(request,timeout=40) as incoming, path.with_suffix('.partial').open('wb') as output:
   while chunk:=incoming.read(1024*1024): output.write(chunk)
  path.with_suffix('.partial').replace(path)
 assert path.stat().st_size==row['bytes']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
 with zipfile.ZipFile(path) as archive:
  assert archive.testzip() is None
  for name in archive.namelist(): assert (root/name).resolve().is_relative_to(root.resolve())
  archive.extractall(root)
 receipt.append({**row,'path':str(path)})
 print('VERIFIED',row['name'],flush=True)
Path('.scratch/validation/m2-b1-vulkan-precision/tools.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
