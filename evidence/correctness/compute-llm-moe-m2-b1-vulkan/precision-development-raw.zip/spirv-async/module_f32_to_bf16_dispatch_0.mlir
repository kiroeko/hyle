hal.executable public @f32_to_bf16_dispatch_0 {
  hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,ext:SPV_KHR_16bit_storage", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
    hal.executable.export public @f32_to_bf16_dispatch_0_elementwise_D_f32xi16 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
      hal.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @f32_to_bf16_dispatch_0_elementwise_D_f32xi16() {
        %c32_i64 = arith.constant 32 : i64
        %c0 = arith.constant 0 : index
        %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
        %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
        %2 = arith.extui %1 : i32 to i64
        %3 = arith.shli %2, %c32_i64 : i64
        %4 = arith.extui %0 : i32 to i64
        %5 = arith.ori %4, %3 : i64
        %6 = arith.index_castui %5 : i64 to index
        %7 = util.assume.int %6<umin = 0, umax = 9007199254740991> : index
        %8 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
        %9 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%8}
        %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%8}
        %11 = iree_tensor_ext.dispatch.tensor.load %9, offsets = [0], sizes = [%8], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%8} -> tensor<?xf32>
        %12 = tensor.empty(%8) : tensor<?xi16>
        %13 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%11 : tensor<?xf32>) outs(%12 : tensor<?xi16>) {
        ^bb0(%in: f32, %out: i16):
          %14 = arith.truncf %in : f32 to bf16
          %15 = arith.bitcast %14 : bf16 to i16
          linalg.yield %15 : i16
        } -> tensor<?xi16>
        iree_tensor_ext.dispatch.tensor.store %13, %10, offsets = [0], sizes = [%8], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%8}
        return
      }
    }
  }
}
