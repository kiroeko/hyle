$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath 'C:\public\project-hyle\hyle').Path
$buildRoot = (Resolve-Path -LiteralPath 'C:\hv\m2vk').Path
$toolsRoot = (Resolve-Path -LiteralPath 'C:\hv\m2vk-tools').Path
if ((Get-Content -LiteralPath (Join-Path $buildRoot '.hyle-owner') -Raw).Trim() -ne 'M2-B1 Vulkan development; canonical C:\public\project-hyle\hyle; /root') { throw 'Build owner mismatch' }
if ((Get-Content -LiteralPath (Join-Path $toolsRoot 'owner.txt') -Raw).Trim() -ne 'M2-B1 Vulkan original precision compiler tools; /root') { throw 'Compiler owner mismatch' }
if (Get-Process -Name 'hyle_m2_precision_qualification' -ErrorAction SilentlyContinue) { throw 'Qualification process is still running' }
$targets = @(
    (Join-Path $buildRoot 'bin\hyle_m2_precision_qualification.exe'),
    (Join-Path $projectRoot '.scratch\validation\m2-b1-vulkan-precision\qualify.obj'),
    (Join-Path $toolsRoot 'iree_base_compiler-3.12.0rc20260919-cp312-abi3-win_amd64.whl'),
    (Join-Path $toolsRoot 'iree_base_runtime-3.12.0rc20260919-cp312-abi3-win_amd64.whl')
)
$removed = @()
foreach ($target in $targets) {
    if (-not (Test-Path -LiteralPath $target)) { continue }
    $resolved = (Resolve-Path -LiteralPath $target).Path
    $item = Get-Item -LiteralPath $resolved
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Expected an ordinary task-owned file' }
    if (-not ($resolved.StartsWith($buildRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or $resolved.StartsWith($toolsRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or $resolved.StartsWith((Join-Path $projectRoot '.scratch\validation\m2-b1-vulkan-precision') + '\', [StringComparison]::OrdinalIgnoreCase))) { throw 'Cleanup target escapes task roots' }
    $removed += [pscustomobject]@{ path = $resolved; bytes = $item.Length; sha256 = (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant() }
    Remove-Item -LiteralPath $resolved -Force
}
$removed | ConvertTo-Json -Depth 4
