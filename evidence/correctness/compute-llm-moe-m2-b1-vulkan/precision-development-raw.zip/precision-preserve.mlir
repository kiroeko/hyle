module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #hal.device.target<"vulkan", [#hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>]> : !hal.device
  hal.executable private @f32_to_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @f32_to_bf16_dispatch_0_elementwise_D_f32xi16 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @f32_to_bf16_dispatch_0_elementwise_D_f32xi16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = util.assume.int %6<umin = 0, umax = 9007199254740991> : index
          %8 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
          %9 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%8}
          %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%8}
          %11 = iree_tensor_ext.dispatch.tensor.load %9, offsets = [0], sizes = [%8], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%8} -> tensor<?xf32>
          %12 = tensor.empty(%8) : tensor<?xi16>
          %13 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%11 : tensor<?xf32>) outs(%12 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: i16):
            %14 = arith.truncf %in : f32 to bf16
            %15 = arith.bitcast %14 : bf16 to i16
            linalg.yield %15 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %13, %10, offsets = [0], sizes = [%8], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%8}
          return
        }
        iree_codegen.dispatch_config @f32_to_bf16_dispatch_0_elementwise_D_f32xi16 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @f32_to_bf16(%arg0: !hal.buffer_view, %arg1: !hal.fence, %arg2: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @f32_to_bf16(%input0: tensor<?xf32>) -> (%output0: tensor<?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0]) type(%element_type_f32) encoding(%dense_row_major)
    %1 = arith.muli %0, %c4 : index
    %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?xf32>{%0} in !stream.resource<external>{%1}
    %3 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg1 : (!hal.fence) => !stream.timepoint
    %4 = arith.muli %0, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%3) => !stream.resource<external>{%4} => !stream.timepoint
    %5 = arith.index_castui %0 : index to i64
    %6 = arith.index_castui %0 : index to i32
    %7 = arith.shrui %5, %c32_i64 : i64
    %8 = arith.trunci %7 : i64 to i32
    %9 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%2 as %arg3: !stream.resource<external>{%1}, %result as %arg4: !stream.resource<external>{%4}) {
      stream.cmd.dispatch @f32_to_bf16_dispatch_0::@vulkan_spirv_fb::@f32_to_bf16_dispatch_0_elementwise_D_f32xi16[%0](%6, %8 : i32, i32) {
        ro %arg3[%c0 for %1] : !stream.resource<external>{%1},
        wo %arg4[%c0 for %4] : !stream.resource<external>{%4}
      }
    } => !stream.timepoint
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %9 => (%arg2 : !hal.fence)
    %10 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?xi16>{%0} in !stream.resource<external>{%4} -> !hal.buffer_view
    util.return %10 : !hal.buffer_view
  }
  hal.executable private @f16_to_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @f16_to_bf16_dispatch_0_elementwise_D_f16xi16 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @f16_to_bf16_dispatch_0_elementwise_D_f16xi16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = util.assume.int %6<umin = 0, umax = 9007199254740991> : index
          %8 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
          %9 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf16>>{%8}
          %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%8}
          %11 = iree_tensor_ext.dispatch.tensor.load %9, offsets = [0], sizes = [%8], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf16>>{%8} -> tensor<?xf16>
          %12 = tensor.empty(%8) : tensor<?xi16>
          %13 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%11 : tensor<?xf16>) outs(%12 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f16, %out: i16):
            %14 = arith.extf %in : f16 to f32
            %15 = arith.truncf %14 : f32 to bf16
            %16 = arith.bitcast %15 : bf16 to i16
            linalg.yield %16 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %13, %10, offsets = [0], sizes = [%8], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%8}
          return
        }
        iree_codegen.dispatch_config @f16_to_bf16_dispatch_0_elementwise_D_f16xi16 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @f16_to_bf16(%arg0: !hal.buffer_view, %arg1: !hal.fence, %arg2: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @f16_to_bf16(%input0: tensor<?xf16>) -> (%output0: tensor<?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %element_type_f16 = hal.element_type<f16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0]) type(%element_type_f16) encoding(%dense_row_major)
    %1 = arith.muli %0, %c2 : index
    %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?xf16>{%0} in !stream.resource<external>{%1}
    %3 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg1 : (!hal.fence) => !stream.timepoint
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%3) => !stream.resource<external>{%1} => !stream.timepoint
    %4 = arith.index_castui %0 : index to i64
    %5 = arith.index_castui %0 : index to i32
    %6 = arith.shrui %4, %c32_i64 : i64
    %7 = arith.trunci %6 : i64 to i32
    %8 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%2 as %arg3: !stream.resource<external>{%1}, %result as %arg4: !stream.resource<external>{%1}) {
      stream.cmd.dispatch @f16_to_bf16_dispatch_0::@vulkan_spirv_fb::@f16_to_bf16_dispatch_0_elementwise_D_f16xi16[%0](%5, %7 : i32, i32) {
        ro %arg3[%c0 for %1] : !stream.resource<external>{%1},
        wo %arg4[%c0 for %1] : !stream.resource<external>{%1}
      }
    } => !stream.timepoint
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %8 => (%arg2 : !hal.fence)
    %9 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?xi16>{%0} in !stream.resource<external>{%1} -> !hal.buffer_view
    util.return %9 : !hal.buffer_view
  }
}