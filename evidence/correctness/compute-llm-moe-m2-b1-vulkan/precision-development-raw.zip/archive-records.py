from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
destination = root.parents[2] / 'evidence/correctness/compute-llm-moe-m2-b1-vulkan/precision-development-raw.zip'
excluded = {'.obj', '.exe', '.dll', '.whl', '.zip', '.gz'}
files = sorted(p for p in root.rglob('*') if p.is_file() and p.suffix not in excluded)
manifest = []
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        name = path.relative_to(root).as_posix()
        data = path.read_bytes()
        archive.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    archive.writestr('RAW-MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for row in manifest:
        assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
print(json.dumps({'archive': str(destination), 'bytes': destination.stat().st_size,
                  'files': len(manifest), 'crc_and_sha256': 'PASS'}))
