#include "native_graph.h"
#include "ggml-backend.h"
#include "ggml.h"
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <fstream>
#include <limits>
#include <memory>
#include <random>
#include <span>
#include <vector>
#include <windows.h>

using namespace hyle::compute::ggml_vulkan::detail;

double decode(std::uint16_t bits, bool bfloat) {
  if (bfloat) return std::bit_cast<float>(std::uint32_t(bits) << 16);
  const auto exponent = (bits >> 10) & 31;
  const auto fraction = bits & 1023;
  const double sign = bits & 0x8000 ? -1.0 : 1.0;
  if (exponent == 31)
    return fraction ? std::numeric_limits<double>::quiet_NaN()
                    : sign * std::numeric_limits<double>::infinity();
  return sign * (exponent ? std::ldexp(1.0 + fraction / 1024.0, exponent - 15)
                         : std::ldexp(double(fraction), -24));
}
std::uint16_t encode(float value, bool bfloat) {
  const std::uint16_t sign = std::signbit(value) ? 0x8000 : 0;
  const std::uint16_t infinity = bfloat ? 0x7f80 : 0x7c00;
  if (std::isnan(value)) return sign | infinity | 1;
  const double x = std::abs(double(value));
  const auto last = std::uint16_t(infinity - 1);
  const auto threshold = decode(last, bfloat) + std::ldexp(1.0, bfloat ? 119 : 4);
  if (x >= threshold) return sign | infinity;
  std::uint16_t low = 0, high = last;
  while (low < high) {
    const auto middle = std::uint16_t((std::uint32_t(low) + high + 1) / 2);
    if (decode(middle, bfloat) <= x) low = middle;
    else high = middle - 1;
  }
  if (low != last) {
    const auto midpoint = (decode(low, bfloat) + decode(low + 1, bfloat)) / 2;
    if (x > midpoint || (x == midpoint && (low & 1))) ++low;
  }
  return sign | low;
}

std::vector<std::byte> run(const NativeDevice &device, ggml_type source,
                          ggml_type target, std::size_t count,
                          std::span<const std::byte> payload) {
  auto arena = MetadataArena::create(16 * ggml_tensor_overhead() +
      ggml_graph_overhead_custom(16, false), hyle::mem::system_allocator()).value();
  auto active = device.activate();
  auto *input = ggml_new_tensor_1d(arena.get(), source, std::int64_t(count));
  auto *output = source == target ? ggml_dup(arena.get(), input)
                                  : ggml_cast(arena.get(), input, target);
  ggml_set_input(input);
  ggml_set_output(output);
  auto buffer = device.allocate_buffer(ggml_nbytes(input)).value();
  auto owner = std::shared_ptr<ggml_backend_buffer>(buffer,
      [device](auto *pointer) { auto scope = device.activate(); ggml_backend_buffer_free(pointer); });
  if (ggml_backend_tensor_alloc(buffer, input, ggml_backend_buffer_get_base(buffer)) != GGML_STATUS_SUCCESS)
    throw std::runtime_error("input allocation");
  auto *graph = ggml_new_graph_custom(arena.get(), 16, false);
  ggml_build_forward_expand(graph, output);
  auto storage = NativeGraph::allocate(device, std::move(arena), graph, owner).value();
  ggml_backend_tensor_set(input, payload.data(), 0, payload.size());
  auto work = device.create_work().value();
  auto status = work.submit(storage.get(), storage.lease()).status;
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
  status = work.wait().status;
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
  std::vector<std::byte> bytes(ggml_nbytes(output));
  ggml_backend_tensor_get(output, bytes.data(), 0, bytes.size());
  return bytes;
}

int main() {
  SetErrorMode(0x8003);
  try {
    auto device = NativeDevice::create().value();
    std::vector<std::uint16_t> raw(65537);
    for (std::size_t i = 0; i < raw.size(); ++i) raw[i] = std::uint16_t(i);
    std::vector<float> narrow;
    for (bool bfloat : {false, true}) {
      const auto last = bfloat ? 0x7f7fU : 0x7bffU;
      for (unsigned i = 0; i < last; ++i) {
        const auto halfway = float((decode(std::uint16_t(i), bfloat) + decode(std::uint16_t(i + 1), bfloat)) / 2);
        for (float value : {std::nextafter(halfway, 0.0f), halfway,
                            std::nextafter(halfway, std::numeric_limits<float>::infinity())}) {
          narrow.push_back(value); narrow.push_back(-value);
        }
      }
    }
    for (std::uint32_t bits : {0U, 0x80000000U, 1U, 0x7f800000U, 0xff800000U,
                              0x7f800001U, 0x7fffffffU, 0xffffffffU, 0x7fc00000U})
      narrow.push_back(std::bit_cast<float>(bits));
    std::mt19937 random(20260921);
    for (int i = 0; i < 65536; ++i) narrow.push_back(std::bit_cast<float>(std::uint32_t(random())));
    std::ofstream("narrow-input.bin", std::ios::binary).write(
        reinterpret_cast<const char *>(narrow.data()), narrow.size() * sizeof(float));
    std::vector<std::uint16_t> bfloat_oracle;
    for (float value : narrow) bfloat_oracle.push_back(encode(value, true));
    std::ofstream("bfloat-oracle.bin", std::ios::binary).write(
        reinterpret_cast<const char *>(bfloat_oracle.data()), bfloat_oracle.size() * 2);
    for (auto type : {GGML_TYPE_F16, GGML_TYPE_BF16}) {
      const bool bfloat = type == GGML_TYPE_BF16;
      auto copied = run(device, type, type, raw.size(), std::as_bytes(std::span(raw)));
      std::size_t errors = 0;
      for (std::size_t i = 0; i < raw.size(); ++i) {
        std::uint16_t value; std::memcpy(&value, copied.data() + 2*i, 2);
        errors += value != raw[i];
      }
      std::cout << "{\"operation\":\"copy\",\"type\":\"" << ggml_type_name(type)
                << "\",\"count\":" << raw.size() << ",\"mismatches\":" << errors << "}\n";
      auto wide = run(device, type, GGML_TYPE_F32, raw.size(), std::as_bytes(std::span(raw)));
      errors = 0;
      for (std::size_t i = 0; i < raw.size(); ++i) {
        float value; std::memcpy(&value, wide.data() + 4*i, 4);
        const float expected = float(decode(raw[i], bfloat));
        errors += std::isnan(expected) ? !std::isnan(value)
            : std::bit_cast<std::uint32_t>(value) != std::bit_cast<std::uint32_t>(expected);
      }
      std::cout << "{\"operation\":\"widen\",\"type\":\"" << ggml_type_name(type)
                << "\",\"count\":" << raw.size() << ",\"mismatches\":" << errors << "}\n";
      auto small = run(device, GGML_TYPE_F32, type, narrow.size(), std::as_bytes(std::span(narrow)));
      errors = 0; std::size_t nan_errors = 0, first = narrow.size();
      for (std::size_t i = 0; i < narrow.size(); ++i) {
        std::uint16_t value; std::memcpy(&value, small.data() + 2*i, 2);
        const bool bad = std::isnan(narrow[i]) ? !std::isnan(decode(value, bfloat))
                                             : value != encode(narrow[i], bfloat);
        if (bad) { ++errors; nan_errors += std::isnan(narrow[i]); if (first == narrow.size()) first = i; }
      }
      std::cout << "{\"operation\":\"narrow\",\"type\":\"" << ggml_type_name(type)
                << "\",\"count\":" << narrow.size() << ",\"mismatches\":" << errors
                << ",\"nan_class_mismatches\":" << nan_errors;
      if (first != narrow.size()) std::cout << ",\"first_input_bits\":" << std::bit_cast<std::uint32_t>(narrow[first]);
      std::cout << "}\n";
    }
    return 0; // Diagnostic completion only; each row reports qualification.
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n'; return 1;
  }
}
