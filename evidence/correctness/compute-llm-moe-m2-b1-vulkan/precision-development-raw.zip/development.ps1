param([ValidateSet('Configure','Vendor','Build','Test')][string]$Action = 'Configure')
$ErrorActionPreference = 'Stop'
$projectRoot = 'C:\public\project-hyle\hyle'
$buildRoot = 'C:\hv\m2vk'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleM2VulkanErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[void][HyleM2VulkanErrorMode]::SetErrorMode(0x8003)
if (-not (Test-Path -LiteralPath $buildRoot)) {
 New-Item -ItemType Directory -Path $buildRoot | Out-Null
 Set-Content -LiteralPath (Join-Path $buildRoot '.hyle-owner') -Value 'M2-B1 Vulkan development; canonical C:\public\project-hyle\hyle; /root' -Encoding utf8
}
if ((Get-Content -LiteralPath (Join-Path $buildRoot '.hyle-owner') -Raw) -notlike 'M2-B1 Vulkan development;*') { throw 'Build directory belongs to another task.' }
$wrapper = Join-Path $projectRoot 'scripts\hyle-windows.ps1'
if ($Action -eq 'Configure') {
 & $wrapper -Action Configure -BinaryDir $buildRoot -Factor 'graph_route_vulkan' -DependencySourceCache 'C:\public\tools\hyle-dependencies\v1' -ExtraArgs @('-DHYLE_STATIC=OFF','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_VULKAN=ON','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_ONEDNN=OFF','-DHYLE_WERROR=ON')
} elseif ($Action -eq 'Vendor') {
 & $wrapper -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','ggml')
} elseif ($Action -eq 'Build') {
 & $wrapper -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','hyle_compute_provider_ggml_vulkan_tests','hyle_compute_provider_iree_vulkan_tests','hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests')
} else {
 $dlls = @(Get-ChildItem -LiteralPath $buildRoot -Filter '*.dll' -File -Recurse)
 $executables = @(Get-ChildItem -LiteralPath $buildRoot -Filter 'hyle_*vulkan*_test.exe' -File -Recurse)
 foreach ($directory in @($executables.DirectoryName | Sort-Object -Unique)) {
  foreach ($dll in $dlls) {
   $destination = Join-Path $directory $dll.Name
   if ($dll.FullName -ne $destination) { Copy-Item -LiteralPath $dll.FullName -Destination $destination -Force }
  }
 }
 & $wrapper -Action Test -BinaryDir $buildRoot -ExtraArgs @('-R','^hyle_(compute_provider_ggml_vulkan|compute_provider_iree_vulkan|compute_route_vulkan|graph_route_vulkan|ggml_vulkan_source_contract|iree_source).*_test$','--output-on-failure','--parallel','1')
}
exit $LASTEXITCODE
