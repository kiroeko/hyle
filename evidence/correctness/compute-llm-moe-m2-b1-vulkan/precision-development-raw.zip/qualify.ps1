$ErrorActionPreference = 'Stop'
$projectRoot = 'C:\public\project-hyle\hyle'
$probeRoot = Join-Path $projectRoot '.scratch\validation\m2-b1-vulkan-precision'
$buildRoot = 'C:\hv\m2vk'
$vsRoot = 'C:\Program Files\Microsoft Visual Studio\18\Enterprise'
Import-Module -Name (Join-Path $vsRoot 'Common7\Tools\Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $vsRoot -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64' | Out-Null
$bin = Join-Path $buildRoot 'bin'
$exe = Join-Path $bin 'hyle_m2_precision_qualification.exe'
$libs = @('hyle_compute_provider_ggml_vulkan.lib','hyle_compute_ggml_runtime.lib','hyle_error.lib','hyle_mem.lib','ggml-base.lib') | ForEach-Object { Join-Path $bin $_ }
Push-Location -LiteralPath $probeRoot
try {
  & cl.exe /nologo /std:c++latest /EHsc /MD /O2 /DNDEBUG /DNOMINMAX /DWIN32_LEAN_AND_MEAN /utf-8 ("/I" + (Join-Path $projectRoot 'include')) ("/I" + (Join-Path $projectRoot 'src\compute_provider_ggml_vulkan')) /IC:\public\tools\hyle-dependencies\v1\sources\ggml-456172ec733a-41b7e10fd424\include /IC:\public\tools\hyle-vulkan\1.4.357.0\Include qualify.cc ("/Fe:" + $exe) /Fo:qualify.obj /link $libs
  if ($LASTEXITCODE -ne 0) { throw "Qualification build failed: $LASTEXITCODE" }
  & $exe > qualification.jsonl
  if ($LASTEXITCODE -ne 0) { throw "Qualification execution failed: $LASTEXITCODE" }
  Get-Content qualification.jsonl
} finally { Pop-Location }
