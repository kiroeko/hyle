#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m2b1-vulkan
candidate=eccbd0461bf626dd5356ac0c49c564f207297d6b
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
test "$(cat "$task/owner.txt")" = 'M2-B1 Vulkan validation; Windows canonical; /root'
test -z "$(git -C "$task/source" status --porcelain)"
mkdir -p "$task/logs-precision"
git -C "$task/source" fetch origin main
git -C "$task/source" switch --detach "$candidate"
{
  git -C "$task/source" rev-parse HEAD
  git -C "$task/source" rev-parse 'HEAD^{tree}'
  /usr/bin/sw_vers
  /usr/sbin/sysctl -n hw.model
  clang --version
  python3 --version
} > "$task/logs-precision/identity.txt"
if ! cmake --build "$task/build" --parallel 2 --target \
  hyle_compute_provider_ggml_vulkan_tests hyle_compute_provider_iree_vulkan_tests \
  hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests > "$task/logs-precision/build.log" 2>&1; then
  tail -n 50 "$task/logs-precision/build.log"
  exit 1
fi
if ctest --test-dir "$task/build" \
  -L '^(compute_provider_ggml_vulkan|compute_provider_iree_vulkan|compute_route_vulkan|graph_route_vulkan)$' \
  --output-on-failure --no-tests=error --parallel 1 --timeout 180 > "$task/logs-precision/tests.log" 2>&1; then
  result=0
else
  result=$?
fi
cp "$task/build/Testing/Temporary/LastTest.log" "$task/logs-precision/LastTest.log"
cp "$task/build/CMakeCache.txt" "$task/logs-precision/CMakeCache.txt"
git -C "$task/source" status --porcelain > "$task/logs-precision/worktree-status.txt"
python3 - <<'PY' > "$task/logs-precision/artifacts.json"
from pathlib import Path
import hashlib, json
root = Path('/Users/kiro/hyle-m2b1-vulkan/build')
files = set(root.glob('lib/*ggml*')) | set(root.glob('lib/*vulkan*')) | set(root.glob('bin/*vulkan*_test'))
rows = []
for p in sorted(files):
    if p.is_file():
        digest = hashlib.sha256()
        with p.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
        rows.append({'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': digest.hexdigest()})
print(json.dumps({'candidate': 'eccbd0461bf626dd5356ac0c49c564f207297d6b', 'artifacts': rows}, indent=2))
PY
du -sk "$task" "$task/build" > "$task/logs-precision/disk.txt"
df -k "$task" >> "$task/logs-precision/disk.txt"
/usr/bin/tar -czf "$task/precision-logs.tar.gz" -C "$task/logs-precision" .
cat "$task/logs-precision/tests.log"
exit "$result"
