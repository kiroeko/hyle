from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parent
destination = root.parents[2] / 'evidence/correctness/compute-llm-moe-m2-b1-vulkan'
identity = json.loads((root / 'windows-identity.json').read_text(encoding='utf-8'))
selected = json.loads((root / 'selected.json').read_text(encoding='utf-8'))
loc = json.loads((root / 'loc.json').read_text(encoding='utf-8-sig'))
machines = []
for name, relative in [('Windows RTX4070', 'windows-LastTest.log'),
                       ('MacBook Air Mac16,12 MoltenVK', 'air/LastTest.log')]:
    log = root / relative
    text = log.read_text(encoding='utf-8', errors='replace')
    machines.append({
        'machine': name, 'candidate': identity['candidate'], 'ctest_pass': 8,
        'cpp_pass': sum(map(int, re.findall(r'\[  PASSED  \] (\d+) tests?', text))),
        'optional_validation_layer': 'SKIPPED: VK_LAYER_KHRONOS_validation unavailable',
        'log': relative, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
    })
files = sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'air-logs.tar.gz')
manifest = [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size,
                 sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
archive_path = destination / 'softmax-development-raw.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in files:
        archive.write(p, p.relative_to(root).as_posix())
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for entry in manifest:
        content = archive.read(entry['path'])
        assert len(content) == entry['bytes']
        assert hashlib.sha256(content).hexdigest() == entry['sha256']
receipt = {
    'schema': 1, 'card': 'docs/implementation/tasks/compute/llm-moe-m2-b1-vulkan.md',
    'checkpoint': 'V1-A original Softmax axes and broadcast masks',
    'candidate': identity['candidate'], 'tree': identity['tree'], 'baseline': 'f74daa30',
    'owners': ['compute_provider_ggml_vulkan', 'compute_provider_iree_vulkan',
               'compute_route_vulkan', 'graph_route_vulkan'], 'state': 'AUDITED',
    'implementation': [
        'original ggml dense nonempty F32/F16/BF16 Softmax at any axis, rank1..8',
        'same-type additive masks expanded using original repeat, then original axis folding and cont',
        'separate original Scale with additive mask when scale is not one, preserving public F32 rounding',
        'cold layout/grid and original mask dtype validation; established per-public-node half rounding retained',
    ],
    'machines': machines,
    'ordinary_tests': {
        'parameter_cases': 96, 'changed_payload_runs_per_case': 2,
        'dimensions': '3 storage types x 8 shape/axis cases x 4 mask cases',
        'behavior': [
            'six axes, rank8, 16385-column original long-row path',
            'none/scalar/row/column/cross-broadcast masks, all-masked rows',
            'exact F32 scale-before-mask rounding counterexample, NaN and infinities',
            'published axis-restored Softmax and residual outputs in all three storage types',
            'two invocation slots, changed payload replay, retained results, owner close and quota zero',
            'original mixed-dtype mask refusal retained before BF16 promotion',
        ],
    },
    'corrections': [
        {'candidate': '0c707d5b',
         'cause': 'Binary broadcast helper retained short row mask, invalid for Softmax full-axis reshape',
         'change': 'original repeat expands scalar/row/column masks before axis folding',
         'log': 'windows-LastTest-first.log'},
        {'candidate': 'e54205e0',
         'cause': 'BF16 promotion erased original dtype mismatch before semantic admission',
         'change': 'check original same-type mask domain before F32 promotion; existing refusal test retained',
         'log': 'windows-LastTest-mixed-mask.log'},
    ],
    'selected_gate_count': len(selected['selected_gates']),
    'skipped_gate_count': len(selected['skipped_gates']),
    'incremental_selected': 'PASS; configure, four factors, docs and closure',
    'cost_contract': [
        'Scale intermediates and dispatch, original repeat/permute/cont materialization charged',
        'original managed encoding/allocation and established half-provider copy/sync charged',
        'no new shader/math, runtime search, timing, zero-copy or SOTA claim',
    ],
    'pending': [
        'complete 21-row B1 mature domains including remaining masks/index/state/stride and stable transforms',
        'applicable WSL/Mini/OFF, host instrumentation and new-domain three-delivery consumers',
        'full selected set from the precision dependency identity change',
        'qualified P1 on an immutable stable full-batch candidate',
    ],
    'full_B1_aggregate': 'INCONCLUSIVE', 'new_complete_matrix_cells': 0, 'p1': 'NOT_RUN',
    'source_design_budget_minutes': {
        'used_conservative': 118, 'limit': 120,
        'build_and_predeclared_validation': 'separate; no reset for sub-batch',
    },
    'loc': next(row for row in loc['metrics'] if row['id'] == 'module'),
    'loc_self_check': loc['self_check'],
    'disk': json.loads((root / 'disk.json').read_text(encoding='utf-8')),
    'raw_archive': {
        'path': archive_path.name, 'files': len(files), 'bytes': archive_path.stat().st_size,
        'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
        'integrity': 'CRC and every manifest SHA256 verified',
    },
}
(destination / 'softmax-development.json').write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'archive': receipt['raw_archive'], 'cpp_pass': [m['cpp_pass'] for m in machines]}))
