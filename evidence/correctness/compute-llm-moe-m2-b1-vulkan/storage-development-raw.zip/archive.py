from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parent
destination = root.parents[2] / 'evidence/correctness/compute-llm-moe-m2-b1-vulkan'
identity = json.loads((root / 'windows-identity.json').read_text(encoding='utf-8'))
selected = json.loads((root / 'selected.json').read_text(encoding='utf-8'))
loc = json.loads((root / 'loc.json').read_text(encoding='utf-8-sig'))
machines = []
for name, relative in [('Windows RTX4070', 'windows-LastTest.log'),
                       ('MacBook Air Mac16,12 MoltenVK', 'air/LastTest.log')]:
    log = root / relative
    text = log.read_text(encoding='utf-8', errors='replace')
    passed = sum(map(int, re.findall(r'\[  PASSED  \] (\d+) tests?', text)))
    machines.append({
        'machine': name, 'candidate': identity['candidate'], 'ctest_pass': 8,
        'cpp_pass': passed,
        'optional_validation_layer': 'SKIPPED: VK_LAYER_KHRONOS_validation unavailable',
        'log': relative, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
    })

files = sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'air-logs.tar.gz')
manifest = [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size,
                 sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
archive_path = destination / 'storage-development-raw.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in files:
        archive.write(p, p.relative_to(root).as_posix())
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for entry in manifest:
        content = archive.read(entry['path'])
        assert len(content) == entry['bytes']
        assert hashlib.sha256(content).hexdigest() == entry['sha256']

receipt = {
    'schema': 1, 'card': 'docs/implementation/tasks/compute/llm-moe-m2-b1-vulkan.md',
    'checkpoint': 'V1-S dense storage copy and empty concat ports',
    'candidate': identity['candidate'], 'tree': identity['tree'], 'baseline': 'c11c6675',
    'owners': ['compute_provider_ggml_vulkan', 'compute_provider_iree_vulkan',
               'compute_route_vulkan', 'graph_route_vulkan'], 'state': 'AUDITED',
    'implementation': [
        'original ggml dense nonempty rank0..8 I32 Copy and F16/BF16/I32 Concat',
        'Concat drops empty native ports during cold lowering; public bind still requires all inputs',
        'one effective input uses Dup for independent output; multiple inputs use Concat without initial Dup',
        'all-empty output retains existing no-GPU-work semantics and does not prove mature computation',
    ],
    'machines': machines,
    'ordinary_tests': [
        'four storage types, six high-rank axes, six ports, unequal lengths and odd tails',
        'exact bits including NaN payloads, negative zero and I32 extremes',
        'mixed-empty, single-effective-input and all-empty Concat',
        'published Copy/Concat/Concat intermediates with dynamic and constant empty ports',
        'two invocation slots, updated inputs, replay, independent outputs and retained results',
        'owner close followed by download and quota returning to zero',
    ],
    'corrections': [{
        'candidate': '3400154d',
        'cause': 'new test omitted explicit Operation wrapper for prepare(span<Argument>)',
        'change': 'test-only correction in 5b45fb76; public API unchanged',
        'log': 'windows-build.log',
    }],
    'selected_gate_count': len(selected['selected_gates']),
    'skipped_gate_count': len(selected['skipped_gates']),
    'incremental_selected': 'PASS; configure, four factors, docs and closure',
    'configure': 'Windows cache byte-identical before and after configure; previous native bridge inputs unchanged',
    'cost_contract': [
        'original managed graph encoding/allocation, Concat intermediates and boundary copy/sync charged',
        'no payload work during prepare and no provider search or timing during submit',
        'no P1, SOTA or frozen-self comparison claim',
    ],
    'pending': [
        'complete 21-row B1 mature coverage: other types, stride, index, mask and state',
        'applicable WSL/Mini/OFF, host instrumentation and new-domain three-delivery consumers',
        'full selected set from the precision dependency identity change',
        'qualified P1 on an immutable stable full-batch candidate',
    ],
    'full_B1_aggregate': 'INCONCLUSIVE', 'new_complete_matrix_cells': 0, 'p1': 'NOT_RUN',
    'source_design_budget_minutes': {
        'used_conservative': 110, 'limit': 120,
        'build_and_predeclared_validation': 'separate; no reset for sub-batch',
    },
    'loc': next(row for row in loc['metrics'] if row['id'] == 'module'),
    'loc_self_check': loc['self_check'],
    'disk': json.loads((root / 'disk.json').read_text(encoding='utf-8')),
    'raw_archive': {
        'path': archive_path.name, 'files': len(files), 'bytes': archive_path.stat().st_size,
        'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
        'integrity': 'CRC and every manifest SHA256 verified',
    },
}
(destination / 'storage-development.json').write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'archive': receipt['raw_archive'], 'cpp_pass': [m['cpp_pass'] for m in machines]}))
