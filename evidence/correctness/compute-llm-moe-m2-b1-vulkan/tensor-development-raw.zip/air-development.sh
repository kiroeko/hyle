#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m2b1-vulkan
candidate=9a49fad478a1181d068a6a7ec8d924c82ca8bbf9
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
for tool in cmake ninja clang python3; do command -v "$tool"; done
test -f "$VK_DRIVER_FILES"
test ! -e "$task"
mkdir "$task"
printf '%s\n' 'M2-B1 Vulkan validation; Windows canonical; /root' > "$task/owner.txt"
git -C /Users/kiro/hyle fetch origin main
git -C /Users/kiro/hyle worktree add --detach "$task/source" "$candidate"
mkdir "$task/logs"
{
  git -C "$task/source" rev-parse HEAD
  git -C "$task/source" rev-parse 'HEAD^{tree}'
  /usr/bin/sw_vers
  /usr/sbin/sysctl -n hw.model
  clang --version
  python3 --version
} > "$task/logs/identity.txt"
if ! cmake -S "$task/source" -B "$task/build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 \
  -DHYLE_DEV_FACTORS=graph_route_vulkan -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON \
  -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF \
  -DHYLE_COMPUTE_VULKAN=ON -DHYLE_WERROR=ON > "$task/logs/configure.log" 2>&1; then
  tail -n 45 "$task/logs/configure.log"
  exit 1
fi
tail -n 6 "$task/logs/configure.log"
if ! cmake --build "$task/build" --parallel 2 --target \
  hyle_compute_provider_ggml_vulkan_tests hyle_compute_provider_iree_vulkan_tests \
  hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests > "$task/logs/build.log" 2>&1; then
  tail -n 55 "$task/logs/build.log"
  exit 1
fi
tail -n 8 "$task/logs/build.log"
if ! ctest --test-dir "$task/build" \
  -L '^(compute_provider_ggml_vulkan|compute_provider_iree_vulkan|compute_route_vulkan|graph_route_vulkan)$' \
  --output-on-failure --no-tests=error --parallel 1 --timeout 180 > "$task/logs/tests.log" 2>&1; then
  cat "$task/logs/tests.log"
  exit 1
fi
cp "$task/build/Testing/Temporary/LastTest.log" "$task/logs/LastTest.log"
cp "$task/build/CMakeCache.txt" "$task/logs/CMakeCache.txt"
git -C "$task/source" status --porcelain > "$task/logs/worktree-status.txt"
/usr/bin/tar -czf "$task/development-logs.tar.gz" -C "$task/logs" .
cat "$task/logs/tests.log"
