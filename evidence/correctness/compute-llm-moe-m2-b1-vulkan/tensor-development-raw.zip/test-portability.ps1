$ErrorActionPreference = 'Stop'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleVulkanPortabilityErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[void][HyleVulkanPortabilityErrorMode]::SetErrorMode(0x8003)
& 'C:\public\project-hyle\hyle\scripts\hyle-windows.ps1' -Action Test -BinaryDir 'C:\hv\m2vk' -ExtraArgs @('-R','^hyle_compute_route_vulkan_test$','--output-on-failure','--parallel','1')
exit $LASTEXITCODE
