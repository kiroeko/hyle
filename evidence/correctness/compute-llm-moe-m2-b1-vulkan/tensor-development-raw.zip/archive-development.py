from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path(__file__).resolve().parent
repository = root.parents[2]
destination = repository / 'evidence/correctness/compute-llm-moe-m2-b1-vulkan'
destination.mkdir(parents=True, exist_ok=True)
product = '9a49fad478a1181d068a6a7ec8d924c82ca8bbf9'
candidate = '4a7058979d1fe7593de4a8bf8eaae6421d4a6a01'
tree = '2e965884eebc92eb0d0f7615ecb1e4506d68bf85'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(name):
    return json.loads((root / name).read_text(encoding='utf-8'))

def gtest_passed(name):
    text = (root / name).read_text(encoding='utf-8', errors='replace')
    assert '[  FAILED  ]' not in text
    return sum(int(n) for n in re.findall(r'\[  PASSED  \] (\d+) tests?\.', text))

assert gtest_passed('windows-LastTest.log') == 166
assert gtest_passed('windows-portability-LastTest.log') == 109
assert gtest_passed('air/LastTest.log') == 167
identity = (root / 'air/identity.txt').read_text()
assert identity.startswith(candidate + '\n' + tree)
assert (root / 'air/worktree-status.txt').read_text().strip() == ''
test_only = subprocess.check_output(
    ['git', 'diff', '--name-only', product, candidate], cwd=repository, text=True).splitlines()
assert test_only == ['tests/compute_route_vulkan/mature_tensor_test.cc']
loc_report = load('product-loc.json')
loc = next(row for row in loc_report['metrics'] if row['id'] == 'module')
assert loc['code'] == 57086 and loc['files'] == 249

archive = destination / 'tensor-development-raw.zip'
files = sorted(p for p in root.rglob('*') if p.is_file() and p.suffix != '.gz')
contents = {str(p.relative_to(root)).replace('\\', '/'): p.read_bytes() for p in files}
manifest = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in contents.items()}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in contents.items():
        output.writestr(name, data)
    output.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name, row in manifest.items():
        assert digest(check.read(name)) == row['sha256']

windows = load('windows-artifacts.json')
windows_after = load('windows-portability-artifacts.json')
record = {
    'kind': 'Windows/Air development checkpoint; full B1 acceptance pending',
    'baseline': '09d2cf99f1298e988ccda65ca76ec1b4907bd0e7',
    'scoped_commit': 'b9478142',
    'audited_commit': '561d970333005d59d5de688e1773db85bb7bea13',
    'product_commit': product,
    'product_tree': '85b950623e2a60c03c14d970a1f5d7132e0b8e46',
    'test_portability_commit': candidate,
    'test_portability_tree': tree,
    'product_inputs_unchanged_by_test_correction': True,
    'provider': {
        'name': 'original ggml Vulkan',
        'revision': '456172ec733a135778adcd32d00e576a58232e45',
        'license': 'MIT',
        'vendor_math_and_dependency_pin_changed': False,
        'source_cache_modified': False,
        'iree_product_changed': False,
    },
    'implemented': [
        'Dense nonempty F32 Copy and Concat (up to six inputs), rank0..8',
        'Two-sided high-rank Add/Sub/Mul/Div broadcasting using original reshape/repeat',
        'Existing unary/gating/RMSNorm/LayerNorm shape expansion using native dimension folding',
        'Arbitrary-axis Sum/Mean and both keepdim modes using original view/cont and exact row tiles',
        'Published reshaped outputs bind and protect their real producer root',
        'Bounded cold metadata and device buffer/dispatch checks',
        'Natural Direct/Graph matching; no user provider ordering or run-time selection',
    ],
    'cost_contract': [
        'Original repeat/cont can allocate GPU temporary storage and add dispatches',
        'Existing alignment and boundary copies, managed encoding/allocation and synchronization remain charged',
        'No zero-allocation, zero-copy or SOTA claim; no self-written operator performance comparison',
    ],
    'validation': {
        'windows': {
            'configuration': windows['configuration'],
            'platform': windows['platform'],
            'gpu': windows['gpu'],
            'candidate': product,
            'ctest_passed': 9, 'ctest_total': 9,
            'gtest_passed': 166, 'gtest_skipped': 1,
            'portability_correction': {
                'candidate': candidate,
                'ctest_passed': 1, 'ctest_total': 1, 'gtest_passed': 109,
                'all_original_product_artifact_hashes_equal': True,
                'changed_artifacts': windows_after['changed_artifacts'],
            },
        },
        'air': {
            'configuration': 'Release/static/WERROR, Apple clang21, arm64, deployment14.4, MoltenVK, parallel2/tests1',
            'identity': identity,
            'candidate': candidate,
            'ctest_passed': 8, 'ctest_total': 8,
            'gtest_passed': 167, 'gtest_skipped': 1,
            'source_worktree_clean': True,
        },
        'optional_skipped_on_both': 'GgmlVulkanNative.ExplicitValidationUsesItsOwnInstance',
        'new_cases': [
            'Independent scalar indexing oracle for two-sided broadcast, ranks2/6/8 and all four arithmetic operations',
            'Independent FP64 reduction oracle for nonadjacent axes, rank3/6/8 and 513 output rows',
            'Bit-preserving Copy special values and rank6 Concat on every axis with three inputs',
            'High-rank norm/Tanh and explicit assertions that original mature regions execute',
            'Graph L2 region publishes intermediate reduction and final output; two slots, changing payloads, retained results after close, quota returns to zero',
        ],
        'selected_plan': 'immutable-development-plan.json',
        'selected_factors': ['compute_provider_ggml_vulkan', 'compute_provider_iree_vulkan', 'compute_route_vulkan', 'graph_route_vulkan'],
        'selector_skipped_reasons_retained': 125,
        'native_execution': 'Existing module wrappers/CTest; development evidence is not a formal selector run receipt',
        'performance_samples': 0,
    },
    'retained_failures_and_corrections': [
        'Initial Windows configure lacked VULKAN_SDK; corrected process environment to the existing SDK, no product change',
        'Air WERROR rejected a copied Operation range-loop variable in a new test; changed to const reference in Windows canonical checkout, committed/pushed, incrementally rebuilt both machines',
    ],
    'not_completed': [
        'Full 21-row B1 coverage, including remaining precision, stride/empty, indexing/mask/stable domains',
        'Applicable WSL/Mini/OFF and host sanitizer checks for the stable whole batch',
        'New-domain source/static/shared delivery acceptance and relocation/hidden producer checks',
        'Final selected verification and independent candidate review',
        'Necessary P1 after stable whole-batch API/algorithm and immutable candidate',
    ],
    'aggregate_gate': 'INCONCLUSIVE',
    'owner_state': 'AUDITED',
    'new_complete_coverage_cells': 0,
    'hyle_numerical_kernels_added': 0,
    'source_design_budget_minutes': {'used': 30, 'limit': 120, 'build_and_predeclared_validation_counted_separately': True},
    'loc': loc,
    'archive': {
        'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()),
        'crc': 'PASS', 'entry_hashes': 'PASS', 'files': len(contents) + 1,
    },
    'retained_active_workspaces': {
        'windows': {'path': windows['build'], 'bytes': windows_after['active_build_bytes'], 'volume_free_bytes': windows_after['volume_free_bytes']},
        'air': {'path': '/Users/kiro/hyle-m2b1-vulkan', 'allocated_kib': 807560, 'build_allocated_kib': 672624, 'volume_free_kib': 48918600},
        'reason': 'One build per platform reused for remaining B1 integration; no further source/model copies',
        'cleanup_action_this_checkpoint': 'No obsolete task build created; both current builds retained for reuse',
    },
}
(destination / 'tensor-development.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'archive_bytes': record['archive']['bytes'], 'raw_files': len(contents), 'loc': loc['code']}, indent=2))
