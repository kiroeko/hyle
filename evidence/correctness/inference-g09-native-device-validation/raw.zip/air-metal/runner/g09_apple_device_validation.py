from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g09-apple-device-validation-1';out.mkdir(exist_ok=False)
inputs=json.loads((base/'g09-host-risk-inputs/g09-apple-device-inputs.json').read_text())
build=base/'a-cpu-apple/selected-graph/source-build';names=['hyle_cpu_apple_contracts','hyle_cpu_apple_pipeline']
artifacts={x['target']:x for x in inputs['artifacts']}
for name in names:assert hashlib.sha256((build/name).read_bytes()).hexdigest()==artifacts[name]['sha256']
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
os.nice(10);env=dict(os.environ,MTL_DEBUG_LAYER='1',MTL_SHADER_VALIDATION='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
r={'state':'SETUP','pid':os.getpid(),'canonical_product_commit':inputs['product_commit'],'identity':inputs['identity'],'stages':[],
   'environment':{k:env[k] for k in ['MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']},'nice':os.nice(0),'build_jobs':0,
   'scope':'Actual Air M4 original shipping-profile CPU+Apple contracts and five original joint pipeline scenarios under Metal API/shader validation. Same numerical/cancel/retirement consumers, unchanged kernels borrowed. No host sanitizer, whole-process leak, SDK or P1 certificate.',
   'artifacts':[dict(path=str(build/name),sha256=artifacts[name]['sha256']) for name in names]}
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
failed=[]
for name in names:
    r.update(state='RUNNING',stage=name);save();print(name,flush=True);stamp=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:
        p=subprocess.Popen([str(build/name)],cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=600);break
            except subprocess.TimeoutExpired:
                if p.poll() is None:r.setdefault('extensions',[]).append({'stage':name,'pid':p.pid,'seconds':600});save();continue
                code=p.returncode;break
    r.pop('child_pid',None);text=(out/(name+'.log')).read_text(errors='replace')
    errors=[x for x in text.splitlines() if any(marker in x for marker in ['MTLDebugCommandBuffer error','Shader Validation Error','failed assertion'])]
    r['stages'].append({'stage':name,'exit_code':code,'elapsed_seconds':time.monotonic()-stamp,'validation_error_lines':errors});save()
    if code or errors:failed.append(name);print(text[-7000:],flush=True)
for name in names:assert hashlib.sha256((build/name).read_bytes()).hexdigest()==artifacts[name]['sha256']
r['failures']=failed;r['state']='METAL_CONSUMERS_EXIT_ZERO_ACTIVATION_REVIEW_PENDING' if not failed else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save()
print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds'],'failures':failed}),flush=True)
