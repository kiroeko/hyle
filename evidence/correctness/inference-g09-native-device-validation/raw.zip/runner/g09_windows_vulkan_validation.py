from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parents[2];out=root/'.scratch/inference-gaps/g09-windows-vulkan-validation-1';out.mkdir(exist_ok=False)
sdk=Path('C:/public/tools/hyle-vulkan/1.4.357.0/Bin')
ordinary=json.loads((root/'evidence/correctness/inference-g09-vulkan-implementation-checkpoint/receipt.json').read_text())
timeline=json.loads((root/'evidence/correctness/inference-g09-vulkan-real-math-timeline/receipt.json').read_text())['cases'][0]['result']
artifacts={Path(x['path']).name:x for x in ordinary['binaries']}
artifacts.update({Path(x['path']).name:x for x in timeline['binaries']})
names=['hyle_cpu_vulkan_contracts.exe','hyle_cpu_vulkan_pipeline.exe']
for name in names:assert hashlib.sha256(Path(artifacts[name]['path']).read_bytes()).hexdigest()==artifacts[name]['sha256']
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env.update(PATH=str(sdk)+';'+env['PATH'],VK_LAYER_PATH=str(sdk),VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
    VK_LOADER_DEBUG='error,warn,layer',VK_LAYER_ENABLES='VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT',
    OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
ctypes.windll.kernel32.SetErrorMode(0x0001|0x0002|0x8000)
r={'state':'SETUP','pid':os.getpid(),'canonical_product_commit':'e09f30925c6dba5cf4540669fd3b4874f45bb158','stages':[],
   'scope':'Original qualified Windows CPU+Vulkan contracts and ordinary five-case two-slot/65-step independent math/cancel pipeline, with actual Khronos validation and requested synchronization validation. No new build, shader qualification or P1 claim.',
   'artifacts':[artifacts[n] for n in names], 'environment':{k:env[k] for k in ['VK_LAYER_PATH','VK_INSTANCE_LAYERS','VK_LOADER_DEBUG','VK_LAYER_ENABLES']},
   'layer':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [sdk/'VkLayer_khronos_validation.json',sdk/'VkLayer_khronos_validation.dll']],
   'max_jobs':0,'priority':'BELOW_NORMAL','logical_cpu_limit':4}
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
failed=[]
for name in names:
    stamp=time.monotonic();log=out/(name+'.log')
    with log.open('wb') as stream:
        p=subprocess.Popen([artifacts[name]['path']],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        get=ctypes.windll.kernel32.GetProcessAffinityMask;get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        set_mask=ctypes.windll.kernel32.SetProcessAffinityMask;set_mask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle))
        assert get(handle,ctypes.byref(available),ctypes.byref(system))
        mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4]);assert set_mask(handle,mask)
        r.update(state='RUNNING',stage=name,child_pid=p.pid,affinity_mask=hex(mask));save();print(name,flush=True)
        while True:
            try:code=p.wait(timeout=600);break
            except subprocess.TimeoutExpired:
                if p.poll() is None:r.setdefault('extensions',[]).append({'stage':name,'pid':p.pid,'seconds':600});save();continue
                code=p.returncode;break
    r.pop('child_pid',None);text=log.read_text(errors='replace')
    errors=[x for x in text.splitlines() if any(marker in x for marker in ['Validation Error','VUID-','SYNC-HAZARD','UNASSIGNED-Threading-MultipleThreads'])]
    r['stages'].append({'stage':name,'exit_code':code,'elapsed_seconds':time.monotonic()-stamp,'validation_error_lines':errors})
    if code or errors:failed.append(name);print(text[-8000:],flush=True)
    save()
r['failures']=failed
r['state']='ALL_RUNS_EXIT_ZERO_REQUIRES_LAYER_ACTIVATION_REVIEW' if not failed else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save()
print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds'],'failures':failed}),flush=True)
