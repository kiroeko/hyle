from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g09-cuda-device-validation-1';out.mkdir(exist_ok=False)
prior=json.loads((root/'evidence/correctness/inference-g09-wsl-cuda-implementation-checkpoint/receipt.json').read_text())
build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/source-build')
artifacts={x['target']:x for x in prior['binaries']};names=['hyle_cpu_cuda_contracts','hyle_cpu_cuda_pipeline']
for name in names:assert hashlib.sha256((build/name).read_bytes()).hexdigest()==artifacts[name]['sha256']
os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
env=dict(os.environ,PATH='/usr/local/cuda-13.3/bin:'+os.environ.get('PATH',''),LD_LIBRARY_PATH='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib',
    OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
tool='/usr/local/cuda-13.3/bin/compute-sanitizer'
r={'state':'SETUP','pid':os.getpid(),'canonical_product_commit':prior['canonical_product_commit'],'stages':[],
   'scope':'Actual WSL RTX4070 original shipping-profile CPU+CUDA contracts and five-scenario independent branch/two-slot pipeline, memcheck/racecheck only. No shader/source edits or new compilation. Original unchanged device kernel barriers/math qualifications are borrowed; no whole-process leak or new SDK/P1 claim.',
   'artifacts':[dict(path=str(build/name),sha256=artifacts[name]['sha256']) for name in names],
   'identity':prior['identity'],'logical_cpus':sorted(os.sched_getaffinity(0)),'nice':os.nice(0),'build_jobs':0}
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args):
    r.update(state='RUNNING',stage=stage);save();print(stage,flush=True);stamp=time.monotonic()
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen(args,env=env,cwd=build,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=600);break
            except subprocess.TimeoutExpired:
                if p.poll() is None:r.setdefault('extensions',[]).append({'stage':stage,'pid':p.pid,'seconds':600});save();continue
                code=p.returncode;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:print((out/(stage+'.log')).read_text(errors='replace')[-9000:],flush=True)
    return code,(out/(stage+'.log')).read_text(errors='replace')
code,_=run('tool-version',[tool,'--version']);assert code==0
failed=[]
for mode in ['memcheck','racecheck']:
    for name in names:
        stage=mode+'-'+name
        code,text=run(stage,[tool,'--tool',mode,'--error-exitcode','86',str(build/name)])
        expected='ERROR SUMMARY: 0 errors' if mode=='memcheck' else 'RACECHECK SUMMARY: 0 hazards'
        if code or expected not in text:failed.append(stage)
for name in names:assert hashlib.sha256((build/name).read_bytes()).hexdigest()==artifacts[name]['sha256']
r['failures']=failed;r['state']='CUDA_MEMCHECK_RACECHECK_TWO_CONSUMERS_PASS' if not failed else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save()
print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds'],'failures':failed}),flush=True)
