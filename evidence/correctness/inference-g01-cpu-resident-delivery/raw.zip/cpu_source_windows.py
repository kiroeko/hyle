from pathlib import Path
import subprocess,json,time,hashlib
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';build=repo/'.scratch/build-compute-v2-dev';hook=out/'cpu-source-project.cmake'
hook.write_text('''if(PROJECT_NAME STREQUAL "hyle")
  function(g01_source_consumer)
    add_executable(g01_cpu_public_source "'''+(out/'public_cpu_resident.cc').as_posix()+'''")
    target_compile_features(g01_cpu_public_source PRIVATE cxx_std_23)
    target_compile_options(g01_cpu_public_source PRIVATE /utf-8)
    target_link_libraries(g01_cpu_public_source PRIVATE hyle::compute)
    hyle_stage_runtime(g01_cpu_public_source)
  endfunction()
  cmake_language(DEFER CALL g01_source_consumer)
endif()
''')
result=out/'cpu-win-source-result.json';rows=json.loads(result.read_text())['stages'] if result.exists() else []
def run(stage,args):
    attempt=1+sum(x['stage']==stage for x in rows);log=out/f'cpu-win-source-{stage}-{attempt}.log';start=time.monotonic()
    with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    result.write_text(json.dumps({'candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','scope':'same public CPU resident consumer linked directly to canonical source HYLE compute facade; private test target only','consumer_sha256':hashlib.sha256((out/'public_cpu_resident.cc').read_bytes()).hexdigest(),'stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:
        with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1600));print(f.read(1600).decode('utf-8',errors='replace'))
        raise SystemExit(r.returncode)
run('configure',['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
run('build',['cmake','--build',str(build),'--target','g01_cpu_public_source','--parallel','2'])
run('run',[str(build/'bin/g01_cpu_public_source.exe')])
