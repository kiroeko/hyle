from pathlib import Path
import subprocess,json,time,sys,hashlib,platform
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';mode=sys.argv[1];assert mode in ('static','shared')
producer=repo/'.scratch/build-compute-v2-dev';base=Path('C:/h7')/('inference-g01-cpu-'+mode+'-sdk');base.mkdir(exist_ok=True);stage=base/'staging';prefix=base/'relocated';source=base/'consumer-source';source.mkdir(exist_ok=True);build=base/'consumer-build'
result_file=out/('cpu-win-'+mode+'-sdk-result.json');old=json.loads(result_file.read_text()) if result_file.exists() else None;records=old['stages'] if old else []
def done(name):return next((x for x in reversed(records) if x['stage']==name),{}).get('exit_code')==0
def run(name,args):
 attempt=1+sum(x['stage']==name for x in records);log=out/('cpu-win-'+mode+'-sdk-'+name+'-'+str(attempt)+'.log');started=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','mode':mode,'producer':str(producer),'scope':'ordinary CPU-only SDK, same mature resident GQA consumer; old legacy public build options removed, cache/tree/failed attempts retained','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1800));print(f.read(1800).decode('utf-8',errors='replace'))
  raise SystemExit(r.returncode)
if not done('configure'):
 run('configure',['cmake','-S',str(repo),'-B',str(producer),'-UCMAKE_PROJECT_INCLUDE','-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES','-UHYLE_COMPUTE_CPU','-UHYLE_COMPUTE_CUDA','-UHYLE_COMPUTE_APPLE','-UHYLE_COMPUTE_VULKAN','-UHYLE_COMPUTE_ONEDNN','-UHYLE_COMPUTE_TORCH_CPU','-UFETCHCONTENT_SOURCE_DIR_GGML','-UFETCHCONTENT_SOURCE_DIR_GGML_CPU','-UFETCHCONTENT_SOURCE_DIR_ONEDNN','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF'),'-DFETCHCONTENT_FULLY_DISCONNECTED=OFF','-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1'])
if not done('producer-build'):run('producer-build',['cmake','--build',str(producer),'--parallel','4'])
if not done('install'):assert not prefix.exists();run('install',['cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
(source/'main.cc').write_bytes((out/'public_cpu_resident.cc').read_bytes())
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g01_cpu_public_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
add_executable(resident main.cc)
target_compile_features(resident PRIVATE cxx_std_23)
target_compile_options(resident PRIVATE /utf-8)
target_link_libraries(resident PRIVATE hyle::compute)
hyle_stage_runtime(resident)
''')
identity={'candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','mode':mode,'public_consumer_inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'main.cc',source/'CMakeLists.txt')},'canonical_product_inputs':{name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in ('src/compute_provider_ggml/ggml_cpu_provider.cc','cmake/HyleDependencyLock.json')},'machine':platform.platform(),'node':platform.node(),'python':sys.version,'producer_cache_sha256':hashlib.sha256((producer/'CMakeCache.txt').read_bytes()).hexdigest(),'relocated_prefix':str(prefix),'staging_absent':not stage.exists(),'consumer_source_scope':'only installed public HYLE headers; raw BF16 uint16 storage, no SIMD/private source dependencies'}
(out/('cpu-win-'+mode+'-sdk-inputs.json')).write_text(json.dumps(identity,indent=2)+'\n')
if not done('consumer-configure'):run('consumer-configure',['cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_CXX_FLAGS=/DWIN32 /D_WINDOWS /GR /EHsc','-DCMAKE_CXX_FLAGS_RELEASE=/O2 /Ob2 /DNDEBUG'])
if not done('consumer-build'):run('consumer-build',['cmake','--build',str(build),'--target','resident','--parallel','2'])
if not done('run'):run('run',[str(build/'resident.exe')])
artifacts=[build/'resident.exe',*(build.glob('*.dll') if mode=='shared' else []),*(prefix/'lib').glob('hyle*'+('.lib'))]
identity['artifacts']=[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(artifacts)) if p.is_file()]
(out/('cpu-win-'+mode+'-sdk-inputs.json')).write_text(json.dumps(identity,indent=2)+'\n')
