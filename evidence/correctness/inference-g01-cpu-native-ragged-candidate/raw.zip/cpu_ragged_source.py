from pathlib import Path
import os,subprocess,json,time,hashlib
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';build=repo/'.scratch/build-compute-v2-dev';hook=out/'cpu-ragged-public-project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 function(g01_ragged_source)
  add_executable(g01_cpu_ragged_public "'''+(out/'public_cpu_ragged.cc').as_posix()+'''")
  target_compile_features(g01_cpu_ragged_public PRIVATE cxx_std_23)
  target_compile_options(g01_cpu_ragged_public PRIVATE /utf-8)
  target_link_libraries(g01_cpu_ragged_public PRIVATE hyle::compute hyle::graph hyle_compute_provider_ggml)
  hyle_stage_runtime(g01_cpu_ragged_public)
 endfunction()
 cmake_language(DEFER CALL g01_ragged_source)
endif()
'''
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
record=out/'cpu-ragged-public-source-result.json';records=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args):
 n=1+sum(x['stage']==stage for x in records);log=out/f'cpu-ragged-public-source-{stage}-{n}.log';start=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 record.write_text(json.dumps({'candidate':'642cc1e67566994a85a65adbe0db8956c1d0350a','consumer_sha256':hashlib.sha256((out/'public_cpu_ragged.cc').read_bytes()).hexdigest(),'scope':'default Direct plus source expert original Graph batch two dependent regions, source-only factory target explicit','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2200));print(f.read(2200).decode(errors='replace'))
  raise SystemExit(r.returncode)
run('configure',['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
run('build',['cmake','--build',str(build),'--target','g01_cpu_ragged_public','--parallel','4'])
run('run',[str(build/'bin/g01_cpu_ragged_public.exe')])
