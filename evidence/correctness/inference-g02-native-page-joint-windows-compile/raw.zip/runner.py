from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();out=root/'.scratch/inference-gaps/g02/windows-native-joint-compile';out.mkdir(exist_ok=True)
candidate='1cd0893979e1672a0f6fac98b783a6a3bfcabbca'
registry=json.loads((root/'docs/implementation/module-status.json').read_bytes())
for name in ['graph_batch','graph_route_cpu_vulkan','compute_batch']:
    row=next(r for r in registry['modules'] if r['module']==name)
    assert row['state']=='CANDIDATE' and row['candidate']==candidate
remote='/Users/kiro/hyle-scratch/compute-unified/g02-native-page-joint-sdk-stage/job.json'
while True:
    result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','cat '+remote],capture_output=True,text=True)
    if result.returncode:
        print('OBSERVATION transient, re-poll same SDK job; no restart',flush=True);time.sleep(15);continue
    job=json.loads(result.stdout)
    if job['state']=='TERMINAL':
        assert job['exit_code']==0,'inspect failed SDK job first';break
    print('WAIT exact remote SDK job before local fourjobs compile',job['route'],job['mode'],job['pid'],flush=True);time.sleep(15)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key,value=line.split('=',1);env[key]=value
tree=Path('C:/h7/inference-g01-native-vulkan');parent=tree/'parent/CMakeLists.txt';build=tree/'build'
body=parent.read_bytes();old=b'set(HYLE_COMPUTE_ROUTES vulkan)';new=b'set(HYLE_COMPUTE_ROUTES "cpu;vulkan")'
if old in body:body=body.replace(old,new)
assert new in body
headers=[]
for index,name in enumerate(['hyle/graph/batch.h','hyle/graph/cpu_vulkan.h','hyle/graph/cpu.h']):
    path=out/f'header-{index}.cc';path.write_bytes(('#include <'+name+'>\n').encode());headers.append(path)
target='g02_joint_public_compile'
if ('add_executable('+target+' ').encode() not in body:
    source=root/'tests/graph_batch/native_paged_joint_consumer.cc';sources=' '.join('"'+p.as_posix()+'"' for p in [source,*headers])
    addition=f'\nadd_executable({target} {sources})\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE /W4 /WX /wd4324 /utf-8)\ntarget_link_libraries({target} PRIVATE hyle::graph)\nhyle_stage_runtime({target})\n'
    body+=addition.encode()
if parent.read_bytes()!=body:parent.write_bytes(body)
record=out/'result.json';rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
log=out/f'build-{1+len(rows)}.log';start=time.monotonic();command=['cmake','--build',str(build),'--target',target,'--parallel','4']
with log.open('w',encoding='utf-8') as stream:
    process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
    (out/'job.json').write_text(json.dumps({'state':'RUNNING','pid':process.pid,'command':command,'log':str(log)},indent=2)+'\n');print('BUILD PID',process.pid,flush=True)
    code=process.wait()
rows.append({'stage':'public-joint-link-three-headers','command':command,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)})
inputs=[]
for row in json.loads((root/'evidence/correctness/inference-g02-native-page-joint-risk-stage/synced-inputs.json').read_bytes())['inputs']:
    name=row['path'];data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',candidate+':'+name]),name
    inputs.append({'path':name,'sha256':hashlib.sha256(data).hexdigest()})
receipt={'candidate':candidate,'scope':'Windows actual public hyle::graph CPU+Vulkan compile/link/three standalone headers; no executable/GPU run, no Windows math/throughput claim','inputs':inputs,'stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)}
record.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code,'cumulative_seconds':receipt['cumulative_seconds']},indent=2)+'\n')
print(json.dumps(receipt),flush=True);print(log.read_text(errors='replace')[-4500:],flush=True);raise SystemExit(code)
