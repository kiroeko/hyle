from pathlib import Path
import json,os,subprocess,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g03-copy-update-host-all';out.mkdir(exist_ok=True)
record=out/'result.json';rows=json.loads(record.read_bytes())['stages'] if record.exists() else [];job=out/'job.json';code=0
for route in ['apple','vulkan']:
 for mode in ['asan','ubsan','tsan']:
  if any(r['route']==route and r['mode']==mode and r['exit_code']==0 for r in rows):continue
  path=base/f'g03-copy-update-host-{route}-{mode}';path.mkdir(exist_ok=True)
  args=['python3',str(base/'g03-copy-update-host/copy_update_san_air.py'),route,mode]
  attempt=1+sum(r['route']==route and r['mode']==mode for r in rows)
  start=time.monotonic();log=out/f'{route}-{mode}-{attempt}.log'
  with log.open('w') as stream:
   process=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT)
   job.write_text(json.dumps({'state':'RUNNING','route':route,'mode':mode,'pid':process.pid,'log':str(log)}))
   print('RUN',route,mode,'PID',process.pid,flush=True);code=process.wait()
  row={'route':route,'mode':mode,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
  (out/'result.json').write_text(json.dumps({'candidate':'bcaec010b528e372671f737f40b4aa53eb076aaf','stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n')
  print(json.dumps(row),flush=True)
  if code:
   print(log.read_text(errors='replace')[-6500:],flush=True)
   break
 if code:break
job.write_text(json.dumps({'state':'TERMINAL','exit_code':code,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)}))
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file() and p.suffix in ['.log','.json']:z.write(p,p.name)
raise SystemExit(code)
