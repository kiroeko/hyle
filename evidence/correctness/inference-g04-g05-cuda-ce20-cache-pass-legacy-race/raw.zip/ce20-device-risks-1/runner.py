from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
prior=json.loads((base/'ce19-source-4/result.json').read_text());assert prior['state']=='TERMINAL_PASS'
binary=Path(prior['build'])/'bin/hyle_compute_provider_flashinfer_test'
out=base/'ce20-device-risks-1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
library=Path(prior['build'])/'bin/libhyle_compute_provider_flashinfer.so.0.1.0'
tool='/usr/local/cuda-13.3/bin/compute-sanitizer'
env=os.environ.copy();env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
r=dict(state='SETUP',scope='CE20 output shared-storage handoff and warp store/load synchronization; no P1/host facets/private-pool leak verdict',
 product_commit='a77bb28d15ddf1be3ae5e3131d4f03108292068f',source_result_sha256=sha(base/'ce19-source-4/result.json'),
 artifacts={str(p):sha(p) for p in (binary,library)},
 tool_version=subprocess.check_output([tool,'--version'],text=True).strip(),stages=[])
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
save()
for label,mode,filter_value in [('memcheck','memcheck','FlashinferCache.*'),('racecheck','racecheck','FlashinferCache.*'),('legacy-racecheck','racecheck','Flashinfer.Fp16PrefillAndDecodeThroughCompute:Flashinfer.Bf16PrefillAndDecodeThroughCompute')]:
 command=[tool,'--tool',mode,'--error-exitcode','86','--print-limit','0']
 if mode=='memcheck':command+=['--leak-check','no']
 else:command+=['--racecheck-num-workers','4']
 command+=[str(binary),'--gtest_filter='+filter_value,'--gtest_output=xml:'+str(out/(label+'.xml'))]
 start=time.monotonic();log=out/(label+'.log')
 with log.open('w') as f:
  proc=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',mode=mode,pid=proc.pid);save();print(mode,proc.pid,flush=True);code=proc.wait()
 text=log.read_text();summary=[line for line in text.splitlines() if 'SUMMARY:' in line]
 stage=dict(label=label,mode=mode,command=command,exit_code=code,elapsed_seconds=time.monotonic()-start,summary=summary)
 if code==0:
  assert any(re.search(r'(?:ERROR SUMMARY: 0 errors|RACECHECK SUMMARY: 0 hazards)',s) for s in summary),summary
  assert (out/(label+'.xml')).exists()
 r['stages'].append(stage);save();print(mode,code,stage['elapsed_seconds'],summary,flush=True)
assert all(sha(Path(p))==expected for p,expected in r['artifacts'].items())
r.update(state='TERMINAL_PASS' if all(s['exit_code']==0 for s in r['stages']) else 'TERMINAL_FAIL');r.pop('pid',None);save()
print(r['state'],flush=True)
