#include <hyle/graph/batch.h>
