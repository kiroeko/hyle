#include <hyle/compute/detail/batch_graph_access.h>
