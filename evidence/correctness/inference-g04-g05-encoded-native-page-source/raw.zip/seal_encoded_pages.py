from pathlib import Path
import hashlib, json, zipfile, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
RUN=ROOT/'.scratch/inference-gaps/g04-g05/encoded-pages'
OUT=ROOT/'evidence/correctness/inference-g04-g05-encoded-native-page-source'
final={'apple':4,'vulkan':2}
records=[]
source_paths=['tests/compute_batch/encoded_page_native_consumer.cc',
              'src/graph_route_vulkan/vulkan_lowering.cc']
current={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in source_paths}
for route,last in final.items():
 for i in range(1,last+1):
  record=json.loads((RUN/f'result-{route}-{i}.json').read_text())
  assert record['state'].startswith('TERMINAL_')
  record['attempt']=f'{route}-{i}';records.append(record)
  if i!=last:continue
  assert record['state']=='TERMINAL_PASS'
  xml=ET.parse(RUN/f'tests-{route}-{last}.xml').getroot()
  assert int(xml.attrib['tests'])==3 and int(xml.attrib['failures'])==0
  inputs={item['path']:item['sha256'] for item in record['inputs']}
  for name,digest in current.items():assert inputs[name]==digest,(route,name)
OUT.mkdir(parents=True,exist_ok=False)
result={
 'kind':'G04_G05_ENCODED_NATIVE_PAGE_DELTA_SOURCE_STAGE',
 'verdict':'PASS_FINITE_ACTUAL_AIR_APPLE_VULKAN_NATIVE_AND_CPU_JOINT_SOURCE',
 'owners_remain':'AUDITED, eleven owners; whole G04/G05 not accepted',
 'input_sha256':current,
 'delivery':'Cached ordinary shared source parents, canonical Windows one-way archives, shipping product with separate GTest executable',
 'tests':'3 tests per actual route: 8 successful episodes x6 updates plus4 accepted numerical failure episodes per route',
 'qualified':[
  'Actual Apple and Vulkan, native page receiver and CPU+GPU joint Graph receiver; no CPU fallback for native page math',
  'Single request activeQ1 and two requests activeQ18, Dqk/Dv(64,128) and(256,256), page16, causal window16',
  'Alternating paired K/V CacheEncode nodes in one Graph and two separately accepted Graph results to the same original F2 Update',
  'Nonzero dirty K and Q=.125; joint CPU Abs(-.125)/Cast and Cast/Neg suffix, independently weighted softmax over reference Q8 bytes',
  'No intermediate producer/F2 wait, move-only source ownership, retained results prevent update recovery, original controls returned after final completion',
  'First update explicitly clones old pages; subsequent updates copy only actual dirty encoded K/V rows with independent row widths',
  'Full K/V destination byte oracles include untouched rows; shared clean page and retained old page bytes stay unchanged',
  'Old frame remains read-protected and actual old attention still matches its independent oracle after all new version updates',
  'Paired-Graph and independent second-Graph NaN source errors propagate InvalidArgument through final result/completion; every destination writer rejects publication',
  'Vulkan Graph default CacheEncode forwards to original already-qualified Compute Plan without user custom lowering'],
 'P0':'Original Graph/Program/slots/status/result/F2/controller/queue and exact page guards reused; CE09 is one cold allowlist entry. '
      'Encoder work is only new dirty rows. First-episode clone is explicit; later logical bytes=requests*(Krow+Vrow). '
      'No new runtime, public metadata, full-history decode, mask or capture claim. Native private storage remains UNKNOWN.',
 'not_proven':['CPU/CUDA new-domain producer/F2/Graph consumers and CPU-only ffa execution',
   'New-domain complete OOM/cancellation/unknown/concurrency/retirement and tiny-scale numerical risk matrix',
   'static/shared installed SDK delivery and remaining source profiles','qualified P1','whole G01/G02/G04/G05 and G06-G10'],
 'runs':[{k:v for k,v in item.items() if k!='inputs'} for item in records],
 'cumulative_seconds':sum(item['cumulative_seconds'] for item in records)}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for file in sorted(RUN.iterdir()):
  if file.is_file() and file.suffix!='.zip':archive.write(file,file.name)
 for record in records:
  attempt=record['attempt']
  with zipfile.ZipFile(RUN/f'source-{attempt}.zip') as source:
   for name in source_paths:archive.writestr(f'inputs/{attempt}/{name}',source.read(name))
 for name in ['encoded_pages_air.py','launch_encoded_pages.py','seal_encoded_pages.py']:
  archive.write(RUN.parent/name,name)
print(json.dumps({'final_tests_per_route':3,'cumulative_seconds':result['cumulative_seconds']}))
