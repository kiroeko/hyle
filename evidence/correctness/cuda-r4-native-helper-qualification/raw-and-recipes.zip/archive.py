from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).parent
repo = Path('C:/public/project-hyle/hyle')
target = repo / 'evidence/correctness/cuda-r4-native-helper-qualification'
target.mkdir(parents=True, exist_ok=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, value):
    (target / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
regression = json.loads((root / 'regression.json').read_text())
receipts = {mode: json.loads((root / f'aa/cuda-{mode}-aa.json').read_text()) for mode in ('compute', 'graph')}
assert regression['gate'] == 'PASS' and all(r['gate'] == 'PASS' for r in receipts.values())
write('summary.json', {'candidate': regression['candidate'], 'gate': 'PASS', 'product_changed': False,
      'p1_run': False, 'progress_launches': len(regression['runs']),
      'max_progress_seconds': max(r['elapsed_seconds'] for r in regression['runs']),
      'negative_guards': len(regression['negative']), 'policy': regression['policy'],
      'aa': {mode: {'gate': receipt['gate'], 'runs': len(receipt['runs']),
             'summaries': receipt['summaries']} for mode, receipt in receipts.items()}})
write('artifacts.json', {p.name: sha(p) for p in sorted(Path('C:/hv4q2/bin').iterdir())
                        if p.suffix in ('.exe', '.dll')})
paths = ['include/hyle/compute', 'include/hyle/graph']
paths += sorted(p.relative_to(repo).as_posix() for p in (repo / 'src').iterdir()
                if p.is_dir() and p.name.startswith(('compute', 'graph')))
command = ['python', 'scripts/loc-report.py', '--module', 'compute_graph',
           '--self-check', '--json', '--commit', regression['candidate']]
for path in paths:
    command += ['--module-path', path]
result = subprocess.run(command, cwd=repo, check=True, capture_output=True, text=True, encoding='utf-8')
(target / 'loc.json').write_text(result.stdout, encoding='utf-8', newline='\n')
with zipfile.ZipFile(target / 'raw-and-recipes.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            archive.write(path, path.relative_to(root).as_posix())
    for name in ('CMakeCache.txt', 'compile_commands.json'):
        archive.write(Path('C:/hv4q2') / name, f'build/{name}')
write('sha256.json', {p.name: sha(p) for p in sorted(target.iterdir())
                     if p.is_file() and p.name != 'sha256.json'})
print(json.dumps({'evidence': str(target), 'summary': json.loads((target / 'summary.json').read_text())}))
