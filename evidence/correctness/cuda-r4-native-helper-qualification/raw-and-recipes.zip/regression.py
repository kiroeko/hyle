import _winapi
import ctypes as c
from ctypes import wintypes as w
import hashlib
import importlib.util
import json
import msvcrt
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).parent
BUILD = Path('C:/hv4q2')
REPO = Path('C:/public/project-hyle/hyle')
spec = importlib.util.spec_from_file_location('cuda_aa', REPO / 'bench/compute_route_cuda/validate_aa.py')
aa = importlib.util.module_from_spec(spec)
spec.loader.exec_module(aa)
sys.path.insert(0, 'C:/hyle-scratch/r4-cuda-20260916/progress-diagnosis')
import observe as obs
set_thread_affinity = obs.bind('SetThreadAffinityMask', [w.HANDLE, c.c_size_t], c.c_size_t)
get_affinity = obs.bind('GetProcessAffinityMask', [w.HANDLE, c.POINTER(c.c_size_t), c.POINTER(c.c_size_t)])
get_priority = obs.bind('GetPriorityClass', [w.HANDLE], w.DWORD)
if not obs.set_affinity(obs.current(), 0x40):
    raise c.WinError(c.get_last_error())
profile = aa.get_machine_profile(aa.load_registry(), 'W1-WIN')
probe = aa.probe_machine(paths=[('build', BUILD)])
gate = aa.evaluate_machine_profile(profile, probe, role='engineering', sampling_topology=aa.TOPOLOGY)
if gate['gate'] != 'PASS':
    raise RuntimeError(gate)
policy = aa.expected_child_policy(profile, probe=probe, sampling_topology=aa.TOPOLOGY)
aa.stage_runtime(BUILD)
prefix = Path('C:/hyle-scratch/r4-cuda-20260916/context-causality/prefix.exe')
report = {'candidate': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
          'policy': policy, 'machine': gate['physical_host_identity'],
          'prefix_sha256': aa.digest(prefix), 'gpu_before': aa.gpu_facts(), 'runs': [], 'negative': []}

def save():
    (ROOT / 'regression.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')

def run(exe, label, env, mask=None, expected=0, error=None):
    directory = ROOT / label
    directory.mkdir()
    if mask is None:
        mask = int(policy['affinity_mask'], 16)
    log = directory / 'process.log'
    with open(os.devnull, 'rb') as inp, log.open('wb') as out:
        handles = [msvcrt.get_osfhandle(f.fileno()) for f in (inp, out)]
        for handle in handles:
            os.set_handle_inheritable(handle, True)
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESTDHANDLES
        si.hStdInput, si.hStdOutput, si.hStdError = handles[0], handles[1], handles[1]
        hp, ht, pid, tid = _winapi.CreateProcess(str(exe), subprocess.list2cmdline([str(exe)]),
            None, None, True, 0x4 | subprocess.ABOVE_NORMAL_PRIORITY_CLASS, env, str(exe.parent), si)
        for handle in handles:
            os.set_handle_inheritable(handle, False)
        row = {'label': label, 'pid': pid, 'primary_thread': tid, 'expected_exit': expected}
        try:
            if not obs.set_affinity(hp, mask):
                raise c.WinError(c.get_last_error())
            if not set_thread_affinity(ht, 1 << policy['caller_logical_cpu']):
                raise c.WinError(c.get_last_error())
            observed, system = c.c_size_t(), c.c_size_t()
            if not get_affinity(hp, c.byref(observed), c.byref(system)):
                raise c.WinError(c.get_last_error())
            row.update(parent_mask=hex(observed.value), priority_class=get_priority(hp),
                       caller_mask=hex(1 << policy['caller_logical_cpu']))
            if observed.value != mask or row['priority_class'] != 0x8000:
                raise RuntimeError('suspended launch policy mismatch')
            started = time.monotonic()
            if obs.resume(ht) == 0xffffffff:
                raise c.WinError(c.get_last_error())
            if _winapi.WaitForSingleObject(hp, 10000) == 258:
                row['threads'] = obs.thread_facts(pid)
                row['capture_exit'] = obs.capture(pid, tid, directory / 'active')
                _winapi.TerminateProcess(hp, 124)
                _winapi.WaitForSingleObject(hp, 10000)
                row['timeout'] = True
            row['elapsed_seconds'] = time.monotonic() - started
            row['exit_code'] = _winapi.GetExitCodeProcess(hp)
        finally:
            if _winapi.GetExitCodeProcess(hp) == 259:
                _winapi.TerminateProcess(hp, 125)
                _winapi.WaitForSingleObject(hp, 10000)
            obs.close(ht)
            obs.close(hp)
    row['log_sha256'] = aa.digest(log)
    output = log.read_text(encoding='utf-8', errors='replace')
    row['pass'] = row['exit_code'] == expected and (error is None or error in output)
    (report['runs'] if expected == 0 else report['negative']).append(row)
    save()
    if not row['pass']:
        raise RuntimeError(f'finite regression stopped: {row}')
    return row

base = aa.child_environment()
base.update(HYLE_PERF_CALLER_CPU=str(policy['caller_logical_cpu']),
            HYLE_PERF_PARENT_MASK=policy['affinity_mask'], HYLE_PERF_PRIORITY=policy['priority'],
            HYLE_PERF_SAMPLING_TOPOLOGY=aa.TOPOLOGY, HYLE_PERF_RUN_NONCE='native-helper-regression')
for index in range(32):
    run(prefix, f'prefix-{index:02d}', base)
print('prefix 32/32 PASS', flush=True)
for mode in ('compute', 'graph'):
    exe = BUILD / 'bin' / f'hyle_{mode}_route_cuda_bench.exe'
    ready = BUILD / 'bin' / f'hyle_cuda_{mode}_aa.ready'
    if ready.exists():
        raise RuntimeError('negative guard needs fresh build without receipt')
    run(exe, f'{mode}-guard-missing', base, expected=86, error='A/A qualification has not passed')
    ready.write_text('FAIL\n', encoding='ascii')
    run(exe, f'{mode}-guard-fail', base, expected=86, error='A/A qualification has not passed')
exe = BUILD / 'bin/hyle_compute_route_cuda_bench.exe'
one = dict(base, HYLE_PERF_PARENT_MASK=hex(1 << policy['caller_logical_cpu']))
run(exe, 'wrong-process-budget', one, mask=1 << policy['caller_logical_cpu'], expected=86, error='CPU budget/priority does not match')
missing = dict(base)
del missing['HYLE_PERF_PARENT_MASK']
run(exe, 'missing-parent-mask', missing, expected=86, error='CPU budget/priority does not match')
wrong = dict(base, HYLE_PERF_PRIORITY='normal')
run(exe, 'wrong-priority', wrong, expected=86, error='CPU budget/priority does not match')
report['gpu_after'] = aa.gpu_facts()
report['gate'] = 'PASS'
save()
print('negative guards 7/7 PASS', flush=True)
