from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parents[3]
work = root / '.scratch/inference-gaps/g03/apple-source-stage'
work.mkdir(exist_ok=True)
remote_script = work / 'apple_source_air.py'
text = (work.parent/'native_producer_shape_air.py').read_text()
text = text.replace('g03-native-producer-shape', 'g03-apple-source-stage')
text = text.replace('cfb883a3bb819cb171325daecc42dfe60f0733bd', '70a1943fb')
text = text.replace('SCOPED public probe; product unchanged b42832de3ddda21bdc3e98ad4cc87e73622cbba4', 'AUDITED WORKTREE Apple source qualification')
text = text.replace('actual two ready Apple ABS outputs -> readonly export -> original F2 copy; fixed resource identity qualification; not complete pending page attention', 'actual 64 ready Apple ABS outputs -> fixed original F2 program/two slots; readonly source qualification; not pending page attention')
remote_script.write_text(text)
paths = ['src/compute_route_apple/apple_copy_internal.h',
         'src/compute_route_apple/apple_memory.mm',
         'src/compute_route_apple/apple_copy_program.cc',
         'include/hyle/compute/apple_memory.h',
         'tests/compute_batch/native_producer_copy_shape_probe.cc']
number = 1
while (work / f'input-{number}.zip').exists(): number += 1
archive = work / f'input-{number}.zip'
manifest = []
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as package:
    for path in paths:
        data = (root/path).read_bytes()
        manifest.append({'path':path, 'sha256':hashlib.sha256(data).hexdigest()})
        package.writestr(path, data)
    package.writestr('input-manifest.json', json.dumps(manifest, indent=2)+'\n')
host = 'kiro@172.22.10.198'
remote = '/Users/kiro/hyle-scratch/compute-unified/g03-apple-source-stage'
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,'mkdir -p '+remote], check=True)
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',str(archive),str(remote_script),f'{host}:{remote}/'], check=True)
result = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,f'python3 {remote}/{remote_script.name} {archive.name} apple'])
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',f'{host}:{remote}/result.json',f'{host}:{remote}/job.json',str(work)], check=True)
raise SystemExit(result.returncode)
