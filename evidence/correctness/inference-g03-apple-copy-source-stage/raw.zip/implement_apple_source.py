from pathlib import Path

def replace(path, before, after):
    p = Path(path)
    data = p.read_bytes()
    nl = b'\r\n' if b'\r\n' in data else b'\n'
    old = before.encode().replace(b'\n', nl)
    new = after.encode().replace(b'\n', nl)
    assert data.count(old) == 1, path
    p.write_bytes(data.replace(old, new))

replace('src/compute_route_apple/apple_copy_internal.h',
    'bool is_copy_resource(mem::MemoryResourceRef resource) noexcept;',
    '''bool is_copy_resource(mem::MemoryResourceRef resource) noexcept;
// A readonly MLX export owns a distinct resource token for correct freeing.
// Only that private carrier may match a nominated native source family.
bool copy_source_resource_matches(mem::MemoryResourceRef nominated,
                                  mem::MemoryResourceRef actual) noexcept;''')
replace('src/compute_route_apple/apple_memory.mm',
    'Result<CopySpan> copy_span(mem::ConstBufferView view) noexcept {',
    '''bool copy_source_resource_matches(mem::MemoryResourceRef nominated,
                                  mem::MemoryResourceRef actual) noexcept {
  if (actual == nominated) return true;
  if (!actual.valid() || !nominated.valid() ||
      dynamic_cast<ImportedArrayStorage *>(&actual.resource()) == nullptr ||
      dynamic_cast<MemoryState *>(&nominated.resource()) == nullptr)
    return false;
  return actual.domain() == nominated.domain();
}
Result<CopySpan> copy_span(mem::ConstBufferView view) noexcept {''')
replace('src/compute_route_apple/apple_copy_program.cc',
    '''  if (view.resource() != spec.resource || view.size() > spec.capacity_bytes)
    return Status::InvalidArgument("Apple copy source endpoint/capacity differs");''',
    '''  if (!detail::copy_source_resource_matches(spec.resource, view.resource()) ||
      view.size() > spec.capacity_bytes)
    return Status::InvalidArgument("Apple copy source endpoint/capacity differs");''')
replace('include/hyle/compute/apple_memory.h',
    '  HYLE_COMPUTE_ROUTE_APPLE_API Status bind_source(CopyResourceId, const ReadLease &) noexcept;',
    '''  // Accept the exact nominated resource or a trusted readonly MLX export
  // from its native family. Retains that export's actual owner and byte range;
  // replay preparation still verifies the original Metal Device. Mutable
  // endpoints require the exact resource. No implicit evaluation or wait.
  HYLE_COMPUTE_ROUTE_APPLE_API Status bind_source(CopyResourceId, const ReadLease &) noexcept;''')
p = Path('docs/user/apple-compute.md')
data = p.read_bytes()
nl = b'\r\n' if b'\r\n' in data else b'\n'
addition = '''

## 原生只读输出到固定 copy slot

成功的原生输出可经 `MemoryResource::import_readonly` 导出为独立永久只读 lease。
冷准备 `CopyBatchProgram` 时以原 `memory.ref()` 与最大来源字节数声明 source endpoint，
每步可将新的导出 `ReadLease` 绑定到同一 `CopyBatchInvocation`，无需按导出的 resource
identity 重建 program/slot。`bind_source` 只接受原资源或受信 MLX readonly 导出家族；
仅伪造相同 domain、host accessible 或来自其它普通 resource 均不成立。

导出实际拥有者和精确 subview 会由原 F2 binding 保留；每次 replay 仍校验容量、别名和
真实 Metal device，可写 endpoint 仍须精确资源身份。`reset`/重新绑定与关闭沿原实际
退休规则清理持有者。readonly import 自身仍有冷 metadata/opaque MLX descriptor 成本，
原 `MemoryResource` 仍需活到所有 program/slot/提交退休，不能经其它 MLX alias 改写源。
这里消费成功 ready 输出，没有隐式求值、producer 等待或 pending 结果转换。
'''
assert '## 原生只读输出到固定 copy slot'.encode() not in data
p.write_bytes(data + addition.encode().replace(b'\n', nl))
print('AS01 implemented; original file newlines preserved')
