from pathlib import Path

p = Path('tests/compute_batch/dirty_page_native_consumer.cc')
data = p.read_bytes()
nl = b'\r\n' if b'\r\n' in data else b'\n'
def change(old, new):
    global data
    old = old.encode().replace(b'\n', nl)
    assert data.count(old) == 1, old
    data = data.replace(old, new.encode().replace(b'\n', nl))
change('#include <vector>', '''#include <vector>
#if defined(HYLE_DIRTY_PAGE_NATIVE_PRODUCER)
#include <mlx/ops.h>
#include <mlx/transforms.h>
#endif''')
change('  const std::array update_specs{c::CopyResourceSpec{staging.ref(),4*row_bytes},',
'''#if defined(HYLE_DIRTY_PAGE_NATIVE_PRODUCER)
  namespace mx=mlx::core;
  const auto native_type=bf?mx::bfloat16:mx::float16;
  const std::array producer_specs{n::InputSpec{{4,2,256},native_type}};
  HYLE_ASSIGN_OR_RETURN(auto producer,context.prepare(c::Unary{c::UnaryKind::kAbs},producer_specs));
  HYLE_ASSIGN_OR_RETURN(auto producer_slot,producer.create_invocation());
  HYLE_ASSIGN_OR_RETURN(auto producer_desc,c::TensorDesc::dense(cap.data_type,
      std::array<std::int64_t,3>{4,2,256}));
  const auto source_resource=device.ref();
#else
  const auto source_resource=staging.ref();
#endif
  const std::array update_specs{c::CopyResourceSpec{source_resource,4*row_bytes},''')
change('''    HYLE_ASSIGN_OR_RETURN(auto hw,host_pool.allocate(incoming.size()*2,64));
    HYLE_RETURN_IF_ERROR(hw.view()->write(std::as_bytes(std::span(incoming))));
    HYLE_ASSIGN_OR_RETURN(auto host,hw.publish());HYLE_RETURN_IF_ERROR(update.bind_source({0},host));''',
'''#if defined(HYLE_DIRTY_PAGE_NATIVE_PRODUCER)
    // The finite producer has fixed ports; unused rows are not copied to pages.
    std::vector<std::uint16_t> negative(4*row_elements,0x8000);
    for(std::size_t i=0;i<incoming.size();++i)negative[i]=incoming[i]|0x8000U;
    auto input=mx::view(mx::array(negative.data(),mx::Shape{4,2,256},mx::uint16),native_type);
    mx::async_eval({input});mx::synchronize(mx::default_stream(mx::Device::gpu));input.wait();
    const std::array producer_inputs{input};HYLE_RETURN_IF_ERROR(producer_slot.bind(producer_inputs));
    c::ReadLease produced;
    {HYLE_ASSIGN_OR_RETURN(auto pending,producer_slot.submit());
      HYLE_ASSIGN_OR_RETURN(auto result,pending.wait());
      HYLE_ASSIGN_OR_RETURN(produced,device.import_readonly(result->arrays()[0],producer_desc));}
    HYLE_RETURN_IF_ERROR(update.bind_source({0},produced));
#else
    HYLE_ASSIGN_OR_RETURN(auto hw,host_pool.allocate(incoming.size()*2,64));
    HYLE_RETURN_IF_ERROR(hw.view()->write(std::as_bytes(std::span(incoming))));
    HYLE_ASSIGN_OR_RETURN(auto host,hw.publish());HYLE_RETURN_IF_ERROR(update.bind_source({0},host));
#endif''')
change('  HYLE_RETURN_IF_ERROR(update.close());HYLE_RETURN_IF_ERROR(slot.drain());',
'''  HYLE_RETURN_IF_ERROR(update.close());HYLE_RETURN_IF_ERROR(slot.drain());
#if defined(HYLE_DIRTY_PAGE_NATIVE_PRODUCER)
  std::fprintf(stderr,"actual native Abs producer -> readonly -> fixed F2 -> original dirty page -> attention PASS; producer program/slot reused64, no host K/V result download, explicit producer-ready waits remain\\n");
#endif''')
p.write_bytes(data)
print('native producer branch added; default Apple/Vulkan journey unchanged')
