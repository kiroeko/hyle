from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parents[3]
work = root / '.scratch/inference-gaps/g03/apple-source-stage'
script = work/'apple_source_journey_air.py'
text = (work/'apple_source_air.py').read_text()
marker = "    old = cmake.read_text()"
setup = '''    addition += '\\nadd_executable(g03_apple_producer_page "'+str(source/'tests/compute_batch/dirty_page_native_consumer.cc')+'")\\n'
    addition += 'target_compile_features(g03_apple_producer_page PRIVATE cxx_std_23)\\n'
    addition += 'target_compile_options(g03_apple_producer_page PRIVATE -Wall -Wextra -Wpedantic -Werror)\\n'
    addition += 'target_compile_definitions(g03_apple_producer_page PRIVATE HYLE_DIRTY_PAGE_APPLE=1 HYLE_DIRTY_PAGE_NATIVE_PRODUCER=1)\\n'
    addition += 'target_link_libraries(g03_apple_producer_page PRIVATE hyle::compute)\\n'
    addition += 'hyle_stage_runtime(g03_apple_producer_page)\\n'
    addition += '\\nadd_executable(g03_apple_copy_tests "'+str(source/'tests/compute_route_apple/copy_program_test.cc')+'" "'+str(source/'tests/compute_route_apple/copy_recording_test.cc')+'")\\n'
    addition += 'target_compile_features(g03_apple_copy_tests PRIVATE cxx_std_23)\\n'
    addition += 'target_include_directories(g03_apple_copy_tests PRIVATE "'+str(source/'src/compute_route_apple')+'")\\n'
    addition += 'target_link_libraries(g03_apple_copy_tests PRIVATE hyle::compute GTest::gtest_main)\\n'
    addition += 'hyle_stage_runtime(g03_apple_copy_tests)\\n'
'''
text = text.replace(marker, setup+marker)
text = text.replace("if 'add_executable(g03_native_producer_shape ' not in old:", "if 'add_executable(g03_apple_producer_page ' not in old:")
# Existing first target stays in the parent. Append just the newly named pair.
text = text.replace('cmake.write_text(old + addition)', "cmake.write_text(old + addition[addition.index('\\nadd_executable(g03_apple_producer_page '):])")
text = text.replace("'--target', 'g03_native_producer_shape', '--parallel', '4'", "'--target', 'g03_native_producer_shape', 'g03_apple_producer_page', 'g03_apple_copy_tests', 'g03_native_dirty_risks', 'g02_native_page_joint', '--parallel', '4'")
text = text.replace("    commands = json.loads", "    run(route, 'native-producer-page', [str(build/'g03_apple_producer_page')])\n    run(route, 'copy-unit', [str(build/'g03_apple_copy_tests')])\n    run(route, 'copy-risks', [str(build/'g03_native_dirty_risks')])\n    run(route, 'graph-direct', [str(build/'g02_native_page_joint')])\n    commands = json.loads")
script.write_text(text)
paths = ['src/compute_route_apple/apple_copy_internal.h', 'src/compute_route_apple/apple_memory.mm',
         'src/compute_route_apple/apple_copy_program.cc', 'include/hyle/compute/apple_memory.h',
         'tests/compute_batch/native_producer_copy_shape_probe.cc',
         'tests/compute_batch/dirty_page_native_consumer.cc',
         'tests/compute_route_apple/copy_program_test.cc', 'tests/compute_route_apple/copy_recording_test.cc']
number = 1
while (work/f'input-{number}.zip').exists(): number += 1
archive = work/f'input-{number}.zip'
manifest = []
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
    for path in paths:
        data = (root/path).read_bytes()
        manifest.append({'path':path,'sha256':hashlib.sha256(data).hexdigest()})
        package.writestr(path,data)
    package.writestr('input-manifest.json',json.dumps(manifest,indent=2)+'\n')
host='kiro@172.22.10.198'
remote='/Users/kiro/hyle-scratch/compute-unified/g03-apple-source-stage'
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',str(archive),str(script),f'{host}:{remote}/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,f'python3 {remote}/{script.name} {archive.name} apple'])
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',f'{host}:{remote}/result.json',f'{host}:{remote}/job.json',str(work)],check=True)
raise SystemExit(result.returncode)
