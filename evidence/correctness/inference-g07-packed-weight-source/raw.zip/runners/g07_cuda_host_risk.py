from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps';mode=sys.argv[1]
assert mode in ['asan','ubsan','tsan'];out=scratch/f'g07-cuda-host-{mode}-1'
resume='--resume-tests' in sys.argv
if not resume:out.mkdir(exist_ok=False)
base=Path('/root/hyle-scratch/compute-unified');source=base/'source-7a7b4c3b';old=base/f'foundation-f5-native-host-cuda-{mode}';build=old/'build'
previous={'asan':'asan-5','ubsan':'ubsan-6','tsan':'tsan-4'}[mode]
original=scratch/f'g06/final-host-{previous}/targets.cmake';assert original.is_file()
prior=json.loads((scratch/'g07-cuda-source-4/result.json').read_text());assert prior['state']=='SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING'
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
env.update(ASAN_OPTIONS='halt_on_error=1:protect_shadow_gap=0:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0')
started=time.monotonic();r=dict(state='SETUP',mode=mode,pid=os.getpid(),candidate=prior['candidate'],identity=prior['identity'],build=str(build),stages=[],limits=['Only host address/undefined/data-race facet; no shader/driver/private-pool or leak certificate. Original NVIDIA process leak and diagnostic-thread lifetime unknowns retained.'],max_jobs=2)
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
 stamp=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(mode,stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
def finish():
 paths=[p/'g07_host_packed' for p in [build,build/'bin',build/'hyle'] if (p/'g07_host_packed').exists()];assert len(paths)==1
 binary=paths[0];prefix=['setarch','x86_64','-R'] if mode=='tsan' else []
 run('tests',prefix+[str(binary),'--gtest_output=xml:'+str(out/'tests.xml')])
 r['artifact']=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
 r['state']='HOST_FACET_PASS';save();print(mode,r['state'],flush=True)
if resume:
 r=json.loads((out/'result.json').read_text());assert r['state']=='SETUP_FAIL' and any(x['stage']=='build' and x['exit_code']==0 for x in r['stages'])
 started=time.monotonic()-r['elapsed_seconds'];r['prior_setup_failure']=r.pop('error');r['resume_reason']='Retain same built tree, locate binary under parent hyle/ subdirectory; no rebuild or budget reset'
 finish();raise SystemExit(0)
try:
 hook=out/'targets.cmake';hook.write_text('include("'+str(original)+'")\n'+'''if(PROJECT_NAME STREQUAL "hyle")
 function(g07_host)
  set_target_properties(hyle_compute_provider_torch_cuda PROPERTIES JOB_POOL_COMPILE g04_cuda_san_compile CUDA_ARCHITECTURES 89-real)
  target_compile_options(hyle_compute_provider_torch_cuda PRIVATE "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
  add_executable(g07_host_packed "@SOURCE@/tests/compute_provider_torch_cuda/packed_test.cc" "@SOURCE@/tests/compute_provider_torch_cuda/mlx_precision_test.cc")
  target_compile_features(g07_host_packed PRIVATE cxx_std_23)
  target_link_libraries(g07_host_packed PRIVATE hyle_compute_route_cuda hyle_compute_backend_cuda hyle_compute_provider_torch_cuda GTest::gtest_main torch torch_cpu c10 hyle_vendor_c10_cuda CUDA::cudart)
  get_target_property(leaf hyle_vendor_c10_cuda IMPORTED_LOCATION)
  get_filename_component(leaf_directory "${leaf}" DIRECTORY)
  target_include_directories(g07_host_packed SYSTEM PRIVATE "${leaf_directory}/../include")
  if(TORCH_CXX_FLAGS)
   separate_arguments(flags NATIVE_COMMAND "${TORCH_CXX_FLAGS}")
   target_compile_options(g07_host_packed PRIVATE ${flags})
  endif()
  hyle_apply_sanitizer(g07_host_packed)
  hyle_stage_runtime(g07_host_packed)
 endfunction()
 cmake_language(DEFER CALL g07_host)
endif()
'''.replace('@SOURCE@',str(source)))
 configure=old/'parent' if mode=='asan' else source
 run('configure',['cmake','-S',str(configure),'-B',str(build),'-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES','-DCMAKE_PROJECT_INCLUDE='+str(hook),'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF'])
 commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],env=env,text=True))
 native=json.loads((scratch/'g04-g05/cuda-host-san/ggml-cuda-reuse-proof.json').read_text())['modes'][mode]
 assert hashlib.sha256(Path(native['archive']).read_bytes()).hexdigest()==native['archive_sha256']
 unary=next(x for x in commands if x['file'].endswith('/src/ggml-cuda/unary.cu'));derived=Path(unary['file'].split('/src/ggml-cuda/')[0])
 for name,digest in native['derived_dependencies']:assert hashlib.sha256((derived/name).read_bytes()).hexdigest()==digest
 for name,digest in native['canonical_dependencies']:assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
 r['native_reuse']=dict(archive=native['archive'],sha256=native['archive_sha256'],derived_inputs=len(native['derived_dependencies']),canonical_inputs=len(native['canonical_dependencies']))
 flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode]
 checked=[]
 for suffix in ['src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_provider_torch_cuda/mlx_packed_kernel.cu','tests/compute_provider_torch_cuda/packed_test.cc']:
  rows=[x for x in commands if x['file'].endswith('/'+suffix)];assert len(rows)==1 and flag in rows[0]['command'];checked.extend(rows)
 (out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2))
 run('manifest',['ninja','-C',str(build),'build.ninja'])
 preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
 dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n','g07_host_packed'],env=env,text=True);(out/'dry-run.log').write_text(dry)
 cuda=[x for x in dry.splitlines() if 'Building CUDA object' in x];r['cuda_edges']=cuda
 assert len(cuda)<=1 and all('compute_provider_torch_cuda' in x for x in cuda),cuda
 assert '/ggml-cuda/' not in dry and 'Re-running CMake' not in dry
 run('build',['ninja','-C',str(build),'-f',str(preview),'-j','2','g07_host_packed'])
 finish()
except BaseException as e:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(e));save()
 raise
