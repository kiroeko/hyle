from pathlib import Path
import datetime,hashlib,json,subprocess

root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
load=lambda name:json.loads((root/name).read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
intake=load('evidence/architecture/inference-g07-packed-weight-intake/receipt.json')
anchors=[]
for old in intake['current_source_anchors']:
    p=root/old['path'];assert sha(p)==old['sha256'],old['path']
    anchors.append(dict(path=old['path'],sha256=old['sha256'],matched_scoped_intake=True))
for name in ['tests/compute_provider_torch_cuda/mlx_precision_test.cc','src/compute_provider_torch_cuda/CMakeLists.txt','src/compute_route_apple/apple_context.cc','tests/compute_provider_torch_cuda/CMakeLists.txt']:
    anchors.append(dict(path=name,sha256=sha(root/name)))
dest=root/'evidence/architecture/inference-g07-packed-weight-audit';dest.mkdir(exist_ok=True)
record=dict(state='AUDIT_CHECKPOINT_1_NOT_FIX_FREEZE',timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    head=head,product_candidate='669121418669b31f6849c74f64362aaf8d6eb919',
    card='docs/implementation/tasks/compute/inference-g07-packed-weights.md',
    goal=dict(status='ACTIVE',scope=['G07','G08','G09','G10'],accepted_before_goal=['G01','G02','G03','G04','G05','G06'],completed_in_goal=0),
    owners=['compute_provider_torch_cuda','compute_route_apple'],owner_state='SCOPED',source_anchors=anchors,
    current_findings=[
        dict(family='W1',disposition='Existing native carrier reuse remains the first route',fact='Q4_K/Q6_K/Q8_0 carriers are already present; repeated-cost and ownership qualification still required. The Qwen vocabulary role is Q6_K, not inferred from Q4 filename.'),
        dict(family='W2 CUDA',disposition='Finite execution mechanism to resolve before FIX',fact='Borrowed ATen matmul loops over every K group, unpacks selected current group, creates float values and invokes matmul/add. It does not expand the entire expert bank, but repeats temporary values and calls on warm execution.'),
        dict(family='W3 CUDA',disposition='Preserve checked errors while selecting device checked carrier',fact='artifact_provider.cc currently converts IDs then performs any().item<bool>() before index_select, forcing a GPU-to-host control check. Do not remove bounds checks or publish a successful invalid result.'),
        dict(family='W2 Apple affine',disposition='KEEP/BORROW candidate, requires actual consumer qualification',fact='Existing quantized_matmul/gather_qmm and device status already provide a native packed route; do not replace this merely to create new code.'),
        dict(family='W2 Apple block128 / W4',disposition='Warm repetition not proven by decode source alone',fact='block_dot contains decode/matmul while Apple region compilation and explicit constants also exist. Must resolve compile/evaluation and constant/runtime-input boundaries before attributing a per-step cost or adding a cache.'),
        dict(family='Precision/repack',disposition='No automatic AWQ/Marlin equivalence',fact='Existing affine precision test admits scale=.1 and bias=.03 for q7/q5 with activation1/-1.375; bias/scale=.3 is not an integer zero point. A representation requiring integer zero points cannot be assumed to preserve this affine domain.',proof='Source-level algebraic constraint from an existing test, not a newly executed GPU test; mature repack/native backend precision must be checked separately.')],
    frozen_scope_unchanged=True,product_fix_set_frozen=False,product_changes=[],registry_changes=[],new_builds=0,new_runtime_tests=0,new_p1_runs=0,
    next_action='Finish the existing W1-W4 native-carrier/input-mutability and checked-status audit, freeze finite KEEP/FIX/BORROW plus API/cost/validation before entering AUDITED. No additional all-library or peer feature sweep.',
    cost='Existing G07 intake costs retained. This checkpoint is source-only and not separately stopwatched; no reset of original budget/failures. No heavy job.',
    setup_notes=['Attempted to open a presumed foundation-audit raw.zip; no such archive exists. Used its actual source-manifest and existing scoped receipt instead; no build/runtime effect.'],
    limits=['No new mathematical/runtime PASS or performance direction.', 'G08-G10 remain future scoped work in this goal; CLI implementation follows all four and is not part of the goal.'])
(dest/'checkpoint-1.json').write_bytes((json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps(dict(state=record['state'],matched_intake_anchors=sum(x.get('matched_scoped_intake',False) for x in anchors),additional_anchors=len(anchors)-len(intake['current_source_anchors']),goal='ACTIVE',product_changes=0)))
