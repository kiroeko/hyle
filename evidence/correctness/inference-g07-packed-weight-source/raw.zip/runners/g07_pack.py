from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
root=Path.cwd(); attempt=sys.argv[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
path=root/f'.scratch/inference-gaps/g07-input-{attempt}.zip'
manifest=dict(candidate=head,inputs=[])
with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 for name in subprocess.check_output(['git','ls-files'],text=True).splitlines():
  if name.startswith(('evidence/','.scratch/','.git')):continue
  p=root/name
  if p.is_file():
   data=p.read_bytes();manifest['inputs'].append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()));z.writestr(name,data)
 z.writestr('input-manifest.json',json.dumps(manifest,indent=2))
print(json.dumps(dict(candidate=head,files=len(manifest['inputs']),bytes=path.stat().st_size,archive=str(path))))
