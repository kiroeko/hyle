from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd()
normalized=lambda p:p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
base=root/'third_party/mlx_cuda_quant'
p=base/'SOURCE.json'; source=json.loads(p.read_text(encoding='utf-8'))
source['name']='mlx_cuda_quant'
path='mlx/backend/cuda/quantized/qmm/qmv.cu'
original=root/'.scratch/inference-gaps/g07-native-audit/source'/path
entry=dict(path=path,url='https://raw.githubusercontent.com/ml-explore/mlx/'+source['revision']+'/'+path,
           bytes=original.stat().st_size,sha256=sha(original.read_bytes()))
assert entry['sha256']=='023d967bdab912ee954258153ee9b200bdc9f7ed690f3ecd3b9d3b1eac74171d'
source['additional_sources']=[x for x in source['additional_sources'] if x.get('path')!=path]+[entry]
p.write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
manifest=''.join(f'{p.relative_to(base).as_posix()}|{sha(normalized(p))}\n' for p in sorted(base.rglob('*'),key=lambda p:p.relative_to(base).as_posix()) if p.is_file())
tree=sha(manifest.encode())
lock=root/'cmake/HyleDependencyLock.json'
raw=subprocess.check_output(['git','show','HEAD:cmake/HyleDependencyLock.json'])
old=raw.decode('utf-8'); data=json.loads(old)
entries=data['dependencies']
if isinstance(entries,dict): entries=list(entries.values())
entry=next(x for x in entries if x['name']=='mlx_cuda_quant')
text=old.replace(entry['vendored']['tree_sha256'],tree)
notice=next(x for x in entry['license']['files'] if x['path'].endswith('NOTICE.md'))
text=text.replace(notice['sha256'],sha(normalized(base/'NOTICE.md')))
lock.write_bytes(text.encode('utf-8'))
after=json.loads(text)
other=lambda d:[x for x in d['dependencies'] if x['name']!='mlx_cuda_quant']
assert other(data)==other(after)
print(json.dumps(dict(tree_sha256=tree,only_dependency_changed='mlx_cuda_quant')))
