if(PROJECT_NAME STREQUAL "hyle")
  function(g07_cuda_profile)
    set_property(GLOBAL APPEND PROPERTY JOB_POOLS ce19_cuda_compile=1)
    foreach(owner IN ITEMS compute_provider_flashinfer compute_provider_torch_cuda)
      set_target_properties(hyle_${owner} PROPERTIES
        JOB_POOL_COMPILE ce19_cuda_compile CUDA_ARCHITECTURES 89-real)
      target_compile_options(hyle_${owner} PRIVATE
        "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
    endforeach()
    if(HYLE_BUILD_TESTS)
      foreach(route IN ITEMS compute graph)
        set(target g07_cuda_mlx_${route})
        add_executable(${target}
          "${PROJECT_SOURCE_DIR}/tests/${route}_route_cuda/d5_qwen38_official_test.cc"
          "${PROJECT_SOURCE_DIR}/tests/${route}_route_cuda/d5_qwen_gguf_vocabulary_test.cc")
        target_compile_features(${target} PRIVATE cxx_std_23)
        target_link_libraries(${target} PRIVATE hyle_compute_route_cuda hyle_graph_route_cuda GTest::gtest_main ggml)
        target_include_directories(${target} PRIVATE "$<TARGET_PROPERTY:ggml,SOURCE_DIR>")
        hyle_stage_runtime(${target})
      endforeach()
    endif()
  endfunction()
  cmake_language(DEFER CALL g07_cuda_profile)
endif()
