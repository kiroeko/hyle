from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g07-apple-device-risks-1';out.mkdir(exist_ok=False)
prior=json.loads((base/'g07-apple-source-5/result.json').read_text());assert prior['state']=='SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING'
build=Path(prior['build']);env=os.environ.copy();env.update(MTL_DEBUG_LAYER='1',MTL_SHADER_VALIDATION='1')
started=time.monotonic();r=dict(state='RUNNING',pid=os.getpid(),candidate=prior['candidate'],identity=prior['identity'],environment={k:env[k] for k in ['MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']},stages=[])
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
for target in ['g07_packed_fp8','g07_existing_weight_consumers']:
 binary=build/target;cmd=[str(binary),'--gtest_output=xml:'+str(out/(target+'.xml'))]
 if target=='g07_existing_weight_consumers':cmd+=['--gtest_filter=AppleMoeFragments.*Fp8*:AppleParityDirect.OfficialFp4ExpertsKeepOriginalFp8ActivationAndGroup32Weights']
 log=out/(target+'.log');stamp=time.monotonic()
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(stage=target,child_pid=p.pid);save();print(target,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=target,command=cmd,artifact_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
r['state']='APPLE_DEVICE_VALIDATION_PASS';save();print(r['state'],flush=True)
