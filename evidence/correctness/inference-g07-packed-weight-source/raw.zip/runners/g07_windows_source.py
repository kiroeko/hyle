from pathlib import Path
import hashlib,json,os,subprocess,sys,time
attempt=sys.argv[1] if len(sys.argv)>1 else '1'
root=Path.cwd();out=root/f'.scratch/inference-gaps/g07-windows-source-{attempt}';out.mkdir(exist_ok=False)
parent=Path('C:/h7/w-cpu-cuda/selected-graph/source-parent');build=parent.parent/'source-build'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
setup=subprocess.run(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.stdout.splitlines() if '=' in line and not line.startswith('=')))
started=time.monotonic();r=dict(state='SETUP',pid=os.getpid(),candidate=head,build=str(build),max_jobs=2,nvcc_pool=1,nvcc_split_compile=3,stages=[],scope='Windows/MSVC source portability and original public CUDA route only; previous WSL/Air tests retained; not SDK/P1 verdict')
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
def run(stage,cmd):
 stamp=time.monotonic();log=out/(stage+'.log')
 with log.open('w',encoding='utf-8') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(encoding='utf-8',errors='replace')[-6000:],flush=True);raise SystemExit(code)
try:
 r['identity']=dict(host=env.get('COMPUTERNAME'),compiler=env.get('VCTOOLSVERSION'),cuda=subprocess.check_output(['nvcc','--version'],env=env,text=True).strip(),gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader'],env=env,text=True).strip())
 p=parent/'CMakeLists.txt';text=p.read_text(encoding='utf-8')
 if 'add_executable(g07_windows_packed ' not in text:
  text+='''
set_property(GLOBAL APPEND PROPERTY JOB_POOLS g07_cuda_compile=1)
set_target_properties(hyle_compute_provider_torch_cuda PROPERTIES JOB_POOL_COMPILE g07_cuda_compile CUDA_ARCHITECTURES 89-real)
target_compile_options(hyle_compute_provider_torch_cuda PRIVATE "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
add_executable(g07_windows_packed "@SOURCE@/tests/compute_provider_torch_cuda/packed_test.cc" "@SOURCE@/tests/compute_provider_torch_cuda/mlx_precision_test.cc" "@SOURCE@/tests/compute_provider_torch_cuda/failure_test.cc")
target_compile_features(g07_windows_packed PRIVATE cxx_std_23)
target_link_libraries(g07_windows_packed PRIVATE hyle_compute_route_cuda hyle_graph_route_cuda GTest::gtest_main torch torch_cpu c10 hyle_vendor_c10_cuda CUDA::cudart)
get_target_property(g07_leaf hyle_vendor_c10_cuda IMPORTED_LOCATION)
get_filename_component(g07_leaf_directory "${g07_leaf}" DIRECTORY)
target_include_directories(g07_windows_packed SYSTEM PRIVATE "${g07_leaf_directory}/../include")
if(TORCH_CXX_FLAGS)
 separate_arguments(g07_torch_flags NATIVE_COMMAND "${TORCH_CXX_FLAGS}")
 target_compile_options(g07_windows_packed PRIVATE ${g07_torch_flags})
endif()
hyle_stage_runtime(g07_windows_packed)
'''.replace('@SOURCE@',root.as_posix())
  p.write_text(text,encoding='utf-8')
 if 'find_package(CUDAToolkit 13.3 REQUIRED)' not in text:
  text=text.replace('set_property(GLOBAL APPEND PROPERTY JOB_POOLS g07_cuda_compile=1)','find_package(CUDAToolkit 13.3 REQUIRED)\nset_property(GLOBAL APPEND PROPERTY JOB_POOLS g07_cuda_compile=1)')
  p.write_text(text,encoding='utf-8')
 (out/'parent.cmake').write_text(text,encoding='utf-8')
 run('configure',['cmake','-S',str(parent),'-B',str(build)])
 run('manifest',['ninja','-C',str(build),'build.ninja'])
 preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
 dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n','g07_windows_packed'],env=env,text=True);(out/'dry-run.log').write_text(dry,encoding='utf-8')
 cuda=[x for x in dry.splitlines() if 'Building CUDA object' in x];r['cuda_edges']=cuda;r['build_edges']=len(dry.splitlines());save()
 assert len(cuda)<=1 and all('compute_provider_torch_cuda' in x for x in cuda),cuda[:8]
 assert 'Re-running CMake' not in dry
 run('build',['ninja','-C',str(build),'-f',str(preview),'-j','2','g07_windows_packed'])
 binary=build/'g07_windows_packed.exe';run('tests',[str(binary),'--gtest_output=xml:'+str(out/'tests.xml')])
 r['artifact']=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest());r['state']='WINDOWS_SOURCE_PASS';save();print(r['state'],flush=True)
except BaseException as e:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(e));save()
 raise
