from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();scratch=root/'.scratch/inference-gaps';dest=root/'evidence/correctness/inference-g07-packed-weight-source';dest.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
product=lambda p:p.startswith(('src/','include/','third_party/')) or p=='cmake/HyleDependencyLock.json'
manifest=json.loads((scratch/'g07-cuda-source-4/input-manifest.json').read_text(encoding='utf-8'))
inputs=[x for x in manifest['inputs'] if product(x['path'])]
assert all(sha((root/x['path']).read_bytes())==x['sha256'] for x in inputs),'Product changed after qualified source test'
normal=[('g07-cuda-source-4','SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING'),('g07-cuda-model-consumers-2','N2_FULL_SHAPE_DIRECT_GRAPH_PASS'),('g07-apple-source-5','SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING'),('g07-apple-source-6','SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING')]
risks=[('g07-cuda-device-risks-1','CUDA_DEVICE_RISKS_PASS'),('g07-apple-device-risks-1','APPLE_DEVICE_VALIDATION_PASS')]
risks += [(f'g07-{route}-host-{mode}-1','HOST_FACET_PASS') for route in ['cuda','apple'] for mode in ['asan','ubsan','tsan']]
runs=[]
for name,state in normal+risks:
 folder=scratch/name;record=json.loads((folder/'result.json').read_text(encoding='utf-8'));assert record['state']==state,(name,record['state'])
 tests=[]
 for p in sorted(folder.glob('*.xml')):
  xml=ET.parse(p).getroot();assert int(xml.get('failures','0'))==0 and int(xml.get('errors','0'))==0
  tests.append(dict(path=p.name,tests=int(xml.get('tests','0')),failures=0,errors=0,sha256=sha(p.read_bytes())))
 runs.append(dict(path=name,state=state,candidate=record.get('candidate'),stages=record['stages'],tests=tests))
metal=scratch/'g07-apple-device-risks-1/g07_packed_fp8.log'
assert 'Metal API Validation Enabled' in metal.read_text(encoding='utf-8') and 'Metal GPU Validation Enabled' in metal.read_text(encoding='utf-8')
for mode in ['memcheck','racecheck']:
 text=(scratch/'g07-cuda-device-risks-1'/(mode+'.log')).read_text(encoding='utf-8')
 assert 'ERROR SUMMARY: 0 errors' in text or 'RACECHECK SUMMARY: 0 hazards' in text
base='669121418669b31f6849c74f64362aaf8d6eb919'
w1_prefixes=['src/compute_provider_ggml/','src/compute_provider_ggml_cuda/','src/compute_provider_ggml_vulkan/','src/compute_ggml_runtime/','src/graph_route_cpu_cuda/','src/graph_route_cpu_apple/','src/graph_route_cpu_vulkan/']
paths=subprocess.check_output(['git','ls-files'],text=True).splitlines()
w1=[p for p in paths if any(p.startswith(prefix) for prefix in w1_prefixes)]
w1+=['src/compute_route_apple/apple_tensor.cc','src/compute_route_apple/apple_operations.cc','src/compute_route_apple/apple_context.cc','src/compute_route_vulkan/vulkan_mlx.cc','include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc','src/compute_ops/low_precision.cc']
bindings=[]
for name in w1:
 data=subprocess.check_output(['git','show',base+':'+name]);current=subprocess.check_output(['git','show',head+':'+name]);assert data==current,name
 bindings.append(dict(path=name,git_blob_sha256=sha(data)))
raw=dest/'raw.zip';assert not raw.exists()
folders=sorted({p for p in scratch.glob('g07-*') if p.is_dir() and (p/'result.json').exists() and json.loads((p/'result.json').read_text(encoding='utf-8')).get('state')!='RUNNING'})
archived=[]
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in folders:
  for p in sorted(folder.iterdir()):
   if p.is_file() and p.suffix in ['.json','.xml','.log','.cmake']:
    data=p.read_bytes();name=folder.name+'/'+p.name;z.writestr(name,data);archived.append(dict(path=name,sha256=sha(data)))
 for p in sorted(scratch.glob('g07_*.py'))+sorted(scratch.glob('g07_*.cmake')):
  data=p.read_bytes();name='runners/'+p.name;z.writestr(name,data);archived.append(dict(path=name,sha256=sha(data)))
 z.writestr('product-manifest.json',json.dumps(inputs,indent=2))
with zipfile.ZipFile(raw) as z:
 assert z.testzip() is None
 for item in archived:assert sha(z.read(item['path']))==item['sha256']
failures=[dict(path=p.name,state=json.loads((p/'result.json').read_text(encoding='utf-8'))['state']) for p in folders if p.name not in [x[0] for x in normal+risks]]
receipt=dict(state='PARTIAL_G07_SOURCE_AND_DEVICE_HOST_FACETS_PASS_DELIVERY_P1_PENDING',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 canonical_head=head,unchanged_product_from=manifest['candidate'],product_baseline=base,card='docs/implementation/tasks/compute/inference-g07-packed-weights.md',
 owners=['compute_provider_torch_cuda','compute_route_apple'],owner_state='AUDITED',runs=runs,
 normal_test_count=sum(t['tests'] for x in runs[:4] for t in x['tests']),
 current_product_inputs=len(inputs),product_manifest_sha256=sha(json.dumps(inputs,sort_keys=True).encode()),
 w1_reuse=dict(state='UNCHANGED_SOURCE_BINDINGS_SUPPORT_EXISTING_ROUTED_P0_QUALIFICATIONS',baseline=base,bindings=bindings,
  limits='No new 64-step/full-engine claim for every GGUF cross-product. Existing native/mixed-route evidence and original resource limits must be reconciled at final G07 closure; changed MLX/Apple paths have new ordinary/risk journeys above.'),
 retained_attempts=failures,retained_failure_notes=[
  'CUDA1: Windows path sorting produced a wrong vendored tree hash; CMake rejected it. Hash corrected using case-sensitive portable order.',
  'CUDA2/3: new fixture read uninitialized Torch allocator metadata, then reused a failed invocation. Fixtures corrected; original numerical thresholds unchanged.',
  'Apple2/3: private parent Ninja glob preview and private ggml include path setup failures; product shader/C++ not failing.',
  'Apple4: overbroad 759-test run explicitly stopped after relevant early cases; cost/log retained. Apple5 uses original finite affected filter.',
  'CUDA host ASan: build passed; test binary was in parent hyle/ folder. Same tree/record resumed without rebuild and prior failure retained.',
  'CUDA models1: private reduced test target omitted original vocabulary support TU; added original TU, retained two already-compiled model objects; models2 passed.',
  'Windows1: private parent lacked CUDAToolkit imported target scope. Same source/tree resumed as Windows2 with find_package; its verdict remains separate.'
 ],raw=dict(path='raw.zip',sha256=sha(raw.read_bytes()),bytes=raw.stat().st_size,entries=len(archived)),
 limits=['No P1, token/s or llama.cpp comparison is signed.','Original host facets do not certify native driver/private pools, LSan or original NVIDIA diagnostic-thread lifetime.','Windows source, relocated static/shared SDKs, final W1/route reconciliation, red-team and final gates remain pending.','G08-G10 remain unstarted; this is not G07 or goal completion.'])
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(state=receipt['state'],normal_tests=receipt['normal_test_count'],w1_sources=len(bindings),raw_bytes=raw.stat().st_size)))
