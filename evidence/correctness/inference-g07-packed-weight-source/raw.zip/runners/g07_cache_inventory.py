from pathlib import Path
import platform,json
root=Path('/root/hyle-scratch/compute-unified') if platform.system()=='Linux' else Path('/Users/kiro/hyle-scratch/compute-unified')
names=['l-cpu-cuda','l-cuda'] if platform.system()=='Linux' else ['a-cpu-apple']
for name in names:
    parent=root/name/'selected-graph/source-parent'
    build=root/name/'selected-graph/source-build'
    print('PARENT',str(parent)); print((parent/'CMakeLists.txt').read_text()[:1800])
    cache=(build/'CMakeCache.txt').read_text().splitlines()
    print('\n'.join(l for l in cache if any(x in l for x in ['HYLE_','CMAKE_CUDA_COMPILER:','CMAKE_CUDA_HOST_COMPILER:','CMAKE_CXX_COMPILER:','CMAKE_CUDA_ARCHITECTURES:','CMAKE_BUILD_TYPE:','CMAKE_HOME_DIRECTORY:','BUILD_SHARED_LIBS:','BUILD_TESTING:'])))
