from pathlib import Path
import hashlib,json,tarfile,time,urllib.request

root=Path.cwd();out=root/'.scratch/inference-gaps/g07-native-audit';out.mkdir(exist_ok=True)
source=json.loads((root/'third_party/mlx_cuda_quant/SOURCE.json').read_text(encoding='utf-8'))
archive=out/'mlx-2b2bb497.tar.gz';start=time.monotonic()
if not archive.exists():
    with urllib.request.urlopen(source['archive']['url'],timeout=30) as response:
        archive.write_bytes(response.read())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==source['archive']['sha256']
selected=[]
with tarfile.open(archive,'r:gz') as tar:
    for member in tar.getmembers():
        if not member.isfile():continue
        relative='/'.join(member.name.split('/')[1:])
        if not (relative.startswith('mlx/backend/cuda/quantized/') or relative in ['mlx/backend/cpu/quantized.cpp','mlx/backend/metal/kernels/quantized.h','mlx/backend/metal/kernels/fp_quantized.h','mlx/backend/metal/quantized.cpp','LICENSE']):continue
        path=out/'source'/relative;assert path.resolve().is_relative_to((out/'source').resolve())
        path.parent.mkdir(parents=True,exist_ok=True);data=tar.extractfile(member).read();path.write_bytes(data)
        selected.append(dict(path=relative,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
cpu=next(x for x in selected if x['path']=='mlx/backend/cpu/quantized.cpp')
assert cpu['sha256']=='8890160da0a884b559aad18ce20a2b08170b721c38ce1c800229ae9998ed846d'
r=dict(state='LOCKED_ARCHIVE_VERIFIED_READ_ONLY_AUDIT',revision=source['revision'],archive=str(archive),sha256=source['archive']['sha256'],selected=selected,seconds=time.monotonic()-start,source_checkout_changed=False)
(out/'mlx-source-identity.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
print(json.dumps(dict(state=r['state'],files=len(selected),seconds=r['seconds'],cuda_sources=[x['path'] for x in selected if '/cuda/' in x['path']][:26])))
