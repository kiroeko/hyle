from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');mode=sys.argv[1];assert mode in ['asan','ubsan','tsan']
source=base/'source-c8874688';parent=base/f'foundation-f5-native-host-apple-{mode}/parent';build=parent.parent/'build'
out=base/f'g07-apple-host-{mode}-1';out.mkdir(exist_ok=False);started=time.monotonic()
prior=json.loads((base/'g07-apple-source-5/result.json').read_text());assert prior['state']=='SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING'
assert f'HYLE_SANITIZER:STRING={mode}' in (build/'CMakeCache.txt').read_text()
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0')
r=dict(state='SETUP',mode=mode,pid=os.getpid(),candidate=prior['candidate'],identity=prior['identity'],build=str(build),max_jobs=4,stages=[],limits=['Host sanitizer facet only; original native shader/driver/private allocation and original G06 external callback/atomic model qualifications retained. Device validation has separate actual Metal evidence.'])
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
 stamp=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(mode,stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
try:
 p=parent/'CMakeLists.txt';text=p.read_text()
 if 'add_executable(g07_host_packed ' not in text:
  text+='\nadd_executable(g07_host_packed "'+str(source/'tests/compute_route_apple/fp8_tile_test.cc')+'")\n'
  text+='target_compile_features(g07_host_packed PRIVATE cxx_std_23)\ntarget_link_libraries(g07_host_packed PRIVATE hyle::compute GTest::gtest_main)\nhyle_apply_sanitizer(g07_host_packed)\nhyle_stage_runtime(g07_host_packed)\n'
  p.write_text(text)
 (out/'parent.cmake').write_text(text)
 run('configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build)])
 commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
 flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode];checked=[]
 for suffix in ['src/compute_route_apple/apple_mature_float.cc','tests/compute_route_apple/fp8_tile_test.cc']:
  rows=[x for x in commands if x['file'].endswith('/'+suffix)];assert len(rows)==1 and flag in rows[0]['command'];checked.extend(rows)
 (out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2))
 run('manifest',['/opt/homebrew/bin/ninja','-C',str(build),'build.ninja'])
 preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
 dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-n','g07_host_packed'],env=env,text=True);(out/'dry-run.log').write_text(dry)
 assert 'Re-running CMake' not in dry and 'Building CUDA object' not in dry
 r['build_edges']=len(dry.splitlines());save()
 run('build',['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-j','4','g07_host_packed'])
 binary=build/'g07_host_packed';run('tests',[str(binary),'--gtest_output=xml:'+str(out/'tests.xml')])
 r['artifact']=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest());r['state']='HOST_FACET_PASS';save();print(mode,r['state'],flush=True)
except BaseException as e:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(e));save()
 raise
