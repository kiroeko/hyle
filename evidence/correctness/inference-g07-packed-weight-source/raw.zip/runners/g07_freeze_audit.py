from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile

root=Path.cwd();dest=root/'evidence/architecture/inference-g07-packed-weight-audit';work=root/'.scratch/inference-gaps/g07-native-audit'
load=lambda p:json.loads((root/p).read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
identity=load('.scratch/inference-gaps/g07-native-audit/mlx-source-identity.json')
assert identity['state']=='LOCKED_ARCHIVE_VERIFIED_READ_ONLY_AUDIT'
sources=[]
for name in ['mlx/backend/cpu/quantized.cpp','mlx/backend/cuda/quantized/qmm/qmv.cu','mlx/backend/cuda/quantized/qmm/qmm_naive.cu','mlx/backend/cuda/quantized/qmm/qmm.cu','mlx/backend/metal/kernels/fp_quantized.h','LICENSE']:
 p=work/'source'/name;expected=next(x for x in identity['selected'] if x['path']==name);assert sha(p)==expected['sha256'];sources.append(dict(path=name,sha256=sha(p),url='https://raw.githubusercontent.com/ml-explore/mlx/'+identity['revision']+'/'+name))
intake=load('evidence/architecture/inference-g07-packed-weight-intake/receipt.json');peer=[]
for x in intake['fixed_peers']:
 data=subprocess.check_output(['git','-C',str(root.parent/x['name']),'show',x['commit']+':'+x['path']]);assert hashlib.sha256(data).hexdigest()==x['file_sha256'];peer.append(x)
raw=dest/'audit-sources.zip';assert not raw.exists()
manifest=[]
with zipfile.ZipFile(raw,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for x in sources:
  p=work/'source'/x['path'];z.write(p,x['path']);manifest.append(dict(path=x['path'],sha256=sha(p)))
 z.write(work/'mlx-source-identity.json','mlx-source-identity.json')
with zipfile.ZipFile(raw) as z:
 assert z.testzip() is None
 for x in manifest:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
r=dict(state='AUDITED_FINITE_FIX_FROZEN_NOT_RUNTIME_ACCEPTANCE',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 baseline=head,product_baseline='669121418669b31f6849c74f64362aaf8d6eb919',card='docs/implementation/tasks/compute/inference-g07-packed-weights.md',
 owners=['compute_provider_torch_cuda','compute_route_apple'],fixes=['W-CUDA','W-CHECK','W-APPLE','W-QUAL'],
 public_api='Existing signatures and physical encodings unchanged; only provider runtime/cost and usage documentation corrected. No compatibility layer, address cache, loader or scheduler.',
 sources=sources,fixed_peer_source_hashes_verified=peer,
 source_verdicts={'W1':'Existing native carriers KEEP/BORROW, actual finite repeated/lifetime qualification in W-QUAL remains required.',
 'W2_CUDA':'Port original packed row/warp structure with original widened F32 affine and per-group MX scaling, retaining all original typed domains; no new universal GEMM or narrower-decoder substitution.',
 'W3_CUDA':'Existing exported acquire_device_status(Queue&) and completion protocol are available. Separate all-IDs check precedes native math; nonzero status prevents invalid payload reads and output writes.',
 'W2_Apple':'Program constants pass as MLX compiled region arguments. Existing block_dot decodes full unscaled weights/dots in the compiled execution graph; replace only FP8 block128 path with original SIMDgroup F32 matrix tiles and ordered scales. FP4 path retained.',
 'native_Apple_API':'Actual Air SDK fast.h provides metal_kernel with CompileOptions; actual machine Mac16,12/arm64/macOS27.0.1. No new Metal runtime/vendor patch planned.',
 'precision':'No implicit AWQ integer-zero conversion; no FP16 dequant/partial narrowing; original current mathematical error gates retained.'},
 validation={'ordinary_targets':['hyle_compute_provider_torch_cuda_test','affected MLX/model cases in hyle_compute_route_cuda_test and hyle_graph_route_cuda_test','hyle_compute_route_apple_test and affected native/Graph/CPU+Apple consumers'],
 'risk':'Affected CUDA memcheck/racecheck, actual Metal shader validation, scoped ASan/UBSan/TSan facets, OOM/prefix/old output/close; preserve driver/private limitations.',
 'delivery':'Affected source/relocated static/shared/owned public headers; reuse unchanged lower/vendor inputs, no full rebuild.',
 'numeric':'All original F16/BF16/F32 and mixed affine, noninteger bias, E8M0 limits, FP8 codes, multiple groups, TF32 policy, edge tiles and checked IDs; original tolerances.',
 'lifecycle':'At least64 steps, changed weight/IDs, two slots, old output, accepted failure and real retirement; W1 finite four-native/three-joint qualifications retained.',
 'p1':'Only after ordinary gates and immutable candidate. Two fixed workloads/route, old669 same-contract whole-completion baseline, route-local AA/orders,5% original instrument/n15 or n31. No product/P1 PASS now.'},
 costs={'archive_fetch':'Python urllib SSL EOF retained; curl fetched the same4.29MiB locked archive successfully, exact486e8b... SHA verified. No checkout or dependency revision changed.',
 'investigation':'Source preparation and reading not separately stopwatched; UNKNOWN, original intake budget/cost retained.', 'new_builds':0,'new_runtime_tests':0,'new_p1':0},
 raw={'path':raw.relative_to(root).as_posix(),'sha256':sha(raw),'entries_sha256_verified':True},
 limits=['Implementation and all new runtime gates still unrun.', 'This freeze does not sign all-format/native performance or engine token/s.', 'Systematic scope/API/owner changes require return to audit.'])
(dest/'audit.json').write_bytes((json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
p=root/'docs/implementation/module-status.json';rawtext=p.read_bytes();j=json.loads(rawtext.decode('utf-8'))
for m in j['modules']:
 if m['module'] in r['owners']:
  assert m['state']=='SCOPED';m['state']='AUDITED';m['summary']='G07 AUDITED W-CUDA/W-CHECK/W-APPLE/W-QUAL finite FIX frozen: native packed F32 CUDA equations/device checked status, Apple FP8 tile-local F32 math with original scale order,64-step/lifetime/route qualification. Existing public shapes/encodings and other closed scopes unchanged; no new runtime/P1 verdict yet.'
s=json.dumps(j,ensure_ascii=False,indent=2)+'\n';p.write_bytes(s.replace('\n','\r\n').encode('utf-8') if b'\r\n' in rawtext else s.encode('utf-8'))
print(json.dumps(dict(state=r['state'],baseline=head,owners=r['owners'],verified_peer_sources=len(peer),raw_bytes=raw.stat().st_size)))
