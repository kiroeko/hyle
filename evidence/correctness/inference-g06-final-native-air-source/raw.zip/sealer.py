from pathlib import Path
import datetime,hashlib,json,shlex,subprocess,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';folder=base/'final-native-air-1';out=root/'evidence/correctness/inference-g06-final-native-air-source'
assert not out.exists();r=json.loads((folder/'result.json').read_text());assert r['state']=='TERMINAL_PASS'
assert r['identity']['model']=='Mac16,12' and r['identity']['arch']=='arm64'
assert all(s['exit_code']==0 for s in r['stages'])
for route in ['apple','vulkan']:
 log=(folder/(route+'-g06_native_ragged.log')).read_text();assert '[  FAILED  ]' not in log and '[  PASSED  ]' in log
 assert not ('[  SKIPPED ]' in log or 'DISABLED_' in log)
manifest=json.loads((folder/'input-manifest.json').read_text())
assert all(hashlib.sha256((root/i['path']).read_bytes()).hexdigest()==i['sha256'] for i in manifest['inputs'])
remote='/Users/kiro/hyle-scratch/compute-unified/g06-final-native-1/artifacts.json'
check="from pathlib import Path;import hashlib,json;rows=json.loads(Path("+repr(remote)+").read_text());assert all(hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()==i['sha256'] for i in rows);print(len(rows),sum(i['bytes'] for i in rows))"
verified=subprocess.check_output(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -c '+shlex.quote(check)],text=True).strip()
out.mkdir(parents=True)
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(folder.iterdir()):
  if p.is_file():z.write(p,p.name)
 z.write(base/'final_native_air.py','runner.py');z.write(base/'launch_final_native_air.py','launcher.py');z.write(Path(__file__),'sealer.py')
receipt={'state':'PASS_FINITE_APPLE_VULKAN_SOURCE_AND_RECORDER_RISKS_ONLY','product_candidate':'0a29d119426b2975d48c238c37a2994675e0ba9f','source_snapshot':r['candidate'],
 'record':'docs/implementation/tasks/compute/inference-g06-metadata-decode.md','identity':r['identity'],'input_count':len(manifest['inputs']),
 'source_manifest_scope':'Canonical tracked product/CMake/test inputs, one-way Windows->disposable Air validation source; no reverse product copy.',
 'stages':r['stages'],'outer_elapsed_seconds':r['outer_elapsed_seconds'],'artifact_recheck_count_bytes':verified,
 'qualification':['Actual MacBook Air Mac16,12/arm64. Apple and Vulkan original Direct,CPU+GPU,encoded/plain,pending,source errors,late results,abandon,multi-native-source all pass; Vulkan original provider/alias-phase controls also pass.',
 'Final native ragged original tests include Apple48/Vulkan24 runtime configurations each64 updates and original cold/native old-output cases. Unchanged mathematical domains and negative space preserved.',
 'Vulkan original ragged Program now additionally exercised through Recorder cold-copy, caller Program destruction before submit, head64/128/256 and two real replays each with independent numerical oracle; passed in original packed-layout test.',
 'Final core/Graph CXX bridges and BatchPlanning version2 consumed by actual routes; runtime capture qualification remains FI-only, Apple managed/Vulkan re-record costs not called capture.'],
 'limits':['Source qualification only, not relocated SDK/header/sanitizer/P1 or G06 acceptance','Apple managed construction, Vulkan re-encoding, native private/driver costs UNKNOWN; no all-mode native symmetry claim','Original G04/G05 performance unresolved and complete G01-G10 scope remain'],
 'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'state':receipt['state'],'artifacts':verified,'stages':len(r['stages'])},ensure_ascii=False))
