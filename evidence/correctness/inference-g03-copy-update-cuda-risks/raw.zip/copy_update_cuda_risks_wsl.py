from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
canonical=Path('/mnt/c/public/project-hyle/hyle')
base=Path('/root/hyle-scratch/compute-unified')
source=base/'source-7a7b4c3b'
build=base/'l-cpu-cuda/selected-graph/source-build'
parent=base/'l-cpu-cuda/selected-graph/source-parent/CMakeLists.txt'
out=canonical/'.scratch/inference-gaps/g03/copy-update-cuda-risks';out.mkdir(exist_ok=True)
assert source.is_dir() and not (source/'.git').exists() and build.is_dir()
names=['include/hyle/compute/batch_transfer.h','include/hyle/compute/detail/copy_stream_access.h',
       'src/compute/batch_transfer.cc','tests/compute_batch/copy_update_cuda_risks.cc']
manifest=[];changed=[]
for name in names:
 data=(canonical/name).read_bytes();dest=source/name
 manifest.append({'path':name,'sha256':hashlib.sha256(data).hexdigest()})
 if not dest.exists() or dest.read_bytes()!=data:
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
(out/'inputs.json').write_text(json.dumps({'baseline':'5eda0cc0f','candidate':'AUDITED WORKTREE','one_way':True,'inputs':manifest,'changed':changed},indent=2)+'\n')
for route in ['cuda']:
 target='g03_copy_update_risks_'+route
 body=parent.read_bytes()
 if ('add_executable('+target+' ').encode() not in body:
  addition=f'\nadd_executable({target} "{source}/tests/compute_batch/copy_update_cuda_risks.cc")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle_compute hyle_compute_backend_{route})\n'
  if route=='cuda':addition+=f'target_compile_definitions({target} PRIVATE HYLE_COPY_UPDATE_CUDA=1)\n'
  addition+=f'hyle_stage_runtime({target})\n'
  parent.write_bytes(body+addition.encode())
# Validation-only: enable the existing observation hooks in the one original
# host translation unit, not globally and not in any CUDA kernel or SDK tree.
body=parent.read_bytes()
marker='# G03 original event observation hooks, host TU only'
if marker.encode() not in body:
 body+=f'\n{marker}\nset_source_files_properties("{source}/src/compute_backend_cuda/cuda_backend.cc" DIRECTORY "{source}/src/compute_backend_cuda" PROPERTIES COMPILE_DEFINITIONS HYLE_TESTING=1)\n'.encode()
 parent.write_bytes(body)
record=out/'result.json';previous=json.loads(record.read_bytes()) if record.exists() else {};rows=previous.get('stages',[])
digest=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
identity={'uname':subprocess.check_output(['uname','-a'],text=True).strip(),
 'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.used,utilization.gpu','--format=csv,noheader'],text=True).strip(),
 'compiler':subprocess.check_output(['/usr/bin/g++-14','--version'],text=True).splitlines()[0]}
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
for route in ['cuda']:
 target='g03_copy_update_risks_'+route
 for stage,args in [('build',['cmake','--build',str(build),'--target',target,'--parallel','4']),('public-source',[str(build/target)])]:
  attempt=1+sum(r['stage']==stage and r['route']==route for r in rows);log=out/f'{route}-{stage}-{attempt}.log';start=time.monotonic()
  with log.open('w') as stream:
   process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
   (out/'job.json').write_text(json.dumps({'state':'RUNNING','route':route,'stage':stage,'pid':process.pid,'log':str(log)}))
   print('RUN',route,stage,'PID',process.pid,flush=True);code=process.wait()
  rows.append({'stage':stage,'route':route,'command':args,'input_manifest_sha256':digest,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)})
  record.write_text(json.dumps({'candidate':'AUDITED WORKTREE','identity':identity,'inputs':manifest,'stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n')
  log_text=log.read_text(errors='replace')
  assert 'device_status_kernel.cu.o' not in log_text and 'nvcc -' not in log_text, 'unexpected CUDA kernel rebuild'
  print(log_text[-6500:],flush=True)
  if code:
   (out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code}));raise SystemExit(code)
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
checked=[c for c in commands if c['file'].endswith('src/compute_backend_cuda/cuda_backend.cc')]
assert checked and all('-DHYLE_TESTING=1' in c['command'] for c in checked)
(out/'observation-hook-host-tu.json').write_text(json.dumps(checked,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in out.iterdir():
  if f.is_file() and f.suffix in ['.json','.log']:z.write(f,f.name)
 z.write(__file__,'copy_update_cuda_risks_wsl.py')
(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':0}))
