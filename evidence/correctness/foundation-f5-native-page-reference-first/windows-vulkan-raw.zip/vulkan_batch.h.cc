#include <hyle/compute/vulkan_batch.h>
