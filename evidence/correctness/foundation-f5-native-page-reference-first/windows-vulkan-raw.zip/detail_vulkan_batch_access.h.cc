#include <hyle/compute/detail/vulkan_batch_access.h>
