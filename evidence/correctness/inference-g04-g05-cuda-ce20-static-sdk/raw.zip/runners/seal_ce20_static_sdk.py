from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';sdk=base/'sdk';tag='cuda-static-ce19-resume-1';r=json.loads((sdk/('result-'+tag+'.json')).read_text());assert r['state']=='TERMINAL_PASS'
tests={}
for name in ('cpu_math','native_math','cpu','native'):
 x=ET.parse(sdk/(name+'-'+tag+'.xml')).getroot();assert x.attrib['failures']==x.attrib['errors']=='0'
 assert not any(c.find('skipped') is not None or c.attrib.get('status')=='notrun' for c in x.findall('.//testcase'))
 tests[name]=int(x.attrib['tests'])
dest=root/'evidence/correctness/inference-g04-g05-cuda-ce20-static-sdk';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(sdk.iterdir()):
  if p.is_file() and ('cuda-static-ce19-1' in p.name or tag in p.name) and p.suffix!='.zip':z.write(p,'sdk/'+p.name)
 for p in sorted((base/'ce20-static-native-reuse-1').iterdir()):
  if p.is_file():z.write(p,'native-reuse/'+p.name)
 for name in ('ce20_resume_static_sdk.py','ce19_cuda_compile.cmake','ce20_static_native_reuse_wsl.py','seal_ce20_static_sdk.py'):z.write(base/name,'runners/'+name)
 with zipfile.ZipFile(sdk/('source-'+tag+'.zip')) as source:z.writestr('source-manifest.json',source.read('source-manifest.json'))
receipt=dict(kind='G04_G05_CUDA_CE20_RELOCATED_STATIC_SDK',verdict='PASS_STATIC_SDK_HOST_P1_PENDING',product_candidate='274cd9fec7cecb2e683cf5f0f87d6e0fd6b3ab55',
 tests=tests,independent_public_headers=12,consumer_compile_commands=16,stages=r['stages'],
 original_setup_guard=dict(exit_code=1,stage='producer-plan scope guard',product_build_started=False,prior_result_sha256=hashlib.sha256((sdk/'result-cuda-static-ce19-1.json').read_bytes()).hexdigest(),
 successful_stages=json.loads((sdk/'result-cuda-static-ce19-1.json').read_text())['stages']),
 native_reuse=r['native_cuda_reuse'],prefix=r['prefix'],identity=r['identity'],
 limits=['Actual relocated Linux static C++ consumers, no repository headers; private snapshot reuses exactly146 shipping native objects through verified byte-equivalent source paths.',
 'Original producer guard failure is retained, source archive identical on resume, configured identity stable; dynamic GPU usage telemetry is recorded rather than treated as compiler identity.',
 'Source17 and GPU device checks are separate final receipts; three host facets/newP1/whole G04-G05 not signed.'],
 raw_zip_sha256=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(dest),tests=tests,seconds=r['cumulative_seconds'])))
