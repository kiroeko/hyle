from pathlib import Path
import ctypes,hashlib,json,os,shutil,subprocess,time,zipfile

ctypes.windll.kernel32.SetErrorMode(0x8003)
root=Path('C:/hyle-scratch/r6-vulkan-20260917').resolve()
source=Path('C:/public/project-hyle/hyle').resolve()
logs=root/'windows-delivery-60de4212'
logs.mkdir(exist_ok=False)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert commit.startswith('60de4212')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
env=os.environ.copy(); env['CMAKE_BUILD_PARALLEL_LEVEL']='2'; env['CTEST_PARALLEL_LEVEL']='1'
records=[]
def run(label,args,timeout=600):
    print(label,flush=True); start=time.time()
    with (logs/(label+'.log')).open('w') as f:
        p=subprocess.run([str(x) for x in args],cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    records.append({'label':label,'command':[str(x) for x in args],'exit_code':p.returncode,'seconds':time.time()-start})
    print(label,'exit',p.returncode,flush=True)
    if p.returncode: print((logs/(label+'.log')).read_text()[-6000:],flush=True)
    p.check_returncode()
def relocate(old,new):
    assert old.resolve().is_relative_to(root) and new.resolve().is_relative_to(root)
    assert old.is_dir() and not new.exists()
    old.rename(new)
def config(build,tree,static,install=True):
    run(build.name+'-configure',['cmake','-S',tree,'-B',build,'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPONENTS=compute;graph',
        '-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF',
        '-DHYLE_COMPUTE_ONEDNN=OFF','-DHYLE_COMPUTE_VULKAN=ON',
        '-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON',
        '-DHYLE_STATIC='+('ON' if static else 'OFF'),'-DHYLE_INSTALL='+('ON' if install else 'OFF'),
        '-DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe',
        '-DHYLE_DEP_SOURCE_CACHE=C:/public/project-hyle/.deps','-DFETCHCONTENT_FULLY_DISCONNECTED=ON',
        '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=C:/hyle-scratch/r6-vulkan-20260917/locked-sources/vulkan_headers/Vulkan-Headers-e3b1eec08173d6b825cd3ac88c885a63b621504a'])
consumer_source=root/'independent-consumer-sources'
for product in ('compute','graph'):
    shutil.copytree(source/'samples/package'/product/'cpp',consumer_source/product/'cpp')

def consume(prefix,linkage):
    assert (prefix/'include/vulkan/vulkan_core.h').is_file()
    licenses=prefix/'share/licenses/Hyle'
    for name in ('ggml-vulkan-shaders-LICENSE','ggml-vulkan-shaders-NOTICE.md',
                 'vulkan-headers-LICENSE.md','vulkan-headers-Apache-2.0.txt','vulkan-headers-MIT.txt'):
        assert (licenses/name).is_file(),name
    forbidden=('onednn','libmlx','cublas','marlin','compute_backend_cpu','compute_backend_cuda','compute_route_apple')
    artifacts=[p.name for p in prefix.rglob('*') if p.suffix.lower() in ('.lib','.dll','.a','.so','.dylib')]
    assert not any(word in name.lower() for name in artifacts for word in forbidden),artifacts
    for product in ('compute','graph'):
        build=root/f'relocated-{linkage}-{product}'
        run(build.name+'-configure',['cmake','-S',consumer_source/product/'cpp','-B',build,'-G','Ninja',
            '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix)])
        run(build.name+'-build',['cmake','--build',build,'--parallel','2'])
        if linkage=='shared':
            assert (build/'hyle_compute_route_vulkan.dll').is_file(),list(build.glob('*.dll'))
        run(build.name+'-test',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','--timeout','120'])

identity={'commit':commit,'state':'RUNNING','records':records}
try:
    static=root/'relocated-sdk-static'
    relocate(root/'sdk-static',static)
    consume(static,'static')
    build=root/'public-shared'; config(build,source,False)
    run('shared-build',['cmake','--build',build,'--parallel','2'])
    original=root/'sdk-shared'
    run('shared-install',['cmake','--install',build,'--prefix',original])
    prefix=root/'relocated-sdk-shared'; relocate(original,prefix)
    consume(prefix,'shared')
    run('complete-source-package',['cmake','--build',root/'public-static','--target','hyle_source_package','--parallel','2'])
    archives=list((root/'public-static/dist').glob('*-source.zip')); assert len(archives)==1
    archive=archives[0]; digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    assert archive.with_suffix('.zip.sha256').read_text().split()[0]==digest
    extracted=root/'complete-source-60de4212'; assert not extracted.exists()
    with zipfile.ZipFile(archive) as z:
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
        z.extractall(extracted)
    sources=list(extracted.glob('hyle-*-source')); assert len(sources)==1
    tree=sources[0]; assert commit in (tree/'SOURCE-MANIFEST.txt').read_text()
    parent=root/'source-consumer-60de4212'; parent.mkdir()
    parent.joinpath('CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(vulkan_source_consumer LANGUAGES CXX)
add_subdirectory("'''+tree.as_posix()+'''" hyle)
enable_testing()
foreach(product IN ITEMS compute graph)
  add_executable(vulkan_source_${product} "'''+tree.as_posix()+'''/samples/package/${product}/cpp/main.cc")
  target_compile_features(vulkan_source_${product} PRIVATE cxx_std_23)
  target_link_libraries(vulkan_source_${product} PRIVATE hyle::${product})
  hyle_stage_runtime_dependencies(vulkan_source_${product})
  add_test(NAME vulkan_source_${product} COMMAND vulkan_source_${product})
endforeach()
''')
    source_build=root/'source-build-60de4212'; config(source_build,parent,True,False)
    run('source-build',['cmake','--build',source_build,'--parallel','2'])
    run('source-test',['ctest','--test-dir',source_build,'--output-on-failure','--no-tests=error','--timeout','120'])
    identity.update(state='PASS',source_archive=str(archive),source_archive_sha256=digest)
except Exception as error:
    identity.update(state='FAIL',error=str(error)); raise
finally:
    (logs/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
