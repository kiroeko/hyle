$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$r6Root = 'C:/hyle-scratch/r6-vulkan-20260917'
$r6Build = "$r6Root/public-static"
$r6Sdk = "$r6Root/sdk-static"
$r6Logs = "$r6Root/public-static-logs"
New-Item -ItemType Directory -Path $r6Logs -ErrorAction Stop | Out-Null
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_PARALLEL_LEVEL = '1'
& cmake -S C:/public/project-hyle/hyle -B $r6Build -G Ninja `
  '-DCMAKE_BUILD_TYPE=Release' '-DHYLE_COMPONENTS=compute;graph' `
  '-DHYLE_COMPUTE_VULKAN=ON' '-DHYLE_COMPUTE_CPU=OFF' '-DHYLE_COMPUTE_CUDA=OFF' `
  '-DHYLE_COMPUTE_APPLE=OFF' '-DHYLE_COMPUTE_ONEDNN=OFF' `
  '-DHYLE_BUILD_TESTS=OFF' '-DHYLE_BUILD_BENCH=OFF' '-DHYLE_STATIC=ON' '-DHYLE_INSTALL=ON' '-DHYLE_WERROR=ON' `
  '-DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe' `
  '-DHYLE_DEP_SOURCE_CACHE=C:/public/project-hyle/.deps' `
  '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=C:/hyle-scratch/r6-vulkan-20260917/locked-sources/vulkan_headers/Vulkan-Headers-e3b1eec08173d6b825cd3ac88c885a63b621504a' *> "$r6Logs/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/configure.log" -Tail 80; exit $LASTEXITCODE }
& cmake --build $r6Build --parallel 2 *> "$r6Logs/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/build.log" -Tail 80; exit $LASTEXITCODE }
& cmake --install $r6Build --prefix $r6Sdk *> "$r6Logs/install.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/install.log" -Tail 80; exit $LASTEXITCODE }
foreach ($r6Product in @('compute', 'graph')) {
  $r6Consumer = "$r6Root/consumer-static-$r6Product"
  & cmake -S "C:/public/project-hyle/hyle/samples/package/$r6Product/cpp" -B $r6Consumer -G Ninja `
    '-DCMAKE_BUILD_TYPE=Release' "-DCMAKE_PREFIX_PATH=$r6Sdk" *> "$r6Logs/$r6Product-configure.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/$r6Product-configure.log" -Tail 80; exit $LASTEXITCODE }
  & cmake --build $r6Consumer --parallel 2 *> "$r6Logs/$r6Product-build.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/$r6Product-build.log" -Tail 80; exit $LASTEXITCODE }
  & ctest --test-dir $r6Consumer --output-on-failure --no-tests=error *> "$r6Logs/$r6Product-test.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$r6Logs/$r6Product-test.log" -Tail 80; exit $LASTEXITCODE }
  Get-Content "$r6Logs/$r6Product-test.log"
}
Write-Output 'PASS Windows public installed static Direct/Graph FFN + custom SPIR-V; relocation/source/shared still pending.'
