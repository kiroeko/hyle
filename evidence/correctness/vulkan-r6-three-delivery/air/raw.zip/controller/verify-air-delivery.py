from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time
import zipfile


root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917').resolve()
commit = '60de42121b1361cc9fadecc33806404ddc84a2df'
archive = root / 'hyle-0.1.0-source-60de4212.zip'
digest = '2114f5381ec4f1450bb173f2a9dcea8db18b0bb6e513c375570f873e860456b2'
logs = root / 'air-delivery-60de4212'
logs.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(PATH='/opt/homebrew/bin:' + env['PATH'],
           CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1',
           MACOSX_DEPLOYMENT_TARGET='14.4',
           DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib',
           VK_LOADER_LAYERS_DISABLE='~implicit~')
records = []
identity = {'commit': commit, 'state': 'RUNNING', 'records': records,
            'source_archive_sha256': digest,
            'environment': {k: env[k] for k in (
                'PATH', 'MACOSX_DEPLOYMENT_TARGET', 'DYLD_LIBRARY_PATH',
                'VK_LOADER_LAYERS_DISABLE', 'CMAKE_BUILD_PARALLEL_LEVEL',
                'CTEST_PARALLEL_LEVEL')}}


def save():
    (logs / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')


def run(label, args, timeout=600):
    print(label, flush=True)
    args = [str(x) for x in args]
    start = time.time()
    with (logs / (label + '.log')).open('w') as stream:
        result = subprocess.run(args, cwd=root, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=timeout)
    records.append({'label': label, 'command': args, 'exit_code': result.returncode,
                    'seconds': time.time() - start})
    save()
    print(label, 'exit', result.returncode, flush=True)
    if result.returncode:
        print((logs / (label + '.log')).read_text()[-6000:], flush=True)
    result.check_returncode()


def relocate(old, new):
    assert root in old.resolve().parents and root in new.resolve().parents
    assert old.is_dir() and not new.exists(), (old, new)
    old.rename(new)


def configure(build, source, static, install=True):
    run(build.name + '-configure', [
        'cmake', '-S', source, '-B', build, '-G', 'Ninja',
        '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
        '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4', '-DHYLE_COMPONENTS=compute;graph',
        '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF',
        '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_COMPUTE_ONEDNN=OFF',
        '-DHYLE_COMPUTE_VULKAN=ON', '-DHYLE_BUILD_TESTS=OFF',
        '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_WERROR=ON',
        '-DHYLE_STATIC=' + ('ON' if static else 'OFF'),
        '-DHYLE_INSTALL=' + ('ON' if install else 'OFF'),
        '-DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator',
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON',
        '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=' + str(headers)])


def consume(prefix, linkage):
    assert (prefix / 'include/vulkan/vulkan_core.h').is_file()
    license_root = prefix / 'share/licenses/Hyle'
    for name in ('ggml-vulkan-shaders-LICENSE', 'ggml-vulkan-shaders-NOTICE.md',
                 'vulkan-headers-LICENSE.md', 'vulkan-headers-Apache-2.0.txt',
                 'vulkan-headers-MIT.txt'):
        assert (license_root / name).is_file(), name
    artifacts = [p.name for p in prefix.rglob('*')
                 if p.suffix.lower() in ('.lib', '.dll', '.a', '.so', '.dylib')]
    forbidden = ('onednn', 'libmlx', 'cublas', 'marlin', 'compute_backend_cpu',
                 'compute_backend_cuda', 'compute_route_apple')
    assert not any(word in name.lower() for name in artifacts for word in forbidden)
    (logs / (linkage + '-artifacts.json')).write_text(json.dumps(artifacts, indent=2) + '\n')
    for product in ('compute', 'graph'):
        build = root / ('delivery-' + linkage + '-' + product + '-60de4212')
        run(build.name + '-configure', [
            'cmake', '-S', consumers / product / 'cpp', '-B', build, '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
            '-DCMAKE_PREFIX_PATH=' + str(prefix)])
        run(build.name + '-build', ['cmake', '--build', build, '--parallel', '2'])
        run(build.name + '-test', [
            'ctest', '--test-dir', build, '--output-on-failure', '--no-tests=error',
            '--timeout', '120'])
        shutil.copyfile(build / 'Testing/Temporary/LastTest.log',
                        logs / (build.name + '-LastTest.log'))
        executable = build / ('hyle_package_' + product + '_cpp')
        run(build.name + '-linkage', ['/usr/bin/otool', '-L', executable])
        identity.setdefault('executables', {})[build.name] = hashlib.sha256(
            executable.read_bytes()).hexdigest()


try:
    save()
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == digest
    extracted = root / 'complete-source-60de4212'
    assert not extracted.exists()
    with zipfile.ZipFile(archive) as packed:
        assert all(not Path(name).is_absolute() and '..' not in Path(name).parts
                   for name in packed.namelist())
        packed.extractall(extracted)
    trees = list(extracted.glob('hyle-*-source'))
    assert len(trees) == 1
    tree = trees[0]
    assert commit in (tree / 'SOURCE-MANIFEST.txt').read_text()
    headers = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/'
                   'vulkan_headers-e3b1eec08173-69d6adc9001f')
    assert (headers / 'include/vulkan/vulkan_core.h').is_file()
    consumers = root / 'independent-consumers-60de4212'
    for product in ('compute', 'graph'):
        shutil.copytree(tree / 'samples/package' / product / 'cpp',
                        consumers / product / 'cpp')
    parent = root / 'source-consumer-60de4212'
    parent.mkdir()
    (parent / 'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(vulkan_source_consumer LANGUAGES CXX)
add_subdirectory("''' + tree.as_posix() + '''" hyle)
enable_testing()
foreach(product IN ITEMS compute graph)
  add_executable(vulkan_source_${product} "''' + tree.as_posix() + '''/samples/package/${product}/cpp/main.cc")
  target_compile_features(vulkan_source_${product} PRIVATE cxx_std_23)
  target_link_libraries(vulkan_source_${product} PRIVATE hyle::${product})
  hyle_stage_runtime_dependencies(vulkan_source_${product})
  add_test(NAME vulkan_source_${product} COMMAND vulkan_source_${product})
endforeach()
''')
    source_build = root / 'source-build-60de4212'
    configure(source_build, parent, True, False)
    run('source-build', ['cmake', '--build', source_build, '--parallel', '2'])
    run('source-test', ['ctest', '--test-dir', source_build, '--output-on-failure',
                        '--no-tests=error', '--timeout', '120'])
    shutil.copyfile(source_build / 'Testing/Temporary/LastTest.log', logs / 'source-LastTest.log')
    prefixes = {}
    producer_builds = [source_build]
    for linkage in ('static', 'shared'):
        build = root / ('public-' + linkage + '-60de4212')
        configure(build, tree, linkage == 'static')
        run(linkage + '-build', ['cmake', '--build', build, '--parallel', '2'])
        prefix = root / ('sdk-' + linkage + '-60de4212')
        run(linkage + '-install', ['cmake', '--install', build, '--prefix', prefix])
        relocated = root / ('relocated-sdk-' + linkage + '-60de4212')
        relocate(prefix, relocated)
        prefixes[linkage] = relocated
        producer_builds.append(build)
    for build in producer_builds:
        shutil.copyfile(build / 'CMakeCache.txt', logs / (build.name + '-CMakeCache.txt'))
        shutil.copyfile(build / 'compile_commands.json', logs / (build.name + '-compile_commands.json'))
        relocate(build, build.with_name(build.name + '-hidden'))
    relocate(extracted, extracted.with_name(extracted.name + '-hidden'))
    identity['producer_paths_hidden_before_sdk_consumption'] = True
    for linkage, prefix in prefixes.items():
        consume(prefix, linkage)
    identity['state'] = 'PASS'
except Exception as error:
    identity.update(state='FAIL', error=str(error))
    raise
finally:
    identity['finished'] = time.time()
    save()
