from pathlib import Path
import hashlib,json,os,subprocess,time
BASE=Path('/Users/kiro/hyle-scratch/compute-unified')
OUT=BASE/'g04-g05-metal-nil-probe';OUT.mkdir(exist_ok=True)
HEADER=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/metal_cpp-f567ed836e4c-3874e9e28e8e')
assert not (OUT/'result.json').exists()
result={'scope':'Independent original metal-cpp nullptr member bridge versus actual Objective-C nil messaging; no HYLE or MLX','stages':[],'inputs':[
    {'path':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()} for file in [OUT/'metal_nil_probe.cc',HEADER/'Foundation/NSSharedPtr.hpp',HEADER/'Foundation/NSObject.hpp']],
    'cumulative_seconds':0}
env=os.environ.copy();env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
commands=[('compile',['xcrun','clang++','-std=c++20','-O3','-g','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(HEADER),str(OUT/'metal_nil_probe.cc'),'-framework','Foundation','-framework','Metal','-lobjc','-o',str(OUT/'probe')]),
          ('original-cpp',[str(OUT/'probe')]),('objc-nil',[str(OUT/'probe'),'objc'])]
for stage,command in commands:
    start=time.monotonic();log=OUT/f'{stage}.log'
    with log.open('w') as stream:code=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env).returncode
    elapsed=time.monotonic()-start;result['cumulative_seconds']+=elapsed
    result['stages'].append(dict(stage=stage,command=command,exit_code=code,elapsed_seconds=elapsed,log=str(log)))
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(stage,code,round(elapsed,3),flush=True)
    if stage=='compile' and code:raise SystemExit(code)
