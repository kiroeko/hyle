from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
path=ROOT/'cmake/HyleDependencyLock.json';text=path.read_text(encoding='utf-8')
lock=json.loads(text);entry=next(x for x in lock['dependencies'] if x['name']=='mlx_cast_patches')
bundle=ROOT/entry['vendored']['path']
listing=''.join(f'{f.relative_to(bundle).as_posix()}|{hashlib.sha256(f.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n'
                for f in sorted((p for p in bundle.rglob('*') if p.is_file()),key=lambda p:p.relative_to(bundle).as_posix()))
entry['vendored']['tree_sha256']=hashlib.sha256(listing.encode()).hexdigest()
entry['version']='hyle-apple-native-patches-v2'
entry['license']['expression']='MIT AND Apache-2.0'
notice=next(x for x in entry['license']['files'] if x['path'].endswith('NOTICE.md'))
notice['sha256']=hashlib.sha256((ROOT/notice['path']).read_bytes()).hexdigest()
apache='third_party/mlx_cast/metal-cpp-LICENSE.txt'
if not any(x['path']==apache for x in entry['license']['files']):
    entry['license']['files'].append({'root':'hyle','path':apache,'sha256':hashlib.sha256((ROOT/apache).read_bytes()).hexdigest()})
position=text.index('"name": "mlx_cast_patches"');begin=text.rfind('    {',0,position);end=text.index('\n    }',position)+6
text=text[:begin]+'\n'.join('    '+line for line in json.dumps(entry,ensure_ascii=False,indent=2).splitlines())+text[end:]
json.loads(text);path.write_text(text,encoding='utf-8',newline='\n')
print(entry['vendored']['tree_sha256'])
