from pathlib import Path
import hashlib,io,json,re,tarfile,urllib.request
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'.scratch/inference-gaps/g04-g05/metal-lifetime';OUT.mkdir(exist_ok=True)
lock_path=ROOT/'cmake/HyleDependencyLock.json'
lock_text=lock_path.read_text(encoding='utf-8');lock=json.loads(lock_text)
def upstream(name,files):
    entry=next(x for x in lock['dependencies'] if x['name']==name)
    archive=OUT/f'{name}-{entry["revision"]}.tar.gz'
    if not archive.exists():
        with urllib.request.urlopen(entry['archive']['url'],timeout=60) as stream:raw=stream.read()
        assert hashlib.sha256(raw).hexdigest()==entry['archive']['sha256'];archive.write_bytes(raw)
    raw=archive.read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['archive']['sha256']
    result={}
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as package:
        for name in files:
            matches=[m for m in package.getmembers() if '/' in m.name and m.name.split('/',1)[1]==name and m.isfile()];assert len(matches)==1
            result[name]=package.extractfile(matches[0]).read().replace(b'\r\n',b'\n')
    return result
metal=upstream('metal_cpp',['Foundation/NSSharedPtr.hpp','LICENSE.txt'])
mlx=upstream('mlx',['CMakeLists.txt'])
original=metal['Foundation/NSSharedPtr.hpp'].decode()
def guarded(text):
    for expr in ('m_pObject','pOldObject','other.m_pObject'):
        pattern=r'(?m)^(\s*)'+re.escape(expr)+r'->release\(\);$'
        text=re.sub(pattern,lambda m:m[1]+f'if ({expr}) {expr}->release();',text)
    replacements={
      'ret.m_pObject = pObject->retain();':'ret.m_pObject = pObject ? pObject->retain() : nullptr;',
      ': m_pObject(other.m_pObject->retain())':': m_pObject(other.m_pObject ? other.m_pObject->retain() : nullptr)',
      ': m_pObject(reinterpret_cast<_Class*>(other.get()->retain()))':': m_pObject(other.get() ? reinterpret_cast<_Class*>(other.get()->retain()) : nullptr)',
      'm_pObject = other.m_pObject->retain();':'m_pObject = other.m_pObject ? other.m_pObject->retain() : nullptr;',
      'm_pObject = reinterpret_cast<_Class*>(other.get()->retain());':'m_pObject = other.get() ? reinterpret_cast<_Class*>(other.get()->retain()) : nullptr;'}
    for before,after in replacements.items():text=text.replace(before,after)
    return text
edits=[];updated=original
for match in re.finditer(r'(?m)^_NS_INLINE[^\n]*',original):
    begin=match.start();brace=original.find('{',match.end());assert brace>=0
    level=1;end=brace+1
    while level:
        level+=(original[end]=='{')-(original[end]=='}');end+=1
    before=original[begin:end];after=guarded(before)
    if before!=after:
        assert original.count(before)==1;edits.append(dict(before=before,after=after));updated=updated.replace(before,after,1)
assert len(edits)==9,len(edits)
assert updated==guarded(original)
bundle=ROOT/'third_party/mlx_cast'
manifest={'schema':1,'upstream_revision':'f567ed836e4cbb85788c42115a2682bbe68097ee',
          'scope':'Null-safe original SharedPtr retain/release call sites; original nonnull ownership ordering, layout and API unchanged',
          'files':[dict(path='Foundation/NSSharedPtr.hpp',before_sha256=hashlib.sha256(original.encode()).hexdigest(),after_sha256=hashlib.sha256(updated.encode()).hexdigest(),edits=edits)]}
(bundle/'metal-shared-ptr.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(bundle/'metal-cpp-LICENSE.txt').write_bytes(metal['LICENSE.txt'])
(OUT/'original-NSSharedPtr.hpp').write_text(original,encoding='utf-8',newline='\n')
(OUT/'guarded-NSSharedPtr.hpp').write_text(updated,encoding='utf-8',newline='\n')
patch_path=bundle/'patches.json';patches=json.loads(patch_path.read_text(encoding='utf-8'))
assert not any(x['path']=='CMakeLists.txt' for x in patches['files'])
before='  FetchContent_MakeAvailable(metal_cpp)\n  target_include_directories(\n'
after='''  FetchContent_MakeAvailable(metal_cpp)
  if(NOT HYLE_APPLE_METAL_CPP_PATCHED_SOURCE_DIR)
    message(FATAL_ERROR "HYLE Metal lifetime patch source is required")
  endif()
  set(metal_cpp_SOURCE_DIR "${HYLE_APPLE_METAL_CPP_PATCHED_SOURCE_DIR}")
  target_include_directories(
'''
source=mlx['CMakeLists.txt'].decode();assert source.count(before)==1
patched=source.replace(before,after,1)
patches['files'].append(dict(path='CMakeLists.txt',before_sha256=hashlib.sha256(source.encode()).hexdigest(),after_sha256=hashlib.sha256(patched.encode()).hexdigest(),edits=[dict(before=before,after=after)]))
patch_path.write_text(json.dumps(patches,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'guarded_functions':len(edits),'before_sha256':manifest['files'][0]['before_sha256'],'after_sha256':manifest['files'][0]['after_sha256']}))
