#define NS_PRIVATE_IMPLEMENTATION
#define MTL_PRIVATE_IMPLEMENTATION
#include <Foundation/Foundation.hpp>
#include <Metal/Metal.hpp>
#include <objc/message.h>
#include <objc/runtime.h>
#include <cstdio>

int main(int argc,char**) {
  if(argc>1) {
    auto send=reinterpret_cast<void(*)(id,SEL)>(&objc_msgSend);
    send(nullptr,sel_registerName("release"));
    std::puts("actual Objective-C release(nil) completed");
    return 0;
  }
  auto* pool=NS::AutoreleasePool::alloc()->init();
  {
    NS::SharedPtr<MTL::Device> device;
    device=NS::TransferPtr(MTL::CreateSystemDefaultDevice());
    if(!device)return 2;
    std::puts("actual metal-cpp SharedPtr null-to-device assignment completed");
  }
  pool->release();
  return 0;
}
