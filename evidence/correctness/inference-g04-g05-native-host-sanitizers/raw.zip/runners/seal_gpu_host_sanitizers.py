from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.scratch/inference-gaps/g04-g05'
RUN=BASE/'gpu-host'
OUT=ROOT/'evidence/correctness/inference-g04-g05-native-host-sanitizers'
records=[]
for path in sorted(RUN.glob('result-*.json')):
    data=json.loads(path.read_text());assert data['state'].startswith('TERMINAL_'),path
    tag=path.stem.removeprefix('result-');records.append((tag,data))
latest={}
for tag,record in records:
    key=(record['route'],record['mode']);number=int(tag.rsplit('-',1)[1])
    if key not in latest or number>int(latest[key][0].rsplit('-',1)[1]):latest[key]=(tag,record)
for route in ('apple','vulkan'):
    for mode in ('asan','ubsan','tsan'):
        tag,record=latest[route,mode]
        assert record['state']=='TERMINAL_PASS',(tag,record['state'])
        for stage,count in [('math',11),('pages',4 if route=='apple' else 3)]:
            xml=ET.parse(RUN/f'{stage}-{tag}.xml').getroot()
            assert int(xml.attrib['tests'])==count and xml.attrib['failures']=='0',(tag,stage)
        assert (RUN/f'instrumentation-{tag}.json').is_file()
        log=(RUN/f'risks-{tag}.log').read_text()
        assert 'allocation faults' in log and 'foreign resource refusal PASS' in log
        assert 'mode=0 ' in log and 'mode=3 ' in log
        expected=[2 if route=='apple' else 1] if mode=='tsan' else []
        assert len(record['models'])==(expected[0] if expected else 0)

names=['tests/compute_batch/encoded_page_native_consumer.cc','tests/compute_batch/native_paged_risk_fixture.h',
       'tests/compute_batch/native_paged_apple_risks.cc','tests/compute_batch/native_paged_vulkan_risks.cc',
       'tests/compute_batch/native_apple_failure_fixture.h','tests/compute_batch/native_vulkan_failure_fixture.h',
       'tests/compute_route_apple/native_cache_test.cc','tests/compute_route_vulkan/native_cache_test.cc',
       'src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_batch.cc',
       'src/compute_route_vulkan/vulkan_batch.cc','src/compute_provider_ggml_vulkan/region.cc',
       'include/hyle/compute/model_ops.h','include/hyle/compute/batch_layout.h',
       'include/hyle/compute/detail/materialized_native_controller.h',
       'third_party/mlx_cast/patches.json','third_party/ggml_vulkan_runtime/patches.json',
       'cmake/HyleDependencyLock.json']
apple_only=['third_party/mlx_cast/patches.json','third_party/mlx_cast/metal-shared-ptr.json',
            'third_party/mlx_cast/metal-cpp-LICENSE.txt','third_party/mlx_cast/NOTICE.md',
            'cmake/HyleAppleDependencies.cmake','src/compute_route_apple/CMakeLists.txt',
            'tests/compute_route_apple/metal_shared_ptr_lifetime.cc']
names=list(dict.fromkeys(names+apple_only))
sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names}
for tag,record in latest.values():
    inputs={i['path']:i['sha256'] for i in record['inputs']}
    for name,digest in sha.items():
        if record['route']=='vulkan' and (name in apple_only or name.startswith('src/compute_route_apple/') or name=='cmake/HyleDependencyLock.json'):continue
        assert inputs[name]==digest,(record['route'],record['mode'],name)
    if record['route']=='vulkan':
        # CE10 changes only the Apple patch asset. Every other lock entry must
        # exactly match the earlier passing Vulkan build; no global-lock rerun.
        with zipfile.ZipFile(RUN/f'source-{tag}.zip') as source:
            old=json.loads(source.read('cmake/HyleDependencyLock.json'))
        new=json.loads((ROOT/'cmake/HyleDependencyLock.json').read_text())
        for data in (old,new):data['dependencies']=[d for d in data['dependencies'] if d['name']!='mlx_cast_patches']
        assert old==new,(tag,'non-Apple lock inputs changed')

provenance=json.loads((RUN/'metal-product-provenance.json').read_text())
assert provenance['verdict']=='PASS_DERIVED_HEADER_AND_ACTUAL_INCLUDE_COMMANDS'
nil=json.loads((BASE/'metal-nil-probe/result.json').read_text())
assert [s['exit_code'] for s in nil['stages']]==[0,-6,0]
startup=json.loads((RUN/'startup-apple-tsan-1.json').read_text())
assert startup['state']=='TERMINAL_FAIL'
tag,lifetime=latest['apple','ubsan']
assert all(any(s['stage']==stage and s['exit_code']==0 for s in lifetime['stages']) for stage in ('metal-lifetime-compile','metal-lifetime'))

OUT.mkdir(parents=True,exist_ok=False)
result={
 'kind':'G04_G05_ACTUAL_APPLE_VULKAN_NEW_DOMAIN_HOST_SANITIZERS',
 'verdict':'PASS_SIX_CONFIGURATIONS_WITH_EXPLICIT_ORIGINAL_TSAN_BOUNDARY_MODELS',
 'product_baseline':'2983af255 plus exact CE10/CE11 inputs below; eleven owners remain AUDITED; not complete G04/G05',
 'input_sha256':sha,
 'qualified':[
   'Actual MacBook Air Mac16,12 arm64/macOS27.0.1/AppleClang21; Apple and Vulkan each ASan/UBSan/TSan',
   'Each configuration all11new-domain CacheEncode/attention tests PASS, including finite tiny-scale bytes, window/noncausal/Dv, long-prefill and finite accumulation boundaries',
   'Each Apple configuration public native/requiredCPU+Apple four tests PASS: F16 and BF16, single/multi, D64/128 andD256/256, paired/independent original Graph encoders -> one original F2 Update -> final-only native/joint consumption, six updates and original accepted numeric failures',
   'Each Vulkan configuration same finite F16 native/requiredCPU+Vulkan three public tests PASS; no BF16 Vulkan claim',
   'Each configuration six Q8 D64/128 window16 original native risks PASS; all52Apple/55Vulkan cold allocation failure points, cancellation/abandonment or actual accepted unknown/wait error, native guard/page retirement and empty/foreign/role mismatch refusal',
   'Actual compile commands verify sanitizer instrumentation on selected HYLE native/Graph/metadata/controller consumers, CPU+GPU coordinator, original MLX host fast/Metal attention or ggml Vulkan host region/backend and all three test TUs',
   'CE10 actual original locked SharedPtr independent no-HYLE/no-MLX nullptr-member negative control exits -6 under UBSan; actual objc_msgSend nil control exits0. Product-derived nullable guards pass standalone empty/nonempty/copy/move/reset/retain/destruction and actual Metal device lifecycle at Clang21/O3/UBSan; all final Apple configurations use guarded product Foundation header',
   'CE11 original Apple TSan2 math11 PASS but public encoded pages exit -6 with actual allocator active-memory reader versus old-array free writer race. Exact allocator.h/cpp patch protects four external getters with existing mutex; internal already-locked malloc/free read fields/cache directly, no recursive lock/new state or whole-execution serialization. Final three Apple sanitizer profiles run actual CE10+CE11 derived product and all fixed public consumers.'],
 'ce10':{'product_header_provenance':provenance,'independent_negative_control':nil,
         'original_startup_failure':startup,
         'reuse':'Vulkan profiles passed with Apple patch asset differing. Relevant route input hashes and all non-Apple dependency lock entries exactly match final CE10+CE11 source; no unchanged run repeated.'},
 'boundary_models':{
   'refcount':'TSan only, original qualified SHA2b90ab65... unchanged. Mechanical reversal of sanitizer include, final acquire annotation, one static-to-const method and two member call sites exactly equals current canonical header. No product change or race suppression.',
   'metal':'Apple TSan only, original independently reproduced command-buffer commit/completion annotation SHA4a58c6e5... unchanged. Current product-derived Metal tree retained byte-for-byte except that one exact MTLCommandBuffer.hpp. Foundation SharedPtr uses real CE10 product guards, never an old validation-model Foundation tree. No suppressions.',
   'prior_evidence':['evidence/correctness/inference-g01-native-page-host-sanitizers/receipt.json','evidence/correctness/inference-g03-graph-late-risks/validation-result.json']},
 'limits':['ASan detect_leaks0: no LSan certificate','No GPU shader/driver sanitizer','No native private-pool byte bound or instrumentation certificate','No new-domain installed static/shared/standalone-header or qualified P1 verdict','No whole G04/G05 or complete G01-G10 acceptance'],
 'runs':[dict(tag=tag,**{k:v for k,v in record.items() if k!='inputs'}) for tag,record in records],
 'cumulative_seconds':sum(r['cumulative_seconds'] for _,r in records)+nil['cumulative_seconds'],
 'unmeasured_elapsed':['Apple TSan attempt1 stopped before configure at runner assertion; exact wall time not measured, never recorded as zero.']}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as raw:
    for file in sorted(RUN.iterdir()):
        if file.is_file() and file.suffix!='.zip':raw.write(file,file.name)
    for tag,_ in records:
        with zipfile.ZipFile(RUN/f'source-{tag}.zip') as source:
            for name in [*names,'source-manifest.json']:
                if name in source.namelist():raw.writestr(f'inputs/{tag}/{name}',source.read(name))
    with zipfile.ZipFile(RUN/'source-apple-tsan-1.zip') as source:
        raw.writestr('inputs/apple-tsan-1/source-manifest.json',source.read('source-manifest.json'))
    for file in sorted((BASE/'metal-nil-probe').iterdir()):
        if file.is_file():raw.write(file,'metal-nil-probe/'+file.name)
    for file in sorted((BASE/'metal-lifetime').glob('original-allocator.*')):
        raw.write(file,'ce11-original/'+file.name)
    for name in ['encoded_gpu_san_air.py','launch_encoded_gpu_san.py','seal_gpu_host_sanitizers.py','metal_nil_probe.cc','metal_nil_probe_air.py','collect_metal_provenance_air.py','prepare_allocator_stats.py','prepare_metal_lifetime.py','refresh_apple_lifetime_lock.py']:
        raw.write(BASE/name,'runners/'+name)
print(json.dumps({'runs':len(records),'cumulative_seconds':result['cumulative_seconds'],'raw_bytes':(OUT/'raw.zip').stat().st_size}))
