from pathlib import Path
import hashlib,json,shlex,subprocess
BASE=Path('/Users/kiro/hyle-scratch/compute-unified')
OUT=BASE/'g04-g05-encoded-host-sanitizers'
SOURCE=BASE/'source-c8874688'
locked=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/metal_cpp-f567ed836e4c-3874e9e28e8e')
expected='d93f38effcc9556aa2cd2dec13db0cdcf37cd36bfd217bcbeedeb7e6c55fd2f4'
original=hashlib.sha256((locked/'Foundation/NSSharedPtr.hpp').read_bytes()).hexdigest()
assert original=='0dea8b2ec04c9fbabfc4a105a372ec2750789ad83ff4b878b78814a81bc2c6fa'
bundle=next(d for d in json.loads((SOURCE/'cmake/HyleDependencyLock.json').read_text())['dependencies'] if d['name']=='mlx_cast_patches')
patch_id=bundle['vendored']['tree_sha256'][:16]
result={'verdict':'PASS_DERIVED_HEADER_AND_ACTUAL_INCLUDE_COMMANDS','original_cache_sha256':original,'bundle_sha256':bundle['vendored']['tree_sha256'],'configurations':[]}
allocator_manifest={f['path']:f for f in json.loads((SOURCE/'third_party/mlx_cast/patches.json').read_text())['files'] if f['path'] in ('mlx/backend/metal/allocator.h','mlx/backend/metal/allocator.cpp')}
assert len(allocator_manifest)==2
for mode,attempt in [('asan',3),('ubsan',5),('tsan',3)]:
    build=BASE/f'foundation-f5-native-host-apple-{mode}/build'
    derived=build/'hyle/_deps'/f'metal-cpp-{patch_id}'/'source'
    header=derived/'Foundation/NSSharedPtr.hpp'
    assert hashlib.sha256(header.read_bytes()).hexdigest()==expected
    record=json.loads((OUT/f'result-apple-{mode}-{attempt}.json').read_text())
    assert record['state']=='TERMINAL_PASS'
    mlx_source=build/'hyle/_deps'/f'mlx-{patch_id}'/'source'
    allocator_files=[]
    for name,entry in allocator_manifest.items():
        file=mlx_source/name
        assert hashlib.sha256(file.read_bytes()).hexdigest()==entry['after_sha256']
        upstream=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/mlx-1f8e74e3f12f-95caa530dd41')/name
        assert hashlib.sha256(upstream.read_bytes()).hexdigest()==entry['before_sha256']
        allocator_files.append({'path':str(file),'sha256':entry['after_sha256'],'original_cache_sha256':entry['before_sha256']})
    rows=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],text=True))
    selected=[]
    for suffix in ['mlx/fast.cpp','mlx/backend/metal/scaled_dot_product_attention.cpp','mlx/backend/metal/allocator.cpp','src/compute_route_apple/apple_mature_float.cc']:
        found=[r for r in rows if r['file'].endswith(suffix)]
        assert found,suffix
        for row in found:
            tokens=shlex.split(row['command']);normal=[];system=[];i=0
            while i<len(tokens):
                token=tokens[i]
                if token in ('-I','-isystem'):
                    (normal if token=='-I' else system).append(Path(tokens[i+1]));i+=2;continue
                if token.startswith('-I'):normal.append(Path(token[2:]))
                i+=1
            resolved=next((folder/'Foundation/NSSharedPtr.hpp' for folder in normal+system if (folder/'Foundation/NSSharedPtr.hpp').is_file()),None)
            assert resolved is not None,suffix
            assert hashlib.sha256(resolved.read_bytes()).hexdigest()==expected,(mode,suffix,str(resolved))
            selected.append({'source':row['file'],'command':row['command'],'effective_foundation_header':str(resolved),'sha256':expected})
    result['configurations'].append({'mode':mode,'attempt':attempt,'derived_header':str(header),'sha256':expected,'allocator_files':allocator_files,'compile_commands':selected})
(OUT/'metal-product-provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS original cache unchanged; final three Apple profiles use actual guarded product header')
