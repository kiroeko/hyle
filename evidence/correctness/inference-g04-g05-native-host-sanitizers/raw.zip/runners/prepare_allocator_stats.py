from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[3]
scratch=ROOT/'.scratch/inference-gaps/g04-g05/metal-lifetime'
path=ROOT/'third_party/mlx_cast/patches.json'
manifest=json.loads(path.read_text(encoding='utf-8'))
edits={
 'mlx/backend/metal/allocator.h':[
  (f'  size_t {name}() {{\n    return ',f'  size_t {name}() {{\n    std::unique_lock lk(mutex_);\n    return ')
  for name in ('get_active_memory','get_peak_memory','get_cache_memory')],
 'mlx/backend/metal/allocator.cpp':[
  ('size_t MetalAllocator::get_memory_limit() {\n  return block_limit_;',
   'size_t MetalAllocator::get_memory_limit() {\n  std::unique_lock lk(mutex_);\n  return block_limit_;'),
  ('    size_t mem_required = get_active_memory() + get_cache_memory() + size;',
   '    size_t mem_required = active_memory_ + buffer_cache_.cache_size() + size;'),
  ('  if (get_cache_memory() > max_pool_size_) {',
   '  if (buffer_cache_.cache_size() > max_pool_size_) {'),
  ('        get_cache_memory() - max_pool_size_);',
   '        buffer_cache_.cache_size() - max_pool_size_);'),
  ('  if (get_cache_memory() < max_pool_size_) {',
   '  if (buffer_cache_.cache_size() < max_pool_size_) {')]
}
for name,replacements in edits.items():
 assert not any(f['path']==name for f in manifest['files'])
 raw=(scratch/('original-'+Path(name).name)).read_bytes()
 before=raw.decode('utf-8');after=before
 for old,new in replacements:
  assert after.count(old)==1,(name,old)
  after=after.replace(old,new)
 manifest['files'].append({'path':name,'before_sha256':hashlib.sha256(raw).hexdigest(),
    'after_sha256':hashlib.sha256(after.encode()).hexdigest(),
    'edits':[{'before':old,'after':new} for old,new in replacements]})
 print(name,manifest['files'][-1]['before_sha256'],manifest['files'][-1]['after_sha256'])
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
