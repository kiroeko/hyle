from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,time
r=Path('/Users/kiro/hyle-verify/r5-apple-20260917')
archive=r/'apple-native-candidate-1636365b.tar.gz'
expected='a37e7e63d082c9d146f95efa7ffCBD3ebe7d7e0e51caa60419456309a94f7c90'.lower()
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
source=r/'candidate-1636365b'
if not source.exists():
    with tarfile.open(archive) as t:
        for m in t.getmembers():
            assert (r/m.name).resolve().is_relative_to(source)
        t.extractall(r)
build=r/'native-1636365b'
logs=r/'logs/native-1636365b'
assert not logs.exists(),'inspect previous native validation before resuming'
logs.mkdir()
env=os.environ.copy()
env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/Users/kiro/hyle-verify-tools/bin:'+env['PATH']
env['CMAKE_BUILD_PARALLEL_LEVEL']='2'
env['CTEST_PARALLEL_LEVEL']='1'
def run(label,args):
    print(label,flush=True)
    begin=time.monotonic()
    with (logs/(label+'.log')).open('w') as f:
        p=subprocess.run([str(x) for x in args],env=env,cwd=source,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
    print(label+': rc='+str(p.returncode)+' seconds='+str(round(time.monotonic()-begin,2)),flush=True)
    if p.returncode: print((logs/(label+'.log')).read_text()[-10000:],flush=True)
    p.check_returncode()
run('configure',['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
    '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
    '-DHYLE_DEV_FACTORS=compute_route_apple;graph_route_apple','-DHYLE_COMPUTE_APPLE=ON',
    '-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_BUILD_TESTS=ON',
    '-DHYLE_BUILD_BENCH=OFF','-DHYLE_STATIC=ON','-DHYLE_INSTALL=OFF','-DHYLE_WERROR=ON',
    '-DHYLE_SANITIZER=off','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build',['cmake','--build',build,'--parallel','2','--target','hyle_compute_route_apple_tests','hyle_graph_route_apple_tests'])
run('ctest',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','--timeout','120',
    '-L','^(compute_route_apple|graph_route_apple)$'])
shutil.copyfile(build/'Testing/Temporary/LastTest.log',logs/'LastTest.log')
shutil.copyfile(build/'CMakeCache.txt',logs/'CMakeCache.txt')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
record={'candidate':'1636365bbe47779de24e84d7c7d1ed8088fe1af2','archive_sha256':expected,
    'model':subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip(),
    'os':subprocess.check_output(['/usr/bin/sw_vers'],text=True),
    'role':'correctness/portability only; not the M1-MAC performance machine','result':'PASS',
    'artifacts':{p.name:sha(p) for p in (build/'bin/hyle_compute_route_apple_test',build/'bin/hyle_graph_route_apple_test')},
    'logs':{p.name:sha(p) for p in logs.glob('*.log')}}
(logs/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
