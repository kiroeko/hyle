from pathlib import Path
import re

ROOT=Path.cwd()
def get(name):return (ROOT/name).read_text()
def put(name,text):(ROOT/name).write_text(text,encoding='utf-8',newline='\n')
def block_end(text,start):
    depth=0
    for i in range(start,len(text)):
        if text[i]=='{':depth+=1
        elif text[i]=='}':
            depth-=1
            if depth==0:return i+1
    raise AssertionError('unbalanced braces')
def keep_if_body(text,condition):
    marker='if constexpr ('+condition+')'
    while marker in text:
        a=text.index(marker);opening=text.index('{',a);end=block_end(text,opening)
        body=text[opening+1:end-1];after=end
        tail=text[after:];match=re.match(r'\s*else\s*\{',tail)
        if match:
            else_open=after+match.end()-1;after=block_end(text,else_open)
        text=text[:a]+body+text[after:]
    return text

n='src/compute_provider_native/normalization.cc';t=get(n)
t=t.replace(', class Bias, bool Rms','').replace('<Value, Scale, Bias, Rms>','<Value, Scale>')
t=t.replace('  const void *bias = nullptr;\n','')
a=t.index('    if constexpr (!Rms) {');b=block_end(t,t.index('{',a));t=t[:a]+t[b:]
t=t.replace('''      if constexpr (!Rms)
        for (std::size_t index = 0; index < size; ++index)
          values[index] -= mean;
''','')
t=t.replace('    float mean = 0.0F;\n','').replace('(values[index] - mean) * inverse','values[index] * inverse')
a=t.index('      if (episode.bias != nullptr) {');b=block_end(t,t.index('{',a));t=t[:a]+t[b:]
t=t.replace('      .bias = inputs.size() > 2 ? source_data[2] : nullptr,\n','')
a=t.index('  if constexpr (std::is_same_v<Value, float>) {');b=t.index('    parallel_for_ranges(\n',a)
t=t[:a]+t[b:]
t=t.replace('template <class Value, bool Rms>','template <class Value>')
t=keep_if_body(t,'Rms')
t=t.replace('<Value, float, Value, true>','<Value, float>').replace('<Value, Value, Value, true>','<Value, Value>')
t=t.replace('<simd::bfloat16_t, true>','<simd::bfloat16_t>')
t=t.replace('inputs.size() > 3','inputs.size() > 2')
put(n,t)

n='src/compute_provider_native/transformer.cc';t=get(n)
a=t.index('Status require_plain_f32(');b=t.index('Status invalidate_for_read(',a);t=t[:a]+t[b:]
t=keep_if_body(t,'!std::is_same_v<Value, float>')
t=t.replace('''        if (plan.softmax_kind == SoftmaxKind::kSoftmax)
          simd::softmax_f32(row_scratch, axis_extent);
        else
          simd::log_softmax_f32(row_scratch, axis_extent);''',
            '        simd::softmax_f32(row_scratch, axis_extent);')
assert 'softmax_kind' not in t,t[t.find('softmax_kind')-50:t.find('softmax_kind')+100]
put(n,t)

n='src/compute_provider_native/elementwise.cc';t=get(n)
t=t.replace('  else if constexpr (Kind == BinaryKind::kMultiply)\n    return left * right;\n','')
t=t.replace('''  } else if constexpr (Kind == BinaryKind::kMultiply) {
    simd::multiply(left, right, destination, count);''','')
t=t.replace('''  } else if constexpr (Kind == BinaryKind::kMinimum) {
    simd::fmin(left, right, destination, count);
  } else {
    static_assert(Kind == BinaryKind::kMaximum);
    simd::fmax(left, right, destination, count);''',
'''  } else {
    static_assert(Kind == BinaryKind::kMinimum);
    simd::fmin(left, right, destination, count);''')
t=t.replace('''  else if constexpr (Kind == BinaryKind::kMinimum)
    return std::fmin(left, right);
  else {''','''  else {''')
put(n,t)

n='src/compute_provider_native/cast.cc';t=get(n)
a=t.index('template <class Source>\nbool select_destination');b=t.index('detail::EnqueueResult submit_cast',a)
replacement='''template <class Source, class Destination>
void select_pair(NativePlan &plan) noexcept {
  plan.linear_elementwise_route = &convert_linear<Source, Destination>;
  plan.scalar_elementwise_route = &convert_scalar<Source, Destination>;
}
bool select_cast(DataType source, DataType destination, NativePlan &plan) noexcept {
  if (source == DataType::kFloat8E4M3FN && destination == DataType::kFloat16) {
    select_pair<simd::float8_e4m3_t, simd::float16_t>(plan);
    return true;
  }
  if (source != DataType::kFloat8E5M2)
    return false;
  if (destination == DataType::kBFloat16) {
    select_pair<simd::float8_e5m2_t, simd::bfloat16_t>(plan);
    return true;
  }
  if (destination == DataType::kFloat8E4M3FN) {
    select_pair<simd::float8_e5m2_t, simd::float8_e4m3_t>(plan);
    return true;
  }
  return destination == DataType::kFloat8E5M2;
}

'''
t=t[:a]+replacement+t[b:]
t=t.replace('  if (inputs[0].data_type() == cast->output_type)\n    return prepare_transform(Operation(Copy{}), inputs, outputs, plan);\n','')
needle='  auto elements = outputs[0].element_count();'
at=t.index(needle,t.index('Status prepare_cast('))
t=t[:at]+'''  if (inputs[0].data_type() == cast->output_type)
    return prepare_transform(Operation(Copy{}), inputs, outputs, plan);
'''+t[at:]
put(n,t)

n='src/compute_provider_native/native_plan.h';t=get(n)
a=t.index('using RopeKernelRoute =');b=t.index('using ParallelRangeRoute =',a);t=t[:a]+t[b:]
for line in ('  std::size_t count = 0;','  std::size_t rotary_dimensions = 0;',
             '  std::size_t sequence_axis = 0;','  ScatterKind scatter_kind = ScatterKind::kAssign;',
             '  RopeLayout rope_layout = RopeLayout::kInterleaved;',
             '  SoftmaxKind softmax_kind = SoftmaxKind::kSoftmax;',
             '  bool largest = true;','  bool sorted = true;','  bool stable = true;',
             '  RopeKernelRoute rope_kernel_route = nullptr;'):
    t=t.replace(line+'\n','')
put(n,t)
print('Removed unreachable LayerNorm/log/f32 transformer arithmetic, obsolete fields and unused Cast instantiations.')
