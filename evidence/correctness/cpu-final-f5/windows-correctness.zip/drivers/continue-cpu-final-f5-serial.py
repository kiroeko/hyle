import ctypes,json,subprocess,sys,time
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f5'
kernel=ctypes.windll.kernel32
kernel.SetErrorMode(32771)
kernel.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32]
kernel.OpenProcess.restype=ctypes.c_void_p
kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
kernel.CloseHandle.argtypes=[ctypes.c_void_p]
# Open the already verified owning process now. A retained OS handle remains
# tied to that process even if Windows later reuses its numeric PID.
handle=kernel.OpenProcess(0x100000,False,73052)
if not handle:raise RuntimeError('Verified consumer batch handle no longer available; inspect its receipt before resuming.')
started=time.monotonic()
print('Waiting on verified consumer batch process 73052; subsequent heavy steps remain serial.',flush=True)
try:
    while True:
        state=kernel.WaitForSingleObject(handle,1000)
        if state==0:break
        if state!=258:raise RuntimeError('Cannot observe the original consumer batch handle')
finally:kernel.CloseHandle(handle)
(out/'serial-handoff.json').write_text(json.dumps({'waited_seconds':round(time.monotonic()-started,3),
    'observed_handle':'Win32 process 73052','condition':'original consumer batch process terminal',
    'next':'Graph test migration; Windows delivery if migration passes'},indent=2)+'\n')
for name,script in [('graph-migration','.scratch/validate-cpu-final-f5-graph-migration.py'),
                    ('windows-delivery','.scratch/run-cpu-final-f5-windows-delivery.py')]:
    log=out/(name+'-driver.log')
    with log.open('wb') as stream:
        result=subprocess.run([sys.executable,script],stdout=stream,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW)
    print({'name':name,'exit':result.returncode,'log':str(log)},flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-5000:],flush=True)
        raise SystemExit(result.returncode)
