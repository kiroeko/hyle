exec(open('.scratch/validate-cpu-final-f5-first.py',encoding='utf-8').read().split("\nrun('configure-tests'")[0])
run('graph-migration-configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON',
    '-DHYLE_INSTALL=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('graph-migration-build',['cmake','--build',build,'--target','hyle_graph_tests','--parallel','2'])
run('graph-migration-tests',[build/'bin/hyle_graph_executable_test.exe',
    '--gtest_output=xml:'+str(out/'graph-migration.xml')])
