"""Audited D1: finite branch deletion, retaining qualified arithmetic verbatim."""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
def read(name): return (ROOT/name).read_text(encoding='utf-8')
def write(name,text): (ROOT/name).write_text(text,encoding='utf-8',newline='\n')
def cut(text,begin,end):
    a=text.index(begin);b=text.index(end,a);return text[:a]+text[b:]

name='src/compute_provider_native/elementwise.cc';t=read(name)
# Sigmoid helper remains necessary for the qualified SiLU scalar calculation.
t=t.replace('if constexpr (Kind == UnaryKind::kAbs) {\n    return std::fabs(value);\n  } else if constexpr (Kind == UnaryKind::kNeg)', 'if constexpr (Kind == UnaryKind::kNeg)')
t=t.replace('  } else if constexpr (Kind == UnaryKind::kSigmoid) {\n    return sigmoid(value);','')
t=t.replace('  } else if constexpr (Kind == UnaryKind::kSoftplus) {\n    return std::fmax(value, 0.0F) + std::log1p(std::exp(-std::abs(value)));','')
t=t.replace('if constexpr (Kind == UnaryKind::kAbs) {\n    simd::abs(source, destination, count);\n  } else if constexpr (Kind == UnaryKind::kNeg)', 'if constexpr (Kind == UnaryKind::kNeg)')
t=t.replace('  } else if constexpr (Kind == UnaryKind::kSigmoid) {\n    simd::sigmoid_f32_batch(source, destination, count);','')
t=cut(t,'  } else if constexpr (Kind == UnaryKind::kSoftplus) {','  } else {\n    static_assert(Kind == UnaryKind::kRsqrt);')
t=cut(t,'template <std::size_t ElementSize>\nvoid select_linear','template <class Left, class Right>')
t=cut(t,'bool select_select(DataType','bool dense_same_shape(')
t=cut(t,'  case OperationKind::kSelect: {','  default:\n    return Status::Unimplemented("operation is not native elementwise")')
for kind in ('kAbs','kSigmoid','kSoftplus'):
    t=t.replace('    HYLE_NATIVE_SELECT_UNARY('+kind+');\n','')
for kind in ('kMultiply','kMaximum'):
    t=t.replace('    HYLE_NATIVE_SELECT_BINARY('+kind+');\n','')
# Avoid instantiating unused arithmetic for another dtype. Conditions derive
# only from the complete F4 choices, not from unqualified partial wins.
u='''  if constexpr (std::is_same_v<Value, float>) {
    if (kind != UnaryKind::kExp) return false;
  } else if constexpr (std::is_same_v<Value, simd::float16_t>) {
    if (kind != UnaryKind::kExp && kind != UnaryKind::kLog && kind != UnaryKind::kSqrt &&
        kind != UnaryKind::kRsqrt && kind != UnaryKind::kTanh && kind != UnaryKind::kSilu) return false;
  } else {
    if (kind != UnaryKind::kNeg && kind != UnaryKind::kExp && kind != UnaryKind::kSqrt &&
        kind != UnaryKind::kRsqrt && kind != UnaryKind::kRelu) return false;
  }
'''
old='''  if constexpr (std::is_same_v<Value, float>)
    if (kind == UnaryKind::kSilu)
      return false;
'''
assert old in t;t=t.replace(old,u)
# The switch cases themselves are template-gated to remove unwanted instances.
for kind,condition in {'kNeg':'std::is_same_v<Value, simd::bfloat16_t>',
 'kExp':'true','kLog':'std::is_same_v<Value, simd::float16_t>',
 'kSqrt':'!std::is_same_v<Value, float>','kRsqrt':'!std::is_same_v<Value, float>',
 'kTanh':'std::is_same_v<Value, simd::float16_t>',
 'kRelu':'std::is_same_v<Value, simd::bfloat16_t>',
 'kSilu':'std::is_same_v<Value, simd::float16_t>'}.items():
    old='    HYLE_NATIVE_SELECT_UNARY('+kind+');'
    assert old in t;t=t.replace(old,'    if constexpr ('+condition+') { '+old.strip()+' }')
for kind,condition in {'kAdd':'std::is_same_v<Value, float>',
 'kSubtract':'!std::is_same_v<Value, simd::bfloat16_t>',
 'kDivide':'!std::is_same_v<Value, simd::bfloat16_t>',
 'kMinimum':'std::is_same_v<Value, simd::float16_t>'}.items():
    old='    HYLE_NATIVE_SELECT_BINARY('+kind+');';assert old in t
    t=t.replace(old,'    if constexpr ('+condition+') { '+old.strip()+' }')
# Delete the retired arithmetic branches, not just their dispatch.
t=t.replace('  } else if constexpr (Kind == BinaryKind::kMultiply) {\n    return left * right;','')
t=t.replace('  } else if constexpr (Kind == BinaryKind::kMultiply) {\n    simd::multiply(left, right, result, count);','')
t=t.replace('    static_assert(Kind == BinaryKind::kMaximum);\n    return std::fmax(left, right);','    static_assert(Kind == BinaryKind::kMinimum);\n    return std::fmin(left, right);')
t=t.replace('      gated->activation != GatedActivationKind::kSilu)',
            '      gated->activation != GatedActivationKind::kSilu ||\n      gated->inputs != GatedInputKind::kSeparate)')
t=t.replace('return Status::InvalidArgument("native Binary kind is invalid");',
            'return Status::Unimplemented("native Binary kind/dtype is not retained");')
write(name,t)

name='src/compute_provider_native/indexing.cc';t=read(name)
t=cut(t,'template <class Value>\ndetail::EnqueueResult\nsubmit_scatter','} // namespace\n\nStatus prepare_indexing')
t=cut(t,'  case OperationKind::kScatter: {','  default:\n    return Status::Unimplemented("operation is not native indexing")')
write(name,t)

name='src/compute_provider_native/normalization.cc';t=read(name)
t=cut(t,'void run_layer_norm_range(', 'template <class Value, class Scale, class Bias, bool Rms>')
# Preserve the original RMS specialization unchanged; delete LayerNorm selection
# and its unreachable bias instantiations, letting the compiler discard branches.
t=cut(t,'  const bool bias_f32 =','}\n\n} // namespace\n\nStatus prepare_normalization')
t=t.replace('  const LayerNorm *layer = operation.get_if<LayerNorm>();\n','')
t=t.replace('  if (layer == nullptr && rms == nullptr)', '  if (rms == nullptr)')
t=t.replace('  const DataType accumulation =\n      layer != nullptr ? layer->accumulation_type : rms->accumulation_type;',
            '  const DataType accumulation = rms->accumulation_type;')
t=t.replace('  plan.scalar = layer != nullptr ? layer->epsilon : rms->epsilon;', '  plan.scalar = rms->epsilon;')
t=t.replace('''  case DataType::kFloat32:
    if (rms != nullptr)
      return Status::Internal("float32 RMSNorm uses its native float route");
    plan.submit_route = &submit_normalization<float, float, float, false>;
    break;
  case DataType::kFloat16:
    plan.submit_route =
        rms != nullptr ? select_narrow_norm<simd::float16_t, true>(inputs)
                       : select_narrow_norm<simd::float16_t, false>(inputs);
    break;
''', '''  case DataType::kFloat32:
    return Status::Internal("float32 RMSNorm uses its native float route");
''')
t=t.replace('''    plan.submit_route =
        rms != nullptr ? select_narrow_norm<simd::bfloat16_t, true>(inputs)
                       : select_narrow_norm<simd::bfloat16_t, false>(inputs);''',
            '    plan.submit_route = select_narrow_norm<simd::bfloat16_t, true>(inputs);')
t=t.replace('''  if constexpr (std::is_same_v<Value, float>) {
    parallel_for_ranges(plan, rows, &run_layer_norm_range, &episode);
  } else {
''','')
t=t.replace('''        plan, rows, &run_narrow_norm_range<Value, Scale, Bias, Rms>, &episode);
  }''','''        plan, rows, &run_narrow_norm_range<Value, Scale, Bias, Rms>, &episode);''')
write(name,t)

name='src/compute_provider_native/reduction.cc';t=read(name)
t=cut(t,'void finish_mean(', 'float reduce_dense(')
t=t.replace('  case ReductionKind::kSum:\n  case ReductionKind::kMean:\n    return 0.0F;\n','')
t=t.replace('  case ReductionKind::kSum:\n  case ReductionKind::kMean:\n    result += value;\n    return;\n','')
t=t.replace('  case ReductionKind::kSum:\n  case ReductionKind::kMean:\n    return simd::sum(input, count);\n','')
t=t.replace('''    if (plan.reduction_kind == ReductionKind::kMean)
      accumulator = count == 0 ? std::numeric_limits<float>::quiet_NaN()
                               : accumulator / static_cast<float>(count);
''','')
t=re.sub(r'    if \(plan.reduction_kind == ReductionKind::kMean\)\n      finish_mean\([^;]+;\n','',t)
needle='  const Reduce *reduce = operation.get_if<Reduce>();'
assert needle in t;t=t.replace(needle,needle+'''
  if (reduce == nullptr ||
      (reduce->kind != ReductionKind::kMinimum && reduce->kind != ReductionKind::kMaximum) ||
      (inputs[0].data_type() != DataType::kFloat16 &&
       !(inputs[0].data_type() == DataType::kBFloat16 && reduce->kind == ReductionKind::kMaximum)))
    return Status::Unimplemented("native Reduce retains qualified narrow Min/Max only");''')
t=t.replace('''  plan.submit_route =
      type == DataType::kFloat16    ? &submit_reduction<simd::float16_t>
      : type == DataType::kBFloat16 ? &submit_reduction<simd::bfloat16_t>
                                    : &submit_reduction<float>;''',
'''  plan.submit_route = type == DataType::kFloat16
                          ? &submit_reduction<simd::float16_t>
                          : &submit_reduction<simd::bfloat16_t>;''')
write(name,t)

name='src/compute_provider_native/transformer.cc';t=read(name)
t=t.replace('#include "../compute/rope_kernels.h"\n','').replace('#include "hyle/simd/fat_kernel.h"\n','')
t=cut(t,'RopeKernelRoute select_rope_kernel(', 'template <class Value>\ndetail::EnqueueResult submit_softmax_impl')
# Helper definitions before the rope selector remain shared by Softmax.
t=cut(t,'detail::EnqueueResult\nsubmit_softmax(', '} // namespace\n\nStatus prepare_transformer')
t=cut(t,'  case OperationKind::kRoPE: {','  case OperationKind::kSoftmax: {')
needle='    const Softmax *softmax = operation.get_if<Softmax>();';assert needle in t
t=t.replace(needle,needle+'''
    if (softmax->kind != SoftmaxKind::kSoftmax || softmax->mask != MaskKind::kBoolean ||
        type != DataType::kFloat16)
      return Status::Unimplemented("native Softmax retains qualified F16 Bool softmax only");''')
t=t.replace('    plan.softmax_kind = softmax->kind;\n','')
t=re.sub(r'    if \(type == DataType::kFloat32\) \{\n      plan.submit_route = &submit_softmax;\n    \} else \{', '    {', t)
t=t.replace('''      plan.workspace_submit_route =
          type == DataType::kFloat16 ? &submit_softmax_impl<simd::float16_t>
                                     : &submit_softmax_impl<simd::bfloat16_t>;''',
            '      plan.workspace_submit_route = &submit_softmax_impl<simd::float16_t>;')
# Remove log-output arithmetic conditionals without touching normal softmax.
t=t.replace('plan.softmax_kind == SoftmaxKind::kLogSoftmax','false')
write(name,t)

name='src/compute_provider_native/native_provider.cc';t=read(name)
t=t.replace('  case OperationKind::kSelect: {','  {')
t=cut(t,'  case OperationKind::kLayerNorm: {','  case OperationKind::kRmsNorm: {')
t=t.replace('  case OperationKind::kScatter:\n  case OperationKind::kConcat: {','  {')
t=t.replace('  case OperationKind::kRoPE:\n','')
write(name,t)

name='src/compute_provider_native/CMakeLists.txt';t=read(name)
t=cut(t,'hyle_add_fat_kernel(', '\0') if '\0' in t else t[:t.index('hyle_add_fat_kernel(')]
write(name,t.rstrip()+'\n')
for name in ('src/compute/rope_kernel_impl.h','src/compute/rope_kernels.h'):
    (ROOT/name).unlink()
print('Removed retired families/dispatch/private RoPE generation; retained arithmetic still needs D1 cleanup review.')
