from pathlib import Path
import re

root=Path.cwd()
p=root/'src/compute_provider_native/elementwise.cc';t=p.read_text()
for word in ('UNARY','BINARY'):
    enum='Unary' if word=='UNARY' else 'Binary'
    a=t.index('template <class Value>\nbool select_'+enum.lower()+'(')
    b=t.index('bool select_'+('binary' if word=='UNARY' else 'unary')+'(',a+len('template <class Value>\nbool select_'))
    # End at the next function template/type dispatcher, preserving its prefix.
    b=t.index('\n#undef HYLE_NATIVE_SELECT_'+word,a)
    end=t.index('\n}',b)+2
    segment=t[a:end]
    conditions=re.findall(r'if constexpr \((.*?)\) \{ HYLE_NATIVE_SELECT_'+word+r'\((k\w+)\); \}',segment)
    assert conditions
    body='template <class Value>\nbool select_'+enum.lower()+'('+enum+'Kind kind, NativePlan &plan) noexcept {\n'
    for condition,kind in conditions:
        body+='  if constexpr ('+condition+') {\n    if (kind == '+enum+'Kind::'+kind+') {\n'
        body+='      if constexpr (std::is_same_v<Value, float>)\n        plan.linear_elementwise_route = &'+enum.lower()+'_linear<'+enum+'Kind::'+kind+'>;\n'
        body+='      else\n        plan.linear_elementwise_route = &'+enum.lower()+'_narrow_linear<'+enum+'Kind::'+kind+', Value>;\n'
        body+='      plan.scalar_elementwise_route = &'+enum.lower()+'_scalar<'+enum+'Kind::'+kind+', Value>;\n      return true;\n    }\n  }\n'
    body+='  return false;\n}'
    t=t[:a]+body+t[end:]
p.write_text(t,encoding='utf-8')
p=root/'src/compute_provider_native/normalization.cc';t=p.read_text()
t=t.replace('values[index] = values[index] * inverse;','values[index] = (values[index] - 0.0F) * inverse;')
t=t.replace('    parallel_for_ranges(\n        plan, rows, &run_narrow_norm_range<Value, Scale>, &episode);',
            '  parallel_for_ranges(plan, rows, &run_narrow_norm_range<Value, Scale>, &episode);')
p.write_text(t,encoding='utf-8')
p=root/'src/compute_provider_native/native_provider.cc';t=p.read_text()
t=t.replace('  case OperationKind::kBinary:\n  {','  case OperationKind::kBinary: {')
t=t.replace('  case OperationKind::kGather:\n  {','  case OperationKind::kGather: {')
t=t.replace('  case OperationKind::kLayerNorm:\n','')
p.write_text(t,encoding='utf-8')
for p in (root/'src/compute_provider_native').glob('*'):
    if p.suffix in ('.cc','.h'):
        old=p.read_text();new='\n'.join(line.rstrip() for line in old.splitlines())+'\n'
        if new!=old:p.write_text(new,encoding='utf-8')
print('Retained arithmetic preserved; generated dispatch removes unneeded instantiations.')
