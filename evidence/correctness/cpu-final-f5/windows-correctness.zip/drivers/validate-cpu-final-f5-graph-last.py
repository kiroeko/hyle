exec(open('.scratch/validate-cpu-final-f5-first.py',encoding='utf-8').read().split("\nrun('configure-tests'")[0])
run('graph-last-fixture-build',['cmake','--build',build,'--target','hyle_graph_tests','--parallel','2'])
run('graph-last-fixture-tests',[build/'bin/hyle_graph_executable_test.exe',
    '--gtest_output=xml:'+str(out/'graph-migration-final.xml')])
