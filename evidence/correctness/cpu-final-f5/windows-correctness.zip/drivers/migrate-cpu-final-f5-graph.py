from pathlib import Path
p=Path('tests/graph/executable_test.cc')
t=p.read_text(encoding='utf-8')
t=t.replace('#include "../compute/native_context_fixture.h"','#include "cpu_context_fixture.h"')
t=t.replace('hyle::compute::test::native_context(', 'hyle::graph::test::cpu_context(')
t=t.replace('TEST(GraphCompile, NativeConcatEvaluatesSumAndRunsMultipleSpecializations)',
            'TEST(GraphCompile, MatureConcatEvaluatesSumAndRunsMultipleSpecializations)')
# Pure finite-budget and alias tests need the retained allocation-free leaf;
# their operation is a scheduling vehicle, not a retired-math qualification.
names=['LargeProviderConstraintMetadataFailuresRollBack','placeholder']
# Specific compile-only exact-domain counterexamples do not execute old Neg.
t=t.replace('builder.add(Unary{UnaryKind::kNeg}, spec, input)',
            'builder.add(Unary{UnaryKind::kExp}, spec, input)')
t=t.replace('builder.add(Unary{UnaryKind::kNeg}, spec(rows), input)',
            'builder.add(Unary{UnaryKind::kExp}, spec(rows), input)')
t=t.replace('builder.add(Unary{UnaryKind::kNeg}, fixed_input)',
            'builder.add(Unary{UnaryKind::kExp}, fixed_input)')
p.write_text(t,encoding='utf-8',newline='\n')
p=Path('tests/graph/region_provider_test.cc')
t=p.read_text(encoding='utf-8')
# Standalone mature leaves in region/fallback tests must use the same carrier
# as their make_context helper, rather than the withdrawn Native Neg domain.
t=t.replace('hyle::compute::native::provider()', 'hyle::compute::ggml_cpu::provider()')
p.write_text(t,encoding='utf-8',newline='\n')
