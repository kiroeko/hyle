import json
from pathlib import Path
p=Path('docs/implementation/module-status.json');raw=p.read_bytes()
data=json.loads(raw)
for item in data['modules']:
    if item['module'] in ('compute','compute_provider_native'):
        assert item['state']=='AUDITED' and item['record'].endswith('cpu-final-f5-retirement.md')
        item['state']='CANDIDATE'
        item['candidate']='507bad9698f9988d371c59e5661a69e4394c580a'
        item['summary']='F5 CANDIDATE：冗余14种与未需要dtype／variant已物理清退，21种必要机制和SIMD/Mem／原借入程序保留；产品固定507bad96，owning144项无skip通过。普通两入口／Graph旧夹具迁移／三平台及mixed三交付差异和终审仍待，不签goal完成。' if item['module']=='compute_provider_native' else 'F5 CANDIDATE：仅两份Compute私有RoPE生成文件删除，产品候选507bad96；runtime／公开API不变，Native owner owning144项通过，受影响消费与交付差异待验。'
eol='\r\n' if b'\r\n' in raw else '\n'
p.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').replace('\n',eol).encode('utf-8'))
