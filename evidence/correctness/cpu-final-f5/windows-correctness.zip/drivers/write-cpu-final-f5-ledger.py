import json, subprocess
from pathlib import Path
repo=Path.cwd()
source=repo/'docs/implementation/tasks/compute/cpu-final-f4-retirement-handoff.json'
handoff=json.loads(source.read_text(encoding='utf-8'))
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
domains={
 'Neg':'BF16', 'Exp':'F32/F16/BF16', 'Log':'F16', 'Sqrt':'F16/BF16',
 'Rsqrt':'F16/BF16', 'Tanh':'F16', 'Relu':'BF16', 'Silu':'F16',
 'Add':'F32', 'Subtract':'F32/F16', 'Divide':'F32/F16', 'Minimum':'F16',
 'ReduceMinimum':'F16', 'ReduceMaximum':'F16/BF16',
 'RmsNorm':'qualified BF16; named F32 declared-domain/strict-resource',
 'Softmax':'F16 Bool mask, non-log only',
 'GatedActivation':'F16 separate SiLU only',
 'Copy':'named dynamic/strict-resource; plain bit-storage mechanism',
 'Cast':'E4M3->F16; E5M2->BF16/E4M3/E5M2',
 'Fill':'F32 bit-write only',
 'Gather':'qualified requests; shared checked I32/I64 index and bit-storage mechanism',
}
entries=[]
for item in handoff['entries']:
 retired=item['handoff']=='F5_FINITE_RETIREMENT_AUDIT'
 entries.append({
  'operation':item['operation'],'source':'src/compute_provider_native/'+item['source'],
  'decision':'PHYSICALLY_RETIRED' if retired else 'RETAIN_NECESSARY_BRANCHES',
  'retained_domain':None if retired else domains[item['operation']],
  'qualified_win_requests':item['qualified_win_requests'],
  'mature_candidates_from_f4':item['mature_candidates'],
  'unique_demand':item['unique_demand'],
  'boundary':'Exact F4 WIN remains conditional; expert availability is not a WIN claim. Generic old Native-only strict domains of retired math are withdrawn. Managed unknown storage is not zero.'
 })
assert len(entries)==35 and sum(e['decision']=='PHYSICALLY_RETIRED' for e in entries)==14
assert sum(len(e['qualified_win_requests']) for e in entries)==41
assert not (repo/'src/compute/rope_kernel_impl.h').exists()
assert not (repo/'src/compute/rope_kernels.h').exists()
ledger={
 'schema':1,'scope':'F5 current source retirement, not whole goal terminal',
 'product_candidate':candidate,'baseline': '0d96c635040e70b1ee561e51e4cb1a74169870f0',
 'before_kinds':35,'physically_retired_kinds':14,'remaining_kinds':21,
 'qualified_semantic_kinds':20,'additional_named_unique_kind':'Copy',
 'removed_files':['src/compute/rope_kernel_impl.h','src/compute/rope_kernels.h'],
 'protected':['SIMD standalone','Mem standalone','View alias','original borrowed TorchAO/ATen/MLX/DS4 programs and codecs'],
 'edge_replacement':'Original ATen basic Unary/Binary only for non-dense, empty, rank0 or rank>4; F4 dense rank2 candidate set unchanged.',
 'entries':entries,
}
path=repo/'docs/implementation/tasks/compute/cpu-final-f5-source-ledger.json'
path.write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({k:v for k,v in ledger.items() if k not in ('entries','protected')})
