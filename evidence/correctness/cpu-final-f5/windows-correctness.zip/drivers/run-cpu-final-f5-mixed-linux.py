import subprocess
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f5/mixed-linux';out.mkdir(parents=True,exist_ok=True)
namespace={}
template=(repo/'.scratch/run-cpu-final-f5-linux-delivery.py').read_text(encoding='utf-8')
exec(template.split('\nscript=out/')[0],namespace)
code=namespace['remote_code']
code=code.replace('f5-result','f5-mixed-result')
code=code.replace("('f5-'+shape+'-", "('f5-mixed-'+shape+'-")
code=code.replace("for shape in ('static','shared'):","for shape in ('shared','static'):")
code=code.replace("'-DHYLE_COMPUTE_CUDA=OFF'", "'-DHYLE_COMPUTE_CUDA=ON'")
code=code.replace("'-DHYLE_COMPONENTS=compute,graph'", "'-DHYLE_COMPONENTS=compute,graph','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-13'")
code=code.replace("env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',CC='gcc-14',CXX='g++-14')", 
 "env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',CC='gcc-14',CXX='g++-14',CUDAHOSTCXX='/usr/bin/g++-13');env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env.pop('LD_LIBRARY_PATH',None)")
driver=out/'remote-driver.py';driver.write_text(code,encoding='utf-8')
with (out/'driver.log').open('wb') as stream:
    r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3',
        '/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/mixed-linux/remote-driver.py'],
        stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/'driver.log').read_text(errors='replace')[-5500:],flush=True)
copy="from pathlib import Path;import shutil;a=Path('/root/hyle-scratch/active-cpu-z/f5-mixed-result');b=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/mixed-linux');[shutil.copyfile(p,b/p.name) for p in a.iterdir() if p.is_file()]"
subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',copy],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
r.check_returncode()
