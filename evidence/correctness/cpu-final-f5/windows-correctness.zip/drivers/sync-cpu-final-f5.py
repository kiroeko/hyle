import ctypes,hashlib,json,shlex,subprocess,time
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f5'
flags={'creationflags':subprocess.CREATE_NO_WINDOW}
ctypes.windll.kernel32.SetErrorMode(32771)
candidate='507bad9698f9988d371c59e5661a69e4394c580a'
archive=out/'source.tar'
if not archive.exists():
    subprocess.run(['git','archive','--format=tar','--output='+str(archive),candidate],check=True,**flags)
sha=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
identity={'candidate':candidate,'archive_sha256':sha,'bytes':archive.stat().st_size,
    'canonical':'Windows immutable Git source; all remote copies disposable.'}
(out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
code=r'''
import hashlib,json,os,pathlib,subprocess,tarfile
root=pathlib.Path(ROOT).resolve();source=pathlib.Path(SOURCE).resolve()
assert source.is_relative_to(root) and source!=root and source.is_dir() and not source.is_symlink()
live=subprocess.check_output(['ps','-eo','pid=,args='],text=True)
assert not any(str(root) in line and any(x in line for x in ('cmake --build','ctest --test-dir','ninja -C'))
 for line in live.splitlines() if line.strip().split(None,1)[0]!=str(os.getpid()))
archive=pathlib.Path(ARCHIVE)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==SHA
names=set();updated=[];removed=[]
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  if member.isdir():continue
  assert member.isfile(),member.name
  path=(source/member.name).resolve();assert path.is_relative_to(source)
  names.add(member.name);data=tar.extractfile(member).read()
  if not path.exists() or path.read_bytes()!=data:
   path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);updated.append(member.name)
  if member.mode & 0o111:path.chmod(path.stat().st_mode|0o111)
 for directory in ('src','include','tests','cmake','third_party','scripts','samples','bench','docs'):
  for path in (source/directory).rglob('*'):
   if path.is_file() and path.relative_to(source).as_posix() not in names:
    assert path.resolve().is_relative_to(source) and not path.is_symlink()
    path.unlink();removed.append(path.relative_to(source).as_posix())
result={'candidate':CANDIDATE,'archive_sha256':SHA,'updated':updated,'removed':removed,
        'canonical':'Windows immutable archive; forward sync only.'}
(root/'f5-sync.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'updated':len(updated),'removed':removed,'candidate':CANDIDATE}))
'''
consumer=out/'delivery-consumer'
ssh='C:/Windows/System32/OpenSSH/ssh.exe';scp='C:/Windows/System32/OpenSSH/scp.exe'
records=json.loads((out/'sync-receipt.json').read_text()) if (out/'sync-receipt.json').exists() else []
def call(name,args,timeout=55):
    start=time.monotonic()
    r=subprocess.run(args,capture_output=True,timeout=timeout,**flags)
    log=out/(str(len(records)+1)+'-'+name+'.log')
    log.write_bytes(r.stdout+r.stderr)
    records.append({'name':name,'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name})
    (out/'sync-receipt.json').write_text(json.dumps(records,indent=2)+'\n')
    print(records[-1],flush=True)
    if r.returncode:print((r.stdout+r.stderr).decode(errors='replace')[-4000:]);r.check_returncode()
for platform in ('mac','linux'):
    root='/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8' if platform=='mac' else '/root/hyle-scratch/active-cpu-z'
    source=root+('/hyle-0.1.0-source' if platform=='mac' else '/source')
    target=root+'/f5-source.tar' if platform=='mac' else '/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/source.tar'
    if platform=='mac':
        call('mac-transfer',[scp,'-q','-o','BatchMode=yes',str(archive),'kiro@172.22.10.198:'+target])
    program=code
    for key,value in [('ROOT',root),('SOURCE',source),('ARCHIVE',target),('SHA',sha),('CANDIDATE',candidate)]:
        program=program.replace(key,repr(value))
    call(platform+'-sync',([ssh,'-o','BatchMode=yes','kiro@172.22.10.198','python3 -c '+shlex.quote(program)]
         if platform=='mac' else ['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',program]))
    if platform=='mac':
        call('mac-consumer-mkdir',[ssh,'-o','BatchMode=yes','kiro@172.22.10.198','mkdir -p '+root+'/f5-consumer'])
        for name in ('CMakeLists.txt','main.cc'):
            call('mac-consumer-'+name,[scp,'-q','-o','BatchMode=yes',str(consumer/name),
                'kiro@172.22.10.198:'+root+'/f5-consumer/'+name])
        call('mac-sync-receipt',[scp,'-q','-o','BatchMode=yes','kiro@172.22.10.198:'+root+'/f5-sync.json',str(out/'mac-sync.json')])
    else:
        c="from pathlib import Path;import shutil;root=Path('"+root+"');d=root/'f5-consumer';d.mkdir(exist_ok=True);[shutil.copyfile(Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/delivery-consumer')/n,d/n) for n in ('CMakeLists.txt','main.cc')];shutil.copyfile(root/'f5-sync.json','/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/linux-sync.json')"
        call('linux-consumer',['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',c])
