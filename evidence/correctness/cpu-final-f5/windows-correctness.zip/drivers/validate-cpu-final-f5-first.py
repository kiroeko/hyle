exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-final-f5';records=json.loads((out/'receipt.json').read_text())
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
run('configure-tests',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build-native-tests',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','--parallel','2'])
run('mature-and-retirement-tests',[build/'bin/hyle_compute_provider_native_test.exe','--gtest_filter=CpuNativeRetirement.*:AtenCpu*.*:NativeProviderShape.*:NativeMetadataOwner.*:NativeTransform.*',
     '--gtest_output=xml:'+str(out/'first.xml')])
