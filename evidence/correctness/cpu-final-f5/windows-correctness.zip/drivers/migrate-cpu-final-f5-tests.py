from pathlib import Path
import subprocess
import re

ROOT=Path.cwd()
def get(name):return (ROOT/name).read_text()
def save(name,text):
    p=ROOT/name;old=subprocess.check_output(['git','show','HEAD:'+name])
    p.write_bytes(text.replace('\n','\r\n').encode() if b'\r\n' in old else text.encode())
def mature(t):
    return t.replace('hyle::compute::test::native_context()',
        'hyle::compute::Context::create(hyle::compute::cpu::device(), hyle::compute::aten_cpu::provider())')
def replace_test(t,suite,name,transform):
    marker='TEST('+suite+', '+name+')';a=t.index(marker);opening=t.index('{',a);level=0
    for i in range(opening,len(t)):
        if t[i]=='{':level+=1
        elif t[i]=='}':
            level-=1
            if level==0:return t[:a]+transform(t[a:i+1])+t[i+1:]
    raise AssertionError(marker)

name='tests/compute_provider_native/cast_test.cc';t=mature(get(name)).replace('TEST(NativeCast,','TEST(MatureCast,')
# Preserve native verification of the four retained dtype pairs separately.
marker='TEST(MatureCast, CoversCompleteInferenceStorageConversionGraph)'
extra='''TEST(NativeCast, ReplaysAllFourQualifiedStoragePairs) {
  expect_dense_cast<hyle::simd::float8_e4m3_t, hyle::simd::float16_t>();
  expect_dense_cast<hyle::simd::float8_e5m2_t, hyle::simd::bfloat16_t>();
  expect_dense_cast<hyle::simd::float8_e5m2_t, hyle::simd::float8_e4m3_t>();
  expect_dense_cast<hyle::simd::float8_e5m2_t, hyle::simd::float8_e5m2_t>();
}

'''
# Parameterize the existing independent cast oracle rather than duplicating it.
t=t.replace('template <class Source, class Destination> void expect_dense_cast() {',
            'template <class Source, class Destination> void expect_dense_cast(bool native = false) {')
t=t.replace('  auto context = hyle::compute::Context::create(hyle::compute::cpu::device(), hyle::compute::aten_cpu::provider()).value();',
'''  auto context = (native ? hyle::compute::test::native_context()
                        : hyle::compute::Context::create(hyle::compute::cpu::device(), hyle::compute::aten_cpu::provider())).value();''',1)
extra=extra.replace('>();','>(true);');t=t.replace(marker,extra+marker);save(name,t)

name='tests/compute_provider_native/indexing_test.cc';t=get(name)
for test in ('ScatterAssignsOrAddsAndSupportsExactSourceAlias','ConcatenatesVariadicDenseInputsAlongMiddleAxis'):
    t=replace_test(t,'NativeIndexing',test,lambda text:mature(text).replace('TEST(NativeIndexing,','TEST(MatureIndexing,'))
save(name,t)

name='tests/compute_provider_native/reduction_test.cc';t=mature(get(name)).replace('TEST(NativeReduction,','TEST(MatureReduction,')
# Invalid accumulation and native explicit refusal remain exercised in retirement_test.
save(name,t)

name='tests/compute_provider_native/normalization_test.cc';t=mature(get(name))
t=t.replace('TEST(NativeLayerNorm,','TEST(MatureLayerNorm,').replace('TEST(NativeNormalization,','TEST(MatureNormalization,')
# Fan-out is a retained native RMS mechanism, not a retired LayerNorm expectation.
t=t.replace('TEST(MatureLayerNorm, PinsExecutorAndUsesOneBoundedSynchronousFanOut)',
            'TEST(NativeRmsNorm, PinsExecutorAndUsesOneBoundedSynchronousFanOut)')
t=replace_test(t,'NativeRmsNorm','PinsExecutorAndUsesOneBoundedSynchronousFanOut',
    lambda text:text.replace('LayerNorm{}','hyle::compute::RmsNorm{}'))
save(name,t)

name='tests/compute_provider_native/matmul_gated_test.cc';t=get(name)
t=t.replace('if (type != DataType::kFloat16 || kind != GatedActivationKind::kSilu) {',
            'if (type != DataType::kFloat16 || kind != GatedActivationKind::kSilu || is_packed) {')
save(name,t)

name='tests/compute_provider_native/transformer_test.cc';t=get(name)
for test in ('ExecutesBothRopeLayoutsAndPreservesTheTail','RopeExercisesVectorBlocksAndPairTail',
             'RopeMaterializesPlainStridedInputs','SoftmaxSupportsBroadcastMasksScaleAndExactAlias',
             'LogSoftmaxSupportsANonTrailingAxis','SoftmaxSupportsAdditiveMasksAndUndefinedRows'):
    t=replace_test(t,'NativeTransformer',test,lambda text:mature(text).replace('TEST(NativeTransformer,','TEST(MatureTransformer,'))
# Keep the original independent workspace/mask numeric oracle only for the actual survivor.
t=t.replace('for (const auto kind : {SoftmaxKind::kSoftmax, SoftmaxKind::kLogSoftmax}) {',
            'for (const auto kind : {SoftmaxKind::kSoftmax}) {')
t=t.replace('''    for (const auto mask :
         {MaskKind::kNone, MaskKind::kBoolean, MaskKind::kAdditive}) {
      expect_half_softmax<hyle::simd::float16_t>(strided, mask);
      expect_half_softmax<hyle::simd::bfloat16_t>(strided, mask);
    }''','''    expect_half_softmax<hyle::simd::float16_t>(strided, MaskKind::kBoolean);''')
# Empty survivor still includes the required Bool port, not the retired unmasked variant.
t=t.replace('  auto softmax = hyle::compute::prepare(context, Softmax{}, desc).value();',
'''  const auto boolean = TensorDesc::dense(DataType::kBool, std::array<std::int64_t, 2>{0, 129}).value();
  auto softmax = hyle::compute::prepare(context, Softmax{.mask = MaskKind::kBoolean}, desc, boolean).value();''')
t=t.replace('  ASSERT_TRUE(invocation.submit(queue, input, output)->wait().ok());\n}\n\nTEST(NativeTransformer, EmptyHalfWorkload',
'''  const auto mask = ConstTensorView::create(boolean, empty.view()).value();
  ASSERT_TRUE(invocation.submit(queue, input, mask, output)->wait().ok());
}

TEST(NativeTransformer, EmptyHalfWorkload''')
t=t.replace('  expect_half_empty_transformer<hyle::simd::bfloat16_t>();\n','')
save(name,t)
print('Migrated retired Cast/Index/Reduce/Norm/Transformer consumers; retained native gate/mask/storage oracles remain.')
