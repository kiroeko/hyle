exec(open('.scratch/migrate-cpu-final-f5-tests.py',encoding='utf-8').read().split("name='tests/compute_provider_native/cast_test.cc'")[0])
name='tests/compute_provider_native/elementwise_test.cc';t=get(name)
t=t.replace('''    if (kind == UnaryKind::kGelu || kind == UnaryKind::kGeluTanh ||
        kind == UnaryKind::kSilu) {''','''    if (kind != UnaryKind::kExp) {''')
# The exact in-place survivor is Exp; neg F32 has retired from Native.
t=replace_test(t,'NativeElementwise','ExecutesRetainedUnaryModesAndDeclinesRetiredDomains',
    lambda text:text.replace('Unary{UnaryKind::kNeg}', 'Unary{UnaryKind::kExp}').replace('EXPECT_FLOAT_EQ(actual[index], -values[index]);','EXPECT_NEAR(actual[index], std::exp(values[index]), 3e-5F);'))
t=replace_test(t,'NativeElementwise','SoftplusHasStableTailsSpecialValuesAndExactAlias',
    lambda text:mature(text).replace('TEST(NativeElementwise,','TEST(MatureElementwise,'))
old='''    if (kind == UnaryKind::kGelu || kind == UnaryKind::kGeluTanh) {'''
new='''    const bool retained = std::is_same_v<Value, hyle::simd::float16_t>
        ? (kind == UnaryKind::kExp || kind == UnaryKind::kLog || kind == UnaryKind::kSqrt ||
           kind == UnaryKind::kRsqrt || kind == UnaryKind::kTanh || kind == UnaryKind::kSilu)
        : (kind == UnaryKind::kNeg || kind == UnaryKind::kExp || kind == UnaryKind::kSqrt ||
           kind == UnaryKind::kRsqrt || kind == UnaryKind::kRelu);
    if (!retained) {'''
assert old in t;t=t.replace(old,new)
needle='''    auto prepared =
        hyle::compute::prepare(context, Binary{kind}, description, description);
    ASSERT_TRUE(prepared.has_value());'''
replacement='''    auto prepared =
        hyle::compute::prepare(context, Binary{kind}, description, description);
    if (!std::is_same_v<Value, hyle::simd::float16_t> ||
        (kind != BinaryKind::kSubtract && kind != BinaryKind::kDivide && kind != BinaryKind::kMinimum)) {
      ASSERT_FALSE(prepared); EXPECT_TRUE(prepared.error().IsUnimplemented()); continue;
    }
    ASSERT_TRUE(prepared.has_value());'''
assert needle in t;t=t.replace(needle,replacement,1)
# Existing independent odd-stride/broadcast oracle moves to original ATen edge program.
a=t.index('template <class Value> void expect_half_strided_broadcast()');b=t.index('TEST(NativeElementwise, HalfStorageSupportsOddByteStridesAndBroadcast)',a)
t=t[:a]+mature(t[a:b])+t[b:]
t=t.replace('TEST(NativeElementwise, HalfStorageSupportsOddByteStridesAndBroadcast)',
            'TEST(MatureElementwise, HalfStorageSupportsOddByteStridesAndBroadcast)')
for test in ('MaterializesUnalignedStridedUnary','BroadcastsSelectWithoutChangingBranchBits',
             'SupportsDenseSelectAliasingABranch','ExecutesDenseF32SelectAcrossVectorBlocksAndTail',
             'ExecutesZeroElementFamiliesWithoutTouchingStorage'):
    t=replace_test(t,'NativeElementwise',test,lambda text:mature(text).replace('TEST(NativeElementwise,','TEST(MatureElementwise,'))
# Dense F32 arithmetic keeps only the actual survivor branches.
t=replace_test(t,'NativeElementwise','ExecutesEveryDenseBinaryModeAndAliasesSecondInput',
    lambda text:text.replace('    ASSERT_TRUE(prepared.has_value());',
        '    if (kind != BinaryKind::kAdd && kind != BinaryKind::kSubtract && kind != BinaryKind::kDivide) { ASSERT_FALSE(prepared); EXPECT_TRUE(prepared.error().IsUnimplemented()); continue; }\n    ASSERT_TRUE(prepared.has_value());',1))
save(name,t)
print('Migrated retired elementwise consumers and retained only actual Native kind/dtype expectations.')
