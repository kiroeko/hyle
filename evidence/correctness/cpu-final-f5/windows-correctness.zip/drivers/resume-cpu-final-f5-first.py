exec(open('.scratch/validate-cpu-final-f5-first.py',encoding='utf-8').read().split("\nrun('configure-tests'")[0])
run('relink-native-tests',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','--parallel','2'])
run('mature-and-retirement-tests',[build/'bin/hyle_compute_provider_native_test.exe','--gtest_filter=CpuNativeRetirement.*:AtenCpu*.*:NativeProviderShape.*:NativeMetadataOwner.*:NativeTransform.*:MatureTransform.*','--gtest_output=xml:'+str(out/'first-corrected.xml')])
