from pathlib import Path
import shutil
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f5/delivery-consumer'
out.mkdir(parents=True,exist_ok=True)
original=repo/'.scratch/validation/cpu-final-f4/delivery-consumer'
shutil.copyfile(original/'CMakeLists.txt',out/'CMakeLists.txt')
t=(original/'main.cc').read_text(encoding='utf-8')
needle='  int checks=0;\n'
addition=r'''
  // Actual retired-provider edges in both ordinary entry points. The byte
  // stride deliberately cannot be represented by ggml native tensor strides.
  for (bool graph : {false, true}) {
    const auto odd=c::TensorDesc::strided_bytes(D::kFloat32,
        std::array<std::int64_t,2>{2,3},std::array<std::int64_t,2>{13,4}).value();
    const std::array<float,6> source{-1,-2,-3,-4,-5,-6};
    std::vector<std::byte> payload(25);
    for(std::size_t i=0;i<source.size();++i)
      std::memcpy(payload.data()+(i/3)*13+(i%3)*4,&source[i],4);
    const auto check=[&](const std::vector<std::byte>& actual,auto reference) {
      require(actual.size()==source.size()*sizeof(float));
      for(std::size_t i=0;i<source.size();++i) {
        float value;std::memcpy(&value,actual.data()+i*4,4);
        require(std::abs(value-reference(source[i]))<1e-6f);
      }
    };
    check(execute(graph,c::Unary{c::UnaryKind::kAbs},{odd},{payload}),
          [](float x){return std::abs(x);});++checks;
    check(execute(graph,c::Unary{c::UnaryKind::kNeg},{odd},{payload}),
          [](float x){return -x;});++checks;
    check(execute(graph,c::Binary{c::BinaryKind::kMultiply},
          {odd,dense(D::kFloat32,{})},{payload,bytes(std::vector<float>{2})}),
          [](float x){return x*2;});++checks;
    // Retired dense primitive and stable original program still bind without
    // provider ordering from the consumer or a hardware profile.
    const auto result=execute(graph,c::Unary{c::UnaryKind::kSoftplus},
        {dense(D::kFloat32,{2,3})},{bytes(std::vector<float>(source.begin(),source.end()))});
    check(result,[](float x){return std::log1p(std::exp(x));});++checks;
  }
'''
assert t.count(needle)==1
t=t.replace(needle,needle+addition)
(out/'main.cc').write_text(t,encoding='utf-8')
print('F5 delivery consumer: original 43 cold requests in 2 contexts, 40 original numeric/replay checks, 8 actual mature edge checks.')
