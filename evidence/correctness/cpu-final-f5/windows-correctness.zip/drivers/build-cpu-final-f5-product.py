exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-final-f5';out.mkdir(parents=True,exist_ok=True)
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
run('product-build',['cmake','--build',build,'--target','hyle_compute_provider_native','--parallel','2'])
