from pathlib import Path
p=Path('tests/graph/executable_test.cc');t=p.read_text(encoding='utf-8')
a=t.index('TEST(GraphCompilationStorage,\n     AccountsAllocatorRequestsWithoutPersistentDoubleCharge)')
b=t.index('TEST(GraphInvocationStorage,\n     VariantsShareQuotaAndEscapedSignatureRetainsOwner)',a)
part=t[a:b];assert part.count('make_transformer_graph(2, 4, 4)')==6
part=part.replace('make_transformer_graph(2, 4, 4)','make_resource_graph()')
t=t[:a]+part+t[b:]
p.write_text(t,encoding='utf-8',newline='\n')
