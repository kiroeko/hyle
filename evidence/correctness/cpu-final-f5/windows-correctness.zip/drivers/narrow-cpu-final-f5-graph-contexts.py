import re
from pathlib import Path
p=Path('tests/graph/executable_test.cc');t=p.read_text(encoding='utf-8')
points=[match.start() for match in re.finditer(r'^TEST\(',t,re.MULTILINE)]+[len(t)]
pieces=[t[:points[0]]];restored=[];mature=[]
for first,last in zip(points,points[1:]):
    block=t[first:last]
    title=block[:block.index('{')].replace('\n',' ').strip()
    needs_mature=any(term in block for term in (
        'UnaryKind::kNeg','UnaryKind::kAbs','make_transformer_graph(',
        'make_branch_graph(','hyle::compute::Concat','MatMul{}',
        'ScaledDotProductAttention{','hyle::compute::Copy{}'))
    if 'ProviderPolicyAllocationsRollBackAndDoNotReachReplay' in title:
        needs_mature=False
    if not needs_mature:
        if 'hyle::graph::test::cpu_context(' in block:restored.append(title)
        block=block.replace('hyle::graph::test::cpu_context(', 'hyle::compute::test::native_context(')
    else:mature.append(title)
    pieces.append(block)
p.write_text(''.join(pieces),encoding='utf-8',newline='\n')
print({'native_resource_or_mechanism_contexts_restored':len(restored),'mature_context_tests':len(mature)})
