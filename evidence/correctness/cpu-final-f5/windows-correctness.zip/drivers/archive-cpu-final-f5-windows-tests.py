import hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path.cwd();raw=repo/'.scratch/validation/cpu-final-f5';out=repo/'evidence/correctness/cpu-final-f5'
out.mkdir(parents=True,exist_ok=True)
batch=ET.parse(raw/'consumer-batch.xml').getroot();programs=[]
last_test=(repo/'.scratch/build-compute-v2-dev/Testing/Temporary/LastTest.log').read_text(encoding='utf-8',errors='replace')
for case in batch.findall('testcase'):
    output=case.findtext('system-out','')
    marker='Testing: '+case.get('name')+'\n'
    if marker in last_test:
        section=last_test.split(marker,1)[1]
        output=section.split('Test time =',1)[0]
    totals=re.findall(r'\[==========\] (\d+) tests? from (\d+) test suites? ran',output)
    passed=re.findall(r'\[  PASSED  \] (\d+) tests?',output)
    skipped=re.findall(r'\[  SKIPPED \] (\d+) tests?',output)
    programs.append({'program':case.get('name'),'ctest_status':case.get('status'),
        'initial_failure':case.find('failure') is not None,
        'gtest_cases':int(totals[-1][0]) if totals else None,
        'gtest_passed':int(passed[-1]) if passed else None,
        'gtest_skipped':int(skipped[-1]) if skipped else 0})
corrections=[]
for name in ('owning-migration-corrected.xml','ordinary-select-policy-corrected.xml','graph-migration-final.xml'):
    root=ET.parse(raw/name).getroot();cases=root.findall('.//testcase')
    assert not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
    corrections.append({'xml':name,'tests':len(cases),'failures':0,'skips':0,'sha256':hashlib.sha256((raw/name).read_bytes()).hexdigest()})
bundle=out/'windows-correctness.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    archive.write(repo/'.scratch/build-compute-v2-dev/Testing/Temporary/LastTest.log',
                  'raw/complete-ctest-last-test.log')
    for path in raw.iterdir():
        if path.is_file() and path.suffix in ('.json','.xml','.log') and path.name!='source.tar':
            archive.write(path,'raw/'+path.name)
    for directory in ('tests/compute_provider_native','tests/graph','tests/graph_route_cpu'):
        for path in (repo/directory).iterdir():
            if path.is_file():archive.write(path,'canonical-tests/'+path.relative_to(repo).as_posix())
    for path in repo.glob('.scratch/*cpu-final-f5*.py'):
        archive.write(path,'drivers/'+path.name)
receipt={'scope':'F5 Windows owning/ordinary/generic Graph correctness; platform delivery and terminal are still pending',
 'product_candidate':'507bad9698f9988d371c59e5661a69e4394c580a',
 'test_candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'original_batch_verdict':'FAIL retained; generic retired-math fixtures and two stale Select provider identities',
 'original_programs':programs,'successful_correction_receipts':corrections,
 'reuse':'Successful unchanged cases in the original complete batch are retained; only affected Graph fixtures/2 identity expectations rerun.',
 'p1':'NOT_RUN; retained mathematics/default rule qualification unchanged',
 'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()}
(out/'windows-correctness-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'programs':len(programs),'corrections':[(x['xml'],x['tests']) for x in corrections],
       'bundle_bytes':bundle.stat().st_size,'program_counts':programs})
