from pathlib import Path
import subprocess

ROOT=Path.cwd()
def braces_end(t,p):
    level=0
    for i in range(p,len(t)):
        if t[i]=='{':level+=1
        elif t[i]=='}':
            level-=1
            if level==0:return i+1
    raise AssertionError
def save(p,t):
    previous=subprocess.check_output(['git','show','HEAD:'+p.relative_to(ROOT).as_posix()])
    t='\n'.join(line.rstrip() for line in t.splitlines())+'\n'
    p.write_bytes(t.replace('\n','\r\n').encode() if b'\r\n' in previous else t.encode())
p=ROOT/'src/compute_provider_native/reduction.cc';t=p.read_text()
start=t.index('  if constexpr (!std::is_same_v<Value, float>) {')
opening=t.index('{',start);end=braces_end(t,opening);end_else=braces_end(t,t.index('{',end))
t=t[:start]+t[opening+1:end-1]+t[end_else:]
# Min/Max template uses narrow original kernels; retire the obsolete float32-only path.
save(p,t)
p=ROOT/'src/compute_provider_native/transformer.cc';t=p.read_text()
a=t.index('float load_f32(');b=t.index('template <class Value>',a);t=t[:a]+t[b:]
save(p,t)
p=ROOT/'src/compute_provider_native/normalization.cc';t=p.read_text()
t=t.replace('    return scale_f32 ?', '  return scale_f32 ?').replace('\n                     : &submit_normalization', '\n                   : &submit_normalization')
save(p,t)
p=ROOT/'src/compute_provider_native/transform.cc';t=p.read_text()
a=t.index('  switch (element_size) {');b=braces_end(t,t.index('{',a))
t=t[:a]+'''  std::fill_n(reinterpret_cast<std::uint32_t *>(writable->data()), elements,
              static_cast<std::uint32_t>(plan.scalar_bits));'''+t[b:]
t=t.replace('  const std::size_t element_size = plan.parameters[1];\n','')
needle='    const Fill *fill = operation.get_if<Fill>();'
t=t.replace(needle,needle+'''
    if (fill->output_type != DataType::kFloat32)
      return Status::Unimplemented("native Fill retains qualified F32 storage only");''')
save(p,t)
print('Trimmed dead execution branches and obsolete helpers; no changes to retained numeric equations.')
