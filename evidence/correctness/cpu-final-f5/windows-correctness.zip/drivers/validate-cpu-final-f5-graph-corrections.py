exec(open('.scratch/validate-cpu-final-f5-first.py',encoding='utf-8').read().split("\nrun('configure-tests'")[0])
env['HYLE_D5_QWEN35_FIXTURE']=str(repo/'.scratch/d5-qwen35-six-profile-fixture')
run('graph-correction-build',['cmake','--build',build,'--target',
    'hyle_graph_tests','hyle_graph_route_cpu_tests','--parallel','2'])
run('ordinary-select-policy-correction',[build/'bin/hyle_graph_route_cpu_test.exe',
    '--gtest_filter=CpuGraph.*','--gtest_output=xml:'+str(out/'ordinary-select-policy-corrected.xml')])
run('graph-fixture-corrections',[build/'bin/hyle_graph_executable_test.exe',
    '--gtest_output=xml:'+str(out/'graph-migration-corrected.xml')])
