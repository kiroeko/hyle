from pathlib import Path
repo=Path.cwd()
mac=(repo/'.scratch/run-cpu-final-f4-mac-delivery.py').read_text(encoding='utf-8')
mac=mac.replace('cpu-final-f4/delivery-mac','cpu-final-f5/delivery-mac')
mac=mac.replace('cpu-final-f4/mac-sync.json','cpu-final-f5/mac-sync.json')
mac=mac.replace('/f4-','/f5-').replace('/f4-consumer','/f5-consumer')
mac=mac.replace("remote+'/f5-consumer'", "remote+'/f4-consumer'")
mac=mac.replace("remote+'/f5-source-consumer'", "remote+'/f4-source-consumer'")
mac=mac.replace("remote+'/f5-source-consumer/cpu_final_delivery'", "remote+'/f4-source-consumer/cpu_final_delivery'")
mac=mac.replace("run('source-build',['cmake','--build',remote+'/source-build','--parallel','2'])\n",'')
needle="run('machine',['sh','-c','sysctl -n hw.model; sw_vers; clang++ --version; cmake --version'])"
copy="from pathlib import Path;import shutil;a=Path("+repr('/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8/f5-consumer')+");b=a.with_name('f4-consumer');assert b.is_dir();[shutil.copyfile(a/n,b/n) for n in ('CMakeLists.txt','main.cc')]"
mac=mac.replace(needle,needle+"\nrun('reuse-source-consumer-cache',['python3','-c',"+repr(copy)+"])")
# Preserve receipts across observed failures; do not replay successful steps.
mac=mac.replace('records=[]',"records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []")
mac=mac.replace('for shape in (\'static\',\'shared\'):', 'for shape in (\'shared\',\'static\'):')
(repo/'.scratch/run-cpu-final-f5-mac-delivery.py').write_text(mac,encoding='utf-8')

linux=(repo/'.scratch/run-cpu-final-f4-linux.py').read_text(encoding='utf-8')
linux=linux.replace('cpu-final-f4/delivery-linux','cpu-final-f5/delivery-linux')
linux=linux.replace('cpu-final-f4/source.tar','cpu-final-f5/source.tar')
linux=linux.replace('cpu-final-f4/delivery-consumer','cpu-final-f5/delivery-consumer')
linux=linux.replace("candidate='64304e9e691cc78d2ead05a7c88fa485f9b8adc4'", "candidate='507bad9698f9988d371c59e5661a69e4394c580a'")
linux=linux.replace('f4-result','f5-result').replace('f4-consumer','f5-consumer').replace('f4-overlay','f5-overlay')
linux=linux.replace('cpu_f4','cpu_f5').replace("('f4-'", "('f5-'")
linux=linux.replace('target_link_libraries(cpu_f5_source_delivery PRIVATE hyle::compute hyle::graph)\\\\n',
                    'target_link_libraries(cpu_f5_source_delivery PRIVATE hyle::compute hyle::graph)\\\\nhyle_stage_runtime_dependencies(cpu_f5_source_delivery)\\\\n')
# Canonical sources already synchronized from this exact SHA, no second
# archive overwrite or timestamp churn is necessary.
a=linux.index('names=set();updated=[];removed=[]')
b=linux.index("out=root/'f5-result'",a)
linux=linux[:a]+"updated=[];removed=[]\n"+linux[b:]
linux=linux.replace("env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')", "env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',CC='gcc-14',CXX='g++-14')")
linux=linux.replace("for shape in ('static','shared'):","for shape in ('static','shared'):")
(repo/'.scratch/run-cpu-final-f5-linux-delivery.py').write_text(linux,encoding='utf-8')
print('Prepared cached Mac/Linux CPU-only source/static/shared delta drivers. Heavy execution remains serial.')
