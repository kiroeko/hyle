import hashlib,json,zipfile
from pathlib import Path
repo=Path.cwd();base=repo/'.scratch/validation/cpu-final-f5';out=repo/'evidence/correctness/cpu-final-f5'
out.mkdir(parents=True,exist_ok=True)
for platform in ('windows','mac','linux'):
    raw=base/('delivery-'+platform)
    if not (raw/'receipt.json').exists():continue
    records=json.loads((raw/'receipt.json').read_text())
    expected=('static-consumer-qualified' if platform=='windows' else 'source-consumer-run' if platform=='mac' else 'shared-export')
    result_key='returncode' if platform=='windows' else 'exit'
    if records[-1]['name']!=expected or records[-1][result_key]!=0:continue
    bundle=out/(platform+'-delivery.zip')
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in raw.iterdir():
            if path.is_file():archive.write(path,'raw/'+path.name)
        for path in (base/'delivery-consumer').iterdir():
            if path.is_file():archive.write(path,'consumer/'+path.name)
        for pattern in ('*cpu-final-f5*delivery*.py','*cpu-final-f5*consumer*.py'):
            for path in repo.glob('.scratch/'+pattern):archive.write(path,'drivers/'+path.name)
    receipt={'scope':'F5 CPU-only source/static/shared retirement and mature edge delta',
        'platform':platform,'product_candidate':'507bad9698f9988d371c59e5661a69e4394c580a',
        'checks':'43 exact rule requests in both contexts, 48 numeric/replay checks including 8 mature edge checks',
        'qualified_win':'Windows static singleton CPU2 only; other conditions use engineering defaults',
        'successful_steps':sum(r[result_key]==0 for r in records),
        'original_failures_retained':sum(r[result_key]!=0 for r in records),
        'steps':records,'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()}
    (out/(platform+'-delivery-receipt.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print({'platform':platform,'successful_steps':receipt['successful_steps'],'original_failures_retained':receipt['original_failures_retained'],'bundle_bytes':bundle.stat().st_size})
