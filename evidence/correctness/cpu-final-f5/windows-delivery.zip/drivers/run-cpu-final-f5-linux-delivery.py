import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path.cwd()
out=ROOT/'.scratch/validation/cpu-final-f5/delivery-linux'
out.mkdir(parents=True,exist_ok=True)
archive=out.parent/'source.tar'
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
candidate='64b454fa23404d26bead60d495eda9475c802e32'
remote_code='''import hashlib,json,pathlib,shutil,subprocess,tarfile,time,os
root=pathlib.Path('/root/hyle-scratch/active-cpu-z').resolve()
source=(root/'source').resolve()
assert source.parent==root and source.is_dir() and not source.is_symlink()
live=subprocess.check_output(['ps','-eo','pid=,args='],text=True)
assert not any(str(root) in line and any(term in line for term in ('cmake --build','ctest --test-dir','ninja -C')) for line in live.splitlines() if line.strip().split(None,1)[0]!=str(os.getpid()))
archive=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/source.tar')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==SHA
delta=json.loads(pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/cleanup-delta.json').read_text());assert delta['product_candidate']==CANDIDATE
for name,digest in delta['files'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
updated=[];removed=[]
out=root/'f5-result';out.mkdir(exist_ok=True)
(out/'source-sync.json').write_text(json.dumps({'candidate':CANDIDATE,'base_archive_candidate':'507bad9698f9988d371c59e5661a69e4394c580a','archive_sha256':SHA,'equivalent_product_delta':delta,'updated':updated,'removed':removed,'mirror_only':True},indent=2)+'\\n')
consumer=root/'f5-consumer';consumer.mkdir(exist_ok=True)
original=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/delivery-consumer')
for name in ('CMakeLists.txt','main.cc'):shutil.copyfile(original/name,consumer/name)
overlay=root/'f5-overlay.cmake'
overlay.write_text('function(cpu_f5_hook)\\nadd_executable(cpu_f5_source_delivery "'+str(consumer/'main.cc')+'")\\ntarget_compile_features(cpu_f5_source_delivery PRIVATE cxx_std_23)\\ntarget_link_libraries(cpu_f5_source_delivery PRIVATE hyle::compute hyle::graph)\\nhyle_stage_runtime_dependencies(cpu_f5_source_delivery)\\nendfunction()\\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\\ncmake_language(DEFER CALL cpu_f5_hook)\\nendif()\\n')
records=[];env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',CC='gcc-14',CXX='g++-14')
def run(name,args):
 start=time.monotonic();args=list(map(str,args));log=out/(str(len(records)+1)+'-'+name+'.log')
 with log.open('wb') as stream:result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
 records.append({'name':name,'candidate':CANDIDATE,'args':args,'exit':result.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name})
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\\n');print(records[-1],flush=True)
 if result.returncode:print(log.read_text(errors='replace')[-6000:],flush=True);result.check_returncode()
run('machine',['sh','-c','uname -a; g++-14 --version; cmake --version'])
build=root/'build'
for shape in ('static','shared'):
 prefix=root/('f5-'+shape+'-staging');relocated=root/('f5-'+shape+'-relocated')
 assert not prefix.exists() and not relocated.exists()
 run(shape+'-configure',['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPONENTS=compute,graph','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=AUTO','-DHYLE_COMPUTE_TORCH_CPU=AUTO','-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_PROJECT_INCLUDE='+str(overlay),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(shape+'-build',['cmake','--build',build,'--parallel','2'])
 run(shape+'-source',[build/'bin/cpu_f5_source_delivery'])
 run(shape+'-install',['cmake','--install',build])
 assert prefix.resolve().parent==root and relocated.resolve().parent==root;prefix.rename(relocated)
 b=root/('f5-'+shape+'-consumer')
 run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',b,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(shape+'-consumer-build',['cmake','--build',b,'--parallel','2'])
 run(shape+'-consumer-run',[b/'cpu_final_delivery'])
 run(shape+'-loader',['ldd',b/'cpu_final_delivery'])
 if shape=='shared':run('shared-export',['python3',source/'scripts/check-shared-export-hygiene.py','--root',relocated])
'''.replace('SHA',repr(sha)).replace('CANDIDATE',repr(candidate))
script=out/'remote-driver.py'
script.write_text(remote_code,encoding='utf-8')
args=['wsl.exe','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/delivery-linux/remote-driver.py']
with (out/'driver.log').open('wb') as log:
    result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/'driver.log').read_text(errors='replace')[-6500:],flush=True)
copy="from pathlib import Path; import shutil; a=Path('/root/hyle-scratch/active-cpu-z/f5-result'); b=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/delivery-linux'); [shutil.copyfile(p,b/p.name) for p in a.iterdir() if p.is_file()]"
subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',copy],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
result.check_returncode()
