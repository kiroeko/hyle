import json
from pathlib import Path
import shlex
import subprocess
import time

out=Path('.scratch/validation/cpu-final-f5/delivery-mac')
out.mkdir(parents=True,exist_ok=True)
remote='/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8'
source=remote+'/hyle-0.1.0-source'
identity=json.loads(Path('.scratch/validation/cpu-final-f5/mac-sync.json').read_text())
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
flags={'creationflags':subprocess.CREATE_NO_WINDOW}
ssh='C:/Windows/System32/OpenSSH/ssh.exe'
scp='C:/Windows/System32/OpenSSH/scp.exe'
def run(name,args):
    start=time.monotonic()
    with (out/(str(len(records)+1)+'-'+name+'.log')).open('wb') as log:
        result=subprocess.run([ssh,'-o','BatchMode=yes','kiro@172.22.10.198',
            'export PATH=/opt/homebrew/bin:$PATH OMP_NUM_THREADS=1 MKL_NUM_THREADS=1; '+shlex.join(args)],
            stdout=log,stderr=subprocess.STDOUT,**flags)
    records.append({'name':name,'candidate':identity['candidate'],'args':args,'exit':result.returncode,
                    'seconds':round(time.monotonic()-start,3)})
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(records[-1],flush=True)
    if result.returncode:
        print((out/(str(len(records))+'-'+name+'.log')).read_text(errors='replace')[-6000:],flush=True)
        result.check_returncode()
run('machine',['sh','-c','sysctl -n hw.model; sw_vers; clang++ --version; cmake --version'])
run('reuse-source-consumer-cache',['python3','-c',"from pathlib import Path;import shutil;a=Path('/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8/f5-consumer');b=a.with_name('f4-consumer');assert b.is_dir();[shutil.copyfile(a/n,b/n) for n in ('CMakeLists.txt','main.cc')]"])
for shape in ('shared','static'):
    build=remote+'/'+shape+'-build'
    prefix=remote+'/f5-'+shape+'-staging'
    relocated=remote+'/f5-'+shape+'-relocated'
    run(shape+'-configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=OFF',
        '-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DHYLE_INSTALL=ON',
        '-DCMAKE_INSTALL_PREFIX='+prefix,'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-build',['cmake','--build',build,'--parallel','2'])
    run(shape+'-install',['cmake','--install',build])
    move="from pathlib import Path; a=Path("+repr(prefix)+"); b=Path("+repr(relocated)+"); root=Path("+repr(remote)+").resolve(); assert a.resolve().parent==root and b.resolve().parent==root and a.is_dir() and not b.exists(); a.rename(b)"
    run(shape+'-relocate',['python3','-c',move])
    consumer=remote+'/f5-'+shape+'-consumer'
    run(shape+'-consumer-configure',['cmake','-S',remote+'/f4-consumer','-B',consumer,'-G','Ninja',
         '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+relocated,'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
    run(shape+'-consumer-run',[consumer+'/cpu_final_delivery'])
    if shape=='shared':
        run('shared-export',['python3',source+'/scripts/check-shared-export-hygiene.py','--root',relocated])
# Existing source parent is a separate real add_subdirectory delivery, not an SDK journey.
run('source-consumer-configure',['cmake','-S',remote+'/f4-consumer','-B',remote+'/f4-source-consumer','-G','Ninja',
    '-DHYLE_EMBED_SOURCE='+source,'-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF',
    '-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_TORCH_CPU=AUTO',
    '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('source-consumer-build',['cmake','--build',remote+'/f4-source-consumer','--parallel','2'])
run('source-consumer-run',[remote+'/f4-source-consumer/cpu_final_delivery'])
