exec(open('.scratch/validate-cpu-final-f5-first.py',encoding='utf-8').read().split("\nrun('configure-tests'")[0])
env['HYLE_D5_QWEN35_FIXTURE']=str(repo/'.scratch/d5-qwen35-six-profile-fixture')
assert Path(env['HYLE_D5_QWEN35_FIXTURE']).is_dir()
run('consumer-batch-build',['cmake','--build',build,'--target',
    'hyle_compute_tests','hyle_compute_backend_cpu_tests','hyle_compute_provider_ggml_tests',
    'hyle_compute_provider_onednn_tests','hyle_compute_route_cpu_tests',
    'hyle_graph_tests','hyle_graph_provider_onednn_tests','hyle_graph_route_cpu_tests',
    '--parallel','2'])
run('consumer-batch-tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error',
    '-L','^(compute|compute_backend_cpu|compute_provider_ggml|compute_provider_onednn|compute_route_cpu|graph|graph_provider_onednn|graph_route_cpu)$',
    '-LE','headers','-j','1','--output-junit',out/'consumer-batch.xml'])
