import hashlib,json,subprocess
from pathlib import Path
repo=Path.cwd();consumer=repo/'.scratch/validation/cpu-final-f5/delivery-consumer'
remote='/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8/f5-consumer'
scp='C:/Windows/System32/OpenSSH/scp.exe'
for name in ('main.cc','CMakeLists.txt'):
    subprocess.run([scp,'-q','-o','BatchMode=yes',str(consumer/name),'kiro@172.22.10.198:'+remote+'/'+name],
        check=True,capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
(consumer/'identity.json').write_text(json.dumps({'scope':'F5 standalone consumer correction, no product change',
    'files':{name:hashlib.sha256((consumer/name).read_bytes()).hexdigest() for name in ('main.cc','CMakeLists.txt')}},indent=2)+'\n')
print('Corrected canonical standalone consumer forwarded to Mac; Linux driver copies from mounted canonical files.')
