from pathlib import Path
driver=Path('.scratch/run-cpu-final-f5-windows-delivery.py').read_text(encoding='utf-8')
exec(driver.split("\nfor shape in ('shared','static'):")[0])
shape='shared';prefix=sdk_root/(shape+'-staging');relocated=sdk_root/(shape+'-relocated')
run('shared-build-corrected',['cmake','--build',build,'--parallel','2'])
run('shared-source-default',[build/'bin/cpu_f5_source_delivery.exe'])
run('shared-install',['cmake','--install',build])
assert prefix.resolve().parent==sdk_root.resolve() and relocated.resolve().parent==sdk_root.resolve() and not relocated.exists()
prefix.rename(relocated)
cb=sdk_root/'shared-consumer'
run('shared-consumer-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja',
    '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('shared-consumer-build',['cmake','--build',cb,'--parallel','2'])
for name in ('torch_cpu.dll','torch.dll','c10.dll'):assert (cb/name).is_file()
previous=env['PATH'];env['PATH']=os.environ['SystemRoot']+'/System32;'+os.environ['SystemRoot']
try:run('shared-consumer-default',[cb/'cpu_final_delivery.exe'])
finally:env['PATH']=previous
run('shared-export',['python',repo/'scripts/check-shared-export-hygiene.py','--root',relocated])
loop="\nfor shape in ('static',):"+driver.split("\nfor shape in ('shared','static'):",1)[1]
exec(loop)
