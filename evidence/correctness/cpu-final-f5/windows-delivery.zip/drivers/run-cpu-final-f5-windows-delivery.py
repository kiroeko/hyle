exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-final-f5/delivery-windows';out.mkdir(parents=True,exist_ok=True)
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
consumer=repo/'.scratch/validation/cpu-final-f5/delivery-consumer'
sdk_root=Path('C:/hv/cpu-final-f5-sdk');sdk_root.mkdir(exist_ok=True)
overlay=out/'source-overlay.cmake'
overlay.write_text('function(cpu_f5_hook)\nadd_executable(cpu_f5_source_delivery "'+str((consumer/'main.cc').as_posix())+'")\ntarget_compile_features(cpu_f5_source_delivery PRIVATE cxx_std_23)\ntarget_link_libraries(cpu_f5_source_delivery PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(cpu_f5_source_delivery)\nendfunction()\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\ncmake_language(DEFER CALL cpu_f5_hook)\nendif()\n',encoding='utf-8')
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
import ctypes
kernel=ctypes.windll.kernel32
kernel.GetCurrentProcess.restype=ctypes.c_void_p
kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
original=ctypes.c_size_t();system=ctypes.c_size_t()
assert kernel.GetProcessAffinityMask(kernel.GetCurrentProcess(),ctypes.byref(original),ctypes.byref(system))
for shape in ('shared','static'):
    prefix=sdk_root/(shape+'-staging');relocated=sdk_root/(shape+'-relocated')
    assert not prefix.exists() and not relocated.exists()
    run(shape+'-configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON',
        '-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+str(prefix),
        '-DCMAKE_PROJECT_INCLUDE='+str(overlay),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-build',['cmake','--build',build,'--parallel','2'])
    run(shape+'-source-default',[build/'bin/cpu_f5_source_delivery.exe'])
    if shape=='static':
        assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),4)
        try:run(shape+'-source-qualified',[build/'bin/cpu_f5_source_delivery.exe','--qualified'])
        finally:assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),original.value)
    run(shape+'-install',['cmake','--install',build])
    assert prefix.resolve().parent==sdk_root.resolve() and relocated.resolve().parent==sdk_root.resolve()
    prefix.rename(relocated)
    cb=sdk_root/(shape+'-consumer')
    run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-consumer-build',['cmake','--build',cb,'--parallel','2'])
    for name in ('torch_cpu.dll','torch.dll','c10.dll'):assert (cb/name).is_file()
    previous=env['PATH'];env['PATH']=os.environ['SystemRoot']+'/System32;'+os.environ['SystemRoot']
    try:
        run(shape+'-consumer-default',[cb/'cpu_final_delivery.exe'])
        if shape=='static':
            assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),4)
            try:run(shape+'-consumer-qualified',[cb/'cpu_final_delivery.exe','--qualified'])
            finally:assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),original.value)
    finally:env['PATH']=previous
    if shape=='shared':run('shared-export',['python',repo/'scripts/check-shared-export-hygiene.py','--root',relocated])
