from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
ext=Path('/root/hyle-scratch/compute-unified');attempt=sys.argv[1]
out=base/('ce25-native-prefill-numeric-'+attempt);out.mkdir(exist_ok=False)
source=ext/('g04-ce25-native-prefill-source-'+attempt);build=ext/('g04-ce25-native-prefill-build-'+attempt)
assert not source.exists() and not build.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True).strip()
for mode in ('static','shared'):
 p=root/('evidence/correctness/inference-g04-g05-cuda-ce25-'+mode+'-sdk/receipt.json')
 sdk_receipt=json.loads(p.read_text())
 assert sdk_receipt['product_candidate']=='0143102aebcbc29600a77ce2950136462fba2a36' and 'PASS' in sdk_receipt['verdict'],mode+' SDK must finish before numeric'
r=dict(state='SETUP',stages=[],cumulative_seconds=0,scope='Current CE25 static SDK and sync-fixed native peer; two variants, three finite shapes, independent double oracle and actual primary device checks. No A/A or performance sampling.',heavy_serial=True,max_compile_jobs=2,native_tu_pool=1)
active=None
def save():(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def failed(kind,error,tb):
 r.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if active and active.poll() is None else 'TERMINAL_FAIL',error=repr(error));save();sys.__excepthook__(kind,error,tb)
sys.excepthook=failed;save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['CMAKE_BUILD_PARALLEL_LEVEL']='2'
env['HYLE_BENCH_VERIFY_ONLY']='1';env['CUDA_VISIBLE_DEVICES']='0';env.pop('HYLE_BENCH_AA_ROUTE',None)
def run(stage,command):
 global active
 log=out/(stage+'.log');start=time.monotonic()
 with log.open('w') as f:
  active=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',active_stage=stage,active_pid=active.pid);save();print(stage,active.pid,flush=True);code=active.wait()
 elapsed=time.monotonic()-start;r['stages'].append(dict(stage=stage,command=command,exit_code=code,elapsed_seconds=elapsed,log=str(log)));r['cumulative_seconds']+=elapsed;save();print(stage,code,round(elapsed,3),flush=True)
 assert code==0,stage+' failed; see '+str(log)
 return log
r['identity']={k:subprocess.check_output(cmd,text=True).strip() for k,cmd in (
 ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
 ('gpu',['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader']))}
assert 'RTX 4070' in r['identity']['gpu'] and '8.9' in r['identity']['gpu']
run('clone',['git','clone','--shared','--no-checkout',str(root),str(source)])
run('checkout',['git','-C',str(source),'checkout','--detach',head])
old=json.loads((root/'evidence/correctness/inference-g04-g05-cuda-episode-interleave-numeric-rebind/receipt.json').read_text())['successful_run']
bench=[x['path'] for x in old['snapshot']['benchmark_inputs']]+['bench/inference_resident_sdpa/cuda_encoded_p1/CMakeLists.txt','bench/inference_resident_sdpa/cpu_placement.cc','bench/integration/perf_control_bench.cc','third_party/flashinfer_cache/patches.json']
products=[x['path'] for x in old['snapshot']['product_inputs']]
r['snapshot']=dict(canonical_head=head,product_inputs=[dict(path=p,sha256=sha(source/p)) for p in products],benchmark_inputs=[dict(path=p,sha256=sha(source/p)) for p in sorted(set(bench))])
shipping_path=base/'sdk/result-cuda-static-ce25-1.json';shipping=json.loads(shipping_path.read_text());assert shipping['state']=='TERMINAL_PASS'
qualified={x['path']:x['sha256'] for x in shipping['inputs']}
for item in r['snapshot']['product_inputs']:assert qualified.get(item['path'])==item['sha256'],'SDK source mismatch '+item['path']
sdk=Path(shipping['prefix']);r['sdk_artifacts']=json.loads((base/'sdk/artifacts-cuda-static-ce25-1.json').read_text())
r['sdk_recipes']=[dict(path=str(p.relative_to(sdk)),sha256=sha(p)) for p in sorted((sdk/'lib/cmake').rglob('*')) if p.is_file()]
r['sdk_native_archives']=[dict(path=str(p.relative_to(sdk)),sha256=sha(p)) for p in sorted((sdk/'lib').glob('*.a')) if not p.name.startswith('libhyle')]
def verify_inputs():
 for x in r['sdk_artifacts']:assert sha(Path(x['path']))==x['sha256'],x['path']
 for x in r['sdk_recipes']+r['sdk_native_archives']:assert sha(sdk/x['path'])==x['sha256'],x['path']
 for x in r['snapshot']['benchmark_inputs']+r['snapshot']['product_inputs']:assert sha(source/x['path'])==x['sha256'],x['path']
verify_inputs();r['shipping_receipt']=dict(path=str(shipping_path),sha256=sha(shipping_path));save()
contract_path=source/'bench/inference_resident_sdpa/cuda_encoded_p1';contract=json.loads((contract_path/'contract.json').read_text());settings=contract['extensions']['runner']['cmake']['cache'].copy()
settings.update(contract['extensions']['runner']['profiles']['W1-WSL']['cache']);settings['CMAKE_BUILD_TYPE']='Release'
assert settings['CMAKE_PREFIX_PATH']==str(sdk) and settings['HYLE_SIMD_EXACT_TARGET']==''
settings['HYLE_FLASHINFER_ORIGINAL_SOURCE']=str(ext/'peers/flashinfer-69ff-git-1')
run('configure',['cmake','-S',str(contract_path),'-B',str(build),'-G','Ninja']+['-D'+k+'='+v for k,v in settings.items()])
r['original_source']=json.loads((build/'original-peer/original-flashinfer-source.json').read_text());save()
manifest=out/'preview.ninja';manifest.write_bytes((build/'build.ninja').read_bytes())
targets=['g04_cuda_encoded_bench','g04_cuda_encoded_bench_placement','g04_cuda_encoded_perf_control']
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(manifest),'-n']+targets,env=env,text=True);(out/'dry-run.txt').write_text(dry)
assert all(x not in dry for x in ('Re-running CMake','Building CXX object src/','Building C object src/','Building CUDA object src/'))
run('compile',['cmake','--build',str(build),'--parallel','2','--target']+targets)
sys.path.insert(0,str(source/'scripts'))
from hyle_perf.runner import _read_cmake_cache,_cmake_toolchain_details,_observed_configuration,_evaluate_validators
cache=_read_cmake_cache(build);toolchain=_cmake_toolchain_details(build,cache)
observed=_observed_configuration(cache,contract['build']['configuration'])
build_record=dict(fresh=True,configuration=observed['value'],details=dict(machine_profile='W1-WSL',
 configuration_observation=observed,generator=cache['CMAKE_GENERATOR'],architecture=cache.get('CMAKE_GENERATOR_PLATFORM','default') or 'default',
 cmake_cache=cache,compiler={k:toolchain[k] for k in ('compiler_id','compiler_version')},toolchain=toolchain))
runner=contract['extensions']['runner'].copy();runner['validators']=[v for v in runner['validators'] if v['id']=='build-contract']
guard=_evaluate_validators(runner,source=contract_path,build=build,output=out,artifact_hashes_before={},artifact_hashes_after={},contract=contract,build_record=build_record)
(out/'build-contract-preflight.json').write_text(json.dumps(guard,indent=2)+'\n')
assert len(guard)==1 and guard[0]['gate']=='PASS',guard
r['build_contract_preflight']=guard;save()
r['actual_compile_steps']=[line for line in (out/'compile.log').read_text().splitlines() if re.search(r'Building (CXX|CUDA) object ',line)]
assert sum('Building CUDA object ' in line for line in r['actual_compile_steps'])==1
deps=subprocess.check_output(['ninja','-C',str(build),'-t','deps'],text=True);(out/'actual-dependencies.txt').write_text(deps)
prepared=Path(r['original_source']['prepared_source']);headers=[]
for line in deps.splitlines():
 name=line.strip()
 if name.startswith('/') and '/flashinfer/' in name:
  p=Path(name);assert p.is_relative_to(prepared/'include'),name;headers.append(dict(path=str(p),sha256=sha(p)))
 if name.startswith(str(sdk/'include/hyle')+'/'):
  p=Path(name);key='include/hyle/'+str(p.relative_to(sdk/'include/hyle'));assert qualified[key]==sha(p),key
assert headers;r['actual_original_headers']=headers
r['binaries']=[dict(variant=v,path=str(build/'bin'/t),sha256=sha(build/'bin'/t)) for v,t in (('primary',targets[0]),('placement',targets[1]))]
r['binary']=r['binaries'][0];save();all_errors=[];environments=[]
def check_oracle(log):
 text=log.read_text();values=re.findall(r'# CUDA_ENCODED_CORRECTNESS max_abs_error=([^ ]+)',text)
 assert len(values)==24 and max(map(float,values))<=8e-3 and text.count('# CUDA_FP8_PAIR ')==3 and text.count('# CUDA_ENCODED_ORIGINAL_COLD ')==3
 facts=[re.sub(r' original=[01]$','',line) for line in text.splitlines() if line.startswith('# CUDA_ENCODED_ENV ')]
 assert len(facts)==6 and len(set(facts))==1;environments.append(facts[0]);all_errors.extend(map(float,values));return max(map(float,values))
for row in r['binaries']:check_oracle(run('oracle-'+row['variant'],[row['path']]))
r['device_checks']=[]
for tool in ('memcheck','racecheck'):
 command=['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool',tool,'--error-exitcode','86','--print-limit','0']
 if tool=='racecheck':command+=['--racecheck-num-workers','4']
 log=run(tool,command+[r['binary']['path']]);check_oracle(log);text=log.read_text()
 assert 'ERROR SUMMARY: 0 errors' in text or (tool=='racecheck' and 'RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)' in text)
 assert not re.search(r'^========= (Error:|Warning:)',text,re.M)
 r['device_checks'].append(dict(tool=tool,verdict='PASS',log=str(log),sha256=sha(log)))
verify_inputs()
for row in r['binaries']:assert sha(Path(row['path']))==row['sha256']
assert len(set(environments))==1
r.update(state='TERMINAL_PASS',native_environment=environments[0],max_abs_error=max(all_errors),readonly='PASS',replays=4,slots=2)
r.pop('active_pid',None);r.pop('active_stage',None);save();print('TERMINAL_PASS',r['cumulative_seconds'],flush=True)
