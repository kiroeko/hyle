from pathlib import Path
import hashlib, json, subprocess, xml.etree.ElementTree as ET, zipfile

root = Path.cwd()
base = root/'.scratch/inference-gaps/g04-g05'
candidate = 'd41431f82a373ae400fb10e97418931031fa48e8'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((base/'ce27-source-1/result.json').read_text())
device = json.loads((base/'ce27-device-risks-1/result.json').read_text())
assert source['state'] == device['state'] == 'TERMINAL_PASS'
codegen=json.loads((base/'ce27-fixed-codegen-1/result.json').read_text())
assert codegen['state']=='TERMINAL_PASS' and codegen['product_candidate']==candidate
for row in codegen['kernels']+[codegen['merge']]:
    assert 'STACK:0 ' in row['after_resource'] and row['after_sass']['LDL']==row['after_sass']['STL']==0

assert device['product_commit'] == candidate
assert all(s['exit_code'] == 0 for r in (source, device) for s in r['stages'])
assert device['source_result_sha256'] == sha(base/'ce27-source-1/result.json')
for name, count in [('ce27-source-1/tests.xml',17), ('ce27-device-risks-1/memcheck.xml',10),
                    ('ce27-device-risks-1/racecheck.xml',10), ('ce27-device-risks-1/legacy-racecheck.xml',2)]:
    x = ET.parse(base/name).getroot()
    assert int(x.attrib['tests']) == count and x.attrib['failures'] == x.attrib['errors'] == '0'
    assert not any(c.find('skipped') is not None or c.attrib.get('status') == 'notrun' for c in x.findall('.//testcase'))
for row in source['inputs']:
    assert sha(root/row['path']) == row['sha256'], row['path']
for name in ['third_party/flashinfer_cache/patches.json', 'third_party/flashinfer_cache/NOTICE.md', 'cmake/HyleDependencyLock.json']:
    committed = subprocess.check_output(['git','show',candidate+':'+name]).replace(b'\r\n',b'\n')
    assert (root/name).read_bytes().replace(b'\r\n',b'\n') == committed
for label in ['memcheck','racecheck','legacy-racecheck']:
    text = (base/'ce27-device-risks-1'/(label+'.log')).read_text()
    assert not any(word in text.lower() for word in ['========= warning:', '========= error:', 'race reported'])
for path, expected in device['artifacts'].items():
    assert subprocess.check_output(['wsl','-e','sha256sum',path], text=True).split()[0] == expected

dest = root/'evidence/correctness/inference-g04-g05-cuda-ce27-owned-conversion-source-device'
assert not dest.exists()
dest.mkdir()
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for folder in ['ce27-source-1','ce27-device-risks-1']:
        for p in sorted((base/folder).rglob('*')):
            if p.is_file(): archive.write(p,p.relative_to(base).as_posix())
    for name in ['launch_ce27_source.py','ce27_source_wsl.py','ce19_cuda_compile.cmake',
                 'ce27_device_risks_wsl.py','seal_ce27_source_device.py']:
        archive.write(base/name,'runners/'+name)
    with zipfile.ZipFile(base/'ce27-source-1.zip') as package:
        archive.writestr('source-manifest.json',package.read('source-manifest.json'))
receipt = dict(kind='G04_G05_CUDA_CE27_OWNED_FP8_CONVERSION_SOURCE_DEVICE',
    verdict='PASS_SOURCE17_CACHE_MEM10_RACE10_LEGACY_RACE2_ONLY', product_candidate=candidate,
    source_tests=17, source_stages=source['stages'], source_input_count=len(source['inputs']),
    source_result_raw_sha256=sha(base/'ce27-source-1/result.json'), native_cuda_edges=source['native_cuda_edges'],
    device_stages=device['stages'],artifacts=device['artifacts'],
    measured_stage_seconds=dict(source=sum(s['elapsed_seconds'] for s in source['stages']),
                               device=sum(s['elapsed_seconds'] for s in device['stages'])),
    limits=['Actual W1 WSL RTX4070 SM89 only; no other GPU or OS qualification.',
    'One audited fix: producer-owned full-row FP8 conversion and adjacent pre-barrier coalescing; fallback assignments and barriers unchanged.',
    'All async operations/waits and post-conversion publication, consumer-retirement, final/output barriers, conversion values and geometry retained; CE26 F32 merge unchanged.',
    'Source17/cache mem10/race10/legacy race2 only; new SDK/numeric/runtime/host/original P1 remain separate gates.',
    'All prior qualified failures, hazards, diagnostic runs, third-party unknowns and costs remain immutable evidence.'],
    raw_zip_sha256=sha(dest/'raw.zip'))
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
p = root/'docs/implementation/module-status.json'
registry = json.loads(p.read_text(encoding='utf-8'))
m = next(x for x in registry['modules'] if x['module']=='compute_provider_flashinfer')
assert m['state']=='AUDITED' and 'candidate' not in m
m['state']='CANDIDATE';m['candidate']=candidate
m['summary']='G04/G05 CE27 CANDIDATEd414：producer-owned转换/相邻同步修正的新17math/22device及attention+merge零栈codegen通过。两SDK/numeric/runtime/三host/原P1待验；原qualified FAIL与全部旧失败/未知、累计成本保留。'
p.write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\r\n')
print(json.dumps(dict(path=str(dest),candidate=candidate,seconds=receipt['measured_stage_seconds'])))
