from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
source=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
out=base/('ce27-source-'+sys.argv[2]);out.mkdir(exist_ok=False)
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
with zipfile.ZipFile(sys.argv[1]) as package:
 inputs=json.loads(package.read('source-manifest.json'))
 for row in inputs:
  p=Path(row['path']);assert not p.is_absolute() and '..' not in p.parts
  data=package.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
  target=source/p
  if not target.exists() or target.read_bytes()!=data:
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
r=dict(state='SETUP',pid=os.getpid(),source=str(source),build=str(build),inputs=inputs,stages=[],max_ninja_jobs=2,nvcc_optimizer_threads=3,
 scope='CE27 producer-owned FP8 conversion and adjacent barrier coalescing source/math only; no G02/other route/global or P1 verdict')
def save():(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,command):
 start=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as f:
  proc=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=proc.pid);save();print(stage,proc.pid,flush=True);code=proc.wait()
 r['stages'].append(dict(stage=stage,command=command,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)));save()
 if code:
  r.update(state='TERMINAL_FAIL');save();raise SystemExit(code)
run('configure',['cmake','-S',str(source),'-B',str(build),'-DHYLE_INSTALL=OFF','-DHYLE_BUILD_TESTS=ON','-DHYLE_TEST_INSTRUMENTATION=OFF','-DCMAKE_PROJECT_INCLUDE=/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce19_cuda_compile.cmake'])
run('prepare-manifest',['ninja','-C',str(build),'build.ninja'])
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n','hyle_compute_provider_flashinfer_test'],env=env,text=True)
(out/'dry-run.log').write_text(dry)
cuda=[line for line in dry.splitlines() if 'Building CUDA object' in line]
assert 'Re-running CMake' not in dry,'Dry run must expand actual target edges after manifest preparation'
assert not any('ggml-cuda' in line for line in cuda),'Unrelated ggml CUDA rebuild rejected before build'
assert len(cuda)<=4,('Unexpected native CUDA scope',cuda)
r['native_cuda_edges']=cuda;save()
run('build',['cmake','--build',str(build),'--target','hyle_compute_provider_flashinfer_test','--parallel','2','--','-k','0'])
run('tests',[str(build/'bin/hyle_compute_provider_flashinfer_test'),'--gtest_output=xml:'+str(out/'tests.xml')])
r.update(state='TERMINAL_PASS');r.pop('child_pid',None);save();print('TERMINAL_PASS',flush=True)
