from pathlib import Path
import hashlib,json,re

root=Path('C:/public/project-hyle/hyle')
original=root/'.scratch/inference-gaps/g01/native-paged/mlx-original'
manifest_path=root/'third_party/mlx_cast/patches.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
original_manifest=manifest_path.read_bytes()
preview=root/'.scratch/inference-gaps/g01/native-paged/mlx-patched-preview'
edits={}
def read(name):
    if name not in edits:
        patch=next((p for p in manifest['files'] if p['path']==name),None)
        raw=(original/name).read_bytes().replace(b'\r\n',b'\n')
        if patch:
            assert hashlib.sha256(raw).hexdigest()==patch['before_sha256'],name
            for e in patch['edits']:
                assert raw.count(e['before'].encode())==1,(name,e['before'][:80])
                raw=raw.replace(e['before'].encode(),e['after'].encode(),1)
            assert hashlib.sha256(raw).hexdigest()==patch['after_sha256'],name
        edits[name]=raw.decode()
    return edits[name]
def replace(name,before,after):
    text=read(name);assert text.count(before)==1,(name,before[:140],text.count(before))
    edits[name]=text.replace(before,after,1)

fast='mlx/fast.h'
replace(fast,'MLX_API array scaled_dot_product_attention(','''// Private HYLE exact-page adapter. Native physical K/V shapes stay truthful;
// ordinary callers use HYLE's typed frame controller, never this raw seam.
MLX_API array hyle_paged_attention(
    const array& q, const array& k, const array& v, const array& pages,
    int logical_rows, int table_offset, float scale, bool causal, Stream stream);

MLX_API array scaled_dot_product_attention(''')
primitive='mlx/fast_primitives.h'
replace(primitive,'class ScaledDotProductAttention : public Custom {','''class HylePagedAttention final : public Custom {
 public:
  HylePagedAttention(Stream stream, int rows, int offset, float scale, bool causal)
      : Custom(stream, [](std::vector<array>) -> std::vector<array> {
          throw std::runtime_error("HYLE paged attention has no fallback/AD transform");
        }), rows_(rows), offset_(offset), scale_(scale), causal_(causal) {}
  void eval_cpu(const std::vector<array>&, std::vector<array>&) override {
    throw std::runtime_error("HYLE paged attention requires original Metal math");
  }
  void eval_gpu(const std::vector<array>&, std::vector<array>&) override;
  bool is_equivalent(const Primitive& other) const override {
    const auto& p = static_cast<const HylePagedAttention&>(other);
    return rows_ == p.rows_ && offset_ == p.offset_ &&
           scale_ == p.scale_ && causal_ == p.causal_;
  }
  DEFINE_NAME(HylePagedAttention);
  DEFINE_INPUT_OUTPUT_SHAPE()
  auto state() const { return std::make_tuple(nullptr, rows_, offset_, scale_, causal_); }
 private:
  int rows_, offset_;
  float scale_;
  bool causal_;
};

class ScaledDotProductAttention : public Custom {''')
fastcc='mlx/fast.cpp'
replace(fastcc,'array scaled_dot_product_attention(','''array hyle_paged_attention(
    const array& q, const array& k, const array& v, const array& pages,
    int rows, int offset, float scale, bool causal, Stream stream) {
  if (q.ndim() != 4 || k.ndim() != 4 || v.shape() != k.shape() ||
      q.shape(0) != 1 || k.shape(0) != 1 || k.shape(2) <= 0 || k.shape(2) % 16 ||
      q.shape(2) <= 0 || q.shape(1) <= 0 || k.shape(1) <= 0 ||
      q.shape(1) % k.shape(1) || q.shape(3) != k.shape(3) ||
      (q.shape(3) != 64 && q.shape(3) != 128 && q.shape(3) != 256) ||
      q.dtype() != k.dtype() || q.dtype() != v.dtype() ||
      (q.dtype() != float16 && q.dtype() != bfloat16) ||
      pages.ndim() != 1 || pages.dtype() != int32 || pages.strides(0) != 1 ||
      rows <= 0 || offset < 0 || int64_t(offset) + (int64_t(rows) + 15) / 16 > pages.size() ||
      (causal && rows < q.shape(2)) || !std::isfinite(scale)) {
    throw std::invalid_argument("HYLE paged attention physical/logical/table domain");
  }
  return array(q.shape(), q.dtype(),
      std::make_shared<HylePagedAttention>(stream, rows, offset, scale, causal),
      {q, k, v, pages});
}

array scaled_dot_product_attention(''')

host='mlx/backend/metal/scaled_dot_product_attention.cpp'
replace(host,'namespace {\n','''namespace {
struct HylePageInfo {
  array table;
  int rows, offset;
};
''')
# Four private dispatch helpers accept page info. No fields are added to the
# original public primitive, AttnParams, normal arrays or Program state.
text=read(host)
for name in ['sdpa_full_self_attention_nax','sdpa_full_self_attention_metal','sdpa_vector','sdpa_vector_2pass']:
    start=text.index('void '+name+'(')
    end=text.index('\n}',start)+2
    chunk=text[start:end]
    before='    const std::optional<array>& sinks) {'
    assert chunk.count(before)==1
    chunk=chunk.replace(before,'''    const std::optional<array>& sinks,
    const std::optional<HylePageInfo>& page = std::nullopt) {''',1)
    chunk=chunk.replace('int kL = k.shape(2);','int kL = page ? page->rows : k.shape(2);')
    chunk=chunk.replace('int N = k.shape(2);','int N = page ? page->rows : k.shape(2);')
    chunk=chunk.replace('  if (split_d && do_causal_', '  if (!page && split_d && do_causal_')
    if name.endswith('metal'):
        chunk=chunk.replace('/* const std::optional<array>& sinks = */ sinks);', '/* const std::optional<array>& sinks = */ sinks, page);')
    if 'full_self' in name:
        chunk=chunk.replace('  const bool has_sinks = sinks.has_value();','  const bool has_sinks = sinks.has_value();\n  const bool hyle_paged = page.has_value();')
        chunk=chunk.replace('{&has_sinks, MTL::DataType::DataTypeBool, 302}};', '{&has_sinks, MTL::DataType::DataTypeBool, 302},\n      {&hyle_paged, MTL::DataType::DataTypeBool, 303}};')
        before='  auto& compute_encoder = metal::get_command_encoder(s);'
        assert chunk.count(before)==1
        chunk=chunk.replace(before,'  if (page) hash_name += "_hyle_page16";\n\n'+before)
        before='  compute_encoder.set_bytes(params, 4);'
        chunk=chunk.replace(before,before+'''\n  if (page) {
    compute_encoder.set_input_array(page->table, 8);
    compute_encoder.set_bytes(page->offset, 9);
  }''')
    else:
        chunk=chunk.replace('  bool has_sinks = sinks.has_value();','  bool has_sinks = sinks.has_value();\n  bool hyle_paged = page.has_value();')
        before='      {&has_sinks, MTL::DataType::DataTypeBool, 25},'
        chunk=chunk.replace(before,before+'\n      {&hyle_paged, MTL::DataType::DataTypeBool, 27},')
        before='  hash_name += has_sinks ? "_sinks" : "_nosinks";'
        chunk=chunk.replace(before,before+'\n  if (page) hash_name += "_hyle_page16";')
        # Bind before the first-stage dispatch, never the reduction stage.
        before='  compute_encoder.set_input_array(v, 2);'
        chunk=chunk.replace(before,before+'''\n  if (page) {
    compute_encoder.set_input_array(page->table, 19);
    compute_encoder.set_bytes(page->offset, 20);
  }''')
        chunk=chunk.replace('k.shape(2) >= 8192','(page ? page->rows : k.shape(2)) >= 8192')
    text=text[:start]+chunk+text[end:]
edits[host]=text
# One shared original eval implementation; the private primitive supplies
# logical lengths/table, while normal SDPA supplies no page metadata.
replace(host,'''void ScaledDotProductAttention::eval_gpu(
    const std::vector<array>& inputs,
    std::vector<array>& outputs) {
  auto& s = stream();''','''static void eval_sdpa_native(
    const std::vector<array>& inputs, std::vector<array>& outputs,
    const Stream& s, float scale_, bool do_causal_, bool has_sinks_,
    const std::optional<HylePageInfo>& page) {''')
replace(host,'  bool has_arr_mask = inputs.size() > (3 + has_sinks_);','  bool has_arr_mask = !page && inputs.size() > (3 + has_sinks_);')
text=read(host)
text=text.replace("k.shape(2) >= 1024", "(page ? page->rows : k.shape(2)) >= 1024")
text=text.replace("k.shape(2) >= 4096", "(page ? page->rows : k.shape(2)) >= 4096")
for name in ['sdpa_vector_2pass','sdpa_vector']:
    text=text.replace(f'{name}(s, d, q, k, v, o, scale_, do_causal, mask, sinks);',f'{name}(s, d, q, k, v, o, scale_, do_causal, mask, sinks, page);')
text=text.replace('s, d, q, k, v, scale_, o, do_causal_, mask, sinks);','s, d, q, k, v, scale_, o, do_causal_, mask, sinks, page);')
edits[host]=text
replace(host,'bool ScaledDotProductAttentionVJP::use_fallback(','''void ScaledDotProductAttention::eval_gpu(
    const std::vector<array>& inputs, std::vector<array>& outputs) {
  eval_sdpa_native(inputs, outputs, stream(), scale_, do_causal_, has_sinks_, std::nullopt);
}
void HylePagedAttention::eval_gpu(
    const std::vector<array>& inputs, std::vector<array>& outputs) {
  if (inputs.size() != 4) throw std::invalid_argument("HYLE paged attention needs four inputs");
  eval_sdpa_native(inputs, outputs, stream(), scale_, causal_, false,
                   HylePageInfo{inputs[3], rows_, offset_});
}

bool ScaledDotProductAttentionVJP::use_fallback(''')

# Vector native read points: one-pass, two-pass, and grouped-query two-pass.
vector='mlx/backend/metal/kernels/sdpa_vector.h'
replace(vector,'constant int blocks [[function_constant(26)]];','''constant int blocks [[function_constant(26)]];
constant bool hyle_paged [[function_constant(27)]];''')
text=read(vector)
for name in ['sdpa_vector','sdpa_vector_2pass_1','sdpa_vector_2pass_1_gqa']:
    start=text.index('[[kernel]] void '+name+'(')
    end=text.index('\n}',start)+2
    chunk=text[start:end]
    anchor='    uint3 tid [[threadgroup_position_in_grid]],'
    chunk=chunk.replace(anchor,'''    const device int* hyle_pages [[buffer(19), function_constant(hyle_paged)]],
    const constant int& hyle_offset [[buffer(20), function_constant(hyle_paged)]],
'''+anchor,1)
    if name=='sdpa_vector':
        chunk=chunk.replace('simd_gid * k_seq_stride +', '(hyle_paged ? 0 : simd_gid * k_seq_stride) +',1)
        chunk=chunk.replace('simd_gid * v_seq_stride +', '(hyle_paged ? 0 : simd_gid * v_seq_stride) +',1)
        anchor='  for (int i = simd_gid; i < N; i += BN) {'
        chunk=chunk.replace(anchor,anchor+'''\n    const int physical = hyle_paged ? ((hyle_pages[hyle_offset + (i >> 4)] << 4) + (i & 15)) : 0;
    const device T* key_row = keys + (hyle_paged ? physical * k_seq_stride : 0);
    const device T* value_row = values + (hyle_paged ? physical * v_seq_stride : 0);''')
        chunk=chunk.replace('k[j] = keys[j];','k[j] = key_row[j];')
        chunk=chunk.replace('exp_score * values[j]','exp_score * value_row[j]')
        chunk=chunk.replace('    keys += inner_k_stride;\n    values += inner_v_stride;','    if (!hyle_paged) { keys += inner_k_stride; values += inner_v_stride; }')
    elif name=='sdpa_vector_2pass_1':
        chunk=chunk.replace('block_idx * k_seq_stride +', '(hyle_paged ? 0 : block_idx * k_seq_stride) +',1)
        chunk=chunk.replace('block_idx * v_seq_stride +', '(hyle_paged ? 0 : block_idx * v_seq_stride) +',1)
        anchor='  for (int i = block_idx; i < N; i += blocks) {'
        chunk=chunk.replace(anchor,anchor+'''\n    const int physical = hyle_paged ? ((hyle_pages[hyle_offset + (i >> 4)] << 4) + (i & 15)) : 0;
    const device T* key_row = keys + (hyle_paged ? physical * k_seq_stride : 0);
    const device T* value_row = values + (hyle_paged ? physical * v_seq_stride : 0);''')
        chunk=chunk.replace('q[i] * keys[i]','q[i] * key_row[i]')
        chunk=chunk.replace('exp_score * values[i]','exp_score * value_row[i]')
        chunk=chunk.replace('    keys += blocks * int(k_seq_stride);\n    values += blocks * int(v_seq_stride);','    if (!hyle_paged) { keys += blocks * int(k_seq_stride); values += blocks * int(v_seq_stride); }')
    else:
        chunk=chunk.replace('s0 * k_seq_stride +', '(hyle_paged ? 0 : s0 * k_seq_stride) +',1)
        chunk=chunk.replace('s0 * v_seq_stride +', '(hyle_paged ? 0 : s0 * v_seq_stride) +',1)
        anchor='  for (int t = s0; t < s1; t++) {'
        chunk=chunk.replace(anchor,anchor+'''\n    const int physical = hyle_paged ? ((hyle_pages[hyle_offset + (t >> 4)] << 4) + (t & 15)) : 0;
    const device T* key_row = kp + (hyle_paged ? physical * k_seq_stride : 0);
    const device T* value_row = vp + (hyle_paged ? physical * v_seq_stride : 0);''')
        chunk=chunk.replace('kr[i] = kp[i];','kr[i] = key_row[i];').replace('vr[i] = vp[i];','vr[i] = value_row[i];')
        chunk=chunk.replace('    kp += k_seq_stride;\n    vp += v_seq_stride;','    if (!hyle_paged) { kp += k_seq_stride; vp += v_seq_stride; }')
    text=text[:start]+chunk+text[end:]
edits[vector]=text

# Split the NAX original tile load at its original 16-row fragment boundary.
# No MMA, accumulators, softmax or reduction is replaced.
nax='mlx/backend/metal/kernels/steel/attn/nax.h'
replace(nax,'''  template <typename U>
  METAL_FUNC void store(device U* dst, const int ld) const thread {''','''  template <typename U>
  METAL_FUNC void load_paged(const device U* src, const int ld,
      const device int* pages, const int offset, const int first, const int n_rows) thread {
    static_assert(kFragRows == 16, "HYLE page16 requires original 16-row fragments");
    const_for_loop<0, kTileRows, 1>([&](auto idx_row) {
      const int logical = first + idx_row.value * kFragRows;
      const short remaining = short(metal::max(0, metal::min(kFragRows, n_rows - idx_row.value * kFragRows)));
      const int physical = remaining > 0 ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : 0;
      const_for_loop<0, kTileCols, 1>([&](auto idx_col) {
        NAXFrag_t::load_rows(frag_at<idx_row.value, idx_col.value>(),
            src + physical * ld, ld, Int<1>{}, remaining,
            Int<0>{}, idx_col * Int<kFragCols>{});
      });
    });
  }

  template <typename U>
  METAL_FUNC void store(device U* dst, const int ld) const thread {''')
full='mlx/backend/metal/kernels/steel/attn/kernels/steel_attention_nax.h'
text=read(full)
text=text.replace('constant bool has_sinks [[function_constant(302)]];','constant bool has_sinks [[function_constant(302)]];\nconstant bool hyle_paged [[function_constant(303)]];')
text=text.replace('    const device T* sinks [[buffer(7), function_constant(has_sinks)]],','''    const device T* sinks [[buffer(7), function_constant(has_sinks)]],
    const device int* hyle_pages [[buffer(8), function_constant(hyle_paged)]],
    const constant int& hyle_offset [[buffer(9), function_constant(hyle_paged)]],''')
for tile,letter in [('Ktile','K'),('Vtile','V')]:
    pattern=rf'(\s*)if \(!align_K && is_last_k\) {{\n\s*{tile}\.load_rows\((.*?)\n\s*}} else {{\n\s*{tile}\.load\((.*?)\n\s*}}'
    matches=list(re.finditer(pattern,text,re.S));assert len(matches)==2,(tile,len(matches))
    for m in reversed(matches):
        before=m.group(0);indent=m.group(1).split('\n')[-1]
        after='\n'+indent+f'''if (hyle_paged) {{
{indent}  {tile}.load_paged({letter} + id * kU, int(params->{letter}_strides[2]),
{indent}      hyle_pages, hyle_offset, kb * BK + ik * kU,
{indent}      params->kL - kb * BK - ik * kU);
{indent}}} else '''+before.lstrip()
        text=text[:m.start()]+after+text[m.end():]
text=text.replace('    K += BK * int(params->K_strides[2]);\n    V += BK * int(params->V_strides[2]);','''    if (!hyle_paged) {
      K += BK * int(params->K_strides[2]);
      V += BK * int(params->V_strides[2]);
    }''')
edits[full]=text

# Older steel tile loading keeps the same per-lane destination layout. Only
# its source row address changes; normal loader instance layout stays unchanged.
loader='mlx/backend/metal/kernels/steel/attn/loader.h'
text=read(loader);start=text.index('struct BlockLoaderT {')
anchor='  /* Iteration helper */'
pos=text.index(anchor,start)
addition='''  METAL_FUNC void load_paged(const device T* root, const device int* pages,
      const int offset, const int first, const int valid_rows) const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : 0;
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * kDstStrRow + j * kDstStrCol] = valid ? root[physical * src_ld + bj + j] : T(0);
      }
    }
  }

'''
edits[loader]=text[:pos]+addition+text[pos:]
steel='mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h'
text=read(steel)
text=text.replace('constant bool has_sinks [[function_constant(302)]];','constant bool has_sinks [[function_constant(302)]];\nconstant bool hyle_paged [[function_constant(303)]];')
text=text.replace('    const device T* sinks [[buffer(7), function_constant(has_sinks)]],','''    const device T* sinks [[buffer(7), function_constant(has_sinks)]],
    const device int* hyle_pages [[buffer(8), function_constant(hyle_paged)]],
    const constant int& hyle_offset [[buffer(9), function_constant(hyle_paged)]],''')
for letter in ['k','v']:
    before=f'    if (!align_K && kb == (params->NK_aligned)) {{\n      loader_{letter}.load_safe'
    assert text.count(before)==1,(letter,text.count(before))
    text=text.replace(before,f'''    if (hyle_paged) {{
      loader_{letter}.load_paged({letter.upper()}, hyle_pages, hyle_offset, kb * BK, params->kL - kb * BK);
    }} else if (!align_K && kb == (params->NK_aligned)) {{
      loader_{letter}.load_safe''')
    text=text.replace(f'    loader_{letter}.next();',f'    if (!hyle_paged) loader_{letter}.next();')
edits[steel]=text

# Record each bounded file transformation as an exact final-byte edit on top
# of existing edits, preserving all original cast/resource adaptations.
for name,after in edits.items():
    raw=(original/name).read_bytes().replace(b'\r\n',b'\n')
    patch=next((p for p in manifest['files'] if p['path']==name),None)
    if patch is None:
        patch={'path':name,'before_sha256':hashlib.sha256(raw).hexdigest(),'edits':[]};manifest['files'].append(patch)
    before=raw
    for e in patch['edits']:before=before.replace(e['before'].encode(),e['after'].encode(),1)
    if before.decode()!=after:
        # Store only differing contiguous chunks, each uniquely matched and
        # applied in reverse order so preceding contexts cannot shift.
        import difflib
        old=before.decode().splitlines(keepends=True);new=after.splitlines(keepends=True)
        matcher=difflib.SequenceMatcher(None,old,new,autojunk=False)
        current=before.decode()
        for tag,i1,i2,j1,j2 in reversed(matcher.get_opcodes()):
            if tag=='equal':continue
            lo=max(0,i1-1);hi=min(len(old),i2+1)
            original_chunk=''.join(old[lo:hi])
            while current.count(original_chunk)!=1:
                if lo>0:lo-=1
                elif hi<len(old):hi+=1
                else:raise AssertionError((name,'nonunique change'))
                original_chunk=''.join(old[lo:hi])
            replacement=''.join(old[lo:i1])+''.join(new[j1:j2])+''.join(old[i2:hi])
            patch['edits'].append({'before':original_chunk,'after':replacement})
            current=current.replace(original_chunk,replacement,1)
        assert current==after,name
    patch['after_sha256']=hashlib.sha256(after.encode()).hexdigest()
    path=preview/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(after.encode())
# Reapply every existing + new context before changing the canonical manifest.
for patch in manifest['files']:
    path=original/patch['path']
    if not path.exists():continue  # Existing unchanged files weren't re-fetched.
    data=path.read_bytes().replace(b'\r\n',b'\n')
    assert hashlib.sha256(data).hexdigest()==patch['before_sha256'],patch['path']
    for e in patch['edits']:
        b,a=e['before'].encode(),e['after'].encode();assert data.count(b)==1,(patch['path'],b[:100])
        data=data.replace(b,a,1)
    assert hashlib.sha256(data).hexdigest()==patch['after_sha256'],patch['path']
manifest_path.write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
print('verified native MLX page transformations:',len(edits),'files')
