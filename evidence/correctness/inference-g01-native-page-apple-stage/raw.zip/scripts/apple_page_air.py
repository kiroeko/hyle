from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified')
source=base/'source-c8874688'
out=base/'g01-native-page-apple-draft'
out.mkdir(exist_ok=True)
identity={name:subprocess.check_output(args,text=True).strip() for name,args in [
    ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),
    ('os',['sw_vers']),('compiler',['xcrun','clang','--version']),
    ('cpu',['sysctl','-n','hw.ncpu']),('memory',['sysctl','-n','hw.memsize'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
assert source.is_dir() and not (source/'.git').exists()
with zipfile.ZipFile(out/'input.zip') as archive:
    manifest=json.loads(archive.read('input-manifest.json'))
    copied=[]
    for item in manifest:
        rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
        data=archive.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        dest=source/rel
        if not dest.exists() or dest.read_bytes()!=data:
            dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);copied.append(item['path'])
        assert hashlib.sha256(dest.read_bytes()).hexdigest()==item['sha256']
(out/'synced-inputs.json').write_text(json.dumps({'one_way':True,'identity':identity,'inputs':manifest,'copied':copied},indent=2)+'\n')
parent=base/'a-cpu-apple/selected-graph/source-parent'
build=base/'a-cpu-apple/selected-graph/source-build'
target='hyle_g01_native_page_apple'
cmake=parent/'CMakeLists.txt'
addition=f'''
add_executable({target} "{source}/tests/compute_batch/native_paged_apple_consumer.cc")
target_compile_features({target} PRIVATE cxx_std_23)
target_link_libraries({target} PRIVATE hyle::compute)
target_compile_definitions({target} PRIVATE HYLE_G01_NATIVE_PAGE_APPLE=1)
hyle_stage_runtime({target})
'''
text=cmake.read_text()
if f'add_executable({target} ' not in text:cmake.write_text(text+addition)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
record=out/'result.json'
rows=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args):
    number=1+sum(r['stage']==stage for r in rows)
    log=out/f'{stage}-{number}.log';start=time.monotonic()
    with log.open('w') as handle:result=subprocess.run(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log),'inputs':manifest}
    rows.append(row);record.write_text(json.dumps({'scope':'AUDITED NP02/NP03 Apple page draft, actual GPU consumer; no CANDIDATE or whole-goal claim','identity':identity,'inputs':manifest,'stages':rows},indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k!='inputs'}),flush=True)
    if result.returncode:
        with log.open('rb') as data:data.seek(max(0,log.stat().st_size-5000));print(data.read().decode(errors='replace'),flush=True)
        raise SystemExit(result.returncode)
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target',target,'hyle_f5_materialized_native','--parallel','4'])
run('paged-math-final',[str(build/target)])
run('paged-long-math',[str(build/target),'--long-read'])
run('reference-regression',[str(build/'hyle_f5_materialized_native')])
print('TERMINAL PASS actual Apple page draft + original reference',flush=True)
