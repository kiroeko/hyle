from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
ROOT=Path('/mnt/c/public/project-hyle/hyle');OUT=ROOT/'.scratch/inference-gaps/g04-g05/cuda-native'
SOURCE=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
BUILD=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
assert SOURCE.is_dir() and not (SOURCE/'.git').exists() and (BUILD/'CMakeCache.txt').is_file()
with zipfile.ZipFile(sys.argv[1]) as package:
 inputs=json.loads(package.read('source-manifest.json'))
 for item in inputs:
  relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
  data=package.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
  target=SOURCE/relative
  if not target.exists() or target.read_bytes()!=data:
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
identity={key:subprocess.check_output(command,text=True).strip() for key,command in [
 ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
 ('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu','--format=csv,noheader'])]}
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
result={'state':'RUNNING','pid':os.getpid(),'identity':identity,'inputs':inputs,
 'scope':'CE04/08 actual source target compile only. No GPU/model/math/SDK/sanitizer/P1 pass',
 'max_jobs':4,'stages':[],'cumulative_seconds':0}
attempt=sys.argv[2]
def save():
 (OUT/f'compile-result-{attempt}.json').write_text(json.dumps(result,indent=2)+'\n')
save()
test_mode=int(attempt)>=3
target='hyle_compute_provider_flashinfer_test' if test_mode else 'hyle_compute_provider_flashinfer'
commands=[('compile',['cmake','--build',str(BUILD),'--target',target,'--parallel','4'])]
if attempt=='1':commands.insert(0,('configure',['cmake','-S',str(SOURCE),'-B',str(BUILD)]))
if test_mode:
 commands.insert(0,('configure',['cmake','-S',str(SOURCE),'-B',str(BUILD),'-DHYLE_INSTALL=OFF',
  '-DHYLE_BUILD_TESTS=ON','-DHYLE_TEST_INSTRUMENTATION=OFF']))
 commands.append(('tests',[str(BUILD/'bin/hyle_compute_provider_flashinfer_test'),
  '--gtest_output=xml:'+str(OUT/f'tests-{attempt}.xml')]))
 result['scope']='CE04/08 actual shipping factor plus bounded original/new FI tests; no model/heavy GPU/SDK/sanitizer/P1 acceptance'
for stage,command in commands:
 start=time.monotonic();log=OUT/f'{stage}-{attempt}.log'
 with log.open('w') as stream:
  process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}))
  print(f'{stage}: pid={process.pid}',flush=True);code=process.wait()
 elapsed=time.monotonic()-start
 result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 result['cumulative_seconds']+=elapsed;save();print(f'{stage}: exit={code}, elapsed={elapsed:.3f}s',flush=True)
 if code:
  result['state']='TERMINAL_FAIL';save();(OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
result['state']='TERMINAL_PASS';save();(OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
