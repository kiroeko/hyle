from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
ROOT=Path(__file__).resolve().parents[3];out=ROOT/'.scratch/inference-gaps/g04-g05/cuda-native'
attempt=sys.argv[1];out.mkdir(exist_ok=True);archive=out/f'source-{attempt}.zip';assert not archive.exists()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for path in sorted(set(paths)):
  if path.startswith(('evidence/','.scratch/','.git')):continue
  f=ROOT/path
  if not f.is_file():continue
  data=f.read_bytes();inputs.append({'path':path,'sha256':hashlib.sha256(data).hexdigest()});package.writestr(path,data)
 package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
(out/f'source-{attempt}-manifest.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8',newline='\n')
raise SystemExit(subprocess.run(['wsl','-d','Ubuntu-24.04','-u','root','--','python3',
 '/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/cuda_cache_compile.py',
 f'/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/cuda-native/source-{attempt}.zip',attempt]).returncode)
