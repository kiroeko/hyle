from pathlib import Path
import hashlib, json, sys, zipfile, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / '.scratch/inference-gaps/g04-g05/cuda-native'
OUT = ROOT / 'evidence/correctness/inference-g04-g05-cuda-encoding-math-stage'
last = int(sys.argv[1])
records = [json.loads((RUN / f'compile-result-{i}.json').read_text(encoding='utf-8'))
           for i in range(1, last + 1)]
assert all(r['state'].startswith('TERMINAL_') for r in records)
assert records[-1]['state'] == 'TERMINAL_PASS'
xml = ET.parse(RUN / f'tests-{last}.xml').getroot()
assert int(xml.attrib['tests']) == 12 and int(xml.attrib['failures']) == 0
inputs = {i['path']: i['sha256'] for i in records[-1]['inputs']
          if i['path'].startswith(('src/compute_backend_cuda/', 'src/compute_provider_flashinfer/',
                                   'tests/compute_provider_flashinfer/')) or i['path'] == 'cmake/HyleComponents.cmake'}
for path, digest in inputs.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest, path
OUT.mkdir(parents=True, exist_ok=False)
result = {
    'kind': 'G04_G05_CUDA_ENCODING_AND_NATIVE_MATH_SOURCE_STAGE',
    'verdict': 'PASS_FINITE_LINUX_CUDA_SOURCE_DOMAIN',
    'owners_remain': 'AUDITED; whole G04/G05 not accepted',
    'identity': records[-1]['identity'], 'input_sha256': inputs,
    'tests': {'final': 12, 'original': 4, 'new': 8},
    'qualified': [
        'FP8 E4M3FN encoder independent bytes: F16/BF16/F32 inputs, scales, ties, zero and saturation',
        'Accepted nonfinite encoder payload reports InvalidArgument through original Completion',
        'Direct paged/ragged FP8 K/V, independent sK=.5 and sV=2, F16/BF16 query/output',
        'Finite (64,64)/(128,128)/(256,256)/(64,128), window -1/0/15/16, full noncausal Q>KV',
        'D256 long prefill Q1/65 and KV129/145; paged logical274 over physical256',
        'Explicit split-KV8192 rows, +/-65536 values with sV512, F32 partial/merge then final scale/cast',
        'Plain window and independent Dv; long cancellation; original one-op math and cold allocation tests'],
    'not_proven': ['SDK static/shared', 'incremental F2 and Graph encoder/page journey',
                   'new domain host sanitizers/concurrency/allocation faults', 'qualified P1',
                   'Apple/Vulkan new domains', 'whole G04/G05'],
    'runs': [{k: v for k, v in r.items() if k != 'inputs'} for r in records],
    'cumulative_seconds': sum(r['cumulative_seconds'] for r in records),
    'P0': 'Only dirty encoding rows; FP8 staging align16(Qactive*Hq*Dv*4) counted in float budget; '
          'one final scale/cast dispatch, no full-KV expansion; original queues/slots/retirement/status reused',
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n',
                                 encoding='utf-8', newline='\n')
with zipfile.ZipFile(OUT / 'raw.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(RUN.iterdir()):
        if path.is_file() and path.suffix != '.zip':
            archive.write(path, path.name)
    for name in ['launch_cuda_cache_compile.py', 'cuda_cache_compile.py', 'seal_cuda_native_stage.py']:
        archive.write(RUN.parent / name, name)
print(json.dumps({'tests': 12, 'cumulative_seconds': result['cumulative_seconds']}))
