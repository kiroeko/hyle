$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$routeRoot='C:/hyle-scratch/r4-cuda-20260916/delivery'
$routeBuild="$routeRoot/isolation-backend-toplevel"
$routeLogs="$routeRoot/logs/isolation/backend-toplevel"
New-Item -ItemType Directory -Force -Path $routeLogs | Out-Null
cmake -S C:/public/project-hyle/hyle -B $routeBuild -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_DEV_FACTORS=compute_backend_cuda -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_BUILD_TESTS=OFF -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_STATIC=ON *> "$routeLogs/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$routeLogs/configure.log" -Tail 60; exit $LASTEXITCODE }
cmake --build $routeBuild --target help *> "$routeLogs/targets.txt"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$routeTargets=Get-Content "$routeLogs/targets.txt" -Raw
if ($routeTargets -notmatch '(?m)^hyle_compute_backend_cuda:') { throw 'backend-only target missing' }
foreach ($routeAbsent in @('compute_provider_cublas','compute_provider_marlin','compute_provider_cuda','compute_route_cuda','graph_route_cuda','compute_backend_cpu','compute_provider_native','compute_provider_onednn','graph_provider_onednn','compute_route_cpu','graph_route_cpu')) {
  if ($routeTargets -match ('(?m)^hyle_'+$routeAbsent+':')) { throw "Backend-only acquired $routeAbsent" }
}
Copy-Item -LiteralPath "$routeBuild/CMakeCache.txt" -Destination "$routeLogs/CMakeCache.txt"
'PASS: top-level CUDA backend-only target; no default providers, route factories, or CPU factors' | Tee-Object -FilePath "$routeLogs/verdict.txt"
