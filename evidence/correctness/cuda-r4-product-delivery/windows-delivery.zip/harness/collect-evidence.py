import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

repo = Path('C:/public/project-hyle/hyle')
scratch = Path('C:/hyle-scratch/r4-cuda-20260916/delivery')
dest = repo / 'evidence/correctness/cuda-r4-product-delivery'
dest.mkdir(parents=True, exist_ok=True)
candidate = 'f735271b725d2f3b1d9016dd35a2a9d7b0d43b5e'
baseline = 'd2e631b4e9eda584d94f5b9936f68e01f4a5a3c7'
paths = ['include/hyle/compute', 'include/hyle/graph', 'src/compute', 'src/graph',
         'src/compute_backend_cpu', 'src/compute_provider_native', 'src/compute_provider_onednn',
         'src/compute_route_cpu', 'src/graph_provider_onednn', 'src/graph_route_cpu']
trees = {}
for path in paths:
    before = subprocess.check_output(['git', 'rev-parse', f'{baseline}:{path}'], cwd=repo).decode().strip()
    after = subprocess.check_output(['git', 'rev-parse', f'{candidate}:{path}'], cwd=repo).decode().strip()
    assert before == after, path
    trees[path] = {'baseline_tree': before, 'candidate_tree': after}
proof = {'baseline': baseline, 'candidate': candidate, 'verdict': 'PASS', 'scope': 'eight old owners runtime/header source projection unchanged; no new CPU timing', 'trees': trees}
(dest / 'p0-unchanged.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
with zipfile.ZipFile(dest / 'windows-delivery.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((scratch / 'logs').rglob('*')):
        if path.is_file() and not path.name.startswith(('tool-', 'selector-configure')):
            archive.write(path, path.relative_to(scratch).as_posix())
    for folder in ('consumer', 'projection'):
        for path in sorted((scratch / folder).rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(scratch).as_posix())
    for path in sorted(scratch.iterdir()):
        if path.suffix in ('.py', '.ps1', '.sh') or path.name in ('candidate.txt', 'archive.sha256'):
            archive.write(path, 'harness/' + path.name)
for name in ('wsl-delivery.tar.gz', 'air-projection.tar.gz', 'mini-projection.tar.gz'):
    shutil.copyfile(scratch / name, dest / name)
shutil.copyfile(scratch / 'logs/loc.json', dest / 'loc-f735271b.json')
tool_dest = repo / 'evidence/correctness/validation-cuda-cpu-coexistence-v1'
tool_dest.mkdir(parents=True, exist_ok=True)
for name in ('selector-configure-preflight.log', 'tool-regression-before.log', 'tool-regression-after.log', 'tool-fix-validation.json'):
    shutil.copyfile(scratch / 'logs' / name, tool_dest / name)
for directory in (dest, tool_dest):
    manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.iterdir()) if p.is_file() and p.name not in ('sha256.json', 'README.md')}
    (directory / 'sha256.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
print('C5 delivery/P0 and tool before/after evidence retained; aggregate selector still pending')
