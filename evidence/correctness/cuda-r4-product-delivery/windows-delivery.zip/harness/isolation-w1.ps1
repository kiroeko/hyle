$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$routeRoot='C:/hyle-scratch/r4-cuda-20260916/delivery'
$routeSource='C:/public/project-hyle/hyle'
$env:HYLE_DEP_SOURCE_CACHE='C:/public/project-hyle/.deps'
foreach ($routeKind in @('none','cpu','core','backend')) {
  $routeBuild="$routeRoot/isolation-$routeKind"
  $routeLogs="$routeRoot/logs/isolation/$routeKind"
  New-Item -ItemType Directory -Force -Path $routeLogs | Out-Null
  $routeArgs=@('-S',"$routeRoot/projection",'-B',$routeBuild,'-G','Ninja',"-DR4_SOURCE=$routeSource","-DR4_KIND=$routeKind",'-DCMAKE_BUILD_TYPE=Release')
  if ($routeKind -ne 'backend') { $routeArgs+='-DCMAKE_DISABLE_FIND_PACKAGE_CUDAToolkit=TRUE' }
  cmake @routeArgs *> "$routeLogs/configure.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$routeLogs/configure.log" -Tail 80; exit $LASTEXITCODE }
  Copy-Item -LiteralPath "$routeBuild/CMakeCache.txt" -Destination "$routeLogs/CMakeCache.txt"
  if ($routeKind -eq 'backend') { Write-Output 'backend-only default-provider absence PASS'; continue }
  python "$routeRoot/check-projection.py" $routeKind "$routeBuild/hyle_build" "$routeLogs/projection.json"
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
  Copy-Item -LiteralPath "$routeBuild/hyle_build/HyleConfig.cmake","$routeBuild/hyle_build/cmake_install.cmake" -Destination $routeLogs
  if ($routeKind -in @('none','cpu')) {
    cmake --build $routeBuild --parallel 2 *> "$routeLogs/build.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$routeLogs/build.log" -Tail 80; exit $LASTEXITCODE }
    foreach ($routeProduct in @('compute','graph')) {
      foreach ($routeDll in @('msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll')) {
        Copy-Item -LiteralPath "C:/Windows/System32/$routeDll" -Destination "$routeBuild/$routeProduct" -Force
      }
    }
    ctest --test-dir $routeBuild --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 *> "$routeLogs/tests.log"
    $routeVerdict=$LASTEXITCODE
    Get-Content "$routeLogs/tests.log" -Tail 15
    if ($routeVerdict -ne 0) { exit $routeVerdict }
    cmake --install $routeBuild --prefix "$routeRoot/isolation-sdk-$routeKind" *> "$routeLogs/install.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$routeLogs/install.log" -Tail 50; exit $LASTEXITCODE }
    Get-ChildItem -LiteralPath "$routeRoot/isolation-sdk-$routeKind" -Recurse -File | ForEach-Object { $_.FullName } | Set-Content -LiteralPath "$routeLogs/installed-files.txt" -Encoding utf8
  }
}
