$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$routeRoot='C:/hyle-scratch/r4-cuda-20260916/delivery'
$routeBuild="$routeRoot/w1-source-shared"
$routeSource='C:/public/project-hyle/hyle'
$dlls=@('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cudart64_13.dll','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cublasLt64_13.dll','C:/Windows/System32/msvcp140.dll','C:/Windows/System32/msvcp140_atomic_wait.dll','C:/Windows/System32/vcruntime140.dll','C:/Windows/System32/vcruntime140_1.dll')
foreach ($routeLinkage in @('shared','static')) {
 $routeLog="$routeRoot/logs/w1-$routeLinkage"
 New-Item -ItemType Directory -Force -Path $routeLog | Out-Null
 if ($routeLinkage -eq 'static') {
  cmake -S "$routeRoot/consumer" -B $routeBuild -DHYLE_STATIC=ON -DBUILD_SHARED_LIBS=OFF *> "$routeLog/configure.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$routeLog/configure.log" -Tail 65; exit $LASTEXITCODE }
  cmake --build $routeBuild --parallel 2 *> "$routeLog/build.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$routeLog/build.log" -Tail 95; exit $LASTEXITCODE }
 }
 $routeStage="$routeRoot/w1-sdk-$routeLinkage"
 $routeSdk="$routeRoot/w1-sdk-$routeLinkage-relocated"
 if ((Test-Path -LiteralPath $routeStage) -or (Test-Path -LiteralPath $routeSdk)) { throw 'Fresh SDK path already exists' }
 cmake --install $routeBuild --prefix $routeStage *> "$routeLog/install.log"
 if ($LASTEXITCODE -ne 0) { Get-Content "$routeLog/install.log" -Tail 65; exit $LASTEXITCODE }
 $routeAllowed=[IO.Path]::GetFullPath($routeRoot)+'\'
 foreach ($routePath in @($routeStage,$routeSdk)) {
  if (-not [IO.Path]::GetFullPath($routePath).StartsWith($routeAllowed,[StringComparison]::OrdinalIgnoreCase)) { throw 'Relocation path escaped task root' }
 }
 Move-Item -LiteralPath $routeStage -Destination $routeSdk
 $routeConsumer="$routeRoot/w1-consume-$routeLinkage"
 cmake -S "$routeRoot/consumer" -B $routeConsumer -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$routeSdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$routeSource" *> "$routeLog/consumer-configure.log"
 if ($LASTEXITCODE -ne 0) { Get-Content "$routeLog/consumer-configure.log" -Tail 90; exit $LASTEXITCODE }
 cmake --build $routeConsumer --parallel 1 *> "$routeLog/consumer-build.log"
 if ($LASTEXITCODE -ne 0) { Get-Content "$routeLog/consumer-build.log" -Tail 90; exit $LASTEXITCODE }
 foreach ($product in @('compute','graph')) { foreach ($dll in $dlls) { Copy-Item -LiteralPath $dll -Destination "$routeConsumer/$product" -Force } }
 ctest --test-dir $routeConsumer --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 *> "$routeLog/consumer-test.log"
 $routeVerdict=$LASTEXITCODE
 Copy-Item -LiteralPath "$routeConsumer/Testing/Temporary/LastTest.log" -Destination "$routeLog/LastTest.log"
 Get-Content "$routeLog/consumer-test.log" -Tail 25
 if ($routeVerdict -ne 0) { exit $routeVerdict }
 Copy-Item -LiteralPath "$routeBuild/CMakeCache.txt" -Destination "$routeLog/CMakeCache.txt"
 Get-ChildItem -LiteralPath $routeSdk -Recurse -File | ForEach-Object { $_.FullName.Substring($routeSdk.Length+1) } | Set-Content -LiteralPath "$routeLog/installed-files.txt" -Encoding utf8
}
