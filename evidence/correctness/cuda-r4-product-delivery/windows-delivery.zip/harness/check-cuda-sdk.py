import hashlib
import json
import pathlib
import re
import sys

sdk, source, output = map(pathlib.Path, sys.argv[1:])
required_headers = ['compute/cuda.h', 'graph/cuda.h', 'compute/backends/cuda.h',
                    'compute/providers/cublas.h', 'compute/providers/marlin.h', 'compute/providers/cuda.h']
absent_headers = ['compute/cpu.h', 'graph/cpu.h', 'compute/backends/cpu.h',
                  'compute/providers/native.h', 'compute/providers/onednn.h', 'graph/providers/onednn.h']
for name in required_headers:
    assert (sdk / 'include/hyle' / name).read_bytes() == (source / 'include/hyle' / name).read_bytes(), name
for name in absent_headers:
    assert not (sdk / 'include/hyle' / name).exists(), name
package = sdk / 'lib/cmake/Hyle'
config = (package / 'HyleConfig.cmake').read_text()
exports = (package / 'HyleTargets.cmake').read_text()
assert 'CUDAToolkit|13.3' in config
assert 'set(Hyle_AVAILABLE_FEATURES "compute_cuda")' in config
factors = re.findall(r'add_library\(hyle::_factor_(\w+) ', exports)
for name in ('compute_backend_cuda', 'compute_provider_cublas', 'compute_provider_marlin',
             'compute_provider_cuda', 'compute_route_cuda', 'graph_route_cuda'):
    assert name in factors, name
for name in ('compute_backend_cpu', 'compute_provider_native', 'compute_provider_onednn',
             'compute_route_cpu', 'graph_provider_onednn', 'graph_route_cpu', 'simd'):
    assert name not in factors, name
assert 'HYLE_COMPUTE_CPU' not in exports and 'HYLE_COMPUTE_CUDA=1' in exports
for suffix in ('LICENSE', 'NOTICE'):
    assert (sdk / 'share/licenses/Hyle' / f'marlin-{suffix}').read_bytes() == (source / 'third_party/marlin' / suffix).read_bytes()
assert str(source).replace('\\', '/') not in exports
record = {'result': 'PASS', 'sdk': str(sdk), 'factors': factors,
          'required_headers': required_headers, 'absent_headers': absent_headers,
          'checks': ['CUDA 13.3 find dependency', 'actual source-equal public headers', 'CUDA-only exported factors',
                     'Marlin LICENSE/NOTICE byte equality', 'no canonical source path in exports'],
          'package_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.glob('*.cmake'))}}
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(f'{sdk.name}: CUDA headers/factors/dependencies/licenses PASS')
