#!/usr/bin/env bash
set -euo pipefail
r4_root=/root/hyle-validation/r4-cuda-f735271b
r4_windows=/mnt/c/hyle-scratch/r4-cuda-20260916/delivery
test ! -e "$r4_root"
mkdir -p "$r4_root/source" "$r4_root/consumer"
test "$(sha256sum "$r4_windows/f735271b.tar.gz" | cut -d' ' -f1)" = "$(cat "$r4_windows/archive.sha256")"
tar -xzf "$r4_windows/f735271b.tar.gz" -C "$r4_root/source"
cp "$r4_windows/candidate.txt" "$r4_windows/archive.sha256" "$r4_windows/verify-wsl.sh" "$r4_root/"
cp "$r4_windows/consumer/CMakeLists.txt" "$r4_root/consumer/"
