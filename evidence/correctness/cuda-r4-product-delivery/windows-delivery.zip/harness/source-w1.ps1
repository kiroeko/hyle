$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$routeRoot='C:/hyle-scratch/r4-cuda-20260916/delivery'
$routeBuild="$routeRoot/w1-source-shared"
$routeSource='C:/public/project-hyle/hyle'
$routeLog="$routeRoot/logs/w1-source"
New-Item -ItemType Directory -Force -Path $routeLog | Out-Null
$env:HYLE_DEP_SOURCE_CACHE='C:/public/project-hyle/.deps'
cmake -S "$routeRoot/consumer" -B $routeBuild -G Ninja -DCMAKE_BUILD_TYPE=Release "-DHYLE_SOURCE_DIR=$routeSource" "-DHYLE_SAMPLE_SOURCE_ROOT=$routeSource" -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_ONEDNN=AUTO -DHYLE_BUILD_TESTS=OFF -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=ON -DHYLE_STATIC=OFF -DHYLE_WERROR=ON -DHYLE_TEST_INSTRUMENTATION=OFF *> "$routeLog/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$routeLog/configure.log" -Tail 80; exit $LASTEXITCODE }
cmake --build $routeBuild --parallel 2 *> "$routeLog/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$routeLog/build.log" -Tail 100; exit $LASTEXITCODE }
$dlls=@('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cudart64_13.dll','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cublasLt64_13.dll','C:/Windows/System32/msvcp140.dll','C:/Windows/System32/msvcp140_atomic_wait.dll','C:/Windows/System32/vcruntime140.dll','C:/Windows/System32/vcruntime140_1.dll')
foreach ($product in @('compute','graph')) { foreach ($dll in $dlls) { Copy-Item -LiteralPath $dll -Destination "$routeBuild/$product" -Force } }
$dlls | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$routeLog/runtime.json" -Encoding utf8
ctest --test-dir $routeBuild --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 *> "$routeLog/test.log"
$result=$LASTEXITCODE
Copy-Item -LiteralPath "$routeBuild/Testing/Temporary/LastTest.log" -Destination "$routeLog/LastTest.log"
Get-Content "$routeLog/test.log" -Tail 55
exit $result
