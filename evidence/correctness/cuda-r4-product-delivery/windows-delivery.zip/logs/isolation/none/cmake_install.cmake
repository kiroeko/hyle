# Install script for directory: C:/public/project-hyle/hyle

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "C:/Program Files (x86)/hyle_r4_isolation")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/core/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/container_intrusive/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/util_core/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/error/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/time/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/math/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/platform/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/platform_thread/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/mem/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/container/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute_ops/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/graph/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute_backend_cuda/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute_provider_cublas/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute_provider_marlin/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute_provider_cuda/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute_route_cuda/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/graph_route_cuda/cmake_install.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/error/hyle_error.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/time/hyle_time.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/platform/hyle_platform.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/platform_thread/hyle_platform_thread.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/mem/hyle_mem.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/container/hyle_container.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute/hyle_compute.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/graph/hyle_graph.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/compute_ops/hyle_compute_ops.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/src/mem/mimalloc_static.lib")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/core/assert.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/core/cache.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/core/compiler.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/core/detail/compiler_attributes.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/core/detail/preprocessor.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/core/environment.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/version.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/detail/intrusive_member.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/intrusive_forward_list.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/intrusive_hlist.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/intrusive_list.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/borrow.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/function_ref.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/random.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/ref_counted.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/scope_guard.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/spin_lock.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/type_name.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/util" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/util/unique_resource.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/error" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/error/format.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/error" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/error/result.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/error" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/error/status.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/error" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/error/system_error.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/math" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/math/scalar.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/time" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/time/clock.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/time" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/time/native_interop.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/time" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/time/unix_timestamp.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/cpu.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/cpu_convenience.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/dynlib.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/environment.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/environment_convenience.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/host_memory.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/numa.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/process.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/random.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/virtual_memory.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/thread.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/thread_convenience.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/thread_visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/platform" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/platform/wait.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/alignment.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/allocator.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/arena.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/buffer.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/buffer_pool.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/fixed_pool.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/growable_pool.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/heap.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/large_page_reservation.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/lifetime_plan.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/object_pool.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/pmr.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/pool.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/pool_cache.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/pool_loan.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/quota_allocator.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/range_allocator.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/region.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/resource.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/shared_pool.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/stack_allocator.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/stats.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/std_allocator.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/system_inline.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/mem" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/mem/visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/btree.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/btree_map.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/btree_set.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/circular_buffer.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/detail/adaptive_mutex.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/detail/adaptive_rw_lock.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/detail/flat_hash_probe.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/detail/flat_hash_table.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/dynamic_bitset.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/flat_hash_map.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/flat_hash_set.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/flat_map.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/flat_set.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/flat_sorted.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/hash.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/inplace_vector.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/lru_cache.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/pod_vector.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/ring_deque.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/small_vector.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/sparse_set.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/static_vector.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/container" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/container/visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/completion.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/custom_kernel.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/delegated_operation.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/backend_extension.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/command_capture.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/completion_access.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/context_ref.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/generated_result.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/prepared_callbacks.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/provider_extension.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/queue_sequence.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute/detail" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/detail/resource_binding.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/device.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/prepared_operation.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/provider.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/resource_requirement.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/result.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/tensor.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/transfer.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/graph" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/graph/executable.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/graph" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/graph/graph.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/graph" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/graph/region_provider.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/graph" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/graph/visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/operation.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/ops_visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/compute" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/compute/tensor_desc.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/obs" TYPE FILE FILES "C:/public/project-hyle/hyle/include/hyle/obs/trace.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "HYLE-LICENSE" FILES "C:/public/project-hyle/hyle/LICENSE")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "THIRD_PARTY-NOTICES.md" FILES "C:/public/project-hyle/hyle/THIRD_PARTY_NOTICES.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "highway-upstream-LICENSE" FILES "C:/public/project-hyle/.deps/sources/highway-18e449b64259-b2ddaa056705/LICENSE")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "rust-parker-LICENSE-MIT" FILES "C:/public/project-hyle/hyle/third_party/ported/LICENSE-RUST")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "mimalloc-LICENSE" FILES "C:/public/project-hyle/hyle/third_party/mimalloc/LICENSE")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "xxhash-LICENSE" FILES "C:/public/project-hyle/hyle/third_party/xxhash/LICENSE")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "wyhash-LICENSE" FILES "C:/public/project-hyle/hyle/third_party/wyhash/LICENSE")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets.cmake")
    file(DIFFERENT _cmake_export_file_changed FILES
         "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets.cmake"
         "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/CMakeFiles/Export/7d59d35bec50044b093b33bd79dfe56a/HyleTargets.cmake")
    if(_cmake_export_file_changed)
      file(GLOB _cmake_old_config_files "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets-*.cmake")
      if(_cmake_old_config_files)
        string(REPLACE ";" ", " _cmake_old_config_files_text "${_cmake_old_config_files}")
        message(STATUS "Old export file \"$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets.cmake\" will be replaced.  Removing files [${_cmake_old_config_files_text}].")
        unset(_cmake_old_config_files_text)
        file(REMOVE ${_cmake_old_config_files})
      endif()
      unset(_cmake_old_config_files)
    endif()
    unset(_cmake_export_file_changed)
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle" TYPE FILE FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/CMakeFiles/Export/7d59d35bec50044b093b33bd79dfe56a/HyleTargets.cmake")
  if(CMAKE_INSTALL_CONFIG_NAME MATCHES "^([Rr][Ee][Ll][Ee][Aa][Ss][Ee])$")
    file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle" TYPE FILE FILES "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/CMakeFiles/Export/7d59d35bec50044b093b33bd79dfe56a/HyleTargets-release.cmake")
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle" TYPE FILE FILES
    "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/HyleConfig.cmake"
    "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/HyleConfigVersion.cmake"
    "C:/public/project-hyle/hyle/cmake/HyleRuntimeStaging.cmake"
    )
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "C:/hyle-scratch/r4-cuda-20260916/delivery/isolation-none/hyle_build/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
