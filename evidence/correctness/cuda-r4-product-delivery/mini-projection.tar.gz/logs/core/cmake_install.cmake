# Install script for directory: /Users/kiro/hyle-validation/r4-delivery-f735271b/source

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/Users/kiro/hyle-validation/r4-delivery-f735271b/build-core/hyle_build/src/core/cmake_install.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/core/assert.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/core/cache.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/core/compiler.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core/detail" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/core/detail/compiler_attributes.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core/detail" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/core/detail/preprocessor.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle/core" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/core/environment.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/version.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/hyle" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/include/hyle/visibility.h")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "HYLE-LICENSE" FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/LICENSE")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Runtime" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/licenses/Hyle" TYPE FILE RENAME "THIRD_PARTY-NOTICES.md" FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/THIRD_PARTY_NOTICES.md")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets.cmake")
    file(DIFFERENT _cmake_export_file_changed FILES
         "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets.cmake"
         "/Users/kiro/hyle-validation/r4-delivery-f735271b/build-core/hyle_build/CMakeFiles/Export/7d59d35bec50044b093b33bd79dfe56a/HyleTargets.cmake")
    if(_cmake_export_file_changed)
      file(GLOB _cmake_old_config_files "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets-*.cmake")
      if(_cmake_old_config_files)
        string(REPLACE ";" ", " _cmake_old_config_files_text "${_cmake_old_config_files}")
        message(STATUS "Old export file \"$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle/HyleTargets.cmake\" will be replaced.  Removing files [${_cmake_old_config_files_text}].")
        unset(_cmake_old_config_files_text)
        file(REMOVE ${_cmake_old_config_files})
      endif()
      unset(_cmake_old_config_files)
    endif()
    unset(_cmake_export_file_changed)
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle" TYPE FILE FILES "/Users/kiro/hyle-validation/r4-delivery-f735271b/build-core/hyle_build/CMakeFiles/Export/7d59d35bec50044b093b33bd79dfe56a/HyleTargets.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Hyle_Development" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/Hyle" TYPE FILE FILES
    "/Users/kiro/hyle-validation/r4-delivery-f735271b/build-core/hyle_build/HyleConfig.cmake"
    "/Users/kiro/hyle-validation/r4-delivery-f735271b/build-core/hyle_build/HyleConfigVersion.cmake"
    "/Users/kiro/hyle-validation/r4-delivery-f735271b/source/cmake/HyleRuntimeStaging.cmake"
    )
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/Users/kiro/hyle-validation/r4-delivery-f735271b/build-core/hyle_build/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
