#!/usr/bin/env bash
set -euo pipefail
r4_root=$1
r4_cmake=$2
export PATH="$(dirname "$r4_cmake"):/opt/homebrew/bin:$PATH"
cd "$r4_root"
printf '%s  %s\n' 28d3d95779b5c2199871303a1602deba42edb736f7b8e7fb9cd271a1b014f609 f735271b.tar.gz | shasum -a 256 -c -
mkdir -p logs
if [ ! -e source/CMakeLists.txt ]; then
  mkdir -p source
  tar -xzf f735271b.tar.gz -C source
fi
uname -a >logs/machine.txt
xcrun clang++ --version >>logs/machine.txt
for kind in none cpu core; do
  r4_logs="$r4_root/logs/$kind"
  mkdir -p "$r4_logs"
  if ! bash source/scripts/hyle-unix.sh "$r4_cmake" -S projection -B "$r4_root/build-$kind" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 \
    "-DR4_SOURCE=$r4_root/source" "-DR4_KIND=$kind" -DCMAKE_DISABLE_FIND_PACKAGE_CUDAToolkit=TRUE \
    >"$r4_logs/configure.log" 2>&1; then
    tail -n 70 "$r4_logs/configure.log"
    exit 1
  fi
  python3 check-projection.py "$kind" "$r4_root/build-$kind/hyle_build" "$r4_logs/projection.json"
  cp "$r4_root/build-$kind/CMakeCache.txt" "$r4_logs/CMakeCache.txt"
  cp "$r4_root/build-$kind/hyle_build/HyleConfig.cmake" "$r4_logs/HyleConfig.cmake"
  cp "$r4_root/build-$kind/hyle_build/cmake_install.cmake" "$r4_logs/cmake_install.cmake"
done
echo 'R4 CUDA-OFF macOS configure/publishing projection PASS; no CUDA runtime claim'
