from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys

repo = Path.cwd()
attempt = sys.argv[1] if len(sys.argv) > 1 else '1'
route = sys.argv[2] if len(sys.argv) > 2 else 'vulkan'
assert route in ['vulkan', 'cpu-cuda']
root = repo / '.scratch/foundation-f3' / ('math-source-windows-' + route + '-' + attempt)
assert not root.exists()
root.mkdir()
parent = Path('C:/h7/w-' + route + '/selected-graph/source-parent')
build = parent.parent / 'source-build'
file = parent / 'CMakeLists.txt'
text = file.read_text()
original_text = text
for target, sample in [('hyle_f3_file_streaming', 'main.cc'), ('hyle_f3_qwen_file_streaming', 'qwen_main.cc')]:
    if target not in text:
        text += '\nadd_executable(' + target + ' "' + (repo / 'samples/package/graph/file_streaming' / sample).as_posix() + '")\n'
        text += 'target_link_libraries(' + target + ' PRIVATE hyle::graph)\nhyle_stage_runtime(' + target + ')\n'
if text != original_text:
    file.write_bytes(text.encode())
spec = importlib.util.spec_from_file_location('hyle_header_env', repo / 'scripts/header-self-contained.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
compiler = 'C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'
env = module.visual_studio_environment('', 'x64', '', compiler)
env['VSLANG'] = '1033'
cmake = shutil.which('cmake', path=env['PATH'])
manifest = repo / '.scratch/foundation-f3/qwen-consumer-input/ranges.tsv'
record = {'baseline': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'scope': 'Actual Windows ' + route + ' small mature GGUF BF16/F32/Q8 and checked local Qwen BF16/F32 file roundtrip Direct+Graph; source only',
          'build': str(build), 'route': route, 'compiler': compiler, 'parallel': 1, 'stages': [],
          'samples': {name: hashlib.sha256((repo / 'samples/package/graph/file_streaming' / name).read_bytes()).hexdigest() for name in ['main.cc', 'qwen_main.cc', 'qwen_input.h']},
          'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest()}
class MemoryStatus(ctypes.Structure):
    _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [(str(i), ctypes.c_ulonglong) for i in range(7)]
for name, command, timeout in [
    ('configure', [cmake, '-S', str(parent), '-B', str(build)], 300),
    ('build', [cmake, '--build', str(build), '--target', 'hyle_f3_file_streaming', 'hyle_f3_qwen_file_streaming', '--parallel', '1'], 1800),
    ('math', [str(build / 'hyle_f3_file_streaming.exe'), str(repo / '.scratch/foundation-f3/gguf-consumer-input/gguf-ranges.tsv')], 180),
    ('qwen', [str(build / 'hyle_f3_qwen_file_streaming.exe'), str(manifest)], 180),
]:
    memory = MemoryStatus(); memory.length = ctypes.sizeof(memory)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory))
    available = getattr(memory, '1'); assert available >= 4 * 1024**3
    if '--parallel' in command:
        record['parallel'] = 4 if available >= 12 * 1024**3 else 2 if available >= 8 * 1024**3 else 1
        command[command.index('--parallel') + 1] = str(record['parallel'])
    log = root / (name + '.log')
    runtime = env.copy()
    if name != 'build':
        runtime['PATH'] = str(build) + ';' + str(build / 'hyle/bin') + ';C:/Windows/System32;C:/Windows'
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=repo, env=runtime, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'available_bytes': available, 'log': log.name}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill(); process.wait(); row.update(state='terminal', verdict='TIMEOUT')
            (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
record['verdict'] = 'PASS_SOURCE_WINDOWS_' + route.upper().replace('-', '_') + '_FILE_MATH_AND_QWEN_ONLY'
(root / 'job.json').write_text(json.dumps(record, indent=2))
