from pathlib import Path
import hashlib
import json
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'
subjects = [(scratch / 'source-current-air-cpu-apple', 'Air CPU/Apple'),
            (scratch / 'source-current-air-vulkan', 'Air Vulkan'),
            (scratch / 'foundation-f3-math-97858fbc8-logs', 'WSL CPU/CUDA'),
            (scratch / 'math-source-windows-vulkan-suffix-final-source', 'Windows Vulkan')]
rows = []
for folder, label in subjects:
    job = json.loads((folder / 'job.json').read_text())
    for stage in job['stages']:
        assert stage['state'] == 'terminal' and stage['exit_code'] == 0
        assert hashlib.sha256((folder / stage['log']).read_bytes()).hexdigest() == stage['sha256']
    assert all(any(row['name'] == name for row in job['stages']) for name in ['build', 'math', 'qwen'])
    assert '75497984' in (folder / 'qwen.log').read_text() and '226493952' in (folder / 'qwen.log').read_text()
    rows.append({'routes': label, 'source_identity': job.get('candidate', job.get('baseline')),
                 'identity': job.get('identity', job.get('compiler')), 'parallel': job.get('parallel')})
out = repo / 'evidence/correctness/foundation-f3-final-source'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for folder, label in subjects:
        for path in sorted(folder.iterdir()):
            if path.is_file(): packed.writestr(label.replace(' ', '-') + '/' + path.name, path.read_bytes())
    for name in ['run_math_air.py', 'run_math_vulkan_windows.py', 'run_wsl_gates.py', 'seal_final_source.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1, 'product_commit': '97858fbc88a6b5a87f109290b956eeaeee632dd2',
    'scope': 'Current ordinary source Graph/selected route small mature encoded weight and real Qwen full file/math roundtrip only.',
    'runs': rows, 'windows_cpu_cuda': 'Same product source-math/source-qwen explicitly run and sealed in foundation-f3-sdk-windows-cpu-cuda-static-f6db4d5b2.',
    'source_subject': 'Admitted readonly original file ranges -> fixed 2MiB stage/two slots -> early Direct+Graph -> new temporary sink -> bounded byte oracle -> same pool reload -> Direct+Graph reference.',
    'input': 'Original header and exact three BF16 projections plus F32 norm, 75,497,984 bytes. Checked official Safetensors and mature GGUF adapters; no whole checkpoint read/transfer/hash.',
    'encoding': 'CPU/CUDA/Vulkan mature GGUF Q8; Apple original affine Q4. Existing providers/kernels only.',
    'original_warnings': 'Locked WSL CUDA leaf 12/13 linker warnings retained; actual ordinary source correctness ran successfully.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_CURRENT_F3_ALL_APPLICABLE_SOURCE_MATH_AND_QWEN_ONLY',
    'limits': 'Bounded exact ranges and named machines only; no full model/FFN/tokenizer/generation or throughput winner.'}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('Current Air/WSL/Windows Vulkan ordinary source journeys verified; Windows CPU/CUDA source sealed separately.')
