from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

candidate, route = sys.argv[1:]
assert len(candidate) == 40 and route in ['cpu-apple', 'vulkan']
base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
assert candidate in (source / 'SOURCE-MANIFEST.txt').read_text()
parent = base / ('a-' + route) / 'selected-graph/source-parent'
build = parent.parent / 'source-build'
root = base / ('foundation-f3-math-' + route + '-' + candidate[:9])
assert not root.exists(); root.mkdir()
file = parent / 'CMakeLists.txt'; text = file.read_text()
original_text = text
for target, sample in [('hyle_f3_file_streaming', 'main.cc'), ('hyle_f3_qwen_file_streaming', 'qwen_main.cc')]:
    if target not in text:
        text += '\nadd_executable(' + target + ' "' + str(source / 'samples/package/graph/file_streaming' / sample) + '")\n'
        text += 'target_link_libraries(' + target + ' PRIVATE hyle::graph)\nhyle_stage_runtime(' + target + ')\n'
if text != original_text: file.write_text(text)
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
identity = {key: subprocess.check_output(command, text=True, env=env).strip() for key, command in [
    ('hardware', ['sysctl', '-n', 'hw.model']), ('memory', ['sysctl', '-n', 'hw.memsize']),
    ('os', ['sw_vers']), ('compiler', ['clang++', '--version']), ('cmake', ['/opt/homebrew/bin/cmake', '--version']),
    ('ninja', ['/opt/homebrew/bin/ninja', '--version'])]}
assert identity['hardware'] == 'Mac16,12'
manifest = base / 'foundation-f3-qwen-input/ranges.tsv'
record = {'candidate': candidate, 'source': str(source), 'build': str(build), 'route': route,
          'scope': 'F3 ordinary source mathematical consumers only, bounded original Qwen ranges in checksum-verified sparse verification mirror, no full model or installed SDK claim',
          'identity': identity, 'parallel': 1, 'stages': [],
          'samples': {name: hashlib.sha256((source / 'samples/package/graph/file_streaming' / name).read_bytes()).hexdigest() for name in ['main.cc', 'qwen_main.cc', 'qwen_input.h']},
          'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest()}
def available():
    page = int(subprocess.check_output(['sysctl', '-n', 'hw.pagesize'], text=True, env=env))
    stats = subprocess.check_output(['vm_stat'], text=True, env=env)
    total = 0
    for name in ['free', 'inactive', 'speculative']:
        match = re.search(r'Pages ' + name + r':\s*(\d+)', stats); assert match
        total += int(match.group(1))
    return total * page
for name, command, timeout in [
    ('configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build)], 300),
    ('build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', 'hyle_f3_file_streaming', 'hyle_f3_qwen_file_streaming', '--parallel', '1'], 1800),
    ('math', [str(build / 'hyle_f3_file_streaming'), str(base / 'foundation-f3-gguf-input/gguf-ranges.tsv')], 180),
    ('qwen', [str(build / 'hyle_f3_qwen_file_streaming'), str(manifest)], 180),
]:
    free = available(); assert free >= 4 * 1024**3, free
    if '--parallel' in command:
        record['parallel'] = 4 if free >= 12 * 1024**3 else 2 if free >= 8 * 1024**3 else 1
        command[command.index('--parallel') + 1] = str(record['parallel'])
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=output, stderr=subprocess.STDOUT)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'available_bytes': free, 'log': log.name}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill(); process.wait(); row.update(state='terminal', verdict='TIMEOUT')
            (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
record['verdict'] = 'PASS_SOURCE_AIR_' + route.upper() + '_FILE_MATH_AND_QWEN_ONLY'
(root / 'job.json').write_text(json.dumps(record, indent=2))
