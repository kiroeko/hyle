from pathlib import Path
import subprocess,json,time,sys,os
mode=sys.argv[1];assert mode in ('asan','ubsan','tsan')
repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/inference-gaps/g01';source=Path('/home/kiro/hyle-f1/sanitizers/source-03242e7723cb');build=source.parent/(mode+'-03242e7723cb')
hook=Path('/root/hyle-scratch/compute-unified')/('foundation-f5-'+mode+'-77df1c10c/cpu-consumer.cmake');body=hook.read_text()
if 'g01_cpu_attention' not in body:
 body+='\nfunction(g01_add_cpu_attention)\nset(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\nadd_subdirectory(/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-gtest EXCLUDE_FROM_ALL)\nadd_executable(g01_cpu_attention "'+str(source/'tests/compute_provider_ggml/layout_broadcast_test.cc')+'")\ntarget_compile_features(g01_cpu_attention PRIVATE cxx_std_23)\ntarget_link_libraries(g01_cpu_attention PRIVATE hyle::compute GTest::gtest_main hyle_compute_provider_ggml hyle_compute_backend_cpu hyle_simd)\nhyle_apply_sanitizer(g01_cpu_attention)\nhyle_stage_runtime(g01_cpu_attention)\nendfunction()\ncmake_language(DEFER CALL g01_add_cpu_attention)\n'
 hook.write_text(body)
body=hook.read_text()
gtest='set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\nadd_subdirectory(/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-gtest EXCLUDE_FROM_ALL)\n'
if 'function(g01_add_cpu_attention)\n'+gtest in body:
 body=body.replace('function(g01_add_cpu_attention)\n'+gtest,gtest+'function(g01_add_cpu_attention)\n')
 hook.write_text(body)
body=hook.read_text()
body=body.replace(gtest,'')
hook.write_text(body)
project_hook=out/('cpu-'+mode+'-project.cmake')
project_hook.write_text('''get_property(_g01_gtest GLOBAL PROPERTY G01_GTEST_ADMITTED)
if(NOT _g01_gtest AND PROJECT_NAME STREQUAL "hyle")
  set_property(GLOBAL PROPERTY G01_GTEST_ADMITTED TRUE)
  set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
  add_subdirectory(/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-gtest EXCLUDE_FROM_ALL)
endif()
''')
result_file=out/('cpu-'+mode+'-result.json');old=json.loads(result_file.read_text()) if result_file.exists() else None;records=old['stages'] if old else []
def run(name,args,env=None):
 attempt=1+sum(x['stage']==name for x in records);log=out/('cpu-'+mode+'-'+name+'-'+str(attempt)+'.log');started=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','mode':mode,'scope':'CPU original ggml resident attention + lifecycle/control tests; not GPU/driver qualification','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1800));print(f.read(1800).decode('utf-8',errors='replace'))
  raise SystemExit(r.returncode)
run('configure',['cmake','-S',str(source),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(project_hook)])
run('build',['cmake','--build',str(build),'--target','g01_cpu_attention','--parallel','4'])
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True));flag={'asan':'-fsanitize=address','ubsan':'-fsanitize=undefined','tsan':'-fsanitize=thread'}[mode];checked=[]
for name in ['src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/layout_broadcast_test.cc']:
 rows=[x for x in commands if x['file'].endswith(name)];assert rows and all(flag in x['command'] for x in rows),name;checked+=rows
(out/('cpu-'+mode+'-instrumented-inputs.json')).write_text(json.dumps(checked,indent=2)+'\n')
env=os.environ.copy();env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
args=[str(build/'g01_cpu_attention'),'--gtest_filter=GgmlCpuProvider.*Attention*:GgmlCpuProvider.ResidentCache*']
if not (build/'g01_cpu_attention').exists():args[0]=str(build/'bin/g01_cpu_attention')
if mode=='tsan':args=['setarch','x86_64','-R',*args]
run('run',args,env)
