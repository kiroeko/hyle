from pathlib import Path
import subprocess,sys
script=Path(__file__).parent/'g07_apple_host_risk.py'
for mode in ['asan','ubsan','tsan']:
 subprocess.run([sys.executable,str(script),mode,'d1','d1'],check=True)
print('ALL_THREE_D1_HOST_FACETS_PASS',flush=True)
