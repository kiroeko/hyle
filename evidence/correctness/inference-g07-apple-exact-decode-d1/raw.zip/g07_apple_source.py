from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');attempt=sys.argv[1]
package=sys.argv[2] if len(sys.argv)>2 else attempt
out=base/f'g07-apple-source-{attempt}';out.mkdir(exist_ok=False);started=time.monotonic()
source=base/'source-c8874688';parent=base/'a-cpu-apple/selected-graph/source-parent';build=parent.parent/'source-build'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
r=dict(state='SETUP',pid=os.getpid(),attempt=attempt,source=str(source),build=str(build),max_jobs=4,stages=[])
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
 stamp=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
try:
 r['identity']={name:subprocess.check_output(cmd,env=env,text=True).strip() for name,cmd in [
  ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
  ('compiler',['xcrun','clang','--version']),('gpu',['/usr/sbin/system_profiler','SPDisplaysDataType'])]}
 assert r['identity']['model']=='Mac16,12' and r['identity']['arch']=='arm64'
 assert source.is_dir() and not (source/'.git').exists()
 with zipfile.ZipFile(base/f'g07-input-{package}.zip') as z:
  manifest=json.loads(z.read('input-manifest.json'));r['candidate']=manifest['candidate'];changed=[]
  for item in manifest['inputs']:
   rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
   data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
   p=source/rel
   if not p.exists() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
  (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
 r['synced_paths']=changed
 p=parent/'CMakeLists.txt';text=p.read_text()
 if 'add_executable(g07_packed_fp8 ' not in text:
  text+='\nadd_executable(g07_packed_fp8 "'+str(source/'tests/compute_route_apple/fp8_tile_test.cc')+'")\n'
  text+='target_compile_features(g07_packed_fp8 PRIVATE cxx_std_23)\ntarget_compile_options(g07_packed_fp8 PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(g07_packed_fp8 PRIVATE hyle::compute GTest::gtest_main)\nhyle_stage_runtime(g07_packed_fp8)\n'
  text+='\nadd_executable(g07_existing_weight_consumers "'+str(source/'tests/compute_route_apple/mlx_quantized_test.cc')+'" "'+str(source/'tests/compute_route_apple/mature_overlap_test.cc')+'" "'+str(source/'tests/compute_route_apple/d5_qwen35_execution_test.cc')+'")\n'
  text+='target_compile_features(g07_existing_weight_consumers PRIVATE cxx_std_23)\ntarget_link_libraries(g07_existing_weight_consumers PRIVATE hyle::compute GTest::gtest_main ggml)\ntarget_include_directories(g07_existing_weight_consumers PRIVATE "$<TARGET_PROPERTY:ggml,SOURCE_DIR>")\nhyle_stage_runtime(g07_existing_weight_consumers)\n'
  p.write_text(text)
 text=text.replace('target_include_directories(g07_existing_weight_consumers PRIVATE "${HYLE_GGML_SOURCE_DIR}/src")','target_include_directories(g07_existing_weight_consumers PRIVATE "$<TARGET_PROPERTY:ggml,SOURCE_DIR>")')
 if 'add_executable(g07_graph_weight_consumers ' not in text:
  text+='\nadd_executable(g07_graph_weight_consumers "'+str(source/'tests/graph_route_apple/d5_qwen35_execution_test.cc')+'")\n'
  text+='target_compile_features(g07_graph_weight_consumers PRIVATE cxx_std_23)\ntarget_link_libraries(g07_graph_weight_consumers PRIVATE hyle::graph GTest::gtest_main ggml)\ntarget_include_directories(g07_graph_weight_consumers PRIVATE "$<TARGET_PROPERTY:ggml,SOURCE_DIR>")\nhyle_stage_runtime(g07_graph_weight_consumers)\n'
  text+='\nadd_executable(g07_joint_weight_consumer "'+str(source/'tests/graph_route_cpu_apple/packed_weight_test.cc')+'")\n'
  text+='target_compile_features(g07_joint_weight_consumer PRIVATE cxx_std_23)\ntarget_link_libraries(g07_joint_weight_consumer PRIVATE hyle::graph GTest::gtest_main)\nhyle_stage_runtime(g07_joint_weight_consumer)\n'
 if 'add_executable(g07_public_weight_consumer ' not in text:
  text+='\nadd_executable(g07_public_weight_consumer "'+str(source/'tests/compute_route_apple/packed_resident_consumer.cc')+'")\n'
  text+='target_compile_features(g07_public_weight_consumer PRIVATE cxx_std_23)\ntarget_compile_options(g07_public_weight_consumer PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(g07_public_weight_consumer PRIVATE hyle::compute)\nhyle_stage_runtime(g07_public_weight_consumer)\n'
 p.write_text(text)
 (out/'parent.cmake').write_text(text)
 run('configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build)])
 run('manifest',['/opt/homebrew/bin/ninja','-C',str(build),'build.ninja'])
 targets=['g07_packed_fp8','g07_existing_weight_consumers']
 if '--graph-joint' in sys.argv:targets=['g07_graph_weight_consumers','g07_joint_weight_consumer']
 if '--public' in sys.argv:targets=['g07_public_weight_consumer']
 if '--all-declared' in sys.argv:targets=['g07_packed_fp8','g07_existing_weight_consumers','g07_graph_weight_consumers','g07_joint_weight_consumer','g07_public_weight_consumer']
 preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
 dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True);(out/'dry-run.log').write_text(dry)
 r['build_edges']=len(dry.splitlines());save()
 assert 'Re-running CMake' not in dry and 'Building CUDA object' not in dry
 run('build',['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-j','4',*targets])
 for target in targets:
  command=[str(build/target)]
  if target!='g07_public_weight_consumer':command+=['--gtest_output=xml:'+str(out/(target+'.xml'))]
  if target=='g07_existing_weight_consumers':
   command+=['--gtest_filter=AppleMlxQuantized.*:AppleMatureOverlap.*:AppleParityDirect.RealMlxPackedDemandUsesAllRowsAndRealK:AppleParityDirect.OfficialFp4ExpertsKeepOriginalFp8ActivationAndGroup32Weights:AppleMoeFragments.*Fp8*']
  if target=='g07_graph_weight_consumers':command+=['--gtest_filter=AppleParityGraph.RealMlxPackedDemandUsesAllRowsAndRealK:AppleParityGraph.*Fp4*:AppleGraphMoeFragments.*Fp8*']
  run(target,command)
 r['state']='SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING';save();print(r['state'],flush=True)
except BaseException as e:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(e));save()
 raise
