#!/bin/sh
set -eu
m1r_machine=$1
case "$m1r_machine" in
  wsl)
    m1r_prefix=/root
    PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
    ;;
  air|mini)
    m1r_prefix=/Users/kiro
    PATH=/Users/kiro/hyle-m1r-tools:/opt/homebrew/bin:/Users/kiro/hyle-verify-tools/bin:/usr/bin:/bin:/usr/sbin:/sbin
    if [ "$m1r_machine" = air ]; then
      export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
      export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
    fi
    ;;
  *) exit 2 ;;
esac
export PATH
unset CMAKE_TOOLCHAIN_FILE
python3 "$m1r_prefix/hyle-m1r-combined-delivery.py" \
  "$m1r_prefix/hyle-m1r-0d85a9ad" "$m1r_prefix/hyle-m1r-sdk" "$m1r_machine"
