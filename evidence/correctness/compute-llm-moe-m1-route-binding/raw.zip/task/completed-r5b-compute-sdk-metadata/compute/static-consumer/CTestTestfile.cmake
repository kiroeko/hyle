# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/compute/cpp
# Build directory: C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-compute/selected-compute/static-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
if(CTEST_CONFIGURATION_TYPE MATCHES "^([Dd][Ee][Bb][Uu][Gg])$")
  add_test("hyle_package_compute_cpp" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-compute/selected-compute/static-consumer/Debug/hyle_package_compute_cpp.exe")
  set_tests_properties("hyle_package_compute_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;15;add_test;C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;0;")
elseif(CTEST_CONFIGURATION_TYPE MATCHES "^([Rr][Ee][Ll][Ee][Aa][Ss][Ee])$")
  add_test("hyle_package_compute_cpp" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-compute/selected-compute/static-consumer/Release/hyle_package_compute_cpp.exe")
  set_tests_properties("hyle_package_compute_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;15;add_test;C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;0;")
elseif(CTEST_CONFIGURATION_TYPE MATCHES "^([Mm][Ii][Nn][Ss][Ii][Zz][Ee][Rr][Ee][Ll])$")
  add_test("hyle_package_compute_cpp" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-compute/selected-compute/static-consumer/MinSizeRel/hyle_package_compute_cpp.exe")
  set_tests_properties("hyle_package_compute_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;15;add_test;C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;0;")
elseif(CTEST_CONFIGURATION_TYPE MATCHES "^([Rr][Ee][Ll][Ww][Ii][Tt][Hh][Dd][Ee][Bb][Ii][Nn][Ff][Oo])$")
  add_test("hyle_package_compute_cpp" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-compute/selected-compute/static-consumer/RelWithDebInfo/hyle_package_compute_cpp.exe")
  set_tests_properties("hyle_package_compute_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;15;add_test;C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;0;")
else()
  add_test("hyle_package_compute_cpp" NOT_AVAILABLE)
endif()
