import json
from pathlib import Path
path = Path('docs/implementation/module-status.json')
registry = json.loads(path.read_text(encoding='utf-8'))
entry = next(m for m in registry['modules'] if m['module'] == 'compute_route_apple')
assert entry['state'] == 'CANDIDATE'
entry['state'] = 'AUDITED'
entry.pop('candidate')
entry['summary'] = 'M1-R R5b AUDITED：实际shared多消费者共目录暂存失败，有限修复Apple构建期资源writer协调；不改算术/运行时。Windows三交付与四环境原生/插桩保留原身份，其余声明交付待完成。'
path.write_bytes((json.dumps(registry, ensure_ascii=False, indent=2) + '\n').encode())
