import hashlib
import json
from pathlib import Path
import shutil

task = Path(__file__).resolve().parent
out = Path('evidence/correctness/apple-runtime-selector-owner-v1')
out.mkdir(parents=True, exist_ok=True)
names = ('selector-apple-owner-tests.log', 'selector-apple-owner-focused.log',
         'r5b-product-plan.json', 'r5b-owned-plan.json')
for name in names:
    shutil.copyfile(task / name, out / name)
data = {'candidate': '256c45473f13e7554d318a10b246e6fd18b10959', 'status': 'PASS',
        'scope': 'One factor-owned CMake path; no gate/P1/evidence reuse changes',
        'original_suite': {'tests': 57, 'pass': 56, 'fixture_failure': 1},
        'corrected_focused': {'tests': 3, 'pass': 3},
        'unique_tests_covered': 57,
        'correction': 'New Windows fixture originally omitted its header-suite target; added that fixture target only, then reran all three new cases. Tool implementation unchanged.',
        'inputs': {name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in
                   ('scripts/validation-policy.json', 'scripts/validation-select.py', 'tests/tooling/validation_selector_test.py')},
        'files': {name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in names}}
(out / 'validation.json').write_bytes((json.dumps(data, indent=2) + '\n').encode())
