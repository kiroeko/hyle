#!/bin/sh
set -eu
m1r_machine=$1
case "$m1r_machine" in
  wsl)
    m1r_prefix=/root
    PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
    m1r_compiler=/usr/bin/g++-14
    m1r_generator=Ninja
    m1r_cuda=ON; m1r_apple=OFF; m1r_vulkan=OFF; m1r_onednn=ON
    m1r_factors=compute,compute_backend_cpu,compute_backend_cuda,compute_provider_native,compute_route_cpu,compute_route_cuda,graph,graph_route_cpu,graph_route_cuda
    ;;
  air|mini)
    m1r_prefix=/Users/kiro
    PATH=/Users/kiro/hyle-m1r-tools:/opt/homebrew/bin:/Users/kiro/hyle-verify-tools/bin:/usr/bin:/bin:/usr/sbin:/sbin
    m1r_compiler=/usr/bin/c++
    m1r_generator=Ninja
    m1r_cuda=OFF; m1r_apple=ON; m1r_vulkan=OFF; m1r_onednn=OFF
    m1r_factors=compute,compute_backend_cpu,compute_provider_native,compute_route_cpu,graph,graph_route_cpu,compute_route_apple,graph_route_apple
    if [ "$m1r_machine" = air ]; then
      m1r_vulkan=ON
      m1r_factors=$m1r_factors,compute_route_vulkan,graph_route_vulkan
      export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
      export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
    fi
    ;;
  *) exit 2 ;;
esac
export PATH
export CMAKE_BUILD_PARALLEL_LEVEL=2 CTEST_INTERACTIVE_DEBUG_MODE=0 TRACY_ONLY_LOCALHOST=1
m1r_source=$m1r_prefix/hyle-m1r-0d85a9ad
m1r_build=$m1r_prefix/hyle-m1r-native
grep 'd4a4b38955e8feae9d4c768cd232f5d23d0327c2' "$m1r_source/SOURCE-MANIFEST.txt"
if [ "$m1r_apple" = ON ]; then
  mkdir -p /Users/kiro/hyle-m1r-tools
  cp "$m1r_source/evidence/correctness/apple-r5-foundation-checkpoint/xcrun-metal-validation.sh" /Users/kiro/hyle-m1r-tools/xcrun
  chmod +x /Users/kiro/hyle-m1r-tools/xcrun
  xcrun -sdk macosx metal --version
  xcrun -sdk macosx metallib --version
fi
cmake --version
"$m1r_compiler" --version
set --
if [ "$m1r_vulkan" = ON ]; then
  set -- -DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator \
    -DVulkan_INCLUDE_DIR=/opt/homebrew/opt/vulkan-headers/include \
    -DVulkan_LIBRARY=/opt/homebrew/opt/vulkan-loader/lib/libvulkan.dylib \
    -DVulkan_GLSLC_EXECUTABLE=/opt/homebrew/bin/glslc \
    -DSPIRV-Headers_DIR=/opt/homebrew/opt/spirv-headers/share/cmake/SPIRV-Headers
fi
cmake -S "$m1r_source" -B "$m1r_build" -G "$m1r_generator" \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER="$m1r_compiler" \
  -DHYLE_DEV_FACTORS="$m1r_factors" -DHYLE_BUILD_TESTS=ON \
  -DHYLE_STATIC=OFF -DHYLE_SANITIZER=off -DHYLE_INSTALL=OFF \
  -DHYLE_BUILD_BENCH=OFF -DHYLE_WERROR=ON -DHYLE_COMPUTE_CPU=ON \
  -DHYLE_COMPUTE_CUDA="$m1r_cuda" -DHYLE_COMPUTE_APPLE="$m1r_apple" \
  -DHYLE_COMPUTE_VULKAN="$m1r_vulkan" -DHYLE_COMPUTE_ONEDNN="$m1r_onednn" "$@"
set --
m1r_old_ifs=$IFS
IFS=,
for m1r_factor in $m1r_factors; do set -- "$@" "hyle_${m1r_factor}_tests"; done
IFS=$m1r_old_ifs
cmake --build "$m1r_build" --parallel 2 --target "$@" -- -k0
m1r_labels=$(printf '%s' "$m1r_factors" | tr ',' '|')
ctest --test-dir "$m1r_build" -N -L "^($m1r_labels)$" > "$m1r_build/selected-tests.txt"
cat "$m1r_build/selected-tests.txt"
if [ "$m1r_apple" = ON ]; then
  grep ' hyle_compute_route_apple_test$' "$m1r_build/selected-tests.txt"
  grep ' hyle_graph_route_apple_test$' "$m1r_build/selected-tests.txt"
fi
if [ "$m1r_vulkan" = ON ]; then
  grep ' hyle_compute_route_vulkan_test$' "$m1r_build/selected-tests.txt"
  grep ' hyle_graph_route_vulkan_test$' "$m1r_build/selected-tests.txt"
fi
if [ "$m1r_cuda" = ON ]; then
  grep ' hyle_compute_backend_cuda_test$' "$m1r_build/selected-tests.txt"
  grep ' hyle_graph_route_cuda_test$' "$m1r_build/selected-tests.txt"
fi
ctest --test-dir "$m1r_build" -L "^($m1r_labels)$" --no-tests=error --output-on-failure --timeout 180
printf '%s\n' "M1-R $m1r_machine native selected checks PASS"
