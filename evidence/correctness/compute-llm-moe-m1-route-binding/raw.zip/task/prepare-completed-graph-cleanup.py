import json
from pathlib import Path

task = Path(__file__).resolve().parent
result = json.loads((task / 'r5b-selected-result.json').read_text())
assert result['verdict'] == 'PASS'
gate = next(x for x in result['selected_gates'] if x['id'] == 'delivery:graph')
assert gate['status'] == 'PASS'
receipt = Path(gate['receipt']).resolve()
assert receipt.parent == Path('.git/hyle-validation').resolve()
text = (task / 'cleanup-r5b-compute.ps1').read_text()
text = text.replace('369b174723a6ff28a78cf70fe4a3c93e6488381820ef9639a2f1c9ece546a553.json', receipt.name)
text = text.replace('completed-r5b-compute-sdk-', 'completed-r5b-graph-sdk-')
text = text.replace("@('compute')", "@('graph')")
(task / 'cleanup-r5b-graph.ps1').write_bytes(text.encode())
print(receipt.name)
