"""Execute only the remaining declared M1-R checks, serially and fail-fast."""
import datetime
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd().resolve()
logs = root / '.scratch/validation/m1-route-binding'
completed = json.loads((logs / 'continued-result.json').read_text(encoding='utf-8'))
assert completed['status'] == 'PASS', 'Windows selector must finish first'
candidate = 'd4a4b38955e8feae9d4c768cd232f5d23d0327c2'
canonical_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
metadata_only = subprocess.check_output(['git', 'diff', '--name-only', candidate, canonical_head], text=True).splitlines()
assert all(p.startswith(('docs/', 'evidence/')) for p in metadata_only), metadata_only
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
remote = str(logs / 'run-remote.py')
checks = [
    ('wsl-sanitizers', [sys.executable, '-X', 'utf8', remote, 'tsan-resume', 'wsl']),
    ('windows-gpu-delivery', ['pwsh', '-NoProfile', '-File', str(logs / 'windows-gpu-delivery.ps1')]),
    ('air-delivery', [sys.executable, '-X', 'utf8', remote, 'delivery', 'air']),
    ('mini-delivery', [sys.executable, '-X', 'utf8', remote, 'delivery', 'mini']),
    ('wsl-delivery', [sys.executable, '-X', 'utf8', remote, 'delivery', 'wsl']),
]
receipt = {'candidate': candidate, 'canonical_head': canonical_head,
           'metadata_only_since_candidate': metadata_only, 'status': 'RUNNING', 'checks': []}
prior = json.loads((logs / 'pending-result-before-tsan-aslr.json').read_text(encoding='utf-8'))
assert prior['candidate'] == candidate
for entry in prior['checks']:
    if entry['status'] == 'PASS':
        receipt['checks'].append(dict(entry, candidate=entry.get('candidate',prior['candidate']), reused_from='pending-result-before-tsan-aslr.json'))
assert [e['name'] for e in receipt['checks']] == ['air-native', 'mini-native', 'wsl-native', 'windows-asan']
receipt['fixture_only_correction'] = 'GCC default member initialization, guarded assertion braces and structured binding reference; original Mac receipts retain 7016443b identity'
record = logs / 'pending-result.json'
assert not record.exists(), 'preserve earlier attempts; do not restart the whole queue'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save():
    record.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

for name, command in checks:
    print('RUN ' + name, flush=True)
    entry = {'name': name, 'command': command, 'started': now(), 'status': 'RUNNING', 'candidate': candidate}
    receipt['checks'].append(entry)
    save()
    log_name = 'wsl-tsan-resume.log' if name == 'wsl-sanitizers' else name + '.log'
    with (logs / log_name).open('wb') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    entry.update(exit_code=result.returncode, ended=now(), status='PASS' if result.returncode == 0 else 'FAIL')
    save()
    if result.returncode:
        receipt['status'] = 'FAIL'
        save()
        print('FAIL ' + name, flush=True)
        raise SystemExit(result.returncode)
    if name == 'wsl-sanitizers':
        with (logs / 'wsl-sanitizers.log').open('ab') as merged:
            merged.write(b'\nTSan resumed with process-local ASLR disabled; same instrumented binaries.\n')
            merged.write((logs / log_name).read_bytes())
        entry['environment_correction'] = 'TSan startup address collision; process-local setarch -R only, no rebuild'
        save()
    print('PASS ' + name, flush=True)
receipt['status'] = 'PASS'
save()
