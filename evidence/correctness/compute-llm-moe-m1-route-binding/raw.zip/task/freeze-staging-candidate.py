import json
from pathlib import Path
path = Path('docs/implementation/module-status.json')
registry = json.loads(path.read_text(encoding='utf-8'))
for entry in registry['modules']:
    if entry.get('record') == 'docs/implementation/tasks/compute/llm-moe-m1-route-binding.md':
        assert entry['state'] in ('AUDITED', 'CANDIDATE')
        entry['state'] = 'CANDIDATE'
        entry['candidate'] = 'c482ce1b33cefecdb949c8b0ec89f9309c3e86ac'
        entry['summary'] = 'M1-R CANDIDATE：冷模型/阶段/环境接线固定；四环境原生及Windows/WSL插桩、Windows三交付通过。Apple构建期暂存协调修复固定，适用OFF/交付续验；不签模型覆盖，自研冻结。'
path.write_bytes((json.dumps(registry, ensure_ascii=False, indent=2) + '\n').encode())
