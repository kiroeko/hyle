# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent
# Build directory: C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
if(CTEST_CONFIGURATION_TYPE MATCHES "^([Dd][Ee][Bb][Uu][Gg])$")
  add_test("hyle_selected_source_consumer" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-build/Debug/hyle_selected_source_consumer.exe")
  set_tests_properties("hyle_selected_source_consumer" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;15;add_test;C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;0;")
elseif(CTEST_CONFIGURATION_TYPE MATCHES "^([Rr][Ee][Ll][Ee][Aa][Ss][Ee])$")
  add_test("hyle_selected_source_consumer" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-build/Release/hyle_selected_source_consumer.exe")
  set_tests_properties("hyle_selected_source_consumer" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;15;add_test;C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;0;")
elseif(CTEST_CONFIGURATION_TYPE MATCHES "^([Mm][Ii][Nn][Ss][Ii][Zz][Ee][Rr][Ee][Ll])$")
  add_test("hyle_selected_source_consumer" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-build/MinSizeRel/hyle_selected_source_consumer.exe")
  set_tests_properties("hyle_selected_source_consumer" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;15;add_test;C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;0;")
elseif(CTEST_CONFIGURATION_TYPE MATCHES "^([Rr][Ee][Ll][Ww][Ii][Tt][Hh][Dd][Ee][Bb][Ii][Nn][Ff][Oo])$")
  add_test("hyle_selected_source_consumer" "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-build/RelWithDebInfo/hyle_selected_source_consumer.exe")
  set_tests_properties("hyle_selected_source_consumer" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;15;add_test;C:/hyle-scratch/m1r-r5b/270c3875b4b53932c1e9/delivery-graph/selected-graph/source-parent/CMakeLists.txt;0;")
else()
  add_test("hyle_selected_source_consumer" NOT_AVAILABLE)
endif()
subdirs("hyle")
