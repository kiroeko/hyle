"""Run one task script only; the caller serializes all heavy environments."""
from pathlib import Path
import subprocess
import sys

action, machine = sys.argv[1:]
script = Path('.scratch/validation/m1-route-binding') / ('remote-' + action + '.sh')
if machine == 'wsl':
    command = ['wsl', '-d', 'Ubuntu-24.04', '--', 'sh', '-s', '--', machine]
elif machine == 'air':
    command = ['ssh', '-o', 'BatchMode=yes', 'kiro@172.22.10.198', 'sh', '-s', '--', machine]
elif machine == 'mini':
    command = ['ssh', '-o', 'BatchMode=yes', '-i', 'C:/Users/kiro/.ssh/codex_mac_172_22_10_107_win',
               'kiro@172.22.10.107', 'sh', '-s', '--', machine]
else:
    raise SystemExit('unknown validation machine')
raise SystemExit(subprocess.run(command, input=script.read_bytes().replace(b'\r\n', b'\n')).returncode)
