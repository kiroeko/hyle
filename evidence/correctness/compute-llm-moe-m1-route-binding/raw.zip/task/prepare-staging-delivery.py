"""Keep failed SDKs/logs; reuse only the existing producer objects for R5b."""
import json
from pathlib import Path
import subprocess

task = Path(__file__).resolve().parent
identity = json.loads((task / 'source-identity-c482ce1b.json').read_text())
assert len(identity['copies']) == 3 and all(c['sha256_verified'] for c in identity['copies'])
candidate = 'c482ce1b33cefecdb949c8b0ec89f9309c3e86ac'
assert identity['candidate'] == candidate
helper = task / 'combined-delivery-staging.py'
helper.write_bytes((task / 'combined-delivery.py').read_bytes().replace(
    b'd4a4b38955e8feae9d4c768cd232f5d23d0327c2', candidate.encode()))

script = b'''from pathlib import Path
import json
root = Path('/Users/kiro/hyle-m1r-sdk')
assert root.resolve() == root and root.is_dir()
receipt = json.loads((root / 'logs/receipt.json').read_text())
assert receipt['status'] == 'FAIL' and receipt['commands'][-1]['name'] == 'shared-consumer-build'
for name in ('logs', 'shared-relocated', 'shared-consumer-build'):
    source = root / name
    target = root / (name + '-before-staging-lock')
    assert source.resolve().parent == root and not target.exists()
    source.rename(target)
(root / 'logs').mkdir()
hidden = root / 'shared-producer-unavailable'
producer = root / 'shared-producer'
assert hidden.resolve().parent == root and not producer.exists()
hidden.rename(producer)
print('Retained original failed logs/SDK/consumer; existing producer restored for CMake-only correction.')
'''
subprocess.run(['ssh', '-o', 'BatchMode=yes', 'kiro@172.22.10.198', 'python3', '-'], input=script, check=True)
for host, extra in [('kiro@172.22.10.198', []), ('kiro@172.22.10.107', ['-i', 'C:/Users/kiro/.ssh/codex_mac_172_22_10_107_win'])]:
    subprocess.run(['scp', '-o', 'BatchMode=yes', *extra, str(helper), host + ':/Users/kiro/hyle-m1r-combined-delivery.py'], check=True)
subprocess.run(['wsl', '-d', 'Ubuntu-24.04', '--', 'cp',
    '/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-route-binding/combined-delivery-staging.py',
    '/root/hyle-m1r-combined-delivery.py'], check=True)
