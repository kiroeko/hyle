"""One source/shared/static producer per environment, two ordinary SDK consumers.

Task-local validation only. Uses the existing public staging helpers and never
changes central build/validation tools. Completed producers are removed after
their logs and CMake cache have been retained.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

source = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
machine = sys.argv[3]
candidate = 'd4a4b38955e8feae9d4c768cd232f5d23d0327c2'
assert machine in ('windows', 'wsl', 'air', 'mini')
assert root.name == 'hyle-m1r-sdk' or str(root) == 'C:\\hyle-scratch\\m1r-sdk'
root.mkdir(parents=True, exist_ok=True)
logs = root / 'logs'
logs.mkdir(exist_ok=True)
if machine == 'windows':
    canonical_head = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
    metadata_only = subprocess.check_output(['git', '-C', str(source), 'diff', '--name-only', candidate, canonical_head], text=True).splitlines()
    assert all(p.startswith(('docs/', 'evidence/')) for p in metadata_only), metadata_only
    assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip()
else:
    assert candidate in (source / 'SOURCE-MANIFEST.txt').read_text()
    canonical_head = candidate
    metadata_only = []
environment = dict(os.environ)
environment.update(CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_INTERACTIVE_DEBUG_MODE='0', TRACY_ONLY_LOCALHOST='1')
if machine == 'air':
    # /usr/bin/python3 is SIP-protected and drops inherited DYLD_* variables.
    # Set the existing validation-machine loader paths for its native children.
    environment['DYLD_LIBRARY_PATH'] = '/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib'
    environment['VK_DRIVER_FILES'] = '/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json'
gpu = machine in ('windows', 'wsl')
apple = machine in ('air', 'mini')
vulkan = machine in ('windows', 'air')
flags = ['-DCMAKE_BUILD_TYPE=Release', '-DHYLE_WERROR=ON', '-DHYLE_BUILD_BENCH=OFF',
         '-DHYLE_BUILD_TESTS=OFF', '-DHYLE_COMPUTE_CPU=' + ('OFF' if machine == 'windows' else 'ON'),
         '-DHYLE_COMPUTE_CUDA=' + ('ON' if gpu else 'OFF'),
         '-DHYLE_COMPUTE_APPLE=' + ('ON' if apple else 'OFF'),
         '-DHYLE_COMPUTE_VULKAN=' + ('ON' if vulkan else 'OFF'),
         '-DHYLE_COMPUTE_ONEDNN=' + ('ON' if machine == 'wsl' else 'OFF')]
toolchain_flags = []
if machine == 'wsl':
    toolchain_flags = ['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14']
elif apple:
    toolchain_flags = ['-DCMAKE_CXX_COMPILER=/usr/bin/c++', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4']
flags += toolchain_flags
if machine == 'air':
    flags += ['-DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator',
              '-DVulkan_INCLUDE_DIR=/opt/homebrew/opt/vulkan-headers/include',
              '-DVulkan_LIBRARY=/opt/homebrew/opt/vulkan-loader/lib/libvulkan.dylib',
              '-DVulkan_GLSLC_EXECUTABLE=/opt/homebrew/bin/glslc',
              '-DSPIRV-Headers_DIR=/opt/homebrew/opt/spirv-headers/share/cmake/SPIRV-Headers']
report = {'candidate': candidate, 'machine': machine, 'source': str(source),
          'canonical_head': canonical_head, 'metadata_only_since_candidate': metadata_only,
          'status': 'RUNNING', 'commands': [], 'cleaned': []}
record = logs / 'receipt.json'
resumed_source = {}
if record.exists():
    prior = json.loads(record.read_text())
    assert prior['candidate'] == candidate and prior['status'] == 'FAIL'
    assert [(c['name'], c['exit_code']) for c in prior['commands']] == [
        ('source-configure', 0), ('source-build', 0), ('source-test', 8)]
    resumed_source = {c['name']: c for c in prior['commands'] if c['exit_code'] == 0}
    report['resume'] = 'Reuse unchanged source configure/build; only child loader environment corrected. Original test failure retained separately.'

def save():
    record.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

def run(name, args):
    if name in resumed_source:
        entry = resumed_source[name]
        assert entry['argv'] == args
        assert hashlib.sha256((logs / entry['log']).read_bytes()).hexdigest() == entry['sha256']
        report['commands'].append(entry)
        save()
        print('REUSE ' + name, flush=True)
        return
    print('RUN ' + name, flush=True)
    log = logs / (name + '.log')
    with log.open('wb') as out:
        result = subprocess.run(args, stdout=out, stderr=subprocess.STDOUT, env=environment)
    report['commands'].append({'name': name, 'argv': args, 'exit_code': result.returncode,
                               'log': log.name, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    if result.returncode:
        report['status'] = 'FAIL'
    save()
    if result.returncode:
        print(log.read_text(errors='replace')[-8000:], flush=True)
        raise SystemExit(result.returncode)

def child(path):
    assert not path.is_symlink()
    path = path.resolve()
    assert path != root and root in path.parents
    return path

def remove_completed(path):
    path = child(path)
    shutil.copy2(path / 'CMakeCache.txt', logs / (path.name + '-CMakeCache.txt'))
    shutil.rmtree(path)
    report['cleaned'].append(str(path))
    save()

def consumer(directory, embedded):
    directory.mkdir(exist_ok=True)
    cmake = ['cmake_minimum_required(VERSION 3.25)', 'project(hyle_m1r_consumers LANGUAGES CXX)']
    if embedded:
        cmake += ['set(HYLE_COMPONENTS graph)', 'set(HYLE_INSTALL OFF)',
                  'add_subdirectory("' + source.as_posix() + '" hyle)']
    else:
        cmake += ['find_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)']
    cmake += ['enable_testing()']
    for component in ('compute', 'graph'):
        name = 'm1r_' + component
        sample = source / 'samples/package' / component / 'cpp/main.cc'
        cmake += ['add_executable(' + name + ' "' + sample.as_posix() + '")',
                  'target_compile_features(' + name + ' PRIVATE cxx_std_23)',
                  'target_link_libraries(' + name + ' PRIVATE hyle::' + component + ')',
                  'hyle_stage_runtime_dependencies(' + name + ')']
        if apple:
            cmake += ['hyle_stage_apple_runtime(' + name + ')']
        cmake += ['add_test(NAME ' + name + ' COMMAND ' + name + ')']
    footprint = directory / 'footprint.cc'
    footprint.write_text('''#include <cstdio>
#include <hyle/compute/workload.h>
#include <hyle/compute/prepared_operation.h>
#include <hyle/graph/executable.h>
#if defined(HYLE_COMPUTE_CUDA)
#include <hyle/compute/backends/cuda.h>
#endif
int main() {
  using namespace hyle::compute;
  std::printf("ModelIdentity=%zu WorkloadContext=%zu PreparedOperation=%zu Executable=%zu\\n",
              sizeof(ModelIdentity), sizeof(WorkloadContext),
              sizeof(PreparedOperation), sizeof(hyle::graph::Executable));
#if defined(HYLE_COMPUTE_CUDA)
  std::printf("CUDAEnvironment=%zu\\n", sizeof(cuda::Environment));
#endif
}
''', encoding='utf-8')
    cmake += ['add_executable(m1r_footprint "' + footprint.as_posix() + '")',
              'target_link_libraries(m1r_footprint PRIVATE hyle::graph)',
              'hyle_stage_runtime_dependencies(m1r_footprint)',
              'add_test(NAME m1r_footprint COMMAND m1r_footprint)']
    (directory / 'CMakeLists.txt').write_text('\n'.join(cmake) + '\n', encoding='utf-8')

save()
source_parent = root / 'source-consumer'
source_build = root / 'source-build'
consumer(source_parent, True)
run('source-configure', ['cmake', '-S', str(source_parent), '-B', str(source_build), '-G', 'Ninja', *flags])
run('source-build', ['cmake', '--build', str(source_build), '--parallel', '2'])
run('source-test', ['ctest', '--test-dir', str(source_build), '--verbose', '--no-tests=error', '--timeout', '180'])
remove_completed(source_build)
for linkage in ('shared', 'static'):
    producer = child(root / (linkage + '-producer'))
    staging = child(root / (linkage + '-staging'))
    relocated = child(root / (linkage + '-relocated'))
    hidden = child(root / (linkage + '-producer-unavailable'))
    assert not relocated.exists() and not hidden.exists(), 'do not overwrite a previous completed SDK'
    run(linkage + '-configure', ['cmake', '-S', str(source), '-B', str(producer), '-G', 'Ninja', *flags,
        '-DHYLE_COMPONENTS=graph', '-DHYLE_INSTALL=ON', '-DCMAKE_INSTALL_PREFIX=' + str(staging),
        '-DHYLE_STATIC=' + ('ON' if linkage == 'static' else 'OFF')])
    run(linkage + '-build', ['cmake', '--build', str(producer), '--parallel', '2'])
    run(linkage + '-install', ['cmake', '--install', str(producer)])
    assert (staging / 'include/hyle/compute/workload.h').is_file()
    for header in ('provider_internal.h', 'native_context.h', 'prepared_state.h'):
        assert not list((staging / 'include').rglob(header)), 'private header leaked'
    staging.rename(relocated)
    producer.rename(hidden)
    (logs / (linkage + '-installed-files.txt')).write_text(
        '\n'.join(sorted(p.relative_to(relocated).as_posix() for p in relocated.rglob('*') if p.is_file())) + '\n', encoding='utf-8')
    parent = root / (linkage + '-consumer')
    build = root / (linkage + '-consumer-build')
    consumer(parent, False)
    run(linkage + '-consumer-configure', ['cmake', '-S', str(parent), '-B', str(build), '-G', 'Ninja',
        '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(relocated), *toolchain_flags])
    run(linkage + '-consumer-build', ['cmake', '--build', str(build), '--parallel', '2'])
    run(linkage + '-relocated-test', ['ctest', '--test-dir', str(build), '--verbose', '--no-tests=error', '--timeout', '180'])
    remove_completed(hidden)
report['status'] = 'PASS'
save()
print('M1-R ' + machine + ' source/shared/static Direct+Graph PASS', flush=True)
