param([switch]$Delete)
$ErrorActionPreference = 'Stop'
$m1rArchiveRoot = [IO.Path]::GetFullPath('C:\hyle-scratch')
$m1rArchivePaths = @(
  'C:\hyle-scratch\m1g-04368a39-source.zip',
  'C:\hyle-scratch\m1g-04368a39-source.zip.sha256',
  'C:\hyle-scratch\m1g-04368a39.tar.gz',
  'C:\hyle-scratch\m1g-candidate-final.tar.gz',
  'C:\hyle-scratch\m1g-candidate-fixed.tar.gz',
  'C:\hyle-scratch\m1g-candidate.tar.gz',
  'C:\hyle-scratch\m1g-validation-delta.tar'
)
$m1rInventory = @()
foreach ($m1rArchivePath in $m1rArchivePaths) {
  $m1rResolvedArchive = [IO.Path]::GetFullPath($m1rArchivePath)
  if ([IO.Path]::GetDirectoryName($m1rResolvedArchive) -ne $m1rArchiveRoot) {
    throw 'Archive cleanup escaped the explicitly named task directory'
  }
  if (Test-Path -LiteralPath $m1rResolvedArchive -PathType Leaf) {
    $m1rArchiveItem = Get-Item -LiteralPath $m1rResolvedArchive
    if ($m1rArchiveItem.Attributes -band [IO.FileAttributes]::ReparsePoint) {
      throw 'Refusing to follow a reparse point'
    }
    $m1rInventory += [pscustomobject]@{
      path = $m1rResolvedArchive
      bytes = $m1rArchiveItem.Length
    }
  }
}
$m1rInventory | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'closed-m1g-archive-cleanup.json')
$m1rInventory | Format-Table
if ($Delete) {
  foreach ($m1rArchiveItem in $m1rInventory) {
    Remove-Item -LiteralPath $m1rArchiveItem.path -Force
  }
  Write-Output 'Removed only the listed closed M1-G validation archives.'
}
