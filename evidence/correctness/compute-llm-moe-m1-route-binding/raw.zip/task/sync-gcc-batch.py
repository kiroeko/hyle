"""Transfer one complete canonical Git candidate to disposable validation copies."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path.cwd().resolve()
candidate = subprocess.check_output(['git', 'rev-parse', 'd4a4b389'], text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', candidate + '^{tree}'], text=True).strip()
archive = Path('C:/hyle-scratch/m1r-d4a4b389.tar.gz')
raw = archive.with_suffix('')
subprocess.run(['git', 'archive', '--format=tar', '-o', str(raw), candidate], check=True)
manifest = ('HYLE complete validation source archive\n\nGit commit: ' + candidate +
            '\nGit tree: ' + tree + '\n').encode()
with tarfile.open(raw, 'a') as tar:
    info = tarfile.TarInfo('SOURCE-MANIFEST.txt')
    info.size = len(manifest)
    info.mode = 0o644
    tar.addfile(info, io.BytesIO(manifest))
with raw.open('rb') as source, gzip.open(archive, 'wb', compresslevel=1) as target:
    shutil.copyfileobj(source, target)
assert raw.resolve().parent == Path('C:/hyle-scratch').resolve()
raw.unlink()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
identity = {'candidate': candidate, 'tree': tree, 'archive': str(archive),
            'sha256': digest, 'bytes': archive.stat().st_size, 'copies': [], 'stable_build_source': 'hyle-m1r-0d85a9ad', 'stable_source_update': 'full archive then checksum rsync; suffix is not the source identity'}
record = root / '.scratch/validation/m1-route-binding/source-identity.json'
for label, host, extra in [
    ('air', 'kiro@172.22.10.198', []),
    ('mini', 'kiro@172.22.10.107', ['-i', 'C:/Users/kiro/.ssh/codex_mac_172_22_10_107_win']),
]:
    remote = '/Users/kiro/' + archive.name
    subprocess.run(['scp', '-q', *extra, str(archive), host + ':' + remote], check=True)
    source = '/Users/kiro/hyle-m1r-d4a4b389'
    command = ('set -eu\n'
               f'test "$(shasum -a 256 {remote} | cut -d " " -f 1)" = {digest}\n'
               f'mkdir -p {source}\ntar -xzf {remote} -C {source}\n'
               f'cat {source}/SOURCE-MANIFEST.txt\n'
               f'rsync -rlc --delete {source}/ /Users/kiro/hyle-m1r-0d85a9ad/\n')
    subprocess.run(['ssh', '-o', 'BatchMode=yes', *extra, host, 'sh', '-s'],
                   input=command.encode(), check=True)
    identity['copies'].append({'machine': label, 'source': source, 'sha256_verified': True})
    record.write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
command = ('set -eu\n'
           'm1r_archive=/mnt/c/hyle-scratch/m1r-d4a4b389.tar.gz\n'
           f'test "$(sha256sum "$m1r_archive" | cut -d " " -f 1)" = {digest}\n'
           'mkdir -p /root/hyle-m1r-d4a4b389\n'
           'tar -xzf "$m1r_archive" -C /root/hyle-m1r-d4a4b389\n'
           'cat /root/hyle-m1r-d4a4b389/SOURCE-MANIFEST.txt\n'
           'rsync -rlc --delete /root/hyle-m1r-d4a4b389/ /root/hyle-m1r-0d85a9ad/\n')
subprocess.run(['wsl', '-d', 'Ubuntu-24.04', '--', 'sh', '-s'],
               input=command.encode(), check=True)
identity['copies'].append({'machine': 'wsl', 'source': '/root/hyle-m1r-d4a4b389', 'sha256_verified': True})
record.write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
print(json.dumps(identity, indent=2))
