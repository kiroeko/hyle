"""Fetch only the already-admitted immutable upstream source; no build or math edits."""
import hashlib
import json
from pathlib import Path
import tarfile
import urllib.request

root = Path(__file__).resolve().parent / 'm1-cuda-intake'
root.mkdir(exist_ok=True)
revision = '69ff11fc4954396d98326656dc85debd2223f637'
archive = root / ('flashinfer-' + revision + '.tar.gz')
url = 'https://codeload.github.com/flashinfer-ai/flashinfer/tar.gz/' + revision
assert not archive.exists(), 'reuse an existing source instead of downloading twice'
total = 0
with urllib.request.urlopen(url, timeout=60) as response, archive.open('wb') as output:
    while block := response.read(1024 * 1024):
        total += len(block)
        assert total <= 128 * 1024 * 1024, 'bounded source intake'
        output.write(block)
selected = []
with tarfile.open(archive) as source:
    for member in source.getmembers():
        relative = Path(member.name).parts[1:]
        if not relative:
            continue
        if relative[0] in {'include', 'csrc', 'tests', 'CMakeLists.txt', '.gitmodules', 'LICENSE', 'README.md'}:
            if member.isfile() or member.isdir():
                selected.append(member)
    source.extractall(root, members=selected, filter='data')
receipt = {'revision': revision, 'url': url, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'bytes': total, 'members_extracted': len(selected), 'kind': 'source intake only; no qualification verdict'}
(root / 'flashinfer-source.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt))
