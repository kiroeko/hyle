from pathlib import Path

def edit(name, change):
    p = Path(name)
    s = p.read_text(encoding='utf-8')
    result = change(s)
    assert result != s, name
    p.write_text(result, encoding='utf-8', newline='\n')

def replace(s, old, new, count=1):
    assert s.count(old) == count, (old, s.count(old), count)
    return s.replace(old, new)

def prepared_header(s):
    s = replace(s, '#include "hyle/compute/visibility.h"', '#include "hyle/compute/visibility.h"\n#include "hyle/compute/workload.h"')
    s = replace(s, 'OperationResourceBindings resources) noexcept;', 'OperationResourceBindings resources,\n        const WorkloadContext &workload = {}) noexcept;')
    s = replace(s, 'mem::MemoryResourceRef resource) noexcept;', 'mem::MemoryResourceRef resource,\n        const WorkloadContext &workload = {}) noexcept;')
    s = replace(s, 'mem::MemoryResourceRef workspace_resource = {}) noexcept;', 'mem::MemoryResourceRef workspace_resource = {},\n        const WorkloadContext &workload = {}) noexcept;')
    s = replace(s, 'mem::MemoryResourceRef resource = mem::system_resource()) noexcept;', 'mem::MemoryResourceRef resource = mem::system_resource(),\n        const WorkloadContext &workload = {}) noexcept;', count=27)
    s = replace(s, 'std::span<const TensorDesc>, OperationResourceBindings) noexcept;', 'std::span<const TensorDesc>, OperationResourceBindings,\n          const WorkloadContext &) noexcept;')
    s = replace(s, '  HYLE_COMPUTE_API OperationKind kind() const noexcept;', '  // Immutable facts bound during preparation; this cold query retains their owner.\n  HYLE_COMPUTE_API WorkloadContext workload() const noexcept;\n  HYLE_COMPUTE_API OperationKind kind() const noexcept;')
    return s

def delegated_header(s):
    s = replace(s, 'OperationResourceBindings) noexcept;', 'OperationResourceBindings, const WorkloadContext &) noexcept;')
    s = replace(s, 'std::span<const TensorView>, mem::MemoryResourceRef) noexcept;', 'std::span<const TensorView>, mem::MemoryResourceRef,\n      const WorkloadContext &) noexcept;')
    s = replace(s, 'OperationResourceBindings resources) noexcept;', 'OperationResourceBindings resources,\n                  const WorkloadContext &workload = {}) noexcept;')
    s = replace(s, 'mem::MemoryResourceRef workspace_resource = {}) noexcept;', 'mem::MemoryResourceRef workspace_resource = {},\n                  const WorkloadContext &workload = {}) noexcept;')
    s = replace(s, '  std::size_t input_count() const noexcept { return prepared_.input_count(); }', '  WorkloadContext workload() const noexcept { return prepared_.workload(); }\n  std::size_t input_count() const noexcept { return prepared_.input_count(); }')
    return s

def provider_header(s):
    s = replace(s, 'kProviderContractVersion = 13;', 'kProviderContractVersion = 14;')
    s = replace(s, '  ProviderShapeDomain shape{};\n};', '  ProviderShapeDomain shape{};\n  WorkloadContext workload{};\n};', count=2)
    s = replace(s, '  ProviderRouteKey profile_key{};\n};', '  ProviderRouteKey profile_key{};\n  // Compute fixes this after propose; exact prepare consumes the same facts.\n  WorkloadContext workload{};\n};')
    start = s.index('  propose(const Context &context')
    end = s.index('  HYLE_COMPUTE_API static Result<ProviderPrepareAttempt>', start)
    before = s[start:end]
    after = replace(before, 'std::optional<mem::AllocatorRef> allocator = std::nullopt) noexcept;', 'std::optional<mem::AllocatorRef> allocator = std::nullopt,\n          const WorkloadContext &workload = {}) noexcept;')
    return s[:start] + after + s[end:]

def custom_header(s):
    start = s.index('struct KernelRequest final')
    end = s.index('struct KernelProposal final', start)
    s = s[:start] + replace(s[start:end], '  std::span<const TensorDesc> outputs{};', '  std::span<const TensorDesc> outputs{};\n  WorkloadContext workload{};') + s[end:]
    start = s.index('struct KernelPrepareRequest final')
    end = s.index('namespace detail', start)
    return s[:start] + replace(s[start:end], '  std::uint64_t route = 0;', '  std::uint64_t route = 0;\n  WorkloadContext workload{};') + s[end:]

def custom_source(s):
    s = replace(s, 'request.inputs, request.outputs};', 'request.inputs, request.outputs, request.workload};')
    s = replace(s, '      .route = request.route,', '      .route = request.route,\n      .workload = request.workload,')
    return s

def operation_source(s):
    # Shared and delegated descriptor/view preparation, including all typed
    # conveniences, carry one optional cold request. No submit code changes.
    start = s.index('Result<PreparedOperation> prepare_for_mode(')
    end = s.index('Result<OperationInvocation>', start)
    part = s[start:end]
    part = replace(part, 'ProviderRuntimeMode mode) noexcept {', 'ProviderRuntimeMode mode,\n                                           const WorkloadContext &workload) noexcept {', count=2)
    part = replace(part, 'OperationResourceBindings resources) noexcept {', 'OperationResourceBindings resources,\n        const WorkloadContext &workload) noexcept {', count=2)
    part = replace(part, 'mem::MemoryResourceRef resource) noexcept {', 'mem::MemoryResourceRef resource,\n        const WorkloadContext &workload) noexcept {', count=28)
    part = replace(part, 'mem::MemoryResourceRef workspace_resource) noexcept {', 'mem::MemoryResourceRef workspace_resource,\n        const WorkloadContext &workload) noexcept {', count=2)
    part = replace(part, '  HYLE_TRACE_ZONE_NAMED("hyle.compute.prepare");', '  HYLE_TRACE_ZONE_NAMED("hyle.compute.prepare");\n  if (!workload.valid())\n    return std::unexpected(Status::InvalidArgument("compute workload context"));')
    part = replace(part, 'output_requirements.span());', 'output_requirements.span(), {}, std::nullopt, workload);')
    part = replace(part, 'ProviderRuntimeMode::kSharedQueue);', 'ProviderRuntimeMode::kSharedQueue, workload);', count=2)
    part = replace(part, 'ProviderRuntimeMode::kDelegated));', 'ProviderRuntimeMode::kDelegated, workload));', count=2)
    part = replace(part, '                          mode);', '                          mode, workload);')
    part = replace(part, '                     .workspace_resource = resource,\n                 });', '                     .workspace_resource = resource,\n                 }, workload);')
    part = replace(part, 'resource);', 'resource, workload);', count=27)
    s = s[:start] + part + s[end:]
    start = s.index('detail::OperationPreparationAccess::propose(')
    end = s.index('detail::OperationPreparationAccess::prepare_candidate(', start)
    part = s[start:end]
    part = replace(part, 'std::optional<mem::AllocatorRef> requested_allocator) noexcept {', 'std::optional<mem::AllocatorRef> requested_allocator,\n    const WorkloadContext &workload) noexcept {\n  if (!workload.valid())\n    return std::unexpected(Status::InvalidArgument("compute workload context"));')
    part = replace(part, 'request{operation, inputs, outputs, shape};', 'request{operation, inputs, outputs, shape, workload};')
    part = replace(part, '  return proposal;', '  proposal.workload = workload;\n  return proposal;')
    s = s[:start] + part + s[end:]
    s = replace(s, '      .route = proposal.route,\n      .shape = shape,', '      .route = proposal.route,\n      .shape = shape,\n      .workload = proposal.workload,')
    s = replace(s, '  if (!shape.exact()) {\n    auto owned_shape', '  (*prepared)->workload = proposal.workload;\n  if (!shape.exact()) {\n    auto owned_shape')
    s = replace(s, '  result->domain_owner = state;', '  result->workload = state->workload;\n  result->domain_owner = state;')
    marker = 'ProviderInstanceId PreparedOperation::provider_instance_id() const noexcept {'
    s = replace(s, marker, 'WorkloadContext PreparedOperation::workload() const noexcept {\n  return state_ != nullptr ? state_->workload : WorkloadContext{};\n}\n\n' + marker)
    return s

import sys
if '--operation-only' not in sys.argv:
    edit('include/hyle/compute/prepared_operation.h', prepared_header)
    edit('include/hyle/compute/delegated_operation.h', delegated_header)
    edit('src/compute/provider_internal.h', provider_header)
    edit('src/compute/prepared_state.h', lambda s: replace(s, '  PreparedState *domain_owner = nullptr;', '  PreparedState *domain_owner = nullptr;\n  WorkloadContext workload{};'))
    edit('include/hyle/compute/custom_kernel.h', custom_header)
    edit('src/compute/custom_kernel.cc', custom_source)
edit('src/compute/operation.cc', operation_source)
print('Compute cold request and artifact plumbing updated')
