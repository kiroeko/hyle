"""Resume only failed/unrun remote SDK checks; preserve original receipts."""
import datetime
import json
from pathlib import Path
import shutil
import subprocess
import sys

task = Path(__file__).resolve().parent
helper = task / 'combined-delivery.py'
source = helper.read_bytes()
previous = task / 'combined-delivery-before-parent-target.py'
assert not previous.exists()
previous.write_bytes(source.replace(
    b"toolchain_flags = []\nif machine == 'wsl':\n    toolchain_flags = ['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14']\nelif apple:\n    toolchain_flags = ['-DCMAKE_CXX_COMPILER=/usr/bin/c++', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4']\nflags += toolchain_flags",
    b"if machine == 'wsl':\n    flags += ['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14']\nelif apple:\n    flags += ['-DCMAKE_CXX_COMPILER=/usr/bin/c++']").replace(
    b"str(relocated), *toolchain_flags]", b"str(relocated)]"))

for machine, address in (('air', '172.22.10.198'), ('mini', '172.22.10.107')):
    options = ['-o', 'BatchMode=yes']
    if machine == 'mini':
        options += ['-i', 'C:/Users/kiro/.ssh/codex_mac_172_22_10_107_win']
    if machine == 'air':
        script = b"set -eu\ncd /Users/kiro/hyle-m1r-sdk\ntest ! -e logs-before-parent-target\ncp -R logs logs-before-parent-target\n"
        subprocess.run(['ssh', *options, 'kiro@' + address, 'sh', '-s'], input=script, check=True)
    subprocess.run(['scp', *options, str(helper), 'kiro@' + address + ':/Users/kiro/hyle-m1r-combined-delivery.py'], check=True)
subprocess.run(['wsl', '-d', 'Ubuntu-24.04', '--', 'cp',
    '/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-route-binding/combined-delivery.py',
    '/root/hyle-m1r-combined-delivery.py'], check=True)

record = task / 'pending-result.json'
before = task / 'pending-result-before-parent-target.json'
assert not before.exists()
shutil.copyfile(record, before)
shutil.copyfile(task / 'air-delivery.log', task / 'air-delivery-before-parent-target.log')
receipt = json.loads(record.read_text())
assert receipt['status'] == 'FAIL'
assert receipt['checks'][-1]['name'] == 'air-delivery'
receipt['checks'] = [e for e in receipt['checks'] if e['status'] == 'PASS']
assert len(receipt['checks']) == 6
receipt['status'] = 'RUNNING'
receipt['delivery_fixture_correction'] = 'Embedding parent sets documented macOS 14.4 deployment floor; all consumers use the selected producer compiler. No product changes.'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save():
    record.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())

for machine in ('air', 'mini', 'wsl'):
    name = machine + '-delivery'
    command = [sys.executable, '-X', 'utf8', str(task / 'run-remote.py'), 'delivery', machine]
    entry = {'name': name, 'command': command, 'started': now(), 'status': 'RUNNING', 'candidate': receipt['candidate']}
    receipt['checks'].append(entry)
    save()
    print('RUN ' + name, flush=True)
    with (task / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    entry.update(exit_code=result.returncode, ended=now(), status='PASS' if result.returncode == 0 else 'FAIL')
    save()
    print(entry['status'] + ' ' + name, flush=True)
    if result.returncode:
        receipt['status'] = 'FAIL'
        save()
        raise SystemExit(result.returncode)
receipt['status'] = 'PASS'
save()
