"""Wait for the declared Windows gates, then run remaining remote SDKs serially."""
import datetime
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

task = Path(__file__).resolve().parent
result = task / 'r5b-selected-result.json'
deadline = time.monotonic() + 2 * 60 * 60
print('WAIT Windows selected gates; no remote build runs concurrently.', flush=True)
while not result.exists():
    if time.monotonic() >= deadline:
        raise SystemExit('Windows selected result missing after bounded wait')
    time.sleep(5)
selected = json.loads(result.read_text())
assert selected['verdict'] == 'PASS', selected['verdict']
record = task / 'pending-result.json'
before = task / 'pending-result-before-staging-lock.json'
assert not before.exists()
shutil.copyfile(record, before)
shutil.copyfile(task / 'air-delivery.log', task / 'air-delivery-before-staging-lock.log')
receipt = json.loads(record.read_text())
assert receipt['status'] == 'FAIL' and receipt['checks'][-1]['name'] == 'air-delivery'
receipt['checks'] = [entry for entry in receipt['checks'] if entry['status'] == 'PASS']
assert len(receipt['checks']) == 6
receipt['candidate'] = 'c482ce1b33cefecdb949c8b0ec89f9309c3e86ac'
receipt['status'] = 'RUNNING'
receipt['staging_correction'] = 'R5b build-time same-directory resource writer coordination; runtime code unchanged from 7016443b. Prior checks keep their actual candidate identities.'
receipt['windows_staging_selector'] = 'r5b-selected-result.json'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save():
    record.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())

for machine in ('air', 'mini', 'wsl'):
    name = machine + '-delivery'
    command = [sys.executable, '-X', 'utf8', str(task / 'run-remote.py'), 'delivery', machine]
    entry = {'name': name, 'command': command, 'started': now(), 'status': 'RUNNING', 'candidate': receipt['candidate']}
    receipt['checks'].append(entry)
    save()
    print('RUN ' + name, flush=True)
    with (task / (name + '.log')).open('wb') as log:
        done = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    entry.update(exit_code=done.returncode, ended=now(), status='PASS' if done.returncode == 0 else 'FAIL')
    save()
    print(entry['status'] + ' ' + name, flush=True)
    if done.returncode:
        receipt['status'] = 'FAIL'
        save()
        raise SystemExit(done.returncode)
receipt['status'] = 'PASS'
save()
