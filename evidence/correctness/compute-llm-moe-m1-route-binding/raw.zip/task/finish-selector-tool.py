"""Close the bounded tool card only from the finished selected-gate receipts."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

task = Path(__file__).resolve().parent
out = Path('evidence/correctness/apple-runtime-selector-owner-v1')
candidate = '67f4339e7b8b8dc06c535df00a176e773e4b4263'
result = json.loads((task / 'r5b-selected-result.json').read_text())
assert result['candidate_commit'] == candidate and result['verdict'] == 'PASS'
gate = next(g for g in result['selected_gates']
            if g['id'] == 'tool:tests/tooling/validation_selector_test.py')
assert gate['status'] == 'PASS'
receipt_path = Path(gate['receipt'])
receipt = json.loads(receipt_path.read_text())
assert receipt['candidate_commit'] == candidate and receipt['verdict'] == 'PASS'
copied = []
for item in receipt['logs']:
    source = receipt_path.parent / item['path']
    content = source.read_bytes()
    assert hashlib.sha256(content).hexdigest() == item['sha256']
    decoded = content.decode(errors='replace')
    assert 'Ran 57 tests' in decoded and '\nOK' in decoded
    shutil.copyfile(source, out / source.name)
    copied.append(source.name)
shutil.copyfile(receipt_path, out / receipt_path.name)
copied.append(receipt_path.name)
for name in ('selector-apple-owner-history.log',
             'r5b-selected-result-before-history-map.json', 'r5b-selected-result.json'):
    shutil.copyfile(task / name, out / name)
    copied.append(name)
old = out / 'validation.json'
assert not (out / 'validation-before-history-map.json').exists()
shutil.copyfile(old, out / 'validation-before-history-map.json')
data = json.loads(old.read_text())
data.update(candidate=candidate, status='PASS',
            final_suite={'tests': 57, 'pass': 57},
            historical_authorization_focused={'tests': 5, 'pass': 5},
            correction='The original fixture correction was insufficient: immutable history scans omitted mapped external CMake paths. Added those exact paths to the existing rev-list, with READY and genuine CLOSED-owner rejection regression assertions. The full 57-test suite then passed on the final tool candidate.')
data['prior_candidate'] = '256c45473f13e7554d318a10b246e6fd18b10959'
data['inputs'] = {name: hashlib.sha256(subprocess.check_output(
    ['git', 'show', candidate + ':' + name])).hexdigest() for name in data['inputs']}
data['files'].update({name: hashlib.sha256((out / name).read_bytes()).hexdigest()
                      for name in copied + ['validation-before-history-map.json']})
old.write_bytes((json.dumps(data, indent=2) + '\n').encode())
card = Path('docs/implementation/tasks/build/apple-runtime-selector-owner-v1.md')
text = card.read_text(encoding='utf-8')
text = text.replace('状态：AUDITED（只改维护工具，无产品 factor）',
                    '状态：CLOSED（只改维护工具，无产品 factor）')
text += '''
## 最终裁决（2026-09-20）

本节替代上面撤回的终审。最终工具候选`67f4339e7b8b8dc06c535df00a176e773e4b4263`
通过完整57项原工具suite；历史授权专项5项亦通过。真实R5b不可变候选正确追溯至事先AUDITED的
产品提交，保持Apple owner/直接消费者/三交付/OFF边界；实际选中7门全部通过。
本工具卡只签T1–T3，不代签M1-R运行时；原夹具失败和遗漏历史路径导致的BLOCKED计划均保留。
没有修改原门命令、状态协议、P1或证据复用合同，P0范围关闭。后续只有具名owner映射或授权
追溯的可复现错误才重开，不扩大为全库CMake重分类。
'''
card.write_bytes(text.encode('utf-8'))
print(json.dumps({'status': 'PASS', 'candidate': candidate, 'tests': 57}))
