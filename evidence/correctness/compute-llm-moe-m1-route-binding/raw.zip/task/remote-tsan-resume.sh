#!/bin/sh
set -eu
test "$1" = wsl
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
export CTEST_INTERACTIVE_DEBUG_MODE=0 TRACY_ONLY_LOCALHOST=1 TSAN_OPTIONS=halt_on_error=1
m1r_build=/root/hyle-m1r-tsan
m1r_logs=/root/hyle-m1r-sanitizer-logs
test ! -e "$m1r_logs/tsan-tests-before-process-aslr.log"
cp "$m1r_logs/tsan-tests.log" "$m1r_logs/tsan-tests-before-process-aslr.log"
cp "$m1r_build/Testing/Temporary/LastTest.log" "$m1r_logs/tsan-LastTest-before-process-aslr.log"
printf '%s\n' 'Same TSan binaries; disable ASLR only for the validation process and its children.'
setarch x86_64 -R ctest --test-dir "$m1r_build" -L '^(compute|graph)$' -LE headers \
  --no-tests=error --output-on-failure --timeout 180 \
  > "$m1r_logs/tsan-tests.log" 2>&1
cp "$m1r_build/Testing/Temporary/LastTest.log" "$m1r_logs/tsan-LastTest.log"
GTEST_FILTER=CustomKernel.WorkloadIsBoundOnceAndRetainedThroughInvocation \
  setarch x86_64 -R ctest --test-dir "$m1r_build" -R '^hyle_compute_backend_cpu_test$' \
    --no-tests=error --verbose --timeout 180 \
    > "$m1r_logs/tsan-direct-tests.log" 2>&1
cp "$m1r_build/Testing/Temporary/LastTest.log" "$m1r_logs/tsan-direct-LastTest.log"
cat "$m1r_logs/tsan-tests.log"
cat "$m1r_logs/tsan-direct-tests.log"
printf '%s\n' 'M1-R WSL tsan PASS'
