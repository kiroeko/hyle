"""Archive completed M1-R evidence only. Assertions forbid signing unrun gates."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parents[3]
task = root / '.scratch/validation/m1-route-binding'
destination = root / 'evidence/correctness/compute-llm-moe-m1-route-binding'
candidate = 'c482ce1b33cefecdb949c8b0ec89f9309c3e86ac'
runtime_candidate = '7016443b1bf895fc4300958e12099e89385de954'
fixture_candidate = 'd4a4b38955e8feae9d4c768cd232f5d23d0327c2'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def write(path, data):
    path.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

continued = read(task / 'continued-result.json')
assert continued['status'] == 'PASS' and len(continued['gates']) == 15
covered = set(continued['prior_candidate_pass_gates'])
for gate in continued['gates']:
    assert gate['status'] == 'PASS'
    covered.add(gate['id'])
    for log in gate['logs']:
        assert sha(task / log['path']) == log['sha256']
original = read(task / 'selected-result.json')
assert covered == {g['id'] for g in original['selected_gates']} and len(covered) == 28
pending = read(task / 'pending-result.json')
assert pending['status'] == 'PASS' and pending['candidate'] == candidate
assert len(pending['checks']) == 9
assert all(x['status'] == 'PASS' and x['exit_code'] == 0 for x in pending['checks'])
off = read(task / 'apple-off-selected-result.json')
assert all(x['status'] == 'PASS' for x in off['selected_gates'])
staging = read(task / 'r5b-selected-result.json')
assert staging['verdict'] == 'PASS'
assert all(x['status'] in ('PASS', 'REUSED') for x in staging['selected_gates'])

native = []
for machine in ('air', 'mini', 'wsl'):
    log = task / (machine + '-native.log')
    content = log.read_text(encoding='utf-8', errors='replace')
    assert '100% tests passed' in content and 'M1-R ' + machine + ' native selected checks PASS' in content
    native.append({'machine': machine, 'status': 'PASS', 'candidate': next(x.get('candidate', pending['candidate']) for x in pending['checks'] if x['name'] == machine + '-native'),
                   'log': log.name, 'sha256': sha(log)})

delivery = []
sizes = []
for machine in ('windows', 'air', 'mini', 'wsl'):
    if machine == 'windows':
        logs = Path('C:/hyle-scratch/m1r-sdk/logs')
        receipt = read(logs / 'receipt.json')
        payload = {p.name: p.read_bytes() for p in logs.iterdir() if p.is_file()}
    else:
        archive = task / 'remote-evidence' / machine / 'delivery.tar.gz'
        with tarfile.open(archive) as bundle:
            payload = {Path(m.name).name: bundle.extractfile(m).read()
                       for m in bundle.getmembers() if m.isfile() and m.name.startswith('hyle-m1r-sdk/logs/')}
        receipt = json.loads(payload['receipt.json'])
    expected = fixture_candidate if machine == 'windows' else candidate
    assert receipt['status'] == 'PASS' and receipt['candidate'] == expected
    for entry in receipt['commands']:
        assert entry['exit_code'] == 0
        assert hashlib.sha256(payload[entry['log']]).hexdigest() == entry['sha256']
    for name in ('source-test.log', 'shared-relocated-test.log', 'static-relocated-test.log'):
        text = payload[name].decode(errors='replace')
        assert '100% tests passed' in text
        measured = [line.strip() for line in text.splitlines()
                    if 'ModelIdentity=' in line or 'CUDAEnvironment=' in line]
        assert measured, (machine, name)
        assert any('ModelIdentity=8 WorkloadContext=40 PreparedOperation=8 Executable=8'
                   in line for line in measured), (machine, name, measured)
        if machine in ('windows', 'wsl'):
            assert any('CUDAEnvironment=296' in line for line in measured), (machine, name, measured)
        sizes.append({'machine': machine, 'log': name, 'measurements': measured})
    delivery.append({'machine': machine, 'candidate': receipt['candidate'], 'status': 'PASS',
                     'forms': ['source', 'shared-relocated', 'static-relocated'],
                     'consumers': ['ordinary Direct', 'ordinary Graph', 'public footprint']})

windows_asan = task / 'windows-asan-tests.log'
assert '100% tests passed' in windows_asan.read_text(encoding='utf-8', errors='replace')
windows_direct = (task / 'windows-asan-direct-tests.log').read_text(encoding='utf-8', errors='replace')
assert '100% tests passed' in windows_direct and '[       OK ] CustomKernel.WorkloadIsBoundOnceAndRetainedThroughInvocation' in windows_direct
sanitizer_log = (task / 'wsl-sanitizers.log').read_text(encoding='utf-8', errors='replace')
for name in ('asan', 'ubsan', 'tsan'):
    assert 'M1-R WSL ' + name + ' PASS' in sanitizer_log

p0 = read(task / 'p0-review.json')
p0['measurement_status'] = 'PASS'
p0['public_sizes'] = sizes
p0['final_fixture_candidate'] = fixture_candidate
p0['final_packaging_candidate'] = candidate
p0['facts']['warm_state'] = 'Existing Invocation types unchanged; cold artifact metadata retains WorkloadContext. Actual public sizes from all declared delivery consumers are recorded below.'
write(task / 'p0-review.json', p0)
loc = read(task / 'implementation-loc-c482ce1b.json')
assert loc['repository']['commit'] == candidate and loc['self_check'] == 'pass'
summary = {'candidate': candidate, 'status': 'PASS', 'windows_selector_gates': 28,
           'windows_prior_candidate': original['candidate_commit'],
           'windows_fixture_candidate': continued['candidate'],
           'windows_staging_correction_selector': {'candidate': staging['candidate_commit'], 'gates': len(staging['selected_gates']), 'status': 'PASS'},
           'native': native, 'delivery': delivery,
           'sanitizers': ['Windows ASan', 'WSL ASan+LSan', 'WSL UBSan', 'WSL TSan'],
           'sanitizer_method': 'WSL TSan initially failed before test bodies on an address-layout collision. The same instrumented binaries passed with process-local setarch x86_64 -R; no rebuild, system setting, or elevated command.',
           'p0': 'PASS, cold metadata and native dependency seam only; no timing or operator winner claim',
           'unrun': [], 'new_model_coverage_cells': 0}

red_team = read(task / 'red-team.json')
red_team['final_evidence_review'] = {
    'status': 'PASS', 'packaging_candidate': candidate,
    'runtime_candidate': runtime_candidate, 'fixture_candidate': fixture_candidate,
    'checks': [
        'Original and continued Windows receipts jointly cover the exact 28 selected gates; their original commit identities and failure remain.',
        'R5b selector and all nine pending checks passed; all four environment SDK receipts and command log hashes were checked, including source/shared/static ordinary Direct/Graph tests.',
        'Public metadata sizes are checked against all twelve actual SDK footprint outputs, not inferred from source.',
        'Original source reviews above retain their then-pending wording. The final execution verdict is recorded separately here, without changing old receipts or claiming a source review ran tests.',
        'No new model coverage cell, timing result, provider winner, self-written operator extension or old BLOCKED-owner clearance is claimed.'
    ]
}
write(task / 'red-team.json', red_team)

files = {}
for path in task.rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts and 'm1-cuda-intake' not in path.parts:
        if path.suffix in {'.json', '.log', '.py', '.ps1', '.sh', '.cmake', '.txt', '.gz'}:
            files['task/' + path.relative_to(task).as_posix()] = path
for path in Path('C:/hyle-scratch/m1r-sdk/logs').iterdir():
    if path.is_file():
        files['windows-sdk/' + path.name] = path
for name in ('CMakeCache.txt', 'compile_commands.json', 'Testing/Temporary/LastTest.log'):
    path = Path('C:/hyle-scratch/m1r-asan') / name
    assert path.is_file()
    files['windows-asan/' + name] = path
for result in (original, off, staging):
    for gate in result['selected_gates']:
        if gate['status'] not in ('PASS', 'FAIL'):
            continue
        receipt = Path(gate['receipt'])
        files['selector/' + receipt.name] = receipt
        for entry in read(receipt)['logs']:
            path = receipt.parent / entry['path']
            assert sha(path) == entry['sha256']
            files['selector/' + path.name] = path

destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'raw.zip'
assert not archive.exists(), 'preserve any previously published evidence archive'
manifest = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, path in sorted(files.items()):
        content = path.read_bytes()
        bundle.writestr(name, content)
        manifest.append({'path': name, 'bytes': len(content),
                         'sha256': hashlib.sha256(content).hexdigest()})
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
write(destination / 'validation.json', summary)
for name in ('p0-review.json', 'red-team.json'):
    shutil.copyfile(task / name, destination / name)
shutil.copyfile(task / 'implementation-loc-c482ce1b.json', destination / 'implementation-loc.json')
write(destination / 'identity.json', {
    'candidate': candidate, 'runtime_candidate': runtime_candidate, 'fixture_candidate': fixture_candidate,
    'tree': subprocess.check_output(['git', 'rev-parse', candidate + '^{tree}'], text=True).strip(),
    'baseline': '6933817f', 'tier': 'P0', 'status': 'PASS',
    'source_archives': [read(task / n) for n in ('source-identity-0d85a9ad.json', 'source-identity-7016443b.json', 'source-identity-810a8425.json', 'source-identity-0fdfd5b1.json', 'source-identity.json', 'source-identity-c482ce1b.json')],
    'raw': {'file': 'raw.zip', 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'members': manifest},
    'corrections': [
        'Removed an invalid overlong string_view test; length overflow is source-audited, never claimed as runtime coverage.',
        '0d85a9ad corrected only the CUDA test/sample workspace argument; original Windows failure and all prior identities remain.',
        'd4a4b389 completed the keep-going GCC diagnostics: four guarded assertions and a reference structured binding, tests only.',
        '0fdfd5b1 braced two guarded test assertions for GCC dangling-else; no product change.',
        '810a8425 added explicit empty initialization to two Graph test members for GCC Werror; no product change, prior Mac identities retained.',
        '7016443b replaced direct construction of the non-exported MLX Depends class with exported depends and a cold stream check; original Air link failure remains.',
        'Task-local SDK parent corrected missing explicit macOS 14.4 deployment target and uses the producer compiler for installed consumers. Original configure failure retained; no product changes.',
        'Air system Python strips inherited DYLD variables under SIP. Existing loader/driver paths were restored in its native subprocess environment; unchanged source configure/build reused and initial failed tests retained.',
        'WSL TSan startup address collision resolved using process-local setarch x86_64 -R on the same binaries. Initial fatal logs and resumed test logs both retained.',
        'c482ce1b coordinates concurrent Apple runtime resource staging with a build-process lock per destination directory; no C++ runtime changes. Original shared-consumer failure and the non-reproducing 16-pair diagnostic remain.'
    ],
    'limits': [
        'Cold facts and qualification seam only, no new model coverage or dedicated model optimization signed.',
        'CUDA driver_cuda_version is the supported CUDA API level, not the driver package/patch number.',
        'WSL TSan verdict applies to the recorded process-local ASLR-disabled run; CPU instrumentation does not sign native GPU drivers.',
        'Allocator backing must outlive all retained identity handles; changing workload/environment requires new preparation.',
        'No self-written operator research, extension, optimization, comparison or deletion; oneDNN/ggml CPU old blockers remain.'
    ]
})
(destination / 'README.md').write_bytes('''# M1-R：冷模型条件与原生路线接缝验收

本证据只签 [M1-R 任务卡](../../../docs/implementation/tasks/compute/llm-moe-m1-route-binding.md)
的 R1–R5/R5a/R5b。完整候选为 `c482ce1b33cefecdb949c8b0ec89f9309c3e86ac`，
最后C++运行时变化为 `7016443b1bf895fc4300958e12099e89385de954`；夹具固定于`d4a4b389`，
R5b只协调Apple构建期同目录资源复制。
基线为 `6933817f`。这是准备时的事实传递、资源保活与交付验收，新增模型覆盖格为 **0**。

## 已验内容

- ModelIdentity 一次冷分配拥有三个独立字符串；空对象不分配，复用 Mem/Util 所有权。
  Direct、delegated、Graph operation/region 及 Apple/Vulkan 原生程序保留同一 workload。
- 固定条件验证完整匹配、缺失/未知、版本/配置/phase/region 不符和合法通用候选；
  重复执行不重入冷提案/编译。条件夹具不作为模型优化或完整 Provider 覆盖证明。
- CUDA 在 Context 创建时保存设备、UUID、SM、driver CUDA API、runtime 和 Toolkit 事实。
  `driver_cuda_version` 是 CUDA API 支持级别，不是驱动安装包/补丁号。
- 纠正既有 Apple shared 状态依赖接缝：使用 MLX 导出的公开 depends，冷检查原生 stream；
  保留同一上游 primitive，没有新增 copy、kernel 或算术。
- 多个消费目标写同目录`mlx.metallib`时使用构建进程锁；执行期不加锁。原真实构建失败保留，
  16组双copy诊断未复现，记录为风险结构修复，不冒称诊断复现成功。

## 运行与交付

| 环境 | 原生/头检查 | 三交付 |
|---|---|---|
| Windows | selector 原选 28 门由原始与有限续跑收据共同覆盖 | CPU Compute/Graph；补充 CUDA+Vulkan，均 source/static/shared |
| WSL | 21 项，CPU+CUDA（包含 oneDNN 消费） | CPU+CUDA+oneDNN，source/static/shared |
| MacBook Air | 22 项，CPU+Apple+Vulkan | CPU+Apple+Vulkan，source/static/shared |
| Mac mini | 18 项，CPU+Apple | CPU+Apple，source/static/shared；不签 Formal 性能 |

安装消费先搬移 prefix、隐藏 producer，再构建普通 Direct/Graph consumer；Windows DLL 邻置。
四环境公共大小实测：ModelIdentity 8 字节、WorkloadContext 40 字节，PreparedOperation 与
Executable 各 8 字节；CUDA 环境快照为 296 字节。每种交付的原始输出都在归档中。

Windows ASan 与 WSL ASan+LSan、UBSan、TSan 通过共同 owner/Graph 用例及新增 Direct 绑定用例。
WSL TSan 首次在测试体之前发生地址映射冲突；同一插桩二进制在进程级 `setarch x86_64 -R`
下通过，未修改系统设置或重编译。原失败和续跑记录均保留，CPU 插桩不代签 GPU driver。

## 成本、身份与限制

性能级别 **P0 PASS**，仅签复杂度、一次冷拷贝/分配及复用所有权；没有计时、SOTA 或算子胜负
结论。Invocation/submit 未增加 workload 参数、模型比较、设备查询、分配或锁。长度溢出保护
只签源码检查；构造越过实际存储的 string_view 不是合法运行测试，该夹具已删除并留痕。

原始 Windows、Air/Mini 收据保留各自 commit/tree，不重签成最终候选：Apple 专有修复不改变
Windows 已验路径，GCC 夹具修正不改变产品。验证父工程部署版本和 Air 子进程 loader 环境的
纠正均留存失败日志，已通过项不重跑。复用与差异见 [验证摘要](validation.json) 和
[身份及逐文件摘要](identity.json)，原始命令、日志、cache 与脚本在 raw.zip。

allocator backing 必须活到最后一个身份保留者释放；改变模型/阶段或有关原生环境须重新准备。
未新增跨模型/跨进程缓存。全部自研算子仍冻结，旧 ggml CPU 与 oneDNN BLOCKED 不因本卡解除。
统一 Compute+Graph 实现统计为 **49,804 行、205 个实现文件**（不含测试/第三方），相对 M1-G
新增 391 行冷元数据与接缝；完整统计见 [LOC](implementation-loc.json)。
'''.encode('utf-8'))
print(json.dumps({'status': 'PASS', 'candidate': candidate, 'raw_bytes': archive.stat().st_size,
                  'members': len(files)}))
