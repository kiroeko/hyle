param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath('C:\public\project-hyle\hyle')
$scratchRoot = [IO.Path]::GetFullPath('C:\hyle-scratch')
$proof = Join-Path $workspace 'evidence\correctness\compute-llm-moe-m1-route-binding\identity.json'
if ($Execute) {
  $identity = Get-Content -LiteralPath $proof -Raw | ConvertFrom-Json
  if ($identity.status -ne 'PASS') { throw 'Completed evidence is required before cleanup.' }
  $bundle = Join-Path (Split-Path $proof) 'raw.zip'
  if ((Get-FileHash -LiteralPath $bundle -Algorithm SHA256).Hash.ToLowerInvariant() -ne $identity.raw.sha256) {
    throw 'Evidence archive checksum mismatch.'
  }
}
$names = @('m1r-apple-off', 'm1r-asan', 'm1r-core', 'm1r-g', 'm1r-sdk', 'm1r-r5b')
$names += @('0d85a9ad','0fdfd5b1','7016443b','810a8425','d4a4b389','f56c2f67','c482ce1b') | ForEach-Object { "m1r-$_.tar.gz" }
$results = @()
foreach ($name in $names) {
  $path = [IO.Path]::GetFullPath((Join-Path $scratchRoot $name))
  if ([IO.Path]::GetDirectoryName($path) -ne $scratchRoot -or -not $name.StartsWith('m1r-')) {
    throw "Unsafe cleanup target: $path"
  }
  if (-not (Test-Path -LiteralPath $path)) { continue }
  $item = Get-Item -LiteralPath $path -Force
  if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Root is a link: $path" }
  $items = if ($item.PSIsContainer) { @(Get-ChildItem -LiteralPath $path -Force -Recurse) } else { @($item) }
  $bytes = ($items | Where-Object { -not $_.PSIsContainer -and -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) } | Measure-Object Length -Sum).Sum
  $links = @($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })
  if ($Execute) {
    foreach ($link in ($links | Sort-Object { $_.FullName.Length } -Descending)) {
      if ($link.PSIsContainer) { [IO.Directory]::Delete($link.FullName) }
      else { [IO.File]::Delete($link.FullName) }
    }
    Remove-Item -LiteralPath $path -Recurse -Force
  }
  $results += [pscustomobject]@{ path = $path; bytes = $bytes; links_unlinked_without_following = $links.Count; deleted = [bool]$Execute }
}
$json = $results | ConvertTo-Json -Depth 5
$record = Join-Path $workspace '.scratch\validation\m1-route-binding\closed-windows-cleanup.json'
[IO.File]::WriteAllText($record, $json + "`n", [Text.UTF8Encoding]::new($false))
$json
