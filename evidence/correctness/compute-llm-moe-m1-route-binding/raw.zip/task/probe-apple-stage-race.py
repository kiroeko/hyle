"""Bounded repro of the exact two same-directory consumer staging commands."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/kiro/hyle-m1r-stage-repro')
assert not root.exists()
root.mkdir()
source = Path('/Users/kiro/hyle-m1r-sdk/shared-relocated/lib/mlx.metallib')
expected = hashlib.sha256(source.read_bytes()).hexdigest()
records = []
for index in range(16):
    destination = root / str(index)
    destination.mkdir()
    arguments = ['/opt/homebrew/bin/cmake', '-E', 'copy_if_different', str(source), str(destination / 'mlx.metallib')]
    children = [subprocess.Popen(arguments, stdout=subprocess.PIPE, stderr=subprocess.STDOUT) for _ in range(2)]
    outputs = [child.communicate()[0].decode(errors='replace') for child in children]
    result = {'iteration': index, 'exits': [c.returncode for c in children], 'output': outputs,
              'complete_file': hashlib.sha256((destination / 'mlx.metallib').read_bytes()).hexdigest() == expected}
    records.append(result)
    if any(result['exits']):
        break
print(json.dumps({'source_sha256': expected, 'same_destination': True, 'records': records}, indent=2))
