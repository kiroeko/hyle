"""Continue unchanged SDK binaries after fixing only the child loader environment."""
import datetime
import json
from pathlib import Path
import shutil
import subprocess
import sys

task = Path(__file__).resolve().parent
helper = task / 'combined-delivery.py'
subprocess.run(['ssh', '-o', 'BatchMode=yes', 'kiro@172.22.10.198', 'sh', '-s'],
    input=b'set -eu\ncd /Users/kiro/hyle-m1r-sdk\ntest ! -e logs-before-loader-env\ncp -R logs logs-before-loader-env\ncp source-build/Testing/Temporary/LastTest.log logs-before-loader-env/LastTest.log\ncp /Users/kiro/hyle-m1r-combined-delivery.py logs-before-loader-env/combined-delivery.py\n', check=True)
subprocess.run(['scp', '-o', 'BatchMode=yes', str(helper),
    'kiro@172.22.10.198:/Users/kiro/hyle-m1r-combined-delivery.py'], check=True)
record = task / 'pending-result.json'
before = task / 'pending-result-before-loader-env.json'
assert not before.exists()
shutil.copyfile(record, before)
shutil.copyfile(task / 'air-delivery.log', task / 'air-delivery-before-loader-env.log')
receipt = json.loads(record.read_text())
assert receipt['status'] == 'FAIL' and receipt['checks'][-1]['name'] == 'air-delivery'
receipt['checks'] = [e for e in receipt['checks'] if e['status'] == 'PASS']
assert len(receipt['checks']) == 6
receipt['status'] = 'RUNNING'
receipt['air_loader_environment'] = 'macOS SIP removes DYLD_* before system Python starts; native subprocess environment now explicitly restores installed Vulkan loader/driver paths. Source configure/build reused unchanged.'

def save():
    record.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

for machine in ('air', 'mini', 'wsl'):
    name = machine + '-delivery'
    command = [sys.executable, '-X', 'utf8', str(task / 'run-remote.py'), 'delivery', machine]
    entry = {'name': name, 'command': command, 'started': now(), 'status': 'RUNNING', 'candidate': receipt['candidate']}
    receipt['checks'].append(entry)
    save()
    print('RUN ' + name, flush=True)
    with (task / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    entry.update(exit_code=result.returncode, ended=now(), status='PASS' if result.returncode == 0 else 'FAIL')
    save()
    print(entry['status'] + ' ' + name, flush=True)
    if result.returncode:
        receipt['status'] = 'FAIL'
        save()
        raise SystemExit(result.returncode)
receipt['status'] = 'PASS'
save()
