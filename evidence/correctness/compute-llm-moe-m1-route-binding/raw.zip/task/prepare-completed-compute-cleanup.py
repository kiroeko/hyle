from pathlib import Path
task = Path(__file__).resolve().parent
text = (task / 'cleanup-windows-sdk.ps1').read_text()
text = text.replace("(Join-Path $m1rTask 'continued-result.json')", "'C:/public/project-hyle/hyle/.git/hyle-validation/369b174723a6ff28a78cf70fe4a3c93e6488381820ef9639a2f1c9ece546a553.json'")
text = text.replace("$m1rReceipt.status -ne 'PASS'", "$m1rReceipt.verdict -ne 'PASS'")
text = text.replace("C:\\hyle-scratch\\m1r-g\\cd86175af864fa00e30d", "C:\\hyle-scratch\\m1r-r5b\\270c3875b4b53932c1e9")
text = text.replace("completed-windows-sdk-metadata", "completed-r5b-compute-sdk-metadata")
text = text.replace("completed-windows-sdk-cleanup.json", "completed-r5b-compute-sdk-cleanup.json")
text = text.replace("@('compute', 'graph')", "@('compute')")
start = text.index('  $m1rGate =')
end = text.index('  $m1rTarget =', start)
text = text[:start] + text[end:]
needle = "$m1rAllowedRoot ="
checks = '''if ($m1rReceipt.candidate_commit -ne '67f4339e7b8b8dc06c535df00a176e773e4b4263') { throw 'Wrong completed candidate' }
foreach ($m1rLog in $m1rReceipt.logs) {
  $m1rLogPath = Join-Path 'C:/public/project-hyle/hyle/.git/hyle-validation' $m1rLog.path
  if ((Get-FileHash -LiteralPath $m1rLogPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $m1rLog.sha256) { throw 'Receipt log mismatch' }
}
'''
text = text.replace(needle, checks + needle, 1)
(task / 'cleanup-r5b-compute.ps1').write_bytes(text.encode())
