$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logs = Join-Path $canonicalRoot '.scratch\validation\m1-route-binding'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
$env:Path = 'C:\public\tools\glslang;C:\public\tools\hyle-vulkan\1.4.357.0\Bin;' + $env:Path
# Import the ordinary toolchain without compiling another candidate.
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -Preset windows-ninja -BinaryDir C:\hyle-scratch\m1r-core -ExtraArgs @('--target','help') > (Join-Path $logs 'selector-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Set-Location -LiteralPath $canonicalRoot
# This new Direct-lifetime case is registered in the CPU backend test binary.
# Its ASan target is already built; run only the relevant case before SDK work.
Copy-Item -LiteralPath 'C:\hyle-scratch\m1r-asan\Testing\Temporary\LastTest.log' -Destination (Join-Path $logs 'windows-asan-common-LastTest.log')
$env:GTEST_FILTER = 'CustomKernel.WorkloadIsBoundOnceAndRetainedThroughInvocation'
& python -X utf8 -c 'import ctypes,subprocess,sys; ctypes.windll.kernel32.SetErrorMode(0x8003); sys.exit(subprocess.run(["ctest","--test-dir","C:/hyle-scratch/m1r-asan","-R","^hyle_compute_backend_cpu_test$","--verbose","--no-tests=error","--timeout","60"]).returncode)' > (Join-Path $logs 'windows-asan-direct-tests.log') 2>&1
Remove-Item Env:GTEST_FILTER
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$env:CMAKE_TOOLCHAIN_FILE = 'C:\hyle-scratch\m1r-g\cd86175af864fa00e30d\native-context.cmake'
& python -X utf8 -c 'import ctypes,runpy,sys; ctypes.windll.kernel32.SetErrorMode(0x8003); sys.argv=["combined-delivery.py","C:/public/project-hyle/hyle","C:/hyle-scratch/m1r-sdk","windows"]; runpy.run_path(".scratch/validation/m1-route-binding/combined-delivery.py",run_name="__main__")'
exit $LASTEXITCODE
