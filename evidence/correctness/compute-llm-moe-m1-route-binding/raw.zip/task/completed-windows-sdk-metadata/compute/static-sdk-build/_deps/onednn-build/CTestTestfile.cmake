# CMake generated Testfile for 
# Source directory: C:/public/tools/hyle-dependencies/v1/sources/onednn-71094df45190-7ee703ecda81
# Build directory: C:/hyle-scratch/m1r-g/cd86175af864fa00e30d/delivery-compute/selected-compute/static-sdk-build/_deps/onednn-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("src")
subdirs("examples")
subdirs("tests")
