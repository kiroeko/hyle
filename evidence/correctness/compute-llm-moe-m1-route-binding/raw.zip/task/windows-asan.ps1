$ErrorActionPreference = 'Stop'
$m1rRoot = 'C:\public\project-hyle\hyle'
$m1rBuild = 'C:\hyle-scratch\m1r-asan'
$m1rLogs = Join-Path $m1rRoot '.scratch\validation\m1-route-binding'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1rErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1rErrorMode]::SetErrorMode(0x8003)
. (Join-Path $m1rRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'compute,compute_backend_cpu,compute_provider_native,graph' -BinaryDir $m1rBuild -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=ON','-DHYLE_SANITIZER=asan','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') > (Join-Path $m1rLogs 'windows-asan-configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& cmake --build $m1rBuild --parallel 2 --target hyle_compute_tests hyle_compute_backend_cpu_tests hyle_graph_tests > (Join-Path $m1rLogs 'windows-asan-build.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$m1rBin = Join-Path $m1rBuild 'bin'
foreach ($m1rDll in Get-ChildItem -LiteralPath $m1rBuild -Recurse -File -Filter '*.dll') {
  $m1rDestination = Join-Path $m1rBin $m1rDll.Name
  if ($m1rDll.FullName -ne $m1rDestination) {
    Copy-Item -LiteralPath $m1rDll.FullName -Destination $m1rDestination -Force
  }
}
& ctest --test-dir $m1rBuild -L '^(compute|graph)$' -LE headers --output-on-failure --timeout 60 > (Join-Path $m1rLogs 'windows-asan-tests.log') 2>&1
exit $LASTEXITCODE
