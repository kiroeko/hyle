param([switch]$Delete)
$ErrorActionPreference = 'Stop'
$m1rTask = 'C:\public\project-hyle\hyle\.scratch\validation\m1-route-binding'
$m1rReceipt = Get-Content -LiteralPath 'C:/public/project-hyle/hyle/.git/hyle-validation/ad195bb5af8ebaeae3718a200b15880738f1f24e44dc2c9eb63947e27ebaee85.json' -Raw | ConvertFrom-Json
if ($m1rReceipt.verdict -ne 'PASS') { throw 'Windows continuation has not passed' }
if ($m1rReceipt.candidate_commit -ne '67f4339e7b8b8dc06c535df00a176e773e4b4263') { throw 'Wrong completed candidate' }
foreach ($m1rLog in $m1rReceipt.logs) {
  $m1rLogPath = Join-Path 'C:/public/project-hyle/hyle/.git/hyle-validation' $m1rLog.path
  if ((Get-FileHash -LiteralPath $m1rLogPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $m1rLog.sha256) { throw 'Receipt log mismatch' }
}
$m1rAllowedRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\m1r-r5b\270c3875b4b53932c1e9')
$m1rArchive = Join-Path $m1rTask 'completed-r5b-graph-sdk-metadata'
[void](New-Item -ItemType Directory -Path $m1rArchive -Force)
$m1rInventory = @()
foreach ($m1rComponent in @('graph')) {
  $m1rTarget = [IO.Path]::GetFullPath((Join-Path $m1rAllowedRoot ('delivery-' + $m1rComponent + '\selected-' + $m1rComponent)))
  if (-not $m1rTarget.StartsWith($m1rAllowedRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped allowed root' }
  if (-not (Test-Path -LiteralPath $m1rTarget -PathType Container)) { throw 'Expected completed SDK directory missing' }
  $m1rItem = Get-Item -LiteralPath $m1rTarget
  if (($m1rItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Root is a link' }
  $m1rEntries = @(Get-ChildItem -LiteralPath $m1rTarget -Recurse -Force)
  $m1rLinks = @($m1rEntries | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 })
  foreach ($m1rLink in $m1rLinks) {
    if (-not $m1rLink.FullName.StartsWith($m1rTarget + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Link escaped target' }
    if ($m1rLink.LinkType -notin @('Junction', 'SymbolicLink')) { throw 'Unknown reparse point' }
  }
  $m1rFiles = @($m1rEntries | Where-Object { -not $_.PSIsContainer -and ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0 })
  foreach ($m1rFile in $m1rFiles | Where-Object Name -In @('CMakeCache.txt', 'LastTest.log', 'install_manifest.txt', 'CTestTestfile.cmake')) {
    $m1rRelative = [IO.Path]::GetRelativePath($m1rTarget, $m1rFile.FullName)
    $m1rSaved = Join-Path (Join-Path $m1rArchive $m1rComponent) $m1rRelative
    [void](New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($m1rSaved)) -Force)
    Copy-Item -LiteralPath $m1rFile.FullName -Destination $m1rSaved -Force
  }
  $m1rInventory += [PSCustomObject]@{ path = $m1rTarget; files = $m1rFiles.Count; bytes = ($m1rFiles | Measure-Object Length -Sum).Sum; unlinked_only = @($m1rLinks | Select-Object FullName, LinkType, Target); deleted = [bool]$Delete }
  if ($Delete) {
    # Nonrecursive .NET deletion removes the link entry, never the linked cache.
    foreach ($m1rLink in $m1rLinks) {
      if ($m1rLink.PSIsContainer) { [IO.Directory]::Delete($m1rLink.FullName, $false) }
      else { [IO.File]::Delete($m1rLink.FullName) }
    }
    if (Get-ChildItem -LiteralPath $m1rTarget -Recurse -Force -Attributes ReparsePoint) { throw 'Links remain' }
    Remove-Item -LiteralPath $m1rTarget -Recurse -Force
  }
}
$m1rInventory | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $m1rTask 'completed-r5b-graph-sdk-cleanup.json') -Encoding utf8
$m1rInventory | Format-Table -AutoSize
