$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logs = Join-Path $canonicalRoot '.scratch\validation\m1-route-binding'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
$env:Path = 'C:\public\tools\glslang;C:\public\tools\hyle-vulkan\1.4.357.0\Bin;' + $env:Path
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -Preset windows-ninja -BinaryDir C:\hyle-scratch\m1r-core -ExtraArgs @('--target','help') > (Join-Path $logs 'continued-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Set-Location -LiteralPath $canonicalRoot
& python -X utf8 scripts/validation-select.py plan --base 72c58fc0 --candidate HEAD --context .scratch/validation/windows-msvc-context.json --output .scratch/validation/m1-route-binding/corrected-plan.json > (Join-Path $logs 'continued-plan.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python -X utf8 .scratch/validation/m1-route-binding/continue-selected.py
exit $LASTEXITCODE
