#!/bin/sh
set -eu
test "$1" = wsl
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 CTEST_INTERACTIVE_DEBUG_MODE=0 TRACY_ONLY_LOCALHOST=1
m1r_source=/root/hyle-m1r-0d85a9ad
m1r_logs=/root/hyle-m1r-sanitizer-logs
mkdir -p "$m1r_logs"
grep 'd4a4b389' "$m1r_source/SOURCE-MANIFEST.txt"
for m1r_sanitizer in asan ubsan tsan; do
  m1r_build=/root/hyle-m1r-$m1r_sanitizer
  cmake -S "$m1r_source" -B "$m1r_build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=/usr/bin/g++-14 \
    -DHYLE_DEV_FACTORS=compute,compute_backend_cpu,compute_provider_native,graph \
    -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
    -DHYLE_STATIC=ON -DHYLE_SANITIZER="$m1r_sanitizer" -DHYLE_WERROR=ON \
    -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DHYLE_COMPUTE_CPU=ON \
    -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=OFF \
    -DHYLE_COMPUTE_ONEDNN=OFF > "$m1r_logs/$m1r_sanitizer-configure.log" 2>&1
  cmake --build "$m1r_build" --parallel 2 --target hyle_compute_tests hyle_compute_backend_cpu_tests hyle_graph_tests \
    > "$m1r_logs/$m1r_sanitizer-build.log" 2>&1
  cp "$m1r_build/CMakeCache.txt" "$m1r_logs/$m1r_sanitizer-CMakeCache.txt"
  cp "$m1r_build/compile_commands.json" "$m1r_logs/$m1r_sanitizer-compile_commands.json"
  ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 TSAN_OPTIONS=halt_on_error=1 \
    ctest --test-dir "$m1r_build" -L '^(compute|graph)$' -LE headers \
      --no-tests=error --output-on-failure --timeout 180 \
      > "$m1r_logs/$m1r_sanitizer-tests.log" 2>&1
  cp "$m1r_build/Testing/Temporary/LastTest.log" "$m1r_logs/$m1r_sanitizer-LastTest.log"
  ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 TSAN_OPTIONS=halt_on_error=1 \
    GTEST_FILTER=CustomKernel.WorkloadIsBoundOnceAndRetainedThroughInvocation \
    ctest --test-dir "$m1r_build" -R '^hyle_compute_backend_cpu_test$' \
      --no-tests=error --verbose --timeout 180 \
      > "$m1r_logs/$m1r_sanitizer-direct-tests.log" 2>&1
  cp "$m1r_build/Testing/Temporary/LastTest.log" "$m1r_logs/$m1r_sanitizer-direct-LastTest.log"
  cat "$m1r_logs/$m1r_sanitizer-tests.log"
  cat "$m1r_logs/$m1r_sanitizer-direct-tests.log"
  printf '%s\n' "M1-R WSL $m1r_sanitizer PASS"
done
