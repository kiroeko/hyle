"""Remove only declared M1-R validation products after collecting and signing evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

machine = sys.argv[1]
assert machine in ('air', 'mini', 'wsl')
task = Path(__file__).resolve().parent
evidence = task.parents[2] / 'evidence/correctness/compute-llm-moe-m1-route-binding'
identity = json.loads((evidence / 'identity.json').read_text())
assert identity['status'] == 'PASS'
assert hashlib.sha256((evidence / 'raw.zip').read_bytes()).hexdigest() == identity['raw']['sha256']
assert (task / 'remote-evidence' / machine / 'delivery.tar.gz').is_file()
prefix = '/root' if machine == 'wsl' else '/Users/kiro'
names = ['hyle-m1r-native', 'hyle-m1r-sdk', 'hyle-m1r-tools', 'hyle-m1r-stage-repro',
         'hyle-m1r-combined-delivery.py', 'hyle-m1r-probe-stage.py']
for revision in ('f56c2f67', '0d85a9ad', '7016443b', '810a8425', '0fdfd5b1', 'd4a4b389', 'c482ce1b'):
    names += ['hyle-m1r-' + revision, 'm1r-' + revision + '.tar.gz']
if machine == 'wsl':
    assert (task / 'remote-evidence/wsl/sanitizers.tar.gz').is_file()
    names += ['hyle-m1r-asan', 'hyle-m1r-ubsan', 'hyle-m1r-tsan', 'hyle-m1r-sanitizer-logs']
script = '''import json, os, shutil
from pathlib import Path
prefix = Path(%r)
names = %r
results = []
for name in names:
    path = prefix / name
    if not path.exists():
        continue
    assert path.resolve().parent == prefix and not path.is_symlink()
    total = 0
    if path.is_dir():
        for directory, dirs, files in os.walk(path, followlinks=False):
            for file in files:
                entry = Path(directory) / file
                if not entry.is_symlink():
                    total += entry.stat().st_size
        shutil.rmtree(path)
    else:
        total = path.stat().st_size
        path.unlink()
    results.append({'path': str(path), 'bytes': total, 'deleted': True})
print(json.dumps(results, indent=2))
''' % (prefix, names)
if machine == 'wsl':
    command = ['wsl', '-d', 'Ubuntu-24.04', '--', 'python3', '-']
else:
    command = ['ssh', '-o', 'BatchMode=yes']
    if machine == 'mini':
        command += ['-i', 'C:/Users/kiro/.ssh/codex_mac_172_22_10_107_win']
    command += ['kiro@' + ('172.22.10.198' if machine == 'air' else '172.22.10.107'), 'python3', '-']
completed = subprocess.run(command, input=script.encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
(task / (machine + '-closed-cleanup.json')).write_bytes(completed.stdout)
print(completed.stdout.decode())
