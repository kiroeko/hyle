"""Collect only existing declared validation logs, never product source or models."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

machine, kind = sys.argv[1:]
assert machine in ('air', 'mini', 'wsl') and kind in ('native', 'delivery', 'sanitizers')
out = Path('.scratch/validation/m1-route-binding/remote-evidence') / machine
out.mkdir(parents=True, exist_ok=True)
prefix = '/root' if machine == 'wsl' else '/Users/kiro'
if machine == 'wsl':
    command = ['wsl', '-d', 'Ubuntu-24.04', '--', 'sh', '-s']
else:
    command = ['ssh', '-o', 'BatchMode=yes']
    if machine == 'mini':
        command += ['-i', 'C:/Users/kiro/.ssh/codex_mac_172_22_10_107_win']
    command += ['kiro@' + ('172.22.10.198' if machine == 'air' else '172.22.10.107'), 'sh', '-s']
if kind == 'native':
    members = ['hyle-m1r-native/' + n for n in ('CMakeCache.txt', 'selected-tests.txt',
               'build.ninja', 'CMakeFiles/rules.ninja', 'Testing/Temporary/LastTest.log')]
elif kind == 'delivery':
    members = ['hyle-m1r-sdk/logs']
    if machine == 'air':
        members += ['hyle-m1r-sdk/logs-before-parent-target',
                    'hyle-m1r-sdk/logs-before-loader-env',
                    'hyle-m1r-sdk/logs-before-staging-lock']
else:
    assert machine == 'wsl'
    members = ['hyle-m1r-sanitizer-logs']
script = ('set -eu\ncd ' + prefix + '\ntar -czf - ' + ' '.join(members) + '\n').encode()
archive = out / (kind + '.tar.gz')
assert not archive.exists(), 'preserve prior collected evidence'
with archive.open('wb') as target:
    result = subprocess.run(command, input=script, stdout=target, stderr=subprocess.PIPE)
if result.returncode:
    print(result.stderr.decode(errors='replace'))
    raise SystemExit(result.returncode)
receipt = {'machine': machine, 'kind': kind, 'members': members,
           'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}
archive.with_suffix('.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt))
