#include "iree/async/operation.h"
#include "iree/async/operations/semaphore.h"
#include <cstddef>
#include <cstdio>
int main(){
  std::printf("operation_size=%zu wait_size=%zu count_offset=%zu semaphores_offset=%zu\n",
      sizeof(iree_async_operation_t),sizeof(iree_async_semaphore_wait_operation_t),
      offsetof(iree_async_semaphore_wait_operation_t,count),
      offsetof(iree_async_semaphore_wait_operation_t,semaphores));
}
