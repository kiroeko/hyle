from pathlib import Path
import hashlib,json,os,shlex,subprocess,time
root=Path('/Users/kiro/hyle-scratch/compute-unified/foundation-f5-native-host-vulkan-tsan');build=root/'build'
lines=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','commands','public_native'],text=True).splitlines()
actual=shlex.split(next(l for l in lines if '/compute_provider_iree_vulkan/' in l and '/native_program.cc' in l and ' -c ' in l))
filtered=[];i=0
while i<len(actual):
    if actual[i] in ('-o','-c','-MF','-MT'):i+=2;continue
    if actual[i]=='-MD':i+=1;continue
    filtered.append(actual[i]);i+=1
record={'candidate':'25e4fb398e2a782ee60f916c3c6351c4736b6eda','scope':'same actual IREE headers/config and adapter flags, compare built-in TSan conditional layout','stages':[]}
for mode in ('instrumented','vendor-uninstrumented'):
    binary=root/('layout-'+mode)
    command=filtered.copy()
    if mode=='vendor-uninstrumented':command=[s for s in command if s!='-fsanitize=thread' and s!='-DHYLE_DETAIL_SANITIZER_THREAD=1']
    command += [str(root/'iree_tsan_layout_probe.cc'),'-o',str(binary)]
    p=subprocess.run(command,cwd=build,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
    (root/('layout-'+mode+'-compile.log')).write_text(p.stdout)
    assert p.returncode==0,p.stdout
    result=subprocess.run([str(binary)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=10)
    record['stages'].append({'mode':mode,'command':command,'compile_exit':p.returncode,'run_exit':result.returncode,'output':result.stdout,'source_sha256':hashlib.sha256((root/'iree_tsan_layout_probe.cc').read_bytes()).hexdigest()})
    print(mode,result.stdout.strip(),flush=True)
(root/'layout-probe.json').write_text(json.dumps(record,indent=2))
