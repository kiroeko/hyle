from pathlib import Path
import hashlib,json,sys,subprocess,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3]
RUN=ROOT/'.scratch/inference-gaps/g04-g05/common-encoded'
OUT=ROOT/'evidence/correctness/inference-g04-g05-cuda-encoded-page-source'
last=int(sys.argv[1]);records=[]
for attempt in range(1,last+1):
 record=json.loads((RUN/f'cuda-{attempt}/result.json').read_text())
 assert record['state'].startswith('TERMINAL_')
 record['attempt']=attempt;records.append(record)
assert records[-1]['state']=='TERMINAL_PASS'
xml=ET.parse(RUN/f'cuda-{last}/tests.xml').getroot()
assert int(xml.attrib['tests'])==2 and int(xml.attrib['failures'])==0 and int(xml.attrib.get('disabled',0))==0
fixture='tests/compute_batch/encoded_page_common_consumer.cc'
inputs={item['path']:item['sha256'] for item in records[-1]['inputs']}
assert hashlib.sha256((ROOT/fixture).read_bytes()).hexdigest()==inputs[fixture]
log=(RUN/f'cuda-{last}/tests.log').read_text()
assert 'CPU+CUDA' in log
manifest=json.loads((ROOT/'third_party/flashinfer_cache/patches.json').read_text())['files'][0]
lock=json.loads((ROOT/'cmake/HyleDependencyLock.json').read_text())
entry=next(d for d in lock['dependencies'] if d['name']=='flashinfer_cache_patches')
base='/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build/src/compute_provider_flashinfer'
header=base+'/cache-source-'+entry['vendored']['tree_sha256']+'/'+manifest['path']
upstream='/root/.cache/hyle/dependencies/v1/sources/flashinfer-69ff11fc4954-dda66e35e348/'+manifest['path']
digests=subprocess.check_output(['wsl','-d','Ubuntu-24.04','-u','root','--','sha256sum',upstream,header],text=True).splitlines()
assert digests[0].split()[0]==manifest['before_sha256']
assert digests[1].split()[0]==manifest['after_sha256']
OUT.mkdir(parents=True,exist_ok=False)
result={
 'kind':'G04_G05_CUDA_ENCODER_F2_DIRECT_GRAPH_JOINT_SOURCE_STAGE',
 'verdict':'PASS_FINITE_ACTUAL_WSL_CUDA_AND_CPU_CUDA_SOURCE',
 'owners_remain':'AUDITED; whole G04/G05 not accepted',
 'fixture_sha256':inputs[fixture],
 'actual_upstream_and_derived_header_sha256':digests,
 'patch_input_sha256':{name:sha for name,sha in inputs.items() if name.startswith('third_party/flashinfer_cache/') or name=='src/compute_provider_flashinfer/CMakeLists.txt'},
 'identity':records[-1]['identity'],
 'qualified':[
  'Actual FP8 E4M3FN K/V with independent fixed K=.5 and V=2 scales, F16 Q/output',
  '12 successful episodes x6 updates: Direct, CUDA-only Graph, required CPU+CUDA Graph; single/multi request; D64/128 and D256/256',
  'Paired K/V encoder Graph uses two disjoint outputs in one real WriteLease, one original Completion and F1 write ticket',
  'Independent K/V Graphs retain two original writers and completions into the same original F2 Update',
  'Final-only pending receiver wait, exact dirty byte cost, complete K/V byte oracles, old reader and shared clean page preserved',
  'Nonzero K/Q=.125 and independent weighted softmax; required CPU Abs/Cast prefix and Cast/Neg suffix in joint route',
  'Six failed paired/independent second producer episodes retain original InvalidArgument through final completion and refuse output after final wait; every target writer refuses publication'],
 'finite_native_fix':'FP8 QK64/VO128 original K loader had4/8=0iterations. Private K tile stride/extent128 with zero upper half; original global layout and QK64 math retained. Producers/repack/3dispatcher shared-memory accounting patched in verified build-local source; only native_cache TU uses derived headers.',
 'P0':'Original Graph/Program/Completion/F1/F2/page receiver and CPU+CUDA coordinator reused. No new runtime, full-history decode or mask. Explicit first clone; subsequent bytes=requests*(Krow+Vrow).',
 'not_proven':['BF16 encoded F2/Graph qualification','new-domain complete risk and installed static/shared SDK matrix','qualified candidate P1','whole G04/G05 and other goal items'],
 'runs':[{k:v for k,v in r.items() if k!='inputs'} for r in records],
 'cumulative_seconds':sum(r['cumulative_seconds'] for r in records)}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as raw:
 for r in records:
  attempt=r['attempt']
  for f in sorted((RUN/f'cuda-{attempt}').iterdir()):
   if f.is_file():raw.write(f,f'cuda-{attempt}/{f.name}')
  with zipfile.ZipFile(RUN/f'source-cuda-{attempt}.zip') as source:
   raw.writestr(f'inputs/cuda-{attempt}/{fixture}',source.read(fixture))
   for path in source.namelist():
    if path.startswith('third_party/flashinfer_cache/') or path=='src/compute_provider_flashinfer/CMakeLists.txt':
     raw.writestr(f'inputs/cuda-{attempt}/{path}',source.read(path))
   raw.writestr(f'inputs/cuda-{attempt}/source-manifest.json',source.read('source-manifest.json'))
 for file in sorted((RUN.parent/'selector-prefix-check').glob('*')):
  if file.is_file():raw.write(file,'tool-supplement/'+file.name)
 for name in ['common_encoded_cuda.py','launch_common_cuda.py','seal_common_cuda.py']:
  raw.write(RUN.parent/name,name)
print(json.dumps({'tests':2,'cumulative_seconds':result['cumulative_seconds']}))
