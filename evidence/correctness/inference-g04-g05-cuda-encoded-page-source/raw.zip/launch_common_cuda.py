from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'.scratch/inference-gaps/g04-g05/common-encoded';OUT.mkdir(exist_ok=True)
attempt=sys.argv[1];archive=OUT/f'source-cuda-{attempt}.zip';assert not archive.exists()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines();inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for name in sorted(set(paths)):
  if name.startswith(('evidence/','.scratch/','.git')):continue
  file=ROOT/name
  if not file.is_file():continue
  raw=file.read_bytes();inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()});package.writestr(name,raw)
 package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
raise SystemExit(subprocess.run(['wsl','-d','Ubuntu-24.04','-u','root','--','python3',
 '/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/common_encoded_cuda.py',
 f'/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/common-encoded/source-cuda-{attempt}.zip',attempt,*sys.argv[2:]]).returncode)
