from pathlib import Path
import subprocess,json,time,sys,shutil,hashlib
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';mode=sys.argv[1];assert mode in ('static','shared')
candidate='d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f'
producer=Path('C:/h7/inference-g01-native-vulkan/build') if mode=='shared' else Path('C:/h7/w-vulkan/selected-graph/static-sdk-build')
workspace=Path('C:/h7/inference-g01-'+mode+'-sdk');workspace.mkdir(exist_ok=True)
stage=workspace/'staging';prefix=workspace/'relocated';source=workspace/'consumer-source';build=workspace/'consumer-build';source.mkdir(exist_ok=True)
result_file=out/(mode+'-sdk-result.json');old=json.loads(result_file.read_text()) if result_file.exists() else None
records=old['stages'] if old else []
if old:assert old['candidate']==candidate
def done(name):return next((x for x in reversed(records) if x['stage']==name),{}).get('exit_code')==0
def run(name,args):
 attempt=1+sum(x['stage']==name for x in records);log=out/(mode+'-sdk-'+name+'-'+str(attempt)+'.log');started=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'candidate':candidate,'mode':mode,'producer':str(producer),'prefix':str(prefix),'consumer':'copied public Graph Vulkan resident test, no private HYLE APIs','stages':records},indent=2)+'\n',encoding='utf-8');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2400));print(f.read(2400).decode('utf-8',errors='replace'))
  raise SystemExit(r.returncode)
if mode=='static' and not done('configure'):
 run('configure',['cmake','-S',str(repo),'-B',str(producer),'-DHYLE_STATIC=ON','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=vulkan','-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1','-DVulkan_INCLUDE_DIR=C:/public/tools/hyle-vulkan/1.4.357.0/include','-DVulkan_LIBRARY=C:/public/tools/hyle-vulkan/1.4.357.0/Lib/vulkan-1.lib','-DVulkan_GLSLC_EXECUTABLE=C:/public/tools/hyle-vulkan/1.4.357.0/Bin/glslc.exe','-DSPIRV-Headers_DIR=C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake/SPIRV-Headers'])
if not done('producer-build'):run('producer-build',['cmake','--build',str(producer),'--target','hyle_graph_route_vulkan','hyle_graph_batch','--parallel','4'])
if not done('install'):
 assert not prefix.exists(),'relocated prefix must not be overwritten'
 if stage.exists():
  assert any(x['stage']=='install' and x['exit_code']!=0 for x in records)
  run('remaining-export-build',['cmake','--build',str(producer),'--target','hyle_compute_state','--parallel','4'])
 run('install',['cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():
 assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists(),'actual prefix relocation required'
inputs=['tests/graph_route_vulkan/mature_tensor_test.cc','tests/compute_route_vulkan/concat_test_support.h','tests/compute_route_vulkan/gate_norm_test_support.h','tests/compute_route_vulkan/reduction_test_support.h','tests/compute_route_vulkan/tensor_test_support.h','tests/compute_route_vulkan/fixture.h','tests/compute_provider_native/half_test_support.h']
manifest=[]
for name in inputs:
 blob=subprocess.check_output(['git','show',candidate+':'+name]);target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blob);manifest.append({'path':name,'sha256':hashlib.sha256(blob).hexdigest()})
carrier=subprocess.check_output(['git','show',candidate+':include/hyle/simd/types.h'])
(source/'tests/compute_provider_native/oracle_storage.h').write_bytes(carrier)
helper=source/'tests/compute_provider_native/half_test_support.h'
helper.write_bytes(helper.read_bytes().replace(b'#include "hyle/simd/dtype.h"',b'#include "oracle_storage.h"'))
manifest.append({'path':'tests/compute_provider_native/oracle_storage.h','source':'candidate include/hyle/simd/types.h, copied test-only bit carriers','sha256':hashlib.sha256(carrier).hexdigest()})
manifest.append({'path':'tests/compute_provider_native/half_test_support.h','adaptation':'test-only carrier include; independent numerical encoder/decoder unchanged','actual_sha256':hashlib.sha256(helper.read_bytes()).hexdigest()})
(out/(mode+'-sdk-consumer-inputs.json')).write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g01_installed_resident LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph compute)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 gtest EXCLUDE_FROM_ALL)
add_executable(resident tests/graph_route_vulkan/mature_tensor_test.cc)
target_compile_features(resident PRIVATE cxx_std_23)
target_compile_options(resident PRIVATE /W4 /WX /wd4324 /utf-8)
target_link_libraries(resident PRIVATE hyle::graph GTest::gtest_main)
hyle_stage_runtime(resident)
''',encoding='utf-8')
if not done('consumer-configure'):run('consumer-configure',['cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_CXX_COMPILER=C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe','-DCMAKE_CXX_FLAGS=/DWIN32 /D_WINDOWS /GR /EHsc','-DCMAKE_CXX_FLAGS_RELEASE=/O2 /Ob2 /DNDEBUG'])
if not done('consumer-build'):run('consumer-build',['cmake','--build',str(build),'--target','resident','--parallel','4'])
if not done('run'):run('run',[str(build/'resident.exe'),'--gtest_filter=VulkanGraph.ResidentAttentionViewsPreserveEffectiveLengthsAndOldResults'])
print(mode+' relocated installed public resident SDK PASS',flush=True)
