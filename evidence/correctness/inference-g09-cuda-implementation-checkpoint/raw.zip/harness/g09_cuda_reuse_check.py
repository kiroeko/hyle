from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,time

root=Path(__file__).resolve().parents[2]
out=root/'.scratch/inference-gaps/g09-cuda-implementation-check-1'
prior=json.loads((out/'result.json').read_text(encoding='utf8'))
assert prior['stages'][-1]['stage']=='manifest'
prior['state']='PREFLIGHT_REFUSED_UNNECESSARY_LEAF_REBUILD'
prior['reason']='199 preview edges include missing CUDA object dependencies, despite qualified unchanged static leaf archives. No native compilation was launched.'
if not (out/'result-preflight.json').exists():
    (out/'result-preflight.json').write_text(json.dumps(prior,indent=2)+'\n',encoding='utf8')
build=Path('C:/h7/w-cpu-cuda/selected-graph/source-build')
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env.update(VSLANG='1033',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
env['PATH']='C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/extras/CUPTI/lib64;'+env.get('PATH','')
r={'state':'SETUP','stages':[],'pid':os.getpid(),'head':prior['head'],'retained_preflight_seconds':prior['elapsed_seconds'],
   'scope':'Partial CXX owner compilation and real CUDA public consumer execution, reusing qualified unchanged G08 leaf archives from the exact prior source-integration tree. Scratch Ninja projection only; not a new source/static/shared delivery gate or P1.',
   'max_jobs':2,'logical_cpu_limit':4,'priority':'BELOW_NORMAL','input_hashes':prior['input_hashes'],'borrowed_archives':[]}
source=(build/'build.ninja').read_text(encoding='utf8');lines=[]
keep=('hyle/src/graph/hyle_graph.lib','hyle/src/graph_route_cpu_cuda/hyle_graph_route_cpu_cuda.lib')
for line in source.splitlines(keepends=True):
    match=re.match(r'^build ([^:]+): (?:CXX|CUDA)_STATIC_LIBRARY_LINKER',line)
    if match and match[1].replace('\\','/') not in keep:
        output=match[1];path=build/output.replace('\\','/')
        if not path.is_file():
            lines.append(line)
            continue
        r['borrowed_archives'].append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})
        line=f'build {output}: phony\n'
        # Rule-local variables following a phony edge are harmless and unused.
    lines.append(line)
preview=out/'unchanged-leaf-reuse.ninja';preview.write_text(''.join(lines),encoding='utf8')
started=time.monotonic()
def save():
    r['elapsed_seconds']=r['retained_preflight_seconds']+time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
def run(stage,args,timeout=1800):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('wb') as stream:
        job=subprocess.Popen([str(a) for a in args],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        kernel=ctypes.windll.kernel32
        kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(job._handle))
        if not kernel.GetProcessAffinityMask(handle,ctypes.byref(available),ctypes.byref(system)):raise OSError('read affinity')
        mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4])
        if not kernel.SetProcessAffinityMask(handle,mask):raise OSError('set affinity')
        r.update(state='RUNNING',stage=stage,child_pid=job.pid);save();print(stage,job.pid,flush=True)
        try:code=job.wait(timeout=timeout)
        except subprocess.TimeoutExpired:job.kill();job.wait();code=124
    r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp})
    r.pop('child_pid',None);save()
    if code:
        r['state']='FAIL';save();print(log.read_text(encoding='utf8',errors='replace')[-10000:],flush=True);raise SystemExit(code)
targets=['hyle_graph_test','hyle_cpu_cuda_pipeline','hyle_cpu_cuda_contracts','joint']
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace')
(out/'dry-run-reuse.log').write_text(dry,encoding='utf8')
r['dry_run_edges']=len(dry.splitlines());r['cuda_edges']=[s for s in dry.splitlines() if 'Building CUDA object' in s];save()
assert not r['cuda_edges'] and len(dry.splitlines())<50 and 'Re-running CMake' not in dry,dry
run('build-reuse',['ninja','-C',build,'-f',preview,'-j','2',*targets])
def binary(target):
    p=build/(target+'.exe')
    if not p.exists():p=build/'bin'/(target+'.exe')
    assert p.is_file(),p
    return p
run('common',[binary('hyle_graph_test'),'--gtest_output=json:'+str(out/'gtest.json')],600)
run('contracts',[binary('hyle_cpu_cuda_contracts')],600)
run('g08-joint-regression',[binary('joint')],600)
run('pipeline-correctness',[binary('hyle_cpu_cuda_pipeline')],600)
run('pipeline-real-kernel-trace',[binary('hyle_cpu_cuda_pipeline'),'--trace'],600)
for item in r['input_hashes']:
    if item['path'].startswith(('src/graph_route_cpu_apple/','src/graph_route_cpu_vulkan/')):continue
    assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item
for item in r['borrowed_archives']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['state']='PARTIAL_CUDA_IMPLEMENTATION_CHECK_PASS'
r['binaries']=[{'target':t,'path':str(binary(t)),'sha256':hashlib.sha256(binary(t).read_bytes()).hexdigest()} for t in targets]
save();print(json.dumps({k:r[k] for k in ['state','elapsed_seconds','stages','dry_run_edges']}),flush=True)
