from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time,sys

root=Path(__file__).resolve().parents[2]
out=root/'.scratch/inference-gaps/g09-cuda-implementation-check-1'
out.mkdir(exist_ok=False)
build=Path('C:/h7/w-cpu-cuda/selected-graph/source-build')
parent=Path('C:/h7/w-cpu-cuda/selected-graph/source-parent')
cmake=parent/'CMakeLists.txt'
(out/'original-parent-CMakeLists.txt').write_bytes(cmake.read_bytes())
text=cmake.read_text(encoding='utf8')
assert 'add_executable(hyle_cpu_cuda_pipeline' not in text
text+='\n# G09 public joint consumer; reuse all qualified dependencies.\n'
for target,source in [('hyle_cpu_cuda_pipeline','cpu_cuda_pipeline.cc'),('hyle_cpu_cuda_contracts','cpu_cuda_contracts.cc')]:
    text+=f'add_executable({target} "{(root/"tests/graph"/source).as_posix()}")\n'
    text+=f'target_compile_features({target} PRIVATE cxx_std_23)\n'
    text+=f'target_link_libraries({target} PRIVATE hyle::graph)\n'
    text+=f'hyle_stage_runtime({target})\n'
text+='find_package(CUDAToolkit REQUIRED)\nif(TARGET CUDA::cupti)\n'
text+='target_compile_definitions(hyle_cpu_cuda_pipeline PRIVATE HYLE_G09_HAS_CUPTI=1)\n'
text+='target_link_libraries(hyle_cpu_cuda_pipeline PRIVATE CUDA::cupti)\nendif()\n'
cmake.write_text(text,encoding='utf8')
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env.update(VSLANG='1033',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
env['PATH']='C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/extras/CUPTI/lib64;'+env.get('PATH','')
r={'state':'SETUP','stages':[],'pid':os.getpid(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
   'scope':'G09 concentrated common and real CUDA joint implementation check. Not final candidate, P1, aggregate delivery or sanitizer acceptance.',
   'max_jobs':2,'priority':'BELOW_NORMAL','logical_cpu_limit':4,'prior_common_evidence':'evidence/architecture/inference-g09-partial-common-check/receipt.json'}
paths=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
r['input_hashes']=[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths if (root/p).is_file()]
started=time.monotonic()
def save():
    r['elapsed_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
def run(stage,args,timeout=1800):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('wb') as stream:
        job=subprocess.Popen([str(a) for a in args],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        kernel=ctypes.windll.kernel32
        kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(job._handle))
        if not kernel.GetProcessAffinityMask(handle,ctypes.byref(available),ctypes.byref(system)):raise OSError('read affinity')
        mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4])
        if not kernel.SetProcessAffinityMask(handle,mask):raise OSError('set affinity')
        r.update(state='RUNNING',stage=stage,child_pid=job.pid);save();print(stage,job.pid,flush=True)
        try:code=job.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            job.kill();job.wait();code=124
    r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp})
    r.pop('child_pid',None);save()
    if code:
        r['state']='FAIL';save();print(log.read_text(encoding='utf8',errors='replace')[-10000:],flush=True);raise SystemExit(code)
run('manifest',['ninja','-C',build,'build.ninja'])
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
targets=['hyle_graph_test','hyle_cpu_cuda_pipeline','hyle_cpu_cuda_contracts','joint']
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace')
(out/'dry-run.log').write_text(dry,encoding='utf8')
r['dry_run_edges']=len(dry.splitlines());r['cuda_edges']=[s for s in dry.splitlines() if 'Building CUDA object' in s];save()
assert not r['cuda_edges'] and len(dry.splitlines())<100 and 'Re-running CMake' not in dry,dry
run('build',['ninja','-C',build,'-f',preview,'-j','2',*targets])
def binary(target):
    p=build/(target+'.exe')
    if not p.exists():p=build/'bin'/(target+'.exe')
    assert p.is_file(),p
    return p
run('common',[binary('hyle_graph_test'),'--gtest_output=json:'+str(out/'gtest.json')],600)
run('contracts',[binary('hyle_cpu_cuda_contracts')],600)
run('g08-joint-regression',[binary('joint')],600)
run('pipeline-correctness',[binary('hyle_cpu_cuda_pipeline')],600)
run('pipeline-real-kernel-trace',[binary('hyle_cpu_cuda_pipeline'),'--trace'],600)
for item in r['input_hashes']:
    p=root/item['path']
    if item['path'].startswith(('src/graph_route_cpu_apple/','src/graph_route_cpu_vulkan/')):continue
    assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item
r['state']='CUDA_IMPLEMENTATION_CHECK_PASS'
r['binaries']=[{'target':t,'path':str(binary(t)),'sha256':hashlib.sha256(binary(t).read_bytes()).hexdigest()} for t in targets]
save();print(json.dumps(r),flush=True)
