from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile

canonical=Path('/mnt/c/public/project-hyle/hyle');base=Path('/root/hyle-scratch/compute-unified');source=base/'source-7a7b4c3b'
out=canonical/'.scratch/inference-gaps/g03/graph-late-cuda-sdk';out.mkdir(exist_ok=True)
assert source.is_dir() and not (source/'.git').exists()
with zipfile.ZipFile(sys.argv[1]) as archive:
    inputs=json.loads(archive.read('source-manifest.json'))
    for item in inputs:
        relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
        data=archive.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        target=source/relative
        if not target.exists() or target.read_bytes()!=data:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
digest=hashlib.sha256(json.dumps(inputs,sort_keys=True).encode()).hexdigest()
identity={key:subprocess.check_output(args,text=True).strip() for key,args in [
    ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
    ('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu','--format=csv,noheader'])]}
rows=json.loads((out/'result.json').read_bytes())['stages'] if (out/'result.json').exists() else []
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
def run(mode,stage,args):
    attempt=1+sum(r['mode']==mode and r['stage']==stage for r in rows);log=out/f'{mode}-{stage}-{attempt}.log';start=time.monotonic()
    with log.open('w') as handle:
        process=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
        (out/'job.json').write_text(json.dumps(dict(state='RUNNING',mode=mode,stage=stage,pid=process.pid,log=str(log))))
        print('RUN',mode,stage,process.pid,flush=True);code=process.wait()
    row=dict(mode=mode,stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,input_manifest_sha256=digest,log=str(log));rows.append(row)
    (out/'result.json').write_text(json.dumps(dict(scope='G03 original full CPU+CUDA factor qualification and installed public pure/joint Graph64; original required ggml CUDA recompilation permitted by finite card exception, no algorithm/vendor/build-tool change',identity=identity,inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
    (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)))
    print(json.dumps(row),flush=True)
    if code:print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
def done(mode,stage):return any(r['mode']==mode and r['stage']==stage and r['input_manifest_sha256']==digest and r['exit_code']==0 for r in rows)
for mode in ['static','shared']:
    if len(sys.argv)>2 and sys.argv[2]!='all' and sys.argv[2]!=mode:continue
    producer=base/f'l-cpu-cuda/selected-graph/{mode}-sdk-build';assert producer.is_dir()
    folder=base/f'g03-graph-late-{mode}-{digest[:12]}';folder.mkdir(exist_ok=True);parent=folder/'consumer';parent.mkdir(exist_ok=True);build=folder/'build';staging=folder/'staging';prefix=folder/'relocated'
    if not done(mode,'producer-configure'):run(mode,'producer-configure',['cmake','-S',str(source),'-B',str(producer)])
    commands=json.loads(subprocess.check_output(['ninja','-C',str(producer),'-t','compdb'],env=env,text=True))
    selected=[c for c in commands if c['file'].endswith(('src/compute_backend_cuda/cuda_backend.cc','src/graph_route_cpu_cuda/compile.cc','src/graph_route_cpu_cuda/invocation.cc','src/graph/leased_invocation.cc','src/graph_batch/batch.cc'))]
    assert len(selected)==5 and all('HYLE_TESTING' not in c['command'] for c in selected)
    (out/f'{mode}-shipping-commands.json').write_text(json.dumps(selected,indent=2)+'\n')
    targets=['hyle_graph','hyle_graph_batch','hyle_graph_route_cpu_cuda','hyle_compute_batch','hyle_compute_provider_flashinfer']
    if not done(mode,'producer-build'):run(mode,'producer-build',['cmake','--build',str(producer),'--target',*targets,'--parallel','4'])
    if not prefix.exists():
        run(mode,'install',['cmake','--install',str(producer),'--prefix',str(staging)]);staging.rename(prefix)
    assert not staging.exists()
    headers=['graph/batch.h','graph/cpu_cuda.h','compute/detail/copy_outcome_source.h','compute/backends/cuda.h']
    for i,name in enumerate(headers):
        assert (prefix/'include/hyle'/name).read_bytes()==(source/'include/hyle'/name).read_bytes(),name
        (parent/f'header-{i}.cc').write_text(f'#include <hyle/{name}>\n')
    (parent/'main.cc').write_bytes((source/'tests/compute_batch/pending_paged_receiver_cpu_consumer.cc').read_bytes())
    body='''cmake_minimum_required(VERSION 3.25)
project(g03_graph_late_cuda_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph)
add_executable(cuda main.cc)
add_executable(joint main.cc)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc header-3.cc)
target_compile_definitions(joint PRIVATE HYLE_PENDING_GRAPH_CPU_CUDA=1)
foreach(t cuda joint)
 target_compile_definitions(${t} PRIVATE HYLE_PENDING_GRAPH_RECEIVER=1 HYLE_PENDING_GRAPH_CUDA=1)
endforeach()
foreach(t cuda joint headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${t} PRIVATE hyle::graph)
endforeach()
hyle_stage_runtime(cuda)
hyle_stage_runtime(joint)
'''
    cmake=parent/'CMakeLists.txt'
    if not cmake.exists() or cmake.read_text()!=body:cmake.write_text(body)
    for stage,args in [
        ('configure',['cmake','-S',str(parent),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']),
        ('consumer-build',['cmake','--build',str(build),'--target','cuda','joint','headers','--parallel','4'])]:
        if not done(mode,stage):run(mode,stage,args)
    commands=json.loads((build/'compile_commands.json').read_bytes());assert len(commands)==6
    assert all(str(source) not in c['command'] and str(producer) not in c['command'] and str(prefix/'include') in c['command'] for c in commands)
    (out/f'{mode}-public-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    for name in ['cuda','joint']:
        if not done(mode,name):run(mode,name,[str(build/name)])
    libraries=[p for p in (prefix/'lib').rglob('*') if p.is_file() and p.name.startswith('libhyle') and p.suffix in ['.a','.so']]
    assert libraries
    (out/f'{mode}-artifacts.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in libraries],indent=2)+'\n')
print('Selected CUDA SDK profiles terminal; inspect matrix before acceptance',flush=True)
