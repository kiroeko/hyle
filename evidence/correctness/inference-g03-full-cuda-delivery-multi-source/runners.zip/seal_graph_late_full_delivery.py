from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
task = root / '.scratch/inference-gaps/g03'
out = root / 'evidence/correctness/inference-g03-full-cuda-delivery-multi-source'
assert not out.exists(), 'Do not overwrite a sealed checkpoint'

def read(folder):
    path = task / folder
    assert json.loads((path / 'job.json').read_bytes())['state'] == 'TERMINAL'
    data = json.loads((path / 'result.json').read_bytes())
    return path, data

def log(folder, row):
    return (folder / Path(row['log']).name).read_text(encoding='utf-8')

sdk_path, sdk = read('graph-late-cuda-sdk')
latest = {(r['mode'], r['stage']): r for r in sdk['stages']}
for mode in ('static', 'shared'):
    for stage in ('producer-configure', 'producer-build', 'install', 'configure', 'consumer-build', 'cuda', 'joint'):
        assert latest[mode, stage]['exit_code'] == 0
    for stage in ('cuda', 'joint'):
        assert log(sdk_path, latest[mode, stage]).count('Graph pending PASS:64') == 2
    public = json.loads((sdk_path / f'{mode}-public-commands.json').read_bytes())
    assert len(public) == 6
    assert all('/relocated/include' in r['command'] and '/source-7a7b4c3b/' not in r['command'] and '/selected-graph/' not in r['command'] for r in public)
    shipping = json.loads((sdk_path / f'{mode}-shipping-commands.json').read_bytes())
    assert len(shipping) == 5 and all('HYLE_TESTING' not in r['command'] for r in shipping)
for item in sdk['inputs']:
    if item['path'].startswith(('src/', 'include/')) or item['path'] == 'tests/compute_batch/pending_paged_receiver_cpu_consumer.cc':
        assert hashlib.sha256((root / item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']

air_path, air = read('graph-late-air')
san_path, san = read('graph-late-sanitizers')
al = {(r['route'], r['stage']): r for r in air['stages']}
sl = {(r['route'], r['mode'], r['stage']): r for r in san['stages']}
for route in ('apple', 'vulkan'):
    row = al[route, 'g03_multi_native_sources']
    assert row['exit_code'] == 0
    assert log(air_path, row).count('two independent accepted native producer owners') == 3
    row = al[route, 'g03_native_result_risks']
    assert row['exit_code'] == 0 and 'readonly alias rejects destination writes' in log(air_path, row)
    for mode in ('asan', 'ubsan', 'tsan'):
        row = sl[route, mode, 'g03_gl_multi_sources']
        assert row['exit_code'] == 0
        assert log(san_path, row).count('two independent accepted native producer owners') == 3
        row = sl[route, mode, 'g03_gl_source_risks']
        assert row['exit_code'] == 0 and 'readonly alias rejects destination writes' in log(san_path, row)

out.mkdir()
changed = [p for p in subprocess.check_output(['git', 'diff', '--name-only', '2bc71f56a'], text=True).splitlines() if p.startswith(('include/', 'src/', 'tests/'))]
for folder in ('graph-late-cuda-sdk', 'graph-late-air', 'graph-late-sanitizers'):
    with zipfile.ZipFile(out / (folder + '-raw.zip'), 'w', zipfile.ZIP_DEFLATED) as package:
        for p in (task / folder).iterdir():
            if p.suffix in ('.json', '.log'):
                package.write(p, p.name)
        archives = sorted((task / folder).glob('source-*.zip'), key=lambda p: int(p.stem.split('-')[-1]))
        with zipfile.ZipFile(archives[-1]) as snapshot:
            paths = set(snapshot.namelist())
            for name in changed:
                if name in paths:
                    package.writestr('last-canonical-input/' + name, snapshot.read(name))
with zipfile.ZipFile(out / 'runners.zip', 'w', zipfile.ZIP_DEFLATED) as package:
    for name in ('graph_late_sdk_cuda.py', 'run_graph_late_sdk_cuda.py', 'graph_late_air.py', 'run_graph_late_air.py', 'graph_late_san_air.py', 'run_graph_late_san_air.py', 'seal_graph_late_full_delivery.py'):
        package.write(task / name, name)
result = dict(
    kind='PARTIAL_FULL_CUDA_INSTALLED_DELIVERY_AND_INDEPENDENT_NATIVE_SOURCES',
    state='AUDITED', whole_g03_completed=False,
    verified=[
        'Original full CPU+CUDA dependency closure builds, installs and relocates in static and shared profiles; no frozen CPU archive or explicit compiler translation unit workaround.',
        'Both installed profiles run CUDA and required CPU+CUDA public Graph/F2 pending consumers: 64 steps F16/BF16, two requests/two slots, cross-page growth, independent double oracle. Four standalone public headers per profile.',
        'Installed consumer commands have no source or producer build includes; five shipping object receipts per profile have no HYLE_TESTING.',
        'Two independently accepted native Abs result owners enter the same original F2 Update and two joint page nodes with required CPU fragments; actual nonzero success oracle, second producer cancellation failure and abandonment pass on Apple/Vulkan.',
        'Native readonly result used as destination is rejected before copy acceptance, retaining the accepted producer owner; both source routes and six ASan/UBSan/TSan configurations pass.',
        'Independent two-producer source lifecycle fixture passes on all six original host sanitizer profiles.'
    ],
    limitations=[
        'This is a partial checkpoint; required CPU+CUDA source lifecycle qualification is separately running, not signed here.',
        'No immutable G03 candidate or final seven-gate verdict; original G01/G02 unresolved gates and G04-G10 remain.',
        'Original sanitizer model/private-driver limitations, native CUDA Unimplemented cancellation, cold table waits and bounded per-binding allocations remain explicit.'
    ],
    failures='All original compile/runtime failures and cumulative records retained. New multi-source fixture compile warning, incorrect output read length and pre-recovery Vulkan status expectations were corrected without product weakening. Original source ownership must be recovered before failed epoch admission is judged.',
    cumulative_seconds=dict(cuda_sdk=sdk['cumulative_seconds'],native_source=air['cumulative_seconds'],host_sanitizers=san['cumulative_seconds']),
    current_product_inputs=[dict(path=p, sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in changed if p.startswith(('include/', 'src/'))]
)
(out / 'validation-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(result['cumulative_seconds']))
