from pathlib import Path
import hashlib,json,os,subprocess,sys,time
mode=sys.argv[1];assert mode in ['static','shared']
root=Path('/mnt/c/public/project-hyle/hyle');base=Path('/root/hyle-scratch/compute-unified');logs=root/('.scratch/inference-gaps/g07-graph-consumer-c1-'+mode);work=base/('g07-graph-consumer-c1-'+mode)
job=json.loads((base/'g07-p1-cuda/qualification-job-3.json').read_text());assert job['state']=='TERMINAL','No heavy build/test while fixed CUDA P1 is live.'
resume='--resume-after-compile-fix' in sys.argv
if not resume:logs.mkdir(exist_ok=False);work.mkdir(exist_ok=False)
prefix=base/('g07-sdk/cuda-'+mode+'-c1/relocated');sdk=json.loads((root/('.scratch/inference-gaps/g07-sdk/cuda-'+mode+'-c1/result.json')).read_text());assert sdk['state']=='RELOCATED_SDK_PUBLIC_CONSUMERS_AND_HEADERS_PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for artifact in sdk['owner_artifacts']:assert sha(Path(artifact['path']))==artifact['sha256']
source=work/'consumer.cc';original=root/'tests/graph_route_cuda/packed_resident_consumer.cc';source.write_bytes(original.read_bytes())
if not resume:(logs/'consumer.cc').write_bytes(original.read_bytes())
cmake='''cmake_minimum_required(VERSION 3.25)
project(g07_graph_packed LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
add_executable(g07_graph_packed consumer.cc)
target_compile_features(g07_graph_packed PRIVATE cxx_std_23)
target_compile_options(g07_graph_packed PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_link_libraries(g07_graph_packed PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime(g07_graph_packed)
'''
(work/'CMakeLists.txt').write_text(cmake);(logs/'CMakeLists.txt').write_text(cmake)
env=dict(os.environ);env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
prior=None
if resume:
 prior=json.loads((logs/'result.json').read_text());assert prior['state']=='FAIL' and prior['stage']=='build'
 archive=logs/'compile-failure-1';archive.mkdir(exist_ok=False)
 for name in ['result.json','configure.log','build.log','consumer.cc']:
  (logs/name).rename(archive/name)
 (logs/'consumer.cc').write_bytes(original.read_bytes())
r=dict(state='SETUP',mode=mode,pid=os.getpid(),candidate='4274ee6cb6275bf36bda1d8c8c0e223f0fa65db5',test_snapshot=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),source=dict(path=original.relative_to(root).as_posix(),sha256=sha(original)),sdk_result_sha256=sha(root/('.scratch/inference-gaps/g07-sdk/cuda-'+mode+'-c1/result.json')),owner_artifacts=sdk['owner_artifacts'],stages=[],scope='Only missing public Graph65step M1/M17/M64, shared original packed backing, two slots, changed weights/A, actual TopK device-produced IDs, repeats/reorder, invalid IDs, failed publication and old caller-owned outputs after graph teardown. Product/API/P1 contract unchanged. Host risk facets reused from exact C1; new static consumer additionally device memcheck/racecheck.')
if prior:r['prior_compile_failure']=prior;r['resume_reason']='Only consumer View::reshape argument uses explicit public TensorShape::create. Same immutable SDK/prefix/build tree; old failure and elapsed retained, no product or P1 repeat.'
started=time.monotonic()-(prior['elapsed_seconds'] if prior else 0)
def save():
 r['elapsed_seconds']=time.monotonic()-started;(logs/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
 stamp=time.monotonic()
 with (logs/(stage+'.log')).open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(mode,stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp));r.pop('child_pid',None);save()
 if code:
  r['state']='FAIL';save();print((logs/(stage+'.log')).read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
if not resume:run('configure',['cmake','-S',str(work),'-B',str(work/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
run('build',['cmake','--build',str(work/'build'),'--parallel','2'])
commands=json.loads((work/'build/compile_commands.json').read_text());assert len(commands)==1 and str(prefix/'include') in commands[0]['command'] and str(root) not in commands[0]['command'] and str(base/'source-7a7b4c3b') not in commands[0]['command']
(logs/'compile_commands.json').write_text(json.dumps(commands,indent=2))
binary=work/'build/g07_graph_packed';run('consumer',[str(binary)])
ldd=subprocess.check_output(['ldd',str(binary)],env=env,text=True);assert 'not found' not in ldd;(logs/'ldd.log').write_text(ldd)
if mode=='static':
 for tool in ['memcheck','racecheck']:run(tool,['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool',tool,'--error-exitcode','86',str(binary)])
r.update(state='PUBLIC_GRAPH_PACKED_65STEP_3SHAPES_PASS',artifact=dict(path=str(binary),sha256=sha(binary)));save();print(mode,r['state'],flush=True)
