from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
air=sys.platform=='darwin';route='apple' if air else 'cuda';mode=sys.argv[1];assert mode in ['source','static','shared'] and (air or mode=='source')
base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified';canonical=Path('/mnt/c/public/project-hyle/hyle')
packet=base/'g07-graph-input.zip' if air else canonical/'.scratch/inference-gaps/g07-graph-input.zip'
logs=(base if air else canonical/'.scratch/inference-gaps')/('g07-graph-extra-'+route+'-'+mode)
previous=None
if '--resume-after-config-fix' in sys.argv:
 previous=json.loads((logs/'result.json').read_text());assert previous['state']=='FAIL' and previous['stage']=='configure'
 archive=logs/'configuration-failure-1';archive.mkdir(exist_ok=False)
 for name in ['result.json','configure.log']:(archive/name).write_bytes((logs/name).read_bytes())
else:logs.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ);env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
cmake='/opt/homebrew/bin/cmake' if air else 'cmake';ninja='/opt/homebrew/bin/ninja' if air else 'ninja';start=time.monotonic()
r=dict(state='SETUP',route=route,mode=mode,pid=os.getpid(),stages=[])
if previous:r['previous_attempt']=previous;r['resume_reason']='Explicit HYLE_INSTALL=OFF for source test configuration; same source/build/config except install packaging switch. Original configure failure/cost retained.'
def save():
 r['elapsed_seconds']=time.monotonic()-start;r['cumulative_elapsed_seconds']=r['elapsed_seconds']+(previous['elapsed_seconds'] if previous else 0);(logs/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd,extra=None):
 stamp=time.monotonic()
 with (logs/(stage+'.log')).open('w') as stream:
  p=subprocess.Popen(cmd,env=env if extra is None else dict(env,**extra),stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(route,mode,stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,extra_environment=extra));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print((logs/(stage+'.log')).read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
if air:
 r['machine']={key:subprocess.check_output(cmd,env=env,text=True).strip() for key,cmd in [('model',['/usr/sbin/sysctl','-n','hw.model']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]};assert r['machine']['model']=='Mac16,12'
with zipfile.ZipFile(packet) as z:
 identity=json.loads(z.read('identity.json'));r['input']=identity
 for item in identity['files']:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
 if mode=='source':
  source=base/('source-c8874688' if air else 'source-7a7b4c3b');assert not (source/'.git').exists()
  for item in identity['products'][route]:assert sha(source/item['path'])==item['sha256']
  for item in identity['files']:
   if item['path'].startswith('tests/graph_route_'+route+'/'):(source/item['path']).write_bytes(z.read(item['path']))
  build=base/('a' if air else 'l')/('cpu-'+route) # overwritten by the actual retained producer below
  build=base/(('a' if air else 'l')+'-cpu-'+route)/'selected-graph/shared-sdk-build'
  run('configure',[cmake,'-S',str(source),'-B',str(build),'-DHYLE_INSTALL=OFF','-DHYLE_BUILD_TESTS=ON','-DHYLE_TEST_INSTRUMENTATION=OFF'])
  run('manifest',[ninja,'-C',str(build),'build.ninja'])
  preview=logs/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
  if not air:
   helper=canonical/'.scratch/inference-gaps/g04-g05/ce28_shipping_native_reuse_wsl.py';label='g07-graph-source'
   run('native-reuse',['python3',str(helper),'shared',label]);folder=helper.parent/('ce28-shared-native-reuse-'+label)
   proof=json.loads((folder/'result.json').read_text());assert proof['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK';r['native_reuse']=proof;preview=folder/'reuse.ninja'
  target='hyle_graph_route_'+route+'_packed_consumer_test'
  dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n',target],env=env,text=True);(logs/'dry-run.log').write_text(dry)
  assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry,dry[-4000:]
  run('build',[ninja,'-C',str(build),'-f',str(preview),'-j','4' if air else '2',target])
  binaries=[p/target for p in [build,build/'bin',build/'hyle',build/'hyle/bin'] if (p/target).is_file()];assert len(binaries)==1;binary=binaries[0]
 else:
  prefix=base/('g07-sdk/apple-'+mode+'-d2/relocated');sdk=json.loads((base/('g07-sdk-evidence/apple-'+mode+'-d2/result.json')).read_text());assert sdk['state']=='RELOCATED_SDK_PUBLIC_CONSUMERS_AND_HEADERS_PASS'
  for item in sdk['owner_artifacts']:assert sha(Path(item['path']))==item['sha256']
  r['sdk_owner_artifacts']=sdk['owner_artifacts'];work=base/('g07-graph-apple-'+mode);work.mkdir(exist_ok=False);(work/'consumer.cc').write_bytes(z.read('tests/graph_route_apple/packed_resident_consumer.cc'))
  body='cmake_minimum_required(VERSION 3.25)\nproject(g07_graph_packed LANGUAGES CXX)\nfind_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\nadd_executable(consumer consumer.cc)\ntarget_compile_features(consumer PRIVATE cxx_std_23)\ntarget_compile_options(consumer PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(consumer PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime(consumer)\n'
  (work/'CMakeLists.txt').write_text(body);(logs/'CMakeLists.txt').write_text(body);build=work/'build'
  run('configure',[cmake,'-S',str(work),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
  run('build',[cmake,'--build',str(build),'--parallel','4']);binary=build/'consumer'
  commands=json.loads((build/'compile_commands.json').read_text());assert len(commands)==1 and str(prefix/'include') in commands[0]['command'] and str(base/'source-c8874688') not in commands[0]['command'];(logs/'compile_commands.json').write_text(json.dumps(commands,indent=2))
run('consumer',[str(binary)])
if air and mode=='static':run('metal-validation',[str(binary)],dict(MTL_DEBUG_LAYER='1',MTL_SHADER_VALIDATION='1'))
r.update(state='GRAPH_PUBLIC_CONSUMER_PASS',artifact=dict(path=str(binary),sha256=sha(binary)));save();print(route,mode,r['state'],flush=True)
