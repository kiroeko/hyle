from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[2];base=root/'.scratch/inference-gaps'
out=root/'evidence/correctness/inference-g07-packed-graph-consumers';out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['g07-graph-extra-cuda-source','g07-graph-consumer-c1-static','g07-graph-consumer-c1-shared']+['g07-graph-extra-apple-'+m for m in ['source','static','shared']]
rows=[]
for name in names:
 d=base/name;r=json.loads((d/'result.json').read_text())
 assert r['state'] in ['GRAPH_PUBLIC_CONSUMER_PASS','PUBLIC_GRAPH_PACKED_65STEP_3SHAPES_PASS']
 assert all(stage['exit_code']==0 for stage in r['stages'])
 text=(d/'consumer.log').read_text()
 for m in [1,17,64]:assert f'M={m}:65 steps/' in text
 route='apple' if 'apple' in name else 'cuda';source='tests/graph_route_'+route+'/packed_resident_consumer.cc'
 if 'input' in r:assert next(x['sha256'] for x in r['input']['files'] if x['path']==source)==sha(root/source)
 else:assert r['source']['sha256']==sha(root/source)
 rows.append(dict(id=name,route=route,verdict='PASS',result_sha256=sha(d/'result.json'),consumer_source=dict(path=source,sha256=sha(root/source)),elapsed_seconds=r.get('cumulative_elapsed_seconds',r['elapsed_seconds']),artifact=r['artifact']))
assert 'ERROR SUMMARY: 0 errors' in (base/names[1]/'memcheck.log').read_text()
assert '0 hazards displayed (0 errors, 0 warnings)' in (base/names[1]/'racecheck.log').read_text()
metal=(base/'g07-graph-extra-apple-static/metal-validation.log').read_text()
assert 'Metal API Validation Enabled' in metal and 'Metal GPU Validation Enabled' in metal
for m in [1,17,64]:assert f'M={m}:65 steps/' in metal
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name in names:
  for p in sorted((base/name).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(base).as_posix())
 for name in ['g07_graph_extra.py','g07_graph_consumer.py','g07-graph-input.zip','g07_seal_graph.py']:z.write(base/name,name)
 for route in ['cuda','apple']:
  for suffix in ['CMakeLists.txt','packed_resident_consumer.cc']:
   p=root/('tests/graph_route_'+route)/suffix;z.write(p,p.relative_to(root).as_posix())
r=dict(schema='hyle.inference-g07-packed-graph-consumers/v1',state='PASS_SOURCE_STATIC_SHARED_65STEP_BOTH_ROUTES_AND_DEVICE_FACETS',candidates=dict(cuda='4274ee6cb6275bf36bda1d8c8c0e223f0fa65db5',apple='91ae8e67faa028061d8f5e8e216310c827e024a3'),test_snapshot=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),rows=rows,normal_consumer_runs=6,shapes_per_run=[1,17,64],replays_per_shape=65,device_facets=dict(cuda_memcheck='PASS_0_ERRORS',cuda_racecheck='PASS_0_HAZARDS_ERRORS_WARNINGS',apple_metal='PASS_ACTUAL_API_AND_GPU_VALIDATION'),raw_archive=dict(path='raw.zip',sha256=sha(out/'raw.zip')),scope='Independent final-review evidence supplement only. CUDA affine4/group64 K128/N9 linear and grouped, real device TopK IDs, repeat/reorder/invalid/failure, shared backing, two queues/slots and old caller output after teardown. Apple block128 FP8 K256/N19, two slots, changed codes/scales and ordered-scale oracle, retained native array after Program/Context close. All M1/17/64 and65steps. Full real-role N/K fixtures and full-shape P1 are separate evidence, not these small orthogonal shapes.',retained_failures=['CUDA installed static consumer initial View::reshape array compile failure, corrected using explicit public TensorShape::create in same build/prefix; original source reconstructed from exact recorded Git blob with provenance.','CUDA source configure initially mixed HYLE_INSTALL=ON with tests ON; corrected packaging switch to OFF in same source/build. Original failure and cumulative cost retained.'],limits=['No product/API/precision/performance change or new P1.','Host facets and original W1 reuse remain bound to exact candidate inputs; this supplement does not certify all formats/routes/shapes/capture/private upper.','Source builds are actual root Hyle test targets; SDK builds are installed-only pure-public consumers. Source mirror Git-free and Windows canonical; no remote product copyback.'])
(out/'receipt.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
print(json.dumps(dict(state=r['state'],runs=len(rows),raw_sha256=r['raw_archive']['sha256'])))
