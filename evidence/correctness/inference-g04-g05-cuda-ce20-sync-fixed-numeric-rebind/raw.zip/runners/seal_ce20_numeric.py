from pathlib import Path
import hashlib,json,sys,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';run=base/('ce20-sync-fixed-numeric-'+sys.argv[1])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_PASS'
assert all(x['exit_code']==0 for x in r['stages']) and len(r['binaries'])==2
assert [x['tool'] for x in r['device_checks']]==['memcheck','racecheck'] and all(x['verdict']=='PASS' for x in r['device_checks'])
for row in r['snapshot']['benchmark_inputs']+r['snapshot']['product_inputs']:assert sha(root/row['path'])==row['sha256'],row['path']
dest=root/'evidence/correctness/inference-g04-g05-cuda-ce20-sync-fixed-numeric-rebind';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(run.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(run).as_posix())
 z.write(base/'ce20_sync_fixed_numeric_wsl.py','runners/ce20_sync_fixed_numeric_wsl.py')
 z.write(base/'seal_ce20_numeric.py','runners/seal_ce20_numeric.py')
receipt=dict(state='TERMINAL_PASS',kind='G04_G05_CUDA_CE20_SYNC_FIXED_NATIVE_NUMERIC_REBIND',product_candidate='274cd9fec7cecb2e683cf5f0f87d6e0fd6b3ab55',successful_run=r,
 measured_seconds=r['cumulative_seconds'],raw_zip_sha256=sha(dest/'raw.zip'),limits=['Actual current relocated static CUDA SDK, primary/placement independent double oracles and readonly checks; three finite shapes.','Primary memcheck/racecheck includes both current product and sync-fixed native peer, no suppressed hazards.','No A/A, throughput or whole G04-G05 verdict. W1-WSL SM89 engineering only; native private-pool upper UNKNOWN.'])
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(path=str(dest),seconds=r['cumulative_seconds'],max_abs_error=r['max_abs_error'])))
