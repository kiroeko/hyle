#include <hyle/compute/detail/apple_batch_access.h>
