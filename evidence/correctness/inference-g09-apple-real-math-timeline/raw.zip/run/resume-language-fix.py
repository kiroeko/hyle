from pathlib import Path
import hashlib,json,os,re,subprocess,time,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified')
out=base/'g09-metal-timeline-check-1';profile=base/'a-cpu-apple/selected-graph'
parent=profile/'source-parent';build=profile/'source-build'
r=json.loads((out/'result.json').read_text())
assert r['state']=='FAIL' and r['stage']=='build'
assert not (out/'result-language-failure.json').exists()
(out/'result-language-failure.json').write_text(json.dumps(r,indent=2)+'\n')
cmake=parent/'CMakeLists.txt';text=(out/'original-parent-CMakeLists.txt').read_text()
source=Path(re.search(r'add_subdirectory\("([^"]+)" hyle\)',text)[1])
assert source.resolve().is_relative_to(base.resolve())
manifest=json.loads((out/'inputs-language-fix.json').read_text())
os.nice(10)
env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
started=time.monotonic()-r['elapsed_seconds']
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
with zipfile.ZipFile(out/'source-language-fix.zip') as archive:
    for item in manifest['files']:
        relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
        p=source/relative;assert p.resolve().is_relative_to(source.resolve())
        data=archive.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        if not p.is_file() or p.read_bytes()!=data:
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
r['source_tree_language_fix']=manifest['tree']
r['retained_failure']='result-language-failure.json'
old=str(source/'tests/graph/native_joint_pipeline.cc');new=str(source/'tests/graph/cpu_apple_pipeline_trace.mm')
assert text.count(old)==1
text=text.replace(old,new)
text+='\nset_source_files_properties("'+new+'" PROPERTIES LANGUAGE CXX COMPILE_OPTIONS "-x;objective-c++")\n'
text+='target_link_libraries(hyle_cpu_apple_pipeline PRIVATE "-framework Foundation" "-framework Metal")\n'
cmake.write_text(text)
def run(stage,args,timeout=1800):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        process=subprocess.Popen([str(a) for a in args],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
        r['child_pid']=process.pid;save()
        while True:
            try:code=process.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if stage.startswith(('manifest','build')) and process.poll() is None:
                    r.setdefault('time_extensions',[]).append({'stage':stage,'pid':process.pid,'seconds':timeout});save();continue
                process.kill();process.wait();code=124;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-14000:],flush=True);raise SystemExit(code)
ninja='/opt/homebrew/bin/ninja';targets=['hyle_cpu_apple_pipeline','hyle_cpu_apple_contracts','joint']
run('manifest-language-fix',[ninja,'-C',build,'build.ninja'])
preview=out/'preview-language-fix.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
(out/'dry-run-language-fix.log').write_text(dry);r['dry_run_language_fix_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<70 and 'Re-running CMake' not in dry and 'Building OBJCXX object' not in dry,dry
run('build-language-fix',[ninja,'-C',build,'-f',preview,'-j','4',*targets])
run('ordinary-pipeline',[build/'hyle_cpu_apple_pipeline'],600)
run('contracts',[build/'hyle_cpu_apple_contracts'],600)
run('g08-joint-regression',[build/'joint'],600)
run('metal-real-math-timeline',[build/'hyle_cpu_apple_pipeline','--trace'],600)
for item in manifest['files']:
    assert hashlib.sha256((source/item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['binaries']=[{'target':t,'sha256':hashlib.sha256((build/t).read_bytes()).hexdigest()} for t in targets]
r['state']='METAL_REAL_MATH_TIMELINE_AND_ORDINARY_CONSUMERS_PASS';save();print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
