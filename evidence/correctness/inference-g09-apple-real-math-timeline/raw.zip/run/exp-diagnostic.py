from pathlib import Path
import hashlib,json,os,re,subprocess,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g09-metal-timeline-check-1'
build=base/'a-cpu-apple/selected-graph/source-build';parent=build.parent/'source-parent'
r=json.loads((out/'result.json').read_text())
assert r['state']=='FAIL' and r['stage']=='metal-silu-real-math-timeline'
assert not (out/'result-silu-observation-gap.json').exists()
(out/'result-silu-observation-gap.json').write_text(json.dumps(r,indent=2)+'\n')
manifest=json.loads((out/'inputs-exp.json').read_text())
source=Path(re.search(r'add_subdirectory\("([^"]+)" hyle\)',(parent/'CMakeLists.txt').read_text())[1])
assert source.resolve().is_relative_to(base.resolve())
os.nice(10)
env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
started=time.monotonic()-r['elapsed_seconds']
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
with zipfile.ZipFile(out/'source-exp.zip') as z:
    for item in manifest['files']:
        p=source/item['path'];assert p.resolve().is_relative_to(source.resolve())
        data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        if not p.is_file() or p.read_bytes()!=data:
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
r['source_tree_exp']=manifest['tree'];r['diagnostic_shape_exp']='Final fixed same 4M F32 CPU Exp through the original default GGML executor, original GPU Neg and CPU join. One cold warm-up and eight single-slot observations per insertion order. Double oracle with fixed 2e-6 absolute plus 2e-6 relative error and nonfinite rejection. Earlier Abs no-overlap and SiLU incomplete CPU observation retained separately. No further shape search, no P1 or product change.'
def run(stage,args,timeout=1800):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        process=subprocess.Popen([str(a) for a in args],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
        r['child_pid']=process.pid;save()
        while True:
            try:code=process.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if stage.startswith('build') and process.poll() is None:
                    r.setdefault('time_extensions',[]).append({'stage':stage,'seconds':timeout});save();continue
                process.kill();process.wait();code=124;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-16000:],flush=True);raise SystemExit(code)
ninja='/opt/homebrew/bin/ninja';preview=out/'preview-language-fix.ninja'
dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n','hyle_cpu_apple_pipeline'],env=env,text=True)
(out/'dry-run-exp.log').write_text(dry);assert len(dry.splitlines())<6 and 'Building CXX object CMakeFiles/hyle_cpu_apple_pipeline' in dry,dry
run('build-exp',[ninja,'-C',build,'-f',preview,'-j','4','hyle_cpu_apple_pipeline'])
run('ordinary-pipeline-exp-final',[build/'hyle_cpu_apple_pipeline'],600)
run('metal-exp-real-math-timeline',[build/'hyle_cpu_apple_pipeline','--trace'],600)
for item in manifest['files']:assert hashlib.sha256((source/item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['binaries']=[{'target':t,'sha256':hashlib.sha256((build/t).read_bytes()).hexdigest()} for t in ['hyle_cpu_apple_pipeline','hyle_cpu_apple_contracts','joint']]
r['state']='METAL_REAL_MATH_TIMELINE_AND_ORDINARY_CONSUMERS_PASS';save();print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
