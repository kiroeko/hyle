from pathlib import Path
import subprocess,json,time
folder=Path.cwd()/'.scratch/inference-gaps/g01';base='/Users/kiro/hyle-scratch/compute-unified';remote=base+'/g01-native-ragged-cost-diagnostic.cc'
subprocess.run(['scp',str(folder/'native_ragged_cost_diagnostic.cc'),'kiro@172.22.10.198:'+remote],check=True)
body='''from pathlib import Path
import subprocess,os,time,json
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';build=base/'a-vulkan/selected-graph/static-sdk-build';out=base/'g01-native-ragged-cost-diagnostic';out.mkdir(exist_ok=True)
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
previous=(base/'g01-native-ragged-bench/project.cmake').read_text()
hook=out/'project.cmake';hook.write_text(previous+\"\"\"
if(PROJECT_NAME STREQUAL \\\"hyle\\\")
 function(g01_ragged_cost)
  add_executable(g01_ragged_cost \\\"\"\"\"+str(base/'g01-native-ragged-cost-diagnostic.cc')+\"\"\"\\\" \\\"\"\"\"+str(source/'bench/inference_resident_sdpa/native_ragged_reference.cc')+\"\"\"\\\" \\\"\"\"\"+str(source/'bench/inference_resident_sdpa/reference.cc')+\"\"\"\\\")
  target_compile_features(g01_ragged_cost PRIVATE cxx_std_23)
  target_include_directories(g01_ragged_cost PRIVATE \\\"\"\"\"+str(source/'src/compute_route_vulkan')+\"\"\"\\\" \\\"\"\"\"+str(source/'bench/inference_resident_sdpa')+\"\"\"\\\" \\\"\"\"\"+str(base/'g01-native-ragged-bench/reference-shaders')+\"\"\"\\\")
  target_link_libraries(g01_ragged_cost PRIVATE hyle::compute)
  hyle_stage_runtime(g01_ragged_cost)
 endfunction()
 cmake_language(DEFER CALL g01_ragged_cost)
endif()
\"\"\")
env=os.environ.copy();env['PATH']='/opt/homebrew/bin:'+env['PATH'];rows=[]
for stage,args in [('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)]),('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_ragged_cost','--parallel','4']),('run',[str(build/'bin/g01_ragged_cost')])]:
 log=out/(stage+'.log');start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'command':args,'log':str(log)};rows.append(row);(out/'result.json').write_text(json.dumps(rows,indent=2)+'\\n');print(json.dumps(row),flush=True)
 if r.returncode or stage=='run':print(log.read_text()[-2500:])
 if r.returncode:raise SystemExit(r.returncode)
'''
log=folder/'native-ragged-cost-diagnostic.log';start=time.monotonic()
with log.open('w',encoding='utf-8') as f:r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -'],input=body,text=True,stdout=f,stderr=subprocess.STDOUT)
(folder/'native-ragged-cost-diagnostic.json').write_text(json.dumps({'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
print(log.read_text(encoding='utf-8')[-3000:]);raise SystemExit(r.returncode)
