from pathlib import Path
import os,subprocess,json,time,sys,hashlib
route,mode=sys.argv[1:];assert route in ('apple','vulkan') and mode in ('static','shared')
base=Path('/Users/kiro/hyle-scratch/compute-unified');canonical=base/'source-c8874688';producer=base/f'a-{route}/selected-graph/{mode}-sdk-build'
assert producer.is_dir();assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
candidate='bc0ba41f714f6529cb1c583bee59d482946e7589';manifest=json.loads((base/'g01-native-ragged-input-manifest.json').read_text())
expected={x['path']:x['sha256'] for x in manifest['files']}
for name in [f'src/compute_route_{route}/{route}_batch.cc',f'include/hyle/compute/{route}_batch.h']:
 assert hashlib.sha256((canonical/name).read_bytes()).hexdigest()==expected[name]
workspace=base/f'g01-native-ragged-{route}-{mode}-rr-sdk';workspace.mkdir(exist_ok=True);source=workspace/'consumer-source';source.mkdir(exist_ok=True)
build=workspace/'consumer-build';stage=workspace/'staging';prefix=workspace/'relocated';record=workspace/'result.json';records=json.loads(record.read_text())['stages'] if record.exists() else []
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def done(stage):return next((x for x in reversed(records) if x['stage']==stage),{}).get('exit_code')==0
def run(stage,args):
 n=1+sum(x['stage']==stage for x in records);log=workspace/f'{stage}-{n}.log';start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 record.write_text(json.dumps({'candidate':candidate,'route':route,'mode':mode,'scope':'actual relocated public SDK, native math/lease allocation/two-eight requests/empty/reorder/old outputs/tail/readonly; source-only structure/failure tests excluded','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2300));print(f.read(2300).decode(errors='replace'))
  raise SystemExit(r.returncode)
if not done('producer-build'):run('producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target',f'hyle_compute_route_{route}','hyle_graph_batch','hyle_compute_state','--parallel','4'])
if not done('install'):
 assert not prefix.exists();run('install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
inputs=[f'tests/compute_route_{route}/native_ragged_test.cc','tests/compute_batch/native_ragged_layout_test.h','tests/compute_provider_native/half_test_support.h']
ident=[]
for name in inputs:
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((canonical/name).read_bytes());ident.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
storage=source/'tests/compute_provider_native/oracle_storage.h';storage.write_bytes((canonical/'include/hyle/simd/types.h').read_bytes())
helper=source/'tests/compute_provider_native/half_test_support.h';helper.write_bytes(helper.read_bytes().replace(b'#include "hyle/simd/dtype.h"',b'#include "oracle_storage.h"'))
ident.append({'path':'tests/compute_provider_native/oracle_storage.h','role':'test-only scalar bit carriers, not product SDK dependency','sha256':hashlib.sha256(storage.read_bytes()).hexdigest()})
(workspace/'consumer-inputs.json').write_text(json.dumps(ident,indent=2)+'\n')
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g01_native_ragged_public_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory(/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 gtest EXCLUDE_FROM_ALL)
add_executable(ragged tests/compute_route_'''+route+'''/native_ragged_test.cc)
target_compile_features(ragged PRIVATE cxx_std_23)
target_compile_options(ragged PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_link_libraries(ragged PRIVATE hyle::compute GTest::gtest_main)
hyle_stage_runtime(ragged)
''')
if not done('consumer-configure'):run('consumer-configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+str(prefix)])
if not done('consumer-build'):run('consumer-build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','ragged','--parallel','4'])
if not done('run'):run('run',[str(build/'ragged')])
