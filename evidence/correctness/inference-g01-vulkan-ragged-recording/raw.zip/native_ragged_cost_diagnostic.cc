#include "hyle/compute/vulkan_batch.h"
#include "vulkan_program_internal.h"
#include "native_ragged_reference.h"
#include <array>
#include <cstdio>
namespace c=hyle::compute;namespace v=c::vulkan;namespace d=v::detail;
template<class T>T take(hyle::Result<T> r){if(!r){std::fprintf(stderr,"%.*s\n",int(r.error().message().size()),r.error().message().data());std::exit(2);}return std::move(*r);}
int main(){
 v::ContextOptions o;o.loader_path="/opt/homebrew/opt/vulkan-loader/lib/libvulkan.1.dylib";auto context=take(v::Context::create(o));
 const c::BatchCapacity cap{.storage=c::BatchStorage::kRagged,.max_requests=2,.max_query_rows=21,.max_kv_rows=91,.max_pages=0,.max_page_refs=0,.query_heads=8,.kv_heads=2,.head_dim=64,.page_size=1};
 const std::array<std::int32_t,3> qp{0,1,18},kp{0,31,78};auto schema=take(c::BatchSchema::create(cap));auto layout=take(schema.version({qp,kp,{},{}}));const c::RaggedAttention a{cap,.125F,false};
 for(bool peer:{false,true}){
  auto program=peer?hyle::bench::resident::ragged_reference_program(context,layout,a):take(v::prepare_ragged_batch(context,layout,a));auto slot=take(program.create_invocation());
  const auto &p=*d::Access::program(program);
  std::printf("arm=%s values=%zu dispatches=%zu storage_blocks=%zu\n",peer?"peer":"candidate",p.values.size(),p.dispatches.size(),p.block_bytes.size());
  for(std::size_t index=0;index<p.dispatches.size();++index){const auto &dispatch=p.dispatches[index];std::printf("dispatch=%zu managed=%d native=%d ports=%zu\n",index,bool(dispatch.region),bool(dispatch.pipeline),dispatch.values.size());
   if(dispatch.region)for(const auto &node:dispatch.region->nodes)std::printf("  operation=%u inputs=%zu outputs=%zu\n",unsigned(node.operation.kind()),node.inputs.size(),node.outputs.size());
  }
 }
 if(!context.close().ok())return 2;
}
