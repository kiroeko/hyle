#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <span>
#include <utility>
#include <vector>

#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/onednn.h"
#include "hyle/graph/cpu.h"
#include "hyle/mem/buffer.h"

namespace c = hyle::compute;
namespace g = hyle::graph;
template <class T> T take(hyle::Result<T> result) {
  if (!result) {
    std::fprintf(stderr, "%.*s\n", int(result.error().message().size()), result.error().message().data());
    std::exit(1);
  }
  return std::move(*result);
}
void require(hyle::Status result) {
  if (!result.ok()) {
    std::fprintf(stderr, "%.*s\n", int(result.message().size()), result.message().data());
    std::exit(2);
  }
}
c::TensorDesc matrix(std::int64_t rows, std::int64_t columns) {
  return take(c::TensorDesc::dense(c::DataType::kFloat32, std::array{rows, columns}));
}
int main() {
  for (const std::int64_t rows : {1, 4}) {
    constexpr std::int64_t k = 17, n = 65;
    const auto xd = matrix(rows, k), wd = matrix(k, n), yd = matrix(rows, n);
    auto xb = take(hyle::mem::Buffer::create(hyle::mem::system_resource(), *xd.required_bytes(), 64));
    auto wb = take(hyle::mem::Buffer::create(hyle::mem::system_resource(), *wd.required_bytes(), 64));
    auto yb = take(hyle::mem::Buffer::create(hyle::mem::system_resource(), *yd.required_bytes(), 64));
    std::vector<float> x(rows * k), w(k * n, 1.0F), actual(rows * n);
    require(wb.view().write(std::as_bytes(std::span(w))));
    const auto xv = take(c::ConstTensorView::create(xd, xb.view()));
    const auto wv = take(c::ConstTensorView::create(wd, wb.view()));
    const auto yv = take(c::TensorView::create(yd, yb.view()));
    auto input = [&](int seed) {
      std::fill(x.begin(), x.end(), float(seed));
      require(xb.view().write(std::as_bytes(std::span(x))));
    };
    auto check = [&](int seed) {
      require(yb.view().read(std::as_writable_bytes(std::span(actual))));
      for (const auto value : actual) {
        if (value != float(seed * k)) { std::fprintf(stderr, "wrong M%lld result %.9g\n", (long long)rows, value); std::exit(3); }
      }
    };
    for (const bool expert : {false, true}) {
      auto context = expert ? take(c::Context::create(c::cpu::device(), c::onednn::provider()))
                            : take(c::cpu::create_context());
      auto queue = take(context.create_queue());
      auto program = take(c::prepare(context, c::MatMul{}, xd, wd, yd));
      if (program.provider().id != c::onednn::kProviderId) std::exit(4);
      hyle::mem::Buffer workspace;
      const auto need = program.workspace_requirement();
      if (need.size) workspace = take(hyle::mem::Buffer::create(hyle::mem::system_resource(), need.size, need.alignment));
      auto lane = take(program.create_invocation(workspace.view()));
      for (const int seed : {1, 2}) {
        input(seed);
        auto done = take(lane.submit(queue, xv, wv, yv)); require(done.wait()); check(seed);
      }
    }
    auto builder = take(g::GraphBuilder::create());
    const auto xi = take(builder.input(xd)), wi = take(builder.input(wd));
    const auto yi = take(builder.add(c::MatMul{}, xi, wi));
    require(builder.publish(yi));
    auto logical = take(std::move(builder).finish());
    auto context = take(g::cpu::create_context());
    auto compiled = take(g::compile(logical, context));
    if (compiled.report.provider().id != c::onednn::kProviderId) std::exit(5);
    auto queue = take(context.create_queue());
    auto lane = take(compiled.executable.create_invocation());
    require(lane.bind(xi, xv)); require(lane.bind(wi, wv)); require(lane.bind(yi, yv));
    const std::array queues{g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &queue}};
    require(lane.prepare_replay(queues));
    for (const int seed : {1, 2}) {
      input(seed);
      auto done = take(lane.submit(queue)); require(done.wait()); check(seed);
    }
  }
  std::puts("ordinary + expert CPU oneDNN M1/M4 Direct and ordinary Graph, changed-input two replays PASS");
}
