import hashlib
exec(open('.scratch/cpu-ggml-isa-product-validate.py', encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-onednn-admission/windows-delivery'
out.mkdir(parents=True,exist_ok=True)
records=[]
manifest=json.loads((out.parent/'manifest.json').read_text())
assert candidate==manifest['candidate']
source=Path('C:/hv/d5cd/source-tree').resolve()
assert source.is_relative_to(Path('C:/hv/d5cd').resolve()) and source.is_dir()
changed=[]
for name,sha in manifest['files'].items():
    data=(repo/name).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,name
    dest=(source/name).resolve();assert dest.is_relative_to(source)
    if not dest.exists() or dest.read_bytes()!=data:
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha,name
(out/'source-identity.json').write_text(json.dumps(dict(candidate=candidate,checked=len(manifest['files']),forward_updated=changed),indent=2)+'\n')
print('canonical source forward sync',len(manifest['files']),'checked',len(changed),'updated',flush=True)
overlay=out.parent/'windows-overlay.cmake'
for stage in ('shared','static'):
    producer=repo if stage=='shared' else Path('C:/hv/d5cp/consumer')
    build=repo/'.scratch/build-compute-v2-dev' if stage=='shared' else Path('C:/hv/d5cp/source-build')
    prefix=Path('C:/hv/cpu-ggml-isa-'+stage+'-sdk')
    run(stage+'-producer-configure',['cmake','-S',producer,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(overlay)])
    run(stage+'-producer-build',['cmake','--build',build,'--target','cpu_onednn_admission_consumer','hyle_time','--parallel','2'])
    run(stage+'-source-ordinary-expert-graph',[build/'bin/cpu_onednn_admission_consumer.exe' if stage=='shared' else build/'cpu_onednn_admission_consumer.exe'])
    run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
    consumer=Path('C:/hv/cpu-onednn-'+stage+'-consumer')
    run(stage+'-consumer-configure',['cmake','-S',out.parent/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
    run(stage+'-installed-ordinary-expert-graph',[consumer/'cpu_onednn_admission_consumer.exe'])
