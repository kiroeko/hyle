import hashlib,sys
exec(open('.scratch/cpu-ggml-isa-product-validate.py', encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-ggml-gated-numeric/windows'
out.mkdir(parents=True,exist_ok=True)
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
fixture=out.parent
manifest=json.loads((repo/'.scratch/validation/cpu-onednn-admission/manifest.json').read_text())
candidate=manifest['candidate']
for name,sha in manifest['files'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha,name
overlay=fixture/'windows-overlay.cmake'
if '--resume-configure' not in sys.argv:
    run('selector-plan',['python','scripts/validation-select.py','plan','--base','fe203c75','--candidate',candidate,'--output',out/'selector-plan.json'])
    run('fixture-tool-tests',['python','tests/compute_models/inputs_test.py'])
run('configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(overlay)])
run('selected-batch-build',['cmake','--build',build,'--target','hyle_compute_provider_ggml_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','cpu_gated_consumer','--parallel','2'])
run('selected-batch-tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-L','^(compute_provider_ggml|compute_route_cpu|graph_route_cpu)$','-LE','headers','-j','1','--output-junit',out/'tests.xml'])
run('shared-source-gated',[build/'bin/cpu_gated_consumer.exe'])
source=Path('C:/hv/d5cd/source-tree').resolve()
assert source.is_relative_to(Path('C:/hv/d5cd').resolve()) and source.is_dir()
changed=[]
for name,sha in manifest['files'].items():
    data=(repo/name).read_bytes(); assert hashlib.sha256(data).hexdigest()==sha,name
    dest=(source/name).resolve(); assert dest.is_relative_to(source)
    if not dest.exists() or dest.read_bytes()!=data:
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha,name
(out/'source-identity.json').write_text(json.dumps(dict(candidate=candidate,checked=len(manifest['files']),forward_updated=changed),indent=2)+'\n')
for stage in ('shared','static'):
    prefix=Path('C:/hv/cpu-ggml-isa-'+stage+'-sdk')
    if stage=='shared':
        run('shared-producer-configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    else:
        build=Path('C:/hv/d5cp/source-build')
        run('static-producer-configure',['cmake','-S','C:/hv/d5cp/consumer','-B',build,'-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(overlay)])
    run(stage+'-producer-build',['cmake','--build',build,'--target','cpu_gated_consumer','hyle_time','--parallel','2'])
    if stage=='static':run(stage+'-source-gated',[build/'cpu_gated_consumer.exe'])
    run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
    consumer=Path('C:/hv/cpu-gated-'+stage+'-consumer')
    run(stage+'-consumer-configure',['cmake','-S',fixture/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
    run(stage+'-installed-gated',[consumer/'cpu_gated_consumer.exe'])
