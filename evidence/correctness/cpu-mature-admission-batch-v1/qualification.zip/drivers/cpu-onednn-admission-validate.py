exec(open('.scratch/cpu-ggml-isa-product-validate.py', encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-onednn-admission/windows'
out.mkdir(parents=True,exist_ok=True)
records=[]
run('selector-plan', ['python','scripts/validation-select.py','plan','--base','60534925','--candidate',candidate,'--output',out/'selector-plan.json'])
run('configure', ['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('selected-cpu-batch-build', ['cmake','--build',build,'--target','hyle_compute_provider_onednn_tests','hyle_compute_route_cpu_tests','hyle_graph_provider_onednn_tests','hyle_graph_route_cpu_tests','--parallel','2'])
run('selected-cpu-batch-tests', ['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-L','^(compute_provider_onednn|compute_route_cpu|graph_provider_onednn|graph_route_cpu)$','-LE','headers','-j','1','--output-junit',out/'tests.xml'])
