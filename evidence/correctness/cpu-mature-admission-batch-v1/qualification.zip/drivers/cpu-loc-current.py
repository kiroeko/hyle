import json,subprocess
from pathlib import Path
paths=json.loads(Path('evidence/correctness/llm-moe-d5-real-fragments/cpu-official-torch-binding/loc.json').read_text(encoding='utf-8'))['module']['paths']
args=['python','scripts/loc-report.py','--module','compute-graph','--json','--self-check']
for path in paths:args+=['--module-path',path]
r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
r.check_returncode()
Path('.scratch/validation/cpu-ggml-isa-admission/product/loc.json').write_bytes(r.stdout)
d=json.loads(r.stdout);print(json.dumps(d['module'],ensure_ascii=False))
