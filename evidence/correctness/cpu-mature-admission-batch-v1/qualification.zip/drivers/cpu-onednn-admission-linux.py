import hashlib,json,os,subprocess,sys,time
from pathlib import Path
repo=Path('/mnt/c/public/project-hyle/hyle')
out=repo/'.scratch/validation/cpu-onednn-admission/linux'
out.mkdir(parents=True,exist_ok=True)
manifest=json.loads((out.parent/'manifest.json').read_text())
source=Path('/root/hyle-scratch/active-cpu-z/source').resolve()
assert source.is_relative_to(Path('/root/hyle-scratch/active-cpu-z').resolve()) and source.is_dir()
changed=[]
for name,sha in manifest['files'].items():
    data=(repo/name).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,name
    dest=(source/name).resolve();assert dest.is_relative_to(source)
    if not dest.exists() or dest.read_bytes()!=data:
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha,name
identity = out/'source-identity.json'
if identity.exists():
    previous=json.loads(identity.read_text())
    (out/('source-identity-'+previous['candidate'][:12]+'.json')).write_bytes(identity.read_bytes())
identity.write_text(json.dumps(dict(candidate=manifest['candidate'],checked=len(manifest['files']),forward_updated=changed),indent=2)+'\n')
print('canonical source forward sync',len(manifest['files']),'checked',len(changed),'updated',flush=True)
if '--sync-only' in sys.argv: raise SystemExit(0)
os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
os.environ.pop('LD_LIBRARY_PATH',None)
build=source.parent/'build'
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
def run(name,args):
    start=time.monotonic();path=out/(str(len(records)+1)+'-'+name+'.log')
    with path.open('wb') as log:r=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=list(map(str,args)),candidate=manifest['candidate'],log=path.name,returncode=r.returncode,seconds=round(time.monotonic()-start,3)))
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
    if r.returncode:print(path.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(r.returncode)
if '--resume-build' not in sys.argv and '--delivery-only' not in sys.argv:
    run('configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(out.parent/'linux-overlay.cmake')])
if '--delivery-only' not in sys.argv:
    run('selected-cpu-batch-build',['cmake','--build',build,'--target','hyle_compute_provider_ggml_tests','hyle_compute_provider_onednn_tests','hyle_compute_route_cpu_tests','hyle_graph_provider_onednn_tests','hyle_graph_route_cpu_tests','cpu_onednn_admission_consumer','--parallel','2'])
    run('selected-cpu-batch-tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-L','^(compute_provider_ggml|compute_provider_onednn|compute_route_cpu|graph_provider_onednn|graph_route_cpu)$','-LE','headers','-j','1','--output-junit',out/'tests.xml'])
    run('source-ordinary-expert-graph',[''+str(build/'bin/cpu_onednn_admission_consumer')])
if '--tests-only' in sys.argv:raise SystemExit(0)
for stage in ('shared','static'):
    prefix=Path('/root/hyle-scratch/cpu-ggml-isa-delivery')/stage
    run(stage+'-producer-configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if stage=='static' else 'OFF'),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(stage+'-producer-build',['cmake','--build',build,'--parallel','2'])
    run(stage+'-source-ordinary-expert-graph',[build/'bin/cpu_onednn_admission_consumer'])
    run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
    consumer=prefix.parent/(stage+'-consumer')
    run(stage+'-consumer-configure',['cmake','-S',out.parent/'consumer','-B',consumer.parent/(stage+'-onednn-consumer'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    consumer=consumer.parent/(stage+'-onednn-consumer')
    run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
    run(stage+'-installed-ordinary-expert-graph',[consumer/'cpu_onednn_admission_consumer'])
