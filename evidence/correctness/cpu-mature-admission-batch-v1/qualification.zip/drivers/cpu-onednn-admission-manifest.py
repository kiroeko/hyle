import hashlib, json, subprocess
from pathlib import Path
repo=Path.cwd()
names=subprocess.check_output(['git','ls-files'],text=True).splitlines()
prefixes=('src/','include/','cmake/','scripts/','third_party/','tests/','samples/package/')
files={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in names if name.startswith(prefixes) or name in ('CMakeLists.txt','CMakePresets.json')}
out=repo/'.scratch/validation/cpu-onednn-admission/manifest.json'
out.write_text(json.dumps(dict(candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files=files),indent=2)+'\n',encoding='utf-8')
print(len(files),'canonical product/test inputs')
