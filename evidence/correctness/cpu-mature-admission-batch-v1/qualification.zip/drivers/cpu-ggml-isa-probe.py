import ctypes,json,os,subprocess,time
from pathlib import Path
repo=Path(__file__).resolve().parents[1]
out=repo/'.scratch/validation/cpu-ggml-isa-admission'
build=Path('C:/hv/cpu-ggml-isa-admission')
ctypes.windll.kernel32.SetErrorMode(32771)
flags=dict(creationflags=subprocess.CREATE_NO_WINDOW)
env=dict(os.environ,VSLANG='1033')
r=subprocess.run(['cmd','/d','/c',str(repo/'.scratch/validation/d5-cpu-apple-official-binding/3c22b7b9f230-tests/environment.cmd')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,**flags);r.check_returncode()
for line in r.stdout.decode(errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        key,value=line.split('=',1);env[key]=value
records=[]
def run(name,args):
    start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:
        r=subprocess.run(list(map(str,args)),env=env,stdout=log,stderr=subprocess.STDOUT,**flags)
    records.append(dict(name=name,args=list(map(str,args)),returncode=r.returncode,seconds=round(time.monotonic()-start,3)))
    (out/'receipt.json').write_bytes((json.dumps(records,indent=2)+'\n').encode('utf-8'));print(records[-1],flush=True)
    if r.returncode:
        print((out/(name+'.log')).read_text(encoding='utf-8',errors='replace')[-4000:],flush=True);raise SystemExit(r.returncode)
run('configure',['cmake','-S',out,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DHYLE_SOURCE_DIR='+str(repo),'-DGGML_SOURCE='+str(repo/'.scratch/build-compute-v2-dev/src/compute_ggml_runtime/source-d8ea95b566c61d43')])
run('build',['cmake','--build',build,'--target','cpu_capsule_probe','-j','2'])
run('original-capsule-graph',[build/'cpu_capsule_probe.exe',build/'cpu_haswell.dll'])
