import hashlib,json,os,subprocess,time
from pathlib import Path
repo=Path('/mnt/c/public/project-hyle/hyle')
fixture=repo/'.scratch/validation/cpu-ggml-gated-numeric'
out=fixture/'linux-delivery';out.mkdir(parents=True,exist_ok=True)
identity=json.loads((repo/'.scratch/validation/cpu-onednn-admission/linux/source-identity.json').read_text())
manifest=json.loads((repo/'.scratch/validation/cpu-onednn-admission/manifest.json').read_text())
candidate=manifest['candidate']
assert candidate==identity['candidate']
for name,sha in manifest['files'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha,name
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2';os.environ.pop('LD_LIBRARY_PATH',None)
build=Path('/root/hyle-scratch/active-cpu-z/build')
def run(name,args):
    start=time.monotonic();path=out/(str(len(records)+1)+'-'+name+'.log')
    with path.open('wb') as log:r=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(name=name,args=list(map(str,args)),candidate=candidate,log=path.name,returncode=r.returncode,seconds=round(time.monotonic()-start,3)))
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
    if r.returncode:print(path.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(r.returncode)
# The preceding producer batch ended on the installed static candidate. This
# adds only an ordinary consumer target and retains the product/cache identity.
assert 'build cpu_gated_consumer:' in (build/'build.ninja').read_text()
assert 'HYLE_STATIC:BOOL=ON' in (build/'CMakeCache.txt').read_text()
run('static-source-build',['cmake','--build',build,'--target','cpu_gated_consumer','--parallel','2'])
run('static-source-gated',[build/'bin/cpu_gated_consumer'])
for stage in ('shared','static'):
    prefix=Path('/root/hyle-scratch/cpu-ggml-isa-delivery')/stage
    consumer=prefix.parent/(stage+'-gated-consumer')
    run(stage+'-consumer-configure',['cmake','-S',fixture/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
    run(stage+'-installed-gated',[consumer/'cpu_gated_consumer'])
