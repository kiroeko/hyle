#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <span>
#include <type_traits>
#include <utility>
#include <vector>

#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/cpu.h"
#include "hyle/mem/buffer.h"
#include "hyle/simd/types.h"

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;

template <class T> T take(hyle::Result<T> result) {
  if (!result) {
    std::fprintf(stderr, "%.*s\n", int(result.error().message().size()),
                 result.error().message().data());
    std::exit(1);
  }
  return std::move(*result);
}
void require(hyle::Status result) {
  if (!result.ok()) {
    std::fprintf(stderr, "%.*s\n", int(result.message().size()), result.message().data());
    std::exit(2);
  }
}
template <class T> constexpr c::DataType dtype() {
  if constexpr (std::is_same_v<T, float>) return c::DataType::kFloat32;
  if constexpr (std::is_same_v<T, hyle::simd::float16_t>) return c::DataType::kFloat16;
  return c::DataType::kBFloat16;
}
// Input constants are exact in all three storage formats. No library/private
// conversion or fixture dependency is needed by the installed consumer.
template <class T> T constant(int value) {
  if constexpr (std::is_same_v<T, float>) {
    return value == -1 ? -std::numeric_limits<float>::infinity() : float(value);
  } else {
    constexpr bool half = std::is_same_v<T, hyle::simd::float16_t>;
    const std::uint16_t bits = value == -1 ? (half ? 0xfc00 : 0xff80)
                               : value == 1 ? (half ? 0x3c00 : 0x3f80)
                               : value == 2 ? 0x4000 : 0;
    return T::from_bits(bits);
  }
}
template <class T> float decode(T value) {
  if constexpr (std::is_same_v<T, float>) {
    return value;
  } else if constexpr (std::is_same_v<T, hyle::simd::bfloat16_t>) {
    return std::bit_cast<float>(std::uint32_t(value.bits) << 16);
  } else {
    const auto exponent = (value.bits >> 10) & 31;
    const auto fraction = value.bits & 1023;
    const float magnitude = exponent == 31 ? std::numeric_limits<float>::infinity()
                            : exponent == 0 ? std::ldexp(float(fraction), -24)
                            : std::ldexp(float(1024 + fraction), int(exponent) - 25);
    return value.bits & 0x8000 ? -magnitude : magnitude;
  }
}
template <class T> c::TensorDesc matrix(std::int64_t rows, std::int64_t columns) {
  return take(c::TensorDesc::dense(dtype<T>(), std::array{rows, columns}));
}
m::Buffer buffer(const c::TensorDesc &description) {
  return take(m::Buffer::create(m::system_resource(), take(description.required_bytes()), 64));
}
template <class T> void check(const m::Buffer &output, std::size_t count, float expected) {
  std::vector<T> actual(count);
  require(output.view().read(std::as_writable_bytes(std::span(actual))));
  constexpr float tolerance = std::is_same_v<T, float> ? 2.e-5F
                              : std::is_same_v<T, hyle::simd::float16_t> ? 0.01F : 0.04F;
  for (auto stored : actual) {
    const float value = decode(stored);
    if (!std::isfinite(value) || std::abs(value - expected) > tolerance ||
        (expected == 0 && (value != 0 || std::signbit(value)))) {
      std::fprintf(stderr, "wrong gated %d output: %.9g expected %.9g\n", int(dtype<T>()), value, expected);
      std::exit(3);
    }
  }
}
template <class T> void run() {
  constexpr std::int64_t rows = 3, hidden = 7, columns = 2;
  const auto description = matrix<T>(rows, hidden);
  auto value_buffer = buffer(description), output_buffer = buffer(description);
  std::vector<T> values(rows * hidden, constant<T>(1));
  require(value_buffer.view().write(std::as_bytes(std::span(values))));
  const auto value_view = take(c::ConstTensorView::create(description, value_buffer.view()));
  const auto output_view = take(c::TensorView::create(description, output_buffer.view()));
  auto context = take(c::cpu::create_context({.native_threads = 4}));
  auto queue = take(context.create_queue());
  for (const bool packed : {false, true}) {
    const auto gate_desc = matrix<T>(rows, hidden * (packed ? 2 : 1));
    auto gate_buffer = buffer(gate_desc);
    const auto gate_view = take(c::ConstTensorView::create(gate_desc, gate_buffer.view()));
    const auto operation = c::GatedActivation{
        .inputs = packed ? c::GatedInputKind::kPackedHalves : c::GatedInputKind::kSeparate};
    std::vector<c::TensorDesc> inputs{gate_desc};
    if (!packed) inputs.push_back(description);
    const std::array outputs{description};
    auto program = take(c::prepare(context, c::Operation(operation), inputs, outputs, m::system_resource()));
    if (program.provider().id != c::ggml_cpu::kProviderId) std::exit(4);
    m::Buffer workspace;
    const auto need = program.workspace_requirement();
    if (need.size) workspace = take(m::Buffer::create(m::system_resource(), need.size, need.alignment));
    auto lane = take(program.create_invocation(workspace.view()));
    for (const int input : {-1, 2}) {
      std::vector<T> gates(rows * hidden * (packed ? 2 : 1), constant<T>(1));
      for (std::int64_t row = 0; row < rows; ++row) {
        std::fill_n(gates.begin() + row * hidden * (packed ? 2 : 1), hidden, constant<T>(input));
      }
      require(gate_buffer.view().write(std::as_bytes(std::span(gates))));
      std::vector<c::ConstTensorView> bindings{gate_view};
      if (!packed) bindings.push_back(value_view);
      const std::array results{output_view};
      auto done = take(lane.submit(queue, bindings, results));
      require(done.wait());
      check<T>(output_buffer, rows * hidden, input == -1 ? 0.F : 1.761594156F);
    }
  }

  auto gate_buffer = buffer(description);
  const auto weights = take(matrix<T>(columns, hidden).transposed());
  auto weight_buffer = buffer(weights);
  std::vector<T> weight_values(hidden * columns, constant<T>(1));
  require(weight_buffer.view().write(std::as_bytes(std::span(weight_values))));
  const auto result_desc = matrix<T>(rows, columns);
  auto result_buffer = buffer(result_desc);
  auto builder = take(g::GraphBuilder::create());
  const auto gate = take(builder.input(description)), value = take(builder.input(description));
  const auto weight = take(builder.input(weights));
  const auto activation = take(builder.add(c::GatedActivation{.inputs = c::GatedInputKind::kSeparate}, gate, value));
  const auto output = take(builder.add(c::MatMul{}, activation, weight));
  require(builder.publish(output));
  auto logical = take(std::move(builder).finish());
  auto graph_context = take(g::cpu::create_context({.native_threads = 4}));
  auto compiled = take(g::compile(logical, graph_context));
  if (compiled.report.region_count() != 1 || compiled.report.step_count() != 1 ||
      compiled.report.step(0)->provider.id != c::ggml_cpu::kProviderId ||
      compiled.report.step(0)->node_count != 2) std::exit(5);
  auto graph_queue = take(graph_context.create_queue());
  auto lane = take(compiled.executable.create_invocation());
  require(lane.bind(gate, take(c::ConstTensorView::create(description, gate_buffer.view()))));
  require(lane.bind(value, value_view));
  require(lane.bind(weight, take(c::ConstTensorView::create(weights, weight_buffer.view()))));
  require(lane.bind(output, take(c::TensorView::create(result_desc, result_buffer.view()))));
  const std::array queues{g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &graph_queue}};
  require(lane.prepare_replay(queues));
  for (const int input : {-1, 2}) {
    std::vector<T> gates(rows * hidden, constant<T>(input));
    require(gate_buffer.view().write(std::as_bytes(std::span(gates))));
    auto done = take(lane.submit(graph_queue));
    require(done.wait());
    check<T>(result_buffer, rows * columns, input == -1 ? 0.F : hidden * 1.761594156F);
  }
}
int main() {
  run<float>();
  run<hyle::simd::float16_t>();
  run<hyle::simd::bfloat16_t>();
  std::puts("ordinary CPU F32/F16/BF16 packed/separate Gated Direct + whole Gated->MatMul Graph, -Inf/finite changed-input replay PASS");
}
