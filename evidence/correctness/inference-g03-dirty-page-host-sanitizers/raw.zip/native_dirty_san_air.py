from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
route,mode=sys.argv[1:]
assert route in ['apple','vulkan'] and mode in ['asan','ubsan','tsan']
candidate='b42832de3ddda21bdc3e98ad4cc87e73622cbba4'
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688'
root=base/f'foundation-f5-native-host-{route}-{mode}';parent=root/'parent';build=root/'build'
out=base/f'g03-dirty-page-{route}-{mode}';out.mkdir(exist_ok=True)
assert build.is_dir() and parent.is_dir()
identity={n:subprocess.check_output(a,text=True).strip() for n,a in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
with zipfile.ZipFile(base/'g03-native-dirty-risk-stage/input-9.zip') as archive:
    manifest=json.loads(archive.read('input-manifest.json'))
for item in manifest:
    destination=source/item['path']
    if not destination.exists() or hashlib.sha256(destination.read_bytes()).hexdigest()!=item['sha256']:
        with zipfile.ZipFile(base/'g03-native-dirty-risk-stage/input-9.zip') as archive:data=archive.read(item['path'])
        assert hashlib.sha256(data).hexdigest()==item['sha256']
        destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
    assert hashlib.sha256(destination.read_bytes()).hexdigest()==item['sha256'],item['path']
targets=[('g03_dirty_public','tests/compute_batch/dirty_page_native_consumer.cc'),('g03_dirty_risks','tests/compute_batch/dirty_page_'+route+'_risks.cc'),('g03_dirty_cpu','tests/compute_batch/dirty_page_public_consumer.cc')]
body=(parent/'CMakeLists.txt').read_text()
for target,name in targets:
    if f'add_executable({target} ' not in body:
        body+=f'\nadd_executable({target} "{source/name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_link_libraries({target} PRIVATE hyle::graph)\nhyle_apply_sanitizer({target})\nhyle_stage_runtime({target})\n'
        if route=='apple' and target=='g03_dirty_public':body+=f'target_compile_definitions({target} PRIVATE HYLE_DIRTY_PAGE_APPLE=1)\n'
if route=='apple' and mode=='tsan':
    metal=base/'g01-metal-callback-tsan-probe/tsan-metal-cpp'
    assert hashlib.sha256((metal/'Metal/MTLCommandBuffer.hpp').read_bytes()).hexdigest()=='4a58c6e564e3a7efcdf5c7709eeee99ec7b7c40594e2ada5ec5c91012171d504'
    for target,_ in targets:
        body+=f'target_include_directories({target} BEFORE PRIVATE "{metal}")\n'
if mode=='tsan':
    model=base/'g02-refcount-fence-probe/tsan-headers'
    for target,_ in targets:
        body+=f'target_include_directories({target} BEFORE PRIVATE "{model}")\n'
(parent/'CMakeLists.txt').write_text(body)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
record=out/'result.json';rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
def run(stage,args):
    number=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{number}.log';start=time.monotonic()
    with log.open('w') as stream:
        process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (out/'job.json').write_text(json.dumps({'state':'RUNNING','route':route,'mode':mode,'stage':stage,'pid':process.pid,'log':str(log)}))
        print('RUN',route,mode,stage,'PID',process.pid,flush=True)
        result=subprocess.CompletedProcess(args,process.wait())
    row={'stage':stage,'command':args,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    record.write_text(json.dumps({'candidate':candidate,'route':route,'mode':mode,'identity':identity,'inputs':manifest,
        'scope':'actual G03 dirty page/CPU public/native math and copy lifecycle host instrumentation; explicit Metal boundary only Apple TSan, exact intrusive final-fence model on TSan both; no LSan/shader/driver/native private pool claim',
        'stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n');print(json.dumps(row),flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-5500:],flush=True);(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':result.returncode}));raise SystemExit(result.returncode)
run('configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build),'-DHYLE_COMPUTE_ROUTES=cpu;'+route])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target']+[t for t,_ in targets]+['--parallel','4'])
commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode];checked=[]
names=['src/compute/batch_transfer.cc',f'src/compute_route_{route}/'+('apple_copy_program.cc' if route=='apple' else 'vulkan_copy_program.cc'),
       'src/graph/lease_submission.cc','src/compute_batch/batch_paged_native.cc','src/compute_batch/paged_arena.cc',
       ('src/compute_route_apple/apple_context.cc' if route=='apple' else 'src/compute_route_vulkan/vulkan_device.cc')]+[n for _,n in targets]
if route=='apple' and mode=='tsan':names+=['mlx/array.cpp','mlx/backend/metal/metal.cpp','mlx/backend/metal/scaled_dot_product_attention.cpp']
for name in names:
    found=[r for r in commands if r['file'].endswith(name)];assert found and all(flag in r['command'] for r in found),name;checked.extend(found)
(out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\n')
for target,_ in targets:run(target,[str(build/target)])
print('TERMINAL PASS',route,mode,flush=True)

(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':0,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)}))
