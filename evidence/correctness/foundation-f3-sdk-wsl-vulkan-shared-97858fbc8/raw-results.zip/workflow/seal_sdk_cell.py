from pathlib import Path
import hashlib
import json
import sys
import zipfile

repo = Path.cwd(); folder = Path(sys.argv[1])
job = json.loads((folder / 'job.json').read_text())
assert job['verdict'].startswith('PASS_') and job['verdict'].endswith('_RELOCATED_SDK_ONLY')
for row in job['stages']:
    assert row['state'] == 'terminal'
    assert row['exit_code'] != 0 if row['verdict'] == 'PASS_EXPECTED_ABSENT' else row['exit_code'] == 0
    assert hashlib.sha256((folder / row['log']).read_bytes()).hexdigest() == row['sha256']
assert job['relocation']['original_absent']
assert job['relocation'].get('Hyle_metadata_no_source_build_staging_paths', job['relocation'].get('Hyle_metadata_no_source_build_staging_paths'))
host = 'windows' if 'compiler' in job else job['host']
name = 'foundation-f3-sdk-' + host + '-' + job['profile'] + '-' + job['mode'] + '-' + job['candidate'][:9]
out = repo / 'evidence/correctness' / name; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for path in sorted(folder.iterdir()):
        if path.is_file(): packed.writestr(path.name, path.read_bytes())
    packed.writestr('workflow/seal_sdk_cell.py', Path(__file__).read_bytes())
    runner = repo / '.scratch/foundation-f3' / ('run_sdk_windows.py' if host == 'windows' else 'run_sdk_posix.py')
    packed.writestr('workflow/' + runner.name, runner.read_bytes())
receipt = {'schema_version': 1, 'candidate': job['candidate'],
    'product_commit': job.get('product_commit', job['candidate']), 'host': host, 'profile': job['profile'], 'mode': job['mode'],
    'scope': job['scope'], 'relocation': job['relocation'], 'header_scope': job['header_scope'],
    'absent_headers_and_route_diagnostics': job['absent_headers_and_route_diagnostics'],
    'runtime_dlls': job.get('runtime_dlls'), 'actual_dyld': job.get('actual_dyld'), 'identity': job.get('identity', job.get('compiler')),
    'gpu_math': job.get('gpu_math', 'Actual named ordinary consumers ran; see terminal stages.'),
    'device_qualification': job.get('device_qualification'),
    'stages': [{'name': row['name'], 'verdict': row['verdict']} for row in job['stages']],
    'original_failures': 'All earlier setup/validation/product failures retained in previous F3 receipts; this one SDK cell does not replace them.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': job['verdict'], 'limits': 'Only the named host/profile/linkage/ordinary consumers/changed headers. Other deliveries and final closure remain unproven.'}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print(name)
