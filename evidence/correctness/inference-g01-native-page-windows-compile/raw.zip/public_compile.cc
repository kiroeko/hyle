#include <hyle/compute/vulkan_batch.h>
#include <hyle/compute/vulkan_memory.h>
#include <hyle/compute/batch_paged_native.h>
#include <type_traits>
namespace c=hyle::compute;namespace n=c::vulkan;
static_assert(std::is_move_constructible_v<n::PagedBatchInvocation>);
static_assert(!std::is_copy_constructible_v<n::PagedBatchInvocation>);
hyle::Status public_calls(const n::Context& context,const n::MemoryResource& device,
 const n::MemoryResource& staging,c::BatchSchema schema,c::BatchLayoutVersion layout,
 c::ReadLease query,c::PagedArenaRead keys,c::PagedArenaRead values){
 HYLE_ASSIGN_OR_RETURN(auto recipe,c::NativePagedBatchProgram::prepare(schema,{.max_host_metadata_bytes=1048576}));
 HYLE_ASSIGN_OR_RETURN(auto version,recipe.version(layout));
 HYLE_ASSIGN_OR_RETURN(auto indices,version.indices());
 HYLE_ASSIGN_OR_RETURN(auto slot,n::PagedBatchInvocation::create(context,recipe,device,staging,{.max_metadata_backing_bytes=1048576}));
 HYLE_RETURN_IF_ERROR(slot.prepare_batch(layout));
 HYLE_RETURN_IF_ERROR(slot.bind(query,keys,values));
 HYLE_ASSIGN_OR_RETURN(auto submission,slot.submit());
 HYLE_ASSIGN_OR_RETURN(auto result,submission.wait());
 const auto report=slot.report();(void)report;(void)indices;(void)result;
 HYLE_RETURN_IF_ERROR(slot.close());return slot.drain();
}
int main(int argc,char**){if(argc>1){n::Context context;n::MemoryResource device,staging;
 return public_calls(context,device,staging,{},{},{},{},{}).ok()?0:1;}return 0;}
