#include <hyle/compute/batch_paged_native.h>
