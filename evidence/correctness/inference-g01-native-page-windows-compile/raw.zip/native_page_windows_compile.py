from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();out=root/'.scratch/inference-gaps/g01/native-paged/windows-compile';out.mkdir(exist_ok=True)
tree=Path('C:/h7/inference-g01-native-vulkan');parent=tree/'parent/CMakeLists.txt';build=tree/'build'
candidate='520027a57ff41da96ac908ad0d35896e2dda9734'
registry=json.loads((root/'docs/implementation/module-status.json').read_bytes())
assert next(r for r in registry['modules'] if r['module']=='compute_route_vulkan')['candidate']==candidate
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key,value=line.split('=',1);env[key]=value
source=out/'public_compile.cc'
source.write_bytes(b'''#include <hyle/compute/vulkan_batch.h>
#include <hyle/compute/vulkan_memory.h>
#include <hyle/compute/batch_paged_native.h>
#include <type_traits>
namespace c=hyle::compute;namespace n=c::vulkan;
static_assert(std::is_move_constructible_v<n::PagedBatchInvocation>);
static_assert(!std::is_copy_constructible_v<n::PagedBatchInvocation>);
hyle::Status public_calls(const n::Context& context,const n::MemoryResource& device,
 const n::MemoryResource& staging,c::BatchSchema schema,c::BatchLayoutVersion layout,
 c::ReadLease query,c::PagedArenaRead keys,c::PagedArenaRead values){
 HYLE_ASSIGN_OR_RETURN(auto recipe,c::NativePagedBatchProgram::prepare(schema,{.max_host_metadata_bytes=1048576}));
 HYLE_ASSIGN_OR_RETURN(auto version,recipe.version(layout));
 HYLE_ASSIGN_OR_RETURN(auto indices,version.indices());
 HYLE_ASSIGN_OR_RETURN(auto slot,n::PagedBatchInvocation::create(context,recipe,device,staging,{.max_metadata_backing_bytes=1048576}));
 HYLE_RETURN_IF_ERROR(slot.prepare_batch(layout));
 HYLE_RETURN_IF_ERROR(slot.bind(query,keys,values));
 HYLE_ASSIGN_OR_RETURN(auto submission,slot.submit());
 HYLE_ASSIGN_OR_RETURN(auto result,submission.wait());
 const auto report=slot.report();(void)report;(void)indices;(void)result;
 HYLE_RETURN_IF_ERROR(slot.close());return slot.drain();
}
int main(int argc,char**){if(argc>1){n::Context context;n::MemoryResource device,staging;
 return public_calls(context,device,staging,{},{},{},{},{}).ok()?0:1;}return 0;}
''')
headers=[]
for i,name in enumerate(['hyle/compute/batch_paged_native.h','hyle/compute/vulkan_batch.h','hyle/compute/detail/materialized_native_controller.h']):
    path=out/f'header-{i}.cc';path.write_bytes(('#include <'+name+'>\n').encode());headers.append(path)
body=parent.read_bytes();target='native_page_public_compile'
if ('add_executable('+target+' ').encode() not in body:
    sources=' '.join('"'+p.as_posix()+'"' for p in [source,*headers])
    addition=f'\nadd_executable({target} {sources})\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE /W4 /WX /wd4324 /utf-8)\ntarget_link_libraries({target} PRIVATE hyle::compute)\nhyle_stage_runtime({target})\n'
    parent.write_bytes(body+addition.encode())
record=out/'result.json';rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
attempt=1+len(rows);log=out/f'build-{attempt}.log';start=time.monotonic()
command=['cmake','--build',str(build),'--target',target,'--parallel','4']
with log.open('w',encoding='utf-8') as stream:r=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
rows.append({'stage':'build-public-link-headers','command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)})
inputs=[]
for name in ['cmake/HyleDependencyLock.json','third_party/ggml_vulkan_runtime/patches.json','include/hyle/compute/batch_paged_native.h','include/hyle/compute/vulkan_batch.h','include/hyle/compute/detail/materialized_native_controller.h','src/compute_batch/batch_paged_native.cc','src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_materialized_invocation.cc','src/compute_provider_ggml_vulkan/region.cc']:
    data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',candidate+':'+name]),name
    inputs.append({'path':name,'sha256':hashlib.sha256(data).hexdigest()})
receipt={'candidate':candidate,'scope':'Windows actual affected native page library/public linkage and three standalone headers, no executable/GPU/math run; original cached source tree and fourjobs',
 'inputs':inputs,'stages':rows,'cumulative_seconds':sum(row['elapsed_seconds'] for row in rows)}
record.write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps(receipt),flush=True)
with log.open('rb') as stream:stream.seek(max(0,log.stat().st_size-2500));print(stream.read().decode(errors='replace'))
raise SystemExit(r.returncode)
