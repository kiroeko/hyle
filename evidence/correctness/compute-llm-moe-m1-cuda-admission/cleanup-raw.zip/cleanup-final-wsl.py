from pathlib import Path
import hashlib
import json
import shutil

task = Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission')
archive = task.parents[2] / 'evidence/correctness/compute-llm-moe-m1-cuda-admission/final-native-host-sanitizers-raw.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'dbe44e6d9183dddda56dc803aa3362577f08cd7d3c045750d6a0b5fcc4aa56cd'
report = []
for name in ('/root/hyle-m1c-ggml-build', '/root/hyle-m1c-ggml-source', '/root/hyle-m1c-cuda-init-asan'):
    path = Path(name)
    assert path.resolve() == path and not path.is_symlink()
    if path.is_dir():
        size = sum(p.stat().st_size for p in path.rglob('*') if p.is_file())
        shutil.rmtree(path)
        digest = None
    else:
        assert path.is_file()
        size = path.stat().st_size
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        path.unlink()
    report.append({'path': name, 'logical_bytes': size, 'removed': not path.exists(), 'file_sha256': digest})
(task / 'cleanup-final-wsl.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
