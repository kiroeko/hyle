from pathlib import Path
import hashlib
import json
import shutil

task = Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission')
evidence = task.parents[2] / 'evidence/correctness/compute-llm-moe-m1-cuda-admission/ggml-wsl-sdk-raw.zip'
digest = 'a77d0be7c8550cecaf8c4f91de16f2bc9ec1deeafd4fa96e63d4911e8d0161c7'
assert hashlib.sha256(evidence.read_bytes()).hexdigest() == digest
assert json.loads((task / 'ggml-delivery-wsl/receipt.json').read_text())['status'] == 'PASS'
active = Path('/root/hyle-m1c-ggml-build/build.ninja').read_text()
report = []
for name in ('/root/hyle-m1c-sdk', '/root/hyle-m1c-source'):
    path = Path(name)
    assert path.resolve() == path and not path.is_symlink() and path.is_dir()
    assert name not in active, 'Active build still references ' + name
    size = sum(p.stat().st_size for p in path.rglob('*') if p.is_file())
    shutil.rmtree(path)
    report.append({'path': name, 'logical_bytes': size, 'removed': not path.exists()})
result = {'evidence_sha256': digest, 'removed': report}
(task / 'cleanup-finished-wsl-sdk.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
