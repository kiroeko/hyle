$ErrorActionPreference = 'Stop'
$m1cTask = 'C:\public\project-hyle\hyle\.scratch\validation\m1-cuda-admission'
$m1cEvidence = 'C:\public\project-hyle\hyle\evidence\correctness\compute-llm-moe-m1-cuda-admission'
if ((Get-FileHash -LiteralPath (Join-Path $m1cEvidence 'final-native-host-sanitizers-raw.zip') -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'dbe44e6d9183dddda56dc803aa3362577f08cd7d3c045750d6a0b5fcc4aa56cd') { throw 'Final evidence identity differs' }
if (-not (Test-Path -LiteralPath (Join-Path $m1cEvidence 'q-cuda-api-raw.zip') -PathType Leaf)) { throw 'Qualification archive missing' }
$m1cReport = @()
foreach ($m1cExpected in @('C:\hyle-scratch\m1cg', 'C:\hyle-scratch\m1c-qapi', 'C:\hyle-scratch\m1c-fi-full')) {
  $m1cResolved = (Resolve-Path -LiteralPath $m1cExpected).Path
  if ($m1cResolved -cne $m1cExpected) { throw "Unexpected cleanup target: $m1cResolved" }
  if ((Get-Item -LiteralPath $m1cResolved).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Refusing redirected cleanup root' }
  $m1cBytes = (Get-ChildItem -LiteralPath $m1cResolved -Recurse -File | Measure-Object Length -Sum).Sum
  Remove-Item -LiteralPath $m1cResolved -Recurse -Force
  $m1cReport += @{ path = $m1cResolved; logical_bytes = $m1cBytes; removed = -not (Test-Path -LiteralPath $m1cResolved) }
}
$m1cReport | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $m1cTask 'cleanup-final-windows.json')
$m1cReport | ConvertTo-Json
