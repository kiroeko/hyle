from pathlib import Path
import json
import shutil
import sys

root = Path('/Users/kiro/hyle-m1c-verify')
assert root.resolve() == root and not root.is_symlink()
label = sys.argv[1]
assert label in ('air', 'mini')
for mode in ('off', 'gqa'):
    text = (root / 'logs' / (label + '-' + mode + '-tests.log')).read_text()
    assert '100% tests passed' in text and '***Failed' not in text
assert (root / (label + '-logs.tar.gz')).is_file()
total = sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
shutil.rmtree(root)
print(json.dumps({'machine': label, 'path': str(root), 'logical_bytes': total,
                  'removed': not root.exists(),
                  'canonical_evidence_sha256': '92d1ff4df64699bd29bfb6ce4c8a30f634d6b4fa751f9b94d02a47277815282d'}))
