$ErrorActionPreference = 'Stop'
$m1cExpected = 'C:\hyle-scratch\m1cs'
$m1cTask = 'C:\public\project-hyle\hyle\.scratch\validation\m1-cuda-admission'
$m1cArchive = 'C:\public\project-hyle\hyle\evidence\correctness\compute-llm-moe-m1-cuda-admission\ggml-windows-sdk-raw.zip'
if ((Get-FileHash -LiteralPath $m1cArchive -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'd2ecf5179fe95a07288b34a622f61b5824939df70e9ee162b90f6b1b19f86004') { throw 'SDK evidence identity differs' }
if ((Get-Content -LiteralPath (Join-Path $m1cTask 'ggml-delivery-windows\fixed-receipt.json') -Raw | ConvertFrom-Json).status -ne 'PASS') { throw 'SDK work is not finished' }
if (Get-Process -Name m1c_attention -ErrorAction SilentlyContinue) { throw 'An SDK consumer is still running' }
$m1cResolved = (Resolve-Path -LiteralPath $m1cExpected).Path
if ($m1cResolved -cne $m1cExpected) { throw 'Unexpected cleanup target' }
if ((Get-Item -LiteralPath $m1cResolved).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Refusing a redirected cleanup root' }
$m1cBytes = (Get-ChildItem -LiteralPath $m1cResolved -Recurse -File | Measure-Object Length -Sum).Sum
Remove-Item -LiteralPath $m1cResolved -Recurse -Force
$m1cResult = @{ target = $m1cResolved; logical_bytes = $m1cBytes; removed = -not (Test-Path -LiteralPath $m1cResolved); evidence_sha256 = 'd2ecf5179fe95a07288b34a622f61b5824939df70e9ee162b90f6b1b19f86004' }
$m1cResult | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $m1cTask 'cleanup-finished-windows-sdk.json')
$m1cResult | ConvertTo-Json
