from pathlib import Path
import hashlib
import json
import subprocess

task = Path(__file__).resolve().parent
root = task.parents[2]
candidate = '43732241adf81ad2bad9f64594e72d752b900b37'
subprocess.run(['git', 'diff', '--exit-code', candidate, '--', 'src', 'include', 'cmake', 'third_party'],
               cwd=root, check=True, stdout=subprocess.PIPE)
prefixes = ('src/', 'include/', 'cmake/', 'third_party/')
checks = {}
for label, filename in (
    ('windows_sdk', 'ggml-delivery-windows/fixed-source-manifest.json'),
    ('wsl_sanitizers', 'ggml-sanitizer-source-manifest.json')):
    manifest = json.loads((task / filename).read_text())
    checked = 0
    for name, digest in manifest['files'].items():
        if name.startswith(prefixes):
            assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, (label, name)
            checked += 1
    checks[label] = {'product_files_identical': checked, 'manifest': filename}
manifest = json.loads((task / 'ggml-delivery-wsl/source-manifest.json').read_text())
exceptions = {'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc', 'src/compute_route_cuda/CMakeLists.txt'}
checked = 0
for name, digest in manifest['files'].items():
    if not name.startswith(prefixes):
        continue
    current = (root / name).read_bytes()
    if name not in exceptions:
        assert hashlib.sha256(current).hexdigest() == digest, name
        checked += 1
        continue
    if name.endswith('ggml_cuda_provider.cc'):
        text = current.decode()
        start = text.index('#if defined(_WIN32)\n    // This DLL embeds its own ggml copy.')
        end = text.index('#endif\n', start) + len('#endif\n')
        current = (text[:start] + text[end:]).encode()
    else:
        text = current.decode()
        start = text.index('  if(HYLE_STATIC AND NOT CMAKE_SYSTEM_NAME STREQUAL "Linux")')
        end = text.index('  endif()\n', start) + len('  endif()\n')
        current = (text[:start] + text[end:]).encode()
    assert hashlib.sha256(current).hexdigest() == digest, name
checks['wsl_sdk'] = {'product_files_identical': checked, 'false_on_linux_only_changes': sorted(exceptions),
                     'proof': 'removing exactly the two Windows-only conditional additions reproduces the original source hashes'}
report = {'candidate': candidate, 'checks': checks}
(task / 'candidate-evidence-match.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
