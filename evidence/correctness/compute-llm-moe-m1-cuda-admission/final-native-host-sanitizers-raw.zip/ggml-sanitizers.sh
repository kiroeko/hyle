#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
source=/root/hyle-m1c-ggml-source
build=/root/hyle-m1c-ggml-build
tar -xzf "$task/product-worktree.tar.gz" -C "$source"
cp "$task/product-worktree-manifest.json" "$task/ggml-sanitizer-source-manifest.json"
for mode in "$@"; do
  case "$mode" in asan|ubsan) ;; *) exit 2 ;; esac
  cmake -S "$source" -B "$build" -G Ninja -UHYLE_COMPONENTS \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=/usr/bin/gcc-14 -DCMAKE_CXX_COMPILER=/usr/bin/g++-14 \
    -DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14 \
    -DCMAKE_CUDA_ARCHITECTURES=89-real -DHYLE_DEV_FACTORS=compute_ggml_runtime,compute_provider_ggml_cuda,graph_provider_ggml_cuda \
    -DHYLE_SANITIZER="$mode" -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF \
    -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=ON \
    -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_ONEDNN=OFF \
    > "$task/ggml-$mode-configure.log" 2>&1
  cmake --build "$build" --parallel 2 --target hyle_compute_ggml_runtime_tests \
    hyle_compute_provider_ggml_cuda_tests hyle_graph_provider_ggml_cuda_tests \
    > "$task/ggml-$mode-build.log" 2>&1
  if test "$mode" = asan; then
    export ASAN_OPTIONS=protect_shadow_gap=0:detect_leaks=1:halt_on_error=1
    export LSAN_OPTIONS="suppressions=$task/wsl-driver-lsan.supp:print_suppressions=1"
    /root/hyle-m1c-cuda-init-asan > "$task/ggml-asan-driver-control.log" 2>&1
  fi
  export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
  set +e
  ctest --test-dir "$build" -L '^(compute_ggml_runtime|compute_provider_ggml_cuda|graph_provider_ggml_cuda)$' -LE headers \
    --output-on-failure --no-tests=error --timeout 120 > "$task/ggml-$mode-tests.log" 2>&1
  result=$?
  set -e
  cp "$build/Testing/Temporary/LastTest.log" "$task/ggml-$mode-LastTest.log"
  cp "$build/CMakeCache.txt" "$task/ggml-$mode-CMakeCache.txt"
  sha256sum "$build/bin/hyle_compute_ggml_runtime_cuda_test" "$build/bin/hyle_compute_provider_ggml_cuda_test" \
    "$build/bin/hyle_graph_provider_ggml_cuda_test" > "$task/ggml-$mode-binary-sha256.log"
  cat "$task/ggml-$mode-tests.log"
  if test "$result" != 0; then exit "$result"; fi
done
