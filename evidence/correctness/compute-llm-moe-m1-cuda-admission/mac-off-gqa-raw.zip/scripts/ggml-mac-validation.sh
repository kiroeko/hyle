#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1c-verify
source="$task/source"
label="$1"
cmake="$2"
export PATH="$(dirname "$cmake"):/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
mkdir -p "$source" "$task/logs"
tar -xzf "$task/source.tar.gz" -C "$source"
common=(-G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON
        -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON
        -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=OFF
        -DHYLE_COMPUTE_ONEDNN=OFF -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4)
"$cmake" -S "$source" -B "$task/off" "${common[@]}" -DHYLE_COMPUTE_CPU=OFF \
  -DHYLE_DEV_FACTORS=compute_provider_ggml_cuda,graph_provider_ggml_cuda,compute_provider_flashinfer \
  > "$task/logs/$label-off-configure.log" 2>&1
python3 - "$task/off/CMakeCache.txt" > "$task/logs/$label-off-cache-proof.log" <<'PY'
from pathlib import Path
import re, sys
cache = Path(sys.argv[1]).read_text()
for key in ('CMAKE_CUDA_COMPILER', 'ggml_SOURCE_DIR', 'flashinfer_SOURCE_DIR'):
    assert not re.search(r'^' + key + r':', cache, re.M), key
print('PASS: no CUDA compiler discovery or ggml/FlashInfer source acquisition in all-route-OFF closure')
PY
"$cmake" --build "$task/off" --parallel 2 --target hyle_compute_provider_ggml_cuda_tests \
  hyle_graph_provider_ggml_cuda_tests hyle_compute_provider_flashinfer_tests \
  > "$task/logs/$label-off-build.log" 2>&1
ctest --test-dir "$task/off" -L '^(compute_provider_ggml_cuda|graph_provider_ggml_cuda|compute_provider_flashinfer)$' \
  --output-on-failure --no-tests=error --timeout 120 > "$task/logs/$label-off-tests.log" 2>&1
cp "$task/off/Testing/Temporary/LastTest.log" "$task/logs/$label-off-LastTest.log"
"$cmake" -S "$source" -B "$task/gqa" "${common[@]}" -DHYLE_COMPUTE_CPU=ON \
  -DHYLE_DEV_FACTORS=compute_ops,compute_provider_native \
  > "$task/logs/$label-gqa-configure.log" 2>&1
"$cmake" --build "$task/gqa" --parallel 2 --target hyle_compute_ops_tests hyle_compute_provider_native_tests \
  > "$task/logs/$label-gqa-build.log" 2>&1
ctest --test-dir "$task/gqa" -L '^(compute_ops|compute_provider_native)$' \
  --output-on-failure --no-tests=error --timeout 120 > "$task/logs/$label-gqa-tests.log" 2>&1
cp "$task/gqa/Testing/Temporary/LastTest.log" "$task/logs/$label-gqa-LastTest.log"
cp "$task/off/CMakeCache.txt" "$task/logs/$label-off-cache.txt"
cp "$task/gqa/CMakeCache.txt" "$task/logs/$label-gqa-cache.txt"
shasum -a 256 "$task/gqa/bin/hyle_compute_ops_test" "$task/gqa/bin/hyle_compute_provider_native_test" \
  > "$task/logs/$label-binary-sha256.log"
tar -czf "$task/$label-logs.tar.gz" -C "$task/logs" .
cat "$task/logs/$label-off-cache-proof.log" "$task/logs/$label-off-tests.log" "$task/logs/$label-gqa-tests.log"
