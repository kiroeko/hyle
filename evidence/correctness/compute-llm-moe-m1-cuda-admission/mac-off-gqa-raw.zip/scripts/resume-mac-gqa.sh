#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1c-verify
label="$1"
cmake="$2"
export PATH="$(dirname "$cmake"):/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
tar -xzf "$task/source.tar.gz" -C "$task/source"
"$cmake" --build "$task/gqa" --parallel 2 --target hyle_compute_ops_tests hyle_compute_provider_native_tests \
  > "$task/logs/$label-gqa-build.log" 2>&1
ctest --test-dir "$task/gqa" -L '^(compute_ops|compute_provider_native)$' \
  --output-on-failure --no-tests=error --timeout 120 > "$task/logs/$label-gqa-tests.log" 2>&1
cp "$task/gqa/Testing/Temporary/LastTest.log" "$task/logs/$label-gqa-LastTest.log"
cp "$task/off/CMakeCache.txt" "$task/logs/$label-off-cache.txt"
cp "$task/gqa/CMakeCache.txt" "$task/logs/$label-gqa-cache.txt"
cp "$task/product-worktree-manifest.json" "$task/logs/final-source-manifest.json"
shasum -a 256 "$task/gqa/bin/hyle_compute_ops_test" "$task/gqa/bin/hyle_compute_provider_native_test" \
  > "$task/logs/$label-binary-sha256.log"
tar -czf "$task/$label-logs.tar.gz" -C "$task/logs" .
cat "$task/logs/$label-off-cache-proof.log" "$task/logs/$label-off-tests.log" "$task/logs/$label-gqa-tests.log"
