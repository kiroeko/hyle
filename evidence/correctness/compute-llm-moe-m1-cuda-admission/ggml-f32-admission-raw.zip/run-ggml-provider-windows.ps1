$ErrorActionPreference = 'Stop'
$m1cRoot = 'C:\public\project-hyle\hyle'
$m1cBuild = 'C:\hyle-scratch\m1cg'
$m1cLogs = Join-Path $m1cRoot '.scratch\validation\m1-cuda-admission'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1cGgmlErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1cGgmlErrorMode]::SetErrorMode(0x8003)
. (Join-Path $m1cRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'compute_route_cuda,graph_route_cuda' -BinaryDir $m1cBuild -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=ON','-DCMAKE_CUDA_ARCHITECTURES=89-real','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=ON','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') > (Join-Path $m1cLogs 'ggml-provider-windows-configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& cmake --build $m1cBuild --parallel 2 --target hyle_compute_provider_ggml_cuda_tests hyle_graph_provider_ggml_cuda_tests hyle_compute_route_cuda_tests hyle_graph_route_cuda_tests > (Join-Path $m1cLogs 'ggml-provider-windows-build.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$m1cBin = Join-Path $m1cBuild 'bin'
foreach ($m1cDll in Get-ChildItem -LiteralPath $m1cBuild -Recurse -File -Filter '*.dll') {
  $m1cDestination = Join-Path $m1cBin $m1cDll.Name
  if ($m1cDll.FullName -ne $m1cDestination) {
    Copy-Item -LiteralPath $m1cDll.FullName -Destination $m1cDestination -Force
  }
}
$m1cCuda = 'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin'
foreach ($m1cName in @('cudart64_13.dll', 'cublas64_13.dll', 'cublasLt64_13.dll')) {
  $m1cDll = Get-ChildItem -LiteralPath $m1cCuda -Recurse -File -Filter $m1cName | Select-Object -First 1
  if (-not $m1cDll) { throw "CUDA runtime missing: $m1cName" }
  Copy-Item -LiteralPath $m1cDll.FullName -Destination (Join-Path $m1cBin $m1cName) -Force
}
& ctest --test-dir $m1cBuild -L '^(compute_provider_ggml_cuda|graph_provider_ggml_cuda|compute_route_cuda|graph_route_cuda)$' --output-on-failure --no-tests=error --timeout 60 > (Join-Path $m1cLogs 'ggml-provider-windows-tests.log') 2>&1
$m1cExit = $LASTEXITCODE
Copy-Item -LiteralPath (Join-Path $m1cBuild 'Testing\Temporary\LastTest.log') -Destination (Join-Path $m1cLogs 'ggml-provider-windows-LastTest.log') -Force
exit $m1cExit
