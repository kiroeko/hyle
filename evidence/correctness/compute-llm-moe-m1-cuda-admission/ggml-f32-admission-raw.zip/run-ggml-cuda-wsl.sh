#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
source=/root/hyle-m1c-ggml-source
build=/root/hyle-m1c-ggml-build
mkdir -p "$source"
tar -xzf "$task/product-worktree.tar.gz" -C "$source"
cmake -S "$source" -B "$build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=/usr/bin/gcc-14 -DCMAKE_CXX_COMPILER=/usr/bin/g++-14 \
  -DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14 \
  -DCMAKE_CUDA_ARCHITECTURES=89-real -DHYLE_DEV_FACTORS=compute_ggml_runtime,compute_backend_cuda \
  -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON \
  -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=OFF \
  -DHYLE_COMPUTE_ONEDNN=OFF > "$task/ggml-cuda-wsl-configure.log" 2>&1
cmake --build "$build" --parallel 2 --target hyle_compute_ggml_runtime_cuda_test \
  > "$task/ggml-cuda-wsl-build.log" 2>&1
ctest --test-dir "$build" -R '^hyle_compute_ggml_runtime_cuda_test$' \
  --output-on-failure --no-tests=error --timeout 60 > "$task/ggml-cuda-wsl-tests.log" 2>&1
cp "$build/Testing/Temporary/LastTest.log" "$task/ggml-cuda-wsl-LastTest.log"
cat "$task/ggml-cuda-wsl-tests.log"
