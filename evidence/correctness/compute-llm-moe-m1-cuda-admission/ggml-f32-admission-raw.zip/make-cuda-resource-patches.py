import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parents[3]
peer = root.parent / 'ggml'
revision = '456172ec733a135778adcd32d00e576a58232e45'
files = []

def source(path):
    return subprocess.check_output(['git', '-C', str(peer), 'show', revision + ':' + path]).decode()

def clean_checks(text):
    return re.sub(r'\b(?:CUDA_CHECK|CUBLAS_CHECK|CU_CHECK)\((.*)\);', r'(void)(\1);', text)

def patch(path, transform):
    before = source(path)
    data = before
    edits = []
    def edit(old, new):
        nonlocal data
        assert data.count(old) == 1, (path, old[:120], data.count(old))
        data = data.replace(old, new, 1)
        edits.append({'before': old, 'after': new})
    transform(before, edit)
    files.append({'path': path, 'before_sha256': hashlib.sha256(before.encode()).hexdigest(),
                  'after_sha256': hashlib.sha256(data.encode()).hexdigest(), 'edits': edits})

def common(original, edit):
    edit('#define STRINGIZE_IMPL', '#include "native_bridge.h"\n\n#define STRINGIZE_IMPL')
    edit('ggml_cuda_error(#err, __func__, __FILE__, __LINE__, error_fn(err_));',
         'hyle::compute::ggml_cuda::bridge::fail(err_, #err);')
    graph = original[original.index('    ~ggml_cuda_graph() {'):original.index('    cudaGraph_t graph = nullptr;')]
    edit(graph, clean_checks(graph))
    events = original[original.index('    ~ggml_cuda_concurrent_event() {'):original.index('\nstruct ggml_cuda_stream_context')]
    edit(events, clean_checks(events))
    edit('    const ggml_tensor * join_node;', '    const ggml_tensor * join_node = nullptr;')
    ctor = original[original.index('    explicit ggml_cuda_concurrent_event(int'):original.index('    ggml_cuda_concurrent_event(ggml_cuda_concurrent_event &&')]
    edit(ctor, '''    explicit ggml_cuda_concurrent_event(int n_streams) : n_streams(n_streams) {
        join_events.resize(n_streams);
        try {
            for (auto & event : join_events) {
                CUDA_CHECK(cudaEventCreateWithFlags(&event, cudaEventDisableTiming));
            }
            CUDA_CHECK(cudaEventCreateWithFlags(&fork_event, cudaEventDisableTiming));
        } catch (...) {
            for (auto event : join_events) {
                if (event != nullptr) (void) cudaEventDestroy(event);
            }
            if (fork_event != nullptr) (void) cudaEventDestroy(fork_event);
            throw;
        }
    }

''')

def runtime(original, edit):
    clear = original[original.index('    void clear_pool() {'):original.index('    void * alloc(size_t size, size_t * actual_size) override {')]
    replacement = clean_checks(clear).replace('void clear_pool()', 'void clear_pool() noexcept').replace(
        'ggml_cuda_set_device(device);', '(void) cudaSetDevice(ggml_cuda_get_physical_device(device));')
    edit(clear, replacement)
    free_begin = original.index('    void free(void * ptr, size_t size) override {')
    free_end = original.index('\n};', free_begin)
    free = original[free_begin:free_end]
    edit(free, clean_checks(free).replace(' override {', ' noexcept override {').replace(
        'ggml_cuda_set_device(device);', '(void) cudaSetDevice(ggml_cuda_get_physical_device(device));'))
    vmm_dtor = original[original.index('    ~ggml_cuda_pool_vmm() {'):original.index('    void * alloc(size_t size, size_t * actual_size) override {', original.index('    ~ggml_cuda_pool_vmm() {'))]
    edit(vmm_dtor, clean_checks(vmm_dtor).replace('(void)(cuMemUnmap(pool_addr, pool_size));', 'if (pool_size != 0) (void) cuMemUnmap(pool_addr, pool_size);'))
    edit('            GGML_ASSERT(pool_size + reserve_size <= CUDA_POOL_VMM_MAX_SIZE);',
         '            if (reserve_size > CUDA_POOL_VMM_MAX_SIZE - pool_size) throw std::bad_alloc();')
    edit('        const size_t alignment = 128;\n        size = alignment * ((size + alignment - 1) / alignment);',
         '        const size_t alignment = 128;\n        if (size > CUDA_POOL_VMM_MAX_SIZE) throw std::bad_alloc();\n        size = alignment * ((size + alignment - 1) / alignment);')
    edit('''            CUmemGenericAllocationHandle handle;
            CU_CHECK(cuMemCreate(&handle, reserve_size, &prop, 0));''', '''            struct HandleOwner {
                CUmemGenericAllocationHandle value = 0;
                ~HandleOwner() { if (value != 0) (void) cuMemRelease(value); }
            } handle_owner;
            CU_CHECK(cuMemCreate(&handle_owner.value, reserve_size, &prop, 0));
            const auto handle = handle_owner.value;''')
    edit('            CU_CHECK(cuMemMap(start_ptr, reserve_size, 0, handle, 0));', '''            CU_CHECK(cuMemMap(start_ptr, reserve_size, 0, handle, 0));
            struct MappingOwner {
                CUdeviceptr pointer;
                size_t size;
                ~MappingOwner() { if (pointer != 0) (void) cuMemUnmap(pointer, size); }
            } mapping_owner{start_ptr, reserve_size};''')
    edit('            CU_CHECK(cuMemRelease(handle));', '            CU_CHECK(cuMemRelease(handle));\n            handle_owner.value = 0;')
    edit('            pool_size += reserve_size;', '            pool_size += reserve_size;\n            mapping_owner.pointer = 0;')
    begin = original.index('ggml_backend_cuda_context::~ggml_backend_cuda_context() {')
    end = original.index('// cuda buffer', begin)
    edit(original[begin:end], clean_checks(original[begin:end]))
    edit('    void * dev_ptr = nullptr;\n    std::string name;', '    void * dev_ptr = nullptr;\n    bool owns_payload = true;\n    std::string name;')
    edit('''    ~ggml_backend_cuda_buffer_context() {
        CUDA_CHECK(cudaFree(dev_ptr));
    }''', '''    ~ggml_backend_cuda_buffer_context() {
        if (owns_payload && dev_ptr != nullptr) (void) cudaFree(dev_ptr);
    }''')
    begin = original.index('    void * dev_ptr;\n', original.index('static ggml_backend_buffer_t ggml_backend_cuda_buffer_type_alloc_buffer'))
    end = original.index('\n}\n', begin)
    edit(original[begin:end], '''    // Allocate metadata first; both a native failure and a later host allocation
    // failure unwind through the same non-throwing payload owner.
    auto ctx = std::make_unique<ggml_backend_cuda_buffer_context>(buft_ctx->device, nullptr);
    CUDA_CHECK(ggml_cuda_device_malloc(&ctx->dev_ptr, size, buft_ctx->device));
    auto buffer = ggml_backend_buffer_init(buft, ggml_backend_cuda_buffer_interface, ctx.get(), size);
    ctx.release();
    return buffer;''')
    begin = original.index('    ggml_backend_cuda_context * ctx = new ggml_backend_cuda_context(device);', original.index('ggml_backend_t ggml_backend_cuda_init(int device)'))
    end = original.index('\n    return cuda_backend;', begin)
    old = original[begin:end]
    backend = old[old.index('    ggml_backend_t cuda_backend ='):].replace('/* .context = */ ctx,', '/* .context = */ ctx.get(),')
    edit(old, '    auto ctx = std::make_unique<ggml_backend_cuda_context>(device);\n\n' + backend + '\n    ctx.release();\n')
    marker = 'static std::atomic<int> ggml_cuda_lock_counter;'
    edit(marker, marker + '''

// Resource-only capture guard. A failed begin/end/encode must release the
// process-wide capture count and destroy any discarded partial native graph.
struct ggml_hyle_capture_guard {
    cudaStream_t stream = nullptr;
    bool counted = false;
    bool capturing = false;
    void release_count() noexcept {
        if (!counted) return;
        std::lock_guard<std::mutex> lock(ggml_cuda_lock);
        counted = false;
        if (ggml_cuda_lock_counter.fetch_sub(1, std::memory_order_relaxed) == 1)
            ggml_cuda_lock_cv.notify_all();
    }
    void begin(cudaStream_t native_stream) {
        stream = native_stream;
        {
            std::lock_guard<std::mutex> lock(ggml_cuda_lock);
            ggml_cuda_lock_counter.fetch_add(1, std::memory_order_relaxed);
            counted = true;
        }
        CUDA_CHECK(cudaStreamBeginCapture(stream, cudaStreamCaptureModeRelaxed));
        capturing = true;
    }
    void end(cudaGraph_t * graph) {
        const auto status = cudaStreamEndCapture(stream, graph);
        capturing = false;
        release_count();
        CUDA_CHECK(status);
    }
    ~ggml_hyle_capture_guard() {
        if (capturing) {
            cudaGraph_t discarded = nullptr;
            (void) cudaStreamEndCapture(stream, &discarded);
            if (discarded != nullptr) (void) cudaGraphDestroy(discarded);
        }
        release_count();
    }
};
''')
    signature = 'static void ggml_cuda_graph_evaluate_and_capture(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph, const bool use_cuda_graph, const bool cuda_graph_update_required, const void * graph_key) {'
    edit(signature, signature.replace('const void * graph_key)', 'const void * graph_key, [[maybe_unused]] ggml_hyle_capture_guard & capture)'))
    old = '''            CUDA_CHECK(cudaStreamEndCapture(cuda_ctx->stream(), &graph->graph));
            graph_evaluated_or_captured = true; // CUDA graph has been captured

            std::lock_guard<std::mutex> lock(ggml_cuda_lock);
            if (ggml_cuda_lock_counter.fetch_sub(1, std::memory_order_relaxed) == 1) {
                ggml_cuda_lock_cv.notify_all();
            }'''
    edit(old, '''            capture.end(&graph->graph);
            graph_evaluated_or_captured = true; // CUDA graph has been captured''')
    old = '''    if (use_cuda_graph && cuda_graph_update_required) {
        // Start CUDA graph capture
        {
            std::lock_guard<std::mutex> lock(ggml_cuda_lock);
            ggml_cuda_lock_counter.fetch_add(1, std::memory_order_relaxed);
        }

        CUDA_CHECK(cudaStreamBeginCapture(cuda_ctx->stream(), cudaStreamCaptureModeRelaxed));
    }

    ggml_cuda_graph_evaluate_and_capture(cuda_ctx, cgraph, use_cuda_graph, cuda_graph_update_required, graph_key);'''
    edit(old, '''    ggml_hyle_capture_guard capture;
    if (use_cuda_graph && cuda_graph_update_required) {
        capture.begin(cuda_ctx->stream());
    }

    ggml_cuda_graph_evaluate_and_capture(cuda_ctx, cgraph, use_cuda_graph, cuda_graph_update_required, graph_key, capture);''')
    edit('GGML_BACKEND_DL_IMPL(ggml_backend_cuda_reg)', '#include "native_bridge_impl.h"\n\nGGML_BACKEND_DL_IMPL(ggml_backend_cuda_reg)')

patch('src/ggml-cuda/common.cuh', common)
patch('src/ggml-cuda/ggml-cuda.cu', runtime)
path = root / 'third_party/ggml_cuda_runtime/patches.json'
path.parent.mkdir(exist_ok=True)
path.write_text(json.dumps({'upstream_revision': revision, 'files': files}, indent=2) + '\n', newline='\n')
print(path, len(files), sum(len(p['edits']) for p in files))
