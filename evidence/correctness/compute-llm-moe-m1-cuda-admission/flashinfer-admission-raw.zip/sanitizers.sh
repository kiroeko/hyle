#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
source=/root/hyle-m1c-source
modes=("$@")
if test ${#modes[@]} -eq 0; then modes=(asan ubsan); fi
for mode in "${modes[@]}"; do
  build=/root/hyle-m1c-$mode
  cpu=ON
  factors=compute_provider_flashinfer,compute_ops,compute_provider_native
  targets=(hyle_compute_provider_flashinfer_tests hyle_compute_ops_tests hyle_compute_provider_native_tests)
  if test "$mode" = ubsan; then
    # Changed public shape arithmetic and the new CUDA host adapter. The native
    # CPU change only declines the new domain; its full suite has passed ASan.
    cpu=OFF
    factors=compute_provider_flashinfer,compute_ops
    targets=(hyle_compute_provider_flashinfer_tests hyle_compute_ops_tests)
  fi
  cmake -S "$source" -B "$build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=/usr/bin/gcc-14 -DCMAKE_CXX_COMPILER=/usr/bin/g++-14 \
    -DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14 \
    -DCMAKE_CUDA_ARCHITECTURES=89 -DHYLE_DEV_FACTORS="$factors" \
    -DHYLE_SANITIZER="$mode" -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF \
    -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON -DHYLE_COMPUTE_CPU="$cpu" -DHYLE_COMPUTE_CUDA=ON \
    -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_ONEDNN=OFF \
    > "$task/$mode-configure.log" 2>&1
  cmake --build "$build" --parallel 2 --target "${targets[@]}" \
    > "$task/$mode-build.log" 2>&1
  ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
    ctest --test-dir "$build" -L '^(compute_provider_flashinfer|compute_ops|compute_provider_native)$' -LE headers \
      --output-on-failure --no-tests=error --timeout 120 > "$task/$mode-tests.log" 2>&1
  cp "$build/Testing/Temporary/LastTest.log" "$task/$mode-LastTest.log"
  cp "$build/CMakeCache.txt" "$task/$mode-CMakeCache.txt"
  cat "$task/$mode-tests.log"
done
