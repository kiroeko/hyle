#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
export ASAN_OPTIONS=protect_shadow_gap=0:detect_leaks=1:halt_on_error=1
export LSAN_OPTIONS="suppressions=$task/wsl-driver-lsan.supp:print_suppressions=1"
/root/hyle-m1c-cuda-init-asan > "$task/cuda-init-asan-qualified.log" 2>&1
ctest --test-dir /root/hyle-m1c-asan -R '^hyle_compute_provider_flashinfer_test$' \
  --output-on-failure --no-tests=error --timeout 120 > "$task/asan-qualified-tests.log" 2>&1
cp /root/hyle-m1c-asan/Testing/Temporary/LastTest.log "$task/asan-qualified-LastTest.log"
cat "$task/cuda-init-asan-qualified.log" "$task/asan-qualified-tests.log"
