"""M1-C admission consumer; only disposable WSL copies are moved/removed."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

task = Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission')
source = Path('/root/hyle-m1c-source')
static_build = Path('/root/hyle-m1c-build')
root = Path('/root/hyle-m1c-sdk')
root.mkdir(exist_ok=True)
logs = task / 'delivery-logs'
logs.mkdir(exist_ok=True)
snapshot = json.loads((task / 'product-worktree-manifest.json').read_text())
report = {'candidate': snapshot['base'], 'status': 'RUNNING', 'commands': []}
environment = dict(os.environ, PATH='/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin', CMAKE_BUILD_PARALLEL_LEVEL='2', TRACY_ONLY_LOCALHOST='1')
record = logs / 'receipt.json'

def save():
    record.write_text(json.dumps(report, indent=2) + '\n')

def run(name, command):
    print('RUN ' + name, flush=True)
    with (logs / (name + '.log')).open('wb') as out:
        result = subprocess.run([str(a) for a in command], stdout=out, stderr=subprocess.STDOUT, env=environment)
    report['commands'].append({'name': name, 'argv': [str(a) for a in command], 'exit_code': result.returncode,
                               'sha256': hashlib.sha256((logs / (name + '.log')).read_bytes()).hexdigest()})
    save()
    if result.returncode:
        print((logs / (name + '.log')).read_text(errors='replace')[-7000:], flush=True)
        raise RuntimeError(name)

consumer = root / 'consumer'
(consumer / 'tests/graph_route_cuda').mkdir(parents=True, exist_ok=True)
(consumer / 'tests/compute_provider_flashinfer').mkdir(parents=True, exist_ok=True)
for name in ('tests/graph_route_cuda/attention_test.cc', 'tests/compute_provider_flashinfer/attention_test_support.h'):
    shutil.copy2(source / name, consumer / name)
gtest = next(Path('/root/.cache/hyle/dependencies/v1/sources').glob('googletest-063de7e9578f-*'))
(consumer / 'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(m1c_attention_consumer LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(M1C_SOURCE)
  set(HYLE_COMPONENTS graph)
  set(HYLE_BUILD_TESTS OFF)
  set(HYLE_BUILD_BENCH OFF)
  set(HYLE_INSTALL ON)
  set(HYLE_STATIC OFF)
  add_subdirectory("${M1C_SOURCE}" hyle)
else()
  find_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)
endif()
set(INSTALL_GTEST OFF)
add_subdirectory("''' + str(gtest) + '''" googletest EXCLUDE_FROM_ALL)
add_executable(m1c_attention tests/graph_route_cuda/attention_test.cc)
target_link_libraries(m1c_attention PRIVATE hyle::graph GTest::gtest_main)
hyle_stage_runtime_dependencies(m1c_attention)
enable_testing()
add_test(NAME m1c_attention COMMAND m1c_attention)
''')
flags = ['-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_C_COMPILER=/usr/bin/gcc-14', '-DCMAKE_CXX_COMPILER=/usr/bin/g++-14',
         '-DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc', '-DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14',
         '-DCMAKE_CUDA_ARCHITECTURES=89', '-DHYLE_WERROR=ON', '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=ON',
         '-DHYLE_COMPUTE_VULKAN=OFF', '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_COMPUTE_ONEDNN=OFF']

def consume(linkage, producer, prefix):
    relocated = root / (linkage + '-relocated')
    assert not relocated.exists()
    prefix.rename(relocated)
    hidden_source = source.with_name(source.name + '-hidden')
    hidden_build = producer.with_name(producer.name + '-hidden')
    assert not hidden_source.exists() and not hidden_build.exists()
    source.rename(hidden_source)
    producer.rename(hidden_build)
    try:
        build = root / (linkage + '-consumer')
        run(linkage + '-consumer-configure', ['cmake', '-S', consumer, '-B', build, '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=/usr/bin/g++-14', '-DCMAKE_PREFIX_PATH=' + str(relocated)])
        run(linkage + '-consumer-build', ['cmake', '--build', build, '--parallel', '2'])
        run(linkage + '-consumer-test', ['ctest', '--test-dir', build, '--output-on-failure', '--timeout', '120'])
    finally:
        hidden_build.rename(producer)
        hidden_source.rename(source)

try:
    # Reuse the exact static objects already exercised by native correctness.
    prefix = root / 'static-prefix'
    run('static-configure', ['cmake', '-S', source, '-B', static_build, '-G', 'Ninja', '-UHYLE_DEV_FACTORS',
        '-DHYLE_COMPONENTS=graph', '-DHYLE_INSTALL=ON', '-DHYLE_STATIC=ON', '-DHYLE_BUILD_TESTS=OFF',
        '-DHYLE_BUILD_BENCH=OFF', '-DCMAKE_INSTALL_PREFIX=' + str(prefix)] + flags)
    run('static-build', ['cmake', '--build', static_build, '--parallel', '2'])
    run('static-install', ['cmake', '--install', static_build])
    consume('static', static_build, prefix)

    # One shared source-embedding producer also supplies the shared SDK; no
    # redundant recompilation of the same third-party objects for two journeys.
    build = root / 'source-build'
    prefix = root / 'shared-prefix'
    run('source-configure', ['cmake', '-S', consumer, '-B', build, '-G', 'Ninja',
        '-DM1C_SOURCE=' + str(source), '-DCMAKE_INSTALL_PREFIX=' + str(prefix)] + flags)
    run('source-build', ['cmake', '--build', build, '--parallel', '2'])
    run('source-test', ['ctest', '--test-dir', build, '--output-on-failure', '--timeout', '120'])
    run('shared-install', ['cmake', '--install', build / 'hyle'])
    consume('shared', build, prefix)
    report['status'] = 'PASS'
except Exception:
    report['status'] = 'FAIL'
    raise
finally:
    save()
