#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
source=/root/hyle-m1c-source
build=/root/hyle-m1c-sdk/source-build
prefix=/root/hyle-m1c-sdk/shared-relocated
tar -xzf "$task/product-worktree.tar.gz" -C "$source"
cmake --build "$build" --parallel 2 > "$task/shared-visibility-build.log" 2>&1
ctest --test-dir "$build" --output-on-failure --timeout 120 > "$task/shared-visibility-source-test.log" 2>&1
cmake --install "$build/hyle" --prefix "$prefix" > "$task/shared-visibility-install.log" 2>&1
nm -D --defined-only "$prefix/lib/libhyle_compute_provider_flashinfer.so" > "$task/shared-visibility-exports.log"
if grep -E '_ZN10flashinfer|_ZN4hyle7compute10flashinfer6native' "$task/shared-visibility-exports.log"; then
  exit 1
fi
python3 "$source/scripts/check-shared-export-hygiene.py" --root "$prefix" > "$task/shared-visibility-hygiene.log"
mv "$source" "$source-hidden"
mv "$build" "$build-hidden"
trap 'mv "$build-hidden" "$build"; mv "$source-hidden" "$source"' EXIT
ctest --test-dir /root/hyle-m1c-sdk/shared-consumer --output-on-failure --timeout 120 > "$task/shared-visibility-installed-test.log" 2>&1
cat "$task/shared-visibility-hygiene.log" "$task/shared-visibility-installed-test.log"
