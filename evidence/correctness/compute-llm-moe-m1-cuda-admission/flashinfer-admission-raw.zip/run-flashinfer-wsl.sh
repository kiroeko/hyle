#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2
export TRACY_ONLY_LOCALHOST=1
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
source=/root/hyle-m1c-source
build=/root/hyle-m1c-build
mkdir -p "$source"
tar -xzf "$task/product-worktree.tar.gz" -C "$source"
cache=/root/.cache/hyle/dependencies/v1
archive="$cache/archives/flashinfer-69ff11fc4954-dda66e35e348.tar.gz"
test -f "$cache/.hyle-dependency-cache-v1"
if test ! -f "$archive"; then
  cp /mnt/c/public/project-hyle/hyle/.scratch/validation/m1-route-binding/m1-cuda-intake/flashinfer-69ff11fc4954396d98326656dc85debd2223f637.tar.gz "$archive"
fi
cmake -S "$source" -B "$build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=/usr/bin/gcc-14 \
  -DCMAKE_CXX_COMPILER=/usr/bin/g++-14 \
  -DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc \
  -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14 -DCMAKE_CUDA_ARCHITECTURES=89 \
  -DHYLE_DEV_FACTORS=compute_provider_flashinfer -DHYLE_STATIC=ON \
  -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
  -DHYLE_WERROR=ON -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=ON \
  -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_ONEDNN=OFF \
  > "$task/flashinfer-wsl-configure.log" 2>&1
cmake --build "$build" --parallel 2 --target hyle_compute_provider_flashinfer_tests \
  > "$task/flashinfer-wsl-build.log" 2>&1
ctest --test-dir "$build" -L '^compute_provider_flashinfer$' \
  --output-on-failure --timeout 120 > "$task/flashinfer-wsl-tests.log" 2>&1
cat "$task/flashinfer-wsl-tests.log"
