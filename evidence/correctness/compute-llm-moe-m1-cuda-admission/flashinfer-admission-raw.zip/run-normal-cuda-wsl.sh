#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2
export TRACY_ONLY_LOCALHOST=1
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
source=/root/hyle-m1c-source
build=/root/hyle-m1c-build
tar -xzf "$task/product-worktree.tar.gz" -C "$source"
cmake -S "$source" -B "$build" -G Ninja \
  -DHYLE_DEV_FACTORS=graph_route_cuda,compute_provider_flashinfer,compute_ops \
  > "$task/normal-cuda-wsl-configure.log" 2>&1
cmake --build "$build" --parallel 2 --target hyle_graph_route_cuda_tests hyle_compute_provider_flashinfer_tests hyle_compute_ops_tests \
  > "$task/normal-cuda-wsl-build.log" 2>&1
ctest --test-dir "$build" -L '^(graph_route_cuda|compute_provider_flashinfer|compute_ops)$' \
  --output-on-failure --timeout 120 > "$task/normal-cuda-wsl-tests.log" 2>&1
cat "$task/normal-cuda-wsl-tests.log"
