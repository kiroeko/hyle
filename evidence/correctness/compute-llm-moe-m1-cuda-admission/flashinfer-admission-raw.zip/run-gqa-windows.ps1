$ErrorActionPreference = 'Stop'
$m1cRoot = 'C:\public\project-hyle\hyle'
$m1cBuild = 'C:\hyle-scratch\m1c-gqa'
$m1cLogs = Join-Path $m1cRoot '.scratch\validation\m1-cuda-admission'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M1cErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M1cErrorMode]::SetErrorMode(0x8003)
. (Join-Path $m1cRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'compute_ops,compute_provider_native' -BinaryDir $m1cBuild -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=ON','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') > (Join-Path $m1cLogs 'gqa-windows-configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& cmake --build $m1cBuild --parallel 2 --target hyle_compute_ops_tests hyle_compute_provider_native_tests > (Join-Path $m1cLogs 'gqa-windows-build.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$m1cBin = Join-Path $m1cBuild 'bin'
foreach ($m1cDll in Get-ChildItem -LiteralPath $m1cBuild -Recurse -File -Filter '*.dll') {
  $m1cDestination = Join-Path $m1cBin $m1cDll.Name
  if ($m1cDll.FullName -ne $m1cDestination) {
    Copy-Item -LiteralPath $m1cDll.FullName -Destination $m1cDestination -Force
  }
}
& ctest --test-dir $m1cBuild -L '^(compute_ops|compute_provider_native)$' --output-on-failure --timeout 60 > (Join-Path $m1cLogs 'gqa-windows-tests.log') 2>&1
exit $LASTEXITCODE
