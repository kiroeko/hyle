#include <cstdio>
#include <cuda.h>
#include <cuda_runtime_api.h>

int main() {
  const auto driver = cuInit(0);
  const char *message = nullptr;
  (void)cuGetErrorString(driver, &message);
  std::printf("cuInit=%d (%s)\n", int(driver), message ? message : "unavailable");
  int count = -1;
  const auto runtime = cudaGetDeviceCount(&count);
  std::printf("cudaGetDeviceCount=%d (%s), devices=%d\n", int(runtime), cudaGetErrorString(runtime), count);
  std::fflush(stdout);
  return driver == CUDA_SUCCESS && runtime == cudaSuccess ? 0 : 1;
}
