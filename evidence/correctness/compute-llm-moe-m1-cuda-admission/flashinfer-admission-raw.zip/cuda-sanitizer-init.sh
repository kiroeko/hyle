#!/bin/bash
set -eu
export PATH=/usr/local/cuda-13.3/bin:/usr/bin:/bin:/usr/sbin:/sbin
task=/mnt/c/public/project-hyle/hyle/.scratch/validation/m1-cuda-admission
g++-14 -g -fsanitize=address "$task/cuda-sanitizer-init.cc" \
  -I/usr/local/cuda-13.3/include -L/usr/local/cuda-13.3/lib64 -L/usr/lib/wsl/lib \
  -Wl,-rpath,/usr/local/cuda-13.3/lib64 -lcudart -lcuda -o /root/hyle-m1c-cuda-init-asan
set +e
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 /root/hyle-m1c-cuda-init-asan > "$task/cuda-init-asan.log" 2>&1
code=$?
head -65 "$task/cuda-init-asan.log"
exit "$code"
