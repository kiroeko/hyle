from pathlib import Path
import ctypes
import hashlib
import json
import os
import shutil
import subprocess

task = Path(__file__).resolve().parent
root = Path('C:/hyle-scratch/m1cs')
logs = task / 'ggml-delivery-windows'
consumer, build = root / 'consumer', root / 'b'
assert json.loads((logs / 'receipt.json').read_text())['status'] == 'FAIL'
for name in ('receipt.json', 'shared-source-test.log', 'shared-source-build.log'):
    shutil.copy2(logs / name, logs / ('before-timer-' + name))
shutil.copy2(build / 'Testing/Temporary/LastTest.log', logs / 'before-timer-LastTest.log')
ctypes.windll.kernel32.SetErrorMode(0x8003)
manifest = {str(p.relative_to(build)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [build / 'm1c_attention.exe', build / 'hyle_compute_provider_ggml_cuda.dll']}
(logs / 'before-timer-binary-sha256.json').write_text(json.dumps(manifest, indent=2))
cmake = consumer / 'CMakeLists.txt'
shutil.copy2(cmake, logs / 'consumer-original-CMakeLists.txt')
(consumer / 'diagnostic.cc').write_text(r'''
#include <windows.h>
#include <cstdio>
#include <cstdint>
static void address(void *value) {
  HMODULE module{};
  char path[1024]{};
  GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                    GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                    reinterpret_cast<const char *>(value), &module);
  GetModuleFileNameA(module, path, sizeof(path));
  std::fprintf(stderr, "%s + 0x%llx\n", path,
    static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(value) -
                                   reinterpret_cast<std::uintptr_t>(module)));
}
static LONG CALLBACK trace(EXCEPTION_POINTERS *error) {
  if (error->ExceptionRecord->ExceptionCode == EXCEPTION_INT_DIVIDE_BY_ZERO) {
    std::fprintf(stderr, "DIVIDE-BY-ZERO AT ");
    address(error->ExceptionRecord->ExceptionAddress);
    void *frames[24];
    const auto count = CaptureStackBackTrace(0, 24, frames, nullptr);
    for (USHORT i = 0; i < count; ++i) address(frames[i]);
  }
  return EXCEPTION_CONTINUE_SEARCH;
}
static auto handler = AddVectoredExceptionHandler(1, trace);
''')
with cmake.open('a') as output:
    output.write('\ntarget_sources(m1c_attention PRIVATE diagnostic.cc)\n')
    output.write('target_link_options(hyle_compute_provider_ggml_cuda PRIVATE /MAP)\n')
env = dict(os.environ, CMAKE_BUILD_PARALLEL_LEVEL='2')
def run(name, args):
    with (logs / (name + '.log')).open('wb') as output:
        result = subprocess.run(args, stdout=output, stderr=subprocess.STDOUT, env=env)
    print(name, result.returncode, flush=True)
    return result.returncode
assert run('diagnostic-configure', ['cmake', '-S', str(consumer), '-B', str(build)]) == 0
assert run('diagnostic-build', ['cmake', '--build', str(build), '--parallel', '2']) == 0
shutil.copy2(build / 'hyle/src/compute_provider_ggml_cuda/hyle_compute_provider_ggml_cuda.dll',
             build / 'hyle_compute_provider_ggml_cuda.dll')
run('diagnostic-stack', [str(build / 'm1c_attention.exe'),
    '--gtest_filter=CudaDefault.OriginalGgmlThroughOrdinaryDirectEntry'])
print((logs / 'diagnostic-stack.log').read_text(errors='replace'))
shutil.copy2(build / 'hyle/src/compute_provider_ggml_cuda/hyle_compute_provider_ggml_cuda.map',
             logs / 'diagnostic-ggml.map')
shutil.copy2(logs / 'consumer-original-CMakeLists.txt', cmake)
