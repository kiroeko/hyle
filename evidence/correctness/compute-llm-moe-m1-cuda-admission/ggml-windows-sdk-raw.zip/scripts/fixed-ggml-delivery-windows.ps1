$ErrorActionPreference = 'Stop'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
. C:\public\project-hyle\hyle\scripts\hyle-windows.ps1 -Action Build -Preset windows-ninja -BinaryDir C:\hyle-scratch\m1cg -ExtraArgs @('--target', 'help') > (Join-Path $PSScriptRoot 'ggml-delivery-windows-toolchain.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python (Join-Path $PSScriptRoot 'ggml-delivery-windows-fixed.py')
exit $LASTEXITCODE
