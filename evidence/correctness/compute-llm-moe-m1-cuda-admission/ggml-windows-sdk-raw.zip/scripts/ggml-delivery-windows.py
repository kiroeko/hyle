"""Real SDK consumers; all moves are guarded PowerShell operations in m1cs."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

task = Path(__file__).resolve().parent
root = Path('C:/hyle-scratch/m1cs')
source, consumer, build = root / 's', root / 'consumer', root / 'b'
logs = task / 'ggml-delivery-windows'
logs.mkdir(exist_ok=True)
assert not root.exists(), 'Use the recorded live process or a bounded resume, never overwrite a run'
source.mkdir(parents=True)
with tarfile.open(task / 'product-worktree.tar.gz') as archive:
    archive.extractall(source, filter='data')
manifest = json.loads((task / 'product-worktree-manifest.json').read_text())
report = {'candidate': manifest['base'], 'source_manifest_sha256': hashlib.sha256(
    (task / 'product-worktree-manifest.json').read_bytes()).hexdigest(),
    'status': 'RUNNING', 'commands': []}
record = logs / 'receipt.json'
env = dict(os.environ, CMAKE_BUILD_PARALLEL_LEVEL='2', TRACY_ONLY_LOCALHOST='1',
           CTEST_INTERACTIVE_DEBUG_MODE='0')
ctypes.windll.kernel32.SetErrorMode(0x8003)

def save():
    record.write_text(json.dumps(report, indent=2) + '\n')

def run(name, argv):
    print('RUN ' + name, flush=True)
    with (logs / (name + '.log')).open('wb') as output:
        result = subprocess.run([str(value) for value in argv], stdout=output,
                                stderr=subprocess.STDOUT, env=env)
    report['commands'].append({'name': name, 'argv': [str(value) for value in argv],
        'exit_code': result.returncode,
        'sha256': hashlib.sha256((logs / (name + '.log')).read_bytes()).hexdigest()})
    save()
    if result.returncode:
        print((logs / (name + '.log')).read_text(errors='replace')[-7000:], flush=True)
        raise RuntimeError(name)

def move(src, dst):
    subprocess.run(['pwsh', '-NoProfile', '-File', str(task / 'move-windows-sdk.ps1'),
                    '-Source', str(src), '-Destination', str(dst)], check=True)

def stage(binary, roots):
    executable = binary / 'm1c_attention.exe'
    assert executable.is_file()
    for origin in roots:
        for dll in origin.rglob('*.dll'):
            destination = binary / dll.name
            if dll.resolve() != destination.resolve():
                shutil.copy2(dll, destination)
    cuda = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin')
    for name in ('cudart64_13.dll', 'cublas64_13.dll', 'cublasLt64_13.dll'):
        shutil.copy2(next(cuda.rglob(name)), binary / name)

names = ('tests/graph_route_cuda/attention_test.cc',
         'tests/compute_provider_flashinfer/attention_test_support.h',
         'tests/graph_route_cuda/ggml_test.cc',
         'tests/graph_provider_ggml_cuda/region_test_support.h',
         'tests/compute_route_cuda/ggml_test.cc',
         'tests/compute_provider_ggml_cuda/test_support.h')
for name in names:
    (consumer / name).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / name, consumer / name)
gtest = next(Path('C:/public/tools/hyle-dependencies/v1/sources').glob('googletest-063de7e9578f-*'))
(consumer / 'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(m1c_ggml_sdk LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(gtest_force_shared_crt ON CACHE BOOL "" FORCE)
if(M1C_SOURCE)
  set(HYLE_COMPONENTS graph)
  set(HYLE_BUILD_TESTS OFF)
  set(HYLE_BUILD_BENCH OFF)
  set(HYLE_INSTALL ON)
  add_subdirectory("${M1C_SOURCE}" hyle)
else()
  find_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)
endif()
set(INSTALL_GTEST OFF)
add_subdirectory("''' + gtest.as_posix() + '''" googletest EXCLUDE_FROM_ALL)
add_executable(m1c_attention tests/graph_route_cuda/attention_test.cc
  tests/graph_route_cuda/ggml_test.cc tests/compute_route_cuda/ggml_test.cc)
target_link_libraries(m1c_attention PRIVATE hyle::graph GTest::gtest_main)
hyle_stage_runtime_dependencies(m1c_attention)
enable_testing()
add_test(NAME m1c_attention COMMAND m1c_attention)
''', encoding='utf-8', newline='\n')
flags = ['-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_C_COMPILER=cl', '-DCMAKE_CXX_COMPILER=cl',
         '-DCMAKE_CUDA_COMPILER=C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/nvcc.exe',
         '-DCMAKE_CUDA_ARCHITECTURES=89-real', '-DHYLE_WERROR=ON', '-DHYLE_COMPUTE_CPU=OFF',
         '-DHYLE_COMPUTE_CUDA=ON', '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_COMPUTE_VULKAN=OFF',
         '-DHYLE_COMPUTE_ONEDNN=OFF']

def consume(linkage, prefix):
    relocated = root / (linkage + '-relocated')
    move(prefix, relocated)
    hidden_source, hidden_build = root / 's-hidden', root / 'b-hidden'
    move(source, hidden_source)
    try:
        move(build, hidden_build)
        try:
            target = root / (linkage + '-consumer')
            run(linkage + '-consumer-configure', ['cmake', '-S', consumer, '-B', target,
                '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=cl',
                '-DCMAKE_PREFIX_PATH=' + str(relocated)])
            run(linkage + '-consumer-build', ['cmake', '--build', target, '--parallel', '2'])
            stage(target, [relocated])
            run(linkage + '-consumer-test', ['ctest', '--test-dir', target,
                '--output-on-failure', '--no-tests=error', '--timeout', '120'])
        finally:
            move(hidden_build, build)
    finally:
        move(hidden_source, source)

try:
    # A single disposable source producer provides source/static/shared journeys.
    # Toggling HYLE linkage keeps ggml's unchanged static vendor objects reusable.
    for linkage, static in (('static', 'ON'), ('shared', 'OFF')):
        prefix = root / (linkage + '-prefix')
        run(linkage + '-source-configure', ['cmake', '-S', consumer, '-B', build, '-G', 'Ninja',
            '-DM1C_SOURCE=' + str(source), '-DHYLE_STATIC=' + static,
            '-DCMAKE_INSTALL_PREFIX=' + str(prefix)] + flags)
        run(linkage + '-source-build', ['cmake', '--build', build, '--parallel', '2'])
        stage(build, [build])
        run(linkage + '-source-test', ['ctest', '--test-dir', build,
            '--output-on-failure', '--no-tests=error', '--timeout', '120'])
        run(linkage + '-install', ['cmake', '--install', build / 'hyle'])
        consume(linkage, prefix)
    run('shared-hygiene', ['python', source / 'scripts/check-shared-export-hygiene.py',
                           '--root', root / 'shared-relocated'])
    report['status'] = 'PASS'
except Exception:
    report['status'] = 'FAIL'
    raise
finally:
    save()
