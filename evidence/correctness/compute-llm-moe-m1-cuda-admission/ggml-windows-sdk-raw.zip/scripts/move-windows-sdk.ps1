param([Parameter(Mandatory=$true)][string]$Source,
      [Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference = 'Stop'
$m1cRoot = [System.IO.Path]::GetFullPath('C:\hyle-scratch\m1cs').TrimEnd('\') + '\'
$m1cSource = (Resolve-Path -LiteralPath $Source).Path
$m1cDestination = [System.IO.Path]::GetFullPath($Destination)
foreach ($m1cPath in @($m1cSource, $m1cDestination)) {
  if (-not $m1cPath.StartsWith($m1cRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw "SDK move escaped the task workspace: $m1cPath"
  }
}
if (Test-Path -LiteralPath $m1cDestination) { throw 'SDK move destination exists' }
Move-Item -LiteralPath $m1cSource -Destination $m1cDestination
