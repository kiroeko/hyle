# Bounded next G01 CPU paged P1 work

Product remains immutable1e9cdfd45, runtime3cf. No product APIs or common instruments may change.
Implement only finite bench adapter/contract under bench/inference_resident_sdpa/cpu_paged_p1.
The pinned original CPU flash has no arbitrary native page table. Do not compare against a
newly invented attention kernel or label the patched default path a pristine original runtime.
Do not let an original masked physical-capacity flash scan unread spare pages (tiled math can
read K before applying masks); exact page guards remain required in the product arm.

A permissible narrow baseline to prove is original prepared contiguous CPU cache for immutable
ready K/V, with a cold logical-order copy into separately owned native storage, explicitly
accounted outside warm timing. Both arms hold actual ready histories immutable throughout all
samples; output/Queue/update/Completion/lease-return boundary must match. The comparison only
claims warm readonly attention/page-indirection overhead, not cache production/growth/reorder
performance. G03/G06 update costs still need their own declared gates. Cold conversion/storage
cannot be hidden or called zero. Independent pristine pinned original math must be authenticated
(e.g. privately isolated original DLL API), not linked through the new address helper and called
unpatched. Original C API is private benchmark dependency, no public HYLE FFI layer.

Before qualification freeze actual peer ownership and supported domain; reject/review the adapter
if it caches a changing input without an immutable owner proof. Use original scalar oracle,
16 AA/order/allocation/placement, controls and existing n15 stop/5% contract machinery. No
full engine, global benchmark or re-scan of the three engines. This file is a bounded design
input, not qualified P1 evidence or authority to weaken lifecycle/math requirements.
