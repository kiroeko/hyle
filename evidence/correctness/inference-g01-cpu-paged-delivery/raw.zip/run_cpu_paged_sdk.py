from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time

repo = Path.cwd()
out = repo / '.scratch/inference-gaps/g01'
mode = sys.argv[1]
assert mode in ('static', 'shared')
tag = sys.argv[2] if len(sys.argv) > 2 else ''
assert tag in ('', '2')
label = mode + tag
candidate = '1e9cdfd45307ea4a15b92374377ad2b268203193'
producer = repo / '.scratch/build-compute-v2-dev'
base = Path('C:/h7') / ('g01-paged-' + label + '-sdk')
stage, prefix = base / 'staging', base / 'relocated'
source, build = base / 'consumer-source', base / 'consumer-build'
source.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
for line in subprocess.check_output(['cmd', '/d', '/c', str(out / 'cpu-ragged-env.cmd')], text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key] = value
result_file = out / ('cpu-paged-win-' + label + '-sdk-result.json')
records = json.loads(result_file.read_text())['stages'] if result_file.exists() else []

def done(stage_name):
    return next((r for r in reversed(records) if r['stage'] == stage_name), {}).get('exit_code') == 0

def run(stage_name, args):
    attempt = 1 + sum(r['stage'] == stage_name for r in records)
    log = out / ('cpu-paged-win-' + label + '-sdk-' + stage_name + '-' + str(attempt) + '.log')
    started = time.monotonic()
    with log.open('w', encoding='utf-8') as f:
        result = subprocess.run(args, env=env, stdout=f, stderr=subprocess.STDOUT)
    row = {'stage': stage_name, 'command': args, 'exit_code': result.returncode,
           'elapsed_seconds': time.monotonic() - started, 'log': str(log)}
    records.append(row)
    result_file.write_text(json.dumps({'candidate': candidate, 'mode': mode,
        'producer': str(producer), 'scope': 'relocated installed public Compute/Graph only; exact canonical paged oracle source',
        'stages': records}, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        with log.open('rb') as f:
            f.seek(max(0, log.stat().st_size - 2400))
            print(f.read(2400).decode('utf-8', errors='replace'), flush=True)
        raise SystemExit(result.returncode)

hook = out / 'cpu-paged-sdk-producer.cmake'
body = '''if(PROJECT_NAME STREQUAL "hyle")
 function(g01_cpu_paged_sdk_producer)
  add_executable(g01_cpu_paged_sdk_producer "@SOURCE@")
  target_compile_features(g01_cpu_paged_sdk_producer PRIVATE cxx_std_23)
  target_compile_options(g01_cpu_paged_sdk_producer PRIVATE /utf-8 /wd4324)
  target_link_libraries(g01_cpu_paged_sdk_producer PRIVATE hyle::compute hyle::graph)
  hyle_stage_runtime(g01_cpu_paged_sdk_producer)
 endfunction()
 cmake_language(DEFER CALL g01_cpu_paged_sdk_producer)
endif()
'''.replace('@SOURCE@', (out / 'public_cpu_ragged.cc').as_posix())
if not hook.exists() or hook.read_text(encoding='utf-8') != body:
    hook.write_text(body, encoding='utf-8')
if not done('configure'):
    run('configure', ['cmake', '-S', str(repo), '-B', str(producer),
        '-DCMAKE_PROJECT_INCLUDE=' + str(out / 'cpu-paged-sdk-producer.cmake'), '-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES',
        '-DHYLE_COMPONENTS=compute;graph', '-DHYLE_COMPUTE_ROUTES=cpu',
        '-DHYLE_BUILD_TESTS=OFF', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_INSTALL=ON',
        '-DHYLE_STATIC=' + ('ON' if mode == 'static' else 'OFF')])
if not done('producer-build'):
    run('producer-build', ['cmake', '--build', str(producer), '--target', 'g01_cpu_paged_sdk_producer', '--parallel', '4'])
if not done('install'):
    assert not prefix.exists()
    run('install', ['cmake', '--install', str(producer), '--prefix', str(stage)])
if stage.exists():
    assert not prefix.exists()
    stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
copies = {'tests/compute_provider_ggml/native_paged_test.cc': 'tests/compute_provider_ggml/native_paged_test.cc',
          'tests/compute_provider_native/half_test_support.h': 'tests/compute_provider_native/half_test_support.h',
          '.scratch/inference-gaps/g01/public_cpu_ragged.cc': 'ragged.cc',
          '.scratch/inference-gaps/g01/public_cpu_resident.cc': 'resident.cc'}
inputs = {}
for origin, relative in copies.items():
    dest = source / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    data = (repo / origin).read_bytes()
    if not dest.exists() or dest.read_bytes() != data:
        dest.write_bytes(data)
    inputs[origin] = hashlib.sha256(data).hexdigest()
body = '''cmake_minimum_required(VERSION 3.25)
project(g01_cpu_paged_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 gtest EXCLUDE_FROM_ALL)
add_executable(paged tests/compute_provider_ggml/native_paged_test.cc)
target_link_libraries(paged PRIVATE hyle::compute GTest::gtest_main)
add_executable(ragged ragged.cc)
add_executable(resident resident.cc)
foreach(name paged ragged resident)
 target_compile_features(${name} PRIVATE cxx_std_23)
 target_compile_options(${name} PRIVATE /utf-8 /W4 /WX /wd4324)
 if(NOT name STREQUAL "paged")
  target_link_libraries(${name} PRIVATE hyle::compute hyle::graph)
 endif()
 hyle_stage_runtime(${name})
endforeach()
'''
cmake_file = source / 'CMakeLists.txt'
if not cmake_file.exists() or cmake_file.read_text() != body:
    cmake_file.write_text(body)
if not done('consumer-configure'):
    run('consumer-configure', ['cmake', '-S', str(source), '-B', str(build), '-G', 'Ninja',
        '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(prefix)])
if not done('consumer-build'):
    run('consumer-build', ['cmake', '--build', str(build), '--target', 'paged', 'ragged', 'resident', '--parallel', '4'])
for name in ('paged', 'ragged', 'resident'):
    if not done('run-' + name):
        run('run-' + name, [str(build / (name + '.exe'))])
inputs.update({str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [cmake_file, producer / 'CMakeCache.txt']})
artifacts = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [
    *build.glob('*.exe'), *build.glob('*.dll'), *(prefix / 'lib').glob('hyle*.lib'),
    *(prefix / 'bin').glob('*.dll')] if p.is_file()}
(out / ('cpu-paged-win-' + label + '-sdk-inputs.json')).write_text(json.dumps({
    'candidate': candidate, 'relocated_prefix': str(prefix), 'staging_absent': not stage.exists(),
    'inputs': inputs, 'artifacts': artifacts}, indent=2) + '\n')
