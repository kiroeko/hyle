from pathlib import Path
import json, os, subprocess, sys, time

out = Path('.scratch/inference-gaps/g01')
job = out / 'cpu-paged-final-gates-job.json'
rows = json.loads((out / 'cpu-paged-final-gates-job-1.json').read_text(encoding='utf-8'))['stages']
assert rows[-1]['stage'] == 'shared-sdk' and rows[-1]['exit_code'] != 0
steps = [('shared-sdk2', [sys.executable, str(out / 'run_cpu_paged_sdk.py'), 'shared', '2'])]
steps += [('air-cpu-portable', ['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15',
    '-o','ServerAliveCountMax=3','kiro@172.22.10.198',
    '/usr/bin/python3 /Users/kiro/hyle-scratch/compute-unified/g01-cpu-paged-portable/run.py'])]
for name, args in steps:
    job.write_text(json.dumps({'state':'RUNNING','pid':os.getpid(),'current':name,'command':args,
        'candidate':'1e9cdfd45307ea4a15b92374377ad2b268203193','stages':rows},indent=2)+'\n',encoding='utf-8')
    print('START ' + name, flush=True)
    started=time.monotonic()
    r=subprocess.run(args)
    row={'stage':name,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'command':args}
    rows.append(row)
    print(json.dumps(row),flush=True)
    if r.returncode:
        job.write_text(json.dumps({'state':'TERMINAL','pid':os.getpid(),'exit_code':r.returncode,
            'failed_stage':name,'stages':rows},indent=2)+'\n',encoding='utf-8')
        raise SystemExit(r.returncode)
job.write_text(json.dumps({'state':'TERMINAL','pid':os.getpid(),'exit_code':0,'stages':rows},indent=2)+'\n',encoding='utf-8')
