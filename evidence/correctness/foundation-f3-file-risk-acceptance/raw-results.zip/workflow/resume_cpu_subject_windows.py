from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys

repo=Path.cwd();build=Path('C:/h7/foundation-f1-cpu')
out=repo/'.scratch/foundation-f3/cpu-subject-windows-1';assert out.exists()
attempt=sys.argv[1];record=json.loads((out/'job.json').read_text())
assert all(stage['state']=='terminal' for stage in record['stages'])
spec=importlib.util.spec_from_file_location('hyle_header_env',repo/'scripts/header-self-contained.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
env=module.visual_studio_environment('','x64','',record['compiler']);env['VSLANG']='1033'
cmake=shutil.which('cmake',path=env['PATH'])
record.setdefault('resumes',[]).append({'attempt':attempt,'reason':'Same F3 implementation/tree; original failures retained, no budget reset.',
    'inputs':[{'path':row['path'],'sha256':hashlib.sha256((repo/row['path']).read_bytes()).hexdigest()} for row in record['inputs']]})
class MemoryStatus(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(str(i),ctypes.c_ulonglong) for i in range(7)]
for name,command,timeout in [
    ('build-'+attempt,[cmake,'--build',str(build),'--target','hyle_compute_stream_test','--parallel','1'],1800),
    ('files-'+attempt,[str(build/'bin/hyle_compute_stream_test.exe'),'--gtest_filter=FileStream.*',
                       '--gtest_output=xml:'+str(out/('files-'+attempt+'.xml'))],120)
]:
    memory=MemoryStatus();memory.length=ctypes.sizeof(memory);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory))
    available=getattr(memory,'1');assert available>=4*1024**3
    log=out/(name+'.log');assert not log.exists();runtime=env.copy()
    if name.startswith('files'):runtime['PATH']=str(build/'bin')+';C:/Windows/System32;C:/Windows'
    with log.open('w') as output:
        process=subprocess.Popen(command,cwd=repo,env=runtime,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        row={'name':name,'command':command,'pid':process.pid,'state':'running','available_bytes':available,'log':log.name}
        record['stages'].append(row);(out/'job.json').write_text(json.dumps(record,indent=2))
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill();process.wait();row.update(state='terminal',verdict='TIMEOUT');(out/'job.json').write_text(json.dumps(record,indent=2));raise
        row.update(state='terminal',exit_code=code,verdict='PASS' if code==0 else 'FAIL',sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (out/'job.json').write_text(json.dumps(record,indent=2))
    print(name,code,flush=True)
    if code:raise SystemExit(code)
record['verdict']='PASS_CPU_FILE_SUBJECT_ONLY';(out/'job.json').write_text(json.dumps(record,indent=2))
