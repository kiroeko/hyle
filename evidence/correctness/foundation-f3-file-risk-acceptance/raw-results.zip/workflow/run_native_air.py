from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

candidate,route=sys.argv[1:];assert len(candidate)==40 and route in ('apple','vulkan')
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688'
assert candidate in (source/'SOURCE-MANIFEST.txt').read_text()
build=base/('a-'+route)/'selected-graph/shared-sdk-build'
root=base/('foundation-f3-'+route+'-'+candidate[:9]);assert not root.exists();root.mkdir()
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
identity={key:subprocess.check_output(command,text=True,env=env).strip() for key,command in [
    ('hardware',['sysctl','-n','hw.model']),('memory',['sysctl','-n','hw.memsize']),('os',['sw_vers']),
    ('compiler',['clang++','--version']),('cmake',['/opt/homebrew/bin/cmake','--version']),('ninja',['/opt/homebrew/bin/ninja','--version'])]}
assert identity['hardware']=='Mac16,12'
cache=(build/'CMakeCache.txt').read_text();assert 'HYLE_BUILD_TESTS:BOOL=ON' in cache and 'HYLE_INSTALL:BOOL=OFF' in cache
target='hyle_compute_route_'+route+'_file_stream_test'
record={'candidate':candidate,'source':str(source),'build':str(build),'identity':identity,'parallel':1,
        'scope':'F3 original native file byte roundtrip/late EOF only; full math/SDK/native-fault scope unproven','stages':[]}
def available():
    page=int(subprocess.check_output(['sysctl','-n','hw.pagesize'],text=True,env=env))
    stats=subprocess.check_output(['vm_stat'],text=True,env=env)
    total=0
    for name in ['free','inactive','speculative']:
        match=re.search(r'Pages '+name+r':\s*(\d+)',stats);assert match
        total+=int(match.group(1))
    return total*page
for name,command,timeout in [
    ('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-DHYLE_COMPONENTS=compute'],300),
    ('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target',target,'--parallel','1'],1800),
    ('files',[str(build/'bin'/target),'--gtest_filter='+route.capitalize()+'FileStream.*','--gtest_output=xml:'+str(root/'files.xml')],120),
]:
    free=available();assert free>=4*1024**3,free
    log=root/(name+'.log')
    with log.open('w') as output:
        process=subprocess.Popen(command,cwd=source,env=env,stdout=output,stderr=subprocess.STDOUT)
        row={'name':name,'command':command,'pid':process.pid,'state':'running','available_bytes':free,'log':log.name}
        record['stages'].append(row);(root/'job.json').write_text(json.dumps(record,indent=2))
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill();process.wait();row.update(state='terminal',verdict='TIMEOUT');(root/'job.json').write_text(json.dumps(record,indent=2));raise
        row.update(state='terminal',exit_code=code,verdict='PASS' if code==0 else 'FAIL',sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root/'job.json').write_text(json.dumps(record,indent=2))
    print(name,code,flush=True)
    if code:raise SystemExit(code)
record['verdict']='PASS_NATIVE_FILE_JOURNEY_ONLY';(root/'job.json').write_text(json.dumps(record,indent=2))
