from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'
fixture = '452eada9b770950d28f3b8e2d8ee3ac735d468ef'
cpu = scratch / 'cpu-subject-windows-1'; job = json.loads((cpu / 'job.json').read_text())
resume = next(row for row in job['resumes'] if row['attempt'] == 'file-risks')
for row in resume['inputs']:
    assert hashlib.sha256((repo / row['path']).read_bytes()).hexdigest() == row['sha256']
for row in job['stages']:
    if row['name'] not in ['build-file-risks', 'files-file-risks']: continue
    assert row['state'] == 'terminal' and row['exit_code'] == 0
    assert hashlib.sha256((cpu / row['log']).read_bytes()).hexdigest() == row['sha256']
tests = ET.parse(cpu / 'files-file-risks.xml').getroot()
assert tests.attrib['tests'] == '10' and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
air = scratch / 'file-risk-air-logs'; rows = []
for route, count in [('apple', 6), ('vulkan', 5)]:
    folder = air / ('foundation-f3-' + route + '-' + fixture[:9]); data = json.loads((folder / 'job.json').read_text())
    assert data['candidate'] == fixture and data['identity']['hardware'] == 'Mac16,12'
    for stage in data['stages']:
        assert stage['state'] == 'terminal' and stage['exit_code'] == 0
        assert hashlib.sha256((folder / stage['log']).read_bytes()).hexdigest() == stage['sha256']
    tests = ET.parse(folder / 'files.xml').getroot()
    assert tests.attrib['tests'] == str(count) and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
    rows.append({'route': route, 'tests_passed': count, 'identity': data['identity']})
out = repo / 'evidence/correctness/foundation-f3-file-risk-acceptance'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for name in ['job.json', 'build-file-risks.log', 'files-file-risks.log', 'files-file-risks.xml']:
        packed.writestr('cpu/' + name, (cpu / name).read_bytes())
    for path in sorted(air.rglob('*')):
        if path.is_file(): packed.writestr('air/' + path.relative_to(air).as_posix(), path.read_bytes())
    packed.writestr('air-source.json', (scratch / ('air-source-' + fixture[:9] + '.json')).read_bytes())
    for name in ['run_native_air.py', 'resume_cpu_subject_windows.py', 'seal_file_risks.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1, 'product_commit': 'f3d931c47777f7fbfd35dedf1f5e0734fa28ef6c',
    'fixture_commit': fixture, 'scope': 'F3 selected Windows CPU and Air Apple/Vulkan file risk acceptance only',
    'windows_cpu_tests_passed': 10, 'windows_cpu_inputs': resume['inputs'], 'windows_cpu_compiler': job['compiler'],
    'air': rows,
    'cpu_risks': ['Descriptions/offset/backing cap rejected before input permission move or IO/native acceptance.',
        'Admitted owned File and cold-copied descriptors survive caller release.',
        'Original readonly File write error preserves zero written bytes, one copied chunk and no ready; original file unchanged.',
        'After admission injected metadata quota exhaustion reports original ResourceExhausted with no IO/ready and balanced owners.'],
    'apple_risks': ['Actual MLX GPU prefix blocks original owner; accepted original Metal producer is retained by F3.',
        'Normal producer file readback checks original bytes.', 'Cancel and abandon retain admitted native uses until real retirement.',
        'Actual late original native failure preserves Internal with zero ready/file bytes.'],
    'vulkan_risks': 'Same five original Windows-qualified file/producer/unknown/suffix fixtures on actual Air Apple M4 GPU.',
    'allocator_verdict': 'Actual native uses zero and injected F3 metadata balanced after explicit own-work retirement; no physical driver-private memory zero claim.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_WINDOWS_CPU_TEN_AND_AIR_APPLE_SIX_VULKAN_FIVE_FILE_RISK_TESTS_ONLY',
    'unproven': ['Positive partial short-write seam', 'F3 WSL/sanitizer and explicit cross-thread exported-result drop', 'Installed deliveries/new heads/absence/relocation', 'Final P0/red team/closure'],
    'budget': 'Original finite F3-02/04/06 acceptance, no product change/new FIX/budget reset; prior failures remain in their sealed receipts.'}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('CPU ten and actual Air Apple six/Vulkan five terminal file tests verified and archived.')
