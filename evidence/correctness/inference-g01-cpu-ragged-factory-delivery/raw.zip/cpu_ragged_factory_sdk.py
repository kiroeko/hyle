from pathlib import Path
old=Path('.scratch/inference-gaps/g01/cpu_ragged_sdk_windows.py').read_text()
old=old.replace("('g01-ragged-'+mode+'-sdk')","('g01-ragged-factory-'+mode+'-sdk')")
old=old.replace("cpu-ragged-win-{mode}-sdk","cpu-ragged-factory-win-{mode}-sdk")
old=old.replace('642cc1e67566994a85a65adbe0db8956c1d0350a','f780e44fcbf14684731a3b70a50512fd4411a2f4')
exec(compile(old,__file__,'exec'))
