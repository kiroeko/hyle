from pathlib import Path
import subprocess,os,time,json
out=Path.cwd()/'.scratch/inference-gaps/g01';env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
build=Path('C:/h7/inference-g01-native-vulkan/build');source=Path('C:/h7/inference-g01-native-vulkan/parent');log=out/'cpu-ragged-factory-cpu-absence-configure-1.log'
assert not log.exists();args=['cmake','-S',str(source),'-B',str(build)];start=time.monotonic()
with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
row={'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log),'scope':'configure only existing Vulkan-only tree; no GPU/build/global validation'}
if not r.returncode:
 cache=(build/'CMakeCache.txt').read_text(encoding='utf-8');row['routes']=[x for x in cache.splitlines() if x.startswith('HYLE_COMPUTE_ROUTES:')]
 install='\n'.join(p.read_text(encoding='utf-8') for p in build.rglob('cmake_install.cmake'))
 row['cpu_provider_header_in_install']= 'compute/providers/ggml_cpu.h' in install
 row['cpu_provider_library_in_install']='hyle_compute_provider_ggml.' in install
 assert row['routes']==['HYLE_COMPUTE_ROUTES:STRING=vulkan'] and not row['cpu_provider_header_in_install'] and not row['cpu_provider_library_in_install'],row
(out/'cpu-ragged-factory-cpu-absence-result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
if r.returncode:
 with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1600));print(f.read(1600).decode(errors='replace'))
raise SystemExit(r.returncode)
