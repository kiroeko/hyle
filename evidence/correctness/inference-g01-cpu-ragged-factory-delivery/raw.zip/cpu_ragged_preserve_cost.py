from pathlib import Path
import json
out=Path('.scratch/inference-gaps/g01')
current=json.loads((out/'cpu-ragged-diagnostic-cost-1.json').read_text())
if current['elapsed_seconds']<12:
 (out/'cpu-ragged-diagnostic-cost-1.log').rename(out/'cpu-ragged-diagnostic-cost-2.log')
 current['log']=str((out/'cpu-ragged-diagnostic-cost-2.log').resolve())
 (out/'cpu-ragged-diagnostic-cost-2.json').write_text(json.dumps(current,indent=2)+'\n')
 (out/'cpu-ragged-diagnostic-cost-1.json').write_text(json.dumps({'classification':'diagnostic min2 only, no formal qualification','exit_code':0,'elapsed_seconds':15.64100000000326,'source':'actual exec tool result, first min2 run','raw_log_missing':True,'reason':'diagnostic helper reused filename and second min1 run overwrote original raw; no claim that the original is replayable or performance-qualified'},indent=2)+'\n')
