from pathlib import Path
import json,hashlib
root=Path.cwd();base=root/'bench/inference_resident_sdpa/cpu_p1';dst=base.parent/'cpu_ragged_p1'
text=(base/'contract.json').read_text(encoding='utf-8')
replacements={'inference-resident-cpu-w1-p1-v2':'inference-cpu-ragged-w1-p1-v1','g01_cpu_resident':'g01_cpu_ragged','g01_cpu_perf_control':'g01_cpu_ragged_perf_control','cpu-resident-aa':'cpu-ragged-aa','cpu-resident-decode-d256':'cpu-ragged-mixed-d256','cpu-resident-prefill-d256':'cpu-ragged-prefill-d256','cpu-resident-holdout-d64':'cpu-ragged-holdout-d64','CPU resident BF16 Q=1 KV=1024 D=256 causal=1':'CPU ragged BF16 Q=1,17 KV=1024,768 D=256 causal=1','CPU resident BF16 Q=128 KV=1024 D=256 causal=1':'CPU ragged BF16 Q=64,128 KV=1024,768 D=256 causal=1','CPU resident BF16 Q=17 KV=257 D=64 causal=0':'CPU ragged BF16 Q=1,17 KV=31,47 D=64 causal=0','# HYLE_CPU_RESIDENT_RUN ':'# HYLE_CPU_RAGGED_RUN '}
for a,b in replacements.items():text=text.replace(a,b)
d=json.loads(text);d['claim']='Finite ordinary CPU BF16 packed NHD ragged two-request mixed decode/prefill, long prefill and noncausal holdout versus independent pinned original ggml flash graphs under the same original BatchProgram/Queue/F1 leases/metadata update/Completion/output owner return. Single native thread, two slots; private pool bounds UNKNOWN; not all G01 or whole-engine throughput.'
d['peers'][0]['configuration'].update(role='independent original CPU flash graph through the same original BatchProgram extension lifecycle; no candidate compile/lower math',scope='BF16 packed NHD ragged two requests; native_threads1; cold metadata/mask/query/workspace billed, native private upper UNKNOWN')
d['candidate']['entrypoint']='../cpu_ragged_bench.cc'
provenance={'source':'consumer-provenance.md','sha256':hashlib.sha256((dst/'consumer-provenance.md').read_bytes()).hexdigest(),'consumer':'finite two-request BF16 packed NHD GQA8/2 CPU mixed and prefill with exact same original BatchProgram/F1/Queue/Completion ownership topology','scope':'selected three shapes; not token/s or all G01','peer_revision':'ffa4e8b80930029a35991f94e7c8a93cd67730ab'}
(dst/'consumer-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
provenance_sha=hashlib.sha256((dst/'consumer-provenance.json').read_bytes()).hexdigest()
cases=[([1,17],[1024,768],256,True),([64,128],[1024,768],256,True),([1,17],[31,47],64,False)]
for row,(qs,ks,depth,causal) in zip(d['workloads'],cases):
 row['semantic_contract']=f'BF16 packed NHD requests2 GQA8/2 Q{qs} KV{ks} D{depth} causal={causal}; capacity tail13; original F32 query/accumulation BF16 output and F16 causal mask; same ready bind, explicit same-topology metadata update, two slots, checked completion and output owner release'
 row['provenance']={'path':'consumer-provenance.json','sha256':provenance_sha}
 row['input']['scale']={'query_rows':qs,'key_rows':ks,'depth':depth,'heads':8,'kv_heads':2,'requests':2}
 row['ownership_topology']={'candidate':'ordinary CPU BatchProgram/native ragged flash, two slots and original F1/Queue/Completion/output lease','peer':'same BatchProgram with private same-build extension carrying independent original ggml flash graphs; original provider leaf storage lifecycle unchanged','equivalence':'same packed ready bytes/layout generation/two slots/update metadata/F1 guards/Queue/Completion/output return/native_threads1'}
 row['consumer_key']='inference-cpu-ragged/'+row['id']
 row['pair']={'candidate':'HYLE CPU ragged','peer':'Original CPU ragged lifecycle'}
 row['charged_phases']=['explicit same-topology BatchInvocation.update_batch with original metadata staging/upload and host wait','original BatchProgram/F1 lease use admission and coherent buffer mapping','original native query cast/flash/output conversion and synchronous one-thread runtime work','CPUQueue submit, checked Completion.wait and output owner return/release']
 row['setup']='cold metadata/native graph and F16 causal mask, resident ready buffers, query/output payloads and cplan workspace; independent double oracle/readonly checks, four warm episodes per arm before timing; native private pool upper UNKNOWN'
 row['material_contribution']['denominator']='one two-request attention episode including explicit same-topology metadata update and owner return'
 row['material_contribution']['unit']='complete-two-request-attention'
d['extensions']['cpu_measurement']['minimum_epoch_iterations']=1
d['extensions']['cpu_measurement']['reason']='preflight measured169ms/long prefill versus4ms epoch floor; min2 cost15.641s recorded but raw accidentally overwritten by diagnostic helper, latest min1 raw9.422s retained; min1 frozen before formal sampling,16 paired rounds/process n15/31/5% margin unchanged; compile FAIL logs retained'
for executable in d['extensions']['runner']['executables']:executable['id']=executable['id'].replace('cpu-resident','cpu-ragged')
(dst/'contract.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
v=(base/'validate_aa.py').read_text(encoding='utf-8')
for a,b in replacements.items():v=v.replace(a,b)
v=v.replace('Finite CPU resident','Finite CPU ragged').replace('CPU resident','CPU ragged').replace('HYLE CPU resident','HYLE CPU ragged').replace('Original CPU flash lifecycle','Original CPU ragged lifecycle')
v=v.replace('CASES = ((1, 1024, 256, 1), (128, 1024, 256, 1), (17, 257, 64, 0))','CASES = ((1, 17, 1024, 768, 256, 1), (64, 128, 1024, 768, 256, 1), (1, 17, 31, 47, 64, 0))')
v=v.replace('for q, kv, d, causal in CASES:', 'for q1, q2, k1, k2, d, causal in CASES:').replace("title = f'CPU ragged BF16 Q={q} KV={kv} D={d} causal={causal}'","title = f'CPU ragged BF16 Q={q1},{q2} KV={k1},{k2} D={d} causal={causal}'")
(dst/'validate_aa.py').write_text(v,encoding='utf-8')
print('finite ragged contract/AA adapter prepared, not qualified')
