from pathlib import Path
import os,subprocess,json,time,sys,hashlib
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';mode=sys.argv[1];assert mode in ('static','shared')
producer=repo/'.scratch/build-compute-v2-dev';base=Path('C:/h7')/('g01-ragged-'+mode+'-sdk');base.mkdir(exist_ok=True)
stage=base/'staging';prefix=base/'relocated';source=base/'consumer-source';source.mkdir(exist_ok=True);build=base/'consumer-build'
env=os.environ.copy();batch=out/'cpu-ragged-env.cmd'
for line in subprocess.check_output(['cmd','/d','/c',str(batch)],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
result_file=out/f'cpu-ragged-win-{mode}-sdk-result.json';records=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
def done(name):return next((x for x in reversed(records) if x['stage']==name),{}).get('exit_code')==0
def run(name,args):
 n=1+sum(x['stage']==name for x in records);log=out/f'cpu-ragged-win-{mode}-sdk-{name}-{n}.log';start=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'candidate':'642cc1e67566994a85a65adbe0db8956c1d0350a','mode':mode,'producer':str(producer),'stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2200));print(f.read(2200).decode(errors='replace'))
  raise SystemExit(r.returncode)
if not done('configure'):
 run('configure',['cmake','-S',str(repo),'-B',str(producer),'-UCMAKE_PROJECT_INCLUDE','-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF')])
if not done('producer-build'):run('producer-build',['cmake','--build',str(producer),'--parallel','4'])
if not done('install'):
 assert not prefix.exists();run('install',['cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
(source/'main.cc').write_bytes((out/'public_cpu_ragged.cc').read_bytes())
(source/'resident.cc').write_bytes((out/'public_cpu_resident.cc').read_bytes())
body='''cmake_minimum_required(VERSION 3.25)
project(g01_ragged_public_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
foreach(name ragged resident)
 if(name STREQUAL "ragged")
  add_executable(${name} main.cc)
 else()
  add_executable(${name} resident.cc)
 endif()
 target_compile_features(${name} PRIVATE cxx_std_23)
 target_compile_options(${name} PRIVATE /utf-8)
 target_link_libraries(${name} PRIVATE hyle::compute hyle::graph)
 hyle_stage_runtime(${name})
endforeach()
'''
if not(source/'CMakeLists.txt').exists() or (source/'CMakeLists.txt').read_text()!=body:(source/'CMakeLists.txt').write_text(body)
if not done('consumer-configure'):run('consumer-configure',['cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix)])
if not done('consumer-build'):run('consumer-build',['cmake','--build',str(build),'--target','ragged','resident','--parallel','4'])
if not done('run-ragged'):run('run-ragged',[str(build/'ragged.exe')])
if not done('run-resident'):run('run-resident',[str(build/'resident.exe')])
inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source/'main.cc',source/'resident.cc',source/'CMakeLists.txt',producer/'CMakeCache.txt']}
artifacts={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [build/'ragged.exe',build/'resident.exe',*build.glob('*.dll'),*(prefix/'lib').glob('hyle*.lib')] if p.is_file()}
(out/f'cpu-ragged-win-{mode}-sdk-inputs.json').write_text(json.dumps({'candidate':'642cc1e67566994a85a65adbe0db8956c1d0350a','relocated_prefix':str(prefix),'staging_absent':not stage.exists(),'inputs':inputs,'artifacts':artifacts},indent=2)+'\n')
