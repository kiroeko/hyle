from pathlib import Path
import subprocess,os,json,time
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';build=repo/'.scratch/build-compute-v2-dev';hook=out/'cpu-ragged-bench-project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 function(g01_ragged_bench)
  add_library(g01_ragged_nb STATIC "'''+(repo/'bench/nanobench_impl.cc').as_posix()+'''")
  target_include_directories(g01_ragged_nb SYSTEM PUBLIC "'''+(repo/'third_party/nanobench').as_posix()+'''")
  add_executable(g01_cpu_ragged_bench "'''+(repo/'bench/inference_resident_sdpa/cpu_ragged_bench.cc').as_posix()+'''" "'''+(repo/'bench/inference_resident_sdpa/cpu_ragged_reference.cc').as_posix()+'''")
  target_compile_features(g01_cpu_ragged_bench PRIVATE cxx_std_23)
  target_include_directories(g01_cpu_ragged_bench PRIVATE "'''+(repo/'src/compute_ggml_runtime').as_posix()+'''")
  target_link_libraries(g01_cpu_ragged_bench PRIVATE hyle::compute hyle_compute_ggml_runtime hyle_compute_provider_ggml ggml g01_ragged_nb)
  hyle_apply_warnings(g01_cpu_ragged_bench)
  hyle_stage_runtime(g01_cpu_ragged_bench)
 endfunction()
 cmake_language(DEFER CALL g01_ragged_bench)
endif()
'''
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
record=out/'cpu-ragged-bench-checks.json';records=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args,extra=None):
 n=1+sum(x['stage']==stage for x in records);log=out/f'cpu-ragged-bench-{stage}-{n}.log';start=time.monotonic();runenv=env.copy();runenv.update(extra or {})
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=runenv,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 record.write_text(json.dumps({'scope':'diagnostic adapter preflight, not qualified P1','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2400));print(f.read(2400).decode(errors='replace'))
  raise SystemExit(r.returncode)
if next((x for x in reversed(records) if x['stage']=='configure'),{}).get('exit_code')!=0:
 run('configure',['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
run('build',['cmake','--build',str(build),'--target','g01_cpu_ragged_bench','--parallel','4'])
run('oracle',[str(build/'bin/g01_cpu_ragged_bench.exe')],{'HYLE_BENCH_VERIFY_ONLY':'1'})
