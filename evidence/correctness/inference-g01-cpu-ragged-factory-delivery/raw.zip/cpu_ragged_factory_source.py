from pathlib import Path
old=Path('.scratch/inference-gaps/g01/cpu_ragged_source.py').read_text()
old=old.replace('cpu-ragged-public-source','cpu-ragged-factory2-public-source')
old=old.replace('cpu-ragged-public-project','cpu-ragged-factory2-public-project')
old=old.replace(' hyle_compute_provider_ggml)',' )')
old=old.replace('642cc1e67566994a85a65adbe0db8956c1d0350a','973d3ffbf642aff06f6316fcec4b3cc99eba2e4d')
old=old.replace('source-only factory target explicit','public facade factory declaration/root mapping')
exec(compile(old,__file__,'exec'))
