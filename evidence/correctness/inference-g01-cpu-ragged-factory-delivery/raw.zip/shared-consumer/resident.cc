#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <hyle/compute/cpu.h>
#include <hyle/compute/prepared_operation.h>
#include <hyle/compute/providers/ggml_cpu.h>
#include <hyle/mem/buffer.h>
#include <vector>
namespace c = hyle::compute;
using hyle::Status;
Status run() {
  HYLE_ASSIGN_OR_RETURN(auto context,
                        c::cpu::create_context({.native_threads = 1}));
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  for (bool bshd : {false, true})
    for (auto rows : {1, 17}) {
      constexpr std::int64_t hq = 8, hk = 2, d = 256, nk = 31, cap = 37;
      const auto shape = [&](std::int64_t n, std::int64_t h) {
        return bshd ? std::array<std::int64_t, 4>{1, n, h, d}
                    : std::array<std::int64_t, 4>{1, h, n, d};
      };
      HYLE_ASSIGN_OR_RETURN(
          auto qd,
          c::TensorDesc::dense(c::DataType::kBFloat16, shape(rows, hq)));
      HYLE_ASSIGN_OR_RETURN(
          auto physical,
          c::TensorDesc::dense(c::DataType::kBFloat16, shape(cap, hk)));
      HYLE_ASSIGN_OR_RETURN(auto kd, c::TensorDesc::strided_bytes(
                                         c::DataType::kBFloat16, shape(nk, hk),
                                         physical.byte_strides()));
      HYLE_ASSIGN_OR_RETURN(
          auto prepared,
          c::prepare(
              context,
              c::ScaledDotProductAttention{
                  .layout = bshd ? c::AttentionLayout::kBatchSequenceHeadDepth
                                 : c::AttentionLayout::kBatchHeadSequenceDepth,
                  .scale = 0.0625F,
                  .causal = true},
              qd, kd, kd));
      if (prepared.provider().id != c::ggml_cpu::kProviderId)
        return Status::Internal(
            "ordinary CPU resident cache did not select mature ggml");
      HYLE_ASSIGN_OR_RETURN(auto slot, prepared.create_invocation());
      const auto encode = [](float x) {
        return std::uint16_t(std::bit_cast<std::uint32_t>(x) >> 16);
      };
      const auto decode = [](std::uint16_t x) {
        return std::bit_cast<float>(std::uint32_t(x) << 16);
      };
      std::vector<std::uint16_t> q(*qd.element_count(), 0),
          k(*physical.element_count(), encode(1.F)), v(k.size(), encode(128.F)),
          actual(q.size());
      const auto at = [&](int row, int h, int depth, int n, int heads) {
        return bshd ? (row * heads + h) * d + depth : (h * n + row) * d + depth;
      };
      for (int seed : {0, 1}) {
        for (int h = 0; h < hk; ++h)
          for (int t = 0; t < nk; ++t)
            for (int z = 0; z < d; ++z)
              v[at(t, h, z, cap, hk)] =
                  encode(h * .25F + t * .03125F + seed * .5F);
        auto buffer = [](std::span<const std::uint16_t> data)
            -> hyle::Result<hyle::mem::Buffer> {
          HYLE_ASSIGN_OR_RETURN(auto result, hyle::mem::Buffer::create(
                                                 hyle::mem::system_resource(),
                                                 data.size_bytes(), 64));
          HYLE_RETURN_IF_ERROR(result.view().write(std::as_bytes(data)));
          return result;
        };
        HYLE_ASSIGN_OR_RETURN(auto qb, buffer(q));
        HYLE_ASSIGN_OR_RETURN(auto kb, buffer(k));
        HYLE_ASSIGN_OR_RETURN(auto vb, buffer(v));
        HYLE_ASSIGN_OR_RETURN(auto output, buffer(actual));
        HYLE_ASSIGN_OR_RETURN(auto qv,
                              c::ConstTensorView::create(qd, qb.view()));
        HYLE_ASSIGN_OR_RETURN(auto kv,
                              c::ConstTensorView::create(kd, kb.view()));
        HYLE_ASSIGN_OR_RETURN(auto vv,
                              c::ConstTensorView::create(kd, vb.view()));
        HYLE_ASSIGN_OR_RETURN(auto ov,
                              c::TensorView::create(qd, output.view()));
        const std::array inputs{qv, kv, vv};
        HYLE_ASSIGN_OR_RETURN(auto done,
                              slot.submit(queue, inputs, std::span(&ov, 1)));
        HYLE_RETURN_IF_ERROR(done.wait());
        HYLE_RETURN_IF_ERROR(
            output.view().read(std::as_writable_bytes(std::span(actual))));
        for (int h = 0; h < hq; ++h)
          for (int row = 0; row < rows; ++row)
            for (int z = 0; z < d; ++z) {
              const int visible = nk - rows + row + 1;
              const float expected =
                  (h / 4) * .25F + (visible - 1) * .015625F + seed * .5F;
              if (std::abs(decode(actual[at(row, h, z, rows, hq)]) - expected) >
                  .008F)
                return Status::Internal(
                    "resident GQA numeric/padding mismatch");
            }
        std::vector<std::uint16_t> after(v.size());
        HYLE_RETURN_IF_ERROR(
            vb.view().read(std::as_writable_bytes(std::span(after))));
        if (after != v)
          return Status::Internal("readonly cache changed");
        HYLE_RETURN_IF_ERROR(
            kb.view().read(std::as_writable_bytes(std::span(after))));
        if (after != k)
          return Status::Internal("readonly key cache changed");
      }
    }
  return context.close();
}
int main() {
  auto status = run();
  if (!status.ok()) {
    std::fprintf(stderr, "%.*s\n", int(status.message().size()),
                 status.message().data());
    return 1;
  }
  std::puts("public CPU BF16 GQA8/2 D256 two layouts/decode/prefill/resident "
            "padding/replay PASS");
}
