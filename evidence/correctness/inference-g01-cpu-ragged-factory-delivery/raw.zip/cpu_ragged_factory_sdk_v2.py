from pathlib import Path
old=Path('.scratch/inference-gaps/g01/cpu_ragged_sdk_windows.py').read_text()
old=old.replace("('g01-ragged-'+mode+'-sdk')","('g01-ragged-factory2-'+mode+'-sdk')")
old=old.replace("cpu-ragged-win-{mode}-sdk","cpu-ragged-factory2-win-{mode}-sdk")
old=old.replace('642cc1e67566994a85a65adbe0db8956c1d0350a','973d3ffbf642aff06f6316fcec4b3cc99eba2e4d')
exec(compile(old,__file__,'exec'))
