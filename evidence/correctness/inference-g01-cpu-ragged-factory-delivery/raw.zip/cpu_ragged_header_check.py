from pathlib import Path
import subprocess,os,time,json
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
rows=[]
for mode in ['static','shared']:
 attempt=1+len(list(out.glob(f'cpu-ragged-factory-header-{mode}-*.log')));log=out/f'cpu-ragged-factory-header-{mode}-{attempt}.log'
 args=[str(Path(env['VCToolsInstallDir'])/'bin/Hostx64/x64/cl.exe'),'/nologo','/c','/std:c++latest','/EHsc','/W4','/WX','/utf-8','/Zc:__cplusplus','/Zc:preprocessor','/I'+str(Path('C:/h7')/f'g01-ragged-factory2-{mode}-sdk/relocated/include'),'/Fo'+str(out/f'cpu-ragged-factory-header-{mode}.obj'),str(out/'cpu_ragged_header.cc')]
 if mode=='static':args.insert(1,'/DHYLE_STATIC')
 start=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'mode':mode,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)})
 if r.returncode:
  print(log.read_text(encoding='utf-8'));raise SystemExit(r.returncode)
(out/'cpu-ragged-factory-header-result.json').write_text(json.dumps({'scope':'self-contained installed public factory header, macro-independent declaration, compile only','candidate':'973d3ffbf642aff06f6316fcec4b3cc99eba2e4d','stages':rows},indent=2)+'\n');print(json.dumps(rows))
