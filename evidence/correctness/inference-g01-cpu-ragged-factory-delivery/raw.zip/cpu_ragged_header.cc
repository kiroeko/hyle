#if defined(HYLE_COMPUTE_GGML_CPU)
#undef HYLE_COMPUTE_GGML_CPU
#endif
#include <hyle/compute/providers/ggml_cpu.h>
using Factory=hyle::compute::Provider (*)(hyle::compute::ggml_cpu::Options) noexcept;
Factory delivered_cpu_factory=&hyle::compute::ggml_cpu::provider;
