from pathlib import Path
import subprocess,time,json,os
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';exe=repo/'.scratch/build-compute-v2-dev/bin/g01_cpu_ragged_bench.exe'
attempt=1+max([int(p.stem.rsplit('-',1)[1]) for p in out.glob('cpu-ragged-diagnostic-cost-*.json')],default=0)
start=time.monotonic();log=out/f'cpu-ragged-diagnostic-cost-{attempt}.log'
with log.open('w',encoding='utf-8') as f:r=subprocess.run([str(exe)],stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())
row={'classification':'diagnostic cost preflight only; no AA/placement/process qualification, no performance verdict','exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)}
(out/f'cpu-ragged-diagnostic-cost-{attempt}.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1600));print(f.read(1600).decode(errors='replace'))
raise SystemExit(r.returncode)
