#!/usr/bin/env bash
set -euo pipefail
r1_source=$1
r1_root=$2
r1_platform=$3
case "$r1_root" in
  /root/hyle-validation/r1-20260915-d4006bf7|/Users/kiro/hyle-validation/r1-20260915-d4006bf7) ;;
  *) printf '%s\n' 'Unexpected verification root' >&2; exit 2 ;;
esac
export PATH=/opt/homebrew/bin:$PATH
cd "$r1_source"
printf 'source=%s\nplatform=%s\n' "$r1_source" "$r1_platform"
scripts/hyle-unix.sh --print-toolchain
uname -a
r1_profiles='cpu none'
if [ "$r1_platform" = linux ]; then r1_profiles='cpu none cuda'; fi
for r1_profile in $r1_profiles; do
  for r1_product in compute graph; do
    r1_output="$r1_root/$r1_platform-$r1_profile-$r1_product-37dc8b54"
    if [ -e "$r1_output" ]; then printf 'Use a fresh smoke directory: %s\n' "$r1_output" >&2; exit 2; fi
    mkdir -p "$r1_output"
    r1_cpu=OFF
    r1_cuda=OFF
    if [ "$r1_profile" = cpu ]; then r1_cpu=ON; fi
    if [ "$r1_profile" = cuda ]; then r1_cuda=ON; fi
    printf 'START %s / %s\n' "$r1_profile" "$r1_product"
    if scripts/hyle-unix.sh cmake -DHYLE_SOURCE_DIR="$r1_source" -DHYLE_SMOKE_ROOT="$r1_output" \
      -DHYLE_SMOKE_COMPONENT="$r1_product" -DHYLE_SMOKE_GENERATOR=Ninja \
      -DHYLE_SMOKE_COMPUTE_CPU="$r1_cpu" -DHYLE_SMOKE_COMPUTE_CUDA="$r1_cuda" \
      -DHYLE_SMOKE_COMPUTE_ONEDNN=OFF -P cmake/HyleCiSelectedComponentSmoke.cmake > "$r1_output/smoke.log" 2>&1; then
      printf 'PASS %s / %s (source/static/shared/relocated)\n' "$r1_profile" "$r1_product"
    else
      r1_status=$?
      tail -n 45 "$r1_output/smoke.log"
      exit "$r1_status"
    fi
  done
done
