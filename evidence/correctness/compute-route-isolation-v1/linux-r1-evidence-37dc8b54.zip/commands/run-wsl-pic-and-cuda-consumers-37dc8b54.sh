#!/usr/bin/env bash
set -euo pipefail
r1_root=/root/hyle-validation/r1-20260915-d4006bf7
r1_source="$r1_root/source-37dc8b54"
export PATH=/usr/local/cuda-13.3/bin:$PATH
cd "$r1_source"
r1_pic="$r1_root/linux-cpu-graph-37dc8b54-pic"
if [ -e "$r1_pic" ]; then printf 'Expected fresh PIC SDK directory\n' >&2; exit 2; fi
mkdir -p "$r1_pic"
printf 'START static CPU SDK with PIC for shared-library consumer\n'
if (
  scripts/hyle-unix.sh cmake -S "$r1_source" -B "$r1_pic/sdk-build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_POSITION_INDEPENDENT_CODE=ON \
    -DHYLE_COMPONENTS=graph -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_CUDA=OFF \
    -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_STATIC=ON -DHYLE_INSTALL=ON \
    -DHYLE_BUILD_TESTS=OFF -DHYLE_BUILD_BENCH=OFF -DCMAKE_INSTALL_PREFIX="$r1_pic/static-sdk-staging" &&
  scripts/hyle-unix.sh cmake --build "$r1_pic/sdk-build" --parallel 2 &&
  scripts/hyle-unix.sh cmake --install "$r1_pic/sdk-build" &&
  mv "$r1_pic/static-sdk-staging" "$r1_pic/static-sdk-relocated"
) > "$r1_pic/sdk.log" 2>&1; then
  printf 'PASS static CPU PIC SDK build/install/relocation\n'
else
  r1_status=$?
  tail -n 45 "$r1_pic/sdk.log"
  exit "$r1_status"
fi

for r1_case in cpu-static cuda-source cuda-shared cuda-static; do
  r1_profile=${r1_case%-*}
  r1_shape=${r1_case#*-}
  r1_suffix=''
  if [ "$r1_profile" = cpu ]; then r1_suffix=-pic; fi
  r1_output="$r1_root/custom-linux-$r1_profile-$r1_shape-37dc8b54$r1_suffix"
  if [ -e "$r1_output" ]; then printf 'Expected fresh consumer directory\n' >&2; exit 2; fi
  mkdir -p "$r1_output"
  r1_cuda=ON
  if [ "$r1_profile" = cpu ]; then r1_cuda=OFF; fi
  r1_args=(-S "$r1_source/samples/package/graph/custom_kernel" -B "$r1_output/build"
    -G Ninja -DCMAKE_BUILD_TYPE=Release "-DHYLE_SAMPLE_CUDA=$r1_cuda")
  if [ "$r1_profile" = cpu ]; then
    r1_args+=("-DCMAKE_PREFIX_PATH=$r1_pic/static-sdk-relocated")
  elif [ "$r1_shape" = source ]; then
    r1_args+=("-DHYLE_SAMPLE_SOURCE=$r1_source" -DHYLE_COMPUTE_CPU=OFF
      -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_INSTALL=OFF)
  else
    r1_args+=("-DCMAKE_PREFIX_PATH=$r1_root/linux-cuda-graph-37dc8b54-native-sdk/selected-graph/$r1_shape-sdk-relocated")
  fi
  printf 'START custom execution / linux / %s / %s%s\n' "$r1_profile" "$r1_shape" "$r1_suffix"
  if (
    scripts/hyle-unix.sh cmake "${r1_args[@]}" &&
    scripts/hyle-unix.sh cmake --build "$r1_output/build" --parallel 2 &&
    scripts/hyle-unix.sh ctest --test-dir "$r1_output/build" --output-on-failure --no-tests=error --timeout 90
  ) > "$r1_output/sample.log" 2>&1; then
    printf 'PASS custom execution / linux / %s / %s%s\n' "$r1_profile" "$r1_shape" "$r1_suffix"
  else
    r1_status=$?
    tail -n 45 "$r1_output/sample.log"
    exit "$r1_status"
  fi
done
