#!/usr/bin/env bash
set -euo pipefail
r1_source=$1
r1_root=$2
r1_platform=$3
case "$r1_root" in
  /root/hyle-validation/r1-20260915-d4006bf7|/Users/kiro/hyle-validation/r1-20260915-d4006bf7) ;;
  *) printf '%s\n' 'Unexpected verification root' >&2; exit 2 ;;
esac
export PATH=/opt/homebrew/bin:/usr/local/cuda-13.3/bin:$PATH
cd "$r1_source"
r1_profiles=cpu
if [ "$r1_platform" = linux ]; then r1_profiles='cpu cuda'; fi
r1_platform_args=()
if [ "$r1_platform" = macos ]; then r1_platform_args=(-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4); fi
for r1_profile in $r1_profiles; do
  for r1_shape in source shared static; do
    r1_output="$r1_root/custom-$r1_platform-$r1_profile-$r1_shape-37dc8b54"
    if [ -e "$r1_output" ]; then printf 'Expected fresh directory: %s\n' "$r1_output" >&2; exit 2; fi
    mkdir -p "$r1_output"
    r1_cpu=OFF
    r1_cuda=OFF
    if [ "$r1_profile" = cpu ]; then r1_cpu=ON; else r1_cuda=ON; fi
    r1_args=(-S "$r1_source/samples/package/graph/custom_kernel" -B "$r1_output/build"
      -G Ninja -DCMAKE_BUILD_TYPE=Release "-DHYLE_SAMPLE_CUDA=$r1_cuda" "${r1_platform_args[@]}")
    if [ "$r1_shape" = source ]; then
      r1_args+=("-DHYLE_SAMPLE_SOURCE=$r1_source" "-DHYLE_COMPUTE_CPU=$r1_cpu"
        "-DHYLE_COMPUTE_CUDA=$r1_cuda" -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_INSTALL=OFF)
    else
      r1_sdk_suffix=''
      if [ "$r1_platform" = linux ] && [ "$r1_profile" = cuda ]; then r1_sdk_suffix=-native-sdk; fi
      r1_args+=("-DCMAKE_PREFIX_PATH=$r1_root/$r1_platform-$r1_profile-graph-37dc8b54$r1_sdk_suffix/selected-graph/$r1_shape-sdk-relocated")
    fi
    printf 'START custom execution / %s / %s / %s\n' "$r1_platform" "$r1_profile" "$r1_shape"
    if (
      scripts/hyle-unix.sh cmake "${r1_args[@]}" &&
      scripts/hyle-unix.sh cmake --build "$r1_output/build" --config Release --parallel 2 &&
      scripts/hyle-unix.sh ctest --test-dir "$r1_output/build" -C Release --output-on-failure --no-tests=error --timeout 90
    ) > "$r1_output/sample.log" 2>&1; then
      printf 'PASS custom execution / %s / %s / %s\n' "$r1_platform" "$r1_profile" "$r1_shape"
    else
      r1_status=$?
      tail -n 45 "$r1_output/sample.log"
      exit "$r1_status"
    fi
  done
done
