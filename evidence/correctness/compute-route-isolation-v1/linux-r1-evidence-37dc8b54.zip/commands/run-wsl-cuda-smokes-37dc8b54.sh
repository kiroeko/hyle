#!/usr/bin/env bash
set -euo pipefail
r1_root=/root/hyle-validation/r1-20260915-d4006bf7
r1_source="$r1_root/source-37dc8b54"
export PATH=/usr/local/cuda-13.3/bin:$PATH
cd "$r1_source"
command -v nvcc
nvcc --version
for r1_product in compute graph; do
  r1_output="$r1_root/linux-cuda-$r1_product-37dc8b54-native-sdk"
  if [ -e "$r1_output" ]; then printf 'Expected fresh directory: %s\n' "$r1_output" >&2; exit 2; fi
  mkdir -p "$r1_output"
  printf 'START CUDA native SDK / %s\n' "$r1_product"
  if scripts/hyle-unix.sh cmake -DHYLE_SOURCE_DIR="$r1_source" -DHYLE_SMOKE_ROOT="$r1_output" \
    -DHYLE_SMOKE_COMPONENT="$r1_product" -DHYLE_SMOKE_GENERATOR=Ninja \
    -DHYLE_SMOKE_COMPUTE_CPU=OFF -DHYLE_SMOKE_COMPUTE_CUDA=ON \
    -DHYLE_SMOKE_COMPUTE_ONEDNN=OFF -P cmake/HyleCiSelectedComponentSmoke.cmake > "$r1_output/smoke.log" 2>&1; then
    printf 'PASS CUDA native SDK / %s (source/static/shared/relocated)\n' "$r1_product"
  else
    r1_status=$?
    tail -n 45 "$r1_output/smoke.log"
    exit "$r1_status"
  fi
done
