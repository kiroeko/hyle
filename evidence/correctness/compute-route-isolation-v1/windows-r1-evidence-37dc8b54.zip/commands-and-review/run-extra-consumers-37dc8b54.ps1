$ErrorActionPreference = 'Stop'
$r1Repo = 'C:\public\project-hyle\hyle'
$r1Scratch = 'C:\hyle-scratch\r1-20260915-d4006bf7'
Set-Location -LiteralPath $r1Repo
$r1Vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$r1Vs = & $r1Vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $r1Vs) { throw 'MSVC installation missing' }
$r1Dev = Join-Path $r1Vs 'Common7\Tools\VsDevCmd.bat'
$r1Command = 'call "' + $r1Dev + '" -arch=x64 >nul && set'
$r1Environment = & $env:ComSpec /d /s /c $r1Command
if ($LASTEXITCODE -ne 0) { throw 'MSVC initialization failed' }
foreach ($r1Line in $r1Environment) {
    $r1Split = $r1Line.IndexOf('=')
    if ($r1Split -le 0) { continue }
    $r1Name = $r1Line.Substring(0, $r1Split)
    $r1Value = $r1Line.Substring($r1Split + 1)
    if ($r1Name -ieq 'Path' -and $r1Value -notlike "*$r1Vs\VC\Tools\MSVC\*") { continue }
    [Environment]::SetEnvironmentVariable($r1Name, $r1Value, 'Process')
}
if ((git rev-parse HEAD).Trim() -ne '37dc8b542d52361cfa7b6cc176dc65555941e48d') { throw 'Candidate changed' }
function Invoke-R1Command([string]$r1Log, [string[]]$r1Arguments) {
  & cmake @r1Arguments *>> $r1Log
  if ($LASTEXITCODE -ne 0) { Get-Content $r1Log -Tail 40; throw "Command failed: $r1Log" }
}
foreach ($r1Profile in @('cpu','cuda')) {
  foreach ($r1Shape in @('source','shared','static')) {
    $r1Output = "$r1Scratch\custom-$r1Profile-$r1Shape-37dc8b54"
    if (Test-Path $r1Output) { throw 'Expected fresh custom sample directory' }
    New-Item -ItemType Directory -Path $r1Output | Out-Null
    $r1Cpu = if ($r1Profile -eq 'cpu') { 'ON' } else { 'OFF' }
    $r1Cuda = if ($r1Profile -eq 'cuda') { 'ON' } else { 'OFF' }
    $r1Arguments = @('-S', "$r1Repo\samples\package\graph\custom_kernel", '-B', "$r1Output\build", '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', "-DHYLE_SAMPLE_CUDA=$r1Cuda")
    if ($r1Shape -eq 'source') {
      $r1Arguments += @("-DHYLE_SAMPLE_SOURCE=$r1Repo", "-DHYLE_COMPUTE_CPU=$r1Cpu", "-DHYLE_COMPUTE_CUDA=$r1Cuda", '-DHYLE_COMPUTE_ONEDNN=OFF', '-DHYLE_INSTALL=OFF')
    } else {
      $r1Arguments += "-DCMAKE_PREFIX_PATH=$r1Scratch\win-$r1Profile-graph-37dc8b54\selected-graph\$r1Shape-sdk-relocated"
    }
    Invoke-R1Command "$r1Output\sample.log" $r1Arguments
    Invoke-R1Command "$r1Output\sample.log" @('--build', "$r1Output\build", '--config', 'Release', '--parallel', '2')
    & ctest --test-dir "$r1Output\build" -C Release --output-on-failure --no-tests=error --timeout 90 *>> "$r1Output\sample.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$r1Output\sample.log" -Tail 40; throw 'Custom sample failed' }
    Write-Host "PASS custom execution / $r1Profile / $r1Shape"
  }
}
$r1Negative = "$r1Scratch\cpu-executor-absent-37dc8b54"
if (Test-Path $r1Negative) { throw 'Expected fresh negative configure directory' }
New-Item -ItemType Directory -Path $r1Negative | Out-Null
& cmake -S "$r1Repo\samples\package\graph\cpu_executor" -B "$r1Negative\build" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DHYLE_SAMPLE_SOURCE=$r1Repo" -DHYLE_COMPUTE_CPU=OFF -DHYLE_INSTALL=OFF *> "$r1Negative\configure.log"
if ($LASTEXITCODE -eq 0 -or (Get-Content -Raw "$r1Negative\configure.log") -notmatch 'CPU executor sample requires HYLE_COMPUTE_CPU=ON') { throw 'CPU absence diagnostic missing' }
Write-Host 'PASS CPU executor missing capability diagnostic'
exit 0
