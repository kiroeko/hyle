$ErrorActionPreference = 'Stop'
$r1Repo = 'C:\public\project-hyle\hyle'
$r1Root = 'C:\hyle-scratch\r1-20260915-d4006bf7'
Set-Location -LiteralPath $r1Repo
$r1Candidate = (& git rev-parse HEAD).Trim()
if ($r1Candidate -ne '37dc8b542d52361cfa7b6cc176dc65555941e48d') { throw 'Candidate changed' }
foreach ($r1Profile in @('cpu', 'none', 'cuda')) {
    foreach ($r1Product in @('compute', 'graph')) {
        $r1Output = [IO.Path]::GetFullPath((Join-Path $r1Root "win-$r1Profile-$r1Product-37dc8b54"))
        if (-not $r1Output.StartsWith($r1Root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe scratch path' }
        if (Test-Path -LiteralPath $r1Output) { throw "Use a fresh smoke directory: $r1Output" }
        New-Item -ItemType Directory -Path $r1Output | Out-Null
        $r1Cpu = if ($r1Profile -eq 'cpu') { 'ON' } else { 'OFF' }
        $r1Cuda = if ($r1Profile -eq 'cuda') { 'ON' } else { 'OFF' }
        Write-Host "START $r1Profile / $r1Product"
        & scripts/hyle-windows.ps1 -Action SelectedComponentSmoke -Component $r1Product -SmokeRoot $r1Output -ExtraArgs @("-DHYLE_SMOKE_COMPUTE_CPU=$r1Cpu", "-DHYLE_SMOKE_COMPUTE_CUDA=$r1Cuda", '-DHYLE_SMOKE_COMPUTE_ONEDNN=OFF') *> "$r1Output\smoke.log"
        if ($LASTEXITCODE -ne 0) {
            Get-Content "$r1Output\smoke.log" -Tail 45
            exit $LASTEXITCODE
        }
        Write-Host "PASS $r1Profile / $r1Product (source/static/shared/relocated)"
    }
}
