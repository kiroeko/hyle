from pathlib import Path
import hashlib,json,subprocess

ROOT=Path(__file__).resolve().parents[3]
name='mlx/backend/metal/kernels/sdpa_vector.h';file=ROOT/'.scratch/inference-gaps/g04-g05/apple-native/mlx-preview'/name
before=file.read_text(encoding='utf-8');after=before
for stride,initial in [('BN','simd_gid'),('blocks','block_idx')]:
 old=f'  for (int i = (first_key / {stride}) * {stride} + {initial}; i < last_key; i += {stride}) {{'
 new=(f'  if (!hyle_paged && !hyle_q8) {{\n'
      f'    keys += (first_key / {stride}) * {stride} * k_seq_stride;\n'
      f'    values += (first_key / {stride}) * {stride} * v_seq_stride;\n  }}\n'+old)
 assert after.count(old)==1;after=after.replace(old,new)
path=ROOT/'third_party/mlx_cast/patches.json';manifest=json.loads(path.read_text(encoding='utf-8'))
entry=next(p for p in manifest['files'] if p['path']==name)
assert hashlib.sha256(before.encode()).hexdigest()==entry['after_sha256']
entry['edits'].append({'before':before,'after':after});entry['after_sha256']=hashlib.sha256(after.encode()).hexdigest()
file.write_text(after,encoding='utf-8',newline='\n');path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
notice=ROOT/'third_party/mlx_cast/NOTICE.md'
note='''
The finite HYLE cache adapter additionally supports Q8_0 block32/34-byte
rows, separate QK/VO depths and causal inclusive left windows. The original
vector/two-pass/steel loaders decode inline half scales and signed codes in
F32, without materializing the historical K/V arrays. Encoded queries and
outputs use bounded active-row F32 conversion; two-pass partials stay F32.
Steel uses independent BD/BV tiles, with a finite smaller D256 F32 tile to
respect Metal threadgroup memory limits. Plain coupled/unbounded NAX and GQA
paths remain original. Window loops restrict the effective row range; cache
keys include encoding/paging/window function constants. These adapters retain
the original MLX runtime, queues, MMA/softmax and completion ownership.
'''
notice.write_bytes(notice.read_bytes().replace(b'\r\n',b'\n')+note.encode())
directory=ROOT/'third_party/mlx_cast'
tree=''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(b"\r\n",b"\n")).hexdigest()}\n'
 for p in sorted(directory.rglob('*'),key=lambda p:p.relative_to(directory).as_posix()) if p.is_file())
digest=hashlib.sha256(tree.encode()).hexdigest()
original=subprocess.check_output(['git','show','HEAD:cmake/HyleDependencyLock.json'],cwd=ROOT)
start=original.index(b'"name": "mlx_cast_patches"');index=original.index(b'"tree_sha256": "',start)+len(b'"tree_sha256": "')
(ROOT/'cmake/HyleDependencyLock.json').write_bytes(original[:index]+digest.encode()+original[index+64:])
print(digest)
