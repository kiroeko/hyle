from pathlib import Path
import difflib, hashlib, json

ROOT = Path(__file__).resolve().parents[3]
ORIGINAL = ROOT / '.scratch/inference-gaps/g01/native-paged/mlx-original'
PREVIEW = ROOT / '.scratch/inference-gaps/g04-g05/apple-native/mlx-preview'
MANIFEST = ROOT / 'third_party/mlx_cast/patches.json'
manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
texts = {}
initial = {}

def read(name):
    if name not in texts:
        raw = (ORIGINAL / name).read_bytes().replace(b'\r\n', b'\n')
        patch = next((p for p in manifest['files'] if p['path'] == name), None)
        if patch:
            assert hashlib.sha256(raw).hexdigest() == patch['before_sha256'], name
            for edit in patch['edits']:
                before = edit['before'].encode()
                assert raw.count(before) == 1, (name, before[:100])
                raw = raw.replace(before, edit['after'].encode(), 1)
            assert hashlib.sha256(raw).hexdigest() == patch['after_sha256'], name
        texts[name] = initial[name] = raw.decode()
    return texts[name]

def replace(name, before, after, count=1):
    text = read(name)
    assert text.count(before) == count, (name, before[:100], text.count(before), count)
    texts[name] = text.replace(before, after)

fast = 'mlx/fast.h'
replace(fast, 'int logical_rows, int table_offset, float scale, bool causal, Stream stream);',
    'int logical_rows, int table_offset, float scale, bool causal, Stream stream,\n'
    '    bool q8 = false, int window_left = -1);\n'
    'MLX_API array hyle_ragged_attention(\n'
    '    const array& q, const array& k, const array& v, float scale, bool causal,\n'
    '    Stream stream, bool q8 = false, int window_left = -1);')
primitive = 'mlx/fast_primitives.h'
replace(primitive, 'HylePagedAttention(Stream stream, int rows, int offset, float scale, bool causal)',
    'HylePagedAttention(Stream stream, int rows, int offset, float scale, bool causal,\n'
    '      bool q8, int window)')
replace(primitive, 'rows_(rows), offset_(offset), scale_(scale), causal_(causal) {}',
    'rows_(rows), offset_(offset), scale_(scale), causal_(causal), q8_(q8), window_(window) {}')
replace(primitive, 'scale_ == p.scale_ && causal_ == p.causal_;',
    'scale_ == p.scale_ && causal_ == p.causal_ && q8_ == p.q8_ && window_ == p.window_;')
replace(primitive, 'std::make_tuple(nullptr, rows_, offset_, scale_, causal_)',
    'std::make_tuple(nullptr, rows_, offset_, scale_, causal_, q8_, window_)')
replace(primitive, '  bool causal_;\n};', '  bool causal_, q8_;\n  int window_;\n};')
fastcc = 'mlx/fast.cpp'
text = read(fastcc)
start = text.index('array hyle_paged_attention(')
end = text.index('\narray scaled_dot_product_attention(', start)
texts[fastcc] = text[:start] + '''namespace {
array hyle_cache_attention(const array& q, const array& k, const array& v,
    const std::optional<array>& pages, int rows, int offset, float scale, bool causal,
    Stream stream, bool q8, int window) {
  const int dk = q.shape(-1);
  const int dv = q8 ? v.shape(-1) / 34 * 32 : v.shape(-1);
  if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4 ||
      q.shape(0) != 1 || k.shape(0) != 1 || v.shape(0) != 1 ||
      k.shape(1) != v.shape(1) || k.shape(2) != v.shape(2) ||
      q.shape(2) <= 0 || q.shape(1) <= 0 || k.shape(1) <= 0 || q.shape(1) % k.shape(1) ||
      (dk != 64 && dk != 128 && dk != 256) || (dv != dk && !(dk == 64 && dv == 128)) ||
      (q8 ? (k.dtype() != uint8 || v.dtype() != uint8 ||
             k.shape(-1) != dk / 32 * 34 || v.shape(-1) != dv / 32 * 34) :
            (k.dtype() != q.dtype() || v.dtype() != q.dtype() || k.shape(-1) != dk)) ||
      (q.dtype() != float16 && q.dtype() != bfloat16) || rows <= 0 ||
      (causal && rows < q.shape(2)) || window < -1 || (!causal && window != -1) ||
      !std::isfinite(scale) ||
      (pages && (k.shape(2) % 16 || pages->ndim() != 1 || pages->dtype() != int32 ||
          pages->strides(0) != 1 || offset < 0 ||
          int64_t(offset) + (int64_t(rows) + 15) / 16 > pages->size())) ||
      (!pages && rows != k.shape(2))) {
    throw std::invalid_argument("HYLE cache attention physical/logical/encoding domain");
  }
  auto shape = q.shape(); shape.back() = dv;
  // Q8 can decode to 65532 from a legal F16 encoder input 65504. Keep
  // original tiles and two-pass partials F32 until final output conversion.
  auto query = q8 ? astype(q, float32, stream) : q;
  std::vector<array> inputs{query, k, v};
  if (pages) inputs.push_back(*pages);
  auto result = array(shape, query.dtype(),
      std::make_shared<HylePagedAttention>(stream, rows, pages ? offset : -1,
          scale, causal, q8, window), std::move(inputs));
  return q8 ? astype(result, q.dtype(), stream) : result;
}
}
array hyle_paged_attention(const array& q, const array& k, const array& v,
    const array& pages, int rows, int offset, float scale, bool causal,
    Stream stream, bool q8, int window) {
  return hyle_cache_attention(q,k,v,pages,rows,offset,scale,causal,stream,q8,window);
}
array hyle_ragged_attention(const array& q, const array& k, const array& v,
    float scale, bool causal, Stream stream, bool q8, int window) {
  return hyle_cache_attention(q,k,v,std::nullopt,k.shape(2),-1,scale,causal,stream,q8,window);
}
''' + text[end:]

host = 'mlx/backend/metal/scaled_dot_product_attention.cpp'
replace(host, '  array table;\n  int rows, offset;',
    '  std::optional<array> table;\n  int rows, offset;\n  bool q8;\n  int window;')
replace(host, 'const bool hyle_paged = page.has_value();',
    'const bool hyle_paged = page && page->table.has_value();', 2)
replace(host, 'bool hyle_paged = page.has_value();',
    'bool hyle_paged = page && page->table.has_value();', 2)
replace(host, 'compute_encoder.set_input_array(page->table,',
    'compute_encoder.set_input_array(*page->table,', 4)
replace(host, 'if (page) {\n    compute_encoder.set_input_array(*page->table,',
    'if (page && page->table) {\n    compute_encoder.set_input_array(*page->table,', 4)
# Full native tile: selected encoded/window/Dv paths use original steel,
# leaving original same-D plain NAX available and unchanged.
text = read(host)
start = text.index('void sdpa_full_self_attention_metal(')
end = text.index('\nvoid sdpa_vector(', start)
chunk = text[start:end]
chunk = chunk.replace('  if (', '  if ((!page || (!page->q8 && page->window == -1)) && v.shape(-1) == D && ', 1)
chunk = chunk.replace('  int bd = q.shape(-1);', '  int bd = q.shape(-1);\n  int bv = o.shape(-1);')
chunk = chunk.replace('  const bool hyle_paged = page && page->table.has_value();',
    '  const bool hyle_paged = page && page->table.has_value();\n'
    '  const bool hyle_q8 = page && page->q8;\n'
    '  const bool hyle_window = page && page->window >= 0;')
chunk = chunk.replace('{&hyle_paged, MTL::DataType::DataTypeBool, 303}};',
    '{&hyle_paged, MTL::DataType::DataTypeBool, 303},\n'
    '      {&hyle_q8, MTL::DataType::DataTypeBool, 304},\n'
    '      {&hyle_window, MTL::DataType::DataTypeBool, 305}};')
chunk = chunk.replace('  std::string hash_name;', '  base_name += "_bv" + std::to_string(bv);\n  std::string hash_name;')
chunk = chunk.replace('  if (page) hash_name += "_hyle_page16";',
    '  if (page) hash_name += "_hyle_" + std::to_string(hyle_paged) + "_" +\n'
    '      std::to_string(hyle_q8) + "_" + std::to_string(hyle_window);')
chunk = chunk.replace('      (has_mask ? *mask : q));', '      (has_mask ? *mask : q), bv);')
chunk = chunk.replace('  compute_encoder.set_bytes(params, 4);',
    '  compute_encoder.set_bytes(params, 4);\n'
    '  if (hyle_window) compute_encoder.set_bytes(page->window, 10);')
texts[host] = text[:start] + chunk + text[end:]
# Vector kernels already support separate D/V; use logical output Dv rather
# than U8 carrier bytes, and qualify function constants in original pipeline.
text = read(host)
for name in ['sdpa_vector', 'sdpa_vector_2pass']:
    start = text.index('void ' + name + '(')
    end = text.index('\n}', start) + 2
    chunk = text[start:end]
    chunk = chunk.replace('v.shape(-1)', ('o.shape(-1)' if name == 'sdpa_vector' else 'out.shape(-1)'))
    chunk = chunk.replace('  bool hyle_paged = page && page->table.has_value();',
        '  bool hyle_paged = page && page->table.has_value();\n'
        '  bool hyle_q8 = page && page->q8;\n'
        '  bool hyle_window = page && page->window >= 0;')
    chunk = chunk.replace('{&hyle_paged, MTL::DataType::DataTypeBool, 27},',
        '{&hyle_paged, MTL::DataType::DataTypeBool, 27},\n'
        '      {&hyle_q8, MTL::DataType::DataTypeBool, 28},\n'
        '      {&hyle_window, MTL::DataType::DataTypeBool, 29},')
    chunk = chunk.replace('  if (page) hash_name += "_hyle_page16";',
        '  if (page) hash_name += "_hyle_" + std::to_string(hyle_paged) + "_" +\n'
        '      std::to_string(hyle_q8) + "_" + std::to_string(hyle_window);')
    chunk = chunk.replace('  compute_encoder.set_input_array(v, 2);',
        '  compute_encoder.set_input_array(v, 2);\n'
        '  if (hyle_window) compute_encoder.set_bytes(page->window, 21);')
    if name == 'sdpa_vector_2pass':
        chunk = chunk.replace('if (!mask && !sinks &&',
            'if ((!page || (!page->q8 && page->window == -1)) && !mask && !sinks &&')
    text = text[:start] + chunk + text[end:]
texts[host] = text
replace(host, 'bool do_causal = do_causal_ && q.shape(2) > 1;',
    'bool do_causal = do_causal_ && (q.shape(2) > 1 || (page && page->window >= 0));')
replace(host, '''  if (inputs.size() != 4) throw std::invalid_argument("HYLE paged attention needs four inputs");
  eval_sdpa_native(inputs, outputs, stream(), scale_, causal_, false,
                   HylePageInfo{inputs[3], rows_, offset_});''',
    '''  if (inputs.size() != (offset_ < 0 ? 3u : 4u))
    throw std::invalid_argument("HYLE cache attention input arity");
  eval_sdpa_native(inputs, outputs, stream(), scale_, causal_, false,
      HylePageInfo{offset_ < 0 ? std::nullopt : std::optional<array>{inputs[3]},
                   rows_, offset_, q8_, window_});''')

vector = 'mlx/backend/metal/kernels/sdpa_vector.h'
replace(vector, 'constant bool hyle_paged [[function_constant(27)]];',
    '''constant bool hyle_paged [[function_constant(27)]];
constant bool hyle_q8 [[function_constant(28)]];
constant bool hyle_window [[function_constant(29)]];
inline float hyle_q8_read(const device uchar* row, int column) {
  const device uchar* block = row + (column / 32) * 34;
  ushort bits = ushort(block[0]) | (ushort(block[1]) << 8);
  return float(as_type<half>(bits)) * float(as_type<char>(block[2 + column % 32]));
}''')
text = read(vector)
# Only the original general vector and first pass need decoding. Original
# GQA special is retained for its plain/unbounded domain.
end = text.index('// queries without mask') if '// queries without mask' in text else text.index('[[kernel]] void sdpa_vector_2pass_1_gqa')
prefix, suffix = text[:end], text[end:]
prefix = prefix.replace('const constant int& hyle_offset [[buffer(20), function_constant(hyle_paged)]],',
    'const constant int& hyle_offset [[buffer(20), function_constant(hyle_paged)]],\n'
    '    const constant int& hyle_window_left [[buffer(21), function_constant(hyle_window)]],')
for head in ['kv_head_idx', 'kv_batch_head_idx']:
    before = f'  keys += {head} * k_head_stride +'
    prefix = prefix.replace(before, f'  const device uchar* key_bytes = reinterpret_cast<const device uchar*>(keys) + {head} * k_head_stride;\n'
        f'  const device uchar* value_bytes = reinterpret_cast<const device uchar*>(values) + {head} * v_head_stride;\n'
        f'  if (!hyle_q8) keys += {head} * k_head_stride +')
    prefix = prefix.replace(f'  values += {head} * v_head_stride +', f'  if (!hyle_q8) values += {head} * v_head_stride +')
prefix = prefix.replace(' : 0;\n    const device T* key_row', ' : i;\n    const device T* key_row')
prefix = prefix.replace('    if (use_key) {',
    '    if (hyle_window) use_key = use_key && i >= max(0, N - '+
    'int(q_seq_len) + int(q_seq_idx) - hyle_window_left);\n    if (use_key) {', 0) if False else prefix
# Query-length names differ in the two original kernels.
first_end = prefix.index('[[kernel]] void sdpa_vector_2pass_1(')
one, two = prefix[:first_end], prefix[first_end:]
one = one.replace('    if (use_key) {',
    '    if (hyle_window) use_key = use_key && i >= max(0, N - int(tpg.y) + int(q_seq_idx) - hyle_window_left);\n    if (use_key) {')
two = two.replace('    if (use_key) {',
    '    if (hyle_window) use_key = use_key && i >= max(0, N - q_seq_len + int(q_seq_idx) - hyle_window_left);\n    if (use_key) {')
one = one.replace('k[j] = key_row[j];',
    'k[j] = hyle_q8 ? hyle_q8_read(key_bytes + physical * k_seq_stride, simd_lid * qk_per_thread + j) : float(key_row[j]);')
one = one.replace('exp_score * value_row[j]',
    'exp_score * (hyle_q8 ? hyle_q8_read(value_bytes + physical * v_seq_stride, simd_lid * v_per_thread + j) : float(value_row[j]))')
two = two.replace('score += q[i] * key_row[i];',
    'score += q[i] * (hyle_q8 ? hyle_q8_read(key_bytes + physical * k_seq_stride, simd_lid * qk_per_thread + i) : float(key_row[i]));')
two = two.replace('exp_score * value_row[i]',
    'exp_score * (hyle_q8 ? hyle_q8_read(value_bytes + physical * v_seq_stride, simd_lid * v_per_thread + i) : float(value_row[i]))')
prefix = (one + two).replace('if (!hyle_paged) { keys +=', 'if (!hyle_paged && !hyle_q8) { keys +=')
texts[vector] = prefix + suffix
metal = 'mlx/backend/metal/kernels/scaled_dot_product_attention.metal'
replace(metal, '  instantiate_sdpa_vector(type, 64, 64)',
    '  instantiate_sdpa_vector(type, 64, 128)         \\\n+  instantiate_sdpa_vector(type, 64, 64)')

steel = 'mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h'
replace(steel, 'constant bool hyle_paged [[function_constant(303)]];',
    'constant bool hyle_paged [[function_constant(303)]];\n'
    'constant bool hyle_q8 [[function_constant(304)]];\n'
    'constant bool hyle_window [[function_constant(305)]];')
replace(steel, '    typename AccumType = float>', '    typename AccumType = float, int BV = BD>')
replace(steel, '    const constant int& hyle_offset [[buffer(9), function_constant(hyle_paged)]],',
    '    const constant int& hyle_offset [[buffer(9), function_constant(hyle_paged)]],\n'
    '    const constant int& hyle_window_left [[buffer(10), function_constant(hyle_window)]],')
text = read(steel)
text = text.replace('  K += tidl.z', '  const device uchar* Kbytes = reinterpret_cast<const device uchar*>(K) +\n'
    '      tidl.z * params->K_strides[0] + kv_head_idx * params->K_strides[1];\n'
    '  const device uchar* Vbytes = reinterpret_cast<const device uchar*>(V) +\n'
    '      tidl.z * params->V_strides[0] + kv_head_idx * params->V_strides[1];\n'
    '  if (!hyle_q8) K += tidl.z')
text = text.replace('  V += tidl.z', '  if (!hyle_q8) V += tidl.z')
text = text.replace('LDV_tgp = BD + padV', 'LDV_tgp = BV + padV')
text = text.replace('BK * (BD + padV)', 'BK * (BV + padV)')
vs = text.index('  using VBlockLoader =')
ve = text.index('  QBlockLoader loader_q', vs)
text = text[:vs] + text[vs:ve].replace('/* short BCOLS = */ BD', '/* short BCOLS = */ BV') + text[ve:]
text = text.replace('  constexpr int TD = BD / kFragSize;',
    '  constexpr int TD = BD / kFragSize;\n  constexpr int TV = BV / kFragSize;')
text = text.replace('MMATile<AccumType, TQ, TD, MMAFrag_acc_t> Otile;',
    'MMATile<AccumType, TQ, TV, MMAFrag_acc_t> Otile;')
text = text.replace('  for (int kb = 0; kb < kb_lim; kb++) {',
    '  const int kb_first = hyle_window ? max(0, (int(tid.x) * BQ + params->qL_off - hyle_window_left) / BK) : 0;\n'
    '  for (int kb = kb_first; kb < kb_lim; kb++) {')
for field in ['k', 'v']:
    upper = field.upper()
    before = f'    if (hyle_paged) {{\n      loader_{field}.load_paged({upper}, hyle_pages, hyle_offset, kb * BK, params->kL - kb * BK);'
    after = (f'    if (hyle_q8) {{\n      loader_{field}.load_q8({upper}bytes, '
             f'hyle_paged ? hyle_pages : nullptr, hyle_paged ? hyle_offset : 0, kb * BK, params->kL - kb * BK);\n'
             f'    }} else if (hyle_paged || hyle_window) {{\n      loader_{field}.load_paged({upper}, '
             'hyle_paged ? hyle_pages : nullptr, hyle_paged ? hyle_offset : 0, kb * BK, params->kL - kb * BK);')
    assert text.count(before) == 1
    text = text.replace(before, after)
text = text.replace('loader_v.load_safe(short2(BD,', 'loader_v.load_safe(short2(BV,')
text = text.replace('    // Other masking as needed', '''    if (hyle_window) {
      using stile_t = decltype(Stile);
      for (short i = 0; i < stile_t::kTileRows; ++i) {
        const int row = int(tid.x) * BQ + params->qL_off + tm + sm + i * stile_t::kFragRows;
        for (short j = 0; j < stile_t::kTileCols; ++j) {
          const int col = kb * BK + sn + j * stile_t::kFragCols;
          for (short jj = 0; jj < stile_t::MMAFrag_t::kElemCols; ++jj)
            if (col + jj < max(0, row - hyle_window_left))
              Stile.frag_at(i,j)[jj] = Limits<AccumType>::finite_min;
        }
      }
    }
    // Other masking as needed''')
text = text.replace('for (short id = 0; id < TD;', 'for (short id = 0; id < TV;')
text = text.replace('if (!hyle_paged) loader_', 'if (!hyle_paged && !hyle_q8 && !hyle_window) loader_')
text = text.replace('short2(BD - sn,', 'short2(BV - sn,')
texts[steel] = text
loader = 'mlx/backend/metal/kernels/steel/attn/loader.h'
replace(loader, 'valid ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : 0;',
    'valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;')
text = read(loader)
point = text.index('  /* Iteration helper */', text.index('  METAL_FUNC void load_paged('))
texts[loader] = text[:point] + '''  METAL_FUNC void load_q8(const device uchar* root, const device int* pages,
      const int offset, const int first, const int valid_rows) const thread {
    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
      for (short j = 0; j < vec_size; ++j) {
        const int col = bj + j;
        const device uchar* block = root + physical * src_ld + (col / 32) * 34;
        const ushort bits = ushort(block[0]) | (ushort(block[1]) << 8);
        dst[i * kDstStrRow + j * kDstStrCol] = valid ?
            T(float(as_type<half>(bits)) * float(as_type<char>(block[2 + col % 32]))) : T(0);
      }
    }
  }
''' + text[point:]
# Cold JIT accepts a separately named finite VO dimension. Existing callers
# retain the original coupled tile through the default value.
header = 'mlx/backend/metal/kernels.h'
text = read(header); start = text.index('MTL::ComputePipelineState* get_steel_attention_kernel(')
end = text.index('\nMTL::ComputePipelineState*', start + 1)
texts[header] = text[:start] + text[start:end].replace('const array& m);', 'const array& m, int bv = -1);') + text[end:]
jit = 'mlx/backend/metal/jit_kernels.cpp'
text = read(jit); start = text.index('MTL::ComputePipelineState* get_steel_attention_kernel(')
end = text.index('\nMTL::ComputePipelineState*', start + 1)
chunk = text[start:end].replace('const array& m) {', 'const array& m, int bv) {')
chunk = chunk.replace('get_type_string(m.dtype())));', 'get_type_string(m.dtype()), "float", bv < 0 ? bd : bv));')
texts[jit] = text[:start] + chunk + text[end:]

# All transformations are validated before changing canonical manifests.
for name, after in texts.items():
    if after == initial[name]:
        continue
    patch = next((p for p in manifest['files'] if p['path'] == name), None)
    if patch is None:
        raw = (ORIGINAL / name).read_bytes().replace(b'\r\n', b'\n')
        patch = {'path': name, 'before_sha256': hashlib.sha256(raw).hexdigest(), 'edits': []}
        manifest['files'].append(patch)
    old, new = initial[name].splitlines(keepends=True), after.splitlines(keepends=True)
    current = initial[name]
    for tag, i1, i2, j1, j2 in reversed(difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes()):
        if tag == 'equal': continue
        lo, hi = max(0, i1-1), min(len(old), i2+1)
        before = ''.join(old[lo:hi])
        while current.count(before) != 1:
            if lo > 0: lo -= 1
            elif hi < len(old): hi += 1
            else: raise AssertionError((name, 'nonunique edit'))
            before = ''.join(old[lo:hi])
        after_chunk = ''.join(old[lo:i1]) + ''.join(new[j1:j2]) + ''.join(old[i2:hi])
        patch['edits'].append({'before': before, 'after': after_chunk})
        current = current.replace(before, after_chunk, 1)
    assert current == after, name
    patch['after_sha256'] = hashlib.sha256(after.encode()).hexdigest()
    path = PREVIEW / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(after.encode())
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
directory = ROOT / 'third_party/mlx_cast'
tree = ''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(b"\r\n",b"\n")).hexdigest()}\n'
    for p in sorted(directory.rglob('*'), key=lambda p: p.relative_to(directory).as_posix()) if p.is_file())
lock_path = ROOT / 'cmake/HyleDependencyLock.json'
lock = json.loads(lock_path.read_text(encoding='utf-8'))
dep = next(p for p in lock['dependencies'] if p['name'] == 'mlx_cast_patches')
dep['vendored']['tree_sha256'] = hashlib.sha256(tree.encode()).hexdigest()
lock_path.write_text(json.dumps(lock, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'files': len(texts), 'tree_sha256': dep['vendored']['tree_sha256']}))
