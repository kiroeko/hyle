from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile

BASE=Path('/Users/kiro/hyle-scratch/compute-unified')
SOURCE=BASE/'source-c8874688'
PARENT=BASE/'a-cpu-apple/selected-graph/source-parent'
BUILD=PARENT.parent/'source-build'
OUT=BASE/'g04-g05-apple-cache'
attempt=sys.argv[1]
assert SOURCE.is_dir() and not (SOURCE/'.git').exists()
identity={k:subprocess.check_output(v,text=True).strip() for k,v in [
 ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
 ('compiler',['/Library/Developer/CommandLineTools/usr/bin/clang++','--version']),
 ('memory',['/usr/sbin/sysctl','-n','hw.memsize'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
with zipfile.ZipFile(OUT/f'source-{attempt}.zip') as package:
 inputs=json.loads(package.read('source-manifest.json'))
 for item in inputs:
  relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
  raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
  destination=SOURCE/relative
  if not destination.exists() or destination.read_bytes()!=raw:
   destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw)
cmake=PARENT/'CMakeLists.txt';text=cmake.read_text()
target='g04_g05_apple_cache'
if f'add_executable({target} ' not in text:
 text+=f'\nadd_executable({target} "{SOURCE}/tests/compute_route_apple/native_cache_test.cc")\n'
 text+=f'target_compile_features({target} PRIVATE cxx_std_23)\n'
 text+=f'target_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\n'
 text+=f'target_link_libraries({target} PRIVATE hyle::compute GTest::gtest_main)\n'
 text+=f'hyle_stage_runtime({target})\n'
 cmake.write_text(text)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
result={'state':'RUNNING','identity':identity,'inputs':inputs,'max_jobs':4,'stages':[],
 'scope':'Only real Apple new-cache source fixture; no model/whole-test/SDK/sanitizer/P1 verdict','cumulative_seconds':0}
def save():
 (OUT/f'result-{attempt}.json').write_text(json.dumps(result,indent=2)+'\n')
save()
commands=[('configure',['/opt/homebrew/bin/cmake','-S',str(PARENT),'-B',str(BUILD)]),
 ('compile',['/opt/homebrew/bin/cmake','--build',str(BUILD),'--target',target,'--parallel','4']),
 ('tests',[str(BUILD/target),'--gtest_output=xml:'+str(OUT/f'tests-{attempt}.xml')])]
for stage,command in commands:
 log=OUT/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as stream:
  process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}))
  print(f'{stage}: pid={process.pid}',flush=True);code=process.wait()
 elapsed=time.monotonic()-start
 result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 result['cumulative_seconds']+=elapsed;save();print(f'{stage}: exit={code}, elapsed={elapsed:.3f}s',flush=True)
 if code:
  result['state']='TERMINAL_FAIL';save();(OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
result['state']='TERMINAL_PASS';save();(OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
