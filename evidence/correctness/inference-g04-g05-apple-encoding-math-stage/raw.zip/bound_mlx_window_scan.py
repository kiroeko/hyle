from pathlib import Path
import hashlib,json,subprocess

ROOT=Path(__file__).resolve().parents[3]
name='mlx/backend/metal/kernels/sdpa_vector.h'
file=ROOT/'.scratch/inference-gaps/g04-g05/apple-native/mlx-preview'/name
before=file.read_text(encoding='utf-8');after=before
for stride,initial,length in [('BN','simd_gid','int(tpg.y)'),('blocks','block_idx','q_seq_len')]:
 old=f'  for (int i = {initial}; i < N; i += {stride}) {{'
 new=(f'  const int first_key = hyle_window ? max(0, N - {length} + int(q_seq_idx) - hyle_window_left) : 0;\n'
      f'  const int last_key = hyle_window ? N - {length} + int(q_seq_idx) + 1 : N;\n'
      f'  for (int i = (first_key / {stride}) * {stride} + {initial}; i < last_key; i += {stride}) {{')
 assert after.count(old)==1;after=after.replace(old,new)
path=ROOT/'third_party/mlx_cast/patches.json';manifest=json.loads(path.read_text(encoding='utf-8'))
entry=next(p for p in manifest['files'] if p['path']==name)
assert hashlib.sha256(before.encode()).hexdigest()==entry['after_sha256']
entry['edits'].append({'before':before,'after':after});entry['after_sha256']=hashlib.sha256(after.encode()).hexdigest()
file.write_text(after,encoding='utf-8',newline='\n')
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
directory=ROOT/'third_party/mlx_cast'
tree=''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(b"\r\n",b"\n")).hexdigest()}\n'
 for p in sorted(directory.rglob('*'),key=lambda p:p.relative_to(directory).as_posix()) if p.is_file())
digest=hashlib.sha256(tree.encode()).hexdigest()
original=subprocess.check_output(['git','show','HEAD:cmake/HyleDependencyLock.json'],cwd=ROOT)
start=original.index(b'"name": "mlx_cast_patches"');index=original.index(b'"tree_sha256": "',start)+len(b'"tree_sha256": "')
(ROOT/'cmake/HyleDependencyLock.json').write_bytes(original[:index]+digest.encode()+original[index+64:])
print(digest)
