from pathlib import Path
import hashlib, json, subprocess

ROOT = Path(__file__).resolve().parents[3]
PREVIEW = ROOT / '.scratch/inference-gaps/g04-g05/apple-native/mlx-preview'
path = ROOT / 'third_party/mlx_cast/patches.json'
manifest = json.loads(path.read_text(encoding='utf-8'))
changes = {
 'mlx/backend/metal/scaled_dot_product_attention.cpp': [('std::to_string(o.shape(-1))', 'std::to_string(out.shape(-1))')],
 'mlx/backend/metal/kernels/scaled_dot_product_attention.metal': [('\n+  instantiate_sdpa_vector(type, 64, 64)', '\n  instantiate_sdpa_vector(type, 64, 64)')],
}
for name, edits in changes.items():
    file = PREVIEW / name; before = file.read_text(encoding='utf-8'); after = before
    for old, new in edits:
        assert after.count(old) == 1, (name, old)
        after = after.replace(old, new, 1)
    entry = next(p for p in manifest['files'] if p['path'] == name)
    assert hashlib.sha256(before.encode()).hexdigest() == entry['after_sha256']
    entry['edits'].append({'before': before, 'after': after})
    entry['after_sha256'] = hashlib.sha256(after.encode()).hexdigest()
    file.write_text(after, encoding='utf-8', newline='\n')
path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
directory = ROOT / 'third_party/mlx_cast'
tree = ''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(b"\r\n",b"\n")).hexdigest()}\n'
    for p in sorted(directory.rglob('*'), key=lambda p: p.relative_to(directory).as_posix()) if p.is_file())
digest = hashlib.sha256(tree.encode()).hexdigest()
lock = ROOT / 'cmake/HyleDependencyLock.json'
original = subprocess.check_output(['git','show','HEAD:cmake/HyleDependencyLock.json'],cwd=ROOT)
start = original.index(b'"name": "mlx_cast_patches"')
index = original.index(b'"tree_sha256": "',start) + len(b'"tree_sha256": "')
lock.write_bytes(original[:index] + digest.encode() + original[index+64:])
print(digest)
