from pathlib import Path
import hashlib,json,subprocess

ROOT=Path(__file__).resolve().parents[3]
manifest_path=ROOT/'third_party/mlx_cast/patches.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
name='mlx/backend/metal/scaled_dot_product_attention.cpp'
path=ROOT/'.scratch/inference-gaps/g04-g05/apple-native/mlx-preview'/name
before=path.read_text(encoding='utf-8');after=before
old='  int bk = bd < 128 ? 32 : 16;'
new=old+'\n  if (page && page->q8 && bd == 256) { wm = 2; bq = 16; bk = 8; }'
assert after.count(old)==1;after=after.replace(old,new)
old='  hash_name += std::to_string(blocks);'
new=old+'\n  if (page) hash_name += "_hyle_" + std::to_string(hyle_paged) + "_" +\n      std::to_string(hyle_q8) + "_" + std::to_string(hyle_window);'
assert after.count(old)==1;after=after.replace(old,new)
entry=next(p for p in manifest['files'] if p['path']==name)
assert hashlib.sha256(before.encode()).hexdigest()==entry['after_sha256']
entry['edits'].append({'before':before,'after':after});entry['after_sha256']=hashlib.sha256(after.encode()).hexdigest()
path.write_text(after,encoding='utf-8',newline='\n')
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
directory=ROOT/'third_party/mlx_cast'
tree=''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(b"\r\n",b"\n")).hexdigest()}\n'
 for p in sorted(directory.rglob('*'),key=lambda p:p.relative_to(directory).as_posix()) if p.is_file())
digest=hashlib.sha256(tree.encode()).hexdigest()
original=subprocess.check_output(['git','show','HEAD:cmake/HyleDependencyLock.json'],cwd=ROOT)
start=original.index(b'"name": "mlx_cast_patches"');index=original.index(b'"tree_sha256": "',start)+len(b'"tree_sha256": "')
(ROOT/'cmake/HyleDependencyLock.json').write_bytes(original[:index]+digest.encode()+original[index+64:])
print(digest)
