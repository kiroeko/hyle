from pathlib import Path
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
RUN=ROOT/'.scratch/inference-gaps/g04-g05/apple-native'
OUT=ROOT/'evidence/correctness/inference-g04-g05-apple-encoding-math-stage'
last=int(sys.argv[1])
records=[json.loads((RUN/f'result-{i}.json').read_text(encoding='utf-8')) for i in range(1,last+1)]
assert all(r['state'].startswith('TERMINAL_') for r in records)
assert records[-1]['state']=='TERMINAL_PASS'
xml=ET.parse(RUN/f'tests-{last}.xml').getroot()
assert int(xml.attrib['tests'])==10 and int(xml.attrib['failures'])==0
inputs={p['path']:p['sha256'] for p in records[-1]['inputs'] if p['path'].startswith(
    ('src/compute_route_apple/','tests/compute_route_apple/','third_party/mlx_cast/')) or p['path']=='cmake/HyleDependencyLock.json'}
for name,digest in inputs.items():
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
manifest=json.loads((ROOT/'third_party/mlx_cast/patches.json').read_text(encoding='utf-8'))
patched=[]
original=ROOT/'.scratch/inference-gaps/g01/native-paged/mlx-original'
for entry in manifest['files']:
 file=original/entry['path']
 if not file.exists():continue
 raw=file.read_bytes().replace(b'\r\n',b'\n')
 assert hashlib.sha256(raw).hexdigest()==entry['before_sha256'],entry['path']
 for edit in entry['edits']:
  before=edit['before'].encode();assert raw.count(before)==1,(entry['path'],before[:100])
  raw=raw.replace(before,edit['after'].encode(),1)
 assert hashlib.sha256(raw).hexdigest()==entry['after_sha256'],entry['path']
 patched.append({'path':entry['path'],'after_sha256':entry['after_sha256']})
OUT.mkdir(parents=True,exist_ok=False)
result={'kind':'G04_G05_APPLE_ENCODING_AND_NATIVE_MATH_SOURCE_STAGE',
 'verdict':'PASS_FINITE_MACBOOK_AIR_SOURCE_DOMAIN','owners_remain':'AUDITED; whole G04/G05 not accepted',
 'identity':records[-1]['identity'],'delivery':'Actual shared shipping source target; no HYLE_TESTING, canonical Windows one-way archives; original build-local MLX patch',
 'input_sha256':inputs,'verified_patch_derivations':patched,'tests':{'final':10},
 'qualified':[
  'Q8_0 encoder bytes for F16/BF16/F32: zero blocks, signed exact ties and +/- nextafter(.5) boundary',
  'NaN/Inf and finite F32 scale overflow accepted then reported by original Results numeric status',
  'Actual direct paged/ragged U8 Q8 carriers, logical D64/D128/D256 and independent (64,128)',
  'F16/BF16 Q/output, original vector/steel, long D256 Q1/65, shared/reordered logical274 over physical256',
  'Causal inclusive window -1/0/15/16 and full noncausal Q33/35 over KV31/33',
  '8192-row Q8 high-value cancellation, Q1 two-pass and Q65 steel; no early half decode or half unnormalized partial',
  '8192-row two-pass Q8/plain window -1/0/16/-1 pipeline specialization and bounded effective scans',
  'Empty paged/ragged Q8 (64,128) output [0,8,128], F16/BF16; original exact zero-frame contract',
  'Original plain coupled/unbounded paged/ragged D64/D128/D256 F16/BF16 vector/full NAX paths'],
 'P0':'Q8 tile/row F32 decode; active Q/output F32 conversion O(Q*Hq*(Dqk+Dv)), original two-pass F32 partials; '
      'D256 Q8 WM2/BQ16/BK8 shared memory28928 bytes; window loops bounded to effective rows plus one alignment block; '
      'no full-history decode/gather/mask and no new runtime/queue/controller. Original native private bytes UNKNOWN.',
 'not_proven':['Incremental encoder/F2/Graph page consumer journey','static/shared SDK delivery','new-domain sanitizer/OOM/concurrency/retirement matrix',
               'qualified P1','Vulkan new domain','whole G04/G05'],
 'runs':[{k:v for k,v in r.items() if k!='inputs'} for r in records],
 'cumulative_seconds':sum(r['cumulative_seconds'] for r in records)}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for file in sorted(RUN.iterdir()):
  if file.is_file() and file.suffix!='.zip':archive.write(file,file.name)
 for file in sorted((RUN/'mlx-preview').rglob('*')):
  if file.is_file():archive.write(file,file.relative_to(RUN).as_posix())
 for name in ['launch_apple_cache.py','apple_cache_air.py','extend_mlx_cache_patch.py',
  'refine_mlx_cache_patch.py','fix_mlx_cache_dispatch.py','bound_mlx_window_scan.py',
  'finalize_mlx_window_patch.py','seal_apple_native_stage.py']:
  archive.write(RUN.parent/name,name)
print(json.dumps({'tests':10,'cumulative_seconds':result['cumulative_seconds']}))
