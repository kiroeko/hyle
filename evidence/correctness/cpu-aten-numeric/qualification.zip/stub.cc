#include <array>
#include <cstdio>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"
int main() {
  namespace c = hyle::compute;
  if (c::aten_cpu::provider().valid()) return 1;
  auto direct = c::cpu::create_context();
  auto graph = hyle::graph::cpu::create_context();
  if (!direct || !graph) return 2;
  for (const auto *ctx : {&*direct, &*graph})
    for (std::size_t i=0; i<ctx->provider_count(); ++i)
      if (ctx->provider_identity(i)->id == c::aten_cpu::kProviderId) return 2;
  const auto desc = c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t, 1>{2}).value();
  for (const auto *ctx : {&*direct, &*graph}) {
    auto p = c::prepare(*ctx, c::Unary{c::UnaryKind::kNeg}, desc);
    if (!p || p->provider().id != c::native::kProviderId) return 3;
  }
  if (!direct->close().ok() || !graph->close().ok()) return 4;
  std::puts("SDK-disabled adapter and both ordinary assemblers skip invalid ATen factory PASS");
}
