import ctypes,subprocess,sys
ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
args=['wsl.exe','-d','Ubuntu-24.04','--','python3']+sys.argv[1:]
r=subprocess.run(args,creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print(r.stdout.decode(errors='replace'),flush=True)
raise SystemExit(r.returncode)
