import hashlib,json,subprocess
from pathlib import Path
repo=Path.cwd();fixture=repo/'.scratch/validation/cpu-aten-numeric'
for platform,source in [('windows',str(fixture/'consumer.cc').replace('\\','/')),
                         ('linux','/root/hyle-scratch/active-cpu-z/source/.scratch/validation/cpu-aten-numeric/consumer.cc')]:
    (fixture/(platform+'-overlay.cmake')).write_bytes(('''function(cpu_mature_consumer)
  add_executable(cpu_mature_consumer "'''+source+'''")
  target_compile_features(cpu_mature_consumer PRIVATE cxx_std_23)
  target_link_libraries(cpu_mature_consumer PRIVATE hyle::compute hyle::graph)
  hyle_stage_runtime_dependencies(cpu_mature_consumer)
endfunction()
if(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)
  cmake_language(DEFER CALL cpu_mature_consumer)
endif()
''').encode())
(fixture/'consumer').mkdir(exist_ok=True)
(fixture/'consumer/CMakeLists.txt').write_bytes((repo/'.scratch/validation/cpu-aten-storage-index/consumer/CMakeLists.txt').read_bytes())
(fixture/'stub').mkdir(exist_ok=True)
for name in ('stub.cc','stub/CMakeLists.txt'):
    (fixture/name).write_bytes((repo/'.scratch/validation/cpu-aten-storage-index'/name).read_bytes())
for name in ('windows.py','linux.py','windows-extra.py'):
    src=(repo/('.scratch/cpu-si-'+name)).read_text(encoding='utf8')
    src=src.replace('cpu-aten-storage-index','cpu-aten-numeric').replace('cpu-si-','cpu-mn-')
    if name=='linux.py':src=src.replace("stage+'-lb-consumer'","stage+'-mn-consumer'")
    (repo/('.scratch/cpu-mn-'+name)).write_bytes(src.encode())
files=subprocess.check_output(['git','ls-files'],text=True).splitlines()
files=[p for p in files if (p.startswith(('cmake/','include/','src/','tests/','scripts/')) or p in ('CMakeLists.txt','hyle-config.cmake.in')) and (repo/p).is_file()]
files+=['.scratch/validation/cpu-aten-numeric/'+p for p in ('consumer.cc','windows-overlay.cmake','linux-overlay.cmake','consumer/CMakeLists.txt')]
manifest=dict(candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in files})
(fixture/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(dict(candidate=manifest['candidate'],files=len(files)))
