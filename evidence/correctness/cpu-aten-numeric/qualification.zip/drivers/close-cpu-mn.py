import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path.cwd()
scratch = root / '.scratch/validation/cpu-aten-numeric'
evidence = root / 'evidence/correctness/cpu-aten-numeric'
candidate = '0763fd3e3163d16eb0b43e684f5881f8314bc1e9'
qualification = '91f04856270880e9cdc4548c116d92f10a839e57'
previous = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert previous == qualification
manifest = json.loads((scratch / 'manifest.json').read_bytes())
old_manifest = json.loads((scratch / 'manifest-windows-qualified.json').read_bytes())
assert manifest['candidate'] == qualification and old_manifest['candidate'] == candidate
changed = [p for p in manifest['files'] if manifest['files'][p] != old_manifest['files'][p]]
assert changed == ['tests/compute_provider_native/aten_numeric_test.cc']
assert all(hashlib.sha256((root / p).read_bytes()).hexdigest() == sha for p, sha in manifest['files'].items())
old_test = subprocess.check_output(['git', 'show', candidate + ':' + changed[0]])
new_test = (root / changed[0]).read_bytes()
assert old_test.replace(b'for (const auto shape :', b'for (const auto &shape :').replace(b'\r\n', b'\n') == new_test.replace(b'\r\n', b'\n')
required = {'provider-tests', 'native-public-header', 'compute_route_cpu-affected-tests',
            'graph_route_cpu-affected-tests', 'shared-source-ordinary', 'static-source-ordinary',
            'shared-installed-ordinary', 'static-installed-ordinary'}
results, files, cleanup_bytes = {}, [], 0
for platform, validation_candidate in [('windows', candidate), ('linux', qualification)]:
    folder = scratch / platform
    receipt = json.loads((folder / 'receipt.json').read_bytes())
    qualified = [r for r in receipt if r['candidate'] == validation_candidate]
    last = {r['name']: r for r in qualified}
    expected = required | ({'sdk-disabled-adapter-and-assembly'} if platform == 'windows' else set())
    assert expected <= last.keys(), platform
    assert all(r['returncode'] == 0 for r in last.values()), platform
    suites = {}
    for name in ('provider', 'compute_route_cpu', 'graph_route_cpu', 'header'):
        doc = ET.parse(folder / (name + '.xml')).getroot()
        cases = list(doc.iter('testcase'))
        assert not list(doc.iter('failure')) and not list(doc.iter('error'))
        skipped = [c.attrib['name'] for c in cases if list(c.iter('skipped'))]
        suites[name] = dict(registered=len(cases), passed=len(cases)-len(skipped), skipped=skipped)
    assert suites['provider']['passed'] == 120
    assert suites['compute_route_cpu']['passed'] == 12 and len(suites['compute_route_cpu']['skipped']) == 1
    assert suites['graph_route_cpu']['passed'] == 15 and suites['header']['passed'] == 1
    identity = json.loads((folder / 'source-identity.json').read_bytes())
    assert identity['candidate'] == validation_candidate and identity['checked'] == 1333
    cleanup = json.loads((folder / 'cleanup.json').read_text(encoding='utf-8-sig'))
    assert all(c['removed'] for c in cleanup)
    reclaimed = sum(int(c['logical_bytes']) for c in cleanup if not c.get('original_probe_hardlinks', False))
    cleanup_bytes += reclaimed
    results[platform] = dict(validation_tree=validation_candidate, product_candidate=candidate,
        commands=len(receipt), qualified_tree_commands=len(qualified), latest_commands_passed=sorted(last),
        tests=suites, prior_failures_retained=[r for r in receipt if r['returncode']],
        source_identity_files=identity['checked'], consumer_cleanup_logical_bytes=reclaimed,
        delivery={k: 'PASS' for k in ('source_shared', 'source_static', 'installed_shared', 'installed_static')})
    files += [(p, f'{platform}/{p.name}') for p in folder.iterdir() if p.is_file()]

loc_data = json.loads((scratch / 'loc.json').read_bytes())
assert loc_data['repository']['commit'] == candidate and loc_data['self_check'] == 'pass'
loc = next(v for v in loc_data['metrics'] if v['id'] == 'module')
assert loc['code'] == 61950 and loc['files'] == 249
for name in ('consumer.cc', 'windows-overlay.cmake', 'linux-overlay.cmake', 'manifest.json',
             'manifest-windows-qualified.json', 'test-fixture-only-reuse.json', 'selector-plan.json',
             'stub.cc', 'loc.json', 'consumer/CMakeLists.txt', 'stub/CMakeLists.txt'):
    files.append((scratch / name, name))
for name in ('cpu-mn-windows.py', 'cpu-mn-linux.py', 'cpu-mn-windows-extra.py',
             'cpu-ggml-wsl-launch.py', 'prepare-cpu-mn.py', 'cleanup-cpu-mn-windows.ps1',
             'cleanup-cpu-mn-linux.py', 'close-cpu-mn.py'):
    files.append((root / '.scratch' / name, 'drivers/' + name))
assert len({name for _, name in files}) == len(files)
file_hashes = {}
archive = evidence / 'qualification.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for source, name in files:
        assert source.is_file(), source
        file_hashes[name] = hashlib.sha256(source.read_bytes()).hexdigest()
        output.write(source, name)
    output.writestr('files-sha256.json', json.dumps(file_hashes, indent=2) + '\n')
report = dict(candidate=candidate, previous_registry_ref=previous, qualification_fixture_tree=qualification,
    platforms=results,
    test_only_correction=dict(file=changed[0], reason='GCC14 -Werror=range-loop-construct',
        edit='const auto shape -> const auto &shape; immutable read-only values and all numerical cases unchanged',
        unchanged_product_and_consumer_inputs=725, proof='test-fixture-only-reuse.json in qualification.zip',
        windows_reuse='Actual candidate tests/deliveries, not relabelled as runs at fixture tree'),
    original_diagnostic=dict(assertions=48780, manifest='original-manifest.json', does_not_prove_ordinary_or_delivery=True),
    archive=dict(path='qualification.zip', files=len(files)+1, bytes=archive.stat().st_size,
        sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
    loc=dict(candidate=candidate, code=loc['code'], files=loc['files']),
    cleanup=dict(consumer_logical_bytes_removed=cleanup_bytes, retained='producer builds, installed SDKs and dependency caches',
        original_probe_hardlinks_not_counted_as_reclaimed_disk_bytes=True),
    disabled_adapter=dict(platform='windows', verdict='PASS',
        boundary='Current ATen/CPU/Graph translation units compiled with the ATen feature disabled; invalid factory omitted by both ordinary assemblers. Reused installed dependencies; not a fresh full SDK-OFF build or a no-Torch-dependency claim.'),
    performance=dict(tier='P0', verdict='PASS',
        boundary='Full Byte packing, F32/Double casts, original Tensor nodes, scratch and hot metadata declared. No Native P1, SOTA or WIN claim.'),
    red_team=dict(reviewer='root, separate post-qualification source/evidence pass', date='2026-10-06',
        budget='one finite MN1-MN4 pass', verdict='PASS', findings=[
            dict(severity='fixture', finding='An explicit empty Axes list is illegal in the public schema',
                 disposition='Use legal all/single/multi axes; keep original XML and unchanged numerical gates'),
            dict(severity='fixture', finding='GCC14 rejects copied vector loop variable with Werror',
                 disposition='Read-only const reference only; preserve initial Linux build log, hash all product/consumer inputs'),
            dict(severity='limit', finding='Original GELU and cancellation-prone oracle lose negative tails',
                 disposition='Qualified original Double erfc / sigmoid Tensor programs and stable independent oracle; cost is not a raw single-kernel timing'),
            dict(severity='limit', finding='Native physical OOM/noncoherent mapping fault not injected',
                 disposition='Source-audited exception/mapping propagation, tracked HYLE cold OOM actually tested'),
            dict(severity='limit', finding='Other default ggml Sigmoid/SiLU finite-tail source suspicion remains',
                 disposition='Explicitly outside MN owner, finite complete-consumer followup required before CPU goal closes')]))
(evidence / 'receipt.json').write_bytes((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode())

readme = f'''# CPU ATen：稳定数值程序接线资格

MN1–4 **CLOSED**，不可变产品候选 `{candidate}`。
[当前卡](../../../docs/implementation/tasks/compute/cpu-aten-numeric-admission.md)；Windows产品真相，
验证副本单向同步。已锁LibTorch2.8.0 CPU SDK限定Windows/Linux x86_64；本批不签其它CPU平台。

## 实现与语义

plain F32/F16/BF16，exact shape、rank0..8、任意合法byte stride与inferred dense output：四Unary
SiLU/GELU/GELU-tanh/Softplus、三GatedActivation的packed/separate、number Binary Min/Max、
Reduce Sum/Mean/Min/Max。Reduce任意合法axes/keepdim/empty，显式F32 accumulation；F32还允许Unknown。
gate在F32 activation与乘法之后一次输出舍入。普通入口与Graph下游不需要用户注册或排序Provider。

原Byte copy先将输入打包到冷私有对齐typed native Tensor，不能将odd byte stride截断成element stride。
SiLU借原Double silu，erf-GELU借原Double erfc等价程序，tanh-GELU借原Double sigmoid/pow/add/mul；
原where仅修复−Inf极限。显式F32 activation后乘value，再一次storage cast。Softplus借原Float稳定kernel。
Min/Max借原fmin/fmax，单NaN取另一数，双零用原signbit/where修复；Reduce借原sum/mean/amin/amax，
传播NaN，空集合写约定identity，零号用原kernel mask组合修复。没有HYLE新payload数学/近似/SIMD循环。

原Double转换、多节点temporary、input/output packing及F32中间materialization均属于真实完整程序成本。
普通规则仍先现有oneDNN/ggml，再ATen，再具名Native残余；这不是SOTA/WIN裁决。ATen是managed
同步leaf，host阻塞、原库私有线程/allocator、unknown内部内存；不承诺capture、零热分配或严格内存上界。
仅Unary或Binary匹配equal dense description的端口支持精确alias；所有Gate/Reduce、broadcast/strided
alias拒绝。prepared program不可变，native packing槽每invocation独立，borrowed Tensor先于maps关闭。

## 实际验证

| 环境 | 受影响测试 | 同一普通C++消费者 |
|---|---|---|
| Windows | Provider120/120；CPU12通过/1跳过；Graph15/15；公开头1/1；feature关闭adapter/程序集 | source shared/static、installed shared/static通过 |
| Linux GCC14 | Provider120/120；CPU12通过/1跳过；Graph15/15；公开头1/1 | source shared/static、installed shared/static通过 |

6项新增批量测试包含三dtype、稠密/odd strides、tail/±Inf/NaN/±0、large-value gate、广播、rank0/8、
empty/all/single/multi axes、keepdim、零号/NaN Reduce、允许alias/拒绝其它alias、真实wait/close，
两线程独立invocation/queue12轮并发、tracked冷prepare/invocation逐点OOM恢复与资源归零。
独立scalar oracle使用稳定erfc/branch exp和独立低精度RNE encoder；未以消减后的0弱化门。
ordinary consumer只链接hyle::compute/graph，三dtype四组能力变化输入重放，核对实际成熟identity与
op→Copy Graph最终结果；odd-byte域实际绑定ATen。没有新增整ATen region或拆除已有成熟融合。

旧D5RealQwenProjectionUsesExactProfileAndReplays因缺fixture两平台跳过，不计PASS；本卡未改该画像，
新的普通主/正交旅程实际运行。native物理OOM/noncoherent mapping fault未注入，仅源码审计传播，
不写成故障注入PASS。Windows feature-OFF是当前ATen/CPU/Graph TU与assembler的编译/消费资格，
复用已安装依赖，不宣称完整SDK-OFF重建或去除Torch DLL。Windows DLL按既有helper放exe邻目录。

## 失败、不可变产品与证据复用

首批Windows119/120来自qualification对非法Axes::from(empty)取value；改为合法axes，保留原XML，
产品代码未改，最终120/120。Linux先被-Werror=range-loop-construct拦住，仅把测试vector循环变量
改const引用；保留失败命令/编译日志。测试维护commit `{qualification}` 不改变产品candidate，
725项产品/CMake/普通消费者输入hash与Windows已验收版本一致，Linux1333项输入已单向校验。
同一测试数值/形状保持，Windows证据按原实际commit复用，不伪写成新commit运行记录。

原版diagnostic **48,780断言**仍绑定[原manifest](original-manifest.json)，只证明原程序可运行，
不是算子/模型数量。直接raw GELU与消减oracle的失效日志保留；负尾部−8.36250019073原double结果
与消减0不一致，最后采用稳定原程序和独立参考。原−Inf和signed-zero边界均明确，未放宽数值门。

## 终审、成本与剩余

root于2026-10-06独立一遍MN1–4源码/证据检查，核对exact准入、native对齐packing、alias顺序、
borrowed生命周期、异常/OOM、私有lane、数值中间阶段、ordinary identity、交付和fixture复用边界。
P0为O(input+output)多节点原程序；所有cast/packing/scratch/hot metadata显式managed收费。
七门通过，但无新P1/WIN、模型级推理或其它路线资格；Native/SIMD自研优化/性能清退保持冻结。

ggml现有Sigmoid/SiLU有限负尾部仍有具名源码疑点，须一次完整consumer核对，不由ATen后备掩盖。
其余RoPE/I64 positions、Bool/log-softmax、FP8 numeric Cast、shape/资源残余及最终自研取舍仍未完成。
本卡关闭仅本批域，CPU整体没有完成。只有本批语义/资源/组合/交付反例或依赖升级可重开。
统一Compute+Graph实现LOC **{loc['code']:,}/{loc['files']}文件**，不可变产品candidate统计，排除测试/vendor。
本批消费者临时目录已删 **{cleanup_bytes:,} logical bytes**；producer/SDK/cache保留，probe DLL硬链接
不计为实际回收空间，不复制巨型二进制到证据。

[收据](receipt.json)和[工件](qualification.zip)保存命令/所有失败/XML、同一consumer/stub、两份
manifest/fixture-only复用证明、selector selected/skipped、驱动/cleanup/LOC。工件SHA256
`{report['archive']['sha256']}`。终审状态/文档变化不重建/P1。
'''
(evidence / 'README.md').write_bytes(readme.encode())

card_path = root / 'docs/implementation/tasks/compute/cpu-aten-numeric-admission.md'
card = card_path.read_text(encoding='utf-8').replace('<!-- MODULE REVIEW: CANDIDATE -->', '<!-- MODULE REVIEW: CLOSED -->')
card = card.replace('scope审计/原程序尚未完成，产品gate均UNPROVEN。', '审计时产品gate均UNPROVEN，最终产品资格见下方。')
card = card.replace('owner AUDITED，产品gate尚未运行；原program witness不代签产品成功。', '审计时owner AUDITED、产品gate尚未运行；原program witness不代签产品成功。')
card = card.replace('源码/installed static/shared、Linux与剩余工程门尚未全部运行，本卡保持CANDIDATE，不签CLOSED。',
    '源码/installed static/shared与Linux全部通过；Windows证据按产品输入一致复用，详见最终收据。')
card += f'''

## 逐能力覆盖与最终七门

[完整证据](../../../../evidence/correctness/cpu-aten-numeric/README.md)。PASS仅本批plain F32/F16/BF16
exact/rank<=8/dense-output域，已锁Windows/Linux x86_64 SDK；不代签其它CPU平台/模型/GPU。

| 能力/public journey | 正常与边界 | failure/OOM/overflow | ownership/teardown | concurrency/取消 | 主/正交消费 | 平台/交付 |
|---|---|---|---|---|---|---|
| 四Unary/三gate Direct→Graph下游 | PASS：三dtype/packed-separate/odd stride/tails/large-value/±Inf/NaN/±0、一次输出舍入 | PASS：checked容量与tracked冷OOM；其它非法alias拒绝；native物理OOM源码审计 | PASS：私有对齐输入packing、允许Unary alias先读后写、borrowed maps关闭与归零 | PASS：独立两queue/invocation两线程12轮；原kernel中途抢占NOT_APPLICABLE | PASS：LLM激活/专家gate及普通变化输入，不依赖模型名特化 | PASS：Win/Linux、公开头、同一consumer三交付 |
| number Min/Max与四Reduce | PASS：广播/odd stride/rank0/8/all-single-multi axes/keepdim/emptyidentity/NaN与signed-zero | PASS：half Unknown accumulation/非法alias拒绝；checked容量与tracked冷OOM，物理故障未注入 | PASS：Binary允许equal-desc alias，Reduce无alias；private slots/close/资源归零 | PASS：immutable Program及invocation隔离；同步原库不承诺抢占 | PASS：普通多轴统计与主gate融合边界消费，Graph最终结果核对 | PASS：两平台同一四交付journey |
| factory/默认组装/成本 | PASS：独立ATen identity、原成熟排序、feature关闭不绑定 | PASS：managed/private-thread/unknown真实属性，硬预算不以unknown冒充零 | PASS：既有CPU Context/Completion与存储index回归保持 | PASS：线程属性明确，无全局线程设置或新Queue | PASS：用户仅选CPU，准备绑定，执行不计时裁决 | PASS：既有SDK/package seam，stub仅声明实际边界 |

| Gate | 证据与限制 | Verdict |
|---|---|---|
| scope | MN1–4固定；十三kind及gate输入模式逐项回映；不扩张自研数学/模型loader/GPU | PASS |
| architecture | 既有Native binary/ATen独立factory、原Tensor程序和对齐packing、CPU/Graph成熟顺序；无新万能executor | PASS |
| correctness | 两平台120/120、CPU12通过/1旧fixture跳过、Graph15/15、头1/1；逐能力矩阵及故障/资源资格 | PASS |
| delivery | 两平台相同consumer source shared/static、installed shared/static；725产品输入hash复用证明/1333 forward identity | PASS |
| usability_docs | 普通入口/数值阶段/alias/managed成本/SDK平台限制说明；docs/closure通过 | PASS |
| red_team | root独立一次固定MN范围源码/收据复核；两fixture问题保留，原尾部参考及物理故障/其它owner边界明确 | PASS |
| engineering_performance | P0包含全部Byte packing/Double-F32 casts/原Tensor节点/temporary与metadata；无Native P1/SOTA/WIN | PASS |

sanitizer/codegen测量不在本卡预声明验证；未改intrinsic/layout ABI/source hint，不制造测量。
native物理OOM和非coherent映射故障仅源码检查，不写注入PASS；受供allocator冷OOM已实测。
旧Qwen fixture跳过不计PASS，主/正交ordinary旅程实际运行。测试警告修正不改变不可变产品，
不用测试维护commit制造新算法candidate或重做Windows交付。

最终 **CLOSED**：候选 `{candidate}`，全部适用MN工程门完成；产品字节候选后未改。
有限重开条件：本批具名语义/资源/生命周期/组合/交付反例或相关依赖升级。
统一Compute+Graph LOC **{loc['code']:,}/{loc['files']}文件**，不含测试/vendor。CPU整体未完成，
其它成熟边界及冻结自研逐域裁决仍需后续有限批次。
'''
card_path.write_bytes(card.encode())
registry = root / 'docs/implementation/module-status.json'
data = json.loads(registry.read_bytes())
entry = next(x for x in data['modules'] if x['module'] == 'compute_provider_native')
assert entry['state'] == 'CANDIDATE' and entry['candidate'] == candidate
entry['state'] = 'CLOSED'
entry['summary'] = 'MN1–4 CLOSED：原ATen四stable Unary/三gate、number MinMax/四Reduce的F32/F16/BF16 exact/stride数值程序；Win/Linux120/120、CPU12通过/1旧fixture跳过、Graph15/15、普通Direct/Graph三交付及P0通过。Native自研冻结，CPU整体未完。'
entry['performance'] = dict(tier='P0', evidence='evidence/correctness/cpu-aten-numeric/README.md')
registry.write_bytes((json.dumps(data, ensure_ascii=False, indent=2)+'\n').encode())

def edit(path, replacements):
    target = root / path
    contents = target.read_bytes()
    for old, new in replacements:
        old, new = old.encode(), new.encode()
        assert old in contents, (path, old)
        contents = contents.replace(old, new, 1)
    target.write_bytes(contents)

edit('docs/user/compute.md', [
    ('再匹配已构建的ATen存储/索引程序，Native只保留具名残余；', '再匹配已构建的ATen原程序，Native只保留具名残余；')])
target = root / 'docs/user/compute.md'
contents = target.read_bytes()
anchor = 'CPU 默认入口也支持 `model_ops::block_quantization_roundtrip()` 的'.encode()
assert anchor in contents
addition = '''同一ATen接入还覆盖F32/F16/BF16的SiLU、GELU、GELU-tanh、Softplus，三种packed/separate
gate、number Min/Max和四种Reduce；exact/rank<=8、合法byte stride、dense output。Reduce显式F32
accumulation（F32也允许Unknown）。稳定activation用原Double Tensor程序后显式F32，gate在F32
乘法后一次storage舍入；输入必须原Byte packing到冷私有对齐native槽。Unary/Binary只有dense
equal-desc端口允许精确alias；Gate/Reduce无alias。Double转换/原Tensor节点/临时数据均收费，
仍为managed leaf，不承诺零热分配或性能WIN。已锁SDK仅Windows/Linux x86_64；其他平台不继承
这项资格。[数值范围和两平台交付](../../evidence/correctness/cpu-aten-numeric/README.md)。

'''.encode()
target.write_bytes(contents.replace(anchor, addition + anchor, 1))
target = root / 'docs/user/graph.md'
contents = target.read_bytes()
anchor = '固定画像的当前运行结果及Windows三交付'.encode()
assert anchor in contents
addition = '''同一ATen leaf还接稳定activation/gate、number Min/Max与多轴Reduce，F32/F16/BF16变化输入
已通过普通Direct和op→Copy Graph三交付；[范围/数值阶段/alias/成本](../../evidence/correctness/cpu-aten-numeric/README.md)
同Compute，限定已锁Windows/Linux x86_64 SDK。原Double/F32转换、packing和临时Tensor成本仍在
该原程序中，不冒充完整模型region或性能WIN，不改变已有ggml/oneDNN融合。
'''.encode()
target.write_bytes(contents.replace(anchor, addition + anchor, 1))
edit('docs/implementation/tasks/compute/cpu-native-provider-domain-decision.md', [
    ('当前绑定[MN卡](cpu-aten-numeric-admission.md) CANDIDATE；', '当前绑定[MN卡](cpu-aten-numeric-admission.md) CLOSED；'),
    ('| Unary | ggml Abs/Neg/Exp/Log/Sqrt/Rsqrt/Tanh/Sigmoid/ReLU三floating dtype；oneDNN dense F32稳定Softplus | SiLU/GELU/GELU-tanh、narrow Softplus、特殊layout/alias/非有限尾部仍需成熟资格 | DECISION_REQUIRED，按kind/dtype分开；ReLU成熟接线已验 |',
     '| Unary | ggml Abs/Neg/Exp/Log/Sqrt/Rsqrt/Tanh/Sigmoid/ReLU三floating dtype；oneDNN dense F32稳定Softplus；ATen三dtype稳定SiLU/GELU/GELU-tanh/Softplus，rank<=8/odd-byte与限定exact alias | bounded/严格预算及原ggml有限尾部仍待具名核对 | DECISION_REQUIRED，按kind/dtype/精度与资源分开；MN成熟接线已验 |'),
    ('| Binary/Select | ggml Add/Subtract/Multiply/Divide；oneDNN Bool Select广播/plain分支；ATen全15scalar exact Select/odd-byte stride/非零condition | number Min/Max的NaN/signed-zero、特殊alias/预算/bounded域 | DECISION_REQUIRED；宽位Select成熟接线已验 |',
     '| Binary/Select | ggml Add/Subtract/Multiply/Divide；oneDNN Bool Select广播/plain分支；ATen全15scalar exact Select及三floating number Min/Max/odd-byte/broadcast/NaN-signed-zero与限定dense exact alias | 其它alias/严格预算/bounded域 | DECISION_REQUIRED；SI/MN成熟接线已验 |'),
    ('| Reduce | ggml Sum/Mean、Unknown/F32 accumulation | Min/Max语义、部分axes/rank/empty/checked strides | DECISION_REQUIRED |',
     '| Reduce | ggml Sum/Mean、Unknown/F32 accumulation；ATen三floating四kind、任意合法axes/keepdim/rank0..8/empty/byte stride，显式F32 accumulation，NaN与零号资格 | bounded/严格预算；native内部内存unknown | DECISION_REQUIRED；MN成熟接线已验 |'),
    ('| GatedActivation | ggml SiLU的packed/separate浮点端口；原位-Inf数值边界已完成两平台三交付资格 | 原版数学核不改；GELU/GELU-tanh原函数未接，alias/layout单列 | SiLU DECISION_REQUIRED；其它kind继续成熟准入核对，边界检查和必要cast成本全部计入 |',
     '| GatedActivation | ggml SiLU packed/separate与-Inf边界；ATen三kind/三dtype packed-separate、rank<=8/odd-byte，稳定F32 activation+乘法后一次舍入，普通Graph下游已验 | 原ggml SiLU有限负尾部另核对；bounded/严格预算；公共gate禁止alias | DECISION_REQUIRED；MN成熟接线已验，完整Double/F32 cast/packing/原节点成本包含 |'),
    ('与[SI批](cpu-aten-storage-index-admission.md)已分别真实关闭；', '、[SI批](cpu-aten-storage-index-admission.md)与[MN批](cpu-aten-numeric-admission.md)已分别真实关闭；'),
    ('activation/gate、Min/Max/reduce、RoPE/I64 positions、Bool/log-softmax、FP8 numeric Cast与其它具名shape/资源域候选仍需批量资格；', 'RoPE/I64 positions、Bool/log-softmax、FP8 numeric Cast与其它具名shape/资源域候选仍需批量资格；'),
    ('MN数值批候选已完成Windows120/120与三dtype普通Direct/Graph首批验证，Linux/三交付尚未完整\n资格，不提前更新上表为全验收。', 'MN数值批已完成Windows/Linux120/120、三dtype普通Direct/Graph与三交付资格，上表更新为本批\n已接域，不是性能WIN或CPU整体完成。')])
print(json.dumps(dict(candidate=candidate, fixture=qualification, archive=report['archive'], loc=report['loc'],
                     cleanup_bytes=cleanup_bytes, owner='compute_provider_native CLOSED'), ensure_ascii=False))
