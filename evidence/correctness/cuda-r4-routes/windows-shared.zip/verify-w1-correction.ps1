$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/noninteractive.ps1
$routeRoot='C:/hyle-scratch/r4-cuda-20260916/routes'
$routeBuild='C:/hyle-scratch/r4-cuda-20260916/marlin-shared'
Set-Location C:/public/project-hyle/hyle
& scripts/hyle-windows.ps1 -Action Build -Preset windows-ninja -BinaryDir $routeBuild -ExtraArgs @('--target','hyle_graph_route_cuda_test','--parallel','2') *> "$routeRoot/build-correction.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$routeRoot/build-correction.log" -Tail 70; exit $LASTEXITCODE }
ctest --test-dir $routeBuild -C Release --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 -R '^hyle_graph_route_cuda_test$' *> "$routeRoot/test-correction.log"
$routeVerdict=$LASTEXITCODE
Copy-Item -LiteralPath "$routeBuild/Testing/Temporary/LastTest.log" -Destination "$routeRoot/LastTest-correction.log"
Get-Content "$routeRoot/test-correction.log" -Tail 90
exit $routeVerdict
