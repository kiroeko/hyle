$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/noninteractive.ps1
$routeRoot = 'C:/hyle-scratch/r4-cuda-20260916/routes'
$routeBuild = 'C:/hyle-scratch/r4-cuda-20260916/marlin-shared'
Set-Location C:/public/project-hyle/hyle
& scripts/hyle-windows.ps1 -Action Configure -Preset windows-ninja -BinaryDir $routeBuild -Factor 'compute_route_cuda;graph_route_cuda' -DependencySourceCache C:/public/project-hyle/.deps -ExtraArgs @('-DHYLE_COMPUTE_CUDA=ON','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF') *> "$routeRoot/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$routeRoot/configure.log" -Tail 60; exit $LASTEXITCODE }
& scripts/hyle-windows.ps1 -Action Build -Preset windows-ninja -BinaryDir $routeBuild -ExtraArgs @('--target','hyle_compute_route_cuda_tests','hyle_graph_route_cuda_tests','--parallel','2') *> "$routeRoot/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$routeRoot/build.log" -Tail 80; exit $LASTEXITCODE }
$routeDlls = @('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cudart64_13.dll','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/cublasLt64_13.dll','C:/Windows/System32/msvcp140.dll','C:/Windows/System32/msvcp140_atomic_wait.dll','C:/Windows/System32/vcruntime140.dll','C:/Windows/System32/vcruntime140_1.dll')
$routeExecutables = Get-ChildItem -LiteralPath $routeBuild -Recurse -Filter '*route_cuda_test.exe'
foreach ($routeExecutable in $routeExecutables) {
 foreach ($routeDll in $routeDlls) { Copy-Item -LiteralPath $routeDll -Destination $routeExecutable.DirectoryName -Force }
}
$routeDlls | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath "$routeRoot/runtime.json" -Encoding utf8
ctest --test-dir $routeBuild -C Release --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 -R '^hyle_(compute|graph)_route_cuda(_header_self_contained)?_test$' *> "$routeRoot/test.log"
$routeVerdict = $LASTEXITCODE
Copy-Item -LiteralPath "$routeBuild/Testing/Temporary/LastTest.log" -Destination "$routeRoot/LastTest.log"
Get-Content "$routeRoot/test.log" -Tail 80
exit $routeVerdict
