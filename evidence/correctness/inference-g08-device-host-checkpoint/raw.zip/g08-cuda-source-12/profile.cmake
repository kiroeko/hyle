if(PROJECT_NAME STREQUAL "hyle")
  function(g08_cuda_profile)
    set_property(GLOBAL APPEND PROPERTY JOB_POOLS g08_cuda_compile=1)
    foreach(owner IN ITEMS compute_backend_cuda compute_provider_cuda compute_provider_flashinfer compute_provider_torch_cuda)
      set_target_properties(hyle_${owner} PROPERTIES JOB_POOL_COMPILE g08_cuda_compile)
    endforeach()
    # Retain G07's exact flags on its owners; only the two modified/new G08
    # translation units acquire split compile. This is a scratch profile.
    foreach(owner IN ITEMS compute_provider_flashinfer compute_provider_torch_cuda)
      set_target_properties(hyle_${owner} PROPERTIES CUDA_ARCHITECTURES 89-real)
      target_compile_options(hyle_${owner} PRIVATE "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
    endforeach()
    set_source_files_properties(
      "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda/collectives.cu"
      "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda/sampling_kernel.cu"
      DIRECTORY "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda"
      PROPERTIES COMPILE_OPTIONS "--split-compile=3")
    if(TARGET hyle_compute_provider_cuda_sampling_math_test)
      set_target_properties(hyle_compute_provider_cuda_sampling_math_test PROPERTIES
        JOB_POOL_COMPILE g08_cuda_compile CUDA_ARCHITECTURES 89-real)
      target_compile_options(hyle_compute_provider_cuda_sampling_math_test PRIVATE
        "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
    endif()
    add_executable(g08_cpu_topk_holdout "${PROJECT_SOURCE_DIR}/tests/compute_provider_ggml/cpu_provider_test.cc")
    target_link_libraries(g08_cpu_topk_holdout PRIVATE hyle_compute_provider_ggml hyle_compute_backend_cpu hyle_compute_batch hyle_compute_route_cpu hyle_simd GTest::gtest_main ggml)
    add_executable(g08_cpu_graph_topk_holdout "${PROJECT_SOURCE_DIR}/tests/graph_route_cpu/graph_test.cc")
    target_link_libraries(g08_cpu_graph_topk_holdout PRIVATE hyle_graph_route_cpu GTest::gtest_main ggml)
    add_executable(g08_cuda_topk_holdout "${PROJECT_SOURCE_DIR}/tests/compute_provider_cuda/collectives_test.cc")
    target_link_libraries(g08_cuda_topk_holdout PRIVATE hyle_compute_provider_cuda hyle_compute_backend_cuda GTest::gtest_main)
    add_executable(g08_cuda_graph_topk_holdout "${PROJECT_SOURCE_DIR}/tests/graph_route_cuda/topk_test.cc")
    target_link_libraries(g08_cuda_graph_topk_holdout PRIVATE hyle_graph_route_cuda GTest::gtest_main)
    foreach(target IN ITEMS g08_cpu_topk_holdout g08_cpu_graph_topk_holdout g08_cuda_topk_holdout g08_cuda_graph_topk_holdout)
      target_compile_features(${target} PRIVATE cxx_std_23)
      hyle_stage_runtime(${target})
    endforeach()
  endfunction()
  cmake_language(DEFER CALL g08_cuda_profile)
endif()
