from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps'
label=sys.argv[1];out=scratch/f'g08-cuda-source-{label}';out.mkdir(exist_ok=False)
source=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
started=time.monotonic();env=os.environ.copy()
env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
r=dict(state='SETUP',scope='G08 ordinary implementation batch, not immutable candidate qualification',
       label=label,pid=os.getpid(),stages=[],max_jobs=2,nvcc_pool=1,nvcc_split_compile=3,source=str(source),build=str(build))
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
    stamp=time.monotonic();log=out/(stage+'.log')
    with log.open('w') as stream:
        p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
        r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True)
        code=p.wait()
    r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)))
    r.pop('child_pid',None);save()
    if code:
        r['state']='FAIL';save();print(log.read_text(errors='replace')[-9000:],flush=True);raise SystemExit(code)
try:
    assert source.is_dir() and not (source/'.git').exists()
    with zipfile.ZipFile(scratch/f'g08-input-{label}.zip') as z:
        manifest=json.loads(z.read('input-manifest.json'));r['source_snapshot']=manifest['source_snapshot']
        changed=[]
        for item in manifest['inputs']:
            rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
            data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
            assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==item['sha256'],str(rel)
            p=source/rel
            if not p.exists() or p.read_bytes()!=data:
                p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
        (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
    r['synced_paths']=changed
    r['identity']={name:subprocess.check_output(cmd,env=env,text=True).strip() for name,cmd in [
        ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['nvcc','--version']),
        ('gpu',['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader'])]}
    if '--reuse-configure' in sys.argv:
        assert all(not p.startswith('cmake/') and not p.endswith('CMakeLists.txt') for p in changed),changed
        assert all(p.startswith(('tests/','docs/','evidence/','src/compute_route_apple/','src/compute_route_vulkan/','src/graph_route_vulkan/')) for p in changed),changed
        r['configure_reuse']='Same source/tree/profile/options; consumer bodies/headers/docs plus bodies of disabled Apple/Vulkan owners changed'
    else:
        run('configure',['cmake','-S',str(source),'-B',str(build),'-DHYLE_INSTALL=OFF',
            '-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF',
            '-DCMAKE_PROJECT_INCLUDE='+str(scratch/'g08_cuda_profile.cmake')])
    run('manifest',['ninja','-C',str(build),'build.ninja'])
    run('native-reuse',['python3',str(scratch/'g04-g05/ce28_shipping_native_reuse_wsl.py'),'shared','g08-'+label])
    reuse=scratch/f'g04-g05/ce28-shared-native-reuse-g08-{label}'
    proof=json.loads((reuse/'result.json').read_text())
    assert proof['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
    r['native_reuse']=proof;preview=reuse/'reuse.ninja'
    targets=['hyle_compute_ops_sampling_test','hyle_compute_route_cpu_sampling_consumer_test',
        'hyle_graph_route_cpu_sampling_consumer_test','hyle_compute_route_cuda_sampling_consumer_test',
        'hyle_graph_route_cuda_sampling_consumer_test']
    if '--math' in sys.argv:targets.append('hyle_compute_provider_cuda_sampling_math_test')
    if '--joint' in sys.argv:targets.append('hyle_graph_route_cpu_cuda_sampling_consumer_test')
    if '--mem' in sys.argv:targets.insert(0,'hyle_mem_test')
    if '--only-joint' in sys.argv:targets=['hyle_graph_route_cpu_cuda_sampling_consumer_test']
    if '--ports-only' in sys.argv:targets=['hyle_graph_route_cpu_sampling_consumer_test','hyle_graph_route_cuda_sampling_consumer_test']
    if '--holdouts' in sys.argv:targets=['g08_cpu_topk_holdout','g08_cpu_graph_topk_holdout','g08_cuda_topk_holdout','g08_cuda_graph_topk_holdout']
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
    (out/'dry-run.log').write_text(dry)
    cuda=[x for x in dry.splitlines() if 'Building CUDA object' in x];r['cuda_edges']=cuda
    allowed=['collectives.cu','sampling_kernel.cu']+(['sampling_math_probe.cu'] if '--math' in sys.argv else [])
    assert len(cuda)<=len(allowed) and all('compute_provider_cuda' in x and any(n in x for n in allowed) for x in cuda),cuda
    assert 'Re-running CMake' not in dry
    save();run('build',['ninja','-C',str(build),'-f',str(preview),'-j','2',*targets])
    for target in targets:
        binary=build/'bin'/target
        args=[str(binary)]+(['--ports-only'] if '--ports-only' in sys.argv else [])
        if '--holdouts' in sys.argv:
            filters={'g08_cpu_topk_holdout':'GgmlCpuProvider.StandardSelection*',
                     'g08_cpu_graph_topk_holdout':'CpuDefaultGraph.StandardTopK*',
                     'g08_cuda_topk_holdout':'CudaCccl.TopK*:CudaCccl.Invalid*',
                     'g08_cuda_graph_topk_holdout':'*'}
            args+=['--gtest_filter='+filters[target]]
        run(target,args)
        r.setdefault('artifacts',[]).append(dict(target=target,path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
    r['state']='SOURCE_BATCH_PASS_GPU_RISKS_DELIVERY_PERF_PENDING';save();print(r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
