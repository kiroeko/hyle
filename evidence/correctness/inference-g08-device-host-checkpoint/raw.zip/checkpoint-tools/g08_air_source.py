from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');route,label=sys.argv[1:3]
assert route in ['apple','vulkan']
package=sys.argv[3] if len(sys.argv)>3 and not sys.argv[3].startswith('--') else label
out=base/f'g08-{route}-source-{label}';resume='--resume-preflight' in sys.argv
if not resume:out.mkdir(exist_ok=False)
source=base/'source-c8874688';build=base/f'a-cpu-{route}/selected-graph/shared-sdk-build'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
if '--metal-validation' in sys.argv:env.update(MTL_DEBUG_LAYER='1',MTL_SHADER_VALIDATION='1')
if route=='vulkan':
    env['HYLE_VULKAN_VALIDATION']='0' if '--without-validation' in sys.argv else '1'
    env['HYLE_TEST_VULKAN_VALIDATE']=env['HYLE_VULKAN_VALIDATION']
started=time.monotonic()
r=dict(state='SETUP',scope='G08 ordinary implementation source batch; not immutable candidate/SDK/P1 acceptance',
       route=route,label=label,pid=os.getpid(),source=str(source),build=str(build),max_jobs=4,stages=[])
if '--metal-validation' in sys.argv:r['metal_validation_requested']={key:env[key] for key in ['MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']}
if route=='vulkan':
    r['vulkan_validation_requested']=env['HYLE_VULKAN_VALIDATION']=='1'
if resume:
    r=json.loads((out/'result.json').read_text());assert r['state']=='SETUP_FAIL'
    r.setdefault('retained_preflight_failures',[]).append(dict(state=r['state'],error=r.get('error'),elapsed_seconds=r['elapsed_seconds'],
        reason='Preserve original dry run; use byte-identical frozen manifest as in existing source qualification, avoiding VERIFY_GLOBS dry-run regeneration.'))
    started=time.monotonic()-r['elapsed_seconds'];r['pid']=os.getpid();r.pop('error',None)
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,command,required=True):
    stamp=time.monotonic();log=out/(stage+'.log')
    with log.open('w') as stream:
        process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
        r.update(state='RUNNING',stage=stage,child_pid=process.pid);save();print(stage,process.pid,flush=True)
        code=process.wait()
    r['stages'].append(dict(stage=stage,command=command,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)))
    r.pop('child_pid',None);save()
    if code:
        print(log.read_text(errors='replace')[-9000:],flush=True)
        if required:r['state']='FAIL';save();raise SystemExit(code)
    return code
try:
    r['identity']={name:subprocess.check_output(cmd,env=env,text=True).strip() for name,cmd in [
        ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
        ('compiler',['xcrun','clang','--version']),('metal',['xcrun','-sdk','macosx','metal','--version']),
        ('gpu',['/usr/sbin/system_profiler','SPDisplaysDataType'])]}
    assert r['identity']['model']=='Mac16,12' and r['identity']['arch']=='arm64'
    assert source.is_dir() and not (source/'.git').exists()
    with zipfile.ZipFile(base/f'g08-input-{package}.zip') as z:
        manifest=json.loads(z.read('input-manifest.json'));r['source_snapshot']=manifest['source_snapshot'];changed=[]
        for item in manifest['inputs']:
            rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
            data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
            p=source/rel
            if not p.exists() or p.read_bytes()!=data:
                p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
        (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
    r['synced_paths']=changed
    if resume:
        assert not changed,changed
        r['configure_reuse']='Original successful configure/manifest; exact source archive and options unchanged'
    elif '--reuse-configure' in sys.argv:
        assert all(not p.endswith('CMakeLists.txt') and not p.startswith('cmake/') for p in changed),changed
        r['configure_reuse']='Same source/tree/options/profile, existing source/header/consumer bodies only'
    else:
        run('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),
            '-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF',
            '-DHYLE_TEST_INSTRUMENTATION=OFF','-DCMAKE_PROJECT_INCLUDE='+str(base/'g08_air_profile.cmake')])
    if not resume:run('manifest',['/opt/homebrew/bin/ninja','-C',str(build),'build.ninja'])
    preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
    r['frozen_manifest_sha256']=hashlib.sha256(preview.read_bytes()).hexdigest()
    targets=['hyle_mem_test','hyle_compute_ops_sampling_test',
        'hyle_compute_route_cpu_sampling_consumer_test','hyle_graph_route_cpu_sampling_consumer_test',
        f'hyle_compute_route_{route}_sampling_consumer_test',f'hyle_graph_route_{route}_sampling_consumer_test',
        f'hyle_compute_route_{route}_sampling_math_test',f'hyle_graph_route_cpu_{route}_sampling_consumer_test',
        f'g08_{route}_topk_holdout']
    if '--selected-only' in sys.argv:targets=sys.argv[sys.argv.index('--selected-only')+1:]
    if resume and (out/'dry-run.log').exists():(out/'original-dry-run.log').write_bytes((out/'dry-run.log').read_bytes())
    dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
    (out/'dry-run.log').write_text(dry);r['build_edges']=len(dry.splitlines());save()
    assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry
    run('build',['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-j','4',*targets])
    failures=[]
    for target in targets:
        binary=build/'bin'/target
        args=[str(binary)]
        if '--phase' in sys.argv and 'consumer_test' in target:
            args+=[sys.argv[sys.argv.index('--phase')+1]]
        if target=='g08_apple_topk_holdout':
            args+=['--gtest_filter=AppleReduction.*TopK*:AppleReduction.EmptyResultsAndPreparationRejections:AppleGraph.*']
        code=run(target,args,False)
        r.setdefault('artifacts',[]).append(dict(target=target,sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
        if code:failures.append(dict(target=target,exit_code=code))
    r['failures']=failures;r['state']='SOURCE_BATCH_PASS_RISKS_DELIVERY_PERF_PENDING' if not failures else 'FAIL_WITH_ALL_TARGETS_OBSERVED'
    save();print(r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
