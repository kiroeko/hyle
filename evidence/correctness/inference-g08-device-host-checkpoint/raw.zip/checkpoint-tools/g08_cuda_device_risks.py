from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps'
label=sys.argv[1];out=scratch/f'g08-cuda-device-risks-{label}';out.mkdir(exist_ok=False)
prior=json.loads((scratch/'g08-cuda-source-12/result.json').read_text());assert prior['state']=='SOURCE_BATCH_PASS_GPU_RISKS_DELIVERY_PERF_PENDING'
build=Path(prior['build']);manifest=scratch/'g04-g05/ce28-shared-native-reuse-g08-12/reuse.ninja'
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
started=time.monotonic();r=dict(state='SETUP',pid=os.getpid(),source_snapshot=prior['source_snapshot'],identity=prior['identity'],
    build=str(build),scope='G08 changed CUDA selection/random/categorical kernels and public Graph/joint consumers on actual device tools; no whole-library or driver host/leak certificate.',stages=[],max_jobs=2)
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
    r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
    if code:
        r['state']='FAIL';save();print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
    return log.read_text(errors='replace')
try:
    targets=['hyle_compute_route_cuda_sampling_consumer_test','hyle_compute_provider_cuda_sampling_math_test','hyle_graph_route_cpu_cuda_sampling_consumer_test']
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(manifest),'-n',*targets],env=env,text=True)
    (out/'dry-run.log').write_text(dry);assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry,dry
    run('build',['ninja','-C',str(build),'-f',str(manifest),'-j','2',*targets])
    cases=[('topk','g08_cuda_topk_holdout',['--gtest_filter=CudaCccl.TopKFourTypesStableTiesNaNsAndOriginalBits']),
           ('raw','hyle_compute_route_cuda_sampling_consumer_test',['--random-only']),
           ('categorical','hyle_compute_route_cuda_sampling_consumer_test',['--categorical-only']),
           ('graph-ports','hyle_graph_route_cuda_sampling_consumer_test',['--ports-only']),
           ('joint','hyle_graph_route_cpu_cuda_sampling_consumer_test',[]),
           ('math','hyle_compute_provider_cuda_sampling_math_test',[])]
    r['artifacts']=[dict(path=str(build/'bin'/name),sha256=hashlib.sha256((build/'bin'/name).read_bytes()).hexdigest()) for name in sorted(set(x[1] for x in cases))]
    run('tool-version',['/usr/local/cuda-13.3/bin/compute-sanitizer','--version'])
    for tool in ['memcheck','racecheck']:
        for stage,target,args in cases:
            log=run(tool+'-'+stage,['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool',tool,'--error-exitcode','86',str(build/'bin'/target),*args])
            expected='ERROR SUMMARY: 0 errors' if tool=='memcheck' else 'RACECHECK SUMMARY: 0 hazards'
            assert expected in log,(tool,stage,log[-3000:])
    r['state']='CUDA_DEVICE_RISKS_PASS';save();print(r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
