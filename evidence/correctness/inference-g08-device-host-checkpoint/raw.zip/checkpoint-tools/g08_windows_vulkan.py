from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[2];label=sys.argv[1]
out=root/'.scratch/inference-gaps'/f'g08-windows-vulkan-{label}';resume='--resume-preflight' in sys.argv
if not resume:out.mkdir(exist_ok=False)
build=Path('C:/h7/w-vulkan/selected-graph/shared-sdk-build')
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf-8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
sdk=Path('C:/public/tools/hyle-vulkan/1.4.357.0');env.update(VSLANG='1033',VULKAN_SDK=str(sdk),HYLE_VULKAN_VALIDATION='1',HYLE_TEST_VULKAN_VALIDATE='1',
    VK_LAYER_PATH=str(sdk/'Bin'),VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LOADER_LAYERS_DISABLE='~implicit~')
env['PATH']=str(sdk/'Bin')+';'+env['PATH']
os.environ['VK_LAYER_PATH']=env['VK_LAYER_PATH'];os.environ['VK_LOADER_LAYERS_DISABLE']=env['VK_LOADER_LAYERS_DISABLE']
ctypes.windll.kernel32.SetErrorMode(0x0001|0x0002|0x8000)
started=time.monotonic();r=dict(state='SETUP',pid=os.getpid(),build=str(build),max_jobs=4,
    source_snapshot=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    scope='G08 actual Windows Vulkan numerical/validation and Windows Mem244 ordinary source; no SDK/P1 acceptance or Air validation-layer claim.',stages=[])
if resume:
    r=json.loads((out/'result.json').read_text());assert r['state']=='SETUP_FAIL' and (r['build_edges']==459 or r['build_edges']<40)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==r['source_snapshot']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
    r.setdefault('retained_preflight_failures',[]).append(dict(error=r.pop('error'),elapsed_seconds=r['elapsed_seconds'],
        reason='Retain original preflight failure and same configure/tree/manifest. Reviewed full459 dependency batch has five real native input differences; small incremental batches retain existing ExternalProject build/install no-op bookkeeping. CPU and priority remain bounded.'))
    started=time.monotonic()-r['elapsed_seconds'];r['pid']=os.getpid()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
def run(stage,cmd,required=True):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('wb') as stream:
        flags=subprocess.CREATE_NO_WINDOW|(subprocess.BELOW_NORMAL_PRIORITY_CLASS if stage=='build' else 0)
        p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=flags)
        if stage=='build':
            get=ctypes.windll.kernel32.GetProcessAffinityMask;get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
            set_mask=ctypes.windll.kernel32.SetProcessAffinityMask;set_mask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
            available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle))
            if not get(handle,ctypes.byref(available),ctypes.byref(system)):
                p.terminate();p.wait();raise OSError('Cannot read build process affinity')
            bits=[1<<i for i in range(64) if available.value&(1<<i)][:4];mask=sum(bits)
            if not set_mask(handle,mask):
                p.terminate();p.wait();raise OSError('Cannot bound build process affinity')
            r['build_resource_profile']=dict(priority='BELOW_NORMAL',cpu_affinity_mask=hex(mask),logical_cpus=len(bits),ninja_jobs=4,
                native_generator='Original ggml tool may launch up to16 glslc children; inherited four-CPU affinity and below-normal priority bound its CPU use. No vendor/tool source edits.')
        r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
    r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
    if code:
        print(log.read_text(encoding='utf-8',errors='replace')[-7000:],flush=True)
        if required:r['state']='FAIL';save();raise SystemExit(code)
    return code,log
try:
    class Layer(ctypes.Structure):
        _fields_=[('name',ctypes.c_char*256),('spec',ctypes.c_uint32),('implementation',ctypes.c_uint32),('description',ctypes.c_char*256)]
    vk=ctypes.WinDLL('vulkan-1.dll');fn=vk.vkEnumerateInstanceLayerProperties
    fn.argtypes=[ctypes.POINTER(ctypes.c_uint32),ctypes.POINTER(Layer)];fn.restype=ctypes.c_int
    count=ctypes.c_uint32();assert fn(ctypes.byref(count),None)==0
    layers=(Layer*count.value)();assert fn(ctypes.byref(count),layers)==0
    r['validation_discovery']=dict(layers=[x.name.decode() for x in layers],manifest=json.loads((sdk/'Bin/VkLayer_khronos_validation.json').read_text()),
        library_sha256=hashlib.sha256((sdk/'Bin/VkLayer_khronos_validation.dll').read_bytes()).hexdigest(),environment={k:env[k] for k in ['VK_LAYER_PATH','VK_INSTANCE_LAYERS','VK_LOADER_LAYERS_DISABLE','HYLE_VULKAN_VALIDATION']})
    assert 'VK_LAYER_KHRONOS_validation' in r['validation_discovery']['layers']
    r['identity']=dict(host=env.get('COMPUTERNAME'),compiler=env.get('VCTOOLSVERSION'),os=subprocess.check_output(['cmd','/d','/c','ver'],text=True).strip(),
        gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,uuid','--format=csv,noheader'],env=env,text=True).strip())
    if not resume and '--reuse-configure' not in sys.argv:
        run('configure',['cmake','-S',str(root),'-B',str(build),'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF',
            '-DHYLE_TEST_INSTRUMENTATION=OFF','-DCMAKE_PROJECT_INCLUDE='+str(root/'.scratch/inference-gaps/g08_air_profile.cmake')])
        run('manifest',['ninja','-C',str(build),'build.ninja'])
    preview=out/'preview.ninja'
    if resume:assert preview.read_bytes()==(build/'build.ninja').read_bytes()
    else:preview.write_bytes((build/'build.ninja').read_bytes())
    targets=['hyle_mem_test','hyle_compute_route_vulkan_sampling_consumer_test','hyle_graph_route_vulkan_sampling_consumer_test',
        'hyle_compute_route_vulkan_sampling_math_test','g08_vulkan_topk_holdout']
    if '--selected-only' in sys.argv:
        selected=sys.argv[sys.argv.index('--selected-only')+1:];assert selected and set(selected)<=set(targets)
        targets=selected
    r['selected_targets']=targets
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
    (out/'dry-run.log').write_text(dry);r['build_edges']=len(dry.splitlines());save()
    assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry
    assert r['build_edges']<=500,dry[-6000:]
    if not resume and '--reuse-configure' not in sys.argv:assert r['build_edges']<300 and not any('vulkan-shaders-gen' in x for x in dry.splitlines()),dry[-6000:]
    if '--reuse-configure' in sys.argv:assert r['build_edges']<40,dry[-6000:]
    run('build',['ninja','-C',str(build),'-f',str(preview),'-j','4','-k','0',*targets])
    failed=[]
    for target in targets:
        binary=build/'bin'/(target+'.exe');code,log=run(target,[str(binary)],False)
        text=log.read_text(encoding='utf-8',errors='replace')
        if code or any(marker in text for marker in ['Validation Error','VUID-','SYNC-HAZARD']):failed.append(target)
        r.setdefault('artifacts',[]).append(dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
    r['failures']=failed;r['state']='SOURCE_AND_VULKAN_VALIDATION_PASS_SDK_PERF_PENDING' if not failed else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save();print(r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
