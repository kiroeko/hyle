from pathlib import Path
import hashlib,json,re,subprocess
scratch=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps');out=scratch/'g08-cuda-host-asan-1'
run=json.loads((out/'result.json').read_text());assert run['state']=='HOST_FACET_PASS'
text=(out/'targets.cmake').read_text();imported=Path(re.search(r'IMPORTED_LOCATION "([^"]+)"',text).group(1))
actual=hashlib.sha256(imported.read_bytes()).hexdigest();assert actual==run['native_reuse']['sha256']
assert str(imported) in (out/'preview.ninja').read_text()
commands=json.loads(subprocess.check_output(['ninja','-C',run['build'],'-t','compdb'],text=True))
suffixes=['src/mem/system.cc','src/compute_ops/sampling_ops.cc','src/compute_provider_native/sampling.cc',
    'src/compute_provider_ggml/standard_index.cc','src/compute_provider_cuda/sampling_provider.cc',
    'src/compute_provider_cuda/collectives.cu','src/compute_provider_cuda/sampling_kernel.cu',
    'tests/compute_ops/sampling_test.cc','tests/compute_route_cpu/sampling_consumer.cc',
    'tests/compute_route_cuda/sampling_consumer.cc','tests/graph_route_cpu_cuda/sampling_consumer.cc']
selected=[x for x in commands if any(x['file'].endswith('/'+suffix) for suffix in suffixes)]
assert len(selected)>=13 and all('-fsanitize=address' in x['command'] for x in selected)
(out/'all-changed-owner-instrumented-inputs.json').write_text(json.dumps(selected,indent=2)+'\n')
r=dict(state='PASS',actual_imported_archive=str(imported),sha256=actual,reference_archive=run['native_reuse']['archive'],
    instrumented_selected_units=len(selected),
    scope='Post-run exact imported archive matches the original byte-qualified native archive; full derived/canonical input identities already checked before build.')
(out/'actual-imported-native-reuse.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
