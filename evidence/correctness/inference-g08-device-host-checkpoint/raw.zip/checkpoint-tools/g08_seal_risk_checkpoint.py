from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path(__file__).resolve().parents[2];scratch=root/'.scratch/inference-gaps'
out=root/'evidence/correctness/inference-g08-device-host-checkpoint'
assert not subprocess.check_output(['git','ls-files','--',str(out.relative_to(root))],cwd=root,text=True).strip()
out.mkdir(exist_ok=True)
names=['g08-cuda-source-11','g08-cuda-source-12','g08-cuda-source-13','g08-cuda-device-risks-1',
       'g08-cuda-host-asan-1','g08-cuda-host-ubsan-1','g08-cuda-host-tsan-1',
       *[f'g08-windows-vulkan-{i}' for i in range(1,5)],
       'g08-apple-device-risks-1','g08-apple-source-a5','g08-apple-source-a6','g08-vulkan-source-v6']
records=[json.loads((scratch/name/'result.json').read_text()) for name in names]
assert all(x['state']!='RUNNING' for x in records)
host_counts={}
for mode in ['asan','ubsan','tsan']:
    folder=scratch/f'g08-cuda-host-{mode}-1'
    assert json.loads((folder/'result.json').read_text())['state']=='HOST_FACET_PASS'
    host_counts[mode]={kind:int(re.search(r'\[  PASSED  \] ([1-9][0-9]*) tests?',(folder/f'g08_host_{kind}.log').read_text()).group(1)) for kind in ['mem','schema']}
assert json.loads((scratch/'g08-cuda-host-asan-1/actual-imported-native-reuse.json').read_text())['state']=='PASS'
for name in ['g08-apple-source-a6','g08-windows-vulkan-3','g08-windows-vulkan-4']:
    for p in (scratch/name).glob('*.log'):
        content=p.read_text(encoding='utf-8',errors='replace')
        assert not any(x in content for x in ['failed assertion','Shader Validation Error','MTLDebugCommandBuffer error','Validation Error','VUID-','SYNC-HAZARD']),str(p)
review=dict(state='SOURCE12_CPU_GRAPH_NOT_QUALIFIED_SOURCE13_CORRECTED',
    original_execution_state=records[1]['state'],original_log='g08-cuda-source-12/g08_cpu_graph_topk_holdout.log',
    reason='Original private CPU Graph target omitted upstream test dependencies/macros and selected0 tests. Exit0 is not acceptance. Original result/log retained; only other three nonempty source12 selections are accepted.',
    correction='Same original TU with original test dependencies and macro; source13 nonempty1 test PASS. Private runner now requires nonempty selected GTest set.')
(scratch/'g08-cuda-source-12/nonempty-qualification-review.json').write_text(json.dumps(review,indent=2)+'\n')
tools=['g08_cuda_source.py','g08_cuda_profile.cmake','g08_cuda_device_risks.py','g08_cuda_host_risks.py',
       'g08_verify_asan_import.py','g08_windows_vulkan.py','g08_vulkan_derived_compare.py',
       'g08-vulkan-derived-comparison.json','g08_apple_device_risks.py','g08_air_source.py','g08_air_profile.cmake','g08_seal_risk_checkpoint.py']
with zipfile.ZipFile(out/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in names:
        for p in sorted((scratch/name).iterdir()):
            if p.is_file():z.write(p,f'{name}/{p.name}')
    for name in tools:
        p=scratch/name
        if p.is_file():z.write(p,'checkpoint-tools/'+name)
receipt=dict(schema='hyle.g08-device-host-checkpoint/v1',state='IN_PROGRESS_NOT_ACCEPTED',
    checkpoint_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    closure_card='docs/implementation/tasks/compute/inference-g08-output-selection.md',batches=records,
    prior_checkpoints=['evidence/correctness/inference-g08-implementation-checkpoint/receipt.json','evidence/correctness/inference-g08-air-implementation-checkpoint/receipt.json'],
    accepted_facts=[
        'source11 CPU/CUDA independent Graph ports PASS; CPU provider2, CUDA provider1, CUDA Graph1 source12 selected old TopK tests PASS; CPU Graph original selection0 rejected, corrected source13 real1 PASS.',
        'Actual CUDA memcheck/racecheck each6 cases, all12 zero errors/hazards. Product CUDA source unchanged by later Vulkan/Apple-only fixes.',
        'ASan/UBSan/TSan static host facets each PASS: Mem changed-TU counts51/50/50 respectively, schema3 each, CPU/CUDA four full Direct/Graph numerical/distribution/65-step/independent-port consumers and CPU+CUDA joint. Actual modified-owner instrumentation13 TUs and imported native archive qualification verified.',
        'Windows Vulkan with enumerated/requested Khronos1.4.357: Mem244 and oldTopK17 PASS W1. Original W1/W2 endpoint failure retained. Fixed W3 math1048772 pairs maxabs5.12140621e-6 PASS; W4 Direct/Graph full numerical/distribution/65-step/ports/origins PASS. No validation error/VUID/sync hazard in accepted logs.',
        'Air Vulkan v6 new math full numerical/distribution/65-step/independent ports/origins, actual1048772-pair math maxabs3.72330296e-6 and joint PASS; Air Khronos layer remains absent and no Air-layer acceptance is claimed.',
        'Apple original Metal API/GPU validation empty-Graph abort retained. a6 fixed empty Binary output after original schema/type checks: all5 Metal-validation targets PASS, including Direct/Graph full journeys, actual math, CPU+Apple joint and original4TopK holdouts with zero-row normalization.'
    ],
    retained_failures=['source12 selected0 is explicitly not PASS; see nonempty-qualification-review.json and source13 correction.',
        'Windows full459-edge preflight and small incremental ExternalProject bookkeeping preflight failures retained across same-tree resumes; original configure cost retained.',
        'Windows original native-log approximation endpoint error .002923995977 at wordsffff0000:00000000 retained; frozen2e-5 threshold unchanged.',
        'Apple original device-risk and a5 abort on rows0/experts256 Graph probability/TopK normalization retained; fixed a6 preserves same shape/tests/validation flags.'],
    known_batch_elapsed_seconds=sum(x['elapsed_seconds'] for x in records),
    total_cost='UNKNOWN beyond measured batches: packing, transfer, source inspection and process-affinity observation were not all timed; no zero-cost or reset claim.',
    original_cpu_graph_review=review,
    host_test_counts=host_counts,
    cpu_cuda_product_reuse=dict(reference='9fab024c9a5aecb56c32a726db9b0fe9365fecd9',
        product_delta=subprocess.check_output(['git','diff','--name-only','9fab024c9a5aecb56c32a726db9b0fe9365fecd9','HEAD','--','include','src','third_party','cmake','scripts'],cwd=root,text=True).splitlines(),
        reason='Later product changes are exclusively Apple/Vulkan native bodies. CPU/CUDA product inputs and their host/device evidence remain unchanged; new endpoint test diagnostic does not change oracle, corpus or threshold.'),
    pending=['Apple/Vulkan remaining applicable host sanitizer facets, source/static/shared relocated SDK/public headers and Mem remaining delivery facets.',
        'Immutable candidate, exact timing/CHARGED-DEFERRED preflight and qualified S1 P1 four routes plus Apple count3 holdout.',
        'Final P0/user documentation, independent review/LOC and terminal G08; G09/G10 unstarted.'],
    coarse_estimates=dict(g08_percent=75,g07_g10_goal_percent=45,accepted_items=1,total_items=4,meaning='Implementation estimate, not acceptance gate pass percentage.'),
    raw_archive=dict(path='raw.zip',sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest()))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
summaries={
 'mem':'G08 M1 AUDITED: mi_free_aligned fix source244/244 each on Windows/WSL/Air; selected static ASan51/UBSan50/TSan50 allocation/Buffer tests PASS. SDK/native host facets pending; natural path/layout/quota/vendor unchanged.',
 'compute_provider_ggml':'G08 AUDITED: TopK1 scan without V-sized Entry scratch, CPU full Direct/Graph numerical and original selected TopK provider/Graph holdouts PASS. Three static host sanitizer consumer facets PASS; SDK/S1 P1 pending.',
 'compute_provider_native':'G08 AUDITED: CPU counter/CDF full Direct/Graph numerical/distribution/65-step and independent-port consumers PASS, including all three static host sanitizer facets. SDK/final qualification pending; no speed claim.',
 'compute_provider_cuda':'G08 AUDITED: Direct/Graph/joint numerics and device1048772-pair math PASS; actual memcheck/racecheck all12 groups zero errors/hazards and all three static host sanitizer consumer facets PASS. SDK/S1 P1 pending.',
 'compute_route_apple':'G08 AUDITED: exact TopK keys and empty Binary consumer fix; all5 actual Metal API/GPU validation targets PASS a6 (Direct/Graph/math/joint/original4TopK), including zero-row normalization. Host sanitizer/SDK/S1 P1 pending.',
 'compute_route_vulkan':'G08 AUDITED: centered math/byte origins and stable small-tail log fix; Windows Khronos validation plus full Direct/Graph/ports/origins and actual1048772-pair math PASS, Air MoltenVK numerics/math/joint PASS. Host facets/SDK/S1 P1 pending.',
 'graph_route_vulkan':'G08 AUDITED: original plan/liveness/status/owners carry both sampling schemas; ID-only/score-only/both and native-origin View consumers PASS on actual Windows validation and Air ordinary route. SDK/final qualification pending.'
}
p=root/'docs/implementation/module-status.json';data=p.read_bytes();registry=json.loads(data)
for row in registry['modules']:
    if row['module'] in summaries:
        assert row['state']=='AUDITED' and row['record'].endswith('inference-g08-output-selection.md')
        row['summary']=summaries[row['module']]
text=json.dumps(registry,indent=2,ensure_ascii=False)+'\n'
if b'\r\n' in data:text=text.replace('\n','\r\n')
p.write_bytes(text.encode('utf-8'))
print(json.dumps(dict(out=str(out),raw_bytes=(out/'raw.zip').stat().st_size,known_batch_seconds=receipt['known_batch_elapsed_seconds'])))
