from pathlib import Path
import hashlib,json
base=Path('C:/h7/w-vulkan/selected-graph/shared-sdk-build/src/compute_ggml_runtime')
roots=sorted(base.glob('source-*'));assert len(roots)==2
maps=[{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.rglob('*') if p.is_file()} for r in roots]
diff=[p for p in sorted(maps[0].keys()|maps[1].keys()) if maps[0].get(p)!=maps[1].get(p)]
r=dict(roots=[str(p) for p in roots],file_counts=[len(x) for x in maps],diffs=diff)
Path('C:/public/project-hyle/hyle/.scratch/inference-gaps/g08-vulkan-derived-comparison.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
