from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps';mode,label=sys.argv[1:3]
assert mode in ['asan','ubsan','tsan']
out=scratch/f'g08-cuda-host-{mode}-{label}';out.mkdir(exist_ok=False)
prior=json.loads((scratch/'g08-cuda-source-12/result.json').read_text());assert prior['state']=='SOURCE_BATCH_PASS_GPU_RISKS_DELIVERY_PERF_PENDING'
source=Path(prior['source']);base=Path('/root/hyle-scratch/compute-unified');old=base/f'foundation-f5-native-host-cuda-{mode}';build=old/'build'
cache=(build/'CMakeCache.txt').read_text();assert f'HYLE_SANITIZER:STRING={mode}' in cache
original=scratch/'g06'/('final-host-'+dict(asan='asan-5',ubsan='ubsan-6',tsan='tsan-4')[mode])/'targets.cmake'
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
env.update(ASAN_OPTIONS='halt_on_error=1:protect_shadow_gap=0:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0')
started=time.monotonic();r=dict(state='SETUP',pid=os.getpid(),mode=mode,source_snapshot=prior['source_snapshot'],identity=prior['identity'],
    build=str(build),max_jobs=2,nvcc_pool=1,nvcc_split_compile=3,stages=[],
    limits=['Host sanitizer facet on changed CPU/CUDA adapters and Mem allocator boundary tests. No shader, driver, vendor-private allocator or process leak certificate.',
            'Same retained sanitizer tree, flags and byte-qualified original native ggml CUDA archive; existing G06 external diagnostic-thread lifetime limitations retained.'])
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd,required=True):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(mode,stage,p.pid,flush=True);code=p.wait()
    r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
    if code:
        print(log.read_text(errors='replace')[-7000:],flush=True)
        if required:r['state']='FAIL';save();raise SystemExit(code)
    return code
try:
    inputs=json.loads((scratch/'g08-cuda-source-12/input-manifest.json').read_text())['inputs']
    assert all(hashlib.sha256((source/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in inputs)
    text=original.read_text().split('  add_executable(g04_cuda_encoded_host_tests ',1)[0]
    text=text.replace(str(original.parent),str(out))
    text+='''
  set_target_properties(hyle_compute_provider_torch_cuda hyle_compute_provider_cuda PROPERTIES JOB_POOL_COMPILE g04_cuda_san_compile)
  set_target_properties(hyle_compute_provider_torch_cuda PROPERTIES CUDA_ARCHITECTURES 89-real)
  target_compile_options(hyle_compute_provider_torch_cuda PRIVATE "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
  set_source_files_properties("@SOURCE@/src/compute_provider_cuda/collectives.cu" "@SOURCE@/src/compute_provider_cuda/sampling_kernel.cu"
    DIRECTORY "@SOURCE@/src/compute_provider_cuda" PROPERTIES COMPILE_OPTIONS "--split-compile=3")
  add_executable(g08_host_mem "@SOURCE@/tests/mem/allocator_test.cc" "@SOURCE@/tests/mem/buffer_resource_test.cc")
  target_link_libraries(g08_host_mem PRIVATE hyle_mem GTest::gtest_main)
  target_include_directories(g08_host_mem PRIVATE "@SOURCE@/src/mem")
  add_executable(g08_host_schema "@SOURCE@/tests/compute_ops/sampling_test.cc")
  target_link_libraries(g08_host_schema PRIVATE hyle_compute_ops GTest::gtest_main)
  foreach(route IN ITEMS cpu cuda)
    foreach(kind IN ITEMS direct graph)
      set(target g08_host_${route}_${kind})
      add_executable(${target} "@SOURCE@/tests/compute_route_${route}/sampling_consumer.cc")
      target_link_libraries(${target} PRIVATE hyle_compute_route_${route} hyle_graph_route_${route})
      if(kind STREQUAL "graph")
        target_compile_definitions(${target} PRIVATE HYLE_G08_GRAPH=1)
      endif()
    endforeach()
  endforeach()
  add_executable(g08_host_joint "@SOURCE@/tests/graph_route_cpu_cuda/sampling_consumer.cc")
  target_link_libraries(g08_host_joint PRIVATE hyle_graph_route_cpu_cuda hyle_compute_backend_cuda)
  foreach(target IN ITEMS g08_host_mem g08_host_schema g08_host_cpu_direct g08_host_cpu_graph g08_host_cuda_direct g08_host_cuda_graph g08_host_joint)
    target_compile_features(${target} PRIVATE cxx_std_23)
    hyle_apply_sanitizer(${target})
    hyle_stage_runtime(${target})
  endforeach()
  set_source_files_properties("@SOURCE@/src/compute_backend_cuda/cuda_backend.cc" DIRECTORY "@SOURCE@/src/compute_backend_cuda" PROPERTIES COMPILE_DEFINITIONS HYLE_TESTING=1)
 endfunction()
 cmake_language(DEFER CALL g04_cuda_host_san)
endif()
'''.replace('@SOURCE@',str(source))
    hook=out/'targets.cmake';hook.write_text(text)
    configure=old/'parent' if mode=='asan' else source
    run('configure',['cmake','-S',str(configure),'-B',str(build),'-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES','-DCMAKE_PROJECT_INCLUDE='+str(hook),
        '-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF'])
    proof=json.loads((scratch/'g04-g05/cuda-host-san/ggml-cuda-reuse-proof.json').read_text())['modes'][mode]
    assert hashlib.sha256(Path(proof['archive']).read_bytes()).hexdigest()==proof['archive_sha256']
    imported=Path(re.search(r'IMPORTED_LOCATION "([^"]+)"',text).group(1))
    assert hashlib.sha256(imported.read_bytes()).hexdigest()==proof['archive_sha256']
    commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],env=env,text=True))
    unary=next(x for x in commands if x['file'].endswith('/src/ggml-cuda/unary.cu'));derived=Path(unary['file'].split('/src/ggml-cuda/')[0])
    for name,digest in proof['derived_dependencies']:assert hashlib.sha256((derived/name).read_bytes()).hexdigest()==digest
    for name,digest in proof['canonical_dependencies']:assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
    r['native_reuse']=dict(archive=proof['archive'],actual_imported_archive=str(imported),sha256=proof['archive_sha256'],derived_inputs=len(proof['derived_dependencies']),canonical_inputs=len(proof['canonical_dependencies']))
    flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode]
    selected=[x for x in commands if any(x['file'].endswith('/'+suffix) for suffix in ['src/mem/system.cc','src/compute_ops/sampling_ops.cc','src/compute_provider_native/sampling.cc','src/compute_provider_ggml/standard_index.cc','src/compute_provider_cuda/sampling_provider.cc','src/compute_provider_cuda/collectives.cu','src/compute_provider_cuda/sampling_kernel.cu','tests/compute_ops/sampling_test.cc','tests/compute_route_cpu/sampling_consumer.cc','tests/compute_route_cuda/sampling_consumer.cc','tests/graph_route_cpu_cuda/sampling_consumer.cc'])]
    assert len(selected)>=13 and all(flag in x['command'] for x in selected)
    (out/'instrumented-inputs.json').write_text(json.dumps(selected,indent=2))
    run('manifest',['ninja','-C',str(build),'build.ninja'])
    preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
    targets=['g08_host_mem','g08_host_schema','g08_host_cpu_direct','g08_host_cpu_graph','g08_host_cuda_direct','g08_host_cuda_graph','g08_host_joint']
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True);(out/'dry-run.log').write_text(dry)
    cuda=[x for x in dry.splitlines() if 'Building CUDA object' in x];r['cuda_edges']=cuda;save()
    assert 'Re-running CMake' not in dry and len(cuda)<=2 and all('compute_provider_cuda' in x and any(y in x for y in ['collectives.cu','sampling_kernel.cu']) for x in cuda),cuda
    run('build',['ninja','-C',str(build),'-f',str(preview),'-j','2','-k','0',*targets])
    failed=[]
    for target in targets:
        paths=[build/path/target for path in [Path('.'),Path('bin'),Path('hyle'),Path('hyle/bin')] if (build/path/target).is_file()];assert len(paths)==1,paths
        binary=paths[0];prefix=['setarch','x86_64','-R'] if mode=='tsan' else []
        # Full public CPU/CUDA journeys retain full vocab and quality; Graph
        # consumers also cover independent port publication in this run.
        if run(target,prefix+[str(binary)],False):failed.append(target)
        r.setdefault('artifacts',[]).append(dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
    r['failures']=failed;r['state']='HOST_FACET_PASS' if not failed else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save();print(mode,r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
