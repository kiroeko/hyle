from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');label=sys.argv[1]
out=base/f'g08-apple-device-risks-{label}';out.mkdir(exist_ok=False)
prior=json.loads((base/'g08-apple-source-a4/result.json').read_text());assert prior['state']=='SOURCE_BATCH_PASS_RISKS_DELIVERY_PERF_PENDING'
build=Path(prior['build']);env=os.environ.copy();env.update(MTL_DEBUG_LAYER='1',MTL_SHADER_VALIDATION='1')
started=time.monotonic();r=dict(state='SETUP',pid=os.getpid(),build=str(build),source_snapshot=prior['source_snapshot'],identity=prior['identity'],
    environment={key:env[key] for key in ['MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']},stages=[],
    scope='Existing a4 Apple product/Graph binaries and unchanged Metal math/joint on actual Metal validation; Vulkan-only later source changes do not alter these binaries. No host sanitizer or SDK/P1 claim.')
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
try:
    assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
    for artifact in prior['artifacts']:
        assert hashlib.sha256((build/'bin'/artifact['target']).read_bytes()).hexdigest()==artifact['sha256']
    targets=['hyle_compute_route_apple_sampling_consumer_test','hyle_graph_route_apple_sampling_consumer_test',
        'hyle_compute_route_apple_sampling_math_test','hyle_graph_route_cpu_apple_sampling_consumer_test','g08_apple_topk_holdout']
    failed=[]
    for target in targets:
        binary=build/'bin'/target;args=[str(binary)]
        if target=='g08_apple_topk_holdout':args+=['--gtest_filter=AppleReduction.*TopK*:AppleReduction.EmptyResultsAndPreparationRejections:AppleGraph.*']
        log=out/(target+'.log');stamp=time.monotonic()
        with log.open('w') as stream:
            p=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=target,child_pid=p.pid);save();print(target,p.pid,flush=True);code=p.wait()
        r['stages'].append(dict(stage=target,command=args,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log),artifact_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));r.pop('child_pid',None);save()
        text=log.read_text(errors='replace')
        if code or any(x in text for x in ['MTLDebugCommandBuffer error','Shader Validation Error','failed assertion']):
            failed.append(target);print(text[-7000:],flush=True)
    r['failures']=failed;r['state']='APPLE_DEVICE_VALIDATION_PASS' if not failed else 'FAIL_WITH_ALL_TARGETS_OBSERVED';save();print(r['state'],flush=True)
except BaseException as error:
    r.update(state='SETUP_FAIL',error=repr(error));save();raise
