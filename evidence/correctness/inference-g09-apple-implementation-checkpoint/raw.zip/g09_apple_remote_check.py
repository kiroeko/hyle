from pathlib import Path
import hashlib,json,os,platform,re,subprocess,sys,time,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified')
out=base/'g09-apple-implementation-check-1'
build=base/'a-cpu-apple/selected-graph/source-build'
parent=base/'a-cpu-apple/selected-graph/source-parent'
canonical=base/'source-c8874688'
assert out.is_dir() and canonical.is_dir()
manifest=json.loads((out/'full-inputs.json').read_text())
retained=json.loads((out/'result.json').read_text())
assert retained['state']=='FAIL'
(out/'result-initial.json').write_text(json.dumps(retained,indent=2)+'\n')
os.environ['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH','')
model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()
assert model=='Mac16,12',model
r={'state':'SETUP','stages':[],'model':model,'input_hashes':manifest['files'],
   'canonical_windows_head':manifest['head'],'canonical_source_tree':manifest['tree'],'retained_initial_manifest_seconds':retained['elapsed_seconds'],'retained_initial_failure':'result-initial.json','source_copy':str(canonical),'max_jobs':4,'priority':'nice10',
   'scope':'Actual MacBook Air CPU+Apple owner/direct-public-consumer incremental source check only; not GPU overlap, SDK delivery, host/device sanitizer, P1 or aggregate acceptance.',
   'identity':{k:subprocess.check_output(v,text=True).strip() for k,v in {'chip':['sysctl','-n','machdep.cpu.brand_string'],'system':['sw_vers'],'toolchain':['xcrun','clang++','--version'],'metal':['xcrun','-sdk','macosx','metal','--version']}.items()}}
started=time.monotonic()-retained['elapsed_seconds']
def save():
    r['elapsed_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
with zipfile.ZipFile(out/'full-source.zip') as archive:
    before=[]
    for item in manifest['files']:
        relative=Path(item['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        path=canonical/relative
        assert path.resolve().is_relative_to(canonical.resolve())
        data=archive.read(relative.as_posix());assert hashlib.sha256(data).hexdigest()==item['sha256']
        before.append({'path':item['path'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None})
        if not path.is_file() or path.read_bytes()!=data:
            path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    (out/'previous-full-source-hashes.json').write_text(json.dumps(before,indent=2)+'\n')
cmake=parent/'CMakeLists.txt';text=cmake.read_text()
assert str(canonical) in text
for target,source in [('hyle_cpu_apple_pipeline','native_joint_pipeline.cc'),('hyle_cpu_apple_contracts','cpu_apple_contracts.cc')]:
    if f'add_executable({target}' in text:continue
    text+=f'\nadd_executable({target} "{canonical/"tests/graph"/source}")\n'
    text+=f'target_compile_features({target} PRIVATE cxx_std_23)\n'
    if target.endswith('pipeline'):text+=f'target_compile_definitions({target} PRIVATE HYLE_G09_APPLE=1)\n'
    text+=f'target_link_libraries({target} PRIVATE hyle::graph)\nhyle_stage_runtime({target})\n'
cmake.write_text(text)
env=dict(os.environ,PATH=os.environ['PATH'],OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
def run(stage,args,timeout=1800):
    stage='retry1-'+stage
    stamp=time.monotonic();log=out/(stage+'.log')
    r.update(state='RUNNING',stage=stage);save();print(stage,flush=True)
    with log.open('wb') as stream:
        process=subprocess.Popen([str(a) for a in args],cwd=canonical,env=env,stdout=stream,stderr=subprocess.STDOUT)
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:process.kill();process.wait();code=124
    r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        r['state']='FAIL';save();print(log.read_text(errors='replace')[-12000:],flush=True);raise SystemExit(code)
run('manifest',['/opt/homebrew/bin/ninja','-C',build,'build.ninja'])
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
targets=['hyle_cpu_apple_pipeline','hyle_cpu_apple_contracts','joint']
dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
(out/'dry-run.log').write_text(dry);r['dry_run_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<100 and 'Re-running CMake' not in dry,dry
run('build',['/opt/homebrew/bin/ninja','-C',build,'-f',preview,'-j','4',*targets])
run('contracts',[build/'hyle_cpu_apple_contracts'],600)
run('g08-joint-regression',[build/'joint'],600)
run('pipeline-correctness',[build/'hyle_cpu_apple_pipeline'],600)
for item in manifest['files']:
    assert hashlib.sha256((canonical/item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['binaries']=[{'target':t,'sha256':hashlib.sha256((build/t).read_bytes()).hexdigest()} for t in targets]
r['state']='PARTIAL_APPLE_IMPLEMENTATION_CHECK_PASS';save();print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
