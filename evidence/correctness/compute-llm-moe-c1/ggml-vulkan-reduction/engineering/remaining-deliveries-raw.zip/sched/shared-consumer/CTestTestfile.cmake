# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/sched/cpp
# Build directory: C:/hyle-scratch/active-vk/g34/delivery-sched/selected-sched/shared-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_sched_cpp_package_probe" "C:/hyle-scratch/active-vk/g34/delivery-sched/selected-sched/shared-consumer/hyle_sched_cpp_package_probe.exe")
set_tests_properties("hyle_sched_cpp_package_probe" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/sched/cpp/CMakeLists.txt;12;add_test;C:/public/project-hyle/hyle/samples/package/sched/cpp/CMakeLists.txt;0;")
