# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/compute/cpp
# Build directory: C:/hyle-scratch/active-vk/g34/delivery-compute/selected-compute/static-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_compute_cpp" "C:/hyle-scratch/active-vk/g34/delivery-compute/selected-compute/static-consumer/hyle_package_compute_cpp.exe")
set_tests_properties("hyle_package_compute_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;15;add_test;C:/public/project-hyle/hyle/samples/package/compute/cpp/CMakeLists.txt;0;")
