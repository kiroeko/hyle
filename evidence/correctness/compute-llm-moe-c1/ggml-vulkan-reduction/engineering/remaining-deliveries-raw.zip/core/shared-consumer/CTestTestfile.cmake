# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/core/cpp
# Build directory: C:/hyle-scratch/active-vk/g34/delivery-core/selected-core/shared-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_core_cpp" "C:/hyle-scratch/active-vk/g34/delivery-core/selected-core/shared-consumer/hyle_package_core_cpp.exe")
set_tests_properties("hyle_package_core_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/core/cpp/CMakeLists.txt;46;add_test;C:/public/project-hyle/hyle/samples/package/core/cpp/CMakeLists.txt;0;")
add_test("hyle_package_core_no_exceptions" "C:/hyle-scratch/active-vk/g34/delivery-core/selected-core/shared-consumer/hyle_package_core_no_exceptions.exe")
set_tests_properties("hyle_package_core_no_exceptions" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/core/cpp/CMakeLists.txt;47;add_test;C:/public/project-hyle/hyle/samples/package/core/cpp/CMakeLists.txt;0;")
