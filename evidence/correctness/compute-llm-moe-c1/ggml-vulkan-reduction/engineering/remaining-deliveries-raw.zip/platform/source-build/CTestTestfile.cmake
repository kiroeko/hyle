# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/active-vk/g34/delivery-platform/selected-platform/source-parent
# Build directory: C:/hyle-scratch/active-vk/g34/delivery-platform/selected-platform/source-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_selected_source_consumer" "C:/hyle-scratch/active-vk/g34/delivery-platform/selected-platform/source-build/hyle_selected_source_consumer.exe")
set_tests_properties("hyle_selected_source_consumer" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-vk/g34/delivery-platform/selected-platform/source-parent/CMakeLists.txt;12;add_test;C:/hyle-scratch/active-vk/g34/delivery-platform/selected-platform/source-parent/CMakeLists.txt;0;")
subdirs("hyle")
