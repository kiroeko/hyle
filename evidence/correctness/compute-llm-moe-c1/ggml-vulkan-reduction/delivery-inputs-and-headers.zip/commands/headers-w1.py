import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = root.parents[2]
candidate = '923895c58a07bcdb29649ddd89e1b6a14f983065'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'])
out = root / 'headers-w1'
out.mkdir()
plan = out / 'plan.json'
subprocess.run([sys.executable, str(repo / 'scripts/validation-select.py'), 'plan', '--base', '3cd981b3',
                '--candidate', candidate, '--context', str(root.parent / 'vulkan-layernorm/remaining-context.json'),
                '--output', str(plan)], check=True, stdout=subprocess.DEVNULL)
selected = json.loads(plan.read_text(encoding='utf-8'))['selected_gates']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
build = Path('C:/hyle-scratch/active-vk/static')
record = {'candidate': candidate, 'scope': 'Only two selected Vulkan public-header gates; not all112 gates',
          'plan_sha256': sha(plan), 'build_cache_sha256': sha(build / 'CMakeCache.txt'),
          'commands': [], 'status': 'RUNNING', 'compiler_PATH_retained': True}
def save():
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
save()
for gate in selected:
    if gate['id'] not in ('headers:compute_route_vulkan', 'headers:graph_route_vulkan'):
        continue
    assert len(gate['commands']) == 1
    argv = [x.replace('{build}', str(build)) for x in gate['commands'][0]]
    argv[0] = 'C:/Program Files/CMake/bin/ctest.exe'
    log = out / (gate['id'].replace(':', '-') + '.log')
    print('RUN', gate['id'], flush=True)
    with log.open('wb') as stream:
        rc = subprocess.run(argv, cwd=repo, stdout=stream, stderr=subprocess.STDOUT).returncode
    record['commands'].append({'id': gate['id'], 'argv': argv, 'exit_code': rc, 'log': log.name, 'sha256': sha(log)})
    if rc:
        record['status'] = 'FAIL'
        save()
        raise SystemExit(rc)
    save()
assert len(record['commands']) == 2
record['status'] = 'PASS'
save()
print('PASS two Vulkan public-header gates', flush=True)
