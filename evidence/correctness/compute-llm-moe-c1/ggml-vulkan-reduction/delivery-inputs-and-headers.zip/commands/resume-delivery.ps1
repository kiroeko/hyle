$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$taskRoot = Join-Path $canonicalRoot '.scratch\validation\vulkan-reduction'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:PYTHONIOENCODING = 'utf-8'
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-vk\static' -ExtraArgs @('--target','help') > (Join-Path $taskRoot 'delivery-resume-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$inputs = Get-Content -LiteralPath (Join-Path $taskRoot 'inputs.json') -Raw -Encoding utf8 | ConvertFrom-Json
& python (Join-Path $taskRoot 'verify-delivery.py') --root C:\hyle-scratch\active-vk\d34 --archive (Join-Path $taskRoot 'hyle-0.1.0-source.zip') --sha256 $inputs.source_archive_sha256 --candidate $inputs.candidate --consumer (Join-Path $taskRoot 'consumer') --fixtures (Join-Path $canonicalRoot '.scratch\validation\vulkan-c1-fragment\fixtures') --resume-source-build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python (Join-Path $taskRoot 'pack-delivery.py') --workspace C:\hyle-scratch\active-vk\d34 --output (Join-Path $taskRoot 'proof\windows-delivery')
exit $LASTEXITCODE
