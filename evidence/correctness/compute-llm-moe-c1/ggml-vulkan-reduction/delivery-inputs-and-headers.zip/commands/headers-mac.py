import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

base = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
platform = sys.argv[1]
assert platform in ('air', 'mini')
inputs = json.loads((base / 'y34-header-inputs.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name, expected in inputs['headers'].items():
    assert sha(base / 'source' / name) == expected, name
out = base / ('y34-' + platform + '-headers')
out.mkdir()
ctest = Path('/opt/homebrew/bin/ctest') if platform == 'air' else next(Path('/Users/kiro/hyle-verify-tools/lib').glob('python*/site-packages/cmake/data/bin/ctest'))
env = os.environ.copy()
env['PATH'] = ('/opt/homebrew/bin:' if platform == 'air' else '/Users/kiro/hyle-verify-tools/bin:') + env['PATH']
record = dict(inputs, scope='Two public Vulkan headers only, same canonical header inputs', platform=platform,
              commands=[], status='RUNNING', cache_sha256=sha(base / 'build-vulkan-static/CMakeCache.txt'))
def save():
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
save()
for factor in ('compute_route_vulkan', 'graph_route_vulkan'):
    command = [str(ctest), '--test-dir', str(base / 'build-vulkan-static'), '-C', 'Release',
               '--output-on-failure', '--no-tests=error', '-L', '^' + factor + '$', '-R', '_header_self_contained_test$']
    log = out / (factor + '.log')
    with log.open('wb') as output:
        code = subprocess.run(command, env=env, stdout=output, stderr=subprocess.STDOUT).returncode
    record['commands'].append({'id': 'headers:' + factor, 'argv': command, 'exit_code': code,
                               'log': log.name, 'sha256': sha(log)})
    if code:
        record['status'] = 'FAIL'
        save()
        raise SystemExit(code)
    save()
record['status'] = 'PASS'
save()
print(platform + ': both public headers PASS')
