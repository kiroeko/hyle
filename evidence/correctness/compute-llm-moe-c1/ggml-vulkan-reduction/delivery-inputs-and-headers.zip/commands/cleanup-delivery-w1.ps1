$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-reduction'
$requestedRoot = 'C:\hyle-scratch\active-vk\d34'
$boundary = (Resolve-Path -LiteralPath $requestedRoot).Path
if ($boundary -ne [IO.Path]::GetFullPath($requestedRoot)) { throw 'Delivery root changed.' }
$outputPath = Join-Path $taskRoot 'proof\windows-delivery-cleanup.json'
if (Test-Path -LiteralPath $outputPath) { throw 'Existing cleanup receipt; inspect before continuing.' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'proof\windows-delivery.json') -Raw -Encoding utf8 | ConvertFrom-Json
$archive = Join-Path (Join-Path $taskRoot 'proof') $proof.archive
if ($proof.status -ne 'PASS' -or (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $proof.archive_sha256) { throw 'Delivery proof invalid.' }
$active = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -in @('cmake.exe','ninja.exe','cl.exe','python.exe') -and $_.CommandLine -match 'active-vk[\\/]d34[\\/]'
})
if ($active.Count -ne 0) { throw 'Delivery producer or consumer remains active.' }
$targets = @()
$links = @()
foreach ($name in @('bs-hidden','bd-hidden','complete-source-hidden')) {
  $expected = Join-Path $boundary $name
  $target = (Resolve-Path -LiteralPath $expected).Path
  if ($target -ne $expected -or -not $target.StartsWith($boundary + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped delivery root.' }
  if ((Get-Item -LiteralPath $target -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Refusing reparse root.' }
  $items = @(Get-ChildItem -LiteralPath $target -Recurse -Force)
  foreach ($link in @($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })) {
    if ($link.PSIsContainer -or $link.LinkType -ne 'SymbolicLink' -or $link.Name -ne 'SYSTEM.md' -or $link.Directory.Name -ne '.pi') { throw 'Unexpected link.' }
    $linkTarget = [IO.Path]::GetFullPath((Join-Path $link.DirectoryName $link.Target))
    if (-not $linkTarget.StartsWith($target + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Link target escaped producer.' }
    $links += $link.FullName
  }
  $files = @($items | Where-Object { -not $_.PSIsContainer -and -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) })
  $targets += [ordered]@{ path=$target; files=$files.Count; logical_bytes=[long](($files | Measure-Object Length -Sum).Sum) }
}
foreach ($path in $links) { Remove-Item -LiteralPath $path -Force }
foreach ($target in $targets) {
  Remove-Item -LiteralPath $target.path -Recurse -Force
  if (Test-Path -LiteralPath $target.path) { throw 'Target remains after cleanup.' }
}
$receipt = [ordered]@{
  candidate=$proof.candidate; status='PASS'; scope='Y34 two delivery producers and extracted package only'
  qualification_archive_sha256=$proof.archive_sha256; targets=$targets
  logical_bytes_removed=[long](($targets | ForEach-Object { [long]$_.logical_bytes } | Measure-Object -Sum).Sum)
  retained=@('relocated SDKs','installed consumers','fixtures','logs','source archive','active module caches','shared dependencies and tools')
}
[IO.File]::WriteAllText($outputPath, ($receipt | ConvertTo-Json -Depth 7).Replace("`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$receipt | ConvertTo-Json -Depth 7
