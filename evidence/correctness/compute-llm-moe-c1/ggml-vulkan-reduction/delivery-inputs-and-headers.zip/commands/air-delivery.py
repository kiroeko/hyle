"""Run only after the Windows heavy stages have finished."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

inputs = Path(__file__).resolve().parent
record = json.loads((inputs / 'inputs.json').read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
archive = inputs / 'hyle-0.1.0-source.zip'
assets = inputs / record['assets']
assert sha(archive) == record['source_archive_sha256']
assert sha(assets) == record['assets_sha256']
assert sha(inputs / 'verify-delivery.py') == record['verifier_sha256']
with zipfile.ZipFile(assets) as z:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
    z.extractall(inputs / 'assets')
for name, digest in record['consumer_files'].items():
    assert sha(inputs / 'assets/consumer' / name) == digest
assert sha(inputs / 'assets/fixtures/receipt.json') == record['fixture_receipt_sha256']
command = [sys.executable, str(inputs / 'verify-delivery.py'),
           '--root', str(inputs.parent / 'delivery-y34'),
           '--archive', str(archive), '--sha256', record['source_archive_sha256'],
           '--candidate', record['candidate'], '--consumer', str(inputs / 'assets/consumer'),
           '--fixtures', str(inputs / 'assets/fixtures')]
subprocess.run(command, check=True)
subprocess.run([sys.executable, str(inputs / 'pack-delivery.py'),
                '--workspace', str(inputs.parent / 'delivery-y34'),
                '--output', str(inputs / 'air-delivery')], check=True)
