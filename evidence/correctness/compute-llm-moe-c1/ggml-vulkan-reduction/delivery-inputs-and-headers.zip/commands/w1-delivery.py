import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
repo = root.parents[2]
candidate = '923895c58a07bcdb29649ddd89e1b6a14f983065'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
contract = json.loads((root / 'consumer-contract.json').read_text(encoding='utf-8'))
assert contract['candidate'] == candidate
for name, expected in contract['consumer'].items():
    assert sha(root / 'consumer' / name) == expected
cmake = 'C:/Program Files/CMake/bin/cmake.exe'
log = root / 'source-package.log'
assert not log.exists()
with log.open('wb') as output:
    subprocess.run([cmake, '--build', 'C:/hyle-scratch/active-vk/static', '--target', 'hyle_source_package',
                    '--parallel', '2'], cwd=repo, stdout=output, stderr=subprocess.STDOUT, check=True)
archive = root / 'hyle-0.1.0-source.zip'
shutil.copy2('C:/hyle-scratch/active-vk/static/dist/hyle-0.1.0-source.zip', archive)
assets = root / 'y34-assets.zip'
fixtures = root.parent / 'vulkan-c1-fragment/fixtures'
with zipfile.ZipFile(assets, 'x', zipfile.ZIP_DEFLATED) as z:
    for directory, prefix in ((root / 'consumer', 'consumer'), (fixtures, 'fixtures')):
        for path in directory.iterdir():
            if path.is_file():
                z.write(path, prefix + '/' + path.name)
    z.write(root / 'consumer-contract.json', 'consumer-contract.json')
with zipfile.ZipFile(assets) as z:
    assert z.testzip() is None
inputs = {'candidate': candidate, 'source_archive_sha256': sha(archive), 'assets_sha256': sha(assets),
          'verifier_sha256': sha(root / 'verify-delivery.py'), 'consumer_files': contract['consumer'],
          'fixture_receipt_sha256': sha(fixtures / 'receipt.json')}
(root / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8', newline='\n')
work = Path('C:/hyle-scratch/active-vk/d34')
subprocess.run([sys.executable, str(root / 'verify-delivery.py'), '--root', str(work),
                '--archive', str(archive), '--sha256', sha(archive), '--candidate', candidate,
                '--consumer', str(root / 'consumer'), '--fixtures', str(fixtures)], check=True)
subprocess.run([sys.executable, str(root / 'pack-delivery.py'), '--workspace', str(work),
                '--output', str(root / 'proof/windows-delivery')], check=True)
