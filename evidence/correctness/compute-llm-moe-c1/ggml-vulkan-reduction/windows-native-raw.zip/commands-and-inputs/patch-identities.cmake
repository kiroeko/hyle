include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
_hyle_dependency_tree_sha256("C:/public/project-hyle/hyle/third_party/ggml_vulkan_runtime" _tree)
_hyle_dependency_normalized_sha256("C:/public/project-hyle/hyle/third_party/ggml_vulkan_runtime/NOTICE.md" _notice)
file(WRITE "C:/public/project-hyle/hyle/.scratch/validation/vulkan-reduction/patch-identities.txt" "${_tree}\n${_notice}\n")
