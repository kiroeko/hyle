import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
proof = root / 'proof'
proof.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
candidate = '05581df80e3b6290d4e7c5fc7a66ecf26821eb09'
records = {}
files = {}
for mode, directory, expected in [('static', 'first-w1', 136), ('shared', 'shared-w1', 135)]:
    result = json.loads((root / directory / 'result.json').read_text(encoding='utf-8'))
    assert result['status'] == 'PASS' and result['candidate'] == candidate
    assert all(c['exit_code'] == 0 for c in result['commands'])
    count = sum(c.get('tests', 0) for c in result['commands'])
    assert count == expected
    for command in result['commands']:
        assert sha(root / directory / command['log']) == command['sha256']
    records[mode] = {'tests': count, 'result': result}
    for path in (root / directory).iterdir():
        if path.is_file():
            files[directory + '/' + path.name] = path
    build = Path('C:/hyle-scratch/active-vk') / mode
    files[mode + '/CMakeCache.txt'] = build / 'CMakeCache.txt'
for name in ('first-environment-powershell51-failure.log', 'first-environment.log', 'shared-environment.log',
             'initial-plan.json', 'y34-candidate.json', 'all-implementation-loc.json',
             'first-w1.ps1', 'first-w1.py', 'shared-w1.ps1', 'shared-w1.py',
             'prepare-platform-inputs.py', 'pack-windows.py', 'patch-identities.cmake', 'patch-identities.txt'):
    files['commands-and-inputs/' + name] = root / name
archive = proof / 'windows-native-raw.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as package:
    for name, path in files.items():
        package.write(path, name)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for name, path in files.items():
        assert hashlib.sha256(package.read(name)).hexdigest() == sha(path)
receipt = {'candidate': candidate, 'status': 'PASS', 'scope': 'Y34 W1 static/shared C++ module qualification only',
           'records': records, 'archive': archive.name, 'archive_sha256': sha(archive),
           'archive_bytes': archive.stat().st_size, 'archive_members': len(files),
           'initial_launcher_failure': 'Windows PowerShell 5.1 lacks Path.IsPathFullyQualified; failed before configure/GPU. Same script then invoked in required PowerShell7.',
           'product_corrections': 0, 'algorithm_corrections': 0,
           'not_claimed': ['all112 selected gates', 'Air/Mini correctness', 'three delivery', 'performance', 'C1 completion']}
(proof / 'windows-native.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': 'PASS', 'static': 136, 'shared': 135, 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': receipt['archive_sha256']}))
