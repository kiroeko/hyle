import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
prior = root.parent / 'vulkan-layernorm'
repo = root.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert candidate == '05581df80e3b6290d4e7c5fc7a66ecf26821eb09'
assert not subprocess.check_output(['git', 'status', '--porcelain'])

shared = (root / 'first-w1.py').read_text(encoding='utf-8')
shared = shared.replace('active-vk/static', 'active-vk/shared').replace("TASK / 'first-w1'", "TASK / 'shared-w1'")
shared = shared.replace('W1 static relevant factors', 'W1 shared relevant factors')
shared = shared.replace('W1 static module qualification', 'W1 shared module qualification')
shared = shared.replace("'-DHYLE_STATIC=ON'", "'-DHYLE_STATIC=OFF'")
shared = shared.replace("('graph_route_vulkan', 26)", "('graph_route_vulkan', 25)")
(root / 'shared-w1.py').write_text(shared, encoding='utf-8', newline='\n')
wrapper = (root / 'first-w1.ps1').read_text(encoding='utf-8').replace('active-vk\\static', 'active-vk\\shared')
wrapper = wrapper.replace('first-w1.py', 'shared-w1.py').replace('first-environment.log', 'shared-environment.log')
(root / 'shared-w1.ps1').write_text(wrapper, encoding='utf-8', newline='\n')

archive = root / 'y34-source.tar.gz'
bundle = root / 'y34.bundle'
assert not archive.exists() and not bundle.exists()
subprocess.run(['git', 'archive', '--format=tar.gz', '--prefix=source/', '--output=' + str(archive), candidate], check=True)
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^4d255a5174825dc669de1684affd7729d3b430d7'], check=True)
old = json.loads((prior / 'y33-candidate.json').read_text(encoding='utf-8'))
names = set(old['verified_implementation_files']) | {'src/compute_route_vulkan/vulkan_reduction.cc'}
files = {}
with tarfile.open(archive, 'r:gz') as package:
    for member in package.getmembers():
        name = member.name.removeprefix('source/')
        if name in names:
            files[name] = hashlib.sha256(package.extractfile(member).read()).hexdigest()
assert set(files) == names
meta = {'candidate': candidate, 'product_candidate': candidate,
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
        'archive': archive.name, 'archive_sha256': sha(archive), 'bundle_sha256': sha(bundle),
        'verified_implementation_files': files,
        'expected_tests': {platform: {'compute_provider_ggml_vulkan': 19, 'compute_route_vulkan': 91,
                                     'graph_route_vulkan': 26} for platform in ('air', 'mini')}}
(root / 'y34-candidate.json').write_text(json.dumps(meta, indent=2) + '\n', encoding='utf-8', newline='\n')

for platform in ('air', 'mini'):
    text = (prior / ('run-y33-' + platform + '.py')).read_text(encoding='utf-8')
    text = text.replace('y33', 'y34').replace('Y33', 'Y34').replace('mature LayerNorm', 'mature reduction and Softmax')
    if platform == 'mini':
        check = "    assert all(test['status'] == 'RUN' and test['result'] == 'COMPLETED' for group in report['testsuites'] for test in group['testsuite'])"
        assert text.count(check) == 1
        text = text.replace(check, """    skipped = []
    for group in report['testsuites']:
        for test in group['testsuite']:
            assert test['status'] == 'RUN'
            if test['result'] == 'SKIPPED':
                name = group['name'] + '.' + test['name']
                assert name == 'GgmlVulkanNative.ExplicitValidationUsesItsOwnInstance'
                skipped.append(name)
            else:
                assert test['result'] == 'COMPLETED'
    result['excluded_cases'].extend(skipped)""")
        marker = "result['verdict'] = 'PASS'\nsave()"
        assert text.count(marker) == 1
        text = text.replace(marker, """for artifact, suite in zip(result['artifacts'], ('compute_provider_ggml_vulkan', 'compute_route_vulkan', 'graph_route_vulkan')):
    report = json.loads((LOGS / (suite + '.json')).read_text())
    artifact['skipped'] = sum(test['result'] == 'SKIPPED' for group in report['testsuites'] for test in group['testsuite'])
    artifact['passed'] = artifact['tests'] - artifact['skipped']
result['verdict'] = 'PASS'
save()""")
    (root / ('run-y34-' + platform + '.py')).write_text(text, encoding='utf-8', newline='\n')
text = (prior / 'pack-y33-platform.py').read_text(encoding='utf-8').replace('y33', 'y34')
text = text.replace("'cases':sum(a['tests'] for a in report['artifacts']),", "'passed':sum(a.get('passed',a['tests']) for a in report['artifacts']), 'skipped':sum(a.get('skipped',0) for a in report['artifacts']),")
(root / 'pack-y34-platform.py').write_text(text, encoding='utf-8', newline='\n')
print(json.dumps({'candidate': candidate, 'implementation_files': len(files),
                  'archive_bytes': archive.stat().st_size, 'bundle_bytes': bundle.stat().st_size}))
