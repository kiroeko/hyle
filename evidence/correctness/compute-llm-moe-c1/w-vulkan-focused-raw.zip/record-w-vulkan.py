from pathlib import Path
import hashlib, json, re, shutil, subprocess, zipfile

root = Path('C:/hyle-scratch/llm-moe-c1-20260917')
repo = Path('C:/public/project-hyle/hyle')
evidence = repo / 'evidence/correctness/compute-llm-moe-c1'
candidate = '4449b77a5e320ecc5502cdc2939f392101482123'
tree = '7c26c3492fe1e21a8fd7b74926a82adbec38f9af'
attempts, raw_files, selectors = [], [], []
for host in ('windows', 'air', 'mini'):
    directory = root / f'w-{host}' / candidate[:8]
    path = directory / 'result.json'
    record = json.loads(path.read_text(encoding='utf-8'))
    assert record['candidate'] == candidate and record['tree'] == tree
    assert record['verdict'] == 'PASS'
    record['validation_host'] = host
    record['local_result'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for command in record['commands']:
        log = directory / Path(command['log']).name
        assert command['exit_code'] == 0
        assert hashlib.sha256(log.read_bytes()).hexdigest() == command['sha256']
        command['local_log'] = str(log)
    text = (directory / 'test.log').read_text(encoding='utf-8')
    counts = [int(n) for n in re.findall(r'^\d+: \[==========\] Running (\d+) tests? from', text, re.M)]
    assert counts == [27, 12]
    assert re.search(r'100% tests passed(?:, 0 tests failed)? out of 4', text)
    record['test_cases'] = {'compute_route_vulkan': 27, 'graph_route_vulkan': 12,
                            'separate_header_checks': 2}
    assert hashlib.sha256((directory / 'LastTest.log').read_bytes()).hexdigest() == record['last_test_sha256']
    if host != 'mini':
        assert not any(marker in text for marker in ('Validation Error', 'VUID-', 'SYNC-HAZARD'))
    attempts.append(record)
    raw_files.extend(p for p in directory.iterdir() if p.is_file())
    if host != 'mini':
        path = directory / 'selector.json'
        plan = json.loads(path.read_text(encoding='utf-8'))
        selectors.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'verdict': plan['verdict'], 'selected': [g['id'] for g in plan['selected_gates']],
            'skipped_count': len(plan['skipped_gates']),
            'skipped_reasons': [{'id': g['id'], 'reason': g['reason']} for g in plan['skipped_gates']],
            'execution_boundary': 'Selected factors and card-declared public headers; full-C1 delivery/performance gates remain pending.'})

loc = json.loads((root / 'w-implementation-loc.json').read_text(encoding='utf-8'))
assert loc['repository']['commit'] == candidate and loc['self_check'] == 'pass'
assert not subprocess.check_output(['git', 'diff', candidate, 'HEAD', '--', *loc['module']['paths']], cwd=repo)
shutil.copy2(root / 'w-implementation-loc.json', evidence / 'w-implementation-loc.json')
ownership_path = root / 'w-concat-word-ownership.json'
ownership = json.loads(ownership_path.read_text(encoding='utf-8'))
assert ownership['verdict'] == 'PASS' and ownership['cases'] == 86976
for name in ('run-w-vulkan-windows.py', 'run-w-vulkan-windows.ps1',
             'run-w-vulkan-air.py', 'run-w-vulkan-mini.py', 'record-w-vulkan.py',
             'w-concat-word-ownership.json'):
    raw_files.append(root / name)
archive = evidence / 'w-vulkan-focused-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(set(raw_files)):
        output.write(path, path.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as result:
    archive_entries = len(result.namelist())
    assert result.testzip() is None
record = {
    'kind': 'C1-W focused Vulkan variadic Concat; not full C1 acceptance',
    'baseline': 'd13a4748e647a6531abbd7b5ae82536d5fd48cf1',
    'product_candidate': candidate, 'validation_candidate': candidate, 'validation_tree': tree,
    'verdict': 'PASS', 'scope': 'W01-W03 focused correctness/lifecycle/P0; whole-C1 gates remain unproven',
    'attempts': attempts,
    'qualification': [
        'W1, Air and Mini each passed 27 Direct + 12 Graph cases and two public-header checks on the first immutable candidate. No product or test correction followed compilation or device execution.',
        'W1/Air installed validation layers reported no Validation Error, VUID or SYNC-HAZARD. Mini is correctness/portability only and has no installed validation layer.',
        'Concat preserves raw F32/F16/BF16/I32/I64/Bool bits. Independent literal row concatenation covers 1/2/3/4/5/9 inputs, positive and negative axes, permuted odd-byte strides, rank-eight broadcast, repeated inputs, skipped empty groups, all-empty outputs and huge empty extents.',
        'Every group of at most three inputs writes only its final-output segments. Output words crossing rows have one writer per group; existing native compute barriers protect preserved earlier-group bits. No intermediate device buffer, memset, full-output scan per group or host payload evaluation is introduced.',
        'Fixed Recorder checks borrowed output guard bytes and rejects input/output alias. Ordinary Graph permutes five true input Views and concatenates them in two native dispatches with one output storage block. Widths 1/129/2048, odd native origins, two slots, changed bindings, retained old outputs and reading after close passed.',
        'Preparation freezes the native specialization and group boundaries. Execution does not search or time providers. Full-C1 actual-weight, three-delivery and fair P1 qualification has not run.'
    ],
    'p0_word_ownership': {'record': ownership, 'sha256': hashlib.sha256(ownership_path.read_bytes()).hexdigest(),
        'boundary': 'Finite host arithmetic enumeration before implementation; not GPU correctness or route acceptance.'},
    'selectors': selectors,
    'raw_archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'entries': archive_entries},
    'not_run': ['Remaining Vulkan C1 Reduce/Softmax/LogSoftmax/TopK/checked indexing/Scatter/Scan mechanisms',
                'Full C1 actual model-weight consumer and 64-row/256-cell acceptance',
                'Full C1 source/installed-static/installed-shared and remaining applicable environment/sanitizer gates',
                'P1 and final default-rule qualification']}
(evidence / 'w-vulkan-focused.json').write_bytes((json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
registry = repo / 'docs/implementation/module-status.json'
data = json.loads(registry.read_text(encoding='utf-8'))
summary = 'LLM/MoE C1-W AUDITED：W01–W03 已实现六 storage 变参 Concat、原生分组片段/字边界所有权及普通 Direct/Graph；W1/Air/Mini 各39例和2个头检查首轮通过。完整 C1 归约/索引等后续机制、真实权重/三交付和 P1 尚未签收。'
for row in data['modules']:
    if row['module'] in ('compute_route_vulkan', 'graph_route_vulkan'):
        assert row['state'] == 'AUDITED'
        row['summary'] = summary
registry.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print('W receipt written;', archive_entries, 'raw files;', archive.stat().st_size, 'archive bytes')
