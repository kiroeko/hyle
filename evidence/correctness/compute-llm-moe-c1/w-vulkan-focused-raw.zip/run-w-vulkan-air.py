from pathlib import Path
import hashlib, json, os, subprocess, sys, time

root = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
source = root / 'source'
build = root / 'build-vulkan-static'
candidate = '4449b77a5e320ecc5502cdc2939f392101482123'
tree = '7c26c3492fe1e21a8fd7b74926a82adbec38f9af'
bundle = root / 'w-vulkan.bundle'
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == 'd417ec9a329315d1167caba2e1d6296f72209b0985ff856aa326713d95bade4d'
logs = root / ('w-' + candidate[:8])
assert not logs.exists(), 'inspect the existing attempt before any restart'
logs.mkdir(parents=True)
if not source.exists():
    subprocess.run(['git', 'clone', '--shared', '--no-checkout', '/Users/kiro/hyle-verify/r5-apple-20260917/candidate-1636365b', str(source)], check=True)
else:
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
subprocess.run(['git', 'fetch', str(bundle), 'HEAD'], cwd=source, check=True)
subprocess.run(['git', 'checkout', '--detach', candidate], cwd=source, check=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=source, text=True).strip() == tree
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
env = os.environ.copy()
env.update(PATH='/opt/homebrew/bin:' + env['PATH'],
           CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1', TRACY_ONLY_LOCALHOST='1', DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib',
           HYLE_VULKAN_VALIDATION='1', VK_LOADER_LAYERS_DISABLE='~implicit~',
           VK_LAYER_PATH='/Users/kiro/hyle-verify/r6-vulkan-20260917/tools/vulkan-validationlayers/1.4.357.0/share/vulkan/explicit_layer.d')
configure = ['cmake', '-S', str(source), '-B', str(build), '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
    '-DHYLE_DEV_FACTORS=compute_route_vulkan;graph_route_vulkan', '-DHYLE_COMPUTE_APPLE=OFF',
    '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF', '-DHYLE_COMPUTE_VULKAN=ON', '-DHYLE_COMPUTE_ONEDNN=OFF',
    '-DHYLE_BUILD_TESTS=ON', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_STATIC=ON', '-DHYLE_INSTALL=OFF',
    '-DHYLE_WERROR=ON', '-DHYLE_SANITIZER=off', '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator']
commands = [('configure', configure),
    ('build', ['cmake', '--build', str(build), '--parallel', '2', '--target', 'hyle_compute_route_vulkan_test', 'hyle_graph_route_vulkan_test']),
    ('test', ['ctest', '--test-dir', str(build), '--output-on-failure', '--no-tests=error', '--timeout', '180', '--verbose', '-L', '^(compute_route_vulkan|graph_route_vulkan)$'])]
result = {'candidate': candidate, 'tree': tree, 'kind': 'C1-W Vulkan Concat focused correctness and headers; not full C1 delivery/P1',
    'source': str(source), 'build': str(build), 'bundle_sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
    'machine': {'model': subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip(),
                'os': subprocess.check_output(['/usr/bin/sw_vers'], text=True),
                'compiler': subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'], text=True)},
    'commands': [], 'verdict': 'RUNNING'}
def save():
    (logs / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
save()
for label, command in commands:
    print('RUN', label, flush=True)
    log = logs / (label + '.log')
    start = time.monotonic()
    with log.open('wb') as output:
        rc = subprocess.run(command, cwd=source, env=env, stdout=output, stderr=subprocess.STDOUT).returncode
    result['commands'].append({'label': label, 'command': command, 'exit_code': rc, 'seconds': time.monotonic() - start,
                              'log': str(log), 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    if rc:
        result['verdict'] = 'FAIL'; save()
        print(label, 'FAIL', flush=True)
        print(log.read_text(errors='replace')[-8000:], flush=True)
        sys.exit(rc)
    save()
raw = (build / 'Testing/Temporary/LastTest.log').read_bytes()
(logs / 'LastTest.log').write_bytes(raw)
result['last_test_sha256'] = hashlib.sha256(raw).hexdigest()
assert not any(marker in raw.decode(errors='replace') for marker in ('Validation Error','VUID-','SYNC-HAZARD'))
result['verdict'] = 'PASS'; save()
print('C1-W Vulkan focused PASS', flush=True)
