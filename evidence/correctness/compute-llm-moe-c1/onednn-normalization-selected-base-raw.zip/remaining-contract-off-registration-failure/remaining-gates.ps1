param([ValidateSet('native','contract','delivery')][string]$Group)
$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logRoot = Join-Path $canonicalRoot '.scratch\validation\onednn-aa'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CMAKE_TOOLCHAIN_FILE = Join-Path $logRoot 'remaining-toolchain.cmake'
# Standard entry imports the selected VS environment; only show available targets.
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-cpu\static' -ExtraArgs @('--target','help') > (Join-Path $logRoot 'remaining-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python (Join-Path $logRoot 'remaining-gates.py') $Group
exit $LASTEXITCODE
