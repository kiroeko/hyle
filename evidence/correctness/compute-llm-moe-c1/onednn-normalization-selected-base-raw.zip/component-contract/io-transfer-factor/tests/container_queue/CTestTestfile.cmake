# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/container_queue
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/tests/container_queue
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_container_queue_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "container_queue" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "container" "--header" "bounded_queue.h" "--header" "byte_ring_buffer.h" "--header" "sharded_queue.h" "--header" "spsc_queue.h" "--header" "unbounded_queue.h" "--header" "work_stealing_deque.h" "--header" "ws_fifo_queue.h")
set_tests_properties("hyle_container_queue_header_self_contained_test" PROPERTIES  LABELS "container_queue;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/container_queue/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/container_queue/CMakeLists.txt;0;")
add_test("hyle_container_queue_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_container_queue_test.exe")
set_tests_properties("hyle_container_queue_test" PROPERTIES  LABELS "container_queue" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/container_queue/CMakeLists.txt;11;hyle_add_test;C:/public/project-hyle/hyle/tests/container_queue/CMakeLists.txt;0;")
