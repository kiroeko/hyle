# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/io_tls
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/tests/io_tls
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_io_tls_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "io_tls" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "io" "--header" "tls.h")
set_tests_properties("hyle_io_tls_header_self_contained_test" PROPERTIES  LABELS "io_tls;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/io_tls/CMakeLists.txt;2;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/io_tls/CMakeLists.txt;0;")
add_test("hyle_io_tls_feature_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_tls_feature_test.exe")
set_tests_properties("hyle_io_tls_feature_test" PROPERTIES  LABELS "io_tls" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_tls/CMakeLists.txt;3;hyle_add_test;C:/public/project-hyle/hyle/tests/io_tls/CMakeLists.txt;0;")
