# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/io_http
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/tests/io_http
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_io_http_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_http_test.exe")
set_tests_properties("hyle_io_http_test" PROPERTIES  LABELS "io_http" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;1;hyle_add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;0;")
add_test("hyle_io_http_cancel_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_http_cancel_test.exe")
set_tests_properties("hyle_io_http_cancel_test" PROPERTIES  LABELS "io_http" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;2;hyle_add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;0;")
add_test("hyle_io_http_file_body_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_http_file_body_test.exe")
set_tests_properties("hyle_io_http_file_body_test" PROPERTIES  LABELS "io_http" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;3;hyle_add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;0;")
add_test("hyle_io_http_upgrade_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_http_upgrade_test.exe")
set_tests_properties("hyle_io_http_upgrade_test" PROPERTIES  LABELS "io_http" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;4;hyle_add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;0;")
add_test("hyle_io_http_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "io_http" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "io" "--header" "http.h")
set_tests_properties("hyle_io_http_header_self_contained_test" PROPERTIES  LABELS "io_http;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;5;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/io_http/CMakeLists.txt;0;")
