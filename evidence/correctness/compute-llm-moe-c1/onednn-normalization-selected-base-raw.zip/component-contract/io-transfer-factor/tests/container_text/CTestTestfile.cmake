# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/container_text
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/tests/container_text
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_container_text_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "container_text" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "container" "--header" "base64.h" "--header" "path.h" "--header" "string_algo.h" "--header" "string_interner.h" "--header" "string_view.h")
set_tests_properties("hyle_container_text_header_self_contained_test" PROPERTIES  LABELS "container_text;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/container_text/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/container_text/CMakeLists.txt;0;")
add_test("hyle_container_text_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_container_text_test.exe")
set_tests_properties("hyle_container_text_test" PROPERTIES  LABELS "container_text" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/container_text/CMakeLists.txt;9;hyle_add_test;C:/public/project-hyle/hyle/tests/container_text/CMakeLists.txt;0;")
