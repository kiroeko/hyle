# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/io_core
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/tests/io_core
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_io_core_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_test.exe")
set_tests_properties("hyle_io_core_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;1;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_endpoint_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_endpoint_test.exe")
set_tests_properties("hyle_io_core_endpoint_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;2;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_buffer_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_buffer_test.exe")
set_tests_properties("hyle_io_core_buffer_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;3;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_io_context_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_io_context_test.exe")
set_tests_properties("hyle_io_core_io_context_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;16;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_net_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_net_test.exe")
set_tests_properties("hyle_io_core_net_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;17;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_tcp_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_tcp_test.exe")
set_tests_properties("hyle_io_core_tcp_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;18;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_udp_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_udp_test.exe")
set_tests_properties("hyle_io_core_udp_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;19;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_file_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_file_test.exe")
set_tests_properties("hyle_io_core_file_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;22;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_file_region_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_file_region_test.exe")
set_tests_properties("hyle_io_core_file_region_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;23;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_local_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_local_test.exe")
set_tests_properties("hyle_io_core_local_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;24;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_dns_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_dns_test.exe")
set_tests_properties("hyle_io_core_dns_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;25;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_signal_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_signal_test.exe")
set_tests_properties("hyle_io_core_signal_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;26;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_timeout_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_timeout_test.exe")
set_tests_properties("hyle_io_core_timeout_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;27;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
add_test("hyle_io_core_net_cancel_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/bin/hyle_io_core_net_cancel_test.exe")
set_tests_properties("hyle_io_core_net_cancel_test" PROPERTIES  LABELS "io_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;29;hyle_add_test;C:/public/project-hyle/hyle/tests/io_core/CMakeLists.txt;0;")
