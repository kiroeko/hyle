# CMake generated Testfile for 
# Source directory: C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor/_deps/googletest-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("googletest")
