# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/io-transfer-factor
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("src/core")
subdirs("src/container_intrusive")
subdirs("src/util_core")
subdirs("src/error")
subdirs("src/time")
subdirs("src/timer_queue")
subdirs("src/platform")
subdirs("src/platform_thread")
subdirs("src/platform_fs")
subdirs("src/mem")
subdirs("src/mem_vm")
subdirs("src/container")
subdirs("src/container_text")
subdirs("src/container_queue")
subdirs("src/sched")
subdirs("src/io_core")
subdirs("src/io_tls")
subdirs("src/io_http")
subdirs("src/io_transfer")
subdirs("tests")
