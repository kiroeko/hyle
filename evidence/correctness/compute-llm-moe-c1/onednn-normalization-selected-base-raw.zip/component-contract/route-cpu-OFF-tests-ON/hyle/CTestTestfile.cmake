# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("src/core")
subdirs("src/container_intrusive")
subdirs("src/util_core")
subdirs("src/error")
subdirs("src/time")
subdirs("src/math")
subdirs("src/platform")
subdirs("src/platform_thread")
subdirs("src/mem")
subdirs("src/container")
subdirs("src/compute_ops")
subdirs("src/compute")
subdirs("src/graph")
subdirs("src/compute_backend_cuda")
subdirs("src/compute_provider_cublas")
subdirs("src/compute_provider_marlin")
subdirs("src/compute_provider_cuda")
subdirs("src/compute_route_cuda")
subdirs("src/graph_route_cuda")
subdirs("src/compute_route_apple")
subdirs("src/graph_route_apple")
subdirs("src/compute_provider_ggml_vulkan")
subdirs("src/compute_route_vulkan")
subdirs("src/graph_route_vulkan")
subdirs("tests")
