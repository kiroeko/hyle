# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/platform
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/platform
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_platform_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "platform" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "platform" "--header" "cpu.h" "--header" "cpu_convenience.h" "--header" "dynlib.h" "--header" "environment.h" "--header" "environment_convenience.h" "--header" "host_memory.h" "--header" "numa.h" "--header" "process.h" "--header" "random.h" "--header" "virtual_memory.h" "--header" "visibility.h")
set_tests_properties("hyle_platform_header_self_contained_test" PROPERTIES  LABELS "platform;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/platform/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/platform/CMakeLists.txt;0;")
add_test("hyle_platform_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/platform/hyle_platform_test.exe")
set_tests_properties("hyle_platform_test" PROPERTIES  LABELS "platform" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/platform/CMakeLists.txt;15;hyle_add_test;C:/public/project-hyle/hyle/tests/platform/CMakeLists.txt;0;")
