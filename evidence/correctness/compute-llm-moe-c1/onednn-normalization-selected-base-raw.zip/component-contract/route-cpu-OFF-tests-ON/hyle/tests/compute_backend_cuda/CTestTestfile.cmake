# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/compute_backend_cuda
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/compute_backend_cuda
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
