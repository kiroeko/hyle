# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/compute_provider_cublas
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/compute_provider_cublas
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_compute_provider_cublas_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "compute_provider_cublas" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "compute/providers" "--header" "cublas.h")
set_tests_properties("hyle_compute_provider_cublas_header_self_contained_test" PROPERTIES  LABELS "compute_provider_cublas;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/compute_provider_cublas/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/compute_provider_cublas/CMakeLists.txt;0;")
