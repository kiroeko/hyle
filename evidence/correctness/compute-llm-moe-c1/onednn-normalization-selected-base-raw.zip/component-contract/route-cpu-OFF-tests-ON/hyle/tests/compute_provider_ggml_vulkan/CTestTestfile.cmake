# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/compute_provider_ggml_vulkan
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/compute_provider_ggml_vulkan
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_ggml_vulkan_source_contract_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/compute_provider_ggml_vulkan/source_contract_test.py")
set_tests_properties("hyle_ggml_vulkan_source_contract_test" PROPERTIES  LABELS "compute_provider_ggml_vulkan" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/compute_provider_ggml_vulkan/CMakeLists.txt;4;add_test;C:/public/project-hyle/hyle/tests/compute_provider_ggml_vulkan/CMakeLists.txt;0;")
