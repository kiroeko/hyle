# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/compute_ops
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/compute_ops
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_compute_ops_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "compute_ops" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "compute" "--header" "ops_visibility.h" "--header" "tensor_desc.h" "--header" "operation.h")
set_tests_properties("hyle_compute_ops_header_self_contained_test" PROPERTIES  LABELS "compute_ops;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/compute_ops/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/compute_ops/CMakeLists.txt;0;")
add_test("hyle_compute_ops_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/compute_ops/hyle_compute_ops_test.exe")
set_tests_properties("hyle_compute_ops_test" PROPERTIES  LABELS "compute_ops" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/compute_ops/CMakeLists.txt;21;hyle_add_test;C:/public/project-hyle/hyle/tests/compute_ops/CMakeLists.txt;0;")
