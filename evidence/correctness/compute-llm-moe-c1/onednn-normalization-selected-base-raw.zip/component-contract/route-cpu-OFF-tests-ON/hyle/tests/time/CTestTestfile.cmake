# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/time
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/time
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_time_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "time" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC")
set_tests_properties("hyle_time_header_self_contained_test" PROPERTIES  LABELS "time;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/time/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/time/CMakeLists.txt;0;")
add_test("hyle_time_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/time/hyle_time_test.exe")
set_tests_properties("hyle_time_test" PROPERTIES  LABELS "time" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/time/CMakeLists.txt;2;hyle_add_test;C:/public/project-hyle/hyle/tests/time/CMakeLists.txt;0;")
add_test("hyle_time_codegen_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/time-codegen-audit.py" "--object" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-OFF-tests-ON/hyle/tests/time/CMakeFiles/hyle_time_codegen_probe.dir/./codegen_probe.cc.obj" "--configuration" "Debug")
set_tests_properties("hyle_time_codegen_test" PROPERTIES  LABELS "time;codegen" SKIP_RETURN_CODE "77" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/time/CMakeLists.txt;19;add_test;C:/public/project-hyle/hyle/tests/time/CMakeLists.txt;0;")
