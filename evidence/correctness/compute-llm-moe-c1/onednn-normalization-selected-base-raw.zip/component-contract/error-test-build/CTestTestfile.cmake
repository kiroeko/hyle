# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/error-test-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("src/core")
subdirs("src/error")
subdirs("tests")
