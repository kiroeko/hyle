# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/correctness
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/error-test-build/tests/correctness
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
