# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-source
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_core_source_consumer" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-build/hyle_core_source_consumer.exe")
set_tests_properties("hyle_core_source_consumer" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-source/CMakeLists.txt;45;add_test;C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-source/CMakeLists.txt;0;")
add_test("hyle_core_source_no_exceptions" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-build/hyle_core_source_no_exceptions.exe")
set_tests_properties("hyle_core_source_no_exceptions" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-source/CMakeLists.txt;46;add_test;C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/core-source/CMakeLists.txt;0;")
subdirs("hyle")
