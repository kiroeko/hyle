# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/parent-gtest-build/hyle/tests
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_bench_stat_parser_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/bench_stat_parser_test.py")
set_tests_properties("hyle_bench_stat_parser_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;125;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_machine_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/perf_machine_test.py")
set_tests_properties("hyle_perf_machine_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;130;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_core_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/hyle_perf_core_test.py")
set_tests_properties("hyle_perf_core_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;135;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_nanobench_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/hyle_perf_nanobench_test.py")
set_tests_properties("hyle_perf_nanobench_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;140;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_runner_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/hyle_perf_runner_test.py")
set_tests_properties("hyle_perf_runner_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;145;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_controls_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/hyle_perf_controls_test.py")
set_tests_properties("hyle_perf_controls_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;150;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_evidence_runner_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/hyle_perf_evidence_runner_test.py")
set_tests_properties("hyle_perf_evidence_runner_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;155;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_raw_replay_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/hyle_perf_raw_replay_test.py")
set_tests_properties("hyle_perf_raw_replay_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;160;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_perf_build_replay_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/hyle_perf_build_replay_test.py")
set_tests_properties("hyle_perf_build_replay_test" PROPERTIES  LABELS "tooling;benchmark" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;165;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_module_closure_contract_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/check_module_closure_test.py")
set_tests_properties("hyle_module_closure_contract_test" PROPERTIES  LABELS "tooling;documentation;closure" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;170;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_module_closure_registry_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/check-module-closure.py")
set_tests_properties("hyle_module_closure_registry_test" PROPERTIES  LABELS "tooling;documentation;closure" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;175;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_shared_export_hygiene_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/shared_export_hygiene_test.py")
set_tests_properties("hyle_shared_export_hygiene_test" PROPERTIES  LABELS "tooling;build;package" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;180;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
add_test("hyle_loc_report_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/tooling/loc_report_test.py")
set_tests_properties("hyle_loc_report_test" PROPERTIES  LABELS "tooling;closure" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;190;add_test;C:/public/project-hyle/hyle/tests/CMakeLists.txt;0;")
subdirs("core")
subdirs("correctness")
