# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/core
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/intrusive-factor-build/tests/core
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_core_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/intrusive-factor-build/bin/hyle_core_test.exe")
set_tests_properties("hyle_core_test" PROPERTIES  LABELS "core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;1;hyle_add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;0;")
add_test("hyle_core_release_assert_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/intrusive-factor-build/bin/hyle_core_release_assert_test.exe")
set_tests_properties("hyle_core_release_assert_test" PROPERTIES  LABELS "core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;2;hyle_add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;0;")
add_test("hyle_core_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "core" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC")
set_tests_properties("hyle_core_header_self_contained_test" PROPERTIES  LABELS "core;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;4;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;0;")
add_test("hyle_core_codegen_audit_parser_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/core/codegen_audit_test.py")
set_tests_properties("hyle_core_codegen_audit_parser_test" PROPERTIES  LABELS "core;codegen;tooling" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;126;add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;0;")
add_test("hyle_core_symbol_visibility_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/core-symbol-visibility-audit.py" "--library" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/intrusive-factor-build/bin/hyle_core_symbol_visibility_probe.dll")
set_tests_properties("hyle_core_symbol_visibility_test" PROPERTIES  LABELS "core;symbols" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;142;add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;0;")
add_test("hyle_core_codegen_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/core-codegen-audit.py" "--object" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/intrusive-factor-build/tests/core/CMakeFiles/hyle_core_codegen_probe.dir/./codegen_probe.cc.obj" "--architecture" "x86_64" "--configuration" "Release")
set_tests_properties("hyle_core_codegen_test" PROPERTIES  LABELS "core;codegen" SKIP_RETURN_CODE "77" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;162;add_test;C:/public/project-hyle/hyle/tests/core/CMakeLists.txt;0;")
