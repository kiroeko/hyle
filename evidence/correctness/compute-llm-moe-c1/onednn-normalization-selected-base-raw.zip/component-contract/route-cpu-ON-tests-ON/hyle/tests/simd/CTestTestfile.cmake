# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/simd
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/simd
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_simd_provider_codegen_audit_parser_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/tests/simd/provider_codegen_audit_test.py")
set_tests_properties("hyle_simd_provider_codegen_audit_parser_test" PROPERTIES  LABELS "simd;codegen" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;13;add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;0;")
add_test("hyle_simd_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/simd/hyle_simd_test.exe")
set_tests_properties("hyle_simd_test" PROPERTIES  LABELS "simd" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;22;hyle_add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;0;")
add_test("hyle_simd_provider_route_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/simd/hyle_simd_provider_route_test.exe")
set_tests_properties("hyle_simd_provider_route_test" PROPERTIES  LABELS "simd" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;26;hyle_add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;0;")
add_test("hyle_simd_provider_codegen_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/simd-provider-codegen-audit.py" "--object" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/simd/CMakeFiles/hyle_simd_provider_codegen_probe.dir/./provider_codegen_probe.cc.obj" "--architecture" "x86_64" "--configuration" "Debug")
set_tests_properties("hyle_simd_provider_codegen_test" PROPERTIES  LABELS "simd;codegen" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;43;add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;0;")
add_test("hyle_simd_provider_winner_avx2_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/simd/hyle_simd_provider_winner_avx2_test.exe")
set_tests_properties("hyle_simd_provider_winner_avx2_test" PROPERTIES  LABELS "simd" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;57;hyle_add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;0;")
add_test("hyle_simd_avx2_ordering_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/simd/hyle_simd_avx2_ordering_test.exe")
set_tests_properties("hyle_simd_avx2_ordering_test" PROPERTIES  LABELS "simd" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;82;hyle_add_test;C:/public/project-hyle/hyle/tests/simd/CMakeLists.txt;0;")
