# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/util_core
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/util_core
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_util_core_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "util_core" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "util" "--header" "borrow.h" "--header" "function_ref.h" "--header" "random.h" "--header" "ref_counted.h" "--header" "scope_guard.h" "--header" "spin_lock.h" "--header" "type_name.h" "--header" "unique_resource.h")
set_tests_properties("hyle_util_core_header_self_contained_test" PROPERTIES  LABELS "util_core;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/util_core/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/util_core/CMakeLists.txt;0;")
add_test("hyle_util_core_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/util_core/hyle_util_core_test.exe")
set_tests_properties("hyle_util_core_test" PROPERTIES  LABELS "util_core" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/util_core/CMakeLists.txt;12;hyle_add_test;C:/public/project-hyle/hyle/tests/util_core/CMakeLists.txt;0;")
