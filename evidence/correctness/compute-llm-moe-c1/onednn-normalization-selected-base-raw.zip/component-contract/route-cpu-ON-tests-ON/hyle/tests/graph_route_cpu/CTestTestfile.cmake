# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/graph_route_cpu
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/graph_route_cpu
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_graph_route_cpu_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "graph_route_cpu" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "graph" "--header" "cpu.h")
set_tests_properties("hyle_graph_route_cpu_header_self_contained_test" PROPERTIES  LABELS "graph_route_cpu;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/graph_route_cpu/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/graph_route_cpu/CMakeLists.txt;0;")
add_test("hyle_graph_route_cpu_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/graph_route_cpu/hyle_graph_route_cpu_test.exe")
set_tests_properties("hyle_graph_route_cpu_test" PROPERTIES  LABELS "graph_route_cpu" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/graph_route_cpu/CMakeLists.txt;3;hyle_add_test;C:/public/project-hyle/hyle/tests/graph_route_cpu/CMakeLists.txt;0;")
add_test("hyle_graph_route_cpu_cpu_executor_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/graph_route_cpu/hyle_graph_route_cpu_cpu_executor_test.exe")
set_tests_properties("hyle_graph_route_cpu_cpu_executor_test" PROPERTIES  LABELS "graph_route_cpu" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/graph_route_cpu/CMakeLists.txt;12;hyle_add_test;C:/public/project-hyle/hyle/tests/graph_route_cpu/CMakeLists.txt;0;")
