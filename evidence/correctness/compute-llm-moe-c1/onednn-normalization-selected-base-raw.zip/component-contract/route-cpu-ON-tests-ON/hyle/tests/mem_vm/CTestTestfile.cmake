# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/mem_vm
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/mem_vm
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_mem_vm_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "mem_vm" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "mem" "--header" "fiber_stack.h" "--header" "large_mapping.h" "--header" "mapping.h")
set_tests_properties("hyle_mem_vm_header_self_contained_test" PROPERTIES  LABELS "mem_vm;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/mem_vm/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/mem_vm/CMakeLists.txt;0;")
add_test("hyle_mem_vm_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/mem_vm/hyle_mem_vm_test.exe")
set_tests_properties("hyle_mem_vm_test" PROPERTIES  LABELS "mem_vm" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/mem_vm/CMakeLists.txt;4;hyle_add_test;C:/public/project-hyle/hyle/tests/mem_vm/CMakeLists.txt;0;")
