# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/timer_queue
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/timer_queue
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_timer_queue_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "timer_queue" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "time" "--header" "common_timeout_queue.h" "--header" "timer_entry.h" "--header" "timer_queue.h")
set_tests_properties("hyle_timer_queue_header_self_contained_test" PROPERTIES  LABELS "timer_queue;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/timer_queue/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/timer_queue/CMakeLists.txt;0;")
add_test("hyle_timer_queue_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/timer_queue/hyle_timer_queue_test.exe")
set_tests_properties("hyle_timer_queue_test" PROPERTIES  LABELS "timer_queue" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/timer_queue/CMakeLists.txt;4;hyle_add_test;C:/public/project-hyle/hyle/tests/timer_queue/CMakeLists.txt;0;")
