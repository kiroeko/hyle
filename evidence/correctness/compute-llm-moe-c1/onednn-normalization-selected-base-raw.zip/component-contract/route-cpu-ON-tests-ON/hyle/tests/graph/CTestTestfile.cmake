# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/graph
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/graph
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_graph_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "graph" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC")
set_tests_properties("hyle_graph_header_self_contained_test" PROPERTIES  LABELS "graph;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/graph/CMakeLists.txt;3;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/graph/CMakeLists.txt;0;")
add_test("hyle_graph_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/graph/hyle_graph_test.exe")
set_tests_properties("hyle_graph_test" PROPERTIES  LABELS "graph" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/graph/CMakeLists.txt;4;hyle_add_test;C:/public/project-hyle/hyle/tests/graph/CMakeLists.txt;0;")
add_test("hyle_graph_executable_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/graph/hyle_graph_executable_test.exe")
set_tests_properties("hyle_graph_executable_test" PROPERTIES  LABELS "graph" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/graph/CMakeLists.txt;6;hyle_add_test;C:/public/project-hyle/hyle/tests/graph/CMakeLists.txt;0;")
