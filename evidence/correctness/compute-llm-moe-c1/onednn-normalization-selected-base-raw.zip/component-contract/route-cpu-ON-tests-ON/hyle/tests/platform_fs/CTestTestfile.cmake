# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/tests/platform_fs
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/platform_fs
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_platform_fs_header_self_contained_test" "C:/Program Files/Python312/python.exe" "C:/public/project-hyle/hyle/scripts/header-self-contained.py" "--module" "platform_fs" "--include-dir" "C:/public/project-hyle/hyle/include" "--cxx" "C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe" "--cxx-compiler-id" "MSVC" "--cxx-frontend" "MSVC" "--header-dir" "platform" "--header" "fs.h" "--header" "fs_convenience.h" "--header" "fs_visibility.h")
set_tests_properties("hyle_platform_fs_header_self_contained_test" PROPERTIES  LABELS "platform_fs;headers" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/tests/CMakeLists.txt;105;add_test;C:/public/project-hyle/hyle/tests/platform_fs/CMakeLists.txt;1;hyle_add_header_self_contained_test;C:/public/project-hyle/hyle/tests/platform_fs/CMakeLists.txt;0;")
add_test("hyle_platform_fs_test" "C:/hyle-scratch/active-cpu/aa/remaining/component/component-contract/route-cpu-ON-tests-ON/hyle/tests/platform_fs/hyle_platform_fs_test.exe")
set_tests_properties("hyle_platform_fs_test" PROPERTIES  LABELS "platform_fs" _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/cmake/HyleModule.cmake;488;add_test;C:/public/project-hyle/hyle/tests/platform_fs/CMakeLists.txt;4;hyle_add_test;C:/public/project-hyle/hyle/tests/platform_fs/CMakeLists.txt;0;")
