#include <hyle/graph/vulkan.h>

#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <expected>
#include <filesystem>
#include <fstream>
#include <span>
#include <utility>
#include <vector>

namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace gv = g::vulkan;
using hyle::Result;
using hyle::Status;
constexpr std::size_t table_width = 2048;
constexpr std::size_t table_rows = 34;
constexpr float epsilon = 1e-5F;

template <class T>
Result<std::vector<T>> read(const std::filesystem::path &path,
                            std::size_t count) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  if (!file || file.tellg() != static_cast<std::streamoff>(count * sizeof(T)))
    return std::unexpected(Status::DataLoss("fixture byte size"));
  std::vector<T> result(count);
  file.seekg(0);
  if (!file.read(reinterpret_cast<char *>(result.data()),
                 static_cast<std::streamsize>(count * sizeof(T))))
    return std::unexpected(Status::DataLoss("fixture read"));
  return result;
}

float decode(std::uint16_t value) {
  return std::bit_cast<float>(static_cast<std::uint32_t>(value) << 16);
}
std::uint16_t encode(double value) {
  auto bits = std::bit_cast<std::uint32_t>(static_cast<float>(value));
  bits += 0x7fffU + ((bits >> 16) & 1U);
  return static_cast<std::uint16_t>(bits >> 16);
}

Result<v::Tensor> upload(const v::Context &context,
                         const c::TensorDesc &description,
                         std::span<const double> values) {
  if (description.data_type() == c::DataType::kFloat32) {
    std::vector<float> packed;
    packed.reserve(values.size());
    for (double value : values)
      packed.push_back(static_cast<float>(value));
    return context.upload(description, std::as_bytes(std::span(packed)));
  }
  std::vector<std::uint16_t> packed;
  for (double value : values)
    packed.push_back(encode(value));
  return context.upload(description, std::as_bytes(std::span(packed)));
}

Result<std::vector<std::byte>> bytes(const v::Context &context,
                                     const v::Tensor &tensor) {
  HYLE_ASSIGN_OR_RETURN(auto size, tensor.description().required_bytes());
  std::vector<std::byte> result(size);
  HYLE_RETURN_IF_ERROR(context.download(tensor, result));
  return result;
}

Status verify(const v::Context &context, const v::Tensor &tensor,
              std::span<const double> input, std::size_t width,
              std::span<const double> scale, std::span<const double> bias) {
  const bool half = tensor.description().data_type() == c::DataType::kBFloat16;
  std::vector<float> floats(half ? 0 : input.size());
  std::vector<std::uint16_t> halves(half ? input.size() : 0);
  if (half)
    HYLE_RETURN_IF_ERROR(
        context.download(tensor, std::as_writable_bytes(std::span(halves))));
  else
    HYLE_RETURN_IF_ERROR(
        context.download(tensor, std::as_writable_bytes(std::span(floats))));
  for (std::size_t row = 0; row < input.size() / width; ++row) {
    double mean = 0, squares = 0;
    for (std::size_t column = 0; column < width; ++column)
      mean += input[row * width + column];
    mean /= static_cast<double>(width);
    for (std::size_t column = 0; column < width; ++column) {
      const auto centered = input[row * width + column] - mean;
      squares += centered * centered;
    }
    const auto inverse =
        1 / std::sqrt(squares / static_cast<double>(width) + epsilon);
    for (std::size_t column = 0; column < width; ++column) {
      const auto index = row * width + column;
      double expected = (input[index] - mean) * inverse;
      if (!scale.empty())
        expected *= scale[column];
      if (!bias.empty())
        expected += bias[column];
      expected = half ? static_cast<double>(decode(encode(expected)))
                      : static_cast<double>(static_cast<float>(expected));
      const double actual = half ? decode(halves[index]) : floats[index];
      const double tolerance =
          (half ? 0.008 : 6e-6) * std::abs(expected) + (half ? 2e-7 : 2e-6);
      if (!std::isfinite(actual) || std::abs(actual - expected) > tolerance) {
        std::fprintf(stderr, "row=%zu col=%zu actual=%.12g expected=%.12g\n",
                     row, column, actual, expected);
        return Status::DataLoss("independent centered FP64 LayerNorm oracle");
      }
    }
  }
  return Status::Ok();
}

Result<v::Program> prepare(const v::Context &context, const c::TensorDesc &desc,
                           const v::Tensor &scale, const v::Tensor &bias,
                           int parameters, bool graph) {
  const c::LayerNorm operation{.epsilon = epsilon};
  if (!graph) {
    if (parameters == 0)
      return v::prepare(context, operation, desc);
    if (parameters == 1)
      return v::prepare(context, operation, desc, scale);
    return v::prepare(context, operation, desc, scale, bias);
  }
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto input, builder.input(desc));
  g::ValueId output;
  std::vector<v::Tensor> constants;
  if (parameters == 0) {
    HYLE_ASSIGN_OR_RETURN(output, builder.add(operation, input));
  } else {
    HYLE_ASSIGN_OR_RETURN(auto weights, builder.constant(scale.description()));
    constants.push_back(scale);
    if (parameters == 1) {
      HYLE_ASSIGN_OR_RETURN(output, builder.add(operation, input, weights));
    } else {
      HYLE_ASSIGN_OR_RETURN(auto offsets, builder.constant(bias.description()));
      constants.push_back(bias);
      HYLE_ASSIGN_OR_RETURN(output,
                            builder.add(operation, input, weights, offsets));
    }
  }
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto plan, std::move(builder).finish());
  gv::CompileReport report;
  HYLE_ASSIGN_OR_RETURN(
      auto program, gv::compile(context, plan, constants, {.report = &report}));
  if (report.managed_region_count != 1)
    return std::unexpected(
        Status::DataLoss("Graph did not bind mature LayerNorm"));
  return program;
}

Status run_case(std::span<const std::uint16_t> table,
                std::span<const float> weights,
                const std::array<std::int64_t, 3> &shape, c::DataType type,
                int parameters, bool graph) {
  hyle::mem::QuotaAllocator quota(hyle::mem::system_allocator(),
                                  128 * 1024 * 1024);
  {
    HYLE_ASSIGN_OR_RETURN(
        auto context,
        v::Context::create({.validation = true, .memory_quota = &quota}));
    HYLE_ASSIGN_OR_RETURN(auto desc, c::TensorDesc::dense(type, shape));
    const auto width = static_cast<std::size_t>(shape.back());
    HYLE_ASSIGN_OR_RETURN(auto count, desc.element_count());
    HYLE_ASSIGN_OR_RETURN(
        auto parameter_desc,
        c::TensorDesc::dense(c::DataType::kFloat32, std::array{shape.back()}));
    std::vector<double> scale(width), bias(width);
    for (std::size_t column = 0; column < width; ++column) {
      scale[column] = weights[column];
      bias[column] = static_cast<float>(decode(table[column]) * 0.125F);
    }
    HYLE_ASSIGN_OR_RETURN(auto scale_tensor,
                          upload(context, parameter_desc, scale));
    HYLE_ASSIGN_OR_RETURN(auto bias_tensor,
                          upload(context, parameter_desc, bias));
    HYLE_ASSIGN_OR_RETURN(
        auto program,
        prepare(context, desc, scale_tensor, bias_tensor, parameters, graph));
    HYLE_ASSIGN_OR_RETURN(auto first, program.create_invocation());
    HYLE_ASSIGN_OR_RETURN(auto working, program.create_invocation());
    v::Tensor retained;
    std::vector<std::byte> snapshot;
    for (std::size_t phase = 0; phase < 3; ++phase) {
      std::vector<double> input(count);
      for (std::size_t row = 0; row < count / width; ++row)
        for (std::size_t column = 0; column < width; ++column)
          input[row * width + column] = decode(
              table[((row + phase * 7) % table_rows) * table_width + column]);
      HYLE_ASSIGN_OR_RETURN(auto tensor, upload(context, desc, input));
      auto &slot = phase == 0 ? first : working;
      HYLE_RETURN_IF_ERROR(slot.bind(tensor));
      HYLE_ASSIGN_OR_RETURN(auto pending, slot.submit());
      HYLE_ASSIGN_OR_RETURN(auto result, pending.wait());
      const auto output = result.get()->tensors()[0];
      HYLE_RETURN_IF_ERROR(verify(context, output, input, width,
                                  parameters > 0
                                      ? std::span<const double>(scale)
                                      : std::span<const double>{},
                                  parameters > 1 ? std::span<const double>(bias)
                                                 : std::span<const double>{}));
      if (phase == 0) {
        retained = output;
        HYLE_ASSIGN_OR_RETURN(snapshot, bytes(context, retained));
      } else {
        HYLE_ASSIGN_OR_RETURN(auto current, bytes(context, retained));
        if (current != snapshot)
          return Status::DataLoss("retained result was overwritten");
      }
    }
    first = {};
    working = {};
    program = {};
    HYLE_RETURN_IF_ERROR(context.close());
    HYLE_ASSIGN_OR_RETURN(auto after_close, bytes(context, retained));
    if (after_close != snapshot)
      return Status::DataLoss("retained result changed after close");
  }
  if (quota.used() != 0)
    return Status::DataLoss("LayerNorm owners leaked quota");
  return Status::Ok();
}

Status run(const std::filesystem::path &fixtures) {
  HYLE_ASSIGN_OR_RETURN(
      auto table,
      read<std::uint16_t>(fixtures / "table.bf16", table_rows * table_width));
  HYLE_ASSIGN_OR_RETURN(auto weights,
                        read<float>(fixtures / "gemma_scale.f32", table_width));
  const std::array<std::array<std::int64_t, 3>, 5> shapes{
      {{1, 1, 1}, {1, 17, 129}, {2, 23, 257}, {1, 128, 2048}, {2, 129, 2048}}};
  std::size_t cases = 0;
  for (auto type : {c::DataType::kFloat32, c::DataType::kBFloat16})
    for (const auto &shape : shapes)
      for (int parameters = 0; parameters <= 2; ++parameters)
        for (bool graph : {false, true}) {
          HYLE_RETURN_IF_ERROR(
              run_case(table, weights, shape, type, parameters, graph));
          ++cases;
        }
  std::printf(
      "PASS LayerNorm cases=%zu runs=%zu retained_close=%zu quota_zero=%zu\n",
      cases, cases * 3, cases, cases);
  return Status::Ok();
}

int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  const auto status = run(argv[1]);
  if (!status.ok()) {
    const auto message = status.message();
    std::fprintf(stderr, "%.*s\n", static_cast<int>(message.size()),
                 message.data());
    return 1;
  }
  return 0;
}
