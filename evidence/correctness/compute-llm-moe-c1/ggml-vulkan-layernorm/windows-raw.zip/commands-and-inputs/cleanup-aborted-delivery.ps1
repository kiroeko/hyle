$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-layernorm'
$expectedRoot = 'C:\hyle-scratch\active-vk\g33'
$resolved = (Resolve-Path -LiteralPath $expectedRoot).Path
if (-not [string]::Equals($resolved, $expectedRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Unexpected resolved cleanup target'
}
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'aborted-default-archive.json') -Raw | ConvertFrom-Json
$archive = Join-Path $taskRoot $proof.archive
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $proof.sha256) {
    throw 'Archived failure evidence changed'
}
$active = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -in @('cmake.exe','ninja.exe','cl.exe','python.exe') -and
    $_.CommandLine -match 'active-vk[\\/]g33[\\/]'
})
if ($active.Count -ne 0) { throw 'Aborted build still has an active process' }
$entries = @(Get-ChildItem -LiteralPath $resolved -Force -Recurse)
if ((Get-Item -LiteralPath $resolved).Attributes -band [IO.FileAttributes]::ReparsePoint) {
    throw 'Cleanup root is a reparse point'
}
if (@($entries | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -ne 0) {
    throw 'Unexpected reparse point in task-owned build'
}
$files = @($entries | Where-Object { -not $_.PSIsContainer })
$bytes = ($files | Measure-Object Length -Sum).Sum
Remove-Item -LiteralPath $resolved -Recurse -Force
if (Test-Path -LiteralPath $resolved) { throw 'Cleanup did not finish' }
$receipt = [ordered]@{
    candidate = '4d255a5174825dc669de1684affd7729d3b430d7'
    status = 'PASS'
    scope = 'Removed only this task aborted CPU/oneDNN default delivery build'
    absolute_target = $resolved
    files_removed = $files.Count
    logical_bytes_removed = $bytes
    archived_evidence_sha256 = $proof.sha256
}
$json = ($receipt | ConvertTo-Json -Depth 6) -replace "`r`n", "`n"
[IO.File]::WriteAllText((Join-Path $taskRoot 'aborted-delivery-cleanup.json'), $json + "`n", [Text.UTF8Encoding]::new($false))
Write-Output $json
