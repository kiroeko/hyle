import hashlib,json,re,zipfile
from pathlib import Path
TASK=Path(__file__).resolve().parent
ROOT=TASK.parents[2]
WORK=Path('C:/hyle-scratch/active-vk/g33v')
CANDIDATE='4d255a5174825dc669de1684affd7729d3b430d7'
OUT=TASK/'proof';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda name:json.loads((TASK/name).read_text(encoding='utf-8'))
native=read('remaining-native/result.json');shared=read('shared-native/result.json')
delivery=read('route-resumed-delivery/result.json');actual=read('w1-actual-delivery-fixed/result.json')
for record in (native,shared,delivery,actual):
 assert record['candidate']==CANDIDATE and record['status']=='PASS'
assert len(native['gates'])==7 and all(g['status']=='PASS' for g in native['gates'])
assert len(shared['gates'])==5 and all(g['status']=='PASS' for g in shared['gates'])
assert len(delivery['commands'])==2 and all(c['exit_code']==0 for c in delivery['commands'])
assert len(actual['deliveries'])==3
cases={}
for linkage,folder in [('static','remaining-native'),('shared','shared-native')]:
 cases[linkage]={}
 for factor in ('compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan'):
  path=TASK/folder/('factor-'+factor+'-1-CTest.log')
  text=path.read_text(errors='replace')
  assert not any(x in text for x in ('VUID-','Validation Error','SYNC-HAZARD'))
  counts=re.findall(r'\[  PASSED  \] (\d+) tests?\.',text)
  assert len(counts)==1
  cases[linkage][factor]=int(counts[0])
files={}
folders=('first-w1','second-w1','third-w1','qualified-w1','remaining-native','shared-native',
         'remaining-delivery','route-delivery','route-fixed-delivery','route-resumed-delivery',
         'w1-actual-delivery','w1-actual-delivery-fixed','consumer')
for folder in folders:
 for p in (TASK/folder).rglob('*'):
  if p.is_file():files[p.relative_to(TASK).as_posix()]=p
for p in TASK.iterdir():
 if p.is_file() and (p.suffix in ('.py','.ps1','.cmd','.cmake','.json','.log') or
                    p.name in ('consumer-first-build-failure.zip','aborted-default-delivery.zip',
                               'route-environment-failure.zip','route-prefix-failure.zip')):
  files['commands-and-inputs/'+p.name]=p
for p in WORK.rglob('CMakeCache.txt'):
 files['caches/'+p.relative_to(WORK).as_posix()]=p
manifests={}
for component in ('compute','graph'):
 for linkage in ('static','shared'):
  prefix=WORK/('delivery-'+component)/('selected-'+component)/(linkage+'-sdk-relocated')
  assert prefix.is_dir()
  manifests[component+'-'+linkage]=[{'path':p.relative_to(prefix).as_posix(),
    'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(prefix.rglob('*')) if p.is_file()]
for entry in actual['deliveries']:
 build=(WORK/'delivery-graph/selected-graph/source-build' if entry['linkage']=='source'
        else WORK/('layernorm-'+entry['linkage']))
 assert sha(build/'hyle_c1_layernorm.exe')==entry['executable_sha256']
 assert sha(build/'CMakeCache.txt')==entry['cache_sha256']
archive=OUT/'windows-raw.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('sdk-manifests.json',json.dumps(manifests,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,p in files.items():assert z.read(name)==p.read_bytes(),name
summary={'candidate':CANDIDATE,'scope':'C1-Y33 Windows LayerNorm integration qualification; no full C1 or P1',
 'status':'PASS','selected_gates':{'passed':9,'skipped':111,'native':native['gates'],
   'deliveries':'Vulkan-only Compute and Graph source/static/shared; source and shared SDK checkpoints resumed without rebuilding',
   'default_CPU_delivery_attempt':'ABORTED_SCOPE; no PASS; existing CPU evidence not relabeled'},
 'module_cpp_tests':cases,'extra_source_contract_and_headers':'PASS; exact CTest logs in archive',
 'actual_layernorm_deliveries':actual['deliveries'],
 'consumer_scope':read('consumer-contract.json'),
 'prior_failures':['MSVC shadow warning in LayerNorm branch','test missing algorithm include and explicit Operation',
   'missing task validation-layer startup environment','unrelated default CPU/oneDNN build aborted',
   'task Vulkan SDK lookup missing','task CMAKE_PREFIX_PATH hid installed Hyle','consumer narrowing warning corrected explicitly'],
 'product_corrections':2,'algorithm_corrections':0,'consumer_compile_corrections':1,
 'remaining':['Air and Mini relevant regression','Air actual LayerNorm three-delivery','C1 mature Reduce/Softmax and other bindings','C1 full-cost performance and fixed selection; CPU Q2 BLOCKED'],
 'archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
 'archive_members':len(files)+1,'cleanup':read('aborted-delivery-cleanup.json')}
(OUT/'windows-validation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'candidate':CANDIDATE,'module_cpp_tests':cases,'selected_gates':9,
 'actual_layernorm_cases':sum(d['tests'] for d in actual['deliveries']),
 'actual_layernorm_runs':sum(d['runs'] for d in actual['deliveries']),
 'archive_bytes':archive.stat().st_size,'members':len(files)+1}))
