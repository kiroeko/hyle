param([ValidateSet('native','contract','delivery','registration')][string]$Group)
$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logRoot = Join-Path $canonicalRoot '.scratch\validation\vulkan-layernorm'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:HYLE_VULKAN_VALIDATION = '1'
$env:HYLE_TEST_VULKAN_VALIDATE = '1'
$env:VK_INSTANCE_LAYERS = 'VK_LAYER_KHRONOS_validation'
$env:VK_LOADER_LAYERS_DISABLE = '~implicit~'
$env:VK_LAYER_PATH = 'C:\public\tools\hyle-vulkan\1.4.357.0\Bin'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:CMAKE_TOOLCHAIN_FILE = Join-Path $logRoot 'remaining-toolchain.cmake'
# Standard entry imports the selected VS environment; only show available targets.
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-vk\static' -ExtraArgs @('--target','help') > (Join-Path $logRoot 'remaining-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python (Join-Path $logRoot 'remaining-gates.py') $Group
exit $LASTEXITCODE
