import ctypes,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('C:/public/project-hyle/hyle')
TASK=Path(__file__).resolve().parent
CANDIDATE='4d255a5174825dc669de1684affd7729d3b430d7'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==CANDIDATE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
ctypes.windll.kernel32.SetErrorMode(0x8003)
OUT=TASK/'route-resumed-delivery';OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'candidate':CANDIDATE,'scope':'Selected Compute/Graph source/shared/static with Vulkan only',
 'compute_checkpoint':'route-fixed-delivery/result.json plus route-prefix-correction.json',
 'toolchain_sha256':sha(TASK/'route-toolchain.cmake'),'commands':[],'status':'RUNNING'}
def save():(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for component,script in [('compute',str(TASK/'resume-compute.cmake')),('graph','cmake/HyleCiSelectedComponentSmoke.cmake')]:
 command=['C:/Program Files/CMake/bin/cmake.exe','-DHYLE_SMOKE_COMPUTE_CPU=OFF','-DHYLE_SMOKE_COMPUTE_ONEDNN=OFF',
  '-DHYLE_SMOKE_GENERATOR=Ninja','-DCMAKE_CTEST_COMMAND='+str(TASK/'route-ctest.cmd'),
  '-DHYLE_SOURCE_DIR='+str(ROOT),'-DHYLE_SMOKE_ROOT=C:/hyle-scratch/active-vk/g33v/delivery-'+component,
  '-DHYLE_SMOKE_COMPONENT='+component,'-P',script]
 print('START '+component,flush=True);log=OUT/(component+'.log')
 start=time.monotonic()
 with log.open('wb') as f:
  f.write((json.dumps(command)+'\n').encode());f.flush()
  process=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,creationflags=0x08000000)
 record['commands'].append({'component':component,'argv':command,'exit_code':process.returncode,
  'seconds':time.monotonic()-start,'log':log.name,'sha256':sha(log)})
 if process.returncode:
  record['status']='FAIL';save();print('FAIL '+component,flush=True);raise SystemExit(1)
 text=log.read_text(errors='replace')
 assert 'HYLE selected product smoke passed: '+component in text
 assert not any(x in text for x in ('VUID-','Validation Error','SYNC-HAZARD'))
 save();print('PASS '+component,flush=True)
record['status']='PASS';save()
