import ctypes,hashlib,json,os,shutil,subprocess
from pathlib import Path
ROOT=Path('C:/public/project-hyle/hyle')
TASK=Path(__file__).resolve().parent
BUILD=Path('C:/hyle-scratch/active-vk/static')
PRIOR=json.loads((TASK/'third-w1/result.json').read_text())
CANDIDATE=PRIOR['candidate']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==CANDIDATE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
ctypes.windll.kernel32.SetErrorMode(0x8003)
OUT=TASK/'qualified-w1'
OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env.pop('PATH',None)
env.update(HYLE_VULKAN_VALIDATION='1',HYLE_TEST_VULKAN_VALIDATE='1',
 VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin',
 VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LOADER_LAYERS_DISABLE='~implicit~')
shutil.copy2(Path('C:/Windows/System32/vulkan-1.dll'),BUILD/'bin/vulkan-1.dll')
record={'candidate':CANDIDATE,'scope':'Y33 W1 focused runtime qualification; reuse exact successful third build; no P1',
 'environment':{k:env[k] for k in ('HYLE_VULKAN_VALIDATION','HYLE_TEST_VULKAN_VALIDATE','VK_LAYER_PATH','VK_INSTANCE_LAYERS','VK_LOADER_LAYERS_DISABLE')},
 'PATH_unset':True,'dlls':{p.name:sha(p) for p in (BUILD/'bin').glob('*.dll')},'commands':[],'status':'RUNNING'}
def save():
 (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for component,tests,expected in [
 ('compute_route_vulkan','VulkanNative.NativeOwnersTransfersAndQuota:VulkanGateNorm.*',7),
 ('graph_route_vulkan','VulkanGraph.GateNormResidualUsesSharedMixedParametersAndIndependentSlots:VulkanGraph.ManagedLayerNormKeepsMisalignedCapturedRowsAndPublishedForks',2)]:
 exe=BUILD/'bin'/('hyle_'+component+'_test.exe')
 report=OUT/(component+'.json');log=OUT/(component+'.log')
 command=[str(exe),'--gtest_filter='+tests,'--gtest_output=json:'+str(report)]
 print('START '+component,flush=True)
 with log.open('wb') as f:
  f.write((json.dumps(command)+'\n').encode());f.flush()
  result=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=0x08000000,timeout=360)
 row={'argv':command,'exit_code':result.returncode,'log':log.name,'sha256':sha(log),'executable_sha256':sha(exe)}
 record['commands'].append(row)
 text=log.read_text(errors='replace')
 ok=result.returncode==0 and not any(x in text for x in ('VUID-','Validation Error','SYNC-HAZARD'))
 if report.exists():
  data=json.loads(report.read_text());row.update(tests=data['tests'],failures=data['failures'],gtest_sha256=sha(report))
  ok=ok and data['tests']==expected and data['failures']==0 and data.get('disabled',0)==0
  ok=ok and all(t['status']=='RUN' and t['result']=='COMPLETED' for g in data['testsuites'] for t in g['testsuite'])
 else:ok=False
 if not ok:
  record['status']='FAIL';save();print(text[-10000:],flush=True);raise SystemExit(1)
 save();print('PASS '+component,flush=True)
record['status']='PASS';save()
