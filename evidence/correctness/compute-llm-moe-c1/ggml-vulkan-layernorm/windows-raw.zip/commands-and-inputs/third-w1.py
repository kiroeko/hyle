import ctypes,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('C:/public/project-hyle/hyle')
TASK=Path(__file__).resolve().parent
BUILD=Path('C:/hyle-scratch/active-vk/static')
CANDIDATE='4d255a5174825dc669de1684affd7729d3b430d7'
CMAKE='C:/Program Files/CMake/bin/cmake.exe'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==CANDIDATE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
ctypes.WinDLL('kernel32',use_last_error=True).SetErrorMode(0x8003)
OUT=TASK/'third-w1'
OUT.mkdir(exist_ok=False)
record={'candidate':CANDIDATE,'scope':'W1 fixed-candidate LayerNorm focused correctness only; no P1 or selected-gate aggregate','status':'RUNNING','commands':[]}
def save():
 (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,command,runtime=False):
 env=os.environ.copy()
 if runtime:
  env.pop('PATH',None)
  env['HYLE_VULKAN_VALIDATION']='1'
 print('START '+name,flush=True)
 path=OUT/(name+'.log')
 with path.open('wb') as log:
  log.write((json.dumps(command)+'\n').encode())
  log.flush()
  result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=0x08000000)
 record['commands'].append({'name':name,'argv':command,'exit_code':result.returncode,'PATH_unset':runtime,'validation':runtime,'log':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 if result.returncode:
  record['status']='FAIL';save()
  print('FAIL '+name,flush=True)
  raise SystemExit(result.returncode)
 save();print('PASS '+name,flush=True)
save()
run('configure',[CMAKE,'-S',str(ROOT),'-B',str(BUILD),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DHYLE_DEV_FACTORS=compute_provider_ggml_vulkan,compute_route_vulkan,graph_route_vulkan','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_WERROR=ON','-DHYLE_COMPUTE_VULKAN=ON','-DHYLE_STATIC=ON','-DCMAKE_TOOLCHAIN_FILE='+str(ROOT/'.scratch/validation/vulkan-c1-final/remaining-toolchain.cmake')])
run('build',[CMAKE,'--build',str(BUILD),'--config','Release','--target','hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests','--parallel','2'])
versions=sorted(p for p in Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC').iterdir() if (p/'x64/Microsoft.VC145.CRT').is_dir())
for source in (versions[-1]/'x64/Microsoft.VC145.CRT').glob('*.dll'):
 shutil.copy2(source,BUILD/'bin'/source.name)
for component,tests in [('compute_route_vulkan','VulkanGateNorm.*'),('graph_route_vulkan','VulkanGraph.GateNormResidualUsesSharedMixedParametersAndIndependentSlots:VulkanGraph.ManagedLayerNormKeepsMisalignedCapturedRowsAndPublishedForks')]:
 exe=BUILD/'bin'/('hyle_'+component+'_test.exe')
 run(component,[str(exe),'--gtest_filter='+tests,'--gtest_output=json:'+str(OUT/(component+'.json'))],True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==CANDIDATE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
record['status']='PASS';save()
print('Focused LayerNorm qualification PASS; remaining gates still pending.',flush=True)
