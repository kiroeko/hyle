$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logRoot = Join-Path $canonicalRoot '.scratch\validation\vulkan-layernorm'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:PYTHONIOENCODING = 'utf-8'
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-vk\static' -ExtraArgs @('--target','help') > (Join-Path $logRoot 'third-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python (Join-Path $logRoot 'third-w1.py')
exit $LASTEXITCODE
