"""Execute the selected C1-Y33 selected gates serially in fixed task-owned directories.

This records manual gate execution; it does not create selector cache receipts.
Runs all selected default delivery gates; Vulkan-on has additional actual receipts.
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('C:/public/project-hyle/hyle')
LOGS = ROOT / '.scratch/validation/vulkan-layernorm'
BUILD = Path('C:/hyle-scratch/active-vk/static')
SCRATCH = Path('C:/hyle-scratch/active-vk/g33')
CANDIDATE = '4d255a5174825dc669de1684affd7729d3b430d7'
CMAKE = 'C:/Program Files/CMake/bin/cmake.exe'
CTEST = 'C:/Program Files/CMake/bin/ctest.exe'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def assert_candidate():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    dirty = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    if head != CANDIDATE or dirty:
        raise RuntimeError('Frozen candidate changed; stop this validation run')


def stage_crt(test_dir):
    redist = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
    versions = sorted(p for p in redist.iterdir() if (p / 'x64/Microsoft.VC145.CRT').is_dir())
    libraries = sorted((versions[-1] / 'x64/Microsoft.VC145.CRT').glob('*.dll'))
    if not libraries:
        raise RuntimeError('Missing compiler x64 CRT')
    # HYLE's existing runtime staging has already copied HYLE/vendor DLLs.
    directories = {p.parent for p in Path(test_dir).rglob('*.exe')
                   if 'CMakeFiles' not in p.parts and '_deps' not in p.parts}
    for directory in directories:
        for library in libraries:
            shutil.copy2(library, directory / library.name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('group', choices=('native', 'contract', 'delivery', 'registration'))
    args = parser.parse_args()
    assert_candidate()
    ctypes.WinDLL('kernel32', use_last_error=True).SetErrorMode(0x8003)
    SCRATCH.mkdir(parents=True, exist_ok=True)
    output = LOGS / ('remaining-' + args.group)
    output.mkdir(exist_ok=False)
    # Generate under the actual imported VS environment; preserve selected/skipped reasons.
    plan_path = output / 'plan.json'
    command = [sys.executable, str(ROOT / 'scripts/validation-select.py'), 'plan',
               '--base', '5f61546cd0f09ff735b2c01f3f28e33fa3044a2c', '--candidate', CANDIDATE,
               '--context', str(LOGS / 'remaining-context.json'), '--output', str(plan_path)]
    subprocess.run(command, cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    replacements = {'{python}': sys.executable, '{root}': str(ROOT),
                    '{build}': str(BUILD), '{scratch}': str(SCRATCH)}
    selected = []
    for gate in plan['selected_gates']:
        if args.group in ('native', 'registration') and gate['kind'] in ('maintenance', 'build', 'correctness', 'headers'):
            selected.append(gate)
        elif args.group == 'contract' and gate['id'] == 'component-contract':
            selected.append(gate)
        elif args.group == 'delivery' and gate['kind'] == 'delivery' and gate['id'] != 'component-contract':
            selected.append(gate)
    if args.group == 'native':
        # Validate the corrected composition fixture immediately after configure,
        # before unrelated native gates. The selected command set is unchanged.
        selected.sort(key=lambda gate: (0 if gate['id'] in ('docs', 'closure', 'configure')
                                        else 1 if gate['id'] == 'factor:compute_provider_ggml_vulkan'
                                        else 2))
    record = {'candidate': CANDIDATE, 'plan_sha256': sha(plan_path), 'group': args.group,
              'execution': 'manual exact selected commands; parallel2; fixed build and scratch; no selector cache receipts',
              'gates': [], 'status': 'RUNNING'}
    receipt = output / 'result.json'

    def save():
        receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')

    save()
    for gate in selected:
        assert_candidate()
        print('START ' + gate['id'], flush=True)
        result = {'id': gate['id'], 'commands': [], 'status': 'RUNNING'}
        record['gates'].append(result)
        save()
        for index, template in enumerate(gate['commands']):
            command = []
            for token in template:
                for key, value in replacements.items():
                    token = token.replace(key, value)
                command.append(token)
            if command[0] == 'cmake':
                command[0] = CMAKE
            if gate['id'] == 'configure':
                command.extend(['-DHYLE_COMPUTE_CPU=ON', '-DHYLE_STATIC=ON',
                                '-DCMAKE_TOOLCHAIN_FILE=' + str(LOGS / 'remaining-toolchain.cmake'),
                                '-DFETCHCONTENT_SOURCE_DIR_ONEDNN=C:/public/project-hyle/hyle/.scratch/onednn-lock-v3.13.2/extract/oneDNN-71094df451909e95ceeefc8f64c275cdcbbcdff5',
                                '-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=C:/public/project-hyle/ggml',
                                '-DVulkan_GLSLC_EXECUTABLE=C:/public/tools/hyle-vulkan/1.4.357.0/Bin/glslc.exe',
                                '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
            if command[0] == 'ctest':
                test_dir = command[command.index('--test-dir') + 1]
                stage_crt(test_dir)
                # Header self-containment tests invoke compilers, so retain their compiler PATH.
                command[0] = CTEST
            if gate['kind'] == 'delivery':
                # Original CMake scripts recursively remove these precise task-owned children.
                prefix = '-DHYLE_SMOKE_ROOT='
                smoke = Path(next(x[len(prefix):] for x in command if x.startswith(prefix))).resolve()
                smoke.relative_to(SCRATCH.resolve())
                child = ('component-contract' if gate['id'] == 'component-contract'
                         else 'selected-' + gate['id'].split(':', 1)[1])
                (smoke / child).resolve().relative_to(SCRATCH.resolve())
                command[1:1] = ['-DHYLE_SMOKE_GENERATOR=Ninja',
                                '-DCMAKE_CTEST_COMMAND=' + str(LOGS / 'delivery-ctest.cmd')]
            log = output / (gate['id'].replace(':', '-') + '-' + str(index) + '.log')
            started = datetime.datetime.now(datetime.timezone.utc).isoformat()
            with log.open('wb') as stream:
                stream.write((json.dumps(command) + '\n').encode('utf-8'))
                stream.flush()
                run_env = os.environ.copy()
                if command[0] == CTEST and gate["id"] in ("factor:compute_route_vulkan", "factor:graph_route_vulkan"):
                    run_env.pop("PATH", None)
                process = subprocess.run(command, cwd=ROOT, env=run_env, stdout=stream,
                                         stderr=subprocess.STDOUT, creationflags=0x08000000)
            result['commands'].append({'argv': command, 'started': started,
                                       'exit_code': process.returncode,
                                       'log': log.name, 'sha256': sha(log)})
            if command[0] == CTEST:
                detail = Path(test_dir) / 'Testing/Temporary/LastTest.log'
                if detail.exists():
                    saved_detail = output / (gate['id'].replace(':', '-') + '-' + str(index) + '-CTest.log')
                    shutil.copy2(detail, saved_detail)
                    result['commands'][-1]['ctest_detail'] = {
                        'log': saved_detail.name, 'sha256': sha(saved_detail)}
            if process.returncode:
                result['status'] = 'FAIL'
                record['status'] = 'INCONCLUSIVE'
                save()
                print('FAIL ' + gate['id'] + ': ' + str(log), flush=True)
                return process.returncode
            save()
        assert_candidate()
        result['status'] = 'PASS'
        save()
        print('PASS ' + gate['id'], flush=True)
    record['status'] = 'PASS'
    save()
    print('Completed ' + args.group + ': ' + str(len(selected)) + ' selected gates', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
