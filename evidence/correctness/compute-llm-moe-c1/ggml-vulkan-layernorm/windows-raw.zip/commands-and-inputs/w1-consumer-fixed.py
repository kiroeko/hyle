"""Reuse the exact Y33 selected Vulkan SDKs; no additional producer builds."""
import ctypes,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path('C:/public/project-hyle/hyle')
TASK=Path(__file__).resolve().parent
CANDIDATE='4d255a5174825dc669de1684affd7729d3b430d7'
WORK=Path('C:/hyle-scratch/active-vk/g33v')
GRAPH=WORK/'delivery-graph/selected-graph'
CMAKE='C:/Program Files/CMake/bin/cmake.exe'
CTEST='C:/Program Files/CMake/bin/ctest.exe'
CONSUMER=TASK/'consumer'
FIXTURES=ROOT/'.scratch/validation/vulkan-c1-fragment/fixtures'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==CANDIDATE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
assert json.loads((TASK/'route-resumed-delivery/result.json').read_text())['status']=='PASS'
ctypes.windll.kernel32.SetErrorMode(0x8003)
OUT=TASK/'w1-actual-delivery-fixed'
OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy()
env.update(HYLE_VULKAN_VALIDATION='1',HYLE_TEST_VULKAN_VALIDATE='1',
 VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin',
 VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LOADER_LAYERS_DISABLE='~implicit~',
 CMAKE_BUILD_PARALLEL_LEVEL='2',CTEST_PARALLEL_LEVEL='1')
record={'candidate':CANDIDATE,'scope':'Y33 actual local-weight LayerNorm Direct/Graph source/static/shared; no P1',
 'producer_reuse':'exact selected Vulkan source tree and relocated SDKs; no added producer build',
 'consumer_files':{p.name:sha(p) for p in CONSUMER.iterdir() if p.is_file()},
 'fixture_receipt_sha256':sha(FIXTURES/'receipt.json'),'commands':[],'deliveries':[],'status':'RUNNING'}
def save():
 (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,command,runtime=False):
 print('START '+name,flush=True)
 child=env.copy()
 if runtime:child.pop('PATH',None)
 log=OUT/(name+'.log');start=time.monotonic()
 with log.open('wb') as f:
  f.write((json.dumps(command)+'\n').encode());f.flush()
  process=subprocess.run(command,cwd=ROOT,env=child,stdout=f,stderr=subprocess.STDOUT,
                         timeout=600,creationflags=0x08000000)
 row={'name':name,'argv':command,'exit_code':process.returncode,'seconds':time.monotonic()-start,
      'runtime_PATH_unset':runtime,'log':log.name,'sha256':sha(log)}
 record['commands'].append(row);save()
 if process.returncode:raise RuntimeError(name+' failed; inspect '+str(log))
 print('PASS '+name,flush=True)
def stage(directory):
 redist=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
 crt=sorted(p/'x64/Microsoft.VC145.CRT' for p in redist.iterdir() if (p/'x64/Microsoft.VC145.CRT').is_dir())[-1]
 for p in crt.glob('*.dll'):shutil.copy2(p,directory/p.name)
 shutil.copy2(Path('C:/Windows/System32/vulkan-1.dll'),directory/'vulkan-1.dll')
def qualify(label,build):
 stage(build)
 exe=build/'hyle_c1_layernorm.exe'
 run(label+'-test',[str(exe),str(FIXTURES)],True)
 text=(OUT/(label+'-test.log')).read_text(errors='replace')
 assert 'PASS LayerNorm cases=60 runs=180 retained_close=60 quota_zero=60' in text
 assert not any(x in text for x in ('VUID-','Validation Error','SYNC-HAZARD'))
 run(label+'-linkage',['dumpbin','/dependents',str(exe)])
 record['deliveries'].append({'linkage':label,'tests':60,'runs':180,
   'retained_after_close':60,'quota_zero':60,'executable_sha256':sha(exe),
   'cache_sha256':sha(build/'CMakeCache.txt')})
 save()
try:
 save()
 for name,digest in record['consumer_files'].items():assert sha(CONSUMER/name)==digest
 # The already qualified source parent embeds the same clean canonical candidate.
 # Add only this external consumer; unchanged HYLE objects are reused.
 parent=GRAPH/'source-parent/CMakeLists.txt'
 prior=json.loads((TASK/'w1-actual-delivery/result.json').read_text())
 assert prior['status']=='FAIL' and prior['deliveries']==[]
 assert sha(parent)==prior['source_parent_sha256']
 record['reused_source_configure']='w1-actual-delivery/result.json'
 source=GRAPH/'source-build'
 run('source-build',[CMAKE,'--build',str(source),'--target','hyle_c1_layernorm','--parallel','2'])
 qualify('source',source)
 for linkage in ('static','shared'):
  prefix=GRAPH/(linkage+'-sdk-relocated')
  assert prefix.is_dir()
  build=WORK/('layernorm-'+linkage)
  assert not build.exists()
  run(linkage+'-configure',[CMAKE,'-S',str(CONSUMER),'-B',str(build),'-G','Ninja',
                          '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),
                          '-DCMAKE_TOOLCHAIN_FILE='+str(TASK/'remaining-toolchain.cmake')])
  run(linkage+'-build',[CMAKE,'--build',str(build),'--parallel','2'])
  qualify(linkage,build)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==CANDIDATE
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
 record['status']='PASS'
except BaseException as error:
 record.update(status='FAIL',error=str(error));raise
finally:save()
