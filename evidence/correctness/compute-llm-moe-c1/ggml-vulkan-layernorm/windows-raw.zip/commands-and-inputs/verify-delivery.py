"""C1-Y33 real BF16 state fragment; immutable source/static/shared consumer, two producer builds."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--archive', type=Path, required=True)
parser.add_argument('--sha256', required=True)
parser.add_argument('--candidate', required=True)
parser.add_argument('--consumer', type=Path, required=True)
parser.add_argument('--fixtures', type=Path, required=True)
parser.add_argument('--resume-source-build', action='store_true')
args = parser.parse_args()
root, archive = args.root.resolve(), args.archive.resolve()
root.mkdir(exist_ok=args.resume_source_build)
logs = root / 'logs'
logs.mkdir(exist_ok=args.resume_source_build)
windows = os.name == 'nt'
if windows:
    ctypes.windll.kernel32.SetErrorMode(0x8003)
commit = args.candidate
assert len(commit) == 40 and all(c in '0123456789abcdef' for c in commit)
env = dict(os.environ, CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1',
           VK_LOADER_LAYERS_DISABLE='~implicit~', CTEST_INTERACTIVE_DEBUG_MODE='0')
if not windows:
    env.update(PATH='/opt/homebrew/bin:' + env['PATH'], MACOSX_DEPLOYMENT_TARGET='14.4',
               DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib')
headers = Path('C:/public/tools/hyle-dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f'
    if windows else '/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f')
compiler = 'C:/public/tools/glslang/glslangValidator.exe' if windows else '/opt/homebrew/bin/glslangValidator'
cmake = 'C:/Program Files/CMake/bin/cmake.exe' if windows else '/opt/homebrew/bin/cmake'
ctest = 'C:/Program Files/CMake/bin/ctest.exe' if windows else '/opt/homebrew/bin/ctest'
vendor = Path('C:/public/project-hyle/ggml' if windows else '/Users/kiro/hyle-verify/llm-moe-c1-20260918/ggml')
env.update(TRACY_ONLY_LOCALHOST='1', HYLE_VULKAN_VALIDATION='1',
           VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
           VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin' if windows else
           '/Users/kiro/hyle-verify/r6-vulkan-20260917/tools/vulkan-validationlayers/1.4.357.0/share/vulkan/explicit_layer.d',
           HYLE_DEP_SOURCE_CACHE='C:/public/tools/hyle-dependencies/v1' if windows else
           '/Users/kiro/Library/Caches/hyle/dependencies/v1')
records = []
identity = {'snapshot': commit, 'scope': 'Y33 actual-weight LayerNorm Direct/Graph; no full C1/model/performance acceptance',
    'state': 'RUNNING', 'source_archive': str(archive), 'source_archive_sha256': args.sha256,
    'platform': 'Windows' if windows else 'Air Mac16,12', 'records': records, 'executables': {}}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save():
    (logs / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')

def run(label, command, timeout=1800):
    command = [str(x) for x in command]
    print(label, flush=True)
    if command[0] == 'cmake':
        command[0] = cmake
    elif command[0] == 'ctest':
        command[0] = ctest
    started = time.monotonic()
    with (logs / (label + '.log')).open('w', encoding='utf-8') as f:
        result = subprocess.run(command, cwd=root, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    records.append({'label': label, 'command': command, 'exit_code': result.returncode,
                    'seconds': time.monotonic() - started})
    save()
    if result.returncode:
        print((logs / (label + '.log')).read_text(errors='replace')[-6000:], flush=True)
    result.check_returncode()

def relocate(old, new):
    assert root in old.resolve().parents and root in new.resolve().parents
    assert old.is_dir() and not new.exists()
    if windows:
        subprocess.run(['C:/Program Files/PowerShell/7/pwsh.exe', '-NoProfile', '-File',
                        str(Path(__file__).with_name('relocate.ps1')), '-Root', str(root),
                        '-Source', str(old), '-Destination', str(new)], check=True)
    else:
        old.rename(new)

def configure(build, tree, static, install=True, source=None):
    command = ['cmake', '-S', tree, '-B', build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
        '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DHYLE_COMPONENTS=compute;graph',
        '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF', '-DHYLE_COMPUTE_APPLE=OFF',
        '-DHYLE_COMPUTE_ONEDNN=OFF', '-DHYLE_COMPUTE_VULKAN=ON', '-DHYLE_BUILD_TESTS=OFF',
        '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_WERROR=ON', '-DHYLE_STATIC=' + ('ON' if static else 'OFF'),
        '-DHYLE_INSTALL=' + ('ON' if install else 'OFF'), '-DHYLE_VULKAN_GLSLANG=' + compiler,
        '-DHYLE_TEST_INSTRUMENTATION=OFF', '-DHYLE_TRACE=OFF', '-DHYLE_SANITIZER=off',
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=' + str(headers),
        '-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=' + str(vendor),
        '-DVulkan_GLSLC_EXECUTABLE=' + ('C:/public/tools/hyle-vulkan/1.4.357.0/Bin/glslc.exe' if windows else '/opt/homebrew/bin/glslc'),
        '-DCMAKE_PREFIX_PATH=' + ('C:/public/tools/hyle-vulkan/1.4.357.0' if windows else '/opt/homebrew')]
    if source is not None:
        command.append('-DHYLE_SOURCE_ROOT=' + str(source))
    if not windows:
        command.append('-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4')
    run(build.name + '-configure', command)

def verify_executables(build, names):
    if windows:
        redist = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
        crt = sorted(p / 'x64/Microsoft.VC145.CRT' for p in redist.iterdir() if (p / 'x64/Microsoft.VC145.CRT').is_dir())[-1]
        for library in crt.glob('*.dll'):
            shutil.copy2(library, build / library.name)
        shutil.copy2(Path('C:/Windows/System32/vulkan-1.dll'), build / 'vulkan-1.dll')
    command = [ctest, '--test-dir', build, '--output-on-failure', '--no-tests=error', '--timeout', '300', '--parallel', '1']
    if windows:
        command = [cmake, '-E', 'env', '--unset=PATH'] + command
    run(build.name + '-test', command)
    detail = (build / 'Testing/Temporary/LastTest.log').read_text(errors='replace')
    assert not any(marker in detail for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD')), detail
    shutil.copyfile(build / 'Testing/Temporary/LastTest.log', logs / (build.name + '-LastTest.log'))
    for name in names:
        executable = build / (name + ('.exe' if windows else ''))
        identity['executables'][build.name + '/' + name] = sha(executable)
        run(build.name + '-' + name + '-linkage', ['dumpbin', '/dependents', executable] if windows else
            ['/usr/bin/otool', '-L', executable])

try:
    assert sha(archive) == args.sha256
    assert (headers / 'include/vulkan/vulkan_core.h').is_file()
    extracted = root / 'complete-source'
    if args.resume_source_build:
        previous = json.loads((logs / 'identity.json').read_text(encoding='utf-8'))
        assert previous['state'] == 'FAIL' and previous['snapshot'] == commit
        assert previous['source_archive_sha256'] == args.sha256
        assert not previous['executables']
        assert not any((root / n).exists() for n in ('bd', 'sdk-static', 'relocated-sdk-static', 'bs-hidden', 'complete-source-hidden'))
        attempt = previous.get('consumer_corrections', 0) + 1
        assert attempt <= 2, 'finite consumer correction budget exhausted'
        failure = root / ('consumer-attempt-' + str(attempt) + '-failure.zip')
        with zipfile.ZipFile(failure, 'x', zipfile.ZIP_DEFLATED) as z:
            for folder in (logs, root / 'independent-consumer'):
                for p in folder.rglob('*'):
                    if p.is_file(): z.write(p, p.relative_to(root).as_posix())
        identity.update(consumer_corrections=attempt, resumed_failure={'archive': failure.name, 'sha256': sha(failure)})
    save()
    with zipfile.ZipFile(archive) as z:
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
        if args.resume_source_build:
            for entry in z.infolist():
                if not entry.is_dir():
                    assert (extracted / entry.filename).read_bytes() == z.read(entry.filename), 'immutable product drift'
        else:
            z.extractall(extracted)
    trees = list(extracted.glob('hyle-*-source'))
    assert len(trees) == 1
    tree = trees[0]
    assert commit in (tree / 'SOURCE-MANIFEST.txt').read_text(encoding='utf-8')
    consumers = root / 'independent-consumer'
    fixtures = root / 'fixtures'
    if args.resume_source_build:
        for p in args.consumer.resolve().iterdir():
            assert p.is_file()
            if not (consumers / p.name).exists() or p.read_bytes() != (consumers / p.name).read_bytes():
                shutil.copy2(p, consumers / p.name)
        assert sha(fixtures / 'receipt.json') == sha(args.fixtures.resolve() / 'receipt.json')
    else:
        shutil.copytree(args.consumer.resolve(), consumers)
        shutil.copytree(args.fixtures.resolve(), fixtures)
    fixture_receipt = json.loads((fixtures / 'receipt.json').read_text(encoding='utf-8'))
    def verify_fixture(value):
        if isinstance(value, dict):
            if 'file' in value and 'sha256' in value:
                path = (fixtures / value['file']).resolve()
                assert fixtures.resolve() in path.parents
                assert sha(path) == value['sha256']
            for child in value.values():
                verify_fixture(child)
        elif isinstance(value, list):
            for child in value:
                verify_fixture(child)
    verify_fixture(fixture_receipt)
    identity['fixture_receipt_sha256'] = sha(fixtures / 'receipt.json')
    identity['consumer_files'] = {p.name: sha(p) for p in consumers.iterdir() if p.is_file()}
    cmakelists = consumers / 'CMakeLists.txt'
    with cmakelists.open('a', encoding='utf-8') as output:
        output.write('\nenable_testing()\nadd_test(NAME actual_weight_layernorm COMMAND '
                     'hyle_c1_layernorm "' + fixtures.as_posix() + '")\n')
    identity['test_registration_sha256'] = sha(cmakelists)
    source_build = root / 'bs'
    configure(source_build, consumers, True, True, source=tree)
    run('source-build', ['cmake', '--build', source_build, '--parallel', '2'])
    verify_executables(source_build, ['hyle_c1_layernorm'])
    producer_builds, prefixes = [source_build], {}
    for linkage in ('static', 'shared'):
        if linkage == 'static':
            build = source_build
        else:
            build = root / 'bd'
            configure(build, tree, False)
            run(linkage + '-build', ['cmake', '--build', build, '--parallel', '2'])
        prefix = root / ('sdk-' + linkage)
        run(linkage + '-install', ['cmake', '--install', build, '--prefix', prefix])
        relocated = root / ('relocated-sdk-' + linkage)
        relocate(prefix, relocated)
        prefixes[linkage] = relocated
        if build not in producer_builds:
            producer_builds.append(build)
    for build in producer_builds:
        for name in ('CMakeCache.txt', 'compile_commands.json'):
            shutil.copyfile(build / name, logs / (build.name + '-' + name))
        relocate(build, build.with_name(build.name + '-hidden'))
    relocate(extracted, extracted.with_name(extracted.name + '-hidden'))
    identity['producer_paths_hidden_before_sdk_consumption'] = True
    for linkage, prefix in prefixes.items():
        assert (prefix / 'include/vulkan/vulkan_core.h').is_file()
        for name in ('ggml-vulkan-runtime-LICENSE', 'ggml-vulkan-patches-LICENSE', 'ggml-vulkan-patches-NOTICE.md',
                     'ggml-vulkan-shaders-LICENSE', 'ggml-vulkan-shaders-NOTICE.md',
                     'vulkan-headers-LICENSE.md', 'vulkan-headers-Apache-2.0.txt', 'vulkan-headers-MIT.txt'):
            assert (prefix / 'share/licenses/Hyle' / name).is_file(), name
        artifacts = [p.name for p in prefix.rglob('*') if p.suffix.lower() in ('.lib', '.dll', '.a', '.so', '.dylib')]
        forbidden = ('onednn', 'libmlx', 'cublas', 'marlin', 'compute_backend_cpu', 'compute_backend_cuda', 'compute_route_apple')
        assert not any(word in name.lower() for name in artifacts for word in forbidden), artifacts
        (logs / (linkage + '-artifacts.json')).write_text(json.dumps(artifacts, indent=2) + '\n')
        build = root / ('consumer-' + linkage)
        command = ['cmake', '-S', consumers, '-B', build, '-G', 'Ninja',
            '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(prefix)]
        if not windows:
            command.append('-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4')
        run(build.name + '-configure', command)
        run(build.name + '-build', ['cmake', '--build', build, '--parallel', '2'])
        if windows and linkage == 'shared':
            assert (build / 'hyle_compute_route_vulkan.dll').is_file()
        verify_executables(build, ['hyle_c1_layernorm'])
    identity['static_producer_reused_source_build'] = True
    identity['environment'] = {k: v for k, v in env.items() if k in (
        'CMAKE_BUILD_PARALLEL_LEVEL', 'CTEST_PARALLEL_LEVEL', 'HYLE_VULKAN_VALIDATION',
        'VK_INSTANCE_LAYERS', 'VK_LAYER_PATH', 'VK_LOADER_LAYERS_DISABLE', 'HYLE_DEP_SOURCE_CACHE')}
    identity['logs'] = {p.name: sha(p) for p in logs.glob('*.log')}
    identity['state'] = 'PASS'
except Exception as error:
    identity.update(state='FAIL', error=str(error))
    raise
finally:
    identity['finished'] = time.time()
    save()
