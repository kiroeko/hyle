from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time

ROOT = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
META = json.loads((ROOT / 'y33-candidate.json').read_text())
SOURCE = ROOT / 'source'
BUILD = ROOT / 'build-vulkan-static'
CANDIDATE = META['candidate']
TREE = META['tree']
LOGS = ROOT / ('y33-' + CANDIDATE[:8])
TOOLS = ROOT / 't-mini-vulkan-tools'
EXTRA = ROOT / 'y-vulkan-tools'
GLSLC = EXTRA / 'shaderc/2026.3/bin/glslc'
CMAKE = next(Path('/Users/kiro/hyle-verify-tools/lib').glob('python*/site-packages/cmake/data/bin/cmake'))
CTEST = CMAKE.with_name('ctest')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def extract(archive, expected, directory):
    assert digest(archive) == expected
    assert not directory.exists(), 'never overlay a validation source tree'
    with tarfile.open(archive, 'r:gz') as package:
        for member in package.getmembers():
            target = (ROOT / member.name).resolve()
            assert target == directory or directory in target.parents
            assert member.isfile() or member.isdir() or member.issym() or member.islnk()
            if member.issym():
                target = (target.parent / member.linkname).resolve()
                assert target == directory or directory in target.parents
            if member.islnk():
                target = (ROOT / member.linkname).resolve()
                assert target == directory or directory in target.parents
        package.extractall(ROOT)

assert not LOGS.exists(), 'inspect the existing attempt before restarting'
previous_source = ROOT / ('source-prior-y33-' + CANDIDATE[:8])
assert SOURCE.is_dir() and not SOURCE.is_symlink() and SOURCE.resolve().parent == ROOT.resolve()
assert not previous_source.exists()
SOURCE.rename(previous_source)
extract(ROOT / META['archive'], META['archive_sha256'], SOURCE)
# Fresh archive contents are authoritative; keep unchanged-file timestamps for incremental builds.
for current in SOURCE.rglob('*'):
    if current.is_file() and not current.is_symlink():
        previous = previous_source / current.relative_to(SOURCE)
        if previous.is_file() and not previous.is_symlink() and current.read_bytes() == previous.read_bytes():
            stat = previous.stat()
            os.utime(current, ns=(stat.st_atime_ns, stat.st_mtime_ns))

vendor_archive = ROOT / 'ggml.tar.gz'
assert digest(vendor_archive) == 'e13c176ea92e4a54ef3efccdfdb192e7433c76f91181de86b445560a47b07ac7'
with tarfile.open(vendor_archive, 'r:gz') as archive:
    for member in archive.getmembers():
        if member.isfile():
            assert (ROOT / member.name).read_bytes() == archive.extractfile(member).read(), member.name
        elif member.issym():
            assert os.readlink(ROOT / member.name) == member.linkname
assert digest(ROOT / 't-mini-vulkan-tools.tar.gz') == 'a34568e2d301473e39469a4c6cbbf2328ec41d100caf02175a98cc06e7c94144'
for item in json.loads((TOOLS / 'manifest.json').read_text())['files']:
    assert digest(TOOLS / item['file']) == item['sha256']
extra_receipt = json.loads((ROOT / 'y-vulkan-tools.json').read_text())
assert digest(GLSLC) == extra_receipt['glslc_sha256']
for item in extra_receipt['archives']:
    assert digest(ROOT / item['name']) == item['sha256']
LOGS.mkdir()

ENV = os.environ.copy()
ENV.update(PATH='/Users/kiro/hyle-verify-tools/bin:' + ENV['PATH'],
    CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1', TRACY_ONLY_LOCALHOST='1',
    DYLD_LIBRARY_PATH=str(TOOLS / 'lib'), VK_ICD_FILENAMES=str(TOOLS / 'MoltenVK_icd.json'),
    VK_LOADER_LAYERS_DISABLE='~implicit~')
result = {
    'candidate': CANDIDATE, 'tree': TREE, 'archive_sha256': META['archive_sha256'],
    'product_candidate': META.get('product_candidate', CANDIDATE),
    'scope': 'C1-Y33 mature LayerNorm static direct/graph correctness and portability; not delivery or performance acceptance',
    'source': str(SOURCE), 'source_kind': 'complete canonical Git archive', 'build': str(BUILD),
    'vendor_commit': '456172ec733a135778adcd32d00e576a58232e45',
    'vendor_archive_sha256': 'e13c176ea92e4a54ef3efccdfdb192e7433c76f91181de86b445560a47b07ac7',
    'role': 'Mac mini correctness and portability only',
    'validation_layer': 'not installed; W1 and Air provide validation-layer evidence',
    'excluded_cases': [],
    'tools': extra_receipt,
    'machine': {
        'model': subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip(),
        'os': subprocess.check_output(['/usr/bin/sw_vers'], text=True),
        'compiler': subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'], text=True),
    },
    'environment': {k: ENV[k] for k in ('PATH', 'DYLD_LIBRARY_PATH', 'VK_ICD_FILENAMES', 'VK_LOADER_LAYERS_DISABLE')},
    'commands': [], 'verdict': 'RUNNING'}

def save():
    (LOGS / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

def run(label, command, timeout):
    print('RUN', label, flush=True)
    log = LOGS / (label + '.log')
    start = time.monotonic()
    timed_out = False
    with log.open('wb') as output:
        try:
            rc = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=output, stderr=subprocess.STDOUT, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            rc = 124
            timed_out = True
    result['commands'].append({'label': label, 'command': command, 'exit_code': rc,
        'seconds': time.monotonic() - start, 'timed_out': timed_out, 'log': str(log), 'sha256': digest(log)})
    if rc:
        result['verdict'] = 'FAIL'
        save()
        print(log.read_text(errors='replace')[-9000:], flush=True)
        sys.exit(rc)
    save()

save()
run('configure', [str(CMAKE), '-S', str(SOURCE), '-B', str(BUILD), '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
    '-DHYLE_DEV_FACTORS=compute_provider_ggml_vulkan;compute_route_vulkan;graph_route_vulkan',
    '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF',
    '-DHYLE_COMPUTE_VULKAN=ON', '-DHYLE_COMPUTE_ONEDNN=OFF', '-DHYLE_BUILD_TESTS=ON',
    '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_STATIC=ON', '-DHYLE_INSTALL=OFF', '-DHYLE_WERROR=ON',
    '-DHYLE_TEST_INSTRUMENTATION=OFF', '-DHYLE_TRACE=OFF', '-DHYLE_SANITIZER=off',
    '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=' + str(ROOT / 'ggml'),
    '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=' + str(TOOLS / 'vulkan-headers'),
    '-DHYLE_VULKAN_GLSLANG=' + str(TOOLS / 'glslang-local'),
    '-DVulkan_INCLUDE_DIR=' + str(TOOLS / 'vulkan-headers/include'),
    '-DVulkan_LIBRARY=' + str(TOOLS / 'lib/libvulkan.1.dylib'),
    '-DVulkan_GLSLC_EXECUTABLE=' + str(GLSLC),
    '-DSPIRV-Headers_DIR=' + str(EXTRA / 'spirv-headers/share/cmake/SPIRV-Headers')], 180)
run('build', [str(CMAKE), '--build', str(BUILD), '--parallel', '2', '--target',
    'hyle_compute_provider_ggml_vulkan_tests', 'hyle_compute_route_vulkan_tests', 'hyle_graph_route_vulkan_tests', '--', '-k', '0'], 1800)
run('source-contract', [sys.executable, str(SOURCE / 'tests/compute_provider_ggml_vulkan/source_contract_test.py')], 300)
for suite in ('compute_provider_ggml_vulkan', 'compute_route_vulkan', 'graph_route_vulkan'):
    command = [str(BUILD / 'bin' / ('hyle_' + suite + '_test')), '--gtest_output=json:' + str(LOGS / (suite + '.json'))]
    run(suite, command, 300)
    report = json.loads((LOGS / (suite + '.json')).read_text())
    assert report['tests'] == META['expected_tests']['mini'][suite] and report['failures'] == report['errors'] == report.get('disabled', 0) == 0
    assert all(test['status'] == 'RUN' and test['result'] == 'COMPLETED' for group in report['testsuites'] for test in group['testsuite'])
result['artifacts'] = [{
    'path': str(BUILD / 'bin' / ('hyle_' + suite + '_test')),
    'sha256': digest(BUILD / 'bin' / ('hyle_' + suite + '_test')),
    'tests': json.loads((LOGS / (suite + '.json')).read_text())['tests']}
    for suite in ('compute_provider_ggml_vulkan', 'compute_route_vulkan', 'graph_route_vulkan')]
result['verdict'] = 'PASS'
save()
print('C1-Y33 mature LayerNorm Mini static focused PASS', flush=True)
