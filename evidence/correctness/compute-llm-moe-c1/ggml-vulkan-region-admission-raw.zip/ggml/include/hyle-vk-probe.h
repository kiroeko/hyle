#pragma once
#include "ggml-backend.h"
#include <vulkan/vulkan_core.h>
struct hyle_vk_probe_device {
    VkInstance instance;
    VkPhysicalDevice physical_device;
    VkDevice device;
    VkQueue queue;
    uint32_t family;
};
#ifdef __cplusplus
extern "C" {
#endif
bool hyle_vk_probe_native(ggml_backend_t backend, struct hyle_vk_probe_device * out);
VkBuffer hyle_vk_probe_buffer(ggml_backend_buffer_t buffer);
ggml_backend_buffer_t hyle_vk_probe_borrow(ggml_backend_t backend, VkBuffer buffer, size_t bytes);
#ifdef __cplusplus
}
#endif
