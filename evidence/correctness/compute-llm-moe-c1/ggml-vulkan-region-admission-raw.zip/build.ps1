$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:VULKAN_SDK = 'C:/hyle-scratch/ggml-vulkan-region-20260918/sdk'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:PATH = "$env:VULKAN_SDK/Bin;$env:PATH"
$ggmlProbeRoot = 'C:/hyle-scratch/ggml-vulkan-region-20260918'
& cmake -S "$ggmlProbeRoot/probe" -B "$ggmlProbeRoot/build" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$env:VULKAN_SDK" *> "$ggmlProbeRoot/configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlProbeRoot/configure.log" -Tail 25; exit $LASTEXITCODE }
& cmake --build "$ggmlProbeRoot/build" --target ggml_region_probe --parallel 2 *> "$ggmlProbeRoot/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlProbeRoot/build.log" -Tail 25; exit $LASTEXITCODE }
& "$ggmlProbeRoot/build/ggml_region_probe.exe" *> "$ggmlProbeRoot/run.log"
Get-Content "$ggmlProbeRoot/run.log" -Tail 25
exit $LASTEXITCODE
