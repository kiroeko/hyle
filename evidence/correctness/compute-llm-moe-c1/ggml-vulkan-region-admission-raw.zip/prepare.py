import ctypes
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path(__file__).resolve().parent
sdk = Path('C:/hyle-scratch/r6-vulkan-20260917/tools/vulkansdk-windows-X64-1.4.357.0.exe')
seven = Path('C:/Program Files/7-Zip/7z.exe')
data = sdk.read_bytes()
assert hashlib.sha256(data).hexdigest() == '81f474711e9042f4cd22b31b2f7a8870db2e428b21586fb43dd80150be97310d'
offsets = [34765643, 190025084, 190059108, 224383015, 226332128]
inventory = []
for i, start in enumerate(offsets):
    arc = root / f'sdk-part-{start}.7z'
    if not arc.exists():
        arc.write_bytes(data[start:])
    p = subprocess.run([str(seven), 'l', '-slt', str(arc)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
    (root / f'sdk-part-{start}.listing').write_bytes(p.stdout)
    paths = [line[7:] for line in p.stdout.decode('utf-8', errors='replace').splitlines() if line.startswith('Path = ')][1:]
    wanted = [x for x in paths if x.startswith(('Include\\', 'Lib\\vulkan-1.lib', 'Lib\\cmake\\SPIRV-Headers')) or x in ('Bin\\glslc.exe', 'Bin\\shaderc_shared.dll')]
    inventory.append({'offset': start, 'count': len(paths), 'selected': len(wanted)})
    if wanted:
        listing = root / f'extract-{start}.txt'
        listing.write_bytes(('\n'.join(wanted)+'\n').encode('utf-8'))
        with (root / f'extract-{start}.log').open('wb') as log:
            subprocess.run([str(seven), 'x', '-y', '-scsUTF-8', '-o'+str(root/'sdk'), str(arc), '@'+str(listing)], stdout=log, stderr=subprocess.STDOUT, check=True)
print(json.dumps(inventory), flush=True)
source = root / 'ggml'
if not source.exists():
    payload = subprocess.check_output(['git', '-C', 'C:/public/project-hyle/ggml', 'archive', '456172ec733a135778adcd32d00e576a58232e45'])
    source.mkdir()
    with tarfile.open(fileobj=io.BytesIO(payload)) as archive:
        archive.extractall(source, filter='data')
    p = source/'src/ggml-vulkan/vulkan-shaders/vulkan-shaders-gen.cpp'
    s = p.read_text(encoding='utf-8')
    s = s.replace('#define ASYNCIO_CONCURRENCY 64', '#define ASYNCIO_CONCURRENCY 1').replace('std::min(16u, std::thread::hardware_concurrency())', 'std::min(1u, std::thread::hardware_concurrency())')
    p.write_bytes(s.encode('utf-8'))
    p = source/'src/ggml-vulkan/CMakeLists.txt'
    s = p.read_text(encoding='utf-8').replace('    add_definitions(/MP)', '    # Probe uses outer build parallelism 2; no nested /MP.')
    p.write_bytes(s.encode('utf-8'))
print('source prepared: exact upstream algorithms; build concurrency only reduced', flush=True)
