#include <ggml.h>
#include <ggml-alloc.h>
#include <ggml-backend.h>
#include <ggml-vulkan.h>
#include <hyle-vk-probe.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#endif

static void native_fill(const hyle_vk_probe_device &d, VkBuffer buffer, size_t bytes) {
    const auto check = [](VkResult r) { if (r != VK_SUCCESS) throw std::runtime_error("native Vulkan failure"); };
    VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pci.queueFamilyIndex = d.family;
    VkCommandPool pool{};
    check(vkCreateCommandPool(d.device, &pci, nullptr, &pool));
    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = pool;
    cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cai.commandBufferCount = 1;
    VkCommandBuffer command{};
    check(vkAllocateCommandBuffers(d.device, &cai, &command));
    VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    check(vkBeginCommandBuffer(command, &begin));
    vkCmdFillBuffer(command, buffer, 0, bytes, 0x3f000000u);
    VkMemoryBarrier barrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
    barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(command, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                         0, 1, &barrier, 0, nullptr, 0, nullptr);
    check(vkEndCommandBuffer(command));
    VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    VkFence fence{};
    check(vkCreateFence(d.device, &fci, nullptr, &fence));
    VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submit.commandBufferCount = 1;
    submit.pCommandBuffers = &command;
    check(vkQueueSubmit(d.queue, 1, &submit, fence));
    check(vkWaitForFences(d.device, 1, &fence, VK_TRUE, UINT64_MAX));
    vkDestroyFence(d.device, fence, nullptr);
    vkDestroyCommandPool(d.device, pool, nullptr);
}

int main() {
#ifdef _WIN32
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
#endif
    try {
        constexpr int width = 2048;
        for (int rows : {1, 17, 128}) {
            auto backend = ggml_backend_vk_init(0);
            if (!backend) throw std::runtime_error("Vulkan backend unavailable");
            const size_t bytes = 32 * ggml_tensor_overhead() + ggml_graph_overhead_custom(32, false);
            std::vector<unsigned char> arena(bytes);
            auto ctx = ggml_init({bytes, arena.data(), true});
            if (!ctx) throw std::runtime_error("context allocation failed");
            auto x = ggml_new_tensor_2d(ctx, GGML_TYPE_F32, width, rows);
            auto w = ggml_new_tensor_1d(ctx, GGML_TYPE_F32, width);
            auto norm = ggml_rms_norm(ctx, x, 1e-6f);
            auto weighted = ggml_mul(ctx, norm, w);
            auto gate = ggml_silu(ctx, weighted);
            auto result = ggml_add(ctx, gate, x);
            ggml_set_input(x);
            ggml_set_input(w);
            ggml_set_output(result);
            auto graph = ggml_new_graph_custom(ctx, 32, false);
            ggml_build_forward_expand(graph, result);
            hyle_vk_probe_device native{};
            if (!hyle_vk_probe_native(backend, &native)) throw std::runtime_error("native export failed");
            auto input_storage = ggml_backend_alloc_buffer(backend, width * rows * sizeof(float));
            if (!input_storage) throw std::runtime_error("input buffer allocation failed");
            const auto handle = hyle_vk_probe_buffer(input_storage);
            auto borrowed = hyle_vk_probe_borrow(backend, handle, width * rows * sizeof(float));
            if (!borrowed) throw std::runtime_error("native import failed");
            if (ggml_backend_tensor_alloc(borrowed, x, ggml_backend_buffer_get_base(borrowed)) != GGML_STATUS_SUCCESS)
                throw std::runtime_error("native input binding failed");
            auto storage = ggml_backend_alloc_ctx_tensors(ctx, backend);
            if (!storage) throw std::runtime_error("device allocation failed");
            std::vector<float> input(width * rows), weights(width), output(width * rows);
            for (int k = 0; k != width; ++k) weights[k] = 0.5f + float(k % 19) / 19.f;
            ggml_backend_tensor_set(w, weights.data(), 0, weights.size() * sizeof(float));
            double max_error = 0;
            for (int iteration = 0; iteration != 3; ++iteration) {
                for (size_t i = 0; i != input.size(); ++i) input[i] = float(int((i * 13 + iteration * 17) % 193) - 96) / 37.f;
                if (iteration == 1) {
                    std::fill(input.begin(), input.end(), 0.5f);
                    native_fill(native, handle, input.size() * sizeof(float));
                } else {
                    ggml_backend_tensor_set(x, input.data(), 0, input.size() * sizeof(float));
                }
                if (ggml_backend_graph_compute(backend, graph) != GGML_STATUS_SUCCESS)
                    throw std::runtime_error("graph execution failed");
                ggml_backend_tensor_get(result, output.data(), 0, output.size() * sizeof(float));
                for (int row = 0; row < rows; ++row) {
                    double sum = 0;
                    for (int col = 0; col < width; ++col) {
                        double v = input[row * width + col];
                        sum += v * v;
                    }
                    double scale = 1. / std::sqrt(sum / width + 1e-6);
                    for (int col = 0; col < width; ++col) {
                        size_t i = row * width + col;
                        double v = input[i] * scale * weights[col];
                        double expected = v / (1. + std::exp(-v)) + input[i];
                        double error = std::abs(output[i] - expected);
                        if (error > 6e-6 * (1. + std::abs(expected)))
                            throw std::runtime_error("independent scalar oracle mismatch");
                        if (error > max_error) max_error = error;
                    }
                }
            }
            std::printf("rows=%d width=%d repeats=3 max_abs=%.9g backend=%s native-import/export+surviving-owner PASS\n", rows, width, max_error, ggml_backend_name(backend));
            ggml_backend_synchronize(backend);
            ggml_backend_buffer_free(storage);
            ggml_backend_buffer_free(borrowed);
            // The imported wrapper must not destroy the original owner's handle.
            native_fill(native, handle, input.size() * sizeof(float));
            ggml_backend_buffer_free(input_storage);
            ggml_free(ctx);
            ggml_backend_free(backend);
        }
    } catch (const std::exception &e) {
        std::fprintf(stderr, "FAIL: %s\n", e.what());
        return 1;
    }
}
