from pathlib import Path

root = Path(__file__).resolve().parent
source = root/'ggml'
p = source/'include/hyle-vk-probe.h'
p.write_bytes(b'''#pragma once
#include "ggml-backend.h"
#include <vulkan/vulkan_core.h>
struct hyle_vk_probe_device {
    VkInstance instance;
    VkPhysicalDevice physical_device;
    VkDevice device;
    VkQueue queue;
    uint32_t family;
};
#ifdef __cplusplus
extern "C" {
#endif
bool hyle_vk_probe_native(ggml_backend_t backend, struct hyle_vk_probe_device * out);
VkBuffer hyle_vk_probe_buffer(ggml_backend_buffer_t buffer);
ggml_backend_buffer_t hyle_vk_probe_borrow(ggml_backend_t backend, VkBuffer buffer, size_t bytes);
#ifdef __cplusplus
}
#endif
''')
p = source/'src/ggml-vulkan/ggml-vulkan.cpp'
s = p.read_text(encoding='utf-8')
assert 'hyle_probe_borrowed' not in s
s = s.replace('#include "ggml-vulkan.h"', '#include "ggml-vulkan.h"\n#include "hyle-vk-probe.h"', 1)
s = s.replace('struct vk_buffer_struct {', 'struct vk_buffer_struct {\n    bool hyle_probe_borrowed = false;', 1)
s = s.replace('    ~vk_buffer_struct() {\n        if (size == 0)', '    ~vk_buffer_struct() {\n        if (hyle_probe_borrowed || size == 0)', 1)
s = s.replace('    if (buf->device != nullptr) {\n        buf->device->memory_logger->log_deallocation(buf);', '    if (buf->device != nullptr && !buf->hyle_probe_borrowed) {\n        buf->device->memory_logger->log_deallocation(buf);', 1)
s += '''
// Bounded admission probe, not an accepted HYLE or upstream API.
extern "C" bool hyle_vk_probe_native(ggml_backend_t backend, hyle_vk_probe_device * out) {
    if (!out || !ggml_backend_is_vk(backend)) return false;
    auto * ctx = static_cast<ggml_backend_vk_context *>(backend->context);
    *out = { vk_instance.instance, ctx->device->physical_device,
             ctx->device->device, ctx->device->compute_queue->handle->queue,
             ctx->device->compute_queue->queue_family_index };
    return true;
}
extern "C" VkBuffer hyle_vk_probe_buffer(ggml_backend_buffer_t buffer) {
    if (!buffer || !ggml_backend_buffer_is_vk(buffer)) return VK_NULL_HANDLE;
    return static_cast<ggml_backend_vk_buffer_context *>(buffer->context)->dev_buffer->buffer;
}
extern "C" ggml_backend_buffer_t hyle_vk_probe_borrow(ggml_backend_t backend, VkBuffer handle, size_t bytes) {
    if (!ggml_backend_is_vk(backend) || !handle || !bytes) return nullptr;
    auto * ctx = static_cast<ggml_backend_vk_context *>(backend->context);
    auto buf = std::make_shared<vk_buffer_struct>();
    buf->hyle_probe_borrowed = true;
    buf->device = ctx->device;
    buf->buffer = handle;
    buf->size = bytes;
    if (ctx->device->buffer_device_address) {
        buf->bda_addr = ctx->device->device.getBufferAddress(vk::BufferDeviceAddressInfo{handle});
    }
    auto buffer_context = std::make_unique<ggml_backend_vk_buffer_context>(ctx->device, std::move(buf), ctx->name);
    auto result = ggml_backend_buffer_init(&ctx->device->buffer_type, ggml_backend_vk_buffer_interface, buffer_context.get(), bytes);
    buffer_context.release();
    return result;
}
'''
p.write_bytes(s.encode('utf-8'))

p = root/'probe/probe.cpp'
s = p.read_text(encoding='utf-8')
s = s.replace('#include <ggml-vulkan.h>', '#include <ggml-vulkan.h>\n#include <hyle-vk-probe.h>')
s = s.replace('int main() {', '''static void native_fill(const hyle_vk_probe_device &d, VkBuffer buffer, size_t bytes) {
    const auto check = [](VkResult r) { if (r != VK_SUCCESS) throw std::runtime_error("native Vulkan failure"); };
    VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pci.queueFamilyIndex = d.family;
    VkCommandPool pool{};
    check(vkCreateCommandPool(d.device, &pci, nullptr, &pool));
    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = pool;
    cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cai.commandBufferCount = 1;
    VkCommandBuffer command{};
    check(vkAllocateCommandBuffers(d.device, &cai, &command));
    VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    check(vkBeginCommandBuffer(command, &begin));
    vkCmdFillBuffer(command, buffer, 0, bytes, 0x3f000000u);
    VkMemoryBarrier barrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
    barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(command, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                         0, 1, &barrier, 0, nullptr, 0, nullptr);
    check(vkEndCommandBuffer(command));
    VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    VkFence fence{};
    check(vkCreateFence(d.device, &fci, nullptr, &fence));
    VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submit.commandBufferCount = 1;
    submit.pCommandBuffers = &command;
    check(vkQueueSubmit(d.queue, 1, &submit, fence));
    check(vkWaitForFences(d.device, 1, &fence, VK_TRUE, UINT64_MAX));
    vkDestroyFence(d.device, fence, nullptr);
    vkDestroyCommandPool(d.device, pool, nullptr);
}

int main() {''', 1)
s = s.replace('            auto storage = ggml_backend_alloc_ctx_tensors(ctx, backend);', '''            hyle_vk_probe_device native{};
            if (!hyle_vk_probe_native(backend, &native)) throw std::runtime_error("native export failed");
            auto input_storage = ggml_backend_alloc_buffer(backend, width * rows * sizeof(float));
            if (!input_storage) throw std::runtime_error("input buffer allocation failed");
            const auto handle = hyle_vk_probe_buffer(input_storage);
            auto borrowed = hyle_vk_probe_borrow(backend, handle, width * rows * sizeof(float));
            if (!borrowed) throw std::runtime_error("native import failed");
            if (ggml_backend_tensor_alloc(borrowed, x, ggml_backend_buffer_get_base(borrowed)) != GGML_STATUS_SUCCESS)
                throw std::runtime_error("native input binding failed");
            auto storage = ggml_backend_alloc_ctx_tensors(ctx, backend);''')
s = s.replace('                ggml_backend_tensor_set(x, input.data(), 0, input.size() * sizeof(float));', '''                if (iteration == 1) {
                    std::fill(input.begin(), input.end(), 0.5f);
                    native_fill(native, handle, input.size() * sizeof(float));
                } else {
                    ggml_backend_tensor_set(x, input.data(), 0, input.size() * sizeof(float));
                }''')
s = s.replace('            ggml_backend_buffer_free(storage);', '''            ggml_backend_buffer_free(storage);
            ggml_backend_buffer_free(borrowed);
            // The imported wrapper must not destroy the original owner's handle.
            native_fill(native, handle, input.size() * sizeof(float));
            ggml_backend_buffer_free(input_storage);''')
s = s.replace('backend=%s PASS', 'backend=%s native-import/export+surviving-owner PASS')
p.write_bytes(s.encode('utf-8'))
p = root/'probe/CMakeLists.txt'
s = p.read_text(encoding='utf-8').replace('add_subdirectory(../ggml ggml)', 'find_package(Vulkan REQUIRED)\nadd_subdirectory(../ggml ggml)').replace('PRIVATE ggml ggml-vulkan)', 'PRIVATE ggml ggml-vulkan Vulkan::Vulkan)')
p.write_bytes(s.encode('utf-8'))
print('bounded device/buffer bridge probe prepared; no operation algorithm changed')
