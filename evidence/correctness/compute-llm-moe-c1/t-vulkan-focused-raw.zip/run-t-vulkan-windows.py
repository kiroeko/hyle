from pathlib import Path
import ctypes, hashlib, json, os, shutil, subprocess, sys, time

ctypes.windll.kernel32.SetErrorMode(0x8003)
canonical = Path('C:/public/project-hyle/hyle')
root = Path('C:/hyle-scratch/c1vk')
source = root / 'source'
build = root / 'build-static'
candidate = '8397126919a2b01f82669d1b3f7c0920fd0ea020'
tree = 'ddbc0f4cae057d4ab9284b53ac974c92364c52de'
logs = Path('C:/hyle-scratch/llm-moe-c1-20260917/t-windows') / candidate[:8]
logs.mkdir(parents=True, exist_ok=False)
if not source.exists():
    subprocess.run(['git', 'clone', '--shared', '--no-checkout', str(canonical), str(source)], check=True)
else:
    assert not subprocess.check_output(['git','status','--porcelain'], cwd=source)
    subprocess.run(['git','fetch',str(canonical),candidate], cwd=source, check=True)
subprocess.run(['git','checkout','--detach',candidate],cwd=source,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip() == tree
env = os.environ.copy()
env.update(CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1', TRACY_ONLY_LOCALHOST='1',
           HYLE_VULKAN_VALIDATION='1',
           VK_LAYER_PATH='C:/hyle-scratch/r6-vulkan-20260917/tools/validation-1.4.357.0')
env['PATH'] = 'C:/public/tools/glslang;' + env['PATH']
result = {'candidate':candidate, 'tree':tree, 'source':str(source), 'build':str(build),
          'kind':'C1-T Vulkan focused factors and headers; full C1 bundle/delivery/P1 pending',
          'machine':'W1-WIN', 'commands':[], 'verdict':'RUNNING'}
def save():
    (logs/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode('utf-8'))
def run(label, command, timeout=900):
    print('RUN',label,flush=True)
    log=logs/(label+'.log'); start=time.monotonic()
    with log.open('wb') as output:
        rc=subprocess.run(command,cwd=source,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=timeout).returncode
    result['commands'].append({'label':label,'command':command,'exit_code':rc,'seconds':time.monotonic()-start,
                              'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    save()
    if rc:
        result['verdict']='FAIL';save()
        print(log.read_text(errors='replace')[-8000:],flush=True)
        sys.exit(rc)
    print('PASS',label,flush=True)
save()
run('selector',['python','scripts/validation-select.py','plan','--base','be6cf8b1','--candidate',candidate,
                '--context','C:/hyle-scratch/r6-vulkan-20260917/selected-w1-v2/context.json',
                '--output',str(logs/'selector.json')])
run('configure',['cmake','-S',str(source),'-B',str(build),'-G','Ninja',
    '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
    '-DHYLE_DEV_FACTORS=compute_route_vulkan;graph_route_vulkan',
    '-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF',
    '-DHYLE_COMPUTE_ONEDNN=OFF','-DHYLE_COMPUTE_VULKAN=ON',
    '-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON',
    '-DHYLE_STATIC=ON','-DHYLE_INSTALL=OFF','-DHYLE_SANITIZER=off',
    '-DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe',
    '-DHYLE_DEP_SOURCE_CACHE=C:/public/project-hyle/.deps','-DFETCHCONTENT_FULLY_DISCONNECTED=ON',
    '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=C:/hyle-scratch/r6-vulkan-20260917/locked-sources/vulkan_headers/Vulkan-Headers-e3b1eec08173d6b825cd3ac88c885a63b621504a'])
run('build',['cmake','--build',str(build),'--parallel','2','--target',
             'hyle_compute_route_vulkan_test','hyle_graph_route_vulkan_test'])
# Keep all build-owned runtime dependencies beside each test executable.
dlls={p.name:p for p in build.rglob('*.dll')}
staged=[]
for exe in build.rglob('hyle_*vulkan_test.exe'):
    for name,dll in dlls.items():
        destination=exe.parent/name
        if destination.resolve()!=dll.resolve(): shutil.copy2(dll,destination)
    staged.append(str(exe))
result['runtime_staged_executables']=staged;save()
assert len(staged)==2
run('test',['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','--timeout','300',
            '--verbose','-L','^(compute_route_vulkan|graph_route_vulkan)$'])
raw=(build/'Testing/Temporary/LastTest.log').read_bytes()
(logs/'LastTest.log').write_bytes(raw)
result['last_test_sha256']=hashlib.sha256(raw).hexdigest()
result['verdict']='PASS';save()
print('C1-T Vulkan focused PASS',flush=True)
