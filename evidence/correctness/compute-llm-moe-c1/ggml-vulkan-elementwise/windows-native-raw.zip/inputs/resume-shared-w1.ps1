$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$taskRoot = Join-Path $canonicalRoot '.scratch\validation\vulkan-elementwise'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:PYTHONIOENCODING = 'utf-8'
& python (Join-Path $taskRoot 'resume-shared-w1.py')
exit $LASTEXITCODE
