#include <hyle/graph/vulkan.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <expected>
#include <filesystem>
#include <fstream>
#include <span>
#include <utility>
#include <vector>

namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace gv = g::vulkan;
using hyle::Result;
using hyle::Status;
enum class Mode { Stable, Packed, Separate };
constexpr std::size_t fixture_rows = 34;
constexpr std::size_t heads = 16;
constexpr std::size_t hidden = 6144;

template <class T>
Result<std::vector<T>> read(const std::filesystem::path &path,
                            std::size_t count) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  if (!file || file.tellg() != static_cast<std::streamoff>(count * sizeof(T)))
    return std::unexpected(Status::DataLoss("fixture byte size"));
  std::vector<T> result(count);
  file.seekg(0);
  if (!file.read(reinterpret_cast<char *>(result.data()),
                 static_cast<std::streamsize>(count * sizeof(T))))
    return std::unexpected(Status::DataLoss("fixture read"));
  return result;
}

float decode(std::uint16_t value) {
  return std::bit_cast<float>(static_cast<std::uint32_t>(value) << 16);
}
std::uint16_t encode(double value) {
  auto bits = std::bit_cast<std::uint32_t>(static_cast<float>(value));
  bits += 0x7fffU + ((bits >> 16) & 1U);
  return static_cast<std::uint16_t>(bits >> 16);
}
double sigmoid(double x) {
  const double e = std::exp(-std::abs(x));
  return x >= 0 ? 1.0 / (1.0 + e) : e / (1.0 + e);
}

struct Fixtures {
  std::vector<std::uint16_t> a, b, gate, up;
  std::vector<float> bias, logarithm;
};
Result<Fixtures> load(const std::filesystem::path &root) {
  Fixtures f;
  HYLE_ASSIGN_OR_RETURN(
      f.a, read<std::uint16_t>(root / "a.bf16", fixture_rows * heads));
  HYLE_ASSIGN_OR_RETURN(
      f.b, read<std::uint16_t>(root / "b.bf16", fixture_rows * heads));
  HYLE_ASSIGN_OR_RETURN(
      f.gate, read<std::uint16_t>(root / "gate.bf16", fixture_rows * hidden));
  HYLE_ASSIGN_OR_RETURN(
      f.up, read<std::uint16_t>(root / "up.bf16", fixture_rows * hidden));
  HYLE_ASSIGN_OR_RETURN(f.bias, read<float>(root / "dt-bias.f32", heads));
  HYLE_ASSIGN_OR_RETURN(f.logarithm, read<float>(root / "a-log.f32", heads));
  return f;
}

Status upload(const v::Context &context, const v::Tensor &destination,
              std::span<const double> values) {
  if (destination.description().data_type() == c::DataType::kFloat32) {
    std::vector<float> data;
    for (double value : values)
      data.push_back(static_cast<float>(value));
    return context.upload(destination, std::as_bytes(std::span(data)));
  }
  std::vector<std::uint16_t> data;
  for (double value : values)
    data.push_back(encode(value));
  return context.upload(destination, std::as_bytes(std::span(data)));
}
Result<std::vector<std::byte>> bytes(const v::Context &context,
                                     const v::Tensor &tensor) {
  HYLE_ASSIGN_OR_RETURN(auto size, tensor.description().required_bytes());
  std::vector<std::byte> result(size);
  HYLE_RETURN_IF_ERROR(context.download(tensor, result));
  return result;
}
Status verify(const v::Context &context, const v::Tensor &tensor,
              std::span<const double> expected) {
  HYLE_ASSIGN_OR_RETURN(auto count, tensor.description().element_count());
  if (count != expected.size())
    return Status::DataLoss("result element count");
  const bool half = tensor.description().data_type() == c::DataType::kBFloat16;
  std::vector<float> floats(half ? 0 : count);
  std::vector<std::uint16_t> halves(half ? count : 0);
  if (half)
    HYLE_RETURN_IF_ERROR(
        context.download(tensor, std::as_writable_bytes(std::span(halves))));
  else
    HYLE_RETURN_IF_ERROR(
        context.download(tensor, std::as_writable_bytes(std::span(floats))));
  for (std::size_t i = 0; i < count; ++i) {
    const double wanted =
        half ? decode(encode(expected[i])) : static_cast<float>(expected[i]);
    const double actual = half ? decode(halves[i]) : floats[i];
    const double tolerance =
        (half ? 0.008 : 6e-6) * std::abs(wanted) + (half ? 2e-7 : 2e-6);
    if (!std::isfinite(actual) || std::abs(actual - wanted) > tolerance) {
      std::fprintf(stderr,
                   "element=%zu actual=%.12g expected=%.12g tolerance=%.12g\n",
                   i, actual, wanted, tolerance);
      return Status::DataLoss("independent stable/gate FP64 oracle");
    }
  }
  return Status::Ok();
}

struct Node {
  c::Operation operation;
  std::vector<std::size_t> inputs;
};
struct Flow {
  std::size_t input_count = 0;
  std::vector<c::TensorDesc> descriptions;
  std::vector<v::Tensor> constants;
  std::vector<Node> nodes;
  std::vector<std::size_t> outputs;
  Result<std::size_t> add(c::Operation operation,
                          std::initializer_list<std::size_t> inputs) {
    std::vector<c::TensorDesc> arguments;
    for (auto id : inputs)
      arguments.push_back(descriptions[id]);
    HYLE_ASSIGN_OR_RETURN(auto output,
                          c::infer_single_output(operation, arguments));
    const auto id = descriptions.size();
    descriptions.push_back(output);
    nodes.push_back({std::move(operation), std::vector<std::size_t>(inputs)});
    return id;
  }
};

Result<Flow> make_flow(const v::Context &context, const Fixtures &fixtures,
                       const std::array<std::int64_t, 2> &prefix,
                       c::DataType type, Mode mode) {
  const auto width = mode == Mode::Stable ? heads : hidden;
  HYLE_ASSIGN_OR_RETURN(
      auto desc,
      c::TensorDesc::dense(type, std::array{prefix[0], prefix[1],
                                            static_cast<std::int64_t>(width)}));
  Flow flow;
  if (mode == Mode::Packed) {
    HYLE_ASSIGN_OR_RETURN(
        auto packed,
        c::TensorDesc::dense(type,
                             std::array{prefix[0], prefix[1],
                                        static_cast<std::int64_t>(2 * width)}));
    flow.input_count = 1;
    flow.descriptions = {packed};
    HYLE_ASSIGN_OR_RETURN(
        auto gated, flow.add(c::Operation(c::GatedActivation{
                                 .activation = c::GatedActivationKind::kSilu,
                                 .inputs = c::GatedInputKind::kPackedHalves}),
                             {0}));
    flow.outputs = {gated};
    return flow;
  }
  flow.input_count = 2;
  flow.descriptions = {desc, desc};
  if (mode == Mode::Separate) {
    HYLE_ASSIGN_OR_RETURN(
        auto gated, flow.add(c::Operation(c::GatedActivation{
                                 .activation = c::GatedActivationKind::kSilu,
                                 .inputs = c::GatedInputKind::kSeparate}),
                             {0, 1}));
    flow.outputs = {gated};
    return flow;
  }
  HYLE_ASSIGN_OR_RETURN(
      auto parameter,
      c::TensorDesc::dense(c::DataType::kFloat32,
                           std::array{static_cast<std::int64_t>(heads)}));
  for (const auto *values : {&fixtures.bias, &fixtures.logarithm}) {
    HYLE_ASSIGN_OR_RETURN(
        auto tensor,
        context.upload(parameter, std::as_bytes(std::span(*values))));
    flow.descriptions.push_back(parameter);
    flow.constants.push_back(std::move(tensor));
  }
  HYLE_ASSIGN_OR_RETURN(
      auto a, flow.add(c::Operation(c::Cast{c::DataType::kFloat32}), {0}));
  HYLE_ASSIGN_OR_RETURN(
      auto b, flow.add(c::Operation(c::Cast{c::DataType::kFloat32}), {1}));
  HYLE_ASSIGN_OR_RETURN(
      auto shifted,
      flow.add(c::Operation(c::Binary{c::BinaryKind::kAdd}), {a, 2}));
  HYLE_ASSIGN_OR_RETURN(
      auto plus,
      flow.add(c::Operation(c::Unary{c::UnaryKind::kSoftplus}), {shifted}));
  HYLE_ASSIGN_OR_RETURN(
      auto score,
      flow.add(c::Operation(c::Unary{c::UnaryKind::kSqrt}), {plus}));
  HYLE_ASSIGN_OR_RETURN(
      auto log_score,
      flow.add(c::Operation(c::Unary{c::UnaryKind::kLog}), {score}));
  HYLE_ASSIGN_OR_RETURN(
      auto inverse,
      flow.add(c::Operation(c::Unary{c::UnaryKind::kRsqrt}), {plus}));
  HYLE_ASSIGN_OR_RETURN(
      auto exponential,
      flow.add(c::Operation(c::Unary{c::UnaryKind::kExp}), {3}));
  HYLE_ASSIGN_OR_RETURN(
      auto negative,
      flow.add(c::Operation(c::Unary{c::UnaryKind::kNeg}), {exponential}));
  HYLE_ASSIGN_OR_RETURN(
      auto decay, flow.add(c::Operation(c::Binary{c::BinaryKind::kMultiply}),
                           {plus, negative}));
  HYLE_ASSIGN_OR_RETURN(
      auto sigmoid_gate,
      flow.add(c::Operation(c::Unary{c::UnaryKind::kSigmoid}), {b}));
  HYLE_ASSIGN_OR_RETURN(
      auto attended, flow.add(c::Operation(c::Binary{c::BinaryKind::kMultiply}),
                              {sigmoid_gate, a}));
  flow.outputs = {plus, score, log_score, inverse, decay, attended};
  return flow;
}

Result<std::vector<v::Program>> prepare(const v::Context &context,
                                        const Flow &flow, bool graph) {
  std::vector<v::Program> programs;
  if (graph) {
    HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
    std::vector<g::ValueId> values;
    for (std::size_t i = 0; i < flow.input_count; ++i) {
      HYLE_ASSIGN_OR_RETURN(auto id, builder.input(flow.descriptions[i]));
      values.push_back(id);
    }
    for (const auto &constant : flow.constants) {
      HYLE_ASSIGN_OR_RETURN(auto id, builder.constant(constant.description()));
      values.push_back(id);
    }
    for (const auto &node : flow.nodes) {
      std::vector<g::ValueId> inputs;
      for (auto id : node.inputs)
        inputs.push_back(values[id]);
      HYLE_ASSIGN_OR_RETURN(
          auto created, builder.add_node(node.operation,
                                         std::span<const g::ValueId>(inputs)));
      HYLE_ASSIGN_OR_RETURN(auto id, builder.result(created));
      values.push_back(id);
    }
    for (auto id : flow.outputs)
      HYLE_RETURN_IF_ERROR(builder.publish(values[id]));
    HYLE_ASSIGN_OR_RETURN(auto plan, std::move(builder).finish());
    gv::CompileReport report;
    HYLE_ASSIGN_OR_RETURN(
        auto program,
        gv::compile(context, plan, flow.constants, {.report = &report}));
    if (report.managed_region_count == 0)
      return std::unexpected(
          Status::DataLoss("Graph did not bind mature region"));
    programs.push_back(std::move(program));
    return programs;
  }
  for (const auto &node : flow.nodes) {
    std::vector<v::Argument> arguments;
    for (auto id : node.inputs)
      arguments.emplace_back(flow.descriptions[id]);
    HYLE_ASSIGN_OR_RETURN(auto program,
                          v::prepare(context, node.operation,
                                     std::span<const v::Argument>(arguments)));
    programs.push_back(std::move(program));
  }
  return programs;
}

struct Recording {
  std::vector<v::Tensor> values;
  v::RecordedProgram program;
};
Result<Recording> record(const v::Context &context, const Flow &flow,
                         std::span<const v::Program> programs) {
  Recording result;
  const auto first_node = flow.input_count + flow.constants.size();
  for (std::size_t i = 0; i < flow.descriptions.size(); ++i) {
    if (i >= flow.input_count && i < first_node)
      result.values.push_back(flow.constants[i - flow.input_count]);
    else {
      HYLE_ASSIGN_OR_RETURN(auto value, context.allocate(flow.descriptions[i]));
      result.values.push_back(std::move(value));
    }
  }
  HYLE_ASSIGN_OR_RETURN(auto recorder, v::Recorder::create(context));
  for (std::size_t i = 0; i < flow.nodes.size(); ++i) {
    std::vector<v::Tensor> inputs;
    for (auto id : flow.nodes[i].inputs)
      inputs.push_back(result.values[id]);
    HYLE_RETURN_IF_ERROR(recorder.append(
        programs[i], inputs, std::array{result.values[first_node + i]}));
  }
  HYLE_ASSIGN_OR_RETURN(result.program, recorder.finish());
  return result;
}

std::vector<std::vector<double>> input_values(const Fixtures &f,
                                              std::size_t rows, Mode mode,
                                              std::size_t phase) {
  const bool stable = mode == Mode::Stable;
  const std::size_t width = stable ? heads : hidden;
  std::vector<std::vector<double>> result(mode == Mode::Packed ? 1 : 2);
  result[0].resize(rows * width * (mode == Mode::Packed ? 2 : 1));
  if (result.size() == 2)
    result[1].resize(rows * width);
  const auto &left = stable ? f.a : f.gate;
  const auto &right = stable ? f.b : f.up;
  for (std::size_t row = 0; row < rows; ++row) {
    const auto source = ((row + phase * 7) % fixture_rows) * width;
    for (std::size_t column = 0; column < width; ++column) {
      const auto first = row * width * (mode == Mode::Packed ? 2 : 1) + column;
      result[0][first] = decode(left[source + column]);
      if (mode == Mode::Packed)
        result[0][first + width] = decode(right[source + column]);
      else
        result[1][row * width + column] = decode(right[source + column]);
    }
  }
  return result;
}

// Independent scalar FP64 formulas; explicit F32 operation boundaries and final
// BF16 RNE are checked without calling any HYLE numerical implementation.
std::vector<std::vector<double>>
reference(const Fixtures &f, const std::vector<std::vector<double>> &input,
          Mode mode) {
  if (mode != Mode::Stable) {
    const auto count = input[0].size() / (mode == Mode::Packed ? 2 : 1);
    std::vector<std::vector<double>> result(1, std::vector<double>(count));
    for (std::size_t i = 0; i < count; ++i) {
      const auto offset =
          mode == Mode::Packed ? (i / hidden) * 2 * hidden + i % hidden : i;
      const double a = input[0][offset];
      const double b =
          mode == Mode::Packed ? input[0][offset + hidden] : input[1][i];
      const float activated = static_cast<float>(a * sigmoid(a));
      result[0][i] = static_cast<float>(activated * static_cast<float>(b));
    }
    return result;
  }
  std::vector<std::vector<double>> result(6,
                                          std::vector<double>(input[0].size()));
  for (std::size_t i = 0; i < input[0].size(); ++i) {
    const double x = static_cast<float>(input[0][i] + f.bias[i % heads]);
    const float plus = static_cast<float>(std::max(x, 0.0) +
                                          std::log1p(std::exp(-std::abs(x))));
    const float root = static_cast<float>(std::sqrt(static_cast<double>(plus)));
    result[0][i] = plus;
    result[1][i] = root;
    result[2][i] = static_cast<float>(std::log(static_cast<double>(root)));
    result[3][i] =
        static_cast<float>(1.0 / std::sqrt(static_cast<double>(plus)));
    result[4][i] = plus * -static_cast<float>(std::exp(
                              static_cast<double>(f.logarithm[i % heads])));
    result[5][i] = static_cast<float>(sigmoid(input[1][i])) *
                   static_cast<float>(input[0][i]);
  }
  return result;
}

Status run_case(const Fixtures &fixtures,
                const std::array<std::int64_t, 2> &shape, c::DataType type,
                Mode mode, bool graph) {
  hyle::mem::QuotaAllocator quota(hyle::mem::system_allocator(),
                                  256 * 1024 * 1024);
  {
    HYLE_ASSIGN_OR_RETURN(
        auto context,
        v::Context::create({.validation = true, .memory_quota = &quota}));
    HYLE_ASSIGN_OR_RETURN(auto flow,
                          make_flow(context, fixtures, shape, type, mode));
    HYLE_ASSIGN_OR_RETURN(auto programs, prepare(context, flow, graph));
    std::array<v::Invocation, 2> slots;
    std::array<Recording, 2> recordings;
    for (std::size_t i = 0; i < 2; ++i) {
      if (graph) {
        HYLE_ASSIGN_OR_RETURN(slots[i], programs[0].create_invocation());
      } else {
        HYLE_ASSIGN_OR_RETURN(recordings[i], record(context, flow, programs));
      }
    }
    std::vector<v::Tensor> retained;
    std::vector<std::vector<std::byte>> snapshots;
    for (std::size_t phase = 0; phase < 3; ++phase) {
      const auto input = input_values(
          fixtures, static_cast<std::size_t>(shape[0] * shape[1]), mode, phase);
      std::vector<v::Tensor> results;
      if (graph) {
        std::vector<v::Tensor> inputs;
        for (std::size_t i = 0; i < input.size(); ++i) {
          HYLE_ASSIGN_OR_RETURN(auto tensor,
                                context.allocate(flow.descriptions[i]));
          HYLE_RETURN_IF_ERROR(upload(context, tensor, input[i]));
          inputs.push_back(std::move(tensor));
        }
        auto &slot = slots[phase == 0 ? 0 : 1];
        HYLE_RETURN_IF_ERROR(slot.bind(inputs));
        HYLE_ASSIGN_OR_RETURN(auto work, slot.submit());
        HYLE_ASSIGN_OR_RETURN(auto result, work.wait());
        results.assign(result.get()->tensors().begin(),
                       result.get()->tensors().end());
      } else {
        auto &recording = recordings[phase == 0 ? 0 : 1];
        for (std::size_t i = 0; i < input.size(); ++i)
          HYLE_RETURN_IF_ERROR(upload(context, recording.values[i], input[i]));
        HYLE_ASSIGN_OR_RETURN(auto work, recording.program.submit());
        HYLE_RETURN_IF_ERROR(work.wait());
        for (auto id : flow.outputs)
          results.push_back(recording.values[id]);
      }
      const auto expected = reference(fixtures, input, mode);
      if (results.size() != expected.size())
        return Status::DataLoss("published output count");
      for (std::size_t i = 0; i < results.size(); ++i) {
        HYLE_RETURN_IF_ERROR(verify(context, results[i], expected[i]));
        if (phase == 0) {
          HYLE_ASSIGN_OR_RETURN(auto saved, bytes(context, results[i]));
          snapshots.push_back(std::move(saved));
        }
      }
      if (phase == 0)
        retained = results;
      else
        for (std::size_t i = 0; i < retained.size(); ++i) {
          HYLE_ASSIGN_OR_RETURN(auto current, bytes(context, retained[i]));
          if (current != snapshots[i])
            return Status::DataLoss("retained result overwritten");
        }
    }
    slots = {};
    for (auto &recording : recordings)
      recording = {};
    programs.clear();
    flow.constants.clear();
    HYLE_RETURN_IF_ERROR(context.close());
    for (std::size_t i = 0; i < retained.size(); ++i) {
      HYLE_ASSIGN_OR_RETURN(auto current, bytes(context, retained[i]));
      if (current != snapshots[i])
        return Status::DataLoss("retained result changed after close");
    }
  }
  return quota.used() == 0 ? Status::Ok()
                           : Status::DataLoss("elementwise owner quota leak");
}

Status run(const std::filesystem::path &root) {
  HYLE_ASSIGN_OR_RETURN(auto fixtures, load(root));
  const std::array<std::array<std::int64_t, 2>, 3> shapes{
      {{1, 1}, {1, 17}, {2, 23}}};
  std::size_t cases = 0;
  for (auto type : {c::DataType::kFloat32, c::DataType::kBFloat16})
    for (const auto &shape : shapes)
      for (auto mode : {Mode::Stable, Mode::Packed, Mode::Separate})
        for (bool graph : {false, true}) {
          const auto status = run_case(fixtures, shape, type, mode, graph);
          if (!status.ok()) {
            std::fprintf(stderr, "type=%d shape=%lld/%lld mode=%d graph=%d\n",
                         static_cast<int>(type),
                         static_cast<long long>(shape[0]),
                         static_cast<long long>(shape[1]),
                         static_cast<int>(mode), graph);
            return status;
          }
          ++cases;
        }
  std::printf(
      "PASS Elementwise cases=%zu runs=%zu retained_close=%zu quota_zero=%zu\n",
      cases, cases * 3, cases, cases);
  return Status::Ok();
}

int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  const auto status = run(argv[1]);
  if (!status.ok()) {
    std::fprintf(stderr, "%.*s\n", static_cast<int>(status.message().size()),
                 status.message().data());
    return 1;
  }
  return 0;
}
