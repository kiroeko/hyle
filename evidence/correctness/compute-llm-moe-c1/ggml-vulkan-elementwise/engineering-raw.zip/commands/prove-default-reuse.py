"""Read-only identity proof for unchanged Y34 default journeys and native factors.

No test is run or newly passed here. Actual Vulkan-on qualification is separate.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('C:/public/project-hyle/hyle')
OUT = Path(__file__).resolve().parent
BASE = 'ec240ac9392cb8144d326d8407d9af4b8456026a'
CANDIDATE = 'f58d26096dac635fe4ff23a141a0194d94faeebb'
PRIOR = ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-reduction/engineering'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
changed = git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines()
non_docs = [name for name in changed if not name.startswith(('docs/', 'evidence/'))]
allowed = {
    'cmake/HyleDependencyLock.json',
    'src/compute_provider_ggml_vulkan/region.cc',
    'src/compute_route_vulkan/CMakeLists.txt',
    'src/compute_route_vulkan/shaders/tensor.comp',
    'src/compute_route_vulkan/vulkan_elementwise.cc',
    'src/compute_route_vulkan/vulkan_operations.cc',
    'src/compute_route_vulkan/vulkan_program_internal.h',
    'src/compute_route_vulkan/vulkan_region.cc',
    'tests/compute_route_vulkan/managed_region_test.cc',
    'tests/graph_route_vulkan/gate_norm_test.cc',
    'tests/graph_route_vulkan/managed_region_test.cc',
    'tests/graph_route_vulkan/reduction_test.cc',
    'tests/graph_route_vulkan/tensor_test.cc',
    'tests/graph_route_vulkan/view_test.cc',
    'third_party/ggml_vulkan_runtime/NOTICE.md',
    'third_party/ggml_vulkan_runtime/patches.json',
}
assert set(non_docs) == allowed

def differences(a, b, path=''):
    if type(a) is not type(b):
        return [(path, a, b)]
    if isinstance(a, dict):
        assert a.keys() == b.keys()
        return [row for key in a for row in differences(a[key], b[key], path + '/' + key)]
    if isinstance(a, list):
        assert len(a) == len(b)
        return [row for index, (left, right) in enumerate(zip(a, b)) for row in differences(left, right, path + '/' + str(index))]
    return [] if a == b else [(path, a, b)]

old_lock = json.loads(git('show', BASE + ':cmake/HyleDependencyLock.json'))
new_lock = json.loads(git('show', CANDIDATE + ':cmake/HyleDependencyLock.json'))
lock_delta = differences(old_lock, new_lock)
assert len(lock_delta) == 2
assert {row[1] for row in lock_delta} == {
    '5b19b4886eaac1040c8f69820c9d2320f00c6caf57690d6328996f35e238b5a3',
    '422b1e44f7a211f2ddf4bbd3a405565ee19b9c39afb5219c4a4c333ae2280e65'}
changed_dependency = int(lock_delta[0][0].split('/')[2])
assert all(row[0].startswith('/dependencies/' + str(changed_dependency) + '/') for row in lock_delta)
assert old_lock['dependencies'][changed_dependency]['vendored']['path'] == 'third_party/ggml_vulkan_runtime'

native = json.loads((PRIOR / 'selected-gates-result.json').read_text(encoding='utf-8'))
delivery = json.loads((PRIOR / 'remaining-deliveries-receipt.json').read_text(encoding='utf-8'))
assert native['status'] == delivery['status'] == 'PASS'
assert native['candidate'] == delivery['candidate'] == BASE
archives = {}
native_archive = PRIOR / native['archive']['path']
assert sha(native_archive) == native['archive']['sha256']
with zipfile.ZipFile(native_archive) as archive:
    assert archive.testzip() is None
    for name, expected in native['archive']['files'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected['sha256']
    previous_native = json.loads(archive.read('native/result.json'))
    previous_plan = json.loads(archive.read('native/plan.json'))
    archives['native'] = {'path': str(native_archive.relative_to(ROOT)), 'sha256': sha(native_archive)}

def cache(text):
    return {line.split(':', 1)[0]: line.split('=', 1)[1] for line in text.splitlines()
            if line and not line.startswith(('#', '//')) and ':' in line and '=' in line}

default_features = {}
delivery_archive = PRIOR / delivery['archive']
assert sha(delivery_archive) == delivery['archive_sha256']
with zipfile.ZipFile(delivery_archive) as archive:
    assert archive.testzip() is None
    execution = json.loads(archive.read('execution/result.json'))
    assert execution['status'] == 'PASS'
    for gate in execution['gates']:
        assert gate['status'] == 'PASS'
        for command in gate['commands']:
            assert command['exit_code'] == 0
            assert hashlib.sha256(archive.read('execution/' + command['log'])).hexdigest() == command['sha256']
    for component in ('compute', 'graph'):
        for journey in ('source-build', 'shared-sdk-build', 'static-sdk-build'):
            c = cache(archive.read(component + '/' + journey + '/CMakeCache.txt').decode())
            assert c['HYLE_COMPUTE_VULKAN'] == 'OFF'
            assert c['CMAKE_CXX_FLAGS_RELEASE'] == '/O2 /Ob2 /DNDEBUG'
            default_features[component + '/' + journey] = {
                key: c[key] for key in ('HYLE_COMPUTE_VULKAN', 'CMAKE_CXX_COMPILER', 'CMAKE_CXX_FLAGS_RELEASE')}
    archives['delivery'] = {'path': str(delivery_archive.relative_to(ROOT)), 'sha256': sha(delivery_archive)}

artifact_checks = {}
vulkan_executables = {'hyle_compute_provider_ggml_vulkan_test.exe', 'hyle_compute_route_vulkan_test.exe', 'hyle_graph_route_vulkan_test.exe'}
for name, identity in native['native_artifacts'].items():
    if name in vulkan_executables:
        continue
    artifact = Path('C:/hyle-scratch/active-vk/static/bin') / name
    assert artifact.stat().st_size == identity['bytes'] and sha(artifact) == identity['sha256'], name
    artifact_checks[name] = identity

packages, journeys = {}, {}
for component in delivery['components']:
    name = component['component']
    base = Path('C:/hyle-scratch/active-vk/g34') / ('delivery-' + name) / ('selected-' + name)
    for linkage, manifest in component['packages'].items():
        prefix = base / (linkage + '-sdk-relocated')
        for relative, expected in manifest.items():
            artifact = prefix / relative
            assert artifact.stat().st_size == expected['bytes'] and sha(artifact) == expected['sha256'], artifact
        packages[name + '/' + linkage] = {'files': len(manifest), 'identity_verified': True,
                                         'manifest_sha256': hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()}
    for journey in component['journeys']:
        assert journey['status'] == 'PASS'
        present = {}
        for relative, expected in journey['executables'].items():
            artifact = base / relative
            if artifact.exists():
                assert sha(artifact) == expected
                present[relative] = expected
            else:
                assert journey['journey'] == 'source', artifact
        journeys[name + '/' + journey['journey']] = {
            'prior_verdict': 'PASS', 'present_executables_verified': present,
            'source_producer_removed_after_archival': journey['journey'] == 'source' and not present,
            'original_executables': journey['executables']}

proof = {
    'status': 'IDENTITY_VERIFIED_NOT_NEW_EXECUTION', 'baseline': BASE, 'candidate': CANDIDATE,
    'source_delta': non_docs, 'lock_delta': lock_delta, 'archives': archives,
    'default_features': default_features, 'native_artifacts': artifact_checks,
    'default_sdk_identity': packages, 'default_journeys': journeys,
    'reason': 'No public headers, common source, package/selector scripts, component graph or selected default dependency changed. Only Vulkan private implementation and its unused default-route patch/NOTICE hashes differ.',
    'still_required': ['current configure', 'affected Vulkan factor qualification', 'ggml source/MASM composition',
                       'component-contract for updated lock', 'current docs/closure', 'Vulkan-on actual new-operation deliveries'],
    'not_claimed': ['P1', 'CPU Q2 resume', 'C1 or model completion'],
}
(OUT / 'default-reuse-proof.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'native_artifacts': len(artifact_checks), 'sdk_manifests': len(packages), 'default_journeys': len(journeys), 'verdict': proof['status']}))
