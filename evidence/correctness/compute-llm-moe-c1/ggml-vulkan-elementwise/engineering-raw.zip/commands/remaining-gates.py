"""Complete Y35 selected gates with proved reuse; no unrelated producer rebuilds."""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path('C:/public/project-hyle/hyle')
TASK = Path(__file__).resolve().parent
BUILD = Path('C:/hyle-scratch/active-vk/static')
SCRATCH = Path('C:/hyle-scratch/active-vk/g35')
CANDIDATE = 'f58d26096dac635fe4ff23a141a0194d94faeebb'
CMAKE = 'C:/Program Files/CMake/bin/cmake.exe'
CTEST = 'C:/Program Files/CMake/bin/ctest.exe'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
ctypes.windll.kernel32.SetErrorMode(0x8003)
proof = json.loads((TASK / 'default-reuse-proof.json').read_text(encoding='utf-8'))
assert proof['status'] == 'IDENTITY_VERIFIED_NOT_NEW_EXECUTION' and proof['candidate'] == CANDIDATE
plan = json.loads((TASK / 'plan.json').read_text(encoding='utf-8'))
selected = {g['id']: g for g in plan['selected_gates']}
assert len(selected) == 112
OUT = TASK / 'remaining'
OUT.mkdir(exist_ok=False)
SCRATCH.mkdir(exist_ok=False)
shutil.copy2(BUILD / 'compile_commands.json', OUT / 'compile-commands-before.json')
shutil.copy2(BUILD / 'CMakeCache.txt', OUT / 'CMakeCache-before.txt')
prior = ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-reduction/engineering'
with zipfile.ZipFile(prior / 'selected-gates-raw.zip') as archive:
    old_commands = json.loads(archive.read('native/compile-commands-after.json'))
    old_gates = {g['id']: g for g in json.loads(archive.read('native/plan.json'))['selected_gates']}
    assert set(old_gates) == set(selected)
    for key in selected:
        if key != 'closure':
            assert old_gates[key]['commands'] == selected[key]['commands'], key

native_path = ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-elementwise/f2-windows-native.json'
native = json.loads(native_path.read_text(encoding='utf-8'))
assert native['status'] == 'PASS'
assert not subprocess.check_output(['git', 'diff', '--name-only', native['candidate'], CANDIDATE, '--', 'src', 'include', 'tests', 'third_party', 'cmake', 'CMakeLists.txt'], cwd=ROOT)
static = native['qualified']['static']
cpp = {row['label']: row for row in static['commands'] if 'tests' in row}
cpp['compute_provider_ggml_vulkan'] = static['reused_provider']
for name, row in cpp.items():
    assert sha(BUILD / 'bin' / ('hyle_' + name + '_test.exe')) == row['executable_sha256']
for name, digest in static['dlls'].items():
    assert sha(BUILD / 'bin' / name) == digest
gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,driver_version', '--format=csv,noheader'], text=True).strip()
assert gpu == 'GPU-e7376560-6f5d-ec19-6ee4-3dd3a2c81ef8, 610.62'
record = {'candidate': CANDIDATE, 'plan_sha256': sha(TASK / 'plan.json'),
          'reuse_proof_sha256': sha(TASK / 'default-reuse-proof.json'), 'gpu': gpu,
          'native_evidence': str(native_path.relative_to(ROOT)), 'native_evidence_sha256': sha(native_path),
          'status': 'RUNNING', 'gates': [], 'skipped_gates': plan['skipped_gates']}

def save():
    (OUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')

def run(gate, argv, suffix=''):
    log = OUT / (gate['id'].replace(':', '-') + suffix + '.log')
    start = time.monotonic()
    with log.open('wb') as output:
        output.write((json.dumps(argv) + '\n').encode())
        output.flush()
        result = subprocess.run(argv, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT,
                                creationflags=0x08000000, timeout=1800)
    command = {'argv': argv, 'exit_code': result.returncode, 'log': log.name,
               'sha256': sha(log), 'seconds': time.monotonic() - start}
    gate['commands'].append(command)
    save()
    if result.returncode:
        record['status'] = gate['status'] = 'FAIL'
        save()
        print(log.read_text(encoding='utf-8', errors='replace')[-6000:])
        raise SystemExit(result.returncode)

def command(template):
    result = []
    for part in template:
        for name, replacement in {'{python}': sys.executable, '{root}': str(ROOT), '{build}': str(BUILD), '{scratch}': str(SCRATCH)}.items():
            part = part.replace(name, replacement)
        result.append(part)
    if result[0] == 'cmake':
        result[0] = CMAKE
    if result[0] == 'ctest':
        result[0] = CTEST
    return result

def commands_by_identity(rows):
    return {(row['file'], row['output']): row['command'] for row in rows}

def check_configure():
    before = commands_by_identity(json.loads((OUT / 'compile-commands-before.json').read_text(encoding='utf-8')))
    after = commands_by_identity(json.loads((BUILD / 'compile_commands.json').read_text(encoding='utf-8')))
    changed_current = [key[0] for key, value in before.items() if after.get(key) != value]
    assert not changed_current, changed_current
    affected = ('compute_provider_ggml_vulkan', 'compute_route_vulkan', 'graph_route_vulkan')
    unchanged_previous = {key: value for key, value in commands_by_identity(old_commands).items()
                          if not any(name in key[0] for name in affected)}
    changed_previous = [key[0] for key, value in unchanged_previous.items() if after.get(key) != value]
    assert not changed_previous, changed_previous
    record['configure_identity'] = {'current_entries_unchanged': len(before),
                                    'unaffected_previous_entries_unchanged': len(unchanged_previous)}
    shutil.copy2(BUILD / 'compile_commands.json', OUT / 'compile-commands-after.json')
    shutil.copy2(BUILD / 'CMakeCache.txt', OUT / 'CMakeCache-after.txt')

save()
for key in ('docs', 'closure', 'configure', 'factor:compute_provider_ggml_vulkan', 'component-contract'):
    gate = {'id': key, 'status': 'RUNNING', 'commands': []}
    record['gates'].append(gate)
    print('START', key, flush=True)
    if key == 'configure':
        argv = command(selected[key]['commands'][0])
        argv.extend(['-DHYLE_COMPUTE_CPU=ON', '-DHYLE_STATIC=ON',
                     '-DCMAKE_TOOLCHAIN_FILE=' + str(ROOT / '.scratch/validation/vulkan-reduction/global/remaining-toolchain.cmake'),
                     '-DFETCHCONTENT_SOURCE_DIR_ONEDNN=' + str(ROOT / '.scratch/onednn-lock-v3.13.2/extract/oneDNN-71094df451909e95ceeefc8f64c275cdcbbcdff5'),
                     '-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=C:/public/project-hyle/ggml',
                     '-DVulkan_GLSLC_EXECUTABLE=C:/public/tools/hyle-vulkan/1.4.357.0/Bin/glslc.exe',
                     '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
        run(gate, argv)
        check_configure()
    elif key == 'factor:compute_provider_ggml_vulkan':
        gate['reused_cpp'] = cpp['compute_provider_ggml_vulkan']
        argv = command(selected[key]['commands'][1]) + ['-R', '^(hyle_ggml_vulkan_source_contract_test|hyle_ggml_vulkan_masm_composition_test)$']
        run(gate, argv)
        detail = BUILD / 'Testing/Temporary/LastTest.log'
        shutil.copy2(detail, OUT / 'provider-CTest.log')
        gate['ctest_detail'] = {'file': 'provider-CTest.log', 'sha256': sha(detail)}
    elif key == 'component-contract':
        # Same isolated-cache initialization used in Y34, before the contract gate.
        init = ROOT / '.scratch/validation/vulkan-reduction/global/initialize-contract-cache.cmake'
        text = init.read_text(encoding='utf-8').replace('active-vk/g34', 'active-vk/g35')
        (OUT / 'initialize-contract-cache.cmake').write_text(text, encoding='utf-8', newline='\n')
        run(gate, [CMAKE, '-P', str(OUT / 'initialize-contract-cache.cmake')], '-initialize')
        cached_archive = Path('C:/hyle-scratch/active-vk/g34/component/shared-source-cache/archives/highway-18e449b64259-b2ddaa056705.tar.gz')
        lock = json.loads((ROOT / 'cmake/HyleDependencyLock.json').read_text(encoding='utf-8'))
        highway = next(entry for entry in lock['dependencies'] if entry['name'] == 'highway')
        assert sha(cached_archive) == highway['archive']['sha256']
        staged_archive = SCRATCH / 'component/shared-source-cache/archives' / cached_archive.name
        staged_archive.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(cached_archive, staged_archive)
        assert sha(staged_archive) == highway['archive']['sha256']
        gate['locked_archive_reused'] = {'name': staged_archive.name, 'sha256': sha(staged_archive)}
        argv = command(selected[key]['commands'][0])
        argv[1:1] = ['-DHYLE_SMOKE_GENERATOR=Ninja']
        target = (SCRATCH / 'component/component-contract').resolve()
        target.relative_to(SCRATCH.resolve())
        run(gate, argv)
    else:
        for template in selected[key]['commands']:
            run(gate, command(template))
    gate['status'] = 'PASS'
    save()
    print('PASS', key, flush=True)

for key in selected:
    if any(g['id'] == key for g in record['gates']):
        continue
    gate = {'id': key, 'status': 'REUSED', 'commands': []}
    if key in ('factor:compute_route_vulkan', 'factor:graph_route_vulkan'):
        gate['evidence'] = record['native_evidence']
        gate['cpp'] = cpp[key.split(':', 1)[1]]
    else:
        gate['evidence'] = str((prior / 'selected-gates-result.json').relative_to(ROOT))
        gate['identity_proof'] = 'default-reuse-proof.json plus configure_identity'
    record['gates'].append(gate)
assert len(record['gates']) == len(selected)
record['status'] = 'PASS_WITH_DOCUMENTED_REUSE'
record['counts'] = {'selected': len(selected), 'executed': 5, 'reused': len(selected) - 5, 'skipped': len(plan['skipped_gates'])}
save()
print(json.dumps(record['counts']), flush=True)
