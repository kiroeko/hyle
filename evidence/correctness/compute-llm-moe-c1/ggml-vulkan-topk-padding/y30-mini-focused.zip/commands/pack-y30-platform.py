import hashlib,json,os,sys,zipfile
from pathlib import Path
root=Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
meta=json.loads((root/'y30-candidate.json').read_text())
platform=sys.argv[1]
assert platform in ('air','mini')
logs=root/('y30-'+meta['candidate'][:8])
report=json.loads((logs/'result.json').read_text())
assert report['verdict']=='PASS' and report['candidate']==meta['candidate']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path,digest in meta['verified_implementation_files'].items():
    assert sha(root/'source'/path)==digest,path
for artifact in report['artifacts']:
    assert sha(Path(artifact['path']))==artifact['sha256']
files={str(p.relative_to(logs)):p for p in logs.rglob('*') if p.is_file()}
files['commands/run-'+platform+'.py']=root/('run-y30-'+platform+'.py')
files['commands/pack-y30-platform.py']=Path(__file__)
files['identity/candidate.json']=root/'y30-candidate.json'
for p in logs.glob('*.log'):
    assert not any(x in p.read_text(errors='replace') for x in ('VUID-','Validation Error','SYNC-HAZARD'))
archive=root/('y30-'+platform+'-focused.zip')
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,path in files.items():z.write(path,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,path in files.items():
        assert hashlib.sha256(z.read(name)).hexdigest()==sha(path)
receipt={'candidate':meta['candidate'],'product_candidate':meta['product_candidate'],
         'platform':platform,'status':'PASS','result':report,'archive':archive.name,
         'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size}
(root/('y30-'+platform+'-focused.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'platform':platform,'candidate':meta['candidate'],'cases':sum(a['tests'] for a in report['artifacts']),
                  'archive_bytes':archive.stat().st_size,'archive_sha256':receipt['archive_sha256']}))
