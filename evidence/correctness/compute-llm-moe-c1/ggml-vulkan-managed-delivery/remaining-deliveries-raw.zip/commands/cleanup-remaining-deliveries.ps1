$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-vk\g')
$logRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-delivery'
$receipt = Get-Content -LiteralPath (Join-Path $logRoot 'remaining-deliveries-receipt.json') -Raw | ConvertFrom-Json
$expected = @('compute','graph','container','core','error','io','math','mem','obs','platform','process','sched','simd','time','util')
if ($receipt.status -ne 'PASS' -or $receipt.components.Count -ne $expected.Count -or
    @(Compare-Object $expected @($receipt.components.component)).Count -ne 0) {
  throw 'The exact remaining delivery set must pass before cleanup'
}
$archive = Join-Path $logRoot 'remaining-deliveries-raw.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.archive_sha256) {
  throw 'Evidence archive digest mismatch'
}
$targets = @()
foreach ($component in $receipt.components) {
  if ($component.journeys.Count -ne 3 -or @($component.journeys | Where-Object status -ne 'PASS').Count -ne 0) {
    throw 'Every component must retain all three completed consumer journeys'
  }
  $componentRoot = [IO.Path]::GetFullPath((Join-Path $taskRoot ('delivery-' + $component.component + '\selected-' + $component.component)))
  if (-not $componentRoot.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Component outside the dedicated task root'
  }
  foreach ($name in @('source-build','shared-sdk-build','static-sdk-build')) {
    $path = [IO.Path]::GetFullPath((Join-Path $componentRoot $name))
    if (-not $path.StartsWith($componentRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
      throw 'Build outside its component root'
    }
    $item = Get-Item -LiteralPath $path
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked build root refused' }
    if (@(Get-ChildItem -LiteralPath $path -Recurse -Directory -Attributes ReparsePoint).Count -ne 0) {
      throw 'Linked descendants refused'
    }
    $targets += $path
  }
}
# All 45 resolved targets have been checked before any recursive deletion.
$removed = @()
foreach ($path in $targets) {
  $bytes = (Get-ChildItem -LiteralPath $path -Recurse -File | Measure-Object Length -Sum).Sum
  Remove-Item -LiteralPath $path -Recurse -Force
  if (Test-Path -LiteralPath $path) { throw 'Cleanup did not finish' }
  $removed += [pscustomobject]@{ path = $path; logical_bytes = [long]$bytes }
}
$record = [pscustomobject]@{
  candidate = $receipt.candidate
  removed = $removed
  logical_bytes = [long](($removed | Measure-Object logical_bytes -Sum).Sum)
  retained = 'Verified evidence ZIP and receipts, relocated SDKs, independent consumers, all shared source caches'
}
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $logRoot 'remaining-deliveries-cleanup.json') -Encoding utf8
$record | Select-Object candidate,logical_bytes,retained | ConvertTo-Json
