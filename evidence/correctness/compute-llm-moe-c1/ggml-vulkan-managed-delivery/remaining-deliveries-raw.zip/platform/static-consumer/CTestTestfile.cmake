# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/platform/cpp
# Build directory: C:/hyle-scratch/active-vk/g/delivery-platform/selected-platform/static-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_platform_cpp" "C:/hyle-scratch/active-vk/g/delivery-platform/selected-platform/static-consumer/hyle_package_platform_cpp.exe")
set_tests_properties("hyle_package_platform_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/platform/cpp/CMakeLists.txt;11;add_test;C:/public/project-hyle/hyle/samples/package/platform/cpp/CMakeLists.txt;0;")
