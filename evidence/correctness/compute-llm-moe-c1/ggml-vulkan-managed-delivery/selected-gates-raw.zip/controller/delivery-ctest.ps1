$CtestArguments = @($args)
$ErrorActionPreference = 'Stop'
$index = [Array]::IndexOf($CtestArguments, '--test-dir')
if ($index -lt 0 -or $index + 1 -ge $CtestArguments.Length) {throw 'Explicit test directory is required'}
$testRoot = [IO.Path]::GetFullPath($CtestArguments[$index + 1])
$allowedRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-vk\g')
if (-not $testRoot.StartsWith($allowedRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Test root is outside the current delivery workspace'
}
$crt = Get-ChildItem -LiteralPath 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Redist\MSVC' -Directory |
  Where-Object {Test-Path -LiteralPath (Join-Path $_.FullName 'x64\Microsoft.VC145.CRT')} |
  Sort-Object Name -Descending | Select-Object -First 1
if (-not $crt) {throw 'Required x64 CRT not found'}
$crtFiles = @(Get-ChildItem -LiteralPath (Join-Path $crt.FullName 'x64\Microsoft.VC145.CRT') -File -Filter '*.dll')
$executables = @(Get-ChildItem -LiteralPath $testRoot -Recurse -File -Filter '*.exe')
foreach ($directory in @($executables.DirectoryName | Sort-Object -Unique)) {
  foreach ($dll in $crtFiles) {Copy-Item -LiteralPath $dll.FullName -Destination $directory -Force}
}
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleAaDeliveryErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleAaDeliveryErrorMode]::SetErrorMode(0x8003) | Out-Null
Write-Output ('C1-Y20 runtime staging: ' + $executables.Count + ' executables; CRT adjacent; PATH unset')
& 'C:\Program Files\CMake\bin\cmake.exe' -E env --unset=PATH 'C:\Program Files\CMake\bin\ctest.exe' @CtestArguments
exit $LASTEXITCODE
