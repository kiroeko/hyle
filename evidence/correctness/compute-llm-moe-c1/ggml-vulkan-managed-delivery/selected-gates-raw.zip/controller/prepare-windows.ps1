$ErrorActionPreference = 'Stop'
$repo = 'C:\public\project-hyle\hyle'
$logs = Join-Path $repo '.scratch\validation\vulkan-delivery'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
. (Join-Path $repo 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-vk\static' -ExtraArgs @('--target','hyle_source_package','--parallel','2') > (Join-Path $logs 'source-package.log') 2>&1
if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $logs 'source-package.log') -Tail 40; exit $LASTEXITCODE }
$archive = 'C:\hyle-scratch\active-vk\static\dist\hyle-0.1.0-source.zip'
$sha = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
& python (Join-Path $logs 'verify-delivery.py') --root 'C:\hyle-scratch\active-vk\d' --archive $archive --sha256 $sha
exit $LASTEXITCODE
