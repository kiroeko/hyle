from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path('C:/public/project-hyle/hyle')
BASE = ROOT / '.scratch/validation/vulkan-delivery'
CANDIDATE = '351ec13d82057402594a96fcc862bcdc96b2d839'
DEST = ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-managed-delivery'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
assert not subprocess.check_output(['git', 'diff', '--name-only', '3c39428e', CANDIDATE,
                                    '--', 'include', 'src', 'cmake', 'third_party'], cwd=ROOT)
groups = {}
gates = {}
files = {}
for group in ('native', 'contract', 'delivery'):
    directory = BASE / ('remaining-' + group)
    result = json.loads((directory / 'result.json').read_text())
    plan = json.loads((directory / 'plan.json').read_text())
    assert result['candidate'] == CANDIDATE and result['status'] == 'PASS'
    assert result['plan_sha256'] == sha(directory / 'plan.json')
    assert plan['candidate_commit'] == CANDIDATE and len(plan['selected_gates']) == 112
    for gate in result['gates']:
        assert gate['status'] == 'PASS' and gate['id'] not in gates
        for command in gate['commands']:
            assert command['exit_code'] == 0
            assert sha(directory / command['log']) == command['sha256']
            if 'ctest_detail' in command:
                detail = command['ctest_detail']
                assert sha(directory / detail['log']) == detail['sha256']
        gates[gate['id']] = gate
    groups[group] = {'gate_count': len(result['gates']), 'status': 'PASS'}
    for path in directory.iterdir():
        if path.is_file():
            files[group + '/' + path.name] = path
assert set(gates) == {gate['id'] for gate in plan['selected_gates']}
deliveries = json.loads((BASE / 'remaining-deliveries-receipt.json').read_text())
assert deliveries['status'] == 'PASS' and len(deliveries['components']) == 15
assert sha(BASE / deliveries['archive']) == deliveries['archive_sha256']
platforms = {}
for name in ('windows-raw', 'air-delivery-raw'):
    receipt = json.loads((BASE / (name + '.json')).read_text())
    archive = BASE / (name + '.zip')
    assert receipt['status'] == 'PASS' and receipt['executable_count'] == 6
    assert sha(archive) == receipt['sha256']
    with zipfile.ZipFile(archive) as contents:
        manifest = json.loads(contents.read('archive-manifest.json'))
        for entry, record in manifest.items():
            payload = contents.read(entry)
            assert hashlib.sha256(payload).hexdigest() == record['sha256']
    platforms[receipt['platform']] = receipt

DEST.mkdir(exist_ok=False)
for name in ('windows-raw.zip', 'windows-raw.json', 'air-delivery-raw.zip', 'air-delivery-raw.json',
             'remaining-deliveries-raw.zip', 'remaining-deliveries-receipt.json',
             'windows-cleanup.json', 'air-delivery-cleanup.json', 'remaining-deliveries-cleanup.json'):
    shutil.copy2(BASE / name, DEST / name)
loc = BASE / 'loc-head-351ec13d.json'
shutil.copy2(loc, DEST / 'loc.json')
for name in ('remaining-gates.py', 'remaining-gates.ps1', 'remaining-context.json',
             'remaining-toolchain.cmake', 'delivery-ctest.ps1', 'delivery-ctest.cmd',
             'prepare-windows.ps1', 'cleanup-windows.ps1', 'cleanup-air.py', 'finalize-evidence.py',
             'sample-selector.json', 'combined-selector.json', 'source-package.log',
             'seed-contract.ps1', 'contract-offline-seed.json'):
    files['controller/' + name] = BASE / name
for path in (BASE / 'remaining-contract-offline-seed-failure').iterdir():
    if path.is_file():
        files['first-contract-environment-failure/' + path.name] = path
files['CMakeCache.txt'] = Path('C:/hyle-scratch/active-vk/static/CMakeCache.txt')
contract_root = Path('C:/hyle-scratch/active-vk/g/component/component-contract')
for path in contract_root.rglob('LastTest.log'):
    files['component-test-details/' + path.relative_to(contract_root).as_posix()] = path
manifest = {name: {'sha256': sha(path), 'bytes': path.stat().st_size} for name, path in files.items()}
with zipfile.ZipFile(DEST / 'selected-gates-raw.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in files.items():
        archive.write(path, name)
    archive.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
result = {
    'scope': 'C1-Y4 managed Vulkan delivery and Y20 changed-lock selected validation; not complete C1 acceptance',
    'source_snapshot': CANDIDATE, 'product_candidate': '3c39428e3fdf1911b284f7632d891f663ad82f31',
    'source_archive_sha256': 'c0f003904c322a413aacdf1f77f98c22424e21743888dd1108635c92bd5fc603',
    'platforms': platforms, 'selected_gates': groups, 'total_selected_pass': len(gates),
    'unselected': [{'id': x['id'], 'reason': x['reason']} for x in plan.get('skipped_gates', [])],
    'archives': {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in DEST.glob('*.zip')},
    'loc': {'compute_graph': 46990, 'implementation_files': 193, 'tests_bench_vendor': 'excluded',
            'measured_commit': CANDIDATE,
            'measurement': 'uniform script run on the immutable source snapshot; self-check PASS'},
    'verdict': 'PASS for the named delivery and selected validation scopes',
    'c1_acceptance': 'INCONCLUSIVE',
    'uncompleted': ['remaining C1 provider capability bindings including Vulkan checked indexing/Scan/TopK',
                   'local 2B real-weight C1 pieces', 'remaining C1 route/platform/delivery qualification',
                   'fixed performance preferences and replaced implementation retirement'],
    'cpu_onednn_performance': 'BLOCKED unchanged; this run contains no P1',
    'initial_environment_failure': 'The first component-contract run lacked the locked Highway archive in its new isolated disconnected cache. Preserved the failure, copied the already verified existing archive, reran only this gate. No product or public tool change.',
}
(DEST / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'destination': str(DEST), 'gates': len(gates), 'status': 'PASS'}, indent=2))
