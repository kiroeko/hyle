from pathlib import Path
import hashlib
import json
import shutil

base = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
root = (base / 'd').resolve()
receipt = json.loads((base / 'air-delivery-raw.json').read_text())
assert receipt['status'] == 'PASS' and receipt['executable_count'] == 6
assert hashlib.sha256((base / 'air-delivery-raw.zip').read_bytes()).hexdigest() == receipt['sha256']
targets = [root / name for name in ('bs-hidden', 'bd-hidden', 'complete-source-hidden')]
for path in targets:
    assert path.is_dir() and not path.is_symlink()
    assert path.resolve().parent == root
removed = []
for path in targets:
    size = sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(path)
    assert not path.exists()
    removed.append({'path': str(path), 'logical_bytes': size})
record = {'snapshot': receipt['snapshot'], 'removed': removed,
          'logical_bytes': sum(x['logical_bytes'] for x in removed),
          'retained': 'Verified evidence already received on Windows, logs, relocated SDKs, installed consumers, original source archive, dependency/model caches'}
(base / 'air-delivery-cleanup.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
