$ErrorActionPreference = 'Stop'
$logs = [IO.Path]::GetFullPath('C:\public\project-hyle\hyle\.scratch\validation\vulkan-delivery')
$failed = [IO.Path]::GetFullPath((Join-Path $logs 'remaining-contract'))
$saved = [IO.Path]::GetFullPath((Join-Path $logs 'remaining-contract-offline-seed-failure'))
if (-not $failed.StartsWith($logs + '\') -or -not $saved.StartsWith($logs + '\') -or (Test-Path -LiteralPath $saved)) { throw 'Invalid failure archive paths' }
$result = Get-Content -LiteralPath (Join-Path $failed 'result.json') -Raw | ConvertFrom-Json
if ($result.status -ne 'INCONCLUSIVE' -or $result.gates[0].status -ne 'FAIL') { throw 'Expected preserved failed gate' }
Move-Item -LiteralPath $failed -Destination $saved
$cache = 'C:\hyle-scratch\active-vk\g\component\shared-source-cache\archives'
[IO.Directory]::CreateDirectory($cache) | Out-Null
$source = 'C:\public\tools\hyle-dependencies\v1\archives\highway-18e449b64259-b2ddaa056705.tar.gz'
$target = Join-Path $cache 'highway-18e449b64259-b2ddaa056705.tar.gz'
$expected = '718bf1a26f7c074f04e499033166c9e3f415f9b165a390a8b021adac6e0016c0'
if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected -or (Test-Path -LiteralPath $target)) { throw 'Unexpected archive state' }
Copy-Item -LiteralPath $source -Destination $target
if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw 'Archive copy mismatch' }
[pscustomobject]@{source=$source; destination=$target; sha256=$expected; bytes=(Get-Item -LiteralPath $target).Length; purpose='Seed the original isolated offline fixture with the existing locked archive. No network, product, version, or gate change.'} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $logs 'contract-offline-seed.json') -Encoding utf8
