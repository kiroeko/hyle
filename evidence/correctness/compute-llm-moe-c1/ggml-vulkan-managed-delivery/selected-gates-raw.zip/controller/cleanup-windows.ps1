$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-vk\d')
$logs = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-delivery'
$receipt = Get-Content -LiteralPath (Join-Path $logs 'windows-raw.json') -Raw | ConvertFrom-Json
if ($receipt.status -ne 'PASS' -or $receipt.executable_count -ne 6) { throw 'Completed six-consumer receipt required' }
$archive = Join-Path $logs 'windows-raw.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.sha256) { throw 'Evidence archive mismatch' }
$targets = @()
foreach ($name in @('bs-hidden','bd-hidden','complete-source-hidden')) {
    $target = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath (Join-Path $taskRoot $name)).Path)
    if (-not $target.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup target outside dedicated workspace' }
    if ((Get-Item -LiteralPath $target).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Refuse linked target' }
    if (@(Get-ChildItem -LiteralPath $target -Recurse -Directory -Attributes ReparsePoint).Count) { throw 'Refuse linked descendants' }
    $targets += $target
}
$removed = @()
foreach ($target in $targets) {
    $bytes = (Get-ChildItem -LiteralPath $target -Recurse -File | Measure-Object Length -Sum).Sum
    Remove-Item -LiteralPath $target -Recurse -Force
    if (Test-Path -LiteralPath $target) { throw 'Cleanup incomplete' }
    $removed += [pscustomobject]@{path=$target; logical_bytes=[long]$bytes}
}
$result = [pscustomobject]@{
    candidate=$receipt.snapshot; removed=$removed
    logical_bytes=[long](($removed | Measure-Object logical_bytes -Sum).Sum)
    retained='Verified evidence, logs, two relocated SDKs, six consumer identities, installed consumers, original source archive and all dependency/model caches'
}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $logs 'windows-cleanup.json') -Encoding utf8
$result | Select-Object candidate,logical_bytes,retained | ConvertTo-Json
