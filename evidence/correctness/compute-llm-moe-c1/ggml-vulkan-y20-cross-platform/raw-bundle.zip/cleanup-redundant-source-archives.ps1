$ErrorActionPreference = 'Stop'
$archiveRoot = (Resolve-Path -LiteralPath 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-pointwise').Path
if ($archiveRoot -ne 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-pointwise') { throw 'Unexpected archive root' }
$knownArchives = @{
    'source.tar.gz' = '01d4ec3852273a23d0219e0c957f5532c8cc8bb0502607deef2bd5f39e8a2e00'
    'source-fixture.tar.gz' = '4fa5f0e52db15ab8251325ad7bafc347c18b67b0f828476f3687d871619c4ec4'
    'source-current.tar.gz' = 'b630acdeaa295685a345fa895dfd3cc167760de9e5d3db90b03a5471fa10c566'
    'source-final.tar.gz' = 'b81ceb3a6283a1f8583b1cc26455d316d51ac9ed2f1fc6bf6c5127fc2f0f7d3e'
}
$targets = foreach ($entry in $knownArchives.GetEnumerator()) {
    $path = Join-Path $archiveRoot $entry.Key
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Expected a regular archive file' }
    $resolved = (Resolve-Path -LiteralPath $path).Path
    if ([IO.Path]::GetDirectoryName($resolved) -ne $archiveRoot) { throw 'Archive escaped the validation directory' }
    $actual = (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $entry.Value) { throw ('Archive identity changed: ' + $resolved) }
    [PSCustomObject]@{ Path = $resolved; Bytes = $item.Length; Sha256 = $actual; Deleted = $false }
}
$receipt = Join-Path $archiveRoot 'archive-cleanup.json'
$targets | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $receipt
foreach ($target in $targets) {
    Remove-Item -LiteralPath $target.Path
    $target.Deleted = -not (Test-Path -LiteralPath $target.Path)
    $targets | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $receipt
}
$targets | Select-Object Path,Bytes,Deleted
