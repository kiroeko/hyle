from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('C:/public/project-hyle/hyle')
LOGS = ROOT / '.scratch/validation/vulkan-pointwise'
DEST = ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-y20-cross-platform'
CANDIDATE = '3c39428e3fdf1911b284f7632d891f663ad82f31'
TREE = '43ae3b6ff6cd064fb928d5978f36edbca1278c99'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git','diff','HEAD','--','src','include','cmake','third_party','tests'],cwd=ROOT)
verifications = []
artifacts = []
for environment, counts, ctests, validation in (
    ('static', [19,40,17], 2, 'PASS'), ('shared', [19,40,16], 2, 'PASS'),
    ('air-y20', [19,40,17], 1, 'PASS'), ('mini-y20', [18,40,17], 1, 'not installed; dedicated case covered by W1 and Air')):
    is_windows = environment in ('static','shared')
    directory = LOGS / ('y20-w1' if is_windows else environment)
    prefix = environment + '-' if is_windows else ''
    if not is_windows:
        receipt = read(directory / 'result.json')
        assert receipt['candidate'] == CANDIDATE and receipt['tree'] == TREE and receipt['verdict'] == 'PASS'
        artifacts.extend(receipt['artifacts'])
    for suite,count in zip(('compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan'),counts):
        report = read(directory / (prefix+suite+'.json'))
        assert report['tests'] == count and report['failures'] == report['errors'] == report['disabled'] == 0
        assert all(t['status']=='RUN' and t['result']=='COMPLETED' for group in report['testsuites'] for t in group['testsuite'])
        raw = (directory / (prefix+suite+'.log')).read_text(encoding='utf-8-sig',errors='replace')
        assert not any(marker in raw for marker in ('VUID-','Validation Error','SYNC-HAZARD'))
        verifications.append({'environment':environment,'suite':suite,'cases':count,'runtime_skips':0,'correctness':'PASS','validation':validation})
        if is_windows:
            artifact = Path('C:/hyle-scratch/active-vk') / environment / 'bin' / ('hyle_'+suite+'_test.exe')
            artifacts.append({'path':str(artifact),'bytes':artifact.stat().st_size,'sha256':sha(artifact)})
    xml = ET.parse(directory / (prefix+'ctest.xml')).getroot()
    assert int(xml.get('tests')) == ctests and int(xml.get('failures')) == int(xml.get('skipped')) == 0
    verifications.append({'environment':environment,'ctest_entries':ctests,'verdict':'PASS'})
    if is_windows:
        build = Path('C:/hyle-scratch/active-vk') / environment
        (directory / (environment+'-CMakeCache.txt')).write_bytes((build/'CMakeCache.txt').read_bytes())
        for artifact in (build/'bin').glob('*.dll'):
            artifacts.append({'path':str(artifact),'bytes':artifact.stat().st_size,'sha256':sha(artifact)})
loc = read(LOGS/'loc-current.json')
subprocess.run(['git','diff','--exit-code',loc['repository']['commit'],CANDIDATE,'--',*loc['module']['paths']],cwd=ROOT,check=True)
selector = read(LOGS/'y20-immutable-selector.json')
assert selector['candidate_commit'] == CANDIDATE and selector['verdict'] == 'READY'
files = {}
for name in ('y20-w1','air-y20','mini-y20'):
    for path in (LOGS/name).iterdir():
        if path.is_file(): files[path.relative_to(LOGS).as_posix()] = path
for name in ('run-air-y20.py','run-mini-y20.py','y20-w1-run.ps1','y20-candidate.json',
             'air-y20-run.log','mini-y20-run.log','y20-immutable-selector.json','record-y20.py',
             'cleanup-redundant-source-archives.ps1','archive-cleanup.json'):
    files[name] = LOGS/name
DEST.mkdir(exist_ok=True)
archive = DEST/'raw-bundle.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as out:
    for name,path in sorted(files.items()): out.write(path,name)
with zipfile.ZipFile(archive) as saved: assert saved.testzip() is None
result = {
    'candidate':CANDIDATE,'tree':TREE,'scope':'Y17-Y20 focused native provider/direct/graph portability and lifecycle validation',
    'focused_correctness':'PASS','closure':'INCONCLUSIVE',
    'regression':'Air previously emitted 87 VUID 04451 messages; same real suites now emit zero validation diagnostics',
    'verifications':verifications,'artifacts':artifacts,
    'mini_exclusion':{'case':'GgmlVulkanNative.ExplicitValidationUsesItsOwnInstance','reason':'validation layer absent; actual explicit validation executed on W1 and Air'},
    'shared_exclusion':'Existing static-only global-new allocation failure fixture is not compiled in shared Graph tests',
    'windows_dll_policy':'HYLE and CRT DLLs adjacent to EXE; PATH unset; popup error mode; no UAC or power changes',
    'concurrency':'All heavy builds and runtime checks serial by environment; compile parallelism 2',
    'remaining_applicable_gates':{'selected_global_package':'BLOCKED / not yet run on this candidate','real_weight_fragments':'BLOCKED / not yet run','full_three_cpp_deliveries':'BLOCKED / not yet run','qualified_performance_and_rules':'BLOCKED / not yet run'},
    'selector':{'selected':len(selector['selected_gates']),'skipped':len(selector['skipped_gates']),'note':'Focused checks above are not the complete 112 selected global gates; no earlier broad verdict is inherited'},
    'loc':{'report':'../ggml-vulkan-macos-portability/loc.json','counted_commit':loc['repository']['commit'],'implementation_paths_identical_at_candidate':True,'lines':46990,'files':193,'self_check':loc['self_check']},
    'cleanup':{'bytes_removed':sum(x['Bytes'] for x in read(LOGS/'archive-cleanup.json')),'all_verified':all(x['Deleted'] for x in read(LOGS/'archive-cleanup.json'))},
    'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},
    'files':[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(files.items())]}
(DEST/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'correctness':result['focused_correctness'],'closure':result['closure'],'archive':result['archive'],'cleanup':result['cleanup']}))
