[CmdletBinding()]
param(
    [ValidateSet('static','shared')][string]$Linkage = 'static',
    [ValidateSet('Configure','Build','Test')][string]$Action = 'Configure'
)
$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\public\project-hyle\hyle'
$buildRoot = Join-Path 'C:\hyle-scratch\active-vk' $Linkage
$logRoot = Join-Path $sourceRoot '.scratch\validation\vulkan-pointwise\y20-w1'
[IO.Directory]::CreateDirectory($logRoot) | Out-Null
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:TRACY_ONLY_LOCALHOST = '1'
$wrapper = Join-Path $sourceRoot 'scripts\hyle-windows.ps1'
$log = Join-Path $logRoot ($Linkage + '-' + $Action.ToLowerInvariant() + '.log')
if ($Action -eq 'Configure') {
    $options = @(
        '-DCMAKE_BUILD_TYPE=Release', '-DHYLE_WERROR=ON', '-DHYLE_INSTALL=OFF',
        '-DHYLE_BUILD_TESTS=ON', '-DHYLE_BUILD_BENCH=OFF',
        '-DHYLE_TEST_INSTRUMENTATION=OFF', '-DHYLE_TRACE=OFF', '-DHYLE_SANITIZER=off',
        '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_ONEDNN=OFF',
        '-DHYLE_COMPUTE_CUDA=OFF', '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_COMPUTE_VULKAN=ON',
        '-DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe',
        '-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=C:/public/project-hyle/ggml',
        '-DCMAKE_PREFIX_PATH=C:/public/tools/hyle-vulkan/1.4.357.0',
        ('-DHYLE_STATIC=' + $(if ($Linkage -eq 'static') { 'ON' } else { 'OFF' }))
    )
    & $wrapper -Action Configure -BinaryDir $buildRoot -Factor 'compute_provider_ggml_vulkan;compute_route_vulkan;graph_route_vulkan' -ExtraArgs $options > $log 2>&1
} elseif ($Action -eq 'Build') {
    & $wrapper -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','hyle_compute_provider_ggml_vulkan_test','hyle_compute_route_vulkan_test','hyle_graph_route_vulkan_test') > $log 2>&1
} else {
    $env:VK_LAYER_PATH = Join-Path $env:VULKAN_SDK 'Bin'
    $env:VK_INSTANCE_LAYERS = 'VK_LAYER_KHRONOS_validation'
    $env:HYLE_TEST_VULKAN_VALIDATE = '1'
    $env:HYLE_VULKAN_VALIDATION = '1'
    $bin = Join-Path $buildRoot 'bin'
    $crt = Get-ChildItem -LiteralPath 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Redist\MSVC' -Directory |
        Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'x64\Microsoft.VC145.CRT') } |
        Sort-Object Name -Descending | Select-Object -First 1
    if (-not $crt) { throw 'Selected MSVC redistributable CRT not found' }
    Get-ChildItem -LiteralPath (Join-Path $crt.FullName 'x64\Microsoft.VC145.CRT') -Filter '*.dll' -File |
        Copy-Item -Destination $bin -Force
    Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleTestErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
    [HyleTestErrorMode]::SetErrorMode(0x8003) | Out-Null
    $failed = $false
    foreach ($suite in @('compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan')) {
        $output = Join-Path $logRoot ($Linkage+'-'+$suite)
        & 'C:\Program Files\CMake\bin\cmake.exe' -E env --unset=PATH (Join-Path $bin ('hyle_'+$suite+'_test.exe')) ('--gtest_output=json:'+$output+'.json') > ($output+'.log') 2>&1
        if ($LASTEXITCODE -ne 0) { $failed = $true }
        Get-Content -LiteralPath ($output+'.log') -Tail 16
    }
    & $wrapper -Action Test -BinaryDir $buildRoot -ExtraArgs @('--output-on-failure','--parallel','1','-R','(ggml_vulkan_source_contract|ggml_vulkan_masm_composition)','--output-junit',(Join-Path $logRoot ($Linkage+'-ctest.xml'))) > $log 2>&1
    if ($LASTEXITCODE -ne 0) { $failed = $true }
    Get-Content -LiteralPath $log -Tail 20
    exit $(if ($failed) { 1 } else { 0 })
}
$result = $LASTEXITCODE
Get-Content -LiteralPath $log -Tail 32
exit $result
