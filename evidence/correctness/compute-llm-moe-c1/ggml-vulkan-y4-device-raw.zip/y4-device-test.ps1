param([ValidateSet('static','shared')][string]$Mode='static')
$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$testRoot='C:/hyle-scratch/vk-y2'
$env:VK_LAYER_PATH='C:/hyle-scratch/r6-vulkan-20260917/tools/validation-1.4.357.0'
$env:VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation'
$env:HYLE_TEST_VULKAN_VALIDATE='1'
$env:HYLE_VULKAN_VALIDATION='1'
$env:TRACY_ONLY_LOCALHOST='1'
$cmakePath=(Get-Command cmake).Source
& git -C C:/public/project-hyle/hyle rev-parse HEAD
& $cmakePath --build "$testRoot/$Mode" --target hyle_compute_provider_ggml_vulkan_test hyle_compute_route_vulkan_test hyle_graph_route_vulkan_test --parallel 2 *> "$testRoot/y4-device-immutable-build-$Mode.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$testRoot/y4-device-immutable-build-$Mode.log" -Tail 35; exit $LASTEXITCODE }
foreach ($factor in @('compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan')) {
  & $cmakePath -E env --unset=PATH "$testRoot/$Mode/bin/hyle_${factor}_test.exe" "--gtest_output=json:$testRoot/y4-device-$factor-$Mode.json" *> "$testRoot/y4-device-$factor-$Mode.log"
  $result=$LASTEXITCODE
  Get-Content "$testRoot/y4-device-$factor-$Mode.log" -Tail 12
  if ($result -ne 0) { exit $result }
}
& ctest --test-dir "$testRoot/$Mode" --output-on-failure --parallel 1 -R '^hyle_((compute_route_vulkan|graph_route_vulkan)_header_self_contained|ggml_vulkan_source_contract)_test$' *> "$testRoot/y4-device-headers-source-$Mode.log"
$result=$LASTEXITCODE
Get-Content "$testRoot/y4-device-headers-source-$Mode.log" -Tail 20
exit $result
