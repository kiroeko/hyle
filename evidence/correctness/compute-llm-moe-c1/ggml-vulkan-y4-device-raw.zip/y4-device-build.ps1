param([ValidateSet('static','shared')][string]$Mode='static')
$ErrorActionPreference='Stop'
$isStatic = if ($Mode -eq 'static') { 'ON' } else { 'OFF' }
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL='2'
$env:VULKAN_SDK='C:/hyle-scratch/ggml-vulkan-region-20260918/sdk'
$env:PATH="$env:VULKAN_SDK/Bin;$env:PATH"
$env:TRACY_ONLY_LOCALHOST='1'
$ggmlY2Root='C:/hyle-scratch/vk-y2'
New-Item -ItemType Directory -Path $ggmlY2Root -Force | Out-Null
& cmake -S C:/public/project-hyle/hyle -B "$ggmlY2Root/$Mode" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DHYLE_STATIC=$isStatic" -DHYLE_INSTALL=OFF -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF '-DHYLE_DEV_FACTORS=compute_provider_ggml_vulkan;compute_route_vulkan;graph_route_vulkan' -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=ON -DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe -DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=C:/hyle-scratch/ggml-vulkan-region-20260918/upstream-clean "-DCMAKE_PREFIX_PATH=$env:VULKAN_SDK" *> "$ggmlY2Root/y4-device-configure-$Mode.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY2Root/y4-device-configure-$Mode.log" -Tail 45; exit $LASTEXITCODE }
& cmake --build "$ggmlY2Root/$Mode" --target hyle_compute_provider_ggml_vulkan_test hyle_compute_route_vulkan_test hyle_graph_route_vulkan_test --parallel 2 *> "$ggmlY2Root/y4-device-build-$Mode.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY2Root/y4-device-build-$Mode.log" -Tail 55; exit $LASTEXITCODE }
Write-Output "Y4 $Mode build completed"
