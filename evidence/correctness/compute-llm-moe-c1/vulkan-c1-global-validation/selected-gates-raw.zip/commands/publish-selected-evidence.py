"""Publish Y32 only after the fixed candidate's selected gates all pass."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
TASK = Path(__file__).resolve().parent
CANDIDATE = 'c733aa93a8c19e1e9d5747ee54c292db6075c5a1'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
selected = read(TASK / 'selected-gates-result.json')
delivery = read(TASK / 'remaining-deliveries-receipt.json')
cleanup = read(TASK / 'remaining-deliveries-cleanup.json')
assert selected['status'] == delivery['status'] == 'PASS'
assert selected['candidate'] == delivery['candidate'] == cleanup['candidate'] == CANDIDATE
assert selected['selected_gate_count'] == len(selected['gates']) == 112
assert all(g['status'] == 'PASS' for g in selected['gates'])
assert len(delivery['components']) == 15
assert sum(len(c['journeys']) for c in delivery['components']) == 45
assert len(cleanup['removed']) == 45
for archive, digest in [(TASK / selected['archive']['path'], selected['archive']['sha256']),
                        (TASK / delivery['archive'], delivery['archive_sha256'])]:
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == digest
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None

loc_arguments = ['python', 'scripts/loc-report.py', '--module', 'compute-graph-all',
                 '--json', '--self-check', '--module-path', 'include/hyle/compute',
                 '--module-path', 'include/hyle/graph']
for directory in sorted((ROOT / 'src').iterdir()):
    if directory.is_dir() and (directory.name in ('compute', 'graph')
            or directory.name.startswith(('compute_', 'graph_'))):
        loc_arguments.extend(['--module-path', directory.relative_to(ROOT).as_posix()])
loc_raw = subprocess.check_output(loc_arguments, cwd=ROOT)
loc = json.loads(loc_raw)
module_loc = next(metric for metric in loc['metrics'] if metric['id'] == 'module')
assert module_loc['code'] == 48294 and module_loc['files'] == 195
assert loc['repository']['commit'] == CANDIDATE and not loc['repository']['dirty']

destination = ROOT / 'evidence/correctness/compute-llm-moe-c1/vulkan-c1-global-validation'
assert not destination.exists()
destination.mkdir()
for name in ('selected-gates-result.json', 'selected-gates-raw.zip',
             'remaining-deliveries-receipt.json', 'remaining-deliveries-raw.zip'):
    shutil.copyfile(TASK / name, destination / name)
write(destination / 'remaining-deliveries-cleanup.json',
      json.dumps(cleanup, ensure_ascii=False, indent=2) + '\n')
write(destination / 'all-implementation-loc.json', loc_raw.decode('utf-8').replace('\r\n', '\n'))

removed = int(cleanup['logical_bytes'])
write(destination / 'README.md', f'''# C1-Y32 Windows 所选工程验收

不可变候选 `{CANDIDATE}`；selector 产品 baseline 为
`{selected['baseline']}`。Vulkan 产品仍为 `55fe0b8a` 的实现，
Y31 的真实 BF16 状态片段及 Windows/Air 六交付不重复运行。

[执行结果](selected-gates-result.json)与[原始证据](selected-gates-raw.zip)保留全部所选命令、
原始输出、退出码、CTest 明细、工具链/离线来源及 hash：96 项 maintenance/configure/
原生 correctness/headers、1 项 component-contract、15 项默认产品交付，共112项 PASS；
未选项及理由原样保留。Windows 的 Apple OFF 公开头不能代签 Apple runtime。

[交付收据](remaining-deliveries-receipt.json)与[交付原记录](remaining-deliveries-raw.zip)证明
15 个组件各有 source/static/shared 三条真实消费，共45条；包括安装重定位、独立消费者、
包卫生检查，其中 header-only 项签接口包消费。重型步骤串行、并行度2；Windows
HYLE/vendor/CRT DLL 邻置、PATH 隔离、禁错误弹窗。本组默认交付证明包可消费，
不替代各路线算子或模型的数值验收。

component-contract 首次失败来自本轮离线夹具：在未初始化的空 cache 中先放了锁定 archive，
产品正确拒绝非空且无标记的 cache。原失败保留；改用现有 HYLE 初始化函数准备空 cache，
再放同一锁定 archive，仅该门重跑一次通过。产品及公共工具均未改，96 项原生门没有重复运行。

[清理收据](remaining-deliveries-cleanup.json)记录归档核验后删除45个重复 producer 目录，
释放 {removed:,} 逻辑字节；保留重定位 SDK、独立消费者、共享来源 cache 和证据。
[统一实现 LOC](all-implementation-loc.json)覆盖全部 Compute/Graph include 和 src 组件，
排除 tests/bench/vendor，使用统一脚本并自检。

本节没有 P1、默认性能赢家或自有实现淘汰裁决；CPU oneDNN Q2 资格仍 BLOCKED。
四路线完整成本优选、C1 整包与64行/256格矩阵仍未签收，C1 完成通知尚未触发。
''')

card = ROOT / 'docs/implementation/tasks/compute/llm-moe-c1-tensor-state.md'
text = card.read_text(encoding='utf-8')
heading = '#### Y32 固定候选裁决'
assert heading not in text
write(card, text.rstrip() + f'''

{heading}

固定候选`c733aa93`的[Windows所选工程验收](../../../../evidence/correctness/compute-llm-moe-c1/vulkan-c1-global-validation/README.md)
112项全部通过：96项maintenance/configure/原生correctness/headers、1项component-contract、
15项默认产品三交付，共45条真实source/static/shared消费。原生批次不重复，Y31真实BF16
片段和Air/Mini同产品证据保留；本节没有产品改动、P1或新Provider接入。

component-contract首次离线夹具在cache初始化前放置archive，被产品正确拒绝；保留失败后
使用现有cache初始化函数纠正夹具，仅该门重跑一次通过。没有更改公共工具或产品合同。
全部重型步骤串行、并行度2，DLL邻置、PATH隔离、禁错误弹窗。

原始证据与SDK hash核验后删除45个重复producer目录，释放{removed:,}逻辑字节；保留SDK、
独立消费者、当前缓存和归档。统一实现LOC仍为48,294行/195文件，不含测试/bench/第三方。

Y32工程门停止重复；四路线完整成本资格、固定优选与自有实现取舍仍待完成，CPU Q2的
BLOCKED没有解除。矩阵与C1整包尚未签收；完成全部C1适用验收后再通知用户，在C2前等待提问。
''')

registry_path = ROOT / 'docs/implementation/module-status.json'
registry = read(registry_path)
owners = {'compute_route_vulkan', 'graph_route_vulkan', 'compute_provider_ggml_vulkan'}
for module in registry['modules']:
    if module['module'] in owners:
        assert module['state'] == 'AUDITED'
        module['summary'] = ('LLM/MoE C1-Y32 AUDITED：55fe0b8a产品不变；Y31 Windows/Air真实BF16状态六交付通过，'
                             'c733aa93的112项Windows工程门及45条默认三交付通过，原始夹具失败保留并纠正。'
                             '本组停止重复；完整成本优选/淘汰与C1整包未签收，CPU Q2资格BLOCKED保持。')
assert len([m for m in registry['modules'] if m['module'] in owners]) == 3
write(registry_path, json.dumps(registry, ensure_ascii=False, indent=2) + '\n')

cpu_task = ROOT / '.scratch/validation/onednn-aa/q2'
cpu_cleanup = read(cpu_task / 'terminal-build-cleanup.json')
cpu_artifact = Path(cpu_cleanup['artifacts'])
assert not Path(cpu_cleanup['removed']).exists()
assert hashlib.sha256(cpu_artifact.read_bytes()).hexdigest() == cpu_cleanup['artifacts_sha256']
cpu_evidence = ROOT / 'evidence/performance/onednn-normalization-aa-q2'
write(cpu_evidence / 'terminal-build-cleanup.json',
      json.dumps(cpu_cleanup, ensure_ascii=False, indent=2) + '\n')
cpu_readme = cpu_evidence / 'README.md'
text = cpu_readme.read_text(encoding='utf-8')
assert '## 终局构建清理' not in text
write(cpu_readme, text.rstrip() + '''

## 终局构建清理

[清理收据](terminal-build-cleanup.json)记录删除已终止的`active-cpu/p1`，共708个文件、
1,594,507,663逻辑字节。失败实验原始记录已提交；14个实际EXE/CRT/status制品按hash保留在
收据指向的本机任务ZIP（未作为产品提交），与失败候选身份相符。没有重建或重跑任何计时；
该清理不改变资格FAIL、产品性能INCONCLUSIVE和两个owner的BLOCKED。
''')
print(json.dumps({'published': destination.relative_to(ROOT).as_posix(),
                  'selected_gates': 112, 'journeys': 45,
                  'producer_bytes_removed': removed}, ensure_ascii=False))
