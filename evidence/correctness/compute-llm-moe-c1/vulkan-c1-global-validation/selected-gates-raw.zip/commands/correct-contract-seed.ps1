$ErrorActionPreference = 'Stop'
$logRoot = (Resolve-Path -LiteralPath 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-c1-final').Path
$taskRoot = (Resolve-Path -LiteralPath 'C:\hyle-scratch\active-vk\g32\component').Path
$moves = @(
    @((Join-Path $logRoot 'remaining-contract'), (Join-Path $logRoot 'remaining-contract-unmarked-seed-failure')),
    @((Join-Path $taskRoot 'shared-source-cache'), (Join-Path $taskRoot 'unmarked-cache-seed-failure'))
)
foreach ($move in $moves) {
    $from = (Resolve-Path -LiteralPath $move[0]).Path
    $to = [IO.Path]::GetFullPath($move[1])
    $parent = Split-Path -Parent $from
    if ($parent -notin @($logRoot, $taskRoot) -or (Split-Path -Parent $to) -cne $parent -or (Test-Path -LiteralPath $to)) { throw 'Unexpected preservation boundary' }
    foreach ($boundary in @($from, $parent)) {
        if ((Get-Item -LiteralPath $boundary -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked preservation boundary' }
    }
    if (@(Get-ChildItem -LiteralPath $from -Force -Recurse | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw 'Linked descendant' }
}
$failed = Get-Content -LiteralPath (Join-Path $moves[0][0] 'result.json') -Raw | ConvertFrom-Json
if ($failed.status -ne 'INCONCLUSIVE' -or $failed.gates[0].status -ne 'FAIL') { throw 'Expected original fixture failure' }
$cacheFiles = @(Get-ChildItem -LiteralPath $moves[1][0] -Recurse -Force -File)
if ($cacheFiles.Count -ne 1 -or $cacheFiles[0].Name -cne 'highway-18e449b64259-b2ddaa056705.tar.gz') { throw 'Unexpected unmarked cache contents' }
$expected = '718bf1a26f7c074f04e499033166c9e3f415f9b165a390a8b021adac6e0016c0'
if ((Get-FileHash -LiteralPath $cacheFiles[0].FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw 'Archive drift' }
foreach ($move in $moves) { Move-Item -LiteralPath $move[0] -Destination $move[1] }
& 'C:\Program Files\CMake\bin\cmake.exe' -P (Join-Path $logRoot 'initialize-contract-cache.cmake') > (Join-Path $logRoot 'initialize-contract-cache.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$source = Join-Path $moves[1][1] 'archives\highway-18e449b64259-b2ddaa056705.tar.gz'
$destination = Join-Path $moves[1][0] 'archives\highway-18e449b64259-b2ddaa056705.tar.gz'
if (Test-Path -LiteralPath $destination) { throw 'Initialized cache unexpectedly contains archive' }
Copy-Item -LiteralPath $source -Destination $destination
if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw 'Archive copy drift' }
Write-Output 'Preserved original failure; initialized empty fixture cache with existing HYLE mechanism; restaged exact locked archive.'
