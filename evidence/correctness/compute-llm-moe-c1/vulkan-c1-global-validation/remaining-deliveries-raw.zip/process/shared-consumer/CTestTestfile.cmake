# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/process/cpp
# Build directory: C:/hyle-scratch/active-vk/g32/delivery-process/selected-process/shared-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_process_cpp" "C:/hyle-scratch/active-vk/g32/delivery-process/selected-process/shared-consumer/hyle_package_process_cpp.exe")
set_tests_properties("hyle_package_process_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/process/cpp/CMakeLists.txt;12;add_test;C:/public/project-hyle/hyle/samples/package/process/cpp/CMakeLists.txt;0;")
