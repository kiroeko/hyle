# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/math/cpp
# Build directory: C:/hyle-scratch/active-vk/g32/delivery-math/selected-math/shared-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_math_cpp" "C:/hyle-scratch/active-vk/g32/delivery-math/selected-math/shared-consumer/hyle_package_math_cpp.exe")
set_tests_properties("hyle_package_math_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/math/cpp/CMakeLists.txt;10;add_test;C:/public/project-hyle/hyle/samples/package/math/cpp/CMakeLists.txt;0;")
