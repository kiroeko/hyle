"""Retain the selected generic package journeys before pruning duplicate builds."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('C:/public/project-hyle/hyle')
LOGS = ROOT / '.scratch/validation/vulkan-c1-final'
BUILD = Path('C:/hyle-scratch/active-vk/g32')
COMPONENTS = ('compute', 'graph', 'container', 'core', 'error', 'io', 'math', 'mem', 'obs',
              'platform', 'process', 'sched', 'simd', 'time', 'util')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    run_root = LOGS / 'remaining-delivery'
    result = json.loads((run_root / 'result.json').read_text(encoding='utf-8'))
    assert result['status'] == 'PASS'
    gates = {gate['id']: gate for gate in result['gates']}
    assert set(gates) == {'delivery:' + name for name in COMPONENTS}
    files = {}
    for name in ('result.json', 'plan.json'):
        files['execution/' + name] = run_root / name
    for name in ('remaining-gates.py', 'remaining-gates.ps1',
                 'remaining-toolchain.cmake', 'remaining-context.json',
                 'delivery-ctest.ps1', 'delivery-ctest.cmd',
                 'collect_remaining_deliveries.py', 'cleanup-remaining-deliveries.ps1'):
        files['commands/' + name] = LOGS / name
    records = []
    for component in COMPONENTS:
        gate = gates['delivery:' + component]
        assert gate['status'] == 'PASS'
        for command in gate['commands']:
            log = run_root / command['log']
            assert command['exit_code'] == 0 and sha(log) == command['sha256']
            files['execution/' + log.name] = log
        data = log.read_bytes()
        assert ('HYLE selected product smoke passed: ' + component).encode() in data
        assert data.count(b'CRT adjacent; PATH unset') == 3
        base = (BUILD / ('delivery-' + component) / ('selected-' + component)).resolve(strict=True)
        base.relative_to(BUILD.resolve(strict=True))
        journeys = []
        for journey, directory in (('source', 'source-build'),
                                   ('shared', 'shared-consumer'),
                                   ('static', 'static-consumer')):
            folder = base / directory
            test = folder / 'Testing/Temporary/LastTest.log'
            data = test.read_bytes()
            assert b'Test Passed.' in data and b'Test Failed.' not in data
            for path in (test, folder / 'CMakeCache.txt', folder / 'CTestTestfile.cmake'):
                files[component + '/' + str(path.relative_to(base))] = path
            executables = [p for p in folder.rglob('*.exe')
                           if 'CMakeFiles' not in p.parts and '_deps' not in p.parts]
            journeys.append({'journey': journey, 'status': 'PASS',
                             'executables': {str(p.relative_to(base)): sha(p) for p in executables}})
        packages = {}
        for linkage in ('shared', 'static'):
            prefix = base / (linkage + '-sdk-relocated')
            assert prefix.is_dir() and not (base / (linkage + '-sdk-staging')).exists()
            for name in ('CMakeCache.txt', 'install_manifest.txt'):
                path = base / (linkage + '-sdk-build') / name
                files[component + '/' + str(path.relative_to(base))] = path
            packages[linkage] = {str(p.relative_to(prefix)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                                 for p in sorted(prefix.rglob('*')) if p.is_file()}
        records.append({'component': component, 'journeys': journeys, 'packages': packages})
    archive = LOGS / 'remaining-deliveries-raw.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
        for name, path in files.items():
            output.write(path, name.replace('\\', '/'))
    with zipfile.ZipFile(archive) as saved:
        assert saved.testzip() is None
        assert set(saved.namelist()) == {name.replace('\\', '/') for name in files}
        for name, path in files.items():
            assert hashlib.sha256(saved.read(name.replace('\\', '/'))).hexdigest() == sha(path)
    receipt = {'schema': 'hyle.c1-selected-deliveries/v1', 'candidate': result['candidate'],
               'status': 'PASS', 'components': records, 'archive': archive.name,
               'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
               'scope': '15 selected package gates; original source/shared/static, relocation and hygiene checks. No operator or performance verdict.',
               'execution': 'serial gates, parallel2; HYLE/CRT DLLs adjacent, PATH unset and SetErrorMode0x8003'}
    (LOGS / 'remaining-deliveries-receipt.json').write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'status': 'PASS', 'components': len(records),
                      'journeys': sum(len(r['journeys']) for r in records),
                      'archive_bytes': receipt['archive_bytes']}))


if __name__ == '__main__':
    main()
