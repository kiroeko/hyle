import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--machine', choices=('air', 'mini'), required=True)
args = parser.parse_args()
root = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
logs = root / 'y25-5f4df55b'
record = json.loads((logs / 'result.json').read_text())
assert record['candidate'] == '5f4df55b287b9c895048bf05ab350ff49c96fd6c'
assert record['verdict'] == 'PASS'
assert all(command['exit_code'] == 0 for command in record['commands'])
archive = root / ('y25-' + args.machine + '-focused.zip')
files = {path.name: path for path in logs.iterdir() if path.is_file()}
for name in ('run-y25-' + args.machine + '.py', 'pack-y25-focused.py'):
    if (root / name).is_file():
        files['controller/' + name] = root / name
manifest = {name: {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                   'bytes': path.stat().st_size} for name, path in files.items()}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as package:
    for name, path in files.items():
        package.write(path, name)
    package.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
receipt = {'candidate': record['candidate'], 'machine': args.machine, 'verdict': 'PASS',
           'archive': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'bytes': archive.stat().st_size}
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
