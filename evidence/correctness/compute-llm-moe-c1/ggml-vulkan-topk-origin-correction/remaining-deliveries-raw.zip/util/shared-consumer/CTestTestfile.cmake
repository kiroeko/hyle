# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/active-vk/v/samples/package/util/cpp
# Build directory: C:/hyle-scratch/active-vk/g/delivery-util/selected-util/shared-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_util_cpp_package_probe" "C:/hyle-scratch/active-vk/g/delivery-util/selected-util/shared-consumer/hyle_util_cpp_package_probe.exe")
set_tests_properties("hyle_util_cpp_package_probe" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-vk/v/samples/package/util/cpp/CMakeLists.txt;32;add_test;C:/hyle-scratch/active-vk/v/samples/package/util/cpp/CMakeLists.txt;0;")
