@echo off
"C:\Program Files\PowerShell\7\pwsh.exe" -NoProfile -File "C:\public\project-hyle\hyle\.scratch\validation\vulkan-topk\origin-correction\generic\delivery-ctest.ps1" %*
exit /b %errorlevel%
