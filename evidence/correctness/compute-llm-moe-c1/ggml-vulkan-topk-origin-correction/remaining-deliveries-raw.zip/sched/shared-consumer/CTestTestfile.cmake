# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/active-vk/v/samples/package/sched/cpp
# Build directory: C:/hyle-scratch/active-vk/g/delivery-sched/selected-sched/shared-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_sched_cpp_package_probe" "C:/hyle-scratch/active-vk/g/delivery-sched/selected-sched/shared-consumer/hyle_sched_cpp_package_probe.exe")
set_tests_properties("hyle_sched_cpp_package_probe" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-vk/v/samples/package/sched/cpp/CMakeLists.txt;12;add_test;C:/hyle-scratch/active-vk/v/samples/package/sched/cpp/CMakeLists.txt;0;")
