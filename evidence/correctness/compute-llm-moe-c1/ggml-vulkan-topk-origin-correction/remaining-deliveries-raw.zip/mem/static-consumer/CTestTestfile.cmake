# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/active-vk/v/samples/package/mem/cpp
# Build directory: C:/hyle-scratch/active-vk/g/delivery-mem/selected-mem/static-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_mem_cpp" "C:/hyle-scratch/active-vk/g/delivery-mem/selected-mem/static-consumer/hyle_package_mem_cpp.exe")
set_tests_properties("hyle_package_mem_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-vk/v/samples/package/mem/cpp/CMakeLists.txt;12;add_test;C:/hyle-scratch/active-vk/v/samples/package/mem/cpp/CMakeLists.txt;0;")
