# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/active-vk/v/samples/package/error/cpp
# Build directory: C:/hyle-scratch/active-vk/g/delivery-error/selected-error/static-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_error_cpp" "C:/hyle-scratch/active-vk/g/delivery-error/selected-error/static-consumer/hyle_package_error_cpp.exe")
set_tests_properties("hyle_package_error_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-vk/v/samples/package/error/cpp/CMakeLists.txt;11;add_test;C:/hyle-scratch/active-vk/v/samples/package/error/cpp/CMakeLists.txt;0;")
