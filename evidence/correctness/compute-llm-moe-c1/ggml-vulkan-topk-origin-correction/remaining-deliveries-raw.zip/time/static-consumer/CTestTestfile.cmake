# CMake generated Testfile for 
# Source directory: C:/hyle-scratch/active-vk/v/samples/package/time/cpp
# Build directory: C:/hyle-scratch/active-vk/g/delivery-time/selected-time/static-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_time_cpp_package_probe" "C:/hyle-scratch/active-vk/g/delivery-time/selected-time/static-consumer/hyle_time_cpp_package_probe.exe")
set_tests_properties("hyle_time_cpp_package_probe" PROPERTIES  _BACKTRACE_TRIPLES "C:/hyle-scratch/active-vk/v/samples/package/time/cpp/CMakeLists.txt;12;add_test;C:/hyle-scratch/active-vk/v/samples/package/time/cpp/CMakeLists.txt;0;")
