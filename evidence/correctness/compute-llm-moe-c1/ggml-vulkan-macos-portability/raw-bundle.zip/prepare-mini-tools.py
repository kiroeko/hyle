from pathlib import Path
import tarfile, hashlib, json, subprocess
root=Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
dest=root/'y-vulkan-tools'
assert not dest.exists()
dest.mkdir()
artifacts=[('shaderc-2026.3.arm64_tahoe.tar.gz','7040868fd148b36391a8be834c7d4ab8b9d3920256fd4a56c5cc78ef5276f3ee'),('spirv-headers-sdk.tar.gz','949a1ea808eaf15048b99f548080f86b468bd1e8b2b8e7ae6daa1eb9c4ca38db')]
for name, expected in artifacts:
    archive=root/name
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
    with tarfile.open(archive,'r:gz') as package:
        for member in package.getmembers():
            target=(dest/member.name).resolve()
            assert target == dest or dest in target.parents
            assert member.isfile() or member.isdir() or member.issym() or member.islnk()
            if member.issym():
                link=(target.parent/member.linkname).resolve()
                assert link == dest or dest in link.parents
            if member.islnk():
                link=(dest/member.linkname).resolve()
                assert link == dest or dest in link.parents
        package.extractall(dest)
glslc=dest/'shaderc/2026.3/bin/glslc'
result={'archives':[{'name':n,'sha256':s} for n,s in artifacts], 'glslc_sha256':hashlib.sha256(glslc.read_bytes()).hexdigest(), 'commands':[]}
for command in ([str(glslc),'--version'], ['/usr/bin/otool','-L',str(glslc)], ['/usr/bin/vtool','-show-build',str(glslc)]):
    run=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=15)
    result['commands'].append({'command':command,'returncode':run.returncode,'output':run.stdout})
    print(run.stdout)
    assert run.returncode==0
(root/'y-vulkan-tools.json').write_text(json.dumps(result,indent=2)+'\n')
