from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import zipfile

ROOT = Path('C:/public/project-hyle/hyle')
LOGS = ROOT / '.scratch/validation/vulkan-pointwise'
DEST = ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-macos-portability'
DEST.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
verifications = []
for suite, count in [('compute_provider_ggml_vulkan', 19), ('compute_route_vulkan', 40), ('graph_route_vulkan', 17)]:
    report = read(LOGS / 'air-final' / (suite + '.json'))
    assert report['tests'] == count and report['failures'] == report['errors'] == report['disabled'] == 0
    assert all(test['status'] == 'RUN' and test['result'] == 'COMPLETED' for group in report['testsuites'] for test in group['testsuite'])
    raw = (LOGS / 'air-final' / (suite + '.log')).read_text(errors='replace')
    vuids = Counter(re.findall(r'\[ (VUID-[^ ]+) \]', raw))
    assert set(vuids) == {'VUID-VkDeviceCreateInfo-pProperties-04451'}
    verifications.append({'suite': suite, 'cases': count, 'assertions': 'PASS', 'runtime_skips': 0,
                          'validation': 'FAIL', 'vuids': dict(vuids)})
assert sum(sum(v['vuids'].values()) for v in verifications) == 87
files = {}
for name in ('air-initial', 'air-fixture', 'air-portability', 'air-final', 'fixture-w1', 'portability-w1', 'fixture2-w1'):
    for path in (LOGS / name).iterdir():
        if path.is_file(): files[path.relative_to(LOGS).as_posix()] = path
for name in ('run-air-initial.py', 'run-air.py', 'run-air-fixture.py', 'run-air-portability.py', 'run-air-final.py',
             'fixture-w1-run.ps1', 'portability-w1-run.ps1', 'fixture2-w1-run.ps1',
             'fixture-selector.json', 'portability-selector.json', 'fixture2-selector.json',
             'air-bootstrap-failure.txt', 'air-run.log', 'air-fixture-run.log', 'air-portability-run.log', 'air-final-run.log',
             'shaderc-transfer.json', 'mini-shaderc-transfer.json', 'mini-tools.json', 'spirv-headers-sdk.json',
             'air-shaderc-install.log', 'air-shaderc-cached-install.log', 'fetch-shaderc.py', 'fetch-mini-shaderc.py',
             'prepare-mini-tools.py', 'loc-current.json', 'record-mac-portability.py'):
    files[name] = LOGS / name
archive = DEST / 'raw-bundle.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
    for name, path in sorted(files.items()): out.write(path, name)
with zipfile.ZipFile(archive) as stored: assert stored.testzip() is None
result = {
    'candidate': 'ceace753781426e82f6e2f1d4ee50eb2aaed9dde',
    'tree': '322daf9f1d009e264b44f7717c459b60c7f9ceec',
    'product_candidate': '69b3414b182998005b2c23c8444131b45338d3df',
    'machine': read(LOGS / 'air-final/result.json')['machine'],
    'scope': 'Y17-Y19 first macOS build and runtime validation, before the separately audited Y20 fix',
    'verdict': 'FAIL', 'reason': '76 numerical/lifecycle cases passed; 87 mandatory portability-subset device-creation validation errors',
    'verifications': verifications,
    'raw_receipt_note': 'The final driver exits 1 at the validation-log postcondition. Its original RUNNING field is preserved, not interpreted as PASS.',
    'build_corrections': [
        {'commit': '132e7497f7c3ae90f49fdb4853cff24f1b5baa87', 'scope': 'Five Vk struct initializations in a test fixture'},
        {'commit': '69b3414b182998005b2c23c8444131b45338d3df', 'scope': 'Explicit existing defaults in one cold PlanStep'},
        {'commit': 'ceace753781426e82f6e2f1d4ee50eb2aaed9dde', 'scope': 'Remaining lifecycle fixture initializations and vendor-include unused-function diagnostic boundary'}],
    'windows_revalidation': [
        {'scope': 'first test fixture correction', 'provider_cases': 19, 'source_and_masm_ctests': 2, 'verdict': 'PASS'},
        {'scope': 'one product PlanStep correction', 'direct_cases': 40, 'graph_cases': 17, 'verdict': 'PASS'},
        {'scope': 'remaining test fixture correction', 'provider_cases': 19, 'direct_cases': 40, 'source_and_masm_ctests': 2, 'verdict': 'PASS'}],
    'mini_status': 'Tools prepared and verified; no product configure/build/runtime run yet for this candidate',
    'outstanding': ['Y20 corrected candidate validation', 'remaining C1 provider bindings', 'real weights', 'three C++ deliveries', 'qualified performance and fixed rules'],
    'loc': {'implementation_lines': 46990, 'files': 193, 'self_check': read(LOGS / 'loc-current.json')['self_check']},
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive)},
    'files': [{'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)} for name,path in sorted(files.items())]}
(DEST / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n',encoding='utf-8',newline='\n')
(DEST / 'loc.json').write_bytes((LOGS / 'loc-current.json').read_bytes())
print(json.dumps({'verdict': result['verdict'], 'archive': result['archive'], 'loc': result['loc']}))
