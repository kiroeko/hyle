"""Fetch one checksum-pinned public bottle for the Mac validation toolchain."""
import hashlib
import json
from pathlib import Path
import time
import urllib.request

output = Path('C:/hyle-scratch/active-vk/tools/shaderc-2026.4.arm64_golden_gate.tar.gz')
expected = '463549d39c59ba245f05379667d89e83f223f1b035226926534fc28ede01455e'
url = 'https://ghcr.io/v2/homebrew/core/shaderc/blobs/sha256:' + expected
output.parent.mkdir(exist_ok=True)
assert not output.exists()
with urllib.request.urlopen('https://ghcr.io/token?service=ghcr.io&scope=repository:homebrew/core/shaderc:pull', timeout=30) as response:
    token = json.load(response)['token']
request = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + token})
start = time.monotonic()
digest = hashlib.sha256()
with urllib.request.urlopen(request, timeout=30) as response, output.open('xb') as stream:
    while data := response.read(1024 * 1024):
        if time.monotonic() - start > 180:
            raise TimeoutError('bounded tool transfer exceeded 180 seconds')
        stream.write(data)
        digest.update(data)
assert digest.hexdigest() == expected
receipt = {'source': url, 'path': str(output), 'bytes': output.stat().st_size,
           'sha256': expected, 'seconds': time.monotonic() - start,
           'role': 'Mac validation glslc tool only; no product dependency change'}
Path('.scratch/validation/vulkan-pointwise/shaderc-transfer.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(receipt))
