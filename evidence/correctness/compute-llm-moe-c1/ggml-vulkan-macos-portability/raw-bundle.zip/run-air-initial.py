from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time

ROOT = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
SOURCE = ROOT / 'source'
BUILD = ROOT / 'build-vulkan-static'
CANDIDATE = '4c309c6ee8c31e8c9e2811d7d54fd44fc57b2db4'
TREE = '5122cf71d687e86aadf6a9e9a06222633d43ddc5'
BUNDLE = ROOT / 'candidate.bundle'
VENDOR_ARCHIVE = ROOT / 'ggml.tar.gz'
LOGS = ROOT / ('y17-' + CANDIDATE[:8])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert digest(BUNDLE) == '37d114440e185d0a22a86bc6182f3810190d9eb0f5793683c3f860d68f79e6f5'
assert digest(VENDOR_ARCHIVE) == 'e13c176ea92e4a54ef3efccdfdb192e7433c76f91181de86b445560a47b07ac7'
assert not LOGS.exists(), 'inspect the existing attempt before restarting'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE)
subprocess.run(['git', 'fetch', str(BUNDLE), 'HEAD'], cwd=SOURCE, check=True)
subprocess.run(['git', 'checkout', '--detach', CANDIDATE], cwd=SOURCE, check=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=SOURCE, text=True).strip() == TREE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE)
VENDOR = ROOT / 'ggml'
if not VENDOR.exists():
    with tarfile.open(VENDOR_ARCHIVE, 'r:gz') as archive:
        for member in archive.getmembers():
            target = (ROOT / member.name).resolve()
            assert target == VENDOR or VENDOR in target.parents
            assert not member.issym() and not member.islnk() and (member.isfile() or member.isdir())
        archive.extractall(ROOT)
else:
    raise RuntimeError('unexpected vendor directory: check its identity before reuse')
LOGS.mkdir()

ENV = os.environ.copy()
ENV.update(
    PATH='/opt/homebrew/bin:' + ENV['PATH'],
    CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1', TRACY_ONLY_LOCALHOST='1',
    DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib',
    HYLE_VULKAN_VALIDATION='1', HYLE_TEST_VULKAN_VALIDATE='1',
    VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LOADER_LAYERS_DISABLE='~implicit~',
    VK_LAYER_PATH='/Users/kiro/hyle-verify/r6-vulkan-20260917/tools/vulkan-validationlayers/1.4.357.0/share/vulkan/explicit_layer.d')

result = {
    'candidate': CANDIDATE, 'tree': TREE,
    'scope': 'C1-Y17-Y19 same-candidate static provider/direct/graph correctness; not delivery or performance acceptance',
    'source': str(SOURCE), 'build': str(BUILD),
    'bundle_sha256': digest(BUNDLE), 'vendor_archive_sha256': digest(VENDOR_ARCHIVE),
    'vendor_commit': '456172ec733a135778adcd32d00e576a58232e45',
    'machine': {
        'model': subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip(),
        'os': subprocess.check_output(['/usr/bin/sw_vers'], text=True),
        'compiler': subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'], text=True),
        'glslc': subprocess.check_output(['/opt/homebrew/bin/glslc', '--version'], text=True),
        'glslc_sha256': digest(Path('/opt/homebrew/bin/glslc')),
    },
    'environment': {k: ENV[k] for k in ('PATH', 'DYLD_LIBRARY_PATH', 'VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'VK_LOADER_LAYERS_DISABLE', 'HYLE_TEST_VULKAN_VALIDATE', 'HYLE_VULKAN_VALIDATION')},
    'commands': [], 'verdict': 'RUNNING'}

def save():
    (LOGS / 'result.json').write_text(json.dumps(result, indent=2) + '\n')

def run(label, command, timeout):
    print('RUN', label, flush=True)
    log = LOGS / (label + '.log')
    start = time.monotonic()
    timed_out = False
    with log.open('wb') as output:
        try:
            rc = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=output, stderr=subprocess.STDOUT, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            rc = 124
            timed_out = True
    result['commands'].append({'label': label, 'command': command, 'exit_code': rc,
        'seconds': time.monotonic() - start, 'timed_out': timed_out, 'log': str(log), 'sha256': digest(log)})
    if rc:
        result['verdict'] = 'FAIL'
        save()
        print(log.read_text(errors='replace')[-9000:], flush=True)
        sys.exit(rc)
    save()

save()
run('configure', ['/opt/homebrew/bin/cmake', '-S', str(SOURCE), '-B', str(BUILD), '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
    '-DHYLE_DEV_FACTORS=compute_provider_ggml_vulkan;compute_route_vulkan;graph_route_vulkan',
    '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF',
    '-DHYLE_COMPUTE_VULKAN=ON', '-DHYLE_COMPUTE_ONEDNN=OFF', '-DHYLE_BUILD_TESTS=ON',
    '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_STATIC=ON', '-DHYLE_INSTALL=OFF', '-DHYLE_WERROR=ON',
    '-DHYLE_TEST_INSTRUMENTATION=OFF', '-DHYLE_TRACE=OFF', '-DHYLE_SANITIZER=off',
    '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=' + str(VENDOR),
    '-DCMAKE_PREFIX_PATH=/opt/homebrew', '-DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator'], 180),  # cold configuration only
run('build', ['/opt/homebrew/bin/cmake', '--build', str(BUILD), '--parallel', '2', '--target',
    'hyle_compute_provider_ggml_vulkan_test', 'hyle_compute_route_vulkan_test', 'hyle_graph_route_vulkan_test'], 1800)
for suite in ('compute_provider_ggml_vulkan', 'compute_route_vulkan', 'graph_route_vulkan'):
    run(suite, [str(BUILD / 'bin' / ('hyle_' + suite + '_test')), '--gtest_output=json:' + str(LOGS / (suite + '.json'))], 300)
    report = json.loads((LOGS / (suite + '.json')).read_text())
    assert report['tests'] > 0 and report['failures'] == 0 and report.get('disabled', 0) == 0
    assert report.get('skipped', 0) == 0
run('source-contract', ['/opt/homebrew/bin/ctest', '--test-dir', str(BUILD), '--output-on-failure',
    '--parallel', '1', '--no-tests=error', '-R', '^hyle_ggml_vulkan_source_contract_test$',
    '--output-junit', str(LOGS / 'ctest.xml')], 180)
for log in LOGS.glob('*.log'):
    assert not any(marker in log.read_text(errors='replace') for marker in ('Validation Error', 'VUID-', 'SYNC-HAZARD')), log
result['artifacts'] = [{
    'path': str(BUILD / 'bin' / ('hyle_' + suite + '_test')),
    'sha256': digest(BUILD / 'bin' / ('hyle_' + suite + '_test')),
    'tests': json.loads((LOGS / (suite + '.json')).read_text())['tests']}
    for suite in ('compute_provider_ggml_vulkan', 'compute_route_vulkan', 'graph_route_vulkan')]
result['verdict'] = 'PASS'
save()
print('C1-Y17-Y19 Air static focused PASS', flush=True)
