param([ValidateSet('static','shared')][string]$Mode='static')
$ErrorActionPreference='Stop'
$testRoot='C:/hyle-scratch/vk-y2'
$env:VK_LAYER_PATH='C:/hyle-scratch/r6-vulkan-20260917/tools/validation-1.4.357.0'
$env:VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation'
$env:HYLE_TEST_VULKAN_VALIDATE='1'
$env:TRACY_ONLY_LOCALHOST='1'
$cmakePath=(Get-Command cmake).Source
& $cmakePath -E env --unset=PATH "$testRoot/$Mode/bin/hyle_compute_provider_ggml_vulkan_test.exe" "--gtest_output=json:$testRoot/y3-test-$Mode.json" *> "$testRoot/y3-test-$Mode.log"
$result=$LASTEXITCODE
Get-Content "$testRoot/y3-test-$Mode.log" -Tail 50
exit $result
