$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL='2'
$env:VULKAN_SDK='C:/hyle-scratch/ggml-vulkan-region-20260918/sdk'
$env:PATH="$env:VULKAN_SDK/Bin;$env:PATH"
$projectionRoot='C:/hyle-scratch/vk-y2'
& cmake -S C:/public/project-hyle/hyle -B "$projectionRoot/projection" -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=ON -DHYLE_INSTALL=ON -DHYLE_BUILD_TESTS=OFF -DHYLE_BUILD_BENCH=OFF '-DHYLE_COMPONENTS=compute;graph' -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=ON -DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe -DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=C:/hyle-scratch/ggml-vulkan-region-20260918/upstream-clean "-DCMAKE_PREFIX_PATH=$env:VULKAN_SDK" "-DCMAKE_INSTALL_PREFIX=$projectionRoot/unbuilt-install" *> "$projectionRoot/configure-projection.log"
$result=$LASTEXITCODE
Get-Content "$projectionRoot/configure-projection.log" -Tail 10
exit $result
