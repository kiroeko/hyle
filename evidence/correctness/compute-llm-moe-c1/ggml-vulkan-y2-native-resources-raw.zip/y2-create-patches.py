from pathlib import Path
import hashlib, json, subprocess
root = Path.cwd()
upstream = Path('C:/public/project-hyle/ggml')
manifest_path = root / 'third_party/ggml_vulkan_runtime/patches.json'
manifest = json.loads(subprocess.check_output(['git', 'show', '3caa1103:third_party/ggml_vulkan_runtime/patches.json'], encoding='utf-8'))

def edit_file(name, modifications):
    original = (upstream / name).read_bytes().replace(b'\r\n', b'\n').decode('utf-8')
    record = next((x for x in manifest['files'] if x['path'] == name), None)
    if record is None:
        record = {'path': name, 'before_sha256': hashlib.sha256(original.encode()).hexdigest(), 'edits': []}
        manifest['files'].append(record)
    text = original
    for edit in record['edits']:
        assert text.count(edit['before']) == 1, (name, edit['before'][:90])
        text = text.replace(edit['before'], edit['after'], 1)
    def replace(before, after):
        nonlocal text
        assert text.count(before) == 1, (name, text.count(before), before[:140])
        record['edits'].append({'before': before, 'after': after})
        text = text.replace(before, after, 1)
    modifications(text, replace)
    record['after_sha256'] = hashlib.sha256(text.encode()).hexdigest()


def vulkan(text, replace):
    replace('#include "ggml-vulkan.h"', '#include "ggml-vulkan.h"\n#include "native_bridge.h"')
    replace('    vk_device device;\n};\n\nstruct vk_queue;', '    vk_device_ref device;\n};\n\nstruct vk_queue;')
    replace('    ggml_backend_buffer_type buffer_type;', '    ggml_backend_buffer_type buffer_type{};\n    bool hyle_storage_update_after_bind = false;')
    replace('        VK_LOG_DEBUG("destroy device " << name);', '''        VK_LOG_DEBUG("destroy device " << name);
        delete static_cast<ggml_backend_vk_buffer_type_context *>(buffer_type.context);
        if (!device) return;''')
    before = text[text.index('struct vk_buffer_struct {'):text.index('\nstruct vk_subbuffer {')]
    replace(before, '''struct vk_buffer_struct {
    vk::Buffer buffer = VK_NULL_HANDLE;
    vk::DeviceMemory device_memory = VK_NULL_HANDLE;
    vk::MemoryPropertyFlags memory_property_flags;
    void * ptr = nullptr;
    size_t size = 0;
    vk::DeviceAddress bda_addr {};
    vk_device device;
    std::shared_ptr<const void> external_owner;
    hyle::compute::ggml_vulkan::bridge::Charge charge;
    bool imported_host = false;

    ~vk_buffer_struct() {
        if (!device || external_owner) return;
        if (ptr && !imported_host && device_memory)
            device->device.unmapMemory(device_memory);
        device->device.destroyBuffer(buffer);
        device->device.freeMemory(device_memory);
        // charge retires after the actual memory has been freed.
    }
};
''')
    replace('struct vk_instance_t {\n    vk::Instance instance;', '''struct vk_instance_t {
    hyle::compute::ggml_vulkan::bridge::Options options;
    DispatchLoaderDynamic dispatcher;
    bool initialized = false;
    uint32_t loader_version = 0;
    std::vector<ggml_backend_dev_t> registry_devices;
    bool registry_initialized = false;
    std::mutex registry_mutex;
    vk::Instance instance;''')
    replace('static bool vk_instance_initialized = false;\nstatic vk_instance_t vk_instance;', '''static thread_local vk_instance_t * hyle_vk_active_instance = nullptr;
static vk_instance_t & hyle_vk_instance() {
    GGML_ASSERT(hyle_vk_active_instance);
    return *hyle_vk_active_instance;
}
#define vk_instance (hyle_vk_instance())
#define vk_instance_initialized (vk_instance.initialized)''')
    replace('        vk_instance.devices[idx] = device;\n', '')
    replace('        device->device = device->physical_device.createDevice(device_create_info);', '''        device->hyle_storage_update_after_bind = vk12_features.descriptorBindingStorageBufferUpdateAfterBind;
        device->device = device->physical_device.createDevice(device_create_info);''')
    replace('        return device;\n    }\n\n    return vk_instance.devices[idx];', '''        vk_instance.devices[idx] = device; // Publish only the fully initialized owner.
        return device;
    }

    return vk_instance.devices[idx];''')
    replace('static DispatchLoaderDynamic ggml_vk_default_dispatcher_instance;\nDispatchLoaderDynamic & ggml_vk_default_dispatcher() {\n    return ggml_vk_default_dispatcher_instance;\n}', '''DispatchLoaderDynamic & ggml_vk_default_dispatcher() {
    return vk_instance.dispatcher;
}''')
    replace('    ggml_vk_default_dispatcher_instance.init(vkGetInstanceProcAddr);', '    // The HYLE owner supplies its loader before entering this scope.')
    replace('    vk::ApplicationInfo app_info{ "ggml-vulkan", 1, nullptr, 0, api_version };', '    vk_instance.loader_version = api_version;\n    vk::ApplicationInfo app_info{ "ggml-vulkan", 1, nullptr, 0, api_version };')
    replace('    const bool layer_settings = ggml_vk_instance_layer_settings_available();', '    const bool layer_settings = vk_instance.options.validation && ggml_vk_instance_layer_settings_available();')
    replace('    if (layer_settings) {\n        layers.push_back("VK_LAYER_KHRONOS_validation");\n    }', '''    if (vk_instance.options.validation) {
        const auto available = vk::enumerateInstanceLayerProperties();
        const auto found = std::any_of(available.begin(), available.end(), [](const auto & layer) {
            return strcmp(layer.layerName, "VK_LAYER_KHRONOS_validation") == 0;
        });
        if (!found) throw vk::LayerNotPresentError("VK_LAYER_KHRONOS_validation");
        layers.push_back("VK_LAYER_KHRONOS_validation");
    }''')
    replace('    vk::InstanceCreateInfo instance_create_info(vk::InstanceCreateFlags{}, &app_info, layers, extensions, &layer_setting_info);', '    vk::InstanceCreateInfo instance_create_info(vk::InstanceCreateFlags{}, &app_info, layers, extensions, layer_settings ? &layer_setting_info : nullptr);')
    # Diagnostic environment is process-wide, immutable after the first cold initialization.
    first = text.index('    vk_perf_logger_enabled = getenv("GGML_VK_PERF_LOGGER")')
    last = text.index('\n    // See https://github.com/KhronosGroup/Vulkan-Hpp?', first)
    diagnostics = text[first:last]
    replace(diagnostics, '    static std::once_flag diagnostics_once;\n    std::call_once(diagnostics_once, [] {\n' + diagnostics + '\n    });\n')
    replace('    // Emulate behavior of CUDA_VISIBLE_DEVICES for Vulkan', '''    // HYLE selects by the original physical-device index, not a vendor environment list.
    {
        const auto requested = vk_instance.options.device_index;
        if (requested != UINT32_MAX && requested >= devices.size())
            throw std::out_of_range("Vulkan physical device index");
        int best_score = -1;
        size_t selected = 0;
        for (size_t i = 0; i < devices.size(); ++i) {
            if (requested != UINT32_MAX && requested != i) continue;
            const auto properties = devices[i].getProperties();
            if (!vk_instance.options.allow_software && properties.deviceType == vk::PhysicalDeviceType::eCpu) continue;
            if (properties.apiVersion < VK_API_VERSION_1_2 || !ggml_vk_device_is_supported(devices[i])) continue;
            const auto queues = devices[i].getQueueFamilyProperties();
            if (std::none_of(queues.begin(), queues.end(), [](const auto & q) {
                return q.queueCount && bool(q.queueFlags & vk::QueueFlagBits::eCompute);
            })) continue;
            const int score = properties.deviceType == vk::PhysicalDeviceType::eDiscreteGpu ? 4 :
                              properties.deviceType == vk::PhysicalDeviceType::eIntegratedGpu ? 2 : 0;
            if (score > best_score) { best_score = score; selected = i; }
        }
        if (best_score < 0) throw vk::FeatureNotPresentError("no qualified Vulkan device");
        vk_instance.device_indices.push_back(selected);
        const auto extensions = devices[selected].enumerateDeviceExtensionProperties();
        vk_instance.device_supports_membudget.push_back(std::any_of(extensions.begin(), extensions.end(), [](const auto & ext) {
            return strcmp(ext.extensionName, "VK_EXT_memory_budget") == 0;
        }));
        return;
    }
    // The private HYLE build uses the explicit owner selection above.
    // Emulate behavior of CUDA_VISIBLE_DEVICES for Vulkan''')
    replace('    static std::vector<ggml_backend_dev_t> devices;\n\n    static bool initialized = false;', '    auto & devices = vk_instance.registry_devices;\n    auto & initialized = vk_instance.registry_initialized;')
    replace('        static std::mutex mutex;\n        std::lock_guard<std::mutex> lock(mutex);', '        std::lock_guard<std::mutex> lock(vk_instance.registry_mutex);')
    replace('                ggml_backend_vk_device_context * ctx = new ggml_backend_vk_device_context;', '                auto ctx = std::make_unique<ggml_backend_vk_device_context>();')
    replace('                devices.push_back(new ggml_backend_device {\n                    /* .iface   = */ ggml_backend_vk_device_i,\n                    /* .reg     = */ reg,\n                    /* .context = */ ctx,\n                });', '                auto entry = std::make_unique<ggml_backend_device>(ggml_backend_device {\n                    ggml_backend_vk_device_i, reg, ctx.get(),\n                });\n                devices.push_back(entry.get());\n                ctx.release();\n                entry.release();')
    replace('    devices[device].getProperties(&props);', '    devices[vk_instance.device_indices[device]].getProperties(&props);')
    # Buffer ownership exists before any fallible native creation, including map/bind.
    replace('    vk_buffer buf = std::make_shared<vk_buffer_struct>();\n\n    if (size == 0)', '    vk_buffer buf = std::make_shared<vk_buffer_struct>();\n    buf->device = device;\n    buf->size = size;\n    buf->imported_host = import_ptr != nullptr;\n\n    if (size == 0)')
    replace('    vk::MemoryRequirements mem_req = device->device.getBufferMemoryRequirements(buf->buffer);', '    vk::MemoryRequirements mem_req = device->device.getBufferMemoryRequirements(buf->buffer);\n    buf->charge.reserve(vk_instance.options, import_ptr ? size : mem_req.size);')
    # All four explicit cleanup paths are now covered by the same buffer owner.
    block = text[text.index('static vk_buffer ggml_vk_create_buffer(vk_device&'):text.index('\nstatic vk_buffer ggml_vk_create_buffer_check')]
    for line in ('            device->device.destroyBuffer(buf->buffer);\n', '                        device->device.destroyBuffer(buf->buffer);\n', '        device->device.destroyBuffer(buf->buffer);\n'):
        pass
    # Apply unique statement contexts rather than a broad replacement.
    replace('GGML_LOG_WARN("ggml_vulkan: Failed getMemoryHostPointerPropertiesEXT (%s)\\n", e.what());\n            device->device.destroyBuffer(buf->buffer);', 'GGML_LOG_WARN("ggml_vulkan: Failed getMemoryHostPointerPropertiesEXT (%s)\\n", e.what());')
    replace('            GGML_LOG_WARN("ggml_vulkan: Memory type for host allocation not found\\n");\n            device->device.destroyBuffer(buf->buffer);', '            GGML_LOG_WARN("ggml_vulkan: Memory type for host allocation not found\\n");')
    replace('                        device->device.destroyBuffer(buf->buffer);\n                        throw e;', '                        throw;')
    replace('    if (!buf->device_memory) {\n        device->device.destroyBuffer(buf->buffer);', '    if (!buf->device_memory) {')
    replace('    if (buf->device != nullptr) {\n        buf->device->memory_logger->log_deallocation(buf);', '    if (buf->device != nullptr && !buf->external_owner) {\n        buf->device->memory_logger->log_deallocation(buf);')
    replace('        dev_buffer = ggml_vk_create_buffer_device(ctx->device, size);', '        auto device = ctx->device.lock();\n        dev_buffer = ggml_vk_create_buffer_device(device, size);')
    replace('    ggml_backend_vk_buffer_context * bufctx = new ggml_backend_vk_buffer_context(ctx->device, std::move(dev_buffer), ctx->name);\n\n    return ggml_backend_buffer_init(buft, ggml_backend_vk_buffer_interface, bufctx, size);', '''    auto bufctx = std::make_unique<ggml_backend_vk_buffer_context>(ctx->device.lock(), std::move(dev_buffer), ctx->name);
    auto result = ggml_backend_buffer_init(buft, ggml_backend_vk_buffer_interface, bufctx.get(), size);
    bufctx.release();
    return result;''')
    replace('    return ctx->device->properties.limits.minStorageBufferOffsetAlignment;', '    return ctx->device.lock()->properties.limits.minStorageBufferOffsetAlignment;')
    replace('    return ctx->device->suballocation_block_size;', '    return ctx->device.lock()->suballocation_block_size;')
    replace('    return buft_ctx->device->idx == ctx->device;', '    auto device = buft_ctx->device.lock();\n    return device && device == ggml_vk_get_device(ctx->device);')
    # Cold backend construction has no accepted GPU work; free exactly its created handles on failure.
    before = text[text.index('ggml_backend_t ggml_backend_vk_init(size_t dev_num) {'):text.index('\nbool ggml_backend_is_vk(')]
    replace(before, '''ggml_backend_t ggml_backend_vk_init(size_t dev_num) {
    auto ctx = std::make_unique<ggml_backend_vk_context>();
    try {
        ggml_vk_init(ctx.get(), dev_num);
        auto * backend = new ggml_backend {
            ggml_backend_vk_guid(), ggml_backend_vk_interface,
            ggml_backend_reg_dev_get(ggml_backend_vk_reg(), dev_num), ctx.get(),
        };
        if (!ctx->device->support_async) backend->iface.get_tensor_async = nullptr;
        ctx.release();
        return backend;
    } catch (...) {
        if (ctx->device) {
            auto & device = ctx->device->device;
            device.destroyFence(ctx->fence);
            device.destroyFence(ctx->almost_ready_fence);
            device.destroyCommandPool(ctx->compute_cmd_pool.pool);
            device.destroyCommandPool(ctx->transfer_cmd_pool.pool);
            device.destroySemaphore(ctx->transfer_semaphore.s);
        }
        throw;
    }
}
''')
    replace('    } catch (const vk::SystemError& e) {\n        return nullptr;\n    }\n\n    auto bufctx', '    } catch (const vk::OutOfDeviceMemoryError &) {\n        return nullptr;\n    } catch (const vk::OutOfHostMemoryError &) {\n        return nullptr;\n    }\n\n    auto bufctx')
    # Raw loader imports become owner-scoped PFNs. Every occurrence is uniquely anchored by its line.
    for line in text.splitlines():
        if 'vkGetInstanceProcAddr(' in line:
            replace(line, line.replace('vkGetInstanceProcAddr(', 'VULKAN_HPP_DEFAULT_DISPATCHER.vkGetInstanceProcAddr('))
        if 'vkGetDeviceProcAddr(' in line:
            replace(line, line.replace('vkGetDeviceProcAddr(', 'VULKAN_HPP_DEFAULT_DISPATCHER.vkGetDeviceProcAddr('))
        if 'vkGetPhysicalDeviceFeatures2(' in line:
            replace(line, line.replace('vkGetPhysicalDeviceFeatures2(', 'VULKAN_HPP_DEFAULT_DISPATCHER.vkGetPhysicalDeviceFeatures2('))
        if 'vkCmdCopyBuffer(' in line:
            replace(line, line.replace('vkCmdCopyBuffer(', 'VULKAN_HPP_DEFAULT_DISPATCHER.vkCmdCopyBuffer('))
    replace('GGML_BACKEND_DL_IMPL(ggml_backend_vk_reg)', 'GGML_BACKEND_DL_IMPL(ggml_backend_vk_reg)\n\n#include "native_runtime_impl.h"')

edit_file('src/ggml-vulkan/ggml-vulkan.cpp', vulkan)
edit_file('src/ggml.cpp', lambda text, replace: replace('static std::terminate_handler previous_terminate_handler;', '#if !defined(GGML_HYLE_EMBEDDED)\nstatic std::terminate_handler previous_terminate_handler;') or replace('}();', '}();\n#endif // GGML_HYLE_EMBEDDED: the host owns its terminate handler.'))
edit_file('src/ggml-vulkan/CMakeLists.txt', lambda text, replace: replace('    target_link_libraries(ggml-vulkan PRIVATE Vulkan::Vulkan)', '    target_link_libraries(ggml-vulkan PRIVATE "$<BUILD_INTERFACE:SPIRV-Headers::SPIRV-Headers>")'))
manifest_path.write_bytes((json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print('Updated exact patch manifest:', len(manifest['files']), 'files')
