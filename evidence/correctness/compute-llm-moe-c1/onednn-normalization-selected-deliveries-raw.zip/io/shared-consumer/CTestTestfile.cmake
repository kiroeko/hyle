# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/io/cpp
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/delivery-io/selected-io/shared-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_package_io_cpp" "C:/hyle-scratch/active-cpu/aa/remaining/delivery-io/selected-io/shared-consumer/hyle_package_io_cpp.exe")
set_tests_properties("hyle_package_io_cpp" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/io/cpp/CMakeLists.txt;12;add_test;C:/public/project-hyle/hyle/samples/package/io/cpp/CMakeLists.txt;0;")
