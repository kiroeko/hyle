# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/samples/package/util/cpp
# Build directory: C:/hyle-scratch/active-cpu/aa/remaining/delivery-util/selected-util/static-consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("hyle_util_cpp_package_probe" "C:/hyle-scratch/active-cpu/aa/remaining/delivery-util/selected-util/static-consumer/hyle_util_cpp_package_probe.exe")
set_tests_properties("hyle_util_cpp_package_probe" PROPERTIES  _BACKTRACE_TRIPLES "C:/public/project-hyle/hyle/samples/package/util/cpp/CMakeLists.txt;32;add_test;C:/public/project-hyle/hyle/samples/package/util/cpp/CMakeLists.txt;0;")
