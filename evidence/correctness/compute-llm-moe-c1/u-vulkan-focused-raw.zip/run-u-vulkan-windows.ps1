$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
python C:/hyle-scratch/llm-moe-c1-20260917/run-u-vulkan-windows.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
