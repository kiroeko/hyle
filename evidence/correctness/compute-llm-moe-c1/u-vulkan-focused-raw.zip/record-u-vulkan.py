from pathlib import Path
import hashlib, json, re, subprocess, zipfile

root = Path('C:/hyle-scratch/llm-moe-c1-20260917')
repo = Path('C:/public/project-hyle/hyle')
evidence = repo / 'evidence/correctness/compute-llm-moe-c1'
candidate = 'd0f9ca8ca4e0c217a029bf0c8a336c17b6caa7bc'
product = 'd2a764d26fcb76a8995756a0b716fb3d5a99249e'
entries = [('windows', '9532a7b3'), ('windows', '38793bad'),
           ('windows', 'd2a764d2'), ('windows', candidate[:8]),
           ('air', candidate[:8]), ('mini', candidate[:8])]
failures = {
    '9532a7b3': 'WERROR rejected a shadowed Recorder local name. Renamed the local; no algorithm/tolerance change.',
    'd2a764d2': 'New constant-View test passed std::array directly to View::reshape, which requires TensorShape. Corrected test construction; product code unchanged.'}
attempts, raw_files = [], []
for host, revision in entries:
    directory = root / f'u-{host}' / revision
    path = directory / 'result.json'
    record = json.loads(path.read_text(encoding='utf-8'))
    assert record['verdict'] == ('FAIL' if revision in failures else 'PASS')
    record['validation_host'] = host
    record['local_result'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for command in record['commands']:
        log = directory / Path(command['log']).name
        assert hashlib.sha256(log.read_bytes()).hexdigest() == command['sha256']
        command['local_log'] = str(log)
    if revision in failures:
        record['failure'] = failures[revision]
        record['test_cases'] = None
        assert not (directory / 'test.log').exists()
    else:
        text = (directory / 'test.log').read_text(encoding='utf-8')
        counts = [int(n) for n in re.findall(r'\[==========\] Running (\d+) tests from', text)]
        assert counts == ([20, 9] if revision == '38793bad' else [20, 10])
        assert 'out of 4' in text
        record['test_cases'] = {'compute_route_vulkan': counts[0], 'graph_route_vulkan': counts[1], 'separate_header_checks': 2}
        assert hashlib.sha256((directory / 'LastTest.log').read_bytes()).hexdigest() == record['last_test_sha256']
        if host != 'mini':
            assert not any(marker in text for marker in ('Validation Error', 'VUID-', 'SYNC-HAZARD'))
    attempts.append(record)
    raw_files.extend(p for p in directory.iterdir() if p.is_file())
selectors = []
for host in ('windows', 'air'):
    path = root / f'u-{host}' / candidate[:8] / 'selector.json'
    plan = json.loads(path.read_text(encoding='utf-8'))
    selectors.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'verdict': plan['verdict'], 'selected': [g['id'] for g in plan['selected_gates']],
        'skipped_count': len(plan['skipped_gates']),
        'skipped_reasons': [{'id': g['id'], 'reason': g['reason']} for g in plan['skipped_gates']],
        'execution_boundary': 'Focused factors/headers only. Selected full-C1 delivery gates and P1 remain pending under the current card.'})
for name in ('run-u-vulkan-windows.py', 'run-u-vulkan-windows.ps1',
             'run-u-vulkan-windows-fix.py', 'run-u-vulkan-windows-fix.ps1',
             'run-u-vulkan-windows-constant.py', 'run-u-vulkan-windows-constant.ps1',
             'run-u-vulkan-windows-constant-test.py', 'run-u-vulkan-windows-constant-test.ps1',
             'run-u-vulkan-air-constant-test.py', 'run-u-vulkan-mini-constant-test.py', 'record-u-vulkan.py'):
    raw_files.append(root / name)
archive = evidence / 'u-vulkan-focused-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(set(raw_files)):
        output.write(path, path.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as result:
    archive_entries = len(result.namelist())
    assert result.testzip() is None
boundaries = json.loads((evidence / 'u-implementation-loc.json').read_text(encoding='utf-8'))['module']['paths']
assert not subprocess.check_output(['git', 'diff', product, candidate, '--', *boundaries], cwd=repo)
record = {
    'kind': 'C1-U focused Vulkan zero-copy View and alias ownership; not full C1 acceptance',
    'product_candidate': product,
    'product_commits': ['9532a7b391752cad96f18366c9d8ace7a43dae3c', '38793badbe1ccf89a146e59f94fc381b92b20c5f', product],
    'validation_candidate': candidate, 'validation_tree': '6d88b4cb1d42ff50b41e32ec50ada1b47b0d4afd',
    'product_unchanged_since': 'd2a764d2 (all Compute/Graph implementation boundaries match the validation candidate)',
    'verdict': 'PASS', 'scope': 'U01-U04 focused correctness/lifecycle/P0; whole-C1 gates remain unproven',
    'attempts': attempts,
    'qualification': [
        'Final candidate: 20 Direct + 10 Graph cases and two separate header checks on each host. Two earlier Windows compilation failures are retained. No runtime numeric or tolerance correction.',
        'W1/Air installed validation layers reported no Validation Error, VUID or SYNC-HAZARD. Mini is correctness/portability only; its verified local MoltenVK/loader/compiler archive has no validation layer.',
        'Six storage types; four View kinds; nested/rank-eight/empty/odd origins; actual buffer/offset identity; computed-root liveness; input and constant aliases; old outputs/native tokens/two slots/close; true-alias Recorder outputs and neighbor guards.',
        'Native PFN counters prove equal-origin bind only updates descriptors, changed origins re-record idle commands, and submit reuses resources. Injected Begin failure leaves the slot unbound and retryable.',
        'Source P0 fixed lost constant-View provenance. Two equivalent weight Views share one cold pack and replay only two MatMuls. Original storage is retained only when its View is published; independent math and owner-release checks passed.',
        'View performs no payload allocation/copy/dispatch but retains full root capacity. Host metadata, descriptors and changed-origin recording have real costs. No P1 performance claim.',
        'The mature F32 MatMul/SiLU/custom descriptor-aligned domain is unchanged; unaligned inputs require explicit Copy.'
    ],
    'selectors': selectors,
    'raw_archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'entries': archive_entries},
    'not_run': ['Remaining Vulkan C1 Concat/gates/norm/reduce/Softmax/TopK/index/Scan mechanisms',
                'Full C1 actual model-weight consumer and 64-row/256-cell acceptance',
                'Full C1 source/installed-static/installed-shared and remaining applicable environment/sanitizer gates',
                'P1 and final default-rule qualification']}
(evidence / 'u-vulkan-focused.json').write_bytes((json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
registry = repo / 'docs/implementation/module-status.json'
data = json.loads(registry.read_text(encoding='utf-8'))
summary = 'LLM/MoE C1-U AUDITED：U01–U04 已实现零拷贝 View、别名 liveness/保活、原生重绑定及常量视图冷 packing 复用；W1/Air/Mini 各30例及2个头检查通过。完整 C1 的 Concat/gates/norm/reduce/index 等后续机制、真实权重/三交付和 P1 尚待完成；不签 C1 整包 PASS。'
for row in data['modules']:
    if row['module'] in ('compute_route_vulkan', 'graph_route_vulkan'):
        assert row['state'] == 'AUDITED'
        row['summary'] = summary
registry.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print('U receipt written;', archive_entries, 'raw files;', archive.stat().st_size, 'archive bytes')
