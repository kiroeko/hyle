import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

task = Path(__file__).resolve().parent
root = task.parents[2]
candidate = '07e30f13c3677d6edf56f3f9d1c9c7157504a911'
mac_candidate = '4c7d51c81e61060fffd4495af811f00f76cd4b2d'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == mac_candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
assert subprocess.check_output(['git', 'diff', '--name-only', candidate, mac_candidate], cwd=root, text=True).splitlines() == ['tests/compute_route_vulkan/scatter_test.cc']
test_diff = subprocess.check_output(['git', 'diff', '--unified=0', candidate, mac_candidate], cwd=root, text=True)
assert [s for s in test_diff.splitlines() if s.startswith('+') and not s.startswith('+++')] == ['+#include <algorithm>']
meta = json.loads((task / 'y29-candidate.json').read_text())
output = root / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-scatter'
output.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
raw = {}
windows = {}
logs = task.parent / 'vulkan-gather/w1'
for linkage in ('static', 'shared'):
    build = Path('C:/hyle-scratch/active-vk') / linkage
    suites = []
    for factor, expected in meta['expected_tests']['windows-' + linkage].items():
        report = logs / (linkage + '-' + factor + '.json')
        log = report.with_suffix('.log')
        data = json.loads(report.read_text())
        assert data['tests'] == expected and data['failures'] == 0 and data['errors'] == 0
        assert all(t['status'] == 'RUN' and t['result'] == 'COMPLETED' for s in data['testsuites'] for t in s['testsuite'])
        assert not any(m in log.read_text(encoding='utf-8', errors='replace') for m in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
        exe = build / 'bin' / ('hyle_' + factor + '_test.exe')
        suites.append({'factor': factor, 'tests': expected, 'executable_sha256': sha(exe),
                       'report_sha256': sha(report), 'log_sha256': sha(log)})
        raw[linkage + '/' + report.name] = report
        raw[linkage + '/' + log.name] = log
    ctest = logs / (linkage + '-ctest.xml')
    cases = ET.parse(ctest).getroot().findall('testcase')
    assert len(cases) == 2 and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
    raw[linkage + '/ctest.xml'] = ctest
    raw[linkage + '/CMakeCache.txt'] = build / 'CMakeCache.txt'
    headers = task / ('w1-' + linkage + '-headers.xml')
    checks = ET.parse(headers).getroot().findall('testcase')
    assert len(checks) == 1 and all(c.find('failure') is None and c.find('skipped') is None for c in checks)
    raw[linkage + '/headers.xml'] = headers
    raw[linkage + '/headers.log'] = headers.with_suffix('.log')
    for action in ('configure', 'build', 'test'):
        raw[linkage + '/' + action + '.log'] = logs / ('y29-' + linkage + '-' + action + '.log')
    windows[linkage] = {'status': 'PASS', 'candidate': candidate, 'suites': suites,
                       'tests': sum(s['tests'] for s in suites), 'source_and_masm_checks': 2, 'public_header_checks': 1,
                       'dlls_adjacent': True, 'path_unset': True, 'error_mode': '0x8003'}
focused = json.loads((task / 'w1-static/result.json').read_text())
assert focused['status'] == 'PASS' and focused['candidate'] == candidate
for path in (task / 'w1-static').iterdir():
    if path.is_file():
        raw['first-focused/' + path.name] = path
for name in ('selected-plan.json', 'y29-candidate.json', 'run-focused.py', 'run-y29-air.py', 'run-y29-mini.py',
             'pack-y29-platform.py', 'archive-results.py'):
    raw['commands/' + name] = task / name
raw['commands/w1-run.ps1'] = task.parent / 'vulkan-gather/w1-run.ps1'
for path in (task / 'air-initial-failure').iterdir():
    if path.is_file():
        raw['initial-air-compile-failure/' + path.name] = path
archive = output / 'w1-raw.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as package:
    for name, path in raw.items():
        package.write(path, name)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(hashlib.sha256(package.read(name)).hexdigest() == sha(path) for name, path in raw.items())
platforms = {}
for platform in ('air', 'mini'):
    name = 'y29p-' + platform + '-focused'
    receipt = json.loads((task / (name + '.json')).read_text())
    native_archive = task / (name + '.zip')
    assert receipt['status'] == 'PASS' and receipt['candidate'] == mac_candidate
    assert receipt['product_candidate'] == candidate
    assert receipt['archive_sha256'] == sha(native_archive)
    with zipfile.ZipFile(native_archive) as package:
        assert package.testzip() is None
    write_json(output / (name + '.json'), receipt)
    shutil.copy2(native_archive, output / native_archive.name)
    platforms[platform] = {'receipt': name + '.json', 'tests': sum(a['tests'] for a in receipt['result']['artifacts'])}
result = {'candidate': candidate, 'mac_test_candidate': mac_candidate, 'status': 'PASS', 'scope': 'Y29 ordered Scatter and selected Direct/Graph regression including F32 and I32 Scan',
          'windows': windows, 'macos': platforms,
          'cases': sum(w['tests'] for w in windows.values()) + sum(p['tests'] for p in platforms.values()),
          'first_focused_tests_not_added_again': 9, 'product_corrections': 0,
          'test_portability_corrections': 1,
          'test_portability_note': 'Windows static/shared passed on 07e30f13. Air first compile failed because the Direct test omitted <algorithm>. 4c7d51c8 adds that header only; identical product sources then passed on Air/Mini. Original failure retained in w1-raw.zip.',
          'windows_archive': archive.name, 'windows_archive_sha256': sha(archive),
          'not_claimed': ['Scan/Scatter three-delivery journey', 'complete C1', 'global package gates', 'P1']}
write_json(output / 'result.json', result)
shutil.copy2(task / 'implementation-loc.json', output / 'implementation-loc.json')
print(json.dumps({'candidate': candidate, 'native_cases': result['cases'], 'product_corrections': 0,
                  'windows_archive_sha256': sha(archive)}))
