#include <hyle/graph/vulkan.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <span>
#include <string>
#include <vector>

namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace gv = g::vulkan;
using hyle::Result;
using hyle::Status;
constexpr std::size_t width = 2048;
constexpr std::size_t table_rows = 34;
constexpr std::size_t sequence = 257;
constexpr std::size_t outputs = 7;
using Published = std::array<v::Tensor, outputs>;
using Snapshot = std::array<std::vector<std::byte>, outputs>;

template <class T>
Result<std::vector<T>> read(const std::filesystem::path &path,
                            std::size_t count) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  if (!file || file.tellg() != static_cast<std::streamoff>(count * sizeof(T)))
    return std::unexpected(Status::DataLoss("fixture byte size"));
  std::vector<T> result(count);
  file.seekg(0);
  if (!file.read(reinterpret_cast<char *>(result.data()),
                 static_cast<std::streamsize>(count * sizeof(T))))
    return std::unexpected(Status::DataLoss("fixture read"));
  return result;
}

float decode(std::uint16_t bits) {
  return std::bit_cast<float>(static_cast<std::uint32_t>(bits) << 16);
}
std::uint16_t round_bf16(double value) {
  auto raw = std::bit_cast<std::uint32_t>(static_cast<float>(value));
  raw += 0x7fffU + ((raw >> 16) & 1U);
  return static_cast<std::uint16_t>(raw >> 16);
}
std::uint16_t ordered(std::uint16_t bits) {
  return static_cast<std::uint16_t>((bits & 0x8000U) ? ~bits : bits | 0x8000U);
}
std::uint16_t from_order(std::uint16_t bits) {
  return static_cast<std::uint16_t>((bits & 0x8000U) ? bits & 0x7fffU : ~bits);
}
bool update_allowed(std::uint16_t actual, std::uint16_t expected) {
  return std::isfinite(decode(actual)) &&
         std::abs(static_cast<int>(ordered(actual)) - ordered(expected)) <= 1 &&
         std::abs(static_cast<double>(decode(actual)) - decode(expected)) <=
             0.008 * std::abs(decode(expected)) + 2e-7;
}
std::uint16_t add_bf16(std::uint16_t left, std::uint16_t right) {
  const float sum = decode(left) + decode(right);
  return round_bf16(sum);
}

struct Fixtures {
  std::vector<std::uint16_t> table;
  std::vector<float> scale;
  std::vector<std::int32_t> tokens;
  std::vector<double> oracle;
  std::vector<std::uint16_t> update, low, high;
};
Result<Fixtures> load(const std::filesystem::path &directory) {
  Fixtures f;
  HYLE_ASSIGN_OR_RETURN(f.table, read<std::uint16_t>(directory / "table.bf16",
                                                     table_rows * width));
  HYLE_ASSIGN_OR_RETURN(f.scale,
                        read<float>(directory / "gemma_scale.f32", width));
  HYLE_ASSIGN_OR_RETURN(
      f.tokens, read<std::int32_t>(directory / "token_rows.i32", sequence));
  HYLE_ASSIGN_OR_RETURN(f.oracle, read<double>(directory / "update_oracle.f64",
                                               table_rows * width));
  for (const double value : f.oracle) {
    const auto center = round_bf16(value);
    const auto code = ordered(center);
    const auto lower = from_order(static_cast<std::uint16_t>(code - 1U));
    const auto upper = from_order(static_cast<std::uint16_t>(code + 1U));
    f.update.push_back(center);
    f.low.push_back(update_allowed(lower, center) ? lower : center);
    f.high.push_back(update_allowed(upper, center) ? upper : center);
  }
  return f;
}

template <class T>
Result<std::vector<T>> download(const v::Context &context,
                                const v::Tensor &tensor, c::DataType type,
                                std::size_t count) {
  if (tensor.description().data_type() != type ||
      tensor.description().element_count().value() != count)
    return std::unexpected(Status::DataLoss("published result description"));
  std::vector<T> actual(count);
  HYLE_RETURN_IF_ERROR(
      context.download(tensor, std::as_writable_bytes(std::span(actual))));
  return actual;
}
Result<Snapshot> snapshot(const v::Context &context, const Published &tensors) {
  Snapshot result;
  for (std::size_t i = 0; i < outputs; ++i) {
    const auto count = tensors[i].description().element_count().value();
    const auto size = i >= 2 && i <= 4 ? 2U : 4U;
    result[i].resize(count * size);
    HYLE_RETURN_IF_ERROR(context.download(tensors[i], result[i]));
  }
  return result;
}
Status unchanged(const v::Context &context, const Published &tensors,
                 const Snapshot &before) {
  HYLE_ASSIGN_OR_RETURN(auto now, snapshot(context, tensors));
  return now == before ? Status::Ok()
                       : Status::DataLoss("old result overwritten");
}

struct Stage {
  v::Program program;
  std::array<std::array<v::Invocation, 3>, 2> slots;
  Status allocate() {
    for (auto &stream : slots) {
      for (auto &slot : stream) {
        HYLE_ASSIGN_OR_RETURN(slot, program.create_invocation());
      }
    }
    return Status::Ok();
  }
  Result<std::vector<v::Tensor>> execute(std::size_t stream, std::size_t phase,
                                         std::span<const v::Tensor> inputs) {
    const auto selected = phase == 0 ? 0U : 1U + (phase - 1U) % 2U;
    if (phase == 0) {
      HYLE_RETURN_IF_ERROR(slots[stream][0].bind(inputs));
    } else {
      // Both working slots receive the actual new inputs. Releasing stale
      // downstream owners lets the other producer slot be reused next step.
      HYLE_RETURN_IF_ERROR(slots[stream][1].bind(inputs));
      HYLE_RETURN_IF_ERROR(slots[stream][2].bind(inputs));
    }
    HYLE_ASSIGN_OR_RETURN(auto pending, slots[stream][selected].submit());
    HYLE_ASSIGN_OR_RETURN(auto ready, pending.wait());
    const auto values = ready.get()->tensors();
    return std::vector<v::Tensor>(values.begin(), values.end());
  }
  template <class... Inputs>
  Result<v::Tensor> one(std::size_t stream, std::size_t phase,
                        const Inputs &...inputs) {
    const std::array<v::Tensor, sizeof...(Inputs)> args{inputs...};
    HYLE_ASSIGN_OR_RETURN(auto result, execute(stream, phase, args));
    if (result.size() != 1)
      return std::unexpected(Status::DataLoss("Direct single output"));
    return result[0];
  }
};

constexpr c::RmsNorm norm{.epsilon = 1e-6F,
                          .accumulation_type = c::DataType::kFloat32};
constexpr c::GatedActivation gate{.activation = c::GatedActivationKind::kSilu,
                                  .inputs = c::GatedInputKind::kSeparate};
constexpr c::Scatter assign{.axis = 0, .kind = c::ScatterKind::kAssign};
constexpr c::Scatter add{.axis = 0, .kind = c::ScatterKind::kAdd};

Result<v::Program> graph_program(const v::Context &context,
                                 const v::Tensor &table, const v::Tensor &scale,
                                 const c::TensorDesc &ids_desc,
                                 const c::TensorDesc &float_desc) {
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto delta, builder.input(ids_desc));
  HYLE_ASSIGN_OR_RETURN(auto state, builder.input(table.description()));
  HYLE_ASSIGN_OR_RETURN(auto floats, builder.input(float_desc));
  HYLE_ASSIGN_OR_RETURN(auto source, builder.constant(table.description()));
  HYLE_ASSIGN_OR_RETURN(auto weights, builder.constant(scale.description()));
  HYLE_ASSIGN_OR_RETURN(auto indices, builder.add(c::Scan{-1, false}, delta));
  HYLE_ASSIGN_OR_RETURN(auto previous, builder.add(c::Scan{-1, true}, delta));
  HYLE_ASSIGN_OR_RETURN(auto selected,
                        builder.add(c::Gather{0}, source, indices));
  HYLE_ASSIGN_OR_RETURN(auto wide,
                        builder.add(c::Cast{c::DataType::kFloat32}, selected));
  HYLE_ASSIGN_OR_RETURN(auto normalized, builder.add(norm, wide, weights));
  HYLE_ASSIGN_OR_RETURN(auto gated, builder.add(gate, normalized, wide));
  HYLE_ASSIGN_OR_RETURN(
      auto residual, builder.add(c::Binary{c::BinaryKind::kAdd}, gated, wide));
  HYLE_ASSIGN_OR_RETURN(auto updates,
                        builder.add(c::Cast{c::DataType::kBFloat16}, residual));
  HYLE_ASSIGN_OR_RETURN(auto assigned,
                        builder.add(assign, state, indices, updates));
  HYLE_ASSIGN_OR_RETURN(auto updated,
                        builder.add(add, assigned, indices, updates));
  HYLE_ASSIGN_OR_RETURN(auto gathered,
                        builder.add(c::Gather{0}, updated, indices));
  HYLE_ASSIGN_OR_RETURN(auto inclusive,
                        builder.add(c::Scan{-1, false}, floats));
  HYLE_ASSIGN_OR_RETURN(auto exclusive, builder.add(c::Scan{-1, true}, floats));
  for (const auto value :
       {indices, previous, updates, updated, gathered, inclusive, exclusive})
    HYLE_RETURN_IF_ERROR(builder.publish(value));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  gv::CompileReport report;
  HYLE_ASSIGN_OR_RETURN(auto program,
                        gv::compile(context, graph, std::array{table, scale},
                                    {.report = &report}));
  if (!report.status.ok() || report.nodes.size() != 13 ||
      report.managed_region_count == 0)
    return std::unexpected(
        Status::DataLoss("ordinary Graph did not bind native regions"));
  std::printf("GRAPH compiled nodes=%zu managed_regions=%zu\n",
              report.nodes.size(), report.managed_region_count);
  return program;
}

struct Pipeline {
  bool graph = false;
  std::array<Stage, 13> stages;
  Stage whole;
  Status prepare(const v::Context &context, const v::Tensor &table,
                 const v::Tensor &scale, const c::TensorDesc &ids,
                 const c::TensorDesc &floats) {
    if (graph) {
      HYLE_ASSIGN_OR_RETURN(whole.program,
                            graph_program(context, table, scale, ids, floats));
      return whole.allocate();
    }
    HYLE_ASSIGN_OR_RETURN(stages[0].program,
                          v::prepare(context, c::Scan{-1, false}, ids));
    HYLE_ASSIGN_OR_RETURN(stages[1].program,
                          v::prepare(context, c::Scan{-1, true}, ids));
    HYLE_ASSIGN_OR_RETURN(stages[2].program,
                          v::prepare(context, c::Gather{0}, table, ids));
    HYLE_ASSIGN_OR_RETURN(
        stages[3].program,
        v::prepare(context, c::Cast{c::DataType::kFloat32},
                   stages[2].program.output_descriptions()[0]));
    const auto wide = stages[3].program.output_descriptions()[0];
    HYLE_ASSIGN_OR_RETURN(stages[4].program,
                          v::prepare(context, norm, wide, scale));
    HYLE_ASSIGN_OR_RETURN(stages[5].program,
                          v::prepare(context, gate, wide, wide));
    HYLE_ASSIGN_OR_RETURN(
        stages[6].program,
        v::prepare(context, c::Binary{c::BinaryKind::kAdd}, wide, wide));
    HYLE_ASSIGN_OR_RETURN(
        stages[7].program,
        v::prepare(context, c::Cast{c::DataType::kBFloat16}, wide));
    const auto updates = stages[7].program.output_descriptions()[0];
    HYLE_ASSIGN_OR_RETURN(
        stages[8].program,
        v::prepare(context, assign, table.description(), ids, updates));
    HYLE_ASSIGN_OR_RETURN(
        stages[9].program,
        v::prepare(context, add, table.description(), ids, updates));
    HYLE_ASSIGN_OR_RETURN(
        stages[10].program,
        v::prepare(context, c::Gather{0}, table.description(), ids));
    HYLE_ASSIGN_OR_RETURN(stages[11].program,
                          v::prepare(context, c::Scan{-1, false}, floats));
    HYLE_ASSIGN_OR_RETURN(stages[12].program,
                          v::prepare(context, c::Scan{-1, true}, floats));
    for (auto &stage : stages)
      HYLE_RETURN_IF_ERROR(stage.allocate());
    return Status::Ok();
  }
  Result<Published> execute(std::size_t stream, std::size_t phase,
                            const v::Tensor &delta, const v::Tensor &state,
                            const v::Tensor &floats) {
    Published out;
    if (graph) {
      HYLE_ASSIGN_OR_RETURN(
          auto result,
          whole.execute(stream, phase, std::array{delta, state, floats}));
      if (result.size() != outputs)
        return std::unexpected(
            Status::DataLoss("Graph published output count"));
      std::copy(result.begin(), result.end(), out.begin());
      return out;
    }
    HYLE_ASSIGN_OR_RETURN(out[0], stages[0].one(stream, phase, delta));
    HYLE_ASSIGN_OR_RETURN(out[1], stages[1].one(stream, phase, delta));
    HYLE_ASSIGN_OR_RETURN(auto selected, stages[2].one(stream, phase, out[0]));
    HYLE_ASSIGN_OR_RETURN(auto wide, stages[3].one(stream, phase, selected));
    HYLE_ASSIGN_OR_RETURN(auto normalized, stages[4].one(stream, phase, wide));
    HYLE_ASSIGN_OR_RETURN(auto gated,
                          stages[5].one(stream, phase, normalized, wide));
    HYLE_ASSIGN_OR_RETURN(auto residual,
                          stages[6].one(stream, phase, gated, wide));
    HYLE_ASSIGN_OR_RETURN(out[2], stages[7].one(stream, phase, residual));
    HYLE_ASSIGN_OR_RETURN(auto assigned,
                          stages[8].one(stream, phase, state, out[0], out[2]));
    HYLE_ASSIGN_OR_RETURN(
        out[3], stages[9].one(stream, phase, assigned, out[0], out[2]));
    HYLE_ASSIGN_OR_RETURN(out[4],
                          stages[10].one(stream, phase, out[3], out[0]));
    HYLE_ASSIGN_OR_RETURN(out[5], stages[11].one(stream, phase, floats));
    HYLE_ASSIGN_OR_RETURN(out[6], stages[12].one(stream, phase, floats));
    return out;
  }
};

struct Expected {
  std::vector<std::uint16_t> exact, low, high;
};
Status verify(const v::Context &context, const Published &out,
              const Fixtures &f, std::span<const std::int32_t> ids,
              std::span<const float> floats, std::size_t tokens,
              Expected &state) {
  HYLE_ASSIGN_OR_RETURN(
      auto inclusive,
      download<std::int32_t>(context, out[0], c::DataType::kInt32, ids.size()));
  HYLE_ASSIGN_OR_RETURN(
      auto exclusive,
      download<std::int32_t>(context, out[1], c::DataType::kInt32, ids.size()));
  for (std::size_t row = 0; row < ids.size(); ++row)
    if (inclusive[row] != ids[row] ||
        exclusive[row] != (row % tokens == 0 ? 0 : ids[row - 1]))
      return Status::DataLoss("I32 inclusive/exclusive prefix mismatch");
  HYLE_ASSIGN_OR_RETURN(auto updates,
                        download<std::uint16_t>(context, out[2],
                                                c::DataType::kBFloat16,
                                                ids.size() * width));
  for (std::size_t row = 0; row < ids.size(); ++row) {
    const auto target = static_cast<std::size_t>(ids[row]) * width;
    for (std::size_t column = 0; column < width; ++column) {
      const auto index = row * width + column;
      if (!update_allowed(updates[index], f.update[target + column])) {
        std::fprintf(
            stderr,
            "update mismatch row=%zu column=%zu actual=%.9g expected=%.9g\n",
            row, column, static_cast<double>(decode(updates[index])),
            static_cast<double>(decode(f.update[target + column])));
        return Status::DataLoss(
            "independent FP64 norm/gate/residual oracle mismatch");
      }
      state.exact[target + column] = updates[index];
      state.low[target + column] = f.low[target + column];
      state.high[target + column] = f.high[target + column];
    }
  }
  for (std::size_t row = 0; row < ids.size(); ++row) {
    const auto target = static_cast<std::size_t>(ids[row]) * width;
    for (std::size_t column = 0; column < width; ++column) {
      state.exact[target + column] =
          add_bf16(state.exact[target + column], updates[row * width + column]);
      state.low[target + column] =
          add_bf16(state.low[target + column], f.low[target + column]);
      state.high[target + column] =
          add_bf16(state.high[target + column], f.high[target + column]);
    }
  }
  HYLE_ASSIGN_OR_RETURN(auto actual,
                        download<std::uint16_t>(context, out[3],
                                                c::DataType::kBFloat16,
                                                table_rows * width));
  for (std::size_t i = 0; i < actual.size(); ++i)
    if (actual[i] != state.exact[i] || !std::isfinite(decode(actual[i])) ||
        decode(actual[i]) < decode(state.low[i]) ||
        decode(actual[i]) > decode(state.high[i])) {
      std::fprintf(stderr,
                   "state mismatch index=%zu actual=%04x exact=%04x "
                   "interval=[%.9g, %.9g]\n",
                   i, static_cast<unsigned>(actual[i]),
                   static_cast<unsigned>(state.exact[i]),
                   static_cast<double>(decode(state.low[i])),
                   static_cast<double>(decode(state.high[i])));
      return Status::DataLoss(
          "ordered state or independent propagated interval mismatch");
    }
  HYLE_ASSIGN_OR_RETURN(auto selected,
                        download<std::uint16_t>(context, out[4],
                                                c::DataType::kBFloat16,
                                                ids.size() * width));
  for (std::size_t row = 0; row < ids.size(); ++row)
    if (!std::equal(selected.begin() + row * width,
                    selected.begin() + (row + 1) * width,
                    state.exact.begin() +
                        static_cast<std::size_t>(ids[row]) * width))
      return Status::DataLoss("updated state Gather is not bit exact");
  for (std::size_t kind = 0; kind < 2; ++kind) {
    HYLE_ASSIGN_OR_RETURN(auto actual_scan,
                          download<float>(context, out[5 + kind],
                                          c::DataType::kFloat32, ids.size()));
    for (std::size_t batch_start = 0; batch_start < ids.size();
         batch_start += tokens) {
      double sum = 0, absolute = 0;
      for (std::size_t t = 0; t < tokens; ++t) {
        const auto i = batch_start + t;
        if (kind == 0) {
          sum += floats[i];
          absolute += std::abs(floats[i]);
        }
        if (!std::isfinite(actual_scan[i]) ||
            std::abs(actual_scan[i] - sum) > 3e-6 * (std::max)(1.0, absolute))
          return Status::DataLoss(
              "independent FP64 floating Scan oracle mismatch");
        if (kind == 1) {
          sum += floats[i];
          absolute += std::abs(floats[i]);
        }
      }
    }
  }
  return Status::Ok();
}

Status checked_failure(const v::Context &context, Pipeline &pipeline,
                       const v::Tensor &delta, const v::Tensor &state,
                       const v::Tensor &floats, const v::Tensor &valid_ids,
                       std::span<const std::int32_t> good_delta) {
  std::vector<std::int32_t> invalid(good_delta.begin(), good_delta.end());
  invalid[0] = -1;
  HYLE_ASSIGN_OR_RETURN(
      auto bad,
      context.upload(delta.description(), std::as_bytes(std::span(invalid))));
  auto &program =
      pipeline.graph ? pipeline.whole.program : pipeline.stages[2].program;
  HYLE_ASSIGN_OR_RETURN(auto slot, program.create_invocation());
  const std::vector<v::Tensor> bad_inputs =
      pipeline.graph ? std::vector{bad, state, floats} : std::vector{bad};
  HYLE_RETURN_IF_ERROR(slot.bind(std::span<const v::Tensor>(bad_inputs)));
  HYLE_ASSIGN_OR_RETURN(auto pending, slot.submit());
  auto result = pending.wait();
  if (result || !result.error().IsOutOfRange())
    return Status::DataLoss("negative index did not fail OutOfRange");
  if (!slot.bind(std::span<const v::Tensor>(bad_inputs)).IsOutOfRange())
    return Status::DataLoss("failed invocation was not retired");
  HYLE_ASSIGN_OR_RETURN(auto fresh, program.create_invocation());
  const std::vector<v::Tensor> good_inputs =
      pipeline.graph ? std::vector{delta, state, floats}
                     : std::vector{valid_ids};
  HYLE_RETURN_IF_ERROR(fresh.bind(std::span<const v::Tensor>(good_inputs)));
  HYLE_ASSIGN_OR_RETURN(auto good, fresh.submit());
  HYLE_ASSIGN_OR_RETURN(auto ready, good.wait());
  if (ready.get()->tensors().empty())
    return Status::DataLoss("fresh invocation produced no result");
  return Status::Ok();
}

Status run_case(const Fixtures &f, std::size_t batches, std::size_t tokens,
                bool graph) {
  hyle::mem::QuotaAllocator quota(hyle::mem::system_allocator(),
                                  512 * 1024 * 1024);
  std::size_t cold_used = 0, warm_used = 0;
  {
    HYLE_ASSIGN_OR_RETURN(
        auto context,
        v::Context::create({.validation = true, .memory_quota = &quota}));
    HYLE_ASSIGN_OR_RETURN(
        auto table_desc,
        c::TensorDesc::dense(c::DataType::kBFloat16,
                             std::array<std::int64_t, 2>{table_rows, width}));
    HYLE_ASSIGN_OR_RETURN(
        auto scale_desc,
        c::TensorDesc::dense(c::DataType::kFloat32,
                             std::array<std::int64_t, 1>{width}));
    const std::array<std::int64_t, 2> dimensions{
        static_cast<std::int64_t>(batches), static_cast<std::int64_t>(tokens)};
    HYLE_ASSIGN_OR_RETURN(
        auto ids_desc, c::TensorDesc::dense(c::DataType::kInt32, dimensions));
    HYLE_ASSIGN_OR_RETURN(
        auto floats_desc,
        c::TensorDesc::dense(c::DataType::kFloat32, dimensions));
    HYLE_ASSIGN_OR_RETURN(
        auto table,
        context.upload(table_desc, std::as_bytes(std::span(f.table))));
    HYLE_ASSIGN_OR_RETURN(
        auto scale,
        context.upload(scale_desc, std::as_bytes(std::span(f.scale))));
    Pipeline pipeline;
    pipeline.graph = graph;
    HYLE_RETURN_IF_ERROR(
        pipeline.prepare(context, table, scale, ids_desc, floats_desc));
    std::array<v::Tensor, 2> initial, state, deltas, scan_inputs;
    std::array<Expected, 2> expected;
    std::array<Published, 2> retained;
    std::array<Snapshot, 2> retained_bytes;
    std::array<std::vector<std::int32_t>, 2> host_delta, host_ids;
    for (std::size_t stream = 0; stream < 2; ++stream) {
      HYLE_ASSIGN_OR_RETURN(
          initial[stream],
          context.upload(table_desc, std::as_bytes(std::span(f.table))));
      state[stream] = initial[stream];
      expected[stream] = {f.table, f.table, f.table};
      HYLE_ASSIGN_OR_RETURN(deltas[stream], context.allocate(ids_desc));
      HYLE_ASSIGN_OR_RETURN(scan_inputs[stream], context.allocate(floats_desc));
    }
    cold_used = quota.used();
    for (std::size_t phase = 0; phase < 5; ++phase) {
      for (std::size_t stream = 0; stream < 2; ++stream) {
        std::fprintf(stderr, "BEGIN B=%zu T=%zu path=%s stream=%zu step=%zu\n",
                     batches, tokens, graph ? "Graph" : "Direct", stream,
                     phase);
        auto &ids = host_ids[stream];
        auto &delta = host_delta[stream];
        ids.resize(batches * tokens);
        delta.resize(ids.size());
        std::vector<float> floats(ids.size());
        for (std::size_t b = 0; b < batches; ++b)
          for (std::size_t t = 0; t < tokens; ++t) {
            const auto row = b * tokens + t;
            ids[row] =
                f.tokens[(b * 17 + t + phase * 3 + stream * 11) % sequence];
            delta[row] = ids[row] - (t == 0 ? 0 : ids[row - 1]);
            floats[row] = f.scale[(static_cast<std::size_t>(ids[row]) * 31 +
                                   phase * 7 + stream * 13) %
                                  width];
          }
        HYLE_RETURN_IF_ERROR(
            context.upload(deltas[stream], std::as_bytes(std::span(delta))));
        HYLE_RETURN_IF_ERROR(context.upload(scan_inputs[stream],
                                            std::as_bytes(std::span(floats))));
        HYLE_ASSIGN_OR_RETURN(
            auto result, pipeline.execute(stream, phase, deltas[stream],
                                          state[stream], scan_inputs[stream]));
        HYLE_RETURN_IF_ERROR(
            verify(context, result, f, ids, floats, tokens, expected[stream]));
        state[stream] = result[3];
        if (phase == 0) {
          retained[stream] = result;
          HYLE_ASSIGN_OR_RETURN(retained_bytes[stream],
                                snapshot(context, result));
        }
        for (std::size_t prior = 0; prior < 2; ++prior)
          if (retained[prior][0])
            HYLE_RETURN_IF_ERROR(
                unchanged(context, retained[prior], retained_bytes[prior]));
      }
      if (phase == 2)
        warm_used = quota.used();
      if (phase > 2 && quota.used() != warm_used)
        return Status::DataLoss(
            "native quota changed after all working slots warmed");
    }
    HYLE_ASSIGN_OR_RETURN(
        auto ids,
        context.upload(ids_desc, std::as_bytes(std::span(host_ids[0]))));
    HYLE_RETURN_IF_ERROR(checked_failure(context, pipeline, deltas[0], state[0],
                                         scan_inputs[0], ids, host_delta[0]));
    HYLE_ASSIGN_OR_RETURN(auto original,
                          download<std::uint16_t>(context, table,
                                                  c::DataType::kBFloat16,
                                                  f.table.size()));
    if (original != f.table)
      return Status::DataLoss("shared immutable embedding table changed");
    HYLE_RETURN_IF_ERROR(context.close());
    for (std::size_t stream = 0; stream < 2; ++stream)
      HYLE_RETURN_IF_ERROR(
          unchanged(context, retained[stream], retained_bytes[stream]));
  }
  if (quota.used() != 0)
    return Status::DataLoss("native quota retained after owner destruction");
  std::printf("PASS B=%zu T=%zu path=%s streams=2 steps=5 slots_per_stream=3 "
              "cold=%zu warm=%zu peak=%zu released=all\n",
              batches, tokens, graph ? "Graph" : "Direct", cold_used, warm_used,
              quota.peak());
  return Status::Ok();
}

Status consume(const std::filesystem::path &directory) {
  static_assert(std::endian::native == std::endian::little);
  HYLE_ASSIGN_OR_RETURN(auto fixtures, load(directory));
  for (const auto dimensions : std::array<std::array<std::size_t, 2>, 7>{
           {{1, 1}, {1, 17}, {1, 128}, {1, 23}, {1, 129}, {2, 23}, {2, 129}}})
    for (bool graph : {false, true})
      HYLE_RETURN_IF_ERROR(
          run_case(fixtures, dimensions[0], dimensions[1], graph));
  std::puts("PASS Y31 real BF16 Direct/Graph fragment, state feedback and "
            "checked failure; not full C1/model/performance acceptance");
  return Status::Ok();
}
int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  try {
    const auto status = consume(std::filesystem::path(argv[1]));
    if (!status.ok()) {
      std::fprintf(stderr, "%.*s\n", static_cast<int>(status.message().size()),
                   status.message().data());
      return 1;
    }
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "%s\n", error.what());
    return 1;
  }
}
