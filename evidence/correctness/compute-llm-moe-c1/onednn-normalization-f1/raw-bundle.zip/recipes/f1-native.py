import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('C:/public/project-hyle/hyle')
BUILD = Path('C:/hyle-scratch/active-cpu/static')
LOGS = ROOT / '.scratch/validation/onednn-aa'
linkage = sys.argv[1]
assert linkage in ('static', 'shared')
resume_graph = sys.argv[2:] == ['graph-resume']
out = LOGS / ('f1-' + linkage + ('-graph-resume' if resume_graph else ''))
out.mkdir(exist_ok=False)
ctypes.WinDLL('kernel32').SetErrorMode(0x8003)
changes = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=ROOT)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
subprocess.run([sys.executable, 'scripts/validation-select.py', 'plan', '--base', '40a55333',
                '--candidate', 'WORKTREE', '--context', str(LOGS / 'remaining-context.json'),
                '--output', str(out / 'plan.json')], cwd=ROOT, check=True)
plan = json.loads((out / 'plan.json').read_text(encoding='utf-8'))
record = {'head': head, 'diff_sha256': hashlib.sha256(changes).hexdigest(), 'linkage': linkage,
          'execution': 'manual selected commands; fixed build; no selector cache receipt',
          'status': 'RUNNING', 'commands': []}
def save():
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
def stage_crt():
    redist = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
    runtime = sorted(p / 'x64/Microsoft.VC145.CRT' for p in redist.iterdir()
                     if (p / 'x64/Microsoft.VC145.CRT').is_dir())[-1]
    for library in runtime.glob('*.dll'):
        shutil.copy2(library, BUILD / 'bin' / library.name)
save()
for gate in plan['selected_gates']:
    if gate['kind'] not in ('maintenance', 'build', 'correctness'):
        continue
    if resume_graph and gate['id'] not in ('docs', 'closure', 'factor:graph_route_cpu'):
        continue
    for i, template in enumerate(gate['commands']):
        assert subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=ROOT) == changes
        command = [str(sys.executable) if x == '{python}' else x.replace('{build}', str(BUILD)) for x in template]
        if command[0] in ('cmake', 'ctest'):
            command[0] = 'C:/Program Files/CMake/bin/' + command[0] + '.exe'
        if gate['id'] == 'configure':
            command += ['-DHYLE_STATIC=' + ('ON' if linkage == 'static' else 'OFF'),
                        '-DHYLE_COMPUTE_CPU=ON', '-DHYLE_COMPUTE_CUDA=OFF',
                        '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_COMPUTE_VULKAN=OFF',
                        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON']
        env = os.environ.copy()
        if Path(command[0]).stem == 'ctest':
            stage_crt()
            env.pop('PATH', None)
            command += ['--parallel', '1', '--output-junit', str(out / (gate['id'].replace(':', '-') + '.xml'))]
        log = out / (gate['id'].replace(':', '-') + '-' + str(i) + '.log')
        print('START ' + gate['id'] + ' ' + str(i), flush=True)
        with log.open('w', encoding='utf-8') as stream:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
        record['commands'].append({'gate': gate['id'], 'argv': command, 'exit_code': result.returncode,
                                   'log': log.name, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
        save()
        if result.returncode:
            record['status'] = 'FAIL'
            save()
            print(log.read_text(encoding='utf-8', errors='replace')[-7000:])
            raise SystemExit(result.returncode)
        if Path(command[0]).stem == 'ctest':
            shutil.copy2(BUILD / 'Testing/Temporary/LastTest.log', out / (gate['id'].replace(':', '-') + '-LastTest.log'))
        print('PASS ' + gate['id'] + ' ' + str(i), flush=True)
assert subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=ROOT) == changes
shutil.copy2(BUILD / 'CMakeCache.txt', out / 'CMakeCache.txt')
record['status'] = 'PASS'
record['remaining'] = 'Graph three deliveries, WSL, stable rules and qualified corrected P1 remain pending'
save()
