$ErrorActionPreference = 'Stop'
$repoRoot = 'C:\public\project-hyle\hyle'
$recordRoot = Join-Path $repoRoot '.scratch\validation\onednn-aa'
$receipt = Get-Content -LiteralPath (Join-Path $recordRoot 'f1-source.json') -Raw | ConvertFrom-Json
$archive = [IO.Path]::GetFullPath([string]$receipt.archive)
if ($archive -ne 'C:\hyle-scratch\active-cpu\candidate.tar') { throw 'Unexpected transfer path' }
$remoteHash = ((Get-Content -LiteralPath (Join-Path $recordRoot 'f1-wsl\archive.sha256') -Raw) -split '\s+')[0]
if ($remoteHash -ne $receipt.archive_sha256) { throw 'WSL did not receive this exact archive' }
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receipt.archive_sha256) {
  throw 'Transfer identity changed before cleanup'
}
$bytes = (Get-Item -LiteralPath $archive).Length
Remove-Item -LiteralPath $archive
@{path=$archive; logical_bytes=$bytes; sha256=$receipt.archive_sha256; reason='WSL validation finished; exact received archive verified'} |
  ConvertTo-Json | Set-Content -LiteralPath (Join-Path $recordRoot 'f1-transfer-cleanup.json') -Encoding utf8
