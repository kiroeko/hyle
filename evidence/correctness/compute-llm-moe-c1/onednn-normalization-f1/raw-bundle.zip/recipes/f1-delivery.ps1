$ErrorActionPreference = 'Stop'
$repoRoot = 'C:\public\project-hyle\hyle'
$scratchRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-cpu\aa')
$deliveryRoot = [IO.Path]::GetFullPath((Join-Path $scratchRoot 'selected-graph'))
$logRoot = Join-Path $repoRoot '.scratch\validation\onednn-aa'
if ($deliveryRoot -ne 'C:\hyle-scratch\active-cpu\aa\selected-graph' -or
    -not $deliveryRoot.StartsWith($scratchRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Invalid fixed delivery workspace'
}
$head = (& git -C $repoRoot rev-parse HEAD).Trim()
if (& git -C $repoRoot status --porcelain) { throw 'Delivery requires a clean implementation snapshot' }
# The original smoke removes this exact generated SDK/consumer root. Its prior
# evidence is archived; retain a receipt before rotating the fixed workspace.
if (Test-Path -LiteralPath $deliveryRoot) {
  $items = @((Get-Item -LiteralPath $deliveryRoot)) + @(Get-ChildItem -LiteralPath $deliveryRoot -Recurse -Force)
  if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) {
    throw 'Refuse recursive smoke cleanup through a reparse point'
  }
  $files = @($items | Where-Object { -not $_.PSIsContainer })
  @{path=$deliveryRoot; files=$files.Count; logical_bytes=($files | Measure-Object Length -Sum).Sum; candidate=$head} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $logRoot 'f1-delivery-rotation.json') -Encoding utf8
}
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CMAKE_TOOLCHAIN_FILE = Join-Path $logRoot 'delivery-toolchain.cmake'
$env:VSLANG = '1033'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleNormF1DeliveryMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleNormF1DeliveryMode]::SetErrorMode(0x8003) | Out-Null
& (Join-Path $repoRoot 'scripts\hyle-windows.ps1') -Action SelectedComponentSmoke -Component graph -SmokeRoot $scratchRoot -ExtraArgs @('-DCMAKE_CTEST_COMMAND=C:/public/project-hyle/hyle/.scratch/validation/onednn-aa/delivery-ctest.cmd') > (Join-Path $logRoot 'f1-delivery.log') 2>&1
$result = $LASTEXITCODE
if ((& git -C $repoRoot rev-parse HEAD).Trim() -ne $head -or (& git -C $repoRoot status --porcelain)) {
  throw 'Implementation snapshot changed during delivery'
}
@{candidate=$head; exit_code=$result; root=$deliveryRoot; log='f1-delivery.log'} |
  ConvertTo-Json | Set-Content -LiteralPath (Join-Path $logRoot 'f1-delivery-result.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $logRoot 'f1-delivery.log') -Tail 26
exit $result
