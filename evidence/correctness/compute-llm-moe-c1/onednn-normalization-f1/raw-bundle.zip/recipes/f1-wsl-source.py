import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('C:/public/project-hyle/hyle')
archive = Path('C:/hyle-scratch/active-cpu/candidate.tar')
assert not archive.exists(), 'Do not overwrite an existing transfer'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
diff = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=root)
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z', 'HEAD'], cwd=root).decode().split('\0')
changed = [name for name in changed if name]
assert all((root / name).is_file() for name in changed)
subprocess.run(['git', 'archive', '--format=tar', '--output', str(archive), head], cwd=root, check=True)
with tarfile.open(archive, 'a') as stream:
    for name in changed:
        stream.add(root / name, arcname=name, recursive=False)
with tarfile.open(archive) as stream:
    for name in changed:
        assert stream.extractfile(name).read() == (root / name).read_bytes()
assert subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=root) == diff
record = {'head': head, 'diff_sha256': hashlib.sha256(diff).hexdigest(),
          'archive': str(archive), 'archive_bytes': archive.stat().st_size,
          'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'worktree_overlays': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in changed}}
(root / '.scratch/validation/onednn-aa/f1-source.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8', newline='\n')
(root / '.scratch/validation/onednn-aa/f1-source.diff').write_bytes(diff)
print(json.dumps(record))
