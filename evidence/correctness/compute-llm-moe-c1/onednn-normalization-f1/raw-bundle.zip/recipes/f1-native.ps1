param([ValidateSet('static','shared')][string]$Linkage = 'static', [switch]$ResumeGraph)
$ErrorActionPreference = 'Stop'
$repoRoot = 'C:\public\project-hyle\hyle'
$recordRoot = Join-Path $repoRoot '.scratch\validation\onednn-aa'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:VSLANG = '1033'
. (Join-Path $repoRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-cpu\static' -ExtraArgs @('--target','help') > (Join-Path $recordRoot ('f1-' + $Linkage + '-environment.log')) 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$arguments = @((Join-Path $recordRoot 'f1-native.py'), $Linkage)
if ($ResumeGraph) { $arguments += 'graph-resume' }
& python @arguments
exit $LASTEXITCODE
