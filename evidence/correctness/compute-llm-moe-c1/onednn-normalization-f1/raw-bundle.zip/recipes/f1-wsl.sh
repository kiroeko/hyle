#!/usr/bin/env bash
set -euo pipefail
task_root=/root/hyle-scratch/active-cpu-z
source_root="$task_root/source"
build_root="$task_root/build"
log_root=/mnt/c/public/project-hyle/hyle/.scratch/validation/onednn-aa/f1-wsl
archive=/mnt/c/hyle-scratch/active-cpu/candidate.tar
test "$(realpath -e "$source_root")" = "$task_root/source"
test "$(realpath -e "$build_root")" = "$task_root/build"
mkdir "$log_root"
sha256sum "$archive" > "$log_root/archive.sha256"
staging=$(mktemp -d "$task_root/f1-source.XXXXXX")
tar -xf "$archive" -C "$staging"
# Checksum sync preserves unchanged build inputs' mtimes. Validation source is disposable.
rsync -rclp --delete "$staging/" "$source_root/"
python3 - "$staging" "$task_root" <<'PY'
from pathlib import Path
import shutil,sys
target=Path(sys.argv[1]).resolve(strict=True)
parent=Path(sys.argv[2]).resolve(strict=True)
assert target.parent == parent and target.name.startswith('f1-source.')
shutil.rmtree(target)
PY
cmake -S "$source_root" -B "$build_root" -G Ninja \
  -DCMAKE_C_COMPILER=gcc-14 -DCMAKE_CXX_COMPILER=g++-14 \
  -DCMAKE_BUILD_TYPE=Release -DHYLE_WERROR=ON -DHYLE_STATIC=ON \
  -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
  -DHYLE_TRACE=OFF -DHYLE_SANITIZER=off -DHYLE_TEST_INSTRUMENTATION=OFF \
  -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_ONEDNN=ON \
  -DHYLE_DEP_SOURCE_CACHE=/root/.cache/hyle/dependencies/v1 \
  -DFETCHCONTENT_FULLY_DISCONNECTED=ON \
  '-DHYLE_DEV_FACTORS=compute_provider_onednn;compute_route_cpu;graph_route_cpu;graph_provider_onednn' \
  > "$log_root/configure.log" 2>&1
cmake --build "$build_root" --parallel 2 --target \
  hyle_compute_provider_onednn_tests hyle_compute_route_cpu_tests \
  hyle_graph_route_cpu_tests hyle_graph_provider_onednn_tests \
  > "$log_root/build.log" 2>&1
ctest --test-dir "$build_root" --output-on-failure --parallel 1 --no-tests=error \
  -L '^(compute_provider_onednn|compute_route_cpu|graph_route_cpu|graph_provider_onednn)$' -LE headers \
  --output-junit "$log_root/ctest.xml" > "$log_root/test.log" 2>&1
cp "$build_root/Testing/Temporary/LastTest.log" "$log_root/LastTest.log"
cp "$build_root/CMakeCache.txt" "$log_root/CMakeCache.txt"
sha256sum "$build_root"/bin/hyle_compute_provider_onednn_test \
  "$build_root"/bin/hyle_{compute,graph}_route_cpu_test \
  "$build_root"/bin/hyle_graph_provider_onednn_test > "$log_root/artifacts.sha256"
tail -22 "$log_root/test.log"
