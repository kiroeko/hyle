# Bounded source observation; no SIMD product authorization

User noted oneDNN can inform HYLE SIMD improvement. For the currently compared F32 norms:
- HYLE `src/simd/math/highway_math_kernel-inl.h:490` owns normalization loops over Highway vector primitives. RMS reduction uses one source-level vector accumulator; LayerNorm similarly has separate mean and centered-variance passes.
- Locked oneDNN `src/cpu/x64/jit_uni_layer_normalization.cpp:155,350` declares unroll_factor_=4 and generates four independent accumulation registers followed by a tree reduction.
- This is a concrete candidate mechanism for amortized large-row performance. It is not an assembly/counter attribution or a proved independent SIMD speedup. Current qualified evidence compares full Compute/Graph contracts, not isolated SIMD contracts.
- Current C1 priority remains mature Provider binding and the optimized fusion boundary. SIMD is CLOSED and unchanged; no new SIMD queue, public API, benchmark, or algorithm change is authorized by this note. A future bounded SIMD round needs its own consumer/semantic qualification and existing reopen protocol.
