# CMake generated Testfile for 
# Source directory: C:/public/project-hyle/hyle/.scratch/onednn-lock-v3.13.2/extract/oneDNN-71094df451909e95ceeefc8f64c275cdcbbcdff5/examples
# Build directory: C:/hyle-scratch/active-cpu/aa/selected-graph/source-build/hyle/_deps/onednn-build/examples
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
