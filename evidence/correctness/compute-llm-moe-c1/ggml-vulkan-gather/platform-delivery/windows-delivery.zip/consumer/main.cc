#include <hyle/graph/vulkan.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace gv = g::vulkan;
using hyle::Result;
using hyle::Status;
constexpr std::size_t width = 2048;
constexpr std::size_t table_rows = 34;

template <class T>
Result<std::vector<T>> read(const std::filesystem::path &path,
                            std::size_t count) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  if (!file || file.tellg() != static_cast<std::streamoff>(count * sizeof(T)))
    return std::unexpected(Status::DataLoss("fixture byte size"));
  std::vector<T> result(count);
  file.seekg(0);
  if (!file.read(reinterpret_cast<char *>(result.data()),
                 static_cast<std::streamsize>(count * sizeof(T))))
    return std::unexpected(Status::DataLoss("fixture read"));
  return result;
}

float rounded_bf16(double value) {
  auto raw = std::bit_cast<std::uint32_t>(static_cast<float>(value));
  raw += 0x7fffU + ((raw >> 16) & 1U);
  return std::bit_cast<float>(raw & 0xffff0000U);
}

Status check(const v::Context &context, const v::Tensor &tensor,
             std::span<const double> expected) {
  if (tensor.description().data_type() != c::DataType::kBFloat16 ||
      tensor.description().element_count().value() != expected.size())
    return Status::DataLoss("norm result description");
  std::vector<std::uint16_t> storage(expected.size());
  HYLE_RETURN_IF_ERROR(
      context.download(tensor, std::as_writable_bytes(std::span(storage))));
  for (std::size_t i = 0; i < storage.size(); ++i) {
    const auto actual =
        std::bit_cast<float>(static_cast<std::uint32_t>(storage[i]) << 16);
    const double wanted = rounded_bf16(expected[i]);
    // Existing C1 BF16 numerical contract, including final storage rounding.
    if (!std::isfinite(actual) ||
        std::abs(actual - wanted) > 0.008 * std::abs(wanted) + 2e-7)
      return Status::DataLoss("actual-weight norm scalar oracle mismatch");
  }
  return Status::Ok();
}

Status check_gather(const v::Context &context, const v::Tensor &tensor,
                    std::span<const std::uint16_t> expected) {
  if (tensor.description().data_type() != c::DataType::kBFloat16 ||
      tensor.description().element_count().value() != expected.size())
    return Status::DataLoss("Gather result description");
  std::vector<std::uint16_t> actual(expected.size());
  HYLE_RETURN_IF_ERROR(
      context.download(tensor, std::as_writable_bytes(std::span(actual))));
  if (!std::ranges::equal(actual, expected)) {
    const auto mismatch = std::ranges::mismatch(actual, expected);
    std::fprintf(stderr, "Gather mismatch at %zu: actual=%04x expected=%04x\n",
                 static_cast<std::size_t>(mismatch.in1 - actual.begin()),
                 static_cast<unsigned>(*mismatch.in1),
                 static_cast<unsigned>(*mismatch.in2));
    return Status::DataLoss("actual BF16 Gather did not preserve source bits");
  }
  return Status::Ok();
}

Result<v::Program> prepare_graph(const v::Context &context,
                                 const v::Tensor &table, const v::Tensor &scale,
                                 const c::TensorDesc &indices) {
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto ids, builder.input(indices));
  HYLE_ASSIGN_OR_RETURN(auto source, builder.constant(table.description()));
  HYLE_ASSIGN_OR_RETURN(auto weights, builder.constant(scale.description()));
  HYLE_ASSIGN_OR_RETURN(auto selected, builder.add(c::Gather{0}, source, ids));
  HYLE_ASSIGN_OR_RETURN(auto wide,
                        builder.add(c::Cast{c::DataType::kFloat32}, selected));
  const c::RmsNorm norm{.epsilon = 1e-6F,
                        .accumulation_type = c::DataType::kFloat32};
  HYLE_ASSIGN_OR_RETURN(auto normalized, builder.add(norm, wide, weights));
  HYLE_ASSIGN_OR_RETURN(
      auto output, builder.add(c::Cast{c::DataType::kBFloat16}, normalized));
  HYLE_RETURN_IF_ERROR(builder.publish(selected));
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  gv::CompileReport report;
  HYLE_ASSIGN_OR_RETURN(auto program,
                        gv::compile(context, graph, std::array{table, scale},
                                    {.report = &report}));
  if (!report.status.ok() || report.managed_region_count != 2 ||
      report.nodes.size() != 4)
    return std::unexpected(Status::DataLoss(
        "ordinary Graph must bind Gather and norm managed regions"));
  return program;
}

Status run(const v::Context &context, const v::Tensor &table,
           const v::Tensor &scale,
           std::span<const std::int64_t> original_indices,
           std::span<const std::uint16_t> original,
           std::span<const double> oracle, bool graph_path) {
  const auto rows = original_indices.size();
  HYLE_ASSIGN_OR_RETURN(
      auto index_desc,
      c::TensorDesc::dense(
          c::DataType::kInt64,
          std::array<std::int64_t, 1>{static_cast<std::int64_t>(rows)}));
  HYLE_ASSIGN_OR_RETURN(
      auto program, graph_path
                        ? prepare_graph(context, table, scale, index_desc)
                        : v::prepare(context, c::Gather{0}, table, index_desc));
  std::array<v::Invocation, 3> slots;
  std::array<v::Invocation, 2> norm_slots;
  HYLE_ASSIGN_OR_RETURN(slots[0], program.create_invocation());
  HYLE_ASSIGN_OR_RETURN(slots[1], program.create_invocation());
  if (!graph_path) {
    // Slot zero keeps the published snapshot. Two working Gather slots
    // alternate because the downstream Direct invocation retains its input
    // until it binds the next result. All slots are allocated once, cold.
    HYLE_ASSIGN_OR_RETURN(slots[2], program.create_invocation());
    HYLE_ASSIGN_OR_RETURN(
        auto norm,
        v::prepare(context,
                   c::RmsNorm{.epsilon = 1e-6F,
                              .accumulation_type = c::DataType::kFloat32},
                   program.output_descriptions()[0], scale));
    HYLE_ASSIGN_OR_RETURN(norm_slots[0], norm.create_invocation());
    HYLE_ASSIGN_OR_RETURN(norm_slots[1], norm.create_invocation());
  }
  std::array<v::Tensor, 2> retained;
  std::vector<std::uint16_t> previous_bits;
  std::vector<double> previous_norm;
  for (std::size_t phase = 0; phase < 5; ++phase) {
    std::fprintf(stderr, "BEGIN rows=%zu route=%s phase=%zu\n", rows,
                 graph_path ? "Graph" : "Direct", phase);
    std::vector<std::int64_t> positions(rows);
    std::vector<std::uint16_t> expected(rows * width);
    std::vector<double> expected_norm(rows * width);
    for (std::size_t row = 0; row < rows; ++row) {
      const auto source = (row + phase) % rows;
      positions[row] = original_indices[source];
      std::copy_n(original.begin() + source * width, width,
                  expected.begin() + row * width);
      std::copy_n(oracle.begin() + source * width, width,
                  expected_norm.begin() + row * width);
    }
    HYLE_ASSIGN_OR_RETURN(
        auto indices,
        context.upload(index_desc, std::as_bytes(std::span(positions))));
    const auto norm_slot = phase == 0 ? 0U : 1U;
    const auto slot = phase == 0 ? 0U : graph_path ? 1U : 1U + (phase - 1U) % 2U;
    HYLE_RETURN_IF_ERROR(slots[slot].bind(indices));
    HYLE_ASSIGN_OR_RETURN(auto work, slots[slot].submit());
    HYLE_ASSIGN_OR_RETURN(auto result, work.wait());
    const auto selected = result.get()->tensors()[0];
    HYLE_RETURN_IF_ERROR(check_gather(context, selected, expected));
    v::Tensor normalized;
    if (graph_path) {
      normalized = result.get()->tensors()[1];
    } else {
      HYLE_RETURN_IF_ERROR(norm_slots[norm_slot].bind(selected));
      HYLE_ASSIGN_OR_RETURN(auto norm_work, norm_slots[norm_slot].submit());
      HYLE_ASSIGN_OR_RETURN(auto norm_result, norm_work.wait());
      normalized = norm_result.get()->tensors()[0];
    }
    HYLE_RETURN_IF_ERROR(check(context, normalized, expected_norm));
    if (phase == 0) {
      retained = {selected, normalized};
      previous_bits = expected;
      previous_norm = expected_norm;
    } else {
      HYLE_RETURN_IF_ERROR(check_gather(context, retained[0], previous_bits));
      HYLE_RETURN_IF_ERROR(check(context, retained[1], previous_norm));
    }
  }
  std::vector<std::int64_t> invalid(original_indices.begin(),
                                    original_indices.end());
  invalid.back() = table_rows;
  HYLE_ASSIGN_OR_RETURN(
      auto bad, context.upload(index_desc, std::as_bytes(std::span(invalid))));
  HYLE_ASSIGN_OR_RETURN(auto failed, program.create_invocation());
  HYLE_RETURN_IF_ERROR(failed.bind(bad));
  HYLE_ASSIGN_OR_RETURN(auto bad_work, failed.submit());
  auto bad_result = bad_work.wait();
  if (bad_result || !bad_result.error().IsOutOfRange())
    return Status::DataLoss(
        "installed checked Gather did not report OutOfRange");
  if (!failed.bind(bad).IsOutOfRange())
    return Status::DataLoss("failed Gather invocation was not retired");
  HYLE_RETURN_IF_ERROR(check_gather(context, retained[0], previous_bits));
  return check(context, retained[1], previous_norm);
}

Status consume(const std::filesystem::path &fixtures) {
  static_assert(std::endian::native == std::endian::little);
  HYLE_ASSIGN_OR_RETURN(auto input, read<std::uint16_t>(fixtures / "table.bf16",
                                                        table_rows * width));
  HYLE_ASSIGN_OR_RETURN(auto parameters,
                        read<float>(fixtures / "gemma_scale.f32", width));
  hyle::mem::QuotaAllocator quota(hyle::mem::system_allocator(),
                                  64 * 1024 * 1024);
  HYLE_ASSIGN_OR_RETURN(
      auto context,
      v::Context::create({.validation = true, .memory_quota = &quota}));
  HYLE_ASSIGN_OR_RETURN(
      auto table_desc,
      c::TensorDesc::dense(c::DataType::kBFloat16,
                           std::array<std::int64_t, 2>{table_rows, width}));
  HYLE_ASSIGN_OR_RETURN(
      auto scale_desc,
      c::TensorDesc::dense(c::DataType::kFloat32,
                           std::array<std::int64_t, 1>{width}));
  HYLE_ASSIGN_OR_RETURN(
      auto table, context.upload(table_desc, std::as_bytes(std::span(input))));
  HYLE_ASSIGN_OR_RETURN(
      auto scale,
      context.upload(scale_desc, std::as_bytes(std::span(parameters))));
  for (std::size_t rows : {1U, 17U, 128U}) {
    const auto base = fixtures / ("norm_t" + std::to_string(rows));
    HYLE_ASSIGN_OR_RETURN(auto indices,
                          read<std::int64_t>(base.string() + ".i64", rows));
    HYLE_ASSIGN_OR_RETURN(
        auto original,
        read<std::uint16_t>(base.string() + ".bf16", rows * width));
    HYLE_ASSIGN_OR_RETURN(auto oracle,
                          read<double>(base.string() + ".f64", rows * width));
    for (bool graph : {false, true}) {
      HYLE_RETURN_IF_ERROR(
          run(context, table, scale, indices, original, oracle, graph));
      std::printf("PASS actual-weight Gather -> Gemma RMS rows=%zu route=%s "
                  "runs=5 producer_slots=%u norm_slots=%u plus checked failure\n",
                  rows, graph ? "Graph" : "Direct", graph ? 2U : 3U,
                  graph ? 0U : 2U);
    }
  }
  HYLE_RETURN_IF_ERROR(check_gather(context, table, input));
  HYLE_RETURN_IF_ERROR(context.close());
  table = {};
  scale = {};
  context = {};
  if (quota.used() != 0)
    return Status::DataLoss(
        "actual-weight Gather retained quota after owner destruction");
  std::printf("CHARGED native buffer quota peak=%zu bytes\n", quota.peak());
  return Status::Ok();
}

int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  try {
    const auto status = consume(std::filesystem::path(argv[1]));
    if (!status.ok()) {
      std::fprintf(stderr, "%.*s\n", static_cast<int>(status.message().size()),
                   status.message().data());
      return 1;
    }
    std::puts("PASS C1 actual BF16 embedding subset: Direct + Graph; not full "
              "C1/model/performance acceptance");
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "%s\n", error.what());
    return 1;
  }
}
