import ctypes, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
root=Path(__file__).resolve().parents[3]
task=Path(__file__).parent
build=Path('C:/hyle-scratch/active-vk/static')
logs=task/'w1/static-check'
logs.mkdir(exist_ok=False)
ctypes.windll.kernel32.SetErrorMode(0x8003)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['python',str(task/'check-identity.py')],check=True,cwd=root)
env=dict(os.environ,VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin',
         VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',HYLE_TEST_VULKAN_VALIDATE='1',
         HYLE_VULKAN_VALIDATION='1',VK_LOADER_LAYERS_DISABLE='~implicit~',
         TRACY_ONLY_LOCALHOST='1',CTEST_INTERACTIVE_DEBUG_MODE='0')
env.pop('GTEST_FILTER',None)
compiler_env=dict(env)
env.pop('PATH',None)
crtroot=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
crt=sorted(p/'x64/Microsoft.VC145.CRT' for p in crtroot.iterdir() if (p/'x64/Microsoft.VC145.CRT').is_dir())[-1]
for dll in crt.glob('*.dll'): shutil.copy2(dll,build/'bin'/dll.name)
record={'worktree':json.loads((task/'worktree.json').read_text()),'scope':'Y26 initial checked Gather correctness; no P1',
        'linkage':'static','status':'RUNNING','commands':[],'cmake_cache_sha256':sha(build/'CMakeCache.txt')}
try:
    cases=[('focus','compute_route_vulkan','VulkanGather.*:VulkanLifecycle.CheckedGather*'),
           ('focus','graph_route_vulkan','VulkanGraph.GatherSharesCapturedTableAndPreservesIndependentResults'),
           ('selected','compute_provider_ggml_vulkan',''),('selected','compute_route_vulkan',''),('selected','graph_route_vulkan','')]
    for phase,factor,pattern in cases:
        out=logs/(phase+'-'+factor); out.mkdir()
        exe=build/'bin'/('hyle_'+factor+'_test.exe')
        if phase=='focus':
            command=[str(exe),'--gtest_filter='+pattern,'--gtest_output=json:'+str(out/'gtest.json')]
        else:
            env['GTEST_OUTPUT']='json:'+str(out)+'/'
            command=['C:/Program Files/CMake/bin/ctest.exe','--test-dir',str(build),'-C','Release',
                     '--output-on-failure','--no-tests=error','-L','^'+factor+'$',
                     '-R','^hyle_'+factor+'_test$','--parallel','1',
                     '--output-junit',str(out/'ctest.xml')]
        start=time.monotonic()
        with (out/'run.log').open('w') as stream:
            done=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=300)
        row={'phase':phase,'factor':factor,'command':command,'exit_code':done.returncode,
             'seconds':time.monotonic()-start,'executable_sha256':sha(exe),'log_sha256':sha(out/'run.log'),
             'path_unset':True}
        record['commands'].append(row)
        log=(out/'run.log').read_text(errors='replace')
        print(log[-6000:],flush=True)
        done.check_returncode()
        assert not any(s in log for s in ('VUID-','Validation Error','SYNC-HAZARD'))
        reports=list(out.glob('*.json')); assert len(reports)==1
        report=json.loads(reports[0].read_text())
        assert report['tests']>0 and report['failures']==0 and report['errors']==0
        assert report.get('disabled',0)==0
        assert all(t['status']=='RUN' and t['result']=='COMPLETED' for s in report['testsuites'] for t in s['testsuite'])
        row['tests']=report['tests']; row['gtest_sha256']=sha(reports[0]); row['status']='PASS'
        if phase=='selected':
            # Compiler checks need the imported compiler environment; all
            # actual product executables above still run with PATH absent.
            auxiliary=out/'compiler-checks.log'
            command=['C:/Program Files/CMake/bin/ctest.exe','--test-dir',str(build),'-C','Release',
                     '--output-on-failure','--no-tests=error','-L','^'+factor+'$',
                     '-E','^hyle_'+factor+'_test$','--parallel','1',
                     '--output-junit',str(out/'compiler-checks.xml')]
            start=time.monotonic()
            with auxiliary.open('w') as stream:
                done=subprocess.run(command,cwd=root,env=compiler_env,stdout=stream,
                                    stderr=subprocess.STDOUT,timeout=300)
            record['commands'].append({'phase':'selected-compiler-checks','factor':factor,
                'command':command,'exit_code':done.returncode,'seconds':time.monotonic()-start,
                'log_sha256':sha(auxiliary),'path_unset':False,
                'status':'PASS' if done.returncode==0 else 'FAIL'})
            print(auxiliary.read_text(errors='replace')[-6000:],flush=True)
            done.check_returncode()
    subprocess.run(['python',str(task/'check-identity.py')],check=True,cwd=root)
    record['status']='PASS'
except BaseException as e:
    record['status']='FAIL'; record['failure']=str(e)
    raise
finally:
    (logs/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
