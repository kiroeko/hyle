import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[3]
d=json.loads((Path(__file__).parent/'worktree.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==d['head']
assert hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=root)).hexdigest()==d['diff_sha256']
for p,h in d['files'].items():
    assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h, p
print('Frozen implementation WORKTREE matches', d['diff_sha256'],flush=True)
