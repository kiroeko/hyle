$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-gather'
$previousResult = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-topk\origin-correction\generic\remaining-delivery\result.json'
$worker = Get-Process -Id 77496 -ErrorAction SilentlyContinue
if ($worker) {
    $info = Get-CimInstance Win32_Process -Filter 'ProcessId = 77496'
    if ($info.CommandLine -notmatch 'origin-correction\\generic\\remaining-gates.py delivery') { throw 'Previous process identity changed' }
    Write-Output ('WAIT confirmed generic delivery PID 77496, started ' + $worker.StartTime.ToString('o'))
    while (-not $worker.WaitForExit(1000)) { }
}
$previous = Get-Content -LiteralPath $previousResult -Raw | ConvertFrom-Json
if ($previous.status -ne 'PASS' -or @($previous.gates).Count -ne 15 -or @($previous.gates | Where-Object status -ne 'PASS').Count -ne 0) { throw 'Prior delivery job did not complete its 15 gates; no overlapping build started' }
& python (Join-Path $taskRoot 'check-identity.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Output 'START Y26 static configure'
& (Join-Path $taskRoot 'w1-run.ps1') -Linkage static -Action Configure
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& (Join-Path $taskRoot 'w1-run.ps1') -Linkage static -Action Build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python (Join-Path $taskRoot 'check-identity.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& python (Join-Path $taskRoot 'check-static.py')
exit $LASTEXITCODE
