#include <hyle/graph/vulkan.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace gv = g::vulkan;
using hyle::Result;
using hyle::Status;
constexpr std::size_t width = 2048;
constexpr std::size_t source_rows = 128;

template <class T>
Result<std::vector<T>> read(const std::filesystem::path &path,
                            std::size_t count) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  if (!file || file.tellg() != static_cast<std::streamoff>(count * sizeof(T)))
    return std::unexpected(Status::DataLoss("fixture byte size"));
  std::vector<T> result(count);
  file.seekg(0);
  if (!file.read(reinterpret_cast<char *>(result.data()),
                 static_cast<std::streamsize>(count * sizeof(T))))
    return std::unexpected(Status::DataLoss("fixture read"));
  return result;
}

float rounded_bf16(double value) {
  auto raw = std::bit_cast<std::uint32_t>(static_cast<float>(value));
  raw += 0x7fffU + ((raw >> 16) & 1U);
  return std::bit_cast<float>(raw & 0xffff0000U);
}

Status check(const v::Context &context, const v::Tensor &tensor,
              std::span<const double> expected) {
  if (tensor.description().data_type() != c::DataType::kBFloat16 ||
      tensor.description().element_count().value() != expected.size())
    return Status::DataLoss("norm result description");
  std::vector<std::uint16_t> storage(expected.size());
  HYLE_RETURN_IF_ERROR(context.download(tensor, std::as_writable_bytes(std::span(storage))));
  for (std::size_t i = 0; i < storage.size(); ++i) {
    const auto actual = std::bit_cast<float>(static_cast<std::uint32_t>(storage[i]) << 16);
    const double wanted = rounded_bf16(expected[i]);
    // Existing C1 BF16 numerical contract, including final storage rounding.
    if (!std::isfinite(actual) ||
        std::abs(actual - wanted) > 0.008 * std::abs(wanted) + 2e-7)
      return Status::DataLoss("actual-weight norm scalar oracle mismatch");
  }
  return Status::Ok();
}

Result<v::Program> prepare(const v::Context &context, const c::TensorDesc &desc,
                            const v::Tensor &scale, bool graph_path) {
  const c::RmsNorm norm{.epsilon = 1e-6F, .accumulation_type = c::DataType::kFloat32};
  if (!graph_path)
    return v::prepare(context, norm, desc, scale);
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto x, builder.input(desc));
  HYLE_ASSIGN_OR_RETURN(auto w, builder.constant(scale.description()));
  HYLE_ASSIGN_OR_RETURN(auto wide, builder.add(c::Cast{.output_type = c::DataType::kFloat32}, x));
  HYLE_ASSIGN_OR_RETURN(auto normalized, builder.add(norm, wide, w));
  HYLE_ASSIGN_OR_RETURN(auto output, builder.add(c::Cast{.output_type = c::DataType::kBFloat16}, normalized));
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  gv::CompileReport report;
  HYLE_ASSIGN_OR_RETURN(auto program, gv::compile(context, graph, std::array{scale}, {.report = &report}));
  if (!report.status.ok() || report.managed_region_count != 1 || report.nodes.size() != 3)
    return std::unexpected(Status::DataLoss("ordinary graph did not bind the actual managed norm region"));
  return program; // The source Graph can be destroyed now.
}

Status run(const v::Context &context, v::Program program, std::size_t rows,
             std::span<const std::uint16_t> original,
             std::span<const double> oracle) {
  HYLE_ASSIGN_OR_RETURN(auto first, program.create_invocation());
  HYLE_ASSIGN_OR_RETURN(auto second, program.create_invocation());
  const auto desc = program.input_descriptions()[0];
  program = {};
  v::Tensor retained;
  std::vector<double> old_expected;
  for (std::size_t phase = 0; phase < 3; ++phase) {
    std::vector<std::uint16_t> input(rows * width);
    std::vector<double> expected(input.size());
    for (std::size_t row = 0; row < rows; ++row) {
      // Phase zero is the exact frozen prompt. Further phases rotate actual
      // token embedding rows; this is a changed-input norm test, not a claim
      // about whole-model reference execution of a different prompt.
      const auto source = ((row + phase) % source_rows) * width;
      std::copy_n(original.begin() + source, width, input.begin() + row * width);
      std::copy_n(oracle.begin() + source, width, expected.begin() + row * width);
    }
    HYLE_ASSIGN_OR_RETURN(auto tensor, context.upload(desc, std::as_bytes(std::span(input))));
    auto &slot = phase == 0 ? first : second;
    HYLE_RETURN_IF_ERROR(slot.bind(tensor));
    HYLE_ASSIGN_OR_RETURN(auto work, slot.submit());
    HYLE_ASSIGN_OR_RETURN(auto result, work.wait());
    if (result.get()->tensors().size() != 1)
      return Status::DataLoss("norm output arity");
    HYLE_RETURN_IF_ERROR(check(context, result.get()->tensors()[0], expected));
    if (phase == 0) {
      retained = result.get()->tensors()[0];
      old_expected = expected;
    } else {
      HYLE_RETURN_IF_ERROR(check(context, retained, old_expected));
    }
    std::vector<std::uint16_t> unchanged(input.size());
    HYLE_RETURN_IF_ERROR(context.download(tensor, std::as_writable_bytes(std::span(unchanged))));
    if (unchanged != input)
      return Status::DataLoss("norm changed its input storage");
  }
  first = {};
  second = {};
  return check(context, retained, old_expected);
}

Status consume(const std::filesystem::path &fixtures) {
  static_assert(std::endian::native == std::endian::little);
  HYLE_ASSIGN_OR_RETURN(auto input, read<std::uint16_t>(fixtures / "norm_t128.bf16", source_rows * width));
  HYLE_ASSIGN_OR_RETURN(auto oracle, read<double>(fixtures / "norm_t128.f64", source_rows * width));
  HYLE_ASSIGN_OR_RETURN(auto parameters, read<float>(fixtures / "gemma_scale.f32", width));
  hyle::mem::QuotaAllocator quota(hyle::mem::system_allocator(), 64 * 1024 * 1024);
  HYLE_ASSIGN_OR_RETURN(auto context, v::Context::create({.validation = true, .memory_quota = &quota}));
  HYLE_ASSIGN_OR_RETURN(auto scale_desc, c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t, 1>{width}));
  HYLE_ASSIGN_OR_RETURN(auto scale, context.upload(scale_desc, std::as_bytes(std::span(parameters))));
  for (std::size_t rows : {1U, 17U, 128U}) {
    HYLE_ASSIGN_OR_RETURN(auto desc, c::TensorDesc::dense(c::DataType::kBFloat16,
                                                         std::array<std::int64_t, 2>{static_cast<std::int64_t>(rows), width}));
    for (bool graph : {false, true}) {
      HYLE_ASSIGN_OR_RETURN(auto program, prepare(context, desc, scale, graph));
      HYLE_RETURN_IF_ERROR(run(context, std::move(program), rows, input, oracle));
      std::printf("PASS actual-weight norm rows=%zu route=%s runs=3\n", rows, graph ? "Graph" : "Direct");
    }
  }
  HYLE_RETURN_IF_ERROR(context.close());
  scale = {};
  context = {};
  if (quota.used() != 0)
    return Status::DataLoss("actual-weight norm retained quota after owner destruction");
  std::printf("CHARGED native buffer quota peak=%zu bytes\n", quota.peak());
  return Status::Ok();
}

int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  try {
    const auto status = consume(std::filesystem::path(argv[1]));
    if (!status.ok()) {
      std::fprintf(stderr, "%.*s\n", static_cast<int>(status.message().size()), status.message().data());
      return 1;
    }
    std::puts("PASS C1 actual BF16 weights: Direct + managed Graph; not full C1/model/performance acceptance");
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "%s\n", error.what());
    return 1;
  }
}
