"""Archive completed independent SDK consumers without any model tensor bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--inputs', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

result = json.loads((args.root / 'logs/result.json').read_text())
assert result['status'] == 'PASS'
assert set(result['executables']) == {'static', 'shared'}
files = {'logs/result.json': args.root / 'logs/result.json'}
for command in result['commands']:
    path = args.root / 'logs' / command['log']
    assert command['exit_code'] == 0 and sha(path) == command['sha256']
    files['logs/' + path.name] = path
for linkage, record in result['executables'].items():
    build = args.root / linkage
    exe = build / ('hyle_c1_real_weight_norm.exe' if result['platform'] == 'win32'
                   else 'hyle_c1_real_weight_norm')
    assert sha(exe) == record['sha256']
    for name in ('CMakeCache.txt', 'compile_commands.json', 'build.ninja'):
        files[linkage + '/' + name] = build / name
    output = (args.root / 'logs' / (linkage + '-execute.log')).read_text()
    assert output.count('PASS actual-weight norm rows=') == 6
    assert 'PASS C1 actual BF16 weights:' in output
    assert not any(marker in output for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
for name in ('consumer/main.cc', 'consumer/CMakeLists.txt', 'run-sdks.py',
             'norm-fixtures/receipt.json', 'source-current.json', 'asset-status.json'):
    files['inputs/' + name] = args.inputs / name
for name, expected in result['consumer_sources'].items():
    assert sha(args.inputs / 'consumer' / name) == expected
assert sha(args.inputs / 'norm-fixtures/receipt.json') == result['fixture_receipt_sha256']
manifest = {name: {'sha256': sha(path), 'bytes': path.stat().st_size}
            for name, path in files.items()}
with zipfile.ZipFile(args.output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in files.items():
        archive.write(path, name)
    archive.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(args.output) as archive:
    assert archive.testzip() is None
    for name, record in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == record['sha256']
receipt = {'platform': result['platform'], 'status': 'PASS', 'sdk_consumers': 2,
           'submissions': 36, 'archive': args.output.name, 'sha256': sha(args.output),
           'bytes': args.output.stat().st_size, 'model_tensor_bytes_archived': 0}
args.output.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
