import hashlib
import json
from pathlib import Path
import sys
import zipfile

base = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
archive = base / 'norm-input.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == sys.argv[1]
destination = base / 'norm-input'
assert not destination.exists()
with zipfile.ZipFile(archive) as contents:
    names = contents.namelist()
    assert len(names) == len(set(names))
    for name in names:
        path = Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        (destination / path).resolve().relative_to(destination.resolve())
    contents.extractall(destination)
manifest = json.loads((destination / 'archive-manifest.json').read_text())
for name, entry in manifest.items():
    content = (destination / name).read_bytes()
    assert len(content) == entry['bytes']
    assert hashlib.sha256(content).hexdigest() == entry['sha256']
receipt = {'source': 'Windows-generated actual-weight fixture', 'sha256': sys.argv[1],
           'verified_files': len(manifest), 'destination': str(destination),
           'hyle_execution': 'NOT_RUN'}
(base / 'norm-input-transfer.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
