"""Prepare small actual-weight C1 norm inputs and an independent scalar oracle.

No HYLE verdict, inference engine, Torch/GPU execution or model download.
The full embedding table stays in the original user-supplied safetensors file.
"""
from array import array
import hashlib
import json
import math
from pathlib import Path
import struct
import sys

ROOT = Path('C:/public/project-hyle/hyle')
BASE = ROOT / '.scratch/validation/c1-real-weights'
DEST = BASE / 'norm-fixtures'
assert sys.byteorder == 'little'
assets = json.loads((BASE / 'asset-status.json').read_text())
cases_path = ROOT / 'tests/compute_models/qwen35_cases.json'
cases = json.loads(cases_path.read_text())
assert cases['source_id'] == assets['source_id']
source = Path(assets['original_full_verification']['directory'])
config = json.loads((source / 'config.json').read_text())['text_config']
shard = source / 'model.safetensors-00001-of-00001.safetensors'
before_stat = shard.stat()
qualified = json.loads((ROOT / 'evidence/correctness/compute-llm-moe-c0/b16-reference.json').read_text())
model_source = Path(qualified['model_source_path'])
assert hashlib.sha256(model_source.read_bytes()).hexdigest() == qualified['model_source_sha256']

def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]

def decode_bf16(data):
    assert len(data) % 2 == 0
    return [struct.unpack('<f', struct.pack('<I', raw << 16))[0]
            for (raw,) in struct.iter_unpack('<H', data)]

def write(name, data, dtype, shape):
    (DEST / name).write_bytes(data)
    return {'file': name, 'dtype': dtype, 'shape': shape, 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

embedding_name = 'model.language_model.embed_tokens.weight'
parameter_name = 'model.language_model.layers.0.input_layernorm.weight'
embedding = assets['c1_tensor_metadata'][embedding_name]
parameter = assets['c1_tensor_metadata'][parameter_name]
assert embedding['dtype'] == parameter['dtype'] == 'BF16'
vocabulary, width = embedding['shape']
assert width == config['hidden_size'] == 2048 and parameter['shape'] == [width]
base = assets['data_base_offset']
with shard.open('rb') as stream:
    header_length = struct.unpack('<Q', stream.read(8))[0]
    header = stream.read(header_length)
    assert base == header_length + 8
    assert hashlib.sha256(header).hexdigest() == assets['safetensors_header_sha256']
    stream.seek(base + parameter['data_offsets'][0])
    parameter_bytes = stream.read(width * 2)
    assert len(parameter_bytes) == width * 2
    parameter_values = decode_bf16(parameter_bytes)
    scale = [f32(1.0 + value) for value in parameter_values]
    assert all(math.isfinite(value) for value in scale)
    epsilon = f32(config['rms_norm_eps'])
    DEST.mkdir(exist_ok=False)
    weights = write('gemma_parameter.bf16', parameter_bytes, 'BF16', [width])
    scale_file = write('gemma_scale.f32', array('f', scale).tobytes(), 'F32', [width])
    records = []
    for case in cases['reference_cases']:
        tokens = case['prompt_ids']
        assert all(0 <= token < vocabulary for token in tokens)
        data = bytearray()
        for token in tokens:
            stream.seek(base + embedding['data_offsets'][0] + token * width * 2)
            row = stream.read(width * 2)
            assert len(row) == width * 2
            data.extend(row)
        original = decode_bf16(data)
        assert all(math.isfinite(value) for value in original)
        output = []
        for start in range(0, len(original), width):
            row = original[start:start + width]
            square_mean = math.fsum(value * value for value in row) / width
            inverse = 1.0 / math.sqrt(square_mean + epsilon)
            output.extend(value * inverse * weight for value, weight in zip(row, scale))
        assert all(math.isfinite(value) for value in output)
        name = f'norm_t{len(tokens)}'
        records.append({
            'id': name, 'fixed_case': case['id'], 'token_ids': tokens,
            'input': write(name + '.bf16', data, 'BF16', [len(tokens), width]),
            'unrounded_oracle': write(name + '.f64', array('d', output).tobytes(),
                                      'F64', [len(tokens), width]),
        })
assert shard.stat().st_size == before_stat.st_size
assert shard.stat().st_mtime_ns == before_stat.st_mtime_ns
receipt = {
    'kind': 'actual local-weight C1 norm fixture and scalar oracle; not HYLE execution evidence',
    'source_id': assets['source_id'], 'source_file': str(shard),
    'original_verification': assets['original_full_verification'],
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'frozen_cases_sha256': hashlib.sha256(cases_path.read_bytes()).hexdigest(),
    'model_source_sha256': qualified['model_source_sha256'],
    'tensor_sources': {embedding_name: embedding, parameter_name: parameter},
    'original_data_base_offset': base,
    'parameter': weights, 'scale': scale_file, 'epsilon_f32': epsilon, 'cases': records,
    'formula': 'x is the exact BF16 embedding for the frozen token IDs; scale=F32(1+BF16(weight)); reference=x*rsqrt(mean(x*x)+epsilon_f32)*scale with scalar double/math.fsum, before output storage rounding.',
    'consumer_requirements': 'Direct BF16 input with explicit F32 accumulation and F32 scale; Graph may express Cast(F32)->RmsNorm(scale)->Cast(BF16). Apply the existing C1 numeric acceptance contract, count every conversion/copy, and retain two independent slots and old results.',
    'limitations': 'Only actual first-layer embedding values and Gemma RMS parameters; no HYLE Gather, gate/residual/state, full C1, model or performance verdict. Original full embedding storage was not duplicated.',
}
(DEST / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'cases': len(records), 'tensor_bytes': sum(p.stat().st_size for p in DEST.iterdir() if p.suffix != '.json'),
                  'source_id': receipt['source_id'], 'hyle_execution': 'NOT_RUN'}))
