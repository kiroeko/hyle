"""Read-only C1 asset check; never regenerates or downloads model data."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path('C:/public/project-hyle/hyle')
OUT = ROOT / '.scratch/validation/c1-real-weights'
original = json.loads((OUT / 'source-current.json').read_text())
assert original['result'] == 'PASS'
reference = json.loads((ROOT / 'evidence/correctness/compute-llm-moe-c0/b16-reference.json').read_text())
quantized = json.loads((ROOT / 'evidence/correctness/compute-llm-moe-c0/quantized-inputs.json').read_text())
entries = [{'profile': 'B16-reference', 'path': reference['artifact_directory'],
            'exists': Path(reference['artifact_directory']).is_dir()}]
for profile in quantized['profiles']:
    path = Path(profile['directory']) / profile['artifact']
    entries.append({'profile': profile['profile'], 'path': str(path), 'exists': path.is_file(),
                    'expected_bytes': profile['bytes'], 'expected_sha256': profile['sha256']})

directory = Path(original['directory'])
weight = directory / 'model.safetensors-00001-of-00001.safetensors'
with weight.open('rb') as stream:
    header_length = struct.unpack('<Q', stream.read(8))[0]
    assert 0 < header_length < 16 * 1024 * 1024
    header_bytes = stream.read(header_length)
    assert len(header_bytes) == header_length
    metadata = json.loads(header_bytes)
names = ['model.language_model.embed_tokens.weight',
         'model.language_model.layers.0.input_layernorm.weight',
         'model.language_model.layers.0.post_attention_layernorm.weight',
         'model.language_model.layers.0.linear_attn.norm.weight']
tensors = {name: metadata[name] for name in names}
record = {
    'kind': 'current local asset availability; not HYLE execution evidence',
    'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'source_id': original['source_id'], 'original_full_verification': original,
    'legacy_c0_paths': entries,
    'missing_path_conclusion': 'Named receipt paths are absent; this does not assert that every possible external copy is absent.',
    'safetensors_header_sha256': hashlib.sha256(header_bytes).hexdigest(),
    'data_base_offset': 8 + header_length,
    'c1_tensor_metadata': tensors,
    'next_action': 'Use verified original weights for bounded C1 tensor fixtures. Recover or regenerate old derivatives only when their C3/C6 acceptance consumes them, using unchanged frozen recipes and sequential heavy execution. No model download.',
}
(OUT / 'asset-status.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'original': '13 files size+SHA256 PASS', 'legacy_paths': entries,
                  'c1_tensors': {name: {'dtype': t['dtype'], 'shape': t['shape']} for name, t in tensors.items()}}, indent=2))
