"""Run the actual-weight norm consumer against the already verified Vulkan SDKs.

Run only after the serial predecessor delivery queue is terminal. This controller
does not rebuild HYLE, regenerate model data, or claim a full C1 verdict.
"""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--sdk-root', type=Path, required=True)
args = parser.parse_args()
BASE = Path(__file__).resolve().parent
windows = sys.platform == 'win32'
if windows:
    ctypes.windll.kernel32.SetErrorMode(0x8003)
    predecessor = json.loads((BASE.parent / 'vulkan-delivery/remaining-delivery/result.json').read_text())
    assert predecessor['status'] == 'PASS', 'Do not overlap the heavy delivery queue'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

fixtures = BASE / 'norm-fixtures'
fixture = json.loads((fixtures / 'receipt.json').read_text())
for entry in [fixture['parameter'], fixture['scale']] + [x for case in fixture['cases']
                                                       for x in (case['input'], case['unrounded_oracle'])]:
    assert (fixtures / entry['file']).stat().st_size == entry['bytes']
    assert sha(fixtures / entry['file']) == entry['sha256']
for count in (1, 17):
    for extension, size in (('bf16', 2), ('f64', 8)):
        assert (fixtures / f'norm_t{count}.{extension}').read_bytes() == (
            fixtures / f'norm_t128.{extension}').read_bytes()[:count * 2048 * size]

root = args.root.resolve()
root.mkdir(parents=True, exist_ok=False)
logs = root / 'logs'
logs.mkdir()
cmake = 'C:/Program Files/CMake/bin/cmake.exe' if windows else '/opt/homebrew/bin/cmake'
environment = dict(os.environ)
environment.update(CMAKE_BUILD_PARALLEL_LEVEL='2', TRACY_ONLY_LOCALHOST='1',
                   HYLE_VULKAN_VALIDATION='1', VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
                   VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin' if windows else
                   '/Users/kiro/hyle-verify/r6-vulkan-20260917/tools/vulkan-validationlayers/1.4.357.0/share/vulkan/explicit_layer.d')
if not windows:
    environment['PATH'] = '/opt/homebrew/bin:' + environment.get('PATH', '')
    environment['DYLD_LIBRARY_PATH'] = '/opt/homebrew/opt/vulkan-loader/lib'
    environment['VK_LOADER_LAYERS_DISABLE'] = '~implicit~'
records = []
receipt = {
    'kind': 'C1 actual-weight norm Direct/Graph installed SDK validation',
    'source_snapshot': '351ec13d82057402594a96fcc862bcdc96b2d839',
    'product_candidate': '3c39428e3fdf1911b284f7632d891f663ad82f31',
    'platform': sys.platform, 'status': 'RUNNING',
    'source_id': fixture['source_id'], 'fixture_receipt_sha256': sha(fixtures / 'receipt.json'),
    'consumer_sources': {p.name: sha(p) for p in (BASE / 'consumer').iterdir() if p.is_file()},
    'commands': records, 'executables': {},
    'scope': 'BF16 input, actual Gemma RMS parameter, F32 scale/accumulation; Direct and Cast-F32 -> managed norm -> Cast-BF16 Graph; 1/17/128 rows, two slots, three changed-input runs, old outputs and quota retirement.',
    'not_qualified': ['source delivery of this new consumer', 'C1 Gather/gate/residual/state pieces',
                      'full C1', 'full model', 'performance'],
}

def save():
    (logs / 'result.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def run(label, command, clean_path=False):
    print(label, flush=True)
    child = dict(environment)
    if clean_path:
        child.pop('PATH', None)
    started = time.monotonic()
    with (logs / (label + '.log')).open('w', encoding='utf-8') as stream:
        result = subprocess.run([str(x) for x in command], env=child, cwd=root,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=240)
    records.append({'label': label, 'argv': [str(x) for x in command],
                    'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started,
                    'log': label + '.log', 'sha256': sha(logs / (label + '.log')),
                    'path_unset': clean_path})
    save()
    if result.returncode:
        print((logs / (label + '.log')).read_text(errors='replace')[-7000:], flush=True)
    result.check_returncode()

save()
try:
    for linkage in ('static', 'shared'):
        build = root / linkage
        sdk = args.sdk_root / ('relocated-sdk-' + linkage)
        assert sdk.is_dir()
        command = [cmake, '-S', BASE / 'consumer', '-B', build, '-G', 'Ninja',
                   '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(sdk),
                   '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
        if not windows:
            command.append('-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4')
        run(linkage + '-configure', command)
        run(linkage + '-build', [cmake, '--build', build, '--parallel', '2'])
        executable = build / ('hyle_c1_real_weight_norm' + ('.exe' if windows else ''))
        if windows:
            redist = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
            crt = sorted(p / 'x64/Microsoft.VC145.CRT' for p in redist.iterdir()
                         if (p / 'x64/Microsoft.VC145.CRT').is_dir())[-1]
            for dll in crt.glob('*.dll'):
                shutil.copy2(dll, build / dll.name)
            shutil.copy2(Path('C:/Windows/System32/vulkan-1.dll'), build / 'vulkan-1.dll')
        run(linkage + '-execute', [executable, fixtures], clean_path=windows)
        output = (logs / (linkage + '-execute.log')).read_text()
        assert output.count('PASS actual-weight norm rows=') == 6
        assert 'PASS C1 actual BF16 weights:' in output
        assert not any(marker in output for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
        receipt['executables'][linkage] = {'sha256': sha(executable), 'sdk': str(sdk)}
        run(linkage + '-linkage', ['dumpbin', '/dependents', executable] if windows else
            ['/usr/bin/otool', '-L', executable])
    receipt['status'] = 'PASS'
except Exception as error:
    receipt['status'] = 'FAIL'
    receipt['failure'] = str(error)
    raise
finally:
    save()
print(json.dumps({'status': receipt['status'], 'sdk_consumers': len(receipt['executables']),
                  'hyle_submissions': 36, 'logs': str(logs)}))
