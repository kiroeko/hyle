import hashlib
import json
from pathlib import Path

root = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918/d')
identity = json.loads((root / 'logs/identity.json').read_text())
assert identity['state'] == 'PASS'
assert identity['snapshot'] == '351ec13d82057402594a96fcc862bcdc96b2d839'
for linkage in ('static', 'shared'):
    assert (root / ('relocated-sdk-' + linkage)).is_dir()
print(json.dumps({'snapshot': identity['snapshot'], 'original_delivery': identity['state'],
                  'sdk_static': 'present', 'sdk_shared': 'present'}))
