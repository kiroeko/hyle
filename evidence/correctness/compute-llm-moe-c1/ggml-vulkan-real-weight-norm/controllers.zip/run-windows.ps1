$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$taskRoot = Join-Path $canonicalRoot '.scratch\validation\c1-real-weights'
$predecessor = Get-Content -Raw -LiteralPath (Join-Path $canonicalRoot '.scratch\validation\vulkan-delivery\remaining-delivery\result.json') | ConvertFrom-Json
if ($predecessor.status -ne 'PASS') { throw 'Finish the serial delivery queue first' }
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-vk\static' -ExtraArgs @('--target','help') > (Join-Path $taskRoot 'windows-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python (Join-Path $taskRoot 'run-sdks.py') --root C:/hyle-scratch/active-vk/n --sdk-root C:/hyle-scratch/active-vk/d
exit $LASTEXITCODE
