"""Archive only the small consumer/fixtures for a later serial Air run."""
import hashlib
import json
from pathlib import Path
import zipfile

base = Path(__file__).resolve().parent
files = [base / 'run-sdks.py', base / 'source-current.json', base / 'asset-status.json']
files += sorted((base / 'consumer').glob('*'))
files += sorted((base / 'norm-fixtures').glob('*'))
archive = base / 'air-norm-input.zip'
manifest = {}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for path in files:
        assert path.is_file()
        name = path.relative_to(base).as_posix()
        content = path.read_bytes()
        manifest[name] = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
        output.writestr(name, content)
    output.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as saved:
    for name, entry in manifest.items():
        assert hashlib.sha256(saved.read(name)).hexdigest() == entry['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(base / 'air-norm-input.json').write_text(json.dumps({'archive': archive.name,
    'bytes': archive.stat().st_size, 'sha256': digest, 'files': len(manifest),
    'scope': 'copied local norm fixtures and external C++ consumer; not an execution verdict'}, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest}))
