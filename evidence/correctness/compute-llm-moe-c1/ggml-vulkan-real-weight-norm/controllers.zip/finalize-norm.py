import hashlib
import json
from pathlib import Path
import shutil
import zipfile

base = Path('C:/public/project-hyle/hyle/.scratch/validation/c1-real-weights')
dest = Path('C:/public/project-hyle/hyle/evidence/correctness/compute-llm-moe-c1/ggml-vulkan-real-weight-norm')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipts = {}
for name in ('windows-norm-raw', 'air-norm-raw'):
    receipt = json.loads((base / (name + '.json')).read_text())
    archive = base / (name + '.zip')
    assert receipt['status'] == 'PASS' and receipt['submissions'] == 36
    assert receipt['sha256'] == sha(archive)
    with zipfile.ZipFile(archive) as saved:
        for entry, record in json.loads(saved.read('archive-manifest.json')).items():
            assert hashlib.sha256(saved.read(entry)).hexdigest() == record['sha256']
        result = json.loads(saved.read('logs/result.json'))
        assert result['status'] == 'PASS'
        receipts[receipt['platform']] = receipt

dest.mkdir(exist_ok=False)
for name in ('windows-norm-raw.zip', 'windows-norm-raw.json', 'air-norm-raw.zip',
             'air-norm-raw.json', 'source-current.json', 'asset-status.json', 'air-transfer.json'):
    shutil.copy2(base / name, dest / name)
shutil.copy2(base / 'norm-fixtures/receipt.json', dest / 'fixture-receipt.json')
controllers = ('prepare-norm-fixture.py', 'run-sdks.py', 'run-windows.ps1',
               'inspect-assets.py', 'stage-air.py', 'unpack-air.py',
               'check-air-sdks.py', 'archive-norm.py', 'finalize-norm.py')
with zipfile.ZipFile(dest / 'controllers.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    manifest = {}
    for name in controllers:
        archive.write(base / name, name)
        manifest[name] = {'sha256': sha(base / name), 'bytes': (base / name).stat().st_size}
    archive.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
result = {
    'scope': 'C1-Y4 actual Qwen3.5-2B first-layer RMSNorm piece using ordinary Vulkan Direct and managed Graph',
    'source_snapshot': '351ec13d82057402594a96fcc862bcdc96b2d839',
    'product_candidate': '3c39428e3fdf1911b284f7632d891f663ad82f31',
    'source_id': '4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155',
    'rows': [1, 17, 128], 'width': 2048, 'runs_per_case': 3,
    'platforms': receipts, 'ordinary_sdk_consumers': 4, 'submissions': 72,
    'correctness': 'PASS for BF16 inputs, actual parameter and scalar double oracle under the existing C1 BF16 contract',
    'resources': 'PASS for two invocations, changed inputs, old results, destroyed source Graph/Program, unchanged input bytes, quota retirement',
    'validation': 'Windows and Air requested validation in Context; no VUID/Validation Error/SYNC-HAZARD in actual execution logs',
    'delivery': 'Installed relocated static and shared SDKs on Windows and Air; source delivery of this new consumer remains NOT_RUN',
    'c1_acceptance': 'INCONCLUSIVE', 'performance': 'NOT_RUN',
    'not_qualified': ['Gather, gate/residual and persistent-state real-weight pieces', 'full C1 matrix', 'whole-model execution', 'source delivery of this exact consumer', 'performance preferences'],
    'asset_state': 'Original 13 files reverified. Exact old Windows B16 reference and Q4/Q8/FP8 derivative paths recorded by C0 are absent; historical receipts are retained, but those binary paths cannot be claimed currently reusable. Recover or regenerate with frozen recipes before C3/C6 consumption.',
    'archives': {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in dest.glob('*.zip')},
    'model_tensor_bytes_in_git': 0,
}
(dest / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'destination': str(dest), 'submissions': 72, 'status': 'scoped PASS'}))
