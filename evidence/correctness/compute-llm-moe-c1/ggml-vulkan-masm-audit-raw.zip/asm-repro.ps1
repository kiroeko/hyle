$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logRoot = Join-Path $canonicalRoot '.scratch\validation\onednn-aa'
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-cpu\static' -ExtraArgs @('--target','help') > (Join-Path $logRoot 'asm-repro-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
foreach ($variant in @('OFF','ON')) {
  $build = Join-Path $logRoot ('asm-repro-' + $variant)
  $log = Join-Path $logRoot ('asm-repro-' + $variant + '.log')
  & 'C:\Program Files\CMake\bin\cmake.exe' -S (Join-Path $logRoot 'asm-repro') -B $build -G Ninja -DCMAKE_BUILD_TYPE=Release "-DRESTRICT_VENDOR_ASM_EXTENSIONS=$variant" > $log 2>&1
  $code = $LASTEXITCODE
  Get-Content -LiteralPath $log -Tail 11
  if ($variant -eq 'OFF' -and $code -eq 0) { throw 'The uncorrected fixture did not reproduce the failure' }
  if ($variant -eq 'ON') {
    if ($code -ne 0) { throw 'Scoped extension correction did not configure' }
    & 'C:\Program Files\CMake\bin\cmake.exe' --build $build --parallel 2 >> $log 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Scoped extension correction did not compile the actual MASM source' }
    Get-Content -LiteralPath $log -Tail 4
  }
}
