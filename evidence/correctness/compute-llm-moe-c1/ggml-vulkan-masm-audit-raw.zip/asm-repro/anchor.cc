int hyle_asm_compile_anchor() { return 1; }
