import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root = Path('C:/public/project-hyle/hyle')
logs = root / '.scratch/validation/vulkan-pointwise'
dest = root / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-pointwise-w1'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
candidate = git('rev-parse', 'HEAD')
assert candidate.startswith('4c309c6e') and not git('status', '--porcelain')
verifications = []
artifacts = []
for linkage in ('static', 'shared'):
    build = Path('C:/hyle-scratch/active-vk') / linkage
    for suite, cases in [('compute_provider_ggml_vulkan', 19),
                         ('compute_route_vulkan', 40),
                         ('graph_route_vulkan', 17 if linkage == 'static' else 16)]:
        stem = f'{linkage}-{suite}'
        result = read(logs / (stem + '.json'))
        assert result['tests'] == cases and result['failures'] == result['disabled'] == result['errors'] == 0
        assert all(test['status'] == 'RUN' and test['result'] == 'COMPLETED'
                   for group in result['testsuites'] for test in group['testsuite'])
        raw = (logs / (stem + '.log')).read_text(encoding='utf-8-sig', errors='replace')
        assert not any(marker in raw for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
        verifications.append({'linkage': linkage, 'suite': suite, 'cases': cases, 'skipped': 0,
                              'status': 'PASS', 'log': stem + '.log', 'results': stem + '.json'})
        exe = build / 'bin' / ('hyle_' + suite + '_test.exe')
        artifacts.append({'path': str(exe), 'bytes': exe.stat().st_size, 'sha256': sha(exe)})
    ctest = ET.parse(logs / (linkage + '-ctest.xml')).getroot()
    assert ctest.get('tests') == '2' and ctest.get('failures') == ctest.get('skipped') == '0'
    verifications.append({'linkage': linkage, 'suite': 'source contract and MASM composition',
                          'ctest_entries': 2, 'status': 'PASS', 'log': linkage + '-test.log'})
    for path in (build / 'bin').glob('*.dll'):
        artifacts.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)})
    (logs / (linkage + '-CMakeCache.txt')).write_bytes((build / 'CMakeCache.txt').read_bytes())
loc = read(logs / 'loc.json')
assert loc['repository']['commit'] == candidate and loc['self_check'] == 'pass'
selector = read(logs / 'selector.json')
assert selector['candidate_commit'] == candidate and selector['verdict'] == 'READY'
assert not selector['product_authorization']['issues']
files = {p.name:p for p in logs.iterdir() if p.is_file() and
         (p.name.startswith(('static-', 'shared-', 'candidate-')) and p.suffix in ('.log', '.json', '.xml', '.txt')
          or p.name in ('loc.json', 'selector.json', 'record-w1.py'))}
files['vulkan-pointwise-run.ps1'] = root / '.scratch/validation/vulkan-pointwise-run.ps1'
dest.mkdir(exist_ok=True)
archive = dest / 'raw-bundle.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
    for name, path in sorted(files.items()):
        out.write(path, name)
with zipfile.ZipFile(archive) as stored:
    assert stored.testzip() is None
    assert all(hashlib.sha256(stored.read(name)).hexdigest() == sha(path) for name, path in files.items())
result = {'schema': 'hyle.ggml-vulkan-pointwise-w1/v1', 'date': '2026-09-19', 'owner': '/root',
          'audit': '4add4d1d', 'candidate': candidate, 'tree': git('rev-parse', 'HEAD^{tree}'),
          'upstream': '456172ec733a135778adcd32d00e576a58232e45; existing nine patches unchanged',
          'scope': 'C1-Y17-Y19 ordinary F32 pointwise family; seven added mappings, rank0 scalar and order-preserving Repeat',
          'validation': verifications, 'artifacts': artifacts,
          'configuration': {'machine': 'W1-WIN RTX 4070', 'compiler': 'MSVC 19.50.35728.0',
                            'build': 'Ninja Release WERROR, shipping layout, parallel2',
                            'runtime': 'DLLs beside EXE; PATH unset; process error dialogs disabled; Khronos validation enabled',
                            'selected_factors': ['compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan']},
          'semantics': ['Independent FP64 math for unary rank0/1/2/4 and special values; exact Abs/Neg checks.',
                        'Sub/Div scalar, row and column broadcasting on either side; inputs retained; fixed Recorder replay.',
                        'Published intermediate values and scalar-left Sub/Div in an ordinary Graph without a norm/gate anchor.',
                        'Two independent slots, changing inputs, old results; original failure/drain/close regressions retained.',
                        'Native boundary fault fixture uses still-native ReLU so the accepted-prefix rejection remains meaningful.'],
          'p0': 'Original managed traversal/encoding, boundary copies and optional full-shape Repeat scratch/dispatch are charged; no new runtime winner search.',
          'performance': 'NOT_RUN for this batch; no preferred winner or Native deletion signed.',
          'delivery': 'Static/shared producer and test consumers only; complete independent source/installed/relocated consumer journeys remain pending.',
          'remaining': ['Air and Mini correctness/portability', 'actual local model weight fragments',
                        'complete C1-Y three C++ deliveries', 'remaining C1 provider binding and index/topk/scan domains',
                        'qualified complete-cost performance and default rules; then redundant implementation decisions'],
          'coverage_credit': 'No fully accepted C1 requirement/route cell; partial correctness evidence only.',
          'implementation_loc': next(m for m in loc['metrics'] if m['id'] == 'module'),
          'shared_case_difference': 'Existing static-only Graph global-new fault injection is absent in shared; zero runtime skips.',
          'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                      'files': [{'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)} for name,p in sorted(files.items())]}}
(dest / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
(dest / 'loc.json').write_bytes((logs / 'loc.json').read_bytes())
print(json.dumps({'archive_bytes': archive.stat().st_size, 'tests': verifications, 'loc': result['implementation_loc']['code']}))
