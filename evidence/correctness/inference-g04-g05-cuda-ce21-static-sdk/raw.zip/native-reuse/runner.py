from pathlib import Path
import hashlib,json,re,subprocess,time,sys
root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05';mode,attempt=sys.argv[1:3];assert mode in ('static','shared');build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph')/(mode+'-sdk-build')
out=base/('ce21-'+mode+'-native-reuse-'+attempt);out.mkdir(exist_ok=False);started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((base/'cuda-host-san/ggml-cuda-reuse-proof.json').read_text());expected=proof['modes']['asan']
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True));unary=next(row for row in commands if row['file'].endswith('/src/ggml-cuda/unary.cu'))
new_root=Path(unary['file'].split('/src/ggml-cuda/')[0]);old_root=new_root.parent/'source-c41bfd1864980360';assert old_root.exists()
for name,digest in expected['derived_dependencies']:assert sha(new_root/name)==sha(old_root/name)==digest,name
for name,digest in expected['canonical_dependencies']:assert sha(root/name)==digest,name
original=(build/'build.ninja').read_text();lines=original.splitlines(keepends=True);result=[];objects=[];mapped=[];i=0
old_unary=None;new_unary=None
while i<len(lines):
 line=lines[i]
 if line.startswith('build ') and '.cu.o:' in line and ('/CMakeFiles/ggml-cuda.dir/' in line or '/CMakeFiles/ggml-cuda-precise-unary.dir/' in line):
  block=[line];i+=1
  while i<len(lines) and lines[i].startswith('  '):block.append(lines[i]);i+=1
  before=''.join(block);after=before.replace(str(new_root),str(old_root)).replace(new_root.name,old_root.name)
  before_output=before.splitlines()[0][6:].split(': ',1)[0];after_output=after.splitlines()[0][6:].split(': ',1)[0]
  assert (build/after_output).is_file(),after_output
  if before_output!=after_output:new_unary,old_unary=before_output,after_output
  objects.append(after_output);mapped.append(dict(old_output=after_output,new_output=before_output,object_sha256=sha(build/after_output),before=before,after=after));result.append(after)
 else:result.append(line);i+=1
assert len(objects)==146 and old_unary and new_unary
text=''.join(result).replace(new_unary,old_unary)
manifest=out/'reuse.ninja';manifest.write_text(text)
command=['ninja','-C',str(build),'-f',str(manifest),'-n',*objects]
check=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'object-check.log').write_text(check.stdout)
assert check.returncode==0
assert 'Building CUDA object' not in check.stdout and 'Re-running CMake' not in check.stdout,check.stdout[:1800]
(out/'mapped-edges.json').write_text(json.dumps(mapped,indent=2)+'\n')
r=dict(state='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK',elapsed_seconds=time.monotonic()-started,build=str(build),old_derived_source=str(old_root),new_derived_source=str(new_root),
 original_manifest_sha256=sha(build/'build.ninja'),reuse_manifest_sha256=sha(manifest),verified_derived_inputs=242,verified_canonical_inputs=5,
 native_object_count=146,original_object_checks='Ninja validates original command identity and dependency freshness on old-source paths; no native compile is scheduled',
 scope='Private build-local manifest maps only byte-identical ggml CUDA source/include paths and the precise unary object reference; all current CPU/FlashInfer/other product edges retained.')
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');(out/'runner.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(r))
