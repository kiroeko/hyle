from pathlib import Path
import hashlib,json,re,subprocess
B=Path('/root/hyle-scratch/compute-unified');S=B/'source-7a7b4c3b'
CAN=Path('/mnt/c/public/project-hyle/hyle');SDK=B/'l-cpu-cuda/selected-graph/static-sdk-build'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rules(build):
 return [(line[6:].split(': ',1)[0],Path(line.split(': ',1)[1].split()[1])) for line in (build/'build.ninja').read_text().splitlines() if line.startswith('build ') and '.cu.o:' in line and any(x in line for x in ('/CMakeFiles/ggml-cuda.dir/','/CMakeFiles/ggml-cuda-precise-unary.dir/'))]
def native_root(rows):return Path(re.search(r'(/root/.*?/source-[^/]+)',next(str(p) for _,p in rows if '/source-' in str(p)))[1])
new=native_root(rules(SDK));result={'kind':'UNCHANGED_GGML_CUDA_SANITIZER_ARCHIVE_REUSE','current_derived_source':str(new),'modes':{}}
expected={'asan':'f0f900aee245acf47cc5d5862d1237c4939e3fac32fb6a16f5220c46ebe9b4d5','ubsan':'0d75dd63db7ba706fc0f615da7cbc0c6981430b3db8a94f414e282334c033cd6','tsan':'14dc738087a3d6f5d5b1c2f5a569bce507d7324966c05d3422dccd3cef337414'}
for mode in ('asan','ubsan','tsan'):
 folder=B/f'foundation-f5-native-host-cuda-{mode}';build=folder/'build';objects=rules(build);old=native_root(objects)
 job=json.loads((folder/'job.json').read_text());text=subprocess.check_output(['ninja','-C',str(build),'-t','deps'],text=True)
 deps={};current=None
 for line in text.splitlines():
  if not line.strip():current=None
  elif line.startswith('    ') and current is not None:deps[current].append(Path(line.strip()))
  elif ': #' in line:current=line.split(': #',1)[0];deps[current]=[]
 pairs={};external={}
 for obj,_ in objects:
  output=build/obj;assert output.is_file() and obj in deps,obj
  for p in deps[obj]:
   if not p.is_absolute():p=build/p
   if p.is_relative_to(old):pairs[p]=new/p.relative_to(old)
   else:external[p]=min(external.get(p,float('inf')),output.stat().st_mtime)
 rows=[]
 for p,q in sorted(pairs.items()):
  assert p.is_file() and q.is_file() and sha(p)==sha(q),p
  rows.append((str(p.relative_to(old)),sha(p)))
 missing=[str(p) for p in external if not p.is_file()]
 newer=[str(p) for p,t in external.items() if p.is_file() and p.stat().st_mtime>t]
 canonical=[]
 for p in sorted(external):
  if p.is_relative_to(S):
   rel=str(p.relative_to(S));prior=subprocess.check_output(['git','show',job['candidate']+':'+rel],cwd=CAN)
   assert hashlib.sha256(prior).hexdigest()==sha(p)==sha(CAN/rel),rel
   canonical.append((rel,sha(p)))
 archive=next(build.rglob('libggml-cuda.a'));members=subprocess.check_output(['ar','t',str(archive)],text=True).splitlines()
 commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
 object_names={str(x[0]) for x in objects};native_commands=[r for r in commands if r.get('output') in object_names]
 assert len(native_commands)==146,len(native_commands)
 flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
 assert all(flag in r['command'] and 'compute_89' in r['command'] for r in native_commands)
 data={'verdict':'REUSABLE_UNCHANGED_NATIVE_ARCHIVE','archive':str(archive),'archive_sha256':sha(archive),'objects':len(objects),'archive_members':len(members),'old_derived_source':str(old),'derived_dependencies':rows,'derived_aggregate_sha256':hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest(),'external_count':len(external),'external_missing':missing,'external_newer':newer,'canonical_dependencies':canonical,'original_identity':job['identity'],'instrumented_commands':native_commands,'external_input_policy':'Historical external header hashes were not retained. Existing ninja dependency freshness plus matching original toolchain/package identity; no false historical-hash claim.','scope':'Only unchanged SM89 ggml native archive; current SDK also has SM80, not claimed here; CPU/base/FI/all changed HYLE host are rebuilt.'}
 assert len(objects)==len(members)==146 and len(rows)==242 and not missing and not newer
 assert data['archive_sha256']==expected[mode]
 result['modes'][mode]=data
print(json.dumps(result,indent=2))
