from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';SAN=BASE/'cuda-host-san'
records=[json.loads((SAN/f'asan-{i}/result.json').read_text()) for i in (1,2)]
assert records[0]['state']=='TERMINAL_FAIL' and records[1]['state']=='TERMINAL_PASS'
assert records[0]['inputs']==records[1]['inputs']
tests=ET.parse(SAN/'asan-2/tests.xml').getroot()
assert int(tests.attrib['tests'])==13 and int(tests.attrib['failures'])==0 and int(tests.attrib['errors'])==0
dest=ROOT/'evidence/correctness/inference-g04-g05-cuda-encoded-host-asan';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for i in (1,2):
  for p in sorted((SAN/f'asan-{i}').rglob('*')):
   if p.is_file():package.write(p,f'asan-{i}/'+p.relative_to(SAN/f'asan-{i}').as_posix())
 for name in ('encoded_cuda_host_san.py','launch_encoded_cuda_host_san.py','check_ggml_cuda_reuse.py','resume_cuda_asan_tests.py','seal_cuda_encoded_asan.py'):
  package.write(BASE/name,'runners/'+name)
 package.write(SAN/'source-asan-1.zip','source-asan-1.zip')
receipt={'kind':'G04_G05_CUDA_ENCODED_HOST_ASAN_STAGE','verdict':'PASS_ADDRESS_FACET',
 'identity':records[1]['identity'],'inputs':records[1]['inputs'],
 'runs':[{'attempt':str(i),'state':r['state'],'stages':r['stages'],'cumulative_seconds':r['cumulative_seconds'],
          'setup_error':r.get('setup_error'),'setup_error_elapsed_seconds':r.get('setup_error_elapsed_seconds')} for i,r in enumerate(records,1)],
 'cumulative_measured_seconds':sum(r['cumulative_seconds'] for r in records),
 'unknown_time_retained':'asan-1 wrong test executable path startup; no elapsed measured, not zero',
 'math_and_common_tests':13,'source_risk_modes':5,'environment':records[1]['environment'],
 'reused_archive':records[1]['reused_ggml_cuda'],'binaries':records[1]['binaries'],
 'limits':records[1]['limits']+['UBSan and TSan remain pending; not whole G04/G05','Frozen inputs predate CPU-only CE12 guard optimization; no CE12 CPU runtime claim'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('inputs','runs','identity','binaries')}))
