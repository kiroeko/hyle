from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[3];mode,attempt=sys.argv[1:3]
assert mode in ('asan','ubsan','tsan')
BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'cuda-host-san';OUT.mkdir(exist_ok=True)
# Do not overlap heavy verification or alter its immutable source/artifacts.
live=BASE/'cpu-encoded-p1-job-2.json'
if live.exists():
 state=json.loads(live.read_text(encoding='utf-8'));assert state['state']=='TERMINAL','CPU qualification must actually finish before starting CUDA'
if '--source-archive' in sys.argv:
 archive=Path(sys.argv[sys.argv.index('--source-archive')+1]).resolve()
 assert archive.parent==OUT.resolve() and archive.is_file()
 with zipfile.ZipFile(archive) as package:
  inputs=json.loads(package.read('source-manifest.json'))
  assert all(hashlib.sha256(package.read(item['path'])).hexdigest()==item['sha256'] for item in inputs)
else:
 archive=OUT/f'source-{mode}-{attempt}.zip';assert not archive.exists()
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines();inputs=[]
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
  for name in sorted(set(paths)):
   if name.startswith(('evidence/','.scratch/','.git')):continue
   file=ROOT/name
   if not file.is_file():continue
   raw=file.read_bytes();inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()});package.writestr(name,raw)
  package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
base='/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05'
raise SystemExit(subprocess.run(['wsl','-d','Ubuntu-24.04','-u','root','--','python3',base+'/encoded_cuda_host_san.py',base+'/cuda-host-san/'+archive.name,mode,attempt]).returncode)
