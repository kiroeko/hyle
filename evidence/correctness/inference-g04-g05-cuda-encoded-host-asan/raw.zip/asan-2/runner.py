from pathlib import Path
import hashlib,json,os,subprocess,time
BASE=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/cuda-host-san')
OLD=BASE/'asan-1';RUN=BASE/'asan-2';RUN.mkdir(exist_ok=False)
prior=json.loads((OLD/'result.json').read_text())
assert prior['state']=='TERMINAL_FAIL' and 'FileNotFoundError' in prior['setup_error']
assert prior['stages'][-1]['stage']=='compile' and prior['stages'][-1]['exit_code']==0
SOURCE=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
for item in prior['inputs']:
 assert hashlib.sha256((SOURCE/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
BUILD=Path(prior['build']);binaries={name:BUILD/'hyle'/name for name in ('g04_cuda_encoded_host_tests','g04_cuda_encoded_host_risks')}
assert all(p.is_file() for p in binaries.values())
record={k:v for k,v in prior.items() if k not in ('state','attempt','stages','cumulative_seconds','setup_error','setup_error_elapsed_seconds')}
record.update(state='RUNNING',attempt='2',stages=[],cumulative_seconds=0,
 inherited_compile={'attempt':'asan-1','compile_exit':0,'cumulative_seconds':prior['cumulative_seconds'],'original_failure':'wrong test executable path; original setup elapsed unknown preserved'},
 binaries={name:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in binaries.items()})
(RUN/'runner.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.update(prior['environment']);env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
def save():(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for stage,args in [('tests',[str(binaries['g04_cuda_encoded_host_tests']),'--gtest_output=xml:'+str(RUN/'tests.xml')]),('five-risk-modes',[str(binaries['g04_cuda_encoded_host_risks'])])]:
 log=RUN/f'{stage}.log';start=time.monotonic()
 with log.open('w') as stream:
  p=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':p.pid}))
  print(stage,p.pid,flush=True);code=p.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 record['state']='TERMINAL_FAIL' if code else 'RUNNING';save();print(stage,code,elapsed,flush=True)
 if code:
  (RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}))
  print(log.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(code)
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==record['binaries'][name]['sha256'] for name,p in binaries.items())
record['state']='TERMINAL_PASS';save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
print('CUDA ASan compiled artifact continuation PASS',flush=True)
