from pathlib import Path
import json,os,subprocess,time,hashlib,xml.etree.ElementTree as ET
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'ce14-shader-validation-1';out.mkdir(exist_ok=False)
source=base/'source-c8874688';build=base/'a-cpu-apple/selected-graph/source-build'
env=os.environ.copy();env.update(MTL_SHADER_VALIDATION='1',MTL_SHADER_VALIDATION_ENABLE_ERROR_REPORTING='1',
 MTL_SHADER_VALIDATION_REPORT_TO_STDERR='1',MTL_SHADER_VALIDATION_ABORT_ON_FAULT='1',
 MTL_SHADER_VALIDATION_GLOBAL_MEMORY='1',MTL_SHADER_VALIDATION_THREADGROUP_MEMORY='1')
record=dict(state='RUNNING',environment={k:v for k,v in env.items() if k.startswith('MTL_SHADER_')},stages=[],
 scope='Actual Metal shader validation with release native math13/public4; independent enabled-state witness. Host sanitizers are separate; no P1/performance verdict.')
record['identity']={k:subprocess.check_output(c,text=True).strip() for k,c in [('model',['sysctl','-n','hw.model']),('os',['sw_vers']),('compiler',['clang++','--version'])]}
assert record['identity']['model']=='Mac16,12'
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,cmd):
 t=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  record.update(active_stage=name,pid=p.pid);save();print(name,p.pid,flush=True);code=p.wait()
 record['stages'].append(dict(stage=name,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-t));save()
 if code:record['state']='TERMINAL_FAIL';save();raise SystemExit(code)
probe=base/'ce14-pipeline-attribution-6'
run('enabled-state',[str(probe/'probe'),str(probe/'probe.metallib'),str(probe/'query.metallib'),str(probe/'optimized.metallib')])
resources=[l for l in (out/'enabled-state.log').read_text().splitlines() if l.startswith('RESOURCE ')]
assert len(resources)==8 and all('validation=1' in l for l in resources),resources
record['enabled_state_witness']=resources;save()
for name,count,target in [('math',13,'g04_g05_apple_cache'),('pages',4,'g04_g05_encoded_pages')]:
 binary=build/target;record.setdefault('binary_sha256',{})[target]=hashlib.sha256(binary.read_bytes()).hexdigest()
 run(name,[str(binary),'--gtest_output=xml:'+str(out/(name+'.xml'))])
 xml=ET.parse(out/(name+'.xml')).getroot();assert int(xml.attrib['tests'])==count and int(xml.attrib['failures'])==0
record['state']='TERMINAL_PASS_SHADER_VALIDATION_ONLY';save()
