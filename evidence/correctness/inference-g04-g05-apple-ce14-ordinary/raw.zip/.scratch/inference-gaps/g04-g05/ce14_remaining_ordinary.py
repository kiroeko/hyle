from pathlib import Path
import json,os,subprocess,sys,time,hashlib
root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';out=base/'ce14-ordinary-1';out.mkdir(exist_ok=False)
batch=json.loads((base/'ce14-partial-block-batch-5/job.json').read_text());assert batch['state']=='TERMINAL_SOURCE_STATIC_DIAGNOSTIC_COMPLETE_NOT_CANDIDATE'
sys.path.insert(0,str(root/'scripts'));from hyle_perf.nanobench import parse_nanobench
for log in (base/'ce14-partial-block-batch-5/diagnostic').glob('comparison-*.log'):
 rows=list(parse_nanobench(log.read_text()).values())
 for title in dict.fromkeys(r.title for r in rows):
  d={r.variant:r.operations_per_second for r in rows if r.title==title}
  assert d['HYLE Apple encoded page16']/d['Original Apple Q8 gathered page lifecycle']>=.95,(log,title,d)
shipping=json.loads((base/'sdk/result-apple-static-ce14-6.json').read_text());assert shipping['state']=='TERMINAL_PASS'
inputs=[i for i in shipping['inputs'] if i['path'].startswith(('include/','src/','cmake/','third_party/'))]
record=dict(state='RUNNING',pid=os.getpid(),steps=[],heavy_serial=True,max_compile_jobs=4,
 scope='CE14 actual shared SDK -> Apple host ASan/UBSan/TSan -> actual shader validation; no candidate/P1/whole-goal verdict')
def save():(out/'job.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def run(stage,cmd):
 for i in inputs:assert hashlib.sha256((root/i['path']).read_bytes()).hexdigest()==i['sha256'],i['path']
 t=time.monotonic();log=out/(stage+'.log')
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
  record.update(active_stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
 record['steps'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-t,log=str(log)));save()
 print(stage,code,flush=True)
 if code:record['state']='TERMINAL_FAIL';save();raise SystemExit(code)
save()
run('shared-sdk',[sys.executable,str(base/'launch_encoded_sdk.py'),'apple','shared','ce14-1'])
for mode in ('asan','ubsan','tsan'):run(mode,[sys.executable,str(base/'launch_encoded_gpu_san.py'),'apple',mode,'ce14-1'])
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified'
run('shader-validator-deploy',['scp',str(base/'ce14_shader_validation_air.py'),host+':'+remote+'/'])
run('shader-validation',['ssh','-o','BatchMode=yes',host,'python3',remote+'/ce14_shader_validation_air.py'])
run('shader-validation-download',['scp','-r',host+':'+remote+'/ce14-shader-validation-1',str(out/'shader')])
record['state']='TERMINAL_PASS_ORDINARY_ONLY';save()
