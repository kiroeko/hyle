from pathlib import Path
import hashlib,json
base=Path('/Users/kiro/hyle-scratch/compute-unified')
source=base/'source-c8874688'
old=json.loads((source/'bench/inference_resident_sdpa/apple_encoded_peer/qualified-sdk-artifacts.json').read_text())
shipping=json.loads((base/'g04-g05-encoded-sdk/result-apple-static-ce14-6.json').read_text())
assert shipping['state']=='TERMINAL_PASS'
prefix=Path(shipping['prefix'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def members(p):
 data=p.read_bytes();assert data[:8]==b'!<arch>\n';offset=8;result=[];names=b''
 while offset<len(data):
  header=data[offset:offset+60];assert len(header)==60 and header[58:60]==b'`\n'
  name=header[:16].decode().strip();size=int(header[48:58]);payload=data[offset+60:offset+60+size];assert len(payload)==size
  offset+=60+size+(size%2)
  if name.startswith('#1/'):
   length=int(name[3:]);name=payload[:length].rstrip(b'\0').decode();payload=payload[length:]
  elif name=='//':names=payload;continue
  elif name.startswith('/') and name[1:].isdigit():name=names[int(name[1:]):].split(b'/\n',1)[0].decode()
  else:name=name.rstrip('/')
  if name.startswith('__.SYMDEF') or name in ('','/','/SYM64'):continue
  result.append(dict(name=name,bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest()))
 return result
native=[]
for item in old['supplemental_native_archives']:
 installed=prefix/item['path'];producer=Path(item['producer_path']);a,b=members(installed),members(producer)
 assert a and a==b,item['path']
 native.append(dict(path=item['path'],sha256=sha(installed),producer_path=str(producer),producer_sha256=sha(producer),
  whole_archive_equal=installed.read_bytes()==producer.read_bytes(),ordered_member_payloads_equal=True,members=a))
artifact=json.loads((base/'g04-g05-encoded-sdk/artifacts-apple-static-ce14-6.json').read_text())
qualified=[]
for item in artifact:
 p=Path(item['path']);assert sha(p)==item['sha256'];qualified.append(dict(path=p.relative_to(prefix).as_posix(),sha256=item['sha256'],bytes=item['bytes']))
def rows(key):return [dict(path=item['path'],sha256=sha(prefix/item['path'])) for item in old[key]]
record=dict(prefix=str(prefix),supplemental_native_archives=native,qualified_sdk_recipes=rows('qualified_sdk_recipes'),
 native_metallibs=rows('native_metallibs'),qualified_hyle_artifacts=qualified,
 scope='Actual CE14 static Apple SDK: source/installed native math13 and public4, CPU ordinary14+3, headers12 and Metal lifetime passed. Original native archive ordered object payloads checked against current producer. Performance requires its own immutable-source qualification; no CPU/GPU P1 or whole-goal claim here.')
out=base/'ce14-qualified-sdk-artifacts.json';out.write_text(json.dumps(record,indent=2)+'\n')
print('SDK identity bound',len(qualified),'HYLE',len(native),'native',len(record['qualified_sdk_recipes']),'recipes')
