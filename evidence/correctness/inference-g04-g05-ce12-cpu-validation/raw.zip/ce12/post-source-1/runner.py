from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'ce12/post-source-1'
prior=json.loads((BASE/'ce12/cpu-source-2/result.json').read_text())
assert prior['state']=='TERMINAL_PASS'
for name in ('src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/native_paged_test.cc'):
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==prior['inputs'][name],name
OUT.mkdir(exist_ok=False)
record={'state':'RUNNING','max_jobs':4,'heavy_serial':True,'stages':[],'cumulative_seconds':0}
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
commands=[(mode,[sys.executable,str(BASE/'launch_ce12_cpu_host_san.py'),mode,'ce12-1']) for mode in ('asan','ubsan','tsan')]
commands += [(mode+'-sdk',[sys.executable,str(BASE/'encoded_cpu_sdk.py'),mode,'ce12-1']) for mode in ('static','shared')]
for stage,args in commands:
 start=time.monotonic();log=OUT/f'{stage}.log'
 with log.open('wb') as stream:
  p=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT)
  (OUT/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':p.pid}))
  print(stage,p.pid,flush=True);code=p.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 record['state']='TERMINAL_FAIL' if code else 'RUNNING';(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(stage,code,round(elapsed,3),flush=True)
 if code:
  (OUT/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}))
  print(log.read_text(errors='replace')[-5500:],flush=True);raise SystemExit(code)
record['state']='TERMINAL_PASS';(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(OUT/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
print('CE12 CPU three host risk modes and two SDK configs complete',flush=True)
