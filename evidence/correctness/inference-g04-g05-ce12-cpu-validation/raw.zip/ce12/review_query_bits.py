import hashlib,json,math,struct
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
limit=65504.*127.;limit_bits=struct.unpack('<I',struct.pack('<f',limit))[0]
for kind in ('f16','bf16'):
 for bits in range(65536):
  value=struct.unpack('<e',struct.pack('<H',bits))[0] if kind=='f16' else struct.unpack('<f',struct.pack('<I',bits<<16))[0]
  original=math.isfinite(value) and abs(value)<=limit
  candidate=(bits&0x7fff)<0x7c00 if kind=='f16' else (bits&0x7fff)<=(limit_bits>>16)
  assert original==candidate,(kind,bits,value)
record={'scope':'independent representation-rule review; not compiled product test',
 'f16_patterns':65536,'bf16_patterns':65536,'mismatches':0,'limit':limit,
 'limit_bits':hex(limit_bits),'bf16_floor_bits':hex(limit_bits>>16),
 'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in (
 'src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/native_paged_test.cc')},
 'independent_readonly_review':'No remaining MUST. Correct typed predicate and before-output InvalidArgument/finish; 92 public episodes use decoded numerical oracle and original poisoned-slot lifecycle. No build/test performed by reviewer.'}
(Path(__file__).parent/'representation-review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='source_sha256'}))
