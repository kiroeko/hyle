from pathlib import Path
import hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as ET
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05'
dest=ROOT/'evidence/correctness/inference-g04-g05-ce12-cpu-validation'
assert not dest.exists()
runs=[];files=[]
for i in (1,2):
 folder=BASE/f'ce12/cpu-source-{i}';r=json.loads((folder/'result.json').read_text());runs.append({'kind':'source','attempt':i,'record':r})
 files.extend((p,p.relative_to(BASE).as_posix()) for p in folder.rglob('*') if p.is_file())
assert runs[0]['record']['state']=='TERMINAL_FAIL' and runs[1]['record']['state']=='TERMINAL_PASS'
def xml_count(path,count):
 x=ET.parse(path).getroot();assert int(x.attrib['tests'])==count and int(x.attrib['failures'])==0 and int(x.attrib['errors'])==0
xml_count(BASE/'ce12/cpu-source-2/tests.xml',22)
factor_log=(BASE/'ce12/cpu-source-2/selected-factors.log').read_text()
assert '100% tests passed out of 4' in factor_log
assert len(re.findall(r'^\d/4 Test #\d+:.*\bPassed\s+[0-9.]+ sec$',factor_log,re.M))==4
assert any(s['stage']=='selected-factors' and s['exit_code']==0 for s in runs[1]['record']['stages'])
for mode in ('asan','ubsan','tsan'):
 folder=BASE/f'risk/host-{mode}-ce12-1';r=json.loads((folder/'result.json').read_text());assert r['state']=='TERMINAL_PASS'
 xml_count(folder/'tests.xml',17);runs.append({'kind':'host-risk','mode':mode,'record':r})
 files.extend((p,p.relative_to(BASE).as_posix()) for p in folder.rglob('*') if p.is_file())
 files.append((BASE/f'risk/source-host-{mode}-ce12-1.zip',f'risk/source-host-{mode}-ce12-1.zip'))
for mode in ('static','shared'):
 tag=f'cpu-{mode}-ce12-1';r=json.loads((BASE/f'cpu-sdk/result-{tag}.json').read_text());assert r['state']=='TERMINAL_PASS'
 xml_count(BASE/f'cpu-sdk/cpu_math-{tag}.xml',14);xml_count(BASE/f'cpu-sdk/cpu-{tag}.xml',3)
 runs.append({'kind':'sdk','mode':mode,'record':r})
 files.extend((p,p.relative_to(BASE).as_posix()) for p in (BASE/'cpu-sdk').glob(f'*-{tag}.*') if p.is_file())
post=json.loads((BASE/'ce12/post-source-1/result.json').read_text());assert post['state']=='TERMINAL_PASS'
files.extend((p,p.relative_to(BASE).as_posix()) for p in (BASE/'ce12').glob('*') if p.is_file())
files.extend((p,p.relative_to(BASE).as_posix()) for p in (BASE/'ce12/post-source-1').rglob('*') if p.is_file())
for name in ('ce12_cpu_source.py','ce12_post_source.py','ce12_cpu_host_san.py','launch_ce12_cpu_host_san.py','encoded_cpu_sdk.py','seal_ce12_cpu_validation.py','ce12-validation-plan.json','ce12-validation-plan-final.json'):
 files.append((BASE/name,'runners/'+name))
last=BASE/'ce12/cpu-source-2/selected-factors-LastTest.log'
assert last.is_file();files.append((last,'source-factor-LastTest.log'))
dest.mkdir()
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for path,name in sorted(set(files)):package.write(path,name)
receipt={'kind':'G04_G05_CE12_CPU_QUERY_GUARD_VALIDATION','verdict':'PASS_FINITE_ORDINARY_GATES',
 'product_commit':subprocess.check_output(['git','rev-parse','5f9b261bf'],text=True).strip(),
 'product_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ('src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_ggml/CMakeLists.txt','cmake/HyleComponents.cmake')},
 'runs':[{'kind':x['kind'],'mode':x.get('mode'),'attempt':x.get('attempt'),'state':x['record']['state'],'stages':x['record']['stages'],'cumulative_seconds':x['record']['cumulative_seconds']} for x in runs],
 'cumulative_seconds':sum(x['record']['cumulative_seconds'] for x in runs),
 'post_source_orchestrator_wall_seconds':post['cumulative_seconds'],
 'packaging_failure':{'attempt':1,'reason':'sealer expected obsolete CTest summary wording; actual four gates PASS','elapsed_seconds':None,'original_record':'ce12/seal-attempt-1.json'},
 'source_tests':22,'host_tests_per_mode':17,'source_risk_modes_per_mode':9,'sdk_math_per_mode':14,'sdk_common_per_mode':3,'sdk_independent_headers_per_mode':12,
 'representation_patterns_reviewed':131072,'public_boundary_episodes_per_test_run':92,
 'limits':['Same finite query math/output/error contract; no public API change','P1 still pending; no speedup or whole G04/G05 claim','Two CPU SDK modes reuse one explicitly reconfigured producer tree','Old source link FAIL retained; selector test-only central declaration over-selection tracked separately; no unrelated global gates executed'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('runs','product_sha256')}))
