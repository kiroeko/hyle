from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
archive,mode,attempt=sys.argv[1:4]
assert mode in ('asan','ubsan','tsan')
ROOT=Path('/mnt/c/public/project-hyle/hyle')
SOURCE=Path('/home/kiro/hyle-f1/sanitizers/source-03242e7723cb')
BUILD=SOURCE.parent/f'{mode}-03242e7723cb'
OUT=ROOT/'.scratch/inference-gaps/g04-g05/risk'
RUN=OUT/f'host-{mode}-{attempt}';RUN.mkdir(parents=True,exist_ok=False)
assert SOURCE.is_dir() and not (SOURCE/'.git').exists() and (BUILD/'CMakeCache.txt').exists()
with zipfile.ZipFile(archive) as package:
    inputs=json.loads(package.read('source-manifest.json'))
    for item in inputs:
        name=Path(item['path']);assert not name.is_absolute() and '..' not in name.parts
        raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
        file=SOURCE/name
        if not file.exists() or file.read_bytes()!=raw:
            file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
hook=OUT/f'host-{mode}-project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
 add_subdirectory("/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6" g04-host-risk-gtest EXCLUDE_FROM_ALL)
 function(g04_host_risks)
  add_executable(g04_encoded_host_tests "@SOURCE@/tests/compute_provider_ggml/native_paged_test.cc" "@SOURCE@/tests/compute_batch/encoded_page_common_consumer.cc")
  target_link_libraries(g04_encoded_host_tests PRIVATE hyle::compute hyle::graph GTest::gtest_main)
  add_executable(g04_encoded_host_risks "@SOURCE@/tests/compute_batch/pending_paged_receiver_cpu_risks.cc")
  target_compile_definitions(g04_encoded_host_risks PRIVATE HYLE_ENCODED_PAGE_RISK=1)
  target_link_libraries(g04_encoded_host_risks PRIVATE hyle::compute)
  foreach(target IN ITEMS g04_encoded_host_tests g04_encoded_host_risks)
   target_compile_features(${target} PRIVATE cxx_std_23)
   target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic -Werror)
   hyle_apply_sanitizer(${target})
   hyle_stage_runtime(${target})
  endforeach()
  @EXTRA@
 endfunction()
 cmake_language(DEFER CALL g04_host_risks)
endif()
'''.replace('@SOURCE@',str(SOURCE))
extra=''
if mode=='ubsan':
    extra='\n'.join(f'target_compile_options({target} PRIVATE -fsanitize=float-cast-overflow -fno-sanitize-recover=all)' for target in
                    ['ggml-base','hyle_compute_provider_ggml','g04_encoded_host_tests','g04_encoded_host_risks'])
body=body.replace('@EXTRA@',extra)
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
env=os.environ.copy();env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
record={'state':'RUNNING','mode':mode,'inputs':inputs,'max_jobs':4,'stages':[],'cumulative_seconds':0,
        'identity':{'host':subprocess.check_output(['uname','-a'],text=True).strip(),'compiler':subprocess.check_output(['g++-14','--version'],text=True).splitlines()[0]},
        'scope':'CE12 CPU-only query safety F16/BF16 first/last representation boundaries plus original boxed attention; actual Q8/FP8 encoder including two concurrent original lanes and isolated failure; original public encoded F2/Graph; Q8 D64/128 pending receiver nine risk modes. No GPU/SDK/P1 claim.'}
commands=[('configure',['cmake','-S',str(SOURCE),'-B',str(BUILD),'-DCMAKE_PROJECT_INCLUDE='+str(hook)]),
          ('compile',['cmake','--build',str(BUILD),'--target','g04_encoded_host_tests','g04_encoded_host_risks','--parallel','4']),
          ('tests',[str(BUILD/'bin/g04_encoded_host_tests'),'--gtest_filter=GgmlCpuCacheEncode.*:GgmlCpuBoxed.*:EncodedCommonPages.*','--gtest_output=xml:'+str(RUN/'tests.xml')]),
          ('nine-risk-modes',[str(BUILD/'bin/g04_encoded_host_risks')])]
if '--skip-configure' in sys.argv:commands=commands[1:]
if mode=='tsan':
    commands=[(stage,['setarch','x86_64','-R',*command] if stage in ('tests','nine-risk-modes') else command) for stage,command in commands]
for stage,command in commands:
    if stage=='tests':
        rows=json.loads(subprocess.check_output(['ninja','-C',str(BUILD),'-t','compdb'],text=True))
        flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
        checked=[]
        for name in ['ggml-quants.c','ggml_cpu_provider.cc','native_paged_test.cc','encoded_page_common_consumer.cc','pending_paged_receiver_cpu_risks.cc']:
            found=[r for r in rows if r['file'].endswith('/'+name)]
            assert found and all(flag in r['command'] for r in found),name
            checked.extend(found)
        (RUN/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\n')
    start=time.monotonic();log=RUN/f'{stage}.log'
    with log.open('w') as stream:
        process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid}))
        print(mode,stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start
    record['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    record['cumulative_seconds']+=elapsed;record['state']='TERMINAL_FAIL' if code else 'RUNNING'
    (RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    print(mode,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
record['state']='TERMINAL_PASS';(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
