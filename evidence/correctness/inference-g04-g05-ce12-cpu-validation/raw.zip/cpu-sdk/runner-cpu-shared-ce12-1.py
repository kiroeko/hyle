from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
mode,attempt=sys.argv[1:3];assert mode in ('static','shared')
OUT=ROOT/'.scratch/inference-gaps/g04-g05/cpu-sdk';OUT.mkdir(exist_ok=True)
tag=f'cpu-{mode}-{attempt}';result_file=OUT/f'result-{tag}.json';assert not result_file.exists()
producer=ROOT/'.scratch/build-compute-v2-dev'
folder=Path('C:/h7')/f'g04-sdk-{tag}';assert not folder.exists()
folder.mkdir();staging=folder/'staging';prefix=folder/'relocated';consumer=folder/'consumer';consumer.mkdir();build=folder/'build'
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.stdout.splitlines() if '=' in line and not line.startswith('=')))
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs=[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in sorted(set(paths)) if (ROOT/name).is_file() and not name.startswith(('evidence/','.scratch/','.git'))]
record={'state':'RUNNING','mode':mode,'attempt':attempt,'max_jobs':4,'product_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'identity':{'host':env.get('COMPUTERNAME'),'compiler':env.get('VCTOOLSVERSION'),'routes':'cpu'},'inputs':inputs,'producer':str(producer),'prefix':str(prefix),
        'scope':'Actual Windows CPU-only ffa native encode/math, public Direct/Graph incremental Q8 F2 consumers, relocated installed static/shared and twelve independent headers; same producer tree switched modes explicitly, not two independent trees.',
        'stages':[],'cumulative_seconds':0}
(OUT/f'runner-{tag}.py').write_bytes(Path(__file__).read_bytes())
(OUT/f'input-manifest-{tag}.json').write_text(json.dumps(inputs,indent=2)+'\n')
def run(stage,args):
    log=OUT/f'{stage}-{tag}.log';start=time.monotonic()
    with log.open('wb') as handle:
        process=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'RUNNING','pid':process.pid,'stage':stage,'log':str(log)}))
        print(tag,stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed
    record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    record['state']='TERMINAL_FAIL' if code else 'RUNNING';result_file.write_text(json.dumps(record,indent=2)+'\n')
    print(tag,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}))
        print(log.read_text(encoding='utf-8',errors='replace')[-6500:],flush=True);raise SystemExit(code)
run('producer-configure',['cmake','-S',str(ROOT),'-B',str(producer),'-UCMAKE_PROJECT_INCLUDE',
    '-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF')])
cache=(producer/'CMakeCache.txt').read_text();assert 'HYLE_COMPUTE_ROUTES:STRING=cpu\n' in cache and 'HYLE_SANITIZER:STRING=off' in cache
ggml=next(s.split('=',1)[1] for s in cache.splitlines() if s.startswith('FETCHCONTENT_SOURCE_DIR_GGML_CPU:'))
assert 'ggml_cpu-ffa4e8b80930-' in ggml
record['identity']['ggml_source']=ggml
commands=json.loads(subprocess.check_output(['ninja','-C',str(producer),'-t','compdb'],env=env,text=True))
shipping=[r for r in commands if '/src/' in r['file'].replace('\\','/') and str(ROOT).replace('\\','/') in r['file'].replace('\\','/')]
assert shipping and all('HYLE_TESTING' not in c['command'] for c in shipping)
(OUT/f'shipping-{tag}.json').write_text(json.dumps(shipping,indent=2)+'\n')
run('producer-build',['cmake','--build',str(producer),'--target','hyle_compute','hyle_compute_batch','hyle_compute_stream','hyle_compute_state','hyle_compute_backend_cpu','hyle_compute_provider_ggml','hyle_compute_route_cpu','hyle_graph','hyle_graph_batch','--parallel','4'])
run('install',['cmake','--install',str(producer),'--prefix',str(staging)])
staging.rename(prefix);assert not staging.exists()
headers=['compute/batch_execution.h','compute/batch_layout.h','compute/batch_materialize.h','compute/batch_ops.h',
    'compute/batch_paged_native.h','compute/detail/materialized_native_controller.h','compute/detail/paged_arena_access.h',
    'compute/low_precision.h','compute/model_ops.h','compute/operation.h','compute/paged_arena.h','graph/batch.h']
for i,name in enumerate(headers):
    assert (prefix/'include/hyle'/name).read_bytes()==(ROOT/'include/hyle'/name).read_bytes()
    (consumer/f'header-{i}.cc').write_text(f'#include <hyle/{name}>\n')
for name in ['tests/compute_batch/encoded_page_common_consumer.cc','tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_native/half_test_support.h']:
    file=consumer/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes((ROOT/name).read_bytes())
body='''cmake_minimum_required(VERSION 3.25)
project(g04_cpu_only_encoded_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 gtest EXCLUDE_FROM_ALL)
add_executable(cpu tests/compute_batch/encoded_page_common_consumer.cc)
add_executable(cpu_math tests/compute_provider_ggml/native_paged_test.cc)
add_library(headers OBJECT @HEADERS@)
foreach(t cpu cpu_math headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE /W4 /WX /wd4324 /utf-8)
 target_link_libraries(${t} PRIVATE hyle::graph)
endforeach()
foreach(t cpu cpu_math)
 target_link_libraries(${t} PRIVATE GTest::gtest_main)
 hyle_stage_runtime(${t})
endforeach()
'''.replace('@HEADERS@',' '.join(f'header-{i}.cc' for i in range(12)))
(consumer/'CMakeLists.txt').write_text(body);(OUT/f'consumer-project-{tag}.cmake').write_text(body)
run('consumer-configure',['cmake','-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
run('consumer-build',['cmake','--build',str(build),'--target','cpu','cpu_math','headers','--parallel','4'])
commands=json.loads((build/'compile_commands.json').read_text())
actual=[r for r in commands if str(consumer).replace('\\','/') in r['file'].replace('\\','/')]
assert len(actual)==14,len(actual)
for row in actual:
    command=row['command'].replace('\\','/')
    assert str(ROOT).replace('\\','/') not in command and str(prefix/'include').replace('\\','/') in command,command
(OUT/f'consumer-commands-{tag}.json').write_text(json.dumps(actual,indent=2)+'\n')
for name in ('cpu_math','cpu'):
    args=[str(build/(name+'.exe')),'--gtest_output=xml:'+str(OUT/f'{name}-{tag}.xml')]
    if name=='cpu_math':args+=['--gtest_filter=GgmlCpuCacheEncode.*:GgmlCpuBoxed.*']
    run(name,args)
artifacts=[p for p in prefix.rglob('*') if p.is_file() and p.suffix in ('.dll','.lib') and p.name.startswith('hyle_')]
assert artifacts
(OUT/f'artifacts-{tag}.json').write_text(json.dumps([{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in artifacts],indent=2)+'\n')
record['state']='TERMINAL_PASS';result_file.write_text(json.dumps(record,indent=2)+'\n')
(OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
print(tag,'ALL CPU-ONLY SHIPPING SDK STAGES PASS',flush=True)
