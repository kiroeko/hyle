import hashlib, json, pathlib, sys, tarfile
root=pathlib.Path(sys.argv[1]).resolve()
assert str(root) in ('/root/hyle-validation/r3-cpu-20260916','/Users/kiro/hyle-validation/r3-cpu-20260916')
source=root/'source-79e96ceb'
manifest=json.loads((root/'correction-projection.json').read_text())
archive=root/'correction-d9712e68.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
with tarfile.open(archive) as package:
    for member in package.getmembers():
        if not member.isfile():
            continue
        assert member.name in manifest['overlay_paths']
        destination=source/member.name
        assert destination.resolve().is_relative_to(source.resolve())
        destination.write_bytes(package.extractfile(member).read())
errors=[name for name,digest in manifest['files'].items() if hashlib.sha256((source/name).read_bytes()).hexdigest()!=digest]
assert not errors, errors
logs=root/'logs-d9712e68'
logs.mkdir(exist_ok=True)
(logs/'product-projection.json').write_text(json.dumps({'gate':'PASS',**manifest},indent=2)+'\n')
print('PASS: immutable candidate product/test/build projection',len(manifest['files']),'files')
