#!/usr/bin/env bash
set -euo pipefail
r3_root=$1
r3_platform=$2
r3_cmake=$3
case "$r3_root" in
  /root/hyle-validation/r3-cpu-20260916|/Users/kiro/hyle-validation/r3-cpu-20260916) ;;
  *) exit 2 ;;
esac
r3_source="$r3_root/source-79e96ceb"
r3_logs="$r3_root/logs-79e96ceb"
mkdir -p "$r3_logs"
cd "$r3_source"
common=(-G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_WARNINGS_AS_ERRORS=ON
  -DHYLE_COMPUTE_ONEDNN=AUTO -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_CPU=ON
  -DHYLE_BUILD_BENCH=OFF)
if [ "$r3_platform" != linux ]; then
  common+=(-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4)
fi
run() {
  local log=$1
  shift
  if ! "$@" >"$r3_logs/$log" 2>&1; then
    tail -n 60 "$r3_logs/$log"
    return 1
  fi
}
cmake_run() { bash scripts/hyle-unix.sh "$r3_cmake" "$@"; }
targets=(r3_consume_compute r3_consume_graph r3_consume_cpu_executor
  hyle_compute_test hyle_compute_backend_cpu_test
  hyle_compute_provider_native_test hyle_graph_test hyle_graph_executable_test
  hyle_compute_route_cpu_test hyle_graph_route_cpu_test
  hyle_graph_route_cpu_cpu_executor_test)
if [ "$r3_platform" = linux ]; then
  targets+=(hyle_compute_provider_onednn_test
    hyle_compute_provider_onednn_composition_test
    hyle_compute_provider_onednn_graph_test hyle_graph_provider_onednn_test)
fi

r3_shared="$r3_root/source-shared"
run source-configure.log cmake_run -S "$r3_root/consumer" -B "$r3_shared" \
  "${common[@]}" -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=ON -DHYLE_INSTALL=OFF \
  "-DHYLE_SOURCE_DIR=$r3_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3_source"
run source-build.log "$r3_cmake" --build "$r3_shared" --parallel 2 --target "${targets[@]}"
run source-tests.log ctest --test-dir "$r3_shared" --output-on-failure --no-tests=error \
  -R '^hyle_(compute|graph)_(header_self_contained_test|test|executable_test)$|^hyle_(compute_route_cpu|graph_route_cpu|compute_provider_native|compute_provider_onednn|graph_provider_onednn|compute_backend_cpu)_.*test$|^r3_consume_'
cp "$r3_shared/Testing/Temporary/LastTest.log" "$r3_logs/source-last-test.log"
tail -n 14 "$r3_logs/source-tests.log"

for linkage in shared static; do
  r3_stage="$r3_root/sdk-$linkage"
  r3_sdk="$r3_root/sdk-$linkage-relocated"
  r3_build=$r3_shared
  r3_static=OFF
  r3_shared_switch=ON
  if [ "$linkage" = static ]; then r3_static=ON; r3_shared_switch=OFF; fi
  run "$linkage-configure.log" cmake_run -S "$r3_root/consumer" -B "$r3_build" \
    "${common[@]}" "-DHYLE_SOURCE_DIR=$r3_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3_source" \
    "-DHYLE_STATIC=$r3_static" "-DBUILD_SHARED_LIBS=$r3_shared_switch" \
    -DHYLE_BUILD_TESTS=OFF -DHYLE_INSTALL=ON
  run "$linkage-build.log" "$r3_cmake" --build "$r3_build" --parallel 2
  run "$linkage-install.log" "$r3_cmake" --install "$r3_build" --prefix "$r3_stage"
  test ! -e "$r3_sdk"
  mv "$r3_stage" "$r3_sdk"
  r3_consumer="$r3_root/consume-$linkage"
  run "$linkage-consumer-configure.log" cmake_run -S "$r3_root/consumer" \
    -B "$r3_consumer" -G Ninja -DCMAKE_BUILD_TYPE=Release \
    "-DCMAKE_PREFIX_PATH=$r3_sdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3_source"
  run "$linkage-consumer-build.log" "$r3_cmake" --build "$r3_consumer" --parallel 2
  run "$linkage-consumer-tests.log" ctest --test-dir "$r3_consumer" \
    --output-on-failure --no-tests=error
  cp "$r3_consumer/Testing/Temporary/LastTest.log" "$r3_logs/$linkage-last-test.log"
  tail -n 10 "$r3_logs/$linkage-consumer-tests.log"
done
printf 'R3 %s source/shared/static consumer verification completed\n' "$r3_platform"
