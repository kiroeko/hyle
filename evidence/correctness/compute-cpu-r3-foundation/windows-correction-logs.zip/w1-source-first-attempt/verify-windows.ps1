$ErrorActionPreference = 'Stop'
$r2Repo = 'C:\public\project-hyle\hyle'
$r2Scratch = 'C:\hyle-scratch\r2-q4-20260916'
Set-Location -LiteralPath $r2Repo
$r2Vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$r2Vs = & $r2Vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $r2Vs) { throw 'MSVC installation missing' }
$r2Dev = Join-Path $r2Vs 'Common7\Tools\VsDevCmd.bat'
$r2Command = 'call "' + $r2Dev + '" -arch=x64 >nul && set'
$r2Environment = & $env:ComSpec /d /s /c $r2Command
if ($LASTEXITCODE -ne 0) { throw 'MSVC initialization failed' }
foreach ($r2Line in $r2Environment) {
    $r2Split = $r2Line.IndexOf('=')
    if ($r2Split -le 0) { continue }
    $r2Name = $r2Line.Substring(0, $r2Split)
    $r2Value = $r2Line.Substring($r2Split + 1)
    if ($r2Name -ieq 'Path' -and $r2Value -notlike "*$r2Vs\VC\Tools\MSVC\*") { continue }
    [Environment]::SetEnvironmentVariable($r2Name, $r2Value, 'Process')
}

$r3Root = 'C:/hyle-scratch/r3-cpu-20260916'
$r3Source = "$r3Root/candidate-d9712e68"
$r3Build = "$r3Root/w1-source-shared"
function Invoke-R3([string]$Name, [scriptblock]$Action) {
  & $Action *> "$r3Root/$Name.log"
  if ($LASTEXITCODE -ne 0) {
    Get-Content "$r3Root/$Name.log" -Tail 55
    exit $LASTEXITCODE
  }
}
Invoke-R3 w1-source-configure {
  cmake -S "$r3Root/consumer" -B $r3Build -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=ON -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON -DHYLE_COMPUTE_ONEDNN=AUTO "-DHYLE_SOURCE_DIR=$r3Source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3Source"
}
Invoke-R3 w1-source-build {
  cmake --build $r3Build --parallel 2 --target r3_consume_compute r3_consume_graph r3_consume_cpu_executor hyle_compute_test hyle_compute_backend_cpu_test hyle_compute_provider_native_test hyle_graph_test hyle_graph_executable_test hyle_compute_route_cpu_test hyle_graph_route_cpu_test hyle_graph_route_cpu_cpu_executor_test hyle_compute_provider_onednn_test hyle_compute_provider_onednn_composition_test hyle_compute_provider_onednn_graph_test hyle_graph_provider_onednn_test
}
Invoke-R3 w1-source-tests {
  ctest --test-dir $r3Build --output-on-failure --no-tests=error -R '^hyle_(compute|graph)_(header_self_contained_test|test|executable_test)$|^hyle_(compute_route_cpu|graph_route_cpu|compute_provider_native|compute_provider_onednn|graph_provider_onednn|compute_backend_cpu)_.*test$|^r3_consume_'
}
Copy-Item -LiteralPath "$r3Build/Testing/Temporary/LastTest.log" -Destination "$r3Root/w1-source-last-test.log"
Get-Content "$r3Root/w1-source-tests.log" -Tail 15
foreach ($r3Mode in @('shared','static')) {
  $r3Product = if ($r3Mode -eq 'shared') { $r3Build } else { "$r3Root/p1-graph-correction-build" }
  if ($r3Mode -eq 'shared') {
    Invoke-R3 w1-shared-configure { cmake -S "$r3Root/consumer" -B $r3Product -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=OFF -DHYLE_INSTALL=ON -DHYLE_COMPUTE_ONEDNN=AUTO -DHYLE_WERROR=ON "-DHYLE_SOURCE_DIR=$r3Source" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3Source" }
    Invoke-R3 w1-shared-build { cmake --build $r3Product --parallel 2 }
  }
  if (-not (Test-Path -LiteralPath "$r3Product/CMakeCache.txt")) { throw "Missing frozen product build: $r3Product" }
  $r3Stage = [IO.Path]::GetFullPath("$r3Root/w1-$r3Mode-sdk")
  $r3Sdk = [IO.Path]::GetFullPath("$r3Root/w1-$r3Mode-sdk-relocated")
  $r3Boundary = [IO.Path]::GetFullPath($r3Root).TrimEnd('\') + '\'
  if (-not $r3Stage.StartsWith($r3Boundary,[StringComparison]::OrdinalIgnoreCase) -or -not $r3Sdk.StartsWith($r3Boundary,[StringComparison]::OrdinalIgnoreCase)) { throw 'SDK move escaped the R3 validation directory' }
  if (Test-Path -LiteralPath $r3Sdk) { throw "SDK destination already exists: $r3Sdk" }
  Invoke-R3 "w1-$r3Mode-install" { cmake --install $r3Product --prefix $r3Stage }
  Move-Item -LiteralPath $r3Stage -Destination $r3Sdk
  $r3Consumer = "$r3Root/w1-consume-$r3Mode"
  Invoke-R3 "w1-$r3Mode-consumer-configure" { cmake -S "$r3Root/consumer" -B $r3Consumer -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$r3Sdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$r3Source" }
  Invoke-R3 "w1-$r3Mode-consumer-build" { cmake --build $r3Consumer --parallel 2 }
  Invoke-R3 "w1-$r3Mode-consumer-tests" { ctest --test-dir $r3Consumer --output-on-failure --no-tests=error }
  Copy-Item -LiteralPath "$r3Consumer/Testing/Temporary/LastTest.log" -Destination "$r3Root/w1-$r3Mode-last-test.log"
  Get-Content "$r3Root/w1-$r3Mode-consumer-tests.log" -Tail 10
}
