param([Parameter(Mandatory=$true)][string]$Build)
$ErrorActionPreference = 'Stop'
$r3Dlls = @(Get-ChildItem -LiteralPath "$Build/hyle_build/src" -Recurse -Filter '*.dll') + @(Get-ChildItem -LiteralPath "$Build/bin" -Filter '*.dll')
if (-not ($r3Dlls.Name -contains 'gtest.dll') -or -not ($r3Dlls.Name -contains 'gtest_main.dll')) { throw 'GoogleTest runtime DLLs were not built' }
if (@($r3Dlls | Group-Object Name | Where-Object Count -gt 1).Count -ne 0) { throw 'Ambiguous runtime DLL producer' }
$r3ExeDirectories = @(Get-ChildItem -LiteralPath "$Build/hyle_build/tests" -Recurse -Filter '*.exe' | ForEach-Object DirectoryName | Sort-Object -Unique)
foreach ($r3Directory in $r3ExeDirectories) {
  foreach ($r3Dll in $r3Dlls) {
    Copy-Item -LiteralPath $r3Dll.FullName -Destination (Join-Path $r3Directory $r3Dll.Name) -Force
  }
}
$r3Dlls | ForEach-Object { [pscustomobject]@{Path=$_.FullName;Sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash} } | ConvertTo-Json | Set-Content -Encoding utf8 "$Build/../w1-test-dll-staging.json"
"Staged $($r3Dlls.Count) runtime DLLs beside test executables in $($r3ExeDirectories.Count) directories"
