exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-onednn-fused-tail';out.mkdir(parents=True,exist_ok=True)
build=Path('C:/hv/cpu-onednn-fused-tail-probe');records=[]
run('configure',['cmake','-S',out,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=C:/hv/cpu-ggml-isa-static-sdk','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build',['cmake','--build',build,'--parallel','1'])
import os,hashlib
sdk=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib')
links=[]
for folder in (Path('C:/hv/cpu-ggml-isa-static-sdk/bin'),sdk):
 for source in folder.glob('*.dll'):
  target=build/source.name
  if not target.exists():os.link(source,target)
  links.append(dict(name=source.name,sha256=hashlib.sha256(source.read_bytes()).hexdigest(),hardlink=True))
(out/'runtime-identity.json').write_text(json.dumps(links,indent=2)+'\n')
(out/'product-identity.json').write_text(json.dumps(dict(actual_consumer_head=candidate,product_candidate='c2df0b8973a80b7140e69983c8e861668483a97c',sdk='C:/hv/cpu-ggml-isa-static-sdk',scope='One tiny public constant FFN diagnostic, no timing or product change'),indent=2)+'\n')
run('public-constant-ffn-tail',[build/'cpu_onednn_fused_tail.exe'])
