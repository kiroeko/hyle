#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <span>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/graph/cpu.h"

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template<class T> T take(hyle::Result<T> result) {
  if (!result) { std::fprintf(stderr, "%.*s\n", int(result.error().message().size()), result.error().message().data()); std::exit(2); }
  return std::move(*result);
}
void require(hyle::Status status) {
  if (!status.ok()) { std::fprintf(stderr, "%.*s\n", int(status.message().size()), status.message().data()); std::exit(2); }
}
int main() {
  const auto input_desc = take(c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t,2>{1,8}));
  const auto weight_desc = take(c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t,2>{8,8}));
  const auto down_desc = take(c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t,2>{8,1}));
  const auto output_desc = take(c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t,2>{1,1}));
  auto allocate=[](const c::TensorDesc& desc) { return take(m::Buffer::create(m::system_resource(),desc.required_bytes().value(),64)); };
  const std::array<float,8> values{1,0,0,0,0,0,0,0};
  int failures=0;
  for (float x : {-80.F,-90.F,-100.F}) {
    auto input=allocate(input_desc), gate_weight=allocate(weight_desc), up_weight=allocate(weight_desc), down_weight=allocate(down_desc), output=allocate(output_desc);
    std::array<float,64> gate{},up{};
    for(std::size_t i=0;i<8;++i){gate[i]=x;up[i]=1e38F;}
    std::array<float,8> down{};down.fill(0.125F);
    require(input.view().write(std::as_bytes(std::span(values))));
    require(gate_weight.view().write(std::as_bytes(std::span(gate))));
    require(up_weight.view().write(std::as_bytes(std::span(up))));
    require(down_weight.view().write(std::as_bytes(std::span(down))));
    auto builder=take(g::GraphBuilder::create());
    auto a=take(builder.input(input_desc));
    auto wg=take(builder.constant(weight_desc)),wu=take(builder.constant(weight_desc)),wd=take(builder.constant(down_desc));
    const c::MatMul mm{.accumulation_type=c::DataType::kFloat32};
    auto score=take(builder.add(mm,a,wg)),value=take(builder.add(mm,a,wu));
    auto gated=take(builder.add(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate},score,value));
    auto final=take(builder.add(mm,gated,wd));
    require(builder.publish(final));
    auto logical=take(std::move(builder).finish());
    auto context=take(g::cpu::create_context());
    const std::array constants{
      g::ConstantBinding{wg,take(c::ConstTensorView::create(weight_desc,gate_weight.view()))},
      g::ConstantBinding{wu,take(c::ConstTensorView::create(weight_desc,up_weight.view()))},
      g::ConstantBinding{wd,take(c::ConstTensorView::create(down_desc,down_weight.view()))}};
    auto compiled=take(g::compile(logical,context,{.constants=constants}));
    auto queue=take(context.create_queue());
    auto invocation=take(compiled.executable.create_invocation());
    require(invocation.bind(a,take(c::ConstTensorView::create(input_desc,input.view()))));
    require(invocation.bind(final,take(c::TensorView::create(output_desc,output.view()))));
    const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&queue}};
    require(invocation.prepare_replay(queues));
    require(take(invocation.submit(queue)).wait());
    float actual=0;require(output.view().read(std::as_writable_bytes(std::span(&actual,1))));
    const auto e=std::exp(double(x));
    const float activation=float(double(x)*(e/(1+e)));
    const float expected=activation*1e38F;
    const bool match=std::isfinite(actual)&&std::abs(actual-expected)<=1e-5F*std::abs(expected)+1e-8F;
    failures+=!match;
    std::printf("gate=%g value=1e38 output=%+.9g oracle=%+.9g steps=%zu %s\n",x,actual,expected,compiled.report.step_count(),match?"MATCH":"MISMATCH");
    for(std::size_t i=0;i<compiled.report.step_count();++i){const auto s=take(compiled.report.step(i));std::printf("  step=%zu provider=%.*s nodes=%zu\n",i,int(s.provider.name.size()),s.provider.name.data(),s.node_count);}
  }
  std::printf("fused-tail actual mismatches=%d; diagnostic only, no timing\n",failures);
}
