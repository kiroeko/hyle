from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys

repo=Path.cwd();route=sys.argv[1];attempt=sys.argv[2] if len(sys.argv)>2 else '1'
out=repo/'.scratch/foundation-f3'/('native-windows-'+route+'-'+attempt)
assert not out.exists();out.mkdir()
build=Path('C:/h7/w-cuda/selected-graph/shared-sdk-build' if route=='cuda' else 'C:/h7/w-vulkan-native')
spec=importlib.util.spec_from_file_location('hyle_header_env',repo/'scripts/header-self-contained.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
compiler='C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'
env=module.visual_studio_environment('','x64','',compiler);env['VSLANG']='1033'
env['VULKAN_SDK']='C:/public/tools/hyle-vulkan/1.4.357.0'
env['PATH']=env['VULKAN_SDK']+'/Bin;C:/public/tools/glslang/bin;'+env['PATH']
cmake=shutil.which('cmake',path=env['PATH'])
target='hyle_compute_route_'+route+'_file_stream_test'
record={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'route':route,
        'scope':'F3 original native GPU actual file roundtrip/replays/late EOF only; math/native faults/SDK unproven',
        'build':str(build),'compiler':compiler,'parallel':1,'stages':[],'inputs':[]}
for command in [['git','diff','--name-only','HEAD'],['git','ls-files','--others','--exclude-standard']]:
    for path in subprocess.check_output(command,text=True).splitlines():
        file=repo/path
        if file.is_file():record['inputs'].append({'path':path,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
class MemoryStatus(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(str(i),ctypes.c_ulonglong) for i in range(7)]
commands=[('identity',['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],30)]
if route=='cuda' and not attempt.startswith('resume-'):commands.append(('configure',[cmake,'-S',str(repo),'-B',str(build),'-DHYLE_BUILD_TESTS=ON',
    '-DHYLE_INSTALL=OFF','-DHYLE_COMPONENTS=compute','-DHYLE_COMPUTE_ROUTES=cuda'],300))
commands.extend([
    ('build',[cmake,'--build',str(build),'--target',target,'--parallel','1'],1800),
    ('files',[str(build/'bin'/(target+'.exe')),
              '--gtest_filter='+(route.capitalize()+'FileStream.Abandoned*' if attempt=='resume-abandon-stage' else route.capitalize()+'FileStream.*'),
              '--gtest_output=xml:'+str(out/'files.xml')],120)
])
for name,command,timeout in commands:
    memory=MemoryStatus();memory.length=ctypes.sizeof(memory);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory))
    available=getattr(memory,'1');assert available>=4*1024**3
    if '--parallel' in command:
        command[command.index('--parallel')+1]=str(4 if available>=12*1024**3 else 2 if available>=8*1024**3 else 1)
    log=out/(name+'.log');runtime=env.copy()
    if name=='files':runtime['PATH']=str(build/'bin')+';C:/Windows/System32;C:/Windows'
    with log.open('w') as output:
        process=subprocess.Popen(command,cwd=repo,env=runtime,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        row={'name':name,'command':command,'pid':process.pid,'state':'running','available_bytes':available,'log':log.name}
        record['stages'].append(row);(out/'job.json').write_text(json.dumps(record,indent=2))
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            process.wait();row.update(state='terminal',verdict='TIMEOUT');(out/'job.json').write_text(json.dumps(record,indent=2));raise
        row.update(state='terminal',exit_code=code,verdict='PASS' if code==0 else 'FAIL',sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (out/'job.json').write_text(json.dumps(record,indent=2))
    print(name,code,flush=True)
    if code:raise SystemExit(code)
record['verdict']='PASS_NATIVE_FILE_JOURNEY_ONLY';(out/'job.json').write_text(json.dumps(record,indent=2))
