from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import sys

candidate = sys.argv[1]
assert len(candidate) == 40
base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
assert candidate in (source / 'SOURCE-MANIFEST.txt').read_text()
parent = base / 'a-cpu-apple/selected-graph/source-parent'
build = parent.parent / 'source-build'
root = base / ('foundation-f3-cpu-risks-' + candidate[:9])
assert not root.exists(); root.mkdir()
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
identity = {name: subprocess.check_output(command, env=env, text=True).strip() for name, command in [
    ('hardware', ['sysctl', '-n', 'hw.model']), ('os', ['sw_vers']), ('compiler', ['/usr/bin/clang++', '--version'])]}
assert identity['hardware'] == 'Mac16,12'
cache = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1')
gtest = list((cache / 'sources').glob('googletest-*/CMakeLists.txt'))
assert len(gtest) == 1
file = parent / 'CMakeLists.txt'; original = file.read_text()
target = 'hyle_f3_cpu_file_risks'
if target not in original:
    file.write_text(original + '\nset(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\n'
        + 'add_subdirectory("' + str(gtest[0].parent) + '" f3-gtest EXCLUDE_FROM_ALL)\n'
        + 'add_executable(' + target + ' "' + str(source / 'tests/compute_stream/file_stream_test.cc') + '")\n'
        + 'target_compile_features(' + target + ' PRIVATE cxx_std_23)\n'
        + 'target_link_libraries(' + target + ' PRIVATE hyle::graph GTest::gtest_main)\n'
        + 'hyle_stage_runtime(' + target + ')\n')
record = {'candidate': candidate, 'identity': identity, 'source': str(source), 'build': str(build),
          'scope': 'Actual Air CPU twelve public-API file risks only, reusing ordinary shipping source dependencies; no global correctness catalogue.',
          'stages': [], 'test_parallel': 1}
for name, command, timeout in [
    ('configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build)], 300),
    ('build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', target, '--parallel', '1'], 1800),
    ('files', [str(build / target), '--gtest_filter=FileStream.*', '--gtest_output=xml:' + str(root / 'files.xml')], 120)]:
    page = int(subprocess.check_output(['sysctl', '-n', 'hw.pagesize'], text=True, env=env))
    vm = subprocess.check_output(['vm_stat'], text=True, env=env)
    free = page * sum(int(re.search(r'Pages ' + key + r':\s*(\d+)', vm).group(1)) for key in ['free', 'inactive', 'speculative'])
    assert free >= 4 * 1024**3
    if '--parallel' in command:
        record['parallel'] = 4 if free >= 12 * 1024**3 else 2 if free >= 8 * 1024**3 else 1
        command[command.index('--parallel') + 1] = str(record['parallel'])
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'log': log.name, 'available_bytes': free}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait()
            row.update(state='terminal', verdict='TIMEOUT'); (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
record['verdict'] = 'PASS_AIR_CPU_F3_TWELVE_RISKS_ONLY'
(root / 'job.json').write_text(json.dumps(record, indent=2))
