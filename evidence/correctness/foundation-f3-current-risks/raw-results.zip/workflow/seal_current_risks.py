from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'
rows = []
subjects = [(scratch / 'air-cpu-risks-logs', 13, 'Air CPU'),
            (scratch / 'current-apple-logs', 6, 'Air Apple'),
            (scratch / 'current-vulkan-air-logs', 5, 'Air Vulkan'),
            (scratch / 'native-windows-vulkan-warning-regression', 5, 'Windows Vulkan')]
subjects += [(scratch / 'wsl-current-logs' / ('foundation-f3-current-' + mode + '-838c78bfd'),
              6 if mode == 'cuda' else 13, 'WSL ' + mode) for mode in ['cuda', 'asan', 'ubsan', 'tsan']]
for folder, count, label in subjects:
    job = json.loads((folder / 'job.json').read_text())
    assert all(row['state'] == 'terminal' and row['exit_code'] == 0 for row in job['stages'])
    for stage in job['stages']:
        assert hashlib.sha256((folder / stage['log']).read_bytes()).hexdigest() == stage['sha256']
    tests = ET.parse(folder / 'files.xml').getroot()
    assert tests.attrib['tests'] == str(count) and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
    log = (folder / 'files.log').read_text(encoding='utf-8')
    assert 'WARNING: ThreadSanitizer:' not in log and 'ERROR: AddressSanitizer:' not in log and 'runtime error:' not in log
    rows.append({'label': label, 'tests_passed': count, 'candidate_or_fixture': job.get('candidate', job.get('baseline')),
                 'identity': job.get('identity', job.get('compiler')), 'parallel': job.get('parallel')})
out = repo / 'evidence/correctness/foundation-f3-current-risks'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for folder, count, label in subjects:
        for path in sorted(folder.iterdir()):
            if path.is_file(): packed.writestr(label.replace(' ', '-') + '/' + path.name, path.read_bytes())
    for name in ['warning-equivalence.json', 'candidate-binding.json', 'loc-candidate.json', 'air-source-332026e43.json', 'wsl-source-838c78bfd.json']:
        packed.writestr(name, (scratch / name).read_bytes())
    for name in ['run_cpu_risks_air.py', 'run_native_air.py', 'run_native_windows.py', 'run_wsl_current_delta.py', 'seal_current_risks.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1, 'product_candidate': '3b7b9b9b8f0e99205de0c43ce29b4467bdae46d5',
    'product_tree': '7ffc5f2cedc973dae3093fed36dde2d30ba8ca46',
    'scope': 'Current F3 normal selected platform/native and thirteen common sanitizer risks only, ordinary math previous matched receipts retained.',
    'runs': rows,
    'new_risk': 'Expired monotonic deadline before first chunk preserves DeadlineExceeded/zero IO/zero native/zero ready. Repeated stop/close/drain rejects new work without consuming writers or closing borrowed user resources.',
    'original_failures': 'All earlier F3 failures/timeouts remain in previously sealed evidence; current sanitizer trees/flags retain original accepted diagnostic policy and TSan process-local setarch recovery.',
    'locator': 'LOC computed from product candidate via canonical loc-report registry AUDITED union with self-check PASS; no hand-added historical counts.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_CURRENT_F3_SELECTED_PLATFORM_AND_COMMON_SANITIZER_RISKS_ONLY',
    'unproven': ['Installed static/shared/new heads/absence/relocation', 'Final red team/all gates/closure']}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('Current eight targeted runs and immutable LOC/source binding verified; no installed/final verdict.')
