from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,zipfile
archive,mode,attempt=sys.argv[1:4]
assert mode in ('asan','ubsan','tsan')
ROOT=Path('/mnt/c/public/project-hyle/hyle');BASE=ROOT/'.scratch/inference-gaps/g04-g05'
FINAL=ROOT/'.scratch/inference-gaps/g06'
SOURCE=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
OLD=SOURCE.parent/f'foundation-f5-native-host-cuda-{mode}';BUILD=OLD/'build'
RUN=FINAL/f'final-host-{mode}-{attempt}';RUN.mkdir(parents=True,exist_ok=False)
assert SOURCE.is_dir() and not (SOURCE/'.git').exists() and (BUILD/'CMakeCache.txt').exists()
proof=json.loads((BASE/'cuda-host-san/ggml-cuda-reuse-proof.json').read_text())
reuse_identity_path=BASE/'cuda-host-san/ce19-native-archive-identity-3.json'
reuse_identity=json.loads(reuse_identity_path.read_text())
assert reuse_identity['state']=='PASS_NATIVE_ARCHIVE_REUSE_IDENTITY_ONLY'
assert hashlib.sha256((BASE/'cuda-host-san/ggml-cuda-reuse-proof.json').read_bytes()).hexdigest()==reuse_identity['original_proof_sha256']
(RUN/'ce19-native-archive-identity.json').write_bytes(reuse_identity_path.read_bytes())
reuse=proof['modes'][mode]
assert reuse['verdict']=='REUSABLE_UNCHANGED_NATIVE_ARCHIVE'
original_archive=Path(reuse['archive'])
assert hashlib.sha256(original_archive.read_bytes()).hexdigest()==reuse['archive_sha256']
reused=SOURCE.parent/'g04-encoded-host-reused'/mode/'libggml-cuda.a'
reused.parent.mkdir(parents=True,exist_ok=True)
if not reused.exists():shutil.copyfile(original_archive,reused)
assert hashlib.sha256(reused.read_bytes()).hexdigest()==reuse['archive_sha256']
(RUN/'ggml-cuda-reuse-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
with zipfile.ZipFile(archive) as package:
 snapshot=json.loads(package.read('snapshot.json'))
 inputs=json.loads(package.read('source-manifest.json'))
 for item in inputs:
  name=Path(item['path']);assert not name.is_absolute() and '..' not in name.parts
  raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
  file=SOURCE/name
  if not file.exists() or file.read_bytes()!=raw:
   file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
hook=RUN/'targets.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
 add_subdirectory("/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6" g04-cuda-host-gtest EXCLUDE_FROM_ALL)
 function(g04_cuda_host_san)
  set_property(GLOBAL APPEND PROPERTY JOB_POOLS g04_cuda_san_compile=1)
  set_target_properties(hyle_compute_provider_flashinfer PROPERTIES JOB_POOL_COMPILE g04_cuda_san_compile CUDA_ARCHITECTURES 89-real)
  target_compile_options(hyle_compute_provider_flashinfer PRIVATE "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
  add_library(g04_reused_ggml_cuda STATIC IMPORTED GLOBAL)
  set_property(TARGET g04_reused_ggml_cuda PROPERTY IMPORTED_LOCATION "@REUSED_CUDA@")
  foreach(property IN ITEMS INTERFACE_LINK_LIBRARIES INTERFACE_INCLUDE_DIRECTORIES INTERFACE_COMPILE_DEFINITIONS)
   get_target_property(original ggml-cuda ${property})
   if(NOT original MATCHES "-NOTFOUND$")
    set_property(TARGET g04_reused_ggml_cuda PROPERTY ${property} "${original}")
   endif()
  endforeach()
  foreach(property IN ITEMS LINK_LIBRARIES INTERFACE_LINK_LIBRARIES)
   get_target_property(original ggml ${property})
   if(NOT original MATCHES "-NOTFOUND$")
    string(REPLACE "ggml-cuda" "g04_reused_ggml_cuda" updated "${original}")
    set_property(TARGET ggml PROPERTY ${property} "${updated}")
    file(APPEND "@RUN@/reused-link-seam.txt" "ggml ${property}: ${original} -> ${updated}\n")
   endif()
  endforeach()
  add_executable(g04_cuda_encoded_host_tests "@SOURCE@/tests/compute_provider_flashinfer/native_cache_test.cc" "@SOURCE@/tests/compute_batch/encoded_page_common_consumer.cc")
  target_compile_definitions(g04_cuda_encoded_host_tests PRIVATE HYLE_ENCODED_CUDA=1)
  target_link_libraries(g04_cuda_encoded_host_tests PRIVATE GTest::gtest_main)
  add_executable(g04_cuda_encoded_host_risks "@SOURCE@/tests/compute_batch/pending_paged_receiver_cuda_risks.cc")
  target_compile_definitions(g04_cuda_encoded_host_risks PRIVATE HYLE_ENCODED_PAGE_RISK=1)
  foreach(target IN ITEMS g04_cuda_encoded_host_tests g04_cuda_encoded_host_risks)
   target_compile_features(${target} PRIVATE cxx_std_23)
   target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic)
   target_link_libraries(${target} PRIVATE hyle_compute_state hyle_graph_batch hyle_compute_provider_flashinfer hyle_compute_backend_cuda hyle_graph_route_cpu hyle_graph_route_cpu_cuda)
   hyle_apply_sanitizer(${target})
   hyle_stage_runtime(${target})
  endforeach()
  add_executable(g06_core_host_tests
    "@SOURCE@/tests/compute_batch/batch_layout_test.cc"
    "@SOURCE@/tests/compute_batch/batch_materialize_test.cc"
    "@SOURCE@/tests/compute_batch/native_paged_metadata_test.cc"
    "@SOURCE@/tests/compute_batch/paged_arena_test.cc"
    "@SOURCE@/tests/graph_batch/materialized_graph_test.cc"
    "@SOURCE@/tests/graph_batch/native_paged_node_test.cc"
    "@SOURCE@/tests/compute_provider_ggml/native_ragged_test.cc"
    "@SOURCE@/tests/compute_provider_ggml/native_paged_test.cc"
    "@SOURCE@/tests/graph/region_provider_test.cc"
    "@SOURCE@/tests/graph/lease_submission_test.cc")
  target_link_libraries(g06_core_host_tests PRIVATE GTest::gtest_main ggml hyle_compute_provider_native)
  target_include_directories(g06_core_host_tests PRIVATE "@SOURCE@/src/compute")
  foreach(name IN ITEMS public hybrid pending)
    if(name STREQUAL "public")
      set(file public_batch_cuda_consumer.cc)
    elseif(name STREQUAL "hybrid")
      set(file public_hybrid_batch_consumer.cc)
    else()
      set(file pending_paged_receiver_cuda_consumer.cc)
    endif()
    add_executable(g06_capture_${name} "@SOURCE@/tests/compute_batch/${file}")
    target_compile_definitions(g06_capture_${name} PRIVATE HYLE_G06_CAPTURE_REPLAY=1)
  endforeach()
  foreach(storage IN ITEMS plain encoded)
    add_executable(g06_risk_${storage} "@SOURCE@/tests/compute_batch/pending_paged_receiver_cuda_risks.cc")
    target_compile_definitions(g06_risk_${storage} PRIVATE HYLE_G06_CAPTURE_REPLAY=1)
  endforeach()
  target_compile_definitions(g06_risk_encoded PRIVATE HYLE_ENCODED_PAGE_RISK=1)
  foreach(target IN ITEMS g06_core_host_tests g06_capture_public g06_capture_hybrid g06_capture_pending g06_risk_plain g06_risk_encoded)
    target_compile_features(${target} PRIVATE cxx_std_23)
    target_link_libraries(${target} PRIVATE hyle_graph_batch hyle_graph_route_cpu_cuda hyle_compute_state CUDA::cudart)
    hyle_apply_sanitizer(${target})
    hyle_stage_runtime(${target})
  endforeach()
  set_source_files_properties("@SOURCE@/src/compute_backend_cuda/cuda_backend.cc" DIRECTORY "@SOURCE@/src/compute_backend_cuda" PROPERTIES COMPILE_DEFINITIONS HYLE_TESTING=1)
 endfunction()
 cmake_language(DEFER CALL g04_cuda_host_san)
endif()
'''.replace('@SOURCE@',str(SOURCE)).replace('@REUSED_CUDA@',str(reused)).replace('@RUN@',str(RUN))
hook.write_text(body)
cache=(BUILD/'CMakeCache.txt').read_text();assert f'HYLE_SANITIZER:STRING={mode}' in cache
configure_source=OLD/'parent' if mode=='asan' else SOURCE
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
env.update(ASAN_OPTIONS='halt_on_error=1:protect_shadow_gap=0:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0')
identity={key:subprocess.check_output(args,text=True).strip() for key,args in [('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),('gpu',['nvidia-smi','--query-gpu=name,uuid,driver_version,memory.total','--format=csv,noheader'])]}
old_record=json.loads((OLD/'job.json').read_text())
record={'product_candidate':'669121418669b31f6849c74f64362aaf8d6eb919','state':'RUNNING','mode':mode,'attempt':attempt,'inputs':inputs,'source_snapshot':snapshot,'identity':identity,'build':str(BUILD),'max_jobs':4,'flashinfer_compile_pool':1,'stages':[],'cumulative_seconds':0,'environment':{k:env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','TSAN_OPTIONS')},'previous_f5_sanitizer_scope':{k:v for k,v in old_record.items() if k in ('asan_configuration','lsan_verdict','tsan_scope','verdict')},'limits':['Host instrumentation only; no shader/driver/private-pool byte certificate','ASan address facet only; original NVIDIA process LSan remains INCONCLUSIVE','TSan data races only; original independently reproduced NVIDIA diagnostic-thread lifetime remains INCONCLUSIVE','Source risk observation hook in one backend host TU; not shipping SDK qualification']}
record['reused_ggml_cuda']={'archive':str(reused),'sha256':reuse['archive_sha256'],'scope':'Only unchanged original ggml CUDA native archive, same per-mode sanitizer/toolchain/SM89; CPU/base/FI/all changed host code still compiled.'}
(RUN/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def failed_setup(kind,error,traceback):
 record['state']='TERMINAL_FAIL';record['setup_error']=repr(error)
 record['setup_error_elapsed_seconds']=None
 save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','setup_error':repr(error)}))
 sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed_setup
def run(stage,args):
 log=RUN/f'{stage}.log';start=time.monotonic()
 with log.open('w') as stream:
  process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','pid':process.pid,'stage':stage,'log':str(log)}));print(mode,stage,process.pid,flush=True);
  try:code=process.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   record.setdefault('extensions',[]).append(dict(stage=stage,original_timeout_seconds=1800,extension_seconds=1800));save()
   try:code=process.wait(timeout=1800)
   except subprocess.TimeoutExpired:process.terminate();code=process.wait();record['finite_extension_exhausted']=stage
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed;record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 record['state']='TERMINAL_FAIL' if code else 'RUNNING';save();print(mode,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
 if code:
  (RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));print(log.read_text(errors='replace')[-5500:],flush=True);raise SystemExit(code)
args=['cmake','-S',str(configure_source),'-B',str(BUILD),'-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES','-DCMAKE_PROJECT_INCLUDE='+str(hook),'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF']
run('configure',args)
commands=json.loads(subprocess.check_output(['ninja','-C',str(BUILD),'-t','compdb'],env=env,text=True))
unary=next(row for row in commands if row['file'].endswith('/src/ggml-cuda/unary.cu'))
derived_root=Path(unary['file'].split('/src/ggml-cuda/')[0])
for name,digest in reuse['derived_dependencies']:assert hashlib.sha256((derived_root/name).read_bytes()).hexdigest()==digest,name
for name,digest in reuse['canonical_dependencies']:assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
record['reused_native_current_inputs']={'derived_root':str(derived_root),'derived_verified':len(reuse['derived_dependencies']),'canonical_verified':len(reuse['canonical_dependencies']),'archive_sha256':reuse['archive_sha256']}
save()

flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
required=['src/compute/command_capture.cc','src/compute/device.cc','cuda_backend.cc','cuda_device_status.cc','flashinfer_provider.cc','native_attention.cu','native_batch.cu','native_cache.cu','native_cache_encoder.cu','batch_execution.cc','batch_layout.cc','paged_arena.cc','encoded_page_common_consumer.cc','native_cache_test.cc','pending_paged_receiver_cuda_risks.cc']
required+=['src/graph_batch/batch.cc','src/graph_batch/native_paged_node.cc',
 'src/graph/leased_invocation.cc','src/graph/executable.cc','src/graph/lease_submission.cc',
 'src/graph_route_cpu_cuda/compile.cc','src/graph_route_cpu_cuda/progress.cc',
 'src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml/native_batch.cc']
checked=[]
for name in required:
 rows=[r for r in commands if r['file'].endswith('/'+name)]
 assert rows and all(flag in r['command'] for r in rows),(name,'not instrumented')
 checked.extend(rows)
(RUN/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\n')
run('prepare-manifest',['ninja','-C',str(BUILD),'build.ninja'])
preview=RUN/'preview.ninja';preview.write_bytes((BUILD/'build.ninja').read_bytes())
dry=subprocess.check_output(['ninja','-C',str(BUILD),'-f',str(preview),'-n','g04_cuda_encoded_host_tests','g04_cuda_encoded_host_risks'],env=env,text=True);(RUN/'dry-run.txt').write_text(dry)
assert 'Re-running CMake' not in dry

assert '/ggml-cuda/' not in dry,'unexpected unrelated full ggml CUDA rebuild'
extra=['g06_core_host_tests','g06_capture_public','g06_capture_hybrid','g06_capture_pending','g06_risk_plain','g06_risk_encoded']
dry_extra=subprocess.check_output(['ninja','-C',str(BUILD),'-f',str(preview),'-n',*extra],env=env,text=True);(RUN/'extra-dry-run.txt').write_text(dry_extra)
assert 'Re-running CMake' not in dry_extra and '/ggml-cuda/' not in dry_extra
if mode in ('asan','ubsan'):
 assert 'Building CUDA object' not in dry and 'Building CUDA object' not in dry_extra,'Graph-only fix must not rebuild CUDA'
run('compile',['cmake','--build',str(BUILD),'--target','g04_cuda_encoded_host_tests','g04_cuda_encoded_host_risks',*extra,'--parallel','2'])
prefix=['setarch','x86_64','-R'] if mode=='tsan' else []
def executable(name):
 paths=[p/name for p in (BUILD/'bin',BUILD/'hyle',BUILD) if (p/name).is_file()]
 assert len(paths)==1,(name,paths)
 return paths[0]
record['binaries']={name:{'path':str(executable(name)),
 'sha256':hashlib.sha256(executable(name).read_bytes()).hexdigest()}
 for name in ['g04_cuda_encoded_host_tests','g04_cuda_encoded_host_risks',*extra]}
save()
run('tests',prefix+[str(executable('g04_cuda_encoded_host_tests')),'--gtest_output=xml:'+str(RUN/'tests.xml')])
run('five-risk-modes',prefix+[str(executable('g04_cuda_encoded_host_risks'))])
for name in extra:
 command=prefix+[str(executable(name))]
 if name=='g06_core_host_tests':command+=['--gtest_output=xml:'+str(RUN/'core.xml')]
 run(name,command)
assert all(hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
 for item in record['binaries'].values()),'test binary changed during verification'
assert hashlib.sha256(reused.read_bytes()).hexdigest()==reuse['archive_sha256']
record['state']='TERMINAL_PASS';save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}));print(mode,'CUDA ENCODED HOST FACETS PASS',flush=True)
