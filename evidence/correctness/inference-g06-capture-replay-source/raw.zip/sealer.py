from pathlib import Path
import datetime,hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';out=root/'evidence/correctness/inference-g06-capture-replay-source'
assert not out.exists()
final=base/'capture-source-2';r=json.loads((final/'result.json').read_text());candidate=r['candidate']
assert r['state']=='TERMINAL_ORDINARY_SOURCE_PASS_FINAL_RISKS_PENDING' and not r['native_cuda_edges']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
artifacts=json.loads((final/'artifacts.json').read_text());assert artifacts
# Recheck actual WSL artifacts independently, after all tests, before sealing.
check="from pathlib import Path;import hashlib,json;rows=json.loads(Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/capture-source-2/artifacts.json').read_text());assert all(hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()==i['sha256'] for i in rows);print(len(rows),sum(i['bytes'] for i in rows))"
verified=subprocess.check_output(['wsl','-e','python3','-c',check],text=True).strip()
tests={}
for name in ['cold-capture','provider']:
 t=ET.parse(final/(name+'.xml')).getroot();assert all(t.attrib.get(k,'0')=='0' for k in ['failures','errors','disabled']);tests[name]=dict(t.attrib)
for name in ['hyle_compute_test','hyle_compute_batch_test','hyle_graph_executable_test','hyle_graph_batch_test','hyle_compute_provider_ggml_test']:
 data=(final/(name+'.log')).read_text();passed=re.search(r'\[  PASSED  \] (\d+) tests\.',data);assert passed and '[  FAILED  ]' not in data
 tests[name]={'passed':int(passed[1])}
assert tests['provider']['tests']=='20'
proof=r['native_reuse'];assert proof['native_object_count']==146
out.mkdir(parents=True)
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for attempt in [1,2]:
  folder=base/('capture-source-'+str(attempt))
  for p in sorted(folder.iterdir()):
   if p.is_file():z.write(p,'attempt-'+str(attempt)+'/'+p.name)
  archive=base/('capture-input-'+str(attempt)+'.zip')
  z.writestr('attempt-'+str(attempt)+'/canonical-archive-identity.json',json.dumps({'path':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}))
 z.write(base/'launch_capture.py','launch_capture.py')
 z.write(Path(__file__),'sealer.py')
receipt={'state':'PASS_ORDINARY_SOURCE_ONLY_FINAL_RISKS_PENDING','candidate':candidate,
 'scope':'G06 D7.1-D7.6 actual native cold record/replay and original per-run admission, not full G06 closure',
 'record':'docs/implementation/tasks/compute/inference-g06-metadata-decode.md',
 'audit':'15efb36cabe1e5ccf899c56e32c98f80139a6003','first_implementation':'3fa912569096dc716de8cafad307c8841a2e567e',
 'identity':r['identity'],'tests':tests,
 'public_consumers':[s['stage'] for s in r['stages'] if s['stage'].startswith('hyle_g06_capture_')],
 'qualification':['Separate fresh process enters native attention capture before any ordinary attention warmup;32 finite configurations each64 updates, paged/ragged,plain/FP8,F16/BF16,Q1 single/multi,mixed17+1,head64/128/256/independent Dv/window/noncausal.',
 'Original provider19 plus actual capture grid PASS20. Cold metadata OOM leaves original token usable; exact storage change rejects stale run before acceptance, explicit recapture works; true native replan invalidates and equivalent schedule retains capture with next allocation forbidden.',
 'Actual public Direct/Graph and CPU+CUDA each ordinary/captured variants, independent numeric oracle, Graph reset/bind/layout reuse and old-output gate pass.',
 'Original controller transfers actual capture to pending receiver. Idle captured page readers fully dropped, same arena page writers reacquired, gated producer/F2 original ordered permissions and retirement preserve .25 oracle/old output/writer recovery.',
 'Original compute108,batch60,Graph289 incl new bound-port/borrowed-context and existing native capture/failure gates,graph_batch6,CPU ragged5 pass. CPU unsupported capture explicitly rejected.'],
 'capture_cost':'Explicit cold record completion checked wait reported; exact retained replay adds no preparation wait or control allocation in tested domain. Native driver/private costs UNKNOWN, not zero.',
 'native_math_unchanged':True,'cuda_compile_edges':r['native_cuda_edges'],'native_object_reuse':proof,
 'artifact_recheck':{'actual_wsl_count_and_bytes':verified,'artifacts':artifacts},
 'attempts':[],'remaining':['Original CUDA backend observation/static FI fault injection with instrumentation','Vulkan Recorder runtime risk','Full G06 applicable ASan/UBSan/TSan, independent headers and relocated static/shared SDK','Final immutable-candidate performance and red-team/LOC','Original G04/G05 CUDA prefill noninfer UNRESOLVED, exact causal attribution UNKNOWN; no new P1/profile search here'],
 'complete_items':'G01/G02/G03 only3/10; G06 roughly75% implementation-work estimate, not acceptance or remaining-time estimate',
 'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
for attempt in [1,2]:
 d=json.loads((base/f'capture-source-{attempt}/result.json').read_text());receipt['attempts'].append({'attempt':attempt,'candidate':d['candidate'],'state':d['state'],'outer_elapsed_seconds':d['outer_elapsed_seconds'],'stages':d['stages']})
receipt['cost_limit']='Outer/stage times overlap. Original attempt1 configure62.309s and CXX buildFAIL103.211s remain FAIL/cost. Attempt2 guarded reuses same successful configure, build6.336s, outer37.298s. Full design/edit/archive/observation time UNKNOWN.'
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':receipt['state'],'candidate':candidate,'actual_artifacts':verified,'receipt':str(out.relative_to(root))},ensure_ascii=False))
