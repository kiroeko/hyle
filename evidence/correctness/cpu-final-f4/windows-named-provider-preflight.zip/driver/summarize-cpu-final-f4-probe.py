import collections,json,re
from pathlib import Path
source=Path('.scratch/validation/cpu-final-f4/probe-windows-four/2-capability-and-numeric-preflight.log')
lines=source.read_text(encoding='utf-8',errors='replace').splitlines()
admissions=collections.Counter();pairs=[];counts={};details=[]
for line in lines:
    if line.startswith('# ADMISSION '):
        fields={k:v for k,v in re.findall(r'(\w+)=([^ ]+)',line)}
        admissions[(fields['provider'],fields['result'])]+=1
        details.append(fields)
    elif line.startswith('PAIR\t'):
        _,case,left,right,result=line.split('\t');pairs.append({'case':case,'left':left,'right':right,'result':result})
    elif line.startswith('CARRIER_COUNT\t'):
        _,case,count=line.split('\t');counts[case]=int(count)
summary={'scope':'actual Windows static SDK named-provider capability/numerical preflight, no P1 or WIN','cases':len(counts),'carrier_count_histogram':dict(collections.Counter(counts.values())),'admission_histogram':{a+':'+b:n for (a,b),n in admissions.items()},'pairs':len(pairs),'pair_family_histogram':dict(collections.Counter(p['left']+'-'+p['right'] for p in pairs)),'numeric_mismatches':[p for p in pairs if p['result']!='NUMERIC_MATCH'],'no_carrier_cases':[c for c,n in counts.items() if n==0],'self_accepted_cases':sum(n for (provider,result),n in admissions.items() if provider=='native' and result=='ACCEPTED')}
folder=source.parent
(folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(folder/'admissions.json').write_text(json.dumps(details,indent=2)+'\n')
(folder/'pairs.json').write_text(json.dumps(pairs,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='numeric_mismatches'},indent=2));print('numeric_mismatches',len(summary['numeric_mismatches']));print(json.dumps(summary['numeric_mismatches'][:12],indent=2))
