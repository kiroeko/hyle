exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
out=repo/'.scratch/validation/cpu-final-f4/probe-windows';out.mkdir(parents=True,exist_ok=True);records=[]
b=Path('C:/hv/cpu-final-f4-probe')
run('configure',['cmake','-S',repo/'bench/compute_provider_native/cpu_best_of_p1','-B',b,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=C:/hv/cpu-final-sdk/static-relocated','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build',['cmake','--build',b,'--target','hyle_cpu_best_of_bench','hyle_perf_control_bench','--parallel','2'])
run('capability-and-numeric-preflight',[b/'hyle_cpu_best_of_bench.exe','--probe'])
