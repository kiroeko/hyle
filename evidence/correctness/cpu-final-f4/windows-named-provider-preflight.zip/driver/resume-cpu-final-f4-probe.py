exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
out=repo/'.scratch/validation/cpu-final-f4/probe-windows-corrected';out.mkdir(parents=True,exist_ok=True);records=[]
b=Path('C:/hv/cpu-final-f4-probe')
run('build',['cmake','--build',b,'--target','hyle_cpu_best_of_bench','--parallel','2'])
run('capability-and-numeric-preflight',[b/'hyle_cpu_best_of_bench.exe','--probe'])
