import hashlib,json,pathlib,shutil,subprocess,tarfile,time,os
root=pathlib.Path('/root/hyle-scratch/active-cpu-z').resolve()
source=(root/'source').resolve()
assert source.parent==root and source.is_dir() and not source.is_symlink()
live=subprocess.check_output(['ps','-eo','pid=,args='],text=True)
assert not any(str(root) in line and any(term in line for term in ('cmake --build','ctest --test-dir','ninja -C')) for line in live.splitlines() if line.strip().split(None,1)[0]!=str(os.getpid()))
archive=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/source.tar')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='f6ace0efcc5433b974baf8d5e3af7065b7e2afd906eca8a897e6e5ee6ac5dd87'
names=set();updated=[];removed=[]
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  if member.isdir():continue
  assert member.isfile()
  path=(source/member.name).resolve();assert path.is_relative_to(source)
  names.add(member.name);data=tar.extractfile(member).read()
  if not path.exists() or path.read_bytes()!=data:path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);updated.append(member.name)
  if member.mode & 0o111:path.chmod(path.stat().st_mode|0o111)
 for folder in ('src','include','tests','cmake','third_party','scripts','samples','bench','docs'):
  for path in (source/folder).rglob('*'):
   if path.is_file() and path.relative_to(source).as_posix() not in names:
    assert path.resolve().is_relative_to(source);path.unlink();removed.append(path.relative_to(source).as_posix())
out=root/'f4-result';out.mkdir(exist_ok=True)
(out/'source-sync.json').write_text(json.dumps({'candidate':'64304e9e691cc78d2ead05a7c88fa485f9b8adc4','archive_sha256':'f6ace0efcc5433b974baf8d5e3af7065b7e2afd906eca8a897e6e5ee6ac5dd87','updated':updated,'removed':removed,'mirror_only':True},indent=2)+'\n')
consumer=root/'f4-consumer';consumer.mkdir(exist_ok=True)
original=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/delivery-consumer')
for name in ('CMakeLists.txt','main.cc'):shutil.copyfile(original/name,consumer/name)
overlay=root/'f4-overlay.cmake'
overlay.write_text('function(cpu_f4_hook)\nadd_executable(cpu_f4_source_delivery "'+str(consumer/'main.cc')+'")\ntarget_compile_features(cpu_f4_source_delivery PRIVATE cxx_std_23)\ntarget_link_libraries(cpu_f4_source_delivery PRIVATE hyle::compute hyle::graph)\nendfunction()\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\ncmake_language(DEFER CALL cpu_f4_hook)\nendif()\n')
records=[];env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
def run(name,args):
 start=time.monotonic();args=list(map(str,args));log=out/(str(len(records)+1)+'-'+name+'.log')
 with log.open('wb') as stream:result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
 records.append({'name':name,'candidate':'64304e9e691cc78d2ead05a7c88fa485f9b8adc4','args':args,'exit':result.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name})
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 if result.returncode:print(log.read_text(errors='replace')[-6000:],flush=True);result.check_returncode()
run('machine',['sh','-c','uname -a; g++-14 --version; cmake --version'])
build=root/'build'
for shape in ('static','shared'):
 prefix=root/('f4-'+shape+'-staging');relocated=root/('f4-'+shape+'-relocated')
 assert not prefix.exists() and not relocated.exists()
 run(shape+'-configure',['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPONENTS=compute,graph','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=AUTO','-DHYLE_COMPUTE_TORCH_CPU=AUTO','-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_PROJECT_INCLUDE='+str(overlay),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(shape+'-build',['cmake','--build',build,'--parallel','2'])
 run(shape+'-source',[build/'bin/cpu_f4_source_delivery'])
 run(shape+'-install',['cmake','--install',build])
 assert prefix.resolve().parent==root and relocated.resolve().parent==root;prefix.rename(relocated)
 b=root/('f4-'+shape+'-consumer')
 run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',b,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(shape+'-consumer-build',['cmake','--build',b,'--parallel','2'])
 run(shape+'-consumer-run',[b/'cpu_final_delivery'])
 run(shape+'-loader',['ldd',b/'cpu_final_delivery'])
 if shape=='shared':run('shared-export',['python3',source/'scripts/check-shared-export-hygiene.py','--root',relocated])
