import json,pathlib,shutil,subprocess,time,os
root=pathlib.Path('/root/hyle-scratch/active-cpu-z').resolve();source=root/'source';out=root/'f4-result'
consumer=root/'f4-consumer';overlay=root/'f4-overlay.cmake'
shutil.copyfile('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/delivery-consumer/main.cc',consumer/'main.cc')
before=subprocess.check_output(['readelf','-d',root/'build/bin/cpu_f4_source_delivery'],text=True)
(out/'initial-loader.txt').write_text(before)
content=overlay.read_text()
assert 'hyle_stage_runtime_dependencies(cpu_f4_source_delivery)' not in content
content=content.replace('endfunction()', 'hyle_stage_runtime_dependencies(cpu_f4_source_delivery)\nendfunction()')
overlay.write_text(content)
records=json.loads((out/'receipt.json').read_text());env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
def run(name,args):
 start=time.monotonic();args=list(map(str,args));log=out/(str(len(records)+1)+'-'+name+'.log')
 with log.open('wb') as stream:result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
 records.append({'name':name,'candidate':'64304e9e691cc78d2ead05a7c88fa485f9b8adc4','args':args,'exit':result.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name})
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 if result.returncode:print(log.read_text(errors='replace')[-6000:],flush=True);result.check_returncode()
build=root/'build'
for shape in ('static','shared'):
 prefix=root/('f4-'+shape+'-staging');relocated=root/('f4-'+shape+'-relocated')
 assert not prefix.exists() and not relocated.exists()
 run(shape+'-configure',['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPONENTS=compute,graph','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=AUTO','-DHYLE_COMPUTE_TORCH_CPU=AUTO','-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_PROJECT_INCLUDE='+str(overlay),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(shape+'-build',['cmake','--build',build,'--parallel','2'])
 run(shape+'-source',[build/'bin/cpu_f4_source_delivery'])
 run(shape+'-install',['cmake','--install',build])
 assert prefix.resolve().parent==root and relocated.resolve().parent==root;prefix.rename(relocated)
 b=root/('f4-'+shape+'-consumer')
 run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',b,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(shape+'-consumer-build',['cmake','--build',b,'--parallel','2'])
 run(shape+'-consumer-run',[b/'cpu_final_delivery'])
 run(shape+'-loader',['ldd',b/'cpu_final_delivery'])
 if shape=='shared':run('shared-export',['python3',source/'scripts/check-shared-export-hygiene.py','--root',relocated])
