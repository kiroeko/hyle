#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <span>
#include <string_view>
#include "hyle/compute/providers/native.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include <vector>
#include "hyle/compute/cpu.h"
#include "hyle/compute/low_precision.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/graph/cpu.h"
#include "hyle/graph/executable.h"
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
template<class T> std::vector<std::byte> bytes(const std::vector<T>& data) {
  const auto view=std::as_bytes(std::span(data));return {view.begin(),view.end()};
}
c::TensorDesc dense(c::DataType type,std::initializer_list<std::int64_t> shape) {
  return c::TensorDesc::dense(type,{shape.begin(),shape.size()}).value();
}
void require(bool ok) {if(!ok)throw std::runtime_error("CPU delivery consumer failed");}
std::vector<std::byte> execute(bool graph,c::Operation op,const std::vector<c::TensorDesc>& descs,
    const std::vector<std::vector<std::byte>>& data) {
  std::vector<m::Buffer> owners;std::vector<c::ConstTensorView> inputs;
  for(std::size_t i=0;i<descs.size();++i) {
    owners.push_back(m::Buffer::create(m::system_resource(),data[i].size(),64).value());
    require(owners.back().view().write(data[i]).ok());
    inputs.push_back(c::ConstTensorView::create(descs[i],owners.back().view()).value());
  }
  std::array<c::TensorDesc,1> inferred;require(c::infer_output_descriptions(op,descs,inferred).ok());
  auto owner=m::Buffer::create(m::system_resource(),inferred[0].required_bytes().value(),64).value();
  const auto output=c::TensorView::create(inferred[0],owner.view()).value();
  if(graph) {
    auto context=g::cpu::create_context().value();auto builder=g::GraphBuilder::create().value();
    std::vector<g::ValueId> values;for(const auto& desc:descs)values.push_back(builder.input(desc).value());
    auto node=builder.add_node(op,values).value();auto result=builder.result(node).value();
    require(builder.publish(result).ok());auto compiled=g::compile(std::move(builder).finish().value(),context).value();
    auto invocation=compiled.executable.create_invocation().value();
    for(std::size_t i=0;i<inputs.size();++i)require(invocation.bind(values[i],inputs[i]).ok());
    require(invocation.bind(result,output).ok());auto queue=context.create_queue().value();
    const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&queue}};
    require(invocation.prepare_replay(queues).ok());
    for(int i=0;i<2;++i)require(invocation.submit(queue).value().wait().ok());
  }else{
    auto context=c::cpu::create_context().value();auto prepared_result=c::prepare(context,op,inputs,std::span(&output,1)); if(!prepared_result) { std::cerr<<"EXEC_PREPARE "<<prepared_result.error().message()<<std::endl; throw std::runtime_error("execute prepare failed"); } auto prepared=std::move(*prepared_result);
    auto invocation_result=prepared.create_invocation(); if(!invocation_result) { std::cerr<<"EXEC_INVOCATION "<<invocation_result.error().message()<<std::endl; throw std::runtime_error("execute invocation failed"); } auto invocation=std::move(*invocation_result);auto queue=context.create_queue().value();
    for(int i=0;i<2;++i) { auto completion=invocation.submit(queue,inputs,std::span(&output,1)); if(!completion) { std::cerr<<"EXEC_SUBMIT "<<completion.error().message()<<std::endl; throw std::runtime_error("execute submit failed"); } auto status=completion->wait(); if(!status.ok()) std::cerr<<"EXEC_WAIT "<<status.message()<<std::endl; require(status.ok()); }
  }
  std::vector<std::byte> result(inferred[0].required_bytes().value());require(owner.view().read(result).ok());return result;
}
void floats(const std::vector<std::byte>& output,float expected) {
  for(std::size_t i=0;i<output.size();i+=4){float value;std::memcpy(&value,output.data()+i,4);if(std::abs(value-expected)>=0.0001f)std::cerr<<"float actual="<<value<<" expected="<<expected<<'\n';require(std::abs(value-expected)<0.0001f);}
}
void put_half(std::vector<std::byte>& data,std::size_t offset,std::uint16_t word) {std::memcpy(data.data()+offset,&word,2);}
void check_current_rules(bool qualified) {
  using namespace c;
  struct Case { const char *id; std::string_view family; int variant, type, rows, width, other; c::ProviderId winner; };
  // Fixed independent expectation from the completed all-candidate evidence.
  const Case cases[]{
      {"binary-0-t6-r32-h2048-o6", "binary", 0, 6, 32, 2048, 6, c::native::kProviderId},
      {"binary-1-t4-r32-h2048-o6", "binary", 1, 4, 32, 2048, 6, c::native::kProviderId},
      {"binary-1-t6-r1-h2048-o6", "binary", 1, 6, 1, 2048, 6, c::native::kProviderId},
      {"binary-3-t4-r1-h2048-o6", "binary", 3, 4, 1, 2048, 6, c::native::kProviderId},
      {"binary-3-t4-r1-h4096-o6", "binary", 3, 4, 1, 4096, 6, c::native::kProviderId},
      {"binary-3-t4-r32-h2048-o6", "binary", 3, 4, 32, 2048, 6, c::native::kProviderId},
      {"binary-3-t6-r1-h4096-o6", "binary", 3, 6, 1, 4096, 6, c::native::kProviderId},
      {"binary-4-t4-r1-h2048-o6", "binary", 4, 4, 1, 2048, 6, c::native::kProviderId},
      {"cast-t2-r1-h4096-o4", "cast", 0, 2, 1, 4096, 4, c::native::kProviderId},
      {"cast-t3-r1-h2048-o5", "cast", 0, 3, 1, 2048, 5, c::native::kProviderId},
      {"cast-t3-r1-h4096-o3", "cast", 0, 3, 1, 4096, 3, c::native::kProviderId},
      {"cast-t3-r32-h2048-o2", "cast", 0, 3, 32, 2048, 2, c::native::kProviderId},
      {"fill-t6-r1-h2048-o6", "fill", 0, 6, 1, 2048, 6, c::native::kProviderId},
      {"gather-t4-r1-h4096-o12", "gather", 0, 4, 1, 4096, 12, c::native::kProviderId},
      {"gather-t4-r1-h4096-o14", "gather", 0, 4, 1, 4096, 14, c::native::kProviderId},
      {"gather-t5-r1-h4096-o14", "gather", 0, 5, 1, 4096, 14, c::native::kProviderId},
      {"gather-t6-r1-h2048-o12", "gather", 0, 6, 1, 2048, 12, c::native::kProviderId},
      {"norm-0-t5-r1-h4096-o6", "norm", 0, 5, 1, 4096, 6, c::native::kProviderId},
      {"reduce-2-t4-r32-h2048-o6", "reduce", 2, 4, 32, 2048, 6, c::native::kProviderId},
      {"reduce-3-t4-r1-h2048-o6", "reduce", 3, 4, 1, 2048, 6, c::native::kProviderId},
      {"reduce-3-t5-r1-h4096-o6", "reduce", 3, 5, 1, 4096, 6, c::native::kProviderId},
      {"silu-gate-0-t4-r32-h2048-o6", "silu-gate", 0, 4, 32, 2048, 6, c::native::kProviderId},
      {"softmax-2-t4-r1-h2048-o6", "softmax", 2, 4, 1, 2048, 6, c::native::kProviderId},
      {"softmax-2-t4-r32-h2048-o6", "softmax", 2, 4, 32, 2048, 6, c::aten_cpu::kProviderId},
      {"unary-1-t5-r1-h2048-o6", "unary", 1, 5, 1, 2048, 6, c::native::kProviderId},
      {"unary-1-t5-r32-h2048-o6", "unary", 1, 5, 32, 2048, 6, c::native::kProviderId},
      {"unary-11-t4-r32-h2048-o6", "unary", 11, 4, 32, 2048, 6, c::native::kProviderId},
      {"unary-2-t4-r1-h2048-o6", "unary", 2, 4, 1, 2048, 6, c::native::kProviderId},
      {"unary-2-t4-r32-h2048-o6", "unary", 2, 4, 32, 2048, 6, c::native::kProviderId},
      {"unary-2-t5-r32-h2048-o6", "unary", 2, 5, 32, 2048, 6, c::native::kProviderId},
      {"unary-2-t6-r1-h2048-o6", "unary", 2, 6, 1, 2048, 6, c::native::kProviderId},
      {"unary-2-t6-r1-h4096-o6", "unary", 2, 6, 1, 4096, 6, c::native::kProviderId},
      {"unary-2-t6-r32-h2048-o6", "unary", 2, 6, 32, 2048, 6, c::native::kProviderId},
      {"unary-3-t4-r1-h2048-o6", "unary", 3, 4, 1, 2048, 6, c::native::kProviderId},
      {"unary-4-t4-r1-h2048-o6", "unary", 4, 4, 1, 2048, 6, c::native::kProviderId},
      {"unary-4-t5-r32-h2048-o6", "unary", 4, 5, 32, 2048, 6, c::native::kProviderId},
      {"unary-5-t4-r1-h2048-o6", "unary", 5, 4, 1, 2048, 6, c::native::kProviderId},
      {"unary-5-t4-r32-h2048-o6", "unary", 5, 4, 32, 2048, 6, c::native::kProviderId},
      {"unary-5-t5-r32-h2048-o6", "unary", 5, 5, 32, 2048, 6, c::native::kProviderId},
      {"unary-6-t4-r1-h4096-o6", "unary", 6, 4, 1, 4096, 6, c::native::kProviderId},
      {"unary-8-t5-r1-h2048-o6", "unary", 8, 5, 1, 2048, 6, c::native::kProviderId},
      {"unary-8-t5-r32-h2048-o6", "unary", 8, 5, 32, 2048, 6, c::native::kProviderId},
  };

  for (bool graph : {false, true}) {
    std::cerr<<"RULE_CONTEXT graph="<<graph<<std::endl; auto context_result=graph ? g::cpu::create_context() : c::cpu::create_context(); if(!context_result) { std::cerr<<context_result.error().message()<<std::endl; throw std::runtime_error("rule context failed"); } auto context=std::move(*context_result);
    for (const auto &item : cases) { std::cerr<<"RULE graph="<<graph<<" id="<<item.id<<std::endl;
      const auto t = DataType(item.type);
      const auto input = dense(t, {item.rows, item.width});
      std::vector<TensorDesc> inputs{input};
      Operation op;
      if (item.family == "unary") op = Operation(Unary{UnaryKind(item.variant)});
      else if (item.family == "binary") { op = Operation(Binary{BinaryKind(item.variant)}); inputs.push_back(input); }
      else if (item.family == "norm") { op = Operation(RmsNorm{}); inputs.push_back(dense(t, {item.width})); }
      else if (item.family == "reduce") op = Operation(Reduce{.kind=ReductionKind(item.variant), .axes=Axes::from(std::array<std::int32_t,1>{1}).value(), .accumulation_type=DataType::kFloat32});
      else if (item.family == "softmax") { op=Operation(Softmax{.mask=MaskKind::kBoolean}); inputs.push_back(dense(DataType::kBool,{item.rows,item.width})); }
      else if (item.family == "silu-gate") { op=Operation(GatedActivation{.inputs=GatedInputKind::kSeparate}); inputs.push_back(input); }
      else if (item.family == "fill") { op=Operation(Fill{.output_shape=TensorShape::create(std::array<std::int64_t,2>{item.rows,item.width}).value(), .output_type=t, .value=ScalarValue::from_bits(t,0x3fa00000ULL)}); inputs.clear(); }
      else if (item.family == "gather") { op=Operation(Gather{}); inputs={dense(t,{64,item.width}),dense(DataType(item.other),{item.rows})}; }
      else if (item.family == "cast") op=Operation(Cast{DataType(item.other)});
      const auto output=infer_single_output(op,inputs).value();
      auto result=prepare(context,op,inputs,std::span(&output,1),m::system_resource()); if(!result) { std::cerr<<result.error().message()<<std::endl; throw std::runtime_error("rule prepare failed"); } auto program=std::move(*result);
      if (qualified) { require(program.provider().id==item.winner); require(program.route_policy().namespace_id==0x48594c4543505552ULL && program.route_policy().version==3); }
      else require(program.route_policy().namespace_id!=0x48594c4543505552ULL);
    }
    const auto input=dense(DataType::kBFloat16,{32,2048});
    std::cerr<<"RULE_PROJECTION graph="<<graph<<std::endl; auto weight=dense(DataType::kBFloat16,{6144,2048}); std::cerr<<"weight dense passed"<<std::endl; auto transposed=weight.transposed(); if(!transposed) { std::cerr<<transposed.error().message()<<std::endl; throw std::runtime_error("weight transpose failed"); } std::cerr<<"weight transpose passed"<<std::endl; auto projection_result=prepare(context,MatMul{},input,*transposed); if(!projection_result) { std::cerr<<projection_result.error().message()<<std::endl; throw std::runtime_error("rule projection failed"); } auto projection=std::move(*projection_result);
    require(projection.provider().id==ggml_cpu::kProviderId);
    require(projection.output_description()->data_type()==DataType::kBFloat16);
    if (qualified) require(projection.route_policy().namespace_id==0x48594c4543505552ULL && projection.route_policy().version==3);
    else require(projection.route_policy().namespace_id!=0x48594c4543505552ULL);
    std::cerr<<"RULE_REPLAY graph="<<graph<<std::endl; floats(execute(graph,Operation(Unary{UnaryKind::kExp}),{dense(DataType::kFloat32,{1,2048})},{bytes(std::vector<float>(2048,0.25F))}),std::exp(0.25F));
  }
  std::cout<<"current SDK rules=43 contexts=2 qualified="<<qualified<<" PASS\n";
}

int main(int argc,char** argv){try{
  check_current_rules(argc==2 && std::string_view(argv[1])=="--qualified");
  using D=c::DataType;using Q=c::GgufQuantizedType;
  using F=c::model_ops::WeightArtifactFormat;using M=c::model_ops::MlxWeightFormat;
  int checks=0;
  for(bool graph:{false,true}) {
    // F32 accumulation on exactly represented F16 inputs, with one output
    // rounding. The old ARM half-dot path produces 0x4667 instead of 0x4666.
    for (const auto pair : {std::array<std::uint16_t,2>{0x3400,0x4666},
                           std::array<std::uint16_t,2>{0x3800,0x4a66}}) {
      auto result=execute(graph,c::Operation(c::MatMul{}),
          {dense(D::kFloat16,{1,256}),dense(D::kFloat16,{256,1})},
          {bytes(std::vector<std::uint16_t>(256,pair[0])),
           bytes(std::vector<std::uint16_t>(256,0x2e66))});
      require(result.size()==sizeof(std::uint16_t));std::uint16_t actual;
      std::memcpy(&actual,result.data(),sizeof(actual));require(actual==pair[1]);
      ++checks;
    }
    for(auto type:{Q::kQ4_0,Q::kQ4_1,Q::kQ2K,Q::kIq2Xxs,Q::kIq2Xs,Q::kIq2S,
                   Q::kIq1S,Q::kIq1M,Q::kIq1Xxxs,Q::kIq1Xxs,Q::kIq1Xs}) {
      std::cout<<"graph="<<graph<<" GGUF="<<int(type)<<std::endl;
      const auto k=type==Q::kQ4_0||type==Q::kQ4_1?64:256;
      const auto w=c::gguf_weight_description(type,D::kFloat32,k,2).value();
      std::vector<std::byte> packed(w.required_bytes().value());float expected=0;
      if(type==Q::kQ4_0||type==Q::kQ4_1) {
        const auto block=type==Q::kQ4_0?18:20;
        for(std::size_t base=0;base<packed.size();base+=block){
          put_half(packed,base,0x3c00);
          if(type==Q::kQ4_1)put_half(packed,base+2,0x3800);
          std::fill_n(packed.begin()+base+(type==Q::kQ4_0?2:4),16,std::byte(type==Q::kQ4_0?0x99:0x11));
        }
        // Original Q8_0/Q8_1 activation uses half(1/127) = 0x2008.
        // Q8_1's separately stored half sum is exactly 32 per block.
        expected=type==Q::kQ4_0?63.99609375f:95.99609375f;
      }else if(type==Q::kQ2K){
        for(std::size_t base=0;base<packed.size();base+=84){
          std::fill_n(packed.begin()+base,16,std::byte{0x11});
          std::fill_n(packed.begin()+base+16,64,std::byte{0x55});
          put_half(packed,base+80,0x3c00);put_half(packed,base+82,0x3400);
        }expected=192;
      }
      floats(execute(graph,c::Operation(c::MatMul{}), {dense(D::kFloat32,{1,k}),w},
                     {bytes(std::vector<float>(k,1)),packed}),expected);++checks;
    }
    for(auto format:{F::kNf4,F::kNf4DoubleQuant,F::kAwqGemm4,F::kCompressedTensorsSymmetric4}) {
      std::cout<<"graph="<<graph<<" artifact="<<int(format)<<std::endl;
      const auto group=format==F::kNf4||format==F::kNf4DoubleQuant?64:128;
      std::vector<c::TensorDesc> descs;std::vector<std::vector<std::byte>> payload;
      if(format==F::kNf4||format==F::kNf4DoubleQuant){
        descs={dense(D::kUInt8,{2,128})};payload={bytes(std::vector<std::uint8_t>(256,0x11))};
        if(format==F::kNf4){descs.push_back(dense(D::kFloat32,{8}));payload.push_back(bytes(std::vector<float>(8,1)));}
        else{
          descs.insert(descs.end(),{dense(D::kUInt8,{8}),dense(D::kFloat32,{1}),dense(D::kFloat32,{256}),dense(D::kFloat32,{})});
          payload.insert(payload.end(),{bytes(std::vector<std::uint8_t>(8,1)),bytes(std::vector<float>{1}),
                         bytes(std::vector<float>(256,1)),bytes(std::vector<float>{0})});
        }
        descs.push_back(dense(D::kFloat32,{16}));payload.push_back(bytes(std::vector<float>(16,1)));
      }else if(format==F::kAwqGemm4){
        descs={dense(D::kInt32,{256,1}),dense(D::kInt32,{2,1}),dense(D::kFloat16,{2,8})};
        payload={bytes(std::vector<std::int32_t>(256,0x11111111)),bytes(std::vector<std::int32_t>(2,0)),bytes(std::vector<std::uint16_t>(16,0x3c00))};
      }else{
        descs={dense(D::kInt32,{2,32}),dense(D::kBFloat16,{2,2})};
        payload={bytes(std::vector<std::int32_t>(64,-1717986919)),bytes(std::vector<std::uint16_t>(4,0x3f80))};
      }
      auto op=c::model_ops::artifact_weight_decode(format,group);
      std::array<c::TensorDesc,1> inferred;require(c::infer_output_descriptions(op,descs,inferred).ok());
      auto decoded=execute(graph,op,descs,payload);
      const auto dtype=inferred[0].data_type();const auto n=inferred[0].dimensions()[0];
      const auto one=dtype==D::kFloat16?0x3c00:0x3f80;
      const auto projected=execute(graph,c::Operation(c::MatMul{}), {dense(dtype,{1,256}),inferred[0].transposed().value()},
                    {bytes(std::vector<std::uint16_t>(256,std::uint16_t(one))),decoded});
      require(projected.size()==std::size_t(n*2));
      for(std::size_t i=0;i<projected.size();i+=2){std::uint16_t value;std::memcpy(&value,projected.data()+i,2);if(value!=(dtype==D::kFloat16?0x5c00:0x4380))std::cerr<<"half actual="<<value<<" dtype="<<int(dtype)<<'\n';require(value==(dtype==D::kFloat16?0x5c00:0x4380));}
      ++checks;
    }
    for(auto format:{M::kAffine4,M::kMxfp4,M::kMxfp8}){
      const bool affine=format==M::kAffine4;
      const auto words=format==M::kMxfp8?16:8;
      const auto code=format==M::kMxfp8?0x38383838u:affine?0x11111111u:0x22222222u;
      std::vector<c::TensorDesc> descs{dense(D::kFloat32,{1,2,64}),dense(D::kUInt32,{2,3,words}),
            dense(affine?D::kFloat32:D::kUInt8,{2,3,affine?1:2})};
      std::vector<std::vector<std::byte>> payload{bytes(std::vector<float>(128,1)),bytes(std::vector<std::uint32_t>(6*words,code)),
          affine?bytes(std::vector<float>(6,1)):bytes(std::vector<std::uint8_t>(12,127))};
      if(affine){descs.push_back(descs.back());payload.push_back(bytes(std::vector<float>(6,0)));}
      descs.push_back(dense(D::kInt32,{1,2}));payload.push_back(bytes(std::vector<std::int32_t>{1,1}));
      floats(execute(graph,c::model_ops::mlx_grouped_matmul(format,affine?64:32),descs,payload),64);++checks;
    }
  }
  std::cout<<"ordinary CPU Direct/Graph delivery checks="<<checks<<" PASS\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
