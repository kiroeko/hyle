import subprocess
from pathlib import Path
import json

root=Path.cwd()
out=root/'.scratch/validation/cpu-final-f4/delivery-linux'
source=out.parent/'delivery-consumer/main.cc'
text=source.read_text()
text=text.replace('auto context = graph ? g::cpu::create_context().value() : c::cpu::create_context().value();',
    'std::cerr<<"RULE_CONTEXT graph="<<graph<<std::endl; auto context_result=graph ? g::cpu::create_context() : c::cpu::create_context(); if(!context_result) { std::cerr<<context_result.error().message()<<std::endl; throw std::runtime_error("rule context failed"); } auto context=std::move(*context_result);')
text=text.replace('for (const auto &item : cases) {','for (const auto &item : cases) { std::cerr<<"RULE graph="<<graph<<" id="<<item.id<<std::endl;')
text=text.replace('auto program=prepare(context,op,inputs,std::span(&output,1),m::system_resource()).value();',
    'auto result=prepare(context,op,inputs,std::span(&output,1),m::system_resource()); if(!result) { std::cerr<<result.error().message()<<std::endl; throw std::runtime_error("rule prepare failed"); } auto program=std::move(*result);')
text=text.replace('auto projection=prepare(context,MatMul{},input,dense(DataType::kBFloat16,{6144,2048}).transposed().value()).value();',
    'std::cerr<<"RULE_PROJECTION graph="<<graph<<std::endl; auto weight=dense(DataType::kBFloat16,{6144,2048}); std::cerr<<"weight dense passed"<<std::endl; auto transposed=weight.transposed(); if(!transposed) { std::cerr<<transposed.error().message()<<std::endl; throw std::runtime_error("weight transpose failed"); } std::cerr<<"weight transpose passed"<<std::endl; auto projection_result=prepare(context,MatMul{},input,*transposed); if(!projection_result) { std::cerr<<projection_result.error().message()<<std::endl; throw std::runtime_error("rule projection failed"); } auto projection=std::move(*projection_result);')
diagnostic=out/'consumer-diagnostic.cc'
text=text.replace('floats(execute(graph,Operation(Unary{UnaryKind::kExp}),',
                  'std::cerr<<"RULE_REPLAY graph="<<graph<<std::endl; floats(execute(graph,Operation(Unary{UnaryKind::kExp}),')
text=text.replace('auto invocation=program.create_invocation', 'std::cerr<<"invocation create"<<std::endl; auto invocation=program.create_invocation')
text=text.replace('auto prepared=c::prepare(context,op,inputs,std::span(&output,1)).value();',
    'auto prepared_result=c::prepare(context,op,inputs,std::span(&output,1)); if(!prepared_result) { std::cerr<<"EXEC_PREPARE "<<prepared_result.error().message()<<std::endl; throw std::runtime_error("execute prepare failed"); } auto prepared=std::move(*prepared_result);')
text=text.replace('auto invocation=prepared.create_invocation().value();',
    'auto invocation_result=prepared.create_invocation(); if(!invocation_result) { std::cerr<<"EXEC_INVOCATION "<<invocation_result.error().message()<<std::endl; throw std::runtime_error("execute invocation failed"); } auto invocation=std::move(*invocation_result);')
text=text.replace('for(int i=0;i<2;++i)require(invocation.submit(queue,inputs,std::span(&output,1)).value().wait().ok());',
    'for(int i=0;i<2;++i) { auto completion=invocation.submit(queue,inputs,std::span(&output,1)); if(!completion) { std::cerr<<"EXEC_SUBMIT "<<completion.error().message()<<std::endl; throw std::runtime_error("execute submit failed"); } auto status=completion->wait(); if(!status.ok()) std::cerr<<"EXEC_WAIT "<<status.message()<<std::endl; require(status.ok()); }')
diagnostic.write_text(text,encoding='utf-8')
code="from pathlib import Path; import shutil,subprocess; a=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/delivery-linux/consumer-diagnostic.cc'); b=Path('/root/hyle-scratch/active-cpu-z/f4-consumer/main.cc'); shutil.copyfile(a,b); subprocess.run(['cmake','--build','/root/hyle-scratch/active-cpu-z/build','--target','cpu_f4_source_delivery','--parallel','2'],check=True); result=subprocess.run(['/root/hyle-scratch/active-cpu-z/build/bin/cpu_f4_source_delivery']); raise SystemExit(result.returncode)"
with (out/'diagnostic-driver.log').open('wb') as log:
    result=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',code],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/'diagnostic-driver.log').read_text(errors='replace')[-4500:],flush=True)
print({'diagnostic_exit':result.returncode},flush=True)
