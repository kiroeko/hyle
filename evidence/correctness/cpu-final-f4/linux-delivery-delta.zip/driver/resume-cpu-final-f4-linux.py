import subprocess
from pathlib import Path

ROOT=Path.cwd()
out=ROOT/'.scratch/validation/cpu-final-f4/delivery-linux'
first=out/'remote-driver.py'
text=first.read_text(encoding='utf-8')
begin=text.index('records=[];env=')
end=text.index("run('machine'",begin)
functions=text[begin:end]
functions=functions.replace('records=[];env=',"records=json.loads((out/'receipt.json').read_text());env=")
loop=text[text.index('build=root/'):] 
# Preserve the old source failure and successful configure/build. Configure is
# repeated only to apply the missing consumer staging seam; math is unchanged.
script='''import json,pathlib,shutil,subprocess,time,os
root=pathlib.Path('/root/hyle-scratch/active-cpu-z').resolve();source=root/'source';out=root/'f4-result'
consumer=root/'f4-consumer';overlay=root/'f4-overlay.cmake'
shutil.copyfile('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/delivery-consumer/main.cc',consumer/'main.cc')
before=subprocess.check_output(['readelf','-d',root/'build/bin/cpu_f4_source_delivery'],text=True)
(out/'initial-loader.txt').write_text(before)
content=overlay.read_text()
assert 'hyle_stage_runtime_dependencies(cpu_f4_source_delivery)' not in content
content=content.replace('endfunction()', 'hyle_stage_runtime_dependencies(cpu_f4_source_delivery)\\nendfunction()')
overlay.write_text(content)
'''+functions+loop
script=script.replace("'64304e9e691cc78d2ead05a7c88fa485f9b8adc4'", "'64304e9e691cc78d2ead05a7c88fa485f9b8adc4'")
resume=out/'resume-driver.py'
resume.write_text(script,encoding='utf-8')
with (out/'resume.log').open('wb') as log:
    result=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3',
        '/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/delivery-linux/resume-driver.py'],
        stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/'resume.log').read_text(errors='replace')[-6500:],flush=True)
copy="from pathlib import Path; import shutil; a=Path('/root/hyle-scratch/active-cpu-z/f4-result'); b=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/delivery-linux'); [shutil.copyfile(p,b/p.name) for p in a.iterdir() if p.is_file()]"
subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',copy],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
result.check_returncode()
