#!/usr/bin/env bash
set -euo pipefail
r4_root=$1
r4_cmake=$2
export PATH="$(dirname "$r4_cmake"):/opt/homebrew/bin:$PATH"
cd "$r4_root"
printf '%s  %s\n' 15792e0325fe79492df0cefb4950dcf450df362c31948d34071862154b8a7325 f7d14870.tar.gz | shasum -a 256 -c -
mkdir -p logs
if [ ! -e source/CMakeLists.txt ]; then
  mkdir -p source
  tar -xzf f7d14870.tar.gz -C source
fi
printf '%s  %s\n' 05163c090ea9637d023883354d1dd0942b38d4e8599a0619a5df8f786e40ccda test-braces-755fb7c7.tar | shasum -a 256 -c -
tar -xf test-braces-755fb7c7.tar -C source
uname -a >logs/machine.txt
xcrun clang++ --version >>logs/machine.txt
for kind in none cpu core; do
  r4_logs="$r4_root/logs/$kind"
  mkdir -p "$r4_logs"
  if ! bash source/scripts/hyle-unix.sh "$r4_cmake" -S projection -B "$r4_root/build-$kind" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 \
    "-DR4_SOURCE=$r4_root/source" "-DR4_KIND=$kind" -DCMAKE_DISABLE_FIND_PACKAGE_CUDAToolkit=TRUE \
    >"$r4_logs/configure.log" 2>&1; then
    tail -n 70 "$r4_logs/configure.log"
    exit 1
  fi
  python3 check-projection.py "$kind" "$r4_root/build-$kind/hyle_build" "$r4_logs/projection.json"
  cp "$r4_root/build-$kind/CMakeCache.txt" "$r4_logs/CMakeCache.txt"
  cp "$r4_root/build-$kind/hyle_build/HyleConfig.cmake" "$r4_logs/HyleConfig.cmake"
  cp "$r4_root/build-$kind/hyle_build/cmake_install.cmake" "$r4_logs/cmake_install.cmake"
done
if ! "$r4_cmake" --build "$r4_root/build-none" --target r4_compute r4_graph --parallel 2 >"$r4_root/logs/none/public-build.log" 2>&1; then
  tail -n 70 "$r4_root/logs/none/public-build.log"
  exit 1
fi
if ! ctest --test-dir "$r4_root/build-none" --output-on-failure --no-tests=error --timeout 120 -j 1 >"$r4_root/logs/none/public-test.log" 2>&1; then
  tail -n 70 "$r4_root/logs/none/public-test.log"
  exit 1
fi
cp "$r4_root/build-none/Testing/Temporary/LastTest.log" "$r4_root/logs/none/LastTest.log"
cat "$r4_root/logs/none/public-test.log"
echo 'R4 CUDA-OFF macOS public C++ consumers and publishing projection PASS; no CUDA runtime claim' 
