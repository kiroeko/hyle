import hashlib
import json
import pathlib
import re
import sys

kind, root_arg, output_arg = sys.argv[1:]
root = pathlib.Path(root_arg)
output = pathlib.Path(output_arg)
files = [root / 'HyleConfig.cmake', root / 'cmake_install.cmake']
files += sorted(root.glob('CMakeFiles/Export/*/HyleTargets.cmake'))
assert len(files) == 3, files
contents = {str(p.relative_to(root)): p.read_text(encoding='utf-8') for p in files}
joined = '\n'.join(contents.values())
for token in ('CUDAToolkit', 'CUDA::', 'compute_provider_cublas', 'compute_provider_marlin',
              'hyle/compute/cuda.h', 'hyle/graph/cuda.h', 'marlin-LICENSE', 'sglang-activation-LICENSE', 'sglang-activation-NOTICE',
              'hyle/compute/providers/cuda.h', 'hyle/compute/backends/cuda.h'):
    # Optional absent directories may appear as subdirectory install includes;
    # exported targets, headers, and dependency discovery may not appear.
    if token.startswith('compute_provider_'):
        assert not re.search(r'(add_library|INTERFACE_LINK_LIBRARIES)[^\n]*' + token, joined), token
    else:
        assert token not in joined, token
if kind in ('none', 'core'):
    for token in ('hyle/compute/cpu.h', 'hyle/graph/cpu.h', 'hyle/compute/providers/native.h',
                  'hyle/compute/providers/onednn.h', 'hyle/graph/providers/onednn.h'):
        assert token not in joined, token
if kind == 'cpu':
    assert 'hyle/compute/cpu.h' in joined
    assert 'hyle/graph/cpu.h' in joined
record = {'kind': kind, 'result': 'PASS', 'scope': 'generated install headers, exports, and package dependency projection; no CUDA runtime claim',
          'files': {name: hashlib.sha256(text.encode()).hexdigest() for name, text in contents.items()}}
output.parent.mkdir(parents=True, exist_ok=True)
with output.open('w', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(f'{kind}: CUDA OFF install/export/dependency projection PASS')
