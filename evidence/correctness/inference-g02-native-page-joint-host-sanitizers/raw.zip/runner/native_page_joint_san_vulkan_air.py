from pathlib import Path
import json,subprocess,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');script=base/'native_page_joint_san_air.py'
out=base/'g02-native-page-joint-host-sanitizers';out.mkdir(exist_ok=True)
rows=[];start=time.monotonic()
for route in ['vulkan']:
    for mode in ['asan','ubsan','tsan']:
        log=out/f'{route}-{mode}-attempt2.log'
        assert not log.exists(),'do not overwrite prior attempts or reset budget'
        with log.open('w') as stream:
            process=subprocess.Popen(['/usr/bin/python3',str(script),route,mode],stdout=stream,stderr=subprocess.STDOUT)
            record={'state':'RUNNING','pid':process.pid,'route':route,'mode':mode,'log':str(log),'completed':rows}
            (out/'vulkan-job-attempt2.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
            code=process.wait()
        rows.append({'route':route,'mode':mode,'exit_code':code})
        if code:
            record.update(state='TERMINAL',exit_code=code,completed=rows,elapsed_seconds=time.monotonic()-start)
            (out/'vulkan-job-attempt2.json').write_text(json.dumps(record,indent=2)+'\n');print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
record.update(state='TERMINAL',exit_code=0,completed=rows,elapsed_seconds=time.monotonic()-start)
(out/'vulkan-job-attempt2.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
