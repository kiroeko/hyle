from pathlib import Path
import hashlib,json,os,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/f'.scratch/inference-gaps/g04-g05/cpu-native/source-batch-{sys.argv[1]}'
OUT.mkdir(parents=True,exist_ok=False)
PARENT=Path('C:/h7/inference-g01-native-vulkan/parent/CMakeLists.txt')
BUILD=Path('C:/h7/inference-g01-native-vulkan/build');TARGET='g04_g05_cpu_native_tests'
text=PARENT.read_text(encoding='utf-8')
if f'add_executable({TARGET}' not in text:
 text+=f'''\nadd_executable({TARGET}
   "{(ROOT/'tests/compute_provider_ggml/native_paged_test.cc').as_posix()}"
   "{(ROOT/'tests/compute_provider_ggml/native_ragged_test.cc').as_posix()}")
target_compile_features({TARGET} PRIVATE cxx_std_23)
target_compile_options({TARGET} PRIVATE /W4 /WX /wd4324 /utf-8)
target_link_libraries({TARGET} PRIVATE hyle_compute_backend_cpu hyle_compute_provider_ggml hyle_compute_batch hyle_simd GTest::gtest_main)
hyle_stage_runtime({TARGET})
'''
 PARENT.write_text(text,encoding='utf-8',newline='\n')
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.stdout.splitlines() if '=' in x and not x.startswith('=')))
paths=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
result={'state':'RUNNING','pid':os.getpid(),'baseline':'feca31e543bd63d36c240e622031a428f4abb8dc',
 'scope':'CE03 real Windows CPU encoder/boxed/ragged/paged source stage; no GPU execution, SDK/sanitizer/P1 pass',
 'max_jobs':4,'stages':[],'cumulative_seconds':0,
 'inputs':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}}
(OUT/'worktree.diff').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
def save():
 (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
commands=[
 ('compile',['cmake','--build',str(BUILD),'--target',TARGET,'--parallel','4']),
 ('tests',[str(BUILD/(TARGET+'.exe')),'--gtest_output=xml:'+str(OUT/'tests.xml')])]
if '--new-domain-only' in sys.argv:
 commands[-1][1].append('--gtest_filter=GgmlCpuCacheEncode.*:GgmlCpuBoxed.*')
if '--skip-configure' not in sys.argv:
 commands.insert(0,('configure',['cmake','-S',str(PARENT.parent),'-B',str(BUILD)]))
for stage,command in commands:
 start=time.monotonic();log=OUT/(stage+'.log')
 with log.open('wb') as stream:done=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
 elapsed=time.monotonic()-start
 result['stages'].append({'stage':stage,'command':command,'exit_code':done.returncode,'elapsed_seconds':elapsed,'log':str(log)})
 result['cumulative_seconds']+=elapsed;save();print(f'{stage}: exit={done.returncode}, elapsed={elapsed:.3f}s',flush=True)
 if done.returncode:result['state']='TERMINAL_FAIL';save();raise SystemExit(done.returncode)
result['state']='TERMINAL_PASS';save()
