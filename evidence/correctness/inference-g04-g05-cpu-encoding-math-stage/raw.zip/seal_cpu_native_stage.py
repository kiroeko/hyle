from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3]
RUN=ROOT/'.scratch/inference-gaps/g04-g05/cpu-native'
OUT=ROOT/'evidence/correctness/inference-g04-g05-cpu-encoding-math-stage'
OUT.mkdir(parents=True,exist_ok=False)
records=[json.loads((RUN/f'source-batch-{i}/result.json').read_text(encoding='utf-8')) for i in range(1,9)]
assert all(r['state'].startswith('TERMINAL_') for r in records)
assert records[-1]['state']=='TERMINAL_PASS'
product_paths=[p for p in records[-1]['inputs'] if not p.startswith('docs/')]
for p in product_paths:
 assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==records[-1]['inputs'][p],p
for p in product_paths:
 if p.startswith(('src/','cmake/','third_party/')):
  assert records[3]['inputs'][p]==records[-1]['inputs'][p],p
last_xml=ET.parse(RUN/'source-batch-8/tests.xml').getroot()
old_xml=ET.parse(RUN/'source-batch-4/tests.xml').getroot()
assert int(last_xml.attrib['tests'])==10 and int(last_xml.attrib['failures'])==0
old_pass=[c.attrib['classname']+'.'+c.attrib['name'] for c in old_xml.iter('testcase')
          if c.attrib['classname'] in ['GgmlCpuPaged','GgmlCpuRagged'] and c.find('failure') is None]
assert len(old_pass)==5
failures=[{'run':i+1,'state':r['state'],'stages':[s for s in r['stages'] if s['exit_code']!=0]} for i,r in enumerate(records) if r['state']!='TERMINAL_PASS']
result={'kind':'G04_G05_CPU_ENCODING_AND_BOXED_MATH_SOURCE_STAGE','verdict':'PASS_FINITE_WINDOWS_SOURCE_DOMAIN',
 'baseline':records[-1]['baseline'],'owners_remain':'AUDITED; G04/G05 whole gates UNPROVEN',
 'delivery':'Windows MSVC19.50.35728.0 shared, shipping HYLE_TESTING OFF, cpu+vulkan configured; CPU execution only',
 'native_core':'456172ec733a mixed IQ1 composition, baseline+AVX2 CPU; CPU-only ffa core patch derivation verified but runtime UNPROVEN',
 'input_sha256':{p:records[-1]['inputs'][p] for p in product_paths},
 'qualified':[
 'Real original ggml CacheEncode Q8_0/FP8 bytes; F16/BF16/F32 inputs; independent ties/zero/rounding/saturation oracle and accepted invalid-payload errors',
 'Direct ragged/paged Q8 K/V with original root audit, GQA8/2, (64,64)/(128,128)/(256,256)/(64,128), F16/BF16 Q/output',
 'Causal bottom-right inclusive window -1/0/15/16; plain window with independent Dv; full noncausal query33/35 versus KV31/33',
 'Main D256 long prefill query1/65 versus KV129/145; shared/reordered pages logical274 versus physical256, independent decoded-cache double oracle',
 '4096-row plain F16 cancellation with one original worker, original F32 V accumulator; no history expansion',
 'Q8 query finite/half-scale overflow rejection, original failed slot refusal, fresh recovery; separate encoder invocations and failed encoder recreation',
 'Original coupled plain paged and ragged math/topology reuse/lifetime, budget, partial native allocation failures and accepted math error retirement'],
 'tests':{'new_final':10,'reused_same_product_old':5,'old_test_names':old_pass,'positive_boxed_fixtures':45,
          'note':'CPU Q8 additionally quantizes Q to original vec-dot type; double reference decodes actual encoded K/V and tolerance covers bounded Q conversion plus output rounding'},
 'P0':{'ordinary_invocation':'one nullable pointer (8 bytes on MSVC), no new execution owner',
       'opt_in':'original allocator state/callback values/query-root list; known capacities counted; remaining native metadata is explicitly unknown',
       'warm':'Q8 query range scan O(Q*Hq*Dqk); original query conversion and online softmax; V conversion O(Dv) per row, no full-KV decode or Q*KV mask in boxed path; Q8 encoding per-worker stack128 bytes'},
 'not_proven':['CPU-only ffa execution','CPU encoder two-node Graph and incremental F2/page journey','CUDA/Apple/Vulkan new native math or encoders',
               'SDK static/shared installation','new domain sanitizers/allocator faults/concurrency','P1 engineering performance','G04/G05 full acceptance'],
 'failures_preserved':failures,'runs':records,'cumulative_seconds':sum(r['cumulative_seconds'] for r in records),
 'build_scope':'One CPU fixture target. Selected mixed ggml backend aggregate generated/rebuilt Vulkan dependencies after source identity changed; no Vulkan execution/qualification. Subsequent fixes reused generated outputs.'}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for i in range(1,9):
  for f in sorted((RUN/f'source-batch-{i}').iterdir()):
   if f.is_file():archive.write(f,f.relative_to(RUN).as_posix())
 for name in ['validation-initial.json','validation-after-edge.json','patch-identities.json','f32-patch-identities.json','final-patch-identities.json','mixed-patches-f32.json']:
  f=RUN/name
  if f.exists():archive.write(f,name)
 for p in ['.scratch/inference-gaps/g04-g05/run_cpu_native_batch.py','.scratch/inference-gaps/g04-g05/seal_cpu_native_stage.py']:
  archive.write(ROOT/p,Path(p).name)
print(json.dumps({'tests':15,'cumulative_seconds':result['cumulative_seconds'],'raw_bytes':(OUT/'raw.zip').stat().st_size}))
