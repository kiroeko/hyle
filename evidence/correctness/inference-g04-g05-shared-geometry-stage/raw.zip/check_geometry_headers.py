from pathlib import Path
import json,os,shutil,subprocess,time
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'.scratch/inference-gaps/g04-g05/geometry-batch'
result=json.loads((OUT/'result.json').read_text(encoding='utf-8'))
assert result['state']=='TERMINAL_PASS'
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.stdout.splitlines() if '=' in x and not x.startswith('=')))
compiler=shutil.which('cl.exe',path=env['PATH']);assert compiler
headers=['hyle/compute/low_precision.h','hyle/compute/operation.h','hyle/compute/model_ops.h',
         'hyle/compute/batch_layout.h','hyle/compute/batch_ops.h','hyle/compute/batch_execution.h',
         'hyle/compute/batch_materialize.h','hyle/compute/batch_paged_native.h',
         'hyle/compute/paged_arena.h','hyle/graph/batch.h']
srcs=[]
for i,header in enumerate(headers):
 p=OUT/f'header-{i}.cc';p.write_text(f'#include "{header}"\n',encoding='utf-8',newline='\n');srcs.append(str(p))
start=time.monotonic()
command=[compiler,'/nologo','/c','/std:c++latest','/EHsc','/utf-8','/W4','/WX','/wd4324','/DHYLE_STATIC',
         '/I'+str(ROOT/'include'),'/Fo'+str(OUT)+'\\',*srcs]
with (OUT/'standalone-headers.log').open('wb') as stream:
 completed=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-start
result['stages'].append({'stage':'standalone-headers','headers':headers,'exit_code':completed.returncode,'elapsed_seconds':elapsed,'log':str(OUT/'standalone-headers.log')})
result['cumulative_seconds']+=elapsed
if completed.returncode: result['state']='TERMINAL_FAIL'
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'headers={len(headers)}, exit={completed.returncode}, elapsed={elapsed:.3f}s')
raise SystemExit(completed.returncode)
