from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'.scratch/inference-gaps/g04-g05/geometry-batch'
OUT.mkdir(parents=True,exist_ok=True)
PARENT=Path('C:/h7/inference-g01-native-vulkan/parent/CMakeLists.txt')
BUILD=Path('C:/h7/inference-g01-native-vulkan/build')
TARGET='g04_g05_geometry_tests'
sources=['tests/compute_ops/low_precision_test.cc','tests/compute_batch/batch_layout_test.cc',
         'tests/compute_batch/batch_materialize_test.cc','tests/compute_batch/native_paged_metadata_test.cc',
         'tests/compute_batch/paged_arena_test.cc','tests/compute_batch/paged_arena_pending_test.cc',
         'tests/graph_batch/native_paged_node_test.cc']
text=PARENT.read_text(encoding='utf-8')
if f'add_executable({TARGET} ' not in text:
    text+='\nadd_executable('+TARGET+'\n'+''.join('  "'+(ROOT/p).as_posix()+'"\n' for p in sources)+')\n'
    text+=f'''target_compile_features({TARGET} PRIVATE cxx_std_23)
target_compile_options({TARGET} PRIVATE /W4 /WX /wd4324 /utf-8)
target_link_libraries({TARGET} PRIVATE hyle_graph_batch hyle_compute_state hyle_compute_backend_cpu GTest::gtest_main)
hyle_stage_runtime({TARGET})
'''
    PARENT.write_text(text,encoding='utf-8',newline='\n')
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.stdout.splitlines() if '=' in x and not x.startswith('=')))
paths=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
paths=[p for p in paths if p.startswith(('include/','src/','tests/','bench/'))]
result={'kind':'G04_G05_SHARED_GEOMETRY_IMPLEMENTATION_BATCH','state':'RUNNING','pid':os.getpid(),
        'baseline':'5d3994c728003b3fa0722f85c10f5bc266748f9f','stage_scope':'Common geometry/layout/arena/Graph descriptions and original host risks; no native math/GPU/model/P1 acceptance',
        'inputs':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},
        'stages':[],'cumulative_seconds':0,'max_jobs':4}
def save():
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
commands=[('configure',['cmake','-S',str(PARENT.parent),'-B',str(BUILD)]),
          ('compile',['cmake','--build',str(BUILD),'--target',TARGET,'--parallel','4']),
          ('tests',[str(BUILD/(TARGET+'.exe')),'--gtest_output=xml:'+str(OUT/'tests.xml')])]
for stage,command in commands:
    log=OUT/(stage+'-1.log');start=time.monotonic()
    with log.open('wb') as stream:
        completed=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
    elapsed=time.monotonic()-start
    result['stages'].append({'stage':stage,'command':command,'exit_code':completed.returncode,'elapsed_seconds':elapsed,'log':str(log)})
    result['cumulative_seconds']+=elapsed;save()
    print(f'{stage}: exit={completed.returncode}, elapsed={elapsed:.3f}s',flush=True)
    if completed.returncode:
        result['state']='TERMINAL_FAIL';save();raise SystemExit(completed.returncode)
result['state']='TERMINAL_PASS';save()
