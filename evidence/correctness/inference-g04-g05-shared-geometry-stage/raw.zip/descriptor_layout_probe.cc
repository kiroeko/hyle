#include "hyle/compute/batch_ops.h"
#include "hyle/compute/low_precision.h"
#include "hyle/compute/operation.h"
#include "hyle/graph/batch.h"
#include <cstdio>
#include <variant>

struct Custom96 {
  hyle::compute::OperationId id;
  const void *vtable;
  unsigned char size;
  alignas(std::max_align_t) std::byte descriptor[96];
};
int main() {
  using namespace hyle::compute;
  std::printf("Operation=%zu View=%zu Custom=%zu StorageFormat=%zu CacheStorage=%zu BatchCapacity=%zu NativePagedAttention=%zu Custom96=%zu VariantViewCustom96=%zu\n",
      sizeof(Operation), sizeof(View), sizeof(detail::CustomOperationValue),
      sizeof(StorageFormat), sizeof(CacheStorage), sizeof(BatchCapacity),
      sizeof(hyle::graph::batch::NativePagedAttention), sizeof(Custom96),
      sizeof(std::variant<View, Custom96>));
}
