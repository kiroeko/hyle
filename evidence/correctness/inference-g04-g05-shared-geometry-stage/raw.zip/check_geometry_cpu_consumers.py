from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'.scratch/inference-gaps/g04-g05/geometry-batch'
result=json.loads((OUT/'result.json').read_text(encoding='utf-8'))
assert result['state']=='TERMINAL_PASS'
for name,sha in result['inputs'].items():
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
result['state']='RUNNING';result['pid']=os.getpid()
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.stdout.splitlines() if '=' in x and not x.startswith('=')))
def save():
 (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
build='C:/h7/inference-g01-native-vulkan/build'
commands=[('cpu-direct-graph-compile',['cmake','--build',build,'--target','g03_common_receiver64','g03_pending_graph64','g03_common_receiver_risks','g03_pending_graph_risks','--parallel','4'])]
commands.extend((name,[build+'/'+name+'.exe']) for name in ['g03_common_receiver64','g03_pending_graph64','g03_common_receiver_risks','g03_pending_graph_risks'])
for stage,command in commands:
 start=time.monotonic();log=OUT/(stage+'.log')
 with log.open('wb') as stream:
  completed=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
 elapsed=time.monotonic()-start
 result['stages'].append({'stage':stage,'command':command,'exit_code':completed.returncode,'elapsed_seconds':elapsed,'log':str(log)})
 result['cumulative_seconds']+=elapsed;save();print(f'{stage}: exit={completed.returncode}, elapsed={elapsed:.3f}s',flush=True)
 if completed.returncode:
  result['state']='TERMINAL_FAIL';save();raise SystemExit(completed.returncode)
result['state']='TERMINAL_PASS';save()
