from pathlib import Path
import ctypes,json,os,subprocess,sys,time
from ctypes import wintypes

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';pid=int(sys.argv[1])
path=BASE/('queued-apple-encoded-after-vulkan-'+(sys.argv[2] if len(sys.argv)>2 else '1')+'.json');assert not path.exists()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
handle=kernel.OpenProcess(0x100000|0x1000,False,pid);assert handle
assert kernel.WaitForSingleObject(handle,0)==258,'dependency must be actually live'
record={'state':'WAITING_LIVE_VULKAN_SERIAL_QUEUE_HANDLE','pid':os.getpid(),'dependency_pid':pid,'heavy_serial':True}
def save():path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();print(json.dumps(record),flush=True)
try:
 while True:
  state=kernel.WaitForSingleObject(handle,30000)
  if state==0:break
  assert state==258
finally:kernel.CloseHandle(handle)
remote=BASE/'vulkan-encoded-p1/1/remote/job.json'
assert remote.is_file(),'remote Vulkan state is unconfirmed; do not overlap heavy jobs'
dependency=json.loads(remote.read_text(encoding='utf-8'))
assert dependency['state'] in ('TERMINAL','TERMINAL_SETUP_FAIL'),'require actual remote terminal state'
record['dependency_remote_terminal']=dependency;save()
command=[sys.executable,str(BASE/'launch_apple_encoded_page_preflight.py'),'1']
log=BASE/'queued-apple-encoded-launch-1.log';started=time.monotonic()
with log.open('wb') as stream:
 child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 record.update(state='RUNNING',child_pid=child.pid,command=command,log=str(log));save();print('Apple batch',child.pid,flush=True);code=child.wait()
record.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-started);save();print(json.dumps(record),flush=True)
