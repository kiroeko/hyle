from pathlib import Path
import hashlib,json,subprocess,sys

ROOT=Path.cwd()
allowed={
 'evidence/correctness/inference-g04-g05-cuda-encoded-page-preflight',
 'evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-1',
 'evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-2',
 'evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-3',
 'evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-4',
 'evidence/performance/inference-g04-g05-ce13-cpu-encoded-w1-p1',
 'evidence/performance/inference-g04-g05-vulkan-encoded-m1-p1-attempt-1',
 'evidence/correctness/inference-g04-g05-apple-encoded-page-preflight',
 'evidence/performance/inference-g04-g05-apple-encoded-m1-p1-attempt-1',
 'evidence/performance/inference-g04-g05-apple-encoded-m1-p1-attempt-2'}
relative=sys.argv[1];assert relative in allowed
folder=ROOT/relative;receipt=folder/'receipt.json'
assert receipt.is_file(),'only a complete sealed receipt may be committed'
r=json.loads(receipt.read_text(encoding='utf-8'))
assert hashlib.sha256((folder/'raw.zip').read_bytes()).hexdigest()==r['raw_zip_sha256']
for command in ([sys.executable,'scripts/check-module-closure.py'],
                [sys.executable,'scripts/check-docs.py'],['git','diff','--check']):
 subprocess.run(command,check=True)
changes=subprocess.check_output(['git','status','--porcelain','--',relative],text=True).strip()
if changes:
 subprocess.run(['git','add','--',relative],check=True)
 # --only preserves unrelated staged work and never includes other paths.
 subprocess.run(['git','commit','--only','-m',sys.argv[2],'--',relative],check=True)
print(json.dumps({'state':'SEALED_RECEIPT_COMMITTED','path':relative,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}))
