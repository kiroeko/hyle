from pathlib import Path
import hashlib,json,re,zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'apple-encoded-page-preflight'
runs=[]
for path in sorted(OUT.glob('job-*.json'),key=lambda p:int(p.stem.rsplit('-',1)[1])):
 attempt=path.stem.rsplit('-',1)[1];folder=OUT/attempt
 launch=json.loads(path.read_text(encoding='utf-8'))
 result=json.loads((folder/'result.json').read_text(encoding='utf-8')) if (folder/'result.json').is_file() else None
 runs.append({'attempt':attempt,'launch':launch,'stage_result':result,'setup_cost_unmeasured':not result or not result['stages']})
assert runs
last=runs[-1];r=last['stage_result']
assert last['launch']['state']=='TERMINAL_PASS' and r and r['state']=='TERMINAL_PASS'
assert last['launch']['ssh_exit']==0 and last['launch']['download_exit']==0
log=(OUT/last['attempt']/'oracle.log').read_text(encoding='utf-8')
rows=re.findall(r'^# ENCODED_PAGE_CORRECTNESS peer=([01]) replays=4 slots=2 readonly=PASS max_abs_error=([0-9.e+-]+) elements=([0-9]+)$',log,re.M)
assert len(rows)==6 and sum(peer=='0' for peer,error,elements in rows)==3
assert max(float(error) for peer,error,elements in rows)<=2e-3
assert len(r['actual_compile_steps'])==3
dest=ROOT/'evidence/correctness/inference-g04-g05-apple-encoded-page-preflight';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for path in sorted(OUT.rglob('*')):
  if not path.is_file():continue
  if 'build' in path.relative_to(OUT).parts and (path.suffix in ('.o','.a') or path.name=='g04_apple_encoded_bench'):continue
  package.write(path,path.relative_to(OUT).as_posix())
 for name in ('launch_apple_encoded_page_preflight.py','apple_encoded_page_preflight_air.py','seal_apple_encoded_page_preflight.py','queue_apple_encoded_after_vulkan.py','commit_sealed_receipt.py'):
  package.write(BASE/name,'runners/'+name)
 for name in ('apple-peer-local-materializer-failure-1.json','apple-peer-validation-plan.json','queued-apple-encoded-after-vulkan-1.json'):
  package.write(BASE/name,'setup/'+name)
receipt={'kind':'G04_G05_APPLE_ENCODED_PAGE_COMPLETE_JOURNEY_PREFLIGHT',
 'verdict':'PASS_NUMERICAL_LIFECYCLE_PREFLIGHT_ONLY','identity':r['identity'],
 'snapshot':r['snapshot'],'sdk_identity':r['sdk_identity'],'original_source':r['original_source'],
 'binary':r['binary'],'runs':runs,'actual_compile_steps':r['actual_compile_steps'],
 'cumulative_measured_stage_seconds':sum(x['stage_result']['cumulative_seconds'] for x in runs if x['stage_result']),
 'outer_launch_seconds_separate_overlaps_stages':sum(x['launch']['elapsed_seconds'] for x in runs),
 'shapes':3,'arms':2,'replays_per_shape_per_arm':4,'slots_per_arm':2,
 'max_abs_error':max(float(error) for peer,error,elements in rows),'readonly_KV':'PASS_BYTE_IDENTICAL',
 'limits':['No A/A/P1/throughput/whole G04-G05 verdict',
  'Explicit original general Q8 selection and disclosed 64/128 template instance; not best-of original host',
  'Original half tiles/F32 scores-softmax-output; actual query/output conversion precision retained',
  'Per-episode prepare/F2/exact guards/gather/contiguous/mask/pad/blk/native completion/output return charged',
  'Private-pool retained bytes and hard upper remain UNKNOWN; SDK CPU predates CE12/CE13',
  'Original local materializer retained-proof newline-format failure preserved; source/header unchanged'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('snapshot','sdk_identity','runs','original_source')}))
