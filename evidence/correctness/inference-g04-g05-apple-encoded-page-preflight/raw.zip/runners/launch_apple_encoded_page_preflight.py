from pathlib import Path
import hashlib,json,subprocess,sys,time,zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=sys.argv[1]
assert json.loads((BASE/'cpu-encoded-p1-job-4.json').read_text(encoding='utf-8'))['state']=='TERMINAL'
vulkan=json.loads((BASE/'vulkan-encoded-p1/1/remote/job.json').read_text(encoding='utf-8'))
assert vulkan['state'] in ('TERMINAL','TERMINAL_SETUP_FAIL'),'actual remote Vulkan terminal proof required'
vulkan_receipt=ROOT/'evidence/performance/inference-g04-g05-vulkan-encoded-m1-p1-attempt-1/receipt.json'
if not vulkan_receipt.is_file():
 subprocess.run([sys.executable,str(BASE/'seal_vulkan_encoded_p1.py'),'1'],check=True)
if vulkan_receipt.is_file():
 subprocess.run([sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/performance/inference-g04-g05-vulkan-encoded-m1-p1-attempt-1','test(compute): seal Vulkan encoded-page performance result'],check=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
OUT=BASE/'apple-encoded-page-preflight';OUT.mkdir(exist_ok=True)
archive=OUT/f'input-{attempt}.zip';assert not archive.exists()
paths=['bench/inference_resident_sdpa/'+name for name in ('apple_encoded_page_bench.cc','apple_encoded_page_reference.cc','apple_encoded_page_reference.h','apple_encoded_peer/CMakeLists.txt','apple_encoded_peer/prepare_source.py','apple_encoded_peer/qualified-sdk-artifacts.json')]
paths+=['bench/nanobench_impl.cc','bench/common/perf_process.h','third_party/nanobench/nanobench.h']
products=subprocess.check_output(['git','ls-files','include/hyle','src/compute_route_apple','src/compute_batch','src/graph_batch','src/compute_ops','third_party/mlx_cast/patches.json'],text=True).splitlines()
snapshot={'canonical_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'scope':'GPU-only Apple; unchanged Apple/common product inputs. SDK CPU predates CE12/CE13.',
 'benchmark_inputs':[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in paths],
 'product_inputs':[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in products]}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for name in paths:package.write(ROOT/name,name)
 package.writestr('snapshot.json',json.dumps(snapshot,indent=2)+'\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g04-apple-encoded-page-preflight'
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp',str(archive),str(BASE/'apple_encoded_page_preflight_air.py'),host+':'+remote+'/'],check=True)
command=['ssh','-o','BatchMode=yes',host,'python3',remote+'/apple_encoded_page_preflight_air.py',attempt]
started=time.monotonic();log=OUT/f'launch-{attempt}.log'
with log.open('wb') as stream:
 child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT)
 job={'state':'OBSERVING','pid':child.pid,'command':command,'log':str(log),'snapshot':snapshot}
 (OUT/f'job-{attempt}.json').write_text(json.dumps(job,indent=2)+'\n');print('Apple peer preflight',child.pid,flush=True);code=child.wait()
download=subprocess.run(['scp','-r',host+':'+remote+'/'+attempt,str(OUT)]).returncode
result=OUT/attempt/'result.json';state=json.loads(result.read_text(encoding='utf-8'))['state'] if result.is_file() else None
job.update(state=state if state in ('TERMINAL_PASS','TERMINAL_FAIL') else 'OBSERVER_ERROR_REMOTE_STATE_UNCONFIRMED',ssh_exit=code,download_exit=download,elapsed_seconds=time.monotonic()-started)
(OUT/f'job-{attempt}.json').write_text(json.dumps(job,indent=2)+'\n');print(json.dumps({k:v for k,v in job.items() if k!='snapshot'}),flush=True)
if not (job['state']=='TERMINAL_PASS' and code==0 and download==0):raise SystemExit(1)
for command in (
 [sys.executable,str(BASE/'seal_apple_encoded_page_preflight.py')],
 [sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/correctness/inference-g04-g05-apple-encoded-page-preflight','test(compute): qualify original Metal encoded-page peer'],
 [sys.executable,str(BASE/'launch_apple_encoded_p1.py'),'1']):
 result=subprocess.run(command)
 if result.returncode:
  # An actual P1 FAIL may still have a complete terminal record to seal.
  if command[1].endswith('launch_apple_encoded_p1.py'):
   terminal=BASE/'apple-encoded-p1/1/remote/job.json'
   if terminal.is_file() and json.loads(terminal.read_text(encoding='utf-8'))['state']=='TERMINAL':
    subprocess.run([sys.executable,str(BASE/'seal_apple_encoded_p1.py'),'1'],check=True)
    subprocess.run([sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/performance/inference-g04-g05-apple-encoded-m1-p1-attempt-1','test(compute): seal Apple encoded-page performance result'],check=True)
  raise SystemExit(result.returncode)
subprocess.run([sys.executable,str(BASE/'seal_apple_encoded_p1.py'),'1'],check=True)
subprocess.run([sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/performance/inference-g04-g05-apple-encoded-m1-p1-attempt-1','test(compute): seal Apple encoded-page performance result'],check=True)

