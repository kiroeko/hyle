from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile

BASE=Path('/Users/kiro/hyle-scratch/compute-unified');OUT=BASE/'g04-apple-encoded-page-preflight'
attempt=sys.argv[1];RUN=OUT/attempt;RUN.mkdir(exist_ok=False)
record={'state':'SETUP','stages':[],'cumulative_seconds':0,'max_jobs':4,
 'scope':'Actual Apple candidate/original Q8 page numeric, readonly and two-slot lifecycle only; not A/A/P1'}
active=None
def save():(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();(RUN/'runner.py').write_bytes(Path(__file__).read_bytes())
def failed(kind,error,traceback):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if active and active.poll() is None else 'TERMINAL_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed
identity={k:subprocess.check_output(command,text=True).strip() for k,command in (
 ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version']))}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64' and '21.0.0' in identity['compiler']
SOURCE=RUN/'source';SOURCE.mkdir()
with zipfile.ZipFile(OUT/f'input-{attempt}.zip') as package:
 product=json.loads(package.read('snapshot.json'))
 for item in product['benchmark_inputs']:
  name=Path(item['path']);assert not name.is_absolute() and '..' not in name.parts
  raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
  destination=SOURCE/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw)
canonical_copy=BASE/'source-c8874688'
for item in product['product_inputs']:
 assert hashlib.sha256((canonical_copy/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
proof=json.loads((SOURCE/'bench/inference_resident_sdpa/apple_encoded_peer/qualified-sdk-artifacts.json').read_text())
sdk=Path(proof['prefix'])
artifacts=proof['qualified_hyle_artifacts']+proof['supplemental_native_archives']+proof['qualified_sdk_recipes']+proof['native_metallibs']
def verify_sdk():
 for item in artifacts:assert hashlib.sha256((sdk/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
verify_sdk()
record['installed_public_headers']=[]
record['outside_selected_sdk_headers']=[]
for item in product['product_inputs']:
 if item['path'].startswith('include/hyle/'):
  installed=sdk/item['path']
  if installed.is_file():
   assert installed.read_bytes()==(canonical_copy/item['path']).read_bytes(),item['path']
   record['installed_public_headers'].append(item)
  else:record['outside_selected_sdk_headers'].append(item['path'])
# Unselected CUDA/other-route headers are not required in the Apple SKU.
# The actual compiler dependency closure below must use matched installed headers.
save()
assert hashlib.sha256((sdk/'include/metal_cpp/Foundation/NSSharedPtr.hpp').read_bytes()).hexdigest()=='d93f38effcc9556aa2cd2dec13db0cdcf37cd36bfd217bcbeedeb7e6c55fd2f4'
peer=BASE/'g01-original-ggml-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='456172ec733a135778adcd32d00e576a58232e45'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
record.update(state='RUNNING',identity=identity,snapshot=product,sdk_identity=proof);save()
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env['HYLE_BENCH_VERIFY_ONLY']='1'
def run(stage,args):
 global active
 log=RUN/f'{stage}.log';start=time.monotonic()
 with log.open('w') as stream:
  active=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':active.pid}));print(stage,active.pid,flush=True);code=active.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)});save()
 print(stage,code,elapsed,flush=True)
 if code:
  record.update(state='TERMINAL_FAIL');save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));print(log.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(code)
build=RUN/'build';target='g04_apple_encoded_bench'
run('configure',['/opt/homebrew/bin/cmake','-S',str(SOURCE/'bench/inference_resident_sdpa/apple_encoded_peer'),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+str(sdk),'-DHYLE_RESIDENT_REFERENCE_SOURCE='+str(peer)])
record['original_source']=json.loads((build/'original-metal-q8/source-provenance.json').read_text());save()
manifest=RUN/'exact-build.ninja';manifest.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(manifest),'-n',target],env=env,text=True);(RUN/'dry-run.txt').write_text(dry)
assert all(term not in dry for term in ('Re-running CMake','Building CXX object src/','Building C object src/','vulkan-shaders-gen'))
run('compile',['/opt/homebrew/bin/cmake','--build',str(build),'--target',target,'--parallel','4'])
record['actual_compile_steps']=[line for line in (RUN/'compile.log').read_text().splitlines() if 'Building CXX object ' in line]
assert len(record['actual_compile_steps'])==3
deps=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','deps'],env=env,text=True)
(RUN/'actual-dependencies.txt').write_text(deps)
expected={item['path']:item['sha256'] for item in product['product_inputs']}
used=set()
for line in deps.splitlines():
 name=line.strip()
 if '/include/hyle/' in name and name.startswith('/'):
  path=Path(name)
  assert path.is_relative_to(sdk/'include/hyle'),name
  relative='include/hyle/'+str(path.relative_to(sdk/'include/hyle'))
  assert hashlib.sha256(path.read_bytes()).hexdigest()==expected[relative],relative
  used.add(relative)
assert used,'actual HYLE installed header closure missing'
record['actual_installed_header_closure']=sorted(used)
save()

paths=[p/target for p in (build/'bin',build) if (p/target).is_file()];assert len(paths)==1
record['binary']={'path':str(paths[0]),'sha256':hashlib.sha256(paths[0].read_bytes()).hexdigest()};save()
run('oracle',[str(paths[0])])
assert hashlib.sha256(paths[0].read_bytes()).hexdigest()==record['binary']['sha256'];verify_sdk()
lines=(RUN/'oracle.log').read_text().splitlines()
assert sum(line.startswith('# ENCODED_PAGE_CORRECTNESS ') and 'replays=4 slots=2 readonly=PASS' in line for line in lines)==6
record['max_abs_error']=max(float(re.search(r'max_abs_error=([^ ]+)',line)[1]) for line in lines if line.startswith('# ENCODED_PAGE_CORRECTNESS '))
record.update(state='TERMINAL_PASS');save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
