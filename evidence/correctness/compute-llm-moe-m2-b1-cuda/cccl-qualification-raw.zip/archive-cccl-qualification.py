import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(r"C:\public\project-hyle\hyle")
work = root / ".scratch/validation/m2-b1-cuda"
out = root / "evidence/correctness/compute-llm-moe-m2-b1-cuda"
sdk = Path(r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\include\cccl")
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
raw = [work / name for name in ("cccl-probe.cu", "cccl-probe.ps1", "cccl-probe-build.cmd", "cccl-probe-build.log", "cccl-probe-run.log", "archive-cccl-qualification.py")]
raw.extend(sorted((work / "cccl-licenses").glob("*.txt")))
archive_path = out / "cccl-qualification-raw.zip"
with ZipFile(archive_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in raw:
        archive.write(path, path.relative_to(work).as_posix())
log = (work / "cccl-probe-run.log").read_text(encoding="utf-8-sig")
assert log.count("scan count=") == 8 and log.count("sort bytes=") == 12 and "qualification PASS" in log
sources = ["cub/version.cuh", "cub/device/device_scan.cuh", "cub/device/device_radix_sort.cuh", "cub/device/device_reduce.cuh", "cub/device/device_transform.cuh", "thrust/iterator/transform_iterator.h", "thrust/iterator/counting_iterator.h", "cuda/std/tuple"]
exe = Path(r"C:\hv\m2b1-cccl-probe\probe.exe")
receipt = {
    "kind": "Bounded original CCCL numerical/semantic qualification, not HYLE product or performance acceptance",
    "scope_checkpoint": subprocess.check_output(["git", "rev-parse", "c1923e1a"], cwd=root, text=True).strip(),
    "machine": "Windows RTX4070 SM89; MSVC19.50.35728, CUDA Toolkit13.3.73, CUB3.3.4 / 300304",
    "scan": {"verdict": "PASS", "cases": 8, "algorithm": "Original InclusiveSumByKey on widened I32, original Min/Max, scalar validation and original Transform projection",
             "coverage": "multiple rows, inclusive/exclusive, INT32_MIN/MAX, intermediate overflow and final total overflow, entire output sentinel unchanged on overflow"},
    "topk": {"verdict": "PASS", "cases": 12, "algorithm": "Original radix SortPairs custom decomposer of row/nan/directed-value, stable original index, original Transform extraction",
              "coverage": "F32 and I32; both directions, k=1/7/8, two rows, NaN signs/payloads, infinities, signed zero, ties, integer keys beyond 2^24; selected source bits unchanged"},
    "limits": ["No ordinary HYLE entry or resource/Completion/Graph acceptance yet", "No F16/BF16 qualification in raw probe", "No WSL, SDK delivery, sanitizer or P1", "No self-written math investigation, comparison, optimization or deletion"],
    "implementation_rule": "Only stock DeviceScan/DeviceRadixSort/DeviceReduce/DeviceTransform algorithms; scalar API projection functors specify public ordering/address/type semantics, no own global kernel or scan/sort loop",
    "archive": {"path": archive_path.name, "sha256": sha(archive_path), "bytes": archive_path.stat().st_size},
    "executable_sha256": sha(exe),
    "original_sdk_source_hashes": [{"path": source, "sha256": sha(sdk / source)} for source in sources],
    "licenses": {"source": "https://raw.githubusercontent.com/NVIDIA/cccl/v3.3.4/LICENSE",
                 "sha256": sha(work / "cccl-licenses/CCCL-LICENSE.txt"),
                 "terms": "CUB BSD-3, Thrust Apache-2.0 with Boost exceptions, libcu++ Apache-2.0 WITH LLVM-exception; original combined license preserved"},
    "shared_source_design_budget_minutes": {"used": 88, "remaining": 32, "total": 120},
    "new_complete_requirement_cells": 0, "performance_samples": 0,
}
(out / "cccl-qualification.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
registry_path = root / "docs/implementation/module-status.json"
registry = json.loads(registry_path.read_text(encoding="utf-8"))
for item in registry["modules"]:
    if item["module"] in {"compute_provider_cuda", "compute_route_cuda"}:
        assert item["state"] == "SCOPED"
        item["state"] = "AUDITED"
        item["summary"] = "M2-B1 CUDA-I AUDITED：原版CCCL Scan/TopK的I1–I4已冻结，原版8组扫描/12组稳定排序资格通过；接普通Direct/Graph与真实workspace/完成，尚无产品覆盖。与父卡共用预算，旧自研kernel全部冻结。"
registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"scan_cases": 8, "topk_cases": 12, "archive_bytes": archive_path.stat().st_size}))
