#include <cub/device/device_radix_sort.cuh>
#include <cub/device/device_reduce.cuh>
#include <cub/device/device_scan.cuh>
#include <cub/device/device_transform.cuh>
#include <cub/version.cuh>
#include <cuda/std/functional>
#include <cuda/std/tuple>
#include <thrust/iterator/counting_iterator.h>
#include <thrust/iterator/transform_iterator.h>

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <numeric>
#include <type_traits>
#include <vector>

void checked(cudaError_t status, const char *operation) {
  if (status != cudaSuccess) {
    std::fprintf(stderr, "%s: %s\n", operation, cudaGetErrorString(status));
    std::exit(2);
  }
}
#define CUDA_CHECK(call) checked((call), #call)
void require(bool value, const char *message) {
  if (!value) { std::fprintf(stderr, "FAIL: %s\n", message); std::exit(3); }
}
template <class T> struct Device {
  T *data = nullptr;
  explicit Device(std::size_t count) { CUDA_CHECK(cudaMalloc(&data, count * sizeof(T))); }
  ~Device() { cudaFree(data); }
};
struct Group {
  int width;
  __host__ __device__ int operator()(int i) const { return i / width; }
};
struct Widen {
  __host__ __device__ std::int64_t operator()(std::int32_t value) const { return value; }
};
struct PrefixOutput {
  const std::int64_t *prefix;
  int width;
  bool exclusive;
  __device__ std::int32_t operator()(int i) const {
    return exclusive ? (i % width == 0 ? 0 : static_cast<std::int32_t>(prefix[i - 1]))
                     : static_cast<std::int32_t>(prefix[i]);
  }
};

void scan_case(std::vector<std::int32_t> input, int width, bool exclusive,
               bool should_overflow) {
  const int count = static_cast<int>(input.size());
  Device<std::int32_t> source(count), output(count);
  Device<std::int64_t> prefix(count), bounds(2);
  CUDA_CHECK(cudaMemcpy(source.data, input.data(), input.size() * sizeof(input[0]), cudaMemcpyHostToDevice));
  CUDA_CHECK(cudaMemset(output.data, 0x5a, input.size() * sizeof(input[0])));
  const auto keys = thrust::make_transform_iterator(thrust::counting_iterator<int>(0), Group{width});
  const auto values = thrust::make_transform_iterator(source.data, Widen{});
  std::size_t scan_bytes = 0, min_bytes = 0, max_bytes = 0;
  CUDA_CHECK(cub::DeviceScan::InclusiveSumByKey(nullptr, scan_bytes, keys, values, prefix.data, count));
  CUDA_CHECK(cub::DeviceReduce::Min(nullptr, min_bytes, prefix.data, bounds.data, count));
  CUDA_CHECK(cub::DeviceReduce::Max(nullptr, max_bytes, prefix.data, bounds.data + 1, count));
  Device<std::byte> temporary(std::max({scan_bytes, min_bytes, max_bytes}));
  CUDA_CHECK(cub::DeviceScan::InclusiveSumByKey(temporary.data, scan_bytes, keys, values, prefix.data, count));
  CUDA_CHECK(cub::DeviceReduce::Min(temporary.data, min_bytes, prefix.data, bounds.data, count));
  CUDA_CHECK(cub::DeviceReduce::Max(temporary.data, max_bytes, prefix.data, bounds.data + 1, count));
  std::int64_t limits[2];
  CUDA_CHECK(cudaMemcpy(limits, bounds.data, sizeof(limits), cudaMemcpyDeviceToHost));
  const bool overflow = limits[0] < INT32_MIN || limits[1] > INT32_MAX;
  require(overflow == should_overflow, "all-prefix overflow verdict");
  if (!overflow)
    CUDA_CHECK(cub::DeviceTransform::Transform(thrust::counting_iterator<int>(0), output.data,
                                               count, PrefixOutput{prefix.data, width, exclusive}));
  std::vector<std::int32_t> actual(input.size());
  CUDA_CHECK(cudaMemcpy(actual.data(), output.data, actual.size() * sizeof(actual[0]), cudaMemcpyDeviceToHost));
  std::int64_t total = 0;
  for (int i = 0; i < count; ++i) {
    if (i % width == 0) total = 0;
    const auto before = total;
    total += input[i];
    if (overflow) require(actual[i] == 0x5a5a5a5a, "overflow leaves complete user output untouched");
    else require(actual[i] == (exclusive ? before : total), "segmented integer prefix");
  }
  std::printf("scan count=%d width=%d exclusive=%d overflow=%d PASS\n", count, width, exclusive, overflow);
}

template <class T> using Order = std::conditional_t<std::is_same_v<T, float>, float, std::int64_t>;
template <class T> struct Key { std::uint32_t row, nan; Order<T> value; };
template <class T> struct Decompose {
  __host__ __device__ auto operator()(Key<T> &key) const {
    return cuda::std::tie(key.row, key.nan, key.value);
  }
};
template <class T> struct Project {
  const T *input;
  int width;
  bool largest;
  __device__ Key<T> operator()(int index) const {
    const Order<T> value = input[index];
    bool nan = false;
    if constexpr (std::is_same_v<T, float>) nan = isnan(value);
    return {static_cast<std::uint32_t>(index / width), static_cast<std::uint32_t>(nan),
            nan ? Order<T>{0} : largest ? -value : value};
  }
};
template <class T> struct SelectedValue {
  const T *input;
  const int *indices;
  int width, k;
  __device__ T operator()(int i) const { return input[indices[(i / k) * width + i % k]]; }
};
struct SelectedIndex {
  const int *indices;
  int width, k;
  __device__ int operator()(int i) const { return indices[(i / k) * width + i % k] % width; }
};

template <class T> void sort_case(const std::vector<T> &input, int width, bool largest) {
  const int count = static_cast<int>(input.size());
  Device<T> source(count), result(count);
  Device<Key<T>> keys(count), ordered_keys(count);
  Device<int> indices(count), ordered_indices(count), selected_indices(count);
  CUDA_CHECK(cudaMemcpy(source.data, input.data(), input.size() * sizeof(T), cudaMemcpyHostToDevice));
  CUDA_CHECK(cub::DeviceTransform::Transform(thrust::counting_iterator<int>(0), keys.data,
                                             count, Project<T>{source.data, width, largest}));
  CUDA_CHECK(cub::DeviceTransform::Transform(thrust::counting_iterator<int>(0), indices.data,
                                             count, cuda::std::identity{}));
  std::size_t bytes = 0;
  CUDA_CHECK(cub::DeviceRadixSort::SortPairs(nullptr, bytes, keys.data, ordered_keys.data,
                                           indices.data, ordered_indices.data, count, Decompose<T>{}));
  Device<std::byte> temporary(bytes);
  CUDA_CHECK(cub::DeviceRadixSort::SortPairs(temporary.data, bytes, keys.data, ordered_keys.data,
                                           indices.data, ordered_indices.data, count, Decompose<T>{}));
  for (const int k : {1, width - 1, width}) {
    const int selected_count = count / width * k;
    CUDA_CHECK(cub::DeviceTransform::Transform(thrust::counting_iterator<int>(0), result.data,
                                               selected_count, SelectedValue<T>{source.data, ordered_indices.data, width, k}));
    CUDA_CHECK(cub::DeviceTransform::Transform(thrust::counting_iterator<int>(0), selected_indices.data,
                                               selected_count, SelectedIndex{ordered_indices.data, width, k}));
    std::vector<T> actual(selected_count);
    std::vector<int> actual_indices(selected_count);
    CUDA_CHECK(cudaMemcpy(actual.data(), result.data, actual.size() * sizeof(T), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(actual_indices.data(), selected_indices.data, actual_indices.size() * sizeof(int), cudaMemcpyDeviceToHost));
    for (int row = 0; row < count / width; ++row) {
      std::vector<int> order(width);
      std::iota(order.begin(), order.end(), 0);
      std::stable_sort(order.begin(), order.end(), [&](int left, int right) {
        const T a = input[row * width + left], b = input[row * width + right];
        if constexpr (std::is_same_v<T, float>) {
          if (std::isnan(a) != std::isnan(b)) return !std::isnan(a);
          if (std::isnan(a)) return false;
        }
        return largest ? a > b : a < b;
      });
      for (int i = 0; i < k; ++i) {
        require(actual_indices[row * k + i] == order[i], "stable index, NaN-last and tie order");
        require(std::memcmp(&actual[row * k + i], &input[row * width + order[i]], sizeof(T)) == 0,
                "selected source bits preserved");
      }
    }
    std::printf("sort bytes=%zu width=%d largest=%d k=%d PASS\n", sizeof(T), width, largest, k);
  }
}

int main() {
  std::printf("CUB_VERSION=%d\n", CUB_VERSION);
  CUDA_CHECK(cudaSetDevice(0));
  for (const bool exclusive : {false, true}) {
    scan_case({INT32_MAX, 0, -1, 1, -2, 1, -4, 2, 3}, 3, exclusive, false);
    scan_case({INT32_MAX, 1}, 2, exclusive, true);
    scan_case({INT32_MIN, -1}, 2, exclusive, true);
    scan_case({INT32_MAX, 1, -1}, 3, exclusive, true);
  }
  const float nan = std::bit_cast<float>(0x7fc00123U);
  const float negative_nan = std::bit_cast<float>(0xffc00456U);
  const float inf = std::numeric_limits<float>::infinity();
  const std::vector<float> floating{nan, +0.0F, -0.0F, 3, 3, -inf, inf, negative_nan,
                                   inf, -inf, -2, -2, -0.0F, +0.0F, negative_nan, nan};
  const std::vector<std::int32_t> integer{INT32_MAX, INT32_MIN, 16777216, 16777217, 0, -1, 0, 1,
                                         -2, -2, -1, INT32_MIN, INT32_MAX, 16777217, 16777216, 1};
  for (const bool largest : {false, true}) {
    sort_case(floating, 8, largest);
    sort_case(integer, 8, largest);
  }
  std::puts("CCCL original scan/sort qualification PASS; no product acceptance or performance claim");
}
