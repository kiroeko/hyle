import hashlib
import json
from pathlib import Path
import re
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"C:\public\project-hyle\hyle")
WORK = ROOT / ".scratch/validation/m2-b1-cuda"
OUT = ROOT / "evidence/correctness/compute-llm-moe-m2-b1-cuda"
BUILD = Path(r"C:\hv\m2b1-cuda")

def read(path):
    try:
        return path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        return path.read_text(encoding="gb18030")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()

def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

assert "100% tests passed out of 10" in read(WORK / "collectives-test-final.log")
counts = list(map(int, re.findall(r"\[  PASSED  \] (\d+) tests\.", read(WORK / "collectives-ctest-final.log"))))
assert counts == [50, 8, 24, 13, 5], counts
assert "100% tests passed out of 1" in read(WORK / "collectives-default-graph.log")
assert "[  PASSED  ] 24 tests." in read(WORK / "collectives-default-graph-ctest.log")
assert "56,172" in read(WORK / "collectives-loc.log")
assert "self-check: PASS" in read(WORK / "collectives-loc.log")
paths = git("diff", "--name-only", "59cc78fb", "--", "src", "include", "tests").splitlines()
frozen = git("diff", "--name-only", "59cc78fb", "--", "src/compute_provider_cuda/*_kernel.cu")
assert not frozen, frozen
assert "__global__" not in read(ROOT / "src/compute_provider_cuda/collectives.cu")
qualification = json.loads(read(OUT / "cccl-qualification.json"))
assert sha(OUT / qualification["archive"]["path"]) == qualification["archive"]["sha256"]
assert sha(ROOT / "src/compute_provider_cuda/CCCL-LICENSE.txt") == qualification["licenses"]["sha256"]
plan = json.loads(read(WORK / "collectives-final-plan.json"))
audit = json.loads(read(OUT / "source-audit.json"))
audit["source_design_budget_minutes"] = {"used": 96, "remaining": 24, "total": 120}
audit["remaining"] = [
    "ggml empty tensor and nonrepresentable high-rank/odd-byte-stride paths",
    "other storage types and checked index cast",
    "dynamic Gather/Scatter; CCCL Scan/TopK Windows development passed but full applicable acceptance remains",
    "Select/min/max, stable activation/gates, Boolean Softmax mask and LogSoftmax qualification",
    "cross-environment delivery, sanitizer and immutable-candidate performance gates",
]
audit["third_binding"] = {
    "audited_checkpoint": git("rev-parse", "59cc78fb"),
    "owner": ["compute_provider_cuda", "compute_route_cuda"],
    "operation": "Original CCCL checked Scan F32/I32 and stable TopK F32/F16/BF16/I32",
    "domain": "CUDA13.3 toolkit/runtime, CUB3.3.4, SM89; plain rank<=8, arbitrary axis/byte strides, dense outputs, count<=INT32_MAX, no alias",
    "algorithm": "Original InclusiveSumByKey with widened I32, Reduce Min/Max, stable RadixSort of row/NaN/directed score, Transform of values and indices",
    "projection": "Only scalar public semantic key/type/layout projection; no own scan/sort/reduce kernel or loop",
    "resources": "Caller-owned per-slot workspace; shared native stream, managed replay; I32 Scan returns two validation scalars and blocks host; output written only after validation",
    "execution_evidence": "collectives-windows.json",
    "card_verdict": "INCONCLUSIVE; Windows development pass does not close B1 or full applicable acceptance",
}
save(OUT / "source-audit.json", audit)

raw = sorted(p for p in WORK.glob("collectives-*") if p.is_file())
raw += [WORK / "archive-collectives.py", WORK / "cleanup-cccl-probe.ps1"]
archive_path = OUT / "collectives-windows-raw.zip"
with ZipFile(archive_path, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in raw:
        archive.write(path, path.name)
    archive.write(BUILD / "CMakeCache.txt", "CMakeCache.txt")

def gate(name, expected):
    path = WORK / name
    if not path.exists(): return "UNRUN"
    return "PASS" if expected in read(path) else "INCONCLUSIVE; inspect raw log"

receipt = {
    "kind": "M2-B1 CUDA-I product development checkpoint; no full model coverage or terminal card verdict",
    "baseline": git("rev-parse", "93b5095f"),
    "scope_checkpoint": git("rev-parse", "c1923e1a"),
    "audited_checkpoint": git("rev-parse", "59cc78fb"),
    "candidate": "WORKTREE; exact product/test hashes below; not immutable P1 candidate",
    "selector_candidate_tree": plan["candidate_tree"],
    "machine": "Windows RTX4070 SM89; MSVC19.50.35728; CUDA13.3.73 / CUB3.3.4; Ninja Release shared",
    "settings": {"cuda_architectures": "89-real", "werror": True, "cpu": False, "cuda": True,
                 "build_parallel": 2, "test_parallel": 1, "sanitizer": "off", "dlls_adjacent": True,
                 "error_mode": "0x8003", "uac_or_power_changes": False},
    "binding": audit["third_binding"],
    "windows_development": {"verdict": "PASS", "ctest_targets": 10, "header_targets": 5,
                            "gtest_executions": sum(counts), "cccl_and_existing_cuda_provider": 50,
                            "ordinary_direct": 8, "ordinary_graph": 24, "ggml_compute": 13, "ggml_graph": 5,
                            "post_default_option_test_change": "Only Graph factor repeated: 1/1 CTest and 24 GTests PASS; ordinary prepare_replay defaults proved"},
    "coverage": [
        "Scan F32/I32 axes, rank6/8, odd byte strides, broadcast stride, empty and 8193 columns; inclusive/exclusive, NaN/Inf, integer intermediate/final overflow",
        "TopK four scalar types; every axis; rank8, odd/broadcast strides, k1/full/7-of-8193, empty outer, stable ties and signed zero, NaN payload/Inf, I32 values beyond 2^24; exact value bits and indices",
        "Workspace missing/short and exact/partial alias reject before acceptance; external capture rejected and normal retry succeeds",
        "Every HYLE metadata allocation point in Context, Prepared, Invocation failed in turn with balanced rollback and retry; no native GPU OOM injection claim",
        "Warm native TopK behind real CUDA host gate: pending Completion retains Provider handles after close; caller workspace/payload/Queue remain alive by contract",
        "Ordinary Graph TopK->Scan two independent slots, changed inputs, old results and failure/fresh-slot recovery; default replay chooses commands",
    ],
    "preserved_failures": [
        {"log": "collectives-build.log", "cause": "Runtime asset registry requires locked source dependency; CCCL is installed system SDK", "fix": "Standard factor-owned install(FILES ... COMPONENT Hyle_Runtime); no new downloader or governance change"},
        {"log": "collectives-build-tests.log", "cause": "GoogleTest macro initializer-list comma", "fix": "Parenthesized expected expression"},
        {"log": "collectives-ctest.log", "cause": "New fixture constructed illegal 1-byte tensor base offset; old test expected five providers", "fix": "Typed base offset with odd strides retained; six provider identities asserted"},
        {"log": "collectives-ctest-c1.log", "cause": "New lifetime test freed borrowed caller workspace while its own CUDA host gate was blocked, so cuMemFree waited", "fix": "Preserve caller workspace by documented contract; release Provider handles and close before completion; final gate has no timeout"},
    ],
    "p0": ["Cold fixed preparation/workspace sizing; managed original dispatch, no HYLE hot provider search or timing",
           "O(N) Scan prefix plus native temp; I32 original min/max passes, 16-byte host summary and wait charged",
           "Fixed-width radix work with two key/index arrays plus native temp; all layout projections/value-index extraction charged",
           "No new runtime, stream, completion event, private thread, own global math kernel or self-written algorithm"],
    "selector": {"selection_verdict": plan["verdict"],
                 "selected_ids": [x["id"] for x in plan["selected_gates"]],
                 "skipped_count": len(plan["skipped_gates"]),
                 "skipped_reasons": "Full plan in raw archive", "aggregate_execution": "INCONCLUSIVE; delivery gates unrun"},
    "maintenance": {"docs": gate("collectives-docs.log", "documentation contract passed"),
                    "closure": gate("collectives-closure.log", "module closure contract passed"),
                    "loc_self_check": "PASS"},
    "remaining_unrun": ["WSL native GPU", "Air/Mini CUDA-OFF", "host sanitizers", "source/static/shared relocated consumer", "final candidate review", "immutable-candidate P1"],
    "all_21_b1_rows": "INCONCLUSIVE; unbound exact domains and unrun applicable gates remain",
    "new_complete_requirement_cells": 0,
    "frozen_math_changed_paths": [],
    "performance_samples": 0,
    "source_design_budget_minutes": {"used": 96, "remaining": 24, "total": 120},
    "loc": {"compute_graph_implementation": 56172, "files": 244, "excludes": "tests/vendor", "raw": "collectives-loc.log"},
    "cleanup": "Archived disposable CCCL probe build removed (1545395 bytes); reuse current CPU/CUDA builds only",
    "product_and_test_sha256": {path: sha(ROOT / path) for path in paths},
    "artifact_sha256": {name: sha(BUILD / "bin" / name) for name in ["hyle_compute_provider_cuda.dll", "hyle_compute_route_cuda.dll", "hyle_compute_provider_cuda_test.exe", "hyle_compute_route_cuda_test.exe", "hyle_graph_route_cuda_test.exe"]},
    "archive": {"path": archive_path.name, "sha256": sha(archive_path), "bytes": archive_path.stat().st_size},
}
save(OUT / "collectives-windows.json", receipt)
print(json.dumps({"windows": "PASS", "tests": counts, "archive_bytes": archive_path.stat().st_size,
                  "maintenance": receipt["maintenance"], "card": "INCONCLUSIVE"}))
