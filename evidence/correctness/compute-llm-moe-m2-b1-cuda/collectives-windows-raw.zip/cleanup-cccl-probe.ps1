$ErrorActionPreference = 'Stop'
$probeTarget = (Resolve-Path -LiteralPath 'C:\hv\m2b1-cccl-probe').Path
if ($probeTarget -ne 'C:\hv\m2b1-cccl-probe') { throw 'Unexpected resolved probe directory' }
if ((Get-Item -LiteralPath $probeTarget).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Probe directory is a link' }
$probeOwner = Get-Content -LiteralPath (Join-Path $probeTarget '.hyle-owner') -Raw
if ($probeOwner.Trim() -ne 'M2-B1 CUDA-I original CCCL probe; /root; disposable after archive') { throw 'Probe owner differs' }
$archivePath = 'C:\public\project-hyle\hyle\evidence\correctness\compute-llm-moe-m2-b1-cuda\cccl-qualification-raw.zip'
if (-not (Test-Path -LiteralPath $archivePath -PathType Leaf)) { throw 'Missing archived probe evidence' }
$probeFiles = @(Get-ChildItem -LiteralPath $probeTarget -Recurse -Force)
if ($probeFiles | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }) { throw 'Probe contains a link' }
$probeBytes = ($probeFiles | Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
Remove-Item -LiteralPath $probeTarget -Recurse -Force
Write-Output "Removed owned archived probe directory: $probeTarget; bytes=$probeBytes"
