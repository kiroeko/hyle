#!/bin/bash
set -euo pipefail
export PATH="/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:$PATH"
project=/Users/kiro/hyle
work=/Users/kiro/hyle-m2b1-apple
build="$work/build"
case "${1:-}" in
  Configure)
    "$project/scripts/hyle-unix.sh" /opt/homebrew/bin/cmake -S "$project" -B "$build" -G Ninja \
      -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=/Library/Developer/CommandLineTools/usr/bin/clang \
      -DCMAKE_CXX_COMPILER=/Library/Developer/CommandLineTools/usr/bin/clang++ \
      -DHYLE_DEV_FACTORS=graph_route_apple -DHYLE_BUILD_TESTS=ON -DHYLE_STATIC=OFF \
      -DHYLE_COMPUTE_APPLE=ON -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=OFF \
      -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_WERROR=ON \
      -DHYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
    ;;
  NativeLibrary)
    /opt/homebrew/bin/cmake --build "$build" --parallel 2 --target mlx
    ;;
  Build)
    /opt/homebrew/bin/cmake --build "$build" --parallel 2 \
      --target hyle_compute_route_apple_tests hyle_graph_route_apple_tests
    ;;
  Test)
    /opt/homebrew/bin/ctest --test-dir "$build" \
      -R '^hyle_(compute_route_apple|graph_route_apple).*_test$' --output-on-failure --parallel 1
    ;;
  *) exit 2 ;;
esac
