$ErrorActionPreference = 'Stop'
$appleRoot = 'C:\public\project-hyle\hyle'
$appleBuild = 'C:\hv\m2b1-apple-off'
$appleLogs = Join-Path $appleRoot '.scratch\validation\m2-b1-apple'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class M2b1AppleErrorMode {
  [DllImport("kernel32.dll")]
  public static extern uint SetErrorMode(uint mode);
}
'@
[void][M2b1AppleErrorMode]::SetErrorMode(0x8003)
New-Item -ItemType Directory -Force -Path $appleBuild | Out-Null
Set-Content -LiteralPath (Join-Path $appleBuild '.hyle-owner') -Value 'M2-B1 Apple OFF validation /root'
. (Join-Path $appleRoot 'scripts\hyle-windows.ps1') -Action Configure -Preset windows-ninja -Factor 'compute_route_apple,graph_route_apple' -BinaryDir $appleBuild -ExtraArgs @('-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_WERROR=ON','-DHYLE_STATIC=ON','-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=OFF') *> (Join-Path $appleLogs 'reduction-off-configure.log')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& ctest --test-dir $appleBuild -R '^hyle_(compute_route_apple|graph_route_apple)_header_self_contained_test$' --no-tests=error --output-on-failure --timeout 60 *> (Join-Path $appleLogs 'reduction-off-tests.log')
exit $LASTEXITCODE

