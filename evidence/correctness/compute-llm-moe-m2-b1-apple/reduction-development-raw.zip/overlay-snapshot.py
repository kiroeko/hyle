from pathlib import Path
import tarfile

# A complete Windows index archive, applied only to this disposable clone.
# Preserve timestamps of identical files so a test edit does not rebuild HYLE.
root = Path('/Users/kiro/hyle').resolve()
assert root == Path('/Users/kiro/hyle')
archive = Path('/Users/kiro/hyle-m2b1-apple/indexed-source.tar.gz')
changed = []
with tarfile.open(archive, 'r:gz') as source:
    for member in source:
        target = (root / member.name).resolve()
        assert target.is_relative_to(root) and '.git' not in target.relative_to(root).parts
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        assert member.isfile(), (member.name, member.type)
        data = source.extractfile(member).read()
        if not target.is_file() or target.read_bytes() != data:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            target.chmod(member.mode)
            changed.append(member.name)
print('Applied complete canonical snapshot; changed files:', changed)
