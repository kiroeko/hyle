import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/kiro/hyle')
work = Path('/Users/kiro/hyle-m2b1-apple')
mlx = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/mlx-1f8e74e3f12f-95caa530dd41')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*args): return subprocess.check_output(args, text=True).strip()
sources = [
    'src/compute_route_apple/apple_mature_reduction.cc',
    'src/compute_route_apple/apple_mature_reduction.h',
    'src/compute_route_apple/apple_mature_indexing.cc',
    'src/compute_route_apple/apple_mature_indexing.h',
    'src/compute_route_apple/apple_tensor.cc',
    'src/compute_route_apple/CMakeLists.txt',
    'tests/compute_route_apple/indexing_test.cc',
    'tests/compute_route_apple/reduction_test.cc',
    'tests/graph_route_apple/indexing_test.cc',
    'docs/user/apple-compute.md',
]
cache = (work / 'build/CMakeCache.txt').read_text()
facts = {
    'machine_model': run('/usr/sbin/sysctl', '-n', 'hw.model'),
    'os': run('/usr/bin/sw_vers'),
    'compiler': run('/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'),
    'source_checkout_commit': run('git', '-C', str(root), 'rev-parse', 'HEAD'),
    'canonical_validation_tree': run('git', '-C', str(root), 'write-tree'),
    'unstaged_changes': run('git', '-C', str(root), 'diff', '--name-only'),
    'source_sha256': {name: sha(root / name) for name in sources},
    'mlx_api_sha256': sha(mlx / 'mlx/primitives.h'),
    'artifact_sha256': {name: sha(work / 'build/bin' / name) for name in [
        'libhyle_compute_route_apple.dylib', 'libhyle_graph_route_apple.dylib',
        'libmlx.dylib', 'hyle_compute_route_apple_test', 'hyle_graph_route_apple_test']},
    'configuration': [line for line in cache.splitlines() if line.startswith((
        'CMAKE_BUILD_TYPE:', 'CMAKE_CXX_COMPILER:', 'HYLE_STATIC:', 'MLX_BUILD_CPU:',
        'MLX_BUILD_METAL:', 'MLX_BUILD_CUDA:', 'MLX_METAL_JIT:', 'HYLE_COMPUTE_APPLE:',
        'CMAKE_OSX_DEPLOYMENT_TARGET:', 'HYLE_WERROR:'))],
}
assert facts['canonical_validation_tree'] == '447aecf8313c730931d6b9a6fbacdb0fe13ac4d6'
assert facts['unstaged_changes'] == ''
(work / 'reduction-facts.json').write_text(json.dumps(facts, indent=2) + '\n')
print('Recorded', facts['machine_model'], facts['canonical_validation_tree'])

