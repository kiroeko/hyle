#include <mlx/array.h>
#include <mlx/compile.h>
#include <mlx/ops.h>
#include <mlx/transforms.h>
#include <algorithm>
#include <array>
#include <climits>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>

namespace mx = mlx::core;
mx::Stream stream() { return mx::default_stream(mx::Device::gpu); }
void require(bool ok, const char* reason) { if (!ok) throw std::runtime_error(reason); }
template<class T> std::vector<T> host(mx::array a) {
  a = mx::contiguous(a, false, stream()); mx::eval(a); mx::synchronize(stream());
  if (a.size() == 0) return {};
  return {a.data<T>(), a.data<T>() + a.size()};
}
std::vector<std::uint64_t> bits(mx::array a) {
  a = mx::contiguous(a, false, stream()); mx::eval(a); mx::synchronize(stream());
  std::vector<std::uint64_t> result(a.size(), 0);
  for (std::size_t i=0;i<result.size();++i)
    std::memcpy(&result[i], static_cast<const char*>(a.data<void>())+i*a.itemsize(), a.itemsize());
  return result;
}
mx::array storage(mx::Dtype type, int count, int phase) {
  if(type == mx::float32) {
    const std::array<std::uint32_t,8> pattern={0x7fc00001,0xffc01234,0x80000000,0,0x7f800000,0xff800000,0x3f000001,0xbf800000};
    std::vector<std::uint32_t> data(count);
    for(int i=0;i<count;++i) data[i]=pattern[(i+phase)%pattern.size()];
    return mx::view(mx::array(data.data(),{count},mx::uint32),type,stream());
  }
  if(type == mx::float16 || type == mx::bfloat16) {
    const auto pattern = type == mx::float16 ?
      std::array<std::uint16_t,8>{0x7e01,0xfe37,0x8000,0,0x7c00,0xfc00,0x3801,0xbc00} :
      std::array<std::uint16_t,8>{0x7fc1,0xffc3,0x8000,0,0x7f80,0xff80,0x3f01,0xbf80};
    std::vector<std::uint16_t> data(count);
    for(int i=0;i<count;++i) data[i]=pattern[(i+phase)%pattern.size()];
    return mx::view(mx::array(data.data(),{count},mx::uint16),type,stream());
  }
  if(type == mx::int64) {
    std::vector<std::int64_t> data(count);
    for(int i=0;i<count;++i) data[i] = (i+phase)%2 ? INT64_MIN+i+phase : INT64_MAX-i-phase;
    return mx::array(data.data(),{count},type);
  }
  std::vector<std::int32_t> data(count);
  for(int i=0;i<count;++i) data[i] = type == mx::bool_ ? (i+phase)%2 :
      ((i+phase)%2 ? INT32_MIN+i+phase : INT32_MAX-i-phase);
  return mx::astype(mx::array(data.data(),{count},mx::int32),type,stream());
}

std::vector<mx::array> assign_original(const std::vector<mx::array>& input) {
  auto s=stream(); const auto &base=input[0]; const auto &indices=input[1];
  const auto count=static_cast<int>(indices.size());
  if(base.size()==0) return {mx::zeros(base.shape(),base.dtype(),s),mx::array(0)};
  if(count==0) return {mx::copy(base,s),mx::array(0)};
  const auto extent=base.shape(1);
  auto ids=mx::reshape(indices,{count},s);
  auto bad=mx::logical_or(mx::less(ids,mx::array(0,ids.dtype()),s),
      mx::greater_equal(ids,mx::array(extent,ids.dtype()),s),s);
  auto safe=mx::where(bad,mx::array(0,ids.dtype()),ids,s);
  auto position=mx::arange(count,mx::int32,s);
  auto last=mx::scatter_max(mx::full({extent},mx::array(-1),mx::int32,s),safe,
      mx::reshape(position,{count,1},s),0,s);
  auto present=mx::greater_equal(last,mx::array(0),s);
  auto safe_last=mx::where(present,last,mx::array(0),s);
  auto update_shape=base.shape(); update_shape[1]=count;
  auto chosen=mx::take(mx::reshape(input[2],update_shape,s),safe_last,1,s);
  mx::Shape mask_shape(base.ndim(),1); mask_shape[1]=extent;
  auto mask=mx::reshape(present,mask_shape,s);
  auto type=base.dtype();
  auto native_bits=type==mx::float32?mx::uint32:
      type==mx::float16||type==mx::bfloat16?mx::uint16:type;
  auto output=mx::view(mx::where(mask,mx::view(chosen,native_bits,s),
      mx::view(base,native_bits,s),s),type,s);
  return {output,mx::where(mx::any(bad,s),mx::array(1),mx::array(0),s)};
}

int assign_cases() {
  int cases=0;
  for(auto type:{mx::float32,mx::float16,mx::bfloat16,mx::int32,mx::int64,mx::bool_})
    for(auto index_type:{mx::int32,mx::int64})
      for(auto shape:{mx::Shape{},mx::Shape{4},mx::Shape{2,2},mx::Shape{129}}) {
        auto fn=mx::compile(assign_original);
        const int count=shape.empty()?1:shape==mx::Shape{2,2}?4:shape[0];
        auto base=mx::transpose(mx::reshape(storage(type,42,0),{7,2,3},stream()),{1,0,2},stream());
        const auto original=bits(base);
        for(int phase=0;phase<5;++phase) {
          std::vector<std::int64_t> ids(count);
          for(int i=0;i<count;++i) ids[i]=(i*3+phase)%7;
          if(phase==1) ids.back()=-1;
          if(phase==2) ids.back()=7;
          if(phase==3) ids.back()=index_type==mx::int32?INT32_MAX:INT64_MAX;
          auto index=mx::astype(mx::array(ids.data(),shape,mx::int64),index_type,stream());
          if(shape==mx::Shape{2,2}) index=mx::transpose(index,{1,0},stream());
          ids=host<std::int64_t>(mx::astype(index,mx::int64,stream()));
          auto update=mx::transpose(mx::reshape(storage(type,count*6,phase+2),{count,2,3},stream()),{1,0,2},stream());
          mx::Shape update_shape={2}; update_shape.insert(update_shape.end(),shape.begin(),shape.end()); update_shape.push_back(3);
          update=mx::reshape(update,update_shape,stream());
          const auto update_bits=bits(update);
          auto output=fn({base,index,update});
          auto expected=original;
          bool invalid=false;
          for(int row=0;row<2;++row) for(int i=0;i<count;++i) {
            const bool bad=ids[i]<0 || ids[i]>=7; invalid|=bad;
            const auto id=bad?0:ids[i];
            for(int lane=0;lane<3;++lane)
              expected[(row*7+id)*3+lane]=update_bits[(row*count+i)*3+lane];
          }
          require(host<std::int32_t>(output[1])[0]==(invalid?1:0),"assign status differs");
          require(bits(output[0])==expected,"original max-map assignment storage differs");
          require(bits(base)==original,"base was modified");
          require(bits(update)==update_bits,"updates were modified");
          ++cases;
        }
      }
  for(bool empty_output:{false,true}) {
    auto fn=mx::compile(assign_original);
    auto base=mx::zeros({2,7,empty_output?0:3},mx::int64,stream());
    auto ids=empty_output?mx::array({-1,7}):mx::zeros({0},mx::int64,stream());
    auto update=mx::zeros({2,empty_output?2:0,empty_output?0:3},mx::int64,stream());
    auto output=fn({base,ids,update});
    require(bits(output[0])==bits(base),"empty assignment differs");
    require(host<std::int32_t>(output[1])[0]==0,"empty assignment read indices");
    ++cases;
  }
  return cases;
}

void add_contract_cases() {
  int matches=0;
  for(int count:{3,17,129,8193}) {
    std::vector<float> values(count);
    float expected=0;
    for(int i=0;i<count;++i) {
      values[i]=i%3==0?16777216.F:i%3==1?1.F:-16777216.F;
      expected+=values[i];
    }
    auto fn=mx::compile([](const std::vector<mx::array>& input) {
      return std::vector{mx::scatter_add(input[0],input[1],input[2],0,stream())};
    });
    auto output=fn({mx::array({0.F}),mx::zeros({count},mx::int32,stream()),
        mx::array(values.data(),{count,1},mx::float32)});
    const float actual=host<float>(output[0])[0]; matches+=actual==expected;
    std::cout<<"original scatter_add count="<<count<<" sequential="<<expected
             <<" observed="<<actual<<" match="<<(actual==expected)<<std::endl;
  }
  std::cout<<"scatter_add sequential matches "<<matches<<"/4; upstream unordered atomic updates do not qualify the ordered contract"<<std::endl;
}
int main() try {
  const auto count=assign_cases();
  std::cout<<"PASS "<<count<<" original MLX GPU max-map assignment cases; no HYLE math or timing"<<std::endl;
  add_contract_cases();
} catch(const std::exception& error) { std::cerr<<"FAIL "<<error.what()<<std::endl; return 1; }
