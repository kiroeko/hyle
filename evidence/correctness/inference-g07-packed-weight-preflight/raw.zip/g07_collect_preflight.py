from pathlib import Path
import hashlib,json,subprocess,sys
air=sys.platform=='darwin';route='apple' if air else 'cuda';base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified'/('g07-p1-'+route)
source=base/'source';build=base/'build';out=base/'logs';r=json.loads((out/'result.json').read_text());assert r['state']=='PASS_INDEPENDENT_NUMERICAL_PREFLIGHT_ONLY'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
proof=dict(state='PASS_INDEPENDENT_NUMERICAL_PREFLIGHT_ONLY',route=route,run=r,source_revision=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),benchmark_inputs=[dict(path=p,sha256=sha(source/'bench/inference_packed_weights'/p)) for p in ['CMakeLists.txt','packed_bench.cc','placement.cc','prepare_reference.py']],artifacts=[dict(path=str(build/'bin'/('g07_packed_'+v)),sha256=sha(build/'bin'/('g07_packed_'+v))) for v in ['primary','placement']],original_source=json.loads((build/'original669/source-provenance.json').read_text()),sdk_owner_artifact=('/Users/kiro' if air else '/root')+'/hyle-scratch/compute-unified/g07-sdk/'+route+'-static-1/relocated/lib/libhyle_'+('compute_route_apple' if air else 'compute_provider_torch_cuda')+'.a')
proof['sdk_owner_sha256']=sha(Path(proof['sdk_owner_artifact']));(out/'collected.json').write_text(json.dumps(proof,indent=2)+'\n');print(route,'preflight logs bound')
