from pathlib import Path
import hashlib,json,os,subprocess,sys,time
air=sys.platform=='darwin';base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified'
route='apple' if air else 'cuda';folder=base/('g07-p1-'+route);folder.mkdir(parents=True,exist_ok=True)
source=folder/'source';peer=folder/'original669';build=folder/'build';out=folder/'logs';out.mkdir(exist_ok=True)
canonical=base/'g04-vulkan-encoded-p1-source-1' if air else Path('/mnt/c/public/project-hyle/hyle')
rev=sys.argv[1];env=dict(os.environ);env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
previous=json.loads((out/'result.json').read_text()) if (out/'result.json').exists() else None
r=dict(state='RUNNING',route=route,revision=rev,stages=[]);started=time.monotonic()-(previous['elapsed_seconds'] if previous else 0)
if previous:
 assert previous['state']=='FAIL';r['prior_failed_run']=previous
 archive=out/('prior-'+str(len(list(out.glob('prior-*')))+1));archive.mkdir()
 for p in list(out.iterdir()):
  if p.is_file():p.rename(archive/p.name)
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2))
def run(name,cmd,extra=None):
 e=dict(env);e.update(extra or {});print(route,name,flush=True)
 with (out/(name+'.log')).open('w') as f:p=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,text=True)
 r['stages'].append(dict(stage=name,command=cmd,exit_code=p.returncode));save()
 if p.returncode:raise RuntimeError(name+' failed')
def clone(path,revision,patterns):
 if not path.exists():
  subprocess.run(['git','clone','--shared','--no-checkout',str(canonical),str(path)],check=True,stdout=subprocess.DEVNULL)
  subprocess.run(['git','-C',str(path),'config','core.autocrlf','false'],check=True)
 if air:
  # The historical mirror has a long legitimate shared-clone chain. List all
  # real object stores directly so this new disposable clone adds no depth.
  pending=[canonical/'.git/objects'];stores=[]
  while pending:
   store=pending.pop(0).resolve()
   if store in stores:continue
   assert store.is_dir();stores.append(store);f=store/'info/alternates'
   if f.is_file():pending.extend((Path(x) if Path(x).is_absolute() else store/x) for x in f.read_text().splitlines())
  (path/'.git/objects/info/alternates').write_text(''.join(str(x)+'\n' for x in stores))
  r.setdefault('flattened_object_stores',{})[str(path)]=[str(x) for x in stores]
 subprocess.run(['git','-C',str(path),'sparse-checkout','set',*patterns],check=True)
 subprocess.run(['git','-C',str(path),'checkout','--detach',revision],check=True,stdout=subprocess.DEVNULL)
 assert not subprocess.check_output(['git','-C',str(path),'status','--porcelain'],text=True).strip()
try:
 if air:
  r['model']=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip();assert r['model']=='Mac16,12'
  run('fetch-bundle',['git','-C',str(canonical),'fetch',str(base/'g07-p1.bundle'),'HEAD'])
 clone(source,rev,['bench','scripts','include','src/compute','src/compute_backend_cuda','src/compute_route_apple','third_party/nanobench','third_party/awq_cuda','third_party/bitsandbytes_cuda','third_party/compressed_tensors_cuda','evidence/architecture/inference-g07-packed-weight-audit','evidence/delivery/inference-g07-packed-weights'])
 clone(peer,'669121418669b31f6849c74f64362aaf8d6eb919',['src/compute_provider_torch_cuda','src/compute_route_apple','third_party/mlx_cuda_quant'])
 prefix=base/'g07-sdk'/('apple-static-1' if air else 'cuda-static-1')/'relocated'
 args=['cmake','-S',str(source/'bench/inference_packed_weights'),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER='+('clang++' if air else 'g++-14'),'-DCMAKE_C_COMPILER='+('clang' if air else 'gcc-14'),'-DHYLE_G07_ROUTE='+route,'-DHYLE_G07_REFERENCE_SOURCE='+str(peer),'-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_INTERPROCEDURAL_OPTIMIZATION=OFF']
 if air:args+=['-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4']
 else:args+=['-DCUDAToolkit_ROOT=/usr/local/cuda-13.3']
 run('configure',args);run('build',['cmake','--build',str(build),'--parallel','2' if not air else '4'])
 for variant in ['primary','placement']:
  run('verify-'+variant,[str(build/'bin'/('g07_packed_'+variant))],{'HYLE_BENCH_VERIFY_ONLY':'1'})
 r['state']='PASS_INDEPENDENT_NUMERICAL_PREFLIGHT_ONLY';save();print(r['state'],flush=True)
except Exception as e:r['state']='FAIL';r['error']=repr(e);save();raise
