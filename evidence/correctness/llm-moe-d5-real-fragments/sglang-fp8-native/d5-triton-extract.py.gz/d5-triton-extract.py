from pathlib import Path
import ast
import hashlib
import json
import subprocess

out = Path('.scratch/validation/d5-sglang-fp8-aot')
out.mkdir(parents=True, exist_ok=True)
pin = '06992c92ad4494fe9f9636e75be3e35040512447'
path = 'python/sglang/kernels/ops/quantization/fp8_kernel.py'
raw = subprocess.check_output(['git', '-C', 'C:/public/project-hyle/sglang', 'show', pin + ':' + path])
source = raw.decode('utf-8')
lines = source.splitlines(keepends=True)
names = {'_per_token_group_quant_8bit', '_w8a8_block_fp8_matmul'}
fragments = []
identity = []
for node in ast.parse(source).body:
    if isinstance(node, ast.FunctionDef) and node.name in names:
        start = min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1
        body = ''.join(lines[start:node.end_lineno])
        fragments.append(body)
        identity.append({'function': node.name, 'lines': [start+1, node.end_lineno],
                         'sha256': hashlib.sha256(body.encode()).hexdigest()})
assert len(fragments) == 2
target = out / 'original_kernels.py'
target.write_text('# Original SGLang functions, Apache-2.0; no math edits.\nimport triton\nimport triton.language as tl\n\n' + '\n\n'.join(fragments), encoding='utf-8', newline='\n')
(out / 'source.json').write_text(json.dumps({'repository': 'https://github.com/sgl-project/sglang',
    'revision': pin, 'path': path, 'source_sha256': hashlib.sha256(raw).hexdigest(), 'functions': identity,
    'module_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}, indent=2) + '\n')
print(identity)
