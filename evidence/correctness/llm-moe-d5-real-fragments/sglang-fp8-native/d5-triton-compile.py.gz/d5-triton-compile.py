from pathlib import Path
import importlib.util
import json
import os
import sys
import time

root = Path('/mnt/c/public/project-hyle/hyle')
package = root / '.scratch/tools/d5-triton/unpacked'
sys.path.insert(0, str(package))
out = root / '.scratch/validation/d5-sglang-fp8-aot'
os.environ['TRITON_CACHE_DIR'] = str(out / 'compiler-cache')
import triton
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource

spec = importlib.util.spec_from_file_location('original_kernels', out / 'original_kernels.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
target = GPUTarget('cuda', 89, 32)
jobs = [
    ('quantize', module._per_token_group_quant_8bit,
     {'y_ptr': '*fp32', 'y_q_ptr': '*fp8e4nv', 'y_s_ptr': '*fp32',
      'y_stride': 'i32', 'N': 'i32', 'eps': 'fp32', 'bit8_min': 'fp32', 'bit8_max': 'fp32'},
     {'BLOCK': 128}, {'num_warps': 4, 'num_stages': 1}),
    ('matmul', module._w8a8_block_fp8_matmul,
     {'A':'*fp8e4nv', 'B':'*fp8e4nv', 'C':'*fp32', 'As':'*fp32', 'Bs':'*fp32',
      **{x:'i32' for x in ['M','N','K','stride_am','stride_ak','stride_bk','stride_bn',
                          'stride_cm','stride_cn','stride_As_m','stride_As_k','stride_Bs_k','stride_Bs_n']}},
     {'group_n':128, 'group_k':128, 'BLOCK_SIZE_M':64, 'BLOCK_SIZE_N':128,
      'BLOCK_SIZE_K':128, 'GROUP_SIZE_M':32, 'needs_masking':False},
     {'num_warps':4, 'num_stages':3}),
]
receipt = {'compiler': triton.__version__, 'target': target.__dict__, 'kernels': []}
for label, function, signature, constants, options in jobs:
    start = time.monotonic()
    compiled = triton.compile(ASTSource(fn=function, signature=signature, constexprs=constants),
                              target=target, options=options)
    for extension in ['cubin','ptx','ttir']:
        value = compiled.asm[extension]
        (out / (label + '.' + extension)).write_bytes(value if isinstance(value, bytes) else value.encode())
    metadata = compiled.metadata._asdict()
    metadata['target'] = metadata['target'].__dict__
    receipt['kernels'].append({'label':label, 'signature':signature, 'constexprs':constants,
        'options':options, 'metadata':metadata, 'seconds':time.monotonic()-start})
    (out / 'compilation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(label, metadata['name'], 'shared', metadata['shared'], flush=True)
