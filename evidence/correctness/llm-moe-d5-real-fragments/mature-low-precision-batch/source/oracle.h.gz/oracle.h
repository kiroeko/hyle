#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
namespace oracle {
inline uint32_t bits(float x){return std::bit_cast<uint32_t>(x);}
inline float bf(float x){auto b=bits(x);if((b&0x7f800000u)==0x7f800000u)return x;b+=0x7fff+((b>>16)&1);return std::bit_cast<float>(b&0xffff0000u);}
inline float value(unsigned code,bool fp4){
 float a=0;
 if(fp4){constexpr std::array<float,8> t{0,.5f,1,1.5f,2,3,4,6};a=t[code&7];}
 else {unsigned e=(code>>3)&15,m=code&7;a=e?std::ldexp(1.f+float(m)/8,int(e)-7):std::ldexp(float(m),-9);}
 return std::copysign(a,(code&(fp4?8:128))?-1.f:1.f);
}
inline unsigned nearest(float x,bool fp4){
 unsigned best=0;double d=INFINITY;
 for(unsigned i=0;i<(fp4?8u:127u);++i){double n=std::abs(double(std::abs(x))-double(value(i,fp4)));if(n<d||(n==d&&!(i&1))){best=i;d=n;}}
 return best|(std::signbit(x)?(fp4?8u:128u):0u);
}
inline std::vector<float> roundtrip(const std::vector<float>& input,bool fp4,unsigned group){
 std::vector<float> out(input.size());const float cap=fp4?6.f:448.f;
 for(size_t base=0;base<input.size();base+=group){
  float maximum=fp4?6*std::ldexp(1.f,-126):1e-4f;
  for(unsigned i=0;i<group;++i)maximum=std::max(maximum,std::abs(input[base+i]));
  const float scaled=maximum*(1.f/cap);
  const float scale=float(std::exp2(std::ceil(std::log2(double(scaled)))));
  for(unsigned i=0;i<group;++i){auto x=std::clamp(input[base+i]/scale,-cap,cap);out[base+i]=bf(value(nearest(x,fp4),fp4)*scale);}
 }
 return out;
}
inline std::vector<float> hadamard(std::vector<float> x,bool store_bf16){
 for(size_t base=0;base<x.size();base+=128){
  for(unsigned span=1;span<128;span*=2)for(unsigned i=0;i<128;i+=2*span)for(unsigned j=0;j<span;++j){
   const float a=x[base+i+j],b=x[base+i+j+span];x[base+i+j]=a+b;x[base+i+j+span]=a-b;
  }
  for(unsigned i=0;i<128;++i){x[base+i]*=0.08838834764831845f;if(store_bf16)x[base+i]=bf(x[base+i]);}
 }
 return x;
}
inline std::vector<float> finite_bf(){std::vector<float> x;for(unsigned i=0;i<65536;++i)if((i&0x7f80)!=0x7f80)x.push_back(std::bit_cast<float>(i<<16));return x;}
inline std::vector<float> ordinary(){std::vector<float>x(128*256);for(size_t i=0;i<x.size();++i)x[i]=bf(std::sin(float(i+17)*.13f)*float(1+i%19)/7);return x;}
inline std::vector<float> tiny(){std::vector<float>x;for(int e:{-127,-126,-125,-124,-120,-100,-20,0,10})for(unsigned r=0;r<8;++r)for(unsigned i=0;i<128;++i)x.push_back(bf(std::ldexp(float(int((i+r)%7)-3),e)));return x;}
inline unsigned compare(const char* candidate,const char* domain,const std::vector<float>& got,const std::vector<float>& expected){
 unsigned bad=0,zero_bits=0;for(size_t i=0;i<got.size();++i){const float g=bf(got[i]),e=expected[i];
  if(g!=e){if(bad<3)std::printf("mismatch %s %s index=%zu got_bits=%08x expected_bits=%08x\n",candidate,domain,i,bits(g),bits(e));++bad;}
  else if(bits(g)!=bits(e))++zero_bits;
 }
 std::printf("result %s %s count=%zu mismatch=%u equal_value_bit_difference=%u\n",candidate,domain,got.size(),bad,zero_bits);return bad;
}
inline void write(const char* name,const std::vector<float>& x){std::ofstream f(name,std::ios::binary);f.write(reinterpret_cast<const char*>(x.data()),std::streamsize(x.size()*4));if(!f)throw std::runtime_error(name);}
inline std::vector<float> read(const char* name){std::ifstream f(name,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error(name);auto bytes=f.tellg();f.seekg(0);std::vector<float>x(size_t(bytes)/4);f.read(reinterpret_cast<char*>(x.data()),bytes);if(!f)throw std::runtime_error(name);return x;}
}
