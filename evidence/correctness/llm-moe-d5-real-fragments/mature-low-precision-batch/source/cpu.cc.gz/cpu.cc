#include "oracle.h"
#include "ds4_cpu.inc"
#include <c10/util/Float8_e4m3fn.h>
int main(){
 unsigned bad=0,cases=0;
 auto check=[&](float x){x=std::clamp(x,-448.f,448.f);auto expected=oracle::nearest(x,false);auto got=c10::detail::fp8e4m3fn_from_fp32_value(x);if(got!=expected){if(bad<3)std::printf("c10 mismatch input=%08x got=%u expected=%u\n",oracle::bits(x),unsigned(got),expected);++bad;}++cases;};
 for(float x:oracle::finite_bf())check(x);
 for(unsigned i=0;i<126;++i)for(int sign:{-1,1}){float mid=float(sign)*(oracle::value(i,false)+oracle::value(i+1,false))*.5f;for(float x:{std::nextafter(mid,-INFINITY),mid,std::nextafter(mid,INFINITY)})check(x);}
 for(unsigned i=0;i<256;++i)if((i&127)!=127){float got=c10::detail::fp8e4m3fn_to_fp32_value(uint8_t(i)),expected=oracle::value(i,false);bad+=oracle::bits(got)!=oracle::bits(expected);++cases;}
 std::printf("result c10 direct_e4m3 count=%u mismatch=%u\n",cases,bad);
 for(const auto& domain:std::array<std::pair<const char*,std::vector<float>>,3>{{{"all_finite_bf16",oracle::finite_bf()},{"ordinary",oracle::ordinary()},{"tiny_and_scale",oracle::tiny()}}}){
  for(bool fp4:{false,true}){auto got=domain.second;auto expected=oracle::roundtrip(got,fp4,fp4?32:64);if(fp4)dsv4_fp4_act_quantize_row_inplace_cpu(got.data(),uint32_t(got.size()));else dsv4_fp8_kv_quantize_row_inplace_cpu(got.data(),uint32_t(got.size()),0);oracle::compare(fp4?"ds4_fp4":"ds4_fp8",domain.first,got,expected);}
  const std::string name=std::string(domain.first)+".bin";oracle::write(name.c_str(),domain.second);
 }
 return 0; // Numeric qualification is in the explicit per-candidate records.
}
