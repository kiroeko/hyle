from pathlib import Path
import os
import sys

assert sys.argv[1:] == ['cuda']
os.environ['GTEST_FILTER'] = ':'.join([
    'ComputeOpsLowPrecision.*', 'SglangFp8.*',
    '*MoeFragments.D5OfficialFp8DenseNativeBatch',
    'CudaKernels.PendingCompletionRetainsProgramAndSlotAfterClose',
    'CudaKernels.ColdMetadataFailuresRollbackAndReplayUsesReservedState'])
source = Path('.scratch/d5-kimi-owner-windows.py').read_text(encoding='utf-8')
source = source.replace('d5-kimi-owner', 'd5-f37-native-entry')
source = source.replace("['compute_provider_ggml_cuda', 'graph_provider_ggml_cuda', 'compute_route_cuda', 'graph_route_cuda']",
    "['compute_ops', 'compute_provider_cuda', 'compute_route_cuda', 'graph_route_cuda']")
source = source.replace("'steps': []}", "'steps': [], 'test_filter': os.environ['GTEST_FILTER']}")
exec(compile(source, str(Path(__file__)), 'exec'))
