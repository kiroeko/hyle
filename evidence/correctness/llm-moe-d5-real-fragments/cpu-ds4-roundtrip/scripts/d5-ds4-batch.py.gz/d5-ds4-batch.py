import ctypes
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd().resolve()
out = root / '.scratch/validation/d5-ds4-binding/windows-qualified'
out.mkdir(parents=True, exist_ok=True)
build = root / '.scratch/build-compute-v2-dev'
flags = {'creationflags': subprocess.CREATE_NO_WINDOW}
ctypes.windll.kernel32.SetErrorMode(1 | 2 | 0x8000)
env = dict(os.environ, VSLANG='1033')
vs = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/Common7/Tools/VsDevCmd.bat')
batch = out / 'environment.cmd'
batch.write_text(f'@echo off\ncall "{vs}" -no_logo -arch=x64\nif errorlevel 1 exit /b 1\nset VSLANG=1033\nset\n')
result = subprocess.run(['cmd', '/d', '/c', str(batch)], capture_output=True, text=True, env=env, **flags)
result.check_returncode()
for line in result.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key,value=line.split('=',1)
        env[key]=value
env['HYLE_D5_QWEN35_FIXTURE'] = str(root / '.scratch/d5-qwen35-six-profile-fixture')
candidate = subprocess.check_output(['git','rev-parse','HEAD'], text=True, **flags).strip()
assert not subprocess.check_output(['git','status','--porcelain'], **flags).strip()
receipt = {'candidate':candidate,'steps':[],'scope':'CPU native owner and ordinary Direct/Graph, partial official profile; no P1 verdict'}

def run(label,args):
    start=time.monotonic()
    with (out/(label+'.log')).open('w',encoding='utf-8') as log:
        result = subprocess.run(list(map(str,args)),env=env,stdout=log,stderr=subprocess.STDOUT,**flags)
    step={'label':label,'argv':list(map(str,args)),'returncode':result.returncode,'seconds':round(time.monotonic()-start,3)}
    receipt['steps'].append(step)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,result.returncode,step['seconds'],flush=True)
    if result.returncode:
        print((out/(label+'.log')).read_text(encoding='utf-8',errors='replace')[-12000:],flush=True)
        raise SystemExit(result.returncode)

# The validated CMake configuration is unchanged by the optional-value adapter fix.
factors=['compute_provider_native','compute_route_cpu','graph_route_cpu']
run('build',['cmake','--build',build,'--target',*['hyle_'+f+'_tests' for f in factors],'-j','2'])
env['GTEST_FILTER']='CpuDs4Roundtrip.*'
run('tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-R','^hyle_(compute|graph)_route_cpu_test$','-j','1','--output-junit',out/'tests.xml'])
(out/'native-tests.log').write_bytes((build/'Testing/Temporary/LastTest.log').read_bytes())
print('CPU owner and ordinary-entry batch finished.',flush=True)
