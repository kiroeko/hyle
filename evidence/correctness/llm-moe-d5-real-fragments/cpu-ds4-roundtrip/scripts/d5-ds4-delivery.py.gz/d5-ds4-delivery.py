"""Reuse D5 CPU producers; verify only this new partial capability's three deliveries."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

repo=Path.cwd().resolve()
stage=sys.argv[1]
assert stage in ('source','static','shared','prepare')
root=Path('C:/hv/d5cp').resolve()
source=Path('C:/hv/d5cd/source-tree').resolve()
consumer=root/'consumer'
out=repo/'.scratch/validation/d5-ds4-binding-recovery'/('delivery-'+stage)
out.mkdir(parents=True,exist_ok=True)
flags={'creationflags':subprocess.CREATE_NO_WINDOW}
ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
env=dict(os.environ,VSLANG='1033')
batch=out/'env.cmd'
batch.write_text('@echo off\ncall "C:/Program Files/Microsoft Visual Studio/18/Enterprise/Common7/Tools/VsDevCmd.bat" -no_logo -arch=x64\nif errorlevel 1 exit /b 1\nset VSLANG=1033\nset\n')
r=subprocess.run(['cmd','/d','/c',str(batch)],capture_output=True,text=True,env=env,**flags);r.check_returncode()
for line in r.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1);env[key]=value
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True,**flags).strip()
assert not subprocess.check_output(['git','status','--porcelain'],**flags).strip()
receipt={'candidate':candidate,'stage':stage,'steps':[],'scope':'ds4 CPU roundtrip, Direct/Graph; not full official model or P1'}
def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(name,args,runtime_env=None):
 args=list(map(str,args));start=time.monotonic()
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:
  r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=runtime_env or env,**flags)
 receipt['steps'].append({'name':name,'argv':args,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)});save()
 print(stage,name,r.returncode,receipt['steps'][-1]['seconds'],flush=True)
 if r.returncode:
  print((out/(name+'.log')).read_text(encoding='utf-8',errors='replace')[-10000:],flush=True);raise SystemExit(r.returncode)

if stage=='prepare':
 paths=['include','src','cmake','third_party','CMakeLists.txt','LICENSE','README.md','SOURCE-MANIFEST.txt','scripts']
 archive=out/'product.tar'
 run('archive',['git','archive','--format=tar','--output='+str(archive),candidate,'--',*paths])
 assert source==Path('C:/hv/d5cd/source-tree').resolve() and source.is_dir()
 written=0
 with tarfile.open(archive) as bundle:
  for member in bundle:
   if not member.isfile():continue
   destination=(source/member.name).resolve();assert destination.is_relative_to(source)
   data=bundle.extractfile(member).read()
   if not destination.exists() or destination.read_bytes()!=data:
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data);written+=1
 # Only obsolete files previously tracked in this explicitly named disposable source tree.
 deleted=subprocess.check_output(['git','diff','--name-only','--diff-filter=D','9273bc71017a1febb69db240b6ea8970b88dd77c',candidate,'--',*paths],text=True,**flags)
 for name in deleted.splitlines():
  target=(source/name).resolve();assert target.is_relative_to(source)
  if target.is_file():target.unlink()
 listing=subprocess.check_output(['git','ls-tree','-r',candidate,'--',*paths],text=True,**flags)
 verified={}
 for line in listing.splitlines():
  meta,name=line.split('\t',1);mode,kind,oid=meta.split()
  assert kind=='blob' and mode in ('100644','100755')
  data=(source/name).read_bytes()
  if name!='SOURCE-MANIFEST.txt':assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,name
  verified[name]=hashlib.sha256(data).hexdigest()
 (out/'source-identity.json').write_text(json.dumps({'candidate':candidate,'source':str(source),'sha256':verified},indent=2)+'\n')
 copied={};todo=[repo/'tests/compute_route_cpu/ds4_roundtrip_test.cc']
 while todo:
  path=todo.pop().resolve();relative=path.relative_to(repo).as_posix()
  if relative in copied:continue
  assert relative.startswith('tests/')
  data=path.read_bytes();destination=consumer/relative;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
  copied[relative]=hashlib.sha256(data).hexdigest()
  for name in re.findall(rb'^\s*#include\s+"([^"]+)"',data,re.M):
   if not name.startswith(b'hyle/'):todo.append(path.parent/name.decode())
 cmake=(repo/'evidence/correctness/llm-moe-d5-real-fragments/cpu-delivery/consumer/CMakeLists.txt').read_text()
 for target in ('direct','graph'):
  cmake,count=re.subn(r'add_executable\(d5_cpu_'+target+r'\s+[^)]+\)', 'add_executable(d5_cpu_'+target+' tests/compute_route_cpu/ds4_roundtrip_test.cc)',cmake);assert count==1
 cmake=cmake.replace('target_link_libraries(d5_cpu_graph PRIVATE hyle::graph)','target_link_libraries(d5_cpu_graph PRIVATE hyle::graph)\ntarget_compile_definitions(d5_cpu_graph PRIVATE HYLE_TEST_GRAPH_ROUTE_CPU=1)')
 cmake,count=re.subn(r'"--gtest_filter=[^"]+"','"--gtest_filter=CpuDs4Roundtrip.*"',cmake);assert count==1
 (consumer/'CMakeLists.txt').write_text(cmake)
 copied['CMakeLists.txt']=hashlib.sha256((consumer/'CMakeLists.txt').read_bytes()).hexdigest()
 (out/'consumer-inputs.json').write_text(json.dumps(copied,indent=2)+'\n')
 receipt.update(changed_source_files=written,verified_source_files=len(verified),archive_bytes=archive.stat().st_size);save()
 print('Prepared immutable source and both external consumers',written,len(verified),flush=True)
 raise SystemExit(0)

cache=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources')
dep_args=['-DD5_GGML_SOURCE='+str(cache/'ggml-456172ec733a-41b7e10fd424'),'-DD5_GTEST_SOURCE='+str(cache/'googletest-063de7e9578f-162765170ae6')]
common=['-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
prefix=root/('ds4-'+stage+'-relocated')
staging=root/('ds4-'+stage+'-staging')
producer=root/'source-build'
if stage=='source':
 prior=json.loads((repo/'.scratch/validation/d5-ds4-binding/delivery-source/receipt.json').read_text())
 assert all(step['returncode']==0 for step in prior['steps']) and prior['steps'][-1]['name']=='build'
 assert not subprocess.check_output(['git','diff','--name-only',prior['candidate'],candidate,'--','include','src','cmake','third_party','CMakeLists.txt','tests/compute_route_cpu/ds4_roundtrip_test.cc'],**flags).strip()
 identity=json.loads((repo/'.scratch/validation/d5-ds4-binding/delivery-prepare/source-identity.json').read_text())
 for name,sha in identity['sha256'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==sha,name
 inputs=json.loads((repo/'.scratch/validation/d5-ds4-binding/delivery-prepare/consumer-inputs.json').read_text())
 for name,sha in inputs.items():assert hashlib.sha256((consumer/name).read_bytes()).hexdigest()==sha,name
 receipt['reused_source_build']={'candidate':prior['candidate'],'receipt':str(repo/'.scratch/validation/d5-ds4-binding/delivery-source/receipt.json'),'source_files':len(identity['sha256']),'consumer_files':len(inputs)}
 (root/'ds4-source-candidate.txt').write_text(candidate+'\n');build=producer
else:
 if stage=='shared':
  producer=repo/'.scratch/build-compute-v2-dev'
  run('producer-configure',['cmake','-S',repo,'-B',producer,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC=OFF','-DCMAKE_INSTALL_PREFIX='+str(staging)])
  run('producer-build',['cmake','--build',producer,'-j','2'])
 else:assert (root/'ds4-source-candidate.txt').read_text().strip()==candidate
 assert not prefix.exists() and not staging.exists()
 run('install',['cmake','--install',producer,'--prefix',staging])
 assert staging.resolve().is_relative_to(root) and prefix.resolve().is_relative_to(root)
 staging.rename(prefix)
 license_path=prefix/'share/licenses/Hyle/ds4-quantization-LICENSE'
 assert license_path.read_bytes()==(repo/'third_party/ds4_quantization/LICENSE').read_bytes()
 build=root/('ds4-'+stage+'-consumer')
 run('consumer-configure',['cmake','-S',consumer,'-B',build,*common,*dep_args,'-DCMAKE_PREFIX_PATH='+str(prefix)])
 run('consumer-build',['cmake','--build',build,'--target','d5_cpu_delivery','-j','2'])
 commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','d5_cpu_delivery'],env=env,**flags)
 (out/'compile-link-commands.log').write_bytes(commands)
 for forbidden in (str(repo/'include'),str(repo/'src'),str(producer),str(source)):
  assert forbidden.replace('\\','/').lower() not in commands.decode().replace('\\','/').lower(),forbidden
 dlls={}
 for dll in build.glob('*.dll'):
  matches=list(prefix.rglob(dll.name));assert len(matches)==1
  data=dll.read_bytes();assert data==matches[0].read_bytes()
  dlls[dll.name]={'sha256':hashlib.sha256(data).hexdigest(),'sdk':str(matches[0].relative_to(prefix))}
 (out/'dll-origins.json').write_text(json.dumps(dlls,indent=2)+'\n')
system_root=os.environ['SystemRoot']
runtime_env=dict(env);runtime_env['PATH']=os.pathsep.join([system_root+'/System32',system_root]);runtime_env.pop('GTEST_FILTER',None)
run('tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-j','1','--output-junit',out/'tests.xml'],runtime_env)
native=(build/'Testing/Temporary/LastTest.log').read_bytes();(out/'native-tests.log').write_bytes(native)
passed=sum(map(int,re.findall(rb'\[  PASSED  \]\s+(\d+) tests?\.',native)))
assert b'[  SKIPPED ]' not in native and passed==6,passed
receipt.update(verdict='PASS',passed_tests=passed);save();print(stage,'PASS',passed,flush=True)
