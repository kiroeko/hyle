spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, Matrix], [SPV_KHR_storage_buffer_storage_class]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<2 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @trig_dispatch_0_elementwise_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst64_i32 = spirv.Constant 64 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst_f32 = spirv.Constant -2.59630184E-7 : f32
    %cst_f32_0 = spirv.Constant 2.47562348E-5 : f32
    %cst_f32_1 = spirv.Constant -0.00138883304 : f32
    %cst_f32_2 = spirv.Constant 0.0416666418 : f32
    %cst_f32_3 = spirv.Constant -5.000000e-01 : f32
    %cst_f32_4 = spirv.Constant -2.50293279E-8 : f32
    %cst_f32_5 = spirv.Constant 2.76001265E-6 : f32
    %cst_f32_6 = spirv.Constant -1.98426045E-4 : f32
    %cst_f32_7 = spirv.Constant 0.00833334774 : f32
    %cst_f32_8 = spirv.Constant -0.166666672 : f32
    %cst_f32_9 = spirv.Constant -1.000000e+00 : f32
    %cst_f32_10 = spirv.Constant 1.000000e+00 : f32
    %cst_f32_11 = spirv.Constant 1.57079637 : f32
    %cst_f32_12 = spirv.Constant 0.636619746 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<2 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<2 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %2 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %3 = spirv.CompositeExtract %2[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %4 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %5 = spirv.CompositeExtract %4[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %6 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %7 = spirv.CompositeExtract %6[0 : i32] : vector<3xi32>
    %8 = spirv.IMul %5, %cst64_i32 : i32
    %9 = spirv.IMul %7, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%8 : i32)
    ^bb1(%10: i32):  // 2 preds: ^bb0, ^bb2
      %11 = spirv.SLessThan %10, %1 : i32
      spirv.BranchConditional %11, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %12 = spirv.ISub %1, %10 : i32
      %13 = spirv.GL.SMin %12, %cst64_i32 : i32
      %14 = spirv.SGreaterThan %13, %3 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %14, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %16 = spirv.IAdd %10, %3 : i32
        %17 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %16] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %18 = spirv.Load "StorageBuffer" %17 : f32
        %19 = spirv.FMul %18, %cst_f32_12 : f32
        %20 = spirv.GL.Floor %19 : f32
        %21 = spirv.FMul %20, %cst_f32_11 : f32
        %22 = spirv.FSub %18, %21 : f32
        %23 = spirv.ConvertFToS %20 : f32 to i32
        %24 = spirv.BitwiseAnd %23, %cst3_i32 : i32
        %25 = spirv.IEqual %24, %cst1_i32 : i32
        %26 = spirv.IEqual %24, %cst3_i32 : i32
        %27 = spirv.LogicalOr %25, %26 : i1
        %28 = spirv.SGreaterThan %24, %cst1_i32 : i32
        %29 = spirv.FMul %22, %22 : f32
        %30 = spirv.Select %27, %cst_f32_10, %22 : i1, f32
        %31 = spirv.Select %27, %cst_f32_3, %cst_f32_8 : i1, f32
        %32 = spirv.Select %27, %cst_f32_2, %cst_f32_7 : i1, f32
        %33 = spirv.Select %27, %cst_f32_1, %cst_f32_6 : i1, f32
        %34 = spirv.Select %27, %cst_f32_0, %cst_f32_5 : i1, f32
        %35 = spirv.Select %27, %cst_f32, %cst_f32_4 : i1, f32
        %36 = spirv.GL.Fma %29, %35, %34 : f32
        %37 = spirv.GL.Fma %29, %36, %33 : f32
        %38 = spirv.GL.Fma %29, %37, %32 : f32
        %39 = spirv.GL.Fma %29, %38, %31 : f32
        %40 = spirv.GL.Fma %29, %39, %cst_f32_10 : f32
        %41 = spirv.FMul %30, %40 : f32
        %42 = spirv.FMul %41, %cst_f32_9 : f32
        %43 = spirv.Select %28, %42, %41 : i1, f32
        %44 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %16] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %44, %43 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %15 = spirv.IAdd %10, %9 : i32
      spirv.Branch ^bb1(%15 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @trig_dispatch_0_elementwise_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @trig_dispatch_0_elementwise_D_f32 "LocalSize", 64, 1, 1
}