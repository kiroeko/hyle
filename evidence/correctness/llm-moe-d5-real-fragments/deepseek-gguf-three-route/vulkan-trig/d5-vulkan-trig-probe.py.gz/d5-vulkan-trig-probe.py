from pathlib import Path
import ctypes
import hashlib
import json
import subprocess
import numpy as np

ctypes.windll.kernel32.SetErrorMode(0x0001 | 0x0002 | 0x8000)
out = Path('.scratch/validation/d5-vulkan-trig-source-probe').resolve()
out.mkdir(parents=True, exist_ok=True)
compiler = Path('C:/hv/m2vk-tools/iree/compiler/_mlir_libs/iree-compile.exe')
runner = Path('C:/hv/m2vk-tools/iree/_runtime_libs/iree-run-module.exe')
recipe = out / 'trig.mlir'
recipe.write_text('''module {
  func.func @trig(%input: tensor<?xf32>) -> (tensor<?xf32>, tensor<?xf32>) {
    %zero = arith.constant 0 : index
    %count = tensor.dim %input, %zero : tensor<?xf32>
    %empty = tensor.empty(%count) : tensor<?xf32>
    %sine = linalg.generic {
      indexing_maps = [affine_map<(i) -> (i)>, affine_map<(i) -> (i)>],
      iterator_types = ["parallel"]
    } ins(%input : tensor<?xf32>) outs(%empty : tensor<?xf32>) {
    ^bb0(%x: f32, %unused: f32):
      %v = math.sin %x : f32
      linalg.yield %v : f32
    } -> tensor<?xf32>
    %cosine = linalg.generic {
      indexing_maps = [affine_map<(i) -> (i)>, affine_map<(i) -> (i)>],
      iterator_types = ["parallel"]
    } ins(%input : tensor<?xf32>) outs(%empty : tensor<?xf32>) {
    ^bb0(%x: f32, %unused: f32):
      %v = math.cos %x : f32
      linalg.yield %v : f32
    } -> tensor<?xf32>
    return %sine, %cosine : tensor<?xf32>, tensor<?xf32>
  }
}
''', encoding='utf-8')
binary = out / 'trig.vmfb'
receipt = {'scope': 'Bounded original IREE compiler trig probe; not HYLE product qualification', 'commands': []}
def run(label, argv):
    r = subprocess.run([str(x) for x in argv], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    (out / (label + '.log')).write_bytes(r.stdout)
    receipt['commands'].append({'argv': [str(x) for x in argv], 'returncode': r.returncode})
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    r.check_returncode()
run('version', [compiler, '--version'])
run('compile', [compiler, recipe, '--iree-hal-target-device=vulkan',
    '--iree-vulkan-target=vp_android_baseline_2022', '--iree-vulkan-dispatch-abi=descriptors',
    '--iree-hal-dump-executable-files-to=' + str(out / 'spirv'), '-o', binary])
x = np.asarray([0, 1, -1, 3.1415927, 2380, 4096, 65536, 65663, -65536, 131072,
    *[np.float32(65536) * np.float32(0.4728708267211914 ** i) for i in range(1, 17)]], dtype=np.float32)
np.save(out / 'input.npy', x)
run('execute', [runner, '--device=vulkan', '--module=' + str(binary), '--function=trig',
    '--input=@' + str(out / 'input.npy'), '--output=@' + str(out / 'sin.npy'), '--output=@' + str(out / 'cos.npy')])
receipt['values'] = []
for name, fn in [('sin', np.sin), ('cos', np.cos)]:
    actual = np.load(out / (name + '.npy'))
    reference = fn(x.astype(np.float64))
    error = np.abs(actual.astype(np.float64) - reference)
    receipt[name + '_max_absolute_error'] = float(np.max(error))
    for phase, a, ref in zip(x, actual, reference):
        receipt['values'].append({'function': name, 'phase': float(phase), 'actual': float(a), 'reference': float(ref)})
receipt['files'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [recipe, binary, compiler, runner]}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print({k:v for k,v in receipt.items() if k.endswith('_error')})
