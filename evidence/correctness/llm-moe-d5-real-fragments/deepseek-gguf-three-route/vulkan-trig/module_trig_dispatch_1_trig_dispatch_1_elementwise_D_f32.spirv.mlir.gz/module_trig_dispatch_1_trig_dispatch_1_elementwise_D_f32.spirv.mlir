spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, Matrix], [SPV_KHR_storage_buffer_storage_class]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @trig_dispatch_1_elementwise_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst64_i32 = spirv.Constant 64 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst_f32 = spirv.Constant -2.59630184E-7 : f32
    %cst_f32_0 = spirv.Constant 2.47562348E-5 : f32
    %cst_f32_1 = spirv.Constant -0.00138883304 : f32
    %cst_f32_2 = spirv.Constant 0.0416666418 : f32
    %cst_f32_3 = spirv.Constant -5.000000e-01 : f32
    %cst_f32_4 = spirv.Constant -2.50293279E-8 : f32
    %cst_f32_5 = spirv.Constant 2.76001265E-6 : f32
    %cst_f32_6 = spirv.Constant -1.98426045E-4 : f32
    %cst_f32_7 = spirv.Constant 0.00833334774 : f32
    %cst_f32_8 = spirv.Constant -0.166666672 : f32
    %cst_f32_9 = spirv.Constant -1.000000e+00 : f32
    %cst_f32_10 = spirv.Constant 1.000000e+00 : f32
    %cst_f32_11 = spirv.Constant 1.57079637 : f32
    %cst_f32_12 = spirv.Constant 0.636619746 : f32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %4 = spirv.SDiv %1, %cst4_i32 : i32
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %5 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %6 = spirv.CompositeExtract %5[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %7 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %8 = spirv.CompositeExtract %7[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %9 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %10 = spirv.CompositeExtract %9[0 : i32] : vector<3xi32>
    %11 = spirv.IMul %8, %cst64_i32 : i32
    %12 = spirv.IMul %10, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%11 : i32)
    ^bb1(%13: i32):  // 2 preds: ^bb0, ^bb2
      %14 = spirv.SLessThan %13, %3 : i32
      spirv.BranchConditional %14, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %15 = spirv.ISub %3, %13 : i32
      %16 = spirv.GL.SMin %15, %cst64_i32 : i32
      %17 = spirv.SGreaterThan %16, %6 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %17, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %19 = spirv.IAdd %13, %6 : i32
        %20 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %19] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %21 = spirv.Load "StorageBuffer" %20 : f32
        %22 = spirv.FMul %21, %cst_f32_12 : f32
        %23 = spirv.GL.Floor %22 : f32
        %24 = spirv.FMul %23, %cst_f32_11 : f32
        %25 = spirv.FSub %21, %24 : f32
        %26 = spirv.ConvertFToS %23 : f32 to i32
        %27 = spirv.BitwiseAnd %26, %cst3_i32 : i32
        %28 = spirv.IEqual %27, %cst0_i32 : i32
        %29 = spirv.IEqual %27, %cst1_i32 : i32
        %30 = spirv.IEqual %27, %cst2_i32 : i32
        %31 = spirv.LogicalOr %28, %30 : i1
        %32 = spirv.LogicalOr %29, %30 : i1
        %33 = spirv.FMul %25, %25 : f32
        %34 = spirv.Select %31, %cst_f32_10, %25 : i1, f32
        %35 = spirv.Select %31, %cst_f32_3, %cst_f32_8 : i1, f32
        %36 = spirv.Select %31, %cst_f32_2, %cst_f32_7 : i1, f32
        %37 = spirv.Select %31, %cst_f32_1, %cst_f32_6 : i1, f32
        %38 = spirv.Select %31, %cst_f32_0, %cst_f32_5 : i1, f32
        %39 = spirv.Select %31, %cst_f32, %cst_f32_4 : i1, f32
        %40 = spirv.GL.Fma %33, %39, %38 : f32
        %41 = spirv.GL.Fma %33, %40, %37 : f32
        %42 = spirv.GL.Fma %33, %41, %36 : f32
        %43 = spirv.GL.Fma %33, %42, %35 : f32
        %44 = spirv.GL.Fma %33, %43, %cst_f32_10 : f32
        %45 = spirv.FMul %34, %44 : f32
        %46 = spirv.FMul %45, %cst_f32_9 : f32
        %47 = spirv.Select %32, %46, %45 : i1, f32
        %48 = spirv.IAdd %19, %4 : i32
        %49 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %48] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %49, %47 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %18 = spirv.IAdd %13, %12 : i32
      spirv.Branch ^bb1(%18 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @trig_dispatch_1_elementwise_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @trig_dispatch_1_elementwise_D_f32 "LocalSize", 64, 1, 1
}