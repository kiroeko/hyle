#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/cuda_fp8.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void act_quant_kernel__kernel(float* __restrict__ S, const bfloat16_t* __restrict__ X, bfloat16_t* __restrict__ Y, int M);
extern "C" __global__ void __launch_bounds__(128, 1) act_quant_kernel__kernel(float* __restrict__ S, const bfloat16_t* __restrict__ X, bfloat16_t* __restrict__ Y, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* x_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* y_shared = ((void*)((char*)buf_dyn_shmem + 0));
  bfloat16_t x_local[32];
  float amax_local[4];
  float s_local[4];
  bfloat16_t y_local[32];
  #pragma unroll
  for (int i = 0; i < 4; ++i) {
    bfloat16_t broadcast_var = bfloat16_t(0x0p+0f/*0.000000e+00*/);
    uint4 condval;
    if (((((((int)blockIdx.x) * 32) + (i * 8)) + (((int)threadIdx.x) >> 4)) < M)) {
      condval = *(uint4*)(X + (((((int64_t)((int)blockIdx.x)) * (int64_t)4096) + (((int64_t)i) * (int64_t)1024)) + (((int64_t)((int)threadIdx.x)) * (int64_t)8)));
    } else {
      condval = make_uint4(__pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var), __pack_nv_bfloat162(broadcast_var, broadcast_var));
    }
    *(uint4*)(((bfloat16_t*)x_shared) + ((i * 1024) + (((int)threadIdx.x) * 8))) = condval;
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 4; ++i_1) {
    *(uint4*)(x_local + (i_1 * 8)) = *(uint4*)(((bfloat16_t*)x_shared) + ((i_1 * 1024) + (((int)threadIdx.x) * 8)));
  }
  #pragma unroll
  for (int i_2 = 0; i_2 < 4; ++i_2) {
    amax_local[i_2] = 0x0p+0f/*0.000000e+00*/;
    #pragma unroll
    for (int rv = 0; rv < 8; ++rv) {
      amax_local[i_2] = max(amax_local[i_2], max(((float)x_local[((i_2 * 8) + rv)]), (0x0p+0f/*0.000000e+00*/ - ((float)x_local[((i_2 * 8) + rv)]))));
    }
    amax_local[i_2] = tl::AllReduce<tl::MaxOp, 16, 1, 0, tl::NamedBarrier<128>>::run(amax_local[i_2]);
  }
  #pragma unroll
  for (int i_3 = 0; i_3 < 4; ++i_3) {
    amax_local[i_3] = max(amax_local[i_3], 0x1.a36e2eb1c432dp-14f/*1.000000e-04*/);
    float v_ = amax_local[i_3] * 0x1.2492492492492p-9f/*2.232143e-03*/;
    int condval_1;
    if ((((*(uint *)(&(v_))) & (uint)8388607) != (uint)0)) {
      condval_1 = 1;
    } else {
      condval_1 = 0;
    }
    int v__1 = (((int)(((((*(uint *)(&(v_))) >> (uint)23) & (uint)255) - (uint)127) + ((uint)condval_1))) + 127) << 23;
    s_local[i_3] = (*(float *)(&(v__1)));
  }
  #pragma unroll
  for (int i_4 = 0; i_4 < 8; ++i_4) {
    float broadcast_var_1 = -0x1.cp+8f/*-4.480000e+02*/;
    float broadcast_var_2 = 0x1.cp+8f/*4.480000e+02*/;
    uint2 __1;
    float4 __2;
      float4 __3;
      fp8_e4_4_t __4;
      float4 __5;
        float4 __6;
          float4 __7;
            float4 __8;
            uint2 v__2 = *(uint2*)(x_local + (i_4 * 4));
            ((float2*)(&__8))[0] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__2))[0]);
            ((float2*)(&__8))[1] = __bfloat1622float2((reinterpret_cast<__nv_bfloat162*>(&v__2))[1]);
            float4 v__3 = make_float4(s_local[(i_4 >> 1)], s_local[(i_4 >> 1)], s_local[(i_4 >> 1)], s_local[(i_4 >> 1)]);
            __7.x = (__8.x/v__3.x);
            __7.y = (__8.y/v__3.y);
            __7.z = (__8.z/v__3.z);
            __7.w = (__8.w/v__3.w);
          float4 v__4 = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
          __6.x = max(__7.x, v__4.x);
          __6.y = max(__7.y, v__4.y);
          __6.z = max(__7.z, v__4.z);
          __6.w = max(__7.w, v__4.w);
        float4 v__5 = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
        __5.x = min(__6.x, v__5.x);
        __5.y = min(__6.y, v__5.y);
        __5.z = min(__6.z, v__5.z);
        __5.w = min(__6.w, v__5.w);
      (reinterpret_cast<__nv_fp8x2_storage_t*>(&__4))[0] = __nv_cvt_float2_to_fp8x2(((float2*)(&__5))[0], __NV_SATFINITE, __NV_E4M3);
      (reinterpret_cast<__nv_fp8x2_storage_t*>(&__4))[1] = __nv_cvt_float2_to_fp8x2(((float2*)(&__5))[1], __NV_SATFINITE, __NV_E4M3);
      ((float2*)(&__3))[0] = __tl_cvt_fp8x2_to_float2((reinterpret_cast<__nv_fp8x2_storage_t*>(&__4))[0], __NV_E4M3);
      ((float2*)(&__3))[1] = __tl_cvt_fp8x2_to_float2((reinterpret_cast<__nv_fp8x2_storage_t*>(&__4))[1], __NV_E4M3);
      float4 v__6 = make_float4(s_local[(i_4 >> 1)], s_local[(i_4 >> 1)], s_local[(i_4 >> 1)], s_local[(i_4 >> 1)]);
      __2.x = (__3.x*v__6.x);
      __2.y = (__3.y*v__6.y);
      __2.z = (__3.z*v__6.z);
      __2.w = (__3.w*v__6.w);
    (reinterpret_cast<__nv_bfloat162*>(&__1))[0] = __float22bfloat162_rn(((float2*)(&__2))[0]);
    (reinterpret_cast<__nv_bfloat162*>(&__1))[1] = __float22bfloat162_rn(((float2*)(&__2))[1]);
    *(uint2*)(y_local + (i_4 * 4)) = __1;
  }
  if ((((int)threadIdx.x) % 16) == 0) {
    #pragma unroll
    for (int i_5 = 0; i_5 < 4; ++i_5) {
      if ((((((int)blockIdx.x) * 32) + (i_5 * 8)) + (((int)threadIdx.x) >> 4)) < M) {
        S[(((((int64_t)((int)blockIdx.x)) * (int64_t)32) + (((int64_t)i_5) * (int64_t)8)) + (((int64_t)((int)threadIdx.x)) >> (int64_t)4))] = s_local[i_5];
      }
    }
  }
  __syncthreads();
  #pragma unroll
  for (int i_6 = 0; i_6 < 4; ++i_6) {
    *(uint4*)(((bfloat16_t*)y_shared) + ((i_6 * 1024) + (((int)threadIdx.x) * 8))) = *(uint4*)(y_local + (i_6 * 8));
  }
  #pragma unroll
  for (int i_7 = 0; i_7 < 4; ++i_7) {
    if ((((((int)blockIdx.x) * 32) + (i_7 * 8)) + (((int)threadIdx.x) >> 4)) < M) {
      *(uint4*)(Y + (((((int64_t)((int)blockIdx.x)) * (int64_t)4096) + (((int64_t)i_7) * (int64_t)1024)) + (((int64_t)((int)threadIdx.x)) * (int64_t)8))) = *(uint4*)(((bfloat16_t*)y_shared) + ((i_7 * 1024) + (((int)threadIdx.x) * 8)));
    }
  }
}

