#if defined(_MSC_VER) && !defined(__clang__) && _MSC_VER < 1940
#define _tl_orig_alignas alignas
#define alignas(N) _tl_orig_alignas((N) <= 64 ? (N) : 64)
#include <cuda.h>
#undef alignas
#define alignas _tl_orig_alignas
#endif
#include <tl_templates/cuda/instruction/mma.h>
#include <tl_templates/cuda/copy.h>
#include <tl_templates/cuda/cuda_fp8.h>
#include <tl_templates/cuda/cuda_fp4.h>
#include <tl_templates/cuda/reduce.h>
#include <tl_templates/cuda/scan.h>
#include <tl_templates/cuda/ldsm.h>
#include <tl_templates/cuda/threadblock_swizzle.h>
#include <tl_templates/cuda/debug.h>
#ifdef ENABLE_BF16
#include <tl_templates/cuda/cuda_bf16_fallbacks.cuh>
#endif

extern "C" __global__ void fp4_gemm_kernel__kernel(const fp8_e4_t* __restrict__ A, const fp4_e2_t* __restrict__ B, bfloat16_t* __restrict__ C, const float* __restrict__ scales_a, const float* __restrict__ scales_b, int M);
extern "C" __global__ void __launch_bounds__(128, 1) fp4_gemm_kernel__kernel(const fp8_e4_t* __restrict__ A, const fp4_e2_t* __restrict__ B, bfloat16_t* __restrict__ C, const float* __restrict__ scales_a, const float* __restrict__ scales_b, int M) {
  extern __shared__ __align__(1024) uchar buf_dyn_shmem[];
  void* B_fp4_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* C_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* A_shared = ((void*)((char*)buf_dyn_shmem + 4096));
  void* B_shared = ((void*)((char*)buf_dyn_shmem + 6144));
  float C_local[32];
  float C_local_accum[32];
  float scale_b_frag[16];
  float scale_a_frag[2];
  const dim3 blockIdx = tl::rasterization2DRow<10>();
  #pragma unroll
  for (int i = 0; i < 8; ++i) {
    float broadcast_var = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_local + (i * 4)) = make_float4(broadcast_var, broadcast_var, broadcast_var, broadcast_var);
  }
  #pragma unroll
  for (int i_1 = 0; i_1 < 8; ++i_1) {
    float broadcast_var_1 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_local_accum + (i_1 * 4)) = make_float4(broadcast_var_1, broadcast_var_1, broadcast_var_1, broadcast_var_1);
  }
  tl::cp_async_gs<16>((&(((fp4_e2_t*)B_fp4_shared)[(((int)threadIdx.x) * 16)])), (&(B[((((int)blockIdx.x) * 131072) + (((int)threadIdx.x) * 1024))])));
  tl::cp_async_commit();
  tl::cp_async_gs_conditional<8>((&(((fp8_e4_t*)A_shared)[((((((int)threadIdx.x) >> 2) * 32) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + ((((int)threadIdx.x) & 1) * 8))])), (&(A[(((((int64_t)((int)blockIdx.y)) * (int64_t)65536) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)2048)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)8))])), ((((((int)blockIdx.y) * 32) + (((int)threadIdx.x) >> 2)) < M) && (((((int)blockIdx.y) * 32) + (((int)threadIdx.x) >> 2)) < M)));
  tl::cp_async_commit();
  tl::cp_async_gs<16>((&(((fp4_e2_t*)B_fp4_shared)[((((int)threadIdx.x) * 16) + 2048)])), (&(B[(((((int)blockIdx.x) * 131072) + (((int)threadIdx.x) * 1024)) + 16)])));
  tl::cp_async_commit();
  tl::cp_async_gs_conditional<8>((&(((fp8_e4_t*)A_shared)[(((((((int)threadIdx.x) >> 2) * 32) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + ((((int)threadIdx.x) & 1) * 8)) + 1024)])), (&(A[((((((int64_t)((int)blockIdx.y)) * (int64_t)65536) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)2048)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)8)) + (int64_t)32)])), ((((((int)blockIdx.y) * 32) + (((int)threadIdx.x) >> 2)) < M) && (((((int)blockIdx.y) * 32) + (((int)threadIdx.x) >> 2)) < M)));
  tl::cp_async_commit();
  for (int k = 0; k < 62; ++k) {
    tl::cp_async_wait<3>();
    __syncthreads();
    #pragma unroll
    for (int i_2 = 0; i_2 < 2; ++i_2) {
      fp4_e2_2_t B_fp4_shared_local_cast_1_packed[8];
      fp8_e4_t B_shared_local_cast[16];
      __syncthreads();
      *(fp4_e2_16_t*)(B_fp4_shared_local_cast_1_packed + 0) = *(fp4_e2_16_t*)(((fp4_e2_t*)B_fp4_shared) + ((((k & 1) * 2048) + (i_2 * 1024)) + (((int)threadIdx.x) * 8)));
      for (int vec = 0; vec < 4; ++vec) {
        fp8_e4_4_t __1;
        float4 __2;
        fp4_e2_4_t v_ = *(fp4_e2_4_t*)(B_fp4_shared_local_cast_1_packed + (vec * 2));
        ((float2*)(&__2))[0] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&v_))[0]);
        ((float2*)(&__2))[1] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&v_))[1]);
        (reinterpret_cast<__nv_fp8x2_storage_t*>(&__1))[0] = __nv_cvt_float2_to_fp8x2(((float2*)(&__2))[0], __NV_SATFINITE, __NV_E4M3);
        (reinterpret_cast<__nv_fp8x2_storage_t*>(&__1))[1] = __nv_cvt_float2_to_fp8x2(((float2*)(&__2))[1], __NV_SATFINITE, __NV_E4M3);
        *(fp8_e4_4_t*)(B_shared_local_cast + (vec * 4)) = __1;
      }
      *(fp8_e4_16_t*)(((fp8_e4_t*)B_shared) + (((i_2 * 2048) + ((((int)threadIdx.x) >> 1) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 16))) = *(fp8_e4_16_t*)(B_shared_local_cast + 0);
    }
    __syncthreads();
    tl::cp_async_gs<16>((&(((fp4_e2_t*)B_fp4_shared)[(((k & 1) * 2048) + (((int)threadIdx.x) * 16))])), (&(B[((((((int)blockIdx.x) * 131072) + (((int)threadIdx.x) * 1024)) + (k * 16)) + 32)])));
    tl::cp_async_commit();
    #pragma unroll
    for (int i_3 = 0; i_3 < 16; ++i_3) {
      scale_b_frag[i_3] = scales_b[((((((((int)blockIdx.x) * 8192) + ((((int)threadIdx.x) >> 6) * 4096)) + ((i_3 >> 1) * 512)) + ((((int)threadIdx.x) & 3) * 128)) + ((i_3 & 1) * 64)) + k)];
    }
    #pragma unroll
    for (int i_4 = 0; i_4 < 2; ++i_4) {
      float condval;
      if ((((((((int)blockIdx.y) * 32) + (((((int)threadIdx.x) & 63) >> 5) * 16)) + (i_4 * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M)) {
        condval = scales_a[(((((((int64_t)((int)blockIdx.y)) * (int64_t)512) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)256)) + (((int64_t)i_4) * (int64_t)128)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)16)) + (((int64_t)k) >> (int64_t)2))];
      } else {
        condval = 0x0p+0f/*0.000000e+00*/;
      }
      scale_a_frag[i_4] = condval;
    }
    tl::cp_async_wait<3>();
    __syncthreads();
    {
      fp8_e4_t A_local[16];
      fp8_e4_t B_local[64];
      tl::ptx_ldmatrix_x4((&(((fp8_e4_t*)A_shared)[(((((k & 1) * 1024) + (((((int)threadIdx.x) & 63) >> 5) * 512)) + ((((int)threadIdx.x) & 15) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 16))])), (&(A_local[0])));
      #pragma unroll
      for (int i_5 = 0; i_5 < 4; ++i_5) {
        tl::ptx_ldmatrix_x4((&(((fp8_e4_t*)B_shared)[((((((((int)threadIdx.x) >> 6) * 2048) + (i_5 * 512)) + (((((int)threadIdx.x) & 31) >> 4) * 256)) + ((((int)threadIdx.x) & 7) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 16))])), (&(B_local[(i_5 * 16)])));
      }
      for (int j = 0; j < 4; ++j) {
        tl::mma_sync<tl::DataType::kFloat8_e4m3, tl::DataType::kFloat8_e4m3, tl::DataType::kFloat32, 16, 8, 32, false, true>(reinterpret_cast<float*>(C_local + (j * 8)), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + (j * 16)));
        tl::mma_sync<tl::DataType::kFloat8_e4m3, tl::DataType::kFloat8_e4m3, tl::DataType::kFloat32, 16, 8, 32, false, true>(reinterpret_cast<float*>(C_local + ((j * 8) + 4)), reinterpret_cast<const unsigned*>(A_local + 0), reinterpret_cast<const unsigned*>(B_local + ((j * 16) + 8)));
      }
    }
    __syncthreads();
    tl::cp_async_gs_conditional<8>((&(((fp8_e4_t*)A_shared)[(((((k & 1) * 1024) + ((((int)threadIdx.x) >> 2) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 3) >> 1)) & 1) * 16)) + ((((int)threadIdx.x) & 1) * 8))])), (&(A[(((((((int64_t)((int)blockIdx.y)) * (int64_t)65536) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)2) * (int64_t)2048)) + (((int64_t)k) * (int64_t)32)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)3) * (int64_t)8)) + (int64_t)64)])), ((((((int)blockIdx.y) * 32) + (((int)threadIdx.x) >> 2)) < M) && (((((int)blockIdx.y) * 32) + (((int)threadIdx.x) >> 2)) < M)));
    tl::cp_async_commit();
    #pragma unroll
    for (int i_6 = 0; i_6 < 16; ++i_6) {
      float2 __3;
        float2 v__1 = *(float2*)(C_local_accum + (i_6 * 2));
        float2 __4;
          float2 __5;
            float2 v__2 = *(float2*)(C_local + (i_6 * 2));
            float2 v__3 = make_float2(scale_a_frag[(i_6 & 1)], scale_a_frag[(i_6 & 1)]);
            __5.x = (v__2.x*v__3.x);
            __5.y = (v__2.y*v__3.y);
          float2 v__4 = *(float2*)(scale_b_frag + ((i_6 >> 1) * 2));
          __4.x = (__5.x*v__4.x);
          __4.y = (__5.y*v__4.y);
        __3.x = (v__1.x+__4.x);
        __3.y = (v__1.y+__4.y);
      *(float2*)(C_local_accum + (i_6 * 2)) = __3;
    }
    #pragma unroll
    for (int i_7 = 0; i_7 < 8; ++i_7) {
      float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
      *(float4*)(C_local + (i_7 * 4)) = make_float4(broadcast_var_2, broadcast_var_2, broadcast_var_2, broadcast_var_2);
    }
  }
  tl::cp_async_wait<3>();
  __syncthreads();
  #pragma unroll
  for (int i_8 = 0; i_8 < 2; ++i_8) {
    fp4_e2_2_t B_fp4_shared_local_cast_3_packed[8];
    fp8_e4_t B_shared_local_cast_2[16];
    *(fp4_e2_16_t*)(B_fp4_shared_local_cast_3_packed + 0) = *(fp4_e2_16_t*)(((fp4_e2_t*)B_fp4_shared) + ((i_8 * 1024) + (((int)threadIdx.x) * 8)));
    for (int vec_1 = 0; vec_1 < 4; ++vec_1) {
      fp8_e4_4_t __6;
      float4 __7;
      fp4_e2_4_t v__5 = *(fp4_e2_4_t*)(B_fp4_shared_local_cast_3_packed + (vec_1 * 2));
      ((float2*)(&__7))[0] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&v__5))[0]);
      ((float2*)(&__7))[1] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&v__5))[1]);
      (reinterpret_cast<__nv_fp8x2_storage_t*>(&__6))[0] = __nv_cvt_float2_to_fp8x2(((float2*)(&__7))[0], __NV_SATFINITE, __NV_E4M3);
      (reinterpret_cast<__nv_fp8x2_storage_t*>(&__6))[1] = __nv_cvt_float2_to_fp8x2(((float2*)(&__7))[1], __NV_SATFINITE, __NV_E4M3);
      *(fp8_e4_4_t*)(B_shared_local_cast_2 + (vec_1 * 4)) = __6;
    }
    *(fp8_e4_16_t*)(((fp8_e4_t*)B_shared) + (((i_8 * 2048) + ((((int)threadIdx.x) >> 1) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 16))) = *(fp8_e4_16_t*)(B_shared_local_cast_2 + 0);
  }
  #pragma unroll
  for (int i_9 = 0; i_9 < 16; ++i_9) {
    scale_b_frag[i_9] = scales_b[((((((((int)blockIdx.x) * 8192) + ((((int)threadIdx.x) >> 6) * 4096)) + ((i_9 >> 1) * 512)) + ((((int)threadIdx.x) & 3) * 128)) + ((i_9 & 1) * 64)) + 62)];
  }
  #pragma unroll
  for (int i_10 = 0; i_10 < 2; ++i_10) {
    float condval_1;
    if ((((((((int)blockIdx.y) * 32) + (((((int)threadIdx.x) & 63) >> 5) * 16)) + (i_10 * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M)) {
      condval_1 = scales_a[(((((((int64_t)((int)blockIdx.y)) * (int64_t)512) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)256)) + (((int64_t)i_10) * (int64_t)128)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)16)) + (int64_t)15)];
    } else {
      condval_1 = 0x0p+0f/*0.000000e+00*/;
    }
    scale_a_frag[i_10] = condval_1;
  }
  tl::cp_async_wait<2>();
  __syncthreads();
  {
    fp8_e4_t A_local_1[16];
    fp8_e4_t B_local_1[64];
    tl::ptx_ldmatrix_x4((&(((fp8_e4_t*)A_shared)[(((((((int)threadIdx.x) & 63) >> 5) * 512) + ((((int)threadIdx.x) & 15) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 16))])), (&(A_local_1[0])));
    #pragma unroll
    for (int i_11 = 0; i_11 < 4; ++i_11) {
      tl::ptx_ldmatrix_x4((&(((fp8_e4_t*)B_shared)[((((((((int)threadIdx.x) >> 6) * 2048) + (i_11 * 512)) + (((((int)threadIdx.x) & 31) >> 4) * 256)) + ((((int)threadIdx.x) & 7) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 16))])), (&(B_local_1[(i_11 * 16)])));
    }
    for (int j_1 = 0; j_1 < 4; ++j_1) {
      tl::mma_sync<tl::DataType::kFloat8_e4m3, tl::DataType::kFloat8_e4m3, tl::DataType::kFloat32, 16, 8, 32, false, true>(reinterpret_cast<float*>(C_local + (j_1 * 8)), reinterpret_cast<const unsigned*>(A_local_1 + 0), reinterpret_cast<const unsigned*>(B_local_1 + (j_1 * 16)));
      tl::mma_sync<tl::DataType::kFloat8_e4m3, tl::DataType::kFloat8_e4m3, tl::DataType::kFloat32, 16, 8, 32, false, true>(reinterpret_cast<float*>(C_local + ((j_1 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local_1 + 0), reinterpret_cast<const unsigned*>(B_local_1 + ((j_1 * 16) + 8)));
    }
  }
  #pragma unroll
  for (int i_12 = 0; i_12 < 16; ++i_12) {
    float2 __8;
      float2 v__6 = *(float2*)(C_local_accum + (i_12 * 2));
      float2 __9;
        float2 __10;
          float2 v__7 = *(float2*)(C_local + (i_12 * 2));
          float2 v__8 = make_float2(scale_a_frag[(i_12 & 1)], scale_a_frag[(i_12 & 1)]);
          __10.x = (v__7.x*v__8.x);
          __10.y = (v__7.y*v__8.y);
        float2 v__9 = *(float2*)(scale_b_frag + ((i_12 >> 1) * 2));
        __9.x = (__10.x*v__9.x);
        __9.y = (__10.y*v__9.y);
      __8.x = (v__6.x+__9.x);
      __8.y = (v__6.y+__9.y);
    *(float2*)(C_local_accum + (i_12 * 2)) = __8;
  }
  #pragma unroll
  for (int i_13 = 0; i_13 < 8; ++i_13) {
    float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_local + (i_13 * 4)) = make_float4(broadcast_var_3, broadcast_var_3, broadcast_var_3, broadcast_var_3);
  }
  tl::cp_async_wait<1>();
  __syncthreads();
  #pragma unroll
  for (int i_14 = 0; i_14 < 2; ++i_14) {
    fp4_e2_2_t B_fp4_shared_local_cast_5_packed[8];
    fp8_e4_t B_shared_local_cast_4[16];
    __syncthreads();
    *(fp4_e2_16_t*)(B_fp4_shared_local_cast_5_packed + 0) = *(fp4_e2_16_t*)(((fp4_e2_t*)B_fp4_shared) + (((i_14 * 1024) + (((int)threadIdx.x) * 8)) + 2048));
    for (int vec_2 = 0; vec_2 < 4; ++vec_2) {
      fp8_e4_4_t __11;
      float4 __12;
      fp4_e2_4_t v__10 = *(fp4_e2_4_t*)(B_fp4_shared_local_cast_5_packed + (vec_2 * 2));
      ((float2*)(&__12))[0] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&v__10))[0]);
      ((float2*)(&__12))[1] = __tl_cvt_fp4x2_to_float2((reinterpret_cast<uint8_t*>(&v__10))[1]);
      (reinterpret_cast<__nv_fp8x2_storage_t*>(&__11))[0] = __nv_cvt_float2_to_fp8x2(((float2*)(&__12))[0], __NV_SATFINITE, __NV_E4M3);
      (reinterpret_cast<__nv_fp8x2_storage_t*>(&__11))[1] = __nv_cvt_float2_to_fp8x2(((float2*)(&__12))[1], __NV_SATFINITE, __NV_E4M3);
      *(fp8_e4_4_t*)(B_shared_local_cast_4 + (vec_2 * 4)) = __11;
    }
    *(fp8_e4_16_t*)(((fp8_e4_t*)B_shared) + (((i_14 * 2048) + ((((int)threadIdx.x) >> 1) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + (((int)threadIdx.x) & 1)) & 1) * 16))) = *(fp8_e4_16_t*)(B_shared_local_cast_4 + 0);
  }
  #pragma unroll
  for (int i_15 = 0; i_15 < 16; ++i_15) {
    scale_b_frag[i_15] = scales_b[((((((((int)blockIdx.x) * 8192) + ((((int)threadIdx.x) >> 6) * 4096)) + ((i_15 >> 1) * 512)) + ((((int)threadIdx.x) & 3) * 128)) + ((i_15 & 1) * 64)) + 63)];
  }
  #pragma unroll
  for (int i_16 = 0; i_16 < 2; ++i_16) {
    float condval_2;
    if ((((((((int)blockIdx.y) * 32) + (((((int)threadIdx.x) & 63) >> 5) * 16)) + (i_16 * 8)) + ((((int)threadIdx.x) & 31) >> 2)) < M)) {
      condval_2 = scales_a[(((((((int64_t)((int)blockIdx.y)) * (int64_t)512) + (((((int64_t)((int)threadIdx.x)) & (int64_t)63) >> (int64_t)5) * (int64_t)256)) + (((int64_t)i_16) * (int64_t)128)) + (((((int64_t)((int)threadIdx.x)) & (int64_t)31) >> (int64_t)2) * (int64_t)16)) + (int64_t)15)];
    } else {
      condval_2 = 0x0p+0f/*0.000000e+00*/;
    }
    scale_a_frag[i_16] = condval_2;
  }
  tl::cp_async_wait<0>();
  __syncthreads();
  {
    fp8_e4_t A_local_2[16];
    fp8_e4_t B_local_2[64];
    tl::ptx_ldmatrix_x4((&(((fp8_e4_t*)A_shared)[((((((((int)threadIdx.x) & 63) >> 5) * 512) + ((((int)threadIdx.x) & 15) * 32)) + (((((((int)threadIdx.x) & 31) >> 4) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 16)) + 1024)])), (&(A_local_2[0])));
    #pragma unroll
    for (int i_17 = 0; i_17 < 4; ++i_17) {
      tl::ptx_ldmatrix_x4((&(((fp8_e4_t*)B_shared)[((((((((int)threadIdx.x) >> 6) * 2048) + (i_17 * 512)) + (((((int)threadIdx.x) & 31) >> 4) * 256)) + ((((int)threadIdx.x) & 7) * 32)) + (((((((int)threadIdx.x) & 15) >> 3) + ((((int)threadIdx.x) & 7) >> 2)) & 1) * 16))])), (&(B_local_2[(i_17 * 16)])));
    }
    for (int j_2 = 0; j_2 < 4; ++j_2) {
      tl::mma_sync<tl::DataType::kFloat8_e4m3, tl::DataType::kFloat8_e4m3, tl::DataType::kFloat32, 16, 8, 32, false, true>(reinterpret_cast<float*>(C_local + (j_2 * 8)), reinterpret_cast<const unsigned*>(A_local_2 + 0), reinterpret_cast<const unsigned*>(B_local_2 + (j_2 * 16)));
      tl::mma_sync<tl::DataType::kFloat8_e4m3, tl::DataType::kFloat8_e4m3, tl::DataType::kFloat32, 16, 8, 32, false, true>(reinterpret_cast<float*>(C_local + ((j_2 * 8) + 4)), reinterpret_cast<const unsigned*>(A_local_2 + 0), reinterpret_cast<const unsigned*>(B_local_2 + ((j_2 * 16) + 8)));
    }
  }
  #pragma unroll
  for (int i_18 = 0; i_18 < 16; ++i_18) {
    float2 __13;
      float2 v__11 = *(float2*)(C_local_accum + (i_18 * 2));
      float2 __14;
        float2 __15;
          float2 v__12 = *(float2*)(C_local + (i_18 * 2));
          float2 v__13 = make_float2(scale_a_frag[(i_18 & 1)], scale_a_frag[(i_18 & 1)]);
          __15.x = (v__12.x*v__13.x);
          __15.y = (v__12.y*v__13.y);
        float2 v__14 = *(float2*)(scale_b_frag + ((i_18 >> 1) * 2));
        __14.x = (__15.x*v__14.x);
        __14.y = (__15.y*v__14.y);
      __13.x = (v__11.x+__14.x);
      __13.y = (v__11.y+__14.y);
    *(float2*)(C_local_accum + (i_18 * 2)) = __13;
  }
  #pragma unroll
  for (int i_19 = 0; i_19 < 8; ++i_19) {
    float broadcast_var_4 = 0x0p+0f/*0.000000e+00*/;
    *(float4*)(C_local + (i_19 * 4)) = make_float4(broadcast_var_4, broadcast_var_4, broadcast_var_4, broadcast_var_4);
  }
  __syncthreads();
  #pragma unroll
  for (int i_20 = 0; i_20 < 16; ++i_20) {
    bfloat16_t C_shared_local_cast_6[2];
    uint1 __16;
    float2 v__15 = *(float2*)(C_local_accum + (i_20 * 2));
    (reinterpret_cast<__nv_bfloat162*>(&__16))[0] = __float22bfloat162_rn(((float2*)(&v__15))[0]);
    *(uint1*)(C_shared_local_cast_6 + 0) = __16;
    *(uint1*)(((bfloat16_t*)C_shared) + ((((((((((int)threadIdx.x) & 63) >> 5) * 2048) + ((i_20 & 1) * 1024)) + (((((int)threadIdx.x) & 31) >> 2) * 128)) + ((((int)threadIdx.x) >> 6) * 64)) + ((i_20 >> 1) * 8)) + ((((int)threadIdx.x) & 3) * 2))) = *(uint1*)(C_shared_local_cast_6 + 0);
  }
  __syncthreads();
  #pragma unroll
  for (int i_21 = 0; i_21 < 4; ++i_21) {
    if ((((((int)blockIdx.y) * 32) + (i_21 * 8)) + (((int)threadIdx.x) >> 4)) < M) {
      *(uint4*)(C + (((((((int64_t)((int)blockIdx.y)) * (int64_t)131072) + (((int64_t)i_21) * (int64_t)32768)) + ((((int64_t)((int)threadIdx.x)) >> (int64_t)4) * (int64_t)4096)) + (((int64_t)((int)blockIdx.x)) * (int64_t)128)) + ((((int64_t)((int)threadIdx.x)) & (int64_t)15) * (int64_t)8))) = *(uint4*)(((bfloat16_t*)C_shared) + ((i_21 * 1024) + (((int)threadIdx.x) * 8)));
    }
  }
}

