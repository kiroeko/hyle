import hashlib,json,pathlib,subprocess
repo=pathlib.Path(__file__).resolve().parents[1];folder=repo/'.scratch/validation/cpu-matmul-retirement'
old=json.loads((repo/'.scratch/validation/cpu-rn/manifest.json').read_text())
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
files={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in old['files'] if not name.startswith('.scratch/') and (repo/name).is_file()}
for name in ('consumer.cc','consumer/CMakeLists.txt','windows-overlay.cmake','linux-overlay.cmake'):
    files[(folder/name).relative_to(repo).as_posix()]=hashlib.sha256((folder/name).read_bytes()).hexdigest()
removed=['src/compute/matmul_kernel_impl.h','src/compute/matmul_kernels.h']
files['samples/package/graph/cpu_executor/main.cc']=hashlib.sha256((repo/'samples/package/graph/cpu_executor/main.cc').read_bytes()).hexdigest()
(folder/'manifest.json').write_text(json.dumps({'candidate':candidate,'files':files,'removed':removed},indent=2)+'\n',encoding='utf-8',newline='\n')
for platform in ('windows','linux'):
    text=(repo/('.scratch/cpu-rn-'+platform+'.py')).read_text().replace('cpu-rn','cpu-matmul-retirement')
    text=text.replace('cpu-ggml-isa-'+"'"+"+stage",'cpu-matmul-retirement-'+"'"+"+stage")
    text=text.replace("Path('/root/hyle-scratch/cpu-ggml-isa-delivery')", "Path('/root/hyle-scratch/cpu-matmul-retirement-delivery')")
    text=text.replace('CpuDefaultContext.*:*Rope*:*Scatter*','CpuDefaultContext.*:*MatMul*')
    text=text.replace('CpuGraph.*:CpuDefaultGraph.*:*Rope*:*Scatter*-CpuDefaultGraph.D5*','CpuGraph.*:CpuDefaultGraph.*:*MatMul*-CpuDefaultGraph.D5*')
    text=text.replace("(out/'source-identity.json').write_text", "for name in manifest['removed']:\n dest=(source/name).resolve();assert dest.is_relative_to(source)\n if dest.exists():dest.unlink()\n(out/'source-identity.json').write_text")
    text=text.replace("run('provider-tests'", "run('compute-core-tests',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-L','^compute$','-LE','headers','-j','1','--output-junit',out/'compute.xml'])\n run('provider-tests'")
    executable='hyle_graph_route_cpu_cpu_executor_test'+('.exe' if platform=='windows' else '')
    text=text.replace(" run('shared-source-ordinary'" if platform=='windows' else " run('static-source-ordinary'", " run('cpu-executor-consumer',[build/'bin/"+executable+"'])\n"+(" run('shared-source-ordinary'" if platform=='windows' else " run('static-source-ordinary'"))
    # Existing fixture models are local; bind them for affected Qwen projection.
    if platform=='windows':text=text.replace("overlay=fixture/'windows-overlay.cmake'", "env['HYLE_D5_QWEN35_FIXTURE']=str(repo/'.scratch/d5-qwen35-six-profile-fixture')\noverlay=fixture/'windows-overlay.cmake'")
    # Static producer source stays canonical-forwarded; protect frozen P1 SDK.
    if platform=='windows':
        text=text.replace("Path('C:/hv/cpu-ggml-isa-'+stage+'-sdk')", "Path('C:/hv/cpu-matmul-retirement-'+stage+'-sdk')")
    path=repo/('.scratch/cpu-mm-'+platform+'.py');path.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'candidate':candidate,'inputs':len(files),'deleted':removed}))
