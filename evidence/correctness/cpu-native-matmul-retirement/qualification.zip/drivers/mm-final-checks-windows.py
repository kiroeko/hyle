exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-matmul-retirement/windows';records=json.loads((out/'receipt.json').read_text());candidate='7157655201df3b63619a4e5b11dfe272bcf35273'
run('core-fixture-test-configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('core-fixture-followup-build',['cmake','--build',build,'--target','hyle_compute_test','--parallel','2'])
run('core-fixture-followup-test',[build/'bin/hyle_compute_test.exe','--gtest_output=xml:'+str(out/'compute-followup.xml')])
