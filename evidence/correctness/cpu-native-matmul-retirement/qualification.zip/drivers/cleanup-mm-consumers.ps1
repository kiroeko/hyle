$ErrorActionPreference = 'Stop'
$taskRoots = @('C:\hv\cpu-matmul-retirement-shared-consumer', 'C:\hv\cpu-matmul-retirement-static-consumer')
$taskExpectedSource = 'C:/public/project-hyle/hyle/.scratch/validation/cpu-matmul-retirement/consumer'
$taskReceipts = @()
foreach ($taskRoot in $taskRoots) {
  $taskResolved = (Resolve-Path -LiteralPath $taskRoot).Path
  if ($taskResolved -ne $taskRoot -or -not $taskResolved.StartsWith('C:\hv\cpu-matmul-retirement-')) { throw 'Unexpected cleanup target' }
  $taskItems = @(Get-ChildItem -LiteralPath $taskResolved -Recurse -Force)
  if ((Get-Item -LiteralPath $taskResolved).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse root' }
  if ($taskItems | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }) { throw 'Reparse child' }
  $taskCache = Get-Content -LiteralPath (Join-Path $taskResolved 'CMakeCache.txt')
  if (-not ($taskCache -contains "CMAKE_HOME_DIRECTORY:INTERNAL=$taskExpectedSource")) { throw 'Wrong CMake owner' }
  $taskBytes = ($taskItems | Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
  Remove-Item -LiteralPath $taskResolved -Recurse -Force
  $taskReceipts += @{ path = $taskResolved; logical_bytes = $taskBytes; removed = -not (Test-Path -LiteralPath $taskResolved) }
}
$taskReceipts | ConvertTo-Json | Set-Content -LiteralPath 'C:\public\project-hyle\hyle\.scratch\validation\cpu-matmul-retirement\cleanup-windows.json' -Encoding utf8
$taskReceipts | ConvertTo-Json
