import pathlib
repo=pathlib.Path(__file__).resolve().parents[1]
folder=repo/'.scratch/validation/cpu-matmul-retirement';folder.mkdir(parents=True,exist_ok=True)
source=(repo/'.scratch/validation/cpu-native-numeric-retirement/consumer.cc').read_text().split('double activate(')[0]
source=source.replace('#include "hyle/graph/cpu.h"','#include "hyle/graph/cpu.h"\n#include "hyle/compute/providers/ggml_cpu.h"\n#include "hyle/compute/providers/onednn.h"')
source=source.replace('if (prepared.provider().id != c::aten_cpu::kProviderId)', 'if (prepared.provider().id != c::aten_cpu::kProviderId && prepared.provider().id != c::ggml_cpu::kProviderId && prepared.provider().id != c::onednn::kProviderId)')
source=source.replace('take(compiled.report.step(i)).provider.id == c::aten_cpu::kProviderId;', '(take(compiled.report.step(i)).provider.id == c::aten_cpu::kProviderId || take(compiled.report.step(i)).provider.id == c::ggml_cpu::kProviderId || take(compiled.report.step(i)).provider.id == c::onednn::kProviderId);')
source=source.replace('  auto invocation = take(prepared.create_invocation());','''  m::Buffer workspace;
  if(prepared.runtime_properties().workspace_owner==c::ProviderWorkspaceOwner::kCaller){
    const auto requirement=prepared.workspace_requirement();
    if(requirement.size) workspace=take(m::Buffer::create(m::system_resource(),requirement.size,requirement.alignment));
  }
  auto invocation = take(prepared.create_invocation(workspace.view()));''')
source=source.replace('  auto gi = take(compiled.executable.create_invocation());','''  g::CompileOptions strict{};
  strict.invocation_storage=g::InvocationStorageLimits{.max_bytes=1U<<20};
  if(g::compile(logical,gc,strict)) std::exit(12);
  auto gi = take(compiled.executable.create_invocation());''')
source=source.replace('  auto gi = take(compiled.executable.create_invocation());', '''  if(inputs[0].rank()>4){
    g::CompileOptions prepared_only{};
    prepared_only.provider_replay=g::ProviderReplayPolicy::kRequirePrepared;
    if(g::compile(logical,gc,prepared_only)) std::exit(11);
  }
  auto gi = take(compiled.executable.create_invocation());''')
source+=r'''
void matrix(const c::TensorDesc &a,const c::TensorDesc &b,int batches=1){
 const auto rows=std::size_t(a.dimensions()[a.rank()-2]),inner=std::size_t(a.dimensions().back()),cols=std::size_t(b.dimensions().back());
 const std::array ds{a,b};
 journey(c::Operation(c::MatMul{}),ds,
  [&](auto &buffers,int seed){std::vector<float> x(take(a.element_count())),w(take(b.element_count()));for(std::size_t i=0;i<x.size();++i)x[i]=float(int(i%7)-3+seed)/4;for(std::size_t i=0;i<w.size();++i)w[i]=float(int(i%5)-2)/4;write<float>(buffers[0],a,x);write<float>(buffers[1],b,w);},
  [&](const auto &out,int seed){std::vector<float> expected(std::size_t(batches)*rows*cols,0);for(std::size_t batch=0;batch<std::size_t(batches);++batch)for(std::size_t row=0;row<rows;++row)for(std::size_t col=0;col<cols;++col)for(std::size_t k=0;k<inner;++k)expected[(batch*rows+row)*cols+col]+=float(int(((batch*rows+row)*inner+k)%7)-3+seed)/4*float(int((k*cols+col)%5)-2)/4;compare(out,expected);});
}
int main(){
 const auto f=c::DataType::kFloat32;
 matrix(desc(f,{2,3}),desc(f,{3,4}));
 matrix(desc(f,{2,3}),take(desc(f,{4,3}).transposed()));
 matrix(desc(f,{2,2,3}),desc(f,{1,3,4}),2);
 matrix(desc(f,{1,2,1,2,3}),desc(f,{1,1,1,3,4}),2);
 matrix(desc(f,{2,0}),desc(f,{0,4}));
 matrix(desc(f,{0,3}),desc(f,{3,4}));
 std::puts("PASS ordinary mature MatMul Direct/Graph, row/transpose/broadcast/rank5/K0/empty, two changed replays and close; Native and high-rank prepared-only decline");
}
'''
(folder/'consumer.cc').write_text(source,encoding='utf-8',newline='\n')
consumer=folder/'consumer';consumer.mkdir(exist_ok=True)
(consumer/'CMakeLists.txt').write_bytes((repo/'.scratch/validation/cpu-rn/consumer/CMakeLists.txt').read_bytes())
for platform in ('windows','linux'):
    old=(repo/'.scratch/validation/cpu-rn'/(platform+'-overlay.cmake')).read_text()
    (folder/(platform+'-overlay.cmake')).write_text(old.replace('cpu-rn','cpu-matmul-retirement'),encoding='utf-8',newline='\n')
print('Prepared one ordinary consumer for all source/installed journeys')
