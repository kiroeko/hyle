#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/providers/onednn.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> value) {
  if (!value) {
    std::fprintf(stderr, "%.*s\n", int(value.error().message().size()),
                 value.error().message().data());
    std::exit(2);
  }
  return std::move(*value);
}
void require(hyle::Status value) {
  if (!value.ok()) {
    std::fprintf(stderr, "%.*s\n", int(value.message().size()),
                 value.message().data());
    std::exit(2);
  }
}
c::TensorDesc desc(c::DataType type,
                   std::initializer_list<std::int64_t> dimensions,
                   bool odd = false) {
  if (!odd)
    return take(
        c::TensorDesc::dense(type, {dimensions.begin(), dimensions.size()}));
  std::vector<std::int64_t> strides(dimensions.size());
  auto n = std::int64_t(c::data_type_size(type) + 1);
  for (std::size_t i = dimensions.size(); i-- > 0;) {
    strides[i] = n;
    n = n * dimensions.begin()[i] + 1;
  }
  return take(c::TensorDesc::strided_bytes(
      type, {dimensions.begin(), dimensions.size()}, strides));
}
m::Buffer allocate(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
std::size_t offset(const c::TensorDesc &d, std::size_t linear) {
  std::size_t out = 0;
  for (std::size_t i = d.rank(); i-- > 0;) {
    out += linear % std::size_t(d.dimensions()[i]) *
           std::size_t(d.byte_strides()[i]);
    linear /= std::size_t(d.dimensions()[i]);
  }
  return out;
}
template <class T>
void write(m::Buffer &b, const c::TensorDesc &d, std::span<const T> values) {
  std::vector<std::byte> bytes(b.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    std::memcpy(bytes.data() + offset(d, i), &values[i], sizeof(T));
  require(b.view().write(bytes));
}
void compare(const m::Buffer &b, std::span<const float> expected) {
  std::vector<float> x(expected.size());
  require(b.view().read(std::as_writable_bytes(std::span(x))));
  for (std::size_t i = 0; i < x.size(); ++i) {
    bool match = std::isnan(expected[i]) ? std::isnan(x[i])
                 : std::isinf(expected[i])
                     ? x[i] == expected[i]
                     : std::abs(x[i] - expected[i]) <=
                           1e-6F + std::abs(expected[i]) * 8e-5F;
    if (!match) {
      std::fprintf(stderr, "Mismatch %zu actual=%g expected=%g\n", i, x[i],
                   expected[i]);
      std::exit(3);
    }
  }
}
template <class Fill, class Check>
void journey(c::Operation op, std::span<const c::TensorDesc> inputs, Fill fill,
             Check check) {
  std::vector<m::Buffer> buffers;
  for (const auto &d : inputs)
    buffers.push_back(allocate(d));
  auto context = take(c::cpu::create_context());
  auto queue = take(context.create_queue());
  const auto output = take(c::infer_single_output(op, inputs));
  auto native_context = take(c::Context::create(c::cpu::device(), c::native::provider()));
  auto declined = c::prepare(native_context, op, inputs, std::span(&output, 1), m::system_resource());
  if (declined || !declined.error().IsUnimplemented()) std::exit(9);
  auto prepared = take(c::prepare(context, op, inputs, std::span(&output, 1),
                                  m::system_resource()));
  if (prepared.provider().id != c::aten_cpu::kProviderId && prepared.provider().id != c::ggml_cpu::kProviderId && prepared.provider().id != c::onednn::kProviderId) {
    std::fprintf(stderr, "Unqualified default carrier %.*s\n",
                 int(prepared.provider().name.size()),
                 prepared.provider().name.data());
    std::exit(4);
  }
  m::Buffer workspace;
  if(prepared.runtime_properties().workspace_owner==c::ProviderWorkspaceOwner::kCaller){
    const auto requirement=prepared.workspace_requirement();
    if(requirement.size) workspace=take(m::Buffer::create(m::system_resource(),requirement.size,requirement.alignment));
  }
  auto invocation = take(prepared.create_invocation(workspace.view()));
  auto direct = allocate(output), graph_output = allocate(output);
  std::vector<c::ConstTensorView> views;
  for (std::size_t i = 0; i < inputs.size(); ++i)
    views.push_back(
        take(c::ConstTensorView::create(inputs[i], buffers[i].view())));
  const std::array destination{
      take(c::TensorView::create(output, direct.view()))};
  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> ids;
  for (const auto &d : inputs)
    ids.push_back(take(builder.input(d)));
  auto node = take(builder.add_node(op, ids));
  auto result = take(builder.result(node));
  auto final = take(builder.add(c::Copy{}, result));
  require(builder.publish(final));
  auto logical = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto gq = take(gc.create_queue());
  auto compiled = take(g::compile(logical, gc));
  const std::array only_native{c::native::kProviderId};
  g::CompileOptions restricted{};
  restricted.allowed_providers = only_native;
  if (g::compile(logical, gc, restricted)) std::exit(10);
  g::CompileOptions strict{};
  strict.invocation_storage=g::InvocationStorageLimits{.max_bytes=1U<<20};
  if(g::compile(logical,gc,strict)) std::exit(12);
  if(inputs[0].rank()>4){
    g::CompileOptions prepared_only{};
    prepared_only.provider_replay=g::ProviderReplayPolicy::kRequirePrepared;
    if(g::compile(logical,gc,prepared_only)) std::exit(11);
  }
  auto gi = take(compiled.executable.create_invocation());
  bool aten = false;
  for (std::size_t i = 0; i < compiled.report.step_count(); ++i)
    aten |=
        (take(compiled.report.step(i)).provider.id == c::aten_cpu::kProviderId || take(compiled.report.step(i)).provider.id == c::ggml_cpu::kProviderId || take(compiled.report.step(i)).provider.id == c::onednn::kProviderId);
  if (!aten)
    std::exit(5);
  for (std::size_t i = 0; i < ids.size(); ++i)
    require(gi.bind(ids[i], views[i]));
  require(
      gi.bind(final, take(c::TensorView::create(output, graph_output.view()))));
  const std::array lanes{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(gi.prepare_replay(lanes));
  for (int replay = 0; replay < 2; ++replay) {
    fill(buffers, replay);
    require(take(invocation.submit(queue, views, destination)).wait());
    require(take(gi.submit(gq)).wait());
    check(direct, replay);
    check(graph_output, replay);
  }
  require(context.close());
  require(gc.close());
  if (invocation.submit(queue, views, destination) || gi.submit(gq))
    std::exit(6);
}


void matrix(const c::TensorDesc &a,const c::TensorDesc &b,int batches=1){
 const auto rows=std::size_t(a.dimensions()[a.rank()-2]),inner=std::size_t(a.dimensions().back()),cols=std::size_t(b.dimensions().back());
 const std::array ds{a,b};
 journey(c::Operation(c::MatMul{}),ds,
  [&](auto &buffers,int seed){std::vector<float> x(take(a.element_count())),w(take(b.element_count()));for(std::size_t i=0;i<x.size();++i)x[i]=float(int(i%7)-3+seed)/4;for(std::size_t i=0;i<w.size();++i)w[i]=float(int(i%5)-2)/4;write<float>(buffers[0],a,x);write<float>(buffers[1],b,w);},
  [&](const auto &out,int seed){std::vector<float> expected(std::size_t(batches)*rows*cols,0);for(std::size_t batch=0;batch<std::size_t(batches);++batch)for(std::size_t row=0;row<rows;++row)for(std::size_t col=0;col<cols;++col)for(std::size_t k=0;k<inner;++k)expected[(batch*rows+row)*cols+col]+=float(int(((batch*rows+row)*inner+k)%7)-3+seed)/4*float(int((k*cols+col)%5)-2)/4;compare(out,expected);});
}
int main(){
 const auto f=c::DataType::kFloat32;
 matrix(desc(f,{2,3}),desc(f,{3,4}));
 matrix(desc(f,{2,3}),take(desc(f,{4,3}).transposed()));
 matrix(desc(f,{2,2,3}),desc(f,{1,3,4}),2);
 matrix(desc(f,{1,2,1,2,3}),desc(f,{1,1,1,3,4}),2);
 matrix(desc(f,{2,0}),desc(f,{0,4}));
 matrix(desc(f,{0,3}),desc(f,{3,4}));
 std::puts("PASS ordinary mature MatMul Direct/Graph, row/transpose/broadcast/rank5/K0/empty, two changed replays and close; Native and high-rank prepared-only decline");
}
