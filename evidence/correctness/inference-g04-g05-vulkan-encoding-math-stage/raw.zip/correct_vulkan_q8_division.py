from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parents[3]
manifest_path = ROOT / 'third_party/ggml_vulkan_runtime/patches.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
name = 'src/ggml-vulkan/vulkan-shaders/copy_to_quant.comp'
preview = ROOT / '.scratch/inference-gaps/g04-g05/vulkan-native/patched-preview' / name
raw = preview.read_bytes()
entry = next(item for item in manifest['files'] if item['path'] == name)
assert hashlib.sha256(raw).hexdigest() == entry['after_sha256']
before = """        precise float exact_d = amax / 127.0f;
        precise float exact_id = exact_d != 0.0f ? 1.0f / exact_d : 0.0f;"""
after = """        precise float exact_d = amax / 127.0f;
        // Native shader division may be approximate. Residual correction
        // retains the reference's two distinct F32 rounded quotients.
        precise float d_residual = fma(-exact_d, 127.0f, amax);
        exact_d = fma(d_residual, 1.0f / 127.0f, exact_d);
        precise float exact_id = exact_d != 0.0f ? 1.0f / exact_d : 0.0f;
        if (exact_d != 0.0f) {
            precise float id_residual = fma(-exact_id, exact_d, 1.0f);
            exact_id = fma(id_residual, exact_id, exact_id);
        }"""
assert raw.count(before.encode()) == 1
raw = raw.replace(before.encode(), after.encode())
entry['edits'].append({'before': before, 'after': after})
entry['after_sha256'] = hashlib.sha256(raw).hexdigest()
preview.write_bytes(raw)
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
directory = ROOT / 'third_party/ggml_vulkan_runtime'
tree = ''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n'
    for p in sorted(directory.rglob('*'), key=lambda p:p.relative_to(directory).as_posix()) if p.is_file())
digest = hashlib.sha256(tree.encode()).hexdigest()
lock = ROOT / 'cmake/HyleDependencyLock.json'
raw = lock.read_bytes()
start = raw.index(b'"name": "ggml_vulkan_runtime_patches"')
offset = raw.index(b'"tree_sha256": "', start) + len(b'"tree_sha256": "')
lock.write_bytes(raw[:offset]+digest.encode()+raw[offset+64:])
print(digest)
