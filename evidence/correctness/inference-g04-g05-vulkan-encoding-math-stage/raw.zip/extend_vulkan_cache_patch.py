from pathlib import Path
import difflib,hashlib,json

ROOT=Path(__file__).resolve().parents[3]
UPSTREAM=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
PATH=ROOT/'third_party/ggml_vulkan_runtime/patches.json'
PREVIEW=ROOT/'.scratch/inference-gaps/g04-g05/vulkan-native/patched-preview'
manifest=json.loads(PATH.read_text(encoding='utf-8'));texts={};initial={}
def read(name):
 if name not in texts:
  raw=(UPSTREAM/name).read_bytes().replace(b'\r\n',b'\n')
  entry=next((p for p in manifest['files'] if p['path']==name),None)
  if entry:
   assert hashlib.sha256(raw).hexdigest()==entry['before_sha256'],name
   for edit in entry['edits']:
    before=edit['before'].encode();assert raw.count(before)==1,(name,before[:100])
    raw=raw.replace(before,edit['after'].encode(),1)
   assert hashlib.sha256(raw).hexdigest()==entry['after_sha256'],name
  texts[name]=initial[name]=raw.decode()
 return texts[name]
def replace(name,before,after,count=1):
 text=read(name);assert text.count(before)==count,(name,before[:120],text.count(before))
 texts[name]=text.replace(before,after)
host='src/ggml-vulkan/ggml-vulkan.cpp'
replace(host,'    const bool hyle_paged = dst->src[5] != nullptr &&',
 '    const bool hyle_cache = dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionCacheSlot] ==\n'
 '        hyle::compute::ggml_vulkan::bridge::kFlashAttentionCache;\n'
 '    const bool hyle_paged = dst->src[5] != nullptr &&')
replace(host,'    const uint32_t KV = hyle_paged ?', '    const uint32_t KV = (hyle_paged || hyle_cache) ?')
replace(host,'''    if (hyle_paged) {
        GGML_ASSERT(hyle_full_f32 && !mask && !sinks && !use_mask_opt);
        fa_pipeline_state.flags |= 16u;
        if (dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionCausalSlot]) {
            fa_pipeline_state.flags |= 32u;
        }
    }''','''    if (hyle_paged || hyle_cache) {
        GGML_ASSERT(hyle_full_f32 && !mask && !sinks && !use_mask_opt);
        if (hyle_paged) fa_pipeline_state.flags |= 16u;
        if (hyle_cache) fa_pipeline_state.flags |= 128u;
        if (dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionCausalSlot])
            fa_pipeline_state.flags |= 32u;
        if (hyle_cache && dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionWindowSlot] >= 0)
            fa_pipeline_state.flags |= 64u;
    }''')
replace(host,'hyle_paged ? uint32_t(neq1) : nem1,', '(hyle_paged || hyle_cache) ? uint32_t(neq1) : nem1,')
replace(host,'hyle_paged ? uint32_t(dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionTableOffsetSlot]) : nem2,',
 '(hyle_paged || hyle_cache) ? uint32_t(dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionTableOffsetSlot]) : nem2,')
replace(host,'hyle_paged ? 1u : nem3,',
 'hyle_cache ? uint32_t(dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionWindowSlot] + 1) : (hyle_paged ? 1u : nem3),')
replace(host,'op->src[1]->type != GGML_TYPE_F16 || op->src[2]->type != GGML_TYPE_F16 ||',
 '(op->src[1]->type != GGML_TYPE_F16 && op->src[1]->type != GGML_TYPE_Q8_0) ||\n'
 '                        op->src[2]->type != op->src[1]->type ||')
replace(host,'if (HSK != HSV || (HSK != 64 && HSK != 128 && HSK != 256) ||',
 'if ((HSK != HSV && !(HSK == 64 && HSV == 128)) || (HSK != 64 && HSK != 128 && HSK != 256) ||')
replace(host,'(op->src[1]->type != GGML_TYPE_F16 && op->src[1]->type != GGML_TYPE_F32) ||',
 '(op->src[1]->type != GGML_TYPE_F16 && op->src[1]->type != GGML_TYPE_F32 && op->src[1]->type != GGML_TYPE_Q8_0) ||')
replace(host,'(op->src[2]->type != GGML_TYPE_F16 && op->src[2]->type != GGML_TYPE_F32)) {',
 '(op->src[2]->type != GGML_TYPE_F16 && op->src[2]->type != GGML_TYPE_F32 && op->src[2]->type != GGML_TYPE_Q8_0)) {')
# Existing copy push constants have four unused scalar fields. Only this
# tagged dirty producer chooses byte-exact Q8 rounding; ordinary copies keep
# the upstream shader semantics and pipeline.
replace(host,'''    vk_op_unary_push_constants p = vk_op_unary_push_constants_init(src0, dst, ne);
    ggml_vk_op_f32(ctx, subctx, src0, nullptr, nullptr, nullptr, dst, GGML_OP_CPY, std::move(p));''',
 '''    vk_op_unary_push_constants p = vk_op_unary_push_constants_init(src0, dst, ne);
    if (dst->type == GGML_TYPE_Q8_0 && dst->op_params[hyle::compute::ggml_vulkan::bridge::kCacheEncoderCopySlot] ==
        hyle::compute::ggml_vulkan::bridge::kCacheEncoderCopyExact) p.param4 = 1.0f;
    ggml_vk_op_f32(ctx, subctx, src0, nullptr, nullptr, nullptr, dst, GGML_OP_CPY, std::move(p));''')
shader='src/ggml-vulkan/vulkan-shaders/flash_attn.comp'
replace(shader,'const bool HYLE_CAUSAL = (Flags & 32u) != 0;',
 'const bool HYLE_CAUSAL = (Flags & 32u) != 0;\n'
 'const bool HYLE_WINDOW = (Flags & 64u) != 0;\n'
 'const bool HYLE_CACHE = (Flags & 128u) != 0;')
replace(shader,'if (!HYLE_PAGED) return logical_row;',
 'if (!HYLE_PAGED) return logical_row + (HYLE_CACHE ? p.nem2 : 0u);')
replace(shader,'    [[dont_unroll]]\n    for (uint32_t j = start_j;',
 '''    if (HYLE_WINDOW) {
        uint first_query = p.gqa_ratio > 1 ? gqa_iq1 : i * Br;
        uint last_query = p.gqa_ratio > 1 ? first_query : min(p.nem1 - 1u, i * Br + Br - 1u);
        uint first_key = uint(max(0, int(KV - p.nem1 + first_query) - int(p.nem3 - 1u)));
        uint last_key = KV - p.nem1 + last_query + 1u;
        start_j = max(start_j, first_key / Bc);
        end_j = min(end_j, CEIL_DIV(last_key, Bc));
    }
    [[dont_unroll]]
    for (uint32_t j = start_j;''')
replace(shader,'if (j * Bc + c * cols_per_iter + col_tid > KV - p.nem1 + query_row) {',
 '''uint position = KV - p.nem1 + query_row;
                    uint key_row = j * Bc + c * cols_per_iter + col_tid;
                    if (key_row > position || (HYLE_WINDOW && int(key_row) < max(0, int(position) - int(p.nem3 - 1u)))) {''')
copy='src/ggml-vulkan/vulkan-shaders/copy_to_quant.comp'
replace(copy,'        data_q[dst_idx].qs[j] = int8_t(round(x0));',
 '''        float rounded = round(x0);
#ifndef SET_ROWS
        if (p.param4 == 1.0f) {
            float magnitude = abs(x0), base = floor(magnitude);
            rounded = sign(x0) * (base + float(magnitude - base >= 0.5f));
        }
#endif
        data_q[dst_idx].qs[j] = int8_t(rounded);''')
for name,after in texts.items():
 entry=next((p for p in manifest['files'] if p['path']==name),None)
 if entry is None:
  raw=(UPSTREAM/name).read_bytes().replace(b'\r\n',b'\n')
  entry={'path':name,'before_sha256':hashlib.sha256(raw).hexdigest(),'edits':[]};manifest['files'].append(entry)
 old,new=initial[name].splitlines(keepends=True),after.splitlines(keepends=True);current=initial[name]
 for tag,i1,i2,j1,j2 in reversed(difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes()):
  if tag=='equal':continue
  lo,hi=max(0,i1-1),min(len(old),i2+1);before=''.join(old[lo:hi])
  while current.count(before)!=1:
   if lo>0:lo-=1
   elif hi<len(old):hi+=1
   else:raise AssertionError((name,'nonunique'))
   before=''.join(old[lo:hi])
  replacement=''.join(old[lo:i1])+''.join(new[j1:j2])+''.join(old[i2:hi])
  entry['edits'].append({'before':before,'after':replacement});current=current.replace(before,replacement,1)
 assert current==after,name
 entry['after_sha256']=hashlib.sha256(after.encode()).hexdigest()
 file=PREVIEW/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(after.encode())
PATH.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
directory=ROOT/'third_party/ggml_vulkan_runtime'
tree=''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(b"\r\n",b"\n")).hexdigest()}\n'
 for p in sorted(directory.rglob('*'),key=lambda p:p.relative_to(directory).as_posix()) if p.is_file())
lock=ROOT/'cmake/HyleDependencyLock.json';raw=lock.read_bytes()
start=raw.index(b'"name": "ggml_vulkan_runtime_patches"');index=raw.index(b'"tree_sha256": "',start)+len(b'"tree_sha256": "')
digest=hashlib.sha256(tree.encode()).hexdigest();lock.write_bytes(raw[:index]+digest.encode()+raw[index+64:])
print(json.dumps({'files':len(texts),'tree_sha256':digest}))
