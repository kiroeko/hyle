from pathlib import Path
import hashlib,json,subprocess,sys,zipfile

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'.scratch/inference-gaps/g04-g05/vulkan-native'
OUT.mkdir(exist_ok=True)
attempt=sys.argv[1];archive=OUT/f'source-{attempt}.zip';assert not archive.exists()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for path in sorted(set(paths)):
  if path.startswith(('evidence/','.scratch/','.git')):continue
  file=ROOT/path
  if not file.is_file():continue
  raw=file.read_bytes();inputs.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest()});package.writestr(path,raw)
 package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
remote='/Users/kiro/hyle-scratch/compute-unified/g04-g05-vulkan-cache'
host='kiro@172.22.10.198'
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp',str(archive),str(OUT.parent/'vulkan_cache_air.py'),host+':'+remote+'/'],check=True)
code=subprocess.run(['ssh','-o','BatchMode=yes',host,'python3',remote+'/vulkan_cache_air.py',attempt]).returncode
subprocess.run(['scp',host+':'+remote+f'/result-{attempt}.json',host+':'+remote+f'/job-{attempt}.json',str(OUT)],check=True)
subprocess.run(['scp',host+':'+remote+f'/*-{attempt}.log',str(OUT)],check=True)
subprocess.run(['scp',host+':'+remote+f'/tests-{attempt}.xml',str(OUT)],check=False)
raise SystemExit(code)
