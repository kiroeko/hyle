from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parents[3]
manifest_path = ROOT / 'third_party/ggml_vulkan_runtime/patches.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
name = 'src/ggml-vulkan/ggml-vulkan.cpp'
preview = ROOT / '.scratch/inference-gaps/g04-g05/vulkan-native/patched-preview' / name
raw = preview.read_bytes()
entry = next(item for item in manifest['files'] if item['path'] == name)
assert hashlib.sha256(raw).hexdigest() == entry['after_sha256']
before = 'uint32_t(dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionWindowSlot] + 1)'
after = '(uint32_t(dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionWindowSlot]) + 1u)'
assert raw.count(before.encode()) == 1
raw = raw.replace(before.encode(), after.encode())
entry['edits'].append({'before': before, 'after': after})
entry['after_sha256'] = hashlib.sha256(raw).hexdigest()
preview.write_bytes(raw)
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
directory = ROOT / 'third_party/ggml_vulkan_runtime'
tree = ''.join(f'{p.relative_to(directory).as_posix()}|{hashlib.sha256(p.read_bytes().replace(bytes([13,10]),bytes([10]))).hexdigest()}\n'
    for p in sorted(directory.rglob('*'), key=lambda p:p.relative_to(directory).as_posix()) if p.is_file())
digest = hashlib.sha256(tree.encode()).hexdigest()
lock = ROOT / 'cmake/HyleDependencyLock.json'
raw = lock.read_bytes()
start = raw.index(b'"name": "ggml_vulkan_runtime_patches"')
offset = raw.index(b'"tree_sha256": "', start) + len(b'"tree_sha256": "')
lock.write_bytes(raw[:offset]+digest.encode()+raw[offset+64:])
print(digest)
