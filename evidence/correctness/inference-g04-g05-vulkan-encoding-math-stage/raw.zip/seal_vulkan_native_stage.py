from pathlib import Path
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
RUN=ROOT/'.scratch/inference-gaps/g04-g05/vulkan-native'
OUT=ROOT/'evidence/correctness/inference-g04-g05-vulkan-encoding-math-stage'
last=int(sys.argv[1])
records=[json.loads((RUN/f'result-{i}.json').read_text(encoding='utf-8')) for i in range(1,last+1)]
assert all(r['state'].startswith('TERMINAL_') for r in records)
assert records[-1]['state']=='TERMINAL_PASS'
xml=ET.parse(RUN/f'tests-{last}.xml').getroot()
assert int(xml.attrib['tests'])==10 and int(xml.attrib['failures'])==0
inputs={p['path']:p['sha256'] for p in records[-1]['inputs'] if p['path'].startswith(
    ('src/compute_route_vulkan/','src/compute_provider_ggml_vulkan/','tests/compute_route_vulkan/','third_party/ggml_vulkan_runtime/')) or p['path']=='cmake/HyleDependencyLock.json'}
for name,digest in inputs.items():
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
manifest=json.loads((ROOT/'third_party/ggml_vulkan_runtime/patches.json').read_text(encoding='utf-8'))
patched=[]
original=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
for entry in manifest['files']:
 file=original/entry['path']
 if not file.exists():continue
 raw=file.read_bytes().replace(b'\r\n',b'\n')
 assert hashlib.sha256(raw).hexdigest()==entry['before_sha256'],entry['path']
 for edit in entry['edits']:
  before=edit['before'].encode();assert raw.count(before)==1,(entry['path'],before[:100])
  raw=raw.replace(before,edit['after'].encode(),1)
 assert hashlib.sha256(raw).hexdigest()==entry['after_sha256'],entry['path']
 patched.append({'path':entry['path'],'after_sha256':entry['after_sha256']})
OUT.mkdir(parents=True,exist_ok=False)
result={'kind':'G04_G05_VULKAN_ENCODING_AND_NATIVE_MATH_SOURCE_STAGE',
 'verdict':'PASS_FINITE_MACBOOK_AIR_SOURCE_DOMAIN','owners_remain':'AUDITED; whole G04/G05 not accepted',
 'identity':records[-1]['identity'],'delivery':'Actual shared shipping source target; no HYLE_TESTING, canonical Windows one-way archives; original build-local ggml Vulkan patch',
 'input_sha256':inputs,'verified_patch_derivations':patched,'tests':{'final':10},
 'qualified':[
  'Q8_0 encoder bytes for F16/BF16/F32: zero blocks, exact ties and signed nextafter(.5) boundary',
  'NaN/Inf and finite F32 scale overflow accepted then reported by original Results numeric status',
  'Actual direct paged/ragged Q8 physical roots, F16 Q/output, D64/D128/D256 and independent (64,128)',
  'Causal inclusive window -1/0/15/16/INT32_MAX, full noncausal Q33/35 over KV31/33',
  'D256 Q1/65 long prefill; shared/reordered logical274 over physical256; independent double oracle',
  '8192-row Q8 high-value cancellation Q1/Q65: direct F32 block decode and partial storage',
  '8192-row Q8/plain window -1/0/16/-1 specialization and bounded effective scans',
  'Empty paged/ragged Q8 independent-Dv output [0,8,128]',
  'Original plain coupled/unbounded paged/ragged D64/D128/D256'],
 'P0':'Original scalar full-F32 flash tile/row Q8 decode, independent K/V strides, no full-history F16 expansion or QxKV mask. '
      'Ragged retains aligned roots and physical row offset, Q8 pitch2 independent of root descriptor alignment. '
      'Encoder original checked F32 dirty scratch plus original Q8 CPY/reference-roundf tag and dependency-carrying zero-copy carrier view. '
      'No new runtime/queue/controller. Original native private bytes remain UNKNOWN.',
 'review_fixes':[
  'Dependency-carrying ggml_view_4d retains encoded CPY producer; raw ggml_view_tensor had made an empty graph',
  'Zero payload Copy canonicalizes the sliced empty descriptor before independent-Dv reshape; no device payload dispatch',
  'Legal INT32_MAX window packed by unsigned addition, including -1 unsigned wrap to zero',
  'Reference encoder keeps scale/division/product intermediate rounding rather than reassociating across a byte rounding boundary'],
 'not_proven':['Incremental encoder/F2/Graph page consumer journey','static/shared SDK delivery','new-domain sanitizer/OOM/concurrency/retirement matrix',
               'qualified P1','whole G04/G05'],
 'runs':[{k:v for k,v in r.items() if k!='inputs'} for r in records],
 'cumulative_seconds':sum(r['cumulative_seconds'] for r in records)}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for file in sorted(RUN.iterdir()):
  if file.is_file() and file.suffix!='.zip':archive.write(file,file.name)
 for file in sorted((RUN/'patched-preview').rglob('*')):
  if file.is_file():archive.write(file,file.relative_to(RUN).as_posix())
 for name in ['launch_vulkan_cache.py','vulkan_cache_air.py','extend_vulkan_cache_patch.py',
  'refine_vulkan_cache_patch.py','precise_vulkan_q8_patch.py','correct_vulkan_q8_division.py','seal_vulkan_native_stage.py']:
  archive.write(RUN.parent/name,name)
print(json.dumps({'tests':10,'cumulative_seconds':result['cumulative_seconds']}))
