import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
out = repo / '.scratch/validation/cpu-standard-build/integration'
out.mkdir(parents=True, exist_ok=True)
ctypes.windll.kernel32.SetErrorMode(1 | 2 | 0x8000)
flags = dict(creationflags=subprocess.CREATE_NO_WINDOW)
env = dict(os.environ, VSLANG='1033', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2')
env_result = subprocess.run(['cmd', '/d', '/c', str(repo / '.scratch/validation/d5-cpu-apple-official-binding/3c22b7b9f230-tests/environment.cmd')],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, **flags)
env_result.check_returncode()
for line in env_result.stdout.decode(errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key] = value
records = json.loads((out/'receipt.json').read_text())

def run(name, args):
    started = time.monotonic()
    with (out / (name + '.log')).open('wb') as log:
        result = subprocess.run(list(map(str, args)), cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, **flags)
    records.append(dict(name=name, args=list(map(str,args)), returncode=result.returncode, seconds=round(time.monotonic()-started,3)))
    (out / 'receipt.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(records[-1]), flush=True)
    if result.returncode:
        print((out / (name + '.log')).read_text(encoding='utf-8',errors='replace')[-6000:],flush=True)
        raise SystemExit(result.returncode)

cache = Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1'
sdk = cache / 'sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch'
old_sdk = repo / '.scratch/validation/d5-cpu-apple-official-sources/cpu-sdk-full/libtorch'
identities = {}
for name in ('asmjit.dll','c10.dll','fbgemm.dll','libiomp5md.dll','torch_cpu.dll','torch.dll','uv.dll'):
    old_sha = hashlib.sha256((old_sdk / 'lib' / name).read_bytes()).hexdigest()
    new_sha = hashlib.sha256((sdk / 'lib' / name).read_bytes()).hexdigest()
    assert old_sha == new_sha, name
    identities[name] = new_sha
(out / 'runtime-unchanged.json').write_text(json.dumps(identities,indent=2)+'\n')

project=out/'root-override-source';project.mkdir(exist_ok=True)
project.joinpath('CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.25)\nproject(cpu_root_override LANGUAGES CXX)\nset(HYLE_SOURCE_DIR "'+repo.as_posix()+'")\nset(HYLE_TARGET_PROCESSOR x86_64)\ninclude("'+(repo/'cmake/HyleFeatureOption.cmake').as_posix()+'")\ninclude("'+(repo/'src/compute_provider_native/torch_cpu_sdk.cmake').as_posix()+'")\nif(NOT Torch_DIR STREQUAL HYLE_COMPUTE_TORCH_CPU_ROOT+"/share/cmake/Torch")\nendif()\n',encoding='utf-8')
# Avoid an expression-language fake assertion: inspect the actual imported library.
s=project.joinpath('CMakeLists.txt').read_text(encoding='utf-8');s=s[:s.index('if(NOT Torch_DIR')]+ 'get_target_property(_lib torch_cpu IMPORTED_IMPLIB_RELEASE)\nif(NOT _lib MATCHES "'+sdk.as_posix()+'/lib/torch_cpu.lib")\nmessage(FATAL_ERROR "Wrong root: ${_lib}")\nendif()\n'
project.joinpath('CMakeLists.txt').write_text(s,encoding='utf-8')
run('explicit-root-beats-stale-package-cache',['cmake','-S',project,'-B','C:/hv/cpu-root-override','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPUTE_TORCH_CPU_ROOT='+str(sdk),'-DTorch_DIR=C:/must-not-use/Torch','-DCaffe2_DIR=C:/must-not-use/Caffe2','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
copy=Path('C:/hv/d5cd/source-tree')
for name in ('torch_cpu_fetch.cmake','torch_cpu_sdk.cmake','HyleTorchCpuSdkConfig.cmake'):
 (copy/'src/compute_provider_native'/name).write_bytes((repo/'src/compute_provider_native'/name).read_bytes())
for stage,producer in [('static',Path('C:/hv/d5cp/source-build/hyle')),('shared',repo/'.scratch/build-compute-v2-dev')]:
 prefix=Path('C:/hv/cpu-standard-'+stage+'-sdk')
 run(stage+'-install-final-helper',['cmake','--install',producer,'--prefix',prefix])
 run(stage+'-consumer-managed-reconfigure',['cmake','-S','C:/hv/d5cp/consumer','-B','C:/hv/d5cp/official-'+stage+'-consumer','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('component-contract',['cmake','-DHYLE_SOURCE_DIR='+str(repo),'-DHYLE_SMOKE_ROOT=C:/hv/cpu-standard-component','-P',repo/'cmake/HyleCiComponentContract.cmake'])
