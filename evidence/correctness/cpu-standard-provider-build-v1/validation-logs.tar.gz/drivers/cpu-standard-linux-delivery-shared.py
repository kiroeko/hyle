import ctypes,subprocess
ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-standard-build/linux/delivery-shared-final.py'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print(r.stdout.decode(errors='replace'),flush=True)
raise SystemExit(r.returncode)
