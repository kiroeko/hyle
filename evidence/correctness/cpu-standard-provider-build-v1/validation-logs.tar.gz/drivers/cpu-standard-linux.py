import ctypes,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'.scratch/validation/cpu-standard-build/linux';out.mkdir(parents=True,exist_ok=True)
script=out/'resolve.cmake'
script.write_text('''cmake_minimum_required(VERSION 3.25)
set(CMAKE_SYSTEM_NAME Linux)
set(HYLE_COMPUTE_TORCH_CPU_ARCHIVE /mnt/c/public/project-hyle/hyle/.scratch/validation/d5-cpu-apple-official-sources/libtorch-linux-cxx11-cpu-2.8.0.zip)
set(FETCHCONTENT_FULLY_DISCONNECTED ON)
include(/mnt/c/public/project-hyle/hyle/src/compute_provider_native/torch_cpu_fetch.cmake)
hyle_resolve_torch_cpu_sdk(/mnt/c/public/project-hyle/hyle/cmake/HyleDependencyLock.json sdk)
file(WRITE /mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-standard-build/linux/resolved-root.txt "${sdk}\\n")
''')
run=out/'run.py'
run.write_text('''import hashlib,json,subprocess,time
from pathlib import Path
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-standard-build/linux')
r=[]
for name in ['local-archive','disconnected-cache-hit']:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:
  result=subprocess.run(['cmake','-P',str(out/'resolve.cmake')],stdout=log,stderr=subprocess.STDOUT)
 r.append(dict(name=name,returncode=result.returncode,seconds=round(time.monotonic()-start,3)))
 (out/'receipt.json').write_text(json.dumps(r,indent=2)+'\\n');print(r[-1],flush=True)
 if result.returncode:raise SystemExit(result.returncode)
sdk=Path((out/'resolved-root.txt').read_text().strip())
old=Path('/root/hyle-scratch/libtorch-cpu-2.8.0/libtorch')
verified={}
for p in (old/'lib').glob('*.so*'):
 if not p.is_file():continue
 sha=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
 assert sha==hashlib.file_digest((sdk/'lib'/p.name).open('rb'),'sha256').hexdigest(),p.name
 verified[p.name]=sha
(out/'runtime-unchanged.json').write_text(json.dumps(verified,indent=2)+'\\n')
project=out/'sdk-consumer';project.mkdir(exist_ok=True)
(project/'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.25)\\nproject(cpu_sdk_resolution LANGUAGES CXX)\\nset(CMAKE_PREFIX_PATH "'+str(sdk)+'")\\nfind_package(Torch 2.8.0 EXACT CONFIG REQUIRED)\\nif(CAFFE2_USE_CUDA)\\nmessage(FATAL_ERROR "CUDA SDK")\\nendif()\\n')
start=time.monotonic()
with (out/'find-torch.log').open('wb') as log:
 result=subprocess.run(['cmake','-S',str(project),'-B',str(project/'build'),'-G','Ninja'],stdout=log,stderr=subprocess.STDOUT)
r.append(dict(name='find-torch-cpu',returncode=result.returncode,seconds=round(time.monotonic()-start,3)))
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\\n');print(r[-1],flush=True)
raise SystemExit(result.returncode)
''')
ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
result=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-standard-build/linux/run.py'],creationflags=subprocess.CREATE_NO_WINDOW)
raise SystemExit(result.returncode)
