import ctypes
import json
import os
import subprocess
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / '.scratch/validation/cpu-standard-build/sdk-fetch'
out.mkdir(parents=True, exist_ok=True)
cache = Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1'
archive = root / '.scratch/validation/d5-cpu-apple-official-sources/libtorch-cpu-2.8.0.zip'
helper = root / 'src/compute_provider_native/torch_cpu_fetch.cmake'
lock = root / 'cmake/HyleDependencyLock.json'
ctypes.windll.kernel32.SetErrorMode(1 | 2 | 0x8000)
records = []

def run(name, variables, *, success=True, diagnostic=None):
    script = out / (name + '.cmake')
    lines = ['cmake_minimum_required(VERSION 3.25)', 'set(CMAKE_SYSTEM_NAME Windows)']
    lines += [f'set({key} [==[{str(value).replace(chr(92), chr(47))}]==])' for key, value in variables.items()]
    lines += [f'include("{helper.as_posix()}")', f'hyle_resolve_torch_cpu_sdk("{lock.as_posix()}" sdk)', 'message(STATUS "RESOLVED=${sdk}")']
    script.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    started = time.monotonic()
    result = subprocess.run(['cmake', '-P', str(script)], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    (out / (name + '.log')).write_bytes(result.stdout)
    output = result.stdout.decode('utf-8', errors='replace')
    passed = (result.returncode == 0) == success and (diagnostic is None or diagnostic in output)
    records.append(dict(name=name, returncode=result.returncode, expected_success=success,
                        diagnostic=diagnostic, seconds=round(time.monotonic()-started, 3), verdict='PASS' if passed else 'FAIL'))
    (out / 'receipt.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(records[-1]), flush=True)
    if not passed:
        raise RuntimeError(output[-6000:])

run('local-archive', dict(HYLE_DEP_SOURCE_CACHE=cache, HYLE_COMPUTE_TORCH_CPU_ARCHIVE=archive,
                          FETCHCONTENT_FULLY_DISCONNECTED='ON'))
run('disconnected-cache-hit', dict(HYLE_DEP_SOURCE_CACHE=cache, FETCHCONTENT_FULLY_DISCONNECTED='ON'), diagnostic='reusing locked CPU SDK')
run('disconnected-cache-miss', dict(HYLE_DEP_SOURCE_CACHE=out / 'empty-cache', FETCHCONTENT_FULLY_DISCONNECTED='ON'),
    success=False, diagnostic='LibTorch CPU SDK missing while disconnected')
bad = out / 'wrong-archive.zip'
bad.write_bytes(b'not the qualified SDK')
run('wrong-archive-with-valid-cache', dict(HYLE_DEP_SOURCE_CACHE=cache, HYLE_COMPUTE_TORCH_CPU_ARCHIVE=bad),
    success=False, diagnostic='SHA256 differs from the lock')
run('explicit-missing-root', dict(HYLE_COMPUTE_TORCH_CPU_ROOT=out / 'missing-root'),
    success=False, diagnostic='Incomplete LibTorch CPU SDK')
gpu = out / 'gpu-root'
(gpu / 'share/cmake/Torch').mkdir(parents=True, exist_ok=True)
(gpu / 'build-version').write_text('2.8.0+cu128\n')
(gpu / 'share/cmake/Torch/TorchConfig.cmake').write_text('message(FATAL_ERROR "GPU SDK was probed")\n')
run('gpu-sdk-rejected-before-probe', dict(HYLE_COMPUTE_TORCH_CPU_ROOT=gpu),
    success=False, diagnostic='CUDA Torch is not accepted')
