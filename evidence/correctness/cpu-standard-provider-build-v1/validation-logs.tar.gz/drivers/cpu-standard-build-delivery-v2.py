import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
out = repo / '.scratch/validation/cpu-standard-build/integration'
out.mkdir(parents=True, exist_ok=True)
ctypes.windll.kernel32.SetErrorMode(1 | 2 | 0x8000)
flags = dict(creationflags=subprocess.CREATE_NO_WINDOW)
env = dict(os.environ, VSLANG='1033', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2')
env_result = subprocess.run(['cmd', '/d', '/c', str(repo / '.scratch/validation/d5-cpu-apple-official-binding/3c22b7b9f230-tests/environment.cmd')],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, **flags)
env_result.check_returncode()
for line in env_result.stdout.decode(errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key] = value
records = json.loads((out/'receipt.json').read_text())

def run(name, args):
    started = time.monotonic()
    with (out / (name + '.log')).open('wb') as log:
        result = subprocess.run(list(map(str, args)), cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, **flags)
    records.append(dict(name=name, args=list(map(str,args)), returncode=result.returncode, seconds=round(time.monotonic()-started,3)))
    (out / 'receipt.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(records[-1]), flush=True)
    if result.returncode:
        print((out / (name + '.log')).read_text(encoding='utf-8',errors='replace')[-6000:],flush=True)
        raise SystemExit(result.returncode)

cache = Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1'
sdk = cache / 'sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch'
old_sdk = repo / '.scratch/validation/d5-cpu-apple-official-sources/cpu-sdk-full/libtorch'
identities = {}
for name in ('asmjit.dll','c10.dll','fbgemm.dll','libiomp5md.dll','torch_cpu.dll','torch.dll','uv.dll'):
    old_sha = hashlib.sha256((old_sdk / 'lib' / name).read_bytes()).hexdigest()
    new_sha = hashlib.sha256((sdk / 'lib' / name).read_bytes()).hexdigest()
    assert old_sha == new_sha, name
    identities[name] = new_sha
(out / 'runtime-unchanged.json').write_text(json.dumps(identities,indent=2)+'\n')

run('runtime-staging-contract-v2', ['cmake','-DHYLE_SOURCE_DIR='+str(repo), '-DHYLE_SMOKE_ROOT=C:/hv/cpu-standard-staging-contract-v2', '-P',repo/'cmake/HyleCiRuntimeStagingContract.cmake'])
copy=Path('C:/hv/d5cd/source-tree').resolve()
(copy/'cmake/HyleRuntimeStaging.cmake').write_bytes((repo/'cmake/HyleRuntimeStaging.cmake').read_bytes())
# Reconfigure only the unchanged source consumer after the staging helper fix.
run('source-staging-reconfigure',['cmake','-S','C:/hv/d5cp/consumer','-B','C:/hv/d5cp/source-build','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('source-staging-build',['cmake','--build','C:/hv/d5cp/source-build','--target','d5_cpu_delivery','--parallel','2'])
prefix=Path('C:/hv/cpu-standard-static-sdk')
run('static-install-v2',['cmake','--install','C:/hv/d5cp/source-build/hyle','--prefix',prefix])
for stage in ('static','shared'):
 if stage=='shared':
  producer=repo/'.scratch/build-compute-v2-dev'
  prefix=Path('C:/hv/cpu-standard-shared-sdk')
  run('shared-producer-configure',['cmake','-S',repo,'-B',producer,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC=OFF','-UHYLE_COMPUTE_TORCH_CPU_ROOT','-UTorch_DIR','-DCMAKE_PREFIX_PATH=','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
  run('shared-producer-build',['cmake','--build',producer,'--parallel','2'])
  run('shared-install',['cmake','--install',producer,'--prefix',prefix])
 build=Path('C:/hv/d5cp/official-'+stage+'-consumer')
 run(stage+'-consumer-configure-v2',['cmake','-S','C:/hv/d5cp/consumer','-B',build,'-DD5_SOURCE_ROOT=','-DCMAKE_PREFIX_PATH='+str(prefix),'-UHYLE_COMPUTE_TORCH_CPU_ROOT','-UTorch_DIR','-UHyle_DIR','-UHyleTorchCpuSdk_DIR','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(stage+'-consumer-build-v2',['cmake','--build',build,'--target','d5_cpu_delivery','--parallel','2'])
 for name in identities:
  assert (build/name).is_file(),name
  assert hashlib.sha256((build/name).read_bytes()).hexdigest()==identities[name],name
 # Remove producer/compiler/SDK paths from the execution search path.
 original_path=env['PATH']; env['PATH']=os.environ['SystemRoot']+'/System32;'+os.environ['SystemRoot']
 run(stage+'-consumer-direct-graph-v2',[r'C:/Program Files/CMake/bin/ctest.exe','--test-dir',build,'--no-tests=error','--output-on-failure','--output-junit',out/(stage+'-tests.xml'),'-R','^d5_cpu_(direct|graph)$'])
 env['PATH']=original_path
