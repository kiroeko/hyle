import hashlib,json,subprocess,tarfile
from pathlib import Path
repo=Path(__file__).resolve().parents[1]
out=repo/'evidence/correctness/cpu-standard-provider-build-v1'
out.mkdir(parents=True,exist_ok=True)
scratch=repo/'.scratch/validation/cpu-standard-build'
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
tree=subprocess.check_output(['git','rev-parse',candidate+'^{tree}'],cwd=repo,text=True).strip()
files=[]
for directory in ('integration','sdk-fetch','linux'):
    files.extend(p for p in (scratch/directory).rglob('*') if p.is_file() and
                 p.suffix in ('.json','.log','.xml','.cmake','.py','.cc') and
                 'build' not in p.relative_to(scratch/directory).parts)
files.append(scratch/'loc.json')
scripts=list(repo.glob('.scratch/*cpu-standard*.py'))
scripts+=list(repo.glob('.scratch/check-cpu-sdk*.py'))
with tarfile.open(out/'validation-logs.tar.gz','w:gz') as tar:
    for path in sorted(files):tar.add(path,arcname=path.relative_to(scratch).as_posix())
    for path in sorted(scripts):tar.add(path,arcname='drivers/'+path.name)
product={}
for name in ('CMakePresets.json','cmake/HyleCiRuntimeStagingContract.cmake','cmake/HyleDependencyLock.json','cmake/HyleRuntimeStaging.cmake','src/compute_provider_native/CMakeLists.txt','src/compute_provider_native/HyleTorchCpuSdkConfig.cmake','src/compute_provider_native/torch_cpu_sdk.cmake','src/compute_provider_native/torch_cpu_fetch.cmake'):
    product[name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
metadata=dict(candidate=candidate,tree=tree,canonical=str(repo),product_inputs_sha256=product,
    archive_sha256=hashlib.sha256((out/'validation-logs.tar.gz').read_bytes()).hexdigest(),
    selector='Conservative global plan preserved separately; not a selector-run PASS.',
    precommit_checks='Native C++ mathematics and original SDK bytes unchanged. Targeted CMake and loader checks ran on these product contents before freezing this commit; final generic helper comment differs only in prose.',
    limits=['Default live HTTP download not exercised: previously downloaded locked original archives reused.',
            'WSL installed consumers cover FP8 Direct/Graph with two replays; not the Windows 28-test suite.',
            'Some corrective reruns overwrote same-name raw logs. Receipt history retains exit codes; README distinguishes observed defects from harness mistakes.'])
(out/'identity.json').write_bytes((json.dumps(metadata,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps(dict(candidate=candidate,archive_bytes=(out/'validation-logs.tar.gz').stat().st_size)))
