import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
out = repo / '.scratch/validation/cpu-standard-build/integration'
out.mkdir(parents=True, exist_ok=True)
ctypes.windll.kernel32.SetErrorMode(1 | 2 | 0x8000)
flags = dict(creationflags=subprocess.CREATE_NO_WINDOW)
env = dict(os.environ, VSLANG='1033', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2')
env_result = subprocess.run(['cmd', '/d', '/c', str(repo / '.scratch/validation/d5-cpu-apple-official-binding/3c22b7b9f230-tests/environment.cmd')],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, **flags)
env_result.check_returncode()
for line in env_result.stdout.decode(errors='replace').splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key] = value
records = []

def run(name, args):
    started = time.monotonic()
    with (out / (name + '.log')).open('wb') as log:
        result = subprocess.run(list(map(str, args)), cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, **flags)
    records.append(dict(name=name, args=list(map(str,args)), returncode=result.returncode, seconds=round(time.monotonic()-started,3)))
    (out / 'receipt.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(records[-1]), flush=True)
    if result.returncode:
        print((out / (name + '.log')).read_text(encoding='utf-8',errors='replace')[-6000:],flush=True)
        raise SystemExit(result.returncode)

cache = Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1'
sdk = cache / 'sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch'
old_sdk = repo / '.scratch/validation/d5-cpu-apple-official-sources/cpu-sdk-full/libtorch'
identities = {}
for name in ('asmjit.dll','c10.dll','fbgemm.dll','libiomp5md.dll','torch_cpu.dll','torch.dll','uv.dll'):
    old_sha = hashlib.sha256((old_sdk / 'lib' / name).read_bytes()).hexdigest()
    new_sha = hashlib.sha256((sdk / 'lib' / name).read_bytes()).hexdigest()
    assert old_sha == new_sha, name
    identities[name] = new_sha
(out / 'runtime-unchanged.json').write_text(json.dumps(identities,indent=2)+'\n')

# The successful standard-preset configure is retained from the first batch.
run('runtime-staging-contract', ['cmake','-DHYLE_SOURCE_DIR='+str(repo), '-DHYLE_SMOKE_ROOT=C:/hv/cpu-standard-staging-contract',
    '-P',repo / 'cmake/HyleCiRuntimeStagingContract.cmake'])

# A disposable source validation copy, never an upstream source of product changes.
copy = Path('C:/hv/d5cd/source-tree').resolve()
assert copy == Path('C:/hv/d5cd/source-tree') and copy.is_dir()
for name in ('cmake/HyleDependencyLock.json','cmake/HyleRuntimeStaging.cmake',
             'src/compute_provider_native/CMakeLists.txt','src/compute_provider_native/torch_cpu_sdk.cmake',
             'src/compute_provider_native/torch_cpu_fetch.cmake','src/compute_provider_native/HyleTorchCpuSdkConfig.cmake'):
    destination = (copy / name).resolve()
    assert destination.is_relative_to(copy)
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((repo / name).read_bytes())

build = Path('C:/hv/d5cp/source-build')
run('source-reconfigure-default-sdk', ['cmake','-S','C:/hv/d5cp/consumer','-B',build,
    '-UHYLE_COMPUTE_TORCH_CPU_ROOT','-UTorch_DIR','-DCMAKE_PREFIX_PATH=', '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('source-build', ['cmake','--build',build,'--target','d5_cpu_delivery','--parallel','2'])
for name in identities:
    assert (build/name).is_file(), name
    assert hashlib.sha256((build/name).read_bytes()).hexdigest() == identities[name], name
run('source-direct-graph', ['ctest','--test-dir',build,'--no-tests=error','--output-on-failure','-R','^d5_cpu_(direct|graph)$'])
prefix = Path('C:/hv/cpu-standard-static-sdk')
run('static-install', ['cmake','--install',build / 'hyle','--prefix',prefix])
export = (prefix/'lib/cmake/Hyle/HyleTargets.cmake').read_text()
assert str(old_sdk).replace('\\','/') not in export
assert str(sdk).replace('\\','/') not in export
assert '/lib/c10.lib' not in export
(out/'export-no-producer-sdk-path.json').write_text(json.dumps(dict(verdict='PASS', scope='Native Torch links are imported identities; SDK paths not baked into export'),indent=2)+'\n')

run('static-consumer-configure-hyle-only', ['cmake','-S','C:/hv/d5cp/consumer','-B','C:/hv/d5cp/official-static-consumer',
    '-DD5_SOURCE_ROOT=', '-DCMAKE_PREFIX_PATH='+str(prefix), '-UHYLE_COMPUTE_TORCH_CPU_ROOT','-UTorch_DIR',
    '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('static-consumer-build',['cmake','--build','C:/hv/d5cp/official-static-consumer','--target','d5_cpu_delivery','--parallel','2'])
for name in identities:
    assert (Path('C:/hv/d5cp/official-static-consumer') / name).is_file(), name
run('static-consumer-direct-graph',['ctest','--test-dir','C:/hv/d5cp/official-static-consumer','--no-tests=error',
    '--output-on-failure','-R','^d5_cpu_(direct|graph)$'])
