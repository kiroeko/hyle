import ctypes
import json
import os
import subprocess
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / '.scratch/validation/cpu-standard-build/sdk-fetch'
out.mkdir(parents=True, exist_ok=True)
cache = Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1'
archive = root / '.scratch/validation/d5-cpu-apple-official-sources/libtorch-cpu-2.8.0.zip'
helper = root / 'src/compute_provider_native/torch_cpu_fetch.cmake'
lock = root / 'cmake/HyleDependencyLock.json'
ctypes.windll.kernel32.SetErrorMode(1 | 2 | 0x8000)
records = json.loads((out/'receipt.json').read_text())

def run(name, variables, *, success=True, diagnostic=None):
    script = out / (name + '.cmake')
    lines = ['cmake_minimum_required(VERSION 3.25)', 'set(CMAKE_SYSTEM_NAME Windows)']
    lines += [f'set({key} [==[{str(value).replace(chr(92), chr(47))}]==])' for key, value in variables.items()]
    lines += [f'include("{helper.as_posix()}")', f'hyle_resolve_torch_cpu_sdk("{lock.as_posix()}" sdk)', 'message(STATUS "RESOLVED=${sdk}")']
    script.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    started = time.monotonic()
    result = subprocess.run(['cmake', '-P', str(script)], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    (out / (name + '.log')).write_bytes(result.stdout)
    output = result.stdout.decode('utf-8', errors='replace')
    passed = (result.returncode == 0) == success and (diagnostic is None or diagnostic in output)
    records.append(dict(name=name, returncode=result.returncode, expected_success=success,
                        diagnostic=diagnostic, seconds=round(time.monotonic()-started, 3), verdict='PASS' if passed else 'FAIL'))
    (out / 'receipt.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(records[-1]), flush=True)
    if not passed:
        raise RuntimeError(output[-6000:])

# Actual option/platform guards; these must return before any SDK lookup.
def guard(name, mode, system, processor, success, diagnostic):
 script=out/(name+'.cmake')
 script.write_text('cmake_minimum_required(VERSION 3.25)\n'+f'set(CMAKE_SYSTEM_NAME {system})\nset(HYLE_TARGET_PROCESSOR {processor})\nset(HYLE_COMPUTE_TORCH_CPU {mode})\nset(HYLE_SOURCE_DIR missing)\n'+f'include("{(root/"cmake/HyleFeatureOption.cmake").as_posix()}")\ninclude("{(root/"src/compute_provider_native/torch_cpu_sdk.cmake").as_posix()}")\n'+ 'if(HYLE_COMPUTE_TORCH_CPU_ENABLED)\nmessage(FATAL_ERROR "Unexpected enabled SDK")\nendif()\n')
 result=subprocess.run(['cmake','-P',str(script)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/(name+'.log')).write_bytes(result.stdout)
 passed=(result.returncode==0)==success and (not diagnostic or diagnostic in result.stdout.decode(errors='replace'))
 records.append(dict(name=name,returncode=result.returncode,expected_success=success,verdict='PASS' if passed else 'FAIL'))
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 assert passed,result.stdout
for name,mode,system,processor,success,diagnostic in [
 ('cpu-sdk-off-no-probe','OFF','Windows','x86_64',True,None),
 ('unsupported-auto-no-probe','AUTO','Darwin','arm64',True,None),
 ('unsupported-on-diagnostic','ON','Darwin','arm64',False,'requires Windows/Linux x86_64')]:
 guard(name,mode,system,processor,success,diagnostic)
fake=out/'corrupt-managed'
(fake/'libtorch/share/cmake/Torch').mkdir(parents=True,exist_ok=True)
(fake/'libtorch/build-version').write_text('2.8.0+cpu\n')
(fake/'libtorch/share/cmake/Torch/TorchConfig.cmake').write_text('# must never load corrupted SDK\n')
(fake/'.hyle-torch-sdk-stage').write_text('owned test fixture\n')
(fake/'sha256.txt').write_text('0'*64+'  build-version\n')
run('managed-torch-dir-cannot-bypass-manifest',dict(Torch_DIR=fake/'libtorch/share/cmake/Torch'),success=False,diagnostic='Corrupt cached LibTorch SDK')
