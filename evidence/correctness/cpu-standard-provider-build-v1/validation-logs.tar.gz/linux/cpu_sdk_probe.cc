#include <array>
#include <cstdint>
#include <cstdio>
#include <span>
#include <utility>
#include "hyle/compute/cpu.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/graph/cpu.h"
#include "hyle/mem/buffer.h"
namespace c=hyle::compute; namespace g=hyle::graph;
int main() {
 auto desc=c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{1,128}).value();
 auto op=c::model_ops::block_quantization_roundtrip(c::model_ops::BlockQuantizationFormat::kFloat8E4M3Block128);
 std::array<std::uint16_t,128> values{};values.fill(0x3f80);
 auto input=hyle::mem::Buffer::create(hyle::mem::system_resource(),256,64).value();
 auto output=hyle::mem::Buffer::create(hyle::mem::system_resource(),256,64).value();
 if(!input.view().write(std::as_bytes(std::span(values))).ok())return 1;
 auto x=c::ConstTensorView::create(desc,input.view()).value();auto y=c::TensorView::create(desc,output.view()).value();
 auto check=[&]{std::array<std::uint16_t,128> actual{};return output.view().read(std::as_writable_bytes(std::span(actual))).ok()&&actual==values;};
 {
 auto context=c::cpu::create_context().value();auto queue=context.create_queue().value();
 auto p=c::prepare(context,op,std::span(&desc,1),std::span(&desc,1),hyle::mem::system_resource()).value();
 auto lane=p.create_invocation().value();
 for(int i=0;i<2;++i){auto done=lane.submit(queue,x,y);if(!done||!done->wait().ok()||!check())return 2;}
 }
 {
 auto builder=g::GraphBuilder::create().value();auto xi=builder.input(desc).value();auto yi=builder.add(op,xi).value();
 if(!builder.publish(yi).ok())return 3;auto logical=std::move(builder).finish().value();
 auto context=g::cpu::create_context().value();auto queue=context.create_queue().value();auto compiled=g::compile(logical,context).value();
 auto lane=compiled.executable.create_invocation().value();if(!lane.bind(xi,x).ok()||!lane.bind(yi,y).ok())return 4;
 const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&queue}};
 if(!lane.prepare_replay(queues).ok())return 5;
 for(int i=0;i<2;++i){auto done=lane.submit(queue);if(!done){std::fprintf(stderr,"Graph submit: %.*s\n",int(done.error().message().size()),done.error().message().data());return 6;} auto status=done->wait();if(!status.ok()){std::fprintf(stderr,"Graph wait: %.*s\n",int(status.message().size()),status.message().data());return 6;}if(!check()){std::array<std::uint16_t,128> actual{};output.view().read(std::as_writable_bytes(std::span(actual))).IgnoreError();std::fprintf(stderr,"Graph mismatch: expected 0x3f80, actual %x\n",actual[0]);return 6;}}
 }
 std::puts("CPU SDK Direct/Graph FP8 roundtrip replay PASS");
}
