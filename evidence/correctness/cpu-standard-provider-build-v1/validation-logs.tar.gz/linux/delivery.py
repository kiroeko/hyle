import json,os,subprocess,time
from pathlib import Path
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-standard-build/linux')
repo=Path('/mnt/c/public/project-hyle/hyle');source=Path('/root/hyle-scratch/active-cpu-z/source').resolve()
assert source.is_relative_to(Path('/root/hyle-scratch/active-cpu-z').resolve()) and source.is_dir()
for name in ('cmake/HyleDependencyLock.json','cmake/HyleRuntimeStaging.cmake','src/compute_provider_native/CMakeLists.txt','src/compute_provider_native/torch_cpu_sdk.cmake','src/compute_provider_native/torch_cpu_fetch.cmake','src/compute_provider_native/HyleTorchCpuSdkConfig.cmake'):
 dest=(source/name).resolve();assert dest.is_relative_to(source);data=(repo/name).read_bytes();
 if not dest.exists() or dest.read_bytes()!=data:dest.write_bytes(data)
build=source.parent/'build';r=json.loads((out/'delivery-receipt.json').read_text()) if (out/'delivery-receipt.json').exists() else []
os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1';os.environ.pop('LD_LIBRARY_PATH',None)
def run(name,args):
 if name == 'static-producer-configure' and any(step['name']==name and step['returncode']==0 and step['args']==list(map(str,args)) for step in r):
  print('Reusing completed unchanged static producer',name,flush=True);return
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:
  result=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
 r.append(dict(name=name,args=list(map(str,args)),returncode=result.returncode,seconds=round(time.monotonic()-start,3)))
 (out/'delivery-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(r[-1],flush=True)
 if result.returncode:
  print((out/(name+'.log')).read_text(errors='replace')[-6000:],flush=True);raise SystemExit(result.returncode)
for stage in ('static','shared'):
 prefix=Path('/root/hyle-scratch/cpu-standard-delivery')/stage
 run(stage+'-producer-configure',['cmake','-S',source,'-B',build,'-DHYLE_COMPONENTS=compute;graph','-UHYLE_DEV_FACTORS','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if stage=='static' else 'OFF'),'-DHYLE_COMPUTE_TORCH_CPU=AUTO','-DHYLE_COMPUTE_ONEDNN=AUTO','-UHYLE_COMPUTE_TORCH_CPU_ROOT','-UTorch_DIR','-DCMAKE_PREFIX_PATH=','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(out/'overlay.cmake')])
 run(stage+'-producer-build',['cmake','--build',build,'--target','cpu_sdk_probe','-j','2'])
 run(stage+'-source-public-fp8',[build/'bin/cpu_sdk_probe'])
 run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
 consumer=prefix.parent/(stage+'-consumer')
 run(stage+'-consumer-configure',['cmake','-S',out/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(stage+'-consumer-build',['cmake','--build',consumer,'-j','2'])
 run(stage+'-installed-public-fp8',[consumer/'cpu_sdk_probe'])
