# must never load corrupted SDK
