message(FATAL_ERROR "GPU SDK was probed")
