from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parents[3]
scratch = root / '.scratch/validation/m1-ggml-runtime'
dest = root / 'evidence/correctness/compute-llm-moe-m1-ggml-runtime'
candidate = '04368a397859f2d03e71ab005a5d66227a5f9a0f'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

continued = read(scratch / 'continued-result.json')
assert continued['candidate'] == candidate and continued['status'] == 'PASS'
assert len(continued['gates']) == 88
for gate in continued['gates']:
    assert gate['status'] == 'PASS'
    for log in gate['logs']:
        assert sha(scratch / log['path']) == log['sha256']
for name in ['windows-extra-result.json', 'windows-vulkan-delivery-result.json', 'source-package.json']:
    assert read(scratch / name)['status'] == 'PASS', name

remote = [
    ('WSL', 'CPU static native + source/shared/static/relocated SDK', 'wsl-cpu-delivery.log', 'M1-G CPU static resources and source/shared/static SDK PASS'),
    ('MacBook Air', 'CPU static native + source/shared/static/relocated SDK', 'air-cpu-delivery.log', 'M1-G CPU static resources and source/shared/static SDK PASS'),
    ('Mac mini', 'CPU static native + source/shared/static/relocated SDK', 'mini-cpu-delivery.log', 'M1-G CPU static resources and source/shared/static SDK PASS'),
    ('MacBook Air', 'CPU+Vulkan source/shared/static/relocated SDK only', 'air-vulkan-delivery.log', 'HYLE selected product smoke passed: compute'),
    ('MacBook Air', 'Vulkan actual native provider/Compute/Graph resource regression', 'air-vulkan-native.log', 'M1-G Air Vulkan native GPU resources PASS (explicit ON, actual test names checked)'),
]
summary = read(scratch / 'native-summary.json')
for platform, gate, name, marker in remote:
    log = scratch / name
    content = log.read_text(encoding='utf-8', errors='replace')
    assert marker in content, name
    assert '100% tests passed' in content, name
    summary['native_evidence'].append(dict(platform=platform, gate=gate, status='PASS', candidate=candidate, log=name, sha256=sha(log)))
summary['status'] = 'PASS'
summary['unrun'] = []
summary['air_native_correction'] = 'Initial Air script reused CPU-only cache; its five native tests do not prove Vulkan regression. Three SDK consumers used fresh Vulkan-ON builds and passed. Explicit ON plus actual GPU test-name checks reran only the missing native suite; original log retained without rewriting its misleading final marker.'
summary['p0'] = 'PASS: cold context/pool/plan/workspace; allocation counters and exact join/free fixtures; no HYLE search/timing in run; upstream math/fusion/worker loops unchanged. No throughput or provider-winner claim.'
write(scratch / 'native-summary.json', summary)

files = {}
for path in scratch.iterdir():
    if path.is_file() and path.suffix in {'.json', '.log', '.py', '.ps1', '.sh', '.cmake'}:
        files['task/' + path.name] = path
original = read(scratch / 'selected-result.json')
for gate in original['selected_gates']:
    if gate['status'] not in ('PASS', 'FAIL'):
        continue
    receipt = Path(gate['receipt'])
    record = read(receipt)
    files['selector/' + receipt.name] = receipt
    for log in record['logs']:
        path = receipt.parent / log['path']
        assert sha(path) == log['sha256']
        files['selector/' + path.name] = path

dest.mkdir(parents=True, exist_ok=True)
archive = dest / 'raw.zip'
manifest = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        bundle.writestr(name, data)
        manifest.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
shutil.copyfile(scratch / 'loc-current.json', dest / 'implementation-loc.json')
write(dest / 'validation.json', summary)
identity = dict(
    candidate=candidate,
    tree=subprocess.check_output(['git', 'rev-parse', candidate + '^{tree}'], cwd=root, text=True).strip(),
    baseline='9401082b116334ca6dc9cfbd4e426bf11c497e0d',
    tier='P0', status='PASS', p1='NOT_APPLICABLE: resource integration, no provider performance verdict',
    upstream_ggml='456172ec733a135778adcd32d00e576a58232e45',
    source_archive_sha256='2ac8d5b1d13aaee4ddf61f70ba0553f3cb8cc33bf5d96e579adf5642fb096218',
    raw=dict(file='raw.zip', bytes=archive.stat().st_size, sha256=sha(archive), members=manifest),
    corrections=[
        '2c1011cb: POSIX fixture distinguished ggml context free from its backing free; original failing log retained.',
        'c76c041c: explicit developer-factor delimiter/case/whitespace normalization; subsequent build identities retained.',
        '04368a39: Vulkan bridge test directly links migrated metadata owner; 29 prior PASS receipts retain c76 identity; affected gate and 84 formerly unrun gates completed in 88-gate continuation.',
        'Air task script correction: cached native CPU build missed Vulkan ON; no product change, only previously absent native GPU tests executed.'
    ],
    coverage_claim='Private shared resource seam and affected delivery closure only; zero new model/route coverage cells; ggml CPU Provider remains BLOCKED until its own card.',
    red_team=dict(status='PASS', kind='separate final source/evidence review by /root', checks=[
        'Move/reset destroys native context before borrowed backing and joins pool before workspace release; partial prepare returns destroy already-owned resources.',
        'Per-slot graph/plan/pool/workspace; documented no concurrent run/close; shared constants immutable; cancellations complete workers before return.',
        'Capacity checks precede ggml arena use; trusted validated lowering only; arbitrary native graphs not accepted by public SDK.',
        'Private headers not installed; selected native backend targets and licenses in source/static/shared; route-OFF does not fetch ggml.',
        'Exact Vulkan non-resource manifest entries unchanged; upstream CPU math tables/operators/worker loops unchanged; no self-operator research or P1.',
        'Final evidence audit caught Air cached CPU-only native selection; retained original log and required explicit actual GPU test names before closure.'
    ])
)
write(dest / 'identity.json', identity)
print(json.dumps({'status': 'PASS', 'raw_bytes': archive.stat().st_size, 'members': len(files), 'candidate': candidate}))
