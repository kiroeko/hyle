$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logs = Join-Path $canonicalRoot '.scratch\validation\m1-ggml-runtime'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
$env:Path = 'C:\public\tools\glslang;C:\public\tools\hyle-vulkan\1.4.357.0\Bin;' + $env:Path
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -Preset windows-ninja -BinaryDir C:\hyle-scratch\m1g-cpu -ExtraArgs @('--target','help') > (Join-Path $logs 'vulkan-delivery-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Set-Location -LiteralPath $canonicalRoot
$smokeRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\m1g-vd')
$target = [IO.Path]::GetFullPath((Join-Path $smokeRoot 'selected-compute'))
if (-not $target.StartsWith($smokeRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid smoke cleanup path' }
if ((Test-Path -LiteralPath $target) -and ((Get-Item -LiteralPath $target).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected reparse point' }
$env:CMAKE_TOOLCHAIN_FILE = Join-Path $logs 'windows-vulkan-toolchain.cmake'
& python -X utf8 -c 'import ctypes,subprocess,sys; ctypes.windll.kernel32.SetErrorMode(0x8003); sys.exit(subprocess.call(["cmake","-DHYLE_SOURCE_DIR=C:/public/project-hyle/hyle","-DHYLE_SMOKE_ROOT=C:/hyle-scratch/m1g-vd","-DHYLE_SMOKE_COMPONENT=compute","-DHYLE_SMOKE_COMPUTE_ONEDNN=OFF","-DHYLE_SMOKE_GENERATOR=Ninja","-P","cmake/HyleCiSelectedComponentSmoke.cmake"]))'
exit $LASTEXITCODE
