import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd().resolve()
out = root / '.scratch/validation/m1-ggml-runtime'
candidate = '04368a397859f2d03e71ab005a5d66227a5f9a0f'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
ctypes.windll.kernel32.SetErrorMode(0x8003)
common = ['-DCMAKE_BUILD_TYPE=Release', '-DHYLE_DEV_FACTORS=compute_ggml_runtime',
          '-DHYLE_BUILD_TESTS=ON', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_INSTALL=OFF',
          '-DHYLE_COMPUTE_CPU=ON', '-DHYLE_COMPUTE_CUDA=OFF',
          '-DHYLE_COMPUTE_VULKAN=OFF', '-DHYLE_COMPUTE_APPLE=OFF', '-DHYLE_WERROR=ON']
stages = [
 ('windows-static-native', [
   ['cmake', '-S', str(root), '-B', 'C:/hyle-scratch/m1g-cpu', *common, '-DHYLE_STATIC=ON'],
   ['cmake', '--build', 'C:/hyle-scratch/m1g-cpu', '--target', 'hyle_compute_ggml_runtime_tests', '--parallel', '2'],
   ['ctest', '--test-dir', 'C:/hyle-scratch/m1g-cpu', '-L', '^compute_ggml_runtime$', '--output-on-failure', '--timeout', '60']]),
 ('windows-source-archive-native', [
   ['cmake', '-S', 'C:/hyle-scratch/m1g-source/hyle-m1g-source', '-B', 'C:/hyle-scratch/m1g-source-build', '-G', 'Ninja', *common, '-DHYLE_STATIC=OFF'],
   ['cmake', '--build', 'C:/hyle-scratch/m1g-source-build', '--target', 'hyle_compute_ggml_runtime_tests', '--parallel', '2'],
   ['ctest', '--test-dir', 'C:/hyle-scratch/m1g-source-build', '-L', '^compute_ggml_runtime$', '--output-on-failure', '--timeout', '60']]),
 ('windows-route-off', [
   ['cmake', '--build', 'C:/hyle-scratch/m1g-off', '--target', 'hyle_compute_ggml_runtime_tests', '--parallel', '2'],
   ['ctest', '--test-dir', 'C:/hyle-scratch/m1g-off', '-L', '^compute_ggml_runtime$', '--output-on-failure', '--timeout', '60']]),
]
report = {'candidate': candidate, 'status': 'IN_PROGRESS', 'stages': []}
def save():
    (out / 'windows-extra-result.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
for name, commands in stages:
    item = {'id': name, 'status': 'RUNNING', 'logs': []}
    report['stages'].append(item)
    print('RUN ' + name, flush=True)
    save()
    for index, argv in enumerate(commands):
        log = out / (name + '-' + str(index) + '.log')
        with log.open('wb') as stream:
            result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT)
        item['logs'].append({'path': log.name, 'argv': argv, 'exit_code': result.returncode,
                             'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
        if result.returncode:
            item['status'] = report['status'] = 'FAIL'
            save()
            sys.exit(result.returncode)
    item['status'] = 'PASS'
    save()
    print('PASS ' + name, flush=True)
off_ninja = Path('C:/hyle-scratch/m1g-off/build.ninja').read_text(encoding='utf-8')
assert 'ggml-base' not in off_ninja and 'ggml-cpu' not in off_ninja and 'ggml-vulkan' not in off_ninja
report['route_off_vendor_targets'] = 'ABSENT'
report['status'] = 'PASS'
save()
