$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logs = Join-Path $canonicalRoot '.scratch\validation\m1-ggml-runtime'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_PREFIX_PATH = 'C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake'
$env:Path = 'C:\public\tools\glslang;C:\public\tools\hyle-vulkan\1.4.357.0\Bin;' + $env:Path
# Import the ordinary toolchain without compiling another candidate.
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -Preset windows-ninja -BinaryDir C:\hyle-scratch\m1g-cpu -ExtraArgs @('--target','help') > (Join-Path $logs 'selector-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Set-Location -LiteralPath $canonicalRoot
& python -X utf8 -c 'import ctypes,runpy; ctypes.windll.kernel32.SetErrorMode(0x8003); runpy.run_path("scripts/validation-select.py",run_name="__main__")' run --base 9401082b --candidate HEAD --context .scratch/validation/windows-msvc-context.json --scratch C:/hyle-scratch/m1g-g --output .scratch/validation/m1-ggml-runtime/selected-result.json
exit $LASTEXITCODE
