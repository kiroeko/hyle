#!/bin/sh
set -eu
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2
export CTEST_INTERACTIVE_DEBUG_MODE=0
export TRACY_ONLY_LOCALHOST=1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
m1g_source=/Users/kiro/hyle-m1g-2c1011cb
m1g_build=/Users/kiro/hyle-m1g-build
grep '04368a397859f2d03e71ab005a5d66227a5f9a0f' "$m1g_source/SOURCE-MANIFEST.txt"
cmake -S "$m1g_source" -B "$m1g_build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DHYLE_DEV_FACTORS=compute_ggml_runtime,compute_provider_ggml_vulkan,compute_route_vulkan,graph_route_vulkan \
  -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
  -DHYLE_STATIC=OFF -DHYLE_SANITIZER=off -DHYLE_WERROR=ON \
  -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_VULKAN=ON \
  -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF \
  -DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator \
  -DVulkan_INCLUDE_DIR=/opt/homebrew/opt/vulkan-headers/include \
  -DVulkan_LIBRARY=/opt/homebrew/opt/vulkan-loader/lib/libvulkan.dylib \
  -DVulkan_GLSLC_EXECUTABLE=/opt/homebrew/bin/glslc \
  -DSPIRV-Headers_DIR=/opt/homebrew/opt/spirv-headers/share/cmake/SPIRV-Headers
grep '^HYLE_COMPUTE_VULKAN:STRING=ON$' "$m1g_build/CMakeCache.txt"
cmake --build "$m1g_build" --parallel 2 --target \
  hyle_compute_ggml_runtime_tests hyle_compute_provider_ggml_vulkan_tests \
  hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests
ctest --test-dir "$m1g_build" -N -L '^(compute_ggml_runtime|compute_provider_ggml_vulkan|compute_route_vulkan|graph_route_vulkan)$' \
  -LE headers > "$m1g_build/m1g-native-test-list.txt"
cat "$m1g_build/m1g-native-test-list.txt"
for test in hyle_compute_provider_ggml_vulkan_test hyle_compute_route_vulkan_test hyle_graph_route_vulkan_test; do
  grep " $test\$" "$m1g_build/m1g-native-test-list.txt"
done
ctest --test-dir "$m1g_build" -L '^(compute_ggml_runtime|compute_provider_ggml_vulkan|compute_route_vulkan|graph_route_vulkan)$' \
  -LE headers --output-on-failure --timeout 180
printf '%s\n' 'M1-G Air Vulkan native GPU resources PASS (explicit ON, actual test names checked)'
