from pathlib import Path
import shutil

root = Path('/Users/kiro').resolve()
names = (
    'hyle-m1g-archive-6235ddc9', 'hyle-m1g-stage',
    'hyle-m1g-6235ddc9.tar.gz', 'hyle-m1g-fixed.tar.gz',
    'hyle-m1g-final.tar.gz', 'hyle-m1g-validation-delta.tar',
)
for name in names:
    target = root / name
    if not target.exists():
        continue
    assert not target.is_symlink() and target.resolve().parent == root
    if target.is_dir():
        shutil.rmtree(target)
    else:
        target.unlink()
    print('Removed superseded M1-G validation copy:', target)
