#!/bin/sh
set -eu
case "$1" in
  air)
    PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
    m1g_prefix=/Users/kiro
    m1g_source=$m1g_prefix/hyle-m1g-2c1011cb
    m1g_ggml=$m1g_prefix/hyle-m1g-ggml
    m1g_generator=Ninja
    m1g_compiler=/usr/bin/c++
    ;;
  mini)
    PATH=/Users/kiro/hyle-verify-tools/bin:/usr/bin:/bin:/usr/sbin:/sbin
    m1g_prefix=/Users/kiro
    m1g_source=$m1g_prefix/hyle-m1g-2c1011cb
    m1g_ggml=$m1g_prefix/hyle-m1g-ggml
    m1g_generator='Unix Makefiles'
    m1g_compiler=/usr/bin/c++
    ;;
  wsl)
    m1g_prefix=/root
    m1g_source=$m1g_prefix/hyle-m1g-6235ddc9
    m1g_ggml=/root/.cache/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424
    m1g_generator=Ninja
    m1g_compiler=/usr/bin/g++-14
    ;;
  *) exit 2 ;;
esac
export PATH
export CMAKE_BUILD_PARALLEL_LEVEL=2
export CTEST_INTERACTIVE_DEBUG_MODE=0
export TRACY_ONLY_LOCALHOST=1
unset ASAN_OPTIONS UBSAN_OPTIONS TSAN_OPTIONS
grep '04368a397859f2d03e71ab005a5d66227a5f9a0f' "$m1g_source/SOURCE-MANIFEST.txt"
cmake --version
"$m1g_compiler" --version
m1g_build=$m1g_prefix/hyle-m1g-build
cmake -S "$m1g_source" -B "$m1g_build" -G "$m1g_generator" \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER="$m1g_compiler" \
  -DHYLE_DEV_FACTORS=compute_ggml_runtime -DHYLE_BUILD_TESTS=ON \
  -DHYLE_STATIC=ON -DHYLE_SANITIZER=off -DHYLE_INSTALL=OFF \
  -DHYLE_BUILD_BENCH=OFF -DHYLE_COMPUTE_CPU=ON \
  -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_APPLE=OFF \
  -DFETCHCONTENT_SOURCE_DIR_GGML="$m1g_ggml"
cmake --build "$m1g_build" --target hyle_compute_ggml_runtime_tests --parallel 2
ctest --test-dir "$m1g_build" -L '^compute_ggml_runtime$' --output-on-failure --timeout 60
m1g_toolchain=$m1g_prefix/hyle-m1g-cpu-toolchain.cmake
cat > "$m1g_toolchain" <<EOF
set(CMAKE_CXX_COMPILER "$m1g_compiler" CACHE FILEPATH "M1-G validation compiler")
set(FETCHCONTENT_SOURCE_DIR_GGML "$m1g_ggml" CACHE PATH "M1-G locked local source")
set(HYLE_COMPUTE_VULKAN OFF CACHE STRING "CPU-only delivery")
set(HYLE_COMPUTE_APPLE OFF CACHE STRING "CPU-only delivery")
EOF
export CMAKE_TOOLCHAIN_FILE=$m1g_toolchain
cmake -DHYLE_SOURCE_DIR="$m1g_source" \
  -DHYLE_SMOKE_ROOT="$m1g_prefix/hyle-m1g-cpu-sdk" \
  -DHYLE_SMOKE_COMPONENT=compute -DHYLE_SMOKE_COMPUTE_ONEDNN=OFF \
  -DHYLE_SMOKE_GENERATOR="$m1g_generator" \
  -P "$m1g_source/cmake/HyleCiSelectedComponentSmoke.cmake"
printf '%s\n' 'M1-G CPU static resources and source/shared/static SDK PASS'
