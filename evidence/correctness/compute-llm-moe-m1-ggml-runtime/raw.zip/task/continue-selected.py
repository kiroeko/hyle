"""Execute the selector's remaining commands after a test-only link correction."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd().resolve()
out = root / '.scratch/validation/m1-ggml-runtime'
old = json.loads((out / 'selected-result.json').read_text(encoding='utf-8'))
plan = json.loads((out / 'corrected-plan.json').read_text(encoding='utf-8'))
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert candidate == plan['candidate_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only', old['candidate_commit'], candidate], text=True).splitlines()
assert changed == ['tests/compute_route_vulkan/CMakeLists.txt'], changed
scratch = Path('C:/hyle-scratch/m1g-g/f0769631e560fbc2089f').resolve()
build = scratch / 'build-d218cd4f4de787f864fa'
assert 'CMAKE_HOME_DIRECTORY:INTERNAL=' + root.as_posix() in (build / 'CMakeCache.txt').read_text(encoding='utf-8')
for gate in plan['selected_gates']:
    if gate['id'].startswith('delivery:'):
        name = gate['id'].split(':')[1]
        target = (scratch / ('delivery-' + name) / ('selected-' + name)).resolve()
        assert target.is_relative_to(scratch) and not target.is_symlink()
old_pass = {g['id'] for g in old['selected_gates'] if g.get('status') == 'PASS'}
required = [g for g in plan['selected_gates'] if g['id'] not in old_pass or g['id'] in {'docs', 'closure', 'configure'}]
report = {'candidate': candidate, 'prior_candidate': old['candidate_commit'],
          'correction': changed, 'prior_candidate_pass_gates': sorted(old_pass),
          'rule': 'fixture correction: rerun affected gate and finish previously unrun gates; prior receipts retain their original identity',
          'status': 'IN_PROGRESS', 'gates': []}
report_file = out / 'continued-result.json'
def save():
    report_file.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
ctypes.windll.kernel32.SetErrorMode(0x8003)
environment = dict(os.environ)
environment['CMAKE_TOOLCHAIN_FILE'] = str(scratch / 'native-context.cmake')
replace = {'{python}': sys.executable, '{root}': str(root), '{scratch}': str(scratch), '{build}': str(build)}
for gate in required:
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    item = {'id': gate['id'], 'candidate': candidate, 'selector_identity': gate['identity'], 'status': 'RUNNING', 'logs': []}
    report['gates'].append(item)
    save()
    print('RUN ' + gate['id'], flush=True)
    for index, template in enumerate(gate['commands']):
        argv = []
        for token in template:
            for source, destination in replace.items():
                token = token.replace(source, destination)
            argv.append(token)
        log = out / ('continued-' + gate['id'].replace(':', '-') + '-' + str(index) + '.log')
        with log.open('wb') as stream:
            result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, env=environment)
        item['logs'].append({'path': log.name, 'sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'argv': argv, 'exit_code': result.returncode})
        save()
        if result.returncode:
            item['status'] = report['status'] = 'FAIL'
            save()
            print('FAIL ' + gate['id'] + ': ' + str(log), flush=True)
            sys.exit(1)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    item['status'] = 'PASS'
    save()
    print('PASS ' + gate['id'], flush=True)
report['status'] = 'PASS'
save()
