$ErrorActionPreference = 'Stop'
# This copy was created by M1-G prepare_source.py, never used by a build.
$ownedParent = [IO.Path]::GetFullPath('C:\hyle-scratch')
$ownedPath = [IO.Path]::GetFullPath('C:\hyle-scratch\m1g-source')
if ([IO.Path]::GetDirectoryName($ownedPath) -ne $ownedParent) {
  throw 'Cleanup path escaped the task scratch root.'
}
if (Test-Path -LiteralPath $ownedPath) {
  $entry = Get-Item -LiteralPath $ownedPath
  if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) {
    throw 'Refusing to recurse into a reparse point.'
  }
  if (-not (Test-Path -LiteralPath (Join-Path $ownedPath 'src\ggml.c'))) {
    throw 'The expected disposable ggml source copy is missing.'
  }
  Remove-Item -LiteralPath $ownedPath -Recurse -Force
  Write-Output "Removed M1-G disposable source probe: $ownedPath"
}
