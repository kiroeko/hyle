#!/bin/sh
set -eu
export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2
export CTEST_INTERACTIVE_DEBUG_MODE=0
export TRACY_ONLY_LOCALHOST=1
export VK_DRIVER_FILES=/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json
export DYLD_LIBRARY_PATH=/opt/homebrew/opt/vulkan-loader/lib:/opt/homebrew/opt/molten-vk/lib
m1g_source=/Users/kiro/hyle-m1g-2c1011cb
m1g_build=/Users/kiro/hyle-m1g-build
grep '04368a397859f2d03e71ab005a5d66227a5f9a0f' "$m1g_source/SOURCE-MANIFEST.txt"
m1g_toolchain=/Users/kiro/hyle-m1g-vulkan-toolchain.cmake
cat > "$m1g_toolchain" <<'EOF'
set(CMAKE_CXX_COMPILER /usr/bin/c++ CACHE FILEPATH "M1-G validation compiler")
set(FETCHCONTENT_SOURCE_DIR_GGML /Users/kiro/hyle-m1g-ggml CACHE PATH "M1-G locked local source")
set(HYLE_COMPUTE_VULKAN ON CACHE STRING "M1-G combined delivery" FORCE)
set(HYLE_COMPUTE_APPLE OFF CACHE STRING "M1-G scope" FORCE)
set(HYLE_VULKAN_GLSLANG /opt/homebrew/bin/glslangValidator CACHE FILEPATH "Host shader compiler")
set(Vulkan_INCLUDE_DIR /opt/homebrew/opt/vulkan-headers/include CACHE PATH "Vulkan tools")
set(Vulkan_LIBRARY /opt/homebrew/opt/vulkan-loader/lib/libvulkan.dylib CACHE FILEPATH "Vulkan tools")
set(Vulkan_GLSLC_EXECUTABLE /opt/homebrew/bin/glslc CACHE FILEPATH "Vulkan tools")
set(SPIRV-Headers_DIR /opt/homebrew/opt/spirv-headers/share/cmake/SPIRV-Headers CACHE PATH "Vulkan tools")
EOF
export CMAKE_TOOLCHAIN_FILE=$m1g_toolchain
cmake -S "$m1g_source" -B "$m1g_build" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$m1g_toolchain" -DCMAKE_BUILD_TYPE=Release \
  -DHYLE_DEV_FACTORS=compute_ggml_runtime,compute_provider_ggml_vulkan,compute_route_vulkan,graph_route_vulkan \
  -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
  -DHYLE_STATIC=OFF -DHYLE_SANITIZER=off -DHYLE_WERROR=ON \
  -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_COMPUTE_CUDA=OFF
cmake --build "$m1g_build" --parallel 2 --target \
  hyle_compute_ggml_runtime_tests hyle_compute_provider_ggml_vulkan_tests \
  hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests
ctest --test-dir "$m1g_build" -L '^(compute_ggml_runtime|compute_provider_ggml_vulkan|compute_route_vulkan|graph_route_vulkan)$' \
  -LE headers --output-on-failure --timeout 180
cmake -DHYLE_SOURCE_DIR="$m1g_source" -DHYLE_SMOKE_ROOT=/Users/kiro/hyle-m1g-vulkan-sdk \
  -DHYLE_SMOKE_COMPONENT=compute -DHYLE_SMOKE_COMPUTE_ONEDNN=OFF \
  -DHYLE_SMOKE_GENERATOR=Ninja -P "$m1g_source/cmake/HyleCiSelectedComponentSmoke.cmake"
printf '%s\n' 'M1-G Air combined native resources and source/shared/static Vulkan SDK PASS'
