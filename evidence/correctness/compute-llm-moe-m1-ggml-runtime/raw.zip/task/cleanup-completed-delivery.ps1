$ErrorActionPreference = 'Stop'
$scratchRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\m1g-g\f0769631e560fbc2089f').TrimEnd('\')
$report = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'continued-result.json') -Raw | ConvertFrom-Json
$active = Get-CimInstance Win32_Process
foreach ($component in @('compute','container','core','error','graph','io','math','mem','obs','platform','process','sched','simd','time','util')) {
  $gate = $report.gates | Where-Object { $_.id -eq "delivery:$component" -and $_.status -eq 'PASS' }
  if (-not $gate) { continue }
  foreach ($receiptLog in $gate.logs) {
    $logPath = Join-Path $PSScriptRoot $receiptLog.path
    if ((Get-FileHash -LiteralPath $logPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $receiptLog.sha256) { throw 'Delivery log identity mismatch' }
  }
  $target = [IO.Path]::GetFullPath((Join-Path $scratchRoot "delivery-$component\selected-$component"))
  if (-not $target.StartsWith($scratchRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped task scratch root' }
  if (-not (Test-Path -LiteralPath $target)) { continue }
  if ($active | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($target) }) { throw "Completed delivery still has a live process: $target" }
  $entry = Get-Item -LiteralPath $target -Force
  while ($entry.FullName.Length -ge $scratchRoot.Length) {
    if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected reparse point: $($entry.FullName)" }
    $entry = $entry.Parent
  }
  Remove-Item -LiteralPath $target -Recurse -Force
  Write-Output "Removed completed delivery build: $target"
}
