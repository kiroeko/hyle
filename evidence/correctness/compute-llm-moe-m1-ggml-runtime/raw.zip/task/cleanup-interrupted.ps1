$ErrorActionPreference = 'Stop'
$scratchRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\m1g-g').TrimEnd('\')
$target = [IO.Path]::GetFullPath('C:\hyle-scratch\m1g-g\b4577f2c13ea09773bf9')
if (-not $target.StartsWith($scratchRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped task scratch root' }
$active = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($target) }
if ($active) { throw 'Interrupted candidate still has a live process' }
if (Test-Path -LiteralPath $target) {
  $entry = Get-Item -LiteralPath $target -Force
  if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected reparse point' }
  Remove-Item -LiteralPath $target -Recurse -Force
  Write-Output "Removed interrupted validation build: $target"
}
