$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$logs = Join-Path $canonicalRoot '.scratch\validation\m1-ggml-runtime'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$env:TRACY_ONLY_LOCALHOST = '1'
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -Preset windows-ninja -BinaryDir C:\hyle-scratch\m1g-cpu -ExtraArgs @('--target','help') > (Join-Path $logs 'extra-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Set-Location -LiteralPath $canonicalRoot
& python -X utf8 .scratch/validation/m1-ggml-runtime/windows-extra.py
exit $LASTEXITCODE
