$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath('C:\hyle-scratch').TrimEnd('\')
$extra = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'windows-extra-result.json') -Raw | ConvertFrom-Json
$combined = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'windows-vulkan-delivery-result.json') -Raw | ConvertFrom-Json
if ($extra.status -ne 'PASS' -or $combined.status -ne 'PASS') { throw 'Windows validation incomplete' }
$log = Join-Path $PSScriptRoot 'windows-vulkan-delivery.log'
if ((Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash.ToLowerInvariant() -ne $combined.log_sha256) { throw 'Combined log identity mismatch' }
$active = Get-CimInstance Win32_Process
foreach ($relative in @('m1g-cpu','m1g-vk','m1g-off','m1g-source','m1g-source-build','m1g-vd','m1g-g\f0769631e560fbc2089f\build-d218cd4f4de787f864fa','m1g-g\f0769631e560fbc2089f\component')) {
  $target = [IO.Path]::GetFullPath((Join-Path $taskRoot $relative))
  if (-not $target.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped scratch root' }
  if (-not (Test-Path -LiteralPath $target)) { continue }
  if ($active | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($target) }) { throw "Build still has a live process: $target" }
  $entry = Get-Item -LiteralPath $target -Force
  while ($entry.FullName.Length -ge $taskRoot.Length) {
    if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected reparse point: $($entry.FullName)" }
    $entry = $entry.Parent
  }
  Remove-Item -LiteralPath $target -Recurse -Force
  Write-Output "Removed completed Windows build: $target"
}
