import ctypes,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(0x8003);flags={'creationflags':subprocess.CREATE_NO_WINDOW}
vs='C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\Common7\\Tools\\VsDevCmd.bat'
s=subprocess.check_output('"'+os.environ['ComSpec']+'" /d /s /c "call "'+vs+'" -arch=x64 >nul && set"',text=True,**flags)
for line in s.splitlines():
 n,sep,v=line.partition('=')
 if sep and n and (n.lower()!='path' or '\\VC\\Tools\\MSVC\\' in v):os.environ[n]=v
repo=Path.cwd();root=Path('C:/hv/v4w');out=root/'receipts/windows-w2-w3-delta';out.mkdir()
receipt={'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True,**flags).strip(),'steps':[]}
def run(label,cmd,env=None):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),stdout=f,stderr=subprocess.STDOUT,env=env,**flags)
 receipt['steps'].append({'label':label,'argv':list(map(str,cmd)),'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for name in ['src/compute_provider_iree_vulkan/native_program.cc','src/compute_route_vulkan/vulkan_iree.cc']:
 (root/'source-tree'/name).write_bytes((repo/name).read_bytes())
for stage,producer in [('static',root/'source-build'),('shared',Path('C:/hv/vp1'))]:
 run(stage+'-build',[shutil.which('cmake'),'--build',producer,'--target','hyle_compute_provider_iree_vulkan','hyle_compute_route_vulkan','hyle_graph_route_vulkan','--parallel','2'])
 prefix=root/(stage+'-relocated');run(stage+'-install',[shutil.which('cmake'),'--install',producer,'--prefix',prefix])
 build=root/(stage+'-consumer');run(stage+'-consumer-link',[shutil.which('cmake'),'--build',build,'--target','d5_vulkan_delivery','--parallel','2'])
 if stage=='shared':
  for dll in prefix.rglob('*.dll'):shutil.copyfile(dll,build/dll.name)
 env=dict(os.environ);env['PATH']=os.environ['SystemRoot']+'/System32'+os.pathsep+os.environ['SystemRoot'];env['HYLE_VULKAN_VALIDATION']='1';env['VK_LAYER_PATH']='C:/public/tools/hyle-vulkan/1.4.357.0/Bin'
 for entry in ['direct','graph']:
  run(stage+'-'+entry+'-iq1',[build/('d5_vulkan_'+entry+'.exe'),'--gtest_filter=*V4OriginalIq1ShapesChangedInputsAndCheckedIds','--gtest_output=xml:'+str(out/(stage+'-'+entry+'.xml'))],env)
 receipt.setdefault('stages',{})[stage]={'verdict':'PASS','iq1_cases':2,'source_changes':'only two unused constexpr captures and equal-width bounded elements type; no VMFB or numerical algorithm change'}
receipt['verdict']='PASS';(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
