import json,subprocess,time
from pathlib import Path
root=Path('/root/hyle-scratch/vulkan-v4');out=root/'receipts-off';out.mkdir();receipt={'steps':[]}
def run(label,args):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT)
 receipt['steps'].append({'label':label,'argv':list(map(str,args)),'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('off-build',['cmake','--build',root/'off','--parallel','2'])
commands=subprocess.check_output(['ninja','-C',str(root/'off'),'-t','commands'],text=True)
(out/'commands.log').write_text(commands)
for forbidden in ('glslang','glslc','/ggml-vulkan/','iree_runtime','compute_route_vulkan.dir','compute_provider_iree_vulkan.dir'):
 if forbidden in commands:raise SystemExit('OFF artifact leakage: '+forbidden)
run('off-common-consumer',[root/'off/v4_platform'])
receipt['verdict']='PASS';receipt['vulkan_probe_and_artifact_leakage']=False
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
