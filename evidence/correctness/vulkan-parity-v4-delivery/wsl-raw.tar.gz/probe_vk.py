import ctypes as c,json
lib=c.CDLL('libvulkan.so.1')
class App(c.Structure):
    _fields_=[('stype',c.c_uint32),('next',c.c_void_p),('name',c.c_char_p),('version',c.c_uint32),('engine',c.c_char_p),('ev',c.c_uint32),('api',c.c_uint32)]
class Create(c.Structure):
    _fields_=[('stype',c.c_uint32),('next',c.c_void_p),('flags',c.c_uint32),('app',c.POINTER(App)),('layers',c.c_uint32),('layernames',c.c_void_p),('exts',c.c_uint32),('extnames',c.c_void_p)]
a=App(0,None,b'hyle-v4-capability',0,b'hyle',0,(1<<22)|(2<<12));info=Create(1,None,0,c.pointer(a),0,None,0,None);instance=c.c_void_p()
lib.vkCreateInstance.argtypes=[c.POINTER(Create),c.c_void_p,c.POINTER(c.c_void_p)]
result=lib.vkCreateInstance(c.byref(info),None,c.byref(instance))
out={'create_result':result,'devices':[]}
if result==0:
    enum=lib.vkEnumeratePhysicalDevices;enum.argtypes=[c.c_void_p,c.POINTER(c.c_uint32),c.POINTER(c.c_void_p)]
    count=c.c_uint32();result=enum(instance,c.byref(count),None);out['enumerate_result']=result
    devices=(c.c_void_p*count.value)();enum(instance,c.byref(count),devices)
    props=lib.vkGetPhysicalDeviceProperties;props.argtypes=[c.c_void_p,c.c_void_p]
    for d in devices:
        raw=c.create_string_buffer(4096);props(d,raw)
        words=(c.c_uint32*5).from_buffer_copy(raw.raw[:20])
        out['devices'].append({'api':words[0],'driver':words[1],'vendor':words[2],'device':words[3],'type':words[4],'name':raw.raw[20:276].split(b'\0')[0].decode(errors='replace')})
    lib.vkDestroyInstance.argtypes=[c.c_void_p,c.c_void_p];lib.vkDestroyInstance(instance,None)
print(json.dumps(out,indent=2))
