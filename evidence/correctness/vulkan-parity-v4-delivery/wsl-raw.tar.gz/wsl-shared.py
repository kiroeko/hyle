import json,os,subprocess,time
from pathlib import Path
root=Path('/root/hyle-scratch/vulkan-v4');source=Path('/root/hyle');out=root/'receipts-shared';out.mkdir()
receipt={'scope':'Linux shared compilation/SDK and software default rejection; no GPU numerical PASS','steps':[]}
def run(label,args):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT)
 receipt['steps'].append({'label':label,'argv':list(map(str,args)),'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit('Failed: '+str(out/(label+'.log')))
producer=root/'producer';staging=root/'shared-staging';prefix=root/'shared-relocated'
run('shared-configure',['cmake','-S',source/'evidence/correctness/vulkan-parity-v4-delivery/platform','-B',producer,'-DV4_SOURCE_STATIC=OFF'])
run('shared-build',['cmake','--build',producer,'--parallel','2'])
run('shared-install',['cmake','--install',producer,'--prefix',staging])
if prefix.exists():raise SystemExit('Existing SDK move destination')
staging.rename(prefix);build=root/'shared-consumer'
run('shared-consumer-configure',['cmake','-S',source/'evidence/correctness/vulkan-parity-v4-delivery/platform','-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(prefix)])
run('shared-consumer-build',['cmake','--build',build,'--parallel','2'])
run('shared-default-rejection',[build/'v4_platform'])
headers=root/'shared-headers'
run('shared-public-headers-configure',['cmake','-S',source/'evidence/correctness/vulkan-parity-v4-delivery/headers','-B',headers,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(prefix)])
run('shared-public-headers-build',['cmake','--build',headers,'--parallel','2'])
receipt['verdict']='PASS';(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
