import json,os,subprocess,time
from pathlib import Path
root=Path('/root/hyle-scratch/vulkan-v4');source=Path('/root/hyle');out=root/'receipts';out.mkdir(exist_ok=True)
receipt={'candidate':'a27a9b17f043f557726dd73a023e38e70e3e270d','scope':'Linux source/static/shared public binding and actual software-only default rejection; no GPU numerical qualification','steps':[]}
def run(label,args):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT)
 receipt['steps'].append({'label':label,'argv':list(map(str,args)),'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit('Failed: '+str(out/(label+'.log')))
producer=root/'producer'
run('source-sdk-all-build',['cmake','--build',producer,'--parallel','2'])
run('source-default-rejection',[producer/'v4_platform'])
staging=root/'static-staging';prefix=root/'static-relocated'
run('static-install-complete',['cmake','--install',producer,'--prefix',staging])
if prefix.exists():raise SystemExit('SDK move target already exists')
staging.rename(prefix)
build=root/'static-consumer'
run('static-consumer-configure',['cmake','-S',source/'evidence/correctness/vulkan-parity-v4-delivery/platform','-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(prefix)])
run('static-consumer-build',['cmake','--build',build,'--target','v4_platform','--parallel','2'])
run('static-default-rejection',[build/'v4_platform'])
headers=root/'static-headers'
run('static-public-headers-configure',['cmake','-S',source/'evidence/correctness/vulkan-parity-v4-delivery/headers','-B',headers,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(prefix)])
run('static-public-headers-build',['cmake','--build',headers,'--parallel','2'])
receipt['verdict']='PASS';(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Linux source/static and public headers PASS; GPU unavailable',flush=True)
