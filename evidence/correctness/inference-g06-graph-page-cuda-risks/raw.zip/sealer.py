from pathlib import Path
import datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';folder=base/'final-risks-static-3';out=root/'evidence/correctness/inference-g06-graph-page-cuda-risks'
assert not out.exists()
product='669121418669b31f6849c74f64362aaf8d6eb919'
assert not subprocess.check_output(['git','diff','--name-only',product,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
r=json.loads((folder/'result.json').read_text());assert r['state']=='TERMINAL_INSTRUMENTED_RISKS_PASS_FINAL_GATES_PENDING'
assert not r['native_cuda_edges'] and r['configuration_reused_from'].endswith('final-risks-static-1')
tree=ET.parse(folder/'provider.xml').getroot();assert int(tree.attrib['tests'])==24
assert all(tree.attrib.get(k,'0')=='0' for k in ['failures','errors','disabled']) and not list(tree.iter('skipped'))
case=next(t for t in tree.iter('testcase') if t.attrib['name']=='NativeArtifactAllocationFailureAfterRecordingRetires');assert not list(case)
counts={}
for stage in r['stages']:
 name=stage['stage'];text=(folder/Path(stage['log']).name).read_text()
 if name.startswith('hyle_g06_risk_'):
  assert text.count('PASS')==5;counts[name]=5
 elif name in ['hyle_compute_test','hyle_graph_executable_test','hyle_graph_test']:
  found=re.search(r'\[  PASSED  \] (\d+) tests\.',text);assert found and '[  FAILED  ]' not in text and '[  SKIPPED ]' not in text;counts[name]=int(found[1])
assert len([n for n in counts if n.startswith('hyle_g06_risk_')])==4
inputs=json.loads((folder/'input-manifest.json').read_text())
for item in inputs:
 if item['path'].startswith(('include/','src/','cmake/','tests/')) or item['path']=='CMakeLists.txt':assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
path='/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/final-risks-static-3/artifacts.json'
check="from pathlib import Path;import hashlib,json;r=json.loads(Path("+repr(path)+").read_text());assert all(hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()==i['sha256'] for i in r);print(len(r),sum(i['bytes'] for i in r))"
recheck=subprocess.check_output(['wsl','-e','python3','-c',check],text=True).strip()
prior=root/'evidence/correctness/inference-g06-final-cuda-risks/receipt.json'
out.mkdir(parents=True)
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(folder.iterdir()):
  if file.is_file():z.write(file,file.name)
 z.write(Path(__file__),'sealer.py');z.write(base/'launch_final_risks.py','launcher.py')
receipt={'state':'PASS_G06_GRAPH_PAGE_AND_POST_RECORD_ARTIFACT_OOM_CUDA_RISKS_ONLY','product_candidate':product,'source_snapshot':r['candidate'],'record':'docs/implementation/tasks/compute/inference-g06-metadata-decode.md','provider':dict(tree.attrib),'tests_and_modes':counts,'artifact_recheck_count_bytes':recheck,'stages':r['stages'],'outer_elapsed_seconds':r['outer_elapsed_seconds'],'native_object_reuse':r['native_reuse'],
'qualification':['Static24 contains real plain/FP8 original CUDA artifact allocation failure after stream-end/instantiate, preserved ResourceExhausted message, failed slot rejection, independently owned fresh captured slot .25 oracle and metadata allocator return tozero. Original capture attribute and launch faults stillpass.','Fresh process cold-capture32x64, original core/Graph and nine LeaseSubmission tests, ordinary/captured plain/FP8 pending five-mode sets all pass withnewGraph admission.','Original static configuration/tree exactly reused, no CUDA recompilation; unchanged146 native objects independently verified. Original backend single-host-TU observation hook only, not shipping SDK.'],
'prior_risk_evidence':{'path':str(prior.relative_to(root)),'sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'scope':'Original shared/static qualifications and original fixture FAIL/cumulative costs remain; changedGraph/static24 supplemental risk actually rerun here.'},
'limits':['Not shipping SDK/header/P1/fullG06 acceptance; applicable host sanitizer receipts separate.','Graph source changes only; FI/native/backend mathematics unchanged. Original G04/G05 performance unresolved and private/driver cost UNKNOWN remain.','Stage/outer costs overlap; unmeasured investigation/edit/launch cost UNKNOWN.'],'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'state':receipt['state'],'provider_tests':24,'others':counts,'artifacts':recheck}))
