from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).parent
repo = Path('C:/public/project-hyle/hyle')
target = repo / 'evidence/correctness/cuda-r4-context-causality'
target.mkdir(parents=True, exist_ok=True)
results = json.loads((root / 'results.json').read_text(encoding='utf-8'))
captures = [r for r in results if 'capture' in r]
summary = {
    'diagnostic_verdict': 'mechanism supported; sampling repair still required',
    'product_gate': 'BLOCKED', 'p1_gate': 'INCONCLUSIVE',
    'runs': len(results), 'native_runs': sum(r['variant'] == 'native' for r in results),
    'full_runs': sum(r['variant'] == 'full' for r in results),
    'captures': captures,
    'findings': [
        'Two stopped processes link CUDA only, without HYLE/Graph/Sched/Marlin/cuBLAS.',
        'Both stop at cuDevicePrimaryCtxRetain with the same NVIDIA wait-loop RVA as the full fixture.',
        'All captured threads initially have affinity 0x4; caller current priority is 24, helper priorities are 10 or 11.',
        'Driver call at RVA 0x2e350e passes timeout zero to WaitForSingleObject; the captured handle queries as Thread.',
        'Giving helpers CPU4 while retaining caller CPU2 recovers the first live process.',
        'Lowering only caller priority, with the same one-CPU process mask, recovers the second in about 62 milliseconds.'
    ],
    'limitations': [
        'The component that raised the caller current priority to 24 is not identified.',
        'Earlier uncaptured 120-second occurrences cannot be assigned this phase with certainty.',
        'wait_timeout_100ns from run 040 was read after capture resumed the process; its stale value is not evidence.',
        'The NtQueryInformationThread BasePriority field is a relative adjustment on this host, not the absolute Toolhelp base_priority.',
        'Interventions are diagnostic, not product repair, performance samples, or a universal driver claim.'
    ],
    'next_action': 'Freeze truthful caller/helper CPU qualification and bounded progress regression before another P1.'
}
(target / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
artifacts = [root / 'prefix.exe', root.parent / 'progress-diagnosis/phase.exe']
artifacts += sorted(root.glob('*.dll'))
identity = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts}
driver = Path('C:/Windows/System32/DriverStore/FileRepository/nv_dispi.inf_amd64_6f3cfb7117944855/nvcuda64.dll')
identity[str(driver)] = hashlib.sha256(driver.read_bytes()).hexdigest()
(target / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
names = ['prefix.cc', 'prefix.map', 'build.ps1', 'build.log', 'capture_state.py', 'run.py',
         'results.json', 'driver-wait-disasm.txt', 'driver-wait-imports.json', 'imports.py',
         'native-unwound.txt', 'native-priority-unwound.txt', 'query-selfcheck.py', 'query-selfcheck.json']
with zipfile.ZipFile(target / 'raw-and-recipes.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        archive.write(root / name, name)
    for directory in sorted(root.glob('run-*-*')):
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(root).as_posix())
    for name in ['observe.py', 'phase.h', 'unwind.cc']:
        archive.write(root.parent / 'progress-diagnosis' / name, 'support/' + name)
    archive.write(root.parent / 'qualification/affinity-probe/capture-hang.py', 'support/capture-hang.py')
    archive.write(Path(__file__), 'archive.py')
print(json.dumps({'runs': len(results), 'captures': len(captures), 'path': str(target)}))
