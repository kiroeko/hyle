from pathlib import Path
import json
import struct

path = Path('C:/Windows/System32/DriverStore/FileRepository/nv_dispi.inf_amd64_6f3cfb7117944855/nvcuda64.dll')
data = path.read_bytes()
pe = struct.unpack_from('<I', data, 0x3c)[0]
count = struct.unpack_from('<H', data, pe + 6)[0]
opt_size = struct.unpack_from('<H', data, pe + 20)[0]
opt = pe + 24
sections = []
for i in range(count):
    _, size, rva, raw_size, raw = struct.unpack_from('<8sIIII', data, opt + opt_size + i * 40)
    sections.append((rva, max(size, raw_size), raw))

def offset(rva):
    for begin, size, raw in sections:
        if begin <= rva < begin + size:
            return raw + rva - begin
    return rva

def string(rva):
    start = offset(rva)
    return data[start:data.index(b'\0', start)].decode('ascii')

imports_rva = struct.unpack_from('<I', data, opt + 120)[0]
cursor = offset(imports_rva)
result = {}
while True:
    original, stamp, chain, name, iat = struct.unpack_from('<IIIII', data, cursor)
    if not name:
        break
    module = string(name)
    index = 0
    while True:
        entry = struct.unpack_from('<Q', data, offset(original or iat) + index * 8)[0]
        if not entry:
            break
        value = 'ordinal:' + str(entry & 0xffff) if entry & (1 << 63) else string(entry + 2)
        result[hex(iat + index * 8)] = module + '!' + value
        index += 1
    cursor += 20
keys = ['0x1671258', '0x16712f0', '0x1671288', '0x16710e0']
selected = {key: result.get(key) for key in keys}
Path(__file__).with_name('driver-wait-imports.json').write_text(json.dumps(selected, indent=2) + '\n')
print(json.dumps(selected))
