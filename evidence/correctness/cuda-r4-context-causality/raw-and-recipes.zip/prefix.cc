#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <cstdio>
#include "../progress-diagnosis/phase.h"

#define STEP(id, expr) do { \
  phase_diag::mark(id); \
  std::fprintf(stderr, "begin phase=%d %s\n", id, #expr); \
  auto started = GetTickCount64(); \
  int result = static_cast<int>(expr); \
  std::fprintf(stderr, "end phase=%d status=%d elapsed_ms=%llu\n", id, result, \
               GetTickCount64() - started); \
  if (result != 0) return result; \
} while (false)

int main() {
  phase_diag::init();
  phase_diag::shared->rows = 1;
  int version = 0, count = 0;
  cudaDeviceProp properties{};
  STEP(10, cudaDriverGetVersion(&version));
  STEP(11, cudaRuntimeGetVersion(&version));
  STEP(12, cudaGetDeviceProperties(&properties, 0));
  STEP(20, cudaGetDeviceCount(&count));
  STEP(30, cuInit(0));
  CUdevice device = 0;
  STEP(40, cuDeviceGet(&device, 0));
  CUcontext primary = nullptr;
  STEP(100, cuDevicePrimaryCtxRetain(&primary, device));
  STEP(110, cuDevicePrimaryCtxRelease(device));
  phase_diag::mark(9000);
}
