$ErrorActionPreference = 'Stop'
. 'C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1'
$r4CausalRoot = 'C:/hyle-scratch/r4-cuda-20260916/context-causality'
$r4CausalCuda = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3'
Set-Location -LiteralPath $r4CausalRoot
cl /nologo /O2 /EHsc /std:c++20 /MD "/I$r4CausalCuda/include" prefix.cc /link "/LIBPATH:$r4CausalCuda/lib/x64" cuda.lib cudart.lib /MAP:prefix.map /OUT:prefix.exe *> build.log
if ($LASTEXITCODE -ne 0) { Get-Content -LiteralPath build.log -Tail 20; exit $LASTEXITCODE }
foreach ($r4CausalDll in @('cudart64_13.dll','msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll')) {
  Copy-Item -LiteralPath "C:/hv4d1v2/bin/$r4CausalDll" -Destination $r4CausalRoot
}
Write-Output 'Standalone CUDA API prefix built; actual DLLs adjacent.'
