import _winapi
import ctypes as c
from ctypes import wintypes as w
import hashlib
import importlib.util
import json
import msvcrt
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

root=Path(__file__).parent
k=c.WinDLL('kernel32',use_last_error=True)
def bind(name,args,ret=w.BOOL):
    fn=getattr(k,name);fn.argtypes=args;fn.restype=ret;return fn
current=bind('GetCurrentProcess',[],w.HANDLE)
set_affinity=bind('SetProcessAffinityMask',[w.HANDLE,c.c_size_t])
resume=bind('ResumeThread',[w.HANDLE],w.DWORD)
close=bind('CloseHandle',[w.HANDLE])
open_map=bind('OpenFileMappingW',[w.DWORD,w.BOOL,w.LPCWSTR],w.HANDLE)
map_view=bind('MapViewOfFile',[w.HANDLE,w.DWORD,w.DWORD,w.DWORD,c.c_size_t],c.c_void_p)
unmap=bind('UnmapViewOfFile',[c.c_void_p])
open_thread=bind('OpenThread',[w.DWORD,w.BOOL,w.DWORD],w.HANDLE)
times=bind('GetThreadTimes',[w.HANDLE,*([c.POINTER(w.FILETIME)]*4)])
description=bind('GetThreadDescription',[w.HANDLE,c.POINTER(c.c_void_p)],w.LONG)
local_free=bind('LocalFree',[c.c_void_p],c.c_void_p)
snapshot=bind('CreateToolhelp32Snapshot',[w.DWORD,w.DWORD],w.HANDLE)
class Thread(c.Structure):
    _fields_=[('size',w.DWORD),('usage',w.DWORD),('id',w.DWORD),('pid',w.DWORD),
              ('base_priority',w.LONG),('delta_priority',w.LONG),('flags',w.DWORD)]
first=bind('Thread32First',[w.HANDLE,c.POINTER(Thread)])
next_thread=bind('Thread32Next',[w.HANDLE,c.POINTER(Thread)])
k.SetErrorMode(0x8003)
if not set_affinity(current(),0x10): raise c.WinError(c.get_last_error())
spec=importlib.util.spec_from_file_location('cuda_aa','C:/public/project-hyle/hyle/bench/compute_route_cuda/validate_aa.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
env=module.child_environment()
env['HYLE_BENCH_RIVAL_FIRST']='1'
env['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'

def thread_facts(pid):
    result=[];snap=snapshot(4,0);entry=Thread();entry.size=c.sizeof(entry)
    try:
        ok=first(snap,c.byref(entry))
        while ok:
            if entry.pid==pid:
                row={'id':entry.id,'base_priority':entry.base_priority}
                th=open_thread(0x40,False,entry.id)
                if th:
                    values=[w.FILETIME() for _ in range(4)]
                    if times(th,*[c.byref(v) for v in values]):
                        row['cpu_seconds']=sum((v.dwHighDateTime<<32)+v.dwLowDateTime for v in values[2:])/1e7
                    text=c.c_void_p()
                    if description(th,c.byref(text))==0 and text.value:
                        row['description']=c.wstring_at(text.value);local_free(text)
                    close(th)
                result.append(row)
            ok=next_thread(snap,c.byref(entry))
    finally: close(snap)
    return sorted(result,key=lambda r:r.get('cpu_seconds',0),reverse=True)

def capture(pid,tid,directory):
    result=subprocess.run([sys.executable,
        'C:/hyle-scratch/r4-cuda-20260916/qualification/affinity-probe/capture-hang.py',
        str(pid),str(tid),str(directory)],capture_output=True,timeout=20)
    directory.mkdir(parents=True,exist_ok=True)
    (directory/'capture.log').write_bytes(result.stdout+result.stderr)
    return result.returncode

def run(index,selftest=False):
    directory=root/('selftest' if selftest else f'run-{index:02d}')
    directory.mkdir()
    with open(os.devnull,'rb') as inp,(directory/'process.log').open('wb') as out:
        handles=[msvcrt.get_osfhandle(f.fileno()) for f in (inp,out)]
        for h in handles: os.set_handle_inheritable(h,True)
        si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESTDHANDLES
        si.hStdInput=handles[0];si.hStdOutput=handles[1];si.hStdError=handles[1]
        hp,ht,pid,tid=_winapi.CreateProcess(str(root/'phase.exe'),
            subprocess.list2cmdline([str(root/'phase.exe'),*(['capture-selftest'] if selftest else [])]),
            None,None,True,0x4|subprocess.ABOVE_NORMAL_PRIORITY_CLASS,env,str(root),si)
        for h in handles: os.set_handle_inheritable(h,False)
        # The observer remains on CPU4; the suspended child is constrained to
        # CPU2 before its first instruction, then resumed with its exact mask.
        if not set_affinity(hp,4): raise c.WinError(c.get_last_error())
        if resume(ht)==0xffffffff: raise c.WinError(c.get_last_error())
        close(ht)
        start=time.monotonic();mapped=None;view=None;history=[];last=None
        report={'pid':pid,'primary_thread':tid,'observer_mask':'0x10','child_mask':'0x4',
                'priority':'AboveNormal','limit_seconds':10,'selftest':selftest}
        try:
            while _winapi.WaitForSingleObject(hp,50)==258:
                if not mapped:
                    mapped=open_map(4,False,f'Local\\hyle-r4-phase-{pid}')
                    if mapped: view=map_view(mapped,4,0,0,24)
                if view:
                    phase,rows,thread,count,tick=struct.unpack('<iiiiQ',c.string_at(view,24))
                    if (phase,rows)!=last:
                        # Keep coarse stage transitions; the fine per-submit
                        # phase remains readable at the actual timeout.
                        if phase<1000 or phase>=5000:
                            history.append({'seconds':time.monotonic()-start,'phase':phase,'rows':rows,'thread':thread,'count':count})
                        last=(phase,rows)
                elapsed=time.monotonic()-start
                if (selftest and view and phase==8888) or elapsed>10:
                    report['observed_seconds']=elapsed
                    report['phase']={'phase':phase,'rows':rows,'thread':thread,'count':count} if view else None
                    report['threads']=thread_facts(pid)
                    selected=report['threads'][0]['id'] if report['threads'] else tid
                    report['capture_exit']=capture(pid,selected,directory/'active')
                    if selected!=tid:
                        report['primary_capture_exit']=capture(pid,tid,directory/'primary')
                    report['timed_out']=not selftest
                    _winapi.TerminateProcess(hp,42 if selftest else 124)
                    _winapi.WaitForSingleObject(hp,10000)
                    break
            report['elapsed_seconds']=time.monotonic()-start
            report['exit_code']=_winapi.GetExitCodeProcess(hp)
            report['history']=history
        finally:
            if view: unmap(view)
            if mapped: close(mapped)
            close(hp)
    (directory/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--selftest':
        result=run(0,True);print(json.dumps(result));sys.exit(0 if result.get('capture_exit')==0 else 2)
    started=time.monotonic();results=[]
    for index in range(80):
        if time.monotonic()-started>=480: break
        result=run(index);results.append(result)
        (root/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        if result.get('timed_out') or result['exit_code']:
            print(json.dumps(result));break
    else: print('80 starts completed without a long-delay capture')
