#define NOMINMAX
#include <windows.h>
#include <dbghelp.h>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

struct Image {
  DWORD64 base;
  DWORD size;
  std::wstring path;
  HANDLE file = INVALID_HANDLE_VALUE;
  HANDLE mapping = nullptr;
  BYTE* view = nullptr;
};
std::vector<BYTE> dump;
std::vector<Image> images;
MINIDUMP_MEMORY_LIST* memory = nullptr;
HANDLE identity = reinterpret_cast<HANDLE>(0x12345678);

Image* image_for(DWORD64 address) {
  for (auto& image : images)
    if (address >= image.base && address - image.base < image.size)
      return &image;
  return nullptr;
}
BYTE* map_image(Image& image) {
  if (image.view) return image.view;
  image.file = CreateFileW(image.path.c_str(), GENERIC_READ,
      FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
      OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (image.file == INVALID_HANDLE_VALUE) return nullptr;
  image.mapping = CreateFileMappingW(image.file, nullptr,
      PAGE_READONLY | SEC_IMAGE, 0, 0, nullptr);
  if (!image.mapping) return nullptr;
  image.view = static_cast<BYTE*>(MapViewOfFile(image.mapping, FILE_MAP_READ, 0, 0, 0));
  return image.view;
}
BOOL CALLBACK read_memory(HANDLE, DWORD64 address, PVOID target, DWORD size,
                          LPDWORD read) {
  *read = 0;
  for (ULONG i = 0; memory && i < memory->NumberOfMemoryRanges; ++i) {
    const auto& segment = memory->MemoryRanges[i];
    if (address >= segment.StartOfMemoryRange &&
        address - segment.StartOfMemoryRange + size <= segment.Memory.DataSize) {
      std::memcpy(target, dump.data() + segment.Memory.Rva +
          (address - segment.StartOfMemoryRange), size);
      *read = size;
      return TRUE;
    }
  }
  auto* image = image_for(address);
  if (!image || address - image->base + size > image->size || !map_image(*image))
    return FALSE;
  std::memcpy(target, image->view + address - image->base, size);
  *read = size;
  return TRUE;
}
DWORD64 CALLBACK module_base(HANDLE, DWORD64 address) {
  const auto* image = image_for(address);
  return image ? image->base : 0;
}
PVOID CALLBACK function_table(HANDLE, DWORD64 address) {
  auto* image = image_for(address);
  if (!image || !map_image(*image)) return nullptr;
  auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(image->view);
  auto* pe = reinterpret_cast<IMAGE_NT_HEADERS64*>(image->view + dos->e_lfanew);
  const auto& directory = pe->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
  auto* table = reinterpret_cast<RUNTIME_FUNCTION*>(image->view + directory.VirtualAddress);
  auto* end = table + directory.Size / sizeof(RUNTIME_FUNCTION);
  const auto rva = address - image->base;
  auto* item = std::upper_bound(table, end, rva,
      [](DWORD64 value, const RUNTIME_FUNCTION& entry) { return value < entry.BeginAddress; });
  if (item == table) return nullptr;
  --item;
  return rva < item->EndAddress ? item : nullptr;
}
void print_address(DWORD64 address) {
  auto* image = image_for(address);
  std::printf("0x%llx", address);
  if (image) std::printf(" %ls+0x%llx", image->path.c_str(), address - image->base);
  alignas(SYMBOL_INFO) char bytes[sizeof(SYMBOL_INFO) + MAX_SYM_NAME]{};
  auto* symbol = reinterpret_cast<SYMBOL_INFO*>(bytes);
  symbol->SizeOfStruct = sizeof(SYMBOL_INFO);
  symbol->MaxNameLen = MAX_SYM_NAME;
  DWORD64 displacement = 0;
  if (SymFromAddr(identity, address, &displacement, symbol))
    std::printf(" [%s+0x%llx]", symbol->Name, displacement);
  std::puts("");
}
int main(int argc, char** argv) {
  SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
  if (argc != 2) return 2;
  std::ifstream input(argv[1], std::ios::binary);
  dump.assign(std::istreambuf_iterator<char>(input), {});
  PMINIDUMP_DIRECTORY directory = nullptr;
  ULONG bytes = 0;
  MINIDUMP_THREAD_LIST* threads = nullptr;
  MINIDUMP_MODULE_LIST* modules = nullptr;
  if (!MiniDumpReadDumpStream(dump.data(), ThreadListStream, &directory,
          reinterpret_cast<PVOID*>(&threads), &bytes) ||
      !MiniDumpReadDumpStream(dump.data(), ModuleListStream, &directory,
          reinterpret_cast<PVOID*>(&modules), &bytes) ||
      !MiniDumpReadDumpStream(dump.data(), MemoryListStream, &directory,
          reinterpret_cast<PVOID*>(&memory), &bytes)) return 3;
  SymSetOptions(SYMOPT_UNDNAME | SYMOPT_DEFERRED_LOADS | SYMOPT_FAIL_CRITICAL_ERRORS |
                SYMOPT_NO_PROMPTS | SYMOPT_EXACT_SYMBOLS);
  if (!SymInitialize(identity, "", FALSE)) return 4;
  for (ULONG i = 0; i < modules->NumberOfModules; ++i) {
    const auto& mod = modules->Modules[i];
    const auto* name = reinterpret_cast<MINIDUMP_STRING*>(dump.data() + mod.ModuleNameRva);
    images.push_back({mod.BaseOfImage, mod.SizeOfImage,
                     std::wstring(name->Buffer, name->Length / sizeof(WCHAR))});
    SymLoadModuleExW(identity, nullptr, images.back().path.c_str(), nullptr,
                    mod.BaseOfImage, mod.SizeOfImage, nullptr, 0);
  }
  for (ULONG i = 0; i < threads->NumberOfThreads; ++i) {
    const auto& th = threads->Threads[i];
    CONTEXT context{};
    std::memcpy(&context, dump.data() + th.ThreadContext.Rva,
                std::min<std::size_t>(sizeof(context), th.ThreadContext.DataSize));
    STACKFRAME64 frame{};
    frame.AddrPC.Offset = context.Rip;
    frame.AddrStack.Offset = context.Rsp;
    frame.AddrFrame.Offset = context.Rbp;
    frame.AddrPC.Mode = frame.AddrStack.Mode = frame.AddrFrame.Mode = AddrModeFlat;
    std::printf("THREAD %lu\n", th.ThreadId);
    print_address(context.Rip);
    for (int n = 0; n < 64; ++n) {
      if (!StackWalk64(IMAGE_FILE_MACHINE_AMD64, identity, nullptr, &frame, &context,
                       read_memory, function_table, module_base, nullptr)) break;
      if (!frame.AddrPC.Offset) break;
      print_address(frame.AddrPC.Offset);
      if (frame.AddrPC.Offset == frame.AddrReturn.Offset) break;
    }
  }
  SymCleanup(identity);
}
