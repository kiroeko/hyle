#pragma once
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>

namespace phase_diag {
struct Shared {
  volatile LONG phase;
  volatile LONG rows;
  volatile LONG thread;
  volatile LONG count;
  volatile ULONGLONG tick;
};
inline Shared *shared = nullptr;
inline HANDLE mapping = nullptr;
inline void mark(LONG value) {
  shared->tick = GetTickCount64();
  shared->thread = static_cast<LONG>(GetCurrentThreadId());
  InterlockedIncrement(&shared->count);
  InterlockedExchange(&shared->phase, value);
}
inline void init() {
  SetErrorMode(0x8003);
  wchar_t name[100];
  swprintf_s(name, L"Local\\hyle-r4-phase-%lu", GetCurrentProcessId());
  mapping = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE,
                               0, sizeof(Shared), name);
  if (!mapping) std::exit(90);
  shared = static_cast<Shared *>(MapViewOfFile(mapping, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(Shared)));
  if (!shared) std::exit(91);
  mark(1);
  // Intentionally process-owned: observers can still see global teardown.
  std::atexit([] { mark(9999); });
}
}
