import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import capture_state as capture

obs = capture.obs
current_thread = obs.bind('GetCurrentThread', [], w.HANDLE)
get_priority = obs.bind('GetThreadPriority', [w.HANDLE], c.c_int)
set_priority = obs.bind('SetThreadPriority', [w.HANDLE, c.c_int])
get_class = obs.bind('GetPriorityClass', [w.HANDLE], w.DWORD)
thread = current_thread()
original = get_priority(thread)
results = []
try:
    for delta in (0, -2, 0):
        if not set_priority(thread, delta):
            raise c.WinError(c.get_last_error())
        value = capture.ThreadBasic()
        status = capture.query_thread(thread, 0, c.byref(value), c.sizeof(value), None)
        results.append({'requested_delta': delta, 'win32_thread_priority': get_priority(thread),
                        'process_class': get_class(obs.current()), 'query_status': status,
                        'affinity': hex(value.affinity), 'current_priority': value.priority,
                        'basic_information_base_field': value.base_priority})
finally:
    set_priority(thread, original)
assert [r['win32_thread_priority'] for r in results] == [0, -2, 0]
assert [r['current_priority'] for r in results] == [8, 6, 8]
assert [r['basic_information_base_field'] for r in results] == [0, -2, 0]
Path(__file__).with_name('query-selfcheck.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results))
