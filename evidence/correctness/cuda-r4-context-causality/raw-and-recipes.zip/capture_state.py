import ctypes as c
from ctypes import wintypes as w
import json
from pathlib import Path
import struct
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / 'progress-diagnosis'))
import observe as obs

n = c.WinDLL('ntdll', use_last_error=True)
class ClientId(c.Structure):
    _fields_ = [('process', c.c_void_p), ('thread', c.c_void_p)]
class ThreadBasic(c.Structure):
    _fields_ = [('exit_status', w.LONG), ('teb', c.c_void_p), ('client', ClientId),
                ('affinity', c.c_size_t), ('priority', w.LONG), ('base_priority', w.LONG)]
query_thread = n.NtQueryInformationThread
query_thread.argtypes = [w.HANDLE, w.ULONG, c.c_void_p, w.ULONG, c.c_void_p]
query_thread.restype = w.LONG
priority_boost = obs.bind('GetThreadPriorityBoost', [w.HANDLE, c.POINTER(w.BOOL)])
open_process = obs.bind('OpenProcess', [w.DWORD, w.BOOL, w.DWORD], w.HANDLE)
read_memory = obs.bind('ReadProcessMemory', [w.HANDLE, c.c_void_p, c.c_void_p,
                                          c.c_size_t, c.POINTER(c.c_size_t)])
duplicate = obs.bind('DuplicateHandle', [w.HANDLE, w.HANDLE, w.HANDLE, c.POINTER(w.HANDLE),
                                       w.DWORD, w.BOOL, w.DWORD])
query_object = n.NtQueryObject
query_object.argtypes = [w.HANDLE, w.ULONG, c.c_void_p, w.ULONG, c.c_void_p]
query_object.restype = w.LONG
class Unicode(c.Structure):
    _fields_ = [('length', w.USHORT), ('maximum', w.USHORT), ('buffer', c.c_void_p)]
query_event = n.NtQueryEvent
query_event.argtypes = [w.HANDLE, w.ULONG, c.c_void_p, w.ULONG, c.c_void_p]
query_event.restype = w.LONG

def facts(pid):
    result = obs.thread_facts(pid)
    for row in result:
        handle = obs.open_thread(0x40, False, row['id'])
        if not handle:
            continue
        try:
            value = ThreadBasic()
            status = query_thread(handle, 0, c.byref(value), c.sizeof(value), None)
            row['basic_query_status'] = status
            if status >= 0:
                row.update(affinity=hex(value.affinity), dynamic_priority=value.priority,
                           queried_base_priority=value.base_priority)
            disabled = w.BOOL()
            if priority_boost(handle, c.byref(disabled)):
                row['priority_boost_disabled'] = bool(disabled.value)
        finally:
            obs.close(handle)
    return result

def capture(pid, tid, output):
    output.mkdir(parents=True, exist_ok=True)
    before = facts(pid)
    result = subprocess.run([sys.executable,
        str(Path(__file__).parent.parent / 'qualification/affinity-probe/capture-hang.py'),
        str(pid), str(tid), str(output)], capture_output=True, timeout=15)
    (output / 'capture.log').write_bytes(result.stdout + result.stderr)
    report = {'threads': before, 'capture_exit': result.returncode}
    if result.returncode:
        return report
    raw = json.loads((output / 'hung-context.json').read_text(encoding='utf-8'))
    # Only interpret the first argument as a wait handle if the exact PC is in
    # this machine's NtWaitForSingleObject stub, not an arbitrary captured call.
    pc = raw['instruction']
    local_base = n._handle
    wait_rva = c.cast(n.NtWaitForSingleObject, c.c_void_p).value - local_base
    report['nt_wait_stub_rva'] = hex(wait_rva)
    if Path(pc.get('module', '')).name.lower() == 'ntdll.dll' and \
            wait_rva <= int(pc.get('rva', '0'), 16) < wait_rva + 0x30:
        process = open_process(0x450, False, pid)
        if process:
            try:
                timeout_pointer = int(raw['registers']['r8'], 16)
                timeout = c.c_int64()
                copied = c.c_size_t()
                if timeout_pointer and read_memory(process, timeout_pointer,
                        c.byref(timeout), 8, c.byref(copied)):
                    report['wait_timeout_100ns'] = timeout.value
                elif not timeout_pointer:
                    report['wait_timeout_100ns'] = None
                handle_value = int(raw['registers']['rcx'], 16)
                report['wait_handle'] = hex(handle_value)
                handle = w.HANDLE()
                if duplicate(process, handle_value, obs.current(), c.byref(handle), 0, False, 2):
                    try:
                        storage = c.create_string_buffer(4096)
                        status = query_object(handle, 2, storage, len(storage), None)
                        report['object_type_status'] = status
                        if status >= 0:
                            name = Unicode.from_buffer(storage)
                            report['object_type'] = c.wstring_at(name.buffer, name.length // 2)
                            if report['object_type'] == 'Event':
                                values = (w.LONG * 2)()
                                event_status = query_event(handle, 0, values, c.sizeof(values), None)
                                report['event_query_status'] = event_status
                                if event_status >= 0:
                                    report['event_type'] = values[0]
                                    report['event_state'] = values[1]
                    finally:
                        obs.close(handle)
                else:
                    report['duplicate_error'] = c.get_last_error()
            finally:
                obs.close(process)
    (output / 'thread-and-wait.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return report
