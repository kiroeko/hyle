import ctypes as c
from ctypes import wintypes as w
import json
import msvcrt
import os
from pathlib import Path
import struct
import subprocess
import time
import _winapi

import capture_state as capture
obs = capture.obs
root = Path(__file__).parent
set_thread_affinity = obs.bind('SetThreadAffinityMask', [w.HANDLE, c.c_size_t], c.c_size_t)
set_thread_priority = obs.bind('SetThreadPriority', [w.HANDLE, c.c_int])
if not obs.set_affinity(obs.current(), 0x40):
    raise c.WinError(c.get_last_error())

def run(index, captures):
    variant = 'native' if index % 2 == 0 else 'full'
    executable = root / 'prefix.exe' if variant == 'native' else root.parent / 'progress-diagnosis/phase.exe'
    output = root / f'run-{index:03d}-{variant}'
    output.mkdir()
    with open(os.devnull, 'rb') as inp, (output / 'process.log').open('wb') as out:
        handles = [msvcrt.get_osfhandle(f.fileno()) for f in (inp, out)]
        for handle in handles:
            os.set_handle_inheritable(handle, True)
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESTDHANDLES
        startup.hStdInput, startup.hStdOutput, startup.hStdError = handles[0], handles[1], handles[1]
        hp, ht, pid, tid = _winapi.CreateProcess(str(executable),
            subprocess.list2cmdline([str(executable)]), None, None, True,
            0x4 | subprocess.ABOVE_NORMAL_PRIORITY_CLASS, obs.env, str(executable.parent), startup)
        for handle in handles:
            os.set_handle_inheritable(handle, False)
        if not obs.set_affinity(hp, 4):
            raise c.WinError(c.get_last_error())
        obs.resume(ht)
        obs.close(ht)
        started = time.monotonic()
        mapped = view = None
        history = []
        last = None
        intervention_at = None
        report = {'index': index, 'variant': variant, 'pid': pid, 'primary_thread': tid,
                  'initial_mask': '0x4', 'observer_mask': '0x40', 'priority': 'AboveNormal'}
        try:
            while _winapi.WaitForSingleObject(hp, 25) == 258:
                if not mapped:
                    mapped = obs.open_map(4, False, f'Local\\hyle-r4-phase-{pid}')
                    if mapped:
                        view = obs.map_view(mapped, 4, 0, 0, 24)
                phase = rows = None
                if view:
                    phase, rows, thread, count, tick = struct.unpack('<iiiiQ', c.string_at(view, 24))
                    if (phase, rows) != last:
                        history.append({'seconds': time.monotonic() - started,
                                        'phase': phase, 'rows': rows, 'count': count})
                        last = phase, rows
                elapsed = time.monotonic() - started
                if intervention_at is None and elapsed > 5:
                    report['delayed_phase'] = {'phase': phase, 'rows': rows}
                    report['capture'] = capture.capture(pid, tid, output / 'before')
                    if phase != 100 or rows != 1 or report['capture']['capture_exit']:
                        report['intervention'] = 'NOT_APPLICABLE'
                        _winapi.TerminateProcess(hp, 124)
                        break
                    if captures == 0:
                        if not obs.set_affinity(hp, 0x14):
                            raise c.WinError(c.get_last_error())
                        updates = []
                        for fact in report['capture']['threads']:
                            handle = obs.open_thread(0x60, False, fact['id'])
                            if not handle:
                                raise c.WinError(c.get_last_error())
                            mask = 4 if fact['id'] == tid else 0x14
                            old_mask = set_thread_affinity(handle, mask)
                            obs.close(handle)
                            if not old_mask:
                                raise c.WinError(c.get_last_error())
                            updates.append({'thread': fact['id'], 'old_mask': hex(old_mask), 'new_mask': hex(mask)})
                        report['intervention'] = 'helper_affinity_only'
                        report['affinity_updates'] = updates
                    else:
                        handle = obs.open_thread(0x60, False, tid)
                        if not handle or not set_thread_priority(handle, -2):
                            raise c.WinError(c.get_last_error())
                        obs.close(handle)
                        report['intervention'] = 'caller_priority_only'
                    intervention_at = time.monotonic()
                    report['intervention_seconds'] = intervention_at - started
                    report['threads_after_intervention'] = capture.facts(pid)
                elif intervention_at is not None and time.monotonic() - intervention_at > 5:
                    report['recovered'] = False
                    report['after_capture'] = capture.capture(pid, tid, output / 'after')
                    _winapi.TerminateProcess(hp, 124)
                    break
                if time.monotonic() - started > 20:
                    report['hard_timeout'] = True
                    _winapi.TerminateProcess(hp, 124)
                    break
            _winapi.WaitForSingleObject(hp, 10000)
            report['elapsed_seconds'] = time.monotonic() - started
            report['exit_code'] = _winapi.GetExitCodeProcess(hp)
            report['history'] = history
            if intervention_at is not None:
                report['seconds_after_intervention'] = time.monotonic() - intervention_at
                report['recovered'] = report['exit_code'] == 0
        finally:
            if view:
                obs.unmap(view)
            if mapped:
                obs.close(mapped)
            obs.close(hp)
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return report

started = time.monotonic()
reports = []
captures = 0
for index in range(128):
    if time.monotonic() - started >= 480:
        break
    report = run(index, captures)
    reports.append(report)
    (root / 'results.json').write_text(json.dumps(reports, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k not in
                     ('history', 'capture', 'after_capture', 'threads_after_intervention')}), flush=True)
    if 'capture' in report:
        captures += 1
    if captures >= 2 or report.get('intervention') == 'NOT_APPLICABLE' or \
            report.get('hard_timeout') or (report['exit_code'] and 'intervention' not in report):
        break
