from pathlib import Path
import hashlib, json, subprocess
repo=Path(__file__).resolve().parents[1]
old=repo/'.scratch/validation/cpu-aten-transformer-matrix'
out=repo/'.scratch/validation/cpu-aten-scatter-add'
out.mkdir(parents=True,exist_ok=True)
def write_if_changed(path, data):
    if not path.exists() or path.read_bytes()!=data:
        path.write_bytes(data)
helper=(old/'consumer.cc').read_text(encoding='utf-8').split('int main() {')[0]
main=r'''
int main() {
 const auto f=c::DataType::kFloat32;
 const auto index=c::DataType::kInt64;
 const std::array matrix{desc(f,{4,3},true),desc(index,{2,2},true),desc(f,{2,2,3},true)};
 journey(c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),matrix,
  [&](auto &b,int seed){
   std::array<float,12> base,updates;
   for(int i=0;i<12;++i){base[i]=float(i+seed);updates[i]=float(i%3+seed)*.25F;}
   const std::array<std::int64_t,4> ids{2,0,2,3};
   write<float>(b[0],matrix[0],base);write<std::int64_t>(b[1],matrix[1],ids);write<float>(b[2],matrix[2],updates);
  },[&](const auto &b,int seed){
   std::array<float,12> expected;
   for(int i=0;i<12;++i)expected[i]=float(i+seed);
   const std::array<int,4> ids{2,0,2,3};
   for(int i=0;i<4;++i)for(int col=0;col<3;++col)expected[ids[i]*3+col]+=float(col+seed)*.25F;
   compare(b,expected);
  });
 const std::array scalar{desc(f,{2,4,3},true),desc(index,{}),desc(f,{2,3},true)};
 journey(c::Operation(c::Scatter{.axis=1,.kind=c::ScatterKind::kAdd}),scalar,
  [&](auto &b,int seed){
   std::array<float,24> base;for(int i=0;i<24;++i)base[i]=float(i+seed)*.125F;
   const std::array<std::int64_t,1> ids{1};
   const std::array<float,6> updates{float(seed),1,2,3,4,5};
   write<float>(b[0],scalar[0],base);write<std::int64_t>(b[1],scalar[1],ids);write<float>(b[2],scalar[2],updates);
  },[&](const auto &b,int seed){
   std::array<float,24> expected;for(int i=0;i<24;++i)expected[i]=float(i+seed)*.125F;
   const std::array<float,6> added{float(seed),1,2,3,4,5};
   for(int row=0;row<2;++row)for(int col=0;col<3;++col)expected[row*12+3+col]+=added[row*3+col];
   compare(b,expected);
  });
 const std::array empty{desc(f,{2,3},true),desc(index,{0}),desc(f,{0,3})};
 journey(c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),empty,
  [&](auto &b,int seed){const std::array<float,6> base{float(seed),1,2,3,4,5};write<float>(b[0],empty[0],base);},
  [&](const auto &b,int seed){const std::array<float,6> expected{float(seed),1,2,3,4,5};compare(b,expected);});
 std::puts("PASS ordinary mature CPU ScatterAdd Direct/Graph duplicate multi-axis/odd-stride/scalar/empty/changed inputs/close");
}
'''
write_if_changed(out/'consumer.cc',(helper+main).encode('utf-8'))
(out/'consumer').mkdir(exist_ok=True)
write_if_changed(out/'consumer/CMakeLists.txt',(old/'consumer/CMakeLists.txt').read_bytes())
for platform in ('windows','linux'):
    text=(old/(platform+'-overlay.cmake')).read_text(encoding='utf-8').replace('cpu-aten-transformer-matrix','cpu-aten-scatter-add')
    write_if_changed(out/(platform+'-overlay.cmake'),text.encode('utf-8'))
previous=json.loads((old/'manifest.json').read_text())
manifest={'candidate':'e13edaebe0aac974fd2f7d2ff50246dfd61ad330','fixture_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{}}
for name in previous['files']:
    if name.startswith('.scratch/validation/cpu-aten-transformer-matrix/'):
        continue
    manifest['files'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
for name in ('consumer.cc','consumer/CMakeLists.txt','windows-overlay.cmake','linux-overlay.cmake'):
    relative=(out/name).relative_to(repo).as_posix()
    manifest['files'][relative]=hashlib.sha256((out/name).read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
for platform in ('windows','linux'):
    text=(repo/('.scratch/cpu-tm-'+platform+'.py')).read_text(encoding='utf-8')
    text=text.replace('cpu-aten-transformer-matrix','cpu-aten-scatter-add').replace('cpu-tm-','cpu-as-').replace("+'-tm-consumer'","+'-as-consumer'")
    write_if_changed(repo/('.scratch/cpu-as-'+platform+'.py'),text.encode('utf-8'))
print(json.dumps({'candidate':manifest['candidate'],'inputs':len(manifest['files'])}))
