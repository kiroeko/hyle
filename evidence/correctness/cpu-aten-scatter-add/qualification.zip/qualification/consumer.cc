#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> value) {
  if (!value) {
    std::fprintf(stderr, "%.*s\n", int(value.error().message().size()),
                 value.error().message().data());
    std::exit(2);
  }
  return std::move(*value);
}
void require(hyle::Status value) {
  if (!value.ok()) {
    std::fprintf(stderr, "%.*s\n", int(value.message().size()),
                 value.message().data());
    std::exit(2);
  }
}
c::TensorDesc desc(c::DataType type,
                   std::initializer_list<std::int64_t> dimensions,
                   bool odd = false) {
  if (!odd)
    return take(
        c::TensorDesc::dense(type, {dimensions.begin(), dimensions.size()}));
  std::vector<std::int64_t> strides(dimensions.size());
  auto n = std::int64_t(c::data_type_size(type) + 1);
  for (std::size_t i = dimensions.size(); i-- > 0;) {
    strides[i] = n;
    n = n * dimensions.begin()[i] + 1;
  }
  return take(c::TensorDesc::strided_bytes(
      type, {dimensions.begin(), dimensions.size()}, strides));
}
m::Buffer allocate(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
std::size_t offset(const c::TensorDesc &d, std::size_t linear) {
  std::size_t out = 0;
  for (std::size_t i = d.rank(); i-- > 0;) {
    out += linear % std::size_t(d.dimensions()[i]) *
           std::size_t(d.byte_strides()[i]);
    linear /= std::size_t(d.dimensions()[i]);
  }
  return out;
}
template <class T>
void write(m::Buffer &b, const c::TensorDesc &d, std::span<const T> values) {
  std::vector<std::byte> bytes(b.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    std::memcpy(bytes.data() + offset(d, i), &values[i], sizeof(T));
  require(b.view().write(bytes));
}
void compare(const m::Buffer &b, std::span<const float> expected) {
  std::vector<float> x(expected.size());
  require(b.view().read(std::as_writable_bytes(std::span(x))));
  for (std::size_t i = 0; i < x.size(); ++i) {
    bool match = std::isnan(expected[i]) ? std::isnan(x[i])
                 : std::isinf(expected[i])
                     ? x[i] == expected[i]
                     : std::abs(x[i] - expected[i]) <=
                           1e-6F + std::abs(expected[i]) * 8e-5F;
    if (!match) {
      std::fprintf(stderr, "Mismatch %zu actual=%g expected=%g\n", i, x[i],
                   expected[i]);
      std::exit(3);
    }
  }
}
template <class Fill, class Check>
void journey(c::Operation op, std::span<const c::TensorDesc> inputs, Fill fill,
             Check check) {
  std::vector<m::Buffer> buffers;
  for (const auto &d : inputs)
    buffers.push_back(allocate(d));
  auto context = take(c::cpu::create_context());
  auto queue = take(context.create_queue());
  const auto output = take(c::infer_single_output(op, inputs));
  auto prepared = take(c::prepare(context, op, inputs, std::span(&output, 1),
                                  m::system_resource()));
  if (prepared.provider().id != c::aten_cpu::kProviderId) {
    std::fprintf(stderr, "Unqualified default carrier %.*s\n",
                 int(prepared.provider().name.size()),
                 prepared.provider().name.data());
    std::exit(4);
  }
  auto invocation = take(prepared.create_invocation());
  auto direct = allocate(output), graph_output = allocate(output);
  std::vector<c::ConstTensorView> views;
  for (std::size_t i = 0; i < inputs.size(); ++i)
    views.push_back(
        take(c::ConstTensorView::create(inputs[i], buffers[i].view())));
  const std::array destination{
      take(c::TensorView::create(output, direct.view()))};
  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> ids;
  for (const auto &d : inputs)
    ids.push_back(take(builder.input(d)));
  auto node = take(builder.add_node(op, ids));
  auto result = take(builder.result(node));
  auto final = take(builder.add(c::Copy{}, result));
  require(builder.publish(final));
  auto logical = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto gq = take(gc.create_queue());
  auto compiled = take(g::compile(logical, gc));
  auto gi = take(compiled.executable.create_invocation());
  bool aten = false;
  for (std::size_t i = 0; i < compiled.report.step_count(); ++i)
    aten |=
        take(compiled.report.step(i)).provider.id == c::aten_cpu::kProviderId;
  if (!aten)
    std::exit(5);
  for (std::size_t i = 0; i < ids.size(); ++i)
    require(gi.bind(ids[i], views[i]));
  require(
      gi.bind(final, take(c::TensorView::create(output, graph_output.view()))));
  const std::array lanes{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(gi.prepare_replay(lanes));
  for (int replay = 0; replay < 2; ++replay) {
    fill(buffers, replay);
    require(take(invocation.submit(queue, views, destination)).wait());
    require(take(gi.submit(gq)).wait());
    check(direct, replay);
    check(graph_output, replay);
  }
  require(context.close());
  require(gc.close());
  if (invocation.submit(queue, views, destination) || gi.submit(gq))
    std::exit(6);
}

int main() {
 const auto f=c::DataType::kFloat32;
 const auto index=c::DataType::kInt64;
 const std::array matrix{desc(f,{4,3},true),desc(index,{2,2},true),desc(f,{2,2,3},true)};
 journey(c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),matrix,
  [&](auto &b,int seed){
   std::array<float,12> base,updates;
   for(int i=0;i<12;++i){base[i]=float(i+seed);updates[i]=float(i%3+seed)*.25F;}
   const std::array<std::int64_t,4> ids{2,0,2,3};
   write<float>(b[0],matrix[0],base);write<std::int64_t>(b[1],matrix[1],ids);write<float>(b[2],matrix[2],updates);
  },[&](const auto &b,int seed){
   std::array<float,12> expected;
   for(int i=0;i<12;++i)expected[i]=float(i+seed);
   const std::array<int,4> ids{2,0,2,3};
   for(int i=0;i<4;++i)for(int col=0;col<3;++col)expected[ids[i]*3+col]+=float(col+seed)*.25F;
   compare(b,expected);
  });
 const std::array scalar{desc(f,{2,4,3},true),desc(index,{}),desc(f,{2,3},true)};
 journey(c::Operation(c::Scatter{.axis=1,.kind=c::ScatterKind::kAdd}),scalar,
  [&](auto &b,int seed){
   std::array<float,24> base;for(int i=0;i<24;++i)base[i]=float(i+seed)*.125F;
   const std::array<std::int64_t,1> ids{1};
   const std::array<float,6> updates{float(seed),1,2,3,4,5};
   write<float>(b[0],scalar[0],base);write<std::int64_t>(b[1],scalar[1],ids);write<float>(b[2],scalar[2],updates);
  },[&](const auto &b,int seed){
   std::array<float,24> expected;for(int i=0;i<24;++i)expected[i]=float(i+seed)*.125F;
   const std::array<float,6> added{float(seed),1,2,3,4,5};
   for(int row=0;row<2;++row)for(int col=0;col<3;++col)expected[row*12+3+col]+=added[row*3+col];
   compare(b,expected);
  });
 const std::array empty{desc(f,{2,3},true),desc(index,{0}),desc(f,{0,3})};
 journey(c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),empty,
  [&](auto &b,int seed){const std::array<float,6> base{float(seed),1,2,3,4,5};write<float>(b[0],empty[0],base);},
  [&](const auto &b,int seed){const std::array<float,6> expected{float(seed),1,2,3,4,5};compare(b,expected);});
 std::puts("PASS ordinary mature CPU ScatterAdd Direct/Graph duplicate multi-axis/odd-stride/scalar/empty/changed inputs/close");
}
