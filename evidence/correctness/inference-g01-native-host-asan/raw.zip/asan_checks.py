from pathlib import Path
import subprocess,json,time,os
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';parent=Path('C:/h7/foundation-f5-native-san-vulkan-asan/parent');build=parent.parent/'build'
body=(parent/'CMakeLists.txt').read_text()
if 'g01_resident' not in body:
 for target,filename in [('g01_resident','tests/graph_route_vulkan/mature_tensor_test.cc'),('g01_cache','tests/compute_provider_ggml_vulkan/attention_cache_test.cc')]:
  body+='\nadd_executable('+target+' "'+str(repo/filename).replace('\\','/')+'")\ntarget_compile_features('+target+' PRIVATE cxx_std_23)\ntarget_compile_options('+target+' PRIVATE /W4 /WX /wd4324 /utf-8)\ntarget_link_libraries('+target+' PRIVATE hyle::graph GTest::gtest_main)\nhyle_apply_sanitizer('+target+')\nhyle_stage_runtime('+target+')\n'
 body+='\ntarget_include_directories(g01_cache PRIVATE "'+str(repo/'src/compute_provider_ggml_vulkan').replace('\\','/')+'")\ntarget_link_libraries(g01_cache PRIVATE hyle_compute_provider_ggml_vulkan hyle_compute_ggml_runtime ggml)\n'
 body=body.replace('get_property(HYLE_TARGET_PROCESSOR GLOBAL PROPERTY HYLE_TARGET_PROCESSOR)','get_property(HYLE_TARGET_PROCESSOR GLOBAL PROPERTY HYLE_TARGET_PROCESSOR)\nset(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\nadd_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-gtest EXCLUDE_FROM_ALL)')
 (parent/'CMakeLists.txt').write_text(body,encoding='utf-8',newline='\n')
body=(parent/'CMakeLists.txt').read_text()
if 'hyle_apply_sanitizer(gtest)' not in body:
 body+='\nhyle_apply_sanitizer(gtest)\nhyle_apply_sanitizer(gtest_main)\n'
 (parent/'CMakeLists.txt').write_text(body,encoding='utf-8',newline='\n')
result_file=out/'asan-result.json';old=json.loads(result_file.read_text()) if result_file.exists() else None;records=old['stages'] if old else []
def run(name,args,env=None):
 attempt=1+sum(x['stage']==name for x in records);log=out/('asan-'+name+'-'+str(attempt)+'.log');started=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','scope':'MSVC ASan host HYLE objects/consumers; native GPU shader/driver and LSan not instrumented','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1800));print(f.read(1800).decode('utf-8',errors='replace'))
  raise SystemExit(r.returncode)
run('build',['cmake','--build',str(build),'--target','g01_resident','g01_cache','--parallel','4'])
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True));required=['src/compute_provider_ggml_vulkan/region.cc','tests/graph_route_vulkan/mature_tensor_test.cc','tests/compute_provider_ggml_vulkan/attention_cache_test.cc']
matches=[]
for name in required:
 rows=[x for x in commands if x['file'].replace('\\','/').endswith(name)];assert rows and all('/fsanitize=address' in x['command'].lower() for x in rows),name;matches+=rows
(out/'asan-instrumented-inputs.json').write_text(json.dumps(matches,indent=2)+'\n')
env=os.environ.copy();env['ASAN_OPTIONS']='halt_on_error=1:detect_leaks=0'
run('resident',[str(build/'g01_resident.exe'),'--gtest_filter=VulkanGraph.ResidentAttentionViewsPreserveEffectiveLengthsAndOldResults'],env)
run('cache',[str(build/'g01_cache.exe')],env)
