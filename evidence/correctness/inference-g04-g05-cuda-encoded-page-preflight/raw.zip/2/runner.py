from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile

BASE=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05')
attempt=sys.argv[1];RUN=BASE/'cuda-encoded-page-preflight'/attempt;RUN.mkdir(exist_ok=False)
SOURCE=Path('/root/hyle-scratch/compute-unified')/'g04-cuda-encoded-peer-1'
reuse=attempt!='1'
if not reuse:SOURCE.mkdir(exist_ok=False)
else:
 previous=json.loads((BASE/'cuda-encoded-page-preflight/1/result.json').read_text())
 assert previous['state']=='TERMINAL_FAIL' and SOURCE.is_dir()

record={'state':'SETUP','stages':[],'cumulative_seconds':0,'pid':os.getpid(),
 'scope':'CUDA SM89 BF16 Q/output and FP8 .5/2 immutable paged history. Original cold BF16 snapshot; numeric/readonly/two-slot only, no A/A/P1.',
 'heavy_serial':True,'max_compile_jobs':4,'native_tu_pool':1}
active=None
def save():(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();(RUN/'runner.py').write_bytes(Path(__file__).read_bytes())
def failed(kind,error,traceback):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if active and active.poll() is None else 'TERMINAL_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed
record['identity']={k:subprocess.check_output(cmd,text=True).strip() for k,cmd in (
 ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
 ('gpu',['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader']))}
assert 'RTX 4070' in record['identity']['gpu'] and '8.9' in record['identity']['gpu']
with zipfile.ZipFile(BASE/'cuda-encoded-page-preflight'/('input-'+attempt+'.zip')) as package:
 snapshot=json.loads(package.read('snapshot.json'))
 for item in snapshot['benchmark_inputs']:
  name=Path(item['path']);assert not name.is_absolute() and '..' not in name.parts
  raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
  dest=SOURCE/name;dest.parent.mkdir(parents=True,exist_ok=True)
  if not dest.exists() or dest.read_bytes()!=raw:dest.write_bytes(raw)
record['snapshot']=snapshot
reused_objects=[]
if reuse:
 old_inputs={v['path']:v['sha256'] for v in previous['snapshot']['benchmark_inputs']}
 changed=[v['path'] for v in snapshot['benchmark_inputs'] if old_inputs.get(v['path'])!=v['sha256']]
 assert changed==['bench/inference_resident_sdpa/cuda_encoded_page_reference.cc'],changed
 for obj in sorted((SOURCE/'build').rglob('*.o')):
  assert not obj.name.startswith('CMake'),obj
  reused_objects.append({'path':str(obj),'sha256':hashlib.sha256(obj.read_bytes()).hexdigest()})
 assert len(reused_objects)==3,reused_objects
 record['reuse']={'attempt':'1','changed_inputs':changed,'objects':reused_objects,
  'reason':'Only host Status error conversion changed; original CUDA TU,benchmark and nanobench bytes/flags/SDK remain fixed.'}

record['initial_source_verifier_failure']=json.loads((BASE/'cuda-peer-source-identity-failure-1.json').read_text())
shipping=json.loads((BASE/'sdk/result-cuda-static-1.json').read_text())
assert shipping['state']=='TERMINAL_PASS'
qualified={v['path']:v['sha256'] for v in shipping['inputs']}
for item in snapshot['product_inputs']:
 assert qualified.get(item['path'])==item['sha256'],item['path']+' differs from shipping GPU input'
sdk=Path(shipping['prefix']);artifacts=json.loads((BASE/'sdk/artifacts-cuda-static-1.json').read_text())
def verify_sdk():
 for item in artifacts:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
verify_sdk();record['sdk_artifacts']=artifacts
record['sdk_recipes']=[{'path':str(p.relative_to(sdk)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 for p in sorted((sdk/'lib/cmake').rglob('*')) if p.is_file()]
record['sdk_native_archives']=[{'path':str(p.relative_to(sdk)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 for p in sorted((sdk/'lib').glob('*.a')) if not p.name.startswith('libhyle')]
peer=Path('/root/.cache/hyle/dependencies/v1/sources/flashinfer-69ff11fc4954-dda66e35e348')
env=os.environ.copy();env['HYLE_BENCH_VERIFY_ONLY']='1';env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['CUDA_VISIBLE_DEVICES']='0';env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
def run(stage,args):
 global active
 log=RUN/(stage+'.log');start=time.monotonic()
 with log.open('w') as stream:
  active=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',active_stage=stage,active_pid=active.pid);save();print(stage,active.pid,flush=True);code=active.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)});save()
 print(stage,code,elapsed,flush=True)
 if code:
  record.update(state='TERMINAL_FAIL');save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
build=SOURCE/'build';target='g04_cuda_encoded_bench'
run('configure',['cmake','-S',str(SOURCE/'bench/inference_resident_sdpa/cuda_encoded_peer'),'-B',str(build),'-G','Ninja',
 '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc',
 '-DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_PREFIX_PATH='+str(sdk),
 '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DHYLE_FLASHINFER_ORIGINAL_SOURCE='+str(peer)])
record['original_source']=json.loads((build/'original-flashinfer-source.json').read_text());save()
manifest=RUN/'exact-build.ninja';manifest.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(manifest),'-n',target],env=env,text=True);(RUN/'dry-run.txt').write_text(dry)
assert all(t not in dry for t in ('Re-running CMake','Building CXX object src/','Building C object src/','vulkan-shaders-gen','Building CUDA object src/'))
run('compile',['cmake','--build',str(build),'--target',target,'--parallel','4'])
steps=[s for s in (RUN/'compile.log').read_text().splitlines() if re.search(r'Building (CXX|CUDA) object ',s)]
record['actual_compile_steps']=steps;assert len(steps)==(1 if reuse else 4),steps
for item in reused_objects:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
assert len(list(build.rglob('*.o')))==4
deps=subprocess.check_output(['ninja','-C',str(build),'-t','deps'],text=True);(RUN/'actual-dependencies.txt').write_text(deps)
headers=[]
for line in deps.splitlines():
 name=line.strip()
 if name.startswith('/') and '/flashinfer/' in name:
  p=Path(name);assert p.is_relative_to(peer/'include'),name
  headers.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert headers,'actual original compiler header closure missing'
record['actual_original_headers']=headers
for line in deps.splitlines():
 name=line.strip()
 if name.startswith(str(sdk/'include/hyle')+'/'):
  p=Path(name);canonical='include/hyle/'+str(p.relative_to(sdk/'include/hyle'))
  expected={v['path']:v['sha256'] for v in snapshot['product_inputs']}.get(canonical)
  assert expected==hashlib.sha256(p.read_bytes()).hexdigest(),canonical+' installed public header mismatch'
binary=build/target;record['binary']={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()};save()
run('oracle',[str(binary)])
assert hashlib.sha256(binary.read_bytes()).hexdigest()==record['binary']['sha256'];verify_sdk()
lines=(RUN/'oracle.log').read_text().splitlines()
numeric=[line for line in lines if line.startswith('# CUDA_ENCODED_CORRECTNESS ')]
assert len(numeric)==24 and sum(line.startswith('# CUDA_FP8_PAIR ') for line in lines)==3
facts=[re.sub(r' original=[01]$', '',line) for line in lines if line.startswith('# CUDA_ENCODED_ENV ')]
assert len(facts)==6 and len(set(facts))==1
record['native_environment']=facts[0]
record['max_abs_error']=max(float(re.search(r'max_abs_error=([^ ]+)',line)[1]) for line in numeric)
assert record['max_abs_error']<=8e-3
assert sum(line.startswith('# CUDA_ENCODED_ORIGINAL_COLD ') for line in lines)==3
record.update(state='TERMINAL_PASS',replays=4,slots=2,readonly='PASS');save()
