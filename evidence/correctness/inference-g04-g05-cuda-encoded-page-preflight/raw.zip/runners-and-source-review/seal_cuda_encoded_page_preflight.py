from pathlib import Path
import hashlib,json,zipfile
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';RUNS=BASE/'cuda-encoded-page-preflight'
jobs=sorted(RUNS.glob('job-*.json'),key=lambda p:int(p.stem.split('-')[-1]))
assert jobs
runs=[]
for path in jobs:
 job=json.loads(path.read_text());number=path.stem.split('-')[-1]
 result=RUNS/number/'result.json'
 assert job['state'] in ('TERMINAL_PASS','TERMINAL_FAIL'),'actual terminal state required'
 runs.append({'attempt':number,'job':job,'result':json.loads(result.read_text())})
last=runs[-1];assert last['job']['state']=='TERMINAL_PASS' and last['job']['exit_code']==0
successful=last['result'];assert successful['state']=='TERMINAL_PASS'
assert len(successful['actual_compile_steps'])+len(successful.get('reuse',{}).get('objects',[]))==4 and successful['replays']==4 and successful['slots']==2
assert successful['readonly']=='PASS' and successful['max_abs_error']<=8e-3
dest=ROOT/'evidence/correctness/inference-g04-g05-cuda-encoded-page-preflight';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for p in sorted(RUNS.rglob('*')):
  if p.is_file():package.write(p,p.relative_to(RUNS).as_posix())
 for name in ('launch_cuda_encoded_page_preflight.py','cuda_encoded_page_preflight_wsl.py','seal_cuda_encoded_page_preflight.py',
   'cuda-original-source-identity.json','cuda-peer-source-identity-failure-1.json','cuda-peer-batch-review.json','cuda-peer-validation-plan.json'):
  p=BASE/name
  if p.is_file():package.write(p,'runners-and-source-review/'+name)
receipt={'state':'TERMINAL_PASS','kind':'G04_G05_CUDA_ENCODED_PAGE_NUMERIC_PREFLIGHT_ONLY','runs':runs,
 'successful_run':successful,'cumulative_measured_stage_seconds':sum(r['result']['cumulative_seconds'] for r in runs),
 'limits':['Numeric/source lifecycle only; no A/A or performance verdict','BF16 Q/output,FP8 .5/2,three shapes; no F16 or producer/growth inference',
  'SDK CPU predates CE12/13; GPU-only claim','Initial source verifier failed before compiler; elapsed UNKNOWN; preserved',
  'Native private-pool upper, driver/shader sanitizer coverage UNKNOWN'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'state':receipt['state'],'path':str(dest)}))
