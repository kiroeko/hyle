from pathlib import Path
import hashlib,json,subprocess,sys,time,zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=sys.argv[1]
assert json.loads((BASE/'cpu-encoded-p1-job-4.json').read_text())['state']=='TERMINAL'
vulkan=json.loads((BASE/'vulkan-encoded-p1/1/remote/job.json').read_text())
assert vulkan['state'] in ('TERMINAL','TERMINAL_SETUP_FAIL')
apple_jobs=sorted((BASE/'apple-encoded-page-preflight').glob('job-*.json'),key=lambda p:int(p.stem.split('-')[-1]))
assert apple_jobs
latest=apple_jobs[-1];apple_job=json.loads(latest.read_text());apple_attempt=latest.stem.split('-')[-1]
assert apple_job['state'] in ('TERMINAL_PASS','TERMINAL_FAIL'),'latest actual Apple observation must be terminal'
apple=json.loads((BASE/'apple-encoded-page-preflight'/apple_attempt/'result.json').read_text())
assert apple['state'] in ('TERMINAL_PASS','TERMINAL_FAIL')
formal=BASE/'apple-encoded-p1/1/remote/job.json'
if apple['state']=='TERMINAL_PASS':
 assert formal.is_file() and json.loads(formal.read_text())['state'] in ('TERMINAL','TERMINAL_SETUP_FAIL')
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
OUT=BASE/'cuda-encoded-page-preflight';OUT.mkdir(exist_ok=True)
archive=OUT/('input-'+attempt+'.zip');assert not archive.exists()
paths=['bench/inference_resident_sdpa/'+name for name in ('cuda_encoded_page_bench.cc','cuda_encoded_page_reference.cc',
 'cuda_encoded_page_reference.h','cuda_encoded_page_native.cu','cuda_encoded_page_native.h','cuda_encoded_peer/CMakeLists.txt','cuda_encoded_peer/verify_source.py')]
paths+=['bench/nanobench_impl.cc','bench/common/perf_process.h','third_party/nanobench/nanobench.h']
private=subprocess.check_output(['git','ls-files','src/compute/*.h','src/compute_backend_cuda/*.h'],text=True).splitlines()
paths+=private
products=subprocess.check_output(['git','ls-files','include/hyle','src/compute_batch','src/graph_batch',
 'src/compute_backend_cuda','src/compute_provider_flashinfer','third_party/flashinfer_cache'],text=True).splitlines()+private
snapshot={'canonical_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'product_inputs':[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in sorted(set(products))],
 'benchmark_inputs':[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in sorted(set(paths))]}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for item in snapshot['benchmark_inputs']:package.write(ROOT/item['path'],item['path'])
 package.writestr('snapshot.json',json.dumps(snapshot,indent=2)+'\n')
started=time.monotonic();log=OUT/('launch-'+attempt+'.log')
command=['wsl','-e','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/cuda_encoded_page_preflight_wsl.py',attempt]
with log.open('wb') as stream:
 child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 job={'state':'OBSERVING','pid':child.pid,'command':command,'log':str(log)}
 (OUT/('job-'+attempt+'.json')).write_text(json.dumps(job,indent=2)+'\n');print(json.dumps(job),flush=True);code=child.wait()
result=OUT/attempt/'result.json';state=json.loads(result.read_text())['state'] if result.is_file() else None
job.update(state=state if state in ('TERMINAL_PASS','TERMINAL_FAIL') else 'OBSERVER_ERROR_WSL_STATE_UNCONFIRMED',
 exit_code=code,elapsed_seconds=time.monotonic()-started)
(OUT/('job-'+attempt+'.json')).write_text(json.dumps(job,indent=2)+'\n');print(json.dumps(job),flush=True)
if not (state=='TERMINAL_PASS' and code==0):raise SystemExit(1)
for command in (
 [sys.executable,str(BASE/'seal_cuda_encoded_page_preflight.py')],
 [sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/correctness/inference-g04-g05-cuda-encoded-page-preflight','test(compute): qualify original CUDA cold-expanded encoded peer'],
 [sys.executable,str(BASE/'launch_cuda_encoded_p1.py'),'1']):
 result=subprocess.run(command)
 if result.returncode:
  if command[1].endswith('launch_cuda_encoded_p1.py'):
   terminal=BASE/'cuda-encoded-p1/1/job.json'
   if terminal.is_file() and json.loads(terminal.read_text())['state'] in ('TERMINAL','TERMINAL_SETUP_FAIL'):
    subprocess.run([sys.executable,str(BASE/'seal_cuda_encoded_p1.py'),'1'],check=True)
    subprocess.run([sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-1','test(compute): seal CUDA encoded-page performance result'],check=True)
  raise SystemExit(result.returncode)
subprocess.run([sys.executable,str(BASE/'seal_cuda_encoded_p1.py'),'1'],check=True)
subprocess.run([sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-1','test(compute): seal CUDA encoded-page performance result'],check=True)

