from pathlib import Path
from fractions import Fraction
import hashlib,json,struct,zipfile
root=Path.cwd();dest=root/'evidence/architecture/inference-g04-g05-cuda-output-cost-audit'
def bf16(value):
 bits=struct.unpack('<I',struct.pack('<f',value))[0]
 rounded=(bits+0x7fff+((bits>>16)&1))&0xffff0000
 return struct.unpack('<f',struct.pack('<I',rounded))[0]
def half(value):return struct.unpack('<e',struct.pack('<e',value))[0]
rows=[]
for kind,count,convert in [('BF16',64,bf16),('F16',256,half)]:
 positive=Fraction(128*(count-1)+144,count);negative=Fraction(-128)
 exact=(positive+negative)*512/2
 narrowed=(convert(float(positive))+convert(float(negative)))*512/2
 assert exact>0 and narrowed==0 and half(float(exact))==float(exact) and bf16(float(exact))==float(exact)
 rows.append(dict(partial_type=kind,rows_per_equal_chunk=count,total_kv_rows=2*count,
  first_chunk='one FP8 code0x71(144),remaining code0x70(128)',second_chunk='all FP8 code0xf0(-128)',
  q_and_k=0,value_scale=512,positive_raw_partial=str(positive),negative_raw_partial=-128,
  exact_f32_partial_final_output=float(exact),narrow_raw_partial_then_merge_output=narrowed))
proof=dict(kind='EXACT_ARITHMETIC_COUNTEREXAMPLE_NOT_GPU_EXECUTION',scope='Existing page16 FP8 scaled-cache input domain: zeroQ/K yields uniform weights; equal chunks,exact representable E4M3 codes and positiveF32 scale512. Output16/64 fits bothF16/BF16. This refutes raw16-bit partial narrowing as a general equivalent replacement; no claim about runtime partition selection.',rows=rows)
p=root/'.scratch/inference-gaps/g04-g05/cuda-resource-readonly-6/partial-precision-counterexamples.json';p.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(dest/'raw.zip','a',zipfile.ZIP_DEFLATED) as z:
 assert 'partial-precision-counterexamples.json' not in z.namelist()
 z.write(p,'partial-precision-counterexamples.json');z.write(Path(__file__),'runners/'+Path(__file__).name)
p=dest/'receipt.json';receipt=json.loads(p.read_text(encoding='utf-8'));receipt['partial_precision_counterexamples']=proof;receipt['raw_zip_sha256']=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest();p.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
