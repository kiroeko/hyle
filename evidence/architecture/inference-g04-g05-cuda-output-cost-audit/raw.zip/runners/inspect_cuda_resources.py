from pathlib import Path
import hashlib,json,re,subprocess,time
base=Path('/root/hyle-scratch/compute-unified')
binary=base/'g04-cuda-encoded-p1-fresh-6/bin/g04_cuda_encoded_bench'
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/cuda-resource-readonly-6');out.mkdir(exist_ok=False)
before=hashlib.sha256(binary.read_bytes()).hexdigest();start=time.monotonic()
command=['/usr/local/cuda-13.3/bin/cuobjdump','--dump-resource-usage',str(binary)]
r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert r.returncode==0
(out/'resources-mangled.txt').write_text(r.stdout)
d=subprocess.run(['c++filt'],input=r.stdout,stdout=subprocess.PIPE,text=True);assert d.returncode==0
(out/'resources-demangled.txt').write_text(d.stdout)
lines=d.stdout.splitlines();selected=[]
for i,line in enumerate(lines):
 if 'BatchPrefillWithPagedKVCacheKernel<' in line or 'PersistentVariableLengthMergeStatesKernel<' in line or 'scale_cast<' in line:
  selected.append('\n'.join(lines[i:i+3]))
assert selected
record=dict(state='READ_ONLY_STATIC_RESOURCES_NO_RUNTIME_VERDICT',binary=str(binary),binary_sha256=before,command=command,elapsed_seconds=time.monotonic()-start,kernels=selected)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==before
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'matched_kernels':len(selected),'elapsed_seconds':record['elapsed_seconds'],'first':selected[:7]},indent=2))
