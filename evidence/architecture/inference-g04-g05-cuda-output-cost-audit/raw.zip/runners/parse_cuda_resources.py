from pathlib import Path
import json,re
p=Path('.scratch/inference-gaps/g04-g05/cuda-resource-readonly-6')
lines=(p/'resources-demangled.txt').read_text(encoding='utf-8').splitlines();rows=[];arch=None
for i,line in enumerate(lines[:-1]):
 if line.startswith('arch = '):arch=line.split('=',1)[1].strip()
 if arch!='sm_89' or not re.search(r'KernelTraits<\([^)]*::MaskMode\)1,',line):continue
 if 'BatchPrefillWithPagedKVCacheKernel<' not in line or 'BatchPrefillPagedParams<__nv_bfloat16,' not in line:continue
 if 'DefaultAttention<false, true, false, false>' not in line:continue
 m=re.search(r'KernelTraits<[^,]+, (\d+)u, (\d+)u, (\d+)u, (\d+)u, (\d+)u, (\d+)u, (\d+)u,',line)
 if not m:continue
 fields=list(map(int,m.groups()));tile,q,kv,k,v,wq,wkv=fields
 if tile!=64 or q!=1 or (k,v)!=(16,16):continue
 if 'hyle_benchmark_original_flashinfer_69ff::' in line:route='pristine_bf16'
 elif 'BatchPrefillPagedParams<__nv_bfloat16, __nv_fp8_e4m3, float, int>' in line:route='selected_fp8_f32'
 else:continue
 rows.append(dict(route=route,arch=arch,mask='causal',tile=tile,kv_mma=kv,dimensions=[k*16,v*16],threads=wq*wkv*32,resource=lines[i+1].strip(),function=line.strip()))
assert rows and {r['route'] for r in rows}=={'pristine_bf16','selected_fp8_f32'}
(p/'d256-comparison.json').write_text(json.dumps(dict(state='STATIC_DIAGNOSTIC_NOT_RUNTIME_SELECTION',rows=rows),indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k!='function'} for r in rows],indent=2))
