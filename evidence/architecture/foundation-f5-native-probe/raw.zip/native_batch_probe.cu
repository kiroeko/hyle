#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <flashinfer/attention/default_prefill_params.cuh>
#include <flashinfer/attention/prefill.cuh>
#include <flashinfer/attention/scheduler.cuh>
#include <flashinfer/attention/variants.cuh>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <type_traits>
#include <vector>

namespace fi=flashinfer;
void check(cudaError_t error){if(error!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(error));}
struct DeviceBytes {
  void* pointer=nullptr;std::size_t bytes=0;
  explicit DeviceBytes(std::size_t n):bytes(n){check(cudaMalloc(&pointer,n));}
  ~DeviceBytes(){cudaFree(pointer);}
  template<class T>T* get(std::size_t offset=0){return reinterpret_cast<T*>(static_cast<char*>(pointer)+offset);}
};
struct PinnedBytes {
  void* pointer=nullptr;explicit PinnedBytes(std::size_t n){check(cudaMallocHost(&pointer,n));}
  ~PinnedBytes(){cudaFreeHost(pointer);}
};
template<class T>T encode(float value){if constexpr(std::is_same_v<T,half>)return __float2half(value);else return __float2bfloat16(value);}
template<class T>float decode(T value){if constexpr(std::is_same_v<T,half>)return __half2float(value);else return __bfloat162float(value);}
template<class T>void upload(DeviceBytes&to,const std::vector<T>&from,cudaStream_t stream){check(cudaMemcpyAsync(to.pointer,from.data(),from.size()*sizeof(T),cudaMemcpyHostToDevice,stream));}
template<class P>void bind_plan(P&params,const fi::PrefillPlanInfo&plan,DeviceBytes&integer){
  params.request_indices=integer.get<int>(plan.request_indices_offset);
  params.qo_tile_indices=integer.get<int>(plan.qo_tile_indices_offset);
  params.kv_tile_indices=integer.get<int>(plan.kv_tile_indices_offset);
  params.o_indptr=integer.get<int>(plan.o_indptr_offset);
  params.kv_chunk_size_ptr=integer.get<int>(plan.kv_chunk_size_ptr_offset);
  params.padded_batch_size=plan.padded_batch_size;params.max_total_num_rows=plan.total_num_rows;
  if(plan.split_kv)throw std::runtime_error("probe disabled splitKV but native plan split");
}
template<bool Paged,class P>cudaError_t launch(P params,const fi::PrefillPlanInfo&plan,cudaStream_t stream){
  using Variant=fi::DefaultAttention<false,false,false,false>;
  switch(plan.cta_tile_q){
#define PROBE_TILE(tile) case tile: if constexpr(Paged)return fi::BatchPrefillWithPagedKVCacheDispatched<tile,64,64,fi::PosEncodingMode::kNone,false,fi::MaskMode::kCausal,Variant>(params,nullptr,nullptr,false,stream);else return fi::BatchPrefillWithRaggedKVCacheDispatched<tile,64,64,fi::PosEncodingMode::kNone,false,fi::MaskMode::kCausal,Variant>(params,nullptr,nullptr,false,stream)
    PROBE_TILE(16);PROBE_TILE(64);PROBE_TILE(128);
#undef PROBE_TILE
  }
  throw std::runtime_error("native CTA tile outside original dispatch domain");
}
template<class T>void run(bool paged,cudaStream_t stream){
  constexpr unsigned heads=4,kv_heads=2,depth=64,page=16,arena_pages=4,rows=3;
  const std::vector<int> queries{0,1,3},logical_kv{0,19,29},page_indptr{0,2,3},indices{2,0,3},tails{3,10};
  std::vector<T> q(rows*heads*depth),k(29*kv_heads*depth),v(k.size());
  for(std::size_t i=0;i<q.size();++i)q[i]=encode<T>(0.2f*std::sin(float(i)*0.017f));
  for(std::size_t i=0;i<k.size();++i){k[i]=encode<T>(0.3f*std::cos(float(i)*0.019f));v[i]=encode<T>(std::sin(float(i)*0.013f)+float(i%11)*0.01f);}
  std::vector<T> kp(arena_pages*page*kv_heads*depth,encode<T>(64.f)),vp(kp.size(),encode<T>(64.f));
  for(unsigned request=0;request<2;++request)for(int token=0;token<logical_kv[request+1]-logical_kv[request];++token){
    const auto physical=indices[page_indptr[request]+token/page]*page+token%page;
    for(unsigned hd=0;hd<kv_heads*depth;++hd){kp[physical*kv_heads*depth+hd]=k[(logical_kv[request]+token)*kv_heads*depth+hd];vp[physical*kv_heads*depth+hd]=v[(logical_kv[request]+token)*kv_heads*depth+hd];}
  }
  DeviceBytes dq(q.size()*sizeof(T)),dk((paged?kp:k).size()*sizeof(T)),dv((paged?vp:v).size()*sizeof(T)),output(q.size()*sizeof(T));
  DeviceBytes dquery(queries.size()*sizeof(int)),dkv((paged?page_indptr:logical_kv).size()*sizeof(int)),dindices(indices.size()*sizeof(int)),dtails(tails.size()*sizeof(int));
  upload(dq,q,stream);upload(dk,paged?kp:k,stream);upload(dv,paged?vp:v,stream);upload(dquery,queries,stream);upload(dkv,paged?page_indptr:logical_kv,stream);upload(dindices,indices,stream);upload(dtails,tails,stream);
  auto host_q=queries,host_kv=paged?page_indptr:logical_kv;std::size_t float_bytes=0,int_bytes=0;
  check(fi::PrefillPlanWorkspaceSize(float_bytes,int_bytes,host_q.data(),host_kv.data(),rows,2,heads,kv_heads,depth,depth,paged?page:1,false,sizeof(T),-1,-1,true,0,0,stream,sizeof(T)));
  DeviceBytes floating(std::max<std::size_t>(float_bytes,16)),integer(std::max<std::size_t>(int_bytes,16));PinnedBytes pinned(std::max<std::size_t>(int_bytes,16));fi::PrefillPlanInfo plan;
  check(fi::PrefillPlan(floating.pointer,float_bytes,integer.pointer,pinned.pointer,int_bytes,plan,host_q.data(),host_kv.data(),rows,2,heads,kv_heads,depth,depth,paged?page:1,false,sizeof(T),-1,-1,true,0,0,stream,sizeof(T)));
  if(paged){fi::BatchPrefillPagedParams<T,T,T,int> params;params.q=dq.get<T>();params.o=output.get<T>();params.q_indptr=dquery.get<int>();params.paged_kv=fi::paged_kv_t<T,int>(kv_heads,page,depth,2,fi::QKVLayout::kNHD,dk.get<T>(),dv.get<T>(),dindices.get<int>(),dkv.get<int>(),dtails.get<int>());
    params.num_qo_heads=heads;params.group_size=fi::uint_fastdiv(heads/kv_heads);params.q_stride_n=heads*depth;params.q_stride_h=depth;params.window_left=-1;params.sm_scale=1.f/std::sqrt(float(depth));bind_plan(params,plan,integer);check(launch<true>(params,plan,stream));
  }else{fi::BatchPrefillRaggedParams<T,T,T,int> params;params.q=dq.get<T>();params.k=dk.get<T>();params.v=dv.get<T>();params.o=output.get<T>();params.q_indptr=dquery.get<int>();params.kv_indptr=dkv.get<int>();
    params.num_qo_heads=heads;params.num_kv_heads=kv_heads;params.group_size=fi::uint_fastdiv(heads/kv_heads);params.q_stride_n=heads*depth;params.q_stride_h=depth;params.k_stride_n=params.v_stride_n=kv_heads*depth;params.k_stride_h=params.v_stride_h=depth;params.window_left=-1;params.sm_scale=1.f/std::sqrt(float(depth));bind_plan(params,plan,integer);check(launch<false>(params,plan,stream));
  }
  std::vector<T> result(q.size());check(cudaMemcpyAsync(result.data(),output.pointer,result.size()*sizeof(T),cudaMemcpyDeviceToHost,stream));check(cudaStreamSynchronize(stream));double maximum=0;
  for(unsigned request=0;request<2;++request){const int qlen=queries[request+1]-queries[request],kvlen=logical_kv[request+1]-logical_kv[request];
    for(int qi=0;qi<qlen;++qi)for(unsigned head=0;head<heads;++head){const int valid=kvlen-qlen+qi+1;const unsigned kv_head=head/(heads/kv_heads);std::vector<double> score(valid);double high=-1e100,sum=0;
      for(int token=0;token<valid;++token){double dot=0;for(unsigned d=0;d<depth;++d)dot+=double(decode(q[((queries[request]+qi)*heads+head)*depth+d]))*decode(k[((logical_kv[request]+token)*kv_heads+kv_head)*depth+d]);score[token]=dot/std::sqrt(double(depth));high=std::max(high,score[token]);}
      for(auto&x:score){x=std::exp(x-high);sum+=x;}for(unsigned d=0;d<depth;++d){double oracle=0;for(int token=0;token<valid;++token)oracle+=score[token]/sum*decode(v[((logical_kv[request]+token)*kv_heads+kv_head)*depth+d]);const double difference=std::abs(decode(result[((queries[request]+qi)*heads+head)*depth+d])-oracle);maximum=std::max(maximum,difference);if(!std::isfinite(difference)||difference>0.007)throw std::runtime_error("native paged/ragged independent dense oracle differs");}
    }
  }
  std::printf("NATIVE_CXX_PROBE %s %s rows=3 requests=2 qlens=1,2 kvlens=19,10 physicalPages=2,0,3 tail=3,10 GQA=2 cta=%lld split=%d floatWorkspace=%zu intWorkspace=%zu maxError=%.9g PASS\n",paged?"paged":"ragged",std::is_same_v<T,half>?"F16":"BF16",static_cast<long long>(plan.cta_tile_q),plan.split_kv,float_bytes,int_bytes,maximum);std::fflush(stdout);
}
int main(){cudaStream_t stream=nullptr;try{check(cudaSetDevice(0));check(cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking));run<half>(true,stream);run<half>(false,stream);run<__nv_bfloat16>(true,stream);run<__nv_bfloat16>(false,stream);check(cudaStreamDestroy(stream));return 0;}catch(const std::exception&e){std::fprintf(stderr,"native C++ prototype: %s\n",e.what());if(stream){cudaStreamSynchronize(stream);cudaStreamDestroy(stream);}return 1;}}
