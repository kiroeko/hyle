#include <hyle/compute/batch_ops.h>
#include <hyle/compute/batch_paged_native.h>
#include <hyle/compute/low_precision.h>
#include <hyle/compute/paged_arena.h>
#include <array>
#include <algorithm>
#include <cstdio>

namespace c=hyle::compute;
using hyle::Status;
Status require(bool ok,const char*text){return ok?Status::Ok():Status::Internal(text);}
Status probe(){
  const c::BatchCapacity cap{.max_query_rows=2,.max_kv_rows=2,.max_pages=2,.max_page_refs=1,
      .query_heads=8,.kv_heads=2,.head_dim=256};
  HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(cap));
  HYLE_ASSIGN_OR_RETURN(auto recipe,c::NativePagedBatchProgram::prepare(schema,
      {.max_host_metadata_bytes=1024,.causal=false}));
  HYLE_ASSIGN_OR_RETURN(auto arena,c::PagedArena::create(schema,hyle::mem::system_resource(),
      {.max_backing_bytes=32769}));
  HYLE_ASSIGN_OR_RETURN(auto weight,c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,
      c::DataType::kFloat32,256,1));
  HYLE_ASSIGN_OR_RETURN(auto encoded,c::TensorDesc::blocked_dense(c::DataType::kFloat32,
      std::array<std::int64_t,4>{2,16,2,256},weight.storage_format()));
  HYLE_ASSIGN_OR_RETURN(auto encoded_bytes,encoded.required_bytes());
  HYLE_ASSIGN_OR_RETURN(auto original_bytes,recipe.descriptions()[1].required_bytes());
  HYLE_RETURN_IF_ERROR(require(arena.page_bytes()==16384 && original_bytes==32768 &&
      encoded_bytes==17408,"current plain versus native Q8_0 geometry differs unexpectedly"));
  std::array<c::TensorDesc,4> ports;
  std::copy(recipe.descriptions().begin(),recipe.descriptions().end(),ports.begin());
  ports[1]=encoded;ports[2]=encoded;
  std::array<c::TensorDesc,1> output;
  HYLE_RETURN_IF_ERROR(require(!c::infer_batch_attention(cap,c::BatchStorage::kPaged,ports,output).ok(),
      "current batch unexpectedly admits truthful Q8_0 cache descriptions"));
  const std::array<std::int32_t,2> q{0,2},kv{0,1};
  const std::array<std::int32_t,1> page{0},tail{1};
  const auto version=schema.version({q,kv,page,tail});
  HYLE_RETURN_IF_ERROR(require(!recipe.causal() && !version && version.error().IsInvalidArgument(),
      "current noncausal Q>KV layout restriction changed"));
  auto fp8=cap;fp8.data_type=c::DataType::kFloat8E4M3FN;
  HYLE_RETURN_IF_ERROR(require(!c::BatchSchema::create(fp8),"current batch unexpectedly admits FP8 capacity"));
  std::printf("OBSERVED DOMAIN GAP: typed GGUF Q8_0 root17408 bytes exists, current plain root32768/page16384 rejects it; full noncausal recipe still cannot create Q2/KV1 layout; current FP8 capacity rejects. No native quant/window capability PASS.\n");
  return Status::Ok();
}
int main(){const auto s=probe();if(!s.ok())std::fprintf(stderr,"%.*s\n",int(s.message().size()),s.message().data());return s.ok()?0:1;}
