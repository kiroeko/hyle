"""One predeclared local mini-dump attempt for the observed diagnostic AV."""
from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,time,winreg
ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
ATTEMPT=OUT/'wer-crash-1'
PARENT=r'SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps'
KEY=PARENT+r'\g09_observed_driver.exe'
ACCESS=winreg.KEY_READ|winreg.KEY_WRITE|winreg.KEY_WOW64_64KEY
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert ctypes.windll.shell32.IsUserAnAdmin()
assert not ATTEMPT.exists() and not (OUT/'run-wer-crash-1').exists()
auth=json.loads((OUT/'wer-crash-authorization.json').read_text(encoding='utf8'))
for row in auth['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
def exists(path):
 try:
  with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,path,0,winreg.KEY_READ|winreg.KEY_WOW64_64KEY):return True
 except FileNotFoundError:return False
assert not exists(KEY), 'Do not replace existing per-app dump configuration'
with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\AeDebug',0,winreg.KEY_READ|winreg.KEY_WOW64_64KEY) as k:
 try:auto=winreg.QueryValueEx(k,'Auto')[0]
 except FileNotFoundError:auto=None
assert auto not in ['1',1], 'Automatic debugging precludes WER local dump'
parent_existed=exists(PARENT)
ATTEMPT.mkdir();dumps=ATTEMPT/'dumps';dumps.mkdir()
expected={'DumpFolder':(str(dumps),winreg.REG_EXPAND_SZ),'DumpCount':(1,winreg.REG_DWORD),'DumpType':(1,winreg.REG_DWORD)}
result=dict(state='SETTING_UP',key=KEY,parent_preexisted=parent_existed,per_app_preexisted=False,
    settings={n:dict(value=v,type=t) for n,(v,t) in expected.items()},auto_debug=auto,
    source_product_changes=0,builds=0,planned_application_processes=1,ranking=False)
stamp=time.monotonic();owned_key=False;child=None
def save():
 result['elapsed_seconds']=time.monotonic()-stamp
 (ATTEMPT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
try:
 with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE,KEY,0,ACCESS) as key:
  owned_key=True
  # KEY was verified absent; do not alter any unrelated/global key values.
  for name,(value,kind) in expected.items():winreg.SetValueEx(key,name,0,kind,value)
  for name,(value,kind) in expected.items():assert winreg.QueryValueEx(key,name)==(value,kind)
 result['state']='RUNNING';save()
 with (ATTEMPT/'launcher.log').open('wb') as log:
  child=subprocess.Popen([sys.executable,'-B','-X','utf8',str(ROOT/'.scratch/inference-gaps/g09_run_completion_observation_wer.py')],
    cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  result['owned_launcher_pid']=child.pid;save();print('OWNED_CRASH_ATTEMPT',child.pid,flush=True)
  while True:
   try:code=child.wait(timeout=1800);break
   except subprocess.TimeoutExpired:
    result.setdefault('extensions',[]).append(dict(pid=child.pid,seconds=1800));save()
 result.update(state='APPLICATION_ATTEMPT_TERMINAL',launcher_exit_code=code)
except BaseException as error:
 result.update(state='SETUP_OR_LAUNCH_FAIL',error=repr(error))
 if child is not None and child.poll() is None:
  cleanup=subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True,text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
  result['owned_cleanup']=dict(pid=child.pid,exit_code=cleanup.returncode,stdout=cleanup.stdout,stderr=cleanup.stderr)
  if child.poll() is None:child.kill()
  child.wait()
 raise
finally:
 try:
  if owned_key and exists(KEY):
   with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,KEY,0,ACCESS) as key:
    subkeys,values,_=winreg.QueryInfoKey(key)
    assert subkeys==0 and values<=len(expected), 'Foreign changes: preserve configuration'
    for index in range(values):
     name,value,kind=winreg.EnumValue(key,index)
     assert name in expected and (value,kind)==expected[name], 'Foreign changes: preserve configuration'
   winreg.DeleteKeyEx(winreg.HKEY_LOCAL_MACHINE,KEY,winreg.KEY_WOW64_64KEY)
   assert not exists(KEY)
  if not parent_existed and exists(PARENT):
   with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,PARENT,0,ACCESS) as key:
    subkeys,values,_=winreg.QueryInfoKey(key)
   assert subkeys==0 and values==0, 'New parent contains foreign data: preserve it'
   winreg.DeleteKeyEx(winreg.HKEY_LOCAL_MACHINE,PARENT,winreg.KEY_WOW64_64KEY)
  result['registry_restored']=not exists(KEY) and exists(PARENT)==parent_existed
 except BaseException as cleanup_error:
  result['registry_restoration_error']=repr(cleanup_error)
 result['dumps']=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(dumps.glob('*.dmp'))]
 save()
print(json.dumps(result,indent=2),flush=True)
assert result.get('registry_restored') is True, 'Own per-app dump setting restoration failed'
