"""One targeted first-chance AV capture in the observed Nsight combination."""
from pathlib import Path
import ast,ctypes,hashlib,json,os,re,secrets,sqlite3,subprocess,sys,time
ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
RUN=OUT/'run-nsys-procdump-1'
BUILD=Path('C:/h7/g09-completion-observation-25')
NSYS=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
PROC=Path('C:/h7/g09-procdump-1/procdump64.exe')
TOOLS=Path('C:/h7/g09-p1-peer-9e2/scripts')
sys.path.insert(0,str(TOOLS))
from hyle_perf import evaluate_machine_profile,expected_child_policy,get_machine_profile,load_registry,probe_machine
from hyle_perf.runner import _apply_sampling_policy,_child_environment,_creation_flags,_probe_child_policy
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert ctypes.windll.shell32.IsUserAnAdmin() and not RUN.exists()
auth=json.loads((OUT/'nsys-procdump-authorization.json').read_text(encoding='utf8'))
assert auth['decision']=='ALLOW_ONE_TARGETED_AV_DUMP_DIAGNOSTIC'
for row in auth['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
host=probe_machine(paths=[('build',BUILD)]);profile=get_machine_profile(load_registry(),'W1-WIN')
gate=evaluate_machine_profile(profile,host,role='engineering',sampling_topology='native-runtime-pair')
assert gate['gate']=='PASS',gate
policy=expected_child_policy(profile,sampling_topology='native-runtime-pair',probe=host)
nonce=secrets.token_hex(16)
env=_child_environment(['HYLE_BENCH_AA_ROUTE','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_APPLE_QOS'],
 {'HYLE_BENCH_AA_ROUTE':'candidate','HYLE_BENCH_RIVAL_FIRST':'0','HYLE_BENCH_PEER_ALLOCATION_FIRST':'0','HYLE_PERF_RUN_NONCE':nonce},profile,policy)
env['DISABLE_VULKAN_OBS_CAPTURE']='1'
assert not any(k.upper() in ['CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH'] for k in env)
RUN.mkdir();(RUN/'dumps').mkdir();started=time.monotonic()
result=dict(state='RUNNING',stages=[],qualification='DIAGNOSTIC_ONLY',valid_formal_ab=0,
 math_application_processes_planned=1,first_chance_only=True,maximum_dumps=1,builds=0,source_product_changes=0,
 authorization_sha256=sha(OUT/'nsys-procdump-authorization.json'))
def save():
 result['elapsed_seconds']=time.monotonic()-started
 (RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
# Existing reviewed wait/owned-tree cleanup; only its target-log path changes.
old=(ROOT/'.scratch/inference-gaps/g09_run_completion_observation_admin_retry.py').read_text(encoding='utf8')
for node in ast.parse(old).body:
 if isinstance(node,ast.FunctionDef) and node.name in ['run','stop_owned_application_on_failure']:
  source=ast.get_source_segment(old,node)
  if node.name=='stop_owned_application_on_failure':source=source.replace("path=RUN/'profile.log'","path=RUN/'embedded-stderr.log'")
  exec(compile(source,'<existing-reviewed-owned-helper>','exec'))
command=[NSYS,'profile','--trace=vulkan,nvtx','--sample=none','--cpuctxsw=none','--backtrace=none',
 '--vulkan-gpu-workload=batch','--wait=all','--stop-on-exit=true','--kill=true','--show-output=true',
 '--output',RUN/'trace',PROC,'-accepteula','-mt','-e','1','-f','C0000005','-n','1','-x',RUN/'dumps',BUILD/'bin/g09_observed_driver.exe']
try:
 with _apply_sampling_policy(policy) as applied:
  result['policy']=applied;result['child_canary']=_probe_child_policy(policy,_creation_flags(policy));save()
  try:run('profile',command,_creation_flags(policy),env)
  except RuntimeError as error:result['profile_nonzero_retained']=str(error);save()
 if (RUN/'trace.nsys-rep').is_file():
  run('export',[NSYS,'export','--type=sqlite','--output',RUN/'trace.sqlite',RUN/'trace.nsys-rep'],
      subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS,dict(os.environ))
  c=sqlite3.connect(f'file:{(RUN/"trace.sqlite").as_posix()}?mode=ro',uri=True);c.row_factory=sqlite3.Row
  schema=[dict(r) for r in c.execute("select name,sql from sqlite_master where type='table' order by name")]
  (RUN/'sqlite-schema.json').write_text(json.dumps(schema,indent=2)+'\n',encoding='utf8')
  stderr=[]
  for row in c.execute('select a.filename,s.value from ANALYSIS_FILE a left join StringIds s on a.contentId=s.id'):
   if Path(row['filename']).name.startswith('stderr_'):
    stderr.append(row['value'] or '')
  text='\n'.join(stderr).replace(chr(0),'').replace('\r\n','\n').replace('\r','\n')
  (RUN/'embedded-stderr.log').write_text(text,encoding='utf8')
  result['normal_main_exit_observed']='# G09_OBSERVATION_PROCESS_EXIT code=0' in text
  result['diagnostics']=[dict(r) for r in c.execute('select * from DIAGNOSTIC_EVENT')]
  result['table_counts']={r['name']:c.execute('select count(*) from "'+r['name']+'"').fetchone()[0] for r in schema}
 result['dumps']=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((RUN/'dumps').glob('*.dmp'))]
 # A first-chance dump may describe a handled exception. Never relabel it fatal.
 result['state']='FIRST_CHANCE_DUMP_CAPTURED_NOT_INTERPRETED' if result['dumps'] else 'NO_DUMP_CAPTURED'
 stop_owned_application_on_failure()
 for row in auth['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
 save();print(json.dumps({k:v for k,v in result.items() if k not in ['diagnostics','table_counts','profile_nonzero_retained']},indent=2),flush=True)
except BaseException as error:
 result.update(state='CAPTURE_FAIL',error=repr(error))
 try:stop_owned_application_on_failure()
 except BaseException as cleanup_error:result['target_cleanup_error']=repr(cleanup_error)
 save();raise
