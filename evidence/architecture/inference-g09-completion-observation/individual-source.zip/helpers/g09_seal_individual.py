"""Freeze the one R27 mode-only diagnostic; no native application execution."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,sqlite3,zipfile
ROOT=Path('C:/public/project-hyle/hyle');OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
E=ROOT/'evidence/architecture/inference-g09-completion-observation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (OUT/'run-individual-1').exists() and not (OUT/'individual-authorization.json').exists()
review=ROOT/'.scratch/inference-gaps/g09-handoff-capture-review-27.json'
assert sha(review)=='a2fa73b2bafee014f4ec8a042e518f4a82e43f08b4d308a3939864f85296fe66'
launch_review=ROOT/'.scratch/inference-gaps/g09-individual-launcher-review-27.json'
assert launch_review.is_file()
launcher=ROOT/'.scratch/inference-gaps/g09_capture_individual.py'
old_auth=OUT/'nsys-procdump-authorization.json'
old=json.loads(old_auth.read_text(encoding='utf8'))
files={};old_prose=[]
cards=[ROOT/'docs/implementation/tasks/graph/inference-g09-joint-pipeline.md',ROOT/'docs/implementation/tasks/tooling/inference-g09-native-workload-aa.md']
def add(path,expected=None):
 p=Path(path).resolve();actual=sha(p)
 assert expected is None or expected==actual,(str(p),expected,actual)
 files[str(p)]=dict(path=str(p),bytes=p.stat().st_size,sha256=actual)
for row in old['files']:
 p=Path(row['path'])
 if p not in cards:add(p,row['sha256']);continue
 assert sha(p)!=row['sha256']
 matches=[]
 for name in ['nsys-procdump-source.zip','wer-scope-source.zip']:
  with zipfile.ZipFile(E/name) as z:
   for member in z.namelist():
    if member.endswith(p.name) and hashlib.sha256(z.read(member)).hexdigest()==row['sha256']:matches.append(dict(archive=name,member=member,sha256=row['sha256']))
 assert matches,('Historical frozen card not retained',str(p))
 old_prose.extend(matches);add(p)
fault=OUT/'run-nsys-procdump-1'
annotation=dict(state='TRIAGE_PARAMETERS_NOT_RECOVERABLE',raw_attachment_sha256=sha(fault/'handoff-submit-structure.json'),
 redacted_unknown_fields=['waitSemaphoreCount','pWaitSemaphores','commandBufferCount','pCommandBuffers','pWaitDstStageMask_referent'],
 meaning='0xAAAAAAAA words are triage sanitization, not actual invalid parameters. Preserve original raw view; use R27 disassembly/source only for expected count1/empty PRIMARY/wait1. No ICD-final-structure proof.')
note=OUT/'handoff-triage-interpretation.json';note.write_text(json.dumps(annotation,indent=2)+'\n',encoding='utf8')
decoder_source=OUT/'run-admin-retry-1/trace.sqlite'
with sqlite3.connect(f'file:{decoder_source.as_posix()}?mode=ro',uri=True) as c:
 text='\n'.join(row[1] or '' for row in c.execute('select a.filename,s.value from ANALYSIS_FILE a left join StringIds s on a.contentId=s.id') if Path(row[0]).name.startswith('stderr_')).replace(chr(0),'').replace('\r\n','\n').replace('\r','\n')
 decoder=dict(source=str(decoder_source),source_sha256=sha(decoder_source),before=len(re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M)),
  after=len(re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M)),retire=len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M)),
  blocks=len(re.findall(r'^# G09_OBSERVATION tag=(\S+) count=(\d+) capacity=65536 overflow=0 clock=QPC-ns$',text,re.M)),
  actual_policy=len(re.findall(r'^# G09_OBSERVATION_ACTUAL_POLICY pid=(\d+) mask=0x14 priority=32768 nonce=[0-9a-f]{32}$',text,re.M)),
  normal_main='# G09_OBSERVATION_PROCESS_EXIT code=0' in text)
assert [decoder[k] for k in ['before','after','retire','blocks','actual_policy','normal_main']]==[2,2,4,4,1,False]
decoder['verdict']='PASS_OFFLINE_RECOGNIZES_ORIGINAL_INCOMPLETE_ATTEMPT'
decoder_path=OUT/'individual-decoder-regression.json';decoder_path.write_text(json.dumps(decoder,indent=2)+'\n',encoding='utf8')
add(old_auth)
for p in [review,launch_review,launcher,Path(__file__),note,decoder_path,fault/'submit-transfer-disassembly.txt',fault/'handoff-submit-structure.json',fault/'fault-driver-identity.json',fault/'dbgeng-stack.log',fault/'hyle-stack-map.json']:add(p)
nsys=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64')
for p in [nsys/'ToolsInjection64.dll',nsys/'ToolsInjectionHelper64.dll',Path('C:/Windows/System32/vulkan-1.dll'),Path('C:/Windows/System32/DriverStore/FileRepository/nv_dispi.inf_amd64_da865124972e1f80/nvoglv64.dll')]:add(p)
assert sha(Path('C:/Windows/System32/DriverStore/FileRepository/nv_dispi.inf_amd64_da865124972e1f80/nvoglv64.dll'))=='68b2d0f82e69e6bb7af67ea554c11caba783e2c75f5ab475db108ff55bf1313c'
shutil.copyfile(review,E/'27.json');shutil.copyfile(launch_review,E/'27-launcher.json')
source_rows=[(review,'review/27.json'),(launch_review,'review/27-launcher.json'),(launcher,'helpers/'+launcher.name),(Path(__file__),'helpers/'+Path(__file__).name),
 (note,note.name),(decoder_path,decoder_path.name)]
source_rows += [(p,'callsite/'+p.name) for p in [fault/'submit-transfer-disassembly.txt',fault/'handoff-submit-structure.json']]
source_rows += [(p,'pre-run-cards/'+p.name) for p in cards]
archive=E/'individual-source.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name in source_rows:z.write(p,name)
add(archive);add(E/'27.json');add(E/'27-launcher.json')
auth=dict(schema='hyle.g09.r27-mode-only-capture/v1',created_utc=datetime.now(timezone.utc).isoformat(),
 decision='ALLOW_ONE_MODE_ONLY_NONRANKING_CAPTURE',maximum_math_processes=1,builds=0,source_product_changes=0,
 fixed_run=str(OUT/'run-individual-1'),launcher=str(launcher),launcher_sha256=sha(launcher),review_sha256=sha(review),launcher_review_sha256=sha(launch_review),
 only_collection_delta='batch -> individual; ordinary original direct profile, no debugger',
 scope='Original four shapes/4M F32/2workers/8warmups/12paired/exact1/candidate self-pair/original order/policy; one process then stop.',
 forbidden=['No A/A/P1 qualification or ranking','No product/statistical/provider/driver changes','No further configuration/debugger combination after this one attempt'],
 prior430_live_input_matches=428,retained_historical_card_snapshots=old_prose,files=[files[k] for k in sorted(files)])
target=OUT/'individual-authorization.json';target.write_text(json.dumps(auth,indent=2)+'\n',encoding='utf8');shutil.copyfile(target,E/'individual-authorization.json')
print(json.dumps(dict(state='SEALED_NOT_RUN',files=len(files),authorization_sha256=sha(target),source_archive_sha256=sha(archive)),indent=2))
