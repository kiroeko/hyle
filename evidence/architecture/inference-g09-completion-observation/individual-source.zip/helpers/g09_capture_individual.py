"""R27: one ordinary Nsight capture; only batch -> individual changes."""
from pathlib import Path
import ast,ctypes,hashlib,json,os,re,secrets,sqlite3,subprocess,sys,time
from ctypes import wintypes as W
ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
RUN=OUT/'run-individual-1'
BUILD=Path('C:/h7/g09-completion-observation-25')
NSYS=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
sys.path.insert(0,'C:/h7/g09-p1-peer-9e2/scripts')
from hyle_perf import evaluate_machine_profile,expected_child_policy,get_machine_profile,load_registry,probe_machine
from hyle_perf.runner import _apply_sampling_policy,_child_environment,_creation_flags,_probe_child_policy
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert ctypes.windll.shell32.IsUserAnAdmin() and not RUN.exists()
auth=json.loads((OUT/'individual-authorization.json').read_text(encoding='utf8'))
assert auth['decision']=='ALLOW_ONE_MODE_ONLY_NONRANKING_CAPTURE'
for row in auth['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
host=probe_machine(paths=[('build',BUILD)]);profile=get_machine_profile(load_registry(),'W1-WIN')
gate=evaluate_machine_profile(profile,host,role='engineering',sampling_topology='native-runtime-pair')
assert gate['gate']=='PASS',gate
policy=expected_child_policy(profile,sampling_topology='native-runtime-pair',probe=host)
nonce=secrets.token_hex(16)
env=_child_environment(['HYLE_BENCH_AA_ROUTE','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_APPLE_QOS'],
 {'HYLE_BENCH_AA_ROUTE':'candidate','HYLE_BENCH_RIVAL_FIRST':'0','HYLE_BENCH_PEER_ALLOCATION_FIRST':'0','HYLE_PERF_RUN_NONCE':nonce},profile,policy)
env['DISABLE_VULKAN_OBS_CAPTURE']='1'
assert not any(k.upper() in ['CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH'] for k in env)
RUN.mkdir();started=time.monotonic()
result=dict(state='RUNNING',stages=[],qualification='DIAGNOSTIC_ONLY',valid_formal_ab=0,
 math_application_processes_planned=1,builds=0,source_product_changes=0,nonce=nonce,
 physical_machine=gate['physical_host_identity'],authorization_sha256=sha(OUT/'individual-authorization.json'))
def save():
 result['elapsed_seconds']=time.monotonic()-started
 (RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
# Reuse the reviewed stage runner; the retained-handle cleanup below also covers
# absent embedded stderr. --show-output is not reliable here.
old=(ROOT/'.scratch/inference-gaps/g09_run_completion_observation_admin_retry.py').read_text(encoding='utf8')
for node in ast.parse(old).body:
 if isinstance(node,ast.FunctionDef) and node.name=='run':
  source=ast.get_source_segment(old,node)
  exec(compile(source,'<reviewed-owned-helper>','exec'))
# A retained handle to a path-checked child of our exact collector covers the
# failure before embedded stderr can be extracted. Never select by name alone.
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
class Entry(ctypes.Structure):
 _fields_=[('dwSize',W.DWORD),('cntUsage',W.DWORD),('pid',W.DWORD),('heap',ctypes.c_size_t),
  ('module',W.DWORD),('threads',W.DWORD),('parent',W.DWORD),('priority',W.LONG),('flags',W.DWORD),('exe',W.WCHAR*260)]
kernel.CreateToolhelp32Snapshot.argtypes=[W.DWORD,W.DWORD];kernel.CreateToolhelp32Snapshot.restype=W.HANDLE
kernel.Process32FirstW.argtypes=[W.HANDLE,ctypes.POINTER(Entry)];kernel.Process32NextW.argtypes=kernel.Process32FirstW.argtypes
kernel.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];kernel.OpenProcess.restype=W.HANDLE
kernel.QueryFullProcessImageNameW.argtypes=[W.HANDLE,W.DWORD,W.LPWSTR,ctypes.POINTER(W.DWORD)]
kernel.WaitForSingleObject.argtypes=[W.HANDLE,W.DWORD]
kernel.TerminateProcess.argtypes=[W.HANDLE,W.UINT]
kernel.GetExitCodeProcess.argtypes=[W.HANDLE,ctypes.POINTER(W.DWORD)]
kernel.CloseHandle.argtypes=[W.HANDLE]
kernel.GetProcessTimes.argtypes=[W.HANDLE,ctypes.POINTER(W.FILETIME),ctypes.POINTER(W.FILETIME),ctypes.POINTER(W.FILETIME),ctypes.POINTER(W.FILETIME)]
owned_handles={}
ancestry_handles={}
def lifetime(handle):
 values=[W.FILETIME() for _ in range(4)]
 assert kernel.GetProcessTimes(handle,*[ctypes.byref(x) for x in values])
 return [x.dwLowDateTime+(x.dwHighDateTime<<32) for x in values[:2]]
def process_table():
 snapshot=kernel.CreateToolhelp32Snapshot(2,0)
 assert snapshot not in (None,ctypes.c_void_p(-1).value),ctypes.get_last_error()
 table={};entry=Entry();entry.dwSize=ctypes.sizeof(entry)
 try:
  more=kernel.Process32FirstW(snapshot,ctypes.byref(entry))
  while more:
   table[entry.pid]=(entry.parent,entry.exe)
   more=kernel.Process32NextW(snapshot,ctypes.byref(entry))
 finally:kernel.CloseHandle(snapshot)
 return table
def remember_owned_target(root_pid):
 table=process_table()
 if root_pid not in ancestry_handles:
  handle=kernel.OpenProcess(0x1000|0x100000,False,root_pid)
  if not handle:return
  ancestry_handles[root_pid]=handle
 changed=True
 while changed:
  changed=False
  for pid,(parent,name) in table.items():
   if pid in ancestry_handles or parent not in ancestry_handles:continue
   target=name.lower()=='g09_observed_driver.exe'
   handle=kernel.OpenProcess(0x1000|0x100000|(0x1 if target else 0),False,pid)
   if not handle:continue
   child_start,_=lifetime(handle);parent_start,parent_end=lifetime(ancestry_handles[parent])
   # Retain the actual parent object. A reused numeric parent PID cannot admit
   # a child created after that object's exit or before its creation.
   if child_start<parent_start or (parent_end and child_start>parent_end):
    kernel.CloseHandle(handle);continue
   ancestry_handles[pid]=handle;changed=True
   if not target:continue
   size=W.DWORD(32768);path=ctypes.create_unicode_buffer(size.value)
   assert kernel.QueryFullProcessImageNameW(handle,0,path,ctypes.byref(size))
   assert Path(path.value).resolve()==(BUILD/'bin/g09_observed_driver.exe').resolve()
   owned_handles[pid]=handle
   result.setdefault('owned_target_ancestry',[]).append(dict(pid=pid,parent_pid=parent,collector_pid=root_pid,image=path.value,creation_time=child_start,parent_lifetime=[parent_start,parent_end],handle_retained=True))
def remaining_target_images():
 found=[]
 for pid,(_,name) in process_table().items():
  if name.lower()!='g09_observed_driver.exe':continue
  handle=kernel.OpenProcess(0x1000|0x100000,False,pid)
  if not handle:
   found.append(dict(pid=pid,state='UNKNOWN_UNINSPECTABLE',winerror=ctypes.get_last_error()));continue
  try:
   size=W.DWORD(32768);path=ctypes.create_unicode_buffer(size.value)
   assert kernel.QueryFullProcessImageNameW(handle,0,path,ctypes.byref(size))
   if Path(path.value).resolve()==(BUILD/'bin/g09_observed_driver.exe').resolve() and kernel.WaitForSingleObject(handle,0)==258:found.append(pid)
  finally:kernel.CloseHandle(handle)
 return found
def cleanup_retained_targets():
 for pid,handle in owned_handles.items():
  state=kernel.WaitForSingleObject(handle,0)
  assert state in (0,258),state
  if state==258:
   assert kernel.TerminateProcess(handle,1),ctypes.get_last_error()
   assert kernel.WaitForSingleObject(handle,30000)==0
   result.setdefault('owned_handle_cleanup',[]).append(dict(pid=pid,state='TERMINATED_OWNED_DESCENDANT'))
  else:
   code=W.DWORD();assert kernel.GetExitCodeProcess(handle,ctypes.byref(code))
   result.setdefault('owned_handle_cleanup',[]).append(dict(pid=pid,state='ALREADY_EXITED',exit_code=code.value))
# Keep the reviewed runner, adding only ancestry snapshots during its same-PID
# waits and once after collector exit. It still records one process/stage.
run_node=next(n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name=='run')
run_source=ast.get_source_segment(old,run_node)
run_source=run_source.replace('try:code=child.wait(timeout=1800);break',
 'try:\n                    if stage=="profile":remember_owned_target(child.pid)\n                    code=child.wait(timeout=0.25 if stage=="profile" else 1800)\n                    if stage=="profile":remember_owned_target(child.pid)\n                    break')
run_source=run_source.replace("result.setdefault('extensions',[]).append(dict(stage=stage,pid=child.pid,seconds=1800));save()",
 'if stage!="profile" or time.monotonic()-stamp>=1800*(1+len(result.get("extensions",[]))):\n                        result.setdefault("extensions",[]).append(dict(stage=stage,pid=child.pid,seconds=1800));save()')
exec(compile(run_source,'<reviewed-runner-with-owned-ancestry>','exec'))
assert not remaining_target_images(),'Existing diagnostic process; do not start another'
command=[NSYS,'profile','--trace=vulkan,nvtx','--sample=none','--cpuctxsw=none','--backtrace=none',
 '--vulkan-gpu-workload=individual','--wait=primary','--stop-on-exit=true','--kill=true','--show-output=true',
 '--output',RUN/'trace',BUILD/'bin/g09_observed_driver.exe']
try:
 with _apply_sampling_policy(policy) as applied:
  result['policy']=applied;result['child_canary']=_probe_child_policy(policy,_creation_flags(policy));save()
  try:run('profile',command,_creation_flags(policy),env)
  except RuntimeError as error:result['profile_nonzero_retained']=str(error);save()
 text=''
 # Export and inspect the saved trace even after nonzero profile exit. This is
 # offline processing only, never a second mathematical application process.
 if (RUN/'trace.nsys-rep').is_file():
  run('export',[NSYS,'export','--type=sqlite','--output',RUN/'trace.sqlite',RUN/'trace.nsys-rep'],
      subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS,dict(os.environ))
  with sqlite3.connect(f'file:{(RUN/"trace.sqlite").as_posix()}?mode=ro',uri=True) as c:
   c.row_factory=sqlite3.Row
   schema=[dict(r) for r in c.execute("select name,sql from sqlite_master where type='table' order by name")]
   (RUN/'sqlite-schema.json').write_text(json.dumps(schema,indent=2)+'\n',encoding='utf8')
   names={r['name'] for r in schema}
   if {'ANALYSIS_FILE','StringIds'}<=names:
    stderr=[r['value'] or '' for r in c.execute('select a.filename,s.value from ANALYSIS_FILE a left join StringIds s on a.contentId=s.id') if Path(r['filename']).name.startswith('stderr_')]
    text='\n'.join(stderr).replace(chr(0),'').replace('\r\n','\n').replace('\r','\n')
   result['table_counts']={r['name']:c.execute('select count(*) from "'+r['name']+'"').fetchone()[0] for r in schema}
   result['diagnostics']=[dict(r) for r in c.execute('select * from DIAGNOSTIC_EVENT')] if 'DIAGNOSTIC_EVENT' in names else []
 (RUN/'embedded-stderr.log').write_text(text,encoding='utf8')
 before=re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M)
 after=re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M)
 retired=re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M)
 blocks=re.findall(r'^# G09_OBSERVATION tag=(\S+) count=(\d+) capacity=65536 overflow=0 clock=QPC-ns$',text,re.M)
 actual=re.findall(r'^# G09_OBSERVATION_ACTUAL_POLICY pid=(\d+) mask=0x14 priority=32768 nonce='+nonce+r'$',text,re.M)
 modules=re.findall(r'^# G09_MODULE phase=(\S+) path=(.+)$',text,re.M)
 phases={p for p,_ in modules}
 obs=[p for _,p in modules if 'obs-studio-hook' in p.lower() or 'graphics-hook64.dll' in p.lower()]
 images=re.findall(r'^# G09_IMAGE path=(.+?) tag=(candidate-[12]) ',text,re.M)
 image_ok=len(images)==2 and all(Path(p).resolve()==(BUILD/'bin'/('g09_observed_'+tag[-1]+'.dll')).resolve() for p,tag in images)
 normal='# G09_OBSERVATION_PROCESS_EXIT code=0' in text
 image_ok=image_ok and {tag for _,tag in images}=={'candidate-1','candidate-2'}
 blocks_ok=len(blocks)==8 and all(int(count)>0 for _,count in blocks) and all(sum(tag==expected for tag,_ in blocks)==4 for expected in ['candidate-1','candidate-2'])
 complete=normal and len(before)==len(after)==4 and len(retired)==8 and blocks_ok and len(actual)==1 and len(phases)==4 and not obs and image_ok
 result.update(actual_normal_main_exit=normal,oracles_before=len(before),oracles_after=len(after),retired_states=len(retired),
  recorder_blocks=len(blocks),source_record_count=sum(int(x[1]) for x in blocks),actual_policy_matches=len(actual),
  actual_target_pid=int(actual[0]) if len(actual)==1 else None,module_phases=sorted(phases),obs_modules=obs,actual_facade_paths_match=image_ok)
 cleanup_retained_targets()
 complete=complete and all(row['state']=='ALREADY_EXITED' and row.get('exit_code')==0 for row in result.get('owned_handle_cleanup',[]))
 result['remaining_exact_target_images']=remaining_target_images()
 assert not result['remaining_exact_target_images'],'Unattributed live target: UNKNOWN, never clean by name'
 complete=complete and int(actual[0]) in owned_handles
 for row in auth['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
 result['all_frozen_inputs_match']=True
 profile_ok=next(s for s in result['stages'] if s['stage']=='profile')['exit_code']==0
 result['state']='CAPTURED_NOT_INTERPRETED' if complete and profile_ok else 'MODE_ONLY_CAPTURE_FAIL'
 save();print(json.dumps({k:v for k,v in result.items() if k not in ['diagnostics','table_counts','profile_nonzero_retained']},indent=2),flush=True)
except BaseException as error:
 result.update(state='CAPTURE_FAIL',error=repr(error))
 try:cleanup_retained_targets()
 except BaseException as cleanup_error:result['retained_target_cleanup_error']=repr(cleanup_error)
 try:result['remaining_exact_target_images']=remaining_target_images()
 except BaseException as cleanup_error:result['postfailure_inventory_error']=repr(cleanup_error)
 save();raise
finally:
 for handle in ancestry_handles.values():kernel.CloseHandle(handle)
