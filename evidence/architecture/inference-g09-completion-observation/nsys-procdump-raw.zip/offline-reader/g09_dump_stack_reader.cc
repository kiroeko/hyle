// Disposable offline reader: opens an existing dump; never starts/attaches a target.
#include <windows.h>
#include <initguid.h>
#include <DbgEng.h>
#include <cstdio>

struct DumpOutput final : IDebugOutputCallbacks {
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id, void **out) override {
    if (id == IID_IUnknown || id == IID_IDebugOutputCallbacks) {
      *out = static_cast<IDebugOutputCallbacks *>(this); return S_OK;
    }
    *out = nullptr; return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return 1; }
  ULONG STDMETHODCALLTYPE Release() override { return 1; }
  HRESULT STDMETHODCALLTYPE Output(ULONG, PCSTR text) override {
    std::fputs(text, stdout); return S_OK;
  }
};
int main(int argc, char **argv) {
  if (argc != 4) return 2; // dump, local image path, local symbol path
  IDebugClient *client = nullptr;
  IDebugControl *control = nullptr;
  IDebugSymbols *symbols = nullptr;
  const auto check = [](HRESULT status, const char *phase) {
    if (FAILED(status)) std::fprintf(stderr, "%s failed HRESULT=%08lx\n", phase, status);
    return SUCCEEDED(status);
  };
  if (!check(DebugCreate(IID_IDebugClient, reinterpret_cast<void **>(&client)), "DebugCreate")) return 3;
  DumpOutput output;
  if (!check(client->SetOutputCallbacks(&output), "SetOutputCallbacks") ||
      !check(client->QueryInterface(IID_IDebugControl, reinterpret_cast<void **>(&control)), "control") ||
      !check(client->QueryInterface(IID_IDebugSymbols, reinterpret_cast<void **>(&symbols)), "symbols")) return 4;
  if (!check(symbols->SetImagePath(argv[2]), "image path") ||
      !check(symbols->SetSymbolPath(argv[3]), "local-only symbols") ||
      !check(client->OpenDumpFile(argv[1]), "OpenDumpFile") ||
      !check(control->WaitForEvent(0, 60000), "offline WaitForEvent")) return 5;
  const HRESULT status = control->Execute(DEBUG_OUTCTL_THIS_CLIENT,
      ".ecxr; r; k 30; lm m nvoglv64; lm m ToolsInjection64", DEBUG_EXECUTE_DEFAULT);
  client->EndSession(DEBUG_END_PASSIVE);
  client->SetOutputCallbacks(nullptr);
  symbols->Release(); control->Release(); client->Release();
  return check(status, "offline commands") ? 0 : 6;
}
