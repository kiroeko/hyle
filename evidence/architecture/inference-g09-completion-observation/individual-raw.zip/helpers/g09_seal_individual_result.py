"""Preserve the completed one-shot individual diagnostic and its limitations."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile
ROOT=Path('C:/public/project-hyle/hyle');OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25';RUN=OUT/'run-individual-1'
E=ROOT/'evidence/architecture/inference-g09-completion-observation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf8'))
auth=OUT/'individual-authorization.json';frozen=load(auth);actual=load(RUN/'result.json');source=load(RUN/'source-analysis.json');gpu=load(RUN/'gpu-attribution.json')
assert actual['state']=='CAPTURED_NOT_INTERPRETED' and actual['all_frozen_inputs_match']
assert actual['actual_target_pid']==43320 and actual['owned_handle_cleanup']==[dict(pid=43320,state='ALREADY_EXITED',exit_code=0)]
assert not actual['remaining_exact_target_images']
review=ROOT/'.scratch/inference-gaps/g09-individual-result-review-28.json';assert review.is_file()
for row in frozen['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
original=ROOT/'evidence/architecture/inference-g09-p1-instrument-attempt/receipt.json'
assert sha(original)=='0eaf29dcc6e661c46af7bc7715937c80768c7a144258a667833281f811ae07df'
old_receipts=[E/n for n in ['receipt.json','wer-receipt.json','direct-debug-receipt.json','nsys-procdump-receipt.json']]
shutil.copyfile(review,E/'28.json')
archive=E/'individual-raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(RUN.rglob('*')):
  if p.is_file():z.write(p,'run/'+p.relative_to(RUN).as_posix())
 for name in ['g09_analyze_individual.py','g09_analyze_partial_observation.py','g09_seal_individual_result.py']:
  p=ROOT/'.scratch/inference-gaps'/name;z.write(p,'helpers/'+name)
 z.write(review,'review/28.json')
receipt=dict(schema='hyle.g09.individual-completion-observation-result/v1',created_utc=datetime.now(timezone.utc).isoformat(),
 state='DIAGNOSTIC_APPLICATION_COMPLETE_NATIVE_READINESS_INCONCLUSIVE',source_freeze_commit='895bfa14f',
 product_candidate='3524413272cb52d06af5e64d634edbfef09b9864',product_changes=0,builds=0,math_application_processes=1,
 authorization_sha256=sha(auth),review_sha256=sha(review),launcher_sha256=frozen['launcher_sha256'],
 only_collection_delta='ordinary direct Nsight workload mode batch -> individual; no debugger',
 runtime=dict(actual_target_pid=43320,actual_target_exit_code=0,normal_main_marker=True,oracles_before=4,oracles_after=4,
  retired_states=8,record_blocks=8,records=7730,module_phases=actual['module_phases'],obs_modules=[],frozen_input_count=len(frozen['files']),
  all_frozen_inputs_match_before_result_card_edits=True,no_live_target=True,actual_nonce_policy_images='PASS'),
 cost=dict(elapsed_seconds=actual['elapsed_seconds'],stages=actual['stages'],same_pid_extensions=actual.get('extensions',[]),
  earlier_attempts_unchanged=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for p in old_receipts]),
 capture=dict(table_counts=actual['table_counts'],diagnostics=actual['diagnostics'],complete_gpu_trace='NOT_ESTABLISHED',
  nvtx_clock_markers_matched=source['clock']['matched_markers'],nvtx_clock_markers_unmatched=source['clock']['unmatched_markers'],
  global_constant_qpc_offset=source['clock']['bounded_constant_offset_ns'],global_constant_qpc_offset_verdict=source['clock']['verdict'],
  gpu_workload_rows=gpu['workload_rows'],uniquely_linked_gpu_rows=gpu['uniquely_linked_workload_rows'],unassigned_gpu_rows=gpu['unassigned'],
  measured_submission_coverage=gpu['summary'],native_readiness='UNKNOWN'),
 host_measurement_scope='Exactly12 original measured replays per image/shape; exclude8warmups and before/after oracles. Park intervals are unions and not summed with overlapping caller waits.',
 host_measurement=source['aggregate'],
 conclusions=['This sole individual capture completed allfourshapes with the original mathematical/lifecycle/host identity gates.',
  'Successful individual execution supports one usable diagnostic configuration, not a batch/profiler/driver root-cause certificate.',
  'Measured replay queue-submit APIs are recorded, but no uniquely linked GPU workload rows lie in any of the96 measured replay bookends. Missing rows do not mean zero GPU work.',
  'The collector warns resubmitted command buffers were ignored/shortened. This is not by itself a Vulkan misuse certificate.',
  'All352 clock markers match, but the global constant-offset bounds miss by4ns; retain UNKNOWN without a new tolerance or clock/statistics contract.',
  'Native/public Completion readiness and causes of the original A/A failures remain UNKNOWN. No product FIX or formal qualification recovery is established.',
  'This one candidate is terminal. No further profiler/debugger/driver/provider configuration is authorized by it.'],
 original_formal_receipt_sha256=sha(original),valid_formal_ab=0,formal_status='CUDA original P1 qualified/PASS; Windows Vulkan/Air Apple/Air Vulkan original A/A unqualified, unchanged.',
 artifacts=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in [archive,E/'28.json',E/'individual-source.zip',E/'individual-authorization.json']])
target=E/'individual-receipt.json';assert not target.exists();target.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(state=receipt['state'],receipt_sha256=sha(target),raw_archive_bytes=archive.stat().st_size,raw_archive_sha256=sha(archive)),indent=2))
