"""Offline reuse of the frozen source accounting, now covering all four shapes."""
from pathlib import Path
p=Path('C:/public/project-hyle/hyle/.scratch/inference-gaps/g09_analyze_partial_observation.py')
s=p.read_text(encoding='utf8')
s=s.replace('run-admin-retry-1','run-individual-1')
s=s.replace('OFFLINE_PARTIAL_DIAGNOSTIC_ONLY','OFFLINE_FOUR_SHAPE_DIAGNOSTIC_ONLY')
s=s.replace('UNKNOWN; no GPU workload records and trace incomplete','UNKNOWN; GPU workloads present but incomplete, early range ends and exact native completion not certified')
s=s.replace('Only first two shapes, both completed image lifetimes; later shape crashed.','Allfourshapes and eight completed image lifetimes; no crash in individual mode.')
s=s.replace('partial-source-analysis.json','source-analysis.json')
exec(compile(s,str(p)+'::<four-shape-offline>','exec'))
# Use NVTX bookends within the trace's own clock, without repairing the failed
# all-run constant QPC offset test. Correlation keys assign only recorded rows;
# absence of a GPU row is missing evidence, never zero GPU work.
c.row_factory=sqlite3.Row
nvtx={}
for row in c.execute("select start,uint64Value,coalesce(n.text,s.value) label from NVTX_EVENTS n left join StringIds s on n.textId=s.id where coalesce(n.text,s.value) like '%:clock-align'"):
 key=(row['label'].removesuffix(':clock-align'),row['uint64Value']);assert key not in nvtx;nvtx[key]=row['start']
apis=[dict(row) for row in c.execute("select a.* from VULKAN_API a join StringIds s on a.nameId=s.id where s.value='vkQueueSubmit'")]
workloads=[dict(row) for row in c.execute('select * from VULKAN_WORKLOAD')]
owners={};unassigned=[]
for index,w in enumerate(workloads):
 matches=[a for a in apis if a['contextId']==w['contextId'] and a['correlationId']<=w['correlationId'] and (a['endCorrelationId'] if a['endCorrelationId'] is not None else a['correlationId'])>=w['endCorrelationId']]
 if len(matches)==1:owners[index]=matches[0]['id']
 else:unassigned.append(dict(workload=index,api_ids=[a['id'] for a in matches]))
per_replay=[]
for block_index,block in enumerate(blocks):
 records=sorted(enumerate(block['records']),key=lambda pair:(pair[1]['ns'],pair[0]));records=[r for _,r in records]
 entries=[i for i,r in enumerate(records) if r['kind']==1];exits=[i for i,r in enumerate(records) if r['kind']==3]
 for ordinal,(begin,end) in enumerate(zip(entries,exits)):
  bookends=[]
  for index in [begin,end]:
   mark=next(r for r in records[index+1:] if r['kind']==2 and r['run']==records[index]['run'])
   bookends.append(nvtx[(block['tag'],mark['value'])])
  lo,hi=bookends;assert lo<hi
  calls=[a for a in apis if lo<=a['start'] and a['end']<=hi]
  ids={a['id'] for a in calls}
  gpu=[w for i,w in enumerate(workloads) if owners.get(i) in ids]
  linked_ids={owners[i] for i in owners if owners[i] in ids}
  per_replay.append(dict(block=block_index,tag=block['tag'],ordinal=ordinal,phase='measurement' if 9<=ordinal<=20 else 'excluded-oracle-warmup',
   trace_bookends_ns=bookends,queue_submit_api_count=len(calls),submits_with_recorded_gpu_rows=len(linked_ids),gpu_rows=len(gpu),
   recorded_gpu_span_ns=[min(w['start'] for w in gpu),max(w['end'] for w in gpu)] if gpu else None,
   native_readiness='UNKNOWN: incomplete trace and early execution-range end limitation'))
summary=[]
for index in range(len(blocks)):
 group=[r for r in per_replay if r['block']==index and r['phase']=='measurement']
 summary.append(dict(block=index,tag=blocks[index]['tag'],measurement_replays=len(group),queue_submit_apis=sum(r['queue_submit_api_count'] for r in group),
  submits_with_recorded_gpu_rows=sum(r['submits_with_recorded_gpu_rows'] for r in group),gpu_rows=sum(r['gpu_rows'] for r in group),
  replays_with_any_gpu_rows=sum(r['gpu_rows']>0 for r in group)))
gpu_result=dict(state='OFFLINE_RECORDED_SUBMISSION_ATTRIBUTION_ONLY',workload_rows=len(workloads),uniquely_linked_workload_rows=len(owners),unassigned=unassigned,
 method='Exact contextId plus correlation range of vkQueueSubmit APIs, bracketed by paired source-identified NVTX markers; uses trace clock only, no global QPC repair.',
 summary=summary,replays=per_replay,
 limits=['GPU-row absence is missing evidence, not zero GPU execution.','Collector warned resubmitted command buffers were ignored/shortened; this warning alone does not prove Vulkan misuse.',
 'All352 QPC marker matches exist, but all-run constant-offset interval is empty by4ns. Retain that UNKNOWN; no tolerance/clock contract change.',
 'No GPU-range end certifies independent fence readiness or public Completion; no causal A/A or product MUST conclusion.'])
(R/'gpu-attribution.json').write_text(json.dumps(gpu_result,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(gpu_attribution=summary,linked_rows=len(owners),unassigned=unassigned),indent=2))
