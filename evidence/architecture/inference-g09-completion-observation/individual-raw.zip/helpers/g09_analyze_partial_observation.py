"""Offline source-record accounting for completed lifetimes in failed trace."""
from pathlib import Path
from collections import Counter,defaultdict
import json,re,sqlite3,statistics
R=Path('C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-completion-observation-25/run-admin-retry-1')
text=(R/'embedded-stderr.log').read_text(encoding='utf8')
pattern=re.compile(r'^# G09_RECORD tag=(\S+) ns=(\d+) kind=(\d+) run=(\d+) token=(\d+) value=(\d+) thread=(\d+)$')
blocks=[];current=None
for line in text.splitlines():
 if line.startswith('# G09_OBSERVATION tag='):
  m=re.fullmatch(r'# G09_OBSERVATION tag=(\S+) count=(\d+) capacity=65536 overflow=0 clock=QPC-ns',line)
  assert m
  current=dict(tag=m[1],count=int(m[2]),records=[]);blocks.append(current)
 elif line.startswith('# G09_RECORD '):
  m=pattern.fullmatch(line);assert m and current is not None and m[1]==current['tag']
  current['records'].append(dict(zip(['ns','kind','run','token','value','thread'],map(int,m.groups()[1:]))))

def union(intervals):
 merged=[]
 for a,b in sorted(intervals):
  assert b>=a
  if merged and a<=merged[-1][1]:merged[-1][1]=max(b,merged[-1][1])
  else:merged.append([a,b])
 return sum(b-a for a,b in merged)
def stats(values):
 return dict(count=len(values),minimum=min(values),median=statistics.median(values),maximum=max(values)) if values else dict(count=0)

replays=[];alignment={};block_metadata=[]
for index,block in enumerate(blocks):
 records=block['records'];assert len(records)==block['count']
 records=sorted(enumerate(records),key=lambda x:(x[1]['ns'],x[0]))
 records=[r for _,r in records]
 entries=[r for r in records if r['kind']==1];exits=[r for r in records if r['kind']==3]
 assert len(entries)==len(exits)>0
 block_metadata.append(dict(block=index,tag=block['tag'],records=len(records),replays=len(entries),
     kinds=dict(Counter(r['kind'] for r in records))))
 for r in records:
  if r['kind']==2:
   key=(block['tag'],r['value']);assert key not in alignment;alignment[key]=r
 for ordinal,(start,stop) in enumerate(zip(entries,exits)):
  assert start['run']==stop['run'] and start['thread']==stop['thread'] and start['ns']<stop['ns']
  if ordinal+1<len(entries):assert stop['ns']<entries[ordinal+1]['ns']
  subset=[r for r in records if start['ns']<=r['ns']<=stop['ns']]
  pending={};intervals=defaultdict(list);wait_count=Counter()
  for r in subset:
   if r['kind'] in [20,30,40]:
    key=(r['kind'],r['run']);assert key not in pending
    pending[key]=r
   elif r['kind'] in [21,31,41]:
    key=(r['kind']-1,r['run']);assert key in pending
    begin=pending.pop(key)
    intervals[key[0]].append((begin['ns'],r['ns']));wait_count[key[0]]+=1
  assert not pending
  duration=stop['ns']-start['ns']
  assert len(entries)==22, 'Fixed original before-oracle +8warmups +12measurement +after-oracle'
  phase='oracle' if ordinal in [0,21] else 'warmup' if ordinal<=8 else 'measurement'
  replays.append(dict(block=index,tag=block['tag'],ordinal=ordinal,phase=phase,ns=duration,
    park20_ns=union(intervals[20]),park30_ns=union(intervals[30]),park40_ns=union(intervals[40]),
    native_park_fraction=union(intervals[30])/duration,
    native_park_count=wait_count[30],progress_park_count=wait_count[20],
    polls_pending=sum(r['kind']==12 and r['value']==0 for r in subset),
    polls_complete=sum(r['kind']==12 and r['value']==1 for r in subset)))

c=sqlite3.connect(f'file:{(R/"trace.sqlite").as_posix()}?mode=ro',uri=True)
matches=[];unmatched=[]
for start,label,payload in c.execute("select n.start,coalesce(n.text,s.value),n.uint64Value from NVTX_EVENTS n left join StringIds s on n.textId=s.id where coalesce(n.text,s.value) like '%:clock-align' order by n.start"):
 tag=label.removesuffix(':clock-align');record=alignment.get((tag,payload))
 if record is None:unmatched.append(dict(start=start,tag=tag,payload=payload));continue
 matches.append(dict(tag=tag,before_qpc_ns=payload,after_qpc_ns=record['ns'],trace_ns=start,
   offset_lower_ns=start-record['ns'],offset_upper_ns=start-payload))
lower=max(r['offset_lower_ns'] for r in matches);upper=min(r['offset_upper_ns'] for r in matches)
aggregate={}
for b in block_metadata:
 group=[r for r in replays if r['block']==b['block']]
 group=[r for r in group if r['phase']=='measurement']
 assert len(group)==12
 aggregate[str(b['block'])]=dict(**{k:b[k] for k in ['tag','replays','records']},
   scope='Only original12 measurement replays; before/after full oracles and8warmups excluded',
   replay_ms=stats([r['ns']/1e6 for r in group]),
   native_frontier_park_union_ms=stats([r['park30_ns']/1e6 for r in group]),
   native_frontier_park_fraction=stats([r['native_park_fraction'] for r in group]),
   native_frontier_park_count=stats([r['native_park_count'] for r in group]),
   unsignaled_progress_park_count=sum(r['progress_park_count'] for r in group),
   finished_wait_union_ms=stats([r['park40_ns']/1e6 for r in group]))
result=dict(state='OFFLINE_PARTIAL_DIAGNOSTIC_ONLY',blocks=block_metadata,aggregate=aggregate,
 replays=replays,
 clock=dict(matched_markers=len(matches),unmatched_markers=unmatched,
   bounded_constant_offset_ns=[lower,upper],consistent=lower<=upper,
   verdict='BOUNDED_MATCH_FOR_RETAINED_MARKERS_ONLY' if lower<=upper else 'UNKNOWN_NO_COMMON_OFFSET',matches=matches),
 valid_formal_ab=0,native_submission_readiness='UNKNOWN; no GPU workload records and trace incomplete',
 limits=['Only first two shapes, both completed image lifetimes; later shape crashed.',
 'Native park includes useful GPU work, host/provider tails, timer and scheduling; it is not proved avoidable cost.',
 'Caller finished waits overlap native/CPU execution and must not be added as independent overhead.',
 'These instrumented times are not original performance measurements or A/A qualification.',
 'Poll-complete time/GPU API return is not independent native readiness; no completion-notice gap conclusion.'])
(R/'partial-source-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(state=result['state'],aggregate=aggregate,
 clock={k:v for k,v in result['clock'].items() if k!='matches'}),indent=2))
