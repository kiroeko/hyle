"""Prepare the one reviewed WinVk host condition; never execute a workload."""
from pathlib import Path
import hashlib
import json

ROOT = Path('C:/public/project-hyle/hyle')
SOURCE = ROOT / '.scratch/inference-gaps/g09-p1-instrument-adapter'
original = (SOURCE / 'validate_aa.py').read_text(encoding='utf8')
assert hashlib.sha256((SOURCE / 'validate_aa.py').read_bytes()).hexdigest() == '1b72362ddf5189a5fc5df7eaa8034b8ae57df0ba0dfe1437867e380757e28ecf'

helpers = '''
def check_obs_absent(log):
    text = log.read_text(encoding='utf8', errors='replace')
    snapshots = {}
    for phase, path in re.findall(r'^# G09_MODULE phase=(\\S+) path=(.+)$', text, re.M):
        snapshots.setdefault(phase, set()).add(path.strip())
    assert set(snapshots) == set(SHAPES), ('Missing/unexpected phase module snapshots', str(log))
    for phase, paths in snapshots.items():
        lowered = [x.replace('\\\\', '/').lower() for x in paths]
        assert any(x.endswith('/vulkan-1.dll') for x in lowered), ('Missing Vulkan loader', phase)
        assert not any('obs-studio-hook' in x or x.rsplit('/', 1)[-1] in
            {'graphics-hook64.dll', 'graphics-hook32.dll'} for x in lowered), ('OBS still loaded', str(log), phase)
    assert len(re.findall(r'^# G09_ORACLE .* before=PASS ', text, re.M)) == 4
    assert len(re.findall(r'^# G09_ORACLE .* after=PASS ', text, re.M)) == 4
    assert len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$', text, re.M)) == 8
    return dict(log=str(log.resolve()), sha256=sha(log),
        phases={k: sorted(v) for k, v in snapshots.items()},
        residual_nvspcap=any('nvspcap64.dll' in x.lower() for v in snapshots.values() for x in v),
        scope='Four existing pre-timing snapshots; not continuous module tracing or proof of causation')

def check_host_record(output, aa):
    rows = [check_obs_absent(Path(x['log'])) for x in [aa['verify']] + aa['runs']]
    product = [check_obs_absent(p) for p in sorted((output/'raw').glob('n-*/product-*.log'))]
    save(output/'pipeline-obs-host.json', dict(gate='PASS', environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},
        qualification_snapshots=rows, product_snapshots=product,
        product_count=len(product), causal_claim='NONE', other_capture_layers_disabled=False))

def bind_host_authorization(build, output):
    assert not AIR and os.environ.get('DISABLE_VULKAN_OBS_CAPTURE') == '1'
    authorization = load(SOURCE/'obs-host-authorization.json')
    assert authorization['decision'] == 'ALLOW_ONE_FROZEN_OBS_FREE_WINDOWS_VULKAN_ATTEMPT'
    assert Path(authorization['build']).resolve() == build.resolve()
    assert Path(authorization['output']).resolve() == output.resolve()
    for row in authorization['files']:
        path = Path(row['path'])
        if not path.is_absolute():
            path = SOURCE/path
        assert sha(path) == row['sha256'], ('Frozen host entry/manifest/review changed', str(path))
    manifest = load(Path(authorization['manifest']))
    assert manifest['layer']['disable_environment'] == {'DISABLE_VULKAN_OBS_CAPTURE':'1'}
    assert manifest['layer']['name'] == 'VK_LAYER_OBS_HOOK'
    return dict(authorization_sha256=sha(SOURCE/'obs-host-authorization.json'),
        validator_sha256=sha(Path(__file__)), environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},
        manifest_sha256=sha(Path(authorization['manifest'])))

'''

def replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

new = replace(original, 'def main():\n', helpers + '\ndef main():\n')
new = replace(new, '    route = a.profile.split(\'-\')[1]\n',
    "    assert a.profile == 'windows-vulkan', 'This host exclusion is Windows Vulkan only'\n"
    "    route = a.profile.split('-')[1]\n")
new = replace(new, "    ready.write_text('FAIL\\n',encoding='ascii')\n",
    "    ready.write_text('FAIL\\n',encoding='ascii')\n    host_condition = bind_host_authorization(a.build, a.output)\n")
new = replace(new, "    identity = {'executable_sha256':sha(executable),'control_sha256':sha(control),",
    "    identity = {'host_condition':host_condition,'executable_sha256':sha(executable),'control_sha256':sha(control),")
new = replace(new, "        ready.write_text('PASS\\n',encoding='ascii')\n        print('Retained matching workload-A/A PASS revalidated; no new samples',flush=True)",
    "        try:\n            check_host_record(a.output, old)\n        except BaseException as error:\n"
    "            save(a.output/'pipeline-obs-host.json',dict(gate='FAIL',error=repr(error)))\n            raise\n"
    "        ready.write_text('PASS\\n',encoding='ascii')\n        print('Retained matching workload-A/A PASS and no-OBS snapshots revalidated; no new samples',flush=True)")
new = replace(new, "        env = _child_environment(CONTROLLED,additions,profile,policy)\n",
    "        env = _child_environment(CONTROLLED,additions,profile,policy)\n        env['DISABLE_VULKAN_OBS_CAPTURE'] = '1'\n")
new = replace(new, "        assert code == 0, text[-5000:]\n",
    "        assert code == 0, text[-5000:]\n        host_snapshot = check_obs_absent(log)\n")
new = replace(new, "return text,dict(log=str(log.resolve()),sha256=sha(log),exit_code=code,elapsed_seconds=time.monotonic()-stamp)",
    "return text,dict(log=str(log.resolve()),sha256=sha(log),exit_code=code,elapsed_seconds=time.monotonic()-stamp,host_snapshot=host_snapshot)")
new = replace(new, "        if not errors:\n            ready.write_text('PASS\\n',encoding='ascii')",
    "        if not errors:\n            check_host_record(a.output, result)\n            ready.write_text('PASS\\n',encoding='ascii')")
compile(new, 'validate_obs_host.py', 'exec')
(SOURCE / 'validate_obs_host.py').write_bytes(new.encode('utf8'))

contract = json.loads((SOURCE/'contract-windows-vulkan.json').read_text(encoding='utf8'))
contract['id'] = 'inference-g09-windows-vulkan-obs-free-pipeline-p1-v1'
contract['claim'] += ' One separately frozen host condition: DISABLE_VULKAN_OBS_CAPTURE=1 before fresh child startup; actual four-phase no-OBS snapshots required. No historical causal or all-capture-free claim.'
validators = contract['extensions']['runner']['validators']
for row in validators:
    if row['kind'] == 'command':
        row['command'][2] = 'validate_obs_host.py'
(SOURCE/'contract-windows-vulkan-obs-free.json').write_bytes((json.dumps(contract, indent=2)+'\n').encode('utf8'))
print('Prepared dedicated validator and host-only contract; no workload executed')
