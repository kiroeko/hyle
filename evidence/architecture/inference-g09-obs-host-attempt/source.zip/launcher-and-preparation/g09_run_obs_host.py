"""Exactly one fresh original WinVk qualification with the OBS host control."""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('C:/public/project-hyle/hyle')
SOURCE = ROOT/'.scratch/inference-gaps/g09-p1-instrument-adapter'
TOOL = Path('C:/h7/g09-p1-peer-9e2/scripts/hyle-perf.py')
PEER = TOOL.parent.parent
BUILD = Path('C:/h7/g09-p1-instrument/vulkan/qualified-build-obs-free-1')
FOLDER = ROOT/'.scratch/inference-gaps/g09-p1-obs-free-1'
OUTPUT = FOLDER/'evidence'
CONTRACT = SOURCE/'contract-windows-vulkan-obs-free.json'

sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert os.name == 'nt'
assert not BUILD.exists() and not FOLDER.exists(), 'Preserve attempts; no repeat/restart'
assert subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip() == ''
assert subprocess.check_output(['git','-C',str(PEER),'status','--porcelain'],text=True).strip() == ''
assert subprocess.check_output(['git','-C',str(PEER),'rev-parse','HEAD'],text=True).strip() == '9e2f25c469634a6f723e76eaf1aa2db5973bca9a'
authorization = json.loads((SOURCE/'obs-host-authorization.json').read_text(encoding='utf8'))
assert authorization['decision'] == 'ALLOW_ONE_FROZEN_OBS_FREE_WINDOWS_VULKAN_ATTEMPT'
assert Path(authorization['build']).resolve() == BUILD.resolve()
assert Path(authorization['output']).resolve() == OUTPUT.resolve()
for row in authorization['files']:
    path = Path(row['path'])
    if not path.is_absolute():
        path = SOURCE/path
    assert sha(path) == row['sha256'], ('Frozen file changed', str(path))

env = {k.upper():v for k,v in os.environ.items()}
setup = subprocess.check_output(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace')
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
env.update(VSLANG='1033',PYTHONDONTWRITEBYTECODE='1',DISABLE_VULKAN_OBS_CAPTURE='1')
assert not any(k in ['CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH'] for k in env)
FOLDER.mkdir(parents=True, exist_ok=False)
command = [sys.executable,'-B',str(TOOL),'qualify-platform','--source',str(SOURCE),'--contract',str(CONTRACT),
    '--machine','W1-WIN','--peer','baseline9e2='+str(PEER),'--build',str(BUILD),'--output',str(OUTPUT)]
started = time.monotonic()
result = dict(state='RUNNING',profile='windows-vulkan',command=command,
    source_revision=subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),
    contract_sha256=sha(CONTRACT),host_authorization_sha256=sha(SOURCE/'obs-host-authorization.json'),
    host_environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},product_rebuilds=0,facade_rebuilds=0,
    stages='Original three-TU entry build; exact R18 text/artifacts; one verify with no OBS; original8AA then only if PASS original n15->31/P1. No other switch/retry.')

def save():
    result['elapsed_seconds'] = time.monotonic()-started
    (FOLDER/'run-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')

child = None
try:
    with (FOLDER/'instrument.log').open('wb') as log:
        child = subprocess.Popen(command,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        get = ctypes.windll.kernel32.GetProcessAffinityMask
        get.argtypes = [ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        pin = ctypes.windll.kernel32.SetProcessAffinityMask
        pin.argtypes = [ctypes.c_void_p,ctypes.c_size_t]
        available, system = ctypes.c_size_t(), ctypes.c_size_t()
        handle = ctypes.c_void_p(int(child._handle))
        assert get(handle,ctypes.byref(available),ctypes.byref(system))
        assert pin(handle,sum([1<<i for i in range(64) if available.value&(1<<i)][:4]))
        result['child_pid'] = child.pid
        save()
        print('Windows Vulkan OBS-free RUNNING',child.pid,flush=True)
        while True:
            try:
                code = child.wait(timeout=1800)
                break
            except subprocess.TimeoutExpired:
                result.setdefault('extensions',[]).append(dict(pid=child.pid,seconds=1800))
                save()
    result.pop('child_pid',None)
    result.update(state='TERMINAL',exit_code=code)
    save()
    print('Windows Vulkan OBS-free TERMINAL',code,result['elapsed_seconds'],flush=True)
    if code:
        print((FOLDER/'instrument.log').read_text(encoding='utf8',errors='replace')[-8000:],flush=True)
    raise SystemExit(code)
except Exception as error:
    result.update(state='LAUNCH_FAIL',error=repr(error))
    if child is not None:
        result['owned_child_pid'] = child.pid
        if child.poll() is None:
            cleanup = subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],
                capture_output=True,text=True,encoding='utf8',errors='replace',
                creationflags=subprocess.CREATE_NO_WINDOW)
            result['owned_tree_cleanup'] = dict(exit_code=cleanup.returncode,
                stdout=cleanup.stdout,stderr=cleanup.stderr)
            if child.poll() is None:
                child.kill()
            result['owned_child_exit_code'] = child.wait()
    save()
    raise
