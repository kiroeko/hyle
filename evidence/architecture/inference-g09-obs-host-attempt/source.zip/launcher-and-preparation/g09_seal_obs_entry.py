"""Freeze reviewed files into the single private host authorization; no runs."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path('C:/public/project-hyle/hyle')
SOURCE = ROOT/'.scratch/inference-gaps/g09-p1-instrument-adapter'
EV = ROOT/'evidence/architecture/inference-g09-obs-host-attempt'
review = ROOT/'.scratch/inference-gaps/g09-obs-entry-review-22.json'
assert review.is_file(), 'Independent actual source review is required'
reviewed = json.loads(review.read_text(encoding='utf8'))
assert reviewed['decision'] == 'SUPPORT_ONE_FIXED_OBS_FREE_WINDOWS_VULKAN_ATTEMPT_AFTER_AUTHORIZATION_SEAL_AND_CLEAN_COMMIT'
assert all(x['state'] == 'RESOLVED_IN_READ_SNAPSHOT' for x in reviewed['finding_history'])
for row in reviewed['inputs']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'], ('Reviewed input changed',row['path'])
assert not (SOURCE/'obs-host-authorization.json').exists(), 'Do not silently replace an authorization'
shutil.copy2(review, EV/'22.json')
shutil.copy2(ROOT/'.scratch/inference-gaps/g09-obs-entry-checks-22/checks.json',EV/'static-entry-checks.json')
files = [SOURCE/'validate_obs_host.py',SOURCE/'contract-windows-vulkan-obs-free.json',
    SOURCE/'validate_aa.py',SOURCE/'contract-windows-vulkan.json',SOURCE/'review-authorization.json',
    SOURCE/'artifacts-windows-vulkan.json',ROOT/'.scratch/inference-gaps/g09_run_obs_host.py',
    Path('C:/ProgramData/obs-studio-hook/obs-vulkan64.json'),Path('C:/ProgramData/obs-studio-hook/graphics-hook64.dll'),
    Path('C:/Program Files/obs-studio/bin/64bit/obs64.exe'),EV/'21.json',EV/'22.json',EV/'host-facts.json',EV/'static-entry-checks.json']
rows = []
for path in files:
    rows.append(dict(path=path.name if path.parent == SOURCE else str(path),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size))
authorization = dict(schema='hyle.g09.obs-host-authorization.v1',decision='ALLOW_ONE_FROZEN_OBS_FREE_WINDOWS_VULKAN_ATTEMPT',
    source_base='35ec95dbfb7012c746c4a4114c5b3bcffaf3d12e',
    build='C:/h7/g09-p1-instrument/vulkan/qualified-build-obs-free-1',
    output=str(ROOT/'.scratch/inference-gaps/g09-p1-obs-free-1/evidence'),
    manifest='C:/ProgramData/obs-studio-hook/obs-vulkan64.json',environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},
    files=rows,attempts=1,scope='Windows Vulkan only; no product/core/Cpp/math change; exact original R18 text and SDKs; unchanged AA/P1.',
    stops='One fresh complete verify no OBS, then8AA original5% factor/10% gross; any failure stops. P1 only after PASS; post-check every product log. No other capture knob/retry.',
    causal_claim='NONE',residual_capture_modules='nvspcap recorded only; not disabled or judged causal',
    historical_facts_count_note='Original R21 facts scope32 is a metadata typo: actual4profiles x9logs=36; original bytes/hash and failures preserved.')
(SOURCE/'obs-host-authorization.json').write_bytes((json.dumps(authorization,indent=2)+'\n').encode('utf8'))
print('Frozen host authorization; no workload executed')
