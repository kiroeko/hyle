"""Static parser/contract checks only: no probe/build/benchmark/native child."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

ROOT = Path('C:/public/project-hyle/hyle')
SOURCE = ROOT/'.scratch/inference-gaps/g09-p1-instrument-adapter'
OUT = ROOT/'.scratch/inference-gaps/g09-obs-entry-checks-22'
OUT.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
newpath = SOURCE/'validate_obs_host.py'
spec = importlib.util.spec_from_file_location('g09_obs_check',newpath)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
old = json.loads((SOURCE/'contract-windows-vulkan.json').read_text(encoding='utf8'))
new = json.loads((SOURCE/'contract-windows-vulkan-obs-free.json').read_text(encoding='utf8'))
assert new.pop('id') == 'inference-g09-windows-vulkan-obs-free-pipeline-p1-v1'
assert new.pop('claim').startswith(old['claim'])
old.pop('id'); old.pop('claim')
new['extensions']['runner']['validators'][2]['command'][2] = 'validate_aa.py'
assert old == new, 'Contract delta exceeds id/claim/dedicated validator'
original = ROOT/'.scratch/inference-gaps/g09-p1-formal/windows-vulkan/evidence/pipeline-aa-raw/verify.log'
try:
    module.check_obs_absent(original)
except AssertionError as error:
    assert 'OBS still loaded' in str(error), error
else:
    raise AssertionError('Historical OBS log falsely accepted')
clean = OUT/'synthetic-no-obs.log'
text = original.read_text(encoding='utf8')
clean.write_text(''.join(x for x in text.splitlines(keepends=True) if 'obs-studio-hook' not in x.lower()), encoding='utf8')
accepted = module.check_obs_absent(clean)
missing = OUT/'synthetic-missing-phase.log'
missing.write_text(re.sub(r'^# G09_MODULE phase=serial-holdout .*\n','',clean.read_text(encoding='utf8'),flags=re.M), encoding='utf8')
try:
    module.check_obs_absent(missing)
except AssertionError as error:
    assert 'Missing/unexpected phase' in str(error), error
else:
    raise AssertionError('Missing phase falsely accepted')
for path in [newpath,ROOT/'.scratch/inference-gaps/g09_run_obs_host.py']:
    compile(path.read_text(encoding='utf8'),str(path),'exec')
result = dict(gate='PASS',scope='Static parser synthetic fixtures and exact contract delta only; no native verify/AA/P1 qualification',
    checks=['Actual historical OBS log rejected','Synthetic removed-OBS parser fixture accepted','Missing phase rejected','Only id/claim/validator contract delta','Python syntax valid'],
    files=[dict(path=str(p),sha256=sha(p)) for p in [newpath,SOURCE/'contract-windows-vulkan-obs-free.json',ROOT/'.scratch/inference-gaps/g09_run_obs_host.py']],
    source_fact_count_note='R21 host-facts.json scope says32; actual4profiles x9logs=36. Original bytes/hash preserved.')
(OUT/'checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
