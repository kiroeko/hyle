// Only argv setup for the unchanged opaque-C-table consumer.
#define main g09_fixed_driver_main
#include "driver.cc"
#undef main
int main(int argc, char **argv) {
  const auto qos = hyle::bench::perf::configure_thread_qos();
  const auto affinity = hyle::bench::perf::configure_thread_affinity("HYLE_PERF_CALLER_CPU");
  std::fprintf(stderr,
      "# HYLE_G09_INSTRUMENT_RUN run_nonce=%s apple_qos=%s qos_ok=%s "
      "execution_order=%s allocation_order=%s affinity_topology=%s "
      "caller_cpu=%s parent_mask=%s priority=%s affinity_ok=%s\n",
      hyle::bench::perf::run_nonce(), qos.name, qos.ok,
      enabled("HYLE_BENCH_RIVAL_FIRST") ? "peer-first" : "candidate-first",
      enabled("HYLE_BENCH_PEER_ALLOCATION_FIRST") ? "peer-first" : "candidate-first",
      affinity.topology, affinity.cpu, environment("HYLE_PERF_PARENT_MASK").c_str(),
      environment("HYLE_PERF_PRIORITY").c_str(), affinity.ok);
  if (argc != 1) return g09_fixed_driver_main(argc, argv);
  char *arguments[]{argv[0], const_cast<char *>(G09_CANDIDATE_1),
      const_cast<char *>(G09_BASELINE_1), const_cast<char *>(G09_CANDIDATE_2),
      const_cast<char *>(G09_BASELINE_2)};
  return g09_fixed_driver_main(5, arguments);
}
