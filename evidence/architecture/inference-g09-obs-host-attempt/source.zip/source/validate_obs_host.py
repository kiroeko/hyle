"""Finite G09 artifact binding and existing workload-A/A policy; no perf core."""
import argparse
import hashlib
import json
import os
import platform
import re
import secrets
import statistics
import struct
import subprocess
import sys
import time
from pathlib import Path

SOURCE = Path(__file__).resolve().parent
AIR = platform.system() == 'Darwin'
BASE = Path('/Users/kiro/hyle-scratch/compute-unified' if AIR else 'C:/h7')
TOOLS = BASE / 'g09-p1-peer-9e2/scripts'
sys.path.insert(0, str(TOOLS))
from hyle_perf import evaluate_machine_profile, expected_child_policy, get_machine_profile, load_registry, probe_machine
from hyle_perf.controls import AA_MAXIMUM_BIAS_PERCENT
from hyle_perf.machine import applied_macos_qos
from hyle_perf.nanobench import parse_nanobench, select_pair
from hyle_perf.runner import (_apply_sampling_policy, _child_environment, _creation_flags,
    _probe_child_policy, _product_telemetry_expectations, _required_telemetry)
from hyle_perf.stats import equivalence_band

SHAPES = ['independent-cpu-first', 'independent-gpu-first', 'two-microbatches', 'serial-holdout']
CONTROLLED = ['HYLE_BENCH_AA_ROUTE', 'HYLE_BENCH_VERIFY_ONLY', 'HYLE_BENCH_RIVAL_FIRST', 'HYLE_BENCH_PEER_ALLOCATION_FIRST', 'HYLE_PERF_APPLE_QOS']

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    return json.loads(path.read_text(encoding='utf8'))

def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf8')

def text_section(path):
    """Actual executable code bytes only; independent review fixes each profile."""
    b = path.read_bytes()
    if b[:2] == b'MZ':
        pe = struct.unpack_from('<I', b, 0x3c)[0]
        assert b[pe:pe+4] == b'PE\0\0'
        count = struct.unpack_from('<H',b,pe+6)[0]
        optional = struct.unpack_from('<H',b,pe+20)[0]
        for i in range(count):
            row = pe+24+optional+i*40
            if b[row:row+8].rstrip(b'\0') == b'.text':
                size = struct.unpack_from('<I',b,row+8)[0]
                raw = struct.unpack_from('<I',b,row+20)[0]
                return hashlib.sha256(b[raw:raw+size]).hexdigest()
    else:
        assert b[:4] == b'\xcf\xfa\xed\xfe', 'Expected original native thin arm64 Mach-O'
        count = struct.unpack_from('<I',b,16)[0]
        cursor = 32
        for _ in range(count):
            cmd, size = struct.unpack_from('<II',b,cursor)
            if cmd == 0x19:
                sections = struct.unpack_from('<I',b,cursor+64)[0]
                for i in range(sections):
                    row = cursor+72+i*80
                    if b[row:row+16].rstrip(b'\0') == b'__text':
                        length = struct.unpack_from('<Q',b,row+40)[0]
                        offset = struct.unpack_from('<I',b,row+48)[0]
                        return hashlib.sha256(b[offset:offset+length]).hexdigest()
            cursor += size
    raise RuntimeError('Missing executable text section')


def check_obs_absent(log):
    text = log.read_text(encoding='utf8', errors='replace')
    snapshots = {}
    for phase, path in re.findall(r'^# G09_MODULE phase=(\S+) path=(.+)$', text, re.M):
        snapshots.setdefault(phase, set()).add(path.strip())
    assert set(snapshots) == set(SHAPES), ('Missing/unexpected phase module snapshots', str(log))
    for phase, paths in snapshots.items():
        lowered = [x.replace('\\', '/').lower() for x in paths]
        assert any(x.endswith('/vulkan-1.dll') for x in lowered), ('Missing Vulkan loader', phase)
        assert not any('obs-studio-hook' in x or x.rsplit('/', 1)[-1] in
            {'graphics-hook64.dll', 'graphics-hook32.dll'} for x in lowered), ('OBS still loaded', str(log), phase)
    assert len(re.findall(r'^# G09_ORACLE .* before=PASS ', text, re.M)) == 4
    assert len(re.findall(r'^# G09_ORACLE .* after=PASS ', text, re.M)) == 4
    assert len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$', text, re.M)) == 8
    return dict(log=str(log.resolve()), sha256=sha(log),
        phases={k: sorted(v) for k, v in snapshots.items()},
        residual_nvspcap=any('nvspcap64.dll' in x.lower() for v in snapshots.values() for x in v),
        scope='Four existing pre-timing snapshots; not continuous module tracing or proof of causation')

def check_host_record(output, aa):
    rows = [check_obs_absent(Path(x['log'])) for x in [aa['verify']] + aa['runs']]
    product = [check_obs_absent(p) for p in sorted((output/'raw').glob('n-*/product-*.log'))]
    save(output/'pipeline-obs-host.json', dict(gate='PASS', environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},
        qualification_snapshots=rows, product_snapshots=product,
        product_count=len(product), causal_claim='NONE', other_capture_layers_disabled=False))

def bind_host_authorization(build, output):
    assert not AIR and os.environ.get('DISABLE_VULKAN_OBS_CAPTURE') == '1'
    authorization = load(SOURCE/'obs-host-authorization.json')
    assert authorization['decision'] == 'ALLOW_ONE_FROZEN_OBS_FREE_WINDOWS_VULKAN_ATTEMPT'
    assert Path(authorization['build']).resolve() == build.resolve()
    assert Path(authorization['output']).resolve() == output.resolve()
    for row in authorization['files']:
        path = Path(row['path'])
        if not path.is_absolute():
            path = SOURCE/path
        assert sha(path) == row['sha256'], ('Frozen host entry/manifest/review changed', str(path))
    manifest = load(Path(authorization['manifest']))
    assert manifest['layer']['disable_environment'] == {'DISABLE_VULKAN_OBS_CAPTURE':'1'}
    assert manifest['layer']['name'] == 'VK_LAYER_OBS_HOOK'
    return dict(authorization_sha256=sha(SOURCE/'obs-host-authorization.json'),
        validator_sha256=sha(Path(__file__)), environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},
        manifest_sha256=sha(Path(authorization['manifest'])))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--profile',required=True,choices=['windows-cuda','windows-vulkan','air-apple','air-vulkan'])
    a = parser.parse_args()
    assert a.profile == 'windows-vulkan', 'This host exclusion is Windows Vulkan only'
    route = a.profile.split('-')[1]
    assert AIR == a.profile.startswith('air-')
    if AIR:
        assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip() == 'Mac16,12'
    machine = 'M1-MAC' if AIR else 'W1-WIN'
    topology = 'single-logical-cpu' if AIR else 'native-runtime-pair'
    executable = a.build/'bin'/('g09_pipeline_primary'+('' if AIR else '.exe'))
    ready = executable.parent/'g09_pipeline_aa.ready'
    ready.write_text('FAIL\n',encoding='ascii')
    host_condition = bind_host_authorization(a.build, a.output)
    a.output.mkdir(parents=True,exist_ok=True)
    result_path = a.output/'pipeline-aa.json'
    started = time.monotonic()
    specification = load(SOURCE/('artifacts-'+a.profile+'.json'))
    authorization = load(SOURCE/'review-authorization.json')
    assert authorization['decision'] == 'ALLOW_FIXED_CONTRACTS_AND_REVIEWED_EQUIVALENT_CONSUMER_TEXT_ONLY'
    for row in authorization['source_files']:
        assert sha(SOURCE/row['path']) == row['sha256'], ('Source differs from independent review',row['path'])
    reviewed = authorization['profiles'][a.profile]
    assert text_section(executable) == reviewed['primary_text_sha256'], 'Actual primary text differs from independently reviewed artifact'
    control = executable.with_name('g09_pipeline_control'+('' if AIR else '.exe'))
    assert text_section(control) == reviewed['control_text_sha256'], 'Actual control text differs from review'
    for row in specification['original_instrument_files']:
        assert sha(TOOLS/row['path']) == row['sha256'], ('Original instrument changed',row['path'])
    def bind_artifacts():
        rows = []
        for row in specification['artifacts']:
            path = Path(row['path'])
            assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], ('Private SDK image/runtime changed',str(path))
            rows.append({'path':str(path),'sha256':row['sha256'],'bytes':row['bytes']})
        resource = specification['copied_executable_resource']
        if resource:
            expected = [x for x in specification['artifacts'] if Path(x['path']).name == resource]
            assert expected and len({x['sha256'] for x in expected}) == 1
            assert sha(executable.parent/resource) == expected[0]['sha256'], 'Executable-side original native resource differs'
        return rows
    artifacts = bind_artifacts()
    cache = dict(x.split('=',1) for x in (a.build/'CMakeCache.txt').read_text().splitlines() if '=' in x and not x.startswith(('#','//')))
    assert cache['G09_ROUTE:STRING'] == route
    assert Path(cache['G09_BASE:PATH']).resolve() == BASE.resolve(), 'Actual facade path root differs from frozen artifacts'
    assert Path(cache['G09_PEER_SOURCE:PATH']).resolve() == TOOLS.parent.resolve()
    commands = load(a.build/'compile_commands.json')
    assert len(commands) == 3 and {Path(x['file']).name for x in commands} == {'wrapper.cc','nanobench_impl.cc','perf_control_bench.cc'}
    assert all(Path(x['file']).resolve().is_relative_to(SOURCE) for x in commands), 'Product or other source compilation is forbidden'
    profile = get_machine_profile(load_registry(),machine)
    host = probe_machine(paths=[('build',a.build)],expected_qos='interactive' if AIR else None)
    gate = evaluate_machine_profile(profile,host,role='engineering',sampling_topology=topology)
    assert gate['gate'] == 'PASS', gate
    policy = expected_child_policy(profile,sampling_topology=topology,probe=host)
    identity = {'host_condition':host_condition,'executable_sha256':sha(executable),'control_sha256':sha(control),
        'artifact_specification_sha256':sha(SOURCE/('artifacts-'+a.profile+'.json')),
        'authorization_sha256':sha(SOURCE/'review-authorization.json'),
        'reviewed_sources':authorization['source_files'],'actual_frozen_artifacts':artifacts,
        'physical_machine':gate['physical_host_identity'],'sampling_policy':policy}
    if result_path.exists():
        old = load(result_path)
        assert old['gate'] == 'PASS' and old['identity'] == identity, 'A/A failed or identity changed: preserve failure; no blind repeat'
        assert all(sha(Path(x['log'])) == x['sha256'] for x in old['runs']+[old['verify']])
        try:
            check_host_record(a.output, old)
        except BaseException as error:
            save(a.output/'pipeline-obs-host.json',dict(gate='FAIL',error=repr(error)))
            raise
        ready.write_text('PASS\n',encoding='ascii')
        print('Retained matching workload-A/A PASS and no-OBS snapshots revalidated; no new samples',flush=True)
        return 0
    raw = a.output/'pipeline-aa-raw'
    raw.mkdir(exist_ok=False)
    result = {'gate':'RUNNING','profile':a.profile,'identity':identity,'runs':[],
        'rule':'Original existing Graph/compute workload-AA: full baseline/candidate two-image topology; all four execution/allocation factors, original5% factor medians and10% gross stop. No A/B or tuning.'}
    def checkpoint():
        result['elapsed_seconds'] = time.monotonic()-started
        save(result_path,result)
    def invoke(tag, additions):
        nonce = secrets.token_hex(16)
        additions = {**additions,'HYLE_PERF_RUN_NONCE':nonce}
        env = _child_environment(CONTROLLED,additions,profile,policy)
        env['DISABLE_VULKAN_OBS_CAPTURE'] = '1'
        log = raw/(tag+'.log')
        stamp = time.monotonic()
        with log.open('wb') as output:
            child = subprocess.Popen([str(executable)],env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=_creation_flags(policy))
            result.update(stage=tag,child_pid=child.pid)
            checkpoint()
            while True:
                try:
                    code = child.wait(timeout=1800)
                    break
                except subprocess.TimeoutExpired:
                    result.setdefault('time_extensions',[]).append({'pid':child.pid,'seconds':1800})
                    checkpoint()
        result.pop('child_pid',None)
        text = log.read_text(encoding='utf8',errors='replace')
        assert code == 0, text[-5000:]
        host_snapshot = check_obs_absent(log)
        assert len(re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M)) == 4
        assert len(re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M)) == 4
        assert len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M)) == 8
        dimensions = dict(execution_order='peer-first' if additions.get('HYLE_BENCH_RIVAL_FIRST')=='1' else 'candidate-first',allocation_order='peer-first' if additions.get('HYLE_BENCH_PEER_ALLOCATION_FIRST')=='1' else 'candidate-first')
        expected = _product_telemetry_expectations({'dimensions':dimensions},profile,policy)
        expected['run_nonce'] = nonce
        _required_telemetry(text,['# HYLE_G09_INSTRUMENT_RUN '],expected)
        return text,dict(log=str(log.resolve()),sha256=sha(log),exit_code=code,elapsed_seconds=time.monotonic()-stamp,host_snapshot=host_snapshot)
    try:
        with _apply_sampling_policy(policy) as applied:
            result['applied_policy'] = applied
            result['child_canary'] = _probe_child_policy(policy,_creation_flags(policy))
            _,result['verify'] = invoke('verify',{'HYLE_BENCH_VERIFY_ONLY':'1'})
            for sdk in ['baseline','candidate']:
                for peer_first in [False,True]:
                    for allocation_first in [False,True]:
                        text,item = invoke(f'{sdk}-{int(peer_first)}-{int(allocation_first)}',{'HYLE_BENCH_AA_ROUTE':sdk,'HYLE_BENCH_RIVAL_FIRST':str(int(peer_first)),'HYLE_BENCH_PEER_ALLOCATION_FIRST':str(int(allocation_first))})
                        rows = parse_nanobench(text)
                        item.update(sdk=sdk,execution_order='peer-first' if peer_first else 'candidate-first',allocation_order='peer-first' if allocation_first else 'candidate-first',ratios={})
                        for shape in SHAPES:
                            candidate,peer = select_pair(rows,'HYLE G09','HYLE baseline',title=f'G09 {route} {shape} warm')
                            item['ratios'][shape] = candidate.operations_per_second/peer.operations_per_second
                        result['runs'].append(item)
                        checkpoint()
                        print(f'workload-AA {a.profile}: {len(result["runs"])}/8',flush=True)
        errors,summaries = [],{}
        narrow,gross = equivalence_band(AA_MAXIMUM_BIAS_PERCENT),equivalence_band(10)
        for sdk in ['baseline','candidate']:
            matching = [r for r in result['runs'] if r['sdk']==sdk]
            for shape in SHAPES:
                values = [r['ratios'][shape] for r in matching]
                medians = {'all':statistics.median(values)}
                for factor in ['execution_order','allocation_order']:
                    for level in sorted({r[factor] for r in matching}):
                        medians[factor+'='+level] = statistics.median(r['ratios'][shape] for r in matching if r[factor]==level)
                if any(not gross[0]<=x<=gross[1] for x in values):
                    errors.append(sdk+'/'+shape+': gross instability')
                if any(not narrow[0]<=x<=narrow[1] for x in medians.values()):
                    errors.append(sdk+'/'+shape+': factor median bias')
                summaries[sdk+'/'+shape] = dict(ratios=values,factor_medians=medians)
        assert bind_artifacts() == artifacts
        assert sha(executable) == identity['executable_sha256'] and sha(control) == identity['control_sha256']
        result.update(gate='FAIL' if errors else 'PASS',errors=errors,summaries=summaries)
        checkpoint()
        if not errors:
            check_host_record(a.output, result)
            ready.write_text('PASS\n',encoding='ascii')
        print(json.dumps({'gate':result['gate'],'errors':errors}),flush=True)
        return 2 if errors else 0
    except BaseException as error:
        result.update(gate='FAIL',error=repr(error))
        checkpoint()
        raise

if __name__ == '__main__':
    with applied_macos_qos('interactive' if AIR else None):
        raise SystemExit(main())
