#include "facade_api.h"
#include "perf_process.h"
#include <nanobench.h>

#include <array>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <memory>
#include <stdexcept>
#include <string>
#if defined(_WIN32)
#include <tlhelp32.h>
#else
#include <dlfcn.h>
#include <mach-o/dyld.h>
#endif

namespace {
namespace nb = ankerl::nanobench;
std::string environment(const char *name) {
#if defined(_WIN32)
  char *value = nullptr;
  std::size_t size = 0;
  if (_dupenv_s(&value, &size, name)) throw std::runtime_error("cannot read environment");
  const std::string result = value ? value : "";
  std::free(value);
  return result;
#else
  const auto *value = std::getenv(name);
  return value ? value : "";
#endif
}
bool enabled(const char *name) {
  const auto value = environment(name);
  return !value.empty() && value != "0";
}
void ensure(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}

struct Image {
#if defined(_WIN32)
  HMODULE handle = nullptr;
#else
  void *handle = nullptr;
#endif
  const G09FacadeApi *api = nullptr;
  std::filesystem::path path;
  explicit Image(const std::filesystem::path &file) : path(std::filesystem::canonical(file)) {
#if defined(_WIN32)
    handle = LoadLibraryExW(path.c_str(), nullptr,
        LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    ensure(handle != nullptr, "cannot load private facade DLL");
    auto get = reinterpret_cast<G09GetApi>(GetProcAddress(handle, "hyle_g09_facade_v1"));
#else
    handle = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!handle) throw std::runtime_error(dlerror());
    auto get = reinterpret_cast<G09GetApi>(dlsym(handle, "hyle_g09_facade_v1"));
#endif
    ensure(get != nullptr, "missing private facade C getter");
    api = get();
    ensure(api && api->abi_version == 1 && api->struct_bytes == sizeof(G09FacadeApi), "C table ABI differs");
    const std::array addresses{
        reinterpret_cast<const void *>(get), static_cast<const void *>(api),
        reinterpret_cast<const void *>(api->create), reinterpret_cast<const void *>(api->replay),
        reinterpret_cast<const void *>(api->facts), reinterpret_cast<const void *>(api->destroy),
        static_cast<const void *>(api->image_tag)};
    for (const auto *address : addresses) {
#if defined(_WIN32)
      MEMORY_BASIC_INFORMATION mapping{};
      ensure(VirtualQuery(address, &mapping, sizeof(mapping)) != 0 && mapping.AllocationBase == handle,
          "facade C table/code/data resolves outside its own PE image");
#else
      Dl_info mapping{};
      ensure(dladdr(address, &mapping) != 0 && mapping.dli_fname,
          "cannot locate facade code/data image");
      ensure(std::filesystem::equivalent(path, mapping.dli_fname),
          "facade C table/code/data resolves outside its own Mach-O image");
#endif
    }
    std::fprintf(stderr, "# G09_IMAGE path=%s tag=%s getter=%p table=%p create=%p replay=%p facts=%p destroy=%p tag_data=%p\n",
        path.string().c_str(), api->image_tag, addresses[0], addresses[1], addresses[2],
        addresses[3], addresses[4], addresses[5], addresses[6]);
  }
  Image(const Image &) = delete;
  Image &operator=(const Image &) = delete;
  ~Image() {
    if (!handle) return;
    std::array<char, 128> tag{};
    std::snprintf(tag.data(), tag.size(), "%s", api ? api->image_tag : "unknown");
    const auto begin = std::chrono::steady_clock::now();
#if defined(_WIN32)
    const int status = FreeLibrary(handle) ? 0 : 1;
#else
    const int status = dlclose(handle);
#endif
    const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - begin).count();
    std::fprintf(stderr, "# G09_DEFERRED_DSO_UNLOAD tag=%s nanoseconds=%lld status=%d private_vendor_cache=UNKNOWN\n",
        tag.data(), static_cast<long long>(ns), status);
  }
};

void emit_modules(const char *phase) {
#if defined(_WIN32)
  const HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, GetCurrentProcessId());
  ensure(snapshot != INVALID_HANDLE_VALUE, "cannot enumerate actual loaded modules");
  MODULEENTRY32W entry{};
  entry.dwSize = sizeof(entry);
  if (Module32FirstW(snapshot, &entry)) {
    do {
      const auto path = std::filesystem::path(entry.szExePath).string();
      std::fprintf(stderr, "# G09_MODULE phase=%s path=%s\n", phase, path.c_str());
    } while (Module32NextW(snapshot, &entry));
  }
  CloseHandle(snapshot);
#else
  for (std::uint32_t i = 0; i < _dyld_image_count(); ++i)
    std::fprintf(stderr, "# G09_MODULE phase=%s path=%s\n", phase, _dyld_get_image_name(i));
#endif
}

struct Arm {
  Image &image;
  void *state = nullptr;
  explicit Arm(Image &owner, unsigned shape) : image(owner) {
    std::array<char, 1024> error{};
    const auto begin = std::chrono::steady_clock::now();
    state = image.api->create(shape, error.data(), error.size());
    if (!state) throw std::runtime_error(error.data());
    const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - begin).count();
    std::fprintf(stderr, "# G09_COLD_CREATE tag=%s shape=%u nanoseconds=%lld\n",
        image.api->image_tag, shape, static_cast<long long>(ns));
  }
  void replay(bool full_oracle = false) {
    std::array<char, 1024> error{};
    if (image.api->replay(state, full_oracle ? 1u : 0u, error.data(), error.size()))
      throw std::runtime_error(error.data());
  }
  void facts(unsigned shape) {
    G09Facts info{};
    std::array<char, 1024> error{};
    if (image.api->facts(state, &info, error.data(), error.size())) throw std::runtime_error(error.data());
    ensure(info.elements == 4194304 && info.slots == (shape == 2 ? 2u : 1u) && info.cpu_target == 1 && info.gpu_target == 0,
        "fixed facade consumer shape differs");
    std::fprintf(stderr, "# G09_PLANNED tag=%s shape=%u elements=%llu slots=%llu fragments=%llu copy_count=%llu copy_bytes=%llu copy_scope=slot0-per-invocation pair_total_claim=0 actual_dispatch_claim=0\n",
        image.api->image_tag, shape, static_cast<unsigned long long>(info.elements),
        static_cast<unsigned long long>(info.slots), static_cast<unsigned long long>(info.cold_fragments),
        static_cast<unsigned long long>(info.planned_copy_count), static_cast<unsigned long long>(info.planned_copy_bytes));
  }
  void finish() {
    if (!state) return;
    auto *owned = state;
    state = nullptr;
    std::array<char, 1024> error{};
    const auto begin = std::chrono::steady_clock::now();
    const auto code = image.api->destroy(owned, error.data(), error.size());
    const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - begin).count();
    std::fprintf(stderr, "# G09_DEFERRED_DESTROY tag=%s nanoseconds=%lld status=%d\n",
        image.api->image_tag, static_cast<long long>(ns), code);
    if (code) throw std::runtime_error(error.data());
  }
  ~Arm() {
    if (state) {
      std::array<char, 1024> error{};
      if (image.api->destroy(state, error.data(), error.size()))
        std::fprintf(stderr, "FAIL cleanup: %s\n", error.data());
    }
  }
};

constexpr std::array<const char *, 4> shapes{
    "independent-cpu-first", "independent-gpu-first", "two-microbatches", "serial-holdout"};
void measure(Image &candidate_image, Image &peer_image, unsigned shape) {
  std::unique_ptr<Arm> candidate, peer;
  if (enabled("HYLE_BENCH_PEER_ALLOCATION_FIRST")) {
    peer = std::make_unique<Arm>(peer_image, shape);
    candidate = std::make_unique<Arm>(candidate_image, shape);
  } else {
    candidate = std::make_unique<Arm>(candidate_image, shape);
    peer = std::make_unique<Arm>(peer_image, shape);
  }
  candidate->facts(shape);
  peer->facts(shape);
  candidate->replay(true);
  peer->replay(true);
  for (unsigned i = 0; i < 8; ++i) {
    candidate->replay();
    peer->replay();
  }
  emit_modules(shapes[shape]);
  std::fprintf(stderr, "# G09_ORACLE shape=%s before=PASS full_elements=4194304 warmups_per_arm=8 unit=complete-%u-slot-replay\n",
      shapes[shape], shape == 2 ? 2u : 1u);
  if (!enabled("HYLE_BENCH_VERIFY_ONLY")) {
    nb::Bench bench;
    bench.title(std::string("G09 ") + G09_ROUTE_NAME + " " + shapes[shape] + " warm")
        .batch(1).epochs(11).epochIterations(1).minEpochIterations(1)
        .warmup(0).performanceCounters(false);
    const auto a = [&] { candidate->replay(); };
    const auto b = [&] { peer->replay(); };
    const auto result = enabled("HYLE_BENCH_RIVAL_FIRST")
        ? bench.compare("HYLE baseline", b, "HYLE G09", a)
        : bench.compare("HYLE G09", a, "HYLE baseline", b);
    // Original paired instrument rounds requested11 to12 for its ABBA blocks.
    ensure(result.rounds() == 12, "original paired-round topology differs");
    std::fprintf(stderr, "# G09_MEASUREMENT shape=%s requested_epochs=11 actual_paired_rounds=%zu exact_epoch_iterations=1 logical_replays_per_call=1\n",
        shapes[shape], result.rounds());
  }
  // Separate complete replays. No view from the final timed replay escapes.
  candidate->replay(true);
  peer->replay(true);
  std::fprintf(stderr, "# G09_ORACLE shape=%s after=PASS full_elements=4194304\n", shapes[shape]);
  candidate->finish();
  peer->finish();
}
} // namespace

int main(int argc, char **argv) {
  try {
    ensure(argc == 5, "pass candidate, peer, candidate A/A clone, peer A/A clone images");
    const auto qos = hyle::bench::perf::configure_thread_qos();
    const auto aa = environment("HYLE_BENCH_AA_ROUTE");
    ensure(aa.empty() || aa == "baseline" || aa == "candidate", "invalid workload A/A route");
    if (!enabled("HYLE_BENCH_VERIFY_ONLY") && aa.empty() && enabled("HYLE_PERF_RUN_NONCE")) {
      std::string ready;
      std::ifstream(std::filesystem::absolute(argv[0]).parent_path() / "g09_pipeline_aa.ready") >> ready;
      ensure(ready == "PASS", "original workload-matched A/A not qualified");
    }
    const auto candidate_path = aa == "baseline" ? argv[2] : argv[1];
    const auto peer_path = aa == "baseline" ? argv[4] : aa == "candidate" ? argv[3] : argv[2];
    ensure(!std::filesystem::equivalent(candidate_path, peer_path), "A/A and A/B need two distinct isolated images");
    std::fprintf(stderr, "# HYLE_G09_RUN run_nonce=%s apple_qos=%s qos_ok=%s route=%s verify_only=%d requested_epochs=11 actual_paired_rounds=12 exact_iterations=1 execution_order=%s allocation_and_load_order=%s aa_route=%s\n",
        hyle::bench::perf::run_nonce(), qos.name, qos.ok, G09_ROUTE_NAME,
        enabled("HYLE_BENCH_VERIFY_ONLY"), enabled("HYLE_BENCH_RIVAL_FIRST") ? "peer-first" : "candidate-first",
        enabled("HYLE_BENCH_PEER_ALLOCATION_FIRST") ? "peer-first" : "candidate-first", aa.c_str());
    std::unique_ptr<Image> candidate, peer;
    if (enabled("HYLE_BENCH_PEER_ALLOCATION_FIRST")) {
      peer = std::make_unique<Image>(peer_path);
      candidate = std::make_unique<Image>(candidate_path);
    } else {
      candidate = std::make_unique<Image>(candidate_path);
      peer = std::make_unique<Image>(peer_path);
    }
    for (unsigned i = 0; i < shapes.size(); ++i) measure(*candidate, *peer, i);
    return 0;
  } catch (const std::exception &failure) {
    std::fprintf(stderr, "FAIL G09: %s\n", failure.what());
    return 1;
  }
}
