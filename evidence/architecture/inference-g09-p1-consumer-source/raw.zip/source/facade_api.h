#pragma once
#include <cstddef>
#include <cstdint>

// Private benchmark boundary. No HYLE/STL object or ownership crosses images.
struct G09Facts {
  std::uint64_t elements;
  std::uint64_t slots;
  std::uint64_t cold_fragments;
  std::uint64_t planned_copy_count;
  std::uint64_t planned_copy_bytes;
  std::uint64_t cpu_target;
  std::uint64_t gpu_target;
};
struct G09FacadeApi {
  std::uint64_t abi_version;
  std::uint64_t struct_bytes;
  const char *image_tag;
  void *(*create)(std::uint32_t shape, char *error, std::size_t capacity) noexcept;
  int (*replay)(void *state, std::uint32_t full_oracle,
                char *error, std::size_t capacity) noexcept;
  int (*facts)(void *state, G09Facts *facts,
               char *error, std::size_t capacity) noexcept;
  int (*destroy)(void *state, char *error, std::size_t capacity) noexcept;
};
using G09GetApi = const G09FacadeApi *(*)() noexcept;
