// Build-time staging consumer only. Never executed or included in timing.
int main() { return 0; }
