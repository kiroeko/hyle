#include "mlx/backend/metal/kernels/defines.h"
#include "mlx/backend/metal/kernels/utils.h"
#include "/Users/kiro/hyle-scratch/compute-unified/ce14-query-header.h"
instantiate_kernel("probe_float16", attention, float, 16, 8, 256, 2, 1, float, float, 256);
instantiate_kernel("probe_half16", attention, half, 16, 8, 256, 2, 1, half, float, 256);
instantiate_kernel("probe_half32", attention, half, 32, 16, 256, 4, 1, half, float, 256);

instantiate_kernel("probe_queryhalf", attention, float, 16, 16, 256, 2, 1, float, float, 256, half);

instantiate_kernel("probe_queryhalf32", attention, float, 32, 8, 256, 4, 1, float, float, 256, half);
