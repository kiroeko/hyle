from pathlib import Path
import ctypes, hashlib, json, os, subprocess, sys, time

root=Path('C:/public/project-hyle/hyle')
build=Path('C:/h7/w-cuda/selected-graph/static-sdk-build')
inputs=root/'.scratch/inference-gaps/g10-delivery-inputs'
label=sys.argv[1]
assert label.isdigit()
out=root/'.scratch/inference-gaps'/('g10-windows-cpu-cuda-'+label)
out.mkdir(exist_ok=False)
started=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((inputs/'inputs.json').read_text())
r=dict(state='SETUP',pid=os.getpid(),stages=[],source_commit=manifest['head'],build=str(build),jobs=4,
       scope='G10 startup limit followed by unchanged original public CPU+CUDA sample math, two slots, native DMA and lifecycle. Reuses shipping-layout test tree and proven unchanged CUDA inputs/objects. No SDK or P1 claim.')
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
env.update(VSLANG='1033',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
kernel=ctypes.windll.kernel32
kernel.GetCurrentProcess.restype=ctypes.c_void_p
handle=kernel.GetCurrentProcess()
kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
available,system=ctypes.c_size_t(),ctypes.c_size_t()
assert kernel.GetProcessAffinityMask(handle,ctypes.byref(available),ctypes.byref(system))
mask=sum([1<<i for i in range(64) if available.value & (1<<i)][:4])
assert kernel.SetProcessAffinityMask(handle,mask)
kernel.SetErrorMode(0x0001|0x0002|0x8000)
r['resource']=dict(affinity_mask=hex(mask),priority='BelowNormal',logical_cpu_limit=4)

def save():
 r['elapsed_seconds']=time.monotonic()-started
 (out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')

def run(stage,args):
 r.update(state='RUNNING',stage=stage);save();print(stage,flush=True);stamp=time.monotonic()
 with (out/(stage+'.log')).open('wb') as log:
  p=subprocess.Popen([str(x) for x in args],env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  r['child_pid']=p.pid;save()
  while True:
   try:code=p.wait(timeout=1800);break
   except subprocess.TimeoutExpired:r.setdefault('time_extensions',[]).append(dict(stage=stage,pid=p.pid,seconds=1800));save()
 r.pop('child_pid',None)
 r['stages'].append(dict(stage=stage,argv=[str(x) for x in args],exit=code,seconds=time.monotonic()-stamp));save()
 if code:
  print((out/(stage+'.log')).read_text(encoding='utf8',errors='replace')[-12000:],flush=True)
  raise RuntimeError(stage+' exited '+str(code))

try:
 for item in manifest['files']:assert sha(root/item['path'])==item['sha256'],item['path']
 for item in manifest['fixtures']:assert sha(inputs/item['path'])==item['sha256'],item['path']
 (out/'runner.py').write_bytes(Path(__file__).read_bytes())
 profile='include("'+(root/'.scratch/inference-gaps/g08_shipping_cuda_profile.cmake').as_posix()+'")\n'
 wrapper=(inputs/'joint_runtime.cc').read_text().replace('#include "cpu_cuda.cc"','#include "'+(root/'samples/package/graph/cpu_cuda/main.cc').as_posix()+'"')
 (out/'joint_runtime.cc').write_text(wrapper,encoding='utf8')
 profile+='''if(PROJECT_NAME STREQUAL "hyle")
function(g10_joint_app)
add_executable(g10_joint "OUT/joint_runtime.cc")
target_compile_features(g10_joint PRIVATE cxx_std_23)
target_link_libraries(g10_joint PRIVATE hyle::compute hyle::graph hyle::sched CUDA::cudart)
hyle_stage_runtime(g10_joint)
endfunction()
cmake_language(DEFER CALL g10_joint_app)
endif()
'''.replace('OUT',out.as_posix())
 (out/'targets.cmake').write_text(profile,encoding='utf8')
 run('configure',['cmake','-S',root,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DCMAKE_PROJECT_INCLUDE='+(out/'targets.cmake').as_posix()])
 run('manifest',['ninja','-C',build,'build.ninja'])
 preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
 run('dry-run',['ninja','-C',build,'-f',preview,'-n','g10_joint'])
 dry=(out/'dry-run.log').read_text(encoding='utf8',errors='replace')
 if 'Building CUDA object' in dry:
  run('native-reuse',[sys.executable,'-X','utf8',root/'.scratch/inference-gaps/g08_windows_cuda_native_reuse.py','static','g10-joint-'+label])
  reuse=root/'.scratch/inference-gaps'/('g08-windows-static-native-reuse-g10-joint-'+label)
  proof=json.loads((reuse/'result.json').read_text())
  assert proof['state']=='PASS_146_WINDOWS_NATIVE_OBJECTS_INPUTS_AND_ORIGINAL_NINJA_COMMANDS_FRESH'
  assert proof['original_manifest_sha256']==sha(build/'build.ninja') and proof['reuse_manifest_sha256']==sha(reuse/'reuse.ninja')
  r['unchanged_cuda_input_object_reuse']=dict(path=str(reuse),proof=proof)
  preview.write_bytes((reuse/'reuse.ninja').read_bytes())
  run('mapped-dry-run',['ninja','-C',build,'-f',preview,'-n','g10_joint'])
  dry=(out/'mapped-dry-run.log').read_text(encoding='utf8',errors='replace')
 assert len(dry.splitlines())<150 and all(x not in dry for x in ['Building CUDA object','vulkan-shaders','Re-running CMake']),dry[-12000:]
 r['dry_run_edges']=len(dry.splitlines())
 run('build',['ninja','-C',build,'-f',preview,'-j','4','g10_joint'])
 matches=[p for p in [build/'bin/g10_joint.exe',build/'g10_joint.exe'] if p.is_file()]
 assert len(matches)==1,matches
 run('public-joint',[matches[0]])
 r['binary']=dict(path=str(matches[0]),sha256=sha(matches[0]))
 for item in manifest['files']:assert sha(root/item['path'])==item['sha256'],item['path']
 r['state']='PUBLIC_CPU_CUDA_MATH_LIFECYCLE_WITH_SHARED_STARTUP_LIMIT_PASS';save();print(r['state'],r['elapsed_seconds'],flush=True)
except BaseException as error:
 r.update(state='FAIL',error=repr(error));save();raise
