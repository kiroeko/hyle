from pathlib import Path
import ctypes, hashlib, json, os, re, subprocess, sys, time

mode, label = sys.argv[1:3]
assert mode in ['asan', 'ubsan', 'tsan'] and label.isdigit()
win, air = sys.platform == 'win32', sys.platform == 'darwin'
if win:
    assert mode in ['disabled', 'asan']
    source = Path('C:/public/project-hyle/hyle')
    inputs = source / '.scratch/inference-gaps/g10-delivery-inputs'
    build = Path('C:/h7/w-cpu-cuda/selected-graph/source-build' if mode == 'disabled' else 'C:/h7/foundation-f5-native-san-vulkan-asan/build')
    out = source / '.scratch/inference-gaps' / ('g10-windows-host-' + mode + '-' + label)
    setup = subprocess.check_output(['cmd', '/d', '/c', str(source / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], encoding='utf8', errors='replace')
    env = {k.upper(): v for k, v in os.environ.items()}
    env.update((k.upper(), v) for k, v in (x.split('=', 1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
    env['VSLANG'] = '1033'
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    handle = kernel.GetCurrentProcess()
    kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
    kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    available, system = ctypes.c_size_t(), ctypes.c_size_t()
    assert kernel.GetProcessAffinityMask(handle, ctypes.byref(available), ctypes.byref(system))
    mask = sum([1 << i for i in range(64) if available.value & (1 << i)][:4])
    assert kernel.SetProcessAffinityMask(handle, mask)
    kernel.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    resource = dict(affinity_mask=hex(mask), priority='BelowNormal', logical_cpu_limit=4)
    cmake, ninja = 'cmake', 'ninja'
else:
    base = Path('/Users/kiro/hyle-scratch/compute-unified' if air else '/root/hyle-scratch/compute-unified')
    source = base / ('source-c8874688' if air else 'source-7a7b4c3b')
    inputs = base / 'g10-delivery-inputs'
    build = base / ('foundation-f5-native-host-' + ('apple' if air else 'cuda') + '-' + mode) / 'build'
    out = base / ('g10-host-' + mode + '-' + label)
    env = dict(os.environ)
    env['PATH'] = ('/opt/homebrew/bin:' if air else '') + env.get('PATH', '')
    os.nice(10)
    resource = dict(nice=os.nice(0), logical_cpu_limit='macOS no supported hard affinity' if air else 4)
    if not air:
        os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:4])
        resource['logical_cpus'] = sorted(os.sched_getaffinity(0))
    cmake, ninja = ('/opt/homebrew/bin/cmake', '/opt/homebrew/bin/ninja') if air else ('cmake', 'ninja')

out.mkdir(parents=True, exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((inputs / 'inputs.json').read_text())
started = time.monotonic()
r = dict(state='SETUP', pid=os.getpid(), mode=mode, source=str(source), build=str(build), stages=[],
         snapshot={k:manifest[k] for k in ['head','tree','archive_sha256']}, resource=resource, jobs=4,
         scope='New G10 shared startup/first-use state with actual feature ON for sanitizers, public two-phase concurrent math/lifecycle and original Graph/executor consumer. OFF is a separate absence/no-Torch/ggml-only check. No GPU/private-vendor-pool/leak/P1 certificate.')
env.update(OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           ASAN_OPTIONS='halt_on_error=1:detect_leaks=0', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',
           TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0')
parent_file = original_parent = None

def save():
    r['elapsed_seconds'] = time.monotonic() - started
    (out / 'result.json').write_text(json.dumps(r, indent=2) + '\n', encoding='utf8')

def run(stage, args, accepted=(0,)):
    r.update(state='RUNNING', stage=stage)
    save()
    print(mode, stage, flush=True)
    stamp = time.monotonic()
    with (out / (stage + '.log')).open('wb') as log:
        p = subprocess.Popen([str(x) for x in args], env=env, stdout=log, stderr=subprocess.STDOUT,
            creationflags=(subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS) if win else 0)
        r['child_pid'] = p.pid
        save()
        while True:
            try:
                code = p.wait(timeout=1800)
                break
            except subprocess.TimeoutExpired:
                r.setdefault('time_extensions', []).append(dict(stage=stage,pid=p.pid,seconds=1800))
                save()
    r.pop('child_pid',None)
    r['stages'].append(dict(stage=stage,argv=[str(x) for x in args],exit=code,seconds=time.monotonic()-stamp))
    save()
    if code not in accepted:
        print((out / (stage + '.log')).read_text(encoding='utf8',errors='replace')[-14000:],flush=True)
        raise RuntimeError(stage + ' exited ' + str(code))
    return code

try:
    for item in manifest['files']: assert sha(source / item['path']) == item['sha256'],item['path']
    for item in manifest['fixtures']: assert sha(inputs / item['path']) == item['sha256'],item['path']
    (out / 'runner.py').write_bytes(Path(__file__).read_bytes())
    if win:
        r['identity'] = dict(host=env.get('COMPUTERNAME'),compiler=env.get('VCTOOLSVERSION'))
    else:
        queries = {'model':['sysctl','-n','hw.model'],'system':['sw_vers'],'compiler':['xcrun','clang++','--version']} if air else {'system':['uname','-a'],'compiler':['g++-14','--version']}
        r['identity'] = {k:subprocess.check_output(v,env=env,text=True).strip() for k,v in queries.items()}
        if air: assert r['identity']['model'] == 'Mac16,12'
    cache = (build / 'CMakeCache.txt').read_text()
    (out / 'original-cache.txt').write_text(cache,encoding='utf8')
    home = Path(next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_HOME_DIRECTORY:')))
    if home.resolve() != source.resolve():
        parent_file = home / 'CMakeLists.txt'
        original_parent = parent_file.read_bytes()
        (out / 'original-parent.cmake').write_bytes(original_parent)
        parent_file.write_text('cmake_minimum_required(VERSION 3.25)\nproject(g10_host_risk LANGUAGES CXX)\n' + ('set(CMAKE_OSX_DEPLOYMENT_TARGET 14.4)\n' if air else '') + 'add_subdirectory("' + source.as_posix() + '" hyle)\n',encoding='utf8')
    model = None
    if mode == 'tsan':
        model = base / 'g02-refcount-fence-probe/tsan-headers' if air else Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g09-tsan-refcount-model')
        ref = model / 'hyle/util/ref_counted.h'
        body = ref.read_text().replace('#include <sanitizer/tsan_interface.h>\n','').replace('    __tsan_acquire(const_cast<std::atomic<std::uint32_t>*>(&value_));\n','')
        body = body.replace('  void acquire_before_destroy() const noexcept {','  static void acquire_before_destroy() noexcept {').replace('      refcount_.acquire_before_destroy();','      decltype(refcount_)::acquire_before_destroy();')
        assert body == (source / 'include/hyle/util/ref_counted.h').read_text()
        assert sha(ref) == '2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
        r['original_fence_model'] = dict(path=str(ref),sha256=sha(ref),scope='Original final refcount acquire-fence annotation only; no new synchronization model or suppression. New G10 std::mutex state is normally instrumented.')
    profile = '''if(PROJECT_NAME STREQUAL "hyle")
function(g10_host_apps)
get_target_property(_torch hyle_compute_provider_native HYLE_TORCH_CPU_ENABLED)
file(WRITE "OUT/features.txt" "torch=${_torch}\\nsanitizer=${HYLE_SANITIZER}\\n")
add_executable(g10_runtime "INPUTS/thread_runtime_consumer.cc")
target_link_libraries(g10_runtime PRIVATE hyle::compute)
set(_apps g10_runtime)
if(_torch)
add_executable(g10_graph "INPUTS/graph_runtime.cc")
target_link_libraries(g10_graph PRIVATE hyle::compute hyle::graph hyle::sched)
add_executable(g10_vendor "${HYLE_SOURCE_DIR}/tests/compute_route_cpu/thread_runtime_consumer.cc")
target_compile_definitions(g10_vendor PRIVATE HYLE_G10_TEST_VENDOR=1)
target_link_libraries(g10_vendor PRIVATE hyle::compute torch)
list(APPEND _apps g10_graph g10_vendor)
endif()
foreach(_app IN LISTS _apps)
target_compile_features(${_app} PRIVATE cxx_std_23)
hyle_apply_sanitizer(${_app})
hyle_stage_runtime(${_app})
endforeach()
MODELS
endfunction()
cmake_language(DEFER CALL g10_host_apps)
endif()
'''.replace('OUT',out.as_posix()).replace('INPUTS',inputs.as_posix())
    models = ''
    if model:
        models = '''function(g10_original_fence_model directory)
get_property(_targets DIRECTORY "${directory}" PROPERTY BUILDSYSTEM_TARGETS)
foreach(_target IN LISTS _targets)
get_target_property(_kind "${_target}" TYPE)
if(_target MATCHES "^hyle_" AND NOT _kind STREQUAL "INTERFACE_LIBRARY")
target_include_directories("${_target}" BEFORE PRIVATE "MODEL")
endif()
endforeach()
get_property(_children DIRECTORY "${directory}" PROPERTY SUBDIRECTORIES)
foreach(_child IN LISTS _children)
g10_original_fence_model("${_child}")
endforeach()
endfunction()
g10_original_fence_model("${HYLE_SOURCE_DIR}")
foreach(_app IN LISTS _apps)
target_include_directories(${_app} BEFORE PRIVATE "MODEL")
endforeach()
'''.replace('MODEL',model.as_posix())
    profile = profile.replace('MODELS',models)
    (out / 'targets.cmake').write_text(profile,encoding='utf8')
    args = [cmake,'-S',home,'-B',build,'-UHYLE_DEV_FACTORS','-DHYLE_COMPONENTS=compute;graph;sched',
        '-UHYLE_COMPUTE_TORCH_CPU','-DHYLE_COMPUTE_ROUTES=cpu',
        '-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_INSTALL=OFF',
        '-DHYLE_SANITIZER=' + ('off' if mode=='disabled' else mode),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
        '-DCMAKE_PROJECT_INCLUDE=' + (out / 'targets.cmake').as_posix()]
    run('configure',args)
    features=(out / 'features.txt').read_text()
    assert ('torch=TRUE' in features) == (mode!='disabled'),features
    assert ('sanitizer=' + ('off' if mode=='disabled' else mode)) in features
    r['features']=features
    run('manifest',[ninja,'-C',build,'build.ninja'])
    preview = out / 'preview.ninja'
    preview.write_bytes((build / 'build.ninja').read_bytes())
    targets=['g10_runtime'] + ([] if mode=='disabled' else ['g10_graph','g10_vendor'])
    run('dry-run',[ninja,'-C',build,'-f',preview,'-n',*targets])
    dry=(out / 'dry-run.log').read_text(encoding='utf8',errors='replace')
    assert len(dry.splitlines())<450 and all(x not in dry for x in ['Building CUDA object','vulkan-shaders','Re-running CMake']),dry[-12000:]
    r['dry_run_edges']=len(dry.splitlines())
    commands=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb'],env=env,text=True,encoding='utf8',errors='replace'))
    core=[x for x in commands if x.get('file','').replace('\\','/').endswith(('/src/compute_provider_native/aten_cpu_provider.cc','/src/compute_provider_native/native_provider.cc','/src/compute_provider_native/torch_cpu_program.cc','/src/compute_route_cpu/cpu_context.cc'))]
    assert len(core)==(3 if mode=='disabled' else 4),len(core)
    if mode!='disabled':
        flag='/fsanitize=address' if win else '-fsanitize=' + {'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
        assert all(flag in x['command'] for x in core)
        assert all('HYLE_COMPUTE_TORCH_CPU=1' in x['command'] for x in core if 'compute_provider_native' in x['file'])
        apps=[x for x in commands if x.get('file','').lower().endswith(('.cc','.cpp','.cxx')) and any('/CMakeFiles/'+t+'.dir/' in x.get('output','').replace('\\','/') or ('CMakeFiles/'+t+'.dir') in x['command'].replace('\\','/') for t in targets)]
        assert len(apps)==3 and all(flag in x['command'] for x in apps),apps
    (out / 'instrumented-core-commands.json').write_text(json.dumps(core,indent=2)+'\n',encoding='utf8')
    if mode!='disabled':
        (out / 'instrumented-app-commands.json').write_text(json.dumps(apps,indent=2)+'\n',encoding='utf8')
    run('build',[ninja,'-C',build,'-f',preview,'-j','4',*targets])
    suffix='.exe' if win else ''
    def binary(name):
        matches=[p for p in [build/(name+suffix),build/'bin'/(name+suffix),build/'hyle'/(name+suffix),build/'hyle/bin'/(name+suffix)] if p.is_file()]
        assert len(matches)==1,matches
        return matches[0]
    public=binary('g10_runtime')
    if mode=='disabled':
        if win:
            compiler=Path(next(x.split('=',1)[1] for x in (build/'CMakeCache.txt').read_text().splitlines() if x.startswith('CMAKE_CXX_COMPILER:')))
            deps=subprocess.check_output([str(compiler.with_name('dumpbin.exe')),'/nologo','/dependents',str(public)],env=env,text=True)
            assert 'HYLE_STATIC:BOOL=ON' in cache,'OFF import audit currently requires the retained static producer'
        else: deps=subprocess.check_output(['otool','-L',str(public)] if air else ['ldd',str(public)],env=env,text=True)
        (out / 'disabled-imports.log').write_text(deps,encoding='utf8')
        assert not re.search(r'(torch|c10)[^\s]*\.(dll|dylib|so)',deps,re.I),deps
        run('public-disabled',[public,'--disabled'])
    else:
        for scenario in ['startup','query-first','late-native','late-aten','race-use','race-config','metadata-oom']:
            run('public-'+scenario,[public,'--'+scenario])
        run('public-graph-executor',[binary('g10_graph')])
        run('private-foreign',[binary('g10_vendor'),'--foreign'])
        run('private-qualified-drift',[binary('g10_vendor'),'--qualified-drift'],accepted=(0,77))
    r['binaries']=[dict(path=str(binary(t)),sha256=sha(binary(t))) for t in targets]
    for item in manifest['files']: assert sha(source/item['path'])==item['sha256'],item['path']
    r['state']='FEATURE_OFF_ABSENCE_NO_TORCH_IMPORTS_GGML_MATH_PASS' if mode=='disabled' else 'FEATURE_ON_INSTRUMENTED_G10_STATE_AND_PUBLIC_CONSUMERS_PASS'
    save()
    print(r['state'],r['elapsed_seconds'],flush=True)
except BaseException as error:
    r.update(state='FAIL',error=repr(error))
    save()
    raise
finally:
    if parent_file is not None and original_parent is not None:
        parent_file.write_bytes(original_parent)
        r['original_parent_restored']=sha(parent_file)==hashlib.sha256(original_parent).hexdigest()
        save()
