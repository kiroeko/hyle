"""One reviewed single-condition incremental rebuild; no application launch."""
from pathlib import Path
import hashlib
import json

root = Path('C:/public/project-hyle/hyle')
out = root / '.scratch/inference-gaps/g09-native-wait-29'
manifest_path = out / 'source-manifest.json'
old = json.loads(manifest_path.read_text(encoding='utf8'))
assert not (out / 'source-manifest-before-review.json').exists()
(out / 'source-manifest-before-review.json').write_bytes(manifest_path.read_bytes())
old['review_correction'] = 'Recheck !changed() under the acquired frontier mutex; record pending and CPU-ready.'
old['sources'] = [dict(path=p.name, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                  for p in sorted((out/'source').iterdir())]
manifest_path.write_text(json.dumps(old, indent=2)+'\n', encoding='utf8')
original = root / '.scratch/inference-gaps/g09_build_completion_observation.py'
source = original.read_text(encoding='utf8')
source = source.replace('g09-completion-observation-25', 'g09-native-wait-29')
source = source.replace('g09_observed_', 'g09_native_wait_')
source = source.replace("LOGS=OUT/'build-logs'", "LOGS=OUT/'build-reviewed-logs'")
source = source.replace("assert not BUILD.exists() and not LOGS.exists(), 'Preserve attempts'",
                        "assert BUILD.exists() and not LOGS.exists(), 'Preserve original and reviewed attempts'")
source = source.replace("OUT/'build-result.json'", "OUT/'build-reviewed-result.json'")
exec(compile(source, str(original)+':reviewed-native-wait-29', 'exec'))
