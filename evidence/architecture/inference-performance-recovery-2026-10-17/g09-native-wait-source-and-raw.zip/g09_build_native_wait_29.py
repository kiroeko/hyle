"""Reuse the reviewed four-TU builder for the new disposable diagnostic."""
from pathlib import Path

root = Path('C:/public/project-hyle/hyle')
original = root / '.scratch/inference-gaps/g09_build_completion_observation.py'
source = original.read_text(encoding='utf8')
source = source.replace('g09-completion-observation-25', 'g09-native-wait-29')
source = source.replace('g09_observed_', 'g09_native_wait_')
exec(compile(source, str(original) + ':native-wait-29', 'exec'))
