#pragma once
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <windows.h>
#include <nvtx3/nvToolsExt.h>
namespace g09_observation {
struct Record { std::uint64_t ns, run, token, value; unsigned kind, thread; };
constexpr unsigned capacity = 65536;
inline Record records[capacity]{};
inline std::atomic<unsigned> used{0};
inline std::uint64_t now() noexcept {
  static const std::uint64_t frequency = [] { LARGE_INTEGER f{}; QueryPerformanceFrequency(&f); return static_cast<std::uint64_t>(f.QuadPart); }();
  LARGE_INTEGER v{}; QueryPerformanceCounter(&v);
  const auto count = static_cast<std::uint64_t>(v.QuadPart);
  return count/frequency*1000000000ULL + count%frequency*1000000000ULL/frequency;
}
inline void marker(unsigned kind, const void *state, std::uint64_t value) noexcept;
inline bool flush() noexcept {
  const auto count = used.load(std::memory_order_acquire);
  std::fprintf(stderr,"# G09_OBSERVATION tag=%s count=%u capacity=%u overflow=%u clock=QPC-ns\n",G09_IMAGE_TAG,count,capacity,count>capacity);
  for (unsigned i=0; i<count && i<capacity; ++i) {
    const auto &r=records[i];
    std::fprintf(stderr,"# G09_RECORD tag=%s ns=%llu kind=%u run=%llu token=%llu value=%llu thread=%u\n",G09_IMAGE_TAG,
      static_cast<unsigned long long>(r.ns),r.kind,static_cast<unsigned long long>(r.run),
      static_cast<unsigned long long>(r.token),static_cast<unsigned long long>(r.value),r.thread);
  }
  used.store(0,std::memory_order_release);
  return count<=capacity;
}
}
extern "C" void g09_record(unsigned kind,const void *run,const void *token,std::uint64_t value) noexcept {
  using namespace g09_observation;
  const auto stamp=now();
  const auto slot=used.fetch_add(1,std::memory_order_relaxed);
  if(slot<capacity) records[slot]={stamp,reinterpret_cast<std::uintptr_t>(run),reinterpret_cast<std::uintptr_t>(token),value,kind,GetCurrentThreadId()};
}
namespace g09_observation {
inline void marker(unsigned kind,const void *state,std::uint64_t value) noexcept {
  g09_record(kind,state,nullptr,value);
  const auto payload=now();
  nvtxEventAttributes_t a{};a.version=NVTX_VERSION;a.size=NVTX_EVENT_ATTRIB_STRUCT_SIZE;
  a.messageType=NVTX_MESSAGE_TYPE_ASCII;a.message.ascii=G09_IMAGE_TAG ":clock-align";
  a.payloadType=NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;a.payload.ullValue=payload;
  nvtxMarkEx(&a);
  // Nsight marker time must lie between payload and this record's clock.
  g09_record(2,state,nullptr,payload);
}
}
