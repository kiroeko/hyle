"""Prepare one native-wait diagnostic. Does not build or execute anything."""
from pathlib import Path
import hashlib
import json

ROOT = Path('C:/public/project-hyle/hyle')
OLD = ROOT / '.scratch/inference-gaps/g09-completion-observation-25/source'
OUT = ROOT / '.scratch/inference-gaps/g09-native-wait-29'
SOURCE = OUT / 'source'
BUILD = Path('C:/h7/g09-native-wait-29')
assert not OUT.exists() and not BUILD.exists(), 'Preserve original attempts'
SOURCE.mkdir(parents=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['facade_api.h', 'recorder.h', 'facade.cc', 'wrapper.cc', 'driver.cc']:
    (SOURCE / name).write_bytes((OLD / name).read_bytes())
original = (OLD / 'invocation.cc').read_text(encoding='utf8')
needle = '''    if (pending != 0) {
      g09_record(30, &run, nullptr, pending);'''
replacement = '''    // R29 disposable causal intervention: only one accepted native prefix,
    // after all currently ready native admissions have been serviced.
    if (pending == 1) {
      using Kind = graph::detail::NativePipelineStage::Kind;
      const auto job_id = run.pending_native[0];
      const auto &selected = run.plan->pipeline_stages[job_id];
      const compute::Completion *completion = nullptr;
      if (selected.kind == Kind::kFragment)
        completion = &run.fragments[selected.index].pending.completion();
      else if (selected.kind == Kind::kUpload || selected.kind == Kind::kDownload)
        completion = &run.values[selected.index].pending_transfer;
      if (completion && completion->valid()) {
        g09_record(50, &run, completion, job_id);
        lock.unlock(); // The CPU lane must retain frontier/queue progress.
        const auto status = completion->wait();
        g09_record(51, &run, completion, status.ok() ? 0 : 1);
        lock.lock();
        if (!status.ok()) run.pipeline_error.Update(status);
        continue; // Original poll/finish/checked-result/retirement remains.
      }
    }
    if (pending != 0) {
      g09_record(30, &run, nullptr, pending);'''
assert original.count(needle) == 1
(SOURCE / 'invocation.cc').write_text(original.replace(needle, replacement), encoding='utf8')
driver = (SOURCE / 'driver.cc').read_text(encoding='utf8')
guard = '''    if (!enabled("HYLE_BENCH_VERIFY_ONLY") && aa.empty() && enabled("HYLE_PERF_RUN_NONCE")) {'''
assert driver.count(guard) == 1
driver = driver.replace(guard, '''    // R29 has no product-ranking or qualification claim.
    if (!enabled("G09_NATIVE_WAIT_DIAGNOSTIC") && !enabled("HYLE_BENCH_VERIFY_ONLY") && aa.empty() && enabled("HYLE_PERF_RUN_NONCE")) {''')
driver = driver.replace('g09_pipeline_aa.ready', 'g09_pipeline_aa.ready')
(SOURCE / 'driver.cc').write_text(driver, encoding='utf8')
(SOURCE / 'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g09_native_wait_diagnostic LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_INTERPROCEDURAL_OPTIMIZATION OFF)
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
if(NOT Hyle_STATIC OR NOT WIN32)
  message(FATAL_ERROR "Only the previously qualified static Windows SDK")
endif()
add_library(g09_wait_invocation OBJECT invocation.cc)
target_link_libraries(g09_wait_invocation PRIVATE hyle::graph)
target_include_directories(g09_wait_invocation PRIVATE "C:/public/project-hyle/hyle/src/graph_route_cpu_vulkan")
foreach(copy RANGE 1 2)
  set(target g09_native_wait_${copy})
  add_library(${target} SHARED facade.cc $<TARGET_OBJECTS:g09_wait_invocation>)
  target_compile_definitions(${target} PRIVATE G09_VULKAN=1 "G09_IMAGE_TAG=\\"native-wait-${copy}\\"")
  target_include_directories(${target} PRIVATE "C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include")
  target_link_libraries(${target} PRIVATE hyle::compute hyle::graph)
  target_link_options(${target} PRIVATE /INCREMENTAL:NO "/MAP:${CMAKE_BINARY_DIR}/${target}.map")
endforeach()
add_library(g09_original_nanobench STATIC IMPORTED)
set_target_properties(g09_original_nanobench PROPERTIES IMPORTED_LOCATION "C:/h7/g09-p1-instrument/vulkan/qualified-build-obs-free-1/g09_nanobench.lib")
add_executable(g09_native_wait_driver wrapper.cc)
target_include_directories(g09_native_wait_driver PRIVATE
 "C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-p1-instrument-adapter/instrument/third_party/nanobench"
 "C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-p1-instrument-adapter/instrument/bench/common")
target_compile_definitions(g09_native_wait_driver PRIVATE "G09_ROUTE_NAME=\\"vulkan-native-wait-diagnostic\\""
 "G09_CANDIDATE_1=\\"C:/h7/g09-native-wait-29/bin/g09_native_wait_1.dll\\""
 "G09_CANDIDATE_2=\\"C:/h7/g09-native-wait-29/bin/g09_native_wait_2.dll\\""
 "G09_BASELINE_1=\\"C:/h7/g09-completion-observation-25/bin/g09_observed_1.dll\\""
 "G09_BASELINE_2=\\"C:/h7/g09-completion-observation-25/bin/g09_observed_2.dll\\"")
target_link_libraries(g09_native_wait_driver PRIVATE g09_original_nanobench)
''', encoding='utf8')
manifest = dict(scope='R29 single-prefix native-wait diagnostic, never a product candidate',
                product_candidate='3524413272cb52d06af5e64d634edbfef09b9864',
                old_source=str(OLD), source=str(SOURCE), build=str(BUILD),
                sources=[dict(path=p.name, sha256=sha(p)) for p in sorted(SOURCE.iterdir())],
                original_sources=[dict(path=str(p), sha256=sha(p)) for p in sorted(OLD.iterdir()) if p.is_file()])
(OUT / 'source-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf8')
print(json.dumps(dict(source=str(SOURCE), build=str(BUILD), files=len(manifest['sources']))))
