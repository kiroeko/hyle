"""Four frozen nonranking cause-intervention processes; never formal P1/A/A."""
from pathlib import Path
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
import time

ROOT = Path('C:/public/project-hyle/hyle')
OUT = ROOT / '.scratch/inference-gaps/g09-native-wait-29'
RUN = OUT / 'run'
BUILD = Path('C:/h7/g09-native-wait-29')
OLD = Path('C:/h7/g09-completion-observation-25/bin')
EVIDENCE = ROOT / 'evidence/architecture/inference-performance-recovery-2026-10-17'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0, 'C:/h7/g09-p1-peer-9e2/scripts')
from hyle_perf import evaluate_machine_profile, expected_child_policy, get_machine_profile, load_registry, probe_machine
from hyle_perf.runner import _apply_sampling_policy, _child_environment, _creation_flags, _probe_child_policy

assert not RUN.exists(), 'Do not replace or repeat a measurement attempt'
manifest = json.loads((OUT/'source-manifest.json').read_text(encoding='utf8'))
build = json.loads((OUT/'build-reviewed-result.json').read_text(encoding='utf8'))
assert build['state'] == 'BUILT_NOT_RUN' and build['compile_units'] == 4
files = [dict(path=str(OUT/'source'/r['path']), sha256=r['sha256']) for r in manifest['sources']]
files += [dict(path=r['path'], sha256=r['sha256']) for r in build['artifacts']+build['runtime']]
files += [dict(path=str(OLD/name), sha256=sha(OLD/name)) for name in ['g09_observed_1.dll','g09_observed_2.dll']]
files += [dict(path=str(EVIDENCE/'g09-native-wait-review.json'), sha256=sha(EVIDENCE/'g09-native-wait-review.json'))]
files += [dict(path=str(Path(__file__).resolve()), sha256=sha(Path(__file__).resolve()))]
files += [dict(path=str(p), sha256=sha(p)) for p in [OUT/'source-manifest.json', OUT/'build-reviewed-result.json',
    Path('C:/h7/g09-p1-peer-9e2/scripts/hyle_perf/runner.py'),
    Path('C:/h7/g09-p1-peer-9e2/scripts/hyle_perf/machine.py'),
    Path('C:/h7/g09-p1-peer-9e2/scripts/perf-machines.json')]]
for item in files:
    assert sha(Path(item['path'])) == item['sha256'], item['path']
assert not any('INJECTION' in k.upper() and v for k,v in os.environ.items()), 'Unexpected profiler injection'
host = probe_machine(paths=[('build',BUILD)])
profile = get_machine_profile(load_registry(), 'W1-WIN')
gate = evaluate_machine_profile(profile, host, role='engineering', sampling_topology='native-runtime-pair')
assert gate['gate'] == 'PASS', gate
policy = expected_child_policy(profile, sampling_topology='native-runtime-pair', probe=host)
assert policy['caller_logical_cpu'] == 2
authorization_path = OUT/'launch-authorization.json'
if '--seal-only' in sys.argv:
    assert not authorization_path.exists()
    authorization_path.write_text(json.dumps(dict(decision='ALLOW_FOUR_FROZEN_NONRANKING_NATIVE_WAIT_DIAGNOSTICS',
        files=files, policy=policy, orders=[[0,0],[1,0],[0,1],[1,1]],
        original_failures_retained=True, product_fix_authorized=False),indent=2)+'\n',encoding='utf8')
    print('SEALED_NOT_RUN',authorization_path)
    sys.exit(0)
assert '--execute' in sys.argv, 'Use --seal-only or --execute'
authorization=json.loads(authorization_path.read_text(encoding='utf8'))
assert authorization['decision']=='ALLOW_FOUR_FROZEN_NONRANKING_NATIVE_WAIT_DIAGNOSTICS'
assert authorization['files']==files and authorization['policy']==policy
RUN.mkdir()
started = time.monotonic()
result = dict(state='PREPARED_NOT_RUN', qualification='DIAGNOSTIC_ONLY', valid_formal_ab=0,
              product_changes=0, processes=[], files=files, host=gate, policy=policy,
              factor_orders=[[0,0],[1,0],[0,1],[1,1]],
              only_intervention='Single pending/no ready native prefix: unlock and call original Completion.wait; all original math/results/drain retained.')
def save():
    result['elapsed_seconds'] = time.monotonic()-started
    (RUN/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')

save()
try:
    with _apply_sampling_policy(policy) as applied:
        result['applied_policy'] = applied
        result['child_canary'] = _probe_child_policy(policy, _creation_flags(policy))
        for index,(rival_first,allocation_first) in enumerate(result['factor_orders']):
            for item in files:
                assert sha(Path(item['path'])) == item['sha256'], item['path']
            nonce = secrets.token_hex(16)
            controlled = ['HYLE_BENCH_AA_ROUTE','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_APPLE_QOS','G09_NATIVE_WAIT_DIAGNOSTIC']
            env = _child_environment(controlled, dict(HYLE_BENCH_AA_ROUTE='',HYLE_BENCH_VERIFY_ONLY='0',
                HYLE_BENCH_RIVAL_FIRST=str(rival_first),HYLE_BENCH_PEER_ALLOCATION_FIRST=str(allocation_first),
                HYLE_PERF_RUN_NONCE=nonce,G09_NATIVE_WAIT_DIAGNOSTIC='1'), profile, policy)
            env['DISABLE_VULKAN_OBS_CAPTURE'] = '1'
            command = [str(BUILD/'bin/g09_native_wait_driver.exe'),
                       str(BUILD/'bin/g09_native_wait_1.dll'),str(OLD/'g09_observed_1.dll'),
                       str(BUILD/'bin/g09_native_wait_2.dll'),str(OLD/'g09_observed_2.dll')]
            path = RUN/f'order-{index}.log'
            entry = dict(index=index,rival_first=rival_first,allocation_first=allocation_first,nonce=nonce,command=command,log=str(path))
            result['processes'].append(entry)
            child = None
            stamp = time.monotonic()
            try:
                with path.open('wb') as output:
                    child = subprocess.Popen(command,cwd=BUILD/'bin',env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=_creation_flags(policy))
                    entry['pid'] = child.pid
                    result['state'] = 'RUNNING';save()
                    print('RUNNING',index,child.pid,flush=True)
                    while True:
                        try:
                            code=child.wait(timeout=60);break
                        except subprocess.TimeoutExpired:
                            entry.setdefault('same_pid_extensions_seconds',[]).append(60);save()
            finally:
                if child is not None and child.poll() is None:
                    child.terminate();child.wait()
                    entry['owned_child_terminated_on_launcher_error']=True
            entry.update(exit_code=code,elapsed_seconds=time.monotonic()-stamp,sha256=sha(path))
            text = path.read_text(encoding='utf8',errors='replace').replace('\x00','').replace('\r\n','\n')
            assert code == 0 and '# G09_OBSERVATION_PROCESS_EXIT code=0' in text
            fields = lambda line: dict(re.findall(r'(\w+)=([^\s]*)',line))
            actual = re.findall(r'^# G09_OBSERVATION_ACTUAL_POLICY .*$',text,re.M)
            assert len(actual)==1
            actual = fields(actual[0])
            assert actual['pid']==str(child.pid) and actual['nonce']==nonce
            assert actual['mask']=='0x14' and actual['priority']=='32768'
            instrument = re.findall(r'^# HYLE_G09_INSTRUMENT_RUN .*$',text,re.M)
            assert len(instrument)==1
            instrument = fields(instrument[0])
            assert instrument['run_nonce']==nonce and instrument['caller_cpu']=='2'
            assert instrument['affinity_ok']=='1' and instrument['affinity_topology']=='native-runtime-pair'
            assert instrument['execution_order']==('peer-first' if rival_first else 'candidate-first')
            assert instrument['allocation_order']==('peer-first' if allocation_first else 'candidate-first')
            headers=re.findall(r'^# HYLE_G09_RUN .*$',text,re.M)
            assert len(headers)==1 and fields(headers[0])['aa_route']==''
            images=re.findall(r'^# G09_IMAGE path=(\S+) tag=(\S+) ',text,re.M)
            assert len(images)==2 and {tag for _,tag in images}=={'native-wait-1','candidate-1'}
            assert {Path(p).resolve() for p,_ in images}=={Path(command[1]).resolve(),Path(command[2]).resolve()}
            assert text.count('before=PASS full_elements=4194304') == 4
            assert text.count('after=PASS full_elements=4194304') == 4
            assert len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M)) == 8
            blocks = re.findall(r'^# G09_OBSERVATION tag=(\S+) count=(\d+) capacity=65536 overflow=(\d+) clock=QPC-ns$',text,re.M)
            assert len(blocks)==8 and all(x[2]=='0' for x in blocks)
            chunks=text.split('# G09_OBSERVATION tag=')[1:]
            for block_index,chunk in enumerate(chunks):
                tag,count,_=blocks[block_index]
                records=re.findall(r'^# G09_RECORD tag=(\S+) ns=(\d+) kind=(\d+) run=(\d+) token=(\d+) value=(\d+) thread=(\d+)$',chunk,re.M)
                assert len(records)==int(count) and all(r[0]==tag for r in records)
                waits=[r for r in records if r[2] in ('50','51','52')]
                if tag=='candidate-1' or block_index>=4:
                    assert not waits, 'Control or shape2/3 changed observation path'
                else:
                    assert waits and sum(r[2]=='50' for r in waits)==sum(r[2]=='51' for r in waits)==sum(r[2]=='52' for r in waits)
                    assert all(r[5]=='0' for r in waits if r[2]=='51')
                    assert all(int(r[5])&0xffffffff==1 for r in waits if r[2]=='52')
                    sequences={}
                    for row in waits:
                        key=(row[3],row[4],row[6])
                        sequences.setdefault(key,[]).append(row[2])
                    assert all(seq==['52','50','51']*(len(seq)//3) for seq in sequences.values())
            assert len(re.findall(r'^# G09_MEASUREMENT .*actual_paired_rounds=12',text,re.M)) == 4
            module_lines='\n'.join(x for x in text.splitlines() if x.startswith('# G09_MODULE '))
            assert not re.search(r'graphics-hook|ToolsInjection64|nsight',module_lines,re.I)
            guards = re.findall(r'^# G09_RECORD tag=native-wait-\d+ .* kind=52 .* value=(\d+) ',text,re.M)
            assert guards and all(int(v)&0xffffffff==1 for v in guards)
            assert not re.search(r'^# G09_RECORD tag=candidate-\d+ .* kind=5[012] ',text,re.M)
            assert re.search(r'aa_route=\s*\n',text)
            entry.update(oracle_before=4,oracle_after=4,state_destroy=8,record_blocks=8,
                         single_pending_guard_records=len(guards),validation='PASS')
            save()
            print('PASS',index,round(entry['elapsed_seconds'],3),flush=True)
        result['state']='COMPLETE_NONRANKING_CAUSAL_DIAGNOSTIC'
        save()
except BaseException as error:
    result.update(state='DIAGNOSTIC_FAILED_STOPPED',error=repr(error));save();raise
