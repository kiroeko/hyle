from pathlib import Path
import ctypes, hashlib, json, os, re, subprocess, sys, time, zipfile

mode, label = sys.argv[1:3]
assert mode in ['static', 'shared', 'source'] and label.isdigit()
win, air = sys.platform == 'win32', sys.platform == 'darwin'
if win:
    canonical = source = Path('C:/public/project-hyle/hyle')
    inputs = source / '.scratch/inference-gaps/g10-delivery-inputs'
    base = Path('C:/h7')
    family = base / 'w-cpu-cuda/selected-graph'
    producer = {'static': source / '.scratch/build-compute-v2-dev', 'shared': base / 'w-vulkan/selected-graph/shared-sdk-build', 'source': family / 'source-build'}[mode]
    folder = base / 'g10-sdk' / (mode + '-' + label)
    out = source / '.scratch/inference-gaps/g10-sdk-windows' / (mode + '-' + label)
    setup = subprocess.check_output(['cmd', '/d', '/c', str(source / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], encoding='utf8', errors='replace')
    env = {k.upper(): v for k, v in os.environ.items()}
    env.update((k.upper(), v) for k, v in (x.split('=', 1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
    env['VSLANG'] = '1033'
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    handle = kernel.GetCurrentProcess()
    kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
    kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    available, system = ctypes.c_size_t(), ctypes.c_size_t()
    assert kernel.GetProcessAffinityMask(handle, ctypes.byref(available), ctypes.byref(system))
    mask = sum([1 << i for i in range(64) if available.value & (1 << i)][:4])
    assert kernel.SetProcessAffinityMask(handle, mask)
    kernel.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    resource = dict(affinity_mask=hex(mask), priority='BelowNormal', logical_cpu_limit=4)
    cmake, ninja = 'cmake', 'ninja'
else:
    base = Path('/Users/kiro/hyle-scratch/compute-unified' if air else '/root/hyle-scratch/compute-unified')
    source = base / ('source-c8874688' if air else 'source-7a7b4c3b')
    inputs = base / 'g10-delivery-inputs'
    family = base / ('a-cpu/selected-graph' if air else 'l-cpu/selected-graph')
    producer = family / ('source-build' if mode == 'source' else mode + '-sdk-build')
    if not air and mode != 'source':
        producer = base / 'l-cpu-cuda/selected-graph' / (mode + '-sdk-build')
    folder = base / 'g10-sdk' / (mode + '-' + label)
    out = folder / 'evidence'
    env = dict(os.environ)
    env['PATH'] = ('/opt/homebrew/bin:' if air else '') + env.get('PATH', '')
    os.nice(10)
    resource = dict(nice=os.nice(0), logical_cpu_limit='macOS no supported hard affinity' if air else 4)
    if not air:
        os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:4])
        resource['logical_cpus'] = sorted(os.sched_getaffinity(0))
    cmake, ninja = ('/opt/homebrew/bin/cmake', '/opt/homebrew/bin/ninja') if air else ('cmake', 'ninja')

folder.mkdir(parents=True, exist_ok=False)
out.mkdir(parents=True, exist_ok=False)
started = time.monotonic()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((inputs / 'inputs.json').read_text())
env.update(OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
r = dict(state='SETUP', pid=os.getpid(), mode=mode, stages=[], source=str(source), producer=str(producer),
         source_snapshot={k: manifest[k] for k in ['head', 'tree', 'archive_sha256']}, resource=resource, jobs=4,
         scope='G10 CPU-only public thread startup and actual Graph/executor math via source embedding or independently relocated shipping SDK; private vendor state fixture identified separately. No GPU/P1/all-operator claim.')
parent_file = original_parent = None

def save():
    r['elapsed_seconds'] = time.monotonic() - started
    (out / 'result.json').write_text(json.dumps(r, indent=2) + '\n', encoding='utf8')

def changed(p, data):
    if isinstance(data, str): data = data.encode()
    if not p.is_file() or p.read_bytes() != data:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

def run(stage, args, accepted=(0,)):
    stamp = time.monotonic()
    r.update(state='RUNNING', stage=stage)
    save()
    print(mode, stage, flush=True)
    with (out / (stage + '.log')).open('wb') as log:
        flags = subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS if win else 0
        p = subprocess.Popen([str(x) for x in args], env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
        r['child_pid'] = p.pid
        save()
        while True:
            try:
                code = p.wait(timeout=1800)
                break
            except subprocess.TimeoutExpired:
                r.setdefault('time_extensions', []).append(dict(stage=stage, pid=p.pid, seconds=1800))
                save()
    r.pop('child_pid', None)
    r['stages'].append(dict(stage=stage, argv=[str(x) for x in args], exit=code, seconds=time.monotonic() - stamp))
    save()
    if code not in accepted:
        print((out / (stage + '.log')).read_text(encoding='utf8', errors='replace')[-12000:], flush=True)
        raise RuntimeError(stage + ' exited ' + str(code))
    return code

def build_targets(build, targets, stage):
    run(stage + '-manifest', [ninja, '-C', build, 'build.ninja'])
    preview = out / (stage + '.ninja')
    preview.write_bytes((build / 'build.ninja').read_bytes())
    run(stage + '-dry', [ninja, '-C', build, '-f', preview, '-n', *targets])
    dry = (out / (stage + '-dry.log')).read_text(encoding='utf8', errors='replace')
    assert 'Building CUDA object' not in dry and 'vulkan-shaders' not in dry and 'Re-running CMake' not in dry, 'Unexpected GPU or manifest work; retained dry-run'
    assert len(dry.splitlines()) < 450, 'Unexpected broad rebuild; retained dry-run'
    r[stage + '_edges'] = len(dry.splitlines())
    commands = json.loads(subprocess.check_output([ninja, '-C', str(build), '-t', 'compdb'], env=env, text=True, encoding='utf8', errors='replace'))
    shipping = [x for x in commands if x.get('file', '').replace('\\', '/').startswith(source.as_posix() + '/src/')]
    if build == producer:
        assert shipping and all('HYLE_TESTING' not in x['command'] and 'HYLE_SIMD_INTERNAL_TESTING' not in x['command'] and '-fsanitize=' not in x['command'] for x in shipping)
    (out / (stage + '-commands.json')).write_text(json.dumps(commands, indent=2) + '\n', encoding='utf8')
    run(stage, [ninja, '-C', build, '-f', preview, '-j', '4', *targets])

try:
    if win:
        r['identity'] = dict(host=env.get('COMPUTERNAME'), compiler=env.get('VCTOOLSVERSION'), os=subprocess.check_output(['cmd', '/d', '/c', 'ver'], text=True).strip())
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == manifest['head']
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True).strip()
    else:
        cmds = {'model': ['sysctl', '-n', 'hw.model'], 'system': ['sw_vers'], 'compiler': ['xcrun', 'clang++', '--version']} if air else {'host': ['uname', '-a'], 'compiler': ['g++-14', '--version']}
        r['identity'] = {k: subprocess.check_output(v, env=env, text=True).strip() for k, v in cmds.items()}
        if air: assert r['identity']['model'] == 'Mac16,12'
        assert sha(inputs / 'source.zip') == manifest['archive_sha256']
        sync = []
        with zipfile.ZipFile(inputs / 'source.zip') as z:
            for item in manifest['files']:
                rel = Path(item['path'])
                assert not rel.is_absolute() and '..' not in rel.parts
                data = z.read(item['path'])
                assert hashlib.sha256(data).hexdigest() == item['sha256']
                p = source / rel
                assert p.resolve().is_relative_to(source.resolve())
                if not p.is_file() or p.read_bytes() != data:
                    changed(p, data)
                    sync.append(item['path'])
        r['synced_paths'] = sync
    owners = json.loads((source / 'docs/implementation/module-status.json').read_text())['modules']
    assert all(x['state'] == 'AUDITED' for x in owners if x['module'] in ['compute_route_cpu', 'compute_provider_native'])
    for item in manifest['fixtures']: assert sha(inputs / item['path']) == item['sha256']
    (out / 'runner.py').write_bytes(Path(__file__).read_bytes())
    effective_static = mode == 'static' or (mode == 'source' and 'HYLE_STATIC:BOOL=ON\n' in (producer / 'CMakeCache.txt').read_text())
    r['effective_static'] = effective_static
    args = ['-DHYLE_BUILD_TESTS=OFF', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_TEST_INSTRUMENTATION=OFF',
            '-DHYLE_COMPONENTS=compute;graph;sched', '-DHYLE_COMPUTE_ROUTES=cpu', '-DHYLE_SANITIZER=off',
            '-DHYLE_STATIC=' + ('ON' if effective_static else 'OFF'),
            '-DCMAKE_PROJECT_INCLUDE=' + (inputs / 'g10_apps.cmake').as_posix()]
    if not win and not air: args += ['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14']
    producer_targets = ['hyle_compute', 'hyle_compute_ops', 'hyle_compute_batch', 'hyle_compute_state', 'hyle_compute_stream',
                        'hyle_graph', 'hyle_graph_batch', 'hyle_compute_route_cpu', 'hyle_graph_route_cpu', 'hyle_sched', 'g10_vendor']
    if mode != 'source':
        run('producer-configure', [cmake, '-S', source, '-B', producer, '-DHYLE_INSTALL=ON', *args])
        build_targets(producer, producer_targets, 'producer-build')
        staging, prefix = folder / 'staging', folder / 'relocated'
        run('install', [cmake, '--install', producer, '--prefix', staging])
        assert staging.resolve().parent == folder.resolve() and prefix.resolve().parent == folder.resolve()
        staging.rename(prefix)
        for header in ['compute/cpu.h', 'graph/cpu.h']:
            assert sha(prefix / 'include/hyle' / header) == sha(source / 'include/hyle' / header), header
        consumer = folder / 'consumer'
        build = folder / 'consumer-build'
        body = 'cmake_minimum_required(VERSION 3.25)\nproject(g10_public_delivery LANGUAGES CXX)\nfind_package(Hyle CONFIG REQUIRED COMPONENTS compute graph sched)\n'
    else:
        prefix = None
        consumer, build = family / 'source-parent', producer
        parent_file = consumer / 'CMakeLists.txt'
        assert parent_file.is_file()
        original_parent = parent_file.read_bytes()
        (out / 'original-parent.cmake').write_bytes(original_parent)
        body = 'cmake_minimum_required(VERSION 3.25)\nproject(g10_public_delivery LANGUAGES CXX)\nadd_subdirectory("' + source.as_posix() + '" hyle)\n'
    consumer.mkdir(parents=True, exist_ok=True)
    for name in ['thread_runtime_consumer.cc', 'cpu_executor.cc', 'graph_runtime.cc']:
        changed(consumer / name, (inputs / name).read_bytes())
    for i, header in enumerate(['compute/cpu.h', 'graph/cpu.h']): changed(consumer / ('header-' + str(i) + '.cc'), '#include <hyle/' + header + '>\n')
    body += '''add_executable(g10_runtime thread_runtime_consumer.cc)
target_compile_features(g10_runtime PRIVATE cxx_std_23)
target_link_libraries(g10_runtime PRIVATE hyle::compute)
hyle_stage_runtime(g10_runtime)
add_executable(g10_graph graph_runtime.cc)
target_compile_features(g10_graph PRIVATE cxx_std_23)
target_link_libraries(g10_graph PRIVATE hyle::compute hyle::graph hyle::sched)
hyle_stage_runtime(g10_graph)
add_library(g10_headers OBJECT header-0.cc header-1.cc)
target_compile_features(g10_headers PRIVATE cxx_std_23)
target_link_libraries(g10_headers PRIVATE hyle::compute hyle::graph)
'''
    changed(consumer / 'CMakeLists.txt', body)
    (out / 'consumer.cmake').write_text(body, encoding='utf8')
    configure = [cmake, '-S', consumer, '-B', build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    configure += ['-DCMAKE_PREFIX_PATH=' + prefix.as_posix()] if prefix else ['-DHYLE_INSTALL=OFF', *args]
    if not win and not air: configure += ['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14']
    run('consumer-configure', configure)
    build_targets(build, ['g10_runtime', 'g10_graph', 'g10_headers'] + (['g10_vendor'] if mode == 'source' else []), 'consumer-build')
    commands = json.loads((build / 'compile_commands.json').read_text())
    selected = [x for x in commands if Path(x['file']).resolve().is_relative_to(consumer.resolve()) and Path(x['file']).name in ['thread_runtime_consumer.cc', 'graph_runtime.cc', 'header-0.cc', 'header-1.cc']]
    assert len(selected) == 4, len(selected)
    for item in selected:
        cmd = item['command'].replace('\\', '/')
        assert (source / 'src').as_posix() not in cmd and 'HYLE_TESTING' not in cmd and '-fsanitize=' not in cmd
        if prefix: assert source.as_posix() not in cmd and producer.as_posix() not in cmd and (prefix / 'include').as_posix() in cmd
    (out / 'public-commands.json').write_text(json.dumps(selected, indent=2) + '\n', encoding='utf8')
    suffix = '.exe' if win else ''
    def binary(tree, name):
        matches = [p for p in [tree / (name + suffix), tree / 'bin' / (name + suffix), tree / 'hyle' / (name + suffix), tree / 'hyle/bin' / (name + suffix)] if p.is_file()]
        assert len(matches) == 1, matches
        return matches[0]
    public, graph = binary(build, 'g10_runtime'), binary(build, 'g10_graph')
    vendor = binary(producer, 'g10_vendor')
    if win:
        cache = (build / 'CMakeCache.txt').read_text()
        compiler = Path(next(x.split('=', 1)[1] for x in cache.splitlines() if x.startswith('CMAKE_CXX_COMPILER:')))
        dumpbin = compiler.with_name('dumpbin.exe')
        needed, todo = {}, [public, graph]
        while todo:
            p = todo.pop()
            if p.name.lower() in needed: continue
            needed[p.name.lower()] = p
            deps = subprocess.check_output([str(dumpbin), '/nologo', '/dependents', str(p)], env=env, text=True, encoding='utf8', errors='replace')
            (out / ('deps-' + p.name + '.log')).write_text(deps, encoding='utf8')
            for dll in re.findall(r'^\s+(hyle_[^\s]+\.dll)\s*$', deps, re.M | re.I):
                staged = public.parent / dll
                assert staged.is_file(), dll
                if prefix:
                    originals = [x for x in prefix.rglob(dll) if x.is_file()]
                    assert len(originals) == 1 and sha(staged) == sha(originals[0]), dll
                    r.setdefault('staged_hyle_runtime', []).append(dict(path=str(staged), original=str(originals[0]), sha256=sha(staged)))
                todo.append(staged)
    elif not air:
        for p in [public, graph]:
            deps = subprocess.check_output(['ldd', str(p)], env=env, text=True)
            assert 'not found' not in deps, deps
            (out / ('deps-' + p.name + '.log')).write_text(deps, encoding='utf8')
            if prefix:
                for line in deps.splitlines():
                    if 'libhyle_' in line:
                        resolved = line.split('=>', 1)[1].strip().split(' ', 1)[0]
                        assert Path(resolved).resolve().is_relative_to(prefix.resolve()), line
    else:
        for p in [public, graph]:
            (out / ('deps-' + p.name + '.log')).write_text(subprocess.check_output(['otool', '-L', str(p)], text=True), encoding='utf8')
    # SDK execution uses staged/installed runtime; canonical/producer PATH entries are removed.
    if prefix:
        separator = ';' if win else ':'
        env['PATH'] = separator.join(x for x in env['PATH'].split(separator) if x and not Path(x).resolve().is_relative_to(source.resolve()) and not Path(x).resolve().is_relative_to(producer.resolve()))
    for scenario in ['startup', 'query-first', 'late-native', 'late-aten', 'race-use', 'race-config', 'metadata-oom']:
        run('public-' + scenario, [public, '--' + scenario])
    run('public-graph-executor', [graph])
    run('private-foreign', [vendor, '--foreign'])
    run('private-qualified-drift', [vendor, '--qualified-drift'], accepted=(0, 77))
    r['binaries'] = [dict(path=str(p), sha256=sha(p)) for p in [public, graph, vendor]]
    r['public_headers'] = [dict(path=h, sha256=sha((prefix / 'include/hyle' if prefix else source / 'include/hyle') / h)) for h in ['compute/cpu.h', 'graph/cpu.h']]
    for item in manifest['files']: assert sha(source / item['path']) == item['sha256'], item['path']
    r['state'] = 'CPU_SOURCE_PUBLIC_RUNTIME_GRAPH_HEADERS_PASS' if mode == 'source' else 'CPU_RELOCATED_SDK_PUBLIC_RUNTIME_GRAPH_HEADERS_PASS'
    save()
    print(r['state'], r['elapsed_seconds'], flush=True)
except BaseException as error:
    r.update(state='FAIL', error=repr(error))
    save()
    raise
finally:
    if parent_file is not None and original_parent is not None:
        parent_file.write_bytes(original_parent)
        r['original_parent_restored'] = sha(parent_file) == hashlib.sha256(original_parent).hexdigest()
        save()
