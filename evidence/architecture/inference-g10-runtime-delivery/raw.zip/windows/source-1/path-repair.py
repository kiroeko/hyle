from pathlib import Path
import ctypes, hashlib, json, os, subprocess, time

root = Path('C:/public/project-hyle/hyle')
out = root / '.scratch/inference-gaps/g10-sdk-windows/source-1'
inputs = root / '.scratch/inference-gaps/g10-delivery-inputs'
build = Path('C:/h7/w-cpu-cuda/selected-graph/source-build')
consumer = build.parent / 'source-parent'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r = json.loads((out / 'result.json').read_text())
assert r['state'] == 'FAIL' and r['error'] == 'AssertionError([])'
assert any(x['stage'] == 'consumer-build' and x['exit'] == 0 for x in r['stages'])
assert r['original_parent_restored']
assert (build / 'build.ninja').read_bytes() == (out / 'consumer-build.ninja').read_bytes()
manifest = json.loads((inputs / 'inputs.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == manifest['head']
for item in manifest['files']: assert sha(root / item['path']) == item['sha256'], item['path']
for name in ['thread_runtime_consumer.cc', 'cpu_executor.cc', 'graph_runtime.cc']:
    assert sha(consumer / name) == sha(inputs / name), name
commands = json.loads((out / 'public-commands.json').read_text())
assert len(commands) == 4 and all('HYLE_TESTING' not in x['command'] and '-fsanitize=' not in x['command'] for x in commands)
public, graph, vendor = build / 'g10_runtime.exe', build / 'g10_graph.exe', build / 'hyle/g10_vendor.exe'
assert all(p.is_file() for p in [public, graph, vendor])
(out / 'retained-source-path-error.json').write_bytes((out / 'result.json').read_bytes())
(out / 'retained-source-path-runner.py').write_bytes((out / 'runner.py').read_bytes())
(out / 'path-repair.py').write_bytes(Path(__file__).read_bytes())
started = time.monotonic() - r['elapsed_seconds']
r.update(state='RESUMING_COMPLETED_ARTIFACTS', retained_failure='retained-source-path-error.json',
    path_correction='Source embedding puts the deferred private fixture at hyle/g10_vendor.exe, not bin or hyle/bin. Original manifest, complete product inputs, public commands and copied fixtures rechecked; no configure/build/source mutation or time reset.',
    completed_build_manifest_sha256=sha(build / 'build.ninja'))
setup = subprocess.check_output(['cmd', '/d', '/c', str(root / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], encoding='utf8', errors='replace')
env = {k.upper(): v for k, v in os.environ.items()}
env.update((k.upper(), v) for k, v in (x.split('=', 1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
env.update(VSLANG='1033', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
kernel = ctypes.windll.kernel32
kernel.GetCurrentProcess.restype = ctypes.c_void_p
kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
available, system = ctypes.c_size_t(), ctypes.c_size_t()
handle = kernel.GetCurrentProcess()
assert kernel.GetProcessAffinityMask(handle, ctypes.byref(available), ctypes.byref(system))
mask = sum([1 << i for i in range(64) if available.value & (1 << i)][:4])
assert kernel.SetProcessAffinityMask(handle, mask)
kernel.SetErrorMode(0x0001 | 0x0002 | 0x8000)

def save():
    r['elapsed_seconds'] = time.monotonic() - started
    (out / 'result.json').write_text(json.dumps(r, indent=2) + '\n', encoding='utf8')

try:
    for name, args in [(x, [public, '--' + x]) for x in ['startup', 'query-first', 'late-native', 'late-aten', 'race-use', 'race-config', 'metadata-oom']] + [
        ('graph-executor', [graph]), ('foreign', [vendor, '--foreign']), ('qualified-drift', [vendor, '--qualified-drift'])]:
        r.update(state='RUNNING', stage='path-repair-' + name)
        save()
        stamp = time.monotonic()
        print(name, flush=True)
        with (out / ('path-repair-' + name + '.log')).open('wb') as log:
            p = subprocess.Popen([str(x) for x in args], env=env, stdout=log, stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            r['child_pid'] = p.pid
            save()
            code = p.wait()
        r.pop('child_pid', None)
        r['stages'].append(dict(stage='path-repair-' + name, argv=[str(x) for x in args], exit=code, seconds=time.monotonic() - stamp))
        assert code == 0, (name, code)
    assert (build / 'build.ninja').read_bytes() == (out / 'consumer-build.ninja').read_bytes()
    for item in manifest['files']: assert sha(root / item['path']) == item['sha256'], item['path']
    r['binaries'] = [dict(path=str(p), sha256=sha(p)) for p in [public, graph, vendor]]
    r['public_headers'] = [dict(path=h, sha256=sha(root / 'include/hyle' / h)) for h in ['compute/cpu.h', 'graph/cpu.h']]
    r['state'] = 'CPU_SOURCE_PUBLIC_RUNTIME_GRAPH_HEADERS_PASS'
    save()
    print(r['state'], r['elapsed_seconds'])
except BaseException as error:
    r.update(state='FAIL', error=repr(error))
    save()
    raise
