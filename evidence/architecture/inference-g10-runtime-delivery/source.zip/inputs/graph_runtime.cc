#include <hyle/compute/cpu.h>
#include <cstdio>
#define main g10_original_consumer_main
#include "cpu_executor.cc"
#undef main
int main() {
  namespace cpu = hyle::compute::cpu;
  const auto configured = cpu::configure_runtime_threads(2);
  if (!configured.ok()) { std::fprintf(stderr, "G10 startup: %.*s\n", int(configured.message().size()), configured.message().data()); return 1; }
  const auto result = g10_original_consumer_main();
  if (result) return result;
  const auto info = cpu::runtime_thread_info();
  if (!info || info->configuration_open || !info->usage_started ||
      info->configured_intra_op_threads != 2 || info->intra_op_limit != 2 ||
      !cpu::configure_runtime_threads(1).IsFailedPrecondition()) {
    std::fputs("G10 consumer did not preserve the shared startup limit\n", stderr); return 1;
  }
  std::puts("G10 startup + original public math/lifecycle/executor consumer PASS");
  return 0;
}
