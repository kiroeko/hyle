from pathlib import Path
import hashlib, json, shlex, subprocess, sys, zipfile

root=Path('C:/public/project-hyle/hyle')
script='''from pathlib import Path
import sys,zipfile
base=Path(BASE)
with zipfile.ZipFile(sys.stdout.buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for mode in ['static','shared','source']:
  folder=base/(mode+'-1')/'evidence'
  assert folder.is_dir(),folder
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,mode+'-1/'+p.relative_to(folder).as_posix())
'''
for host,base in [('air','/Users/kiro/hyle-scratch/compute-unified/g10-sdk'),('wsl','/root/hyle-scratch/compute-unified/g10-sdk')]:
 out=root/'.scratch/inference-gaps'/('g10-sdk-'+host)
 out.mkdir(exist_ok=True)
 archive=out/'raw.zip'
 assert not archive.exists(),archive
 code=script.replace('BASE',repr(base))
 args=['ssh','kiro@172.22.10.198','python3','-c',shlex.quote(code)] if host=='air' else ['wsl','-d','Ubuntu-24.04','--','python3','-c',code]
 with archive.open('xb') as stream:
  result=subprocess.run(args,stdout=stream,stderr=subprocess.PIPE)
 assert result.returncode==0,result.stderr.decode(errors='replace')
 with zipfile.ZipFile(archive) as z:
  for item in z.infolist():
   path=Path(item.filename)
   assert not path.is_absolute() and '..' not in path.parts
  z.extractall(out/'collected')
 rows=[]
 for mode in ['static','shared','source']:
  d=json.loads((out/'collected'/(mode+'-1')/'result.json').read_text())
  assert d['state'] in ['CPU_RELOCATED_SDK_PUBLIC_RUNTIME_GRAPH_HEADERS_PASS','CPU_SOURCE_PUBLIC_RUNTIME_GRAPH_HEADERS_PASS'],d
  rows.append(dict(mode=mode,state=d['state'],seconds=d['elapsed_seconds']))
 print(json.dumps(dict(host=host,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),rows=rows)),flush=True)
