from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path('C:/public/project-hyle/hyle')
inputs=root/'.scratch/inference-gaps/g10-delivery-inputs'
out=root/'evidence/architecture/inference-g10-runtime-delivery'
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((inputs/'inputs.json').read_text())
rows=[]
rawfiles=[]
for host,folder in [('windows',root/'.scratch/inference-gaps/g10-sdk-windows'),('air',root/'.scratch/inference-gaps/g10-sdk-air/collected'),('wsl',root/'.scratch/inference-gaps/g10-sdk-wsl/collected')]:
 for mode in ['static','shared','source']:
  path=folder/(mode+'-1')
  result=json.loads((path/'result.json').read_text())
  expected='CPU_SOURCE_PUBLIC_RUNTIME_GRAPH_HEADERS_PASS' if mode=='source' else 'CPU_RELOCATED_SDK_PUBLIC_RUNTIME_GRAPH_HEADERS_PASS'
  assert result['state']==expected,(host,mode,result['state'])
  assert result['source_snapshot']['head']==manifest['head'] and result['source_snapshot']['archive_sha256']==manifest['archive_sha256']
  assert len(result['binaries'])==3
  stages={x['stage']:x for x in result['stages']}
  public='path-repair-' if host=='windows' and mode=='source' else 'public-'
  for name in ['startup','query-first','late-native','late-aten','race-use','race-config','metadata-oom']:
   assert stages[public+name]['exit']==0
  assert stages[public+'graph-executor']['exit']==0
  backend=(path/(public+'startup.log')).read_text()
  assert 'backend=1 configured=2 observed=2 used=1' in backend,backend
  assert result.get('original_parent_restored',True)
  assert len(result['public_headers'])==2
  for h in result['public_headers']:assert sha(root/'include/hyle'/h['path'])==h['sha256']
  row=dict(host=host,mode=mode,verdict='PASS',raw_result=host+'/'+mode+'-1/result.json',result_sha256=sha(path/'result.json'),
   elapsed_seconds=result['elapsed_seconds'],identity=result.get('identity'),effective_static=result.get('effective_static'),
   source_commit=manifest['head'],actual_backend='ATen OpenMP',binaries=result['binaries'],resource=result.get('resource'),jobs=result['jobs'])
  if host=='windows' and mode=='source':
   old=json.loads((path/'retained-source-path-error.json').read_text())
   assert old['state']=='FAIL' and old['error']=='AssertionError([])'
   row['retained_collector_failure']=dict(file='windows/source-1/retained-source-path-error.json',sha256=sha(path/'retained-source-path-error.json'),
    resolution='Existing completed build manifest, all product/fixture hashes and public compile commands rechecked; private vendor fixture located at hyle/g10_vendor.exe and existing artifacts executed without configure/rebuild or elapsed-budget reset. Current result retains the original error field as historical context.')
  rows.append(row)
  for p in sorted(path.rglob('*')):
   if p.is_file():rawfiles.append((p,host+'/'+mode+'-1/'+p.relative_to(path).as_posix()))
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name in rawfiles:z.write(p,name)
sourcefiles=[]
implementation=json.loads((root/'evidence/architecture/inference-g10-thread-runtime-implementation/receipt.json').read_text())
for item in implementation['source_inputs']:
 p=root/item['path'];assert sha(p)==item['sha256'];sourcefiles.append((p,'product/'+item['path']))
for p in sorted(inputs.iterdir()):
 if p.is_file() and p.name!='source.zip':sourcefiles.append((p,'inputs/'+p.name))
for name in ['g10_prepare_delivery.py','g10_sdk.py','g10_finish_windows_source.py','g10_collect_sdk.py','g10_seal_sdk.py']:
 sourcefiles.append((root/'.scratch/inference-gaps'/name,'helpers/'+name))
with zipfile.ZipFile(out/'source.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name in sourcefiles:z.write(p,name)
receipt=dict(schema='hyle.g10-runtime-delivery-checkpoint/v1',verdict='NINE_CPU_SOURCE_STATIC_SHARED_PUBLIC_RUNTIME_GRAPH_EXECUTOR_HEADER_JOURNEYS_PASS',
 owner_state='AUDITED_NOT_ACCEPTED',product_commit=manifest['head'],product_tree=manifest['tree'],
 source_cohort=dict(transmitted_full_archive_sha256=manifest['archive_sha256'],tracked_files=len(manifest['files']),
   scope=manifest['archive_scope'],reconstruction='Canonical Git commit plus source.zip inputs/inputs.json binds the complete transmitted cohort; historical evidence excluded from the cohort.'),
 rows=rows,total_journeys=len(rows),passed=len(rows),retained_elapsed_seconds=sum(x['elapsed_seconds'] for x in rows),
 claims=['Actual public runtime scenarios in fresh processes on all nine delivery journeys.',
  'Original full Graph FFN/executor math/lifecycle sample after startup shared limit=2, independent workspaces/outputs and actual checked completion.',
  'Both public headers compile independently; relocated SDK consumers use installed headers/libraries and captured commands exclude producer/source paths.',
  'Tests, benchmarks, fault instrumentation and sanitizers OFF in shipping producer commands; no CUDA kernels, shaders or global operator rebuild.'],
 limits=['No sanitizer, P1, whole-process OS-thread quota, vendor-private-pool memory or final G10 acceptance claim.',
  'All actual CPU SDKs report OpenMP. The Native singleton late-setter scenario is not a runtime PASS on these artifacts.',
  'The old qualified cached-recipe positive runtime precondition remains NOT_APPLICABLE under the previously sealed current peer identities; ordinary drift refusal is actual.'],
 pending=['Actual Windows CPU+CUDA public math consumer','Explicit unavailable/OFF applicability verdict','New-state applicable sanitizers','P0 cost ledger and final review/acceptance'],
 archives=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in [out/'raw.zip',out/'source.zip']],
 archived_raw_files=[dict(path=name,sha256=sha(p),bytes=p.stat().st_size) for p,name in rawfiles])
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
review=root/'.scratch/inference-gaps/g09-native-aa-mechanism-review-20.json'
target=root/'evidence/architecture/inference-g09-p1-instrument-attempt/20.json'
assert sha(review)=='77513f47376e88b3860d76b5a86e6960b5667d4d1570e3af207856ca54a11dcf'
assert not target.exists()
target.write_bytes(review.read_bytes())
print(json.dumps(dict(verdict=receipt['verdict'],seconds=receipt['retained_elapsed_seconds'],archives=receipt['archives'])),flush=True)
