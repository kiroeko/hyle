from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path('C:/public/project-hyle/hyle')
out = root / '.scratch/inference-gaps/g10-delivery-inputs'
out.mkdir(exist_ok=False)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
paths = [x for x in paths if x and not x.startswith('evidence/')]
files = []
with zipfile.ZipFile(out / 'source.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name in paths:
        p = root / name
        assert p.is_file(), name
        files.append(dict(path=name, sha256=sha(p)))
        z.write(p, name)
for name, relative in [('cpu_executor.cc', 'samples/package/graph/cpu_executor/main.cc'),
                       ('cpu_cuda.cc', 'samples/package/graph/cpu_cuda/main.cc'),
                       ('thread_runtime_consumer.cc', 'tests/compute_route_cpu/thread_runtime_consumer.cc')]:
    (out / name).write_bytes((root / relative).read_bytes())
for name, sample in [('graph_runtime.cc', 'cpu_executor.cc'), ('joint_runtime.cc', 'cpu_cuda.cc')]:
    (out / name).write_text('''#include <hyle/compute/cpu.h>
#include <cstdio>
#define main g10_original_consumer_main
#include "''' + sample + '''"
#undef main
int main() {
  namespace cpu = hyle::compute::cpu;
  const auto configured = cpu::configure_runtime_threads(2);
  if (!configured.ok()) { std::fprintf(stderr, "G10 startup: %.*s\\n", int(configured.message().size()), configured.message().data()); return 1; }
  const auto result = g10_original_consumer_main();
  if (result) return result;
  const auto info = cpu::runtime_thread_info();
  if (!info || info->configuration_open || !info->usage_started ||
      info->configured_intra_op_threads != 2 || info->intra_op_limit != 2 ||
      !cpu::configure_runtime_threads(1).IsFailedPrecondition()) {
    std::fputs("G10 consumer did not preserve the shared startup limit\\n", stderr); return 1;
  }
  std::puts("G10 startup + original public math/lifecycle/executor consumer PASS");
  return 0;
}
''', encoding='utf8')
(out / 'g10_apps.cmake').write_text('''if(PROJECT_NAME STREQUAL "hyle")
  function(g10_validation_apps)
    get_target_property(_torch hyle_compute_provider_native HYLE_TORCH_CPU_ENABLED)
    if(_torch)
      add_executable(g10_vendor "${HYLE_SOURCE_DIR}/tests/compute_route_cpu/thread_runtime_consumer.cc")
      target_compile_features(g10_vendor PRIVATE cxx_std_23)
      target_compile_definitions(g10_vendor PRIVATE HYLE_G10_TEST_VENDOR=1)
      target_link_libraries(g10_vendor PRIVATE hyle::compute torch)
      hyle_stage_runtime(g10_vendor)
    endif()
  endfunction()
  cmake_language(DEFER CALL g10_validation_apps)
endif()
''', encoding='utf8')
manifest = dict(head=head, tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip(),
    archive_sha256=sha(out / 'source.zip'), files=files,
    archive_scope='Complete tracked product/source/tests/docs snapshot excluding historical evidence only; no hand-selected source subset.',
    fixtures=[dict(path=p.name, sha256=sha(p)) for p in sorted(out.iterdir()) if p.is_file() and p.name != 'source.zip'])
(out / 'inputs.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(head=head, files=len(files), archive_bytes=(out / 'source.zip').stat().st_size, archive_sha256=manifest['archive_sha256'])))
