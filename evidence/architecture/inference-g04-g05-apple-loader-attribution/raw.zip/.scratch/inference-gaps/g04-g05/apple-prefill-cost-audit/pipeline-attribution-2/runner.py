from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path('/Users/kiro/hyle-scratch/compute-unified')
out=base/'ce14-pipeline-attribution-2';out.mkdir(exist_ok=False)
original=base/'a-cpu-apple/selected-graph/source-build/hyle/_deps/mlx-31b1c0624fcc3fb4/source'
header=base/'ce14-pipeline-probe-header.h';driver=base/'ce14_pipeline_probe.mm'
assert original.is_dir() and header.is_file() and driver.is_file()
record=dict(state='RUNNING',stages=[],inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (header,driver)},
            scope='Original F32 Q8 vs predecoded same-geometry F32, same-geometry F16 and original F16 geometry. Native GPU kernel-only attribution; no product/P1 verdict.')
record['identity']={name:subprocess.check_output(cmd,text=True).strip() for name,cmd in [
 ('model',['sysctl','-n','hw.model']),('os',['sw_vers']),('arch',['uname','-m']),('compiler',['clang++','--version'])]}
assert record['identity']['model']=='Mac16,12'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def run(stage,cmd):
 t=time.monotonic()
 with (out/(stage+'.log')).open('w') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 record['stages'].append(dict(stage=stage,command=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-t));save()
 print(stage,p.returncode,flush=True)
 if p.returncode:record['state']='TERMINAL_FAIL';save();raise SystemExit(p.returncode)
source=out/'probe.metal'
source.write_text('#include "mlx/backend/metal/kernels/defines.h"\n#include "mlx/backend/metal/kernels/utils.h"\n#include "'+str(header)+'"\n'+
 'instantiate_kernel("probe_float16", attention, float, 16, 8, 256, 2, 1, float, float, 256);\n'+
 'instantiate_kernel("probe_half16", attention, half, 16, 8, 256, 2, 1, half, float, 256);\n'+
 'instantiate_kernel("probe_half32", attention, half, 32, 16, 256, 4, 1, half, float, 256);\n')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
save()
run('metal-compile',['xcrun','-sdk','macosx','metal','-std=metal3.2','-I'+str(original),'-c',str(source),'-o',str(out/'probe.air')])
run('metallib',['xcrun','-sdk','macosx','metallib',str(out/'probe.air'),'-o',str(out/'probe.metallib')])
for tag in ('query','optimized'):
 include=out/tag;include.mkdir()
 shader=out/(tag+'.metal')
 if tag=='optimized':
  loader=include/'mlx/backend/metal/kernels/steel/attn/loader.h';loader.parent.mkdir(parents=True)
  loader.write_bytes((base/'ce14-query-loader.h').read_bytes())
 shader.write_text(source.read_text().replace(str(header),str(base/'ce14-query-header.h'))+'\ninstantiate_kernel("probe_queryhalf", attention, float, 16, 16, 256, 2, 1, float, float, 256);\n')
 # QueryT=half only for the added specialization; the other three stay original.
 shader.write_text(shader.read_text().replace('float, float, 256);\n', 'float, float, 256);\n',1).replace('16, 16, 256, 2, 1, float, float, 256);','16, 16, 256, 2, 1, float, float, 256, half);'))
 run(tag+'-metal',['xcrun','-sdk','macosx','metal','-std=metal3.2','-I'+str(include),'-I'+str(original),'-c',str(shader),'-o',str(out/(tag+'.air'))])
 run(tag+'-metallib',['xcrun','-sdk','macosx','metallib',str(out/(tag+'.air')),'-o',str(out/(tag+'.metallib'))])
run('host-compile' ,['clang++','-std=c++20','-O2','-fobjc-arc','-framework','Foundation','-framework','Metal',str(driver),'-o',str(out/'probe')])
run('probe',[str(out/'probe'),str(out/'probe.metallib'),str(out/'query.metallib'),str(out/'optimized.metallib')])
record['state']='TERMINAL_ATTRIBUTION_ONLY';save()
