#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>

struct Params {
  int B,H,D,qL,kL,gqa; float scale;
  int NQ,NK,NQa,NKa,qRem,kRem,qOff;
  int64_t qs[3],ks[3],vs[3],os[3];
};
static_assert(sizeof(Params)==152);

int main(int argc,char**argv) { @autoreleasepool {
  if(argc!=4)return 2;
  id<MTLDevice> device=MTLCreateSystemDefaultDevice();
  NSError*error=nil;
  id<MTLLibrary> lib=[device newLibraryWithURL:[NSURL fileURLWithPath:@(argv[1])] error:&error];
  if(!lib){fprintf(stderr,"library: %s\n",error.description.UTF8String);return 3;}
  id<MTLLibrary> qlib=[device newLibraryWithURL:[NSURL fileURLWithPath:@(argv[2])] error:&error];
  id<MTLLibrary> olib=[device newLibraryWithURL:[NSURL fileURLWithPath:@(argv[3])] error:&error];
  if(!qlib||!olib)return 3;
  constexpr int H=8,HK=2,D=256,Q=128,K=768;
  std::vector<float> query(H*Q*D),key(K*HK*D),value(key.size());
  std::vector<_Float16> qh(query.size()),kh(key.size()),vh(key.size());
  std::vector<unsigned char> k8(key.size()/32*34),v8(k8.size());
  for(size_t i=0;i<query.size();++i)qh[i]=(_Float16)(query[i]=float(int(i*13%31)-15)*.015625f);
  for(unsigned port=0;port<2;++port) {
    auto &bytes=port?v8:k8;auto &f=port?value:key;auto &h=port?vh:kh;
    for(size_t block=0;block<f.size()/32;++block) {
      _Float16 scale=(_Float16)std::ldexp(1.f,-9+int((block+17*port)%5));
      auto bits=std::bit_cast<uint16_t>(scale);bytes[block*34]=bits&255;bytes[block*34+1]=bits>>8;
      for(unsigned d=0;d<32;++d) {
        int8_t code=int((block*13+d*7+17*port)%31)-15;
        bytes[block*34+2+d]=uint8_t(code);h[block*32+d]=(_Float16)(f[block*32+d]=float(scale)*float(code));
      }
    }
  }
  std::vector<int> pages(K/16);for(int i=0;i<K/16;++i)pages[i]=K/16-1-i;
  auto buffer=[&](const void*p,size_t n){return [device newBufferWithBytes:p length:n options:MTLResourceStorageModeShared];};
  id<MTLBuffer> qf=buffer(query.data(),query.size()*4),kf=buffer(key.data(),key.size()*4),vf=buffer(value.data(),value.size()*4);
  id<MTLBuffer> qb=buffer(qh.data(),qh.size()*2),kb=buffer(kh.data(),kh.size()*2),vb=buffer(vh.data(),vh.size()*2);
  id<MTLBuffer> ke=buffer(k8.data(),k8.size()),ve=buffer(v8.data(),v8.size()),pt=buffer(pages.data(),pages.size()*4);
  id<MTLCommandQueue> queue=[device newCommandQueue];
  struct Route { const char*name;bool half,encoded;int bq,bk;id<MTLComputePipelineState> pipeline;id<MTLBuffer> output;int library=0; };
  Route routes[]={{"q8_f32_16x8",false,true,16,8,nil,nil},{"plain_f32_16x8",false,false,16,8,nil,nil},
                  {"plain_half_16x8",true,false,16,8,nil,nil},{"plain_half_32x16",true,false,32,16,nil,nil},
                  {"query_half_f32_16x16",false,true,16,16,nil,nil,1},
                  {"hoisted_q8_f32_16x8",false,true,16,8,nil,nil,2},
                  {"query_half_hoisted_f32_16x16",false,true,16,16,nil,nil,2}};
  for(auto &r:routes) {
    MTLFunctionConstantValues*fc=[MTLFunctionConstantValues new];
    for(unsigned i:{200,201,300,301,302,303,304,305}) {
      bool v=i==200||i==201||i==301||i==303||(i==304&&r.encoded);
      [fc setConstantValue:&v type:MTLDataTypeBool atIndex:i];
    }
    NSString *name=r.half?(r.bq==32?@"probe_half32":@"probe_half16"):(r.bk==16?@"probe_queryhalf":@"probe_float16");
    id<MTLLibrary> selected=r.library==1?qlib:(r.library==2?olib:lib);
    id<MTLFunction> f=[selected newFunctionWithName:name constantValues:fc error:&error];
    if(!f){fprintf(stderr,"function: %s\n",error.description.UTF8String);return 4;}
    r.pipeline=[device newComputePipelineStateWithFunction:f error:&error];
    if(!r.pipeline){fprintf(stderr,"pipeline: %s\n",error.description.UTF8String);return 5;}
    r.output=[device newBufferWithLength:query.size()*(r.half?2:4) options:MTLResourceStorageModeShared];
    printf("RESOURCE %s shared=%lu max_threads=%lu width=%lu validation=%lu\n",r.name,
      (unsigned long)r.pipeline.staticThreadgroupMemoryLength,(unsigned long)r.pipeline.maxTotalThreadsPerThreadgroup,
      (unsigned long)r.pipeline.threadExecutionWidth,(unsigned long)r.pipeline.shaderValidation);
  }
  auto run=[&](Route&r,int repeats) {
    Params p{1,H,D,Q,K,H/HK,1.f/std::sqrt(float(D)),Q/r.bq,K/r.bk,Q/r.bq,K/r.bk,0,0,K-Q,
      {H*Q*D,Q*D,D},{K*HK*D,D,HK*D},{K*HK*D,D,HK*D},{H*Q*D,Q*D,D}};
    if(r.encoded)for(int i=0;i<3;++i)p.ks[i]=p.vs[i]=p.ks[i]/32*34;
    id<MTLCommandBuffer> cb=[queue commandBuffer];
    id<MTLComputeCommandEncoder> enc=[cb computeCommandEncoder];
    [enc setComputePipelineState:r.pipeline];
    [enc setBuffer:r.half?qb:qf offset:0 atIndex:0];
    [enc setBuffer:r.encoded?ke:(r.half?kb:kf) offset:0 atIndex:1];
    [enc setBuffer:r.encoded?ve:(r.half?vb:vf) offset:0 atIndex:2];
    [enc setBuffer:r.output offset:0 atIndex:3];[enc setBytes:&p length:sizeof(p) atIndex:4];
    int offset=0;[enc setBuffer:pt offset:0 atIndex:8];[enc setBytes:&offset length:4 atIndex:9];
    for(int n=0;n<repeats;++n) {
      [enc dispatchThreadgroups:MTLSizeMake(Q/r.bq,H,1) threadsPerThreadgroup:MTLSizeMake(32,r.bq/8,1)];
      [enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
    }
    [enc endEncoding];[cb commit];[cb waitUntilCompleted];
    if(cb.status!=MTLCommandBufferStatusCompleted){fprintf(stderr,"command: %s\n",cb.error.description.UTF8String);exit(6);}
    return (cb.GPUEndTime-cb.GPUStartTime)/repeats;
  };
  for(auto &r:routes)for(int n=0;n<2;++n)run(r,1);
  for(int round=0;round<6;++round)for(int i=0;i<7;++i) {
    auto &r=routes[round%2?6-i:i];printf("TIME %s round=%d gpu_seconds=%.9g\n",r.name,round,run(r,8));
  }
  for(int j=1;j<7;++j) {
    double errorMax=0;auto&r=routes[j];const float*baseline=(const float*)routes[0].output.contents;
    for(size_t i=0;i<query.size();++i) {
      double v=r.half?double(((const _Float16*)r.output.contents)[i]):double(((const float*)r.output.contents)[i]);
      if(!std::isfinite(v)){fprintf(stderr,"nonfinite\n");return 7;}
      errorMax=std::max(errorMax,std::abs(v-double(baseline[i])));
    }
    printf("DIFFERENCE %s max_abs=%.9g\n",r.name,errorMax);
    if(errorMax>(r.half?.002:1e-6))return 8;
  }
  printf("LIMIT kernel-only attribution; predecoded controls exclude decode and allocation; no product P1 or new numerical qualification\n");
  return 0;
} }
