from pathlib import Path
import hashlib
base=Path('.scratch/inference-gaps/g04-g05/apple-prefill-cost-audit')
name='mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h'
s=(base/'candidate'/name).read_text()
def change(before,after):
 global s
 assert s.count(before)==1,(before,s.count(before));s=s.replace(before,after,1)
change('typename AccumType = float, int BV = BD>','typename AccumType = float, int BV = BD, typename QueryT = T>')
change('constexpr short padQ = 16 / sizeof(T);','constexpr short padQ = 16 / sizeof(QueryT);')
change('threadgroup T Q_smem[BQ * (BD + padQ)];','threadgroup QueryT Q_smem[BQ * (BD + padQ)];')
change('threadgroup T* Qs = Q_smem;','threadgroup QueryT* Qs = Q_smem;')
change('  QBlockLoader loader_q(\n      Q, params->Q_strides[2], Qs, simd_group_id, simd_lane_id);\n','')
change('  MMATile<AccumType, TQ, 1, MMAFrag_acc_t> Qtile;','  MMATile<QueryT, TQ, 1, BaseMMAFrag<QueryT, kFragSize, kFragSize>> Qtile;')
change('Qtile.template load<T, 1, 1, LDQ_tgp, 1>','Qtile.template load<QueryT, 1, 1, LDQ_tgp, 1>')
change('''  // Load Q blocks
  if (!align_Q && int(tid.x) == (params->NQ_aligned)) {
    loader_q.load_safe(short2(BD, params->qL_rem));
  } else {
    loader_q.load_unsafe();
  }
''','''  // Source Query is still F32; only a known original F16 Query may instantiate
  // QueryT=half. Each element is an exact round-trip, including F16 subnormals.
  if constexpr (is_same_v<QueryT, T>) {
    QBlockLoader loader_q(Q, params->Q_strides[2], Qs, simd_group_id, simd_lane_id);
    if (!align_Q && int(tid.x) == params->NQ_aligned)
      loader_q.load_safe(short2(BD, params->qL_rem));
    else loader_q.load_unsafe();
  } else {
    for (int idx = simd_group_id * 32 + simd_lane_id; idx < BQ * BD; idx += WM * WN * 32) {
      const int row = idx / BD, col = idx % BD;
      const bool valid = align_Q || int(tid.x) != params->NQ_aligned || row < params->qL_rem;
      Qs[row * LDQ_tgp + col] = valid ? QueryT(Q[row * params->Q_strides[2] + col]) : QueryT(0);
    }
  }
''')
out=base/'query-stage-probe';out.mkdir(exist_ok=False)
(out/'kernel.h').write_text(s,encoding='utf-8')
name='mlx/backend/metal/kernels/steel/attn/loader.h';s=(base/'candidate'/name).read_text()
before='''    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
      for (short j = 0; j < vec_size; ++j) {
'''
after='''    // Each aligned 32-element code block owns one scale. Do not reconstruct
    // its address/scale independently for every element in the block.
    if constexpr (vec_size % 32 == 0 && BCOLS % 32 == 0) {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        const bool valid = bi + i < valid_rows;
        const int logical = first + bi + i;
        const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j += 32) {
          if (valid) {
            const device uchar* block = root + physical * src_ld + ((bj + j) / 32) * 34;
            const float scale = float(as_type<half>(ushort(block[0]) | (ushort(block[1]) << 8)));
            STEEL_PRAGMA_UNROLL
            for (short k = 0; k < 32; ++k)
              dst[i * kDstStrRow + (j + k) * kDstStrCol] = T(scale * float(as_type<char>(block[2 + k])));
          } else {
            STEEL_PRAGMA_UNROLL
            for (short k = 0; k < 32; ++k)
              dst[i * kDstStrRow + (j + k) * kDstStrCol] = T(0);
          }
        }
      }
      return;
    }
    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
      for (short j = 0; j < vec_size; ++j) {
'''
assert s.count(before)==1;s=s.replace(before,after,1)
(out/'loader.h').write_text(s,encoding='utf-8')
print('Diagnostic derivation only',hashlib.sha256(s.encode()).hexdigest())
