from pathlib import Path
import hashlib,json,os,re,sqlite3,subprocess,time,uuid

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
receipt=root/'evidence/correctness/inference-g04-g05-cuda-ce24-packed-math-numeric-rebind/receipt.json'
numeric=json.loads(receipt.read_text());assert numeric['state']=='TERMINAL_PASS'
assert numeric['product_candidate']=='6e57e28ada9e29ed07819fbe9a97b8a7d08271fe'
run=numeric['successful_run'];binary=Path(run['binary']['path']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)==run['binary']['sha256']
projected=json.loads((root/'evidence/architecture/inference-g04-g05-cuda-ce24-packed-math-budget/codegen-receipt.json').read_text())
expected={r['mangled']:r for r in projected['kernels']};assert len(expected)==3
out=base/'ce24-runtime-profile-1';out.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('HYLE_BENCH_AA_ROUTE',None);env.update(HYLE_BENCH_VERIFY_ONLY='1',HYLE_PERF_RUN_NONCE=uuid.uuid4().hex)
command=['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--export=sqlite',
         '--force-overwrite=false','--output='+str(out/'dispatch'),str(binary)]
r=dict(state='SETUP',purpose='CE24_RUNTIME_DISPATCH_IDENTITY_ONLY_NOT_P1',command=command,
       product_candidate=numeric['product_candidate'],numeric_receipt_sha256=sha(receipt),binary_sha256=sha(binary),
       nsys_version=subprocess.check_output(['nsys','--version'],text=True).strip())
save=lambda:(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
save();started=time.monotonic()
with (out/'profile.log').open('w') as f:
    p=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',pid=p.pid);save();code=p.wait()
r.update(exit_code=code,elapsed_seconds=time.monotonic()-started);save();assert code==0
log=(out/'profile.log').read_text();errors=re.findall(r'# CUDA_ENCODED_CORRECTNESS max_abs_error=([^ ]+)',log)
assert len(errors)==24 and max(map(float,errors))<=8e-3 and log.count('# CUDA_FP8_PAIR ')==3
facts=[re.sub(r' original=[01]$','',line) for line in log.splitlines() if line.startswith('# CUDA_ENCODED_ENV ')]
assert len(facts)==6 and set(facts)=={run['native_environment']}
db=sqlite3.connect(out/'dispatch.sqlite')
query='''select distinct m.value,d.value,k.registersPerThread,k.dynamicSharedMemory,k.blockX,k.blockY,k.blockZ
from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds m on k.mangledName=m.id
join StringIds d on k.demangledName=d.id where m.value like '_ZN10flashinfer%BatchPrefillWithPagedKVCacheKernel%' '''
rows=db.execute(query).fetchall();assert len(rows)==3 and {row[0] for row in rows}==set(expected)
r['kernels']=[dict(mangled=m,demangled=d,projected_mma_kv=expected[m]['projected_mma_kv'],registers=reg,dynamic_shared=shared,block=[x,y,z]) for m,d,reg,shared,x,y,z in rows]
assert sorted((row['projected_mma_kv'],row['dynamic_shared']) for row in r['kernels'])==[(1,40960),(1,40960),(4,24576)]
assert sha(binary)==r['binary_sha256']
r.update(state='TERMINAL_DISPATCH_IDENTITY_PASS',max_abs_error=max(map(float,errors)),
         limits=['One short VERIFY_ONLY trace; no new A/A or throughput qualification.',
                 'Actual current immutable static SDK numeric binary; same three frozen workloads/peer.',
                 'Original qualified attempt9 FAIL and all failed hypotheses/costs retained.'])
r.pop('pid',None);save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(r['kernels'],indent=2))
