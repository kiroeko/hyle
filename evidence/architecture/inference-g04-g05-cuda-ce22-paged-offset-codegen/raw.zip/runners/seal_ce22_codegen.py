from pathlib import Path
import hashlib,json,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';run=base/'ce22-fixed-codegen-1'
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_PASS' and len(r['kernels'])==3
assert r['product_candidate']=='8d61d51f162a200fd519a8e27e90d0a787b51cd2'
dest=root/'evidence/architecture/inference-g04-g05-cuda-ce22-paged-offset-codegen';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(run).as_posix())
    z.write(base/'seal_ce22_codegen.py','runners/seal_ce22_codegen.py')
receipt=dict(kind='G04_G05_CE22_PAGED_OFFSET_FIXED_KERNEL_CODEGEN',
    verdict='EXTRACTION_PASS_RESOURCE_HYPOTHESIS_NOT_MET_NO_THROUGHPUT_VERDICT',
    product_candidate=r['product_candidate'],binary_sha256=r['binary_sha256'],header_sha256=r['header_sha256'],
    previous_codegen_sha256=r['old_codegen_sha256'],kernels=r['kernels'],stages=r['stages'],
    measured_seconds=sum(s['elapsed_seconds'] for s in r['stages']),
    limits=r['limits']+['Actual stack frames increased40/48/120 to48/56/144; LDL/STL remain and peak registers255 unchanged.',
        'This falsifies the proposed register-pressure relief; it does not establish actual throughput regression.',
        'Downstream static/shared,host facets,numeric and P1 intentionally not launched while this P0 hypothesis remains unmet.',
        'Correctness/device PASS and all original failures/costs remain; aggregate G04/G05 not accepted.'],
    raw_zip_sha256=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(dest)
