from pathlib import Path
import hashlib, json, re, subprocess, time

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
candidate='8d61d51f162a200fd519a8e27e90d0a787b51cd2'
source=json.loads((base/'ce22-source-1/result.json').read_text())
device=json.loads((base/'ce22-device-risks-1/result.json').read_text())
assert source['state']==device['state']=='TERMINAL_PASS' and device['product_commit']==candidate
build=Path(source['build']);binary=build/'bin/libhyle_compute_provider_flashinfer.so.0.1.0'
out=base/'ce22-fixed-codegen-1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(binary);assert before==device['artifacts'][str(binary)]
oldpath=Path('/root/hyle-scratch/compute-unified/ce22-cuda-product-profile-9/actual-kernel-resources.json')
old=json.loads(oldpath.read_text())
selected=[row for row in old['kernels'] if row['mangled'].startswith('_ZN10flashinfer')]
assert len(selected)==3
tool='/usr/local/cuda-13.3/bin/cuobjdump';stages=[]
def run(label,command):
    started=time.monotonic()
    with (out/(label+'.log')).open('w') as stream:
        p=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
    stages.append(dict(stage=label,command=command,exit_code=p.returncode,elapsed_seconds=time.monotonic()-started))
    assert p.returncode==0
run('resources',[tool,'--dump-resource-usage',str(binary)])
resources={};name=None
for line in (out/'resources.log').read_text().splitlines():
    if line.strip().startswith('Function ') and line.endswith(':'):name=line.strip()[9:-1]
    elif name and 'REG:' in line:resources.setdefault(name,[]).append(line.strip())
for row in selected:assert row['mangled'] in resources,row['mangled']
run('selected-sass',[tool,'--dump-sass','--function',','.join(row['mangled'] for row in selected),str(binary)])
counts={};current=None
for line in (out/'selected-sass.log').read_text().splitlines():
    found=re.search(r'Function\s*:\s*(\S+)',line)
    if found:
        current=found.group(1)
        assert current not in counts, 'Duplicate image requires explicit architecture mapping'
        counts[current]=dict(LDL=0,STL=0)
    if current:
        for instruction in ('LDL','STL'):counts[current][instruction]+=len(re.findall(r'\b'+instruction+r'\b',line))
rows=[]
for row in selected:
    name=row['mangled'];assert len(resources[name])==1 and name in counts
    rows.append(dict(mangled=name,demangled=row['demangled'],before_resource=row['resource'],
                     after_resource=resources[name][0],before_sass=row['sass_local_instructions'],after_sass=counts[name]))
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
command=next(row for row in commands if row['file'].endswith('/native_cache.cu'))
include=re.search(r'-I(\S*cache-source-\S*/include)',command['command']).group(1)
header=Path(include)/'flashinfer/attention/prefill.cuh'
manifest=json.loads((root/'third_party/flashinfer_cache/patches.json').read_text())
expected=next(row for row in manifest['files'] if row['path']=='include/flashinfer/attention/prefill.cuh')['after_sha256']
assert sha(header)==expected and sha(binary)==before
record=dict(kind='CE22_SAME_THREE_KERNEL_SYMBOLS_STATIC_CODEGEN_ONLY',state='TERMINAL_PASS',
 product_candidate=candidate,binary=str(binary),binary_sha256=before,old_codegen_sha256=sha(oldpath),
 header=str(header),header_sha256=sha(header),compile_command=command,stages=stages,kernels=rows,
 limits=['Actual source-test shared artifact, WSL SM89; same three exact mangled specializations as qualified attempt9.',
         'Only static resource and instruction counts; no runtime timing, occupancy or throughput verdict.',
         'Original tile, warp and math template parameters unchanged; SDK and fresh numeric/P1 remain separate gates.'])
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(rows,indent=2))
