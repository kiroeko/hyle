from pathlib import Path
import argparse,hashlib,json

p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--route',required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();r=json.loads((a.reference/'source-identity.json').read_text());sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert r['schema']=='hyle.inference-g08-original-source-materialization/v1' and r['original_revision']=='85bcfa4ebc29cc4d2ed5fb122074204aca675d58' and r['route']==a.route
for item in r['files']:assert sha(a.reference/item['path'])==item['materialized_sha256'],item['path']
for item in r['owned_public_overlay']:assert sha(a.reference/item['path'])==item['sha256'],item['path']
for item in r['shared_private_headers']:assert sha(a.repo/item['path'])==item['sha256'],('common private bridge changed',item['path'])
assert all((a.reference/x).is_file() for x in r['compiled_original_sources'])
assert (a.reference/'sources.cmake').read_text()=='set(G08_ORIGINAL_SOURCES\n'+''.join('  "${HYLE_G08_REFERENCE_DIR}/'+x+'"\n' for x in r['compiled_original_sources'])+')\n'
a.output.write_text(json.dumps(dict(state='PINNED_REFERENCE_AND_SHARED_PRIVATE_BRIDGES_VERIFIED_NOT_RUNTIME_QUALIFICATION',route=a.route,original_revision=r['original_revision'],source_identity_sha256=sha(a.reference/'source-identity.json'),files=len(r['files']),shared_private_headers=len(r['shared_private_headers']),compiled_original_sources=r['compiled_original_sources']),indent=2)+'\n')
print('Pinned original implementation, owned overlay and unchanged common private bridges: PASS')
