set(G08_ORIGINAL_SOURCES
  "${HYLE_G08_REFERENCE_DIR}/src/compute_provider_ggml/ggml_cpu_provider.cc"
  "${HYLE_G08_REFERENCE_DIR}/src/compute_provider_ggml/standard_index.cc"
  "${HYLE_G08_REFERENCE_DIR}/src/compute_provider_ggml/native_batch.cc"
)
