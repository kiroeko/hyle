"""Prepare clean sparse original85 peers; no product build or source copyback."""
from pathlib import Path
import argparse,json,subprocess,sys,time

p=argparse.ArgumentParser();p.add_argument('--label',required=True);a=p.parse_args()
air=sys.platform=='darwin';assert air or sys.platform=='linux'
base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified'
canonical=base/'g04-vulkan-encoded-p1-source-1' if air else Path('/mnt/c/public/project-hyle/hyle')
out=base/('g08-original-peer-setup-'+a.label) if air else canonical/'.scratch/inference-gaps'/('g08-original-peer-setup-'+a.label)
out.mkdir(exist_ok=False);pin='85bcfa4ebc29cc4d2ed5fb122074204aca675d58';tree='165e375ccaf1cbbee9d076728517defdee98a4e0';started=time.monotonic()
r=dict(state='RUNNING',scope='Sparse clean original85 Git peers for the unchanged public performance runner. Read-only references; no workload/native build, sampling or product source copyback.',cases=[])
def run(name,args):
    result=subprocess.run(args,capture_output=True,text=True)
    (out/(name+'.log')).write_text(result.stdout+result.stderr)
    assert result.returncode==0,(name,result.stderr[-1600:]);return result.stdout.strip()
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
if air:
    r['model']=run('model',['/usr/sbin/sysctl','-n','hw.model']);assert r['model']=='Mac16,12'
    run('fetch-bundle',['git','-C',str(canonical),'fetch',str(base/'g08-p1-base.bundle'),'HEAD'])
patterns=['include','src/compute','src/compute_backend_cpu','src/compute_backend_cuda','src/compute_ggml_runtime','src/compute_provider_ggml','src/compute_provider_cuda','src/compute_route_apple','src/compute_route_vulkan','src/compute_provider_ggml_vulkan','third_party/ggml_vulkan_shaders']
for route in ['apple','vulkan'] if air else ['cuda']:
    folder=base/('g08-p1-'+route);folder.mkdir(exist_ok=True);peer=folder/'original85'
    if not peer.exists():
        run(route+'-clone',['git','clone','--shared','--no-checkout',str(canonical),str(peer)])
        run(route+'-line-endings',['git','-C',str(peer),'config','core.autocrlf','false'])
        pending=[canonical/'.git/objects'];stores=[]
        while pending:
            store=pending.pop(0).resolve()
            if store in stores:continue
            assert store.is_dir();stores.append(store);alternates=store/'info/alternates'
            if alternates.is_file():pending.extend(Path(x) if Path(x).is_absolute() else store/x for x in alternates.read_text().splitlines())
        (peer/'.git/objects/info/alternates').write_text(''.join(str(x)+'\n' for x in stores))
        run(route+'-sparse',['git','-C',str(peer),'sparse-checkout','set',*patterns])
        run(route+'-checkout',['git','-C',str(peer),'checkout','--detach',pin])
    revision=run(route+'-revision',['git','-C',str(peer),'rev-parse','HEAD']);observed_tree=run(route+'-tree',['git','-C',str(peer),'rev-parse','HEAD^{tree}']);status=run(route+'-status',['git','-C',str(peer),'status','--porcelain','--untracked-files=all'])
    assert revision==pin and observed_tree==tree and not status
    r['cases'].append(dict(route=route,peer=str(peer),revision=revision,tree=observed_tree,clean=True));save();print(json.dumps(r['cases'][-1]),flush=True)
r['state']='PINNED_CLEAN_ORIGINAL85_PEERS_READY';save()
