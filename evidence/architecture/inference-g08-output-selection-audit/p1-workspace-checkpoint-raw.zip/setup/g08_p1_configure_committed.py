"""Configure the committed benchmark snapshot only; the future probe reuses this tree."""
from pathlib import Path
import argparse,ctypes,json,os,subprocess,sys,time

p=argparse.ArgumentParser();p.add_argument('--route',choices=['cpu','cuda','apple','vulkan'],required=True);p.add_argument('--label',required=True);a=p.parse_args()
air=sys.platform=='darwin';windows=sys.platform=='win32';route=a.route;assert (windows and route=='cpu') or (sys.platform=='linux' and route=='cuda') or (air and route in ['apple','vulkan'])
base=Path('C:/h7') if windows else Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified';folder=base/('g08-p1-'+route);source=folder/'source';build=folder/'probe-build'
canonical=Path('C:/public/project-hyle/hyle') if windows else Path('/mnt/c/public/project-hyle/hyle')
out=(base/('g08-p1-final-config-'+a.label) if air else canonical/'.scratch/inference-gaps'/('g08-p1-final-config-'+a.label))/route;out.mkdir(parents=True,exist_ok=False)
snapshot='c31e7919cb9fcaba1293d814cbfbb3a16d4a21cf';assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==snapshot
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=all'],text=True).strip();assert not build.exists()
env={k.upper():v for k,v in os.environ.items()} if windows else dict(os.environ)
if windows:
    setup=subprocess.check_output(['cmd','/d','/c',str(canonical/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf-8',errors='replace')
    env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')));env['VSLANG']='1033'
else:
    os.nice(10);env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
if air:assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
bench=source/'bench/inference_output_selection';contract=json.loads((bench/('contract-'+route+'.json')).read_text());runner=contract['extensions']['runner'];machine='W1-WIN' if windows else 'M1-MAC' if air else 'W1-WSL'
cache={**runner['cmake']['cache'],**runner['profiles'][machine]['cache'],'HYLE_G08_REFERENCE_SOURCE':str(folder/'original85'),'CMAKE_BUILD_TYPE':'Release'}
args=['cmake','-S',str(bench),'-B',str(build),'-G','Ninja']+['-D'+k+'='+v for k,v in sorted(cache.items())]
r=dict(state='RUNNING',pid=os.getpid(),route=route,source_revision=snapshot,command=args,scope='Committed source/peer/SDK CMake configuration and benchmark-only Ninja preview. No actual workload build or timing.');started=time.monotonic();(out/'result.json').write_text(json.dumps(r,indent=2))
with (out/'configure.log').open('wb') as log:
    flags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS if windows else 0
    child=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=flags)
    if windows:
        setter=ctypes.windll.kernel32.SetProcessAffinityMask;setter.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert setter(ctypes.c_void_p(int(child._handle)),15)
    status=child.wait()
r.update(exit_code=status,elapsed_seconds=time.monotonic()-started,state='CONFIGURE_FAIL' if status else 'CONFIGURE_PASS')
if not status:
    preview=subprocess.run(['ninja','-C',str(build),'-n','g08_topk_primary','g08_topk_placement','g08_topk_control'],env=env,capture_output=True,text=True)
    (out/'dry-run.log').write_text(preview.stdout+preview.stderr);assert preview.returncode==0 and 'Re-running CMake' not in preview.stdout
    proof=json.loads((build/'reference-identity.json').read_text());assert proof['original_checkout_verified'] and proof['original_checkout']['revision']=='85bcfa4ebc29cc4d2ed5fb122074204aca675d58'
    (out/'reference-identity.json').write_bytes((build/'reference-identity.json').read_bytes());(out/'compile-commands.json').write_bytes((build/'compile_commands.json').read_bytes());r['preview_lines']=len(preview.stdout.splitlines());r['state']='COMMITTED_SOURCE_CLEAN_PEER_CONFIG_AND_BENCHMARK_ONLY_PREVIEW_PASS'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=all'],text=True).strip()
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['command']}));
if status:print((out/'configure.log').read_text(errors='replace')[-1800:])
raise SystemExit(status)
