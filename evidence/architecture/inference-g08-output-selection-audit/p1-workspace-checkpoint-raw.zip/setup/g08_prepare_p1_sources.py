"""Prepare clean benchmark-only snapshots; canonical product checkout is untouched."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time

p=argparse.ArgumentParser();p.add_argument('--revision',required=True);p.add_argument('--bundle-sha256',required=True);p.add_argument('--label',required=True);a=p.parse_args()
air=sys.platform=='darwin';assert air or sys.platform=='linux';base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified'
canonical=base/'g04-vulkan-encoded-p1-source-1' if air else Path('/mnt/c/public/project-hyle/hyle')
bundle=base/'g08-p1-source.bundle' if air else canonical/'.scratch/inference-gaps/g08-p1-source.bundle';assert hashlib.sha256(bundle.read_bytes()).hexdigest()==a.bundle_sha256
out=base/('g08-p1-source-setup-'+a.label) if air else canonical/'.scratch/inference-gaps'/('g08-p1-source-setup-'+a.label);out.mkdir(exist_ok=False)
r=dict(state='RUNNING',revision=a.revision,cases=[],scope='Clean committed Windows-authored benchmark/evidence snapshot only; no product change, workload build or P1 sampling.');started=time.monotonic()
def run(name,args):
    p=subprocess.run(args,capture_output=True,text=True);(out/(name+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(name,p.stderr[-2000:]);return p.stdout.strip()
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
if air:
    r['model']=run('model',['/usr/sbin/sysctl','-n','hw.model']);assert r['model']=='Mac16,12'
    run('fetch-source-bundle',['git','-C',str(canonical),'fetch',str(bundle),'HEAD'])
patterns=['bench','scripts','include','src/compute','src/compute_backend_cpu','src/compute_backend_cuda','src/compute_ggml_runtime','src/compute_provider_ggml_vulkan','third_party/nanobench','evidence/architecture/inference-g08-output-selection-audit','evidence/delivery/inference-g08-air-sdk-checkpoint','evidence/delivery/inference-g08-windows-cpu-sdk-checkpoint','evidence/delivery/inference-g08-cuda-sdk-checkpoint']
for route in ['apple','vulkan'] if air else ['cuda']:
    source=base/('g08-p1-'+route)/'source';assert not source.exists()
    run(route+'-clone',['git','clone','--shared','--no-checkout',str(canonical),str(source)])
    run(route+'-line-endings',['git','-C',str(source),'config','core.autocrlf','false'])
    pending=[canonical/'.git/objects'];stores=[]
    while pending:
        store=pending.pop(0).resolve()
        if store in stores:continue
        assert store.is_dir();stores.append(store);f=store/'info/alternates'
        if f.is_file():pending.extend(Path(x) if Path(x).is_absolute() else store/x for x in f.read_text().splitlines())
    (source/'.git/objects/info/alternates').write_text(''.join(str(x)+'\n' for x in stores))
    if not air:run(route+'-fetch-source-bundle',['git','-C',str(source),'fetch',str(bundle),'HEAD'])
    run(route+'-sparse',['git','-C',str(source),'sparse-checkout','set',*patterns])
    run(route+'-checkout',['git','-C',str(source),'checkout','--detach',a.revision])
    assert run(route+'-revision',['git','-C',str(source),'rev-parse','HEAD'])==a.revision
    assert not run(route+'-status',['git','-C',str(source),'status','--porcelain','--untracked-files=all'])
    actual=source/'bench/inference_output_selection';contract=json.loads((actual/('contract-'+route+'.json')).read_text());assert contract['extensions']['runner']['cmake']['cache']['HYLE_G08_SOURCE']==str(source)
    r['cases'].append(dict(route=route,source=str(source),revision=a.revision,clean=True,flattened_object_stores=[str(x) for x in stores]));save();print(json.dumps({k:v for k,v in r['cases'][-1].items() if k!='flattened_object_stores'}),flush=True)
r['state']='CLEAN_BENCHMARK_SOURCE_SNAPSHOTS_READY';save()
