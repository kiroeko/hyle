"""Run the existing performance instrument after the fixed delivery matrix passes."""
from pathlib import Path
import argparse,ctypes,hashlib,json,os,subprocess,sys,time

p=argparse.ArgumentParser();p.add_argument('--route',choices=['cpu','cuda','apple','vulkan'],required=True);p.add_argument('--mode',choices=['probe','qualify'],required=True);p.add_argument('--delivery-proof',type=Path,required=True);p.add_argument('--revision',required=True);a=p.parse_args()
air=sys.platform=='darwin';windows=sys.platform=='win32';route=a.route;assert (windows and route=='cpu') or (sys.platform=='linux' and route=='cuda') or (air and route in ['apple','vulkan'])
delivery=json.loads(a.delivery_proof.read_text());assert delivery['verdict']=='ALL_18_SOURCE_STATIC_SHARED_DELIVERIES_PASS' and delivery['configs']==18 and delivery['candidate']=='5103c13d8ed119b06aa64e799f9768aea45ab913'
base=Path('C:/h7') if windows else Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified';folder=base/('g08-p1-'+route);source=folder/'source';peer=folder/'original85';bench=source/'bench/inference_output_selection';contract=bench/('contract-'+route+'.json')
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==a.revision
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=all'],text=True).strip()
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='85bcfa4ebc29cc4d2ed5fb122074204aca675d58'
if air:assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
build=folder/('probe-build' if a.mode=='probe' else 'qualified-build-1');out=folder/('probe-1' if a.mode=='probe' else 'qualification-1');job=folder/(a.mode+'-job-1.json')
assert not job.exists() and not out.exists(),'Preserve the existing finite run; inspect and resume the original failure, never reset it.'
if a.mode=='qualify':
    prior=json.loads((folder/'probe-job-1.json').read_text());assert prior['state']=='TERMINAL' and prior['exit_code']==0 and prior.get('verify_exit_code')==0
    assert json.loads((folder/'probe-1/topk-aa.json').read_text())['gate']=='PASS'
    assert not build.exists()
env={k.upper():v for k,v in os.environ.items()} if windows else dict(os.environ)
if windows:
    canonical=Path('C:/public/project-hyle/hyle');setup=subprocess.check_output(['cmd','/d','/c',str(canonical/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf-8',errors='replace')
    env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')));env['VSLANG']='1033'
else:
    env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
    if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
machine='W1-WIN' if windows else 'M1-MAC' if air else 'W1-WSL';cmd=[sys.executable,str(source/'scripts/hyle-perf.py'),'probe' if a.mode=='probe' else 'qualify-platform','--source',str(bench),'--contract',str(contract),'--machine',machine,'--peer','original85='+str(peer),'--build',str(build),'--output',str(out)]
sys.path.insert(0,str(source/'scripts'))
from hyle_perf import expected_child_policy,get_machine_profile,load_registry,probe_machine
from hyle_perf.runner import _apply_sampling_policy,_creation_flags,_probe_child_policy
profile=get_machine_profile(load_registry(),machine);host=probe_machine(paths=[('source',source)],expected_qos='interactive' if air else None);policy=expected_child_policy(profile,sampling_topology='single-logical-cpu',probe=host)
r=dict(state='RUNNING',pid=os.getpid(),route=route,mode=a.mode,source_revision=a.revision,command=cmd,delivery_proof_sha256=hashlib.sha256(a.delivery_proof.read_bytes()).hexdigest(),scope='Existing instrument and unchanged5%/n15-31. Probe is diagnostic only. Same registered process topology surrounds A/A and product children; no public statistics/instrument change.');started=time.monotonic()
def save():r['elapsed_seconds']=time.monotonic()-started;job.write_bytes((json.dumps(r,indent=2)+'\n').encode())
save()
with _apply_sampling_policy(policy) as applied:
    flags=_creation_flags(policy);r['applied_parent_sampling_policy']=applied;r['inherited_child_canary']=_probe_child_policy(policy,flags);save()
    with (folder/(a.mode+'-1.log')).open('wb') as log:
        child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=flags);r['child_pid']=child.pid;save();status=child.wait()
r.update(state='TERMINAL',exit_code=status);r.pop('child_pid',None)
if (out/'manifest.json').is_file():
    verify=subprocess.run([sys.executable,str(source/'scripts/hyle-perf.py'),'verify','--contract',str(contract),'--manifest',str(out/'manifest.json')],env=env,capture_output=True,text=True)
    (folder/(a.mode+'-verify-1.log')).write_bytes((verify.stdout+verify.stderr).encode());r['verify_exit_code']=verify.returncode
save();print(json.dumps({k:v for k,v in r.items() if k not in ['command','applied_parent_sampling_policy','inherited_child_canary']}));raise SystemExit(status)
