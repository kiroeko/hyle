from pathlib import Path
import hashlib,json,time
import numpy as np
out=Path(__file__).resolve().parent/'g08-readonly-intake';start=time.monotonic()
rng=np.random.default_rng(20261016);hi=rng.integers(0,2**32,size=2**20,dtype=np.uint32);lo=rng.integers(0,2**32,size=2**20,dtype=np.uint32)
edge=[0,1,2,3,7,127,255,65535,2**23-1,2**24-1,2**31-1,2**31,2**32-2,2**32-1]
hi=np.concatenate([hi,np.repeat(np.array(edge,dtype=np.uint32),len(edge))]);lo=np.concatenate([lo,np.tile(np.array(edge,dtype=np.uint32),len(edge))])
upper=hi>=np.uint32(2**31);part_hi=np.where(upper,~hi,hi);part_lo=np.where(upper,~lo,lo)
# Interpret the exact open-interval midpoint through the smaller side, never
# subtract a rounded single-precision U from one.
small=(np.ldexp(part_hi.astype(np.float32),-32)+np.ldexp(part_lo.astype(np.float32)+np.float32(.5),-64)).astype(np.float32)
assert np.all(small>0) and np.all(small<=.5)
e=np.empty_like(small);e[~upper]=-np.log(small[~upper])
v=small[upper];t=np.float32(1)-v;correction=np.empty_like(v);tiny=t==np.float32(1);correction[tiny]=v[tiny];correction[~tiny]=v[~tiny]*(np.log(t[~tiny])/(t[~tiny]-np.float32(1)))
e[upper]=correction;g=-np.log(e);assert np.all(np.isfinite(g))
exact_small=np.ldexp(part_hi.astype(np.float64),-32)+np.ldexp(part_lo.astype(np.float64)+.5,-64)
ref_e=np.empty_like(exact_small);ref_e[~upper]=-np.log(exact_small[~upper]);ref_e[upper]=-np.log1p(-exact_small[upper]);ref_g=-np.log(ref_e)
error=np.abs(g.astype(np.float64)-ref_g);assert float(np.max(error))<2e-5
r=dict(state='DIAGNOSTIC_NUMERICAL_FEASIBILITY_PASS_NOT_PRODUCT_ACCEPTANCE',samples=len(g),pair_word_midpoint='U=(hi*2^32+lo+0.5)*2^-64; evaluate the smaller of U and 1-U directly from original/complemented words',upper_exponential='-log1p(-v), compensated logarithm fallback when native log1p absent; t==1 uses v, otherwise v*log(t)/(t-1)',lower_exponential='-log(u)',f32_gumbel_max_abs_error_vs_independent_f64=float(error.max()),f32_error_p999=float(np.quantile(error,.999)),all_finite=True,endpoint_cases=len(edge)**2,lowest_midpoint=float(np.ldexp(.5,-64)),elapsed_seconds=time.monotonic()-start,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Feasibility check for CPU/CUDA/Metal/GLSL common integer inputs and stable transform; no vendor/device product executed. Does not prove categorical distribution or runtime determinism; those remain actual tests after AUDITED implementation.',limits=['NumPy ufunc/math is host diagnostic only, not actual native shader log accuracy.','Categorical must center logits before adding noise; finite common offsets otherwise erase F32 noise.','Counter raw words need exact mature known-answer and actual four-route checks.','Cross-backend bit-identical selected categorical IDs are not implied.'])
(out/'endpoint-probe.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(r,indent=2))
