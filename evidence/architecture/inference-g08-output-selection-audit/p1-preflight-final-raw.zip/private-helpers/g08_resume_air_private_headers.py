from pathlib import Path
import hashlib,io,json,subprocess,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g08-p1-gpu-compile-fixes-1';pin='85bcfa4ebc29cc4d2ed5fb122074204aca675d58';revision='47b63229d7e09afaa5c2e0f10f0ac5a4c5c7e953';paths=['src/compute_ops/view_alias.h','src/compute_provider_iree_vulkan/native_device.h','src/compute_provider_iree_vulkan/native_program.h'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for route in ['apple','vulkan']:
 source=base/('g08-p1-'+route)/'source';assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==revision
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=all'],text=True).strip()
source=base/'g08-p1-vulkan/source';log=out/'vulkan-sparse-private-headers.log';assert log.exists();assert not log.with_suffix('.retained.log').exists();log.with_suffix('.retained.log').write_bytes(log.read_bytes())
r=subprocess.run(['git','-C',str(source),'sparse-checkout','add','src/compute_ops','src/compute_provider_iree_vulkan'],capture_output=True,text=True);(out/'vulkan-sparse-private-headers-resume2.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
reference=source.parent/'reference85';identity=reference/'source-identity.json';record=json.loads(identity.read_text());before=(out/'vulkan-source-identity-before.json').read_bytes();assert identity.read_bytes()==before
payload=subprocess.check_output(['git','-C',str(source.parent/'original85'),'archive','--format=zip',pin,*paths]);added=[]
with zipfile.ZipFile(io.BytesIO(payload)) as z:
 for rel in paths:
  data=z.read(rel);assert (source/rel).read_bytes()==data,('shared private bridge changed',rel);assert not (reference/rel).exists() and not any(x['path']==rel for x in record['files'])
  target=reference/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);digest=hashlib.sha256(data).hexdigest();record['files'].append({'path':rel,'original_sha256':digest,'materialized_sha256':digest,'namespace_only':False});record['shared_private_headers'].append({'path':rel,'sha256':digest});added.append({'path':rel,'sha256':digest})
identity.write_text(json.dumps(record,indent=2)+'\n');(out/'vulkan-source-identity-after.json').write_bytes(identity.read_bytes())
result={'state':'ALL_LOCAL_GPU_COMPILE_FIX_SOURCES_READY','revision':revision,'retained_setup_failure':'Initial updater reached new frozen source HEAD then stopped because sparse checkout omitted three private headers; a pattern-form add was refused because checkout uses cone directories. Both logs retained. Added only the two required source directories, verified the three exact bridge bytes against original85; no build/sample or product change.','routes':{}}
for route in ['apple','vulkan']:
 source=base/('g08-p1-'+route)/'source';reference=source.parent/'reference85';record=json.loads((reference/'source-identity.json').read_text());job=json.loads((source.parent/'probe-job-setup-resume-1.json').read_text());assert job['state']=='TERMINAL' and job['exit_code']==1
 if route=='apple':assert record['compile_definitions']==['lower_tensor=g08_original_lower_tensor','lower_mature_indexing=g08_original_lower_mature_indexing','is_mlx_tensor_custom=g08_original_is_mlx_tensor_custom']
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=all'],text=True).strip()
 result['routes'][route]={'source':str(source),'retained_failed_seconds':job['cumulative_elapsed_seconds'],'same_build_tree':str(source.parent/'probe-build-setup-resume-1'),'original_source_identity_before_sha256':sha(out/(route+'-source-identity-before.json')),'original_source_identity_after_sha256':sha(reference/'source-identity.json'),'added_unchanged_shared_private_headers':added if route=='vulkan' else [],'compiled_original_tus_unchanged':record['compiled_original_sources'],'compile_definitions':record['compile_definitions'],'product_paths_changed':[]}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
