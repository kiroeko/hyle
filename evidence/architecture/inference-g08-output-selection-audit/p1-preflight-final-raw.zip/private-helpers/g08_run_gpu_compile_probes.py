from pathlib import Path
import json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[2];out=root/'.scratch/inference-gaps/g08-p1-gpu-probes-compile-resume-2';out.mkdir(exist_ok=False);r={'state':'RUNNING','pid':os.getpid(),'stage':'WAIT_CPU_PROBE_TERMINAL','cases':[],'retained_gpu_build_failures':{'path':'.scratch/inference-gaps/g08-p1-remaining-probes-resume-1','seconds':72.12023036699999,'scope':'Same three build trees and original objects retained; only finite CUDA include/Apple third symbol/Vulkan exact private bridge materialization fixed. No original probe reached numerical or performance sampling.'},'retained_dispatch_setup':{'path':'.scratch/inference-gaps/g08-p1-remaining-probes-1','elapsed_seconds':2.875,'failure':'Three delivery receipt paths were absent from sparse source checkouts; failed before any probe job/build/sample was created. Exact canonical receipt copied+SHA checked for Air; WSL uses canonical mounted receipt.'},'scope':'Finite diagnostic probes only, serial across Windows/WSL/Air. Retain CPU original14.016s setup failure and all configured trees. No formal qualification or product change.'};started=time.monotonic()
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
save();cpu=Path('C:/h7/g08-p1-cpu/probe-job-setup-resume-1.json')
while True:
 current=json.loads(cpu.read_text())
 if current['state']=='TERMINAL':break
 assert current['state']=='RUNNING'
 try:
  import ctypes
  handle=ctypes.windll.kernel32.OpenProcess(0x1000,False,current['pid']);assert handle,'CPU controller disappeared before terminal record';ctypes.windll.kernel32.CloseHandle(handle)
 except Exception as e:r.update(state='WAIT_FAILED',error=repr(e));save();raise
 save();time.sleep(5)
r['cpu_observed']={k:current.get(k) for k in ['state','source_revision','exit_code','verify_exit_code','cumulative_elapsed_seconds']};save()
revision='47b63229d7e09afaa5c2e0f10f0ac5a4c5c7e953';base='/Users/kiro/hyle-scratch/compute-unified/'
commands=[('cuda',['wsl','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g08_run_p1.py','--route','cuda','--mode','probe','--compile-resume','2','--delivery-proof','/mnt/c/public/project-hyle/hyle/evidence/delivery/inference-g08-sdk-final/receipt.json','--revision',revision])]
for route in ['apple','vulkan']:
 command='python3 '+base+'g08_run_p1.py --route '+route+' --mode probe --compile-resume 2 --delivery-proof '+base+'g08-sdk-final-receipt.json --revision '+revision
 commands.append((route,['ssh','kiro@172.22.10.198',command]))
for route,command in commands:
 r['stage']=route+'_DIAGNOSTIC_PROBE';save();print(r['stage'],flush=True)
 with (out/(route+'.log')).open('wb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=child.pid;save();status=child.wait()
 r['cases'].append({'route':route,'exit_code':status,'log':route+'.log'});r.pop('child_pid',None);save()
r['state']='TERMINAL_ALL_THREE_DIAGNOSTIC_PROBES_OBSERVED';save();print(json.dumps(r))
