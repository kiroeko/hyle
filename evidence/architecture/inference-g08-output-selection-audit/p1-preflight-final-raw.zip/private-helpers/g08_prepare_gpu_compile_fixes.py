from pathlib import Path
import argparse,hashlib,io,json,subprocess,sys,time,zipfile
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--revision',required=True);a=p.parse_args();air=sys.platform=='darwin';assert air or sys.platform=='linux'
base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified';out=base/'g08-p1-gpu-compile-fixes-1';out.mkdir(exist_ok=False);pin='85bcfa4ebc29cc4d2ed5fb122074204aca675d58';old='5fbc13992137af26d0766f026415d5a80c7f2dd8';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r={'state':'RUNNING','revision':a.revision,'routes':{}};started=time.monotonic()
if air:assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
for route in (['apple','vulkan'] if air else ['cuda']):
 folder=base/('g08-p1-'+route);source=folder/'source';reference=folder/'reference85';git=lambda args:subprocess.check_output(['git','-C',str(source),*args],text=True,stderr=subprocess.PIPE).strip()
 assert git(['rev-parse','HEAD'])==old and not git(['status','--porcelain','--untracked-files=all'])
 job=json.loads((folder/'probe-job-setup-resume-1.json').read_text());assert job['state']=='TERMINAL' and job['exit_code']==1
 for stage,args in [('fetch',['fetch',str(a.bundle),'HEAD']),('fast-forward',['merge','--ff-only','FETCH_HEAD'])]:
  result=subprocess.run(['git','-C',str(source),*args],capture_output=True,text=True);(out/(route+'-'+stage+'.log')).write_text(result.stdout+result.stderr);assert result.returncode==0,(route,stage)
 assert git(['rev-parse','HEAD'])==a.revision and not git(['status','--porcelain','--untracked-files=all'])
 assert not git(['diff','--name-only',old,a.revision,'--','include','src','cmake','third_party','scripts'])
 identity=reference/'source-identity.json';before=identity.read_bytes();record=json.loads(before);assert record['original_revision']==pin and record['route']==route
 (out/(route+'-source-identity-before.json')).write_bytes(before);added=[]
 if route=='apple':
  definition='is_mlx_tensor_custom=g08_original_is_mlx_tensor_custom';assert definition not in record['compile_definitions'];record['compile_definitions'].append(definition)
 elif route=='vulkan':
  paths=['src/compute_ops/view_alias.h','src/compute_provider_iree_vulkan/native_device.h','src/compute_provider_iree_vulkan/native_program.h']
  payload=subprocess.check_output(['git','-C',str(folder/'original85'),'archive','--format=zip',pin,*paths])
  with zipfile.ZipFile(io.BytesIO(payload)) as z:
   for rel in paths:
    data=z.read(rel);assert (source/rel).read_bytes()==data,('shared private bridge changed',rel);assert not (reference/rel).exists() and not any(row['path']==rel for row in record['files'])
    target=reference/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);digest=hashlib.sha256(data).hexdigest()
    record['files'].append({'path':rel,'original_sha256':digest,'materialized_sha256':digest,'namespace_only':False});record['shared_private_headers'].append({'path':rel,'sha256':digest});added.append({'path':rel,'sha256':digest})
 if route!='cuda':identity.write_text(json.dumps(record,indent=2)+'\n')
 (out/(route+'-source-identity-after.json')).write_bytes(identity.read_bytes())
 r['routes'][route]={'state':'CLEAN_SOURCE_AND_EXACT_ORIGINAL_REFERENCE_READY','source':str(source),'retained_failed_seconds':job['cumulative_elapsed_seconds'],'same_build_tree':str(folder/'probe-build-setup-resume-1'),'original_source_identity_before_sha256':hashlib.sha256(before).hexdigest(),'original_source_identity_after_sha256':sha(identity),'added_unchanged_shared_private_headers':added,'compiled_original_tus_unchanged':record['compiled_original_sources'],'compile_definitions':record['compile_definitions'],'product_paths_changed':[]}
r.update(state='ALL_LOCAL_GPU_COMPILE_FIX_SOURCES_READY',elapsed_seconds=time.monotonic()-started);(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
