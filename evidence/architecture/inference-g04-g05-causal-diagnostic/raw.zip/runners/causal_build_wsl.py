from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
work=Path('/root/hyle-scratch/compute-unified/g04-causal-diagnostic-1');work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
setup=json.loads((out/'setup.json').read_text());sdk=Path(setup['prefix']);oldbuild=Path(setup['old_consumer_build'])
old=json.loads((root/'evidence/correctness/inference-g04-g05-cuda-ce28-direct-stage-numeric-rebind/receipt.json').read_text())['successful_run']
artifacts=json.loads((root/'.scratch/inference-gaps/g06/final-sdk/artifacts-cuda-static-1.json').read_text())
for x in artifacts:assert sha(Path(x['path']))==x['sha256'],x['path']
public=json.loads((root/'.scratch/inference-gaps/g06/final-sdk/public-inputs-cuda-static-1.json').read_text())
for x in public['headers']:
 assert sha(sdk/'include/hyle'/x['path'])==x['sha256']
 assert sha(root/'include/hyle'/x['path'])==x['sha256']
delta=subprocess.check_output(['git','-C',str(root),'diff','--name-only','73fc7b6abaf96a5e9f9732f78d3617b41365c54f','HEAD','--','src','include'],text=True).splitlines()
assert set(delta)<=set(['src/graph/lease_submission.cc','src/graph/leased_invocation.cc','src/graph/submission_internal.h']),delta
for row in old['actual_original_headers']:assert sha(Path(row['path']))==row['sha256']
for x in old['snapshot']['benchmark_inputs']:
 if (root/x['path']).is_file() and not x['path'].endswith('contract.json'):
  assert sha(root/x['path'])==x['sha256'],x['path']
dep=subprocess.check_output(['ninja','-C',str(oldbuild),'-t','deps'],text=True)
object_path=Path(setup['old_object_candidates'][0]);assert object_path.exists()
original=oldbuild/'original-peer/libg04_cuda_encoded_original.a';nano=oldbuild/'original-peer/libg04_cuda_encoded_nanobench.a'
for relative in ['bench/inference_resident_sdpa/cuda_encoded_page_bench.cc','bench/inference_resident_sdpa/cuda_encoded_page_reference.cc','bench/inference_resident_sdpa/cuda_encoded_page_reference.h','bench/inference_resident_sdpa/cuda_encoded_page_native.h','bench/common/perf_process.h']:
 target=work/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/relative).read_bytes())
p=work/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc';text=p.read_text()
text=text.replace('#include <vector>','#include <vector>\n#include <nvtx3/nvToolsExt.h>')
text=text.replace('namespace c=hyle::compute;namespace nb=ankerl::nanobench;', '''namespace c=hyle::compute;namespace nb=ankerl::nanobench;
bool diagnostic_trace=false;
void push(const char *s){if(diagnostic_trace)nvtxRangePushA(s);}
void pop(){if(diagnostic_trace)nvtxRangePop();}''')
before='''  c::ReadLease execute(){auto &slot=slots[next++%slots.size()];auto prepared=take(slot.update_batch(layout));if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));
    auto completion=take(prepared.run(query,key_frame,value_frame));check(completion.wait());return take(slot.output());}'''
after='''  c::ReadLease execute(){auto &slot=slots[next++%slots.size()];
    push("update");auto prepared=take(slot.update_batch(layout));pop();
    if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));
    push("admit_submit");auto completion=take(prepared.run(query,key_frame,value_frame));pop();
    push("checked_wait");check(completion.wait());pop();
    push("output_acquire");auto output=take(slot.output());pop();return output;}'''
assert before in text;text=text.replace(before,after)
begin=text.index('  for(int i=0;i<4;++i){auto a=candidate->execute();')
end=text.index('\n}\n}\nint main',begin)
replacement='''  if(set("HYLE_BENCH_VERIFY_ONLY"))return;
  const char *shape=window>=0?"window":(dk==256?"prefill":"holdout");
  diagnostic_trace=false;
  for(unsigned i=0;i<64;++i){auto a=candidate->execute();auto b=peer->execute();nb::doNotOptimizeAway(a);nb::doNotOptimizeAway(b);}
  diagnostic_trace=set("HYLE_DIAG_TRACE");push(shape);
  const bool peer_first=set("HYLE_BENCH_RIVAL_FIRST");
  for(unsigned group=0;group<8;++group){
    double elapsed[2]{};
    for(unsigned step=0;step<64;++step)for(unsigned order=0;order<2;++order){
      const unsigned side=peer_first?1-order:order;
      auto &h=side?*peer:*candidate;
      const auto start=std::chrono::steady_clock::now();push(side?"peer.episode":"candidate.episode");
      {auto output=h.execute();nb::doNotOptimizeAway(output);push("output_release");output.reset();pop();}
      pop();elapsed[side]+=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    }
    std::printf("# CAUSAL_DIAG shape=%s group=%u trace=%d candidate_us=%.9f peer_us=%.9f\\n",shape,group,diagnostic_trace,elapsed[0]*1e6/64,elapsed[1]*1e6/64);
  }
  pop();diagnostic_trace=false;
  candidate->verify(data,expected);peer->verify(data,expected);'''
text=text[:begin]+replacement+text[end:];p.write_text(text)
# The original nanobench experiment function stays compiled but is never called.
cmake='''cmake_minimum_required(VERSION 3.25)
project(g04_causal_diagnostic LANGUAGES C CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
add_executable(diag bench/inference_resident_sdpa/cuda_encoded_page_bench.cc bench/inference_resident_sdpa/cuda_encoded_page_reference.cc)
target_compile_features(diag PRIVATE cxx_std_23)
target_include_directories(diag PRIVATE "@ROOT@/src/compute_backend_cuda" "/usr/local/cuda-13.3/include" "@ROOT@/third_party/nanobench")
target_compile_options(diag PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_link_libraries(diag PRIVATE hyle::compute "@ORIGINAL@" "@NANO@" CUDA::cudart dl)
set_property(TARGET diag PROPERTY INTERPROCEDURAL_OPTIMIZATION FALSE)
hyle_stage_runtime(diag)
'''.replace('@ROOT@',str(root)).replace('@ORIGINAL@',str(original)).replace('@NANO@',str(nano))
(work/'CMakeLists.txt').write_text(cmake)
r=dict(state='D0_VERIFIED_BUILDING',work=str(work),prefix=str(sdk),sdk_artifacts_verified=len(artifacts),headers_verified=len(public['headers']),
 source_delta_from_g06_sdk=delta,original_headers_verified=len(old['actual_original_headers']),
 reused_reference_object={'path':str(object_path),'sha256':sha(object_path)},
 reused_libraries=[{'path':str(x),'sha256':sha(x)} for x in [original,nano]],
 consumer_inputs=[{'path':str(x.relative_to(work)),'sha256':sha(x)} for x in work.rglob('*') if x.is_file()],stages=[])
def save():(out/'build.json').write_text(json.dumps(r,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
for name,cmd in [('configure',['cmake','-S',str(work),'-B',str(work/'build'),'-G','Ninja','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_C_COMPILER=gcc-14','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk)]),('compile',['cmake','--build',str(work/'build'),'--parallel','2','--target','diag'])]:
 save();start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:code=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['stages'].append(dict(name=name,command=cmd,exit=code,seconds=time.monotonic()-start));save()
 if code:r['state']='SETUP_FAIL';save();raise RuntimeError(name+' failed')
binary=work/'build/diag';r.update(state='D0_BUILT',binary={'path':str(binary),'sha256':sha(binary)})
save();print('D0_BUILT',json.dumps(r['stages']))
