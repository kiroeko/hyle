from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
r=json.loads((out/'build.json').read_text());work=Path(r['work']);binary=Path(r['binary']['path'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=work/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc';s=p.read_text()
before='  measure(1,17,1024,768,256,256,true,16);measure(64,128,1024,768,256,256,true,-1);measure(17,1,7,47,64,128,false,-1);'
after='''  const auto all_shapes=[](){measure(1,17,1024,768,256,256,true,16);measure(64,128,1024,768,256,256,true,-1);measure(17,1,7,47,64,128,false,-1);};
  if(set("HYLE_DIAG_MATRIX")){
    for(unsigned alloc=0;alloc<2;++alloc)for(unsigned order=0;order<2;++order){
      if(alloc)setenv("HYLE_BENCH_PEER_ALLOCATION_FIRST","1",1);else unsetenv("HYLE_BENCH_PEER_ALLOCATION_FIRST");
      if(order)setenv("HYLE_BENCH_RIVAL_FIRST","1",1);else unsetenv("HYLE_BENCH_RIVAL_FIRST");
      diagnostic_trace=true;push(alloc?(order?"PF_PF":"CF_PF"):(order?"PF_CF":"CF_CF"));
      all_shapes();diagnostic_trace=true;pop();diagnostic_trace=false;
    }
  }else all_shapes();'''
if before in s:s=s.replace(before,after);p.write_text(s)
else:assert after in s
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['CUDA_VISIBLE_DEVICES']='0'
env.pop('HYLE_PERF_CALLER_CPU',None)
available=os.sched_getaffinity(0);caller_cpu=2 if 2 in available else min(available);os.sched_setaffinity(0,{caller_cpu})
for name in ['HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_AA_ROUTE','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_RUN_NONCE','HYLE_DIAG_TRACE','HYLE_DIAG_MATRIX']:env.pop(name,None)
prior=json.loads((out/'d1.json').read_text()) if (out/'d1.json').exists() else None
if prior:
 assert prior['state']=='TERMINAL_FAIL' and prior['active_stage']=='current-oracle'
 (out/'d1-host-affinity-setup-failure.json').write_text(json.dumps(prior,indent=2)+'\n')
 (out/'current-oracle.log').rename(out/'current-oracle-host-affinity-failure.log')
result=dict(state='D1_SETUP',commands=[],controls=[],binary_initial=r['binary'],sdk_binding='build.json',caller_cpu=caller_cpu,setup_failure='d1-host-affinity-setup-failure.json' if prior else None)
def save():(out/'d1.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,command,extra=None):
 local=env.copy();local.update(extra or {});start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  child=subprocess.Popen(command,env=local,stdout=f,stderr=subprocess.STDOUT)
  result.update(state='RUNNING',active_stage=name,active_pid=child.pid);save();print(name,child.pid,flush=True);code=child.wait()
 row=dict(name=name,command=command,environment_changes=extra or {},exit=code,seconds=time.monotonic()-start)
 result['commands'].append(row);save();print(name,code,round(row['seconds'],3),flush=True)
 if code:result['state']='TERMINAL_FAIL';save();raise RuntimeError(name+' failed')
 return (out/(name+'.log')).read_text()
run('host-label-build',['cmake','--build',str(work/'build'),'--parallel','2','--target','diag'])
result['binary']={'path':str(binary),'sha256':sha(binary)};save()
oracle=run('current-oracle',[str(binary)],{'HYLE_BENCH_VERIFY_ONLY':'1'})
errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',oracle)]
assert len(errors)==24 and max(errors)<=8e-3
result['oracle']={'observations':len(errors),'max_abs_error':max(errors),'readonly':'PASS'};save()
for route in ['selected','native','AB']:
 for alloc in range(2):
  for order in range(2):
   changes={}
   if route!='AB':changes['HYLE_BENCH_AA_ROUTE']=route
   if alloc:changes['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'
   if order:changes['HYLE_BENCH_RIVAL_FIRST']='1'
   text=run('short-'+route+'-a'+str(alloc)+'-o'+str(order),[str(binary)],changes)
   rows=[dict(shape=m[0],group=int(m[1]),candidate_us=float(m[2]),peer_us=float(m[3])) for m in re.findall(r'CAUSAL_DIAG shape=(\w+) group=(\d+) trace=0 candidate_us=([^ ]+) peer_us=([^\n]+)',text)]
   assert len(rows)==24
   errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)];assert len(errors)==30 and max(errors)<=8e-3
   result['controls'].append(dict(route=route,allocation=alloc,order=order,groups=rows,max_abs_error=max(errors)));save()
command=['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--export=sqlite','--force-overwrite=false','--output='+str(work/'timeline'),str(binary)]
text=run('current-timeline',command,{'HYLE_DIAG_TRACE':'1','HYLE_DIAG_MATRIX':'1'})
errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)];assert len(errors)==120 and max(errors)<=8e-3
assert len(re.findall(r'CAUSAL_DIAG shape=',text))==96
assert sha(binary)==result['binary']['sha256']
result.update(state='D1_CAPTURED_NOT_P1',timeline={'sqlite':str(work/'timeline.sqlite'),'sqlite_sha256':sha(work/'timeline.sqlite'),'report':str(work/'timeline.nsys-rep')},max_abs_error=max(errors),native_recompiles=0)
result.pop('active_pid',None);result.pop('active_stage',None);save();print('D1_CAPTURED_NOT_P1',flush=True)
