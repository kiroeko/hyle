from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
build=json.loads((out/'d3-build.json').read_text());assert build['state']=='D3_BUILT'
binary=Path(build['binary']['path']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(binary)==build['binary']['sha256']
env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='0';cpu=json.loads((out/'d1.json').read_text())['caller_cpu'];os.sched_setaffinity(0,{cpu})
for key in ['HYLE_PERF_CALLER_CPU','HYLE_DIAG_TRACE','HYLE_DIAG_MATRIX','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_AA_ROUTE','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_RUN_NONCE']:env.pop(key,None)
r=dict(state='D3_SETUP',binary=build['binary'],experiments=[],commands=[])
save=lambda:(out/'d3.json').write_text(json.dumps(r,indent=2)+'\n')
def run(name,cmd,changes):
 local=env.copy();local.update(changes);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  child=subprocess.Popen(cmd,env=local,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',active_stage=name,pid=child.pid);save();print(name,child.pid,flush=True);code=child.wait()
 row=dict(name=name,command=cmd,environment=changes,exit=code,seconds=time.monotonic()-start);r['commands'].append(row);save()
 if code:r['state']='TERMINAL_FAIL';save();raise RuntimeError(name+' failed')
 return (out/(name+'.log')).read_text()
for variant in ['bf16-f32','fp8-bf16']:
 extra={'HYLE_CAUSAL_VARIANT':variant}
 oracle=run(variant+'-oracle',[str(binary)],dict(extra,HYLE_BENCH_VERIFY_ONLY='1'))
 errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',oracle)]
 assert len(errors)==8 and max(errors)<=8e-3
 e=dict(variant=variant,oracle_max_abs_error=max(errors),controls=[]);r['experiments'].append(e);save()
 memcheck=run(variant+'-memcheck',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','86',str(binary)],dict(extra,HYLE_BENCH_VERIFY_ONLY='1'))
 assert 'ERROR SUMMARY: 0 errors' in memcheck
 e['memcheck']='PASS';save()
 for route in ['selected','native','AB']:
  for alloc in range(2):
   for order in range(2):
    changes=extra.copy()
    if route!='AB':changes['HYLE_BENCH_AA_ROUTE']=route
    if alloc:changes['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'
    if order:changes['HYLE_BENCH_RIVAL_FIRST']='1'
    text=run(variant+'-'+route+'-a'+str(alloc)+'-o'+str(order),[str(binary)],changes)
    errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)];assert len(errors)==10 and max(errors)<=8e-3
    rows=[dict(group=int(x[0]),candidate_us=float(x[1]),peer_us=float(x[2])) for x in re.findall(r'CAUSAL_DIAG shape=prefill group=(\d+) trace=0 candidate_us=([^ ]+) peer_us=([^\n]+)',text)]
    assert len(rows)==8
    e['controls'].append(dict(route=route,allocation=alloc,order=order,groups=rows));save()
 report=binary.parent.parent/('timeline-'+variant)
 command=['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--export=sqlite','--force-overwrite=false','--output='+str(report),str(binary)]
 text=run(variant+'-timeline',command,dict(extra,HYLE_DIAG_TRACE='1',HYLE_DIAG_MATRIX='1'))
 errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)];assert len(errors)==40 and max(errors)<=8e-3
 e['timeline']={'sqlite':str(report.with_suffix('.sqlite')),'sha256':sha(report.with_suffix('.sqlite')),'report':str(report.with_suffix('.nsys-rep'))};save()
r.update(state='D3_TWO_VARIANTS_CAPTURED_DIAGNOSTIC_ONLY');r.pop('pid',None);r.pop('active_stage',None);save();print(r['state'],flush=True)
