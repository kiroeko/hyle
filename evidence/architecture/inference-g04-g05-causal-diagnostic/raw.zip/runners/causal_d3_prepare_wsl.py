from pathlib import Path
import hashlib,json,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
info=json.loads((out/'build.json').read_text());work=Path(info['work']);record=json.loads((root/'.scratch/inference-gaps/g04-g05/ce28-fixed-codegen-1/result.json').read_text())
header=Path(record['header']);assert hashlib.sha256(header.read_bytes()).hexdigest()==record['header_sha256']
scheduler=header.parent/'scheduler.cuh';text=scheduler.read_text()
for name in ['PrefillPlanWorkspaceSize(','PrefillPlan(']:
 i=text.index(name);print(text[i:i+1400])
print('HEADER_DIR',header.parent.parent)
