from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
d1=json.loads((out/'d1.json').read_text());assert d1['state']=='D1_CAPTURED_NOT_P1'
binary=Path(d1['binary']['path']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(binary)==d1['binary']['sha256']
work=binary.parent.parent;report=work/'attention-counters'
env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='0';env['HYLE_DIAG_TRACE']='1'
for key in ['HYLE_PERF_CALLER_CPU','HYLE_DIAG_MATRIX','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_AA_ROUTE','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_RUN_NONCE']:env.pop(key,None)
os.sched_setaffinity(0,{d1['caller_cpu']})
sections=['LaunchStats','Occupancy','SpeedOfLight','SchedulerStats','WarpStateStats','MemoryWorkloadAnalysis','InstructionStats','SourceCounters']
command=['/usr/local/cuda-13.3/bin/ncu','--target-processes','all','--kernel-name-base','demangled','--kernel-name','regex:.*BatchPrefillWithPagedKVCacheKernel.*','--launch-count','2','--nvtx','--nvtx-include','prefill/','--cache-control','none','--clock-control','none','--export',str(report)]
for s in sections:command+=['--section',s]
command+=[str(binary)]
r=dict(state='SETUP',purpose='ONE_TARGETED_TWO_KERNEL_PREFILL_COUNTER_COLLECTION_NOT_P1',command=command,binary=d1['binary'],sections=sections)
save=lambda:(out/'d2.json').write_text(json.dumps(r,indent=2)+'\n')
save();start=time.monotonic()
with (out/'d2-profile.log').open('w') as f:
 p=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',pid=p.pid);save();print('D2_STARTED',p.pid,flush=True);code=p.wait()
r.update(state='CAPTURE_EXIT_'+str(code),exit_code=code,seconds=time.monotonic()-start);r.pop('pid',None);save()
assert code==0,'Counter capture failed; do not retry or rebuild tools'
assert report.with_suffix('.ncu-rep').is_file()
export=['/usr/local/cuda-13.3/bin/ncu','--import',str(report.with_suffix('.ncu-rep')),'--page','raw','--csv']
with (out/'d2-metrics.csv').open('w') as f:code=subprocess.call(export,stdout=f,stderr=subprocess.STDOUT)
assert code==0
r.update(state='D2_CAPTURED_DIAGNOSTIC_ONLY',report={'path':str(report.with_suffix('.ncu-rep')),'sha256':sha(report.with_suffix('.ncu-rep'))},metrics_sha256=sha(out/'d2-metrics.csv'))
save();print('D2_CAPTURED',round(r['seconds'],3),flush=True)
