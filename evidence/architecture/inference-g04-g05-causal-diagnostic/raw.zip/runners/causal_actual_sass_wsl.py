from pathlib import Path
import hashlib,json,re,sqlite3,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
d3=json.loads((out/'d3.json').read_text());binary=Path(d3['binary']['path']);names={}
for e in d3['experiments']:
 db=sqlite3.connect(Path(e['timeline']['sqlite']).as_uri()+'?mode=ro',uri=True)
 for m,d in db.execute('select distinct m.value,d.value from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds m on k.mangledName=m.id join StringIds d on k.demangledName=d.id'):
  if 'BatchPrefillWithPagedKVCacheKernel' not in d:continue
  key=e['variant'] if 'hyle_causal_flashinfer_private' in d else 'current_fp8_f32'
  if key in names:assert names[key]['mangled']==m
  names[key]={'mangled':m,'demangled':d}
assert set(names)=={'current_fp8_f32','bf16-f32','fp8-bf16'}
command=['/usr/local/cuda-13.3/bin/cuobjdump','--dump-sass','--function',','.join(x['mangled'] for x in names.values()),str(binary)]
start=time.monotonic()
with (out/'actual-attention-sass.txt').open('w') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT)
assert code==0
counts={};current=None;lookup={x['mangled']:k for k,x in names.items()}
for line in (out/'actual-attention-sass.txt').read_text().splitlines():
 m=re.search(r'Function\s*:\s*(\S+)',line)
 if m:current=lookup.get(m[1]);counts.setdefault(current,{})
 if current:
  m=re.search(r'/\*[0-9a-fA-F]+\*/\s+(?:@!?P\d+\s+)?([A-Z][A-Z0-9_]*(?:\.[A-Z0-9_]+)*)',line)
  if m:
   op=m[1];counts[current][op]=counts[current].get(op,0)+1
assert set(counts)==set(names)
kind=lambda ops,p:sum(n for op,n in ops.items() if op.split('.')[0]==p)
r={'state':'READ_ONLY_ACTUAL_GENERATED_INSTRUCTIONS_NOT_DYNAMIC_COUNTERS','command':command,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
 'kernels':[dict(route=k,**names[k],static_instructions=v,total_static_instructions=sum(v.values()),selected_instruction_counts={p:kind(v,p) for p in ['LDG','LDGSTS','LDS','STS','STG','PRMT','LOP3','HFMA2','HMMA','F2F','BAR','LDL','STL']}) for k,v in counts.items()],
 'limits':['Static instruction inventory is not executed instruction count, stalls or a cycle attribution.','Same live D3 binary and kernels verified through runtime dispatch names; no new GPU experiment.']}
(out/'actual-sass.json').write_text(json.dumps(r,indent=2)+'\n')
for k in r['kernels']:print(k['route'],k['total_static_instructions'],k['selected_instruction_counts'])
