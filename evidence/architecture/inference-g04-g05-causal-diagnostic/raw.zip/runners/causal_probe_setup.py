from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/mnt/c/public/project-hyle/hyle')
out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def cmd(args):return subprocess.check_output(args,text=True,stderr=subprocess.STDOUT).strip()
sdk=json.loads((root/'evidence/correctness/inference-g06-final-relocated-sdk/receipt.json').read_text())
cuda=next(x for x in sdk['configurations'] if x['route']=='cuda' and x['mode']=='static')
manifest=json.loads((root/'.scratch/inference-gaps/g06/sdk-artifact-recheck-cuda-static-1.json').read_text())
old=json.loads((root/'evidence/correctness/inference-g04-g05-cuda-ce28-direct-stage-numeric-rebind/receipt.json').read_text())['successful_run']
build=Path(old['binary']['path']).parent.parent
r={'state':'D0_INVENTORY','head':cmd(['git','-C',str(root),'rev-parse','HEAD']),
   'prefix':cuda['prefix'],'producer':cuda['producer'],'sdk_manifest_keys':list(manifest),
   'sdk_receipt_sha256':sha(root/'evidence/correctness/inference-g06-final-relocated-sdk/receipt.json'),
   'old_consumer_build':str(build),'old_binary_exists':Path(old['binary']['path']).exists(),
   'tools':{k:shutil.which(k) for k in ['g++-14','cmake','ninja','nsys','ncu','nvidia-smi']},
   'gpu':cmd(['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap,utilization.gpu,memory.used','--format=csv,noheader']),
   'gpu_processes':cmd(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader']),
   'processes':cmd(['ps','-eo','pid,comm,args'])[-20000:],
   'old_object_candidates':[str(p) for p in build.rglob('*cuda_encoded_page_native*') if p.is_file()],
   'nvtx_headers':[str(p) for parent in [Path('/usr/local/cuda-13.3/include'),Path('/opt/nvidia/nsight-systems')] if parent.exists() for p in parent.rglob('nvToolsExt.h')][:8]}
(out/'setup.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ['processes','nvtx_headers']},indent=2))
