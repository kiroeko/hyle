from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
p=out/'d3-build.json';r=json.loads(p.read_text());assert r['state']=='SETUP_FAIL'
work=Path(r['work']);cmake=work/'CMakeLists.txt';s=cmake.read_text();before='target_compile_options(diag PRIVATE -Wall -Wextra -Wpedantic -Werror)'
assert before in s;s=s.replace(before,'target_compile_options(diag PRIVATE $<$<COMPILE_LANGUAGE:CXX>:-Wall;-Wextra;-Wpedantic;-Werror>)');cmake.write_text(s)
(out/'cf-compile.log').rename(out/'cf-compile-host-flags-setup-failure.log')
r['setup_failures']=['Native compile rejected host-only -Werror forwarded to nvcc; corrected only disposable consumer CMake language scoping.','Initial private source generator namespace spelling assertion failed before configure; corrected exact source alias.']
command=['cmake','--build',str(work/'build'),'--parallel','2','--target','diag'];env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
save=lambda:p.write_text(json.dumps(r,indent=2)+'\n')
start=time.monotonic()
with (out/'cf-compile-resume.log').open('w') as f:
 child=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',active_stage='cf-compile-resume',pid=child.pid);save();print('CF_BUILD_RESUME',child.pid,flush=True);code=child.wait()
r['stages'].append(dict(name='cf-compile-resume',command=command,exit=code,seconds=time.monotonic()-start));save()
assert code==0
r.update(state='D3_BUILT',binary={'path':str(work/'build/diag'),'sha256':hashlib.sha256((work/'build/diag').read_bytes()).hexdigest()});r.pop('pid',None);r.pop('active_stage',None);save();print('D3_BUILT',flush=True)
