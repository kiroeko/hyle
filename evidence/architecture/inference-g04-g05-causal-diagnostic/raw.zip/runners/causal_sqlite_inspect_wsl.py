from pathlib import Path
import json,sqlite3,subprocess
work=Path('/root/hyle-scratch/compute-unified/g04-causal-diagnostic-1')
db=sqlite3.connect((work/'timeline.sqlite').as_uri()+'?mode=ro',uri=True)
for table in ['NVTX_EVENTS','CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_RUNTIME']:
 print(table,db.execute('pragma table_info('+table+')').fetchall())
print('NVTX_SAMPLE',db.execute('select * from NVTX_EVENTS limit 4').fetchall())
print('NCU',subprocess.check_output(['/usr/local/cuda-13.3/bin/ncu','--version'],text=True).strip())
