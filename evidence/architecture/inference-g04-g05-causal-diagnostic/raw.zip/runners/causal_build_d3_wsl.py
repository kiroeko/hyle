from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
base=Path('/root/hyle-scratch/compute-unified/g04-causal-diagnostic-1')
work=Path('/root/hyle-scratch/compute-unified/g04-causal-counterfactual-1');work.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=json.loads((out/'build.json').read_text());sdk=Path(binding['prefix'])
gen=json.loads((root/'.scratch/inference-gaps/g04-g05/ce28-fixed-codegen-1/result.json').read_text());header=Path(gen['header'])
assert sha(header)==gen['header_sha256']
for relative in ['bench/inference_resident_sdpa/cuda_encoded_page_bench.cc','bench/inference_resident_sdpa/cuda_encoded_page_reference.cc','bench/inference_resident_sdpa/cuda_encoded_page_reference.h','bench/inference_resident_sdpa/cuda_encoded_page_native.h','bench/common/perf_process.h']:
 p=work/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((base/relative).read_bytes())
p=work/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc';s=p.read_text()
sequence='measure(1,17,1024,768,256,256,true,16);measure(64,128,1024,768,256,256,true,-1);measure(17,1,7,47,64,128,false,-1);'
assert sequence in s;s=s.replace(sequence,'measure(64,128,1024,768,256,256,true,-1);');p.write_text(s)
native_header='''#pragma once
#include "cuda_encoded_page_native.h"
#include "native_batch.h"
namespace hyle::bench::resident::cuda_counterfactual {
using Spec=cuda_original::Spec;using Facts=cuda_original::Facts;
using BatchSpec=hyle::compute::flashinfer::native::BatchSpec;
bool uses_fp8();
void *create_plan();void destroy_plan(void *) noexcept;
cudaError_t workspace(Spec,const std::int32_t *,const std::int32_t *,cudaStream_t,Facts &);
cudaError_t plan(void *,Spec,const std::int32_t *,const std::int32_t *,void *,std::size_t,void *,void *,std::size_t,cudaStream_t,Facts &);
cudaError_t run(const void *,Spec,const void *,const void *,const void *,const void *,void *,void *,void *,cudaStream_t);
inline cudaError_t decode(const void *p,void *q,const std::uint32_t *valid,unsigned pages,unsigned page_size,unsigned heads,unsigned depth,float,cudaStream_t stream){
 return cuda_original::decode(p,q,valid,pages,page_size,heads,depth,1.F,stream);
}
}
'''
(work/'bench/inference_resident_sdpa/counterfactual_native.h').write_text(native_header)
(work/'bench/inference_resident_sdpa/native_batch.h').write_bytes((root/'src/compute_provider_flashinfer/native_batch.h').read_bytes())
p=work/'bench/inference_resident_sdpa/cuda_encoded_page_reference.cc';s=p.read_text();s='#include "counterfactual_native.h"\n'+s
assert 'namespace n=cuda_original;' in s
s=s.replace('namespace n=cuda_original;','namespace n=cuda_counterfactual;')
s=s.replace('s.context.data->expanded[0].view()', '(n::uses_fp8()?inputs[1].storage():mem::ConstBufferView(s.context.data->expanded[0].view()))')
s=s.replace('s.context.data->expanded[1].view()', '(n::uses_fp8()?inputs[2].storage():mem::ConstBufferView(s.context.data->expanded[1].view()))')
# Both carriers contain the exact unscaled decoded FP8 values. All scales stay
# at the same mathematical location as the current product.
p.write_text(s)
native=(root/'src/compute_provider_flashinfer/native_cache.cu').read_text()
native=native[:native.index('template<class Q,class KV,unsigned QK,unsigned VO>\ncudaError_t run_typed')]
native=native.replace('#include "native_batch.h"','#include "counterfactual_native.h"\n#include <cstdlib>\n#include <cstring>')
native=native.replace('#include <flashinfer/attention/default_prefill_params.cuh>','#define flashinfer hyle_causal_flashinfer_private\n#include <flashinfer/attention/default_prefill_params.cuh>')
native=native.replace('namespace hyle::compute::flashinfer::native {','namespace hyle::bench::resident::cuda_counterfactual {')
native=native.replace('    HYLE_CACHE_TILE(16);HYLE_CACHE_TILE(64);HYLE_CACHE_TILE(128);','    HYLE_CACHE_TILE(64);')
before='''  return spec.causal?launch<QK,VO,Paged,fi::MaskMode::kCausal>(params,plan,floating,stream):
                     launch<QK,VO,Paged,fi::MaskMode::kNone>(params,plan,floating,stream);'''
assert before in native;native=native.replace(before,'''  (void)spec;
  return launch<QK,VO,Paged,fi::MaskMode::kCausal>(params,plan,floating,stream);''')
a=native.index('  }else{\n    using Base=fi::BatchPrefillRaggedParams');b=native.index('\n  return status;\n}',a)
native=native[:a]+'  }else return cudaErrorNotSupported;'+native[b:]
native+='''
} // anonymous namespace
bool uses_fp8(){static const bool value=[](){const auto *v=std::getenv("HYLE_CAUSAL_VARIANT");
 if(!v || (std::strcmp(v,"bf16-f32") && std::strcmp(v,"fp8-bf16")))std::abort();
 return !std::strcmp(v,"fp8-bf16");}();return value;}
void *create_plan(){return new fi::PrefillPlanInfo;}
void destroy_plan(void *p) noexcept{delete static_cast<fi::PrefillPlanInfo*>(p);}
cudaError_t workspace(Spec s,const std::int32_t *q,const std::int32_t *k,cudaStream_t stream,Facts &f){
 return fi::PrefillPlanWorkspaceSize(f.floating,f.integer,const_cast<std::int32_t*>(q),const_cast<std::int32_t*>(k),s.query_rows,s.requests,s.query_heads,s.kv_heads,s.key_depth,s.value_depth,s.page_size,false,uses_fp8()?2:4,s.window,-1,false,0,0,stream,1);
}
cudaError_t plan(void *state,Spec s,const std::int32_t *q,const std::int32_t *k,void *floating,std::size_t fb,void *integer,void *host,std::size_t ib,cudaStream_t stream,Facts &f){
 auto &p=*static_cast<fi::PrefillPlanInfo*>(state);
 auto status=fi::PrefillPlan(floating,fb,integer,host,ib,p,const_cast<std::int32_t*>(q),const_cast<std::int32_t*>(k),s.query_rows,s.requests,s.query_heads,s.kv_heads,s.key_depth,s.value_depth,s.page_size,false,uses_fp8()?2:4,s.window,-1,false,0,0,stream,1);
 f.tile=unsigned(p.cta_tile_q);f.padded=unsigned(p.padded_batch_size);f.split=p.split_kv;return status;
}
cudaError_t run(const void *state,Spec s,const void *q,const void *k,const void *v,const void *metadata,void *o,void *floating,void *integer,cudaStream_t stream){
 const auto &p=*static_cast<const fi::PrefillPlanInfo*>(state);
 if(s.key_depth!=256 || s.value_depth!=256 || !s.causal || s.window!=-1 || !p.split_kv || p.cta_tile_q!=64)return cudaErrorNotSupported;
 BatchSpec spec{.query_heads=s.query_heads,.kv_heads=s.kv_heads,.qk_head_dim=s.key_depth,.value_head_dim=s.value_depth,.page_size=s.page_size,
 .query_rows=s.query_rows,.requests=s.requests,.query_indptr_offset=s.query_offset,.kv_indptr_offset=s.kv_offset,.page_indices_offset=s.indices_offset,.tail_offset=s.tails_offset,
 .scale=s.scale,.key_scale=.5F,.value_scale=2.F,.window_left=-1,.paged=true,.bfloat16=true,.fp8=uses_fp8(),.causal=true};
 if(uses_fp8())return run_output<__nv_bfloat16,__nv_fp8_e4m3,256,256,false>(p,spec,q,k,v,metadata,o,floating,integer,stream);
 return run_output<__nv_bfloat16,__nv_bfloat16,256,256,true>(p,spec,q,k,v,metadata,o,floating,integer,stream);
}
} // namespace
#undef flashinfer
'''
(work/'bench/inference_resident_sdpa/counterfactual_native.cu').write_text(native)
cmake=(base/'CMakeLists.txt').read_text().replace('project(g04_causal_diagnostic LANGUAGES C CXX)','project(g04_causal_diagnostic LANGUAGES C CXX CUDA)')
cmake+='''
target_sources(diag PRIVATE bench/inference_resident_sdpa/counterfactual_native.cu)
set_property(TARGET diag PROPERTY CUDA_ARCHITECTURES 89-real)
set_property(TARGET diag PROPERTY CUDA_STANDARD 20)
target_compile_options(diag PRIVATE $<$<COMPILE_LANGUAGE:CUDA>:--expt-relaxed-constexpr>)
target_include_directories(diag PRIVATE "@INCLUDE@")
'''.replace('@INCLUDE@',str(header.parent.parent.parent))
(work/'CMakeLists.txt').write_text(cmake)
r=dict(state='D3_HYPOTHESES_FIXED_BEFORE_BUILD',work=str(work),hypotheses=[
 {'id':'BF16_F32','change':'Only KV physical carrier changes: cold expand exact FP8 codes to unscaled BF16; retain F32 partial/merge, key .5 and final value scale2, fixed original FP8 planner geometry.','prediction':'If load/conversion explains the attention difference, BF16/F32 lowers attention time while F32 merge remains near current.','limits':'Extra readonly BF16 resident storage and cold conversion explicitly charged; diagnostic route cannot ship as native encoded KV.'},
 {'id':'FP8_BF16','change':'Keep original FP8 carrier but use BF16 partial/merge instead of F32; move value scale before partial BF16 rounding as the output representation requires.','prediction':'If intermediate representation explains the difference, BF16 partial lowers attention/store and merge time.','limits':'Lower intermediate precision/scale placement is a numerical contract change; finite-fixture oracle success cannot license product use.'}],
 d2_hardware_counter='ERR_NVGPUCTRPERM retained; no retry, tool rebuild or driver change. D3 uses actual phase difference and source/type mechanism; no stall-counter attribution claimed.',
 sources=[{'path':str(p.relative_to(work)),'sha256':sha(p)} for p in work.rglob('*') if p.is_file()],stages=[])
save=lambda:(out/'d3-build.json').write_text(json.dumps(r,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
for name,command in [('cf-configure',['cmake','-S',str(work),'-B',str(work/'build'),'-G','Ninja','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_C_COMPILER=gcc-14','-DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc','-DCMAKE_CUDA_HOST_COMPILER=g++-14','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk)]),('cf-compile',['cmake','--build',str(work/'build'),'--parallel','2','--target','diag'])]:
 save();start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  child=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(active_stage=name,pid=child.pid);save();print(name,child.pid,flush=True);code=child.wait()
 r['stages'].append(dict(name=name,command=command,exit=code,seconds=time.monotonic()-start));save()
 if code:r['state']='SETUP_FAIL';save();raise RuntimeError(name+' failed')
r.update(state='D3_BUILT',binary={'path':str(work/'build/diag'),'sha256':sha(work/'build/diag')});r.pop('pid',None);r.pop('active_stage',None);save();print('D3_BUILT',flush=True)
