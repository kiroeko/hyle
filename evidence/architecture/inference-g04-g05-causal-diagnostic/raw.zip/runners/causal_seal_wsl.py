from pathlib import Path
import datetime,hashlib,json,re,subprocess,time,zipfile
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
dest=root/'evidence/architecture/inference-g04-g05-causal-diagnostic';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda name:json.loads((out/name).read_text())
d0=load('build.json');d1=load('d1.json');d2=load('d2.json');build3=load('d3-build.json');d3=load('d3.json');a1=load('d1-analysis.json');a3=load('d3-analysis.json');sass=load('actual-sass.json')
assert d1['state']=='D1_CAPTURED_NOT_P1' and d3['state']=='D3_TWO_VARIANTS_CAPTURED_DIAGNOSTIC_ONLY'
assert d2['exit_code']==1 and 'ERR_NVGPUCTRPERM' in (out/'d2-profile.log').read_text()
assert len(d3['experiments'])==2 and all(x['memcheck']=='PASS' and x['oracle_max_abs_error']<=8e-3 for x in d3['experiments'])
for item in json.loads((root/'.scratch/inference-gaps/g06/final-sdk/artifacts-cuda-static-1.json').read_text()):assert sha(Path(item['path']))==item['sha256']
for row in d0['reused_libraries']:assert sha(Path(row['path']))==row['sha256']
for r in [d1['binary'],d3['binary']]:assert sha(Path(r['path']))==r['sha256']
for row in [d1['timeline']]+[x['timeline'] for x in d3['experiments']]:assert sha(Path(row['sqlite']))==row.get('sha256',row.get('sqlite_sha256'))
raw=[]
for p in out.iterdir():
 if p.is_file():raw.append((p,'private-records/'+p.name))
for p in (root/'.scratch/inference-gaps/g04-g05').glob('causal_*.py'):raw.append((p,'runners/'+p.name))
for label,work in [('current',Path(d0['work'])),('counterfactual',Path(build3['work']))]:
 for p in work.rglob('*'):
  if p.is_file() and (p.name=='CMakeLists.txt' or p.is_relative_to(work/'bench')):raw.append((p,'sources/'+label+'/'+str(p.relative_to(work))))
 for kind,args in [('commands',['ninja','-C',str(work/'build'),'-t','commands','diag']),('dependencies',['ninja','-C',str(work/'build'),'-t','deps'])]:
  p=out/(label+'-'+kind+'.txt');p.write_text(subprocess.check_output(args,text=True));raw.append((p,'private-records/'+p.name))
 for p in work.glob('timeline*'):
  if p.suffix in ['.sqlite','.nsys-rep']:raw.append((p,'profiles/'+label+'/'+p.name))
archive=dest/'raw.zip';assert not archive.exists()
started=time.monotonic();manifest=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name in raw:
  assert name not in {x['name'] for x in manifest};z.write(p,name)
  manifest.append(dict(name=name,bytes=p.stat().st_size,sha256=sha(p)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
prefill=[x for x in a1['summary'] if x['shape']=='prefill']
range_delta=lambda rows,kind:[min(x['sides']['candidate'][kind]['median_us']-x['sides']['peer'][kind]['median_us'] for x in rows),max(x['sides']['candidate'][kind]['median_us']-x['sides']['peer'][kind]['median_us'] for x in rows)]
negative=root/'tests/compute_provider_flashinfer/native_cache_test.cc'
receipt={'state':'TERMINAL_DIAGNOSTIC_REPRESENTATION_CAUSE_LOCALIZED_NO_PRODUCT_FIX','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'baseline':'0314eec0421b06ec6fcfdf13186b752c6943aa95','full_product_candidate':'669121418669b31f6849c74f64362aaf8d6eb919','fi_product_candidate':'0a29d119426b2975d48c238c37a2994675e0ba9f','math_candidate':'830dd9e01829e3e5850ddff7eaa6355ee7c8fd0d',
 'record':'docs/implementation/tasks/compute/inference-g04-g05-cache-attention-domain.md','registry_changed':False,'product_changed':False,'formal_p1_run':False,'new_product_fix':None,
 'd0':{'sdk_artifacts_verified':37,'public_headers_verified':17,'reference_headers_verified':d0['original_headers_verified'],'reused_reference_object':d0['reused_reference_object'],'reused_libraries':d0['reused_libraries'],'sdk_graph_only_source_delta':d0['source_delta_from_g06_sdk'],'binary':d1['binary'],'sdk_rebuilds':0,'ggml_rebuilds':0},
 'd1':{'state':d1['state'],'short_control_processes':12,'timeline_collections':1,'episodes':a1['matched_episodes'],'kernels':a1['matched_kernels'],'oracle_max_abs_error':d1['max_abs_error'],'prefill_attention_median_deltas_us':range_delta(prefill,'attention'),'prefill_merge_median_deltas_us':range_delta(prefill,'merge'),'cross_clock_negative_offsets':a1['cross_clock_negative_offsets'],'phase_results':a1['summary']},
 'd2':{'state':'BLOCKED_HARDWARE_COUNTERS','attempts':1,'error':'ERR_NVGPUCTRPERM','elapsed_seconds':d2['seconds'],'counter_metrics_collected':False,'driver_permissions_changed':False,'tool_rebuilt':False,'actual_sass_read_only':sass},
 'd3':{'state':d3['state'],'native_compile_units':1,'variants':2,'binary':d3['binary'],'hypotheses':build3['hypotheses'],'experiments':[dict(variant=x['variant'],oracle_max_abs_error=x['oracle_max_abs_error'],memcheck=x['memcheck'],short_control_processes=len(x['controls']),timeline=x['timeline']) for x in d3['experiments']],
       'causal_deltas':[dict(variant=e['variant'],attention_median_deltas_us=range_delta(e['summary'],'attention'),merge_median_deltas_us=range_delta(e['summary'],'merge')) for e in a3['experiments']]},
 'conclusions':['Within the fixed actual prefill consumer, native FP8 KV loading/conversion path is the principal attention difference. Switching to exact cold-expanded unscaled BF16 while preserving F32 partial/merge and scale locations cuts attention by3.058-3.184us with essentially unchanged merge.','Changing only FP8 intermediate representation to BF16 cuts merge by1.066-1.155us but attention changes only0.060-0.237us, with extra shared-memory reorder in actual generated code.','Matched grids/blocks, equal attention shared bytes, and no observed local spills exclude the earlier tile/shared-budget mismatch as an explanation for this current prefill comparison.','No claim identifies per-instruction stall cycles or guarantees speedup from a specific FP8 rewrite; hardware counters were not available.','Extra BF16 KV storage/cold expansion and lower-precision partials fail original product cost/numerical requirements; neither diagnostic variant is a product FIX.'],
 'existing_precision_counterexamples':{'path':str(negative.relative_to(root)),'sha256':sha(negative),'tests':['SplitKvScalesOnlyAfterF32MergeAgainstPartialOverflow','SplitKvPreservesBfloat16PartialCancellationResidual','SplitKvPreservesFloat16PartialCancellationResidual','SplitKvSinglePartialScalesBeforeFinalNarrowing'],'not_rerun':'Unchanged accepted product tests; cited to reject lowering precision based solely on the finite benchmark fixture.'},
 'limitations':a1['limits']+a3['limits']+['Cross-capture absolute timings cannot be summed into contribution percentages.','No inference-engine token/s, full-context sweep, other platform or full numerical-domain acceptance.','Original attempt14 LOSS/noninferiority UNRESOLVED and all costs remain; module stays BLOCKED/engineering INCONCLUSIVE.'],
 'setup_failures_retained':['Linux HYLE_PERF_CALLER_CPU belongs to Windows-only affinity helper; pre-GPU abort corrected with Linux sched_setaffinity and original failure retained.','Postcapture console marker guard counted94 rather than96; exact console loss cause not proven. Existing SQLite proves all12288 episodes and120 oracle records passed; no recapture.','Private generator namespace spelling assertion failed before configure.','Private CMake sent host-only -Werror to nvcc; failed log preserved, same build resumed after language scoping.','NCU hardware-counter permission failure retained without retry.'],
 'costs_seconds':{'d0_stages':sum(x['seconds'] for x in d0['stages']),'d1_stages':sum(x['seconds'] for x in d1['commands']),'d2_failed_capture':d2['seconds'],'d3_build_stages':sum(x['seconds'] for x in build3['stages']),'d3_runs':sum(x['seconds'] for x in d3['commands']),'cost_rule':'Measured process stages; do not equate to full human/agent wall time or add overlapping observer cost. Initial setup reads/unmeasured source-preparation time retained as UNKNOWN.'},
 'disposition':'Diagnostic batch terminated. No third variant, unchanged P1 resampling or product change. Future scoped optimization must preserve compressed resident KV and F32 numerical domain and target the proven load/conversion path with a concrete mechanism.',
 'raw_archive':{'path':str(archive.relative_to(root)),'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(manifest),'entries_sha256_verified':True,'manifest':manifest}}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'state':receipt['state'],'archive_bytes':archive.stat().st_size,'raw_entries':len(manifest),'archive_verify_seconds':time.monotonic()-started}))
