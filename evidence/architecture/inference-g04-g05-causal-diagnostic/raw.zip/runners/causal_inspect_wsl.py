from pathlib import Path
import json,subprocess
root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
r=json.loads((base/'setup.json').read_text());build=Path(r['old_consumer_build'])
print('OLD_LIBS', [str(x) for x in build.rglob('*.a')])
print('OLD_COMMANDS',subprocess.check_output(['ninja','-C',str(build),'-t','commands','g04_cuda_encoded_bench'],text=True)[-10000:])
for p in [Path('/opt/nvidia'),Path('/usr/local/cuda-13.3')]:
 print('NCU', [str(x) for x in p.glob('**/ncu')][:8])
print('SDK sample',[(str(x.relative_to(Path(r['prefix']))),x.stat().st_size) for x in Path(r['prefix']).glob('lib/*flashinfer*')])
