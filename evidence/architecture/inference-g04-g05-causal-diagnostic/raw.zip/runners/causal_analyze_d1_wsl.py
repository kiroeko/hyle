from pathlib import Path
import bisect,hashlib,json,re,sqlite3,statistics
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/causal-diagnostic-1'
work=Path('/root/hyle-scratch/compute-unified/g04-causal-diagnostic-1');trace=work/'timeline.sqlite'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
db=sqlite3.connect(trace.as_uri()+'?mode=ro',uri=True)
nv=db.execute('select start,end,text from NVTX_EVENTS where end is not null order by start').fetchall()
episodes=[x for x in nv if x[2] in ['candidate.episode','peer.episode']];assert len(episodes)==4*3*2*512
shapes=[x for x in nv if x[2] in ['window','prefill','holdout']];assert len(shapes)==12
cases=[x for x in nv if x[2] in ['CF_CF','PF_CF','CF_PF','PF_PF']];assert len(cases)==4
starts=[x[0] for x in episodes]
runtime={}
for table in ['CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER']:
 if not db.execute('select count(*) from sqlite_master where name=?',(table,)).fetchone()[0]:continue
 for row in db.execute('select start,end,correlationId,s.value from '+table+' r join StringIds s on r.nameId=s.id'):
  runtime.setdefault(row[2],[]).append(row)
gpu=db.execute('select k.start,k.end,k.correlationId,s.value,k.registersPerThread,k.dynamicSharedMemory,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,k.localMemoryPerThread from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on k.demangledName=s.id order by k.start').fetchall()
mapped={};resources={}
for row in gpu:
 a,b,corr,name,*resource=row;launches=runtime.get(corr,[])
 if not launches:continue
 launch=min(launches,key=lambda x:x[0]);i=bisect.bisect_right(starts,launch[0])-1
 if i<0 or launch[0]>episodes[i][1]:continue
 if 'BatchPrefillWithPagedKVCacheKernel' in name:kind='attention'
 elif 'MergeStates' in name:kind='merge'
 else:raise AssertionError(name)
 side=episodes[i][2].split('.')[0]
 assert ('hyle_benchmark_original_flashinfer_69ff' in name)==(side=='peer')
 mapped.setdefault(i,[]).append((a,b,kind))
 resources[(side,name)]=resource
groups={};raw=[]
for i,(begin,end,label) in enumerate(episodes):
 shape=next(x[2] for x in shapes if x[0]<=begin and end<=x[1]);case=next(x[2] for x in cases if x[0]<=begin and end<=x[1]);side=label.split('.')[0]
 kernels=mapped[i];assert len(kernels)==(2 if shape=='prefill' else 1)
 times={'episode':(end-begin)/1000,'signed_before_gpu_offset':(kernels[0][0]-begin)/1000,'attention':0.,'merge':0.,'gpu_gap':0.,'signed_after_gpu_offset':(end-kernels[-1][1])/1000}
 for j,(a,b,kind) in enumerate(kernels):
  times[kind]+=(b-a)/1000
  if j:times['gpu_gap']+=(a-kernels[j-1][1])/1000
 assert abs(times['episode']-sum(v for k,v in times.items() if k!='episode'))<1e-6
 groups.setdefault((case,shape,side),[]).append(times)
 raw.append(dict(case=case,shape=shape,side=side,**times))
summary=[]
for case in [x[2] for x in cases]:
 for shape in ['window','prefill','holdout']:
  row={'case':case,'shape':shape,'sides':{}}
  for side in ['candidate','peer']:
   values=groups[case,shape,side];assert len(values)==512
   row['sides'][side]={k:{'mean_us':statistics.mean(v[k] for v in values),'median_us':statistics.median(v[k] for v in values),'group64_mean_us':[statistics.mean(v[k] for v in values[j:j+64]) for j in range(0,512,64)]} for k in values[0]}
  row['mean_difference_us']={k:row['sides']['candidate'][k]['mean_us']-row['sides']['peer'][k]['mean_us'] for k in values[0]}
  summary.append(row)
result={'state':'D1_PHASE_ATTRIBUTION_DIAGNOSTIC_ONLY','trace_sha256':sha(trace),'matched_episodes':len(episodes),'matched_kernels':sum(map(len,mapped.values())),
 'units':'microseconds','method':'CUDA runtime/driver correlation links each launch to its containing completed NVTX episode. GPU duration/gaps use the GPU clock. Signed cross-clock before/after offsets are retained but cannot be interpreted as CPU-only time or an exact critical-path split. GPU timestamp calibration can place a short kernel before its correlated CPU launch.','summary':summary,
 'resources':[dict(side=side,kernel=name,registers=r[0],shared=r[1],grid=r[2:5],block=r[5:8],local_bytes=r[8]) for (side,name),r in resources.items()],
 'limits':['Profiled instrumented wall time is perturbed; not P1 and not a current acceptance verdict.','Short unprofiled A/A has sizeable order/address variability; whole-lifecycle timing is diagnostic only.','Phase attribution localizes a difference but does not establish which instruction is causal.','CPU/GPU clock calibration prevents using signed before/after offsets as an exact host/GPU critical-path decomposition.'],
 'cross_clock_negative_offsets':{k:sum(x[k]<0 for x in raw) for k in ['signed_before_gpu_offset','signed_after_gpu_offset']}}
(out/'d1-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'d1-episodes.json').write_text(json.dumps(raw)+'\n')
r=json.loads((out/'d1.json').read_text());text=(out/'current-timeline.log').read_text();errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)]
assert len(errors)==120 and max(errors)<=8e-3
assert r['commands'][-1]['exit']==0
r['postcapture_log_guard_failure']={'expected_console_rows':96,'observed_complete_marker_count':len(re.findall('CAUSAL_DIAG shape=',text)),'disposition':'Mixed stdout/stderr truncated two marker strings; no recapture. SQLite independently proves all12288 episodes and all120 oracle observations passed.'}
r.update(state='D1_CAPTURED_NOT_P1',timeline={'sqlite':str(trace),'sqlite_sha256':sha(trace),'report':str(work/'timeline.nsys-rep')},max_abs_error=max(errors),native_recompiles=0)
r.pop('active_pid',None);r.pop('active_stage',None);(out/'d1.json').write_text(json.dumps(r,indent=2)+'\n')
print('D1_MATCHED',len(episodes),sum(map(len,mapped.values())))
for row in summary:
 if row['shape']=='prefill':
  print(row['case'],{side:{k:round(v['median_us'],3) for k,v in data.items()} for side,data in row['sides'].items()},'mean_delta', {k:round(v,3) for k,v in row['mean_difference_us'].items()})
