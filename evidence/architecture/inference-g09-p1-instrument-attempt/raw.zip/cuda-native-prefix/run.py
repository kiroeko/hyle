from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time,re

root=Path('C:/public/project-hyle/hyle')
folder=root/'.scratch/inference-gaps/g09-p1-cuda-native-ledger-raw'
previous_record=folder/'execution.json'
record_path=folder/'execution-attempt2.json'
if record_path.exists(): raise SystemExit('preserve original attempt: execution.json exists')
started=time.monotonic()
record={'state':'PREPARING','scope':'One unchanged no-argv binary verify-only with private CUPTI injection; no A/A, benchmark or formal samples.','stages':[],'formal_samples':0}
if previous_record.exists():
 previous=json.loads(previous_record.read_text(encoding='utf-8'))
 assert previous['state']=='DIAGNOSTIC_FAIL' and previous.get('stage') is None
 record['previous_attempt']={'path':str(previous_record),'sha256':hashlib.sha256(previous_record.read_bytes()).hexdigest(),'elapsed_seconds':previous['elapsed_seconds'],'state':previous['state'],'error':previous.get('error'),'gpu_runs':0}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p): return {'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
def save():
 record['elapsed_seconds']=time.monotonic()-started
 record_path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
exe=Path('C:/h7/g09-p1-instrument/cuda/probe-build/bin/g09_pipeline_primary.exe')
expected='26cbb903c11387e64772129674326975a6978caf7c0b834f3450fe7dc174c693'
cu=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
vc=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Auxiliary/Build/vcvars64.bat')
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.GetCurrentProcess.restype=ctypes.c_void_p
kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
kernel.SetPriorityClass.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
assert kernel.SetPriorityClass(kernel.GetCurrentProcess(),0x4000)
assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),0xf)
record['resource_policy']={'priority':'BelowNormal','logical_cpu_affinity_mask':'0xf','max_build_jobs':1}
def stage(name,argv,env):
 stamp=time.monotonic();log=folder/(name+'.log')
 with log.open('wb') as f:
  p=subprocess.Popen(argv,cwd=folder,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  record.update(stage=name,child_pid=p.pid);save()
  while True:
   try: code=p.wait(timeout=1800);break
   except subprocess.TimeoutExpired:
    record.setdefault('extensions',[]).append({'stage':name,'seconds':1800,'pid':p.pid});save()
 record.pop('child_pid',None)
 row={'stage':name,'argv':argv,'exit_code':code,'elapsed_seconds':time.monotonic()-stamp,'log':bind(log)};record['stages'].append(row);save();return code
try:
 assert sha(exe)==expected
 record['exe_before']=bind(exe)
 record['facades_before']=[]
 for arm in ['baseline','candidate']:
  q=root/('.scratch/inference-gaps/g09-p1-builds/windows-cuda-'+arm+'/result.json');j=json.loads(q.read_text(encoding='utf-8'))
  for x in j['images']:
   assert sha(x['path'])==x['sha256'];record['facades_before'].append(bind(x['path']))
 record['source']=bind(folder/'injector.cc')
 record['official_inputs']=[bind(cu/x) for x in ['extras/CUPTI/samples/cupti_trace_injection/README.txt','extras/CUPTI/samples/cupti_trace_injection/cupti_trace_injection.cpp','extras/CUPTI/include/cupti_activity.h','extras/CUPTI/include/cupti_callbacks.h','extras/CUPTI/include/cupti_driver_cbid.h','extras/CUPTI/lib64/cupti.lib','extras/CUPTI/lib64/cupti64_2026.2.1.dll']]
 save()
 env_process=subprocess.run('cmd /d /c call "'+str(vc)+'" >nul && set',capture_output=True,text=True,check=True)
 env=dict(os.environ)
 for line in env_process.stdout.splitlines():
  if '=' in line and not line.startswith('='):
   k,v=line.split('=',1);env[k]=v
 cl='C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'
 argv=[cl,'/nologo','/LD','/MD','/O2','/std:c++20','/EHsc','/W4','/I'+str(cu/'include'),'/I'+str(cu/'extras/CUPTI/include'),str(folder/'injector.cc'),'/link','/LIBPATH:'+str(cu/'extras/CUPTI/lib64'),'cupti.lib','/OUT:'+str(folder/'g09_cupti_injection.dll')]
 assert stage('build-private-injection',argv,env)==0
 record['injection']=bind(folder/'g09_cupti_injection.dll');save()
 run_env=dict(os.environ)
 for key in list(run_env):
  if key in ['CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH','HYLE_PERF_RUN_NONCE','HYLE_BENCH_AA_ROUTE','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST']:run_env.pop(key)
 run_env.update(HYLE_BENCH_VERIFY_ONLY='1',CUDA_INJECTION64_PATH=str(folder/'g09_cupti_injection.dll'),HYLE_G09_CUPTI_LOG=str(folder/'activities.ndjson'),HYLE_PERF_CALLER_CPU='0',HYLE_PERF_PARENT_MASK='0xf',HYLE_PERF_PRIORITY='BelowNormal')
 run_env['PATH']=str(cu/'extras/CUPTI/lib64')+os.pathsep+run_env.get('PATH','')
 record['diagnostic_env']={k:run_env[k] for k in ['HYLE_BENCH_VERIFY_ONLY','CUDA_INJECTION64_PATH','HYLE_G09_CUPTI_LOG','HYLE_PERF_CALLER_CPU','HYLE_PERF_PARENT_MASK','HYLE_PERF_PRIORITY']};record['state']='PRIVATE_INJECTION_BUILT_VERIFY_ONLY_RUNNING';save()
 code=stage('verify-only',[str(exe)],run_env)
 text=(folder/'verify-only.log').read_text(encoding='utf-8',errors='replace')
 record['oracle']={'before':len(re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M)),'after':len(re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M)),'destroy_status0':len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M)),'measurement_rows':text.count('G09_MEASUREMENT')}
 record['exe_after']=bind(exe);assert record['exe_after']['sha256']==expected
 record['facades_after']=[bind(x['path']) for x in record['facades_before']]
 assert [x['sha256'] for x in record['facades_before']]==[x['sha256'] for x in record['facades_after']]
 record['activity_file']=bind(folder/'activities.ndjson') if (folder/'activities.ndjson').exists() else None
 assert code==0 and record['oracle']=={'before':4,'after':4,'destroy_status0':8,'measurement_rows':0}
 record['state']='VERIFY_ONLY_EXIT_ORACLES_AND_IMMUTABLE_INPUTS_PASS_ACTIVITY_ANALYSIS_PENDING';save()
 print(record['state'],record['elapsed_seconds'],flush=True)
except BaseException as error:
 record['state']='DIAGNOSTIC_FAIL';record['error']=repr(error);save();raise
