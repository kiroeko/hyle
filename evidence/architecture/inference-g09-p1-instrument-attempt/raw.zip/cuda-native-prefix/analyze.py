from pathlib import Path
import json,re,hashlib,collections,datetime

root=Path('C:/public/project-hyle/hyle');folder=root/'.scratch/inference-gaps/g09-p1-cuda-native-ledger-raw';out=root/'.scratch/inference-gaps/g09-p1-cuda-native-ledger.json'
if out.exists():raise SystemExit('preserve existing receipt')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
rows=[json.loads(line) for line in (folder/'activities.ndjson').read_text(encoding='utf-8').splitlines()]
execution=json.loads((folder/'execution-attempt2.json').read_text(encoding='utf-8'));previous=json.loads((folder/'execution.json').read_text(encoding='utf-8'));text=(folder/'verify-only.log').read_text(encoding='utf-8');apis={r['correlation']:r for r in rows if r['type']=='api_enter'};mods=[]
for line in text.splitlines():
 if line.startswith('# G09_IMAGE'):
  m=re.search(r'path=(.*?) tag=(\S+) getter=([0-9A-F]+)',line);path,tag,getter=m.groups();b=Path(path).read_bytes();import struct
  h=struct.unpack_from('<I',b,0x3c)[0];image_size=struct.unpack_from('<I',b,h+24+56)[0]
  base=int(getter,16)-0x7930;mods.append({'tag':tag,'base':base,'end':base+image_size,'image':bind(path),'getter_rva':'0x7930','image_size':image_size})
def owner(api):
 tags={m['tag'] for f in api.get('frames',[]) for m in mods if m['base']<=int(f,16)<m['end']}
 return next(iter(tags)) if len(tags)==1 else 'UNKNOWN'
releases=collections.defaultdict(list)
for r in rows:
 if r['type']=='api_enter' and r['name']=='cuDevicePrimaryCtxRelease_v2':releases[owner(r)].append(r)
assert sorted(releases)==['baseline-1','candidate-1'] and all(len(v)==4 for v in releases.values())
for values in releases.values():values.sort(key=lambda r:r['timestamp'])
def shape_for_api(r):
 tag=owner(r)
 for shape,end in enumerate(releases.get(tag,[])):
  if r['timestamp']<end['timestamp']:return tag,shape
 return tag,None
stream_owners={}
for r in rows:
 if r['type']=='kernel' and r['correlation'] in apis:
  key=(r['context'],r['stream']);found=shape_for_api(apis[r['correlation']]);assert key not in stream_owners or stream_owners[key]==found;stream_owners[key]=found
kernel_rows=[];copy_rows=[];unknown=[]
for r in rows:
 if r['type']=='kernel':
  tag,shape=stream_owners.get((r['context'],r['stream']),('UNKNOWN',None));valid=r['start']>0 and r['end']>=r['start'];within=None
  if valid and shape is not None:
   end=releases[tag][shape]['timestamp'];begin=0 if shape==0 else releases[tag][shape-1]['timestamp'];within=begin<r['start']<=r['end']<end
  kernel_rows.append({**r,'arm':tag,'shape':shape,'valid_gpu_interval':valid,'inside_original_state_retirement_boundaries':within,'direct_selected_api_correlation':r['correlation'] in apis})
 elif r['type']=='memcpy':
  a=apis.get(r['correlation']);tag,shape=shape_for_api(a or {});role='cold-initial-resident-upload' if a and a['name']=='cuMemcpyHtoD_v2' else 'original-replay-transfer' if a and a['name']=='cuMemcpyAsync' else 'UNKNOWN'
  copy_rows.append({**r,'arm':tag,'shape':shape,'role':role,'driver_api':a['name'] if a else None,'api_timestamp':a['timestamp'] if a else None,'valid_gpu_interval':r['start']>0 and r['end']>=r['start']})
for r in kernel_rows+copy_rows:
 if r['arm']=='UNKNOWN' or r['shape'] is None:unknown.append(r)
summary=[]
for shape in range(4):
 for arm in ['candidate-1','baseline-1']:
  ks=[r for r in kernel_rows if r['shape']==shape and r['arm']==arm];ms=[r for r in copy_rows if r['shape']==shape and r['arm']==arm]
  bins=[]
  for key,count in sorted(collections.Counter((r['role'],r['direction'],r['bytes']) for r in ms).items()):
   role,direction,size=key;bins.append({'role':role,'direction':'HtoD' if direction==1 else 'DtoH' if direction==2 else str(direction),'records':count,'bytes_per_record':size,'total_bytes':size*count})
  summary.append({'shape':shape,'arm':arm,'kernel_records':len(ks),'valid_kernel_intervals':sum(r['valid_gpu_interval'] for r in ks),'streams':sorted({r['stream'] for r in ks}),'memcpy':bins})
assert not unknown and all(r['inside_original_state_retirement_boundaries'] is True for r in kernel_rows if r['valid_gpu_interval'])
invalid=[r for r in kernel_rows if not r['valid_gpu_interval']];lastflush=next(r for r in reversed(rows) if r['type']=='flush')
record={
 'schema':'hyle.g09.cupti-native-prefix-ledger.v1','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'DIAGNOSTIC_HANG_TERMINATED_COMPLETED_PREFIX_OBSERVED_NOT_PROCESS_EXIT_PASS',
 'scope':'One unchanged no-argv P1 binary in VERIFY_ONLY=1, original four fixed 4M F32 journeys and original facade/SDK. Private one-TU CUPTI injection built; no native/kernel/SDK build, no A/A or A/B/formal performance samples. Instrumentation overhead is not performance evidence.',
 'qualification':{'whole_diagnostic':'FAIL_HANG','completed_public_journey':execution['oracle'],'actual_observed_kernel_records':len(kernel_rows),'valid_gpu_kernel_intervals':sum(r['valid_gpu_interval'] for r in kernel_rows),'memcpy_records':len(copy_rows),'valid_memcpy_intervals':sum(r['valid_gpu_interval'] for r in copy_rows),'dropped_records_reported':lastflush['dropped'],'cupti_errors_reported':lastflush['errors'],'activity_buffers_requested':lastflush['requested'],'activity_buffers_completed':lastflush['completed'],'balance_applies_at':'Last successful original checked boundary, before vendor process-exit PrimaryCtxRelease ENTER. Not a claim about unobserved teardown or zero private costs.'},
 'immutable_input_identity':{'exe_before':execution['exe_before'],'exe_after':execution['exe_after'],'facades_before':execution['facades_before'],'facades_after':execution['facades_after'],'all_unchanged':execution['exe_before']['sha256']==execution['exe_after']['sha256'] and [r['sha256'] for r in execution['facades_before']]==[r['sha256'] for r in execution['facades_after']]},
 'actual_kernel':{'name_counts':dict(collections.Counter(r['name'] for r in kernel_rows)),'grid':[16384,1,1],'block':[256,1,1],'interpretation':'Recorded original ggml CUDA F32 op_neg kernel, consistent with original selected provider; not a new native kernel. Do not infer other provider or whole-engine throughput.'},
 'actual_memcpy_totals':[{'direction':name,'records':len([r for r in copy_rows if r['direction']==kind]),'total_bytes':sum(r['bytes'] for r in copy_rows if r['direction']==kind)} for kind,name in [(1,'HtoD'),(2,'DtoH')]],
 'shape_and_arm_ledger':summary,
 'attribution_method':{'arm':'Recorded raw driver callback stack PCs fall within each actual ASLR facade image range. Getter RVA0x7930 is fixed by original map; actual image hashes and bases bound below. No nearest-symbol guess is used as source proof.','state_boundaries':'Eight actual cuDevicePrimaryCtxRelease_v2 entry timestamps, four per arm, are correlated via facade stack PC. Original source closes and destroys each State after its entire shape before the next shape; ordinal0-3 gives finite shape boundaries.','copies':'Every one of164 actual memcpy activity correlation IDs matches recorded driver API. Original synchronous cuMemcpyHtoD_v2 four records are cold resident-input uploads;160 cuMemcpyAsync records are original replay transfers. Classification uses actual APIs and original lifetime order, not planned reports.','kernels':'Ten context/stream pairs each have a first kernel activity matching a recorded direct launch API/arm/state. Remaining records on the same unique live context/stream inherit that State. All99 valid kernel intervals lie before matching original State retirement and after preceding State retirement. This is state-level ownership, not independently marked individual replay phases.','limits':'90 kernel records do not match the selected driver API rows. The small filter did not log cuGraphLaunch; the exact API association of these records was not measured.20 LaunchKernel callbacks were recorded, and no complete API-to-device correlation claim follows. No complete per-API or per-replay GPU graph dispatch bill is claimed. The one zero-timestamp kernel is retained and never counted as a valid GPU interval.'},
 'aslr_image_ranges':mods,'state_retirement_markers':dict(releases),'invalid_gpu_intervals':invalid,'last_successful_flush':lastflush,'final_unreturned_api':rows[-1],
 'exit_failure':{'hang_observation':json.loads((folder/'hang-termination.json').read_text(encoding='utf-8')),'termination':'Only own identity-verified child PID82900 stopped, code57005. Process wait then signaled. Original executable and all facades remain byte-identical.','attribution_limit':'Hang was observed after all public oracle/state completion and last successful v2 primary-context release, at non-v2 cuDevicePrimaryCtxRelease ENTER with no EXIT. No exact WCT/stack or causality verdict was added; no new G09 product defect is signed. Official injection sample warns Windows teardown needs a pre-exit hook. No Detours framework, exit workaround or second GPU run was added.'},
 'instrument_lifecycle':{'official_sample_read':'CUDA13.3 extras/CUPTI/samples/cupti_trace_injection README and source: CUDA_INJECTION64_PATH loads DLL and calls InitializeInjection, success return1. Its Windows cleanup warning was read before construction.','activity_structs':'CUpti_ActivityKernel12 and CUpti_ActivityMemcpy6 per actual installed13.3 header; this is a13.3-only private diagnostic.','flush':'ActivityFlushAll(FORCED) at original checked sync/free/primary-release API exit. No CUDA call registered in own DllMain/atexit. Such forced collection permits incomplete timestamps; the one invalid interval remains explicit.','counters':'105 requested/completed buffers, zero reported drops/errors at last completed boundary. This does not cure the failed process exit or prove arbitrary extreme/other-domain coverage.'},
 'cost_and_failed_attempts':{'setup_attempt':{'state':previous['state'],'elapsed_seconds':previous['elapsed_seconds'],'error':previous.get('error'),'gpu_runs':0},'actual_attempt_state':execution['state'],'actual_attempt_elapsed_seconds':execution['elapsed_seconds'],'total_elapsed_seconds':execution['elapsed_seconds']+previous['elapsed_seconds'],'stage_costs':execution['stages'],'resource_policy':execution['resource_policy'],'gpu_runs_total':1,'formal_samples':0,'timeouts_reset':False},
 'proof_boundaries':['Completed public prefix does not turn diagnostic HANG into PASS','99 valid device kernel intervals, not100','No CPU/native overlap qualification, ranking, P1 confidence or throughput result','No individual warm iteration/oracle split: original verify run contains pre-oracle,8 warmups and post-oracle per arm; state-level actual totals only','No actual allocation/private workspace/driver memory/hidden vendor cache bill; UNKNOWN','No guarantee of unobserved process-detach operations or zero remaining vendor work'],
 'heavy_reservation':{'state':'RELEASED','detail':'Parent notified immediately after own child termination. Subsequent work was only offline parsing/hash/sealing; no more build or GPU execution.'},
 'raw':[],'stop':'Bounded A4 terminal reached with a retained technical limitation. No second GPU run or broader instrument construction.'}
for p in sorted(folder.iterdir()):
 if p.is_file():record['raw'].append(bind(p))
out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'path':str(out),'sha256':bind(out)['sha256'],'state':record['state'],'kernel_records':len(kernel_rows),'valid_kernel_intervals':len(kernel_rows)-len(invalid),'copies':len(copy_rows),'unattributed_state_records':len(unknown),'cost_seconds':record['cost_and_failed_attempts']['total_elapsed_seconds']}))
