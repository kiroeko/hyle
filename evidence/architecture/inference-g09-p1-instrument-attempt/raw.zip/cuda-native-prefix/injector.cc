#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cupti.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <malloc.h>

namespace {
SRWLOCK output_lock = SRWLOCK_INIT;
HANDLE output = INVALID_HANDLE_VALUE;
CUpti_SubscriberHandle subscriber{};
volatile LONG64 requested = 0, completed = 0, kernels = 0, copies = 0, dropped = 0, errors = 0;
thread_local bool in_callback = false;
void emit(const char *s) {
  AcquireSRWLockExclusive(&output_lock);
  if (output != INVALID_HANDLE_VALUE) { DWORD done = 0; const auto size=DWORD(std::strlen(s)); if (!WriteFile(output, s, size, &done, nullptr) || done!=size) InterlockedIncrement64(&errors); }
  ReleaseSRWLockExclusive(&output_lock);
}
void escaped(const char *s, char *d, std::size_t cap) {
  std::size_t n = 0;
  for (; s && *s && n + 7 < cap; ++s) {
    const auto c = static_cast<unsigned char>(*s);
    if (c == '\\' || c == '"') { d[n++]='\\'; d[n++]=char(c); }
    else if (c < 32) { n += std::snprintf(d+n, cap-n, "\\u%04x", unsigned(c)); }
    else d[n++]=char(c);
  }
  d[n] = 0;
}
bool check(CUptiResult r, const char *where) {
  if (r == CUPTI_SUCCESS) return true;
  InterlockedIncrement64(&errors); char line[256];
  std::snprintf(line, sizeof(line), "{\"type\":\"error\",\"where\":\"%s\",\"status\":%d}\n", where, int(r)); emit(line); return false;
}
void CUPTIAPI request(std::uint8_t **b, std::size_t *size, std::size_t *max) {
  *size = 1024 * 1024; *max = 0; *b = static_cast<std::uint8_t *>(_aligned_malloc(*size, 8));
  if (!*b) { *size = 0; InterlockedIncrement64(&errors); }
  InterlockedIncrement64(&requested);
}
void CUPTIAPI complete(CUcontext context, std::uint32_t stream, std::uint8_t *buffer, std::size_t, std::size_t valid) {
  CUpti_Activity *r = nullptr; CUptiResult status;
  while ((status=cuptiActivityGetNextRecord(buffer, valid, &r)) == CUPTI_SUCCESS) {
    char line[12000];
    if (r->kind == CUPTI_ACTIVITY_KIND_KERNEL || r->kind == CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL) {
      const auto *k = reinterpret_cast<const CUpti_ActivityKernel12 *>(r); char name[9000]; escaped(k->name, name, sizeof(name));
      std::snprintf(line, sizeof(line), "{\"type\":\"kernel\",\"name\":\"%s\",\"start\":%llu,\"end\":%llu,\"device\":%u,\"context\":%u,\"stream\":%u,\"correlation\":%u,\"grid\":[%u,%u,%u],\"block\":[%u,%u,%u]}\n", name, k->start,k->end,k->deviceId,k->contextId,k->streamId,k->correlationId,k->gridX,k->gridY,k->gridZ,k->blockX,k->blockY,k->blockZ);
      InterlockedIncrement64(&kernels); emit(line);
    } else if (r->kind == CUPTI_ACTIVITY_KIND_MEMCPY) {
      const auto *m = reinterpret_cast<const CUpti_ActivityMemcpy6 *>(r);
      std::snprintf(line,sizeof(line),"{\"type\":\"memcpy\",\"start\":%llu,\"end\":%llu,\"bytes\":%llu,\"direction\":%u,\"src_kind\":%u,\"dst_kind\":%u,\"flags\":%u,\"copy_count\":%llu,\"device\":%u,\"context\":%u,\"stream\":%u,\"correlation\":%u,\"runtime_correlation\":%u}\n",m->start,m->end,m->bytes,unsigned(m->copyKind),unsigned(m->srcKind),unsigned(m->dstKind),unsigned(m->flags),m->copyCount,m->deviceId,m->contextId,m->streamId,m->correlationId,m->runtimeCorrelationId);
      InterlockedIncrement64(&copies); emit(line);
    }
  }
  if (status != CUPTI_ERROR_MAX_LIMIT_REACHED) check(status,"get_next_record");
  std::size_t count = 0; check(cuptiActivityGetNumDroppedRecords(context,stream,&count),"dropped_records");
  InterlockedAdd64(&dropped,LONG64(count)); InterlockedIncrement64(&completed);
  char line[240]; std::snprintf(line,sizeof(line),"{\"type\":\"buffer\",\"valid_bytes\":%llu,\"dropped\":%llu,\"stream\":%u}\n",static_cast<unsigned long long>(valid),static_cast<unsigned long long>(count),stream); emit(line);
  _aligned_free(buffer);
}
bool interesting(const char *n) {
  return std::strstr(n,"LaunchKernel") || std::strstr(n,"Memcpy") || std::strstr(n,"Memset") || std::strstr(n,"Synchronize") || std::strstr(n,"PrimaryCtxRelease") || std::strstr(n,"MemFree");
}
bool flush_boundary(const char *n) {
  return std::strstr(n,"EventSynchronize") || std::strstr(n,"StreamSynchronize") || std::strstr(n,"CtxSynchronize") || std::strstr(n,"PrimaryCtxRelease") || std::strstr(n,"MemFree");
}
void CUPTIAPI callback(void *, CUpti_CallbackDomain domain, CUpti_CallbackId, const void *raw) {
  if (in_callback || domain != CUPTI_CB_DOMAIN_DRIVER_API) return;
  const auto *d = static_cast<const CUpti_CallbackData *>(raw); if (!d->functionName || !interesting(d->functionName)) return;
  in_callback = true;
  if (d->callbackSite == CUPTI_API_ENTER) {
    void *frames[28]{}; const auto count = CaptureStackBackTrace(0,28,frames,nullptr);
    char stack[1600]; std::size_t used=0; stack[0]=0;
    for (unsigned k=0;k<count;++k) used+=std::snprintf(stack+used,sizeof(stack)-used,"%s\"0x%llx\"",k?",":"",reinterpret_cast<unsigned long long>(frames[k]));
    std::uint64_t ns=0; check(cuptiGetTimestamp(&ns),"api_timestamp");
    char line[2400]; std::snprintf(line,sizeof(line),"{\"type\":\"api_enter\",\"name\":\"%s\",\"timestamp\":%llu,\"correlation\":%u,\"context\":%u,\"thread\":%lu,\"frames\":[%s]}\n",d->functionName,ns,d->correlationId,d->contextUid,GetCurrentThreadId(),stack);emit(line);
  } else if (flush_boundary(d->functionName)) {
    const auto status=cuptiActivityFlushAll(CUPTI_ACTIVITY_FLAG_FLUSH_FORCED); check(status,"flush_checked_boundary");
    std::uint64_t ns=0; check(cuptiGetTimestamp(&ns),"flush_timestamp");
    char line[700]; std::snprintf(line,sizeof(line),"{\"type\":\"flush\",\"boundary\":\"%s\",\"timestamp\":%llu,\"status\":%d,\"driver_result\":%d,\"requested\":%lld,\"completed\":%lld,\"kernels\":%lld,\"memcopies\":%lld,\"dropped\":%lld,\"errors\":%lld}\n",d->functionName,ns,int(status),d->functionReturnValue?int(*static_cast<const CUresult *>(d->functionReturnValue)):-1,requested,completed,kernels,copies,dropped,errors);emit(line);
  }
  in_callback = false;
}
}
extern "C" __declspec(dllexport) int InitializeInjection() {
  char file[32768]; if (!GetEnvironmentVariableA("HYLE_G09_CUPTI_LOG",file,sizeof(file))) return 0;
  output=CreateFileA(file,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr); if(output==INVALID_HANDLE_VALUE)return 0;
  std::uint32_t version=0; std::uint64_t ns=0; LARGE_INTEGER qpc{},freq{};
  check(cuptiGetVersion(&version),"version"); QueryPerformanceCounter(&qpc); QueryPerformanceFrequency(&freq);check(cuptiGetTimestamp(&ns),"initial_timestamp");
  char line[400]; std::snprintf(line,sizeof(line),"{\"type\":\"init\",\"version\":%u,\"timestamp\":%llu,\"qpc\":%lld,\"qpc_frequency\":%lld,\"pid\":%lu}\n",version,ns,qpc.QuadPart,freq.QuadPart,GetCurrentProcessId());emit(line);
  bool ok=check(cuptiSubscribe(&subscriber,&callback,nullptr),"subscribe");
  ok=check(cuptiActivityRegisterCallbacks(&request,&complete),"register_buffers") && ok;
  ok=check(cuptiActivityEnable(CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL),"enable_kernels") && ok;
  ok=check(cuptiActivityEnable(CUPTI_ACTIVITY_KIND_MEMCPY),"enable_memcpy") && ok;
  ok=check(cuptiEnableDomain(1,subscriber,CUPTI_CB_DOMAIN_DRIVER_API),"enable_driver_callbacks") && ok;
  emit(ok?"{\"type\":\"armed\",\"ok\":true}\n":"{\"type\":\"armed\",\"ok\":false}\n");
  // No atexit/DllMain CUDA call: records are flushed at the original checked
  // synchronization/free/release boundaries while CUDA remains valid.
  return ok?1:0;
}
