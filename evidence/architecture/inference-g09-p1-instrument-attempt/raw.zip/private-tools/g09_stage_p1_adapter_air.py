from pathlib import Path
import json, subprocess
root = Path('C:/public/project-hyle/hyle')
source = root/'.scratch/inference-gaps/g09-p1-instrument-adapter'
bundle = root/'.scratch/inference-gaps/g09-p1-instrument-source.bundle'
base = '/Users/kiro/hyle-scratch/compute-unified'
remote = base+'/g09-p1-inputs'
subprocess.run(['git','-C',str(source),'bundle','create',str(bundle),'HEAD'],check=True)
subprocess.run(['scp',str(bundle),str(root/'.scratch/inference-gaps/g09_build_p1_adapter_profiles.py'),'kiro@172.22.10.198:'+remote+'/'],check=True)
setup = '''from pathlib import Path
import subprocess
base=Path('/Users/kiro/hyle-scratch/compute-unified')
source=base/'g09-p1-instrument-source'
assert not source.exists(), 'Preserve existing source; no overwrite'
subprocess.run(['git','clone',str(base/'g09-p1-inputs/g09-p1-instrument-source.bundle'),str(source)],check=True)
assert subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()==''
'''
setup_path = root/'.scratch/inference-gaps/g09_clone_p1_source_air.py'
setup_path.write_text(setup,encoding='utf8')
subprocess.run(['scp',str(setup_path),'kiro@172.22.10.198:'+remote+'/'],check=True)
subprocess.run(['ssh','kiro@172.22.10.198','python3',remote+'/g09_clone_p1_source_air.py'],check=True)
subprocess.run(['ssh','kiro@172.22.10.198','python3','-B',remote+'/g09_build_p1_adapter_profiles.py','apple','vulkan'],check=True)
print('Both Air adapter/control probes built; no execution or product rebuild',flush=True)
