from pathlib import Path
import importlib.util,json,subprocess,sys
sys.dont_write_bytecode=True
root=Path('C:/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps';source=scratch/'g09-p1-instrument-adapter'
spec=importlib.util.spec_from_file_location('g09_validator',source/'validate_aa.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
build=Path('C:/h7/g09-p1-instrument/cuda/probe-build');out=scratch/'g09-p1-instrument-builds/windows-cuda-final-inspection';out.mkdir(exist_ok=False)
cache=(build/'CMakeCache.txt').read_text();compiler=Path(next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_CXX_COMPILER:')))
artifacts={}
for name in ['primary','control']:
    exe=build/'bin'/('g09_pipeline_'+name+'.exe')
    artifacts[name]=dict(path=str(exe),sha256=m.sha(exe),bytes=exe.stat().st_size,text_sha256=m.text_section(exe))
    for flag in ['imports','disasm']:
        with (out/(name+'-'+flag+'.log')).open('wb') as log:subprocess.run([str(compiler.with_name('dumpbin.exe')),'/nologo','/'+flag,str(exe)],stdout=log,stderr=subprocess.STDOUT,check=True)
assert artifacts['primary']['sha256']=='26cbb903c11387e64772129674326975a6978caf7c0b834f3450fe7dc174c693'
(out/'compile-commands.json').write_bytes((build/'compile_commands.json').read_bytes())
result=dict(state='ORIGINAL_EXISTING_CUDA_PROBE_REINSPECTED_NOT_REBUILT_OR_EXECUTED',profile='windows-cuda',artifacts=artifacts)
(out/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
profiles={}
for profile,folder in [
    ('windows-cuda',out),('windows-vulkan',scratch/'g09-p1-instrument-builds/windows-vulkan-probe'),
    ('air-apple',scratch/'g09-p1-instrument-air-collected/air-apple-probe'),
    ('air-vulkan',scratch/'g09-p1-instrument-air-collected/air-vulkan-probe')]:
    actual=json.loads((folder/'build-result.json').read_text())
    profiles[profile]=dict(metadata=str(folder),result_sha256=m.sha(folder/'build-result.json'),
        primary_text_sha256=actual['artifacts']['primary']['text_sha256'],control_text_sha256=actual['artifacts']['control']['text_sha256'],artifacts=actual['artifacts'])
target=scratch/'g09-p1-instrument-final-artifacts.json'
target.write_text(json.dumps(dict(state='FOUR_NATIVE_PROBE_ADAPTERS_READY_FOR_INDEPENDENT_REVIEW_NO_AB_SAMPLES',profiles=profiles),indent=2)+'\n')
print(target)
