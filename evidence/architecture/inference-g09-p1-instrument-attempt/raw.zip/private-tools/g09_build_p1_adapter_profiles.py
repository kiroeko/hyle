from pathlib import Path
import ctypes, hashlib, importlib.util, json, os, platform, subprocess, sys, time
sys.dont_write_bytecode = True
AIR = platform.system() == 'Darwin'
BASE = Path('/Users/kiro/hyle-scratch/compute-unified' if AIR else 'C:/h7')
SOURCE = BASE/'g09-p1-instrument-source' if AIR else Path('C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-p1-instrument-adapter')
OUT = BASE/'g09-p1-instrument-builds' if AIR else Path('C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-p1-instrument-builds')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
if AIR:
    env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env.get('PATH','')
    os.nice(10)
else:
    setup = subprocess.check_output(['cmd','/d','/c','C:/public/project-hyle/hyle/.scratch/inference-gaps/g01/cpu-ragged-env.cmd'],encoding='utf8',errors='replace')
    env = {k.upper():v for k,v in env.items()}
    env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
    env['VSLANG'] = '1033'
spec = importlib.util.spec_from_file_location('g09_validator',SOURCE/'validate_aa.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
sha = module.sha
for route in sys.argv[1:]:
    assert route in (['apple','vulkan'] if AIR else ['vulkan'])
    key = ('air-' if AIR else 'windows-')+route
    build = BASE/'g09-p1-instrument'/route/'probe-build'
    out = OUT/(key+'-probe')
    assert not build.exists() and not out.exists()
    out.mkdir(parents=True)
    started = time.monotonic()
    r = dict(state='RUNNING',profile=key,stages=[],source=str(SOURCE),build=str(build),product_rebuilds=0,facade_rebuilds=0,max_jobs=4)
    def save():
        r['elapsed_seconds']=time.monotonic()-started
        (out/'build-result.json').write_text(json.dumps(r,indent=2)+'\n')
    def run(stage,command):
        r.update(stage=stage);stamp=time.monotonic();save()
        flags=0 if AIR else subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS
        with (out/(stage+'.log')).open('wb') as log:
            p=subprocess.Popen([str(x) for x in command],env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=flags)
            if not AIR:
                get=ctypes.windll.kernel32.GetProcessAffinityMask
                get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
                pin=ctypes.windll.kernel32.SetProcessAffinityMask;pin.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
                available,system=ctypes.c_size_t(),ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle))
                assert get(handle,ctypes.byref(available),ctypes.byref(system))
                assert pin(handle,sum([1<<i for i in range(64) if available.value&(1<<i)][:4]))
            r['child_pid']=p.pid;save()
            while True:
                try:code=p.wait(timeout=1800);break
                except subprocess.TimeoutExpired:r.setdefault('extensions',[]).append(dict(stage=stage,seconds=1800,pid=p.pid));save()
        r.pop('child_pid',None)
        r['stages'].append(dict(stage=stage,command=[str(x) for x in command],exit_code=code,elapsed_seconds=time.monotonic()-stamp))
        save()
        assert code==0,(out/(stage+'.log')).read_text(errors='replace')[-5000:]
    try:
        r['actual_identity']={k:subprocess.check_output(v,env=env,text=True).strip() for k,v in ({'model':['sysctl','-n','hw.model'],'system':['sw_vers'],'compiler':['xcrun','clang++','--version']} if AIR else {'computer':['hostname']}).items()}
        if AIR:assert r['actual_identity']['model']=='Mac16,12'
        run('configure',['cmake','-S',SOURCE,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DG09_ROUTE='+route])
        commands=json.loads((build/'compile_commands.json').read_text())
        assert len(commands)==3 and {Path(x['file']).name for x in commands}=={'wrapper.cc','nanobench_impl.cc','perf_control_bench.cc'}
        assert all(Path(x['file']).resolve().is_relative_to(SOURCE) for x in commands)
        (out/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        run('build',['cmake','--build',build,'-j','4'])
        r['artifacts']={}
        for name in ['primary','control']:
            executable=build/'bin'/('g09_pipeline_'+name+('' if AIR else '.exe'))
            r['artifacts'][name]=dict(path=str(executable),sha256=sha(executable),bytes=executable.stat().st_size,text_sha256=module.text_section(executable))
            if AIR:
                run(name+'-dependencies',['otool','-L',executable])
                run(name+'-disassembly',['otool','-tV',executable])
                run(name+'-symbols',['nm','-m',executable])
            else:
                cache=(build/'CMakeCache.txt').read_text()
                compiler=Path(next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_CXX_COMPILER:')))
                dumpbin=compiler.with_name('dumpbin.exe')
                run(name+'-imports',[dumpbin,'/nologo','/imports',executable])
                run(name+'-disassembly',[dumpbin,'/nologo','/disasm',executable])
                imports=(out/(name+'-imports.log')).read_text(errors='replace')
                assert '@hyle@' not in imports and 'g09_'+route+'_' not in imports and 'FreeLibrary' not in imports
        r['state']='ORIGINAL_THREE_CPP_ARGV_ADAPTER_AND_CONTROL_BUILT_CODEGEN_INSPECTED_NOT_EXECUTED'
        save();print(key,r['state'],r['elapsed_seconds'],flush=True)
    except BaseException as error:r.update(state='FAIL',error=repr(error));save();raise
