from pathlib import Path
import copy, hashlib, json, shutil

ROOT = Path('C:/public/project-hyle/hyle')
BASE = ROOT / '.scratch/inference-gaps'
SOURCE = BASE / 'g09-p1-instrument-adapter'
BASELINE = '9e2f25c469634a6f723e76eaf1aa2db5973bca9a'
CANDIDATE = '3524413272cb52d06af5e64d634edbfef09b9864'
PRODUCT = 'e09f30925c6dba5cf4540669fd3b4874f45bb158'
SHAPES = ['independent-cpu-first', 'independent-gpu-first', 'two-microbatches', 'serial-holdout']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf8'))

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')

retained = SOURCE / 'retained'
retained.mkdir(exist_ok=True)
for name in ['facade.cc', 'phase-ledger.json']:
    shutil.copyfile(BASE / 'g09-p1-draft' / name, retained / name)
proposal = ROOT / 'evidence/architecture/inference-g09-p1-prospective/proposal.json'
shutil.copyfile(proposal, retained / 'prospective.json')
provenance = {
    'consumer': 'G09 fixed public Graph CPU/GPU joint-pipeline consumer fragments',
    'scope': 'Independent CPU/GPU branches with join; two independent microbatches; required serial chain holdout. Not a complete inference engine or measured engine share.',
    'source': 'retained/facade.cc', 'sha256': sha(retained / 'facade.cc'),
    'peer_revision': BASELINE, 'candidate_revision': CANDIDATE,
    'product_code_revision': PRODUCT,
    'source_boundary': {'path': 'driver.cc', 'sha256': sha(SOURCE / 'driver.cc')},
    'phase_ledger': {'path': 'retained/phase-ledger.json', 'sha256': sha(retained / 'phase-ledger.json')},
    'prospective': {'path': 'retained/prospective.json', 'sha256': sha(retained / 'prospective.json')},
    'limitation': 'One complete original public consumer fragment per operation, two slots as one indivisible unit for the two-microbatch row. No token/s, cold 5% or full allocator/cache reclamation claim.'}
write(SOURCE / 'consumer-provenance.json', provenance)
template = read(ROOT / 'bench/compute_ops/contract-cuda.json')

for host, route in [('windows','cuda'), ('windows','vulkan'), ('air','apple'), ('air','vulkan')]:
    key = host + '-' + route
    air = host == 'air'
    machine = 'M1-MAC' if air else 'W1-WIN'
    builds = {}
    artifacts = {}
    for kind in ['baseline','candidate']:
        directory = 'g09-p1-air-collected/g09-p1-builds' if air else 'g09-p1-builds'
        path = BASE / directory / (key + '-' + kind) / 'result.json'
        builds[kind] = read(path)
        for image in builds[kind]['images']:
            artifacts[image['path']] = {k:image[k] for k in ['path','sha256','bytes']}
    if air:
        runtime_path = BASE / 'g09-p1-runtime-air-collected/g09-p1-runtime' / route / 'result.json'
        runtime = read(runtime_path)
        staged = runtime['staged_runtime']
    else:
        runtime_path = BASE / ('g09-p1-' + route + '-runtime-preflight') / 'freeze.json'
        runtime = read(runtime_path)
        staged = runtime['staged_runtime']
    for rows in staged.values():
        for item in rows:
            artifacts[item['path']] = {k:item[k] for k in ['path','sha256','bytes']}
    originals = ['hyle-perf.py', 'perf-machines.json'] + [str(p.relative_to(ROOT/'scripts')).replace('\\','/')
        for p in sorted((ROOT/'scripts/hyle_perf').rglob('*.py'))]
    manifest = {
        'schema':'hyle.g09.private-p1-artifacts/v1', 'profile':key,
        'baseline':BASELINE, 'candidate':CANDIDATE, 'product':PRODUCT,
        'facade_count':4, 'artifacts':list(artifacts.values()),
        'build_receipts':{kind:{'state':b['state'], 'image_hashes':[x['sha256'] for x in b['images']],
            'phase_ledger_sha256':b['phase_ledger_sha256']} for kind,b in builds.items()},
        'runtime_receipt_sha256':sha(runtime_path),
        'original_instrument_files':[{'path':p,'sha256':sha(ROOT/'scripts'/p)} for p in originals],
        'system_runtime_boundary':'Original diagnostics retain actual loaded-module path/hash or explicit dyld shared-cache OS identity. This manifest freezes every original staged native file and all four previously reviewed facade images. It does not claim private cache reclamation.',
        'copied_executable_resource':('mlx.metallib' if air and route=='apple' else
             next((x['name'] for x in staged['candidate'] if x['name'].startswith('hyle_ggml_cpu_')), None))}
    write(SOURCE / ('artifacts-' + key + '.json'), manifest)
    c = copy.deepcopy(template)
    c['id'] = 'inference-g09-' + key + '-pipeline-p1-v1'
    c['module'] = 'graph'
    c['claim'] = 'Complete warm original public CPU/GPU Graph journey against pinned pre-G09 baseline, fixed4M F32. Includes prepare, original math/copies, actual native completion, owning result observation and release, Scheduler.drain. Engineering 5% P1 only; no engine token/s, full process/cold cost or private-cache reclamation claim.'
    c['candidate'] = dict(target='g09_pipeline_primary', delivery_shape='static', revision='runtime-bound', component='graph', entrypoint='wrapper.cc')
    c['peers'] = [dict(id='baseline9e2', revision=BASELINE, configuration={
        'delivery_shape':'static', 'role':'Full original pre-G09 static SDK inside its own reviewed opaque C-table image',
        'precision':'Identical finite F32 inputs, original CPU/native math and exact full before/after oracle',
        'scope':'Same complete public prepare/submit/wait/results/read/retire/drain and symmetric persistent lifetimes'})]
    c['strata'] = [x for x in c['strata'] if x['target_variant']=='primary']
    c['controls'] = [x for x in c['controls'] if x['kind']!='placement']
    c['workloads'] = []
    for shape in SHAPES:
        w = copy.deepcopy(template['workloads'][0])
        slots = 2 if shape=='two-microbatches' else 1
        w.update(id=shape, consumer_key='inference-joint-pipeline/'+shape,
            provenance=dict(path='consumer-provenance.json', sha256=sha(SOURCE/'consumer-provenance.json')),
            ownership_topology={
                'candidate':'Persistent original default CPU/native contexts and Scheduler2; per-call bind/prepare, '+str(slots)+' submit(s), owning checked results, host output observation while ResultLease alive, complete release and drain before return',
                'peer':'Exactly the same original public consumer in the pre-G09 SDK and its independent private image',
                'equivalence':'Both sides charge all original math, bridge/repack/copies, completion and per-step retirement; persistent Graph/invocation/backing/context/cache final destruction is deferred symmetrically. Windows mappings last to process exit; Air uses original dlclose. Private allocator reclamation UNKNOWN.'},
            material_contribution=dict(frequency=1,value=1,unit='complete-'+str(slots)+'-slot-public-replay',budget=5,
                denominator='One entire named joint-pipeline fragment with all slots complete, observed and drained',
                derivation='Actual complete consumer fragment, not a measured inference-engine traffic or share estimate'),
            semantic_contract=next(x['dag'] for x in read(proposal)['workloads'] if x['id']==shape)+'; 4194304 F32 elements per slot; original placement CPU1/GPU0; no fallback',
            input=dict(distribution='float(int(i%101)-50)*0.125f+slot*0.25f; actually uploaded readonly GPU values1.25 and host residual1.25; full independent oracle before/after; eight complete warmups per arm',scale=dict(elements=4194304,slots=slots,dtype='F32')),
            setup='Persistent contexts/Scheduler2, compile/invocations/backing, first touch/native init and full preflight are cold. prepare_replay, original native/math/copies, result observation, all per-call owners and drain are warm. Final State destroy and private mapping/cache teardown are separate diagnostic costs, not a 5% cold claim.',
            charged_phases=['public bind and prepare_replay on every logical replay','one submit or BOTH microbatch submits before either wait','all original CPU/native math, bridge/repack/staging and actual native completion','owning ResultLease and checked host 4-byte read per slot while lease alive; release all step owners; Scheduler.drain before return'],
            peer_id='baseline9e2',pair=dict(candidate='HYLE G09',peer='HYLE baseline'),
            required_strata=[x['id'] for x in c['strata']], required_controls=[x['id'] for x in c['controls']])
        c['workloads'].append(w)
    c['hosts'] = dict(allowed_platforms=['macos' if air else 'windows'],certification_platforms=['macos' if air else 'windows'],requirements=dict(machine_profiles=[machine],qualified_role='engineering',formal_independent_hardware=False))
    c['extensions'] = {
        'runner':dict(schema='hyle.perf.nanobench-runner/v1',
            cmake=dict(cache={'G09_ROUTE':route,'CMAKE_EXPORT_COMPILE_COMMANDS':'ON'},peer_cache={'baseline9e2':'G09_PEER_SOURCE'}),
            profiles={machine:dict(generator='Ninja',cache={},compiler_id='AppleClang' if air else 'MSVC',compiler_version_prefix='21.' if air else '19.50')},
            sampling_topology='single-logical-cpu' if air else 'native-runtime-pair',
            executables=[dict(id='pipeline-primary',target='g09_pipeline_primary',stem='g09_pipeline_primary',target_variant='primary',measurement_batch=1,telemetry_prefixes=['# HYLE_G09_INSTRUMENT_RUN '],workloads=[dict(id=s,title='G09 '+route+' '+s+' warm') for s in SHAPES])],
            control_executable=dict(target='g09_pipeline_control',stem='g09_pipeline_control'),
            controlled_environment=['HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_APPLE_QOS','HYLE_BENCH_AA_ROUTE','HYLE_BENCH_VERIFY_ONLY'],
            validators=[dict(id='artifact-identity',kind='artifact-identity'),dict(id='build-contract',kind='build-contract'),dict(id='pipeline-aa',kind='command',command=['{python}','-B','validate_aa.py','--build','{build}','--output','{output}','--profile',key])],
            measurement_adapter='nanobench-paired-rows-v1'),
        'measurement_recipe':dict(requested_epochs=11,actual_paired_rounds=12,exact_epoch_iterations=1,warmups_per_arm=8,elements=4194304,reason='Frozen before pilot AA; original ABBA rounds11 to12, fixed complete replay. No tuning from sample timing.'),
        'product_identity':dict(candidate=CANDIDATE,implementation=PRODUCT,baseline=BASELINE,source_git_role='Private consumer source identity only; not the product revision'),
        'placement_applicability':read(SOURCE/'source-ledger.json')['placement_applicability']}
    c['artifacts']['validators'] = ['artifact-identity','build-contract','pipeline-aa']
    write(SOURCE/('contract-'+key+'.json'),c)
print('Prepared four immutable-contract drafts and frozen artifact manifests; no build or sample')
