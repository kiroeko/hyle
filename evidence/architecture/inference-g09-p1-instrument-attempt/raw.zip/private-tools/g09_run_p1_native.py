"""Serial finite launch of the unchanged original P1 tool; preserve every attempt."""
from pathlib import Path
import ctypes, hashlib, json, os, platform, subprocess, sys, time

AIR = platform.system() == 'Darwin'
BASE = Path('/Users/kiro/hyle-scratch/compute-unified' if AIR else 'C:/h7')
ROOT = Path('C:/public/project-hyle/hyle') if not AIR else BASE
SOURCE = BASE/'g09-p1-instrument-source' if AIR else ROOT/'.scratch/inference-gaps/g09-p1-instrument-adapter'
TOOL = BASE/'g09-p1-peer-9e2/scripts/hyle-perf.py'
PEER = TOOL.parent.parent
OUT = BASE/'g09-p1-formal' if AIR else ROOT/'.scratch/inference-gaps/g09-p1-formal'
env = dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
if AIR:
    env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env.get('PATH','')
else:
    setup=subprocess.check_output(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace')
    env={k.upper():v for k,v in env.items()}
    env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
    env['VSLANG']='1033'
assert not any(k.upper() in ['CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH'] for k in env), 'No profiler injection in formal samples'
assert subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()==''
assert subprocess.check_output(['git','-C',str(PEER),'rev-parse','HEAD'],text=True).strip()=='9e2f25c469634a6f723e76eaf1aa2db5973bca9a'
for route in sys.argv[1:]:
    assert route in (['apple','vulkan'] if AIR else ['cuda','vulkan'])
    key=('air-' if AIR else 'windows-')+route
    folder=OUT/key
    build=BASE/'g09-p1-instrument'/route/'qualified-build'
    assert not folder.exists() and not build.exists(), 'Preserve previous attempts; no blind restart'
    folder.mkdir(parents=True)
    output=folder/'evidence'
    contract=SOURCE/('contract-'+key+'.json')
    cmd=[sys.executable,'-B',str(TOOL),'qualify-platform','--source',str(SOURCE),'--contract',str(contract),'--machine','M1-MAC' if AIR else 'W1-WIN','--peer','baseline9e2='+str(PEER),'--build',str(build),'--output',str(output)]
    started=time.monotonic()
    result=dict(state='RUNNING',profile=key,command=cmd,product_rebuilds=0,facade_rebuilds=0,source_revision=subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),contract_sha256=hashlib.sha256(contract.read_bytes()).hexdigest(),stages='Original fresh build, independent artifact equivalence, actual workload-AA, product+common-control n15->31, original qualification/statistical verdict; no tuning or retries')
    def save():
        result['elapsed_seconds']=time.monotonic()-started
        (folder/'run-result.json').write_text(json.dumps(result,indent=2)+'\n')
    try:
        flags=0 if AIR else subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS
        with (folder/'instrument.log').open('wb') as log:
            child=subprocess.Popen(cmd,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=flags)
            if not AIR:
                get=ctypes.windll.kernel32.GetProcessAffinityMask
                get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
                pin=ctypes.windll.kernel32.SetProcessAffinityMask;pin.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
                available,system=ctypes.c_size_t(),ctypes.c_size_t();handle=ctypes.c_void_p(int(child._handle))
                assert get(handle,ctypes.byref(available),ctypes.byref(system))
                assert pin(handle,sum([1<<i for i in range(64) if available.value&(1<<i)][:4]))
            result['child_pid']=child.pid;save()
            print(key,'RUNNING',child.pid,flush=True)
            while True:
                try:code=child.wait(timeout=1800);break
                except subprocess.TimeoutExpired:result.setdefault('extensions',[]).append(dict(pid=child.pid,seconds=1800));save()
        result.pop('child_pid',None)
        result.update(state='TERMINAL',exit_code=code)
        save();print(key,'TERMINAL',code,result['elapsed_seconds'],flush=True)
        if code:
            print((folder/'instrument.log').read_text(errors='replace')[-8000:],flush=True)
            break  # Inspect the exact terminal before authorizing any next profile.
    except BaseException as error:result.update(state='LAUNCH_FAIL',error=repr(error));save();raise
