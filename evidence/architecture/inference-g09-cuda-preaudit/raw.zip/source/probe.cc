#include <hyle/graph/cpu.h>
#include <hyle/graph/cuda.h>
#include <hyle/graph/cpu_cuda.h>
#include <cupti.h>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <vector>

namespace c=hyle::compute;
namespace g=hyle::graph;
namespace b=g::cpu_cuda;
namespace m=hyle::mem;
using hyle::Status;
struct Record { unsigned long long ns; char kind[16], name[96]; };
struct Trace {
  std::atomic<bool> active{false};
  std::mutex mutex;
  std::array<Record,1024> records{};
  std::size_t count=0;
  void record(const char* kind,const char* name="") noexcept {
    if(!active.load(std::memory_order_acquire))return;
    const auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    std::lock_guard guard(mutex);
    if(count==records.size())return;
    auto& r=records[count++];r.ns=static_cast<unsigned long long>(ns);
    std::snprintf(r.kind,sizeof(r.kind),"%s",kind);
    std::snprintf(r.name,sizeof(r.name),"%s",name);
  }
};
void CUPTIAPI callback(void* opaque,CUpti_CallbackDomain domain,CUpti_CallbackId,const void* data) {
  if(domain!=CUPTI_CB_DOMAIN_DRIVER_API)return;
  const auto& call=*static_cast<const CUpti_CallbackData*>(data);
  if(call.callbackSite==CUPTI_API_ENTER&&
     (std::strncmp(call.functionName,"cuLaunchKernel",14)==0||
      std::strncmp(call.functionName,"cuGraphLaunch",13)==0))
    static_cast<Trace*>(opaque)->record("gpu_enqueue",call.functionName);
}
void cpu_parallel(void* opaque,std::size_t count,c::ParallelTaskFn task,void* context) noexcept {
  auto& trace=*static_cast<Trace*>(opaque);trace.record("cpu_begin");
  for(std::size_t i=0;i<count;++i)task(context,i,count);
  trace.record("cpu_end");
}
struct Tensor {m::Buffer buffer;c::TensorView view;};
hyle::Result<Tensor> tensor(m::MemoryResourceRef resource,c::TensorDesc desc) {
  HYLE_ASSIGN_OR_RETURN(auto bytes,desc.required_bytes());
  HYLE_ASSIGN_OR_RETURN(auto buffer,m::Buffer::create(resource,bytes,256));
  HYLE_ASSIGN_OR_RETURN(auto view,c::TensorView::create(desc,buffer.view()));
  return Tensor{std::move(buffer),view};
}
Status run(Trace& trace,bool cpu_first) {
  HYLE_ASSIGN_OR_RETURN(auto cpu,g::cpu::create_context({.executor=c::ParallelExecutorRef{&trace,1,&cpu_parallel}}));
  HYLE_ASSIGN_OR_RETURN(auto cuda,g::cuda::create_context());
  HYLE_ASSIGN_OR_RETURN(auto pinned,c::cuda::MemoryResource::create(cuda,c::cuda::MemoryKind::kPinnedHost));
  HYLE_ASSIGN_OR_RETURN(auto device,c::cuda::MemoryResource::create(cuda,c::cuda::MemoryKind::kDevice));
  constexpr std::size_t elements=4*1024*1024;
  HYLE_ASSIGN_OR_RETURN(auto desc,c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{elements}));
  HYLE_ASSIGN_OR_RETURN(auto x,tensor(m::system_resource(),desc));
  HYLE_ASSIGN_OR_RETURN(auto a,tensor(device.ref(),desc));
  HYLE_ASSIGN_OR_RETURN(auto y,tensor(m::system_resource(),desc));
  std::vector<float> values(elements,1.25f);
  HYLE_RETURN_IF_ERROR(a.buffer.view().write(std::as_bytes(std::span(values))));
  for(std::size_t i=0;i<elements;++i)values[i]=float(int(i%101)-50)*0.125f;
  HYLE_RETURN_IF_ERROR(x.buffer.view().write(std::as_bytes(std::span(values))));
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto xi,builder.input(desc));
  HYLE_ASSIGN_OR_RETURN(auto ai,builder.input(desc));
  g::ValueId cv,av;
  if(cpu_first){HYLE_ASSIGN_OR_RETURN(cv,builder.add(c::Unary{c::UnaryKind::kAbs},xi));HYLE_ASSIGN_OR_RETURN(av,builder.add(c::Unary{c::UnaryKind::kNeg},ai));}
  else {HYLE_ASSIGN_OR_RETURN(av,builder.add(c::Unary{c::UnaryKind::kNeg},ai));HYLE_ASSIGN_OR_RETURN(cv,builder.add(c::Unary{c::UnaryKind::kAbs},xi));}
  HYLE_ASSIGN_OR_RETURN(auto out,builder.add(c::Binary{},cv,av));
  HYLE_RETURN_IF_ERROR(builder.publish(out));
  HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
  const std::array placements{
    g::NodePlacement{*graph.node_id(cpu_first?0:1),b::kCpuTarget,g::PlacementStrength::kRequired},
    g::NodePlacement{*graph.node_id(cpu_first?1:0),b::kCudaTarget,g::PlacementStrength::kRequired},
    g::NodePlacement{*graph.node_id(2),b::kCpuTarget,g::PlacementStrength::kRequired}};
  const std::array external{g::ExternalResourceContract{xi,b::kHostStorage},
    g::ExternalResourceContract{ai,b::kDeviceStorage},g::ExternalResourceContract{out,b::kHostStorage}};
  HYLE_ASSIGN_OR_RETURN(auto compiled,b::compile(graph,{.cpu=&cpu,.cuda=&cuda,.staging=&pinned,.device=&device},
    {.node_placements=placements,.external_resources=external}));
  std::printf("{\"case\":\"%s\",\"segments\":%zu,\"serialization_edges\":%zu}\n",cpu_first?"cpu-first":"gpu-first",compiled.report.segment_count(),compiled.report.serialization_edge_count());
  for(std::size_t i=0;i<compiled.report.step_count();++i){
    HYLE_ASSIGN_OR_RETURN(auto s,compiled.report.step(i));
    std::printf("{\"step\":%zu,\"target\":%u,\"kind\":%u,\"blocks_host\":%s,\"nodes\":[",i,s.target.ordinal(),unsigned(s.kind),s.runtime.blocks_host?"true":"false");
    for(std::size_t j=0;j<s.node_count;++j){HYLE_ASSIGN_OR_RETURN(auto n,compiled.report.step_node(i,j));std::printf("%s%u",j?",":"",n.ordinal());}
    std::puts("]}");
  }
  for(std::size_t i=0;i<compiled.report.segment_count();++i){
    HYLE_ASSIGN_OR_RETURN(auto s,compiled.report.segment(i));
    std::printf("{\"segment\":%zu,\"lane\":%u,\"step_begin\":%u,\"step_count\":%u,\"dependencies\":[",i,s.lane.ordinal(),s.step_begin,s.step_count);
    for(std::size_t j=0;j<s.dependency_count;++j){HYLE_ASSIGN_OR_RETURN(auto d,compiled.report.segment_dependency(i,j));std::printf("%s%u",j?",":"",d.source_segment);}
    std::puts("]}");
  }
  hyle::sched::Scheduler scheduler(2,m::system_allocator(),64);
  HYLE_ASSIGN_OR_RETURN(auto cq,cpu.create_queue());HYLE_ASSIGN_OR_RETURN(auto gq,cuda.create_queue());
  struct Drain {hyle::sched::Scheduler& scheduler;~Drain(){scheduler.drain();}} drain{scheduler};
  HYLE_ASSIGN_OR_RETURN(auto native,compiled.executable.create_invocation());
  const std::array bindings{g::QueueBinding{g::ExecutionLaneId{0},&gq},g::QueueBinding{g::ExecutionLaneId{1},&cq}};
  HYLE_ASSIGN_OR_RETURN(auto invocation,b::Invocation::create(std::move(native),scheduler,bindings));
  HYLE_RETURN_IF_ERROR(invocation.bind(xi,x.view.as_const()));HYLE_RETURN_IF_ERROR(invocation.bind(ai,a.view.as_const()));HYLE_RETURN_IF_ERROR(invocation.bind(out,y.view));HYLE_RETURN_IF_ERROR(invocation.prepare_replay());
  trace.count=0;trace.active.store(true,std::memory_order_release);
  auto work=invocation.submit();
  if(!work){trace.active.store(false);return work.error();}
  auto result=work->wait();trace.active.store(false,std::memory_order_release);
  if(!result)return result.error();
  HYLE_RETURN_IF_ERROR(y.buffer.view().read(std::as_writable_bytes(std::span(values))));
  for(std::size_t i=0;i<elements;++i)if(values[i]!=std::abs(float(int(i%101)-50)*0.125f)-1.25f)return Status::Internal("CPU+CUDA branch/join independent oracle differs");
  std::size_t cpu_calls=0,gpu_calls=0;
  for(std::size_t i=0;i<trace.count;++i){const auto& r=trace.records[i];cpu_calls+=std::strcmp(r.kind,"cpu_begin")==0;gpu_calls+=std::strcmp(r.kind,"gpu_enqueue")==0;std::printf("{\"event\":\"%s\",\"ns\":%llu,\"name\":\"%s\"}\n",r.kind,r.ns,r.name);}
  std::printf("{\"oracle\":\"PASS\",\"cpu_episodes\":%zu,\"actual_cuda_enqueue_callbacks\":%zu}\n",cpu_calls,gpu_calls);
  HYLE_RETURN_IF_ERROR(invocation.close());scheduler.drain();
  if(cpu_calls==0||gpu_calls==0)return Status::Internal("required natural CPU executor or real CUDA launch observation missing");
  return Status::Ok();
}
int main(){
  Trace trace;CUpti_SubscriberHandle subscriber{};
  auto rc=cuptiSubscribe(&subscriber,&callback,&trace);
  if(rc==CUPTI_SUCCESS)rc=cuptiEnableDomain(1,subscriber,CUPTI_CB_DOMAIN_DRIVER_API);
  if(rc!=CUPTI_SUCCESS){std::fprintf(stderr,"CUPTI setup failed %u\n",unsigned(rc));return 2;}
  auto status=run(trace,true);if(status.ok())status=run(trace,false);
  cuptiUnsubscribe(subscriber);
  if(!status.ok()){std::fprintf(stderr,"%.*s\n",int(status.message().size()),status.message().data());return 1;}
  return 0;
}
