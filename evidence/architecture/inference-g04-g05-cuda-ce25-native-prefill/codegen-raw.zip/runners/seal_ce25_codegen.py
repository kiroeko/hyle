from pathlib import Path
import hashlib,json,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';run=base/'ce25-fixed-codegen-1'
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_PASS' and len(r['kernels'])==3
assert r['product_candidate']=='0143102aebcbc29600a77ce2950136462fba2a36'
assert [row['projected_mma_kv'] for row in r['kernels']]==[1,1,4]
dest=root/'evidence/architecture/inference-g04-g05-cuda-ce25-native-prefill'
assert (dest/'source-audit.json').exists() and not (dest/'codegen-receipt.json').exists()
with zipfile.ZipFile(dest/'codegen-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(run).as_posix())
    z.write(base/'seal_ce25_codegen.py','runners/seal_ce25_codegen.py')
receipt=dict(kind='G04_G05_CE25_ORIGINAL_PREFILL_REPACK_CODEGEN',verdict='EXTRACTION_PASS_STATIC_RESOURCES_ONLY',
 product_candidate=r['product_candidate'],binary_sha256=r['binary_sha256'],header_sha256=r['header_sha256'],
 kernels=r['kernels'],stages=r['stages'],measured_seconds=sum(s['elapsed_seconds'] for s in r['stages']),
 limits=['Same1/1/4MMA specializations as CE24; original prefill repack predicates restored. Static resources/instruction counts only.',
         'Actual dynamic shared/runtime identity,new SDK/numeric/host/original P1 remain separate gates.',
         'All prior qualified8/9/10 failures,failed hypotheses and measured costs retained.'],
 raw_zip_sha256=hashlib.sha256((dest/'codegen-raw.zip').read_bytes()).hexdigest())
(dest/'codegen-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(json.dumps([dict(mma_kv=row['projected_mma_kv'],ce24=row['ce24_same_mma_resource'],ce25=row['after_resource'],local=row['after_sass']) for row in r['kernels']],indent=2))
