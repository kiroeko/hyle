from pathlib import Path
import hashlib,json,os,subprocess,time

canonical=Path('/mnt/c/public/project-hyle/hyle')
base=Path('/root/hyle-scratch/compute-unified')
source=base/'source-7a7b4c3b'
build=base/'l-cpu-cuda/selected-graph/source-build'
parent=base/'l-cpu-cuda/selected-graph/source-parent/CMakeLists.txt'
out=canonical/'.scratch/inference-gaps/g03/producer-source-probe'
out.mkdir(exist_ok=True)
assert source.is_dir() and not (source/'.git').exists() and build.is_dir()
names={'cmake/HyleComponents.cmake','src/compute/batch_transfer.cc','docs/implementation/module-status.json',
       'tests/compute_batch/producer_source_public_probe.cc'}
names.update(str(p.relative_to(canonical)) for p in (canonical/'include/hyle/compute').rglob('*.h'))
names.update(str(p.relative_to(canonical)) for p in (canonical/'src/compute_batch').iterdir() if p.is_file())
manifest=[];changed=[]
for name in sorted(names):
 data=(canonical/name).read_bytes();dest=source/name
 manifest.append({'path':name,'sha256':hashlib.sha256(data).hexdigest()})
 if not dest.exists() or dest.read_bytes()!=data:
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
(out/'inputs.json').write_text(json.dumps({'candidate':'b42832de3ddda21bdc3e98ad4cc87e73622cbba4','one_way':True,'inputs':manifest,'changed':changed},indent=2)+'\n')
target='g03_producer_source_probe'
body=parent.read_bytes()
if ('add_executable('+target+' ').encode() not in body:
 body+=f'\nadd_executable({target} "{source}/tests/compute_batch/producer_source_public_probe.cc")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle_compute_batch hyle_compute_backend_cuda)\nhyle_stage_runtime({target})\n'.encode()
 parent.write_bytes(body)
record=out/'result.json';rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
identity={'uname':subprocess.check_output(['uname','-a'],text=True).strip(),
 'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.used,utilization.gpu','--format=csv,noheader'],text=True).strip(),
 'compiler':subprocess.check_output(['/usr/bin/g++-14','--version'],text=True).splitlines()[0]}
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
for stage,args in [('build',['cmake','--build',str(build),'--target',target,'--parallel','4']),('tiny-producer-probe',[str(build/target)])]:
 attempt=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as stream:
  process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}))
  print('RUN',stage,'PID',process.pid,flush=True);code=process.wait()
 rows.append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)})
 record.write_text(json.dumps({'candidate':'b42832de3ddda21bdc3e98ad4cc87e73622cbba4','identity':identity,'stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n')
 print(log.read_text(errors='replace')[-6500:],flush=True)
 if code:break
(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code}))
raise SystemExit(code)
