from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');tag=sys.argv[1]
out=base/'g08-sdk-evidence'/tag;prior=json.loads((out/'result.json').read_text())
assert prior['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS','PUBLIC_SOURCE_CONSUMERS_HEADERS_PASS']
receipt=out/'runtime-audit.json';assert not receipt.exists()
prefix=base/'g08-sdk'/tag/'relocated';producer=Path(prior['producer']);source=base/'source-c8874688'
env=os.environ.copy();env['DYLD_PRINT_LIBRARIES']='1';env['HYLE_VULKAN_VALIDATION']='0'
started=time.monotonic();r=dict(state='RUNNING',pid=os.getpid(),source_snapshot=prior['source_snapshot'],candidate=prior['candidate'],stages=[],loaded_hyle_libraries=[])
def save():
    r['elapsed_seconds']=time.monotonic()-started;receipt.write_text(json.dumps(r,indent=2)+'\n')
try:
    for artifact in prior['consumers']:
        binary=Path(artifact['path']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==artifact['sha256']
        name=artifact['name'];args=[str(binary)]
        if name.endswith('direct'):args+=['--random-only']
        if name.endswith('graph'):args+=['--ports-only']
        log=out/('runtime-'+name+'.log');stamp=time.monotonic()
        with log.open('w') as stream:
            p=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(stage=name,child_pid=p.pid);save();code=p.wait()
        r['stages'].append(dict(name=name,command=args,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save();assert code==0,name
        text=log.read_text(errors='replace');loaded=[]
        for line in text.splitlines():
            if line.startswith('dyld[') and '/libhyle' in line and '.dylib' in line:
                path=Path(line.split()[-1]);assert path.is_file(),str(path)
                if prior['mode']=='source':assert path.resolve().is_relative_to(producer.resolve()),str(path)
                else:assert path.resolve().is_relative_to(prefix.resolve()),str(path)
                loaded.append(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        if prior['mode']!='static':assert loaded,(name,text[:2000])
        r['loaded_hyle_libraries'].append(dict(consumer=name,libraries=loaded))
    r['state']='RUNTIME_PATH_ISOLATION_PASS';save();print(tag,r['state'],flush=True)
except BaseException as error:r.update(state='FAIL',error=repr(error));save();raise
