from pathlib import Path
import json,os,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');label,package=sys.argv[1:3]
out=base/f'g08-air-sdk-matrix-{label}';out.mkdir(exist_ok=False);started=time.monotonic()
r=dict(state='RUNNING',pid=os.getpid(),serial=True,max_jobs_per_build=4,cases=[])
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
for route,mode in [('apple','static'),('apple','source'),('vulkan','shared'),('vulkan','static'),('vulkan','source')]:
    cmd=[sys.executable,str(base/'g08_sdk.py'),route,mode,label,package]
    p=subprocess.Popen(cmd);r.update(stage=f'{route}-{mode}',child_pid=p.pid);save();code=p.wait()
    path=base/'g08-sdk-evidence'/f'{route}-{mode}-{label}/result.json'
    result=json.loads(path.read_text()) if path.is_file() else dict(state='NO_RESULT')
    case=dict(route=route,mode=mode,exit_code=code,state=result['state'],result=str(path))
    if code==0 and result['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS','PUBLIC_SOURCE_CONSUMERS_HEADERS_PASS']:
        audit=subprocess.Popen([sys.executable,str(base/'g08_sdk_runtime_air.py'),f'{route}-{mode}-{label}'])
        r.update(stage=f'{route}-{mode}-runtime',child_pid=audit.pid);save();case['runtime_exit_code']=audit.wait()
    r['cases'].append(case);r.pop('child_pid',None);save()
r['state']='ALL_FIVE_DELIVERY_CONFIGS_PASS' if all(x['exit_code']==0 and x.get('runtime_exit_code')==0 for x in r['cases']) else 'FAIL_WITH_ALL_CONFIGS_OBSERVED'
save();print(r['state'],flush=True)
