from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile
route,mode,label,package=sys.argv[1:5];assert route in ['cuda','apple','vulkan'] and mode in ['static','shared','source']
resume='--resume-consumer' in sys.argv
air=sys.platform=='darwin';assert air==(route!='cuda')
base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified'
canonical=None if air else Path('/mnt/c/public/project-hyle/hyle')
source=base/('source-c8874688' if air else 'source-7a7b4c3b')
tag=f'{route}-{mode}-{label}';out=(base/'g08-sdk-evidence' if air else canonical/'.scratch/inference-gaps/g08-sdk')/tag
if not resume:out.mkdir(parents=True,exist_ok=False)
folder=base/'g08-sdk'/tag
if not resume:folder.mkdir(parents=True,exist_ok=False)
family=base/f'{"a" if air else "l"}-cpu-{route}/selected-graph'
producer=family/('source-build' if mode=='source' else mode+'-sdk-build')
env=os.environ.copy();env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
env['HYLE_VULKAN_VALIDATION']='0'
cmake='/opt/homebrew/bin/cmake' if air else 'cmake';ninja='/opt/homebrew/bin/ninja' if air else 'ninja'
jobs=4 if air else 2;started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(state='SETUP',pid=os.getpid(),route=route,mode=mode,producer=str(producer),max_jobs=jobs,stages=[],
    scope='G08 fixed candidate public numerical Direct/Graph/joint, CPU and Mem consumers with independent headers; source embedding or relocated shipping SDK. No P1/full-engine claim.')
if resume:
    r=json.loads((out/'result.json').read_text());assert r['state']=='SETUP_FAIL' and mode!='source'
    assert any(x['stage']=='install' and x['exit_code']==0 for x in r['stages'])
    r.setdefault('retained_consumer_failures',[]).append(dict(error=r.pop('error'),elapsed_seconds=r['elapsed_seconds'],reason='Correct private consumer header name to actual public allocator.h; retain existing installed prefix/producer/source and original failure/cost.'))
    started=time.monotonic()-r['elapsed_seconds'];r['pid']=os.getpid()
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(tag,stage,p.pid,flush=True);code=p.wait()
    r['stages'].append(dict(stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
    if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
try:
    r['identity']={name:subprocess.check_output(args,env=env,text=True).strip() for name,args in
        ([('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version']),('metal',['xcrun','-sdk','macosx','metal','--version'])] if air else
         [('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['nvcc','--version']),('gpu',['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'])])}
    if air:assert r['identity']['model']=='Mac16,12'
    archive=base/f'g08-input-{package}.zip' if air else canonical/f'.scratch/inference-gaps/g08-input-{package}.zip'
    with zipfile.ZipFile(archive) as z:
        manifest=json.loads(z.read('input-manifest.json'));changed=[]
        for item in manifest['inputs']:
            rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
            data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
            p=source/rel
            if not p.exists() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
    (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2));r['source_snapshot']=manifest['source_snapshot'];r['synced_paths']=changed
    registry=json.loads((source/'docs/implementation/module-status.json').read_text());owners=[x for x in registry['modules'] if x.get('record','').endswith('inference-g08-output-selection.md')]
    assert len(owners)==8 and all(x['state']=='CANDIDATE' and x['candidate']=='5103c13d8ed119b06aa64e799f9768aea45ab913' for x in owners)
    r['candidate']=owners[0]['candidate']
    profile=base/'g08_shipping_cuda_profile.cmake' if air else canonical/'.scratch/inference-gaps/g08_shipping_cuda_profile.cmake'
    configure=[cmake,'-S',str(source),'-B',str(producer),'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON',
        '-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu;'+route,'-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF')]
    configure+=['-UCMAKE_PROJECT_INCLUDE'] if air else ['-DCMAKE_PROJECT_INCLUDE='+str(profile)]
    if mode!='source' and not resume:
        run('producer-configure',configure);run('producer-manifest',[ninja,'-C',str(producer),'build.ninja'])
        commands=json.loads(subprocess.check_output([ninja,'-C',str(producer),'-t','compdb'],env=env,text=True))
        shipping=[x for x in commands if x['file'].startswith(str(source/'src')+'/')]
        assert shipping and all('HYLE_TESTING' not in x['command'] and '-fsanitize=' not in x['command'] for x in shipping)
        (out/'shipping-commands.json').write_text(json.dumps(shipping,indent=2))
        preview=out/'preview.ninja';preview.write_bytes((producer/'build.ninja').read_bytes())
        if not air:
            run('native-reuse',['python3',str(canonical/'.scratch/inference-gaps/g04-g05/ce28_shipping_native_reuse_wsl.py'),mode,'g08-sdk-'+label])
            reuse=canonical/f'.scratch/inference-gaps/g04-g05/ce28-{mode}-native-reuse-g08-sdk-{label}'
            proof=json.loads((reuse/'result.json').read_text());assert proof['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
            r['native_reuse']=proof;preview.write_bytes((reuse/'reuse.ninja').read_bytes())
        targets=['hyle_compute','hyle_compute_ops','hyle_compute_batch','hyle_compute_state','hyle_compute_stream','hyle_graph','hyle_graph_batch',f'hyle_compute_route_{route}',f'hyle_graph_route_{route}',f'hyle_graph_route_cpu_{route}']
        dry=subprocess.check_output([ninja,'-C',str(producer),'-f',str(preview),'-n',*targets],env=env,text=True);(out/'dry-run.log').write_text(dry)
        cuda=[x for x in dry.splitlines() if 'Building CUDA object' in x];r['cuda_edges']=cuda;r['build_edges']=len(dry.splitlines());save()
        assert 'Re-running CMake' not in dry and (not air or not cuda)
        if not air:assert len(cuda)<=2 and all('compute_provider_cuda' in x and ('collectives.cu' in x or 'sampling_kernel.cu' in x) for x in cuda),cuda
        run('producer-build',[ninja,'-C',str(producer),'-f',str(preview),'-j',str(jobs),*targets])
        staging=folder/'staging';prefix=folder/'relocated'
        assert staging.resolve().parent==folder.resolve() and prefix.resolve().parent==folder.resolve()
        run('install',[cmake,'--install',str(producer),'--prefix',str(staging)])
        staging.rename(prefix);assert not staging.exists();consumer=folder/'consumer';consumer.mkdir()
    elif mode=='source':
        prefix=None;consumer=family/'source-parent';consumer.mkdir(exist_ok=True)
        if (consumer/'CMakeLists.txt').is_file():(out/'original-source-parent.cmake').write_bytes((consumer/'CMakeLists.txt').read_bytes())
    else:
        prefix=folder/'relocated';consumer=folder/'consumer';assert prefix.is_dir() and consumer.is_dir() and not (folder/'staging').exists()
        state_dry=subprocess.check_output([ninja,'-C',str(producer),'-f',str(out/'preview.ninja'),'-n','hyle_compute_state'],env=env,text=True)
        (out/'state-freshness.log').write_text(state_dry)
        assert 'Building CUDA object' not in state_dry and 'Re-running CMake' not in state_dry
        if 'no work to do' not in state_dry:
            run('producer-state-freshness',[ninja,'-C',str(producer),'-f',str(out/'preview.ninja'),'-j',str(jobs),'hyle_compute_state'])
            run('install-state-freshness',[cmake,'--install',str(producer),'--prefix',str(prefix)])
    copied=set()
    def copy(relative):
        if relative in copied:return
        p=source/relative;assert p.resolve().is_relative_to((source/'tests').resolve()),relative
        data=p.read_bytes();dst=consumer/relative;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);copied.add(relative)
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode('utf-8'),re.M):
            if include.startswith('hyle/'):continue
            path=(p.parent/include).resolve();assert path.is_relative_to((source/'tests').resolve()),(relative,include)
            copy(path.relative_to(source).as_posix())
    fixtures={'cpu_direct':('tests/compute_route_cpu/sampling_consumer.cc',False),'cpu_graph':('tests/compute_route_cpu/sampling_consumer.cc',True),
        'native_direct':(f'tests/compute_route_{route}/sampling_consumer.cc',False),'native_graph':(f'tests/compute_route_{route}/sampling_consumer.cc',True),
        'joint':(f'tests/graph_route_cpu_{route}/sampling_consumer.cc',False)}
    for path,_ in fixtures.values():copy(path)
    allocator=(source/'tests/mem/allocator_test.cc').read_text();buffer=(source/'tests/mem/buffer_resource_test.cc').read_text()
    public_mem='#include <gtest/gtest.h>\n#include <algorithm>\n#include <array>\n#include <cstdint>\n#include <cstring>\n#include <span>\n#include <thread>\n#include <utility>\n#include <hyle/mem/allocator.h>\n#include <hyle/mem/system_inline.h>\n#include <hyle/mem/buffer.h>\nusing namespace hyle::mem;\n'
    public_mem+=allocator[allocator.index('TEST(SystemAllocator, AlignedRequestedSizeCrossingSmallPageKeepsActualPageIdentity)'):]
    public_mem+=buffer[buffer.index('TEST(BufferResource, OverAlignedSmallRequestFullWriteReadMoveAndRelease)'):]
    assert public_mem.count('TEST(')==3 and 'system_internal' not in public_mem
    (consumer/'mem_public.cc').write_text(public_mem);fixtures['mem']=('mem_public.cc',False)
    headers=['compute/sampling_ops.h','compute/operation.h','compute/prepared_operation.h','compute/cpu.h','graph/cpu.h','mem/allocator.h','mem/system_inline.h','mem/buffer.h',f'compute/{route}.h',f'graph/{route}.h',f'graph/cpu_{route}.h']
    if route=='cuda':headers+=['compute/backends/cuda.h','compute/providers/cuda.h']
    for i,name in enumerate(headers):
        if prefix:assert sha(prefix/'include/hyle'/name)==sha(source/'include/hyle'/name),name
        (consumer/f'header-{i}.cc').write_text('#include <hyle/'+name+'>\n')
    body='cmake_minimum_required(VERSION 3.25)\nproject(g08_public_delivery LANGUAGES CXX)\n'
    if mode=='source':
        body+='set(HYLE_COMPONENTS "compute;graph" CACHE STRING "" FORCE)\nset(HYLE_COMPUTE_ROUTES "cpu;'+route+'" CACHE STRING "" FORCE)\nset(HYLE_BUILD_TESTS OFF CACHE BOOL "" FORCE)\nset(HYLE_INSTALL OFF CACHE BOOL "" FORCE)\nset(HYLE_TEST_INSTRUMENTATION OFF CACHE BOOL "" FORCE)\nadd_subdirectory("'+str(source)+'" hyle)\n'
    else:body+='find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\n'
    gtest=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6') if air else Path('/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6')
    body+='set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\nadd_subdirectory("'+str(gtest)+'" g08-gtest EXCLUDE_FROM_ALL)\n'
    for name,(path,graph) in fixtures.items():
        body+=f'add_executable({name} "{path}")\ntarget_compile_features({name} PRIVATE cxx_std_23)\ntarget_link_libraries({name} PRIVATE hyle::compute hyle::graph'+(' GTest::gtest_main' if name=='mem' else '')+')\nhyle_stage_runtime('+name+')\n'
        if graph:body+='target_compile_definitions('+name+' PRIVATE HYLE_G08_GRAPH=1)\n'
    body+='add_library(headers OBJECT '+' '.join(f'header-{i}.cc' for i in range(len(headers)))+')\ntarget_compile_features(headers PRIVATE cxx_std_23)\ntarget_link_libraries(headers PRIVATE hyle::compute hyle::graph)\n'
    (consumer/'CMakeLists.txt').write_text(body);(out/'consumer.cmake').write_text(body)
    build=producer if mode=='source' else folder/'consumer-build'
    args=[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    if prefix:args+=['-DCMAKE_PREFIX_PATH='+str(prefix)]
    if not air:args+=['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3']
    if mode=='source':args+=['-DHYLE_STATIC=OFF','-DHYLE_BUILD_BENCH=OFF','-UCMAKE_PROJECT_INCLUDE'] if air else ['-DCMAKE_PROJECT_INCLUDE='+str(profile)]
    run('consumer-configure',args)
    run('consumer-build',[cmake,'--build',str(build),'--target',*fixtures,'headers','--parallel',str(jobs)])
    actual=[x for x in json.loads((build/'compile_commands.json').read_text()) if x['file'].startswith(str(consumer)+'/')]
    assert len(actual)==len(fixtures)+len(headers),(len(actual),len(fixtures)+len(headers))
    for row in actual:
        command=row['command']
        if prefix:assert str(source) not in command and str(producer) not in command and str(prefix/'include') in command,command
        else:assert str(source/'include') in command and str(source/'src') not in command,command
    (out/'consumer-commands.json').write_text(json.dumps(actual,indent=2))
    for name in fixtures:
        binary=build/name;run(name,[str(binary)])
        r.setdefault('consumers',[]).append(dict(name=name,path=str(binary),sha256=sha(binary)))
        if name=='mem':assert '[  PASSED  ] 3 tests.' in (out/(name+'.log')).read_text()
        if not air:
            dependencies=subprocess.check_output(['ldd',str(binary)],env=env,text=True);(out/(name+'-ldd.log')).write_text(dependencies)
            assert 'not found' not in dependencies and (mode=='source' or str(producer) not in dependencies)
    r['independent_headers']=[dict(path=x,sha256=sha((prefix/'include/hyle' if prefix else source/'include/hyle')/x)) for x in headers]
    if prefix:
        license_paths=[p for p in (prefix/'share/licenses/Hyle').glob('*') if p.is_file() and 'random123' in p.name.lower()]
        assert len(license_paths)>=2,[str(p) for p in license_paths]
        r['random123_license']=[dict(path=str(p),sha256=sha(p)) for p in license_paths]
    assert all(sha(source/x['path'])==x['sha256'] for x in manifest['inputs'])
    r['state']='PUBLIC_SOURCE_CONSUMERS_HEADERS_PASS' if mode=='source' else 'RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS';save();print(tag,r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
