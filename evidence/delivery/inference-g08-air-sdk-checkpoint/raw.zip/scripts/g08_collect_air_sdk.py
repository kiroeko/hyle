from pathlib import Path
import hashlib,json,os,subprocess,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified')
matrix=base/'g08-air-sdk-matrix-1/result.json'
m=json.loads(matrix.read_text());assert m['state']=='ALL_FIVE_DELIVERY_CONFIGS_PASS',m['state']
try:os.kill(m['pid'],0)
except ProcessLookupError:pass
else:raise AssertionError('Matrix process is still alive')
output=base/'g08-air-sdk-complete-1.zip';assert not output.exists()
receipts=[]
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for route in ['apple','vulkan']:
        for mode in ['shared','static','source']:
            tag=f'{route}-{mode}-1';folder=base/'g08-sdk-evidence'/tag
            result=json.loads((folder/'result.json').read_text());runtime=json.loads((folder/'runtime-audit.json').read_text())
            assert result['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS','PUBLIC_SOURCE_CONSUMERS_HEADERS_PASS']
            assert runtime['state']=='RUNTIME_PATH_ISOLATION_PASS'
            assert result['candidate']=='5103c13d8ed119b06aa64e799f9768aea45ab913'
            for item in result['consumers']:
                p=Path(item['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
            receipts.append(dict(route=route,mode=mode,result=result,runtime=runtime))
            for p in folder.rglob('*'):
                if p.is_file():z.write(p,str(Path(tag)/p.relative_to(folder)))
    z.write(matrix,'matrix/result.json')
    for name in ['g08_sdk.py','g08_sdk_runtime_air.py','g08_air_sdk_matrix.py','g08_collect_air_sdk.py']:
        z.write(base/name,'scripts/'+name)
    z.writestr('summary.json',json.dumps(dict(state='ALL_SIX_AIR_DELIVERIES_AND_RUNTIME_ISOLATION_PASS',cases=receipts),indent=2)+'\n')
print(json.dumps(dict(state='ALL_SIX_AIR_DELIVERIES_AND_RUNTIME_ISOLATION_PASS',archive=str(output),sha256=hashlib.sha256(output.read_bytes()).hexdigest(),bytes=output.stat().st_size)))
