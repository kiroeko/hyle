from pathlib import Path

root=Path('C:/public/project-hyle/hyle');p=root/'.scratch/inference-gaps/g09_air_sdk.py';body=p.read_text()
def replace(old,new):
 global body
 assert body.count(old)==1,(old,body.count(old))
 body=body.replace(old,new)
replace("base=Path('/Users/kiro/hyle-scratch/compute-unified')", "base=Path('/root/hyle-scratch/compute-unified');canonical=Path('/mnt/c/public/project-hyle/hyle')")
replace("assert sys.platform=='darwin' and route in ['apple','vulkan'] and mode in ['source','static','shared']", "assert sys.platform=='linux' and route=='cuda' and mode in ['source','static','shared']")
replace("source=base/'source-c8874688';inputs=base/'g09-sdk-inputs';resume='--resume-preflight' in sys.argv", "source=base/'source-7a7b4c3b';inputs=canonical/'.scratch/inference-gaps/g09-delivery-source-bc6';resume=False")
replace("producer=base/f'a-cpu-{route}/selected-graph'", "producer=base/f'l-cpu-{route}/selected-graph'")
replace("env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),", "env=dict(os.environ,PATH='/usr/local/cuda-13.3/bin:'+os.environ.get('PATH',''),LD_LIBRARY_PATH='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib',")
replace("os.nice(10);cmake='/opt/homebrew/bin/cmake';ninja='/opt/homebrew/bin/ninja';started=time.monotonic()", "os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4]);cmake='cmake';ninja='ninja';started=time.monotonic();profile=canonical/'.scratch/inference-gaps/g08_shipping_cuda_profile.cmake'")
replace("'max_jobs':4,'nice':os.nice(0)", "'max_jobs':2,'nice':os.nice(0),'logical_cpus':sorted(os.sched_getaffinity(0)),'cuda_compile_pool':1,'cuda_split_compile':3")
first=body.index("    if route=='vulkan' and build==producer:");last=body.index("    dry=subprocess.check_output",first)
body=body[:first]+body[last:]
first=body.index("    (out/(label+'-dry-run.log')).write_text(dry)")
native=r'''    (out/(label+'-unmapped-dry-run.log')).write_text(dry)
    if build==producer and any('Building CUDA object' in x and ('ggml-cuda.dir' in x or 'ggml-cuda-precise-unary.dir' in x) for x in dry.splitlines()):
        label_id='g09-sdk-'+mode+'-1'
        if mode=='source':
            helper=canonical/'.scratch/inference-gaps/g08_posix_source_native_reuse.py'
            run(label+'-native-reuse',[sys.executable,helper,label_id]);reuse=canonical/'.scratch/inference-gaps'/('g08-posix-source-native-reuse-'+label_id)
            expected='PASS_146_POSIX_SOURCE_NATIVE_OBJECTS_INPUTS_AND_ORIGINAL_COMMANDS_FRESH'
        else:
            helper=canonical/'.scratch/inference-gaps/g04-g05/ce28_shipping_native_reuse_wsl.py'
            run(label+'-native-reuse',[sys.executable,helper,mode,label_id]);reuse=canonical/'.scratch/inference-gaps/g04-g05'/('ce28-'+mode+'-native-reuse-'+label_id)
            expected='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
        proof=json.loads((reuse/'result.json').read_text());assert proof['state']==expected,proof['state']
        assert proof['original_manifest_sha256']==sha(build/'build.ninja') and proof['reuse_manifest_sha256']==sha(reuse/'reuse.ninja')
        r[label+'_native_reuse']={'path':str(reuse),'proof_sha256':sha(reuse/'result.json'),'proof':proof}
        preview.write_bytes((reuse/'reuse.ninja').read_bytes())
        dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
'''
body=body[:first]+native+body[first:]
replace("'-j','4',*targets", "'-j','2',*targets")
first=body.index("    r['identity']={");last=body.index("    assert sha(inputs/'source.zip')",first)
body=body[:first]+'''    r['identity']={k:subprocess.check_output(v,env=env,text=True).strip() for k,v in {'host':['uname','-a'],'compiler':['g++-14','--version'],'cuda':['nvcc','--version'],'gpu':['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader']}.items()}
    (out/'runner.py').write_bytes(Path(__file__).read_bytes())
'''+body[last:]
replace("'-UCMAKE_PROJECT_INCLUDE'])", "'-DCMAKE_PROJECT_INCLUDE='+str(profile)])")
replace("fixtures={'g09_contracts':f'tests/graph/cpu_{route}_contracts.cc','g09_pipeline':'tests/graph/native_joint_pipeline.cc',\n              'g09_pending':'tests/compute_batch/pending_paged_receiver_native_consumer.cc'}", "fixtures={'g09_contracts':'tests/graph/cpu_cuda_contracts.cc','g09_pipeline':'tests/graph/cpu_cuda_pipeline.cc','g09_g06_hybrid':'tests/compute_batch/public_hybrid_batch_consumer.cc','g09_g06_pending':'tests/compute_batch/pending_paged_receiver_cuda_consumer.cc'}")
replace("target_link_libraries({name} PRIVATE hyle::compute hyle::graph)", "target_link_libraries({name} PRIVATE hyle::compute hyle::graph CUDA::cudart)")
replace("    body+='target_compile_definitions(g09_pending PRIVATE HYLE_PENDING_NATIVE_JOINT_GRAPH=1)\\n'", "    # Original CUDA consumers require no fixture mode definition.")
replace("    for name,relative in fixtures.items():", "    body+='find_package(CUDAToolkit REQUIRED)\\n'\n    for name,relative in fixtures.items():")
replace("    else:args+=['-DHYLE_STATIC=OFF','-DHYLE_SANITIZER=off','-UCMAKE_PROJECT_INCLUDE']", "    else:args+=['-DHYLE_STATIC='+('ON' if 'HYLE_STATIC:BOOL=ON\\n' in (producer/'CMakeCache.txt').read_text() else 'OFF'),'-DHYLE_SANITIZER=off','-DCMAKE_PROJECT_INCLUDE='+str(profile)]\n    args+=['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3']")
replace("    assert len(actual)==5,len(actual)", "    assert len(actual)==len(fixtures)+2,len(actual)")
replace("deps=subprocess.check_output(['otool','-L',str(binary)],text=True)", "deps=subprocess.check_output(['ldd',str(binary)],env=env,text=True);assert 'not found' not in deps,deps")
target=root/'.scratch/inference-gaps/g09_wsl_sdk.py';target.write_text(body,encoding='utf8',newline='\n');compile(body,str(target),'exec');print(target)
