from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
assert sys.platform=='linux'
canonical=Path('/mnt/c/public/project-hyle/hyle');base=Path('/root/hyle-scratch/compute-unified')
out=canonical/'.scratch/inference-gaps/g09-sdk-wsl';out.mkdir(exist_ok=False)
windows=json.loads((canonical/'.scratch/inference-gaps/g09-sdk-windows/matrix-final.json').read_text())
assert windows['state']=='WINDOWS_SIX_DELIVERIES_PASS'
started=time.monotonic();r={'state':'RUNNING','pid':os.getpid(),'serial':True,'cases':[],'scope':'Remaining Linux CUDA source/static/shared consumer delivery only; not native Linux P1.'}
for mode in ['static','shared','source']:
 r['stage']=mode;(out/'matrix.json').write_text(json.dumps(r,indent=2)+'\n');print('wsl-cuda',mode,'START',flush=True)
 args=[sys.executable,str(canonical/'.scratch/inference-gaps/g09_wsl_sdk.py'),'cuda',mode]
 with (out/(mode+'-matrix.log')).open('wb') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 file=base/f'g09-sdk/cuda-{mode}-1/evidence/result.json';v=json.loads(file.read_text()) if file.is_file() else {}
 r['cases'].append({'mode':mode,'exit_code':p.returncode,'state':v.get('state'),'result':str(file),'actual_cumulative_seconds':v.get('elapsed_seconds')})
 r['elapsed_seconds']=time.monotonic()-started;(out/'matrix.json').write_text(json.dumps(r,indent=2)+'\n');print(mode,p.returncode,v.get('state'),flush=True)
r['state']='THREE_WSL_CUDA_DELIVERIES_PASS' if all(x['state'] in ['SOURCE_PUBLIC_CONSUMERS_HEADERS_PASS','RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS'] and x['exit_code']==0 for x in r['cases']) else 'FINITE_FAILURES_RETAINED_WITH_ALL_CONFIGURATIONS_OBSERVED'
r['cost_reset']=False;(out/'matrix.json').write_text(json.dumps(r,indent=2)+'\n')
archive=out/'raw.zip';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
 for row in r['cases']:
  folder=Path(row['result']).parent;v=json.loads((folder/'result.json').read_text())
  for item in v.get('binaries',[]):assert sha(Path(item['path']))==item['sha256']
  for p in sorted(folder.rglob('*')):
   if p.is_file() and 'bin' not in p.relative_to(folder).parts:z.write(p,'cuda-'+row['mode']+'/'+p.relative_to(folder).as_posix())
  for key,value in v.items():
   if key.endswith('_native_reuse'):
    reuse=Path(value['path'])
    for p in sorted(reuse.iterdir()):
     if p.is_file():z.write(p,'cuda-'+row['mode']+'/native-reuse/'+p.name)
 z.write(out/'matrix.json','matrix.json')
 for p in sorted(out.glob('*-matrix.log')):z.write(p,p.name)
 for name in ['g09_wsl_sdk.py','g09_wsl_sdk_matrix.py','g09_prepare_wsl_sdk.py']:z.write(canonical/'.scratch/inference-gaps'/name,'runner/'+name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'state':r['state'],'raw':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size}),flush=True)
