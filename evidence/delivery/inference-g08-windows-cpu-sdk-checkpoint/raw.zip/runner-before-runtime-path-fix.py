from pathlib import Path
import ctypes, hashlib, json, os, re, subprocess, sys, time

root=Path(__file__).resolve().parents[2]
route,mode,label=sys.argv[1:4]
assert route in ['cpu','cuda','vulkan'] and mode in ['shared','static','source']
resume='--resume-build' in sys.argv
tag=f'{route}-{mode}-{label}'
out=root/'.scratch/inference-gaps/g08-sdk-windows'/tag
folder=Path('C:/h7/g08-sdk')/tag
family=Path('C:/h7')/('w-cpu-cuda' if route=='cpu' and mode=='source' else 'w-cpu' if route=='cpu' else 'w-cpu-'+route)/'selected-graph'
if mode=='source':producer=family/'source-build'
elif route=='cpu':producer=root/'.scratch/build-compute-v2-dev'
else:producer=Path('C:/h7')/('w-'+route)/'selected-graph'/(mode+'-sdk-build')
if not resume:
    out.mkdir(parents=True,exist_ok=False);folder.mkdir(parents=True,exist_ok=False)
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf-8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env['VSLANG']='1033';env['HYLE_VULKAN_VALIDATION']='0'
cuda=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
vulkan=Path('C:/public/tools/hyle-vulkan/1.4.357.0')
if route=='cuda':env['PATH']=str(cuda/'bin')+';'+env['PATH']
if route=='vulkan':env['VULKAN_SDK']=str(vulkan);env['PATH']=str(vulkan/'Bin')+';'+env['PATH']
ctypes.windll.kernel32.SetErrorMode(0x0001|0x0002|0x8000)
jobs=2 if route=='cuda' else 4
started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(state='SETUP',pid=os.getpid(),route=route,mode=mode,producer=str(producer),max_jobs=jobs,stages=[],
       candidate='5103c13d8ed119b06aa64e799f9768aea45ab913',
       scope='G08 Windows public numerical consumers, affected Mem regression cases, independent headers and source or relocated shipping SDK. No P1/full-engine claim.')
if resume:
    r=json.loads((out/'result.json').read_text());assert r['state']=='SETUP_FAIL'
    r.setdefault('retained_setup_failures',[]).append(dict(error=r.pop('error'),elapsed_seconds=r['elapsed_seconds']))
    started=time.monotonic()-r['elapsed_seconds'];r['pid']=os.getpid()

def save():
    r['elapsed_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')

def run(stage,args):
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('wb') as stream:
        flags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS
        p=subprocess.Popen(args,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=flags)
        get=ctypes.windll.kernel32.GetProcessAffinityMask
        get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        set_mask=ctypes.windll.kernel32.SetProcessAffinityMask
        set_mask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle))
        if not get(handle,ctypes.byref(available),ctypes.byref(system)):
            p.terminate();p.wait();raise OSError('Cannot read process affinity')
        bits=[1<<i for i in range(64) if available.value&(1<<i)][:4]
        if not set_mask(handle,sum(bits)):
            p.terminate();p.wait();raise OSError('Cannot bound process affinity')
        r['resource_profile']=dict(priority='BELOW_NORMAL',logical_cpus=len(bits),affinity_mask=hex(sum(bits)),jobs=jobs,cuda_compile_pool=1 if route=='cuda' else None)
        r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(tag,stage,p.pid,flush=True);code=p.wait()
    r['stages'].append(dict(stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)))
    r.pop('child_pid',None);save()
    if code:
        r['state']='FAIL';save();print(log.read_text(encoding='utf-8',errors='replace')[-6500:],flush=True);raise SystemExit(code)

def build_with_preflight(stage,build,targets):
    run(stage+'-manifest',['ninja','-C',str(build),'build.ninja'])
    preview=out/(stage+'-preview.ninja');preview.write_bytes((build/'build.ninja').read_bytes())
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf-8',errors='replace')
    (out/(stage+'-dry-run.log')).write_text(dry,encoding='utf-8')
    cuda_edges=[x for x in dry.splitlines() if 'Building CUDA object' in x]
    r[stage+'_preflight']=dict(edges=len(dry.splitlines()),cuda_edges=cuda_edges);save()
    assert 'Re-running CMake' not in dry
    assert len(dry.splitlines())<1600
    if route!='cuda':assert not cuda_edges
    else:
        assert len(cuda_edges)<=4 and all(any(owner in x for owner in ['compute_provider_cuda','compute_backend_cuda','compute_provider_torch_cuda','compute_provider_flashinfer']) for x in cuda_edges),cuda_edges[:10]
    run(stage,['ninja','-C',str(build),'-f',str(preview),'-j',str(jobs),*targets])

try:
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    if resume:assert head==r['source_snapshot']
    else:r['source_snapshot']=head
    registry=json.loads((root/'docs/implementation/module-status.json').read_text())
    owners=[x for x in registry['modules'] if x.get('record','').endswith('inference-g08-output-selection.md')]
    assert len(owners)==8 and all(x['state']=='CANDIDATE' and x['candidate']==r['candidate'] for x in owners)
    paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
    inputs=[dict(path=x,sha256=sha(root/x)) for x in paths if (root/x).is_file() and not x.startswith('evidence/')]
    manifest=out/'input-manifest.json'
    if resume:assert json.loads(manifest.read_text())==inputs
    else:manifest.write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
    r['identity']=dict(host=env.get('COMPUTERNAME'),compiler=env.get('VCTOOLSVERSION'),os=subprocess.check_output(['cmd','/d','/c','ver'],text=True).strip())
    if route!='cpu':r['identity']['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],env=env,text=True).strip()
    if route=='cuda':r['identity']['cuda']=subprocess.check_output([str(cuda/'bin/nvcc.exe'),'--version'],env=env,text=True).strip()
    profile=root/'.scratch/inference-gaps/g08_shipping_cuda_profile.cmake'
    configure=['cmake','-S',root.as_posix(),'-B',producer.as_posix(),'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES='+('cpu' if route=='cpu' else 'cpu;'+route),'-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF')]
    configure+=['-DCMAKE_PROJECT_INCLUDE='+profile.as_posix()] if route=='cuda' else ['-UCMAKE_PROJECT_INCLUDE']
    if mode!='source':
        prefix=folder/'relocated';consumer=folder/'consumer'
        if not resume:
            run('producer-configure',configure)
            commands=json.loads(subprocess.check_output(['ninja','-C',str(producer),'-t','compdb'],env=env,text=True))
            shipping=[x for x in commands if x['file'].replace('\\','/').startswith(root.as_posix()+'/src/')]
            assert shipping and all('HYLE_TESTING' not in x['command'] and '-fsanitize=' not in x['command'] for x in shipping)
            (out/'shipping-commands.json').write_text(json.dumps(shipping,indent=2)+'\n')
            targets=['hyle_compute','hyle_compute_ops','hyle_compute_batch','hyle_compute_state','hyle_compute_stream','hyle_graph','hyle_graph_batch','hyle_compute_route_cpu','hyle_graph_route_cpu']
            if route!='cpu':targets += [f'hyle_compute_route_{route}',f'hyle_graph_route_{route}',f'hyle_graph_route_cpu_{route}']
            build_with_preflight('producer-build',producer,targets)
            staging=folder/'staging'
            assert staging.resolve().parent==folder.resolve() and prefix.resolve().parent==folder.resolve()
            run('install',['cmake','--install',str(producer),'--prefix',str(staging)])
            staging.rename(prefix);consumer.mkdir()
        else:assert prefix.is_dir() and consumer.is_dir() and not (folder/'staging').exists()
    else:
        prefix=None;consumer=family/'source-parent';consumer.mkdir(parents=True,exist_ok=True)
        if not resume and (consumer/'CMakeLists.txt').is_file():(out/'original-source-parent.cmake').write_bytes((consumer/'CMakeLists.txt').read_bytes())
    copied=set()
    def copy(relative):
        if relative in copied:return
        p=root/relative;assert p.resolve().is_relative_to((root/'tests').resolve()),relative
        data=p.read_bytes();dst=consumer/relative;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);copied.add(relative)
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode('utf-8'),re.M):
            if include.startswith('hyle/'):continue
            path=(p.parent/include).resolve();assert path.is_relative_to((root/'tests').resolve())
            copy(path.relative_to(root).as_posix())
    fixtures={'cpu_direct':('tests/compute_route_cpu/sampling_consumer.cc',False),'cpu_graph':('tests/compute_route_cpu/sampling_consumer.cc',True)}
    if route!='cpu':fixtures.update(native_direct=(f'tests/compute_route_{route}/sampling_consumer.cc',False),native_graph=(f'tests/compute_route_{route}/sampling_consumer.cc',True),joint=(f'tests/graph_route_cpu_{route}/sampling_consumer.cc',False))
    for path,_ in fixtures.values():copy(path)
    allocator=(root/'tests/mem/allocator_test.cc').read_text();buffer=(root/'tests/mem/buffer_resource_test.cc').read_text()
    public_mem='#include <gtest/gtest.h>\n#include <algorithm>\n#include <array>\n#include <cstdint>\n#include <cstring>\n#include <span>\n#include <thread>\n#include <utility>\n#include <hyle/mem/allocator.h>\n#include <hyle/mem/system_inline.h>\n#include <hyle/mem/buffer.h>\nusing namespace hyle::mem;\n'
    public_mem+=allocator[allocator.index('TEST(SystemAllocator, AlignedRequestedSizeCrossingSmallPageKeepsActualPageIdentity)'):]
    public_mem+=buffer[buffer.index('TEST(BufferResource, OverAlignedSmallRequestFullWriteReadMoveAndRelease)'):]
    assert public_mem.count('TEST(')==3 and 'system_internal' not in public_mem
    (consumer/'mem_public.cc').write_text(public_mem);fixtures['mem']=('mem_public.cc',False)
    headers=['compute/sampling_ops.h','compute/operation.h','compute/prepared_operation.h','compute/cpu.h','graph/cpu.h','mem/allocator.h','mem/system_inline.h','mem/buffer.h']
    if route!='cpu':headers += [f'compute/{route}.h',f'graph/{route}.h',f'graph/cpu_{route}.h']
    if route=='cuda':headers += ['compute/backends/cuda.h','compute/providers/cuda.h']
    for i,name in enumerate(headers):
        if prefix:assert sha(prefix/'include/hyle'/name)==sha(root/'include/hyle'/name)
        (consumer/f'header-{i}.cc').write_text('#include <hyle/'+name+'>\n')
    body='cmake_minimum_required(VERSION 3.25)\nproject(g08_public_delivery LANGUAGES CXX)\n'
    if mode=='source':body+='set(HYLE_COMPONENTS "compute;graph" CACHE STRING "" FORCE)\nset(HYLE_COMPUTE_ROUTES "'+('cpu' if route=='cpu' else 'cpu;'+route)+'" CACHE STRING "" FORCE)\nset(HYLE_BUILD_TESTS OFF CACHE BOOL "" FORCE)\nset(HYLE_BUILD_BENCH OFF CACHE BOOL "" FORCE)\nset(HYLE_INSTALL OFF CACHE BOOL "" FORCE)\nset(HYLE_TEST_INSTRUMENTATION OFF CACHE BOOL "" FORCE)\nadd_subdirectory("'+root.as_posix()+'" hyle)\n'
    else:body+='find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\n'
    gtest=Path('C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6')
    body+='set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\nadd_subdirectory("'+gtest.as_posix()+'" g08-gtest EXCLUDE_FROM_ALL)\n'
    for name,(path,graph) in fixtures.items():
        body+=f'add_executable({name} "{path}")\ntarget_compile_features({name} PRIVATE cxx_std_23)\ntarget_link_libraries({name} PRIVATE hyle::compute hyle::graph'+(' GTest::gtest_main' if name=='mem' else '')+')\nhyle_stage_runtime('+name+')\n'
        if graph:body+='target_compile_definitions('+name+' PRIVATE HYLE_G08_GRAPH=1)\n'
    body+='add_library(headers OBJECT '+' '.join(f'header-{i}.cc' for i in range(len(headers)))+')\ntarget_compile_features(headers PRIVATE cxx_std_23)\ntarget_link_libraries(headers PRIVATE hyle::compute hyle::graph)\n'
    (consumer/'CMakeLists.txt').write_text(body);(out/'consumer.cmake').write_text(body)
    build=producer if mode=='source' else folder/'consumer-build'
    args=['cmake','-S',consumer.as_posix(),'-B',build.as_posix(),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    if prefix:args+=['-DCMAKE_PREFIX_PATH='+prefix.as_posix()]
    if mode=='source':args+=['-DHYLE_STATIC=OFF']+(['-DCMAKE_PROJECT_INCLUDE='+profile.as_posix()] if route=='cuda' else ['-UCMAKE_PROJECT_INCLUDE'])
    if route=='cuda':args+=['-DCUDAToolkit_ROOT='+cuda.as_posix()]
    run('consumer-configure',args)
    build_with_preflight('consumer-build',build,[*fixtures,'headers'])
    actual=[x for x in json.loads((build/'compile_commands.json').read_text()) if x['file'].replace('\\','/').startswith(consumer.as_posix()+'/')]
    assert len(actual)==len(fixtures)+len(headers),(len(actual),len(fixtures)+len(headers))
    for row in actual:
        command=row['command'].replace('\\','/')
        if prefix:assert root.as_posix() not in command and producer.as_posix() not in command and (prefix/'include').as_posix() in command,command
        else:assert (root/'include').as_posix() in command and (root/'src').as_posix() not in command,command
    (out/'consumer-commands.json').write_text(json.dumps(actual,indent=2)+'\n')
    # Stage_runtime must copy every Hyle DLL from this installation, never a prior producer.
    staged=[]
    for dll in build.glob('hyle_*.dll'):
        if prefix:original=prefix/'bin'/dll.name;assert original.is_file(),str(original)
        else:
            matches=list((build/'hyle').rglob(dll.name));matches=[x for x in matches if x.is_file()]
            assert len(matches)==1,(dll,matches);original=matches[0]
        assert sha(dll)==sha(original),str(dll)
        staged.append(dict(staged=str(dll),original=str(original),sha256=sha(dll)))
    if mode!='static':assert staged
    r['staged_runtime']=staged
    # Isolate runtime PATH from product/producer locations; staged runtime remains beside EXEs.
    clean_path=[]
    for part in env['PATH'].split(';'):
        if not part:continue
        resolved=Path(part).resolve()
        if resolved.is_relative_to(root.resolve()) or resolved.is_relative_to(producer.resolve()):continue
        clean_path.append(part)
    env['PATH']=';'.join(clean_path)
    for name in fixtures:
        binary=build/(name+'.exe');run(name,[str(binary)])
        r.setdefault('consumers',[]).append(dict(name=name,path=str(binary),sha256=sha(binary)))
        if name=='mem':assert '[  PASSED  ] 3 tests.' in (out/(name+'.log')).read_text(encoding='utf-8')
    r['independent_headers']=[dict(path=x,sha256=sha((prefix/'include/hyle' if prefix else root/'include/hyle')/x)) for x in headers]
    if prefix:
        licenses=[p for p in (prefix/'share/licenses/Hyle').glob('*') if p.is_file() and 'random123' in p.name.lower()]
        assert len(licenses)>=2
        r['random123_license']=[dict(path=str(p),sha256=sha(p)) for p in licenses]
    assert all(sha(root/x['path'])==x['sha256'] for x in inputs)
    r['state']='PUBLIC_SOURCE_CONSUMERS_HEADERS_RUNTIME_PASS' if mode=='source' else 'RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_RUNTIME_PASS'
    save();print(tag,r['state'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
