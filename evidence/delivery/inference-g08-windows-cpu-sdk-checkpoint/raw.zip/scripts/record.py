from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2]
folder=root/'.scratch/inference-gaps/g08-sdk-windows/cpu-shared-1'
result=json.loads((folder/'result.json').read_text())
assert result['state']=='RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_RUNTIME_PASS'
assert len(result['consumers'])==3 and len(result['independent_headers'])==8
assert len(result['retained_setup_failures'])==2
for x in result['consumers']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']
out=root/'evidence/delivery/inference-g08-windows-cpu-sdk-checkpoint';out.mkdir(exist_ok=False)
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in folder.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(folder))
    z.write(Path(__file__),'scripts/record.py')
receipt=dict(schema='hyle.inference-g08-windows-cpu-sdk-checkpoint/v1',verdict=result['state'],result=result,
    raw=dict(path='raw.zip',sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),bytes=(out/'raw.zip').stat().st_size),
    retained_failures='Private runner first assumed all Hyle runtime DLLs were installed under bin; actual existing ggml CPU variant DLL lives under lib. Corrected unique matching against the actual relocated installation. First resume then refused the new untracked evidence checkpoint; narrowed the clean-source assertion to exclude only evidence, retaining source manifest identity. Both setup failures/time and original logs retained; producer was not rebuilt or reinstalled.',
    scope='Actual Windows/MSVC CPU-only relocated shared SDK. Public CPU Direct/Graph full numerical/quality/full-vocabulary and three existing public Mem regressions PASS. Eight independent public headers, installed Random123 license/NOTICE, installed-only compile includes and exact staged DLL hashes under a runtime PATH excluding canonical/producer paths. Windows runtime checks staged DLL identity and isolated search paths; no claim of actual module tracing. No Windows static/source, CUDA/Vulkan SDK or P1 verdict.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=receipt['verdict'],receipt=str(out/'receipt.json'))))
