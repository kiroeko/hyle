from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2]
out=root/'evidence/delivery/inference-g08-windows-cpu-sdk-checkpoint'
assert (out/'receipt.json').is_file() and not (out/'remaining.json').exists()
cases=[]
with zipfile.ZipFile(out/'remaining-raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for mode in ['static','source']:
        folder=root/f'.scratch/inference-gaps/g08-sdk-windows/cpu-{mode}-1'
        result=json.loads((folder/'result.json').read_text())
        assert result['state'] in ['PUBLIC_SOURCE_CONSUMERS_HEADERS_RUNTIME_PASS','RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_RUNTIME_PASS']
        assert len(result['consumers'])==3 and len(result['independent_headers'])==8
        for x in result['consumers']:
            p=Path(x['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
        cases.append(result)
        for p in folder.rglob('*'):
            if p.is_file():z.write(p,str(Path(mode)/p.relative_to(folder)))
    z.write(Path(__file__),'scripts/record-remaining.py')
r=dict(schema='hyle.inference-g08-windows-cpu-three-deliveries/v1',
    verdict='WINDOWS_CPU_SOURCE_STATIC_SHARED_PUBLIC_CONSUMERS_HEADERS_RUNTIME_LICENSE_PASS',
    candidate='5103c13d8ed119b06aa64e799f9768aea45ab913',source_snapshot='d5b9490a5958593915d69750cb3a4470866a7176',
    earlier_shared_receipt='receipt.json',cases=cases,
    raw=dict(path='remaining-raw.zip',sha256=hashlib.sha256((out/'remaining-raw.zip').read_bytes()).hexdigest(),bytes=(out/'remaining-raw.zip').stat().st_size),
    retained_source_failure='Source embedding completed actual280 steps, then the private dependency inspector could not find bare dumpbin via the parent process PATH. Resolved it from the actual cached MSVC compiler directory. Retained the failure and385.765 seconds; same-tree resume regenerated/recompiled59 additional steps before CPU Direct/Graph and three Mem regressions passed. No product change or source snapshot reset.',
    scope='CPU-only Windows/MSVC source embedding plus relocated static/shared. Each config public CPU Direct/Graph numerical/quality/full-vocabulary consumers, three existing public Mem regressions and8 independent public headers. SDK licenses installed and compiled include paths isolated. Source used a reused, disposable former CPU+CUDA parent with routes explicitly CPU only; its preflight had no CUDA edges. Source runtime walks PE Hyle imports and compares staged DLL hashes to the producer; this is not actual loaded-module tracing. No other platform SDK or P1 acceptance.')
(out/'remaining.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=r['verdict'],new_configs=len(cases))))
