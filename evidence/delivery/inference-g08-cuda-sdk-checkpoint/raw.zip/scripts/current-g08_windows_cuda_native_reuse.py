from pathlib import Path
import hashlib,json,subprocess,sys,time
root=Path(__file__).resolve().parents[2];mode,label=sys.argv[1:3]
assert mode in ['shared','static','source']
build=Path('C:/h7/w-cpu-cuda/selected-graph/source-build') if mode=='source' else Path('C:/h7/w-cuda/selected-graph')/(mode+'-sdk-build')
out=root/'.scratch/inference-gaps'/f'g08-windows-{mode}-native-reuse-{label}';out.mkdir(exist_ok=False)
started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(state='SETUP',build=str(build),stages=[])
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
try:
    commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
    unary=next(x for x in commands if x['file'].replace('\\','/').endswith('/src/ggml-cuda/unary.cu'))
    current=Path(unary['file'].replace('\\','/').split('/src/ggml-cuda/')[0])
    precise=current.parent/'CMakeFiles/ggml-cuda-precise-unary.dir'
    old_objects=[p for p in precise.rglob('unary.cu.obj') if current.name not in p.parts]
    assert len(old_objects)==1,[str(p) for p in old_objects]
    old_name=old_objects[0].relative_to(precise).parts[0];old=current.parent/old_name;assert old.is_dir()
    source=(build/'build.ninja').read_text();lines=source.splitlines(keepends=True);result=[];mapped=[];i=0
    old_unary=new_unary=None
    while i<len(lines):
        line=lines[i]
        if line.startswith('build ') and '.cu.obj:' in line and ('\\CMakeFiles\\ggml-cuda.dir\\' in line or '\\CMakeFiles\\ggml-cuda-precise-unary.dir\\' in line):
            block=[line];i+=1
            while i<len(lines) and lines[i].startswith('  '):block.append(lines[i]);i+=1
            before=''.join(block);after=before.replace(current.name,old.name)
            before_output=before.splitlines()[0][6:].split(': ',1)[0];after_output=after.splitlines()[0][6:].split(': ',1)[0]
            assert (build/after_output).is_file(),after_output
            if before_output!=after_output:new_unary,old_unary=before_output,after_output
            mapped.append(dict(output=after_output,before=before,after=after));result.append(after)
        else:result.append(line);i+=1
    assert len(mapped)==146 and old_unary and new_unary
    preview=out/'reuse.ninja';preview.write_text(''.join(result).replace(new_unary,old_unary))
    objects=[x['output'] for x in mapped]
    deps=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-t','deps',*objects],text=True,encoding='utf-8',errors='replace')
    (out/'original-object-dependencies.log').write_text(deps,encoding='utf-8')
    assert 'deps not found' not in deps and 'STALE' not in deps
    derived=set();canonical=set()
    for line in deps.splitlines():
        if not line.startswith('    '):continue
        p=Path(line.strip())
        if not p.is_absolute():p=build/p
        p=p.resolve()
        if p.is_relative_to(old.resolve()):derived.add(p.relative_to(old.resolve()).as_posix())
        elif p.is_relative_to(root):canonical.add(p.relative_to(root).as_posix())
    for row in commands:
        p=Path(row['file'])
        if p.suffix=='.cu' and p.is_relative_to(current):derived.add(p.relative_to(current).as_posix())
    assert len(derived)>=200 and canonical,(len(derived),canonical)
    expected=json.loads((root/'.scratch/inference-gaps/g04-g05/cuda-host-san/ggml-cuda-reuse-proof.json').read_text())['modes']['asan']
    canonical_proof=dict(expected['canonical_dependencies'])
    checked=[];differences=[]
    for name in sorted(derived):
        a=old/name;b=current/name;assert a.is_file() and b.is_file(),name
        before=sha(a);after=sha(b);checked.append(dict(path=name,old_sha256=before,current_sha256=after))
        if before!=after:differences.append(name)
    for name in sorted(canonical):
        assert name in canonical_proof and sha(root/name)==canonical_proof[name],name
    r.update(old_derived_source=str(old),current_derived_source=str(current),native_objects=146,
             actual_derived_dependencies=len(derived),actual_canonical_dependencies=len(canonical),differences=differences)
    (out/'input-comparison.json').write_text(json.dumps(checked,indent=2)+'\n')
    (out/'mapped-edges.json').write_text(json.dumps(mapped,indent=2)+'\n')
    if differences:
        r['state']='NATIVE_INPUTS_DIFFER_NO_REUSE_AUTHORIZED';save();print(json.dumps(r));raise SystemExit(2)
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*objects],text=True,encoding='utf-8',errors='replace')
    (out/'original-object-check.log').write_text(dry,encoding='utf-8')
    assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry,dry[:1800]
    r['objects']=[dict(path=x,sha256=sha(build/x)) for x in objects]
    r.update(state='PASS_146_WINDOWS_NATIVE_OBJECTS_INPUTS_AND_ORIGINAL_NINJA_COMMANDS_FRESH',
             original_manifest_sha256=sha(build/'build.ninja'),reuse_manifest_sha256=sha(preview),
             scope='Private same-tree manifest path mapping only. All actual recorded Windows native derived dependencies are byte-compared, canonical shared inputs match fixed qualified proof, and Ninja checks original command identity/dependency freshness. Current product/C++/CPU native edges remain current. No object timestamp/content mutation or product source copyback.')
    save();print(json.dumps({k:v for k,v in r.items() if k!='objects'}))
except BaseException as error:
    if not isinstance(error,SystemExit):r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
