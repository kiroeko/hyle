from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[2]
out=root/'evidence/delivery/inference-g08-cuda-sdk-checkpoint'
if out.exists():
    assert not (out/'receipt.json').exists() and (out/'raw.zip').exists()
    assert not (out/'raw-first-seal-failure.zip').exists()
    (out/'raw.zip').rename(out/'raw-first-seal-failure.zip')
else:out.mkdir()
folders=[('windows-shared',root/'.scratch/inference-gaps/g08-sdk-windows/cuda-shared-1'),
         ('wsl-static',root/'.scratch/inference-gaps/g08-sdk/cuda-static-1')]
cases=[]
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,folder in folders:
        r=json.loads((folder/'result.json').read_text())
        assert r['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_RUNTIME_PASS','RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS']
        assert len(r['consumers'])==6 and len(r['independent_headers'])==13
        for x in r['consumers']:
            binary=Path('//wsl.localhost/Ubuntu-24.04'+x['path']) if name.startswith('wsl') else Path(x['path'])
            assert hashlib.sha256(binary.read_bytes()).hexdigest()==x['sha256']
        cases.append(dict(platform_mode=name,result=r))
        for p in folder.rglob('*'):
            if p.is_file():z.write(p,str(Path(name)/p.relative_to(folder)))
    proofs=[root/'.scratch/inference-gaps/g08-windows-shared-native-reuse-1',root/'.scratch/inference-gaps/g08-windows-shared-native-reuse-2',
            root/'.scratch/inference-gaps/g04-g05/ce28-static-native-reuse-g08-sdk-1']
    for folder in proofs:
        assert folder.is_dir()
        for p in folder.rglob('*'):
            if p.is_file():z.write(p,str(Path('native-proofs')/folder.name/p.relative_to(folder)))
    for name in ['g08_sdk.py','g08_sdk_windows.py','g08_windows_cuda_native_reuse.py','g08_shipping_cuda_profile.cmake']:
        z.write(root/'.scratch/inference-gaps'/name,'scripts/current-'+name)
    z.write(Path(__file__),'scripts/record.py')
    if (out/'raw-first-seal-failure.zip').exists():z.write(out/'raw-first-seal-failure.zip','retained-first-seal/raw.zip')
receipt=dict(schema='hyle.inference-g08-cuda-sdk-checkpoint/v1',
    verdict='WINDOWS_SHARED_AND_WSL_STATIC_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS',
    candidate='5103c13d8ed119b06aa64e799f9768aea45ab913',source_snapshot='d5b9490a5958593915d69750cb3a4470866a7176',cases=cases,
    raw=dict(path='raw.zip',sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),bytes=(out/'raw.zip').stat().st_size),
    retained_windows_failures=['Private resource profile initially tried PRIVATE options on the unavailable FlashInfer INTERFACE stub; skip only absent interface targets.',
        'Original native path change scheduled146 unchanged ggml CUDA objects plus6 real product CUDA dependencies. Initial guard failure retained; actual Windows242 derived and5 canonical dependency inputs compared, original Ninja commands/freshness checked and old146 objects reused without touching contents/timestamps. All current C++/CPU/native host edges retained.',
        'Private profile SET of source COMPILE_OPTIONS wiped the products existing MSVC conforming-preprocessor option on two TUs. Original CCCL compilation failure retained; changed only scratch profile to APPEND and reconfigured the same producer. Required original flags restored, native-object proof refreshed; all six public consumers then passed.'],
    runtime='Windows PE import closure plus exact staged Hyle DLL hashes match relocated prefix; runtime PATH excludes canonical/producer paths. WSL actual ldd has no missing/producer Hyle dependencies. External validated LibTorch CPU/CUDA SDK/cache remains required by the existing distribution contract; this is not a hermetic-runtime or module-tracing claim.',
    scope='Two of the six CUDA delivery configurations, each with public CPU/native Direct/Graph numerical/quality/full-vocabulary consumers, joint65-step/two-slot consumer, three public Mem regressions and13 independently compiled headers. Both actual relocated SDKs install Random123 license and NOTICE. No CUDA source/static/shared completion for either full OS matrix yet, no P1 or full-engine claim.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=receipt['verdict'],configs=len(cases),archive_bytes=receipt['raw']['bytes'])))
