cmake_minimum_required(VERSION 3.25)
project(g08_public_delivery LANGUAGES CXX)
set(HYLE_COMPONENTS "compute;graph" CACHE STRING "" FORCE)
set(HYLE_COMPUTE_ROUTES "cpu;cuda" CACHE STRING "" FORCE)
set(HYLE_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(HYLE_BUILD_BENCH OFF CACHE BOOL "" FORCE)
set(HYLE_INSTALL OFF CACHE BOOL "" FORCE)
set(HYLE_TEST_INSTRUMENTATION OFF CACHE BOOL "" FORCE)
add_subdirectory("C:/public/project-hyle/hyle" hyle)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory("C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6" g08-gtest EXCLUDE_FROM_ALL)
add_executable(cpu_direct "tests/compute_route_cpu/sampling_consumer.cc")
target_compile_features(cpu_direct PRIVATE cxx_std_23)
target_link_libraries(cpu_direct PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime(cpu_direct)
add_executable(cpu_graph "tests/compute_route_cpu/sampling_consumer.cc")
target_compile_features(cpu_graph PRIVATE cxx_std_23)
target_link_libraries(cpu_graph PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime(cpu_graph)
target_compile_definitions(cpu_graph PRIVATE HYLE_G08_GRAPH=1)
add_executable(native_direct "tests/compute_route_cuda/sampling_consumer.cc")
target_compile_features(native_direct PRIVATE cxx_std_23)
target_link_libraries(native_direct PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime(native_direct)
add_executable(native_graph "tests/compute_route_cuda/sampling_consumer.cc")
target_compile_features(native_graph PRIVATE cxx_std_23)
target_link_libraries(native_graph PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime(native_graph)
target_compile_definitions(native_graph PRIVATE HYLE_G08_GRAPH=1)
add_executable(joint "tests/graph_route_cpu_cuda/sampling_consumer.cc")
target_compile_features(joint PRIVATE cxx_std_23)
target_link_libraries(joint PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime(joint)
add_executable(mem "mem_public.cc")
target_compile_features(mem PRIVATE cxx_std_23)
target_link_libraries(mem PRIVATE hyle::compute hyle::graph GTest::gtest_main)
hyle_stage_runtime(mem)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc header-3.cc header-4.cc header-5.cc header-6.cc header-7.cc header-8.cc header-9.cc header-10.cc header-11.cc header-12.cc)
target_compile_features(headers PRIVATE cxx_std_23)
target_link_libraries(headers PRIVATE hyle::compute hyle::graph)

# g09_cold_submission: original Graph core/direct custom consumer, shipping interfaces.
add_executable(hyle_graph_test
  "C:/public/project-hyle/hyle/tests/graph/graph_test.cc"
  "C:/public/project-hyle/hyle/tests/graph/lease_submission_test.cc"
  "C:/public/project-hyle/hyle/tests/graph/native_variants_test.cc"
  "C:/public/project-hyle/hyle/tests/graph/effect_preflight_test.cc"
  "C:/public/project-hyle/hyle/tests/graph/custom_kernel_test.cc"
)
target_compile_features(hyle_graph_test PRIVATE cxx_std_23)
target_link_libraries(hyle_graph_test PRIVATE hyle_graph hyle_compute_backend_cpu GTest::gtest_main)
hyle_stage_runtime(hyle_graph_test)

target_sources(hyle_graph_test PRIVATE "C:/public/project-hyle/hyle/tests/graph/joint_pipeline_test.cc")

# G09 public joint consumer; reuse all qualified dependencies.
add_executable(hyle_cpu_cuda_pipeline "C:/public/project-hyle/hyle/tests/graph/cpu_cuda_pipeline.cc")
target_compile_features(hyle_cpu_cuda_pipeline PRIVATE cxx_std_23)
target_link_libraries(hyle_cpu_cuda_pipeline PRIVATE hyle::graph)
hyle_stage_runtime(hyle_cpu_cuda_pipeline)
add_executable(hyle_cpu_cuda_contracts "C:/public/project-hyle/hyle/tests/graph/cpu_cuda_contracts.cc")
target_compile_features(hyle_cpu_cuda_contracts PRIVATE cxx_std_23)
target_link_libraries(hyle_cpu_cuda_contracts PRIVATE hyle::graph)
hyle_stage_runtime(hyle_cpu_cuda_contracts)
find_package(CUDAToolkit REQUIRED)
if(TARGET CUDA::cupti)
target_compile_definitions(hyle_cpu_cuda_pipeline PRIVATE HYLE_G09_HAS_CUPTI=1)
target_link_libraries(hyle_cpu_cuda_pipeline PRIVATE CUDA::cupti)
endif()

# G09 actual direct Graph consumers after private cursor extraction.
add_executable(hyle_graph_executable_test
  "C:/public/project-hyle/hyle/tests/graph/executable_test.cc"
  "C:/public/project-hyle/hyle/tests/graph/custom_kernel_test.cc"
  "C:/public/project-hyle/hyle/tests/graph/region_provider_test.cc"
  "C:/public/project-hyle/hyle/tests/graph/cuda_graph_test.cc"
)
target_compile_features(hyle_graph_executable_test PRIVATE cxx_std_23)
target_link_libraries(hyle_graph_executable_test PRIVATE hyle::graph GTest::gtest_main)
target_include_directories(hyle_graph_executable_test PRIVATE "C:/public/project-hyle/hyle/src/compute")
hyle_stage_runtime(hyle_graph_executable_test)
add_executable(hyle_graph_native_retirement_test
  "C:/public/project-hyle/hyle/tests/graph/aggregate_native_retirement_test.cc"
)
target_compile_features(hyle_graph_native_retirement_test PRIVATE cxx_std_23)
target_link_libraries(hyle_graph_native_retirement_test PRIVATE hyle::graph GTest::gtest_main)
target_include_directories(hyle_graph_native_retirement_test PRIVATE "C:/public/project-hyle/hyle/src/graph")
hyle_stage_runtime(hyle_graph_native_retirement_test)
