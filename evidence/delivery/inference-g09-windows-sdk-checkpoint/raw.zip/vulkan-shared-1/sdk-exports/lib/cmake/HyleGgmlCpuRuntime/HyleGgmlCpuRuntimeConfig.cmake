
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was HyleGgmlCpuRuntimeConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(_hyle_cpu_program "${PACKAGE_PREFIX_DIR}/lib/hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965.dll")
if(NOT EXISTS "${_hyle_cpu_program}")
  message(FATAL_ERROR "Hyle CPU SDK is missing its original optimized ggml program: ${_hyle_cpu_program}")
endif()
# find_dependency runs before HyleTargets and the generic staging helper.
foreach(_owner IN ITEMS hyle_compute_ggml_runtime hyle::_factor_compute_ggml_runtime)
  string(SHA256 _key "${_owner}")
  set_property(GLOBAL APPEND PROPERTY "HYLE_RUNTIME_FILES_${_key}" "${_hyle_cpu_program}")
endforeach()
set(HyleGgmlCpuRuntime_FOUND TRUE)
unset(_hyle_cpu_program)
unset(_owner)
unset(_key)
