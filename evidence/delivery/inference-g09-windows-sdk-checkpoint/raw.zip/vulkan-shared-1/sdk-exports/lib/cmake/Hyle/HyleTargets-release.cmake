#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_error" for configuration "Release"
set_property(TARGET hyle::_factor_error APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_error PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_error.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_error.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_error )
list(APPEND _cmake_import_check_files_for_hyle::_factor_error "${_IMPORT_PREFIX}/lib/hyle_error.lib" "${_IMPORT_PREFIX}/bin/hyle_error.dll" )

# Import target "hyle::_factor_time" for configuration "Release"
set_property(TARGET hyle::_factor_time APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_time PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_time.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_time.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_time )
list(APPEND _cmake_import_check_files_for_hyle::_factor_time "${_IMPORT_PREFIX}/lib/hyle_time.lib" "${_IMPORT_PREFIX}/bin/hyle_time.dll" )

# Import target "hyle::_factor_platform" for configuration "Release"
set_property(TARGET hyle::_factor_platform APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_platform.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_platform.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform "${_IMPORT_PREFIX}/lib/hyle_platform.lib" "${_IMPORT_PREFIX}/bin/hyle_platform.dll" )

# Import target "hyle::_factor_platform_thread" for configuration "Release"
set_property(TARGET hyle::_factor_platform_thread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_thread PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_platform_thread.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_platform_thread.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_thread )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_thread "${_IMPORT_PREFIX}/lib/hyle_platform_thread.lib" "${_IMPORT_PREFIX}/bin/hyle_platform_thread.dll" )

# Import target "hyle::_factor_platform_fs" for configuration "Release"
set_property(TARGET hyle::_factor_platform_fs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_fs PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_platform_fs.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_platform_fs.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_fs )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_fs "${_IMPORT_PREFIX}/lib/hyle_platform_fs.lib" "${_IMPORT_PREFIX}/bin/hyle_platform_fs.dll" )

# Import target "hyle::_factor_mem" for configuration "Release"
set_property(TARGET hyle::_factor_mem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_mem.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_mem.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem "${_IMPORT_PREFIX}/lib/hyle_mem.lib" "${_IMPORT_PREFIX}/bin/hyle_mem.dll" )

# Import target "hyle::_factor_mem_vm" for configuration "Release"
set_property(TARGET hyle::_factor_mem_vm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem_vm PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_mem_vm.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_mem_vm.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem_vm )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem_vm "${_IMPORT_PREFIX}/lib/hyle_mem_vm.lib" "${_IMPORT_PREFIX}/bin/hyle_mem_vm.dll" )

# Import target "hyle::_factor_simd" for configuration "Release"
set_property(TARGET hyle::_factor_simd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_simd PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_simd.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_simd.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_simd )
list(APPEND _cmake_import_check_files_for_hyle::_factor_simd "${_IMPORT_PREFIX}/lib/hyle_simd.lib" "${_IMPORT_PREFIX}/bin/hyle_simd.dll" )

# Import target "hyle::_factor_container" for configuration "Release"
set_property(TARGET hyle::_factor_container APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_container PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_container.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_container.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_container )
list(APPEND _cmake_import_check_files_for_hyle::_factor_container "${_IMPORT_PREFIX}/lib/hyle_container.lib" "${_IMPORT_PREFIX}/bin/hyle_container.dll" )

# Import target "hyle::_factor_sched" for configuration "Release"
set_property(TARGET hyle::_factor_sched APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_sched PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_sched.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_sched.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_sched )
list(APPEND _cmake_import_check_files_for_hyle::_factor_sched "${_IMPORT_PREFIX}/lib/hyle_sched.lib" "${_IMPORT_PREFIX}/bin/hyle_sched.dll" )

# Import target "hyle::_factor_io_core" for configuration "Release"
set_property(TARGET hyle::_factor_io_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_io_core PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_io_core.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_io_core.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_io_core )
list(APPEND _cmake_import_check_files_for_hyle::_factor_io_core "${_IMPORT_PREFIX}/lib/hyle_io_core.lib" "${_IMPORT_PREFIX}/bin/hyle_io_core.dll" )

# Import target "hyle::_factor_compute" for configuration "Release"
set_property(TARGET hyle::_factor_compute APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute "${_IMPORT_PREFIX}/lib/hyle_compute.lib" "${_IMPORT_PREFIX}/bin/hyle_compute.dll" )

# Import target "hyle::_factor_graph" for configuration "Release"
set_property(TARGET hyle::_factor_graph APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_container"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_graph.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph "${_IMPORT_PREFIX}/lib/hyle_graph.lib" "${_IMPORT_PREFIX}/bin/hyle_graph.dll" )

# Import target "hyle::_factor_compute_provider_onednn" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_onednn APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_onednn PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_onednn.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_error;hyle::_factor_mem"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_provider_onednn.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_onednn )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_onednn "${_IMPORT_PREFIX}/lib/hyle_compute_provider_onednn.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_provider_onednn.dll" )

# Import target "hyle::_factor_compute_provider_ggml" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_backend_cpu;hyle::_factor_compute_batch;hyle::_factor_compute_ops;hyle::_factor_compute_ggml_runtime;hyle::_factor_error;hyle::_factor_mem;hyle::_factor_simd"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_provider_ggml.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_provider_ggml.dll" )

# Import target "hyle::_factor_graph_provider_onednn" for configuration "Release"
set_property(TARGET hyle::_factor_graph_provider_onednn APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_provider_onednn PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_provider_onednn.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_ops;hyle::_factor_error;hyle::_factor_graph;hyle::_factor_mem;hyle::_factor_simd;hyle::_factor_compute_provider_onednn"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_graph_provider_onednn.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_provider_onednn )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_provider_onednn "${_IMPORT_PREFIX}/lib/hyle_graph_provider_onednn.lib" "${_IMPORT_PREFIX}/bin/hyle_graph_provider_onednn.dll" )

# Import target "hyle::_factor_compute_ops" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ops APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ops PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_ops.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_ops.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ops )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ops "${_IMPORT_PREFIX}/lib/hyle_compute_ops.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_ops.dll" )

# Import target "hyle::_factor_compute_backend_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_backend_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_backend_cpu PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_backend_cpu.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_backend_cpu.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_backend_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_backend_cpu "${_IMPORT_PREFIX}/lib/hyle_compute_backend_cpu.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_backend_cpu.dll" )

# Import target "hyle::_factor_compute_provider_native" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_native APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_native PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_native.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_mem;hyle::_factor_platform;hyle::_factor_simd;hyle::_factor_compute_backend_cpu;hyle::_factor_compute_ops;torch;torch_cpu;c10"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_provider_native.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_native )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_native "${_IMPORT_PREFIX}/lib/hyle_compute_provider_native.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_provider_native.dll" )

# Import target "hyle::_factor_compute_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_cpu PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_route_cpu.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_provider_native;hyle::_factor_compute_provider_onednn;hyle::_factor_compute_provider_ggml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_route_cpu.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_cpu "${_IMPORT_PREFIX}/lib/hyle_compute_route_cpu.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_route_cpu.dll" )

# Import target "hyle::_factor_graph_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_provider_native;hyle::_factor_compute_provider_onednn;hyle::_factor_graph_provider_onednn;hyle::_factor_compute_provider_ggml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_graph_route_cpu.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu.lib" "${_IMPORT_PREFIX}/bin/hyle_graph_route_cpu.dll" )

# Import target "hyle::_factor_compute_route_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_vulkan PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_route_vulkan.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_time;hyle::_factor_compute_provider_ggml_vulkan;hyle::_factor_compute_provider_iree_vulkan"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_route_vulkan.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_vulkan "${_IMPORT_PREFIX}/lib/hyle_compute_route_vulkan.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_route_vulkan.dll" )

# Import target "hyle::_factor_graph_route_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_vulkan PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_route_vulkan.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_graph_batch"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_graph_route_vulkan.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_vulkan "${_IMPORT_PREFIX}/lib/hyle_graph_route_vulkan.lib" "${_IMPORT_PREFIX}/bin/hyle_graph_route_vulkan.dll" )

# Import target "hyle::_factor_compute_provider_ggml_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml_vulkan PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml_vulkan.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute;hyle::_factor_compute_ops;hyle::_factor_error;hyle::_factor_mem;hyle::_factor_platform;hyle::_factor_compute_ggml_runtime"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_provider_ggml_vulkan.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml_vulkan "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml_vulkan.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_provider_ggml_vulkan.dll" )

# Import target "hyle::_factor_compute_ggml_runtime" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ggml_runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ggml_runtime PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_ggml_runtime.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_error;hyle::_factor_mem;hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_ggml_runtime.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ggml_runtime )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ggml_runtime "${_IMPORT_PREFIX}/lib/hyle_compute_ggml_runtime.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_ggml_runtime.dll" )

# Import target "hyle::_factor_compute_provider_iree_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_iree_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_iree_vulkan PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_iree_vulkan.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_error;hyle::_factor_mem;hyle::_factor_compute_ops;hyle::_factor_compute_provider_ggml_vulkan"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_provider_iree_vulkan.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_iree_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_iree_vulkan "${_IMPORT_PREFIX}/lib/hyle_compute_provider_iree_vulkan.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_provider_iree_vulkan.dll" )

# Import target "hyle::_factor_graph_route_cpu_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu_vulkan PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu_vulkan.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_error;hyle::_factor_mem;hyle::_factor_compute_backend_cpu;hyle::_factor_graph_route_cpu"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_graph_route_cpu_vulkan.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu_vulkan "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu_vulkan.lib" "${_IMPORT_PREFIX}/bin/hyle_graph_route_cpu_vulkan.dll" )

# Import target "hyle::_factor_compute_stream" for configuration "Release"
set_property(TARGET hyle::_factor_compute_stream APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_stream PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_stream.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_sched;hyle::_factor_time"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_stream.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_stream )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_stream "${_IMPORT_PREFIX}/lib/hyle_compute_stream.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_stream.dll" )

# Import target "hyle::_factor_compute_state" for configuration "Release"
set_property(TARGET hyle::_factor_compute_state APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_state PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_state.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_state.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_state )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_state "${_IMPORT_PREFIX}/lib/hyle_compute_state.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_state.dll" )

# Import target "hyle::_factor_compute_batch" for configuration "Release"
set_property(TARGET hyle::_factor_compute_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_batch PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_batch.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_compute_batch.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_batch "${_IMPORT_PREFIX}/lib/hyle_compute_batch.lib" "${_IMPORT_PREFIX}/bin/hyle_compute_batch.dll" )

# Import target "hyle::_factor_graph_batch" for configuration "Release"
set_property(TARGET hyle::_factor_graph_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_batch PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_batch.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/hyle_graph_batch.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_batch "${_IMPORT_PREFIX}/lib/hyle_graph_batch.lib" "${_IMPORT_PREFIX}/bin/hyle_graph_batch.dll" )

# Import target "hyle::_hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965" for configuration "Release"
set_property(TARGET hyle::_hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965 PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELEASE ""
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965 )
list(APPEND _cmake_import_check_files_for_hyle::_hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965 "${_IMPORT_PREFIX}/lib/hyle_ggml_cpu_avx2_456172ec_5909b243d5fdb965.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
