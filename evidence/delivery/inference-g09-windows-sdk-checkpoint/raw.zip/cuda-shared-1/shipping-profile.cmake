if(PROJECT_NAME STREQUAL "hyle")
  function(g08_shipping_cuda)
    set_property(GLOBAL APPEND PROPERTY JOB_POOLS g08_cuda_compile=1)
    foreach(owner IN ITEMS compute_backend_cuda compute_provider_cuda compute_provider_flashinfer compute_provider_torch_cuda)
      get_target_property(g08_kind hyle_${owner} TYPE)
      if(NOT g08_kind STREQUAL "INTERFACE_LIBRARY")
        set_target_properties(hyle_${owner} PROPERTIES JOB_POOL_COMPILE g08_cuda_compile)
      endif()
    endforeach()
    foreach(owner IN ITEMS compute_provider_flashinfer compute_provider_torch_cuda)
      get_target_property(g08_kind hyle_${owner} TYPE)
      if(NOT g08_kind STREQUAL "INTERFACE_LIBRARY")
        set_target_properties(hyle_${owner} PROPERTIES CUDA_ARCHITECTURES 89-real)
        target_compile_options(hyle_${owner} PRIVATE "$<$<COMPILE_LANGUAGE:CUDA>:--split-compile=3>")
      endif()
    endforeach()
    set_property(SOURCE
      "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda/collectives.cu"
      "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda/sampling_kernel.cu"
      DIRECTORY "${PROJECT_SOURCE_DIR}/src/compute_provider_cuda"
      APPEND PROPERTY COMPILE_OPTIONS "--split-compile=3")
  endfunction()
  cmake_language(DEFER CALL g08_shipping_cuda)
endif()
