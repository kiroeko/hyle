from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,sys,time

root=Path('C:/public/project-hyle/hyle');route,mode=sys.argv[1:3];resume='--resume-consumer' in sys.argv
assert sys.platform=='win32' and route in ['cuda','vulkan'] and mode in ['source','static','shared']
assert not resume or (route=='cuda' and mode=='static')
folder=Path('C:/h7/g09-sdk')/f'{route}-{mode}-1';folder.mkdir(parents=True,exist_ok=resume)
out=root/'.scratch/inference-gaps/g09-sdk-windows'/f'{route}-{mode}-1';out.mkdir(parents=True,exist_ok=resume)
family=Path('C:/h7')/f'w-cpu-{route}/selected-graph'
producer=family/'source-build' if mode=='source' else Path('C:/h7')/f'w-{route}/selected-graph/{mode}-sdk-build'
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
env.update(VSLANG='1033',HYLE_VULKAN_VALIDATION='0',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
cuda=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3');vk=Path('C:/public/tools/hyle-vulkan/1.4.357.0')
env['PATH']=str(cuda/'bin' if route=='cuda' else vk/'Bin')+';'+env['PATH']
if route=='vulkan':env['VULKAN_SDK']=str(vk)
ctypes.windll.kernel32.SetErrorMode(0x0001|0x0002|0x8000)
jobs=2 if route=='cuda' else 4;started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'state':'SETUP','pid':os.getpid(),'route':route,'mode':mode,'producer':str(producer),'stages':[],'max_jobs':jobs,
   'candidate':'3524413272cb52d06af5e64d634edbfef09b9864','product_code_commit':'e09f30925c6dba5cf4540669fd3b4874f45bb158',
   'scope':'Fixed G09 public Graph contracts/two-slot pipeline and affected G06 direct consumers through source/independent relocated Windows SDK. Public headers; no sanitizer/trace/device/P1 claim.'}
parent_file=None;original_parent=None
if resume:
    old=json.loads((out/'result.json').read_text());assert old['state']=='FAIL' and old['stage']=='consumer-build'
    assert 'flashinfer.h' in (out/'consumer-build.log').read_text(errors='replace')
    history=out/'retained-inapplicable-fixture-failure';history.mkdir(exist_ok=False)
    for path in out.iterdir():
        if path.is_file():(history/path.name).write_bytes(path.read_bytes())
    r=old;r.update(pid=os.getpid(),state='RESUMING_SAME_INSTALLED_SDK')
    r['retained_failure']='retained-inapplicable-fixture-failure/result.json'
    r['fixture_correction']='Both G06 FlashInfer fixtures explicitly require qualified Linux FlashInfer. Windows provider is OPTIONAL_ABSENT by existing src/compute_provider_flashinfer/CMakeLists.txt; SDK correctly omits that split header. No feature/product change; remove inapplicable fixtures, keep contracts and ordinary CUDA joint pipeline. Qualified Linux tests remain required on WSL.'
    started=time.monotonic()-old['elapsed_seconds']

def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')

def write_changed(p,data):
    if isinstance(data,str):data=data.encode()
    if not p.is_file() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)

def run(stage,args):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(route,mode,stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(x) for x in args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        get=ctypes.windll.kernel32.GetProcessAffinityMask;get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        set_mask=ctypes.windll.kernel32.SetProcessAffinityMask;set_mask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle))
        if not get(handle,ctypes.byref(available),ctypes.byref(system)):p.terminate();p.wait();raise OSError('Cannot read affinity')
        mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4])
        if not set_mask(handle,mask):p.terminate();p.wait();raise OSError('Cannot bound affinity')
        r.update(child_pid=p.pid,priority='BELOW_NORMAL',logical_cpu_limit=4,affinity_mask=hex(mask));save()
        while True:
            try:code=p.wait(timeout=1800);break
            except subprocess.TimeoutExpired:r.setdefault('time_extensions',[]).append({'stage':stage,'pid':p.pid,'seconds':1800});save()
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(x) for x in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-14000:],flush=True);raise SystemExit(code)

def checked_build(build,targets,label):
    run(label+'-manifest',['ninja','-C',build,'build.ninja'])
    preview=out/(label+'-preview.ninja');preview.write_bytes((build/'build.ninja').read_bytes())
    dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace')
    (out/(label+'-unmapped-dry-run.log')).write_text(dry,encoding='utf8')
    if route=='cuda' and build==producer and any('Building CUDA object' in x and ('ggml-cuda.dir' in x or 'ggml-cuda-precise-unary.dir' in x) for x in dry.splitlines()):
        index=1
        while (root/f'.scratch/inference-gaps/g08-windows-{mode}-native-reuse-{index}').exists():index+=1
        run(label+'-native-reuse',[sys.executable,'-X','utf8',root/'.scratch/inference-gaps/g08_windows_cuda_native_reuse.py',mode,str(index)])
        reuse=root/f'.scratch/inference-gaps/g08-windows-{mode}-native-reuse-{index}'
        proof=json.loads((reuse/'result.json').read_text());assert proof['state']=='PASS_146_WINDOWS_NATIVE_OBJECTS_INPUTS_AND_ORIGINAL_NINJA_COMMANDS_FRESH'
        assert Path(proof['build']).resolve()==build.resolve() and proof['original_manifest_sha256']==sha(build/'build.ninja') and proof['reuse_manifest_sha256']==sha(reuse/'reuse.ninja')
        r[label+'_native_reuse']={'path':str(reuse),'proof_sha256':sha(reuse/'result.json'),'proof':proof};preview.write_bytes((reuse/'reuse.ninja').read_bytes())
        dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace')
    (out/(label+'-dry-run.log')).write_text(dry,encoding='utf8');r[label+'_build_edges']=len(dry.splitlines());save()
    assert len(dry.splitlines())<180 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry and 'Generate vulkan shaders' not in dry and not any('vulkan-shaders-gen' in x for x in dry.splitlines() if 'Performing ' in x),dry
    commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],env=env,text=True,encoding='utf8',errors='replace'))
    shipping=[x for x in commands if x.get('file','').replace('\\','/').startswith(root.as_posix()+'/src/')]
    assert all('HYLE_TESTING' not in x['command'] and '-fsanitize=' not in x['command'] for x in shipping)
    if build==producer:assert shipping
    (out/(label+'-commands.json')).write_text(json.dumps(commands,indent=2)+'\n',encoding='utf8')
    run(label+'-build',['ninja','-C',build,'-f',preview,'-j',str(jobs),*targets])

try:
    assert not subprocess.check_output(['git','status','--porcelain','--','.',':!evidence/**'],cwd=root,text=True).strip()
    r['source_snapshot']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    subprocess.run(['git','diff','--exit-code',r['candidate'],'--','src','include','cmake','CMakeLists.txt','tests','samples'],cwd=root,check=True,stdout=subprocess.DEVNULL)
    paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
    inputs=[{'path':x,'sha256':sha(root/x)} for x in paths if not x.startswith('evidence/') and (root/x).is_file()]
    if resume:assert json.loads((out/'source-inputs.json').read_text())==inputs
    else:(out/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
    (out/('runner-resume.py' if resume else 'runner.py')).write_bytes(Path(__file__).read_bytes())
    registry=json.loads((root/'docs/implementation/module-status.json').read_text())
    owners=[x for x in registry['modules'] if x.get('record','').endswith('inference-g09-joint-pipeline.md')]
    assert len(owners)==4 and all(x['state']=='CANDIDATE' and x['candidate']==r['candidate'] for x in owners)
    r['identity']={'host':env.get('COMPUTERNAME'),'compiler':env.get('VCTOOLSVERSION'),'os':subprocess.check_output(['cmd','/d','/c','ver'],text=True).strip(),
        'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],env=env,text=True).strip()}
    profile=root/'.scratch/inference-gaps/g08_shipping_cuda_profile.cmake'
    if route=='cuda':(out/'shipping-profile.cmake').write_bytes(profile.read_bytes())
    if mode!='source' and not resume:
        args=['cmake','-S',root.as_posix(),'-B',producer.as_posix(),'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_TEST_INSTRUMENTATION=OFF',
            '-DHYLE_SANITIZER=off','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu;'+route,'-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF')]
        args+=['-DCMAKE_PROJECT_INCLUDE='+profile.as_posix()] if route=='cuda' else ['-UCMAKE_PROJECT_INCLUDE']
        run('producer-configure',args)
        checked_build(producer,['hyle_compute','hyle_compute_ops','hyle_compute_batch','hyle_compute_state','hyle_compute_stream','hyle_graph','hyle_graph_batch',
            f'hyle_compute_route_{route}',f'hyle_graph_route_{route}',f'hyle_graph_route_cpu_{route}'],'producer')
        staging=folder/'staging';prefix=folder/'relocated';run('install',['cmake','--install',producer,'--prefix',staging]);staging.rename(prefix)
        consumer=folder/'consumer';consumer.mkdir();build=folder/'consumer-build';r['relocated_prefix']=str(prefix)
    elif resume:
        prefix=folder/'relocated';assert prefix.is_dir() and not (folder/'staging').exists()
        consumer=folder/'consumer';assert consumer.is_dir();build=folder/'consumer-build'
        r['resumed_sdk_snapshot']=[{'path':p.relative_to(prefix).as_posix(),'sha256':sha(p)} for p in sorted(prefix.rglob('*')) if p.is_file()]
    else:
        prefix=None;consumer=family/'source-parent';parent_file=consumer/'CMakeLists.txt';original_parent=parent_file.read_bytes()
        (out/'original-parent.cmake').write_bytes(original_parent);build=producer
    fixtures={'g09_contracts':f'tests/graph/cpu_{route}_contracts.cc','g09_pipeline':'tests/graph/'+('cpu_cuda_pipeline.cc' if route=='cuda' else 'native_joint_pipeline.cc')}
    if route=='cuda':r['not_applicable_consumers']={'files':['tests/compute_batch/public_hybrid_batch_consumer.cc','tests/compute_batch/pending_paged_receiver_cuda_consumer.cc'],'reason':'Existing Linux-only FlashInfer consumer; Windows OPTIONAL_ABSENT provider and split-header export. They run on qualified WSL CUDA, not Windows.'}
    else:fixtures['g09_pending']='tests/compute_batch/pending_paged_receiver_native_consumer.cc'
    copied=set()
    def copy(relative):
        if relative in copied:return
        p=(root/relative).resolve();assert p.is_relative_to(root.resolve()) and relative.split('/')[0] in ['tests','samples'],relative
        data=p.read_bytes();write_changed(consumer/relative,data);copied.add(relative)
        for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode(),re.M):
            if not inc.startswith('hyle/'):copy((p.parent/inc).resolve().relative_to(root.resolve()).as_posix())
    for relative in fixtures.values():copy(relative)
    r['fixture_inputs']=[{'path':x,'sha256':sha(consumer/x)} for x in sorted(copied)]
    headers=['graph/cpu.h',f'graph/cpu_{route}.h']
    for i,h in enumerate(headers):
        if prefix:assert sha(prefix/'include/hyle'/h)==sha(root/'include/hyle'/h)
        write_changed(consumer/f'g09-header-{i}.cc','#include <hyle/'+h+'>\n')
    body='cmake_minimum_required(VERSION 3.25)\nproject(g09_public_delivery LANGUAGES CXX)\n'
    if mode=='source':
        body+='set(HYLE_COMPONENTS "compute;graph" CACHE STRING "" FORCE)\nset(HYLE_COMPUTE_ROUTES "cpu;'+route+'" CACHE STRING "" FORCE)\n'
        for key in ['HYLE_BUILD_TESTS','HYLE_BUILD_BENCH','HYLE_INSTALL','HYLE_TEST_INSTRUMENTATION']:body+=f'set({key} OFF CACHE BOOL "" FORCE)\n'
        body+='add_subdirectory("'+root.as_posix()+'" hyle)\n'
    else:body+='find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\n'
    for name,relative in fixtures.items():
        body+=f'add_executable({name} "{relative}")\ntarget_compile_features({name} PRIVATE cxx_std_23)\ntarget_link_libraries({name} PRIVATE hyle::compute hyle::graph'+(' CUDA::cudart' if route=='cuda' else '')+')\nhyle_stage_runtime('+name+')\n'
        body+=f'set_target_properties({name} PROPERTIES RUNTIME_OUTPUT_DIRECTORY "{(folder/"bin").as_posix()}")\n'
    if route=='vulkan':body+='target_compile_definitions(g09_pending PRIVATE HYLE_PENDING_NATIVE_JOINT_GRAPH=1)\n'
    body+='add_library(g09_headers OBJECT g09-header-0.cc g09-header-1.cc)\ntarget_compile_features(g09_headers PRIVATE cxx_std_23)\ntarget_link_libraries(g09_headers PRIVATE hyle::compute hyle::graph)\n'
    write_changed(consumer/'CMakeLists.txt',body);(out/'consumer.cmake').write_text(body,encoding='utf8')
    args=['cmake','-S',consumer.as_posix(),'-B',build.as_posix(),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    if prefix:args+=['-DCMAKE_PREFIX_PATH='+prefix.as_posix()]
    else:args+=['-DHYLE_STATIC='+('ON' if route=='cuda' else 'OFF'),'-DHYLE_SANITIZER=off']+(['-DCMAKE_PROJECT_INCLUDE='+profile.as_posix()] if route=='cuda' else ['-UCMAKE_PROJECT_INCLUDE'])
    if route=='cuda':args+=['-DCUDAToolkit_ROOT='+cuda.as_posix()]
    run('consumer-configure',args);checked_build(build,[*fixtures,'g09_headers'],'consumer')
    files=[*(consumer/x for x in fixtures.values()),*(consumer/f'g09-header-{i}.cc' for i in range(2))]
    actual=[x for x in json.loads((build/'compile_commands.json').read_text()) if Path(x['file']).resolve() in files]
    assert len(actual)==len(fixtures)+2,len(actual)
    for row in actual:
        cmd=row['command'].replace('\\','/');assert (root/'src').as_posix() not in cmd and 'HYLE_TESTING' not in cmd and '-fsanitize=' not in cmd
        if prefix:assert root.as_posix() not in cmd and producer.as_posix() not in cmd and (prefix/'include').as_posix() in cmd,cmd
        else:assert (root/'include').as_posix() in cmd,cmd
    (out/'public-consumer-commands.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf8')
    cache=(build/'CMakeCache.txt').read_text();compiler=Path(next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_CXX_COMPILER:')))
    dumpbin=compiler.with_name('dumpbin.exe');assert dumpbin.is_file()
    pending=[folder/'bin'/(name+'.exe') for name in fixtures];seen=set();staged=[]
    while pending:
        binary=pending.pop()
        if binary.name.lower() in seen:continue
        seen.add(binary.name.lower());deps=subprocess.check_output([str(dumpbin),'/nologo','/dependents',str(binary)],env=env,text=True,encoding='utf8',errors='replace')
        (out/(binary.name+'-dependencies.log')).write_text(deps,encoding='utf8')
        for name in re.findall(r'^\s+(hyle_[^\s]+\.dll)\s*$',deps,re.M|re.I):
            staged_file=folder/'bin'/name;assert staged_file.is_file(),name
            matches=[p for p in (prefix if prefix else build/'hyle').rglob(name) if p.is_file()]
            assert len(matches)==1,(name,matches);assert sha(staged_file)==sha(matches[0]),name
            staged.append({'staged':str(staged_file),'original':str(matches[0]),'sha256':sha(staged_file)});pending.append(staged_file)
    r['staged_runtime']=staged
    if (mode=='shared' or mode=='source' and route=='vulkan'):assert staged
    clean=[]
    for part in env['PATH'].split(';'):
        if part and not Path(part).resolve().is_relative_to(root.resolve()) and not Path(part).resolve().is_relative_to(producer.resolve()):clean.append(part)
    env['PATH']=';'.join(clean)
    for name in fixtures:
        binary=folder/'bin'/(name+'.exe');run(name,[binary]);r.setdefault('binaries',[]).append({'path':str(binary),'sha256':sha(binary)})
    if prefix:r['sdk_files']=[{'path':p.relative_to(prefix).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(prefix.rglob('*')) if p.is_file()]
    r['public_header_inputs']=[{'path':h,'sha256':sha((prefix/'include/hyle' if prefix else root/'include/hyle')/h)} for h in headers]
    for x in inputs:assert sha(root/x['path'])==x['sha256'],x['path']
    r['state']='SOURCE_PUBLIC_CONSUMERS_HEADERS_PASS' if mode=='source' else 'RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS';save();print(route,mode,r['state'],r['elapsed_seconds'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
finally:
    if parent_file is not None and original_parent is not None:parent_file.write_bytes(original_parent);r['original_parent_restored']=sha(parent_file)==hashlib.sha256(original_parent).hexdigest();save()
