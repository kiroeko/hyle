from pathlib import Path
import json,subprocess,sys,time
root=Path('C:/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g09-sdk-windows/matrix.json'
assert not out.exists()
first=json.loads((out.parent/'cuda-static-1/result.json').read_text());assert first['state']=='RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS'
r={'state':'RUNNING','serial':True,'cases':[{'route':'cuda','mode':'static','state':first['state'],'elapsed_seconds':first['elapsed_seconds']}],'stages':[]}
started=time.monotonic()
for route,mode in [('cuda','shared'),('cuda','source'),('vulkan','static'),('vulkan','shared'),('vulkan','source')]:
 name=f'{route}-{mode}';r['stage']=name;out.write_text(json.dumps(r,indent=2)+'\n');print(name,'START',flush=True)
 with (out.parent/(name+'-matrix.log')).open('wb') as log:
  p=subprocess.run([sys.executable,'-X','utf8',str(root/'.scratch/inference-gaps/g09_windows_sdk.py'),route,mode],stdout=log,stderr=subprocess.STDOUT)
 result=out.parent/(name+'-1/result.json');v=json.loads(result.read_text()) if result.is_file() else {}
 r['cases'].append({'route':route,'mode':mode,'exit_code':p.returncode,'state':v.get('state'),'elapsed_seconds':v.get('elapsed_seconds'),'result':str(result)})
 r['matrix_elapsed_seconds']=time.monotonic()-started;out.write_text(json.dumps(r,indent=2)+'\n');print(name,p.returncode,v.get('state'),flush=True)
r['state']='WINDOWS_SIX_DELIVERIES_PASS' if len(r['cases'])==6 and all(x['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS','SOURCE_PUBLIC_CONSUMERS_HEADERS_PASS'] for x in r['cases']) else 'FINITE_FAILURES_RETAINED_WITH_ALL_CONFIGURATIONS_OBSERVED'
out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
