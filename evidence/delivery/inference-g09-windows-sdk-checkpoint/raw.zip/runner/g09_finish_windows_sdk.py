from pathlib import Path
import json,subprocess,sys,time
root=Path('C:/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g09-sdk-windows'
initial=json.loads((base/'matrix.json').read_text());assert initial['state']=='FINITE_FAILURES_RETAINED_WITH_ALL_CONFIGURATIONS_OBSERVED'
output=base/'matrix-final.json';assert not output.exists()
r={'state':'RUNNING_FINITE_SAME_TREE_RETRIES','serial':True,'initial_matrix':'matrix.json','stages':[]};started=time.monotonic()
for route,mode,flag in [('cuda','source','--resume-source-configure'),('vulkan','static','--resume-generator-preflight'),('vulkan','shared','--resume-generator-preflight')]:
 key=f'{route}-{mode}';r['stage']=key;output.write_text(json.dumps(r,indent=2)+'\n');print(key,'RETRY',flush=True)
 command=[sys.executable,'-X','utf8',str(root/'.scratch/inference-gaps/g09_windows_sdk.py'),route,mode,flag]
 with (base/(key+'-matrix-retry.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 result=base/f'{route}-{mode}-1/result.json';v=json.loads(result.read_text())
 r['stages'].append({'case':key,'command':command,'exit_code':p.returncode,'state':v['state'],'elapsed_seconds_including_original':v['elapsed_seconds']})
 r['retry_elapsed_seconds']=time.monotonic()-started;output.write_text(json.dumps(r,indent=2)+'\n');print(key,p.returncode,v['state'],flush=True)
r['cases']=[]
for route in ['cuda','vulkan']:
 for mode in ['static','shared','source']:
  file=base/f'{route}-{mode}-1/result.json';v=json.loads(file.read_text())
  r['cases'].append({'route':route,'mode':mode,'state':v['state'],'result':str(file),'actual_cumulative_seconds':v['elapsed_seconds']})
r['state']='WINDOWS_SIX_DELIVERIES_PASS' if all(x['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS','SOURCE_PUBLIC_CONSUMERS_HEADERS_PASS'] for x in r['cases']) else 'FINITE_FAILURE_REVIEW_REQUIRED'
r['actual_cumulative_seconds']=sum(x['actual_cumulative_seconds'] for x in r['cases']);r['cost_reset']=False
output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
