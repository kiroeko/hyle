#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_error" for configuration "Release"
set_property(TARGET hyle::_factor_error APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_error PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_error.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_error )
list(APPEND _cmake_import_check_files_for_hyle::_factor_error "${_IMPORT_PREFIX}/lib/hyle_error.lib" )

# Import target "hyle::_factor_time" for configuration "Release"
set_property(TARGET hyle::_factor_time APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_time PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_time.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_time )
list(APPEND _cmake_import_check_files_for_hyle::_factor_time "${_IMPORT_PREFIX}/lib/hyle_time.lib" )

# Import target "hyle::_factor_platform" for configuration "Release"
set_property(TARGET hyle::_factor_platform APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_platform.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform "${_IMPORT_PREFIX}/lib/hyle_platform.lib" )

# Import target "hyle::_factor_platform_thread" for configuration "Release"
set_property(TARGET hyle::_factor_platform_thread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_thread PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_platform_thread.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_thread )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_thread "${_IMPORT_PREFIX}/lib/hyle_platform_thread.lib" )

# Import target "hyle::_factor_platform_fs" for configuration "Release"
set_property(TARGET hyle::_factor_platform_fs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_fs PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_platform_fs.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_fs )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_fs "${_IMPORT_PREFIX}/lib/hyle_platform_fs.lib" )

# Import target "hyle::_factor_mem" for configuration "Release"
set_property(TARGET hyle::_factor_mem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_mem.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem "${_IMPORT_PREFIX}/lib/hyle_mem.lib" )

# Import target "hyle::_factor_mem_vm" for configuration "Release"
set_property(TARGET hyle::_factor_mem_vm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem_vm PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_mem_vm.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem_vm )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem_vm "${_IMPORT_PREFIX}/lib/hyle_mem_vm.lib" )

# Import target "hyle::_factor_simd" for configuration "Release"
set_property(TARGET hyle::_factor_simd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_simd PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_simd.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_simd )
list(APPEND _cmake_import_check_files_for_hyle::_factor_simd "${_IMPORT_PREFIX}/lib/hyle_simd.lib" )

# Import target "hyle::_factor_container" for configuration "Release"
set_property(TARGET hyle::_factor_container APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_container PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_container.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_container )
list(APPEND _cmake_import_check_files_for_hyle::_factor_container "${_IMPORT_PREFIX}/lib/hyle_container.lib" )

# Import target "hyle::_factor_sched" for configuration "Release"
set_property(TARGET hyle::_factor_sched APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_sched PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM_MASM;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_sched.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_sched )
list(APPEND _cmake_import_check_files_for_hyle::_factor_sched "${_IMPORT_PREFIX}/lib/hyle_sched.lib" )

# Import target "hyle::_factor_io_core" for configuration "Release"
set_property(TARGET hyle::_factor_io_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_io_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_io_core.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_io_core )
list(APPEND _cmake_import_check_files_for_hyle::_factor_io_core "${_IMPORT_PREFIX}/lib/hyle_io_core.lib" )

# Import target "hyle::_factor_compute" for configuration "Release"
set_property(TARGET hyle::_factor_compute APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute "${_IMPORT_PREFIX}/lib/hyle_compute.lib" )

# Import target "hyle::_factor_graph" for configuration "Release"
set_property(TARGET hyle::_factor_graph APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph "${_IMPORT_PREFIX}/lib/hyle_graph.lib" )

# Import target "hyle::_factor_compute_provider_onednn" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_onednn APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_onednn PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_onednn.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_onednn )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_onednn "${_IMPORT_PREFIX}/lib/hyle_compute_provider_onednn.lib" )

# Import target "hyle::_factor_compute_provider_ggml" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml.lib" )

# Import target "hyle::_factor_graph_provider_onednn" for configuration "Release"
set_property(TARGET hyle::_factor_graph_provider_onednn APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_provider_onednn PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_provider_onednn.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_provider_onednn )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_provider_onednn "${_IMPORT_PREFIX}/lib/hyle_graph_provider_onednn.lib" )

# Import target "hyle::_factor_compute_ops" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ops APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ops PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_ops.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ops )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ops "${_IMPORT_PREFIX}/lib/hyle_compute_ops.lib" )

# Import target "hyle::_factor_compute_backend_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_backend_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_backend_cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_backend_cpu.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_backend_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_backend_cpu "${_IMPORT_PREFIX}/lib/hyle_compute_backend_cpu.lib" )

# Import target "hyle::_factor_compute_backend_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_compute_backend_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_backend_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CUDA;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_backend_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_backend_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_backend_cuda "${_IMPORT_PREFIX}/lib/hyle_compute_backend_cuda.lib" )

# Import target "hyle::_factor_compute_provider_native" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_native APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_native PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_native.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_native )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_native "${_IMPORT_PREFIX}/lib/hyle_compute_provider_native.lib" )

# Import target "hyle::_factor_compute_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_route_cpu.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_cpu "${_IMPORT_PREFIX}/lib/hyle_compute_route_cpu.lib" )

# Import target "hyle::_factor_graph_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu.lib" )

# Import target "hyle::_factor_compute_provider_cublas" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_cublas APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_cublas PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_cublas.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_cublas )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_cublas "${_IMPORT_PREFIX}/lib/hyle_compute_provider_cublas.lib" )

# Import target "hyle::_factor_compute_provider_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CUDA;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_cuda "${_IMPORT_PREFIX}/lib/hyle_compute_provider_cuda.lib" )

# Import target "hyle::_factor_compute_route_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_route_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_cuda "${_IMPORT_PREFIX}/lib/hyle_compute_route_cuda.lib" )

# Import target "hyle::_factor_graph_route_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_route_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cuda "${_IMPORT_PREFIX}/lib/hyle_graph_route_cuda.lib" )

# Import target "hyle::_factor_compute_ggml_runtime" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ggml_runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ggml_runtime PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_ggml_runtime.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ggml_runtime )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ggml_runtime "${_IMPORT_PREFIX}/lib/hyle_compute_ggml_runtime.lib" )

# Import target "hyle::_factor_compute_provider_ggml_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml_cuda "${_IMPORT_PREFIX}/lib/hyle_compute_provider_ggml_cuda.lib" )

# Import target "hyle::_factor_graph_provider_ggml_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_graph_provider_ggml_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_provider_ggml_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_provider_ggml_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_provider_ggml_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_provider_ggml_cuda "${_IMPORT_PREFIX}/lib/hyle_graph_provider_ggml_cuda.lib" )

# Import target "hyle::_factor_compute_provider_torch_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_torch_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_torch_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CUDA;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_torch_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_torch_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_torch_cuda "${_IMPORT_PREFIX}/lib/hyle_compute_provider_torch_cuda.lib" )

# Import target "hyle::_factor_graph_route_cpu_cuda" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu_cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu_cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu_cuda )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu_cuda "${_IMPORT_PREFIX}/lib/hyle_graph_route_cpu_cuda.lib" )

# Import target "hyle::_factor_compute_stream" for configuration "Release"
set_property(TARGET hyle::_factor_compute_stream APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_stream PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_stream.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_stream )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_stream "${_IMPORT_PREFIX}/lib/hyle_compute_stream.lib" )

# Import target "hyle::_factor_compute_state" for configuration "Release"
set_property(TARGET hyle::_factor_compute_state APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_state PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_state.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_state )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_state "${_IMPORT_PREFIX}/lib/hyle_compute_state.lib" )

# Import target "hyle::_factor_compute_batch" for configuration "Release"
set_property(TARGET hyle::_factor_compute_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_batch PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_batch.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_batch "${_IMPORT_PREFIX}/lib/hyle_compute_batch.lib" )

# Import target "hyle::_factor_graph_batch" for configuration "Release"
set_property(TARGET hyle::_factor_graph_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_batch PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_graph_batch.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_batch "${_IMPORT_PREFIX}/lib/hyle_graph_batch.lib" )

# Import target "hyle::_mimalloc" for configuration "Release"
set_property(TARGET hyle::_mimalloc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_mimalloc PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/mimalloc_static.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_mimalloc )
list(APPEND _cmake_import_check_files_for_hyle::_mimalloc "${_IMPORT_PREFIX}/lib/mimalloc_static.lib" )

# Import target "hyle::_onednn_static" for configuration "Release"
set_property(TARGET hyle::_onednn_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_onednn_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX;RC"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/dnnl.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_onednn_static )
list(APPEND _cmake_import_check_files_for_hyle::_onednn_static "${_IMPORT_PREFIX}/lib/dnnl.lib" )

# Import target "hyle::_hyle_ggml_cpu_avx2_456172ec_2f41ad48bddb8a44" for configuration "Release"
set_property(TARGET hyle::_hyle_ggml_cpu_avx2_456172ec_2f41ad48bddb8a44 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_hyle_ggml_cpu_avx2_456172ec_2f41ad48bddb8a44 PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELEASE ""
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_ggml_cpu_avx2_456172ec_2f41ad48bddb8a44.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_hyle_ggml_cpu_avx2_456172ec_2f41ad48bddb8a44 )
list(APPEND _cmake_import_check_files_for_hyle::_hyle_ggml_cpu_avx2_456172ec_2f41ad48bddb8a44 "${_IMPORT_PREFIX}/lib/hyle_ggml_cpu_avx2_456172ec_2f41ad48bddb8a44.dll" )

# Import target "hyle::_ggml_ggml" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml "${_IMPORT_PREFIX}/lib/ggml.lib" )

# Import target "hyle::_ggml_ggml-base" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-base PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml-base.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-base )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-base "${_IMPORT_PREFIX}/lib/ggml-base.lib" )

# Import target "hyle::_ggml_ggml-cpu" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml-cpu.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-cpu )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-cpu "${_IMPORT_PREFIX}/lib/ggml-cpu.lib" )

# Import target "hyle::_ggml_ggml-cuda" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CUDA"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml-cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-cuda )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-cuda "${_IMPORT_PREFIX}/lib/ggml-cuda.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
