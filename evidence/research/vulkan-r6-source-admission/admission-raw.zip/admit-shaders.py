from pathlib import Path
import ctypes,hashlib,json,re,struct,subprocess
root=Path('C:/hyle-scratch/r6-vulkan-20260917/admission/shaders-windows')
root.mkdir(parents=True,exist_ok=True)
assert not (root/'receipt.json').exists()
peer=Path('C:/public/project-hyle/ggml')
source=peer/'src/ggml-vulkan/vulkan-shaders'
revision=subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()
assert revision=='456172ec733a135778adcd32d00e576a58232e45'
compiler=Path('C:/public/tools/glslang/glslangValidator.exe')
ctypes.windll.kernel32.SetErrorMode(0x8003)
common={'DATA_A_F32':'1','FLOAT_TYPE':'float','FLOAT_TYPEV2':'vec2','FLOAT_TYPEV4':'vec4','FLOAT_TYPEV8':'mat2x4','B_TYPE':'float','B_TYPEV2':'vec2','B_TYPEV4':'vec4','D_TYPE':'float'}
mm=dict(common,LOAD_VEC_A='4',LOAD_VEC_B='4',B_TYPE='vec4',B_TYPE_SCALAR='float',ACC_TYPE='float',ACC_TYPEV2='vec2')
variants=[('mm-f32','mul_mm.comp',mm),('mv-f32','mul_mat_vec.comp',common),('mv-f32-subgroup','mul_mat_vec.comp',dict(common,USE_SUBGROUP_ADD='1')),('swiglu-f32','swiglu.comp',{'A_TYPE':'float','D_TYPE':'float'})]
inputs={}
def collect(name):
    if name in inputs: return
    path=source/name
    raw=path.read_bytes()
    gitraw=subprocess.check_output(['git','-C',str(peer),'show',revision+':src/ggml-vulkan/vulkan-shaders/'+name])
    assert raw.replace(b'\r\n',b'\n')==gitraw.replace(b'\r\n',b'\n'),name
    inputs[name]=hashlib.sha256(gitraw).hexdigest()
    for include in re.findall(r'^\s*#include\s+"([^\"]+)"',raw.decode(),re.M): collect(include)
header=Path('C:/public/project-hyle/glslang/SPIRV/spirv.hpp11').read_text()
capsection=re.search(r'enum class Capability[^\{]*\{(.*?)\};',header,re.S).group(1)
names={int(value):name for name,value in re.findall(r'(\w+)\s*=\s*(\d+)',capsection)}
results=[]
for label,name,defines in variants:
    collect(name)
    output=root/(label+'.spv')
    command=[str(compiler),'-V','--target-env','vulkan1.2','--preamble-text','#extension GL_GOOGLE_include_directive : require\n','-I'+str(source),'-S','comp']
    command += ['-D'+k+'='+v for k,v in defines.items()]
    command += ['-o',str(output),str(source/name)]
    process=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
    (root/(label+'.log')).write_bytes(process.stdout)
    row={'variant':label,'command':command,'exit_code':process.returncode}
    if process.returncode==0:
        raw=output.read_bytes(); words=struct.unpack('<'+'I'*(len(raw)//4),raw); caps=[]; i=5
        while i < len(words):
            word=words[i]; size=word>>16; op=word&65535
            assert size>0
            if op==17: caps.append({'value':words[i+1],'name':names.get(words[i+1],'UNKNOWN')})
            i+=size
        row.update(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),capabilities=caps)
    results.append(row)
    print(label,json.dumps({k:v for k,v in row.items() if k!='command'}))
    if process.returncode: print(process.stdout.decode(errors='replace')); break
receipt={'kind':'compiler admission only; no native execution or product qualification','peer_revision':revision,'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'source_blobs_sha256':inputs,'results':results}
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
