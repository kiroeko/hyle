"""One offline replay of already archived D5 logs; never launches a benchmark."""
from pathlib import Path
from collections import Counter
import gzip, hashlib, json, re, statistics, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/research/llm-moe-d5-residual-contract-audit'
OUT.mkdir(parents=True, exist_ok=True)
BASE = '416242f8ef2cd9a83d558b3b7879e4c2c1707be4'
def sha(data): return hashlib.sha256(data).hexdigest()
def save(name, obj):
    (OUT / name).write_bytes((json.dumps(obj, indent=2, ensure_ascii=False)+'\n').encode())
def read_log(p):
    data = p.read_bytes()
    return gzip.decompress(data).decode('utf-8').replace('\r', ''), sha(data)

sources = []
def source(label, path, revision, ranges, url=None, git_path=None):
    p = Path(path)
    data = (subprocess.check_output(['git','-C',str(p),'show',revision+':'+git_path],
            creationflags=subprocess.CREATE_NO_WINDOW) if git_path else p.read_bytes())
    lines = data.decode('utf-8').splitlines()
    item = {'name':label, 'path':git_path or str(p), 'revision':revision,
            'sha256':sha(data), 'url':url,
            'excerpts':[{'first_line':a,'last_line':b,'text':'\n'.join(lines[a-1:b])} for a,b in ranges]}
    sources.append(item)

official = ROOT/'.scratch/validation/d5-f38-dynamic-fp8'
source('DeepSeek original kernel',official/'official-kernel.py',
       'b5968e9190ef611bbf34a7229255be88a0e937c1',[(15,100),(128,183)],
       'https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/b5968e9190ef611bbf34a7229255be88a0e937c1/inference/kernel.py')
source('DeepSeek original model',official/'official-model.py',
       'b5968e9190ef611bbf34a7229255be88a0e937c1',[(108,140),(360,375),(410,421)],
       'https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/b5968e9190ef611bbf34a7229255be88a0e937c1/inference/model.py')
for file,ranges in [('conversion/deepseek.py',[(691,746)]),('conversion/base.py',[(430,462)])]:
    source('llama.cpp GGUF conversion','C:/public/project-hyle/llama.cpp',
           '4c9233c034fc450dcf34c7c0988aebe6da5cdf1a',ranges,git_path=file)
source('ds4 CPU existing math','C:/public/project-hyle/ds4',
       '9139e2ae58a41503968a500f36f75895c1ba63fc',[(3705,3838),(4230,4288)],git_path='ds4.c')
source('ds4 Metal existing QAT','C:/public/project-hyle/ds4',
       '9139e2ae58a41503968a500f36f75895c1ba63fc',[(58,132),(155,214)],git_path='metal/dsv4_kv.metal')
source('PyTorch C10 candidate, not HYLE dependency',
       'C:/Program Files/Python312/Lib/site-packages/torch/include/c10/util/Float8_e4m3fn.h',
       '2.8.0+cu129 / a1cb3cc05d46d198467bebbb6e8fba50a325d4e7',[(145,230)])
for file,ranges in [('include/hyle/compute/model_ops.h',[(20,47),(94,123),(147,175),(190,219)]),
                    ('bench/graph_route_cpu/d5_common.h',[(149,174)]),
                    ('bench/graph_route_vulkan/d5_fragment_bench.cc',[(60,83),(118,137)]),
                    ('third_party/nanobench/nanobench.h',[(4133,4175),(4194,4258)])]:
    source('HYLE current source',ROOT,BASE,ranges,git_path=file)
inventory_path=ROOT/'.scratch/official-weight-audit.json'
inventory=json.loads(inventory_path.read_text(encoding='utf-8'))
configs=[]
for key in ('glm53','glm53_flash','deepseek_v4_pro','deepseek_v4_flash'):
    v=inventory['models'][key]
    q=v['config']['quantization_config'].copy()
    exclusions=q.pop('modules_to_not_convert',[])
    configs.append({'model':key,'repository':v['repository'],'revision':v['revision'],
                    'quantization_config':q,'excluded_module_count':len(exclusions),
                    'excluded_examples':exclusions[:3]})
selected_configs={k:{f:inventory['models'][k][f] for f in ('repository','revision','config')}
                  for k in ('glm53','glm53_flash','deepseek_v4_pro','deepseek_v4_flash')}
(OUT/'official-config-extract.json.gz').write_bytes(gzip.compress(
    (json.dumps(selected_configs,indent=2)+'\n').encode(),mtime=0))
save('sources.json',{'baseline':BASE,'sources':sources,'configs':configs,
     'original_inventory_sha256':sha(inventory_path.read_bytes()),
     'note':'Source evidence only; no new provider or execution qualification.'})

sys.path.insert(0,str(ROOT/'scripts'))
from hyle_perf.nanobench import parse_nanobench, select_pair
aa=[]
for archive,folder in [('graph-vulkan-d5-fragments-interrupted','d5-aa-raw'),
                       ('graph-vulkan-d5-fragments-recovery-preflight','d5-aa-raw'),
                       ('graph-cuda-d5-fragments-p1','d5-cuda-aa-raw')]:
    paths=sorted((ROOT/'evidence/performance'/archive/'run'/folder).glob('*.log.gz'))
    assert len(paths)==8,(archive,len(paths))
    runs=[]
    for p in paths:
        text,digest=read_log(p)
        rows=parse_nanobench(text)
        marginal={t:select_pair(rows,'Graph complete fragment','Direct complete fragment',title=t)[0].operations_per_second /
                    select_pair(rows,'Graph complete fragment','Direct complete fragment',title=t)[1].operations_per_second
                  for t,v in rows if v=='Graph complete fragment'}
        tables={}; title=None
        for line in text.splitlines():
            if not line.startswith('|'):continue
            cols=[s.strip() for s in line.split('|')]
            if cols[1]=='relative':title=cols[-1];tables[title]={}
            if '`Graph complete fragment`' in line or '`Direct complete fragment`' in line:
                name=re.search(r'`([^`]+)`',line)[1]
                tables[title][name]={'relative':float(cols[1].rstrip('%'))/100,
                                     'ci_text':cols[2],'total_seconds_rounded':float(cols[6])}
        paired={t:v['Graph complete fragment']['relative']/v['Direct complete fragment']['relative']
                for t,v in tables.items()}
        arm,order,allocation=p.name.split('.')[0].split('-')
        runs.append({'log':p.relative_to(ROOT).as_posix(),'compressed_sha256':digest,
                     'arm':arm,'order':int(order),'allocation':int(allocation),
                     'marginal_ratio':marginal,'paired_ratio_rounded':paired,'table':tables})
    summaries={}
    for mode in ('marginal_ratio','paired_ratio_rounded'):
        errors=[]
        for arm in ('selected','peer'):
            group=[r for r in runs if r['arm']==arm]
            for title in group[0][mode]:
                values=[r[mode][title] for r in group]
                medians=[statistics.median(values)]
                medians += [statistics.median(r[mode][title] for r in group if r[f]==level)
                            for f in ('order','allocation') for level in (0,1)]
                if any(not 1/1.10<=v<=1.10 for v in values):errors.append(arm+'/'+title+': gross >10%')
                if any(not 1/1.05<=v<=1.05 for v in medians):errors.append(arm+'/'+title+': factor >5%')
        summaries[mode]={'diagnostic_gate':'FAIL' if errors else 'PASS','errors':errors}
    aa.append({'archive':archive,'runs':runs,'summaries':summaries})
save('aa-offline.json',{'baseline':BASE,'note':'Rounded paired table is diagnostic only; cannot recover raw rounds or requalify old runs.', 'archives':aa})

failures=[]
attention_roles={0:{0:'next_raw_history',1:'context_diagnostic',2:'derotated_diagnostic',3:'oa_diagnostic',4:'final_projection'},
4:{0:'next_compressed_cache',1:'next_kv',2:'next_score',3:'next_indexer_cache',4:'next_indexer_kv',5:'next_indexer_score',6:'next_raw_history',7:'compressed_history',8:'indexer_history',9:'indexer_scores_diagnostic',10:'ids_diagnostic',11:'context_diagnostic',12:'derotated_diagnostic',13:'oa_diagnostic',14:'final_projection'},
128:{0:'next_compressed_cache',1:'next_kv',2:'next_score',3:'next_raw_history',4:'compressed_history',5:'context_diagnostic',6:'derotated_diagnostic',7:'oa_diagnostic',8:'final_projection'}}
for entry,output_line,attn_ratio,comp_ratio in [('direct',1384,1415,1427),('graph',1339,1370,1382)]:
    p=ROOT/f'evidence/correctness/llm-moe-d5-real-fragments/vulkan-delivery/raw/precision-current-driver/{entry}.log.gz'
    text,digest=read_log(p); counts=Counter()
    for case in text.split('[ RUN      ] ')[1:]:
        test=case.splitlines()[0]
        for block in case.split('error: The difference between actual[index] and expected[index] is ')[1:]:
            trace={int(n):v for n,v in re.findall(r'd5_qwen35_execution_test\.cc\((\d+)\): ([^\n]+)',block.split('Google Test trace:')[1].split('\n\n')[0])}
            output=int(trace[output_line])
            if 'FullAttentionChain' in test:
                ratio=int(trace[attn_ratio]);model=trace[attn_ratio-3];profile=trace[attn_ratio-2]
                role=attention_roles[ratio][output]
            elif 'StatefulCompression' in test:
                ratio=int(trace[comp_ratio]) if comp_ratio in trace else 'indexer'
                model=trace[comp_ratio-3];profile=trace[comp_ratio-2]
                role={0:'next_compressed_cache',1:'next_kv',2:'next_score'}[output]
            else:raise RuntimeError(test)
            category='diagnostic' if role.endswith('_diagnostic') else ('final' if role=='final_projection' else 'feedback_state')
            counts[(test,model,profile,str(ratio),output,role,category)]+=1
    groups=[dict(zip(('test','model','profile','ratio','output','role','category'),k),assertions=n) for k,n in counts.items()]
    failures.append({'entry':entry,'log':p.relative_to(ROOT).as_posix(),'compressed_sha256':digest,
                     'assertions':sum(counts.values()),'groups':groups})
    assert sum(counts.values())==1368,(entry,sum(counts.values()))
save('vulkan-failure-roles.json',{'baseline':BASE,'note':'Offline assertion classification; no rerun, tolerance change, replay-index inference or whole-profile promotion.', 'entries':failures})
print(json.dumps({'sources':len(sources),'aa_processes':sum(len(a['runs']) for a in aa),
                  'failures':[(v['entry'],v['assertions'],len(v['groups'])) for v in failures]},indent=2))
