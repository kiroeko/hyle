import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

scratch = Path(__file__).resolve().parent
checkout = scratch / 'native-checkout'
baseline = '66897618aeb2b0c043a4904d205f11abf8b5b892'
os.chdir(checkout)
spec = importlib.util.spec_from_file_location('selector', checkout/'scripts/validation-select.py')
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], text=True).strip()
assert git('diff', '--name-only', baseline, 'HEAD') == 'tests/math/CMakeLists.txt'
assert not git('status', '--porcelain')
dry = json.loads((scratch/'native-dry-plan.json').read_text(encoding='utf-8'))
assert dry['selected_factors'] == ['math']
assert {g['id'] for g in dry['selected_gates']} == {'docs','closure','configure','factor:math'}

cl = Path(shutil.which('cl.exe')).resolve()
banner = subprocess.run([str(cl)], capture_output=True).stderr.decode(errors='replace')
version = re.search(r'\b19\.\d+\.\d+(?:\.\d+)?', banner).group(0)
toolset = Path(os.environ['VCToolsInstallDir'])
sdk = Path(os.environ['WindowsSdkDir'])
sdk_version = os.environ['WindowsSDKVersion'].strip('\\/')
include_roots = [toolset/'include', sdk/'Include'/sdk_version/'ucrt']
libraries = [toolset/'lib/x64/msvcprt.lib', toolset/'lib/x64/vcruntime.lib', sdk/'Lib'/sdk_version/'ucrt/x64/ucrt.lib']
compiler_files = [cl.parent/name for name in ('c1xx.dll','c2.dll','link.exe')]
context = {
    'toolchain': {'id':'MSVC '+version, 'compiler_path':str(cl),'compiler_id':'MSVC','compiler_version':version,
        'compiler_sha256':sha(cl), 'compiler_files':{str(p):sha(p) for p in compiler_files},
        'stdlib':{'id':'MSVC STL '+os.environ['VCToolsVersion']+' / UCRT '+sdk_version,
            'files':{str(p):sha(p) for p in libraries},
            'include_roots':{str(p):selector.directory_digest(p) for p in include_roots}},
        'flags':{'CMAKE_CXX_FLAGS':'/DWIN32 /D_WINDOWS /GR /EHsc','CMAKE_CXX_FLAGS_RELEASE':'/O2 /Ob2 /DNDEBUG'},
        'cmake':subprocess.check_output(['cmake','--version'],text=True).splitlines()[0],
        'sdk_version':sdk_version},
    'machine_profile':{'id':'W1-WIN','purpose':'bounded selector native integration; not a performance qualification'}
}
selector.write_json(scratch/'native-context.json',context)
argv = [sys.executable,'scripts/validation-select.py','run','--base',baseline,'--candidate','HEAD',
    '--context',str(scratch/'native-context.json'),'--cache',str(scratch/'native-receipts'),
    '--scratch',str(scratch/'native-build'),'--output',str(scratch/'native-result.json')]
started = time.monotonic()
print('Running actual selector native route: math only; P1 absent',flush=True)
with (scratch/'native-driver.log').open('wb') as stream:
    result = subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT)
assert result.returncode == 0, (result.returncode, str(scratch/'native-driver.log'))
elapsed = time.monotonic()-started
report = json.loads((scratch/'native-result.json').read_text(encoding='utf-8'))
assert report['verdict']=='PASS'
assert {g['id'] for g in report['selected_gates']} == {'docs','closure','configure','factor:math'}
assert all(g['status']=='PASS' for g in report['selected_gates'])
assert next(g for g in report['skipped_gates'] if g['id']=='p1')['status']=='SKIPPED'
builds = list((scratch/'native-build').glob('*/build-*'))
assert len(builds)==1
build=builds[0]
cache={}
for line in (build/'CMakeCache.txt').read_text(encoding='utf-8').splitlines():
    match=re.match(r'([^/#][^:]*):[^=]+=(.*)',line)
    if match: cache[match[1]]=match[2]
assert Path(cache['CMAKE_CXX_COMPILER']).resolve()==cl
assert all(cache[k]==v for k,v in context['toolchain']['flags'].items())
assert cache['HYLE_DEV_FACTORS']=='math'
assert cache['HYLE_BUILD_BENCH']=='OFF'
factor=next(g for g in report['selected_gates'] if g['id']=='factor:math')
receipt=json.loads(Path(factor['receipt']).read_text(encoding='utf-8'))
test_log=(scratch/'native-receipts'/receipt['logs'][1]['path']).read_text(encoding='utf-8')
assert '100% tests passed' in test_log and 'out of 1' in test_log
assert 'hyle_math_test' in test_log
for group in ['selected_gates','skipped_gates']:
    assert all(g['reason'] for g in report[group])
# Read-only second plan proves native reuse without executing a second build/test.
reuse_argv=[sys.executable,'scripts/validation-select.py','plan','--base',baseline,'--candidate','HEAD',
    '--context',str(scratch/'native-context.json'),'--cache',str(scratch/'native-receipts'),
    '--output',str(scratch/'native-reuse-plan.json')]
subprocess.run(reuse_argv,check=True,capture_output=True)
reuse=json.loads((scratch/'native-reuse-plan.json').read_text(encoding='utf-8'))
assert not reuse['selected_gates']
assert {g['id'] for g in reuse['skipped_gates'] if g['status']=='REUSED'}=={'docs','closure','configure','factor:math'}
(scratch/'native-fixture.patch').write_bytes(subprocess.check_output(['git','diff',baseline,'HEAD','--','tests/math/CMakeLists.txt']))
summary={'schema':'hyle.selector-native-integration/v1','tool_candidate':baseline,'fixture_commit':git('rev-parse','HEAD'),
    'fixture_tree':git('rev-parse','HEAD^{tree}'),'scope':'only tests/math/CMakeLists.txt changed; all product files identical',
    'verdict':'PASS','elapsed_seconds':elapsed,'configure_count':1,'build_targets':['hyle_math_tests'],
    'ctest_labels':'^math$ excluding headers','ctest_result':'1/1 PASS','performance_samples':0,'p1_runs':0,
    'context_sha256':sha(scratch/'native-context.json'),'build_directory':str(build),
    'actual_cmake_cache':{k:cache[k] for k in ['CMAKE_CXX_COMPILER','CMAKE_CXX_FLAGS','CMAKE_CXX_FLAGS_RELEASE','HYLE_DEV_FACTORS','HYLE_BUILD_BENCH']},
    'cache_sha256':sha(build/'CMakeCache.txt'),'reuse':'4 gates REUSED in read-only plan; no second build/test'}
selector.write_json(scratch/'native-integration-summary.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
