$ErrorActionPreference = 'Stop'
$installation = 'C:\Program Files\Microsoft Visual Studio\18\Enterprise'
$environmentCommand = 'call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat" -arch=x64 >nul && set'
$environmentLines = & $env:ComSpec /d /s /c $environmentCommand
if ($LASTEXITCODE -ne 0) { throw 'VS environment initialization failed' }
foreach ($line in $environmentLines) {
    $separator = $line.IndexOf('=')
    if ($separator -gt 0) {
        $name = $line.Substring(0, $separator)
        $value = $line.Substring($separator + 1)
        if ($name -ieq 'Path') {
            if ($value -like "*$installation\VC\Tools\MSVC\*") { Set-Item -Path 'Env:Path' -Value $value }
        } else { Set-Item -Path "Env:$name" -Value $value }
    }
}
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
& python -X utf8 "$PSScriptRoot/native-integration.py"
if ($LASTEXITCODE -ne 0) { throw "Native integration failed: $LASTEXITCODE" }
