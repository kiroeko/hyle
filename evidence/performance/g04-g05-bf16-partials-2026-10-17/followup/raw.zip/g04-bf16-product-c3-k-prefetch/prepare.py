from pathlib import Path
import difflib,hashlib,json,shutil

repo=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
base=repo/'.scratch/g04-bf16-partials-vendor/materialized-production-fixed-signatures/include/flashinfer/attention/prefill.cuh'
original=base.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(original)=='c912541502674c9449ad87aa5002219625c815d2ddfb4fb415a223be5fb13ab2'
source=original.decode()
def replace_once(before,after):
    global source
    assert source.count(before)==1,(before[:100],source.count(before))
    source=source.replace(before,after)

anchor='template <bool produce_v, SharedMemFillMode fill_mode, typename KTraits, bool DirectStage = false>\n__device__ __forceinline__ void produce_kv('
helpers='''template <typename KTraits>
constexpr bool hyle_bf16_k_prefetch_scope =
    HyleBf16Partials<typename KTraits::AttentionVariant>::value &&
    KTraits::HYLE_FP8_DIRECT_STAGE && KTraits::MASK_MODE == MaskMode::kCausal &&
    KTraits::CTA_TILE_Q == 64 && KTraits::HEAD_DIM_QK == 256 &&
    KTraits::HEAD_DIM_VO == 256 && KTraits::NUM_MMA_KV == 1 &&
    KTraits::NUM_WARPS_Q == 4 && KTraits::NUM_WARPS_KV == 1 &&
    std::is_same_v<typename KTraits::DTypeQ, __nv_bfloat16> &&
    std::is_same_v<typename KTraits::DTypeO, __nv_bfloat16>;

__device__ __forceinline__ b128_t hyle_prefetch_packed_k_first(const void* source, bool valid) {
  b128_t packed{};
  if (valid) {
    // Keep the packed global read before softmax; conversion and shared stores
    // stay at the original producer site. This adds no synchronization.
    asm volatile("ld.global.v4.u32 {%0,%1,%2,%3}, [%4];"
                 : "=r"(packed.x), "=r"(packed.y), "=r"(packed.z), "=r"(packed.w)
                 : "l"(source) : "memory");
  }
  return packed;
}

template <typename KTraits, typename SmemStorage>
__device__ __forceinline__ void hyle_publish_prefetched_k(
    SmemStorage* storage, typename KTraits::DTypeKV* kv_ptr,
    const size_t* next_offset, uint32_t next_base, uint32_t chunk_size,
    uint32_t warp_idx, uint32_t lane_idx, b128_t packed) {
  static_assert(hyle_bf16_k_prefetch_scope<KTraits>);
  const uint32_t row = warp_idx * 4 + lane_idx / 8;
  const bool valid = next_base + row < chunk_size;
  if (!valid) return;  // Preserve the original K kNoFill behavior.
  smem_t<KTraits::SWIZZLE_MODE_KV> smem(storage->k_smem);
  alignas(16) typename KTraits::DTypeQ converted[16];
  vec_cast<typename KTraits::DTypeQ, typename KTraits::DTypeKV>::template cast<16>(
      converted, reinterpret_cast<typename KTraits::DTypeKV*>(&packed));
  constexpr uint32_t stride = 256 / upcast_size<typename KTraits::DTypeQ>();
  const uint32_t col = lane_idx % 8;
  smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, stride>(row, 2 * col)] =
      *reinterpret_cast<b128_t*>(converted);
  smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, stride>(row, 2 * col + 1)] =
      *reinterpret_cast<b128_t*>(converted + 8);
  // The second packed vector is still read and converted at its original site.
  hyle_load_fp8_native_stage<SharedMemFillMode::kNoFill, KTraits, 256>(
      smem, kv_ptr + next_offset[0] + 128, row, col + 8, valid);
}

'''
replace_once(anchor,helpers+anchor)

# This exact suffix occurs only in the paged main loop, after logits masking.
before='''        // compute m,d states in online softmax
        if constexpr (KTraits::USE_VO_SPLIT) {
          // VO-split: cross-warp consistent m/d + stage P to p_smem; o_scale is the
          // online rescale to apply to o_frag in vosplit_compute_pv below.
          vosplit_softmax_store_p<KTraits>(variant, s_frag, m, d, o_scale, &smem_storage,
                                           get_warp_idx_kv<KTraits>(tid.z),
                                           get_warp_idx_q<KTraits>(tid.y), lane_idx);
        } else {
          update_mdo_states<KTraits>(variant, s_frag, o_frag, m, d);
        }

        block.sync();
        if constexpr (KTraits::USE_KV_SHARED_SMEM) {
          page_produce_kv_on_the_fly<true, KTraits>('''
after='''        [[maybe_unused]] b128_t prefetched_k_first{};
        if constexpr (hyle_bf16_k_prefetch_scope<KTraits>) {
          const uint32_t row = warp_idx * 4 + lane_idx / 8;
          prefetched_k_first = hyle_prefetch_packed_k_first(
              paged_kv.k_data + thr_local_kv_offset_k[0],
              (iter + 1) * CTA_TILE_KV + row < chunk_size);
        }
'''+before
replace_once(before,after)

before='''          page_produce_kv<false, KTraits>(&smem_storage, &k_smem_offset_w, paged_kv.k_data,
                                          (iter + 1) * CTA_TILE_KV, thr_local_kv_offset_k,
                                          chunk_size, warp_idx, lane_idx);
          page_produce_kv_sf<false, KTraits>('''
after='''          if constexpr (hyle_bf16_k_prefetch_scope<KTraits>) {
            hyle_publish_prefetched_k<KTraits>(
                &smem_storage, paged_kv.k_data, thr_local_kv_offset_k,
                (iter + 1) * CTA_TILE_KV, chunk_size, warp_idx, lane_idx, prefetched_k_first);
          } else {
            page_produce_kv<false, KTraits>(&smem_storage, &k_smem_offset_w, paged_kv.k_data,
                                            (iter + 1) * CTA_TILE_KV, thr_local_kv_offset_k,
                                            chunk_size, warp_idx, lane_idx);
          }
          page_produce_kv_sf<false, KTraits>('''
replace_once(before,after)

# Source-only guards: all synchronization and V producer call lines are byte-identical.
import re
for pattern in [r'^.*block\.sync\(\).*$',r'^.*cp_async::.*$',r'^.*page_produce_kv<true, KTraits>.*$',r'^.*page_produce_kv_on_the_fly<.*$',r'^.*page_produce_kv_sf<.*$']:
    assert re.findall(pattern,source,re.M)==re.findall(pattern,original.decode(),re.M),pattern
assert source.count('prefetched_k_first = hyle_prefetch_packed_k_first(')==1
assert source.count('hyle_publish_prefetched_k<KTraits>(')==1
candidate=source.encode()
(out/'prefill.cuh').write_bytes(candidate)
(out/'candidate.patch').write_bytes(''.join(difflib.unified_diff(original.decode().splitlines(True),source.splitlines(True),fromfile='current-product/prefill.cuh',tofile='c3-marker-k-first/prefill.cuh')).encode())
shadow=out/'vendor-shadow'
if not shadow.exists():
    shutil.copytree(base.parents[3],shadow)
(shadow/'include/flashinfer/attention/prefill.cuh').write_bytes(candidate)
base_files={p.relative_to(base.parents[3]).as_posix():sha(p.read_bytes()) for p in base.parents[3].rglob('*') if p.is_file()}
shadow_files={p.relative_to(shadow).as_posix():sha(p.read_bytes()) for p in shadow.rglob('*') if p.is_file()}
assert len(base_files)==2576 and base_files.keys()==shadow_files.keys()
assert [name for name in sorted(base_files) if base_files[name]!=shadow_files[name]]==['include/flashinfer/attention/prefill.cuh']
inventory=''.join(name+'|'+value+'\n' for name,value in sorted(shadow_files.items())).encode()
(out/'shadow-files.json').write_bytes((json.dumps(shadow_files,indent=2)+'\n').encode())
record={'state':'SOURCE_ONLY_SCRATCH_CANDIDATE','canonical_product_modified':False,'cuda_compiled':False,'gpu_executed':False,'base':str(base),'base_sha256':sha(original),'candidate_sha256':sha(candidate),'patch_sha256':sha((out/'candidate.patch').read_bytes()),'gate':'Bf16PartialAttention marker + direct stage + causal + BF16 Q/O + D256 + CTA64 + KV-MMA1 + Q/KV warps4/1; only the paged main loop call sites are changed','prefetch':'First16B packed K per valid thread only; 4 long-lived32bit payload registers across softmax. Second16B stays at original site. Address/predicate/allocator costs require actual codegen; no final register or speed claim.','validity':'same next_base+row<chunk_size as original K producer; no invalid-row global read or shared store; K kNoFill unchanged','unchanged':'V, all barriers/commit/wait, original initial K producer, decoder, layout/swizzle and second vector read; all non-marker/F32 paths remain compile-time original branch','limits':['Not yet compiled or GPU-validated.','The asm volatile memory clobber preserves compiler source ordering but only actual SASS can prove the global load crosses softmax and does not introduce spills or delay the second load.','Read-only loads move earlier; published shared data remains at original site. No fixture length is hard-coded.']}
record['full_shadow']={'path':str(shadow),'files':len(shadow_files),'only_changed_file':'include/flashinfer/attention/prefill.cuh','all_paths_and_raw_hashes_preserved_except_this_file':True,'inventory_sha256':sha(inventory),'inventory_algorithm':'sha256(UTF8 sorted(relative_posix_path + | + raw_file_sha256 + LF))','shadow_files_json_sha256':sha((out/'shadow-files.json').read_bytes())}
(out/'source-plan.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record,indent=2))
