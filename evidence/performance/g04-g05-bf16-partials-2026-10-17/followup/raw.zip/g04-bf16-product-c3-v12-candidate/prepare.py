from pathlib import Path
import copy,difflib,hashlib,json,subprocess,sys,time

repo=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
normalize=lambda b:b.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
folder=repo/'third_party/flashinfer_cache'
old_manifest=(folder/'patches.json').read_bytes()
old_notice=(folder/'NOTICE.md').read_bytes()
old_lock=(repo/'cmake/HyleDependencyLock.json').read_bytes()
assert sha(old_manifest)=='d3a74bb62465b19d5d4e8d47d4ef8e0f6568de0020ed8d52df7b96c37489d6b5'
assert sha(old_notice)=='83131a06ea708e3eeaedeed9791cbcfc3ae78d3cef1d4e0f927f147f4346bb84'
manifest=json.loads(old_manifest);lock=json.loads(old_lock)
dep=next(x for x in lock['dependencies'] if x['name']=='flashinfer_cache_patches')
assert dep['version']=='hyle-flashinfer-bf16-partials-v11'
assert dep['vendored']['tree_sha256']=='30c9130520cc8677b3268d2f7f1fd0caa7fe8e78683c920a1be058057be47cc0'
before_dep=copy.deepcopy(dep)

# Obtain the three exact string edits from the source-only candidate generator,
# before its filesystem output section. No product file is written.
c3_script=repo/'.scratch/g04-bf16-product-c3-k-prefetch/prepare.py'
text=c3_script.read_text().split('# Source-only guards:')[0]
text=text.replace('source=source.replace(before,after)',"edits.append({'before':before,'after':after});source=source.replace(before,after)")
env={'__file__':str(c3_script),'edits':[]};exec(compile(text,str(c3_script),'exec'),env)
edits=env['edits'];assert len(edits)==3
prefill=next(x for x in manifest['files'] if x['path']=='include/flashinfer/attention/prefill.cuh')
old_edits=copy.deepcopy(prefill['edits'])
assert prefill['after_sha256']=='c912541502674c9449ad87aa5002219625c815d2ddfb4fb415a223be5fb13ab2'
prefill['edits'].extend(edits)
prefill['after_sha256']='0642c9cf50794d265aa7281ede8a951174177260bf441dd0e0ac86d2922e7187'
manifest['scope']+='; private marker-gated causal D256 CTA64 first-vector K prefetch before softmax, retaining original decoder/shared publication site, second K vector, V and synchronization'
assert prefill['edits'][:-3]==old_edits
new_manifest=(json.dumps(manifest,indent=2)+'\n').encode()

before=b'remain unchanged; this does not include the unadopted K-load or overlap experiments.'
after=b'remain unchanged. The finite first-vector K prefetch described below is separate\nfrom other unadopted K-load and V-overlap experiments.'
assert old_notice.count(before)==1
notice=old_notice.replace(before,after)+b'''
The private BF16-partial marker additionally permits a first packed K vector
to be read before softmax in the causal paged D256 CTA64, MMA_KV1, Q/KV-warps4/1
direct-stage specialization with BF16 Q/output. Each valid thread retains
one16-byte packed vector; the original decoder and native16 shared stores
remain at the original producer site, as does the second packed vector read.
The original next-tile validity guard and K no-fill behavior are retained.
V producers, all CTA/warp barriers and async commit/wait sites stay unchanged.
No fixture length is fixed, no additional resident cache is expanded, and
other marker/type/geometry specializations keep their original producer.
This source scheduling change alone makes no throughput claim.
'''
license=(folder/'LICENSE').read_bytes()
notice_sha=sha(normalize(notice))
tree=sha(''.join(n+'|'+sha(normalize(b))+'\n' for n,b in sorted({'LICENSE':license,'NOTICE.md':notice,'patches.json':new_manifest}.items())).encode())
dep['version']='hyle-flashinfer-bf16-partials-v12'
dep['vendored']['tree_sha256']=tree
for item in dep['license']['files']:
    if item['path']=='third_party/flashinfer_cache/NOTICE.md':item['sha256']=notice_sha
new_lock=old_lock
for old,new in [(before_dep['version'],dep['version']),(before_dep['vendored']['tree_sha256'],tree),(sha(normalize(old_notice)),notice_sha)]:
    assert new_lock.count(old.encode())==1
    new_lock=new_lock.replace(old.encode(),new.encode(),1)
assert json.loads(new_lock)==lock
assert before_dep['revision']==dep['revision'] and before_dep['archive']==dep['archive'] and before_dep['git_tree']==dep['git_tree']
for relative,data in [('third_party/flashinfer_cache/patches.json',new_manifest),('third_party/flashinfer_cache/NOTICE.md',notice),('third_party/flashinfer_cache/LICENSE',license),('cmake/HyleDependencyLock.json',new_lock)]:
    path=out/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
for relative,before_bytes,after_bytes in [('third_party/flashinfer_cache/patches.json',old_manifest,new_manifest),('third_party/flashinfer_cache/NOTICE.md',old_notice,notice),('cmake/HyleDependencyLock.json',old_lock,new_lock)]:
    (out/(Path(relative).name+'.diff')).write_bytes(''.join(difflib.unified_diff(before_bytes.decode().splitlines(True),after_bytes.decode().splitlines(True),fromfile='v11/'+relative,tofile='candidate-v12/'+relative)).encode())

cmd=[sys.executable,str(repo/'src/compute_ggml_runtime/prepare_source.py'),'--source',str(repo/'.scratch/g04-bf16-partials-vendor/upstream'),'--output',str(out/'materialized'),'--manifest',str(out/'third_party/flashinfer_cache/patches.json')]
t=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True)
(out/'materialize.log').write_bytes((p.stdout+p.stderr).encode())
assert p.returncode==0,(p.stdout,p.stderr)
files={f.relative_to(out/'materialized').as_posix():sha(f.read_bytes()) for f in (out/'materialized').rglob('*') if f.is_file()}
shadow=json.loads((repo/'.scratch/g04-bf16-product-c3-k-prefetch/shadow-files.json').read_text())
assert files==shadow,'Materialization differs from actual C3 compile shadow'
inventory=sha(''.join(n+'|'+v+'\n' for n,v in sorted(files.items())).encode())
assert inventory=='83908762faa70e89539ffcfe0e0f1bf5bca2c7d7cf06c306b330b220b8f6f8f0'
assert (folder/'patches.json').read_bytes()==old_manifest and (folder/'NOTICE.md').read_bytes()==old_notice and (repo/'cmake/HyleDependencyLock.json').read_bytes()==old_lock
record={'status':'UNADOPTED_SCRATCH_V12_CANDIDATE_ONLY','canonical_modified':False,'cuda_compiled_by_this_preparation':False,'gpu_executed':False,'adoption':'Only after actual C3 math/device/resource and ALLTAIL performance results; this preparation is not adoption.','base':{'manifest_sha256':sha(old_manifest),'notice_sha256':sha(old_notice),'lock_sha256':sha(old_lock),'vendor_metadata_tree_sha256':before_dep['vendored']['tree_sha256']},'candidate':{'version':dep['version'],'manifest_sha256':sha(new_manifest),'notice_sha256':sha(notice),'lock_sha256':sha(new_lock),'vendor_metadata_tree_sha256':tree,'prefill_sha256':prefill['after_sha256'],'appended_prefill_replace_rules':3},'upstream_unchanged':{'revision':dep['revision'],'archive':dep['archive'],'git_tree':dep['git_tree']},'materialization':{'argv':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'stdout':p.stdout,'files':len(files),'complete_raw_file_hashes_equal_C3_shadow':True,'full_materialized_inventory_sha256':inventory,'inventory_algorithm':'sha256(UTF8 sorted(relative_posix_path + | + raw_file_sha256 + LF)); this full-source inventory is separate from the three-file vendor metadata tree pin.'},'scope':'Exact three C3 K-first string replacements appended after all old v11 edits; cascade/scheduler unchanged; native C2 false/false variant is a separate canonical product-source change, not included in vendor controls.'}
(out/'candidate.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record,indent=2))
