"""Host TU compilation or final link only. No GPU or CUDA compilation."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,time

repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/g04-bf16-c2-c3'
work=Path('/root/hyle-scratch/compute-unified/g04-bf16-c2-c3');work.mkdir(exist_ok=True)
old=Path('/root/hyle-scratch/compute-unified/g04-bf16-product-bench')
(work/'consumer.cc').write_bytes((out/'consumer.cc').read_bytes())
commands=json.loads((repo/'.scratch/g04-bf16-product-bench/commands.json').read_text())
for stage,argv in commands.items():
    commands[stage]=[str(work/'consumer.cc') if a==str(old/'consumer.cc') else str(work/'consumer.o') if a==str(old/'consumer.o') else str(work/'product_c2_c3') if a==str(old/'product_bench') else '-Wl,-Map='+str(work/'link.map') if a=='-Wl,-Map='+str(old/'link.map') else a for a in argv]
original=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build/bin/libhyle_compute_provider_flashinfer.a')
index=commands['link'].index(str(original))
clones=[work/arm/name for arm in ('c2','c3') for name in ('provider.o','batch.o','cache.o')]
commands['link'][index:index]=[str(p) for p in clones]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
stage='compile' if '--compile-only' in sys.argv else 'link'
if stage=='link':
    isolation=json.loads((out/'isolation-identity.json').read_text())
    assert hashlib.sha256((out/'consumer.cc').read_bytes()).hexdigest()==isolation['source_sha256']
    for arm in isolation['arms'].values():
        for obj in arm['objects']:assert hashlib.sha256(Path(obj['clone']).read_bytes()).hexdigest()==obj['clone_sha256']
start=time.monotonic()
with (out/(stage+'.log')).open('w') as f:p=subprocess.run(commands[stage],stdout=f,stderr=subprocess.STDOUT)
record={'stage':stage,'elapsed_s':time.monotonic()-start,'returncode':p.returncode,
        'source_sha256':hashlib.sha256((out/'consumer.cc').read_bytes()).hexdigest(),'GPU_executed':False,'CUDA_recompiled':False}
if stage=='link' and p.returncode==0:
    linkmap=(work/'link.map').read_text()
    taken=[name for name in ('flashinfer_provider.cc.o','native_batch.cu.o','native_cache.cu.o') if re.search(re.escape(str(original)+'('+name+')'),linkmap)]
    assert taken==[],taken
    (out/'link.map').write_text(linkmap)
    record['original_FI_three_members_extracted']=taken
    record['binary']=str(work/'product_c2_c3');record['binary_sha256']=hashlib.sha256((work/'product_c2_c3').read_bytes()).hexdigest()
(out/('build-'+stage+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
raise SystemExit(p.returncode)
