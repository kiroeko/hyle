from pathlib import Path
import collections,difflib,hashlib,json,re,subprocess,time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
OUT=ROOT/'.scratch/g04-bf16-c2-codegen';OUT.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
binding_path=ROOT/'.scratch/g04-bf16-c2/archive-result.json'
binding=json.loads(binding_path.read_text());assert binding['compile_returncode']==0
obj=Path(binding['object']);archive=Path(binding['C2_archive'])
assert sha(obj.read_bytes())==binding['object_sha256']
assert sha(archive.read_bytes())==binding['C2_archive_sha256']
assert sha(subprocess.check_output(['ar','p',str(archive),'native_cache.cu.o']))==binding['object_sha256']
refpath=ROOT/'.scratch/g04-bf16-product-codegen/review.json'
ref=json.loads(refpath.read_text())
assert sha(Path(binding['C1_archive']).read_bytes())==binding['C1_archive_sha256']==ref['product_archive_sha256']
assert ref['artifacts']['product']['object_sha256']==binding['members_before']['native_cache.cu.o']
trait='MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1E'
# Reuse the retained exact-symbol and full128-bit parser definitions only.
parser_path=ROOT/'.scratch/g04-bf16-product-codegen/review_wsl.py'
parser=parser_path.read_text();start=parser.index('def symbols(');end=parser.index("record={'state':")
exec(compile(parser[start:end],str(parser_path),'exec'))
current=dump('c2',obj,True)
record={'scope':'Read-only C2 versus retained C1 SM89 codegen; no CUDA compilation or GPU execution','gpu_executed':False,'recompiled':False,'binding':str(binding_path),'binding_sha256':sha(binding_path.read_bytes()),'C1_reference':str(refpath),'C1_reference_sha256':sha(refpath.read_bytes()),'parser_sha256':sha(parser_path.read_bytes()),'current':current,'comparisons':[]}
for kind,b in current['kernels'].items():
    a=ref['artifacts']['product']['kernels'][kind]
    row={'kind':kind,'C1':a,'C2':b,'instructions_equal':a['normalized_sha256']==b['normalized_sha256'],'encoded_schedule_words_equal':a['codewords_sha256']==b['codewords_sha256'],'resource_equal':a['resource']==b['resource']}
    for suffix in ['instructions','codewords']:
        before=(ROOT/f'.scratch/g04-bf16-product-codegen/product-{kind}-{suffix}.txt').read_text()
        expected=a['normalized_sha256'] if suffix=='instructions' else a['codewords_sha256']
        assert sha(before.encode())==expected
        after=(OUT/f'c2-{kind}-{suffix}.txt').read_text()
        (OUT/f'C1-vs-C2-{kind}-{suffix}.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='C1',tofile='C2')))
    record['comparisons'].append(row)
sass=(OUT/'c2-sass.txt').read_text()
chunks={piece.splitlines()[0]:piece for piece in re.split(r'\s*Function : ',sass)[1:]}
rows={kind:[{'pc':m[1],'sass':m[2].strip()} for m in re.finditer(r'/\*([0-9a-fA-F]+)\*/\s+(.+?;)',chunks[name])] for kind,name in current['symbols'].items()}
(OUT/'c2-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
key='bf16-prefill';selected=rows[key]
types=['LDG.E.128','PRMT','HFMA2.BF16_V2','LDGSTS','DEPBAR.LE','BAR.SYNC','MUFU.EX2','HMMA.16816.F32.BF16','ISETP.LT.U32.OR']
record['BF16_chain_PCs']={op:[row['pc'] for row in selected if op in row['sass']] for op in types}
assert not record['BF16_chain_PCs']['ISETP.LT.U32.OR']
record['window_eight_comparisons_removed']=True
record['limits']=['Static SHARED:0 is not the dynamic launch shared-memory amount.','Removing source mask can change register allocation and scheduling; differences are preserved, not labeled equivalent codegen.','No performance or numerical result follows solely from static codegen.']
(OUT/'review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'comparisons':[{k:r[k] for k in ['kind','instructions_equal','encoded_schedule_words_equal','resource_equal']} for r in record['comparisons']],'resources':{k:{s:v[s] for s in ['instruction_count','resource','normalized_sha256']} for k,v in current['kernels'].items()},'BF16_chain_PCs':record['BF16_chain_PCs']},indent=2))
