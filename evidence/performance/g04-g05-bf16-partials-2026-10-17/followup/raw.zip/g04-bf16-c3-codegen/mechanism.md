# C3 actual SM89 codegen versus C2

This analysis reads the actual C3 archive member and object, without CUDA compilation or GPU execution. `review.json` binds the C3 object/archive, the retained C2 object and the complete raw disassemblies/differences. Only the exact selected causal D256 CTA64/KV-MMA1 kernels and their merge specializations are compared; it is not an all-kernel performance claim.

* Target BF16 prefill: registers246→250, STACK0, LOCAL0, static SASS rows2032→2024. No spill or stack growth is visible in this selected kernel's resource report.
* The first next-K packed read is now `3020: @!P1 LDG.E.128 R52, [R58.64]`. It precedes the softmax EX2 range3120..3510, and the first conversion use is `3b10: PRMT R52, R52, ...`. This directly confirms the intended raw-register lifetime across softmax.
* The second K read is `3b00: LDG.E.128 R56, [R58.64+0x80]`, behind the original post-softmax barrier at3ae0 and guarded by the branch at3af0. It has not moved later: the compiler now issues it before the first vector's decode instead of between vector decoders. Thus source changes only first-vector prefetch, but actual scheduling also improves the second read's overlap with decoding; this must not be described as an identical second-load instruction schedule.
* K publication is still followed by the original synchronization structure; the consumer barrier is4220 before subsequent PV.
* Both V reads remain ahead of PV: `43f0: @!P1 LDG.E.128 R52,[R246.64]` and `4420: @!P1 LDG.E.128 R60,[R246.64+0x80]`, with PV HMMA44d0..4770. The V path has not regressed into a post-PV load in this generated code.
* The selected default F32 D256 prefill and both merge kernels are exactly equal to C2 in every retained128-bit instruction/control word, not just operation counts or source text.

The C3 source adds no shared storage or launch-geometry changes: the same SharedStorage type and128-thread CTA therefore retain the49152-byte dynamic allocation observed for C1/C2. `cuobjdump`'s static SHARED0 does not measure that dynamic amount. Even budgeting256 registers per thread gives256×128=32768 registers/CTA and65536 for two CTAs; two49152-byte shared allocations total98304 bytes. This is a capacity calculation, not an observed occupancy, allocation-granularity or active-warp result. No native occupancy API is called by this analysis; the runner owns actual cold device attributes and runtime geometry.

Static mechanism and resource checks do not establish numerical correctness or a performance win. Adoption remains dependent on the runner's current-product math/device tests and unprofiled ALLTAIL measurements. All CPU-heavy disassembly work finished before the runner's ordinary timing window.
