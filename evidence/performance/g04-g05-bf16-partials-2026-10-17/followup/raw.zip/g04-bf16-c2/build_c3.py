from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

REPO = Path('/mnt/c/public/project-hyle/hyle')
CANDIDATE = REPO / '.scratch/g04-bf16-product-c3-k-prefetch'
OUT = REPO / '.scratch/g04-bf16-c3'
WORK = Path('/root/hyle-scratch/compute-unified/g04-bf16-c3')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    OUT.mkdir(exist_ok=False)
    WORK.mkdir(exist_ok=False)
    expected = json.loads((CANDIDATE / 'shadow-files.json').read_text())
    plan = json.loads((CANDIDATE / 'source-plan.json').read_text())
    shadow = WORK / 'vendor-shadow'
    start_copy = time.monotonic()
    shutil.copytree(CANDIDATE / 'vendor-shadow', shadow)
    actual = {p.relative_to(shadow).as_posix(): sha(p.read_bytes()) for p in shadow.rglob('*') if p.is_file()}
    assert actual == expected and len(actual) == 2576
    inventory = ''.join(name + '|' + actual[name] + '\n' for name in sorted(actual))
    assert sha(inventory.encode()) == plan['full_shadow']['inventory_sha256']
    header = shadow / 'include/flashinfer/attention/prefill.cuh'
    assert sha(header.read_bytes()) == '0642c9cf50794d265aa7281ede8a951174177260bf441dd0e0ac86d2922e7187'
    source = (REPO / 'src/compute_provider_flashinfer/native_cache.cu').read_bytes()
    assert sha(source) == '8095820397cef116e4ecbc7dae4d6dedb28910000784e267703c88482767295b'
    (WORK / 'native_cache.cu').write_bytes(source)
    (OUT / 'native_cache.cu').write_bytes(source)
    c2 = json.loads((REPO / '.scratch/g04-bf16-c2/identity.json').read_text())
    argv = [arg.replace('/root/hyle-scratch/compute-unified/g04-bf16-c2/', str(WORK) + '/') for arg in c2['argv']]
    old_include = '-I/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build/src/compute_provider_flashinfer/cache-source-30c9130520cc8677b3268d2f7f1fd0caa7fe8e78683c920a1be058057be47cc0/include'
    assert argv.count(old_include) == 1
    argv[argv.index(old_include)] = '-I' + str(shadow / 'include')
    result = {'argv': argv, 'cwd': c2['cwd'], 'C1_baseline_commit': c2['baseline_commit'],
              'source_sha256': sha(source), 'C3_header_sha256': sha(header.read_bytes()),
              'vendor_shadow': str(shadow), 'vendor_inventory_sha256': sha(inventory.encode()),
              'vendor_files': len(actual), 'copy_and_hash_elapsed_s': time.monotonic() - start_copy,
              'only_source_change_from_C2': 'first 16B raw K prefetch in finite BF16 marker domain, via independent shadow prefill header',
              'canonical_vendor_lock_modified': False, 'started_unix': time.time()}
    (OUT / 'identity.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    with (OUT / 'compile.stdout.log').open('w') as stdout, (OUT / 'compile.stderr.log').open('w') as stderr:
        compiled = subprocess.run(argv, cwd=c2['cwd'], stdout=stdout, stderr=stderr)
    result.update({'compile_returncode': compiled.returncode, 'compile_elapsed_s': time.time() - result['started_unix']})
    (OUT / 'compile-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'compile_returncode': compiled.returncode, 'compile_elapsed_s': result['compile_elapsed_s']}), flush=True)
    if compiled.returncode:
        raise SystemExit(compiled.returncode)
    c2_ready = json.loads((REPO / '.scratch/g04-bf16-c2/archive-result.json').read_text())
    base = Path(c2_ready['C2_archive'])
    assert sha(base.read_bytes()) == c2_ready['C2_archive_sha256']
    obj = WORK / 'native_cache.cu.o'
    names = subprocess.check_output(['ar', 't', str(base)], text=True).splitlines()
    assert names.count(obj.name) == 1
    before = {name: sha(subprocess.check_output(['ar', 'p', str(base), name])) for name in names}
    archive = WORK / 'libhyle_compute_provider_flashinfer_c3.a'
    shutil.copyfile(base, archive)
    subprocess.run(['ar', 'r', str(archive), str(obj)], check=True)
    subprocess.run(['ranlib', str(archive)], check=True)
    assert subprocess.check_output(['ar', 't', str(archive)], text=True).splitlines() == names
    after = {name: sha(subprocess.check_output(['ar', 'p', str(archive), name])) for name in names}
    assert after[obj.name] == sha(obj.read_bytes())
    assert all(before[name] == after[name] for name in names if name != obj.name)
    assert sha(base.read_bytes()) == c2_ready['C2_archive_sha256']
    result.update({'C2_archive': str(base), 'C2_archive_sha256': c2_ready['C2_archive_sha256'],
                   'C3_archive': str(archive), 'C3_archive_sha256': sha(archive.read_bytes()),
                   'object': str(obj), 'object_sha256': sha(obj.read_bytes()),
                   'members_before': before, 'members_after': after, 'C2_unchanged': True})
    (OUT / 'archive-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'C3_archive': str(archive), 'C3_archive_sha256': result['C3_archive_sha256'], 'C2_unchanged': True}), flush=True)

if __name__ == '__main__':
    main()
