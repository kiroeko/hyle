from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-bf16-c2')
WORK = Path('/root/hyle-scratch/compute-unified/g04-bf16-c2')
SANITIZER = '/usr/local/cuda-13.3/bin/compute-sanitizer'

def main():
    mode = sys.argv[1]
    name = {'public': 'public', 'native-test': 'native-test', 'memcheck': 'public',
            'synccheck': 'public', 'feature-memcheck': 'native-test',
            'precision': 'precision', 'f32-bench': 'f32-bench', 'peer-bench': 'peer-bench'}[mode]
    links = json.loads((OUT / 'consumer-links.json').read_text())
    built = json.loads((OUT / 'archive-result.json').read_text())
    assert links[name]['returncode'] == 0
    binary = WORK / 'validation' / name / 'consumer'
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == links[name]['binary_sha256']
    argv = [str(binary)]
    if mode == 'native-test':
        argv += ['--gtest_filter=FlashinferCache.*:FlashinferCacheEncode.*:FlashinferBatchReplay.*']
    elif mode in ('memcheck', 'synccheck', 'feature-memcheck'):
        argv = [SANITIZER, '--tool', 'synccheck' if mode == 'synccheck' else 'memcheck', '--error-exitcode', '86'] + argv
        if mode == 'feature-memcheck':
            argv += ['--gtest_filter=FlashinferCache.OptInBfloat16PartialsAgainstFeatureOracle']
    env = os.environ.copy()
    assert not env.get('G04_TRACE'), 'ordinary C2 runs must have no tracing enabled'
    dest = OUT / ('run-' + mode + '-1')
    dest.mkdir(exist_ok=False)
    gpu = subprocess.run(['/usr/lib/wsl/lib/nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.used,temperature.gpu', '--format=csv,noheader'], capture_output=True, text=True)
    identity = {'argv': argv, 'C1_baseline_commit': built['baseline_commit'],
                'C2_source_sha256': built['C2_source_sha256'], 'C2_archive_sha256': built['C2_archive_sha256'],
                'C1_archive_unchanged': built['C1_unchanged'], 'binary_sha256': links[name]['binary_sha256'],
                'C1_unchanged_host_objects': {a: hashlib.sha256(Path(a).read_bytes()).hexdigest() for a in links[name]['argv'] if a.endswith('.o')},
                'gpu_pre': {'returncode': gpu.returncode, 'stdout': gpu.stdout, 'stderr': gpu.stderr},
                'started_unix': time.time()}
    (dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps({'mode': mode, 'argv': argv, 'binary_sha256': identity['binary_sha256']}), flush=True)
    with (dest / 'stdout.log').open('w') as stdout, (dest / 'stderr.log').open('w') as stderr:
        r = subprocess.run(argv, env=env, stdout=stdout, stderr=stderr)
    identity.update({'returncode': r.returncode, 'elapsed_s': time.time() - identity['started_unix']})
    (dest / 'result.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps({'mode': mode, 'returncode': r.returncode, 'elapsed_s': identity['elapsed_s']}), flush=True)
    raise SystemExit(r.returncode)

if __name__ == '__main__':
    main()
