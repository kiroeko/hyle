from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

REPO = Path('/mnt/c/public/project-hyle/hyle')
OUT = REPO / '.scratch/g04-bf16-c2'
WORK = Path('/root/hyle-scratch/compute-unified/g04-bf16-c2')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    plan = json.loads((OUT / 'compile-sm89-plan.json').read_text())
    assert plan['status'] == 'PREPARED_ONLY_NOT_EXECUTED'
    old = (OUT / 'C1-native_cache.cu').read_bytes()
    assert sha(old) == plan['C1_source_sha256']
    before = b'struct Bf16PartialAttention:fi::DefaultAttention<false,true,false,false> {\n  using Base=fi::DefaultAttention<false,true,false,false>;'
    after = before.replace(b'<false,true,false,false>', b'<false,false,false,false>')
    assert old.count(before) == 1
    source = (REPO / 'src/compute_provider_flashinfer/native_cache.cu').read_bytes()
    assert source == old.replace(before, after)
    archive = Path(plan['C1_archive'])
    assert sha(archive.read_bytes()) == 'de8dbd313b03b4c4b40707976f0a8c77221ad0b144794103d8362a748042ff43'
    WORK.mkdir(exist_ok=False)
    (WORK / 'native_cache.cu').write_bytes(source)
    (OUT / 'native_cache.cu').write_bytes(source)
    result = {'argv': plan['argv'], 'cwd': plan['cwd'], 'baseline_commit': '6336e9ffc80bcec28ae4d0d8631e58237d80dd5a',
              'C1_source_sha256': sha(old), 'C2_source_sha256': sha(source),
              'C1_archive': str(archive), 'C1_archive_sha256': sha(archive.read_bytes()),
              'only_source_change': 'Bf16PartialAttention inheritance and Base alias use_sliding_window true -> false; original default Variant unchanged',
              'started_unix': time.time()}
    (OUT / 'identity.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    with (OUT / 'compile.stdout.log').open('w') as stdout, (OUT / 'compile.stderr.log').open('w') as stderr:
        completed = subprocess.run(plan['argv'], cwd=plan['cwd'], stdout=stdout, stderr=stderr)
    result.update({'compile_returncode': completed.returncode, 'compile_elapsed_s': time.time() - result['started_unix']})
    (OUT / 'compile-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'compile_returncode': completed.returncode, 'compile_elapsed_s': result['compile_elapsed_s']}), flush=True)
    if completed.returncode:
        raise SystemExit(completed.returncode)
    obj = WORK / 'native_cache.cu.o'
    names = subprocess.check_output(['ar', 't', str(archive)], text=True).splitlines()
    assert names.count(obj.name) == 1
    before_members = {name: sha(subprocess.check_output(['ar', 'p', str(archive), name])) for name in names}
    candidate = Path(plan['output_archive'])
    assert not candidate.exists()
    shutil.copyfile(archive, candidate)
    subprocess.run(['ar', 'r', str(candidate), str(obj)], check=True)
    subprocess.run(['ranlib', str(candidate)], check=True)
    assert subprocess.check_output(['ar', 't', str(candidate)], text=True).splitlines() == names
    after_members = {name: sha(subprocess.check_output(['ar', 'p', str(candidate), name])) for name in names}
    assert after_members[obj.name] == sha(obj.read_bytes())
    assert all(before_members[name] == after_members[name] for name in names if name != obj.name)
    assert sha(archive.read_bytes()) == result['C1_archive_sha256']
    result.update({'object': str(obj), 'object_sha256': sha(obj.read_bytes()), 'C2_archive': str(candidate),
                   'C2_archive_sha256': sha(candidate.read_bytes()), 'members_before': before_members,
                   'members_after': after_members, 'C1_unchanged': True})
    (OUT / 'archive-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'C2_archive': str(candidate), 'C2_archive_sha256': result['C2_archive_sha256'], 'C1_unchanged': True}), flush=True)

if __name__ == '__main__':
    main()
