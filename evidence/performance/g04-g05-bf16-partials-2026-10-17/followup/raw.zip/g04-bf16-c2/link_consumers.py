from pathlib import Path
import hashlib
import json
import subprocess
import time

REPO = Path('/mnt/c/public/project-hyle/hyle')
OUT = REPO / '.scratch/g04-bf16-c2'
WORK = Path('/root/hyle-scratch/compute-unified/g04-bf16-c2')
C1_ARCHIVE = '/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build/bin/libhyle_compute_provider_flashinfer.a'
TARGETS = {
    'public': 'g04-bf16-product/consumer-commands.json',
    'native-test': 'g04-bf16-product/native-test-commands.json',
    'precision': 'g04-bf16-product-precision/commands.json',
    'f32-bench': 'g04-bf16-product-bench/commands.json',
    'peer-bench': 'g04-bf16-product-peer-bench/commands.json',
    'peer-trace': 'g04-bf16-product-peer-trace/commands.json',
}

def main():
    built = json.loads((OUT / 'archive-result.json').read_text())
    assert built['compile_returncode'] == 0 and built['C1_unchanged']
    candidate = built['C2_archive']
    results = {}
    for name, command_path in TARGETS.items():
        original = json.loads((REPO / '.scratch' / command_path).read_text())['link']
        assert original.count(C1_ARCHIVE) == 1, (name, original.count(C1_ARCHIVE))
        directory = WORK / 'validation' / name
        directory.mkdir(parents=True, exist_ok=False)
        argv = [candidate if arg == C1_ARCHIVE else arg for arg in original]
        argv[argv.index('-o') + 1] = str(directory / 'consumer')
        argv = ['-Wl,-Map=' + str(directory / 'link.map') if arg.startswith('-Wl,-Map=') else arg for arg in argv]
        start = time.time()
        with (OUT / (name + '-link.log')).open('w') as log:
            r = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT)
        item = {'C1_link_command_file': command_path, 'C1_argv': original, 'argv': argv,
                'elapsed_s': time.time() - start, 'returncode': r.returncode,
                'only_link_changes': 'FI archive path, output executable path, output linker map path; identical C1 host objects and remaining libraries'}
        results[name] = item
        if r.returncode == 0:
            item['binary_sha256'] = hashlib.sha256((directory / 'consumer').read_bytes()).hexdigest()
        (OUT / 'consumer-links.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps({'name': name, 'elapsed_s': item['elapsed_s'], 'returncode': r.returncode,
                          'binary_sha256': item.get('binary_sha256')}), flush=True)
        if r.returncode:
            raise SystemExit(r.returncode)

if __name__ == '__main__':
    main()
