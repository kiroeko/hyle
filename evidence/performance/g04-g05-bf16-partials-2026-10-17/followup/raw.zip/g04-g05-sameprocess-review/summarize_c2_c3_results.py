"""Independent retained C2/C3 result summaries, without new measurements."""
from pathlib import Path
import csv,hashlib,json
from summarize_new_product_results import paired_block_interval

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    pooled=[];matrix=[];bindings=[]
    for name,label,folder in [('product-c1-c2-analysis','C1optin -> C2optin','g04-bf16-c1-c2/run-ordinary-1'),
                              ('product-c2-c3-analysis','C2optin -> C3optin','g04-bf16-c2-c3/run-ordinary-1'),
                              ('product-c3-peer-analysis','same-source plain BF16 peer -> C3optin','g04-bf16-c3/run-peer-bench-1')]:
        data=json.loads((HERE/(name+'.json')).read_text())
        for mode in data['capture_modes']:
            assert len(mode['strata'])==4
            summary=paired_block_interval(mode['strata'])
            pooled.append({'comparison':label,'capture':mode['capture'],**summary})
            for r in mode['strata']:
                matrix.append({'comparison':label,'capture':mode['capture'],
                               'allocation_order':r['allocation_order'],'execution_order':r['execution_order'],
                               'control_mean_us':r['control']['arithmetic_mean_us'],'treatment_mean_us':r['treatment']['arithmetic_mean_us'],
                               'latency_change_percent':r['latency_change_percent'],
                               'control_p99_us':r['control']['p99_us'],'treatment_p99_us':r['treatment']['p99_us'],
                               'control_max_us':r['control']['max_us'],'treatment_max_us':r['treatment']['max_us'],
                               'treatment_faster_blocks':r['block_treatment_faster'],'blocks':32,'complete_pairs':4096})
        run=ROOT/'.scratch'/folder;result=json.loads((run/'result.json').read_text());assert result['returncode']==0
        bindings.append({'run':folder,'identity':result,'stdout_sha256':sha(run/'stdout.log'),'stderr_sha256':sha(run/'stderr.log'),
                         'analysis_sha256':sha(HERE/(name+'.json'))})
    precision_c1=json.loads((HERE/'product-precision-review.json').read_text())
    precision_c2=json.loads((HERE/'product-c2-precision-review.json').read_text())
    precision_c3=json.loads((HERE/'product-c3-precision-review.json').read_text())
    assert precision_c1['rows']==precision_c2['rows']==precision_c3['rows']
    assert precision_c1['peer_all_words_checks']==precision_c2['peer_all_words_checks']==precision_c3['peer_all_words_checks']
    tests={}
    for name in ('public','native-test','precision','memcheck','synccheck','feature-memcheck'):
        result=json.loads((ROOT/'.scratch/g04-bf16-c3'/('run-'+name+'-1')/'result.json').read_text())
        assert result['returncode']==0 and result['C3_archive_sha256']=='74cff382522bc01ffaf185531a48dd7c7f5f7e1e3efda1c11599937797c9616c'
        assert result['C3_source_sha256']=='8095820397cef116e4ecbc7dae4d6dedb28910000784e267703c88482767295b'
        assert result['C3_header_sha256']=='0642c9cf50794d265aa7281ede8a951174177260bf441dd0e0ac86d2922e7187'
        tests[name]=result
    attrs=json.loads((HERE/'product-c2-c3-analysis.json').read_text())['cold_actual_hoststub_attributes']
    assert attrs['c2_registers']=='246' and attrs['c3_registers']=='250'
    result={'kind':'INDEPENDENT_C2_C3_FIXED_ORDINARY_AND_SEMANTICS_SUMMARY','pooled_all_tail_means':pooled,
            'all_matrices':matrix,'bindings':bindings,
            'C3_six_semantic_runs':tests,'C3_24_precision_rows_exactly_equal_C1_C2':True,
            'C3_eight_all_word_peer_parity_checks_exactly_equal_C1_C2':True,
            'actual_C2_C3_hoststub_attributes_match_static_codegen':attrs,
            'limits':['Each 128-block interval is descriptive and assumes adjacent blocks independent; no process-to-process/systematic confidence is established.',
                      'Compare only within the retained paired process/mode. Do not chain C1/C2 and C2/C3 ratios or compare absolute means across the three different processes.',
                      'All 32768 pairs per experiment and all tails retained, no negative-control subtraction, cold/setup outside warm primary.',
                      'C3 remains an unadopted scratch candidate in these results; source preparation, successful compilation, correctness and static overlap do not establish a stable public episode improvement.',
                      'Peer is the same-source FlashInfer plain BF16 native path, not an external inference engine.'],
            'conclusion':{'C2_mask_only':'Small pooled reduction; seven of eight strata improve but both pooled block intervals include zero. Do not claim a stable quantified primary speedup.',
                          'C3_K_first_only':'Small pooled reduction with mixed matrix directions and intervals including zero; no stable primary speed benefit established.',
                          'remaining_peer_gap':'All eight C3-vs-plain-BF16 strata remain slower; original remaining gap is not solved.',
                          'semantics':'C3 finite math/safety and both cancellation amplitudes/modes/slots pass, with all precision values and word parity equal to C1/C2.'}}
    target=HERE/'product-c2-c3-results-summary.json';target.write_text(json.dumps(result,indent=2)+'\n')
    with (HERE/'product-c2-c3-all-matrices.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(matrix[0]));writer.writeheader();writer.writerows(matrix)
    for r in pooled:
        print(r['comparison'],'capture',r['capture'],f"{r['control_all_tail_mean_us']:.6f}->{r['treatment_all_tail_mean_us']:.6f}us",f"change={r['latency_change_percent']:+.6f}%",r['latency_change_percent_interval'])
    print('summary_sha256',sha(target))


if __name__=='__main__':main()
