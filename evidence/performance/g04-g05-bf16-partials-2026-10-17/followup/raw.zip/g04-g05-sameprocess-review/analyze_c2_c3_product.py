"""Read-only analysis of actual C2/C3 isolated products, both opt-in/11MiB."""
import argparse,hashlib,json
from pathlib import Path
import analyze as paired
from summarize_new_product_results import paired_block_interval


def fields(line):return dict(w.split('=',1) for w in line.split()[1:] if '=' in w)


def review(text):
    paired.SHAPES=('prefill',)
    records=paired.parse(text);modes=[]
    for capture in (0,1):
        result=paired.analyze([r for r in records if int(r['capture'])==capture],32,128)
        assert result['episode_pairs']==16384 and result['blocks']==128
        modes.append({'capture':capture,**result,'pooled_block_interval':paired_block_interval(result['strata'])})
    memory={};pending=None;attrs=None
    for line in text.splitlines():
        if line.startswith('ISOLATED_ATTR '):
            assert attrs is None;attrs=fields(line)
            assert attrs['c2_stub']!=attrs['c3_stub']
            assert attrs['c2_local']==attrs['c3_local']=='0'
            assert attrs['c2_binary']==attrs['c3_binary']=='89' and attrs['distinct_hoststubs']=='1'
        elif line.startswith('PRODUCT_MEMORY '):
            assert pending is None;pending={k:int(v) for k,v in fields(line).items()}
        elif line.startswith('COLD '):
            assert pending is not None;f=fields(line)
            key=(int(f['capture']),int(f['alloc']),int(f['order']),f['shape'],int(f['side']))
            assert key not in memory and pending['c2']==(key[-1]==0) and pending['captured']==key[0]
            assert pending['slots']==2 and pending['bf16_partials']==1
            assert pending['float_cap']==11<<20 and pending['required_workspace']==10567680
            memory[key]=pending;pending=None
    assert attrs is not None and pending is None and len(memory)==20
    assert text.rstrip().endswith('EXIT code=0')
    return {'kind':'INDEPENDENT_ACTUAL_C2_C3_SAME_PROCESS_PRODUCT_MASK_COMPARISON',
            'comparison':'C3optin / C2optin, both current same ABI and 11MiB each slot',
            'episode_pairs':32768,'complete_episodes':65536,'blocks':256,'capture_modes':modes,
            'cold_actual_hoststub_attributes':attrs,'actual_memory':[{'key':list(k),**v} for k,v in sorted(memory.items())],
            'all_samples_retained':True,'negative_control_subtraction':False,
            'limits':['Real full owner TUs are isolated by the separately retained symbol/COMDAT/fatbin and link-map checks; identical CUPTI device names alone do not prove arm identity.',
                      'Each capture/alloc/order matrix shown separately. Pooled intervals are descriptive same-process block intervals with independence approximation; not cross-process confidence.',
                      'Cold attributes and setup are outside warm timed episodes. No CUDA recompilation is performed by the isolation/consumer scripts.']}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('log',type=Path);p.add_argument('--output',type=Path)
    a=p.parse_args();raw=a.log.read_bytes();result=review(raw.decode());result['source_log_sha256']=hashlib.sha256(raw).hexdigest()
    if a.output:a.output.write_text(json.dumps(result,indent=2)+'\n')
    for mode in result['capture_modes']:
        print('capture',mode['capture'],'pooled',mode['pooled_block_interval'])
        for row in mode['strata']:print(row['allocation_order'],row['execution_order'],row['latency_change_percent'])


if __name__=='__main__':main()
