from pathlib import Path
import hashlib,json

repo=Path(__file__).resolve().parents[2]
out=repo/'.scratch/g04-bf16-c1-c2';out.mkdir(exist_ok=True)
base=repo/'.scratch/g04-bf16-product-bench/consumer.cc'
assert hashlib.sha256(base.read_bytes()).hexdigest()=='a8dd7326e4a412dbe090308a464325b34fbd9fdaf4c6c1e50f7a52209718c30d'
text=base.read_text()
declarations='''namespace hyle::compute::flashinfer {
Provider provider_c1() noexcept asm("g04_c1__ZN4hyle7compute10flashinfer8providerEv");
Provider provider_c2() noexcept asm("g04_c2__ZN4hyle7compute10flashinfer8providerEv");
}
extern "C" void target_c1() asm("g04_c1_target_attention");
extern "C" void target_c2() asm("g04_c2_target_attention");
'''
text=text.replace('namespace {',declarations+'namespace {',1)
assert text.count('c::flashinfer::provider())')==1
text=text.replace('c::flashinfer::provider())','original?c::flashinfer::provider_c1():c::flashinfer::provider_c2())')
text=text.replace('float_cap=std::size_t((original || !prefill)?22u:11u)<<20;','float_cap=std::size_t(11u)<<20;')
text=text.replace('.allow_bf16_partials=!original','.allow_bf16_partials=true')
text=text.replace('PRODUCT_MEMORY f32=%d','PRODUCT_MEMORY c1=%d')
text=text.replace('slots[0].report().bf16_partials!=(!original && prefill)','slots[0].report().bf16_partials!=prefill')
text=text.replace('diagnostic_trace=set("G04_TRACE");push(shape);','diagnostic_trace=set("G04_TRACE");char trace_label[160]{};std::snprintf(trace_label,sizeof(trace_label),"PRODUCT_C1_C2 capture=%u alloc=%u order=%u shape=%s",unsigned(captured),alloc,order,shape);push(trace_label);')
text=text.replace('    measure(alloc,order,replay!=0,1,17,1024,768,256,256,true,16);\n','')
text=text.replace('    measure(alloc,order,replay!=0,17,1,7,47,64,128,false,-1);\n','')
assert text.count('    measure(alloc,order,replay!=0,64,128,1024,768,256,256,true,-1);')==1
attrs='''void attrs(){
  cudaFuncAttributes a{},b{};
  const auto *pa=reinterpret_cast<const void*>(&target_c1),*pb=reinterpret_cast<const void*>(&target_c2);
  if(pa==pb || cudaFuncGetAttributes(&a,pa)!=cudaSuccess || cudaFuncGetAttributes(&b,pb)!=cudaSuccess)
    fail(hyle::Status::Internal("C1/C2 distinct registered hoststubs could not be queried"));
  std::printf("ISOLATED_ATTR c1_stub=%p c2_stub=%p c1_registers=%d c2_registers=%d c1_local=%zu c2_local=%zu c1_binary=%d c2_binary=%d c1_static_shared=%zu c2_static_shared=%zu distinct_hoststubs=1\\n",pa,pb,a.numRegs,b.numRegs,a.localSizeBytes,b.localSizeBytes,a.binaryVersion,b.binaryVersion,a.sharedSizeBytes,b.sharedSizeBytes);
  if(a.numRegs!=246 || a.localSizeBytes || b.localSizeBytes || a.binaryVersion!=89 || b.binaryVersion!=89)
    fail(hyle::Status::Internal("C1 baseline246/no-local SM89 or C2 no-local SM89 identity changed"));
}
'''
text=text.replace('\n}\nint main(){','\n'+attrs+'}\nint main(){')
text=text.replace('  std::printf("SCHEDULE warmups=64','  attrs();\n  std::printf("SCHEDULE warmups=64')
text=text.replace('product_single_factory=1 baseline_f32=1 treatment_bf16=1 trace=%d','product_three_owner_isolated_clones=1 control=C1optin treatment=C2optin both_caps_MiB=11 both_allow_bf16_partials=1 trace=%d')
assert 'baseline_f32=1' not in text and 'both_caps_MiB=11' in text
(out/'consumer.cc').write_text(text)
record={'source_sha256':hashlib.sha256((out/'consumer.cc').read_bytes()).hexdigest(),
        'base_source_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
        'arms':['real C1 archive optin','real C2 archive optin'],
        'workspace_cap_each_slot':11<<20,'slots_each_arm':2,'groups':32,'pairs_each_group':128,
        'capture_modes':2,'allocation_orders':2,'execution_orders':2,'total_pairs':32768,
        'retained_guards':['independent feature oracle','Q and KV readonly','all tails','post-measurement verify both slots','actual report and public replay reuse','close/drain'],
        'GPU_executed':False,'CUDA_recompiled':False}
(out/'source-identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
