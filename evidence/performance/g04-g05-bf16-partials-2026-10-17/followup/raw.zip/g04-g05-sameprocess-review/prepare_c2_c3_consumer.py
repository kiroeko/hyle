"""Derive only the host consumer/build/run scaffolding; no product/CUDA work."""
from pathlib import Path
import hashlib,json,re

repo=Path(__file__).resolve().parents[2]
base=repo/'.scratch/g04-bf16-c1-c2';out=repo/'.scratch/g04-bf16-c2-c3';out.mkdir(exist_ok=True)
mapping={'c1':'c2','c2':'c3','C1':'C2','C2':'C3'}
def relabel(text):return re.sub('c1|c2|C1|C2',lambda m:mapping[m[0]],text)
source=relabel((base/'consumer.cc').read_text())
source=source.replace('a.numRegs!=246 || ','').replace('baseline246/no-local','baseline no-local')
(out/'consumer.cc').write_text(source)
for name in ('build.py','run.py'):(out/name).write_text(relabel((base/name).read_text()))
isolation=relabel((base/'prepare_isolation.py').read_text())
start=isolation.index("    c3=json.loads(")
end=isolation.index("    exported={}",start)
replacement='''    c2_result=json.loads((REPO/'.scratch/g04-bf16-c2/archive-result.json').read_text())
    c3=json.loads((REPO/'.scratch/g04-bf16-c3/archive-result.json').read_text())
    c2_archive=Path(c3['C2_archive']);c3_archive=Path(c3['C3_archive'])
    assert c2_archive==Path(c2_result['C2_archive'])
    assert sha(c2_archive.read_bytes())==c3['C2_archive_sha256']==c2_result['C2_archive_sha256']
    assert sha(c3_archive.read_bytes())==c3['C3_archive_sha256']
    record={'kind':'ACTUAL_C2_C3_THREE_OWNER_ELF_ISOLATION','GPU_executed':False,'CUDA_recompiled':False,
            'source_sha256':sha((OUT/'consumer.cc').read_bytes()),'arms':{},
            'C2_archive_result_sha256':sha((REPO/'.scratch/g04-bf16-c2/archive-result.json').read_bytes()),
            'C3_archive_result_sha256':sha((REPO/'.scratch/g04-bf16-c3/archive-result.json').read_bytes())}
'''
isolation=isolation[:start]+replacement+isolation[end:]
isolation=isolation.replace("if arm=='c2':assert sha(files[-1].read_bytes())==old_codegen['artifacts']['product']['object_sha256']", "if arm=='c2':assert sha(files[-1].read_bytes())==c2_result['object_sha256']")
assert 'old_codegen' not in isolation and 'de8dbd313b03' not in isolation
(out/'prepare_isolation.py').write_text(isolation)
record=json.loads((base/'source-identity.json').read_text())
record['source_sha256']=hashlib.sha256((out/'consumer.cc').read_bytes()).hexdigest()
record['arms']=['real C2 archive optin','real C3 archive optin']
record['baseline_registers']='Record actual C2 attributes; verify against actual C2 fatbin/static codegen rather than assuming C1 register count.'
record['actual_isolation_status']='Not executed; awaiting real C3 archive/member identity.'
(out/'source-identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
