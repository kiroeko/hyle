"""Independent read-only correlation of the small C1 product peer trace."""
from collections import defaultdict
import bisect
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import statistics

ROOT=Path('/mnt/c/public/project-hyle/hyle')
BASE=ROOT/'.scratch/g04-bf16-product-peer-trace/run-trace-1'
DB=Path('/root/hyle-scratch/compute-unified/g04-bf16-product-peer-trace/run-trace-1/profile.sqlite')
OUT=ROOT/'.scratch/g04-g05-sameprocess-review'


def mean(values):return statistics.fmean(values)


def union_ns(ranges):
    if not ranges:return 0
    ranges=sorted(ranges);total=0;lo,hi=ranges[0]
    for start,end in ranges[1:]:
        if start<=hi:hi=max(hi,end)
        else:total+=hi-lo;lo,hi=start,end
    return total+hi-lo


def main():
    db=sqlite3.connect(DB.as_uri()+'?mode=ro&immutable=1',uri=True)
    rows=db.execute("select start,end,text,globalTid from NVTX_EVENTS where text like 'PRODUCT_PEER%' order by start").fetchall()
    assert len(rows)==8
    strata=[]
    for start,end,label,tid in rows:
        values=dict(part.split('=') for part in label.split()[1:])
        assert values['shape']=='prefill'
        strata.append({'start':start,'end':end,'tid':tid,**{k:int(values[k]) for k in ('capture','alloc','order')}})
    assert {(r['capture'],r['alloc'],r['order']) for r in strata}=={(c,a,o) for c in (0,1) for a in (0,1) for o in (0,1)}
    stratum_starts=[r['start'] for r in strata]
    eps=[]
    for start,end,label,tid in db.execute("select start,end,text,globalTid from NVTX_EVENTS where text in ('control.episode','treatment.episode') order by start"):
        index=bisect.bisect_right(stratum_starts,start)-1;s=strata[index]
        assert s['start']<=start<end<=s['end'] and tid==s['tid']
        eps.append({'start':start,'end':end,'tid':tid,'arm':'peer' if label=='control.episode' else 'optin',
                    'capture':s['capture'],'alloc':s['alloc'],'order':s['order'],
                    'kernels':[],'apis':[],'phases':{}})
    assert len(eps)==512
    ep_starts=[r['start'] for r in eps]
    phases=('update','admit_submit','checked_wait','output_acquire')
    for start,end,label,tid in db.execute("select start,end,text,globalTid from NVTX_EVENTS where text in ('update','admit_submit','checked_wait','output_acquire') order by start"):
        i=bisect.bisect_right(ep_starts,start)-1
        if i<0:continue
        e=eps[i]
        if not(e['start']<=start<end<=e['end']):continue
        assert tid==e['tid'] and label not in e['phases']
        e['phases'][label]={'start':start,'end':end}
    api={}
    for start,end,tid,correlation,name,ret in db.execute('select r.start,r.end,r.globalTid,r.correlationId,s.value,r.returnValue from CUPTI_ACTIVITY_KIND_RUNTIME r join StringIds s on s.id=r.nameId order by r.start'):
        assert correlation not in api
        a={'start':start,'end':end,'tid':tid,'correlation':correlation,'name':name,'return_value':ret}
        api[correlation]=a
        i=bisect.bisect_right(ep_starts,start)-1
        if i<0:continue
        e=eps[i]
        if e['start']<=start<end<=e['end'] and tid==e['tid']:
            assert ret==0,(name,ret)
            a['phase']=next((p for p,v in e['phases'].items() if v['start']<=start<end<=v['end']),'outside_inner_phases')
            e['apis'].append(a)
    unmapped=0
    query='''select k.start,k.end,k.correlationId,k.registersPerThread,k.staticSharedMemory,
             k.dynamicSharedMemory,k.localMemoryPerThread,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,
             k.graphNodeId,k.graphId,k.streamId,s.value
             from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on s.id=k.demangledName order by k.start'''
    for start,end,corr,regs,static,dynamic,local,gx,gy,gz,bx,by,bz,node,graph,stream,name in db.execute(query):
        a=api[corr];i=bisect.bisect_right(ep_starts,a['start'])-1
        if i<0 or not(eps[i]['start']<=a['start']<a['end']<=eps[i]['end']):unmapped+=1;continue
        e=eps[i]
        assert e['start']<=start<end<=e['end'] and a['tid']==e['tid']
        kind='attention' if 'BatchPrefillWithPagedKVCacheKernel' in name else 'merge' if 'PersistentVariableLengthMergeStatesKernel' in name else None
        assert kind and local==0
        assert a['name']==('cudaGraphLaunch_v10000' if e['capture'] else 'cudaLaunchKernel_v7000')
        assert bool(node)==bool(graph)==bool(e['capture'])
        e['kernels'].append({'kind':kind,'start':start,'end':end,'us':(end-start)/1000,'correlation':corr,
                             'registers':regs,'static_shared':static,'dynamic_shared':dynamic,'local_per_thread':local,
                             'grid':[gx,gy,gz],'block':[bx,by,bz],'graphNodeId':node,'graphId':graph,'stream':stream,'name':name})
    groups=defaultdict(list)
    for index,e in enumerate(eps):
        assert set(e['phases'])==set(phases)
        assert [k['kind'] for k in e['kernels']]==['attention','merge']
        attention,merge=e['kernels']
        assert attention['grid']==[40,1,2] and merge['grid']==[460,1,1]
        assert attention['block']==merge['block']==[32,4,1]
        assert attention['dynamic_shared']==49152 and merge['dynamic_shared']==8704
        assert attention['static_shared']==merge['static_shared']==0
        assert attention['stream']==merge['stream']
        if e['capture']:
            assert attention['correlation']==merge['correlation'] and attention['graphId']==merge['graphId']
            assert attention['graphNodeId']!=merge['graphNodeId']
        else:assert attention['correlation']!=merge['correlation']
        key=e['capture'],e['alloc'],e['order'],e['arm'];groups[key].append(e)
        if index%64==0 or index%64==1:
            assert e['arm']==('optin' if (index%64==0)==bool(e['order']) else 'peer')
    results=[]
    for key,episodes in sorted(groups.items()):
        assert len(episodes)==32
        count=defaultdict(list);elapsed=defaultdict(list);resources={}
        allnames=sorted({a['name'] for e in episodes for a in e['apis']})
        for name in allnames:
            for e in episodes:
                matched=[a for a in e['apis'] if a['name']==name]
                count[name].append(len(matched));elapsed[name].append(sum(a['end']-a['start'] for a in matched)/1000)
        names={kind:sorted({k['name'] for e in episodes for k in e['kernels'] if k['kind']==kind}) for kind in ('attention','merge')}
        for kind in names:
            assert len(names[kind])==1
            variants={tuple([k['registers'],k['static_shared'],k['dynamic_shared'],k['local_per_thread'],*k['grid'],*k['block']]) for e in episodes for k in e['kernels'] if k['kind']==kind}
            assert len(variants)==1
            resources[kind]={'name':names[kind][0],'variants':[list(v) for v in variants]}
        result={'capture':key[0],'alloc':key[1],'order':key[2],'arm':key[3],'episodes':32,
                'gpu':{kind+'_mean_us':mean([k['us'] for e in episodes for k in e['kernels'] if k['kind']==kind]) for kind in ('attention','merge')},
                'resources':resources,'host_phase_mean_us':{p:mean([(e['phases'][p]['end']-e['phases'][p]['start'])/1000 for e in episodes]) for p in phases},
                'host_episode_mean_us':mean([(e['end']-e['start'])/1000 for e in episodes]),
                'host_api_union_mean_us':mean([union_ns([(a['start'],a['end']) for a in e['apis']])/1000 for e in episodes]),
                'host_api_by_name':{name:{'mean_count_per_episode':mean(count[name]),'total_calls':sum(count[name]),'mean_elapsed_sum_per_episode_us':mean(elapsed[name]),'individual_counts':sorted(set(count[name]))} for name in allnames},
                'host_phase_api':{},
                'gpu_interkernel_gap_mean_us':mean([(e['kernels'][1]['start']-e['kernels'][0]['end'])/1000 for e in episodes]),
                'after_last_kernel_to_episode_end_mean_us':mean([(e['end']-e['kernels'][-1]['end'])/1000 for e in episodes])}
        for p in (*phases,'outside_inner_phases'):
            result['host_phase_api'][p]={name:{'calls':sum(a['name']==name and a['phase']==p for e in episodes for a in e['apis']),
                                             'mean_elapsed_sum_us':sum(a['end']-a['start'] for e in episodes for a in e['apis'] if a['name']==name and a['phase']==p)/1000/len(episodes)} for name in allnames if any(a['name']==name and a['phase']==p for e in episodes for a in e['apis'])}
        result['gpu']['sum_mean_us']=sum(result['gpu'].values())
        results.append(result)
    contrasts=[]
    for capture in (0,1):
        for alloc in (0,1):
            for order in (0,1):
                a,b=(next(r for r in results if (r['capture'],r['alloc'],r['order'],r['arm'])==(capture,alloc,order,arm)) for arm in ('peer','optin'))
                contrasts.append({'capture':capture,'alloc':alloc,'order':order,
                                  'peer_gpu':a['gpu'],'optin_gpu':b['gpu'],
                                  'optin_minus_peer_us':{k:b['gpu'][k]-a['gpu'][k] for k in a['gpu']},
                                  'gpu_sum_change_percent':100*(b['gpu']['sum_mean_us']/a['gpu']['sum_mean_us']-1)})
    result={'kind':'INDEPENDENT_C1_SMALL_PRODUCT_PEER_TRACE_REVIEW','episodes':512,'timed_kernels':1024,
            'all_episodes_exactly_attention_then_merge':True,'captured_graph_two_kernel_association_complete':True,
            'geometry_equal_between_arms':True,'outside_timed_kernels':unmapped,'strata':results,'contrasts':contrasts,
            'raw_episode_file':'product-peer-trace-episodes.jsonl',
            'bindings':{'sqlite_sha256':hashlib.sha256(DB.read_bytes()).hexdigest(),
                        'source_sha256':hashlib.sha256((BASE.parent/'consumer.cc').read_bytes()).hexdigest(),
                        'run_identity':json.loads((BASE/'result.json').read_text())},
            'limits':['Small profiled diagnostic (32 episodes per arm/matrix); never replaces retained unprofiled full-episode performance primary.',
                      'Runtime table includes named CUDA runtime and direct driver APIs. Per-episode API attribution uses exact same-thread NVTX containment; counts and elapsed union are profiler observations.',
                      'checked_wait includes pending GPU work, host scheduling and notification. Host wall minus GPU time is not pure CPU cost; API elapsed time is not a removable critical-path bound.',
                      'Matching geometry does not make FP8/BF16 loaders, attention variants, parameter ABI or final merge scaling the same.']}
    (OUT/'product-peer-trace-review.json').write_text(json.dumps(result,indent=2)+'\n')
    with (OUT/'product-peer-trace-episodes.jsonl').open('w') as f:
        for e in eps:f.write(json.dumps(e)+'\n')
    for c in contrasts:print(json.dumps(c))
    print('review_sha256',hashlib.sha256((OUT/'product-peer-trace-review.json').read_bytes()).hexdigest())


if __name__=='__main__':main()
