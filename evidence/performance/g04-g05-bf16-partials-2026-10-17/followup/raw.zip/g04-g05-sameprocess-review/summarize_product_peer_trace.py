from pathlib import Path
import hashlib,json,statistics

here=Path(__file__).resolve().parent
source=here/'product-peer-trace-review.json'
review=json.loads(source.read_text())
rows=[]
for capture in (0,1):
    for arm in ('peer','optin'):
        strata=[r for r in review['strata'] if r['capture']==capture and r['arm']==arm]
        assert len(strata)==4 and all(r['episodes']==32 for r in strata)
        api={}
        for name in sorted({k for r in strata for k in r['host_api_by_name']}):
            observed=[r['host_api_by_name'].get(name,{'mean_count_per_episode':0,'total_calls':0,'mean_elapsed_sum_per_episode_us':0}) for r in strata]
            api[name]={'mean_count_per_episode':statistics.fmean(r['mean_count_per_episode'] for r in observed),
                       'total_calls':sum(r['total_calls'] for r in observed),
                       'mean_elapsed_sum_per_episode_us':statistics.fmean(r['mean_elapsed_sum_per_episode_us'] for r in observed)}
        rows.append({'capture':capture,'arm':arm,'episodes':128,
                     'gpu':{k:statistics.fmean(r['gpu'][k] for r in strata) for k in strata[0]['gpu']},
                     'host_phase_mean_us':{k:statistics.fmean(r['host_phase_mean_us'][k] for r in strata) for k in strata[0]['host_phase_mean_us']},
                     'host_episode_mean_us':statistics.fmean(r['host_episode_mean_us'] for r in strata),
                     'host_api_union_mean_us':statistics.fmean(r['host_api_union_mean_us'] for r in strata),
                     'gpu_interkernel_gap_mean_us':statistics.fmean(r['gpu_interkernel_gap_mean_us'] for r in strata),
                     'host_api_by_name':api})
contrasts=[]
for capture in (0,1):
    peer,optin=(next(r for r in rows if r['capture']==capture and r['arm']==a) for a in ('peer','optin'))
    contrasts.append({'capture':capture,
                      'gpu_optin_minus_peer_us':{k:optin['gpu'][k]-peer['gpu'][k] for k in peer['gpu']},
                      'host_phase_optin_minus_peer_us':{k:optin['host_phase_mean_us'][k]-peer['host_phase_mean_us'][k] for k in peer['host_phase_mean_us']}})
out={'kind':'SMALL_PROFILED_PRODUCT_PEER_TRACE_POOLED_SUMMARY','groups':rows,'contrasts':contrasts,
     'source_review_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
     'limits':review['limits'],
     'conclusion':'Same kernel geometry and same per-mode API counts. Extra FP8-optin GPU cost is in attention (+about5.3us), while its merge is about1.34us faster. Public replay removes native resource-query APIs symmetrically but preserves the attention gap. Profiling does not establish a new unprofiled performance number or isolate the exact attention source factor.'}
target=here/'product-peer-trace-summary.json';target.write_text(json.dumps(out,indent=2)+'\n')
for r in rows:
    print(r['capture'],r['arm'],r['gpu'],r['host_phase_mean_us'],r['host_episode_mean_us'])
print('summary_sha256',hashlib.sha256(target.read_bytes()).hexdigest())
