from pathlib import Path
import re,ast
p=Path(__file__).resolve().parent
source=(p/'analyze_c1_c2_product.py').read_text()
mapping={'c1':'c2','c2':'c3','C1':'C2','C2':'C3'}
source=re.sub('c1|c2|C1|C2',lambda m:mapping[m[0]],source)
source=source.replace("            assert attrs['c2_registers']=='246'\n",'')
(p/'analyze_c2_c3_product.py').write_text(source)
ast.parse(source)
print('C2/C3 analyzer prepared; no raw read')
