from pathlib import Path
import hashlib,json

root=Path(__file__).resolve().parents[2];here=Path(__file__).resolve().parent
c1=json.loads((here/'product-precision-review.json').read_text())
c2=json.loads((here/'product-c2-precision-review.json').read_text())
assert c1['rows']==c2['rows']
assert c1['peer_all_words_checks']==c2['peer_all_words_checks']
base=root/'.scratch/g04-bf16-c2'
tests={name:json.loads((base/('run-'+name+'-1')/'result.json').read_text())
       for name in ('public','native-test','precision','memcheck','synccheck','feature-memcheck')}
assert all(v['returncode']==0 for v in tests.values())
identity=json.loads((base/'archive-result.json').read_text())
assert all(v['C2_archive_sha256']==identity['C2_archive_sha256'] and v['C2_source_sha256']==identity['C2_source_sha256'] for v in tests.values())
result={'kind':'INDEPENDENT_C2_SEMANTIC_RESULT_REVIEW','six_runs_returncode_zero':True,
        'precision_24_rows_exactly_equal_C1':True,'eight_peer_all_word_parity_checks_exactly_equal_C1':True,
        'independent_double_prefix_and_RNE_recalculated':True,
        'C2_source_sha256':identity['C2_source_sha256'],'C2_archive_sha256':identity['C2_archive_sha256'],
        'C2_cache_object_sha256':identity['object_sha256'],
        'precision_host_source_sha256':hashlib.sha256((root/'.scratch/g04-bf16-product-precision/consumer.cc').read_bytes()).hexdigest(),
        'precision_review_sha256':hashlib.sha256((here/'product-c2-precision-review.json').read_bytes()).hexdigest(),
        'runs':tests,'limits':['Only retained finite consumer/native/sanitizer cases, not a full-model quality claim.',
                              'No new GPU execution or changes to C1 frozen results by this review.',
                              'Actual public/native correctness and sanitizer results rely on the sole runner; double prefix/RNE and all retained precision summary comparisons independently recomputed.']}
out=here/'product-c2-semantics-review.json';out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'precision_24_rows_same_C1':True,'eight_peer_parity_same_C1':True,'six_returncodes_zero':True,
                  'review_sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
