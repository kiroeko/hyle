from pathlib import Path
import hashlib,json,sqlite3

ROOT=Path('/mnt/c/public/project-hyle/hyle')
OUT=ROOT/'.scratch/g04-bf16-product-peer-codegen'
p=ROOT/'.scratch/g04-bf16-product-peer-trace/run-trace-1/profile.sqlite'
c=sqlite3.connect('file:'+str(p)+'?mode=ro',uri=True)
c.row_factory=sqlite3.Row
schema=c.execute("SELECT sql FROM sqlite_master WHERE name='CUPTI_ACTIVITY_KIND_KERNEL'").fetchone()[0]
names=[dict(r) for r in c.execute('SELECT s.value AS name,COUNT(*) AS count,k.registersPerThread,k.staticSharedMemory,k.dynamicSharedMemory,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName GROUP BY s.value,k.registersPerThread,k.staticSharedMemory,k.dynamicSharedMemory,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ')]
(OUT/'actual-trace-kernel-names.json').write_text(json.dumps(names,indent=2)+'\n')
result={'kind':'INDEPENDENT_CURRENT_PRODUCT_PEER_RESIDUAL_BINDING','gpu_executed_by_this_analysis':False,'recompiled':False,'sqlite':str(p),'sqlite_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'kernel_schema':schema,'all_kernel_name_resources':names}
prefills=[x for x in names if 'BatchPrefillWithPagedKVCacheKernel' in x['name']]
assert len(prefills)==2,prefills
plain=next(x for x in prefills if 'DefaultAttention<' in x['name'])
optin=next(x for x in prefills if 'Bf16PartialAttention' in x['name'])
assert 'DefaultAttention<(bool)0, (bool)0, (bool)0, (bool)0>' in plain['name']
assert 'KernelTraits<(flashinfer::MaskMode)1, (unsigned int)64, (unsigned int)1, (unsigned int)1, (unsigned int)16, (unsigned int)16, (unsigned int)4, (unsigned int)1' in plain['name']
assert 'KernelTraits<(flashinfer::MaskMode)1, (unsigned int)64, (unsigned int)1, (unsigned int)1, (unsigned int)16, (unsigned int)16, (unsigned int)4, (unsigned int)1' in optin['name']
assert '__nv_bfloat16, __nv_bfloat16, __nv_bfloat16, float, int' in plain['name']
assert '__nv_bfloat16, __nv_fp8_e4m3, __nv_bfloat16, float, int' in optin['name']
assert plain['registersPerThread']==238 and optin['registersPerThread']==246
for x in prefills:
    assert [x[k] for k in ['gridX','gridY','gridZ','blockX','blockY','blockZ','dynamicSharedMemory']]==[40,1,2,32,4,1,49152]
merges=[x for x in names if 'PersistentVariableLengthMergeStatesKernel' in x['name']]
assert len(merges)==2,merges
for x in merges:
    assert [x[k] for k in ['gridX','gridY','gridZ','blockX','blockY','blockZ','dynamicSharedMemory']]==[460,1,1,32,4,1,8704]
    assert '(unsigned int)8, (unsigned int)32, (unsigned int)4, (unsigned int)4, __nv_bfloat16, __nv_bfloat16, int' in x['name']
review=ROOT/'.scratch/g04-g05-sameprocess-review/product-peer-trace-review.json'
r=json.loads(review.read_text())
assert r['bindings']['sqlite_sha256']==result['sqlite_sha256']
assert r['episodes']==512 and r['timed_kernels']==1024 and r['geometry_equal_between_arms']
assert all(x['optin_minus_peer_us']['attention_mean_us']>0 and x['optin_minus_peer_us']['merge_mean_us']<0 for x in r['contrasts'])
result.update({'source_review':str(review),'source_review_sha256':hashlib.sha256(review.read_bytes()).hexdigest(),'plain_kv_mma1_selection_confirmed_from_actual_sqlite_name':True,'fp8_kv_mma1_selection_confirmed_from_actual_sqlite_name':True,'both_attention_geometry_equal':True,'both_merge_geometry_equal':True,'plain_resources_match_read_only_disassembly':True,'optin_resources_match_read_only_disassembly':True,'timed_episode_association_reused_from_independent_reviewer':{'episodes':512,'timed_kernels':1024,'captured_graph_two_kernel_association_complete':r['captured_graph_two_kernel_association_complete']},'comparisons':r['contrasts'],'conclusion':'Actual same-geometry residual is attention: opt-in attention slower in every stratum; its scaled merge is faster, not a net slowdown. Trace does not separate mask and packed-K decode effects. The old F32-partial-column KV experiment cannot be generalized to this product peer.'})
(OUT/'residual-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'plain_prefill':plain,'optin_prefill':optin,'merge':merges},indent=2))
