# Current product FP8/BF16 partials versus same-source plain BF16 KV

Read-only source and SM89 disassembly, 2026-10-17. No CUDA compilation or GPU execution by this analysis. `read.json` binds the actual shipping archive member to `native_batch.cu.o`, records all commands, and binds the previous new-product FP8 disassembly. The four plain prefill MMA instances are possibilities in the object; the runtime-selected instance must be identified by the runner's new trace.

The subsequent independent product trace review (`.scratch/g04-g05-sameprocess-review/product-peer-trace-review.json`, SHA256 `a1e32621c8a14057c01d34451a595f8c5a1adc0c17a078bee89ec67e0641f6c4`) confirms the table's MMA1 instance is actually selected. It contains512 timed public episodes and1024 kernels, with complete ordinary/graph attention→merge association. Both arms use attention grid40×1×2, block32×4×1, dynamic shared49152; both merges use grid460×1×1, block32×4×1, dynamic shared8704. Therefore the smaller plain merge register count does **not** produce a different persistent grid in this run.

## Comparable CTA64 / KV-MMA1 generated code

| Item | Plain BF16 native_batch | FP8 opt-in BF16 partials native_cache |
|---|---:|---:|
| Q/KV/output storage types | BF16/BF16/BF16 | BF16/E4M3/BF16 |
| MMA Q/KV, Q/KV warps | 1/1, 4/1 | 1/1, 4/1 |
| QK/PV math | BF16 inputs, F32 accumulation | BF16 inputs, F32 accumulation |
| Prefill registers | 238 | 246 |
| Prefill stack / local | 0 / 0 | 0 / 0 |
| Prefill static SASS rows | 1632 | 2032 |
| Merge registers | 40 | 48 |
| Merge stack / local | 0 / 0 | 0 / 0 |
| Merge static SASS rows | 888 | 944 |
| Merge template | vec8, x32, y4, stages4, BF16, SCALE_OUTPUT=false | same geometry/types, SCALE_OUTPUT=true |

Static instruction totals are not cycles or executed instruction counts. Both prefill instances have 65 static HMMA rows, 10 EX2, 263 FMUL and 68 BF16 pack operations. The FP8 one additionally contains 32 PRMT and 64 HFMA2.BF16_V2 rows for conversion across initial and loop K/V producers. Plain has 32 static LDGSTS rows, versus FP8's 16 LDGSTS (Q copies) and 8 LDG.E.128 for packed K/V, followed by explicit conversion and shared stores. These counts include prologue and loop bodies and must not be summed as the number executed per replay.

For a complete CTA KV tile of 16 rows, depth256, global K+V payload is 8192 bytes for FP8 versus16384 bytes for plain BF16. Both subsequently consume 16-bit K/V fragments. Q uses32768 bytes per full CTA64 tile. Direct staging avoids a second packed shared buffer, but does not remove conversion dependency or make the compressed load asynchronous.

## Actual key producer dependency

PCs are in the selected SM89 functions, not source-line timing claims:

* Plain next-K async copies are `LDGSTS` at `24f0,2530,2570,25b0`, interleaved with softmax `EX2` at `2420..2770`. Its K producer can progress while softmax instructions run; the wait/publish points are `26d0/26e0`.
* FP8 next-K global loads are `LDG.E.128` at `3bb0,3f20`, after the last softmax `EX2` at `3590`. The conversion/shared-store dependency follows through `4210`, then the publish barrier is at `4350`, and PV starts at `4600`.
* FP8 V loads are already at `4520,4550`, before PV `4600..4840`. V conversion starts at `4850`. The earlier source-only claim that V lacks any overlap was withdrawn and is not a finding of this review.

The K load→decode→publish sequence is a real additional consumer dependency. Disassembly alone does not assign it a measured microsecond cost or prove how much of the public ~5% gap it explains.

## Unbounded-domain window specialization

`native_batch.cu` uses `DefaultAttention<false,false,false,false>`. The opt-in `Bf16PartialAttention` currently derives from `DefaultAttention<false,true,false,false>`. `variants.cuh` declares the second template boolean as `use_sliding_window`; its only conditional code is the extra lower-bound test in `LogitsMask`:

`kv_idx + qo_len + window_left >= kv_len + qo_idx`

`bf16_partial_domain()` already requires `causal && window_left==-1`, and only that domain reaches the new output-param specialization. The constructor maps -1 to `window_left=kv_len`. For valid query rows, the extra mathematical test is therefore redundant. MaskMode::kCausal independently retains causal upper bound and chunk_end protection in `logits_mask`; changing only the dedicated new variant's base to false/false does not remove either. The constructor, kernel chunk arithmetic and window_iteration code remain unchanged. Invalid padded query rows can have different intermediate masked values but are independent row reductions; output and LSE writes remain guarded by qo_len / qo_upper_bound.

The FP8 selected SASS has eight `ISETP.LT.U32.OR` rows at `2d30,2d50,2dc0,2e30,2e50,2ed0,2ee0,2ef0`, before score FSEL and softmax. Plain has none. These rows run when the logits-mask branch is taken, not necessarily for every prefix tile. Removing them is a finite specialization hypothesis; it is not a prediction that the whole gap disappears. A language-level caveat is that the existing unsigned sum can wrap for hypothetical enormous lengths; the redundant-test proof is over the mathematical index range used by the real allocated D256 workloads, not a proof of existing modulo-arithmetic equality for every uint32 bit pattern.

## Merge is a separate factor

The plain input expands FP8 bytes into BF16 and absorbs key=.5/value=2 on the cold path. Its normal prefill uses no custom `merge_states` method; the upstream merge has SCALE_OUTPUT=false. The FP8 path scales QK through sm_scale and applies value_scale after merging, via the custom derived params and SCALE_OUTPUT=true. BF16 permission alone does not authorize silently moving this scale across partial rounding.

Actual merge disassembly has identical FFMA98 and EX222 counts and the same11 async-copy rows, but FP8 has16 additional FMUL,8 PRMT and4 BF16-pack rows. Its48 registers versus40 could in principle affect occupancy, but the actual new trace has the same460-block grid in both arms. No occupancy measurement is inferred from `cuobjdump`'s static SHARED:0 field, and no register-based prediction overrides that observed equal grid.

The new profiled diagnostic finds FP8 opt-in attention slower by5.19..5.42us in all eight strata, but its merge is **faster** by1.32..1.36us. Net GPU cost is3.85..4.08us higher. Therefore current evidence locates the remaining gap principally in attention; it does not support calling scaled merge the current net slowdown. These instrumented timings explain the retained ordinary measurement, but do not replace its unprofiled complete-episode primary. This trace still does not separate the mask contribution from the packed-K producer dependency.

## Why the earlier -0.48% KV experiment does not transfer

The old four-corner experiment changed the KV type inside native_cache while preserving the old scaled/window-aware/custom-merge path, using unscaled BF16 snapshots and the same record. It was a useful controlled counterfactual, but was not the current plain BF16 product path. Its `00→10=-0.48%` result was specifically in the F32-partial column. The BF16-partial column `01→11` was about-7.67%, showing an interaction; the F32-column number cannot be generalized to every intermediate precision. It also cannot be carried forward as the exact performance of newly compiled prefill: current new-product prefill instructions differ from the prior full-TU diagnostic, as recorded in `g04-bf16-product-codegen/review.json`.

Thus the new same-product peer result is authoritative for the current end-to-end gap, and the new trace places the principal residual in attention. Redundant window-mask work and synchronous packed-K conversion/publication are separate attention hypotheses. The current scaled merge is faster in the actual trace and is not a demonstrated cause of the net regression. A mask-only experiment can isolate the first hypothesis; a later pure-K prefetch experiment must be measured independently before attributing a benefit to the second.
