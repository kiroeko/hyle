from pathlib import Path
import collections,hashlib,json,re,subprocess,time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
OUT=ROOT/'.scratch/g04-bf16-product-peer-codegen'
OUT.mkdir(exist_ok=True)
BUILD=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build')
obj=BUILD/'src/compute_provider_flashinfer/CMakeFiles/hyle_compute_provider_flashinfer.dir/native_batch.cu.o'
archive=BUILD/'bin/libhyle_compute_provider_flashinfer.a'
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=json.loads((ROOT/'.scratch/g04-bf16-product/built-identity.json').read_text())
assert sha(archive.read_bytes())==identity[str(archive)]
assert sha(subprocess.check_output(['ar','p',str(archive),'native_batch.cu.o']))==sha(obj.read_bytes())
nm=subprocess.check_output(['nm','--defined-only','--format=posix',str(obj)],text=True)
(OUT/'native-batch-nm.txt').write_text(nm)
host=[l.split()[0] for l in nm.splitlines() if len(l.split())>=2 and l.split()[1]=='t' and not l.split()[0].endswith('.cold')]
def one(predicate):
    x=[n for n in host if predicate(n)]
    assert len(x)==1,x
    return re.sub(r'^_ZN10flashinferL(\d+)',r'_ZN10flashinfer\1',x[0])
names={f'plain-bf16-prefill-mma{kv}':one(lambda n,kv=kv:n.startswith('_ZN10flashinferL34BatchPrefillWithPagedKVCacheKernel') and f'MaskModeE1ELj64ELj1ELj{kv}ELj16ELj16ELj4ELj1E' in n and '13__nv_bfloat16S4_S4_fiNS_16DefaultAttentionILb0ELb0ELb0ELb0E' in n) for kv in [1,2,4,8]}
names['plain-bf16-merge']=one(lambda n:n.startswith('_ZN10flashinferL41PersistentVariableLengthMergeStatesKernelILj8ELj32ELj4ELj4E13__nv_bfloat16S1_iLb0E'))
record={'scope':'Read-only current product native_batch plain BF16 generated code; runtime-selected MMA instance must come from trace, not all instances in this object are executed.','gpu_executed':False,'recompiled':False,'object':str(obj),'object_sha256':sha(obj.read_bytes()),'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'archive_member_equals_object':True,'commands':[],'kernels':{}}
for option,kind in [('--dump-sass','sass'),('--dump-resource-usage','resources')]:
    cmd=['/usr/local/cuda-13.3/bin/cuobjdump','--gpu-architecture','sm_89',option,'--function',','.join(names.values()),str(obj)]
    t=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
    (OUT/f'plain-{kind}.txt').write_text(p.stdout);(OUT/f'plain-{kind}-stderr.txt').write_text(p.stderr)
    assert p.returncode==0,p.stderr
    record['commands'].append({'argv':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'stdout_sha256':sha(p.stdout.encode())})
sass=(OUT/'plain-sass.txt').read_text();resources=(OUT/'plain-resources.txt').read_text()
assert 'arch = sm_89' in sass and 'arch = sm_80' not in sass
chunks={part.splitlines()[0]:part for part in re.split(r'\s*Function : ',sass)[1:]}
assert set(names.values())==set(chunks)
for key,name in names.items():
    rows=[];bits=[]
    lines=chunks[name].splitlines()
    for i,line in enumerate(lines):
        m=re.search(r'/\*([0-9a-fA-F]+)\*/\s+(.+?;)',line)
        if not m:continue
        lo=re.search(r'/\* (0x[0-9a-fA-F]{16}) \*/',line)
        hi=re.search(r'/\* (0x[0-9a-fA-F]{16}) \*/',lines[i+1]);assert lo and hi
        rows.append({'pc':m[1],'sass':m[2].strip()});bits.append(lo[1]+':'+hi[1])
    assert len(rows)>300
    text='\n'.join(x['sass'] for x in rows)+'\n';encoded='\n'.join(bits)+'\n'
    (OUT/f'{key}-instructions.txt').write_text(text);(OUT/f'{key}-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
    (OUT/f'{key}-codewords.txt').write_text(encoded)
    resource=re.search(r'Function\s+'+re.escape(name)+r':\s*\n([^\n]+)',resources);assert resource
    record['kernels'][key]={'device_symbol':name,'instruction_count':len(rows),'normalized_sha256':sha(text.encode()),'codewords_sha256':sha(encoded.encode()),'resource':resource[1].strip(),'ops':dict(collections.Counter(re.sub(r'^@!?[UP][A-Z0-9]*\s+','',x['sass']).split()[0] for x in rows))}
reference=ROOT/'.scratch/g04-bf16-product-codegen/review.json'
record['fp8_product_reference']={'path':str(reference),'sha256':sha(reference.read_bytes()),'data':json.loads(reference.read_text())['artifacts']['product']['kernels']['bf16-prefill']}
record['fp8_merge_reference']=json.loads(reference.read_text())['artifacts']['product']['kernels']['bf16-merge']
(OUT/'read.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:{x:v[x] for x in ['instruction_count','resource','normalized_sha256']} for k,v in record['kernels'].items()},indent=2))
