"""Clone the two actual three-owner products; no C++/CUDA compilation or GPU work."""
from pathlib import Path
import hashlib,json,re,subprocess,time

REPO=Path('/mnt/c/public/project-hyle/hyle')
OUT=REPO/'.scratch/g04-bf16-c2-c5'
WORK=Path('/root/hyle-scratch/compute-unified/g04-bf16-c2-c5')
MEMBERS=('flashinfer_provider.cc.o','native_batch.cu.o','native_cache.cu.o')
DESTINATIONS=('provider.o','batch.o','cache.o')
FACTORY='_ZN4hyle7compute10flashinfer8providerEv'
sha=lambda data:hashlib.sha256(data).hexdigest()


def run(argv):return subprocess.check_output([str(a) for a in argv],text=True)
def nm(path,*args):return run(['nm',*args,'--format=posix',path])
def names(text):return {line.split()[0] for line in text.splitlines()}


def main():
    WORK.mkdir(exist_ok=True)
    c2_result=json.loads((REPO/'.scratch/g04-bf16-c2/archive-result.json').read_text())
    c5=json.loads((REPO/'.scratch/g04-bf16-c5/archive-result.json').read_text())
    c2_archive=Path(c5['C2_archive']);c5_archive=Path(c5['C5_archive'])
    assert c2_archive==Path(c2_result['C2_archive'])
    assert sha(c2_archive.read_bytes())==c5['C2_archive_sha256']==c2_result['C2_archive_sha256']
    assert sha(c5_archive.read_bytes())==c5['C5_archive_sha256']
    record={'kind':'ACTUAL_C2_C5_THREE_OWNER_ELF_ISOLATION','GPU_executed':False,'CUDA_recompiled':False,
            'source_sha256':sha((OUT/'consumer.cc').read_bytes()),'arms':{},
            'C2_archive_result_sha256':sha((REPO/'.scratch/g04-bf16-c2/archive-result.json').read_bytes()),
            'C5_archive_result_sha256':sha((REPO/'.scratch/g04-bf16-c5/archive-result.json').read_bytes())}
    exported={}
    for arm,archive in (('c2',c2_archive),('c5',c5_archive)):
        folder=WORK/arm;folder.mkdir(exist_ok=False)
        files=[];defined=set();signatures=set();before={}
        for member in MEMBERS:
            path=folder/member;path.write_bytes(subprocess.check_output(['ar','p',str(archive),member]));files.append(path)
            symbols=run(['readelf','-Ws',path]);groups=run(['readelf','--section-groups',path])
            sections=run(['readelf','-SW',path])
            assert '.gnu.linkonce.' not in sections, 'Legacy name-selected linkonce sections require separate isolation'
            (folder/(member+'.before-symbols.txt')).write_text(symbols)
            (folder/(member+'.before-groups.txt')).write_text(groups)
            (folder/(member+'.before-sections.txt')).write_text(sections)
            # No resolver semantics are silently assumed for an ELF IFUNC.
            assert not re.search(r'\sIFUNC\s',symbols)
            defined.update(names(nm(path,'--defined-only','--extern-only')))
            signatures.update(re.findall(r'COMDAT group section.*?\[([^\]]+)\] contains',groups))
            before[member]={'sha256':sha(path.read_bytes()),'defined':names(nm(path,'--defined-only','--extern-only')),
                            'undefined':names(nm(path,'--undefined-only'))}
        assert FACTORY in defined
        if arm=='c2':assert sha(files[-1].read_bytes())==c2_result['object_sha256']
        else:assert sha(files[-1].read_bytes())==c5['object_sha256']
        for member in MEMBERS[:-1]:
            assert before[member]['sha256']==c5['members_before'][member]==c5['members_after'][member]
        candidates=[]
        for line in nm(files[-1],'--defined-only').splitlines():
            name,kind,*_=line.split()
            if kind=='t' and name.startswith('_ZN10flashinferL34BatchPrefillWithPagedKVCacheKernel') and not name.endswith('.cold') and 'MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1E' in name and '13__nv_bfloat1613__nv_fp8_e4m3S4_fi' in name and 'MergeParams' in name and 'Lj256E' in name:
                candidates.append(name)
        assert len(candidates)==1,candidates
        target=candidates[0]
        mapping={name:'g04_'+arm+'_'+name for name in defined|signatures}
        mapping[target]='g04_'+arm+'_target_attention'
        mapfile=folder/'rename.syms';mapfile.write_text(''.join(f'{a} {b}\n' for a,b in sorted(mapping.items())))
        objects=[]
        for i,(member,destination,path) in enumerate(zip(MEMBERS,DESTINATIONS,files)):
            clone=folder/destination;argv=['objcopy','--redefine-syms='+str(mapfile)]
            if i==2:argv+=['--globalize-symbol='+mapping[target]]
            subprocess.run([*argv,str(path),str(clone)],check=True)
            symbols=run(['readelf','-Ws',clone]);groups=run(['readelf','--section-groups',clone])
            (folder/(member+'.after-symbols.txt')).write_text(symbols)
            (folder/(member+'.after-groups.txt')).write_text(groups)
            after_defined=names(nm(clone,'--defined-only','--extern-only'))
            assert after_defined=={mapping[n] for n in before[member]['defined']}|({mapping[target]} if i==2 else set())
            after_undefined=names(nm(clone,'--undefined-only'))
            assert after_undefined=={mapping.get(n,n) for n in before[member]['undefined']}
            assert all(s.startswith('g04_'+arm+'_') for s in re.findall(r'COMDAT group section.*?\[([^\]]+)\] contains',groups))
            row={'original':str(path),'original_sha256':before[member]['sha256'],'clone':str(clone),'clone_sha256':sha(clone.read_bytes()),
                 'defined_names_all_renamed':True,'undefined_edges_exactly_remapped':True,
                 'undefined_original':sorted(before[member]['undefined']),'undefined_after':sorted(after_undefined),
                 'defined_count':len(before[member]['defined']),'COMDAT_signatures_all_renamed':True,'IFUNC_count':0,'legacy_linkonce_sections':0}
            if i in (1,2):
                for label,item in (('original',path),('clone',clone)):
                    image=folder/(destination+'.'+label+'.fatbin')
                    subprocess.run(['objcopy','--dump-section','.nv_fatbin='+str(image),str(item)],check=True)
                    row[label+'_fatbin_sha256']=sha(image.read_bytes())
                assert row['original_fatbin_sha256']==row['clone_fatbin_sha256']
                row['fatbin_unchanged']=True
            objects.append(row)
        exported[arm]=set.union(*(names(nm(folder/name,'--defined-only','--extern-only')) for name in DESTINATIONS))
        # Prove both cold planning and warm dispatch route to this arm's batch,
        # and that this arm's batch points to this arm's cache implementation.
        provider_undefined=names(nm(folder/'provider.o','--undefined-only'))
        batch_undefined=names(nm(folder/'batch.o','--undefined-only'))
        run_batch=[n for n in before[MEMBERS[0]]['undefined'] if '9run_batchE' in n]
        run_cache=[n for n in before[MEMBERS[1]]['undefined'] if '15run_cache_batchE' in n]
        assert len(run_batch)==len(run_cache)==1,(run_batch,run_cache)
        assert mapping[run_batch[0]] in provider_undefined and mapping[run_cache[0]] in batch_undefined
        record['arms'][arm]={'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),
                            'factory_alias':mapping[FACTORY],'attention_stub_alias':mapping[target],
                            'original_attention_stub':target,'objects':objects,
                            'provider_run_batch_edge':mapping[run_batch[0]],'batch_run_cache_edge':mapping[run_cache[0]],
                            'renamed_defined_count':len(defined),'renamed_COMDAT_count':len(signatures),'rename_map_sha256':sha(mapfile.read_bytes())}
    assert not exported['c2']&exported['c5']
    record['no_shared_defined_external_names_between_arms']=True
    (OUT/'isolation-identity.json').write_text(json.dumps(record,indent=2)+'\n')
    (WORK/'isolation-identity.json').write_bytes((OUT/'isolation-identity.json').read_bytes())
    print(json.dumps({'three_owner_closures_complete':True,'objects':6,'isolation_sha256':sha((OUT/'isolation-identity.json').read_bytes())}))


if __name__=='__main__':main()
