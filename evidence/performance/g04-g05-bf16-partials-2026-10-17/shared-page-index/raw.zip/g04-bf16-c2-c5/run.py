"""Exclusive ordinary run, only invoked by the sole GPU runner."""
from pathlib import Path
import hashlib,json,os,subprocess,time

repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/g04-bf16-c2-c5'
work=Path('/root/hyle-scratch/compute-unified/g04-bf16-c2-c5')
binary=work/'product_c2_c5';source=out/'consumer.cc'
isolation=json.loads((out/'isolation-identity.json').read_text())
linked=json.loads((out/'build-link.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert linked['returncode']==0 and linked['original_FI_three_members_extracted']==[]
assert sha(source.read_bytes())==linked['source_sha256']==isolation['source_sha256']
assert sha(binary.read_bytes())==linked['binary_sha256']
assert not os.environ.get('G04_TRACE')
for arm in isolation['arms'].values():
    for obj in arm['objects']:assert sha(Path(obj['clone']).read_bytes())==obj['clone_sha256']
dest=out/'run-ordinary-1';dest.mkdir(exist_ok=False)
(dest/'consumer.cc').write_bytes(source.read_bytes());(dest/'consumer').write_bytes(binary.read_bytes())
identity={'argv':[str(binary)],'source_sha256':linked['source_sha256'],'binary_sha256':linked['binary_sha256'],
          'isolation_identity_sha256':sha((out/'isolation-identity.json').read_bytes()),
          'predeclared_schedule':'32x128 pairs, 2capture x 2allocation x 2execution; target only plus tail oracle; both opt-in/11MiB',
          'isolation':isolation,'started_unix':time.time()}
gpu=subprocess.run(['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,uuid,driver_version,memory.used,temperature.gpu','--format=csv,noheader'],capture_output=True,text=True)
identity['gpu_pre']={'returncode':gpu.returncode,'stdout':gpu.stdout,'stderr':gpu.stderr}
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({'argv':identity['argv'],'dest':str(dest)}),flush=True)
start=time.monotonic()
with (dest/'stdout.log').open('w') as stdout,(dest/'stderr.log').open('w') as stderr:
    result=subprocess.run(identity['argv'],stdout=stdout,stderr=stderr)
identity.update({'returncode':result.returncode,'elapsed_s':time.monotonic()-start})
(dest/'result.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({'returncode':result.returncode,'elapsed_s':identity['elapsed_s']}),flush=True)
raise SystemExit(result.returncode)
