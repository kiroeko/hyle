from pathlib import Path
import hashlib,json,os,subprocess,time
OUT=Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-bf16-c5-peer')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
link=json.loads((OUT/'link-result.json').read_text());assert link['returncode']==0
assert not os.environ.get('G04_TRACE');assert sha(link['binary'])==link['binary_sha256'];assert sha(OUT/'consumer.cc')==link['source_sha256']
for path,value in link['unchanged_original_host_objects'].items():assert sha(path)==value
for path,value in link['linked_static_archives'].items():assert sha(path)==value
out=OUT/'run-ordinary-1';out.mkdir(exist_ok=False)
(out/'consumer.cc').write_bytes((OUT/'consumer.cc').read_bytes())
(out/'consumer').write_bytes(Path(link['binary']).read_bytes())
gpu=subprocess.run(['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,uuid,driver_version,memory.used,temperature.gpu','--format=csv,noheader'],capture_output=True,text=True)
identity={'argv':[link['binary']],'source_sha256':link['source_sha256'],'binary_sha256':link['binary_sha256'],'link_identity':link,'gpu_pre':{'returncode':gpu.returncode,'stdout':gpu.stdout,'stderr':gpu.stderr},'started_unix':time.time(),'schedule':'Original fixed32768pairs normal/replay x2alloc x2execute x32groups x128pairs; tail oracle only; all-tail complete-episode arithmetic mean; C5FP8optin vs same-source plainBF16'}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps({'argv':identity['argv'],'destination':str(out)}),flush=True)
with (out/'stdout.log').open('w') as so,(out/'stderr.log').open('w') as se:r=subprocess.run(identity['argv'],stdout=so,stderr=se)
identity.update(returncode=r.returncode,elapsed_s=time.time()-identity['started_unix']);(out/'result.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps({'returncode':r.returncode,'elapsed_s':identity['elapsed_s']}),flush=True);raise SystemExit(r.returncode)
