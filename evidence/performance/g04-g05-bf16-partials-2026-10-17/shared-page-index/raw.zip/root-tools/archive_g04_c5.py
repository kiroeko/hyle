from pathlib import Path
import hashlib
import json
import zipfile

repo = Path(__file__).resolve().parents[1]
dest = repo / 'evidence/performance/g04-g05-bf16-partials-2026-10-17/shared-page-index'
names = [
    'g04-bf16-product-c5-shared-page-index', 'g04-bf16-c5',
    'g04-bf16-c5-codegen', 'g04-bf16-c2-c5',
    'g04-bf16-c5-validation', 'g04-bf16-c5-peer', 'g04-bf16-ncu-c5',
    'g04-bf16-product-c5-vendor',
]
independent = [
    'product-c5-source-review.json', 'product-c5-codegen-review.json',
    'product-c5-codegen-runtime-review.json',
    'product-c2-c5-analysis.json', 'product-c2-c5-all-matrices.csv',
    'product-ncu-c5-review.json', 'product-c5-peer-analysis.json',
    'product-c5-peer-all-matrices.csv', 'analyze_c2_c5_product.py',
]
skip_dirs = {'vendor-shadow', 'materialized-production', 'materialized-canonical', 'upstream', '__pycache__'}
sha = lambda data: hashlib.sha256(data).hexdigest()

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--decision', required=True)
    args = parser.parse_args()
    dest.mkdir(exist_ok=True)
    entries, external = [], []
    with zipfile.ZipFile(dest / 'raw.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in names:
            source = repo / '.scratch' / name
            for path in sorted(source.rglob('*')):
                relative = path.relative_to(source)
                if not path.is_file() or any(part in skip_dirs for part in relative.parts):
                    continue
                data = path.read_bytes()
                item = {'path': name + '/' + relative.as_posix(), 'bytes': len(data), 'sha256': sha(data)}
                if path.suffix in {'.ncu-rep', '.o', '.a', '.exe', '.cubin'} or data[:4] == b'\x7fELF':
                    external.append(dict(item, local_path=str(path), archived=False))
                    continue
                archive.writestr(item['path'], data)
                entries.append(item)
        for name in independent:
            path = repo / '.scratch/g04-g05-sameprocess-review' / name
            if not path.is_file():
                continue
            data = path.read_bytes()
            archive.writestr('independent/' + name, data)
            entries.append({'path': 'independent/' + name, 'bytes': len(data), 'sha256': sha(data)})
        for name in ['apply_g04_c5.py', 'verify_g04_c5_canonical.py', 'archive_g04_c5.py']:
            data = (repo / '.scratch' / name).read_bytes()
            archive.writestr('root-tools/' + name, data)
            entries.append({'path': 'root-tools/' + name, 'bytes': len(data), 'sha256': sha(data)})
    raw = (dest / 'raw.zip').read_bytes()
    result = {'archive': 'raw.zip', 'archive_bytes': len(raw), 'archive_sha256': sha(raw),
              'entries': entries, 'external_local_artifacts': external, 'product_decision': args.decision}
    (dest / 'archive.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({'archive_bytes': len(raw), 'files': len(entries), 'archive_sha256': sha(raw)}))

if __name__ == '__main__':
    main()
