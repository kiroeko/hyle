from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil

repo = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
base_dir = repo / '.scratch/g04-bf16-product-c4-k-pair-prefetch'
sha = lambda data: hashlib.sha256(data).hexdigest()
original = (base_dir / 'prefill.cuh').read_bytes()
assert sha(original) == 'ecf0b1cf43fabddffb34b6c40f5e1686e2a35e9a9a6fd1087bdc51b6c618b6b9'
source = original.decode()
anchor = '        const uint32_t next_packed_page_iter_base =\n'
assert source.count(anchor) == 1
prefix, suffix = source.split(anchor)
before = '''            thr_local_kv_offset_k[i] = paged_kv.protective_get_k_offset(
                page_iter, kv_head_idx, entry_idx, feat_idx, last_indptr);
            thr_local_kv_offset_v[i] = paged_kv.protective_get_v_offset(
                page_iter, kv_head_idx, entry_idx, feat_idx, last_indptr);
'''
after = '''            if constexpr (hyle_bf16_k_pair_prefetch_scope<KTraits>) {
              // Share the immutable page index; K and V retain their own strides.
              const IdType guarded_page_iter = static_cast<IdType>(page_iter);
              if (guarded_page_iter < last_indptr) {
                const IdType page_idx = __ldg(paged_kv.indices + guarded_page_iter);
                thr_local_kv_offset_k[i] =
                    paged_kv.get_elem_offset(page_idx, kv_head_idx, entry_idx, feat_idx);
                thr_local_kv_offset_v[i] =
                    paged_kv.get_v_elem_offset(page_idx, kv_head_idx, entry_idx, feat_idx);
              } else {
                thr_local_kv_offset_k[i] = 0;
                thr_local_kv_offset_v[i] = 0;
              }
            } else {
              thr_local_kv_offset_k[i] = paged_kv.protective_get_k_offset(
                  page_iter, kv_head_idx, entry_idx, feat_idx, last_indptr);
              thr_local_kv_offset_v[i] = paged_kv.protective_get_v_offset(
                  page_iter, kv_head_idx, entry_idx, feat_idx, last_indptr);
            }
'''
assert suffix.count(before) == 1
suffix = suffix.replace(before, after)
source = prefix + anchor + suffix
assert source.replace(after, before).encode() == original
for pattern in [r'^.*block\.sync\(\).*$', r'^.*cp_async::.*$',
                r'^.*page_produce_kv<true, KTraits>.*$', r'^.*hyle_prefetch_packed_k_vector\(.*$']:
    assert re.findall(pattern, source, re.M) == re.findall(pattern, original.decode(), re.M), pattern
candidate = source.encode()
(out / 'prefill.cuh').write_bytes(candidate)
(out / 'candidate.patch').write_bytes(''.join(difflib.unified_diff(
    original.decode().splitlines(True), source.splitlines(True),
    fromfile='C4-K-pair-prefetch/prefill.cuh', tofile='C5-shared-page-index/prefill.cuh')).encode())
shadow = out / 'vendor-shadow'
shutil.copytree(base_dir / 'vendor-shadow', shadow)
(shadow / 'include/flashinfer/attention/prefill.cuh').write_bytes(candidate)
base_files = json.loads((base_dir / 'shadow-files.json').read_text())
files = {p.relative_to(shadow).as_posix(): sha(p.read_bytes()) for p in shadow.rglob('*') if p.is_file()}
assert len(files) == 2576 and files.keys() == base_files.keys()
assert [p for p in files if files[p] != base_files[p]] == ['include/flashinfer/attention/prefill.cuh']
(out / 'shadow-files.json').write_bytes((json.dumps(files, indent=2) + '\n').encode())
plan = {
    'state': 'SCRATCH_C5_SOURCE_ONLY_BEFORE_COMPILE',
    'canonical_product_modified': False, 'cuda_compiled': False, 'gpu_executed': False,
    'C4_base_header_sha256': sha(original),
    'C2_native_source_sha256': '8095820397cef116e4ecbc7dae4d6dedb28910000784e267703c88482767295b',
    'candidate_header_sha256': sha(candidate), 'candidate_patch_sha256': sha((out / 'candidate.patch').read_bytes()),
    'change': 'Only main-loop next-tile K/V page-index lookup is shared once in the existing C4 scope; initial lookup and all other branches remain C4.',
    'gate': 'Existing hyle_bf16_k_pair_prefetch_scope: SM89 only, private BF16 marker, E4M3 directstage, BF16 Q/O, causal, D256, CTA64, MMA_KV1, Q/KVwarps4/1.',
    'guard': 'Convert uint32 page_iter to IdType exactly as the original protective function parameter conversion, then compare IdType against IdType last_indptr. Only a true guard loads indices+guarded_page_iter; false sets both offsets0.',
    'strides': 'Pass the same IdType page_id separately to original get_elem_offset and get_v_elem_offset. K and V page/head/entry strides stay independent; negative page_id conversion to size_t is unchanged from the original methods.',
    'unchanged': 'All C4 dual-K prefetch, decoder, V producer, K publication, scales, barriers, commit/wait and defaultF32 code retained. No new synchronization or global write.',
    'diagnostic_limit': 'Same-address duplicate page loads are observed in both C2 and C4. C4 new long-scoreboard sample is at a V-offset consumer, but a sampled instruction does not identify every waited hardware barrier. Compile/runtime may confirm or falsify the scheduling benefit.',
    'full_shadow': {
        'files': len(files), 'path': str(shadow), 'only_changed_file_from_C4': 'include/flashinfer/attention/prefill.cuh',
        'inventory_sha256': sha(''.join(p + '|' + h + '\n' for p, h in sorted(files.items())).encode()),
        'inventory_algorithm': 'sha256(sorted relative_path|raw_sha256 LF)',
        'shadow_files_json_sha256': sha((out / 'shadow-files.json').read_bytes())}}
(out / 'source-plan.json').write_bytes((json.dumps(plan, indent=2) + '\n').encode())
build = (base_dir / 'build_c4.py').read_text()
build = build.replace('g04-bf16-product-c4-k-pair-prefetch', 'g04-bf16-product-c5-shared-page-index')
build = build.replace('g04-bf16-c4', 'g04-bf16-c5').replace('C4_', 'C5_').replace('_c4.a', '_c5.a')
build = build.replace(sha(original), sha(candidate))
build = build.replace('both16B raw K prefetch before softmax in finite BF16 marker domain, SM89 only; independent shadow prefill header',
                      'C4 dual-K prefetch plus one shared next-page index load for K/V, finite BF16 marker/SM89 domain only')
(out / 'build_c5.py').write_bytes(build.encode())
print(json.dumps(plan, indent=2), flush=True)
