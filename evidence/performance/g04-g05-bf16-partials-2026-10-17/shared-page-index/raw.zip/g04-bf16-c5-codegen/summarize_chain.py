from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
review_path = OUT / 'review.json'
review = json.loads(review_path.read_text())
rows_path = OUT / 'c5-rows.json'
rows = json.loads(rows_path.read_text())['bf16-prefill']
by_pc = {int(x['pc'], 16): x['sass'] for x in rows}
expected = {
    0x3030: '@!P1 LDG.E.128 R136, [R150.64] ;',
    0x3040: '@!P1 LDG.E.128 R140, [R150.64+0x80] ;',
    0x3ac0: 'BAR.SYNC 0x0 ;',
    0x3ae0: 'PRMT R136, R136, 0x1302, R136 ;',
    0x3b70: 'PRMT R149, R140, 0x1302, R140 ;',
    0x43c0: '@!P1 LDG.E.128 R136, [R246.64] ;',
    0x43f0: '@!P1 LDG.E.128 R144, [R246.64+0x80] ;',
}
for pc, instruction in expected.items():
    assert by_pc[pc] == instruction, (hex(pc), by_pc[pc])
ex2 = [int(x['pc'], 16) for x in rows if 'MUFU.EX2' in x['sass']]
assert min(ex2) == 0x3150 and max(ex2) == 0x3580
assert 0x3030 < 0x3040 < min(ex2) <= max(ex2) < 0x3ac0 < 0x3ae0 < 0x3b70
for first, start, end in [(136, 0x3040, 0x3ae0), (140, 0x3060, 0x3b70)]:
    for x in rows:
        pc = int(x['pc'], 16)
        if not start <= pc < end:
            continue
        s = re.sub(r'^@!?U?P(?:\d+|T)\s+', '', x['sass'])
        m = re.match(r'([A-Z0-9_.]+)\s+R(\d+)(?:,|\.)', s)
        # Include multi-register destinations, rather than checking only the
        # first register of a vector write. The prefetch load itself is outside
        # each interval.
        if m:
            op = m[1]
            width = 1
            if op.startswith(('CS2R', 'IMAD.WIDE')) or op.endswith('.64'):
                width = 2
            if op.startswith('HMMA.') or (op.startswith('LDSM.') and op.endswith('.4')) or op.endswith('.128'):
                width = 4
            written = set(range(int(m[2]), int(m[2]) + width))
            assert not written.intersection(range(first, first + 4)), (hex(pc), s)
local_memory = [x for x in rows if re.search(r'\b(?:LDL|STL)(?:\.|\s)', x['sass'])]
assert not local_memory
target = review['current']['kernels']['bf16-prefill']
assert 'REG:250 STACK:0 SHARED:0 LOCAL:0' in target['resource']
unchanged = [x for x in review['comparisons'] if x['kind'] != 'bf16-prefill']
assert len(unchanged) == 3
assert all(x['instructions_equal'] and x['encoded_schedule_words_equal'] and x['resource_equal'] for x in unchanged)
pv = [int(x['pc'], 16) for x in rows if int(x['pc'], 16) > 0x4400 and 'HMMA.16816.F32.BF16' in x['sass']]
assert min(pv) == 0x44a0 and max(pv) == 0x4740
assert 0x43c0 < 0x43f0 < min(pv) <= max(pv) < 0x4750
store_pcs = [int(x['pc'], 16) for x in rows if 0x3ac0 < int(x['pc'], 16) < 0x4100 and 'STS.128' in x['sass']]
assert store_pcs == [0x4090, 0x40c0, 0x40d0, 0x40e0]

result = {
    'scope': 'Actual SM89 C5 scheduling/resource observations versus retained C2; CPU-only inspection',
    'canonical_modified': False,
    'GPU_executed_by_this_analysis': False,
    'bindings': {str(p.relative_to(ROOT)): sha(p) for p in [
        review_path, rows_path, OUT / 'c5-sass.txt', OUT / 'c5-resources.txt',
        ROOT / '.scratch/g04-bf16-c5/archive-result.json',
        ROOT / '.scratch/g04-bf16-product-c5-shared-page-index/source-plan.json',
        ROOT / '.scratch/g04-bf16-product-c5-shared-page-index/candidate.patch']},
    'target': target,
    'observed_K': {
        'first_raw_LDG': {'pc': '0x3030', 'sass': by_pc[0x3030], 'payload': 'R136..R139'},
        'second_raw_LDG': {'pc': '0x3040', 'sass': by_pc[0x3040], 'payload': 'R140..R143'},
        'softmax_EX2_PCs': [hex(x) for x in ex2],
        'publish_barrier': {'pc': '0x3ac0', 'sass': by_pc[0x3ac0]},
        'first_raw_consumer': {'pc': '0x3ae0', 'sass': by_pc[0x3ae0]},
        'second_raw_consumer': {'pc': '0x3b70', 'sass': by_pc[0x3b70]},
        'payloads_not_overwritten_between_load_and_first_decode': True,
        'all4_BF16_shared_vector_stores': [hex(x) for x in store_pcs],
        'observation': 'Both K global reads are before every main-loop softmax EX2. Both payloads remain in registers until decoder use after the original publication barrier. The machine schedule actually implements the source intent.'
    },
    'V': {'raw_loads': ['0x43c0', '0x43f0'], 'PV_HMMA_range': [hex(min(pv)), hex(max(pv))],
          'first_decode_PRMT': '0x4750',
          'observation': 'Both V loads remain ahead of PV; C5 has not pushed either read behind PV.'},
    'unchanged_selected_kernels': [
        {'kind': x['kind'], 'complete_128bit_instruction_and_control_words_equal': True,
         'codewords_sha256': x['C5']['codewords_sha256'], 'resource': x['C5']['resource']} for x in unchanged],
    'local_memory_instruction_PCs': local_memory,
    'resources': {
        'C2_REG': 246, 'C5_REG': 250, 'C5_STACK_bytes': 0, 'C5_LOCAL_bytes': 0,
        'C5_static_shared_bytes': 0,
        'expected_dynamic_shared_bytes_from_unchanged_KTraits': 49152,
        'expected_CTA_threads_from_unchanged_KTraits': 128,
        'SM89_register_allocation_estimate': {
            'reported_per_thread': 250, 'rounded_per_thread': 256,
            'rounded_per_warp': 8192, 'registers_per_128thread_CTA': 32768,
            'register_limited_resident_CTAs': 2,
            'limits': 'Header-formula estimate only. Actual C5 launch attributes/occupancy belong to the runner. C2 actual NCU register and shared-memory limits were both2.'}},
    'limits': [
        'No numerical, sanitizer or performance pass is supplied by static codegen. C5 correctness and complete ordinary public latency are measured separately by the sole GPU runner.',
        'The target prefill differs in full machine schedule and register allocation; it is not asserted byte-identical to C2. Its decoder instructions are interleaved across the two vectors while retaining the same decoder/store math.',
        'Static PC distances are scheduling opportunity, not a cycle count or guaranteed hidden latency.',
        'DefaultF32 and both merge statements concern the three exact selected D256 kernels. Other architecture machine code was not compiled here; the source restricts new prefetch to __CUDA_ARCH__==890.',
        'Static resource SHARED:0 excludes launch-time dynamic shared memory; it does not mean the attention uses no shared memory.'
    ]
}
controls_path = OUT / 'controls-review.json'
controls = json.loads(controls_path.read_text())
control_by_pc = {int(x['pc'], 16): x for x in controls['all_rows']}
assert len(controls['mainloop_constant_global_loads']) == 1
assert controls['mainloop_constant_global_loads'][0]['pc'] == '2680'
assert controls['mainloop_constant_global_loads'][0]['write_counter'] == 3
assert control_by_pc[0x2bb0]['wait_counters'] == [3]
assert by_pc[0x2c10] == '@!P6 IMAD.WIDE.U32 R136, R169, c[0x0][0x188], R136 ;'
assert by_pc[0x3090] == '@!P6 IMAD.WIDE.U32 R146, R169, c[0x0][0x194], R146 ;'
assert not control_by_pc[0x3090]['wait_counters']
assert all(x['first_wait_after_all_EX2'] for x in controls['early_K_loads_and_first_counter_waits'])
result['bindings'][str(controls_path.relative_to(ROOT))] = sha(controls_path)
result['shared_page_index_and_wait_placement'] = {
    'mainloop_single_page_index_load': controls['mainloop_constant_global_loads'][0],
    'first_index_consumer': control_by_pc[0x2bb0],
    'same_index_K_stride_consumer': control_by_pc[0x2c10],
    'same_index_V_stride_consumer': control_by_pc[0x3090],
    'K_loads_and_first_write_counter_waits': controls['early_K_loads_and_first_counter_waits'],
    'actual_difference_from_C4': 'The page-index read usesW3, cleared at2bb0; the sameR169 feeds Kstride188 and Vstride194. V calculation3090 has no wait. Both raw-K loads useW5 and first wait at3ae0 after allEX2. The C4 mid-softmax wait-for5 at3270 is absent.',
    'limits': 'Counter interpretation uses the explicitly pinned primary reverse-engineered implementation. This is machine-schedule evidence, not hardware timing or proof of measured gain.'}
(OUT / 'mechanism-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'mechanism-review.json'), 'sha256': sha(OUT / 'mechanism-review.json')}, indent=2))
