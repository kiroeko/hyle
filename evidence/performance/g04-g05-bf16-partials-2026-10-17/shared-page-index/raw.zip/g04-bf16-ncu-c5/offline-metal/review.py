from pathlib import Path
from collections import Counter
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = {v: ROOT / f'.scratch/{d}/offline-metal/report-api.json' for v, d in [
    ('C2', 'g04-bf16-ncu-source'), ('C4', 'g04-bf16-ncu-c4'), ('C5', 'g04-bf16-ncu-c5')]}
reports = {v: json.loads(p.read_text()) for v, p in paths.items()}
assert reports['C5']['sha256'] == '446b6e2da0073c5627c8abe7824d81efe7e3945818f7e8c4aa8dbccb95afaa4d'
static = {v: {int(x['pc'], 16): x['sass'] for x in json.loads((ROOT / f'.scratch/g04-bf16-{v.lower()}-codegen/{v.lower()}-rows.json').read_text())['bf16-prefill']} for v in reports}
codegen = {v: json.loads((ROOT / f'.scratch/g04-bf16-{v.lower()}-codegen/review.json').read_text()) for v in reports}
def normal(s, base=0):
    if re.search(r'\b(?:BRA|BSSY|CALL)\b', s):
        s = re.sub(r'0x[0-9a-fA-F]+', lambda m: hex(int(m[0], 16) - base) if int(m[0], 16) >= base else m[0], s)
    return ''.join(s.replace('.reuse', '').replace(',', '').rstrip(' ;').split())
def op(s):
    return re.sub(r'^@!?U?P(?:\d+|T)\s+', '', s.strip()).split()[0].split('.')[0]
points = {
    'C2': {'initial_metadata_consumer': 0xd70, 'initial_K_consumer': 0x1140,
           'initial_V_consumer': 0x14c0, 'K_page_consumer': 0x3190, 'V_page_consumer': 0x2fa0,
           'V_stride_consumer': 0x3ad0, 'first_main_K_payload_consumer': 0x3b20, 'second_main_K_payload_consumer': 0x3ef0,
           'prepublish_BAR': 0x2f00, 'following_prepub_instruction': 0x2f10},
    'C4': {'initial_metadata_consumer': 0xd70, 'initial_K_consumer': 0x1140,
           'initial_V_consumer': 0x14c0, 'K_page_consumer': 0x2b90,
           'V_page_consumer_and_premature_group_wait': 0x3270,
           'first_main_K_payload_consumer': 0x3b30, 'second_main_K_payload_consumer': 0x3bc0,
           'prepublish_BAR': 0x3b10, 'following_prepub_instruction': 0x3b20},
    'C5': {'initial_metadata_consumer': 0xd70, 'initial_K_consumer': 0x1140,
           'initial_V_consumer': 0x14c0, 'shared_page_load': 0x2680, 'shared_page_first_consumer': 0x2bb0,
           'K_stride_consumer': 0x2c10, 'V_stride_consumer_no_wait': 0x3090,
           'first_main_K_payload_consumer_and_W5_group_wait': 0x3ae0, 'second_main_K_payload_consumer': 0x3b70,
           'prepublish_BAR': 0x3ac0, 'following_prepub_instruction': 0x3ad0}}
results = {}
for variant, report in reports.items():
    actions = []
    for action in report['actions']:
        m = action['selected_metrics']
        base = m['launch__function_pcs']['instances'][0]['value']
        inst = m['inst_executed']['instances']
        assert sum(i['value'] for i in inst) == m['inst_executed']['scalar']
        opcode = Counter()
        decoder = Counter()
        for i in inst:
            s = i['sass']; opcode[op(s)] += i['value']
            if 'PRMT' in s and '0x1302' in s: decoder['PRMT_1302'] += i['value']
            elif 'LOP3' in s and any(k in s for k in ['0x80008000', '0x7f007f00', '0x7f007f0,']): decoder['LOP3_packed_fp8_fields'] += i['value']
            elif 'LEA.HI' in s and s.rstrip().endswith('0x1c'): decoder['LEA_HI_shift28'] += i['value']
            elif 'HFMA2.BF16_V2' in s and '1.329227' in s: decoder['HFMA2_BF16_times2p120'] += i['value']
        metrics = {}
        for name, metric in m.items():
            if name.startswith('smsp__pcsamp_') and metric['instances']:
                assert sum(i['value'] for i in metric['instances']) == metric['scalar']
                by_pc = {i['id'] - base: i['value'] for i in metric['instances']}
                metrics[name] = {'sum': metric['scalar'], 'by_relative_PC': {hex(k): v for k, v in by_pc.items() if v}}
        item = {'action': action['action'], 'arm': 'FP8' if action['action'] % 2 else 'plain_BF16',
                'mangled_name': action['mangled_name'], 'function_base': base,
                'dynamic_inst': m['inst_executed']['scalar'], 'per_opcode': dict(sorted(opcode.items())),
                'decoder_exact_fingerprints': dict(decoder), 'decoder_fingerprint_total': sum(decoder.values()),
                'metrics': metrics, 'overflow': m['smsp__pcsamp_buffer_overflow']['scalar'],
                'dropped_bytes': m['smsp__pcsamp_dropped_bytes']['scalar']}
        if action['action'] % 2:
            assert action['mangled_name'] == codegen[variant]['current']['symbols']['bf16-prefill']
            for i in inst:
                pc = i['id'] - base
                assert pc in static[variant]
                assert normal(i['sass'], base) == normal(static[variant][pc]), (variant, hex(pc), i['sass'], static[variant][pc])
            item['all_exported_instruction_PCs_match_retained_exact_kernel_SASS'] = len(inst)
            item['semantic_points'] = {name: {'pc': hex(pc), 'sass': static[variant][pc],
                'samples': {k: v['by_relative_PC'].get(hex(pc), 0) for k, v in metrics.items()}}
                for name, pc in points[variant].items()}
            long = m['smsp__pcsamp_warps_issue_stalled_long_scoreboard_not_issued']
            inst_by_pc = {i['id'] - base: i['sass'] for i in inst}
            item['top_long_scoreboard_PCs'] = [{'pc': hex(i['id'] - base), 'samples': i['value'], 'sass': inst_by_pc.get(i['id'] - base)}
                for i in sorted(long['instances'], key=lambda i: i['value'], reverse=True)[:15]]
        actions.append(item)
    assert actions[0]['dynamic_inst'] == actions[2]['dynamic_inst'] == 2466704
    assert actions[1]['dynamic_inst'] == actions[3]['dynamic_inst']
    assert actions[1]['per_opcode'] == actions[3]['per_opcode']
    results[variant] = actions

c5 = results['C5'][1]
assert c5['dynamic_inst'] == 3428864
assert c5['decoder_fingerprint_total'] == 646144
assert c5['decoder_exact_fingerprints'] == results['C4'][1]['decoder_exact_fingerprints'] == results['C2'][1]['decoder_exact_fingerprints']
assert all(not a['decoder_fingerprint_total'] for v in results.values() for a in v if a['arm'] == 'plain_BF16')
for name in ['HMMA', 'MUFU', 'FMUL', 'LDSM']:
    assert len({a['per_opcode'].get(name) for v in results.values() for a in v}) == 1, name
deltas = {}
for label, a, b in [('C2_to_C4', 'C2', 'C4'), ('C4_to_C5', 'C4', 'C5'), ('C2_to_C5', 'C2', 'C5')]:
    aa, bb = results[a][1], results[b][1]
    deltas[label] = {'total': bb['dynamic_inst'] - aa['dynamic_inst'],
        'per_opcode': {k: bb['per_opcode'].get(k, 0) - aa['per_opcode'].get(k, 0) for k in sorted(set(aa['per_opcode']) | set(bb['per_opcode']))}}
review = {
    'scope': 'Independent CPU-only C5 minimal6 NCU review versus retained C2 and rejectedC4; no GPU/compile/canonical changes',
    'inputs': {v: {'path': str(p), 'sha256': sha(p), 'report_sha256': reports[v]['sha256']} for v, p in paths.items()},
    'SASS_bindings': {v: {'review': str(ROOT / f'.scratch/g04-bf16-{v.lower()}-codegen/review.json'),
        'sha256': sha(ROOT / f'.scratch/g04-bf16-{v.lower()}-codegen/review.json')} for v in reports},
    'C5_control_review': {'path': '.scratch/g04-bf16-c5-codegen/controls-review.json', 'sha256': sha(ROOT / '.scratch/g04-bf16-c5-codegen/controls-review.json')},
    'results': results, 'dynamic_instruction_deltas': deltas,
    'interpretation': [
        'The actual runtimeC5 mangled kernel and every2010 exported instruction PC match the retainedC5 SASS opcode/operands after tool-text normalization of whitespace, commas, .reuse rendering and absolute branch targets. Full static128bit codeword identity is separately bound by the retained codegen files. PC offsets are computed separately from each action function base; no absolute-PC matching or row-position zip is used.',
        'C5 first write-counter5 wait at3ae0 after allEX2 has133/124 long-scoreboard samples; second payload consumer3b70 has0/0. Since both raw-K loads shareW5, those133/124 events cannot be assigned solely to the first vector.',
        'C4 premature V-address/group wait at3270 had248/280 samples. C5 shared index2680, its first consumer2bb0, and V offset3090 are no longer a corresponding dominant wait point. C5:3270 is now FMUL, so matching the old numericPC would be semantically wrong.',
        'Initial page-index consumer d70 remains128/140 and initialK1140 remains73/65. These source stages were not the C5 target. Remaining long samples also occur in initialization and output metadata, so there is no complete hiding claim.',
        'Dynamic warp instructions fall from3476384(C2) to3453104(C4) to3428864(C5), with the same2466704 plain control in all reports. C5 still executes962160 extra instructions versus plain, about39.0%.',
        'HMMA315120, MUFU90400, FMUL681856 and LDSM232704 match allFP8/plain actions. Four exact decoder fingerprints remain646144 instructions in everyFP8 version and0 in plain: PRMT80768, packed-fieldLOP3323072, shift28LEA80768, BF16HFMA2161536. Metadata/prefetch optimization has not removed that software conversion work.',
        'The four decoder fingerprints deliberately exclude ambiguous IMAD shifts that can also appear in address math. Their totals are instruction work, not a microsecond budget or proof that an arbitrary fewer-opcode conversion is faster.'
    ],
    'limits': [
        'The profile is a diagnostic with profiler replay/cache/clock effects. Ordinary normal/replay paired measurements are independent and are the performance verdict; no sampled duration replaces them.',
        'Cross-run changes in sample totals or percentages are not elapsed-time shares, and are not converted to a cost ledger in microseconds.',
        'Write-counter grouping follows an explicitly pinned primary reverse-engineered decoder and research, not an NVIDIA official SM89 ABI. Counter waits can cover several producers.',
        'No barrier_notissued category was collected. All-state samples at BAR or its successor do not independently determine CTA synchronization cost.',
        'No new CUDA module, GPU sampling, product variant or canonical edit was performed by this analysis.'
    ]}
(OUT / 'independent-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'independent-review.json'), 'sha256': sha(OUT / 'independent-review.json'), 'deltas': deltas}, indent=2))
