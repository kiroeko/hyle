from pathlib import Path
from collections import Counter
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = {v: ROOT / f'.scratch/{d}/offline-metal/report-api.json' for v, d in [
    ('C2', 'g04-bf16-ncu-source'), ('C4', 'g04-bf16-ncu-c4'), ('C5', 'g04-bf16-ncu-c5'), ('C6', 'g04-bf16-ncu-c6')]}
reports = {v: json.loads(p.read_text()) for v, p in paths.items()}
assert reports['C6']['sha256'] == '943937c370872fcf6fb8387913e38ccc99cf78cbc969ad8324f4b7cca46b2a8c'
assert reports['C5']['sha256'] == '446b6e2da0073c5627c8abe7824d81efe7e3945818f7e8c4aa8dbccb95afaa4d'
static = {v: {int(x['pc'], 16): x['sass'] for x in json.loads((ROOT / f'.scratch/g04-bf16-{v.lower()}-codegen/{v.lower()}-rows.json').read_text())['bf16-prefill']} for v in reports}
codegen = {v: json.loads((ROOT / f'.scratch/g04-bf16-{v.lower()}-codegen/review.json').read_text()) for v in reports}
def normal(s, base=0):
    if re.search(r'\b(?:BRA|BSSY|CALL)\b', s):
        s = re.sub(r'0x[0-9a-fA-F]+', lambda m: hex(int(m[0], 16) - base) if int(m[0], 16) >= base else m[0], s)
    return ''.join(s.replace('.reuse', '').replace(',', '').rstrip(' ;').split())
def op(s):
    return re.sub(r'^@!?U?P(?:\d+|T)\s+', '', s.strip()).split()[0].split('.')[0]
points = {
    'C2': {'initial_metadata_consumer': 0xd70, 'initial_K_consumer': 0x1140,
           'initial_V_consumer': 0x14c0, 'K_page_consumer': 0x3190, 'V_page_consumer': 0x2fa0,
           'V_stride_consumer': 0x3ad0, 'first_main_K_payload_consumer': 0x3b20, 'second_main_K_payload_consumer': 0x3ef0,
           'prepublish_BAR': 0x2f00, 'following_prepub_instruction': 0x2f10},
    'C4': {'initial_metadata_consumer': 0xd70, 'initial_K_consumer': 0x1140,
           'initial_V_consumer': 0x14c0, 'K_page_consumer': 0x2b90,
           'V_page_consumer_and_premature_group_wait': 0x3270,
           'first_main_K_payload_consumer': 0x3b30, 'second_main_K_payload_consumer': 0x3bc0,
           'prepublish_BAR': 0x3b10, 'following_prepub_instruction': 0x3b20},
    'C5': {'initial_metadata_consumer': 0xd70, 'initial_K_consumer': 0x1140,
           'initial_V_consumer': 0x14c0, 'shared_page_load': 0x2680, 'shared_page_first_consumer': 0x2bb0,
           'K_stride_consumer': 0x2c10, 'V_stride_consumer_no_wait': 0x3090,
           'first_main_K_payload_consumer_and_W5_group_wait': 0x3ae0, 'second_main_K_payload_consumer': 0x3b70,
           'prepublish_BAR': 0x3ac0, 'following_prepub_instruction': 0x3ad0}}
points['C6'] = {'initial_metadata_consumer':0xd70,'initial_K_consumer':0x1140,'initial_V_consumer':0x14c0,'shared_page_load':0x2420,'K_stride_consumer':0x2920,'V_stride_consumer':0x2a70,'first_main_K_payload_consumer_and_W5_group_wait':0x3b00,'second_main_K_payload_consumer':0x3b90,'loop_entry_read_counter1_wait':0x2370,'prepublish_BAR':0x3060,'following_prepub_instruction':0x3070}
results = {}
for variant, report in reports.items():
    actions = []
    for action in report['actions']:
        m = action['selected_metrics']
        base = m['launch__function_pcs']['instances'][0]['value']
        inst = m['inst_executed']['instances']
        assert sum(i['value'] for i in inst) == m['inst_executed']['scalar']
        opcode = Counter()
        decoder = Counter()
        for i in inst:
            s = i['sass']; opcode[op(s)] += i['value']
            if 'PRMT' in s and '0x1302' in s: decoder['PRMT_1302'] += i['value']
            elif 'LOP3' in s and any(k in s for k in ['0x80008000', '0x7f007f00', '0x7f007f0,']): decoder['LOP3_packed_fp8_fields'] += i['value']
            elif 'LEA.HI' in s and s.rstrip().endswith('0x1c'): decoder['LEA_HI_shift28'] += i['value']
            elif 'HFMA2.BF16_V2' in s and '1.329227' in s: decoder['HFMA2_BF16_times2p120'] += i['value']
        metrics = {}
        for name, metric in m.items():
            if name.startswith('smsp__pcsamp_') and metric['instances']:
                assert sum(i['value'] for i in metric['instances']) == metric['scalar']
                by_pc = {i['id'] - base: i['value'] for i in metric['instances']}
                metrics[name] = {'sum': metric['scalar'], 'by_relative_PC': {hex(k): v for k, v in by_pc.items() if v}}
        item = {'action': action['action'], 'arm': 'FP8' if action['action'] % 2 else 'plain_BF16',
                'mangled_name': action['mangled_name'], 'function_base': base,
                'dynamic_inst': m['inst_executed']['scalar'], 'per_opcode': dict(sorted(opcode.items())),
                'decoder_exact_fingerprints': dict(decoder), 'decoder_fingerprint_total': sum(decoder.values()),
                'metrics': metrics, 'overflow': m['smsp__pcsamp_buffer_overflow']['scalar'],
                'dropped_bytes': m['smsp__pcsamp_dropped_bytes']['scalar']}
        if action['action'] % 2:
            assert action['mangled_name'] == codegen[variant]['current']['symbols']['bf16-prefill']
            for i in inst:
                pc = i['id'] - base
                assert pc in static[variant]
                assert normal(i['sass'], base) == normal(static[variant][pc]), (variant, hex(pc), i['sass'], static[variant][pc])
            item['all_exported_instruction_PCs_match_retained_exact_kernel_SASS'] = len(inst)
            item['semantic_points'] = {name: {'pc': hex(pc), 'sass': static[variant][pc],
                'samples': {k: v['by_relative_PC'].get(hex(pc), 0) for k, v in metrics.items()}}
                for name, pc in points[variant].items()}
            long = m['smsp__pcsamp_warps_issue_stalled_long_scoreboard_not_issued']
            inst_by_pc = {i['id'] - base: i['sass'] for i in inst}
            item['top_long_scoreboard_PCs'] = [{'pc': hex(i['id'] - base), 'samples': i['value'], 'sass': inst_by_pc.get(i['id'] - base)}
                for i in sorted(long['instances'], key=lambda i: i['value'], reverse=True)[:15]]
        actions.append(item)
    assert actions[0]['dynamic_inst'] == actions[2]['dynamic_inst'] == 2466704
    assert actions[1]['dynamic_inst'] == actions[3]['dynamic_inst']
    assert actions[1]['per_opcode'] == actions[3]['per_opcode']
    results[variant] = actions

c5 = results['C5'][1]
assert c5['dynamic_inst'] == 3428864
assert c5['decoder_fingerprint_total'] == 646144
assert c5['decoder_exact_fingerprints'] == results['C4'][1]['decoder_exact_fingerprints'] == results['C2'][1]['decoder_exact_fingerprints']
assert all(not a['decoder_fingerprint_total'] for v in results.values() for a in v if a['arm'] == 'plain_BF16')
for name in ['HMMA', 'MUFU', 'FMUL', 'LDSM']:
    assert len({a['per_opcode'].get(name) for v in results.values() for a in v}) == 1, name
deltas = {}
for label, a, b in [('C2_to_C4', 'C2', 'C4'), ('C4_to_C5', 'C4', 'C5'), ('C2_to_C5', 'C2', 'C5'), ('C5_to_C6','C5','C6'), ('C2_to_C6','C2','C6')]:
    aa, bb = results[a][1], results[b][1]
    deltas[label] = {'total': bb['dynamic_inst'] - aa['dynamic_inst'],
        'per_opcode': {k: bb['per_opcode'].get(k, 0) - aa['per_opcode'].get(k, 0) for k in sorted(set(aa['per_opcode']) | set(bb['per_opcode']))}}

assert results['C6'][1]['dynamic_inst'] == results['C6'][3]['dynamic_inst'] == 3438560
assert results['C6'][1]['decoder_exact_fingerprints'] == results['C5'][1]['decoder_exact_fingerprints']
assert results['C6'][1]['decoder_fingerprint_total'] == 646144
assert deltas['C5_to_C6']['total'] == 9696
actual_delta = {k: v for k, v in deltas['C5_to_C6']['per_opcode'].items() if v}
assert actual_delta == {'CS2R': -4848, 'IMAD': 4848, 'LEA': -4848, 'MOV': -320, 'SHF': 10016, 'UIADD3': 4848}
controls_path = ROOT / '.scratch/g04-bf16-c6-codegen/controls-review.json'
controls = json.loads(controls_path.read_text())
control_by_pc = {int(x['pc'], 16): x for x in controls['all_rows']}
assert control_by_pc[0x2370]['wait_counters'] == [1]
assert control_by_pc[0x44c0]['wait_counters'] == [1]
last_counter1_producers = [x for x in controls['all_rows'] if 0x44c0 < int(x['pc'], 16) < 0x4d20 and (x['read_counter'] == 1 or x['write_counter'] == 1)]
assert [x['pc'] for x in last_counter1_producers] == ['4c80', '4cb0', '4ce0', '4cf0']
assert all(x['read_counter'] == 1 and x['write_counter'] == 7 and 'STS.128' in x['sass'] for x in last_counter1_producers)
assert not [x for x in controls['all_rows'] if 0x44c0 < int(x['pc'], 16) <= 0x4d20 and 1 in x['wait_counters']]
assert static['C6'][0x4d20] == 'BRA 0x2350 ;'
assert all(x['first_subsequent_wait_for_its_write_counter']['pc'] == '3b00' and x['first_wait_after_all_EX2'] for x in controls['early_K_loads_and_first_counter_waits'])
review = {
    'scope': 'Independent CPU-only actual C6 minimal6 NCU review versus C5/C4/C2; no new GPU, compile, variant or canonical edit',
    'inputs': {v: {'path': str(p), 'sha256': sha(p), 'report_sha256': reports[v]['sha256']} for v, p in paths.items()},
    'C6_static_bindings': {str(p.relative_to(ROOT)): sha(p) for p in [
        ROOT / '.scratch/g04-bf16-c6-codegen/review.json',
        ROOT / '.scratch/g04-bf16-c6-codegen/c6-rows.json',
        ROOT / '.scratch/g04-bf16-c6-codegen/c6-bf16-prefill-codewords.txt',
        ROOT / '.scratch/g04-bf16-c6-codegen/mechanism-review.json', controls_path]},
    'results': results,
    'dynamic_instruction_deltas': deltas,
    'C5_to_C6_nonzero_opcode_delta': actual_delta,
    'C6_extra_dynamic_instructions_versus_plain': {
        'FP8': 3438560, 'plain': 2466704, 'extra': 3438560 - 2466704,
        'extra_percent': (3438560 / 2466704 - 1) * 100},
    'loop_entry_other_wait': {
        'site': control_by_pc[0x2370],
        'previous_counter1_clear': control_by_pc[0x44c0],
        'last_loop_counter1_producers': last_counter1_producers,
        'backedge': control_by_pc[0x4d20],
        'interpretation': 'This loop-entry wait is for read-counter1. Since the previous clear at44c0, the only increments are the last4V shared stores. They protect queued store source/address registers; for example4cb0 uses addressR162 before2370 overwritesR162. It is a loop-carried WAR/group wait, not evidence that the visibleR215 arithmetic is itself slow.',
        'limits': 'Counter semantics are inferred from the pinned primary decoder/research, not a NVIDIA public ABI. The report does not separately observe which store operand remained pending or supply its exact time cost.'},
    'interpretation': [
        'The actual C6 mangled kernel and all2012 exported instruction PCs match retainedC6 SASS opcode/operands after documented tool-text normalization. Per-action function bases are subtracted; no absolute-PC or row-position matching is used.',
        'The first groupedW5 wait at3b00 has0/2 long-scoreboard samples; second payload consumer3b90 has0/0. This is consistent with better overlap than C5 firstwait3ae0 at133/124, but finite low samples do not prove zero latency or complete latency elimination.',
        'Both raw-K loads shareW5, and3b00 waits counters1/3/4/5. Even its remaining2 samples cannot be exclusively assigned to one raw vector or one producer without additional evidence.',
        'Long-scoreboard totals are485/493 with same-binary plain300/322. Initial page-index consumerd70 remains142/150, initialK1140 remains101/92, and loop-entry2370 has56/55. There are substantial residual waits despite the near-zero main-K consumer samples.',
        'C6 moves the actual load sites to29b0/29c0 inside tailQK and keeps firstW5 wait after everyEX2. The retained source change remains postcompute_qk; compiler scheduling produced the actual interleaving. Dynamic math quantities remain unchanged.',
        'C6 executes3438560 dynamic warp instructions, versus3428864 in C5 and2466704 in plain. The9696 increase is exactly CS2R-4848, LEA-4848, MOV-320, IMAD+4848, SHF+10016 and UIADD3+4848. This is a compiler-schedule/address-lowering tradeoff, not reduced decoder arithmetic.',
        'The four exact decoder fingerprints remain646144 in everyFP8 arm and0 in plain: PRMT80768, packed-fieldLOP3323072, shift28LEA80768, BF16HFMA2161536. HMMA315120, MUFU90400, FMUL681856 and LDSM232704 match allFP8/plain arms in all4 retained profiles.',
        'C6 retains a substantial extra software instruction workload over plain:971856 instructions(+39.399%). This does not imply an equal time overhead because instruction pipelines, overlap and memory behavior differ.'
    ],
    'limits': [
        'This profile supplies mechanism evidence only. Ordinary replay improved about1% againstC5; normal-0.409% had an interval crossing0, as reported by the parent/ordinary reviewer. This analysis does not rederive ordinary statistics or replace them with profiler durations.',
        'The fresh same-source plain-peer comparison still has a measurable residual gap. Moving one wait does not establish FP8/plain parity.',
        'No cross-run profiler duration ratios are spliced into an ordinary speedup. Counter/sample totals are not converted to microseconds or a causal cost ledger.',
        'The dependence-counter decoder is an explicitly pinned primary reverse-engineered implementation, not NVIDIA official SM89 ABI documentation. Grouped waits and sampled operands are distinct concepts.',
        'No barrier_notissued category was collected. All-state samples at BAR3060 or following3070 do not independently determine CTA synchronization cost.',
        'Ambiguous IMAD/address instructions are excluded from the646144 decoder fingerprint total; the total is a conservative exact opcode/operand classification, not every decoder instruction.',
        'No new optimization or profiling run is proposed by this report.']}
(OUT / 'independent-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'independent-review.json'), 'sha256': sha(OUT / 'independent-review.json'),
                  'C5_to_C6_nonzero_opcode_delta': actual_delta}, indent=2))
