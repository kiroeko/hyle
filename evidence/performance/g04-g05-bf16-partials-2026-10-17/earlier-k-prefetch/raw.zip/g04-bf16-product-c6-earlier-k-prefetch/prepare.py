from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil

repo = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
base_dir = repo / '.scratch/g04-bf16-product-c5-shared-page-index'
sha = lambda data: hashlib.sha256(data).hexdigest()
original = (base_dir / 'prefill.cuh').read_bytes()
assert sha(original) == '8655514c44249af1c52bfb019447c09eca0617f8475c2097c0e490fcabca3763'
source = original.decode()
loop_anchor = '        const uint32_t next_packed_page_iter_base =\n'
assert source.count(loop_anchor) == 1
prefix, source = source.split(loop_anchor)
original_loop_suffix = source
block = '''        [[maybe_unused]] b128_t prefetched_k_first{}, prefetched_k_second{};
        if constexpr (hyle_bf16_k_pair_prefetch_scope<KTraits>) {
          const uint32_t row = warp_idx * 4 + lane_idx / 8;
          const bool valid = (iter + 1) * CTA_TILE_KV + row < chunk_size;
          prefetched_k_first = hyle_prefetch_packed_k_vector(
              paged_kv.k_data + thr_local_kv_offset_k[0], valid);
          prefetched_k_second = hyle_prefetch_packed_k_vector(
              paged_kv.k_data + thr_local_kv_offset_k[0] + 128, valid);
        }
'''
anchor = '''        logits_transform<KTraits>(params, variant, /*batch_idx=*/request_idx, qo_packed_idx_base,
                                  kv_idx_base, qo_len, kv_len, chunk_end, group_size, s_frag, tid,
                                  kv_head_idx);
'''
assert source.count(block) == 1
assert source.count(anchor) == 1
assert source.index(anchor) < source.index(block)
source = source.replace(block, '').replace(anchor, block + anchor)
assert source.count('        // compute m,d states in online softmax\n') == 1
assert source.replace(block + anchor, anchor).replace('        // compute m,d states in online softmax\n', block + '        // compute m,d states in online softmax\n') == original_loop_suffix
source = prefix + loop_anchor + source
for pattern in [r'^.*block\.sync\(\).*$', r'^.*cp_async::.*$', r'^.*page_produce_kv<true, KTraits>.*$', r'^.*hyle_publish_prefetched_k_pair.*$']:
    assert re.findall(pattern, source, re.M) == re.findall(pattern, original.decode(), re.M)
candidate = source.encode()
(out / 'prefill.cuh').write_bytes(candidate)
patch = ''.join(difflib.unified_diff(original.decode().splitlines(True), source.splitlines(True),
    fromfile='C5-shared-page-index/prefill.cuh', tofile='C6-earlier-K-prefetch/prefill.cuh', n=60))
assert len(re.findall(r'^@@ ', patch, re.M)) == 1
(out / 'candidate.patch').write_bytes(patch.encode())
shadow = out / 'vendor-shadow'
shutil.copytree(base_dir / 'vendor-shadow', shadow)
(shadow / 'include/flashinfer/attention/prefill.cuh').write_bytes(candidate)
base_files = json.loads((base_dir / 'shadow-files.json').read_text())
files = {p.relative_to(shadow).as_posix(): sha(p.read_bytes()) for p in shadow.rglob('*') if p.is_file()}
assert len(files) == 2576 and files.keys() == base_files.keys()
assert [p for p in files if files[p] != base_files[p]] == ['include/flashinfer/attention/prefill.cuh']
(out / 'shadow-files.json').write_bytes((json.dumps(files, indent=2) + '\n').encode())
plan = {
    'state': 'SCRATCH_C6_SOURCE_ONLY_BEFORE_COMPILE', 'canonical_product_modified': False,
    'cuda_compiled': False, 'gpu_executed': False,
    'C5_base_header_sha256': sha(original),
    'C2_native_source_sha256': '8095820397cef116e4ecbc7dae4d6dedb28910000784e267703c88482767295b',
    'candidate_header_sha256': sha(candidate), 'candidate_patch_sha256': sha((out / 'candidate.patch').read_bytes()),
    'change': 'Move the exact existing C5 dual-K raw prefetch/declaration block to immediately after all compute_qk branches, before logits_transform/mask. One moved block and one unified hunk, context60.',
    'gate': 'Exactly existing C5 private-BF16-marker/SM89/E4M3direct/D256/CTA64/MMAKV1/warps4x1 gate; unchanged.',
    'dependencies': 'Mainloop next K/V offsets remain computed before QK; iter,chunk_size,row and paged pointers are loop inputs. Source move does not precede compute_qk and does not cross its live Q/K fragment window.',
    'validity': 'Payload helper, both input pointers and exact valid expression are byte-identical. No invalid-row load, shared store, sync or pointer advance added.',
    'unchanged': 'Shared page-index C5 change, K decoder/publication, V, all barriers/commit/wait, initialK and defaultF32 retain original source.',
    'resource_limit': 'Eight raw32bit payloads become live across logits_transform/mask. Freed QK and address temporaries may be reused, but actual register count/stack/local and first counter wait must be inspected; no artificial register cap.',
    'diagnostic_limit': 'More static latency overlap is not a guaranteed runtime gain; do not substitute profiler samples for paired ordinary measurement.',
    'full_shadow': {'files': len(files), 'path': str(shadow), 'only_changed_file_from_C5': 'include/flashinfer/attention/prefill.cuh',
        'inventory_sha256': sha(''.join(p + '|' + h + '\n' for p, h in sorted(files.items())).encode()),
        'inventory_algorithm': 'sha256(sorted relative_path|raw_sha256 LF)',
        'shadow_files_json_sha256': sha((out / 'shadow-files.json').read_bytes())}}
(out / 'source-plan.json').write_bytes((json.dumps(plan, indent=2) + '\n').encode())
build = (base_dir / 'build_c5.py').read_text()
build = build.replace('g04-bf16-product-c5-shared-page-index', 'g04-bf16-product-c6-earlier-k-prefetch')
build = build.replace('g04-bf16-c5', 'g04-bf16-c6').replace('C5_', 'C6_').replace('_c5.a', '_c6.a')
build = build.replace(sha(original), sha(candidate))
build = build.replace('c2_ready', 'c5_ready')
build = build.replace("REPO / '.scratch/g04-bf16-c2/archive-result.json'", "REPO / '.scratch/g04-bf16-c5/archive-result.json'")
build = build.replace("c5_ready['C2_archive']", "c5_ready['C5_archive']")
build = build.replace("c5_ready['C2_archive_sha256']", "c5_ready['C5_archive_sha256']")
build = build.replace("'C2_archive':", "'C5_archive':").replace("'C2_archive_sha256':", "'C5_archive_sha256':")
build = build.replace('C2_unchanged', 'C5_unchanged')
build = build.replace('C4 dual-K prefetch plus one shared next-page index load for K/V, finite BF16 marker/SM89 domain only',
                      'C5 shared next-page index plus exact dual-K prefetch moved afterQK and before logits/mask, finite BF16 marker/SM89 domain only')
(out / 'build_c6.py').write_bytes(build.encode())
print(json.dumps(plan, indent=2), flush=True)
