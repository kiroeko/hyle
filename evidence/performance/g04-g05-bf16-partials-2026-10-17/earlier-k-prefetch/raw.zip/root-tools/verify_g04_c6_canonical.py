from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
out = root / '.scratch/g04-bf16-product-c6-vendor'
sha = lambda data: hashlib.sha256(data).hexdigest()
report = json.loads((out / 'source-result.json').read_text())
paths = {'manifest_sha256': 'third_party/flashinfer_cache/patches.json',
         'notice_sha256': 'third_party/flashinfer_cache/NOTICE.md',
         'lock_sha256': 'cmake/HyleDependencyLock.json'}
for key, name in paths.items():
    assert sha((root / name).read_bytes()) == report['candidate'][key], name
materialized = out / 'materialized-canonical'
argv = [sys.executable, str(root / 'src/compute_ggml_runtime/prepare_source.py'),
        '--source', str(root / '.scratch/g04-bf16-partials-vendor/upstream'),
        '--output', str(materialized),
        '--manifest', str(root / 'third_party/flashinfer_cache/patches.json')]
start = time.perf_counter()
r = subprocess.run(argv, capture_output=True, text=True)
(out / 'canonical-materialize.stdout.log').write_text(r.stdout)
(out / 'canonical-materialize.stderr.log').write_text(r.stderr)
assert r.returncode == 0, (r.stdout, r.stderr)
files = {p.relative_to(materialized).as_posix(): sha(p.read_bytes())
         for p in materialized.rglob('*') if p.is_file()}
expected = json.loads((root / '.scratch/g04-bf16-product-c6-earlier-k-prefetch/shadow-files.json').read_text())
assert files == expected and len(files) == 2576
inventory = sha(''.join(p + '|' + h + '\n' for p, h in sorted(files.items())).encode())
assert inventory == report['materializer']['inventory_sha256']
functions = []
source = (root / 'cmake/HyleDependencyVersions.cmake').read_text()
for name in ['_hyle_dependency_normalized_sha256', '_hyle_dependency_tree_sha256']:
    m = re.search(r'^function\(' + re.escape(name) + r'\b.*?^endfunction\(\)', source, re.M | re.S)
    assert m
    functions.append(m.group())
cmake = out / 'verify-canonical-tree-hash.cmake'
tree_result = out / 'canonical-tree-sha256.txt'
cmake.write_text('cmake_minimum_required(VERSION 3.28)\n' + '\n\n'.join(functions)
                 + '\n_hyle_dependency_tree_sha256("' + (root / 'third_party/flashinfer_cache').as_posix()
                 + '" actual)\nfile(WRITE "' + tree_result.as_posix() + '" "${actual}\\n")\n')
c = subprocess.run(['cmake', '-P', str(cmake)], capture_output=True, text=True)
(out / 'canonical-cmake-hash.stdout.log').write_text(c.stdout)
(out / 'canonical-cmake-hash.stderr.log').write_text(c.stderr)
assert c.returncode == 0, (c.stdout, c.stderr)
tree = tree_result.read_text().strip()
assert tree == report['candidate']['vendored_tree_sha256']
lock = json.loads((root / 'cmake/HyleDependencyLock.json').read_text())
dep = next(d for d in lock['dependencies'] if d['name'] == 'flashinfer_cache_patches')
assert dep['version'] == report['new_version'] and dep['vendored']['tree_sha256'] == tree
result = {'version': dep['version'], 'materializer_argv': argv, 'materializer_returncode': r.returncode,
          'materialized_files': len(files), 'all_files_equal_actual_compiled_shadow': True,
          'inventory_sha256': inventory, 'CMake_returncode': c.returncode,
          'CMake_vendor_tree_sha256': tree, 'lock_matches': True,
          'elapsed_s': time.perf_counter() - start}
(out / 'canonical-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))

