from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
scratch = root / '.scratch/g04-bf16-product-c6-vendor'
report = json.loads((scratch / 'source-result.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
paths = {
    'manifest_sha256': 'third_party/flashinfer_cache/patches.json',
    'notice_sha256': 'third_party/flashinfer_cache/NOTICE.md',
    'lock_sha256': 'cmake/HyleDependencyLock.json',
}
payload = []
for key, name in paths.items():
    before, after = (root / name).read_bytes(), (scratch / 'candidate' / name).read_bytes()
    assert sha(before) == report['before'][key], (name, 'canonical changed since candidate preparation')
    assert sha(after) == report['candidate'][key], (name, 'candidate hash mismatch')
    payload.append((root / name, after))
for path, data in payload:
    path.write_bytes(data)
assert all(sha((root / name).read_bytes()) == report['candidate'][key] for key, name in paths.items())
(scratch / 'canonical-adoption.json').write_text(json.dumps({
    'version': report['new_version'],
    'candidate_file_bytes_matched': True,
    'files': {name: report['candidate'][key] for key, name in paths.items()},
    'compiled_header_sha256': report['candidate']['prefill_sha256'],
    'compiled_source_inventory_sha256': report['materializer']['inventory_sha256'],
    'note': 'Applied only three verified Windows candidate files after exact before/after SHA checks.',
}, indent=2) + '\n', encoding='utf-8')
print('Applied three exact Windows candidate files; before and after SHA256 verified.')

