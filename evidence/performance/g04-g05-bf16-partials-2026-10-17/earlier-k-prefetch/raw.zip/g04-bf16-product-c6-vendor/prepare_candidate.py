from pathlib import Path
import argparse,copy,difflib,hashlib,json,re,subprocess,sys,time
args=argparse.ArgumentParser();args.add_argument("--preview",type=Path,required=True);args=args.parse_args()
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
normalize=lambda b:b.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
folder=ROOT/'third_party/flashinfer_cache';old={n:(folder/n).read_bytes() for n in ['LICENSE','NOTICE.md','patches.json']};old_lock=(ROOT/'cmake/HyleDependencyLock.json').read_bytes();manifest=json.loads(old['patches.json']);lock=json.loads(old_lock)
assert sha(old['patches.json'])=='483a7d2924ff639cf671fd607dd592e74302bd89debd28a14bcc462411717baa'
dep=next(x for x in lock['dependencies'] if x['name']=='flashinfer_cache_patches');assert dep['version']=='hyle-flashinfer-bf16-kv-page-index-v14'
base=ROOT/'.scratch/g04-bf16-product-c5-vendor/materialized-production';upstream=ROOT/'.scratch/g04-bf16-partials-vendor/upstream';preview=args.preview.resolve();identity_path=ROOT/'.scratch/g04-bf16-c6/identity.json';identity=json.loads(identity_path.read_text())
header='include/flashinfer/attention/prefill.cuh';before=(base/header).read_bytes();after=(preview/'prefill.cuh').read_bytes();assert sha(before)=='8655514c44249af1c52bfb019447c09eca0617f8475c2097c0e490fcabca3763';expected=identity['C6_header_sha256'];assert sha(after)==identity['C6_header_sha256']==expected
block_start=b'        [[maybe_unused]] b128_t prefetched_k_first{}, prefetched_k_second{};'
assert before.count(block_start)==after.count(block_start)==1
begin=before.index(block_start);end=before.index(b'\n        }\n',begin)+len(b'\n        }\n');old_block=before[begin:end]
assert after.count(old_block)==1
assert before.replace(old_block,b'',1)==after.replace(old_block,b'',1)
old_lines=before.decode().splitlines(True);new_lines=after.decode().splitlines(True);edits=[];working=before
for group in difflib.SequenceMatcher(None,old_lines,new_lines,autojunk=False).get_grouped_opcodes(8):
 i1,i2=group[0][1],group[-1][2];j1,j2=group[0][3],group[-1][4];a=''.join(old_lines[i1:i2]);b=''.join(new_lines[j1:j2]);assert working.count(a.encode())==1;working=working.replace(a.encode(),b.encode(),1);edits.append({'before':a,'after':b})
assert len(edits)>=1 and working==after
item=next(x for x in manifest['files'] if x['path']==header);old_edits=copy.deepcopy(item['edits']);assert item['after_sha256']==sha(before);item['edits'].extend(edits);item['after_sha256']=sha(after)
manifest['scope']+='; same SM89 private BF16 scope moves the unchanged paired raw K prefetch immediately after compute_qk and before logits transform/mask, retaining shared page indexing and original publication'
new_manifest=(json.dumps(manifest,indent=2)+'\n').encode();old_notice=old['NOTICE.md'].decode();new_notice=(old_notice+'\nWithin the same SM89 private BF16-partial scope, the C++ source places the\nunchanged paired raw K prefetch after the QK call and before logits transform\nand masking, ahead of online softmax. The compiler can schedule these raw\nloads across the QK tail. Decoder/publication timing, shared K/V page indexing,\nrow guards, arithmetic, barriers and all other routes remain.\n').encode();version='hyle-flashinfer-bf16-early-k-prefetch-v15'
vendored={'LICENSE':old['LICENSE'],'NOTICE.md':new_notice,'patches.json':new_manifest};tree=lambda files:sha(''.join(n+'|'+sha(normalize(b))+'\n' for n,b in sorted(files.items())).encode());assert tree(old)==dep['vendored']['tree_sha256'];new_tree=tree(vendored)
notice_record=next(x for x in dep['license']['files'] if x['path']=='third_party/flashinfer_cache/NOTICE.md');old_notice_hash=notice_record['sha256'];old_tree=dep['vendored']['tree_sha256'];dep['version']=version;notice_record['sha256']=sha(normalize(new_notice));dep['vendored']['tree_sha256']=new_tree
new_lock=old_lock
for a,b in [('hyle-flashinfer-bf16-kv-page-index-v14',version),(old_notice_hash,notice_record['sha256']),(old_tree,new_tree)]:assert new_lock.count(a.encode())==1;new_lock=new_lock.replace(a.encode(),b.encode(),1)
assert json.loads(new_lock)==lock
candidate=OUT/'candidate';vendor=candidate/'third_party/flashinfer_cache';vendor.mkdir(parents=True,exist_ok=False);(candidate/'cmake').mkdir()
for n,b in vendored.items():(vendor/n).write_bytes(b)
(candidate/'cmake/HyleDependencyLock.json').write_bytes(new_lock)
cmd=[sys.executable,str(ROOT/'src/compute_ggml_runtime/prepare_source.py'),'--source',str(upstream),'--output',str(OUT/'materialized-production'),'--manifest',str(vendor/'patches.json')];start=time.time();r=subprocess.run(cmd,capture_output=True,text=True);(OUT/'materialize.stdout.log').write_text(r.stdout);(OUT/'materialize.stderr.log').write_text(r.stderr);assert r.returncode==0,(r.stdout,r.stderr)
materialized=OUT/'materialized-production';base_files={p.relative_to(base).as_posix():sha(p.read_bytes()) for p in base.rglob('*') if p.is_file()};files={p.relative_to(materialized).as_posix():sha(p.read_bytes()) for p in materialized.rglob('*') if p.is_file()};shadow=json.loads((preview/'shadow-files.json').read_text());assert len(files)==2576 and files.keys()==base_files.keys();assert [p for p in files if files[p]!=base_files[p]]==[header];assert files==shadow;assert (materialized/header).read_bytes()==after
for f in manifest['files']:assert files[f['path']]==f['after_sha256']
(OUT/'materialized-files.json').write_text(json.dumps(files,indent=2)+'\n');inventory=sha(''.join(p+'|'+h+'\n' for p,h in sorted(files.items())).encode());assert inventory==identity['vendor_inventory_sha256']
cmake_source=(ROOT/'cmake/HyleDependencyVersions.cmake').read_text();functions=[]
for name in ['_hyle_dependency_normalized_sha256','_hyle_dependency_tree_sha256']:
 m=re.search(r'^function\('+re.escape(name)+r'\b.*?^endfunction\(\)',cmake_source,re.M|re.S);assert m;functions.append(m.group())
cmake_script='cmake_minimum_required(VERSION 3.28)\n'+'\n\n'.join(functions)+'\n_hyle_dependency_tree_sha256("'+vendor.as_posix()+'" actual)\nfile(WRITE "'+(OUT/'cmake-tree-sha256.txt').as_posix()+'" "${actual}\n")\n';(OUT/'verify-tree-hash.cmake').write_text(cmake_script);cr=subprocess.run(['cmake','-P',str(OUT/'verify-tree-hash.cmake')],capture_output=True,text=True);(OUT/'cmake-hash.stdout.log').write_text(cr.stdout);(OUT/'cmake-hash.stderr.log').write_text(cr.stderr);assert cr.returncode==0,(cr.stdout,cr.stderr);assert (OUT/'cmake-tree-sha256.txt').read_text().strip()==new_tree
patch=''
for name,a,b in [('third_party/flashinfer_cache/patches.json',old['patches.json'],new_manifest),('third_party/flashinfer_cache/NOTICE.md',old['NOTICE.md'],new_notice),('cmake/HyleDependencyLock.json',old_lock,new_lock)]:patch+=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(OUT/'candidate-canonical.patch').write_text(patch)
assert all((folder/n).read_bytes()==old[n] for n in old) and (ROOT/'cmake/HyleDependencyLock.json').read_bytes()==old_lock
compile_result=ROOT/'.scratch/g04-bf16-c6/archive-result.json';compiled_binding={'status':'PENDING_ACTUAL_C6_COMPILE_RESULT','compile_identity_path':str(identity_path),'compile_identity_sha256':sha(identity_path.read_bytes()),'recorded_compile_input_header_sha256':expected}
if compile_result.exists():
 actual=json.loads(compile_result.read_text());assert actual['compile_returncode']==0 and actual['C6_header_sha256']==expected;compiled_binding.update(status='ACTUAL_C6_COMPILE_INPUT_MATCHED',archive_result_sha256=sha(compile_result.read_bytes()))
report={'state':'SCRATCH_ONLY_CANDIDATE_NOT_APPLIED','canonical_unchanged':True,'new_version':version,'before':{'manifest_sha256':sha(old['patches.json']),'notice_sha256':sha(old['NOTICE.md']),'lock_sha256':sha(old_lock),'vendored_tree_sha256':old_tree},'candidate':{'manifest_sha256':sha(new_manifest),'notice_sha256':sha(new_notice),'lock_sha256':sha(new_lock),'vendored_tree_sha256':new_tree,'prefill_sha256':expected,'canonical_patch_sha256':sha((OUT/'candidate-canonical.patch').read_bytes())},'C6_edits_appended_to_existing_prefill':len(edits),'original_v14_edits_retained':item['edits'][:-len(edits)]==old_edits,'materializer':{'argv':cmd,'returncode':r.returncode,'elapsed_s':time.time()-start,'stdout':r.stdout,'whole_source_files':len(files),'changed_from_v14':[header],'inventory_sha256':inventory,'all_files_equal_compiled_shadow_inventory':True},'authoritative_CMake_hash':{'returncode':cr.returncode,'tree_sha256':new_tree,'function_source':'cmake/HyleDependencyVersions.cmake:_hyle_dependency_normalized_sha256 and _hyle_dependency_tree_sha256','source_sha256':sha((ROOT/'cmake/HyleDependencyVersions.cmake').read_bytes())},'compiled_header_binding':compiled_binding,'not_claimed':['candidate performance gain','GPU correctness/safety PASS','canonical adoption','support on non-SM89 hardware']};(OUT/'source-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
