from pathlib import Path
import hashlib
import importlib.util
import json
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
primary = ROOT / '.scratch/g04-bf16-ncu-c4/offline-metal/control-decoder-roundtrip.json'
binding = json.loads(primary.read_text())
source = ROOT / '.scratch/g04-bf16-ncu-c4/offline-metal/primary-sources/CuControlCode.py'
assert sha(source) == binding['primary_sources']['CuControlCode.py']['sha256']
spec = importlib.util.spec_from_file_location('retained_primary_control_decoder', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
decoder = module.CuControlCode
review_path = OUT / 'review.json'
review = json.loads(review_path.read_text())
row_path = OUT / 'c6-rows.json'
rows = json.loads(row_path.read_text())['bf16-prefill']
word_path = OUT / 'c6-bf16-prefill-codewords.txt'
words = word_path.read_text().splitlines()
assert len(words) == len(rows)
control_rows = []
for i, (row, pair) in enumerate(zip(rows, words)):
    pc = int(row['pc'], 16)
    assert pc == i * 16
    lo, hi = (int(x, 16) for x in pair.split(':'))
    raw = lo | hi << 64
    code = raw >> 105 & 0x1ffff
    wait, read, write, yielding, stall = decoder.splitCode(code)
    rebuilt = (raw & ~(0x1ffff << 105)) | decoder.mergeCode(wait, read, write, yielding, stall) << 105
    assert raw == rebuilt
    control_rows.append({**row, 'low64': hex(lo), 'high64': hex(hi), 'control': decoder.decode(code),
                         'wait_counters': [n for n in range(6) if wait & (1 << n)],
                         'write_counter': write, 'read_counter': read})
ex2 = [int(r['pc'], 16) for r in rows if 'MUFU.EX2' in r['sass']]
qk = [int(r['pc'], 16) for r in rows if 'HMMA.16816.F32.BF16' in r['sass'] and int(r['pc'], 16) < min(ex2)]
early_k = [r for r in control_rows if 0x2400 < int(r['pc'], 16) < min(ex2) and 'LDG.E.128' in r['sass']]
first_waits = []
for load in early_k:
    subsequent = [r for r in control_rows if int(r['pc'], 16) > int(load['pc'], 16) and load['write_counter'] in r['wait_counters']]
    first_waits.append({'load': load, 'first_subsequent_wait_for_its_write_counter': subsequent[0] if subsequent else None,
                        'first_wait_after_all_EX2': bool(subsequent) and int(subsequent[0]['pc'], 16) > max(ex2)})
result = {
    'scope': 'Offline C6 control-word inspection with retained primary reverse-engineered implementation; no GPU',
    'bindings': {str(p.relative_to(ROOT)): sha(p) for p in [primary, source, review_path, row_path, word_path]},
    'primary_commit': binding['commit'], 'control_words_roundtripped': len(words),
    'EX2_pcs': [hex(pc) for pc in ex2], 'last_QK_HMMA_pc': hex(max(qk)),
    'early_K_loads_and_first_counter_waits': first_waits,
    'mainloop_constant_global_loads': [r for r in control_rows if 0x2400 < int(r['pc'], 16) < min(ex2) and 'LDG.E.CONSTANT' in r['sass']],
    'all_rows': control_rows,
    'limits': ['This reverse-engineered control decoder is explicitly identified, not NVIDIA public ISA/ABI documentation.',
               'First wait covers a grouped counter, not necessarily just the visible load or visible consumer operand.',
               'No runtime/math/performance verdict follows from these static words.']}
(OUT / 'controls-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'controls-review.json'), 'sha256': sha(OUT / 'controls-review.json'),
                  'index_loads': result['mainloop_constant_global_loads'], 'K_and_waits': first_waits}, indent=2))
