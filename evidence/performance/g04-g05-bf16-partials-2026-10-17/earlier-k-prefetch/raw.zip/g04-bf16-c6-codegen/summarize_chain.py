from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
review_path = OUT / 'review.json'
review = json.loads(review_path.read_text())
rows_path = OUT / 'c6-rows.json'
rows = json.loads(rows_path.read_text())['bf16-prefill']
by_pc = {int(x['pc'], 16): x['sass'] for x in rows}
controls_path = OUT / 'controls-review.json'
controls = json.loads(controls_path.read_text())
ex2 = [int(x['pc'], 16) for x in rows if 'MUFU.EX2' in x['sass']]
qk = [int(x['pc'], 16) for x in rows if 'HMMA.16816.F32.BF16' in x['sass'] and int(x['pc'], 16) < min(ex2)]
assert (min(qk), max(qk)) == (0x2670, 0x2d30)
assert (min(ex2), max(ex2)) == (0x3230, 0x35d0)
assert by_pc[0x29b0] == '@!P6 LDG.E.128 R136, [R184.64] ;'
assert by_pc[0x29c0] == '@!P6 LDG.E.128 R140, [R184.64+0x80] ;'
assert by_pc[0x3b00] == 'PRMT R136, R136, 0x1302, R136 ;'
assert by_pc[0x3b90] == 'PRMT R149, R140, 0x1302, R140 ;'
assert 0x29c0 < max(qk) < 0x3060 < min(ex2) <= max(ex2) < 0x3b00 < 0x3b90
for first, start, end in [(136, 0x29c0, 0x3b00), (140, 0x29d0, 0x3b90)]:
    for x in rows:
        if not start <= int(x['pc'], 16) < end:
            continue
        s = re.sub(r'^@!?U?P(?:\d+|T)\s+', '', x['sass'])
        m = re.match(r'([A-Z0-9_.]+)\s+R(\d+)(?:,|\.)', s)
        if m:
            width = 1
            if m[1].startswith(('CS2R', 'IMAD.WIDE')) or m[1].endswith('.64'):
                width = 2
            if m[1].startswith('HMMA.') or (m[1].startswith('LDSM.') and m[1].endswith('.4')) or m[1].endswith('.128'):
                width = 4
            assert not set(range(int(m[2]), int(m[2]) + width)).intersection(range(first, first + 4)), (x['pc'], s)
assert len(controls['mainloop_constant_global_loads']) == 1
assert controls['mainloop_constant_global_loads'][0]['pc'] == '2420'
assert controls['mainloop_constant_global_loads'][0]['write_counter'] == 2
assert all(x['load']['write_counter'] == 5 and x['first_wait_after_all_EX2'] and x['first_subsequent_wait_for_its_write_counter']['pc'] == '3b00' for x in controls['early_K_loads_and_first_counter_waits'])
assert len(controls['early_K_loads_and_first_counter_waits']) == 2
assert by_pc[0x2920] == '@!P0 IMAD.WIDE.U32 R140, R81, c[0x0][0x188], R140 ;'
assert by_pc[0x2a70] == '@!P0 IMAD.WIDE.U32 R182, R81, c[0x0][0x194], R182 ;'
stores = [x for x in rows if 0x3b00 < int(x['pc'], 16) < 0x4110 and 'STS.128' in x['sass']]
assert [int(x['pc'], 16) for x in stores] == [0x40b0, 0x40e0, 0x40f0, 0x4100]
assert by_pc[0x3060] == 'BAR.SYNC 0x0 ;'
assert by_pc[0x43e0] == '@!P6 LDG.E.128 R136, [R246.64] ;'
assert by_pc[0x4410] == '@!P6 LDG.E.128 R144, [R246.64+0x80] ;'
pv = [int(x['pc'], 16) for x in rows if int(x['pc'], 16) > 0x43d0 and 'HMMA.16816.F32.BF16' in x['sass']]
assert (min(pv), max(pv)) == (0x44c0, 0x4760)
assert not [x for x in rows if re.search(r'\b(?:LDL|STL)(?:\.|\s)', x['sass'])]
unchanged = [x for x in review['comparisons'] if x['kind'] != 'bf16-prefill']
assert len(unchanged) == 3 and all(x['instructions_equal'] and x['encoded_schedule_words_equal'] and x['resource_equal'] for x in unchanged)
result = {
    'scope': 'Actual C6 machine schedule/resource observations versus retained C5; CPU-only inspection, no GPU or canonical edits',
    'bindings': {str(p.relative_to(ROOT)): sha(p) for p in [review_path, rows_path, controls_path, OUT / 'c6-sass.txt',
        ROOT / '.scratch/g04-bf16-c6/archive-result.json',
        ROOT / '.scratch/g04-bf16-product-c6-earlier-k-prefetch/source-plan.json',
        ROOT / '.scratch/g04-bf16-product-c6-earlier-k-prefetch/candidate.patch']},
    'target_resource': review['current']['kernels']['bf16-prefill']['resource'],
    'target_instruction_count': review['current']['kernels']['bf16-prefill']['instruction_count'],
    'QK_HMMA_range': [hex(min(qk)), hex(max(qk))],
    'raw_K': [{'pc': '0x29b0', 'sass': by_pc[0x29b0], 'payload': 'R136..139'},
              {'pc': '0x29c0', 'sass': by_pc[0x29c0], 'payload': 'R140..143'}],
    'EX2_PCs': [hex(x) for x in ex2],
    'K_first_consumers': [{'pc': '0x3b00', 'sass': by_pc[0x3b00]}, {'pc': '0x3b90', 'sass': by_pc[0x3b90]}],
    'held_payload_registers_not_overwritten': True,
    'all4_K_shared_stores': stores,
    'prepublish_CTA_barrier': {'pc': '0x3060', 'sass': by_pc[0x3060]},
    'mainloop_single_shared_page_index': controls['mainloop_constant_global_loads'][0],
    'page_id_consumers_K_and_V_strides': [{'pc': '0x2920', 'sass': by_pc[0x2920]}, {'pc': '0x2a70', 'sass': by_pc[0x2a70]}],
    'write_counter_first_waits': controls['early_K_loads_and_first_counter_waits'],
    'V': {'global_loads': ['0x43e0', '0x4410'], 'PV_range': [hex(min(pv)), hex(max(pv))], 'first_decode': '0x4770'},
    'default_selected_kernels_complete128bit_words_equal_C5': [x['kind'] for x in unchanged],
    'observations': [
        'Both raw-K loads are now interleaved with the remaining QK HMMAs. They remain before all mask/softmax work, and the first wait for their sharedW5 is3b00 after everyEX2.',
        'The source block was moved strictly after compute_qk and before logits/mask, but the compiler hoisted actual loads into tailQK. The source-only live-fragment reasoning does not prove a postQK machine placement; this actual displacement is reported explicitly.',
        'Allocation remains250registers with0stack/0local and noLDL/STL. The longer actual lifetime across tailQK did not raise the reported register allocation versusC5.',
        'The prepublish BAR is scheduled at3060 beforeEX2, whereas C5 used3ac0 afterEX2. Shared K stores still follow this barrier and all softmax work. No source barrier was added or deleted.',
        'The same page indexR81 drives independent Kstride188 and Vstride194 calculations, with only one mainloop index read. Both V global reads remain ahead ofPV.'
    ],
    'limits': [
        'No numerical, sanitizer or ordinary-performance verdict follows from this static result; the sole runner tests the actual archive.',
        'Target machine instructions/control schedule differ fromC5 even though the three default/merge kernels match exactly. Do not characterize the entire target as only two moved machine instructions.',
        'Grouped dependence-counter interpretation uses a pinned primary reverse-engineered implementation, not NVIDIA public SM89 ABI. A grouped wait cannot assign latency to just one vector.',
        'The reported SHARED:0 is static memory; unchanged launchKTraits use49152B dynamic shared with128threads, which must be confirmed in actual launch facts.'
    ]}
(OUT / 'mechanism-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'mechanism-review.json'), 'sha256': sha(OUT / 'mechanism-review.json')}, indent=2))
