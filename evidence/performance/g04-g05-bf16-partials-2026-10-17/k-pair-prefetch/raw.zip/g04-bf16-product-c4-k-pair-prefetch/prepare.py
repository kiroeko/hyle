from pathlib import Path
import difflib,hashlib,json,re,shutil

repo=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
c3script=repo/'.scratch/g04-bf16-product-c3-k-prefetch/prepare.py'
env={'__file__':str(c3script)}
exec(compile(c3script.read_text().split('# Source-only guards:')[0],str(c3script),'exec'),env)
original=env['original'];source=env['source'];old_helpers=env['helpers']
helpers='''template <typename KTraits>
constexpr bool hyle_bf16_k_pair_prefetch_scope =
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ == 890
    HyleBf16Partials<typename KTraits::AttentionVariant>::value &&
    KTraits::HYLE_FP8_DIRECT_STAGE && KTraits::MASK_MODE == MaskMode::kCausal &&
    KTraits::CTA_TILE_Q == 64 && KTraits::HEAD_DIM_QK == 256 &&
    KTraits::HEAD_DIM_VO == 256 && KTraits::NUM_MMA_KV == 1 &&
    KTraits::NUM_WARPS_Q == 4 && KTraits::NUM_WARPS_KV == 1 &&
    std::is_same_v<typename KTraits::DTypeQ, __nv_bfloat16> &&
    std::is_same_v<typename KTraits::DTypeO, __nv_bfloat16>;
#else
    false;
#endif

__device__ __forceinline__ b128_t hyle_prefetch_packed_k_vector(const void* source, bool valid) {
  b128_t packed{};
  if (valid) {
    // Read raw packed K before softmax. Decode and publication remain below.
    asm volatile("ld.global.v4.u32 {%0,%1,%2,%3}, [%4];"
                 : "=r"(packed.x), "=r"(packed.y), "=r"(packed.z), "=r"(packed.w)
                 : "l"(source) : "memory");
  }
  return packed;
}

template <typename KTraits>
__device__ __forceinline__ void hyle_store_prefetched_k_vector(
    smem_t<KTraits::SWIZZLE_MODE_KV> smem, b128_t packed, uint32_t row, uint32_t col) {
  static_assert(hyle_bf16_k_pair_prefetch_scope<KTraits>);
  alignas(16) typename KTraits::DTypeQ converted[16];
  vec_cast<typename KTraits::DTypeQ, typename KTraits::DTypeKV>::template cast<16>(
      converted, reinterpret_cast<typename KTraits::DTypeKV*>(&packed));
  constexpr uint32_t stride = 256 / upcast_size<typename KTraits::DTypeQ>();
  smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, stride>(row, 2 * col)] =
      *reinterpret_cast<b128_t*>(converted);
  smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, stride>(row, 2 * col + 1)] =
      *reinterpret_cast<b128_t*>(converted + 8);
}

template <typename KTraits, typename SmemStorage>
__device__ __forceinline__ void hyle_publish_prefetched_k_pair(
    SmemStorage* storage, uint32_t next_base, uint32_t chunk_size,
    uint32_t warp_idx, uint32_t lane_idx, b128_t first, b128_t second) {
  static_assert(hyle_bf16_k_pair_prefetch_scope<KTraits>);
  const uint32_t row = warp_idx * 4 + lane_idx / 8;
  if (next_base + row >= chunk_size) return;  // Original K kNoFill behavior.
  smem_t<KTraits::SWIZZLE_MODE_KV> smem(storage->k_smem);
  const uint32_t col = lane_idx % 8;
  hyle_store_prefetched_k_vector<KTraits>(smem, first, row, col);
  hyle_store_prefetched_k_vector<KTraits>(smem, second, row, col + 8);
}

'''
def once(before,after):
    global source
    assert source.count(before)==1,(before[:100],source.count(before))
    source=source.replace(before,after)
once(old_helpers,helpers)
once('''        [[maybe_unused]] b128_t prefetched_k_first{};
        if constexpr (hyle_bf16_k_prefetch_scope<KTraits>) {
          const uint32_t row = warp_idx * 4 + lane_idx / 8;
          prefetched_k_first = hyle_prefetch_packed_k_first(
              paged_kv.k_data + thr_local_kv_offset_k[0],
              (iter + 1) * CTA_TILE_KV + row < chunk_size);
        }
''','''        [[maybe_unused]] b128_t prefetched_k_first{}, prefetched_k_second{};
        if constexpr (hyle_bf16_k_pair_prefetch_scope<KTraits>) {
          const uint32_t row = warp_idx * 4 + lane_idx / 8;
          const bool valid = (iter + 1) * CTA_TILE_KV + row < chunk_size;
          prefetched_k_first = hyle_prefetch_packed_k_vector(
              paged_kv.k_data + thr_local_kv_offset_k[0], valid);
          prefetched_k_second = hyle_prefetch_packed_k_vector(
              paged_kv.k_data + thr_local_kv_offset_k[0] + 128, valid);
        }
''')
once('''          if constexpr (hyle_bf16_k_prefetch_scope<KTraits>) {
            hyle_publish_prefetched_k<KTraits>(
                &smem_storage, paged_kv.k_data, thr_local_kv_offset_k,
                (iter + 1) * CTA_TILE_KV, chunk_size, warp_idx, lane_idx, prefetched_k_first);
''','''          if constexpr (hyle_bf16_k_pair_prefetch_scope<KTraits>) {
            hyle_publish_prefetched_k_pair<KTraits>(
                &smem_storage, (iter + 1) * CTA_TILE_KV, chunk_size,
                warp_idx, lane_idx, prefetched_k_first, prefetched_k_second);
''')
assert 'hyle_overlap' not in source and 'hyle_bf16_k_prefetch_scope' not in source
for pattern in [r'^.*block\.sync\(\).*$',r'^.*cp_async::.*$',r'^.*page_produce_kv<true, KTraits>.*$',r'^.*page_produce_kv_on_the_fly<.*$',r'^.*page_produce_kv_sf<.*$']:
    assert re.findall(pattern,source,re.M)==re.findall(pattern,original.decode(),re.M),pattern
candidate=source.encode();(out/'prefill.cuh').write_bytes(candidate)
(out/'candidate.patch').write_bytes(''.join(difflib.unified_diff(original.decode().splitlines(True),source.splitlines(True),fromfile='C2-v11/prefill.cuh',tofile='C4-K-pair-prefetch/prefill.cuh')).encode())
native=(repo/'.scratch/g04-bf16-c2/native_cache.cu').read_bytes()
assert sha(native)=='8095820397cef116e4ecbc7dae4d6dedb28910000784e267703c88482767295b'
record={'state':'SCRATCH_C4_SOURCE_ONLY_BEFORE_COMPILE','canonical_product_modified':False,'cuda_compiled':False,'gpu_executed':False,'base_prefill_sha256':sha(original),'C2_native_source_sha256':sha(native),'candidate_header_sha256':sha(candidate),'candidate_patch_sha256':sha((out/'candidate.patch').read_bytes()),'gate':'Existing BF16-partial marker + directstage + causal + BF16 Q/O + D256 + CTA64 + MMA_KV1 + Q/KVwarps4/1; only paged main-loop call sites','raw_prefetch':'Both16B packed K vectors, addresses offset[0] and offset[0]+128, explicitly asm-volatile before update_mdo_states. Eight long-live32bit payload registers, not a final allocator prediction.','validity':'The same next_base+row<chunk_size guard gates both global reads and later publication; invalid K rows perform no global read/shared write.','unchanged':'Same original vec_cast decoder, first/second vector order and shared swizzle, decoder/shared stores remain original publish site, initial K/V code and all barriers/commit/wait unchanged, all default/F32 and marker-false paths retain original branch','difference_from_C3':'C3 retained only first16B across softmax and loaded second16B at publish. C4 retains both16B raw payloads across softmax, with no remaining global load in the publish helper.','difference_from_old_dualK':'Old dualK only moved both loads together inside the late producer; C4 source places both before softmax and requires actual SASS confirmation of both loads before EX2.','compile_postcheck':'No register cap; record actual REG/STACK/LOCAL. Spill or both-load ordering failure is reported, not hidden. Source does not prove performance.'}
record['arch_gate']='__CUDA_ARCH__ == 890 only; host pass and other device architectures false'
record['source_ordering_limit']='asm volatile is not PTX ld.volatile; it expresses source-ordering intent but actual SASS must prove both raw loads precede EX2.'
(out/'source-plan.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record),flush=True)
shadow=out/'vendor-shadow'
base=repo/'.scratch/g04-bf16-partials-vendor/materialized-production-fixed-signatures'
if not shadow.exists():shutil.copytree(base,shadow)
(shadow/'include/flashinfer/attention/prefill.cuh').write_bytes(candidate)
base_files={p.relative_to(base).as_posix():sha(p.read_bytes()) for p in base.rglob('*') if p.is_file()}
files={p.relative_to(shadow).as_posix():sha(p.read_bytes()) for p in shadow.rglob('*') if p.is_file()}
assert len(files)==2576 and files.keys()==base_files.keys()
assert [p for p in files if files[p]!=base_files[p]]==['include/flashinfer/attention/prefill.cuh']
(out/'shadow-files.json').write_bytes((json.dumps(files,indent=2)+'\n').encode())
record['full_shadow']={'files':len(files),'path':str(shadow),'only_changed_file':'include/flashinfer/attention/prefill.cuh','inventory_sha256':sha(''.join(p+'|'+v+'\n' for p,v in sorted(files.items())).encode()),'inventory_algorithm':'sha256(sorted relative_path|raw_sha256 LF)','shadow_files_json_sha256':sha((out/'shadow-files.json').read_bytes())}
(out/'source-plan.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record['full_shadow']),flush=True)
