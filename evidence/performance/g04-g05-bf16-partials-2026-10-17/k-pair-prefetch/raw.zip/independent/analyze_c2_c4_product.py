"""Offline analysis of actual C2/C4 isolated products, both opt-in/11MiB."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import analyze as paired
from summarize_new_product_results import paired_block_interval


def fields(line):
    return dict(w.split('=', 1) for w in line.split()[1:] if '=' in w)


def review(text):
    paired.SHAPES = ('prefill',)
    records = paired.parse(text)
    modes = []
    for capture in (0, 1):
        result = paired.analyze([r for r in records if int(r['capture']) == capture], 32, 128)
        assert result['episode_pairs'] == 16384 and result['blocks'] == 128
        modes.append({'capture': capture, **result,
                      'pooled_block_interval': paired_block_interval(result['strata'])})
    memory = {}
    pending = None
    attrs = None
    for line in text.splitlines():
        if line.startswith('ISOLATED_ATTR '):
            assert attrs is None
            attrs = fields(line)
            assert attrs['c2_stub'] != attrs['c4_stub']
            assert attrs['c2_local'] == '0'
            assert attrs['c2_binary'] == attrs['c4_binary'] == '89'
            assert attrs['distinct_hoststubs'] == '1'
        elif line.startswith('PRODUCT_MEMORY '):
            assert pending is None
            pending = {k: int(v) for k, v in fields(line).items()}
        elif line.startswith('COLD '):
            assert pending is not None
            f = fields(line)
            key = (int(f['capture']), int(f['alloc']), int(f['order']), f['shape'], int(f['side']))
            assert key not in memory and pending['c2'] == (key[-1] == 0)
            assert pending['captured'] == key[0]
            assert pending['slots'] == 2 and pending['bf16_partials'] == 1
            assert pending['float_cap'] == 11 << 20 and pending['required_workspace'] == 10567680
            memory[key] = pending
            pending = None
    assert attrs is not None and pending is None and len(memory) == 20
    assert text.rstrip().endswith('EXIT code=0')
    return {
        'kind': 'INDEPENDENT_ACTUAL_C2_C4_SAME_PROCESS_K_PAIR_PREFETCH_COMPARISON',
        'comparison': 'C4optin / C2optin, both same ABI and 11MiB each slot',
        'episode_pairs': 32768, 'complete_episodes': 65536, 'blocks': 256,
        'capture_modes': modes, 'cold_actual_hoststub_attributes': attrs,
        'candidate_local_bytes_observed_not_suppressed': int(attrs['c4_local']),
        'actual_memory': [{'key': list(k), **v} for k, v in sorted(memory.items())],
        'all_samples_retained': True, 'negative_control_subtraction': False,
        'limits': [
            'Real full owner TUs are isolated by separately retained symbol/COMDAT/fatbin and link-map checks; identical device kernel names do not prove arm identity.',
            'Every capture/alloc/order matrix is reported separately. Pooled intervals are descriptive same-process paired-block intervals with an independence approximation, not cross-process confidence.',
            'Both sides use BF16 partials. This comparison tests the actual C4 generated kernel and not FP8 versus BF16 storage or F32 versus BF16 partial accuracy.',
            'Cold setup/attributes/teardown are outside warm complete-episode measurements. All individual tails and every block are retained; no trimming or negative-control normalization.',
            'C4 register and local-memory attributes are reported without imposing a favorable value. Source placement and profiler counters do not replace this ordinary performance comparison.',
        ],
    }


def write_matrices(result, path):
    names = ['comparison', 'capture', 'allocation_order', 'execution_order',
             'control_mean_us', 'treatment_mean_us', 'latency_change_percent',
             'control_p99_us', 'treatment_p99_us', 'control_max_us', 'treatment_max_us',
             'treatment_faster_blocks', 'blocks', 'complete_pairs']
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=names)
        writer.writeheader()
        for mode in result['capture_modes']:
            for row in mode['strata']:
                writer.writerow({
                    'comparison': 'C2optin -> C4optin', 'capture': mode['capture'],
                    'allocation_order': row['allocation_order'], 'execution_order': row['execution_order'],
                    'control_mean_us': row['control']['arithmetic_mean_us'],
                    'treatment_mean_us': row['treatment']['arithmetic_mean_us'],
                    'latency_change_percent': row['latency_change_percent'],
                    'control_p99_us': row['control']['p99_us'], 'treatment_p99_us': row['treatment']['p99_us'],
                    'control_max_us': row['control']['max_us'], 'treatment_max_us': row['treatment']['max_us'],
                    'treatment_faster_blocks': row['block_treatment_faster'],
                    'blocks': len(row['blocks']), 'complete_pairs': row['control']['count'],
                })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log', type=Path)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_name('product-c2-c4-analysis.json'))
    parser.add_argument('--matrices', type=Path,
                        default=Path(__file__).with_name('product-c2-c4-all-matrices.csv'))
    args = parser.parse_args()
    raw = args.log.read_bytes()
    result = review(raw.decode('utf-8'))
    result['source_log'] = str(args.log.resolve())
    result['source_log_sha256'] = hashlib.sha256(raw).hexdigest()
    result['analyzer_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    write_matrices(result, args.matrices)
    for mode in result['capture_modes']:
        print('capture', mode['capture'], 'pooled', mode['pooled_block_interval'])
        for row in mode['strata']:
            print(row['allocation_order'], row['execution_order'], row['latency_change_percent'])
    print('output', args.output, 'sha256', hashlib.sha256(args.output.read_bytes()).hexdigest())
    print('matrices', args.matrices, 'sha256', hashlib.sha256(args.matrices.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
