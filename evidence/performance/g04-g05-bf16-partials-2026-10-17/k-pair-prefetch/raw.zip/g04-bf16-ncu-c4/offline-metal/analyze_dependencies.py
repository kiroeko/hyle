"""Read retained codewords/PC samples; never loads or executes a CUDA module."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def normalize_instruction(sass, base=0):
    if re.search(r'\bBRA\b', sass):
        sass = re.sub(r'0x[0-9a-fA-F]+', lambda m: hex(int(m[0], 16) - base) if int(m[0], 16) >= base else m[0], sass)
    return ''.join(sass.replace('.reuse', '').rstrip(' ;').split())
inputs = {
    'C2_pc_API': ROOT / '.scratch/g04-bf16-ncu-source/offline-metal/report-api.json',
    'C4_pc_API': OUT / 'report-api.json',
    'C2_rows': ROOT / '.scratch/g04-bf16-c2-codegen/c2-rows.json',
    'C4_rows': ROOT / '.scratch/g04-bf16-c4-codegen/c4-rows.json',
    'C2_words': ROOT / '.scratch/g04-bf16-c2-codegen/c2-bf16-prefill-codewords.txt',
    'C4_words': ROOT / '.scratch/g04-bf16-c4-codegen/c4-bf16-prefill-codewords.txt',
    'C4_codegen_review': ROOT / '.scratch/g04-bf16-c4-codegen/review.json',
    'C4_prefill': ROOT / '.scratch/g04-bf16-product-c4-k-pair-prefetch/prefill.cuh',
    'page_header': ROOT / '.scratch/g04-bf16-product-c4-k-pair-prefetch/vendor-shadow/include/flashinfer/page.cuh',
    'params_header': ROOT / '.scratch/g04-bf16-product-c4-k-pair-prefetch/vendor-shadow/include/flashinfer/attention/default_prefill_params.cuh',
    'primary_decoder_roundtrip': OUT / 'control-decoder-roundtrip.json',
}
decoder_binding = json.loads(inputs['primary_decoder_roundtrip'].read_text())
decoder_commit = decoder_binding['commit']
rows = {}
control = {}
api = {}
for label in ['C2', 'C4']:
    rows[label] = {int(x['pc'], 16): x['sass'] for x in json.loads(inputs[label + '_rows'].read_text())['bf16-prefill']}
    words = inputs[label + '_words'].read_text().splitlines()
    assert len(words) == len(rows[label]) and list(rows[label]) == list(range(0, len(words) * 16, 16))
    parsed = {}
    for idx, line in enumerate(words):
        lo, hi = [int(x, 16) for x in line.split(':')]
        code = (hi >> 41) & 0x1ffff
        parsed[idx * 16] = {
            'low64': hex(lo), 'high64': hex(hi), 'sass': rows[label][idx * 16],
            'stall_field': code & 15, 'yield_field': (code >> 4) & 1,
            'write_counter': (code >> 5) & 7, 'read_counter': (code >> 8) & 7,
            'wait_mask': hex((code >> 11) & 63),
            'wait_counters': [i for i in range(6) if code & (1 << (11 + i))]}
    control[label] = parsed
    api[label] = json.loads(inputs[label + '_pc_API'].read_text())

c4 = rows['C4']
assert c4[0x2640] == '@!P6 IMAD.WIDE R176, R174, R177, c[0x0][0x1b0] ;'
assert c4[0x2690] == '@!P6 IMAD.WIDE R178, R174, R179, c[0x0][0x1b0] ;'
assert c4[0x2630] == '@!P6 IMAD.MOV.U32 R177, RZ, RZ, 0x4 ;'
assert c4[0x2680] == '@!P6 IMAD.MOV.U32 R179, RZ, RZ, 0x4 ;'
assert c4[0x2660] == '@!P6 LDG.E.CONSTANT R83, [R176.64] ;'
assert c4[0x26c0] == '@!P6 LDG.E.CONSTANT R169, [R178.64] ;'
assert c4[0x3270] == '@!P6 IMAD.WIDE.U32 R146, R169, c[0x0][0x194], R146 ;'
assert c4[0x3280] == '@!P6 SHF.R.S32.HI R169, RZ, 0x1f, R169 ;'
assert c4[0x2bf0] == '@!P6 IMAD.WIDE.U32 R136, R83, c[0x0][0x188], R136 ;'
assert all(control['C4'][pc]['write_counter'] == 5 for pc in [0x26c0, 0x3040, 0x3050])
assert control['C4'][0x3270]['wait_counters'] == [5]
assert not [pc for pc, x in control['C4'].items() if 0x26c0 < pc < 0x3270 and 5 in x['wait_counters']]
assert [pc for pc, x in control['C4'].items() if 0x26c0 <= pc < 0x3270 and x['write_counter'] == 5] == [0x26c0, 0x3040, 0x3050]
assert all(control['C2'][pc]['write_counter'] == 5 for pc in [0x26f0, 0x2720])
assert control['C2'][0x2fa0]['wait_counters'] == [5]
assert all(control['C2'][pc]['write_counter'] == 2 for pc in [0x3af0, 0x3e60])
assert all(control['C2'][pc]['wait_counters'] == [2] for pc in [0x3b20, 0x3ef0])

points = {
    'C2': {'V_page_load': 0x26f0, 'K_page_load': 0x2720, 'first_V_page_value_consumer': 0x2fa0,
           'first_K_page_value_consumer': 0x3190, 'V_page_offset_low': 0x3ad0,
           'next_K_first_consumer': 0x3b20, 'next_K_second_consumer': 0x3ef0,
           'prepublish_CTA_barrier': 0x2f00, 'instruction_after_CTA_barrier': 0x2f10},
    'C4': {'K_page_load': 0x2660, 'V_page_load': 0x26c0, 'first_K_page_value_consumer': 0x2b90,
           'V_page_offset_first_consumer': 0x3270, 'V_page_signed_high': 0x3280,
           'next_K_first_consumer': 0x3b30, 'next_K_second_consumer': 0x3bc0,
           'prepublish_CTA_barrier': 0x3b10, 'instruction_after_CTA_barrier': 0x3b20}}
samples = {}
for label, data in api.items():
    actions = []
    for action in data['actions']:
        if not action['action'] % 2:
            continue
        metrics = action['selected_metrics']
        base = metrics['launch__function_pcs']['instances'][0]['value']
        values = {name: {i['id'] - base: i['value'] for i in val['instances']}
                  for name, val in metrics.items() if name.startswith('smsp__pcsamp_') and val['instances']}
        for name in values:
            assert sum(values[name].values()) == metrics[name]['scalar']
        inst = {i['id'] - base: i['sass'] for i in metrics['inst_executed']['instances']}
        point_rows = {}
        for name, pc in points[label].items():
            if pc in inst:
                assert normalize_instruction(inst[pc], base) == normalize_instruction(rows[label][pc]), (label, hex(pc), inst[pc], rows[label][pc])
            point_rows[name] = {'relative_pc': hex(pc), 'sass': rows[label][pc],
                               'samples': {k: v.get(pc, 0) for k, v in values.items()},
                               'control': control[label][pc]}
        actions.append({'action': action['action'], 'mangled_name': action['mangled_name'],
                        'all_state_samples': metrics['smsp__pcsamp_sample_count']['scalar'],
                        'long_scoreboard_not_issued_samples': metrics['smsp__pcsamp_warps_issue_stalled_long_scoreboard_not_issued']['scalar'],
                        'points': point_rows})
    samples[label] = actions

interesting = {'C2': [0x26a0, 0x26d0, 0x26f0, 0x2720, 0x2fa0, 0x3190, 0x31a0, 0x3ad0, 0x3af0, 0x3b20, 0x3e60, 0x3ef0],
               'C4': [0x2630, 0x2640, 0x2660, 0x2680, 0x2690, 0x26c0, 0x2b90, 0x2bf0, 0x3040, 0x3050,
                      0x31b0, 0x3210, 0x3270, 0x3280, 0x36d0, 0x3b10, 0x3b30, 0x3bc0]}
review = {
    'scope': 'Offline C2 versus rejected C4 dataflow, actual PC samples and independently decoded scheduling-control words',
    'gpu_executed': False, 'cuda_compiled_by_this_analysis': False, 'canonical_modified': False,
    'inputs': {k: {'path': str(p), 'sha256': sha(p)} for k, p in inputs.items()},
    'sources': [
        {'url': f'https://raw.githubusercontent.com/cloudcores/CuAssembler/{decoder_commit}/CuAsm/CuSMVersion.py',
         'role': 'Original reverse-engineered decoder implementation explicitly includes SM89 and extracts17control bits starting at bit105; not an NVIDIA public ISA guarantee.'},
        {'url': f'https://raw.githubusercontent.com/cloudcores/CuAssembler/{decoder_commit}/CuAsm/CuControlCode.py',
         'role': 'Original code partitions stall/yield/write/read/wait fields inside the17bits.'},
        {'url': 'https://arxiv.org/html/2503.20481v1#S4',
         'role': 'Primary Ampere experimental research explains six dependence counters, grouped producers and all-producer completion at a counter wait.'},
        {'url': 'https://docs.nvidia.com/nsight-compute/ProfilingGuide/index.html#warp-stall-reasons',
         'role': 'Official stall-category meaning. A sampled consumer PC does not alone identify which grouped producer remains pending.'}],
    'parameter_layout': {
        'kernel_argument_constant_base': '0x160', 'q_offset': 0, 'paged_kv_offset': 8,
        'uint_fastdiv_size': 20, 'paged_nums_head_dim_batch_bytes': 12,
        'fields': {'stride_page': '0x188', 'stride_n': '0x18c', 'stride_h': '0x190',
                   'v_stride_page': '0x194', 'v_stride_n': '0x198', 'v_stride_h': '0x19c',
                   'k_data': '0x1a0', 'v_data': '0x1a8', 'indices': '0x1b0'},
        'basis': 'Locked source declaration order, Linux64 pointer/uint32 layout, constant pointers used by actual LDG chains; independent reviewer also checked prior actual376B parameter snapshot.'},
    'dataflow_findings': [
        'R169 at C4:3270 is the physical page index loaded at26c0. The pointer is indices+4*page_iter:2640 and2690 form identical addresses from the sameR174 and the samec[1b0] under!P6.',
        'C4:2660 reads that same address intoR83 for K; its offset uses k stride_page c188. C4:26c0 reads it again intoR169 for V; its offset uses v stride_page c194. Separate strides are required, separate page-table reads are not required for immutable indices.',
        'C4:31b0 computes head*v_stride_h;3210 adds entry*v_stride_n;3270 adds page_id*v_stride_page. This is V address calculation, not K payload, V payload or the decoder.',
        'C2 already has the same duplicate page lookup at26f0(R113,V) and2720(R169,K), so C4 asm memory clobbers did not create that duplication.',
        'C2 first V-page consumer is2fa0 SHF, earlier than3ad0 low-offset IMAD. Those two instructions and the K-page consumers have zero sampled long-scoreboard events. Saying only that late K decoder waits hid a pre-existing V metadata wait is unsupported.'
    ],
    'control_word_findings': [
        'C4:26c0 V-page-index LDG and3040/3050 both raw-K LDGs all write dependence counter5. There is no wait5 between26c0 and3270;3270 waits exactlycounter5. Consequently that wait also covers both raw-K payload loads, despite its visible arithmetic operandR169 coming from the page table.',
        'C2:both page-index LDGs writecounter5, and2fa0 waits5 before any next-K raw load. The late raw-K LDGs usecounter2, with the two PRMT consumers waitingcounter2. This is a materially different grouping and wait placement.',
        'C4 zero samples at the two PRMT consumers do not prove their memory latency was fully hidden: a counter5 completion wait can already stall the warp in the middle of softmax at3270.',
        'This explains a plausible source of stall migration without claiming that all3270 events are a page-table miss. The exact split between page-index and raw-K completion within that shared counter is not observable from these collected metrics.'
    ],
    'control_words': {label: {hex(pc): control[label][pc] for pc in pcs} for label, pcs in interesting.items()},
    'primary_decoder_roundtrip': {'commit': decoder_commit,
        'path': str(inputs['primary_decoder_roundtrip']), 'sha256': sha(inputs['primary_decoder_roundtrip']),
        'result': 'All2032 C2 words and2024 C4 words split/merge and text decode/encode using the original primary implementation; full128bit words reconstruct exactly. This is format crosschecking, not new GPU semantic validation.'},
    'sample_correspondence_by_semantics': samples,
    'asm_clobber_interpretation': [
        'The source memory clobber is a compiler memory-scheduling constraint, but both duplicate index loads are already present in C2 and occur before both C4 asm loads. The collected evidence does not show that the clobber caused the duplicate read.',
        'The machine-level shared dependence-counter grouping is directly relevant even if source expressions appear independent. No compiler-flag or cubin control-word rewriting is proposed.'
    ],
    'next_experiment_basis': [
        'C5 can share a single protected IdType page_idx, then call the two existing offset functions with independent strides. This removes one actual duplicate read and avoids a separate V-page load lifetime crossing the raw-K prefetch region.',
        'Actual C5 SASS must show one main-loop index load, earlyK reads, and the absence or relocation of the premature grouped wait. Numerical and ordinary public measurements decide whether it is useful.',
        'Further-earlier K loads alone do not address the demonstrated shared-counter wait. The current data also do not quantify a cycle budget removable by fewer decoder instructions.'
    ],
    'limits': [
        'Control bit decoding relies on a primary third-party reverse-engineered implementation plus primary Ampere experiments; it is identified explicitly and is not represented as NVIDIA official SM89 ABI documentation.',
        'The counter argument establishes what a wait covers; it does not measure which producer was last on each sampled event.',
        'No barrier_notissued category was collected for C4. Zero all-state samples at BAR3b10 and samples at nextBRA3b20 cannot certify that CTA barrier waiting vanished.',
        'Separate profiler runs have different clocks/replays. Sample totals are not elapsed-time percentages or a causal decomposition of the ordinary benchmark.',
        'C4 ordinary normal/replay intervals crossed zero, so C4 remains rejected regardless of the improved original decoder-PC samples.'
    ]
}
(OUT / 'dependency-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'dependency-review.json'), 'sha256': sha(OUT / 'dependency-review.json')}, indent=2))
