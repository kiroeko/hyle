"""Fetch known, read-only primary source snapshots and roundtrip existing words."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import urllib.request

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
SOURCES = OUT / 'primary-sources'
SOURCES.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def read_url(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'Hyle-offline-codegen-inspection'})
    with urllib.request.urlopen(request, timeout=20) as response:
        return response.read()

metadata = read_url('https://api.github.com/repos/cloudcores/CuAssembler/commits/master')
(SOURCES / 'commit.json').write_bytes(metadata)
commit = json.loads(metadata)['sha']
paths = {}
for name in ['CuControlCode.py', 'CuSMVersion.py']:
    url = f'https://raw.githubusercontent.com/cloudcores/CuAssembler/{commit}/CuAsm/{name}'
    p = SOURCES / name
    p.write_bytes(read_url(url))
    paths[name] = {'path': str(p), 'sha256': sha(p), 'url': url}

# CuControlCode was read in full before this import: it contains a regex, pure
# split/merge/format helpers and tests guarded by __name__ == '__main__'. It has
# no GPU/tool/process/file/network calls. No package is installed.
control_path = SOURCES / 'CuControlCode.py'
spec = importlib.util.spec_from_file_location('read_only_primary_control_decoder', control_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
decoder = module.CuControlCode

# Inspect (do not execute) the architecture file. Its explicit SM89 entry and
# class constants supply the extraction position/mask for the original format.
architecture = (SOURCES / 'CuSMVersion.py').read_text(encoding='utf-8')
assert '80, 86, 87, 89' in architecture
assert 'CCPos_7x_8x = 64+41' in architecture
assert 'CCMask_7x_8x = 0x1ffff<<(64+41)' in architecture
ast.parse(architecture)
pos = 105
mask = 0x1ffff << pos
roundtrip = {}
for label in ['c2', 'c4']:
    p = ROOT / f'.scratch/g04-bf16-{label}-codegen/{label}-bf16-prefill-codewords.txt'
    words = p.read_text().splitlines()
    values = []
    for idx, line in enumerate(words):
        low, high = (int(x, 16) for x in line.split(':'))
        raw = low | high << 64
        code = (raw & mask) >> pos
        fields = decoder.splitCode(code)
        reencoded = decoder.mergeCode(*fields)
        text = decoder.decode(code)
        assert decoder.encode(text) == reencoded == code
        rebuilt = (raw & ~mask) | (reencoded << pos)
        assert rebuilt == raw
        if idx * 16 in ([0x26f0, 0x2720, 0x2fa0, 0x3af0, 0x3b20, 0x3e60, 0x3ef0] if label == 'c2' else [0x2660, 0x26c0, 0x3040, 0x3050, 0x3270, 0x3b30, 0x3bc0]):
            values.append({'pc': hex(idx * 16), 'raw_low64': hex(low), 'raw_high64': hex(high),
                           'control_bits': hex(code), 'primary_decoder_text': text,
                           'split_fields_wait_read_write_yield_stall': fields,
                           'reencoded_full128bit_equal': True})
    roundtrip[label] = {'input': str(p), 'sha256': sha(p), 'all_instruction_words_roundtripped': len(words), 'key_rows': values}

result = {
    'scope': 'Original primary decoder source snapshot and pure CPU field-format roundtrip; no tool installation or GPU',
    'commit': commit, 'commit_metadata_sha256': sha(SOURCES / 'commit.json'), 'primary_sources': paths,
    'source_lines': {'CuSMVersion.py': '26-31 SM89 list;73-78 extraction mask/position',
                     'CuControlCode.py': '35-54 split;69-75 merge;78-103 text decode/encode'},
    'primary_implementation_used': 'CuControlCode.splitCode/mergeCode/decode/encode from exact downloaded source',
    'roundtrip': roundtrip,
    'limits': ['This confirms exact field extraction/representation and reconstruction of every original128bit word; it is not a new hardware semantics validation.',
               'The implementation is a primary third-party reverse-engineered source, not NVIDIA ISA/ABI documentation. Architecture applicability is its explicit SM89 support plus matching retained control encodings.',
               'No downloaded code changes or executes a cubin; no source/product/vendor file or GPU state is modified.']}
(OUT / 'control-decoder-roundtrip.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'commit': commit, 'output': str(OUT / 'control-decoder-roundtrip.json'), 'sha256': sha(OUT / 'control-decoder-roundtrip.json')}, indent=2))
