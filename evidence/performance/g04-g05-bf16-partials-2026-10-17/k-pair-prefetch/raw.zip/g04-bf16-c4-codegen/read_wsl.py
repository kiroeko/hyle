from pathlib import Path
import collections,difflib,hashlib,json,re,subprocess,time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
OUT=ROOT/'.scratch/g04-bf16-c4-codegen';OUT.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
binding_path=ROOT/'.scratch/g04-bf16-c4/archive-result.json'
binding=json.loads(binding_path.read_text());assert binding['compile_returncode']==0
obj=Path(binding['object']);archive=Path(binding['C4_archive'])
assert sha(obj.read_bytes())==binding['object_sha256']
assert sha(archive.read_bytes())==binding['C4_archive_sha256']
assert sha(subprocess.check_output(['ar','p',str(archive),'native_cache.cu.o']))==binding['object_sha256']
refpath=ROOT/'.scratch/g04-bf16-c2-codegen/review.json'
ref=json.loads(refpath.read_text())
assert sha(Path(binding['C2_archive']).read_bytes())==binding['C2_archive_sha256']
assert ref['current']['object_sha256']==binding['members_before']['native_cache.cu.o']
trait='MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1E'
parser_path=ROOT/'.scratch/g04-bf16-product-codegen/review_wsl.py'
parser=parser_path.read_text();start=parser.index('def symbols(');end=parser.index("record={'state':")
exec(compile(parser[start:end],str(parser_path),'exec'))
current=dump('c4',obj,True)
record={'scope':'Read-only C4 versus retained C2 SM89 codegen; no CUDA compilation or GPU execution','gpu_executed':False,'recompiled':False,'binding':str(binding_path),'binding_sha256':sha(binding_path.read_bytes()),'C2_reference':str(refpath),'C2_reference_sha256':sha(refpath.read_bytes()),'parser_sha256':sha(parser_path.read_bytes()),'current':current,'comparisons':[]}
for kind,b in current['kernels'].items():
    a=ref['current']['kernels'][kind]
    row={'kind':kind,'C2':a,'C4':b,'instructions_equal':a['normalized_sha256']==b['normalized_sha256'],'encoded_schedule_words_equal':a['codewords_sha256']==b['codewords_sha256'],'resource_equal':a['resource']==b['resource']}
    for suffix in ['instructions','codewords']:
        before=(ROOT/f'.scratch/g04-bf16-c2-codegen/c2-{kind}-{suffix}.txt').read_text()
        expected=a['normalized_sha256'] if suffix=='instructions' else a['codewords_sha256']
        assert sha(before.encode())==expected
        after=(OUT/f'c4-{kind}-{suffix}.txt').read_text()
        (OUT/f'C2-vs-C4-{kind}-{suffix}.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='C2',tofile='C4')))
    record['comparisons'].append(row)
sass=(OUT/'c4-sass.txt').read_text()
chunks={piece.splitlines()[0]:piece for piece in re.split(r'\s*Function : ',sass)[1:]}
rows={kind:[{'pc':m[1],'sass':m[2].strip()} for m in re.finditer(r'/\*([0-9a-fA-F]+)\*/\s+(.+?;)',chunks[name])] for kind,name in current['symbols'].items()}
(OUT/'c4-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
types=['LDG.E.128','PRMT','HFMA2.BF16_V2','LDGSTS','DEPBAR.LE','BAR.SYNC','MUFU.EX2','HMMA.16816.F32.BF16','ISETP.LT.U32.OR']
record['BF16_chain_PCs']={op:[row['pc'] for row in rows['bf16-prefill'] if op in row['sass']] for op in types}
record['limits']=['Static SHARED:0 is not dynamic shared-memory usage. No native occupancy API is called here. Dynamic SharedStorage type and launch geometry are unchanged by C4 source, but actual execution facts belong to the runner.','No numerical or performance verdict follows solely from codegen.','First/second K and V load sites must be identified from surrounding address-use and publish dependency, not inferred from instruction count.']
(OUT/'review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'comparisons':[{k:r[k] for k in ['kind','instructions_equal','encoded_schedule_words_equal','resource_equal']} for r in record['comparisons']],'resources':{k:{s:v[s] for s in ['instruction_count','resource','normalized_sha256']} for k,v in current['kernels'].items()},'BF16_chain_PCs':record['BF16_chain_PCs']},indent=2))
