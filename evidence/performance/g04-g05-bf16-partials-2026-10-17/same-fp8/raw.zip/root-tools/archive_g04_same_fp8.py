from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[1]
source = root / '.scratch/g04-same-fp8-comparison'
dest = root / 'evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8'
sha = lambda data: hashlib.sha256(data).hexdigest()
skip_dirs = {'__pycache__', 'pristine', 'pristine-source', 'effective-source', 'sync-fixed-source'}

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--result', required=True)
    args = parser.parse_args()
    entries, external = [], []
    with zipfile.ZipFile(dest / 'raw.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        paths = [(p, p.relative_to(source).as_posix()) for p in source.rglob('*') if p.is_file()]
        review = root / '.scratch/g04-g05-sameprocess-review'
        paths += [(p, 'independent/' + p.name) for p in review.glob('same-fp8-*') if p.is_file()]
        for name in ['analyze_same_fp8.py', 'analyze_same_fp8_product.py',
                     'review_same_fp8_runtime.py', 'review_same_fp8_source.py']:
            p = review / name
            if p.is_file():
                paths.append((p, 'independent/' + name))
        paths.append((Path(__file__), 'root-tools/archive_g04_same_fp8.py'))
        for path, name in sorted(paths, key=lambda item: item[1]):
            if any(part in skip_dirs for part in Path(name).parts):
                continue
            data = path.read_bytes()
            item = {'path': name, 'bytes': len(data), 'sha256': sha(data)}
            if path.suffix in {'.o', '.a', '.exe', '.cubin', '.ncu-rep'} or data[:4] == b'\x7fELF':
                external.append(dict(item, local_path=str(path), archived=False))
                continue
            archive.writestr(name, data)
            entries.append(item)
    raw = (dest / 'raw.zip').read_bytes()
    result = {'archive': 'raw.zip', 'archive_bytes': len(raw), 'archive_sha256': sha(raw),
              'entries': entries, 'external_local_artifacts': external, 'result': args.result,
              'product_code_changed': False}
    (dest / 'archive.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(dest / 'raw.zip') as archive:
        assert set(archive.namelist()) == {item['path'] for item in entries}
        for item in entries:
            data = archive.read(item['path'])
            assert len(data) == item['bytes'] and sha(data) == item['sha256'], item['path']
    print(json.dumps({'files': len(entries), 'archive_bytes': len(raw), 'archive_sha256': sha(raw)}))

if __name__ == '__main__':
    main()
