from pathlib import Path
import json,hashlib,subprocess,time
REPO=Path('/mnt/c/public/project-hyle/hyle');OUT=REPO/'.scratch/g04-same-fp8-comparison';WORK=Path('/root/hyle-scratch/compute-unified/g04-same-fp8-comparison')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((REPO/'.scratch/g04-bf16-c6-peer/link-result.json').read_text())
reference_result=OUT/'sync-fixed/reference-build-result.json'
meta=json.loads(reference_result.read_text());ref=Path(meta['library'])
assert sha(ref)==meta['library_sha256']=='903576718caa737f73eede52f634ac7c154b85bdf44e914a6ec8e12b7e6809d3'
assert meta['source_sha256']==sha(Path(meta['cwd'])/'upstream_reference.cu')
assert meta['header_after_sha256']==sha(Path(meta['upstream_directory'])/meta['only_upstream_file_changed'])
cmd=list(old['argv']);cmd[cmd.index('-o')+1]=str(WORK/'same_fp8');cmd=[('-Wl,-Map='+str(WORK/'link.map')) if x.startswith('-Wl,-Map=') else x for x in cmd]
idx=cmd.index('/root/hyle-scratch/compute-unified/g04-bf16-product-peer-bench/consumer.o')
cmd[idx:idx+1]=[str(WORK/'consumer.cc.o'),str(WORK/'reference_adapter.cc.o'),str(ref)]
start=time.monotonic()
with (OUT/'link.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
record={'argv':cmd,'returncode':p.returncode,'elapsed_s':time.monotonic()-start,'sources':{n:sha(OUT/n) for n in ['consumer.cc','reference_adapter.cc','reference_adapter.h','reference_api.h']},'archives':{x:sha(x) for x in cmd if x.endswith('.a') and Path(x).is_file()},'GPU_executed':False,'host_objects':{str(WORK/n):sha(WORK/n) for n in ['consumer.cc.o','reference_adapter.cc.o']}}
if p.returncode==0:
 record['binary']=str(WORK/'same_fp8');record['binary_sha256']=sha(WORK/'same_fp8');record['map_sha256']=sha(WORK/'link.map')
 symbols=subprocess.check_output(['nm','-C',str(WORK/'same_fp8')],text=True)
 record['upstream_namespace_present']='g04_syncfixed_same_fp8_flashinfer' in symbols
 record['reference_build']=meta;record['reference_build_result_sha256']=sha(reference_result)
 record['external_inputs']={str(Path(meta['cwd'])/'upstream_reference.cu'):meta['source_sha256'],str(Path(meta['upstream_directory'])/meta['only_upstream_file_changed']):meta['header_after_sha256'],str(reference_result):sha(reference_result)}
 record['C6_archive_sha256']=record['archives']['/root/hyle-scratch/compute-unified/g04-bf16-c6/libhyle_compute_provider_flashinfer_c6.a']
 assert record['C6_archive_sha256']=='bbf3ec34a9aa0d7916ffc3ebb4a340583946ec3ce2bc33a6c0dc2711256ecec2'
(OUT/'link-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['returncode','elapsed_s','binary','binary_sha256'] if k in record}))
raise SystemExit(p.returncode)
