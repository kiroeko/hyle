#include "reference_adapter.h"
#include "reference_api.h"
#include "provider_internal.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/detail/batch_provider.h"
#include "hyle/compute/detail/paged_arena_access.h"
#include "hyle/compute/providers/flashinfer.h"
#include "native_context.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <exception>
#include <new>
#include <vector>

namespace hyle::bench::resident {
namespace c=compute;namespace d=c::detail;namespace n=cuda_original;
namespace {
bool same_layout(const c::BatchLayoutVersion &a,const c::BatchLayoutVersion &b) noexcept {
  if(!a.valid()||!a.schema().owns(b))return false;
  const auto x=a.host(),y=b.host();
  const auto eq=[](auto u,auto v){return u.size()==v.size()&&std::equal(u.begin(),u.end(),v.begin());};
  return eq(x.query_indptr,y.query_indptr)&&eq(x.kv_indptr,y.kv_indptr)&&
      eq(x.page_indices,y.page_indices)&&eq(x.last_page_lengths,y.last_page_lengths);
}
struct Context {const SameFp8ReferenceData *data=nullptr;CUcontext primary=nullptr;};
struct Slot {
  Context context;c::BatchCapacity capacity;c::BatchProgramOptions options;
  c::BatchLayoutVersion layout;n::Spec spec;n::Facts facts;void *plan=nullptr;
  ~Slot(){n::destroy_plan(plan);}
};
Status qualify(void *opaque,c::BatchCapacity cap,const c::BatchProgramOptions &options) noexcept {
  const auto *ctx=static_cast<Context *>(opaque);
  if(!ctx||!ctx->data||!ctx->data->layout.valid()||!ctx->primary||cap!=ctx->data->layout.schema().capacity())
    return Status::FailedPrecondition("original CUDA immutable snapshot is not ready");
  if(cap.storage!=c::BatchStorage::kPaged||cap.query_type!=c::DataType::kBFloat16||
      cap.output_type!=cap.query_type||cap.key_storage!=c::CacheStorage::float8(.5F).value()||
      cap.value_storage!=c::CacheStorage::float8(2.F).value()||cap.query_heads!=8||cap.kv_heads!=2||
      cap.page_size!=16||!((cap.qk_head_dim==256&&cap.value_head_dim==256&&options.causal&&
      (options.window_left==-1||options.window_left==16))||
      (cap.qk_head_dim==64&&cap.value_head_dim==128&&!options.causal&&options.window_left==-1)))
    return Status::Unimplemented("finite original CUDA direct FP8 comparator");
  return Status::Ok();
}
Status create(void *ctx,c::BatchCapacity cap,const c::BatchProgramOptions &options,
    mem::AllocatorRef allocator,void **out) noexcept {
  *out=nullptr;HYLE_RETURN_IF_ERROR(qualify(ctx,cap,options));
  auto *s=allocator.construct<Slot>();if(!s)return Status::ResourceExhausted("original CUDA slot");
  s->context=*static_cast<Context *>(ctx);s->capacity=cap;s->options=options;
  const auto offsets=s->context.data->layout.schema().metadata_offsets();
  s->spec={.query_heads=cap.query_heads,.kv_heads=cap.kv_heads,.key_depth=cap.qk_head_dim,
      .value_depth=cap.value_head_dim,.page_size=cap.page_size,
      .query_offset=offsets.query_indptr,.kv_offset=offsets.kv_indptr,
      .indices_offset=offsets.page_indices,.tails_offset=offsets.last_page_lengths,
      .scale=options.scale,.window=options.window_left,.causal=options.causal,.key_scale=cap.key_storage.scale(),.value_scale=cap.value_storage.scale()};
  try{s->plan=n::create_plan();*out=s;return Status::Ok();}
  catch(const std::bad_alloc &){allocator.destroy(s);return Status::ResourceExhausted("original CUDA plan");}
}
void destroy(void *p,mem::AllocatorRef a) noexcept {a.destroy(static_cast<Slot *>(p));}
c::BatchPlanReport report(const Slot &s,bool reused=false) noexcept {
  return {.layout_generation=s.layout.generation(),.float_workspace_bytes=s.facts.floating,
      .int_workspace_bytes=s.facts.integer,.cta_tile_q=s.facts.tile,.padded_batch_size=s.facts.padded,
      .split_kv=s.facts.split,.bf16_partials=s.facts.split,.reused_native_plan=reused};
}
Result<bool> update(void *p,const c::BatchLayoutVersion &layout,c::BatchPlanReport *r) noexcept {
  auto &s=*static_cast<Slot *>(p);
  if(!s.layout.valid()||!s.layout.schema().owns(layout))return false;
  const auto old=s.layout.host(),next=layout.host();
  const auto eq=[](auto u,auto v){return u.size()==v.size()&&std::equal(u.begin(),u.end(),v.begin());};
  // The original plan depends on Q/KV indptr. Page IDs/tails remain runtime
  // metadata. Match the product's fixed-topology fast path, not a second full
  // snapshot comparison on every warm episode.
  if(!eq(old.query_indptr,next.query_indptr)||!eq(old.kv_indptr,next.kv_indptr))return false;
  s.layout=layout;*r=report(s,true);return true;
}
d::EnqueueResult plan(void *p,c::Queue &queue,const c::BatchLayoutVersion &layout,
    d::BatchWorkspaceViews views,c::BatchPlanReport *r) noexcept {
  auto &s=*static_cast<Slot *>(p);s.layout={};
  if(!same_layout(s.context.data->layout,layout))
    return d::EnqueueResult::rejected(Status::InvalidArgument("original CUDA snapshot topology changed"));
  auto stream=c::cuda::stream(queue);if(!stream)return d::EnqueueResult::rejected(stream.error());
  auto f=c::cuda::detail::mutable_pointer(views.float_workspace,16,1);
  if(!f)return d::EnqueueResult::rejected(f.error());
  auto i=c::cuda::detail::mutable_pointer(views.int_workspace,16,1);
  if(!i)return d::EnqueueResult::rejected(i.error());
  auto host=views.host_workspace.map_host();if(!host)return d::EnqueueResult::rejected(host.error());
  auto bytes=host->writable_bytes();if(!bytes)return d::EnqueueResult::rejected(bytes.error());
  c::cuda::detail::ScopedPrimaryContext scope(s.context.primary);
  if(!scope)return d::EnqueueResult::rejected(scope.status());
  const auto h=layout.host();auto spec=s.spec;spec.requests=layout.facts().requests;spec.query_rows=layout.facts().query_rows;
  bool accepted=false;
  try{
    n::Facts facts;
    auto status=c::cuda::status(n::workspace(spec,h.query_indptr.data(),h.kv_indptr.data(),*stream,facts));
    if(!status.ok())return d::EnqueueResult::rejected(status);
    if(facts.floating>views.float_workspace.size()||facts.integer>views.int_workspace.size()||facts.integer>bytes->size())
      return d::EnqueueResult::rejected(Status::ResourceExhausted("original CUDA plan workspace"));
    accepted=true; // The original planner may enqueue an H2D prefix before failing.
    status=c::cuda::status(n::plan(s.plan,spec,h.query_indptr.data(),h.kv_indptr.data(),
        *f,views.float_workspace.size(),*i,bytes->data(),views.int_workspace.size(),*stream,facts));
    if(status.ok()){s.spec=spec;s.facts=facts;s.layout=layout;*r=report(s);
      std::printf("REFERENCE_NATIVE tile=%u padded=%u split=%d kv_chunk_rows=%u partial_bytes=%u workspace_float=%zu workspace_int=%zu key_scale=%.9g value_scale=%.9g\n",facts.tile,facts.padded,facts.split,facts.kv_chunk_rows,facts.partial_bytes,facts.floating,facts.integer,spec.key_scale,spec.value_scale);}
    return {accepted,status};
  }catch(const std::bad_alloc &){return {accepted,Status::ResourceExhausted("original CUDA planner allocation")};}
   catch(const std::exception &e){return {accepted,Status::Internal(e.what())};}
}
d::EnqueueResult run(void *p,c::Queue &queue,std::span<const c::ConstTensorView> inputs,
    d::BatchWorkspaceViews views) noexcept {
  auto &s=*static_cast<Slot *>(p);
  if(!s.layout.valid()||inputs.size()!=3)return d::EnqueueResult::rejected(Status::FailedPrecondition("original CUDA layout missing"));
  // Public Batch admission retains and validates the actual input leases.
  // Read the submitted FP8 pointers, exactly as the product provider does;
  // the harness proves common immutable storage before and after timing.
  auto stream=c::cuda::stream(queue);if(!stream)return d::EnqueueResult::rejected(stream.error());
  auto q=c::cuda::detail::const_pointer(inputs[0].storage(),16,2);if(!q)return d::EnqueueResult::rejected(q.error());
  auto k=c::cuda::detail::const_pointer(inputs[1].storage(),16,1);if(!k)return d::EnqueueResult::rejected(k.error());
  auto v=c::cuda::detail::const_pointer(inputs[2].storage(),16,1);if(!v)return d::EnqueueResult::rejected(v.error());
  auto m=c::cuda::detail::const_pointer(views.metadata,8,1);if(!m)return d::EnqueueResult::rejected(m.error());
  auto f=c::cuda::detail::mutable_pointer(views.float_workspace,16,1);if(!f)return d::EnqueueResult::rejected(f.error());
  auto i=c::cuda::detail::mutable_pointer(views.int_workspace,16,1);if(!i)return d::EnqueueResult::rejected(i.error());
  auto o=c::cuda::detail::mutable_pointer(views.output,16,2);if(!o)return d::EnqueueResult::rejected(o.error());
  c::cuda::detail::ScopedPrimaryContext scope(s.context.primary);
  if(!scope)return d::EnqueueResult::rejected(scope.status());
  try{return d::EnqueueResult::accepted_command(c::cuda::status(n::run(s.plan,s.spec,*q,*k,*v,*m,*o,*f,*i,*stream)));}
  catch(const std::bad_alloc &){return d::EnqueueResult::accepted_command(Status::ResourceExhausted("original CUDA run allocation"));}
  catch(const std::exception &e){return d::EnqueueResult::accepted_command(Status::Internal(e.what()));}
}
const d::BatchProviderVTable batch{&qualify,&create,&destroy,&update,&plan,&run};
struct Config {const SameFp8ReferenceData *data;};
const d::ProviderVTable &table(){static const auto t=[]{
  auto base=c::flashinfer::provider();auto t=*d::ProviderAccess::vtable(base);
  t.identity={.id={0x48594c4542454e43ULL,0x43554441454e4301ULL},.name="original-cuda-resident-fp8-cache",.version="69ff11fc-pristine-fp8-vscale-hook"};
  t.create_context=[](const c::Provider &provider,c::Device device,void *backend,mem::AllocatorRef a,void **out) noexcept {
    *out=nullptr;if(device.backend_id()!=c::cuda::kBackendId)return Status::Unimplemented("original CUDA device");
    const auto *env=c::cuda::detail::borrow_environment(backend);
    const auto primary=c::cuda::detail::borrow_primary_context(backend);
    if(!primary||!env||env->sm_major!=8||env->sm_minor!=9)return Status::Unimplemented("original CUDA finite SM89 profile");
    const auto *data=d::ProviderAccess::payload<Config>(provider).data;
    if(!data)return Status::InvalidArgument("original CUDA data missing");
    auto *ctx=a.construct<Context>(Context{data,primary});
    if(!ctx)return Status::ResourceExhausted("original CUDA provider context");
    *out=ctx;return Status::Ok();
  };
  t.destroy_context=[](void *p,mem::AllocatorRef a) noexcept {a.destroy(static_cast<Context *>(p));};
  t.drain_context=[](void *) noexcept {return Status::Ok();};
  t.propose=[](void *,const d::ProviderOperationRequest &,std::span<d::ResourceBindingRequirement>,std::span<d::ResourceBindingRequirement>,d::ProviderOperationProposal *) noexcept {return Status::Unimplemented("original CUDA batch-only comparator");};
  t.prepare=[](void *,const d::ProviderPrepareRequest &,mem::AllocatorRef,d::ProviderPrepared *) noexcept {return c::ProviderPrepareOutcome::unsupported(Status::Unimplemented("original CUDA batch only"));};
  t.query_extension=[](void *,c::ProviderExtensionId id) noexcept ->const void * {return id==d::kBatchPlanningExtensionId?&batch:nullptr;};
  return t;
}();return t;}
}
c::Provider same_fp8_reference_provider(const SameFp8ReferenceData *data) noexcept {
  return d::ProviderAccess::make(&table(),Config{data});
}
}
