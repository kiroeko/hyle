#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif
#include "hyle/compute/paged_arena.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/flashinfer.h"

#include "hyle/compute/batch_execution.h"
#include "hyle/simd/dtype.h"
#include "reference_adapter.h"
#include "hyle/compute/detail/batch_graph_access.h"
#include "hyle/compute/detail/paged_arena_access.h"
#include <cstring>
#include <cuda_runtime_api.h>
#include <sched.h>
#include <array>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <nvtx3/nvToolsExt.h>

namespace {
#ifndef HYLE_RESIDENT_PLACEMENT
#define HYLE_RESIDENT_PLACEMENT 0
#endif
namespace c=hyle::compute;
[[noreturn]] void fail(hyle::Status status){std::fprintf(stderr,"CUDA encoded: %.*s\n",int(status.message().size()),status.message().data());std::exit(2);}
void check(hyle::Status status){if(!status.ok())fail(status);}
template<class T>T take(hyle::Result<T> value){if(!value)fail(value.error());return std::move(*value);}
[[maybe_unused]] bool set(const char *name){const auto *p=std::getenv(name);return p&&*p;}
float decode(std::uint16_t x){return std::bit_cast<float>(std::uint32_t(x)<<16);}
std::uint16_t encode(float x){return std::uint16_t(std::bit_cast<std::uint32_t>(x)>>16);}
double fp8(std::uint8_t code){const unsigned e=(code&127)>>3,m=code&7;
  const double value=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);
  return code&128?-value:value;
}
struct Data {
  c::BatchCapacity capacity;
  std::array<std::int32_t,3> qp,kp;
  std::vector<std::int32_t> ids;std::array<std::int32_t,2> tails;
  std::vector<std::uint16_t> query;
  std::array<std::vector<std::byte>,2> packed;
  std::array<std::vector<float>,2> decoded;
  float scale;bool causal;std::int32_t window;
  Data(int q1,int q2,int k1,int k2,int dk,int dv,bool masked,int left):
    capacity{.storage=c::BatchStorage::kPaged,.query_type=c::DataType::kBFloat16,
      .output_type=c::DataType::kBFloat16,.key_storage=c::CacheStorage::float8(.5F).value(),
      .value_storage=c::CacheStorage::float8(2.F).value(),.max_requests=2,
      .max_query_rows=unsigned(q1+q2+3),.max_kv_rows=unsigned(k1+k2+13),
      .max_pages=unsigned((k1+15)/16+(k2+15)/16+2),.max_page_refs=unsigned((k1+15)/16+(k2+15)/16),
      .query_heads=8,.kv_heads=2,.qk_head_dim=unsigned(dk),.value_head_dim=unsigned(dv),.page_size=16},
    qp{0,q1,q1+q2},kp{0,(k1+15)/16,(k1+15)/16+(k2+15)/16},
    scale(1.F/std::sqrt(float(dk))),causal(masked),window(left){
    tails={(k1-1)%16+1,(k2-1)%16+1};
    for(unsigned i=0;i<capacity.max_page_refs;++i)ids.push_back(static_cast<std::int32_t>(capacity.max_pages-1-i));
    ids[static_cast<unsigned>(kp[1])]=ids[0];
    query.resize(std::size_t(capacity.max_query_rows)*8*dk);
    for(std::size_t i=0;i<query.size();++i)query[i]=encode(.125F+float((i/dk)%8%3)*.015625F);
    for(unsigned port=0;port<2;++port){
      const auto depth=port?dv:dk;
      auto &bytes=packed[port];auto &values=decoded[port];
      values.resize(std::size_t(capacity.max_pages)*16*2*depth);
      bytes.resize(values.size());
      // Independent finite FP8 fixture; the oracle decodes these actual bytes.
      for(std::size_t i=0;i<bytes.size();++i){
        const auto row=i/(2*depth),head=(i/depth)%2;
        constexpr std::uint8_t key_codes[]{0,56,64,68,72},value_codes[]{16,24,28,32,34};
        const auto code=(port?value_codes:key_codes)[(row+head)%5];
        bytes[i]=std::byte(code);values[i]=float(fp8(code)*(port?2.:.5));
      }
      for(unsigned page=0;page<capacity.max_pages;++page){
        unsigned valid=0;
        for(unsigned r=0;r<2;++r)for(auto ref=kp[r];ref<kp[r+1];++ref)
          if(ids[unsigned(ref)]==int(page))valid=std::max(valid,ref+1==kp[r+1]?unsigned(tails[r]):16u);
        for(auto i=std::size_t(page*16+valid)*2*depth;i<std::size_t((page+1)*16)*2*depth;++i){
          bytes[i]=std::byte(0x78);values[i]=float(fp8(0x78)*(port?2.:.5));
        }
      }
    }
  }
  std::size_t row_bytes(unsigned port)const{const auto storage=port?capacity.value_storage:capacity.key_storage;return std::size_t(2)*(port?capacity.value_head_dim:capacity.qk_head_dim)*(storage.data_type()==c::DataType::kFloat8E4M3FN?1u:2u);}
  std::vector<double> oracle()const{
    const auto dk=capacity.qk_head_dim,dv=capacity.value_head_dim;
    std::vector<double> output(std::size_t(qp[2])*8*dv),weights;double uniform_difference=0;
    for(unsigned r=0;r<2;++r){const int nq=qp[r+1]-qp[r],nk=(kp[r+1]-kp[r]-1)*16+tails[r];weights.resize(nk);
      for(int row=0;row<nq;++row)for(unsigned h=0;h<8;++h){double sum=0;
        const auto position=nk-nq+row;
        for(int j=0;j<nk;++j){
          if(causal&&(j>position||(window>=0&&j<std::max(0,position-window)))){weights[j]=0;continue;}
          double dot=0;for(unsigned d=0;d<dk;++d)dot+=double(decode(query[(std::size_t(qp[r]+row)*8+h)*dk+d]))*
              decoded[0][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dk+d];
          weights[j]=std::exp(dot*scale);sum+=weights[j];
        }
        for(unsigned d=0;d<dv;++d)for(int j=0;j<nk;++j)output[(std::size_t(qp[r]+row)*8+h)*dv+d]+=
            weights[j]/sum*decoded[1][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dv+d];
        double uniform=0;unsigned eligible=0;
        for(int j=0;j<nk;++j)if(weights[j]>0){++eligible;
          uniform+=decoded[1][((std::size_t(ids[unsigned(kp[r]+j/16)])*16+j%16)*2+h/4)*dv];}
        uniform_difference=std::max(uniform_difference,std::abs(
            output[(std::size_t(qp[r]+row)*8+h)*dv]-uniform/eligible));
      }
    }
    if(uniform_difference<=.01)fail(hyle::Status::Internal("FP8 oracle fixture cannot distinguish missing QK loads"));
    std::fprintf(stderr,"# CUDA_ENCODED_ORACLE uniform_difference=%.9g\n",uniform_difference);
    return output;
  }
};

using Clock=std::chrono::steady_clock;
double us(Clock::duration d){return std::chrono::duration<double,std::micro>(d).count();}
// Sole owner of the actual Q and immutable FP8 pages used by BOTH arms.
struct CommonResident {
  hyle::bench::resident::SameFp8ReferenceData reference;
  c::Context context;c::cuda::MemoryResource memory,host;c::Queue queue;
  c::BatchSchema schema;c::BatchLayoutVersion layout;c::LeasePool pool;
  c::PagedArena keys,values;c::PagedArenaRead key_frame,value_frame;
  std::vector<c::ReadLease> key_pages,value_pages;std::vector<unsigned> physical_ids;c::ReadLease query;
  explicit CommonResident(const Data &data){
    const std::array bindings{c::ProviderBinding{hyle::bench::resident::same_fp8_reference_provider(&reference)},c::ProviderBinding{c::flashinfer::provider()}};
    context=take(c::Context::create(take(c::cuda::device(0)),c::ContextOptions{.providers=bindings}));
    memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
    host=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
    queue=take(context.create_queue());
    schema=take(c::BatchSchema::create(data.capacity));layout=take(schema.version({data.qp,data.kp,data.ids,data.tails}));
    const auto key_bytes=16*data.row_bytes(0),value_bytes=16*data.row_bytes(1);
    keys=take(c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory.ref(),{.max_backing_bytes=key_bytes*data.capacity.max_pages+1}));
    values=take(c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory.ref(),{.max_backing_bytes=value_bytes*data.capacity.max_pages+1}));
    for(unsigned page=0;page<data.capacity.max_pages;++page)if(std::find(data.ids.begin(),data.ids.end(),static_cast<std::int32_t>(page))!=data.ids.end()){
      auto kw=take(keys.acquire(page)),vw=take(values.acquire(page));
      check(kw.lease().view()->write(std::span(data.packed[0]).subspan(page*key_bytes,key_bytes)));
      check(vw.lease().view()->write(std::span(data.packed[1]).subspan(page*value_bytes,value_bytes)));
      physical_ids.push_back(page);key_pages.push_back(take(kw.publish(16)));value_pages.push_back(take(vw.publish(16)));
    }
    key_frame=take(keys.read(layout,key_pages));value_frame=take(values.read(layout,value_pages));
    reference.layout=layout;reference.keys=key_frame;reference.values=value_frame;
    pool=take(c::LeasePool::create(memory.ref(),data.query.size()*2+2048));
    auto writer=take(pool.allocate(data.query.size()*2));check(writer.view()->write(std::as_bytes(std::span(data.query))));query=take(writer.publish());
    check(queue.drain());
    const auto kt=take(c::detail::PagedArenaAccess::tensor(key_frame)),vt=take(c::detail::PagedArenaAccess::tensor(value_frame));
    const auto qview=take(query.view());
    std::printf("SHARED_INPUT q=%p k=%p v=%p q_resource=%p k_resource=%p v_resource=%p key_scale=0.5 value_scale=2 storage=resident_FP8 shared_by_both_arms=1 expanded_cache_bytes=0\n",
      take(c::cuda::detail::const_pointer(qview,16,2)),take(c::cuda::detail::const_pointer(kt.storage(),16,1)),take(c::cuda::detail::const_pointer(vt.storage(),16,1)),
      static_cast<const void*>(&qview.resource().resource()),static_cast<const void*>(&kt.storage().resource().resource()),static_cast<const void*>(&vt.storage().resource().resource()));
  }
  void verify_readonly(const Data &data){
    std::vector<std::uint16_t> after_q(data.query.size());check(query.view()->read(std::as_writable_bytes(std::span(after_q))));
    if(after_q!=data.query)fail(hyle::Status::Internal("shared readonly Q changed"));
    for(unsigned port=0;port<2;++port)for(unsigned index=0;index<key_pages.size();++index){
      auto view=take((port?value_pages[index]:key_pages[index]).view());std::vector<std::byte> after(view.size());check(view.read(after));
      const auto first=data.packed[port].begin()+std::size_t(physical_ids[index])*16*data.row_bytes(port);
      if(!std::equal(after.begin(),after.end(),first))fail(hyle::Status::Internal("shared readonly FP8 KV changed"));
    }
  }
  ~CommonResident(){check(queue.drain());reference={};query.reset();pool={};key_frame={};value_frame={};key_pages.clear();value_pages.clear();keys={};values={};layout={};schema={};queue={};host.reset();memory.reset();check(context.close());}
};
struct Harness {
  CommonResident &common;bool upstream=false;
  c::Queue queue;
  c::BatchProgram program;std::array<c::BatchInvocation,2> slots;std::size_t next=0;
  Harness(CommonResident &shared,const Data &data,bool original):common(shared),upstream(original){
    const auto before=take(common.memory.ref().resource().stats());
    queue=take(common.context.create_queue());
    const auto instance=take(common.context.provider_instance_id(upstream?0u:1u));
    // Existing cold provider-selection seam only; run uses the public normal
    // BatchInvocation/PreparedBatch admission, Completion and owning output.
    program=take(c::detail::BatchGraphAccess::prepare(common.context,common.schema,{.resource=common.memory.ref(),.host_workspace=common.host.ref(),.max_float_workspace_bytes=64u<<20,.max_int_workspace_bytes=1u<<20,
      .scale=data.scale,.causal=data.causal,.window_left=data.window,.allow_bf16_partials=true},instance));
    for(auto &slot:slots){slot=take(c::BatchInvocation::create(program,queue));auto prepared=take(slot.prepare_batch(common.layout));}
    const auto r=slots[0].report(),r1=slots[1].report();
    if(r.float_workspace_bytes!=r1.float_workspace_bytes||r.cta_tile_q!=r1.cta_tile_q||r.bf16_partials!=r1.bf16_partials)fail(hyle::Status::Internal("two cold slots differ"));
    const bool target=data.capacity.qk_head_dim==256&&data.window==-1&&data.causal;
    if(!upstream && r.bf16_partials!=target)fail(hyle::Status::Internal("C6 actual partial policy mismatch"));
    if(upstream&&r.bf16_partials!=r.split_kv)fail(hyle::Status::Internal("upstream BF16 temporary not reported"));
    const auto stats=take(common.memory.ref().resource().stats());
    std::printf("ARM_PLAN upstream=%d tile=%u padded=%u split=%d bf16_partials=%d float_bytes=%zu int_bytes=%zu resource_used_cumulative=%zu resource_reserved_cumulative=%zu arm_used_delta=%zu arm_reserved_delta=%zu max_float_cap=%u slots=2 captured=0 partial_dtype=%s local_accum=F32 value_scale_placement=%s\n",upstream,r.cta_tile_q,r.padded_batch_size,r.split_kv,r.bf16_partials,r.float_workspace_bytes,r.int_workspace_bytes,stats.used_bytes,stats.reserved_bytes,stats.used_bytes-before.used_bytes,stats.reserved_bytes-before.reserved_bytes,64u<<20,r.split_kv?(r.bf16_partials?"BF16":"F32"):"none",upstream?"before_partial_narrowing":"late_output_or_merge");
  }
  ~Harness(){for(auto &slot:slots){check(slot.close());slot={};}program={};check(queue.drain());queue={};}
  c::ReadLease execute(){auto &slot=slots[next++%slots.size()];auto prepared=take(slot.update_batch(common.layout));
    if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("warm topology rebuilt"));
    auto completion=take(prepared.run(common.query,common.key_frame,common.value_frame));check(completion.wait());return take(slot.output());}
  std::vector<std::uint16_t> verify(const Data &data,const std::vector<double> &expected){
    auto output=execute();std::vector<std::uint16_t> actual(std::size_t(data.capacity.max_query_rows)*8*data.capacity.value_head_dim);check(output.view()->read(std::as_writable_bytes(std::span(actual))));
    double worst=0;for(std::size_t i=0;i<expected.size();++i){if(!std::isfinite(decode(actual[i])))fail(hyle::Status::Internal("nonfinite output"));worst=std::max(worst,std::abs(double(decode(actual[i]))-expected[i]));}
    if(worst>8e-3)fail(hyle::Status::Internal("same FP8 double oracle exceeded 8e-3"));
    common.verify_readonly(data);std::printf("ORACLE_ARM upstream=%d max_abs_error=%.12g elements=%zu\n",upstream,worst,expected.size());return actual;
  }
};
void measure(unsigned alloc,unsigned order,int q1,int q2,int k1,int k2,int dk,int dv,bool causal,int window,bool tail=false){
  const char *shape=tail?"tail":(window>=0?"window":(dk==256?"prefill":"holdout"));
  Data data(q1,q2,k1,k2,dk,dv,causal,window);const auto common_start=Clock::now();
  auto resident=std::make_unique<CommonResident>(data);
  std::printf("COMMON_COLD alloc=%u order=%u capture=0 shape=%s create_upload_us=%.9f FP8_bytes=%zu\n",alloc,order,shape,us(Clock::now()-common_start),data.packed[0].size()+data.packed[1].size());
  std::unique_ptr<Harness> h[2];
  for(unsigned i=0;i<2;++i){const unsigned side=alloc?1-i:i;const auto start=Clock::now();h[side]=std::make_unique<Harness>(*resident,data,side==0);std::printf("COLD alloc=%u order=%u capture=0 shape=%s side=%u create_plan_us=%.9f\n",alloc,order,shape,side,us(Clock::now()-start));}
  const auto expected=data.oracle();std::vector<std::uint16_t> values[2];
  for(unsigned pass=0;pass<4;++pass)for(unsigned side=0;side<2;++side)values[side]=h[side]->verify(data,expected);
  double diff=0;for(std::size_t i=0;i<expected.size();++i)diff=std::max(diff,std::abs(double(decode(values[0][i]))-decode(values[1][i])));
  if(diff>8e-3)fail(hyle::Status::Internal("same FP8 cross-arm output difference exceeded 8e-3"));
  std::printf("ORACLE alloc=%u order=%u capture=0 shape=%s pair_difference=%.12g\n",alloc,order,shape,diff);
  if(!tail&&!set("SAME_FP8_VERIFY_ONLY")){
    for(unsigned i=0;i<64;++i)for(unsigned j=0;j<2;++j){auto output=h[order?1-j:j]->execute();output.reset();}
    std::array<std::array<double,2>,4096> raw{};
    for(unsigned group=0;group<32;++group)for(unsigned step=0;step<128;++step)for(unsigned j=0;j<2;++j){const unsigned side=order?1-j:j;
      const auto start=Clock::now();{auto output=h[side]->execute();output.reset();}raw[group*128+step][side]=us(Clock::now()-start);
    }
    for(unsigned group=0;group<32;++group){double sums[2]{};for(unsigned step=0;step<128;++step){const auto &x=raw[group*128+step];sums[0]+=x[0];sums[1]+=x[1];std::printf("PAIR alloc=%u order=%u capture=0 shape=%s group=%u step=%u control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,step,x[0],x[1]);}
      std::printf("BLOCK alloc=%u order=%u capture=0 shape=%s group=%u count=128 control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,sums[0]/128,sums[1]/128);
    }
    for(unsigned pass=0;pass<2;++pass)for(unsigned side=0;side<2;++side)h[side]->verify(data,expected);
  }
  for(unsigned i=0;i<2;++i){const unsigned side=alloc?1-i:i;const auto start=Clock::now();h[side].reset();std::printf("CLOSE alloc=%u order=%u capture=0 shape=%s side=%u close_us=%.9f\n",alloc,order,shape,side,us(Clock::now()-start));}
  resident->verify_readonly(data);const auto shared_close=Clock::now();resident.reset();std::printf("COMMON_CLOSE alloc=%u order=%u shape=%s close_us=%.9f\n",alloc,order,shape,us(Clock::now()-shared_close));
}
}
int main(){cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0)fail(hyle::Status::Internal("caller CPU2 affinity failed"));
  std::printf("SCHEDULE warmups=64 groups=32 group_size=128 primary=complete_episode_arithmetic_block_mean slots=2 allocation_orders=2 execution_orders=2 capture_modes=1 normal_only=1 shared_resident_FP8=1 control=sync_fixed69ff_residentFP8 treatment=C6residentFP8 allow_bf16_partials=1 verify_only=%d\n",set("SAME_FP8_VERIFY_ONLY"));
  const auto *shape_env=std::getenv("SAME_FP8_SHAPE");const std::string shape=shape_env?shape_env:"all";
  if(shape!="all"&&shape!="prefill"&&shape!="window"&&shape!="holdout")fail(hyle::Status::InvalidArgument("unknown SAME_FP8_SHAPE"));
  const unsigned matrices=set("SAME_FP8_VERIFY_ONLY")?1u:2u;
  for(unsigned alloc=0;alloc<matrices;++alloc)for(unsigned order=0;order<matrices;++order){
    if(shape=="all"||shape=="prefill")measure(alloc,order,64,128,1024,768,256,256,true,-1);
    if(shape=="all"||shape=="window")measure(alloc,order,1,17,1024,768,256,256,true,16);
    if(shape=="all"||shape=="holdout")measure(alloc,order,17,1,7,47,64,128,false,-1);
  }
  if(shape=="all"||shape=="prefill")measure(0,0,64,128,1023,767,256,256,true,-1,true);
  std::printf("EXIT code=0\n");return 0;
}
