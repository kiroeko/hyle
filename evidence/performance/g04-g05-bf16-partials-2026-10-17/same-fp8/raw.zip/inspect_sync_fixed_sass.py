from pathlib import Path
import hashlib,json,re,subprocess
BASE=Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-same-fp8-comparison')
OUT=BASE/'sync-fixed';identity=json.loads((OUT/'reference-build-result.json').read_text())
obj=Path(identity['object']);assert hashlib.sha256(obj.read_bytes()).hexdigest()==identity['object_sha256']
symbols=re.findall(r' Function (\S+):\n',(OUT/'reference-resources.txt').read_text())
symbols=[s for s in symbols if 'KernelTraitsILNS_8MaskModeE1ELj64ELj1ELj4ELj16ELj16ELj4ELj1' in s and 'DefaultAttentionILb0ELb0ELb0ELb0' in s]
assert len(symbols)==1
args=['/usr/local/cuda-13.3/bin/cuobjdump','--gpu-architecture','sm_89','--dump-sass','--function',symbols[0],str(obj)]
p=subprocess.run(args,capture_output=True,text=True,check=True)
(OUT/'selected-sass.txt').write_text(p.stdout)
rows=[]
for line in p.stdout.splitlines():
    m=re.search(r'/\*([0-9a-fA-F]+)\*/\s+(.*?)\s*;\s*/\*\s*(0x[0-9a-fA-F]+)\s*\*/',line)
    if m:rows.append({'pc':int(m[1],16),'sass':m[2]+';','low64':m[3]})
sync=[i for i,x in enumerate(rows) if 'WARPSYNC' in x['sass']]
assert not sync
i=next(i for i,x in enumerate(rows) if x['pc']==0xd9a0)
assert rows[i]['sass']=='NOP;'
j=i-1
while not rows[j]['sass'].startswith('STS '):j-=1
k=i+1
while 'LDS.128' not in rows[k]['sass']:k+=1
assert i-j<10 and k-i<10
report={'scope':'Actual sync-fixed selected kernel output publication; offline only',
 'build_result_sha256':hashlib.sha256((OUT/'reference-build-result.json').read_bytes()).hexdigest(),
 'symbol':symbols[0],'argv':args,'selected_rows':len(rows),
 'new_instruction_at_syncwarp_source_position':rows[i],
 'explicit_WARPSYNC_mnemonic_count':len(sync),
 'last_prior_output_write':rows[j],'first_following_output_read':rows[k],
 'actual_lowering':'Source adds __syncwarp but SM89 ptxas emits one NOP atd9a0 here, not an explicit WARPSYNC mnemonic. Do not replace this actual observation with an assumed hardware barrier; exact lowering mechanism is not established.',
 'runtime_racecheck_not_asserted':'Runner owns new numerical/mem/sync/race validation. This source repair is not declared sufficient or ineffective from the mnemonic alone. No extra CTA barrier or compilation is introduced to satisfy a disassembly expectation.'}
(OUT/'output-sync-codegen.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
