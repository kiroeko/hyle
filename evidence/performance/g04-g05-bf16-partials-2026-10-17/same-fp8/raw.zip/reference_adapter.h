#pragma once
#include "hyle/compute/batch_execution.h"
#include "hyle/compute/paged_arena.h"
namespace hyle::bench::resident {
struct SameFp8ReferenceData final {
  compute::BatchLayoutVersion layout;
  compute::PagedArenaRead keys,values;
};
compute::Provider same_fp8_reference_provider(const SameFp8ReferenceData *) noexcept;
}
