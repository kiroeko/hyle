#include "reference_api.h"
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <cmath>
#include <cstring>
#include <stdexcept>

// Keep every upstream header byte unchanged. Isolate its host/device symbols
// from the linked Hyle-patched FlashInfer namespace to avoid ODR interposition.
#define flashinfer g04_syncfixed_same_fp8_flashinfer
#include <flashinfer/attention/default_prefill_params.cuh>
#include <flashinfer/attention/prefill.cuh>
#include <flashinfer/attention/scheduler.cuh>
#include <flashinfer/attention/variants.cuh>
#undef flashinfer

namespace hyle::bench::resident::cuda_original {
namespace fi=::g04_syncfixed_same_fp8_flashinfer;
namespace {
bool supported(Spec s) {
  if (!s.query_heads || !s.kv_heads || s.query_heads%s.kv_heads || !s.page_size ||
      !std::isfinite(s.scale) || !std::isfinite(s.key_scale) ||
      !std::isfinite(s.value_scale) || s.window < -1) return false;
  return (s.key_depth==256 && s.value_depth==256 && s.causal) ||
         (s.key_depth==64 && s.value_depth==128 && !s.causal && s.window==-1);
}

// The original AttentionVariantBase::OutputTransform detects this field and
// computes output * reciprocal(d) * v_scale, before conversion to DTypeO.
// With split KV, that means before BF16 partial rounding. The product instead
// applies V scale after merging its BF16 partials. This adapter preserves the
// real .5/2 mathematical operation, not an arbitrary-data bitwise equivalence;
// each arm must pass the same independent FP8-byte-derived double oracle.
struct Params:fi::BatchPrefillPagedParams<__nv_bfloat16,__nv_fp8_e4m3,
                                        __nv_bfloat16,std::int32_t> {
  float v_scale=1.F;
};

void bind_plan(Params &p,const fi::PrefillPlanInfo &info,void *integer) {
  const auto at=[&](std::int64_t offset) {
    return reinterpret_cast<std::int32_t*>(static_cast<char*>(integer)+offset);
  };
  p.request_indices=at(info.request_indices_offset);
  p.qo_tile_indices=at(info.qo_tile_indices_offset);
  p.kv_tile_indices=at(info.kv_tile_indices_offset);
  p.o_indptr=at(info.o_indptr_offset);
  p.kv_chunk_size_ptr=at(info.kv_chunk_size_ptr_offset);
  p.padded_batch_size=std::uint32_t(info.padded_batch_size);
  p.max_total_num_rows=std::uint32_t(info.total_num_rows);
  if(info.split_kv)p.merge_indptr=at(info.merge_indptr_offset);
}

template<unsigned QK,unsigned VO,fi::MaskMode Mask,bool Window>
cudaError_t launch(Params p,const fi::PrefillPlanInfo &info,void *floating,cudaStream_t stream) {
  using Variant=fi::DefaultAttention<false,Window,false,false>;
  auto *temporary=info.split_kv?reinterpret_cast<__nv_bfloat16*>(
      static_cast<char*>(floating)+info.v_offset):nullptr;
  auto *scores=info.split_kv?reinterpret_cast<float*>(
      static_cast<char*>(floating)+info.s_offset):nullptr;
  // Only the finite shape family is selected here. Original upstream code
  // still selects NUM_MMA_KV, dynamic shared memory and the merge internally.
  switch(info.cta_tile_q) {
#define G04_TILE(tile) case tile:return fi::BatchPrefillWithPagedKVCacheDispatched<tile,QK,VO,fi::PosEncodingMode::kNone,false,Mask,Variant>(p,temporary,scores,false,stream)
    G04_TILE(16);G04_TILE(64);G04_TILE(128);
#undef G04_TILE
  }
  return cudaErrorNotSupported;
}
}

void *create_plan() { return new fi::PrefillPlanInfo; }
void destroy_plan(void *p) noexcept { delete static_cast<fi::PrefillPlanInfo*>(p); }

cudaError_t workspace(Spec s,const std::int32_t *q,const std::int32_t *k,
                      cudaStream_t stream,Facts &facts) {
  facts={};
  if(!supported(s))return cudaErrorNotSupported;
  if(!s.query_rows)return cudaSuccess;
  return fi::PrefillPlanWorkspaceSize(facts.floating,facts.integer,
      const_cast<std::int32_t*>(q),const_cast<std::int32_t*>(k),s.query_rows,s.requests,
      s.query_heads,s.kv_heads,s.key_depth,s.value_depth,s.page_size,false,2,
      s.window,-1,false,0,0,stream,1);
}

cudaError_t plan(void *state,Spec s,const std::int32_t *q,const std::int32_t *k,
                 void *floating,std::size_t floating_bytes,void *integer,void *host,
                 std::size_t integer_bytes,cudaStream_t stream,Facts &facts) {
  if(!state || !supported(s))return cudaErrorNotSupported;
  auto &info=*static_cast<fi::PrefillPlanInfo*>(state);
  if(!s.query_rows){info={};facts={};return cudaSuccess;}
  const auto status=fi::PrefillPlan(floating,floating_bytes,integer,host,integer_bytes,info,
      const_cast<std::int32_t*>(q),const_cast<std::int32_t*>(k),s.query_rows,s.requests,
      s.query_heads,s.kv_heads,s.key_depth,s.value_depth,s.page_size,false,2,
      s.window,-1,false,0,0,stream,1);
  if(status!=cudaSuccess)return status;
  if(info.kv_chunk_size_ptr_offset<0)return cudaErrorInvalidValue;
  const auto offset=std::size_t(info.kv_chunk_size_ptr_offset);
  if(offset>integer_bytes || integer_bytes-offset<sizeof(facts.kv_chunk_rows))
    return cudaErrorInvalidValue;
  std::memcpy(&facts.kv_chunk_rows,static_cast<const char*>(host)+offset,
              sizeof(facts.kv_chunk_rows));
  facts.tile=unsigned(info.cta_tile_q);facts.padded=unsigned(info.padded_batch_size);
  facts.split=info.split_kv;facts.partial_bytes=2;
  return cudaSuccess;
}

cudaError_t run(const void *state,Spec s,const void *q,const void *k,const void *v,
                const void *metadata,void *output,void *floating,void *integer,
                cudaStream_t stream) {
  if(!state || !supported(s))return cudaErrorNotSupported;
  if(!s.query_rows)return cudaSuccess;
  const auto &info=*static_cast<const fi::PrefillPlanInfo*>(state);
  const auto at=[&](std::size_t offset) {
    return reinterpret_cast<std::int32_t*>(const_cast<char*>(
        static_cast<const char*>(metadata))+offset);
  };
  Params p;
  p.q=const_cast<__nv_bfloat16*>(static_cast<const __nv_bfloat16*>(q));
  p.o=static_cast<__nv_bfloat16*>(output);p.q_indptr=at(s.query_offset);
  const std::int64_t ks[]{std::int64_t(s.page_size)*s.kv_heads*s.key_depth,
      std::int64_t(s.kv_heads)*s.key_depth,s.key_depth,1};
  const std::int64_t vs[]{std::int64_t(s.page_size)*s.kv_heads*s.value_depth,
      std::int64_t(s.kv_heads)*s.value_depth,s.value_depth,1};
  p.paged_kv=fi::paged_kv_t<__nv_fp8_e4m3,std::int32_t>(s.kv_heads,s.page_size,
      s.key_depth,s.requests,fi::QKVLayout::kNHD,
      const_cast<__nv_fp8_e4m3*>(static_cast<const __nv_fp8_e4m3*>(k)),
      const_cast<__nv_fp8_e4m3*>(static_cast<const __nv_fp8_e4m3*>(v)),ks,vs,
      at(s.indices_offset),at(s.kv_offset),at(s.tails_offset));
  p.num_qo_heads=s.query_heads;p.group_size=fi::uint_fastdiv(s.query_heads/s.kv_heads);
  p.q_stride_n=s.query_heads*s.key_depth;p.q_stride_h=s.key_depth;
  p.window_left=s.window;p.sm_scale=s.scale*s.key_scale;p.v_scale=s.value_scale;
  bind_plan(p,info,integer);
  if(s.causal) {
    if(s.window>=0)return launch<256,256,fi::MaskMode::kCausal,true>(p,info,floating,stream);
    return launch<256,256,fi::MaskMode::kCausal,false>(p,info,floating,stream);
  }
  return launch<64,128,fi::MaskMode::kNone,false>(p,info,floating,stream);
}
}
