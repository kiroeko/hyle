from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json,shutil,subprocess,time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
BASE=ROOT/'.scratch/g04-same-fp8-comparison'
OUT=BASE/'sync-fixed'
WORK=Path('/root/hyle-scratch/compute-unified/g04-same-fp8-reference-sync-fixed')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
utc=lambda:datetime.now(timezone.utc).isoformat()

def main():
    OUT.mkdir(exist_ok=True);WORK.mkdir(parents=True,exist_ok=True)
    old=json.loads((BASE/'reference-build-result.json').read_text())
    files=json.loads((BASE/'pristine-files.json').read_text())
    original=Path(old['pristine_directory'])
    before={p.relative_to(original).as_posix():sha(p) for p in original.rglob('*') if p.is_file()}
    assert before==files and len(before)==2576
    shadow=WORK/'sync-fixed-upstream'
    assert not shadow.exists(),'Do not overwrite a previous sync-fixed source identity'
    shutil.copytree(original,shadow)
    header=shadow/'include/flashinfer/attention/prefill.cuh'
    b=header.read_bytes()
    anchor=b'''      uint32_t o_smem_offset_w = o_smem->template get_permuted_offset<UPCAST_STRIDE_O>(
          warp_idx_x * KTraits::NUM_MMA_Q * 16 + lane_idx / 8, lane_idx % 8);'''
    assert b.count(anchor)==1
    replacement=b'''      // Publish this warp's cross-lane BF16 output rearrangement before its reads.
      __syncwarp();

'''+anchor
    after=b.replace(anchor,replacement,1)
    assert after.replace(replacement,anchor,1)==b
    header.write_bytes(after)
    (OUT/'prefill.cuh').write_bytes(after)
    patch=''.join(difflib.unified_diff(b.decode().splitlines(True),after.decode().splitlines(True),fromfile='pristine/include/flashinfer/attention/prefill.cuh',tofile='sync-fixed/include/flashinfer/attention/prefill.cuh',n=8))
    (OUT/'sync.patch').write_text(patch)
    expected=dict(files);expected['include/flashinfer/attention/prefill.cuh']=sha(header)
    actual={p.relative_to(shadow).as_posix():sha(p) for p in shadow.rglob('*') if p.is_file()}
    assert actual==expected
    (OUT/'upstream-files.json').write_text(json.dumps(actual,indent=2)+'\n')
    source=(BASE/'upstream_reference.cu').read_bytes()
    old_ns=b'g04_pristine_same_fp8_flashinfer';new_ns=b'g04_syncfixed_same_fp8_flashinfer'
    assert source.count(old_ns)==2
    fixed=source.replace(old_ns,new_ns)
    assert fixed.replace(new_ns,old_ns)==source
    (OUT/'upstream_reference.cu').write_bytes(fixed)
    (OUT/'reference_api.h').write_bytes((BASE/'reference_api.h').read_bytes())
    for name in ['upstream_reference.cu','reference_api.h']:shutil.copyfile(OUT/name,WORK/name)
    args=[x.replace(str(Path(old['cwd'])),str(WORK)) for x in old['argv']]
    args=[x.replace(str(WORK/'pristine-upstream'),str(shadow)) for x in args]
    assert '-I'+str(shadow/'include') in args
    start=utc()
    identity={'kind':'SYNC_FIXED_UPSTREAM_SAME_FP8_REFERENCE_COMPILE',
      'started_utc':start,'pristine_build_result_sha256':sha(BASE/'reference-build-result.json'),
      'pristine_object':old['object'],'pristine_object_sha256':old['object_sha256'],
      'pristine_library':old['library'],'pristine_library_sha256':old['library_sha256'],
      'pristine_failure_log':str(BASE/'run-racecheck-prefill-1/stdout.log'),
      'pristine_failure_log_sha256':sha(BASE/'run-racecheck-prefill-1/stdout.log'),
      'upstream_revision':old['upstream_revision'],'archive_sha256':old['archive_sha256'],
      'original_2576_files_unchanged':True,'upstream_directory':str(shadow),
      'only_upstream_file_changed':'include/flashinfer/attention/prefill.cuh',
      'header_before_sha256':hashlib.sha256(b).hexdigest(),'header_after_sha256':sha(header),
      'patch_sha256':sha(OUT/'sync.patch'),'patch_inverts_byte_exact':True,
      'upstream_files_json_sha256':sha(OUT/'upstream-files.json'),
      'inventory_sha256':hashlib.sha256(''.join(n+'|'+actual[n]+'\n' for n in sorted(actual)).encode()).hexdigest(),
      'source_sha256':sha(WORK/'upstream_reference.cu'),'api_sha256':sha(WORK/'reference_api.h'),
      'source_change':'Namespace token only versus pristine bridge; exactly one __syncwarp in BF16 output shared-memory rearrangement versus pristine upstream. No loader, planner, merge, arithmetic, tile, or scale changes.',
      'race_diagnosis':'Actual CTA64/KMMA4/4x1 FP8 reference warnings bind scalar output STS ce70..d990 to LDS.128 d9a0..daf0 without intervening warp publication. Each Q warp owns independent16-row region and cross-lane readers require its warp writes complete.',
      'retains_pristine_failure':True,'not_pristine':True,'gpu_executed':False,'product_recompiled':False,
      'argv':args,'cwd':str(WORK)}
    (OUT/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    print(json.dumps({'event':'SYNC_FIXED_NVCC_START','utc':start,'source_sha256':identity['source_sha256'],'header_sha256':identity['header_after_sha256']}),flush=True)
    t=time.monotonic()
    with (OUT/'reference-compile.log').open('wb') as log:p=subprocess.run(args,cwd=WORK,stdout=log,stderr=subprocess.STDOUT)
    identity.update({'compile_returncode':p.returncode,'compile_elapsed_s':time.monotonic()-t,'ended_utc':utc(),'log_sha256':sha(OUT/'reference-compile.log')})
    check={p.relative_to(shadow).as_posix():sha(p) for p in shadow.rglob('*') if p.is_file()}
    assert check==expected
    assert {p.relative_to(original).as_posix():sha(p) for p in original.rglob('*') if p.is_file()}==files
    assert sha(Path(old['library']))==old['library_sha256']
    identity['pristine_source_and_library_still_unchanged']=True
    if p.returncode==0:
        obj=WORK/'upstream_reference.cu.o';library=WORK/'libg04_syncfixed_same_fp8_reference.a'
        subprocess.run(['/usr/bin/ar','rcs',str(library),str(obj)],check=True)
        identity.update({'object':str(obj),'object_sha256':sha(obj),'library':str(library),'library_sha256':sha(library)})
        identity['members']=subprocess.run(['/usr/bin/ar','t',str(library)],capture_output=True,text=True,check=True).stdout.splitlines()
        for label,argv in [('nm',['nm','-g','--defined-only',str(obj)]),('resources',['/usr/local/cuda-13.3/bin/cuobjdump','--gpu-architecture','sm_89','--dump-resource-usage',str(obj)])]:
            result=subprocess.run(argv,capture_output=True,text=True)
            (OUT/f'reference-{label}.txt').write_text(result.stdout)
            (OUT/f'reference-{label}-stderr.txt').write_text(result.stderr)
            identity[label]={'argv':argv,'returncode':result.returncode}
    (OUT/'reference-build-result.json').write_text(json.dumps(identity,indent=2)+'\n')
    print(json.dumps({'event':'SYNC_FIXED_NVCC_END','returncode':p.returncode,'elapsed_s':identity['compile_elapsed_s'],'library':identity.get('library'),'library_sha256':identity.get('library_sha256')}),flush=True)
    raise SystemExit(p.returncode)

if __name__=='__main__':main()
