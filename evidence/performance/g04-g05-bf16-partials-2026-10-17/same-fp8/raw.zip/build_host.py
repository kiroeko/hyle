from pathlib import Path
import hashlib,json,subprocess,time,sys
REPO=Path('/mnt/c/public/project-hyle/hyle');OUT=REPO/'.scratch/g04-same-fp8-comparison';WORK=Path('/root/hyle-scratch/compute-unified/g04-same-fp8-comparison')
WORK.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((REPO/'.scratch/g04-bf16-product/consumer-commands.json').read_text())
commands={'compile':[],'link':None}
record={'sources':{},'compile':[],'GPU_executed':False,'CUDA_recompiled':False}
for name in ['consumer.cc','reference_adapter.cc']:
 cmd=list(old['compile']);cmd[cmd.index('-o')+1]=str(WORK/(name+'.o'));cmd[cmd.index('-c')+1]=str(OUT/name)
 cmd[1:1]=['-I'+str(REPO/'include'),'-I'+str(REPO/'src/compute'),'-I'+str(OUT)]
 commands['compile'].append(cmd);record['sources'][name]=sha(OUT/name)
 start=time.monotonic()
 with (OUT/(name+'.compile.log')).open('w') as log: p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 record['compile'].append({'source':name,'argv':cmd,'returncode':p.returncode,'elapsed_s':time.monotonic()-start})
 (OUT/'host-build-result.json').write_text(json.dumps(record,indent=2)+'\n')
 if p.returncode: raise SystemExit(p.returncode)
(OUT/'host-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps(record,indent=2))
