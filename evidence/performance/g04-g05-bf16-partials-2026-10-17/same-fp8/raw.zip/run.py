from pathlib import Path
import json,hashlib,subprocess,time,os,sys,shutil
REPO=Path('/mnt/c/public/project-hyle/hyle');OUT=REPO/'.scratch/g04-same-fp8-comparison';WORK=Path('/root/hyle-scratch/compute-unified/g04-same-fp8-comparison')
mode=sys.argv[1];assert mode in ['verify','memcheck','synccheck','racecheck','ordinary']
shape=sys.argv[2] if len(sys.argv)>2 else 'all';assert shape in ['all','prefill','window','holdout']
tag=sys.argv[3] if len(sys.argv)>3 else '1';assert tag.replace('-','').isalnum()
run=OUT/('run-'+mode+'-'+shape+'-'+tag);run.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
link=json.loads((OUT/'link-result.json').read_text());binary=Path(link['binary']);assert sha(binary)==link['binary_sha256']
for n,h in link['sources'].items():assert sha(OUT/n)==h,(n,'source changed')
for n,h in link['archives'].items():assert sha(n)==h,(n,'archive changed')
for name in link['sources']:shutil.copyfile(OUT/name,run/name)
for i,(name,h) in enumerate(link.get('external_inputs',{}).items()):
 assert sha(name)==h,(name,'effective reference changed')
 shutil.copyfile(name,run/('reference-input-'+str(i)+'-'+Path(name).name))
shutil.copyfile(binary,run/'same_fp8')
env=os.environ.copy();env.pop('G04_TRACE',None);env['SAME_FP8_SHAPE']=shape
if mode!='ordinary':env['SAME_FP8_VERIFY_ONLY']='1'
else:env.pop('SAME_FP8_VERIFY_ONLY',None)
argv=[str(binary)]
if mode in ['memcheck','synccheck','racecheck']:
 argv=['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool',mode,'--error-exitcode','87',*argv]
record={'argv':argv,'mode':mode,'shape':shape,'binary_sha256':sha(binary),'sources':link['sources'],'archives':link['archives'],'shared_resident_FP8':True,'cold_BF16_shadow':False,'reference_build':link['reference_build'],'external_inputs':link.get('external_inputs',{}),'env':{'SAME_FP8_VERIFY_ONLY':env.get('SAME_FP8_VERIFY_ONLY'),'G04_TRACE':env.get('G04_TRACE')},'GPU_pre':subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version,compute_cap','--format=csv,noheader'],text=True)}
(run/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (run/'stdout.log').open('w') as so,(run/'stderr.log').open('w') as se:p=subprocess.run(argv,env=env,stdout=so,stderr=se)
record.update(returncode=p.returncode,elapsed_s=time.monotonic()-start,stdout_sha256=sha(run/'stdout.log'),stderr_sha256=sha(run/'stderr.log'))
(run/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'mode':mode,'shape':shape,'returncode':p.returncode,'elapsed_s':record['elapsed_s'],'run':str(run)}))
raise SystemExit(p.returncode)
