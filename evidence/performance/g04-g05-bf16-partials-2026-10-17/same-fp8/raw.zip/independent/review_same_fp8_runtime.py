"""Reconcile final same-FP8 source, validated binary and all-tail ordinary runs."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
D = ROOT / '.scratch/g04-same-fp8-comparison'
HERE = Path(__file__).resolve().parent
OUT = HERE / 'same-fp8-runtime-review.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
fields = lambda line: dict(w.split('=', 1) for w in line.split()[1:] if '=' in w)
sources = {
    'consumer.cc': '920036428377159cf53fb447134c5952aa1b48258792afb468ee262d46a3593f',
    'reference_adapter.cc': '17f349b854eab1c642bb8113c2802df5841c98ad53ae1328d023d7b5e8c5301d',
    'reference_adapter.h': '1d0776b8e7fdcba84acb63723d6bc0050058148c21c8ddda49d60a7c5ac00b93',
    'reference_api.h': '0da9da29c1a12922133fcdc7c8ce2f9d2786e03ac8dbad003c89f52357830bea',
}
assert all(sha(D / n) == h for n, h in sources.items())
binary = 'f65b9b27ce5842c4c303b2888a9df3a634ca6358950a10e799385c18a8ef60a9'
ref = read(D / 'sync-fixed/reference-build-result.json')
assert ref['not_pristine'] and ref['compile_returncode'] == 0
assert ref['library_sha256'] == '903576718caa737f73eede52f634ac7c154b85bdf44e914a6ec8e12b7e6809d3'
before = D / 'run-verify-prefill-1'
assert (before / 'consumer.cc').read_bytes().replace(b'control=pristine69ff_residentFP8', b'control=sync_fixed69ff_residentFP8') == (D / 'consumer.cc').read_bytes()
old_adapter = (before / 'reference_adapter.cc').read_bytes()
assert old_adapter.replace(b'"original-cuda-resident-fp8-cache"', b'"syncfixed-original-cuda-resident-fp8-cache"').replace(b'69ff11fc-pristine-fp8-vscale-hook', b'69ff11fc-syncfixed-fp8-vscale-hook') == (D / 'reference_adapter.cc').read_bytes()

def bind_run(folder, shape, mode):
    identity, result = [read(folder / name) for name in ['identity.json', 'result.json']]
    assert identity['sources'] == sources
    assert identity['binary_sha256'] == result['binary_sha256'] == binary
    assert sha(folder / 'same_fp8') == binary
    assert identity['mode'] == mode and identity['shape'] == shape
    assert identity['shared_resident_FP8'] and not identity['cold_BF16_shadow']
    assert identity['reference_build']['library_sha256'] == ref['library_sha256']
    assert identity['reference_build']['header_after_sha256'] == ref['header_after_sha256']
    assert ref['library_sha256'] in identity['archives'].values()
    assert 'bbf3ec34a9aa0d7916ffc3ebb4a340583946ec3ce2bc33a6c0dc2711256ecec2' in identity['archives'].values()
    assert result['returncode'] == 0
    assert result['stdout_sha256'] == sha(folder / 'stdout.log')
    assert result['stderr_sha256'] == sha(folder / 'stderr.log')
    out, err = [(folder / n).read_text(encoding='utf-8') for n in ['stdout.log', 'stderr.log']]
    oracles = [fields(line) for line in out.splitlines() if line.startswith('ORACLE_ARM ')]
    assert oracles and all(float(r['max_abs_error']) <= 8e-3 for r in oracles)
    if mode == 'racecheck':
        assert '0 hazards displayed (0 errors, 0 warnings)' in out + err
    if mode in ['memcheck', 'synccheck']:
        assert 'ERROR SUMMARY: 0 errors' in out + err
    return {'folder': str(folder.relative_to(ROOT)), 'returncode': 0, 'elapsed_s': result['elapsed_s'],
            'binary_sha256': binary, 'oracle_records': len(oracles),
            'maximum_logged_double_error_by_arm': {str(side): max(float(r['max_abs_error']) for r in oracles if int(r['upstream']) == side) for side in [0, 1]},
            'files': {n: sha(folder / n) for n in ['identity.json', 'result.json', 'stdout.log', 'stderr.log']}}

checks, ordinary = {}, {}
for shape, tag in [('prefill', 'syncfixed-2'), ('window', 'syncfixed-1')]:
    checks[shape] = {mode: bind_run(D / f'run-{mode}-{shape}-{tag}', shape, mode)
                     for mode in ['verify', 'memcheck', 'synccheck', 'racecheck']}
    run = D / f'run-ordinary-{shape}-syncfixed-1'
    identity = bind_run(run, shape, 'ordinary')
    analysis_path = HERE / f'same-fp8-{shape}-analysis.json'
    analysis = read(analysis_path)
    assert analysis['source_log_sha256'] == sha(run / 'stdout.log')
    assert analysis['episode_pairs'] == 16384 and analysis['blocks'] == 128
    assert all(s['latency_change_percent'] < 0 for s in analysis['strata'])
    pooled = analysis['shape_pooled_block_intervals'][shape]
    assert pooled['latency_change_percent_interval'][1] < 0
    ordinary[shape] = {**identity, 'analysis': str(analysis_path.relative_to(ROOT)),
                       'analysis_sha256': sha(analysis_path),
                       'matrices_csv_sha256': sha(HERE / f'same-fp8-{shape}-all-matrices.csv'),
                       'all_tail_pooled': pooled,
                       'matrix_latency_change_percent': [s['latency_change_percent'] for s in analysis['strata']],
                       'actual_plans': analysis['cold_actual_plans'],
                       'all_tails_and_blocks_retained': True}

pristine = D / 'run-racecheck-prefill-1'
assert read(pristine / 'result.json')['returncode'] == 87
assert '64 warnings' in (pristine / 'stdout.log').read_text()
holdout = D / 'run-verify-holdout-syncfixed-1'
assert read(holdout / 'result.json')['returncode'] == 2
assert 'same FP8 double oracle exceeded 8e-3' in (holdout / 'stderr.log').read_text()
record = {
    'kind': 'INDEPENDENT_VALIDATED_SAME_RESIDENT_FP8_COMPLETE_EPISODE_RECONCILIATION',
    'no_new_GPU_run_compilation_or_canonical_edits_by_reviewer': True,
    'final_sources': sources, 'final_binary_sha256': binary,
    'reference': {'revision': ref['upstream_revision'], 'not_pristine': True,
                  'label': 'synchronization-corrected upstream69ff direct resident FP8',
                  'library_sha256': ref['library_sha256'], 'object_sha256': ref['object_sha256'],
                  'header_sha256': ref['header_after_sha256'],
                  'only_upstream_edit': 'One source __syncwarp after BF16 output cross-lane shared writes, before rereads; independent inverse-edit restores whole original header exactly.',
                  'actual_lowering': 'Selected SASS inserts NOP rather than a WARPSYNC mnemonic. Source correction is proven and actual corrected racecheck has zero hazards; no compilerloweringreason or additionalhardwarebarriersemantic is invented.'},
    'source_review_evidence': {n: sha(HERE / n) for n in ['same-fp8-source-review.json', 'same-fp8-syncfix-source-review.json']},
    'final_host_delta_from_reviewed_singleContext': 'Only printed control label and Provider name/version changed; independent byte replacements exactly restore the retained prefill-pristine consumer/adapter snapshot.',
    'eight_actual_validation_runs': checks,
    'ordinary': ordinary,
    'failed_or_rejected_history_retained': {
        'initial_public_admission': 'run-verify-1 exit2 before attention dispatch: exactresourceguard rejected twoContext inputs. Replaced by oneContext/twoprovider/sameMemoryResource without weakening productguard.',
        'pristine_racecheck': {'returncode': 87, 'warnings': 64, 'stdout_sha256': sha(pristine / 'stdout.log'), 'performance_taken': False},
        'syncfixed_setup_rejections': 'syncfixed-1 setupguard rejections are separate from actualsyncfixed-2prefillGPUvalidation and do not supply numerical or speed evidence.',
        'holdout': {'returncode': 2, 'error': 'Reference first independentdoubleoracle exceeds8e-3 for D64/Dv128 fullnoncausal.',
                    'stderr_sha256': sha(holdout / 'stderr.log'), 'performance_taken': False, 'not_a_product_C6_failure_or_speed_ranking': True},
    },
    'fairness_and_numeric_scope': [
        'Botharms consume one shared actualdeviceFP8K/V allocation, sharedBF16Q, samepage16metadata and .5/2scales. There is no pre-expandedBF16sidecache. The commonowner lives beyond allarmcompletion/outputrelease/queue/slotshutdown.',
        'Onlynormal publiccompleteepisodes are compared; no candidate replay versus referencenormal, no cropped nativebridgewalltime, no hiddenwarmdecode omission on onlyoneFP8arm.',
        'Reference originaldispatch chooses its legalgeometry. Partial dtype/scaleplacement is disclosed; beforepartial versus mergeafter scaling and differingtiling are accepted by the same finite independentdoublebound, not declared arbitrary-data bitwiseequal.',
        'Prefillbothactualtile64/padded40/splitKV/BF16partial/F32localaccum. Windowbothactualtile64/padded3/noKVsplit, so there are no partialbuffers in eitherarm.',
        'Thisfairtimingharness sets equal64MiBfloatcaps per slot: actualtwo-slotallocationdelta is equal137915392Bperarm forprefill. Requiredworkspace is21053440Breference versus10567680BC6. Tightcap memorysaving is established by the separateproducttest, not re-proven as smalleractualreservation by this equalcapmeasurement.',
    ],
    'conclusion': 'Under the same residentFP8 input and validatednormalcompleteepisode contract, thisfixedrun favors C6: prefill-8.219859% and window-6.302877%, with all8matrixmean directions favorable and descriptiveblockintervals belowzero. The oldwarmBF16storagecomparison is not evidence of a same-FP8deficit. The unvalidatedholdout is excluded rather than relabeled as a performancepass.',
    'limits': [
        'One fixed16384pairrunpercase,32groups*128pairs across2allocation*2executionorders. Alltails/blocks retained; no extrapolated cumulativegain from separateearlier experiments.',
        'Blockintervals assume approximateindependence of adjacentblocks, not crossprocess/GPU/modelconfidence. Some individualp99/max observations still favorreference despite meanimprovement.',
        'These are finiteimmutablehistory G04/G05consumerfragments, not fullmodelquality/token_s, append/dirtyrefresh, everyattentiondomain or everydeployment.',
        'Reference is synchronization-corrected source, not pristine or an externalwholeengine. Originalfailurelogs, effectiveheader and separateobject identities stay intact.',
    ],
}
OUT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': str(OUT), 'sha256': sha(OUT), 'bytes': OUT.stat().st_size,
                  'validated_cases': list(checks), 'ordinary_pairs': 32768}, indent=2))
