"""Offline source, identity and timer review of the actual same-FP8 harness."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
D = ROOT / '.scratch/g04-same-fp8-comparison'
OUT = Path(__file__).with_name('same-fp8-source-review.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
expected = {
    'consumer.cc': '18ef13e4b2406e41972a069e563de82cb10c254f5eda68cca40f5960f86a1387',
    'reference_adapter.cc': '96e28047f7cc9a4ec5f67ff89c1024e723e4c79e27b024b2e6f4a75833e007c7',
    'reference_api.h': '0da9da29c1a12922133fcdc7c8ce2f9d2786e03ac8dbad003c89f52357830bea',
    'upstream_reference.cu': '8bac8d0f2323cbf62f5035d7bbaec09c6690a1d1d8b26a7790769e4938b8303e',
}
assert all(sha(D / n) == h for n, h in expected.items())
bridge, adapter, consumer = [(D / n).read_text(encoding='utf-8') for n in
                             ['upstream_reference.cu', 'reference_adapter.cc', 'consumer.cc']]
built, linked = [read(D / n) for n in ['reference-build-result.json', 'link-result.json']]
assert built['compile_returncode'] == linked['returncode'] == 0
assert built['source_sha256'] == expected['upstream_reference.cu']
assert built['api_sha256'] == expected['reference_api.h']
assert built['pristine_after_compile_exact_archive'] and built['pristine_file_count'] == 2576
assert built['library_members'] == ['upstream_reference.cu.o']
assert linked['C6_archive_sha256'] == 'bbf3ec34a9aa0d7916ffc3ebb4a340583946ec3ce2bc33a6c0dc2711256ecec2'
names = [line.split()[-1] for line in (D / 'reference-nm.txt').read_text().splitlines() if line.strip()]
assert not any(re.search(r'N[KVO]*10flashinfer', n) for n in names)
assert any('g04_pristine_same_fp8_flashinfer' in n for n in names)
update = adapter[adapter.index('Result<bool> update'):adapter.index('d::EnqueueResult plan')]
run = adapter[adapter.index('d::EnqueueResult run'):adapter.index('const d::BatchProviderVTable batch')]
assert 'page_indices' not in update and 'last_page_lengths' not in update
assert 'PagedArenaAccess::tensor' not in run and 'immutable FP8 frame identity changed' not in run
assert 'h[side]->execute();output.reset();' in consumer
assert 'plain_bf16_peer' not in consumer and 'prepare_replay' not in consumer
assert 'prepared.run(common.query,common.key_frame,common.value_frame)' in consumer
assert 'n::Facts facts;' in adapter and 'stream,facts' in adapter.replace('*stream', 'stream')
record = {
    'kind': 'INDEPENDENT_SAME_RESIDENT_FP8_SOURCE_ABI_TIMER_AND_OWNERSHIP_REVIEW',
    'verdict': 'NO_SOURCE_CORRECTNESS_DEFECT_FOUND_IN_THE_BOUND_ACTUAL_VERSION',
    'GPU_numerical_memory_synchronization_results_not_claimed': True,
    'no_compile_GPU_product_or_previous_archive_changes_by_this_review': True,
    'sources': expected,
    'binary_sha256': linked['binary_sha256'],
    'reference_library_sha256': built['library_sha256'],
    'reference_object_sha256': built['object_sha256'],
    'C6_archive_sha256': linked['C6_archive_sha256'],
    'source_and_namespace': {
        'upstream_revision': built['upstream_revision'],
        'original_tar_sha256': built['archive_sha256'],
        'all2576_files_exact_before_and_after_compile_recorded': True,
        'preprocessor_namespace_substitution_only_for_upstream': True,
        'reference_defined_external_symbols': len(names),
        'unisolated_upstream_root_flashinfer_symbols': 0,
        'same_private_API_header_across_NVCC_and_host': True,
        'new_device_namespace_distinct_from_product': 'g04_pristine_same_fp8_flashinfer',
    },
    'pointer_layout_and_lifetime': [
        'OneCommonResident owns oneCUDAContext containing twoexplicitproviderinstances plus the commondevice/pinnedresources, allocates/uploads the sole actualBF16Q and E4M3K/V arenas, creates the sharedschema/layout/frames and drains preparation before eitherarm timing.',
        'BothHarness::execute paths pass the identical common.query/common.key_frame/common.value_frame objects. No alternatecache, expansion, pointeroverride or stagingcopy is present in reference::run.',
        'K/V use independent correct NHD strides. Metadata offsets come from the sameschema, Qhead8/KVhead2/page16 and actualrequest/queryrows are propagated. Tail/pagealias layout is passed to the originalpaged_kv_t.',
        'The existingcoldBatchGraphAccess::prepare expectedProviderInstanceId seam selects referenceindex0 or productindex1 within this sameContext. Both use the exactcommonresource required by publicPreparedBatch::run; there is no admissionguardchange or perrunexternalGraphseam.',
        'Separatearm queues, mutablemetadata, workspaces, outputs and twoinvocations are created from the sameContext/resources. Everyepisode waits checkedcompletion before outputreturn/release.',
        'Allarm slots close, programsreset and queuesdrain before CommonResident clears referenceDataframe/layoutcopies and then itsownframe/page/query owners. Sharedresources and Context close last. referenceData is a stablefirstmember and outlives destructionofprovidercontexts.',
    ],
    'numeric_and_planner': [
        'Original nativeplannerquery andmaterialization both receive BF16output width2/FP8KVwidth1, sameheadgeometry/mask/window. The sameFactsobject flows workspace->plan; reportfloating/integer fields are not zeroed.',
        'Originaldispatcher chooses its legalCTA/KMMA/sharedgeometry, rather than forcing the productKMMA1exception. BF16partialpointer and F32scorepointer are typed from the originalplan offsets.',
        'Exactoriginalvariant_helper.cuh in tar has has_v_scale and OutputTransform/get_v_scale hooks: derivedParams.v_scale is natively applied after normalization and before BF16partial narrowing. Kscale multiplies sm_scale. No productloader/merge or persistentBF16shadow is borrowed.',
        'The original .5/2scales and inputbytes are preserved. Productmergescale and referenceprepartialscale plus differinglegaltiling are not declared bitwiseequivalent. Eacharm is checked against the sameindependentFP8-derived doubleoracle/finiteness bound8e-3, plus an additionalcrossarmbound.',
        'Mainprefill C6optin and referencesplit path both have BF16partials. Window/holdout may have C6F32partial versus referenceBF16partial; actualARM_PLAN reports must remain visible and no allshapeidenticalpartialpolicy claim is justified.',
    ],
    'timer_and_guard_fairness': {
        'primary': 'Normal public completeepisode for both: update_batch -> prepared.run(sharedresidentinputs) -> checkedCompletion.wait -> owningoutput acquire/release.',
        'cold_for_both': ['shareddeviceuploads', 'context/resource creation', 'nativeworkspaceplanning', 'independent oracle/readonlyreadbacks', 'teardown'],
        'no_replay_or_hidden_preexpanded_BF16_arm': True,
        'adapter_extra_guard_issue_resolved': 'Finalreferenceupdate checks schema and Q/KV indptr topology rather than twicecomparingallpageIDs/tails. Finalreferencerun no longeradds a secondPinnedArenatensor/storageidentityloop over publicBatch inputadmission. Coldplan still validates immutablelayout; sharedowner and before/afterreadonlyguards remain.',
        'sampling': 'Normalonly,eachselectedshape*2alloc*2order*32groups*128pairs=16384pairs per shape;2slotsalternate. SAME_FP8_SHAPE allows explicit independentprefill/window/holdout validation; all3 wouldtotal49152pairs. Tail1023/767 is oracleonly forprefill. Actualrunidentity must bind selectedshape beforeordinary, not infer it by posthoc trimming.',
        'scope': 'Same-resident-FP8 immutable-history implementationcomparison. It excludes append/dirtyrefresh/encodeproducer and modeltoken_s; those require a separate lifecycle workload. Sharedresource ARM_PLAN stats label cumulativevalues and eacharmallocationdelta separately.',
    },
    'runtime_followup': [
        'Run boundbinary numericaloracle/readonly/doubleslot/tail checks and actualpristineFP8 memory/synchronization/race validation; existingBF16peer tests cannot substitute.',
        'After successfulchecks record actual selectedreference andcandidate kernel/grid/partial/resources. Pristineheaders may expose real upstreamhazards; do not silently patch or sign a speedresult for an invalidreference.',
        'Only the one fixedordinaryrun can decide primarylatency. Staticresource counts, scalarconversionclaims and oldcrossrepresentationratios do not replace it.',
    ],
    'input_evidence': {str(p.relative_to(ROOT)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                       for p in [D / 'reference-build-result.json', D / 'reference-nm.txt', D / 'link-result.json', D / 'reference_adapter.h']},
}
OUT.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': str(OUT), 'sha256': sha(OUT), 'bytes': OUT.stat().st_size}, indent=2))
