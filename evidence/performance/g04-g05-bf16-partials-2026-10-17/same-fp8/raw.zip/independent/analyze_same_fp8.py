"""Fixed all-tail same-resident-FP8 normal complete-episode comparison."""
import argparse
import csv
import hashlib
import inspect
import json
from pathlib import Path

import analyze as paired
from summarize_new_product_results import paired_block_interval

def fields(line):
    return dict(w.split('=', 1) for w in line.split()[1:] if '=' in w)

def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log', type=Path)
    parser.add_argument('--shapes', nargs='+', choices=['prefill', 'window', 'holdout'], required=True)
    parser.add_argument('--output', type=Path, default=here / 'same-fp8-analysis.json')
    parser.add_argument('--matrices', type=Path, default=here / 'same-fp8-all-matrices.csv')
    args = parser.parse_args()
    assert len(set(args.shapes)) == len(args.shapes)
    raw = args.log.read_bytes()
    text = raw.decode('utf-8')
    assert text.rstrip().endswith('EXIT code=0')
    paired.SHAPES = tuple(args.shapes)
    records = paired.parse(text)
    assert set(r['shape'] for r in records if r['kind'] == 'PAIR') == set(args.shapes)
    assert all(int(r['capture']) == 0 for r in records)
    for r in records:
        if r['kind'] == 'COLD':
            assert 'create_us' not in r and 'create_plan_us' in r
            r['create_us'] = float(r['create_plan_us'])
    # The retained helper assumed an oracle-only tail for every old workload.
    # This actual consumer has tail only for prefill, as declared before runs.
    body = inspect.getsource(paired.analyze)
    old = '        expected |= {(0, 0, "tail", side) for side in (0, 1)}'
    assert body.count(old) == 1
    body = body.replace(old, '        if "prefill" in SHAPES:\n    ' + old)
    env = dict(vars(paired))
    exec(compile(body, '<retained-helper-prefill-tail-adapter>', 'exec'), env)
    result = env['analyze'](records, 32, 128)
    assert result['episode_pairs'] == len(args.shapes) * 16384
    assert result['blocks'] == len(args.shapes) * 128
    result['kind'] = 'SAME_RESIDENT_FP8_NORMAL_PUBLIC_COMPLETE_EPISODE_COMPARISON'
    result['comparison'] = 'C6 / synchronization-corrected upstream69ff, both actual shared resident FP8'
    result['normal_only'] = True
    result['source_log_sha256'] = hashlib.sha256(raw).hexdigest()
    result['analyzer_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['selected_shapes'] = args.shapes
    result['parser_adaptation'] = 'create_plan_us is preserved and additionally normalized as create_us for the retained coldsummary helper; only prefill expects the declared oracle-onlytail. All PAIR/BLOCK observations remain unchanged.'
    result['shape_pooled_block_intervals'] = {
        shape: paired_block_interval([s for s in result['strata'] if s['shape'] == shape])
        for shape in args.shapes
    }
    pending = None
    plans, shared, oracles = [], [], []
    for line in text.splitlines():
        if line.startswith('SHARED_INPUT '):
            f = fields(line)
            assert f['shared_by_both_arms'] == '1' and f['expanded_cache_bytes'] == '0'
            assert f['storage'] == 'resident_FP8'
            shared.append(f)
        elif line.startswith('ARM_PLAN '):
            assert pending is None
            pending = fields(line)
            assert pending['captured'] == '0' and pending['slots'] == '2'
            assert pending['max_float_cap'] == str(64 << 20)
        elif line.startswith('COLD '):
            assert pending is not None
            f = fields(line)
            assert pending['upstream'] == str(1 - int(f['side']))
            plans.append({'matrix': f, 'actual_plan': pending})
            pending = None
        elif line.startswith('ORACLE_ARM '):
            f = fields(line)
            assert float(f['max_abs_error']) <= 8e-3
            oracles.append(f)
    assert pending is None
    result['cold_actual_plans'] = plans
    result['shared_input_records'] = shared
    result['oracle_records'] = oracles
    for name in ['identity.json', 'result.json']:
        p = args.log.with_name(name)
        result[name.removesuffix('.json')] = json.loads(p.read_text())
        result[name + '_sha256'] = hashlib.sha256(p.read_bytes()).hexdigest()
    assert result['result']['returncode'] == 0
    result['limits'] = [
        'Alltails, allblocks and everydeclaredmatrix retained. No trimming, coldcostdeduction, negativecontrolnormalization or extraordinarysamples.',
        'Intervals describe pairedblock arithmeticmeans under an independenceapproximation, not crossprocess/machineconfidence.',
        'Both arms consume the identicalresidentFP8bytes, Q, metadata and same8e-3 doubleoraclecontract. Differentlegaltile/partialscaleplacement is recorded and is not an arbitrarydata bitwiseclaim.',
        'The reference includes the separatelyrecorded minimalwarp synchronizationfix and must not be called pristine. Its unmodifiedracefailure remains preserved.',
        'No modeltoken_s, dynamicappend/dirtyrefresh, fullmodelquality, allGPU or replayclaim is made by this normalimmutablehistory workload.',
    ]
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    table = []
    for s in result['strata']:
        table.append({'shape': s['shape'], 'allocation_order': s['allocation_order'],
                      'execution_order': s['execution_order'],
                      'upstream_mean_us': s['control']['arithmetic_mean_us'],
                      'C6_mean_us': s['treatment']['arithmetic_mean_us'],
                      'C6_change_percent': s['latency_change_percent'],
                      'upstream_p99_us': s['control']['p99_us'], 'C6_p99_us': s['treatment']['p99_us'],
                      'upstream_max_us': s['control']['max_us'], 'C6_max_us': s['treatment']['max_us'],
                      'C6_faster_blocks': s['block_treatment_faster'], 'blocks': len(s['blocks']),
                      'complete_pairs': s['control']['count']})
    with args.matrices.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(table[0]))
        w.writeheader()
        w.writerows(table)
    print(json.dumps({'shape_results': result['shape_pooled_block_intervals'],
                      'output': str(args.output), 'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
                      'CSV_sha256': hashlib.sha256(args.matrices.read_bytes()).hexdigest()}, indent=2))

if __name__ == '__main__':
    main()
