# Same-resident-FP8 comparison

Both arms consume the same immutable resident E4M3 K/V owners, BF16 Q, metadata, scales K=0.5/V=2, and BF16 output contract. There is no retained BF16 K/V shadow. The original reference uses the pinned 69ff planner and legal dispatcher rather than forcing Hyle geometry.

The shared Context has both providers. Existing `BatchGraphAccess::prepare(...ProviderInstanceId)` selects each provider only during cold setup; both timed arms use normal public `BatchInvocation::update_batch`, `PreparedBatch::run`, checked `Completion::wait`, and owning output acquisition/release. Every slot has independent plan/workspace/output, while both arms share identical input storage. Both original page-resource and lease guards remain enabled.

Primary: D256 causal unbounded prefill. The two auxiliary shapes remain separately labeled; their actual partial types may differ. Each ordinary shape has two allocation orders, two execution orders, 32 blocks x128 pairs, 64 warmups, and every sample retained. Cold upload/planning and teardown are separate. The original Vscale hook scales before BF16 partial narrowing; Hyle scales late. Both must satisfy the independent double oracle (8e-3); bitwise equality is not a general requirement.

Historical run directories are immutable:

- `run-verify-1`: first harness rejected by the public page-resource identity guard before attention dispatch; then corrected to one Context/resource, without weakening the guard.
- `run-verify-prefill-1`: numeric/readonly/lifetime PASS on pristine reference.
- `run-memcheck-prefill-1` and `run-synccheck-prefill-1`: zero errors.
- `run-racecheck-prefill-1`: pristine reference has 64 shared-memory race warnings, exit87; its performance has not been measured. This failure remains preserved. Any minimal synchronization repair will have a separate source/archive identity and cannot be called pristine throughput.

Actual measured reference: `sync-fixed/reference-build-result.json`, library SHA903576718caa737f73eede52f634ac7c154b85bdf44e914a6ec8e12b7e6809d3; one output `__syncwarp` added to69ff, no loader/planner/math/tile changes. Effective header SHA89b891802bf99bd2989c603d0c3346e0077a832d0c04199f3201d9b3e11023f8. Product actual C6 library SHA bbf3ec34a9aa0d7916ffc3ebb4a340583946ec3ce2bc33a6c0dc2711256ecec2. Final binary SHA f65b9b27ce5842c4c303b2888a9df3a634ca6358950a10e799385c18a8ef60a9. The original inputs and pristine failed artifacts remain preserved.

The corrected reference passes numerical/readonly/lifetime, memcheck, synccheck and racecheck on prefill+tail and window (zero errors/warnings). Auxiliary D64/DV128 holdout fails the original independent double-oracle tolerance on its first reference verification; it has no performance samples. `run-*-syncfixed-1` prefill setup rejections occurred before GPU launch because a link-script syntax error left stale source identities; they are retained separately, and actual corrected prefill checks use `syncfixed-2`.

The two ordinary runs each contain exactly16,384 pairs/128 blocks, all tails retained. `run-ordinary-prefill-syncfixed-1`: reference84.989458us vs C6 78.003444us (-8.219859%); all four matrix directions favor C6. `run-ordinary-window-syncfixed-1`: reference39.540493us vs C6 37.048305us (-6.302877%); all four matrix directions favor C6. These are finite complete normal-episode results, not an engine-wide/full-G04-G05 conclusion. `quick-summary.json` preserves each matrix and every validation status; independent analysis is maintained by the separate reviewer.

Prefill opts in to BF16 partials on both arms; both still accumulate locally in F32. Window actually does not split, so both report partial_dtype=none. Prefill required workspace is21,053,440B(reference) vs10,567,680B(C6), but this benchmark deliberately gives both programs64MiB caps: actual two-slot device-resource deltas are137,915,392B on both sides. Required bytes are not a claim that the benchmark's actual reserved bytes decreased. The previously measured11MiB product configuration is a separate memory experiment.
