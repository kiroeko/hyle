from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path('/mnt/c/public/project-hyle/hyle');OUT=ROOT/'.scratch/g04-same-fp8-comparison/race-analysis'
OUT.mkdir(exist_ok=True)
BASE=OUT.parent
identity=json.loads((BASE/'reference-build-result.json').read_text())
obj=Path(identity['object']);assert hashlib.sha256(obj.read_bytes()).hexdigest()==identity['object_sha256']
resources=(BASE/'reference-resources.txt').read_text()
symbols=re.findall(r' Function (\S+):\n',resources)
symbols=[s for s in symbols if 'KernelTraitsILNS_8MaskModeE1ELj64ELj1ELj4ELj16ELj16ELj4ELj1' in s and 'DefaultAttentionILb0ELb0ELb0ELb0' in s]
assert len(symbols)==1
argv=['/usr/local/cuda-13.3/bin/cuobjdump','--gpu-architecture','sm_89','--dump-sass','--function',symbols[0],str(obj)]
p=subprocess.run(argv,capture_output=True,text=True)
(OUT/'pristine-selected-sass.txt').write_text(p.stdout)
(OUT/'pristine-selected-sass-stderr.txt').write_text(p.stderr)
assert p.returncode==0
raw=(BASE/'run-racecheck-prefill-1/stdout.log').read_text()
reads={};writes={}
for line in raw.splitlines():
    if 'Read access' in line:
        pc=int(re.search(r'\+0x([0-9a-f]+)',line)[1],16);reads[pc]=reads.get(pc,0)+1
    if 'Write access' in line:
        pc=int(re.search(r'\+0x([0-9a-f]+)',line)[1],16);writes[pc]=writes.get(pc,0)+1
rows=[]
for line in p.stdout.splitlines():
    m=re.search(r'/\*([0-9a-fA-F]+)\*/\s+(.*?)\s*;\s*/\*\s*(0x[0-9a-fA-F]+)\s*\*/',line)
    if m:rows.append({'pc':int(m[1],16),'sass':m[2]+';','low64':m[3]})
assert rows and all(pc in {x['pc'] for x in rows} for pc in [*reads,*writes])
report={'scope':'Read-only actual pristine same-FP8 reference race PC binding; no GPU',
 'object':str(obj),'object_sha256':identity['object_sha256'],'symbol':symbols[0],'argv':argv,
 'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),
 'read_PCs':{hex(k):v for k,v in reads.items()},'write_PCs':{hex(k):v for k,v in writes.items()},
 'hazard_instructions':[{'pc':hex(x['pc']),'sass':x['sass'],'reads':reads.get(x['pc'],0),'writes':writes.get(x['pc'],0)} for x in rows if x['pc'] in reads or x['pc'] in writes]}
(OUT/'pristine-race-pc-bindings.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'pristine-selected-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'symbol':symbols[0],'rows':len(rows),'reads':len(reads),'writes':len(writes),'PC_range':[hex(min([*reads,*writes])),hex(max([*reads,*writes]))]},indent=2))
