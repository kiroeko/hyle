from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import tarfile
import time

REPO=Path('/mnt/c/public/project-hyle/hyle')
OUT=REPO/'.scratch/g04-same-fp8-comparison'
WORK=Path('/root/hyle-scratch/compute-unified/g04-same-fp8-reference')
ARCHIVE=REPO/'.scratch/validation/m1-route-binding/m1-cuda-intake/flashinfer-69ff11fc4954396d98326656dc85debd2223f637.tar.gz'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
utc=lambda:datetime.now(timezone.utc).isoformat()

def main():
    assert sha(ARCHIVE)=='4fc85abaa6210d6a1773e6011ff572aa0c04b7030644b74f75a2db2dbda472a9'
    WORK.mkdir(parents=True,exist_ok=True)
    upstream=WORK/'pristine-upstream'
    upstream.mkdir(exist_ok=True)
    archive_files={}
    with tarfile.open(ARCHIVE) as tar:
        prefix=tar.getnames()[0].split('/')[0]+'/'
        for item in tar:
            if not item.isfile():continue
            assert item.name.startswith(prefix)
            name=item.name[len(prefix):]
            dest=upstream/name
            assert dest.resolve().is_relative_to(upstream.resolve())
            data=tar.extractfile(item).read()
            archive_files[name]=hashlib.sha256(data).hexdigest()
            dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.exists() or dest.read_bytes()!=data:dest.write_bytes(data)
    actual={p.relative_to(upstream).as_posix():sha(p) for p in upstream.rglob('*') if p.is_file()}
    assert actual==archive_files and len(actual)==2576
    inventory=''.join(name+'|'+actual[name]+'\n' for name in sorted(actual))
    (OUT/'pristine-files.json').write_text(json.dumps(actual,indent=2)+'\n')
    for name in ['upstream_reference.cu','reference_api.h']:
        shutil.copyfile(OUT/name,WORK/name)
        assert sha(OUT/name)==sha(WORK/name)
    nvcc='/usr/local/cuda-13.3/bin/nvcc'
    obj=WORK/'upstream_reference.cu.o'
    args=[nvcc,'-forward-unknown-to-host-compiler',
          '-DFLASHINFER_ENABLE_BF16','-DFLASHINFER_ENABLE_F16',
          '-I'+str(WORK),'-I'+str(upstream/'include'),
          '-isystem','/usr/local/cuda-13.3/targets/x86_64-linux/include',
          '-O3','-DNDEBUG','-std=c++17',
          '--generate-code=arch=compute_89,code=[sm_89]',
          '-Xcompiler=-fvisibility=hidden,-fvisibility-inlines-hidden',
          '--split-compile=3','-x','cu','-c',str(WORK/'upstream_reference.cu'),
          '-o',str(obj),'--ptxas-options=-v']
    start=utc()
    identity={'kind':'PRISTINE_UPSTREAM_SAME_FP8_REFERENCE_COMPILE',
      'started_utc':start,'upstream_revision':'69ff11fc4954396d98326656dc85debd2223f637',
      'archive':str(ARCHIVE),'archive_sha256':sha(ARCHIVE),
      'pristine_directory':str(upstream),'pristine_file_count':len(actual),
      'pristine_inventory_sha256':hashlib.sha256(inventory.encode()).hexdigest(),
      'pristine_files_json_sha256':sha(OUT/'pristine-files.json'),
      'source_sha256':sha(WORK/'upstream_reference.cu'),
      'api_sha256':sha(WORK/'reference_api.h'),
      'namespace_substitution':'preprocessor token flashinfer -> g04_pristine_same_fp8_flashinfer; every upstream source byte unchanged',
      'adaptation':'Derived Params adds v_scale, consumed by original AttentionVariantBase::OutputTransform before BF16 partial narrowing. K scale multiplies params.sm_scale. No custom loader/planner/merge or expanded KV.',
      'scale_limit':'Same mathematical .5/2 operation; no claim of arbitrary-data bitwise equivalence to post-merge scaling. Both arms must pass identical independent double-oracle tolerance, finiteness, readonly, tail and lifetime checks.',
      'concurrency_limit':'Pristine synchronization is retained. Known old BF16-reference hazards are not silently patched; the actual FP8 reference requires separate racecheck as well as mem/synccheck before valid speed conclusions.',
      'compiled_product':False,'gpu_executed':False,'argv':args,'cwd':str(WORK),
      'toolchain':subprocess.run([nvcc,'--version'],capture_output=True,text=True,check=True).stdout,
      'original_C6_archive_reused':'/root/hyle-scratch/compute-unified/g04-bf16-c6/libhyle_compute_provider_flashinfer_c6.a'}
    (OUT/'pristine-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    t=time.monotonic()
    print(json.dumps({'event':'NVCC_START','utc':start,'source_sha256':identity['source_sha256'],'log':str(OUT/'reference-compile.log')}),flush=True)
    with (OUT/'reference-compile.log').open('wb') as log:
        result=subprocess.run(args,cwd=WORK,stdout=log,stderr=subprocess.STDOUT)
    identity.update({'compile_returncode':result.returncode,'compile_elapsed_s':time.monotonic()-t,'ended_utc':utc(),'log_sha256':sha(OUT/'reference-compile.log')})
    after={p.relative_to(upstream).as_posix():sha(p) for p in upstream.rglob('*') if p.is_file()}
    identity['pristine_after_compile_exact_archive']=after==archive_files
    assert identity['pristine_after_compile_exact_archive']
    if result.returncode==0:
        identity['object']=str(obj);identity['object_sha256']=sha(obj)
        archive=WORK/'libg04_pristine_same_fp8_reference.a'
        subprocess.run(['/usr/bin/ar','rcs',str(archive),str(obj)],check=True)
        identity['library']=str(archive);identity['library_sha256']=sha(archive)
        identity['library_members']=subprocess.run(['/usr/bin/ar','t',str(archive)],capture_output=True,text=True,check=True).stdout.splitlines()
        assert identity['library_members']==[obj.name]
        for label,argv in [('nm',['nm','-g','--defined-only',str(obj)]),
                           ('resources',[str(Path(nvcc).parent/'cuobjdump'),'--gpu-architecture','sm_89','--dump-resource-usage',str(obj)])]:
            p=subprocess.run(argv,capture_output=True,text=True)
            (OUT/f'reference-{label}.txt').write_text(p.stdout)
            (OUT/f'reference-{label}-stderr.txt').write_text(p.stderr)
            identity[label]={'argv':argv,'returncode':p.returncode,'stdout_sha256':sha(OUT/f'reference-{label}.txt')}
    (OUT/'reference-build-result.json').write_text(json.dumps(identity,indent=2)+'\n')
    print(json.dumps({'event':'NVCC_END','returncode':result.returncode,'elapsed_s':identity['compile_elapsed_s'],'library':identity.get('library'),'library_sha256':identity.get('library_sha256')}),flush=True)
    raise SystemExit(result.returncode)

if __name__=='__main__':main()
