from pathlib import Path
import subprocess, json
base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'g01-rr-git-checkout'
candidate = 'a40003f7edb54a3da3113d0cd401b46211e0b0f0'
if not source.exists():
    subprocess.run(['git','clone','--shared',str(base/'g01-p1-git-checkout'),str(source)],check=True)
subprocess.run(['git','-C',str(source),'fetch',str(base/'g01-p1-replay.bundle'),'refs/heads/main'],check=True)
subprocess.run(['git','-C',str(source),'checkout','--detach',candidate],check=True)
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
import hashlib, sys
sys.path.insert(0,str(source/'scripts'))
from hyle_perf.contract import canonical_sha256, load_contract
contract = source/'bench/inference_resident_sdpa/contract.json'
contract_hash = canonical_sha256(load_contract(contract))
assert contract_hash=='4ae724d684be30814e2f28d7d933f771b7e03dda56b86cb51464cef706031720'
peer=base/'g01-original-ggml-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='456172ec733a135778adcd32d00e576a58232e45'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
print(json.dumps({'candidate':candidate,'source':str(source),'contract_sha256':contract_hash,'peer':'original clean pin','old_source_unchanged':True}))
