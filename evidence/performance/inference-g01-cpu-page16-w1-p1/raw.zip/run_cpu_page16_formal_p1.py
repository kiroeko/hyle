from pathlib import Path
import hashlib, json, os, subprocess, time

canonical=Path.cwd();out=canonical/'.scratch/inference-gaps/g01'
repo=Path('C:/h7/g01-cpu-paged-p1-source-2');build=Path('C:/h7/g01-cpu-paged-p1-fresh-2')
evidence=out/'cpu-paged-p1-qualification-2'
assert not build.exists() and not evidence.exists(),'preserve old attempts; no budget reset'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
# Reject bad provenance BEFORE any new sampling; use the original evaluator.
import sys
sys.path.insert(0,str(canonical/'scripts'))
from hyle_perf.runner import _evaluate_product_evidence
contract_dir=canonical/'bench/inference_resident_sdpa/cpu_paged_p1'
contract_data=json.loads((contract_dir/'contract.json').read_text(encoding='utf-8'))
rows=_evaluate_product_evidence(contract_data,contract_dir)
assert all(row['gate']=='PASS' for row in rows),rows
provenance=json.loads((contract_dir/'consumer-provenance.json').read_text(encoding='utf-8'))
assert provenance['sha256']==hashlib.sha256((contract_dir/provenance['source']).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
if not repo.exists():
 subprocess.run(['git','clone','--shared','--no-checkout',str(canonical),str(repo)],check=True)
 subprocess.run(['git','-C',str(repo),'checkout','--detach',head],check=True)
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
candidate='42f98b94f33bdbb252b9259ece33533cf763fa41'
for name in ('src/compute_provider_ggml/native_batch.cc','src/compute_provider_ggml/ggml_cpu_provider.cc',
             'src/compute_provider_ggml/native_batch.h','third_party/ggml_cpu_runtime/patches.json','third_party/ggml_runtime/patches.json'):
 assert subprocess.check_output(['git','show',candidate+':'+name])==(repo/name).read_bytes(),name
# Product artifact evidence is immutable: verify the SDK files actually linked.
sdk=json.loads((out/'cpu-paged-win-static3-sdk-inputs.json').read_text())
for name,digest in sdk['artifacts'].items():
 p=Path(name)
 if 'relocated' in p.parts:assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
identity=json.loads((out/'cpu-paged-original-identity.json').read_text())
for name,digest in identity['original_dlls'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1)
  for old in list(env):
   if old.upper()==key.upper():del env[old]
  env[key]=value
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
source=repo/'bench/inference_resident_sdpa/cpu_paged_p1';peer=out/'original-ggml-cpu-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='ffa4e8b80930029a35991f94e7c8a93cd67730ab'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
args=['python',str(repo/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(source/'contract.json'),
 '--source',str(source),'--machine','W1-WIN','--peer','original-ggml-cpu-flash='+str(peer),
 '--build',str(build),'--output',str(evidence)]
log=out/'cpu-paged-p1-qualification-2.log';started=time.monotonic()
with log.open('w',encoding='utf-8') as f:
 process=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 status={'pid':process.pid,'command':args,'state':'RUNNING','product_candidate':candidate,
         'runtime_candidate':'42f98b94f33bdbb252b9259ece33533cf763fa41','source_commit':head,
         'contract_sha256':hashlib.sha256((source/'contract.json').read_bytes()).hexdigest(),'log':str(log)}
 (out/'cpu-paged-p1-job-2.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
 code=process.wait()
status.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-started)
(out/'cpu-paged-p1-job-2.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-3200));print(f.read(3200).decode(errors='replace'))
raise SystemExit(code)
