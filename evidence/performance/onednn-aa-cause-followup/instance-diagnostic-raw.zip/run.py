import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

root = Path(r'C:\public\project-hyle\hyle')
task = root / '.scratch/validation/onednn-aa-cause'
build = Path(r'C:\hv\odaa')
sdk = Path(r'C:\hyle-scratch\active-cpu\aa\selected-graph\static-sdk-relocated')
expected_jit = 'c739bdccc1ba774af10c8cd257b88d689382c02c2c006deed40b134e695568b0'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def fields(text, prefix):
    return [dict(re.findall(r'(\w+)=([^\s]+)', line)) for line in text.splitlines() if line.startswith(prefix)]

assert (build / '.hyle-owner').read_text(encoding='utf-8-sig').strip() == 'oneDNN A/A cause /root'
assert not (task / 'input-identity.json').exists(), 'This finite bundle has already been frozen'
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
inputs = [task / name for name in ('diagnostic.cc', 'CMakeLists.txt', 'build.ps1', 'run.py')]
inputs += [root / name for name in ('bench/graph_provider_onednn/normalization_p1_bench.cc',
                                   'bench/common/perf_process.h', 'third_party/nanobench/nanobench.h')]
inputs += [p for p in sdk.rglob('*') if p.is_file()]
inputs += [build / 'onednn_instance_diag.exe', build / 'CMakeCache.txt', build / 'compile_commands.json']
inputs += sorted(build.glob('*.dll'))
identity = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in inputs}
write(task / 'input-identity.json', {'candidate': candidate, 'inputs': identity,
                                  'kind': 'Bounded diagnosis; no product performance verdict',
                                  'process_budget': 4, 'groups_per_process': 6,
                                  'paired_rounds_per_group': 12, 'min_epoch_ms': 8,
                                  'historical_q2_binary_reused': False,
                                  'expected_historical_jit_sha256': expected_jit})
with zipfile.ZipFile(task / 'frozen-source.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
    for name in ('diagnostic.cc', 'CMakeLists.txt', 'build.ps1', 'run.py', 'input-identity.json'):
        bundle.write(task / name, name)
ctypes.windll.kernel32.SetErrorMode(0x8003)
rows = []
failure = None
for index in range(4):
    directory = build / 'runs' / f'run-{index}'
    directory.mkdir(parents=True, exist_ok=False)
    environment = {k: v for k, v in os.environ.items() if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_'))}
    environment['ONEDNN_JIT_DUMP'] = '1'
    command = [str(build / 'onednn_instance_diag.exe'), str(index)]
    process = subprocess.Popen(command, cwd=directory, env=environment, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        stdout, stderr = process.communicate()
    (directory / 'stdout.bin').write_bytes(stdout)
    (directory / 'stderr.bin').write_bytes(stderr)
    write(directory / 'process.json', {'command': command, 'pid': process.pid,
                                      'exit_code': process.returncode, 'timeout': timed_out,
                                      'jit_dump': 'ONEDNN_JIT_DUMP=1', 'uac_or_power_changes': False})
    try:
        assert process.returncode == 0 and not timed_out, 'Execution failed'
        output = stdout.decode('utf-8')
        observations = stderr.decode('utf-8')
        assert '# HYLE_AA_CAUSE_COMPLETE groups=6 rounds_per_group=12 correctness=PASS' in output
        summaries = fields(output, '# HYLE_AA_CAUSE_SUMMARY ')
        rounds = fields(output, '# HYLE_AA_CAUSE_ROUND ')
        instances = fields(observations, '# HYLE_NORMALIZATION_INSTANCE ')
        assert len(summaries) == 12 and len(rounds) == 144
        assert all(v['provider'] == 'onednn' for v in instances)
        intervals = fields(observations, '# HYLE_AA_CAUSE_INTERVAL ')
        assert all(v['cpu_before'] == '2' and v['cpu_after'] == '2' for v in intervals)
        jit = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in directory.glob('dnnl_dump_*.bin')}
        assert len(jit) == 2 and all(v['sha256'] == expected_jit for v in jit.values()), 'JIT differs from historical failure'
        parsed = {'index': index, 'summaries': summaries, 'rounds': rounds,
                  'instances': instances, 'intervals': intervals, 'jit': jit,
                  'process': fields(observations, '# HYLE_AA_CAUSE_PROCESS ')}
        write(directory / 'parsed.json', parsed)
        rows.append(parsed)
        print(json.dumps({'process': index, 'ratios': {v['group']: float(v['ratio']) for v in summaries if v['arm'] == '1'},
                          'correctness': 'PASS', 'jit_matches_original': True}), flush=True)
    except Exception as error:
        failure = str(error)
        break
changed = [name for name, fact in identity.items() if sha(Path(name)) != fact['sha256']]
write(task / 'result.json', {'processes_completed': len(rows), 'execution_failure': failure,
                            'immutable_input_changes': changed, 'rows': rows,
                            'old_q2_qualification': 'FAIL', 'new_product_performance_verdict': 'NOT_RUN'})
assert not changed, changed
if failure:
    raise SystemExit(f'Finite diagnosis stopped: {failure}; see C:/hv/odaa/runs')
