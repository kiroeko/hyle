$ErrorActionPreference = 'Stop'
$repoPath = 'C:\public\project-hyle\hyle'
$taskPath = Join-Path $repoPath '.scratch\validation\onednn-aa-cause'
$buildPath = 'C:\hv\odaa'
$sdkPath = 'C:\hyle-scratch\active-cpu\aa\selected-graph\static-sdk-relocated'
if (Test-Path -LiteralPath $buildPath) {
    if ((Get-Content -LiteralPath (Join-Path $buildPath '.hyle-owner') -Raw).Trim() -ne 'oneDNN A/A cause /root') { throw 'Unexpected owner' }
} else {
    New-Item -Path $buildPath -ItemType Directory | Out-Null
    Set-Content -LiteralPath (Join-Path $buildPath '.hyle-owner') -Value 'oneDNN A/A cause /root'
}
$devCmd = 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat'
$environmentCommand = 'call "' + $devCmd + '" -arch=x64 >nul && set'
$environmentLines = & $env:ComSpec /d /s /c $environmentCommand
if ($LASTEXITCODE -ne 0) { throw 'Cannot import compiler environment' }
foreach ($line in $environmentLines) {
    $separator = $line.IndexOf('=')
    if ($separator -gt 0) {
        $name = $line.Substring(0, $separator)
        $value = $line.Substring($separator + 1)
        if ($name -ieq 'Path' -and $value -notlike '*Visual Studio\18\Enterprise\VC\Tools\MSVC\*') { continue }
        Set-Item -Path "Env:$name" -Value $value
    }
}
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:VSLANG = '1033'
$compilerPath = 'C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'
& cmake -S $taskPath -B $buildPath -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_CXX_COMPILER=$compilerPath" "-DCMAKE_PREFIX_PATH=$sdkPath" "-DHYLE_CANONICAL_ROOT=$repoPath" > (Join-Path $taskPath 'configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { Get-Content -LiteralPath (Join-Path $taskPath 'configure.log') -Tail 35; exit $LASTEXITCODE }
& cmake --build $buildPath --parallel 2 > (Join-Path $taskPath 'build.log') 2>&1
if ($LASTEXITCODE -ne 0) { Get-Content -LiteralPath (Join-Path $taskPath 'build.log') -Tail 45; exit $LASTEXITCODE }
$runtimePath = Join-Path $env:VCToolsRedistDir 'x64\Microsoft.VC143.CRT'
if (-not (Test-Path -LiteralPath $runtimePath)) {
    $runtimePath = Get-ChildItem -LiteralPath (Join-Path $env:VCToolsRedistDir 'x64') -Directory | Where-Object { $_.Name -like 'Microsoft.VC*.CRT' } | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $runtimePath) { throw 'Cannot stage adjacent compiler runtime' }
Get-ChildItem -LiteralPath $runtimePath -Filter '*.dll' -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $buildPath -Force }
Get-Content -LiteralPath (Join-Path $taskPath 'build.log') -Tail 8
