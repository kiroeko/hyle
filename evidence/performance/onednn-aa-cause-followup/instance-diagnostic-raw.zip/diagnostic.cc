#define ANKERL_NANOBENCH_IMPLEMENT
#define main historical_normalization_entry
#include "bench/graph_provider_onednn/normalization_p1_bench.cc"
#undef main

namespace {
struct BoundRoute {
  DirectRoute *route;
  void operator()() const { route->run(); }
};

void observe_comparison(const char *group, DirectRoute &first,
                        DirectRoute &second, const Problem &problem) {
  first.verify(problem);
  second.verify(problem);
  first.observe(group, "baseline", true, problem);
  second.observe(group, "alternative", true, problem);
  nb::Bench bench;
  bench.title(group).relative(true).epochs(12)
      .minEpochTime(std::chrono::milliseconds(8));
  const auto before = cold_times();
  const auto result = bench.compare("baseline", BoundRoute{&first},
                                    "alternative", BoundRoute{&second});
  const auto after = cold_times();
  if (result.rounds() != 12 || result.size() != 2)
    fail("unexpected diagnostic round count");
  for (std::size_t arm = 0; arm < result.size(); ++arm) {
    const auto &entry = result[arm];
    std::printf("# HYLE_AA_CAUSE_SUMMARY group=%s arm=%zu ratio=%.17g low=%.17g "
                "high=%.17g rounds=%zu\n", group, arm, entry.relative,
                entry.relativeLow, entry.relativeHigh, result.rounds());
    for (std::size_t round = 0; round < entry.result.size(); ++round)
      std::printf("# HYLE_AA_CAUSE_ROUND group=%s arm=%zu round=%zu "
                  "seconds_per_op=%.17g iterations=%.0f\n", group, arm,
                  round, entry.result.get(round, nb::Result::Measure::elapsed),
                  entry.result.get(round, nb::Result::Measure::iterations));
  }
  std::fprintf(stderr, "# HYLE_AA_CAUSE_INTERVAL group=%s wall_ns=%lld "
                       "thread_cpu_100ns=%llu cpu_before=%lu cpu_after=%lu\n",
               group, static_cast<long long>(std::chrono::duration_cast<
                          std::chrono::nanoseconds>(after.wall-before.wall).count()),
               static_cast<unsigned long long>(after.thread_cpu_100ns-before.thread_cpu_100ns),
               before.cpu, after.cpu);
  first.verify(problem);
  second.verify(problem);
}
} // namespace

int main(int argc, char **argv) {
  ::SetErrorMode(0x8003);
  if (argc != 2 || argv[1][0] < '0' || argv[1][0] > '3' || argv[1][1])
    fail("diagnostic requires fixed process index 0..3");
  const int index = argv[1][0] - '0';
  if (!::SetProcessAffinityMask(::GetCurrentProcess(), 0x4) ||
      !::SetThreadAffinityMask(::GetCurrentThread(), 0x4) ||
      !::SetPriorityClass(::GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS))
    fail("apply original single-P-core process policy");
  DWORD_PTR process_mask = 0, system_mask = 0;
  if (!::GetProcessAffinityMask(::GetCurrentProcess(), &process_mask, &system_mask)
      || process_mask != 0x4)
    fail("verify process affinity");
  std::fprintf(stderr, "# HYLE_AA_CAUSE_PROCESS index=%d pid=%lu mask=0x%llx "
                       "priority=%lu cpu=%lu provider=onednn\n", index,
               ::GetCurrentProcessId(), static_cast<unsigned long long>(process_mask),
               ::GetPriorityClass(::GetCurrentProcess()), ::GetCurrentProcessorNumber());
  Problem problem(17, 257, false);
  std::unique_ptr<DirectRoute> a, b;
  if (index % 2 == 0) {
    a = std::make_unique<DirectRoute>(problem, true);
    b = std::make_unique<DirectRoute>(problem, true);
  } else {
    b = std::make_unique<DirectRoute>(problem, true);
    a = std::make_unique<DirectRoute>(problem, true);
  }
  a->run();
  b->run();
  a->observe("identity", "A", true, problem);
  b->observe("identity", "B", true, problem);
  observe_code("diagnostic-17x257");
  observe_comparison("pre-AA", *a, *a, problem);
  observe_comparison("pre-BB", *b, *b, problem);
  if (index < 2) {
    observe_comparison("AB", *a, *b, problem);
    observe_comparison("BA", *b, *a, problem);
  } else {
    observe_comparison("BA", *b, *a, problem);
    observe_comparison("AB", *a, *b, problem);
  }
  observe_comparison("post-AA", *a, *a, problem);
  observe_comparison("post-BB", *b, *b, problem);
  std::puts("# HYLE_AA_CAUSE_COMPLETE groups=6 rounds_per_group=12 correctness=PASS");
  return 0;
}
