import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import zipfile

root = Path(r'C:\public\project-hyle\hyle')
task = root / '.scratch/validation/onednn-aa-cause'
build = Path(r'C:\hv\odaa')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def fields(text, prefix):
    return [dict(re.findall(r'(\w+)=([^\s]+)', line)) for line in text.splitlines() if line.startswith(prefix)]

identity = json.loads((task / 'input-identity.json').read_text(encoding='utf-8'))
assert all(sha(Path(p)) == v['sha256'] for p, v in identity['inputs'].items())
assert not (task / 'resumed-result.json').exists(), 'Fixed bundle already resumed'
original_failure = json.loads((task / 'result.json').read_text(encoding='utf-8'))
assert original_failure['execution_failure'] == 'JIT differs from historical failure'
with zipfile.ZipFile(root / 'evidence/performance/onednn-normalization-aa-q2/failed-experiment-raw.zip') as archive:
    original = archive.read('preflight/selected-primary-peer-first-candidate-first/dnnl_dump_cpu_jit_lnorm_stat_and_data_kernel_t.28.bin')
assert len(original) == 3039 and original[87:89] == bytes.fromhex('49bb')
exe_bytes = (build / 'onednn_instance_diag.exe').read_bytes()
pe = struct.unpack_from('<I', exe_bytes, 60)[0]
section_count = struct.unpack_from('<H', exe_bytes, pe + 6)[0]
section_table = pe + 24 + struct.unpack_from('<H', exe_bytes, pe + 20)[0]

def validate_relocated_jit(blob, executable_base):
    assert len(blob) == len(original)
    assert blob[:89] == original[:89] and blob[97:] == original[97:]
    pointer = int.from_bytes(blob[89:97], 'little')
    rva = pointer - executable_base
    for index in range(section_count):
        pos = section_table + 40 * index
        virtual_size, virtual_address, raw_size, raw_pos = struct.unpack_from('<IIII', exe_bytes, pos + 8)
        if virtual_address <= rva and rva + 32 <= virtual_address + raw_size:
            flags = struct.unpack_from('<I', exe_bytes, pos + 36)[0]
            assert not flags & 0x80000000, 'Mask table is not read-only'
            table = exe_bytes[raw_pos+rva-virtual_address:raw_pos+rva-virtual_address+32]
            assert table == bytes.fromhex('ffffffff' + '00000000' * 7)
            return {'pointer': hex(pointer), 'rva': hex(rva), 'mask_bytes': table.hex(),
                    'only_relocation_differs': True}
    raise AssertionError('JIT mask pointer outside readable PE file section')

write(task / 'resume-identity.json', {'validator_sha256': sha(Path(__file__)),
                                   'prior_identity_sha256': sha(task / 'input-identity.json'),
                                   'completed_process_reused': 0, 'new_process_indices': [1, 2, 3]})
ctypes.windll.kernel32.SetErrorMode(0x8003)
rows = []
failure = None
for index in range(4):
    directory = build / 'runs' / f'run-{index}'
    if index == 0:
        process_fact = json.loads((directory / 'process.json').read_text(encoding='utf-8'))
        assert process_fact['exit_code'] == 0 and not process_fact['timeout']
        stdout, stderr = (directory / 'stdout.bin').read_bytes(), (directory / 'stderr.bin').read_bytes()
    else:
        directory.mkdir(parents=True, exist_ok=False)
        environment = {k: v for k, v in os.environ.items() if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_'))}
        environment['ONEDNN_JIT_DUMP'] = '1'
        command = [str(build / 'onednn_instance_diag.exe'), str(index)]
        process = subprocess.Popen(command, cwd=directory, env=environment, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        timed_out = False
        try:
            stdout, stderr = process.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            stdout, stderr = process.communicate()
        (directory / 'stdout.bin').write_bytes(stdout)
        (directory / 'stderr.bin').write_bytes(stderr)
        process_fact = {'command': command, 'pid': process.pid, 'exit_code': process.returncode,
                        'timeout': timed_out, 'jit_dump': 'ONEDNN_JIT_DUMP=1', 'uac_or_power_changes': False}
        write(directory / 'process.json', process_fact)
    try:
        assert process_fact['exit_code'] == 0 and not process_fact['timeout'], 'Execution failed'
        output, observations = stdout.decode('utf-8'), stderr.decode('utf-8')
        assert '# HYLE_AA_CAUSE_COMPLETE groups=6 rounds_per_group=12 correctness=PASS' in output
        summaries = fields(output, '# HYLE_AA_CAUSE_SUMMARY ')
        rounds = fields(output, '# HYLE_AA_CAUSE_ROUND ')
        instances = fields(observations, '# HYLE_NORMALIZATION_INSTANCE ')
        intervals = fields(observations, '# HYLE_AA_CAUSE_INTERVAL ')
        assert len(summaries) == 12 and len(rounds) == 144
        assert all(v['provider'] == 'onednn' for v in instances)
        assert all(v['cpu_before'] == '2' and v['cpu_after'] == '2' for v in intervals)
        code_facts = fields(observations, '# HYLE_NORMALIZATION_PROCESS ')
        base = int(code_facts[0]['executable_base'], 16)
        jit = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p),
                        **validate_relocated_jit(p.read_bytes(), base)} for p in directory.glob('dnnl_dump_*.bin')}
        assert len(jit) == 2 and len({v['sha256'] for v in jit.values()}) == 1
        parsed = {'index': index, 'summaries': summaries, 'rounds': rounds,
                  'instances': instances, 'intervals': intervals, 'jit': jit,
                  'process': fields(observations, '# HYLE_AA_CAUSE_PROCESS ')}
        write(directory / 'parsed-relocation-checked.json', parsed)
        rows.append(parsed)
        print(json.dumps({'process': index, 'ratios': {v['group']: float(v['ratio']) for v in summaries if v['arm'] == '1'},
                          'correctness': 'PASS', 'code_and_mask_match_original': True}), flush=True)
    except Exception as error:
        failure = str(error)
        break
changed = [name for name, fact in identity['inputs'].items() if sha(Path(name)) != fact['sha256']]
write(task / 'resumed-result.json', {'processes_completed': len(rows), 'execution_failure': failure,
                                    'immutable_input_changes': changed, 'rows': rows,
                                    'old_q2_qualification': 'FAIL', 'new_product_performance_verdict': 'NOT_RUN'})
assert not changed, changed
if failure:
    raise SystemExit(f'Finite diagnosis stopped: {failure}; see C:/hv/odaa/runs')
