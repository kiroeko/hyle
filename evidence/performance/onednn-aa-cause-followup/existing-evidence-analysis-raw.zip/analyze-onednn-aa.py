import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import zipfile

root = Path.cwd().resolve()
assert (root / 'AGENTS.md').is_file()
archive = root / 'evidence/performance/onednn-normalization-aa-q2/failed-experiment-raw.zip'
expected = 'ae947a9ee0cce43a68c4d52723a4402ae6dde67638a68678a7d37672404d9933'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
workload = 'direct-layer-17x257'
rows = []
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name in sorted(bundle.namelist()):
        if not name.startswith('preflight/selected-') or not name.endswith('/parsed.json'):
            continue
        data = json.loads(bundle.read(name))
        prefix = name.rsplit('/', 1)[0]
        process = json.loads(bundle.read(prefix + '/process.json'))
        observations = data['observations']
        instances = [v for v in observations['instances'] if v['workload'] == workload]
        assert len(instances) == 2 and all(v['provider'] == 'onednn' for v in instances)
        assert instances[0]['input_handle'] == instances[1]['input_handle']
        addresses = []
        for entry in instances:
            addresses.append({**entry, 'output_mod_65536': int(entry['output_handle'], 16) % 65536,
                              'workspace_mod_4096': int(entry['workspace_handle'], 16) % 4096})
        jit = []
        for index in (28, 29):
            filename = f'dnnl_dump_cpu_jit_lnorm_stat_and_data_kernel_t.{index}.bin'
            blob = bundle.read(prefix + '/' + filename)
            fact = {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()}
            assert fact == data['vendor_jit'][filename]
            jit.append({'filename': filename, **fact})
        assert jit[0]['sha256'] == jit[1]['sha256']
        stdout = bundle.read(prefix + '/stdout.bin').decode('utf-8')
        lines = stdout.splitlines()
        table = []
        for index, line in enumerate(lines):
            if 'ns/op' in line and 'normalization direct layer f32 R=17 W=257' in line:
                table = lines[index:index + 8]
        assert table
        rows.append({'process': prefix.split('/')[-1], 'ratio': data['ratios'][workload],
                     'all_workload_ratios': data['ratios'], 'telemetry': data['telemetry'],
                     'instances': addresses, 'jit': jit,
                     'process_observation': [v for v in observations['processes'] if v['workload'] == workload],
                     'coarse_intervals': [v for v in observations['coarse_intervals'] if v['workload'] == workload],
                     'private_executable_ranges': [v for v in observations['private_executable_ranges'] if v['workload'] == workload],
                     'table': table, 'launcher_environment': process.get('environment'),
                     'command': process.get('command'),
                     'gross_fail': not 1 / 1.10 <= data['ratios'][workload] <= 1.10})
    assert len(rows) == 8
    source_names = [n for n in bundle.namelist() if n.startswith('sources/')]
    source_hashes = {n: hashlib.sha256(bundle.read(n)).hexdigest() for n in source_names}
    assert len(source_hashes) == 5

bad = [row for row in rows if row['gross_fail']]
assert len(bad) == 1
good = [row['ratio'] for row in rows if not row['gross_fail']]
nanobench = root / 'third_party/nanobench/nanobench.h'
historical = subprocess.check_output(['git', 'show', '0e107a06:third_party/nanobench/nanobench.h'], cwd=root)
assert nanobench.read_bytes() == historical
report = {
    'kind': 'Read-only analysis of original oneDNN-only Q2 A/A evidence; no new timing',
    'date': '2026-09-21', 'source_archive': str(archive.relative_to(root)).replace('\\', '/'),
    'source_archive_sha256': expected, 'zip_crc': 'PASS', 'source_file_sha256': source_hashes,
    'nanobench_sha256': hashlib.sha256(historical).hexdigest(),
    'workload': workload, 'selected_processes': len(rows),
    'historical_ratio': bad[0]['ratio'], 'historical_reciprocal': 1 / bad[0]['ratio'],
    'other_seven_ratio_range': [min(good), max(good)],
    'eight_process_median': statistics.median(row['ratio'] for row in rows),
    'same_case': rows,
    'new_performance_processes': 0, 'old_qualification': 'FAIL',
    'product_winner_verdict': 'INCONCLUSIVE',
    'proven': [
        'Both roles use the same DirectRoute and oneDNN provider, shared problem inputs, independent output/workspace/context/invocation.',
        'The archived Native display label is stale in selected A/A mode; it does not describe the actual provider.',
        'Two relevant JIT dumps have identical bytes within all eight processes; this does not identify role-specific JIT entry addresses.',
        'The instrument uses common iteration counts and paired ABBA/BAAB blocks; there is no always-A-then-B measured order.',
        'The failing process has a within-process paired interval below unity; a single isolated slow sample has not been proved.',
        'Candidate/peer low address offsets of the failed configuration also occur in successful configurations; these offsets alone do not explain the result.',
        'Gross qualification uses the ratio of marginal throughput medians; paired log-ratio median is a different statistic. Both reported values fail this case.'
    ],
    'unresolved': [
        'Actual role-specific JIT entry addresses and physical cache placement were not recorded.',
        'Per-round samples were discarded by the benchmark even though CompareResult retained them in memory.',
        'CPU identity and thread CPU time were sampled around the complete comparison, not for each arm; no arm-specific cycles or context-switch trace exists.',
        'Existing evidence cannot distinguish persistent instance/code/data placement effects from short-lived environment interference in that process.'
    ],
    'scope_limits': ['No frozen native implementation inspected or timed', 'No product, benchmark or shared instrument changes',
                     'No old Q2 rerun, threshold adjustment, exception or power-policy change']
}
output = Path(__file__).with_name('onednn-aa-existing-evidence.json')
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({key: report[key] for key in ('selected_processes', 'historical_ratio', 'historical_reciprocal', 'other_seven_ratio_range', 'eight_process_median', 'new_performance_processes')}, indent=2))
print('\n'.join(bad[0]['table']))
