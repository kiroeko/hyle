from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'cpu-encoded-p1-qualification-4'
SOURCE=Path('C:/h7/g04-cpu-encoded-p1-source-4');BUILD=Path('C:/h7/g04-cpu-encoded-p1-build-4')
assert not OUT.exists() and not SOURCE.exists() and not BUILD.exists()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
registry=json.loads((ROOT/'docs/implementation/module-status.json').read_text(encoding='utf-8'))
owner=next(m for m in registry['modules'] if m['module']=='compute_provider_ggml')
assert owner['state']=='CANDIDATE'
candidate=owner['candidate']
assert candidate=='42a4c7cdcc0822a7b162efe575909622a906de1d'
assert not subprocess.check_output(['git','diff','--name-only',candidate,head,'--','src','include','cmake','third_party'],text=True).strip()
assert json.loads((BASE/'ce13-air-cpu-mixed-job-3.json').read_text(encoding='utf-8'))['state']=='TERMINAL_PASS'
assert json.loads((BASE/'ce13-validation-job-3.json').read_text(encoding='utf-8'))['state']=='TERMINAL_PASS'
assert sum(m.get('candidate')==candidate and m['state']=='CANDIDATE' and m['module'] in ('compute_ggml_runtime','compute_provider_ggml') for m in registry['modules'])==2
assert sum(m.get('candidate')=='982676cb05a6e6244e66e0a596347aa96043617b' and m['state']=='CANDIDATE' and m.get('record','').endswith('inference-g04-g05-cache-attention-domain.md') for m in registry['modules'])==9
for name in ('cpu_encoded_bench.cc','cpu_paged_reference.cc','cpu_paged_original_execution.h','cpu_placement.cc','cpu_encoded_p1/validate_aa.py','cpu_paged_p1/peer/bridge.cc'):
 path='bench/inference_resident_sdpa/'+name
 assert subprocess.check_output(['git','show','993fc414e352c5a7b8bbf27d4ffd042931bd3117:'+path])==(ROOT/path).read_bytes(),path
for name in ('scripts/hyle-perf.py',):
 assert subprocess.check_output(['git','show','993fc414e352c5a7b8bbf27d4ffd042931bd3117:'+name])==(ROOT/name).read_bytes(),name
for row in json.loads((BASE/'cpu-sdk/artifacts-cpu-static-ce13-1.json').read_text(encoding='utf-8')):assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
identity=json.loads((ROOT/'.scratch/inference-gaps/g01/cpu-paged-original-identity.json').read_text(encoding='utf-8'))
for name,sha in identity['original_dlls'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha
peer=ROOT/'.scratch/inference-gaps/g01/original-ggml-cpu-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='ffa4e8b80930029a35991f94e7c8a93cd67730ab'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
# Independent disposable validation copy. Never changes canonical source or older evidence trees.
subprocess.run(['git','clone','--shared','--no-checkout',str(ROOT),str(SOURCE)],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','-C',str(SOURCE),'checkout','--detach',head],check=True,stdout=subprocess.DEVNULL)
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()
setup=subprocess.check_output(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
contract=SOURCE/'bench/inference_resident_sdpa/cpu_encoded_p1/contract.json'
assert json.loads(contract.read_text())['extensions']['runner']['cmake']['cache']['CMAKE_PREFIX_PATH']=='C:/h7/g04-sdk-cpu-static-ce13-1/relocated','must measure the new CE13 SDK, not the retained original failing artifact'
args=['python',str(SOURCE/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(contract),'--source',str(contract.parent),'--machine','W1-WIN','--peer','original-ggml-cpu-flash='+str(peer),'--build',str(BUILD),'--output',str(OUT)]
log=BASE/'cpu-encoded-p1-qualification-4.log';start=time.monotonic()
with log.open('wb') as stream:
 process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 job={'state':'RUNNING','pid':process.pid,'source_commit':head,'product_candidate':candidate,'contract_sha256':hashlib.sha256(contract.read_bytes()).hexdigest(),'source':str(SOURCE),'build':str(BUILD),'output':str(OUT),'log':str(log),'command':args,'heavy_serial':True,'max_compile_jobs':4}
 (BASE/'cpu-encoded-p1-job-4.json').write_text(json.dumps(job,indent=2)+'\n',encoding='utf-8');print(json.dumps(job),flush=True)
 code=process.wait()
job.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-start)
(BASE/'cpu-encoded-p1-job-4.json').write_text(json.dumps(job,indent=2)+'\n',encoding='utf-8');print(json.dumps(job),flush=True)
print(log.read_text(encoding='utf-8',errors='replace')[-4500:],flush=True)
raise SystemExit(code)
