from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time,uuid

# Invoke only after the actual Air P1 parent has reached terminal. This is a
# four-process measurement diagnostic, never a replacement for full A/A/P1.
base=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05')
air=json.loads((base/'apple-encoded-p1/5/launch.json').read_text())
assert air['state']=='TERMINAL' and air['remote_state']['state'].startswith('TERMINAL')
ext=Path('/root/hyle-scratch/compute-unified');old=ext/'g04-cuda-encoded-p1-fresh-4'
source=ext/'g04-cuda-encoded-p1-source-4';out=ext/'ce14-cuda-duration-diagnostic-1';out.mkdir(exist_ok=False)
canonical=Path('/mnt/c/public/project-hyle/hyle')
name='bench/inference_resident_sdpa/cuda_encoded_page_bench.cc'
assert (canonical/name).read_bytes()==(source/name).read_bytes()
sys.path.insert(0,str(source/'scripts'))
from hyle_perf.environment import PERF_ENVIRONMENT_BLOCKLIST,PERF_ENVIRONMENT_FIXED,PERF_ENVIRONMENT_PREFIXES
from hyle_perf.machine import get_machine_profile,load_registry,expected_child_policy
from hyle_perf.runner import _apply_sampling_policy,_creation_flags
from hyle_perf.nanobench import parse_nanobench
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
record=dict(state='SETUP',stages=[],runs=[],limits='Four diagnostic controls at the previously unstable placement/peer-first/peer-allocation-first stratum. Same original16paired rounds and three shapes; not full16A/A, P1 or a performance claim.')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
record['identity']={k:subprocess.check_output(c,text=True).strip() for k,c in (
 ('host',['uname','-a']),('compiler',['g++-14','--version']),
 ('gpu',['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader']))}
assert 'RTX 4070' in record['identity']['gpu'] and '8.9' in record['identity']['gpu']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def failed(kind,error,tb):
 record.update(state='TERMINAL_SETUP_OR_ANALYSIS_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,tb)
sys.excepthook=failed
save()

def run(stage,cmd,environment=None,cwd=old):
 t=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as f:
  p=subprocess.Popen(cmd,cwd=cwd,env=environment or env,stdout=f,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',stage=stage,pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
 record['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-t));save()
 if code:record['state']='TERMINAL_FAIL';save();raise SystemExit(code)
rows=json.loads(subprocess.check_output(['ninja','-C',str(old),'-t','compdb'],env=env,text=True))
matching=[r for r in rows if r['file'].endswith('cuda_encoded_page_bench.cc') and 'g04_cuda_encoded_bench_placement.dir' in r['output']]
assert len(matching)==1;row=matching[0];compile_args=shlex.split(row['command'])
commands=subprocess.check_output(['ninja','-C',str(old),'-t','commands','g04_cuda_encoded_bench_placement'],env=env,text=True).splitlines()
link=[]
for line in commands:
 parts=shlex.split(line)
 if '-o' not in parts:continue
 target=parts[parts.index('-o')+1]
 if Path(target).name!='g04_cuda_encoded_bench_placement':continue
 start=parts.index(compile_args[0]);parts=parts[start:]
 if '&&' in parts:parts=parts[:parts.index('&&')]
 link=parts
assert link and row['output'] in link
reuse=sorted({(old/a).resolve() for a in link if a.endswith(('.o','.a')) and a!=row['output']})
assert len(reuse)>=3 and all(p.is_file() for p in reuse)
record.update(original_benchmark_sha256=sha(source/name),reused_objects=[dict(path=str(p),sha256=sha(p)) for p in reuse]);save()
policy=expected_child_policy(get_machine_profile(load_registry(),'W1-WSL'))
for milliseconds in (200,500):
 cpp=out/f'bench-{milliseconds}.cc';obj=out/f'bench-{milliseconds}.o';binary=out/f'bench-{milliseconds}'
 text=(source/name).read_text();before='minEpochTime(std::chrono::milliseconds(40))';assert text.count(before)==1
 cpp.write_text(text.replace(before,f'minEpochTime(std::chrono::milliseconds({milliseconds}))'))
 args=list(compile_args);args[args.index('-o')+1]=str(obj)
 for switch,value in [('-MF',str(out/f'bench-{milliseconds}.d')),('-MT',str(obj))]:
  if switch in args:args[args.index(switch)+1]=value
 sources=[i for i,a in enumerate(args) if a.endswith('cuda_encoded_page_bench.cc')];assert len(sources)==1
 args[sources[0]]=str(cpp);args[1:1]=['-iquote',str((source/name).parent)]
 run(f'compile-{milliseconds}',args)
 args=[str(obj) if a==row['output'] else a for a in link];args[args.index('-o')+1]=str(binary)
 for i,a in enumerate(args):
  for prefix in ('-Wl,--dependency-file=','-Wl,-Map='):
   if a.startswith(prefix):args[i]=prefix+str(out/f'link-{milliseconds}.map')
 run(f'link-{milliseconds}',args)
 for p in reuse:assert sha(p)==next(x['sha256'] for x in record['reused_objects'] if x['path']==str(p))
 with _apply_sampling_policy(policy):
  for route in (('selected','native') if milliseconds==200 else ('native','selected')):
   clean={k:v for k,v in env.items() if k not in PERF_ENVIRONMENT_BLOCKLIST and not any(k.startswith(p) for p in PERF_ENVIRONMENT_PREFIXES)}
   clean.update(PERF_ENVIRONMENT_FIXED)
   clean.update(HYLE_BENCH_AA_ROUTE=route,HYLE_PERF_RUN_NONCE=uuid.uuid4().hex,HYLE_BENCH_RIVAL_FIRST='1',HYLE_BENCH_PEER_ALLOCATION_FIRST='1')
   stage=f'control-{milliseconds}-{route}';run(stage,[str(binary)],clean)
   rows=list(parse_nanobench((out/(stage+'.log')).read_text()).values());ratios={}
   for title in dict.fromkeys(r.title for r in rows):
    d={r.variant:r.operations_per_second for r in rows if r.title==title}
    ratios[title]=d['HYLE CUDA encoded paged']/d['Original CUDA cold-expanded immutable lifecycle']
   assert len(ratios)==3
   record['runs'].append(dict(milliseconds=milliseconds,route=route,ratios=ratios,binary_sha256=sha(binary)));save()
record['state']='TERMINAL_DIAGNOSTIC_ONLY';save();print(json.dumps(record['runs']),flush=True)
