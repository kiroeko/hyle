"""One bounded, untimed observation of the frozen F1 executable."""
import ctypes
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path('C:/public/project-hyle/hyle')
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_perf import (evaluate_machine_profile,expected_child_policy,
                       get_machine_profile,load_registry,probe_machine,sampling_mutex)
from hyle_perf.runner import _apply_sampling_policy,_child_environment

logs=ROOT/'.scratch/validation/onednn-aa'
destination=Path('C:/hyle-scratch/active-cpu/aa-q1-jit')
assert destination.resolve()==destination
assert destination.parent==Path('C:/hyle-scratch/active-cpu')
assert not destination.exists()
binary=Path('C:/hyle-scratch/active-cpu/p1/bin/hyle_onednn_normalization_bench.exe')
manifest=json.loads((ROOT/'evidence/performance/onednn-normalization-f1-64e1e169-w1-win/manifest.json').read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
identity=next(r['file']['sha256'] for r in manifest['artifacts'] if r['id']=='normalization-primary')
assert sha(binary)==identity
contract=json.loads((ROOT/'bench/contracts/onednn-normalization-p1-v1.json').read_text(encoding='utf-8'))
assert not subprocess.check_output(['git','diff','64e1e169','--','src','include',
                                    'bench/graph_provider_onednn/normalization_p1_bench.cc'],cwd=ROOT)
profile=get_machine_profile(load_registry(),'W1-WIN')
probe=probe_machine(paths=[('build',binary.parent)])
gate=evaluate_machine_profile(profile,probe,role='engineering',sampling_topology='single-logical-cpu')
assert gate['gate']=='PASS',gate
policy=expected_child_policy(profile,probe=probe,sampling_topology='single-logical-cpu')
environment=_child_environment(contract['extensions']['runner']['controlled_environment'],
    {'HYLE_BENCH_AA_ROUTE':'selected','HYLE_BENCH_VERIFY_ONLY':'1','ONEDNN_JIT_DUMP':'1'},profile,policy)
environment.pop('DNNL_JIT_DUMP',None)
ctypes.WinDLL('kernel32',use_last_error=True).SetErrorMode(0x8003)
destination.mkdir()
with sampling_mutex(profile) as lease:
    with _apply_sampling_policy(policy):
        result=subprocess.run([str(binary)],cwd=destination,env=environment,
                              capture_output=True,text=True,encoding='utf-8',errors='replace',
                              creationflags=0x00008000,timeout=90)
raw=result.stdout+result.stderr
(logs/'q1-jit-identity.log').write_text(raw,encoding='utf-8',newline='\n')
assert result.returncode==0,raw
assert 'ns/op' not in raw and '| relative' not in raw
assert sha(binary)==identity
files=[]
for path in destination.glob('*.bin'):
    files.append({'name':path.name,'bytes':path.stat().st_size,'sha256':sha(path)})
files.sort(key=lambda row:row['name'])
assert files,'vendor dump produced no observable code'
receipt={'mode':'VERIFY_ONLY; no timing or qualification','parent_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
         'artifact_source':manifest['source'],'binary':str(binary),'binary_sha256':identity,
         'child_policy':policy,'environment_overrides':{'HYLE_BENCH_AA_ROUTE':'selected','HYLE_BENCH_VERIFY_ONLY':'1','ONEDNN_JIT_DUMP':'1'},
         'log':'q1-jit-identity.log','log_sha256':sha(logs/'q1-jit-identity.log'),
         'exit_code':result.returncode,'dumps':files,'output':str(destination),
         'limitations':'This newly-created process cannot recover the historical failed instance addresses or infer speed.'}
(logs/'q1-jit-identity.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'files':len(files),'bytes':sum(r['bytes'] for r in files),'unique_code_hashes':len({r['sha256'] for r in files}),'sample_names':[r['name'] for r in files[:4]]}))
