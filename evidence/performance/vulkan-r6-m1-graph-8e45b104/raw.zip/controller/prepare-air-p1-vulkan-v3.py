import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source = root / 'native-a1329dd2'
out = root / 'selected-m1-a41d43d5'
out.mkdir(exist_ok=False)
candidate = 'a41d43d531365a1fb8617d60113b37924e9a9864'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
subprocess.run(['git', 'bundle', 'verify', str(root / 'hyle-air-loader-fix.bundle')], cwd=source, check=True)
subprocess.run(['git', 'fetch', str(root / 'hyle-air-loader-fix.bundle'), 'HEAD'], cwd=source, check=True)
subprocess.run(['git', 'checkout', '--detach', candidate], cwd=source, check=True)
compiler_info = next((root / 'build-native-a1329dd2/CMakeFiles').glob('*/CMakeCXXCompiler.cmake')).read_text()
compiler = Path(re.search(r'set\(CMAKE_CXX_COMPILER "([^"]+)"\)', compiler_info)[1])
version = re.search(r'set\(CMAKE_CXX_COMPILER_VERSION "([^"]+)"\)', compiler_info)[1]
macros = subprocess.check_output([str(compiler), '-dM', '-E', '-x', 'c++', '-include', 'version', '-'], input='', text=True)
stl = re.search(r'^#define _LIBCPP_VERSION (.+)$', macros, re.M)[1]
profile = json.loads((source / 'scripts/perf-machines.json').read_text())['machine_profiles']['M1-MAC']
profile_hash = hashlib.sha256(json.dumps(profile, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
context = {'toolchain': {'id': 'appleclang-' + version + '-arm64', 'compiler_path': str(compiler),
    'compiler_id': 'AppleClang', 'compiler_version': version, 'stdlib': {'id': 'libc++-' + stl},
    'flags': {'CMAKE_CXX_FLAGS': '', 'CMAKE_CXX_FLAGS_RELEASE': '-O3 -DNDEBUG'}},
    'machine_profile': {'id': 'M1-MAC', 'profile_hash': profile_hash, 'role': 'engineering'}}
(out / 'context.json').write_text(json.dumps(context, indent=2) + '\n')
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=source, text=True).strip()
env = dict(os.environ, PATH='/opt/homebrew/bin:' + os.environ['PATH'], MACOSX_DEPLOYMENT_TARGET='14.4',
           CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1',
           DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib', VK_LOADER_LAYERS_DISABLE='~implicit~')
for mode in ('compute', 'graph'):
    contract = f'bench/contracts/{mode}-vulkan-ffn-m1-p1-v1.json'
    raw = subprocess.check_output(['git', 'show', candidate + ':' + contract], cwd=source)
    card = {'candidate_commit': candidate, 'candidate_tree': tree, 'candidate_fixed': True,
            'factors': [mode + '_route_vulkan'], 'contract': contract,
            'contract_hash': hashlib.sha256(raw).hexdigest(),
            'peers': {'ggml-vulkan-f32': str(root / 'peer-ggml-456172ec')}}
    path = out / (mode + '-p1-card.json')
    path.write_text(json.dumps(card, indent=2) + '\n')
    subprocess.run(['/usr/bin/python3', 'scripts/validation-select.py', 'plan', '--base', 'e4085366',
        '--candidate', candidate, '--context', str(out / 'context.json'), '--p1-card', str(path),
        '--scratch', str(out / mode), '--cache', str(out / 'receipts'),
        '--output', str(out / (mode + '-plan.json'))], cwd=source, env=env, check=True)
print('Prepared immutable plans only; no build or sampling.', flush=True)
