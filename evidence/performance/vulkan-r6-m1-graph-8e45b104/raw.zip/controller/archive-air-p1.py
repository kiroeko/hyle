"""Archive one completed immutable Air P1 without altering runner output bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=('compute', 'graph'), required=True)
args = parser.parse_args()
root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source = root / 'native-a1329dd2'
selected = root / 'selected-m1-a41d43d5'
nodes = list((selected / args.mode).glob('*/p1-evidence'))
assert len(nodes) == 1, nodes
evidence = nodes[0]
build = evidence.parent / 'p1-build'
snapshot = 'a41d43d531365a1fb8617d60113b37924e9a9864'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == snapshot
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_bytes((json.dumps(data, indent=2, allow_nan=False) + '\n').encode())


result = json.loads((selected / (args.mode + '-result.json')).read_text())
summary = json.loads((evidence / 'summary.json').read_text())
manifest = json.loads((evidence / 'manifest.json').read_text())
aa = json.loads((evidence / ('vulkan-' + args.mode + '-aa.json')).read_text())
assert result['verdict'] == 'PASS', result['verdict']
assert summary['qualification'] == 'QUALIFIED', summary['qualification']
assert aa['gate'] == 'PASS' and not aa['errors']
assert all(manifest[key] for key in ('artifacts_stable', 'host_stable', 'inputs_stable'))
rows = [s for w in summary['workloads'] for s in w['strata']]
assert len(rows) == 16
assert all(s['noninferiority_gate'] == 'PASS' and s['estimate']['sample_count'] in (15, 31) for s in rows)

out = root / ('archive-m1-' + args.mode + '-a41d43d5')
out.mkdir(exist_ok=False)
contract = 'bench/contracts/' + args.mode + '-vulkan-ffn-m1-p1-v1.json'
verification = subprocess.run([sys.executable, 'scripts/hyle-perf.py', 'verify',
    '--contract', contract, '--manifest', str(evidence / 'manifest.json')], cwd=source,
    capture_output=True)
(out / 'verify.log').write_bytes(verification.stdout + verification.stderr)
assert verification.returncode == 0, verification.stdout + verification.stderr

map_root = build / 'bench/compute_route_vulkan'
if args.mode == 'graph':
    map_root = build / 'bench/graph_route_vulkan'
stem = 'hyle_' + args.mode + '_route_vulkan_bench'
placements = {}
for label, name in [('primary', stem), ('placement', stem + '_placement')]:
    path = map_root / (name + '.map')
    functions = {}
    for line in path.read_text().splitlines():
        if not re.match(r'^0x[0-9A-Fa-f]+\s', line):
            continue
        for key, symbol in [('submit_locked', 'detail13submit_locked'),
                            ('observe', 'detail12_GLOBAL__N_17observe')]:
            if symbol in line and 'l_switch.table' not in line:
                parts = line.split()
                assert key not in functions, line
                functions[key] = {'address': parts[0], 'size': parts[1], 'line': line}
    assert set(functions) == {'submit_locked', 'observe'}, functions
    placements[label] = {'map_sha256': sha(path), 'functions': functions}
delta = {}
for key in ('submit_locked', 'observe'):
    a, b = [placements[label]['functions'][key] for label in ('primary', 'placement')]
    assert a['size'] == b['size'], (a, b)
    delta[key] = int(b['address'], 16) - int(a['address'], 16)
    assert delta[key] != 0
write(out / 'placement-review.json', {'placements': placements, 'function_address_delta_bytes': delta,
    'scope': 'Existing cold prefix moves actual hot functions; unchanged function sizes; no LTO or hot padding.'})

reference = build / 'bench/compute_route_vulkan/reference-shaders'
assert sha(reference / 'identity.json') == aa['identity']['reference']['manifest']
assert sha(reference / 'reference_spirv.h') == aa['identity']['reference']['compiled_header']
files = {'p1/' + p.relative_to(evidence).as_posix(): p for p in evidence.rglob('*') if p.is_file()}
for name in (args.mode + '-result.json', args.mode + '-run.log', args.mode + '-p1-card.json', 'context.json'):
    files['selector/' + name] = selected / name
for gate in result['selected_gates']:
    receipt = Path(gate['receipt'])
    for p in receipt.parent.glob(receipt.stem + '*'):
        if p.is_file():
            files['selector/receipts/' + p.name] = p
for path in map_root.glob('*.map'):
    files['maps/' + path.name] = path
for path in reference.iterdir():
    if path.is_file():
        files['reference-shaders/' + path.name] = path
for name in ('CMakeCache.txt', 'compile_commands.json'):
    if (build / name).is_file():
        files['build/' + name] = build / name
for name in ('run-air-p1-vulkan-v3.py', 'prepare-air-p1-vulkan-v3.py', 'archive-air-p1.py'):
    files['controller/' + name] = root / name
for name in ('verify.log', 'placement-review.json'):
    files['review/' + name] = out / name
entries = {name: {'source': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
           for name, path in sorted(files.items())}
with zipfile.ZipFile(out / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.writestr('archive-manifest.json', json.dumps(entries, indent=2) + '\n')
with zipfile.ZipFile(out / 'raw.zip') as z:
    for name, record in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == record['sha256'], name

headlines = []
for workload in summary['workloads']:
    ratios = [s['estimate']['median_advantage_ratio'] for s in workload['strata']]
    directions = ['WIN' if s['estimate']['confidence_interval'][0] > 1 else
                  'LOSS' if s['estimate']['confidence_interval'][1] < 1 else 'INCONCLUSIVE'
                  for s in workload['strata']]
    headlines.append({'workload': workload['id'], 'ni_gate': workload['combined_noninferiority_gate'],
        'median_advantage_ratio_range': [min(ratios), max(ratios)], 'strict_directions': directions,
        'sample_counts': sorted(set(s['estimate']['sample_count'] for s in workload['strata']))})
identity = {'product_candidate': '8e45b10423686a0753aaa9d461c4ef3b117412c5',
    'measurement_snapshot': snapshot, 'profile': 'M1-MAC engineering; Air Mac16,12 / Apple M4 / MoltenVK / strict F32',
    'qualification': summary['qualification'], 'workloads': headlines,
    'contract_sha256': summary['contract_sha256'], 'summary_sha256': sha(evidence / 'summary.json'),
    'archive': {'file': 'raw.zip', 'sha256': sha(out / 'raw.zip'), 'bytes': (out / 'raw.zip').stat().st_size,
                'entries': len(entries), 'per_entry_integrity': 'PASS'},
    'reference_identity_matches_qualified_aa': True, 'placement_review': 'placement-review.json',
    'skipped_gates': len(result['skipped_gates'])}
write(out / 'identity.json', identity)
(out / 'summary.json').write_bytes((evidence / 'summary.json').read_bytes())
print(json.dumps(identity, indent=2), flush=True)
