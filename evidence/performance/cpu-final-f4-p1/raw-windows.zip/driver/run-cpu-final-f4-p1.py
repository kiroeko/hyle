exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
os.environ.update(env)
os.environ['HYLE_CPU_BESTOF_PAIR_FILE']=str(repo/'bench/compute_provider_native/cpu_best_of_p1/p1-qualified-pairs.txt')
os.environ.pop('HYLE_CPU_BESTOF_AA',None)
for name in ('HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST'):os.environ.pop(name,None)
original_popen=subprocess.Popen
class HiddenPopen(original_popen):
    def __init__(self,*args,**kwargs):
        kwargs['creationflags']=kwargs.get('creationflags',0)|subprocess.CREATE_NO_WINDOW
        super().__init__(*args,**kwargs)
subprocess.Popen=HiddenPopen
import sys,traceback
sys.path.insert(0,str(repo/'scripts'));sys.stdout.reconfigure(encoding='utf-8',errors='replace')
from hyle_perf.runner import run_contract
log=repo/'.scratch/validation/cpu-final-f4/p1-driver.log'
try:
    with log.open('w',encoding='utf-8',buffering=1) as stream:
        with __import__('contextlib').redirect_stdout(stream),__import__('contextlib').redirect_stderr(stream):
            result=run_contract(source=repo/'bench/compute_provider_native/cpu_best_of_p1',contract_path=repo/'bench/compute_provider_native/cpu_best_of_p1/contract.json',machine_id='W1-WIN',peer_paths={'current-cpu-programs':Path('C:/hv/cpu-final-peer-560eb1d')},build=Path('C:/hv/cpu-final-f4-p1-derived-role'),output=repo/'.scratch/validation/cpu-final-f4/p1-windows-derived-role',mode='qualify-platform')
            print({k:result[k] for k in ('manifest_path','qualification_gate','performance_gate')},flush=True)
    print(log.read_text(encoding='utf-8')[-5000:],flush=True)
except Exception:
    with log.open('a',encoding='utf-8') as stream:traceback.print_exc(file=stream)
    print(log.read_text(encoding='utf-8')[-6000:],flush=True)
    raise
