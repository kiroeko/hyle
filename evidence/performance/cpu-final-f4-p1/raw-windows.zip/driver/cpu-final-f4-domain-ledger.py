"""Summarize fixed admission evidence; no timing or product selection."""
import collections
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
with zipfile.ZipFile(ROOT / 'evidence/correctness/cpu-final-f4/windows-named-provider-preflight.zip') as archive:
    admissions = json.loads(archive.read('probe-windows-four/admissions.json'))
cases = collections.defaultdict(dict)
for row in admissions:
    if row['result'] == 'ACCEPTED':
        cases[row['id']][row['provider']] = row
families = collections.defaultdict(list)
for case, carriers in cases.items():
    families[case.split('-t')[0].split('-r')[0]].append((case, carriers))
result = []
for family, points in sorted(families.items()):
    own = [(case, carriers) for case, carriers in points if 'native' in carriers]
    mature = [(case, carriers) for case, carriers in own if set(carriers) - {'native'}]
    result.append({
        'family': family,
        'requests': len(points),
        'native_admitted': len(own),
        'native_with_mature_math_candidate': len(mature),
        'native_only_requests': [case for case, carriers in own if len(carriers) == 1],
        'mature_admission': dict(collections.Counter(provider for _, carriers in points
                                                   for provider in carriers if provider != 'native')),
        'limits': 'Admission/math overlap only. Strict resources and full graph regions need their own ledger.',
    })
target = ROOT / '.scratch/validation/cpu-final-f4/admission-family-ledger.json'
target.write_text(json.dumps({'scope': 'read-only fixed Windows preflight, not retirement or WIN',
                              'families': result}, indent=2) + '\n', encoding='utf-8')
for row in result:
    print(f"{row['family']}: native={row['native_admitted']} mature_overlap={row['native_with_mature_math_candidate']} mature={row['mature_admission']}")
