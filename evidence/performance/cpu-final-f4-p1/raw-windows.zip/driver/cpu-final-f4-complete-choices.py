"""Finite dominance ledger over exactly qualified same-request comparisons."""
import collections
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
out = ROOT / '.scratch/validation/cpu-final-f4'
report = json.loads((out / 'p1-pair-verdicts.json').read_text(encoding='utf-8'))
with zipfile.ZipFile(ROOT / 'evidence/correctness/cpu-final-f4/windows-named-provider-preflight.zip') as archive:
    admissions = json.loads(archive.read('probe-windows-four/admissions.json'))
candidates = collections.defaultdict(set)
for row in admissions:
    if row['result'] == 'ACCEPTED':
        candidates[row['id']].add(row['provider'])
edges = collections.defaultdict(lambda: collections.defaultdict(set))
pair_evidence = collections.defaultdict(list)
for row in report['pairs']:
    pair_evidence[row['request']].append(row['id'])
    if report['qualification_gate'] != 'PASS':
        continue
    if row['exact'] == 'WIN':
        edges[row['request']][row['candidate']].add(row['peer'])
    elif row['exact'] == 'LOSE':
        edges[row['request']][row['peer']].add(row['candidate'])

rows = []
for request, providers in sorted(candidates.items()):
    dominators = []
    for provider in providers:
        reached = set()
        pending = list(edges[request][provider])
        while pending:
            other = pending.pop()
            if other in reached:
                continue
            reached.add(other)
            pending.extend(edges[request][other] - reached)
        if provider not in reached and reached == providers - {provider} and len(providers) > 1:
            dominators.append(provider)
    rows.append({'request': request, 'candidates': sorted(providers),
                 'complete_qualified_dominators': sorted(dominators),
                 'pair_evidence': pair_evidence[request],
                 'status': 'SINGLE_CARRIER' if len(providers) == 1 else
                           'COMPLETE_QUALIFIED_CHOICE' if len(dominators) == 1 else
                           'ENGINEERING_DEFAULT_REQUIRED'})
result = {'scope': 'Exact Windows leaf requests only; paths must consist entirely of qualified same-request wins.',
          'counts': dict(collections.Counter(row['status'] for row in rows)), 'requests': rows}
(out / 'complete-provider-choices.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result['counts']))
for row in rows:
    if row['complete_qualified_dominators']:
        print(row['request'], row['complete_qualified_dominators'], row['candidates'])
