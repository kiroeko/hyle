"""Read only completed unified evidence and preserve qualified/unknown verdicts."""
import collections
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
folder = ROOT / '.scratch/validation/cpu-final-f4/p1-windows-derived-role'
manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
summary = json.loads((folder / 'summary.json').read_text(encoding='utf-8'))
controls = json.loads((folder / 'controls.json').read_text(encoding='utf-8'))
rows = []
for workload in summary['workloads']:
    # Frozen workload IDs are identical to pair IDs; do not infer untested candidates.
    pair_id = workload['id']
    left_part, right = pair_id.rsplit('-vs-', 1)
    case, left = left_part.rsplit('-', 1)
    rows.append({
        'id': pair_id,
        'request': case,
        'candidate': left,
        'peer': right,
        'qualification': summary['qualification'],
        'exact': workload['combined_exact_verdict'],
        'noninferiority': workload['combined_noninferiority_gate'],
        'ratios': [stratum['estimate']['median_advantage_ratio'] for stratum in workload['strata']],
        'intervals': [stratum['estimate']['confidence_interval'] for stratum in workload['strata']],
    })
gates = {row['noninferiority'] for row in rows}
performance_gate = ('INCONCLUSIVE' if manifest['qualification'] != 'QUALIFIED'
                    else 'FAIL' if 'FAIL' in gates
                    else 'PASS' if gates == {'PASS'} else 'INCONCLUSIVE')
report = {
    'qualification': manifest['qualification'],
    'qualification_gate': 'PASS' if manifest['qualification'] == 'QUALIFIED' else 'FAIL',
    'performance_gate': performance_gate,
    'controls': [{key: row[key] for key in ('id', 'gate')} for row in controls],
    'exact_counts': dict(collections.Counter(row['exact'] for row in rows)),
    'noninferiority_counts': dict(collections.Counter(row['noninferiority'] for row in rows)),
    'pairs': rows,
    'limits': 'Per-request qualified leaf comparisons only; no full-region or unmeasured-platform claim.',
}
output = folder.parent / 'p1-pair-verdicts.json'
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in report.items() if key != 'pairs'}, indent=2))
for row in rows:
    print(row['id'], row['exact'], '/'.join(f'{value:.3f}' for value in row['ratios']))
