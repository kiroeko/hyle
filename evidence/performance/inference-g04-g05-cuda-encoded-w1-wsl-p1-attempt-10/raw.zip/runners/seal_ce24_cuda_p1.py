from pathlib import Path
import hashlib,json,sys,zipfile
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=sys.argv[1];RUN=BASE/'cuda-encoded-p1'/attempt
launch=json.loads((RUN/'launch.json').read_text());job=json.loads((RUN/'job.json').read_text())
assert launch['state']=='TERMINAL' and launch['actual_job']==job
assert job['state'] in ('TERMINAL','TERMINAL_SETUP_FAIL')
snapshot=json.loads((RUN/'snapshot.json').read_text());assert job['snapshot']==snapshot
numeric=ROOT/'evidence/correctness/inference-g04-g05-cuda-ce24-packed-math-numeric-rebind/receipt.json'
assert hashlib.sha256(numeric.read_bytes()).hexdigest()==snapshot['numeric_receipt_sha256']
contract=ROOT/'bench/inference_resident_sdpa/cuda_encoded_p1/contract.json'
assert hashlib.sha256(contract.read_bytes()).hexdigest()==snapshot['contract_file_sha256']
declared=json.loads(contract.read_text());assert declared['experiment']['sample_schedule']==[15,31]
out=RUN/'output'
def read(name):
 p=out/name;return json.loads(p.read_text()) if p.is_file() else None
summary=read('summary.json');manifest=read('manifest.json');aa=read('cuda-encoded-aa.json')
qualified=bool(summary and summary['qualification']=='QUALIFIED')
products=list((out/'raw').rglob('product-*.log'));controls=list((out/'raw').rglob('control-*.log'))
stages=[];rows=[]
if qualified:
 assert job['verify_exit']==0 and manifest and aa and aa['gate']=='PASS' and len(aa['runs'])==16
 stages=manifest['extensions']['sample_stages'];index=read('raw-log-index.json')
 assert stages==declared['experiment']['sample_schedule'][:len(stages)] and stages
 assert index['sample_stages']==stages
 assert len(products)==8*sum(stages) and len(controls)==2*sum(stages)
 assert len(products)==sum(x['kind']=='product' for x in index['entries'])
 assert len(controls)==sum(x['kind']=='control' for x in index['entries'])
 for w in summary['workloads']:
  ratios=[s['estimate']['median_advantage_ratio'] for s in w['strata']]
  cis=[s['estimate']['confidence_interval'] for s in w['strata']]
  rows.append({'id':w['id'],'ratio_range':[min(ratios),max(ratios)],'noninferiority':w['combined_noninferiority_gate'],
   'exact':w['combined_exact_verdict'],'direction':'WIN' if all(c[0]>1 for c in cis) else 'LOSS' if all(c[1]<1 for c in cis) else 'INCONCLUSIVE'})
 assert len(rows)==3
passed=qualified and job.get('exit_code')==0 and all(r['noninferiority']=='PASS' for r in rows)
dest=ROOT/('evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-'+attempt);dest.mkdir(exist_ok=False)
for name in ('summary.json','manifest.json','observations.jsonl','raw-log-index.json'):
 p=out/name
 if p.is_file():(dest/name).write_bytes(p.read_bytes())
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for p in sorted(RUN.rglob('*')):
  if p.is_file():package.write(p,p.relative_to(RUN).as_posix())
 for name in ('launch_ce24_cuda_p1.py','ce24_cuda_p1_wsl.py','seal_ce24_cuda_p1.py'):
  package.write(BASE/name,'runners/'+name)
 package.write(contract,'contract.json')
receipt={'kind':'G04_G05_CUDA_CE24_PACKED_MATH_BUDGET_NATIVE_FINITE_P1','attempt':attempt,
 'product_candidate':snapshot['product_candidate'],'performance_source':snapshot['source_commit'],
 'qualification':summary['qualification'] if summary else 'NO_SUMMARY',
 'performance':'PASS' if passed else 'FAIL' if qualified else 'UNPROVEN','rows':rows,
 'aa_processes':len(aa['runs']) if aa else 0,'aa_verdict':aa['gate'] if aa else 'NO_RECEIPT',
 'sample_stages':stages,'product_processes':len(products),'control_processes':len(controls),
 'job':job,'launch':launch,'verify_exit':job.get('verify_exit'),
 'measured_worker_seconds':job['elapsed_seconds'],'observer_seconds_overlaps':launch['elapsed_seconds'],
 'limits':['Actual W1-WSL SM89 engineering only; no nativeLinux/Formal','Resident warm immutable history plus explicit cold BF16 snapshot/extra memory; not direct original FP8/besthost',
  'No producer/growth/G06/capture/token-s/whole G04-G05 verdict','Actual CE24 static SDK; product candidate6e57 and sync-fixed native reference with two explicit output barriers','Private native pool upper remains UNKNOWN'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'performance':receipt['performance'],'path':str(dest)}))
