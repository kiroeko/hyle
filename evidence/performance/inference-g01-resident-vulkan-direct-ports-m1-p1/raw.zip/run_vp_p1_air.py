from pathlib import Path
import subprocess, os, time, json
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'g01-vp-git-checkout'
build=base/'g01-p1-fresh-build-4';output=base/'g01-p1-qualification-4'
assert not build.exists() and not output.exists(),'prior runs must be retained; do not reset or overwrite'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
args=['/usr/bin/python3',str(source/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(source/'bench/inference_resident_sdpa/contract.json'),'--source',str(source/'bench/inference_resident_sdpa'),'--machine','M1-MAC','--peer','original-ggml-flash='+str(base/'g01-original-ggml-peer'),'--build',str(build),'--output',str(output)]
log=base/'g01-p1-qualification-4.log';started=time.monotonic()
with log.open('w') as f:
 process=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 status={'pid':process.pid,'args':args,'log':str(log),'state':'RUNNING','candidate':'3d92eee97a70f7788dfb9bbcda73f6e0f801959f'}
 (base/'g01-p1-job-4.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
 result=process.wait()
status.update(state='TERMINAL',exit_code=result,elapsed_seconds=time.monotonic()-started)
(base/'g01-p1-job-4.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1800));print(f.read(1800).decode(errors='replace'))
raise SystemExit(result)
