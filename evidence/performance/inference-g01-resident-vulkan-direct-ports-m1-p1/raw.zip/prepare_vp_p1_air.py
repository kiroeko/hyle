from pathlib import Path
import subprocess, json, sys
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'g01-vp-git-checkout'
candidate='3d92eee97a70f7788dfb9bbcda73f6e0f801959f'
if not source.exists():
 subprocess.run(['git','clone','--shared',str(base/'g01-rr-git-checkout'),str(source)],check=True,capture_output=True)
subprocess.run(['git','-C',str(source),'fetch',str(base/'p1-hyle-ports.bundle'),'refs/heads/main'],check=True,capture_output=True)
subprocess.run(['git','-C',str(source),'checkout','--detach',candidate],check=True,capture_output=True)
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
sys.path.insert(0,str(source/'scripts'))
from hyle_perf.contract import load_contract,canonical_sha256
hash_value=canonical_sha256(load_contract(source/'bench/inference_resident_sdpa/contract.json'))
assert hash_value=='4ae724d684be30814e2f28d7d933f771b7e03dda56b86cb51464cef706031720'
print(json.dumps({'candidate':candidate,'source':str(source),'contract_sha256':hash_value,'old_runs_unchanged':True}))
