from pathlib import Path
import ctypes, subprocess, sys, time
ctypes.windll.kernel32.SetErrorMode(0x8003)
root=Path('C:/hyle-scratch/r4-cuda-20260916/mature-rule')
mode=sys.argv[1]
assert mode in ('compute','graph')
with (root / ('native-cost-' + mode + '-console.log')).open('w', encoding='utf-8') as log:
 child=subprocess.Popen([sys.executable,str(root/'native-cost-diagnostic.py'),'--mode',mode,'--build','C:/hv4s2'],stdout=log,stderr=subprocess.STDOUT)
 try:
  result=child.wait(timeout=600)
 except subprocess.TimeoutExpired:
  # This exact PID is our own diagnostic process; preserve all partial raw logs.
  subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],check=False,capture_output=True)
  raise RuntimeError('One 600-second diagnostic budget exhausted; no retry or escalation')
print((root/('native-cost-'+mode+'-console.log')).read_text(encoding='utf-8')[-14000:])
raise SystemExit(result)
