"""One R4 boundary-cost diagnostic using existing collector/statistics APIs.

NATURAL_ROUTE only: no same-contract ranking, NI gate or sample escalation.
The containing process has a finite external deadline; all raw logs survive.
"""
from pathlib import Path
import argparse
import ctypes
import hashlib
import importlib.util
import json
import statistics
import subprocess
import sys
import time

ROOT = Path('C:/public/project-hyle/hyle')
TASK = Path('C:/hyle-scratch/r4-cuda-20260916/mature-rule')
EXPECTED = 'f01e92379048b920b2545fa228921ef95038d5b3'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_perf import runner, stats
from hyle_perf.machine import (load_registry, get_machine_profile, probe_machine,
                               evaluate_machine_profile, expected_child_policy)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n',
                    encoding='utf-8', newline='\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('compute', 'graph'), required=True)
    parser.add_argument('--build', type=Path, required=True)
    args = parser.parse_args()
    ctypes.windll.kernel32.SetErrorMode(0x8003)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == EXPECTED
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    output = TASK / ('native-cost-' + args.mode)
    output.mkdir(exist_ok=False)
    raw = output / 'raw'
    raw.mkdir()
    contract = json.loads((ROOT / f'bench/contracts/{args.mode}-cuda-ffn-p1-v3.json').read_text())
    contract['id'] = f'{args.mode}-cuda-final-native-boundary-diagnostic'
    contract['claim'] = 'NATURAL_ROUTE, NOT_COMPARABLE: complete public boundary versus one raw native terminal event; no NI, parity or algorithm-winner claim.'
    contract['strata'] = [s for s in contract['strata'] if s['target_variant'] == 'primary']
    ids = [s['id'] for s in contract['strata']]
    contract['controls'] = []
    contract['experiment']['sample_schedule'] = [15]
    contract['peers'] = [{'id': 'raw-native', 'revision': EXPECTED,
                          'configuration': {'role': 'Same frozen CUDA implementations with one caller-owned native terminal event.'}}]
    for w in contract['workloads']:
        w['pair']['peer'] = w['pair']['peer'].replace('SGLang precise ', 'Raw native ')
        w['required_strata'] = ids
        w['required_controls'] = []
        w['comparability'] = 'NOT_COMPARABLE'
        w['gate_role'] = 'diagnostic'
        w['peer_id'] = 'raw-native'
        w['ownership_topology']['peer'] = 'Caller-owned native stream, two workspaces and immutable weights; one final event. No public admission, retained owner or failure-slot services.'
        w['ownership_topology']['equivalence'] = 'Same math, shapes, storage and changed inputs; deliberately different public completion/lifetime services.'
    extension = contract['extensions']['runner']
    extension['validators'] = []
    extension.pop('control_executable', None)
    extension['executables'] = [e for e in extension['executables'] if e['target_variant'] == 'primary']
    executable = extension['executables'][0]
    executable['id'] = args.mode + '-cuda-native-boundary'
    executable['stem'] = f'hyle_{args.mode}_cuda_native_cost_bench'
    executable['target'] = executable['stem']
    # This is the immutable diagnostic input to the ordinary collection API,
    # not an attempted standalone P1 qualification contract.
    write(output / 'diagnostic-input.json', contract)
    target = args.build / 'bin' / (executable['stem'] + '.exe')
    profile = get_machine_profile(load_registry(), 'W1-WIN')
    probe = probe_machine(paths=[('build', args.build)])
    gate = evaluate_machine_profile(profile, probe, role='engineering',
                                    sampling_topology='native-runtime-pair')
    assert gate['gate'] == 'PASS', gate
    policy = expected_child_policy(profile, probe=probe, sampling_topology='native-runtime-pair')
    spec = importlib.util.spec_from_file_location('r4_aa', ROOT / 'bench/compute_route_cuda/validate_aa.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    before = module.gpu_facts()
    ready = args.build / 'bin' / f'hyle_cuda_{args.mode}_aa.ready'
    assert ready.read_text().split()[0] == 'PASS'
    identity = {'candidate': EXPECTED, 'tree': subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT).decode().strip(),
                'executable': str(target), 'executable_sha256': sha(target),
                'script_sha256': sha(Path(__file__)), 'input_sha256': sha(output / 'diagnostic-input.json'),
                'CMakeCache_sha256': sha(args.build / 'CMakeCache.txt'),
                'runtime': {p.name: sha(p) for p in sorted((args.build/'bin').glob('*.dll'))},
                'profile': profile, 'probe': probe, 'machine_gate': gate,
                'policy': policy, 'gpu_before': before,
                'classification': 'NATURAL_ROUTE / NOT_COMPARABLE',
                'sample_budget': 'four order strata x 15 processes; two shapes/process; no escalation'}
    write(output / 'identity.json', identity)
    # Actual full-chain double oracle is mandatory before interpreting cost.
    env = runner._child_environment(extension['controlled_environment'],
                                    {'HYLE_BENCH_VERIFY_ONLY': '1'}, profile, policy)
    with runner._apply_sampling_policy(policy):
        oracle = subprocess.run([str(target)], env=env, capture_output=True,
                                creationflags=runner._creation_flags(policy), timeout=240)
    (output / 'oracle.log').write_bytes(oracle.stdout + oracle.stderr)
    assert oracle.returncode == 0, oracle.returncode
    start = time.monotonic()
    with runner._apply_sampling_policy(policy):
        observations, paths = runner._collect_product_observations(
            contract, extension, {executable['id']: target}, profile, policy,
            runs=15, creationflags=runner._creation_flags(policy), raw_directory=raw)
    write(output / 'observations.json', [o.to_dict() for o in observations])
    summaries = []
    for w in contract['workloads']:
        for stratum in ids:
            points = [o for o in observations if o.workload_id == w['id'] and o.stratum_id == stratum]
            assert len(points) == 15
            summaries.append({'workload': w['id'], 'stratum': stratum,
                'ratio': stats.process_median_estimate(o.advantage_ratio for o in points).to_dict(),
                'public_median_us': statistics.median(1e6 / o.candidate_value for o in points),
                'native_median_us': statistics.median(1e6 / o.peer_value for o in points),
                'paired_extra_median_us': statistics.median(1e6/o.candidate_value - 1e6/o.peer_value for o in points)})
    after = module.gpu_facts()
    write(output / 'summary.json', {'collection': 'PASS', 'classification': 'NATURAL_ROUTE / NOT_COMPARABLE',
         'ranking': None, 'noninferiority_gate': None, 'sample_escalation': False,
         'wall_seconds': time.monotonic() - start, 'gpu_after': after, 'strata': summaries,
         'raw_sha256': {p.name: sha(p) for p in paths}})
    print(json.dumps({'mode': args.mode, 'collection': 'PASS', 'processes': len(paths), 'strata': summaries}), flush=True)


if __name__ == '__main__':
    main()
