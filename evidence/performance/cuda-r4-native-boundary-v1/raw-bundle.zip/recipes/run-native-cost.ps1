param([ValidateSet('compute','graph')][string]$Mode)
$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
python C:/hyle-scratch/r4-cuda-20260916/mature-rule/cost-deadline.py $Mode
exit $LASTEXITCODE
