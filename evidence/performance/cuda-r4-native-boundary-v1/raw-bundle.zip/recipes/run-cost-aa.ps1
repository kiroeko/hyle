param([ValidateSet('compute','graph')][string]$Mode)
$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
if ((git rev-parse HEAD) -ne 'f01e92379048b920b2545fa228921ef95038d5b3') { throw 'Immutable input checkout changed' }
python bench/compute_route_cuda/validate_aa.py --build C:/hv4s2 --output "C:/hyle-scratch/r4-cuda-20260916/mature-rule/native-cost-$Mode-aa" --mode $Mode
if ($LASTEXITCODE -ne 0) { throw 'native-cost build AA failed; do not time' }
