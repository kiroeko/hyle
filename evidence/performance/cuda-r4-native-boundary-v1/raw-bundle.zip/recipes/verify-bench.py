import ctypes
import json
import os
from pathlib import Path
import subprocess
import time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path('C:/hyle-scratch/r4-cuda-20260916/mature-rule/bench')
environment = dict(os.environ, HYLE_BENCH_VERIFY_ONLY='1', HYLE_PERF_CALLER_CPU='2')
results = []
for name in ('hyle_compute_route_cuda_bench', 'hyle_graph_route_cuda_bench'):
    start = time.monotonic()
    with (root / (name + '-oracle.log')).open('w', encoding='utf-8', newline='\n') as log:
        result = subprocess.run(['C:/hv4s2/bin/' + name + '.exe'], env=environment,
                                stdout=log, stderr=subprocess.STDOUT, timeout=240)
    results.append(dict(executable=name, exit_code=result.returncode,
                        wall_seconds=time.monotonic() - start, performance_claim=False))
    (root / 'oracle-result.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print((root / (name + '-oracle.log')).read_text(encoding='utf-8')[-3000:])
        raise SystemExit(result.returncode)
