from pathlib import Path
import hashlib, json, shutil, subprocess
root=Path(__file__).parent
build=Path('C:/hv4s2')
targets=['hyle_compute_route_cuda_bench','hyle_compute_route_cuda_bench_placement',
         'hyle_graph_route_cuda_bench','hyle_graph_route_cuda_bench_placement',
         'hyle_compute_cuda_native_cost_bench','hyle_graph_cuda_native_cost_bench']
def hashes():
    return {t:hashlib.sha256((build/'bin'/(t+'.exe')).read_bytes()).hexdigest() for t in targets}
before=hashes()
shutil.copy2(root/'logs/native-cost-compute-aa-console.log',root/'bench/aa-missing-peer.log')
with (root/'bench/peer-path-configure.log').open('w') as log:
    subprocess.run(['cmake','-S','C:/public/project-hyle/hyle','-B',str(build),
                    '-DHYLE_CUDA_SGLANG_SOURCE_DIR:PATH=C:/public/project-hyle/sglang'],stdout=log,stderr=subprocess.STDOUT,check=True)
with (root/'bench/peer-path-build.log').open('w') as log:
    subprocess.run(['cmake','--build',str(build),'--parallel','2','--target',*targets],stdout=log,stderr=subprocess.STDOUT,check=True)
after=hashes()
assert before==after, 'Metadata-only reconfigure unexpectedly changed executables'
(root/'bench/peer-path-correction.json').write_text(json.dumps({'reason':'AA rejected missing pinned-peer cache path before any sampling',
    'product_or_benchmark_source_changed':False,'executables_unchanged':True,'before':before,'after':after},indent=2)+'\n',encoding='utf-8')
print('Pinned peer path recorded; all six executable hashes unchanged; no timing samples discarded.')
