from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path('C:/public/project-hyle/hyle')
scratch = Path('C:/hyle-scratch/r6-vulkan-20260917')
selected = scratch / 'selected-w1-v2'
node = selected / 'graph/305895ce49352b4cc9bb'
evidence = node / 'p1-evidence'
build = node / 'p1-build'
out = root / 'evidence/performance/vulkan-r6-w1-graph-8e45b104'
out.mkdir(parents=True, exist_ok=True)
assert not (out / 'raw.zip').exists()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

result = json.loads((selected / 'graph-result.json').read_text())
summary = json.loads((evidence / 'summary.json').read_text())
manifest = json.loads((evidence / 'manifest.json').read_text())
assert result['verdict'] == 'PASS'
assert summary['qualification'] == 'QUALIFIED'
assert all(manifest[x] for x in ('artifacts_stable', 'host_stable', 'inputs_stable'))
rows = [s for w in summary['workloads'] for s in w['strata']]
assert len(rows) == 16
assert all(s['noninferiority_gate'] == 'PASS' and s['estimate']['sample_count'] == 15 for s in rows)
verification = subprocess.run(['python', 'scripts/hyle-perf.py', 'verify', '--contract',
    'bench/contracts/graph-vulkan-ffn-w1-p1-v1.json', '--manifest', str(evidence / 'manifest.json')],
    cwd=scratch / 'candidate-8e45b104', capture_output=True, check=True)
(scratch / 'w1-graph-p1-verify.log').write_bytes(verification.stdout + verification.stderr)
files = {f'p1/{p.relative_to(evidence).as_posix()}': p for p in evidence.rglob('*') if p.is_file()}
for name in ('graph-result.json', 'graph-run.log', 'graph-p1-card.json', 'context.json'):
    files['selector/' + name] = selected / name
for gate in result['selected_gates']:
    receipt = Path(gate['receipt'])
    for p in receipt.parent.glob(receipt.stem + '*'):
        if p.is_file():
            files['selector/receipts/' + p.name] = p
for name in ('run-windows-p1-v2.ps1', 'w1-graph-placement-review.json',
             'w1-graph-p1-verify.log', 'loc-87a2da74.json', 'archive-w1-graph-p1.py'):
    files['controller/' + name] = scratch / name
for p in (build / 'bench/graph_route_vulkan').glob('*.map'):
    files['maps/' + p.name] = p
files['build/CMakeCache.txt'] = build / 'CMakeCache.txt'
for p in (build / 'bench/graph_route_vulkan').rglob('*manifest*.json'):
    files['build/' + p.relative_to(build).as_posix()] = p
entries = {name: {'source': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
           for name, p in sorted(files.items())}
with zipfile.ZipFile(out / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, p in sorted(files.items()):
        z.write(p, name)
    z.writestr('archive-manifest.json', json.dumps(entries, indent=2) + '\n')
with zipfile.ZipFile(out / 'raw.zip') as z:
    for name, record in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == record['sha256'], name
headline = []
for w in summary['workloads']:
    ratios = [s['estimate']['median_advantage_ratio'] for s in w['strata']]
    directions = ['WIN' if s['estimate']['confidence_interval'][0] > 1 else
                  'LOSS' if s['estimate']['confidence_interval'][1] < 1 else 'INCONCLUSIVE'
                  for s in w['strata']]
    headline.append({'workload': w['id'], 'ni_gate': w['combined_noninferiority_gate'],
        'median_advantage_ratio_range': [min(ratios), max(ratios)], 'strict_directions': directions})
identity = {'product_candidate': '8e45b10423686a0753aaa9d461c4ef3b117412c5',
    'measurement_snapshot': '3894b72e3b4fbbda9457e2c31730e48bd0d43c49',
    'profile': 'W1-WIN engineering, RTX 4070 / strict F32',
    'verdict': 'PASS; two workloads, 16 NI gates at the original 5%, n15; strict directions recorded per stratum',
    'qualification': summary['qualification'], 'workloads': headline,
    'contract_sha256': summary['contract_sha256'], 'summary_sha256': sha(evidence / 'summary.json'),
    'archive': {'path': 'raw.zip', 'sha256': sha(out / 'raw.zip'), 'bytes': (out / 'raw.zip').stat().st_size,
                'entries': len(entries), 'per_entry_integrity': 'PASS'},
    'skipped_gates': len(result['skipped_gates']),
    'remaining': ['Air Direct and Graph P1', 'natural boundary diagnostics',
                  'final delivery/selector and route review']}
(out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
(out / 'summary.json').write_bytes((evidence / 'summary.json').read_bytes())
print(json.dumps(identity, indent=2))
