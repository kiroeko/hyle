param([ValidateSet('compute','graph')][string]$Mode = 'compute')
$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:PATH = 'C:/public/tools/glslang;' + $env:PATH
$env:HYLE_DEP_SOURCE_CACHE = 'C:/public/project-hyle/.deps'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_PARALLEL_LEVEL = '1'
$env:VK_LOADER_LAYERS_DISABLE = '~implicit~'
$r6Source = 'C:/hyle-scratch/r6-vulkan-20260917/candidate-8e45b104'
$r6Selected = 'C:/hyle-scratch/r6-vulkan-20260917/selected-w1-v2'
Set-Location -LiteralPath $r6Source
if (Test-Path -LiteralPath "$r6Selected/$Mode-run.log") { throw 'A finite attempt already exists; inspect before any retry' }
python scripts/validation-select.py run --base e4085366 --candidate 3894b72e3b4fbbda9457e2c31730e48bd0d43c49 `
  --context "$r6Selected/context.json" --p1-card "$r6Selected/$Mode-p1-card.json" `
  --scratch "$r6Selected/$Mode" --cache "C:/hyle-scratch/r6-vulkan-20260917/selected-w1/receipts" `
  --output "$r6Selected/$Mode-result.json" *> "$r6Selected/$Mode-run.log"
$r6Exit = $LASTEXITCODE
Get-Content "$r6Selected/$Mode-run.log" -Tail 40
exit $r6Exit
