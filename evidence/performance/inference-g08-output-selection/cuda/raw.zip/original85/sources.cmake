set(G08_ORIGINAL_SOURCES
  "${HYLE_G08_REFERENCE_DIR}/src/compute_provider_cuda/collectives_provider.cc"
  "${HYLE_G08_REFERENCE_DIR}/src/compute_provider_cuda/collectives.cu"
)
