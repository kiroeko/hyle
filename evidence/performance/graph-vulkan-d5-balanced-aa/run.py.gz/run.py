"""Single bounded A/A after the D5 input-cycle fix; not a P1 product verdict."""
from pathlib import Path
import ctypes, hashlib, importlib.util, json, math, os, re, statistics, subprocess, sys, time, uuid
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'.scratch/validation/d5-vulkan-balance'
BUILD=Path('C:/hv/d5pf/p1-vulkan-recovery')
EXE=BUILD/'hyle_graph_route_vulkan_d5_bench.exe'
ctypes.windll.kernel32.SetErrorMode(1|2|0x8000)
original_popen=subprocess.Popen
class HiddenPopen(original_popen):
    def __init__(self,*a,**kw):
        kw['creationflags']=kw.get('creationflags',0)|subprocess.CREATE_NO_WINDOW
        super().__init__(*a,**kw)
subprocess.Popen=HiddenPopen
spec=importlib.util.spec_from_file_location('d5aa',ROOT/'bench/graph_route_cpu/external/validate_aa.py')
aa=importlib.util.module_from_spec(spec);spec.loader.exec_module(aa)
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert candidate.startswith('3a2e1f01')
receipt_path=OUT/'aa-receipt.json'
assert not receipt_path.exists(),'one-shot budget already consumed'
raw=OUT/'aa-raw';raw.mkdir(exist_ok=False)
declared=json.loads((ROOT/'bench/graph_route_cpu/external/inputs.json').read_text())
source_files=declared['source_files'].copy()
for name in ('bench/graph_route_cpu/d5_common.h','bench/graph_route_vulkan/d5_fragment_bench.cc'):
    source_files[name]=aa.digest(ROOT/name,source=True)
aa.check_files(ROOT,source_files,source=True)
fixture=ROOT/'.scratch/d5-qwen35-six-profile-fixture'
aa.check_files(fixture,declared['qwen_files'])
route=declared['routes']['vulkan']
manifest=ROOT/route['sdk_manifest']
assert aa.digest(manifest,source=True)==route['sdk_manifest_sha256']
aa.check_files(Path('C:/hv/d5vk/static-relocated'),json.loads(manifest.read_text()))
profile=aa.get_machine_profile(aa.load_registry(),'W1-WIN')
probe=aa.probe_machine()
gate=aa.evaluate_machine_profile(profile,probe,role='engineering',sampling_topology='native-runtime-pair')
assert gate['gate']=='PASS',gate
policy=aa.expected_child_policy(profile,sampling_topology='native-runtime-pair',probe=probe)
identity={'candidate':candidate,'binary':aa.digest(EXE),'source_files':source_files,
          'sdk_manifest':route['sdk_manifest_sha256'],'fixture_files':declared['qwen_files'],
          'script_sha256':aa.digest(__file__)}
runs=[];start=time.monotonic()
with aa._apply_sampling_policy(policy):
    for arm in ('selected','peer'):
        for order in (0,1):
            for allocation in (0,1):
                env={k:v for k,v in os.environ.items() if k not in aa.PERF_ENVIRONMENT_BLOCKLIST and
                     not any(k.startswith(p) for p in aa.PERF_ENVIRONMENT_PREFIXES)}
                env.update(aa.PERF_ENVIRONMENT_FIXED)
                nonce=uuid.uuid4().hex
                env.update(HYLE_D5_QWEN35_FIXTURE=str(fixture),HYLE_BENCH_AA_ROUTE=arm,
                           HYLE_PERF_RUN_NONCE=nonce,HYLE_PERF_CALLER_CPU=str(policy['caller_logical_cpu']),
                           HYLE_PERF_SAMPLING_TOPOLOGY='native-runtime-pair')
                if order:env['HYLE_BENCH_RIVAL_FIRST']='1'
                if allocation:env['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'
                child=subprocess.run([str(EXE)],env=env,capture_output=True,timeout=180,
                                     creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
                data=child.stdout+child.stderr
                log=raw/f'{arm}-{order}-{allocation}.log';log.write_bytes(data)
                assert child.returncode==0,(log,child.returncode)
                text=data.decode('utf-8')
                expected={'execution_order':'peer-first' if order else 'candidate-first',
                    'allocation_order':'peer-first' if allocation else 'candidate-first',
                    'aa_route':arm,'paired_mode':'nanobench-compare','run_nonce':nonce,'verify_only':'0',
                    'affinity_topology':'native-runtime-pair','caller_cpu':str(policy['caller_logical_cpu']),
                    'affinity_ok':'1','parent_mask':policy['affinity_mask'],'priority':policy['priority']}
                aa._required_telemetry(text,[aa.PREFIX],expected)
                native=[line for line in text.splitlines() if line.startswith('# D5_VULKAN_ENV ')]
                assert len(native)==4 and set(native)=={route['native_environment']}
                records=re.findall(r'# D5_PAIRED_ROUND profile="([^"]+)" arm="([^"]+)" round=(\d+) iterations=(\d+) seconds_per_call=(\S+) paired_relative=(\S+) slots=(\d+)',text)
                assert len(records)==96,(log,len(records))
                pairs={}
                for title,name,round_,iters,seconds,relative,slots in records:
                    assert title in aa.TITLES and name in ('Graph complete fragment','Direct complete fragment')
                    assert int(iters)==6 and int(slots)==(2 if title==aa.TITLES[0] else 3)
                    assert math.isfinite(float(seconds)) and float(seconds)>0
                    key=(title,name);pairs.setdefault(key,[]).append(int(round_))
                assert len(pairs)==4 and all(v==list(range(24)) for v in pairs.values())
                rows=aa.parse_nanobench(text)
                ratios={}
                for title in aa.TITLES:
                    c,p=aa.select_pair(rows,'Graph complete fragment','Direct complete fragment',title=title)
                    ratios[title]=c.operations_per_second/p.operations_per_second
                runs.append({'arm':arm,'order':order,'allocation':allocation,'ratios':ratios,
                             'log':str(log.relative_to(ROOT)),'sha256':aa.digest(log),'round_records':len(records)})
                print(json.dumps({'completed':len(runs),'total':8,'ratios':ratios}),flush=True)
errors=[];summaries={}
for arm in ('selected','peer'):
    group=[r for r in runs if r['arm']==arm]
    for title in aa.TITLES:
        values=[r['ratios'][title] for r in group]
        medians={'all':statistics.median(values)}
        medians.update({f'{f}={l}':statistics.median(r['ratios'][title] for r in group if r[f]==l)
                        for f in ('order','allocation') for l in (0,1)})
        if any(not 1/1.10<=v<=1.10 for v in values):errors.append(arm+'/'+title+': gross >10%')
        if any(not 1/1.05<=v<=1.05 for v in medians.values()):errors.append(arm+'/'+title+': factor >5%')
        summaries[arm+'/'+title]={'ratios':values,'factor_medians':medians}
assert aa.digest(EXE)==identity['binary']
aa.check_files(ROOT,source_files,source=True)
receipt={'schema':'hyle.d5-vulkan-balanced-aa/v1','identity':identity,'policy':policy,
         'gate':'FAIL' if errors else 'PASS','formal_product_samples':0,
         'runs':runs,'summaries':summaries,'errors':errors,'seconds':time.monotonic()-start,
         'native_environment':route['native_environment'],'no_ready_marker_created':True}
receipt_path.write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps({'gate':receipt['gate'],'errors':errors,'seconds':receipt['seconds']}),flush=True)
