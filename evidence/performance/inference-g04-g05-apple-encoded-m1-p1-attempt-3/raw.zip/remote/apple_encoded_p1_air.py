from pathlib import Path
import hashlib,json,os,subprocess,sys,time

base=Path('/Users/kiro/hyle-scratch/compute-unified')
run=Path(sys.argv[1]);snapshot=json.loads((run/'snapshot.json').read_text())
source=base/f'g04-apple-encoded-p1-source-{snapshot["attempt"]}'
build=base/f'g04-apple-encoded-p1-fresh-{snapshot["attempt"]}'
out=base/f'g04-apple-encoded-p1-output-{snapshot["attempt"]}'
assert not source.exists() and not build.exists() and not out.exists()
start=time.monotonic();record={'state':'SETUP','pid':os.getpid(),'snapshot':snapshot,'source':str(source),'build':str(build),'output':str(out)}
def save():(run/'job.json').write_text(json.dumps(record,indent=2)+'\n')
save()
child=None
def failed(kind,error,traceback):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if child and child.poll() is None else 'TERMINAL_SETUP_FAIL',
  error=repr(error),elapsed_seconds=time.monotonic()-start);save()
 sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed
identity={k:subprocess.check_output(args,text=True).strip() for k,args in (
 ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version']))}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64' and '21.0.0' in identity['compiler']
record['identity']=identity;save()
assert hashlib.sha256((run/'hyle.bundle').read_bytes()).hexdigest()==snapshot['bundle_sha256']
subprocess.run(['git','clone','--shared','--no-checkout',str(base/'g04-vulkan-encoded-p1-source-1'),str(source)],check=True)
# Flatten the disposable checkout's existing alternate chain deepest-first.
# No product files or original object stores are modified. Registering deepest
# stores first prevents Git's nesting limit from hiding original tree objects.
objects=source/'.git/objects';ordered=[];visiting=set();visited=set()
def collect(directory):
 directory=directory.resolve();assert directory.is_dir()
 if directory in visited:return
 assert directory not in visiting,'Git alternate cycle'
 visiting.add(directory);listing=directory/'info/alternates'
 if listing.is_file():
  for line in listing.read_text().splitlines():
   if line.strip():collect(directory/line.strip())
 visiting.remove(directory);visited.add(directory);ordered.append(directory)
listing=objects/'info/alternates'
for line in listing.read_text().splitlines():
 if line.strip():collect(objects/line.strip())
listing.write_text(''.join(str(directory)+'\n' for directory in ordered))
record['verification_git_alternates']=[str(directory) for directory in ordered];save()
subprocess.run(['git','-C',str(source),'fetch',str(run/'hyle.bundle'),'HEAD'],check=True)
subprocess.run(['git','-C',str(source),'checkout','--detach',snapshot['source_commit']],check=True)
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
numeric=source/'evidence/correctness/inference-g04-g05-apple-encoded-page-preflight/receipt.json'
assert hashlib.sha256(numeric.read_bytes()).hexdigest()==snapshot['numeric_receipt_sha256']
assert json.loads(numeric.read_text())['verdict']=='PASS_NUMERICAL_LIFECYCLE_PREFLIGHT_ONLY'
contract=source/'bench/inference_resident_sdpa/apple_encoded_p1'
assert hashlib.sha256((contract/'contract.json').read_bytes()).hexdigest()==snapshot['contract_file_sha256']
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
command=['/usr/bin/python3',str(source/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(contract/'contract.json'),
 '--source',str(contract),'--machine','M1-MAC','--peer','original-ggml-flash='+str(base/'g01-original-ggml-peer'),
 '--build',str(build),'--output',str(out)]
with (run/'qualification.log').open('w') as stream:
 child=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
 record.update(state='RUNNING',pid=child.pid,observer_pid=os.getpid(),command=command,identity=identity,
  resource_policy='Heavy runs serial; original instrument parallel2 within cap4; SDK-only benchmark build')
 save()
 try:print(json.dumps(record),flush=True)
 except BrokenPipeError:pass
 code=child.wait()
record['qualification_exit_code']=code
if (out/'manifest.json').is_file():
 verify_start=time.monotonic()
 with (run/'verify.log').open('w') as stream:
  verified=subprocess.run(['/usr/bin/python3',str(source/'scripts/hyle-perf.py'),'verify',
   '--contract',str(contract/'contract.json'),'--manifest',str(out/'manifest.json')],
   env=env,stdout=stream,stderr=subprocess.STDOUT)
 record.update(verify_exit=verified.returncode,verify_elapsed_seconds=time.monotonic()-verify_start)
else:record.update(verify_exit=None,verify_limit='No manifest produced; verification not run')
record.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-start);save()
try:print(json.dumps(record),flush=True)
except BrokenPipeError:pass
raise SystemExit(code)
