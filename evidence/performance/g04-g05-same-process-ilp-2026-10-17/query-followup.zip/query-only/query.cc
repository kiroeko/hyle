#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif
#include "cuda_encoded_page_reference.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/flashinfer.h"

#include "hyle/compute/batch_execution.h"
#include "hyle/simd/dtype.h"
#include <cstring>
#include <cuda_runtime_api.h>
#include <sched.h>
#include <array>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <nvtx3/nvToolsExt.h>

namespace hyle::compute::flashinfer {
Provider provider_control() noexcept asm("g04_control__ZN4hyle7compute10flashinfer8providerEv");
Provider provider_treatment() noexcept asm("g04_treatment__ZN4hyle7compute10flashinfer8providerEv");
}
extern "C" void target_control() asm("g04_control__ZN10flashinferL34BatchPrefillWithPagedKVCacheKernelINS_12KernelTraitsILNS_8MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1ELNS_15PosEncodingModeE0E13__nv_bfloat1613__nv_fp8_e4m3ffiNS_16DefaultAttentionILb0ELb1ELb0ELb0EEEEEN4hyle7compute10flashinfer6native48_GLOBAL__N__ca0ae4f1_15_native_cache_cu_95f5a4b011MergeParamsINS_23BatchPrefillPagedParamsIS4_S5_fiEES4_Lj256EEEEEvT0_");
extern "C" void target_treatment() asm("g04_treatment__ZN10flashinferL34BatchPrefillWithPagedKVCacheKernelINS_12KernelTraitsILNS_8MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1ELNS_15PosEncodingModeE0E13__nv_bfloat1613__nv_fp8_e4m3ffiNS_16DefaultAttentionILb0ELb1ELb0ELb0EEEEEN4hyle7compute10flashinfer6native48_GLOBAL__N__ca0ae4f1_15_native_cache_cu_95f5a4b011MergeParamsINS_23BatchPrefillPagedParamsIS4_S5_fiEES4_Lj256EEEEEvT0_");
namespace {
#ifndef HYLE_RESIDENT_PLACEMENT
#define HYLE_RESIDENT_PLACEMENT 0
#endif
namespace c=hyle::compute;
bool diagnostic_trace=false;
void push(const char *s){if(diagnostic_trace)nvtxRangePushA(s);}
void pop(){if(diagnostic_trace)nvtxRangePop();}
[[noreturn]] void fail(hyle::Status status){std::fprintf(stderr,"CUDA encoded: %.*s\n",int(status.message().size()),status.message().data());std::exit(2);}
void check(hyle::Status status){if(!status.ok())fail(status);}
template<class T>T take(hyle::Result<T> value){if(!value)fail(value.error());return std::move(*value);}
bool set(const char *name){const auto *p=std::getenv(name);return p&&*p;}
float decode(std::uint16_t x){return std::bit_cast<float>(std::uint32_t(x)<<16);}
std::uint16_t encode(float x){return std::uint16_t(std::bit_cast<std::uint32_t>(x)>>16);}
double fp8(std::uint8_t code){const unsigned e=(code&127)>>3,m=code&7;
  const double value=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);
  return code&128?-value:value;
}
struct Data {
  c::BatchCapacity capacity;
  std::array<std::int32_t,3> qp,kp;
  std::vector<std::int32_t> ids;std::array<std::int32_t,2> tails;
  std::vector<std::uint16_t> query;
  std::array<std::vector<std::byte>,2> packed;
  std::array<std::vector<float>,2> decoded;
  float scale;bool causal;std::int32_t window;
  Data(int q1,int q2,int k1,int k2,int dk,int dv,bool masked,int left):
    capacity{.storage=c::BatchStorage::kPaged,.query_type=c::DataType::kBFloat16,
      .output_type=c::DataType::kBFloat16,.key_storage=c::CacheStorage::float8(.5F).value(),
      .value_storage=c::CacheStorage::float8(2.F).value(),.max_requests=2,
      .max_query_rows=unsigned(q1+q2+3),.max_kv_rows=unsigned(k1+k2+13),
      .max_pages=unsigned((k1+15)/16+(k2+15)/16+2),.max_page_refs=unsigned((k1+15)/16+(k2+15)/16),
      .query_heads=8,.kv_heads=2,.qk_head_dim=unsigned(dk),.value_head_dim=unsigned(dv),.page_size=16},
    qp{0,q1,q1+q2},kp{0,(k1+15)/16,(k1+15)/16+(k2+15)/16},
    scale(1.F/std::sqrt(float(dk))),causal(masked),window(left){
    tails={(k1-1)%16+1,(k2-1)%16+1};
    for(unsigned i=0;i<capacity.max_page_refs;++i)ids.push_back(static_cast<std::int32_t>(capacity.max_pages-1-i));
    ids[static_cast<unsigned>(kp[1])]=ids[0];
    query.resize(std::size_t(capacity.max_query_rows)*8*dk);
    for(std::size_t i=0;i<query.size();++i)query[i]=encode(.125F+float((i/dk)%8%3)*.015625F);
    for(unsigned port=0;port<2;++port){
      const auto depth=port?dv:dk;
      auto &bytes=packed[port];auto &values=decoded[port];
      values.resize(std::size_t(capacity.max_pages)*16*2*depth);
      bytes.resize(values.size());
      // Independent finite FP8 fixture; the oracle decodes these actual bytes.
      for(std::size_t i=0;i<bytes.size();++i){
        const auto row=i/(2*depth),head=(i/depth)%2;
        constexpr std::uint8_t key_codes[]{0,56,64,68,72},value_codes[]{16,24,28,32,34};
        const auto code=(port?value_codes:key_codes)[(row+head)%5];
        bytes[i]=std::byte(code);values[i]=float(fp8(code)*(port?2.:.5));
      }
      for(unsigned page=0;page<capacity.max_pages;++page){
        unsigned valid=0;
        for(unsigned r=0;r<2;++r)for(auto ref=kp[r];ref<kp[r+1];++ref)
          if(ids[unsigned(ref)]==int(page))valid=std::max(valid,ref+1==kp[r+1]?unsigned(tails[r]):16u);
        for(auto i=std::size_t(page*16+valid)*2*depth;i<std::size_t((page+1)*16)*2*depth;++i){
          bytes[i]=std::byte(0x78);values[i]=float(fp8(0x78)*(port?2.:.5));
        }
      }
    }
  }
  std::size_t row_bytes(unsigned port)const{return std::size_t(2)*(port?capacity.value_head_dim:capacity.qk_head_dim);}
  std::vector<double> oracle()const{
    const auto dk=capacity.qk_head_dim,dv=capacity.value_head_dim;
    std::vector<double> output(std::size_t(qp[2])*8*dv),weights;double uniform_difference=0;
    for(unsigned r=0;r<2;++r){const int nq=qp[r+1]-qp[r],nk=(kp[r+1]-kp[r]-1)*16+tails[r];weights.resize(nk);
      for(int row=0;row<nq;++row)for(unsigned h=0;h<8;++h){double sum=0;
        const auto position=nk-nq+row;
        for(int j=0;j<nk;++j){
          if(causal&&(j>position||(window>=0&&j<std::max(0,position-window)))){weights[j]=0;continue;}
          double dot=0;for(unsigned d=0;d<dk;++d)dot+=double(decode(query[(std::size_t(qp[r]+row)*8+h)*dk+d]))*
              decoded[0][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dk+d];
          weights[j]=std::exp(dot*scale);sum+=weights[j];
        }
        for(unsigned d=0;d<dv;++d)for(int j=0;j<nk;++j)output[(std::size_t(qp[r]+row)*8+h)*dv+d]+=
            weights[j]/sum*decoded[1][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dv+d];
        double uniform=0;unsigned eligible=0;
        for(int j=0;j<nk;++j)if(weights[j]>0){++eligible;
          uniform+=decoded[1][((std::size_t(ids[unsigned(kp[r]+j/16)])*16+j%16)*2+h/4)*dv];}
        uniform_difference=std::max(uniform_difference,std::abs(
            output[(std::size_t(qp[r]+row)*8+h)*dv]-uniform/eligible));
      }
    }
    if(uniform_difference<=.01)fail(hyle::Status::Internal("FP8 oracle fixture cannot distinguish missing QK loads"));
    std::fprintf(stderr,"# CUDA_ENCODED_ORACLE uniform_difference=%.9g\n",uniform_difference);
    return output;
  }
};
struct Harness {
  c::Context context;c::cuda::MemoryResource memory,host;c::Queue queue;c::BatchSchema schema;c::BatchLayoutVersion layout;
  c::BatchProgram program;std::array<c::BatchInvocation,2> slots;c::LeasePool pool;
  c::PagedArena keys,values;c::PagedArenaRead key_frame,value_frame;
  std::vector<c::ReadLease> key_pages,value_pages;std::vector<unsigned> physical_ids;c::ReadLease query;std::size_t next=0;
  Harness(const Data &data,bool original){
    context=take(c::Context::create(take(c::cuda::device(0)),original?c::flashinfer::provider_control():c::flashinfer::provider_treatment()));
    const auto env=take(c::cuda::environment(context));
    if(env.sm_major!=8||env.sm_minor!=9)fail(hyle::Status::Unimplemented("finite actual SM89 profile"));
    std::fprintf(stderr,"# CUDA_ENCODED_ENV device=%s sm=%d%d driver=%s runtime=%d toolkit=%d original=%d\n",
        env.device_name.data(),env.sm_major,env.sm_minor,env.driver_release.data(),env.runtime_version,env.build_toolkit_version,original);
    memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
    host=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
    queue=take(context.create_queue());
    schema=take(c::BatchSchema::create(data.capacity));layout=take(schema.version({data.qp,data.kp,data.ids,data.tails}));
    const auto key_bytes=16*data.row_bytes(0),value_bytes=16*data.row_bytes(1);
    keys=take(c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory.ref(),{.max_backing_bytes=key_bytes*data.capacity.max_pages+1}));
    values=take(c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory.ref(),{.max_backing_bytes=value_bytes*data.capacity.max_pages+1}));
    for(unsigned page=0;page<data.capacity.max_pages;++page)if(std::find(data.ids.begin(),data.ids.end(),static_cast<std::int32_t>(page))!=data.ids.end()){
      auto kw=take(keys.acquire(page)),vw=take(values.acquire(page));
      check(kw.lease().view()->write(std::span(data.packed[0]).subspan(page*key_bytes,key_bytes)));
      check(vw.lease().view()->write(std::span(data.packed[1]).subspan(page*value_bytes,value_bytes)));
      physical_ids.push_back(page);key_pages.push_back(take(kw.publish(16)));value_pages.push_back(take(vw.publish(16)));
    }
    key_frame=take(keys.read(layout,key_pages));value_frame=take(values.read(layout,value_pages));
    program=take(c::BatchProgram::prepare(context,schema,{.resource=memory.ref(),.host_workspace=host.ref(),
        .max_float_workspace_bytes=32u<<20,.max_int_workspace_bytes=4096,.scale=data.scale,.causal=data.causal,.window_left=data.window}));
    for(auto &slot:slots){slot=take(c::BatchInvocation::create(program,queue));auto prepared=take(slot.prepare_batch(layout));}
    pool=take(c::LeasePool::create(memory.ref(),data.query.size()*2+2048));
    auto writer=take(pool.allocate(data.query.size()*2));check(writer.view()->write(std::as_bytes(std::span(data.query))));query=take(writer.publish());
    std::fprintf(stderr,"# CUDA_ENCODED_COLD original=%d known_float_bytes=%zu known_int_bytes=%zu tile=%u split=%d private_pool_upper=UNKNOWN requests=2 immutable_history=1\n",original,slots[0].report().float_workspace_bytes,slots[0].report().int_workspace_bytes,slots[0].report().cta_tile_q,slots[0].report().split_kv);
  }
  ~Harness(){const auto start=std::chrono::steady_clock::now();
    for(auto &slot:slots){check(slot.close());slot={};}
    program={};query.reset();pool={};key_frame={};value_frame={};
    key_pages.clear();value_pages.clear();keys={};values={};
    check(queue.drain());queue={};host.reset();memory.reset();check(context.close());
    std::fprintf(stderr,"# CUDA_ENCODED_TEARDOWN seconds=%.9f\n",
        std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count());
  }
  c::ReadLease execute(){auto &slot=slots[next++%slots.size()];
    push("update");auto prepared=take(slot.update_batch(layout));pop();
    if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));
    push("admit_submit");auto completion=take(prepared.run(query,key_frame,value_frame));pop();
    push("checked_wait");check(completion.wait());pop();
    push("output_acquire");auto output=take(slot.output());pop();return output;}
  std::vector<std::uint16_t> verify(const Data &data,const std::vector<double> &expected){auto output=execute();std::vector<std::uint16_t> actual(std::size_t(data.capacity.max_query_rows)*8*data.capacity.value_head_dim);check(output.view()->read(std::as_writable_bytes(std::span(actual))));
    double worst=0;for(std::size_t i=0;i<expected.size();++i){if(!std::isfinite(decode(actual[i])))fail(hyle::Status::Internal("paged nonfinite output"));worst=std::max(worst,std::abs(double(decode(actual[i]))-expected[i]));}
    if(worst>8e-3)fail(hyle::Status::Internal("paged independent double oracle exceeded 8e-3"));
    for(unsigned port=1;port<3;++port)for(unsigned index=0;index<key_pages.size();++index){const auto &lease=port==1?key_pages[index]:value_pages[index];auto view=take(lease.view());
      std::vector<std::byte> after(view.size());check(view.read(after));
      const auto first=data.packed[port-1].begin()+std::size_t(physical_ids[index])*16*data.row_bytes(port-1);
      if(!std::equal(after.begin(),after.end(),first))fail(hyle::Status::Internal("paged readonly KV changed"));
    }
    std::fprintf(stderr,"# CUDA_ENCODED_CORRECTNESS max_abs_error=%.9g elements=%zu\n",worst,expected.size());return actual;
  }
};

using Clock=std::chrono::steady_clock;
double us(Clock::duration d){return std::chrono::duration<double,std::micro>(d).count();}
void attrs(){
  cudaFuncAttributes a{},b{};
  if(cudaFuncGetAttributes(&a,reinterpret_cast<const void*>(&target_control))!=cudaSuccess||
     cudaFuncGetAttributes(&b,reinterpret_cast<const void*>(&target_treatment))!=cudaSuccess)
    fail(hyle::Status::Internal("isolated kernel attribute query failed"));
  std::printf("ATTR control_regs=%d treatment_regs=%d control_local=%zu treatment_local=%zu control_shared=%zu treatment_shared=%zu control_binary=%d treatment_binary=%d control_stub=%p treatment_stub=%p\n",a.numRegs,b.numRegs,a.localSizeBytes,b.localSizeBytes,a.sharedSizeBytes,b.sharedSizeBytes,a.binaryVersion,b.binaryVersion,reinterpret_cast<void*>(&target_control),reinterpret_cast<void*>(&target_treatment));
  if(a.numRegs!=248||b.numRegs!=250||a.localSizeBytes||b.localSizeBytes||a.binaryVersion!=89||b.binaryVersion!=89)fail(hyle::Status::Internal("expected original248/new250 SM89 identity not established"));
}
[[maybe_unused]] void measure(unsigned alloc,unsigned order,int q1,int q2,int k1,int k2,int dk,int dv,bool causal,int window,bool verify_only=false){
  const char *shape=verify_only?"tail":(window>=0?"window":(dk==256?"prefill":"holdout"));
  Data data(q1,q2,k1,k2,dk,dv,causal,window);std::unique_ptr<Harness> h[2];
  for(unsigned i=0;i<2;++i){const unsigned side=alloc?1-i:i;const auto start=Clock::now();h[side]=std::make_unique<Harness>(data,side==0);std::printf("COLD alloc=%u order=%u shape=%s side=%u create_us=%.9f\n",alloc,order,shape,side,us(Clock::now()-start));}
  const auto expected=data.oracle();std::vector<std::uint16_t> values[2];
  for(unsigned replay=0;replay<4;++replay)for(unsigned side=0;side<2;++side)values[side]=h[side]->verify(data,expected);
  double diff=0;for(std::size_t i=0;i<expected.size();++i)diff=std::max(diff,std::abs(double(decode(values[0][i]))-decode(values[1][i])));
  if(diff>8e-3)fail(hyle::Status::Internal("control/treatment disagreement exceeded 8e-3"));
  std::printf("ORACLE alloc=%u order=%u shape=%s pair_difference=%.9g\n",alloc,order,shape,diff);
  if(!verify_only){
    for(unsigned i=0;i<64;++i)for(unsigned j=0;j<2;++j){auto output=h[order?1-j:j]->execute();output.reset();}
    diagnostic_trace=set("G04_TRACE");push(shape);
    std::array<std::array<double,2>,512> raw{};
    for(unsigned group=0;group<8;++group)for(unsigned step=0;step<64;++step)for(unsigned j=0;j<2;++j){
      const unsigned side=order?1-j:j;
      push(side?"treatment.episode":"control.episode");const auto start=Clock::now();
      {auto output=h[side]->execute();output.reset();}
      raw[group*64+step][side]=us(Clock::now()-start);pop();
    }
    pop();diagnostic_trace=false;
    for(unsigned group=0;group<8;++group){double sums[2]{};
      for(unsigned step=0;step<64;++step){const auto &x=raw[group*64+step];sums[0]+=x[0];sums[1]+=x[1];std::printf("PAIR alloc=%u order=%u shape=%s group=%u step=%u control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,step,x[0],x[1]);}
      std::printf("BLOCK alloc=%u order=%u shape=%s group=%u count=64 control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,sums[0]/64,sums[1]/64);
    }
    for(unsigned side=0;side<2;++side)h[side]->verify(data,expected);
  }
  for(unsigned i=0;i<2;++i){const unsigned side=alloc?1-i:i;const auto start=Clock::now();h[side].reset();std::printf("CLOSE alloc=%u order=%u shape=%s side=%u close_us=%.9f\n",alloc,order,shape,side,us(Clock::now()-start));}
}
}

extern "C" void query_merge() asm("g04_query_merge");
namespace {
void ck(cudaError_t status){if(status!=cudaSuccess){std::fprintf(stderr,"query CUDA error: %s\n",cudaGetErrorString(status));std::exit(3);}}
struct QueryState {int device=0,smem_sm=0,smem_block=0,sms=0,occupancy=0;};
void query_one(unsigned index,QueryState &s){
 switch(index){
 case 0:ck(cudaGetDevice(&s.device));break;
 case 1:ck(cudaDeviceGetAttribute(&s.smem_sm,cudaDevAttrMaxSharedMemoryPerMultiprocessor,s.device));break;
 case 2:ck(cudaDeviceGetAttribute(&s.smem_block,cudaDevAttrMaxSharedMemoryPerBlockOptin,s.device));break;
 case 3:ck(cudaFuncSetAttribute(reinterpret_cast<const void*>(&target_control),cudaFuncAttributeMaxDynamicSharedMemorySize,49152));break;
 case 4:ck(cudaGetDevice(&s.device));break;
 case 5:ck(cudaDeviceGetAttribute(&s.sms,cudaDevAttrMultiProcessorCount,s.device));break;
 case 6:ck(cudaOccupancyMaxActiveBlocksPerMultiprocessorWithFlags(&s.occupancy,reinterpret_cast<const void*>(&query_merge),128,8704,cudaOccupancyDefault));break;
 case 7:ck(cudaFuncSetAttribute(reinterpret_cast<const void*>(&query_merge),cudaFuncAttributeMaxDynamicSharedMemorySize,8704));break;
 default:std::abort();
 }
}
void query_combo(QueryState &s){for(unsigned i=0;i<8;++i)query_one(i,s);}
}
int main(){
 cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0)std::abort();
 attrs();
 Data data(64,128,1024,768,256,256,true,-1);
 auto control=std::make_unique<Harness>(data,true);auto treatment=std::make_unique<Harness>(data,false);
 // No execute(), verify(), kernel launch or owning output creation in this measurement.
 cudaFuncAttributes a{},b{};ck(cudaFuncGetAttributes(&a,reinterpret_cast<const void*>(&target_control)));ck(cudaFuncGetAttributes(&b,reinterpret_cast<const void*>(&query_merge)));
 if(a.numRegs!=248||b.numRegs!=48||a.localSizeBytes||b.localSizeBytes)std::abort();
 std::printf("QUERY_IDENT prefill_regs=%d merge_regs=%d prefill_shared=49152 merge_shared=8704 merge_threads=128 prefill_local=%zu merge_local=%zu\n",a.numRegs,b.numRegs,a.localSizeBytes,b.localSizeBytes);
 QueryState s;for(unsigned i=0;i<1024;++i)query_combo(s);
 // Same original source order and normal success checks. No empty-loop subtraction.
 std::array<double,16> combo{};std::array<std::array<double,8>,16> single{};
 for(unsigned block=0;block<16;++block){
   auto start=Clock::now();for(unsigned rep=0;rep<1024;++rep)query_combo(s);combo[block]=us(Clock::now()-start)/1024;
   for(unsigned call=0;call<8;++call){start=Clock::now();for(unsigned rep=0;rep<1024;++rep)query_one(call,s);single[block][call]=us(Clock::now()-start)/1024;}
 }
 for(unsigned block=0;block<16;++block){std::printf("QUERY_COMBO block=%u count=1024 mean_us=%.9f\n",block,combo[block]);for(unsigned call=0;call<8;++call)std::printf("QUERY_SINGLE block=%u call=%u count=1024 mean_us=%.9f\n",block,call,single[block][call]);}
 std::printf("QUERY_VALUES device=%d smem_per_sm=%d smem_optin=%d sm_count=%d merge_occupancy=%d status=SUCCESS all_calls_checked=1 native_execute_calls=0\n",s.device,s.smem_sm,s.smem_block,s.sms,s.occupancy);
 treatment.reset();control.reset();std::printf("EXIT code=0\n");return 0;
}
