"""Read one retained SQLite trace; never starts a process or CUDA work."""
import pathlib,sqlite3,json,bisect,collections,statistics,hashlib
ROOT=pathlib.Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp')
P=ROOT/'run-trace-1/profile.sqlite'
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-same-process-ilp/submit-analysis')
OUT.mkdir(exist_ok=False)
c=sqlite3.connect(P);c.row_factory=sqlite3.Row
strings=dict(c.execute('select id,value from StringIds'))
nv=[dict(r) for r in c.execute('select * from NVTX_EVENTS where end is not null order by start')]
episodes=[r for r in nv if r['text'] in ['control.episode','treatment.episode']]
shapes=[r for r in nv if r['text'] in ['window','prefill','holdout']]
starts=[e['start'] for e in episodes];ss=[s['start'] for s in shapes]
for e in episodes:
 j=bisect.bisect_right(ss,e['start'])-1;e.update(shape=shapes[j]['text'],alloc=j//6,order=j//3%2,side=e['text'].split('.')[0],stages={},apis=[])
for r in nv:
 if r['text'] not in ['update','admit_submit','checked_wait','output_acquire']:continue
 i=bisect.bisect_right(starts,r['start'])-1
 if i>=0 and r['end']<=episodes[i]['end']:episodes[i]['stages'][r['text']]=dict(start=r['start'],end=r['end'])
for r in c.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME order by start'):
 i=bisect.bisect_right(starts,r['start'])-1
 if i<0:continue
 e=episodes[i]
 if r['end']>e['end'] or r['globalTid']!=e['globalTid']:continue
 stage=next((k for k,v in e['stages'].items() if v['start']<=r['start'] and r['end']<=v['end']),'outside_inner_ranges')
 e['apis'].append(dict(name=strings[r['nameId']],start_ns=r['start'],end_ns=r['end'],duration_us=(r['end']-r['start'])/1000,episode_offset_us=(r['start']-e['start'])/1000,stage=stage))
def q(v,p):
 v=sorted(v);x=(len(v)-1)*p;lo=int(x);return v[lo]+(v[min(lo+1,len(v)-1)]-v[lo])*(x-lo)
def describe(v):return dict(mean_us=statistics.mean(v),p50_us=q(v,.5),p90_us=q(v,.9),p99_us=q(v,.99),max_us=max(v))
def union_time(intervals):
 total=0;end=-1
 for a,b in sorted(intervals):
  if b<=end:continue
  total+=b-max(a,end);end=b
 return total/1000
prefill=[e for e in episodes if e['shape']=='prefill'];assert len(prefill)==4096
for e in prefill:
 submit=e['stages']['admit_submit'];apis=[a for a in e['apis'] if a['stage']=='admit_submit']
 assert collections.Counter(a['name'] for a in apis)=={'cudaLaunchKernel_v7000':2,'cudaEventRecord_v3020':1}
 assert collections.Counter(a['name'] for a in e['apis'])=={'cudaLaunchKernel_v7000':2,'cudaEventRecord_v3020':1,'cudaEventSynchronize_v3020':1}
 e['submit_us']=(submit['end']-submit['start'])/1000
 e['submit_captured_api_us']=union_time([(a['start_ns'],a['end_ns']) for a in apis])
 e['submit_uncaptured_residual_us']=e['submit_us']-e['submit_captured_api_us']
 # Save every time interval outside captured launch/event calls; these are NOT query-specific.
 cursor=submit['start'];segments=[]
 for a in apis:
  if a['start_ns']>cursor:segments.append(dict(start_offset_us=(cursor-submit['start'])/1000,duration_us=(a['start_ns']-cursor)/1000))
  cursor=max(cursor,a['end_ns'])
 if cursor<submit['end']:segments.append(dict(start_offset_us=(cursor-submit['start'])/1000,duration_us=(submit['end']-cursor)/1000))
 e['submit_uncaptured_intervals']=segments
with (OUT/'prefill-episode-api-intervals.jsonl').open('w') as f:
 for e in prefill:
  r={k:e[k] for k in ['alloc','order','side','submit_us','submit_captured_api_us','submit_uncaptured_residual_us','submit_uncaptured_intervals','apis']};f.write(json.dumps(r)+'\n')
rows=[]
for alloc in range(2):
 for order in range(2):
  for side in ['control','treatment']:
   ee=[e for e in prefill if (e['alloc'],e['order'],e['side'])==(alloc,order,side)];assert len(ee)==512
   counts=collections.Counter(a['name'] for e in ee for a in e['apis'])
   row={'alloc':alloc,'order':order,'side':side,'episodes':len(ee),'actual_captured_api_calls_per_episode':{k:v/len(ee) for k,v in counts.items()},'submit':describe([e['submit_us'] for e in ee]),'submit_captured_api_total':describe([e['submit_captured_api_us'] for e in ee]),'submit_uncaptured_residual':describe([e['submit_uncaptured_residual_us'] for e in ee]),'api_total_per_episode':{name:describe([sum(a['duration_us'] for a in e['apis'] if a['name']==name) for e in ee]) for name in counts}}
   rows.append(row)
result={'scope':'READ_ONLY retained trace; profiler CPU time is explanatory, never ordinary primary latency','sqlite_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'prefill_episodes':len(prefill),'important_limit':'Trace did not enable --cuda-trace-all-apis=true (default false). GetDevice/DeviceGetAttribute/FuncGetAttributes/Occupancy/FuncSetAttribute absent from StringIds and runtime records. Missing rows are NOT zero invocations or zero cost. Uncaptured residual includes all omitted APIs, ordinary host logic, runtime wrappers, checks and profiling overhead; it is only an aggregate upper bound for omitted static-query cost inside submit.','source_expected_per_prefill_episode':{'cudaGetDevice':2,'cudaDeviceGetAttribute':3,'cudaOccupancyMaxActiveBlocksPerMultiprocessorWithFlags':1,'cudaFuncSetAttribute':2,'cudaFuncGetAttributes':'No explicit call in this source path. Runtime-internal use is unknown.'},'source_expected_call_basis':['native_cache.cu merge_f32 lines28–33: GetDevice1,DeviceGetAttribute1,Occupancy1,FuncSetAttribute1','locked+patched attention/prefill.cuh paged dispatcher lines4584–4591,4697–4698: GetDevice1,DeviceGetAttribute2,FuncSetAttribute1','CUDA13.3 cuda_runtime.h inline occupancy overload delegates to cudaOccupancyMaxActiveBlocksPerMultiprocessorWithFlags'], 'all_prefill_episode_observed':{'cudaLaunchKernel':2,'cudaEventRecord':1,'cudaEventSynchronize':1,'captured_memcpy':0,'captured_memset':0},'strata':rows,'not_attributed':'26–32us launch-return to GPU-start interval has no attribution to static queries. These are separate host/device time intervals.'}
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for r in rows:print(r['alloc'],r['order'],r['side'],'submit',round(r['submit']['mean_us'],3),'captured',round(r['submit_captured_api_total']['mean_us'],3),'residual',round(r['submit_uncaptured_residual']['mean_us'],3))
