import pathlib,json,subprocess,hashlib,time
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-same-process-ilp/query-only')
OUT.mkdir(exist_ok=False)
Q=P/'query-only';Q.mkdir(exist_ok=False)
merge='_ZN10flashinferL41PersistentVariableLengthMergeStatesKernelILj8ELj32ELj4ELj2Ef13__nv_bfloat16iLb1EEEvPT3_PfPT5_PT4_S4_jPjjf'
subprocess.run(['objcopy','--redefine-sym',merge+'=g04_query_merge','--globalize-symbol=g04_query_merge',str(P/'control/cache.o'),str(Q/'control-cache.o')],check=True)
base=(P/'bench/cuda_encoded_page_bench.cc').read_text()
base=base[:base.index('int main(){')]
base=base.replace('void measure(unsigned alloc','[[maybe_unused]] void measure(unsigned alloc')
base+='''
extern "C" void query_merge() asm("g04_query_merge");
namespace {
void ck(cudaError_t status){if(status!=cudaSuccess){std::fprintf(stderr,"query CUDA error: %s\\n",cudaGetErrorString(status));std::exit(3);}}
struct QueryState {int device=0,smem_sm=0,smem_block=0,sms=0,occupancy=0;};
void query_one(unsigned index,QueryState &s){
 switch(index){
 case 0:ck(cudaGetDevice(&s.device));break;
 case 1:ck(cudaDeviceGetAttribute(&s.smem_sm,cudaDevAttrMaxSharedMemoryPerMultiprocessor,s.device));break;
 case 2:ck(cudaDeviceGetAttribute(&s.smem_block,cudaDevAttrMaxSharedMemoryPerBlockOptin,s.device));break;
 case 3:ck(cudaFuncSetAttribute(reinterpret_cast<const void*>(&target_control),cudaFuncAttributeMaxDynamicSharedMemorySize,49152));break;
 case 4:ck(cudaGetDevice(&s.device));break;
 case 5:ck(cudaDeviceGetAttribute(&s.sms,cudaDevAttrMultiProcessorCount,s.device));break;
 case 6:ck(cudaOccupancyMaxActiveBlocksPerMultiprocessorWithFlags(&s.occupancy,reinterpret_cast<const void*>(&query_merge),128,8704,cudaOccupancyDefault));break;
 case 7:ck(cudaFuncSetAttribute(reinterpret_cast<const void*>(&query_merge),cudaFuncAttributeMaxDynamicSharedMemorySize,8704));break;
 default:std::abort();
 }
}
void query_combo(QueryState &s){for(unsigned i=0;i<8;++i)query_one(i,s);}
}
int main(){
 cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0)std::abort();
 attrs();
 Data data(64,128,1024,768,256,256,true,-1);
 auto control=std::make_unique<Harness>(data,true);auto treatment=std::make_unique<Harness>(data,false);
 // No execute(), verify(), kernel launch or owning output creation in this measurement.
 cudaFuncAttributes a{},b{};ck(cudaFuncGetAttributes(&a,reinterpret_cast<const void*>(&target_control)));ck(cudaFuncGetAttributes(&b,reinterpret_cast<const void*>(&query_merge)));
 if(a.numRegs!=248||b.numRegs!=48||a.localSizeBytes||b.localSizeBytes)std::abort();
 std::printf("QUERY_IDENT prefill_regs=%d merge_regs=%d prefill_shared=49152 merge_shared=8704 merge_threads=128 prefill_local=%zu merge_local=%zu\\n",a.numRegs,b.numRegs,a.localSizeBytes,b.localSizeBytes);
 QueryState s;for(unsigned i=0;i<1024;++i)query_combo(s);
 // Same original source order and normal success checks. No empty-loop subtraction.
 std::array<double,16> combo{};std::array<std::array<double,8>,16> single{};
 for(unsigned block=0;block<16;++block){
   auto start=Clock::now();for(unsigned rep=0;rep<1024;++rep)query_combo(s);combo[block]=us(Clock::now()-start)/1024;
   for(unsigned call=0;call<8;++call){start=Clock::now();for(unsigned rep=0;rep<1024;++rep)query_one(call,s);single[block][call]=us(Clock::now()-start)/1024;}
 }
 for(unsigned block=0;block<16;++block){std::printf("QUERY_COMBO block=%u count=1024 mean_us=%.9f\\n",block,combo[block]);for(unsigned call=0;call<8;++call)std::printf("QUERY_SINGLE block=%u call=%u count=1024 mean_us=%.9f\\n",block,call,single[block][call]);}
 std::printf("QUERY_VALUES device=%d smem_per_sm=%d smem_optin=%d sm_count=%d merge_occupancy=%d status=SUCCESS all_calls_checked=1 native_execute_calls=0\\n",s.device,s.smem_sm,s.smem_block,s.sms,s.occupancy);
 treatment.reset();control.reset();std::printf("EXIT code=0\\n");return 0;
}
'''
(Q/'query.cc').write_text(base)
# Reference header is unchanged; compile beside it through an include directory.
c=json.loads((P/'commands.json').read_text());c['compile']=[str(Q/'query.cc') if x==str(P/'bench/cuda_encoded_page_bench.cc') else str(Q/'query.o') if x==str(P/'consumer.o') else x for x in c['compile']];c['compile'][1:1]=['-I'+str(P/'bench')]
c['link']=[str(Q/'control-cache.o') if x==str(P/'control/cache.o') else str(Q/'query.o') if x==str(P/'consumer.o') else str(Q/'g04_query_only') if x==str(P/'g04_same_process') else '-Wl,-Map='+str(Q/'link.map') if x=='-Wl,-Map='+str(P/'link.map') else x for x in c['link']]
(Q/'commands.json').write_text(json.dumps(c,indent=2)+'\n')
r={}
for stage in ['compile','link']:
 start=time.monotonic()
 with (Q/(stage+'.log')).open('w') as f:z=subprocess.run(c[stage],stdout=f,stderr=subprocess.STDOUT)
 r[stage]={'exit_code':z.returncode,'seconds':time.monotonic()-start};print(stage,r[stage],flush=True)
 if z.returncode:print((Q/(stage+'.log')).read_text()[-5000:]);break
(Q/'build-result.json').write_text(json.dumps(r,indent=2)+'\n')
for name in ['query.cc','commands.json','compile.log','link.log','build-result.json','link.map']:
 p=Q/name
 if p.exists():(OUT/name).write_bytes(p.read_bytes())
print('executable_sha256',hashlib.sha256((Q/'g04_query_only').read_bytes()).hexdigest() if (Q/'g04_query_only').exists() else 'NOT_BUILT')
