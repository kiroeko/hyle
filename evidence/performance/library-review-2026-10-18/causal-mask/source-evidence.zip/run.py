from pathlib import Path
import argparse, hashlib, json, os, shlex, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
cl=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe');link=cl.with_name('link.exe')
foundation=ROOT/'.scratch/build-compute-v2-dev'
cache=ROOT/'.scratch/bench-api-runtime/vulkan/build'
source=cache/'native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e'
vk=Path('C:/public/tools/hyle-dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f/include')
gtest=Path(os.environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':str(cl),'CMAKE_C_COMPILER':str(cl)});env['VSLANG']='1033'
env['PATH']=str(foundation/'bin')+os.pathsep+env['PATH'];env['DISABLE_VULKAN_OBS_CAPTURE']='1';env['VK_LOADER_LAYERS_DISABLE']='~all~'
flags=['/nologo','/c','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/Ob2','/MD','/DNDEBUG','/permissive-','/bigobj','/DHYLE_STATIC','/DNOMINMAX','/DHYLE_COMPUTE_VULKAN=1',
 '/I'+str(ROOT/'include'),'/I'+str(ROOT/'src/compute_provider_ggml_vulkan'),'/I'+str(ROOT/'src/compute_ggml_runtime'),
 '/external:I'+str(source/'include'),'/external:I'+str(source/'src'),'/external:I'+str(vk),'/external:I'+str(gtest),'/external:W0']
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(label,command,expected=0):
 command=list(map(str,command));t=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
 (OUT/(label+'.log')).write_bytes(p.stdout);records.append({'label':label,'command':command,'exit_code':p.returncode,'expected_exit_code':expected,'cwd':str(ROOT),'elapsed_seconds':time.monotonic()-t})
 (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,p.returncode,p.stdout.decode(errors='replace')[-6000:],flush=True)
 if p.returncode!=expected:raise SystemExit(p.returncode or 2)
def compile(file,obj,label):run(label,[cl,*flags,file,'/Fo'+str(obj)])
core=[foundation/'bin'/(n+'.lib') for n in ['hyle_compute','hyle_compute_ops','hyle_container','hyle_mem','mimalloc_static','hyle_platform','hyle_error','hyle_platform_thread','hyle_time','hyle_simd']]
core += [foundation/'lib'/(n+'.lib') for n in ['gtest','gtest_main']]
line=next(x for x in (cache/'build.ninja').read_text().splitlines() if x.startswith('  LINK_LIBRARIES = '))
vendor=[]
for arg in shlex.split(line.split(' = ',1)[1],posix=False):
 p=Path(arg.strip('"'))
 if p.stem in ['hyle_compute_provider_ggml_vulkan','hyle_compute_ggml_runtime','ggml','ggml-base','ggml-vulkan']:vendor.append(p if p.is_absolute() else cache/p)
system=['bcrypt.lib','PowrProf.lib','Synchronization.lib','advapi32.lib','user32.lib','shell32.lib','ole32.lib','ws2_32.lib']
p=argparse.ArgumentParser();p.add_argument('action',choices=['compile','test','space-final']);args=p.parse_args()
if args.action=='compile':
 compile(ROOT/'tests/compute_provider_ggml_vulkan/attention_causal_test.cc',OUT/'tests.obj','tests-compile')
 for arm in ['baseline','candidate']:
  if not (OUT/(arm+'.obj')).exists():compile(OUT/('vulkan-'+arm+'.cc'),OUT/(arm+'.obj'),arm+'-compile')
  run(arm+'-link',[link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/(arm+'-tests.exe')),OUT/(arm+'.obj'),OUT/'tests.obj',*core,*vendor,*system])
if args.action=='test':
 run('baseline-numerics',[OUT/'baseline-tests.exe','--gtest_filter=GgmlVulkanCausalAttention.OrdinaryGqaBatchAndScalesMatchIndependentOracle:GgmlVulkanCausalAttention.ExistingLayoutAndDtypeAdmissionRemainExplicit'])
 run('baseline-space-regression',[OUT/'baseline-tests.exe','--gtest_filter=GgmlVulkanCausalAttention.ColdGallocrStorageHasNoQuadraticMask'],expected=1)
 run('candidate-all',[OUT/'candidate-tests.exe','--gtest_filter=GgmlVulkanCausalAttention.*'])

if args.action=='space-final':
 for arm,expected in [('baseline',1),('candidate',0)]:
  run(arm+'-space-final',[OUT/(arm+'-tests.exe'),'--gtest_filter=GgmlVulkanCausalAttention.ColdGallocrStorageHasNoQuadraticMask'],expected)
