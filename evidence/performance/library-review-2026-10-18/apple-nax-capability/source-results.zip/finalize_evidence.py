from pathlib import Path
import hashlib,json,subprocess,tarfile,zipfile

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((OUT/name).read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
product=['src/compute_route_apple/apple_tensor.cc','tests/compute_route_apple/attention_test.cc']
assert (ROOT/product[0]).read_bytes()==(OUT/'measured/apple_tensor.candidate.cc').read_bytes()
assert (ROOT/product[1]).read_bytes()==(OUT/'measured/attention_test.cc').read_bytes()
(OUT/'product.patch').write_bytes(subprocess.check_output(['git','diff','--',*product],cwd=ROOT))
source={p:sha(ROOT/p) for p in product}
space={arm:read('measured/'+arm+'-space.stdout.txt') for arm in ['baseline','candidate']}
capability=json.loads(read('results.json')[1]['stdout'])
native_archive=ROOT/'.scratch/inference-gaps/g04-g05/metal-lifetime/mlx-1f8e74e3f12f31365464a6867c6579f0e9b29d85.tar.gz'
snippets=[]
with tarfile.open(native_archive) as t:
 prefix=t.getmembers()[0].name.split('/')[0]+'/'
 for path,begin,end in [('mlx/backend/metal/device.cpp',947,966),('mlx/backend/metal/device_info.cpp',24,53),('mlx/backend/metal/CMakeLists.txt',88,113),('mlx/utils.h',214,217),('mlx/device.h',48,62)]:
  data=t.extractfile(prefix+path).read();lines=data.decode().splitlines()
  snippets.append(dict(path=path,sha256=hashlib.sha256(data).hexdigest(),first_line=begin,last_line=end,text='\n'.join(lines[begin-1:end])))
write('native-source-evidence.json',{'revision':'1f8e74e3f12f31365464a6867c6579f0e9b29d85','source_archive':str(native_archive),'snippets':snippets,'patched_attention_selector':'Current third_party/mlx_cast/patches.json preserves D256 causal Q>=1024 no-array-mask fused shortcut only when native is_nax_available && (enable_tf32 || dtype != F32). Other F32 D256 long-Q paths fall back.'})
maps={}
for arm in ['baseline','candidate']:
 for kind in ['tests','space']:
  text=(OUT/'measured'/(arm+'-'+kind+'.map')).read_text()
  maps[arm+'-'+kind]={'fresh_apple_tensor_object':('/'+arm+'.o') in text,'old_apple_tensor_archive_member':'.a(apple_tensor.cc.o)' in text}
runtime=read('measured/runtime-identities.json')
cleanup=[dict(path=p,**v) for p,v in runtime.items() if '/library-review-20261018-nax-capability/' in p]
write('cleanup-candidates.json',{'files':cleanup,'total_bytes':sum(x['bytes'] for x in cleanup),'instruction':'Only these new objects/executables are candidates; root writes exact cleanup to repository test.ps1 before execution. Do not remove original SDK/libmlx/metallib or prior source/log cache.'})
summary={
 'status':'focused_correctness_passed; large_space_point_numerical_oracle_FAILED_on_both_variants',
 'canonical_source_root':str(ROOT),'product_source_sha256':source,
 'baseline_source_sha256':sha(OUT/'measured/apple_tensor.baseline.cc'),
 'capability':capability,
 'machine':{'model':'Mac16,12','chip':'Apple M4','os':'macOS27.0.1 (26A434)','free_space_before':'41 GiB','compiler':'Apple clang21.0.0','SDK':'/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk'},
 'cause':'Pinned NAX requires macOS>=26.2 and Apple GPU generation>=17 (>=18 phone), and may be disabled at SDK build time. The actual M4 architecture applegpu_g16g independently excludes it. Native enable_tf32 defaults true and was actually true with no relevant env overrides. D256 causal F32 Q>=1024 therefore falls back on this machine.',
 'implementation':{
  'public_capability_only':'mx::device_info(Device::gpu), already used by apple_environment.mm; no existing architecture parser was found.',
  'negative_detection':'Strict 13-character applegpu_g1[3-6][g/s/d/p] recognition. Missing field, wrong variant, unknown/new identifier, or exception returns false and keeps original native selection.',
  'scope':'Only the otherwise possibly fused D256 causal no-mask path uses this query during cold lowering. All existing GPU-only/Q>=1024/benefit/force-fused guards stay in effect.',
  'non_changes':'No private native declaration in product, no OS/build/env selector duplication, no SDK/kernel patch, no eval/sync during tracing, no hot replay metadata query, no public API/admission/precision-budget change.',
  'diagnostic_only_private_query':'capability.cc forward-declares pinned is_nax_available solely to establish actual SDK behavior; product never uses it.',
 },
 'validation':{
  'fresh_compile':'Baseline/candidate apple_tensor.cc, current attention_test.cc, and space.cc host TUs only; O3 C++23 arm64 Wall/Wextra/Wpedantic/Werror. Existing SDK/foundation/gtest/metallib reused; no whole configure/build/download/copy.',
  'targeted_tests':{'baseline':2,'candidate':2,'all_exit':0,'filter':'AppleAttention.LongCausalD256RetainsFp32Reference:AppleAttention.UnsupportedFusedDomainsKeepTheirExistingFallback'},
  'new_case':'F32 D256 BSHD GQA H4/Hkv2 Q1025/KV1281, causal no mask, nonzero QK, independent existing FP64 oracle including one-row tail.',
  'small_controls':'Existing D40 fallback, D192 decode, D256 Q17>KV13 causal cases.',
  'budgets':'Existing F32 rel6e-6+abs2e-6 unchanged.',
  'maps':maps,'runtime_identity':runtime,
 },
 'space_point':{
  'shape':'F32 B1/Hq4/Hkv2/D256 Q=KV2048, causal, no mask input; QK0/V1.25.',
  'measurement':'One separate process per arm, same public prepare/create_invocation/bind then clear_cache/reset_peak and submit/wait. Native MLX active/peak/cache only, not process RSS/device-total/private-byte census. Cold prepare is outside peak capture.',
  'baseline':space['baseline'],'candidate':space['candidate'],
  'numerical_oracle_status':{'baseline':'FAIL','candidate':'FAIL','baseline_exit':3,'candidate_exit':3,'abs_budget':9.5e-6,'max_abs_error_both':3.43323e-5},
  'accuracy_interpretation':'Both violate the unchanged public helper budget at this large uniform causal shape. Equal max errors do not establish bit parity, full numerical equivalence, or a passing large-shape oracle. This existing accuracy issue remains unresolved.',
  'allocation_interpretation':'The real native counters were collected before exit3 and remain reported as measurements only. Extra peak83,902,464 ->60,371,584 bytes (~28.05% decrease) under current default native settings; caller QKV16MiB/output8MiB listed separately. No mask input.',
  'extra_peak_reduction_fraction':1-space['candidate']['peak_minus_active_before']/space['baseline']['peak_minus_active_before'],
  'warm_constants_difference_bytes':space['candidate']['active_before']-space['baseline']['active_before'],
 },
 'remaining_limits':[
  'Unknown/new architectures retain native selection even if their OS/build/env disables NAX, so those fallback cases may still allocate square scores.',
  'No inference throughput measurement, no strict single-block peak guarantee, no other Apple hardware, no full Apple/Graph suite or HEAD SDK rebuild.',
  'Large uniform-causal F32 oracle failure on both variants is recorded and not fixed or marked passing in this batch.',
 ],
 'failures_retained':['baseline-space exit3 stopped the sequential runner; candidate-space was then run exactly once independently and also exit3. No budget/input change or additional shape.','One local archive-helper command had a Python quoting SyntaxError before collecting data; rewritten stdin form succeeded. No workload was launched by that failed wrapper.'],
 'source_evidence':'native-source-evidence.json','cleanup':'cleanup-candidates.json',
}
write('summary.json',summary)
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted((OUT/'measured').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
 for name in ['summary.json','native-source-evidence.json','cleanup-candidates.json','product.patch','results.json','capability.cc','run.py','validate_remote.py','prepare_validation.py','collect_snapshot.py','finalize_evidence.py','validation.stdout.txt','validation.stderr.txt','ssh.stderr.txt']:
  z.write(OUT/name,name)
write('archive-record.json',{'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'summary_sha256':sha(OUT/'summary.json'),'product_source_sha256':source,'binaries_and_SDK_excluded':True})
print(json.dumps(read('archive-record.json'),indent=2))
