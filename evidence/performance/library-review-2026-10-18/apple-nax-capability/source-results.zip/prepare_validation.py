from pathlib import Path
import subprocess
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-nax-capability';HOST='kiro@172.22.10.198'
(OUT/'apple_tensor.baseline.cc').write_bytes(subprocess.check_output(['git','show','HEAD:src/compute_route_apple/apple_tensor.cc'],cwd=ROOT))
(OUT/'apple_tensor.candidate.cc').write_bytes((ROOT/'src/compute_route_apple/apple_tensor.cc').read_bytes())
(OUT/'attention_test.cc').write_bytes((ROOT/'tests/compute_route_apple/attention_test.cc').read_bytes())
for name in ['apple_tensor.baseline.cc','apple_tensor.candidate.cc','attention_test.cc','space.cc','validate_remote.py']:
 subprocess.run(['scp',str(OUT/name),HOST+':'+REMOTE+'/'+name],check=True)
r=subprocess.run(['ssh',HOST,'cd '+REMOTE+' && /usr/bin/python3 validate_remote.py --build --tests --space'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'validation.stdout.txt').write_bytes(r.stdout);(OUT/'validation.stderr.txt').write_bytes(r.stderr)
print(r.stdout.decode(errors='replace'));print(r.stderr.decode(errors='replace'));raise SystemExit(r.returncode)
