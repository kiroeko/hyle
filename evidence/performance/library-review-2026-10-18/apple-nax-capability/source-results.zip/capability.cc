#include <mlx/device.h>
#include <mlx/backend/metal/metal.h>
#include <mlx/utils.h>

#include <cstdlib>
#include <iomanip>
#include <iostream>

// Diagnostic only: pinned native implementation, not a new Hyle API or product
// dependency. Product selection can use public device_info conservatively.
namespace mlx::core::metal { bool is_nax_available(); }

int main() {
  namespace mx = mlx::core;
  mx::metal::set_metallib_path(
      "/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib/mlx.metallib");
  const auto &info = mx::device_info(mx::Device::gpu);
  std::cout << "{\"device_name\":" << std::quoted(std::get<std::string>(info.at("device_name")))
            << ",\"architecture\":" << std::quoted(std::get<std::string>(info.at("architecture")))
            << ",\"native_is_nax_available\":" << std::boolalpha << mx::metal::is_nax_available()
            << ",\"enable_tf32\":" << mx::env::enable_tf32()
            << ",\"MLX_METAL_GPU_ARCH\":" << std::quoted(std::getenv("MLX_METAL_GPU_ARCH") ? std::getenv("MLX_METAL_GPU_ARCH") : "")
            << ",\"MLX_ENABLE_TF32\":" << std::quoted(std::getenv("MLX_ENABLE_TF32") ? std::getenv("MLX_ENABLE_TF32") : "")
            << "}\n";
}
