#include "tests/compute_route_apple/tensor_test_support.h"
#include <mlx/memory.h>
#include <array>
#include <iostream>
int main() {
  using namespace apple_tensor_test;
  try {
    constexpr int depth=256, queries=2048, keys=2048, heads=4, kv_heads=2;
    const std::array inputs{
      make(std::vector<double>(heads*queries*depth), {1,heads,queries,depth}, mx::float32),
      make(std::vector<double>(kv_heads*keys*depth), {1,kv_heads,keys,depth}, mx::float32),
      make(std::vector<double>(kv_heads*keys*depth,1.25), {1,kv_heads,keys,depth}, mx::float32)};
    auto context=a::Context::create().value();
    auto program=context.prepare(c::Operation(c::ScaledDotProductAttention{
        .layout=c::AttentionLayout::kBatchHeadSequenceDepth,
        .scale=0.0625F,.causal=true}),inputs).value();
    auto slot=program.create_invocation().value();
    auto bound=slot.bind(inputs);if(!bound.ok()){std::cerr<<bound.message();return 2;}
    mx::clear_cache();
    const auto before=mx::get_active_memory(),cache_before=mx::get_cache_memory();
    mx::reset_peak_memory();
    auto work=slot.submit().value();auto result=work.wait().value();mx::synchronize(stream());
    const auto after=mx::get_active_memory(),peak=mx::get_peak_memory(),cache_after=mx::get_cache_memory();
    auto observed=values(result.get()->arrays()[0]);double max_error=0;
    for(auto x:observed)max_error=std::max(max_error,std::abs(x-1.25));
    std::cout<<"{\"dtype\":\"F32\",\"B\":1,\"Hq\":4,\"Hkv\":2,\"D\":256,\"Q\":2048,\"KV\":2048,\"mask\":\"None\",\"causal\":true,\"caller_qkv_bytes\":16777216,\"caller_mask_bytes\":0,\"output_bytes\":8388608,\"active_before\":"<<before
      <<",\"cache_before\":"<<cache_before<<",\"active_after\":"<<after<<",\"peak\":"<<peak
      <<",\"peak_minus_active_before\":"<<(peak-before)<<",\"cache_after\":"<<cache_after
      <<",\"max_abs_error\":"<<max_error<<",\"checked_elements\":"<<observed.size()<<"}\n";
    return max_error<=6e-6*1.25+2e-6?0:3;
  }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 4;}
}
