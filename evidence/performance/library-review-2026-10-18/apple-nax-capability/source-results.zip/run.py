from pathlib import Path
import json,subprocess

OUT=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-nax-capability'
HOST='kiro@172.22.10.198'
for command in [['ssh',HOST,'mkdir -p '+REMOTE],['scp',str(OUT/'capability.cc'),HOST+':'+REMOTE+'/capability.cc']]:
 subprocess.run(command,check=True)
code='''from pathlib import Path
import json,subprocess,hashlib
p=Path(REMOTE);sdk=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
commands=[['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64','-DMLX_STATIC','-Wall','-Wextra','-Wpedantic','-Werror','-isystem',str(sdk/'include'),'-isystem',str(sdk/'include/metal_cpp'),str(p/'capability.cc'),str(sdk/'lib/libmlx.a'),'-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore','-o',str(p/'capability')],[str(p/'capability')]]
records=[]
for label,c in zip(['compile','query'],commands):
 r=subprocess.run(c,cwd=p,stdout=subprocess.PIPE,stderr=subprocess.PIPE);record=dict(label=label,command=c,exit=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode());records.append(record)
 if r.returncode:break
(p/'results.json').write_text(json.dumps(records,indent=2));print(json.dumps(records,indent=2))
'''.replace('REMOTE',repr(REMOTE))
r=subprocess.run(['ssh',HOST,'/usr/bin/python3 -'],input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'results.json').write_bytes(r.stdout)
(OUT/'ssh.stderr.txt').write_bytes(r.stderr)
print(r.stdout.decode());print(r.stderr.decode())
if r.returncode:raise SystemExit(r.returncode)
if any(x['exit'] for x in json.loads(r.stdout)):raise SystemExit(1)
