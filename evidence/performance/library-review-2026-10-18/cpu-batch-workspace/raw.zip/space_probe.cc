#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/batch_execution.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/mem/stats.h"
#include <array>
#include <iostream>
#include <vector>
namespace c=hyle::compute;namespace m=hyle::mem;
class Counted final:public m::MemoryResource{
public:explicit Counted(m::AllocatorRef a):a_(a){}
 std::string_view name()const noexcept override{return "CPU batch measured backing";}
 m::MemoryProperties properties()const noexcept override{return m::system_resource().properties();}
 hyle::Result<m::ResourceAllocation>allocate(std::size_t n,std::size_t align)noexcept override{auto*p=a_.allocate(n,align);if(!p)return std::unexpected(hyle::Status::ResourceExhausted("probe backing"));return m::ResourceAllocation{p,n,align};}
 void deallocate(m::ResourceAllocation a)noexcept override{a_.deallocate(a.native_handle,a.size,a.alignment);}
 hyle::Result<m::ResourceHostMapping>map_host(void*p,std::size_t offset,std::size_t,m::HostAccess)noexcept override{return m::ResourceHostMapping{static_cast<std::byte*>(p)+offset,nullptr};}
private:m::AllocatorRef a_;
};
int main(){try{
 const auto storage=c::CacheStorage::plain(c::DataType::kFloat16).value();
 auto schema=c::BatchSchema::create({.storage=c::BatchStorage::kPaged,.query_type=c::DataType::kFloat16,.output_type=c::DataType::kFloat16,
  .key_storage=storage,.value_storage=storage,.max_requests=1,.max_query_rows=2048,.max_kv_rows=16384,.max_pages=2,.max_page_refs=1024,
  .query_heads=1,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=16}).value();
 auto stats=m::StatsAllocator::create(m::system_allocator()).value();Counted resource(stats.get());
 auto context=c::Context::create(c::cpu::device(),c::ggml_cpu::provider({.native_threads=2})).value();auto queue=context.create_queue().value();
 std::uint64_t backing=0;
 {auto program=c::BatchProgram::prepare(context,schema,{.resource=m::MemoryResourceRef(resource),.host_workspace=m::MemoryResourceRef(resource),.max_float_workspace_bytes=128u<<20,.max_int_workspace_bytes=8u<<20,.scale=.125F}).value();
  const auto before=stats.snapshot();auto slot=c::BatchInvocation::create(program,queue).value();backing=stats.snapshot().live_bytes-before.live_bytes;
  if(!slot.close().ok())return 2;}
 if(!stats.balanced())return 3;
 // Counted custom CPU copy writers intentionally have no physical-identity
 // capability. Measure backing creation there, plan with the real system carrier.
 const std::array<std::int32_t,2> q{0,2048},k{0,1024};const std::array<std::int32_t,1> tail{16};std::vector<std::int32_t> ids(1024);for(std::size_t i=0;i<ids.size();++i)ids[i]=std::int32_t(i%2);
 auto layout=schema.version({q,k,ids,tail}).value();
 auto program=c::BatchProgram::prepare(context,schema,{.resource=m::system_resource(),.max_float_workspace_bytes=128u<<20,.max_int_workspace_bytes=8u<<20,.scale=.125F}).value();
 auto slot=c::BatchInvocation::create(program,queue).value();auto prepared=slot.prepare_batch(layout).value();
 std::cout<<"{\"Q\":2048,\"logical_KV\":16384,\"configured_float_bytes\":"<<(128u<<20)<<",\"configured_int_bytes\":"<<(8u<<20)<<",\"tracked_actual_pool_backing_bytes\":"<<backing<<",\"reported_known_native_bytes\":"<<slot.report().float_workspace_bytes<<",\"graph_executed\":false,\"counted_carrier_and_system_plan_separate\":true}\n";
 prepared={};if(!slot.close().ok() || !context.drain().ok())return 4;return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 5;}}
