#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/detail/batch_provider.h"
#include "hyle/graph/batch.h"
#include "hyle/simd/dtype.h"
#include <array>
#include <cmath>
#include <iostream>
#include <vector>
namespace c=hyle::compute;namespace g=hyle::graph;namespace gb=g::batch;namespace m=hyle::mem;
void check(bool x,const char*text){if(!x)throw std::runtime_error(text);}
int main(){try{
 const auto storage=c::CacheStorage::plain(c::DataType::kFloat16).value();
 const c::BatchCapacity cap{.storage=c::BatchStorage::kRagged,.query_type=c::DataType::kFloat16,.output_type=c::DataType::kFloat16,
  .key_storage=storage,.value_storage=storage,.max_requests=1,.max_query_rows=2,.max_kv_rows=3,.max_pages=0,.max_page_refs=0,
  .query_heads=2,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=1};
 auto schema=c::BatchSchema::create(cap).value();const c::BatchProgramOptions options{.resource=m::system_resource(),.max_float_workspace_bytes=8u<<20,.max_int_workspace_bytes=8192,.scale=.125F};
 auto wrapped=gb::provider(c::ggml_cpu::provider({.native_threads=2}),schema,options).value();
 auto context=c::Context::create(c::cpu::device(),wrapped).value();auto queue=context.create_queue().value();
 auto extension=c::detail::ProviderExtensionAccess::query(context,0,c::detail::kBatchPlanningExtensionId).value();
 bool uses=true;auto observed=c::detail::ProviderExtensionAccess::call(extension,[](void*,const void*p,void*out)noexcept{*static_cast<bool*>(out)=static_cast<const c::detail::BatchProviderVTable*>(p)->uses_caller_workspace;return hyle::Status::Ok();},&uses);check(observed.ok()&&!uses,"wrapper forwards opt-out");
 const std::array descriptions{c::batch_query_description(cap).value(),c::batch_cache_description(cap,c::BatchCacheRole::kKey).value(),c::batch_cache_description(cap,c::BatchCacheRole::kValue).value(),schema.metadata_description().value()};
 auto builder=g::GraphBuilder::create().value();std::array<g::ValueId,4> inputs;
 for(unsigned i=0;i<4;++i)inputs[i]=builder.input(descriptions[i]).value();
 auto node=builder.add_node(c::Operation::custom(c::RaggedAttention{.capacity=cap,.scale=.125F}),inputs).value();auto output=builder.result(node).value();check(builder.publish(output).ok(),"publish");auto logical=std::move(builder).finish().value();
 auto compiled=g::compile(logical,context,{.operation_fallback=g::OperationFallbackPolicy::kReject}).value();check(compiled.report.step_count()==1,"one batch region");
 const std::array lanes{gb::LaneBinding{g::ExecutionLaneId{0},&context,&queue,m::system_resource()}};
 auto invocation=gb::Invocation::create(compiled.executable,lanes).value();const std::array<std::int32_t,2> q{0,2},k{0,3};auto layout=schema.version({q,k,{},{}}).value();
 const std::array layouts{gb::NodeLayout{node,layout}};check(invocation.prepare_batch(layouts).ok(),"Graph batch prepare");
 auto pool=c::LeasePool::create(m::system_resource(),4096).value();
 for(unsigned port=0;port<3;++port){const auto bytes=descriptions[port].required_bytes().value();auto writer=pool.allocate(bytes).value();
  std::vector<hyle::simd::float16_t> values(bytes/2,hyle::simd::f32_to_f16(port==2?.5F:0.F));check(writer.view()->write(std::as_bytes(std::span(values))).ok(),"write input");check(invocation.bind(inputs[port],descriptions[port],writer.publish().value()).ok(),"bind input");}
 const auto result_desc=c::batch_output_description(cap,cap.max_query_rows).value();auto writer=pool.allocate(result_desc.required_bytes().value()).value();check(invocation.bind(output,result_desc,std::move(writer)).ok(),"bind external output");
 auto done=invocation.submit().value();check(done.wait().ok(),"Graph terminal");auto result=invocation.output(output).value();auto tensor=result.tensor().value();std::vector<hyle::simd::float16_t> actual(result_desc.element_count().value());check(tensor.storage().read(std::as_writable_bytes(std::span(actual))).ok(),"read result");
 for(auto value:actual)check(std::abs(hyle::simd::f16_to_f32(value)-.5F)<=.002F,"Graph math");
 std::cout<<"{\"actual_graph_batch_region\":true,\"wrapper_uses_caller_workspace\":false,\"external_output_elements\":"<<actual.size()<<",\"native_known_bytes\":"<<invocation.report(node)->float_workspace_bytes<<",\"checked\":true}\n";
 result.reset();done={};check(invocation.close().ok(),"close");check(invocation.drain().ok(),"drain");check(context.drain().ok(),"context drain");return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
