from pathlib import Path
import hashlib,json,re,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
PRODUCT=['include/hyle/compute/detail/batch_provider.h','src/compute_batch/batch_execution.cc','src/compute_provider_ggml/native_batch.cc','tests/compute_batch/workspace_test.cc','tests/compute_batch/CMakeLists.txt']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in PRODUCT:assert (ROOT/name).read_bytes()==(OUT/'candidate'/name).read_bytes(),name
native=json.loads((OUT.parent/'cpu-native-causal/cleanup-and-retain.json').read_text())['retain_for_future_cpu_work']
for r in native:assert rec(Path(r['path']))==r
libraries={}
for command in json.loads((OUT/'commands.json').read_text()):
 for arg in command['argv']:
  p=Path(arg)
  if p.is_absolute() and p.suffix=='.lib' and p.exists() and str(p) not in libraries:libraries[str(p)]=rec(p)
write(OUT/'source-identities.json',dict(baseline_policy_commit='50fcf099c',product=[dict(path=name,sha256=sha(ROOT/name),bytes=(ROOT/name).stat().st_size) for name in PRODUCT],baseline_policy_source=rec(OUT/'baseline-batch_execution.cc'),baseline_compile_header='Current frozen ABI3 header, not the baseline commit ABI2 header. This isolates old backing-allocation policy under the same current native slot/provider and avoids protocol mismatch.',native_unchanged=native,linked_cached_libraries=list(libraries.values())))
space={arm:json.loads((OUT/f'ffa4-space-{arm}.log').read_text().strip()) for arm in ['baseline','candidate']}
graph=json.loads((OUT/'ffa4-graph.log').read_text().strip())
summary={
 'problem':'Common BatchInvocation eagerly allocated max_float_workspace_bytes plus two max_int_workspace_bytes for CPU ggml, although its native plan ignores all three scratch views and owns/charges actual scratch separately. LeasePool::create immediately creates physical resource backing; it was not just a logical capacity.',
 'change':{
  'private_contract':'BatchProviderVTable appends uses_caller_workspace=true. CPU static table explicitly false; FlashInfer retains default true and existing full float/device-int/host-int allocations. Private extension version2→3 rejects mixed old/new tables before interpreting the new bit; no public option/API change and native CpuProgram ABI2 remains unchanged.',
  'core':'Only allocate/account optional scratch in common device/host pool capacities when required. Conditional views and F1 write admission at native submit, capture and pending receiver paths. Original output/metadata/staging, provider/lease ownership, original budget values, query lower bound and final actual-native-budget checks remain.',
  'boundaries':'CPU ragged/paged including Q8/window share this opt-out. Graph batch forwards the whole table and inherits it. FlashInfer genuinely consumes all three views; Apple/Vulkan materialized/native controllers do not implement this private BatchProviderVTable and are unaffected.',
 },
 'method':'Windows x64 MSVC14.50.35717 /O2 /MD /W4 /WX. Direct small host TU compilation; retained same-pin HYCA native baseline objects/AVX2 DLLs and shared foundation reused. No native kernel/SDK/full product rebuild, dependency download, throughput or latency experiment.',
 'validation':{
  'cpu_math_tests':'Both pins each4/4: ImplicitCausalPrefillUsesLogicalRowsAcrossLayoutChanges; ImplicitCausalPlanChargesActualWorkspaceWithoutMaskSeed; NativeFlashReadsTwoRequestsWithoutKvMaterialization; ColdBudgetAndPagedQualificationAreExplicit. The first FFA combined run also had a failing new mock fixture; its four CPU tests passed and were not rerun after mock-only changes.',
  'mock_final':'1/1 final. Default=true observes/writes all full-size float/device-int/host-int views in plan and float/device-int in run. False receives empty scratch views. Counted actual resource backings1,181,408→1,760B, difference1MiB+2×64KiB. Old extension2 query returns Unimplemented. Output ReadLease remains readable after control owners release.',
  'graph':graph,
  'budget':'CPU numerical test retains actual known1,269,488B; a budget1,269,487B is rejected specifically by final known-native-workspace check. Generic pool reduction does not lower, ignore or replace native budget admission.',
  'executor_identity':'Test logs identify the original retained matching pin AVX2 ABI2 DLL. Common host core/test/native-batch objects are shared between pin runs where pin-independent; provider and selector are compiled separately per pin.',
  'not_run':'Actual FlashInfer/CUDA batch runtime and command capture; only default=true core mock/source contract checked. No full test suite, Linux/macOS validation or pending-receiver fault matrix.',
 },
 'real_cpu_backing_example':{
  'shape':'F16 paged Q2048/logicalKV16384/H1/D64, two physical pages referenced1024 times. Same float128MiB/int8MiB budgets.',
  'baseline':space['baseline'],'candidate':space['candidate'],
  'backing_bytes_removed':space['baseline']['tracked_actual_pool_backing_bytes']-space['candidate']['tracked_actual_pool_backing_bytes'],
  'interpretation':'Actual generic pool requests151,266,920→271,976B, exactly144MiB removed. Separately prepared native plan remains1,269,488B on both arms; no attention execution for this large shape. Default64MiB float/8MiB int options would save80MiB per CPU slot by the same policy (derived, not a second sample).',
  'baseline_identity':'Old allocation-policy batch_execution.cc from50fcf099c compiled against the same current ABI3 header and current CPU opt-out table. It is not an old full binary/SDK comparison.',
  'counting_boundary':'StatsAllocator backs a host MemoryResource only for BatchInvocation creation, observing both actual pool backing requests. That custom carrier has no CPU CopyBatch physical-identity authority, so upload/native planning is a separate system_resource phase. No admission rule was bypassed or relaxed. Counts omit native/private C or global allocations, metadata not routed through that resource, RSS and peak resident.',
 },
 'retained_failures':[
  'First mock used the counted custom host resource for upload: existing CPU copy gate rejected mutable carrier without proven physical identity. Fixed fixture by separating counted creation from system-resource execution; product gate unchanged. Full source/log retained.',
  'Second mock tried reading1B from a128B full view. Fixed to explicit1B subview. Full source/log retained. Initial FFA four CPU tests passed despite mock failure; final mock-only run passed.',
 ],
 'artifacts':{'sources':'candidate/ and baseline-batch_execution.cc','identity':'source-identities.json','commands':'commands.json','cleanup':'cleanup-and-retain.json'},
}
write(OUT/'summary.json',summary)
delete=[rec(p) for p in OUT.rglob('*') if p.is_file() and p.suffix.lower() in ['.obj','.exe','.dll','.lib','.exp','.map','.pdb','.pyc']]
for p in [OUT.parent/'cpu-native-causal/__pycache__/build.cpython-312.pyc',OUT.parent/'cpu-hadamard/__pycache__/run.cpython-312.pyc']:
 if p.exists():delete.append(rec(p))
write(OUT/'cleanup-and-retain.json',dict(rule='Exact candidate manifest only; no deletion performed. Root writes test.ps1 and checks hashes. Only new small host objects/images/maps/import bytecode. Sources/logs/ZIP, four retained native objects/DLLs and shared foundation/cache are excluded.',delete_candidates=delete,delete_total_bytes=sum(r['bytes'] for r in delete),retain_for_future_cpu_work=native,retain_total_bytes=sum(r['bytes'] for r in native)))
files={p.relative_to(OUT).as_posix():p for p in OUT.rglob('*') if p.is_file() and p.name not in ['raw.zip','archive-record.json'] and p.suffix.lower() not in ['.obj','.exe','.dll','.lib','.exp','.map','.pdb','.pyc']}
for name in ['cpu-native-causal/build.py','cpu-hadamard/run.py','cpu-hadamard/test_main.cc']:files['reused/'+name]=OUT.parent/name
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
record=dict(path=(OUT/'raw.zip').relative_to(ROOT).as_posix(),bytes=(OUT/'raw.zip').stat().st_size,sha256=sha(OUT/'raw.zip'),members=len(files),note='Sources/commands/identities/all logs only; no obj/exe/DLL/lib/SDK.')
write(OUT/'archive-record.json',record)
print(json.dumps(dict(archive=record,cleanup_files=len(delete),delete_bytes=sum(r['bytes'] for r in delete)),indent=2))
