from pathlib import Path
import argparse,importlib.util,json,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('causal',OUT.parent/'cpu-native-causal/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.OUT=OUT;b.RECORDS=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
FILES=['include/hyle/compute/detail/batch_provider.h','src/compute_batch/batch_execution.cc','src/compute_provider_ggml/native_batch.cc','tests/compute_batch/workspace_test.cc','tests/compute_batch/CMakeLists.txt','src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_ggml/native_ragged_test.cc','src/graph_batch/batch.cc']
def freeze():
 for path in FILES:
  p=OUT/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/path).read_bytes())
 (OUT/'baseline-batch_execution.cc').write_bytes(subprocess.check_output(['git','show','50fcf099c:'+FILES[1]],cwd=ROOT))
 (OUT/'product.diff').write_bytes(subprocess.check_output(['git','diff','--',*FILES[:5]],cwd=ROOT))
def cfg(pin):
 c=dict(b.had.PINS[pin]);c['folder']=OUT/pin;c['folder'].mkdir(exist_ok=True)
 p=OUT.parent/'cpu-native-causal'/pin;c['module']=p/f'hyle_ggml_cpu_avx2_{pin}_causal_overlay.dll';c['native_baseline']=p/'native-baseline.obj';return c
def link(c,name,objects,graph=False,main=False):
 exe=c['folder']/(name+'.exe')
 b.run(c['folder'].name+'-'+name+'-link',[b.had.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(c['folder']/(name+'.map')),*objects,c['native_baseline'],*([b.had.BASE/'bin/hyle_graph.lib',b.had.BASE/'bin/hyle_graph_batch.lib'] if graph else []),*b.had.common_libs(c),b.had.BASE/'lib/gtest.lib',*([b.had.BASE/'lib/gtest_main.lib'] if main else []),*b.had.SYSTEM]);return exe
def build(pin):
 c=cfg(pin);f=c['folder'];s=OUT/'candidate'
 b.cpp(c,s/FILES[5],'provider')
 b.cpp(c,ROOT/'src/compute_ggml_runtime/cpu_program.cc','selector',['/DHYLE_GGML_CPU_AVX2_PROGRAM=1','/DHYLE_GGML_CPU_PROGRAM_LIBRARY="'+str(c['module']).replace('\\','/')+'"'])
 if pin=='ffa4':
  for source,name in [(s/FILES[1],'batch'),(s/FILES[2],'native-batch'),(s/FILES[3],'mock'),(s/FILES[6],'paged'),(s/FILES[7],'ragged'),(b.HAD/'test_main.cc','main')]:
   b.cpp(c,source,name,['/I'+str(ROOT/'tests/compute_batch'),'/I'+str(ROOT/'tests/compute_provider_ggml')])
 common=OUT/'ffa4'
 objects=[f/'provider.obj',f/'selector.obj',*[common/(n+'.obj') for n in ['batch','native-batch','paged','ragged','main']]]
 if pin=='ffa4':objects.append(f/'mock.obj')
 exe=link(c,'tests',objects)
 b.run(pin+'-tests',[exe,'--gtest_filter=BatchWorkspace.*:GgmlCpuPaged.ImplicitCausal*:GgmlCpuRagged.NativeFlashReadsTwoRequestsWithoutKvMaterialization:GgmlCpuRagged.ColdBudgetAndPagedQualificationAreExplicit'])
def space():
 c=cfg('ffa4');f=c['folder']
 b.cpp(c,OUT/'baseline-batch_execution.cc','batch-baseline')
 b.cpp(c,OUT/'space_probe.cc','space')
 for arm,batch in [('baseline','batch-baseline'),('candidate','batch')]:
  exe=link(c,'space-'+arm,[f/(n+'.obj') for n in [batch,'provider','native-batch','selector','space']])
  b.run('ffa4-space-'+arm,[exe])
def graph():
 c=cfg('ffa4');f=c['folder']
 b.cpp(c,OUT/'candidate'/FILES[8],'graph-batch')
 b.cpp(c,OUT/'graph_probe.cc','graph')
 exe=link(c,'graph',[f/(n+'.obj') for n in ['graph','graph-batch','batch','provider','native-batch','selector']],True)
 b.run('ffa4-graph',[exe])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','build','space','graph']);p.add_argument('--pin',choices=['ffa4','mixed'],default='ffa4');a=p.parse_args()
 if a.action=='freeze':freeze()
 elif a.action=='build':build(a.pin)
 elif a.action=='space':space()
 else:graph()
