from pathlib import Path
import ctypes as C
from ctypes import wintypes as W
import datetime
import json
import os
import struct
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
k = C.WinDLL('kernel32', use_last_error=True)
k.GetCurrentProcess.restype = W.HANDLE
k.SetProcessAffinityMask.argtypes = [W.HANDLE, C.c_size_t]
k.GetProcessAffinityMask.argtypes = [W.HANDLE, C.POINTER(C.c_size_t), C.POINTER(C.c_size_t)]
k.GetPriorityClass.argtypes = [W.HANDLE]
k.OpenThread.argtypes = [W.DWORD, W.BOOL, W.DWORD]
k.OpenThread.restype = W.HANDLE
k.CloseHandle.argtypes = [W.HANDLE]
k.CreateToolhelp32Snapshot.argtypes = [W.DWORD, W.DWORD]
k.CreateToolhelp32Snapshot.restype = W.HANDLE

class ThreadEntry(C.Structure):
    _fields_ = [('size', W.DWORD), ('usage', W.DWORD), ('tid', W.DWORD), ('pid', W.DWORD), ('base_priority', W.LONG), ('delta_priority', W.LONG), ('flags', W.DWORD)]

class GroupAffinity(C.Structure):
    _fields_ = [('mask', C.c_size_t), ('group', W.WORD), ('reserved', W.WORD * 3)]

k.Thread32First.argtypes = [W.HANDLE, C.POINTER(ThreadEntry)]
k.Thread32Next.argtypes = [W.HANDLE, C.POINTER(ThreadEntry)]
k.GetThreadGroupAffinity.argtypes = [W.HANDLE, C.POINTER(GroupAffinity)]

length = W.ULONG()
k.GetSystemCpuSetInformation(None, 0, C.byref(length), None, 0)
buf = C.create_string_buffer(length.value)
if not k.GetSystemCpuSetInformation(buf, length, C.byref(length), None, 0):
    raise C.WinError(C.get_last_error())
cpus = []
pos = 0
while pos < length.value:
    size, kind = struct.unpack_from('II', buf.raw, pos)
    if size == 0:
        raise RuntimeError('invalid CPU-set record')
    if kind == 0:
        ident, group, logical, core, llc, numa, eff, flags = struct.unpack_from('IHBBBBBB', buf.raw, pos + 8)
        cpus.append(dict(id=ident, group=group, logical=logical, core=core, llc=llc, numa=numa, efficiency_class=eff, flags=flags))
    pos += size
best = max(c['efficiency_class'] for c in cpus if c['group'] == 0)
selected = []
for cpu in cpus:
    if cpu['group'] == 0 and cpu['efficiency_class'] == best and cpu['core'] not in {c['core'] for c in selected}:
        selected.append(cpu)
selected = selected[:8]
assert len(selected) == 8 and len({c['core'] for c in selected}) == 8
mask = sum(1 << c['logical'] for c in selected)
if not k.SetProcessAffinityMask(k.GetCurrentProcess(), mask):
    raise C.WinError(C.get_last_error())
freq = C.c_longlong()
if not k.QueryPerformanceFrequency(C.byref(freq)):
    raise C.WinError(C.get_last_error())
metadata = dict(all_cpu_sets=cpus, selected_cpu_sets=selected, mask=hex(mask), qpc_frequency_hz=freq.value, qpc_tick_seconds=1/freq.value, resources='Caller plus 4 producers and 4 consumers. One common inherited process affinity mask; workers have no singleton pin. OS may schedule any selected logical CPU. Caller joins workers. ABOVE_NORMAL process priority.', clock='nanobench chooses high_resolution_clock only if steady, else steady_clock; MSVC steady_clock uses QPC. QPC tick is distinct from cross-epoch or cross-process variation.')
(HERE / 'host.json').write_text(json.dumps(metadata, indent=2) + '\n')

nt = C.WinDLL('ntdll', use_last_error=True)
nt.NtGetNextThread.argtypes = [W.HANDLE, W.HANDLE, W.DWORD, W.ULONG, W.ULONG, C.POINTER(W.HANDLE)]
nt.NtGetNextThread.restype = W.LONG
k.GetThreadId.argtypes = [W.HANDLE]
k.GetThreadId.restype = W.DWORD

def threads(process):
    result = []
    current = W.HANDLE()
    while True:
        following = W.HANDLE()
        status = nt.NtGetNextThread(int(process._handle), current, 0x0040, 0, 0, C.byref(following))
        if current:
            k.CloseHandle(current)
        current = following
        if status < 0:
            if status != -2147483622:  # STATUS_NO_MORE_ENTRIES
                result.append(dict(enumeration_error=hex(status & 0xffffffff)))
            break
        affinity = GroupAffinity()
        valid = bool(k.GetThreadGroupAffinity(current, C.byref(affinity)))
        result.append(dict(tid=k.GetThreadId(current), group=affinity.group if valid else None, mask=hex(affinity.mask) if valid else None, affinity_read=valid, read_error=C.get_last_error() if not valid else 0))
    return result

def run(name, order, smoke=False, aa=None, resources=False):
    opts = dict(HYLE_QUEUE_BENCH_FILTER='bounded-mpmc', HYLE_BENCH_JSON=str(HERE / (name + '.epochs.json')))
    if order == 'ba':
        opts['HYLE_BENCH_RIVAL_FIRST'] = '1'
    if smoke:
        opts['HYLE_BENCH_SMOKE'] = '1'
    if aa:
        opts['HYLE_BENCH_AA_ROUTE'] = aa
    env = {key: value for key, value in os.environ.items() if not key.startswith(('HYLE_BENCH_', 'HYLE_QUEUE_BENCH_', 'HYLE_PERF_'))}
    env.update(opts)
    begin = time.time()
    cmd = [str(HERE / 'queue.exe')]
    process = subprocess.Popen(cmd, cwd=HERE, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
    pmask, smask = C.c_size_t(), C.c_size_t()
    if not k.GetProcessAffinityMask(int(process._handle), C.byref(pmask), C.byref(smask)):
        raise C.WinError(C.get_last_error())
    priority = k.GetPriorityClass(int(process._handle))
    snapshots = []
    if smoke or resources:
        while process.poll() is None:
            snap = threads(process)
            if len(snapshots) < 128:
                snapshots.append(dict(unix=time.time(), threads=snap))
            time.sleep(0.001)
    stdout, stderr = process.communicate(timeout=60)
    record = dict(name=name, command=cmd, overrides=opts, pid=process.pid, returncode=process.returncode, begin_utc=datetime.datetime.fromtimestamp(begin, datetime.timezone.utc).isoformat(), end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), elapsed_wall_seconds=time.time()-begin, process_affinity=hex(pmask.value), system_affinity=hex(smask.value), priority_class=priority, resource_snapshots=snapshots, snapshot_scope='Diagnostic process only: NtGetNextThread live handles, each affinity read while handle remains open; no cumulative exited TID count. Formal timings had no monitor. Process affinity inherited from restricted parent and checked on child.')
    (HERE / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    (HERE / (name + '.stdout.txt')).write_bytes(stdout)
    (HERE / (name + '.stderr.txt')).write_bytes(stderr)
    print(name, process.returncode, stdout.decode(errors='replace'), stderr.decode(errors='replace'), flush=True)
    assert pmask.value == mask and priority == 0x8000
    if process.returncode:
        raise SystemExit(process.returncode)
    if smoke or resources:
        assert snapshots and any(t['affinity_read'] for s in snapshots for t in s['threads']), 'Did not capture live affinities; review before formal.'
        assert all(t['mask'] == hex(mask) for s in snapshots for t in s['threads'] if t['affinity_read'])

mode = sys.argv[1]
if mode == 'smoke':
    run('smoke-resource-ab', 'ab', smoke=True)
elif mode == 'formal':
    for i, order in enumerate(['ab', 'ba', 'ab', 'ba'], 1):
        run('formal-' + str(i) + '-' + order, order)
elif mode == 'aa':
    run('aa-candidate', 'ab', aa='candidate')
elif mode == 'resources':
    run('resource-live-handles-ab', 'ab', resources=True)
else:
    raise SystemExit('smoke | formal | aa')
