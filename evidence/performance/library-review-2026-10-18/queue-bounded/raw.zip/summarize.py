from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]

def load(name):
    return json.loads((HERE / name).read_text(encoding='utf-8-sig'))

formal = []
windows = []
for i, order in enumerate(['ab', 'ba', 'ab', 'ba'], 1):
    name = 'formal-' + str(i) + '-' + order
    data = load(name + '.epochs.json')['results']
    assert len(data) == 2 and all(len(x['measurements']) == 11 for x in data)
    assert all(m['iterations'] == 2 for x in data for m in x['measurements'])
    by_name = {x['name']: x for x in data}
    hyle = by_name['HYLE BoundedQueue']
    peer = by_name['rigtorp MPMCQueue (bounded ring)']
    hm = hyle['median(elapsed)'] * 1e9 / 200000
    pm = peer['median(elapsed)'] * 1e9 / 200000
    for x in data:
        windows.extend(m['elapsed'] * m['iterations'] for m in x['measurements'])
    formal.append(dict(process=name, order=order, hyle_ns_per_transferred_item=hm, rigtorp_ns_per_transferred_item=pm, hyle_time_over_rigtorp=hm/pm, hyle_lower_time_percent=100*(1-hm/pm), hyle_epoch_MAPE=hyle['medianAbsolutePercentError(elapsed)'], rigtorp_epoch_MAPE=peer['medianAbsolutePercentError(elapsed)'], hyle_median_episode_seconds=hyle['median(elapsed)'], rigtorp_median_episode_seconds=peer['median(elapsed)']))
aa = load('aa-candidate.epochs.json')['results']
diag = load('resource-live-handles-ab.process.json')
snapshots = diag['resource_snapshots']
live_counts = [sum(t.get('affinity_read', False) for t in s['threads']) for s in snapshots]
source = ROOT / 'bench/container/queue_sota_bench.cc'
assert source.read_bytes() == (HERE / 'queue_sota_bench.cc').read_bytes()
base = subprocess.check_output(['git', 'show', 'HEAD:bench/container/queue_sota_bench.cc'], cwd=ROOT)
current = source.read_bytes()
start = b'// ---- 3. work-stealing OWNER'
end = b'int main() {'
assert base[base.index(start):base.index(end)] == current[current.index(start):current.index(end)]
(HERE / 'benchmark.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'bench/container/queue_sota_bench.cc'], cwd=ROOT))
summary = dict(
    conclusion='Current 4P/4C bounded cold trace did not reproduce a Hyle slower result in four AB/BA processes. This is not a stable overall queue ranking, equivalence conclusion, or warm-operation result. No queue implementation change.',
    method=dict(trace='200000 distinct uint64 ids 1..200000; 4 producers x50000, 4 consumers; usable capacity1024 on each side. Producer full retries and consumer pre-done empty retries yield. After acquire all-done each consumer retries pop before accepting empty. Per-consumer local count/sum/xor aggregated after join; mismatch aborts. No shared per-item checksum counter.', interval='Each iteration includes construction/allocation, sequential creation of 8 std::threads, all transfers, join, conservation check, thread vector destruction and queue destruction. One transfer is reported per batch item; original console unit label op means an item passed through push+pop, not an individual try call.', schedule='One process per AB or BA: AB, BA, AB, BA. Each arm has one untimed warmup cold episode followed by 11 epochs x2 complete cold episodes. Raw JSON elapsed is seconds per episode; actual epoch window = elapsed * iterations. No sample trimming, no old launcher, no background monitor during formal.', fairness='Both default fixed-ring libraries and their default allocation/slot-layout/destruction costs are included. Hyle uses SystemAllocator; rigtorp uses its default aligned allocator and allocates capacity+1 slots while usable remains1024. This does not isolate queue CAS costs. No producer tokens, queue growth, sharded capacity, or moodycamel rows enter this comparison.'),
    results=formal,
    same_path_AA=dict(process='aa-candidate', actual_implementations=['Hyle BoundedQueue', 'Hyle BoundedQueue'], labels=[x['name'] for x in aa], ns_per_item=[x['median(elapsed)'] * 1e9/200000 for x in aa], epoch_MAPE=[x['medianAbsolutePercentError(elapsed)'] for x in aa], second_arm_lower_time_percent=100*(1-aa[1]['median(elapsed)']/aa[0]['median(elapsed)']), limitation='Only one same-path process, no CI. The second peer-named label calls BoundedQueue too. Do not subtract this drift from AB results or assign its cause. First AA arm was flagged unstable by nanobench and retained.'),
    clock=dict(qpc_frequency_hz=load('host.json')['qpc_frequency_hz'], qpc_tick_seconds=load('host.json')['qpc_tick_seconds'], nanobench_reported_clock_resolution_seconds=aa[0]['clockResolution'], shortest_formal_epoch_window_seconds=min(windows), shortest_formal_window_qpc_ticks=round(min(windows)*load('host.json')['qpc_frequency_hz']), limitation='Hardware QPC tick and empirical nanobench clock resolution are separate from epoch/process variation. Millisecond epoch windows do not make the observed variation a hardware timer-resolution result.'),
    resources=dict(configured='8 queue workers plus caller. Actual process mask0x5555 selects one logical processor on each of8 distinct physical cores, actual Windows EfficiencyClass1; no worker singleton pin. ABOVE_NORMAL process priority, verified child mask/priority for every formal process. All32 OS logical processors remain available to unrelated processes.', actual_diagnostic='resource-live-handles-ab is a separate monitored, non-ranking process. 128 live-handle snapshots over about0.254s; each affinity was read with its thread handle open. They are not accumulated exited TIDs and are not formal-process snapshots.', observed_live_thread_count_values=sorted(set(live_counts)), observed_peak_live_threads=max(live_counts), read_masks=sorted({t['mask'] for s in snapshots for t in s['threads'] if t.get('affinity_read')}), additional_threads='Peak12 exceeds the9 explicitly requested by benchmark code. Three additional observed threads were not attributed to a runtime component; no claim that only9 OS threads existed.', limits='Live snapshot cap covers the early part of the separate process, not a continuous per-arm thread census. Formal thread resources are established by identical source construction and verified inherited process mask; diagnostic is supplementary and cannot retroactively prove formal worker snapshots.'),
    retained_negative_points=['Formal Hyle medians vary60.70..78.99ns/item across processes; peer70.71..85.41ns/item. The final BA gap is only0.424%.', 'One BoundedQueue A/A process has73.29 versus64.49ns/item; its first arm has12.2% within-process MAPE.', 'Initial smoke-ab benchmark exit0 but driver assertion failed because no all-worker Toolhelp snapshot survived. Second smoke-resource-ab exit0 also only captured exited thread records.', 'resource-diagnostic-ab Toolhelp snapshots take longer than individual worker lifetimes:4 live handles in early snapshots, other query attempts ERROR_INVALID_PARAMETER87. This failed worker observation is retained. Later live-handle observation is separate, not a replacement of formal data.'],
    scope='All smoke/formal/AA/resource benchmark processes exit0, so every executed episode passed count/sum/xor. Those checks are not an exhaustive linearizability or exact-uniqueness proof. Only the benchmark TU and nanobench implementation TU rebuilt with MSVC19.50.35728 /O2 /MD, HYLE_TESTING not defined; static foundation libs reused with recorded hashes. No full project build, SPSC/Sharded/Moody/TBB/warm-throughput/more shapes, or queue product edits.',
    source_identity=load('identity.json'),
    system=load('system.json'),
    eol=dict(base_crlf=base.count(b'\r\n'), base_lf=base.count(b'\n'), current_crlf=current.count(b'\r\n'), current_lf=current.count(b'\n'), untouched_owner_through_vector_section_byte_identical=True))
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(HERE / 'resource-observation-notes.json').write_text(json.dumps(dict(initial_smoke_driver_error='AssertionError: Did not capture all 8 live workers; retain diagnostic and review before formal.', initial_smoke_benchmark_exit=0, later_assertion_correction='A short-lived cold episode cannot guarantee simultaneous survival of all8 workers through a slow whole-system snapshot. No benchmark start barrier was added.', toolhelp_diagnostic='All unsuccessful queries and snapshots preserved; native live-handle diagnostic run once afterward. No additional formal timing processes.'), indent=2) + '\n')
# Only small source, commands, raw measurements and logs; never archive libraries,
# SDKs, executable, objects or the archive itself.
suffixes = {'.py', '.cc', '.h', '.json', '.txt', '.log', '.diff'}
paths = sorted(p for p in HERE.iterdir() if p.is_file() and p.suffix in suffixes and p.name not in {'archive-record.json', 'manifest.json'})
(HERE / 'manifest.json').write_text(json.dumps([dict(path=p.name, bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths], indent=2) + '\n')
with zipfile.ZipFile(HERE / 'raw.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in [*paths, HERE / 'manifest.json']:
        z.write(p, p.name)
archive = HERE / 'raw.zip'
record = dict(path=str(archive), bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=len(paths)+1, binaries_included=False)
(HERE / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
