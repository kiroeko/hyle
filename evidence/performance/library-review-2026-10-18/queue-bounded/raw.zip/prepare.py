from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
env['VSLANG'] = '1033'
source = ROOT / 'bench/container/queue_sota_bench.cc'
peer = ROOT.parent / 'rigtorp-MPMCQueue/include/rigtorp/MPMCQueue.h'
foundation = ROOT / '.scratch/build-compute-v2-dev/bin'
libs = [foundation / (name + '.lib') for name in ['hyle_platform_thread', 'hyle_platform', 'hyle_time', 'hyle_mem', 'mimalloc_static', 'hyle_error']]
nanobench = HERE / 'nanobench.obj'
records = []

def run(name, argv):
    start = time.time()
    result = subprocess.run([str(x) for x in argv], cwd=HERE, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45)
    (HERE / (name + '.log')).write_bytes(result.stdout)
    records.append(dict(name=name, argv=[str(x) for x in argv], returncode=result.returncode, begin_unix=start, end_unix=time.time()))
    (HERE / 'build-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace'))
        raise SystemExit(result.returncode)

(HERE / 'queue_sota_bench.cc').write_bytes(source.read_bytes())
(HERE / 'bounded_queue.h').write_bytes((ROOT / 'include/hyle/container/bounded_queue.h').read_bytes())
(HERE / 'rigtorp-MPMCQueue.h').write_bytes(peer.read_bytes())
run('compile', [CL, '/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus', '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/DHYLE_STATIC', '/DHYLE_BENCH_RIGTORP', '/I' + str(ROOT / 'include'), '/external:I' + str(ROOT / 'third_party/nanobench'), '/external:I' + str(peer.parents[1]), '/external:W0', source, '/Fo' + str(HERE / 'queue.obj')])
run('compile-nanobench', [CL, '/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus', '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/external:I' + str(ROOT / 'third_party/nanobench'), '/external:W0', ROOT / 'bench/nanobench_impl.cc', '/Fo' + str(nanobench)])
run('link', [CL.with_name('link.exe'), '/nologo', '/INCREMENTAL:NO', '/OPT:REF', '/OUT:' + str(HERE / 'queue.exe'), HERE / 'queue.obj', nanobench, *libs, 'advapi32.lib', 'bcrypt.lib', 'Synchronization.lib'])
paths = [source, ROOT / 'include/hyle/container/bounded_queue.h', peer, ROOT / 'third_party/nanobench/nanobench.h', ROOT / 'bench/nanobench_impl.cc', CL, nanobench, *libs, HERE / 'queue.exe']
identity = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), peer_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=peer.parents[2], text=True).strip(), peer_status=subprocess.check_output(['git', 'status', '--short'], cwd=peer.parents[2], text=True), files=[dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths], limitations='Only benchmark and nanobench implementation TUs rebuilt; queue implementations are header-only. Existing static foundation cache reused. No SDK staging or whole-project build.')
(HERE / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
