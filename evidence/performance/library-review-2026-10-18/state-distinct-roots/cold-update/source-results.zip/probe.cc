#define NOMINMAX
#include <Windows.h>

#include "hyle/compute/state_versions.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

namespace c = hyle::compute;
namespace m = hyle::mem;

namespace {
constexpr unsigned kEntries = 1024;
constexpr unsigned kPerPool = kEntries / 2;
constexpr std::size_t kBlockBytes = 64;
constexpr std::size_t kPoolBytes = (kPerPool + 1) * kBlockBytes;
constexpr unsigned kEpochs = 9;
constexpr unsigned kEpisodes = 128;
constexpr unsigned kWarmEpisodes = 16;

void require(bool ok, const char *message) {
  if (!ok) {
    std::fprintf(stderr, "oracle failure: %s\n", message);
    std::exit(2);
  }
}

template <class T> T take(hyle::Result<T> result, const char *message) {
  require(result.has_value(), message);
  return std::move(*result);
}

std::int64_t qpc() {
  LARGE_INTEGER value{};
  require(QueryPerformanceCounter(&value) != 0, "QueryPerformanceCounter");
  return value.QuadPart;
}

std::uint64_t checksum(const c::StateStoreStats &s) {
  std::uint64_t value = 1469598103934665603ULL;
  const auto mix = [&](std::uint64_t field) {
    value = (value ^ field) * 1099511628211ULL;
  };
  mix(s.versions); mix(s.drafts); mix(s.retained_blocks); mix(s.backing_roots);
  mix(s.registered_clone_slots); mix(s.active_clones); mix(s.backing_bytes);
  mix(s.host_snapshot_bytes); mix(s.clone_capacity_bytes); mix(s.closed);
  return value;
}

struct Fixture {
  c::StateSchema schema;
  std::vector<c::StateEntryId> ids;
  std::array<c::LeasePool, 2> pools;
  c::StateStore store;
  c::StateVersion current;
  std::array<std::byte, kEntries> expected{};
  std::uint64_t updates = 0;

  Fixture() {
    const auto desc = take(c::TensorDesc::dense(c::DataType::kFloat32,
                               std::array<std::int64_t, 1>{16}), "description");
    schema = take(c::StateSchema::create(std::vector<c::StateEntrySpec>(
                      kEntries, {.description = desc})), "schema");
    store = take(c::StateStore::create(schema,
                     {.max_versions = 2, .max_drafts = 1, .max_clone_slots = 1,
                      .max_retained_blocks = kEntries + 1,
                      .max_backing_bytes = 2 * kPoolBytes}), "store");
    for (auto &pool : pools)
      pool = take(c::LeasePool::create(m::system_resource(), kPoolBytes,
                     {.max_blocks = kPerPool + 1, .backing_alignment = 64}), "pool");
    ids.reserve(kEntries);
    std::vector<c::StateMember> members;
    members.reserve(kEntries);
    for (unsigned i = 0; i < kEntries; ++i) {
      ids.push_back(take(schema.entry(i), "entry"));
      expected[i] = std::byte(i & 255);
      auto writer = take(pools[i % 2].allocate(kBlockBytes, 64), "initial block");
      require(take(writer.view(), "initial write view").fill(expected[i]).ok(), "initial fill");
      members.push_back({ids.back(), take(writer.publish(), "initial publish")});
    }
    current = take(store.import(members), "interleaved import");
    members.clear();
    check_all_members();
    check_stats();
  }

  static void check_member(const c::StateVersion &version, const c::StateEntryId &id,
                           std::byte expected_value) {
    auto lease = take(version.member(id), "member");
    std::array<std::byte, kBlockBytes> bytes{};
    require(take(lease.view(), "member view").read(bytes).ok(), "read member");
    for (auto value : bytes)
      require(value == expected_value, "complete 64-byte member payload");
  }

  void check_all_members() const {
    for (unsigned i = 0; i < kEntries; ++i)
      check_member(current, ids[i], expected[i]);
  }

  std::uint64_t check_stats() const {
    const auto s = store.stats();
    require(s.versions == 1 && s.drafts == 0 && s.retained_blocks == kEntries &&
                s.backing_roots == 2 && s.registered_clone_slots == 0 &&
                s.active_clones == 0 && s.backing_bytes == 2 * kPoolBytes &&
                s.host_snapshot_bytes == 0 && s.clone_capacity_bytes == 0 && !s.closed,
            "complete public store stats");
    for (unsigned i = 0; i < 2; ++i) {
      const auto pool = pools[i].stats();
      const auto retired = (updates + (i == 0 ? 1 : 0)) / 2;
      require(pool.capacity_bytes == kPoolBytes &&
                  pool.allocated_bytes == kPerPool * kBlockBytes &&
                  pool.live_blocks == kPerPool && pool.max_blocks == kPerPool + 1 &&
                  pool.active_uses == 0 && pool.reclaimed_blocks == retired &&
                  pool.peak_bytes <= kPoolBytes && !pool.closed,
              "fixed pool capacity/live blocks and exact one-block retirement");
    }
    return checksum(s);
  }

  std::uint64_t episode() {
    // Update entry0/pool0, then entry1/pool1, alternately. A replacement stays
    // in its original pool, so each endpoint always has512 live blocks per root.
    const auto entry = unsigned(updates % 2);
    const auto old_value = expected[entry];
    const auto new_value = std::byte((updates + 17) & 255);
    auto writer = take(pools[entry].allocate(kBlockBytes, 64), "replacement block");
    require(take(writer.view(), "replacement write view").fill(new_value).ok(), "replacement fill");
    auto replacement = take(writer.publish(), "replacement publish");
    auto draft = take(store.begin(current), "begin");
    require(draft.replace(ids[entry], replacement).ok(), "replace one entry");
    auto next = take(draft.finalize(), "finalize");
    check_member(current, ids[entry], old_value);
    check_member(next, ids[entry], new_value);
    current.reset();
    draft = {};
    replacement.reset();
    current = std::move(next);
    require(store.collect().ok(), "collect old block");
    expected[entry] = new_value;
    ++updates;
    return check_stats();
  }
};
} // namespace

int main(int argc, char **argv) {
  const bool smoke = argc == 2 && std::strcmp(argv[1], "--smoke") == 0;
  require(argc == 1 || smoke, "arguments");
  constexpr DWORD_PTR mask = DWORD_PTR{1} << 4;
  DWORD_PTR available = 0, system_mask = 0;
  require(GetProcessAffinityMask(GetCurrentProcess(), &available, &system_mask) != 0 &&
              (available & mask), "LP4 available");
  require(SetProcessAffinityMask(GetCurrentProcess(), mask) != 0, "pin LP4");
  DWORD_PTR actual = 0;
  require(GetProcessAffinityMask(GetCurrentProcess(), &actual, &system_mask) != 0 &&
              actual == mask && GetCurrentProcessorNumber() == 4, "read back LP4");
  LARGE_INTEGER frequency{};
  require(QueryPerformanceFrequency(&frequency) != 0, "QPC frequency");
  auto previous = qpc();
  auto minimum = INT64_MAX;
  for (unsigned i = 0; i < 10000; ++i) {
    const auto now = qpc();
    if (now > previous) minimum = (std::min)(minimum, now - previous);
    previous = now;
  }
  require(minimum != INT64_MAX, "QPC positive step");
  std::printf("{\"event\":\"identity\",\"pid\":%lu,\"affinity_mask\":%llu,"
              "\"logical_processor\":%lu,\"process_priority\":%lu,\"thread_priority\":%d,"
              "\"qpc_frequency_hz\":%lld,\"qpc_observed_min_step_ticks\":%lld,"
              "\"qpc_observed_min_step_ns\":%.9f,\"smoke\":%s}\n",
              GetCurrentProcessId(), static_cast<unsigned long long>(actual),
              GetCurrentProcessorNumber(), GetPriorityClass(GetCurrentProcess()),
              GetThreadPriority(GetCurrentThread()), frequency.QuadPart, minimum,
              double(minimum) * 1e9 / double(frequency.QuadPart), smoke ? "true" : "false");
  Fixture fixture;
  std::uint64_t sum = 0;
  for (unsigned i = 0; i < kWarmEpisodes; ++i) sum += fixture.episode();
  fixture.check_all_members();
  if (smoke) {
    for (unsigned i = 0; i < 32; ++i) sum += fixture.episode();
  } else {
    for (unsigned epoch = 0; epoch < kEpochs; ++epoch) {
      const auto start = qpc();
      for (unsigned i = 0; i < kEpisodes; ++i) sum += fixture.episode();
      const auto ticks = qpc() - start;
      require(ticks > 0, "positive episode batch duration");
      std::printf("{\"event\":\"epoch\",\"sequence\":%u,\"epoch\":%u,\"episodes\":%u,"
                  "\"updates\":%llu,\"ticks\":%lld,\"actual_ns\":%.9f,"
                  "\"ns_per_episode\":%.9f,\"checksum\":%llu}\n", epoch, epoch,
                  kEpisodes, static_cast<unsigned long long>(fixture.updates), ticks,
                  double(ticks) * 1e9 / double(frequency.QuadPart),
                  double(ticks) * 1e9 / double(frequency.QuadPart) / kEpisodes,
                  static_cast<unsigned long long>(sum));
      fixture.check_all_members(); // Outside QPC; does not call stats or mutate ledger.
    }
  }
  fixture.check_all_members();
  fixture.check_stats();
  std::printf("{\"event\":\"oracle\",\"entries\":%u,\"roots\":2,"
              "\"max_retained_blocks\":%u,\"pool_capacity_bytes_each\":%zu,"
              "\"steady_live_blocks_each\":%u,\"updates\":%llu,"
              "\"all_fields_payloads_retirements\":true,\"checksum\":%llu}\n",
              kEntries, kEntries + 1, kPoolBytes, kPerPool,
              static_cast<unsigned long long>(fixture.updates),
              static_cast<unsigned long long>(sum));
}
