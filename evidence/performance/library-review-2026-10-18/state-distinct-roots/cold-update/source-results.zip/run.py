from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent
ROOT = HERE.parents[3]
CACHE = ROOT / '.scratch/build-compute-v2-dev'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

cache = {}
for line in (CACHE / 'CMakeCache.txt').read_text(encoding='utf-8-sig').splitlines():
    if '=' in line and not line.startswith(('#', '//')):
        key, value = line.split('=', 1)
        cache[key.split(':', 1)[0]] = value
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
commands_file = HERE / 'commands.json'
records = json.loads(commands_file.read_text()) if commands_file.exists() else []
old = json.loads((PRIOR / 'v1/commands.json').read_text())
v2 = json.loads((PRIOR / 'v2/commands.json').read_text())


def run(name, argv):
    assert not (HERE / (name + '.stdout.txt')).exists(), 'Do not overwrite previous output.'
    argv = list(map(str, argv))
    start = time.perf_counter()
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=HERE, env=env, capture_output=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_bytes(result.stdout)
    (HERE / (name + '.stderr.txt')).write_bytes(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(HERE), started_utc=started,
                        ended_utc=datetime.now(timezone.utc).isoformat(),
                        wall_seconds=time.perf_counter()-start, exit=result.returncode))
    commands_file.write_text(json.dumps(records, indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:])
        print(result.stderr.decode(errors='replace')[-6000:])
        raise SystemExit(result.returncode)


if sys.argv[1] == 'build':
    identities = json.loads((PRIOR / 'v2/identity.json').read_text())
    for item in identities['reused_v1_objects'][:1] + identities['new_artifacts'][:1]:
        path = Path(item['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
    compile_command = next(r['argv'] for r in old if r['name'] == 'probe-compile-retry1')
    compile_command = [a.replace(str(PRIOR / 'probe.cc'), str(HERE / 'probe.cc'))
                        .replace(str(PRIOR / 'probe.obj'), str(HERE / 'probe.obj'))
                       for a in compile_command]
    run('compile', compile_command)
    link_command = next(r['argv'] for r in v2 if r['name'] == 'candidate-v2-link')
    for variant in ('baseline', 'candidate'):
        state_obj = PRIOR / 'baseline.obj' if variant == 'baseline' else PRIOR / 'v2/candidate-v2.obj'
        argv = [('/OUT:' + str(HERE / (variant + '.exe'))) if a.startswith('/OUT:') else
                a.replace(str(PRIOR / 'v2/candidate-v2.obj'), str(state_obj))
                 .replace(str(PRIOR / 'probe.obj'), str(HERE / 'probe.obj'))
                for a in link_command]
        run(variant + '-link', argv)
elif sys.argv[1] == 'smoke':
    for variant in ('baseline', 'candidate'):
        run(variant + '-smoke', [HERE / (variant + '.exe'), '--smoke'])
elif sys.argv[1] == 'formal':
    for sequence, variant in enumerate(('baseline', 'candidate', 'candidate', 'baseline'), 1):
        run(f'formal-{sequence}-{variant}', [HERE / (variant + '.exe')])
else:
    raise SystemExit('build, smoke or formal')
