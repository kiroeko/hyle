from pathlib import Path
import hashlib
import json
import shutil
import zipfile

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent
ROOT = HERE.parents[3]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


processes = json.loads((HERE / 'processed-processes.json').read_text())
commands = json.loads((HERE / 'commands.json').read_text())
plan = json.loads((HERE / 'plan.json').read_text())
assert len(commands) == 9 and all(row['exit'] == 0 for row in commands)
assert [row['variant'] for row in processes] == ['baseline', 'candidate', 'candidate', 'baseline']
for row in processes:
    assert len(row['epochs']) == 9 and row['oracle']['updates'] == 1168
    assert row['oracle']['all_fields_payloads_retirements']
    assert row['identity']['affinity_mask'] == 16 and row['identity']['logical_processor'] == 4
for variant in ('baseline', 'candidate'):
    rows = [json.loads(line) for line in (HERE / (variant + '-smoke.stdout.txt')).read_text().splitlines()]
    assert len(rows) == 2 and rows[-1]['updates'] == 48
    assert rows[-1]['all_fields_payloads_retirements']
assert all(sha(HERE / name) == value for name, value in plan['source_sha256'].items())

previous_identity = json.loads((PRIOR / 'v2/identity.json').read_text())
reused = [PRIOR / 'baseline.obj', PRIOR / 'v2/candidate-v2.obj']
expected = [previous_identity['reused_v1_objects'][0], previous_identity['new_artifacts'][0]]
assert all(sha(path) == record['sha256'] for path, record in zip(reused, expected))
assert sha(ROOT / 'src/compute_state/state_versions.cc') == 'eef0d5ee35c8de6c0810846bd2bc959010a88ddb9bd827c6322a8b20c4e56b61'
assert sha(ROOT / 'tests/compute_state/state_versions_test.cc') == '389602c1f6008b439362e268eee8427d44464592b5ea6fee9d8638e80c86ade3'
frozen = HERE / 'frozen'
frozen.mkdir()
for source, name in [
    (PRIOR / 'state_versions.baseline.cc', 'state_versions.baseline.cc'),
    (PRIOR / 'v2/state_versions.candidate-v2.cc', 'state_versions.candidate-v2.cc'),
    (PRIOR / 'v1/state_internal.h', 'state_internal.h'),
]:
    shutil.copyfile(source, frozen / name)

link = next(row['argv'] for row in commands if row['name'] == 'candidate-link')
libraries = [Path(arg) for arg in link if arg.lower().endswith('.lib') and Path(arg).is_absolute()]
compiler = Path(next(row['argv'][0] for row in commands if row['name'] == 'compile'))
identities = dict(
    probe_source=identity(HERE / 'probe.cc'), runner_source=identity(HERE / 'run.py'),
    compiler=identity(compiler), reused_state_objects=[identity(path) for path in reused],
    frozen_state_sources=[identity(path) for path in frozen.iterdir()],
    cached_foundation=[identity(path) for path in libraries],
    current_canonical_source=identity(ROOT / 'src/compute_state/state_versions.cc'),
    unchanged_test_source=identity(ROOT / 'tests/compute_state/state_versions_test.cc'),
    public_headers=[identity(ROOT / path) for path in [
        'include/hyle/compute/state_versions.h', 'include/hyle/compute/resource_leases.h',
        'scripts/hyle_environment.py']],
    build_scope='One fresh probe TU, then link reused baseline/v2 StateVersions objects and cached foundation. No CMake configure/build, native/foundation rebuild or SDK copy/download.')
save('identity.json', identities)

summary = dict(
    conclusion='At this fixed complete single-entry update episode, no obvious regression was observed. This does not establish zero sorting overhead or equal cost for every capacity/update pattern.',
    parameters=plan['parameters'], timed=plan['episode_in_timing'],
    outside_timing=plan['fixed_measurement']['outside_timing'],
    smoke='Both arms passed 16 warm plus 32 untimed complete episodes.',
    formal='Exactly old/new/new/old: each process 16 warm plus 9 epochs of 128 timed episodes. All 36 epochs preserved in order; no AA, new shape, sample rejection or rerun.',
    ownership='Each completed episode retains one version, no draft, 1024 blocks and two roots; each pool has 512 live blocks and 32832 B capacity. Each update retires exactly one old block, checked via both pool counters.',
    actual_identity='All formal processes read back LP4 mask16/current CPU4, normal priority32/thread0, QPC10MHz and minimum observed positive step1 tick/100ns. PIDs and original identity records remain.',
    process_results=[{key: value for key, value in row.items() if key not in ('epochs', 'oracle')} for row in processes],
    oracle='Every episode checks all10 StoreStats fields, both pools capacity/allocated/live/max/active/reclaimed/closed/peak bounds, old/new64B payload and observable checksum. Full1024-entry payload is checked outside QPC after every epoch. All passed.',
    source_vs_runtime='Alternating roots can trigger ledger reordering, as discussed in the plan. No per-sort counter or profiler was added; do not claim an observed exact sort frequency or attribute the timing delta only to sort.',
    limits='Whole episode includes pool allocation/fill/publish, begin/finalize reference copies, replacement/preflight/retain, old owner drop, collect, stats and identical checks. Initial interleaved import and destruction are excluded. No capacity matrix, clone-route or pure-sort timing claim.',
    original_evidence='Original v1/v2 archives and144 hot epochs are untouched. plan.json preserves the pre-execution proposal; commands.json and this summary record actual execution.',
    failures=[], no_further_runs=True, no_product_change_commit_or_cleanup=True)
save('summary.json', summary)

artifacts = [HERE / name for name in ('probe.obj', 'baseline.exe', 'candidate.exe')]
cleanup = dict(
    status='Only three additional rebuildable files. No deletion or test.ps1 write. Append to the previous parent cleanup manifest; do not overwrite frozen v1/v2 records.',
    host='Windows', roots=[str(HERE)], files=[identity(path) for path in artifacts],
    count=3, total_bytes=sum(path.stat().st_size for path in artifacts), duplicate_paths=0,
    preserved='All source, commands, logs, epochs, summary, identities, archives, old v1/v2 results and shared compiler/foundation/SDK caches remain.',
    byte_accounting='Logical file lengths only; physical disk reclamation is not measured.')
old_cleanup = json.loads((PRIOR / 'cleanup-final-manifest.json').read_text())
assert not {row['path'].casefold() for row in cleanup['files']} & {row['path'].casefold() for row in old_cleanup['files']}
save('cleanup-additional-manifest.json', cleanup)

files = [path for path in HERE.iterdir() if path.is_file() and path.suffix in ('.cc', '.py', '.json', '.txt')]
files += list(frozen.iterdir())
archive = HERE / 'source-results.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(files, key=lambda path: path.relative_to(HERE).as_posix()):
        output.write(path, path.relative_to(HERE).as_posix())
record = identity(archive)
save('archive-record.json', record)
print(json.dumps(dict(archive=record, additional_cleanup_count=3,
    additional_cleanup_logical_bytes=cleanup['total_bytes'],
    source_sha=identities['current_canonical_source']['sha256'],
    test_sha=identities['unchanged_test_source']['sha256'],
    original_final_zip_sha256=sha(PRIOR / 'source-results-final.zip')), indent=2))
