from pathlib import Path
import hashlib
import json
import tarfile

OUT = Path(__file__).resolve().parent
products = [OUT/n for n in ['fast.o', 'native.o', 'apple.o', 'candidate-tests', 'candidate-space',
                           'native.latency.o', 'latency.o', 'baseline-latency', 'candidate-latency']]
(OUT/'cleanup-candidates.json').write_text(json.dumps(dict(remote_files=[dict(path=str(p),
    bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in products],
    total_bytes=sum(p.stat().st_size for p in products),
    reuse_previous_cleanup='Original apple-sink eight-file cleanup manifest remains separate; this batch still reused its baseline binaries and tests/space objects.'),
    indent=2)+'\n', encoding='utf-8')
selected = [p for p in OUT.iterdir() if p.is_file() and not p.is_symlink() and
            (p.suffix in ['.cpp', '.cc', '.py', '.json', '.txt', '.map'])]
with tarfile.open(OUT/'measured-raw.tar.gz', 'w:gz') as archive:
    for p in selected:
        archive.add(p, arcname=p.name)
print('small source/raw archive and nine-product cleanup manifest ready')
