from pathlib import Path
import hashlib
import json
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OLD = OUT.parent/'library-review-20261018-apple-sink'

def read_command(path):
    return json.loads(path.read_text())['command']

def run(tag, command, required=True):
    command = list(map(str, command))
    try:
        p = subprocess.run(command, cwd=OUT, capture_output=True, timeout=180)
        code, stdout, stderr = p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        code, stdout, stderr = -999, e.stdout or b'', e.stderr or b''
    (OUT/(tag+'-command.json')).write_text(json.dumps(dict(command=command,cwd=str(OUT),exit=code),indent=2)+'\n')
    (OUT/(tag+'.stdout.txt')).write_bytes(stdout)
    (OUT/(tag+'.stderr.txt')).write_bytes(stderr)
    print(tag,code,flush=True)
    if code and required:
        print(stdout.decode(errors='replace'))
        print(stderr.decode(errors='replace'))
        raise SystemExit(code)
    return code

if '--build' in sys.argv:
    command = read_command(OUT/'native-compile-command.json')
    command = [str(OUT/'native.latency.cpp') if x==str(OUT/'native.candidate.cpp') else
               str(OUT/'native.latency.o') if x==str(OUT/'native.o') else x for x in command]
    run('latency-native-compile',command)
    command = read_command(OUT/'apple-compile-command.json')
    command = [str(OUT/'latency.cc') if x==str(OUT/'apple_tensor.candidate.cc') else
               str(OUT/'latency.o') if x==str(OUT/'apple.o') else x for x in command]
    run('latency-consumer-compile',command)
    for arm in ['baseline','candidate']:
        command = read_command((OLD if arm=='baseline' else OUT)/(arm+'-space-link-command.json'))
        command = [str(OUT/(arm+'-latency')) if x==str((OLD if arm=='baseline' else OUT)/(arm+'-space')) else
                   str(OUT/'latency.o') if x==str(OLD/'space.o') else
                   str(OUT/'native.latency.o') if x==str(OUT/'native.o') else
                   '-Wl,-map,'+str(OUT/(arm+'-latency.map')) if x.startswith('-Wl,-map,') else x
                   for x in command]
        run(arm+'-latency-link',command)
    products=[OUT/n for n in ['native.latency.o','latency.o','baseline-latency','candidate-latency']]
    (OUT/'latency-runtime-identities.json').write_text(json.dumps({str(p):dict(bytes=p.stat().st_size,
        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in products},indent=2)+'\n')

if '--run' in sys.argv:
    for key,args in [('machine',['/usr/sbin/sysctl','-n','hw.model','hw.memsize','machdep.cpu.brand_string']),
                     ('power',['/usr/bin/pmset','-g','batt']),('thermal',['/usr/bin/pmset','-g','therm'])]:
        run('latency-before-'+key,args,required=False)
    exits=[]
    for index,arm in enumerate(['baseline','candidate','candidate','baseline']):
        exits.append(run('latency-'+str(index)+'-'+arm,[OUT/(arm+'-latency')],required=False))
    for key,args in [('power',['/usr/bin/pmset','-g','batt']),('thermal',['/usr/bin/pmset','-g','therm'])]:
        run('latency-after-'+key,args,required=False)
    (OUT/'latency-order.json').write_text(json.dumps(dict(order=['baseline','candidate','candidate','baseline'],
        exitcodes=exits,note='Fixed single shape; no AA, retries or additional process.'),indent=2)+'\n')
    if any(exits): raise SystemExit(4)
