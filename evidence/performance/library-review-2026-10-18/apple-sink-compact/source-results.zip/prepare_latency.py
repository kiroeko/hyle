from pathlib import Path
import difflib
import hashlib
import json

OUT=Path(__file__).resolve().parent
source=(OUT/'native.candidate.cpp').read_text(encoding='utf-8')
before=source
source=source.replace('#include <cstdio>\n','')
start=source.index('    std::fprintf(stderr, "HYLE_SINK_COMPACT_PSO')
end=source.index('    if (required > limit)', start)
source=source[:start]+source[end:]
assert 'fprintf' not in source
(OUT/'native.latency.cpp').write_text(source,encoding='utf-8',newline='\n')
(OUT/'native-diagnostic-removal.diff').write_text(''.join(difflib.unified_diff(
    before.splitlines(True),source.splitlines(True),fromfile='native.candidate.cpp',tofile='native.latency.cpp')),
    encoding='utf-8')
(OUT/'latency-source-sha256.json').write_text(json.dumps({n:hashlib.sha256((OUT/n).read_bytes()).hexdigest()
    for n in ['native.latency.cpp','native-diagnostic-removal.diff','latency.cc']},indent=2)+'\n',encoding='utf-8')
print('Diagnostic-free native selector and shared same-work latency consumer frozen')
