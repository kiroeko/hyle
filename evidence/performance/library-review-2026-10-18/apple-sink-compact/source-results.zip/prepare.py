from pathlib import Path
import difflib
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
manifest = json.loads((ROOT / 'third_party/mlx_cast/patches.json').read_text(encoding='utf-8'))
fast = (OUT / 'fast.baseline.cpp').read_text(encoding='utf-8')
fast_entry = next(f for f in manifest['files'] if f['path'] == 'mlx/fast.cpp')
assert hashlib.sha256(fast.encode()).hexdigest() == fast_entry['after_sha256']
host = (OUT.parent / 'apple-steel-f32-d192/native.applied.cpp').read_text(encoding='utf-8')
host_entry = next(f for f in manifest['files'] if f['path'] == 'mlx/backend/metal/scaled_dot_product_attention.cpp')
assert hashlib.sha256(host.encode()).hexdigest() == host_entry['after_sha256']
(OUT / 'native.baseline.cpp').write_text(host, encoding='utf-8', newline='\n')
apple = (ROOT / 'src/compute_route_apple/apple_tensor.cc').read_text(encoding='utf-8')
(OUT / 'apple_tensor.baseline.cc').write_text(apple, encoding='utf-8', newline='\n')

old = '''  if (!ScaledDotProductAttention::use_fallback(
          q,'''
new = '''  // Scratch-only opt-in for HYLE's existing five-port F32 Sink schema.
  // Unforced callers retain the original native admission and fallback.
  const bool hyle_sink_f32 = force_fused && !is_training && !output_logsumexp &&
      stream.device == Device::gpu && !do_causal && has_arr_mask && has_sinks &&
      queries.dtype() == float32 && keys.dtype() == float32 &&
      values.dtype() == float32 && mask_arr->dtype() == float32 &&
      sinks->dtype() == float32 && q.shape(0) == 1 &&
      (q.shape(1) == 64 || q.shape(1) == 128) && q.shape(2) > 8 &&
      q.shape(3) == 512 && k.shape(0) == 1 && k.shape(1) == 1 &&
      k.shape(2) > 0 && k.shape(3) == 512 && v.shape() == k.shape() &&
      mask_arr->ndim() == 2 && mask_arr->shape(0) == q.shape(2) &&
      mask_arr->shape(1) == k.shape(2) && sinks->ndim() == 1 &&
      sinks->shape(0) == q.shape(1) && std::isfinite(scale) && scale > 0;
  if (hyle_sink_f32 || !ScaledDotProductAttention::use_fallback(
          q,'''
assert fast.count(old) == 1
fast = fast.replace(old, new)
(OUT / 'fast.candidate.cpp').write_text(fast, encoding='utf-8', newline='\n')

host = host.replace('#include "mlx/backend/metal/device.h"', '#include "mlx/backend/metal/device.h"\n#include <cmath>\n#include <cstdio>')
assert '#include <cstdio>' in host
old = '''  if (ordinary_f32 || ordinary_f32_d192) { bq = 16; bk = 8; wm = 2; wn = 1; }
  const bool half_query'''
new = '''  if (ordinary_f32 || ordinary_f32_d192) { bq = 16; bk = 8; wm = 2; wn = 1; }
  const bool sink_f32_d512 = !page && mask && sinks && !do_causal_ &&
      q.dtype() == float32 && k.dtype() == float32 && v.dtype() == float32 &&
      mask->dtype() == float32 && sinks->dtype() == float32 && B == 1 &&
      (H == 64 || H == 128) && k.shape(1) == 1 && bd == 512 && bv == 512 &&
      qL > 8 && kL > 0 && mask->ndim() == 4 &&
      mask->shape() == Shape{B, H, qL, kL} && sinks->ndim() == 1 &&
      sinks->shape(0) == H && std::isfinite(scale) && scale > 0;
  if (sink_f32_d512) { bq = bk = 8; wm = wn = 1; }
  const bool half_query'''
assert host.count(old) == 1
host = host.replace(old, new)
old = '''  if (ordinary_f32 || ordinary_f32_d192) {
    const auto required = kernel->staticThreadgroupMemoryLength();'''
new = '''  if (sink_f32_d512) {
    const auto required = kernel->staticThreadgroupMemoryLength();
    const auto limit = d.mtl_device()->maxThreadgroupMemoryLength();
    std::fprintf(stderr, "HYLE_SINK_COMPACT_PSO Q=%d KV=%d H=%d bytes=%lu cap=%lu tile=8/8/1/1 dtype=F32 query_half=%d\\n",
        qL, kL, H, static_cast<unsigned long>(required),
        static_cast<unsigned long>(limit), int(half_query));
    if (required > limit)
      throw std::runtime_error("HYLE F32 Sink Steel static threadgroup exceeds actual device limit");
  }
  if (ordinary_f32 || ordinary_f32_d192) {
    const auto required = kernel->staticThreadgroupMemoryLength();'''
assert host.count(old) == 1
host = host.replace(old, new)
(OUT / 'native.candidate.cpp').write_text(host, encoding='utf-8', newline='\n')

old = '''      auto result = mx::fast::scaled_dot_product_attention(query, key, value,
          sink_attention->scale, "array", inputs[3], inputs[4], false, stream);'''
new = '''      const bool force_fused = query.shape(2) > 8 && known_gpu_without_nax();
      auto result = mx::fast::scaled_dot_product_attention(query, key, value,
          sink_attention->scale, "array", inputs[3], inputs[4], force_fused, stream);'''
assert apple.count(old) == 1
apple = apple.replace(old, new)
(OUT / 'apple_tensor.candidate.cc').write_text(apple, encoding='utf-8', newline='\n')

for stem, suffix in [('fast', '.cpp'), ('native', '.cpp'), ('apple_tensor', '.cc')]:
    before = (OUT / (stem + '.baseline' + suffix)).read_text(encoding='utf-8')
    after = (OUT / (stem + '.candidate' + suffix)).read_text(encoding='utf-8')
    (OUT / (stem + '.diff')).write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile=stem + '.baseline' + suffix, tofile=stem + '.candidate' + suffix)), encoding='utf-8')

for name in ['sink_tests.cc', 'space.cc']:
    (OUT / name).write_bytes((OUT.parent / 'apple-sink' / name).read_bytes())
(OUT / 'frozen-source-sha256.json').write_text(json.dumps({
    p.name: hashlib.sha256(p.read_bytes()).hexdigest()
    for p in OUT.iterdir() if p.suffix in ['.cc', '.cpp', '.h', '.diff']
}, indent=2) + '\n', encoding='utf-8')
print('Three scratch candidate TUs frozen; current manifest source hashes matched; product unchanged')
