from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
RAW = OUT/'measured'
unchanged = subprocess.run(['git','diff','--exit-code','--',
    'src/compute_route_apple/apple_tensor.cc','tests/compute_route_apple/attention_test.cc',
    'third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md'], cwd=ROOT, capture_output=True)
assert unchanged.returncode == 0
(OUT/'canonical-unchanged.json').write_text(json.dumps(dict(
    exitcode=unchanged.returncode, files=['src/compute_route_apple/apple_tensor.cc',
    'tests/compute_route_apple/attention_test.cc','third_party/mlx_cast/patches.json',
    'third_party/mlx_cast/NOTICE.md'], stdout=unchanged.stdout.decode(),
    note='Only scratch candidates created; no candidate product/resource edit.'),indent=2)+'\n',encoding='utf-8')
def load(name):
    return json.loads((RAW/name).read_text(encoding='utf-8'))
baseline = load('baseline-space.stdout.txt')
candidate = load('candidate-space.stdout.txt')
numbers = {}
for arm in ['baseline', 'candidate']:
    numeric = [json.loads(line) for line in (RAW/(arm+'-tests.stdout.txt')).read_text(encoding='utf-8').splitlines()
               if line.startswith('{"kind":"sink_numeric"')]
    report = load(arm+'-tests.json')
    numbers[arm] = dict(tests=report['tests'], failures=report['failures'],
        numeric_observations=numeric,
        max_abs_error=max(n['maximum_error'] for n in numeric),
        max_budget_fraction=max(n['maximum_budget_fraction'] for n in numeric))
maps = {}
for kind in ['tests', 'space']:
    source = (RAW/('candidate-'+kind+'.map')).read_text(encoding='utf-8')
    objects = source.split('# Object files:\n', 1)[1].split('# Sections:', 1)[0]
    maps[kind] = dict(fresh_apple='/apple.o' in objects, fresh_fast='/fast.o' in objects,
        fresh_native='/native.o' in objects,
        old_apple_tensor_object='(apple_tensor.cc.o)' in objects,
        old_fast_object='(fast.cpp.o)' in objects,
        old_native_sdpa_object='(scaled_dot_product_attention.cpp.o)' in objects)
assert all(m['fresh_apple'] and m['fresh_fast'] and m['fresh_native'] and
           not m['old_apple_tensor_object'] and not m['old_fast_object'] and
           not m['old_native_sdpa_object'] for m in maps.values())
(OUT/'link-map-check.json').write_text(json.dumps(maps, indent=2)+'\n', encoding='utf-8')
prior_identity = OUT.parent/'apple-sink/measured/runtime-identities.json'
(OUT/'prior-sdk-runtime-identities.json').write_bytes(prior_identity.read_bytes())
(OUT/'source-review.json').write_bytes((OUT.parent/'source-review/apple-sink-execution-and-d512.json').read_bytes())
latency = []
for index, arm in enumerate(['baseline', 'candidate', 'candidate', 'baseline']):
    result = load('latency-'+str(index)+'-'+arm+'.stdout.txt')
    result['process_order'] = index
    result['arm'] = arm
    result['median_ns'] = statistics.median(result['timed_submit_checkedwait_ns'])
    latency.append(result)
latency_maps = {}
for arm in ['baseline', 'candidate']:
    text = (RAW/(arm+'-latency.map')).read_text(encoding='utf-8')
    objects = text.split('# Object files:\n',1)[1].split('# Sections:',1)[0]
    latency_maps[arm] = dict(fresh_shared_consumer='/latency.o' in objects,
        fresh_apple='/apple.o' in objects, fresh_fast='/fast.o' in objects,
        diagnostic_free_native='/native.latency.o' in objects,
        original_apple='/apple-baseline.o' in objects,
        sdk_fast_object='(fast.cpp.o)' in objects,
        sdk_native_sdpa_object='(scaled_dot_product_attention.cpp.o)' in objects)
assert latency_maps['candidate']['fresh_shared_consumer']
assert latency_maps['candidate']['diagnostic_free_native']
assert latency_maps['baseline']['original_apple'] and latency_maps['baseline']['sdk_fast_object']
summary = dict(
    status='scratch_candidate_rejected_for_default_use; numerical_controls_and_space_passed_but_matched_latency_about7x_slower; not_applied',
    machine=dict(host='kiro@172.22.10.198', model='Mac16,12', chip='Apple M4',
                 ram_bytes=17179869184, free_disk_before='41GiB', compiler='Apple clang21.0.0 arm64'),
    scope='Only force_fused opt-in to exact all-F32 Sink B1/H64or128/KVheads1/D512/arraymask/sinks/Q>8 schema, selected by Hyle only on known Apple generations13-16. Ordinary, unknown/new architecture defaults, NAX/page/other dtype/vector branches remain unchanged.',
    native=dict(tile='BQ8/BK8/WM1/WN1', actual_static_threadgroup_bytes=32768,
        actual_device_cap_bytes=32768, query_half=False,
        resource='The fixed SDK header and embedded JIT source already contain compact zero-padding. Existing float template instantiated; no shader/metallib/SDK rebuild or precision reduction.',
        sink_semantics='Existing kernel initializes max from raw sink and sum=1, adds F32 global additive mask to logits, keeps F32 exp probabilities/PV, normalizes only by sink+keys. Finite sink plus all -Inf key masks contributes zero weighted value.',
        unknown_limits='No D512 ordinary/decode/training/CPU/other GPU support. Controls cover moderate fixed scale and finite sinks, not all finite F32 values. Source has scale and sink pre-multiplication by log2(e), which may overflow for extreme finite values before zero/masked logits; this potential boundary was not experimentally tested and cannot be claimed equivalent over the full public F32 value range.'),
    source_and_build=dict(
        canonical_changed=False, source='Hyle baseline is current canonical source; fast.cpp baseline SHA matches current manifest. Candidate Metal selector uses current D192 materialized host projection. Original SDK native baseline predates unrelated !mask&&!sinks ordinary D192/D256 host selector edits; those do not affect this Sink domain.',
        fresh_tus=['fast.candidate.cpp', 'native.candidate.cpp', 'apple_tensor.candidate.cc'],
        reused='Original SDK/foundation/gtest archives, previous fixed tests.o/space.o and baseline executables. No configure, dependency copy/download, test source/input/budget change or whole-library build.',
        commands='measured/*-command.json', identity='measured/runtime-identities.json and prior-sdk-runtime-identities.json',
        maps=maps,
        compile_failure='Initial standalone fast.cpp compile under -Wall/-Wextra/-Werror stopped on pre-existing upstream sign-compare/unused-lambda-capture warnings. All initial command/output retained as measured/initial-fast-compile*. Native-only warning-category exceptions added; three candidate TUs then compiled/linked. No product warning suppression changed.'),
    controls=dict(processes='Exactly one baseline and one candidate process, same original two corrected-lease tests.',
        original_failed_harness='Prior batch initial lease-reuse failure and negative Q16 candidate remain archived separately; this run reuses its authorized corrected test object without further changes.',
        cases=['H64/Q1025/KV2049 nonzero QK, global per-row mask/finite per-head sink, allmasked rows15/16/last, unaligned tail, two invocations, all-five-port rebind, independent old result/native output lifetime',
               'Original H128/Q17/KV31 numerical control; same test name mentions fallback but candidate intentionally opts into full fused forQ>8. DecodeQ<=8 remains unchanged and was not added to this batch.'],
        oracle='Independent FP64 separable-V oracle over every output channel, original F32 rel6e-6+abs2e-6; no shader or input retuning.',
        results=numbers, pso_gate=load('control-gate.json')),
    fixed_space=dict(processes='Exactly one baseline and one candidate process, after controls/PSO passed.',
        input='Same pre-fixed Q1025/KV2049/H64/KVhead1/D512, Q/K/mask/sinks0, V alternates+1.25/-1.25 by KVrow; no shape/input/budget change.',
        oracle='FP64 expected1.25/2050, all33587200 output elements; rel6e-6+abs2e-6.',
        baseline=baseline, candidate=candidate,
        extra_peak_reduction_bytes=baseline['peak_minus_active_before']-candidate['peak_minus_active_before'],
        extra_peak_reduction_fraction=1-candidate['peak_minus_active_before']/baseline['peak_minus_active_before'],
        boundary='MLX active/peak/cache after public prepare/create_invocation/bind, clear_cache/reset_peak then submit/wait/synchronize. Original SDK allocator counts, not whole-device VRAM/RSS; cold JIT/prepare excluded.',
        conclusion='Candidate extra peak equals its134348800B output; no cached extra scratch after this shape. Actual fixed-shape space result, not a global peak proof or latency claim.'),
    prior_negative_preserved='Q16 lazy-block wrapper extra peak+136724480B remains a valid negative result; compact native fusion is a distinct candidate and does not rewrite that evidence.',
    matched_latency=dict(
        order=['baseline', 'candidate', 'candidate', 'baseline'],
        process_results=latency,
        candidate_over_baseline_median_ratios=[latency[1]['median_ns']/latency[0]['median_ns'],
                                               latency[2]['median_ns']/latency[3]['median_ns']],
        processes='Exactly four sequential independent processes. Two untimed warm invocations, one full independent FP64 oracle before and one after, nine timed complete submit-to-checked-wait samples each. All36 durations and8 complete-oracle outcomes retained.',
        boundary='Same one consumer TU and fixed inputs. Input creation, prepare/isolated warmup/JIT, invocation creation/bind, two warm invocations, oracle checks, lease/result destruction, final Context drain/destruction all outside sample timing. Each sample includes real public submit and successful checked Completion wait. ResultLease and OwnedResult destroyed before slot reuse. No cache clearing or retuning between timed samples.',
        native_change='Only removed cstdio/fprintf diagnostics from measured host source, retained actual PSO<=device guard; compiled one fresh native host TU plus the shared timing consumer. Other candidate TUs and SDK reused. Original PSO/raw space source and observations preserved separately.',
        maps=latency_maps,
        power_before=(RAW/'latency-before-power.stdout.txt').read_text(),
        power_after=(RAW/'latency-after-power.stdout.txt').read_text(),
        thermal_before=(RAW/'latency-before-thermal.stdout.txt').read_text(),
        thermal_after=(RAW/'latency-after-thermal.stdout.txt').read_text(),
        environment_limits='AC power77% unchanged and no recorded pmset thermal/performance warnings; no actual GPU frequency/power or temperature sampling, no clock/power/environment changes. No AA, confidence interval, new shape or retry; about7x latency penalty is consistent across both process orders.',
        conclusion='Actual90% extra-peak reduction comes with about7x higher checked-completion latency on this same shape. Root explicitly rejected default product application; no product/resource edit. Not a high-performance optimization.'),
    pending='No further experiment authorized this batch. A private completion/retirement pipeline remains a future design, not implemented or tested here.',
    cleanup='cleanup-candidates.json lists only this batch new nine obj/exe products. Previous apple-sink eight-file manifest remains separate; originals were reused without modification.')
(OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
(OUT/'final-source-sha256.json').write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
    for p in OUT.iterdir() if p.suffix in ['.cc', '.cpp', '.h', '.diff']}, indent=2)+'\n', encoding='utf-8')
archive = OUT/'source-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p != archive and p.name not in ['measured-raw.tar.gz', 'archive-record.json']:
            z.write(p, p.relative_to(OUT))
record = dict(path=str(archive), bytes=archive.stat().st_size,
              sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(OUT/'archive-record.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(record))
