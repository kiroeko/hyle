from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

OUT = Path(__file__).resolve().parent
OLD = OUT.parent / 'library-review-20261018-apple-sink'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
BLOCKS = OUT.parent / 'library-review-20261018-sdpa-blocks'
CORE = Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
MLX = CORE / 'hyle/_deps/mlx-490c5876b63c15e8/source'
GTEST = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
FMT = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/fmt-407c905e45ad-cd0d9446fff4/include')
flags = ['-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64', '-DHYLE_STATIC', '-DMLX_STATIC',
         '-DHYLE_COMPUTE_APPLE=1', '-Wall', '-Wextra', '-Wpedantic', '-Werror',
         '-I'+str(BLOCKS/'src/compute_route_apple'), '-I'+str(BLOCKS),
         '-I'+str(BLOCKS/'tests/compute_route_apple'), '-isystem', str(SDK/'include'),
         '-isystem', str(SDK/'include/metal_cpp'), '-isystem', str(GTEST)]
libs = [SDK/'lib'/('lib'+x+'.a') for x in ['hyle_compute_route_apple', 'hyle_compute_stream',
    'hyle_compute_state', 'hyle_compute_batch', 'hyle_compute', 'hyle_compute_ops', 'hyle_simd',
    'hyle_sched', 'hyle_container', 'hyle_mem_vm', 'hyle_mem', 'mimalloc_static',
    'hyle_platform_thread', 'hyle_time', 'hyle_platform', 'hyle_error',
    'hyle_compute_provider_ggml_metal', 'hyle_compute_ggml_runtime', 'ggml', 'ggml-metal',
    'ggml-base', 'mlx']]
frameworks = ['-framework', 'Foundation', '-framework', 'Metal', '-framework', 'MetalKit',
              '-framework', 'QuartzCore']

def run(tag, command, required=True):
    command = list(map(str, command))
    try:
        p = subprocess.run(command, cwd=OUT, capture_output=True, timeout=180)
        code, stdout, stderr = p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        code, stdout, stderr = -999, e.stdout or b'', e.stderr or b''
    (OUT/(tag+'-command.json')).write_text(json.dumps(dict(command=command, cwd=str(OUT),
                                                        exit=code), indent=2)+'\n', encoding='utf-8')
    (OUT/(tag+'.stdout.txt')).write_bytes(stdout)
    (OUT/(tag+'.stderr.txt')).write_bytes(stderr)
    print(tag, code, flush=True)
    if code and required:
        print(stdout.decode(errors='replace'))
        print(stderr.decode(errors='replace'))
        raise SystemExit(code)
    return code

if not (OUT/'mlx.metallib').exists():
    (OUT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')

if '--build' in sys.argv:
    if (OUT/'fast-compile-command.json').exists() and not (OUT/'initial-fast-compile-command.json').exists():
        for name in ['fast-compile-command.json', 'fast-compile.stdout.txt', 'fast-compile.stderr.txt']:
            (OUT/('initial-'+name)).write_bytes((OUT/name).read_bytes())
    for stem in ['fast', 'native']:
        run(stem+'-compile', ['/usr/bin/clang++', *flags, '-Wno-unused-parameter',
             '-Wno-sign-compare', '-Wno-unused-lambda-capture',
             '-DFMT_HEADER_ONLY=1', '-isystem', str(MLX), '-isystem', str(FMT),
             '-c', OUT/(stem+'.candidate.cpp'), '-o', OUT/(stem+'.o')])
    run('apple-compile', ['/usr/bin/clang++', *flags, '-c', OUT/'apple_tensor.candidate.cc',
                          '-o', OUT/'apple.o'])
    for kind in ['tests', 'space']:
        run('candidate-'+kind+'-link', ['/usr/bin/clang++', '-O3', '-std=c++23',
            '-o', OUT/('candidate-'+kind), OLD/(kind+'.o'), OUT/'apple.o', OUT/'fast.o',
            OUT/'native.o', *libs, *([CORE/'lib/libgtest_main.a'] if kind=='tests' else []),
            CORE/'lib/libgtest.a', *frameworks, '-Wl,-map,'+str(OUT/('candidate-'+kind+'.map'))])
    selected = [OLD/'tests.o', OLD/'space.o', OLD/'apple-baseline.o',
                OLD/'baseline-tests', OLD/'baseline-space', OUT/'fast.o', OUT/'native.o',
                OUT/'apple.o', OUT/'candidate-tests', OUT/'candidate-space']
    (OUT/'runtime-identities.json').write_text(json.dumps({str(p): dict(bytes=p.stat().st_size,
        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in selected}, indent=2)+'\n', encoding='utf-8')
    (OUT/'sdk-reuse.json').write_text(json.dumps(dict(
        sdk=str(SDK), prior_identity_file=str(OLD/'runtime-identities.json'),
        selected_libraries=list(map(str, libs)),
        note='Original static SDK/native archive/foundation and existing test/space objects reused; no library copied or rebuilt.'),
        indent=2)+'\n', encoding='utf-8')

if '--tests' in sys.argv:
    codes = {}
    for arm in ['baseline', 'candidate']:
        binary = OLD/'baseline-tests' if arm=='baseline' else OUT/'candidate-tests'
        codes[arm] = run(arm+'-tests', [binary, '--gtest_filter=AppleSinkAttention.*',
                         '--gtest_output=json:'+str(OUT/(arm+'-tests.json'))], required=False)
    pso = [(int(size), int(cap)) for size, cap in re.findall(r'bytes=(\d+) cap=(\d+)',
           (OUT/'candidate-tests.stderr.txt').read_text())]
    gate = dict(test_exitcodes=codes, pso_observations=pso,
                controls_passed=all(code==0 for code in codes.values()),
                pso_observed_and_within_cap=bool(pso) and all(size<=cap<=32768 for size,cap in pso))
    gate['allow_fixed_space'] = gate['controls_passed'] and gate['pso_observed_and_within_cap']
    (OUT/'control-gate.json').write_text(json.dumps(gate, indent=2)+'\n', encoding='utf-8')
    if not gate['allow_fixed_space']:
        raise SystemExit(3)

if '--space' in sys.argv:
    assert json.loads((OUT/'control-gate.json').read_text())['allow_fixed_space']
    for arm in ['baseline', 'candidate']:
        binary = OLD/'baseline-space' if arm=='baseline' else OUT/'candidate-space'
        run(arm+'-space', [binary], required=False)
