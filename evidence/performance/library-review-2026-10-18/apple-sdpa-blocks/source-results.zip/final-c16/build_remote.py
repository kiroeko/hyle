from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time
OUT=Path(__file__).resolve().parent
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CORE=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
GTEST=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
flags=['-O3','-DNDEBUG','-std=c++23','-arch','arm64','-DHYLE_STATIC','-DMLX_STATIC','-DHYLE_COMPUTE_APPLE=1',
 '-Wall','-Wextra','-Wpedantic','-Werror','-I'+str(OUT/'src/compute_route_apple'),
 '-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp'),'-isystem',str(GTEST)]
env=dict(os.environ)

def run(tag,cmd):
 rec={'command':list(map(str,cmd)),'cwd':str(OUT)};t=time.time()
 p=subprocess.run(rec['command'],cwd=OUT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 rec.update(exit=p.returncode,wall_seconds=time.time()-t)
 (OUT/(tag+'-command.json')).write_text(json.dumps(rec,indent=2))
 (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
 print(tag,p.returncode,flush=True)
 if p.returncode:
  print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'));raise SystemExit(p.returncode)
 return p.stdout.decode()

if not (OUT/'mlx.metallib').exists(): (OUT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
libs=[SDK/'lib'/('lib'+x+'.a') for x in ['hyle_compute_route_apple','hyle_compute_stream','hyle_compute_state',
 'hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_simd','hyle_sched','hyle_container',
 'hyle_mem_vm','hyle_mem','mimalloc_static','hyle_platform_thread','hyle_time','hyle_platform','hyle_error',
 'hyle_compute_provider_ggml_metal','hyle_compute_ggml_runtime','ggml','ggml-metal','ggml-base','mlx']]
frameworks=['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore']
if '--build' in sys.argv:
 for tag in ['baseline','candidate']:
  run(tag+'-compile',['/usr/bin/clang++',*flags,'-c',OUT/('apple_tensor.'+tag+'.cc'),'-o',OUT/(tag+'.o')])
 run('tests-compile',['/usr/bin/clang++',*flags,'-c',OUT/'tests/compute_route_apple/attention_test.cc','-o',OUT/'tests.o'])
if '--build' in sys.argv or '--link' in sys.argv:
 for tag in ['baseline','candidate']:
  run(tag+'-native-link',['/usr/bin/clang++','-O3','-std=c++23','-o',OUT/(tag+'-tests'),OUT/'tests.o',OUT/(tag+'.o'),
   *libs,CORE/'lib/libgtest_main.a',CORE/'lib/libgtest.a',*frameworks,'-Wl,-map,'+str(OUT/(tag+'.map'))])

if '--tests' in sys.argv:
 for tag in ['baseline','candidate']:
  rec={'command':[str(OUT/(tag+'-tests'))],'cwd':str(OUT)}
  p=subprocess.run(rec['command'],cwd=OUT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
  rec['exit']=p.returncode
  (OUT/(tag+'-tests-command.json')).write_text(json.dumps(rec,indent=2))
  (OUT/(tag+'-tests.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'-tests.stderr.txt')).write_bytes(p.stderr)
  print(tag,'testexit',p.returncode,flush=True)

if '--space' in sys.argv:
 run('space-compile',['/usr/bin/clang++',*flags,'-c',OUT/'space.cc','-o',OUT/'space.o'])
 for tag in ['baseline','candidate']:
  run(tag+'-space-link',['/usr/bin/clang++','-O3','-std=c++23','-o',OUT/(tag+'-space'),OUT/'space.o',OUT/(tag+'.o'),*libs,CORE/'lib/libgtest.a',*frameworks,'-Wl,-map,'+str(OUT/(tag+'-space.map'))])
 for tag in ['baseline','candidate']:
  run(tag+'-space',[OUT/(tag+'-space')])
