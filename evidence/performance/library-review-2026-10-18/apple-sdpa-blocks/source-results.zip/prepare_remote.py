from pathlib import Path
import json, subprocess, tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-sdpa-blocks'
HOST = 'kiro@172.22.10.198'
files = [
 'src/compute_route_apple/apple_tensor.h',
 'src/compute_route_apple/apple_internal.h',
 'src/compute_route_apple/apple_checks.h',
 'src/compute_route_apple/apple_mature_indexing.h',
 'src/compute_route_apple/apple_mature_artifact.h',
 'src/compute_route_apple/apple_mature_reduction.h',
 'tests/compute_route_apple/attention_test.cc',
 'tests/compute_route_apple/tensor_test_support.h',
 'tests/compute_provider_native/half_test_support.h',
]
for name in files:
 p = OUT / name
 p.parent.mkdir(parents=True, exist_ok=True)
 p.write_bytes((ROOT / name).read_bytes())
(OUT / 'apple_tensor.baseline.cc').write_bytes(subprocess.check_output(['git','show','HEAD:src/compute_route_apple/apple_tensor.cc'],cwd=ROOT))
(OUT / 'apple_tensor.candidate.cc').write_bytes((ROOT / 'src/compute_route_apple/apple_tensor.cc').read_bytes())
runner=(ROOT / '.scratch/perf-review-2026-10-18/apple-sdpa/build_remote.py').read_text()
# Reuse the previously validated exact SDK/link closure; avoid rehashing SDKs.
runner=runner.replace(" (OUT/'identities.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in libs+[SDK/'lib/mlx.metallib',OUT/'baseline-tests',OUT/'candidate-tests']},indent=2))",'')
(OUT / 'build_remote.py').write_text(runner)
with tarfile.open(OUT / 'sources.tar','w') as t:
 for name in files+['apple_tensor.baseline.cc','apple_tensor.candidate.cc','build_remote.py','space.cc']:
  if (OUT / name).exists():t.add(OUT/name,arcname=name)
hardware=subprocess.run(['ssh',HOST,'uname -m; sysctl -n hw.model; sysctl -n machdep.cpu.brand_string; df -h /Users/kiro/hyle-scratch; system_profiler SPDisplaysDataType; xcrun clang++ --version'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'machine.stdout.txt').write_bytes(hardware.stdout)
(OUT/'machine.stderr.txt').write_bytes(hardware.stderr)
assert hardware.returncode == 0
for command in [
 ['ssh',HOST,'mkdir -p '+REMOTE],
 ['scp',str(OUT/'sources.tar'),HOST+':'+REMOTE+'/sources.tar'],
 ['ssh',HOST,'cd '+REMOTE+' && tar -xf sources.tar && /usr/bin/python3 build_remote.py --build'],
]:
 p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 print(command[0],p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'),flush=True)
 (OUT/'remote-build.stdout.txt').write_bytes(p.stdout)
 (OUT/'remote-build.stderr.txt').write_bytes(p.stderr)
 if p.returncode:raise SystemExit(p.returncode)
