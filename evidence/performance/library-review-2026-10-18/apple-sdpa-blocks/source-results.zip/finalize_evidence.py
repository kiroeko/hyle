from pathlib import Path
import hashlib,json,subprocess,zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
def read(path):return json.loads((OUT/path).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
product=['src/compute_route_apple/apple_tensor.cc','tests/compute_route_apple/attention_test.cc']
identities={p:sha(ROOT/p) for p in product}
(OUT/'apple_tensor.applied.cc').write_bytes((ROOT/product[0]).read_bytes())
(OUT/'attention_test.applied.cc').write_bytes((ROOT/product[1]).read_bytes())
assert (ROOT/product[0]).read_bytes()==(OUT/'applied-regression/apple_tensor.candidate.cc').read_bytes()
assert (ROOT/product[1]).read_bytes()==(OUT/'applied-regression/tests/compute_route_apple/attention_test.cc').read_bytes()
diff=subprocess.check_output(['git','diff','--',*product],cwd=ROOT)
(OUT/'product.patch').write_bytes(diff)
space={phase:{arm:read(f'{phase}/{arm}-space.stdout.txt') for arm in ['baseline','candidate']} for phase in ['initial-c64','final-c16']}
map_identity={}
for phase in ['initial-c64','final-c16']:
 for arm in ['baseline','candidate']:
  text=(OUT/phase/(arm+'.map')).read_text()
  map_identity[phase+'/'+arm]={'fresh_object':str('/'+arm+'.o') in text,'old_apple_tensor_archive_member':'.a(apple_tensor.cc.o)' in text}
summary={
 'status':'implemented_focused_numerical_and_space_validation_passed',
 'canonical_source_root':str(ROOT),
 'scope':'Apple ordinary SDPA fallback only; no public API, native SDK patch, metallib, CPU, or lock changes',
 'source_sha256':identities,
 'measured_final_candidate_sha256':sha(OUT/'final-c16/apple_tensor.candidate.cc'),
 'applied_vs_measured_source':'After the measured final16-row run, root review requested an explicit GPU-stream selection guard, deletion of the dead D256 rows<1024 alternative, and explicit !mask&&causal normalization inside fallback helpers. Public lower_tensor already rejects combined causal+explicit mask, so these preserve every measured valid GPU path. A reject assertion was appended to the existing broadcast/rebind test; only that test was freshly rebuilt and rerun on baseline/candidate, both PASS. No extra space/full-suite/CPU run. Exact applied source/test snapshots are apple_tensor.applied.cc and attention_test.applied.cc.',
 'baseline_source_sha256':sha(OUT/'final-c16/apple_tensor.baseline.cc'),
 'initial_64row_candidate_sha256':sha(OUT/'initial-c64/apple_tensor.candidate.cc'),
 'machine':{'host':'kiro@172.22.10.198','model':'Mac16,12','chip':'Apple M4','gpu_cores':8,'architecture':'arm64','compiler':'Apple clang 21.0.0 (clang-2100.3.34.2)','free_space_before':'41 GiB','raw':'machine.stdout.txt'},
 'product_domain':{
  'device':'GPU only; CPU stream retains original native entry','block_rows':16,'query_rows':'>=1024',
  'benefit_guard':'(Q - 16) * KV > 2 * Q * Dv; nonempty batch, K/V, Q depth and V depth',
  'static_native_fallback':'Unsupported full-kernel depth/Q-V-depth pair, or causal Q>KV, or depth192, or depth256 outside its possibly fused causal no-array-mask Q>=1024 case.',
  'priority':'Existing force_fused narrow-dtype domain wins first; existing native fused paths such as F32 D128 remain native.',
  'mask_dtype_admission':'Keep the existing MLX promote_types requirement; incompatible masks still use native validation.',
  'math':'Existing fallback dtype and scale, native GQA unflatten/flatten, complete KV per Q block, boolean finite dtype minimum, precise softmax, then PV; concatenate once.',
  'causal_index':'key_index <= KV - full_Q + block_begin + local_row; never trim K/V to a shorter prefix.',
  'lifetime':'Pure lazy graph. depends sequences Q and mask sources after the previous final output; no eval/synchronize in tracing. Existing compiled input replacement, array owners, Invocation and Completion retain lifetime.',
 },
 'validation':{
  'compile':'Only fresh apple_tensor baseline/candidate and attention test host TUs; O3 C++23, arm64, Wall/Wextra/Wpedantic/Werror; linked existing fixed SDK and gtest archives. Final adjustment rebuilt only candidate/test TUs and relinked affected executables.',
  'final_candidate_tests':6,'final_baseline_tests':6,'final_exit_codes':{'candidate':0,'baseline':0},
  'applied_targeted_regression':{'baseline':1,'candidate':1,'both_exit':0,'filter':'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners','assertion':'Combined explicit Bool mask and causal flag still rejected during public prepare as Unimplemented; no API domain expansion. Valid broadcast/rebind and additive-mask checks remain in the same test.','raw':'applied-regression/*-combination-regression*'},
  'tested_final_block_paths':[
   'Nonzero QK F32 D192 BHSD GQA, Q1025/KV1281 causal, 16-row blocks and one-row tail; independent FP64 oracle.',
   'F32 D40 BSHD GQA Q1025>KV769 causal: first256 globally fully masked rows retain uniform output.',
   'F16/BF16 D192/256 boolean Q1025/KV769, fully masked rows including block boundaries and final tail.',
   'F32 B2/H2/Hkv1 Q1025/KV769 rank4 broadcast Bool mask: two independent invocation bindings, submit/wait and rebind.',
   'Same broadcast shape additive mask: all -Inf head retains native NaNs; partially visible head retains finite analytic output.',
  ],
  'controls':'Existing small D192/256 shapes/layouts, zero/negative scale, unsupported fused shape/decode/Q>KV control, and F16 weak probabilities remain checked.',
  'oracle':'Original FP64 sum; V is exactly periodic over17 channels, so compute its17 independent sums once and reuse them. No error budget change.',
  'error_budgets':'Existing F32 rel6e-6+abs2e-6; F16 rel.001+abs2e-7; BF16 rel.008+abs2e-7; weak probabilities abs.002. Space analytic check abs2e-6.',
  'link_maps':map_identity,
  'native_identity':read('final-c16/runtime-identities.json'),
  'applied_regression_binary_identity':read('applied-regression/runtime-identities.json'),
  'raw_logs':'initial-c64/ and final-c16/: command JSON, stdout, stderr, maps and exact source snapshots',
 },
 'space':{
  'shape':'F32 B1/Hq4/Hkv2/D256/Q2048/KV2048, explicit dense Bool[Q,KV], including fully masked rows, V1.25.',
  'boundary':'Separate processes per arm. Public Context prepare/create_invocation/bind complete first; clear_cache/reset_peak then submit/wait/synchronize. All2,097,152 outputs checked, maxerror0 both sides.',
  'metric':'Native MLX allocator active/peak/cache; not whole-device memory, process RSS, exact provider-private storage, or first cold prepare peak. peak-minus-active-before includes output and pending native buffers.',
  'caller_qkv_bytes':16777216,'caller_mask_bytes':4194304,'output_bytes':8388608,
  'initial_64row_negative':space['initial-c64'],
  'initial_64row_conclusion':'Extra peak80MiB ->88MiB (+10%); preserved as a real negative result, not accepted.',
  'final_16row':space['final-c16'],
  'final_extra_peak_reduction_fraction':1-space['final-c16']['candidate']['peak_minus_active_before']/space['final-c16']['baseline']['peak_minus_active_before'],
  'interpretation':'Under this SDK/device/default native settings, extra peak83,886,080 ->61,669,376 bytes (~26.49% less). Actual scheduling still retains multiple blocks. This is not a one-block hard peak guarantee.',
  'warm_constant_difference_bytes':space['final-c16']['candidate']['active_before']-space['final-c16']['baseline']['active_before'],
 },
 'mechanism_and_limitations':[
  'Locked MLX eval builds a finite-width BFS tape. depends gives evaluation order, not immediate GPU retirement.',
  'Metal retains primitive inputs until command buffer completion. Native commit limits and active-task backpressure remain in control; changing their environment settings can change the peak.',
  'More native operations/launches and linear graph metadata are introduced. Throughput is unmeasured; test wall times are not throughput evidence.',
  'Dense caller masks remain quadratic API input storage; only internal scores/probabilities avoid a whole-Q allocation in the selected domain.',
  'Q<1024, shapes failing the benefit guard, and possible D256 causal no-mask NAX domains retain existing behavior, including square fallback where the native heuristic chooses it.',
  'In particular, if the current Air lacks NAX or the native settings do not enable that fused path, long-Q D256 causal no-mask F32 can remain a square fallback. This batch intentionally does not duplicate the complete native selector or patch the SDK.',
  'No full Apple suite, whole HEAD SDK build, full default Graph roster, other hardware, or nondefault MLX environment validation.',
 ],
 'diagnostics_and_failures_retained':[
  'Initial64-row actual space regression retained in initial-c64; final16-row test was the only block-size adjustment.',
  'One SSH python-c wrapper failed with a quoting SyntaxError before launching a workload; subsequent stdin runner succeeded. No numerical/compile test failure was hidden.',
 ],
 'cleanup':'cleanup-candidates.json lists only new remote objects/executables. Original SDK/cache/metallib are not cleanup targets. Delete only after root writes exact operations to test.ps1.',
}
write('summary.json',summary)
runtime=read('applied-regression/runtime-identities.json')
write('cleanup-candidates.json',{'new_remote_rebuildable_files':[dict(path=p,**v) for p,v in runtime.items() if '/library-review-20261018-sdpa-blocks/' in p],'retained_original_sdk':True})
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for phase in ['initial-c64','final-c16']:
  for p in sorted((OUT/phase).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
 for p in sorted((OUT/'applied-regression').iterdir()):
  if p.is_file() and (p.name.startswith(('baseline-combination-regression','candidate-combination-regression','candidate-compile','tests-compile','baseline-native-link','candidate-native-link')) or p.name in ['baseline.map','candidate.map','runtime-identities.json']):
   z.write(p,p.relative_to(OUT).as_posix())
 for name in ['summary.json','cleanup-candidates.json','product.patch','apple_tensor.applied.cc','attention_test.applied.cc','prepare_remote.py','collect_snapshot.py','finalize_evidence.py','machine.stdout.txt','machine.stderr.txt','remote-build.stdout.txt','remote-build.stderr.txt']:
  z.write(OUT/name,name)
write('archive-record.json',{'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'summary_sha256':sha(OUT/'summary.json'),'product_source_sha256':identities,'SDK_binaries_excluded':True})
print(json.dumps(read('archive-record.json'),indent=2))
