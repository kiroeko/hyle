// Actual Hyle Direct SinkAttention; explicit scratch/residency, not peak VRAM.
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include "hyle/mem/buffer.h"
#include <cuda_runtime_api.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>
namespace c=hyle::compute;
namespace m=hyle::mem;
template<class T> T take(hyle::Result<T> r) {if(!r)throw std::runtime_error(std::string(r.error().message()));return std::move(*r);}
void check(hyle::Status s) {if(!s.ok())throw std::runtime_error(std::string(s.message()));}
std::size_t used() {
  if(cudaDeviceSynchronize()!=cudaSuccess)throw std::runtime_error("CUDA synchronize failed");
  std::size_t free=0,total=0;
  if(cudaMemGetInfo(&free,&total)!=cudaSuccess)throw std::runtime_error("CUDA memory query failed");
  return total-free;
}
int main() {try {
  constexpr std::int64_t q=1025,k=1041,h=64,d=512;
  auto context=take(c::Context::create(take(c::cuda::device(0)),c::ggml_cuda::provider()));
  auto memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
  auto queue=take(context.create_queue());
  const auto desc=[](std::initializer_list<std::int64_t> s){return take(c::TensorDesc::dense(c::DataType::kFloat32,std::span(s.begin(),s.size())));};
  const std::array descriptions{desc({1,q,h,d}),desc({1,k,1,d}),desc({1,k,1,d}),desc({q,k}),desc({h})};
  std::array<m::Buffer,5> ports;
  std::array<c::ConstTensorView,5> inputs;
  std::vector<float> mask(std::size_t(q*k)),sinks(std::size_t(h),0.0F);
  for(std::int64_t t=0;t<q;++t)for(std::int64_t s=0;s<k;++s)
    mask[std::size_t(t*k+s)]=s>k-q+t || (s+t)%7==0 ? -std::numeric_limits<float>::infinity() : float((s+t)%3-1)/8.0F;
  for(std::int64_t head=0;head<h;++head)sinks[std::size_t(head)]=float(head%9-4)/4.0F;
  std::size_t requested=0;
  for(std::size_t i=0;i<ports.size();++i) {
    const auto bytes=take(descriptions[i].required_bytes());requested+=bytes;
    ports[i]=take(m::Buffer::create(memory.ref(),bytes,256));
    inputs[i]=take(c::ConstTensorView::create(descriptions[i],ports[i].view()));
    if(i==3)check(ports[i].view().write(std::as_bytes(std::span(mask))));
    else if(i==4)check(ports[i].view().write(std::as_bytes(std::span(sinks))));
    else {const std::vector<float> values(bytes/sizeof(float),i==2?0.125F:0.0F);check(ports[i].view().write(std::as_bytes(std::span(values))));}
  }
  const auto output_bytes=take(descriptions[0].required_bytes());requested+=output_bytes;
  auto output=take(m::Buffer::create(memory.ref(),output_bytes,256));
  const std::array outputs{take(c::TensorView::create(descriptions[0],output.view()))};
  const auto after_ports=used();
  auto prepared=take(c::prepare(context,c::model_ops::sink_attention(0.0625F),inputs,outputs,memory.ref()));
  if(prepared.provider().id!=c::ggml_cuda::kProviderId)throw std::runtime_error("wrong provider");
  const auto after_prepare=used();
  auto invocation=take(prepared.create_invocation());const auto after_invocation=used();
  auto done=take(invocation.submit(queue,inputs,outputs));check(done.wait());const auto after_wait=used();
  std::vector<float> actual(output_bytes/sizeof(float));check(output.view().read(std::as_writable_bytes(std::span(actual))));
  double error=0;
  for(std::int64_t t=0;t<q;++t) {
    double mass=0;for(std::int64_t s=0;s<k;++s)mass+=std::exp(double(mask[std::size_t(t*k+s)]));
    for(std::int64_t head=0;head<h;++head) {
      const double expected=0.125*mass/(mass+std::exp(double(sinks[std::size_t(head)])));
      for(std::int64_t channel=0;channel<d;++channel) {
        const auto value=actual[std::size_t((t*h+head)*d+channel)];
        if(!std::isfinite(value))throw std::runtime_error("nonfinite output");
        error=std::max(error,std::abs(double(value)-expected));
      }
    }
  }
  std::cout<<"{\"q\":"<<q<<",\"kv\":"<<k<<",\"heads\":"<<h<<",\"depth\":"<<d
      <<",\"ports_requested_bytes\":"<<requested<<",\"external_mask_bytes\":"<<q*k*4
      <<",\"old_single_scores_bytes\":"<<q*k*h*4<<",\"cuda_used_after_ports\":"<<after_ports
      <<",\"cuda_used_after_prepare\":"<<after_prepare<<",\"cuda_used_after_invocation\":"<<after_invocation
      <<",\"cuda_used_after_wait\":"<<after_wait<<",\"maximum_error\":"<<error
      <<",\"absolute_budget\":0.00001,\"timing\":false,\"residency_is_peak\":false,\"provider_verified\":true}\n";
  if(error>0.00001)throw std::runtime_error("FP64 formula budget failed");
  return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}}
