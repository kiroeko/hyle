// Validation-only closure: original dense input layout and Sink admission.
// Other tensor supports/lowering decline; no old IQ1 SDK enums are invented.
#include "tensor_program.h"
#include "hyle/compute/model_ops.h"
#include <algorithm>
#include <array>
#include <climits>
namespace hyle::compute::ggml_cuda::internal {
bool tensor_operation_supports(Operation operation, std::span<const TensorDesc> inputs,
                               std::span<const TensorDesc> outputs) noexcept {
  if (!operation.custom_as<model_ops::SinkAttention>() || outputs.size()!=1)
    return false;
  std::array<TensorDesc,1> inferred;
  if (!infer_output_descriptions(operation,inputs,inferred).ok() || inferred[0]!=outputs[0])
    return false;
  return *inputs[3].element_count() <=
      (INT32_MAX-1024)/sizeof(float)/inputs[0].dimensions()[2];
}
ggml_tensor *create_tensor_input(ggml_context *context,const TensorDesc &description) {
  const auto type=description.data_type()==DataType::kFloat16 ? GGML_TYPE_F16
      : description.data_type()==DataType::kBFloat16 ? GGML_TYPE_BF16 : GGML_TYPE_F32;
  std::array<std::int64_t,GGML_MAX_DIMS> shape{1,1,1,1};
  std::reverse_copy(description.dimensions().begin(),description.dimensions().end(),shape.begin());
  return ggml_new_tensor(context,type,static_cast<int>(std::max(std::size_t{1},description.rank())),shape.data());
}
std::vector<ggml_tensor *> lower_tensor_operation(ggml_context *,const Recipe &,
    const Node &,std::span<ggml_tensor *const>,std::vector<ScalarConstant> &,
    std::vector<DenseConstant> &,std::span<const float>) { return {}; }
}
