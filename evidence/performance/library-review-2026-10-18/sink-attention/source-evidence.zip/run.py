from pathlib import Path
import argparse, difflib, hashlib, json, os, re, subprocess, sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
OLD=OUT.parent/'ggml-attention-provider'
BUILD=ROOT/'.scratch/b-cuda-d5'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache=read_cache(BUILD)
env=windows_compiler_environment(cache);env['VSLANG']='1033'
toolkit=Path(cache.get('CUDAToolkit_ROOT') or Path(cache['CMAKE_CUDA_COMPILER']).parent.parent)
parser=argparse.ArgumentParser()
parser.add_argument('--build',action='store_true')
parser.add_argument('--tests',choices=['baseline','candidate'])
parser.add_argument('--space',choices=['baseline','candidate'])
args=parser.parse_args()

def invoke(tag,cmd,timeout=180):
    p=subprocess.run(cmd,cwd=BUILD,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
    (OUT/(tag+'-command.json')).write_text(json.dumps({'command':cmd,'cwd':str(BUILD),'exit':p.returncode},indent=2))
    (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
    print(tag,p.returncode)
    text=p.stdout.decode('utf-8',errors='replace')+p.stderr.decode('utf-8',errors='replace')
    if p.returncode: print(text);raise SystemExit(p.returncode)
    return text

def compile_source(tag,source,obj,template):
    command=json.loads(template.read_text())
    if isinstance(command,dict):command=command['command']
    old_source=re.search(r'(?:-c|/c) (.*)$',command).group(1)
    command=command[:command.rfind(old_source)]+str(source)
    command=re.sub(r'/Fo(?:"[^"]+"|\S+)',lambda _: '/Fo"'+str(obj)+'"',command)
    command=re.sub(r'/Fd(?:"[^"]+"|\S+)',lambda _: '/Fd"'+str(obj.with_suffix('.pdb'))+'"',command)
    invoke(tag,command)

base_link=json.loads((OLD/'candidate-strict-link-command.json').read_text())
def link_provider(tag,obj,destination):
    destination.mkdir(exist_ok=True)
    command=[]
    for item in base_link:
        if item.startswith('/out:'):item='/out:'+str(destination/'hyle_compute_provider_ggml_cuda.dll')
        elif item.startswith('/implib:'):item='/implib:'+str(destination/'hyle_compute_provider_ggml_cuda.lib')
        elif item==str(OLD/'ggml_cuda_provider.obj'):item=str(obj)
        elif item==str(OLD/'tensor_program.obj'):item=str(OUT/'helper.obj')
        command.append(item)
    invoke(tag,command)

if args.build:
    (OUT/'provider.candidate.cc').write_bytes((ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc').read_bytes())
    compile_source('helper-compile',OUT/'attention_tensor_support.cc',OUT/'helper.obj',OLD/'helper-compile-command.json')
    for variant in ['baseline','candidate']:
        compile_source(variant+'-compile',OUT/('provider.'+variant+'.cc'),OUT/(variant+'.obj'),OLD/'candidate-compile-command.json')
        link_provider(variant+'-link',OUT/(variant+'.obj'),OUT/variant)
        source=(OUT/('provider.'+variant+'.cc')).read_text()
        marker='    return Status::Ok();\n  }\n};\n\nStatus create_context'
        diagnostic='''    std::size_t explicit_scratch=0;
    for (auto *buffer : scratch) explicit_scratch+=ggml_backend_buffer_get_size(buffer);
    const auto explicit_gallocr=attention_allocator ? ggml_gallocr_get_buffer_size(attention_allocator,0) : std::size_t{0};
    std::fprintf(stderr,"HYLE_SINK_INIT_BYTES scratch=%zu gallocr=%zu total=%zu\\n",explicit_scratch,explicit_gallocr,explicit_scratch+explicit_gallocr);
'''
        modified=source.replace('#include <cmath>','#include <cmath>\n#include <cstdio>')
        assert modified.count(marker)==1
        modified=modified.replace(marker,diagnostic+marker)
        snapshot=OUT/('provider.'+variant+'.diagnostic.cc');snapshot.write_text(modified)
        (OUT/(variant+'-diagnostic.diff')).write_text(''.join(difflib.unified_diff(source.splitlines(True),modified.splitlines(True))))
        compile_source(variant+'-diagnostic-compile',snapshot,OUT/(variant+'.diagnostic.obj'),OLD/'candidate-compile-command.json')
        link_provider(variant+'-diagnostic-link',OUT/(variant+'.diagnostic.obj'),OUT/(variant+'-diagnostic'))
    template=OUT.parent/'ggml-attention-tests/compile-command.json'
    compile_source('tests-compile',ROOT/'tests/compute_provider_ggml_cuda/sink_attention_test.cc',OUT/'sink_test.obj',template)
    cmd=json.loads((OUT.parent/'ggml-attention-tests/link-command.json').read_text())['command']
    cmd=[('/out:'+str(OUT/'sink_tests.exe')) if x.startswith('/out:') else str(OUT/'sink_test.obj') if x.endswith('attention_test.obj') else x for x in cmd]
    invoke('tests-link',cmd)
    compile_source('space-compile',OUT/'space.cc',OUT/'space.obj',template)
    cmd=[('/out:'+str(OUT/'space.exe')) if x.startswith('/out:') else str(OUT/'space.obj') if x==str(OUT/'sink_test.obj') else x for x in cmd]
    invoke('space-link',cmd)
    # Compile only the changed region TU. No CMake build or SDK staging.
    target=r'src/graph_provider_ggml_cuda/CMakeFiles/hyle_graph_provider_ggml_cuda.dir/ggml_cuda_region.cc.obj'
    lines=subprocess.check_output([cache['CMAKE_MAKE_PROGRAM'],'-t','commands',target],cwd=BUILD,env=env,text=True).splitlines()
    command=next(x for x in lines if 'cl.exe' in x and ' -c ' in x and 'ggml_cuda_region.cc' in x)
    command=re.sub(r'/Fo(?:"[^"]+"|\S+)',lambda _: '/Fo"'+str(OUT/'region.obj')+'"',command)
    command=re.sub(r'/Fd(?:"[^"]+"|\S+)',lambda _: '/Fd"'+str(OUT/'region.pdb')+'"',command)
    invoke('region-compile',command)

if args.tests or args.space:
    variant=args.tests or args.space
    directory=OUT/(variant+'-diagnostic' if args.space else variant)
    env['PATH']=os.pathsep.join(map(str,[directory,BUILD/'bin',toolkit/'bin/x64',toolkit/'bin',env['PATH']]))
    exe=OUT/('space.exe' if args.space else 'sink_tests.exe')
    command=[str(exe)] if args.space else [str(exe),'--gtest_filter=GgmlCudaSinkAttention.*']
    text=invoke(('space-' if args.space else 'tests-')+variant,command)
    print(text)
    identity={'provider':str(directory/'hyle_compute_provider_ggml_cuda.dll'),
        'provider_sha256':hashlib.sha256((directory/'hyle_compute_provider_ggml_cuda.dll').read_bytes()).hexdigest(),
        'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'PATH_prefix':env['PATH'].split(os.pathsep)[:4]}
    (OUT/(('space-' if args.space else 'tests-')+variant+'-identity.json')).write_text(json.dumps(identity,indent=2))
