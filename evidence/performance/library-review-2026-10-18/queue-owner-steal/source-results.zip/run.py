from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
env['VSLANG'] = '1033'
records = []


def run(name, argv, extra=None, timeout=60):
    argv = list(map(str, argv))
    actual_env = env.copy()
    if extra:
        actual_env.update(extra)
    result = subprocess.run(argv, cwd=HERE, env=actual_env, capture_output=True, timeout=timeout)
    (HERE / (name + '.stdout.txt')).write_bytes(result.stdout)
    (HERE / (name + '.stderr.txt')).write_bytes(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(HERE), environment_overrides=extra or {}, exit=result.returncode))
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-4000:])
        print(result.stderr.decode(errors='replace')[-4000:])
        raise SystemExit(result.returncode)


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


cpp = ROOT / 'bench/container/queue_sota_bench.cc'
rust = ROOT / 'bench/rust/crossbeam_queue_bench/src/main.rs'
before = (HERE / 'queue_sota.before.cc').read_bytes()
after = cpp.read_bytes()
for a, b in [(b'// Queue mechanism comparisons.', b'// ---- 3. work-stealing OWNER'),
             (b'// ---- 5. ConcurrentVector:', b'int main()')]:
    assert before[before.index(a):before.index(b)] == after[after.index(a):after.index(b)]
insertion = b'''    if (std::string_view(filter) == "ws-owner") {
      bench_ws_owner();
      return 0;
    }
    if (std::string_view(filter) == "ws-steal") {
      bench_ws_steal();
      return 0;
    }
'''
assert after[after.index(b'int main()'):].replace(insertion, b'') == before[before.index(b'int main()'):]
(HERE / 'queue_sota.candidate.cc').write_bytes(after)
(HERE / 'crossbeam.candidate.rs').write_bytes(rust.read_bytes())
(HERE / 'product.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', str(cpp), str(rust)], cwd=ROOT))

obj = HERE / 'queue_sota.obj'
exe = HERE / 'queue_sota.exe'
nanobench = HERE.parent / 'nanobench.obj'
flags = ['/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor',
         '/Zc:__cplusplus', '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG',
         '/DHYLE_STATIC', '/DHYLE_BENCH_MOODYCAMEL', '/I' + str(ROOT / 'include'),
         '/external:I' + str(ROOT / 'third_party/nanobench'),
         '/external:I' + str(ROOT.parent / 'moodycamel-ConcurrentQueue'), '/external:W0']
run('cpp-compile', [CL, *flags, cpp, '/Fo' + str(obj)])
foundation = ROOT / '.scratch/build-compute-v2-dev/bin'
libraries = [foundation / (name + '.lib') for name in ['hyle_platform_thread',
             'hyle_platform', 'hyle_time', 'hyle_mem', 'mimalloc_static', 'hyle_error']]
run('cpp-link', [CL.with_name('link.exe'), '/nologo', '/INCREMENTAL:NO', '/OPT:REF',
             '/OUT:' + str(exe), obj, nanobench, *libraries, 'advapi32.lib',
             'bcrypt.lib', 'Synchronization.lib'])
run('cargo-build', ['cargo', 'build', '--release', '--offline', '--locked',
    '--manifest-path', ROOT / 'bench/rust/crossbeam_queue_bench/Cargo.toml',
    '--target-dir', HERE / 'cargo-target'])
rust_exe = HERE / 'cargo-target/release/crossbeam_queue_bench.exe'
for section in ('ws-owner', 'ws-steal'):
    extra = dict(HYLE_BENCH_SMOKE='1', HYLE_QUEUE_BENCH_FILTER=section)
    run('cpp-smoke-' + section, [exe], extra, timeout=20)
    run('rust-smoke-' + section, [rust_exe], extra, timeout=20)

inputs = [cpp, rust, CL, nanobench, *libraries,
          ROOT / 'include/hyle/container/ws_fifo_queue.h',
          ROOT / 'include/hyle/container/work_stealing_deque.h',
          ROOT.parent / 'moodycamel-ConcurrentQueue/concurrentqueue.h']
(HERE / 'identity.json').write_text(json.dumps(dict(inputs=[identity(p) for p in inputs],
    outputs=[identity(obj), identity(exe), identity(rust_exe)],
    unchanged_cpp_other_sections_byte_checked=True,
    no_product_library_build=True, sdk_copy_or_download=False,
    rust_build='Only three locked cached crates and this benchmark, offline; no pre-existing target directory found in this benchmark or narrow queue scratch paths.'), indent=2) + '\n')
