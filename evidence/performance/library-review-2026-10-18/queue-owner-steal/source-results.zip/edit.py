from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
path = ROOT / 'bench/container/queue_sota_bench.cc'
before = (HERE / 'queue_sota.before.cc').read_bytes()
text = before.decode('utf-8')
start = text.index('// ---- 3. work-stealing OWNER')
end = text.index('// ---- 5. ConcurrentVector:', start)
replacement = '''// ---- 3. work-stealing OWNER (single-thread fill+drain) ---------------------
// FIFO and LIFO are separate policies. Queue construction/destruction is outside
// timed callbacks; each arm gets 200 explicit checked warm waves. Crossbeam's
// native Worker can still shrink/grow during each wave, unlike these fixed rings.
template <class Push, class Pop>
void checked_ws_owner_wave(Push push, Pop pop, bool lifo) {
  for (int i = 0; i < kBatch; ++i)
    if (!push(static_cast<std::uint64_t>(i))) std::abort();
  std::uint64_t value = 0;
  for (int i = 0; i < kBatch; ++i) {
    const auto expected = static_cast<std::uint64_t>(lifo ? kBatch - 1 - i : i);
    if (!pop(value) || value != expected) std::abort();
  }
  if (pop(value)) std::abort();
  ankerl::nanobench::doNotOptimizeAway(value);
}

struct CheckedStealBatch {
  std::array<bool, kBatch> seen{};
  ConsumerResult result;

  void add(std::uint64_t value) {
    if (value >= kBatch || seen[static_cast<std::size_t>(value)]) std::abort();
    seen[static_cast<std::size_t>(value)] = true;
    ++result.count;
    result.sum += value;
    result.xor_sum ^= value;
  }

  void finish() const {
    if (result.count != kBatch || result.sum != kBatch * (kBatch - 1) / 2 ||
        result.xor_sum != 0)
      std::abort();
    ankerl::nanobench::doNotOptimizeAway(result);
  }
};

void bench_ws_owner() {
  WsFifoQueue<std::uint64_t> fifo(kCap);
  WorkStealingDeque<std::uint64_t> lifo(kCap);
  if (!fifo.valid() || !lifo.valid()) std::abort();
  auto fifo_wave = [&] {
    checked_ws_owner_wave(
        [&](std::uint64_t value) { return fifo.try_push_back(value); },
        [&](std::uint64_t& value) { return fifo.try_pop_front(value); }, false);
  };
  auto lifo_wave = [&] {
    checked_ws_owner_wave(
        [&](std::uint64_t value) { return lifo.try_push_bottom(value); },
        [&](std::uint64_t& value) { return lifo.try_pop_bottom(value); }, true);
  };
#if defined(HYLE_BENCH_MOODYCAMEL)
  // General MPMC reference only; not a same-family owner comparison.
  moodycamel::ConcurrentQueue<std::uint64_t> moody(kCap);
  auto moody_wave = [&] {
    checked_ws_owner_wave(
        [&](std::uint64_t value) { return moody.enqueue(value); },
        [&](std::uint64_t& value) { return moody.try_dequeue(value); }, false);
  };
#endif
  for (unsigned wave = 0; wave != 200; ++wave) {
    fifo_wave();
    lifo_wave();
#if defined(HYLE_BENCH_MOODYCAMEL)
    moody_wave();
#endif
  }
  // Functional smoke never enters nanobench's timing path.
  if (std::getenv("HYLE_BENCH_SMOKE") != nullptr) return;
  ankerl::nanobench::Bench b;
  b.title("work-stealing owner single-thread checked fill+drain (512 items)")
      .relative(true)
      .batch(static_cast<std::uint64_t>(kBatch) * 2)
      .minEpochIterations(2000);
  b.run("HYLE WsFifoQueue (FIFO owner)", fifo_wave);
  b.run("HYLE WorkStealingDeque (LIFO owner)", lifo_wave);
#if defined(HYLE_BENCH_MOODYCAMEL)
  b.run("moodycamel (general MPMC ref)", moody_wave);
#endif
}

// ---- 4. work-stealing APIs, single-thread fill+steal+drain -------------------
// There is no concurrent owner/thief here. Owner fill is inside every callback;
// the denominator is 512 transferred items, not isolated steal operations.
// Hyle steals ceil(remaining/2); Crossbeam's default batch cap is 32. Compare
// conservation, not batch boundaries or the order of each directly returned item.
void bench_ws_steal() {
  WsFifoQueue<std::uint64_t> victim(kCap);
  WsFifoQueue<std::uint64_t> thief(kCap);
  WorkStealingDeque<std::uint64_t> deque(kCap);
  if (!victim.valid() || !thief.valid() || !deque.valid()) std::abort();
  auto batch_wave = [&] {
    for (int i = 0; i < kBatch; ++i)
      if (!victim.try_push_back(static_cast<std::uint64_t>(i))) std::abort();
    CheckedStealBatch checked;
    std::uint64_t value = 0;
    while (victim.try_steal_into(thief, value)) {
      checked.add(value);
      while (thief.try_pop_front(value)) checked.add(value);
    }
    checked.finish();
    if (victim.try_pop_front(value) || thief.try_pop_front(value)) std::abort();
  };
  auto single_wave = [&] {
    for (int i = 0; i < kBatch; ++i)
      if (!deque.try_push_bottom(static_cast<std::uint64_t>(i))) std::abort();
    std::uint64_t count = 0, value = 0;
    for (;;) {
      const auto status = deque.try_steal_top(value);
      if (status == hyle::container::StealStatus::kRetry) continue;
      if (status == hyle::container::StealStatus::kEmpty) break;
      if (count >= kBatch || value != count++) std::abort();
    }
    if (count != kBatch || deque.try_pop_bottom(value)) std::abort();
    ankerl::nanobench::doNotOptimizeAway(count);
  };
  for (unsigned wave = 0; wave != 200; ++wave) {
    batch_wave();
    single_wave();
  }
  if (std::getenv("HYLE_BENCH_SMOKE") != nullptr) return;
  ankerl::nanobench::Bench b;
  b.title("work-stealing API single-thread checked fill+steal+drain (512 items)")
      .relative(true)
      .batch(kBatch)
      .minEpochIterations(1000);
  b.run("HYLE WsFifoQueue steal-half + local drain", batch_wave);
  b.run("HYLE WorkStealingDeque single-item steal", single_wave);
}

'''
text = text[:start] + replacement.replace('\n', '\r\n') + text[end:]
needle = '  if (filter != nullptr) {\n'
filters = '''  if (filter != nullptr) {
    if (std::string_view(filter) == "ws-owner") {
      bench_ws_owner();
      return 0;
    }
    if (std::string_view(filter) == "ws-steal") {
      bench_ws_steal();
      return 0;
    }
'''
assert text.count(needle) == 1
text = text.replace(needle, filters, 1)
path.write_bytes(text.encode('utf-8'))
