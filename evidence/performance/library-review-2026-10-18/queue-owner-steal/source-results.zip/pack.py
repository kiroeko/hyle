from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import tomllib
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


metadata = json.loads((HERE / 'cargo-metadata.json').read_text(encoding='utf-8-sig'))
packages = [p for p in metadata['packages'] if p['source']]
locked = {(p['name'], p['version']): p.get('checksum') for p in tomllib.loads((HERE / 'Cargo.lock').read_text())['package']}
peer_files = []
source_checks = []
for package in packages:
    directory = Path(package['manifest_path']).parent
    crate = directory.parents[2] / 'cache' / directory.parent.name / (package['name'] + '-' + package['version'] + '.crate')
    assert identity(crate)['sha256'] == locked[(package['name'], package['version'])]
    peer_files.extend([Path(package['manifest_path']), directory / 'src/lib.rs', crate])
    mismatches = []
    checked = 0
    with tarfile.open(crate, 'r:gz') as source:
        for member in source.getmembers():
            if not member.isfile():
                continue
            relative = Path(member.name).relative_to(package['name'] + '-' + package['version'])
            installed = directory / relative
            expected = source.extractfile(member).read()
            if not installed.is_file() or installed.read_bytes() != expected:
                mismatches.append(str(relative))
            checked += 1
    assert not mismatches
    source_checks.append(dict(package=package['name'], version=package['version'], archive=identity(crate),
                              installed_source_files_compared=checked, mismatches=mismatches))
deque_dir = Path(next(p['manifest_path'] for p in packages if p['name'] == 'crossbeam-deque')).parent
deque_source = deque_dir / 'src/deque.rs'
peer_files.append(deque_source)
write('source-review.json', dict(
    task='Repair owner/steal benchmark correctness and describe policies; no new timing or queue product change.',
    previous_failings=[
        dict(source='queue_sota.before.cc:415-451', issue='Owner push/pop results ignored, no FIFO/LIFO or complete-payload oracle; static construction occurs on first callback.'),
        dict(source='queue_sota.before.cc:465-492', issue='Batch steal only blackboxes sum; single-item steal spends exactly 512 attempts, silently treating Retry as an item attempt and never checking full drain.'),
        dict(source='crossbeam.before.rs:31-53,58-132', issue='Returned sums are not checked; sample vector sorted in place and only median/min printed; original epoch sequence and elapsed totals lost.'),
        dict(source='crossbeam.before.rs:3-20,56-57; Cargo.toml comments', issue='EXACT/steady-buffer/equivalent compiler optimization claims are not established. Actual native policy and build flags must be recorded separately.')],
    current_contract=[
        dict(source='bench/container/queue_sota_bench.cc:408-418; bench/rust/crossbeam_queue_bench/src/main.rs:59-71', behavior='512 pushes, each C++ bool succeeds; native Rust push has no failure return. Every FIFO/LIFO pop equals its exact expected value and final pop is empty.'),
        dict(source='bench/container/queue_sota_bench.cc:420-438,494-506; bench/rust/crossbeam_queue_bench/src/main.rs:73-104,127-156', behavior='Batch steal validates all 512 distinct values in range, count 512, sum 130816, XOR 0, both queues empty. No shared batch-return order is imposed.'),
        dict(source='bench/container/queue_sota_bench.cc:507-518; bench/rust/crossbeam_queue_bench/src/main.rs:158-182', behavior='Single-item steal retries Retry, stops only at Empty, validates FIFO 0..511 and final owner empty.'),
        dict(source='bench/container/queue_sota_bench.cc:440-482,489-531; bench/rust/crossbeam_queue_bench/src/main.rs:18-27,106-184', behavior='Construction/registration before explicit 200 checked warm waves and all timed callbacks; destruction after timings. Smoke returns before nanobench construction or Instant::now.'),
        dict(source='bench/rust/crossbeam_queue_bench/src/main.rs:28-56', behavior='Existing 400 epochs x 50 calls retained; original-order samples and exact elapsed_ns/iterations/units-per-call are emitted. Sort only a clone; even-size median uses the mean of the two central values.'),
        dict(source='bench/container/queue_sota_bench.cc:736-746; bench/rust/crossbeam_queue_bench/src/main.rs:194-203', behavior='Narrow ws-owner/ws-steal filters support non-timed smoke; no other C++ benchmark section altered.')],
    actual_peer=dict(packages=[dict(name=p['name'], version=p['version'], source=p['source'], manifest_path=p['manifest_path']) for p in packages],
                     local_path_patch_used=False, files=[identity(p) for p in peer_files],
                     cached_source_matches_package_archive=source_checks),
    policy_boundaries=[
        dict(source='crossbeam-deque-0.8.6/src/deque.rs:16-18,222,250,395-415,473-474,526-527', meaning='Worker starts with 64 capacity, grows on push and shrinks during owner pop. Repeated 512-item owner fill/drain can still grow/shrink after warmup; CAP=1024 in the old benchmark was only a label, not a Worker capacity argument.'),
        dict(source='crossbeam-deque-0.8.6/src/deque.rs:937-938,1006-1009; include/hyle/container/ws_fifo_queue.h:170-172', meaning='Crossbeam default steal_batch_and_pop caps each transfer at 32; Hyle takes ceil(remaining/2), initially 256. Both native policies retained unchanged.'),
        dict(source='include/hyle/container/ws_fifo_queue.h:138-145; crossbeam-deque-0.8.6/src/deque.rs:1020-1061,1153-1157', meaning='Hyle directly returns the last copied batch item; Crossbeam FIFO directly returns the first and queues following items. Conservation is the common payload contract.'),
        dict(source='bench/container/queue_sota_bench.cc:484-488; bench/rust/crossbeam_queue_bench/src/main.rs:1-6,122-126,188-193', meaning='One calling thread executes both logical roles; no worker construction/join exists. Owner fill is inside every steal callback. Owner units count push+pop (1024), steal units count transferred items (512), including fill and local drain/checks.')],
    suggested_only_next_trace='If parent requests one necessary comparison, warm single-item steal is the narrowest: it retains native FIFO-from-top semantics without batch-cap mismatch or owner-pop buffer shrink. Still disclose C++/Rust compiler/harness/epoch-reclamation differences; no new result is established here.',
    no_new_performance_result=True))

commands = json.loads((HERE / 'commands.json').read_text())
smokes = [c for c in commands if '-smoke-' in c['name']]
assert len(smokes) == 4 and all(c['exit'] == 0 for c in smokes)
write('summary.json', dict(
    result='Both formal benchmark sources corrected; all four targeted non-timed smoke processes exit 0.',
    canonical_sources=[identity(ROOT / 'bench/container/queue_sota_bench.cc'), identity(ROOT / 'bench/rust/crossbeam_queue_bench/src/main.rs')],
    checks='C++ owner FIFO/LIFO plus optional actual Moody reference; C++ batch/single steal; Rust owner FIFO/LIFO and batch/single steal, each 200 checked waves.',
    compile='One C++ TU /O2 /Ob2 /MD with cached nanobench/foundation; Cargo release offline locked builds only this benchmark and three already cached registry crates, no pre-existing benchmark target found.',
    tests=smokes, product_queue_edit=False, unrelated_cpp_sections_byte_identical=True,
    no_instant_or_nanobench_timing_entered=True, no_ranking=True, no_full_benchmark=True,
    no_peer_algorithm_edit=True, no_sdk_copy_or_download=True,
    limits=['No actual timing, no new performance conclusion or sample stream was generated.',
            'Rust normal-path sample retention was compiled and read, not executed by the smoke path.',
            'Smoke has no concurrent actor, so Retry handling is checked structurally and not forced by a race.',
            'Different batch limits, native Worker growth/shrink, language/compiler/harness and epoch reclamation remain disclosed policy costs.',
            'TBB/rigtorp optional branches were not compiled in this batch; their source sections are unchanged.'],
    peer='Registry crossbeam-deque0.8.6, crossbeam-epoch0.9.18, crossbeam-utils0.8.21; see cargo-metadata.json, Cargo.lock and source-review.json.',
    cleanup='cleanup-manifest.json distinguishes immediate consumer artifacts from the small Cargo dependency/build cache retained until parent chooses a follow-up; no deletion performed.'))

all_target = sorted((p for p in (HERE / 'cargo-target').rglob('*') if p.is_file()), key=lambda p: p.relative_to(HERE).as_posix())
consumer_target = [p for p in all_target if 'crossbeam_queue_bench' in p.name or
                   any('crossbeam_queue_bench-' in part for part in p.relative_to(HERE).parts)]
cache_target = [p for p in all_target if p not in consumer_target]
immediate = [HERE / 'queue_sota.obj', HERE / 'queue_sota.exe', *consumer_target]
write('cleanup-manifest.json', dict(
    files=[identity(p) for p in immediate], bytes=sum(p.stat().st_size for p in immediate),
    optional_after_followup=dict(files=[identity(p) for p in cache_target], bytes=sum(p.stat().st_size for p in cache_target),
                                reason='Small compiled Cargo native peer dependencies and build metadata; retain temporarily for the single possible parent-selected follow-up, or remove exactly these files after that decision.'),
    all_new_artifacts_bytes=sum(p.stat().st_size for p in immediate + cache_target),
    byte_accounting='Sum of logical file sizes; Cargo may hardlink duplicate outputs, so this is not measured physical disk usage.',
    retain='All source/commands/metadata/logs plus pre-existing shared nanobench/foundation and Cargo registry source/archive caches.',
    action='Parent writes exact paths to repo-root test.ps1 before deletion. This agent did not delete anything.'))

snapshots = {'snapshots/ws_fifo_queue.h': ROOT / 'include/hyle/container/ws_fifo_queue.h',
             'snapshots/work_stealing_deque.h': ROOT / 'include/hyle/container/work_stealing_deque.h',
             'snapshots/crossbeam-deque/deque.rs': deque_source,
             'snapshots/crossbeam-deque/Cargo.toml': deque_dir / 'Cargo.toml'}
small = [p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.cc','.rs','.toml','.lock','.json','.txt','.diff') and p.name != 'archive-identity.json']
archive = HERE / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for p in sorted(small, key=lambda p:p.name):
        output.write(p,p.name)
    for name,p in sorted(snapshots.items()):
        output.write(p,name)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None
    assert not any(Path(n).suffix.lower() in ('.obj','.exe','.pdb','.rlib','.rmeta','.dll','.lib') for n in source.namelist())
    members=len(source.namelist())
write('archive-identity.json', dict(**identity(archive), members=members, binary_payloads_included=False))
print(json.dumps(dict(archive=identity(archive), members=members,
                     canonical=[identity(ROOT / 'bench/container/queue_sota_bench.cc'), identity(ROOT / 'bench/rust/crossbeam_queue_bench/src/main.rs')],
                     cleanup_bytes=sum(p.stat().st_size for p in immediate),
                     temporary_cargo_cache_bytes=sum(p.stat().st_size for p in cache_target)),indent=2))
