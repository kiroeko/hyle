#include "hyle/sched/task_scope.h"
#include "hyle/core/cache.h"
#include "hyle/util/spin_lock.h"
namespace hyle::sched::detail {
struct TaskScopeSeparatedLayout {
  enum class JoinPhase : unsigned char { kOpen, kJoining, kJoined };
  mem::AllocatorRef allocator;
  CancelToken cancel;
  std::optional<ExecutionPriority> priority;
  alignas(core::kDestructiveInterferenceSize) util::SpinLock control_lock;
  TaskScopeCompletion* head = nullptr;
  TaskScopeCompletion* tail = nullptr;
  std::atomic<bool> closed{false};
  bool ever_admitted = false;
  JoinPhase join_phase = JoinPhase::kOpen;
  Status first_error;
};
static_assert(alignof(TaskScopeSeparatedLayout) == 64);
static_assert(sizeof(TaskScopeSeparatedLayout) == 128);
static_assert(offsetof(TaskScopeSeparatedLayout, control_lock) == 64);
}
