from pathlib import Path
import ctypes,json,os,subprocess,time,struct,sys
root=Path(__file__).resolve().parent
kernel=ctypes.WinDLL("kernel32",use_last_error=True)
kernel.GetCurrentProcess.restype=ctypes.c_void_p
handle=kernel.GetCurrentProcess()
kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
if not kernel.SetProcessAffinityMask(handle,0x55):raise ctypes.WinError(ctypes.get_last_error())
freq=ctypes.c_longlong();kernel.QueryPerformanceFrequency(ctypes.byref(freq))
length=ctypes.c_ulong();kernel.GetSystemCpuSetInformation(None,0,ctypes.byref(length),None,0)
buf=ctypes.create_string_buffer(length.value)
if not kernel.GetSystemCpuSetInformation(buf,length,ctypes.byref(length),None,0):raise ctypes.WinError(ctypes.get_last_error())
cpus=[];pos=0
while pos<length.value:
 size,kind=struct.unpack_from("II",buf.raw,pos)
 if not size:break
 if kind==0:
  ident,group,logical,core,llc,numa,eff,flags=struct.unpack_from("IHBBBBBB",buf.raw,pos+8)
  if logical in [0,2,4,6] and group==0:cpus.append(dict(id=ident,group=group,logical=logical,core=core,efficiency=eff,flags=flags))
 pos+=size
host=dict(selected_cpus=cpus,qpc_frequency=freq.value,process_mask="0x55",priority="ABOVE_NORMAL",note="Four worker singleton affinities are checked in the original consumer. No old launcher or governance control was used.")
(root/"host.json").write_text(json.dumps(host,indent=2))
assert len(cpus)==4 and len({c["core"] for c in cpus})==4
cases=[("primary","ab",None),("placement","ba",None),("placement","ab",None),("primary","ba",None)]
if len(sys.argv)>1 and sys.argv[1]=="aa":cases=[("primary",order,route) for route in ["candidate","peer"] for order in ["ab","ba"]]
if len(sys.argv)>1 and sys.argv[1]=="exact":cases=[("exact_baseline","ab",None),("exact_front","ba",None),("exact_front","ab",None),("exact_baseline","ba",None)]
if len(sys.argv)>1 and sys.argv[1]=="done":cases=[("exact_baseline","ab",None),("exact_done_first","ba",None),("exact_done_first","ab",None),("exact_baseline","ba",None)]
if len(sys.argv)>1 and sys.argv[1]=="phases":cases=[("phases","ab",None),("phases","ba",None)]
if len(sys.argv)>1 and sys.argv[1]=="separate":cases=[("exact_baseline","ab",None),("exact_separate","ba",None),("exact_separate","ab",None),("exact_baseline","ba",None)]
if len(sys.argv)>1 and sys.argv[1]=="separate_check":cases=[("exact_separate","ba",None),("exact_baseline","ba",None)]
if len(sys.argv)>1 and sys.argv[1]=="scopeonly":cases=[("exact_baseline","ab","candidate"),("exact_separate","ab","candidate"),("exact_separate","ab","candidate"),("exact_baseline","ab","candidate")]
for case_index,(variant,order,route) in enumerate(cases):
 name=("aa-"+route if route else variant)+"-"+order
 if len(sys.argv)>1 and sys.argv[1] in ["done","separate","separate_check"]:name=sys.argv[1]+"-test-"+name
 if len(sys.argv)>1 and sys.argv[1]=="scopeonly":name="scopeonly-"+str(case_index+1)+"-"+variant+"-"+order
 env={k:v for k,v in os.environ.items() if not k.startswith(("HYLE_BENCH_","HYLE_PERF_"))}
 opts={"HYLE_PERF_WORKER_CPUS":"0,2,4,6","HYLE_PERF_PARENT_MASK":"0x55","HYLE_PERF_PRIORITY":"above-normal","HYLE_PERF_SAMPLING_TOPOLOGY":"four-distinct-physical-cores","HYLE_PERF_RUN_NONCE":"task-scope-current-20261018-"+name}
 if order=="ba":opts["HYLE_BENCH_RIVAL_FIRST"]="1"
 if route:opts["HYLE_BENCH_AA_ROUTE"]=route
 env.update(opts);cmd=[str(root/"build"/("task_scope_"+variant+".exe"))]
 begin=time.time();process=subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding="utf-8",errors="replace",creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
 stdout,stderr=process.communicate(timeout=60)
 (root/(name+".json")).write_text(json.dumps(dict(command=cmd,env=opts,pid=process.pid,exit=process.returncode,elapsed_s=time.time()-begin),indent=2))
 (root/(name+".stdout.txt")).write_text(stdout);(root/(name+".stderr.txt")).write_text(stderr)
 print(name,process.returncode);print(stdout);print(stderr)
 if process.returncode:raise SystemExit(process.returncode)
