from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
env['VSLANG'] = '1033'
records = []

def run(name, argv):
    start = time.monotonic()
    result = subprocess.run([str(v) for v in argv], cwd=HERE, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
    (HERE / (name + '.log')).write_bytes(result.stdout)
    records.append(dict(name=name, argv=[str(v) for v in argv], returncode=result.returncode, seconds=time.monotonic()-start))
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode('utf-8', errors='replace')[-8000:])
        raise SystemExit(result.returncode)

flags = ['/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus', '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/DHYLE_STATIC', '/DFOLLY_NO_CONFIG',
         '/I'+str(ROOT/'include'), '/external:I'+str(ROOT/'third_party/nanobench'), '/external:I'+str(ROOT.parent/'folly'), '/external:W0',
         '/sourceDependencies', str(HERE/'source-dependencies.json')]
run('compile', [CL, *flags, HERE/'main.cc', '/Fo'+str(HERE/'main.obj')])
foundation = ROOT/'.scratch/build-compute-v2-dev/bin'
libraries = [foundation/(name+'.lib') for name in ['hyle_platform_thread', 'hyle_platform', 'hyle_time', 'hyle_mem', 'mimalloc_static', 'hyle_error']]
nano = ROOT/'.scratch/perf-review-2026-10-18/queue-contract/nanobench.obj'
run('link', [CL.with_name('link.exe'), '/nologo', '/INCREMENTAL:NO', '/OPT:REF', '/MAP:'+str(HERE/'main.map'), '/OUT:'+str(HERE/'main.exe'), HERE/'main.obj', nano, *libraries, 'advapi32.lib', 'bcrypt.lib', 'Synchronization.lib'])
paths = [HERE/'main.cc', HERE/'main.exe', HERE/'main.obj', CL, nano, *libraries]
deps = json.loads((HERE/'source-dependencies.json').read_text(encoding='utf-8-sig'))['Data']['Includes']
paths += [Path(p) for p in deps if str(ROOT.parent/'folly').lower().replace('/', '\\') in p.lower().replace('/', '\\') or str(ROOT/'include').lower().replace('/', '\\') in p.lower().replace('/', '\\')]
identities = [dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
peer = subprocess.run(['git', '-C', str(ROOT.parent/'folly'), 'rev-parse', 'HEAD'], check=True, capture_output=True, text=True).stdout.strip()
clean = subprocess.run(['git', '-C', str(ROOT.parent/'folly'), 'status', '--short'], check=True, capture_output=True, text=True).stdout
(HERE/'identity.json').write_text(json.dumps(dict(folly_commit=peer, folly_git_status=clean, config='Official FOLLY_NO_CONFIG supported by actual portability/Config.h; no generated folly-config.h or peer-source edit.', files=identities), indent=2)+'\n', encoding='utf-8')
