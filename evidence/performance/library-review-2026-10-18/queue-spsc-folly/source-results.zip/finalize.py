from pathlib import Path
import hashlib
import json
import statistics
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
arms = []
windows = []
for order in ['ab', 'ba']:
    raw = json.loads((HERE/(order+'.epochs.json')).read_text(encoding='utf-8'))
    results = []
    for result in raw['results']:
        measurements = result['measurements']
        values = [m['elapsed']*1e9/(1<<18) for m in measurements]
        windows += [m['elapsed']*m['iterations'] for m in measurements]
        results.append(dict(name=result['name'], median_ns_per_transferred_item=statistics.median(values), all_epoch_ns_per_item=values, epoch_MAPE=result['medianAbsolutePercentError(elapsed)']))
    by_name = {r['name']: r for r in results}
    arms.append(dict(order=order, arms=results, hyle_over_folly=by_name['Hyle SPSC']['median_ns_per_transferred_item']/by_name['actual Folly PCQueue']['median_ns_per_transferred_item']))
summary = dict(
    conclusion='No Hyle loss reproduced in these two fixed AB/BA processes. Cross-process drift and epoch overlap are substantial; no general or stable superiority claim, no product queue change.',
    trace=dict(payload='262144 scalar uint64 values1..262144 per transfer, every pop exact FIFO value checked, final sum and empty checked. Before timing both fill1024, reject overflow, drain exact values and reject underflow.',
               capacity='Hyle requested1024 and actual Folly constructor1025, both1024 usable sentinel slots. Original actual Folly uses32-bit atomic indices, Hyle uses size_t; both domains sufficient for this capacity.',
               boundary='Both queues constructed before all timing. For each arm exactly one persistent producer/consumer pair is created, pinned and warmed once outside timing. Timed callback includes coordinator generation notify/wait, full transfer, exact checks, checksum and empty. Worker join/destruction outside timing, both queues destroyed after all timing/output. Spin retries have no yield for either peer.',
               unit='One transferred item includes one successful scalar push and pop. Raw elapsed is seconds per262144-item complete transfer. It is not the ST512 per-individual-operation unit.',
               resources='Same group0 three distinct highest-efficiency physical cores: producerLP0, consumerLP2, coordinatorLP4. Process mask0x15 and ABOVE_NORMAL; actual worker masks/current CPUs read back. Runtime auxiliary threads not enumerated or constrained.',
               schedule='Fixed AB then BA, nine epochs per arm, minEpochTime20ms/minEpochIterations3, all36epochs retained. No AA because no current Hyle loss; no trimming/additional shape.'),
    results=arms,
    clock=dict(qpc_frequency_hz=10000000, qpc_tick_seconds=1e-7, shortest_actual_epoch_seconds=min(windows), note='Clock tick differs from epoch and cross-process variation. Some large epochs/outliers retained without filtering.'),
    implementation=dict(actual_peer='Local clean folly commit65749da412d92fe27d87ae45a8ef670720712858, actual ProducerConsumerQueue.h and transitive header closure. FOLLY_NO_CONFIG is the peer-supported switch, no generated config shim or peer edits.',
                        observed_layout='Hyle384B align128; Folly256B align64, reported hardware_destructive_interference_size64. No layout equalization or product change.',
                        build='One fresh MSVC14.50/O2/MD C++latest TU, existing nanobench/foundation objects. Actual compile/link logs exit0, no warnings. No full library/peer build.'),
    failures=[], limits='One Windows13900K uint64 capacity1024 trace. No full/allocation/cancellation stress, other systems/topologies, large-capacity domain, bulk API or MPMC result. Formal spsc_bench still explicitly labels its old local shape; this evidence uses actual Folly.')
(HERE/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
cleanup = []
for name in ['main.obj', 'main.exe']:
    path = HERE/name
    cleanup.append(dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(HERE/'cleanup-manifest.json').write_text(json.dumps(dict(files=cleanup, bytes=sum(x['bytes'] for x in cleanup), retain='All sources/logs/raw epochs/maps/identities and pre-existing nanobench/foundation/Folly checkout.', action='Candidates only. Root test.ps1 performs exact preflight/delete.'), indent=2)+'\n', encoding='utf-8')
archive = HERE/'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(HERE.iterdir()):
        if path.is_file() and path.suffix not in ['.exe', '.obj', '.zip'] and path.name != 'archive-record.json':
            z.write(path, path.name)
    identity = json.loads((HERE/'identity.json').read_text(encoding='utf-8'))
    for item in identity['files']:
        path = Path(item['path'])
        for base, label in [(ROOT.parent/'folly', 'peer'), (ROOT/'include', 'hyle-headers')]:
            if path.is_relative_to(base) and path.suffix in ['.h', '.hpp']:
                z.write(path, label+'/'+path.relative_to(base).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    members = len(z.infolist())
record = dict(path=str(archive), bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=members, crc='PASS')
(HERE/'archive-record.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(archive=record, results=[dict(order=x['order'], ratio=x['hyle_over_folly']) for x in arms], cleanup_bytes=sum(x['bytes'] for x in cleanup)), indent=2))
