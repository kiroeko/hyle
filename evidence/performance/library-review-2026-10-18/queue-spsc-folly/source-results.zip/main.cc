#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <nanobench.h>
#include <folly/ProducerConsumerQueue.h>
#include "hyle/container/spsc_queue.h"
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string_view>
#include <thread>

namespace nb=ankerl::nanobench;
constexpr std::uint64_t kItems=1u<<18;
constexpr std::size_t kCapacity=1024;
void check(bool condition,const char*what){if(!condition){std::fprintf(stderr,"FAIL:%s\n",what);std::abort();}}
using Hyle=hyle::container::SpscQueue<std::uint64_t>;
struct ActualFolly {
  folly::ProducerConsumerQueue<std::uint64_t> queue{1025};
  bool try_push(std::uint64_t value){return queue.write(value);}
  bool try_pop(std::uint64_t&value){return queue.read(value);}
  bool empty()const{return queue.isEmpty();}
};
struct WorkerRecord { DWORD tid=0;unsigned cpu=0;GROUP_AFFINITY affinity{}; };
void pin(unsigned cpu,WorkerRecord&record){
  check(cpu<64,"CPU group0 range");
  check(SetThreadAffinityMask(GetCurrentThread(),DWORD_PTR{1}<<cpu)!=0,"set worker affinity");
  check(GetThreadGroupAffinity(GetCurrentThread(),&record.affinity)!=FALSE,"read worker affinity");
  record.tid=GetCurrentThreadId();record.cpu=GetCurrentProcessorNumber();
  check(record.affinity.Group==0 && record.affinity.Mask==(KAFFINITY{1}<<cpu),"worker affinity exact");
  check(record.cpu==cpu,"worker actual CPU");
}
template<class Queue> class Transfer {
 public:
  Transfer(Queue&queue,unsigned producer,unsigned consumer,std::array<WorkerRecord,2>&records)
      :queue_(queue),records_(records),producer_([this,producer]{
         pin(producer,records_[0]);ready_.fetch_add(1,std::memory_order_release);ready_.notify_one();produce();
       }),consumer_([this,consumer]{
         pin(consumer,records_[1]);ready_.fetch_add(1,std::memory_order_release);ready_.notify_one();consume();
       }){
    for(unsigned n=ready_.load(std::memory_order_acquire);n!=2;n=ready_.load(std::memory_order_acquire))ready_.wait(n,std::memory_order_relaxed);
  }
  ~Transfer(){stop_.store(true,std::memory_order_release);generation_.fetch_add(1,std::memory_order_release);generation_.notify_all();producer_.join();consumer_.join();}
  std::uint64_t run(){
    done_.store(0,std::memory_order_relaxed);generation_.fetch_add(1,std::memory_order_release);generation_.notify_all();
    for(unsigned n=done_.load(std::memory_order_acquire);n!=2;n=done_.load(std::memory_order_acquire))done_.wait(n,std::memory_order_relaxed);
    check(queue_.empty(),"empty after transfer");return sum_;
  }
 private:
  bool round(std::uint64_t&observed){
    auto next=generation_.load(std::memory_order_acquire);
    while(next==observed){generation_.wait(next,std::memory_order_relaxed);next=generation_.load(std::memory_order_acquire);}
    observed=next;return !stop_.load(std::memory_order_acquire);
  }
  void finish(){done_.fetch_add(1,std::memory_order_release);done_.notify_one();}
  void produce(){std::uint64_t observed=0;while(round(observed)){
    for(std::uint64_t value=1;value<=kItems;++value)while(!queue_.try_push(value)){}
    finish();
  }}
  void consume(){std::uint64_t observed=0;while(round(observed)){
    std::uint64_t sum=0;
    for(std::uint64_t expected=1;expected<=kItems;++expected){
      std::uint64_t value=0;while(!queue_.try_pop(value)){}
      check(value==expected,"complete FIFO payload");sum+=value;
    }
    sum_=sum;finish();
  }}
  Queue&queue_;std::array<WorkerRecord,2>&records_;
  std::atomic<unsigned>ready_{0},done_{0};std::atomic<std::uint64_t>generation_{0};
  std::atomic<bool>stop_{false};std::uint64_t sum_=0;
  std::thread producer_,consumer_;
};
template<class Queue>void capacity_check(Queue&q){
  check(q.empty(),"initial empty");
  for(std::size_t i=0;i<kCapacity;++i)check(q.try_push(i),"1024 usable slots");
  check(!q.try_push(9999),"exact full");
  for(std::size_t i=0;i<kCapacity;++i){std::uint64_t value=0;check(q.try_pop(value)&&value==i,"capacity FIFO");}
  std::uint64_t value=0;check(!q.try_pop(value)&&q.empty(),"exact empty");
}
template<class Queue>void measure(nb::Bench&bench,Queue&q,const char*label,unsigned producer,unsigned consumer){
  std::array<WorkerRecord,2>records{};
  {
    Transfer runner(q,producer,consumer,records);
    check(runner.run()==kItems*(kItems+1)/2,"warmup checksum");
    std::fprintf(stderr,"warmup label=%s producer_tid=%lu cpu=%u group=%hu mask=%llu consumer_tid=%lu cpu=%u group=%hu mask=%llu\n",
      label,records[0].tid,records[0].cpu,records[0].affinity.Group,(unsigned long long)records[0].affinity.Mask,
      records[1].tid,records[1].cpu,records[1].affinity.Group,(unsigned long long)records[1].affinity.Mask);
    bench.run(label,[&]{const auto sum=runner.run();check(sum==kItems*(kItems+1)/2,"timed checksum");nb::doNotOptimizeAway(sum);});
  }
}
int main(int argc,char**argv){
  check(argc==6,"arguments order output producer consumer main");
  const std::string_view order=argv[1];check(order=="ab"||order=="ba"||order=="aa","order");
  const auto producer=unsigned(std::strtoul(argv[3],nullptr,10));
  const auto consumer=unsigned(std::strtoul(argv[4],nullptr,10));
  const auto coordinator=unsigned(std::strtoul(argv[5],nullptr,10));
  check(producer<64&&consumer<64&&coordinator<64,"CPU indices");
  check(producer!=consumer&&producer!=coordinator&&consumer!=coordinator,"distinct logical CPUs");
  const DWORD_PTR mask=(DWORD_PTR{1}<<producer)|(DWORD_PTR{1}<<consumer)|(DWORD_PTR{1}<<coordinator);
  check(SetProcessAffinityMask(GetCurrentProcess(),mask)!=FALSE,"set process affinity");
  DWORD_PTR actual=0,system=0;check(GetProcessAffinityMask(GetCurrentProcess(),&actual,&system)!=FALSE&&actual==mask,"actual process affinity");
  check(SetPriorityClass(GetCurrentProcess(),ABOVE_NORMAL_PRIORITY_CLASS)!=FALSE,"same process priority");
  WorkerRecord main_record;pin(coordinator,main_record);
  LARGE_INTEGER frequency{};check(QueryPerformanceFrequency(&frequency)!=FALSE,"QPC frequency");
  std::fprintf(stderr,"order=%s process_mask=%llu main_tid=%lu cpu=%u QPC_Hz=%lld Hyle_bytes=%zu Hyle_align=%zu Folly_bytes=%zu Folly_align=%zu Folly_interference=%zu\n",
    argv[1],(unsigned long long)actual,main_record.tid,main_record.cpu,frequency.QuadPart,
    sizeof(Hyle),alignof(Hyle),sizeof(folly::ProducerConsumerQueue<std::uint64_t>),alignof(folly::ProducerConsumerQueue<std::uint64_t>),folly::hardware_destructive_interference_size);
  Hyle hyle(kCapacity);ActualFolly folly;check(hyle.valid(),"Hyle allocation");
  check(hyle.capacity()==kCapacity&&folly.queue.capacity()==kCapacity,"matched usable capacity");
  capacity_check(hyle);capacity_check(folly);
  nb::Bench bench;bench.title("SPSC actual pinned Folly, 1024 usable slots").batch(kItems).unit("transferred item")
    .epochs(9).minEpochIterations(3).minEpochTime(std::chrono::milliseconds(20)).performanceCounters(false);
  if(order=="ab"){
    measure(bench,hyle,"Hyle SPSC",producer,consumer);measure(bench,folly,"actual Folly PCQueue",producer,consumer);
  }else if(order=="ba"){
    measure(bench,folly,"actual Folly PCQueue",producer,consumer);measure(bench,hyle,"Hyle SPSC",producer,consumer);
  }else{
    measure(bench,hyle,"Hyle AA first",producer,consumer);measure(bench,hyle,"Hyle AA second",producer,consumer);
  }
  std::ofstream output(argv[2]);check(bool(output),"result file");bench.render(nb::templates::json(),output);
  return output?0:2;
}
