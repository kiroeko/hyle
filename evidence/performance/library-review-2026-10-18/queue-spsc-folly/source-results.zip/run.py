from pathlib import Path
import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import os
import platform
import statistics
import struct
import subprocess
import time
import winreg

HERE = Path(__file__).resolve().parent
k = C.WinDLL('kernel32', use_last_error=True)
k.GetCurrentProcess.restype = W.HANDLE
k.GetProcessAffinityMask.argtypes = [W.HANDLE, C.POINTER(C.c_size_t), C.POINTER(C.c_size_t)]
k.GetSystemCpuSetInformation.argtypes = [C.c_void_p, W.ULONG, C.POINTER(W.ULONG), W.HANDLE, W.ULONG]
length = W.ULONG()
k.GetSystemCpuSetInformation(None, 0, C.byref(length), None, 0)
buf = C.create_string_buffer(length.value)
if not k.GetSystemCpuSetInformation(buf, length, C.byref(length), None, 0):
    raise C.WinError(C.get_last_error())
parent_mask, system_mask = C.c_size_t(), C.c_size_t()
if not k.GetProcessAffinityMask(k.GetCurrentProcess(), C.byref(parent_mask), C.byref(system_mask)):
    raise C.WinError(C.get_last_error())
cpus = []
pos = 0
while pos < length.value:
    size, kind = struct.unpack_from('II', buf.raw, pos)
    if size == 0:
        raise RuntimeError('invalid CPU record')
    if kind == 0:
        ident, group, logical, core, llc, numa, eff, flags = struct.unpack_from('IHBBBBBB', buf.raw, pos + 8)
        cpus.append(dict(id=ident, group=group, logical=logical, core=core, llc=llc, numa=numa, efficiency_class=eff, flags=flags))
    pos += size
available = [c for c in cpus if c['group'] == 0 and parent_mask.value & (1 << c['logical'])]
best = max(c['efficiency_class'] for c in available)
selected = []
for cpu in available:
    if cpu['efficiency_class'] == best and cpu['core'] not in {c['core'] for c in selected}:
        selected.append(cpu)
    if len(selected) == 3:
        break
assert len(selected) == 3
frequency = C.c_longlong()
if not k.QueryPerformanceFrequency(C.byref(frequency)):
    raise C.WinError(C.get_last_error())
with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:
    cpu_name = winreg.QueryValueEx(key, 'ProcessorNameString')[0]
host = dict(cpu=cpu_name, platform=platform.platform(), all_cpu_sets=cpus, parent_mask=hex(parent_mask.value), selected_cpu_sets=selected,
            roles=['producer', 'consumer', 'coordinator'], qpc_frequency_hz=frequency.value,
            resources='Each worker is pinned to a distinct group0 physical core, as is the coordinator. Actual affinity/current-CPU readback in stderr. One producer and consumer active at a time; runtime auxiliary thread count is not constrained or claimed.')
(HERE/'host.json').write_text(json.dumps(host, indent=2)+'\n', encoding='utf-8')
records = []
orders = ['aa'] if '--aa' in os.sys.argv else ['ab', 'ba']
for order in orders:
    output = HERE/(order+'.epochs.json')
    assert not output.exists(), 'do not overwrite prior formal epochs'
    cmd = [str(HERE/'main.exe'), order, str(output), *[str(c['logical']) for c in selected]]
    start = time.time()
    process = subprocess.run(cmd, cwd=HERE, capture_output=True, timeout=90)
    (HERE/(order+'.stdout.log')).write_bytes(process.stdout)
    (HERE/(order+'.stderr.log')).write_bytes(process.stderr)
    records.append(dict(order=order, argv=cmd, returncode=process.returncode, start_unix_seconds=start, elapsed_seconds=time.time()-start))
    (HERE/('aa-process.json' if order=='aa' else 'processes.json')).write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(order, process.returncode, process.stderr.decode('utf-8', errors='replace'), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
    raw = json.loads(output.read_text(encoding='utf-8'))
    for result in raw['results']:
        values = [m['elapsed'] for m in result['measurements']]
        print(result['name'], 'ns/item', statistics.median(values)*1e9/(1<<18), 'MAPE', result.get('medianAbsolutePercentError(elapsed)'), flush=True)
