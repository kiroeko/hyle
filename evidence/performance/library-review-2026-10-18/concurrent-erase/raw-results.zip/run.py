from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
BUILD=ROOT/'.scratch/build-compute-v2-dev'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache=read_cache(BUILD);env=windows_compiler_environment(cache);env['VSLANG']='1033'
cl=cache['CMAKE_CXX_COMPILER'];link=str(Path(cl).with_name('link.exe'))
flags=['/nologo','/c','/DWIN32','/D_WINDOWS','/EHsc','/O2','/Ob2','/DNDEBUG',
 '/std:c++latest','/MD','/W4','/permissive-','/wd4324','/WX','/Zc:__cplusplus',
 '/utf-8','/Zc:preprocessor','/DHYLE_STATIC','/DNOMINMAX','/DWIN32_LEAN_AND_MEAN']
libs=[str(BUILD/'bin'/(name+'.lib')) for name in ['hyle_container','hyle_mem','hyle_platform','hyle_error','mimalloc_static']]
libs+=['bcrypt.lib','PowrProf.lib','advapi32.lib','Synchronization.lib']

def run(tag,command):
 record={'command':command,'cwd':str(BUILD)};start=time.time()
 p=subprocess.run(command,cwd=BUILD,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 record.update(exit=p.returncode,wall_seconds=time.time()-start)
 (OUT/(tag+'-command.json')).write_text(json.dumps(record,indent=2))
 (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
 print(tag,p.returncode,flush=True)
 if p.returncode:
  print(p.stdout.decode('utf-8',errors='replace'));print(p.stderr.decode('utf-8',errors='replace'));raise SystemExit(p.returncode)
 return p.stdout.decode('utf-8')

p=argparse.ArgumentParser();p.add_argument('action',choices=['build-baseline','build-candidate','tests','count','perf'])
p.add_argument('--tag',default='sample');p.add_argument('--variant',choices=['baseline','candidate'],default='candidate')
a=p.parse_args()
if a.action.startswith('build-'):
 tag=a.action.removeprefix('build-');inc=OUT/tag/'include';inc.mkdir(parents=True,exist_ok=True)
 if tag=='candidate':
  for file in ['include/hyle/container/concurrent_hash_map.h','include/hyle/container/detail/flat_hash_table.h']:
   dst=OUT/tag/file;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((ROOT/file).read_bytes())
 run(tag+'-compile',[cl,*flags,'/I'+str(inc),'/I'+str(ROOT/'include'),'/Fo'+str(OUT/(tag+'.obj')),str(OUT/'probe.cc')])
 run(tag+'-link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console','/out:'+str(OUT/(tag+'.exe')),str(OUT/(tag+'.obj')),*libs])
if a.action=='count':print(run(a.tag,[str(OUT/(a.variant+'.exe')),'count']))
if a.action=='perf':print(run(a.tag,[str(OUT/(a.variant+'.exe')),'perf']))
if a.action=='tests':
 test_objs=[]
 gtest=Path(os.environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
 for file in ['tests/container_concurrent/concurrent_hash_map_test.cc','tests/container/flat_hash_map_test.cc']:
  src=ROOT/file;obj=OUT/(src.stem+'.obj');test_objs.append(str(obj))
  run(src.stem+'-compile',[cl,*flags,'/I'+str(ROOT/'include'),'/external:I'+str(gtest),'/external:W0','/Fo'+str(obj),str(src)])
 run('tests-link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console','/out:'+str(OUT/'tests.exe'),*test_objs,*libs,str(BUILD/'lib/gtest_main.lib'),str(BUILD/'lib/gtest.lib')])
 print(run('tests',[str(OUT/'tests.exe'),'--gtest_filter=ConcurrentHashMap.*:ConcurrentFlatHashSet.*:FlatHashMap.*Erase*:FlatHashMap.*Tombstone*:FlatHashMap.HeterogeneousLookupAndEraseAvoidKeyConstruction:FlatHashMap.*Fallible*:FlatHashMap.ReserveReclaimsTombstonesForItsInsertionGuarantee:FlatHashMap.EraseMatchesOracleUnderMixedOps:FlatHashMap.OwnsMoveOnlyNonTrivialValuesAcrossRehashEraseAndClear']))
