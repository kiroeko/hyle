#include "hyle/container/concurrent_hash_map.h"
#include <windows.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <numeric>
#include <random>
#include <string>
#include <string_view>
#include <vector>

struct StableHash {
  std::uint64_t operator()(std::string_view key) const noexcept {
    return hyle::container::hash_bytes(key.data(), key.size(), UINT64_C(0x71236ab4));
  }
};
struct CountingHash {
  std::size_t *calls;
  std::uint64_t operator()(std::string_view key) const noexcept {
    ++*calls;
    return StableHash{}(key);
  }
};

int count() {
  std::size_t calls = 0;
  using Map = hyle::container::ConcurrentHashMap<std::string, int,
      CountingHash, hyle::container::StringEqual>;
  Map map(64, hyle::mem::SystemAllocator{}, CountingHash{&calls});
  const std::string key(512, 'x');
  Map::Accessor entry;
  if (!map.emplace(entry, key, 7)) return 2;
  entry.release();
  calls = 0;
  if (!map.erase(std::string_view(key))) return 3;
  const auto hit = calls;
  calls = 0;
  if (map.erase(std::string_view(key))) return 4;
  std::printf("{\"mode\":\"count\",\"hit_hash_calls\":%zu,\"miss_hash_calls\":%zu,"
      "\"key_bytes\":%zu,\"empty\":%s,\"counter_is_diagnostic_only\":true}\n",
      hit, calls, key.size(), map.empty() ? "true" : "false");
  return 0;
}

int main(int argc, char **argv) {
  if (argc == 1 || std::string_view(argv[1]) == "count") return count();
  if (!SetThreadAffinityMask(GetCurrentThread(), DWORD_PTR{1} << 4)) return 5;
  constexpr std::size_t entries = 8192, length = 512;
  std::vector<std::string> keys(entries, std::string(length, 'k'));
  std::vector<std::size_t> order(entries);
  std::iota(order.begin(), order.end(), 0);
  std::mt19937_64 random(0x1567);
  std::shuffle(order.begin(), order.end(), random);
  for (std::size_t i = 0; i < entries; ++i) {
    for (std::size_t j = 0; j < length; ++j)
      keys[i][j] = static_cast<char>('!' + (random() % 90));
    for (std::size_t byte = 0; byte < sizeof(i); ++byte)
      keys[i][byte] = static_cast<char>((i >> (byte * 8)) & 0xff);
  }
  using Map = hyle::container::ConcurrentHashMap<std::string, std::uint64_t,
      StableHash, hyle::container::StringEqual>;
  LARGE_INTEGER frequency;
  if (!QueryPerformanceFrequency(&frequency)) return 6;
  std::printf("{\"mode\":\"environment\",\"qpc_frequency\":%lld,\"cpu\":%lu,"
      "\"entries\":%zu,\"key_bytes\":%zu,\"shards\":64,\"warm_rounds\":4,"
      "\"samples\":31,\"hash_seed\":\"0x71236ab4\","
      "\"timed\":\"public erase(string_view), lookup/equality, value+owned key destruction/free and lock/unlock\","
      "\"excluded\":\"map construction,reserve,key generation+copy,insert,final size check and map destruction\"}\n",
      frequency.QuadPart, GetCurrentProcessorNumber(), entries, length);
  for (int sample = -4; sample < 31; ++sample) {
    Map map(64);
    map.reserve(entries);
    Map::Accessor value;
    for (std::size_t index = 0; index < entries; ++index) {
      if (!map.emplace(value, keys[index], static_cast<std::uint64_t>(index))) return 7;
      value.release();
    }
    if (map.size() != entries) return 8;
    LARGE_INTEGER begin, end;
    std::size_t erased = 0;
    QueryPerformanceCounter(&begin);
    for (const auto index : order)
      erased += map.erase(std::string_view(keys[index])) ? 1u : 0u;
    QueryPerformanceCounter(&end);
    if (erased != entries || !map.empty()) return 9;
    if (sample >= 0)
      std::printf("{\"mode\":\"sample\",\"index\":%d,\"qpc_ticks\":%lld,"
          "\"ns_per_erase\":%.9f,\"erased\":%zu,\"empty\":true}\n", sample,
          end.QuadPart - begin.QuadPart,
          double(end.QuadPart - begin.QuadPart) * 1e9 / double(frequency.QuadPart) / entries,
          erased);
  }
}
