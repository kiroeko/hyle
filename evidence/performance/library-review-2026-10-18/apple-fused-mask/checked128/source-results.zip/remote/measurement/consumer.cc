#include "hyle/compute/apple.h"

#include <mlx/memory.h>
#include <mlx/ops.h>
#include <mlx/transforms.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace {
namespace c = hyle::compute;
namespace a = c::apple;
namespace mx = mlx::core;

constexpr int kQueries = 1025, kKeys = 8193, kHeads = 8, kKvHeads = 2;
constexpr int kDepth = 64, kTimedSamples = 9;
constexpr std::size_t kOutputElements =
    std::size_t{kQueries} * kHeads * kDepth;
constexpr std::size_t kOutputBytes = kOutputElements * sizeof(float);
constexpr std::size_t kScoreBytes =
    std::size_t{kHeads} * kQueries * kKeys * sizeof(float);
constexpr std::size_t kCallerPortBytes =
    kOutputBytes + 2 * std::size_t{kKeys} * kKvHeads * kDepth * sizeof(float) +
    std::size_t{kQueries} * kKeys;
constexpr std::size_t kCallerBackingBytes =
    kCallerPortBytes - std::size_t{kQueries} * kKeys + kQueries;
constexpr std::size_t kExpandedMaskBytes = std::size_t{kHeads} * kQueries * kKeys;
static_assert(kOutputElements == 524800 && kOutputBytes == 2099200);
static_assert(kCallerPortBytes == 18886657 && kCallerBackingBytes == 10489857);
static_assert(kScoreBytes == 268730400 && kExpandedMaskBytes == 67182600);

std::array<std::int64_t, kTimedSamples> samples{};
int completed_samples = 0;

mx::Stream stream() { return mx::default_stream(mx::Device::gpu); }

[[noreturn]] void fail(const hyle::Status &status) {
  throw std::runtime_error(std::string(status.message()));
}

void check_status(const hyle::Status &status) {
  if (!status.ok())
    fail(status);
}

// The public native route requires ready input owners. Input evaluation and
// all construction take place before prepare/bind and before measurement.
mx::array ready(mx::array input) {
  mx::async_eval({input});
  mx::synchronize(stream());
  input.wait();
  return input;
}

std::array<mx::array, 4> make_inputs() {
  std::vector<float> q(kOutputElements);
  std::vector<float> k(std::size_t{kKeys} * kKvHeads * kDepth);
  std::vector<float> v(k.size());
  std::vector<std::uint8_t> mask(kQueries, 1);
  for (int s = 0; s < kKeys; ++s)
    std::fill_n(v.begin() + static_cast<std::size_t>(s) * kKvHeads * kDepth,
                kKvHeads * kDepth, s % 2 == 0 ? 1.25F : -1.25F);
  return {
      ready(mx::array(q.data(), {1, kQueries, kHeads, kDepth}, mx::float32)),
      ready(mx::array(k.data(), {1, kKeys, kKvHeads, kDepth}, mx::float32)),
      ready(mx::array(v.data(), {1, kKeys, kKvHeads, kDepth}, mx::float32)),
      ready(mx::broadcast_to(mx::astype(
          mx::array(mask.data(), {1, 1, kQueries, 1}, mx::uint8),
          mx::bool_, stream()), {1, 1, kQueries, kKeys}, stream()))};
}

struct Oracle {
  double max_abs_error = 0;
  double max_error_over_budget = 0;
  std::size_t checked_elements = 0;
  bool passed = true;
};

Oracle check_output(const mx::array &output) {
  if (output.dtype() != mx::float32 ||
      output.shape() != mx::Shape{1, kQueries, kHeads, kDepth})
    throw std::runtime_error("ordinary attention output shape/dtype mismatch");
  Oracle checked;
  const float *data = output.data<float>();
  for (int t = 0; t < kQueries; ++t) {
    // Zero QK and an all-true Boolean mask give a uniform distribution.
    // Alternating exactly representable V has one extra positive key.
    const double expected = 1.25 / double(kKeys);
    const double budget = 2e-6 + 6e-6 * std::abs(expected);
    for (int h = 0; h < kHeads; ++h)
      for (int d = 0; d < kDepth; ++d) {
        const auto offset = static_cast<std::size_t>(t) * output.strides(1) +
            static_cast<std::size_t>(h) * output.strides(2) +
            static_cast<std::size_t>(d) * output.strides(3);
        const double actual = data[offset];
        const double error = std::abs(actual - expected);
        checked.passed &= std::isfinite(actual) && error <= budget;
        if (std::isfinite(error)) {
          checked.max_abs_error = std::max(checked.max_abs_error, error);
          checked.max_error_over_budget =
              std::max(checked.max_error_over_budget, error / budget);
        }
        ++checked.checked_elements;
      }
  }
  return checked;
}

void print_prefix(std::string_view mode) {
  std::cout << std::setprecision(17)
      << "{\"mode\":\"" << mode
      << "\",\"dtype\":\"F32\",\"accumulation\":\"F32\","
         "\"layout\":\"BSHD\",\"B\":1,\"H\":8,\"Hkv\":2,"
         "\"D\":64,\"Q\":1025,\"KV\":8193,\"causal\":false,"
         "\"scale\":0.0625,\"mask\":\"Bool per-query KVstride0 view\","
         "\"input\":\"QK0,V alternating +1.25/-1.25, all-true explicit mask\","
         "\"caller_port_requested_bytes\":" << kCallerPortBytes
      << ",\"caller_backing_requested_bytes\":" << kCallerBackingBytes
      << ",\"caller_mask_logical_bytes\":" << std::size_t{kQueries} * kKeys
      << ",\"caller_mask_backing_requested_bytes\":" << kQueries
      << ",\"native_expanded_Bool_mask_bytes\":" << kExpandedMaskBytes
      << ",\"output_requested_bytes\":" << kOutputBytes
      << ",\"theoretical_one_full_F32_score_bytes\":" << kScoreBytes;
}

bool run_space(a::Invocation &slot) {
  // This is one process, one cold submission; do not clear between chunks.
  mx::clear_cache();
  const auto active_before = mx::get_active_memory();
  const auto cache_before = mx::get_cache_memory();
  mx::reset_peak_memory();
  auto accepted = slot.submit();
  if (!accepted)
    fail(accepted.error());
  auto result = accepted->wait();
  if (!result)
    fail(result.error());
  mx::synchronize(stream());
  const auto active_after = mx::get_active_memory();
  const auto peak = mx::get_peak_memory();
  const auto cache_after = mx::get_cache_memory();
  if (peak < active_before)
    throw std::runtime_error("MLX peak below the reset live baseline");
  const auto checked = check_output(result->get()->arrays()[0]);
  print_prefix("space");
  std::cout << ",\"active_before\":" << active_before
      << ",\"cache_before\":" << cache_before
      << ",\"active_after_with_output_lease\":" << active_after
      << ",\"peak\":" << peak
      << ",\"peak_minus_active_before\":" << peak - active_before
      << ",\"cache_after\":" << cache_after
      << ",\"max_abs_error\":" << checked.max_abs_error
      << ",\"max_error_over_original_budget\":" << checked.max_error_over_budget
      << ",\"checked_elements\":" << checked.checked_elements
      << ",\"oracle_passed\":" << (checked.passed ? "true" : "false")
      << "}\n";
  return checked.passed;
}

Oracle invoke(a::Invocation &slot, bool timed, bool oracle) {
  const auto begin = std::chrono::steady_clock::now();
  auto accepted = slot.submit();
  if (!accepted)
    fail(accepted.error());
  auto result = accepted->wait();
  const auto end = std::chrono::steady_clock::now();
  if (!result)
    fail(result.error());
  if (timed)
    samples[completed_samples++] =
        std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count();
  // Both native result owners and their lease retire before the next submit.
  // Full output validation is deliberately outside the timed interval.
  return oracle ? check_output(result->get()->arrays()[0]) : Oracle{};
}

void print_samples() {
  std::cout << '[';
  for (int i = 0; i < completed_samples; ++i) {
    if (i != 0)
      std::cout << ',';
    std::cout << samples[i];
  }
  std::cout << ']';
}

bool run_latency(a::Invocation &slot) {
  // Match the earlier Q128 latency consumer: 2 warm, an untimed full oracle,
  // 9 submit+checked-wait samples, then another untimed full oracle.
  invoke(slot, false, false);
  invoke(slot, false, false);
  const auto before = invoke(slot, false, true);
  if (!before.passed) {
    print_prefix("latency");
    std::cout << ",\"failed\":true,\"failure_stage\":\"before_oracle\","
                 "\"max_abs_error\":" << before.max_abs_error
        << ",\"checked_elements\":" << before.checked_elements
        << ",\"completed_timed_samples_ns\":[]}\n";
    return false;
  }
  for (int i = 0; i < kTimedSamples; ++i)
    invoke(slot, true, false);
  const auto after = invoke(slot, false, true);
  print_prefix("latency");
  std::cout << ",\"warm_invocations\":2,\"untimed_oracle_invocations\":2,"
               "\"oracle_elements_each\":" << kOutputElements
      << ",\"oracle_before_maxabs\":" << before.max_abs_error
      << ",\"oracle_after_maxabs\":" << after.max_abs_error
      << ",\"oracle_after_max_error_over_original_budget\":"
      << after.max_error_over_budget
      << ",\"oracle_passed\":" << (after.passed ? "true" : "false")
      << ",\"timed_submit_checkedwait_ns\":";
  print_samples();
  std::cout << "}\n";
  return after.passed;
}
} // namespace

int main(int argc, char **argv) {
  if (argc != 2 || (std::string_view(argv[1]) != "--space" &&
                     std::string_view(argv[1]) != "--latency")) {
    std::cerr << "Usage: consumer --space|--latency (fixed shape/input only)\n";
    return 2;
  }
  try {
    const auto inputs = make_inputs();
    std::size_t caller_bytes = 0;
    for (const auto &input : inputs)
      caller_bytes += input.nbytes();
    if (caller_bytes != kCallerPortBytes)
      throw std::runtime_error("caller logical port byte count mismatch");
    if (inputs[3].dtype() != mx::bool_ || inputs[3].strides(-1) != 0 ||
        inputs[3].data_size() != std::size_t{kQueries})
      throw std::runtime_error("fixed mask must retain compact backing and zero KV stride");
    auto created = a::Context::create();
    if (!created)
      fail(created.error());
    auto context = std::move(*created);
    const c::Operation operation(c::ScaledDotProductAttention{
        .layout = c::AttentionLayout::kBatchSequenceHeadDepth,
        .mask = c::MaskKind::kBoolean,
        .scale = 0.0625F,
        .causal = false,
        .accumulation_type = c::DataType::kFloat32});
    auto prepared = context.prepare(operation, inputs);
    if (!prepared)
      fail(prepared.error());
    auto program = std::move(*prepared);
    auto made = program.create_invocation();
    if (!made)
      fail(made.error());
    auto slot = std::move(*made);
    check_status(slot.bind(inputs));
    const bool passed = std::string_view(argv[1]) == "--space"
        ? run_space(slot) : run_latency(slot);
    check_status(context.close());
    return passed ? 0 : 3;
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    std::cout << "{\"failed\":true,\"completed_timed_samples_ns\":";
    print_samples();
    std::cout << "}\n";
    return 4;
  }
}
