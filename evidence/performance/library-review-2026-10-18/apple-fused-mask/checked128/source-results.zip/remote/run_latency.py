from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess

ROOT = Path(__file__).resolve().parent
expected = json.loads((ROOT / 'built-identities.json').read_text())
for arm in ['baseline', 'candidate']:
    item = next(i for i in expected if i['path'].endswith('/' + arm + '-space'))
    p = Path(item['path'])
    assert p.stat().st_size == item['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']
results = []
for number, arm in enumerate(['baseline', 'candidate', 'candidate', 'baseline']):
    tag = 'latency-' + str(number) + '-' + arm
    command = [str(ROOT / (arm + '-space')), '--latency']
    assert not (ROOT / (tag + '-command.json')).exists(), 'No repeated process'
    result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=300)
    (ROOT / (tag + '-command.json')).write_text(json.dumps(dict(
        argv=command, cwd=str(ROOT), exit=result.returncode,
        environment={k:v for k,v in os.environ.items() if k.startswith(('MLX_', 'MTL_', 'METAL_', 'HYLE_'))}), indent=2) + '\n')
    (ROOT / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (ROOT / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace'), flush=True)
        print(result.stderr.decode(errors='replace'), flush=True)
        raise RuntimeError('Stopped at failed process')
    rows = [json.loads(line) for line in result.stdout.decode().splitlines() if line.startswith('{')]
    assert len(rows) == 1
    row = rows[0]
    assert row['oracle_passed'] and row['warm_invocations'] == 2 and row['untimed_oracle_invocations'] == 2
    assert row['oracle_elements_each'] == 524800
    samples = row['timed_submit_checkedwait_ns']
    assert len(samples) == 9 and all(v > 0 for v in samples)
    results.append(dict(process=number, arm=arm, raw=row,
                        minimum_ns=min(samples), median_ns=statistics.median(samples), maximum_ns=max(samples)))
    (ROOT / 'latency-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps([dict(process=r['process'], arm=r['arm'], median_ns=r['median_ns'],
                       range_ns=[r['minimum_ns'], r['maximum_ns']]) for r in results]), flush=True)
