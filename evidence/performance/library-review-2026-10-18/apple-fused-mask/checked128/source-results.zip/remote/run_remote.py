from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
sys.path.insert(0, str(BASE))
# Same already-successful cache/flags/link closure; this directory owns only
# fresh test/consumer TUs. The failed FP64 diagnostic's physical files stay.
import run_remote as shared

FLAGS = shared.FLAGS
INCLUDES = ['-I' + str(ROOT / 'tests/compute_route_apple'), *shared.INCLUDES]
PATTERN = ('AppleAttention.FusedMasksRetainNativeValuesAcrossStridesAndRebinding:'
           'AppleGraph.PublishedFusedMaskNativeResultsRetainOwnersAndRebinding')


def save(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2) + '\n')


def run(tag, argv):
    assert not (ROOT / (tag + '-command.json')).exists(), 'No repeated attempts'
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=300)
    save(tag + '-command.json', dict(argv=argv, cwd=str(ROOT), exit=result.returncode))
    (ROOT / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (ROOT / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:], flush=True)
        print(result.stderr.decode(errors='replace')[-6000:], flush=True)
        raise RuntimeError('Stopped: ' + tag)


expected = json.loads((BASE / 'expected-inputs.json').read_text())
built = json.loads((BASE / 'built-identities.json').read_text())
staged = json.loads((ROOT / 'staged-identities.json').read_text())
for item in staged:
    p = ROOT / item['path']
    assert p.stat().st_size == item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']
baseline = [Path(p) for p in expected['baseline_objects']]
candidate = [BASE / 'context.o', BASE / 'operations.o', baseline[2], baseline[3]]
sink = Path(expected['sink_direct_object'])
for p in set(baseline + candidate + [sink]):
    previous = next(i for i in expected['retained_objects'] + built if i['path'] == str(p))
    assert shared.record(p) == previous
(ROOT / 'tests/compute_provider_native').symlink_to(BASE / 'tests/compute_provider_native', target_is_directory=True)
(ROOT / 'mlx.metallib').symlink_to((BASE / 'mlx.metallib').resolve())
tests = [ROOT / 'attention-tests.o', ROOT / 'graph-tests.o']
gtest = [shared.CORE / 'lib/libgtest_main.a', shared.CORE / 'lib/libgtest.a']
save('runtime-identities.json', dict(staged_sources=staged,
     baseline_objects=[shared.record(p) for p in baseline],
     candidate_objects=[shared.record(p) for p in candidate],sink=shared.record(sink),
     reused_SDK_libraries=[shared.record(p) for p in shared.LIBS],
     fresh_product_TUs=0,fresh_test_TUs=2,consumer_TU_only_after_two_filters_pass=True,
     old_failed_diagnostic_include_closure_untouched=True,latency_authorized_or_run=False))
artifacts = []
gate = dict(filter=PATTERN,runs=[])
try:
    for tag, src, obj in [
        ('compile-attention','tests/compute_route_apple/attention_test.cc',tests[0]),
        ('compile-graph','tests/graph_route_apple/tensor_test.cc',tests[1])]:
        run(tag,['/usr/bin/clang++',*FLAGS,*INCLUDES,'-c',ROOT/src,'-o',obj])
        artifacts.append(obj)
    for arm, host in [('baseline',baseline),('candidate',candidate)]:
        exe=ROOT/(arm+'-tests')
        run('link-'+arm+'-tests',['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64',
            '-o',exe,*tests,sink,*host,*shared.LIBS,*gtest,*shared.FRAMEWORKS,
            '-Wl,-map,'+str(exe)+'.map'])
        artifacts.append(exe)
        mapping=Path(str(exe)+'.map').read_text()
        assert all(str(p) in mapping for p in tests+[sink]+host)
    for arm in ['baseline','candidate']:
        run('run-'+arm+'-tests',[ROOT/(arm+'-tests'),'--gtest_filter='+PATTERN,
            '--gtest_throw_on_failure','--gtest_fail_fast',
            '--gtest_output=json:'+str(ROOT/(arm+'-tests.json'))])
        result=json.loads((ROOT/(arm+'-tests.json')).read_text())
        assert result['tests']==2 and result['failures']==result['errors']==0
        gate['runs'].append(dict(arm=arm,tests=2,failures=0,time=result['time']))
        save('functional-gate.json',gate)
    gate['status']='two_native_equivalence_tests_passed_both_arms'
    save('functional-gate.json',gate)
    source=ROOT/'measurement/consumer.cc'
    assert hashlib.sha256(source.read_bytes()).hexdigest()=='4280b2f6737395c8b4cf653a23e2b7fa3664416c580e573105e97bc0b95e9c07'
    obj=ROOT/'consumer.o'
    run('compile-consumer',['/usr/bin/clang++',*FLAGS,*INCLUDES,'-c',source,'-o',obj])
    artifacts.append(obj)
    spaces={}
    for arm,host in [('baseline',baseline),('candidate',candidate)]:
        exe=ROOT/(arm+'-space')
        run('link-'+arm+'-space',['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64',
            '-o',exe,obj,*host,*shared.LIBS,*shared.FRAMEWORKS,'-Wl,-map,'+str(exe)+'.map'])
        artifacts.append(exe)
        run('run-'+arm+'-space',[exe,'--space'])
        rows=[json.loads(s) for s in (ROOT/('run-'+arm+'-space.stdout.txt')).read_text().splitlines() if s.startswith('{')]
        assert len(rows)==1 and rows[0]['oracle_passed'] and rows[0]['checked_elements']==524800
        spaces[arm]=rows[0]
        save('space-results.json',spaces)
    save('built-identities.json',[shared.record(p) for p in artifacts])
finally:
    files=[shared.record(ROOT/name) for name in ['attention-tests.o','graph-tests.o',
        'baseline-tests','candidate-tests','consumer.o','baseline-space','candidate-space'] if (ROOT/name).is_file()]
    save('cleanup-candidates.json',dict(files=files,total_bytes=sum(i['bytes'] for i in files),
         performed_cleanup=False,preserve='all previous FP64 failure/diagnostic source and raw, caches/native/SDK, source/maps/log/results'))
