from pathlib import Path
import base64
import hashlib
import json
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests'
HOST='kiro@172.22.10.198'


def run(tag,argv,timeout=120):
    assert not (HERE/(tag+'-command.json')).exists()
    argv=list(map(str,argv));result=subprocess.run(argv,capture_output=True,timeout=timeout)
    (HERE/(tag+'-command.json')).write_text(json.dumps(dict(argv=argv,exit=result.returncode),indent=2)+'\n')
    (HERE/(tag+'.stdout.txt')).write_bytes(result.stdout);(HERE/(tag+'.stderr.txt')).write_bytes(result.stderr)
    print(tag,result.returncode,result.stdout.decode(errors='replace')[-7000:],result.stderr.decode(errors='replace')[-4000:],flush=True)
    if result.returncode:raise RuntimeError('Stopped: '+tag)


def ssh_python(tag,code):
    payload=base64.b64encode(code.encode()).decode()
    run(tag,['ssh',HOST,'python3 -c \'import base64;exec(base64.b64decode("'+payload+'"))\''])


identity=json.loads((HERE/'source-identity.json').read_text())
sources=[(HERE/'source'/i['path'],i['path']) for i in identity['sources']]
sources.append((ROOT/'tests/compute_route_apple/sink_attention_test_support.h','tests/compute_route_apple/sink_attention_test_support.h'))
sources.append((HERE.parent/'measurement/consumer.cc','measurement/consumer.cc'))
for item in identity['sources']:
    assert hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()==item['sha256']
records=[dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p,name in sources]
(HERE/'staged-identities.json').write_text(json.dumps(records,indent=2)+'\n')
with tarfile.open(HERE/'sources.tar.gz','w:gz') as tar:
    for p,name in sources:tar.add(p,arcname=name)
    for name in ['run_remote.py','source-identity.json','staged-identities.json']:tar.add(HERE/name,arcname=name)
ssh_python('create-remote','from pathlib import Path;Path('+repr(REMOTE)+').mkdir(exist_ok=False)')
run('stage-sources',['scp',HERE/'sources.tar.gz',HOST+':'+REMOTE+'/sources.tar.gz'])
ssh_python('extract-sources','''from pathlib import Path
import tarfile
root=Path('''+repr(REMOTE)+''')
with tarfile.open(root/'sources.tar.gz','r:gz') as tar:
    for m in tar.getmembers():
        assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        p=root/m.name;assert not p.exists() and p.resolve().is_relative_to(root)
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read())
print('Only new3testsource/Sinkhelper/fixedconsumer/driver staged; originalfailed/diagnostic closure untouched')
''')
run('execute-remote',['ssh',HOST,'python3 '+REMOTE+'/run_remote.py'],timeout=700)
