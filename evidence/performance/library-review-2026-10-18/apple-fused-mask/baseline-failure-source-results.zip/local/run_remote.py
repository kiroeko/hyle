from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'library-review-20261018-apple-ordinary-short-q'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CORE = Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
GTEST = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
FLAGS = ['-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64', '-DHYLE_STATIC',
         '-DMLX_STATIC', '-DHYLE_COMPUTE_APPLE=1', '-DHYLE_COMPUTE_ROUTE_APPLE_API=',
         '-DHYLE_GRAPH_ROUTE_APPLE_API=', '-Wall', '-Wextra', '-Wpedantic', '-Werror']
INCLUDES = ['-I' + str(ROOT / 'src/compute_route_apple'),
            '-I' + str(OLD / 'candidate/include'), '-I' + str(OLD / 'common/include'),
            '-I' + str(OLD / 'candidate/src/compute_route_apple'),
            '-I' + str(OLD / 'common/src/compute_route_apple'),
            '-I' + str(OLD / 'common/src/compute'),
            '-I' + str(OLD / 'common/src/graph_route_apple'),
            '-I' + str(ROOT / 'tests/compute_route_apple'), '-I' + str(OLD / 'common'),
            '-isystem', str(SDK / 'include'), '-isystem', str(SDK / 'include/metal_cpp'),
            '-isystem', str(GTEST)]
LIBS = [SDK / 'lib' / ('lib' + name + '.a') for name in [
    'hyle_graph', 'hyle_compute_route_apple', 'hyle_compute_stream',
    'hyle_compute_state', 'hyle_compute_batch', 'hyle_compute', 'hyle_compute_ops',
    'hyle_simd', 'hyle_sched', 'hyle_container', 'hyle_mem_vm', 'hyle_mem',
    'mimalloc_static', 'hyle_platform_thread', 'hyle_time', 'hyle_platform',
    'hyle_error', 'hyle_compute_provider_ggml_metal', 'hyle_compute_ggml_runtime',
    'ggml', 'ggml-metal', 'ggml-base', 'mlx']]
FRAMEWORKS = ['-framework', 'Foundation', '-framework', 'Metal',
              '-framework', 'MetalKit', '-framework', 'QuartzCore']
PATTERN = ':'.join([
    'AppleAttention.CenteredShortQueryMathKeepsMasksTailAndReboundOwners',
    'AppleGraph.PublishedCenteredShortQueryMathAndNegativeCrossCheckedBoundary',
    'AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners',
    'AppleSinkAttention.ShortQueriesRetainExistingFallback',
    'AppleSinkGraph.PublishedCopySinkAndNegativeCrossPrivateBoundary',
    'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners',
    'AppleAttention.FusedMasksKeepStridesDtypesTailAndReboundOwners',
    'AppleGraph.PublishedFusedMaskRebindingAndNegativeKeepOwners'])


def record(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def run(tag, argv):
    assert not (ROOT / (tag + '-command.json')).exists(), 'No overwritten attempts'
    argv = list(map(str, argv))
    try:
        result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=300)
        code, out, err = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code, out, err = -999, error.stdout or b'', error.stderr or b''
    save(tag + '-command.json', dict(argv=argv, cwd=str(ROOT), exit=code))
    (ROOT / (tag + '.stdout.txt')).write_bytes(out)
    (ROOT / (tag + '.stderr.txt')).write_bytes(err)
    print(tag, code, flush=True)
    if code:
        print(out.decode(errors='replace')[-6000:], flush=True)
        print(err.decode(errors='replace')[-6000:], flush=True)
        raise RuntimeError('Stopped at failed command: ' + tag)


def main():
    assert not (ROOT / 'runtime-identities.json').exists(), 'Already started'
    expected = json.loads((ROOT / 'expected-inputs.json').read_text())
    for item in expected['retained_objects']:
        assert record(item['path']) == item, item
    for item in expected['staged_sources']:
        actual = record(ROOT / item['path'])
        assert (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256']), item
    model = subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip()
    assert model == 'Mac16,12', model
    run('hardware', ['/usr/sbin/sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'])
    run('compiler', ['/usr/bin/clang++', '--version'])
    run('toolchain', ['/usr/bin/xcrun', '--show-sdk-path'])
    (ROOT / 'tests/compute_provider_native').symlink_to(
        OLD / 'common/tests/compute_provider_native', target_is_directory=True)
    (ROOT / 'mlx.metallib').symlink_to(SDK / 'lib/mlx.metallib')
    baseline = [Path(p) for p in expected['baseline_objects']]
    candidate = [ROOT / 'context.o', ROOT / 'operations.o', baseline[2], baseline[3]]
    sink = Path(expected['sink_direct_object'])
    tests = [ROOT / 'attention-tests.o', ROOT / 'graph-tests.o']
    gtest = [CORE / 'lib/libgtest_main.a', CORE / 'lib/libgtest.a']
    save('runtime-identities.json', dict(
        model=model, disk_free_bytes=shutil.disk_usage(ROOT).free,
        retained_objects=expected['retained_objects'], staged_sources=expected['staged_sources'],
        libraries=[record(p) for p in LIBS + gtest],
        half_helper=record(ROOT / 'tests/compute_provider_native/half_test_support.h'),
        metallib=dict(path=str(ROOT / 'mlx.metallib'), target=str((ROOT / 'mlx.metallib').resolve())),
        environment={k:v for k,v in os.environ.items() if k.startswith(('MLX_', 'MTL_', 'METAL_', 'HYLE_'))},
        baseline_objects=list(map(str, baseline)), candidate_objects=list(map(str, candidate)),
        fresh_product_TUs=2, fresh_test_TUs=2, native_SDK_rebuild_or_copy=False,
        latency_authorized_or_run=False))
    gate = dict(filter=PATTERN, expected_tests=8, runs=[], status='started')
    artifacts = []
    try:
        for tag, source, obj in [
            ('compile-context', 'src/compute_route_apple/apple_context.cc', candidate[0]),
            ('compile-operations', 'src/compute_route_apple/apple_operations.cc', candidate[1]),
            ('compile-attention-tests', 'tests/compute_route_apple/attention_test.cc', tests[0]),
            ('compile-graph-tests', 'tests/graph_route_apple/tensor_test.cc', tests[1])]:
            run(tag, ['/usr/bin/clang++', *FLAGS, *INCLUDES, '-c', ROOT / source, '-o', obj])
            artifacts.append(obj)
        for arm, host in [('baseline', baseline), ('candidate', candidate)]:
            exe = ROOT / (arm + '-tests')
            run('link-' + arm + '-tests', ['/usr/bin/clang++', '-O3', '-std=c++23',
                '-arch', 'arm64', '-o', exe, *tests, sink, *host, *LIBS, *gtest,
                *FRAMEWORKS, '-Wl,-map,' + str(exe) + '.map'])
            artifacts.append(exe)
            mapping = Path(str(exe) + '.map').read_text()
            assert all(str(p) in mapping for p in host + tests + [sink])
        save('built-identities.json', [record(p) for p in artifacts])
        for arm in ['baseline', 'candidate']:
            run('run-' + arm + '-tests', [ROOT / (arm + '-tests'),
                '--gtest_filter=' + PATTERN, '--gtest_throw_on_failure', '--gtest_fail_fast',
                '--gtest_output=json:' + str(ROOT / (arm + '-tests.json'))])
            result = json.loads((ROOT / (arm + '-tests.json')).read_text())
            assert result['tests'] == 8 and result['failures'] == result['errors'] == 0, result
            gate['runs'].append(dict(arm=arm, tests=8, failures=0, time=result['time']))
            save('functional-gate.json', gate)
        gate['status'] = 'both_eight_test_filters_passed'
        save('functional-gate.json', gate)
        obj = ROOT / 'consumer.o'
        run('compile-consumer', ['/usr/bin/clang++', *FLAGS, *INCLUDES, '-c',
            ROOT / 'measurement/consumer.cc', '-o', obj])
        artifacts.append(obj)
        spaces = {}
        for arm, host in [('baseline', baseline), ('candidate', candidate)]:
            exe = ROOT / (arm + '-space')
            run('link-' + arm + '-space', ['/usr/bin/clang++', '-O3', '-std=c++23',
                '-arch', 'arm64', '-o', exe, obj, *host, *LIBS, *FRAMEWORKS,
                '-Wl,-map,' + str(exe) + '.map'])
            artifacts.append(exe)
            run('run-' + arm + '-space', [exe, '--space'])
            rows = [json.loads(line) for line in (ROOT / ('run-' + arm + '-space.stdout.txt')).read_text().splitlines() if line.startswith('{')]
            assert len(rows) == 1, rows
            spaces[arm] = rows[0]
            save('space-results.json', spaces)
        save('built-identities.json', [record(p) for p in artifacts])
    finally:
        present = [record(ROOT / name) for name in [
            'context.o', 'operations.o', 'attention-tests.o', 'graph-tests.o',
            'baseline-tests', 'candidate-tests', 'consumer.o', 'baseline-space', 'candidate-space']
            if (ROOT / name).is_file()]
        save('cleanup-candidates.json', dict(host='kiro@172.22.10.198', files=present,
            total_bytes=sum(p['bytes'] for p in present), performed_cleanup=False,
            preserve='all prior SDK/cache/native objects, all source/log/maps/data/archives'))


if __name__ == '__main__':
    main()
