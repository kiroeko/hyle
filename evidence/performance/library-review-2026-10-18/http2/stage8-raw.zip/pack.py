"""Pack fixed two-process results without rerunning or deleting anything."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile

HERE = Path(__file__).resolve().parent
ALIGNED = HERE.parent/'raw-fiber-aligned'
OLD = HERE.parent/'raw-fiber'


def identity(path):
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def save(name,value):
    (HERE/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


results=[]
for order in ('ab','ba'):
    document=json.loads((HERE/('epochs-'+order+'.json')).read_text())
    rows=[]
    for row in document['results']:
        assert row['epochs']==9 and len(row['measurements'])==9
        assert row['minEpochTime']>=0.01 and row['minEpochIterations']>=5 and row['batch']==4
        assert all(epoch['iterations']>=5 for epoch in row['measurements'])
        elapsed=[epoch['elapsed'] for epoch in row['measurements']]
        rows.append(dict(name=row['name'],median_ns_per_stream=row['median(elapsed)']*1e9/4,
                         median_absolute_percent_error=row['medianAbsolutePercentError(elapsed)'],
                         all_epoch_ns_per_stream=[value*1e9/4 for value in elapsed],
                         all_epoch_iterations=[epoch['iterations'] for epoch in row['measurements']],
                         all_epoch_durations_seconds=[epoch['elapsed']*epoch['iterations'] for epoch in row['measurements']]))
    hyle=next(row for row in rows if row['name'].startswith('Hyle'))
    raw=next(row for row in rows if row['name'].startswith('aligned'))
    results.append(dict(order=order,rows=rows,raw_over_hyle_median=raw['median_ns_per_stream']/hyle['median_ns_per_stream']))
commands=json.loads((HERE/'commands.json').read_text())
assert [entry['name'] for entry in commands if entry['name'].startswith('measure-')]==['measure-ab','measure-ba']
assert all(entry['exit']==0 for entry in commands)
previous={item['path']:item for item in json.loads((ALIGNED/'identity.json').read_text())['files']}
current=json.loads((HERE/'build-identity.json').read_text())['files']
matched=[]
for item in current:
    if '/raw-fiber-plain/' in item['path']:
        continue
    assert item['path'] in previous and item['sha256']==previous[item['path']]['sha256'] and item['bytes']==previous[item['path']]['bytes'],item['path']
    matched.append(item)
save('cached-closure-match.json',dict(all_same_as_aligned_stage6_cache=True,files=matched,
                                   timer_fix_not_rebuilt_into_cached_scheduler=True))
summary=dict(
    result='Fixed two uninstrumented AB/BA processes completed successfully. Hyle public and aligned direct-nghttp2 both use the same single-worker two-fiber episode model. Point medians are close in these samples; no equivalence or pure scheduler-cost claim.',
    scope=dict(processes=2,orders=['Hyle then raw','raw then Hyle'],epochs_per_arm=9,configured_min_epoch_time_seconds=0.01,min_complete_episodes_per_epoch=5,
               payload='4streams,256KiB request and response each, reverse pair completion',
               all_epochs_retained=True,filtering=False,additional_trials=False,formal_manual_peer_changed=False),
    results=results,
    measured_boundary='Each call starts on the external caller: new socketpair/adopt, immutable workload references, session endpoints, ordinary spawn_task on the same persistent1worker Scheduler/IoContext, all request/response bytes with16KiB consume+both flow-control windows, reverse completion, final client-consumed Event, both joins, session/socket close, and remaining per-episode owner cleanup before return.',
    differences_kept_visible=['Raw Episode zero-initializes two RawWire objects (128KiB per endpoint) inside every measured call, outside64KiB fiber stacks; raw allocation/container/codec/lifecycle work is still its own.',
                              'Raw direct-nghttp2 and Hyle public sessions differ in headers/body/session storage and host responsibilities. Matching execution model and aggregate counters does not isolate scheduler cost.',
                              'HyleHarness and an inactive persistent RawHarness thread are constructed for the lifetime of each process, identically for both measured arms. Construction/destruction is outside timed episodes.'],
    functional_checks='Each process performs one untimed warmup per arm in its selected order using the exact timed workload and full original header/body/reversal oracle; raw warmup additionally checks both descriptorEBADF after joins. Timed calls retain full protocol validation/status/cleanup but omit extra fd observation. Both warmup stderr lines hyle4/raw4/raw_fds_closed=true and all timed calls succeeded.',
    instrumentation_removed='No raw_probe/owner/phase/dispatch/syscall counters, no resume interposition, no probe object, no dynamic-export or dl link flag; readelf verifies no own Fiber::resume definition or raw_probe symbols. Nanobench performance counters disabled; only normal epoch wall timing remains.',
    build='One fresh GCC14 Release/O3 C++23 TU and link using identical retained stage6 cached HTTP/nghttp2/nanobench/foundation closure. No SDK copy/download/configure/foundation rebuild. New TimerQueue implementation not rebuilt into this scheduler.',
    limitations=['Only two process samples, nine epochs each arm; retain all epoch variation. No CI/equivalence claim, no repeat to chase a result.',
                 'Nanobench minEpochTime is configured10ms; calibrated actual epoch durations include a few below10ms (minimum9.478522ms). All raw durations retained; no replacement or rerun.',
                 'This is a diagnostic same-execution-model total-episode comparison, not a replacement for the formal manual-loop peer. Its previously recorded large-body loss remains separate and is not declared solved.',
                 'No new hot IO/dispatch counters during timing; use the preceding separate aligned diagnostic solely to establish driver work/semantic boundaries, not for time subtraction.',
                 'Explicit-default Event aggregate warning retained in compiler stderr; no compile/link/warmup/runtime failure.'],
    prior_aligned_diagnostic=dict(path=str(ALIGNED/'source-results.zip'),**identity(ALIGNED/'source-results.zip')))
save('summary.json',summary)
cleanup=json.loads((HERE/'cleanup-candidates.json').read_text());cleanup['total_bytes']=sum(item['bytes'] for item in cleanup['files']);save('cleanup-candidates.json',cleanup)
files={path.name:path for path in HERE.iterdir() if path.is_file() and path.suffix in ('.cc','.h','.py','.json','.patch','.diff','.txt') and path.name not in ('archive-record.json','symbols.stdout.txt')}
for name in ('main.cc','diag_bench.cc','split_advance.h','summary.json','before-identity.json'):
    files['aligned-reference/'+name]=ALIGNED/name
files['frozen-stage6/formal-input.cc']=OLD/'formal-input.cc'
archive=HERE/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()):
        z.write(path,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    count=len(z.infolist())
record=dict(path=str(archive),**identity(archive),members=count,cleanup_files=len(cleanup['files']),cleanup_bytes=cleanup['total_bytes'])
save('archive-record.json',record)
print(json.dumps(dict(archive=record,results=results),indent=2))
