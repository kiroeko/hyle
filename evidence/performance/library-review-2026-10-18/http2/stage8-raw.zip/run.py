from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/raw-fiber-plain'
OLD = HERE.parent / 'raw-fiber'
BUILD = Path('/root/hyle-scratch/http2-current-20261018/raw-fiber-plain')
BUILD.mkdir(exist_ok=True)
prior = json.loads((OLD / 'commands.json').read_text())
records = json.loads((HERE / 'commands.json').read_text()) if (HERE / 'commands.json').exists() else []


def run(name, argv, env=None, timeout=60):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=BUILD, env=env, capture_output=True, text=True, timeout=timeout)
    (HERE / (name+'.stdout.txt')).write_text(result.stdout)
    (HERE / (name+'.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(BUILD),exit=result.returncode))
    (HERE / 'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:
        print(result.stdout[-2400:]); print(result.stderr[-2400:])
        raise SystemExit(result.returncode)
    return result.stdout


def identity(path):
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())


parser = argparse.ArgumentParser(); parser.add_argument('action',choices=['build','measure']); args = parser.parse_args()
if args.action == 'build':
    command = next(x['argv'] for x in prior if x['name']=='compile-main')
    command = [x.replace(str(OLD),str(HERE)).replace('/http2-current-20261018/raw-fiber/','/http2-current-20261018/raw-fiber-plain/') for x in command]
    run('compile-main',command)
    link = next(x['argv'] for x in prior if x['name']=='link')
    link = [x.replace('/http2-current-20261018/raw-fiber/','/http2-current-20261018/raw-fiber-plain/') for x in link if not x.endswith('/probe.o') and x not in ('-ldl','-Wl,--export-dynamic-symbol=_ZN4hyle5sched5Fiber6resumeEv')]
    run('link',link)
    symbols = run('symbols',['readelf','-Ws',BUILD/'consumer'])
    definitions = [line for line in symbols.splitlines() if '_ZN4hyle5sched5Fiber6resumeEv' in line and ' UND ' not in line]
    assert not definitions, definitions
    assert 'raw_probe' not in symbols
    (HERE/'no-interposition.json').write_text(json.dumps(dict(own_resume_definition=False,raw_probe_symbols=False,removed_link_options=['probe.o','-ldl','--export-dynamic-symbol=Fiber::resume']),indent=2)+'\n')
    loader = run('loader',['ldd',BUILD/'consumer'])
    paths = {Path(x).resolve() for x in link if x.endswith(('.o','.a'))}
    for line in loader.splitlines():
        if 'libhyle_' in line and '=>' in line:
            paths.add(Path(line.split('=>',1)[1].strip().split()[0]).resolve())
    (HERE/'build-identity.json').write_text(json.dumps(dict(files=[identity(p) for p in sorted(paths)],consumer=identity(BUILD/'consumer')),indent=2)+'\n')
else:
    assert not any(x['name'].startswith('measure-') for x in records), 'Fixed two-process measurement already attempted; do not repeat.'
    env = {k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_'))}
    for order in ('ab','ba'):
        output = run('measure-'+order,['timeout','--kill-after=2s','30s','taskset','-c','2',BUILD/'consumer',order,HERE/('epochs-'+order+'.json')],env,timeout=35)
        print(output[-1800:],flush=True)
    (HERE/'cleanup-candidates.json').write_text(json.dumps(dict(directory=str(BUILD),files=[identity(BUILD/n) for n in ('main.o','consumer')],action='Root test.ps1 exact cleanup only; no deletion here.'),indent=2)+'\n')
