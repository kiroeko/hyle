"""Keep frozen protocol code and only the two validated raw driver changes."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'raw-fiber'
ALIGNED = HERE.parent / 'raw-fiber-aligned'
text = (OLD / 'formal-input.cc').read_text()
assert text.count('  ~HyleHarness() { scheduler_.shutdown(); }') == 1
text = text.replace('  ~HyleHarness() { scheduler_.shutdown(); }', '  ~HyleHarness() { scheduler_.shutdown(); }\n  Scheduler& diagnostic_scheduler() noexcept { return scheduler_; }\n  IoContext& diagnostic_io() noexcept { return io_; }', 1)
before = 'bool raw_write(RawWire &wire, bool &progress) noexcept {'
assert text.count(before) == 1
text = text.replace(before, 'bool raw_write(RawWire &wire, bool &progress, bool single_attempt = false) noexcept {', 1)
before = '      wire.begin += static_cast<std::size_t>(written);\n      progress = true;\n      continue;'
after = '      wire.begin += static_cast<std::size_t>(written);\n      progress = true;\n      // Keep the validated single immediate retry after a yield.\n      if (single_attempt) {\n        if (wire.begin == wire.end) wire.begin = wire.end = 0;\n        return true;\n      }\n      continue;'
assert text.count(before) == 1
text = text.replace(before, after, 1)
(HERE / 'plain_bench.cc').write_text(text)
(HERE / 'split_advance.h').write_bytes((OLD / 'split_advance.h').read_bytes())
for name in ('main.cc', 'plain_bench.cc', 'split_advance.h'):
    data = (HERE / name).read_text()
    assert not any(token in data for token in ('raw_probe', '#include "probe.h"', 'io_site', 'Phase::', 'current_waker', 'spawn_task_on'))
(HERE / 'protocol-only-diff.patch').write_text(''.join(difflib.unified_diff((OLD / 'formal-input.cc').read_text().splitlines(True), text.splitlines(True), fromfile='stage6/formal-input.cc', tofile='plain/plain_bench.cc')))
(HERE / 'aligned-to-plain-main.diff').write_text(''.join(difflib.unified_diff((ALIGNED / 'main.cc').read_text().splitlines(True), (HERE / 'main.cc').read_text().splitlines(True), fromfile='aligned/main.cc', tofile='plain/main.cc')))
(HERE / 'source-identity.json').write_text(json.dumps({str(path):{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in [HERE/'main.cc', HERE/'plain_bench.cc', HERE/'split_advance.h', HERE/'prepare.py', OLD/'formal-input.cc', ALIGNED/'main.cc']},indent=2)+'\n')
print('Plain source prepared; frozen protocol changed only by accessors and single-attempt helper. No run.')
