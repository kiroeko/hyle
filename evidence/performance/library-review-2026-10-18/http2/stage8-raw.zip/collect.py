"""Post-run metadata only; never executes the consumer."""
from pathlib import Path
import json
import os
import platform
import subprocess

HERE = Path('/mnt/c/public/project-hyle/hyle/.scratch/perf-review-2026-10-18/http2/raw-fiber-plain')
metadata = dict(
    uname=platform.uname()._asdict(),
    compiler=subprocess.check_output(['g++-14','--version'],text=True),
    cpu_model=next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),
    measurement_affinity='Both recorded processes taskset -c2, one persistent Scheduler worker plus retained inactive RawHarness worker; no spawn_task_on.',
    loader_injection={key:os.environ.get(key) for key in ('LD_PRELOAD','LD_AUDIT')},
    scope='Post-run read-only metadata. No additional benchmark or consumer execution.')
(HERE/'host-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata))
