from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/terminal-drain'
BASE=Path('/root/hyle-scratch/http2-current-20261018')
OUT=BASE/'terminal-drain';OUT.mkdir(exist_ok=True)
ENV={k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_'))}
ENV['LD_LIBRARY_PATH']=str(BASE/'current-holdout')+':/root/hyle-scratch/io-watch-v2-dev/bin'
LOG=HERE/'commands.json';records=json.loads(LOG.read_text()) if LOG.exists() else []
def rec(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(name,argv):
    if any(x['name']==name for x in records):raise RuntimeError('No overwritten/retried attempt '+name)
    argv=list(map(str,argv));p=subprocess.run(argv,cwd=OUT,env=ENV,capture_output=True,text=True,timeout=60)
    (HERE/(name+'.stdout.txt')).write_text(p.stdout);(HERE/(name+'.stderr.txt')).write_text(p.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(OUT),exit=p.returncode,environment={'LD_LIBRARY_PATH':ENV['LD_LIBRARY_PATH']}))
    LOG.write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,p.stdout[-3000:],p.stderr[-1500:],flush=True)
    if p.returncode:raise RuntimeError(name)
    return p.stdout
if sys.argv[1]=='build':
    old=json.loads((HERE.parent/'current-build-commands.json').read_text())
    cmd=next(x['argv'] for x in old if x['name']=='bench_io_http2_http2_p1_bench.cc')
    run('compile-main',cmd[:-4]+['-DCONTROL_DIAGNOSTIC=1','-c',HERE/'main.cc','-o',OUT/'main.o'])
    link=next(x['argv'] for x in old if x['name']=='link')
    link=[str(OUT/'consumer') if x==str(BASE/'http2_current') else
          str(BASE/'fixed-send-frame/http2.o') if x==str(BASE/'src_io_http2_http2.cc.o') else
          str(OUT/'main.o') if x==str(BASE/'bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
    run('link-consumer',link)
    loader=run('loader',['ldd',OUT/'consumer'])
    assert str(BASE/'current-holdout/libhyle_io_core.so.0.1.0') in loader
    inputs={Path(x) for x in link if x.endswith(('.o','.a'))}
    for line in loader.splitlines():
        if 'libhyle_' in line and '=>' in line:inputs.add(Path(line.split('=>')[1].strip().split()[0]))
    (HERE/'build-identity.json').write_text(json.dumps(dict(files=[rec(p) for p in sorted(inputs)],
        artifacts=[rec(p) for p in sorted(OUT.iterdir())],
        current_product=[rec(ROOT/x) for x in ['src/io_http2/http2.cc','src/io_core/proactor.cc']],
        note='Only1scratchTU freshlycompiled. Frozenrawprotocol; currentretainedproactor/helperobjects, otheroldfoundationcache. NoHyleHTTP2 publicAPI execution in thisrawcontrol.'),indent=2)+'\n')
elif sys.argv[1]=='run':
    assert not any(x['name'].startswith('episode-') for x in records),'No episode retries'
    for mode in ['manual','endpoints']:
        run('episode-'+mode,['taskset','-c','2','timeout','--kill-after=2s','20s',OUT/'consumer',mode,HERE/mode])
else:raise RuntimeError('unknownphase')
