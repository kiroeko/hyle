from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'common-episode/main.cc'
s=OLD.read_text()
prelude=r'''
#include <array>
#include <vector>
#include <fstream>
#include <nghttp2/nghttp2.h>

struct Capture { std::vector<unsigned char> bytes; std::size_t used=0; bool overflow=false; };
std::array<Capture,2> captures;
std::array<int,2> capture_fds{-1,-1};
std::array<nghttp2_session*,2> capture_sessions{nullptr,nullptr};
struct Credit { std::uint64_t stream_calls=0,stream_bytes=0,connection_calls=0,connection_bytes=0,errors=0; };
std::array<Credit,2> credits;
bool quiescent=false;
unsigned terminal_passes=0;
void record_sent(int fd,const void* bytes,std::size_t n) {
  for(unsigned r=0;r<2;++r) if(capture_fds[r]==fd) {
    auto& c=captures[r];
    if(n>c.bytes.size()-c.used){c.overflow=true;return;}
    std::memcpy(c.bytes.data()+c.used,bytes,n);c.used+=n;return;
  }
}
int diag_consume_stream(nghttp2_session* s,std::int32_t id,std::size_t n){
  int rc=::nghttp2_session_consume_stream(s,id,n);
  for(unsigned r=0;r<2;++r)if(capture_sessions[r]==s){
    ++credits[r].stream_calls;credits[r].stream_bytes+=n;credits[r].errors+=rc!=0;
  }
  return rc;
}
int diag_consume_connection(nghttp2_session* s,std::size_t n){
  int rc=::nghttp2_session_consume_connection(s,n);
  for(unsigned r=0;r<2;++r)if(capture_sessions[r]==s){
    ++credits[r].connection_calls;credits[r].connection_bytes+=n;credits[r].errors+=rc!=0;
  }
  return rc;
}
'''
s=s.replace('#include <chrono>','#include <chrono>\n#include <cstring>\n'+prelude,1)
s=s.replace('  const ssize_t result=::send(fd,data,n,flags);',
    '  const ssize_t result=::send(fd,data,n,flags);\n  if(result>0)record_sent(fd,data,static_cast<std::size_t>(result));',1)
s=s.replace('#include "protocol.cc"',
    '#define nghttp2_session_consume_stream diag_consume_stream\n'
    '#define nghttp2_session_consume_connection diag_consume_connection\n'
    '#include "../common-episode/protocol.cc"\n'
    '#undef nghttp2_session_consume_stream\n#undef nghttp2_session_consume_connection',1)
s=s.replace('#include "split_advance.h"','#include "../common-episode/split_advance.h"',1)
assert s.count('      wire.begin+=result.bytes;')==1
s=s.replace('      wire.begin+=result.bytes;',
    '      record_sent(wire.descriptor,wire.pending.data()+wire.begin,result.bytes);\n      wire.begin+=result.bytes;',1)
s=s.replace('    if(mode==Mode::Manual){',
    '    for(unsigned r=0;r<2;++r){capture_fds[r]=descriptors[r];capture_sessions[r]=e.endpoint[r].session;}\n'
    '    if(mode==Mode::Manual){',1)
needle='    if(e.failed || e.endpoint[0].completed!=workload.streams ||'
assert s.count(needle)==1
s=s.replace(needle,
    '    snapshot("PRE",e);\n'
    '    if(outcome==workload.streams && !e.failed)quiescent=terminal_drain(e);\n'
    '    snapshot("POST",e);\n'
    '    if(!quiescent)outcome=-1;\n'+needle,1)
helper=r'''
void snapshot(const char* phase,const Episode& e){
  std::printf("{\"phase\":\"%s\",\"sent_offsets\":[%zu,%zu],\"native\":[",phase,captures[0].used,captures[1].used);
  for(unsigned r=0;r<2;++r){
    const auto& n=e.endpoint[r];const auto& w=e.wire[r];
    std::printf("%s{\"role\":%u,\"completed\":%d,\"failed\":%s,\"want_write\":%d,\"outbound_queue_size\":%zu,\"wire_begin\":%zu,\"wire_end\":%zu,\"readable_pending\":%zu,\"connection_recv_data_length\":%d,\"connection_local_window\":%d,\"streams\":[",
      r?",":"",r,n.completed,n.failed?"true":"false",nghttp2_session_want_write(n.session),
      nghttp2_session_get_outbound_queue_size(n.session),w.begin,w.end,n.readable.size()-n.readable_head,
      nghttp2_session_get_effective_recv_data_length(n.session),nghttp2_session_get_local_window_size(n.session));
    for(std::size_t i=0;i<n.streams.size();++i){const auto& s=n.streams[i];
      std::printf("%s{\"id\":%d,\"received\":%zu,\"input_end\":%s,\"input_done\":%s,\"output_done\":%s,\"buffered\":%zu}",i?",":"",s.id,s.received,
        s.input_end_received?"true":"false",s.input_done?"true":"false",s.output_done?"true":"false",s.inbound.size()-s.inbound_start);
    }
    const auto& c=credits[r];
    std::printf("],\"credit\":{\"stream_calls\":%llu,\"stream_bytes\":%llu,\"connection_calls\":%llu,\"connection_bytes\":%llu,\"errors\":%llu}}",
      (unsigned long long)c.stream_calls,(unsigned long long)c.stream_bytes,
      (unsigned long long)c.connection_calls,(unsigned long long)c.connection_bytes,(unsigned long long)c.errors);
  }
  std::printf("]}\n");
}
bool terminal_drain(Episode& e){
  for(terminal_passes=1;terminal_passes<=1024;++terminal_passes){
    bool progress=false;
    const auto empty0=active_counts->role[0].read_empty,empty1=active_counts->role[1].read_empty;
    if(!raw_fill_output(e.endpoint[0],e.wire[0]) || !raw_fill_output(e.endpoint[1],e.wire[1]) ||
       !raw_write(e.wire[0],progress) || !raw_write(e.wire[1],progress) ||
       !raw_read(e.endpoint[0],e.wire[0],progress) || !raw_read(e.endpoint[1],e.wire[1],progress) ||
       !raw_consume_readable(e.endpoint[0],progress) || !raw_consume_readable(e.endpoint[1],progress))return false;
    if(progress)continue;
    bool done=active_counts->role[0].read_empty>empty0 && active_counts->role[1].read_empty>empty1;
    for(unsigned r=0;r<2;++r){
      done=done && e.wire[r].begin==e.wire[r].end && !nghttp2_session_want_write(e.endpoint[r].session) &&
        e.endpoint[r].completed==e.workload.streams && !e.endpoint[r].failed &&
        e.endpoint[r].readable.size()==e.endpoint[r].readable_head;
      for(const auto& s:e.endpoint[r].streams)
        done=done && s.input_done && s.output_done && s.input_end_received &&
          s.inbound.size()==s.inbound_start;
    }
    return done; // No future producer after join: idle but not quiescent is failure.
  }
  return false;
}
'''
assert s.count('bool server_flushed(const Episode& e){')==1
s=s.replace('bool server_flushed(const Episode& e){',helper+'\nbool server_flushed(const Episode& e){',1)
main=r'''
int main(int argc,char**argv){
  if(argc!=3 || (std::string_view(argv[1])!="manual" && std::string_view(argv[1])!="endpoints"))return 2;
  std::signal(SIGPIPE,SIG_IGN);
  const auto workload=make_workload("HTTP2 untimed terminal drain 4x256KiB",4,256*1024,256*1024,
                                    NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  for(auto& c:captures)c.bytes.resize(2*1024*1024+65536);
  HyleHarness harness;RawHarness inactive_manual_thread;Counts counts;
  const auto mode=std::string_view(argv[1])=="manual"?Mode::Manual:Mode::Endpoints;
  const int result=run_common(harness,workload,mode,true,&counts);
  print_counts(argv[1],counts);
  bool valid=result==4 && quiescent;
  for(unsigned r=0;r<2;++r){
    std::ofstream out(std::string(argv[2])+(r?"-s2c.bin":"-c2s.bin"),std::ios::binary);
    out.write(reinterpret_cast<const char*>(captures[r].bytes.data()),captures[r].used);
    valid=valid && out.good() && !captures[r].overflow && credits[r].errors==0 &&
      credits[r].stream_bytes==1048576 && credits[r].connection_bytes==1048576;
  }
  std::printf("{\"result\":%d,\"quiescent\":%s,\"terminal_passes\":%u,\"capture_overflow\":%s,\"credit_valid\":%s}\n",
    result,quiescent?"true":"false",terminal_passes,
    (captures[0].overflow||captures[1].overflow)?"true":"false",valid?"true":"false");
  return valid?0:3;
}
'''
start=s.index('int main(int argc,char**argv){')
s=s[:start]+main
(HERE/'main.cc').write_text(s)
def rec(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(HERE/'source-identity.json').write_text(json.dumps(dict(head='74fc012eb1f5c6bd9795437e28c48c76f8e6d0b5',
    frozen_common=rec(OLD),generated=rec(HERE/'main.cc'),
    protocol=rec(HERE.parent/'common-episode/protocol.cc'),split_advance=rec(HERE.parent/'common-episode/split_advance.h'),
    canonical_peer=rec(ROOT/'bench/io_http2/http2_p1_bench.cc'),
    mutations='Only owner-local successfulsend capture/creditcounts, PREPOST snapshots, common postjointerminaldrain and oneepisodemain. Originaldriver algorithm/fixture unchanged.'),indent=2)+'\n')
