#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <chrono>
#include <cstring>

#include <array>
#include <vector>
#include <fstream>
#include <nghttp2/nghttp2.h>

struct Capture { std::vector<unsigned char> bytes; std::size_t used=0; bool overflow=false; };
std::array<Capture,2> captures;
std::array<int,2> capture_fds{-1,-1};
std::array<nghttp2_session*,2> capture_sessions{nullptr,nullptr};
struct Credit { std::uint64_t stream_calls=0,stream_bytes=0,connection_calls=0,connection_bytes=0,errors=0; };
std::array<Credit,2> credits;
bool quiescent=false;
unsigned terminal_passes=0;
void record_sent(int fd,const void* bytes,std::size_t n) {
  for(unsigned r=0;r<2;++r) if(capture_fds[r]==fd) {
    auto& c=captures[r];
    if(n>c.bytes.size()-c.used){c.overflow=true;return;}
    std::memcpy(c.bytes.data()+c.used,bytes,n);c.used+=n;return;
  }
}
int diag_consume_stream(nghttp2_session* s,std::int32_t id,std::size_t n){
  int rc=::nghttp2_session_consume_stream(s,id,n);
  for(unsigned r=0;r<2;++r)if(capture_sessions[r]==s){
    ++credits[r].stream_calls;credits[r].stream_bytes+=n;credits[r].errors+=rc!=0;
  }
  return rc;
}
int diag_consume_connection(nghttp2_session* s,std::size_t n){
  int rc=::nghttp2_session_consume_connection(s,n);
  for(unsigned r=0;r<2;++r)if(capture_sessions[r]==s){
    ++credits[r].connection_calls;credits[r].connection_bytes+=n;credits[r].errors+=rc!=0;
  }
  return rc;
}


#ifndef CONTROL_DIAGNOSTIC
#define CONTROL_DIAGNOSTIC 0
#endif
struct Counts {
  struct Role {
    std::uint64_t reads=0, read_ready=0, read_empty=0, read_bytes=0;
    std::uint64_t writes=0, write_ready=0, write_empty=0, write_bytes=0;
    std::uint64_t yields=0, async_reads=0, async_writes=0;
    std::uint64_t async_read_bytes=0, async_write_bytes=0;
  } role[2];
  int fd[2]{-1,-1};
  std::uint64_t polls=0;
};
#if CONTROL_DIAGNOSTIC
Counts* active_counts=nullptr;
Counts::Role* count_for(int fd) {
  if (!active_counts) return nullptr;
  for (unsigned r=0;r<2;++r) if (active_counts->fd[r]==fd) return &active_counts->role[r];
  return nullptr;
}
ssize_t control_recv(int fd,void* data,std::size_t n,int flags) {
  const ssize_t result=::recv(fd,data,n,flags);
  if (auto* c=count_for(fd)) {
    ++c->reads;
    if(result>0){++c->read_ready;c->read_bytes+=result;}
    else if(result<0 && (errno==EAGAIN || errno==EWOULDBLOCK))++c->read_empty;
  }
  return result;
}
ssize_t control_send(int fd,const void* data,std::size_t n,int flags) {
  const ssize_t result=::send(fd,data,n,flags);
  if(result>0)record_sent(fd,data,static_cast<std::size_t>(result));
  if(auto* c=count_for(fd)){
    ++c->writes;
    if(result>0){++c->write_ready;c->write_bytes+=result;}
    else if(result<0 && (errno==EAGAIN || errno==EWOULDBLOCK))++c->write_empty;
  }
  return result;
}
#define recv control_recv
#define send control_send
#endif
#define main original_benchmark_main
#define nghttp2_session_consume_stream diag_consume_stream
#define nghttp2_session_consume_connection diag_consume_connection
#include "../common-episode/protocol.cc"
#undef nghttp2_session_consume_stream
#undef nghttp2_session_consume_connection
#undef main
#if CONTROL_DIAGNOSTIC
#undef recv
#undef send
#endif
#include "../common-episode/split_advance.h"

namespace {
enum class Mode { Manual, Endpoints };
struct Episode {
  const Workload& workload;
  std::array<RawEndpoint,2> endpoint;
  std::array<RawWire,2> wire;
  std::array<TcpStream,2> socket;
  hyle::sched::Event client_consumed;
  bool failed=false;
  ~Episode(){
    for(unsigned r=0;r<2;++r){
      if(endpoint[r].session) nghttp2_session_del(endpoint[r].session);
      socket[r]=TcpStream{};
    }
  }
  int fail(){
    if(!failed){
      failed=true;
      for(auto& w:wire) if(w.descriptor>=0) (void)::shutdown(w.descriptor,SHUT_RDWR);
      client_consumed.signal();
    }
    return -1;
  }
};

void snapshot(const char* phase,const Episode& e){
  std::printf("{\"phase\":\"%s\",\"sent_offsets\":[%zu,%zu],\"native\":[",phase,captures[0].used,captures[1].used);
  for(unsigned r=0;r<2;++r){
    const auto& n=e.endpoint[r];const auto& w=e.wire[r];
    std::printf("%s{\"role\":%u,\"completed\":%d,\"failed\":%s,\"want_write\":%d,\"outbound_queue_size\":%zu,\"wire_begin\":%zu,\"wire_end\":%zu,\"readable_pending\":%zu,\"connection_recv_data_length\":%d,\"connection_local_window\":%d,\"streams\":[",
      r?",":"",r,n.completed,n.failed?"true":"false",nghttp2_session_want_write(n.session),
      nghttp2_session_get_outbound_queue_size(n.session),w.begin,w.end,n.readable.size()-n.readable_head,
      nghttp2_session_get_effective_recv_data_length(n.session),nghttp2_session_get_local_window_size(n.session));
    for(std::size_t i=0;i<n.streams.size();++i){const auto& s=n.streams[i];
      std::printf("%s{\"id\":%d,\"received\":%zu,\"input_end\":%s,\"input_done\":%s,\"output_done\":%s,\"buffered\":%zu}",i?",":"",s.id,s.received,
        s.input_end_received?"true":"false",s.input_done?"true":"false",s.output_done?"true":"false",s.inbound.size()-s.inbound_start);
    }
    const auto& c=credits[r];
    std::printf("],\"credit\":{\"stream_calls\":%llu,\"stream_bytes\":%llu,\"connection_calls\":%llu,\"connection_bytes\":%llu,\"errors\":%llu}}",
      (unsigned long long)c.stream_calls,(unsigned long long)c.stream_bytes,
      (unsigned long long)c.connection_calls,(unsigned long long)c.connection_bytes,(unsigned long long)c.errors);
  }
  std::printf("]}\n");
}
bool terminal_drain(Episode& e){
  for(terminal_passes=1;terminal_passes<=1024;++terminal_passes){
    bool progress=false;
    const auto empty0=active_counts->role[0].read_empty,empty1=active_counts->role[1].read_empty;
    if(!raw_fill_output(e.endpoint[0],e.wire[0]) || !raw_fill_output(e.endpoint[1],e.wire[1]) ||
       !raw_write(e.wire[0],progress) || !raw_write(e.wire[1],progress) ||
       !raw_read(e.endpoint[0],e.wire[0],progress) || !raw_read(e.endpoint[1],e.wire[1],progress) ||
       !raw_consume_readable(e.endpoint[0],progress) || !raw_consume_readable(e.endpoint[1],progress))return false;
    if(progress)continue;
    bool done=active_counts->role[0].read_empty>empty0 && active_counts->role[1].read_empty>empty1;
    for(unsigned r=0;r<2;++r){
      done=done && e.wire[r].begin==e.wire[r].end && !nghttp2_session_want_write(e.endpoint[r].session) &&
        e.endpoint[r].completed==e.workload.streams && !e.endpoint[r].failed &&
        e.endpoint[r].readable.size()==e.endpoint[r].readable_head;
      for(const auto& s:e.endpoint[r].streams)
        done=done && s.input_done && s.output_done && s.input_end_received &&
          s.inbound.size()==s.inbound_start;
    }
    return done; // No future producer after join: idle but not quiescent is failure.
  }
  return false;
}

bool server_flushed(const Episode& e){
  const auto& endpoint=e.endpoint[1]; const auto& wire=e.wire[1];
  const auto count=static_cast<std::size_t>(e.workload.streams);
  return endpoint.streams.size()==count && endpoint.next_response_pair==count &&
         endpoint.streams[count-2].output_done && wire.begin==wire.end;
}
Task<int> manual_driver(AllocatorRef,Episode* e) noexcept {
  auto& client=e->endpoint[0]; auto& server=e->endpoint[1];
  auto& cw=e->wire[0]; auto& sw=e->wire[1];
  // Original canonical manual ordering, now inside one Scheduler task.
  while(client.completed!=e->workload.streams && !client.failed && !server.failed){
    bool progress=false;
    if(!raw_advance(client,server,cw,sw) || !raw_fill_output(client,cw) ||
       !raw_fill_output(server,sw) || !raw_write(cw,progress) ||
       !raw_write(sw,progress) || !raw_read(client,cw,progress) ||
       !raw_read(server,sw,progress) || !raw_consume_readable(client,progress) ||
       !raw_consume_readable(server,progress)) co_return e->fail();
    if(progress) continue;
    pollfd descriptors[2]={{cw.descriptor,static_cast<short>(POLLIN|(cw.begin!=cw.end?POLLOUT:0)),0},
                          {sw.descriptor,static_cast<short>(POLLIN|(sw.begin!=sw.end?POLLOUT:0)),0}};
    int ready;
    do {
#if CONTROL_DIAGNOSTIC
      ++active_counts->polls;
#endif
      ready=::poll(descriptors,2,5000);
    }while(ready<0 && errno==EINTR);
    if(ready<=0) co_return e->fail();
  }
  if(client.failed || server.failed || client.completed!=e->workload.streams ||
     server.completed!=e->workload.streams) co_return e->fail();
  co_return e->workload.streams;
}
bool feed_async(RawEndpoint& endpoint,RawWire& wire,hyle::io::TransferResult result){
  if(!result.ok() || result.eof || !result.bytes || result.bytes>wire.input.size()) return false;
  if(nghttp2_session_mem_recv2(endpoint.session,wire.input.data(),result.bytes)!=
     static_cast<nghttp2_ssize>(result.bytes)) return false;
  bool progress=false;
  return raw_consume_readable(endpoint,progress);
}
Task<int> endpoint_driver(AllocatorRef,Episode* e,unsigned role) noexcept {
  auto& endpoint=e->endpoint[role]; auto& wire=e->wire[role]; auto& socket=e->socket[role];
  // Sessions and transports belong to the common caller, not this Task frame.
  for(;;){
    if(e->failed || endpoint.failed) co_return e->fail();
    if(role==0 && endpoint.completed==e->workload.streams){
      e->client_consumed.signal(); co_return e->workload.streams;
    }
    if(role==1 && server_flushed(*e)){
      if(!e->client_consumed.wait_for(std::chrono::seconds(5)) || e->failed ||
         endpoint.completed!=e->workload.streams) co_return e->fail();
      co_return e->workload.streams;
    }
    if(!(role==0?advance_client(endpoint,wire):advance_server(endpoint,wire)) ||
       !raw_fill_output(endpoint,wire)) co_return e->fail();
    bool written=false;
    if(!raw_write(wire,written)) co_return e->fail();
    if(role==1 && server_flushed(*e)) continue;
    if(written && wire.begin==wire.end) continue;
    bool progress=false;
    if(!raw_read(endpoint,wire,progress) || !raw_consume_readable(endpoint,progress)) co_return e->fail();
    if(progress) continue;
#if CONTROL_DIAGNOSTIC
    ++active_counts->role[role].yields;
#endif
    hyle::sched::Fiber::yield();
    if(e->failed) co_return e->fail();
    progress=false;
    if(!raw_read(endpoint,wire,progress) || !raw_consume_readable(endpoint,progress)) co_return e->fail();
    if(progress) continue;
    if(wire.begin!=wire.end){
      written=false;
      if(!raw_write(wire,written,true)) co_return e->fail();
      if(written) continue;
#if CONTROL_DIAGNOSTIC
      ++active_counts->role[role].async_writes;
#endif
      const auto result=co_await socket.write_some(std::span<const std::byte>(
          reinterpret_cast<const std::byte*>(wire.pending.data()+wire.begin),wire.end-wire.begin),
          hyle::io::OperationOptions{});
#if CONTROL_DIAGNOSTIC
      active_counts->role[role].async_write_bytes+=result.bytes;
#endif
      if(!result.ok() || !result.bytes || result.bytes>wire.end-wire.begin) co_return e->fail();
      record_sent(wire.descriptor,wire.pending.data()+wire.begin,result.bytes);
      wire.begin+=result.bytes;
      if(wire.begin==wire.end) wire.begin=wire.end=0;
    }else{
#if CONTROL_DIAGNOSTIC
      ++active_counts->role[role].async_reads;
#endif
      const auto result=co_await socket.read_some(std::span<std::byte>(
          reinterpret_cast<std::byte*>(wire.input.data()),wire.input.size()),hyle::io::OperationOptions{});
#if CONTROL_DIAGNOSTIC
      active_counts->role[role].async_read_bytes+=result.bytes;
#endif
      if(!feed_async(endpoint,wire,result)) co_return e->fail();
    }
  }
}
int run_common(HyleHarness& harness,const Workload& workload,Mode mode,
               bool check_descriptors=false,Counts* counts=nullptr){
  std::array<int,2> descriptors{-1,-1};
  int outcome=-1;
  {
    // Identical caller-owned allocations, initialization and lifetime in both modes.
    Episode e{workload};
    auto pair=make_socket_pair(); if(!pair.valid()) return -1;
    auto client=TcpStream::adopt(harness.diagnostic_io(),kOwner,pair.release_client());
    auto server=TcpStream::adopt(harness.diagnostic_io(),kOwner,pair.release_server());
    if(!client || !server) return -1;
    e.socket[0]=std::move(*client);e.socket[1]=std::move(*server);
    for(unsigned role=0;role<2;++role){
      e.endpoint[role].workload=&workload;e.endpoint[role].server=role==1;
      e.endpoint[role].streams.reserve(workload.streams);
      descriptors[role]=e.wire[role].descriptor=static_cast<int>(e.socket[role].native_handle());
      if(!raw_initialize(e.endpoint[role])) return -1;
    }
#if CONTROL_DIAGNOSTIC
    active_counts=counts;
    for(unsigned r=0;r<2;++r) counts->fd[r]=descriptors[r];
#else
    (void)counts;
#endif
    for(unsigned r=0;r<2;++r){capture_fds[r]=descriptors[r];capture_sessions[r]=e.endpoint[r].session;}
    if(mode==Mode::Manual){
      auto joined=hyle::sched::spawn_task(harness.diagnostic_scheduler(),system_allocator(),
          manual_driver(system_allocator(),&e));
      auto result=joined.join();
      if(result && *result==workload.streams) outcome=*result;
    }else{
      auto server_join=hyle::sched::spawn_task(harness.diagnostic_scheduler(),system_allocator(),
          endpoint_driver(system_allocator(),&e,1));
      auto client_join=hyle::sched::spawn_task(harness.diagnostic_scheduler(),system_allocator(),
          endpoint_driver(system_allocator(),&e,0));
      auto client_result=client_join.join();auto server_result=server_join.join();
      if(client_result && server_result && *client_result==workload.streams &&
         *server_result==workload.streams) outcome=workload.streams;
    }
    snapshot("PRE",e);
    if(outcome==workload.streams && !e.failed)quiescent=terminal_drain(e);
    snapshot("POST",e);
    if(!quiescent)outcome=-1;
    if(e.failed || e.endpoint[0].completed!=workload.streams ||
       e.endpoint[1].completed!=workload.streams) outcome=-1;
  }
#if CONTROL_DIAGNOSTIC
  active_counts=nullptr;
#endif
  if(check_descriptors) for(int fd:descriptors){
    errno=0;if(::fcntl(fd,F_GETFD)!=-1 || errno!=EBADF) return -1;
  }
  return outcome;
}
#if CONTROL_DIAGNOSTIC
void print_counts(const char* mode,const Counts& c){
  std::printf("{\"mode\":\"%s\",\"completed\":4,\"descriptors_closed\":true,\"polls\":%llu,\"roles\":[",mode,
      static_cast<unsigned long long>(c.polls));
  for(unsigned r=0;r<2;++r){const auto& v=c.role[r];
    std::printf("%s{\"role\":%u,\"recv_calls\":%llu,\"recv_ready\":%llu,\"recv_empty\":%llu,\"recv_bytes\":%llu,"
      "\"send_calls\":%llu,\"send_ready\":%llu,\"send_empty\":%llu,\"send_bytes\":%llu,\"yields\":%llu,"
      "\"async_reads\":%llu,\"async_writes\":%llu,\"async_recv_bytes\":%llu,\"async_send_bytes\":%llu}",r?",":"",r,
      (unsigned long long)v.reads,(unsigned long long)v.read_ready,(unsigned long long)v.read_empty,(unsigned long long)v.read_bytes,
      (unsigned long long)v.writes,(unsigned long long)v.write_ready,(unsigned long long)v.write_empty,(unsigned long long)v.write_bytes,
      (unsigned long long)v.yields,(unsigned long long)v.async_reads,(unsigned long long)v.async_writes,
      (unsigned long long)v.async_read_bytes,(unsigned long long)v.async_write_bytes);
  }
  std::printf("]}\n");
}
#endif
} // namespace

int main(int argc,char**argv){
  if(argc!=3 || (std::string_view(argv[1])!="manual" && std::string_view(argv[1])!="endpoints"))return 2;
  std::signal(SIGPIPE,SIG_IGN);
  const auto workload=make_workload("HTTP2 untimed terminal drain 4x256KiB",4,256*1024,256*1024,
                                    NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  for(auto& c:captures)c.bytes.resize(2*1024*1024+65536);
  HyleHarness harness;RawHarness inactive_manual_thread;Counts counts;
  const auto mode=std::string_view(argv[1])=="manual"?Mode::Manual:Mode::Endpoints;
  const int result=run_common(harness,workload,mode,true,&counts);
  print_counts(argv[1],counts);
  bool valid=result==4 && quiescent;
  for(unsigned r=0;r<2;++r){
    std::ofstream out(std::string(argv[2])+(r?"-s2c.bin":"-c2s.bin"),std::ios::binary);
    out.write(reinterpret_cast<const char*>(captures[r].bytes.data()),captures[r].used);
    valid=valid && out.good() && !captures[r].overflow && credits[r].errors==0 &&
      credits[r].stream_bytes==1048576 && credits[r].connection_bytes==1048576;
  }
  std::printf("{\"result\":%d,\"quiescent\":%s,\"terminal_passes\":%u,\"capture_overflow\":%s,\"credit_valid\":%s}\n",
    result,quiescent?"true":"false",terminal_passes,
    (captures[0].overflow||captures[1].overflow)?"true":"false",valid?"true":"false");
  return valid?0:3;
}
