from pathlib import Path
from collections import Counter,defaultdict
import json
HERE=Path(__file__).resolve().parent
NAMES={0:'DATA',1:'HEADERS',2:'PRIORITY',3:'RST_STREAM',4:'SETTINGS',5:'PUSH_PROMISE',6:'PING',7:'GOAWAY',8:'WINDOW_UPDATE',9:'CONTINUATION'}
PREFACE=b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
reports=[]
for mode in ['manual','endpoints']:
    rows=[json.loads(x) for x in (HERE/('episode-'+mode+'.stdout.txt')).read_text().splitlines() if x.startswith('{')]
    pre=next(x for x in rows if x.get('phase')=='PRE');post=next(x for x in rows if x.get('phase')=='POST')
    counts=next(x for x in rows if x.get('mode')==mode);result=rows[-1]
    assert result['result']==4 and result['quiescent'] and result['credit_valid'] and not result['capture_overflow']
    assert counts['descriptors_closed'] and counts['completed']==4
    directions=[]
    for role,direction in enumerate(['c2s','s2c']):
        data=(HERE/(mode+'-'+direction+'.bin')).read_bytes()
        assert len(data)==post['sent_offsets'][role]
        assert len(data)==counts['roles'][role]['send_bytes']+counts['roles'][role]['async_send_bytes']
        other=counts['roles'][1-role]
        assert len(data)==other['recv_bytes']+other['async_recv_bytes']
        offset=0
        if role==0:assert data.startswith(PREFACE);offset=len(PREFACE)
        frames=[];types=Counter();wire_bytes_by_type=Counter();increments=defaultdict(lambda:dict(count=0,increment_sum=0))
        data_bytes=defaultdict(int);end_stream=Counter()
        while offset<len(data):
            start=offset;assert offset+9<=len(data),(mode,direction,offset,'shortheader')
            n=int.from_bytes(data[offset:offset+3],'big');kind=data[offset+3];flags=data[offset+4]
            stream=int.from_bytes(data[offset+5:offset+9],'big')&0x7fffffff
            end=offset+9+n;assert end<=len(data),(mode,direction,offset,'shortpayload')
            phase='before' if end<=pre['sent_offsets'][role] else 'terminal' if start>=pre['sent_offsets'][role] else 'crossing'
            item=dict(offset=start,end=end,payload_bytes=n,type=NAMES.get(kind,str(kind)),flags=flags,stream=stream,phase=phase)
            payload=data[offset+9:end]
            if kind==8:
                assert n==4
                increment=int.from_bytes(payload,'big')&0x7fffffff;assert increment>0
                item['window_increment']=increment
                increments[stream]['count']+=1;increments[stream]['increment_sum']+=increment
            if kind==0:
                body=n
                if flags&8:body-=1+payload[0]
                assert body>=0
                data_bytes[stream]+=body
            if kind in (0,1) and flags&1:end_stream[stream]+=1
            types[item['type']]+=1;wire_bytes_by_type[item['type']]+=end-start;frames.append(item);offset=end
        assert dict(data_bytes)=={1:262144,3:262144,5:262144,7:262144}
        assert dict(end_stream)=={1:1,3:1,5:1,7:1}
        assert types['RST_STREAM']==0 and types['GOAWAY']==0
        directions.append(dict(direction=direction,bytes_before=pre['sent_offsets'][role],bytes_after=len(data),
            terminal_actual_sent_bytes=len(data)-pre['sent_offsets'][role],
            frame_count=len(frames),types=dict(types),wire_bytes_by_type=dict(wire_bytes_by_type),window_updates=dict(increments),
            data_payload_bytes_per_stream=dict(data_bytes),end_stream_count_per_stream=dict(end_stream),
            frames=frames))
    for n in post['native']:
        assert n['want_write']==0 and n['wire_begin']==n['wire_end'] and n['readable_pending']==0 and n['completed']==4
        assert n['credit']['stream_bytes']==n['credit']['connection_bytes']==1048576 and n['credit']['errors']==0
        assert all(s['received']==262144 and s['input_done'] and s['input_end'] and s['output_done'] and not s['buffered'] for s in n['streams'])
    reports.append(dict(mode=mode,PRE=pre,POST=post,counts=counts,result=result,directions=directions))
(HERE/'parsed-frames.json').write_text(json.dumps(dict(method='Offlineparsing actualsuccessfulsend byte streams once per direction; asyncpartialwrites recordedonce after original resultvalidation. No recvduplication or callback-as-send inference.',episodes=reports),indent=2)+'\n')
compact=[dict(mode=r['mode'],terminal_passes=r['result']['terminal_passes'],
    directions=[{k:v for k,v in d.items() if k!='frames'} for d in r['directions']],
    post_native=[{k:v for k,v in x.items() if k!='streams'} for x in r['POST']['native']]) for r in reports]
(HERE/'frame-summary.json').write_text(json.dumps(compact,indent=2)+'\n')
print(json.dumps(compact,indent=2))
