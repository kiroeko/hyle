from pathlib import Path
import hashlib,json,subprocess,zipfile,difflib
ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/terminal-drain'
OUT=Path('/root/hyle-scratch/http2-current-20261018/terminal-drain')
def rec(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(name,data):(HERE/name).write_text(json.dumps(data,indent=2)+'\n')
parsed=json.loads((HERE/'parsed-frames.json').read_text())['episodes']
manual,dual=parsed
assert manual['mode']=='manual' and dual['mode']=='endpoints'
assert len(parsed)==2
for r in parsed:assert r['result']['result']==4 and r['result']['quiescent'] and r['counts']['descriptors_closed']
for a,b in zip(manual['directions'],dual['directions']):
    assert {k:v for k,v in a['wire_bytes_by_type'].items() if k!='WINDOW_UPDATE'}=={k:v for k,v in b['wire_bytes_by_type'].items() if k!='WINDOW_UPDATE'}
assert manual['directions'][1]['bytes_after']-dual['directions'][1]['bytes_after']==65
assert manual['directions'][1]['types']['WINDOW_UPDATE']-dual['directions'][1]['types']['WINDOW_UPDATE']==5
commands=json.loads((HERE/'commands.json').read_text())
assert [x['name'] for x in commands]==['compile-main','link-consumer','loader','episode-manual','episode-endpoints']
assert all(x['exit']==0 for x in commands)
identity=json.loads((HERE/'build-identity.json').read_text())
for x in identity['files']:assert rec(Path(x['path']))['sha256']==x['sha256']
source=json.loads((HERE/'source-identity.json').read_text())
for name in ['frozen_common','generated','protocol','split_advance','canonical_peer']:
    x=source[name];assert rec(Path(x['path']))['sha256']==x['sha256']
(HERE/'source-changes.diff').write_text(''.join(difflib.unified_diff(
    Path(source['frozen_common']['path']).read_text().splitlines(keepends=True),(HERE/'main.cc').read_text().splitlines(keepends=True),
    fromfile='common-episode/main.cc',tofile='terminal-drain/main.cc')))
cleanup=[rec(p) for p in sorted(OUT.iterdir()) if p.is_file()]
assert {Path(x['path']).name for x in cleanup}=={'main.o','consumer'}
write('cleanup-candidates.json',dict(host='WSL',files=cleanup,total_bytes=sum(x['bytes'] for x in cleanup),
    note='Only thisbatch2 rebuildable artifacts. Actualwiredata are evidence, not compiledbinaries. Sharedcore/helper/dependency/foundationcache excluded. Nothing deleted.'))
summary=dict(
    result='Both raw drivers reach the same socketpair quiescence boundary after a common postjoin terminal pump. In this diagnostic episode, the65B server-to-client difference persists after that pump and consists of fiveWINDOW_UPDATE frames, rather than unflushed server-to-client bytes at exit.',
    scope=dict(head='74fc012eb1f5c6bd9795437e28c48c76f8e6d0b5',trace='Only4streams x256KiB request/response and originalwindow/reversepair',
        processes=2,untimed_episodes_per_driver=1,original_driver_algorithms_preserved=True,
        public_Hyle_HTTP2_executed=False,formal_timing=False,extra_AA_retry_or_shape=False,
        product_or_canonical_peer_changes=False),
    quiescence=dict(boundary='After all driverjoins, samecaller pump fills/writes/reads/consumes bothsides. Successfulfinalsweep has no progress, twoactualrecv EAGAIN, bothRawWire empty, nativewant_write0, completed4, no unreadbody/readableitems.',
        manual_passes=manual['result']['terminal_passes'],two_task_passes=dual['result']['terminal_passes'],
        no_new_GOAWAY_shutdown_yield_or_worker=True,
        failure_policy='Existing drivererrorhelper retained. Terminalpump adds no shutdown; idle-but-not-quiescent fails immediately, max1024passes/external20s timeout.',
        applicability='OnlyAF_UNIXsocketpair with nofuturewriter afteralljoins. Not a generalremoteTCP/TLS flushproof; want_read neednotbezero.',
        observations='Native/wire snapshots atPRE andPOST. Terminalphase has actualbyteinterval/framephase/passcount; intermediateperpass nativestates were not recorded.'),
    actual_wire=dict(manual=dict(c2s_before=1050124,c2s_after=1050137,s2c_before=1050092,s2c_after=1050092),
        two_tasks=dict(c2s_before=1050124,c2s_after=1050124,s2c_before=1050027,s2c_after=1050027),
        terminal='Manual adds one13B connectionWINDOW_UPDATE clienttoserver; twoTask adds no successfulsendbytes. Server-to-client adds0B in bothterminalphases.',
        parser='parsed-frames.json retains everyframe offset/type/stream/flags/length/WUincrement and phase, parsedoffline from actualsuccessfulsend streams. Actualrecv counts are usedonlyas conservationcheck, never duplicatedaswireframes.',
        body='Eachdirection eacharm has64DATAframes,262144bodybytes perstream1/3/5/7, oneEND_STREAM perstream,4HEADERS and2SETTINGS; noRST_STREAM/GOAWAY. Non-WU wirebyte totals match acrossarms.',
        post_frame_counts=dict(manual_c2s_WU=60,two_task_c2s_WU=59,manual_s2c_WU=64,two_task_s2c_WU=59)),
    credit=dict(application='Eacharm eachreceiver successfullycalls consume_stream andconsume_connection for1048576bodybytes. Allfourstream bodyoracles/headerrequirements/reversecompletionchecks and closedfdchecks pass.',
        native_connection=dict(manual_advertised_increment_sum=1048576,two_task_advertised_increment_sum=1023863,
            two_task_unadvertised_difference=24713,manual_post_local_window=65535,two_task_post_local_window=40822),
        interpretation='Applicationcreditcalls and nativeadvertisedcredit are distinct. nghttp2 queues/mergesupdates atwindowthresholds and suppressesstreamupdates afterEND_STREAM; a fullyconsumedbody can leave subthresholdcredit without a sendableframe.',
        sources='nghttp2_session.c5141-5192 and2677-2712, version1.70 lockedcache. Outboundqueuegetter7667 omitsstreamattacheditems; PREwant_write1/queue0 was actuallyobserved.'),
    interpretation=[
        'Thisdiagnostic identifies thedifference in thisrun only. It cannot retroactively prove whichframes made the earlier65B without oldframecapture.',
        'Equalquiescence doesnot imply identicalframegrouping/windowfrontier. ForcingequalWUcounts/increments would alterconsumptionbatching/thresholds orsubmitextracredit and change the testedpolicy.',
        'Noelapsedtime wasrecorded: theseeventcounts do notassign anypartofthe17% public-route loss toframes/Task/contextswitches.',
        'Theofficialpublic-versusmanual peer remains unchanged. Publicsessionsdieinsidetasks; scratchcaller-owned terminalpump is not transparentlyavailable throughthesamepublicfixture.',
        'Public drain() submitsGOAWAY and close() also shutsdown; neither canbe silentlyinserted as a pureflush.',
        'Generalowner/error/cancel/deadline/borrow/generation/flushedepoch duties remainpubliccontracts. No new redundantproductwork is established by thisdiagnostic.'],
    instrumentation=dict(method='Preallocatedowner-local captures, rawsendpositivebytes and validatedasyncwrite resultbytes recordedexactlyonce; no extraatomics/locks/QPC/thread. Offlinefullframeparser afterprocessesexit.',
        caveat='Instrumentationadds copies/counters and mayaffectprogresscadence. Thisis a twoepisode untimedmechanismobservation, not a latency result or distribution.'),
    validation_identity=dict(source='source-identity.json',build='build-identity.json',
        closure='Fresh1scratchmainTU; actualexistingcurrentproactoroverride/helperobjects recheckedandhashed. Otherfoundation/SDKcache retained, notwholeHEADbuild.',
        full_original_checks='Rawcallbacks validate allbodybytes, requiredmethod/path/status/contentlengthheaders, reversepairorder; originalbody/wirebuffers/socketsettings/nativeoptions and commondestruction retained.',
        no_compile_link_run_failure=True,warning='The inheritedexplicitEvent aggregateinitializer warning retained; no codechange made for it.'),
    design='../../source-review/http2-terminal-control-design.json',
    cleanup=dict(manifest='cleanup-candidates.json',files=2,bytes=sum(x['bytes'] for x in cleanup),deleted=False))
write('summary.json',summary)
archive=HERE/'source-results.zip'
members=[p for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in ('.cc','.py','.json','.txt','.diff','.bin') and p.name!='archive-record.json']
extra=[Path(source['frozen_common']['path']),Path(source['protocol']['path']),Path(source['split_advance']['path']),
       HERE.parent/'current-build-commands.json',HERE.parent.parent/'source-review/http2-terminal-control-design.json']
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in members:z.write(p,'terminal-drain/'+p.name)
    for p in extra:
        arc='common-episode/'+p.name if p.parent.name=='common-episode' else p.name
        z.write(p,arc)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
write('archive-record.json',dict(archive=rec(archive),summary=rec(HERE/'summary.json'),members=len(members)+len(extra),
    no_exe_obj_library_or_SDK=True,raw_network_byte_streams_included=True))
print(json.dumps(dict(summary=rec(HERE/'summary.json'),archive=rec(archive),members=len(members)+len(extra),
    cleanup_bytes=sum(x['bytes'] for x in cleanup)),indent=2))
