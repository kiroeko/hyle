"""Read-only post-run identity/cleanup census; never executes the consumer."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/raw-fiber'
commands = json.loads((HERE / 'commands.json').read_text())
link = next(x['argv'] for x in commands if x['name'] == 'link')
paths = {Path(x).resolve() for x in link if x.endswith(('.o', '.a'))}
for line in (HERE / 'loader.stdout.txt').read_text().splitlines():
    if 'libhyle_' in line and '=>' in line:
        paths.add(Path(line.split('=>', 1)[1].strip().split()[0]).resolve())

def identity(p):
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

metadata = dict(
    uname=platform.uname()._asdict(),
    compiler=subprocess.check_output(['g++-14', '--version'], text=True),
    cpu_model=next(x.split(':', 1)[1].strip() for x in
                   Path('/proc/cpuinfo').read_text().splitlines()
                   if x.startswith('model name')),
    link_inputs=[identity(p) for p in sorted(paths)],
    scope='Post-run read-only census. No additional consumer/test/timing run.',
)
(HERE / 'postrun-identity.json').write_text(json.dumps(metadata, indent=2) + '\n')
build = Path(next(x['cwd'] for x in commands if x['name'] == 'one-episode'))
cleanup = dict(
    directory=str(build),
    files=[identity(build / n) for n in ('main.o', 'probe.o', 'consumer')],
    action='Candidates only; no deletion performed. Keep cached foundation/nghttp2 and raw source/results.',
)
cleanup['total_bytes'] = sum(x['bytes'] for x in cleanup['files'])
(HERE / 'cleanup-candidates.json').write_text(json.dumps(cleanup, indent=2) + '\n')
print(json.dumps(dict(identity_files=len(paths), cleanup_bytes=cleanup['total_bytes'])))
