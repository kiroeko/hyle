"""Summarize the one recorded episode and pack small evidence; never run it."""
from pathlib import Path
from collections import Counter
import difflib
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
raw = json.loads((HERE / 'one-episode.stdout.txt').read_text(encoding='utf-8'))
old2path = HERE.parent / 'diagnostic-summary.json'
old2 = json.loads(old2path.read_text(encoding='utf-8'))['result']['hyle']['counts']
old5path = HERE.parent / 'yield-progress/summary.json'
old5 = json.loads(old5path.read_text(encoding='utf-8'))
hashof = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda name, data: (HERE / name).write_text(json.dumps(data, indent=2) + '\n')

eps = raw['endpoints']
now = dict(
    recv_attempts=sum(e['recv_calls'] for e in eps),
    recv_would_block=sum(e['recv_eagain'] for e in eps),
    recv_ready=sum(e['recv_calls'] - e['recv_eagain'] for e in eps),
    recv_bytes=sum(e['received'] for e in eps),
    send_attempts=sum(e['send_calls'] for e in eps),
    send_would_block=sum(e['send_eagain'] for e in eps),
    send_ready=sum(e['send_calls'] - e['send_eagain'] for e in eps),
    send_bytes=sum(e['sent'] for e in eps),
    async_read=sum(e['async_reads'] for e in eps),
    async_write=sum(e['async_writes'] for e in eps),
    async_read_bytes=sum(e['async_received'] for e in eps),
    async_write_bytes=sum(e['async_sent'] for e in eps),
    process_received=sum(e['mem_recv_calls'] for e in eps),
    nonempty_mem_send=sum(e['mem_send_calls'] - e['mem_send_zero'] for e in eps),
    body_ack_calls=sum(e['consumes'] for e in eps),
    body_ack_bytes=sum(e['consumed_bytes'] for e in eps),
)
transitions = [dict(sequence=i + 1, **x)
               for i, x in enumerate(raw['dispatches'])
               if x['owner_before'] != x['owner_after']]
kind_names = ['entry', 'session-ready', 'request-submitted', 'response-submitted',
              'body-validated', 'before-yield', 'after-yield', 'before-read',
              'after-read', 'before-write', 'after-write', 'before-event',
              'after-event', 'session-destroyed', 'socket-closed', 'failure']
phase_table = {str(i): name for i, name in enumerate(kind_names)}
write('phase-legend.json', phase_table)
write('prior-counts.json', dict(
    stage2_path=str(old2path.relative_to(ROOT)), stage2_sha256=hashof(old2path),
    hyle_counts=old2,
    stage5_path=str(old5path.relative_to(ROOT)), stage5_sha256=hashof(old5path),
    hyle_stage5_evidence=old5['evidence'],
    limitation='Previous separate diagnostic episodes, not simultaneous arms. Stage2 used read/write before the matched send/recv change; not a cost subtraction.',
))

source_ranges = {
    'include/hyle/io/detail/net_budget.h': [(43, 58)],
    'src/sched/scheduler.cc': [(2260, 2271), (2293, 2300)],
    'src/sched/sync.cc': [(294, 315)],
    'src/io_core/tcp.cc': [(44, 53), (448, 465)],
    'src/sched/fiber_access.h': [(1, 50)],
}
excerpts = []
for rel, ranges in source_ranges.items():
    p = ROOT / rel
    lines = p.read_text(encoding='utf-8').splitlines()
    excerpts.append(dict(path=rel, sha256=hashof(p),
                         sections=[dict(first=a, last=b,
                                        text='\n'.join(lines[a-1:b]))
                                   for a, b in ranges]))
write('source-excerpts.json', excerpts)
(HERE / 'formal-to-probe.diff').write_text(''.join(difflib.unified_diff(
    (HERE / 'formal-input.cc').read_text(encoding='utf-8').splitlines(True),
    (HERE / 'diag_bench.cc').read_text(encoding='utf-8').splitlines(True),
    fromfile='formal-input.cc', tofile='diag_bench.cc')))
write('postrun-commands.json', [dict(
    argv=['wsl.exe', '--exec', 'python3',
          '/mnt/c/public/project-hyle/hyle/.scratch/perf-review-2026-10-18/http2/raw-fiber/collect.py'],
    cwd='C:/public/project-hyle/hyle', exit=0,
    scope='Post-run metadata/file hash/cleanup census only; no consumer invocation.'
)])

summary = dict(
    result='One raw-nghttp2 two-Hyle-fiber non-timed 4x256KiB full episode passes. Resume/yield and complete wire totals match the separate stage5 Hyle episode. Compared with stage2, successful immediate call counts match, receive bytes differ by9B, and194 more empty immediate IO attempts occur. This is supplementary execution-model evidence, not a pure scheduler cost measurement and not a new ranking.',
    scope=dict(runtime_invocations=1, runtime_exit=0, timed=False,
               workload='4 streams, 256KiB request and 256KiB response per stream, paired responses completed in reverse order',
               command=['timeout', '--kill-after=2s', '15s', 'taskset', '-c', '2',
                        '/root/hyle-scratch/http2-current-20261018/raw-fiber/consumer'],
               compiled='Only scratch main/probe TUs; cached HTTP/HTTP2/feature/nanobench/pico/nghttp2/foundation reused.',
               product='No product or formal benchmark source changed. No AB/AA/timing/profiler/foundation build/SDK download.'),
    checks=dict(completed=raw['completed'], passed=raw['checks_passed'],
                descriptors_closed=raw['descriptors_closed'], overflow=raw['overflow'],
                body_validation_each_direction=4, body_bytes_each_direction=1048576,
                request_stream_ids=[p['arg'] for p in raw['phases'] if p['kind'] == 2],
                response_submit_order=[p['arg'] for p in raw['phases'] if p['kind'] == 3],
                client_completed_order=[p['arg'] for p in raw['phases'] if p['kind'] == 4 and p['role'] == 0],
                sessions_destroyed=2, sockets_closed=2,
                client_to_server_bytes=eps[0]['sent'] + eps[0]['async_sent'],
                server_to_client_bytes=eps[1]['sent'] + eps[1]['async_sent']),
    scheduling=dict(
        dispatches=raw['dispatch_count'], yields=sum(e['yields'] for e in eps),
        dispatches_by_endpoint=[sum(x['fiber'] == e['fiber'] for x in raw['dispatches']) for e in eps],
        current_workers=sorted({x['worker'] for x in raw['dispatches']}),
        ordinary_owner='-1 at entry and every before/after ordinary IO and adaptive-yield phase',
        dispatch_owner_tuples=[dict(worker=w, before=b, after=a, count=n)
                               for (w, b, a), n in Counter((x['worker'], x['owner_before'], x['owner_after'])
                                                          for x in raw['dispatches']).items()],
        owner_transitions=transitions,
        explanation='spawn_task creates initially unowned fibers. Ordinary TCP awaitables current_waker/submit/suspend do not pin. The server tail Event::wait_for uses timed ConditionVariable temporary pin, observed -1->0 at dispatch518 and 0->-1 at dispatch520. Actual worker is0 throughout; no forced spawn_task_on.',
        phase_count=raw['phase_count'],
        interposition=dict(original=raw['original_resume_image'], executable=raw['interposed_resume_image'],
                           evidence='readelf symbol export and runtime dladdr distinct original/executable images; fixed arrays written by the single worker, read after harness shutdown.')),
    current_counts=now,
    prior_hyle_comparison=dict(
        reference='prior-counts.json and existing stage2/stage5 raw archives; separate non-timed episodes',
        stage2_same='323 successful immediate reads and514 writes; immediate send2092087B; one async read and one async write;264 body consumes/2097152B.',
        stage2_receive_distribution='Current immediate recv2091981B versus stage2 Hyle2091990B: current is9B lower. Successful immediate read call count is the same, but byte distribution is not identical.',
        stage2_async_limit='Current async read8170B and write8064B are recorded for this episode only. Stage2 did not record async byte totals, so byte equality with stage2 is not established.',
        stage5_same='The separate stage5 Hyle episode records520 resumes/515 yields and full wire1050124B client-to-server/1050027B server-to-client, matching this episode. These full totals must not be combined with stage2 immediate counts to invent a single prior episode.',
        extra_recv_eagain=now['recv_would_block'] - old2['recv_would_block'],
        extra_send_eagain=now['send_would_block'] - old2['send_would_block'],
        extra_empty_attempts=(now['recv_attempts'] + now['send_attempts']
                              - old2['recv_attempts'] - old2['send_attempts']),
        consequence='The split raw driver is not operation-for-operation the Hyle transport. The unchanged wire/dispatch counts do not permit subtracting latency or assigning the formal residual to scheduler/framework.'),
    retained_boundaries=[
        'Original raw protocol callbacks, status/headers/payload oracle,16KiB stream+connection consumption, paired reverse response rules and send/recv flags retained.',
        'Both endpoint drivers use the original HyleHarness one-worker IoContext and spawn_task; inactive persistent RawHarness also constructed as in the original benchmark.',
        'RawWire owns128KiB per endpoint outside the64KiB fiber stacks, Episode and native userdata live through both joins; reserved4 stream slots prevent pointer relocation.',
        'Server waits only after last pair first response was submitted, its body provider is done and the endpoint pending wire is empty. Client signals after final response payload validation.',
        'Endpoint cleanup destroys native session then resets TcpStream on its worker before returning. TcpStream move assignment calls synchronous ::close on Linux, so post-join fcntl EBADF does not depend on later IoContext drain.',
        'Independent read-only review found no definite protocol/completion/owner-lifetime bug. No additional runtime was requested or executed.',
    ],
    limits=[
        'No durations or cost weights collected. Formal manual-loop peer remains the real comparator; its existing13-15% matched large-body loss is still unresolved.',
        'Single episode with probe array writes/interposition perturbs scheduling; no fresh live thread/worker resource census and no universal runtime guarantee.',
        'Driver is separately implemented from the Hyle protocol transport and has194 additional EAGAIN attempts; changes in syscall/codec/lifecycle work prevent pure scheduler attribution.',
        'No claim that all yields are necessary, negligible, or account for any percentage. No cancellation/fairness/readiness/owner/completion responsibility removed.',
        'Compiler emitted an explicit-default-Event aggregate initialization warning; exact stderr retained. No compile/link/consumer-run failure in this branch. Two post-run packaging attempts stopped on repository-parent/Windows text-decoding issues; corrected only pack.py, with no consumer rerun.',
    ],
    next='Stop this diagnostic. If parent chooses further work, use these phase/IO-count boundaries to design an explicitly authorized attribution step rather than repeating noisy AB runs or replacing the formal peer.',
    identity='identity.json,postrun-identity.json,commands.json,loader.stdout.txt,symbols.stdout.txt',
    cleanup='cleanup-candidates.json: only3 new WSL object/executable files,1634936B; no deletion performed.',
)
write('summary.json', summary)

out = HERE / 'source-results.zip'
files = sorted(p for p in HERE.iterdir() if p.is_file() and p.name not in
               ('source-results.zip', 'archive-record.json'))
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, p.name)
write('archive-record.json', dict(path=str(out.relative_to(ROOT)), bytes=out.stat().st_size,
                                 sha256=hashof(out), files=len(files),
                                 scope='Small sources/commands/raw stdout/stderr/identities/summary only; no executable/object/SDK/native binaries.'))
print((HERE / 'archive-record.json').read_text(encoding='utf-8'))
