#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <sys/types.h>
#include <nghttp2/nghttp2.h>

namespace raw_probe {
constexpr std::size_t kCapacity=4096;
enum class Phase : unsigned { Entry, SessionReady, RequestSubmitted,
  ResponseSubmitted, BodyValidated, BeforeYield, AfterYield, BeforeRead,
  AfterRead, BeforeWrite, AfterWrite, BeforeEvent, AfterEvent,
  SessionDestroyed, SocketClosed, Failure };
struct Endpoint {
  void* endpoint=nullptr;void* fiber=nullptr;int fd=-1;
  std::uint64_t send_calls=0,recv_calls=0,send_eagain=0,recv_eagain=0;
  std::uint64_t sent=0,received=0,async_sent=0,async_received=0;
  std::uint64_t async_writes=0,async_reads=0,yields=0;
  std::uint64_t mem_send_calls=0,mem_send_zero=0,mem_send_bytes=0;
  std::uint64_t mem_recv_calls=0,mem_recv_bytes=0,consumes=0,consumed_bytes=0;
  std::uint64_t requests=0,responses=0,validated=0,destroyed=0,closed=0;
};
struct Record {
  unsigned role=0;Phase phase{};int worker=-1,owner=-99;void* fiber=nullptr;
  std::int64_t arg=0;std::uint64_t sent=0,received=0;
};
struct Dispatch {void* fiber=nullptr;int worker=-1,before=-99,after=-99;};
extern std::array<Endpoint,2> endpoints;
extern std::array<Record,kCapacity> phases;
extern std::array<Dispatch,kCapacity> dispatches;
extern std::uint64_t phase_count,dispatch_count,overflow;
extern const char* original_image;
extern const char* interposed_image;
bool initialize() noexcept;
unsigned role(void*) noexcept;
void record(unsigned,Phase,std::int64_t=0) noexcept;
void body(void*,std::size_t) noexcept;
ssize_t send(int,const void*,std::size_t,int) noexcept;
ssize_t recv(int,void*,std::size_t,int) noexcept;
nghttp2_ssize mem_send(nghttp2_session*,const std::uint8_t**);
nghttp2_ssize mem_recv(nghttp2_session*,const std::uint8_t*,std::size_t);
}
