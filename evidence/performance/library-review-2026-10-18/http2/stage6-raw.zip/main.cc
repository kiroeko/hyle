#define main original_benchmark_main
#include "diag_bench.cc"
#undef main
#include "split_advance.h"
#include "probe.h"

namespace {
struct Episode {
  const Workload& workload;
  std::array<RawEndpoint,2> endpoint;
  std::array<RawWire,2> wire;
  hyle::sched::Event client_consumed;
  bool failed=false;
};
bool server_flushed(const RawEndpoint& e,const RawWire& w) noexcept {
  const auto n=static_cast<std::size_t>(e.workload->streams);
  return e.streams.size()==n && e.next_response_pair==n &&
      e.streams[n-2].output_done && w.begin==w.end;
}
struct EndpointCleanup {
  Episode& episode;unsigned role;TcpStream& socket;bool success=false;
  ~EndpointCleanup() {
    auto& e=episode.endpoint[role];
    if(!success){e.failed=true;episode.failed=true;episode.client_consumed.signal();raw_probe::record(role,raw_probe::Phase::Failure);}
    if(e.session){nghttp2_session_del(e.session);e.session=nullptr;++raw_probe::endpoints[role].destroyed;raw_probe::record(role,raw_probe::Phase::SessionDestroyed);}
    socket=TcpStream{};++raw_probe::endpoints[role].closed;raw_probe::record(role,raw_probe::Phase::SocketClosed);
  }
};
bool feed_async(RawEndpoint& e,RawWire& w,hyle::io::TransferResult result) noexcept {
  if(!result.ok()||result.eof||result.bytes==0||result.bytes>w.input.size())return false;
  if(raw_probe::mem_recv(e.session,w.input.data(),result.bytes)!=static_cast<nghttp2_ssize>(result.bytes))return false;
  bool consumed=false;return raw_consume_readable(e,consumed);
}
Task<int> raw_endpoint(AllocatorRef,TcpStream socket,Episode* episode,unsigned role) noexcept {
  using raw_probe::Phase;auto& e=episode->endpoint[role];auto& w=episode->wire[role];auto& counters=raw_probe::endpoints[role];
  counters.fiber=hyle::sched::Fiber::current();raw_probe::record(role,Phase::Entry);
  EndpointCleanup cleanup{*episode,role,socket};
  if(!raw_initialize(e))co_return -1;
  raw_probe::record(role,Phase::SessionReady);
  for(;;) {
    if(episode->failed||e.failed)co_return -1;
    if(role==0&&e.completed==episode->workload.streams) {
      episode->client_consumed.signal();cleanup.success=true;co_return episode->workload.streams;
    }
    if(role==1&&server_flushed(e,w)) {
      raw_probe::record(role,Phase::BeforeEvent);
      const bool done=episode->client_consumed.wait_for(std::chrono::seconds(5));
      raw_probe::record(role,Phase::AfterEvent,done);
      if(!done||episode->failed||e.completed!=episode->workload.streams)co_return -1;
      cleanup.success=true;co_return episode->workload.streams;
    }
    if(!(role==0?advance_client(e,w):advance_server(e,w))||!raw_fill_output(e,w))co_return -1;
    bool written=false;
    if(!raw_write(w,written))co_return -1;
    if(role==1&&server_flushed(e,w))continue;
    bool progress=false;
    if(!raw_read(e,w,progress)||!raw_consume_readable(e,progress))co_return -1;
    if(progress||(written&&w.begin==w.end))continue;

    // Same bounded handoff as Hyle: read before parking a blocked writer,
    // yield once, then retry read before retrying write / awaiting readiness.
    ++counters.yields;raw_probe::record(role,Phase::BeforeYield,w.begin!=w.end);
    hyle::sched::Fiber::yield();raw_probe::record(role,Phase::AfterYield);
    if(episode->failed)co_return -1;
    progress=false;
    if(!raw_read(e,w,progress)||!raw_consume_readable(e,progress))co_return -1;
    if(progress)continue;
    if(w.begin!=w.end) {
      written=false;if(!raw_write(w,written))co_return -1;
      if(written)continue;
      ++counters.async_writes;raw_probe::record(role,Phase::BeforeWrite,w.end-w.begin);
      const auto result=co_await socket.write_some(
          std::span<const std::byte>(reinterpret_cast<const std::byte*>(w.pending.data()+w.begin),w.end-w.begin),hyle::io::OperationOptions{});
      raw_probe::record(role,Phase::AfterWrite,static_cast<std::int64_t>(result.bytes));
      if(!result.ok()||result.bytes==0||result.bytes>w.end-w.begin)co_return -1;
      counters.async_sent+=result.bytes;w.begin+=result.bytes;
      if(w.begin==w.end)w.begin=w.end=0;
    } else {
      ++counters.async_reads;raw_probe::record(role,Phase::BeforeRead,w.input.size());
      const auto result=co_await socket.read_some(
          std::span<std::byte>(reinterpret_cast<std::byte*>(w.input.data()),w.input.size()),hyle::io::OperationOptions{});
      raw_probe::record(role,Phase::AfterRead,static_cast<std::int64_t>(result.bytes));
      if(result.bytes<=w.input.size())counters.async_received+=result.bytes;
      if(!feed_async(e,w,result))co_return -1;
    }
  }
}
int run_raw_fibers(HyleHarness& h,const Workload& workload,bool& descriptors_closed) {
  auto pair=make_socket_pair();if(!pair.valid())return -1;
  auto client=TcpStream::adopt(h.diagnostic_io(),kOwner,pair.release_client());
  auto server=TcpStream::adopt(h.diagnostic_io(),kOwner,pair.release_server());
  if(!client||!server)return -1;
  // RawWire owns128KiB per endpoint. Keep it outside the64KiB fiber stacks.
  Episode episode{workload};
  for(unsigned role=0;role<2;++role){episode.endpoint[role].workload=&workload;episode.endpoint[role].server=role==1;episode.endpoint[role].streams.reserve(workload.streams);}
  episode.wire[0].descriptor=static_cast<int>(client->native_handle());episode.wire[1].descriptor=static_cast<int>(server->native_handle());
  for(unsigned role=0;role<2;++role){raw_probe::endpoints[role].endpoint=&episode.endpoint[role];raw_probe::endpoints[role].fd=episode.wire[role].descriptor;}
  auto server_join=hyle::sched::spawn_task(h.diagnostic_scheduler(),system_allocator(),raw_endpoint(system_allocator(),std::move(*server),&episode,1));
  auto client_join=hyle::sched::spawn_task(h.diagnostic_scheduler(),system_allocator(),raw_endpoint(system_allocator(),std::move(*client),&episode,0));
  auto client_result=client_join.join();auto server_result=server_join.join();
  descriptors_closed=true;
  for(const auto& w:episode.wire){errno=0;descriptors_closed&=::fcntl(w.descriptor,F_GETFD)==-1&&errno==EBADF;}
  return !episode.failed&&client_result&&server_result&&*client_result==workload.streams&&*server_result==workload.streams?workload.streams:-1;
}
}

int main() {
  using namespace raw_probe;std::signal(SIGPIPE,SIG_IGN);if(!initialize())return 2;
  const auto workload=make_workload("raw two-fiber non-timed diagnostic",4,256*1024,256*1024,NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  int completed=-1;bool descriptors_closed=false;
  {HyleHarness hyle;RawHarness inactive_manual_peer;completed=run_raw_fibers(hyle,workload,descriptors_closed);}
  bool valid=completed==4&&descriptors_closed&&overflow==0&&dispatch_count>2&&endpoints[0].fiber&&endpoints[1].fiber&&endpoints[0].fiber!=endpoints[1].fiber;
  for(unsigned i=0;i<2;++i){const auto& e=endpoints[i];const auto& peer=endpoints[i^1];valid&=e.sent+e.async_sent==peer.received+peer.async_received&&e.consumed_bytes==1048576&&e.validated==4&&e.destroyed==1&&e.closed==1;}
  for(std::uint64_t i=0;i<phase_count&&i<phases.size();++i)valid&=phases[i].worker==0&&(phases[i].owner==-1||phases[i].owner==0);
  std::printf("{\"completed\":%d,\"checks_passed\":%s,\"descriptors_closed\":%s,\"overflow\":%llu,\"dispatch_count\":%llu,\"phase_count\":%llu,\"original_resume_image\":\"%s\",\"interposed_resume_image\":\"%s\",\"endpoints\":[",completed,valid?"true":"false",descriptors_closed?"true":"false",(unsigned long long)overflow,(unsigned long long)dispatch_count,(unsigned long long)phase_count,original_image,interposed_image);
  for(unsigned i=0;i<2;++i){const auto& e=endpoints[i];std::printf("%s{\"role\":%u,\"fiber\":\"%p\",\"fd\":%d",i?",":"",i,e.fiber,e.fd);
#define PRINT_FIELD(f) std::printf(",\"" #f "\":%llu",(unsigned long long)e.f)
    PRINT_FIELD(send_calls);PRINT_FIELD(recv_calls);PRINT_FIELD(send_eagain);PRINT_FIELD(recv_eagain);PRINT_FIELD(sent);PRINT_FIELD(received);PRINT_FIELD(async_sent);PRINT_FIELD(async_received);PRINT_FIELD(async_writes);PRINT_FIELD(async_reads);PRINT_FIELD(yields);PRINT_FIELD(mem_send_calls);PRINT_FIELD(mem_send_zero);PRINT_FIELD(mem_send_bytes);PRINT_FIELD(mem_recv_calls);PRINT_FIELD(mem_recv_bytes);PRINT_FIELD(consumes);PRINT_FIELD(consumed_bytes);PRINT_FIELD(requests);PRINT_FIELD(responses);PRINT_FIELD(validated);PRINT_FIELD(destroyed);PRINT_FIELD(closed);
#undef PRINT_FIELD
    std::printf("}");}
  std::printf("],\"phases\":[");for(std::uint64_t i=0;i<phase_count&&i<phases.size();++i){const auto& p=phases[i];std::printf("%s{\"role\":%u,\"kind\":%u,\"worker\":%d,\"owner\":%d,\"fiber\":\"%p\",\"arg\":%lld,\"sent\":%llu,\"received\":%llu}",i?",":"",p.role,(unsigned)p.phase,p.worker,p.owner,p.fiber,(long long)p.arg,(unsigned long long)p.sent,(unsigned long long)p.received);}
  std::printf("],\"dispatches\":[");for(std::uint64_t i=0;i<dispatch_count&&i<dispatches.size();++i){const auto& d=dispatches[i];std::printf("%s{\"fiber\":\"%p\",\"worker\":%d,\"owner_before\":%d,\"owner_after\":%d}",i?",":"",d.fiber,d.worker,d.before,d.after);}std::printf("]}\n");
  return valid?0:3;
}
