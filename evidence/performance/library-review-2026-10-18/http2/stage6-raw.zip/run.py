from pathlib import Path
import hashlib,json,os,subprocess

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/raw-fiber'
BASE=Path('/root/hyle-scratch/http2-current-20261018')
BUILD=BASE/'raw-fiber';BUILD.mkdir(exist_ok=True)
old=json.loads((HERE.parent/'build-commands.json').read_text())
records=[]
def replace(text,before,after):
 assert text.count(before)==1,(before,text.count(before))
 return text.replace(before,after,1)
original=(ROOT/'bench/io_http2/http2_p1_bench.cc').read_text()
(HERE/'formal-input.cc').write_text(original)
b=replace(original,'#include "hyle/io/http2.h"','#include "hyle/io/http2.h"\n#include "probe.h"')
b=replace(b,'  ~HyleHarness() { scheduler_.shutdown(); }','  ~HyleHarness() { scheduler_.shutdown(); }\n  Scheduler& diagnostic_scheduler() noexcept { return scheduler_; }\n  IoContext& diagnostic_io() noexcept { return io_; }')
b=replace(b,'::send(','raw_probe::send(')
b=replace(b,'::recv(','raw_probe::recv(')
b=replace(b,'nghttp2_session_mem_send2(','raw_probe::mem_send(')
b=replace(b,'nghttp2_session_mem_recv2(','raw_probe::mem_recv(')
b=replace(b,'  stream.response_submitted = true;','  stream.response_submitted = true;\n  ++raw_probe::endpoints[raw_probe::role(&endpoint)].responses;\n  raw_probe::record(raw_probe::role(&endpoint),raw_probe::Phase::ResponseSubmitted,stream.id);')
b=replace(b,'  stream.id = id;\n  return true;','  stream.id = id;\n  ++raw_probe::endpoints[raw_probe::role(&endpoint)].requests;\n  raw_probe::record(raw_probe::role(&endpoint),raw_probe::Phase::RequestSubmitted,id);\n  return true;')
b=replace(b,'  ++endpoint.completed;','  ++endpoint.completed;\n  ++raw_probe::endpoints[raw_probe::role(&endpoint)].validated;\n  raw_probe::record(raw_probe::role(&endpoint),raw_probe::Phase::BodyValidated,stream.id);')
b=replace(b,'      stream.received += count;','      stream.received += count;\n      raw_probe::body(&endpoint,count);')
(HERE/'diag_bench.cc').write_text(b)
start=original.index('bool raw_advance(')
first=original.index('  if (client.streams.empty())',start)
second=original.index('  // Submitted pairs',first)
end=original.index('\n}\n\nint run_raw',second)
(HERE/'split_advance.h').write_text('bool advance_client(RawEndpoint& client,const RawWire& client_wire) noexcept {\n'+original[first:second]+'  return true;\n}\n\nbool advance_server(RawEndpoint& server,const RawWire& server_wire) noexcept {\n'+original[second:end]+'\n}\n')

def run(name,argv,env=None,timeout=60):
 argv=list(map(str,argv));p=subprocess.run(argv,cwd=BUILD,env=env,capture_output=True,text=True,timeout=timeout)
 (HERE/(name+'.stdout.txt')).write_text(p.stdout);(HERE/(name+'.stderr.txt')).write_text(p.stderr)
 records.append(dict(name=name,argv=argv,cwd=str(BUILD),exit=p.returncode));(HERE/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,p.returncode,flush=True)
 if p.returncode:
  print(p.stdout[-1800:]);print(p.stderr[-1800:]);raise SystemExit(p.returncode)
 return p.stdout

command=next(x['argv'] for x in old if x['name']=='bench_io_http2_http2_p1_bench.cc')
for name in ['main','probe']:
 run('compile-'+name,command[:-4]+['-I'+str(HERE),'-I'+str(ROOT/'src/sched'),'-c',HERE/(name+'.cc'),'-o',BUILD/(name+'.o')])
link=next(x['argv'] for x in old if x['name']=='link')
link=[str(BUILD/'consumer') if x.endswith('/http2_current') else str(BUILD/'main.o') if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
link += [str(BUILD/'probe.o'),'-ldl','-Wl,--export-dynamic-symbol=_ZN4hyle5sched5Fiber6resumeEv']
run('link',link)
symbols=run('symbols',['readelf','-Ws',BUILD/'consumer'])
assert any('_ZN4hyle5sched5Fiber6resumeEv' in line and 'GLOBAL DEFAULT' in line for line in symbols.splitlines())
run('loader',['ldd',BUILD/'consumer'])
env={k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_'))}
# The single allowed runtime episode; timeout is process-level only and does not
# add per-transfer timers/cancellation allocations to either endpoint.
output=run('one-episode',['timeout','--kill-after=2s','15s','taskset','-c','2',BUILD/'consumer'],env,timeout=20)
data=json.loads(output)
assert data['checks_passed'] and data['completed']==4 and data['overflow']==0
paths=[ROOT/'bench/io_http2/http2_p1_bench.cc',ROOT/'src/sched/fiber_access.h',ROOT/'include/hyle/sched/fiber.h',HERE/'formal-input.cc',HERE/'diag_bench.cc',HERE/'split_advance.h',HERE/'main.cc',HERE/'probe.cc',HERE/'probe.h',HERE/'run.py',BUILD/'consumer',Path('/root/hyle-scratch/io-watch-v2-dev/bin/libhyle_sched.so.0.1.0'),Path('/root/hyle-scratch/io-watch-v2-dev/bin/libhyle_io_core.so.0.1.0'),BASE/'nghttp2-build/lib/libnghttp2.a']
(HERE/'identity.json').write_text(json.dumps({'files':[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths],'scope':'One non-timed raw two-fiber episode; original HyleHarness and inactive RawHarness preserved; current spawn_task; no foundation/SDK rebuild.'},indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in ['phases','dispatches']},indent=2))
