#pragma once
#include <array>
#include <cstddef>
#include <cstdint>

namespace yield_progress {
struct Endpoint {
  void* fiber = nullptr;
  void* session = nullptr;
  std::uint64_t recv_bytes = 0;
  std::uint64_t send_bytes = 0;
};
struct Yield {
  void* self = nullptr;
  std::uint64_t kind = 0; // 0 write, 1 read
  std::uint64_t first_dispatch = 0;
  std::uint64_t resumed_dispatch = 0;
  std::uint64_t peer_recv_before = 0;
  std::uint64_t peer_recv_after = 0;
  std::uint64_t peer_send_before = 0;
  std::uint64_t peer_send_after = 0;
};
constexpr std::size_t kMaxRecords = 2048;
extern std::array<Endpoint, 2> endpoints; // 0 client, 1 server
extern std::array<void*, kMaxRecords> dispatches;
extern std::array<Yield, kMaxRecords> yields;
extern std::uint64_t dispatch_count;
extern std::uint64_t yield_count;
extern std::uint64_t overflow_count;
extern void* original_resume_address;
extern void* default_resume_address;
extern const char* original_resume_image;
extern const char* default_resume_image;
bool initialize() noexcept;
void set_role(unsigned role) noexcept;
void io(void* session, bool receive, std::size_t bytes) noexcept;
void yield(unsigned kind, void* session) noexcept;
} // namespace yield_progress
