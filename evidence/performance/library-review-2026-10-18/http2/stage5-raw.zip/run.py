from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/yield-progress'
BASE = Path('/root/hyle-scratch/http2-current-20261018')
BUILD = BASE / 'yield-progress'
BUILD.mkdir(exist_ok=True)
old = json.loads((HERE.parent / 'build-commands.json').read_text())
resume = '--resume' in sys.argv
records = json.loads((HERE / 'commands.json').read_text()) if resume else []

def replace(text, before, after, count=1):
    assert text.count(before) == count, (before, text.count(before))
    return text.replace(before, after)

s = (ROOT / 'src/io_http2/http2.cc').read_text()
s = replace(s, '#include "hyle/io/http2.h"', '#include "hyle/io/http2.h"\n#include "probe_state.h"')
s = replace(s, '  if (received.bytes != 0) {', '  if (received.bytes != 0) {\n    yield_progress::io(&state, true, received.bytes);')
s = replace(s, '    state.wire_offset += sent.bytes;', '    yield_progress::io(&state, false, sent.bytes);\n    state.wire_offset += sent.bytes;')
pos = s.index('template <class Ready>')
head, tail = s[:pos], s[pos:]
head = replace(head, '      sched::Fiber::yield();', '      yield_progress::yield(0, &state);')
tail = replace(tail, '      sched::Fiber::yield();', '      yield_progress::yield(1, &state);')
if resume:
    assert (HERE / 'diag_http2.cc').read_text() == head + tail
else:
    (HERE / 'diag_http2.cc').write_text(head + tail)
b = (ROOT / 'bench/io_http2/http2_p1_bench.cc').read_text()
for name, role in [('hyle_server', 1), ('hyle_client', 0)]:
    start = b.index('Task<int> ' + name + '(')
    pos = b.index('  const Workload *workload = run->workload;', start)
    b = b[:pos] + '  yield_progress::set_role(' + str(role) + ');\n' + b[pos:]
if resume:
    assert (HERE / 'diag_bench.cc').read_text() == '#include "probe_state.h"\n' + b
else:
    (HERE / 'diag_bench.cc').write_text('#include "probe_state.h"\n' + b)

def run(name, argv, env=None):
    p = subprocess.run([str(x) for x in argv], cwd=BUILD, env=env, capture_output=True, text=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_text(p.stdout)
    (HERE / (name + '.stderr.txt')).write_text(p.stderr)
    records.append(dict(name=name, argv=[str(x) for x in argv], exit=p.returncode))
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, p.returncode, flush=True)
    if p.returncode:
        print(p.stderr[-5000:])
        raise SystemExit(p.returncode)
    return p.stdout

# Read-only binding evidence; do not rebuild the scheduler/fiber foundation.
sched = Path('/root/hyle-scratch/io-watch-v2-dev/bin/libhyle_sched.so.0.1.0')
assembly = (HERE / 'cached-scheduler-disassembly.stdout.txt').read_text() if resume else run('cached-scheduler-disassembly', ['objdump', '-dC', sched])
plt_calls = [line.strip() for line in assembly.splitlines() if 'call' in line and '<hyle::sched::Fiber::resume()@plt>' in line]
assert plt_calls
(HERE / 'plt-calls.json').write_text(json.dumps(plt_calls, indent=2) + '\n')

for key, source, dest in [
    ('src_io_http2_http2.cc', HERE / 'diag_http2.cc', BUILD / 'http2.o'),
    ('bench_io_http2_http2_p1_bench.cc', HERE / 'main.cc', BUILD / 'main.o'),
    ('bench_io_http2_http2_p1_bench.cc', HERE / 'probe_state.cc', BUILD / 'probe_state.o'),
]:
    if resume and dest.name != 'probe_state.o':
        continue
    cmd = next(x['argv'] for x in old if x['name'] == key)
    run('compile-' + dest.stem + ('-resume' if resume else ''), cmd[:-4] + ['-I' + str(HERE), '-c', source, '-o', dest])
link = next(x['argv'] for x in old if x['name'] == 'link')
link = [str(BUILD / 'consumer') if x.endswith('/http2_current') else
        str(BUILD / 'http2.o') if x.endswith('/src_io_http2_http2.cc.o') else
        str(BUILD / 'main.o') if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
link += [str(BUILD / 'probe_state.o'), '-ldl', '-Wl,--export-dynamic-symbol=_ZN4hyle5sched5Fiber6resumeEv']
run('link', link)
symbols = run('executable-symbols', ['readelf', '-Ws', BUILD / 'consumer'])
assert any('_ZN4hyle5sched5Fiber6resumeEv' in line and 'GLOBAL DEFAULT' in line for line in symbols.splitlines())
env = {k: v for k, v in os.environ.items() if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_'))}
# The only runtime invocation: one full Hyle holdout, no profiler or timed loop.
output = run('one-episode', ['taskset', '-c', '2', BUILD / 'consumer'], env)
data = json.loads(output)
assert data['completed'] == 4 and data['counter_checks_passed'] and data['overflow_count'] == 0
assert data['resume_interposition']['dispatch_calls'] > 2
assert 'libhyle_sched.so' in data['resume_interposition']['original_image']
assert data['resume_interposition']['executable_image'].endswith('/consumer')
for group in data['yield_categories']:
    assert group['total'] == group['direct_same_fiber'] + group['with_peer_dispatch']
    assert group['total'] == group['with_peer_io'] + group['without_peer_io']
    assert group['unknown_dispatches'] == 0
paths = [ROOT / 'src/io_http2/http2.cc', ROOT / 'bench/io_http2/http2_p1_bench.cc',
         HERE / 'diag_http2.cc', HERE / 'diag_bench.cc', HERE / 'main.cc',
         HERE / 'probe_state.h', HERE / 'probe_state.cc', HERE / 'run.py',
         sched, Path('/root/hyle-scratch/io-watch-v2-dev/bin/libhyle_io_core.so.0.1.0'), BUILD / 'consumer']
identity = dict(scope='One non-timed full matched Hyle holdout; executable resume interposition, original cached scheduler/fiber unchanged. No atomics, QPC, extra worker, extra yield, queue/protocol change or product edit. dlsym only before harness creation. Counters are written only by the Hyle owner worker and read after existing harness destructors join all workers.', files=[dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths], configured_affinity='taskset CPU2, inherited by both persistent harness workers; no new live affinity census.', limitations='Fixed dispatch/yield arrays2048. Successful IO counters include both immediate and asynchronous paths at process_received and sent-byte accounting. No timing per turn, no syscall/kernel/idle-work cost, no assertion that no peer IO means unnecessary yield. Original and cached source identity limitations still apply.')
(HERE / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps({k: v for k, v in data.items() if k not in ['dispatches', 'raw_yields']}, indent=2))
