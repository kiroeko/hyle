from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/yield-progress'
BUILD = Path('/root/hyle-scratch/http2-current-20261018/yield-progress')
data = json.loads((HERE / 'one-episode.stdout.txt').read_text())
assert data['completed'] == 4 and data['counter_checks_passed']
assert data['endpoints'][0]['send_bytes'] == data['endpoints'][1]['recv_bytes']
assert data['endpoints'][1]['send_bytes'] == data['endpoints'][0]['recv_bytes']
dispatches = data['dispatches']
yields = data['raw_yields']
firsts = {fiber: dispatches.index(fiber) + 1 for fiber in set(dispatches)}
covered = set(firsts.values()) | {y['resumed_dispatch'] for y in yields}
other_resumes = [i for i in range(1, len(dispatches) + 1) if i not in covered]
direct = [y for y in yields if y['resumed_dispatch'] == y['first_dispatch'] + 1]
assert len(direct) == 2
assert sum(c['with_peer_io'] for c in data['yield_categories']) == 513
assert sum(c['total'] for c in data['yield_categories']) == 515
symbols = (HERE / 'executable-symbols.stdout.txt').read_text()
(HERE / 'resume-symbols.txt').write_text('\n'.join(line for line in symbols.splitlines() if '_ZN4hyle5sched5Fiber6resumeEv' in line) + '\n')
for entry in json.loads((HERE / 'identity.json').read_text())['files']:
    path = Path(entry['path'])
    assert path.stat().st_size == entry['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
summary = dict(
    result='One full non-timed matched Hyle 4x256KiB episode passes all existing protocol/payload/reverse-completion/cleanup oracles. 513/515 adaptive yields dispatch the other endpoint and observe its successful IO bytes. Two yields directly redispatch the same fiber and observe zero peer IO. This does not establish the cost of either category or resolve the formal HTTP2 latency residual.',
    evidence={k: v for k, v in data.items() if k not in ['dispatches', 'raw_yields']},
    direct_same_fiber_records=direct,
    dispatch_accounting=dict(total=520, client=260, server=260, unknown_fiber=0, adaptive_yield_resumptions=515, initial_fiber_entries=2, other_resumption_sequences=other_resumes, limitation='Three resume events outside the two marked adaptive-yield sites are visible but not assigned to individual asynchronous IO/Event waits; their causes and time costs were not instrumented.'),
    method='Cached scheduler ELF has four calls through Fiber::resume()@plt. Executable exports the same symbol, resolves the original once through dlsym(RTLD_NEXT) before constructing harnesses, and forwards every call. Fixed2048-entry owner-worker-local arrays, no atomics/QPC/extra locks/workers/yields. Each marked HTTP2 yield saves dispatch sequence and peer IO byte totals before and after the original Fiber::yield. Explicit endpoint roles register at original client/server entry. Record IO after the original valid-byte checks, covering immediate and asynchronous reads/writes. Read counters only after the pre-existing harness destructors shutdown/join workers.',
    validation='Executable dynamic-symbol dump and runtime different executable/original image addresses plus520 intercepted resume calls establish that PLT interposition actually ran. No missing/unknown fiber, counter overflow, unfinished yield or invalid dispatch sequence. Client sent1050124 equals server received1050124; server sent1050027 equals client received1050027. Successful wire byte total2100151 in each direction includes async progress that earlier immediate-only syscall counters did not include.',
    runtime_scope='Exactly one executable invocation after compiling. HyleHarness and inactive RawHarness retained: one scheduler worker, one inactive raw worker and caller; taskset CPU2 inherited. No fresh live resource census; no alternate route, AA, timing, profiler or hardware counter run. Existing HTTP/feature/nanobench/nghttp2/foundation binaries reused. Only diagnostic HTTP2, consumer-main and probe-state TUs compiled; no scheduler/fiber or SDK build/copy.',
    retained_build_failure='First probe_state compile used a noexcept method definition but the public Fiber::resume declaration is not noexcept. Compiler rejected it before any link/run. Corrected only the diagnostic forwarding signature and compiled that TU again; original failure stderr and command remain. HTTP2/main were not recompiled, and the only runtime invocation exits0.',
    observation_limits=['513 peer-progress events have no time weights; do not derive a percentage of the12–15% formal latency gap from these counts.', 'Two direct redispatches occur at sequence1->2(server read) and3->4(client write), near initial startup in this episode. No claim their cost is negligible or that they characterize every episode.', 'No peer returned IO bytes does not mean no kernel progress, and it does not authorize dropping cancellation, fairness, owner, readiness or completion responsibilities.', 'Probe functions and fixed-array writes perturb execution; diagnostic is supplementary evidence about this episode, not an unperturbed formal thread/call census.', 'Three non-adaptive resume causes, exact per-turn CPU cost, kernel work, backend pending-operation state and empty nghttp2 encode counts remain unobserved. No extrapolation to a universal scheduler bottleneck.'],
    product='No product source edited. Existing submit_epoch dead-state finding remains a separate cleanup, not a measured explanation of the latency gap.')
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
files = [BUILD / name for name in ['http2.o', 'main.o', 'probe_state.o', 'consumer']]
cleanup = dict(allowed_root=str(BUILD), operation='Only exact listed rebuildable files; no deletion performed. Root must write/review test.ps1 before cleanup.', files=[dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files], total_bytes=sum(p.stat().st_size for p in files), preserve='All sources, commands, raw results/logs, archives, cached foundation and parent HTTP2 artifacts.', rebuild='Use successful compile/link argv entries in commands.json. run.py also runs a diagnostic; execution is unnecessary to recreate these binaries.')
(HERE / 'cleanup-manifest.json').write_text(json.dumps(cleanup, indent=2) + '\n')
# Full generated disassembly/dynsym text is reproducible from the identified
# cached ELF; keep it in scratch, archive the precise resume/PLT excerpts only.
excluded = {'cached-scheduler-disassembly.stdout.txt', 'executable-symbols.stdout.txt', 'raw.zip', 'archive-record.json', 'manifest.json'}
paths = sorted(p for p in HERE.iterdir() if p.is_file() and p.name not in excluded and p.suffix in {'.json', '.txt', '.cc', '.h', '.py'})
(HERE / 'manifest.json').write_text(json.dumps([dict(path=p.name, bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths], indent=2) + '\n')
with zipfile.ZipFile(HERE / 'raw.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in [*paths, HERE / 'manifest.json']:
        archive.write(path, path.name)
path = HERE / 'raw.zip'
record = dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest(), members=len(paths)+1, binary_or_sdk_members=False)
(HERE / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print('Cleanup bytes:', cleanup['total_bytes'])
