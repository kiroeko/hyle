#define main original_benchmark_main
#include "diag_bench.cc"
#undef main
#include "probe_state.h"

struct Counts {
  std::uint64_t total = 0;
  std::uint64_t direct_same_fiber = 0;
  std::uint64_t with_peer_dispatch = 0;
  std::uint64_t peer_dispatches = 0;
  std::uint64_t unknown_dispatches = 0;
  std::uint64_t with_peer_io = 0;
  std::uint64_t without_peer_io = 0;
  std::uint64_t peer_recv_bytes = 0;
  std::uint64_t peer_send_bytes = 0;
};

int main() {
  using namespace yield_progress;
  std::signal(SIGPIPE, SIG_IGN);
  if (!initialize()) return 2;
  const auto workload = make_workload("untimed yield progress", 4,
      256 * 1024, 256 * 1024, NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  int completed = -1;
  {
    HyleHarness hyle;
    RawHarness peer; // Same inactive peer harness/thread as the matched fixture.
    completed = hyle.run(workload); // Exactly one full Hyle episode.
  } // Existing RAII shutdown/join completes before reading owner-local counters.
  bool valid = completed == 4 && overflow_count == 0 && dispatch_count > 2 &&
      yield_count != 0 && endpoints[0].fiber != nullptr &&
      endpoints[1].fiber != nullptr && endpoints[0].fiber != endpoints[1].fiber;
  std::array<Counts, 2> counts{};
  std::array<std::uint64_t, 2> role_dispatches{};
  std::uint64_t unknown_dispatches = 0;
  for (std::uint64_t i = 0; i != dispatch_count && i < dispatches.size(); ++i) {
    if (dispatches[i] == endpoints[0].fiber) ++role_dispatches[0];
    else if (dispatches[i] == endpoints[1].fiber) ++role_dispatches[1];
    else ++unknown_dispatches;
  }
  for (std::uint64_t i = 0; i != yield_count && i < yields.size(); ++i) {
    const auto& y = yields[i];
    valid &= y.kind < counts.size() && y.first_dispatch != 0 &&
        y.resumed_dispatch > y.first_dispatch &&
        y.resumed_dispatch <= dispatch_count;
    if (!valid) break;
    const unsigned role = y.self == endpoints[0].fiber ? 0 : 1;
    valid &= y.self == endpoints[role].fiber &&
        dispatches[y.first_dispatch - 1] == y.self &&
        dispatches[y.resumed_dispatch - 1] == y.self &&
        y.peer_recv_after >= y.peer_recv_before &&
        y.peer_send_after >= y.peer_send_before;
    auto& c = counts[y.kind];
    ++c.total;
    c.direct_same_fiber += y.resumed_dispatch == y.first_dispatch + 1;
    std::uint64_t peer_dispatch_count = 0;
    for (std::uint64_t d = y.first_dispatch; d + 1 < y.resumed_dispatch; ++d) {
      if (dispatches[d] == endpoints[role ^ 1].fiber) ++peer_dispatch_count;
      else ++c.unknown_dispatches;
    }
    c.with_peer_dispatch += peer_dispatch_count != 0;
    c.peer_dispatches += peer_dispatch_count;
    const auto recv = y.peer_recv_after - y.peer_recv_before;
    const auto send = y.peer_send_after - y.peer_send_before;
    c.with_peer_io += recv != 0 || send != 0;
    c.without_peer_io += recv == 0 && send == 0;
    c.peer_recv_bytes += recv;
    c.peer_send_bytes += send;
  }
  valid &= unknown_dispatches == 0 &&
      role_dispatches[0] + role_dispatches[1] == dispatch_count &&
      counts[0].total + counts[1].total == yield_count &&
      dispatch_count >= yield_count + 2;
  std::printf("{\"completed\":%d,\"counter_checks_passed\":%s,"
      "\"resume_interposition\":{\"original_image\":\"%s\","
      "\"executable_image\":\"%s\",\"dispatch_calls\":%llu,"
      "\"unknown_fiber_dispatches\":%llu},\"overflow_count\":%llu,"
      "\"endpoints\":[", completed, valid ? "true" : "false",
      original_resume_image, default_resume_image,
      (unsigned long long)dispatch_count, (unsigned long long)unknown_dispatches,
      (unsigned long long)overflow_count);
  for (unsigned role = 0; role != endpoints.size(); ++role) {
    const auto& e = endpoints[role];
    std::printf("%s{\"role\":\"%s\",\"fiber\":\"%p\",\"session\":\"%p\","
        "\"dispatches\":%llu,\"recv_bytes\":%llu,\"send_bytes\":%llu}",
        role ? "," : "", role ? "server" : "client", e.fiber, e.session,
        (unsigned long long)role_dispatches[role],
        (unsigned long long)e.recv_bytes, (unsigned long long)e.send_bytes);
  }
  std::printf("],\"yield_categories\":[");
  for (unsigned kind = 0; kind != counts.size(); ++kind) {
    const auto& c = counts[kind];
    std::printf("%s{\"kind\":\"%s\",\"total\":%llu,\"direct_same_fiber\":%llu,"
        "\"with_peer_dispatch\":%llu,\"peer_dispatches\":%llu,"
        "\"unknown_dispatches\":%llu,\"with_peer_io\":%llu,"
        "\"without_peer_io\":%llu,\"peer_recv_bytes\":%llu,\"peer_send_bytes\":%llu}",
        kind ? "," : "", kind ? "read" : "write",
        (unsigned long long)c.total, (unsigned long long)c.direct_same_fiber,
        (unsigned long long)c.with_peer_dispatch,
        (unsigned long long)c.peer_dispatches,
        (unsigned long long)c.unknown_dispatches,
        (unsigned long long)c.with_peer_io,
        (unsigned long long)c.without_peer_io,
        (unsigned long long)c.peer_recv_bytes,
        (unsigned long long)c.peer_send_bytes);
  }
  std::printf("],\"dispatches\":[");
  for (std::uint64_t i = 0; i < dispatch_count && i < dispatches.size(); ++i)
    std::printf("%s\"%p\"", i ? "," : "", dispatches[i]);
  std::printf("],\"raw_yields\":[");
  for (std::uint64_t i = 0; i < yield_count && i < yields.size(); ++i) {
    const auto& y = yields[i];
    std::printf("%s{\"fiber\":\"%p\",\"kind\":%llu,\"first_dispatch\":%llu,"
        "\"resumed_dispatch\":%llu,\"peer_recv_before\":%llu,"
        "\"peer_recv_after\":%llu,\"peer_send_before\":%llu,\"peer_send_after\":%llu}",
        i ? "," : "", y.self, (unsigned long long)y.kind,
        (unsigned long long)y.first_dispatch,
        (unsigned long long)y.resumed_dispatch,
        (unsigned long long)y.peer_recv_before,
        (unsigned long long)y.peer_recv_after,
        (unsigned long long)y.peer_send_before,
        (unsigned long long)y.peer_send_after);
  }
  std::printf("]}\n");
  return valid ? 0 : 3;
}
