#include "probe_state.h"
#include <cstdlib>
#include <dlfcn.h>
#include "hyle/sched/fiber.h"

namespace yield_progress {
std::array<Endpoint, 2> endpoints{};
std::array<void*, kMaxRecords> dispatches{};
std::array<Yield, kMaxRecords> yields{};
std::uint64_t dispatch_count = 0;
std::uint64_t yield_count = 0;
std::uint64_t overflow_count = 0;
void* original_resume_address = nullptr;
void* default_resume_address = nullptr;
const char* original_resume_image = nullptr;
const char* default_resume_image = nullptr;
using Resume = void (*)(hyle::sched::Fiber*);
Resume original_resume = nullptr;

bool initialize() noexcept {
  constexpr const char* name = "_ZN4hyle5sched5Fiber6resumeEv";
  original_resume_address = dlsym(RTLD_NEXT, name);
  default_resume_address = dlsym(RTLD_DEFAULT, name);
  Dl_info original{}, interposed{};
  if (original_resume_address == nullptr || default_resume_address == nullptr ||
      original_resume_address == default_resume_address ||
      dladdr(original_resume_address, &original) == 0 ||
      dladdr(default_resume_address, &interposed) == 0)
    return false;
  original_resume_image = original.dli_fname;
  default_resume_image = interposed.dli_fname;
  original_resume = reinterpret_cast<Resume>(original_resume_address);
  return true;
}

unsigned current_role(void* session) noexcept {
  void* fiber = hyle::sched::Fiber::current();
  for (unsigned role = 0; role != endpoints.size(); ++role) {
    auto& endpoint = endpoints[role];
    if (endpoint.fiber != fiber) continue;
    if (endpoint.session == nullptr) endpoint.session = session;
    if (endpoint.session != session) std::abort();
    return role;
  }
  std::abort();
}

void set_role(unsigned role) noexcept {
  if (role >= endpoints.size() || endpoints[role].fiber != nullptr)
    std::abort();
  endpoints[role].fiber = hyle::sched::Fiber::current();
  if (endpoints[role].fiber == nullptr) std::abort();
}

void io(void* session, bool receive, std::size_t bytes) noexcept {
  auto& endpoint = endpoints[current_role(session)];
  if (receive) endpoint.recv_bytes += bytes;
  else endpoint.send_bytes += bytes;
}

void yield(unsigned kind, void* session) noexcept {
  const unsigned role = current_role(session);
  const auto& peer = endpoints[role ^ 1];
  const std::uint64_t index = yield_count++;
  if (index >= yields.size()) {
    ++overflow_count;
    hyle::sched::Fiber::yield();
    return;
  }
  auto& record = yields[index];
  record.self = endpoints[role].fiber;
  record.kind = kind;
  record.first_dispatch = dispatch_count;
  record.peer_recv_before = peer.recv_bytes;
  record.peer_send_before = peer.send_bytes;
  hyle::sched::Fiber::yield();
  record.resumed_dispatch = dispatch_count;
  record.peer_recv_after = peer.recv_bytes;
  record.peer_send_after = peer.send_bytes;
}
} // namespace yield_progress

// Exact exported symbol used by cached scheduler PLT calls. Resolve RTLD_NEXT
// once before creating harnesses; this wrapper never allocates or resolves names.
void hyle::sched::Fiber::resume() {
  using namespace yield_progress;
  const std::uint64_t index = dispatch_count++;
  if (index < dispatches.size()) dispatches[index] = this;
  else ++overflow_count;
  if (original_resume == nullptr) std::abort();
  original_resume(this);
}
