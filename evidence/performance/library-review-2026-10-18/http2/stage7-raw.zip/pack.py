"""Summarize the recorded episode; never execute the consumer or clean files."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "raw-fiber"
REVIEW = HERE.parent / "raw-fiber-review"


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


before = json.loads((OLD / "one-episode.stdout.txt").read_text(encoding="utf-8"))
raw = json.loads((HERE / "one-episode.stdout.txt").read_text(encoding="utf-8"))
assert raw["checks_passed"] and raw["descriptors_closed"] and raw["completed"] == 4 and raw["overflow"] == 0
for name, expected in json.loads((HERE / "before-identity.json").read_text()).items():
    assert identity(OLD / name)["sha256"] == expected, name


def counts(data):
    endpoints = data["endpoints"]
    return dict(
        recv_attempts=sum(e["recv_calls"] for e in endpoints),
        recv_eagain=sum(e["recv_eagain"] for e in endpoints),
        recv_ready=sum(e["recv_calls"]-e["recv_eagain"] for e in endpoints),
        recv_bytes=sum(e["received"] for e in endpoints),
        send_attempts=sum(e["send_calls"] for e in endpoints),
        send_eagain=sum(e["send_eagain"] for e in endpoints),
        send_ready=sum(e["send_calls"]-e["send_eagain"] for e in endpoints),
        send_bytes=sum(e["sent"] for e in endpoints),
        async_reads=sum(e["async_reads"] for e in endpoints),
        async_writes=sum(e["async_writes"] for e in endpoints),
        async_recv_bytes=sum(e["async_received"] for e in endpoints),
        async_sent_bytes=sum(e["async_sent"] for e in endpoints),
        nonempty_mem_send=sum(e["mem_send_calls"]-e["mem_send_zero"] for e in endpoints),
        mem_recv_calls=sum(e["mem_recv_calls"] for e in endpoints),
        consumes=sum(e["consumes"] for e in endpoints),
        consumed_bytes=sum(e["consumed_bytes"] for e in endpoints),
        resumes=data["dispatch_count"], yields=sum(e["yields"] for e in endpoints),
        wire_by_direction=[e["sent"]+e["async_sent"] for e in endpoints])


now = counts(raw)
old = counts(before)
for e in raw["endpoints"]:
    sites = e["sites"]
    assert sum(sites[i]["calls"] for i in (0, 3)) == e["send_calls"]
    assert sum(sites[i]["eagain"] for i in (0, 3)) == e["send_eagain"]
    assert sum(sites[i]["bytes"] for i in (0, 3)) == e["sent"]
    assert sum(sites[i]["calls"] for i in (1, 2)) == e["recv_calls"]
    assert sum(sites[i]["eagain"] for i in (1, 2)) == e["recv_eagain"]
    assert sum(sites[i]["bytes"] for i in (1, 2)) == e["received"]
    assert e["consumed_bytes"] == 1048576 and e["validated"] == 4 and e["closed"] == 1 and e["destroyed"] == 1
site_totals = [{"site":i, "calls":sum(e["sites"][i]["calls"] for e in raw["endpoints"]),
                "eagain":sum(e["sites"][i]["eagain"] for e in raw["endpoints"]),
                "bytes":sum(e["sites"][i]["bytes"] for e in raw["endpoints"])} for i in range(4)]
prior_cached = {x["path"]:x for x in json.loads((OLD / "postrun-identity.json").read_text())["link_inputs"]}
current_cached = json.loads((HERE / "identity.json").read_text())["files"]
compared = []
for item in current_cached:
    if "/raw-fiber-aligned/" in item["path"]:
        continue
    previous = prior_cached.get(item["path"])
    assert previous and previous["sha256"] == item["sha256"] and previous["bytes"] == item["bytes"], item["path"]
    compared.append(item)
save("cached-closure-match.json", {"all_same_as_stage6":True,"files":compared})
(HERE / "resume-symbol.txt").write_text("\n".join(line for line in (HERE / "symbols.stdout.txt").read_text().splitlines() if "_ZN4hyle5sched5Fiber6resumeEv" in line)+"\n")
summary = dict(
    result="One aligned raw-nghttp2 driver episode passed. Two scratch driver strategy corrections reduce empty immediate attempts by194 in this episode, while successful IO, full protocol payload/close checks and520resume/515yield counts remain. No elapsed time or ranking collected.",
    runtime_invocations=1, timed=False, workload="4streams,256KiB body each direction, paired reverse completion",
    source="Only separate scratch main/diag/probe copies; original stage6, formal bench and product unchanged. Fresh2TUs plus existing identical cached closure; no SDK copy/download/foundation build.",
    changes=["Restart the outer protocol/flush loop immediately after an entire wire frame was sent, matching flush_once progressed handling.", "After yield, retry only one immediate send before returning to the ordinary flush loop, preventing raw_write from consuming EAGAIN after partial success and immediately repeating it at the top.", "Four endpoint-owned per-site fixed counters record calls/EAGAIN/bytes; callbacks,body-consume,reversal,readiness,spawn_task,Event and cleanup unchanged."],
    checks=dict(passed=True,completed=4,overflow=0,descriptors_closed=True,
                request_order=[p["arg"] for p in raw["phases"] if p["kind"]==2],
                response_submit_order=[p["arg"] for p in raw["phases"] if p["kind"]==3],
                client_completion_order=[p["arg"] for p in raw["phases"] if p["kind"]==4 and p["role"]==0],
                body_validations=8,sessions_destroyed=2,sockets_closed=2),
    counts=dict(stage6_frozen_before=old,aligned_after=now,
                fewer_empty_reads=old["recv_eagain"]-now["recv_eagain"],
                fewer_empty_writes=old["send_eagain"]-now["send_eagain"]),
    sites=site_totals,
    scheduling=dict(workers=sorted({p["worker"] for p in raw["dispatches"]}),
                    owner_tuples=[dict(worker=w,before=b,after=a,count=n) for (w,b,a),n in Counter((p["worker"],p["owner_before"],p["owner_after"]) for p in raw["dispatches"]).items()],
                    phases=raw["phase_count"],
                    original_resume=raw["original_resume_image"],interposed_resume=raw["interposed_resume_image"]),
    prior_hyle="Aligned counts709empty-read/258empty-write,323ready-read/514ready-write match the separately recorded stage2 Hyle aggregate.520resume/515yield and full directional bytes also match separate stage5 Hyle evidence. These separate episodes are not one timing control or cost subtraction.",
    byte_distribution="Same full directional bytes. Immediate recv changes2091981->2091990B and async recv8170->8161B (9B moves between paths); successful call counts remain equal.",
    limits=["Single non-timed episode, both driver changes combined, plus low-cost counter writes/interposition; no one-change-at-a-time attribution of130/64 to individual sites.", "Matching aggregate counts does not make all codec,session,lifecycle and scheduling work identical. Formal manual-loop peer remains unchanged; no scheduler/framework percentage or tokens/s conclusion.", "Retained Event explicit-default aggregate warning matches stage6; no compile/link/runtime failure. No concurrent/full public IO test suite or foundation rebuild.", "Stage6 source/log hashes verified unchanged; only exact new object/executable outputs are cleanup candidates."],
    stage6_archive={"path":str(OLD/"source-results.zip"),**identity(OLD/"source-results.zip")},
)
save("summary.json", summary)
save("source-identity.json", {name:identity(HERE/name) for name in ("main.cc","diag_bench.cc","split_advance.h","probe.h","probe.cc","run.py","pack.py")})
cleanup = json.loads((HERE / "cleanup-candidates.json").read_text())
cleanup["total_bytes"] = sum(x["bytes"] for x in cleanup["files"])
save("cleanup-candidates.json", cleanup)
files = {path.name:path for path in HERE.iterdir() if path.is_file() and path.suffix in {".cc",".h",".py",".json",".txt",".diff"} and path.name not in {"archive-record.json","symbols.stdout.txt"}}
for name in ("main.cc","diag_bench.cc","split_advance.h","probe.h","probe.cc","summary.json","prior-counts.json","phase-legend.json","postrun-identity.json","identity.json","commands.json"):
    files["frozen-stage6/"+name] = OLD / name
for name in ("prepare_aligned.py","driver-align-proposal.diff","review.json"):
    files["proposal-review/"+name] = REVIEW / name
archive = HERE / "source-results.zip"
with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()):
        z.write(path,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    members = len(z.infolist())
record = {"path":str(archive),**identity(archive),"members":members,"cleanup_files":len(cleanup["files"]),"cleanup_bytes":cleanup["total_bytes"]}
save("archive-record.json",record)
print(json.dumps({"archive":record,"current":now,"sites":site_totals},indent=2))
