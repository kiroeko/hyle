#include "probe.h"
#include <cerrno>
#include <cstdlib>
#include <dlfcn.h>
#include <sys/socket.h>
#include "hyle/sched/fiber.h"
#include "hyle/sched/waker.h"
#include "fiber_access.h" // Source-only observation; never changes scheduling.
namespace raw_probe {
std::array<Endpoint,2> endpoints{};
std::array<Record,kCapacity> phases{};
std::array<Dispatch,kCapacity> dispatches{};
std::uint64_t phase_count=0,dispatch_count=0,overflow=0;
const char* original_image=nullptr;const char* interposed_image=nullptr;
using Resume=void(*)(hyle::sched::Fiber*);Resume original_resume=nullptr;
bool initialize() noexcept {
  const char* symbol="_ZN4hyle5sched5Fiber6resumeEv";
  void* original=dlsym(RTLD_NEXT,symbol);void* current=dlsym(RTLD_DEFAULT,symbol);
  Dl_info a{},b{};
  if(!original||!current||original==current||!dladdr(original,&a)||!dladdr(current,&b))return false;
  original_resume=reinterpret_cast<Resume>(original);original_image=a.dli_fname;interposed_image=b.dli_fname;return true;
}
unsigned role(void* endpoint) noexcept {
  for(unsigned i=0;i<endpoints.size();++i)if(endpoints[i].endpoint==endpoint)return i;
  std::abort();
}
unsigned fd_role(int fd) noexcept {
  for(unsigned i=0;i<endpoints.size();++i)if(endpoints[i].fd==fd)return i;
  std::abort();
}
unsigned current_role() noexcept {
  auto* f=hyle::sched::Fiber::current();
  for(unsigned i=0;i<endpoints.size();++i)if(endpoints[i].fiber==f)return i;
  std::abort();
}
void record(unsigned r,Phase p,std::int64_t arg) noexcept {
  const auto i=phase_count++;
  if(i>=phases.size()){++overflow;return;}
  auto* f=hyle::sched::Fiber::current();const auto& e=endpoints[r];
  phases[i]={r,p,hyle::sched::current_worker_index(),f?hyle::sched::detail::FiberAccess::owner_worker(f):-99,f,arg,e.sent+e.async_sent,e.received+e.async_received};
}
void body(void* ep,std::size_t bytes) noexcept {auto& e=endpoints[role(ep)];++e.consumes;e.consumed_bytes+=bytes;}
ssize_t send(int fd,const void* p,std::size_t n,int flags) noexcept {
  auto v=::send(fd,p,n,flags);const int error=errno;auto& e=endpoints[fd_role(fd)];++e.send_calls;
  auto& site=e.sites[e.io_site];++site.calls;if(v>0)site.bytes+=static_cast<std::uint64_t>(v);else if(v<0&&(error==EAGAIN||error==EWOULDBLOCK))++site.eagain;
  if(v>0)e.sent+=static_cast<std::uint64_t>(v);else if(v<0&&(error==EAGAIN||error==EWOULDBLOCK))++e.send_eagain;
  errno=error;return v;
}
ssize_t recv(int fd,void* p,std::size_t n,int flags) noexcept {
  auto v=::recv(fd,p,n,flags);const int error=errno;auto& e=endpoints[fd_role(fd)];++e.recv_calls;
  auto& site=e.sites[e.io_site];++site.calls;if(v>0)site.bytes+=static_cast<std::uint64_t>(v);else if(v<0&&(error==EAGAIN||error==EWOULDBLOCK))++site.eagain;
  if(v>0)e.received+=static_cast<std::uint64_t>(v);else if(v<0&&(error==EAGAIN||error==EWOULDBLOCK))++e.recv_eagain;
  errno=error;return v;
}
nghttp2_ssize mem_send(nghttp2_session* s,const std::uint8_t** p) {
  auto v=nghttp2_session_mem_send2(s,p);auto& e=endpoints[current_role()];++e.mem_send_calls;
  if(v==0)++e.mem_send_zero;else if(v>0)e.mem_send_bytes+=static_cast<std::uint64_t>(v);return v;
}
nghttp2_ssize mem_recv(nghttp2_session* s,const std::uint8_t* p,std::size_t n) {
  auto v=nghttp2_session_mem_recv2(s,p,n);auto& e=endpoints[current_role()];++e.mem_recv_calls;if(v>0)e.mem_recv_bytes+=static_cast<std::uint64_t>(v);return v;
}
}
void hyle::sched::Fiber::resume() {
  using namespace raw_probe;const auto i=dispatch_count++;
  if(i<dispatches.size())dispatches[i]={this,hyle::sched::current_worker_index(),hyle::sched::detail::FiberAccess::owner_worker(this),-99};else ++overflow;
  if(!original_resume)std::abort();original_resume(this);
  if(i<dispatches.size())dispatches[i].after=hyle::sched::detail::FiberAccess::owner_worker(this);
}
