"""Fresh two small TUs, cached closure, exactly one non-timed episode."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/raw-fiber-aligned'
OLD = HERE.parent / 'raw-fiber'
BUILD = Path('/root/hyle-scratch/http2-current-20261018/raw-fiber-aligned')
BUILD.mkdir(exist_ok=True)
previous = json.loads((OLD / 'commands.json').read_text())
records = []


def run(name, argv, env=None, timeout=60):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=BUILD, env=env, capture_output=True, text=True, timeout=timeout)
    (HERE / (name+'.stdout.txt')).write_text(result.stdout)
    (HERE / (name+'.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(BUILD), exit=result.returncode))
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout[-1800:]);print(result.stderr[-1800:])
        raise SystemExit(result.returncode)
    return result.stdout


for name in ('main', 'probe'):
    command = next(row['argv'] for row in previous if row['name'] == 'compile-'+name)
    command = [x.replace(str(OLD), str(HERE)).replace('/http2-current-20261018/raw-fiber/', '/http2-current-20261018/raw-fiber-aligned/') for x in command]
    run('compile-'+name, command)
link = next(row['argv'] for row in previous if row['name'] == 'link')
link = [x.replace('/http2-current-20261018/raw-fiber/', '/http2-current-20261018/raw-fiber-aligned/') for x in link]
run('link', link)
symbols = run('symbols', ['readelf', '-Ws', BUILD/'consumer'])
assert any('_ZN4hyle5sched5Fiber6resumeEv' in line and 'GLOBAL DEFAULT' in line for line in symbols.splitlines())
run('loader', ['ldd', BUILD/'consumer'])
env = {k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_'))}
output = run('one-episode', ['timeout', '--kill-after=2s', '15s', 'taskset', '-c', '2', BUILD/'consumer'], env, timeout=20)
data = json.loads(output)
assert data['checks_passed'] and data['completed'] == 4 and data['overflow'] == 0
paths = {Path(x).resolve() for x in link if x.endswith(('.o','.a'))}
paths.add(BUILD/'consumer')
for line in (HERE/'loader.stdout.txt').read_text().splitlines():
    if 'libhyle_' in line and '=>' in line:
        paths.add(Path(line.split('=>',1)[1].strip().split()[0]).resolve())
def identity(p):
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(HERE/'identity.json').write_text(json.dumps(dict(files=[identity(p) for p in sorted(paths)], scope='Exactly one non-timed episode; same retained stage6 cached closure, no foundation/SDK rebuild.'),indent=2)+'\n')
(HERE/'cleanup-candidates.json').write_text(json.dumps(dict(directory=str(BUILD), files=[identity(BUILD/n) for n in ('main.o','probe.o','consumer')], action='Only candidates; root test.ps1 must select exact WSL paths before deletion. No deletion here.'),indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in ('phases','dispatches')},indent=2))
