"""Create a separate proposed diagnostic; frozen stage6 sources stay intact."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "raw-fiber"
OUT = HERE.parent / "raw-fiber-aligned"
OUT.mkdir(exist_ok=True)


def replace(text, before, after):
    assert text.count(before) == 1, (before, text.count(before))
    return text.replace(before, after, 1)


for name in ("main.cc", "diag_bench.cc", "split_advance.h", "probe.h", "probe.cc"):
    (OUT / name).write_bytes((SOURCE / name).read_bytes())
main = (OUT / "main.cc").read_text()
main = replace(main, "    if(role==1&&server_flushed(e,w))continue;\n    bool progress=false;", "    if(role==1&&server_flushed(e,w))continue;\n    // Match drive_until: restart flushing after a completed wire frame.\n    if(written&&w.begin==w.end)continue;\n    bool progress=false;")
main = replace(main, "if(progress||(written&&w.begin==w.end))continue;", "if(progress)continue;")
main = replace(main, "written=false;if(!raw_write(w,written))co_return -1;", "written=false;if(!raw_write(w,written,true))co_return -1;")
main = replace(main, "    if(!raw_write(w,written))co_return -1;", "    counters.io_site=0;\n    if(!raw_write(w,written))co_return -1;")
main = replace(main, "    bool progress=false;\n    if(!raw_read", "    bool progress=false;\n    counters.io_site=1;\n    if(!raw_read")
main = replace(main, "    progress=false;\n    if(!raw_read", "    progress=false;\n    counters.io_site=2;\n    if(!raw_read")
main = replace(main, "      written=false;if(!raw_write", "      counters.io_site=3;\n      written=false;if(!raw_write")
main = replace(main, '    std::printf("}");}', '''    std::printf(",\\"sites\\":[");
    for(unsigned site=0;site<4;++site){const auto& s=e.sites[site];std::printf("%s{\\"site\\":%u,\\"calls\\":%llu,\\"eagain\\":%llu,\\"bytes\\":%llu}",site?",":"",site,(unsigned long long)s.calls,(unsigned long long)s.eagain,(unsigned long long)s.bytes);}
    std::printf("]}");}''')
(OUT / "main.cc").write_text(main)

diag = (OUT / "diag_bench.cc").read_text()
diag = replace(diag, "bool raw_write(RawWire &wire, bool &progress) noexcept {", "bool raw_write(RawWire &wire, bool &progress, bool single_attempt = false) noexcept {")
diag = replace(diag, "      wire.begin += static_cast<std::size_t>(written);\n      progress = true;\n      continue;", "      wire.begin += static_cast<std::size_t>(written);\n      progress = true;\n      // Match Hyle's single immediate write retry after a yield.\n      if (single_attempt) {\n        if (wire.begin == wire.end) wire.begin = wire.end = 0;\n        return true;\n      }\n      continue;")
(OUT / "diag_bench.cc").write_text(diag)

header = (OUT / "probe.h").read_text()
header = replace(header, "struct Endpoint {", "struct IoSite {std::uint64_t calls=0,eagain=0,bytes=0;};\nstruct Endpoint {\n  unsigned io_site=0;std::array<IoSite,4> sites{};")
(OUT / "probe.h").write_text(header)
probe = (OUT / "probe.cc").read_text()
for operation in ("send", "recv"):
    before = f"++e.{operation}_calls;"
    after = before + "\n  auto& site=e.sites[e.io_site];++site.calls;if(v>0)site.bytes+=static_cast<std::uint64_t>(v);else if(v<0&&(error==EAGAIN||error==EWOULDBLOCK))++site.eagain;"
    probe = replace(probe, before, after)
(OUT / "probe.cc").write_text(probe)
patch = ""
for name in ("main.cc", "diag_bench.cc", "split_advance.h", "probe.h", "probe.cc"):
    patch += "".join(difflib.unified_diff((SOURCE / name).read_text().splitlines(True), (OUT / name).read_text().splitlines(True), fromfile="stage6/"+name, tofile="aligned/"+name))
(OUT / "stage6-to-aligned.diff").write_text(patch)
(OUT / "site-legend.json").write_text(json.dumps({"0":"initial write/drain", "1":"initial read after no complete write", "2":"after-yield read", "3":"after-yield single write retry"}, indent=2)+"\n")
(OUT / "before-identity.json").write_text(json.dumps({name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in ("main.cc","diag_bench.cc","split_advance.h","probe.h","probe.cc","one-episode.stdout.txt","summary.json")}, indent=2)+"\n")
print(str(OUT))
