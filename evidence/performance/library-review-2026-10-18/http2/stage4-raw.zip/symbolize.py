from pathlib import Path
import collections,json,re,subprocess
root=Path('/mnt/c/public/project-hyle/hyle')
here=root/'.scratch/perf-review-2026-10-18/http2/profile-fp'
build=Path('/root/hyle-scratch/http2-current-20261018/profile-fp')
perf='/usr/lib/linux-tools/6.18.54.1-microsoft-standard-WSL2/bin/perf'
summary={}
for route in ['hyle','peer']:
    p=subprocess.run([perf,'script','-i',str(build/(route+'.data')),'--show-mmap-events'],capture_output=True,text=True)
    mmaps=[x for x in p.stdout.splitlines() if 'PERF_RECORD_MMAP' in x]
    (here/(route+'-mmaps.txt')).write_text('\n'.join(mmaps)+'\n')
    mappings=[]
    for line in mmaps:
        m=re.search(r'\[(0x[0-9a-f]+)\((0x[0-9a-f]+)\) @ (0x[0-9a-f]+|0).*\]: r-xp (.+)$',line)
        if m: mappings.append(tuple(int(m[i],16) for i in [1,2,3])+(m[4],))
    samples=[]; images=collections.defaultdict(set)
    for block in (here/('script-'+route+'.stdout.txt')).read_text().strip().split('\n\n'):
        lines=block.splitlines()
        if not lines:continue
        frames=[];broken=False
        for line in lines[1:]:
            m=re.search(r'^\s+([0-9a-f]+) .* \((.+)\)$',line)
            if not m: broken=True;break
            pc=int(m[1],16);image=m[2]
            found=next((x for x in reversed(mappings) if x[3]==image and x[0]<=pc<x[0]+x[1]),None)
            if not found:broken=True;break
            offset=pc-found[0]+found[2]-(1 if frames else 0)
            frames.append((image,offset)); images[image].add(offset)
        samples.append({'header':lines[0],'frames':frames,'truncated_at_invalid':broken})
    symbols={}
    for image,offsets in images.items():
        offsets=sorted(offsets)
        result=subprocess.run(['addr2line','-f','-C','-e',image]+[hex(x) for x in offsets],capture_output=True,text=True)
        result_lines=result.stdout.splitlines()
        assert result.returncode==0 and len(result_lines)==2*len(offsets),(image,result.stderr)
        for i,offset in enumerate(offsets):symbols[(image,offset)]={'function':result_lines[i*2],'line':result_lines[i*2+1]}
    leaves=collections.Counter();chains=collections.Counter();valid_consumer=0
    for sample in samples:
        stack=[symbols[x]['function'] for x in sample['frames']]
        if stack:leaves[stack[0]]+=1
        # Count samples, never sum inclusive parents as separate CPU cost.
        own=[symbols[x]['function'] for x in sample['frames'] if x[0]==str(build/'consumer')]
        if own:valid_consumer+=1;chains[' <- '.join(own[:4])]+=1
    summary[route]={'samples':len(samples),'samples_with_valid_consumer_frame':valid_consumer,
        'samples_with_invalid_suffix':sum(x['truncated_at_invalid'] for x in samples),
        'top_leaf_symbols':leaves.most_common(25),'top_partial_consumer_chains':chains.most_common(20),
        'limitation':'Leaf PCs and in-range consumer frames independently symbolized from recorded MMAP addresses and matching ELF. Return addresses adjusted by minus1. Stop at first unmapped/bogus frame. Foundation/system binaries were not rebuilt with frame pointers; mapped frames may also be incomplete or misleading. Partial chains are diagnostic clues, not exact inclusive percentages or a decomposition of the formal latency gap.'}
    (here/(route+'-symbolized-samples.json')).write_text(json.dumps([{'header':s['header'],'truncated_at_invalid':s['truncated_at_invalid'],'frames':[{'image':x[0],'offset':hex(x[1]),**symbols[x]} for x in s['frames']]} for s in samples],indent=2)+'\n')
(here/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for route,data in summary.items():
    print(route,data['samples'],data['samples_with_invalid_suffix']);print(json.dumps(data['top_leaf_symbols'][:10],indent=2));print(json.dumps(data['top_partial_consumer_chains'][:6],indent=2))
