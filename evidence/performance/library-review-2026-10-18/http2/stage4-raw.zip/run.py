from pathlib import Path
import hashlib,json,subprocess
root=Path('/mnt/c/public/project-hyle/hyle')
here=root/'.scratch/perf-review-2026-10-18/http2/profile-fp'
base=Path('/root/hyle-scratch/http2-current-20261018')
build=base/'profile-fp';build.mkdir(exist_ok=True)
old=json.loads((here.parent/'build-commands.json').read_text())
records=[]
def run(name,argv):
    p=subprocess.run([str(x) for x in argv],cwd=build,capture_output=True,text=True,timeout=60)
    (here/(name+'.stdout.txt')).write_text(p.stdout)
    (here/(name+'.stderr.txt')).write_text(p.stderr)
    records.append({'name':name,'argv':[str(x) for x in argv],'exit':p.returncode})
    (here/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    if p.returncode:print(p.stderr[-2000:]);raise SystemExit(p.returncode)
    return p.stdout
probe=here/'profile.cc'
probe.write_text((here.parent/'profile/profile.cc').read_text())
for key,src,dest in [('src_io_http2_http2.cc',root/'src/io_http2/http2.cc',build/'http2.o'),('bench_io_http2_http2_p1_bench.cc',probe,build/'profile.o')]:
    cmd=next(x['argv'] for x in old if x['name']==key)
    run('compile-'+dest.stem,cmd[:-4]+['-g1','-fno-omit-frame-pointer','-c',src,'-o',dest])
link=next(x['argv'] for x in old if x['name']=='link')
link=[str(build/'consumer') if x.endswith('/http2_current') else str(build/'http2.o') if x.endswith('/src_io_http2_http2.cc.o') else str(build/'profile.o') if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
run('link',link)
identity={'scope':'Separate software FP sampling diagnosis, matched send/recv bench; no formal timing. Cached foundation is not rebuilt with frame pointers; partial/broken callchains expected. Fresh consumer and HTTP2 TUs only.',
    'sources':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'src/io_http2/http2.cc',root/'bench/io_http2/http2_p1_bench.cc',probe]},
    'binaries':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [build/'consumer']}}
(here/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for route in ['hyle','peer']:
    run('smoke-'+route,['taskset','-c','2',build/'consumer',route,'1'])
    run('profile-'+route,['perf','record','-e','cpu-clock:u','-F','1997','--call-graph','fp','-o',build/(route+'.data'),'--','taskset','-c','2',build/'consumer',route,'4000'])
    report=run('report-'+route,['perf','report','-i',build/(route+'.data'),'--stdio','--percent-limit','2','--sort','dso,symbol','--call-graph','graph,2'])
    run('script-'+route,['perf','script','-i',build/(route+'.data')])
    print(report[:8500])
