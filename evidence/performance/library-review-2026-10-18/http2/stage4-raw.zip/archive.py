from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('/mnt/c/public/project-hyle/hyle')
here=root/'.scratch/perf-review-2026-10-18/http2/profile-fp'
build=Path('/root/hyle-scratch/http2-current-20261018/profile-fp')
out=root/'evidence/performance/library-review-2026-10-18/http2'
summary=json.loads((here/'summary.json').read_text())
summary['method']='Separate software sampling,4000 complete holdout episodes per route, matching current send/recv fixture. Fresh HTTP2/consumer TUs with frame pointers, cached foundation unchanged. 1997Hz cpu-clock:u, no hardware PMU or formal timing; all payload/protocol/cleanup oracles passed. Profiling all process threads includes startup and inactive harness overhead.'
summary['conclusion']='Frame-pointer recording recovered some usable source callchains without installing/rebuilding profiler tooling. They implicate ordinary flush/receive/body-consume paths as next diagnostic locations; they do not establish the root cause or a scheduler percentage. Product HTTP2 unchanged, stage3 formal residual still unresolved. Do not rank total sample counts or sum inclusive nodes.'
perf='/usr/lib/linux-tools/6.18.54.1-microsoft-standard-WSL2/bin/perf'
for route in ['hyle','peer']:
 p=subprocess.run([perf,'script','-i',str(build/(route+'.data')),'--header-only'],capture_output=True,text=True)
 (here/(route+'-header.txt')).write_text(p.stdout)
 (here/(route+'-header.stderr.txt')).write_text(p.stderr)
summary['tool_limit']='Header inspection reports Invalid HEADER_EVENT_DESC and event description unavailable. Event samples/MMAP records decode; selected leaf/caller PCs were resolved independently with matching image and addr2line. Unknown/invalid suffixes are retained and excluded after their first invalid frame; mapped pointers can still be misleading when cached frames omit FP. No complete-stack claim.'
(here/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'stage4-summary.json').write_bytes((here/'summary.json').read_bytes())
archive=out/'stage4-raw.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(here.iterdir()):
  if p.is_file():z.write(p,p.name)
 for route in ['hyle','peer']:z.write(build/(route+'.data'),'perf/'+route+'.data')
 z.write(root/'bench/io_http2/http2_p1_bench.cc','source/http2_p1_bench.cc')
 z.write(root/'src/io_http2/http2.cc','source/http2.cc')
 z.write(here.parent/'build-identity.json','prior-cache-identity/build-identity.json')
record={'path':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(zipfile.ZipFile(archive).namelist()),'binaries_included':False}
(out/'stage4-archive-record.json').write_text(json.dumps(record,indent=2)+'\n')
cleanup=[]
for name in ['http2.o','profile.o','consumer']:
 p=build/name;cleanup.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(here/'rebuildable-files.json').write_text(json.dumps({'paths':cleanup},indent=2)+'\n')
print(json.dumps({'archive':record,'cleanup_bytes':sum(p['bytes'] for p in cleanup)},indent=2))
