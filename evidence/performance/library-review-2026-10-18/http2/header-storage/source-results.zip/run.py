from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/header-storage'
PRIOR = HERE.parent
BUILD = Path('/root/hyle-scratch/http2-current-20261018/header-storage')
BUILD.mkdir(exist_ok=True)
old = json.loads((PRIOR / 'build-candidate-commands.json').read_text())
records = []


def run(name, argv, expected=0, env=None, timeout=60):
    argv = list(map(str, argv))
    start = time.monotonic()
    result = subprocess.run(argv, cwd=BUILD, env=env, capture_output=True,
                            text=True, timeout=timeout)
    (HERE / (name + '.stdout.txt')).write_text(result.stdout)
    (HERE / (name + '.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(BUILD),
                        exit=result.returncode, expected_exit=expected,
                        elapsed_seconds=time.monotonic() - start,
                        environment={k: v for k, v in (env or {}).items()
                                     if k.startswith('HYLE_')}))
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode != expected:
        print(result.stdout[-3000:])
        print(result.stderr[-3000:])
        raise SystemExit(result.returncode or 1)
    return result.stdout


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


for arm, source in [('before', HERE / 'http2.before.cc'),
                    ('candidate', HERE / 'http2.candidate.cc')]:
    command = next(x['argv'] for x in old if x['name'] == 'compile-candidate')
    command = command[:-4] + ['-c', str(source), '-o', str(BUILD / (arm + '.o'))]
    run('compile-' + arm, command)

command = next(x['argv'] for x in old if x['name'] == 'compile-tests')
command = command[:-4] + ['-c', str(HERE / 'http2_test.candidate.cc'),
                         '-o', str(BUILD / 'test.o')]
run('compile-tests', command)
link = next(x['argv'] for x in old if x['name'] == 'link-tests')
for arm in ('before', 'candidate'):
    args = []
    for arg in link:
        if arg.endswith('/http2_tests'):
            arg = str(BUILD / (arm + '-tests'))
        elif arg.endswith('/http2-candidate.o'):
            arg = str(BUILD / (arm + '.o'))
        elif arg.endswith('/http2_test.o'):
            arg = str(BUILD / 'test.o')
        args.append(arg)
    run('link-' + arm, args)

filter_arg = '--gtest_filter=IoHttp2.StreamsFragmentedBodiesAndPublishesTrailersAtEnd'
run('before-regression', ['timeout', '--kill-after=2s', '15s', 'taskset', '-c',
                         '2,3', BUILD / 'before-tests', filter_arg], expected=1)
run('candidate-http2-tests', ['timeout', '--kill-after=2s', '25s', 'taskset', '-c',
                            '2,3', BUILD / 'candidate-tests'])
env = os.environ.copy()
env['HYLE_IO_FORCE_EPOLL'] = '1'
run('candidate-epoll-regression', ['timeout', '--kill-after=2s', '15s', 'taskset',
                                  '-c', '2,3', BUILD / 'candidate-tests', filter_arg],
    env=env)

inputs = {Path(x).resolve() for x in link if x.endswith(('.o', '.a'))
          and not x.endswith(('/http2-candidate.o', '/http2_test.o'))}
loader = run('loader', ['ldd', BUILD / 'candidate-tests'])
for line in loader.splitlines():
    if 'libhyle_' in line and '=>' in line:
        inputs.add(Path(line.split('=>', 1)[1].strip().split()[0]).resolve())
(HERE / 'build-identity.json').write_text(json.dumps(dict(
    reuse=[identity(p) for p in sorted(inputs)],
    fresh=[identity(p) for p in sorted(BUILD.iterdir()) if p.is_file()],
    sdk_copy_or_download=False, configure_or_foundation_rebuild=False), indent=2) + '\n')
(HERE / 'cleanup-candidates.json').write_text(json.dumps(dict(
    directory=str(BUILD), files=[identity(p) for p in sorted(BUILD.iterdir())
                                if p.is_file()],
    action='Root test.ps1 exact cleanup only; no deletion performed.'), indent=2) + '\n')
