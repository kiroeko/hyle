from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/header-lifetime'
BASE=Path('/root/hyle-scratch/http2-current-20261018')
OUT=BASE/'header-lifetime'
ENV={k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_','HYLE_IO_FORCE_'))}
ENV['LD_LIBRARY_PATH']=str(BASE/'current-holdout')+':/root/hyle-scratch/io-watch-v2-dev/bin'
LOG=HERE/'holdout-commands.json';records=json.loads(LOG.read_text()) if LOG.exists() else []
def rec(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(name,argv,env=ENV):
    assert not any(x['name']==name for x in records),'No overwritten/retried attempt'
    argv=list(map(str,argv));p=subprocess.run(argv,cwd=OUT,env=env,capture_output=True,text=True,timeout=60)
    (HERE/(name+'.stdout.txt')).write_text(p.stdout);(HERE/(name+'.stderr.txt')).write_text(p.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(OUT),exit=p.returncode,
        environment={k:v for k,v in env.items() if k.startswith(('LD_LIBRARY_PATH','HYLE_'))}))
    LOG.write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,p.stdout[-1700:],p.stderr[-800:],flush=True)
    if p.returncode:raise RuntimeError(name)
    return p.stdout
if sys.argv[1]=='build':
    prior=HERE.parent/'current-holdout-status'
    peer=ROOT/'bench/io_http2/http2_p1_bench.cc'
    assert peer.read_bytes()==(prior/'http2_p1_bench.cc').read_bytes()
    stage3=(HERE.parent/'current-holdout/http2_p1_bench.cc').read_text()
    only_startup=stage3.replace('  std::thread worker_;\n','',1).replace('  bool stopping_ = false;\n',
        '  bool stopping_ = false;\n  // The worker can run immediately, so initialize every field it reads first.\n  std::thread worker_;\n',1)
    assert peer.read_text()==only_startup
    assert (HERE/'http2.before.cc').read_bytes()==(HERE.parent/'fixed-send-frame/http2.applied.cc').read_bytes()
    assert (HERE/'http2.measured.cc').read_bytes()==(ROOT/'src/io_http2/http2.cc').read_bytes()
    (HERE/'holdout.cc').write_bytes((prior/'main.cc').read_bytes())
    (HERE/'http2_p1_bench.cc').write_bytes(peer.read_bytes())
    old=json.loads((HERE.parent/'current-build-commands.json').read_text())
    cmd=next(x['argv'] for x in old if x['name']=='bench_io_http2_http2_p1_bench.cc')
    run('compile-holdout',cmd[:-4]+['-c',HERE/'holdout.cc','-o',OUT/'holdout.o'])
    raw=next(x['argv'] for x in old if x['name']=='link')
    variants={'old':BASE/'fixed-send-frame/http2.o','new':OUT/'http2.o'}
    links=[]
    for arm,obj in variants.items():
        link=[str(OUT/('holdout-'+arm)) if x==str(BASE/'http2_current') else
            str(obj) if x==str(BASE/'src_io_http2_http2.cc.o') else
            str(OUT/'holdout.o') if x==str(BASE/'bench_io_http2_http2_p1_bench.cc.o') else x for x in raw]
        run('link-holdout-'+arm,link)
        loader=run('loader-holdout-'+arm,['ldd',OUT/('holdout-'+arm)])
        assert str(BASE/'current-holdout/libhyle_io_core.so.0.1.0') in loader
        smoke=ENV.copy();smoke['HYLE_BENCH_SMOKE']='1'
        run('smoke-holdout-'+arm,['taskset','-c','2','timeout','--kill-after=2s','20s',OUT/('holdout-'+arm)],smoke)
        links.extend(Path(x) for x in link if x.endswith(('.o','.a')))
    (HERE/'holdout-identity.json').write_text(json.dumps(dict(
        sources=[rec(HERE/'holdout.cc'),rec(HERE/'http2_p1_bench.cc')],
        stage3_peer=rec(HERE.parent/'current-holdout/http2_p1_bench.cc'),
        actual_core=rec(BASE/'current-holdout/libhyle_io_core.so.0.1.0'),
        linked_inputs=[rec(p) for p in sorted(set(links))],
        executables=[rec(OUT/('holdout-'+v)) for v in ['old','new']],
        plan='outerold,new,new,old; first2Hylethenpeer, last2peerthenHyle; original9epochs2armsperprocess=72epochs, noinstrumentation/AA/retry/shapechange.',
        baseline='RetainedStatus-helperfixed object. Recordedmeasured/appliedformatonlydiff; savedbefore sourcebyteidentical toitsappliedsource. No baselineTUrebuild.'),indent=2)+'\n')
elif sys.argv[1]=='formal':
    assert any(x['name']=='smoke-holdout-old' and x['exit']==0 for x in records)
    assert any(x['name']=='smoke-holdout-new' and x['exit']==0 for x in records)
    assert not any(x['name'].startswith('formal-') for x in records),'Noformalretries'
    assert (HERE/'http2.measured.cc').read_bytes()==(ROOT/'src/io_http2/http2.cc').read_bytes()
    assert (HERE/'http2_p1_bench.cc').read_bytes()==(ROOT/'bench/io_http2/http2_p1_bench.cc').read_bytes()
    for index,arm in enumerate(['old','new','new','old']):
        env=ENV.copy();env['HYLE_BENCH_JSON']=str(HERE/('epochs-'+str(index)+'-'+arm))
        if index>=2:env['HYLE_BENCH_RIVAL_FIRST']='1'
        run('formal-'+str(index)+'-'+arm,['taskset','-c','2','timeout','--kill-after=2s','30s',OUT/('holdout-'+arm)],env)
else:raise RuntimeError('Unknownphase')
