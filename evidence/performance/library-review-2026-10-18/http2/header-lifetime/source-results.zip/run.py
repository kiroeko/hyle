from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/header-lifetime'
BASE=Path('/root/hyle-scratch/http2-current-20261018')
OUT=BASE/'header-lifetime';OUT.mkdir(exist_ok=True)
CACHE=Path('/root/hyle-scratch/io-watch-v2-dev')
ENV=os.environ.copy();ENV['LD_LIBRARY_PATH']=str(BASE/'current-holdout')+':'+str(CACHE/'bin')
for k in list(ENV):
    if k.startswith(('HYLE_BENCH_','HYLE_PERF_','HYLE_IO_FORCE_')):ENV.pop(k)
records=[]
def rec(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(name,argv,env=ENV):
    assert not (HERE/(name+'.stdout.txt')).exists(),'No overwritten attempts'
    argv=list(map(str,argv));p=subprocess.run(argv,cwd=OUT,env=env,capture_output=True,text=True,timeout=60)
    (HERE/(name+'.stdout.txt')).write_text(p.stdout);(HERE/(name+'.stderr.txt')).write_text(p.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(OUT),exit=p.returncode,
        environment={k:v for k,v in env.items() if k.startswith(('LD_LIBRARY_PATH','HYLE_'))}))
    (HERE/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,p.stdout[-1300:],p.stderr[-800:],flush=True)
    if p.returncode:raise RuntimeError(name)
    return p.stdout

(HERE/'http2.measured.cc').write_bytes((ROOT/'src/io_http2/http2.cc').read_bytes())
assert (HERE/'http2_test.cc').read_bytes()==(ROOT/'tests/io_http2/http2_test.cc').read_bytes()
(HERE/'feature_test.cc').write_bytes((ROOT/'tests/io_http2/feature_test.cc').read_bytes())
prior=json.loads((HERE.parent/'build-candidate-commands.json').read_text())
run('compiler',['g++-14','--version'])
run('system',['uname','-a'])
cmd=next(x['argv'] for x in prior if x['name']=='compile-candidate')
run('compile-http2',cmd[:-4]+['-c',HERE/'http2.measured.cc','-o',OUT/'http2.o'])
cmd=next(x['argv'] for x in prior if x['name']=='compile-tests')
run('compile-tests',cmd[:-4]+['-c',HERE/'http2_test.cc','-o',OUT/'http2_test.o'])
link=next(x['argv'] for x in prior if x['name']=='link-tests')
link=[str(OUT/'tests') if x==str(BASE/'http2_tests') else
      str(OUT/'http2.o') if x==str(BASE/'http2-candidate.o') else
      str(OUT/'http2_test.o') if x==str(BASE/'http2_test.o') else x for x in link]
run('link-tests',link)
loader=run('loader',['ldd',OUT/'tests'])
assert str(BASE/'current-holdout/libhyle_io_core.so.0.1.0') in loader
run('default-tests',['timeout','--kill-after=2s','20s',OUT/'tests','--gtest_output=json:'+str(HERE/'default-tests.json')])
epoll=ENV.copy();epoll['HYLE_IO_FORCE_EPOLL']='1'
run('epoll-tests',['timeout','--kill-after=2s','20s',OUT/'tests','--gtest_output=json:'+str(HERE/'epoll-tests.json')],epoll)

symbol='_ZN4hyle2io6detail17Http2SessionState13create_streamEi'
code=[]
for variant,obj in [('before',BASE/'fixed-send-frame/http2.o'),('after',OUT/'http2.o')]:
    symbols=run(variant+'-nm',['nm','-S','--defined-only',obj])
    line=next(s for s in symbols.splitlines() if s.split()[-1]==symbol)
    address,size=map(lambda x:int(x,16),line.split()[:2])
    code.append(dict(variant=variant,object=rec(obj),symbol=symbol,address=address,bytes=size))
    run(variant+'-create-stream-disassembly',['objdump','-drw','--section=.text',
        '--start-address='+hex(address),'--stop-address='+hex(address+size),obj])
inputs={Path(x) for x in link if x.endswith(('.o','.a'))}
for line in loader.splitlines():
    if 'libhyle_' in line and '=>' in line:inputs.add(Path(line.split('=>',1)[1].strip().split()[0]))
(HERE/'build-identity.json').write_text(json.dumps(dict(
    fresh_sources=[rec(HERE/x) for x in ['http2.measured.cc','http2_test.cc']],
    baseline_source=rec(HERE/'http2.before.cc'),
    retained_feature=dict(object=rec(BASE/'feature_test.o'),current_source=rec(HERE/'feature_test.cc'),
        note='Feature test small retained object reused, not freshlycompiled. Actual protocoltestTU was freshlycompiled from currentcanonical.'),
    inputs=[rec(p) for p in sorted(inputs)],code=code,
    current_proactor=rec(ROOT/'src/io_core/proactor.cc'),
    artifacts=[rec(p) for p in sorted(OUT.iterdir())],
    method='Only currentHTTP2 and currentprotocoltestTUs fresh. Actualretainedcurrentcoreoverride resolved; remainingfoundation/nativecache retained, notwholeHEADbuild.'),indent=2)+'\n')
(HERE/'cleanup-candidates.json').write_text(json.dumps(dict(host='WSL',files=[rec(p) for p in sorted(OUT.iterdir())],
    total_bytes=sum(p.stat().st_size for p in OUT.iterdir()),
    note='Only3freshheader-lifetime artifacts; no sharedcache objects. No deletion performed.'),indent=2)+'\n')
