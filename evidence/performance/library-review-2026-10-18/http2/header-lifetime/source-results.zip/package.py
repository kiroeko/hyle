from pathlib import Path
import difflib
import hashlib
import json
import math
import statistics
import subprocess
import zipfile

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/header-lifetime'
BASE = Path('/root/hyle-scratch/http2-current-20261018')
OUT = BASE / 'header-lifetime'


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


measured = HERE / 'http2.measured.cc'
applied = ROOT / 'src/io_http2/http2.cc'
assert measured.read_bytes() == applied.read_bytes()
(HERE / 'http2.applied.cc').write_bytes(applied.read_bytes())
(HERE / 'product.diff').write_text(''.join(difflib.unified_diff(
    (HERE / 'http2.before.cc').read_text().splitlines(True),
    measured.read_text().splitlines(True),
    fromfile='src/io_http2/http2.cc before', tofile='src/io_http2/http2.cc measured')))

# Preserve the exact source of the retained old object, including its recorded
# formatting-only difference from the current-before source. No object rebuilt.
prior = HERE.parent / 'fixed-send-frame'
for old, new in [('http2.candidate.cc', 'old-object-measured.cc'),
                 ('measured-to-applied.diff', 'old-object-to-before.diff'),
                 ('commands.json', 'old-object-commands.json')]:
    (HERE / new).write_bytes((prior / old).read_bytes())
assert (HERE / 'http2.before.cc').read_bytes() == (prior / 'http2.applied.cc').read_bytes()

peer = HERE / 'http2_p1_bench.cc'
assert peer.read_bytes() == (ROOT / 'bench/io_http2/http2_p1_bench.cc').read_bytes()
stage3 = (HERE.parent / 'current-holdout/http2_p1_bench.cc').read_text()
only_startup = stage3.replace('  std::thread worker_;\n', '', 1).replace(
    '  bool stopping_ = false;\n',
    '  bool stopping_ = false;\n  // The worker can run immediately, so initialize every field it reads first.\n  std::thread worker_;\n', 1)
assert peer.read_text() == only_startup
(HERE / 'stage3-to-current-peer.diff').write_text(''.join(difflib.unified_diff(
    stage3.splitlines(True), peer.read_text().splitlines(True),
    fromfile='stage3 peer', tofile='current canonical peer')))

build = json.loads((HERE / 'build-identity.json').read_text())
holdout = json.loads((HERE / 'holdout-identity.json').read_text())
commands = json.loads((HERE / 'commands.json').read_text())
formal_commands = json.loads((HERE / 'holdout-commands.json').read_text())
assert all(x['exit'] == 0 for x in commands + formal_commands)
assert len([x for x in formal_commands if x['name'].startswith('formal-')]) == 4

processes = []
for index, variant in enumerate(['old', 'new', 'new', 'old']):
    name = f'epochs-{index}-{variant}-4.json'
    raw = json.loads((HERE / name).read_text())
    assert len(raw['results']) == 2
    arms = []
    for arm in raw['results']:
        assert arm['batch'] == 4 and arm['epochs'] == 9 and len(arm['measurements']) == 9
        assert arm['minEpochTime'] == .001 and arm['minEpochIterations'] == 5
        elapsed = [row['elapsed'] for row in arm['measurements']]
        median = statistics.median(elapsed)
        assert math.isclose(median, arm['median(elapsed)'], rel_tol=1e-12)
        epochs = [dict(iterations=row['iterations'], seconds_per_episode=row['elapsed'],
                       actual_duration_seconds=row['iterations'] * row['elapsed'],
                       microseconds_per_stream=row['elapsed'] * 1e6 / arm['batch'])
                  for row in arm['measurements']]
        arms.append(dict(name=arm['name'], median_microseconds_per_stream=median * 1e6 / 4,
                         epoch_microseconds_per_stream_range=[min(elapsed) * 1e6 / 4,
                                                              max(elapsed) * 1e6 / 4],
                         median_absolute_percent_error=arm['medianAbsolutePercentError(elapsed)'],
                         measured_clock_resolution_seconds=arm['clockResolution'],
                         epochs=epochs))
    hyle = next(a for a in arms if a['name'].startswith('HYLE'))
    peer_arm = next(a for a in arms if a['name'].startswith('nghttp2'))
    ratio = hyle['median_microseconds_per_stream'] / peer_arm['median_microseconds_per_stream']
    processes.append(dict(index=index, variant=variant,
                          inner_order='Hyle then peer' if index < 2 else 'peer then Hyle',
                          raw=name, arms=arms, hyle_over_peer_ratio=ratio,
                          hyle_slower_than_same_process_peer_percent=(ratio - 1) * 100))


def arm_value(process, prefix):
    return next(a['median_microseconds_per_stream'] for a in process['arms']
                if a['name'].startswith(prefix))


pairs = []
for old_index, new_index in [(0, 1), (3, 2)]:
    old, new = processes[old_index], processes[new_index]
    pairs.append(dict(old_process=old_index, new_process=new_index,
                      inner_order=old['inner_order'],
                      new_over_old_hyle_percent=(arm_value(new, 'HYLE') / arm_value(old, 'HYLE') - 1) * 100,
                      new_over_old_peer_percent=(arm_value(new, 'nghttp2') / arm_value(old, 'nghttp2') - 1) * 100,
                      new_over_old_normalized_hyle_peer_percent=(new['hyle_over_peer_ratio'] /
                          old['hyle_over_peer_ratio'] - 1) * 100))

ranges = {}
for variant in ['old', 'new']:
    selected = [p for p in processes if p['variant'] == variant]
    ranges[variant] = dict(
        hyle_process_median_microseconds_per_stream_range=[min(arm_value(p, 'HYLE') for p in selected),
                                                           max(arm_value(p, 'HYLE') for p in selected)],
        peer_process_median_microseconds_per_stream_range=[min(arm_value(p, 'nghttp2') for p in selected),
                                                           max(arm_value(p, 'nghttp2') for p in selected)],
        hyle_slower_than_same_process_peer_percent_range=[min(p['hyle_slower_than_same_process_peer_percent'] for p in selected),
                                                         max(p['hyle_slower_than_same_process_peer_percent'] for p in selected)])

tests = []
for name, backend in [('default-tests.json', 'default configured backend'),
                      ('epoll-tests.json', 'same executable with HYLE_IO_FORCE_EPOLL=1')]:
    result = json.loads((HERE / name).read_text())
    assert result['tests'] == 15 and result['failures'] == result['errors'] == result['disabled'] == 0
    tests.append(dict(backend=backend, tests=15, failures=0, time=result['time'], raw=name,
                      names=[s['name'] + '.' + t['name'] for s in result['testsuites'] for t in s['testsuite']]))

fresh = [rec(OUT / x) for x in ['http2.o', 'http2_test.o', 'tests', 'holdout.o', 'holdout-old', 'holdout-new']]
retain_names = {'http2.o', 'http2_test.o'}
retain = [f for f in fresh if Path(f['path']).name in retain_names]
cleanup = [f for f in fresh if Path(f['path']).name not in retain_names]
old_object = BASE / 'fixed-send-frame/http2.o'
core = BASE / 'current-holdout/libhyle_io_core.so.0.1.0'
write('cleanup-candidates.json', dict(
    host='WSL', root=str(OUT), files=cleanup, total_bytes=sum(f['bytes'] for f in cleanup),
    retain_small_current_cache=retain, retained_bytes=sum(f['bytes'] for f in retain),
    retain_shared_current_core=[rec(core)],
    optional_superseded_old_baseline=dict(file=rec(old_object),
        reason='May be removed after root accepts this batch; exact old source, compile command and object identity are archived. Not needed by current tests/candidate. Not included in current-batch cleanup total.'),
    excluded='All other existing foundation, native dependency, library and feature objects are shared and unchanged.',
    note='Exact candidates only; no deletion performed. Parent writes and executes test.ps1.'))

summary = dict(
    result='Keep the minimal removal of capacity-sized initialization work. These four processes do not establish a throughput improvement; the current candidate remains slower than its same-process manual peer.',
    head_at_packaging=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
    scope=dict(product_file='src/io_http2/http2.cc', trace='Only original 4 streams x256KiB request/response holdout',
               outer_order=['old', 'new', 'new', 'old'], inner_order=['Hyle then peer', 'Hyle then peer', 'peer then Hyle', 'peer then Hyle'],
               processes=4, epochs_per_arm=9, arms_per_process=2, all_72_epochs_retained=True,
               full_smoke='One complete original oracle episode per variant before formal; each returned Hyle=4, peer=4.',
               extra_AA_shapes_probes_or_formal_retries=False, terminal_capture=False),
    change=dict(actual_entries='StoredHeader is construct_at only after both field appends succeed; HttpHeader views are construct_at only for the published count.',
                lifetime='Both types are statically required to be trivially destructible. Capacity storage is independently deallocated without destructing unconstructed entries. Repeated same-type non-const replacement is intentional.',
                unchanged='Both capacity allocations, their order, overflow/OOM checks, limits, bytes, alignment, field append and transport/protocol work remain unchanged. This saves initialization work, not allocated capacity.',
                removed_work='Four max_header_count value-construction loops per stream; at default 128 this is 512 capacity objects per stream. Trivial destructor loops already compile away in the baseline, so no destructor speedup is claimed.'),
    static_review=dict(informational='Informational headers reset count and byte storage without materializing views; overwritten same-type entries are transparently replaced, unused suffix is never read.',
                       repeated_views='Each new HttpHeader value is computed from StoredHeader/ByteBuffer before construct_at; no old HttpHeader value is read. Only [0,count) is exposed as a contiguous span.',
                       partial_initialization='No capacity object is assumed live. Each non-null allocation is deallocated separately even when the other allocation fails; count increments only after both field appends succeed.',
                       address='The views allocation starts at a byte offset, not typed pointer arithmetic across unused StoredHeader capacity. Existing alignment and size-overflow preflight are retained.',
                       limits='No new targeted informational/OOM case or allocation probe; these lifetime boundaries are supported by source analysis. Existing multi-header/trailer/stable-view regressions ran.',
                       independent_review='configuration_consistency_scan reviewed lifetime/count reuse; backend_assembly_design independently recomputed all four medians and Hyle/peer ratios.'),
    static_object_observation=dict(compiler='GCC 14.2.0, same -O3 closure flags recorded in commands',
                                  create_stream_code_bytes_before=4767, create_stream_code_bytes_after=1559,
                                  interpretation='The old object contains capacity zero-store loops absent in the candidate. Code-size reduction is not a measured time attribution.'),
    tests=tests,
    method=dict(toolchain=(HERE / 'compiler.stdout.txt').read_text().splitlines()[0],
                system=(HERE / 'system.stdout.txt').read_text().strip(),
                hardware='Same Windows-host WSL system and process taskset CPU 2 as the retained holdout closure; no new hardware/topology snapshot was collected in this batch.',
                fresh='Current HTTP2 and protocol-test TUs plus the unchanged canonical one-holdout wrapper TU. No whole-HEAD rebuild, configure, dependency download, SDK staging or native-library rebuild.',
                baseline='Reused the saved private-Status-helper-fixed old HTTP2 object. Exact measured source and its formatting-only applied difference are archived. Current before source is byte-identical to that applied source.',
                core='Both tests and both holdout loaders resolve the retained current-holdout core override. Its SHA and current proactor source SHA are recorded; remaining foundation/nghttp2 caches are retained, not rebuilt.',
                feature='Only the protocol test TU is fresh; the one-test feature object is reused with its exact hash and current source snapshot.',
                affinity='All formal processes were launched with taskset -c 2. The original configured harness owns caller + one Scheduler worker + one RawHarness worker. No in-formal TID/backend/affinity snapshot was collected.',
                boundary='Original run_workload warm episodes, nine epochs, min five iterations and original 1ms target, full body/header/reverse completion, socket/session/handoff cleanup boundaries are unchanged.',
                peer='Current canonical peer is byte-identical to the preceding current-holdout-status source. Relative to stage3, only the worker member initialization-order race fix and its comment differ; the source diff is archived.',
                counters='perf_event_open unavailable warning preserved. Zero hardware counter fields are not measurements. Reported clock resolution is separate from process-to-process drift.'),
    processes=processes, same_inner_order_pairs=pairs, process_median_ranges=ranges,
    conclusion=dict(current_residual='Candidate Hyle/peer residuals are the two new-process points and range recorded below; old controls and every raw epoch remain alongside them.',
                    performance='New Hyle absolute medians are slightly lower, while its peer medians are also lower by a larger amount; normalized Hyle/peer is worse in both matched inner orders. No demonstrated throughput gain, equivalence or confidence interval is claimed.',
                    attribution='Do not subtract older rounds (including the previous 14.7-17.1% residual) from this round or attribute their difference to this source change. Four processes do not identify time spent in the deleted initialization.',
                    application='Parent reviewed and authorized retaining this bounded redundant-work deletion; parent owns final commit and cleanup.'),
    source_identities=dict(before=rec(HERE / 'http2.before.cc'), old_object_measured_source=rec(HERE / 'old-object-measured.cc'),
                           measured=rec(measured), applied=rec(HERE / 'http2.applied.cc'), measured_equals_applied=True,
                           canonical_peer=rec(peer), current_proactor=build['current_proactor']),
    identity_files=['build-identity.json', 'holdout-identity.json', 'commands.json', 'holdout-commands.json', 'old-object-commands.json'],
    failures='No compile, link, test, smoke or formal failure in this batch. All attempts and stderr, including empty stderr, are retained.',
    artifacts='Exact four cleanup candidates and two small current cache objects are listed in cleanup-candidates.json; shared core and optional superseded baseline are explicitly separate. No files deleted.')
write('summary.json', summary)

archive = HERE / 'source-results.zip'
exclude = {'source-results.zip', 'archive-record.json'}
files = sorted(p for p in HERE.iterdir() if p.is_file() and p.name not in exclude)
assert all(p.suffix.lower() not in {'.o', '.a', '.so', '.exe', '.dll', '.obj', '.lib'} for p in files)
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for p in files:
        zipped.write(p, p.name)
    assert zipped.testzip() is None
write('archive-record.json', dict(
    archive=rec(archive), members=len(files), summary=rec(HERE / 'summary.json'),
    cleanup=rec(HERE / 'cleanup-candidates.json'),
    note='Source, commands, all raw results, static disassembly and logs only. No executables, objects, libraries, SDK or dependency source copies.'))
print(json.dumps(dict(processes=[dict(index=p['index'], variant=p['variant'],
    hyle_us=arm_value(p, 'HYLE'), peer_us=arm_value(p, 'nghttp2'), ratio=p['hyle_over_peer_ratio'],
    residual_percent=p['hyle_slower_than_same_process_peer_percent']) for p in processes],
    pairs=pairs, ranges=ranges, archive=rec(archive), summary=rec(HERE / 'summary.json'),
    cleanup_bytes=sum(f['bytes'] for f in cleanup), retain_bytes=sum(f['bytes'] for f in retain)), indent=2))
