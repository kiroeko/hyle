#define main original_bench_main
#include "diag_bench.cc"
#undef main
#include <dirent.h>
extern "C" const std::uint64_t *http2_diag_values() noexcept;
static int thread_count() { auto *d=opendir("/proc/self/task"); int n=0; if(d){while(auto *e=readdir(d))if(e->d_name[0]>='0'&&e->d_name[0]<='9')++n; closedir(d);} return n; }
int main(int argc, char **argv) {
  std::signal(SIGPIPE, SIG_IGN);
  if(argc!=2) return 2;
  const bool peer_route = std::string_view(argv[1]) == "peer";
  const Workload workload = make_workload("untimed holdout", 4, 256*1024, 256*1024, NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness hyle; RawHarness peer;
  const int threads_before=thread_count();
  const int completed = peer_route ? peer.run(workload) : hyle.run(workload);
  std::printf("{\"route\":\"%s\",\"completed\":%d,\"threads_before\":%d,\"threads_after\":%d,\"counts\":{",argv[1],completed,threads_before,thread_count());
  const char *labels[] = {"recv_attempts","recv_ready","recv_would_block","recv_other","recv_bytes","send_attempts","send_ready","send_would_block","send_other","send_bytes","write_yields","read_yields","async_read","async_write","notify_owner","notify_cancel","wait_for_change","inbound_copy_calls","inbound_copy_bytes","inbound_compaction_calls","inbound_compaction_bytes","wire_copy_calls","wire_copy_bytes","direction_claim_busy","process_received","body_ack_calls","body_ack_bytes","outbound_copy_calls","outbound_copy_bytes","stream_find"};
  const auto *values = peer_route ? raw_diag : http2_diag_values();
  for(int i=0;i<30;++i) std::printf("%s\"%s\":%llu",i?",":"",labels[i],static_cast<unsigned long long>(values[i]));
  std::printf("}}\n");
  return completed==4 ? 0 : 3;
}
