void report_thread(const char *) noexcept;
#define main unused_bench_main
#include "resources_bench.cc"
#undef main
#include <sched.h>
#include <sys/syscall.h>
void report_thread(const char *role) noexcept {
  cpu_set_t affinity; CPU_ZERO(&affinity);
  const int error=sched_getaffinity(0,sizeof(affinity),&affinity);
  std::string line=std::string(R"json({"role":")json")+role+R"json(","tid":)json"+std::to_string(syscall(SYS_gettid))+R"json(,"affinity_errno":)json"+std::to_string(error?errno:0)+R"json(,"logical_cpus":[)json";
  bool comma=false; for(int i=0;i<CPU_SETSIZE;++i)if(CPU_ISSET(i,&affinity)){if(comma)line+=",";line+=std::to_string(i);comma=true;}
  line+="]}"; std::fprintf(stderr,"%s\n",line.c_str());
}
int main() { HyleHarness hyle; RawHarness peer; report_thread("external-caller"); hyle.diag_resources(); return 0; }
