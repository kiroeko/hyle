import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2'
WORK = HERE / 'write-first'
for relative, name in [('src/io_http2/http2.cc', 'http2-final-product.cc'),
                       ('tests/io_http2/http2_test.cc', 'http2-final-test.cc'),
                       ('bench/io_http2/http2_p1_bench.cc', 'http2-final-bench.cc')]:
    shutil.copyfile(ROOT / relative, WORK / name)
assert hashlib.sha256((WORK / 'http2-final-product.cc').read_bytes()).hexdigest() == 'ef4a1febb929d19bb257671c279cef742c123b6175fc71f7d111605eaf63e3a5'
baseline = json.loads((HERE / 'diagnostic-hyle.log').read_text())
candidate = json.loads((WORK / 'diagnostic-hyle.log').read_text())
formal = []
for path in sorted(WORK.glob('postfix-*-*.json')):
    if path.stem.rsplit('-', 1)[-1] not in ['4', '64']:
        continue
    data = json.loads(path.read_text())
    formal.append({'file': path.name, 'ns_per_stream': {x['name']: x['median(elapsed)'] * 1e9 / x['batch'] for x in data['results']},
                   'epoch_counts': {x['name']: len(x['measurements']) for x in data['results']}})
times = [{'file': p.name, 'completion_log_write_utc': datetime.datetime.fromtimestamp(p.stat().st_mtime, datetime.timezone.utc).isoformat()} for p in sorted(WORK.glob('postfix-[0-3]-*.log'))]
summary = {
    'result': 'Current large-body holdout residual remains unresolved. Neither removing a duplicate notification nor retrying write before the second read established a repeatable latency gain. Both product candidates were reverted. Retain no current noninferiority/equivalence claim from historical PASS/PARITY.',
    'remaining_changes': {'benchmark': 'Monotonic peer next_response_pair skips retired response scheduling work; optional JSON exports all nanobench epochs after timing and smoke reports completion counts.',
                          'test': 'POSIX 4KiB-socket regression: peer reads partial fixed body then closes, writer must terminate with a non-deadline/non-cancel failure. Added test passes both candidate and unchanged product baseline.',
                          'product_http2_sha256': 'ef4a1febb929d19bb257671c279cef742c123b6175fc71f7d111605eaf63e3a5'},
    'diagnostic': {'baseline': baseline, 'write_first_candidate': candidate,
                   'delta': 'Candidate removes192 empty reads but adds63 empty writes, net129 fewer no-progress I/O attempts. Successful reads323/writes514, all copied payload/wire bytes, inbound compaction0,515 yields,1529 owner notifications, async read/write each1 and ownerwait0 are unchanged in these two observed episodes.',
                   'limits': 'One source-instrumented, strace-disturbed complete episode per original route and one Hyle candidate episode. No latency derived from counters/strace; io_uring kernel workers do not expose every I/O as a userspace syscall. Current code has no added counters or hot-path diagnostic branches.'},
    'write_first_candidate': {'source_sha256': hashlib.sha256((WORK / 'http2-write-first-candidate.cc').read_bytes()).hexdigest(),
                              'implementation': 'Keep pre-yield read and one cooperative yield/cancellation check. After yield, retry_write; Ready goes through the original sent-byte/error handling, any non-Ready keeps the original second read and async fallback.',
                              'tests': '14 protocol/feature tests plus forced-epoll duplex and peer-close2 tests all pass. Each baseline/candidate full-payload smoke passes64/64/4/4. Baseline-only new peer-close test separately passes after reverting product source.',
                              'timing': 'Original two journeys, two same-header baseline/candidate order pairs only. Candidate holdout195.419us vs baseline194.866us(+0.284%); other order194.119us vs197.019us(-1.472%). Peer179.850/193.177/184.246/200.068us varies materially. Small-body candidate also not consistently faster. No stable gain established; reverted.',
                              'identity': 'Both protocol TUs rebuilt using the same frozen header state and same existing foundation shared libraries, locked nghttp2_static and corrected peer/consumer. This is not a full HEAD rebuild.'},
    'resources': {'public_capabilities_and_affinity': [json.loads(line) for line in (HERE / 'resources.stderr.log').read_text().splitlines() if line],
                   'limit': 'Separate later resource-only process: actual backend2=kIoUring and one IO worker; caller and both OS worker TIDs affinity[2]. Observed diagnostic episode user threads3->3. Does not backfill formal-run snapshots. Earlier summary metadata taskset0-31 describes its metadata parent, not formal consumers.'},
    'fairness_and_next_direction': 'Both routes retain equal protocol/payload/flow-control/connection-lifetime/cleanup work with one active persistent worker plus external caller. Execution strategy differs: public Hyle drives two endpoint fibers and readiness machinery; direct adapter advances both endpoints in one manual loop. Review that thread/fiber work model next, without dropping public lifecycle responsibilities or collecting another copy of the same AB matrix.',
    'formal_results': formal, 'formal_log_completion_times': times,
    'background_io_check': 'Concat owner reported its~190MiB SHA pass at20:23:28.3-20:23:29.802UTC. Formal completion logs are20:22:39.559-20:22:39.976UTC, about48seconds earlier, so that reported activity did not overlap. This is not a claim that all system I/O was monitored. No additional samples taken.',
    'probe_errors': 'First write-first build orchestration hashed the vendor library under the small experiment subdirectory instead of its reused parent; compilation/link had succeeded. Corrected metadata path without rebuilding those objects. Earlier diagnostic/resource generator errors are recorded separately. No failed payload results or outliers removed.',
}
(HERE / 'stage2-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
# The native Windows Git snapshot is supplied separately; avoid a WSL Git
# scan of the Windows checkout while serializing this small evidence bundle.
assert (HERE / 'stage2-product.diff').is_file()
top = [p for p in HERE.iterdir() if p.is_file() and p.suffix in ['.json', '.log', '.strace', '.cc', '.py', '.diff'] and (p.name.startswith(('diag_', 'diagnostic-', 'resources', 'finalize_diagnostic', 'finalize_stage2', 'stage2-')) or p.name == 'diagnostic.py') and 'archive-record' not in p.name]
members = top + [p for p in WORK.rglob('*') if p.is_file() and p.suffix in ['.json', '.log', '.strace', '.cc', '.py', '.diff']]
archive = HERE / 'stage2-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(members): output.write(path, path.relative_to(HERE).as_posix())
record = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'member_count': len(members), 'excluded': 'No executables, objects, libraries, SDK or vendor source tree; stage1 archive remains separate and unchanged.'}
(HERE / 'stage2-archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
