#!/usr/bin/env python3
"""One untimed complete holdout per route. All counters are probe-only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2'
BUILD = Path('/root/hyle-scratch/http2-current-20261018')
commands = json.loads((HERE / 'build-commands.json').read_text())
records = []
labels = ['recv_attempts', 'recv_ready', 'recv_would_block', 'recv_other', 'recv_bytes',
          'send_attempts', 'send_ready', 'send_would_block', 'send_other', 'send_bytes',
          'write_yields', 'read_yields', 'async_read', 'async_write', 'notify_owner',
          'notify_cancel', 'wait_for_change', 'inbound_copy_calls', 'inbound_copy_bytes',
          'inbound_compaction_calls', 'inbound_compaction_bytes', 'wire_copy_calls',
          'wire_copy_bytes', 'direction_claim_busy', 'process_received', 'body_ack_calls',
          'body_ack_bytes', 'outbound_copy_calls', 'outbound_copy_bytes', 'stream_find']

def replace(text, old, new, expected=1):
    assert text.count(old) == expected, (old, text.count(old))
    return text.replace(old, new)

s = (ROOT / 'src/io_http2/http2.cc').read_text()
assert hashlib.sha256(s.encode()).hexdigest() == 'ef4a1febb929d19bb257671c279cef742c123b6175fc71f7d111605eaf63e3a5'
s = replace(s, '  void notify_owner() noexcept {', '  void notify_owner() noexcept {\n    ++h2_diag[14];')
s = replace(s, '  void notify_cancelled_wait() noexcept {', '  void notify_cancelled_wait() noexcept {\n    ++h2_diag[15];')
s = replace(s, '  Http2StreamState *find(std::int32_t id) noexcept {', '  Http2StreamState *find(std::int32_t id) noexcept {\n    ++h2_diag[29];')
s = replace(s, '                       std::uint64_t observed) noexcept {', '                       std::uint64_t observed) noexcept {\n  ++h2_diag[16];')
s = replace(s, '  if (busy)\n    return false;', '  if (busy) {\n    ++h2_diag[23];\n    return false;\n  }')
s = replace(s, '                                TransferResult received) noexcept {', '                                TransferResult received) noexcept {\n  ++h2_diag[24];')
s = replace(s, 'detail::http_transport_try_read(', 'diag_try_read(')
s = replace(s, 'detail::http_transport_try_write(', 'diag_try_write(', 2)
s = replace(s, '      sched::Fiber::yield();', '      ++h2_diag[10];\n      sched::Fiber::yield();', 2)
pos = s.index('template <class Ready>')
s = s[:pos] + s[pos:].replace('++h2_diag[10];', '++h2_diag[11];')
for name, counter in [('read', 12), ('write', 13)]:
    start = s.index('  static TransferResult ' + name + '(')
    insert = s.index(' noexcept {', start) + len(' noexcept {')
    s = s[:insert] + '\n    ++h2_diag[' + str(counter) + '];' + s[insert:]
s = replace(s, '    if (remaining != 0)\n      std::memmove(stream->inbound.data,\n                   stream->inbound.data + stream->inbound_start, remaining);', '    if (remaining != 0) {\n      ++h2_diag[19]; h2_diag[20] += remaining;\n      std::memmove(stream->inbound.data,\n                   stream->inbound.data + stream->inbound_start, remaining);\n    }')
s = replace(s, '  if (length != 0)\n    std::memcpy(stream->inbound.data + stream->inbound.size, data, length);', '  if (length != 0) {\n    ++h2_diag[17]; h2_diag[18] += length;\n    std::memcpy(stream->inbound.data + stream->inbound.size, data, length);\n  }')
s = replace(s, '    if (!state.wire.append(bytes, static_cast<std::size_t>(encoded),', '    ++h2_diag[21]; h2_diag[22] += encoded;\n    if (!state.wire.append(bytes, static_cast<std::size_t>(encoded),')
s = replace(s, '  if (consumed != 0) {', '  if (consumed != 0) {\n    ++h2_diag[25]; h2_diag[26] += consumed;')
s = replace(s, '    std::memcpy(buffer, stream->outbound_data + stream->outbound_offset, take);', '    ++h2_diag[27]; h2_diag[28] += take;\n    std::memcpy(buffer, stream->outbound_data + stream->outbound_offset, take);')
helpers = '''
std::uint64_t h2_diag[30]{};
ImmediateTransferResult diag_try_read(HttpTransport &transport, std::span<std::byte> bytes) noexcept {
  ++h2_diag[0]; auto r = http_transport_try_read(transport, bytes);
  if (r.state == ImmediateTransferState::kReady) { ++h2_diag[1]; h2_diag[4] += r.transfer.bytes; }
  else if (r.state == ImmediateTransferState::kWouldBlock) ++h2_diag[2]; else ++h2_diag[3];
  return r;
}
ImmediateTransferResult diag_try_write(HttpTransport &transport, std::span<const std::byte> bytes) noexcept {
  ++h2_diag[5]; auto r = http_transport_try_write(transport, bytes);
  if (r.state == ImmediateTransferState::kReady) { ++h2_diag[6]; h2_diag[9] += r.transfer.bytes; }
  else if (r.state == ImmediateTransferState::kWouldBlock) ++h2_diag[7]; else ++h2_diag[8];
  return r;
}
'''
s = replace(s, 'namespace detail {\n', 'namespace detail {\n' + helpers)
s += '\nextern "C" const std::uint64_t *http2_diag_values() noexcept { return hyle::io::detail::h2_diag; }\n'
(HERE / 'diag_http2.cc').write_text(s)

b = (ROOT / 'bench/io_http2/http2_p1_bench.cc').read_text()
b = replace(b, 'constexpr unsigned kOwner = 0;', 'std::uint64_t raw_diag[30]{};\nconstexpr unsigned kOwner = 0;')
b = replace(b, '  if (count != 0)\n    std::memcpy(buffer, body.data() + stream->sent, count);', '  if (count != 0) {\n    ++raw_diag[27]; raw_diag[28] += count;\n    std::memcpy(buffer, body.data() + stream->sent, count);\n  }')
b = replace(b, '    std::memmove(stream->inbound.data(),', '    ++raw_diag[19]; raw_diag[20] += buffered;\n    std::memmove(stream->inbound.data(),')
b = replace(b, '  if (length != 0)\n    std::memcpy(stream->inbound.data() + old_size, data, length);', '  if (length != 0) {\n    ++raw_diag[17]; raw_diag[18] += length;\n    std::memcpy(stream->inbound.data() + old_size, data, length);\n  }')
b = replace(b, '      stream.inbound_start += count;', '      ++raw_diag[25]; raw_diag[26] += count;\n      stream.inbound_start += count;')
b = replace(b, '    std::memcpy(wire.pending.data(), data, static_cast<std::size_t>(length));', '    ++raw_diag[21]; raw_diag[22] += length;\n    std::memcpy(wire.pending.data(), data, static_cast<std::size_t>(length));')
b = replace(b, '    const ssize_t written = ::write(', '    ++raw_diag[5];\n    const ssize_t written = ::write(')
b = replace(b, '    if (written > 0) {', '    if (written > 0) {\n      ++raw_diag[6]; raw_diag[9] += written;')
b = replace(b, '    if (written < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))\n      return true;', '    if (written < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {\n      ++raw_diag[7]; return true;\n    }')
b = replace(b, '    const ssize_t count =\n        ::read(', '    ++raw_diag[0];\n    const ssize_t count =\n        ::read(')
b = replace(b, '    if (count > 0) {', '    if (count > 0) {\n      ++raw_diag[1]; raw_diag[4] += count;')
b = replace(b, '    return errno == EAGAIN || errno == EWOULDBLOCK;', '    if (errno == EAGAIN || errno == EWOULDBLOCK) ++raw_diag[2]; else ++raw_diag[3];\n    return errno == EAGAIN || errno == EWOULDBLOCK;')
(HERE / 'diag_bench.cc').write_text(b)
wrapper = '''#define main original_bench_main
#include "diag_bench.cc"
#undef main
#include <dirent.h>
extern "C" const std::uint64_t *http2_diag_values() noexcept;
static int thread_count() { auto *d=opendir("/proc/self/task"); int n=0; if(d){while(auto *e=readdir(d))if(e->d_name[0]>='0'&&e->d_name[0]<='9')++n; closedir(d);} return n; }
int main(int argc, char **argv) {
  std::signal(SIGPIPE, SIG_IGN);
  if(argc!=2) return 2;
  const bool peer_route = std::string_view(argv[1]) == "peer";
  const Workload workload = make_workload("untimed holdout", 4, 256*1024, 256*1024, NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness hyle; RawHarness peer;
  const int threads_before=thread_count();
  const int completed = peer_route ? peer.run(workload) : hyle.run(workload);
  std::printf("{\\"route\\":\\"%s\\",\\"completed\\":%d,\\"threads_before\\":%d,\\"threads_after\\":%d,\\"counts\\":{",argv[1],completed,threads_before,thread_count());
  const char *labels[] = LABELS;
  const auto *values = peer_route ? raw_diag : http2_diag_values();
  for(int i=0;i<30;++i) std::printf("%s\\"%s\\":%llu",i?",":"",labels[i],static_cast<unsigned long long>(values[i]));
  std::printf("}}\\n");
  return completed==4 ? 0 : 3;
}
'''.replace('LABELS', '{' + ','.join(json.dumps(x) for x in labels) + '}')
(HERE / 'diag_main.cc').write_text(wrapper)

def run(name, argv, env=None):
    result = subprocess.run([str(x) for x in argv], cwd=BUILD, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=45)
    (HERE / (name + '.log')).write_text(result.stdout)
    (HERE / (name + '.stderr.log')).write_text(result.stderr)
    records.append({'name': name, 'argv': [str(x) for x in argv], 'returncode': result.returncode})
    (HERE / 'diagnostic-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stderr[-6000:]); raise SystemExit(result.returncode)

for key, source in [('src_io_http2_http2.cc', HERE / 'diag_http2.cc'), ('bench_io_http2_http2_p1_bench.cc', HERE / 'diag_main.cc')]:
    old = next(x['argv'] for x in commands if x['name'] == key)
    argv = old[:-4] + ['-c', str(source), '-o', str(BUILD / (key + '-diag.o'))]
    run('diagnostic-compile-' + key, argv)
link = next(x['argv'] for x in commands if x['name'] == 'link')
link = [str(BUILD / 'http2_diagnostic') if x.endswith('/http2_current') else str(BUILD / 'src_io_http2_http2.cc-diag.o') if x.endswith('/src_io_http2_http2.cc.o') else str(BUILD / 'bench_io_http2_http2_p1_bench.cc-diag.o') if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
run('diagnostic-link', link)
env = os.environ.copy()
for key in list(env):
    if key.startswith('HYLE_BENCH_'): env.pop(key)
for route in ['hyle', 'peer']:
    run('diagnostic-' + route, ['strace', '-f', '-yy', '-s', '32', '-o', HERE / ('diagnostic-' + route + '.strace'), '-e', 'trace=read,write,recvfrom,sendto,recvmsg,sendmsg,poll,ppoll,epoll_ctl,epoll_wait,futex,io_uring_setup,io_uring_enter,io_uring_register', 'taskset', '-c', '2', BUILD / 'http2_diagnostic', route], env)
(HERE / 'diagnostic-source-identity.json').write_text(json.dumps({str(p.name): hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE / 'diag_http2.cc', HERE / 'diag_bench.cc', HERE / 'diag_main.cc', BUILD / 'http2_diagnostic']}, indent=2) + '\n')
