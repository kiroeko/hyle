import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2'
BUILD = Path('/root/hyle-scratch/http2-current-20261018')
bench = (HERE / 'diag_bench.cc').read_text()
needle = '  ~HyleHarness() { scheduler_.shutdown(); }'
extra = r'''
  static Task<int> diag_task(AllocatorRef) noexcept {
    ::report_thread("hyle-scheduler-worker"); co_return 0;
  }
  void diag_resources() {
    const auto backend = io_.capabilities(0).backend;
    std::fprintf(stderr,R"json({"public_backend":%u,"io_workers":%u})json" "\n",static_cast<unsigned>(backend),io_.num_workers());
    auto join = hyle::sched::spawn_task(scheduler_,system_allocator(),diag_task(system_allocator()));
    auto result = join.join(); if(!result || *result!=0) std::abort();
  }
'''
assert bench.count(needle) == 1
bench = bench.replace(needle, needle + extra)
needle = '  void worker_loop() noexcept {\n'
assert bench.count(needle) == 1
bench = bench.replace(needle, needle + '    ::report_thread("nghttp2-direct-worker");\n')
(HERE / 'resources_bench.cc').write_text(bench)
main = r'''void report_thread(const char *) noexcept;
#define main unused_bench_main
#include "resources_bench.cc"
#undef main
#include <sched.h>
#include <sys/syscall.h>
void report_thread(const char *role) noexcept {
  cpu_set_t affinity; CPU_ZERO(&affinity);
  const int error=sched_getaffinity(0,sizeof(affinity),&affinity);
  std::string line=std::string(R"json({"role":")json")+role+R"json(","tid":)json"+std::to_string(syscall(SYS_gettid))+R"json(,"affinity_errno":)json"+std::to_string(error?errno:0)+R"json(,"logical_cpus":[)json";
  bool comma=false; for(int i=0;i<CPU_SETSIZE;++i)if(CPU_ISSET(i,&affinity)){if(comma)line+=",";line+=std::to_string(i);comma=true;}
  line+="]}"; std::fprintf(stderr,"%s\n",line.c_str());
}
int main() { HyleHarness hyle; RawHarness peer; report_thread("external-caller"); hyle.diag_resources(); return 0; }
'''
(HERE / 'resources_main.cc').write_text(main)
commands = json.loads((HERE / 'build-commands.json').read_text())
compile_args = next(x['argv'] for x in commands if x['name'] == 'bench_io_http2_http2_p1_bench.cc')
obj = BUILD / 'resources.o'
compile_args = compile_args[:-4] + ['-c', str(HERE / 'resources_main.cc'), '-o', str(obj)]
link = next(x['argv'] for x in commands if x['name'] == 'link')
link = [str(BUILD / 'http2_resources') if x.endswith('/http2_current') else str(BUILD / 'src_io_http2_http2.cc-diag.o') if x.endswith('/src_io_http2_http2.cc.o') else str(obj) if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
records = []
for name, argv in [('resources-compile', compile_args), ('resources-link', link), ('resources', ['taskset', '-c', '2', str(BUILD / 'http2_resources')])]:
    result = subprocess.run(argv, cwd=BUILD, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30)
    (HERE / (name + '.log')).write_text(result.stdout)
    (HERE / (name + '.stderr.log')).write_text(result.stderr)
    records.append({'name': name, 'argv': argv, 'returncode': result.returncode})
    (HERE / 'resources-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stderr[-5000:]); raise SystemExit(result.returncode)
(HERE / 'resources-source-identity.json').write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE / 'resources_bench.cc', HERE / 'resources_main.cc', BUILD / 'http2_resources']}, indent=2) + '\n')
