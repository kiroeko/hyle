import hashlib
import json
from pathlib import Path
import re
import zipfile

HERE = Path(__file__).resolve().parent
rows = {route: json.loads((HERE / ('diagnostic-' + route + '.log')).read_text()) for route in ['hyle', 'peer']}
derived = {}
for route in rows:
    events = []
    for lineno, line in enumerate((HERE / ('diagnostic-' + route + '.strace')).read_text().splitlines(), 1):
        matched = re.search(r'^\d+\s+(recvfrom|sendto|read|write)\((\d+)<UNIX-STREAM:.*\)\s+=\s+(-?\d+)(.*)$', line)
        if matched:
            op, fd, result, error = matched.groups()
            events.append({'line': lineno, 'op': op, 'fd': int(fd), 'result': int(result), 'eagain': 'EAGAIN' in error})
    pairs = []
    for first, second in zip(events, events[1:]):
        if first['op'] in ['recvfrom', 'read'] and first['eagain'] and second['op'] in ['sendto', 'write'] and second['result'] > 0 and first['fd'] == second['fd']:
            pairs.append([first['line'], second['line']])
    derived[route] = {'fully_printed_socket_events': len(events), 'adjacent_empty_read_then_successful_write_same_fd': len(pairs), 'line_pairs': pairs,
                      'limit': 'Only complete strace socket lines; unfinished/resumed calls and kernel-executed io_uring operations are not reconstructed. Adjacent here means after filtering to these socket calls, not elapsed-time causality.'}
resources = [json.loads(line) for line in (HERE / 'resources.stderr.log').read_text().splitlines() if line]
summary = {
    'method': 'One untimed 4x256KiB complete connection episode per Hyle/direct route. Same 4KiB sockets, full payload/status/length/reverse-order checks and teardown, both harnesses resident. Source-only owner-local uint64 counters, no atomics or locks added. strace perturbs execution; no timing result or latency cause is inferred.',
    'result': rows,
    'findings': ['Both routes copy exactly 2097152 inbound payload bytes in 384 callbacks, no inbound compaction, and 2097152 outbound provider bytes in 128 callbacks. This workload does not expose quadratic buffering or a Hyle-only full payload copy.',
                 'Wire copies are 2100151 Hyle vs 2100216 direct bytes (259 vs264 calls); both retain their own wire bytes across partial writes. Do not label Hyle wire.append as an extra copy absent from peer.',
                 'Hyle immediate receive attempts1032/709WouldBlock vs direct800/280WouldBlock, while send attempts772vs776 are close. Hyle yields256write/259read, asyncread/write each1, claim contention0 and ownerwait0. Counters identify additional empty receive/yield work, not its unperturbed time cost.',
                 'Public capabilities and actual affinity are from a separate cold resource-only process after the episode probes: backend2=kIoUring, one IO worker; external caller and both OS worker TIDs all affinity[2]. These do not backfill the formal measurements historical snapshots.'],
    'resource_only_probe': resources,
    'strace_auxiliary': derived,
    'next_candidate_not_yet_changed': 'After the bounded writer yield in flush_once, retry_write before the second try_read_once; read/asyncfallback only when still blocked. Keep pre-yield read assist and cancellation check. This could skip an empty receive when the peer has already made the socket writable, but requires independent semantic review and tests before performance claims.',
    'errors': 'Initial diagnostic generator asserted an ambiguous whitespace match before compiling; corrected to locate the named method. Resource-only first compilation failed on probe string escaping; exact failed sources/log retained. No failed product build and no dropped measurements.',
    'product_state': 'src/io_http2/http2.cc is unchanged; failed notify candidate reverted. Only benchmark peer cursor and raw result output retained.',
}
(HERE / 'diagnostic-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
members = [p for p in HERE.iterdir() if p.is_file() and (p.name.startswith(('diag_', 'diagnostic-', 'resources', 'finalize_diagnostic')) or p.name == 'diagnostic.py') and p.suffix in ['.json', '.log', '.strace', '.cc', '.py'] and 'archive-record' not in p.name]
archive = HERE / 'diagnostic-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(members): output.write(path, path.name)
record = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'member_count': len(members), 'excluded': 'No executables, object/static/shared libraries, SDK or vendor source tree.'}
(HERE / 'diagnostic-archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
print(json.dumps({key: {k: v for k, v in value.items() if k != 'line_pairs'} for key, value in derived.items()}))
