#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SOURCE = Path('/mnt/c/public/project-hyle/hyle')
BASE = SOURCE / '.scratch/perf-review-2026-10-18/http2'
RECORD = BASE / 'write-first'
BUILD = Path('/root/hyle-scratch/http2-current-20261018/write-first')
BUILD.mkdir(parents=True, exist_ok=True)
commands = json.loads((BASE / 'build-commands.json').read_text())
compile_command = next(x for x in commands if x['name'] == 'src_io_http2_http2.cc')
link_command = next(x for x in commands if x['name'] == 'link')
records = []

def run(name, argv, env=None):
    start = time.time()
    completed = subprocess.run(argv, cwd=BUILD, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=45)
    (RECORD / (name + '.log')).write_text(completed.stdout)
    records.append({'name': name, 'argv': [str(x) for x in argv], 'cwd': str(BUILD), 'environment': {key: value for key, value in (env or {}).items() if key.startswith('HYLE_')}, 'returncode': completed.returncode, 'elapsed_seconds': time.time() - start})
    (RECORD / (sys.argv[1] + '-candidate-commands.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(name, completed.returncode, flush=True)
    if completed.returncode:
        print(completed.stdout[-6000:])
        raise SystemExit(completed.returncode)

if sys.argv[1] == 'build':
    for arm, source in [('baseline', BASE / 'http2-baseline.cc'), ('candidate', SOURCE / 'src/io_http2/http2.cc')]:
        obj = BUILD / ('http2-' + arm + '.o')
        args = [str(source) if x.endswith('/src/io_http2/http2.cc') else str(obj) if x.endswith('/src_io_http2_http2.cc.o') else x for x in compile_command['argv']]
        run('compile-' + arm, args)
        link = [str(BUILD / ('http2_' + arm)) if x.endswith('/http2_current') else str(obj) if x.endswith('/src_io_http2_http2.cc.o') else x for x in link_command['argv']]
        run('link-' + arm, link)
    testobj = BUILD / 'http2_test.o'
    testflags = compile_command['argv'][:-4] + ['-I/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include']
    run('compile-tests', testflags + ['-c', str(SOURCE / 'tests/io_http2/http2_test.cc'), '-o', str(testobj)])
    featureobj = BUILD / 'feature_test.o'
    run('compile-feature-test', testflags + ['-c', str(SOURCE / 'tests/io_http2/feature_test.cc'), '-o', str(featureobj)])
    link = []
    for arg in link_command['argv']:
        if arg.endswith('/http2_current'):
            arg = str(BUILD / 'http2_tests')
        elif arg.endswith('/src_io_http2_http2.cc.o'):
            arg = str(BUILD / 'http2-candidate.o')
        elif arg.endswith('/bench_io_http2_http2_p1_bench.cc.o'):
            arg = str(testobj)
        elif arg.endswith('/bench_nanobench_impl.cc.o'):
            arg = str(featureobj)
        link.append(arg)
    link += ['/root/hyle-scratch/io-watch-v2-dev/lib/libgtest_main.a', '/root/hyle-scratch/io-watch-v2-dev/lib/libgtest.a']
    run('link-tests', link)

if sys.argv[1] in ['build', 'identity']:
    headers = {}
    for parent in [SOURCE / 'include/hyle', SOURCE / 'src/io_http2']:
        for path in parent.rglob('*.h'):
            headers[str(path.relative_to(SOURCE))] = hashlib.sha256(path.read_bytes()).hexdigest()
    identity = {'common_header_sha256': headers, 'protocol_sources': {}, 'images': {}, 'nghttp2_static_sha256': hashlib.sha256((BUILD.parent / 'nghttp2-build/lib/libnghttp2.a').read_bytes()).hexdigest()}
    for arm, path in [('baseline', BASE / 'http2-baseline.cc'), ('candidate', SOURCE / 'src/io_http2/http2.cc')]:
        identity['protocol_sources'][arm] = hashlib.sha256(path.read_bytes()).hexdigest()
        identity['images'][arm] = hashlib.sha256((BUILD / ('http2_' + arm)).read_bytes()).hexdigest()
    (RECORD / 'candidate-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
elif sys.argv[1] == 'tests':
    run('http2-tests', ['taskset', '-c', '2,3', str(BUILD / 'http2_tests')])
    env = os.environ.copy()
    env['HYLE_IO_FORCE_EPOLL'] = '1'
    run('http2-epoll-duplex-test', ['taskset', '-c', '2,3', str(BUILD / 'http2_tests'), '--gtest_filter=IoHttp2.DuplexProgressSurvivesSmallSocketAndFlowControl:IoHttp2.PeerCloseTerminatesBackpressuredFixedBodyWrite'], env)
    env.pop('HYLE_IO_FORCE_EPOLL')
    env['HYLE_BENCH_SMOKE'] = '1'
    for arm in ['baseline', 'candidate']:
        run('postfix-smoke-' + arm, ['taskset', '-c', '2', str(BUILD / ('http2_' + arm))], env)
elif sys.argv[1] == 'formal':
    for index, arm in enumerate(['baseline', 'candidate', 'candidate', 'baseline']):
        env = os.environ.copy()
        for key in ['HYLE_BENCH_SMOKE', 'HYLE_BENCH_RIVAL_FIRST', 'HYLE_BENCH_JSON']:
            env.pop(key, None)
        if index >= 2:
            env['HYLE_BENCH_RIVAL_FIRST'] = '1'
        name = 'postfix-' + str(index) + '-' + arm
        env['HYLE_PERF_RUN_NONCE'] = name
        env['HYLE_BENCH_JSON'] = str(RECORD / name)
        run(name, ['taskset', '-c', '2', str(BUILD / ('http2_' + arm))], env)
