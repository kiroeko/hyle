from pathlib import Path
import difflib,hashlib,json,os,subprocess,sys,time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/current-holdout-status'
PRIOR=HERE.parent
BASE=Path('/root/hyle-scratch/http2-current-20261018')
OUT=BASE/'current-holdout-status'
CORE=BASE/'current-holdout'
CACHE=Path('/root/hyle-scratch/io-watch-v2-dev')
ENV={k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_'))}
ENV['LD_LIBRARY_PATH']=str(CORE)+':'+str(CACHE/'bin')
LOG=HERE/'commands.json'
records=json.loads(LOG.read_text()) if LOG.exists() else []

def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(name,argv,env=ENV,timeout=60):
    if any(x['name']==name for x in records):raise RuntimeError('Refusing duplicate attempt '+name)
    argv=list(map(str,argv));start=time.time()
    p=subprocess.run(argv,cwd=OUT,env=env,capture_output=True,text=True,timeout=timeout)
    (HERE/(name+'.stdout.txt')).write_text(p.stdout)
    (HERE/(name+'.stderr.txt')).write_text(p.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(OUT),exit=p.returncode,
        started_unix=start,elapsed_seconds=time.time()-start,
        environment={k:v for k,v in env.items() if k.startswith(('LD_LIBRARY_PATH','HYLE_'))}))
    LOG.write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,p.stdout[-1500:],p.stderr[-1000:],flush=True)
    if p.returncode:raise RuntimeError(name)
    return p.stdout

phase=sys.argv[1]
if phase=='build':
    OUT.mkdir(exist_ok=True)
    peer=ROOT/'bench/io_http2/http2_p1_bench.cc'
    before=(PRIOR/'current-holdout/http2_p1_bench.cc').read_text()
    expected=before.replace('  std::thread worker_;\n','',1).replace('  bool stopping_ = false;\n',
        '  bool stopping_ = false;\n  // The worker can run immediately, so initialize every field it reads first.\n  std::thread worker_;\n',1)
    assert peer.read_text()==expected,'Canonical peer has changes beyond startup declaration order/comment'
    (HERE/'peer-before-startup-fix.cc').write_bytes((PRIOR/'current-holdout/http2_p1_bench.cc').read_bytes())
    (HERE/'http2_p1_bench.cc').write_bytes(peer.read_bytes())
    (HERE/'peer-startup-only.diff').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),expected.splitlines(keepends=True),fromfile='peer-before-startup-fix.cc',tofile='http2_p1_bench.cc')))
    wrapper=(PRIOR/'current-holdout/main.cc').read_bytes()
    (HERE/'main.cc').write_bytes(wrapper)
    assert (ROOT/'src/io_http2/http2.cc').read_bytes()==(PRIOR/'fixed-send-frame/http2.applied.cc').read_bytes()
    assert (ROOT/'src/io_core/proactor.cc').read_bytes()==(PRIOR/'current-holdout/proactor.current.cc').read_bytes()
    for src,dest in [(PRIOR/'fixed-send-frame/http2.candidate.cc',HERE/'http2.measured.cc'),
                     (ROOT/'src/io_http2/http2.cc',HERE/'http2.applied.cc')]:dest.write_bytes(src.read_bytes())
    (HERE/'http2-format-only.diff').write_bytes((PRIOR/'fixed-send-frame/measured-to-applied.diff').read_bytes())
    old=json.loads((PRIOR/'current-build-commands.json').read_text())
    cmd=next(x['argv'] for x in old if x['name']=='bench_io_http2_http2_p1_bench.cc')
    run('compile-main',cmd[:-4]+['-c',HERE/'main.cc','-o',OUT/'main.o'])
    link=next(x['argv'] for x in old if x['name']=='link')
    link=[str(OUT/'consumer') if x==str(BASE/'http2_current') else
          str(BASE/'fixed-send-frame/http2.o') if x==str(BASE/'src_io_http2_http2.cc.o') else
          str(OUT/'main.o') if x==str(BASE/'bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
    run('link-consumer',link)
    loader=run('loader',['ldd',OUT/'consumer'])
    assert str(CORE/'libhyle_io_core.so.0.1.0') in loader
    smoke=ENV.copy();smoke['HYLE_BENCH_SMOKE']='1'
    run('smoke',['taskset','-c','2','timeout','--kill-after=2s','20s',OUT/'consumer'],smoke)
    files={Path(x) for x in link if x.endswith(('.o','.a'))}
    for line in loader.splitlines():
        if 'libhyle_' in line and '=>' in line:files.add(Path(line.split('=>',1)[1].strip().split()[0]))
    previous=json.loads((PRIOR/'build-identity.json').read_text())
    matches=[dict(path=x['path'],current_sha256=identity(ROOT/x['path'])['sha256'],
        cache_source_sha256=x['sha256'],same_sha256=identity(ROOT/x['path'])['sha256']==x['sha256'])
        for x in previous['sources'] if x['path'] not in ('src/io_http2/http2.cc','bench/io_http2/http2_p1_bench.cc')]
    assert all(x['same_sha256'] for x in matches)
    (HERE/'build-identity.json').write_text(json.dumps(dict(
        source=[identity(HERE/x) for x in ('main.cc','http2_p1_bench.cc','http2.measured.cc','http2.applied.cc','run.py')],
        actual_current_proactor=identity(ROOT/'src/io_core/proactor.cc'),
        exact_inputs=[identity(p) for p in sorted(files)],
        reused_source_matches=matches,artifacts=[identity(p) for p in sorted(OUT.iterdir()) if p.is_file()],
        method='Only currentcanonical bench via unchangedsingleholdout main wrapper freshly compiled. Reused Status-helperfixed http2 object (measured/applied whitespace-only) and currentproactor runtimeoverride; remaining foundation cache retained, not wholeHEADbuild.',
        peer_delta='Only RawHarness worker member declaration moved after initialized state pluscomment; body/protocol/drive/teardown/timing and JSON export unchanged.',
        no_probe_new_dependency_download_configure_sdk_copy=True),indent=2)+'\n')
elif phase=='formal':
    assert any(x['name']=='smoke' and x['exit']==0 for x in records)
    assert not any(x['name'].startswith('formal-') for x in records),'No formal retries'
    for order in ('ab','ba'):
        env=ENV.copy();env['HYLE_BENCH_JSON']=str(HERE/('epochs-'+order))
        if order=='ba':env['HYLE_BENCH_RIVAL_FIRST']='1'
        run('formal-'+order,['taskset','-c','2','timeout','--kill-after=2s','30s',OUT/'consumer'],env,35)
else:raise RuntimeError('unknownphase')
