from pathlib import Path
import hashlib,json,statistics,subprocess,zipfile

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/current-holdout-status'
OUT=Path('/root/hyle-scratch/http2-current-20261018/current-holdout-status')
def record(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(name,data):(HERE/name).write_text(json.dumps(data,indent=2)+'\n')

identity=json.loads((HERE/'build-identity.json').read_text())
for x in identity['source']:
    assert record(Path(x['path']))['sha256']==x['sha256'],x
for x in identity['exact_inputs']:
    assert record(Path(x['path']))['sha256']==x['sha256'],x
assert (HERE/'http2_p1_bench.cc').read_bytes()==(ROOT/'bench/io_http2/http2_p1_bench.cc').read_bytes()
assert (HERE/'http2.applied.cc').read_bytes()==(ROOT/'src/io_http2/http2.cc').read_bytes()
assert record(ROOT/'src/io_core/proactor.cc')==identity['actual_current_proactor']

orders=[]
durations=[]
for order in ('ab','ba'):
    results=json.loads((HERE/('epochs-'+order+'-4.json')).read_text())['results']
    assert len(results)==2
    arms=[]
    for r in results:
        m=r['measurements'];assert len(m)==9 and r['batch']==4
        median=statistics.median(x['elapsed'] for x in m)
        assert abs(median-r['median(elapsed)'])<1e-15
        epochs=[dict(iterations=x['iterations'],seconds_per_episode=x['elapsed'],
            actual_duration_seconds=x['elapsed']*x['iterations']) for x in m]
        durations += [x['actual_duration_seconds'] for x in epochs]
        arms.append(dict(name=r['name'],median_ns_per_stream=median*1e9/4,
            median_absolute_percent_error=r['medianAbsolutePercentError(elapsed)'],
            clock_resolution_seconds=r['clockResolution'],
            configured_min_epoch_seconds=r['minEpochTime'],epochs=epochs))
    hyle=next(x for x in arms if x['name']=='HYLE HTTP/2 public session')
    peer=next(x for x in arms if x['name']=='nghttp2 direct HTTP/2 session')
    orders.append(dict(order=order,arms=arms,
        hyle_slower_percent=(hyle['median_ns_per_stream']/peer['median_ns_per_stream']-1)*100))

commands=json.loads((HERE/'commands.json').read_text())
assert [x['name'] for x in commands]==['compile-main','link-consumer','loader','smoke','formal-ab','formal-ba']
assert all(x['exit']==0 for x in commands)
assert '# holdout smoke hyle=4 peer=4' in (HERE/'smoke.stderr.txt').read_text()
cleanup=[record(p) for p in sorted(OUT.iterdir()) if p.is_file()]
assert {Path(x['path']).name for x in cleanup}=={'consumer','main.o'}
write('cleanup-candidates.json',dict(host='WSL',files=cleanup,total_bytes=sum(x['bytes'] for x in cleanup),
    note='Only thisbatch2 rebuildable artifacts. Sharedcurrentcore/helperobject and other originaldependency/foundationcache not included. No deletion performed.'))
summary=dict(
    result='The current public HTTP2 route, including the private Status-helper change, remains slower than the unchanged corrected manual peer in both fixed orders for this one large-body holdout.',
    head_at_packaging=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    scope=dict(trace='Only original4streams x256KiB request and response, reverse pair completion, original connection-window holdout',
        public_HTTP2=True,common_episode_control=False,processes=2,epochs_per_arm=9,
        all36epochs_retained=True,sole_full_smoke=True,extra_AA_shapes_probes_or_formal_retries=False,
        fresh_compilation='Only current canonical bench through the byte-identical oneholdout main wrapper; no product TU rebuilt.',
        product_or_peer_modified_in_this_refresh=False),
    results=orders,
    timing=dict(boundary='Original run_workload lambda: full cold connection episode including session/socket setup, public twoTask+join versus raw worker handoff/manual-loop, complete byte checks and session/socket destruction. Persistent harnesses/bodystrings outside timed lambda.',
        epochs='Originalcanonical nanobench:9epochs, min5episodes/epoch, batch4streams, defaultminEpochTime. No duration or timing control changed.',
        actual_epoch_duration_seconds_min=min(durations),actual_epoch_duration_seconds_max=max(durations),
        hardware_counters='perf_event_open unavailable message retained. Wall elapsed samples valid; zero cycle/instruction fields are not measurements.'),
    protocol_work_checks=[
        'Strict source assertion and peer-startup-only.diff establish the peer differs from the previous corrected peer only by moving RawHarness worker_ after initialized fields and one initialization-order comment.',
        'The sole full smoke ran both originalroutes and returned hyle4/peer4; every formal run also aborts if either route does not return4.',
        'Both original routes validate each body byte, required headers/length, all4 completed streams and reverse completion within each pair.',
        'Both preserve explicit stream and connection consume/flow-credit responsibilities, original socket settings, session options and teardown/handoff.',
        'No diagnostic counter, protocol/frame composition probe or terminal pending-frame snapshot was added. Equal payload duties do not assert identical wire chunk/control-frame counts.'],
    source_and_cache=dict(
        canonical_peer=record(HERE/'http2_p1_bench.cc'),
        prior_peer=record(HERE/'peer-before-startup-fix.cc'),
        wrapper=record(HERE/'main.cc'),wrapper_byte_identical_to_prior=True,
        public_http2_applied=record(HERE/'http2.applied.cc'),
        reused_http2_measured=record(HERE/'http2.measured.cc'),
        public_helper='Previously tested fixed-send-frame/http2.o retained. Only parameter indentation and one server co_return line differ between measured/applied source; http2-format-only.diff retained.',
        current_proactor=identity['actual_current_proactor'],
        runtime_core='Loader resolves current-holdout/libhyle_io_core.so.0.1.0, SHA9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779.',
        full_identity='build-identity.json retains actual linked input/runtime hashes and reused source matches; other foundation/shared cache was not rebuilt as wholeHEAD.',
        no_sdk_dependency_download_copy_or_configure=True),
    resources=dict(configured='same persistent one-worker Scheduler/IoContext + one RawHarness peer worker + caller in both arms',
        affinity='Both actual formal commands and smoke explicitly tasksetCPU2, inherited by created user threads.',
        hardware_toolchain='ExistingWSL2 Intel i9-13900K/GCC14.2 cache; this batch did not take a new hardware snapshot.',
        not_observed='No live in-interval actualTID/affinity count or IoContext backend snapshot; no io_uring/epoll selection or exact kernel-driver-thread count claim.'),
    interpretation=[
        'Current remaining loss is confirmed at the finite two-order point-estimate level for this trace, not an unchanged old number after the helper modification.',
        'Before/after batches use new processes; both arms changed absolute latency across rounds. Do not claim a causal frame percentage or subtract different rounds.',
        'The commonEpisode1vs2Task control is not the formal peer here and is not subtracted to attribute this residual.',
        'There are only two fixed formal processes and no cross-process CI/significance or universal-performance claim.',
        'Nanobench clockResolution metadata, actual aggregate epoch durations and run-to-run variability remain separate; no hardware-timer-floor explanation.'],
    failures='No compile/link/smoke/formal failures in this refresh. perf_event_open warning kept in both actualformal outputs.',
    cleanup=dict(manifest='cleanup-candidates.json',files=2,bytes=sum(x['bytes'] for x in cleanup),deleted=False))
write('summary.json',summary)
members=[p for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in ('.cc','.py','.json','.txt','.diff') and p.name!='archive-record.json']
archive=HERE/'source-results.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in members:z.write(p,p.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
write('archive-record.json',dict(archive=record(archive),summary=record(HERE/'summary.json'),members=len(members),no_exe_obj_library_or_SDK=True))
print(json.dumps(dict(results=[dict(order=x['order'],hyle_slower_percent=x['hyle_slower_percent'],
    arms=[dict(name=a['name'],median_ns_per_stream=a['median_ns_per_stream']) for a in x['arms']]) for x in orders],
    actual_epoch_duration_range_seconds=[min(durations),max(durations)],archive=record(archive),
    summary=record(HERE/'summary.json'),members=len(members),cleanup_bytes=sum(x['bytes'] for x in cleanup)),indent=2))
