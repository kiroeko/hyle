#define main original_benchmark_main
#include "protocol.cc"
#undef main
#include "split_advance.h"

#include <chrono>

namespace {
struct Episode {
  const Workload &workload;
  std::array<RawEndpoint, 2> endpoint;
  std::array<RawWire, 2> wire;
  hyle::sched::Event client_consumed;
  bool failed = false;
};

bool server_flushed(const RawEndpoint &endpoint, const RawWire &wire) noexcept {
  const auto count = static_cast<std::size_t>(endpoint.workload->streams);
  return endpoint.streams.size() == count &&
         endpoint.next_response_pair == count &&
         endpoint.streams[count - 2].output_done && wire.begin == wire.end;
}

struct EndpointCleanup {
  Episode &episode;
  unsigned role;
  TcpStream &socket;
  bool success = false;
  ~EndpointCleanup() {
    auto &endpoint = episode.endpoint[role];
    if (!success) {
      endpoint.failed = true;
      episode.failed = true;
      episode.client_consumed.signal();
    }
    if (endpoint.session) {
      nghttp2_session_del(endpoint.session);
      endpoint.session = nullptr;
    }
    // Session callbacks may refer to streams, so retire the session first.
    // Free all endpoint-owned payload on the worker before its join completes.
    std::vector<RawStream *>{}.swap(endpoint.readable);
    std::vector<RawStream>{}.swap(endpoint.streams);
    endpoint.readable_head = 0;
    episode.wire[role].reset_buffers();
    socket = TcpStream{};
  }
};

bool feed_async(RawEndpoint &endpoint, RawWire &wire,
                hyle::io::TransferResult result) noexcept {
  if (!result.ok() || result.eof || result.bytes == 0 ||
      result.bytes > wire.input.size())
    return false;
  if (nghttp2_session_mem_recv2(endpoint.session, wire.input.data(),
                                result.bytes) !=
      static_cast<nghttp2_ssize>(result.bytes))
    return false;
  bool consumed = false;
  return raw_consume_readable(endpoint, consumed);
}

Task<int> raw_endpoint(AllocatorRef allocator, TcpStream socket, Episode *episode,
                       unsigned role) noexcept {
  auto &endpoint = episode->endpoint[role];
  auto &wire = episode->wire[role];
  EndpointCleanup cleanup{*episode, role, socket};
  if (!wire.initialize_buffers(allocator))
    co_return -1;
  try {
    endpoint.streams.reserve(static_cast<std::size_t>(episode->workload.streams));
  } catch (...) {
    co_return -1;
  }
  if (!raw_initialize(endpoint))
    co_return -1;
  for (;;) {
    if (episode->failed || endpoint.failed)
      co_return -1;
    if (role == 0 && endpoint.completed == episode->workload.streams) {
      episode->client_consumed.signal();
      cleanup.success = true;
      co_return episode->workload.streams;
    }
    if (role == 1 && server_flushed(endpoint, wire)) {
      const bool done =
          episode->client_consumed.wait_for(std::chrono::seconds(5));
      if (!done || episode->failed ||
          endpoint.completed != episode->workload.streams)
        co_return -1;
      cleanup.success = true;
      co_return episode->workload.streams;
    }
    if (!(role == 0 ? advance_client(endpoint, wire)
                   : advance_server(endpoint, wire)) ||
        !raw_fill_output(endpoint, wire))
      co_return -1;
    bool written = false;
    if (!raw_write(wire, written))
      co_return -1;
    if (role == 1 && server_flushed(endpoint, wire))
      continue;
    // Keep stage8's two validated driver alignments.
    if (written && wire.begin == wire.end)
      continue;
    bool progress = false;
    if (!raw_read(endpoint, wire, progress) ||
        !raw_consume_readable(endpoint, progress))
      co_return -1;
    if (progress)
      continue;

    hyle::sched::Fiber::yield();
    if (episode->failed)
      co_return -1;
    progress = false;
    if (!raw_read(endpoint, wire, progress) ||
        !raw_consume_readable(endpoint, progress))
      co_return -1;
    if (progress)
      continue;
    if (wire.begin != wire.end) {
      written = false;
      if (!raw_write(wire, written, true))
        co_return -1;
      if (written)
        continue;
      const auto result = co_await socket.write_some(
          std::span<const std::byte>(
              reinterpret_cast<const std::byte *>(wire.pending.data() +
                                                  wire.begin),
              wire.end - wire.begin),
          hyle::io::OperationOptions{});
      if (!result.ok() || result.bytes == 0 ||
          result.bytes > wire.end - wire.begin)
        co_return -1;
      wire.begin += result.bytes;
      if (wire.begin == wire.end)
        wire.begin = wire.end = 0;
    } else {
      const auto result = co_await socket.read_some(
          std::span<std::byte>(
              reinterpret_cast<std::byte *>(wire.input.data()),
              wire.input.size()),
          hyle::io::OperationOptions{});
      if (!feed_async(endpoint, wire, result))
        co_return -1;
    }
  }
}

int run_raw_fibers(HyleHarness &harness, const Workload &workload,
                    bool check_descriptors = false) {
  auto pair = make_socket_pair();
  if (!pair.valid())
    return -1;
  auto client = TcpStream::adopt(harness.diagnostic_io(), kOwner,
                                pair.release_client());
  auto server = TcpStream::adopt(harness.diagnostic_io(), kOwner,
                                pair.release_server());
  if (!client || !server)
    return -1;
  // Only endpoint metadata lives on the caller stack. Each owner Task
  // allocates and frees two uninitialized 64KiB buffers within this episode.
  Episode episode{workload};
  for (unsigned role = 0; role != 2; ++role) {
    episode.endpoint[role].workload = &workload;
    episode.endpoint[role].server = role == 1;
  }
  episode.wire[0].descriptor = static_cast<int>(client->native_handle());
  episode.wire[1].descriptor = static_cast<int>(server->native_handle());
  auto server_join = hyle::sched::spawn_task(
      harness.diagnostic_scheduler(), system_allocator(),
      raw_endpoint(system_allocator(), std::move(*server), &episode, 1));
  auto client_join = hyle::sched::spawn_task(
      harness.diagnostic_scheduler(), system_allocator(),
      raw_endpoint(system_allocator(), std::move(*client), &episode, 0));
  auto client_result = client_join.join();
  auto server_result = server_join.join();
  // Extra descriptor observation belongs to the untimed functional warmup.
  if (check_descriptors) {
    for (const auto &wire : episode.wire) {
      errno = 0;
      if (::fcntl(wire.descriptor, F_GETFD) != -1 || errno != EBADF)
        return -1;
    }
  }
  return !episode.failed && client_result && server_result &&
                 *client_result == workload.streams &&
                 *server_result == workload.streams
             ? workload.streams
             : -1;
}
} // namespace

int main(int argc, char **argv) {
  if (argc != 3 ||
      (std::string_view(argv[1]) != "ab" && std::string_view(argv[1]) != "ba"))
    return 2;
  std::signal(SIGPIPE, SIG_IGN);
  const bool raw_first = std::string_view(argv[1]) == "ba";
  const auto workload = make_workload(
      "HTTP2 matched execution model 4x256KiB", 4, 256 * 1024, 256 * 1024,
      NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness hyle;
  RawHarness inactive_manual_peer;
  auto run_hyle = [&] {
    if (hyle.run(workload) != workload.streams)
      std::abort();
  };
  auto run_raw = [&] {
    if (run_raw_fibers(hyle, workload) != workload.streams)
      std::abort();
  };
  // Each process warms and checks both complete payloads in its chosen order.
  if (raw_first) {
    if (run_raw_fibers(hyle, workload, true) != workload.streams)
      return 3;
    run_hyle();
  } else {
    run_hyle();
    if (run_raw_fibers(hyle, workload, true) != workload.streams)
      return 3;
  }
  std::fprintf(stderr, "warmup order=%s hyle=4 raw=4 raw_fds_closed=true\n",
               argv[1]);
  ankerl::nanobench::Bench bench;
  bench.title(workload.title)
      .relative(true)
      .batch(static_cast<std::uint64_t>(workload.streams))
      .unit("stream")
      .performanceCounters(false)
      .minEpochTime(std::chrono::milliseconds(10))
      .minEpochIterations(5)
      .epochs(9);
  if (raw_first) {
    bench.run("aligned raw two-fiber session", run_raw);
    bench.run("Hyle public two-fiber session", run_hyle);
  } else {
    bench.run("Hyle public two-fiber session", run_hyle);
    bench.run("aligned raw two-fiber session", run_raw);
  }
  std::ofstream output(argv[2]);
  if (!output)
    return 4;
  bench.render(ankerl::nanobench::templates::json(), output);
  return output ? 0 : 4;
}
