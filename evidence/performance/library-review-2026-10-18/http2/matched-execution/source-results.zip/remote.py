"""One authorized preflight/build/AB-BA run; no product or SDK rebuild."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time


LOCAL = Path(__file__).resolve().parent
ROOT = LOCAL.parents[2]
REMOTE = Path("/root/hyle-scratch/http2-current-20261018/http2-matched-execution")
PLAN = json.loads((LOCAL / "plan.json").read_text())
COMMANDS = json.loads((LOCAL / "commands-plan.json").read_text())["commands"]


def write(name, value):
    (LOCAL / name).write_text(json.dumps(value, indent=2) + "\n")


def identity(path):
    path = Path(path)
    stat = path.stat()
    return {"path": str(path), "resolved": str(path.resolve()),
            "bytes": stat.st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def execute(name, argv, cwd=None, extra_env=None):
    env = os.environ.copy()
    env.update(extra_env or {})
    assert not env.get("LD_PRELOAD"), "No preload instrumentation is allowed"
    assert not env.get("LD_AUDIT"), "No audit instrumentation is allowed"
    start = time.monotonic()
    utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
    (LOCAL / (name + ".stdout.txt")).write_bytes(process.stdout)
    (LOCAL / (name + ".stderr.txt")).write_bytes(process.stderr)
    entry = {"name": name, "argv": argv, "cwd": str(cwd) if cwd else None,
             "environment": extra_env or {}, "started_utc": utc,
             "wall_seconds": time.monotonic() - start,
             "exit_code": process.returncode}
    log = LOCAL / "commands-actual.json"
    entries = json.loads(log.read_text()) if log.exists() else []
    entries.append(entry)
    write("commands-actual.json", entries)
    if process.returncode != 0:
        raise RuntimeError(f"{name} exited {process.returncode}; original logs retained")
    return process.stdout.decode()


def preflight():
    assert 2 in os.sched_getaffinity(0), "CPU2 is not in the allowed affinity"
    assert not REMOTE.exists(), "Refuse to reuse an existing probe output directory"
    observed = []
    errors = []
    for expected in PLAN["cache_preflight"]["expected_inputs"]:
        actual = identity(expected["path"])
        actual["matches_expected"] = all(actual[key] == expected[key]
                                          for key in ("bytes", "sha256"))
        observed.append(actual)
        if not actual["matches_expected"]:
            errors.append(expected["path"])
    source_ids = json.loads((LOCAL / "source-identities.json").read_text())
    for expected in source_ids["inputs"] + source_ids["outputs"]:
        actual = identity(ROOT / expected["path"])
        actual["matches_expected"] = all(actual[key] == expected[key]
                                          for key in ("bytes", "sha256"))
        observed.append(actual)
        if not actual["matches_expected"]:
            errors.append(expected["path"])
    metadata = {"allowed_affinity": sorted(os.sched_getaffinity(0)),
                "inherited_preload": os.environ.get("LD_PRELOAD"),
                "inherited_audit": os.environ.get("LD_AUDIT"),
                "expected_inputs": observed, "mismatches": errors}
    write("preflight-identities.json", metadata)
    assert not errors, f"Preflight mismatches: {errors}"
    metadata["uname"] = execute("uname", ["uname", "-a"]).strip()
    metadata["compiler"] = execute("compiler", ["g++-14", "--version"]).strip()
    metadata["lscpu"] = json.loads(execute("lscpu", ["lscpu", "--json"]))
    metadata["cpu2_affinity"] = execute(
        "cpu2-affinity", ["taskset", "-c", "2", "python3", "-c",
                          "import os;print(sorted(os.sched_getaffinity(0)))"]).strip()
    assert metadata["cpu2_affinity"] == "[2]"
    metadata["passed"] = True
    write("preflight-identities.json", metadata)
    REMOTE.mkdir(parents=True, exist_ok=False)
    print(json.dumps({"preflight": "passed", "retained_files": len(observed),
                      "cpu2_affinity": metadata["cpu2_affinity"]}), flush=True)


def build():
    assert json.loads((LOCAL / "preflight-identities.json").read_text())["passed"]
    for command in COMMANDS[:2]:
        execute(command["name"], command["argv"], REMOTE, command["environment"])
    env = COMMANDS[1]["environment"]
    ldd = execute("loader-ldd", ["ldd", str(REMOTE / "probe")], REMOTE, env)
    loaded = []
    for line in ldd.splitlines():
        match = re.search(r"=> (/\S+) ", line)
        if match:
            loaded.append(identity(match.group(1)))
    required_core = next(i for i in PLAN["cache_preflight"]["expected_inputs"]
                         if i["path"].endswith("/libhyle_io_core.so.0.1.0"))
    core = next(i for i in loaded if "/libhyle_io_core.so" in i["path"])
    assert all(core[key] == required_core[key] for key in ("bytes", "sha256"))
    assert core["resolved"] == required_core["path"]
    maps = REMOTE / "probe.map"
    (LOCAL / "probe.map").write_bytes(maps.read_bytes())
    write("build-identities.json", {
        "objects": [identity(REMOTE / "main.o"), identity(REMOTE / "probe")],
        "link_map": identity(maps), "loaded_libraries": loaded,
        "tcp_overlay": identity(LOCAL / "include/hyle/io/tcp.h"),
        "accepted_http2_object": identity(
            "/root/hyle-scratch/http2-current-20261018/discard-frame/http2.o"),
        "core_verified": True,
    })
    print(json.dumps({"build": "passed", "core_identity": core,
                      "probe": identity(REMOTE / "probe")}), flush=True)


def formal():
    assert json.loads((LOCAL / "build-identities.json").read_text())["core_verified"]
    for command in COMMANDS[2:]:
        execute(command["name"], command["argv"], REMOTE, command["environment"])
        order = command["name"].removeprefix("fixed-")
        raw = REMOTE / ("epochs-" + order + ".json")
        (LOCAL / raw.name).write_bytes(raw.read_bytes())
        result = json.loads(raw.read_text())
        assert len(result["results"]) == 2
        assert all(len(arm["measurements"]) == 9 for arm in result["results"])
        print(json.dumps({"process": order, "exit": 0,
                          "measurements": 18}), flush=True)
    write("terminal.json", {"status": "completed", "formal_processes": 2,
                             "measurements": 36, "additional_runs": 0})
    print(json.dumps({"terminal": "completed", "formal_processes": 2,
                      "measurements": 36}), flush=True)


if __name__ == "__main__":
    assert sys.platform.startswith("linux")
    {"preflight": preflight, "build": build, "formal": formal}[sys.argv[1]]()
