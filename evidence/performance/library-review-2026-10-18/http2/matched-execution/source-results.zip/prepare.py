"""Prepare the one fixed execution-model control. Does not build or run it."""

from pathlib import Path
import difflib
import hashlib
import json
import subprocess


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
OLD = ROOT / ".scratch/perf-review-2026-10-18/http2/raw-fiber-plain"


def replace_once(text, before, after):
    assert text.count(before) == 1, before[:120]
    return text.replace(before, after, 1)


def read(path):
    return path.read_text(encoding="utf-8")


def write(name, text):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


canonical_path = ROOT / "bench/io_http2/http2_p1_bench.cc"
canonical = read(canonical_path)
protocol = replace_once(
    canonical,
    "  ~HyleHarness() { scheduler_.shutdown(); }\n",
    "  ~HyleHarness() { scheduler_.shutdown(); }\n\n"
    "  Scheduler &diagnostic_scheduler() noexcept { return scheduler_; }\n"
    "  IoContext &diagnostic_io() noexcept { return io_; }\n",
)
protocol = replace_once(
    protocol,
    """  const std::size_t old_size = stream->inbound.size();
  try {
    stream->inbound.resize(old_size + length);
  } catch (...) {
    endpoint.failed = true;
    return NGHTTP2_ERR_CALLBACK_FAILURE;
  }
  if (length != 0)
    std::memcpy(stream->inbound.data() + old_size, data, length);
""",
    """  // Construct each received byte once, without first value-initializing it.
  // The unchanged capacity check above rules out growing the receive window.
  try {
    if (length != 0)
      stream->inbound.insert(stream->inbound.end(), data, data + length);
  } catch (...) {
    endpoint.failed = true;
    return NGHTTP2_ERR_CALLBACK_FAILURE;
  }
""",
)
protocol = replace_once(
    protocol,
    """struct RawWire {
  int descriptor = -1;
  std::array<std::uint8_t, kWireBytes> pending{};
  std::size_t begin = 0;
  std::size_t end = 0;
  std::array<std::uint8_t, kWireBytes> input{};
};
""",
    """struct RawWire {
  RawWire() noexcept = default;
  RawWire(const RawWire &) = delete;
  RawWire &operator=(const RawWire &) = delete;
  ~RawWire() { reset_buffers(); }

  bool initialize_buffers(AllocatorRef selected) noexcept {
    if (!selected.valid() || pending.data() != nullptr || input.data() != nullptr)
      return false;
    allocator = selected;
    auto *pending_data = static_cast<std::uint8_t *>(
        allocator.allocate(kWireBytes, alignof(std::max_align_t)));
    if (pending_data == nullptr)
      return false;
    pending = {pending_data, kWireBytes};
    auto *input_data = static_cast<std::uint8_t *>(
        allocator.allocate(kWireBytes, alignof(std::max_align_t)));
    if (input_data == nullptr) {
      reset_buffers();
      return false;
    }
    input = {input_data, kWireBytes};
    return true;
  }

  void reset_buffers() noexcept {
    if (input.data() != nullptr)
      allocator.deallocate(input.data(), kWireBytes, alignof(std::max_align_t));
    if (pending.data() != nullptr)
      allocator.deallocate(pending.data(), kWireBytes, alignof(std::max_align_t));
    input = {};
    pending = {};
    begin = end = 0;
  }

  int descriptor = -1;
  AllocatorRef allocator;
  std::span<std::uint8_t> pending;
  std::size_t begin = 0;
  std::size_t end = 0;
  std::span<std::uint8_t> input;
};
""",
)
protocol = replace_once(
    protocol,
    "bool raw_write(RawWire &wire, bool &progress) noexcept {",
    "bool raw_write(RawWire &wire, bool &progress, bool single_attempt = false) noexcept {",
)
protocol = replace_once(
    protocol,
    """      wire.begin += static_cast<std::size_t>(written);
      progress = true;
      continue;
""",
    """      wire.begin += static_cast<std::size_t>(written);
      progress = true;
      // Keep stage8's single immediate retry after a yield.
      if (single_attempt) {
        if (wire.begin == wire.end)
          wire.begin = wire.end = 0;
        return true;
      }
      continue;
""",
)
# Keep the included, inactive canonical manual-loop entry mechanically valid.
protocol = replace_once(
    protocol,
    """  RawWire client_wire{.descriptor = pair.release_client()};
  RawWire server_wire{.descriptor = pair.release_server()};
""",
    """  RawWire client_wire;
  RawWire server_wire;
  client_wire.descriptor = pair.release_client();
  server_wire.descriptor = pair.release_server();
""",
)
protocol = replace_once(
    protocol,
    "  if (!raw_initialize(client) || !raw_initialize(server)) {\n",
    "  if (!client_wire.initialize_buffers(system_allocator()) ||\n"
    "      !server_wire.initialize_buffers(system_allocator()) ||\n"
    "      !raw_initialize(client) || !raw_initialize(server)) {\n",
)
write("protocol.cc", protocol)

main = replace_once(read(OLD / "main.cc"), '#include "plain_bench.cc"', '#include "protocol.cc"')
main = replace_once(
    main,
    """    socket = TcpStream{};
""",
    """    // Session callbacks may refer to streams, so retire the session first.
    // Free all endpoint-owned payload on the worker before its join completes.
    std::vector<RawStream *>{}.swap(endpoint.readable);
    std::vector<RawStream>{}.swap(endpoint.streams);
    endpoint.readable_head = 0;
    episode.wire[role].reset_buffers();
    socket = TcpStream{};
""",
)
main = replace_once(
    main,
    "Task<int> raw_endpoint(AllocatorRef, TcpStream socket, Episode *episode,",
    "Task<int> raw_endpoint(AllocatorRef allocator, TcpStream socket, Episode *episode,",
)
main = replace_once(
    main,
    """  EndpointCleanup cleanup{*episode, role, socket};
  if (!raw_initialize(endpoint))
""",
    """  EndpointCleanup cleanup{*episode, role, socket};
  if (!wire.initialize_buffers(allocator))
    co_return -1;
  try {
    endpoint.streams.reserve(static_cast<std::size_t>(episode->workload.streams));
  } catch (...) {
    co_return -1;
  }
  if (!raw_initialize(endpoint))
""",
)
main = replace_once(
    main,
    """  // Preserve the original zero-initialized RawWire arrays in the timed call.
  // They belong to the external caller, outside both 64KiB fiber stacks.
""",
    """  // Only endpoint metadata lives on the caller stack. Each owner Task
  // allocates and frees two uninitialized 64KiB buffers within this episode.
""",
)
main = replace_once(main, "    episode.endpoint[role].streams.reserve(workload.streams);\n", "")
main = replace_once(
    main,
    '"HTTP2 same execution model 4x256KiB"',
    '"HTTP2 matched execution model 4x256KiB"',
)
main = replace_once(
    main,
    "// Keep the two validated driver alignments; only probes were removed.",
    "// Keep stage8's two validated driver alignments.",
)
write("main.cc", main)
write("split_advance.h", read(OLD / "split_advance.h"))

header_path = ROOT / "include/hyle/io/tcp.h"
old_header = subprocess.check_output(
    ["git", "show", "bfea93767^:include/hyle/io/tcp.h"], cwd=ROOT
).decode("utf-8")
current_header = read(header_path)
assert current_header.count("&detail::IoContextAccess::proactor(*io_, owner_)") == 4
assert current_header.replace(
    "&detail::IoContextAccess::proactor(*io_, owner_)",
    "&detail::IoContextAccess::proactor_for_current(*io_)",
) == old_header
write("include/hyle/io/tcp.h", old_header)


def diff(name, before, after, old_name, new_name):
    write(name, "".join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=old_name, tofile=new_name,
    )))


diff("current-canonical-protocol.diff", canonical, protocol,
     "bench/io_http2/http2_p1_bench.cc", "http2-matched-execution/protocol.cc")
diff("stage8-protocol.diff", read(OLD / "plain_bench.cc"), protocol,
     "stage8/plain_bench.cc", "http2-matched-execution/protocol.cc")
diff("stage8-main.diff", read(OLD / "main.cc"), main,
     "stage8/main.cc", "http2-matched-execution/main.cc")
diff("tcp-header-overlay.diff", current_header, old_header,
     "current/include/hyle/io/tcp.h", "overlay/include/hyle/io/tcp.h")


def identity(path):
    payload = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest()}


write("source-identities.json", json.dumps({
    "status": "source prepared only; not compiled or run",
    "repository_head_at_preparation": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "inputs": [identity(p) for p in (
        canonical_path, ROOT / "src/io_http2/http2.cc", header_path,
        OLD / "main.cc", OLD / "plain_bench.cc", OLD / "split_advance.h")],
    "outputs": [identity(OUT / name) for name in (
        "main.cc", "protocol.cc", "split_advance.h", "include/hyle/io/tcp.h",
        "current-canonical-protocol.diff", "stage8-protocol.diff", "stage8-main.diff",
        "tcp-header-overlay.diff")],
    "split_advance_unchanged": (OUT / "split_advance.h").read_bytes().replace(b"\r\n", b"\n")
        == (OLD / "split_advance.h").read_bytes().replace(b"\r\n", b"\n"),
    "header_overlay": {
        "source": "git show bfea93767^:include/hyle/io/tcp.h",
        "only_difference_from_current": "reverse exactly the four bfea93767 owner-index substitutions",
        "purpose": "fresh raw async fallback and fresh Hyle wrapper use the same TCP inline version as cached HTTP2/core",
    },
}, indent=2) + "\n")

print(json.dumps({"prepared": str(OUT), "compiled": False, "run": False,
                  "main_sha256": identity(OUT / "main.cc")["sha256"],
                  "protocol_sha256": identity(OUT / "protocol.cc")["sha256"]}))
