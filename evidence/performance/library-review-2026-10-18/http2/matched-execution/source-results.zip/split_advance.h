bool advance_client(RawEndpoint& client,const RawWire& client_wire) noexcept {
  if (client.streams.empty()) {
    if (!raw_submit_request(client))
      return false;
  } else if (client.streams.size() <
             static_cast<std::size_t>(client.workload->streams)) {
    const std::size_t count = client.streams.size();
    if ((count & 1u) != 0) {
      const RawStream &first = client.streams.back();
      if (first.output_done && client_wire.begin == client_wire.end &&
          !raw_submit_request(client))
        return false;
    } else if (client.completed == static_cast<int>(count) &&
               !raw_submit_request(client)) {
      return false;
    }
  }

  return true;
}

bool advance_server(RawEndpoint& server,const RawWire& server_wire) noexcept {
  // Submitted pairs need no more response scheduling work. Do not rescan
  // completed streams on every transport turn as the connection grows.
  for (std::size_t base = server.next_response_pair;
       base + 1 < server.streams.size(); base += 2) {
    RawStream &first = server.streams[base];
    RawStream &second = server.streams[base + 1];
    if (!first.input_done || !second.input_done)
      continue;
    if (!second.response_submitted) {
      if (!raw_submit_response(server, second))
        return false;
    } else if (second.output_done &&
               server_wire.begin == server_wire.end &&
               !first.response_submitted) {
      if (!raw_submit_response(server, first))
        return false;
      server.next_response_pair = base + 2;
    }
  }
  return true;
}
