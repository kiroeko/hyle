"""Summarize only the two completed processes and freeze source/result evidence."""

from pathlib import Path
import hashlib
import json
import statistics
import zipfile


OUT = Path(__file__).resolve().parent


def identity(path):
    data = path.read_bytes()
    return {"path": path.name, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


plan = json.loads((OUT / "plan.json").read_text())
source_ids = json.loads((OUT / "source-identities.json").read_text())
build_ids = json.loads((OUT / "build-identities.json").read_text())
preflight = json.loads((OUT / "preflight-identities.json").read_text())
actual_commands = json.loads((OUT / "commands-actual.json").read_text())
terminal = json.loads((OUT / "terminal.json").read_text())
assert terminal["measurements"] == 36 and terminal["additional_runs"] == 0

processes = []
by_order = {}
for order in ("ab", "ba"):
    raw = json.loads((OUT / f"epochs-{order}.json").read_text())
    assert len(raw["results"]) == 2
    result = {"order": order, "exit_code": 0, "arms_in_execution_order": []}
    arms = {}
    for arm in raw["results"]:
        name = "hyle" if arm["name"].startswith("Hyle") else "raw"
        assert len(arm["measurements"]) == 9
        assert arm["batch"] == 4 and arm["minEpochTime"] >= 0.01
        assert arm["minEpochIterations"] >= 5
        ns = [entry["elapsed"] * 1e9 for entry in arm["measurements"]]
        iterations = [entry["iterations"] for entry in arm["measurements"]]
        assert min(iterations) >= 5
        data = {"arm": name, "name": arm["name"], "batch_streams": 4,
                "epochs": 9, "clock_resolution_ns": arm["clockResolution"] * 1e9,
                "configured_minimum_epoch_time_ms": arm["minEpochTime"] * 1e3,
                "configured_minimum_epoch_iterations": arm["minEpochIterations"],
                "median_ns_per_complete_episode": statistics.median(ns),
                "mean_of_epoch_ns_per_complete_episode": statistics.mean(ns),
                "minimum_ns_per_complete_episode": min(ns),
                "maximum_ns_per_complete_episode": max(ns),
                "median_ns_per_stream": statistics.median(ns) / 4,
                "median_absolute_percent_error": arm["medianAbsolutePercentError(elapsed)"] * 100,
                "all_ns_per_complete_episode_in_original_order": ns,
                "all_iterations_in_original_order": iterations}
        result["arms_in_execution_order"].append(data)
        arms[name] = data
    result["raw_over_hyle_median_elapsed_ratio"] = (
        arms["raw"]["median_ns_per_complete_episode"] /
        arms["hyle"]["median_ns_per_complete_episode"])
    result["hyle_over_raw_median_elapsed_change_percent"] = (
        1 / result["raw_over_hyle_median_elapsed_ratio"] - 1) * 100
    result["raw_over_hyle_mean_elapsed_ratio"] = (
        arms["raw"]["mean_of_epoch_ns_per_complete_episode"] /
        arms["hyle"]["mean_of_epoch_ns_per_complete_episode"])
    processes.append(result)
    by_order[order] = arms

drift = {}
for arm in ("hyle", "raw"):
    old = by_order["ab"][arm]["median_ns_per_complete_episode"]
    new = by_order["ba"][arm]["median_ns_per_complete_episode"]
    drift[arm] = {"ba_minus_ab_median_ns": new - old,
                  "ba_over_ab_median_change_percent": (new / old - 1) * 100}

summary = {
    "status": "completed; no product or canonical benchmark modification; no cleanup or commit",
    "scope": "One fixed current-accepted-HTTP2 versus raw two-Task same-execution-model total-episode control",
    "workload": plan["fixed_workload"],
    "timed_boundary": plan["timed_boundary"],
    "source_changes": plan["source_changes"],
    "matching_tcp_inline": plan["matching_tcp_inline"],
    "actual_execution": {
        "fresh_translation_units": 1, "fresh_product_or_sdk_translation_units": 0,
        "separate_smoke_processes": 0, "formal_processes": 2,
        "process_order": ["ab", "ba"], "recorded_epoch_count": 36,
        "extra_shapes_aa_or_repeats": 0, "failures": [],
        "warmup_and_timed_validation": "Both complete warmup episodes in each selected order passed; every timed episode checks exact stream completion, complete body bytes and reverse order. Raw warmups also observed both descriptors closed (EBADF). Failure aborts the process; both processes exited zero.",
        "instrumentation": "No PLT/preload/audit interposition or hot counters/phase probes. nanobench performanceCounters(false).",
        "affinity": [2], "inherited_preload": preflight["inherited_preload"],
        "inherited_audit": preflight["inherited_audit"],
        "uname": preflight["uname"], "compiler": preflight["compiler"].splitlines()[0],
        "cpu_model": next(r["data"] for r in preflight["lscpu"]["lscpu"]
                          if r["field"] == "Model name:"),
    },
    "results": processes,
    "ab_to_ba_process_drift": drift,
    "interpretation": [
        "In AB Hyle median elapsed is about 1.42% above raw; in BA Hyle median is about 0.11% below raw. This fixed control does not show a consistent gap of the formal manual-loop comparison's size.",
        "Process drift is retained: Hyle median +1.28735%, raw +2.83595% from AB to BA; all epoch ranges and raw measurements remain. Mean and median need not produce the same tiny BA ordering.",
        "Do not replace or mark solved the distinct formal manual-loop peer residual. Do not attribute this combined execution-model/driver/ownership difference to pure scheduler or fcontext cost, and do not subtract percentages from prior rounds.",
        "Raw retains default native DATA bounce-copy and its fixed-workload vector representation; accepted Hyle retains owned-wire NO_COPY, generic owner/pin/borrow-ACK/cancel/error/flush epoch responsibilities. These remaining duties differ and are not separately timed.",
        "Matching old TCP header overlay deliberately excludes the later four-line bfea93767 optimization from fresh inline code to match cached HTTP2/core. This is not an all-current-HEAD foundation rebuild.",
    ],
    "remaining_different_responsibilities": plan["remaining_different_responsibilities"],
    "identities": {"sources": source_ids, "build_and_loader": build_ids,
                   "preflight": "preflight-identities.json", "actual_commands": "commands-actual.json"},
    "independent_numeric_review": "A second agent independently recomputed all four nine-epoch medians, ratios, process drift and minimum iterations from the retained JSON; values agreed. Read-only, no additional run.",
    "retained_files": {"raw": ["epochs-ab.json", "epochs-ba.json"],
                       "stdout_stderr": [f"fixed-{order}.{kind}.txt" for order in ("ab", "ba")
                                         for kind in ("stdout", "stderr")]},
}
write("summary.json", summary)

deletes = [{key: entry[key] for key in ("path", "bytes", "sha256")}
           for entry in build_ids["objects"]]
retains = [entry for entry in plan["cache_preflight"]["expected_inputs"]
           if entry["path"].endswith(("/discard-frame/http2.o", "/libhyle_io_core.so.0.1.0"))]
assert len({entry["path"] for entry in deletes + retains}) == len(deletes + retains)
write("cleanup-candidates.json", {
    "host": "WSL Ubuntu-24.04 root",
    "root": "/root/hyle-scratch/http2-current-20261018/http2-matched-execution",
    "files": deletes, "count": len(deletes),
    "logical_bytes": sum(entry["bytes"] for entry in deletes),
    "retain": retains,
    "retain_logical_bytes": sum(entry["bytes"] for entry in retains),
    "disposition": "No deletion executed. These two new binaries are rebuildable; exact cleanup requires root test.ps1. Preserve all source/log/raw/map/archive files and all shared SDK/native/foundation caches, especially accepted HTTP2/core.",
})

names = ["prepare.py", "remote.py", "freeze.py", "main.cc", "protocol.cc",
         "split_advance.h", "include/hyle/io/tcp.h", "current-canonical-protocol.diff",
         "stage8-protocol.diff", "stage8-main.diff", "tcp-header-overlay.diff",
         "plan.json", "commands-plan.json", "commands-actual.json", "source-identities.json",
         "source-review.json", "preflight-identities.json", "build-identities.json", "terminal.json",
         "epochs-ab.json", "epochs-ba.json", "probe.map", "summary.json", "cleanup-candidates.json"]
for command in actual_commands:
    names.extend(command["name"] + suffix for suffix in (".stdout.txt", ".stderr.txt"))
assert len(names) == len(set(names))
for name in names:
    assert (OUT / name).is_file(), name
with zipfile.ZipFile(OUT / "source-results.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        archive.write(OUT / name, name)
write("archive-identity.json", {"archive": identity(OUT / "source-results.zip"),
                                "summary": identity(OUT / "summary.json"),
                                "cleanup": identity(OUT / "cleanup-candidates.json"),
                                "members": len(names), "contains_binary_cache": False})
print(json.dumps({"processes": [{"order": p["order"],
                                "raw_over_hyle": p["raw_over_hyle_median_elapsed_ratio"]}
                               for p in processes],
                  "archive": identity(OUT / "source-results.zip"),
                  "cleanup_count": len(deletes),
                  "cleanup_logical_bytes": sum(entry["bytes"] for entry in deletes)}))
