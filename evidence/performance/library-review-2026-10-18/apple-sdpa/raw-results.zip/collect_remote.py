from pathlib import Path
import subprocess,json,re,hashlib,zipfile
p=Path(__file__).resolve().parent
commands=[['uname','-a'],['sw_vers'],['system_profiler','SPHardwareDataType','SPDisplaysDataType','-json'],['/usr/bin/clang++','--version'],['xcrun','--show-sdk-path']]
records=[]
for c in commands:
 r=subprocess.run(c,capture_output=True,text=True)
 records.append(dict(command=c,exit=r.returncode,stdout=r.stdout,stderr=r.stderr))
(p/'machine.json').write_text(json.dumps(records,indent=2))
data={}
for tag in ['baseline','candidate']:
 s=(p/(tag+'-tests.stdout.txt')).read_text()
 data[tag]={'tests_command':json.loads((p/(tag+'-tests-command.json')).read_text()),
 'test_tail':s[-1600:],'failure_case_counts':{},
 'space':json.loads((p/(tag+'-space.stdout.txt')).read_text()),
 'space_command':json.loads((p/(tag+'-space-command.json')).read_text()),
 'native_map_uses_fresh_object':str(p/(tag+'.o')) in (p/(tag+'.map')).read_text(),
 'native_map_old_apple_tensor_member_loaded':'apple_tensor.cc.o' in (p/(tag+'.map')).read_text()}
 for line in re.findall(r'depth=.+',s):
  data[tag]['failure_case_counts'][line]=data[tag]['failure_case_counts'].get(line,0)+1
files=[q for q in p.rglob('*') if q.is_file() and not q.is_symlink() and q.suffix in {'.cc','.h','.py','.json','.txt','.map','.tar'}]
data['source_hashes']={str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in files if q.suffix in {'.cc','.h','.py'}}
data['rebuildable']=[{'path':str(q),'bytes':q.stat().st_size} for q in p.iterdir() if q.is_file() and (q.suffix=='.o' or q.name in {'baseline-tests','candidate-tests','baseline-space','candidate-space'})]
(p/'collected.json').write_text(json.dumps(data,indent=2))
files.append(p/'collected.json')
with zipfile.ZipFile(p/'raw-results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for q in sorted(set(files)): z.write(q,str(q.relative_to(p)))
print(json.dumps({'zip_bytes':(p/'raw-results.zip').stat().st_size,'zip_sha256':hashlib.sha256((p/'raw-results.zip').read_bytes()).hexdigest(),'rebuildable':data['rebuildable']},indent=2))
