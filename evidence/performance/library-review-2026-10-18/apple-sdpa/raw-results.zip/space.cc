#include "tests/compute_route_apple/tensor_test_support.h"
#include <mlx/memory.h>
#include <iostream>
#include <array>
int main() {
  using namespace apple_tensor_test;
  try {
    constexpr int depth=256, queries=1024, keys=1024, heads=4, kv_heads=2;
    const std::array inputs{
      make(std::vector<double>(heads*queries*depth), {1,heads,queries,depth}, mx::float16),
      make(std::vector<double>(kv_heads*keys*depth), {1,kv_heads,keys,depth}, mx::float16),
      make(std::vector<double>(kv_heads*keys*depth,1.25), {1,kv_heads,keys,depth}, mx::float16)};
    auto context=a::Context::create().value();
    auto program=context.prepare(c::Operation(c::ScaledDotProductAttention{
        .layout=c::AttentionLayout::kBatchHeadSequenceDepth,
        .scale=0.0625F,.causal=true}),inputs).value();
    auto slot=program.create_invocation().value();
    auto bound=slot.bind(inputs); if(!bound.ok()) { std::cerr<<bound.message();return 2; }
    mx::clear_cache();
    const auto active_before=mx::get_active_memory();
    const auto cache_before=mx::get_cache_memory();
    mx::reset_peak_memory();
    auto work=slot.submit().value();
    auto result=work.wait().value();
    mx::synchronize(stream());
    const auto active_after=mx::get_active_memory();
    const auto peak=mx::get_peak_memory();
    const auto cache_after=mx::get_cache_memory();
    auto observed=values(result.get()->arrays()[0]);
    double max_error=0;
    for(auto x:observed) max_error=std::max(max_error,std::abs(x-1.25));
    std::cout<<"{\"dtype\":\"F16\",\"B\":1,\"Hq\":4,\"Hkv\":2,\"D\":256,\"Q\":1024,\"KV\":1024,\"causal\":true,\"caller_input_bytes\":4194304,\"output_bytes\":2097152,\"active_before\":"<<active_before
      <<",\"cache_before\":"<<cache_before<<",\"active_after\":"<<active_after
      <<",\"peak\":"<<peak<<",\"peak_minus_active_before\":"<<(peak-active_before)
      <<",\"cache_after\":"<<cache_after<<",\"max_abs_error\":"<<max_error
      <<",\"checked_elements\":"<<observed.size()<<"}\n";
    return max_error<=2e-3?0:3;
  } catch(const std::exception& e) { std::cerr<<e.what()<<"\n";return 4; }
}
