"""Freeze this bounded validation's sources/results; never compile or clean."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
HAD = OUT.parent / "cpu-hadamard"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": sha(data)}


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


PRODUCT = [
    "cmake/HyleDependencyLock.json",
    "src/compute_provider_ggml/CMakeLists.txt",
    "src/compute_provider_ggml/ggml_cpu_provider.cc",
    "tests/compute_provider_ggml/CMakeLists.txt",
    "tests/compute_provider_ggml/attention_math_test.cc",
    "tests/compute_ggml_runtime/gallocr_faults.c",
    "tests/compute_ggml_runtime/gallocr_faults.h",
    "tests/compute_provider_ggml_vulkan/CMakeLists.txt",
    "tests/compute_provider_ggml_vulkan/storage_test.cc",
    *[f"third_party/{name}/{file}" for name in
      ("ggml_runtime", "ggml_cpu_runtime", "ggml_vulkan_runtime")
      for file in ("NOTICE.md", "patches.json")],
]
REFERENCE = [
    "src/compute_ggml_runtime/cpu_program.cc",
    "src/compute_ggml_runtime/cpu_program.h",
    "src/compute_ggml_runtime/cpu_program_abi.h",
    "src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py",
    "scripts/hyle_environment.py",
    "cmake/HyleDependencyVersions.cmake",
]

expected_trees = {
    "ggml_runtime": "35362dfcd15a927b51412379fb6483282b8c5587a3bc4e6ff943d3731c5cbffe",
    "ggml_cpu_runtime": "fac0b1c718bc238e8c1cadd1eef512049889285c33209c13fc085c3a792e4579",
    "ggml_vulkan_runtime": "38e2cdfe2abf5119571f6697a827defb27da305fa188a25ad5332c5353ce8114",
}
trees = []
for name, expected in expected_trees.items():
    folder = ROOT / "third_party" / name
    files = sorted((p for p in folder.rglob("*") if p.is_file()),
                   key=lambda p: p.relative_to(folder).as_posix())
    manifest = ""
    for path in files:
        assert not path.is_symlink()
        normalized = path.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        manifest += f"{path.relative_to(folder).as_posix()}|{sha(normalized)}\n"
    actual = sha(manifest.encode())
    assert actual == expected, (name, actual, expected)
    notice = (folder / "NOTICE.md").read_bytes()
    trees.append({"path": folder.relative_to(ROOT).as_posix(),
                  "tree_sha256": actual, "NOTICE_sha256": sha(notice),
                  "NOTICE_lf_sha256": sha(notice.replace(b"\r\n", b"\n").replace(b"\r", b"\n"))})
write("resource-tree-identities.json", trees)

assert (OUT / "provider-candidate-frozen.cc").read_bytes() == (ROOT / PRODUCT[2]).read_bytes()
assert (OUT / "attention_math_test-frozen.cc").read_bytes() == (ROOT / PRODUCT[4]).read_bytes()
baseline_source = OUT / "baseline" / PRODUCT[2]
assert baseline_source.read_bytes() == git("show", "782c5d3a4:" + PRODUCT[2])

moves = []
for suffix in ("c", "h"):
    old = f"tests/compute_provider_ggml_vulkan/gallocr_faults.{suffix}"
    new = f"tests/compute_ggml_runtime/gallocr_faults.{suffix}"
    previous = git("show", "782c5d3a4:" + old)
    assert previous == (ROOT / new).read_bytes()
    moves.append({"from": old, "to": new, "unchanged_bytes": True,
                  "sha256": sha(previous)})

write("source-identity.json", {p: identity(ROOT / p) for p in PRODUCT + REFERENCE})
write("fixture-move.json", moves)
(OUT / "product.patch").write_bytes(git("diff", "--", *PRODUCT,
    "tests/compute_provider_ggml_vulkan/gallocr_faults.c",
    "tests/compute_provider_ggml_vulkan/gallocr_faults.h"))

# The archive contains source snapshots as well as the tracked diff: new files
# are intentionally untracked until root integrates the batch.
archive_files = {}
for group, paths in (("product", PRODUCT), ("reference", REFERENCE)):
    for path in paths:
        archive_files[f"{group}/{path}"] = ROOT / path
for path in (OUT / "baseline").rglob("*"):
    if path.is_file():
        archive_files[path.relative_to(OUT).as_posix()] = path
for pin in ("ffa4", "mixed"):
    for name in ("ggml-alloc.fallible.c", "gallocr_faults.c", "provider-command.json", "provider-compile.log"):
        archive_files[f"{pin}/{name}"] = OUT / pin / name
for name in ("run.py", "commands.json", "summary.json", "source-identity.json"):
    archive_files[f"borrowed-cpu-hadamard/{name}"] = HAD / name
for pin in ("ffa4", "mixed"):
    archive_files[f"borrowed-cpu-hadamard/{pin}/ops.unary.cpp"] = HAD / pin / "ops.unary.cpp"

rebuildable = []
for path in sorted(OUT.rglob("*"), key=lambda p: p.relative_to(OUT).as_posix()):
    if path.is_file() and path.suffix.lower() in {".exe", ".obj", ".dll", ".lib", ".pdb", ".ilk", ".exp", ".pyc"}:
        assert path.resolve().is_relative_to(OUT.resolve())
        rebuildable.append({"path": str(path.resolve()), **identity(path)})
write("cleanup-candidates.json", {
    "scope": "Only rebuildable files created under this batch. Root must write/execute test.ps1; nothing deleted here.",
    "files": rebuildable, "total_bytes": sum(x["bytes"] for x in rebuildable),
    "borrowed_cpu_hadamard_files_excluded": True,
})

retain = []
retain_paths = set()
for pin in ("ffa4", "mixed"):
    for name in ("native-baseline.obj", f"hyle_ggml_cpu_avx2_{pin}_hadamard_v2_overlay.dll"):
        path = HAD / pin / name
        retain_paths.add(path.resolve())
        retain.append({"path": str(path.resolve()), **identity(path)})
had_cleanup = []
for path in sorted(HAD.rglob("*"), key=lambda p: p.relative_to(HAD).as_posix()):
    if (path.is_file() and path.resolve() not in retain_paths and
            path.suffix.lower() in {".exe", ".obj", ".dll", ".lib", ".pdb", ".ilk", ".exp", ".map", ".pyc"}):
        assert path.resolve().is_relative_to(HAD.resolve())
        had_cleanup.append({"path": str(path.resolve()), **identity(path)})
write("cleanup-and-retain.json", {
    "rule": "Exact candidates only; root writes test.ps1 and executes. No deletion by this script. Supersedes prior CPUHad whole-folder retention now that Sink validation is complete.",
    "delete_candidates": rebuildable + had_cleanup,
    "delete_total_bytes": sum(x["bytes"] for x in rebuildable + had_cleanup),
    "retain_for_future_cpu_work": retain,
    "retain_total_bytes": sum(x["bytes"] for x in retain),
    "never_delete": "Shared dependency caches, foundation/native library caches, original optimized objects, evidence archives/sources/logs/commands. All candidates reside only under these two batch directories.",
})

summary = {
    "status": "implemented_focused_validation_complete_no_commit",
    "source_root": str(ROOT),
    "frozen_baseline_commit": "782c5d3a4",
    "archive_time_head": git("rev-parse", "HEAD").decode().strip(),
    "implementation": {
        "scope": "Only actually tiled CPU Sink and mixed old-pin F32 math attention recipes use official gallocr. Normal CPU-only flash, causal-mask creation, and other recipes retain their prior path.",
        "scratch": "Cold reserve uses AllocatorRef-backed native CPU buffers. Real caller binding precedes first alloc_graph; fixed-topology replay only refreshes mapped roots/views. Published inputs/outputs retain native liveness marks.",
        "ports": "Truthful native port capacities; borrowed buffer base retains caller scalar alignment. Tests deliberately offset F32 ports by 4 bytes from 64-byte allocation bases.",
        "frontier": "Balanced real concat dataflow preserves multi-node/downstream and published intermediate dependencies, at O(output * log(query_blocks)) copy cost. Full KV conversion is shared once.",
        "math": "Original F32 QK/probability/PV and scale/mask/per-head sink semantics. Total-Q bottom-right offsets, layouts, batches, GQA and distinct V/output depth retained.",
        "private_policy": "8MiB trigger, conservative 64MiB score target, at most128 query rows and a score-savings vs output-frontier guard. These select strategy and do not decline valid inputs.",
        "allocator_resource": "Existing32 fallible ggml-alloc.c edits moved from Vulkan to common456 and applied to FFA CPU with pin-specific complete-file hashes; Vulkan final allocator bytes unchanged.",
    },
    "validation": {
        "toolchain": "Windows x64 MSVC14.50.35717, Release/O2/MD. Fresh provider/test C++ objects /W4 /WX; direct CL/LINK only.",
        "candidate": {"ffa4": {"passed": 5, "total": 5}, "mixed": {"passed": 5, "total": 5}},
        "baseline": "Each pin4/5; only new bounded-cold-allocation assertion fails as expected. Baseline numerical, rebind/downstream, quota cleanup and native fault tests pass. Raw failure retained.",
        "oracle": "Independent FP64 actual-F32-input oracle; tolerance6e-6*abs(expected)+2e-6 unchanged. Sink maxAbs<=7.45058e-9; mixed ordinary<=1.49012e-8; CPU-only flash control<=1.86265e-8.",
        "coverage": "Cross/tail blocks, nonzero row-varying/full-masked mask and per-head sinks, published intermediate plus Neg downstream, B2/GQA, BHSD/BSHD, negative/zero scale, noncausal Q>KV, distinct Dq/Dv, repeated real mappings and an independent second slot executed sequentially.",
        "resource_lock": {"executed_by": "root independently, not rerun by this agent", "command": "cmake -P .scratch/perf-review-2026-10-18/cpu-math-attention/check-lock.cmake", "exit_code": 0, "wall_seconds": 0.6089, "stdout": "-- Three allocator resource trees and license hashes match\n"},
        "prepared_evidence": {"actual_provider": "AllocatorRef allocation counts unchanged during first submit and rebind; payload quotas reject cold failure and charges roll back, then successful retry.", "native_fixture": "Separate original allocator fixture sees12 C malloc metadata calls at cold reserve and12 after first real bind, and failure at every cold site leaves zero live allocations.", "limits": "Native C malloc fixture is not injected into actual provider; no global new interception or single all-heap end-to-end monitor. No concurrent-slot stress. No public default Graph partitioner build/run; actual internal multi-node Region exercised."},
    },
    "cold_space": {
        "shape": "Sink F32 B1/Q129/KV2049/H64/KV1/D512",
        "metric": "Actual incremental AllocatorRef requested private bytes at cold invocation creation, including tracked invocation/arena/workspace/gallocr backing. Not process RSS/resident/whole-process memory; untracked native C malloc/system buffer-wrapper metadata excluded.",
        "baseline_bytes": 156480184, "candidate_ffa4_bytes": 48970792,
        "candidate_mixed_bytes": 48970760,
        "caller_logical_required_bytes": 43266820,
        "caller_allocation_in_this_cold_test": False,
        "single_full_scores_bytes": 67666176,
        "cold_large_shape_numerical_execution": False,
    },
    "limits": ["No throughput or latency experiment; functional GTest elapsed time is not a performance ranking.", "No configure, cmake --build, SDK copy/download or full native rebuild. Native gallocr and Hyle host objects overlaid ahead of existing pinned native libraries.", "Both algorithm arms use the same configured CPUHad ABI2 selected modules. Their ownership was verified in preceding CPUHad validation; this batch did not repeat a module-owner diagnostic."],
    "borrowed_cpu_hadamard_archive": {"path": str(HAD / "source-results.zip"), **identity(HAD / "source-results.zip")},
}
write("summary.json", summary)
for path in OUT.iterdir():
    if path.is_file() and path.suffix in {".json", ".log", ".py", ".cmake", ".cc", ".patch"} and path.name != "archive-record.json":
        archive_files[path.name] = path
archive = OUT / "source-evidence.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(archive_files.items()):
        assert path.suffix.lower() not in {".exe", ".obj", ".dll", ".lib", ".pdb", ".ilk", ".exp", ".zip"}
        z.write(path, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    count = len(z.infolist())
record = {"path": str(archive), **identity(archive), "members": count,
          "rebuildable_files": len(rebuildable), "rebuildable_bytes": sum(x["bytes"] for x in rebuildable),
          "combined_cleanup_files": len(rebuildable + had_cleanup),
          "combined_cleanup_bytes": sum(x["bytes"] for x in rebuildable + had_cleanup),
          "retain_files": len(retain), "retain_bytes": sum(x["bytes"] for x in retain)}
write("archive-record.json", record)
print(json.dumps(record, indent=2))
