from pathlib import Path
import argparse,importlib.util,json,os,shlex,subprocess,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
HAD=OUT.parent/'cpu-hadamard'
spec=importlib.util.spec_from_file_location('had',HAD/'run.py');had=importlib.util.module_from_spec(spec);spec.loader.exec_module(had)
ENV=had.ENV;BASE=had.BASE;CL=had.CL;LINK=had.LINK
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,cmd,expected=0):
 cmd=list(map(str,cmd));start=time.monotonic();r=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
 (OUT/(tag+'.log')).write_bytes(r.stdout);records.append(dict(label=tag,command=cmd,cwd=str(ROOT),exit_code=r.returncode,expected_exit=expected,seconds=time.monotonic()-start));(OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(tag,r.returncode,r.stdout.decode(errors='replace')[-3500:],flush=True)
 if r.returncode!=expected:raise SystemExit(r.returncode or 2)
def config(pin):
 cfg=dict(had.PINS[pin]);cfg['folder']=OUT/pin;cfg['module']=HAD/pin/('hyle_ggml_cpu_avx2_'+pin+'_hadamard_v2_overlay.dll');return cfg
def flags(cfg):return had.hyle_flags(cfg)
def compile_cpp(cfg,source,name,extra=()):
 run(cfg['folder'].name+'-'+name+'-compile',[CL,*flags(cfg),*extra,source,'/Fo'+str(cfg['folder']/(name+'.obj'))])
def compile_c(cfg,source,name):
 db=json.loads(cfg['compdb'].read_text());r=next(x for x in db if Path(x['file']).name=='ggml-alloc.c')
 tokens=[x.strip('"') for x in shlex.split(r['command'],posix=False)][1:]
 keep=[x for x in tokens if x.lower() not in ['/c','-c','/fs'] and not x.lower().startswith(('/fo','/fd')) and x.replace('\\','/')!=r['file'].replace('\\','/')]
 run(cfg['folder'].name+'-'+name+'-compile',[CL,*keep,'/utf-8','/c',source,'/Fo'+str(cfg['folder']/(name+'.obj'))])
def build(pin):
 cfg=config(pin);folder=cfg['folder']
 compile_cpp(cfg,ROOT/'src/compute_provider_ggml/ggml_cpu_provider.cc','provider-candidate')
 compile_cpp(cfg,OUT/'baseline/src/compute_provider_ggml/ggml_cpu_provider.cc','provider-baseline')
 compile_c(cfg,folder/'ggml-alloc.fallible.c','allocator')
 compile_c(cfg,folder/'gallocr_faults.c','faults')
 compile_cpp(cfg,ROOT/'tests/compute_provider_ggml/attention_math_test.cc','tests')
 compile_cpp(cfg,ROOT/'src/compute_ggml_runtime/cpu_program.cc','selector',['/DHYLE_GGML_CPU_AVX2_PROGRAM=1','/DHYLE_GGML_CPU_PROGRAM_LIBRARY="'+str(cfg['module']).replace('\\','/')+'"'])
 for arm in ['baseline','candidate']:
  run(pin+'-'+arm+'-link',[LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(folder/(arm+'-tests.exe')),folder/('provider-'+arm+'.obj'),folder/'allocator.obj',folder/'selector.obj',folder/'tests.obj',folder/'faults.obj',HAD/pin/'native-baseline.obj',*had.common_libs(cfg),BASE/'lib/gtest.lib',BASE/'lib/gtest_main.lib',*had.SYSTEM])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['build','tests']);p.add_argument('--pin',choices=['ffa4','mixed'],default='ffa4');a=p.parse_args()
 if a.action=='build':build(a.pin)
 else:
  for arm in ['baseline','candidate']:
   run(a.pin+'-'+arm+'-tests',[OUT/a.pin/(arm+'-tests.exe'),'--gtest_filter=GgmlCpuMathAttention.*'],expected=1 if arm=='baseline' else 0)
