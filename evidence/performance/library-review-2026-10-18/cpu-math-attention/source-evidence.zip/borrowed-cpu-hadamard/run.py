from pathlib import Path
import argparse, hashlib, json, os, re, shlex, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3]; OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
BASE=ROOT/'.scratch/build-compute-v2-dev'
CL=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'); LINK=CL.with_name('link.exe')
ENV=windows_compiler_environment({'CMAKE_CXX_COMPILER':str(CL),'CMAKE_C_COMPILER':str(CL)})
ENV['VSLANG']='1033';ENV['PATH']=str(BASE/'bin')+os.pathsep+ENV['PATH']
GTEST=Path(os.environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
RECORDS=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
SYSTEM=['bcrypt.lib','PowrProf.lib','Synchronization.lib','advapi32.lib','user32.lib','shell32.lib','ole32.lib','ws2_32.lib']
def run(tag,cmd,timeout=180):
 cmd=list(map(str,cmd));start=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (OUT/(tag+'.log')).write_bytes(p.stdout);RECORDS.append(dict(label=tag,command=cmd,cwd=str(ROOT),exit=p.returncode,wall_seconds=time.monotonic()-start));(OUT/'commands.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
 print(tag,p.returncode,round(time.monotonic()-start,3),p.stdout.decode(errors='replace')[-1800:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 return p.stdout
PINS={
 'ffa4':dict(raw=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml_cpu-ffa4e8b80930-ac5706fbc134'),source=BASE/'src/compute_ggml_runtime/source-e74fc9bb8964d04f',manifest=ROOT/'third_party/ggml_cpu_runtime/patches.json',compdb=BASE/'compile_commands.json',optimized=BASE/'src/compute_ggml_runtime/CMakeFiles/hyle_ggml_cpu_avx2.dir/source-e74fc9bb8964d04f',base=BASE/'bin/ggml-base.lib',cpu=BASE/'bin/ggml-cpu.lib'),
 'mixed':dict(raw=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424'),source=ROOT/'.scratch/validation/cpu-final-f1/mixed-iq1/source',manifest=OUT/'mixed-cpu-patches.json',compdb=ROOT/'.scratch/build-cpu-final-mixed-probe/compile_commands.json',optimized=BASE/'src/compute_ggml_runtime/CMakeFiles/hyle_ggml_cpu_avx2.dir/source-d8ea95b566c61d43',base=ROOT/'.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-base.lib',cpu=ROOT/'.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-cpu.lib')}
def prepare(pin):
 cfg=PINS[pin];folder=OUT/pin;folder.mkdir(exist_ok=True)
 manifest=json.loads(cfg['manifest'].read_text());patch=next(f for f in manifest['files'] if f['path']=='src/ggml-cpu/ops.cpp')
 data=(cfg['raw']/patch['path']).read_bytes().replace(b'\r\n',b'\n');assert hashlib.sha256(data).hexdigest()==patch['before_sha256']
 for e in patch['edits']:
  old=e['before'].encode();assert data.count(old)==1,e['before'][:90];data=data.replace(old,e['after'].encode(),1)
 assert hashlib.sha256(data).hexdigest()==patch['after_sha256']
 (folder/'ops.unary.cpp').write_bytes(data)
 cfg['folder']=folder;cfg['module']=folder/('hyle_ggml_cpu_avx2_'+pin+'_hadamard_v2_overlay.dll')
 return cfg

def native_flags(cfg):
 db=json.loads(cfg['compdb'].read_text());row=next(x for x in db if Path(x['file']).name=='ops.cpp')
 tokens=[x[1:-1] if x.startswith('"') and x.endswith('"') else x for x in shlex.split(row['command'],posix=False)]
 result=[];skip=False
 for t in tokens[1:]:
  if t.lower() in ['-c','/c','/fs'] or t==row['file'] or t.replace('\\','/')==row['file'].replace('\\','/'):continue
  if t.lower().startswith(('/fo','/fd','/arch:')):continue
  if re.match(r'[-/]D(GGML_(AVX|AVX2|FMA|F16C|BMI2)|__BMI2__)(=|$)',t):continue
  result.append(t)
 return result

def hyle_flags(cfg):
 return ['/nologo','/c','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/Ob2','/MD','/DNDEBUG','/permissive-','/bigobj','/W4','/WX','/wd4324','/wd4702','/DHYLE_STATIC','/DNOMINMAX','/DHYLE_COMPUTE_GGML_CPU=1','/DHYLE_TEST_GGML_CPU=1',
  '/DHYLE_GGML_CPU_PROVIDER_VERSION="hadamard-unary-overlay"',
  '/I'+str(ROOT/'include'),'/I'+str(ROOT/'src/compute'),'/I'+str(ROOT/'src/compute_provider_ggml'),'/I'+str(ROOT/'src/compute_ggml_runtime'),
  '/external:I'+str(cfg['source']/'include'),'/external:I'+str(cfg['source']/'src'),'/external:I'+str(GTEST),'/external:W0']+(['/DHYLE_GGML_CPU_F32_FLASH=1'] if cfg['manifest'].name=='patches.json' else [])

def compile_object(cfg,source,name,extra=(),native=False):
 obj=cfg['folder']/(name+'.obj');flags=native_flags(cfg) if native else hyle_flags(cfg)
 run(cfg['folder'].name+'-'+name+'-compile',[CL,*flags,*extra,'/c',source,'/Fo'+str(obj)])
 return obj

def compile_native(pin):
 cfg=prepare(pin);folder=cfg['folder']
 compile_object(cfg,folder/'ops.unary.cpp','native-baseline',native=True)
 compile_object(cfg,folder/'ops.unary.cpp','native-avx2',['/DGGML_AVX','/DGGML_AVX2','/DGGML_FMA','/DGGML_F16C','/DGGML_BMI2','/D__BMI2__','/arch:AVX2'],native=True)
 compile_object(cfg,ROOT/'src/compute_ggml_runtime/cpu_program_export.cc','program-export',['/I'+str(ROOT/'include'),'/I'+str(ROOT/'src/compute_ggml_runtime')],native=True)
 cached=list(cfg['optimized'].rglob('*.obj'));assert cached and any(q.name=='ops.cpp.obj' for q in cached)
 cached=[q for q in cached if q.name!='ops.cpp.obj']
 run(pin+'-module-link',[LINK,'/nologo','/DLL','/MACHINE:X64','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(cfg['module']),'/IMPLIB:'+str(folder/'module.lib'),'/MAP:'+str(folder/'module.map'),folder/'native-avx2.obj',folder/'program-export.obj',*cached,cfg['base'],*SYSTEM])
 return cfg

def common_libs(cfg=None):
 names=['hyle_compute_backend_cpu','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_container','hyle_mem','mimalloc_static','hyle_platform','hyle_error','hyle_platform_thread','hyle_time','hyle_simd','hyle_compute_provider_ggml','hyle_compute_ggml_runtime','ggml','ggml-base','ggml-cpu']
 result=[BASE/'bin'/(n+'.lib') for n in names]
 if cfg and cfg['folder'].name=='mixed':
  native=ROOT/'.scratch/build-cpu-final-mixed-probe/ggml/src'
  result=[native/q.name if q.stem in ['ggml','ggml-base','ggml-cpu'] else q for q in result]
 return result

def compile_tests(pin='ffa4'):
 cfg=prepare(pin);f=cfg['folder']
 compile_object(cfg,ROOT/'src/compute_provider_ggml/ggml_cpu_provider.cc','provider-candidate')
 compile_object(cfg,OUT/'baseline/src/compute_provider_ggml/ggml_cpu_provider.cc','provider-baseline')
 compile_object(cfg,ROOT/'tests/compute_provider_ggml/hadamard_test.cc','provider-tests')
 compile_object(cfg,ROOT/'tests/compute_ggml_runtime/execution_test.cc','runtime-tests')
 compile_object(cfg,OUT/'test_main.cc','test-main')
 for mode in ['baseline','selected']:
  macros=[] if mode=='baseline' else ['/DHYLE_GGML_CPU_AVX2_PROGRAM=1','/DHYLE_GGML_CPU_PROGRAM_LIBRARY="'+str(cfg['module']).replace('\\','/')+'"']
  compile_object(cfg,ROOT/'src/compute_ggml_runtime/cpu_program.cc','selector-'+mode,macros)
  run(pin+'-tests-'+mode+'-link',[LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(f/('tests-'+mode+'.exe')),'/MAP:'+str(f/('tests-'+mode+'.map')),f/'provider-candidate.obj',f/'provider-tests.obj',f/'runtime-tests.obj',f/'test-main.obj',f/('selector-'+mode+'.obj'),f/'native-baseline.obj',*common_libs(cfg),BASE/'lib/gtest.lib',*SYSTEM])

def compile_space():
 cfg=prepare('ffa4');f=cfg['folder']
 compile_object(cfg,OUT/'space_probe.cc','space')
 for arm in ['baseline','candidate']:
  run('ffa4-space-'+arm+'-link',[LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(f/('space-'+arm+'.exe')),'/MAP:'+str(f/('space-'+arm+'.map')),f/('provider-'+arm+'.obj'),f/'space.obj',f/'selector-selected.obj',f/'native-baseline.obj',*common_libs(),*SYSTEM,'psapi.lib'])
def run_space():
 for arm in ['baseline','candidate']:
  run('ffa4-space-'+arm,[OUT/'ffa4'/('space-'+arm+'.exe')])
def run_tests(pin='ffa4'):
 for mode in ['baseline','selected']:
  run(pin+'-tests-'+mode,[OUT/pin/('tests-'+mode+'.exe'),'--gtest_filter=GgmlCpuHadamard.*:GgmlCpuExecution.UnaryHadamardOwnsNoMatrixInEitherReferenceSetting'])

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['native','tests-build','tests','space-build','space','mixed-native']);p.add_argument('--pin',choices=list(PINS),default='ffa4');a=p.parse_args()
 if a.action=='native':compile_native(a.pin)
 elif a.action=='tests-build':compile_tests(a.pin)
 elif a.action=='tests':run_tests(a.pin)
 elif a.action=='space-build':compile_space()
 elif a.action=='space':run_space()
 else:raise SystemExit('not implemented yet')
