include("${CMAKE_CURRENT_LIST_DIR}/../../../cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_runtime_patches ggml_cpu_runtime_patches ggml_vulkan_runtime_patches)
message(STATUS "Three allocator resource trees and license hashes match")
