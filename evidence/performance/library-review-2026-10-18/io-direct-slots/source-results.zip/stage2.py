from pathlib import Path
import hashlib,json,os,shlex,subprocess
here=Path(__file__).resolve().parent
cache=Path('/root/hyle-scratch/io-watch-v2-dev')
out=Path('/root/hyle-scratch/io-direct-slots-20261018')
commands=[]
def run(tag,argv,env=None):
    result=subprocess.run(list(map(str,argv)),cwd=cache,env=env,stdin=subprocess.DEVNULL,
                          capture_output=True,text=True,timeout=60)
    commands.append({'tag':tag,'argv':list(map(str,argv)),'cwd':str(cache),
                     'LD_LIBRARY_PATH':None if env is None else env.get('LD_LIBRARY_PATH'),'exit_code':result.returncode})
    (here/(tag+'.stdout.txt')).write_text(result.stdout)
    (here/(tag+'.stderr.txt')).write_text(result.stderr)
    (here/'stage2-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(tag,result.returncode,flush=True)
    if result.returncode:raise RuntimeError(tag)
    return result.stdout
compdb=json.loads((here/'compdb.stdout.txt').read_text())
def compile_(suffix,source,output):
    old=shlex.split(next(x['command'] for x in compdb if x['file'].endswith(suffix)));new=[];i=0
    while i<len(old):
        if old[i] in ('-MT','-MF','-o','-c'):i+=2;continue
        if old[i]=='-MD':i+=1;continue
        new.append(old[i]);i+=1
    return new+['-o',str(output),'-c',str(source)]
raw=(here/'link-commands.stdout.txt').read_text()
def linker(target,output,oldobj,newobj):
    line=next(x for x in raw.splitlines() if ' -o '+target+' ' in x)
    args=shlex.split(line[len(': && '):-len(' && :')]);args[args.index('-o')+1]=str(output)
    args[args.index(oldobj)]=str(newobj);return args
env=os.environ.copy()
final=out/'final';final.mkdir(exist_ok=True)
obj=final/'proactor.o';lib=final/'libhyle_io_core.so.0.1.0';testobj=final/'tests.o';testexe=final/'tests'
run('compile-final',compile_('/src/io_core/proactor.cc',here/'final-proactor.cc',obj))
run('link-final',linker('bin/libhyle_io_core.so.0.1.0',lib,'src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o',obj))
run('compile-final-tests',compile_('/tests/io_core/proactor_test.cc',here/'final-proactor_test.cc',testobj))
run('link-final-tests',linker('bin/hyle_io_core_test',testexe,'tests/io_core/CMakeFiles/hyle_io_core_test.dir/proactor_test.cc.o',testobj))
env['LD_LIBRARY_PATH']=str(final)+':'+str(cache/'bin')
assert str(lib) in run('loader-final',['ldd',testexe],env)
run('test-final',[testexe,'--gtest_filter=Proactor.*'],env)
consumer=out/'admission'
run('compile-admission',['/usr/bin/g++-14','-std=c++23','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-Werror',
      '-I/mnt/c/public/project-hyle/hyle/include',here/'admission.cc','-o',consumer,
      '-L'+str(cache/'bin'),'-lhyle_io_core','-Wl,-rpath,'+str(cache/'bin'),'-ldl'])
prefix='''\n#if HYLE_OS_LINUX
namespace { unsigned long long hyle_accept_scan=0,hyle_close_scan=0; }
extern "C" __attribute__((visibility("default"))) unsigned long long hyle_direct_accept_visits(){return hyle_accept_scan;}
extern "C" __attribute__((visibility("default"))) unsigned long long hyle_direct_close_visits(){return hyle_close_scan;}
#endif
'''
results=[]
for arm,filename in [('scan-baseline','candidate-proactor.cc'),('scan-candidate','final-proactor.cc')]:
    text=(here/filename).read_text();anchor='#include "timeout_internal.h"\n';assert text.count(anchor)==1
    text=text.replace(anchor,anchor+prefix)
    if arm=='scan-baseline':
        before='''  for (const std::intptr_t value : impl_->file_slots)
    if (value == -1) ++free_slots;'''
        after='''  for (const std::intptr_t value : impl_->file_slots) {
    ++hyle_accept_scan;
    if (value == -1) ++free_slots;
  }'''
        assert text.count(before)==1;text=text.replace(before,after)
        before='''  for (const Impl::PendingDirectClose& pending :
       impl_->pending_direct_closes)
    if (pending.slot == slot) return false;'''
        after='''  for (const Impl::PendingDirectClose& pending :
       impl_->pending_direct_closes) {
    ++hyle_close_scan;
    if (pending.slot == slot) return false;
  }'''
        assert text.count(before)==1;text=text.replace(before,after)
    source=here/(arm+'.cc');source.write_text(text)
    directory=out/arm;directory.mkdir(exist_ok=True);obj=directory/'proactor.o';lib=directory/'libhyle_io_core.so.0.1.0'
    run('compile-'+arm,compile_('/src/io_core/proactor.cc',source,obj))
    run('link-'+arm,linker('bin/libhyle_io_core.so.0.1.0',lib,'src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o',obj))
    env['LD_LIBRARY_PATH']=str(directory)+':'+str(cache/'bin')
    assert str(lib) in run('loader-'+arm,['ldd',consumer],env)
    for table,batch in [(64,32),(1024,64),(4096,128)]:
        result=json.loads(run(f'{arm}-{table}-{batch}',[consumer,str(table),str(batch)],env))
        assert result['accepted']==batch and result['closed']==batch
        assert result['accept_scan_visits']==(table*batch if arm=='scan-baseline' else 0)
        assert result['close_scan_visits']==(batch*(batch-1)//2 if arm=='scan-baseline' else 0)
        results.append({'arm':arm,**result})
(here/'scan-results.json').write_text(json.dumps(results,indent=2)+'\n')
def record(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
old=json.loads((here/'cleanup-candidates.json').read_text())['files']
new=[record(p) for p in out.rglob('*') if p.is_file() and str(p) not in {r['path'] for r in old}]
records=old+new
(here/'cleanup-candidates.json').write_text(json.dumps({'files':records,'bytes':sum(r['bytes'] for r in records),'note':'Exact new binary artifacts only; no SDK or cached library/object deletion.'},indent=2)+'\n')
