from pathlib import Path
import hashlib,json,os
prefix=(Path(__file__).parent/'stage2.py').read_text().split('env=os.environ.copy()')[0]
exec(prefix.replace('stage2-commands.json','guard-commands.json'))
directory=out/'guard-final';directory.mkdir(exist_ok=True)
obj=directory/'proactor.o';lib=directory/'libhyle_io_core.so.0.1.0'
testobj=directory/'tests.o';testexe=directory/'tests'
run('compile-guard',compile_('/src/io_core/proactor.cc',here/'applied-proactor.cc',obj))
run('link-guard',linker('bin/libhyle_io_core.so.0.1.0',lib,'src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o',obj))
run('compile-guard-tests',compile_('/tests/io_core/proactor_test.cc',here/'applied-proactor_test.cc',testobj))
run('link-guard-tests',linker('bin/hyle_io_core_test',testexe,'tests/io_core/CMakeFiles/hyle_io_core_test.dir/proactor_test.cc.o',testobj))
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(directory)+':'+str(cache/'bin')
assert str(lib) in run('loader-guard',['ldd',testexe],env)
run('test-guard',[testexe,'--gtest_filter=Proactor.FixedTableAdmissionTracksFailedAcceptAndReleasedMappings'],env)
def record(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
records=[record(p) for p in out.rglob('*') if p.is_file()]
(here/'cleanup-candidates.json').write_text(json.dumps({'files':records,'bytes':sum(r['bytes'] for r in records),'note':'Exact new binaries only, immutable cache retained. Root test.ps1 before deletion.'},indent=2)+'\n')
