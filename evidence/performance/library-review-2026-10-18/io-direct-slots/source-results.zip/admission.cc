#include "hyle/io/detail/proactor.h"
#include <arpa/inet.h>
#include <dlfcn.h>
#include <sys/socket.h>
#include <unistd.h>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <vector>
using hyle::io::detail::Proactor;
using hyle::io::detail::Completion;
void check(bool ok) { if (!ok) std::abort(); }
int main(int argc,char**argv) {
  check(argc==3);const unsigned table=std::strtoul(argv[1],nullptr,10);
  const unsigned batch=std::strtoul(argv[2],nullptr,10);
  Proactor p;check(p.init(256));
  check(p.backend_kind()==hyle::io::IoBackend::kIoUring);
  check(p.register_file_table(table));
  const int listener=::socket(AF_INET,SOCK_STREAM|SOCK_CLOEXEC,0);check(listener>=0);
  sockaddr_in address{};address.sin_family=AF_INET;address.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
  check(::bind(listener,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0);
  check(::listen(listener,int(batch)+1)==0);socklen_t length=sizeof(address);
  check(::getsockname(listener,reinterpret_cast<sockaddr*>(&address),&length)==0);
  std::vector<int> clients(batch),slots(batch,-1);std::vector<bool> occupied(table);
  for(unsigned i=0;i<batch;++i){
    check(p.submit_accept_direct(listener,0xA000+i));
    clients[i]=::socket(AF_INET,SOCK_STREAM|SOCK_CLOEXEC,0);check(clients[i]>=0);
    check(::connect(clients[i],reinterpret_cast<sockaddr*>(&address),sizeof(address))==0);
  }
  std::array<Completion,256> events{};unsigned accepted=0;
  for(unsigned polls=0;accepted<batch&&polls<100;++polls){
    const auto n=p.reap(events.data(),events.size(),100'000'000);
    for(std::size_t j=0;j<n;++j){const auto&e=events[j];check(e.user_data>=0xA000&&e.user_data<0xA000+batch);
      check(e.result>=0&&std::uint64_t(e.result)<table);check(!occupied[e.result]);occupied[e.result]=true;
      check(slots[e.user_data-0xA000]==-1);slots[e.user_data-0xA000]=int(e.result);++accepted;}
  }
  check(accepted==batch&&!p.in_flight());
  for(unsigned i=0;i<batch;++i)check(p.submit_close_direct(slots[i],0xC000+i));
  std::vector<bool> seen(batch);unsigned closed=0;
  for(unsigned polls=0;closed<batch&&polls<100;++polls){
    const auto n=p.reap(events.data(),events.size(),100'000'000);
    for(std::size_t j=0;j<n;++j){const auto&e=events[j];check(e.user_data>=0xC000&&e.user_data<0xC000+batch);
      check(e.result==0&&!seen[e.user_data-0xC000]);seen[e.user_data-0xC000]=true;++closed;}
  }
  check(closed==batch&&!p.in_flight());
  using Count=unsigned long long(*)();
  const auto accept_visits=reinterpret_cast<Count>(dlsym(RTLD_DEFAULT,"hyle_direct_accept_visits"));
  const auto close_visits=reinterpret_cast<Count>(dlsym(RTLD_DEFAULT,"hyle_direct_close_visits"));
  check(accept_visits&&close_visits);
  std::printf("{\"table\":%u,\"batch\":%u,\"accepted\":%u,\"closed\":%u,\"accept_scan_visits\":%llu,\"close_scan_visits\":%llu}\n",table,batch,accepted,closed,accept_visits(),close_visits());
  const int reusable=p.assign_fixed_slot(listener);check(reusable>=0);check(p.release_fixed_slot(reusable));
  for(int client:clients) { ::close(client); }
  ::close(listener);
}
