#include "hyle/io/detail/proactor.h"

#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <unistd.h>

#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>

using hyle::io::detail::Completion;
using hyle::io::detail::Proactor;

#define CHECK(condition)                                                       \
  do {                                                                       \
    if (!(condition)) {                                                       \
      std::fprintf(stderr, "check failed at %d: %s errno=%d\n", __LINE__,        \
                   #condition, errno);                                       \
      std::abort();                                                           \
    }                                                                        \
  } while (false)

int main() {
  const bool stdin_open = ::fcntl(STDIN_FILENO, F_GETFD) >= 0;
  Proactor proactor;
  CHECK(proactor.init(16));
  CHECK(proactor.backend_kind() == hyle::io::IoBackend::kIoUring);
  CHECK(proactor.register_file_table(2));
  const int listener = ::socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
  CHECK(listener >= 0);
  sockaddr_in address{};
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  CHECK(::bind(listener, reinterpret_cast<sockaddr*>(&address),
               sizeof(address)) == 0);
  CHECK(::listen(listener, 8) == 0);
  socklen_t length = sizeof(address);
  CHECK(::getsockname(listener, reinterpret_cast<sockaddr*>(&address),
                      &length) == 0);

  const int old_client = ::socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
  CHECK(old_client >= 0);
  CHECK(::connect(old_client, reinterpret_cast<sockaddr*>(&address),
                  sizeof(address)) == 0);
  CHECK(proactor.submit_accept_direct(listener, 0xFA10));
  Completion event{};
  CHECK(proactor.reap(&event, 1, 1'000'000'000) == 1);
  CHECK(event.user_data == 0xFA10 && event.result == 0);
  const int slot = static_cast<int>(event.result);
  const char old_payload = 'o';
  CHECK(::send(old_client, &old_payload, 1, MSG_NOSIGNAL) == 1);
  char old_received = 0;
  CHECK(proactor.submit_recv_fixed(slot, &old_received, 1, 0, 0xFA11));
  CHECK(proactor.reap(&event, 1, 1'000'000'000) == 1);
  CHECK(event.user_data == 0xFA11 && event.result == 1);
  CHECK(old_received == old_payload);

  // The probe-only provider snapshot preserves both real CQEs, but forces the
  // accept CQE to be observed before the close CQE when both are ready.
  CHECK(proactor.submit_close_direct(slot, 0xFA20));
  CHECK(proactor.submit_accept_direct(listener, 0xFA21));
  CHECK(proactor.assign_fixed_slot(listener) == -1);
  const int new_client = ::socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
  CHECK(new_client >= 0);
  CHECK(::connect(new_client, reinterpret_cast<sockaddr*>(&address),
                  sizeof(address)) == 0);
  const char new_payload = 'n';
  CHECK(::send(new_client, &new_payload, 1, MSG_NOSIGNAL) == 1);
  CHECK(proactor.reap(&event, 1, 1'000'000'000) == 1);
  CHECK(event.user_data == 0xFA21 && event.result == slot);

  // The slot is now -4: usable for the new connection, while its old close is
  // still waiting in the CQ. It cannot start a second close yet.
  CHECK(!proactor.submit_close_direct(slot, 0xFA22));
  char new_received = 0;
  const char reply = 'r';
  CHECK(proactor.submit_recv_fixed(slot, &new_received, 1, 0, 0xFA30));
  CHECK(proactor.submit_send_fixed(slot, &reply, 1, 0, 0xFA31));
  const int other_slot = proactor.assign_fixed_slot(listener);
  CHECK(other_slot >= 0 && other_slot != slot);
  CHECK(proactor.release_fixed_slot(other_slot));
  CHECK(proactor.reap(&event, 1, 1'000'000'000) == 1);
  CHECK(event.user_data == 0xFA20 && event.result == 0);

  bool recv_done = false;
  bool send_done = false;
  std::array<Completion, 2> events{};
  for (unsigned attempt = 0; attempt != 4 && (!recv_done || !send_done);
       ++attempt) {
    const auto count = proactor.reap(events.data(), events.size(), 1'000'000'000);
    for (std::size_t index = 0; index != count; ++index) {
      CHECK(events[index].result == 1);
      if (events[index].user_data == 0xFA30) {
        CHECK(!recv_done);
        recv_done = true;
      } else {
        CHECK(events[index].user_data == 0xFA31 && !send_done);
        send_done = true;
      }
    }
  }
  CHECK(recv_done && send_done && new_received == new_payload);
  char reply_received = 0;
  CHECK(::recv(new_client, &reply_received, 1, MSG_DONTWAIT) == 1);
  CHECK(reply_received == reply);
  CHECK(proactor.submit_close_direct(slot, 0xFA40));
  CHECK(proactor.reap(&event, 1, 1'000'000'000) == 1);
  CHECK(event.user_data == 0xFA40 && event.result == 0);
  CHECK(!proactor.in_flight());

  const int first = proactor.assign_fixed_slot(listener);
  const int second = proactor.assign_fixed_slot(listener);
  CHECK(first >= 0 && second >= 0 && first != second);
  CHECK(proactor.assign_fixed_slot(listener) == -1);
  CHECK(proactor.release_fixed_slot(first));
  CHECK(proactor.release_fixed_slot(second));
  CHECK(::close(old_client) == 0);
  CHECK(::close(new_client) == 0);
  CHECK(::close(listener) == 0);
  CHECK(::fcntl(old_client, F_GETFD) < 0 && errno == EBADF);
  CHECK(::fcntl(new_client, F_GETFD) < 0 && errno == EBADF);
  CHECK(::fcntl(listener, F_GETFD) < 0 && errno == EBADF);
  CHECK(!stdin_open || ::fcntl(STDIN_FILENO, F_GETFD) >= 0);
  std::puts("{\"real_accepts\":2,\"real_closes\":2,"
            "\"old_payload\":true,\"new_payload\":true,\"new_reply\":true,"
            "\"new_io_before_old_close_reap\":true,"
            "\"second_close_rejected_while_old_close_pending\":true,"
            "\"other_free_slot_usable\":true,\"all_slots_reusable\":2,"
            "\"raw_fds_closed\":3,\"stdin_preserved\":true}");
}
