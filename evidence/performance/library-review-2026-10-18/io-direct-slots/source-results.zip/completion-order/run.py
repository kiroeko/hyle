from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent
CACHE = Path('/root/hyle-scratch/io-watch-v2-dev')
OUT = Path('/root/hyle-scratch/io-direct-slots-20261018/completion-order')
OUT.mkdir(exist_ok=True)
compdb = json.loads((PRIOR / 'compdb.stdout.txt').read_text())
links = (PRIOR / 'link-commands.stdout.txt').read_text()
records = []


def run(tag, argv, env=None):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=CACHE, env=env, stdin=subprocess.DEVNULL,
                            capture_output=True, text=True, timeout=60)
    records.append(dict(tag=tag, argv=argv, cwd=str(CACHE),
                        LD_LIBRARY_PATH=None if env is None else env.get('LD_LIBRARY_PATH'),
                        exit_code=result.returncode))
    (HERE / (tag + '.stdout.txt')).write_text(result.stdout)
    (HERE / (tag + '.stderr.txt')).write_text(result.stderr)
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout[-3000:]); print(result.stderr[-3000:])
        raise RuntimeError(tag)
    return result.stdout


def compile_command(suffix, source, output):
    old = shlex.split(next(x['command'] for x in compdb if x['file'].endswith(suffix)))
    new = []
    index = 0
    while index < len(old):
        if old[index] in ('-MT', '-MF', '-o', '-c'):
            index += 2
        elif old[index] == '-MD':
            index += 1
        else:
            new.append(old[index]); index += 1
    return new + ['-o', str(output), '-c', str(source)]


def link_command(target, output, oldobj, newobj):
    line = next(x for x in links.splitlines() if ' -o ' + target + ' ' in x)
    args = shlex.split(line[len(': && '):-len(' && :')])
    args[args.index('-o') + 1] = str(output)
    args[args.index(oldobj)] = str(newobj)
    return args


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


normal = OUT / 'normal'; normal.mkdir(exist_ok=True)
obj = normal / 'proactor.o'; library = normal / 'libhyle_io_core.so.0.1.0'
testobj = normal / 'tests.o'; tests = normal / 'tests'
run('compile-normal', compile_command('/src/io_core/proactor.cc', HERE / 'proactor.final.cc', obj))
run('link-normal', link_command('bin/libhyle_io_core.so.0.1.0', library,
                                'src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o', obj))
run('compile-tests', compile_command('/tests/io_core/proactor_test.cc', HERE / 'proactor_test.final.cc', testobj))
run('link-tests', link_command('bin/hyle_io_core_test', tests,
                               'tests/io_core/CMakeFiles/hyle_io_core_test.dir/proactor_test.cc.o', testobj))
env = os.environ.copy(); env['LD_LIBRARY_PATH'] = str(normal) + ':' + str(CACHE / 'bin')
assert str(library) in run('loader-normal', ['ldd', tests], env)
run('test-normal', ['timeout', '--kill-after=2s', '20s', tests,
                    '--gtest_filter=Proactor.DirectCloseBatchRetiresEachReservedSlot:'
                    'Proactor.FixedTableAdmissionTracksFailedAcceptAndReleasedMappings'], env)

source = (HERE / 'proactor.final.cc').read_text()
needle = '  std::size_t n = 0;\n  bool wake_fired = false;'
assert source.count(needle) == 1
hook = r'''
  // PROBE ONLY: retain the real CQEs and force their observation order.
  if (impl_->pending_completions.contains(0xFA20) &&
      impl_->pending_completions.contains(0xFA21)) {
    while (tail - head < 2) {
      const int result = sys_io_uring_enter(impl_->fd, 0, 2,
                                           IORING_ENTER_GETEVENTS, nullptr, 0);
      HYLE_FATAL_ASSERT(result >= 0 || errno == EINTR);
      tail = as_atomic(impl_->cq_tail)->load(std::memory_order_acquire);
    }
    unsigned close_pos = tail;
    unsigned accept_pos = tail;
    const unsigned probe_mask = *impl_->cq_ring_mask;
    for (unsigned position = head; position != tail; ++position) {
      const auto& event = impl_->cqes[position & probe_mask];
      if (event.user_data == 0xFA20) close_pos = position;
      if (event.user_data == 0xFA21) accept_pos = position;
    }
    HYLE_FATAL_ASSERT(close_pos != tail && accept_pos != tail);
    const auto close_cqe = impl_->cqes[close_pos & probe_mask];
    const auto accept_cqe = impl_->cqes[accept_pos & probe_mask];
    HYLE_FATAL_ASSERT(close_cqe.res == 0 && accept_cqe.res == 0);
    const bool swapped = close_pos < accept_pos;
    if (swapped) {
      impl_->cqes[close_pos & probe_mask] = accept_cqe;
      impl_->cqes[accept_pos & probe_mask] = close_cqe;
    }
    std::fprintf(stderr,
        "{\"observation_order_simulation\":true,\"swapped\":%s,"
        "\"close_cqe\":{\"user_data\":%llu,\"res\":%d,\"flags\":%u},"
        "\"accept_cqe\":{\"user_data\":%llu,\"res\":%d,\"flags\":%u}}\n",
        swapped ? "true" : "false",
        static_cast<unsigned long long>(close_cqe.user_data), close_cqe.res,
        close_cqe.flags, static_cast<unsigned long long>(accept_cqe.user_data),
        accept_cqe.res, accept_cqe.flags);
  }
'''
(HERE / 'proactor.probe.cc').write_text(source.replace(needle, hook + '\n' + needle))
probe = OUT / 'probe'; probe.mkdir(exist_ok=True)
probeobj = probe / 'proactor.o'; probelib = probe / 'libhyle_io_core.so.0.1.0'
consumer = probe / 'consumer'
run('compile-probe-provider', compile_command('/src/io_core/proactor.cc', HERE / 'proactor.probe.cc', probeobj))
run('link-probe-provider', link_command('bin/libhyle_io_core.so.0.1.0', probelib,
                                       'src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o', probeobj))
run('compile-probe-main', ['/usr/bin/g++-14', '-std=c++23', '-O3', '-DNDEBUG',
                           '-Wall', '-Wextra', '-Wpedantic', '-Werror',
                           '-I/mnt/c/public/project-hyle/hyle/include', HERE / 'order_probe.cc',
                           '-o', consumer, '-L' + str(CACHE / 'bin'), '-lhyle_io_core',
                           '-Wl,-rpath,' + str(CACHE / 'bin')])
env['LD_LIBRARY_PATH'] = str(probe) + ':' + str(CACHE / 'bin')
assert str(probelib) in run('loader-probe', ['ldd', consumer], env)
run('probe', ['timeout', '--kill-after=2s', '15s', consumer], env)

new_files = [identity(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
(HERE / 'binary-identities.json').write_text(json.dumps(new_files, indent=2) + '\n')
prior_files = json.loads((PRIOR / 'cleanup-candidates.json').read_text())['files']
by_path = {x['path']: x for x in prior_files + new_files}
(PRIOR / 'cleanup-candidates.json').write_text(json.dumps(dict(
    files=list(by_path.values()), bytes=sum(x['bytes'] for x in by_path.values()),
    note='Exact new binary artifacts only, includes prior root stages and completion-order final/probe; cached SDK/foundation untouched. Root test.ps1 cleanup only.'), indent=2) + '\n')
