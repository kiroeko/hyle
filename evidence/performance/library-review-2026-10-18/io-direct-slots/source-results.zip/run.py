from pathlib import Path
import hashlib,json,os,shlex,subprocess

here=Path(__file__).resolve().parent
cache=Path('/root/hyle-scratch/io-watch-v2-dev')
out=Path('/root/hyle-scratch/io-direct-slots-20261018')
out.mkdir(exist_ok=True)
commands=[]
def run(tag, argv, *, env=None, expected=0):
    record={'tag':tag,'argv':list(map(str,argv)),'cwd':str(cache),'expected':expected}
    if env:record['LD_LIBRARY_PATH']=env.get('LD_LIBRARY_PATH')
    result=subprocess.run(record['argv'],cwd=cache,env=env,stdin=subprocess.DEVNULL,
                          capture_output=True,text=True,timeout=60)
    record['exit_code']=result.returncode;commands.append(record)
    (here/(tag+'.stdout.txt')).write_text(result.stdout)
    (here/(tag+'.stderr.txt')).write_text(result.stderr)
    (here/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(tag, result.returncode,flush=True)
    if result.returncode!=expected:raise RuntimeError(tag)
    return result.stdout
def identity(p):
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
identities=[identity(cache/'bin/libhyle_io_core.so.0.1.0'),identity(cache/'bin/hyle_io_core_test')]
assert identities[0]['sha256']=='864a35ab5216cfafcba804e62ebbf0732c85ea2d1bab2fda9968e7573ee2d8c2'
assert hashlib.sha256((here/'baseline-proactor.cc').read_bytes()).hexdigest()=='7fb4d91b2d8d893eb3269decb568e1b8cefd1384cc8cfc0dae039bf880d798cb'
compdb=json.loads(run('compdb',['ninja','-C',str(cache),'-t','compdb']))
def compile_command(suffix, source, output):
    entry=next(x for x in compdb if x['file'].endswith(suffix))
    old=shlex.split(entry['command']);new=[];i=0
    while i<len(old):
        if old[i] in ('-MT','-MF','-o','-c'):i+=2;continue
        if old[i]=='-MD':i+=1;continue
        new.append(old[i]);i+=1
    return new+['-o',str(output),'-c',str(source)]
raw=run('link-commands',['ninja','-C',str(cache),'-t','commands','bin/libhyle_io_core.so.0.1.0','bin/hyle_io_core_test'])
def linker(target, output, oldobj, newobj):
    line=next(x for x in raw.splitlines() if ' -o '+target+' ' in x)
    assert line.startswith(': && ') and line.endswith(' && :')
    args=shlex.split(line[len(': && '):-len(' && :')]);args[args.index('-o')+1]=str(output)
    args[args.index(oldobj)]=str(newobj)
    return args
base_env=os.environ.copy();base_env['LD_LIBRARY_PATH']=str(cache/'bin')
run('baseline-direct',[cache/'bin/hyle_io_core_test','--gtest_filter=Proactor.DirectAccept:Proactor.DirectCloseBatchRetiresEachReservedSlot'],env=base_env)
tests_obj=out/'tests.o';tests_exe=out/'tests'
run('compile-tests',compile_command('/tests/io_core/proactor_test.cc',here/'candidate-proactor_test.cc',tests_obj))
run('link-tests',linker('bin/hyle_io_core_test',tests_exe,'tests/io_core/CMakeFiles/hyle_io_core_test.dir/proactor_test.cc.o',tests_obj))
for arm,source,expected,filter_ in [
    ('accept-only',here/'accept-only-proactor.cc',1,'Proactor.DirectCloseBatchRetiresEachReservedSlot'),
    ('candidate',here/'candidate-proactor.cc',0,'Proactor.*')]:
    directory=out/arm;directory.mkdir(exist_ok=True)
    obj=directory/'proactor.o';lib=directory/'libhyle_io_core.so.0.1.0'
    run('compile-'+arm,compile_command('/src/io_core/proactor.cc',source,obj))
    run('link-'+arm,linker('bin/libhyle_io_core.so.0.1.0',lib,'src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o',obj))
    env=base_env.copy();env['LD_LIBRARY_PATH']=str(directory)+':'+str(cache/'bin')
    loaded=run('loader-'+arm,['ldd',tests_exe],env=env)
    assert str(lib) in loaded
    run('test-'+arm,[tests_exe,'--gtest_filter='+filter_],env=env,expected=expected)
    identities.extend([identity(obj),identity(lib)])
identities.extend([identity(tests_obj),identity(tests_exe)])
(here/'binary-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
(here/'cleanup-candidates.json').write_text(json.dumps({'files':identities[2:],'bytes':sum(x['bytes'] for x in identities[2:]),'note':'Exact new obj/exe/shared overlays only; cached SDK untouched. Root test.ps1 before deletion.'},indent=2)+'\n')
