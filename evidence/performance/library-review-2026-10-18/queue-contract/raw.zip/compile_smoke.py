from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
env['VSLANG'] = '1033'
resume = '--resume' in sys.argv
records = json.loads((HERE / 'commands.json').read_text()) if resume else []

def run(name, argv, extra=None):
    selected = dict(env)
    selected.update(extra or {})
    start = time.monotonic()
    result = subprocess.run([str(x) for x in argv], cwd=HERE, env=selected, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45)
    (HERE / (name + '.log')).write_bytes(result.stdout)
    records.append({'name': name, 'argv': [str(x) for x in argv], 'environment_overrides': extra or {}, 'returncode': result.returncode, 'elapsed_seconds': time.monotonic() - start})
    (HERE / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:])
        raise SystemExit(result.returncode)

flags = ['/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus', '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/DHYLE_STATIC', '/I' + str(ROOT / 'include'), '/external:I' + str(ROOT / 'third_party/nanobench'), '/external:W0']
peer_flags = ['/DHYLE_BENCH_RIGTORP', '/DHYLE_BENCH_MOODYCAMEL',
              '/external:I' + str(ROOT.parent / 'rigtorp-MPMCQueue/include'),
              '/external:I' + str(ROOT.parent / 'moodycamel-ConcurrentQueue')]
for name, relative, additions in [('mpmc', 'bench/container/queue_sota_bench.cc', peer_flags),
                                   ('spsc', 'bench/container/spsc_bench.cc', []),
                                   ('nanobench', 'bench/nanobench_impl.cc', [])]:
    if not resume:
        run('compile-' + name, [CL, *flags, *additions, ROOT / relative, '/Fo' + str(HERE / (name + '.obj'))])
foundation = ROOT / '.scratch/build-compute-v2-dev/bin'
libraries = [foundation / (name + '.lib') for name in ['hyle_platform_thread', 'hyle_platform', 'hyle_time', 'hyle_mem', 'mimalloc_static', 'hyle_error']]
for name in ['mpmc', 'spsc']:
    if not resume or name == 'spsc':
        run('link-' + name + ('-resume' if resume else ''), [CL.with_name('link.exe'), '/nologo', '/INCREMENTAL:NO', '/OPT:REF', '/OUT:' + str(HERE / (name + '.exe')), HERE / (name + '.obj'), HERE / 'nanobench.obj', *libraries, 'advapi32.lib', 'bcrypt.lib', 'Synchronization.lib'])
if '--smoke' in sys.argv:
    run('smoke-mpmc', [HERE / 'mpmc.exe'], {'HYLE_BENCH_SMOKE': '1', 'HYLE_QUEUE_BENCH_FILTER': 'mpmc'})
    run('smoke-spsc', [HERE / 'spsc.exe'], {'HYLE_BENCH_SMOKE': '1'})
identity = {'sources': {relative: hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() for relative in ['bench/container/queue_sota_bench.cc', 'bench/container/spsc_bench.cc']},
            'foundation': [{'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in libraries],
            'peer_headers': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in [ROOT.parent / 'rigtorp-MPMCQueue/include/rigtorp/MPMCQueue.h', ROOT.parent / 'moodycamel-ConcurrentQueue/concurrentqueue.h']},
            'limits': 'Only compile/link and one fixed-iteration no-output smoke per row. No full benchmark, timing ranking or TBB optional branch run.'}
(HERE / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
