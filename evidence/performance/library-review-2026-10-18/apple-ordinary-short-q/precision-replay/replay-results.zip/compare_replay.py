"""Offline reproduction/error-boundary check; never starts a GPU process."""
from array import array
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import sys
import zipfile


def values(raw, kind):
    result = array(kind)
    result.frombytes(raw)
    if sys.byteorder != 'little':
        result.byteswap()
    return result


def main():
    local = Path(__file__).resolve().parent
    with zipfile.ZipFile(local / 'replay-raw.zip') as replay, zipfile.ZipFile(
            local.parent / 'diagnostic/full-output-raw.zip') as original:
        raw = replay.read('raw/full-pv-bhsd-phase0.f32')
        old_raw = original.read('raw-baseline/bhsd-phase0.f32')
        assert len(raw) == len(old_raw) == 4202496
        pv, old = values(raw, 'f'), values(old_raw, 'f')
        bits, old_bits = values(raw, 'I'), values(old_raw, 'I')
        p_raw = replay.read('raw/P-h0q0.f32')
        p = values(p_raw, 'f')
        v = values(replay.read('raw/actual-V-kvhead0-sd.f32'), 'f')
        assert len(p) == 8193 and len(v) == 8193 * 256
        dots = []
        for d in range(256):
            ideal = math.fsum(v[s * 256 + d] for s in range(8193)) / 8193
            actual_dot = math.fsum(float(p[s]) * v[s * 256 + d] for s in range(8193))
            dots.append({'channel': d, 'pv': pv[d], 'ideal_uniform_fp64': ideal,
                'fp64_dot_actual_P_actual_V': actual_dot,
                'P_contribution': actual_dot - ideal,
                'PV_reduction_residual': float(pv[d]) - actual_dot})
        cpp = [json.loads(line) for line in replay.read('raw/first-row-dots.jsonl').decode().splitlines()]
        result = {
            'full_PV_elements': len(pv),
            'full_PV_bit_differences': sum(a != b for a, b in zip(bits, old_bits)),
            'full_PV_max_absolute_difference': max(abs(a - b) for a, b in zip(pv, old)),
            'full_PV_sha256': hashlib.sha256(raw).hexdigest(),
            'original_baseline_PV_sha256': hashlib.sha256(old_raw).hexdigest(),
            'P_bit_counts': dict(Counter(values(p_raw, 'I'))),
            'P_sum_fp64': math.fsum(p),
            'max_absolute_P_error': max(abs(float(q) - 1 / 8193) for q in p),
            'max_absolute_P_output_contribution': max(abs(d['P_contribution']) for d in dots),
            'max_absolute_PV_reduction_residual': max(abs(d['PV_reduction_residual']) for d in dots),
            'cpp_vs_math_fsum_dot_max_difference': max(abs(a['fp64_dot_actual_P_actual_V'] -
                b['fp64_dot_actual_P_actual_V']) for a, b in zip(dots, cpp)),
            'channel0': dots[0],
            'interpretation': 'Source-equivalent replay, not a private fast hook. '
                'Attribute the first-row boundary only after complete PV reproduction; '
                'this is not a kernel/pipeline identification or an accuracy pass.'}
        print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
