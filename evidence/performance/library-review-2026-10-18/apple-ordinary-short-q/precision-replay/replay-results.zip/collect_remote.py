from pathlib import Path
import base64,hashlib,json,zipfile
root=Path('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q/precision-replay')
archive=root/'replay-raw.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted((root/'raw').iterdir()):z.write(p,'raw/'+p.name)
 for p in sorted(root.iterdir()):
  if p.is_file() and (p.suffix in ['.cc','.json','.map'] or p.name.endswith(('.stdout.txt','.stderr.txt'))):z.write(p,p.name)
raw=archive.read_bytes();print(json.dumps({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'data':base64.b64encode(raw).decode()}))
