#include "tests/compute_route_apple/tensor_test_support.h"
#include <mlx/utils.h>

#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>

namespace {
using namespace apple_tensor_test;
namespace sq = apple_tensor_test::ordinary_short_query;
namespace fs = std::filesystem;
static_assert(std::endian::native == std::endian::little);

void checked(hyle::Status status, const char *where) {
  if (status.ok()) return;
  std::ostringstream text;
  text << where << ": " << status.message();
  throw std::runtime_error(text.str());
}
template <class T> T take(hyle::Result<T> result, const char *where) {
  if (!result) checked(result.error(), where);
  return std::move(*result);
}
template <class T> void write(const fs::path &path, const std::vector<T> &data) {
  std::ofstream file(path, std::ios::binary);
  file.write(reinterpret_cast<const char *>(data.data()), data.size() * sizeof(T));
  if (!file) throw std::runtime_error("binary write failed");
}
std::string number(double value) {
  if (!std::isfinite(value)) return std::isnan(value) ? "\"NaN\"" : "\"Infinity\"";
  std::ostringstream out;
  out << std::setprecision(17) << value;
  return out.str();
}
void ready_f32(const mx::array &value) {
  if (value.dtype() != mx::float32 || value.status() != mx::array::available)
    throw std::runtime_error("published value is not ready F32");
}
std::vector<float> flatten(const mx::array &value) {
  ready_f32(value);
  std::vector<float> result(value.size());
  for (std::size_t i = 0; i < result.size(); ++i) {
    std::size_t rest = i, offset = 0;
    for (std::size_t axis = value.ndim(); axis-- > 0;) {
      offset += (rest % value.shape()[axis]) * value.strides()[axis];
      rest /= value.shape()[axis];
    }
    result[i] = value.data<float>()[offset];
  }
  return result;
}

std::vector<float> first_row(const mx::array &value) {
  ready_f32(value);
  if (value.shape() != mx::Shape{1, 2, 4, sq::queries, sq::keys})
    throw std::runtime_error("published scores/P shape differs from original GQA");
  std::vector<float> row(sq::keys);
  for (int s = 0; s < sq::keys; ++s)
    row[s] = value.data<float>()[std::size_t(s) * value.strides(4)];
  return row;
}

void describe_row(std::ostream &out, const std::vector<float> &row) {
  std::map<std::uint32_t, std::size_t> counts;
  double sum = 0, minimum = std::numeric_limits<double>::infinity(),
         maximum = -std::numeric_limits<double>::infinity();
  for (float value : row) {
    ++counts[std::bit_cast<std::uint32_t>(value)];
    sum += value;
    minimum = std::min(minimum, double(value));
    maximum = std::max(maximum, double(value));
  }
  out << "{\"elements\":" << row.size() << ",\"dtype\":\"F32\",\"min\":"
      << number(minimum) << ",\"max\":" << number(maximum)
      << ",\"sum_fp64\":" << number(sum) << ",\"bit_counts\":[";
  bool first = true;
  for (const auto &[bits, count] : counts) {
    if (!first) out << ',';
    first = false;
    out << "{\"bits_u32\":" << bits << ",\"bits_hex\":\"0x" << std::hex
        << std::setw(8) << std::setfill('0') << bits << std::dec
        << "\",\"count\":" << count << '}';
  }
  out << "]}";
}
} // namespace

int main(int argc, char **argv) {
  if (argc != 3 || std::string(argv[1]) != "--output") return 2;
  try {
    const fs::path directory(argv[2]);
    if (fs::exists(directory)) throw std::runtime_error("refuse to overwrite replay data");
    fs::create_directories(directory);
    const auto inputs = sq::ports(c::AttentionLayout::kBatchHeadSequenceDepth, 0);
    auto context = take(a::Context::create(), "create context");
    // Source-equivalent replay of pinned fast.cpp fallback lines872-935,
    // including its initial array-mask broadcast (lines952-955). Publishing
    // intermediates is NOT an opaque mx::fast internal hook.
    auto program = take(context.compile(
        [](const std::vector<mx::array> &ports, mx::Stream native)
            -> hyle::Result<std::vector<mx::array>> {
          auto q = mx::multiply(mx::array(sq::scale, ports[0].dtype()), ports[0], native);
          q = mx::unflatten(q, 1, {sq::kv_heads, sq::heads / sq::kv_heads}, native);
          auto k = mx::expand_dims(ports[1], 2, native);
          auto v = mx::expand_dims(ports[2], 2, native);
          auto scores = mx::matmul(q, mx::swapaxes(k, -1, -2, native), native);
          auto mask = mx::broadcast_to(ports[3], {1, sq::heads, sq::queries, sq::keys}, native);
          mask = mx::unflatten(mask, -3, {sq::kv_heads, sq::heads / sq::kv_heads}, native);
          auto masked = mx::where(mask, scores,
              mx::array(mx::finfo(scores.dtype()).min, scores.dtype()), native);
          auto p = mx::softmax(masked, std::vector<int>{-1}, true, native);
          auto pv = mx::flatten(mx::matmul(p, v, native), 1, 2, native);
          return std::vector{pv, masked, p};
        }, inputs), "compile source replay");
    auto slot = take(program.create_invocation(), "create invocation");
    checked(slot.bind(inputs), "bind original four ports");
    auto accepted = take(slot.submit(), "submit source replay");
    auto finished = take(accepted.wait(), "checked replay completion");
    const auto outputs = finished.get()->arrays();
    if (outputs.size() != 3 || outputs[0].shape() != mx::Shape{1, sq::heads, sq::queries, sq::depth})
      throw std::runtime_error("replay output arity/PV shape mismatch");
    const auto pv = flatten(outputs[0]);
    const auto scores = first_row(outputs[1]), p = first_row(outputs[2]);
    write(directory / "full-pv-bhsd-phase0.f32", pv);
    write(directory / "masked-scores-h0q0.f32", scores);
    write(directory / "P-h0q0.f32", p);
    ready_f32(inputs[2]);
    std::vector<float> actual_v(std::size_t(sq::keys) * sq::depth);
    for (int s = 0; s < sq::keys; ++s)
      for (int d = 0; d < sq::depth; ++d)
        actual_v[std::size_t(s) * sq::depth + d] = inputs[2].data<float>()[
            std::size_t(s) * inputs[2].strides(2) + std::size_t(d) * inputs[2].strides(3)];
    write(directory / "actual-V-kvhead0-sd.f32", actual_v);

    // Reuse the exact independent oracle already captured by the primary
    // baseline diagnostic. No new FP64 reference formula or budget.
    const auto oracle_path = directory.parent_path().parent_path() /
        "diagnostic/raw-baseline/oracle-phase0-hqt17.f64";
    std::vector<double> oracle(std::size_t(sq::heads) * sq::queries * 17);
    std::ifstream oracle_file(oracle_path, std::ios::binary);
    oracle_file.read(reinterpret_cast<char *>(oracle.data()), oracle.size() * sizeof(double));
    if (!oracle_file) throw std::runtime_error("captured FP64 oracle read failed");
    std::size_t violations = 0;
    double max_abs = 0, max_normalized = 0;
    for (int h = 0; h < sq::heads; ++h)
      for (int t = 0; t < sq::queries; ++t)
        for (int d = 0; d < sq::depth; ++d) {
          const double target = static_cast<float>(oracle[(h * sq::queries + t) * 17 + d % 17]);
          const double actual = pv[(h * sq::queries + t) * sq::depth + d];
          const double error = std::isfinite(actual) ? std::abs(actual - target)
              : std::numeric_limits<double>::infinity();
          const double allowed = 2e-6 + 6e-6 * std::abs(target);
          violations += error > allowed;
          max_abs = std::max(max_abs, error);
          max_normalized = std::max(max_normalized, error / allowed);
        }
    std::ofstream details(directory / "first-row-dots.jsonl");
    double max_p_contribution = 0, max_pv_reduction = 0;
    for (int d = 0; d < sq::depth; ++d) {
      double ideal_sum = 0, actual_p_dot = 0;
      for (int s = 0; s < sq::keys; ++s) {
        const double v = actual_v[std::size_t(s) * sq::depth + d];
        ideal_sum += v;
        actual_p_dot += double(p[s]) * v;
      }
      const double ideal = ideal_sum / sq::keys;
      const double p_contribution = actual_p_dot - ideal;
      const double pv_reduction = double(pv[d]) - actual_p_dot;
      max_p_contribution = std::max(max_p_contribution, std::abs(p_contribution));
      max_pv_reduction = std::max(max_pv_reduction, std::abs(pv_reduction));
      details << "{\"channel\":" << d << ",\"pv\":" << number(pv[d])
          << ",\"ideal_uniform_fp64\":" << number(ideal)
          << ",\"fp64_dot_actual_P_actual_V\":" << number(actual_p_dot)
          << ",\"P_contribution\":" << number(p_contribution)
          << ",\"PV_reduction_residual\":" << number(pv_reduction) << "}\n";
    }
    if (!details) throw std::runtime_error("first-row details write failed");
    std::ostringstream summary;
    summary << "{\"diagnostic_complete\":true,\"source_equivalent_replay\":true,"
        << "\"opaque_native_internal_hook\":false,\"golden_pass\":" << (violations == 0 ? "true" : "false")
        << ",\"original_expect_violations\":" << violations
        << ",\"max_absolute\":" << number(max_abs)
        << ",\"max_normalized\":" << number(max_normalized)
        << ",\"masked_scores_first_row\":";
    describe_row(summary, scores);
    summary << ",\"P_first_row\":";
    describe_row(summary, p);
    summary << ",\"ideal_P\":" << number(1.0 / sq::keys)
        << ",\"max_abs_P_contribution_first_row\":" << number(max_p_contribution)
        << ",\"max_abs_PV_reduction_residual_first_row\":" << number(max_pv_reduction)
        << ",\"exit_zero_means\":\"collection complete; reproduction and golden failure are separate\"}\n";
    std::ofstream file(directory / "summary.json");
    file << summary.str();
    if (!file) throw std::runtime_error("summary write failed");
    std::cout << summary.str();
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "diagnostic incomplete: " << error.what() << '\n';
    return 3;
  }
}
