from pathlib import Path
import subprocess,tarfile
OUT=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink'
code=r'''
from pathlib import Path
import sys,tarfile
p=Path(REMOTE)
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as t:
 for f in sorted(p.iterdir()):
  if f.is_file() and f.suffix in ['.cc','.cpp','.py','.json','.map','.txt']:
   t.add(f,arcname=f.name)
'''.replace('REMOTE',repr(REMOTE))
r=subprocess.run(['ssh','kiro@172.22.10.198','/usr/bin/python3 -'],input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
(OUT/'collect.stderr.txt').write_bytes(r.stderr)
if r.returncode:raise SystemExit(r.returncode)
(OUT/'measured-raw.tar.gz').write_bytes(r.stdout)
with tarfile.open(OUT/'measured-raw.tar.gz') as t:
 for member in t.getmembers():
  target=(OUT/'measured'/member.name).resolve()
  if not target.is_relative_to((OUT/'measured').resolve()):raise RuntimeError('unexpected archive path')
 t.extractall(OUT/'measured',filter='data')
print('collected',len(r.stdout),'bytes')
