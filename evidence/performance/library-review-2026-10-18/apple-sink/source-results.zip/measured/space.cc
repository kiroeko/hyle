#include "tests/compute_route_apple/tensor_test_support.h"
#include "hyle/compute/model_ops.h"
#include <mlx/memory.h>
#include <array>
#include <iomanip>
#include <iostream>
int main() {
  using namespace apple_tensor_test;
  try {
    constexpr int depth = 512, queries = 1025, keys = 2049, heads = 64;
    auto zeros = [](mx::Shape shape) {
      std::size_t count = 1;
      for (int n : shape) count *= std::size_t(n);
      std::vector<float> data(count);
      return mx::array(data.data(), std::move(shape), mx::float32);
    };
    std::vector<float> v(std::size_t(keys) * depth);
    for (int s = 0; s < keys; ++s)
      std::fill_n(v.begin() + std::size_t(s) * depth, depth,
                     s % 2 == 0 ? 1.25F : -1.25F);
    const std::array inputs{
        zeros({1, queries, heads, depth}), zeros({1, keys, 1, depth}),
        mx::array(v.data(), {1, keys, 1, depth}, mx::float32),
        zeros({queries, keys}), zeros({heads})};
    auto context = a::Context::create().value();
    auto program = context.prepare(c::model_ops::sink_attention(0.0625F), inputs).value();
    auto slot = program.create_invocation().value();
    auto bound = slot.bind(inputs);
    if (!bound.ok()) { std::cerr << bound.message(); return 2; }
    mx::clear_cache();
    const auto before = mx::get_active_memory(), cache_before = mx::get_cache_memory();
    mx::reset_peak_memory();
    auto work = slot.submit().value();
    auto result = work.wait().value();
    mx::synchronize(stream());
    const auto after = mx::get_active_memory(), peak = mx::get_peak_memory(),
               cache_after = mx::get_cache_memory();
    const auto &output = result.get()->arrays()[0];
    const float *data = output.data<float>();
    bool passed = output.shape() == mx::Shape{1, queries, heads, depth};
    const double expected = 1.25 / double(keys + 1);
    double max_error = 0;
    for (int t = 0; t < queries; ++t)
      for (int h = 0; h < heads; ++h)
        for (int d = 0; d < depth; ++d) {
          const auto offset = std::size_t(t) * output.strides(1) +
              std::size_t(h) * output.strides(2) + std::size_t(d) * output.strides(3);
          const double actual = data[offset];
          const double error = std::abs(actual - expected);
          passed &= std::isfinite(actual) && error <= 6e-6 * std::abs(expected) + 2e-6;
          max_error = std::max(max_error, error);
        }
    std::cout << std::setprecision(17)
        << "{\"dtype\":\"F32\",\"B\":1,\"H\":64,\"Hkv\":1,\"D\":512,\"Q\":1025,\"KV\":2049,\"input\":\"QKmaskSink0,V alternating +1.25/-1.25\",\"caller_qkv_mask_sinks_bytes\":151142660,\"output_bytes\":134348800,\"original_score_bytes\":537657600,\"active_before\":" << before
        << ",\"cache_before\":" << cache_before << ",\"active_after\":" << after
        << ",\"peak\":" << peak << ",\"peak_minus_active_before\":" << (peak-before)
        << ",\"cache_after\":" << cache_after << ",\"max_abs_error\":" << max_error
        << ",\"checked_elements\":" << output.size()
        << ",\"oracle_passed\":" << (passed ? "true" : "false") << "}\n";
    return passed ? 0 : 3;
  } catch (const std::exception &e) { std::cerr << e.what() << "\n"; return 4; }
}
