#include "tensor_test_support.h"
#include "hyle/compute/model_ops.h"

#include <array>
#include <bit>
#include <cstdio>

namespace {
using namespace apple_tensor_test;

constexpr int kSinkDepth = 512;
constexpr float kSinkScale = 0.125F;

float sink_query(int token, int head, int channel, int seed) {
  return channel == 0
      ? float((token + seed) % 7 - 3) / 8 + float(head) / 256
      : float((head + seed) % 9 - 4) / 16;
}
float sink_key(int row, int channel, int seed) {
  return channel == 0 ? float((row + seed) % 11 - 5) / 16
                      : float((row + 2 * seed) % 13 - 6) / 32;
}
float sink_mask(int token, int row, int queries, int keys, int seed) {
  return token == 15 || token == 16 || token == queries - 1 ||
                 (token + seed) % 97 == 0 || row > keys - queries + token ||
                 (row + token + seed) % 5 == 0
      ? -std::numeric_limits<float>::infinity()
      : float((row + token + seed) % 7 - 3) / 16;
}
float sink_logit(int head, int seed) {
  return float((head + seed) % 9 - 4) / 4;
}

std::array<mx::array, 5> sink_ports(int queries, int keys, int heads, int seed) {
  std::vector<float> q(std::size_t(queries) * heads * kSinkDepth),
      k(std::size_t(keys) * kSinkDepth), v(k.size()),
      mask(std::size_t(queries) * keys), sinks(heads);
  for (int t = 0; t < queries; ++t)
    for (int h = 0; h < heads; ++h) {
      const auto offset = std::size_t(t * heads + h) * kSinkDepth;
      q[offset] = sink_query(t, h, 0, seed);
      q[offset + 1] = sink_query(t, h, 1, seed);
    }
  for (int s = 0; s < keys; ++s) {
    k[std::size_t(s) * kSinkDepth] = sink_key(s, 0, seed);
    k[std::size_t(s) * kSinkDepth + 1] = sink_key(s, 1, seed);
    const float factor = float((s + seed) % 17 - 8) / 16;
    for (int d = 0; d < kSinkDepth; ++d)
      v[std::size_t(s) * kSinkDepth + d] =
          factor * float(d % 7 - 3) / 32 + float(d % 11 - 5) / 64;
  }
  for (int t = 0; t < queries; ++t)
    for (int s = 0; s < keys; ++s)
      mask[std::size_t(t) * keys + s] = sink_mask(t, s, queries, keys, seed);
  for (int h = 0; h < heads; ++h) sinks[h] = sink_logit(h, seed);
  return {mx::array(q.data(), {1, queries, heads, kSinkDepth}, mx::float32),
      mx::array(k.data(), {1, keys, 1, kSinkDepth}, mx::float32),
      mx::array(v.data(), {1, keys, 1, kSinkDepth}, mx::float32),
      mx::array(mask.data(), {queries, keys}, mx::float32),
      mx::array(sinks.data(), {heads}, mx::float32)};
}

struct SinkExpectedRow {
  double weighted = 0;
  double mass = 0;
};
std::vector<SinkExpectedRow> sink_reference(int queries, int keys, int heads,
                                           int seed) {
  std::vector<SinkExpectedRow> result(std::size_t(queries) * heads);
  std::vector<double> scores(keys);
  for (int t = 0; t < queries; ++t)
    for (int h = 0; h < heads; ++h) {
      double maximum = sink_logit(h, seed);
      for (int s = 0; s < keys; ++s) {
        scores[s] = (double(sink_query(t, h, 0, seed)) * sink_key(s, 0, seed) +
                      double(sink_query(t, h, 1, seed)) * sink_key(s, 1, seed)) *
                kSinkScale + sink_mask(t, s, queries, keys, seed);
        maximum = std::max(maximum, scores[s]);
      }
      double denominator = std::exp(double(sink_logit(h, seed)) - maximum);
      double mass = 0, weighted = 0;
      for (int s = 0; s < keys; ++s) {
        const double weight = std::exp(scores[s] - maximum);
        denominator += weight;
        mass += weight;
        weighted += weight * (double((s + seed) % 17 - 8) / 16);
      }
      result[std::size_t(t) * heads + h] = {weighted / denominator,
                                                   mass / denominator};
    }
  return result;
}

std::uint64_t sink_output_hash(const mx::array &output) {
  const float *data = output.data<float>();
  std::uint64_t hash = 1469598103934665603ULL;
  for (int t = 0; t < output.shape(1); ++t)
    for (int h = 0; h < output.shape(2); ++h)
      for (int d = 0; d < kSinkDepth; ++d) {
        const auto offset = std::size_t(t) * output.strides(1) +
            std::size_t(h) * output.strides(2) +
            std::size_t(d) * output.strides(3);
        hash = (hash ^ std::bit_cast<std::uint32_t>(data[offset])) * 1099511628211ULL;
      }
  return hash;
}

void check_sink(const mx::array &output,
                 const std::vector<SinkExpectedRow> &expected) {
  ASSERT_EQ(output.dtype(), mx::float32);
  ASSERT_EQ(output.shape(3), kSinkDepth);
  ASSERT_EQ(expected.size(), std::size_t(output.shape(1)) * output.shape(2));
  const float *data = output.data<float>();
  bool finite = true;
  double maximum_error = 0, maximum_budget_fraction = 0;
  for (int t = 0; t < output.shape(1); ++t)
    for (int h = 0; h < output.shape(2); ++h) {
      const auto row = expected[std::size_t(t) * output.shape(2) + h];
      const auto offset = std::size_t(t) * output.strides(1) +
          std::size_t(h) * output.strides(2);
      for (int d = 0; d < kSinkDepth; ++d) {
        // All source values and both separable V terms are exactly dyadic F32.
        const double value = row.weighted * (double(d % 7 - 3) / 32) +
            row.mass * (double(d % 11 - 5) / 64);
        const double actual = data[offset + std::size_t(d) * output.strides(3)];
        finite &= std::isfinite(actual);
        const double error = std::abs(actual - value);
        maximum_error = std::max(maximum_error, error);
        maximum_budget_fraction = std::max(maximum_budget_fraction,
            error / (6e-6 * std::abs(value) + 2e-6));
      }
    }
  EXPECT_TRUE(finite);
  EXPECT_LE(maximum_budget_fraction, 1);
  std::printf("{\"kind\":\"sink_numeric\",\"Q\":%d,\"H\":%d,\"maximum_error\":%.17g,\"maximum_budget_fraction\":%.17g,\"finite\":%s}\n",
      output.shape(1), output.shape(2), maximum_error, maximum_budget_fraction,
      finite ? "true" : "false");
}

TEST(AppleSinkAttention, QBlocksKeepMasksSinksRebindingAndOwners) {
  constexpr int queries = 1025, keys = 2049, heads = 64;
  const auto reference_a = sink_reference(queries, keys, heads, 0);
  const auto reference_b = sink_reference(queries, keys, heads, 7);
  auto inputs_a = sink_ports(queries, keys, heads, 0);
  auto inputs_b = sink_ports(queries, keys, heads, 7);
  auto context = a::Context::create().value();
  auto program = context.prepare(c::model_ops::sink_attention(kSinkScale), inputs_a).value();
  auto first = program.create_invocation().value();
  auto second = program.create_invocation().value();
  ASSERT_TRUE(first.bind(inputs_a).ok());
  ASSERT_TRUE(second.bind(inputs_b).ok());
  auto work_a = first.submit().value(), work_b = second.submit().value();
  auto result_a = work_a.wait().value(), result_b = work_b.wait().value();
  auto output_a = result_a.get()->arrays()[0];
  auto output_b = result_b.get()->arrays()[0];
  check_sink(output_a, reference_a);
  check_sink(output_b, reference_b);
  ASSERT_FALSE(::testing::Test::HasFailure());
  const auto original_hash = sink_output_hash(output_a);
  ASSERT_TRUE(first.bind(inputs_b).ok());
  auto rebound = first.submit().value();
  inputs_a = inputs_b;
  first = {};
  second = {};
  program = {};
  context = {};
  auto result = rebound.wait().value();
  check_sink(result.get()->arrays()[0], reference_b);
  EXPECT_EQ(sink_output_hash(output_a), original_hash);
}

TEST(AppleSinkAttention, ShortQueriesRetainExistingFallback) {
  constexpr int queries = 17, keys = 31, heads = 128;
  auto inputs = sink_ports(queries, keys, heads, 3);
  auto context = a::Context::create().value();
  auto result = execute(context, c::model_ops::sink_attention(kSinkScale), inputs);
  ASSERT_TRUE(result) << result.error().message();
  check_sink(*result, sink_reference(queries, keys, heads, 3));
}
} // namespace
