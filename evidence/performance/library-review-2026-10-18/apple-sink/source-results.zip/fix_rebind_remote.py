import validate_remote as v
import hashlib,json
OUT=v.OUT
v.run('rebindfix-tests-compile',['/usr/bin/clang++',*v.flags,'-c',OUT/'sink_tests.cc','-o',OUT/'tests.o'])
for arm in ['baseline','candidate']:
    v.run('rebindfix-'+arm+'-tests-link',['/usr/bin/clang++','-O3','-std=c++23','-o',OUT/(arm+'-tests'),OUT/'tests.o',OUT/('apple-'+arm+'.o'),*v.libs,
        v.CORE/'lib/libgtest_main.a',v.CORE/'lib/libgtest.a',*v.frameworks,'-Wl,-map,'+str(OUT/('rebindfix-'+arm+'-tests.map'))])
for arm in ['baseline','candidate']:
    v.run('rebindfix-'+arm+'-tests',[OUT/(arm+'-tests'),'--gtest_filter=AppleSinkAttention.*','--gtest_output=json:'+str(OUT/('rebindfix-'+arm+'-tests.json'))],required=False)
identity={str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [OUT/'tests.o',OUT/'baseline-tests',OUT/'candidate-tests']}
(OUT/'rebindfix-runtime-identities.json').write_text(json.dumps(identity,indent=2))
