from pathlib import Path
import hashlib,json,re,subprocess,zipfile
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
RAW=OUT/'measured'
baseline=json.loads((RAW/'baseline-space.stdout.txt').read_text())
candidate=json.loads((RAW/'candidate-space.stdout.txt').read_text())
identities=json.loads((RAW/'runtime-identities.json').read_text())
identities.update(json.loads((RAW/'rebindfix-runtime-identities.json').read_text()))
remote='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink/'
cleanup={'remote_files':[{'path':p,**v} for p,v in identities.items() if p.startswith(remote)],'preserve':'Source/log/data/maps/commands, original SDK/foundation/gtest/metallib; only listed8 object/executable files are cleanup targets, via root test.ps1. No deletion performed.'}
(OUT/'cleanup-candidates.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf-8')
maps={}
for name in ['baseline-tests','candidate-tests','baseline-space','candidate-space','rebindfix-baseline-tests','rebindfix-candidate-tests']:
    text=(RAW/(name+'.map')).read_text()
    arm='candidate' if 'candidate' in name else 'baseline'
    maps[name]={'fresh_lowerer':bool(re.search(r'^\[\s*\d+\].*apple-'+arm+r'\.o$',text,re.M)),
        'old_archive_lowerer':'apple_tensor.cc.o)' in text,
        'original_native_MLX_archive_selector':'scaled_dot_product_attention.cpp.o)' in text}
    assert maps[name]['fresh_lowerer'] and not maps[name]['old_archive_lowerer']
(OUT/'link-map-check.json').write_text(json.dumps(maps,indent=2)+'\n',encoding='utf-8')
fresh_sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.suffix in ['.cc','.diff']}
(OUT/'final-source-sha256.json').write_text(json.dumps(fresh_sources,indent=2)+'\n',encoding='utf-8')
check=subprocess.run(['git','diff','--exit-code','--','src/compute_route_apple/apple_tensor.cc','tests/compute_route_apple/attention_test.cc'],cwd=ROOT,capture_output=True)
(OUT/'canonical-unchanged.json').write_text(json.dumps({'command':['git','diff','--exit-code','--','src/compute_route_apple/apple_tensor.cc','tests/compute_route_apple/attention_test.cc'],'exit':check.returncode,'unchanged':check.returncode==0},indent=2)+'\n',encoding='utf-8')
assert check.returncode==0
q,k,h,d=1025,2049,64,512
logical={'full_q_scale':q*h*d*4,'all_qk_scores':q*k*h*4,'all_sink_concat_scores':q*(k+1)*h*4,'full_output':q*h*d*4}
base_sum=sum(logical.values())
candidate_sum=base_sum+logical['full_output']
summary={
 'status':'negative_space_candidate_not_applied; Apple Sink full-score space issue remains unresolved',
 'machine':{'host':'kiro@172.22.10.198','model':'Mac16,12','chip':'Apple M4','ram_bytes':17179869184,'available_disk_before':'41GiB','compiler':'Apple clang21.0.0 arm64'},
 'candidate':'Scratch-only private Q16 wrapper; Q>=1024 plus (Q-16)*KV>2*Q*Dv. Slice Q and global additive mask rows, share complete KV/sinks, depends both Q/mask sources on preceding output, invoke same native fast fallback each block, concatenate BHSD once then original BSHD transpose. No hand-written normalization/new shader/native SDK patch/dtype/TF32/env/CB/sync change.',
 'source_scope':'Current canonical lowerer frozen as baseline; original SDK native is used on both sides. D512 always rejects both vector/full fused admission including Q1 tail, so current D192/D256 selector patches absent from the historical SDK are irrelevant to this tested Sink domain. All library hashes and actual link maps retained.',
 'tests':{
  'initial_failure':{'baseline':'1/2 PASS, long case FAIL at invalid slot reuse after first two full numerical checks passed','candidate':'same1/2 result and same failure stage','cause':'Harness retained work_a OwnedResult and result_a ResultLease, then called first.submit().value(). result_slot.begin() must return FailedPrecondition("result is still retained"): src/compute/result.cc:90-94; thrown bad_expected_access was not a numerical failure.','source':'sink_tests.initial-failure.cc matches original tests-compile-command source body before replacement; original failed logs/JSON/maps/runtime identities retained.'},
  'authorized_harness_fix':'Keep output_a native array copy, release that slot ResultLease/OwnedResult before bind/submit again. Independent second-slot old result stays live. Replace unchecked rebind submit.value() with explicit Result assertion.',
  'final':{'baseline_passed':2,'candidate_passed':2,'same_original_two_tests':'No shape/input/scale/FP64 budget change. Only the fixed test TU and two test executables rebuilt; no lowerer rebuild or new space run.','raw':'measured/rebindfix-{baseline,candidate}-tests.{stdout.txt,json}','max_F32_error':4.33824060126764e-7,'max_budget_fraction':0.18268049532022862},
  'coverage':['Selected H64/Q1025/KV2049 nonzero two-channel QK and exact dyadic V, per-head sink logits, finite positive/negative additive masks and -Inf entries, full global bottom-right causal mask already supplied by caller','All-masked rows15/16/last and65 Q blocks with one-row tail; each33,587,200-element output checked by independent stable FP64 separable-V formula, preserving6e-6*abs(expected)+2e-6','Two independent invocations/sets of all five ports, actual rebind of first invocation to second set, copied old output hash unchanged after slot reuse and producer handles released before completion wait','H128/Q17/KV31 short-query native fallback control'],
  'oracle_limits':'Two nonzero Q/K channels and exactly dyadic separable V, not arbitrary dense random dot-product oracle; no whole NaN/Inf matrix expansion.'},
 'fixed_space':{'executions':'Exactly one independent baseline and one independent candidate process; never repeated after the negative result or harness correction.','input':'Pre-fixed Q/K/mask/sinks0, V alternates+1.25/-1.25 by KV row. Every output independently checked against1.25/2050; original F32 rel6e-6+abs2e-6.','baseline':baseline,'candidate':candidate,'extra_peak_increase_bytes':candidate['peak_minus_active_before']-baseline['peak_minus_active_before'],'extra_peak_increase_fraction':candidate['peak_minus_active_before']/baseline['peak_minus_active_before']-1,'metric':'Actual MLX allocator peak-minus-active-before after public prepare/create_invocation/bind, clear_cache/reset_peak, then submit/wait/synchronize. Includes output and native pending buffers, excludes cold prepare/JIT; not whole-device VRAM or RSS.'},
 'liveness_analysis':{
  'actual_observation':'Both active-before values151175428B and retained output134348800B match. Candidate extra peak adds136724480B, close to an additional full block-output frontier134348800B, plus2375680B. The Q16 logical score width reduction did not lower actual peak.',
  'source':'Locked MLX backend/metal/eval.cpp:47-67 captures primitive input/sibling data_shared_ptr in command-buffer completion handlers; device.cpp:471-475 also retains temporaries/outputs to completion,511-513/605-626 preserve original operation/byte commit windows. depends orders work but does not retire these native references. Blocks vector plus final concat retain a linear output frontier.',
  'shape_derived_payload_sizes_not_allocation_trace':logical,
  'illustrative_sum':{'baseline_q_scale_scores_sink_scores_output':base_sum,'candidate_same_plus_block_output_frontier':candidate_sum,'baseline_measured_minus_sum':baseline['peak_minus_active_before']-base_sum,'candidate_measured_minus_sum':candidate['peak_minus_active_before']-candidate_sum},
  'limit':'These shape sums are consistent with broad intermediate residency plus an extra output frontier, but no per-buffer allocation/donation or command-buffer trace was collected. They cannot uniquely attribute the peak or prove all65 score blocks simultaneously resided. Do not infer throughput.'},
 'next_engineering_direction':'A real lifetime change must stop submitting one whole lazy graph with all block intermediates at once. Use a native-completion-driven bounded number of block evaluations: precompile full/tail block math, submit from the existing owner stream, retire prior temporary roots only on actual GPU completion, then enqueue the next block on that owner thread. Keep one user Completion and the O(output) result frontier. This needs a native retirement/event adapter and invocation-state/lifetime design, not another depends or per-block host synchronize/wait. An explicit reusable-workspace native plan is an alternative if output/scratch binding exists. Same full KV and F32 arithmetic/work must remain; no new shader/precision reduction is implied. Only a future design direction, not implemented or proven feasible with current public MLX hooks.',
 'build_scope':'Initial4 fresh host TUs and4links; authorized rebind correction1 test TU+2test links. Original SDK/foundation/gtest reused; no configure/native/metallib rebuild or dependency copy/download. Compile/link all passed. No latency/throughput/shape/tile/CB/environment follow-up.',
 'link_maps':maps,
 'final_sources':fresh_sources,
 'canonical_unchanged':'canonical-unchanged.json',
 'cleanup':'cleanup-candidates.json contains actual final eight object/executable files with exact size/SHA; old overwritten binary generations are not extra cleanup targets.'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p!=archive and p.name!='archive-record.json' and p.suffix not in ('.gz','.zip'):
            z.write(p,p.relative_to(OUT))
record={'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'cleanup_files':len(cleanup['remote_files']),'cleanup_bytes':sum(x['bytes'] for x in cleanup['remote_files'])}
(OUT/'archive-record.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
