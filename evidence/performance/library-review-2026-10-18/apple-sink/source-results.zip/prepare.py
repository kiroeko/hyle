from pathlib import Path
import difflib,hashlib,json
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
source=(ROOT/'src/compute_route_apple/apple_tensor.cc').read_text(encoding='utf-8')
(OUT/'apple_tensor.baseline.cc').write_bytes(source.encode())
marker='mx::array lower_attention(const ScaledDotProductAttention &attention,'
assert source.count(marker)==1
helper='''mx::array sink_attention_math_blocks(const model_ops::SinkAttention &attention,
                                     const mx::array &query,
                                     const mx::array &key,
                                     const mx::array &value,
                                     const mx::array &mask,
                                     const mx::array &sinks,
                                     mx::Stream stream) {
  const int rows = query.shape(2), keys = key.shape(2);
  std::vector<mx::array> blocks;
  blocks.reserve(static_cast<std::size_t>((rows - 1) / kAttentionQueryBlock + 1));
  for (int begin = 0; begin < rows;) {
    const int end = begin + std::min(kAttentionQueryBlock, rows - begin);
    auto start = mx::Shape(4, 0), stop = query.shape();
    start[2] = begin;
    stop[2] = end;
    std::vector<mx::array> sources{
        mx::slice(query, start, stop, stream),
        mx::slice(mask, {begin, 0}, {end, keys}, stream)};
    if (!blocks.empty())
      sources = mx::depends(sources, {blocks.back()});
    // The locked D512 Sink schema always uses the native F32 fallback,
    // including a short tail. Reuse its unscaled sink column and precise
    // softmax rather than introducing a second normalization implementation.
    blocks.push_back(mx::fast::scaled_dot_product_attention(
        sources[0], key, value, attention.scale, "array", sources[1], sinks,
        false, stream));
    begin = end;
  }
  return mx::concatenate(std::move(blocks), 2, stream);
}

'''
source=source.replace(marker,helper+marker)
old='''      auto result = mx::fast::scaled_dot_product_attention(query, key, value,
          sink_attention->scale, "array", inputs[3], inputs[4], false, stream);'''
assert source.count(old)==1
new='''      const auto rows = std::int64_t{query.shape(2)};
      const auto keys = std::int64_t{key.shape(2)};
      const auto value_depth = std::int64_t{value.shape(3)};
      // Preserve short/no-benefit shapes: concatenated outputs and pending
      // Metal command buffers can otherwise outweigh the smaller score blocks.
      const bool chunk = rows >= 1024 &&
          (rows - kAttentionQueryBlock) * keys > 2 * rows * value_depth;
      auto result = chunk
          ? sink_attention_math_blocks(*sink_attention, query, key, value,
                                        inputs[3], inputs[4], stream)
          : mx::fast::scaled_dot_product_attention(query, key, value,
                sink_attention->scale, "array", inputs[3], inputs[4], false, stream);'''
source=source.replace(old,new)
(OUT/'apple_tensor.candidate.cc').write_bytes(source.encode())
(OUT/'apple_tensor.diff').write_text(''.join(difflib.unified_diff((OUT/'apple_tensor.baseline.cc').read_text(encoding='utf-8').splitlines(True),source.splitlines(True),fromfile='baseline',tofile='candidate')),encoding='utf-8')
(OUT/'frozen-source-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.suffix in ['.cc','.diff']},indent=2)+'\n',encoding='utf-8')
print('scratch lowerer prepared; canonical unchanged')
