include("${CMAKE_CURRENT_LIST_DIR}/../../../cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_cpu_runtime_patches)
message(STATUS "CPU patch tree and license hashes match")
