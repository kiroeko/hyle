#include "cpu_program.h"
#include <iostream>
#include <string_view>
int main(int argc,char**argv) {
  const bool stale=argc>1&&std::string_view(argv[1])=="stale";
  auto result=hyle::compute::ggml_runtime::select_cpu_program();
  if(stale) {
    if(result||!result.error().IsFailedPrecondition())return 1;
    std::cout<<"stale v1 module correctly rejected: "<<result.error().message()<<"\n";
    return 0;
  }
  if(!result) {std::cerr<<result.error().message()<<"\n";return 2;}
  if((*result)->abi!=2||!(*result)->hadamard)return 3;
  std::cout<<"imported select_cpu_program returned ABI2 callback across runtime DLL\n";
  return 0;
}
