from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCT = [
    'cmake/HyleDependencyLock.json',
    'scripts/check-shared-export-hygiene.py',
    'src/compute_ggml_runtime/cpu_program.cc',
    'src/compute_ggml_runtime/cpu_program.h',
    'src/compute_ggml_runtime/cpu_program_abi.h',
    'src/compute_ggml_runtime/cpu_program_export.cc',
    'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
    'src/compute_provider_ggml/ggml_cpu_provider.cc',
    'tests/compute_ggml_runtime/execution_test.cc',
    'tests/compute_provider_ggml/CMakeLists.txt',
    'tests/compute_provider_ggml/hadamard_test.cc',
    'tests/tooling/shared_export_hygiene_test.py',
    'third_party/ggml_cpu_runtime/NOTICE.md',
    'third_party/ggml_cpu_runtime/patches.json',
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def load(name):
    return json.loads((OUT / name).read_text(encoding='utf-8'))

commands = load('commands.json')
source_identity = {p: {'bytes': (ROOT / p).stat().st_size, 'sha256': sha(ROOT / p)} for p in PRODUCT}
write('source-identity.json', source_identity)
diff = subprocess.run(['git', 'diff', '--binary', '--', *PRODUCT], cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
(OUT / 'product.patch').write_bytes(diff)

pin_results = []
for pin in ['ffa4', 'mixed']:
    for mode in ['baseline', 'selected']:
        raw = (OUT / f'{pin}-tests-{mode}.log').read_text(encoding='utf-8')
        identity = json.loads(raw.splitlines()[0])
        map_text = (OUT / pin / f'tests-{mode}.map').read_text(errors='replace')
        pin_results.append({
            'pin': pin, 'selection': mode, 'tests_passed': 4,
            'raw_log': f'{pin}-tests-{mode}.log',
            'actual_identity': identity,
            'fresh_baseline_callback_in_link_map': any('ggml_hyle_cpu_hadamard' in line and 'native-baseline.obj' in line for line in map_text.splitlines()),
            'old_native_ops_archive_member_present': 'ggml-cpu:ops.cpp.obj' in map_text,
        })

space = {arm: load(f'ffa4-space-{arm}.log') for arm in ['baseline', 'candidate']}
cleanup = []
for directory in ['ffa4', 'mixed', 'shared']:
    for path in sorted((OUT / directory).rglob('*')):
        if path.is_file() and path.suffix.lower() in {'.obj', '.dll', '.exe', '.lib', '.exp', '.pdb', '.ilk'}:
            cleanup.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)})
write('cleanup-candidates.json', {
    'rule': 'Only newly created outputs inside this CPU-Hadamard scratch directory. Do not delete SDK/cache originals. Root must place exact chosen deletion paths in repository test.ps1 first.',
    'retain_for_next_cpu_sink_work_until_released': [str(OUT / 'ffa4'), str(OUT / 'mixed')],
    'total_bytes': sum(row['bytes'] for row in cleanup), 'files': cleanup,
    'additional_small_rebuildable_directory': str(OUT / '__pycache__'),
})

summary = {
    'status': 'implemented_and_focused_validation_passed',
    'canonical_source_root': str(ROOT),
    'implementation': {
        'operation': 'CPU Hadamard, public C++ domain and scaling unchanged',
        'native_bridge': 'Real unary GGML_OP_CUSTOM callback reuses the existing native FWHT arithmetic body; no dummy matrix, null W-squared storage, numerical kernel rewrite, or log-W operation graph.',
        'private_abi': 2, 'entry_symbol': 'hyle_ggml_cpu_program_v2',
        'pins': ['ffa4e8b80930029a35991f94e7c8a93cd67730ab', '456172ec733a (existing mixed CPU pin/cache)'],
        'reference_semantics': 'The unary CUSTOM always means FWHT under either use_ref value. The original hinted MUL_MAT still owns a real matrix and preserves its genuine matrix reference fallback.',
        'ownership': 'The callback comes from the selected baseline/AVX2 CpuProgram. The module and compute callback share the actual selected owner; no new per-invocation globals or scratch state.',
        'metadata_capacity': 'Existing capacity retained: matrix-plus-MUL_MAT becomes one unary CUSTOM, with the same possible dtype casts.',
    },
    'validation': {
        'toolchain': 'Windows x64, MSVC 14.50.35717 / compiler 19.50.35728, Release /MD; fresh Hyle/test objects /W4 /WX',
        'public_and_native_tests': pin_results,
        'total_gtests_passed': 16,
        'coverage': 'F32/F16/BF16, widths 1/4/128/4096, 6 rows, forward/inverse, independent invocations and rebind; independent FP64 Sylvester oracle. F32 native unary and legacy real-matrix reference each tested with use_ref false/true.',
        'shared_boundary': {
            'good': 'Actual dllimport select_cpu_program crosses a fresh runtime selector DLL and returns ABI2 callback; shared-good-client.log exit 0.',
            'stale': 'Existing old v1 module rejected as FailedPrecondition ggml CPU program ABI; shared-stale-client.log exit 0.',
            'scope': 'Private selector DLL boundary smoke, not a full installed shared SDK rebuild.',
        },
        'export_hygiene_unit': {'command': 'python tests/tooling/shared_export_hygiene_test.py', 'exit': 0, 'raw_log': 'export-hygiene-unit.log', 'note': 'Negative synthetic cases intentionally print failed diagnostics; the unit script succeeds. Not a full product export scan.'},
        'resource_lock': {'command': 'cmake -P .scratch/perf-review-2026-10-18/cpu-hadamard/check-lock.cmake', 'result': 'PASS', 'reported_and_run_by': 'root, independent final tree/license check; not rerun by this subagent'},
    },
    'cold_prepare_allocation': {
        'shape': 'F32 W4096, rows2, separate baseline/candidate processes',
        'measurement_boundary': 'Selected CPU program DLL loaded/initialized before counters. Only public prepare is measured; input/output allocation and numerical execution occur after capture.',
        'metric': 'Successful unaligned global new/new[] requested bytes, plus separate coarse Windows process PrivateUsage/WorkingSet snapshots. Not live allocation, device memory, complete allocator traffic, or peak resident memory.',
        'baseline': space['baseline'], 'candidate': space['candidate'],
        'removed_payload_bytes': 67108864,
        'removed_largest_new_request_note': 'The real W-squared float matrix requests payload 64 MiB plus 39 B of MSVC STL aligned-allocation overhead. Total requested-byte reduction also includes the removed outer vector storage.',
        'initial_instrumentation_correction': 'Initial exact-64MiB counter was zero because MSVC requested 64MiB+39B; first-space logs preserved. Final counter uses requests >=64MiB. Both initial and final numerical checks passed.',
    },
    'build_scope': {
        'foundation_cache': str(ROOT / '.scratch/build-compute-v2-dev'),
        'fresh_native_per_pin': 'Only ops.cpp baseline + AVX2, and private entry host TU; old original ops.cpp.obj excluded from linking.',
        'reused_non_ops_avx2_objects': {'ffa4': 15, 'mixed': 14},
        'reused_libraries': 'Existing same-pin ggml base/CPU libraries and current Hyle foundation static libraries; original files unchanged. Exact paths and commands retained in commands.json/run.py.',
        'not_performed': ['No configure or whole native/SDK build', 'No dependency download or SDK copy', 'No throughput timing', 'No full shared installed SDK validation', 'No full Graph suite', 'No non-Windows runtime validation'],
    },
    'history_and_warnings': ['Native FFA4 command retains the pre-existing exception-flag override warning; compile succeeded.', 'Initial source-feasibility.json describes the previous missing-unary-API state and is superseded by this implementation. It is not a current pending conclusion.'],
    'commands_recorded': len(commands),
    'command_exit_codes': sorted({row['exit'] for row in commands}),
    'resource_identity': load('lock-update.json'),
    'source_identity_file': 'source-identity.json',
    'cleanup_candidates_file': 'cleanup-candidates.json',
}
write('summary.json', summary)

archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in PRODUCT:
        z.write(ROOT / p, 'product/' + p)
    for path in sorted((OUT / 'baseline').rglob('*')):
        if path.is_file():
            z.write(path, path.relative_to(OUT).as_posix())
    top_names = {'run.py', 'finalize_evidence.py', 'shared_smoke.py', 'shared_client.cc', 'test_main.cc', 'space_probe.cc', 'mixed-cpu-patches.json', 'commands.json', 'lock-update.json', 'check-lock.cmake', 'summary.json', 'source-identity.json', 'cleanup-candidates.json', 'product.patch', 'source-feasibility.json'}
    for path in sorted(OUT.iterdir()):
        if path.is_file() and (path.name in top_names or path.suffix == '.log'):
            z.write(path, path.name)
    for name in ['ffa4', 'mixed', 'shared']:
        for path in sorted((OUT / name).rglob('*')):
            if path.is_file() and path.suffix.lower() in {'.cpp', '.cc', '.def', '.map'}:
                z.write(path, path.relative_to(OUT).as_posix())
write('archive-record.json', {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'product_patch_sha256': sha(OUT / 'product.patch'), 'summary_sha256': sha(OUT / 'summary.json'), 'source_identity_sha256': sha(OUT / 'source-identity.json'), 'binary_outputs_excluded_from_zip': True})
print(json.dumps(load('archive-record.json'), indent=2))
