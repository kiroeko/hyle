from pathlib import Path
import importlib.util,json,re,subprocess
import run as b
cfg=b.prepare('ffa4');out=b.OUT/'shared';out.mkdir(exist_ok=True)
lib=b.CL.with_name('lib.exe');dump=b.CL.with_name('dumpbin.exe')
imports=[]
for name in ['hyle_error','hyle_platform']:
 dll=b.BASE/'bin'/(name+'.dll');raw=b.run('shared-'+name+'-exports',[dump,'/nologo','/exports',dll]).decode(errors='replace')
 symbols=re.findall(r'^\s*\d+\s+[0-9A-F]+\s+[0-9A-F]+\s+(\S+)',raw,re.M)
 assert symbols,name
 deffile=out/(name+'.def');deffile.write_text('LIBRARY '+name+'.dll\nEXPORTS\n'+'\n'.join(symbols)+'\n')
 dest=out/(name+'.lib');b.run('shared-'+name+'-import-lib',[lib,'/nologo','/DEF:'+str(deffile),'/MACHINE:X64','/OUT:'+str(dest)]);imports.append(dest)
flags=[v for v in b.hyle_flags(cfg) if v!='/DHYLE_STATIC']
b.run('shared-client-compile',[b.CL,*flags,b.OUT/'shared_client.cc','/Fo'+str(out/'client.obj')])
for mode,module in [('good',cfg['module']),('stale',b.BASE/'bin/hyle_ggml_cpu_avx2_ffa4e8b8_e74fc9bb8964d04f.dll')]:
 obj=out/(mode+'.obj');dll=out/('selector-'+mode+'.dll');imp=out/('selector-'+mode+'.lib')
 b.run('shared-'+mode+'-compile',[b.CL,*flags,'/DHYLE_COMPUTE_GGML_RUNTIME_BUILD=1','/DHYLE_GGML_CPU_AVX2_PROGRAM=1','/DHYLE_GGML_CPU_PROGRAM_LIBRARY="'+str(module).replace('\\','/')+'"',b.ROOT/'src/compute_ggml_runtime/cpu_program.cc','/Fo'+str(obj)])
 b.run('shared-'+mode+'-link',[b.LINK,'/nologo','/DLL','/MACHINE:X64','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(dll),'/IMPLIB:'+str(imp),'/MAP:'+str(out/(mode+'.map')),obj,cfg['folder']/'native-baseline.obj',cfg['cpu'],cfg['base'],*imports,*b.SYSTEM])
 b.run('shared-'+mode+'-client-link',[b.LINK,'/nologo','/SUBSYSTEM:CONSOLE','/MACHINE:X64','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(out/('client-'+mode+'.exe')),out/'client.obj',imp,*imports,*b.SYSTEM])
 b.run('shared-'+mode+'-client',[out/('client-'+mode+'.exe'),mode])
