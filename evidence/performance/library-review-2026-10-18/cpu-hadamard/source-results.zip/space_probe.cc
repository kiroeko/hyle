#include "cpu_program.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include <windows.h>
#include <psapi.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <bit>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <new>
#include <vector>
namespace {
std::atomic<bool> count_new{false};
std::atomic<std::size_t> calls{0},bytes{0},maximum{0},matrix_requests{0};
constexpr int width=4096,rows=2;
}
void* operator new(std::size_t n) {
  void*p=std::malloc(n?n:1);if(!p)throw std::bad_alloc();
  if(count_new.load(std::memory_order_relaxed)) {
    calls.fetch_add(1,std::memory_order_relaxed);bytes.fetch_add(n,std::memory_order_relaxed);
    auto old=maximum.load(std::memory_order_relaxed);
    while(old<n&&!maximum.compare_exchange_weak(old,n,std::memory_order_relaxed)){}
    if(n>=std::size_t(width)*width*sizeof(float))matrix_requests.fetch_add(1,std::memory_order_relaxed);
  }
  return p;
}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void*p)noexcept{std::free(p);}
void operator delete[](void*p)noexcept{std::free(p);}
void operator delete(void*p,std::size_t)noexcept{std::free(p);}
void operator delete[](void*p,std::size_t)noexcept{std::free(p);}
PROCESS_MEMORY_COUNTERS_EX memory() {
  PROCESS_MEMORY_COUNTERS_EX m{};m.cb=DWORD(sizeof(m));
  if(!GetProcessMemoryInfo(GetCurrentProcess(),reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&m),DWORD(sizeof(m))))throw std::bad_alloc();
  return m;
}
int main() {
  using namespace hyle::compute;
  try {
    auto native=hyle::compute::ggml_runtime::select_cpu_program().value();native->initialize();
    auto context=Context::create(cpu::device(),ggml_cpu::provider({.native_threads=1})).value();
    auto queue=context.create_queue().value();
    const auto desc=TensorDesc::dense(DataType::kFloat32,std::array<std::int64_t,2>{rows,width}).value();
    const auto before=memory();count_new.store(true,std::memory_order_relaxed);
    auto made=prepare(context,Operation(Hadamard{}),std::span(&desc,1),std::span(&desc,1),hyle::mem::system_resource());
    count_new.store(false,std::memory_order_relaxed);const auto after=memory();
    if(!made){std::cerr<<made.error().message();return 2;}
    if(made->provider().id!=ggml_cpu::kProviderId)return 3;
    std::vector<float> input(width*rows),observed(width*rows);
    for(int r=0;r<rows;++r)input[r*width+3]=float(r+1);
    auto source=hyle::mem::Buffer::create(hyle::mem::system_resource(),input.size()*sizeof(float),64).value();
    auto output=hyle::mem::Buffer::create(hyle::mem::system_resource(),input.size()*sizeof(float),64).value();
    if(!source.view().write(std::as_bytes(std::span(input))).ok())return 7;
    const auto view=ConstTensorView::create(desc,source.view()).value();
    const auto destination=TensorView::create(desc,output.view()).value();
    auto invocation=made->create_invocation().value();
    auto done=invocation.submit(queue,std::span(&view,1),std::span(&destination,1)).value();
    auto status=done.wait();if(!status.ok()){std::cerr<<status.message();return 4;}
    if(!output.view().read(std::as_writable_bytes(std::span(observed))).ok())return 8;
    double max_error=0;
    for(int r=0;r<rows;++r)for(int c=0;c<width;++c){
      double expected=(std::popcount(unsigned(3&c))%2?-1:1)*double(r+1)/64;
      max_error=std::max(max_error,std::abs(observed[r*width+c]-expected));
    }
    std::cout<<"{\"width\":4096,\"rows\":2,\"dtype\":\"F32\",\"native_abi\":"<<native->abi
      <<",\"cold_successful_unaligned_new_calls\":"<<calls.load()<<",\"cold_new_requested_bytes\":"<<bytes.load()
      <<",\"cold_largest_new_request\":"<<maximum.load()<<",\"cold_requests_at_least_64MiB\":"<<matrix_requests.load()
      <<",\"private_before\":"<<before.PrivateUsage<<",\"private_after\":"<<after.PrivateUsage
      <<",\"working_set_before\":"<<before.WorkingSetSize<<",\"working_set_after\":"<<after.WorkingSetSize
      <<",\"caller_input_bytes\":32768,\"caller_output_bytes\":32768,\"checked_elements\":8192,\"max_abs_error\":"<<max_error<<"}\n";
    return max_error==0?0:5;
  }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 6;}
}
