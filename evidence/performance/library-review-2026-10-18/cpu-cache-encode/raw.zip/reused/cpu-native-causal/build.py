from pathlib import Path
import argparse, hashlib, importlib.util, json, os, subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
HAD = OUT.parent / 'cpu-hadamard'
spec = importlib.util.spec_from_file_location('had', HAD / 'run.py')
had = importlib.util.module_from_spec(spec)
spec.loader.exec_module(had)
RECORDS = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []

def run(label, argv, expected=0):
    p = subprocess.run(list(map(str, argv)), cwd=ROOT, env=had.ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    (OUT / (label + '.log')).write_bytes(p.stdout)
    RECORDS.append(dict(label=label, argv=list(map(str, argv)), exit=p.returncode, expected=expected))
    (OUT / 'commands.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    print(label, p.returncode, p.stdout.decode(errors='replace')[-1800:], flush=True)
    if p.returncode != expected:
        raise SystemExit(p.returncode or 2)

def config(pin):
    cfg = dict(had.PINS[pin])
    cfg['folder'] = OUT / pin
    cfg['module'] = cfg['folder'] / ('hyle_ggml_cpu_avx2_' + pin + '_causal_overlay.dll')
    return cfg

def cpp(cfg, source, name, extra=(), native=False):
    flags = had.native_flags(cfg) if native else had.hyle_flags(cfg)
    obj = cfg['folder'] / (name + '.obj')
    run(cfg['folder'].name + '-' + name, [had.CL, *flags, *extra, '/c', source, '/Fo' + str(obj)])
    return obj

def c_obj(cfg, source, name):
    import shlex
    db = json.loads(cfg['compdb'].read_text())
    row = next(x for x in db if Path(x['file']).name == 'ggml-alloc.c')
    flags = [x.strip('"') for x in shlex.split(row['command'], posix=False)][1:]
    flags = [x for x in flags if x.lower() not in ['/c', '-c', '/fs'] and not x.lower().startswith(('/fo', '/fd')) and x.replace('\\', '/') != row['file'].replace('\\', '/')]
    obj = cfg['folder'] / (name + '.obj')
    run(cfg['folder'].name + '-' + name, [had.CL, *flags, '/utf-8', '/c', source, '/Fo' + str(obj)])
    return obj

def native(pin):
    cfg = config(pin)
    f = cfg['folder']
    cpp(cfg, f / 'ops.cpp', 'native-baseline', native=True)
    cpp(cfg, f / 'ops.cpp', 'native-avx2', ['/DGGML_AVX', '/DGGML_AVX2', '/DGGML_FMA', '/DGGML_F16C', '/DGGML_BMI2', '/D__BMI2__', '/arch:AVX2'], native=True)
    cpp(cfg, ROOT / 'src/compute_ggml_runtime/cpu_program_export.cc', 'program-export', ['/I' + str(ROOT / 'include'), '/I' + str(ROOT / 'src/compute_ggml_runtime')], native=True)
    cached = [p for p in cfg['optimized'].rglob('*.obj') if p.name != 'ops.cpp.obj']
    assert cached
    run(pin + '-module-link', [had.LINK, '/nologo', '/DLL', '/MACHINE:X64', '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(cfg['module']), '/IMPLIB:' + str(f / 'module.lib'), '/MAP:' + str(f / 'module.map'), f / 'native-avx2.obj', f / 'program-export.obj', *cached, cfg['base'], *had.SYSTEM])

def tests(pin):
    cfg = config(pin)
    f = cfg['folder']
    cpp(cfg, ROOT / 'src/compute_provider_ggml/ggml_cpu_provider.cc', 'provider')
    cpp(cfg, ROOT / 'tests/compute_provider_ggml/attention_math_test.cc', 'tests')
    cpp(cfg, HAD / 'test_main.cc', 'test-main')
    cpp(cfg, ROOT / 'src/compute_ggml_runtime/cpu_program.cc', 'selector', ['/DHYLE_GGML_CPU_AVX2_PROGRAM=1', '/DHYLE_GGML_CPU_PROGRAM_LIBRARY="' + str(cfg['module']).replace('\\', '/') + '"'])
    allocator = OUT.parent / 'cpu-math-attention' / pin / 'ggml-alloc.fallible.c'
    c_obj(cfg, allocator, 'allocator')
    c_obj(cfg, ROOT / 'tests/compute_ggml_runtime/gallocr_faults.c', 'faults')
    run(pin + '-test-link', [had.LINK, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT', '/OUT:' + str(f / 'tests.exe'), '/MAP:' + str(f / 'tests.map'), *[f / (x + '.obj') for x in ['provider', 'tests', 'test-main', 'selector', 'allocator', 'faults', 'native-baseline']], *had.common_libs(cfg), had.BASE / 'lib/gtest.lib', *had.SYSTEM])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['native', 'tests', 'run'])
    parser.add_argument('--pin', choices=['ffa4', 'mixed'], required=True)
    args = parser.parse_args()
    if args.action == 'native': native(args.pin)
    elif args.action == 'tests': tests(args.pin)
    else:
        run(args.pin + '-causal-tests', [config(args.pin)['folder'] / 'tests.exe', '--gtest_filter=GgmlCpuMathAttention.ImplicitCausal*:GgmlCpuMathAttention.DecodeOmitsZeroMaskAndRetainsNativeSplit'])
