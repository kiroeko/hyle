#include "cpu_program.h"
#include <gtest/gtest.h>
#include <windows.h>
#include <array>
#include <filesystem>
#include <iostream>
#include <cstdint>
std::string owner(std::uintptr_t address) {
  HMODULE module=nullptr;
  if(!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|
      GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
      reinterpret_cast<LPCSTR>(address),&module)) return "owner-error";
  std::array<char,4096> name{};
  if(!GetModuleFileNameA(module,name.data(),DWORD(name.size()))) return "path-error";
  return std::filesystem::path(name.data()).generic_string();
}
int main(int argc,char**argv) {
  testing::InitGoogleTest(&argc,argv);
  auto selected=hyle::compute::ggml_runtime::select_cpu_program();
  if(!selected) { std::cerr<<selected.error().message()<<"\n";return 2; }
  const auto*p=*selected;
  std::cout<<"{\"abi\":"<<p->abi<<",\"descriptor_bytes\":"<<p->descriptor_bytes
      <<",\"tensor_bytes\":"<<p->tensor_bytes<<",\"plan_bytes\":"<<p->plan_bytes
      <<",\"callback_owner\":\""<<owner(reinterpret_cast<std::uintptr_t>(p->hadamard))
      <<"\",\"compute_owner\":\""<<owner(reinterpret_cast<std::uintptr_t>(p->compute))
      <<"\"}\n";
  return RUN_ALL_TESTS();
}
