from pathlib import Path
import argparse,importlib.util,json,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('causal',OUT.parent/'cpu-native-causal/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.OUT=OUT;b.RECORDS=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
FILES=['src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/attention_math_test.cc','tests/compute_provider_ggml/native_paged_test.cc','src/compute_provider_ggml/native_batch.cc','src/graph_route_cpu/ggml_region.cc']
def freeze():
 for path in FILES:
  p=OUT/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/path).read_bytes())
 p=OUT/'baseline-provider.cc';p.write_bytes(subprocess.check_output(['git','show','8eb28b92e:'+FILES[0]],cwd=ROOT))
 (OUT/'product.diff').write_bytes(subprocess.check_output(['git','diff','--',*FILES[:2]],cwd=ROOT))
def cfg(pin):
 c=dict(b.had.PINS[pin]);c['folder']=OUT/pin;c['folder'].mkdir(exist_ok=True)
 old=OUT.parent/'cpu-native-causal'/pin;c['module']=old/f'hyle_ggml_cpu_avx2_{pin}_causal_overlay.dll';c['native_baseline']=old/'native-baseline.obj';return c
def link(c,name,objects,graph=False):
 f=c['folder'];exe=f/(name+'.exe')
 b.run(f.name+'-'+name+'-link',[b.had.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(f/(name+'.map')),*[f/(x+'.obj') for x in objects],c['native_baseline'],*([b.had.BASE/'bin/hyle_graph.lib'] if graph else []),*b.had.common_libs(c),b.had.BASE/'lib/gtest.lib',*b.had.SYSTEM]);return exe
def build(pin):
 c=cfg(pin);s=OUT/'candidate'
 for source,name in [(s/FILES[0],'provider'),(s/FILES[1],'tests'),(s/FILES[2],'encoder-tests'),(s/FILES[3],'native-batch'),(b.HAD/'test_main.cc','main')]:b.cpp(c,source,name,['/I'+str(ROOT/'tests/compute_provider_ggml')])
 b.cpp(c,ROOT/'src/compute_ggml_runtime/cpu_program.cc','selector',['/DHYLE_GGML_CPU_AVX2_PROGRAM=1','/DHYLE_GGML_CPU_PROGRAM_LIBRARY="'+str(c['module']).replace('\\','/')+'"'])
 b.c_obj(c,OUT.parent/'cpu-math-attention'/pin/'ggml-alloc.fallible.c','allocator')
 b.c_obj(c,ROOT/'tests/compute_ggml_runtime/gallocr_faults.c','faults')
 objects=['provider','tests','encoder-tests','native-batch','main','selector','allocator','faults']
 exe=link(c,'tests',objects)
 filt='GgmlCpuStorage.CacheEncodeKeeps*:GgmlCpuCacheEncode.Q8ReferenceBytesTiesZeroAndThreeInputTypes:GgmlCpuCacheEncode.Float8CodesMatchIndependentEnumerationIncludingRoundingAndSaturation:GgmlCpuCacheEncode.InvalidPayloadReturnsOriginalCompletionErrorAfterWorkersRetire:GgmlCpuCacheEncode.IndependentInvocationsAndFreshRecoveryAfterOriginalWorkersRetire'
 if pin=='ffa4':filt+=':GgmlCpuStorage.CacheEncodeChainColdAllocationIsBounded'
 b.run(pin+'-tests',[exe,'--gtest_filter='+filt])
 if pin=='ffa4':
  b.cpp(c,OUT/'baseline-provider.cc','provider-baseline')
  exe=link(c,'baseline-cold',['provider-baseline',*objects[1:]])
  b.run(pin+'-baseline-cold',[exe,'--gtest_filter=GgmlCpuStorage.CacheEncodeChainColdAllocationIsBounded'],expected=1)
def graph():
 c=cfg('ffa4')
 b.cpp(c,OUT/'candidate'/FILES[4],'region',['/I'+str(ROOT/'src/graph_route_cpu')])
 b.cpp(c,OUT/'graph_probe.cc','graph',['/I'+str(ROOT/'src/graph_route_cpu')])
 exe=link(c,'graph',['provider','native-batch','region','graph','selector','allocator','faults'],True)
 b.run('ffa4-graph',[exe])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','build','graph']);p.add_argument('--pin',choices=['ffa4','mixed'],default='ffa4');a=p.parse_args()
 if a.action=='freeze':freeze()
 elif a.action=='build':build(a.pin)
 else:graph()
