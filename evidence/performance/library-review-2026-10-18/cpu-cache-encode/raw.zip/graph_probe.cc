#include "ggml_region.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/executable.h"
#include "hyle/simd/dtype.h"
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <vector>
namespace c=hyle::compute;namespace g=hyle::graph;
void check(bool value,const char*message){if(!value)throw std::runtime_error(message);}
int main(){try{
 for(auto storage:{c::CacheStorage::q8_0().value(),c::CacheStorage::float8(.5F).value()}){
  auto context=c::Context::create(c::cpu::device(),g::cpu::internal::ggml_regions({.native_threads=2})).value();auto queue=context.create_queue().value();
  auto input=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{4,32}).value();
  const auto encode=c::Operation::custom(c::model_ops::CacheEncode{storage});auto output=c::infer_single_output(encode,std::span(&input,1)).value();
  auto builder=g::GraphBuilder::create().value();auto x=builder.input(input).value();auto y=x,middle=x;
  for(int i=1;i<=8;++i){y=builder.add(c::Unary{c::UnaryKind::kNeg},y).value();if(i==3)middle=y;}
  auto node=builder.add_node(encode,std::span(&y,1)).value();auto encoded=builder.result(node).value();
  check(builder.publish(middle).ok(),"publish middle");check(builder.publish(encoded).ok(),"publish encoded");
  auto logical=std::move(builder).finish().value();auto compiled=g::compile(logical,context).value();
  check(compiled.report.step_count()==1,"one native region");check(compiled.report.step(0)->provider.id==c::ggml_cpu::kProviderId,"actual ggml region");
  std::array<std::array<hyle::mem::Buffer,3>,2> buffers;
  std::array invocations{compiled.executable.create_invocation().value(),compiled.executable.create_invocation().value()};
  for(unsigned lane=0;lane<2;++lane){
   for(unsigned port=0;port<3;++port)buffers[lane][port]=hyle::mem::Buffer::create(hyle::mem::system_resource(),port==2?output.required_bytes().value():512,64).value();
  }
  const auto bind=[&](unsigned lane){auto&inv=invocations[lane];
   check(inv.bind(x,c::ConstTensorView::create(input,buffers[lane][0].view()).value()).ok(),"bind input");
   check(inv.bind(middle,c::TensorView::create(input,buffers[lane][1].view()).value()).ok(),"bind published middle");
   check(inv.bind(encoded,c::TensorView::create(output,buffers[lane][2].view()).value()).ok(),"bind encoded output");
  };
  const auto verify=[&](unsigned lane,float value){
   std::array<float,128> middle_data{};check(buffers[lane][1].view().read(std::as_writable_bytes(std::span(middle_data))).ok(),"read middle");
   for(float actual:middle_data)check(actual==-value,"published odd root survived");
   std::vector<std::uint8_t> actual(output.required_bytes().value()),expected(actual.size());check(buffers[lane][2].view().read(std::as_writable_bytes(std::span(actual))).ok(),"read encoded");
   if(storage==c::CacheStorage::q8_0().value())for(unsigned block=0;block<4;++block){const auto bits=hyle::simd::f32_to_f16(std::abs(value)/127.F).bits;
    expected[block*34]=std::uint8_t(bits);expected[block*34+1]=std::uint8_t(bits>>8);std::fill_n(expected.begin()+block*34+2,32,std::uint8_t(value<0?-127:127));}
   else std::fill(expected.begin(),expected.end(),std::uint8_t((std::abs(value)==.5F?0x38:0x3c)|(value<0?0x80:0)));
   check(actual==expected,"encoded reference bytes");
  };
  for(unsigned lane=0;lane<2;++lane){bind(lane);std::array<float,128> values;values.fill(lane?-.75F:.5F);check(buffers[lane][0].view().write(std::as_bytes(std::span(values))).ok(),"write finite");auto done=invocations[lane].submit(queue).value();check(done.wait().ok(),"finite terminal");verify(lane,values[0]);}
  std::array<float,128> bad;bad.fill(.5F);bad[17]=std::numeric_limits<float>::quiet_NaN();check(buffers[0][0].view().write(std::as_bytes(std::span(bad))).ok(),"write invalid");
  {auto done=invocations[0].submit(queue).value();check(done.wait().IsInvalidArgument(),"preserve accepted numeric error");}
  check(!invocations[0].submit(queue),"accepted failure retires invocation");verify(1,-.75F);
  invocations[0]=compiled.executable.create_invocation().value();bind(0);bad.fill(.5F);check(buffers[0][0].view().write(std::as_bytes(std::span(bad))).ok(),"write recovery");
  {auto done=invocations[0].submit(queue).value();check(done.wait().ok(),"fresh recovery terminal");}verify(0,.5F);check(context.drain().ok(),"drain after actual workers");
  std::cout<<"{\"encoding\":\""<<(storage==c::CacheStorage::q8_0().value()?"Q8_0":"FP8")<<"\",\"region_steps\":1,\"two_slots\":true,\"published_root\":true,\"accepted_invalid_retired\":true,\"fresh_slot_recovery\":true}\n";
 }
 return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
