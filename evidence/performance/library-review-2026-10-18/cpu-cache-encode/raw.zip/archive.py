from pathlib import Path
import hashlib,json,re,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
FILES=['src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/attention_math_test.cc']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in FILES:assert (ROOT/name).read_bytes()==(OUT/'candidate'/name).read_bytes()
baseline=int(re.search(r'cache_encode_chain_cold_allocator_bytes=(\d+)',(OUT/'ffa4-baseline-cold.log').read_text()).group(1))
candidate=int(re.search(r'cache_encode_chain_cold_allocator_bytes=(\d+)',(OUT/'ffa4-tests.log').read_text()).group(1))
native=json.loads((OUT.parent/'cpu-native-causal/cleanup-and-retain.json').read_text())['retain_for_future_cpu_work']
for r in native:assert rec(Path(r['path']))==r
libraries={}
for command in json.loads((OUT/'commands.json').read_text()):
 for arg in command['argv']:
  p=Path(arg)
  if p.is_absolute() and p.suffix=='.lib' and p.exists() and str(p) not in libraries:libraries[str(p)]=rec(p)
write(OUT/'source-identities.json',dict(baseline_commit='8eb28b92e',product=[dict(path=name,sha256=sha(ROOT/name),bytes=(ROOT/name).stat().st_size) for name in FILES],native_unchanged=native,linked_cached_libraries=list(libraries.values())))
summary={
 'scope':'Allow existing GraphStorage liveness allocation for immutable multi-node CacheEncode recipes. Keep single-node and PagedRead rules; no native kernel/resource/lock/API or arithmetic change.',
 'change':'Remove encoders==0 from the multi-node use_liveness condition. Existing callback owners/reserved calls array, all graph nodes/source edges, invalid flag reset/read, published-root flags, mapped ports and worker retirement stay unchanged.',
 'complexity':'The prior one-encoder exclusion gave a chain ofN full-size arithmetic intermediates flat Θ(N·M) private payload. Native gallocr can reuse only dead internal tensors, giving a bounded live payload frontier for this trace; graph metadata remains Θ(N). No throughput claim.',
 'toolchain':'Windows x64 MSVC14.50.35717 /O2 /MD /W4 /WX; direct fresh provider/tests/native_batch/selector and existing same-pin foundation+four retained HYCA native ops objects/DLLs. Native kernels were not rebuilt; no full SDK/HEAD build or staging.',
 'tests':{
  'passed_executions':11,
  'ffa4':'6/6: two new CacheEncode storage tests and four existing public encoder reference/error/recovery tests.',
  'mixed':'5/5: new published-root/two-slot/bytes test and the same four existing public encoder tests. No second cold-allocation sample.',
  'new_binding_test':'64Neg→Q8 or FP8, intermediate31 published. Two invocation slots each execute with two independently retained caller Buffer sets at4-byte subview offsets. Exact source preservation, odd published intermediate, independent block-constant Q8 scale/sign bytes and FP8 .5/1/1.5 codes; earlier output buffer survives rebinding.',
  'existing':['Q8ReferenceBytesTiesZeroAndThreeInputTypes','Float8CodesMatchIndependentEnumerationIncludingRoundingAndSaturation','InvalidPayloadReturnsOriginalCompletionErrorAfterWorkersRetire','IndependentInvocationsAndFreshRecoveryAfterOriginalWorkersRetire'],
  'scratch_graph':'One FFA consumer process, Q8 and FP8. Actual public Graph compile/bind/submit/wait with current ggml_regions factory, one native ggml step, two slots and published odd intermediate. Accepted InvalidArgument terminates and retires failed Invocation; retry rejected, other slot output unchanged, fresh Invocation succeeds. Graph provider factory is explicit; default CPU route factory and mixed Graph variant not exercised.',
 },
 'cold_private_allocation':{
  'shape':'F32[256,1024],64Neg→Q8, only encoded U8 result published. One slot per arm after compilation; no caller input/output payload allocation and no graph execution.',
  'baseline_bytes':baseline,'candidate_bytes':candidate,'bytes_removed':baseline-candidate,
  'method':'StatsAllocator incremental live requested bytes across native create_invocation, includes tracked backing, graph metadata and native workspace. Same FFA module/library closure in both arms; one sample each, no latency collector.',
  'limits':'Not RSS, peak resident, complete C/global-new allocation count or engine end-to-end footprint. Caller tensors are outside the private count; global C malloc metadata remains untracked.',
 },
 'failures_and_limits':[
  'Baseline8eb28b92e intentionally fails the new8MiB cold-allocation assertion at68,112,224B; exit1 and log retained. Candidate is3,100,744B. All final compilation/link/runtime steps otherwise succeeded.',
  'Both native program owners are logged by test main and match retained current HYCA DLLs. Foundation/non-ops native cached code is reused, not a complete current HEAD rebuild.',
  'Targeted Windows validation only; no full suite, Linux/macOS, performance timing, arbitrary cache graph matrix or PagedRead allocator expansion.',
 ],
 'artifacts':{'sources':'candidate/,baseline-provider.cc','source_identity':'source-identities.json','commands':'commands.json','graph_consumer':'graph_probe.cc','cleanup':'cleanup-and-retain.json'},
}
write(OUT/'summary.json',summary)
delete=[rec(p) for p in OUT.rglob('*') if p.is_file() and p.suffix.lower() in ['.obj','.exe','.dll','.lib','.exp','.map','.pdb','.pyc']]
for p in [OUT.parent/'cpu-native-causal/__pycache__/build.cpython-312.pyc',OUT.parent/'cpu-hadamard/__pycache__/run.cpython-312.pyc']:
 if p.exists():delete.append(rec(p))
write(OUT/'cleanup-and-retain.json',dict(rule='Exact candidate manifest only; no deletion performed. Root checks hashes and writes test.ps1. Rebuildable new host artifacts plus imported Python bytecode only. Keep all sources/logs/ZIP and four unchanged retained native objects/DLLs; no shared cache deletion.',delete_candidates=delete,delete_total_bytes=sum(r['bytes'] for r in delete),retain_for_future_cpu_work=native,retain_total_bytes=sum(r['bytes'] for r in native)))
files={p.relative_to(OUT).as_posix():p for p in OUT.rglob('*') if p.is_file() and p.name not in ['raw.zip','archive-record.json'] and p.suffix.lower() not in ['.obj','.exe','.dll','.lib','.exp','.map','.pdb','.pyc']}
for name in ['cpu-native-causal/build.py','cpu-hadamard/run.py','cpu-hadamard/test_main.cc']:
 files['reused/'+name]=OUT.parent/name
for pin in ['ffa4','mixed']:files['reused/'+pin+'/ggml-alloc.fallible.c']=OUT.parent/'cpu-math-attention'/pin/'ggml-alloc.fallible.c'
for name in ['gallocr_faults.c','gallocr_faults.h']:files['reused/'+name]=ROOT/'tests/compute_ggml_runtime'/name
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
record=dict(path=(OUT/'raw.zip').relative_to(ROOT).as_posix(),bytes=(OUT/'raw.zip').stat().st_size,sha256=sha(OUT/'raw.zip'),members=len(files),note='Sources/commands/identities/all logs only; no obj/exe/DLL/lib/SDK.')
write(OUT/'archive-record.json',record)
print(json.dumps(dict(archive=record,cleanup_files=len(delete),delete_bytes=sum(r['bytes'] for r in delete)),indent=2))
