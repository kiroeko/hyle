from pathlib import Path
import base64
import hashlib
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
HOST = 'kiro@172.22.10.198'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math'
BASE = HERE.parent / 'apple-ordinary-short-q'
SINK = HERE.parent / 'apple-sink-short-q'


def record(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def run(tag, argv, timeout=120):
    assert not (HERE / (tag + '-command.json')).exists(), 'No overwritten attempts'
    argv = list(map(str, argv))
    result = subprocess.run(argv, capture_output=True, timeout=timeout)
    (HERE / (tag + '-command.json')).write_text(json.dumps(dict(argv=argv, exit=result.returncode), indent=2) + '\n')
    (HERE / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (HERE / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, result.stdout.decode(errors='replace')[-7000:],
          result.stderr.decode(errors='replace')[-4000:], flush=True)
    if result.returncode:
        raise RuntimeError('Stopped: ' + tag)


def ssh_python(tag, code):
    payload = base64.b64encode(code.encode()).decode()
    run(tag, ['ssh', HOST, 'python3 -c \'import base64;exec(base64.b64decode("' + payload + '"))\''])


old = json.loads((SINK / 'expected-inputs.json').read_text())
built = json.loads((SINK / 'built-identities.json').read_text())['artifacts']
baseline = [next(i for i in old['retained_objects'] if i['path'].endswith('/candidate-' + key + '.o'))
            for key in ['context', 'tensor', 'graph']]
ops = next(i for i in built if i['path'].endswith('/operations.o'))
sink = next(i for i in built if i['path'].endswith('/sink-tests.o'))
baseline.insert(1, ops)
identity = json.loads((HERE / 'source-identity.json').read_text())
paths = [i['path'] for i in identity['sources'] if i['variant'] == 'candidate']
staged = [dict(record(HERE / 'source/candidate' / p), path=p) for p in paths]
extra = ['tests/compute_route_apple/sink_attention_test_support.h']
staged += [dict(record(REPO / p), path=p) for p in extra]
staged += [dict(record(HERE / 'measurement/consumer.cc'), path='measurement/consumer.cc')]
expected = dict(baseline_objects=[i['path'] for i in baseline],
                sink_direct_object=sink['path'], retained_objects=baseline + [sink], staged_sources=staged)
(HERE / 'expected-inputs.json').write_text(json.dumps(expected, indent=2) + '\n')
archive = HERE / 'sources.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in paths:
        tar.add(HERE / 'source/candidate' / p, arcname=p)
    for p in extra:
        tar.add(REPO / p, arcname=p)
    for p in ['measurement/consumer.cc', 'run_remote.py', 'expected-inputs.json', 'source-identity.json']:
        tar.add(HERE / p, arcname=p)
ssh_python('create-remote', 'from pathlib import Path; Path(' + repr(REMOTE) + ').mkdir(exist_ok=False)')
run('stage-sources', ['scp', archive, HOST + ':' + REMOTE + '/sources.tar.gz'])
ssh_python('extract-sources', '''from pathlib import Path
import tarfile
root=Path(''' + repr(REMOTE) + ''')
with tarfile.open(root/'sources.tar.gz','r:gz') as tar:
    for member in tar.getmembers():
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        target=root/member.name
        assert target.resolve().is_relative_to(root) and not target.exists()
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(tar.extractfile(member).read())
print('Staged only current 7 sources, original Sink helper, fixed consumer and driver metadata; no SDK copy')
''')
run('execute-remote', ['ssh', HOST, 'python3 ' + REMOTE + '/run_remote.py'], timeout=1500)
