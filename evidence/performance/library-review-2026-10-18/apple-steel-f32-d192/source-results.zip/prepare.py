from pathlib import Path
import difflib, hashlib, json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PREV=OUT.parent/'apple-steel-f32'
native_path=PREV/'materializer-output/mlx/backend/metal/scaled_dot_product_attention.cpp'
native=native_path.read_text()
manifest=json.loads((ROOT/'third_party/mlx_cast/patches.json').read_text())
entry=next(x for x in manifest['files'] if x['path']=='mlx/backend/metal/scaled_dot_product_attention.cpp')
assert hashlib.sha256(native_path.read_bytes()).hexdigest()==entry['after_sha256']
(OUT/'native.baseline.cpp').write_text(native)
old='  if (ordinary_f32) { bq = 16; bk = 8; wm = 2; wn = 1; }'
assert native.count(old)==1
native=native.replace(old,'''  const bool ordinary_f32_d192 = !page && !mask && !sinks &&
      q.dtype() == float32 && bd == 192 && bv == 192 && qL > 8 &&
      (!do_causal_ || qL <= kL);
  if (ordinary_f32 || ordinary_f32_d192) { bq = 16; bk = 8; wm = 2; wn = 1; }''')
old='  if (ordinary_f32) {\n    const auto required'
assert native.count(old)==1
native=native.replace(old,'  if (ordinary_f32 || ordinary_f32_d192) {\n    const auto required')
old='    const auto limit = d.mtl_device()->maxThreadgroupMemoryLength();\n    if (required > limit)'
assert native.count(old)==1
native=native.replace(old,'''    const auto limit = d.mtl_device()->maxThreadgroupMemoryLength();
    if (ordinary_f32_d192)
      std::fprintf(stderr, "# HYLE_F32_D192_STEEL q=%d kv=%d bq=%d bk=%d wm=%d wn=%d static=%lu limit=%lu key=%s\\n", qL, kL, bq, bk, wm, wn, static_cast<unsigned long>(required), static_cast<unsigned long>(limit), hash_name.c_str());
    if (required > limit)''')
native=native.replace('#include <sstream>','#include <sstream>\n#include <cstdio>')
(OUT/'native.candidate.cpp').write_text(native)
apple=(ROOT/'src/compute_route_apple/apple_tensor.cc').read_text()
(OUT/'apple_tensor.baseline.cc').write_text(apple)
old='''       (query.dtype() == mx::float32 && query.shape(3) == 256 &&
        attention.causal && known_gpu_without_nax()))'''
assert apple.count(old)==1
apple=apple.replace(old,'''       (query.dtype() == mx::float32 &&
        (query.shape(3) == 192 ||
         (query.shape(3) == 256 && attention.causal)) &&
        known_gpu_without_nax()))''')
(OUT/'apple_tensor.candidate.cc').write_text(apple)
test=(ROOT/'tests/compute_route_apple/attention_test.cc').read_text()
prefix=test[:test.index('TEST(AppleAttention, SupportedLargeDepths')]
weak=test[test.index('TEST(AppleAttention, FusedFloat32KeepsWeakProbabilities)'):test.index('TEST(AppleAttention, HalfPrefillRetainsWeakProbabilitiesBeforeLargeValues)')]
weak=weak.replace('FusedFloat32KeepsWeakProbabilities','D192Float32KeepsWeakProbabilities').replace('depth = 256','depth = 192').replace('depth=256','depth=192')
tests=prefix+'''TEST(AppleAttention, D192CausalGqaKeepsBhSdTailReference) {
  attention_case(192, mx::float32, c::AttentionLayout::kBatchHeadSequenceDepth,
                 17, 31, 0.125F, true, c::MaskKind::kNone);
}

TEST(AppleAttention, D192NoncausalGqaKeepsBsHdNegativeScaleReference) {
  attention_case(192, mx::float32, c::AttentionLayout::kBatchSequenceHeadDepth,
                 33, 17, -0.25F, false, c::MaskKind::kNone);
}

'''+weak+'} // namespace\n'
(OUT/'attention_test.cc').write_text(tests)
space=(PREV/'space.cc').read_text().replace('depth=256','depth=192').replace('\\"D\\":256','\\"D\\":192')
assert '134746112' in space and '528384' in space
qkv=(4*129*192+2*2*32768*192)*4
space=space.replace('134746112',str(qkv)).replace('528384',str(4*129*192*4))
(OUT/'space.cc').write_text(space)
for stem in ['native','apple_tensor']:
    before=(OUT/(stem+'.baseline.'+('cpp' if stem=='native' else 'cc'))).read_text()
    after=(OUT/(stem+'.candidate.'+('cpp' if stem=='native' else 'cc'))).read_text()
    (OUT/(stem+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='baseline',tofile='candidate')))
(OUT/'frozen-source-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.suffix in ['.cc','.cpp','.diff']},indent=2))
print('prepared only scratch source; caller qkv bytes',qkv)
