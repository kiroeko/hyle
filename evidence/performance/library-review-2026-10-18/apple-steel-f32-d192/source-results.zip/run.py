from pathlib import Path
import subprocess
OUT=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-steel-f32-d192'
HOST='kiro@172.22.10.198'
subprocess.run(['ssh',HOST,'mkdir -p '+REMOTE],check=True)
for name in ['native.baseline.cpp','native.candidate.cpp','apple_tensor.baseline.cc','apple_tensor.candidate.cc','attention_test.cc','space.cc','validate_remote.py']:
    subprocess.run(['scp',str(OUT/name),HOST+':'+REMOTE+'/'+name],check=True)
r=subprocess.run(['ssh',HOST,'cd '+REMOTE+' && /usr/bin/python3 validate_remote.py --build --run'],capture_output=True,timeout=240)
(OUT/'validation.stdout.txt').write_bytes(r.stdout);(OUT/'validation.stderr.txt').write_bytes(r.stderr)
print(r.stdout.decode(errors='replace'));print(r.stderr.decode(errors='replace'));raise SystemExit(r.returncode)
