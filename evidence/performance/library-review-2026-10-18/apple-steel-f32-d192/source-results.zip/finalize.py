from pathlib import Path
import hashlib,json,zipfile
OUT=Path(__file__).resolve().parent
RAW=OUT/'measured'
identities=json.loads((RAW/'runtime-identities.json').read_text())
remote='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-steel-f32-d192/'
cleanup={'remote_files':[{'path':p,**v} for p,v in identities.items() if p.startswith(remote)],'preserve':'All source/commands/stdout/stderr/results/maps; original SDK, source cache, metallib symlink and dependencies. Delete listed exact object/executable paths only through root test.ps1.'}
(OUT/'cleanup-candidates.json').write_text(json.dumps(cleanup,indent=2)+'\n')
baseline=json.loads((RAW/'baseline-space.stdout.txt').read_text())
candidate=json.loads((RAW/'candidate-space.stdout.txt').read_text())
summary={
 'status':'scoped_D192_f32_steel_applied_after_root_review; no_throughput_claim',
 'machine':{'host':'kiro@172.22.10.198','model':'Mac16,12','chip':'Apple M4','available_before':'41GiB','sdk':'/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk'},
 'scope':{'native':'Only ordinary !page/!mask/!sinks F32 Dq=Dv192, Q>8, causal Q<=KV or noncausal. Existing D256 guard literal and NAX early-return unchanged. One tile BQ16/BK8/WM2/WN1, plain float QueryT, hyle_q8=false.',
          'hyle':'GPU ordinary F32 D192 none-mask full attention on known Apple architecture generations13-16, nonempty B/KV. Reuses existing known_gpu_without_nax() cold capability query; unknown/new architectures retain current routes.',
          'precision':'Original float Steel loads, QK, online softmax probabilities and PV; no half/TF32/new kernel.',
          'unchanged':'D256, page/ragged/q8/half branches, CPU streams, explicit masks/fully-masked bool semantics, causal Q>KV/decode fallback; public C++ API/ABI.'},
 'threadgroup':{'original_D192_static_bytes':40448,'original_formula':'4*(32*(192+4)+max((16+4)*192,16*(192+4)))','candidate_expected_bytes':21760,'candidate_actual_PSO_bytes':21760,'actual_device_cap_bytes':32768,'raw':'measured/candidate-{tests,space}.stderr.txt','admission':'Actual staticThreadgroupMemoryLength checked before encoder dispatch; only selected tile was tested, no fallback tile trial.'},
 'correctness':{'baseline_tests':3,'candidate_tests':3,'passed_each':3,'cases':['F32 BHSD GQA Q17/KV31 causal positive0.125 scale, nonzero QK, unaligned tails','F32 BSHD GQA Q33/KV17 noncausal negative-0.25 scale, nonzero QK, unaligned tails','F32 GQA Q17/KV257 causal weak exp(-16) probabilities before V60000'],'oracle':'Existing independent FP64 test helper; F32 rel6e-6+abs2e-6 unchanged. Same exact test TU linked both arms.','raw':'measured/{baseline,candidate}-tests.{json,stdout.txt,stderr.txt}'},
 'space':{'fixed_shape':'F32 B1/H4/Hkv2/D192 Q129/KV32768,causal,None','input':'Pre-fixed Q/K0, V alternating +1.25/-1.25 by KV row; original FP64 prefix-mean oracle and rel6e-6+abs2e-6 over all99,072 outputs. No post-result input or budget change.','baseline':baseline,'candidate':candidate,'extra_peak_reduction_bytes':baseline['peak_minus_active_before']-candidate['peak_minus_active_before'],'metric':'MLX allocator peak minus active-before-submit, after public prepare/create_invocation/bind and clear_cache/reset_peak; submit/wait/synchronize included, output396288B retained. Cold preparation/JIT excluded; not whole-device VRAM or RSS.','executions':'Exactly one fresh baseline and one fresh candidate process, no timing or repeat matrix.'},
 'build':{'fresh_TUs':6,'links':4,'scope':'Two native selector overlays, two Hyle lowerers, one three-case test TU, one fixed space TU. Original current resource native host baseline freshly compiled so existing D256 patch is retained on both sides.','failures':'No remote compile/link/runtime failures. Two initial local preparation attempts failed exact source-hash path/test-name lookup before any remote build; corrected to current materializer-output source and actual full test name.','maps':json.loads((OUT/'link-map-check.json').read_text()),'identity':'measured/runtime-identities.json includes all reused SDK/gtest library hashes and temporary object/executable identities. No SDK/metallib rebuild, configure, download or copy.'},
 'limitations':['Only this Air M4 and one tile were tested. No throughput claim or speed ranking.','No explicit-mask fusion, new architecture force, causal Q>KV, decode or generic F32 depth expansion.','D192 long-Q uniform case was not run; prior D256 result is not evidence for D192 numerical behavior.'],
 'applied':{'commit':'706bfb748','root_independent_check':'Root independently reviewed the five-file diff and ran cmake -P check-lock.cmake: PASS, then committed. Recorded from root completion message; no additional source hashing/build/measurement.','canonical_source_sha256':json.loads((OUT/'frozen-applied-source-sha256.json').read_text()),'materializer':json.loads((OUT/'materializer-result.json').read_text()),'resource_check':json.loads((OUT/'resource-check-result.json').read_text()),'lock_update':json.loads((OUT/'lock-update.json').read_text()),'tested_to_applied':'Native removes diagnostic cstdio/fprintf and adds a scope comment; Hyle only changes explanatory comments; the three added canonical tests exactly equal executed scratch test bodies. D256 literal, NAX order, domains and math match the tested probe. No repeat native/SDK compilation or measurement.','initial_resource_failure':'Initial projected host check rejected an incorrectly encoded expected after-SHA; fixed hash generation to explicit UTF-8 from exact normalized baseline, existing manifest bytes and actual probe bytes unchanged. Failed attempt retained in materializer-initial-error.txt.'},
 'cleanup':'cleanup-candidates.json',
 'frozen_probe_source_sha256':json.loads((OUT/'frozen-source-sha256.json').read_text())}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file() and p!=archive and p.name!='archive-record.json' and p.suffix not in ('.zip','.gz'):
   z.write(p,p.relative_to(OUT))
record={'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'cleanup_files':len(cleanup['remote_files']),'cleanup_bytes':sum(x['bytes'] for x in cleanup['remote_files'])}
(OUT/'archive-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
