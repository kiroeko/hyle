from pathlib import Path
import hashlib,json,subprocess,sys
OUT=Path(__file__).resolve().parent
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
BLOCKS=Path('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-sdpa-blocks')
CORE=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
MLX=CORE/'hyle/_deps/mlx-490c5876b63c15e8/source'
GTEST=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
FMT=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/fmt-407c905e45ad-cd0d9446fff4/include')
flags=['-O3','-DNDEBUG','-std=c++23','-arch','arm64','-DHYLE_STATIC','-DMLX_STATIC','-DHYLE_COMPUTE_APPLE=1','-Wall','-Wextra','-Wpedantic','-Werror',
    '-I'+str(BLOCKS/'src/compute_route_apple'),'-I'+str(BLOCKS),'-I'+str(BLOCKS/'tests/compute_route_apple'),
    '-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp'),'-isystem',str(GTEST)]
libs=[SDK/'lib'/('lib'+x+'.a') for x in ['hyle_compute_route_apple','hyle_compute_stream','hyle_compute_state','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_simd','hyle_sched','hyle_container','hyle_mem_vm','hyle_mem','mimalloc_static','hyle_platform_thread','hyle_time','hyle_platform','hyle_error','hyle_compute_provider_ggml_metal','hyle_compute_ggml_runtime','ggml','ggml-metal','ggml-base','mlx']]
frameworks=['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore']
def run(tag,cmd,required=True):
    cmd=list(map(str,cmd));p=subprocess.run(cmd,cwd=OUT,capture_output=True,timeout=180)
    (OUT/(tag+'-command.json')).write_text(json.dumps(dict(command=cmd,cwd=str(OUT),exit=p.returncode),indent=2))
    (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
    print(tag,p.returncode,flush=True)
    if p.returncode and required:
        print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'));raise SystemExit(p.returncode)
    return p.returncode
if not (OUT/'mlx.metallib').exists():(OUT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
if '--build' in sys.argv:
    for arm in ['baseline','candidate']:
        run('native-'+arm+'-compile',['/usr/bin/clang++',*flags,'-Wno-unused-parameter','-DFMT_HEADER_ONLY=1','-isystem',str(MLX),'-isystem',str(FMT),'-c',OUT/('native.'+arm+'.cpp'),'-o',OUT/('native-'+arm+'.o')])
        run('apple-'+arm+'-compile',['/usr/bin/clang++',*flags,'-c',OUT/('apple_tensor.'+arm+'.cc'),'-o',OUT/('apple-'+arm+'.o')])
    for name,source in [('tests','attention_test.cc'),('space','space.cc')]:
        run(name+'-compile',['/usr/bin/clang++',*flags,'-c',OUT/source,'-o',OUT/(name+'.o')])
    for arm in ['baseline','candidate']:
        for kind in ['tests','space']:
            run(arm+'-'+kind+'-link',['/usr/bin/clang++','-O3','-std=c++23','-o',OUT/(arm+'-'+kind),OUT/(kind+'.o'),OUT/('apple-'+arm+'.o'),OUT/('native-'+arm+'.o'),*libs,
                *([CORE/'lib/libgtest_main.a'] if kind=='tests' else []),CORE/'lib/libgtest.a',*frameworks,'-Wl,-map,'+str(OUT/(arm+'-'+kind+'.map'))])
    identity={str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [*libs,CORE/'lib/libgtest_main.a',CORE/'lib/libgtest.a']}
    identity.update({str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in OUT.iterdir() if p.suffix=='.o' or (p.is_file() and p.name in ['baseline-tests','candidate-tests','baseline-space','candidate-space'])})
    (OUT/'runtime-identities.json').write_text(json.dumps(identity,indent=2))
if '--run' in sys.argv:
    for arm in ['baseline','candidate']:
        run(arm+'-tests',[OUT/(arm+'-tests'),'--gtest_filter=AppleAttention.D192*','--gtest_output=json:'+str(OUT/(arm+'-tests.json'))])
    # One process on each side; same fixed input/oracle and no further shapes.
    for arm in ['baseline','candidate']:
        run(arm+'-space',[OUT/(arm+'-space')],required=False)
