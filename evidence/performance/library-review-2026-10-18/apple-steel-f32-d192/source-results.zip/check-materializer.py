from pathlib import Path
import importlib.util,json,tarfile,hashlib
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
entry=next(x for x in json.loads((ROOT/'third_party/mlx_cast/patches.json').read_text(encoding='utf-8'))['files']
    if x['path']=='mlx/backend/metal/scaled_dot_product_attention.cpp')
archive=ROOT/'.scratch/inference-gaps/g04-g05/metal-lifetime/mlx-1f8e74e3f12f31365464a6867c6579f0e9b29d85.tar.gz'
source=OUT/'materializer-source'
with tarfile.open(archive) as t:
    member=next(m for m in t.getmembers() if m.name.endswith('/'+entry['path']))
    p=source/entry['path'];p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(t.extractfile(member).read())
manifest=OUT/'host-manifest.json'
manifest.write_text(json.dumps(dict(schema=1,files=[entry]),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
spec=importlib.util.spec_from_file_location('materializer',ROOT/'src/compute_ggml_runtime/prepare_source.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mod.prepare(source,OUT/'materializer-output',manifest)
actual=(OUT/'materializer-output'/entry['path']).read_bytes()
assert actual==(OUT/'native.applied.cpp').read_bytes().replace(b'\r\n',b'\n')
data=dict(scope='Existing exact materializer on projected single host entry and its pristine file read from the pinned archive. Not a full source/SDK rebuild.',
    after_sha256=hashlib.sha256(actual).hexdigest(),passed=True)
(OUT/'materializer-result.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data))
