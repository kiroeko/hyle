include("${CMAKE_CURRENT_LIST_DIR}/../../../cmake/HyleDependencyVersions.cmake")
_hyle_dependency_tree_sha256("${HYLE_DEPENDENCY_SOURCE_ROOT}/third_party/mlx_cast" tree)
_hyle_dependency_normalized_sha256("${HYLE_DEPENDENCY_SOURCE_ROOT}/third_party/mlx_cast/NOTICE.md" notice)
file(WRITE "${CMAKE_CURRENT_LIST_DIR}/resource-hashes.json"
  "{\"tree_sha256\":\"${tree}\",\"notice_sha256\":\"${notice}\"}\n")
