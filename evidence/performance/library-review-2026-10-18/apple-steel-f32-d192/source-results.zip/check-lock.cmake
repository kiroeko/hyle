include("${CMAKE_CURRENT_LIST_DIR}/../../../cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(mlx_cast_patches)
message(STATUS "MLX patch tree and license hashes match")
