#include "hyle/io/detail/proactor.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>

void check(bool value) { if (!value) std::abort(); }
int main() {
  using hyle::io::detail::Proactor;
  constexpr unsigned size = 1024;
  Proactor proactor;
  check(proactor.init(32));
  check(proactor.backend_kind() == hyle::io::IoBackend::kIoUring);
  check(proactor.register_file_table(size));
  const int fd = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
  check(fd >= 0);
  using Counter = std::uint64_t (*)();
  const auto visits = reinterpret_cast<Counter>(
      dlsym(RTLD_DEFAULT, "hyle_fixed_assignment_visits"));
  check(visits && visits() == 0);
  for (unsigned slot = 0; slot != size; ++slot)
    check(proactor.assign_fixed_slot(fd) == static_cast<int>(slot));
  check(proactor.assign_fixed_slot(fd) == -1);
  const auto count = visits();
  for (unsigned slot = 0; slot != size; ++slot)
    check(proactor.release_fixed_slot(static_cast<int>(slot)));
  check(::close(fd) == 0);
  std::printf("{\"table\":1024,\"assigned\":1024,\"released\":1024,\"scan_visits\":%llu,\"timed\":false}\n",
              static_cast<unsigned long long>(count));
}
