from pathlib import Path
import hashlib, json, os, shlex, subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/io-fixed-slot-hint'
PRIOR = HERE.parent / 'io-direct-slots'
CACHE = Path('/root/hyle-scratch/io-watch-v2-dev')
OUT = Path('/root/hyle-scratch/io-fixed-slot-hint-20261018')
OUT.mkdir(exist_ok=True)
commands = []

def run(tag, argv, env=None):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=CACHE, env=env, capture_output=True,
                            text=True, timeout=60)
    commands.append(dict(tag=tag, argv=argv, cwd=str(CACHE),
        LD_LIBRARY_PATH=None if env is None else env.get('LD_LIBRARY_PATH'),
        exit_code=result.returncode))
    (HERE / (tag+'.stdout.txt')).write_text(result.stdout)
    (HERE / (tag+'.stderr.txt')).write_text(result.stderr)
    (HERE / 'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    print(tag, result.returncode, result.stdout[-2500:], result.stderr[-1000:], flush=True)
    if result.returncode:
        raise RuntimeError(tag)
    return result.stdout

compdb = json.loads((PRIOR / 'compdb.stdout.txt').read_text())
def compile_command(suffix, source, obj):
    old = shlex.split(next(x['command'] for x in compdb if x['file'].endswith(suffix)))
    args = []
    i = 0
    while i < len(old):
        if old[i] in ('-MT','-MF','-o','-c'):
            i += 2
        elif old[i] == '-MD':
            i += 1
        else:
            args.append(old[i]); i += 1
    return args + ['-o',str(obj),'-c',str(source)]

raw = (PRIOR / 'link-commands.stdout.txt').read_text()
def link_command(target, output, oldobj, newobj):
    line = next(x for x in raw.splitlines() if ' -o '+target+' ' in x)
    args = shlex.split(line[len(': && '):-len(' && :')])
    args[args.index('-o')+1] = str(output)
    args[args.index(oldobj)] = str(newobj)
    return args

def build_proactor(arm, source):
    directory = OUT / arm
    directory.mkdir(exist_ok=True)
    obj = directory / 'proactor.o'
    lib = directory / 'libhyle_io_core.so.0.1.0'
    run('compile-'+arm, compile_command('/src/io_core/proactor.cc', source, obj))
    run('link-'+arm, link_command('bin/libhyle_io_core.so.0.1.0',lib,
        'src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o',obj))
    env = os.environ.copy()
    env['LD_LIBRARY_PATH'] = str(directory)+':'+str(CACHE/'bin')
    return directory, env

directory, env = build_proactor('candidate', HERE/'proactor.candidate.cc')
obj = directory / 'tests.o'
exe = directory / 'tests'
run('compile-tests', compile_command('/tests/io_core/proactor_test.cc',HERE/'proactor_test.cc',obj))
run('link-tests', link_command('bin/hyle_io_core_test',exe,
    'tests/io_core/CMakeFiles/hyle_io_core_test.dir/proactor_test.cc.o',obj))
assert str(directory/'libhyle_io_core.so.0.1.0') in run('loader-tests',['ldd',exe],env)
filter_ = 'Proactor.RegisteredFixedFiles:Proactor.FixedFileSubmissionsHonorQueueDepth:Proactor.DirectAccept:Proactor.DirectCloseBatchRetiresEachReservedSlot:Proactor.FixedTableAdmissionTracksFailedAcceptAndReleasedMappings:Proactor.FixedTableFillsAndReusesLowestHoleAfterFailedUpdate'
run('fixed-direct-tests',['timeout','--kill-after=2s','20s',exe,'--gtest_filter='+filter_],env)

consumer = OUT / 'scan'
run('compile-scan',['g++-14','-std=c++23','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-Werror',
    '-I'+str(ROOT/'include'),HERE/'scan.cc','-o',consumer,
    '-L'+str(CACHE/'bin'),'-lhyle_io_core','-Wl,-rpath,'+str(CACHE/'bin'),'-ldl'])
prefix = '''
#if HYLE_OS_LINUX
namespace { std::uint64_t hyle_fixed_assignment_scan_visits = 0; }
extern "C" __attribute__((visibility("default"))) std::uint64_t hyle_fixed_assignment_visits() {
  return hyle_fixed_assignment_scan_visits;
}
#endif
'''
results = []
for arm in ['before','candidate']:
    text = (HERE / ('proactor.'+arm+'.cc')).read_text()
    anchor = '#include "timeout_internal.h"\n'
    assert text.count(anchor) == 1
    text = text.replace(anchor,anchor+prefix)
    anchor = '    if (impl_->file_slots[i] == -1) { slot = static_cast<int>(i); break; }'
    assert text.count(anchor) == 1
    text = text.replace(anchor,'    ++hyle_fixed_assignment_scan_visits;\n'+anchor)
    source = HERE / ('scan-'+arm+'.cc')
    source.write_text(text)
    directory, env = build_proactor('scan-'+arm,source)
    assert str(directory/'libhyle_io_core.so.0.1.0') in run('loader-scan-'+arm,['ldd',consumer],env)
    result = json.loads(run('scan-'+arm,[consumer],env))
    assert result['scan_visits'] == (1024*1025//2 if arm == 'before' else 1024)
    results.append(dict(arm=arm,**result))
(HERE/'scan-results.json').write_text(json.dumps(results,indent=2)+'\n')

def record(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
artifacts = [record(p) for p in OUT.rglob('*') if p.is_file()]
(HERE/'cleanup-candidates.json').write_text(json.dumps(dict(host='WSL',directory=str(OUT),
    files=artifacts,total_bytes=sum(p['bytes'] for p in artifacts),
    note='Only this run rebuildable artifacts. Root test.ps1 exact cleanup; no deletion performed.'),indent=2)+'\n')
libs = [CACHE/'bin'/name for name in ['libhyle_io_core.so.0.1.0','libhyle_sched.so.0.1.0','libhyle_mem.so.0.1.0']]
(HERE/'build-identity.json').write_text(json.dumps(dict(artifacts=artifacts,
    original_reused_libraries=[record(p) for p in libs],
    no_configure_foundation_build_sdk_copy_or_download=True),indent=2)+'\n')
