from pathlib import Path
import hashlib, json, re, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {'src/io_core/proactor.cc':'proactor.candidate.cc',
           'tests/io_core/proactor_test.cc':'proactor_test.cc'}
for path, snapshot in sources.items():
    assert sha(ROOT/path) == sha(HERE/snapshot)
log = (HERE/'fixed-direct-tests.stdout.txt').read_text()
assert '[  PASSED  ] 6 tests.' in log and '[  SKIPPED ]' not in log
counts = json.loads((HERE/'scan-results.json').read_text())
assert [row['scan_visits'] for row in counts] == [524800,1024]
commit = 'e427c3cc8'
(HERE/'product.diff').write_bytes(subprocess.check_output(
    ['git','show','--format=',commit,'--',*sources],cwd=ROOT))
summary = {
    'task': 'Avoid repeated occupied-prefix scans when assigning registered fixed file slots',
    'applied_commit': commit,
    'change': 'One private lowest-candidate size_t in the Linux proactor mirror. No free-list, new dynamic allocation, user option, public API or header change.',
    'invariant': 'For every mirror index i<hint, file_slots[i] is nonfree, including -3pending-close and -4accepted-before-old-close. This is a conservative mirror lower bound, not an assertion about when the kernel frees a descriptor.',
    'transitions': {
        'register': 'Set0 for the new all-empty sparse table.',
        'assign': 'Scan fromhint, preserving the smallest free index. Only a successful native FILES_UPDATE advances toslot+1. Failure preserves the slot and hint.',
        'release': 'Only after successful FILES_UPDATE to-1, lower hint tomin(hint,index).',
        'direct_close': 'Only its successful CQE that actually creates-1 lowers the hint. Failed/cancelledclose returns to-2. -4close completion leaves the newer accepted descriptor at-2 without lowering.',
        'direct_accept': 'Assign remains blocked while accept slots are unobserved. -1→-2 and-3→-4 only occupy/reserve mirror entries and do not require loweringhint.',
    },
    'complexity': {
        'sequential_fill': 'The actual1024assignments visit524800=N(N+1)/2 mirror entries before and1024=N after. Thus continuous filling of an initially free table changes fromTheta(N squared) scan work toTheta(N). Native UPDATE calls remain1024.',
        'limits': 'This is not a global constant-time guarantee for arbitrary directaccept/hole interleavings. A conservative hint can rescan occupied entries when direct accepts consume a lower candidate; no timing, latency or end-to-end throughput claim.',
        'cost': 'One private size_t field and owner-local updates; no allocation. Actual Impl sizeof/padding was not separately measured.',
    },
    'validation': {
        'normal_candidate': 'Fresh uninstrumented proactor.cc and current test TU, linked existing io_core object closure plus cached foundation/gtest.6native fixed/direct tests PASS without SKIP.',
        'new_regression': '8slots: failed closed-positive-fd UPDATE followed by ordered fill0..7, full rejection, holes released5then2, repeated failed UPDATE preserving hole2, reuse2then5, full clear, duplicate release rejection and reuse0.',
        'tests': re.findall(r'^\[ RUN      \] (.+)$',log,re.M),
        'counter_probe': 'One fresh process per before/candidate instrumented proactor variant, same1024slot native sparse table and valid /dev/null descriptor. All1024assigned in index order, then all1024released successfully. Only a plain owner-local integer increment inside the actual scan loop; no timer/atomics/new thread.',
        'counter_results': counts,
        'runtime_identity': 'ldd confirms each test/probe loaded its intended fresh libhyle_io_core override, using LD_LIBRARY_PATH ahead of the same retained foundation cache.',
        'scope_limits': 'WSL Linux GCC14/current proactor TU only. Existing non-proactor IO TUs and foundation reused; no fullSDK build/configure/download/copy. No Windows/macOS, sanitizer, expandedCQE matrix or throughput measurement.',
        'failures': 'No unexpected compile/link/test/probe failures. Invalid-FD operations are deliberate regression inputs and preserve the expected empty slot.',
    },
    'source_identity': {
        'before': {'snapshot':'proactor.before.cc','sha256':sha(HERE/'proactor.before.cc')},
        'measured_applied_identical': {path:{'snapshot':snapshot,'sha256':sha(HERE/snapshot)}
            for path,snapshot in sources.items()},
        'counter_variants': {name:{'sha256':sha(HERE/name)} for name in ['scan-before.cc','scan-candidate.cc']},
    },
    'independent_review': 'Apple agent read all file_slots writes and both direct-close/accept CQE orderings, confirming the mirror lower bound; no separate run by that reviewer.',
    'cleanup': 'Exact WSL9artifact manifest; no deletion performed, original caches retained.',
}
(HERE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(HERE/'source-results.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(HERE.iterdir(),key=lambda p:p.name):
        if path.is_file() and path.suffix in {'.py','.cc','.json','.txt','.diff'} and path.name!='archive-record.json':
            z.write(path,path.name)
    z.write(ROOT/'include/hyle/io/detail/proactor.h','include/hyle/io/detail/proactor.h')
    for name in ['compdb.stdout.txt','link-commands.stdout.txt']:
        z.write(HERE.parent/'io-direct-slots'/name,'original-cache/'+name)
record = {name:{'path':(HERE/name).relative_to(ROOT).as_posix(),
    'bytes':(HERE/name).stat().st_size,'sha256':sha(HERE/name)}
    for name in ['summary.json','source-results.zip','cleanup-candidates.json']}
(HERE/'archive-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
