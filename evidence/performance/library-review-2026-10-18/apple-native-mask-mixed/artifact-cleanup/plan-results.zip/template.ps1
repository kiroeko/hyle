# TEMPLATE ONLY: root reviews/copies to test.ps1; never rerun stale cleanup scripts.
# Exact native stride/mixed generated files; accepted native/Hyle/test/probe caches retained.
$ErrorActionPreference = 'Stop'
$pythonSource = @'
import hashlib
import json
import os
from pathlib import Path
import stat

manifest = json.loads(r'''{"root":"/Users/kiro/hyle-scratch/compute-unified","targets":[{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/baseline/native-host.o","bytes":116880,"sha256":"62e3e9c8191117871975cfa87c48f56f3f9290353fe17f3a7c23d0b36da9f8cc"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate/native-host.o","bytes":117000,"sha256":"fc312c803aa49a72ca057107d892e922d797e0a9931e55b57a930cde849c6e04"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/baseline-tests","bytes":10478272,"sha256":"50609b9cec3dea178b98a8831dc1c9e65331e9cf835c89a16387cb95bb222de6"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate-tests","bytes":10478304,"sha256":"ca3dc15dbb27abd420c1246f343a3014eaa68888bebdd74954694f9ab45f180a"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate-diagnostic","bytes":9613448,"sha256":"1db8ef1f2a9387de0b63526e45932c34ded0668a5299baafbf4693ae8439afca"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/baseline-space","bytes":9577136,"sha256":"f4da1d501c2a8a5d2a18a39993876e494499cdb0f21c8d0c5775ffc906a1b901"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate-space","bytes":9577184,"sha256":"356e02c2c27b52c28c9a6c3cfa60f5087162c28c1cb16f3e6ebf02dc0768b31f"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/baseline/fast.o","bytes":248160,"sha256":"d1c344fe8361c2eb075d17fe90a9f210cf751f6769d7f34a872886a40e038717"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/baseline-tests","bytes":10481216,"sha256":"e51409f7029e6b9730ebbe3ddb03f90c1f483e77efd74edaf91d5d676d05eb68"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate-diagnostic","bytes":9621512,"sha256":"51274dd2a0410755ce2ca94aa5af202ba816dd562be34c8109d134ed36b076d3"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/baseline-space","bytes":9580048,"sha256":"b3427b22ad2ba35bdb6a68cee3a3643b2488de56750e2541cfe3ac0ca4856769"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate-space","bytes":9601712,"sha256":"8531d6c78c383b11108e4b19f0e1d72f4277c409c371540b2f5d66f8772e3e5d"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-stride/attention-tests.o","bytes":322168,"sha256":"bbc54931bc8e538a5da2e977c2fbc11eed820419879e31e0a25b85f31d9818cf"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-stride/baseline-newtests","bytes":10477184,"sha256":"f8b2bccc9785e47d63af8fb9c88d58e95bfdd76b9b8fa708cb40fd9427ad5c1a"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/attention-tests.o","bytes":302800,"sha256":"a952c73389323374271c80a2f69b434ed5a8c76f4354e150e9500a36a6f03a09"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/baseline-space","bytes":9576000,"sha256":"1d9ebf92b9a790c4a6e177a7d4010a5ef6e138d323a5da45ad9ee8068fb6b79f"}],"retain":[{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/context.o","bytes":187280,"sha256":"5c0c5c2e324f6667ec3ec18598b63330784d6977361cd97b8aef990a7102e896"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/operations.o","bytes":73616,"sha256":"1f43f11529f2582ec1103576ab700710669f80221a706aa2a7e4135815fe0f8c"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/tensor.o","bytes":131640,"sha256":"25e905b914d0c28740c1e3721ba277f9b8506c1fbbc6ab5939d629c895665b40"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q/candidate-graph.o","bytes":87824,"sha256":"13b405c34bb446496563f51db9b91439ea6004d34b00d833edcba6e25d197de6"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink-short-q/sink-tests.o","bytes":258920,"sha256":"1f7f88bb886dc897082422be2585d775c58dc0ba115a82d0bd3f2eef2d62e051"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/graph-tests.o","bytes":274408,"sha256":"ed7761898b035ff80b82a7ab3595fb3e32ccdbc968d823287f277285d8498784"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/consumer.o","bytes":44120,"sha256":"a7e8ff3253f6ed221fa7bca37b7051620584c004bccd8ce4707f0deb35fcfc13"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/diagnostic/diagnostic.o","bytes":94672,"sha256":"4416558f54c65d1333939de74d703b78c6e2b499ba154fb5a7e804a5119987b8"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate/steel_attention.o","bytes":71312,"sha256":"868bdff604640df9aa6a94eb01910ad11c5975de3a2b74905fcd6d98ddf2d351"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate/fast.o","bytes":258232,"sha256":"2a7095dc5e11bb45270529b9176825d13d2e04e69eb67faef18048e02162397e"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate/native-host.o","bytes":122528,"sha256":"a397eaf90db5f0578ac8d927cc6ccb9e94f4651c98b3dacb99be77a83ece951d"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/attention-tests.o","bytes":322544,"sha256":"ac67649f3e693741fa2335c451287d1db749c0874eec80c87a9df00c764599e0"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/consumer.o","bytes":42520,"sha256":"c6e4a17924498e8d422d32efd9e74e3e7d69b87dce2c3cc60ab3ccd8ac1aed20"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate-tests","bytes":10502864,"sha256":"b6f3a4e77d01897a52cf9676c2c1ff038066945d482c6ddc5e1e098d4a0cd445"}]}''')
root = Path(manifest['root'])
targets = manifest['targets']
retained = manifest['retain']
expected_targets = set(['/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/baseline/native-host.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate/native-host.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/baseline-tests', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate-tests', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate-diagnostic', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/baseline-space', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate-space', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/baseline/fast.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/baseline-tests', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate-diagnostic', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/baseline-space', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate-space', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-stride/attention-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-stride/baseline-newtests', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/attention-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/baseline-space'])
expected_retained = set(['/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/context.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/operations.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/tensor.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q/candidate-graph.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink-short-q/sink-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/graph-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/consumer.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/diagnostic/diagnostic.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate/steel_attention.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate/fast.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate/native-host.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/attention-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/consumer.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/candidate-tests'])
allowed_target_parents = {Path(p) for p in ['/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed/baseline', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-stride', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/baseline', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides/candidate']}

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

require(str(root) == '/Users/kiro/hyle-scratch/compute-unified', 'Wrong literal work root')
require(root.resolve(strict=True) == root, 'Root resolves outside literal path')
require(len(targets) == 16 and len(retained) == 14, 'Wrong exact manifest counts')
require({item['path'] for item in targets} == expected_targets, 'Wrong target allowlist')
require({item['path'] for item in retained} == expected_retained, 'Wrong retained allowlist')
all_items = targets + retained
require(len({item['path'] for item in all_items}) == 30, 'Repeated or overlapping path')
for item in all_items:
    require(Path(item['path']).is_relative_to(root), 'File outside literal work root')
for item in targets:
    require(Path(item['path']).parent in allowed_target_parents, 'Target outside exact batch directories')

def inspect(item):
    path = Path(item['path'])
    require(path.is_absolute() and str(path) == item['path'], 'Non-canonical absolute path')
    cursor = Path(path.anchor)
    for index, part in enumerate(path.parts[1:]):
        cursor = cursor / part
        status = cursor.lstat()
        require(not stat.S_ISLNK(status.st_mode), 'Symlink forbidden: ' + str(cursor))
        if index + 1 < len(path.parts) - 1:
            require(stat.S_ISDIR(status.st_mode), 'Non-directory ancestor: ' + str(cursor))
    require(path.resolve(strict=True) == path, 'Resolved path changed: ' + str(path))
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'Not a regular file: ' + str(path))
    require(before.st_size == item['bytes'], 'Size mismatch: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        require((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino),
                'File changed while opening: ' + str(path))
        hasher = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
        after = os.fstat(stream.fileno())
    require(after.st_size == item['bytes'] and hasher.hexdigest() == item['sha256'],
            'Size/SHA mismatch: ' + str(path))
    current = path.lstat()
    require(not stat.S_ISLNK(current.st_mode) and
            (current.st_dev, current.st_ino, current.st_size) ==
            (after.st_dev, after.st_ino, after.st_size),
            'File changed while hashing: ' + str(path))
    return current.st_dev, current.st_ino

# Preflight every target and every retained cache before any deletion.
identities = {item['path']: inspect(item) for item in all_items}
print(json.dumps({'preflight_files': len(all_items), 'delete_files': len(targets),
                  'delete_bytes': sum(item['bytes'] for item in targets),
                  'retain_files': len(retained),
                  'retain_bytes': sum(item['bytes'] for item in retained)}), flush=True)
deleted = []
for item in targets:
    require(inspect(item) == identities[item['path']],
            'Identity changed after preflight: ' + item['path'])
    Path(item['path']).unlink()
    deleted.append(item['path'])
    print('Deleted exact file: ' + item['path'], flush=True)
for item in retained:
    require(inspect(item) == identities[item['path']],
            'Retained file changed: ' + item['path'])
print(json.dumps({'deleted': deleted, 'retained_files_verified': len(retained),
                  'deleted_bytes': sum(item['bytes'] for item in targets)}), flush=True)

'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$remoteCode = 'import base64;exec(base64.b64decode("' + $payload + '"))'
$remoteCommand = "python3 -c '" + $remoteCode + "'"
& ssh 'kiro@172.22.10.198' $remoteCommand
if ($LASTEXITCODE -ne 0) { throw "Mac exact cleanup failed with SSH exit $LASTEXITCODE" }
