from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess

ROOT=Path(__file__).resolve().parent
exes=dict(baseline=ROOT/'baseline-space',candidate=ROOT/'candidate-space')
old=json.loads((ROOT/'built-identities.json').read_text())
new=old
for arm,path in exes.items():
    item=next(i for i in (old if arm=='baseline' else new) if i['path']==str(path))
    assert path.stat().st_size==item['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
assert not (ROOT/'latency-driver.json').exists(),'No second driver'
(ROOT/'latency-driver.json').write_text(json.dumps(dict(driver_pid=os.getpid(),executables={k:str(v) for k,v in exes.items()},order=['baseline','candidate','candidate','baseline']),indent=2)+'\n')
print('latency_driver_pid',os.getpid(),flush=True)
results=[]
for number,arm in enumerate(['baseline','candidate','candidate','baseline']):
    tag=f'latency-{number}-{arm}'
    assert not (ROOT/(tag+'-command.json')).exists(),'No repeated process'
    command=[str(exes[arm]),'--latency']
    process=subprocess.Popen(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    stdout,stderr=process.communicate(timeout=300)
    (ROOT/(tag+'-command.json')).write_text(json.dumps(dict(argv=command,cwd=str(ROOT),driver_pid=os.getpid(),child_pid=process.pid,exit=process.returncode,environment={k:v for k,v in os.environ.items() if k.startswith(('MLX_','MTL_','METAL_','HYLE_'))}),indent=2)+'\n')
    (ROOT/(tag+'.stdout.txt')).write_bytes(stdout);(ROOT/(tag+'.stderr.txt')).write_bytes(stderr)
    print(tag,process.pid,process.returncode,flush=True)
    if process.returncode:
        print(stdout.decode(errors='replace'),flush=True);print(stderr.decode(errors='replace'),flush=True)
        raise RuntimeError('Stopped at failed process')
    rows=[json.loads(s) for s in stdout.decode().splitlines() if s.startswith('{')];assert len(rows)==1
    row=rows[0]
    assert row['oracle_passed'] and row['oracle_elements_each']==524800 and row['warm_invocations']==row['untimed_oracle_invocations']==2
    samples=row['timed_submit_checkedwait_ns'];assert len(samples)==9 and all(v>0 for v in samples)
    results.append(dict(process=number,arm=arm,child_pid=process.pid,raw=row,minimum_ns=min(samples),median_ns=statistics.median(samples),maximum_ns=max(samples)))
    (ROOT/'latency-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([dict(process=r['process'],arm=r['arm'],median_ns=r['median_ns'],range_ns=[r['minimum_ns'],r['maximum_ns']]) for r in results]),flush=True)
