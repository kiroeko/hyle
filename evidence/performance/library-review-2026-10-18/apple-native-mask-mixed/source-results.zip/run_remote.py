from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'library-review-20261018-apple-fused-mask'
STRIDE = ROOT.parent / 'library-review-20261018-apple-native-mask-strides'
sys.path.insert(0, str(PREVIOUS))
import run_remote as shared

MLX = shared.CORE / 'hyle/_deps/mlx-490c5876b63c15e8/source'
FMT = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/fmt-407c905e45ad-cd0d9446fff4/include')


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def run(tag, argv):
    assert not (ROOT / (tag + '-command.json')).exists(), 'No repeated command'
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=500)
    save(tag + '-command.json', dict(argv=argv, cwd=str(ROOT), exit=result.returncode))
    (ROOT / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (ROOT / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-7000:], flush=True)
        print(result.stderr.decode(errors='replace')[-7000:], flush=True)
        raise RuntimeError('Stopped: ' + tag)


expected = json.loads((ROOT / 'expected-inputs.json').read_text())
for item in expected['staged_sources']:
    p = ROOT / item['path']
    assert p.stat().st_size == item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']
for item in expected['retained_objects']:
    assert shared.record(item['path']) == {key: item[key] for key in ['path', 'bytes', 'sha256']}
hosts = [Path(p) for p in expected['hyle_objects']]
tests = [ROOT / 'attention-tests.o', Path(expected['graph_test_object'])]
sink = Path(expected['sink_object'])
diagnostic_obj = Path(expected['diagnostic_object'])
consumer_obj = ROOT / 'consumer.o'
control_host = Path(expected['control_host_object'])
steel_obj = Path(expected['shared_steel_object'])
if not (ROOT / 'mlx.metallib').is_symlink():
    (ROOT / 'mlx.metallib').symlink_to(shared.SDK / 'lib/mlx.metallib')
assert (ROOT / 'mlx.metallib').resolve() == (shared.SDK / 'lib/mlx.metallib').resolve()
half = ROOT / 'tests/compute_provider_native'
if not half.is_symlink():
    half.symlink_to(shared.OLD / 'common/tests/compute_provider_native', target_is_directory=True)
assert half.resolve() == (shared.OLD / 'common/tests/compute_provider_native').resolve()
save('runtime-identities.json', dict(
    hyle_objects=[shared.record(p) for p in hosts], graph_tests=shared.record(tests[1]),
    sink=shared.record(sink), diagnostic=shared.record(diagnostic_obj),
    control_host=shared.record(control_host), shared_Steel=shared.record(steel_obj),
    SDK_libraries=[shared.record(p) for p in shared.LIBS],
    compiler=subprocess.check_output(['/usr/bin/clang++', '--version'], text=True),
    fresh_fast_TUs=2, fresh_host_TUs=1, fresh_test_TUs=1, fresh_consumer_TUs=1,
    fresh_Steel_or_Hyle_TUs=0, NO_NAX=True, NAX_compiled_or_executed=False,
    SDK_or_metallib_rebuilt=False,
    control='Fresh current-manifest fast.cpp and accepted stride host/Steel; NOT old SDK fast.cpp.',
    diagnostic_reference='Original frozen SDK baseline raw, NOT this batch current-manifest control.'))

artifacts = []
try:
    native_flags = [*shared.FLAGS, '-Wno-unused-parameter', '-Wno-sign-compare',
        '-Wno-unused-lambda-capture', '-DFMT_HEADER_ONLY=1', '-DMLX_METAL_NO_NAX']
    for tag, arm, relative, output in [
        ('compile-baseline-fast-native-warning-fix', 'baseline', 'mlx/fast.cpp', 'fast.o'),
        ('compile-candidate-fast', 'candidate', 'mlx/fast.cpp', 'fast.o'),
        ('compile-candidate-host', 'candidate', 'mlx/backend/metal/scaled_dot_product_attention.cpp', 'native-host.o')]:
        obj = ROOT / arm / output
        run(tag, ['/usr/bin/clang++', *native_flags, '-I' + str(ROOT / arm),
            '-I' + str(STRIDE / 'candidate'), '-isystem', MLX, '-isystem', FMT,
            '-isystem', shared.SDK / 'include', '-isystem', shared.SDK / 'include/metal_cpp',
            '-c', ROOT / arm / relative, '-o', obj])
        artifacts.append(obj)
    includes = ['-I' + str(ROOT / 'tests/compute_route_apple'), *shared.INCLUDES]
    for tag, source, obj in [
        ('compile-attention-tests', 'tests/compute_route_apple/attention_test.cc', tests[0]),
        ('compile-consumer', 'measurement/consumer.cc', consumer_obj)]:
        run(tag, ['/usr/bin/clang++', *shared.FLAGS, *includes, '-c', ROOT / source, '-o', obj])
        artifacts.append(obj)

    def native(arm):
        return [ROOT / arm / 'fast.o', control_host if arm == 'baseline' else ROOT / 'candidate/native-host.o', steel_obj]

    def link(tag, exe, leading, arm, gtest):
        run(tag, ['/usr/bin/clang++', '-O3', '-std=c++23', '-arch', 'arm64', '-o', exe,
            *leading, *hosts, *native(arm), *shared.LIBS, *gtest, *shared.FRAMEWORKS,
            '-Wl,-map,' + str(exe) + '.map'])
        artifacts.append(exe)
        mapping = Path(str(exe) + '.map').read_text()
        assert all(str(p) in mapping for p in hosts + native(arm))
        assert all('libmlx.a(' + name + ')' not in mapping for name in [
            'fast.cpp.o', 'scaled_dot_product_attention.cpp.o', 'steel_attention.cpp.o'])

    pattern = ':'.join([
        'AppleAttention.CenteredShortQueryMathKeepsMasksTailAndReboundOwners',
        'AppleGraph.PublishedCenteredShortQueryMathAndNegativeCrossCheckedBoundary',
        'AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners',
        'AppleSinkAttention.ShortQueriesRetainExistingFallback',
        'AppleSinkGraph.PublishedCopySinkAndNegativeCrossPrivateBoundary',
        'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners',
        'AppleAttention.FusedMasksRetainNativeValuesAcrossStridesAndRebinding',
        'AppleGraph.PublishedFusedMaskNativeResultsRetainOwnersAndRebinding',
        'AppleAttention.FullMasksKeepIndependentReferenceAcrossKvStrides'])
    gtest = [shared.CORE / 'lib/libgtest_main.a', shared.CORE / 'lib/libgtest.a']
    for arm in ['baseline', 'candidate']:
        exe = ROOT / (arm + '-tests')
        link('link-' + arm + '-tests', exe, tests + [sink], arm, gtest)
        selected = 'AppleAttention.FullMasksKeepIndependentReferenceAcrossKvStrides' if arm == 'baseline' else pattern
        run('run-' + arm + '-tests', [exe, '--gtest_filter=' + selected,
            '--gtest_throw_on_failure', '--gtest_fail_fast',
            '--gtest_output=json:' + str(ROOT / (arm + '-tests.json'))])
        result = json.loads((ROOT / (arm + '-tests.json')).read_text())
        assert result['tests'] == (1 if arm == 'baseline' else 9)
        assert result['failures'] == result['errors'] == 0
    save('functional-gate.json', dict(old_control_tests=1, candidate_tests=9, failures=0,
        independent_small_fixture_mask_types=['Bool', 'F16', 'BF16']))

    diagnostic = ROOT / 'diagnostic'
    (diagnostic / 'baseline-output').symlink_to(PREVIOUS / 'diagnostic/baseline-output', target_is_directory=True)
    (ROOT / 'diagnostic-run-baseline.stdout.txt').write_bytes((PREVIOUS / 'diagnostic-run-baseline.stdout.txt').read_bytes())
    diagnostic_exe = ROOT / 'candidate-diagnostic'
    link('link-candidate-diagnostic', diagnostic_exe, [diagnostic_obj], 'candidate',
        [shared.CORE / 'lib/libgtest.a'])
    run('diagnostic-run-candidate', [diagnostic_exe, diagnostic / 'candidate-output'])
    run('diagnostic-analysis', ['python3', diagnostic / 'analyze.py'])
    comparison = json.loads((diagnostic / 'comparison.json').read_text())
    assert comparison['checked_elements_per_arm'] == 4198400 and comparison['references']['consistent']
    assert comparison['all_native_postprocess_reports_consistent'] and comparison['all_lifetimes_true']
    regressions = ['oldpass_newfail', 'new_old_over', 'category_changes', 'bits_different', 'error_growth']
    if any(row['counts'][key] for row in comparison['outputs'] for key in regressions):
        raise RuntimeError('Diagnostic difference: stop before space; no golden PASS claim')

    spaces = {}
    for arm in ['baseline', 'candidate']:
        exe = ROOT / (arm + '-space')
        link('link-' + arm + '-space', exe, [consumer_obj], arm, [])
        run('run-' + arm + '-space', [exe, '--space'])
        rows = [json.loads(line) for line in (ROOT / ('run-' + arm + '-space.stdout.txt')).read_text().splitlines() if line.startswith('{')]
        assert len(rows) == 1 and rows[0]['oracle_passed'] and rows[0]['checked_elements'] == 524800
        spaces[arm] = rows[0]
        save('space-results.json', spaces)
    keys = ['active_before', 'active_after_with_output_lease', 'caller_port_requested_bytes',
        'caller_backing_requested_bytes', 'caller_mask_backing_requested_bytes',
        'caller_mask_physical_shape', 'caller_mask_query_stride', 'caller_mask_kv_stride', 'output_requested_bytes']
    assert all(spaces['baseline'][key] == spaces['candidate'][key] for key in keys)
    save('completed.json', dict(status='functional_diagnostic_space_complete_no_latency',
        new_current_manifest_control=True, old_SDK_raw_reused_only_for_diagnostic=True,
        native_fp64_failures_preserved=True))
finally:
    save('built-identities.json', [shared.record(p) for p in artifacts if p.exists()])
