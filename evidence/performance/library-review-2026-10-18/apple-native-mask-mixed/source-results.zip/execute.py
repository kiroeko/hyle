from pathlib import Path
import base64
import hashlib
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
SOURCE = HERE.parent
PREVIOUS = SOURCE.parent / 'apple-fused-mask'
STRIDE = SOURCE.parent / 'apple-native-mask-strides/validation'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-mixed'
HOST = 'kiro@172.22.10.198'


def run(tag, argv, timeout=120):
    assert not (HERE / (tag + '-command.json')).exists()
    argv = list(map(str, argv))
    result = subprocess.run(argv, capture_output=True, timeout=timeout)
    (HERE / (tag + '-command.json')).write_text(json.dumps(dict(argv=argv, exit=result.returncode), indent=2) + '\n')
    (HERE / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (HERE / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, result.stdout.decode(errors='replace')[-7000:], result.stderr.decode(errors='replace')[-4000:], flush=True)
    if result.returncode:
        raise RuntimeError('Stopped: ' + tag)


def ssh_python(tag, code):
    payload = base64.b64encode(code.encode()).decode()
    run(tag, ['ssh', HOST, 'python3 -c \'import base64;exec(base64.b64decode("' + payload + '"))\''])


assert hashlib.sha256((REPO / 'third_party/mlx_cast/patches.json').read_bytes()).hexdigest() == 'bf0f21411b581260fab14f0954056002fed13366b843c2312152a6f458be99d5'
replay = json.loads((SOURCE / 'full-manifest-replay.json').read_text())
sources = []
for item in replay['changed']:
    for arm, key in [('baseline', 'baseline_applied_sha256'), ('candidate', 'candidate_applied_sha256')]:
        p = SOURCE / arm / item['path']
        assert hashlib.sha256(p.read_bytes()).hexdigest() == item[key]
        sources.append((p, arm + '/' + item['path']))
consumer = SOURCE.parent / 'apple-native-mixed-mask/measurement/consumer.cc'
assert hashlib.sha256(consumer.read_bytes()).hexdigest() == 'baca12f1a5235b1fc76e2e78a4e55b223b54b76fd4ebdc7a4d6bf2badf6e7158'
attention = REPO / 'tests/compute_route_apple/attention_test.cc'
assert hashlib.sha256(attention.read_bytes()).hexdigest() == 'd7e11edd44a2ae389f69729eeb1bc1b9199479d2b740e611c7dd134a35f52ea9'
sources.extend([(consumer, 'measurement/consumer.cc'), (attention, 'tests/compute_route_apple/attention_test.cc'),
    (REPO / 'tests/compute_route_apple/tensor_test_support.h', 'tests/compute_route_apple/tensor_test_support.h'),
    (PREVIOUS / 'diagnostic/analyze.py', 'diagnostic/analyze.py'),
    (SOURCE / 'native.diff', 'native.diff'), (SOURCE / 'full-manifest-replay.json', 'full-manifest-replay.json')])
staged = [dict(path=n, bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p, n in sources]
old = json.loads((PREVIOUS / 'expected-inputs.json').read_text())
runtime = json.loads((STRIDE / 'runtime-identities.json').read_text())
stride_objects = json.loads((STRIDE / 'built-identities.json').read_text())
control = next(x for x in stride_objects if x['path'].endswith('/candidate/native-host.o'))
steel = next(x for x in stride_objects if x['path'].endswith('/candidate/steel_attention.o'))
expected = dict(staged_sources=staged,
    retained_objects=[*runtime['hyle_objects'], runtime['tests'][1], runtime['sink'], runtime['diagnostic'], control, steel],
    hyle_objects=old['baseline_objects'], graph_test_object=runtime['tests'][1]['path'],
    sink_object=runtime['sink']['path'], diagnostic_object=runtime['diagnostic']['path'],
    control_host_object=control['path'], shared_steel_object=steel['path'])
(HERE / 'expected-inputs.json').write_text(json.dumps(expected, indent=2) + '\n')
with tarfile.open(HERE / 'sources.tar.gz', 'w:gz') as tar:
    for p, name in sources:
        tar.add(p, arcname=name)
    for name in ['run_remote.py', 'expected-inputs.json']:
        tar.add(HERE / name, arcname=name)
ssh_python('create-remote', 'from pathlib import Path;Path(' + repr(REMOTE) + ').mkdir(exist_ok=False)')
run('stage-sources', ['scp', HERE / 'sources.tar.gz', HOST + ':' + REMOTE + '/sources.tar.gz'])
ssh_python('extract-sources', '''from pathlib import Path
import tarfile
root=Path(''' + repr(REMOTE) + ''')
with tarfile.open(root/'sources.tar.gz','r:gz') as tar:
 for member in tar.getmembers():
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  p=root/member.name;assert not p.exists() and p.resolve().is_relative_to(root)
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(member).read())
''')
run('execute-remote', ['ssh', HOST, 'python3 ' + REMOTE + '/run_remote.py'], timeout=1400)
