from pathlib import Path
import hashlib,json,os,subprocess,sys,time

ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
cpu=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
mode='smoke' if '--smoke' in sys.argv else 'formal'
tag=sys.argv[sys.argv.index('--tag')+1] if '--tag' in sys.argv else mode
env=os.environ.copy();env['PATH']=os.pathsep.join([str(cpu/'lib'),env['PATH']])
env['DISABLE_VULKAN_OBS_CAPTURE']='1';env['VK_LOADER_LAYERS_DISABLE']='~all~'
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
order=['current','control'] if mode=='smoke' else ['current','control','control','current']
records=[]
for i,arm in enumerate(order):
    label=f'{tag}-{i}-{arm}'
    command=[sys.executable,str(HERE/'source/measure.py'),'--image',str(HERE/mode/('g09_'+arm+'.dll')),
             '--label',label,'--warmup','0' if mode=='smoke' else '8','--iterations','1' if mode=='smoke' else '31',
             '--output',str(HERE/(label+'.json'))]
    t=time.monotonic();p=subprocess.run(command,cwd=HERE,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    (HERE/(label+'.log')).write_bytes(p.stdout);(HERE/(label+'.stderr.log')).write_bytes(p.stderr)
    records.append({'label':label,'command':command,'exit_code':p.returncode,'seconds':time.monotonic()-t,
                    'environment':{k:env.get(k) for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','DISABLE_VULKAN_OBS_CAPTURE','VK_LOADER_LAYERS_DISABLE']},
                    'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
    (HERE/(tag+'-run-commands.json')).write_text(json.dumps(records,indent=2)+'\n',encoding='utf8')
    print(label,p.returncode,round(time.monotonic()-t,3),p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'),flush=True)
    if p.returncode:raise SystemExit(p.returncode)
    d=json.loads((HERE/(label+'.json')).read_text(encoding='utf8'))
    for row in d['shapes']:
        print('SHAPE',row['name'],'GUARDS',row['guard_after_timing']-row['guard_before_timing'],
              'RESOURCES',row['resources_before_timing'],'THREADS',len(row['threads_before_timing']),len(row['threads_after_timing']),flush=True)
