from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time

ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
cl=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
link=cl.with_name('link.exe')
cache=ROOT/'.scratch/bench-api-runtime/vulkan/build'
foundation=ROOT/'.scratch/build-compute-v2-dev/bin'
cpu=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
vk=Path('C:/public/tools/hyle-dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f/include')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':str(cl),'CMAKE_C_COMPILER':str(cl)});env['VSLANG']='1033'
env['PATH']=os.pathsep.join([str(cpu/'lib'),env['PATH']])
mode='smoke' if '--smoke' in sys.argv else 'formal';count=1 if mode=='smoke' else 0
out=HERE/mode;out.mkdir(exist_ok=True)
log=[]
def run(label,command):
    t=time.monotonic();p=subprocess.run([str(x) for x in command],cwd=HERE,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (out/(label+'.log')).write_bytes(p.stdout)
    log.append({'label':label,'command':[str(x) for x in command],'exit_code':p.returncode,'seconds':time.monotonic()-t})
    (out/'commands.json').write_text(json.dumps(log,indent=2)+'\n',encoding='utf8')
    print(label,p.returncode,round(time.monotonic()-t,3),p.stdout.decode(errors='replace')[-2400:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)

flags=['/nologo','/c','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/Ob2','/MD','/DNDEBUG','/permissive-','/bigobj','/DHYLE_STATIC','/DHYLE_COMPUTE_VULKAN=1','/DG09_VULKAN=1','/DG09_VULKAN_POOL_API=1','/I'+str(ROOT/'include'),'/I'+str(ROOT/'src/graph_route_cpu_vulkan'),'/external:I'+str(vk),'/external:I'+str(cpu/'include'),'/external:I'+str(cpu/'include/torch/csrc/api/include'),'/external:W0']
common=HERE/'common';common.mkdir(exist_ok=True)
objects=[]
for name,file in [('vulkan_lowering',ROOT/'src/graph_route_vulkan/vulkan_lowering.cc'),('vulkan_batch',ROOT/'src/graph_route_vulkan/vulkan_batch.cc'),('hybrid_compile',ROOT/'src/graph_route_cpu_vulkan/compile.cc')]:
    obj=common/(name+'.obj')
    if not obj.exists():run('compile-'+name,[cl,*flags,file,'/Fo'+str(obj)])
    objects.append(obj)

line=next(x for x in (cache/'build.ninja').read_text(encoding='utf8').splitlines() if x.startswith('  LINK_LIBRARIES = '))
libraries=[]
override={'hyle_compute_state','hyle_compute_batch','hyle_compute_stream','hyle_compute','hyle_compute_ops','hyle_io_core','hyle_sched','hyle_mem_vm','hyle_platform_thread','hyle_container','hyle_mem','mimalloc_static','hyle_platform_fs','hyle_time','hyle_platform','hyle_error'}
for arg in line.split(' = ',1)[1].split():
    p=Path(arg)
    if p.stem=='g01_nr_nanobench':continue
    if p.stem in override:p=foundation/p.name
    elif ('/' in arg or '\\' in arg) and not p.is_absolute():p=cache/p
    if '/' in str(p) or '\\' in str(p):assert p.is_file(),p
    libraries.append(str(p))
for name in ['hyle_graph','hyle_graph_batch','hyle_compute_provider_native','hyle_compute_backend_cpu','hyle_simd']:
    p=foundation/(name+'.lib');assert p.is_file();libraries.append(str(p))
libraries += [str(cpu/'lib'/name) for name in ['torch.lib','torch_cpu.lib','c10.lib']]
assert not any('hyle_compute_provider_ggml.lib' in x or 'ggml-cpu.lib' in x for x in libraries)
for arm,value in [('current',0),('control',1)]:
    arm_objects=[]
    for name in ['invocation','facade']:
        obj=out/(arm+'-'+name+'.obj')
        file=HERE/'source'/(name+'.cc')
        if not obj.exists() or obj.stat().st_mtime<file.stat().st_mtime:
            run('compile-'+arm+'-'+name,[cl,*flags,'/DG09_NATIVE_WAIT_CONTROL='+str(value),'/DG09_COUNT_GUARDS='+str(count),'/DG09_IMAGE_TAG="windows-vulkan-'+arm+'-'+mode+'"',file,'/Fo'+str(obj)])
        arm_objects.append(obj)
    run('link-'+arm,[link,'/nologo','/DLL','/MACHINE:X64','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(out/('g09_'+arm+'.dll')),'/IMPLIB:'+str(out/('g09_'+arm+'.lib')),'/MAP:'+str(out/('g09_'+arm+'.map')),*objects,*arm_objects,*libraries])
identity={'mode':mode,'guard_counter':count,'libraries':[{'path':str(Path(x).resolve()),'bytes':Path(x).stat().st_size,'sha256':hashlib.sha256(Path(x).read_bytes()).hexdigest()} for x in libraries if Path(x).is_file()], 'images':{arm:hashlib.sha256((out/('g09_'+arm+'.dll')).read_bytes()).hexdigest() for arm in ['current','control']}}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
print('BUILT',mode,flush=True)
