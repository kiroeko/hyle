#include "facade_api.h"
#include <hyle/graph/cpu.h>
#include <hyle/sched/scheduler.h>
#if defined(G09_CUDA)
#include <hyle/graph/cuda.h>
#include <hyle/graph/cpu_cuda.h>
#elif defined(G09_APPLE)
#include <hyle/graph/cpu_apple.h>
#else
#include <hyle/graph/cpu_vulkan.h>
#include <hyle/sched/blocking.h>
#endif

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <exception>
#include <memory>
#include <optional>
#include <span>
#include <vector>

#ifndef G09_IMAGE_TAG
#error A facade must bind its own immutable SDK image tag
#endif

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
#if defined(G09_CUDA)
namespace b = g::cpu_cuda;
namespace n = c::cuda;
constexpr auto gpu_target = b::kCudaTarget;
#elif defined(G09_APPLE)
namespace b = g::cpu_apple;
namespace n = c::apple;
constexpr auto gpu_target = b::kAppleTarget;
#else
namespace b = g::cpu_vulkan;
namespace n = c::vulkan;
constexpr auto gpu_target = b::kVulkanTarget;
#endif
using hyle::Status;
constexpr std::size_t elements = 4 * 1024 * 1024;

Status require(bool ok, const char *message) {
  return ok ? Status::Ok() : Status::Internal(message);
}
struct Tensor {
  m::Buffer buffer;
  c::TensorView view;
};
hyle::Result<Tensor> tensor(m::MemoryResourceRef resource,
                          const c::TensorDesc &description) {
  HYLE_ASSIGN_OR_RETURN(auto bytes, description.required_bytes());
  HYLE_ASSIGN_OR_RETURN(auto buffer, m::Buffer::create(resource, bytes, 256));
  HYLE_ASSIGN_OR_RETURN(auto view, c::TensorView::create(description, buffer.view()));
  return Tensor{std::move(buffer), view};
}

// Declaration/destruction order keeps contexts/resources/Scheduler alive until
// every program, invocation, tensor and per-slot Queue has retired.
struct State {
  unsigned shape = 0, count = 0;
  bool closed = false;
  c::Context cpu;
#if defined(G09_CUDA)
  c::Context native;
  n::MemoryResource device, staging;
#else
  n::Context native;
#if defined(G09_APPLE)
  n::MemoryResource device;
#else
  n::MemoryResource device, staging;
#endif
#endif
#if !defined(G09_CUDA) && !defined(G09_APPLE)
  // Outlives Scheduler and every slot, including partial init cleanup.
  std::unique_ptr<hyle::sched::BlockingPool> native_wait_pool;
#endif
  std::unique_ptr<hyle::sched::Scheduler> scheduler;
  std::array<c::Queue, 2> cpu_queues;
#if defined(G09_CUDA)
  std::array<c::Queue, 2> gpu_queues;
  g::Executable executable;
  Tensor resident;
#else
  b::Executable executable;
#if defined(G09_APPLE)
  std::optional<mlx::core::array> resident;
#else
  n::Tensor resident;
#endif
#endif
  Tensor residual;
  std::array<Tensor, 2> x, y;
  std::vector<float> oracle;
  g::ValueId xi{}, ai{}, output{};
  std::array<b::Invocation, 2> slots;
  G09Facts report{};
  bool independent() const noexcept { return shape < 2; }

  Status init(unsigned selected) {
    HYLE_RETURN_IF_ERROR(require(selected < 4, "invalid fixed G09 shape"));
    shape = selected;
    count = shape == 2 ? 2u : 1u;
    HYLE_ASSIGN_OR_RETURN(cpu, g::cpu::create_context());
#if defined(G09_CUDA)
    HYLE_ASSIGN_OR_RETURN(native, g::cuda::create_context());
    HYLE_ASSIGN_OR_RETURN(device, n::MemoryResource::create(native, n::MemoryKind::kDevice));
    HYLE_ASSIGN_OR_RETURN(staging, n::MemoryResource::create(native, n::MemoryKind::kPinnedHost));
#elif defined(G09_APPLE)
    HYLE_ASSIGN_OR_RETURN(native, n::Context::create());
    HYLE_ASSIGN_OR_RETURN(device, n::MemoryResource::create(native));
#else
    HYLE_ASSIGN_OR_RETURN(native, n::Context::create());
    HYLE_ASSIGN_OR_RETURN(device, n::MemoryResource::create(native, n::MemoryKind::kDevice));
    HYLE_ASSIGN_OR_RETURN(staging, n::MemoryResource::create(native, n::MemoryKind::kStaging));
#endif
    HYLE_ASSIGN_OR_RETURN(auto description, c::TensorDesc::dense(c::DataType::kFloat32,
        std::array<std::int64_t, 1>{elements}));
    oracle.assign(elements, 1.25f);
    HYLE_ASSIGN_OR_RETURN(residual, tensor(m::system_resource(), description));
    HYLE_RETURN_IF_ERROR(residual.buffer.view().write(std::as_bytes(std::span(oracle))));
    if (independent()) {
#if defined(G09_CUDA)
      HYLE_ASSIGN_OR_RETURN(resident, tensor(device.ref(), description));
      HYLE_RETURN_IF_ERROR(resident.buffer.view().write(std::as_bytes(std::span(oracle))));
#elif defined(G09_APPLE)
      HYLE_ASSIGN_OR_RETURN(auto array, device.allocate(description));
      resident.emplace(std::move(array));
      HYLE_RETURN_IF_ERROR(device.copy_from_host(*resident, residual.view.as_const()));
#else
      HYLE_ASSIGN_OR_RETURN(resident, native.upload(description, std::as_bytes(std::span(oracle))));
#endif
    }
    HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
    HYLE_ASSIGN_OR_RETURN(xi, builder.input(description));
    HYLE_ASSIGN_OR_RETURN(ai, builder.input(description));
    g::ValueId cpu_value, gpu_value;
    if (shape == 1) {
      HYLE_ASSIGN_OR_RETURN(gpu_value, builder.add(c::Unary{c::UnaryKind::kNeg}, ai));
      HYLE_ASSIGN_OR_RETURN(cpu_value, builder.add(c::Unary{c::UnaryKind::kAbs}, xi));
    } else {
      HYLE_ASSIGN_OR_RETURN(cpu_value, builder.add(c::Unary{c::UnaryKind::kAbs}, xi));
      HYLE_ASSIGN_OR_RETURN(gpu_value, builder.add(c::Unary{c::UnaryKind::kNeg}, independent() ? ai : cpu_value));
    }
    HYLE_ASSIGN_OR_RETURN(output, builder.add(c::Binary{}, independent() ? cpu_value : ai, gpu_value));
    HYLE_RETURN_IF_ERROR(builder.publish(output));
    HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
    const std::array placements{
        g::NodePlacement{*graph.node_id(shape == 1 ? 1 : 0), b::kCpuTarget, g::PlacementStrength::kRequired},
        g::NodePlacement{*graph.node_id(shape == 1 ? 0 : 1), gpu_target, g::PlacementStrength::kRequired},
        g::NodePlacement{*graph.node_id(2), b::kCpuTarget, g::PlacementStrength::kRequired}};
    report.elements = elements;
    report.slots = count;
    report.cpu_target = 1;
    report.gpu_target = 0;
#if defined(G09_CUDA)
    const std::array external{
        g::ExternalResourceContract{xi, b::kHostStorage},
        g::ExternalResourceContract{ai, independent() ? b::kDeviceStorage : b::kHostStorage},
        g::ExternalResourceContract{output, b::kHostStorage}};
    HYLE_ASSIGN_OR_RETURN(auto compiled, b::compile(graph,
        {.cpu = &cpu, .cuda = &native, .staging = &staging, .device = &device},
        {.node_placements = placements, .external_resources = external}));
    report.cold_fragments = compiled.report.segment_count();
    executable = std::move(compiled.executable);
#else
#if defined(G09_APPLE)
    const b::Environment environment{.cpu = &cpu, .apple = &native, .native = &device};
#else
    const b::Environment environment{.cpu = &cpu, .vulkan = &native, .device = &device, .staging = &staging};
#endif
    b::CompileReport compilation;
    HYLE_ASSIGN_OR_RETURN(executable, b::compile(graph, environment,
        {.node_placements = placements}, &compilation));
    report.cold_fragments = compilation.fragments.size();
#endif
    // Do not require the baseline to have the candidate's private partition.
#if !defined(G09_CUDA) && !defined(G09_APPLE)
    // Equal cold capacity in both SDK arms; workers remain naturally lazy.
    Status pool_status;
    native_wait_pool = std::make_unique<hyle::sched::BlockingPool>(
        m::system_allocator(), 2, std::chrono::seconds(10), &pool_status);
    HYLE_RETURN_IF_ERROR(pool_status);
#endif
    scheduler = std::make_unique<hyle::sched::Scheduler>(2, m::system_allocator(), 64);
    for (unsigned i = 0; i < count; ++i) {
      HYLE_ASSIGN_OR_RETURN(cpu_queues[i], cpu.create_queue());
      HYLE_ASSIGN_OR_RETURN(x[i], tensor(m::system_resource(), description));
      for (std::size_t j = 0; j < elements; ++j)
        oracle[j] = float(int(j % 101) - 50) * 0.125f + float(i) * 0.25f;
      HYLE_RETURN_IF_ERROR(x[i].buffer.view().write(std::as_bytes(std::span(oracle))));
#if defined(G09_CUDA)
      HYLE_ASSIGN_OR_RETURN(y[i], tensor(m::system_resource(), description));
      HYLE_ASSIGN_OR_RETURN(gpu_queues[i], native.create_queue());
      HYLE_ASSIGN_OR_RETURN(auto invocation, executable.create_invocation());
      const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &gpu_queues[i]},
                              g::QueueBinding{g::ExecutionLaneId{1}, &cpu_queues[i]}};
      HYLE_ASSIGN_OR_RETURN(slots[i], b::Invocation::create(std::move(invocation), *scheduler, queues));
#elif !defined(G09_APPLE) && defined(G09_VULKAN_POOL_API) && G09_VULKAN_POOL_API
      HYLE_ASSIGN_OR_RETURN(slots[i], executable.create_invocation(
          *scheduler, cpu_queues[i], *native_wait_pool));
#else
      HYLE_ASSIGN_OR_RETURN(slots[i], executable.create_invocation(*scheduler, cpu_queues[i]));
#endif
      HYLE_RETURN_IF_ERROR(prepare(i));
    }
    // These reports describe preparation, not actual kernels/polls/timing.
    HYLE_ASSIGN_OR_RETURN(auto prepared, slots[0].replay_report());
#if defined(G09_CUDA)
    report.planned_copy_count = prepared.staging_copy_count;
    report.planned_copy_bytes = prepared.staging_copy_bytes;
#else
    report.planned_copy_count = prepared.host_copy_count;
    report.planned_copy_bytes = prepared.host_copy_bytes;
#endif
    return Status::Ok();
  }

  Status prepare(unsigned i) {
    HYLE_RETURN_IF_ERROR(slots[i].bind(xi, x[i].view.as_const()));
    if (independent()) {
#if defined(G09_CUDA)
      HYLE_RETURN_IF_ERROR(slots[i].bind(ai, resident.view.as_const()));
#elif defined(G09_APPLE)
      HYLE_RETURN_IF_ERROR(slots[i].bind(ai, *resident));
#else
      HYLE_RETURN_IF_ERROR(slots[i].bind(ai, resident));
#endif
    } else HYLE_RETURN_IF_ERROR(slots[i].bind(ai, residual.view.as_const()));
#if defined(G09_CUDA)
    HYLE_RETURN_IF_ERROR(slots[i].bind(output, y[i].view));
#endif
    return slots[i].prepare_replay();
  }

  Status replay(bool full_oracle) {
    struct Drain {
      hyle::sched::Scheduler &scheduler;
      ~Drain() { scheduler.drain(); }
    } drain{*scheduler};
    for (unsigned i = 0; i < count; ++i) HYLE_RETURN_IF_ERROR(prepare(i));
    {
      std::array<c::OwnedResult<b::Results>, 2> pending;
      std::array<c::ResultLease<b::Results>, 2> results;
      for (unsigned i = 0; i < count; ++i) {
        HYLE_ASSIGN_OR_RETURN(pending[i], slots[i].submit());
      }
      for (unsigned i = 0; i < count; ++i) {
        HYLE_ASSIGN_OR_RETURN(results[i], pending[i].wait());
        HYLE_ASSIGN_OR_RETURN(auto view, results[i]->output(output));
        if (full_oracle) {
          HYLE_RETURN_IF_ERROR(view.storage().read(std::as_writable_bytes(std::span(oracle))));
          for (std::size_t j = 0; j < elements; ++j) {
            const auto input = float(int(j % 101) - 50) * 0.125f + float(i) * 0.25f;
            const auto expected = independent() ? std::abs(input) - 1.25f : 1.25f - std::abs(input);
            HYLE_RETURN_IF_ERROR(require(oracle[j] == expected, "full original G09 output oracle differs"));
          }
        } else {
          float value = 0;
          HYLE_ASSIGN_OR_RETURN(auto scalar, view.storage().subview(0, sizeof(value)));
          HYLE_RETURN_IF_ERROR(scalar.read(std::as_writable_bytes(std::span(&value, 1))));
          const auto input = -6.25f + float(i) * 0.25f;
          const auto expected = independent() ? std::abs(input) - 1.25f : 1.25f - std::abs(input);
          HYLE_RETURN_IF_ERROR(require(value == expected, "timed scalar observation differs"));
        }
      }
    } // Every borrowed view, ResultLease and OwnedResult is gone before drain.
    return Status::Ok(); // Drain runs before C facade replay returns.
  }

  Status close() noexcept {
    if (closed) return Status::Ok();
    closed = true;
    Status first = Status::Ok();
    for (unsigned i = 0; i < count; ++i) {
      if (!slots[i].valid()) continue;
      const auto status = slots[i].close();
      if (first.ok() && !status.ok()) first = status;
    }
    if (scheduler) scheduler->drain();
#if !defined(G09_CUDA) && !defined(G09_APPLE)
    if (native_wait_pool) native_wait_pool->shutdown();
#endif
    return first;
  }
  ~State() { close().IgnoreError(); }
};

void message(char *buffer, std::size_t capacity, const char *value) noexcept {
  if (buffer && capacity) std::snprintf(buffer, capacity, "%s", value);
}
int status_result(const Status &status, char *buffer, std::size_t capacity) noexcept {
  if (status.ok()) return 0;
  if (buffer && capacity) std::snprintf(buffer, capacity, "%.*s", int(status.message().size()), status.message().data());
  return 1;
}
void *create(unsigned shape, char *error, std::size_t capacity) noexcept {
  try {
    auto state = std::make_unique<State>();
    const auto status = state->init(shape);
    if (status_result(status, error, capacity)) return nullptr;
    return state.release();
  } catch (const std::exception &failure) { message(error, capacity, failure.what()); return nullptr; }
  catch (...) { message(error, capacity, "unknown facade construction exception"); return nullptr; }
}
int replay(void *state, unsigned full_oracle, char *error, std::size_t capacity) noexcept {
  try {
    if (!state || full_oracle > 1) { message(error, capacity, "invalid replay argument"); return 1; }
    return status_result(static_cast<State *>(state)->replay(full_oracle != 0), error, capacity);
  } catch (const std::exception &failure) { message(error, capacity, failure.what()); return 1; }
  catch (...) { message(error, capacity, "unknown facade replay exception"); return 1; }
}
int facts(void *state, G09Facts *result, char *error, std::size_t capacity) noexcept {
  if (!state || !result) { message(error, capacity, "invalid facts argument"); return 1; }
  *result = static_cast<State *>(state)->report;
  return 0;
}
int destroy(void *opaque, char *error, std::size_t capacity) noexcept {
  std::unique_ptr<State> state(static_cast<State *>(opaque));
  return state ? status_result(state->close(), error, capacity) : 0;
}
const G09FacadeApi api{1, sizeof(G09FacadeApi), G09_IMAGE_TAG, &create, &replay, &facts, &destroy};
} // namespace

#if defined(_WIN32)
#define G09_EXPORT __declspec(dllexport)
#else
#define G09_EXPORT __attribute__((visibility("default")))
#endif
extern "C" G09_EXPORT const G09FacadeApi *hyle_g09_facade_v1() noexcept { return &api; }
