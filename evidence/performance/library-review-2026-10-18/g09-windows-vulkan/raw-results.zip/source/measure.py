"""Direct timings of the original G09 private facade; no qualification system."""
from pathlib import Path
import argparse
import ctypes as C
import hashlib
import json
import math
import os
import platform
import statistics
import subprocess
import sys
import time

SHAPES = ['independent-cpu-first', 'independent-gpu-first', 'two-microbatches', 'serial-holdout']
ERROR = C.POINTER(C.c_char)
CREATE = C.CFUNCTYPE(C.c_void_p, C.c_uint32, ERROR, C.c_size_t)
REPLAY = C.CFUNCTYPE(C.c_int, C.c_void_p, C.c_uint32, ERROR, C.c_size_t)
DESTROY = C.CFUNCTYPE(C.c_int, C.c_void_p, ERROR, C.c_size_t)

class Facts(C.Structure):
    _fields_ = [(name, C.c_uint64) for name in ['elements', 'slots', 'cold_fragments',
                'planned_copy_count', 'planned_copy_bytes', 'cpu_target', 'gpu_target']]

FACTS = C.CFUNCTYPE(C.c_int, C.c_void_p, C.POINTER(Facts), ERROR, C.c_size_t)

class Api(C.Structure):
    _fields_ = [('abi_version', C.c_uint64), ('struct_bytes', C.c_uint64),
                ('image_tag', C.c_char_p), ('create', CREATE), ('replay', REPLAY),
                ('facts', FACTS), ('destroy', DESTROY)]

def stats(values):
    ordered = sorted(values)
    return {'n': len(values), 'median_ns': statistics.median(values),
            'p90_ns': ordered[math.ceil(.90 * len(ordered)) - 1],
            'p99_ns': ordered[math.ceil(.99 * len(ordered)) - 1],
            'min_ns': ordered[0], 'max_ns': ordered[-1]}

def save(path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

def threads():
    # Outside replay intervals; no monitoring thread. Times are 100 ns units.
    from ctypes import wintypes as W
    k=C.WinDLL('kernel32',use_last_error=True)
    class Entry(C.Structure):
        _fields_=[('dwSize',W.DWORD),('cntUsage',W.DWORD),('th32ThreadID',W.DWORD),
                  ('th32OwnerProcessID',W.DWORD),('tpBasePri',W.LONG),
                  ('tpDeltaPri',W.LONG),('dwFlags',W.DWORD)]
    k.CreateToolhelp32Snapshot.argtypes=[W.DWORD,W.DWORD];k.CreateToolhelp32Snapshot.restype=W.HANDLE
    k.Thread32First.argtypes=[W.HANDLE,C.POINTER(Entry)];k.Thread32Next.argtypes=[W.HANDLE,C.POINTER(Entry)]
    k.OpenThread.argtypes=[W.DWORD,W.BOOL,W.DWORD];k.OpenThread.restype=W.HANDLE
    k.GetThreadTimes.argtypes=[W.HANDLE,*([C.POINTER(C.c_uint64)]*4)]
    k.GetThreadDescription.argtypes=[W.HANDLE,C.POINTER(C.c_void_p)]
    k.CloseHandle.argtypes=[W.HANDLE];k.LocalFree.argtypes=[C.c_void_p]
    snap=k.CreateToolhelp32Snapshot(4,0)
    if snap==C.c_void_p(-1).value:raise C.WinError(C.get_last_error())
    row=Entry();row.dwSize=C.sizeof(row);rows=[]
    try:
        ready=k.Thread32First(snap,C.byref(row))
        while ready:
            if row.th32OwnerProcessID==os.getpid():
                h=k.OpenThread(0x0800,False,row.th32ThreadID)
                if h:
                    name=C.c_void_p();created=C.c_uint64();ended=C.c_uint64();kernel=C.c_uint64();user=C.c_uint64()
                    try:
                        text=''
                        if k.GetThreadDescription(h,C.byref(name))==0 and name:
                            text=C.wstring_at(name);k.LocalFree(name)
                        if not k.GetThreadTimes(h,C.byref(created),C.byref(ended),C.byref(kernel),C.byref(user)):
                            raise C.WinError(C.get_last_error())
                        rows.append({'tid':row.th32ThreadID,'name':text,'created_100ns':created.value,
                                     'user_100ns':user.value,'kernel_100ns':kernel.value})
                    finally:k.CloseHandle(h)
            ready=k.Thread32Next(snap,C.byref(row))
    finally:k.CloseHandle(snap)
    return rows

def measure(args):
    from ctypes import wintypes as W
    k=C.WinDLL('kernel32',use_last_error=True)
    k.GetCurrentProcess.restype=W.HANDLE
    k.SetProcessAffinityMask.argtypes=[W.HANDLE,C.c_size_t]
    if not k.SetProcessAffinityMask(k.GetCurrentProcess(),0x55):raise C.WinError(C.get_last_error())
    image = args.image.resolve(strict=True)
    directories = []
    if os.name == 'nt':
        directories.append(os.add_dll_directory(str(image.parent)))
        directories.append(os.add_dll_directory('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib'))
    report = {'mode': 'DIRECT_USER_JOURNEY_LATENCY', 'label': args.label,
              'image': str(image), 'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
              'host': platform.platform(), 'pid': os.getpid(), 'observer_resources': '2 Scheduler workers + explicit lazy BlockingPool capacity2; same resident waiter startup/stop; driver/runtime threads observed separately', 'vulkan_environment': {k: os.environ.get(k) for k in ['VK_INSTANCE_LAYERS','VK_LAYER_PATH','VK_LOADER_LAYERS_DISABLE','VK_ICD_FILENAMES']}, 'python': sys.version, 'shapes': [],
              'timing_boundary': 'Python ctypes call through original private C table; includes FFI overhead; native replay drains and releases every result before return',
              'warm_math': 'Current explicit Native CPU Add(x,x) / Vulkan Neg / CPU Add; input4M and dependency shapes retained; exact modified-workload oracle before/after, scalar check timed; not old CPU Abs result',
              'warmup_replays': args.warmup, 'iterations': args.iterations,
              'process_exit_vendor_cleanup': 'Included only in parent process_elapsed_ns, not warm samples'}
    begin = time.perf_counter_ns()
    library = C.CDLL(str(image))
    report['image_load_ns'] = time.perf_counter_ns() - begin
    getter = library.hyle_g09_facade_v1
    getter.restype = C.POINTER(Api)
    api = getter().contents
    if api.abi_version != 1 or api.struct_bytes != C.sizeof(Api):
        raise RuntimeError('Private facade ABI mismatch')
    report['image_tag'] = api.image_tag.decode()
    guard_visits = library.hyle_g09_guard_visits
    guard_visits.restype = C.c_uint64
    report['process_affinity_mask']='0x55 (logical CPUs 0,2,4,6; no P/E claim)'
    resources=library.hyle_g09_state_resources
    resources.argtypes=[C.c_void_p];resources.restype=C.c_char_p
    report['threads_initial'] = threads()
    for shape in [0, 3]:
        name = SHAPES[shape]
        error = C.create_string_buffer(2048)
        row = {'shape': shape, 'name': name, 'warm_ns': []}
        report['shapes'].append(row)
        state = None
        try:
            begin = time.perf_counter_ns()
            state = api.create(shape, error, len(error))
            row['cold_create_ns'] = time.perf_counter_ns() - begin
            if not state:
                raise RuntimeError(error.value.decode(errors='replace'))
            facts = Facts()
            if api.facts(state, C.byref(facts), error, len(error)):
                raise RuntimeError(error.value.decode(errors='replace'))
            row['facts'] = {field: getattr(facts, field) for field, _ in Facts._fields_}
            if facts.elements != 4194304 or facts.slots != (2 if shape == 2 else 1) or facts.cpu_target != 1 or facts.gpu_target != 0:
                raise RuntimeError('Original workload elements/slots/CPU+GPU targets changed')

            def replay(full=False):
                begin = time.perf_counter_ns()
                code = api.replay(state, int(full), error, len(error))
                elapsed = time.perf_counter_ns() - begin
                if code:
                    raise RuntimeError(error.value.decode(errors='replace'))
                return elapsed

            row['resources_after_create'] = json.loads(resources(state))
            row['threads_after_create'] = threads()
            row['first_replay_ns'] = replay()
            row['full_oracle_before_ns'] = replay(True)
            for _ in range(args.warmup):
                replay()
            row['resources_before_timing'] = json.loads(resources(state))
            row['threads_before_timing'] = threads()
            row['guard_before_timing'] = guard_visits()
            for _ in range(args.iterations):
                row['warm_ns'].append(replay())
            row['guard_after_timing'] = guard_visits()
            row['threads_after_timing'] = threads()
            row['resources_after_timing'] = json.loads(resources(state))
            row['full_oracle_after_ns'] = replay(True)
            row['warm'] = stats(row['warm_ns'])
            row['oracle'] = 'PASS_ALL_ELEMENTS_ALL_SLOTS_BEFORE_AND_AFTER'
        except BaseException as failure:
            row['error'] = repr(failure)
            report['error'] = repr(failure)
            raise
        finally:
            if state:
                begin = time.perf_counter_ns()
                code = api.destroy(state, error, len(error))
                row['close_destroy_ns'] = time.perf_counter_ns() - begin
                row['threads_after_destroy'] = threads()
                if code:
                    row['destroy_error'] = error.value.decode(errors='replace')
                    report['error'] = row['destroy_error']
            save(args.output, report)
        if 'error' in report:
            raise RuntimeError(report['error'])
    report['result'] = 'COMPLETED_WITH_NUMERICAL_CHECKS'
    save(args.output, report)
    for row in report['shapes']:
        print(f"{args.label} {row['name']}: cold={row['cold_create_ns']/1e6:.3f} ms first={row['first_replay_ns']/1e6:.3f} ms warm median={row['warm']['median_ns']/1e6:.3f} p90={row['warm']['p90_ns']/1e6:.3f} p99={row['warm']['p99_ns']/1e6:.3f} ms oracle=PASS", flush=True)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--image', type=Path, required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--warmup', type=int, default=8)
parser.add_argument('--iterations', type=int, default=31)
parser.add_argument('--output', type=Path, required=True)
measure(parser.parse_args())
