from pathlib import Path
import hashlib,json

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
source=HERE/'source';source.mkdir(exist_ok=True)
s=(ROOT/'src/graph_route_cpu_vulkan/invocation.cc').read_text(encoding='utf8')
needle='''    if (pending != 0 && run.native_wait_completion == nullptr &&
        run.pipeline_error.ok() && !run.cancel.load(std::memory_order_acquire) &&
        !run.frontier.ready(PipelineLane::kNative)) {
      request_native_wait(run, native_stage_completion(run, run.pending_native[0]));
    }'''
replacement='''#if G09_COUNT_GUARDS || G09_NATIVE_WAIT_CONTROL
    // Diagnostic only. The resident pool job still starts/stops normally,
    // but cannot concurrently observe this handle while its pointer is null.
    if (pending == 1 && run.native_wait_completion == nullptr &&
        run.pipeline_error.ok() && !run.cancel.load(std::memory_order_acquire) &&
        !run.frontier.ready(PipelineLane::kNative)) {
#if G09_COUNT_GUARDS
      g09_guard_visits.fetch_add(1, std::memory_order_relaxed);
#endif
#if G09_NATIVE_WAIT_CONTROL
      const auto &completion = native_stage_completion(run, run.pending_native[0]);
      lock.unlock();
      const auto status = completion.wait();
      lock.lock();
      if (!status.ok()) run.pipeline_error.Update(status);
      continue; // Original poll/checked result/lease retirement remains.
#endif
    }
#endif
'''+needle
assert s.count(needle)==1
s=s.replace(needle,replacement)
counter='''namespace {
#if G09_COUNT_GUARDS
std::atomic<std::uint64_t> g09_guard_visits{0};
#endif
}
extern "C" __declspec(dllexport) std::uint64_t hyle_g09_guard_visits() noexcept {
#if G09_COUNT_GUARDS
  return g09_guard_visits.load(std::memory_order_relaxed);
#else
  return 0;
#endif
}

'''
s=s.replace('namespace hyle::graph::cpu_vulkan {',counter+'namespace hyle::graph::cpu_vulkan {',1)
(source/'invocation.cc').write_text(s,encoding='utf8')
(source/'original_invocation.cc').write_bytes((ROOT/'src/graph_route_cpu_vulkan/invocation.cc').read_bytes())
for p in ['facade.cc','facade_api.h']:(source/p).write_bytes((ROOT/'.scratch/g09-direct-latency'/p).read_bytes())
s=(source/'facade.cc').read_text(encoding='utf8')
s=s.replace('#include <hyle/graph/cpu.h>','#include <hyle/compute/backends/cpu.h>\n#include <hyle/compute/providers/native.h>\n#include <hyle/compute/prepared_operation.h>\n#include <ATen/Parallel.h>\n#include <mutex>')
s=s.replace('    HYLE_ASSIGN_OR_RETURN(cpu, g::cpu::create_context());','''    static std::once_flag cpu_runtime;
    std::call_once(cpu_runtime, [] { at::set_num_threads(1); at::set_num_interop_threads(1); });
    HYLE_ASSIGN_OR_RETURN(cpu, c::Context::create(c::cpu::device(), c::native::provider()));''')
s+='''
extern "C" G09_EXPORT const char *hyle_g09_state_resources(void *opaque) noexcept {
  static char text[2048];
  const auto &state = *static_cast<State *>(opaque);
  const auto &environment = state.native.environment();
  std::snprintf(text, sizeof(text),
    "{\\"cpu_provider\\":\\"explicit-native\\",\\"scheduler_workers\\":2,"
    "\\"pool_capacity\\":2,\\"pool_keepalive_seconds\\":10,\\"pool_live_threads\\":%u,"
    "\\"pool_retained_handles\\":%zu,\\"aten_intra_op\\":%d,\\"aten_inter_op\\":%d,"
    "\\"vulkan_device\\":\\"%s\\",\\"driver_version\\":%u,\\"vendor_id\\":%u}",
    state.native_wait_pool->live_threads(), state.native_wait_pool->retained_thread_handles(),
    static_cast<int>(at::get_num_threads()), static_cast<int>(at::get_num_interop_threads()),
    environment.device_name.c_str(), environment.driver_version, environment.vendor_id);
  return text;
}
'''
s=s.replace('cpu_value, builder.add(c::Unary{c::UnaryKind::kAbs}, xi)', 'cpu_value, builder.add(c::Binary{}, xi, xi)').replace('std::abs(input) - 1.25f : 1.25f - std::abs(input)','(input + input) - 1.25f : 1.25f - (input + input)')
s=s.replace('    oracle.assign(elements, 1.25f);', '#if G09_COUNT_GUARDS\n    {\n      const std::array binary_inputs{description, description};\n      const std::array binary_outputs{description};\n      auto added = c::prepare(cpu, c::Operation(c::Binary{}), binary_inputs, binary_outputs, m::system_resource());\n      if (!added) return added.error();\n      std::fprintf(stderr, "DIRECT CPU F32 ADD prepared\\n");\n    }\n#endif\n    oracle.assign(elements, 1.25f);')
(source/'facade.cc').write_text(s,encoding='utf8')
original=(ROOT/'.scratch/perf-review-2026-10-18/g09/source/measure.py').read_text(encoding='utf8')
a=original.index('def threads():');b=original.index('def measure(args):',a)
thread_code='''def threads():
    # Outside replay intervals; no monitoring thread. Times are 100 ns units.
    from ctypes import wintypes as W
    k=C.WinDLL('kernel32',use_last_error=True)
    class Entry(C.Structure):
        _fields_=[('dwSize',W.DWORD),('cntUsage',W.DWORD),('th32ThreadID',W.DWORD),
                  ('th32OwnerProcessID',W.DWORD),('tpBasePri',W.LONG),
                  ('tpDeltaPri',W.LONG),('dwFlags',W.DWORD)]
    k.CreateToolhelp32Snapshot.argtypes=[W.DWORD,W.DWORD];k.CreateToolhelp32Snapshot.restype=W.HANDLE
    k.Thread32First.argtypes=[W.HANDLE,C.POINTER(Entry)];k.Thread32Next.argtypes=[W.HANDLE,C.POINTER(Entry)]
    k.OpenThread.argtypes=[W.DWORD,W.BOOL,W.DWORD];k.OpenThread.restype=W.HANDLE
    k.GetThreadTimes.argtypes=[W.HANDLE,*([C.POINTER(C.c_uint64)]*4)]
    k.GetThreadDescription.argtypes=[W.HANDLE,C.POINTER(C.c_void_p)]
    k.CloseHandle.argtypes=[W.HANDLE];k.LocalFree.argtypes=[C.c_void_p]
    snap=k.CreateToolhelp32Snapshot(4,0)
    if snap==C.c_void_p(-1).value:raise C.WinError(C.get_last_error())
    row=Entry();row.dwSize=C.sizeof(row);rows=[]
    try:
        ready=k.Thread32First(snap,C.byref(row))
        while ready:
            if row.th32OwnerProcessID==os.getpid():
                h=k.OpenThread(0x0800,False,row.th32ThreadID)
                if h:
                    name=C.c_void_p();created=C.c_uint64();ended=C.c_uint64();kernel=C.c_uint64();user=C.c_uint64()
                    try:
                        text=''
                        if k.GetThreadDescription(h,C.byref(name))==0 and name:
                            text=C.wstring_at(name);k.LocalFree(name)
                        if not k.GetThreadTimes(h,C.byref(created),C.byref(ended),C.byref(kernel),C.byref(user)):
                            raise C.WinError(C.get_last_error())
                        rows.append({'tid':row.th32ThreadID,'name':text,'created_100ns':created.value,
                                     'user_100ns':user.value,'kernel_100ns':kernel.value})
                    finally:k.CloseHandle(h)
            ready=k.Thread32Next(snap,C.byref(row))
    finally:k.CloseHandle(snap)
    return rows

'''
s=original[:a]+thread_code+original[b:]
s=s.replace("directories.append(os.add_dll_directory(str(image.parent)))", "directories.append(os.add_dll_directory(str(image.parent)))\n        directories.append(os.add_dll_directory('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib'))")
s=s.replace("'2 Scheduler workers + original hyle-mlx owner; no extra wait pool or monitor thread'","'2 Scheduler workers + explicit lazy BlockingPool capacity2; same resident waiter startup/stop; driver/runtime threads observed separately'")
s=s.replace("'metal_environment': {k: os.environ.get(k) for k in ['MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']}","'vulkan_environment': {k: os.environ.get(k) for k in ['VK_INSTANCE_LAYERS','VK_LAYER_PATH','VK_LOADER_LAYERS_DISABLE','VK_ICD_FILENAMES']}")
s=s.replace("    image = args.image.resolve(strict=True)",'''    from ctypes import wintypes as W
    k=C.WinDLL('kernel32',use_last_error=True)
    k.GetCurrentProcess.restype=W.HANDLE
    k.SetProcessAffinityMask.argtypes=[W.HANDLE,C.c_size_t]
    if not k.SetProcessAffinityMask(k.GetCurrentProcess(),0x55):raise C.WinError(C.get_last_error())
    image = args.image.resolve(strict=True)''')
s=s.replace("    report['threads_initial'] = threads()",'''    report['process_affinity_mask']='0x55 (logical CPUs 0,2,4,6; no P/E claim)'
    resources=library.hyle_g09_state_resources
    resources.argtypes=[C.c_void_p];resources.restype=C.c_char_p
    report['threads_initial'] = threads()''')
s=s.replace("row['threads_after_create'] = threads()","row['resources_after_create'] = json.loads(resources(state))\n            row['threads_after_create'] = threads()")
s=s.replace("row['threads_before_timing'] = threads()","row['resources_before_timing'] = json.loads(resources(state))\n            row['threads_before_timing'] = threads()")
s=s.replace("row['threads_after_timing'] = threads()","row['threads_after_timing'] = threads()\n            row['resources_after_timing'] = json.loads(resources(state))")
s=s.replace('Original scalar check every slot; independent full 4M oracle before and after timed samples', 'Current explicit Native CPU Add(x,x) / Vulkan Neg / CPU Add; input4M and dependency shapes retained; exact modified-workload oracle before/after, scalar check timed; not old CPU Abs result')
(source/'measure.py').write_text(s,encoding='utf8');compile(s,'measure.py','exec')
identity={'source_files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/graph_route_vulkan/vulkan_lowering.cc',ROOT/'src/graph_route_vulkan/vulkan_batch.cc',ROOT/'src/graph_route_cpu_vulkan/compile.cc',ROOT/'src/graph_route_cpu_vulkan/invocation.cc']},'probe_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.is_file()}}
(HERE/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
print('Prepared',source)
