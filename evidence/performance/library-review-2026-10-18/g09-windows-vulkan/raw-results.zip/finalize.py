from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json,platform,re,subprocess,time,zipfile

ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text(encoding='utf8'))
processes=[]
for p in sorted(HERE.glob('formal-[0-9]*.json')):
    d=load(p);record={'file':p.name,'pid':d['pid'],'image_sha256':d['image_sha256'],'shapes':[]}
    assert d['result']=='COMPLETED_WITH_NUMERICAL_CHECKS'
    for row in d['shapes']:
        assert row['oracle']=='PASS_ALL_ELEMENTS_ALL_SLOTS_BEFORE_AND_AFTER'
        assert row['guard_before_timing']==row['guard_after_timing']==0
        assert len(row['warm_ns'])==31
        before={x['tid']:x for x in row['threads_before_timing']}
        deltas=[]
        for x in row['threads_after_timing']:
            y=before.get(x['tid'])
            if y and y['created_100ns']==x['created_100ns']:
                deltas.append({'tid':x['tid'],'name':x['name'],'created_100ns':x['created_100ns'],
                               'user_100ns':x['user_100ns']-y['user_100ns'],
                               'kernel_100ns':x['kernel_100ns']-y['kernel_100ns']})
        record['shapes'].append({'name':row['name'],'facts':row['facts'],'warm':row['warm'],
                                  'resources_before_timing':row['resources_before_timing'],
                                  'resources_after_timing':row['resources_after_timing'],
                                  'thread_count_before':len(before),'thread_count_after':len(row['threads_after_timing']),
                                  'thread_cpu_deltas_100ns_units':deltas})
    processes.append(record)
assert len(processes)==4
pairs=[]
for current,control in [(0,1),(3,2)]:
    for shape in range(2):
        c=processes[current]['shapes'][shape];n=processes[control]['shapes'][shape]
        pairs.append({'current':processes[current]['file'],'control':processes[control]['file'],
                      'shape':c['name'],'current_median_ns':c['warm']['median_ns'],
                      'control_median_ns':n['warm']['median_ns'],
                      'control_over_current':n['warm']['median_ns']/c['warm']['median_ns']})
smoke=[]
for p in sorted(HERE.glob('smoke-add-admitted-[01]-*.json')):
    d=load(p);smoke.append({'file':p.name,'result':d['result'],'shapes':[
        {'name':x['name'],'oracle':x['oracle'],'guard_hits_in_one_replay':x['guard_after_timing']-x['guard_before_timing']}
        for x in d['shapes']]})
assert len(smoke)==2

provenance=[]
for mode in ['smoke','formal']:
    for arm in ['current','control']:
        p=HERE/mode/('g09_'+arm+'.map');text=p.read_text(encoding='utf8',errors='replace')
        assert 'ggml-cpu' not in text.lower()
        selected=[x for x in text.splitlines() if any(key in x for key in
                  ['run_native_wait_job@','start_native_waiter@','stop_native_waiter@',
                   'wait_native_completion@','drive_native_lane@','drive_graph@',
                   'hyle_g09_facade_v1','hyle_g09_guard_visits','hyle_g09_state_resources'])]
        ggml=sorted({x.split()[-1] for x in text.splitlines() if 'ggml' in x and x.split()})
        provenance.append({'file':str(p.relative_to(HERE)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                           'selected_symbols':selected,'ggml_object_owners':ggml,'ggml_cpu_object_present':False})
(HERE/'link-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf8')
for name,file in [('fresh-vulkan_lowering.cc','src/graph_route_vulkan/vulkan_lowering.cc'),
                  ('fresh-vulkan_batch.cc','src/graph_route_vulkan/vulkan_batch.cc'),
                  ('fresh-hybrid_compile.cc','src/graph_route_cpu_vulkan/compile.cc'),
                  ('original-facade.cc','.scratch/g09-direct-latency/facade.cc')]:
    (HERE/'source'/name).write_bytes((ROOT/file).read_bytes())
a=(HERE/'source/original_invocation.cc').read_text(encoding='utf8').splitlines(keepends=True)
b=(HERE/'source/invocation.cc').read_text(encoding='utf8').splitlines(keepends=True)
(HERE/'observer-diagnostic.diff').write_text(''.join(difflib.unified_diff(a,b,fromfile='current-product-invocation.cc',tofile='private-diagnostic-invocation.cc')),encoding='utf8')
summary={
 'experiment':'Windows Vulkan Add(x,x)/Neg/Add constrained completion-observer diagnostic',
 'captured_utc':datetime.now(timezone.utc).isoformat(),
 'decision':'CURRENT_BLOCKINGPOOL_PATH_NOT_OBSERVED_SLOWER_IN_THIS_CONSTRAINED_CONTROL',
 'interpretation':'Current BlockingPool path is below the root-direct-wait control in both independent-case process medians. This does not establish statistical significance, equivalence, a production speedup or the old Abs G09 ranking.',
 'machine':{'platform':platform.platform(),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,compute_cap,driver_version,uuid','--format=csv,noheader'],text=True).strip(),
            'process_affinity':'0x55, logical CPUs 0,2,4,6; no P/E or physical-core inference',
            'latency_clock':vars(time.get_clock_info('perf_counter'))},
 'workload':{'input':'4194304 F32 values, original x[j]=(j%101-50)*0.125, residual1.25; one invocation slot.',
             'independent':'CPU Native Add(x,x) and resident Vulkan Neg(1.25), then CPU Native Add joining both. Exact oracle=(x+x)-1.25.',
             'serial':'CPU Native Add(x,x) -> Vulkan Neg -> CPU Native Add with residual1.25. Exact oracle=1.25-(x+x).',
             'scope_change':'Original Abs is replaced in both arms because explicit Native rejects dense F32 Abs. Native also rejects F32 Neg; ATen CPU deliberately declines dense basic math. This is a different current workload, not a repaired old Abs benchmark or a cross-platform rank.'},
 'boundary':{'timed':'Python ctypes replay: bind, prepare_replay, submit, checked wait and output scalar read/check, destroy every view/ResultLease/OwnedResult, then Scheduler.drain before return.',
             'excluded':'Cold runtime/Context/Graph preparation, first replay, 8 warmups, all-element oracles before/after, resource/thread snapshots, close/destroy and process-exit cleanup.',
             'control':'Only one pending original native Completion, no ready native stage and no pool-owned handle: root unlocks monitor and directly waits the same owner. Original pool job start/stop/destroy, leases, checked finish and retirement remain.',
             'control_limit':'Waiting on Scheduler root changes Scheduler availability. This is a same-owner/explicit-resource causal intervention, not a directly substitutable production optimization or theoretical minimum native cost.',
             'counters':'Smoke macros ON; formal macros OFF in both arms. The formal current code excludes the diagnostic conditional entirely. Serial does not enter the modified parallel-lane branch.'},
 'resources':{'explicit':'Both 2 Scheduler workers, BlockingPool cap2/keepalive10s, measured pool live1/retained handles1 throughout each timed block; ATen intra/inter-op1 set once cold and observed1/1. No extra observer thread.',
              'actual_os_threads':'First three formal processes have 19; last current process18. GetThreadDescription returned empty names. Full before/after/creation/CPU-time snapshots retained; extra thread role is unknown, not asserted to be a driver thread.',
              'cpu_time_limit':'GetThreadTimes values use 100 ns units but observed CPU accounting steps are coarse. These bracketed snapshots do not provide per-stage costs, instantaneous runnable-thread counts or latency timer resolution.'},
 'method':{'order':['current','control','control','current'],'formal_processes':4,'shapes_per_process':2,'samples_per_shape':31,'discarded_samples':0,'aa':'No additional A/A run.','numeric':'Both final smoke and all formal full exact all-element oracles pass before and after timing, plus every timed scalar check.'},
 'reuse':{'vulkan_cache':'.scratch/bench-api-runtime/vulkan/build (Release/static, native implementation cc unchanged since4fb1927f7)',
          'foundation_cache':'.scratch/build-compute-v2-dev/bin',
          'fresh':'vulkan_lowering.cc, vulkan_batch.cc, hybrid compile.cc, each-arm invocation.cc/facade.cc only.',
          'ggml':'Only locked GPU ggml456172 core used; no CPU ggml core/library linked. Native CPU provider has existing Torch imports; no Torch tensor math selected for F32 Add.',
          'limit':'Both share cached common foundation and native Vulkan libraries; not a complete current-HEAD rebuild. No new vendor, dependency download, SDK/runtime staging or copying.'},
 'setup_failures':[
    {'files':'smoke-0-current.*','cause':'Python DLL search omitted existing Torch CPU lib directory; no Context or replay created. Fixed with os.add_dll_directory, not DLL copying.'},
    {'files':'smoke-dll-search-0-current.*','cause':'Native dense F32 Abs Graph preparation declined.'},
    {'files':'smoke-aten-0-current.*','cause':'Explicit ATen CPU dense basic math Graph preparation declined by its edge-layout-only gate.'},
    {'files':'smoke-native-neg-0-current.*; smoke-direct-resource-0-current.*','cause':'Native F32 Neg is not retained; Direct cold prepare confirms it. No GPU replay/performance samples.'},
    {'files':'smoke-direct-admission-0-current.*; smoke-native-add-0-current.*','cause':'These ran the prior smoke DLL after intermediate compilation failed, so their repeated Neg decline is not a new candidate result. Excluded from final measurements.'}],
 'failure_source_retention':'Final source, original facade and generation scripts retained. Failed provider/operator choices are documented above; intermediate facade revisions and overwritten compile diagnostics were not independently frozen, so no exact historical failed-source hash is claimed.',
 'processes':processes,'paired_ratios':pairs,'smoke':smoke,
 'product_changes':0,'git_head_at_archive':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
(HERE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
files=[p for p in HERE.rglob('*') if p.is_file() and p.suffix in ['.json','.jsonl','.log','.py','.cc','.h','.diff'] and p.name not in ['archive-record.json','archive-members.json']]
members=[{'file':str(p.relative_to(HERE)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
(HERE/'archive-members.json').write_text(json.dumps(members,indent=2)+'\n',encoding='utf8');files.append(HERE/'archive-members.json')
archive=HERE/'raw-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,str(p.relative_to(HERE)))
record={'archive':str(archive.resolve()),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'contents':'All 4 formal process raw samples/snapshots, 2 accepted smoke/full oracles, failed setup logs, final/original source, generation/build/run commands, exact library/source/image hashes and extracted link provenance. No DLL/lib/exe/obj/SDK/full link maps.'}
(HERE/'archive-record.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(record));print(json.dumps(pairs))
