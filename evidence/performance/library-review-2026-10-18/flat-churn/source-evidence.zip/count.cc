#include "hyle/container/flat_hash_map.h"
#include <cstdint>
#include <cstdio>
#include <vector>

struct CountHash {
  std::size_t *calls;
  std::uint64_t operator()(std::uint64_t key) const noexcept {
    ++*calls;
    return hyle::container::Hash<std::uint64_t>{}(key);
  }
};

int main() {
  for (const bool prepare : {false, true}) {
  for (const std::size_t capacity : {1024u, 8192u}) {
    for (const std::size_t delta : {0u, 1u, 16u, 128u}) {
      const auto live = capacity - capacity / 8 - delta;
      std::size_t calls = 0, rehashes = 0, rehashed_keys = 0;
      hyle::container::FlatHashMap<std::uint64_t, std::uint64_t, CountHash>
          map(hyle::mem::SystemAllocator{}, CountHash{&calls});
      map.reserve(live);
      if (map.capacity() != capacity) return 2;
      for (std::uint64_t i = 0; i < live; ++i)
        if (!map.insert(i, i ^ UINT64_C(0x579a))) return 3;
      const auto initial_calls = calls;
      constexpr std::size_t rounds = 32768;
      for (std::uint64_t i = 0; i < rounds; ++i) {
        if (!map.erase(i)) return 4;
        const auto before = calls;
        if (prepare && !map.try_prepare_insert()) return 8;
        if (!map.insert(i + live, (i + live) ^ UINT64_C(0x579a))) return 5;
        const auto insert_calls = calls - before;
        if (insert_calls > 1) {
          ++rehashes;
          rehashed_keys += insert_calls - 1;
        }
        if (map.size() != live) return 6;
      }
      for (std::uint64_t i = rounds; i < rounds + live; ++i) {
        const auto *value = map.find(i);
        if (!value || *value != (i ^ UINT64_C(0x579a))) return 7;
      }
      std::printf("{\"prepare\":%s,\"initial_capacity\":%zu,\"live\":%zu,\"rounds\":%zu,"
          "\"rehashes\":%zu,\"rehashed_keys\":%zu,\"final_capacity\":%zu,"
          "\"warm_fill_hash_calls\":%zu,\"oracle\":true}\n",
          prepare ? "true" : "false", capacity, live, rounds, rehashes, rehashed_keys, map.capacity(), initial_calls);
    }
  }
  }
}
