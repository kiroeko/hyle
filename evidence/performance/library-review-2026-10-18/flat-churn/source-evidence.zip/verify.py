from pathlib import Path
import json, subprocess, sys
exec(Path(__file__).with_name('run.py').read_text().split('variant=sys.argv')[0])
gtest=Path(__import__('os').environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
commands=[]
objects=[]
for file in ['tests/container/flat_hash_map_test.cc','tests/container_concurrent/concurrent_hash_map_test.cc']:
 src=ROOT/file;obj=OUT/(src.stem+'.obj');objects.append(str(obj))
 commands.append((src.stem,[cl,*flags,'/I'+str(ROOT/'include'),'/external:I'+str(gtest),'/external:W0','/Fo'+str(obj),str(src)]))
commands.extend([
 ('tests-link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console','/out:'+str(OUT/'tests.exe'),*objects,*libs,str(BUILD/'lib/gtest_main.lib'),str(BUILD/'lib/gtest.lib')]),
 ('tests',[str(OUT/'tests.exe')])])
for tag,cmd in commands:
 p=subprocess.run(cmd,cwd=BUILD,env=env,capture_output=True,timeout=120)
 (OUT/(tag+'-command.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode},indent=2))
 (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
 print(tag,p.returncode,flush=True)
 if p.returncode: print(p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'));sys.exit(p.returncode)
 if tag=='tests': print(p.stdout.decode()[-1800:])
