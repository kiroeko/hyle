from pathlib import Path
import json, subprocess, sys, hashlib
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
BUILD=ROOT/'.scratch/build-compute-v2-dev'
cache=read_cache(BUILD);env=windows_compiler_environment(cache);env['VSLANG']='1033'
cl=cache['CMAKE_CXX_COMPILER'];link=str(Path(cl).with_name('link.exe'))
flags=['/nologo','/c','/DWIN32','/D_WINDOWS','/EHsc','/O2','/Ob2','/DNDEBUG',
 '/std:c++latest','/MD','/W4','/permissive-','/wd4324','/WX','/Zc:__cplusplus',
 '/utf-8','/Zc:preprocessor','/DHYLE_STATIC','/DNOMINMAX','/DWIN32_LEAN_AND_MEAN']
libs=[str(BUILD/'bin'/(name+'.lib')) for name in ['hyle_container','hyle_mem','hyle_platform','hyle_error','mimalloc_static']]
libs+=['bcrypt.lib','PowrProf.lib','advapi32.lib','Synchronization.lib']
variant=sys.argv[1] if len(sys.argv)>1 else 'baseline'
snapshot=OUT/variant/'include/hyle/container/detail/flat_hash_table.h'
snapshot.parent.mkdir(parents=True,exist_ok=True)
if not snapshot.exists():
 snapshot.write_bytes((ROOT/'include/hyle/container/detail/flat_hash_table.h').read_bytes())
for step,cmd in [('compile',[cl,*flags,'/I'+str(OUT/variant/'include'),'/I'+str(ROOT/'include'),'/Fo'+str(OUT/(variant+'.obj')),str(OUT/'count.cc')]),
 ('link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console','/out:'+str(OUT/(variant+'.exe')),str(OUT/(variant+'.obj')),*libs]),
 ('count',[str(OUT/(variant+'.exe'))])]:
 p=subprocess.run(cmd,cwd=BUILD,env=env,capture_output=True,timeout=120)
 (OUT/(variant+'-'+step+'-command.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode},indent=2))
 (OUT/(variant+'-'+step+'.stdout.txt')).write_bytes(p.stdout)
 (OUT/(variant+'-'+step+'.stderr.txt')).write_bytes(p.stderr)
 print(step,p.returncode,flush=True)
 if p.returncode: print(p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'));sys.exit(p.returncode)
 if step=='count': print(p.stdout.decode())
(OUT/(variant+'-identity.json')).write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [snapshot,OUT/'count.cc',OUT/(variant+'.exe'),*[Path(x) for x in libs if Path(x).is_file()]]},indent=2))
