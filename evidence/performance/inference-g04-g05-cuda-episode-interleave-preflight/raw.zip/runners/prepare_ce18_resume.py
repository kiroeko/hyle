from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'ce18_cuda_interleave_diagnostic_wsl.py').read_text(encoding='utf-8')
s=s.replace('out.mkdir(exist_ok=False)','assert out.is_dir()')
start=s.index('record=dict(');end=s.index('\n',start)
s=s[:start]+"record=json.loads((out/'result.json').read_text());assert record['state']=='TERMINAL_FAIL' and len(record['stages'])==1 and record['stages'][0]['exit_code']==1\nrecord['prior_compile_source_sha256']=hashlib.sha256((out/'episode.cc').read_bytes()).hexdigest()"+s[end:]
s=s.replace("(out/'runner.py')","(out/'runner-resume.py')")
s=s.replace("text=(source/name).read_text()","text='#include <iostream>\\n'+(source/name).read_text()")
s=s.replace("run('compile',args)","run('compile-resume',args)")
s=s.replace("record.update(original_benchmark_sha256=", "assert all(sha(Path(x['path']))==x['sha256'] for x in record['reused_objects'])\nrecord.update(original_benchmark_sha256=")
(p/'ce18_cuda_interleave_resume_wsl.py').write_text(s,encoding='utf-8')
