from pathlib import Path
import hashlib,json,re,shutil,zipfile
p=Path('/root/hyle-scratch/compute-unified/ce18-cuda-interleave-diagnostic-1')
root=Path('/mnt/c/public/project-hyle/hyle')
dest=root/'evidence/performance/inference-g04-g05-cuda-episode-interleave-preflight'
dest.mkdir(exist_ok=False)
r=json.loads((p/'result.json').read_text());assert r['state']=='TERMINAL_DIAGNOSTIC_ONLY' and len(r['runs'])==4
assert r['stages'][0]['exit_code']==1 and all(x['exit_code']==0 for x in r['stages'][1:])
for row in r['runs']:
 assert len(row['ratios'])==3 and all(1/1.05<=v<=1.05 for v in row['ratios'].values())
 text=(p/(row['stage']+'.log')).read_text()
 groups=re.findall(r'# CUDA_EPISODE_GROUP side=([01]) group=(\d+) count=(\d+) seconds=([0-9.eE+-]+)',text)
 assert len(groups)==96 and all(int(n)==2048 and float(s)>0 for _,_,n,s in groups)
 for first in range(0,96,32):assert {(int(s),int(g)) for s,g,_,_ in groups[first:first+32]}=={(s,g) for s in (0,1) for g in range(16)}
with zipfile.ZipFile(p/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(p.iterdir()):
  if f.is_file() and f.name not in ('raw.zip','episode','episode.o','episode.d'):z.write(f,f.name)
 for name in ('prepare_ce18.py','prepare_ce18_resume.py','ce18_cuda_interleave_diagnostic_wsl.py','ce18_cuda_interleave_resume_wsl.py','seal_ce18.py'):
  z.write(root/'.scratch/inference-gaps/g04-g05'/name,'runners/'+name)
shutil.copyfile(p/'raw.zip',dest/'raw.zip')
receipt=dict(kind='G04_G05_CUDA_EPISODE_INTERLEAVE_FINITE_PREFLIGHT',verdict='PASS_FOUR_CONTROL_PREFLIGHT_ONLY',
 product_candidate='982676cb05a6e6244e66e0a596347aa96043617b',identity=r['identity'],sampling_policy=r['sampling_policy'],
 binary_sha256=r['binary_sha256'],runs=r['runs'],stages=[{k:s[k] for k in ('stage','elapsed_seconds','exit_code')} for s in r['stages']],
 episode_count=4*3*2*16*2048,groups_per_side=16,pairs_per_group=2048,
 measured_worker_seconds=sum(s['elapsed_seconds'] for s in r['stages']),
 conclusion='All12 same-implementation marginal operation-rate ratios .980652..1.017490 meet original5%band with every elapsed tail included. Finite evidence supports freezing the workload-local adapter and declaring original16-route qualification, not promoting four controls into A/A or product performance PASS.',
 limits=['Only placement1/peer-allocation-first, both original execution orders and both same-implementation routes',
 'Original3 shapes, two slots,4 independent oracle replays,full update/run/wait/output release preserved',
 'Initial scratch CXX compilation failed from missing iostream9.628s; original failure/log/source hash preserved, include fixed in same tree; no SDK/native/product rebuild',
 'Group sums/counts retained; original stats and mean-episode estimand, no trimmed samples or copied favorable single-episode medians',
 'Old4ms/40ms/200ms/500ms and16x128 group instability retained. Host sanitizer/SDK/native qualification not rerun; private pool upper UNKNOWN'],
 raw_zip_sha256=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'path':str(dest),'elapsed_seconds':receipt['measured_worker_seconds'],'zip_bytes':(dest/'raw.zip').stat().st_size}))
