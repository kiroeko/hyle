from pathlib import Path
p=Path(__file__).resolve().parent
original=(p/'ce17_cuda_episode_diagnostic_wsl.py').read_text(encoding='utf-8')
prefix=original[:original.index("text=(source/name).read_text()")]
prefix=prefix.replace("ce17-cuda-episode-diagnostic-1","ce18-cuda-interleave-diagnostic-1")
prefix=prefix.replace("Finite complete-episode mechanism diagnostic; no product verdict or A/A qualification.","Finite complete-episode interleave+arithmetic-group diagnostic; no product or A/A qualification.")
body=r'''text=(source/name).read_text()
marker='struct Harness {'
assert text.count(marker)==1
helper=r"""
template<class A,class B>
nb::CompareResult episode_compare(nb::Bench&bench,const char*an,A&&a,const char*bn,B&&b){
  constexpr unsigned groups=16,pairs=2048;
  // One complete episode per measured micro epoch. The original nanobench
  // balanced random order is reused; no sample is discarded or normalized.
  const auto micro=bench.output(nullptr).epochs(groups*pairs).epochIterations(1).compare(an,a,bn,b);
  std::vector<nb::Result> results;results.reserve(2);
  for(unsigned side=0;side<2;++side){
    auto config=micro[side].result.config();config.mNumEpochs=groups;
    config.mEpochIterations=pairs;results.emplace_back(config);
    if(micro[side].result.size()!=groups*pairs)std::abort();
    for(unsigned group=0;group<groups;++group){
      double seconds=0;
      for(unsigned pair=0;pair<pairs;++pair){
        const auto index=group*pairs+pair;
        if(micro[side].result.get(index,nb::Result::Measure::iterations)!=1)std::abort();
        seconds+=micro[side].result.get(index,nb::Result::Measure::elapsed);
      }
      std::printf("# CUDA_EPISODE_GROUP side=%u group=%u count=%u seconds=%.17g\n",side,group,pairs,seconds);
      results[side].add(std::chrono::duration_cast<nb::Clock::duration>(std::chrono::duration<double>(seconds)),pairs,nb::detail::performanceCounters());
    }
  }
  const auto ratios=nb::detail::pairedLogRatios(results[0],results[1]);
  const auto ci=nb::detail::medianInterval(ratios,nb::detail::bonferroniConfidence(1));
  std::vector<nb::CompareResult::Entry> entries;
  entries.emplace_back(an,std::move(results[0]),1.,1.,1.,0);
  entries.emplace_back(bn,std::move(results[1]),std::exp(nb::detail::medianOf(ratios)),std::exp(ci.first),std::exp(ci.second),nb::detail::countTiedRounds(ratios));
  nb::CompareResult result(std::move(entries),groups);std::cout<<result;return result;
}
"""
text=text.replace(marker,helper+marker)
text=text.replace('(void)bench.compare(', '(void)episode_compare(bench,')
assert text.count('episode_compare(bench,')==2
cpp=out/'episode.cc';obj=out/'episode.o';binary=out/'episode';cpp.write_text(text)
args=list(compile_args);args[args.index('-o')+1]=str(obj)
for switch,value in [('-MF',str(out/'episode.d')),('-MT',str(obj))]:
 if switch in args:args[args.index(switch)+1]=value
args[next(i for i,a in enumerate(args) if a.endswith('cuda_encoded_page_bench.cc'))]=str(cpp)
args[1:1]=['-iquote',str((source/name).parent)]
run('compile',args)
args=[str(obj) if a==row['output'] else a for a in link];args[args.index('-o')+1]=str(binary)
for i,a in enumerate(args):
 for prefix in ('-Wl,--dependency-file=','-Wl,-Map='):
  if a.startswith(prefix):args[i]=prefix+str(out/'episode-link.map')
run('link',args)
record['binary_sha256']=sha(binary)
policy=expected_child_policy(get_machine_profile(load_registry(),'W1-WSL'));record['sampling_policy']=policy;save()
from hyle_perf.nanobench import parse_nanobench
with _apply_sampling_policy(policy):
 for route in ('native','selected'):
  for peer_first in (False,True):
   clean={k:v for k,v in env.items() if k not in PERF_ENVIRONMENT_BLOCKLIST and not any(k.startswith(p) for p in PERF_ENVIRONMENT_PREFIXES)}
   clean.update(PERF_ENVIRONMENT_FIXED)
   clean.update(HYLE_BENCH_AA_ROUTE=route,HYLE_PERF_RUN_NONCE=uuid.uuid4().hex,HYLE_BENCH_PEER_ALLOCATION_FIRST='1')
   if peer_first:clean['HYLE_BENCH_RIVAL_FIRST']='1'
   stage=route+('-peer-first' if peer_first else '-candidate-first')
   run(stage,[str(binary)],clean)
   log=(out/(stage+'.log')).read_text()
   measured=list(parse_nanobench(log).values());ratios={}
   for title in dict.fromkeys(r.title for r in measured):
    d={r.variant:r.operations_per_second for r in measured if r.title==title}
    ratios[title]=d['HYLE CUDA encoded paged']/d['Original CUDA cold-expanded immutable lifecycle']
   assert len(ratios)==3
   record['runs'].append(dict(stage=stage,route=route,peer_first=peer_first,ratios=ratios));save()
for p in reuse:assert sha(p)==next(x['sha256'] for x in record['reused_objects'] if x['path']==str(p))
record['state']='TERMINAL_DIAGNOSTIC_ONLY';record.pop('pid',None);save();print(json.dumps(record['runs']),flush=True)
'''
(p/'ce18_cuda_interleave_diagnostic_wsl.py').write_text(prefix+body,encoding='utf-8')
print('prepared independent CE18 runner')
