# Equivalent reproduction command. Original artifact/output paths are retained;
# the shared instrument refuses any nonempty build/output directory.
param([ValidateSet('compute','graph')][string]$Mode,
      [Parameter(Mandatory=$true)][string]$Build,
      [Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
if ((git rev-parse HEAD) -ne 'a677565959ea5534c5aca4ce90b41d1740a4d1a5') {
  throw 'This recipe requires the original immutable candidate checkout'
}
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
python scripts/hyle-perf.py qualify-platform --source C:/public/project-hyle/hyle `
  --contract "bench/contracts/$Mode-cuda-ffn-p1-v2.json" --machine W1-WIN `
  --peer sglang-precise=C:/public/project-hyle/sglang --build $Build --output $Output
if ($LASTEXITCODE -ne 0) { throw 'qualification failed; retain output and stop' }
