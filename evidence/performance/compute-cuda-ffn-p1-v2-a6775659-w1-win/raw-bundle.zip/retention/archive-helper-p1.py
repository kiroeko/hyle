from pathlib import Path
from collections import Counter
import hashlib
import json
import zipfile

root = Path(__file__).parent
repo = Path('C:/public/project-hyle/hyle')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for mode in ('compute', 'graph'):
    source = root / f'p1-{mode}-helper'
    manifest = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))
    summary = json.loads((source / 'summary.json').read_text(encoding='utf-8'))
    assert manifest['qualification'] == 'QUALIFIED'
    assert all(row['gate'] == 'PASS' for row in manifest['controls'])
    assert all(row['gate'] == 'PASS' for row in manifest['validator_results'])
    assert all(row['combined_noninferiority_gate'] == 'PASS' for row in summary['workloads'])
    target = repo / f'evidence/performance/{mode}-cuda-ffn-p1-v2-a6775659-w1-win'
    target.mkdir(parents=True, exist_ok=False)
    for name in ('contract-lock.json', 'controls.json', 'manifest.json', 'summary.json'):
        (target / name).write_text((source / name).read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
    (target / 'verify.json').write_text((root / f'p1-{mode}-helper-verify.json').read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
    table = []
    directions = {}
    for workload in summary['workloads']:
        estimates = [row['estimate'] for row in workload['strata']]
        values = [row['median_advantage_ratio'] for row in estimates]
        intervals = [row['confidence_interval'] for row in estimates]
        counts = Counter('WIN' if low > 1 else 'LOSS' if high < 1 else 'INCONCLUSIVE' for low, high in intervals)
        directions[workload['id']] = dict(counts)
        table.append(f"| {workload['id']} | {min(values):.6f}–{max(values):.6f} | "
                     f"{min(row[0] for row in intervals):.6f}–{max(row[1] for row in intervals):.6f} | "
                     f"{counts['WIN']} WIN / {counts['LOSS']} LOSS / {counts['INCONCLUSIVE']} INCONCLUSIVE | PASS |")
    (target / 'direction.json').write_text(json.dumps(directions, indent=2) + '\n', encoding='utf-8', newline='\n')
    kind = 'Direct' if mode == 'compute' else 'captured Graph'
    readme = f'''# R4 CUDA {kind} 完整 FFN 基线比较

不可变候选 `a677565959ea5534c5aca4ce90b41d1740a4d1a5`，W1-WIN RTX 4070 / SM89、
driver 610.62、CUDA Toolkit 13.3.73、MSVC 19.50，engineering 身份。
合同 `{mode}-cuda-ffn-p1-v2`，native-runtime-pair：caller CPU2，process mask0x14，
AboveNormal；两个不同物理 P 核，SDK helpers 原生管理。运行前真实 DLL 邻置。

两侧都是 HYLE 的完整资源/完成/失败合同，固定 Marlin group128 W4A16 与 cuBLASLt，
仅激活分别为 HYLE scalar 与 SGLang 06992c92 precise vector。没有快数学或额外 FP16 中间舍入。
两个 shape、两个 placement、正反执行/分配顺序；各 stratum n=15 即裁决，没有启动 n=31。
同 workload A/A、五项控制、build/artifact 验证、完整 raw replay 都 PASS；5% 非劣门 PASS。

## 方向与限制

ratio>1 有利于 HYLE 激活。以下方向按每个 stratum 的 CI 与1比较，保留小幅 LOSS；
仪器原始 5% practical PARITY 不能解释为严格等速或 HYLE 胜出。

| Workload | paired median ratio 范围 | 各分层 CI 外界 | 分层严格方向 | 5% NI |
|---|---|---|---|---|
''' + '\n'.join(table) + f'''

CI 外界是八个区间的最小/最大端点，不是另一个聚合置信区间。完整结果见 summary.json。
没有证据签 HYLE 完整链优势；默认实现仍须按主卡完成选择/接入。此处不是最终路线 CLOSED，
不是模型吞吐，也不外推其它 GPU/driver/toolkit/dtype/shape。

## 保留

raw-bundle.zip 保留全部原始输出、A/A receipt、control、manifest 和采集 recipe。
可读 JSON 副本仅规范 LF；原引用路径及结果不变。原 output 为 `{source.as_posix()}`，
build 为 `C:/hv4{'d' if mode == 'compute' else 'g'}p2`，实际 artifact 继续保留；不伪称脱离这些
文件也已取得永久 Formal 资格。sha256.json 记录归档身份。
'''
    (target / 'README.md').write_text(readme, encoding='utf-8', newline='\n')
    with zipfile.ZipFile(target / 'raw-bundle.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(source).as_posix())
        for path in (root / f'p1-{mode}-helper-console.log', root / f'p1-{mode}-helper-verify.json', Path(__file__)):
            archive.write(path, 'retention/' + path.name)
    hashes = {path.name: digest(path) for path in sorted(target.iterdir()) if path.is_file()}
    (target / 'sha256.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'evidence': str(target), 'directions': directions}))
