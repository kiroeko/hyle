from pathlib import Path
import argparse,os,signal,subprocess,time
r=Path('/Users/kiro/hyle-verify/r5-apple-20260917')
s=r/'candidate-1636365b'
d=r/'selected-final'
parser=argparse.ArgumentParser()
parser.add_argument('--mode',choices=('compute','graph'),required=True)
parser.add_argument('--natural',action='store_true')
args=parser.parse_args()
env=os.environ.copy()
env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env['MACOSX_DEPLOYMENT_TARGET']='14.4'
env['CMAKE_GENERATOR']='Ninja'
env['CMAKE_BUILD_PARALLEL_LEVEL']='2'
env['CTEST_PARALLEL_LEVEL']='1'
def run(command,log,seconds):
    print('RUN '+str(log),flush=True)
    assert not log.exists(),'previous finite attempt exists; inspect before resuming'
    begin=time.monotonic()
    with log.open('w') as f:
        p=subprocess.Popen([str(x) for x in command],cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGTERM)
            try: p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL)
                p.wait()
            raise RuntimeError('finite process deadline; retain raw output and inspect owned sampling/validation leases')
    print('DONE '+str(log)+' rc='+str(code)+' seconds='+str(round(time.monotonic()-begin,2)),flush=True)
    print(log.read_text()[-7000:],flush=True)
    if code: raise SystemExit(code)
if args.natural:
    builds=list((d/args.mode).glob('*/p1-build'))
    assert len(builds)==1,builds
    b=builds[0]
    run(['cmake','--build',b,'--parallel','2','--target',f'hyle_{args.mode}_apple_native_cost_bench'],
        d/(args.mode+'-natural-build.log'),180)
    run(['/usr/bin/python3',r/'apple-native-cost-diagnostic.py','--mode',args.mode,'--build',b],
        d/(args.mode+'-natural-run.log'),600)
else:
    run(['/usr/bin/python3','scripts/validation-select.py','run','--base','6f3ff7ca',
        '--candidate','1636365bbe47779de24e84d7c7d1ed8088fe1af2','--context',d/'context.json',
        '--p1-card',d/(args.mode+'-p1-card.json'),'--scratch',d/args.mode,'--cache',d/'receipts',
        '--output',d/(args.mode+'-result.json')],d/(args.mode+'-run.log'),1800)
