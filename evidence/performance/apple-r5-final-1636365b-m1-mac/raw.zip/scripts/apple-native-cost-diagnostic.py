"""Finite NATURAL_ROUTE diagnosis via existing HYLE collection/statistics APIs."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,statistics,subprocess,sys,time
TASK=Path('/Users/kiro/hyle-verify/r5-apple-20260917')
ROOT=TASK/'candidate-1636365b'
EXPECTED='1636365bbe47779de24e84d7c7d1ed8088fe1af2'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_perf import runner,stats
from hyle_perf.machine import (load_registry,get_machine_profile,probe_machine,
    evaluate_machine_profile,expected_child_policy,sampling_mutex,applied_macos_qos)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('compute','graph'),required=True)
    parser.add_argument('--build',type=Path,required=True)
    args=parser.parse_args()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==EXPECTED
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
    assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
    output=TASK/('natural-cost-'+args.mode+'-1636365b')
    output.mkdir(exist_ok=False)
    raw=output/'raw'
    raw.mkdir()
    contract=json.loads((ROOT/f'bench/contracts/{args.mode}-apple-ffn-p1-v1.json').read_text())
    contract['id']=args.mode+'-apple-native-boundary-diagnostic'
    contract['claim']='NATURAL_ROUTE / NOT_COMPARABLE: full MLX math; different admission, owner thread, close/cancel and result services. No NI or algorithm ranking.'
    contract['strata']=[x for x in contract['strata'] if x['target_variant']=='primary']
    ids=[x['id'] for x in contract['strata']]
    contract['controls']=[]
    contract['experiment']['sample_schedule']=[15]
    contract['peers']=[{'id':'raw-native','revision':'1f8e74e3f12f31365464a6867c6579f0e9b29d85',
        'configuration':{'role':'Caller-thread native compiled MLX region, actual checked synchronization and native arrays.'}}]
    for w in contract['workloads']:
        w['pair']['peer']=w['pair']['peer'].replace('MLX lifecycle ','Raw MLX ')
        w.update(required_strata=ids,required_controls=[],comparability='NOT_COMPARABLE',
                 gate_role='diagnostic',peer_id='raw-native')
        w['ownership_topology']['peer']='Caller-thread MLX stream, two resident inputs and native result slots; no public async admission, cancellation, close or result lease services.'
        w['ownership_topology']['equivalence']='Same full math, storage, precision and checked completion; deliberately different ownership/service boundary.'
    ext=contract['extensions']['runner']
    ext['validators']=[]
    ext.pop('control_executable',None)
    ext['executables']=[x for x in ext['executables'] if x['target_variant']=='primary']
    exe=ext['executables'][0]
    exe['id']=args.mode+'-apple-native-boundary'
    exe['stem']=f'hyle_{args.mode}_apple_native_cost_bench'
    exe['target']=exe['stem']
    write(output/'diagnostic-input.json',contract)
    target=args.build/'bin'/exe['stem']
    ready=args.build/'bin'/f'hyle_apple_{args.mode}_aa.ready'
    assert ready.read_text().split()[0]=='PASS'
    profile=get_machine_profile(load_registry(),'M1-MAC')
    before=probe_machine(paths=[('build',args.build)],expected_qos='interactive')
    gate=evaluate_machine_profile(profile,before,role='engineering')
    assert gate['gate']=='PASS',gate
    policy=expected_child_policy(profile,probe=before,sampling_topology='single-logical-cpu')
    spec=importlib.util.spec_from_file_location('apple_aa',ROOT/'bench/compute_route_apple/validate_aa.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    identity={'candidate':EXPECTED,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),
        'classification':'NATURAL_ROUTE / NOT_COMPARABLE','executable':str(target),'executable_sha256':sha(target),
        'script_sha256':sha(Path(__file__)),'input_sha256':sha(output/'diagnostic-input.json'),
        'cache_sha256':sha(args.build/'CMakeCache.txt'),'native_reference':module.reference_identity(args.build),
        'machine_gate':gate,'probe_before':before,'profile':profile,'policy':policy,
        'sample_budget':'four order strata x 15 independent processes; M1/M16 per process; no escalation'}
    with sampling_mutex(profile) as lease:
        identity['sampling_mutex']=lease.manifest_record()
        write(output/'identity.json',identity)
        env=runner._child_environment(ext['controlled_environment'],{'HYLE_BENCH_VERIFY_ONLY':'1'},profile,policy)
        with runner._apply_sampling_policy(policy):
            check=subprocess.run([str(target)],env=env,capture_output=True,timeout=120)
        (output/'oracle.log').write_bytes(check.stdout+check.stderr)
        assert check.returncode==0,check.returncode
        begin=time.monotonic()
        with runner._apply_sampling_policy(policy):
            observations,paths=runner._collect_product_observations(contract,ext,{exe['id']:target},
                profile,policy,runs=15,creationflags=runner._creation_flags(policy),raw_directory=raw)
        write(output/'observations.json',[x.to_dict() for x in observations])
        summaries=[]
        for w in contract['workloads']:
            for stratum in ids:
                points=[x for x in observations if x.workload_id==w['id'] and x.stratum_id==stratum]
                assert len(points)==15
                summaries.append({'workload':w['id'],'stratum':stratum,
                    'ratio':stats.process_median_estimate(x.advantage_ratio for x in points).to_dict(),
                    'public_median_us':statistics.median(1e6/x.candidate_value for x in points),
                    'native_median_us':statistics.median(1e6/x.peer_value for x in points),
                    'paired_extra_median_us':statistics.median(1e6/x.candidate_value-1e6/x.peer_value for x in points)})
        after=probe_machine(paths=[('build',args.build)],expected_qos='interactive')
        after_gate=evaluate_machine_profile(profile,after,role='engineering')
        assert after_gate['gate']=='PASS',after_gate
        assert sha(target)==identity['executable_sha256']
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
        write(output/'summary.json',{'collection':'PASS','classification':'NATURAL_ROUTE / NOT_COMPARABLE',
            'ranking':None,'noninferiority_gate':None,'sample_escalation':False,'strata':summaries,
            'wall_seconds':time.monotonic()-begin,'probe_after':after,'machine_gate_after':after_gate,
            'raw_sha256':{p.name:sha(p) for p in paths}})
    print(json.dumps({'mode':args.mode,'collection':'PASS','processes':len(paths),'strata':summaries}),flush=True)
if __name__=='__main__':
    with applied_macos_qos('interactive'): main()
