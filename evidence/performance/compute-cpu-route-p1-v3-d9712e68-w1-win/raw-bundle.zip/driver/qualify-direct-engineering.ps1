. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:HYLE_BENCH_VENDOR_DIR = 'C:/public/project-hyle'
python -X utf8 scripts/hyle-perf.py qualify-platform --contract bench/contracts/compute-cpu-route-p1-v3.json --machine W1-WIN --peer hyle-native=C:/hyle-scratch/r3-cpu-20260916/candidate-d9712e68 --peer onednn=C:/hyle-scratch/onednn-71094df45190 --source C:/hyle-scratch/r3-cpu-20260916/candidate-d9712e68 --build C:/hyle-scratch/r3-cpu-20260916/p1-direct-engineering-build --output C:/hyle-scratch/r3-cpu-20260916/p1-direct-engineering *> C:/hyle-scratch/r3-cpu-20260916/p1-direct-engineering-run.log
$r3Exit = $LASTEXITCODE
Get-Content C:/hyle-scratch/r3-cpu-20260916/p1-direct-engineering-run.log -Tail 35
exit $r3Exit
