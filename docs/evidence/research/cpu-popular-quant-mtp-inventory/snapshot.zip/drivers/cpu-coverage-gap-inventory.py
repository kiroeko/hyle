from pathlib import Path
import concurrent.futures,datetime,json,urllib.request
repo=Path.cwd();out=repo/'.scratch/validation/cpu-coverage-gap-inventory';out.mkdir(parents=True,exist_ok=True)
names=['unsloth/Qwen3.5-2B-GGUF','unsloth/Qwen3.8-27B-GGUF','unsloth/Qwen3.8-2.4T-A95B-GGUF','unsloth/Kimi-K3-GGUF','unsloth/GLM-5.3-GGUF','unsloth/GLM-5.3-Flash-GGUF','unsloth/DeepSeek-V4-Pro-0813-GGUF','unsloth/DeepSeek-V4-Flash-0731-GGUF','deepseek-ai/DeepSeek-V4-Pro-0813','deepseek-ai/DeepSeek-V4-Flash-0731']
def read(name):
 url='https://huggingface.co/api/models/'+name
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'HYLE-CPU-coverage-audit'}),timeout=20) as response:raw=response.read()
  j=json.loads(raw);(out/(name.replace('/','--')+'.json')).write_bytes(raw)
  files=[f['rfilename'] for f in j.get('siblings',[])];gguf=[f for f in files if f.endswith('.gguf') and not f.rsplit('/',1)[-1].lower().startswith('mmproj')]
  return dict(repository=name,url=url,revision=j.get('sha'),downloads=j.get('downloads'),last_modified=j.get('lastModified'),gguf_files=gguf,source_files=[f for f in files if f.endswith('.py') or f.endswith('config.json') or f.endswith('safetensors.index.json')])
 except Exception as e:return dict(repository=name,url=url,error=type(e).__name__+': '+str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(read,names))
result=dict(observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='public repository metadata only; no weight payload downloaded; downloads are repository-level, not per-variant popularity',repositories=rows)
(out/'inventory.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for r in rows:
 print(r['repository'],r.get('revision'),len(r.get('gguf_files',[])),r.get('error',''))
 if r.get('gguf_files'):
  print('folders',sorted(set(f.split('/')[0] for f in r['gguf_files'] if '/' in f)))
  print('sidecars',[f for f in r['gguf_files'] if 'mtp' in f.lower() or 'dspark' in f.lower()])
 print('sources',r.get('source_files',[])[:14])
