from pathlib import Path
import concurrent.futures,hashlib,json,urllib.request
out=Path('.scratch/validation/cpu-coverage-gap-inventory');j=json.loads((out/'inventory.json').read_text());jobs=[]
for r in j['repositories']:
 if r['repository'].startswith('deepseek-ai/'):
  for name in ('config.json','inference/model.py'):
   jobs.append((r['repository'].replace('/','--')+'--'+name.replace('/','--'),'https://huggingface.co/'+r['repository']+'/resolve/'+r['revision']+'/'+name))
jobs.append(('ggml-ffa4e8b80930029a35991f94e7c8a93cd67730ab.h','https://raw.githubusercontent.com/ggml-org/ggml/ffa4e8b80930029a35991f94e7c8a93cd67730ab/include/ggml.h'))
def read(item):
 name,url=item
 try:
  with urllib.request.urlopen(url,timeout=20) as r:data=r.read()
  (out/name).write_bytes(data)
  return dict(path=name,url=url,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
 except Exception as e:return dict(path=name,url=url,error=type(e).__name__+': '+str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:rows=list(p.map(read,jobs))
(out/'source-receipt.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
