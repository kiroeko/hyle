"""Root-only explicit necessary-range batch; always restore the pause marker."""
import argparse,hashlib,importlib.util,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=B.parents[1]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
b=load('planned_batch_budget',B/'budget.py');c=load('planned_batch_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
p=argparse.ArgumentParser();p.add_argument('plan',type=Path);args=p.parse_args()
plan_path=args.plan.resolve();plan=json.loads(plan_path.read_text('utf-8'))
script=(R/plan['script']).resolve();out=(R/plan['out']).resolve();evidence=(R/plan['need_evidence']['path']).resolve()
assert script.is_relative_to(R/'.scratch') and script.is_file()
assert out.is_relative_to(R/'.scratch') and not out.exists()
assert hashlib.sha256(evidence.read_bytes()).hexdigest()==plan['need_evidence']['sha256']
assert type(plan['new_unique_body_bytes']) is int and plan['new_unique_body_bytes']>0
assert plan['whole_bank'] is False and plan['whole_model'] is False
out.mkdir(parents=True)
c.save(out/'plan.json',plan)
with b.locked() as record:
    marker=B/'PAUSED';assert marker.is_file();marker.replace(out/'PAUSED.before')
    before=record['reserved_request_bytes'];limited_before=b.limited_bytes(record)
try:
    command=[sys.executable,str(B/'budget.py'),'run',str(script),'--',*plan['arguments']]
    process=c.execute(command,os.environ.copy(),out/'run',timeout=plan.get('timeout_seconds',900))
finally:
    with b.locked() as record:
        c.save(B/'PAUSED',dict(paused_at=b.now(),reason='Planned necessary batch ended; no implicit prefetch.',reserved_request_bytes=record['reserved_request_bytes'],requests=len(record['requests'])))
        reserved=record['reserved_request_bytes']-before;limited=b.limited_bytes(record)-limited_before
summary=dict(process=process,plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),new_unique_body_bytes=plan['new_unique_body_bytes'],reserved_request_bytes=reserved,hf_reserved_request_bytes=limited,non_hf_reserved_request_bytes=reserved-limited,paused_after=True)
c.save(out/'summary.json',summary)
print(json.dumps(dict(exit=process['exit'],new_unique_body_bytes=plan['new_unique_body_bytes'],reserved_request_bytes=reserved,hf_reserved_request_bytes=limited,non_hf_reserved_request_bytes=reserved-limited,paused_after=True)),flush=True)
sys.exit(process['exit'])
