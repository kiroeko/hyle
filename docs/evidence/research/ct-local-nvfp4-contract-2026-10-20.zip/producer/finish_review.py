from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent


def identity(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(p)).replace("\\", "/"),
            "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    (p / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


primary = json.loads((p / "primary-source-identities.json").read_text(encoding="utf-8"))
oracle = json.loads((p / "oracle-results.json").read_text(encoding="utf-8"))
review = {
    "status": "bounded fixed-producer source review; proposal not implemented by this task",
    "scope": {"artifacts": [8, 18], "group_size": 16, "activation_dtype": "BF16",
              "payload_bytes_read": 0, "builds": 0, "GPU_runs": 0, "Mac_runs": 0,
              "writes": "Only this producer research directory"},
    "primary_sources": {
        "artifact8": {"producer_version_from_config": "0.17.2.a20260716",
                      "normalized_pypi_version": "0.17.2a20260716",
                      "pypi_url": "https://pypi.org/pypi/compressed-tensors/0.17.2.a20260716/json",
                      "source_archive": identity(p / "compressed_tensors-0.17.2a20260716.tar.gz"),
                      "archive_sha_matches_pypi_digest": True,
                      "version_py": "ct-nightly-20260716/src/compressed_tensors/version.py",
                      "unknown": "No exact git commit claimed for this nightly; the exact release source archive is retained"},
        "artifact18": {"producer_version_from_config": "0.17.2.dev32+g46196ce",
                       "resolved_commit": "46196ce607421d9992a47644612dc6b443f3c434",
                       "commit_url": "https://github.com/vllm-project/compressed-tensors/commit/46196ce607421d9992a47644612dc6b443f3c434",
                       "commit_receipt": "ct-commit-46196ce.json"},
        "source_manifest": "primary-source-identities.json",
        "http_receipts": ["http-initial.json", "http-source-archives.json"],
        "source_snapshot_count": len(primary)},
    "canonical_activation_qdq": {
        "layout": "Independently for each leading-index row and each consecutive group of 16 K elements. No per-token current global max is computed.",
        "global": "IG is a stored F32[1] calibration parameter. dynamic=local initializes this global but does not store input_scale; only local scales are recomputed at forward.",
        "steps": [
            "A is BF16. Group absmax remains BF16. u = BF16_RNE(amax / 6). This divide happens before the F32 global multiply.",
            "v = F32_RNE(IG * F32(u)); IG has shape [1], promoting BF16 local scales to F32.",
            "SF = E4M3FN_RNE(clamp(v,-448,448)), widened back to F32. Only exact SF==0 is replaced by 0.125. This is not max(SF,eps), min-normal, or the E4 min-subnormal.",
            "effective = F32_RNE(SF / IG). Do not replace this division by SF * F32_RNE(1/IG).",
            "normalized = clamp(F32_RNE(F32(A) / effective),-6,6).",
            "FP4 pre-rounding is the real semantic difference: exact nightly casts this normalized value directly to E2M1; commit46196ce first rounds this clamped value to BF16, then E2M1.",
            "E2M1 ties go to even magnitude code. Thresholds are .25->0, .75->1, 1.25->1, 1.75->2, 2.5->2, 3.5->4, 5->4.",
            "QDQ = BF16_RNE(F32_RNE(F32(code_value) * effective)); the final group result is explicitly restored to original A dtype."
        ],
        "source_locations": ["utils/helpers.py:50-136 (calculate_qparams)",
                             "utils/helpers.py:140-196 (group reduction)",
                             "utils/helpers.py:364-370 (E4 epsilon .125)",
                             "lifecycle/initialize.py:160-174 (static global, local dynamic)",
                             "lifecycle/forward.py:310-335 (current local-scale calculation)",
                             "lifecycle/forward_helpers.py:122-168,176-212 (reshape, dtype and QDQ)",
                             "quant_args.py:462-498 (clamp before FP4 cast)"]},
    "canonical_weight_decode_and_storage": {
        "ports": "Wpacked U8[N,K/2], SF E4M3FN[N,K/16], raw WG F32[1]; A also needs raw IG F32[1]",
        "global_convention": "CT raw WG/IG is a quantization multiplier, hence an effective-dequant divisor. ModelOpt's scaling_factor_2 is the dequant multiplier; these are not interchangeable input buffers.",
        "steps": [
            "Unpack even K from low nibble, odd K from high nibble. Sign bit is 3; magnitude table is [0,.5,1,1.5,2,3,4,6]. Code8 is negative zero.",
            "Canonical CT decompressor unpacks to BF16 by default, widens SF E4 to BF16 exactly, then computes F32_RNE(SF / rawWG).",
            "Decoded W = BF16_RNE(F32_RNE(F32(code_value) * F32_RNE(SF / rawWG))).",
            "Weight SF0 is directly decoded; unlike dynamic activation scale generation, weight decompression adds no epsilon or new validity guard.",
            "Ordinary CT reference inference multiplies QDQ A and decoded W in their BF16 dtype. A future packed implementation must preserve the per-element BF16 operands, not substitute a code-dot with combined post-scales. The backend dot/reduction tree remains a separate contract."
        ],
        "source_locations": ["compressors/nvfp4/base.py:55-65,116-138",
                             "compressors/nvfp4/helpers.py:101-166,169-202",
                             "lifecycle/forward_helpers.py:246-268"]},
    "pinned_version_comparison": {
        "helpers": "utils/helpers.py, lifecycle/forward_helpers.py, compressors/nvfp4/base.py are identical in the relevant retained versions (see version diff files).",
        "nightly": "FP4_E2M1_DATA._cast_to_fp4 thresholds the current floating value directly (quant_args.py:67-80).",
        "dev461": "FP4_E2M1_DATA.cast_to_fp4 dispatches to new fp4_utils. Both cast_to_fp4_torch and the Triton kernel first cast to BF16 (fp4_utils.py:26,108).",
        "natural_schema": "A numerical pre-rounding field (direct vs BF16) is sufficient to distinguish the finite normalized-value difference; do not encode model names, producer versions, or a routing whitelist.",
        "not_uniform_bit_semantics": "The finite pre-rounding field alone does not establish identical special-value behavior across the producer CPU and Triton branches; see signed_zero_and_nonfinite."
    },
    "signed_zero_and_nonfinite": {
        "A_negative_zero": "Nightly and dev CPU use torch.sign, not a copied sign bit; exact signed-zero preservation is not explicitly guaranteed there. The dev Triton kernel explicitly carries the BF16 input sign bit, including -0.",
        "negative_tiny_to_zero": "For finite negative nonzero normalized values, thresholded +0 times sign=-1 produces -0 in the sign-multiply paths; Triton explicitly ORs the sign bit.",
        "weight_code8": "Unpack table's +0 multiplied by -1 yields -0; positive finite WG and finite nonnegative SF preserve the usual IEEE signed-zero path. No unsigned-zero reinterpretation is justified.",
        "NaN": "Nightly/CPU torch.sign+arithmetic and dev Triton comparison/bitwise-sign code are not one uniform NaN contract. In particular Triton NaN comparisons leave initial magnitude0; CPU arithmetic propagates a NaN. No actual backend special-value execution was performed.",
        "positive_finite_globals": "A sensible bounded consumer domain, but not proof all intermediates remain finite. F32 SF/global may overflow or underflow; 0*Inf can yield NaN. Preserve operation order and IEEE behavior rather than adding a new clamp/guard.",
        "finite_overflow_tree": "Local IG*u may overflow F32 and is then clamped by the E4 conversion; effective SF/IG can overflow even for positive finite IG. W SF/WG can similarly overflow; code0*Inf is NaN. Finite normalized A overflows are clipped to6 before FP4."
    },
    "global_calibration": {
        "formula_in_CT": "generate_gparam computes 2688 / max(abs(observed_min),abs(observed_max)), with a tiny clamp and nan_to_num(nan/posinf/neginf=1), then converts to requested dtype (default F32) and shape[1].",
        "caution": "The expression's initial tensor dtype is supplied by its observer; no unconditional .float() precedes the division. Artifact8/18 serialize F32 globals, but actual values and the exact upstream llm-compressor observer/calibration history were not read. Runtime must consume stored IG/WG, not recompute globals from current A.",
        "source": "utils/helpers.py:309-338"
    },
    "deployment_paths_are_not_canonical_producer": {
        "vllm": json.loads((p / "deployment-identities.json").read_text(encoding="utf-8")),
        "loader": "compressed_tensors_w4a4_nvfp4.py takes maximum across fused-partition globals, F32 reciprocal of checkpoint IG/WG, and precombines alpha=IG_reciprocal*WG_reciprocal. This is deployment adaptation, not a byte-exact replacement of CT dequant division.",
        "cpu_reference": "nvfp4_emulation_utils.py:640-677 first converts group absmax to F32 and uses a pre-rounded 1/6 multiply; zero reciprocal guard is x+(x==0)*1e8. It does not reproduce CT's BF16 amax/6 and zero-scale replacement tree.",
        "triton_reference": "nvfp4_emulation_utils.py:363-414 loads A to F32, uses max*(1/6), scale0 produces output_scale0, and directly thresholds F32 normalized values. It differs from both pinned producers in at least some rounding/zero details.",
        "native": "scaled_fp4_quant/CUTLASS/FlashInfer hardware routes are distinct deployment numerical contracts. No such kernel was executed or signed as canonical CT QDQ in this task."
    },
    "comparison_with_ModelOpt": {
        "source_commit": "82f1d216d1a9022e60b8e1143a77f36c00b885a4",
        "existing_public_evidence": "docs/evidence/research/nvfp4-channel-global-contract-2026-10-20.zip",
        "source_copy": identity(p / "modelopt-comparison/nvfp4_tensor.py"),
        "differences": ["ModelOpt global is dequant multiplier; CT serialized global is dequant divisor.",
                        "ModelOpt local dynamic source computes amax.float()/(6*global) and zero->1; CT source first divides BF16 amax by6, then multiplies stored F32 global, E4 rounds, zero->.125.",
                        "Even converting raw globals to reciprocal once does not preserve the division/rounding tree; the included witness changes final BF16 bits.",
                        "ModelOpt source directly casts normalized FP4; CT dev461 pre-rounds BF16. Do not reuse a ModelOpt operator merely because packing and group16 agree."]},
    "minimum_witnesses": {"oracle": "oracle.py", "results": "oracle-results.json",
        "status": "Pure Python scalar assertions passed; not a Hyle/producer numerical execution",
        "version_difference": {"A": [1.25, 6, "14 zeros"], "raw_IG_bits": "0x3f8020c5", "SF": 1,
                               "nightly_first_dq": 1.5, "dev461_first_dq": 1.0},
        "global_direction": oracle["global_convention"],
        "input_dtype_rounding": oracle["input_dtype_scale_rounding"],
        "reciprocal_conversion": oracle["reciprocal_conversion_not_equivalent"]},
    "artifact_coverage_boundary": {
        "facts_owner": "../artifact/artifact-facts.json",
        "facts": "Artifact8:168 complete NVFP4 language roles; last8 MLP layers are a different FP8 contract. Artifact18 sampled shard:1593 complete NVFP4 roles including shared expert; no W g_idx/perm/shape observed. Header-only facts belong to the artifact review, not this producer review.",
        "not_claimed": ["No checkpoint global/SF/code payload values or quality read",
                        "No complete model inference or all-shards verification",
                        "No bit equality with torch.compile/Triton/native deployment",
                        "No performance claim or backend carrier/full-bank capacity claim",
                        "No integer GPTQ actorder semantics inferred from config weights.actorder=static"]}
}
save("review.json", review)
save("oracle-execution.json", {
    "command": "python .scratch/architecture-refactor-2026-10-18/ct-local-nvfp4-contract-review/producer/oracle.py",
    "final_exit_code": 0, "oracle": identity(p / "oracle.py"), "results": identity(p / "oracle-results.json"),
    "earlier_source_only_issue": "Initial witness search incorrectly limited IG to1 and found no scale-rounding witness, AssertionError. Search corrected to finite stored IG values; no product or producer numerical test failed."
})
files = sorted(q for q in p.rglob("*") if q.is_file() and "__pycache__" not in q.parts
               and q.name != "source-freeze.json")
save("source-freeze.json", {"scope": "Fixed primary/deployment source snapshots and independent research only",
                           "files": [identity(q) for q in files]})
for name in ("review.json", "source-freeze.json", "oracle.py", "oracle-results.json"):
    print(json.dumps(identity(p / name)))
