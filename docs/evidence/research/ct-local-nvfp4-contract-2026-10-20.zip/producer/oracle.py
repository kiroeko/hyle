"""Independent scalar reading of the two pinned CT NVFP4 QDQ source trees.

Run with Python only. Does not import torch, producer code, or Hyle; no GPU.
Finite BF16 inputs / positive finite F32 globals are the executable witness domain.
F32 operations are rounded separately, never collapsed into reciprocal products.
This is a source-contract oracle, not execution of torch.compile or Triton.
"""
from __future__ import annotations

import json
import math
import struct
from pathlib import Path


def bits(x):
    return struct.unpack("<I", struct.pack("<f", x))[0]


def f32(x):
    try:
        return struct.unpack("<f", struct.pack("<f", x))[0]
    except OverflowError:
        return math.copysign(math.inf, x)


def bf16(x):
    u = bits(x)
    if u & 0x7F800000 == 0x7F800000:
        u = (u & 0xFFFF0000) | (0x400000 if u & 0x7FFFFF else 0)
    else:
        u = (u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000
    return struct.unpack("<f", struct.pack("<I", u))[0]


def e4_value(code):
    e, m = code >> 3, code & 7
    return m * 2.0**-9 if e == 0 else (1.0 + m / 8.0) * 2.0**(e - 7)


E4 = [(e4_value(c), c) for c in range(127)]


def e4(x):
    # Producer round_to_quantized_type_dtype clamps to [-448,448] before cast.
    sign = -1 if x < 0 else 1
    v = min(abs(x), 448.0)
    q, _ = min(E4, key=lambda item: (abs(item[0] - v), item[1] & 1))
    return sign * q


def fp4(x, version):
    if version == "46196ce":
        x = bf16(x)
    a = min(abs(x), 6.0)
    q = (0.0 if a <= .25 else .5 if a < .75 else 1.0 if a <= 1.25
         else 1.5 if a < 1.75 else 2.0 if a <= 2.5 else 3.0 if a < 3.5
         else 4.0 if a <= 5.0 else 6.0)
    # Finite nonzero magnitudes; signed-zero backend difference is reported separately.
    return -q if x < 0 else q


def ct_group(values, global_scale, version):
    assert len(values) == 16
    a = [bf16(v) for v in values]
    g = f32(global_scale)
    assert g > 0 and math.isfinite(g) and all(math.isfinite(v) for v in a)
    maximum = max(map(abs, a))
    # BF16 tensor / Python scalar stays BF16; F32[1] global then promotes to F32.
    local_before_global = bf16(maximum / 6.0)
    scaled_local = f32(g * local_before_global)
    stored_local = e4(scaled_local)
    if stored_local == 0:
        stored_local = .125  # _get_dtype_eps(E4M3), ONLY replace exact zero.
    effective = f32(stored_local / g)
    normalized = [f32(v / effective) for v in a]
    q = [fp4(v, version) for v in normalized]
    dq = [bf16(f32(v * effective)) for v in q]
    return dict(amax=maximum, pre_global_bf16=local_before_global,
                pre_e4_f32=scaled_local, local_sf=stored_local,
                effective_scale=effective, normalized=normalized,
                fp4=q, dq_bf16=dq)


def weight(code, sf, raw_global):
    # CT decompress: SF E4 -> BF16 exact; divide by F32[1] WG -> F32;
    # unpacked BF16 E2M1 -> F32 multiplication -> final BF16.
    return bf16(f32(code * f32(sf / f32(raw_global))))


def details(x):
    return dict(value=x, f32_bits=f"0x{bits(x):08x}")


def main():
    ordinary = [1.25, 6.0] + [0.0] * 14
    old = ct_group(ordinary, 1.001, "nightly-20260716")
    new = ct_group(ordinary, 1.001, "46196ce")
    assert old["fp4"][0] == 1.5 and new["fp4"][0] == 1.0
    assert old["dq_bf16"][0] == 1.5 and new["dq_bf16"][0] == 1.0
    zero = ct_group([0.0] * 16, 1.0, "nightly-20260716")
    small = ct_group([2.0**-8] + [0.0] * 15, 1.0, "nightly-20260716")
    assert zero["local_sf"] == .125 and all(v == 0 for v in zero["dq_bf16"])
    assert small["local_sf"] == .125 and small["dq_bf16"][0] == 0
    # Find a finite BF16 amax showing why F32-first scale generation isn't identical.
    scale_witness = None
    for g in (1.001, 1.01, 1.1, 1.3, 3.0):
        for raw_bf in range(0x3B00, 0x4200):
            a = struct.unpack("<f", struct.pack("<I", raw_bf << 16))[0]
            ct_sf = e4(f32(f32(g) * bf16(a / 6.0)))
            f32_sf = e4(f32(f32(g) * f32(a / 6.0)))
            if ct_sf != f32_sf:
                scale_witness = dict(amax=details(a), raw_IG=details(f32(g)),
                                     bf16_divide=details(bf16(a / 6.0)),
                                     f32_divide=details(f32(a / 6.0)),
                                     ct_local_e4=ct_sf, f32_first_local_e4=f32_sf)
                break
        if scale_witness:
            break
    assert scale_witness
    # A canonical CT decoded weight also cannot in general remain F32 for the dot.
    dequant_witness = None
    for g in (1.001, 1.01, 1.1, 1.3, 3.0):
        effective = f32(1.0 / f32(g))
        rounded = weight(1.0, 1.0, g)
        if effective != rounded:
            dequant_witness = dict(raw_global=details(f32(g)),
                                  before_bf16=details(effective),
                                  canonical_bf16=details(rounded))
            break
    assert dequant_witness
    g = struct.unpack("<f", struct.pack("<I", 0x453F40BE))[0]
    direct = f32(1.5 / g)
    reciprocal_product = f32(1.5 * f32(1.0 / g))
    assert bits(direct) == 0x3A008001 and bits(reciprocal_product) == 0x3A008000
    assert bf16(direct) != bf16(reciprocal_product)
    result = {
        "scope": "Independent finite-domain source-level scalar oracle; 0 producer/Hyle execution, 0 GPU",
        "version_difference": {"a_bf16": ordinary, "raw_IG": details(f32(1.001)),
            "nightly": old, "commit46196ce": new},
        "global_convention": {"packed_code": 1, "SF": 1, "raw_WG": 2,
            "CT_dq_BF16": weight(1.0, 1.0, 2.0),
            "incorrect_direct_ModelOpt_multiplier": bf16(1.0 * 1.0 * 2.0)},
        "zero_scale": zero, "tiny_nonzero_group": small,
        "input_dtype_scale_rounding": scale_witness,
        "required_final_bf16_dequant_rounding": dequant_witness,
        "reciprocal_conversion_not_equivalent": {
            "SF": 1.5, "raw_WG": details(g), "packed_code": 1.0,
            "direct_divide": details(direct),
            "loader_reciprocal_then_mul": details(reciprocal_product),
            "CT_final_BF16": details(bf16(direct)),
            "converted_final_BF16": details(bf16(reciprocal_product))},
        "tie_table": [{"input": v, "fp4": fp4(v, "nightly-20260716")}
                      for v in (.25, .75, 1.25, 1.75, 2.5, 3.5, 5.0)],
        "packing_witness": {"K_values": [1.0, -2.0], "low_code": 2,
            "high_code": 12, "packed_byte": "0xc2", "rule": "even K low nibble; odd K high nibble; sign bit 3"},
        "limitations": ["No actual checkpoint payload values read",
            "No claim of bit equality with torch.compile/Triton/device special-value behavior",
            "Scalar F32 operations use Python double then round to F32; witnesses avoid double-rounding boundaries",
            "No dot/reduction-tree equivalence or model-quality claim"]}
    path = Path(__file__).with_name("oracle-results.json")
    path.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
