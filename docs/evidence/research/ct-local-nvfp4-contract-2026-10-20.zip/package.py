from pathlib import Path
import json,hashlib,zipfile
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';R=A/'ct-local-nvfp4-contract-review';D=ROOT/'docs/evidence/research/ct-local-nvfp4-contract-2026-10-20'
def load(p):return json.loads(p.read_bytes())
def encoded(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
facts=load(R/'artifact/artifact-facts.json');producer=load(R/'producer/review.json');implementation=load(R/'implementation/review.json')
assert facts['actual_config_local_dynamic_artifact_indices']==[8,18]
assert all(a['tensor_payload_bytes_read']==0 and a['physical_schema_all_sampled_roles_pass'] for a in facts['artifacts'])
entries={}
for p in sorted(R.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.name in ['package-receipt.json','package-plan.json']:continue
 rel=p.relative_to(R).as_posix()
 if p.name=='length.bin':assert p.stat().st_size==8
 elif p.suffix.lower() not in ['.json','.py','.diff','.md','.txt','.gz']:continue
 entries[rel]=p.read_bytes()
artifacts=[]
for a in facts['artifacts']:
 artifacts.append({k:a[k] for k in ['catalog_index','repository','revision','producer_config_version','model_dtype','header','nvfp4_targets','sampled_complete_packed_roles','complete_role_counts_by_layer','logical_shapes','physical_schema_all_sampled_roles_pass','roles_with_partial_companions','global_tensors_for_cross_shard_roles']})
report=dict(status='fixed_checkpoint_headers_and_producer_math_researched_implementation_separate',
 scope='CT tensor_group16 local-dynamic NVFP4 parts of the two locked target-model artifacts; BF16 inputs, original U8 low-first packed weights, E4M3FN group scales and original independent F32[1] WG/IG quantization multipliers.',
 artifacts=artifacts,network_read_summary=facts['network_read_summary'],
 activation=producer['canonical_activation_qdq'],weight=producer['canonical_weight_decode_and_storage'],
 producer_sources=producer['primary_sources'],version_difference=producer['pinned_version_comparison'],
 witnesses=producer['minimum_witnesses'],signed_zero_and_nonfinite=producer['signed_zero_and_nonfinite'],
 integration=dict(shape='Two explicit FP4 pre-rounding policies under the existing prepared/native operation execution and resource lifetime machinery; dense and selected-grouped paths are both required. No runtime model/producer whitelist or new executor.',
  chosen_portable_reference='Torch sign convention is explicit: a signed zero presented to the FP4 threshold stage maps to+0; a negative nonzero value which rounds to zero retains-0. The BF16 pre-rounding mode applies before that sign test. Original packed weight code8 retains-0.',
  resource_gap='Checkpoint expert weights are separate tensors. Current grouped carrier requires one dense bank. Existing WeightSlots/catalog/selected fragments provide bounded uploading and lifetime building blocks, but the NVFP4 bridge for segmented experts, global/local ID mapping, working-set planning and real copy accounting is still to be completed under delivery3. Combining512 artifact18 role weights creates a4GiB W carrier and512MiB SF carrier, which is not a requirement of the checkpoint itself.',
  source_map=dict(member='implementation/review.json',identity=identity(R/'implementation/review.json'))),
 limits=['No tensor payload values, publisher artifact execution, model import, quality or throughput were verified.',
  'Artifact8 full header covers168 complete MLP NVFP4 roles in layers0-55; last8 layers MLP are FP8. Artifact18 only first of70 shards was inspected, covering1593 complete NVFP4 roles; additional global-only cross-shard entries are not complete roles.',
  'A source-level independent scalar oracle is not execution of the original producer. Calibration observer/version and calibration payload are not reconstructed. Stored globals remain original ports.',
  'Deployment FP4 tensor-core/code-dot paths, vLLM emulation variants and the producer fakequant tree are not assumed numerically equivalent.',
  'This research archive makes no Hyle build, GPU, Linux, installed-consumer, complete bank or whole-model support claim. Hyle implementation and focused testing are in progress separately.'],
 reports={name:identity(R/name/'review.json') for name in ['artifact','producer','implementation']})
entries['report-core.json']=encoded(report)
inventory=[dict(member=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for name,b in sorted(entries.items())]
entries['inventory.json']=encoded(dict(members=inventory,note='All members except this inventory are hashed. Length-prefix binary files contain exactly8 bytes; no tensor payload is included.'))
D.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(D.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in sorted(entries.items()):z.writestr(name,b)
with zipfile.ZipFile(D.with_suffix('.zip')) as z:
 assert z.testzip() is None
 for name,b in entries.items():assert z.read(name)==b
report['archive']=dict(identity=identity(D.with_suffix('.zip')),members=len(entries),verification='CRC plus every member exact bytes and SHA inventory')
D.with_suffix('.json').write_bytes(encoded(report));receipt=dict(report=identity(D.with_suffix('.json')),archive=identity(D.with_suffix('.zip')),members=len(entries),tensor_payload=0)
(R/'package-receipt.json').write_bytes(encoded(receipt));print(json.dumps(receipt,indent=2))
