from pathlib import Path
import importlib.util,sys,concurrent.futures,json
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('artifact_fetch',S/'fetch.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def verify(row):
 i,repo,rev,_=row;d=S/str(i);h.h.fetch(f'https://huggingface.co/{repo}/resolve/{rev}/config.json',d/'fixed-config.json',100_000);a=(d/'config.json').read_bytes();b=(d/'fixed-config.json').read_bytes();assert a==b,(i,'cached config differs from fixed revision');return {'artifact_index':i,'byte_identical':True,'cache':h.h.identity(d/'config.json'),'fixed':h.h.identity(d/'fixed-config.json')}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:rows=list(p.map(verify,h.ARTS))
h.h.save(S/'fixed-config-verification.json',rows)
print(json.dumps(rows))
