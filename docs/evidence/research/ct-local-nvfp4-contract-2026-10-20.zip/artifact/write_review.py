from pathlib import Path
import json,hashlib
R=Path.cwd();S=Path(__file__).resolve().parent;P=S.parent/'producer'
def identity(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
facts=json.loads((S/'artifact-facts.json').read_text(encoding='utf-8'))
refs=[]
for folder,sub,needles in [('ct-nightly-20260716','quantization/utils/helpers.py',['def calculate_qparams','scales = max_val_pos /','scales = global_scale * scales','scales = torch.where']),('ct-nightly-20260716','quantization/lifecycle/forward_helpers.py',['def _process_group','def _quantize_dequantize','scale = scale / global_scale','output = output.flatten']),('ct-nightly-20260716','quantization/quant_args.py',['def _cast_to_fp4','class DynamicType','class ActivationOrdering']),('ct-nightly-20260716','compressors/nvfp4/base.py',['def decompress','scale_float =']),('ct-nightly-20260716','compressors/nvfp4/helpers.py',['packed = idx_low','def unpack_fp4_from_uint8','combined = torch.stack','values = kE2M1']),('ct-46196ce','quantization/utils/fp4_utils.py',['x = x.to(tl.bfloat16)','def cast_to_fp4_torch','x.to(torch.bfloat16)'])]:
 p=P/folder/'src/compressed_tensors'/sub;lines=p.read_text(encoding='utf-8').splitlines();refs.append({'source':identity(p),'anchors':{n:[i+1 for i,l in enumerate(lines) if n in l] for n in needles}})
report={
 'status':'Fixed artifact/source research only; no product change, build, GPU run or weight payload read.',
 'sufficient_to_design':True,
 'catalog_local_dynamic_artifacts':[8,18],
 'artifact_facts':identity(S/'artifact-facts.json'),
 'fixed_config_verification':identity(S/'fixed-config-verification.json'),
 'artifacts':[dict(catalog_index=x['catalog_index'],repository=x['repository'],revision=x['revision'],producer_config_version=x['producer_config_version'],model_dtype=x['model_dtype'],header=x['header'],sampled_complete_packed_roles=x['sampled_complete_packed_roles'],logical_shapes=x['logical_shapes'],target_resolution=x.get('mixed_target_resolution_observed') or x.get('parent_ignore_observed'),scope='Complete single main-file header; separate MTP file uninspected' if x['catalog_index']==8 else 'First of70shards only. Layer0 all512experts+shared, layer1 first18experts; cross-shard global-only entry excluded') for x in facts['artifacts']],
 'producer_identity':{
  'artifact8':{'version':'0.17.2a20260716','identity':'Exact PyPI source distribution; no guessed current tag','archive':identity(P/'compressed_tensors-0.17.2a20260716.tar.gz'),'url':'https://files.pythonhosted.org/packages/38/4b/4ab767fcb51365763bd180322ca5dd365405e4ac6b8975a582faa547c73c/compressed_tensors-0.17.2a20260716.tar.gz'},
  'artifact18':{'version':'0.17.2.dev32+g46196ce','commit':'46196ce607421d9992a47644612dc6b443f3c434','url':'https://github.com/vllm-project/compressed-tensors/tree/46196ce607421d9992a47644612dc6b443f3c434'},
  'parallel_producer_source_manifest':identity(P/'primary-source-identities.json'),'source_anchors':refs},
 'packing_and_scale_contract':{
  'ports':'Original packedU8[N,K/2], E4M3FN SF[N,K/16], rawWG F32[1], rawIG F32[1]; BF16 source model. Every separate projection/expert/shared-expert has independent WG/IG.',
  'nibbles':'Bytej low nibble=K2j, high=K2j+1; E2M1 magnitude table[0,.5,1,1.5,2,3,4,6], bit3 sign. No blocked hardware packing or shuffled scale layout is implied.',
  'actorder':'Artifact8 weights.actorder=static is a calibration weight-order alias per fixed producer enum, not a runtime g_idx permutation format. Neither inspected header contains g_idx/perm/weight_shape tensors.',
  'code8':'Source unpack lookup applies negative sign to zero for code8. The old ModelOpt software table makes code8 positivezero; exact downstream zero-sign consequences need explicit contract, not relabeling.'},
 'ordered_reference_for_design':{
  'notation':'R_BF16/R_F32 are separate RNE boundaries. WG/IG below are RAW STORED CT globals. Do not replace them by multiplicative ModelOpt globals.',
  'weight':'UnpackE2M1 toBF16; widen E4SF exactly toBF16; effectiveWScale=F32(SF/WG), promoted by originalF32[1]WG. Wdecoded=BF16(F32(code*effectiveWScale)). Preserve direct division; SF*R_F32(1/WG) is not assumed equal.',
  'A_local_scale':'For each currentBF16 row/group16, b=absmax; base=BF16(b/6); t=F32(IG*base); local=clamp448+E4round(t) returnedF32; exact local==0 becomes E4 epsilon0.125. effectiveAScale=F32(local/IG). This is not the old1e-5 guard/fallback1.',
  'A_QDQ':'scaled=F32(BF16A/effectiveAScale); clamp[-6,6]; FP4 round using explicit mode below; F32(code*effectiveAScale); group output returnsBF16. Current local scale is recomputed from A, but originalIG remains calibrated.',
  'artifact8_FP4_round':'Direct finite E2M1 thresholds on scaled/clampedF32; ties0.25,0.75,1.25,1.75,2.5,3.5,5 use source nearest-even inequalities.',
  'artifact18_FP4_round':'BF16(scaled/clampedF32) before the same finite thresholds; fixed fp4_utils CPU and Triton both insert this boundary. A real input-pre-round policy is needed if both references are offered.',
  'dot':'Producer fakequant/decompressed path feeds BF16 operands to ordinaryF.linear. This does not fix a cross-backend reduction tree or certify hardware scaledFP4 GEMM; an Hyle reference must state its F32 accumulation and BF16 output policy.'},
 'minimal_design_implications':[
  'Keep ModelOpt Nvfp4Linear/GroupedNvfp4Linear numerical identity unchanged. CT needs explicit divisor scales, epsilon0.125 and the genuine directF32/BF16-pre-round FP4 boundary. Passing reciprocalglobals to the old op is not an exact adapter.',
  'Reuse bounded W tiles, U8/E4 carrier checks, NativePlan/QueueSequence/nativeProgram/Completion. QDQ A once per row/group into BF16 MK workspace, no NK or ENK floating bank and no new executor.',
  'Expert IG is projection/expert-specific. Shared raw A does not prove shared quantizedA; keep selected-slot TSK bound and validate allIDs before any selected metadata addressing.',
  'A small independent oracle can isolate FP4pre-round ties, directglobal division, exactzero epsilon, nibble/sign, dynamic updates and slot lifetime. No full payload is needed to design or verify those formulas.'
 ],
 'unknowns_and_limits':[
  'No WG/IG/SF numeric payload read: sign, positivity, finite/zero domain and real calibrated values cannot be inferred from metadata. Runtime numerical domain must be explicit and validated separately.',
  'CTsource CPU/Triton have negativezero/nonfinite implementation differences. The finite formulas here do not certify universal bit equality or invalid-input policy.',
  'Artifact18 complete70shard coverage is unverified; artifact8 separateMTP and multimodal execution are outside this review.',
  'No deployed vLLM/SGLang/kernel accumulation, nativeW4A4 equivalence, fullartifact loading, quality or performance support is established.'
 ],
 'network_read_summary':dict(facts['network_read_summary'],fixed_config_bytes=22564+18914),
 'supporting_artifact_files':[identity(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name not in ['review.json','write_review.py']]
}
(S/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(identity(S/'review.json')))
