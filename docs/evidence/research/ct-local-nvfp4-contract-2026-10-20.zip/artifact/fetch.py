from pathlib import Path
import concurrent.futures,importlib.util,json,struct,shutil,sys
sys.dont_write_bytecode=True
ROOT=Path.cwd();S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('range_helper',S.parents[1]/'static-fp8-contract-review/fetch.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
ARTS=[(8,'unsloth/Qwen3.8-27B-NVFP4','f0b7c9e722f5565102fff8481c99e4d86ae099c7','model.safetensors'),(18,'RedHatAI/Qwen3.8-2.4T-A95B-NVFP4-FP8','b94577f02dd4bcb722aad2c60f8117032411dfb5','model-00001-of-00070.safetensors')]
def one(row):
 i,repo,rev,file=row;d=S/str(i);cache=ROOT/'.scratch/model-quantization-discovery-2026-10-19/qwen-kimi'/repo.replace('/','--');d.mkdir(parents=True,exist_ok=True)
 for f in ['config.json','api-model.json','metadata-identity.json','README.md']:shutil.copyfile(cache/f,d/f)
 url=f'https://huggingface.co/{repo}/resolve/{rev}/{file}';dest=d/file
 length=struct.unpack('<Q',h.fetch(url+'?download=true&hyle_ct_local_range=0-7',dest/'length.bin',8,0,7))[0];assert 2<=length<=2_000_000,length
 head=json.loads(h.fetch(url+f'?download=true&hyle_ct_local_range=8-{length+7}',dest/'header.json',length,8,length+7))
 summary=dict(artifact_index=i,repository=repo,revision=rev,file=file,header=h.identity(dest/'header.json'),metadata=head.get('__metadata__'),tensor_count=len(head)-('__metadata__'in head),tensor_payload_bytes=0)
 if i==18:h.fetch(f'https://huggingface.co/{repo}/resolve/{rev}/recipe.yaml',d/'recipe.yaml',100_000)
 h.save(d/'header-summary.json',summary);print(json.dumps(summary),flush=True);return summary
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:rows=list(p.map(one,ARTS))
 h.save(S/'header-summary.json',rows)
