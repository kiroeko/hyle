---
license: other
license_name: kimi-k3
license_link: LICENSE
base_model: moonshotai/Kimi-K3
library_name: transformers
tags:
- compressed-tensors
- quantized
---
# Kimi K3: calibrated routed-expert INT4/K512

Source: `moonshotai/Kimi-K3` at `f831ab66814297da540d832a5235f8e904f29d06`. Build contract: `kimi-k3-w4a8-k512-v1`.

Only routed experts are quantized: symmetric signed INT4 [-7,7], contiguous K512
groups and FP32 scales, compressed-tensors offset-binary INT32 packing. All other
source tensors are preserved exactly. This artifact targets a custom
W4A8 runtime; it does not claim compatibility with arbitrary loaders.