---
language:
- en
library_name: transformers
base_model:
- Qwen/Qwen3.8-2.4T-A95B-FP8
---

# Model Overview

- **Model Architecture:** Qwen3_5MoeForCausalLM
  - **Input:** Text
  - **Output:** Text
- **Supported Hardware Microarchitecture:** AMD MI350 / MI355
- **ROCm**: 7.2.0
- **PyTorch**: 2.12.0
- **Transformers**: 5.14.1
- **Operating System(s):** Linux
- **Inference Engine:** [SGLang](https://docs.sglang.ai/)/[vLLM](https://docs.vllm.ai/en/latest/)
- **Model Optimizer:** [AMD-Quark](https://quark.docs.amd.com/latest/index.html) (v0.12)
  - **Quantized layers:** router experts
  - **Weight quantization:** OCP MXFP4, Static
  - **Activation quantization:** OCP MXFP4, Dynamic


# Model Quantization

The model was quantized from [Qwen/Qwen3.8-2.4T-A95B-FP8](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B-FP8) using [AMD-Quark](https://quark.docs.amd.com/latest/index.html). The weights and activations of the routed experts are quantized to MXFP4.

**Quantization scripts:**
```
from quark.torch import LLMTemplate, ModelQuantizer

qwen3_5_moe_text_template = LLMTemplate(
    model_type="qwen3_5_moe_text",
    kv_layers_name=["*k_proj", "*v_proj"],
    q_layer_name="*q_proj"
)
LLMTemplate.register_template(qwen3_5_moe_text_template)

# === NOTE: Change the following source and output dir as needed ===
src_ckpt_path = "Qwen/Qwen3.8-2.4T-A95B-FP8"
output_dir = "amd/Qwen3.8-2.4T-A95B-Quark-MXFP4"

quant_scheme = "mxfp4"
exclude_layers = [
    "lm_head",
    "*self_attn*",
    "*linear_attn*",
    "*mlp.gate",
    "*shared_expert*",
    "mtp.fc",
]
template = LLMTemplate.get("qwen3_5_moe_text")

quant_config = template.get_config(scheme=quant_scheme, exclude_layers=exclude_layers)

# Quantize with File2File mode to avoid loading full model
quantizer = ModelQuantizer(quant_config)
quantizer.direct_quantize_checkpoint(
    pretrained_model_path=src_ckpt_path,
    save_path=output_dir,
)
```
For further details or issues, please refer to the AMD-Quark documentation or contact the respective developers.

# Evaluation

The model was evaluated on the GSM8K benchmark using the [SGLang](https://docs.sglang.ai/) framework. The baseline is the
original [Qwen/Qwen3.8-2.4T-A95B-FP8](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B-FP8) checkpoint.

### Accuracy

| **Benchmark**                     | **Qwen/Qwen3.8-2.4T-A95B-FP8** | **amd/Qwen3.8-2.4T-A95B-Quark-MXFP4 (this model)** | **Recovery** |
| --------------------------------- | ------------------------------ | ------------------------------------------------ | ------------ |
| gsm8k                             | 97.49                          | 97.49                                            | 100.00%       |


### Reproduction

The GSM8K results were obtained on SGLang based on the docker image `rocm/sgl-dev:v0.5.16-rocm720-mi35x-20260727` using the following recipe.

1. Serve the model with SGLang:
```
 python3 -m sglang.launch_server \
    --model-path amd/Qwen3.8-2.4T-A95B-Quark-MXFP4 \
    --served-model-name amd/Qwen3.8-2.4T-A95B-Quark-MXFP4 \
    --tp-size 8 \
    --attention-backend aiter \
    --page-size 1 \
    --kv-cache-dtype auto \
    --chunked-prefill-size 16384 \
    --watchdog-timeout 1200 \
    --mem-fraction-static 0.9 \
    --model-loader-extra-config '{"enable_multithread_load": true}' \
    --trust-remote-code \
    --host 0.0.0.0 \
    --port 9001
```

2. Evaluate the model
```
python3 -m sglang.test.run_eval \
    --port 9001 \
    --model amd/Qwen3.8-2.4T-A95B-Quark-MXFP4 \
    --eval-name gsm8k \
    --num-examples 1319 \
    --num-threads 512 \
    --max-tokens 2048 \
    --chat-template-kwargs '{"enable_thinking": false}'
```

# License
Modifications Copyright(c) 2026 Advanced Micro Devices, Inc. All rights reserved.