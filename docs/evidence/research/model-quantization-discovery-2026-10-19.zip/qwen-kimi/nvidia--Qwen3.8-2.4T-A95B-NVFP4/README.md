---
pipeline_tag: text-generation
base_model:
- Qwen/Qwen3.8-2.4T-A95B
license: other
license_name: nvidia-open-model-license
library_name: Model Optimizer
tags:
- NVIDIA
- ModelOpt
- Qwen3.8
- quantized
- 4-bit precision
- FP4
- fp4
---

# Model Overview

## Description:
Qwen3.8 delivers substantial gains across coding, professional work, research, and long-horizon agentic tasks. The NVIDIA Qwen3.8-2.4T-A95B-NVFP4 model is the quantized version of Alibaba's Qwen3.8-2.4T-A95B model.For more information, please check [here](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B). The NVIDIA Qwen3.8-2.4T-A95B-NVFP4 model is quantized with [Model Optimizer](https://github.com/NVIDIA/Model-Optimizer).


This model is ready for commercial or non-commercial use.  <br>

## Third-Party Community Consideration
This model is not owned or developed by NVIDIA. This model has been developed and built to a third-party's requirements for this application and use case; see link to Non-NVIDIA [(Qwen3.8-2.4T-A95B) Model Card](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B).

### License/Terms of Use:
**GOVERNING TERMS:** Use of the model is governed by the [NVIDIA Open Model Agreement](https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-open-model-agreement/). **Additional Information:** [Qwen3.8-2.4T-A95B](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B) 

### Use Case:
Qwen3.8-2.4T-A95B delivers comprehensive improvements across coding, work, research, and long-horizon tasks. <br>

### Release Date:
Hugging Face 08/27/2026 via https://huggingface.co/nvidia/Qwen3.8-2.4T-A95B-NVFP4 <br>

## References
- NVIDIA Model Optimizer: https://github.com/NVIDIA/Model-Optimizer
- [Qwen3.8-2.4T-A95B model card](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B)

### Deployment Geography:
Global <br>

## Model Architecture:
**Architecture Type:** Transformers  <br>
**Network Architecture:** Mixture-of-Experts (MoE) with Hybrid Attention and fine-grained MoE blocks <br>
**Number of Model Parameters:** 2.4T in total and 95B activated <br>
## Input:
**Input Type(s):** Text <br>
**Input Format(s):** String <br>
**Input Parameters:** One-Dimensional (1D) <br>
**Other Properties Related to Input:** ** Context length up to 1 million tokens <br>

## Output:
**Output Type(s):** Text <br>
**Output Format:** String <br>
**Output Parameters:** One-Dimensional (1D): Sequences <br>
**Other Properties Related to Output:** Outputs may include natural-language responses, code, tool-calling content, and structured outputs depending on deployment configuration and application-level tooling. <br>

Our AI models are designed and/or optimized to run on NVIDIA GPU-accelerated systems. By leveraging NVIDIA's hardware (e.g. GPU cores) and software frameworks (e.g., CUDA libraries), the model achieves faster training and inference times compared to CPU-only solutions. <br>

## Software Integration:
**Supported Runtime Engine(s):** <br>
* vLLM <br>
* SGLang <br>

**Supported Hardware Microarchitecture Compatibility:** <br>
* NVIDIA Blackwell <br>

**Preferred Operating System(s):** <br>
* Linux <br>

The integration of foundation and fine-tuned models into AI systems requires additional testing using use-case-specific data to ensure safe and effective deployment. Following the V-model methodology, iterative testing and validation at both unit and system levels are essential to mitigate risks, meet technical and functional requirements, and ensure compliance with safety and ethical standards before deployment.

## Model Version(s):
The model version is NVFP4 and is quantized with NVIDIA Model Optimizer **v0.46.0**. <br>

## Training, Testing and Evaluation Datasets:

## Calibration Dataset:
**Link:** [Nemotron-Post-Training-Dataset-v2](https://huggingface.co/datasets/nvidia/Nemotron-Post-Training-Dataset-v2) <br>
**Data Collection Method by dataset:** Automated. <br>
**Labeling Method by dataset:** Automated. <br>
**Properties:** The Nemotron-Post-Training-Dataset-v2 is a post-training dataset curated by NVIDIA containing multi-turn conversations across diverse topics. <br>

## Training Dataset:
**Data Modality:** Undisclosed <br>
**Data Collection Method by dataset:** Undisclosed <br>
**Labeling Method by dataset:** Undisclosed <br>
**Properties:** Undisclosed. <br>

## Testing Dataset:
**Data Collection Method by dataset:** Undisclosed <br>
**Labeling Method by dataset:** Undisclosed <br>
**Data Size:** Undisclosed <br>
**Properties:** Undisclosed. <br>

## Evaluation Dataset:
**Datasets:** GPQA Diamond, SciCode, IFBench, AA-LCR, Terminal Bench 2.1 <br>
**Data Collection Method by dataset:** Hybrid: Automated, manually-collected <br>
**Labeling Method by dataset:** Hybrid: manually-labelled, Automated <br>
**Properties:** We evaluated the model on text-based reasoning, coding, long-context recall, and agentic tool-use benchmarks: GPQA Diamond contains 448 graduate-level multiple-choice questions written by domain experts in biology, physics, and chemistry; SciCode evaluates scientific coding capabilities; IFBench is a benchmark for evaluating instruction-following capabilities across diverse and structured task constraints; AA-LCR (Artificial Analysis Long Context Recall) evaluates a model's ability to accurately retrieve and recall information from long input contexts; τ²-Bench Telecom evaluates agentic tool-use and policy-adherence capabilities in dual-control telecom customer-service scenarios where the model interacts with a simulated user and external tools to resolve account issues. <br>

## Inference:
**Acceleration Engine:** vLLM, SGLang <br>
**Test Hardware:** NVIDIA GB200, NVIDIA B300 <br>

## Post Training Quantization
This model was obtained by quantizing the weights and activations of Qwen3.8-2.4T-A95B-NVFP4 to NVFP4 data type, ready for inference with vLLM. Only the weights and activations of the linear operators within transformer blocks are quantized. This optimization reduces the number of bits per parameter from 16 to 4, reducing the disk size and GPU memory requirements by approximately 2.5x.<br>


## Usage

To serve this checkpoint with [vLLM](https://github.com/vllm-project/vllm), run a command similar to the one below:

```sh
vllm serve nvidia/Qwen3.8-2.4T-A95B-NVFP4 \
  --port 8000 \
  --tensor-parallel-size 8 \
  --max-model-len 262144 \
  --kv-cache-dtype nvfp4 \
  --reasoning-parser qwen3
```

To serve the same checkpoint with [SGLang](https://github.com/sgl-project/sglang), run a command similar to:

```sh
python -m sglang.launch_server \
  --model-path nvidia/Qwen3.8-2.4T-A95B-NVFP4 \
  --port 8000 \
  --tp-size 8 \
  --context-length 262144 \
  --kv-cache-dtype nvfp4 \
  --reasoning-parser qwen3
```

These examples enable NVFP4 KV cache explicitly. NVFP4 KV cache requires a recent
vLLM or SGLang release with NVFP4 KV support and an NVIDIA Blackwell GPU. Omit
`--kv-cache-dtype nvfp4` to use the runtime's default KV cache precision.

## Evaluation
The accuracy benchmark results are presented in the table below:
<table>
  <tr>
   <td><strong>Precision</strong>
   </td>
   <td><strong>GPQA Diamond</strong>
   </td>
   <td><strong>HLE</strong>
   </td>
   <td><strong>SciCode</strong>
   </td>
   <td><strong>AA-LCR</strong>
   </td>
   <td><strong>IFBench</strong>
   </td>
   <td><strong>Terminal Bench 2.1</strong>
   </td>
  </tr>
  <tr>
   <td>Baseline(BF16)
   </td>
   <td>92.55
   </td>
   <td>41.43
   </td>
   <td>54.44
   </td>
   <td>71.5
   </td>
   <td>79.93
   </td>
   <td>76.03
   </td>
  </tr>
  <tr>
   <td>NVFP4
   </td>
   <td>92.58
   </td>
   <td>40.55
   </td>
   <td>56.21
   </td>
   <td>71.63
   </td>
   <td>81.73
   </td>
   <td>76.4
   </td>
  </tr>
  <tr>
   <td>NVFP4 + NVFP4 KV
   </td>
   <td>92.33
   </td>
   <td>40.64
   </td>
   <td>55.92
   </td>
   <td>71.25
   </td>
   <td>81.33
   </td>
   <td>77.25
   </td>
  </tr>
</table>

> Baseline: [Qwen3.8-2.4T-A95B](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B).Benchmarked with temperature=1.0, top_p=0.95, top_k=20. GPQA Diamond, SciCode, AA-LCR and IFBench used max_new_tokens=65,536; HLE used max_new_tokens=131,072; Terminal Bench 2.1 used max_new_tokens=262,144.

> The `NVFP4 + NVFP4 KV` row uses this checkpoint with
> `--kv-cache-dtype nvfp4`.

## Model Limitations:
The base model may generate inaccurate, incomplete, or otherwise undesirable outputs, even when prompts are benign. Because this is a large reasoning-capable model, output quality can vary significantly with prompt construction, reasoning mode, tool configuration, and context length. The model may also reflect biases or content artifacts present in its upstream training data, so deployers should apply application-specific safeguards and evaluate the model in the intended environment before production use.

## Ethical Considerations

NVIDIA believes Trustworthy AI is a shared responsibility and we have established policies and practices to enable development for a wide array of AI applications. Developers should work with their internal model team to ensure this model meets requirements for the relevant industry and use case and addresses unforeseen product misuse.

Please make sure you have proper rights and permissions for all input image and video content; if image or video includes people, personal health information, or intellectual property, the image or video generated will not blur or maintain proportions of image subjects included.

Please report model quality, risk, security vulnerabilities or NVIDIA AI Concerns [here](https://www.nvidia.com/en-us/support/submit-security-vulnerability/).
