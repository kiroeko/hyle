---
license: apache-2.0
base_model: Qwen/Qwen3.5-2B
---

# Freesolo-Co/Qwen3.5-2B-FP8

Freesolo-owned FP8_DYNAMIC prequantized checkpoint for `Qwen/Qwen3.5-2B`. Generated with llmcompressor for vLLM-compatible inference. Vision tower + MoE router left in original precision (vision-language preserved).
