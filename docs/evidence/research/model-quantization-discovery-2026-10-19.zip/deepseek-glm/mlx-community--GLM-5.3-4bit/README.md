---
license: other
license_name: glm-5.3
library_name: mlx
tags:
- mlx
- transformers
language:
- en
- zh
pipeline_tag: text-generation
base_model: zai-org/GLM-5.3-BF16
---

# mlx-community/GLM-5.3-4bit

This model [mlx-community/GLM-5.3-4bit](https://huggingface.co/mlx-community/GLM-5.3-4bit) was converted to MLX format from [zai-org/GLM-5.3-BF16](https://huggingface.co/zai-org/GLM-5.3-BF16) using mlx-lm version **0.31.3** (with PR #1410).

Note that this quant is using the GLM-5.3-BF16 as base. Testing various quant recipes, these often start to overthink and redoing "decisions". The standard 4-bit quant is stable and fast.

This is created for people using a single Apple Mac Studio M3 Ultra with 512 GB. The 4-bit version of GLM-5.3 fits comfortably.

You can find more similar MLX model quants for Apple Mac Studio with 512 GB at https://huggingface.co/bibproj

```bash
pip install mlx-lm

mlx_lm.generate --model mlx-community/GLM-5.3-4bit --prompt "Hi"
```

Enjoy!