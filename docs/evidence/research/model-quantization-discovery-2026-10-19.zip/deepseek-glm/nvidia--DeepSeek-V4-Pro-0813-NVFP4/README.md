---
pipeline_tag: text-generation
base_model:
- deepseek-ai/DeepSeek-V4-Pro-0813
license: mit
library_name: Model Optimizer
tags:
- nvidia
- ModelOpt
- DeepSeekV4
- quantized
- NVFP4
- nvfp4
---

# Model Overview

## Description:
The NVIDIA DeepSeek-V4-Pro-0813-NVFP4 model is the quantized version of DeepSeek AI's DeepSeek-V4-Pro-0813 model, an autoregressive Mixture-of-Experts language model that uses an optimized Transformer architecture with hybrid attention (Compressed Sparse Attention and Heavily Compressed Attention) and Manifold-Constrained Hyper-Connections. DeepSeek-V4-Pro-0813 is the official DeepSeek-V4-Pro release with enhanced agentic capabilities, and includes DeepSeek's DSpark speculative decoding module in the same checkpoint. For more information, refer to the [DeepSeek-V4-Pro-0813 model card](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813). The NVIDIA DeepSeek-V4-Pro-0813-NVFP4 model is quantized with [Model Optimizer](https://github.com/NVIDIA/Model-Optimizer).

This model is ready for commercial or non-commercial use.  <br>

## Third-Party Community Consideration
This model is not owned or developed by NVIDIA. This model has been developed and built to a third-party’s requirements for this application and use case; see link to Non-NVIDIA [(DeepSeek-V4-Pro-0813) Model Card](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813).

### License/Terms of Use:
[MIT](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/blob/main/LICENSE)

### Deployment Geography:
Global <br>

### Use Case:
DeepSeek V4 is well-suited for advanced reasoning, agentic AI applications, tool use scenarios, and complex problem-solving in domains such as mathematics, software engineering, and enterprise AI assistants.  <br>

### Release Date:
Hugging Face 08/27/2026 via https://huggingface.co/nvidia/DeepSeek-V4-Pro-0813-NVFP4 <br>

## References
Nvidia Model Optimizer: https://github.com/NVIDIA/Model-Optimizer

## Model Architecture:
**Architecture Type:** Transformers  <br>
**Network Architecture:** DeepseekV4ForCausalLM — Mixture-of-Experts (MoE) with Hybrid Attention (Compressed Sparse Attention + Heavily Compressed Attention) <br>
**Number of Model Parameters:** 1.65T in total and **49B** activated <br>
**This model was developed based on [DeepSeek-V4-Pro-0813](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813)** <br>

## Input:
**Input Type(s):** Text <br>
**Input Format(s):** String <br>
**Input Parameters:** One-Dimensional (1D): Sequences <br>
**Other Properties Related to Input:** Supports multi-turn conversations with system prompts, user messages, and assistant responses. Maximum context length of 1 million tokens. Uses a custom encoding pipeline (encoding_dsv4) with reasoning effort levels (`low`, `high`, `max`). <br>

## Output:
**Output Type(s):** Text <br>
**Output Format:** String <br>
**Output Parameters:** One-Dimensional (1D): Sequences <br>
**Other Properties Related to Output:** Supports structured JSON output, function/tool calling, and reasoning content when enabled. <br>

Our AI models are designed and/or optimized to run on NVIDIA GPU-accelerated systems. By leveraging NVIDIA’s hardware (e.g. GPU cores) and software frameworks (e.g., CUDA libraries), the model achieves faster training and inference times compared to CPU-only solutions. <br>

## Software Integration:
**Supported Runtime Engine(s):** <br>
* **SGLang** <br>
* **vLLM** <br>

**Supported Hardware Microarchitecture Compatibility:** <br>
* NVIDIA Blackwell B200<br>

**Preferred Operating System(s):** <br>
* Linux <br>

The integration of foundation and fine-tuned models into AI systems requires additional testing using use-case-specific data to ensure safe and effective deployment. Following the V-model methodology, iterative testing and validation at both unit and system levels are essential to mitigate risks, meet technical and functional requirements, and ensure compliance with safety and ethical standards before deployment.

## Model Version(s):
The model is DeepSeek-V4-Pro-0813 NVFP4 quantized with nvidia-modelopt **v0.47.0rc1**  <br>

## Training and Evaluation Datasets:

## Calibration Dataset:
**Link:** [cnn_dailymail](https://huggingface.co/datasets/abisee/cnn_dailymail), [Nemotron-Post-Training-Dataset-v2](https://huggingface.co/datasets/nvidia/Nemotron-Post-Training-Dataset-v2) <br>
**Data Collection Method by dataset:** Automated. <br>
**Labeling Method by dataset:** Automated. <br>
**Properties:** The cnn_dailymail dataset is an English-language dataset containing just over 300k unique news articles as written by journalists at CNN and the Daily Mail. The Nemotron-Post-Training-Dataset-v2 is a post-training dataset curated by NVIDIA containing multi-turn conversations across diverse topics. <br>

## Training Dataset:
**Data Modality:** Undisclosed <br>
**Data Collection Method by dataset:** Undisclosed <br>
**Labeling Method by dataset:** Undisclosed <br>
**Properties:** Undisclosed

## Evaluation Dataset:
**Datasets:** GPQA Diamond, AA-LCR, τ²-Bench Telecom, SciCode, IFBench, Terminal-Bench Hard <br>
**Data Collection Method by dataset:** Hybrid: Automated, Manually-Collected <br>
**Labeling Method by dataset:** Hybrid: Manually-Labeled, Automated <br>
**Properties:** We evaluated the model on reasoning, long-context recall, agentic tool-use, coding, and instruction-following benchmarks: GPQA Diamond contains 448 graduate-level multiple-choice questions written by domain experts in biology, physics, and chemistry. AA-LCR (Artificial Analysis Long Context Recall) evaluates a model's ability to accurately retrieve and recall information from long input contexts. τ²-Bench Telecom evaluates agentic tool-use and policy-adherence capabilities in dual-control telecom customer-service scenarios where the model interacts with a simulated user and external tools to resolve account issues. SciCode evaluates scientific coding capabilities. IFBench is a benchmark for evaluating instruction-following capabilities across diverse and structured task constraints. Terminal-Bench Hard evaluates agentic software-engineering capability in a real terminal environment, where the model must plan and execute shell commands to complete tasks end to end. <br>

## Inference:
**Acceleration Engine:** **SGLang** (benchmarks in this card) <br>
**Test Hardware:** **NVIDIA Blackwell B200** <br>

## Post Training Quantization
This model was obtained by quantizing the weights and activations of DeepSeek-V4-Pro-0813 to NVFP4 data type, ready for inference with **SGLang** and **vLLM**. Only the weights and activations of the linear operators within transformer blocks in MoE are quantized. DeepSeek's DSpark speculative-decoding heads are carried through unquantized and unmodified.

### Quantization Recipe
The recipe is in the Model Optimizer repository under
[`examples/deepseek/deepseek_v4`](https://github.com/NVIDIA/Model-Optimizer/tree/main/examples/deepseek/deepseek_v4)
([`ptq.py`](https://github.com/NVIDIA/Model-Optimizer/blob/main/examples/deepseek/deepseek_v4/ptq.py),
[`quantize_to_nvfp4.py`](https://github.com/NVIDIA/Model-Optimizer/blob/main/examples/deepseek/deepseek_v4/quantize_to_nvfp4.py)).
It runs in three stages:

**1. Reshard the source checkpoint to the model-parallel layout** (CPU only), using DeepSeek's own `convert.py`:

```sh
python convert.py \
    --hf-ckpt-path  <DeepSeek-V4-Pro-0813> \
    --save-path     <mp8_checkpoint> \
    --n-experts     384 \
    --model-parallel 8 \
    --expert-dtype  fp4
```

**2. Collect activation ranges (amax) on the routed experts:**

```sh
torchrun --nproc-per-node 8 deepseek_v4/ptq.py \
    --model_path  <mp8_checkpoint> \
    --config      <DeepSeek-V4-Pro-0813>/inference/config.json \
    --calib_size  512 \
    --calib_seq   4096 \
    --output_path <amax_dump>
```

Calibration uses the script's default datasets — `cnn_dailymail` and
`Nemotron-Post-Training-Dataset-v2` — at 512 samples each (1024 total).
`--calib_seq 4096` sets the tokenizer truncation cap; it is the setting that
mattered most for this model, since the default of 512 does not cover
long-context activation ranges.

The command above uses `ptq.py`'s built-in quantization config. The same config also ships
as a declarative recipe, selectable with `--recipe`:

```sh
torchrun --nproc-per-node 8 deepseek_v4/ptq.py \
    --recipe models/deepseek-ai/DeepSeek-V4-Pro-0813/ptq/nvfp4_experts_only \
    ...
```

The [recipe YAML](https://github.com/NVIDIA/Model-Optimizer/blob/main/modelopt_recipes/models/deepseek-ai/DeepSeek-V4-Pro-0813/ptq/nvfp4_experts_only.yaml)
is pinned by a test to match the built-in default, so either path yields the same quantizer
configuration.

**3. Export the NVFP4 checkpoint:**

```sh
python deepseek_v4/quantize_to_nvfp4.py \
    --amax_path   <amax_dump> \
    --source_ckpt <DeepSeek-V4-Pro-0813> \
    --output_ckpt <output> \
    --cast_mxfp4_to_nvfp4 \
    --device cuda
```

`--cast_mxfp4_to_nvfp4` matters for this model in particular. DeepSeek-V4 already
ships its routed experts in **MXFP4** (E2M1 nibbles with one E8M0 scale per 32
elements). NVFP4 reuses the same E2M1 nibble grid but stores an E4M3 scale per 16
elements, so the weight bits are carried over unchanged — a lossless bit-cast —
and only the block scales are rewritten. The activation amax from stage 2 is
therefore the only calibrated quantity that survives into the artifact, and the
checkpoint is slightly *larger* than its source (scale bytes double while weight
bytes stay the same).

## Usage

### Deploy with SGLang

```sh
python3 -m sglang.launch_server \
    --model-path nvidia/DeepSeek-V4-Pro-0813-NVFP4 \
    --tp 8 \
    --trust-remote-code \
    --tool-call-parser deepseekv4 \
    --reasoning-parser deepseek-v4
```

The base DeepSeek-V4-Pro-0813 checkpoint includes DSpark and those heads are preserved here, but speculative decoding was not exercised during this release's validation — enable it only after verifying it for this NVFP4 checkpoint.

### Deploy with vLLM

```sh
vllm serve nvidia/DeepSeek-V4-Pro-0813-NVFP4 \
    --served-model-name DeepSeek-V4-Pro-0813-NVFP4 \
    --tensor-parallel-size 8 \
    --enable-expert-parallel \
    --reasoning-parser deepseek_v4 \
    --max-model-len 400000 \
    --gpu-memory-utilization 0.9 \
    --kv-cache-dtype fp8 \
    --max-num-batched-tokens 8192 \
    --enable-chunked-prefill \
    --model-loader-extra-config '{"enable_multithread_load": true, "num_threads": 128}'
```

vLLM selects the NVFP4 MoE backend automatically; no backend environment variables
are required. `--model-loader-extra-config` parallelises the checkpoint load, which
otherwise dominates startup for a checkpoint this size. Tune `--max-num-seqs` to your
own concurrency — it is a throughput knob and does not affect output.

This configuration was validated on 8xB200 (TP=8) against this checkpoint with both
`vllm/vllm-openai:v0.27.1` and `v0.28.0`, running a full long-context evaluation
(~115K-token prompts, ~128K total) with no errors on either. It was contributed and run
by NVIDIA ModelOpt QA rather than measured for the table below, which was produced with
SGLang.

## Evaluation
The accuracy benchmark results are presented in the table below:
<table>
  <tr>
   <td><strong>Precision</strong>
   </td>
   <td><strong>GPQA Diamond</strong>
   </td>
   <td><strong>AA-LCR</strong>
   </td>
   <td><strong>τ²-Bench Telecom</strong>
   </td>
   <td><strong>SciCode</strong>
   </td>
   <td><strong>IFBench</strong>
   </td>
   <td><strong>Terminal-Bench Hard</strong>
   </td>
  </tr>
  <tr>
   <td>MXFP4 (source)
   </td>
   <td><strong>88.51</strong>
   </td>
   <td><strong>68.67</strong>
   </td>
   <td><strong>96.49</strong>
   </td>
   <td><strong>53.45</strong>
   </td>
   <td><strong>76.53</strong>
   </td>
   <td><strong>51.39</strong>
   </td>
  </tr>
  <tr>
   <td>NVFP4
   </td>
   <td><strong>88.42</strong>
   </td>
   <td><strong>69.33</strong>
   </td>
   <td><strong>98.25</strong>
   </td>
   <td><strong>53.75</strong>
   </td>
   <td><strong>75.68</strong>
   </td>
   <td><strong>50.69</strong>
   </td>
  </tr>
</table>

> Baseline: [DeepSeek-V4-Pro-0813](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813), whose routed experts already ship in MXFP4. Both checkpoints are mixed precision and share the same FP8 attention and shared-expert projections, BF16 norms and embeddings; only the routed-expert format differs (MXFP4 → NVFP4).
> All scores measured on SGLang at `temperature 1.0`, `top_p 1.0`, max reasoning effort. GPQA Diamond, SciCode, τ²-Bench Telecom and Terminal-Bench Hard are single-run; IFBench is pooled over 4 runs per side; AA-LCR is the matched-configuration pair (2 runs per side).

## Model Limitations:
The base model was trained on data that contains toxic language and societal biases originally crawled from the internet. Therefore, the model may amplify those biases and return toxic responses especially when prompted with toxic prompts. The model may generate answers that may be inaccurate, omit key information, or include irrelevant or redundant text producing socially unacceptable or undesirable text, even if the prompt itself does not include anything explicitly offensive.

## Ethical Considerations

NVIDIA believes Trustworthy AI is a shared responsibility and we have established policies and practices to enable development for a wide array of AI applications. Developers should work with their internal model team to ensure this model meets requirements for the relevant industry and use case and addresses unforeseen product misuse.

Users are responsible for model inputs and outputs. Users are responsible for ensuring safe integration of this model, including implementing guardrails as well as other safety mechanisms, prior to deployment.

Please report model quality, risk, security vulnerabilities or NVIDIA AI Concerns [here](https://app.intigriti.com/programs/nvidia/nvidiavdp/detail).
