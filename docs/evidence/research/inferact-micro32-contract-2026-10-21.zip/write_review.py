from pathlib import Path
import hashlib, json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
A = S.parent
OLD = A / 'fixed-role-binding-2026-10-21/inferact'

def identity(p):
    b = p.read_bytes()
    return dict(path=str(p.relative_to(ROOT)).replace('\\','/'), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def write(name, value):
    (S/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')

old = json.loads((OLD/'assessment.json').read_text(encoding='utf-8'))
catalog = json.loads((ROOT/'docs/implementation/model-quantizations.json').read_text(encoding='utf-8'))
row = catalog['artifacts'][19]
assert row['repository'] == old['repository'] and row['revision'] == old['revision']

evidence = [identity(OLD/name) for name in (
    'assessment.json','config.json','README.md','api-model.json','metadata-identity.json',
    'model-00001-of-00007.safetensors/header.json',
    'model-00001-of-00007.safetensors/header.json.http.json',
    'mxfp4_experts-00001-of-00092.safetensors/header.json',
    'mxfp4_experts-00001-of-00092.safetensors/header.json.http.json')]
write('existing-evidence.json', dict(reused_without_refetch=True, files=evidence,
    public_source='docs/evidence/research/fixed-role-binding-2026-10-21.json',
    archive='docs/evidence/research/fixed-role-binding-2026-10-21.zip',
    archive_prefix='inferact/', tensor_payload_bytes_read=0))

new_sources=[]
for p in sorted(S.rglob('*.http.json')):
    receipt=json.loads(p.read_text(encoding='utf-8'))
    body=p.with_suffix('')
    r=dict(receipt=identity(p), url=receipt['url'], status=receipt.get('status'), error=receipt.get('error'))
    if body.exists(): r['file']=identity(body)
    new_sources.append(r)
write('primary-source-identities.json', dict(files=new_sources,
    note='Small official API/text source reads only; no model numeric tensor payload, SDK, repository clone or binary execution. HTTP receipts preserve failed 404 and first empty path-history query.'))

def anchor(file, needle):
    lines=(S/file).read_text(encoding='utf-8').splitlines()
    return dict(file=file, line=next(i+1 for i,l in enumerate(lines) if needle in l), text=needle)

refs={
 'config':anchor('runtime/mxfp4.py','def from_config(cls, config):'),
 'act_dtype':anchor('runtime/mxfp4.py','return [torch.bfloat16]'),
 'scale_encode':anchor('runtime/mxfp4.py','def _encode_mxfp4_weight_scale'),
 'weight_shape':anchor('runtime/mxfp4.py','mxfp4_block = 32'),
 'weights_setup':anchor('runtime/mxfp4.py','def _setup_kernel('),
 'w4a16':anchor('runtime/mxfp4.py','Canonical ``mxfp4`` checkpoints are weight-only W4A16.'),
 'select':anchor('runtime/moe_mxfp4.py','def select_deepseek_v4_mxfp4_moe_backend('),
 'key':anchor('runtime/moe_mxfp4.py','def _backend_activation_key('),
 'aiter_w4a16':anchor('runtime/moe_mxfp4.py','AITER_MXFP4_BF16 = "AITER_MXFP4_BF16"'),
 'gate_up_consumer':anchor('runtime/routed_experts.py','elif is_per_expert_fused_w13:'),
 'gate_up_mapping':anchor('runtime/routed_experts.py','for shard_id in ("w1", "w3")'),
 'native_dtype':anchor('runtime/moe_mxfp4.py','w13_weight.data.view(torch.float4_e2m1fn_x2),'),
 'torch_e2m1_layout':anchor('runtime/torch-Float4_e2m1fn_x2-fixed.h','original value             | val1 : val0'),
 'e8_round':anchor('runtime/torch-Float8_e8m0fnu-fixed.h','uint8_t fp8e8m0fnu_from_fp32_value(float f)'),
 'e8_widen':anchor('runtime/torch-Float8_e8m0fnu-fixed.h','Float8_e8m0fnu::operator float() const'),
 'bf16_emulation':anchor('runtime/ocp_mx_emulation_moe.py','# Dequantize w1 and w2 from packed OCP MX format to bf16/fp16'),
 'runtime_pack':anchor('runtime/mxfp4_utils.py','out_tensor = evens | (odds << 4)'),
 'runtime_dequant':anchor('runtime/mxfp4_utils.py','return mx.dq_mxfp4(x, scale, float_dtype)'),
 'recipe_target':anchor('official-recipe/qwen38-24t.yaml','model_id: "Inferact/Qwen3.8-2.4T-A95B-MXFP4"'),
 'recipe_amd':anchor('official-recipe/qwen38-24t.yaml','supported_hardware: [mi300x, mi325x, mi355x]'),
 'blog_quant':anchor('official-blog/qwen38.md','RTN) quantization with activation calibration'),
}

runtime_commit='7b569ec8953cf8099638a6d2ee1e915b75867c3a'
review=dict(
 observed_on='2026-10-21',
 status='Bounded research complete: exact artifact metadata known; fixed official deployment reader known; original Inferact exporter numerical contract remains incomplete.',
 task_scope='Read-only capability-8 investigation; no product, catalog or public-document changes; no build, GPU, model numeric payload, SDK download or repository clone.',
 artifact=dict(catalog_index=19, repository=old['repository'], revision=old['revision'],
    fixed_url=old['source_url'], current_catalog=identity(ROOT/'docs/implementation/model-quantizations.json'),
    artifact_execution_verified=False, exact_exporter_version='not recorded in pinned config/card/API',
    quantization_config=old['config_contract']),
 metadata_and_roles=dict(reused_evidence='existing-evidence.json',
    sampled_headers=old['headers'],
    observed=[
      'First preserved shard contains 130 BF16 tensors, including head/embedding/attention/norm. This is a sampled shard, not all-preserved-role validation.',
      'First expert shard contains all 512 layer-0 expert down and fused gate_up pairs: 1024 U8 weights plus 1024 F32 weight_scale tensors, and no activation-scale tensor in this sampled shard.',
      'down U8[8192,1024], F32 SF[8192,64]; gate_up U8[4096,4096], F32 SF[4096,256]. A two-E2M1-per-byte consumer interprets logical K=2048/8192 and group32; exact writer nibble order is not established by these dimensions.',
      'Pinned API lists 7 preserved shards, 92 main expert shards and 2 MTP expert shards. No full index/header census or numeric scale-value inspection was done.'
    ]),
 official_sources=dict(runtime_repository='vllm-project/vllm', runtime_commit=runtime_commit,
    runtime_commit_reuse='Same fixed official revision already used by the compact MLA research; not a newly selected moving main.',
    blog_repository='vllm-project/vllm-project.github.io', blog_commit='650ec0cd3b967956c9e81be897b66caf4131f0db',
    recipe_repository='vllm-project/recipes', recipe_commit='38650cbd468bafaf7cce5303403e9935d1f002db',
    fetched_source_identities='primary-source-identities.json', anchors=refs),
 exact_reader_facts=[
    dict(fact='Mxfp4Config.from_config returns cls() and does not read micro_block, macro_block, mbs_mode, use_oas, scale_search or ignore. The numerical exporter options cannot be reconstructed from this reader.', sources=[refs['config']]),
    dict(fact='The ordinary MXFP4 method allocates U8 packed W[E,N,K/2] and U8 scales[E,N,K/32], with native BF16 activation capability. F32 checkpoint weight_scale is numerically converted to torch.float8_e8m0fnu then viewed U8; it is not treated as arbitrary original F32 multiplicative SF by this reader.', sources=[refs['act_dtype'], refs['scale_encode'], refs['weight_shape']]),
    dict(fact='The official target recipe calls this artifact AMD MXFP4 and names MI300X/MI325X/MI355X. The generic MXFP4 reader chooses backend-dependent activation schemes. The AITER BF16 variant is explicitly W4A16, and EMULATION explicitly preserves BF16 A for canonical MXFP4. This is real deployment evidence against requiring a single inferred W4A4 activation policy from the repository name.', sources=[refs['recipe_target'],refs['recipe_amd'],refs['aiter_w4a16'],refs['w4a16'],refs['key'],refs['select']]),
    dict(fact='A current runtime quantize helper packs adjacent even K in low nibble and odd K in high nibble, and loaded U8 weights are viewed as torch.float4_e2m1fn_x2. The fixed PyTorch type explicitly places val0 in low nibble and val1 in high nibble. Together these establish the deployment-consumer adjacent E2M1 byte contract; they are not the original Inferact pack writer.', sources=[refs['runtime_pack'],refs['native_dtype'],refs['torch_e2m1_layout']]),
    dict(fact='The actual RoutedExperts loader handles per-expert gate_up_proj W and block scales by chunk(2,dim=0), first chunk w1/gate then w3/up. Backend conversion subsequently shuffles/interleaves its own storage. Do not import the separate GPT-OSS de-interleave branch into this target contract.',sources=[refs['gate_up_consumer'],refs['gate_up_mapping']]),
    dict(fact='The official day-0 blog jointly describes RTN FP4 weights and activation calibration enabling 4-bit activations. It does not pin this exact HF revision or provide micro/macro/OAS math, and also discusses a separate AMD Quark path. Pinned artifact calibration_applied=false and fixed reader W4A16 are kept as separate source facts, not normalized into a fabricated common producer.',sources=[refs['blog_quant']])
 ],
 unresolved_contract=[
    dict(item='Original codebook/pack writer', known='Runtime native FP4 and adjacent-nibble helper expectations are pinned.', missing='Exact Inferact writer implementation, producer revision and whether any transpose/reorder is applied before storing this particular W.'),
    dict(item='F32 micro32 SF semantics',known='Actual F32 SF shape is pinned; fixed reader numerically converts it to E8M0. Fixed PyTorch constructor uses GRS exponent RNE, described below.',missing='Whether actual exported SF values are all exact E8M0 powers, whether OAS permits non-powers, and whether preserving raw F32 vs reader conversion is the original exporter intention. No numeric model values were read.'),
    dict(item='macro128/mbs_mode off/use_oas',known='Exact fields and values are pinned; no corresponding tensor was observed in the sampled header.',missing='Whether macro128 affects calibration/search only, scale generation or runtime decode. mbs_mode off cannot by itself prove macro is numerically irrelevant; use_oas has no recovered mathematical definition.'),
    dict(item='Activation and output math',known='Pinned consumer supports BF16 A, backend variants can choose W4A16/W4A8/W4A4, and EMULATION preserves BF16 for canonical MXFP4.',missing='Artifact-producer QDQ/scale/clamp/ties policy and exact W multiply/cast/accumulation/output rounding. Do not reuse Quark W4A4 or BlockQuantizationRoundtrip as that missing contract.'),
    dict(item='Fused gate/up order',known='Fused stored rows4096 plus exact current per-expert loader are pinned: first2048 rows gate, second2048 up, identically for SF. This is a deployment-reader contract.',missing='Original pack writer code was not acquired. No payload or end-to-end load verified that the artifact was generated correctly against that reader contract.')
 ],
 bounded_search=dict(
    official_inferact_public_repositories='official-inferact/repos.json: five returned public repositories, none is a quantization/exporter project. This does not establish that the implementation is unavailable privately or under another namespace.',
    exact_term_web_search=['mbs_mode + mxfp4','use_oas + mxfp4','micro_block + macro_block + Inferact'],
    search_result='Only fixed/sibling HF config occurrences were found by this bounded search; sibling numeric contracts were not substituted. Existing source-search negatives in fixed-role assessment are retained, not treated as proof of nonexistence.',
    official_vllm_issue_search='official-vllm/target-search.json is supplementary navigation only, not a mathematical source; no results were promoted to producer proof.',
    stopping_condition='Exact target metadata and a fixed public runtime reader are acquired. No broad clone, full model index, unrelated producer or payload search is needed to state the remaining missing source precisely.'),
 hyle_overlap=dict(current_sources=[identity(ROOT/'include/hyle/compute/model_ops.h'),identity(ROOT/'src/compute_provider_native/nvfp4.cc')],
    already_implemented='model_ops::Mxfp4Linear/GroupedMxfp4Linear define explicit Quark-compatible portable BF16 W4A4 QDQ with original U8 E8M0 SF, group32 and signed E2M1 codes. MLX MX is weight-only but uses U32 row bitstreams and a distinct group-dot/scale tree. The needed deployment W4A16 reference is not supplied merely by accepting a U8/F32 descriptor.',
    not_a_missing_general_executor='Original Graph, typed Cast/Views, checked IDs and bounded selected-expert execution already exist. Independent expert spans/working-set import remain the separate delivery-3 resource bridge.'),
 minimal_next_action=dict(
    recommendation='A bounded deployment-reference W4A16 bridge can proceed now without waiting for the missing exporter: explicitly target the fixed reader contract below. Do not implement an assumed Inferact W4A4/OAS/macro primitive or label that bridge original-exporter equivalence.',
    precise_required_source_interface=['pack(U8 destination, logical W) and inverse code table/adjacent lane order','micro32 SF generation/application, OAS meaning and macro/off branches','runtime activation quantization or explicit weight-only contract','fused gate/up stored row order and loader mapping'],
    if_fixed_runtime_reference_is_the_deliberate_target='Make that choice explicit: cold numeric F32 SF -> E8M0 conversion as the loader does; consume BF16 A unchanged, decode E2M1 W with E8M0 scales to BF16 before dot, then preserve ordinary declared output/reduction boundaries. This is a deployment reference, not proof of all runtime backend variants.',
    natural_implementation_after_contract='Use the existing Mxfp4Linear/GroupedMxfp4Linear numerical family with an explicit activation_mode (default existing Float4Group32; new BFloat16 leaves A unchanged), revisioned OpID and no compatibility entry. Keep adjacent U8 W and an explicitly cold-converted U8 E8 grid; preserve original F32 SF and its source identity as import provenance. Dense ports A,W[N,K/2],SF[N,K/32]; grouped A,W[E,N,K/2],SF[E,N,K/32],checked IDs[T,S]. Reuse existing bounded W tile/row decode, queue, status and Invocation mechanisms. Reusing a U32 MLX carrier would still not match its group-dot-after-scale numerical tree automatically.',
    memory='Never cast/expand all E*N*K weights. Validate all IDs before selected expert addressing, keep actual A strides/duplicate slots and original bank owner/range lifetimes. Dense conversion or E8 scale cache must be cold, explicit and bounded by proven scale semantics.',
    finite_regression_when_ready=['All16 codes + lane order + two adjacent groups and non-square W','F32 SF that distinguishes raw multiply from E8M0 conversion; zero/tiny/extreme according to actual source contract','BF16 A unchanged vs actual QDQ witness, plus exact fused gate/up row witness','Selected experts/duplicate IDs/full ID validation, two updates/two Invocation slots, retained output and published-decode escape']),
 non_claims=['No Hyle implementation/test/performance or hardware FP4 qualification in this research.','No whole-artifact import/execution, quality, all-shard data-value or scale calibration validation.','No claim original Inferact is equal to Quark, MLX, GGUF or a same-named canonical runtime format.'],
 work_counts=dict(model_numeric_payload_bytes=0, builds=0, gpu_processes=0, canonical_file_edits=0)
)
# This report deliberately fixes a deployable public-reader reference while
# preserving the separate, still missing Inferact exporter contract.
quark=A/'quark-mxfp4-contract-review/producer'
quark_files=[
    quark/'review.json',quark/'primary-source-identities.json',
    quark/'quark-012post1/quark/torch/kernel/mx/__init__.py',
    quark/'quark-012post1/quark/torch/kernel/mx/hip.py',
    quark/'quark-012post1/quark/torch/kernel/hw_emulation/csrc/mxfp4/dequantize_kernels.cuh',
    quark/'quark-012post1/quark/torch/kernel/hw_emulation/csrc/mxfp4/low_precision_intrinsics.cuh'
]
review['reference_decision']='Parent selected the finite BF16 W4A16 deployment reference; implementable without pretending the original Inferact exporter has been acquired. This is a numerical capability, not full artifact execution.'
review['reference_dependency_sources']=[identity(p) for p in quark_files]
review['torch_cast_contract']=dict(
    torch_revision='cf30153c4c131c8164ee7798e5022d810682e2cb',tag='v2.13.0',
    identity=identity(S/'runtime/torch-Float8_e8m0fnu-fixed.h'),
    tag_and_fixed_commit_bytes_identical=True,
    installed_2_8_crosscheck='The same fp8e8m0fnu_from_fp32_value GRS algorithm was inspected in the existing Hyle torch2.8 CPU SDK header; no SDK compilation or Tensor cast execution was performed.',
    numeric_cast_not_reinterpret=True,
    source_api='loaded_weight.to(torch.float8_e8m0fnu).view(torch.uint8)',
    algorithm=['Let b be original F32 storage bits, e=(b>>23)&255. Source constructor returns255 for e=255.',
               'g=(b&0x00400000)!=0; r=(b&0x00200000)!=0; s=(b&0x001fffff)!=0; lsb=(e>0).',
               'code=e+uint8(g && (r || s || lsb)); source sign bit is not used. This is the exact source GRS rule, not ceil(log2(x)), nearest exponent/log distance, raw exponent truncation or a U8 numeric cast.',
               'E8 code0 widens to F32bits0x00400000=2^-127;1..254 to F32bits(code<<23);255 is E8 NaN in the dtype. The chosen finite decoder rejects255, avoiding the distinct Quark HIP/Triton255 behavior.'],
    deduced_witnesses_not_runtime_tests=[
      dict(f32_bits='0x3f800001',value='nextafter(1,+Inf)',e8_code=127,decoded='1; ceil power2 would2'),
      dict(f32_bits='0x3fa00000',value='1.25',e8_code=127,decoded='1'),
      dict(f32_bits='0x3fc00000',value='1.5',e8_code=128,decoded='2; normal tie rounds up by the source implicit-bit rule'),
      dict(f32_bits='0x00000001',value='smallest positive F32',e8_code=0,decoded='2^-127, not0'),
      dict(f32_bits='0x00400000',value='2^-127',e8_code=0,decoded='2^-127'),
      dict(f32_bits='0x7f400000',value='1.5*2^127',e8_code=255,decoded='outside selected finite reference domain')],
    source_specials_outside_selected_domain='Original F32 +/-0 mapcode0; negative finite sign is discarded; NaN/+/-Inf map255. The selected cold import accepts only positive finite F32 and then rejects rounded255; it does not silently adopt these source-special conversions.',
    deployment_version_limit='Pinned artifact and recipe do not pin the actual Torch wheel used to produce or execute the model. The explicitly selected reference fixes this source algorithm, with an observed identical2.8 implementation, rather than claiming every arbitrary Torch version/device lowering has been executed.')
review['selected_reference_math']=dict(
    source_basis=[refs['scale_encode'],refs['w4a16'],refs['bf16_emulation'],refs['runtime_dequant'],refs['torch_e2m1_layout'],refs['gate_up_consumer']],
    dependency_chain='Fixed vLLM mxfp4 reader -> EMULATION OCP expert -> mx.dq_mxfp4; its fixed ROCm requirements specify amd-quark==0.12.post1. Reusing that exact cached decoder source is an actual consumer dependency, not replacing Inferact exporter provenance with an unrelated producer.',
    original_import_ports='F32 stored SF[N,K/32] or [E,N,K/32] is positive finite; numeric GRS-RNE to E8 code0..254 cold, otherwise import fails before ready publication. Original adjacent U8 W bytes are not requantized.',
    primitive_ports='Same as current Mxfp4 dense/grouped ports, with U8 E8 SF and BF16 A/Y. K complete32. For grouped A[T,1|S,K], W[E,N,K/2], SF[E,N,K/32], I32 IDs[T,S], retain original stride/zero-slot and all-ID-before-address contracts.',
    activation='Finite BF16 A is unchanged, no absmax/scale generation/FP4 QDQ. Shared A is shared naturally, not expanded per expert.',
    weight='For lane k, nibble=(W[n,k//2]>>(4*(k%2)))&15. E2M1 table is [0,.5,1,1.5,2,3,4,6,-0,-.5,-1,-1.5,-2,-3,-4,-6]. e8code c0..254 gives s=2^(c-127), with c0=2^-127. Woperand=BF16_RNE(E2M1(nibble)*s); scaling and BF16 rounding occur before the dot, code8 retains negative zero.',
    reduce='Original F32 dot/reduction of unchanged BF16 A and decoded BF16 W, followed by BF16 output. Reduction tree is backend-defined, not scalar-bit-equal across all implementations.',
    finite_overflow='Finite admitted source scale can yield decoded BF16 Inf, and dot may yield Inf/NaN; preserve IEEE arithmetic rather than invent post-decode finite rejection.',
    special_restriction='SF255 is rejected for selected rows/experts by the selected portable reference. Quark default HIP and optional Triton disagree on255 and some extreme internals; no all-IEEE or every deployment-backend equivalence is claimed.',
    gate_up='Current RoutedExperts reader treats fused per-expert gate_up rows as contiguous gate[0:2048] then up[2048:4096], with identical splitting of weight_scale. Subsequent backend shuffle is not source row order.',
    macro='For this fixed deployment reader, macro_block128/mbs_mode off/use_oas are ignored by from_config and never become runtime math parameters. Therefore the selected reference needs no macro port or policy. This does not prove those fields are irrelevant to original exporter scale generation.',
    not_equivalent=['RawF32SF multiply vs GRS-rounded E8SF multiply unless exact data values prove equality.','Existing W4A4 MXFP4 activation quantization.','MLX group-dot then cast/scale accumulation instead of BF16 scaled W before dot.','GPT-OSS interleaved source gate_up.','Hardware native FP4 accumulation or all source calibration/OAS procedures.'])
write('design-review.json',review)
inventory=[identity(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='source-freeze.json']
write('source-freeze.json',dict(files=inventory, scope='Read-only research artifacts only; canonical source hashes are observations, not a product freeze.'))
print(json.dumps(dict(report=identity(S/'design-review.json'), source_freeze=identity(S/'source-freeze.json'), local_files=len(inventory))))
