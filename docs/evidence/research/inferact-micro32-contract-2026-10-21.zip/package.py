"""Publish the bounded Inferact reader/scale contract, without model payload."""
from pathlib import Path, PurePosixPath
import argparse,hashlib,json,zlib,zipfile

S=Path(__file__).resolve().parent
ROOT=S.parents[2];A=S.parent
STEM='inferact-micro32-contract-2026-10-21'
PUBLIC=ROOT/'docs/evidence/research'
EXPECTED_REPORT='bcd705ab3ac72dcf10ebd041157c764d4b10a87c4b441a95133045e7536d78e2'

def encoded(v): return (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
def sha(b): return hashlib.sha256(b).hexdigest()
def ident(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=sha(b))
def safe(name):
    p=PurePosixPath(name)
    assert name and not p.is_absolute() and '..' not in p.parts and ':' not in name and '\\' not in name

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',action='store_true');parser.add_argument('--publish',action='store_true')
    args=parser.parse_args();assert args.plan!=args.publish
    report=json.loads((S/'design-review.json').read_text(encoding='utf-8'))
    assert sha((S/'design-review.json').read_bytes())==EXPECTED_REPORT
    selected={}
    def add(name,path,expected=None):
        safe(name);assert name not in selected
        b=path.read_bytes()
        if expected:
            assert len(b)==expected['bytes'] and sha(b)==expected['sha256'],str(path)
        selected[name]=(path,b)

    for name in ['design-review.json','existing-evidence.json','primary-source-identities.json','fetch.py','write_review.py','package.py']:
        add(name,S/name)
    runtime=[
        'mxfp4.py','moe_mxfp4.py','mxfp4_utils.py','ocp_mx_emulation_moe.py',
        'routed_experts.py','qwen3_5.py','qwen3_next.py','requirements-rocm.txt',
        'torch-Float8_e8m0fnu-fixed.h','torch-Float4_e2m1fn_x2-fixed.h','torch-v213-commit.json']
    for name in runtime:
        add('runtime/'+name,S/'runtime'/name)
        add('runtime/'+name+'.http.json',S/'runtime'/(name+'.http.json'))
    for name in ['official-blog/qwen38.md','official-blog/path-commits.json',
                 'official-recipe/qwen38-24t.yaml','official-recipe/path-commits.json',
                 'official-inferact/repos.json']:
        add(name,S/name);add(name+'.http.json',S/(name+'.http.json'))

    old=A/'fixed-role-binding-2026-10-21/inferact'
    evidence=json.loads((S/'existing-evidence.json').read_text(encoding='utf-8'))
    for row in evidence['files']:
        path=ROOT/row['path'];name='artifact/'+path.relative_to(old).as_posix()
        add(name,path,row)
    for shard in ['model-00001-of-00007.safetensors','mxfp4_experts-00001-of-00092.safetensors']:
        prefix=old/shard/'length.bin'
        assert prefix.stat().st_size==8
        add('artifact/'+shard+'/length.bin',prefix)
        add('artifact/'+shard+'/length.bin.http.json',prefix.with_suffix('.bin.http.json'))

    quark=A/'quark-mxfp4-contract-review/producer'
    for row in report['reference_dependency_sources']:
        path=ROOT/row['path']
        add('decoder-dependency/'+path.relative_to(quark).as_posix(),path,row)
    constants=quark/'quark-012post1/quark/torch/utils/constants.py'
    add('decoder-dependency/quark-012post1/quark/torch/utils/constants.py',constants)
    # Published old evidence supplies the independently pinned wheel/commit provenance;
    # don't duplicate wheels or the entire Quark research/SDK archive here.
    references=[]
    for stem in ['fixed-role-binding-2026-10-21','quark-mxfp4-contract-2026-10-20']:
        for suffix in ['.json','.zip']:
            references.append(ident(PUBLIC/(stem+suffix)))
    refbytes=encoded(dict(scope='Referenced prior metadata and decoder provenance, not duplicated full archives.',files=references))
    selected['prior-public-evidence.json']=(None,refbytes)

    plan=dict(payload_members=len(selected),payload_bytes=sum(len(b) for _,b in selected.values()),
        source_files=sum(name.endswith(('.py','.h','.cuh')) for name in selected),
        archive=(PUBLIC/(STEM+'.zip')).relative_to(ROOT).as_posix(),
        report=(PUBLIC/(STEM+'.json')).relative_to(ROOT).as_posix(),
        excludes=['model tensor payload','SDK/binaries/objects','broad issue/directory navigation results','initial superseded research drafts','separate product implementation/compilation/GPU results'])
    (S/'package-plan.json').write_bytes(encoded(plan))
    if args.plan:
        print(json.dumps(plan,indent=2));return

    manifest=dict(schema_version=1,observed_on='2026-10-21',
        scope='Fixed artifact metadata and selected finite deployment-reader contract; not exact original exporter, Hyle correctness or model execution.',
        members=[dict(path=name,source_path=path.relative_to(ROOT).as_posix() if path else None,
            bytes=len(raw),sha256=sha(raw),crc32=f'{zlib.crc32(raw):08x}')
            for name,(path,raw) in sorted(selected.items())])
    manifest_raw=encoded(manifest)
    payloads={name:raw for name,(_,raw) in selected.items()}
    payloads['archive-manifest.json']=manifest_raw
    PUBLIC.mkdir(parents=True,exist_ok=True)
    archive=PUBLIC/(STEM+'.zip')
    assert not archive.exists(),'Do not overwrite an earlier publication silently'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(payloads.items()):
            safe(name);entry=zipfile.ZipInfo(name,(2026,10,21,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
            entry.external_attr=0o644<<16;z.writestr(entry,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        names=z.namelist();assert len(names)==len(set(names)) and set(names)==set(payloads)
        for name in names:
            safe(name);raw=z.read(name);assert raw==payloads[name]
            assert z.getinfo(name).CRC==zlib.crc32(raw)
        archived=json.loads(z.read('archive-manifest.json'))
        for row in archived['members']:
            raw=z.read(row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    summary=dict(schema_version=1,observed_on='2026-10-21',
        status='Research complete; explicit finite BF16 W4A16 deployment reference selected. Product execution evidence is separate.',
        artifact_execution_verified=False,
        artifact=dict(catalog_index=19,repository='Inferact/Qwen3.8-2.4T-A95B-MXFP4',revision='98b8fd6c5dec37c28ff28e7a0f577677ccbdc49f'),
        scope=dict(model_numeric_payload_bytes=0,Hyle_builds_in_research=0,Hyle_operation_tests_in_research=0,GPU_processes_in_research=0),
        key_findings=[
          'Sampled expert W is U8[N,K/2] with original F32SF[N,K/32]. Fixed reader expects adjacent even-low/odd-high E2M1; fused gate_up rows and scales are loaded as contiguous gate then up.',
          'Fixed vLLM numerically casts F32SF to E8M0. Fixed PyTorch GRS-RNE is not ceil, reinterpret or raw F32 multiplication:1.25->1,1.5->2,tinypositive->2^-127. The selected import rejects nonpositive/nonfinite source SF and rounded code255 before ready publication.',
          'Selected runtime reference keeps finite BF16 A unchanged. Decode signed E2M1 times BF16 E8scale to BF16 W before F32 dot and BF16 output; never substitute activation FP4 QDQ or MLX post-dot group scaling.',
          'Fixed deployment reader ignores micro/macro/OAS fields; its selected reference needs no macro math port. Original Inferact exporter, OAS generation and actual stored numeric scale values remain unverified.',
          'Cached Quark0.12.post1 decoder is a real dependency of the selected vLLM EMULATION reference, not evidence that Inferact was produced by Quark. SF255 and optional backend extremes are outside the selected equivalence.'],
        exact_reference_domain='Positive finite original F32SF -> GRS-RNE E8 codes0..254 cold; finite BF16 A, unchanged adjacent E2M1 weights; selected SF255 and nonfinite A fail. Legal finite decoded-W/dot overflow retains IEEE results. No hardware FP4 or universal reduction-bit equivalence.',
        minimum_next_implementation='Extend existing Mxfp4Linear/GroupedMxfp4Linear with explicit BF16 activation mode and cold F32-to-E8 scale import; reuse bounded selected-expert row/group decode and original resource/Invocation/status/capture chain. No new executor or E*N*K floating bank.',
        not_verified=['original Inferact exporter/OAS mathematical equivalence','actual numeric payload/calibration values','whole artifact import or model execution','quality','hardware native FP4 GEMM','throughput'],
        sources=[
          'https://huggingface.co/Inferact/Qwen3.8-2.4T-A95B-MXFP4/blob/98b8fd6c5dec37c28ff28e7a0f577677ccbdc49f/config.json',
          'https://github.com/vllm-project/vllm/blob/7b569ec8953cf8099638a6d2ee1e915b75867c3a/vllm/model_executor/layers/quantization/mxfp4.py',
          'https://github.com/pytorch/pytorch/blob/cf30153c4c131c8164ee7798e5022d810682e2cb/torch/headeronly/util/Float8_e8m0fnu.h'],
        detail_members=['design-review.json','runtime/routed_experts.py','runtime/moe_mxfp4.py','runtime/torch-Float8_e8m0fnu-fixed.h','artifact/assessment.json'],
        archive=ident(archive),archive_manifest=dict(member='archive-manifest.json',bytes=len(manifest_raw),sha256=sha(manifest_raw)),
        member_count=len(payloads),source_count=plan['source_files'],
        verification=dict(CRC_all_members=True,SHA256_all_payloads=True,safe_unique_member_paths=True))
    public_json=PUBLIC/(STEM+'.json');assert not public_json.exists()
    public_json.write_bytes(encoded(summary))
    receipt=dict(public_json=ident(public_json),public_zip=ident(archive),member_count=len(payloads),source_count=plan['source_files'],verified=True)
    (S/'package-receipt.json').write_bytes(encoded(receipt))
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
