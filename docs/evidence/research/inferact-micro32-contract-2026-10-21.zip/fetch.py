from pathlib import Path
import hashlib, json, sys, time, urllib.request

S = Path(__file__).resolve().parent

def ident(p):
    b = p.read_bytes()
    return dict(path=str(p.relative_to(S)).replace('\\', '/'), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def fetch(url, relative, limit=1048576):
    p = S / relative
    receipt = dict(url=url, maximum_body_bytes=limit, started=time.time(), tensor_payload_bytes=0)
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        req = urllib.request.Request(url, headers={'User-Agent':'hyle-read-only-contract/1','Accept-Encoding':'identity'})
        with urllib.request.urlopen(req, timeout=40) as r:
            receipt.update(status=r.status, headers={k:v for k,v in r.headers.items() if k.lower() in ['content-length','content-type','etag','last-modified','x-repo-commit']})
            n = r.headers.get('Content-Length')
            if n is not None and int(n) > limit:
                raise ValueError('Content-Length exceeds bounded source limit')
            b = r.read(limit+1)
            if len(b) > limit:
                raise ValueError('source exceeds bounded source limit')
        p.write_bytes(b)
        receipt['body'] = ident(p)
        return b
    except Exception as e:
        receipt['error'] = str(e)
        raise
    finally:
        receipt['finished'] = time.time()
        save(p.with_suffix(p.suffix+'.http.json'), receipt)

if __name__ == '__main__':
    data = fetch(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv)>3 else 1048576)
    print(json.dumps(dict(bytes=len(data), identity=ident(S/sys.argv[2]))))
