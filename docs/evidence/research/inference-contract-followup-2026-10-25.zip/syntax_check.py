"""One strict syntax-only app TU for finite variant dispatch completeness."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
spec = importlib.util.spec_from_file_location('cpu_recipe', ROOT / '.scratch/inference-duplicate-session-20261025/check_cpu.py')
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
assert recipe.ROOT == ROOT
recipe.WORK = WORK / 'verification'

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sha', required=True)
args = parser.parse_args()
call = argparse.Namespace(attempt='syntax1', phase='current', main_sha=args.sha,
    case_sha='1ad36aeddee338177167ac3232b7bc1d22130ad611b74df487493f39d9e0dbc7')
recipe.prepare(call)
attempt = recipe.WORK / call.attempt
plan = recipe.read(attempt / 'recipe.json')
frozen = recipe.read(attempt / 'frozen-source.json')
recipe.verify([entry['frozen'] for entry in frozen])
command = []
skip = False
for flag in plan['compile']:
    if skip:
        skip = False
        continue
    if flag == '/sourceDependencies':
        skip = True
        continue
    if flag.lower().startswith(('/fo', '/fd')):
        continue
    command.append(flag)
command.append('/Zs')
assert '/W4' in command and '/WX' in command
result = recipe.cached.execute(command, recipe.environment(command[0]), attempt / 'syntax', 120)
recipe.verify([entry['frozen'] for entry in frozen])
recipe.save(attempt / 'summary.json', {
    'status': 'STRICT_CPU_APP_TU_SYNTAX_ONLY_PASS', 'process': result,
    'main_source': plan['main_source'], 'case_source': plan['case_source'],
    'frozen_files': len(frozen), 'app_TUs': 1, 'core_provider_SDK_TUs': 0,
    'object_or_link_or_run': False, 'GPU': False, 'HTTP': 0,
    'command': command,
    'limits': 'Compile-time variant completeness and source equivalence only; no runtime, new codec, native GPU, MTP or performance qualification.'})
print('STRICT_CPU_APP_TU_SYNTAX_ONLY_PASS', result)
