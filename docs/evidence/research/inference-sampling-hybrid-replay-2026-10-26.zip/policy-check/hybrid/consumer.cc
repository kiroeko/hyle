#include "source/engine/models/qwen35/main.cc"
#include "../source/tests/tools/qwen_sampling_policy_case.h"
int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("policy INPUTS");return qwen_sampling_policy_case::run(argv[1],qwen35::ReplayPolicy::kPreferCapture);}catch(const std::exception &e){std::cerr<<"sampling_hybrid_case_failure="<<e.what()<<"\n";return 1;}}
