"""Two bounded original policy-helper CUDA behaviors, no throughput comparison."""
import importlib.util,json,os,re,shutil,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/inference-current-closure-20261026';D=W/'policy-check';SH=D/'source';REL='tests/tools/qwen_sampling_policy_case.h'
spec=importlib.util.spec_from_file_location('original_local_executor',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
pin,save,execute=h.pin,h.save,h.execute
def read(p):return json.loads(p.read_bytes())
def prepare():
 assert pin(R/'engine/models/qwen35/main.cc')['sha256']=='b346d408cdf8226b2df464f757483cc3aecd5b7c2f2d7f290751c7115d3cc44c'
 assert pin(R/'engine/inference/sampling_graph.h')['sha256']=='d066651db9acba82ca5b96d8f35ccceefd60e96c2c61e6e5040389f8f71485bb'
 assert pin(W/'source/engine/models/qwen35/main.cc')['sha256']=='7a2f85c1dd8e7f9866bd29c943676d672ddb93aaeb81b822d3726fd10b667952'
 SH.mkdir(parents=True,exist_ok=True)
 text=(R/REL).read_text(encoding='utf-8-sig')
 assert text.count('inline int run(const std::filesystem::path &input) {')==1
 text=text.replace('inline int run(const std::filesystem::path &input) {','inline int run(const std::filesystem::path &input, q::ReplayPolicy replay) {').replace('false, q::ReplayPolicy::kCommands, 1073741824','false, replay, 1073741824')
 needle='  preflight(model); boundaries(model, prompt, suffix);'
 assert text.count(needle)==1
 text=text.replace(needle,'''  std::size_t identity_phases = 0;
  for (auto &[key, phase] : model.phases) {
    if (key.requests != 2 || key.tokens != 1 || key.sampling_index == 0) continue;
    require(phase->sampling_identities.description.rank() == 3 &&
        phase->sampling_identities.description.dimensions()[0] == 2 &&
        phase->sampling_identities.description.dimensions()[1] == 3 &&
        phase->sampling_identities.description.dimensions()[2] == 4,
        "original random identity carrier is not [2,3,4]");
    std::array<std::uint32_t, 24> actual;
    q::check(model.execution.read(phase->sampling_identities.storage(), std::as_writable_bytes(std::span(actual))));
    const auto stream = key.sampling_index == 2 ? 2u : 4u;
    const auto first = q::cache::SamplingCursor{123, stream, 4}.identity();
    const auto second = q::cache::SamplingCursor{123, stream + 1, 4}.identity();
    const auto matches = [&](std::size_t row, const auto &expected) {
      for (std::size_t slot = 0; slot < 3; ++slot)
        if (!std::equal(expected.begin(), expected.end(), actual.begin() + row * 12 + slot * 4)) return false;
      return true;
    };
    require((matches(0, first) && matches(1, second)) || (matches(0, second) && matches(1, first)),
        "random final decode identity differs from original streams and draw4");
    ++identity_phases;
  }
  require(identity_phases == 2, "original random R2 policy phases were not actually used");
  std::cout << "sampling_hybrid_witness identity_phases=" << identity_phases << " final_draw=4 words=24" << '\\n';
  preflight(model); boundaries(model, prompt, suffix);''')
 p=SH/REL;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(text,encoding='utf-8')
 todo=['engine/models/qwen35/main.cc',REL];seen=set()
 while todo:
  rel=todo.pop()
  if rel in seen:continue
  seen.add(rel);dest=SH/rel;canonical=R/rel
  if not dest.exists():dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(canonical,dest)
  for m in re.finditer(r'^\s*#\s*include\s*(["<])([^">]+)[">]',dest.read_text(encoding='utf-8-sig'),re.M):
   name=m[2]
   if name.startswith('hyle/'):child=R/'include'/name
   elif m[1]=='"':child=(canonical.parent/name).resolve()
   else:continue
   if child.is_file() and child.is_relative_to(R) and not child.is_relative_to(R/'.scratch'):todo.append(str(child.relative_to(R)))
 save(D/'frozen-project-inputs.json',[pin(SH/rel) for rel in sorted(seen)])
def build(arm):
 prepare();out=D/(arm+'2');out.mkdir(parents=True,exist_ok=True);assert not (out/'ready.json').exists()
 main=out/'source/engine/models/qwen35/main.cc';main.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2((R if arm=='control' else W/'source')/'engine/models/qwen35/main.cc',main)
 policy='kCommands' if arm=='control' else 'kPreferCapture'
 driver=out/'consumer.cc';driver.write_text('#include "source/engine/models/qwen35/main.cc"\n#include "../source/tests/tools/qwen_sampling_policy_case.h"\nint main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("policy INPUTS");return qwen_sampling_policy_case::run(argv[1],qwen35::ReplayPolicy::'+policy+');}catch(const std::exception &e){std::cerr<<"sampling_hybrid_case_failure="<<e.what()<<"\\n";return 1;}}\n',encoding='utf-8')
 cmd=read(B/'engine/model/command.json')['command'];compiler=cmd[0]
 cmd=[str(driver) if x==str(R/'engine/models/qwen35/main.cc') else x for x in cmd]
 stage=out/('compile2' if (out/'compile').exists() else 'compile');obj=stage/'unit.obj';cmd[cmd.index('/sourceDependencies')+1]=str(stage/'dependencies.json')
 cmd=[('/Fo'+str(obj)) if x.startswith('/Fo') else ('/Fd'+str(stage/'unit.pdb')) if x.startswith('/Fd') else x for x in cmd]
 cmd[1:1]=['/I'+str(SH/'include'),'/I'+str(SH),'/I'+str(SH/'engine/models/qwen35')]
 env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
 compiled=execute(cmd,env,stage,timeout=120);dep=read(stage/'dependencies.json')['Data'];save(stage/'actual-dependencies.json',[pin(Path(p)) for p in dict.fromkeys([dep['Source'],*dep['Includes']])])
 orig=read(B/'link-current/process/command.json')['command'];entry=str(B/'engine/entry/unit.obj');model=str(B/'engine/model/unit.obj');assert orig.count(entry)==orig.count(model)==1
 args=[str(obj) if x==model else x for x in orig if x!=entry and not x.lower().startswith(('/out:','/pdb:','/implib:','/map:'))]
 save(out/'link-inputs.json',[pin(Path(x)) for x in args if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]);image=out/'link/component.exe';linked=execute([*args,'/OUT:'+str(image),'/PDB:'+str(image.with_suffix('.pdb'))],env,image.parent,timeout=120)
 native=Path(read(B/'ready-current.json')['native']['path']);os.link(native,image.parent/native.name)
 runtime=read(B/'runtime-current.json');runtime['PATH']=str(image.parent)+os.pathsep+runtime['PATH'];save(out/'runtime.json',runtime)
 fixture=R/'.scratch/inference-e4-model-20261025/fixture-preparation/bf16-original'
 save(out/'ready.json',{'image':pin(image),'main':pin(main),'header':pin(SH/'engine/inference/sampling_graph.h'),'helper':pin(SH/REL),'compile':compiled,'link':linked,'fixture':pin(fixture/'weights.tsv'),'runtime':pin(out/'runtime.json'),'replay':policy,'new_TUs':1,'SDK_builds':0})
 print('BUILT_NOT_RUN',arm,flush=True)
def run(arm):
 out=D/(arm+'2');ready=read(out/'ready.json');assert pin(Path(ready['image']['path']))==ready['image'];env=dict(os.environ);runtime=read(out/'runtime.json');env['PATH']=runtime['PATH'];env.update(runtime.get('configured_flags',{}));env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 process=execute([ready['image']['path'],str(Path(ready['fixture']['path']).parent)],env,out/'run',timeout=120)
 text=(out/'run/stdout.log').read_text(encoding='utf-8-sig');lines=text.splitlines();witness=next(l for l in lines if l.startswith('sampling_hybrid_witness'))
 report=json.loads(next(l for l in lines if l.startswith('{')));final=json.loads(next(l for l in reversed(lines) if l.startswith('{')));assert final['status']=='PASS' and final['configurations']==3 and final['requests']==6 and final['turns']==12
 cursors=[]
 for s in report['sessions']:
  r=s['result']
  if r['request_sampling']!='random':continue
  steps=s['ledger'];assert [x['sampling_draw_before'] for x in steps]==list(range(5));assert [x['sampling_draw_after'] for x in steps]==list(range(1,6))
  cursors.append({'session':s['session_id'],'stream':r['sampling_stream'],'draws':[x['sampling_draw_before'] for x in steps],'U32_keys':[[123^r['sampling_stream'],0,i,0] for i in range(5)],'final_draw':r['sampling_draw_cursor']})
 assert len(cursors)==4
 save(out/'report.json',report);save(out/'summary.json',{'status':'ORIGINAL_POLICY_FLOW_PASS','arm':arm,'process':process,'result':final,'witness':witness,'cursor_progress_and_expected_U32_keys':cursors,'ready':pin(out/'ready.json'),'GPU_released':True,'TPS_claim':False});print('GPU_TERMINAL_RELEASED',arm,process,witness,flush=True)
if __name__=='__main__':{'build':build,'run':run}[sys.argv[1]](sys.argv[2])
