"""Original-work comparison; only clock/per-rate JSON fields excluded."""
import ast,hashlib,json,re,sys
from pathlib import Path
W=Path(__file__).resolve().parent;D=W/'policy-check';R=W.parents[1]
def read(p):return json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=R/'.scratch/mtp-m2-typed-mmf-20261026/consumer/screen.py';tree=ast.parse(p.read_text(encoding='utf-8-sig'));ns={}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('normalize','differences')],type_ignores=[]),str(p),'exec'),ns)
prepared=re.compile(r'^prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=(\S+) capture_recorded=(\d+) capture_reused=(\d+)$')
results={}
for arm in ('control','hybrid'):
 out=D/(arm+'2');text=(out/'run/stderr.log').read_text(encoding='utf-8-sig');rows=[];phase=''
 for i,line in enumerate(text.splitlines()):
  if line.startswith('memory_phase='):phase=line[len('memory_phase='):]
  m=prepared.fullmatch(line)
  if m:rows.append({'line':i+1,'phase_marker':phase,'T':int(m[1]),'visible':int(m[2]),'route':m[3],'capture_recorded':int(m[5]),'capture_reused':int(m[6])})
 results[arm]={'summary':read(out/'summary.json'),'original_prepared_observations':rows,'report':read(out/'report.json'),'raw_stdout':pin(out/'run/stdout.log'),'raw_stderr':pin(out/'run/stderr.log')}
a,b=results['control'],results['hybrid'];delta=ns['differences'](ns['normalize'](a['report']),ns['normalize'](b['report']));save(D/'non-time-differences.json',delta)
random=lambda rows:[x for x in rows if re.search(r'generation_policy[2345]_',x['phase_marker'])]
baserows=random(a['original_prepared_observations']);newrows=random(b['original_prepared_observations'])
assert baserows and newrows and all(x['route']=='commands' for x in baserows)
assert any(x['route']=='hybrid' for x in newrows)
assert any(x['capture_reused']>0 and x['route']=='hybrid' for x in newrows)
assert not delta,delta[:3]
assert a['summary']['cursor_progress_and_expected_U32_keys']==b['summary']['cursor_progress_and_expected_U32_keys']
save(D/'comparison.json',{'status':'SAME_ORIGINAL_NON_TIME_WORK_HYBRID_AND_LIVE_IDENTITIES_PASS','normalization':pin(p),'normalization_scope':'Original clock/per-rate JSON exclusions only; no state/cache/work fields removed. Replay diagnostics intentionally differ and every original prepared observation is retained.','non_time_difference_count':len(delta),'differences':pin(D/'non-time-differences.json'),'actual_results':results,'limits':['One Commands and one explicit PreferCapture behavior, no latency/TPS comparison','Original sampling header d066, original three policies, no unfiltered R2 patch','Actual U32 identity buffers checked after completion while Tensor owner lives; replay reports are read only from original completion-time diagnostics, never after Invocation retirement.','Prepared logs can repeat per member; listed range counts are observations, not deduplicated GPU totals.','Native sampling capture=false/rejection unchanged; Graph segments surrounding eager gaps do replay.']})
print(json.dumps({'status':'PASS','non_time_differences':len(delta),'Commands_random_observations':len(baserows),'Hybrid_random_observations':sum(x['route']=='hybrid' for x in newrows),'Hybrid_random_reuse_observations':sum(x['capture_reused']>0 and x['route']=='hybrid' for x in newrows),'limits':'No TPS/latency conclusion; log observations can repeat per member.'},indent=2))
