"""Finalize the already-successful probe without recompiling or relaunching it."""
from pathlib import Path
import hashlib
import json
import subprocess

S = Path(__file__).resolve().parent
OUT = S / 'upstream-cuda-probe'

def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

assert not (OUT / 'receipt.json').exists()
plan = read(OUT / 'plan.json')
for frozen in plan['source_closure']:
    current = identity(frozen['path'])
    assert current['sha256'] == frozen['sha256'] and current['bytes'] == frozen['bytes']
compile_path = OUT / 'compile/compile-upstream-probe.result.json'
gpu_path = OUT / 'gpu/run-upstream-probe.result.json'
compile_result, gpu_result = read(compile_path), read(gpu_path)
assert compile_result['exit'] == gpu_result['exit'] == 0
assert compile_result['terminal'] and gpu_result['terminal']
assert compile_result['command'] == plan['command']
gpu_identity = subprocess.run(['nvidia-smi', '--query-gpu=name,uuid,driver_version,compute_cap',
    '--format=csv,noheader'], capture_output=True, text=True, check=True)
(OUT / 'hardware.csv').write_text(gpu_identity.stdout, encoding='utf-8')
save(OUT / 'receipt.json', dict(source_closure=plan['source_closure'],
    executable=identity(OUT / 'probe.exe'), compile_result=identity(compile_path),
    gpu_result=identity(gpu_path), observations=identity(OUT / 'observations.json'),
    hardware=identity(OUT / 'hardware.csv'), source_dependency_file=identity(OUT / 'probe.d'),
    scope='NVIDIA CUDA execution of unchanged retained producer QDQ/DQ templates; not AMD, Triton, whole artifact or Hyle support',
    compiler_successes=1, gpu_processes=1, Hyle_product_builds=0, SDK_builds=0,
    receipt_setup_failure=dict(
        phase='post-success receipt serialization', error='TypeError: c.execute returned a dict, not a path',
        prior_runner=identity(S / 'revisions/run_upstream_probe-before-receipt-type-fix.py'),
        corrected_runner=identity(S / 'run_upstream_probe.py'),
        recompiled=False, reran_GPU=False),
    finalizer=identity(__file__)))
print('Finalized one successful upstream compiler/link and one CUDA process; no rerun')
