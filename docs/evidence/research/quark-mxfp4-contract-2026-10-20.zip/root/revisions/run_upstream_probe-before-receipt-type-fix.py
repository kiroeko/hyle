"""Run the retained producer kernels without Torch or any Hyle product build."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
Q = S.parent
A = Q.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location(
    'quark_probe_helpers', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

out = S / 'upstream-cuda-probe'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
source = Q / 'producer/upstream_cuda_probe.cu'
assert source.is_file(), source
upstream = Q / 'producer/quark-012post1/quark/torch/kernel/hw_emulation/csrc'
frozen = [b.identity(source)] + [b.identity(p) for p in sorted((upstream / 'mxfp4').glob('*.cuh'))]
recipe_path = A / 'ct-local-nvfp4-reference/cuda/checks/attempt1/nvfp4-kernel-identity.json'
recipe = c.read(recipe_path)
host = c.read(A / 'ct-local-nvfp4-reference/cuda/checks/attempt1/nvfp4-provider-identity.json')
env, runtime = b.environment(host['command'], [], out)
command = [recipe['command'][0], '-std=c++20', '-O2', '-DUSE_CUDA',
    '--generate-code=arch=compute_89,code=[sm_89]',
    '-Xcompiler=/MD,/EHsc,/utf-8,/Zc:preprocessor',
    '-I' + str(upstream), '-MD', '-MF', str(out / 'probe.d'),
    str(source), '-o', str(out / 'probe.exe')]
c.save(out / 'plan.json', dict(command=command, source_closure=frozen,
    compiler_recipe=b.identity(recipe_path), scope='retained upstream standalone math only; no Torch/Hyle build'))
compile_job = out / 'compile'
compile_job.mkdir()
compile_result = c.execute('compile-upstream-probe', command, env, compile_job)
assert all(b.same(row) for row in frozen)
image = b.identity(out / 'probe.exe')
gpu_job = out / 'gpu'
gpu_job.mkdir()
run_result = c.execute('run-upstream-probe', [image['path']], env, gpu_job)
assert all(b.same(row) for row in frozen)
stdout = gpu_job / 'run-upstream-probe.stdout.log'
data = json.loads(stdout.read_text(encoding='utf-8'))
c.save(out / 'observations.json', data)
c.save(out / 'receipt.json', dict(source_closure=frozen, executable=image,
    compile_result=b.identity(compile_result), gpu_result=b.identity(run_result),
    observations=b.identity(out / 'observations.json'),
    scope='NVIDIA CUDA execution of retained default HIP/CUDA source; not an AMD/Triton/whole-artifact result',
    compiler_successes=1, gpu_processes=1, Hyle_product_builds=0, SDK_builds=0,
    runtime=runtime))
print(json.dumps(data, indent=2))
