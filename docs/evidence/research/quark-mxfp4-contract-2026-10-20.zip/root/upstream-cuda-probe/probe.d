C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/root/upstream-cuda-probe/probe.exe : C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/producer/upstream_cuda_probe.cu \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/producer/upstream_cuda_probe.cu \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_runtime.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_config.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/crtdefs.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/sal.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/concurrencysal.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vadefs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdarg \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/yvals_core.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xkeycheck.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdarg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/builtin_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_defines.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/ctype.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wctype.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/driver_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_types.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/limits.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stddef.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/surface_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/texture_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/library_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/channel_descriptor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_runtime_api.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_device_runtime_api.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stdlib.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_malloc.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_search.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstdlib.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/driver_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/common_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_defines.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/string.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_memory.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_memcpy_s.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/errno.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_string.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstring.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/time.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wtime.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/new \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/exception \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/yvals.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/crtdbg.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_new_debug.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_new.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/use_ansi.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdlib \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/math.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_math.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/type_traits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstddef \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xtr1common \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdint \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdint.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/malloc.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_exception.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/eh.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_terminate.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stdio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstdio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_stdio_config.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/assert.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/math_functions.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cmath \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/math_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_double_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_double_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_35_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_60_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_60_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_30_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_30_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_35_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_61_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_61_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_70_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_70_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_80_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_80_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_90_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_90_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_100_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_100_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/texture_indirect_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/surface_indirect_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/cudacc_ext.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_launch_parameters.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/utility \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/initializer_list \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/compare \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/concepts \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/producer/quark-012post1/quark/torch/kernel/hw_emulation/csrc/mxfp4/fake_kernels.cuh \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/climits \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/producer/quark-012post1/quark/torch/kernel/hw_emulation/csrc/mxfp4/low_precision_intrinsics.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_bf16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/target \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/detail/__target_macros \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/detail/__preprocessor \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp16.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_bf16.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdio \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdexcept \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xstring \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_sanitizer_annotate_container.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_string_view.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/iosfwd \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstring \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cwchar \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/wchar.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wconio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wdirect.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_share.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wprocess.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/sys/stat.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/sys/types.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin0.inl.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/setjmp.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/immintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/wmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/nmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/smmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/tmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/pmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/emmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/mmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/zmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ammintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xutility \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_iter_core.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xmemory \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/limits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cfloat \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/float.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin0.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xatomic.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/tuple \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xpolymorphic_allocator.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/type_traits \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/detail/__config \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/atomic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cccl_config \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/architecture.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/compiler.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/preprocessor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/assert.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/system_header.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/is_non_narrowing_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/attributes.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/diagnostic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/dialect.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/builtin.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/extended_data_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/cuda_toolkit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/execution_space.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/os.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/host_std_lib.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/version \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/prologue.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/epilogue.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/cuda_capabilities.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/deprecated.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/exceptions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/ptx_isa.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/rtti.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/sequence_access.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/unreachable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/version.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/visibility.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/features.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/cpp_dialect.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/namespaces.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/version.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/pstl_config.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/thread_api.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/iter_swap.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/concept_macros.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/declval.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/void_t.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/forward.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/integral_constant.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cstddef \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cstddef/byte.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_integral.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_cv.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_volatile.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cstddef/types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/version \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/swap.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/enable_if.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_move_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_lvalue_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_referenceable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_same.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_rvalue_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_void.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_cvref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_move_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/conjunction.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/conditional.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/disjunction.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_base_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_destructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_function.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_all_extents.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/negation.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_move_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_scalar.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_arithmetic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_floating_point.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_enum.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_member_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_member_function_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_null_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_move_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_swappable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/nat.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/type_identity.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/move.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_copy_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/identity.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/reference_wrapper.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/invoke.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/reference_wrapper.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/decay.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_array.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_extent.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_core_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_member_object_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/weak_result_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/binary_function.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/unary_function.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__memory/addressof.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/hash.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/pair.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_cv.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_volatile.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/aligned_storage.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/type_list.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/type_set.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/fold.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/integer_sequence.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/undefined.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/aligned_union.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/alignment_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/always_false.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/can_extract_key.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_const_ref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/common_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/common_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/copy_cvref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_extended_floating_point.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/copy_cv.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/dependent_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/extent.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/has_unique_object_representation.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/has_virtual_destructor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_abstract.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_aggregate.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_allocator.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_bounded_array.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_callable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_valid_expansion.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_char_like_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_standard_layout.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivial.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_class.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_compound.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_fundamental.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_constant_evaluated.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_copy_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_corresponding_member.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_empty.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_execution_policy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/execution_policy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cstdint \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_final.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_implicitly_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_integer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_signed_integer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_unsigned_integer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_layout_compatible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_literal_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/lazy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_copy_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_copy_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_destructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_object.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_union.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_one_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pod.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pointer_interconvertible_base_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pointer_interconvertible_with_class.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_polymorphic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_primary_template.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/iterator.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/iterator \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_scoped_enum.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/underlying_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_signed.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_copy_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_copy_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_copyable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_destructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_move_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_move_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_unbounded_array.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_unsigned.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_volatile.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_const_lvalue_ref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_nbit_int.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_signed.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_unsigned.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/maybe_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/num_bits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/complex.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/climits \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/promote.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/rank.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/reference_constructs_from_temporary.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/reference_converts_from_temporary.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/result_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/convert_to_integral.h \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/producer/quark-012post1/quark/torch/kernel/hw_emulation/csrc/mxfp4/mxfp4_format.cuh \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/producer/quark-012post1/quark/torch/kernel/hw_emulation/csrc/mxfp4/dequantize_kernels.cuh \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vector \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_bit_utils.hpp
