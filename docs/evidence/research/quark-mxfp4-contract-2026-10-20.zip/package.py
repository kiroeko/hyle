import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zlib
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
STEM = 'quark-mxfp4-contract-2026-10-20'
PUBLIC_DIR = ROOT / 'docs/evidence/research'
PUBLIC_JSON = PUBLIC_DIR / (STEM + '.json')
PUBLIC_ZIP = PUBLIC_DIR / (STEM + '.zip')
EXCLUDED_SUFFIXES = {
    '.exe', '.obj', '.o', '.lib', '.a', '.exp', '.pdb', '.ilk', '.map', '.pch', '.res',
    '.dll', '.so', '.dylib', '.metallib', '.air', '.spv', '.cubin', '.pyc', '.tmp', '.temp',
}
EXCLUDED_ROOT_NAMES = {'package-plan.json', 'package-receipt.json'}


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def load(relative):
    return json.loads((STAGE / relative).read_text(encoding='utf-8'))


def assert_safe(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '..' not in path.parts
    assert '\\' not in name and ':' not in name


def snapshot_product_sources():
    inventory = load('implementation/review.json')['source_inventory']
    assert len(inventory) == 47
    saved = []
    for item in inventory:
        relative = item['path']
        assert_safe(relative)
        source = ROOT / relative
        expected = {key: item[key] for key in ('bytes', 'sha256')}
        assert identity(source) == expected, f'Actual source drift: {relative}'
        destination = STAGE / 'implementation/source' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        raw = source.read_bytes()
        if destination.exists():
            assert destination.read_bytes() == raw, f'Existing retained source differs: {relative}'
        else:
            destination.write_bytes(raw)
        saved.append({'source': relative, 'member': destination.relative_to(STAGE).as_posix(), **expected})
    (STAGE / 'implementation/retained-source-inventory.json').write_bytes(encoded({
        'source_count': len(saved), 'all_actual_source_hashes_match_review': True, 'sources': saved,
        'scope': 'Read-only existing implementation snapshot for the reuse/gap review; not a Quark implementation or build',
    }))
    return saved


def collect():
    result = {}
    excluded = []
    for path in sorted(STAGE.rglob('*')):
        if not path.is_file():
            continue
        name = path.relative_to(STAGE).as_posix()
        if ('__pycache__' in path.parts or path.suffix.lower() in EXCLUDED_SUFFIXES
                or name in EXCLUDED_ROOT_NAMES or name.startswith('revisions/first-publication/')):
            excluded.append(name)
            continue
        assert_safe(name)
        assert name not in result
        result[name] = path.read_bytes()
    return result, excluded


def check_catalog_references(members):
    catalog = json.loads((ROOT / 'docs/implementation/model-quantizations.json').read_text(encoding='utf-8'))
    assert len(catalog['artifacts']) == 33
    assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in catalog['artifacts'])
    checked = []
    for index in (16, 23, 30):
        coverage = catalog['artifacts'][index]['provider_coverage']
        assert coverage['contract_research_evidence'] == PUBLIC_JSON.relative_to(ROOT).as_posix()
        for item in coverage['metadata_sources']:
            if item['archive'] != PUBLIC_ZIP.relative_to(ROOT).as_posix():
                continue
            raw = members[item['entry']]
            assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], item['entry']
            checked.append({'artifact': index, 'member': item['entry'], 'bytes': len(raw), 'sha256': sha(raw)})
    assert len(checked) == 11
    return checked


def write_zip(path, members):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(members.items()):
            entry = zipfile.ZipInfo(name, date_time=(2026, 10, 20, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o644 << 16
            archive.writestr(entry, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_zip(path, payloads, manifest_raw):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert set(names) == set(payloads) | {'archive-manifest.json'}
        assert archive.testzip() is None
        for name in names:
            assert_safe(name)
            raw = archive.read(name)
            expected = manifest_raw if name == 'archive-manifest.json' else payloads[name]
            assert raw == expected
            assert archive.getinfo(name).CRC == zlib.crc32(expected)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', action='store_true')
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    assert args.plan != args.publish, 'Use exactly one of --plan or --publish'
    assert identity(STAGE / 'implementation/review.json') == {
        'bytes': 48002, 'sha256': 'e91063abc538d8611399b01df400db73fe9d479fbd9974bae020068f4b818734',
    }, 'Root final implementation report freeze required'
    assert identity(STAGE / 'producer/review.json') == {
        'bytes': 15430, 'sha256': 'fd80829f59256f26715f860f955bddfbb3e6ecc7583ccc5b2173fade5801ddc9',
    }, 'Producer final report freeze required'
    sources = snapshot_product_sources()
    payloads, excluded = collect()
    references = check_catalog_references(payloads)
    required = (
        'artifact/review.json', 'artifact/artifact-facts.json', 'implementation/review.json',
        'producer/review.json', 'producer/amd_quark-0.12.post1-py3-none-any.whl',
        'root/upstream-cuda-probe/receipt.json', 'root/upstream-cuda-probe/observations.json',
        'root/revisions/run_upstream_probe-before-receipt-type-fix.py',
    )
    missing = [name for name in required if name not in payloads]
    plan = {
        'status': 'Ready to publish' if not missing else 'Prepared; awaiting final producer report',
        'missing_required_members': missing, 'payload_count': len(payloads),
        'payload_bytes': sum(map(len, payloads.values())), 'source_count': len(sources),
        'catalog_reference_count': len(references), 'excluded': excluded,
        'public_json': PUBLIC_JSON.relative_to(ROOT).as_posix(),
        'public_zip': PUBLIC_ZIP.relative_to(ROOT).as_posix(),
    }
    (STAGE / 'package-plan.json').write_bytes(encoded(plan))
    if args.plan:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
        return
    assert not missing, missing
    receipt = load('root/upstream-cuda-probe/receipt.json')
    assert receipt['compiler_successes'] == 1 and receipt['gpu_processes'] == 1
    assert receipt['Hyle_product_builds'] == 0 and receipt['SDK_builds'] == 0
    for phase in ('compile_result', 'gpu_result'):
        result_path = Path(receipt[phase]['path'])
        assert identity(result_path) == {key: receipt[phase][key] for key in ('bytes', 'sha256')}
        result = json.loads(result_path.read_text(encoding='utf-8'))
        assert result['exit'] == 0, (phase, result)
    manifest = {
        'format': 1,
        'status': 'Research complete; Hyle implementation not complete',
        'scope': 'Zero weight payload; pinned producer and header review, existing Hyle source snapshot and one upstream-template CUDA probe',
        'payload_count': len(payloads), 'source_count': len(sources),
        'catalog_metadata_references': references,
        'members': [
            {'path': name, 'bytes': len(raw), 'sha256': sha(raw), 'crc32': f'{zlib.crc32(raw):08x}'}
            for name, raw in sorted(payloads.items())
        ],
    }
    manifest_raw = encoded(manifest)
    PUBLIC_DIR.mkdir(parents=True, exist_ok=True)
    write_zip(PUBLIC_ZIP, payloads | {'archive-manifest.json': manifest_raw})
    verify_zip(PUBLIC_ZIP, payloads, manifest_raw)
    facts = load('artifact/artifact-facts.json')
    summary = {
        'schema_version': 1, 'observed_on': '2026-10-20',
        'status': 'Research complete; Hyle implementation not complete',
        'artifact_execution_verified': False,
        'scope': {
            'catalog_indices': [16, 23, 30], 'weight_payload_bytes_read': 0,
            'Hyle_product_builds': 0, 'Hyle_operation_tests': 0,
            'upstream_template_CUDA_compiler_successes': 1, 'upstream_template_CUDA_processes': 1,
            'not_verified': ['Hyle MXFP4 W4A4 implementation', 'complete importer/artifact/model execution', 'AMD HIP or Triton execution', 'hardware MXFP4 GEMM', 'quality', 'throughput'],
        },
        'artifacts': [
            {
                'catalog_index': item['catalog_index'], 'repository': item['repository'], 'revision': item['revision'],
                'fixed_config_url': f"https://huggingface.co/{item['repository']}/blob/{item['revision']}/config.json",
                'producer_version': item['producer_version'],
                'sampled_U8_weight_scale_pairs': item['sampled_paired_U8_weight_scale_roles'],
                'sampled_FP8_weight_scale_pairs': item['sampled_FP8_roles'],
                'detail_member': 'artifact/artifact-facts.json',
            }
            for item in facts['artifacts']
        ],
        'key_findings': [
            'Original packed weights are U8[N,K/2], adjacent even-K low/odd-K high; original E8M0 scales are U8[N,K/32]. Fixed Pack_fp4 ignores the reorder flag; do not import GGUF or MLX layouts.',
            'All25 retained wheel sources match the GLM fixed tag;24 of these match the Kimi fixed commit. Its sole config.py change adds a TwoBitScalar algorithm branch; retained MXFP4 numerical kernels, packing and dispatch are unchanged.',
            'Kimi sampled layer1 includes896 independent packed experts; excluded BF16 routed_expert_up/down_proj are distinct outer projections.',
            'GLM mixed config has924 exact FP8 overrides:871 MTP layer45 plus53 main roles; ordinary sampled experts are MXFP4 and preserved attention/router examples are BF16. It is not all-layer FP8.',
            'Default retained HIP, optional Triton and the Python even_round helper have different extreme/zero behavior. Their full domains are not interchangeable; the bounded upstream CUDA template probe is not a Hyle test.',
        ],
        'numerical_boundaries': {
            'normal': 'Pinned producer BF16 group32 quantization/reconstruction and packing supply the next reference contract; its BF16 intermediate rounding is substantive, not the existing MLX weight-only or ceil-scale roundtrip contract.',
            'selected_portable_reference_not_implemented': {
                'A_domain': 'Finite BF16 including subnormal and signed zero; source NaN/Inf fail checked Completion.',
                'scale': 'Round absmax BF16 bits by (bits+0x20)&0x7f80; rounded zero selects exponent-127, finite-to-Inf carry selects127, otherwise exact exponent minus2 clamped[-127,127]. No new epsilon floor.',
                'operands': 'BF16 divide, nearest-even saturating E2M1 with sign bits preserved, BF16 reconstruction; original W scale codes0..254 decode2^(code-127) followed by BF16 code product.',
                'invalid_scale': 'Original W scale255 fails checked Completion; legal finite-input intermediate Inf/NaN remain ordinary IEEE results.',
                'boundary': 'This explicitly selected mathematical reference does not preserve undefined log2(0)-to-int behavior, upstream tiny-subnormal loss or optional-Triton differences. No Hyle implementation exists in this research package.',
            },
            'extreme': 'Zero, subnormal, maximum finite and nonfinite diagnostics plus scale-code raw bits are retained. Normal/tie observations and extreme outcomes define the scope; no all-finite bit identity to upstream HIP, AMD hardware or optional Triton is asserted.',
            'detail_member': 'producer/review.json',
            'raw_upstream_probe_member': 'root/upstream-cuda-probe/observations.json',
        },
        'next_implementation': (
            'Implement an explicit BF16 group32/E8M0 software reference on original three/four-port packed banks, sharing existing '
            'per-backend FP4 traversal/status. Preserve existing ModelOpt/Local semantics, once-per-token shared-activation QDQ, '
            'selected-ID checks and bounded W tiles; do not materialize E*N*K floating banks or add an executor. '
            'Exact role/import binding and the separate FP8 branches remain follow-up work.'
        ),
        'detail_members': ['artifact/review.json', 'producer/review.json', 'implementation/review.json', 'implementation/retained-source-inventory.json', 'root/upstream-cuda-probe/receipt.json'],
        'metadata_request_counts': facts['network_counts'],
        'archive': {'path': PUBLIC_ZIP.relative_to(ROOT).as_posix(), **identity(PUBLIC_ZIP)},
        'archive_manifest': {'member': 'archive-manifest.json', 'bytes': len(manifest_raw), 'sha256': sha(manifest_raw)},
        'member_count': len(payloads) + 1,
        'retained_current_source_count': len(sources),
        'verification': {'CRC_all_members': True, 'SHA256_all_payloads': True, 'safe_unique_member_paths': True, 'catalog_metadata_members_exact': len(references)},
    }
    PUBLIC_JSON.write_bytes(encoded(summary))
    public = json.loads(PUBLIC_JSON.read_text(encoding='utf-8'))
    assert public['archive'] == {'path': PUBLIC_ZIP.relative_to(ROOT).as_posix(), **identity(PUBLIC_ZIP)}
    assert public['archive_manifest']['sha256'] == sha(manifest_raw)
    report = {
        'status': 'Published and verified', 'json': {'path': PUBLIC_JSON.relative_to(ROOT).as_posix(), **identity(PUBLIC_JSON)},
        'zip': public['archive'], 'member_count': len(payloads) + 1, 'source_count': len(sources),
        'payload_count': len(payloads), 'payload_bytes': sum(map(len, payloads.values())),
        'catalog_metadata_member_count': len(references), 'checks': public['verification'], 'excluded': excluded,
    }
    (STAGE / 'package-receipt.json').write_bytes(encoded(report))
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
