from pathlib import Path
import concurrent.futures,importlib.util,json,struct,shutil,sys
sys.dont_write_bytecode=True
R=Path.cwd();S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('quark_header_helpers',S/'fetch.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
ROWS=[(16,'amd/Qwen3.8-2.4T-A95B-Quark-MXFP4','13dc9676cdd9e2374c3efb50389d3392b975acae','model-00002-of-00213.safetensors'),(23,'amd/Kimi-K3-Quark-MXFP4-AttnFP8','398ecc22db3722ed6e416d22f8ddb491da32d566','model-00002-of-000096.safetensors'),(30,'amd/GLM-5.3-Flash-Quark-MXFP4','b5688f25491202978c19c4d036eef579f61bbe07','model-00001-of-00062.safetensors')]
def one(row):
 i,repo,rev,file=row;d=S/str(i);d.mkdir(parents=True,exist_ok=True)
 if i==30:
  shutil.copyfile(R/'.scratch/model-quantization-discovery-2026-10-19/deepseek-glm'/repo.replace('/','--')/'api.json',d/'api-model.json')
  h.h.fetch(f'https://huggingface.co/{repo}/resolve/{rev}/config.json',d/'fixed-config.json',3*1024*1024);shutil.copyfile(d/'fixed-config.json',d/'config.json')
  h.h.fetch(f'https://huggingface.co/{repo}/resolve/{rev}/README.md',d/'README.md',100_000)
 base=f'https://huggingface.co/{repo}/resolve/{rev}/{file}';dest=d/file
 length=struct.unpack('<Q',h.h.fetch(base+'?download=true&hyle_quark_range=0-7',dest/'length.bin',8,0,7))[0];assert 2<=length<=2_000_000,length
 head=json.loads(h.h.fetch(base+f'?download=true&hyle_quark_range=8-{length+7}',dest/'header.json',length,8,length+7))
 summary=dict(artifact_index=i,repository=repo,revision=rev,file=file,header=h.h.identity(dest/'header.json'),tensor_count=len(head)-('__metadata__'in head),tensor_payload_bytes=0)
 h.h.save(dest/'summary.json',summary);print(json.dumps(summary),flush=True);return summary
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:rows=list(p.map(one,ROWS))
h.h.save(S/'additional-header-summary.json',rows)
