from pathlib import Path
import importlib.util,sys,re,json,struct
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('quark_fetch',S/'fetch.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
repo='amd/GLM-5.3-Flash-Quark-MXFP4';rev='b5688f25491202978c19c4d036eef579f61bbe07';d=S/'30'
u=f'https://huggingface.co/{repo}/resolve/{rev}/model.safetensors.index.json';b=h.h.fetch(u+'?download=true&hyle_quark_index_prefix=0-262143',d/'index-prefix-262144.jsonpart',262144,0,262143)
pairs=re.findall(rb'"([^"]+)"\s*:\s*"([^"]+\.safetensors)"',b)
chosen=[]
for key,file in pairs:
 name=key.decode();f=file.decode()
 if re.search(r'layers\.(?:[3-9]|[1-3]\d|4[0-4])\.mlp\.experts\.0\.(gate_proj|down_proj)\.weight$',name):chosen.append((name,f))
assert chosen,('No regular expert in bounded indexprefix',len(pairs))
name,file=chosen[0];dest=d/file;base=f'https://huggingface.co/{repo}/resolve/{rev}/{file}'
length=struct.unpack('<Q',h.h.fetch(base+'?download=true&hyle_quark_range=0-7',dest/'length.bin',8,0,7))[0];assert length<=2_000_000
head=json.loads(h.h.fetch(base+f'?download=true&hyle_quark_range=8-{length+7}',dest/'header.json',length,8,length+7))
summary=dict(repository=repo,revision=rev,selected_role=name,file=file,index_prefix=h.h.identity(d/'index-prefix-262144.jsonpart'),header=h.h.identity(dest/'header.json'),tensor_payload_bytes=0,matching_prefix_roles=chosen[:12])
h.h.save(d/'regular-role-location.json',summary);print(json.dumps(summary))
