from pathlib import Path
import json,hashlib,collections,re
R=Path.cwd();S=Path(__file__).resolve().parent
CONFIGS={16:('amd/Qwen3.8-2.4T-A95B-Quark-MXFP4','13dc9676cdd9e2374c3efb50389d3392b975acae'),23:('amd/Kimi-K3-Quark-MXFP4-AttnFP8','398ecc22db3722ed6e416d22f8ddb491da32d566'),30:('amd/GLM-5.3-Flash-Quark-MXFP4','b5688f25491202978c19c4d036eef579f61bbe07')}
def identity(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def layer(k):
 m=re.search(r'layers\.(\d+)',k);return m.group(1) if m else 'other'
rows=[]
for i,(repo,rev) in CONFIGS.items():
 d=S/str(i);config=json.loads((d/'config.json').read_text(encoding='utf-8'));q=config['quantization_config'];heads=sorted(d.glob('model*.safetensors/header.json'));combined={};locations={}
 for p in heads:
  for k,v in json.loads(p.read_bytes()).items():
   if k=='__metadata__':continue
   assert k not in combined,k;combined[k]=v;locations[k]=p.parent.name
 paired={k[:-7]:(v,combined.get(k[:-7]+'.weight_scale')) for k,v in combined.items() if k.endswith('.weight') and k[:-7]+'.weight_scale' in combined}
 packed={k:(w,sf) for k,(w,sf) in paired.items() if w['dtype']=='U8' and sf['dtype']=='U8'}
 fp8={k:(w,sf) for k,(w,sf) in paired.items() if w['dtype']=='F8_E4M3'}
 schema=[]
 for name,(w,sf) in packed.items():
  if len(w['shape'])!=2 or sf['shape']!=[w['shape'][0],w['shape'][1]//16]:schema.append(name)
 shapes=collections.Counter((w['shape'][0],w['shape'][1]*2,tuple(sf['shape'])) for w,sf in packed.values())
 override=q.get('layer_quant_config') or {};overlayers=collections.Counter(layer(k) for k in override)
 examples={k:{'weight':w,'scale':sf,'file':locations[k+'.weight']} for k,(w,sf) in packed.items() if ('.experts.0.' in k or '.shared_experts.' in k or (i==23 and '.layers.0.mlp.' in k))}
 row=dict(catalog_index=i,repository=repo,revision=rev,config=identity(d/'config.json'),fixed_config=identity(d/'fixed-config.json'),config_matches_existing_cache=True if i!=30 else 'New bounded fixedrevision metadata; previous cache APIonly',producer_version=q['version'],model_dtype=config.get('dtype'),export=q['export'],global_quant_config=q['global_quant_config'],excluded_count=len(q['exclude']),exclude_examples=q['exclude'][:12],layer_override_count=len(override),layer_override_counts_by_layer=dict(overlayers),layer_override_format_counts=[{'weight_dtype':a,'weight_qscheme':b,'count':n} for (a,b),n in collections.Counter((x['weight']['dtype'],x['weight']['qscheme']) for x in override.values()).items()],headers=[identity(p) for p in heads],sampled_tensors=len(combined),sampled_paired_U8_weight_scale_roles=len(packed),physical_group32_schema_consistent=not schema,schema_mismatches=schema,packed_role_counts_by_layer=dict(collections.Counter(layer(k) for k in packed)),packed_shapes=[dict(logical_N=n,logical_K=k,scale_shape=list(sf),role_count=count) for (n,k,sf),count in shapes.items()],sampled_FP8_roles=len(fp8),FP8_shapes=[dict(weight_dtype=a,weight_shape=list(b),scale_dtype=c,scale_shape=list(d),roles=n) for (a,b,c,d),n in collections.Counter((w['dtype'],tuple(w['shape']),sf['dtype'],tuple(sf['shape'])) for w,sf in fp8.values()).items()],packed_examples=examples,extra_layout_metadata_tensors=[k for k in combined if any(x in k for x in ['g_idx','perm','weight_shape','reorder'])],payload_bytes=0,reorder_limitation='Headers alone do not prove nibble order. Fixed producer Pack_fp4 source establishes adjacent evenK low/oddK high and ignores reorder; see review.json source proof. No numeric weight bytes inspected.')
 if i==16:
  row['role_scope']='Exactly all512experts gate/up/down in layer0 across sampled first2shards:1536 pairs. Excluded FP8-base attention/shared/head roles are named byconfig/card, not observed in these2expert-only shards.'
 elif i==23:
  row['role_scope']='Layer0 ordinarydense MLP3; layer1 independentexperts896*3 and sharedexperts3 packed pairs. Outer routed_expert_up/down projections are excluded BF16 and are distinct from expert.w1/w2/w3.'
  keep=['language_model.model.layers.1.block_sparse_moe.routed_expert_down_proj.weight','language_model.model.layers.1.block_sparse_moe.routed_expert_up_proj.weight','language_model.model.layers.1.block_sparse_moe.gate.weight']
  row['preserved_excluded_examples']={k:combined[k] for k in keep};row['publisher_emulation_note']='FixedREADME instructs self.emulate=True in deployment example; that is not hardwareMXFP4 GEMM evidence.'
 else:
  row['role_scope']='Firstshard mostlypreserved/overridden FP8 MTP layer45; exact indexprefix locates regular layer22 expert0 toshard19, which contains606 packedroles acrosslayers21/22 plus preservedBF16 nodes. Not all62shards inspected.'
  row['regular_role_location']=identity(d/'regular-role-location.json');row['prior_API_only_resolved']='New fixed1716060Bconfig identifies QuarkMXFP4 W4A4 g32 even plus924 FP8overrides,871MTP and53main; actualregular MXFP4 header confirms this family. Config remains metadata, not tensorvalue or execution proof.'
  row['preserved_excluded_examples']={k:v for k,v in combined.items() if v['dtype']=='BF16' and any(x in k for x in ['self_attn','mlp.gate.weight'])}
 rows.append(row)
summary=dict(status='Pinned metadata/headers only; no product/docs changes/build/GPU/weightpayload',artifacts=rows,all_current_catalog_Quark_repositories=[dict(catalog_index=i,repository=a['repository'],revision=a['revision']) for i,a in enumerate(json.loads((R/'docs/implementation/model-quantizations.json').read_text(encoding='utf-8'))['artifacts']) if 'quark' in a.get('repository','').lower()],source_catalog=identity(R/'docs/implementation/model-quantizations.json'),network_counts=dict(safetensors_header_files=sum(len(x['headers']) for x in rows),safetensors_header_bytes=sum(p.stat().st_size for p in S.glob('*/model*.safetensors/header.json')),safetensors_length_prefix_bytes=8*sum(len(x['headers']) for x in rows),fixed_config_bytes=sum((S/str(i)/'fixed-config.json').stat().st_size for i in CONFIGS),index_prefix_bytes=262144,tensor_payload_bytes=0),unknowns=['Originalscale numericcodes/invalid specialvalues uninspected','Numeric payload/order was not sampled, but fixedproducer Pack_fp4 establishes the same adjacentlowfirst mapping for the selected versions','Exclusion/override precedence must resolve actualmodule names; no all-role model support claim','Hardware/kernel/quality/throughput and allshards untested'])
(S/'artifact-facts.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(identity(S/'artifact-facts.json')))
