from pathlib import Path
import json,hashlib
R=Path.cwd();S=Path(__file__).resolve().parent;P=S.parent/'producer'
def ident(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
facts=json.loads((S/'artifact-facts.json').read_text(encoding='utf-8'));pack=P/'quark-012post1/quark/torch/utils/pack.py';lines=pack.read_text(encoding='utf-8').splitlines()
report={
 'status':'Fixed Quark artifact headers/configs researched; no product/public-doc edits, build, GPU or weightpayload read.',
 'sufficient_to_design_physical_ports':True,
 'artifact_facts':ident(S/'artifact-facts.json'),
 'catalog_scope':[16,23,30],
 'artifacts':[dict(catalog_index=a['catalog_index'],repository=a['repository'],revision=a['revision'],producer_version=a['producer_version'],fixed_config=a['fixed_config'],export=a['export'],headers=a['headers'],sampled_paired_U8_roles=a['sampled_paired_U8_weight_scale_roles'],U8_role_counts_by_layer=a['packed_role_counts_by_layer'],packed_shapes=a['packed_shapes'],role_scope=a['role_scope'],sampled_FP8_roles=a['sampled_FP8_roles']) for a in facts['artifacts']],
 'source_packing_proof':{
  'artifact16':'Exact PyPI amd-quark0.12.post1 wheel, fixed producer/primary-source-identities.json.',
  'artifact23_commit':'2fba630fc87e35b32ed42bb09ddce7d0d35f1562',
  'artifact30_tag_commit':'1b229f781a1974cc742884e42d8eefc1eebb4f0a',
  'pack_fp4_source':ident(pack),'source_URLs':['https://github.com/amd/Quark/blob/2fba630fc87e35b32ed42bb09ddce7d0d35f1562/quark/torch/utils/pack.py','https://github.com/amd/Quark/blob/1b229f781a1974cc742884e42d8eefc1eebb4f0a/quark/torch/utils/pack.py'],
  'line_anchors':{needle:[i+1 for i,l in enumerate(lines) if needle in l] for needle in ['class Pack_fp4','def pack(self, tensor: torch.Tensor, reorder: bool)','tensor = (tensor[..., 1] << 4) + tensor[..., 0]','unpacked[:, 1::2]','unpacked[:, ::2]']},
  'parallel_producer_manifest':ident(P/'primary-source-identities.json'),'GLM_tag_blob_comparison':ident(P/'tag-1b229f7-source-comparison.json'),
  'conclusion':'Selected plainfp4 Pack_fp4 packs evenK in low nibble, oddK in high nibble and ignores its reorder argument. Source bodies are equal across the pinned versions and GLMtag comparison. Reorder metadata does not require importing the different Pack_mxfp4/GGUF/MLX layouts. Scale carrier is originalU8[N,K/32], interpretedE8M0 from fixedconfig/export source, not F32 global scales.'},
 'role_corrections':[
  '16 first2headers contain exactly512 layer0expert banks, eachgate/up/down:1536 U8weight/U8scale pairs. gate/up logicalN2048/K8192, downN8192/K2048. Excluded attention/shared/head stay separately listed; their baseFP8 contract was not directly inspected in these2expert-only shards.',
  '23 actualfirst2headers contain layer0dense3 +layer1expert896*3 +shared3 =2694U8pairs. Expertw1/w3 logicalN3072/K3584, w2N3584/K3072, reflecting the preceding routingprojection. Excluded routed_expert_up/down_proj names are separate BF16 matrices that map7168<->3584; they are not the896 independentexperts. RouterBF16 too. Self_attn8roles perlayer are E4M3+F32[N]channelSF; activationaxis semantics remain their separateFP8 contract.',
  '30 previousAPI-only is resolved with exact1716060Bconfig and boundedheaders. GlobalMXFP4 W4A4 g32/E8M0/even;924FP8overrides include871layer45MTP and53main roles, plus626exclusions. Firstshard shows329FP8pairs; indexprefix256KiB locates regularlayer22 toshard19, which has606U8pairs acrosslayers21/22 withoriginalBF16attention/router nodes. Do not classify its entire checkpoint as onlyMXFP4.'
 ],
 'minimal_current_document_changes':{
  'model_quantizations_16':'Replace unknownU8packing/scale representation with pinned originalU8[N,K/2]+U8E8M0[N,K/32] and source-proven adjacentlowfirst. Keep even-scale dynamicA4 arithmetic/implementation execution missing, and excludedbaseFP8roles conditional until their own metadata/math aligned.',
  'model_quantizations_23':'Same rawpacking update; correct role wording to BF16outer routed_expert_up/down_proj versus896independentMXFP4experts; keep exactFP8attention axis/scaling separate and not certified by MXFP4 work.',
  'model_quantizations_30':'Change codec_domain/config_evidence fromunknownAPI-only to observed mixedQuarkMXFP4group32even +FP8block128/group128overrides +BF16exclusions, with source/version/header links and precise924/871/53 counts. Fixedconfig is a known metadata contract, not new artifactexecution.',
  'all_three':'Keep artifact_execution_verified=false; keep full-shard/importer/quantizer/deployment/quality/throughput unverified. No supported-format claim until the reference/math package is implemented and run.',
  'model_operators_and_current_work':'One short Quark research reference can replace stale packing-unknown wording and list remaining group32even A4 numerical behavior/selectedrolebinding. Do not copy the full process or create a new rule document.'},
 'natural_next_scope':[
  'Original3ports A/packedW/E8M0SF can support dense and selectedexpert references after producer even-scale/FP4-round/accumulator boundaries are fixed. Reuse boundedtile and per-row A_QDQ mechanisms; no need newexecutor, fullNKfloatbank, model whitelist or producer-version switch.',
  'Single-expert files are distinct original spans. Largebank/4GiB limits and futurecatalogWeightSlots remain explicit integration work; combining thousands ofspan identities into one fictitious densebank is not established.',
  'This artifact review does not choose the exact runtime exceptional-domain or hardwarescaled-MXFP4 policy; producer owner independently defines those math boundaries and failure semantics.'
 ],
 'network_counts':facts['network_counts'],
 'unknowns':['No originalnumeric codes/scales read, so E8M0specialvalues or actualcalibrateddistributions are unknown.','Only selectedheaders; not every213/96/62shard or fullartifactbasepin verified.','Exactdynamic scale-even and operandrounding deploymentequivalence belongs to producerreview/reference design, not mere group32naming.','No nativehardwareW4A4GEMM, kernel/performance/quality or wholemodel support claim.'],
 'initial_request_error':{'kind':'One GLMregularheader8byteprefix TLS EOF before response; retry succeeded,0payload. Not a format/compiler/GPU failure.','receipt':ident(S/'30/model-00019-of-00062.safetensors/length.bin.first-error.http.json')},
 'artifact_file_inventory':[ident(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name not in ['review.json','write_review.py']]
}
(S/'review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(ident(S/'review.json')))
