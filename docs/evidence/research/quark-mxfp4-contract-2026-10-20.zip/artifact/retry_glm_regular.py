from pathlib import Path
import importlib.util,sys,re,json,struct,shutil
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('quark_fetch',S/'fetch.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
d=S/'30';b=(d/'index-prefix-262144.jsonpart').read_bytes();pairs=re.findall(rb'"([^"]+)"\s*:\s*"([^"]+\.safetensors)"',b);chosen=[(k.decode(),v.decode()) for k,v in pairs if re.search(rb'layers\.(?:[3-9]|[1-3]\d|4[0-4])\.mlp\.experts\.0\.(gate_proj|down_proj)\.weight$',k)];name,file=chosen[0];dest=d/file
prior=dest/'length.bin.http.json';assert not (dest/'length.bin.first-error.http.json').exists();shutil.copyfile(prior,dest/'length.bin.first-error.http.json')
repo='amd/GLM-5.3-Flash-Quark-MXFP4';rev='b5688f25491202978c19c4d036eef579f61bbe07';base=f'https://huggingface.co/{repo}/resolve/{rev}/{file}'
length=struct.unpack('<Q',h.h.fetch(base+'?download=true&hyle_quark_range=0-7&retry=1',dest/'length.bin',8,0,7))[0];assert length<=2_000_000
head=json.loads(h.h.fetch(base+f'?download=true&hyle_quark_range=8-{length+7}',dest/'header.json',length,8,length+7))
summary=dict(repository=repo,revision=rev,selected_role=name,file=file,index_prefix=h.h.identity(d/'index-prefix-262144.jsonpart'),header=h.h.identity(dest/'header.json'),tensor_payload_bytes=0,matching_prefix_roles=chosen[:12],initial_tls_error_retained=h.h.identity(dest/'length.bin.first-error.http.json'))
h.h.save(d/'regular-role-location.json',summary);print(json.dumps(summary))
