import copy
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[5]
STAGE = Path(__file__).resolve().parent
ARTIFACT = STAGE.parent
TARGET = ROOT / 'docs/implementation/model-quantizations.json'
PUBLIC_JSON = 'docs/evidence/research/quark-mxfp4-contract-2026-10-20.json'
PUBLIC_ZIP = 'docs/evidence/research/quark-mxfp4-contract-2026-10-20.zip'


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def source(relative):
    path = ARTIFACT / relative
    return {
        'archive': PUBLIC_ZIP,
        'entry': 'artifact/' + relative,
        'present_in_original_snapshot': False,
        **identity(path),
    }


before_raw = TARGET.read_bytes()
before_path = STAGE / 'before/model-quantizations.json'
before_path.parent.mkdir(parents=True, exist_ok=True)
if before_path.exists():
    assert before_path.read_bytes() == before_raw, 'Refuse overwriting an existing different before snapshot'
else:
    before_path.write_bytes(before_raw)
before = json.loads(before_raw)
after = copy.deepcopy(before)
facts = json.loads((ARTIFACT / 'artifact-facts.json').read_text(encoding='utf-8'))
fact_by_index = {entry['catalog_index']: entry for entry in facts['artifacts']}
expected_repos = {
    16: 'amd/Qwen3.8-2.4T-A95B-Quark-MXFP4',
    23: 'amd/Kimi-K3-Quark-MXFP4-AttnFP8',
    30: 'amd/GLM-5.3-Flash-Quark-MXFP4',
}

packing = (
    'Pinned Quark Pack_fp4 stores adjacent even-K code in the low nibble and odd-K code in the high nibble, '
    'in U8[N,K/2]; original E8M0 scale bytes are U8[N,K/32]. Pack_fp4 ignores its reorder argument in '
    'the three inspected producer versions. This is not the separate Pack_mxfp4, GGUF block or MLX U32 layout.'
)
for index, repository in expected_repos.items():
    row = after['artifacts'][index]
    fact = fact_by_index[index]
    assert row['repository'] == repository
    assert row['revision'] == fact['revision']
    coverage = row['provider_coverage']
    coverage['review'] = 'pinned_config_header_and_producer_source_review'
    coverage['review_scope'] = (
        'Fixed-revision config, bounded safetensors headers and pinned Quark producer source; no numeric '
        'weight/scale payload, build, Hyle operation execution, importer binding or whole artifact execution in this review'
    )
    coverage['artifact_execution_verified'] = False
    metadata_sources = coverage.setdefault('metadata_sources', [])
    metadata_sources.append(source(f'{index}/fixed-config.json'))
    for header in fact['headers']:
        relative = Path(header['path']).relative_to(ARTIFACT.relative_to(ROOT)).as_posix()
        metadata_sources.append(source(relative))
    coverage['contract_research_evidence'] = PUBLIC_JSON
    coverage['pinned_producer'] = {
        'name': 'amd-quark',
        'version': fact['producer_version'],
        'source_identity': (
            'Exact PyPI amd-quark 0.12.post1 wheel'
            if index == 16 else
            '2fba630fc87e35b32ed42bb09ddce7d0d35f1562'
            if index == 23 else
            '1b229f781a1974cc742884e42d8eefc1eebb4f0a'
        ),
        'packing_contract': packing,
        'source_evidence': PUBLIC_JSON,
        'execution_boundary': (
            'Pinned producer source establishes metadata and packing semantics; default HIP and optional Triton '
            'quantization paths are not assumed numerically interchangeable and were not run by this header review.'
        ),
    }
    coverage['header_observations'] = {
        'sampled_shards': [Path(item['path']).parent.name for item in fact['headers']],
        'u8_weight_scale_pairs': fact['sampled_paired_U8_weight_scale_roles'],
        'u8_pairs_by_layer': fact['packed_role_counts_by_layer'],
        'logical_shapes_and_role_counts': fact['packed_shapes'],
        'fp8_weight_scale_pairs': fact['sampled_FP8_roles'],
        'payload_bytes_read': 0,
        'scope': fact['role_scope'],
    }

row = after['artifacts'][16]
c = row['provider_coverage']
row['notes'] = (
    'Fixed Quark 0.12.post1 config and layer0 headers establish original U8 packed FP4/E8M0 group32 banks; '
    'card starts from the official FP8 variant. Pack_fp4 source resolves adjacent low/high nibble order despite reorder metadata.'
)
c['mapping_status'] = (
    'Original U8 weight/E8M0 scale layout and source packing established; no Hyle Quark group32 even-scale dynamic W4A4 '
    'execution/import mapping yet. Excluded base FP8 roles remain separately unaligned.'
)
c['required_format_domain'] = (
    'Quark group32 static FP4 weights and dynamic FP4 activations, E8M0 even scale calculation and half-even rounding; '
    'U8[N,K/2] adjacent-nibble weights and U8[N,K/32] scales. Base claim is official FP8; 977 exclusions retain separate source roles.'
)
c['role_domains'] = [
    {
        'role': 'sampled routed expert weights',
        'observed': 'Layer0 all512 experts gate/up/down: 1536 U8 weight/scale pairs; gate/up logical N2048 K8192, down N8192 K2048; original per-expert banks remain separate tensors',
    },
    {
        'role': 'activations',
        'observed': 'Config declares dynamic fp4 per_group axis-1 group32, E8M0 even scales and half_even; this is W4A4, not weight-only MLX MXFP4',
        'unresolved': 'No Hyle exact quantizer/kernel execution or producer deployment-path equivalence established',
    },
    {
        'role': 'excluded/base roles',
        'observed': '977 exclusions and official FP8 base claim retained in fixed config/card',
        'unresolved': 'The two sampled expert-only headers do not establish actual excluded attention/shared/head tensor formats or exact FP8 quantization contracts',
    },
]
c['artifact_unaligned_or_unverified'] = [
    'Pinned source resolves U8 adjacent nibble packing and original E8M0 carrier; numeric codes/scales and calibrated distributions were not read',
    'Group32 even-scale dynamic A4 arithmetic and bounded dense/grouped Hyle execution remain to implement; no whole-bank floating expansion is an acceptable substitute',
    'MLX U32 MXFP4 with ordinary floating activation, ceil-power-of-two BlockQuantizationRoundtrip and FP4-weight/FP8-activation GroupedFloat4Linear are different contracts',
    'Excluded base FP8/BF16 roles, all213 shards, importer binding and whole artifact execution remain unverified',
]
c['missing_capabilities'] = [
    'Quark group32 E8M0 even-scale dynamic A4 numerical path with original U8 packed dense/grouped weights',
    'Exact selected artifact role binding and separate excluded-base FP8 contract alignment',
]

row = after['artifacts'][23]
c = row['provider_coverage']
row['notes'] = (
    'Fixed Quark 0.13+2fba630fc87 config/source and two headers establish U8 MXFP4 banks for dense/shared and 896 independent '
    'layer1 experts; excluded outer routed_expert_up/down_proj remain BF16. Attention E4M3 channel scales are a separate contract.'
)
c['mapping_status'] = (
    'Original U8 MXFP4/E8M0 packing and sampled dense/shared/independent expert roles established; Hyle Quark even-scale '
    'dynamic W4A4 execution and exact per-channel attention FP8 binding are still missing.'
)
c['required_format_domain'] = (
    'Quark static FP4 W/dynamic FP4 A group32 with E8M0 even scales, half_even rounding and original U8 adjacent-nibble packing; '
    'attention E4M3 W channel-axis0/A channel-axis1 override; excluded outer routing projections remain BF16.'
)
c['role_domains'] = [
    {
        'role': 'dense, shared and independent expert MXFP4 banks',
        'observed': 'Two headers contain2694 U8 weight/scale pairs: layer0 dense MLP3 and layer1 896 independent experts x3 plus shared3. Independent w1/w3 logical N3072 K3584; w2 N3584 K3072.',
    },
    {
        'role': 'excluded outer routing projections and router',
        'observed': 'Layer1 routed_expert_down_proj BF16[3584,7168], routed_expert_up_proj BF16[7168,3584] and router BF16[896,7168]; these are distinct from the 896 packed expert w1/w2/w3 banks',
    },
    {
        'role': '*self_attn* override',
        'observed': 'Config W E4M3 per_channel axis0 static and A E4M3 per_channel axis1 dynamic; sampled16 attention W tensors are F8_E4M3 with F32[N] scales',
        'unresolved': 'Axis1 is recorded literally; exact activation layout/rounding and Hyle attention-FP8 execution are not established by the MXFP4 headers',
    },
    {
        'role': 'preserved/excluded domain',
        'observed': '781 exclusions retain head, routers, residual projections, KDA convolutions and outer routed projections; exact list stays in fixed config',
        'unresolved': 'Sampled layers do not constitute the complete96-shard role census',
    },
]
c['artifact_unaligned_or_unverified'] = [
    'Original Pack_fp4 U8 even-K-low/odd-K-high packing is source-proven; it is not MLX U32 or GGUF packing and no reordered-bank adapter is implied',
    'Group32 E8M0 even-scale dynamic activation quantizer and bounded packed dense/grouped execution remain to implement; MlxQuantizedMatMul and upward-power-of-two BlockQuantizationRoundtrip are not equivalent',
    'Attention per-channel E4M3 axis0/axis1 math is separate from block128 FP8 and remains unaligned; no KV quantization scheme was declared',
    'Publisher README uses self.emulate=True in its example; no hardware MXFP4 GEMM, whole artifact execution or quality/throughput claim follows',
]
c['missing_capabilities'] = [
    'Quark group32 E8M0 even-scale dynamic W4A4 dense/shared/grouped execution on original U8 banks',
    'Attention FP8 per-channel axis0/axis1 quantization contract and exact artifact-role/import binding',
]
c['fusion_coverage'] = 'No Hyle Quark W4A4 packed execution or fusion verified; known packing does not borrow MLX/GGUF coverage or certify the separate attention FP8 domain'

row = after['artifacts'][30]
c = row['provider_coverage']
fact = fact_by_index[30]
raw_config = json.loads((ARTIFACT / '30/fixed-config.json').read_text(encoding='utf-8'))
quant = raw_config['quantization_config']


def quant_spec(spec):
    keys = ('dtype', 'is_dynamic', 'qscheme', 'ch_axis', 'group_size', 'block_size', 'symmetric', 'round_method', 'scale_type', 'scale_format', 'scale_calculation_mode')
    return {key: spec.get(key) for key in keys}


override = next(iter(quant['layer_quant_config'].values()))
row['codec_domain'] = 'Quark-MXFP4-W4A4-FP8-block128'
row['config_evidence'] = {
    'pointer': '/quantization_config',
    'quant_method': quant['quant_method'],
    'producer_version': quant['version'],
    'global_quant_config': {
        'input_tensors': quant_spec(quant['global_quant_config']['input_tensors']),
        'weight': quant_spec(quant['global_quant_config']['weight']),
    },
    'layer_quant_config': {
        'count': 924,
        'mtp_layer45_count': 871,
        'main_network_count': 53,
        'counts_by_layer': fact['layer_override_counts_by_layer'],
        'input_tensors': quant_spec(override['input_tensors']),
        'weight': quant_spec(override['weight']),
        'exact_role_names_in_raw': True,
    },
    'exclude': {'count': 626, 'examples': quant['exclude'][:5], 'exact_list_in_raw': True},
    'export': quant['export'],
    'kv_cache_quant_config': quant['kv_cache_quant_config'],
}
row['notes'] = (
    'Follow-up fixed config1716060bytes resolves the former API-only cap. Quark0.12.post1+1b229f7 mixes group32 even-scale '
    'MXFP4 W4A4, 924 FP8 block128/dynamic-group128 overrides (871 MTP layer45 +53 main), and626 exclusions. '
    'First shard is MTP FP8; selected shard19 establishes ordinary expert U8 MXFP4 banks.'
)
c['metadata_sources'].append(source('30/index-prefix-262144.jsonpart'))
c['metadata_sources'].append(source('30/regular-role-location.json'))
c['mapping_status'] = (
    'Fixed mixed Quark MXFP4/FP8 metadata and selected physical banks established; no Hyle exact group32 even-scale '
    'W4A4 execution/import mapping or complete FP8/BF16 artifact alignment yet.'
)
c['required_format_domain'] = (
    'Global static FP4 W/dynamic FP4 A group32, E8M0 even scales and half_even; 924 exact role overrides use static E4M3 '
    'W block128x128/F32 scales plus dynamic group128 E4M3 A (871 MTP layer45,53 main);626 role exclusions preserve other source formats.'
)
c['role_domains'] = [
    {
        'role': 'ordinary non-overridden MXFP4 expert banks',
        'observed': 'Shard19 contains606 U8 weight/scale pairs: layer21 573 and layer22 33; gate/up W[2048,2048] SF[2048,128], down W[4096,1024] SF[4096,64]; U8 SF carrier is E8M0 group32',
        'unresolved': 'Only a selected shard subset, not all62 shards or every288-expert layer',
    },
    {
        'role': 'FP8 role overrides',
        'observed': '924 exact config entries =871 MTP layer45 +53 main roles; W E4M3 block128x128/F32 SF and dynamic group128 E4M3 A. First shard directly shows329 MTP W/F32-block-scale pairs.',
        'unresolved': 'Do not label all main layers FP8 or infer FP8 execution equivalence from names/config alone',
    },
    {
        'role': 'preserved/excluded roles',
        'observed': '626 excludes; sampled ordinary layer21 attention/router weights remain BF16, including router[288,4096]',
        'unresolved': 'Full preserved-role census and exact importer/numerical binding remain unverified',
    },
]
c['artifact_unaligned_or_unverified'] = [
    'Former API-only/config-cap uncertainty is resolved by the fixed full config and selected headers; original historical API metadata is retained',
    'Original U8 adjacent-nibble FP4/E8M0 carrier is source-proven, but no numeric weight/scale payload was read and no Hyle Quark W4A4 operation ran',
    'FP8 overrides are924 exact roles (871 MTP+53 main), not every layer; their activation quantizer, complete role binding and execution require independent alignment',
    'Whole62-shard import, all preserved BF16 roles, native hardware MX GEMM, quality and throughput remain unverified',
]
c['missing_capabilities'] = [
    'Quark group32 E8M0 even-scale dynamic A4 numerical path with bounded original-U8 dense/grouped W4A4 execution',
    'Exact mixed MXFP4/FP8-block128/BF16 role/import binding; no complete artifact execution verified',
]
c['fusion_coverage'] = 'Mixed metadata and original packing are known; no Hyle exact Quark W4A4 operation/fusion or complete FP8 override execution verified'

# This task is deliberately restricted to these three zero-based catalog rows.
changed_indices = [i for i, (a, b) in enumerate(zip(before['artifacts'], after['artifacts'])) if a != b]
assert changed_indices == [16, 23, 30]
assert len(after['artifacts']) == 33
assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in after['artifacts'])
for key in before.keys() - {'artifacts'}:
    assert before[key] == after[key]
for index in (16, 23, 30):
    old_sources = before['artifacts'][index]['provider_coverage'].get('metadata_sources', [])
    new_sources = after['artifacts'][index]['provider_coverage']['metadata_sources']
    assert new_sources[:len(old_sources)] == old_sources
    assert after['artifacts'][index]['provider_coverage']['reachable_entry_points'] == []
    for item in new_sources[len(old_sources):]:
        assert item['archive'] == PUBLIC_ZIP
        assert item['entry'].startswith('artifact/')
        source_path = ARTIFACT / item['entry'].removeprefix('artifact/')
        assert identity(source_path) == {key: item[key] for key in ('bytes', 'sha256')}

after_raw = (json.dumps(after, ensure_ascii=False, indent=2) + '\n').replace('\n', '\r\n').encode('utf-8')
assert TARGET.read_bytes() == before_raw, 'Concurrent canonical JSON change; do not overwrite'
TARGET.write_bytes(after_raw)
after_path = STAGE / 'after/model-quantizations.json'
after_path.parent.mkdir(parents=True, exist_ok=True)
after_path.write_bytes(after_raw)
diff = ''.join(difflib.unified_diff(
    before_raw.decode('utf-8').splitlines(keepends=True),
    after_raw.decode('utf-8').splitlines(keepends=True),
    fromfile='before/model-quantizations.json', tofile='after/model-quantizations.json', n=3,
))
(STAGE / 'model-quantizations.diff').write_text(diff, encoding='utf-8', newline='')
save_json(STAGE / 'validation.json', {
    'status': 'Three catalog records updated; no Hyle execution/support claim',
    'target': TARGET.relative_to(ROOT).as_posix(),
    'changed_zero_based_artifacts': changed_indices,
    'other_artifacts_and_root_fields_structurally_unchanged': True,
    'historic_metadata_sources_retained_as_exact_prefix': True,
    'artifact_execution_verified_false_count': 33,
    'new_metadata_source_identities_match_actual_files': True,
    'new_reachable_entry_points': 0,
    'glm_fp8_overrides': {'total': 924, 'mtp_layer45': 871, 'main': 53},
    'before': identity(before_path),
    'after': identity(after_path),
    'diff': identity(STAGE / 'model-quantizations.diff'),
    'public_evidence_json': PUBLIC_JSON,
    'public_evidence_zip': PUBLIC_ZIP,
    'not_run': ['build', 'GPU', 'operation/model numerical execution', 'quality', 'throughput'],
})
print(json.dumps(json.loads((STAGE / 'validation.json').read_text(encoding='utf-8')), indent=2))
