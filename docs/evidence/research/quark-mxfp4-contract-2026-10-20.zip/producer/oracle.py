"""Small independent finite-BF16 oracle for intended Quark MXFP4 arithmetic.

No Quark/Hyle/Torch imports. This does not execute device intrinsics or resolve
the pinned HIP/Triton special-value differences; the separate probe does that.
"""
import json
import math
import struct
from pathlib import Path


def u32(x):
    return struct.unpack("<I", struct.pack("<f", x))[0]


def bf16(x):
    bits = u32(x)
    if bits & 0x7F800000 == 0x7F800000:
        return (bits >> 16) | (0x40 if bits & 0x7FFFFF else 0)
    return (bits + 0x7FFF + ((bits >> 16) & 1)) >> 16


def wide(bits):
    return struct.unpack("<f", struct.pack("<I", bits << 16))[0]


MAG = (0.0, .5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0)


def scale_even(maximum):
    # Independent algebraic reading of the documented 1.75 binade threshold.
    if maximum == 0:
        return 2.0**-127  # portable even_round observer intent, not HIP integer conversion proof
    fraction, exponent = math.frexp(maximum)
    rounded_exponent = exponent - 1 + (fraction >= .875)
    # The retained source rounds the amax in F32 storage BEFORE log2. Carry
    # into exponent128 becomes +Inf, then its clamped scale exponent is127.
    if rounded_exponent >= 128:
        return 2.0**127
    return 2.0**max(-127, min(127, rounded_exponent - 2))


def nearest(x, tie):
    magnitude = abs(x)
    if tie == "even":
        index = min(range(8), key=lambda i: (abs(magnitude - MAG[i]), i & 1))
    else:
        index = min(range(8), key=lambda i: (abs(magnitude - MAG[i]), -i))
    # Both native paths carry the input sign bit, including explicit -0.
    return math.copysign(MAG[index], x)


def qdq(group, scale, tie):
    return [wide(bf16(nearest(wide(bf16(x)) / scale, tie) * scale)) for x in group]


def main():
    group = [6.5, 1.5] + [0.0] * 30
    s = scale_even(max(map(abs, group)))
    ceil_s = 2.0**math.ceil(math.log2(max(map(abs, group)) / 6.0))
    a, b = qdq(group, s, "even"), qdq(group, ceil_s, "even")
    assert s == 1 and ceil_s == 2 and a[1] == 1.5 and b[1] == 2
    ties = [6.0, 1.25] + [0.0] * 30
    hip, triton = qdq(ties, 1, "even"), qdq(ties, 1, "up")
    assert hip[1] == 1 and triton[1] == 1.5
    table = [{"amax": x, "intended_scale": scale_even(x)}
             for x in (0.0, 1.5, 1.75, 3.0, 3.5, 6.0, 6.5, 7.0, 2.0**-126)]
    result = {
        "status": "independent finite-domain scalar assertions passed; no GPU/producer execution",
        "even_is_not_ceil": {"A": group, "even_scale": s, "ceil_scale": ceil_s,
                             "even_BF16": a, "ceil_BF16": b},
        "HIP_Triton_tie_difference": {"A": ties, "scale": 1,
            "HIP_intended_ties_even_BF16": hip, "Triton_source_ties_up_BF16": triton},
        "even_scale_table": table,
        "packing": {"low_value": 1.0, "high_value": -2.0, "low_code": 2,
            "high_code": 12, "packed_byte": "0xc2",
            "reorder": "Pack_fp4 ignores its reorder argument; adjacent K low/high nibbles"},
        "E8M0_intent": [{"code": code, "power": code - 127,
            "value": 2.0**(code - 127), "F32_bits": f"0x{u32(2.0**(code-127)):08x}",
            "BF16_bits": f"0x{bf16(2.0**(code-127)):04x}"} for code in (0, 1, 127, 254)],
        "signed_zero": {"input_bits": "0x8000", "output_bits": f"0x{bf16(qdq([-0.0],1,'even')[0]):04x}"},
        "portable_definition_recommendation": {
            "A": "all finite BF16 including signed zeros and subnormals",
            "zero_or_rounded_zero_scale": 2.0**-127,
            "rounded_amax_F32_overflow_scale": 2.0**127,
            "weight_SF_codes": "0..254 map to 2**(code-127); code255 rejected as nonfinite scale",
            "not_claimed": "not a compatibility mode for upstream HIP nonfinite-to-int behavior"},
        "limits": ["Scale-zero intent uses the explicit observer rule, not unqualified HIP log2(0)->int behavior",
            "Code255 is deliberately excluded from the portable finite-scale table; pinned paths disagree on its handling",
            "No general CPU/GPU NaN/Inf/FTZ or hardware GEMM equality inferred",
            "No real checkpoint payload values, model quality, or dot-reduction equivalence tested"]}
    Path(__file__).with_name("oracle-results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("passed")


if __name__ == "__main__":
    main()
