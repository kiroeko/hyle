from pathlib import Path
import hashlib
import json
import subprocess

P = Path(__file__).resolve().parent


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


old_rows = json.loads((P / "primary-source-identities.json").read_text(encoding="utf-8"))
old = {x["file"]: x for x in old_rows}
trees = {}
for tag, file in [("2fba630", "quark-tree-2fba630.json"), ("1b229f7", "quark-tree-1b229f7.json")]:
    trees[tag] = {x["path"]: x["sha"] for x in json.loads((P / file).read_text(encoding="utf-8"))["tree"] if x["type"] == "blob"}
rows = []
for version in ["quark-012post1", "quark-2fba630"]:
    for file in sorted((P / version).rglob("*")):
        if not file.is_file():
            continue
        rel = file.relative_to(P / version).as_posix()
        data = file.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        record = old.get(version + "/" + rel, {}).copy()
        record.update(file=file.relative_to(P).as_posix(), bytes=len(data),
                      sha256=hashlib.sha256(data).hexdigest(), pinned_git_blob=blob)
        assert blob == trees["1b229f7" if version == "quark-012post1" else "2fba630"][rel]
        record["also_byte_equal_at_commit"] = [commit for key, commit in [
            ("1b229f7", "1b229f781a1974cc742884e42d8eefc1eebb4f0a"),
            ("2fba630", "2fba630fc87e35b32ed42bb09ddce7d0d35f1562")]
            if blob == trees[key][rel]]
        if version == "quark-012post1":
            record.update(version="0.12.post1", archive_member=rel)
        else:
            record.update(version="0.13+2fba630fc87", url="https://raw.githubusercontent.com/amd/Quark/2fba630fc87e35b32ed42bb09ddce7d0d35f1562/" + rel)
        rows.append(record)
save(P / "primary-source-identities.json", rows)
# Reuse the already-present local deployment source, pinned separately from
# the artifact's producer. No package install or SDK/tree download.
repo = Path("C:/public/project-hyle/vllm")
rev = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
deployment = []
for rel in ["vllm/model_executor/layers/quantization/quark/schemes/quark_ocp_mx.py",
            "vllm/model_executor/kernels/linear/mxfp4/emulation.py",
            "vllm/model_executor/layers/quantization/utils/mxfp4_utils.py"]:
    data = (repo / rel).read_bytes()
    dest = P / "vllm-deployment" / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    deployment.append(dict(file=dest.relative_to(P).as_posix(), revision=rev,
        sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
        url="https://github.com/vllm-project/vllm/blob/" + rev + "/" + rel,
        working_tree_clean=subprocess.run(["git", "-C", str(repo), "diff", "--quiet", "HEAD", "--", rel]).returncode == 0))
save(P / "deployment-identities.json", deployment)
probe = P.parent / "root/upstream-cuda-probe"
observations = json.loads((probe / "observations.json").read_text(encoding="utf-8"))
groups = []
for kind in ["bfloat16", "float16"]:
    data = observations[kind]
    for i, name in enumerate(observations["groups"]):
        groups.append(dict(dtype=kind, group=name,
            output_unique_u16=sorted(set(data["output_u16"][i*32:(i+1)*32])),
            scale_sidecar_u32=data["scale_sidecar_u32"][i*4:(i+1)*4]))
save(P / "upstream-probe-summary.json", dict(raw=identity(probe / "observations.json"), groups=groups,
    note="Root performed one standalone CUDA compile and one GPU process. The actual qdq/dq outputs call unchanged producer templates. The scale sidecar repeats the source expression for diagnosis; it is not the original output kernel."))
review = {
    "status": "fixed-source contract research complete; no Hyle implementation or artifact execution claimed",
    "scope": {"artifact_indexes": [16, 23, 30], "model_dtype": "BF16 in all three fixed artifact configs",
        "producer_agent_builds": 0, "producer_agent_GPU_runs": 0, "root_upstream_probe_compile": 1,
        "root_upstream_probe_GPU_processes": 1, "Hyle_product_builds": 0, "SDK_builds": 0,
        "tensor_payload_read_by_this_agent": 0, "writes": "Only producer research directory"},
    "identity": {
        "16": {"version": "0.12.post1", "primary": "https://pypi.org/pypi/amd-quark/0.12.post1/json",
            "archive": identity(P / "amd_quark-0.12.post1-py3-none-any.whl"),
            "note": "Exact official pure-Python/source wheel retained and SHA matched to PyPI; not installed"},
        "23": {"version": "0.13+2fba630fc87", "commit": "2fba630fc87e35b32ed42bb09ddce7d0d35f1562",
            "url": "https://github.com/amd/Quark/commit/2fba630fc87e35b32ed42bb09ddce7d0d35f1562"},
        "30": {"version": "0.12.post1+1b229f7", "commit": "1b229f781a1974cc742884e42d8eefc1eebb4f0a",
            "tag": "v0.12", "url": "https://github.com/amd/Quark/tree/1b229f781a1974cc742884e42d8eefc1eebb4f0a"},
        "comparison": "All25 retained source files in the exact0.12.post1 wheel match tag1b229f7. Of these,24 match commit2fba630; its config/config.py adds a TwoBitScalar algorithm-selection branch, with no changed MXFP4 configuration or numerical function. All retained kernel/pack/utils/dispatch math is identical. This is not equality of complete releases or unknown dependencies.",
        "source_manifest": "primary-source-identities.json", "source_count": len(rows),
        "tag_comparison": "tag-1b229f7-source-comparison.json", "version_comparison": "versions-source-comparison.json"},
    "default_dynamic_A_QDQ": {
        "dispatch": "DynamicScaledFakeQuantize selects mxfp4_dynamic_fake_quantize for OCP group32/even. BF16/F16 inputs call mx.qdq_mxfp4; QUARK_MXFP4_IMPL defaults to hip. That name also wraps the original CUDA-build template on NVIDIA. F32 uses the observer/fake-quantizer fallback.",
        "geometry": "Each consecutive32 K elements independently, for each leading row. No global scalar or calibration-dependent activation scale. Shared A slots therefore share the same quantization numerics; per-expert IG is not part of this format.",
        "default_BF16_steps": [
            "Read BF16, absmax through BF16 abs/max and warp shuffles. Round its16-bit representation as (absmax_bits+0x20)&0xff80.",
            "Source then computes BF16 log2/floor, converts to integer, subtracts2 and clamps exponent to[-127,127]. Scale is powf(2,exponent), rounded to BF16.",
            "BF16 divide A/scale; fp16_to_fp4_simulate uses bit arithmetic for E2M1 nearest-even saturation; BF16 multiply FP4 value*scale, returning BF16.",
            "Sign bits carry through explicit +/-0 and negative nonzero values quantizing to0. No CT global factors, group16 scales or tiny-scale1e-5 guard apply."
        ],
        "even_scale_meaning": "For finite nondegenerate rounded amax in binade[2^n,2^(n+1)), values below1.75*2^n round down to2^n and values at/above it round up; scale exponent is that rounded exponent minus2. This is NOT ceil(log2(amax/6)), round(log2(amax/6)), or ordinary IEEE nearest rounding of the scale.",
        "source_anchors": ["quantization/tensor_quantize.py:660-670", "kernel/__init__.py:120-134",
            "kernel/mx/__init__.py:26-35", "utils/constants.py:71-72",
            "kernel/hw_emulation/csrc/mxfp4/fake_kernels.cuh:24-153,164-211",
            "kernel/hw_emulation/csrc/mxfp4/low_precision_intrinsics.cuh:224-310"]},
    "observer_intent_and_edge_cases": {
        "source": "quantization/utils.py:258-300 even_round",
        "algorithm": "amax is widened toF32, original zero and NaN masks saved, bits add0x200000 then mask0xff800000; original-zero replaced with2^-126, NaN restored; floor(log2)-2, clamp[-127,127], exp2. Only floor/ceil modes use a general eps replacement; even mode does not floor all scales at eps.",
        "zero": "Observer's explicit zero rule yields scale2^-127. The HIP kernel has no matching zero guard before converting log2(0) to int.",
        "upper_carry": "Large finite BF16 amax at/above1.75*2^127 rounds into F32+Inf before log2; source then clamps scale exponent to127, so scale2^127. Do not silently replace this ordered source tree with an unbounded mathematical logarithm that gives exponent126.",
        "root_actual_NVIDIA_probe": "Original BF16 +0/-0 groups retained their signs, but sidecar observed log2(0) conversion INT_MIN and wrapped scaleExp254 (scale2^127); min BF16 subnormal group became0; min-normal group stayed0x0080 with scale0x0040; maximum finite group becameInf. These are measured device outcomes, not a requirement to retain integer-overflow behavior in a portable library.",
        "F16": "Same source has actual F16 allzero/minsubnormal/maxfinite QDQ NaNs on RTX4070. Current three artifact model dtypes are BF16, so this finding does not require adding F16 support or an SDK-bug compatibility mode."
    },
    "optional_Triton_is_different": {
        "source": "kernel/mx/triton.py:47-130,946-967",
        "steps": "A is widened toF32; even scale uses F32 bit rounding and explicit zero epsilon, normalized inF32; FP4 code packing implements nearest ties-UP, despite configuration half_even. Codes are then dequantized and cast back to original dtype.",
        "witness": "Group[6,1.25,0x30] has scale1. Default HIP intended nearest-even returns1 for the second element; Triton source returns1.5. The root raw CUDA probe measured the default path's1. No Triton GPU execution was run.",
        "special_values": "Triton upcast explicitly converts scale255 toNaN, whereas HIP dequant does not. Triton BF16 scale decode uses byte<<7 so code0 becomes0; default HIP decode instead evaluates2^-127. No all-domain bit equality is justified."
    },
    "W_codec_and_decode": {
        "storage": "Original U8[N,K/2] E2M1 codes, U8[N,K/32] E8M0 scales; no zero point/global scale. Expert banks addE naturally. Physical headers are separately inventoried by the artifact agent.",
        "packing": "Pack_fp4.pack/unpack ignores its reorder parameter. Adjacent evenK is low nibble and oddK high nibble; sign bit3; magnitudes[0,.5,1,1.5,2,3,4,6], code8=-0. No AWQ permutation, MLX U32 packing or runtime tensor swizzle is implied by the export string reorder.",
        "pack_anchor": "utils/pack.py:534-577",
        "export_scale": "realquantizer.py:136-137,296-297: E8M0 scale export uses to_e8m0_uint8 (utils/numerics.py:60-71), biased exponent round/clamp to0..254. FP4 scales are not transposed by the integer-only transpose rule.",
        "generic_decompress": "Pack_fp4.unpack reconstructs F32 E2M1 values; StaticRealQuantizer.unpack_params reconstructs2^(byte-127) in configured floating dtype, then generic dequantization applies the group scale. This is separate from deployment's dedicated packed dequant kernels.",
        "default_packed_BF16_decode": "dq_uint8_mxfp4_to_half_kernel decodes E2M1 toBF16, scale from powf(2,rawcode-127) castBF16, then BF16 multiply. Normal finite E8M0 powers are exact BF16 values. Root measured code0=2^-127 including BF16 subnormal products and code8=-0.",
        "scale255_default": "Root measured raw255: code0/8 produceNaN, nonzero positive/negative codes produce+/-Inf on BF16, because default upstream converts2^128 toInf. This differs from Triton's explicit allNaN rule and must not be mislabeled uniform E8M0 NaN semantics.",
        "finite_overflow": "Scale254 is finite2^127; BF16 code2*scale isfinite2^127, code4 and larger overflow toInf. Such legal finite-input arithmetic overflow must remain distinguishable from an invalid scale code. Dot0*Inf can then yieldNaN normally.",
        "decode_anchors": ["kernel/hw_emulation/csrc/mxfp4/dequantize_kernels.cuh:37-121",
            "kernel/hw_emulation/csrc/mxfp4/low_precision_intrinsics.cuh:184-212", "export/nn/modules/realquantizer.py:118-148,190-212"]},
    "selected_portable_reference_not_implemented": {
        "purpose": "Explicit finite BF16 software reference for these artifacts; not bug-for-bug emulation of a chosen SDK, TensorCore or entire Quark runtime.",
        "A_domain": "All finite BF16 including subnormals and signed zeros; rejectNaN/Inf source A through the existing checked Completion contract.",
        "scale": "Selected rule: rounded=(absmax_BF16_u16+0x20)&0x7f80. If rounded is0 choose exponent-127 directly; if rounded is+Inf after carry from finite input choose127 directly; otherwise subtract2 from its exact exponent and clamp[-127,127]. Scale=2^exponent represented exactly inBF16. This replaces undefined nonfinite-to-int conversion with stated mathematics, no new eps floor.",
        "A_rounding": "Round division toBF16, E2M1 nearest-even saturating while preserving explicit signbits, then BF16 product. Positive power-of-two scale is exactly represented, including2^-127; no FTZ substitution.",
        "W_domain": "Allow rawSF0..254 with exact2^(code-127) and BF16 code*scale. RawSF255 fails Completion as nonfinite scale input, consistent with existing NVFP4 checked-domain policy; do not silently choose HIP's mixedInf/NaN or add two SDK-bug compatibility branches.",
        "overflow": "Keep IEEE Inf/NaN produced by legal finite values; failure is about source-domain violations, not arbitrary intermediate nonfiniteness.",
        "normal_match_vs_edge_definition": "Default BF16 normal/tie/zero/minnormal/maxfinite observations support the stated normal math and declared overflow boundaries. Tiny-subnormal and allzero scale selection is an explicit portable definition, not a claim of all-finite bit identity to upstream HIP or AMD hardware.",
        "separate_attention": "Attention FP8 overrides/exclusions retain their independently observed precision/axis contracts. Do not route them through group32 MXFP4 based on repository name.",
        "decision_status": "Root explicitly selected this BF16 mathematical definition before report freeze. It is not implemented in this research batch; no public descriptor/API guessed or created by this agent. No F16 or optional-Triton compatibility branch is required for the current artifact set."
    },
    "evidence": {"scalar_oracle": identity(P / "oracle.py"), "scalar_results": identity(P / "oracle-results.json"),
        "scalar_run": "python producer/oracle.py -> exit0, independent source-only finite witnesses",
        "upstream_probe_source": identity(P / "upstream_cuda_probe.cu"),
        "upstream_probe_receipt": identity(probe / "receipt.json"), "upstream_raw": identity(probe / "observations.json"),
        "summary": "upstream-probe-summary.json",
        "hardware": "Root: NVIDIA GeForce RTX4070 SM89, driver617.14, CUDA13.3; no AMD, Mac or Triton qualification",
        "receipt_note": "Root corrected a post-success receipt-serialization TypeError without recompiling/rerunning; raw compile/GPU success and first metadata failure preserved in root receipt."},
    "deployment_boundary": {"snapshots": deployment,
        "meaning": "Local vLLM Quark reader creates U8 packed W/E8M0 banks and software emulation delegates QDQ/DQ to Quark mx dispatch, then high-precision F.linear. Optional load-time W dequantization is a deployment policy, not the only necessary storage shape.",
        "Kimi_card": "Fixed card explicitly evaluates with QuarkOCP_MX.emulate=True. This is not evidence of native MXFP4 hardware GEMM or every selected provider's numerical equivalence."},
    "artifact_boundary": {"facts": "../artifact/artifact-facts.json", "payload_read": 0,
        "roles": "Artifact16 first2headers:1536pairs(layer0 all512 gate/up/down). Artifact23:2694pairs including denseMLP,896 independent experts and shared expert; excluded routed_expert_up/down are BF16 outer projections, not all expert banks. Artifact30:ordinaryMXFP4 shard19 has606pairs; 924FP8overrides include871MTP plus53main, so main domain is mixed.",
        "not_claimed": ["All-shards complete roles, payload validity, model inference, quality or performance",
            "Universal FP8 attention or MTP support from an MXFP4 header",
            "MLX weight-only MXFP4 or ceil-power scale operator is equivalent to this W4A4 contract",
            "All producer special-value/backend behavior is uniform or should be retained as bugs"]}}
save(P / "review.json", review)
files = sorted(x for x in P.rglob("*") if x.is_file() and "__pycache__" not in x.parts and x.name != "source-freeze.json")
save(P / "source-freeze.json", dict(scope="bounded source contract and independent research", files=[identity(x) for x in files]))
print(json.dumps(identity(P / "review.json")))
print(json.dumps(identity(P / "source-freeze.json")))
