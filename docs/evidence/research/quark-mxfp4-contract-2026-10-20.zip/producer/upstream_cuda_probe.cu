// Source-only probe of the pinned upstream headers; root owns compilation/run.
// -std=c++17 -DUSE_CUDA -I<producer>/quark-012post1/quark/torch/kernel/hw_emulation/csrc
#include "mxfp4/fake_kernels.cuh"
#include "mxfp4/dequantize_kernels.cuh"
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <vector>

static void checked(cudaError_t code) {
  if (code != cudaSuccess) { std::fprintf(stderr,"CUDA: %s\n",cudaGetErrorString(code)); std::exit(1); }
}

template<class T, unsigned Add, unsigned Mask>
__global__ void observe_scale(const T *input, std::uint32_t *output) {
  const int group = int(threadIdx.x);
  T maximum = habs_impl(input[group*32]);
  for (int i=1;i<32;++i) maximum=hmax_impl(maximum,habs_impl(input[group*32+i]));
  const std::uint16_t rounded=(*(std::uint16_t*)(&maximum)+Add)&Mask;
  maximum=*(const T*)(&rounded);
  const T floor_value=hfloor_impl(hlog2_impl(maximum));
  const int integer=bf16_or_half2int_rn<T>(floor_value);
  // Same upstream expression, including the actual device conversion on log2(0).
  const std::uint8_t scale_exp=max(0,127+min(integer-2,127));
  const T scale=float_to_bf16_or_half<T>(powf(2.F,scale_exp-127));
  output[group*4]=rounded; output[group*4+1]=std::uint32_t(integer);
  output[group*4+2]=scale_exp; output[group*4+3]=*(const std::uint16_t*)(&scale);
}

template<class T, unsigned E, unsigned M, unsigned Bias, unsigned Add, unsigned Mask>
static void run(const char *name, const std::uint16_t *input_bits) {
  constexpr int elements=256, groups=8;
  T *input,*output; std::uint32_t *observed;
  checked(cudaMalloc(&input,elements*sizeof(T))); checked(cudaMalloc(&output,elements*sizeof(T)));
  checked(cudaMalloc(&observed,groups*4*sizeof(std::uint32_t)));
  checked(cudaMemcpy(input,input_bits,elements*sizeof(T),cudaMemcpyHostToDevice));
  qdq_mxfp4_kernel<T,E,M,Bias,Add,Mask><<<2,128>>>(input,output);
  checked(cudaGetLastError()); checked(cudaDeviceSynchronize());
  std::uint16_t actual[elements]; checked(cudaMemcpy(actual,output,sizeof(actual),cudaMemcpyDeviceToHost));
  observe_scale<T,Add,Mask><<<1,groups>>>(input,observed);
  checked(cudaGetLastError()); checked(cudaDeviceSynchronize());
  std::uint32_t details[groups*4]; checked(cudaMemcpy(details,observed,sizeof(details),cudaMemcpyDeviceToHost));
  std::printf("\"%s\":{\"input_u16\":[",name);
  for(int i=0;i<elements;++i)std::printf("%s%u",i?",":"",unsigned(input_bits[i]));
  std::printf("],\"output_u16\":[");
  for(int i=0;i<elements;++i)std::printf("%s%u",i?",":"",unsigned(actual[i]));
  std::printf("],\"scale_sidecar_u32\":[");
  for(int i=0;i<groups*4;++i)std::printf("%s%u",i?",":"",unsigned(details[i]));
  std::printf("],\"weight_scale_codes\":[0,1,127,254,255],\"weight_output_u16\":[");
  // 5 groups x32 values. This upstream kernel writes8 values per thread and
  // has no bounds test, so launch exactly20 threads, without a partial tail.
  std::uint8_t packed[80],scales[5]={0,1,127,254,255};
  for(int i=0;i<80;++i)packed[i]=std::uint8_t(((i%8)*2)|(((i%8)*2+1)<<4));
  std::uint8_t *w,*sf; checked(cudaMalloc(&w,sizeof(packed))); checked(cudaMalloc(&sf,sizeof(scales)));
  checked(cudaMemcpy(w,packed,sizeof(packed),cudaMemcpyHostToDevice));
  checked(cudaMemcpy(sf,scales,sizeof(scales),cudaMemcpyHostToDevice));
  dq_uint8_mxfp4_to_half_kernel<T,std::uint8_t,E,M,Bias><<<1,20>>>(w,sf,output);
  checked(cudaGetLastError()); checked(cudaDeviceSynchronize());
  checked(cudaMemcpy(actual,output,160*sizeof(T),cudaMemcpyDeviceToHost));
  for(int i=0;i<160;++i)std::printf("%s%u",i?",":"",unsigned(actual[i]));
  std::printf("]}"); checked(cudaFree(w));checked(cudaFree(sf));checked(cudaFree(input));checked(cudaFree(output));checked(cudaFree(observed));
}

int main() {
  std::uint16_t bf[256]={},half[256]={};
  for(int j=0;j<32;++j){
    bf[32+j]=half[32+j]=0x8000; // explicit -0 group
    bf[64+j]=0x0080;half[64+j]=0x0400; // smallest normal
    bf[96+j]=half[96+j]=0x0001; // smallest subnormal
    bf[128+j]=0x7f7f;half[128+j]=0x7bff; // largest finite
    bf[160+j]=0;half[160+j]=0;
    bf[192+j]=0;half[192+j]=0;
    bf[224+j]=0x3f80;half[224+j]=0x3c00;
  }
  // Scale1 group: exact FP4 midpoint ties, signs and explicit signed zeros.
  const std::uint16_t bt[16]={0x40c0,0x3e80,0x3f40,0x3fa0,0x3fe0,0x4020,0x4060,0x40a0,
      0xc0c0,0xbe80,0xbf40,0xbfa0,0xbfe0,0xc020,0xc060,0xc0a0};
  const std::uint16_t ht[16]={0x4600,0x3400,0x3a00,0x3d00,0x3f00,0x4100,0x4300,0x4500,
      0xc600,0xb400,0xba00,0xbd00,0xbf00,0xc100,0xc300,0xc500};
  for(int j=0;j<16;++j){bf[160+j]=bt[j];half[160+j]=ht[j];}
  bf[192]=0x40d0;bf[193]=0x3fc0;half[192]=0x4680;half[193]=0x3e00; // 6.5,1.5
  bf[224]=0x7fc1;bf[225]=0x7f80;half[224]=0x7e01;half[225]=0x7c00; // diagnostic, outside finite profile
  std::printf("{\"groups\":[\"positive_zero\",\"negative_zero\",\"min_normal\",\"min_subnormal\",\"max_finite\",\"ties_scale1\",\"even_vs_ceil\",\"nonfinite_diagnostic\"],");
  run<__nv_bfloat16,8,7,127,32,0xff80>("bfloat16",bf);std::printf(",");
  run<__half,5,10,15,256,0xfc00>("float16",half);std::printf("}\n");
}
