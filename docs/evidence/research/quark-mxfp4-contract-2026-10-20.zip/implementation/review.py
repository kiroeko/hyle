from pathlib import Path
import json,hashlib,subprocess,datetime
root=Path.cwd(); base=root/'.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review'; stage=base/'implementation'
paths=[
'include/hyle/compute/model_ops.h','include/hyle/compute/low_precision.h','include/hyle/compute/tensor.h','include/hyle/mem/buffer.h',
'src/compute_ops/weight_decode.cc','src/compute_ops/low_precision.cc',
'src/compute_provider_native/nvfp4.cc','src/compute_provider_native/native_plan.h','src/compute_provider_native/native_provider.cc','src/compute_provider_native/CMakeLists.txt','src/compute_provider_native/ds4_quantization.cc','src/compute_provider_native/torch_cpu_program.cc',
'src/compute_provider_cuda/nvfp4_provider.h','src/compute_provider_cuda/nvfp4_provider.cc','src/compute_provider_cuda/nvfp4_kernel.h','src/compute_provider_cuda/nvfp4_kernel.cu','src/compute_provider_cuda/packed_rows.cuh','src/compute_provider_cuda/cuda_provider.cc','src/compute_provider_cuda/CMakeLists.txt','src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc','src/compute_provider_cuda/deepseek_fp8_provider.cc','src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
'src/compute_route_apple/apple_nvfp4.h','src/compute_route_apple/apple_nvfp4.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc','src/compute_route_apple/apple_tensor.cc','src/compute_route_apple/CMakeLists.txt','src/compute_route_apple/apple_weights.mm',
'src/compute_route_vulkan/vulkan_nvfp4.cc','src/compute_route_vulkan/shaders/nvfp4.comp','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_tensor.h','src/compute_route_vulkan/vulkan_mlx.cc','src/compute_route_vulkan/vulkan_official.cc','src/compute_route_vulkan/build_shaders.py','src/compute_route_vulkan/CMakeLists.txt','src/compute_route_vulkan/vulkan_weights.cc',
'src/compute_shader_shared/nvfp4_f32.h','src/compute_shader_shared/ct_packed.h','third_party/mlx_cpu_quant/mlx_cpu_quant.h','third_party/mlx_cuda_quant/mlx_cuda_quant.h','third_party/ds4_quantization/ds4_roundtrip.h','src/graph/input_sources.h','src/graph/input_sources.cc','src/mem/composite_buffer.cc'
]
def identity(p):
 p=Path(p); p=p if p.is_absolute() else root/p; b=p.read_bytes()
 return {'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def anchors(path, needles):
 lines=(root/path).read_text(encoding='utf-8').splitlines(); out={}
 for n in needles:
  out[n]=[i+1 for i,line in enumerate(lines) if n in line][:5]
 return {'path':path,'line_anchors':out}
header_summaries=[]; headers=[]
for name in ['header-summary.json','additional-header-summary.json']:
 p=base/'artifact'/name; header_summaries.append(identity(p))
 for entry in json.loads(p.read_text(encoding='utf-8')):
  h=entry['header']; p=Path(h['path']); actual=identity(p); assert actual['sha256']==h['sha256']
  entries=json.loads(p.read_text(encoding='utf-8')); pairs=[]
  for k,v in entries.items():
   if not isinstance(v,dict) or v.get('dtype')!='U8' or not k.endswith('.weight'): continue
   sf=entries.get(k[:-len('.weight')]+'.weight_scale')
   if sf and sf.get('dtype')=='U8':
    geom={'weight':v['shape'],'scale':sf['shape']}
    if geom not in [x['geometry'] for x in pairs]: pairs.append({'example':k,'geometry':geom})
  headers.append({'artifact_index':entry['artifact_index'],'repository':entry['repository'],'revision':entry['revision'],'file':entry['file'],'header':actual,'tensor_count':entry['tensor_count'],'u8_weight_scale_shape_examples':pairs,'payload_bytes_read':0,'interpretation':'Shapes establish U8 carriers; neither nibble/reorder semantics nor E8M0 numeric special-code behavior follows from shapes.'})
report={
 'status':'read_only_implementation_map; Quark producer arithmetic and physical reorder are not yet signed',
 'scope':{'product_edits':0,'public_documentation_edits':0,'builds':0,'gpu_runs':0,'payload_bytes_read':0,'network_requests_by_this_review':0,'note':'Current local Hyle source and already-retained header bytes only. Producer math and artifact catalog review are owned by sibling agents; this map does not certify Quark support.'},
 'checkout':{'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_identity':'Dirty worktree per-file SHA256 below; HEAD is insufficient.'},
 'decision':{
  'recommended_direction':'If confirmed producer math is the expected group32 E2M1/E8M0 runtime A quantization, extend one private FP4-reference family per backend, using cold geometry/codec policy and existing execution/lifetime paths; retain distinct public numerical semantics.',
  'not_yet_a_design_freeze':'Names, exact new public descriptors, arity, source nibble/reorder mapping, scale quantizer and operand boundary remain subject to the producer/header review. Do not implement by guessing a Quark version or repository-name whitelist.',
  'public_compatibility':'Keep current ModelOpt Nvfp4Linear/GroupedNvfp4Linear and LocalNvfp4Linear/GroupedLocalNvfp4Linear unchanged: two ModelOpt plus two Local descriptors, four total. Do not widen the Local pre-round field into an ambiguous format selector.',
  'no_new_graph_execution':'No new GraphCore scheduling, Graph executor, provider queue, user CMake switch or compatibility import alias is needed for a new explicit typed operation.'},
 'existing_contracts':[
  {'name':'ModelOpt group16 NVFP4 reference','ports':'Dense A/W/SF/WG/IG; grouped adds IDs. W is U8 adjacent low-first E2M1, SF E4M3FN per16, independent positive-finite F32 globals.','math':'Activation uses E4(max/(6*IG))*IG and a 1e-5 guard; decoded W scales multiply SF*WG before code multiplication and BF16 storage; ModelOpt code8 is positive zero. BF16 operands enter backend F32 reduction.','reusable':'Mapping/alias checks, prepared plan, once-per-row activation materialization, bounded W decoding, ID gate and state/status lifetime.','not_Quark':'Group16, E4 scales, two globals, tiny guard and code8 policy are numerical semantics, not reusable defaults.'},
  {'name':'CT Local group16 NVFP4 reference','ports':'Same physical geometry as ModelOpt, independently typed public operation and Fp4InputRounding field.','math':'BF16(absmax/6) then F32 IG multiply -> E4, only zero scale replaces with0.125; direct sf/IG and SF/WG division; optional BF16 pre-FP4 rounding; W code8 negative zero; BF16 operands.','reusable':'Explicit cold contract dispatch is already established in all four backends.','not_Quark':'Original globals/direct-division tree and portable sign(v) rule cannot be presumed for a group32 Quark quantizer.'},
  {'name':'MLX Mxfp4','ports':'MlxQuantized kMxfp4 uses U32 low-first continuous row bits, 4bits/group32 and separate U8 scales. Plain A is F16/BF16/F32; no runtime FP4 A quantization is provided by this descriptor.','math':'F32 per-group code-dot then multiply E8 scale after first rounding scale to the output/activation dtype; code8 is negative zero. This is not pre-dequantize-weight-to-BF16 dot math.','reusable':'Raw E2M1 magnitudes/sign decode and source-byte/selected-row traversal; CUDA common packed_rows handles group_size already.','not_Quark':'Its U32 layout, low-precision scale cast, group-scale-after-dot and special-scale behavior must match actual producer before reuse. Do not reinterpret U8 Quark data into this layout or silently apply A16.'},
  {'name':'BlockQuantizationRoundtrip Float4E2M1Block32','ports':'One finite dense BF16 matrix -> distinct same-shape BF16 output. Packed codes/scales are not exposed.','math':'Per32 scale=2^ceil(log2(max(absmax,6*2^-126)/6)), saturated nearest-even E2M1, F32 reconstruct then BF16. Public comment explicitly distinguishes round-even MX scale policy.','reusable':'E2M1 nearest-even threshold logic, group traversal and BF16 codec only after zero/tie policy confirmation.','not_Quark':'This fixed ceil+floor formula cannot be renamed to generic MX quantization. Adding it before MLX W-only matmul is not evidence of the Quark W4A4 tree.'},
  {'name':'DeepSeek GroupedFloat4Linear','ports':'Original encoded [E,N,K]: all adjacent E2M1 U8 codes followed by F32 [E,N,K/32] scales; source UE8M0 may have been widened. BF16 A and I32 IDs; K%128.','math':'A is runtime E4M3 group128 with 1e-4 floor and upward power2 scale, followed by FP4-weight/FP8-activation dot and scaling; not FP4 A.','reusable':'Only selected-expert traversal/status/capture patterns, not its arithmetic or AOT images.','actual_cuda_boundary':'CUDA provider selects four precompiled N/K pairs:3072/7168,7168/3072,2048/4096,4096/2048. No new Quark shape can use those images by format name.'},
  {'name':'GGUF/ggml MXFP4 encoded weight','ports':'mxfp4_weight_description:32 values in17 bytes, scale byte then16 code bytes; low nibbles encode K0..15 and high K16..31.','not_Quark':'This half-group interleave differs from adjacent even/odd nibble order. Group width32 alone does not authorize a byte reinterpret or packing conversion.'}
 ],
 'backend_reuse':[
  {'backend':'native CPU','natural_owners':['src/compute_provider_native/nvfp4.cc','src/compute_provider_native/native_plan.h','src/compute_provider_native/native_provider.cc'],
   'reuse':'NativePlan workspace_submit_route, existing parallel_for_ranges, host mapping close/flush, overflow/alias rejection, complete-ID validation before metadata, current small W-group stack tile and simd::dot.',
   'required_if_math_confirms':'Make group width/scale-code decoder/quantize/weight operand conversion a private cold policy. Current kGroup=16, mappings up to6, globals and inputs.size()==6 grouped detection must become exact-schema geometry instead of copying another executor. Keep new carrier arity real.',
   'workspace':'Current family uses caller2*R*K BF16 bytes; a group32 BF16-QDQ policy can reuse that only if BF16 operand reconstruction is producer-correct. If A remains code+scale until dot, scratch content/size must change explicitly rather than claiming2RK by inheritance.',
   'other_entry':'Current MLX CPU work is in torch_cpu_program.cc + borrowed mlx_cpu_quant; DS4 roundtrip has separate native ds4_quantization.cc. Neither must be edited merely to add a new family policy.'},
  {'backend':'native CUDA','natural_owners':['src/compute_provider_cuda/nvfp4_provider.h','src/compute_provider_cuda/nvfp4_provider.cc','src/compute_provider_cuda/nvfp4_kernel.h','src/compute_provider_cuda/nvfp4_kernel.cu','src/compute_provider_cuda/cuda_provider.cc'],
   'reuse':'SharedQueue/caller workspace, capture-compatible prepared vtable, actual byte-span alias checks, acquired device status, separate all-ID kernel, capped U64 grid-stride, cold resolved quantize/dot pointers.',
   'existing_generic_piece':'packed_rows.cuh is parameterized by group_size and Loader::group/value/finish; no loop duplication is needed for32. Leave its reduction tree intact unless producer/math explicitly requires another tree.',
   'required_if_math_confirms':'Extend cold codec/shape selection, true ports/dtypes/scale geometry and loader; resolve exact new template instantiations with cudaFuncGetAttributes during prepare. Keep direct runtime launches free of function materialization.',
   'row_sharing':'Rows4 is legal only for rows sharing the same W and group policy. Existing grouped usesRows1; arbitrary selected experts cannot share decoded weights. Shared raw A may be quantized once per token only if confirmed quantization is independent of expert metadata; otherwise per selected row.'},
  {'backend':'Apple','natural_owners':['src/compute_route_apple/apple_nvfp4.h','src/compute_route_apple/apple_nvfp4.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc'],
   'reuse':'Existing native lowerer, input_spec, mlx::fast::metal_kernel template constants and Stream, full-ID dependency, with_device_status and explicit output ownership/lifetime.',
   'required_if_math_confirms':'One group-width/codec cold template family with actual original U8 carriers. Replace baked16 arrays/group offsets with policy constants only in shared traversal; do not clone dense/grouped state/shape plumbing.',
   'numeric':'Reuse shared U32 IEEE helpers where scalar quantizer/reconstruction boundaries need subnormal and exact RNE; normal F32 dot may use established reduction only under the declared numerical contract. Native Metal divide/FTZ is not an exact quantizer substitute.',
   'workspace':'Current explicit q array2RK plus quantization checks4*R*(K/16), dot checks4RN and grouped ID status; group32 changes check cardinality. These are native arrays, not caller-only2RK; opaque MLX allocation remains unknown.'},
  {'backend':'Vulkan','natural_owners':['src/compute_route_vulkan/vulkan_nvfp4.cc','src/compute_route_vulkan/shaders/nvfp4.comp','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/build_shaders.py'],
   'reuse':'Original Program values/aliases/status, pipeline metadata and checked_dispatch phases, origins/capacity checks, same Queue/fence lifetime. Existing cold shader variant plus specialization values is a natural group/codec policy.',
   'required_if_math_confirms':'Parameterize group width and original byte accessor; replace fixed5/6 source ports with true new schema, preserve all-ID phase before any selected addresses; quantize once then bounded W dot. New SPIRV variants are internal generated entries, not a new SDK/AOT matrix.',
   'admission':'For confirmed U8 W and U8 SF, ordinary U8 carrier admission already exists; do not widen vulkan_program.cc E4 port2 exception. Touch that owner only if exact actual new types require it. Preserve U32 byte origins, actual spans, generic INT32 planner bounds and device maxStorageBufferRange as distinct limits.',
   'numeric':'Shared nvfp4_f32.h U32 IEEE scalar math is independent of group16; reuse rather than duplicate an inaccurate GLSL log/div path. Do not choose full integer dot by convenience if an ordinary finite F32 dot honors the producer contract and exceptional cases can stay exact.'}
 ],
 'private_family_refactor':{
  'worthwhile_when':'One additional compatible E2M1 grouped reference contract justifies a private FP4 reference family so no backend acquires a second shape/mapping/status executor. Parent approval is for evaluation only; no code renamed in this review.',
  'minimum_abstraction':['Cold physical geometry: group width, actual source port indices/count, original nibble address/reorder and scale storage.','Cold numerical policy: activation scale/rounding/zero rules; E2M1 threshold input precision; weight operand rounding/scaling order; dot/epilogue boundary.','Existing per-backend prepared/native traversal and status remain the execution owner; codec supplies group values and optional group finish.'],
  'avoid':['No producer-version boolean or repository whitelist.','No dummy WG/IG tensors ofones to force an old5/6-port ABI.','No reshape/packing conversion of original W merely to make MLX or GGUF fit.','No public generic kitchen-sink descriptor permitting unsupported group/math combinations.','No common Graph format branch or new executor.'],
  'rename':'Private function/namespace names can move from nvfp4 to fp4_reference with this substantive policy change. File renames are optional and should be atomic in the existing owner, not a separate broad cleanup. Preserve all four current public descriptors and their numerical branches.',
  'rename_only_additional_owners':['Per-backend CMakeLists.txt source lists; CUDA per-source /Zc:preprocessor option must follow a renamed .cu.','Vulkan internal shader generator entry/include references and its CMake dependency list.','Apple private include/call sites and Vulkan lowerer declaration in vulkan_tensor.h.'],
  'shared_scalar_helper':'The existing shader::kNvfp4F32 name describes history, but its body is generic IEEE bits. Reuse it unchanged initially; a later private rename can use one shared source/marker update, not duplicated math.'},
 'ordinary_composition':{
  'already_available':'Ordinary F32/BF16 Cast, arithmetic and MatMul leaves exist, plus W-only MLX Mxfp4 and fixed DS4 roundtrip. This is enough to explore a producer-confirmed mathematical graph, not to assert an exact Quark representation today.',
  'missing_semantic_condition':'No public E2M1 Cast or arbitrary E8M0-scale quantization op is established by these existing descriptors. If Quark scale rounding or BF16 boundaries differ, BQRoundtrip+MLX is not an equivalent composition. Prefer a clearly documented new typed semantic over silently changing existing operators.',
  'source_layout':'If the retained original Quark exporter packs a reorder permutation, implement a bounded accessor or a justified one-time cold import mapping with measured copy cost; do not copy/expand the entire bank just to reuse another codec.'},
 'must_be_confirmed_before_implementation':[
  'Exact artifact-to-producer version/source route for dynamic A versus saved W; fake-QDQ and deployment dot are different contracts.',
  'Group32 scale derivation: ceil/floor/round-even or mantissa-threshold policy; absmax floor; allzero group; upper/lower saturation; use of reciprocal versus division; F32/F16/BF16 intermediate rounding.',
  'E8M0 code0/subnormal behavior and code255 reserved/NaN behavior. Existing MLX ldexp and cast behavior cannot certify Quark.',
  'E2M1 code8 sign, explicit negative-zero activation, negative tiny quantization, all midpoint ties and nonfinite source domain.',
  'Whether A and W are reconstructed to BF16 before F32 dot, or codes/scales participate in a different group-dot tree; final output type and allowed reduction-tree differences.',
  'Original U8 nibble packing/reorder, leading axes, any stored transpose/permutation; U32 and GGUF17B contracts are not default aliases.',
  'Actual grouped A geometry and whether quantizer depends on expert/weight metadata; selected-only numeric checks versus whole-bank checks are semantic choices, not assumed optimizations.'
 ],
 'artifact_header_context':{'header_only':headers,'summary_identities':header_summaries,'limits':'16/23 observed U8 weight and scale shapes are consistent with K/2 and K/32 for the expected group32 role, but not proof of code order or mathematical contract. Artifact30 retained first shard contains FP8/BF16 rather than a U8 MX pair, so repository title cannot choose this route. Other roles/shards remain owned by artifact review.'},
 'delivery3_resource_boundary':{
  'existing':'WeightSlots provides two fixed capacity staging/device slots, fragment catalog upload, retained WeightBatch/tensor owners and retirement checks; Graph InputSource provides ready/source lifetime. CompositeBuffer provides segmented memory ranges, but TensorView still accepts one BufferView.',
  'not_done':'Current grouped FP4 operators take one dense W/SF expert-axis bank. There is no proven original per-expert fragment -> selected bounded bank -> global/local ID remap -> grouped invocation journey for these artifacts. This is a concrete integration task, not a fundamental lack of all resource APIs.',
  'why_no_forced_merge':'Artifact16 actual gate/up each expert W=8MiB and SF=512KiB;512 hypothetical merged W is4GiB and SF256MiB, before other roles. Avoid claiming a required cold full-bank copy; original checkpoint experts are separate tensors. Actual descriptor/storage limits differ from total device RAM.',
  'next_action':'Keep in delivery3: one selected fragment-catalog/working-set bridge using current slots/source ownership, immutable role geometry, explicit ID remap and old-result/failed-retirement behavior; count actual upload/copy bytes and check each bound span. No second executor or generic Graph expansion in this math package.',
  'proof_limit':'Small-E mathematical/lifetime tests do not certify full512 banks, capacity/OOM fallback, complete artifacts, Linux or throughput. Runtime OOM does not automatically reselect a different physical plan.'},
 'finite_followup_after_math':{'product':'Only confirmed new public semantic/inference plus these existing backend owners and exact dispatch admissions; tests use one shared independent producer-math fixture with thin four-backend wrappers. Refresh only actual ABI/inline owners and generated shader callers; reuse SDK and immutable cached dependency objects.','neighbors':'Retain existing ModelOpt and Local dense/grouped numerical branches and original MLX/BQ/DeepSeek contracts. Select meaningful adjacent regressions rather than a full SDK/shape matrix.','not_requested':'No implementation, test execution, performance selection or public evidence publication is authorized by this review alone.'},
 'source_inventory':[identity(p) for p in paths],
 'anchors':[
  anchors('include/hyle/compute/model_ops.h',['enum class Fp4InputRounding','struct LocalNvfp4Linear','struct GroupedLocalNvfp4Linear','struct BlockQuantizationRoundtrip','struct GroupedFloat4Linear']),
  anchors('src/compute_provider_native/nvfp4.cc',['constexpr std::size_t kGroup','enum class Math','void quantize_groups','void dot_rows','Status prepare_nvfp4']),
  anchors('src/compute_provider_cuda/packed_rows.cuh',['template<class Output','unsigned group_size']),
  anchors('src/compute_provider_cuda/nvfp4_kernel.cu',['void check_ids','cudaError_t configure','cudaError_t prepare_kernel']),
  anchors('src/compute_route_vulkan/vulkan_nvfp4.cc',['Status lower_nvfp4','const auto check_bytes','SpecializationConstant','The first dispatch']),
  anchors('third_party/mlx_cpu_quant/mlx_cpu_quant.h',['Original FP4_LUT','dequantize_scale','auto scale_values']),
  anchors('src/compute_provider_torch_cuda/mlx_packed_kernel.cu',['struct MlxGroup','float finish','ldexpf']),
  anchors('include/hyle/compute/low_precision.h',['Source UE8M0','low nibbles encode'])]
}
out=stage/'review.json'; out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'path':out.relative_to(root).as_posix(),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'sources':len(report['source_inventory']),'retained_headers':len(headers),'status':report['status']}))
