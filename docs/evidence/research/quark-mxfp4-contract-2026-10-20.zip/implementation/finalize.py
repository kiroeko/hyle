from pathlib import Path
import json,hashlib
root=Path.cwd(); base=root/'.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review'; stage=base/'implementation'; p=stage/'review.json'; r=json.loads(p.read_text(encoding='utf-8'))
def identity(p):
 p=Path(p); p=p if p.is_absolute() else root/p; b=p.read_bytes(); return {'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def source_anchor(rel,needles):
 p=base/'producer'/'quark-012post1'/rel; lines=p.read_text(encoding='utf-8').splitlines()
 return {**identity(p),'anchors':{n:[i+1 for i,line in enumerate(lines) if n in line][:5] for n in needles}}
r['status']='read_only_final_reuse_design; retained Quark HIP/Triton boundaries explicit; no new product capability delivered'
r['decision']['recommended_direction']='Extend the existing private FP4 reference family per backend with explicit Quark group32/U8-scale math, rather than copying shape/mapping/state executors. Actual retained packing is adjacent low-even/high-odd U8, compatible with a byte accessor; do not convert it to U32 or GGUF blocks.'
r['decision']['not_yet_a_design_freeze']='This is a finite implementation recommendation, not a public API or code edit. A future portable BF16 reference must choose documented zero/extreme behavior explicitly: default HIP, optional Triton and the Python even_round helper do not define identical full domains.'
r['confirmed_producer_math']={
 'provenance':{'artifact16':'PyPI amd-quark0.12.post1','artifact23':'amd/Quark commit2fba630fc87e35b32ed42bb09ddce7d0d35f1562','artifact30':'amd/Quark tag commit1b229f781a1974cc742884e42d8eefc1eebb4f0a','cross_source_proof':identity(base/'producer/tag-1b229f7-source-comparison.json'),'scope':'Producer owner established25 relevant source files identical by Git blob across exact wheel, source commit and tag; this implementation owner read key retained kernels/pack files and did not run them.'},
 'packing':'Pack_fp4 ignores the reorder argument; U8[N,K/2], evenK in low nibble, oddK in high nibble. Both retained pack/unpack and HIP W decoder agree. Config export.pack_method=reorder does not imply the unrelated INT4 order_map.',
 'default_HIP_BF16_activation':'Per32 BF16absmax -> round magnitude bits (amax_bits+0x20)&0x7f80 -> floor(log2(rounded_amax))-2 -> exponent clamp via source integer path -> powf(2,exp) converted to BF16; source BF16 divide -> E2M1 nearest-even -> BF16 multiply/store. Source BF16 hdiv/hmul boundaries cannot be omitted.',
 'weight_BF16':'Decode adjacent E2M1 code (including negative code8 zero); scale=BF16(powf(2,rawE8M0-127)); then BF16(code*scale), before F32 dot. This is different from MLX code-dot with scale after the group.',
 'optional_Triton':'Explicit F32 normalization and E2M1 nearest with ties-up. Retained [6,1.25,0,...] group witness distinguishes default HIP output1 from Triton1.5; do not choose either from producer version or name.',
 'extreme_scale_difference':'Default HIP BF16 scale code0 decodes2^-127 and255 becomesInf through powf; optional Triton reconstructs code0 as0 via exponent bitshift and explicitly maps255 toNaN. Do not apply a generic E8M0 NaN policy without selecting the actual contract.',
 'zero_group_difference':'Python quantization/utils.py even_round explicitly replaces original zero max with2^-126 and returns minimum scale2^-127. HIP fake kernel has no matching guard and reaches log2(0)->integer conversion. The hardware outcome is not established by retained source; finite maxima whose bit rounding overflows also need an explicit portable rule rather than a guessed device conversion.',
 'domain_decision_before_code':'For the first BF16 reference define the portable scale/zero/extreme policy in one public numerical contract, with the retained HIP normal finite arithmetic and BF16 rounding boundaries. Keep exceptional-domain differences visible and do not claim bit identity to every producer implementation.',
 'sources':[
 source_anchor('quark/torch/utils/pack.py',['class Pack_fp4','tensor = (tensor[..., 1] << 4) + tensor[..., 0]']),
 source_anchor('quark/torch/kernel/hw_emulation/csrc/mxfp4/fake_kernels.cuh',['uint16_t block_max_uint','uint8_t scale_exp','elem = hdiv_impl','out[idx] = hmul_impl']),
 source_anchor('quark/torch/kernel/hw_emulation/csrc/mxfp4/dequantize_kernels.cuh',['e8m0_to_half','out_thread[FP4_PER_BYTE * i]']),
 source_anchor('quark/torch/kernel/hw_emulation/csrc/mxfp4/low_precision_intrinsics.cuh',['e8m0_to_half(uint8_t scale)','return __hdiv','return __hmul']),
 source_anchor('quark/torch/quantization/utils.py',['def even_round','masked_fill_(zero_mask'])]
}
proof=json.loads((base/'producer/tag-1b229f7-source-comparison.json').read_text(encoding='utf-8')); assert len(proof)==25 and all(x['equal'] for x in proof)
r['confirmed_producer_math']['provenance']['verified_comparison_count']=len(proof)
r['minimal_new_semantic_recommendation']={
 'status':'Proposed physical/semantic scope only; no descriptors have been added by this review.',
 'dense_true_ports':'3: BF16 A[M,K], U8 W[N,K/2], U8 SF[N,K/32] -> BF16[M,N]. Positive M/N, positive K%32=0; original adjacent nibble bytes and per-group scale. No WG/IG.',
 'grouped_true_ports':'4: BF16 A[T,1-or-S,K], U8 W[E,N,K/2], U8 SF[E,N,K/32], I32 IDs[T,S] -> BF16[T,S,N]. Permit source A shared/independent/zero-slot-stride with true token padding as existing family does; ordinary other ports remain dense.',
 'arithmetic':'Choose an explicit BF16 software reference after the portable zero/extreme decision, preserving BF16 normalized-value and reconstructed A/W boundaries. Default HIP versus optional Triton must not become an accidental backend difference. More input/output precision is separate scope, not inherited from source templates.',
 'not_a_fake_Nvfp4_call':'No constant-one WG/IG ports, no float8 E4 reinterpretation for U8 E8 scale, no change to existing ModelOpt/Local descriptors.',
 'primitive_boundary':'A typed linear reference is a natural exact leaf; ordinary compose BQRoundtrip+MLX remains mathematically different. Whole-model import and native hardware MXFP4 GEMM are separate capabilities.'}
r['shared_activation_layout_design']={
 'reason':'The Quark activation quantizer has no expert-selected global or W-scale input, so shared raw A also shares identical QDQ A. Existing NVFP4 per-selected expert IG behavior must remain unchanged.',
 'derived_cold_geometry':'selected_rows=T*S; quant_slots=(A.slotDim==1 or actualA.slotStride==0)?1:S; quant_rows=T*quant_slots. Dense uses quant_rows=selected_rows=M. Store true input token/slot strides as now; no expanded A.',
 'quantize_once':'Traverse quant_rows*(K/32) once, reconstruct producer BF16 QDQ into2*quant_rows*K caller/native scratch. Dot row(t,s) reads qrow=t*quant_slots+(quant_slots==1?0:s). Never recompute A perN or per selected expert for the shared case.',
 'ID_status':'Retain one full-ID gate before any selected W/SF address. It can remain the first device phase even though quantizer itself does not load expert metadata. No host ID download or new synchronization is required.',
 'bounded_weight':'Each output reads only selected expert and one original group32 code/SF tile, rounds W operands before reduction, and discards the tile. No N*K or E*N*K floating bank.',
 'cold_family_policy':'Separate source-shared quantization from expert-dependent quantization in private cold geometry, not a user flag. The old ModelOpt/Local mode still uses quant_rows=T*S due to selected IG.',
 'row_tiles':'Do not enable CUDA Rows4 across arbitrary selected experts. A shared quantized A does not imply common weights; preserve Rows1 grouped until a proven same-bank tile algorithm exists.',
 'memory_reporting':'CPU/CUDA scratch2*quant_rows*K. Apple/Vulkan own native QDQ and check/status arrays; Apple quant checks become4*quant_rows*(K/32), dot checks4*selected_rows*N plus IDs. Total/private opaque allocations remain separate and unknown.'}
r['must_be_confirmed_before_implementation']=[
 'Select one portable BF16 arithmetic definition for zero groups, rounded-amax overflow and extreme scale codes; do not pretend HIP source log2(0)->int is a portable rule.',
 'Decide whether the first public reference accepts all U8 scale codes with source BF16 Inf/NaN propagation or imposes an explicit documented source domain. Never inherit NVFP4 positive-finite global checks onto a nonexistent port.',
 'Keep the declared F32 reduction-tree boundary versus producer GEMM exactness honest; BF16 reconstructed operands do not guarantee arbitrary sums match every library reduction.',
 'Confirm the target fixture/API scope is BF16 as actual model config; F16 producer templates have separate scale-decoder behavior and are not automatically included.'
]
for b in r['backend_reuse']:
 if b['backend']=='native CPU':
  b['required_if_math_confirms']='Refactor baked kGroup16 and globals into one private cold geometry/codec policy; exact 3/4ports for Quark versus old5/6ports. Select source-shared or expert-dependent quantization rows explicitly, preserve old numeric functions. Reuse existing mappings and parallel executor.'
  b['workspace']='For proposed BF16 reconstructed-operand reference, caller2*quant_rows*K bytes; shared A1/zeroS quant_rows=T and AS quant_rows=T*S. Weight tile grows only16->32 elements. Do not retain a full floating bank.'
 elif b['backend']=='native CUDA':
  b['required_if_math_confirms']='One new private group32 codec and cold port/scale policy; true3/4input alignment/byte spans, quant_rows separate from selected_rows, and BF16 source rounding. Resolve exact kernels during prepare and retain original vtable/status/capture. No hot function lookup.'
  b['row_sharing']='Quantizer independent of selected metadata: shared A1/zeroS quantizes T rows, AS quantizes T*S; dot maps output rows back to that QDQ array. Rows4 decode-sharing remains dense only; selected expert differences require Rows1.'
 elif b['backend']=='Apple':
  b['required_if_math_confirms']='Retain one native FP4 template family; source group32 and 3/4ports are cold policy, quant_rows differs from output_rows for shared A. Implement exact source BF16 normalize/product and E8M0 bit mapping with existing shared IEEE helpers; retain ID dependency and status reductions.'
 elif b['backend']=='Vulkan':
  b['required_if_math_confirms']='Use the same Program, origins and native phase generator with private group32 codec/port policy; true3/4inputs, explicit quant_rows and qrow mapping, ID gate before W/SF addresses. Original six/seven descriptor palette is sufficient; internal status/scratch descriptors do not create fictitious public globals.'
r['ordinary_composition']['missing_semantic_condition']='Confirmed default HIP uses source BF16 divide, ties-even and BF16 multiply with the MX even scale policy. Existing BQRoundtrip ceil+floor policy and MLX scale-after-group-dot are not equivalent. A separate clearly named typed software reference can share existing execution without changing those operations.'
r['ordinary_composition']['source_layout']='The retained exporter now confirms adjacent low-even/high-odd U8 bytes and ignores reorder for Pack_fp4. Use those original bytes directly; no cold repacking or dense expansion is needed for these fixed sources.'
r['private_family_refactor']['worthwhile_when']='The confirmed group32 U8 E2M1/E8M0 contract now justifies extending one private FP4 reference family per backend. Share mapping/traversal/status while keeping distinct ModelOpt, Local and Quark codec/math policies. No code edit has occurred in this review.'
r['private_family_refactor']['minimum_abstraction'].append('Separate quant_rows/quant_slots from selected output rows so expert-independent shared A is QDQd once per token; retain selected-dependent NVFP4 IG semantics.')
newh=base/'artifact/30/model-00019-of-00062.safetensors/header.json'; entries=json.loads(newh.read_text(encoding='utf-8')); pairs=[]
for k,v in entries.items():
 if not isinstance(v,dict) or v.get('dtype')!='U8' or not k.endswith('.weight'):continue
 sf=entries.get(k[:-7]+'.weight_scale')
 if sf and sf.get('dtype')=='U8':
  geom={'weight':v['shape'],'scale':sf['shape']}
  if geom not in [x['geometry'] for x in pairs]:pairs.append({'example':k,'geometry':geom})
r['artifact_header_context']['header_only'].append({'artifact_index':30,'repository':'amd/GLM-5.3-Flash-Quark-MXFP4','revision':'b5688f25491202978c19c4d036eef579f61bbe07','file':newh.parent.name,'header':identity(newh),'tensor_count':len(entries),'u8_weight_scale_shape_examples':pairs,'payload_bytes_read':0,'interpretation':'Actual ordinary group32 U8 W/SF pairs; retained first shard was FP8/BF16 and does not negate mixed MXFP4 roles.'})
r['artifact_header_context']['artifact_facts']=identity(base/'artifact/artifact-facts.json')
r['artifact_header_context']['limits']='Actual16/23 and30 ordinary roles contain U8[N,K/2] and U8[N,K/32] pairs. Producer Pack_fp4 proves adjacent nibble order for fixed sources. Mixed FP8/BF16 overrides remain separate; first-shard or repository-wide naming is not a role-wide proof. No payload values were read.'
r['revision_notes']=['Initial local map kept producer arithmetic/reorder unknown. This final read-only revision incorporates root/K3 fixed source proof and quant actual30 ordinary header; no product/API implementation or execution was added.']
p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'hyle_sources':len(r['source_inventory']),'headers':len(r['artifact_header_context']['header_only']),'producer_comparisons':len(proof)}))
