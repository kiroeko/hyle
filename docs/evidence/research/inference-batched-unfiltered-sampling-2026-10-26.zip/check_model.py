"""One original tiny Model flow with a real unfiltered R2 policy cohort."""
import importlib.util,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/inference-current-closure-20261026'
spec=importlib.util.spec_from_file_location('model_local_runner',W/'check_math.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
read,pin,save,execute=h.read,h.pin,h.save,h.execute
REL='tests/tools/qwen_sampling_policy_case.h'
def prepare():
    p=W/'source'/REL;text=(R/REL).read_text(encoding='utf-8-sig')
    text=text.replace('q::SamplingConfiguration{true, {.7F, (std::min)(std::size_t{8}, static_cast<std::size_t>(geometry.vocabulary)), .9F}}};',
      'q::SamplingConfiguration{true, {.7F, (std::min)(std::size_t{8}, static_cast<std::size_t>(geometry.vocabulary)), .9F}},\n      q::SamplingConfiguration{true, {1.F, 0, 1.F}}};')
    marker='  const std::array<std::size_t, 6> policy{0, 0, 2, 2, 1, 1};'
    assert text.count(marker)==1
    text=text.replace(marker,'''  // The original filtered boundary producer remains independent of the new R2 cohort.
  const std::array boundary_chunks{prompt.size()};
  model.prepare_family(boundary_chunks, false, 1, q::GraphRole::kText, false, q::TextCompletion::kEmitNext, 2);
  model.plan_replay_uses(prompt.size(), 1, 2, q::GraphRole::kText, q::TextCompletion::kEmitNext, 2);
'''+marker)
    assert text.count('policy{0, 0, 2, 2, 1, 1}')==1;text=text.replace('policy{0, 0, 2, 2, 1, 1}','policy{0, 0, 3, 3, 1, 1}')
    needle='  preflight(model); boundaries(model, prompt, suffix);'
    assert text.count(needle)==1
    text=text.replace(needle,'''  std::size_t batched_families = 0, flat_identity_phases = 0;
  for (const auto &[key, family] : model.families)
    if (key.requests == 2 && key.sampling_index == 3) {
      require(family->batched_text_sampling, "unfiltered R2 family did not select the batched identity contract");
      ++batched_families;
    }
  for (auto &[key, phase] : model.phases)
    if (key.requests == 2 && key.sampling_index == 3) {
      require(phase->batched_text_sampling && phase->sampling_identities.description.rank() == 2 &&
          phase->sampling_identities.description.dimensions()[0] == 2 &&
          phase->sampling_identities.description.dimensions()[1] == 4,
          "unfiltered R2 phase identity storage is not the real [R,4] port");
      ++flat_identity_phases;
      if (key.tokens == 1) {
        std::array<std::uint32_t, 8> actual;
        q::check(model.execution.read(phase->sampling_identities.storage(), std::as_writable_bytes(std::span(actual))));
        const auto first = q::cache::SamplingCursor{123, 2, 4}.identity();
        const auto second = q::cache::SamplingCursor{123, 3, 4}.identity();
        const auto matches = [&](std::size_t row, const auto &expected) {
          return std::equal(expected.begin(), expected.end(), actual.begin() + row * 4);
        };
        require((matches(0, first) && matches(1, second)) || (matches(0, second) && matches(1, first)),
            "unfiltered R2 final decode lost distinct original request identities/draw4");
      }
    }
  require(batched_families && flat_identity_phases, "tiny Model never entered actual unfiltered R2 sampling");
  std::cout << "batched_text_sampling=true flat_identity_rows=2 flat_identity_words=4 families="
      << batched_families << " phases=" << flat_identity_phases << '\\n';
  preflight(model); boundaries(model, prompt, suffix);''')
    assert '\\"configurations\\":3' in text;text=text.replace('\\"configurations\\":3','\\"configurations\\":4')
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text,encoding='utf-8')
    todo=['engine/models/qwen35/main.cc',REL];seen=set()
    while todo:
        rel=todo.pop()
        if rel in seen:continue
        seen.add(rel);dest=W/'source'/rel;canonical=R/rel
        if not dest.exists():dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(canonical,dest)
        for match in re.finditer(r'^\s*#\s*include\s*(["<])([^">]+)[">]',dest.read_text(encoding='utf-8-sig'),re.M):
            name=match[2]
            if name.startswith('hyle/'):child=R/'include'/name
            elif match[1]=='"':child=(canonical.parent/name).resolve()
            else:continue
            if child.is_file() and child.is_relative_to(R) and not child.is_relative_to(R/'.scratch'):todo.append(str(child.relative_to(R)))
    save(W/'model-frozen-project-inputs.json',[pin(W/'source'/rel) for rel in sorted(seen)])
def build():
    prepare();out=W/'model2';assert not out.exists();out.mkdir()
    source=out/'consumer.cc';source.write_text('#include "../source/engine/models/qwen35/main.cc"\n#include "../source/tests/tools/qwen_sampling_policy_case.h"\nint main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("sampling-policies INPUTS");return qwen_sampling_policy_case::run(argv[1]);}catch(const std::exception &e){std::cerr<<"sampling_policy_case_failure="<<e.what()<<"\\n";return 1;}}\n')
    cmd=read(B/'engine/model/command.json')['command'];compiler=cmd[0]
    cmd=[str(source) if x==str(R/'engine/models/qwen35/main.cc') else x for x in cmd]
    stage=out/'compile';obj=stage/'unit.obj';cmd[cmd.index('/sourceDependencies')+1]=str(stage/'dependencies.json')
    cmd=[('/Fo'+str(obj)) if x.startswith('/Fo') else ('/Fd'+str(stage/'unit.pdb')) if x.startswith('/Fd') else x for x in cmd]
    cmd[1:1]=['/I'+str(W/'source/include'),'/I'+str(W/'source'),'/I'+str(W/'source/engine/models/qwen35')]
    env=h.h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=execute(cmd,env,stage,timeout=120);d=read(stage/'dependencies.json')['Data'];save(stage/'actual-dependencies.json',[pin(Path(p)) for p in dict.fromkeys([d['Source'],*d['Includes']])])
    original=read(B/'link-current/process/command.json')['command'];entry=str(B/'engine/entry/unit.obj');model=str(B/'engine/model/unit.obj')
    assert original.count(entry)==original.count(model)==1
    args=[str(obj) if x==model else x for x in original if x!=entry and not x.lower().startswith(('/out:','/pdb:','/implib:','/map:'))]
    save(out/'link-inputs.json',[pin(Path(x)) for x in args if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')])
    image=out/'link/component.exe';linked=execute([*args,'/OUT:'+str(image),'/PDB:'+str(image.with_suffix('.pdb'))],env,image.parent,timeout=120)
    native=Path(read(B/'ready-current.json')['native']['path']);os.link(native,image.parent/native.name)
    runtime=read(B/'runtime-current.json');runtime['PATH']=str(image.parent)+os.pathsep+runtime['PATH'];save(out/'runtime.json',runtime)
    fixture=R/'.scratch/inference-e4-model-20261025/fixture-preparation/bf16-original'
    save(out/'ready.json',{'image':pin(image),'compile':compiled,'link':linked,'fixture':pin(fixture/'weights.tsv'),'runtime':pin(out/'runtime.json'),'new_TUs':1,'SDK_builds':0,'private_helper':pin(W/'source'/REL)})
def run():
    out=W/'model2';ready=read(out/'ready.json');assert pin(Path(ready['image']['path']))==ready['image']
    runtime=read(out/'runtime.json');env=dict(os.environ);env['PATH']=runtime['PATH'];env.update(runtime.get('configured_flags',{}));env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    fixture=Path(ready['fixture']['path']).parent;process=execute([ready['image']['path'],str(fixture)],env,out/'run',timeout=120)
    text=(out/'run/stdout.log').read_text(encoding='utf-8-sig');assert 'batched_text_sampling=true flat_identity_rows=2 flat_identity_words=4' in text
    result=json.loads(next(line for line in reversed(text.splitlines()) if line.startswith('{')));assert result['status']=='PASS' and result['configurations']==4 and result['requests']==6 and result['turns']==12
    save(out/'summary.json',{'status':'TINY_MODEL_SAMPLING_POLICIES_BATCHED_IDENTITY_PASS','process':process,'ready':pin(out/'ready.json'),'result':result,'GPU_released':True,'no_TPS_or_quality_claim':True});print('GPU_TERMINAL_RELEASED',process,flush=True)
if __name__=='__main__':{'build':build,'run':run}[sys.argv[1]]()
