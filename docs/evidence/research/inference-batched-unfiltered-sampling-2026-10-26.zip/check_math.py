"""Bounded existing CPU/CUDA closures, one changed formal test TU per backend."""
import hashlib,importlib.util,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('retained_local_execute',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
pin,save,execute=h.pin,h.save,h.execute
def read(p):return json.loads(p.read_bytes())
def freeze():
    todo=['tests/graph_route_cpu/qwen_sampling_graph_test.cc'];seen=set()
    while todo:
        rel=todo.pop()
        if rel in seen:continue
        seen.add(rel);dest=W/'source'/rel;canonical=R/rel
        if not dest.exists():dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(canonical,dest)
        for match in re.finditer(r'^\s*#\s*include\s*(["<])([^">]+)[">]',dest.read_text(),re.M):
            name=match[2]
            if name.startswith('hyle/'):candidate=R/'include'/name
            elif match[1]=='"':candidate=(canonical.parent/name).resolve()
            else:continue
            if candidate.is_file() and candidate.is_relative_to(R) and not candidate.is_relative_to(R/'.scratch'):
                todo.append(str(candidate.relative_to(R)))
    save(W/'frozen-project-inputs.json',[pin(W/'source'/rel) for rel in sorted(seen)])
def build(kind):
    freeze();out=W/(kind+('2' if (W/(kind+'1')).exists() else '1'));assert not out.exists();out.mkdir()
    old=R/'.scratch/inference-cpu-cold-options-20261025/host3'
    args=read(old/'compile/command.json')['command'];compiler=args[0]
    oldsrc=str(old/'source');source=W/'source/tests/graph_route_cpu/qwen_sampling_graph_test.cc'
    stage=out/'compile';obj=stage/'unit.obj'
    cmd=[]
    for a in args:
        if a==str(old/'source/consumer.cc'):a=str(source)
        else:a=a.replace(oldsrc,str(W/'source'))
        if a.startswith('/Fo'):a='/Fo'+str(obj)
        elif a.startswith('/Fd'):a='/Fd'+str(stage/'unit.pdb')
        cmd.append(a)
    cmd[cmd.index('/sourceDependencies')+1]=str(stage/'dependencies.json')
    if kind=='cuda':
        cmd.extend(['/DHYLE_TEST_QWEN_SAMPLING_CUDA=1','/DHYLE_COMPUTE_CUDA=1','/external:IC:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v13.3\\include'])
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=execute(cmd,env,stage,timeout=120)
    d=read(stage/'dependencies.json')['Data'];save(stage/'actual-dependencies.json',[pin(Path(p)) for p in dict.fromkeys([d['Source'],*d['Includes']])])
    if kind=='cpu':
        link=read(old/'link/command.json')['command'];removed=str(old/'compile/unit.obj')
        assert link.count(removed)==1
        link=[str(obj) if a==removed else a for a in link if not a.lower().startswith(('/out:','/pdb:','/implib:','/map:'))]
        link.extend([str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')])
    else:
        base=R/'.scratch/inference-current-closure-20261026';link=read(base/'link-current/process/command.json')['command'];removed=str(base/'engine/entry/unit.obj')
        assert link.count(removed)==1
        link=[str(obj) if a==removed else a for a in link if not a.lower().startswith(('/out:','/pdb:','/implib:','/map:'))]
    inputs=[pin(Path(a)) for a in link if Path(a).is_absolute() and Path(a).suffix.lower() in ('.obj','.lib')];save(out/'link-inputs.json',inputs)
    image=out/'link/sampling.exe';linked=execute([*link,'/OUT:'+str(image),'/PDB:'+str(image.with_suffix('.pdb'))],env,image.parent,timeout=120)
    runtime=read(R/'.scratch/inference-current-closure-20261026/runtime-current.json');runtime['PATH']=str(image.parent)+os.pathsep+runtime['PATH']
    # Original current CPU native is reused exactly, without a renamed ABI guess.
    native=Path(read(R/'.scratch/inference-current-closure-20261026/ready-current.json')['native']['path']);os.link(native,image.parent/native.name)
    save(out/'runtime.json',runtime);save(out/'ready.json',{'image':pin(image),'source':pin(source),'compile':compiled,'link':linked,'native':pin(native),'runtime':pin(out/'runtime.json'),'link_inputs':pin(out/'link-inputs.json'),'source_pins':pin(W/'source-pins.json'),'new_TUs':1,'SDK_builds':0})
    print('BUILT_NOT_RUN',kind,flush=True)
def run(kind):
    out=W/(kind+('2' if (W/(kind+'2/ready.json')).exists() else '1'));ready=read(out/'ready.json');assert pin(Path(ready['image']['path']))==ready['image']
    env=dict(os.environ);runtime=read(out/'runtime.json');env['PATH']=runtime['PATH'];env.update(runtime.get('configured_flags',{}));env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    if kind=='cpu':
        original=read(R/'.scratch/inference-cpu-cold-options-20261025/host3/runtime.json')
        native=Path(original['native']['path']);assert pin(native)==original['native']
        alias=Path(ready['image']['path']).parent/native.name
        if not alias.exists():os.link(native,alias)
        assert os.path.samefile(native,alias)
        env['PATH']=str(alias.parent)+os.pathsep+original['PATH']
        save(out/'native-cpu-runtime.json',{'original':original['native'],'same_file_alias':pin(alias),'PATH':env['PATH'],'basis':'Exact native consumed by the reused host3 core closure; no renamed ABI guess.'})
    stage=out/('run2' if (out/'run').exists() else 'run')
    xml=stage/'results.xml';process=execute([ready['image']['path'],'--gtest_filter=QwenSamplingGraph.Policy*:QwenSamplingGraph.UnfilteredBatchMatchesRowsKeysAndValidity','--gtest_output=xml:'+str(xml)],env,stage,timeout=120)
    save(out/'summary.json',{'status':'FINITE_MATH_POLICY_AND_BATCH_PASS','backend':kind,'process':process,'ready':pin(out/'ready.json'),'XML':pin(xml),'no_Model_or_TPS':True})
    print('TERMINAL_FINITE_MATH',kind,process,flush=True)
if __name__=='__main__':{'build':build,'run':run}[sys.argv[1]](sys.argv[2])
