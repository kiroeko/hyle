"""Offline matched-cohort summaries of the already completed W13 profiles."""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib
import json
import sqlite3
import statistics
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent


def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())


def merged(xs):
    out=[]
    for a,b in sorted(xs):
        if b<=a:continue
        if out and a<=out[-1][1]:out[-1][1]=max(out[-1][1],b)
        else:out.append([a,b])
    return out


def measure(xs):return sum(b-a for a,b in merged(xs))


def stats(xs):
    xs=list(xs)
    return dict(count=len(xs),mean=statistics.mean(xs),median=statistics.median(xs),minimum=min(xs),maximum=max(xs)) if xs else None


def folder(name):return W/'runs'/('r1-peer-attempt2' if name=='r1-peer' else name)


def roots(name):return read(folder(name)/'roots.json')


def strict_hot(r):
    return not r['recording_API_counts'] and r['native_graph_launches']==1


def ordinary_cohort(prefix):
    arms=[prefix+'-off',prefix+'-auto',prefix+'-peer']
    maps={a:{r['seq']:r for r in roots(a) if r['meta'].get('target_T',r['meta'].get('T'))==1} for a in arms}
    seqs=sorted(set.intersection(*(set(m) for m in maps.values())))
    assert len(seqs)==96
    for seq in seqs:
        expected=154+seq-2
        for arm,m in maps.items():
            meta=m[seq]['meta']
            assert meta.get('c0',meta.get('context'))==expected,(arm,seq,meta)
            assert meta.get('R',1)==(2 if prefix=='b2' else 1)
    hot=[s for s in seqs if all(strict_hot(maps[a][s]) for a in arms)]
    steady=[s for s in hot if s>=10]  # Excludes actual first eight decode ordinals, identically for all arms.
    assert len(steady)==88
    cohorts={}
    for label,selected in [('common_no_record_single_native',hot),('common_after_first8',steady)]:
        cohorts[label]=dict(sequences=selected,arms={})
        for arm in arms:
            rows=[maps[arm][s] for s in selected]
            cohorts[label]['arms'][arm]=dict(
                root_wall_ms=stats(r['wall_ns']/1e6 for r in rows),
                gpu_union_ms=stats(r['gpu_union_ns']/1e6 for r in rows),
                kernel_union_ms=stats(r['kernel_union_ns']/1e6 for r in rows),
                kernel_count=stats(r['kernel_count'] for r in rows),
                copies={kind:{field:stats(r['memcpy'].get(kind,{}).get(field,0)/(1e6 if field=='sum_ns' else 1) for r in rows)
                       for field in ('count','bytes','sum_ns')} for kind in sorted({k for r in rows for k in r['memcpy']})})
    return cohorts


def phase_costs(name):
    rs=roots(name)
    decode=[r for r in rs if r['meta'].get('target_T',r['meta'].get('T'))==1]
    byseq={r['seq']:r for r in decode}
    pair_a={};pair_b=set()
    for first,second in zip(decode,decode[1:]):
        if second['start_ns']<first['end_ns']:
            pair_a[first['seq']]=second['seq'];pair_b.add(second['seq'])
    grouped=defaultdict(list)
    for r in decode:
        group='first8' if r['seq']<=9 else 'pair_a' if r['seq'] in pair_a else 'pair_b' if r['seq'] in pair_b else 'single_or_tail'
        grouped[group].append(r)
    result={}
    for group,rs in grouped.items():
        labels=sorted({p['label'] for r in rs for p in r['phases']})
        result[group]=dict(root_count=len(rs),root_wall_ms=stats(r['wall_ns']/1e6 for r in rs),
            phase_call_wall_ms_inclusive_do_not_add={label:stats(p['wall_ns']/1e6 for r in rs for p in r['phases'] if p['label']==label) for label in labels})
    q=read(folder(name)/'quality.json')
    top=[(p['start_ns'],p['end_ns']) for r in roots(name) for p in r['phases'] if p['label'] in ('hyle/prepare','hyle/submit','hyle/wait_publish')]
    result['whole_model_root_envelope']=dict(root_wall_sum_ms=q['root_wall_sum_ns']/1e6,
        root_wall_union_ms=q['root_wall_union_ns']/1e6,root_envelope_ms=q['root_envelope_ns']/1e6,
        between_root_residual_ms=q['root_between_or_outer_envelope_residual_ns']/1e6,
        not_in_top_phase_union_ms=(q['root_envelope_ns']-measure(top))/1e6,
        boundary='Residual includes unlabelled helper/source preparation/ledger/inter-root work, NVTX overhead and possible GPU overlap; not CPU self-time. Work before first or after final Model root lies outside this envelope.')
    return result


def kernel_inventory(name,selected):
    f=folder(name)
    con=sqlite3.connect((f/'trace.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    con.row_factory=sqlite3.Row
    nvtx=[dict(x) for x in con.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start') if x['label']]
    apis=[dict(x) for x in con.execute('SELECT a.*,s.value api FROM CUPTI_ACTIVITY_KIND_RUNTIME a JOIN StringIds s ON s.id=a.nameId ORDER BY a.start')]
    seq_to_cids=defaultdict(set)
    # Same successful root attribution rule, limited to API activities inside
    # actual seq-labelled call phases. No wall-root overlap attribution.
    for row in apis:
        owners={int(n['uint64Value']) for n in nvtx if n['end'] is not None and n['uint64Value'] in selected and
                n['label'] in ('hyle/prepare','hyle/submit','hyle/wait_publish','hyle/completion_wait','hyle/postwait_publish',
                               'peer/prepare','peer/llama_decode','peer/synchronize','peer/sample_publish') and
                n['globalTid']==row['globalTid'] and n['start']<=row['start'] and row['end']<=n['end']}
        assert len(owners)<=1
        if owners:seq_to_cids[next(iter(owners))].add(row['correlationId'])
    cids=set().union(*seq_to_cids.values())
    strings=dict(con.execute('SELECT id,value FROM StringIds'))
    groups=defaultdict(lambda:[0,0])
    for row in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL'):
        if row['correlationId'] not in cids:continue
        key=(strings[row['shortName']],row['gridX'],row['gridY'],row['gridZ'],row['blockX'],row['blockY'],row['blockZ'])
        groups[key][0]+=1;groups[key][1]+=row['end']-row['start']
    con.close()
    return [dict(name=k[0],grid=list(k[1:4]),block=list(k[4:]),count_per_root=v[0]/len(selected),sum_us_per_root=v[1]/len(selected)/1000,
                 mean_kernel_us=v[1]/v[0]/1000) for k,v in sorted(groups.items(),key=lambda p:-p[1][1])]


def main():
    x=dict(status='OFFLINE_ALL8_CURRENT_PROFILES_ANALYZED',
        scope='Eight successful diagnostic processes plus one retained loading-only wrong-GGUF failure. No new timing benchmark or cross-engine same-continuation-ID claim.',
        ordinary={p:ordinary_cohort(p) for p in ('r1','b2')},
        hyle_phases={name:phase_costs(name) for name in ('r1-off','r1-auto','b2-off','b2-auto')},mtp={})
    for name in ('mtp-hyle','mtp-peer'):
        rs=roots(name);report=read(folder(name)/'report.json')
        records=[r for r in rs if r['recording_API_counts']]
        x['mtp'][name]=dict(root_count=len(rs),record_or_update_root_sequences=[r['seq'] for r in records],
            recording_API_counts=dict(Counter(k for r in records for k,v in r['recording_API_counts'].items() for _ in range(v))),
            actual_work={k:report[k] for k in ('generated_tokens','generated_decode_tokens','actual_graph_calls','actual_target_rows','actual_draft_rows','verified_target_rows','agreements','accepted_drafts','target_decode_calls','draft_decode_calls','proposals') if k in report},
            constraint='Hyle combines draft/target in one Model invocation; peer exposes separate actual target/draft calls. Compare native subgraphs only with current source/correlation proof, not root-count equivalence.')
    save(W/'analysis-summary.json',x)
    inventory={name:kernel_inventory(name,x['ordinary'][prefix]['common_after_first8']['sequences'])
               for prefix in ('r1','b2') for name in (prefix+'-off',prefix+'-auto',prefix+'-peer')}
    save(W/'kernel-inventory.json',inventory)
    print('OFFLINE_ANALYSIS_READY')
    for prefix in ('r1','b2'):
        c=x['ordinary'][prefix]['common_after_first8']
        print(prefix,'common roots',len(c['sequences']))
        for arm,r in c['arms'].items():print(arm,'GPUms',r['gpu_union_ms']['mean'],'kernels',r['kernel_count']['mean'],'D2D',r['copies'].get('8'))
    print('MTP',x['mtp'])


if __name__=='__main__':main()
