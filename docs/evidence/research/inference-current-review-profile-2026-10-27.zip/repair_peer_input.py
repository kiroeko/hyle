"""Offline metadata/command correction for the one authorized input retry."""
from pathlib import Path
import json
import struct
W=Path(__file__).resolve().parent
R=W.parent.parent


def scalar(f, kind, keep):
    formats={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}
    if kind==8:
        n=struct.unpack('<Q',f.read(8))[0]
        if keep:return f.read(n).decode('utf-8')
        f.seek(n,1);return None
    if kind==9:
        elem,n=struct.unpack('<IQ',f.read(12))
        if elem in formats and not keep:
            f.seek(struct.calcsize('<'+formats[elem])*n,1);return None
        out=[]
        for _ in range(n):
            x=scalar(f,elem,keep)
            if keep:out.append(x)
        return out if keep else None
    data=f.read(struct.calcsize('<'+formats[kind]))
    return struct.unpack('<'+formats[kind],data)[0] if keep else None


def metadata(path):
    with path.open('rb') as f:
        magic,version,nt,nk=struct.unpack('<IIQQ',f.read(24))
        assert magic==0x46554747 and version in (2,3)
        selected={}
        for _ in range(nk):
            key=scalar(f,8,True);kind=struct.unpack('<I',f.read(4))[0]
            keep=key in ('general.architecture','qwen35.block_count') or 'nextn' in key
            value=scalar(f,kind,keep)
            if keep:selected[key]=value
        return dict(path=str(path),bytes=path.stat().st_size,tensors=nt,metadata=selected,
                    metadata_end=f.tell(),tensor_payload_read=False)


def main():
    base=R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'
    plain=metadata(base/'Qwen3.5-2B-text-BF16.gguf')
    full=metadata(base/'Qwen3.5-2B-text-MTP-BF16.gguf')
    receipt=json.loads((base/'converted-file-identity.json').read_bytes())
    audit=json.loads((base/'converted-model-audit.json').read_bytes())
    assert plain['bytes']==receipt['bytes'] and plain['tensors']==audit['tensors']==320
    assert plain['metadata']['general.architecture']=='qwen35' and plain['metadata']['qwen35.block_count']==24
    assert all(v==0 for k,v in plain['metadata'].items() if 'nextn' in k)
    assert any(v==1 for k,v in full['metadata'].items() if 'nextn' in k)
    x=json.loads((W/'plan.json').read_bytes())
    entry=next(r for r in x['commands'] if r['name']=='r1-peer')
    old=entry['consumer'][entry['consumer'].index('--model')+1]
    assert old==full['path']
    entry['consumer'][entry['consumer'].index('--model')+1]=plain['path']
    folder=W/'runs/r1-peer-attempt2';entry['run_directory']='r1-peer-attempt2'
    entry['profile']=[s.replace(str(W/'runs/r1-peer'),str(folder)).replace(old,plain['path']) for s in entry['profile']]
    entry['consumer']=[s.replace(str(W/'runs/r1-peer'),str(folder)) for s in entry['consumer']]
    assert next(r for r in x['commands'] if r['name']=='b2-peer')['consumer'][1]==plain['path']
    x['original_plan_preserved']=str(W/'plan.json')
    x['input_retry']=dict(logical_arm='r1-peer',attempt=2,original_failure_directory=str(W/'runs/r1-peer'),
        reason='Ordinary native consumer requires target-only metadata; original full-MTP GGUF was rejected before any logical root.',
        original_process_exit=1,original_logical_roots=0,previous_successful_arms_not_repeated=True)
    (W/'run-plan2.json').write_bytes((json.dumps(x,indent=2)+'\n').encode())
    proof=dict(plain=plain,full_mtp=full,historical_full_file_identity=receipt,
        original_success_command=str(R/'.scratch/inference-current-closure-20261026/full-window/single-timing/03-peer_plain/command.json'),
        current_payload_rehashed=False,scope='Only GGUF metadata and file size read now; historical full-file SHA is explicitly cited, not newly recomputed.')
    (W/'peer-input-correction.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
    print(json.dumps(proof,indent=2))


if __name__=='__main__':main()
