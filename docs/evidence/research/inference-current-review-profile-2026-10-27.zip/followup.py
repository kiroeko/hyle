"""Offline actual-correlation follow-up of the eight already retained traces."""
from pathlib import Path
from collections import Counter, defaultdict
import bisect
import json
import sqlite3
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent

def read(p): return json.loads(p.read_bytes())
def measure(xs):
    end = -1; total = 0
    for a, b in sorted(xs):
        if b > max(a, end): total += b-max(a, end)
        end = max(end, b)
    return total

def analyze(name):
    f = W/'runs'/('r1-peer-attempt2' if name == 'r1-peer' else name)
    roots = read(f/'roots.json'); report = read(f/'report.json')
    c = sqlite3.connect((f/'trace.sqlite').resolve().as_uri()+'?mode=ro&immutable=1', uri=True)
    c.row_factory = sqlite3.Row
    s = dict(c.execute('SELECT id,value FROM StringIds'))
    root_tid = {}
    for n in c.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId'):
        label=n['label'] or ''
        if label.startswith(('hyle/episode ', 'peer/b2_episode ', 'peer/target_prefill seq=',
                             'peer/target_decode seq=', 'peer/draft_prefill seq=', 'peer/draft_decode seq=')):
            root_tid[n['uint64Value']]=n['globalTid']
    assert len(root_tid)==len(roots)
    tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    api = []
    for table in ('RUNTIME', 'DRIVER'):
        if 'CUPTI_ACTIVITY_KIND_'+table in tables:
            api += [dict(r, api=s[r['nameId']]) for r in c.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_'+table)]
    api.sort(key=lambda r:r['start']); starts = [r['start'] for r in api]
    owner = {}; api_of = {}
    for r in roots:
        phases = r['phases']
        if 'peer' in name:
            phases = phases+[dict(start_ns=r['start_ns'], end_ns=r['end_ns'])]
        for p in phases:
            for i in range(bisect.bisect_left(starts,p['start_ns']), bisect.bisect_left(starts,p['end_ns'])):
                a = api[i]
                if a['end'] > p['end_ns'] or a['globalTid'] != root_tid[r['seq']]: continue
                cid = a['correlationId']
                assert cid not in owner or owner[cid] == r['seq']
                owner[cid] = r['seq']; api_of[cid] = a['api']
    rows = []
    for table in ('KERNEL','MEMCPY','MEMSET'):
        rows += [dict(r, kind=table, seq=owner[r['correlationId']], api=api_of[r['correlationId']])
                 for r in c.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_'+table) if r['correlationId'] in owner]
    actual_count=Counter(y['seq'] for y in rows)
    assert all(actual_count[r['seq']]==r['gpu_activity_count'] for r in roots)
    result = {}
    for label, seqs in [('all_actual_roots',{r['seq'] for r in roots}),
                        ('common_after_first8',set(range(10,98)) if not name.startswith('mtp') else set())]:
        if not seqs: continue
        rr = [r for r in roots if r['seq'] in seqs]; ys = [r for r in rows if r['seq'] in seqs]
        ru = measure((r['start_ns'],r['end_ns']) for r in rr)
        gu = measure((r['start'],r['end']) for r in ys)
        result[label] = dict(root_count=len(rr), root_wall_union_ms=ru/1e6,
            root_wall_sum_ms=sum(r['wall_ns'] for r in rr)/1e6,
            root_envelope_ms=(max(r['end_ns'] for r in rr)-min(r['start_ns'] for r in rr))/1e6,
            actual_gpu_union_ms=gu/1e6, root_union_minus_gpu_union_ms=(ru-gu)/1e6,
            warning='Union difference is uncovered wall, not CPU self-time; peer root endpoints differ. Root sum double-counts overlap.')
    # This exact native kernel family is not, by its generic name alone, a
    # mathematical node ID. Frozen model shapes and the 36 occurrences supply
    # additional supporting evidence, recorded separately in the receipt.
    small = defaultdict(list)
    for y in rows:
        if y['kind']!='KERNEL' or s[y['shortName']]!='Kernel2': continue
        if (y['gridX'],y['gridY'],y['gridZ'],y['blockX'],y['blockY'],y['blockZ']) != (1,1,1,32,1,1): continue
        r=roots[y['seq']-1]
        if name.startswith('mtp'):
            if y['seq'] <= 9: continue
            role = r['meta'].get('role',r['label'].split(' seq=')[0])
        else:
            if y['seq'] < 10: continue
            role = 'ordinary_T1'
        small[(str(role),s[y['demangledName']])].append(y)
    result['one_warp_grid1_Kernel2'] = [dict(role=k[0],demangled=k[1],
        actual_roots=len({y['seq'] for y in ys}),launches=len(ys),
        launches_per_matching_root=len(ys)/len({y['seq'] for y in ys}),
        sum_us_per_matching_root=sum(y['end']-y['start'] for y in ys)/1000/len({y['seq'] for y in ys}),
        mean_launch_us=sum(y['end']-y['start'] for y in ys)/1000/len(ys)) for k,ys in small.items()]
    if name in ('r1-off','b2-off'):
        cp = [y for y in rows if y['kind']=='MEMCPY' and y['copyKind']==8 and y['seq']==20]
        stream=sorted((y for y in rows if y['seq']==20),key=lambda y:y['start'])
        neighbors=Counter()
        for i,y in enumerate(stream):
            if y['kind']!='MEMCPY' or y['copyKind']!=8: continue
            previous=next((s[z['shortName']] for z in reversed(stream[:i]) if z['kind']=='KERNEL'),'none')
            following=next((s[z['shortName']] for z in stream[i+1:] if z['kind']=='KERNEL'),'none')
            neighbors[(previous,following,y['bytes'])]+=1
        result['representative_seq20_D2D'] = dict(count=len(cp),bytes=sum(y['bytes'] for y in cp),
            sizes=dict(Counter(str(y['bytes']) for y in cp)),
            actual_accepting_APIs=dict(Counter(y['api'] for y in cp)),
            native_neighbor_patterns=[dict(previous=k[0],following=k[1],bytes=k[2],count=v) for k,v in neighbors.items()],
            warning='Native memcpy nodes are not indexed state bulk-copy proof. No kernel arguments or src/dst addresses were exported.')
    if name=='mtp-hyle':
        ledger=report['sessions'][0]['ledger']; records=[]
        for r in roots:
            if not r['recording_API_counts']: continue
            l=ledger[r['seq']-1]
            records.append(dict(seq=r['seq'],meta=r['meta'],API_counts=r['recording_API_counts'],
                ledger={k:l[k] for k in ('before_length','before_frontier','before_lag','after_length','after_frontier','after_lag','accepted','quota')},
                confirmed_transition=('first terminal role5/T1 graph family' if r['seq']==53 else
                    'lag0 role3 reentry after rejected seq42, not a new target width' if r['seq']==43 else
                    'lag1 role4 reentry after accepted role3 seq43' if r['seq']==44 else
                    'first use of role3/T2 family' if r['seq']==2 else
                    'first use of role4/T2 family' if r['seq']==3 else
                    'same observed R/T/role/physical slot; exact changing key operand not exported')))
        result['capture_record_rows']=records
        result['capture_limit']='Trace records API status and graph nodes but no tensor port pointers/private tuple values. Context length alone does not prove a capture miss. seq45/46 exact changing operand remains unlocated.'
    c.close(); return result

if __name__=='__main__':
    out={name:analyze(name) for name in ('r1-off','r1-auto','r1-peer','b2-off','b2-auto','b2-peer','mtp-hyle','mtp-peer')}
    (W/'followup-summary.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
    for name,x in out.items():
        print(name,x.get('common_after_first8',x['all_actual_roots']))
        print('small_projection_native_family',x['one_warp_grid1_Kernel2'])
