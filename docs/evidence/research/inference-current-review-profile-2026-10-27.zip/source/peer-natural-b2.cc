#include "logical_trace.h"
// Draft native equal-T multi-sequence consumer. Retained SDK/math unchanged.
// Not yet compiled/run; align observed episode order with the Hyle CLI before timing.
#define main retained_peer_single_session_main
#include "C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/peer-continuation/peer_benchmark.cpp"
#undef main

#include <exception>
#include "tools/qwen35_text/session_schedule.h"
#include "C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/src/llama-memory.h"

namespace peer_batch {
namespace schedule = qwen35::benchmark;
using Tokens = std::vector<llama_token>;

struct Pool;
struct Version {
    Pool * pool = nullptr;
    llama_seq_id id = -1;
    const Tokens * tokens = nullptr;
    std::size_t length = 0;
    llama_token next = LLAMA_TOKEN_NULL;
    ~Version();
};
struct Pool {
    llama_context * context;
    std::vector<bool> used;
    std::size_t live = 0, peak = 0;
    bool native_inflight = false;
    explicit Pool(llama_context * c, std::size_t count) : context(c), used(count, false) {}
    std::shared_ptr<Version> create() {
        const auto found = std::find(used.begin(), used.end(), false);
        if (found == used.end()) throw std::runtime_error("native sequence/version quota exhausted");
        const auto slot = static_cast<std::size_t>(found - used.begin());
        auto value = std::make_shared<Version>();
        value->pool = this; value->id = static_cast<llama_seq_id>(slot);
        used[slot] = true; ++live; peak = std::max(peak, live);
        return value;
    }
};
Version::~Version() {
    if (!pool) return;
    // Every call is synchronized before publication. Never recycle a native
    // seq id while an original decode or sampled-token access is in flight.
    if (pool->native_inflight) {
        llama_synchronize(pool->context);
        pool->native_inflight = false;
    }
    if (!llama_memory_seq_rm(llama_get_memory(pool->context), id, -1, -1)) std::terminate();
    pool->used[static_cast<std::size_t>(id)] = false;
    --pool->live;
}

struct Directory {
    struct Entry { std::shared_ptr<Version> version; std::uint64_t stamp; };
    std::vector<Entry> entries;
    std::size_t capacity, evictions = 0;
    std::uint64_t clock = 0;
    explicit Directory(std::size_t count) : capacity(count) { entries.reserve(count); }
    bool evict() {
        if (entries.empty()) return false;
        const auto oldest = std::min_element(entries.begin(), entries.end(),
            [](const Entry & a, const Entry & b) { return a.stamp < b.stamp; });
        entries.erase(oldest); ++evictions; return true;
    }
    std::shared_ptr<Version> lookup(const Tokens & target, std::size_t end, std::size_t minimum) {
        Entry * selected = nullptr;
        for (auto & entry : entries) {
            const auto & v = *entry.version;
            if (v.length < minimum || v.length > end || (selected && v.length <= selected->version->length)) continue;
            if (std::equal(v.tokens->begin(), v.tokens->begin() + static_cast<std::ptrdiff_t>(v.length), target.begin()))
                selected = &entry;
        }
        if (!selected) return {};
        selected->stamp = ++clock;
        return selected->version;
    }
    void publish(const std::shared_ptr<Version> & version) {
        for (auto & entry : entries) {
            const auto & old = *entry.version;
            if (old.length == version->length && std::equal(old.tokens->begin(),
                    old.tokens->begin() + static_cast<std::ptrdiff_t>(old.length), version->tokens->begin())) {
                entry.version = version; entry.stamp = ++clock; return;
            }
        }
        if (entries.size() == capacity) evict();
        entries.push_back({version, ++clock});
    }
};

struct Observation {
    std::string session, name;
    std::size_t turn = 0, logical_tokens = 0, graph_tokens = 0, visible = 0, reused = 0;
    llama_token next = LLAMA_TOKEN_NULL;
    bool prompt = false, hit = false, full_hit = false;
    double total = 0, lookup = 0, copy_api = 0, prepare = 0, decode = 0, synchronize = 0, sample = 0;
    std::uint32_t sampled_logits = 0;
    llama_seq_id source_seq = -1, target_seq = -1;
};
struct Phase {
    std::string name, begin_marker, end_marker;
    Point start{};
    double seconds = 0, step_sum = 0;
    std::size_t before = 0, after = 0;
};
struct Run {
    Tokens tokens;
    std::vector<Phase> phases;
    std::vector<llama_token> predictions;
    std::shared_ptr<Version> head;
    std::size_t visible = 0;
    bool stopped = false;
    Point start{}, endpoint{};
};
struct Call { std::size_t session, phase, local, first, count; };

std::size_t cache_bytes(llama_context * context) {
    // Exact retained private ABI, cold-only: these are actual KV + R/S buffer
    // sizes, excluding model and execution workspace. Not process VRAM usage.
    std::size_t total = 0;
    for (const auto & entry : llama_get_memory(context)->memory_breakdown()) {
        if (entry.second > (std::numeric_limits<std::size_t>::max)() - total)
            throw std::runtime_error("native cache backing byte sum overflow");
        total += entry.second;
    }
    return total;
}

// R is the maximum number of independent mutable requests in one native call;
// each input token carries exactly one seq tag. Context IDs include N committed
// versions and R transient candidates, not R cloned model/context instances.
static int run(const char * model_path, const char * manifest, std::size_t capacity,
        std::size_t committed, std::size_t width, std::size_t pool_tokens,
        std::size_t byte_limit, const char * output_path, bool prefix_enabled) {
    [[maybe_unused]] logical_trace::RunScope trace_process;
    const auto startup = Clock::now();
    constexpr std::int64_t vocabulary = 248320;
    if (!capacity || capacity > static_cast<std::size_t>((std::numeric_limits<int32_t>::max)()) ||
            !committed || !width || width > committed || committed >= LLAMA_MAX_SEQ ||
            width > LLAMA_MAX_SEQ - committed || pool_tokens < capacity ||
            pool_tokens > (std::numeric_limits<uint32_t>::max)())
        throw std::runtime_error("invalid capacity/N/R/token-pool bounds");
    const auto schedules = schedule::read_session_schedules(manifest, vocabulary, capacity, committed, true);
    if (prefix_enabled || width != 2 || schedules.size() != 2)
        throw std::runtime_error("W13 natural wrapper requires two requests and no prefix cache");
    for (const auto &session : schedules) {
        if (session.phases.size() != 2 || session.phases[0].kind != schedule::PhaseKind::kPrompt ||
            session.phases[1].kind == schedule::PhaseKind::kPrompt ||
            session.phases[0].ids.size() != 154 || session.phases[1].ids.size() != 96)
            throw std::runtime_error("W13 natural wrapper requires P154 plus97 output quota per member");
    }
    std::vector<Run> runs(schedules.size());
    std::vector<std::vector<Call>> calls(schedules.size());
    std::size_t total_calls = 0, logical_tokens = 0, max_t = 1;
    for (std::size_t s = 0; s < schedules.size(); ++s) {
        auto & run = runs[s]; run.tokens.reserve(capacity); run.phases.resize(schedules[s].phases.size());
        for (std::size_t p = 0; p < schedules[s].phases.size(); ++p) {
            const auto & phase = schedules[s].phases[p];
            const bool prompt = phase.kind == schedule::PhaseKind::kPrompt;
            const auto first = run.tokens.size();
            run.tokens.insert(run.tokens.end(), phase.ids.begin(), phase.ids.end());
            logical_tokens += phase.ids.size();
            if (prompt) max_t = std::max(max_t, phase.ids.size());
            auto & summary = run.phases[p];
            summary.name = "round" + std::to_string(phase.turn) + (prompt ? "_prefill" : "_decode");
            summary.begin_marker = schedules[s].id + "_" + summary.name + "_begin";
            summary.end_marker = schedules[s].id + "_" + summary.name + "_end";
            const auto count = prompt ? std::size_t{1} : phase.ids.size();
            for (std::size_t i = 0; i < count; ++i)
                calls[s].push_back({s, p, i, first + (prompt ? 0 : i), prompt ? phase.ids.size() : 1});
        }
        run.predictions.reserve(calls[s].size()); total_calls += calls[s].size();
    }
    if (max_t > static_cast<std::size_t>((std::numeric_limits<int32_t>::max)()) / width)
        throw std::runtime_error("R*T batch capacity exceeds I32");
    const auto batch_capacity = max_t * width;
    // Same turn/cohort order as the Hyle manifest driver. At most one current
    // call of a Session is exposed in each wave; no per-Session dependency skips.
    std::vector<std::vector<Call>> waves;
    std::vector<std::size_t> cursors(runs.size());
    for (std::size_t turn = 1;; ++turn) {
        std::vector<std::size_t> eligible;
        for (std::size_t s = 0; s < runs.size(); ++s)
            if (turn <= schedules[s].phases.back().turn) eligible.push_back(s);
        if (eligible.empty()) break;
        for (std::size_t first = 0; first < eligible.size(); first += width) {
            const auto end = first + std::min(width, eligible.size() - first);
            for (;;) {
                std::vector<Call> wave; wave.reserve(end - first);
                for (auto at = first; at < end; ++at) {
                    const auto s = eligible[at]; auto & cursor = cursors[s];
                    if (cursor < calls[s].size() && schedules[s].phases[calls[s][cursor].phase].turn == turn)
                        wave.push_back(calls[s][cursor++]);
                }
                if (wave.empty()) break;
                waves.push_back(std::move(wave));
            }
        }
    }
    std::vector<Observation> observations; observations.reserve(total_calls);
    json episodes = json::array(), wave_observations = json::array();
    Backend backend;
    auto * device = ggml_backend_dev_by_name("CUDA0");
    if (!device || ggml_backend_dev_type(device) != GGML_BACKEND_DEVICE_TYPE_GPU)
        throw std::runtime_error("CUDA0 GPU required");
    ggml_backend_dev_t devices[] = {device, nullptr};
    auto mp = llama_model_default_params(); mp.devices = devices; mp.n_gpu_layers = 999;
    const llama_model_tensor_buft_override overrides[] = {
        {"^token_embd\\.weight$", ggml_backend_dev_buffer_type(device)}, {nullptr, nullptr}};
    mp.tensor_buft_overrides = overrides;
    using Model = std::unique_ptr<llama_model, decltype(&llama_model_free)>;
    const auto model_start = Clock::now();
    Model model(llama_model_load_from_file(model_path, mp), &llama_model_free);
    const auto model_end = Clock::now();
    if (!model || llama_model_n_layer(model.get()) != 24 || llama_vocab_n_tokens(llama_model_get_vocab(model.get())) != vocabulary)
        throw std::runtime_error("expected original complete Qwen3.5-2B model");
    const auto native_sequences = committed + width;
    using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;
    std::vector<Sampler> samplers; samplers.reserve(native_sequences);
    std::vector<llama_sampler_seq_config> configs; configs.reserve(native_sequences);
    for (std::size_t i = 0; i < native_sequences; ++i) {
        Sampler sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
        if (!sampler) throw std::runtime_error("cannot create native sampler");
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_greedy());
        configs.push_back({static_cast<llama_seq_id>(i), sampler.get()}); samplers.push_back(std::move(sampler));
    }
    auto cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(pool_tokens); cp.n_seq_max = static_cast<uint32_t>(native_sequences); cp.kv_unified = true;
    cp.n_batch = static_cast<uint32_t>(batch_capacity); cp.n_ubatch = static_cast<uint32_t>(batch_capacity);
    cp.n_threads = 24; cp.n_threads_batch = 24;
    cp.type_k = GGML_TYPE_BF16; cp.type_v = GGML_TYPE_BF16; cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    cp.samplers = configs.data(); cp.n_samplers = configs.size();
    using Context = std::unique_ptr<llama_context, decltype(&llama_free)>;
    const auto context_start = Clock::now();
    Context context(llama_init_from_model(model.get(), cp), &llama_free);
    const auto context_end = Clock::now();
    if (!context || llama_n_ctx_seq(context.get()) < capacity || llama_n_seq_max(context.get()) != native_sequences ||
            llama_n_batch(context.get()) < batch_capacity || llama_n_ubatch(context.get()) < batch_capacity)
        throw std::runtime_error("native unified context failed per-request context/version quota");
    const auto native_bytes = cache_bytes(context.get());
    if (byte_limit && native_bytes > byte_limit) throw std::runtime_error("KV+R/S backing exceeds requested byte limit");
    Batch batch(static_cast<int32_t>(batch_capacity));
    Pool pool(context.get(), native_sequences); Directory directory(committed);
    const auto ready = Clock::now(); const auto memory_ready = memory("ready_before_first", startup, device);
    std::size_t graph_calls = 0, graph_tokens = 0, graph_requests = 0, hits = 0, misses = 0, full_hits = 0, reused_tokens = 0, copies = 0;
    double prefill_service = 0, decode_service = 0;
    Point journey_start{}, journey_end{};
    struct Pending {
        Call call; std::size_t observation, target, count; Point start;
        std::shared_ptr<Version> candidate;
        bool consumed = false;
    };
    std::vector<std::size_t> completed_phases;
    completed_phases.reserve(width);
    const auto publish = [&](Pending & p) {
        auto & run = runs[p.call.session]; auto & o = observations[p.observation];
        const auto & phase = schedules[p.call.session].phases[p.call.phase]; auto & summary = run.phases[p.call.phase];
        run.visible = p.target; run.endpoint = journey_end = Clock::now();
        o.visible = p.target; o.total = seconds(run.endpoint, p.start); run.predictions.push_back(o.next);
        // Request latencies may overlap. Never sum these into aggregate service.
        summary.step_sum += o.total;
        if (o.prompt || p.call.local + 1 == phase.ids.size()) {
            summary.after = p.target; summary.seconds = seconds(run.endpoint, summary.start);
            completed_phases.push_back(p.call.session);
        }
        if (o.next == 248044 || o.next == 248046) {
            run.stopped = true;
            summary.after = p.target; summary.seconds = seconds(run.endpoint, summary.start);
        }
        p.consumed = true;
    };
    try {
        for (const auto & wave : waves) {
            completed_phases.clear();
            const auto wave_start = Clock::now();
            const auto graphs_before = graph_calls, tokens_before = graph_tokens;
            if (observations.empty()) journey_start = wave_start;
            std::vector<Pending> pending; pending.reserve(wave.size());
            double lookup_total = 0;
            for (const auto & call : wave) {
                if (runs[call.session].stopped) continue;
                auto & run = runs[call.session]; const auto & phase = schedules[call.session].phases[call.phase];
                auto & summary = run.phases[call.phase];
                if (call.local == 0) {
                    std::cerr << "memory_phase=" << summary.begin_marker << '\n';
                    summary.before = run.visible; summary.start = Clock::now();
                    if (run.predictions.empty()) run.start = summary.start;
                }
                const auto start = Clock::now(); const auto target = run.visible + call.count;
                // Natural continuation: the placeholder tape fixes only quota.
                // Every executed decode consumes its own previous GPU greedy ID.
                if (phase.kind != schedule::PhaseKind::kPrompt) {
                    if (!run.head || run.head->next < 0 || run.head->next >= vocabulary || call.count != 1)
                        throw std::runtime_error("natural decode has no exact previous greedy token");
                    run.tokens[call.first] = run.head->next;
                }
                Observation o; o.session = schedules[call.session].id; o.name = schedule::phase_name(phase, call.local);
                o.turn = phase.turn; o.prompt = phase.kind == schedule::PhaseKind::kPrompt; o.logical_tokens = call.count;
                if (o.prompt && prefix_enabled) {
                    const auto begin = Clock::now();
                    auto hit = directory.lookup(run.tokens, target, run.visible + (run.head ? 1 : 0));
                    if (hit) { o.reused = hit->length - run.visible; run.head = std::move(hit); o.hit = true; ++hits; reused_tokens += o.reused; }
                    else ++misses;
                    o.lookup = seconds(Clock::now(), begin); lookup_total += o.lookup;
                }
                o.graph_tokens = call.count - o.reused;
                pending.push_back({call, observations.size(), target, o.graph_tokens, start, {}, false});
                observations.push_back(std::move(o));
                if (!pending.back().count) {
                    auto & hit = observations.back();
                    if (!run.head || run.head->length != target || run.head->next == LLAMA_TOKEN_NULL)
                        throw std::runtime_error("full prefix hit has no complete boundary/next ID");
                    hit.full_hit = true; ++full_hits; hit.next = run.head->next; hit.target_seq = run.head->id;
                    publish(pending.back());
                }
            }
            if (pending.empty()) continue;
            // Stable equal actual-T + phase-kind buckets. No padding/extra
            // prompt evaluation, and a full hit is absent from all decode calls.
            for (std::size_t first = 0; first < pending.size(); ++first) {
                if (pending[first].consumed) continue;
                std::vector<std::size_t> members; members.reserve(width);
                const auto t = pending[first].count; const auto prompt = observations[pending[first].observation].prompt;
                for (std::size_t i = first; i < pending.size(); ++i)
                    if (!pending[i].consumed && pending[i].count == t && observations[pending[i].observation].prompt == prompt) members.push_back(i);
                const auto begin = Clock::now();
                const auto &trace_b2_call0 = pending[members.front()].call;
                const auto &trace_b2_call1 = pending[members.size() > 1 ? members[1] : members.front()].call;
                const auto trace_b2_context0 = pending[members.front()].target;
                const auto trace_b2_context1 = pending[members.size() > 1 ? members[1] : members.front()].target;
                logical_trace::b2_begin("peer", prompt ? "prefill" : "decode", graph_calls, t, members.size(),
                    trace_b2_call0.session, trace_b2_call1.session, trace_b2_call0.phase, trace_b2_call1.phase,
                    trace_b2_context0 >= t ? trace_b2_context0 - t : 0,
                    trace_b2_context1 >= t ? trace_b2_context1 - t : 0);
                logical_trace::Range trace_prepare("peer/prepare", logical_trace::sequence);
                // A distinct old version disappears only if all its real owners
                // are selected heads. Directory aliases and idle Sessions count
                // as external; select at most one in-place native ID per base.
                const auto reusable_bases = [&] {
                    std::vector<Version *> result;
                    for (auto i : members) {
                        const auto & base = runs[pending[i].call.session].head;
                        if (!base || std::find(result.begin(), result.end(), base.get()) != result.end()) continue;
                        std::size_t selected = 0, head_owners = 0, cache_owners = 0;
                        for (auto j : members) selected += runs[pending[j].call.session].head.get() == base.get();
                        for (const auto & run : runs) head_owners += run.head.get() == base.get();
                        for (const auto & entry : directory.entries) cache_owners += entry.version.get() == base.get();
                        if (cache_owners == 0 && head_owners == selected && base.use_count() == static_cast<long>(head_owners)) result.push_back(base.get());
                    }
                    return result;
                };
                auto reusable = reusable_bases();
                while (pool.live - reusable.size() + members.size() > committed) {
                    if (!directory.evict()) throw std::runtime_error("batch cannot fit N distinct committed heads; split the ready bucket or raise N");
                    reusable = reusable_bases();
                }
                for (auto i : members) {
                    auto & p = pending[i]; auto & run = runs[p.call.session]; auto & o = observations[p.observation];
                    const auto found = std::find(reusable.begin(), reusable.end(), run.head.get());
                    if (run.head && found != reusable.end()) { p.candidate = run.head; reusable.erase(found); }
                    else {
                        p.candidate = pool.create();
                        if (run.head) {
                            o.source_seq = run.head->id; const auto copy_start = Clock::now();
                            {
                                logical_trace::Range trace_copy("peer/seq_copy", logical_trace::sequence);
                                llama_memory_seq_cp(llama_get_memory(context.get()), run.head->id, p.candidate->id, -1, -1);
                            }
                            o.copy_api = seconds(Clock::now(), copy_start); ++copies;
                            if (llama_memory_seq_pos_max(llama_get_memory(context.get()), p.candidate->id) != static_cast<llama_pos>(run.head->length) - 1)
                                throw std::runtime_error("full hybrid state copy lost position boundary");
                        }
                    }
                    o.target_seq = p.candidate->id;
                }
                batch.value.n_tokens = static_cast<int32_t>(members.size() * t);
                for (std::size_t j = 0; j < members.size(); ++j) {
                    auto & p = pending[members[j]]; auto & run = runs[p.call.session]; const auto & o = observations[p.observation];
                    for (std::size_t k = 0; k < t; ++k) {
                        const auto at = j * t + k;
                        batch.value.token[at] = run.tokens[p.call.first + o.reused + k];
                        batch.value.pos[at] = static_cast<llama_pos>(run.visible + o.reused + k);
                        batch.value.n_seq_id[at] = 1; batch.value.seq_id[at][0] = p.candidate->id;
                        batch.value.logits[at] = k + 1 == t;
                    }
                }
                const auto prepared = Clock::now(); pool.native_inflight = true;
                trace_prepare.finish();
                logical_trace::Range trace_decode("peer/llama_decode", logical_trace::sequence);
                const auto status = llama_decode(context.get(), batch.value); const auto decoded = Clock::now();
                trace_decode.finish();
                if (status != 0) throw std::runtime_error("llama_decode failed: " + std::to_string(status));
                logical_trace::Range trace_synchronize("peer/synchronize", logical_trace::sequence);
                llama_synchronize(context.get()); pool.native_inflight = false; const auto synchronized = Clock::now();
                trace_synchronize.finish();
                logical_trace::Range trace_publish("peer/sample_publish", logical_trace::sequence);
                std::vector<llama_token> next_ids(members.size());
                for (std::size_t j = 0; j < members.size(); ++j) {
                    auto & p = pending[members[j]]; auto & o = observations[p.observation];
                    const auto output_index = static_cast<int32_t>(j * t + t - 1);
                    const auto native_next = llama_get_sampled_token_ith(context.get(), output_index);
                    if (native_next == LLAMA_TOKEN_NULL) throw std::runtime_error("per-sequence GPU greedy missing; no CPU fallback");
                    const auto next = llama_sampler_sample(samplers[static_cast<std::size_t>(p.candidate->id)].get(), context.get(), output_index);
                    if (next != native_next || next < 0 || next >= vocabulary) throw std::runtime_error("native/public greedy mismatch");
                    if (llama_memory_seq_pos_max(llama_get_memory(context.get()), p.candidate->id) != static_cast<llama_pos>(p.target) - 1)
                        throw std::runtime_error("batch output sequence position mismatch");
                    next_ids[j] = next; o.sampled_logits = llama_get_sampled_logits_count_ith(context.get(), output_index);
                }
                const auto sampled = Clock::now();
                for (std::size_t j = 0; j < members.size(); ++j) {
                    auto & p = pending[members[j]]; auto & run = runs[p.call.session]; auto & o = observations[p.observation];
                    p.candidate->tokens = &run.tokens; p.candidate->length = p.target; p.candidate->next = next_ids[j];
                    run.head = std::move(p.candidate); o.next = next_ids[j];
                    o.prepare = seconds(prepared, begin); o.decode = seconds(decoded, prepared);
                    o.synchronize = seconds(synchronized, decoded); o.sample = seconds(sampled, synchronized);
                }
                if (pool.live > committed) throw std::runtime_error("post-batch committed versions exceed N");
                for (auto i : members) publish(pending[i]);
                const auto end = Clock::now(); const auto elapsed = seconds(end, begin);
                trace_publish.finish(); logical_trace::episode.finish();
                (prompt ? prefill_service : decode_service) += elapsed;
                json episode; episode["index"] = graph_calls; episode["requests"] = members.size(); episode["T"] = t;
                episode["kind"] = prompt ? "prefill" : "decode"; episode["input_tokens"] = members.size() * t;
                episode["seconds"] = elapsed; episode["input_prepare_seconds"] = seconds(prepared, begin);
                episode["decode_return_seconds"] = seconds(decoded, prepared); episode["synchronize_seconds"] = seconds(synchronized, decoded);
                episode["sampling_seconds"] = seconds(sampled, synchronized); episode["members"] = json::array();
                for (std::size_t j = 0; j < members.size(); ++j) {
                    const auto & p = pending[members[j]]; const auto & o = observations[p.observation];
                    episode["members"].push_back({{"session", o.session}, {"name", o.name}, {"target_seq", o.target_seq},
                        {"position_first", p.target - t}, {"position_end", p.target}, {"output_input_index", j * t + t - 1}, {"predicted_id", o.next}});
                }
                episodes.push_back(std::move(episode)); ++graph_calls; graph_tokens += members.size() * t; graph_requests += members.size();
            }
            // Prefix lookup is host work before these native episodes. Count it
            // once, never R times. Other between-episode work remains in wall.
            prefill_service += lookup_total;
            // All lookups in this wave precede every newly completed phase
            // checkpoint, exactly as the Hyle CLI. A wave cannot reuse a peer
            // checkpoint which did not exist at its admission boundary.
            for (const auto s : completed_phases) {
                if (prefix_enabled) directory.publish(runs[s].head);
                const auto & call = *std::find_if(wave.begin(), wave.end(), [s](const Call & c) { return c.session == s; });
                std::cerr << "memory_phase=" << runs[s].phases[call.phase].end_marker << '\n';
            }
            journey_end = Clock::now();
            const auto prompt = schedules[wave.front().session].phases[wave.front().phase].kind;
            const bool homogeneous = std::all_of(wave.begin(), wave.end(), [&](const Call & call) {
                return schedules[call.session].phases[call.phase].kind == prompt;
            });
            std::size_t wave_tokens = 0;
            for (const auto & item : pending) wave_tokens += item.call.count;
            wave_observations.push_back({{"kind", homogeneous ? (prompt == schedule::PhaseKind::kPrompt ? "prefill" : "decode") : "mixed"},
                {"outputs", pending.size()}, {"logical_tokens", wave_tokens}, {"actual_tokens", graph_tokens - tokens_before},
                {"graph_calls", graph_calls - graphs_before}, {"seconds", seconds(journey_end, wave_start)}});
        }
        const auto memory_final = memory("all_sessions_complete", startup, device);
        json result;
        result["status"] = "native batch consumer completed; no cross-engine numeric or performance acceptance";
        result["llama_commit"] = "d9e03f1074dbd2979126d91dce1b5d304ec8394e";
        result["model"] = model_path; result["session_manifest"] = manifest;
        result["active_sequences"] = width; result["logical_capacity"] = capacity; result["committed_versions_limit"] = committed;
        result["native_sequence_quota"] = native_sequences; result["native_n_ctx"] = llama_n_ctx(context.get());
        result["native_n_ctx_seq"] = llama_n_ctx_seq(context.get()); result["kv_unified"] = true;
        result["cache_backing_bytes"] = native_bytes; result["cache_byte_limit"] = byte_limit;
        logical_tokens = 0; for (const auto &item : observations) logical_tokens += item.logical_tokens;
        result["natural_greedy"] = true;
        result["processed_tokens"] = logical_tokens; result["generated_tokens"] = observations.size();
        result["actual_graph_calls"] = graph_calls; result["actual_graph_requests"] = graph_requests; result["actual_graph_tokens"] = graph_tokens;
        result["prefix_hits"] = hits; result["prefix_misses"] = misses; result["prefix_full_hits"] = full_hits;
        result["reused_tokens"] = reused_tokens; result["seq_copy_api_calls"] = copies;
        result["directory_evictions"] = directory.evictions; result["peak_native_versions"] = pool.peak;
        result["session_seconds"] = seconds(journey_end, journey_start); result["startup_total_seconds"] = seconds(journey_end, startup);
        result["ready_seconds"] = seconds(ready, startup); result["model_load_seconds"] = seconds(model_end, model_start);
        result["context_seconds"] = seconds(context_end, context_start);
        result["prefill_service_seconds"] = prefill_service; result["decode_service_seconds"] = decode_service;
        result["waves"] = std::move(wave_observations); result["prefix_cache"] = prefix_enabled ? "auto" : "off";
        result["episodes"] = std::move(episodes); result["sessions"] = json::array(); result["steps"] = json::array();
        for (std::size_t s = 0; s < runs.size(); ++s) {
            const auto & run = runs[s]; json item;
            item["id"] = schedules[s].id; item["generated_ids"] = run.predictions; item["visible_tokens"] = run.visible;
            item["eos"] = run.stopped; item["actual_input_ids"] = Tokens(run.tokens.begin(), run.tokens.begin() + static_cast<std::ptrdiff_t>(run.visible));
            item["session_wall_seconds"] = seconds(run.endpoint, run.start); item["phases"] = json::array();
            for (std::size_t p = 0; p < run.phases.size(); ++p) {
                const auto & summary = run.phases[p]; const auto & phase = schedules[s].phases[p];
                item["phases"].push_back({{"name", summary.name}, {"turn", phase.turn}, {"kind", phase.kind == schedule::PhaseKind::kPrompt ? "prefill" : "decode"},
                    {"input_tokens", phase.ids.size()}, {"context_before", summary.before}, {"context_after", summary.after}, {"seconds", summary.seconds}, {"step_sum_seconds", summary.step_sum}});
            }
            result["sessions"].push_back(std::move(item));
        }
        for (const auto & o : observations) result["steps"].push_back({{"session", o.session}, {"name", o.name}, {"kind", o.prompt ? "prefill" : "decode"},
            {"turn", o.turn}, {"input_tokens", o.logical_tokens}, {"visible_tokens", o.visible}, {"predicted_id", o.next}, {"step_seconds", o.total},
            {"graph_tokens", o.graph_tokens}, {"prefix_hit", o.hit}, {"full_hit", o.full_hit}, {"reused_tokens", o.reused},
            {"lookup_seconds", o.lookup}, {"seq_copy_api_seconds", o.copy_api}, {"input_prepare_seconds", o.prepare},
            {"decode_return_seconds", o.decode}, {"synchronize_seconds", o.synchronize}, {"sampling_seconds", o.sample},
            {"sampled_logits_elements", o.sampled_logits}, {"source_seq", o.source_seq}, {"target_seq", o.target_seq}});
        result["memory"] = {{{"name", memory_ready.name}, {"device_global_free_bytes", memory_ready.device_free}, {"device_global_total_bytes", memory_ready.device_total}},
            {{"name", memory_final.name}, {"device_global_free_bytes", memory_final.device_free}, {"device_global_total_bytes", memory_final.device_total}}};
        result["scope"] = "One retained model/context, complete hybrid KV+conv/GDN sequence states, equal actual-T/kind request buckets, one llama_decode per bucket, N committed versions plus R candidate IDs; full hit has zero native decode. No MTP, eviction/restore, cancellation-equivalence or cross-engine numeric-quality acceptance.";
        result["timing_boundary"] = "Global wall includes readiness/lookup/admission/native sequence copy/batch fill/native decode/synchronize/all R GPU-greedy host IDs/publication/phase checkpoints. Episode service counted once; per-request and per-session latencies overlap and must not be added. All wave lookups precede stable equal-T/kind buckets; every new phase checkpoint is published only after all wave buckets finish. Per-request phase endpoints precede deferred checkpoint publication; use global wall for complete service and match observed Hyle episode order before timing.";
        result["budget_boundary"] = "N counts distinct native versions, directory aliases do not add IDs; native IDs N+R. In-place base allowed only when every actual shared_ptr owner is a selected head, once per distinct base. Context KV+RS bytes are measured after allocation; byte cap is not an early allocation quota. Match capacity/physical pool/byte budget independently; same ID results alone do not prove resource fairness.";
        result["failure_boundary"] = "Any native failure aborts the process and synchronizes before ID recycle. Unretained bases may be reused in place, so this consumer does not provide Hyle whole-batch rollback/cancellation atomicity on an error. No simulated success or serialized state export inside timed path.";
        std::ofstream output(output_path); output << result.dump(2) << '\n';
        if (!output) throw std::runtime_error("cannot write peer result");
    } catch (...) {
        llama_synchronize(context.get()); pool.native_inflight = false;
        for (auto & run : runs) run.head.reset(); directory.entries.clear(); throw;
    }
    for (auto & run : runs) run.head.reset(); directory.entries.clear();
    return 0;
}
} // namespace peer_batch

int main(int argc, char ** argv) {
    try {
        if (argc < 2) throw std::runtime_error("MODEL.gguf --session-schedules FILE --result FILE --active-sequences R [--capacity256 --cache-slots4 --pool-tokens1024 --cache-bytesB]");
        const char * manifest = nullptr; const char * output = nullptr;
        std::size_t capacity = 256, slots = 4, width = 2, pool_tokens = 1024, byte_limit = 0;
        bool prefix_enabled = true;
        const auto integer = [](const char * text) {
            const std::string value(text); std::size_t end = 0;
            if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos) throw std::runtime_error("expected unsigned decimal");
            const auto n = std::stoull(value, &end);
            if (end != value.size() || n > (std::numeric_limits<std::size_t>::max)()) throw std::runtime_error("value exceeds size_t");
            return static_cast<std::size_t>(n);
        };
        for (int i = 2; i < argc; ++i) {
            if (i + 1 >= argc) throw std::runtime_error("missing CLI value");
            const std::string key = argv[i]; const char * value = argv[++i];
            if (key == "--session-schedules") manifest = value;
            else if (key == "--result") output = value;
            else if (key == "--capacity") capacity = integer(value);
            else if (key == "--cache-slots") slots = integer(value);
            else if (key == "--active-sequences") width = integer(value);
            else if (key == "--pool-tokens") pool_tokens = integer(value);
            else if (key == "--cache-bytes") byte_limit = integer(value);
            else if (key == "--prefix-cache") {
                const std::string policy(value);
                if (policy != "off" && policy != "auto") throw std::runtime_error("--prefix-cache expects off or auto");
                prefix_enabled = policy == "auto";
            }
            else throw std::runtime_error("unknown option: " + key);
        }
        if (!manifest || !output) throw std::runtime_error("session manifest and result required");
        return peer_batch::run(argv[1], manifest, capacity, slots, width, pool_tokens, byte_limit, output, prefix_enabled);
    } catch (const std::exception & e) { std::cerr << "error: " << e.what() << '\n'; return 1; }
}

