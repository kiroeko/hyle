"""Run at most the eight explicitly frozen W13 profiles, in order, no retry."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('w13_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
spec=importlib.util.spec_from_file_location('w13_analysis',W/'analyze.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
p=b.p


def main():
    plan=p.read(W/('run-plan2.json' if (W/'run-plan2.json').exists() else 'plan.json')); names=[r['name'] for r in plan['commands']]
    selected=names if sys.argv[1]=='all' else [sys.argv[1]]
    assert all(n in names for n in selected)
    images={'hyle':p.read(W/'ready-hyle.json')['image'],'b2-peer':p.read(W/'ready-peer-b2.json')['image'],
            'r1-peer':p.read(p.P/'peer/ready.json')['image']}
    # Original images were fully pinned before this window. No CXX or image
    # mutations are allowed during it; preserve quiet between these profiles.
    for row in images.values():assert Path(row['path']).stat().st_size==row['bytes']
    assert Path(plan['profiler']['path']).stat().st_size==plan['profiler']['bytes']
    rows=[]
    for name in selected:
        record=next(r for r in plan['commands'] if r['name']==name)
        f=W/'runs'/record.get('run_directory',name)
        if (f/'process.json').exists():
            assert p.read(f/'process.json')['exit']==0, 'Prior actual failure retained; stop'
            assert p.read(f/'command.json')['command']==record['profile']
            quality=a.parse(name,f)  # Offline only; never repeats a completed process.
        else:
            image=images['b2-peer' if name=='b2-peer' else 'r1-peer' if name.endswith('peer') else 'hyle']
            assert record['consumer'][0]==image['path']
            if not name.endswith('peer'):assert '--trace' not in record['consumer']
            runtime=p.read(p.P/'peer/runtime.json') if name.endswith('peer') else p.read(p.V/'runtime.json')
            env=os.environ.copy();env['PATH']=str(Path(image['path']).parent)+';'+runtime['PATH']
            env.update(runtime.get('configured_flags',{}));env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
            f.mkdir(parents=True,exist_ok=False)
            print('PROFILE_START',name,flush=True)
            process=b.execute(record['profile'],f,env,record['timeout_seconds'])
            print('PROFILE_TERMINATED',name,process,flush=True)
            quality=a.parse(name,f)
        rows.append(dict(name=name,process=p.read(f/'process.json'),quality=quality))
        p.save(W/'summary-partial.json',rows)
        print('PROFILE_PASS',name,quality['root_count'],flush=True)
    if selected==names:
        p.save(W/'summary.json',dict(status='ALL8_PROCESSES_AND_REPORTS_AND_ROOT_MAPS_PASS',runs=rows,
            profile_processes=8,extra_memory_processes=0,new_TPS_claim=False))


if __name__=='__main__': main()
