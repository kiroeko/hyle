"""Finite W13 host build. `plan` is read-only apart from scratch metadata."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('w13_prepare', W/'prepare.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)


def key(s):
    return os.path.normcase(str(Path(s).resolve()))


def compile_command(original, source, name, model):
    args = original['command']
    old_source = next(x for x in args if x.lower().endswith(('.cc', '.cpp')) and not x.startswith('/'))
    out = W/('hyle' if model else 'peer-b2')/'compile'
    result = [args[0], '/I'+str(W/'source')]
    skip = False
    for arg in args[1:]:
        if skip: skip = False; continue
        if arg.lower() == '/sourcedependencies': skip = True; continue
        if key(arg) == key(old_source) or arg.lower().startswith(('/fo', '/fd')): continue
        if model and arg.lower().startswith('/i'):
            folder = Path(arg[2:])
            if folder.is_relative_to(p.R) and not folder.is_relative_to(p.R/'.scratch'):
                arg = '/I'+str(W/'source'/folder.relative_to(p.R))
        result.append(arg)
    result += [source['path'], '/sourceDependencies', str(out/'dependencies.json'),
               '/Fo'+str(out/'unit.obj'), '/Fd'+str(out/'unit.pdb')]
    return result


def link_command(old, original_object, model):
    folder = W/('hyle' if model else 'peer-b2')
    result, replacements = [], 0
    for arg in old:
        if key(arg) == key(original_object):
            result.append(str(folder/'compile/unit.obj')); replacements += 1
        elif not arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:')):
            result.append(arg)
    assert replacements == 1, (original_object, replacements)
    output = folder/'bin'/('hyle.exe' if model else 'consumer.exe')
    result += ['/OUT:'+str(output), '/PDB:'+str(output.with_suffix('.pdb')),
               '/IMPLIB:'+str(output.with_suffix('.lib'))]
    return result, output


def plan():
    x = p.read(W/'plan.json')
    model_ready = p.read(p.M/'ready-cli1.json')
    peer_ready = p.read(p.B/'peer2/ready.json')
    units = []
    for name, is_model, old_ready, old_compile, old_link, old_inputs in (
        ('model', True, model_ready, p.M/'logs/model1/command.json',
         Path(p.read(p.V/'ready-cli.json')['recipe']['path']), p.V/'cli-link-inputs.json'),
        ('peer-b2', False, peer_ready, p.B/'peer2/compile/command.json',
         p.B/'peer2/link/command.json', p.B/'peer2/link-inputs.json')):
        source = x['sources']['model' if is_model else 'peer_b2']['source']
        original_obj = model_ready['compiled']['object'] if is_model else old_ready['app']
        p.exact(original_obj)
        compile = compile_command(p.read(old_compile), source, name, is_model)
        old_command = p.read(old_link)['command']
        link, output = link_command(old_command, original_obj['path'], is_model)
        retained = [r for r in p.read(old_inputs) if key(r['path']) != key(original_obj['path'])]
        assert len(retained) == (223 if is_model else 8)
        units.append(dict(name=name, source=source, original_object=original_obj,
            original_compile=p.pin(old_compile), original_link=p.pin(old_link),
            original_inputs=p.pin(old_inputs), compile=compile, link=link,
            image=str(output), retained_inputs=retained))
    dependency = p.read(W/'model-precompile-dependencies.json')
    known = {key(x['snapshot']['path']): x['snapshot'] for x in dependency['headers']}
    for row in dependency['nvtx']:
        known[key(row['path'])] = row
    for row in p.read(p.B/'peer2/compile/actual-dependencies.json'):
        known[key(row['path'])] = row
    for file in (W/'source').rglob('*'):
        if file.is_file(): known[key(file)] = p.pin(file)
    p.save(W/'precompile-identity.json', list(known.values()))
    p.save(W/'build-plan.json', dict(status='PLANNED_NOT_BUILT', units=units,
        environment=p.pin(p.V/'environment.json'), identity=p.pin(W/'precompile-identity.json'),
        freeze=p.pin(W/'plan.json'), counts=dict(CXX=2, links=2, SDK=0, NVCC=0, model_runs=0),
        Source_qualification='Only NVTX metadata added to frozen e006 Model. Active canonical main/RequestLoop/range headers are not compiler inputs.'))
    print('BUILD_PLAN_READY', p.pin(W/'build-plan.json'))


def execute(command, folder, env, timeout):
    assert not (folder/'process.json').exists(), 'Preserve original attempts; no automatic retry'
    folder.mkdir(parents=True, exist_ok=True)
    p.save(folder/'command.json', dict(command=command, cwd=str(p.R), timeout_seconds=timeout))
    start = time.perf_counter()
    with (folder/'stdout.log').open('wb') as out, (folder/'stderr.log').open('wb') as err:
        proc = subprocess.Popen(command, cwd=p.R, env=env, stdout=out, stderr=err,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        p.save(folder/'live.json', dict(pid=proc.pid, started_unix_ns=time.time_ns()))
        try: code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            kill = subprocess.run(['C:/Windows/System32/taskkill.exe', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
            (folder/'timeout-kill.stdout.log').write_bytes(kill.stdout)
            (folder/'timeout-kill.stderr.log').write_bytes(kill.stderr)
            proc.wait(timeout=20); code = proc.returncode
    result = dict(exit=code, pid=proc.pid, seconds=time.perf_counter()-start)
    p.save(folder/'process.json', result)
    assert code == 0, 'First failure retained; stop without retry'
    return result


def build(name):
    frozen = p.read(W/'build-plan.json')
    unit = next(x for x in frozen['units'] if x['name'] == name)
    for row in (unit['source'], frozen['freeze'], frozen['identity']): p.exact(row)
    for row in unit['retained_inputs']: p.exact(row)
    env = os.environ.copy(); env.update(p.read(frozen['environment']['path']))
    folder = W/('hyle' if name == 'model' else 'peer-b2')
    (folder/'compile').mkdir(parents=True, exist_ok=True)
    (folder/'bin').mkdir(parents=True, exist_ok=True)
    compile = execute(unit['compile'], folder/'logs/compile', env, 300)
    deps = p.read(folder/'compile/dependencies.json')['Data']
    expected = {key(x['path']): x for x in p.read(frozen['identity']['path'])}
    actual = []
    for path in [deps['Source'], *deps['Includes']]:
        row = p.pin(path)
        assert key(path) in expected, ('unfrozen Include', path)
        assert row == expected[key(path)], ('dependency drift', path)
        actual.append(row)
    p.save(folder/'compile/actual-dependencies.json', actual)
    linked = execute(unit['link'], folder/'logs/link', env, 180)
    p.save(W/('ready-hyle.json' if name == 'model' else 'ready-peer-b2.json'),
        dict(status='LINKED_NOT_PROFILED', image=p.pin(unit['image']),
             object=p.pin(folder/'compile/unit.obj'), compile=compile, link=linked,
             source=unit['source'], actual_dependencies=p.pin(folder/'compile/actual-dependencies.json'),
             retained_inputs=unit['retained_inputs'], baseline=unit['original_inputs']))
    print('READY', name, p.pin(unit['image']))


if __name__ == '__main__':
    if sys.argv[1] == 'plan': plan()
    elif sys.argv[1] in ('model', 'peer-b2'): build(sys.argv[1])
    else: raise ValueError('Use plan, model, or peer-b2; GPU is a separate explicit operation')
