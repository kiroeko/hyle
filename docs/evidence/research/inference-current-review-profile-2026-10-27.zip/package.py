"""Archive only small reproducibility materials from the completed W13 window."""
from pathlib import Path
import hashlib
import json
import zipfile
W=Path(__file__).resolve().parent
R=W.parent.parent
D=R/'docs/evidence/research'
NAME='inference-current-review-profile-2026-10-27'

def read(p):return json.loads(p.read_bytes())
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()
def pin(p):return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p))
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())

def main():
    plan=read(W/'plan.json');allruns=read(W/'summary.json')
    details=read(W/'followup-summary.json');summary=read(W/'analysis-summary.json')
    assert allruns['status']=='ALL8_PROCESSES_AND_REPORTS_AND_ROOT_MAPS_PASS'
    assert len(allruns['runs'])==8
    for fn in ('ready-hyle.json','ready-peer-b2.json'):
        ready=read(W/fn)
        for kind in ('image','object','source','actual_dependencies'):
            p=Path(ready[kind]['path'])
            assert p.stat().st_size==ready[kind]['bytes'] and sha(p)==ready[kind]['sha256'],(fn,kind)
    attempted=[]
    for f in sorted((W/'runs').iterdir()):
        if not f.is_dir():continue
        process=read(f/'process.json')
        traces=[pin(f/x) for x in ('trace.nsys-rep','trace.sqlite') if (f/x).exists()]
        attempted.append(dict(directory=str(f.relative_to(W)),process=process,traces=traces,
                              status='LOADING_ONLY_WRONG_GGUF_FAILURE' if f.name=='r1-peer' else 'SUCCESS'))
    assert len(attempted)==9 and sum(a['status']=='SUCCESS' for a in attempted)==8
    save(W/'trace-identities.json',attempted)
    fields=['arm','roots','root_union_ms','root_sum_ms','root_envelope_ms','GPU_union_ms','uncovered_root_wall_ms']
    table=[]
    for n in ('r1-off','r1-auto','r1-peer','b2-off','b2-auto','b2-peer'):
        m=details[n]['common_after_first8']
        table.append([n,m['root_count']]+[round(m[k],6) for k in ('root_wall_union_ms','root_wall_sum_ms','root_envelope_ms','actual_gpu_union_ms','root_union_minus_gpu_union_ms')])
    c=summary['ordinary']
    ordinary=[]
    for p in ('r1','b2'):
        for n,v in c[p]['common_after_first8']['arms'].items():
            cp=v['copies'].get('8',{})
            ordinary.append([n,round(v['kernel_count']['mean'],3),round(v['kernel_union_ms']['mean'],6),
                cp.get('count',{}).get('mean',0),cp.get('bytes',{}).get('mean',0),round(cp.get('sum_ns',{}).get('mean',0),6)])
    report=dict(
        status='EIGHT_COMPLETED_CURRENT_PROFILES_OFFLINE_REVIEW',
        scope='Frozen 2fe/e006 diagnostic build; not current W12 range/new RequestLoop, not a new TPS/statistical benchmark.',
        hardware=plan['hardware'],profiler=dict(version=plan['tool_version'],identity=plan['profiler']),
        build=dict(CXX=2,links=2,SDK=0,NVCC=0,downloads=0,retained_CLI_input_count=224,
            baseline_image=plan['baseline_image'],Model=plan['Model'],Graph=plan['Graph'],frozen_project_headers=174,
            comment_only_reuse_exception='W9 output_source.h comment-only token-equivalent change is explicitly retained in precompile metadata.',
            diagnostic_hyle=read(W/'ready-hyle.json')['image'],natural_B2_peer=read(W/'ready-peer-b2.json')['image'],
            retained_R1_MTP_peer_ready=plan['existing_peer']),
        processes=dict(successful=8,attempts=9,loading_only_failures=1,
            failure='r1-peer initially passed complete target+MTP GGUF to ordinary guard; native rejected before any logical sequence. Corrected attempt2 uses historical target-only file; successful arms were never rerun.',
            parser_correction='Initial B2 off/auto oracle failure is retained. Exactly 12 explicit mode facts differ: four backing/budget fields and two cpu-ahead counters per member. Every other non-time per-session result including all 194 IDs equals; profile work is not filtered into the oracle.'),
        work=dict(prompt_rows_per_member=154,output_quota_per_member=97,context_capacity=256,
            ordinary_physical_roots=97,B2_outputs=194,
            natural='Each engine feeds its own actual greedy result. B2 is natural R2, not the old teacher-forced window; cross-engine continuation IDs are not asserted equal.',
            MTP='Hyle combines target/draft in 53 roots; peer exposes 104 target/draft roots. Actual target/draft/accepted work remains in complete reports.'),
        attribution=dict(common_ordinary_sequences='10..97 inclusive, 88 roots, same actual context/R/T; all modes no recording and one native graph launch per selected root',
            native='GPU owner is actual same-thread API correlation from unique seq-labelled phases; zero unmapped in all eight root envelopes.',
            endpoint='Model finished-clock endpoint before outer ledger/delivery; root union is not root sum. Peer decode-root endpoint excludes different outer work.',
            wall_columns=fields,wall_rows=table,
            warning='GPU union, call wall and CPU self-time differ. Uncovered wall is not host CPU time. A/B root sums double-count overlap.'),
        ordinary_native=dict(columns=['arm','kernels_per_root','kernel_union_ms_per_root','D2D_per_root','D2D_bytes_per_root','D2D_sum_ms_per_root'],rows=ordinary,
            interpretation='Indexed-state work did not remove every D2D. Current 19/60 nodes carry 77824/491520 bytes, not the old 132/39.7MB. Copies take roughly 15/50 us/root; their count does not identify the main wall gap.',
            residual_mapping='R1 native copies lie in six repeated full-attention qnorm/gate neighborhoods plus final normalized-head materialization; B2 has 54 in 18 GDN L2 neighborhoods plus six full-attention neighborhoods. This is source/order-supported attribution, not recorded logical node IDs. All representative D2D payloads are 4096/8192 bytes, not Top1/control scalars.'),
        host_call_walls=dict(boundary='Inclusive phase wall; replay is nested in prepare and must not be added. Nsight node tracing perturbs submit wall.',
            R1_steady_prepare_ms=dict(off=.516209,auto_A=.785439,auto_B=.833571),
            B2_steady_prepare_ms=dict(off=.613653,auto_A=1.093453,auto_B=1.079915),
            conclusion='Auto reduces uncovered wall but adds preparation wall and a small measured GPU-work increase. These single profiles are structural evidence, not a net throughput gain estimate.'),
        small_projection=dict(native='Exact one-warp grid1 cutlass Kernel2 family; count 36/root, supported by frozen 18 GDN layers with separate [16,2048] a/b weights. No explicit graph node ID or kernel tensor argument is exported.',
            B2_us_per_root=dict(hyle_off=415.333216,hyle_auto=437.599239,peer=414.122364),
            MTP_us_per_matching_root_after_seq9=dict(hyle_role4_38roots=404.794895,hyle_role3_5roots=423.714000,peer_target_47roots=436.733660),
            boundary='Supports review small-projection magnitude for both engines. R1 uses a different native kernel family; do not transfer B2 cost. Fusion benefit and effective DRAM bandwidth remain unmeasured.'),
        MTP_capture=dict(hyle=dict(BeginCapture=16,EndCapture=16,Instantiate=5,Update=11),peer=dict(BeginCapture=6,EndCapture=6,Instantiate=2,Update=6),
            hyle_sequences=[2,3,4,5,9,10,11,13,14,15,16,43,44,45,46,53],
            proven='seq2/3 first role3/4 graph families; seq43 lag0 reentry after rejection42; seq44 lag1 reentry; seq53 first terminal role5/T1 with quota1. All Hyle physical execution slots are 0.',
            unresolved='For other same-role R/T/slot recordings, including45/46, exact changing capture operand is unlocated. Trace has no tensor/private tuple operands or memcpy source/destination pairs. Context length alone does not prove KV growth caused capture.',
            source_mechanism='Graph compares full recorded port tuples plus private binding-preservation proof, with two retained variants. Draft carry/prior hidden ReadLease bindings and append control carriers can affect those facts; no claim which one changed without operand evidence.',
            boundary='16 vs6 is current actual API count, not an improvement calculation from old27/7. Different accepted work and target/draft root decomposition remain explicit.'),
        limitations=['One process per successful arm, no significance/new memory/TPS claim.',
            'Logical backing/budget bytes are not independent PSAPI or physical VRAM peaks.',
            'Old758 kernels/132 D2D/27 captures do not describe this frozen build.',
            'No new GPU run, source optimization, model-quality claim or MTP depth2 implementation was performed during offline analysis.'],
        reproduce=dict(work_directory=str(W.relative_to(R)),analysis_scripts=['analyze.py','summarize.py','followup.py'],
            full_results=['summary.json','analysis-summary.json','followup-summary.json','kernel-inventory.json','trace-identities.json'],
            raw_traces='Retained at exact pinned scratch paths; excluded from this small ZIP along with all binaries, SDK and model payloads.'))
    D.mkdir(parents=True,exist_ok=True);save(D/(NAME+'.json'),report)
    allowed={'.py','.json','.log','.patch','.h','.hpp','.cc','.cpp','.txt','.ids','.schedule','.sessions','.env','.rsp','.tsv'}
    forbidden={'.exe','.obj','.pdb','.lib','.exp','.dll','.sqlite','.nsys-rep','.bin','.gguf','.safetensors'}
    files=[]
    for p in sorted(W.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:continue
        if p.name=='package-result.json' or p.suffix in forbidden:continue
        if p.suffix in allowed or p.parent.name=='inputs':files.append(p)
    assert not any(p.stat().st_size>4_000_000 for p in files),[(str(p),p.stat().st_size) for p in files if p.stat().st_size>4_000_000]
    manifest=[pin(p) for p in files];save(W/'package-manifest.json',manifest)
    z=D/(NAME+'.zip')
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
        f.write(D/(NAME+'.json'),NAME+'.json')
        for p in files:f.write(p,str(p.relative_to(W)).replace('\\','/'))
        f.write(W/'package-manifest.json','package-manifest.json')
    with zipfile.ZipFile(z) as f:
        assert f.testzip() is None
        assert json.loads(f.read(NAME+'.json'))==report
        for p,m in zip(files,manifest):
            body=f.read(str(p.relative_to(W)).replace('\\','/'))
            assert len(body)==m['bytes'] and hashlib.sha256(body).hexdigest()==m['sha256']
    result=dict(status='ARCHIVE_READBACK_VERIFIED',json=pin(D/(NAME+'.json')),zip=pin(z),files=len(files)+2,
        no_new_model_runs=True,no_binary_or_SDK_or_model_payload=True)
    save(W/'package-result.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':main()
