#include "tests/tools/qwen_backend_cpu_options_case.h"
#include <iostream>
int main() {
  auto checked=hyle::inference::test::cpu_options_case();
  if(!checked) { std::cerr<<checked.error().message()<<'\n'; return 1; }
  std::cout<<"{\"status\":\"PASS\",\"configured_provider\":\""<<checked->configured_provider
    <<"\",\"default_provider\":\""<<checked->default_provider
    <<"\",\"executor_calls\":"<<checked->executor_calls<<",\"executor_tasks\":"<<checked->executor_tasks
    <<",\"compared_values\":"<<checked->compared_values<<",\"native_threads\":1,\"invalid_threads\":[0,4294967295]}\n";
}
