#include "engine/inference/backend.h"
hyle::Result<hyle::inference::Backend> explicit_options(
    const hyle::compute::cpu::DefaultContextOptions &options) noexcept {
  return hyle::inference::Backend::create({.primary=hyle::inference::BackendKind::kCuda},{},options);
}
hyle::Result<hyle::inference::Backend> original_default() noexcept {
  return hyle::inference::Backend::create();
}
