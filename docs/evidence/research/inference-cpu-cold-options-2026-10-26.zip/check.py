"""One real CPU shared test body and one GPU-only header check; no SDK rebuild."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
spec = importlib.util.spec_from_file_location('finite_cpu', ROOT/'.scratch/inference-ct-block128-model-20261025/check_host.py')
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
COMPILE = ROOT/'.scratch/inference-duplicate-session-20261025/current1/compile/command.json'
LINK = ROOT/'.scratch/inference-duplicate-session-20261025/current1/link/command.json'
OLD = ROOT/'.scratch/inference-duplicate-session-20261025/current1/compile/unit.obj'
NATIVE = ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'

def main():
    name=sys.argv[1] if len(sys.argv)>1 else 'host1'
    assert name.startswith('host') and name[4:].isdigit()
    out=WORK/name; assert not out.exists(), 'Preserve previous attempt'
    tree=c.freeze(out,['tests/tools/qwen_backend_cpu_options_case.h'])
    source=tree/'consumer.cc'
    source.write_text('''#include "tests/tools/qwen_backend_cpu_options_case.h"
#include <iostream>
int main() {
  auto checked=hyle::inference::test::cpu_options_case();
  if(!checked) { std::cerr<<checked.error().message()<<'\\n'; return 1; }
  std::cout<<"{\\"status\\":\\"PASS\\",\\"configured_provider\\":\\""<<checked->configured_provider
    <<"\\",\\"default_provider\\":\\""<<checked->default_provider
    <<"\\",\\"executor_calls\\":"<<checked->executor_calls<<",\\"executor_tasks\\":"<<checked->executor_tasks
    <<",\\"compared_values\\":"<<checked->compared_values<<",\\"native_threads\\":1,\\"invalid_threads\\":[0,4294967295]}\\n";
}
''',encoding='utf-8')
    recipe=c.read(COMPILE)['command']; flags=c.flags(recipe,tree); env=c.environment(recipe[0])
    obj=out/'compile/unit.obj'; image=out/'link/check.exe'
    compiled=c.execute([recipe[0],*flags,str(source),'/sourceDependencies',str(out/'compile/dependencies.json'),
        '/Fo'+str(obj),'/Fd'+str(obj.with_suffix('.pdb'))],env,out/'compile')
    if compiled['exit']: c.save(out/'summary.json',dict(status='COMPILE_FAILED',compile=compiled)); return 1
    c.dependencies(out/'compile')
    old=c.read(LINK)['command']; assert old.count(str(OLD))==1
    args=[str(obj) if a==str(OLD) else a for a in old
        if not a.lower().startswith(('/out:','/pdb:','/map:','/implib:'))]
    inputs=[Path(a) for a in args[1:] if Path(a).is_absolute() and Path(a).suffix.lower() in {'.obj','.lib'}]
    c.save(out/'link-inputs.json',[c.pin(p) for p in inputs])
    linked=c.execute([*args,'/OUT:'+str(image),'/PDB:'+str(image.with_suffix('.pdb'))],env,out/'link')
    if linked['exit']: c.save(out/'summary.json',dict(status='LINK_FAILED',compile=compiled,link=linked)); return 1
    runtime=c.read(NATIVE.parents[1]/'runtime-environment.json')
    assert c.pin(NATIVE)['sha256']=='1066e80261cc58d1c0ea57e50475e2e38b7675b666eb2b639969e01e85916a46'
    os.link(NATIVE,image.parent/NATIVE.name)
    runenv=dict(env,PATH=str(image.parent)+';'+runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    c.save(out/'runtime.json',dict(native=c.pin(NATIVE),PATH=runenv['PATH']))
    ran=c.execute([str(image)],runenv,out/'run',timeout=120)
    if ran['exit']:c.save(out/'summary.json',dict(status='CPU_CASE_FAILED',compile=compiled,link=linked,run=ran)); return 1
    # The incomplete original type is enough to expose the overload. This TU
    # must not include a CPU factory or create a CPU link dependency.
    gpu_source=tree/'gpu_only.cc'
    gpu_source.write_text('''#include "engine/inference/backend.h"
hyle::Result<hyle::inference::Backend> explicit_options(
    const hyle::compute::cpu::DefaultContextOptions &options) noexcept {
  return hyle::inference::Backend::create({.primary=hyle::inference::BackendKind::kCuda},{},options);
}
hyle::Result<hyle::inference::Backend> original_default() noexcept {
  return hyle::inference::Backend::create();
}
''',encoding='utf-8')
    gpu_flags=[a for a in flags if 'HYLE_COMPUTE_CPU' not in a]
    gpu_flags+=['/DHYLE_COMPUTE_CUDA=1','/Zs']
    gpu=c.execute([recipe[0],*gpu_flags,str(gpu_source),'/sourceDependencies',str(out/'gpu-header/dependencies.json')],env,out/'gpu-header')
    if gpu['exit']:c.save(out/'summary.json',dict(status='GPU_HEADER_FAILED',compile=compiled,link=linked,run=ran,gpu_header=gpu)); return 1
    c.dependencies(out/'gpu-header')
    deps=c.read(out/'gpu-header/dependencies.json')['Data']['Includes']
    assert not any(Path(p).as_posix().endswith(('hyle/compute/cpu.h','hyle/graph/cpu.h','hyle/compute/backends/cpu.h')) for p in deps)
    facts=c.read(out/'run/stdout.log')
    summary=dict(status='PASS',compile=compiled,link=linked,run=ran,gpu_header=gpu,facts=facts,
        link_inputs=len(inputs),core_SDK_provider_rebuilds=0,GPU_runs=0,HTTP=0,
        scope='shared actual CPU Graph/helper; existing full CPU+CUDA gtest wrapper source-only; no multithread speed or global runtime claim')
    c.save(out/'summary.json',summary)
    c.save(out/'ready.json',dict(status='READY_CPU_CHECKED_GPU_HEADER_CHECKED',image=c.pin(image),app=c.pin(obj),
        source_pins=[c.pin(ROOT/p) for p in ['engine/inference/backend.h','tests/tools/qwen_backend_cpu_options_case.h','tests/tools/qwen_backend_cpu_cuda_test.cc']],
        commands=[str(out/p/'command.json') for p in ['compile','link','run','gpu-header']],summary=str(out/'summary.json')))
    print(json.dumps(summary,indent=2)); return 0

if __name__=='__main__':sys.exit(main())
