from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
spec=importlib.util.spec_from_file_location('finite',ROOT/'.scratch/inference-ct-block128-model-20261025/check_host.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
out=WORK/'host3'
tree=out/'source'
recipe=c.read(ROOT/'.scratch/inference-current-cuda-20261025/app/command.json')['command']
flags=[a for a in c.flags(recipe,tree) if 'HYLE_COMPUTE_CPU' not in a]
assert any('HYLE_COMPUTE_CUDA=1' in a for a in flags)
folder=out/'gpu-header2'
result=c.execute([recipe[0],*flags,'/Zs',str(tree/'gpu_only.cc'),'/sourceDependencies',str(folder/'dependencies.json')],c.environment(recipe[0]),folder)
if result['exit']:sys.exit(1)
c.dependencies(folder)
deps=c.read(folder/'dependencies.json')['Data']['Includes']
assert not any(Path(p).as_posix().endswith(('hyle/compute/cpu.h','hyle/graph/cpu.h','hyle/compute/backends/cpu.h')) for p in deps)
summary=c.read(out/'summary.json')
summary['status']='PASS'
summary['gpu_header_first_missing_sdk_include']=summary.pop('gpu_header')
summary['gpu_header']=result
summary['facts']=c.read(out/'run/stdout.log')
summary.update(link_inputs=len(c.read(out/'link-inputs.json')),core_SDK_provider_rebuilds=0,GPU_runs=0,HTTP=0,
    scope='shared actual CPU Graph/helper; existing full CPU+CUDA gtest wrapper source-only; no multithread speed or global runtime claim')
c.save(out/'summary.json',summary)
image=out/'link/check.exe'
c.save(out/'ready.json',dict(status='READY_CPU_CHECKED_GPU_HEADER_CHECKED',image=c.pin(image),app=c.pin(out/'compile/unit.obj'),
    source_pins=[c.pin(ROOT/p) for p in ['engine/inference/backend.h','tests/tools/qwen_backend_cpu_options_case.h','tests/tools/qwen_backend_cpu_cuda_test.cc']],
    commands=[str(out/p/'command.json') for p in ['compile','link','run','gpu-header','gpu-header2']],summary=str(out/'summary.json')))
print(summary)
