"""Offline arithmetic over retained traces only; never invokes native inference."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import re
import sqlite3
import statistics

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
F = ROOT / '.scratch/mtp-finish-phase-20261025/analysis.json'
P = ROOT / 'docs/evidence/performance/mtp-logical-call-attribution-2026-10-25.json'
SQLITE = ROOT / '.scratch/mtp-logical-call-trace-20261025/peer/trace1/trace.sqlite'
finish, prior = json.loads(F.read_text()), json.loads(P.read_text())

def pin(path):
    b = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def stat(values):
    return {'n': len(values), 'mean_ms': statistics.mean(values) / 1e6,
        'median_ms': statistics.median(values) / 1e6,
        'min_ms': min(values) / 1e6, 'max_ms': max(values) / 1e6} if values else {'n': 0}

def union(intervals):
    end, total = None, 0
    for a, b in sorted(intervals):
        if end is None or a >= end:
            total += b - a
        elif b > end:
            total += b - end
        end = max(end, b) if end is not None else b
    return total

episodes = [e for e in finish['same_trace_outer_episode']['episodes'] if e['decode'] and e['classification'] == 'no_record']
assert len(episodes) == 45
seqs = {e['seq'] for e in episodes}
phases = defaultdict(list)
for row in finish['phase_rows']:
    if row['seq'] in seqs:
        phases[row['phase']].append(row)
steady = {'episodes': stat([e['wall_ns'] for e in episodes]),
    'observed_gpu_union': stat([e['gpu_execution_union_ns'] for e in episodes]),
    'wall_without_observed_gpu': stat([e['wall_without_observed_gpu_ns'] for e in episodes]),
    'outer': {phase: {
        'wall': stat([e['outer_phase_activity'][phase]['wall_ns'] for e in episodes]),
        'observed_gpu_union': stat([e['outer_phase_activity'][phase]['execution_gpu_union_ns'] for e in episodes]),
        'wall_without_observed_gpu': stat([e['outer_phase_activity'][phase]['wall_without_observed_gpu_ns'] for e in episodes])}
        for phase in episodes[0]['outer_phase_activity']},
    'finish': {phase: {'wall': stat([r['wall_ns'] for r in rows]),
        'observed_gpu_union': stat([r['execution_gpu_union_ns'] for r in rows]),
        'wall_without_observed_gpu': stat([r['wall_without_observed_gpu_ns'] for r in rows])}
        for phase, rows in phases.items()}}
steady['prepare_outside_replay'] = stat([e['outer_phase_wall_ns']['hyle/prepare'] - e['outer_phase_wall_ns']['hyle/prepare_replay'] for e in episodes])
steady['current_trace_captured_gpu'] = finish['same_role_T_GPU_comparison']['hyle_current_by_episode_record']
steady['last_gpu_to_event_sync_return_all_decode'] = finish['decode_last_visible_GPU_to_wait_return']['gap']
steady['caller_gap_all_decode'] = {k:v for k,v in finish['caller_dispatch_gap'].items() if k != 'samples'}

con = sqlite3.connect('file:' + SQLITE.resolve().as_posix() + '?mode=ro', uri=True)
con.row_factory = sqlite3.Row
con.execute('PRAGMA query_only=ON')
nvtx_sql = 'SELECT n.start,n.end,n.globalTid,COALESCE(n.text,s.value) AS label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL ORDER BY n.start'
api_sql = 'SELECT r.start,r.end,r.globalTid,s.value AS api FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId ORDER BY r.start'
apis = [dict(row) for row in con.execute(api_sql)]
gpu = []
for table in ('CUPTI_ACTIVITY_KIND_KERNEL', 'CUPTI_ACTIVITY_KIND_MEMCPY', 'CUPTI_ACTIVITY_KIND_MEMSET'):
    gpu += [(row['start'], row['end']) for row in con.execute('SELECT start,end FROM ' + table)]
calls = []
for row in con.execute(nvtx_sql):
    label = row['label'] or ''
    if not label.startswith(('peer/target_decode ', 'peer/draft_decode ')):
        continue
    meta = {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)', label)}
    if meta['T'] != 2:
        continue
    local = [a for a in apis if a['globalTid'] == row['globalTid'] and row['start'] <= a['start'] and a['end'] <= row['end']]
    if any(any(name in a['api'] for name in ('BeginCapture','EndCapture','GraphInstantiate','GraphExecUpdate')) for a in local):
        continue
    if not any('GraphLaunch' in a['api'] for a in local):
        continue
    observed = union([(max(a, row['start']), min(b, row['end'])) for a,b in gpu if a < row['end'] and row['start'] < b])
    wall = row['end'] - row['start']
    calls.append({'role': 'target' if '/target_' in label else 'draft', 'context': meta['context'],
        'wall_ns': wall, 'gpu_ns': observed, 'no_gpu_ns': wall-observed})
peer = {}
for role in ('target', 'draft'):
    for late in (False, True):
        rows = [r for r in calls if r['role'] == role and (not late or r['context'] >= 384)]
        peer[role + '/T2/no_record' + ('/context>=384' if late else '')] = {
            'wall': stat([r['wall_ns'] for r in rows]),
            'observed_gpu_union': stat([r['gpu_ns'] for r in rows]),
            'wall_without_observed_gpu': stat([r['no_gpu_ns'] for r in rows])}
con.close()

def compact_group(group):
    return {name: {'n': rows['n'], 'mean_ms': rows['mean_ms'], 'median_ms': rows['median_ms']}
        for name, rows in group.items()}

steady_compact = {
    'episodes': steady['episodes'],
    'observed_gpu_union': steady['observed_gpu_union'],
    'wall_without_observed_gpu': steady['wall_without_observed_gpu'],
    'outer_phases_ms_mean': {name: {key: value['mean_ms'] for key,value in group.items()} for name,group in steady['outer'].items()},
    'finish_phases_ms_mean': {name.rsplit('/',1)[-1]: {key:value['mean_ms'] for key,value in group.items()} for name,group in steady['finish'].items()},
    'prepare_outside_nested_replay_mean_ms': steady['prepare_outside_replay']['mean_ms'],
    'last_gpu_to_event_sync_return_all66_decode_median_ms': steady['last_gpu_to_event_sync_return_all_decode']['median_ms'],
    'endpoint_to_next_prepare_all65_median_ms': steady['caller_gap_all_decode']['span']['median_ms'],
    'endpoint_to_next_prepare_excluding_finish_observer_median_ms': steady['caller_gap_all_decode']['other_caller_gap']['median_ms'],
}

memo = {
    'status': 'READ_ONLY_EXISTING_DIAGNOSTICS_NO_NEW_BUILD_RUN_OR_PROFILE',
    'strongest_fact': 'The45no-record Hyle episodes expose about0.63ms prepare before native launch; their roughly13ms finish/wait is overwhelmingly real GPU progress. Complete state publication/retirement is about16us, not a millisecond-scale host bottleneck. There is a measurable bounded steady preparation surface, but these traces do not prove that its validation/upload work can be removed or that it explains current9.6-9.9% MTP throughput deficit.',
    'hyle_same_trace_no_record45': steady_compact,
    'peer_same_role_T2_no_capture_API': {key:compact_group(group) for key,group in peer.items()},
    'same_role_gpu_descriptive_only': {
        'hyle_target_T2_no_record_median_ms': finish['same_role_T_GPU_comparison']['hyle_current_by_episode_record']['target/T2/no_record']['median_ms'],
        'hyle_draft_T2_no_record_median_ms': finish['same_role_T_GPU_comparison']['hyle_current_by_episode_record']['draft/T2/no_record']['median_ms'],
        'peer_target_T2_captured_median_ms': prior['analysis']['arms']['peer']['by_role_T']['target/T2/captured']['gpu_active']['median_ms'],
        'peer_draft_T2_captured_median_ms': prior['analysis']['arms']['peer']['by_role_T']['draft/T2/captured']['gpu_active']['median_ms'],
    },
    'interpretation': [
        'Prior logical-call trace independently finds45no-record episodes: prepare mean0.658ms/replay0.277ms, submit1.072ms with substantial GPU overlap. Finish trace estimates agree in scale; do not pool the two process clocks.',
        'prepare_replay is nested within prepare. In the finish trace, replay contributes about0.256ms and prepare outside replay about0.378ms. The original fixed-capacity input scratch, original Graph replay/binding admission and provider batch-plan reuse are already used; no redundant hot allocation or unused gate is established by these aggregate numbers.',
        'The roughly1ms submit wall cannot be added to GPU elapsed time: most actual GPU work starts while submit runs. Likewise wall minus observed GPU is neither pure CPU utilization nor recoverable time. EventSynchronize last-visible-GPU→return median19.7us is much smaller than completion_wait wall.',
        'Peer decode NVTX finishes immediately after llama_synchronize, before host sampled(), hidden(), KV trim and next input construction. Hyle episode includes selection, full immutable state export and atomic publication. Peer target+draft residuals cannot be subtracted from Hyle whole-episode residual as equivalent CPU overhead.',
        'Same-T observed target GPU activity is slightly higher for Hyle, while draftT2 is not higher. Peer no-record target/draft T2 nonactivity means0.928/0.328ms already exist inside their narrower decode-only markers; this does not establish a larger Hyle steady host tax. GPU-side matched target/provider work merits attribution, but no particular kernel/fusion or state-copy change is proven. Closed wholeM2/fixed512/input/hidden-order hypotheses stay closed.',
    ],
    'current_source_boundaries': [
        {'anchor': 'engine/models/qwen35/main.cc:3677', 'fact': 'Current preallocated packed input workspace writes actual token/position tensors; per-request layout and page permissions still derive from original complete heads.'},
        {'anchor': 'engine/models/qwen35/main.cc:3836', 'fact': 'Current exact Invocation.prepare_replay uses original selected Graph/provider facilities. Old no-record replay cost does not identify a dispensable permission/identity check.'},
        {'anchor': 'engine/models/qwen35/main.cc:3924', 'fact': 'Finish waits actual original Graph Completion before original selection/export; it is not host publication overhead.'},
        {'anchor': 'engine/models/qwen35/main.cc:3997', 'fact': 'Current hidden-egress copy is a new actual Completion boundary absent from both old diagnostic profiles. Its timing cannot be certified from this memo.'},
        {'anchor': '.scratch/mtp-logical-call-trace-20261025/peer.patch:25', 'fact': 'Peer marker covers llama_decode+synchronize, excluding the following sampled/hidden and caller state bookkeeping.'},
    ],
    'limits': [
        'These are retained single profiled processes and historical source; the current full32clean comparison remains separate. No stable speedup or current phase percentage is inferred from profiler durations.',
        'No per-operator/PMU event attribution was recomputed here. Different precision, context, acceptance and output-state authority remain real cross-engine differences.',
        'No new profiling, model execution, build, product edit or proposal to expand pools/cache/manager. A next change still needs concrete redundant work or matched provider evidence, not only this upper-bound phase budget.',
    ],
    'inputs': [pin(F), pin(P), pin(SQLITE), pin(ROOT / '.scratch/mtp-logical-call-trace-20261025/peer.patch')],
    'current_source_pin': pin(ROOT / 'engine/models/qwen35/main.cc'),
}
(WORK / 'memo.json').write_text(json.dumps(memo, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'memo': pin(WORK/'memo.json'), 'hyle_steady_episode_mean_ms': steady['episodes']['mean_ms'],
    'hyle_steady_gpu_mean_ms': steady['observed_gpu_union']['mean_ms'],
    'hyle_steady_nonactivity_mean_ms': steady['wall_without_observed_gpu']['mean_ms'],
    'hyle_prepare_mean_ms': steady['outer']['hyle/prepare']['wall']['mean_ms'],
    'peer_no_record_T2': {role:compact_group(peer[role+'/T2/no_record']) for role in ('target','draft')}}, indent=2))
