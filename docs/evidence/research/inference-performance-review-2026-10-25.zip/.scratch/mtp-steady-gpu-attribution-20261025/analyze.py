"""Only read the existing paired logical traces. No compiler/device/profiler calls."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import sqlite3
import statistics

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
SOURCE = ROOT / '.scratch/mtp-logical-call-trace-20261025'
SQL = {
    'kernels': '''SELECT k.*,s.value AS name FROM CUPTI_ACTIVITY_KIND_KERNEL k
                  JOIN StringIds s ON s.id=k.demangledName ORDER BY start''',
    'copies': 'SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY start',
    'memsets': 'SELECT * FROM CUPTI_ACTIVITY_KIND_MEMSET ORDER BY start',
    'runtime': '''SELECT r.*,s.value AS name FROM CUPTI_ACTIVITY_KIND_RUNTIME r
                  JOIN StringIds s ON s.id=r.nameId ORDER BY start''',
}


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def union(events):
    joined = []
    for start, end in sorted((r['start'], r['end']) for r in events):
        assert end >= start
        if joined and start <= joined[-1][1]:
            joined[-1][1] = max(joined[-1][1], end)
        else:
            joined.append([start, end])
    return sum(end - start for start, end in joined)


def stats(values):
    return {'n': len(values), 'mean_ms': statistics.mean(values) / 1e6,
            'median_ms': statistics.median(values) / 1e6,
            'min_ms': min(values) / 1e6, 'max_ms': max(values) / 1e6}


def family(row, arm, role):
    if row['kind'] == 'copy':
        return 'memory_copy/' + row['copy_name']
    if row['kind'] == 'memset':
        return 'memory_set'
    name = row['name']
    grid = tuple(row['grid' + axis] for axis in 'XYZ')
    if any(part in name for part in ['gemm', 'gemv', 'mul_mat_f<', 'mul_mat_vec_f<']):
        # These grid/shape associations are the existing body-route source review,
        # and counts are checked below for each actual target, not inferred afresh.
        if arm == 'hyle':
            shape = {(8, 48, 1): 'N6144_K2048', (8, 16, 1): 'N2048_mixedK',
                     (8, 1940, 1): 'vocabulary_head', (62080, 1, 1): 'vocabulary_head'}
        else:
            shape = {(192, 1, 1): 'N6144_K2048', (64, 1, 1): 'N2048_mixedK',
                     (7760, 1, 1): 'vocabulary_head', (248320, 1, 1): 'vocabulary_head'}
        return 'matrix/' + shape.get(grid, 'other_matrix')
    if 'splitKreduce_kernel' in name:
        return 'matrix/reduction_auxiliary'
    if 'gated_delta_net_cuda' in name:
        return 'GDN_recurrence'
    if any(part in name for part in ['flashinfer::', 'flash_attn_']):
        return 'attention'
    if 'ssm_conv_f32' in name:
        return 'GDN_convolution'
    if 'hyle_bf16_l2' in name or 'rms_norm_f32' in name:
        # Peer expresses its L2 work with its normalization/gain route, so do not
        # label the specialized Hyle L2 kernel as an absent peer operation.
        return 'normalization_RMS_or_L2'
    if any(part in name for part in ['arg_tiles_kernel', 'arg_finish_kernel', 'argmax_f32',
                                     'gather_output_kernel', 'top_k', 'TopK']):
        return 'selection_or_gather'
    if 'append_rows' in name or 'k_set_rows' in name:
        return 'KV_append'
    if 'rope' in name:
        return 'position_RoPE'
    if 'concat' in name or 'k_get_rows' in name or 'pad_f32' in name:
        return 'row_gather_concat_pad'
    if 'cpy_scalar' in name or 'convert_unary' in name:
        # Same-type copies and dtype conversion stay separately identified.
        if ('float, float>' in name or '__nv_bfloat16, __nv_bfloat16>' in name):
            return 'copy_kernel_same_type'
        return 'dtype_conversion'
    if any(part in name for part in ['silu', 'softplus', 'sigmoid', 'op_add', 'op_mul',
                                     'op_repeat', 'scale_f32']):
        return 'elementwise_gate_residual_scale'
    return 'other_kernel'


out = {'status': 'OFFLINE_EXISTING_PAIRED_LOGICAL_TRACE_ONLY', 'new_GPU_build_HTTP': 0,
       'SQL': SQL, 'script': None, 'arms': {}}
for arm in ['hyle', 'peer']:
    db_path = SOURCE / arm / 'trace1/trace.sqlite'
    db = sqlite3.connect('file:' + db_path.as_posix() + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA query_only=ON')
    copy_labels = dict(db.execute('SELECT id,name FROM ENUM_CUDA_MEMCPY_OPER'))
    events = []
    for key, kind in [('kernels', 'kernel'), ('copies', 'copy'), ('memsets', 'memset')]:
        for row in db.execute(SQL[key]):
            value = dict(row)
            value['kind'] = kind
            if kind == 'copy':
                value['copy_name'] = copy_labels[value['copyKind']]
            events.append(value)
    by_corr = defaultdict(list)
    for row in events:
        by_corr[row['correlationId']].append(row)
    runtime = [dict(row) for row in db.execute(SQL['runtime'])]
    records = read(SOURCE / arm / 'logical-records.json')
    used = []
    outside_graphs = []
    excluded = Counter()
    for rec in records:
        decode = (rec['meta']['role'] in [3, 4, 5, 6] if arm == 'hyle'
                  else '_decode' in rec['label'])
        if not decode:
            continue
        # Cold/warm is checked directly against this same trace's runtime rows.
        apis = [api for api in runtime if api['globalTid'] == rec['globalTid']
                and rec['start_ns'] <= api['start'] and api['end'] <= rec['end_ns']]
        if any(any(part in api['name'] for part in
                   ['BeginCapture', 'EndCapture', 'GraphInstantiate', 'GraphExecUpdate'])
               for api in apis):
            excluded['capture_or_native_update_root'] += 1
            continue
        assert rec['first_use_class'] == 'no_record_or_instantiate'
        graph_cids = {row['correlationId'] for row in rec['captured_launches']}
        outside = [row for row in events if rec['start_ns'] <= row['start']
                   and row['end'] <= rec['end_ns'] and row['correlationId'] not in graph_cids]
        outside_graphs.append({'seq': rec['meta']['seq'], 'meta': rec['meta'],
                               'GPU_union_ns': union(outside),
                               'kinds': dict(Counter(row['kind'] for row in outside)),
                               'bytes': sum(row.get('bytes', 0) for row in outside),
                               'copy_kinds': dict(Counter(row.get('copy_name') for row in outside if row['kind'] == 'copy')),
                               'kernel_names': dict(Counter(row['name'] for row in outside if row['kind'] == 'kernel'))})
        for role in ['target', 'draft']:
            if arm == 'peer' and not rec['label'].startswith('peer/' + role):
                continue
            count = rec['meta'][role + '_T'] if arm == 'hyle' else rec['meta']['T']
            if count != 2:
                excluded[role + '_not_T2'] += 1
                continue
            launches = [row for row in rec['captured_launches'] if row['role'] == role]
            if not launches:
                excluded[role + '_eager_no_captured_launch'] += 1
                continue
            assert len(launches) == 1
            launch = launches[0]
            cid = launch['correlationId']
            assert sum(api['correlationId'] == cid and 'GraphLaunch' in api['name']
                       for api in apis) == 1
            selected = by_corr[cid]
            assert selected
            assert all(rec['start_ns'] <= row['start'] and row['end'] <= rec['end_ns']
                       for row in selected)
            kernels = [row for row in selected if row['kind'] == 'kernel']
            expected = (738 if role == 'target' else 41) if arm == 'hyle' else (727 if role == 'target' else 34)
            assert len(kernels) == expected, (arm, role, rec['meta'], len(kernels))
            groups = defaultdict(list)
            for row in selected:
                groups[family(row, arm, role)].append(row)
            if role == 'target':
                for key, size in [('matrix/N6144_K2048', 66), ('matrix/N2048_mixedK', 66),
                                  ('matrix/vocabulary_head', 1), ('matrix/other_matrix', 54)]:
                    assert len(groups[key]) == size
            row = {'seq': rec['meta']['seq'], 'context': rec['meta']['context'],
                   'meta': rec['meta'], 'role': role, 'correlationId': cid,
                   'kernel_count': len(kernels), 'GPU_union_ns': union(selected),
                   'kernel_union_ns': union(kernels),
                   'activity_sum_ns': sum(item['end'] - item['start'] for item in selected),
                   'kernel_sum_ns': sum(item['end'] - item['start'] for item in kernels),
                   'GPU_span_ns': max(item['end'] for item in selected) - min(item['start'] for item in selected),
                   'families': {key: {'union_ns': union(rows), 'activity_sum_ns': sum(item['end'] - item['start'] for item in rows),
                                      'events': len(rows), 'bytes': sum(item.get('bytes', 0) for item in rows)}
                                for key, rows in groups.items()}}
            row['cross_family_union_overlap_ns'] = sum(g['union_ns'] for g in row['families'].values()) - row['GPU_union_ns']
            if arm == 'peer':
                external = [item for item in events if rec['start_ns'] <= item['start']
                            and item['end'] <= rec['end_ns'] and item['correlationId'] != cid]
                row['outside_captured_graph_but_inside_peer_native_range'] = {
                    'GPU_union_ns': union(external),
                    'kinds': dict(Counter(item['kind'] for item in external)),
                    'bytes': sum(item.get('bytes', 0) for item in external),
                    'copy_kinds': dict(Counter(item.get('copy_name') for item in external if item['kind'] == 'copy'))}
            used.append((row, selected))
    groups_out = {}
    for window in ['all_warm', 'late_context_ge384']:
        for role in ['target', 'draft']:
            chosen = [(row, events) for row, events in used if row['role'] == role
                      and (window == 'all_warm' or row['context'] >= 384)]
            rows = [row for row, events in chosen]
            assert rows
            group_stats = {}
            all_families = sorted({family for row in rows for family in row['families']})
            for key in all_families:
                values = [row['families'].get(key, {}).get('union_ns', 0) for row in rows]
                event_counts = [row['families'].get(key, {}).get('events', 0) for row in rows]
                byte_counts = [row['families'].get(key, {}).get('bytes', 0) for row in rows]
                group_stats[key] = stats(values) | {'events_per_call': sorted(set(event_counts)),
                                                    'bytes_per_call': sorted(set(byte_counts))}
            names = defaultdict(list)
            for call_row, chosen_events in chosen:
                for event in chosen_events:
                    if event['kind'] == 'kernel':
                        names[(family(event, arm, role), event['name'])].append(event)
            group_names = [{'family': key[0], 'name': key[1], 'events': len(events),
                            'sum_duration_mean_per_call_ms': sum(item['end'] - item['start'] for item in events) / len(rows) / 1e6,
                            'grids': sorted({(item['gridX'], item['gridY'], item['gridZ']) for item in events})}
                           for key, events in names.items()]
            groups_out[window + '/' + role] = {
                'calls': len(rows), 'seq': [row['seq'] for row in rows],
                'contexts': [row['context'] for row in rows],
                'GPU_union': stats([row['GPU_union_ns'] for row in rows]),
                'kernel_union': stats([row['kernel_union_ns'] for row in rows]),
                'GPU_span': stats([row['GPU_span_ns'] for row in rows]),
                'within_graph_no_observed_activity': stats([row['GPU_span_ns'] - row['GPU_union_ns'] for row in rows]),
                'sum_minus_union': stats([row['activity_sum_ns'] - row['GPU_union_ns'] for row in rows]),
                'cross_family_union_overlap': stats([row['cross_family_union_overlap_ns'] for row in rows]),
                'families': group_stats,
                'kernel_names': sorted(group_names, key=lambda value: value['sum_duration_mean_per_call_ms'], reverse=True)}
            if arm == 'peer':
                external = [row['outside_captured_graph_but_inside_peer_native_range'] for row in rows]
                groups_out[window + '/' + role]['outside_captured_graph_but_inside_peer_native_range'] = {
                    'GPU_union': stats([row['GPU_union_ns'] for row in external]),
                    'bytes_per_call': sorted({row['bytes'] for row in external}),
                    'observed_kinds': sorted({key for row in external for key in row['kinds']}),
                    'copy_kinds': sorted({key for row in external for key in row['copy_kinds']})}
    source_analysis = read(SOURCE / 'analysis.json')['arms'][arm]
    # Preserve the observability boundary: activities outside even the logical
    # native roots are not silently charged to a chosen warm target/draft.
    external_to_all_roots = [row for row in events if not any(
        rec['start_ns'] <= row['start'] and row['end'] <= rec['end_ns'] for rec in records)]
    out['arms'][arm] = {
        'inputs': [pin(db_path), pin(SOURCE / arm / 'logical-records.json')],
        'source_work_equal': source_analysis['source_work_equal'],
        'work': source_analysis['work'], 'excluded': dict(excluded),
        'driver_table_present': source_analysis['driver_table_present'],
        'hardware_from_existing_trace': [dict(row) for row in db.execute('SELECT name,totalMemory,smCount,computeMajor,computeMinor FROM TARGET_INFO_GPU WHERE smCount>0')],
        'outside_captured_graphs_inside_no_capture_decode_roots': outside_graphs,
        'outside_every_logical_root_whole_trace_NOT_warm_attribution': {
            'GPU_union_ns': union(external_to_all_roots),
            'kinds': dict(Counter(row['kind'] for row in external_to_all_roots)),
            'bytes': sum(row.get('bytes', 0) for row in external_to_all_roots),
            'copy_kinds': dict(Counter(row.get('copy_name') for row in external_to_all_roots if row['kind'] == 'copy'))},
        'groups': groups_out, 'per_call': [row for row, events in used]}
    db.close()

out['comparison'] = {}
for group in ['all_warm/target', 'all_warm/draft', 'late_context_ge384/target', 'late_context_ge384/draft']:
    h = out['arms']['hyle']['groups'][group]
    p = out['arms']['peer']['groups'][group]
    out['comparison'][group] = {
        'H_calls': h['calls'], 'P_calls': p['calls'],
        'H_minus_P_GPU_union_mean_ms': h['GPU_union']['mean_ms'] - p['GPU_union']['mean_ms'],
        'family_H_minus_P_union_mean_ms': {key: h['families'].get(key, {}).get('mean_ms', 0) - p['families'].get(key, {}).get('mean_ms', 0)
                                         for key in sorted(h['families'].keys() | p['families'].keys())}}
out['script'] = pin(Path(__file__))
(WORK / 'facts.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': out['status'], 'comparison': out['comparison']}, indent=2))
