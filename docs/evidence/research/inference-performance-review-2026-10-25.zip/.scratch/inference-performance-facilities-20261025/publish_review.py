from pathlib import Path
import datetime, hashlib, json, zipfile

R = Path.cwd()
W = Path(__file__).resolve().parent
D = R / 'docs/evidence/research'
NAME = 'inference-performance-review-2026-10-25'

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def pin(p):
    p = Path(p)
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

sources = [
    W / 'root-review.json', W / 'latest-llama-source.json',
    R / '.scratch/inference-facility-reuse-review-20261025/memo.json',
    R / '.scratch/mtp-steady-cost-review-20261025/memo.json',
    R / '.scratch/mtp-steady-cost-review-20261025/review.py',
    R / '.scratch/mtp-steady-gpu-attribution-20261025/memo.json',
    R / '.scratch/mtp-steady-gpu-attribution-20261025/analyze.py',
    R / '.scratch/mtp-steady-gpu-attribution-20261025/reporting-boundary.json',
    R / '.scratch/inference-foundation-inventory-20261025/local-reference-performance.json',
    R / '.scratch/inference-foundation-inventory-20261025/trtllm-decode-inspiration.json',
    R / '.scratch/mtp-body-recapture-cause-20261025/vllm-fixed-buffer-anchor.json',
    Path(__file__).resolve(),
]
inventory = read(sources[8])
trt, vllm = read(sources[9]), read(sources[10])
llama = read(sources[1])
versions = [dict(repository='llama.cpp', HEAD=llama['latest_HEAD'], clean=True,
                 qualification='Selected local-source comparison; executable benchmark remains matched433e7051 closure.'),
            dict(repository='vllm', HEAD=vllm['actual_HEAD'],
                 qualification='Fixed-buffer/shape-bucket source anchors only.'),
            dict(repository='TensorRT-LLM', HEAD=trt['reference']['HEAD'],
                 qualification=trt['reference']['status_caveat'])]
versions += [dict(repository=x['directory'], HEAD=x['head'],
                  clean=not x['dirty_entries'], inspected_files=len(x['implementation_files']))
             for x in inventory['repositories']]
archive = D / (NAME + '.zip')
members = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sources:
        item = pin(p)
        z.write(p, item['path'])
        members.append(item)
    z.writestr('manifest.json', json.dumps(dict(members=members,
        limits='No models, bins, SDKs, source trees, raw SQLite duplicates or large derived facts. '
               'Original diagnostic inputs remain pinned in the archived memos; scripts regenerate derivations.'), indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in members:
        assert hashlib.sha256(z.read(item['path'])).hexdigest() == item['sha256']
report = dict(
    status='BOUNDED_SOURCE_AND_RETAINED_TRACE_REVIEW',
    generated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Performance facility reuse and selected mechanisms in nine actual local reference engines. '
          'This is not an exhaustive code audit of those engines or a new throughput window.',
    execution=dict(new_model_runs=0, GPU=0, builds=0, network=0, downloads=0),
    reference_versions=versions,
    strongest_findings=[
        dict(area='Existing Hyle acceleration facilities',
             conclusion='Weight loading already uses bounded Scheduler/IoContext/FileResourcePipeline; '
                        'hot integer/request storage uses reserved vectors/SmallVector and a fixed FIFO. '
                        'Output facts are cold-indexed; Graph uses prepared binding spans and reserved full keys. '
                        'No measured reason to mechanically substitute containers or add a second scheduler/cache.'),
        dict(area='No-record host stages in retained diagnostic',
             conclusion='45 original no-record episodes: mean prepare0.633568ms, including replay0.255652ms; '
                        'publication/retirement0.015825ms. Finish/wait13.120427ms overlaps12.708460ms GPU activity. '
                        'Nested/overlapped intervals are not added or treated as removable host time.'),
        dict(area='Matched captured GPU subsets',
             conclusion='Late T2 target Hyle23/peer25 captured intervals differ by mean+0.316575ms; '
                        'draft by-0.026362ms. Largest positive family is66 N6144/K2048 projections,+0.340235ms, '
                        'partly offset by faster vocabulary head. Existing MMVF/Lt routes remain closed absent a new mechanism.',
             limit='These are retained instrumented subsets with explicit outside activities and precision/work differences, '
                   'not a decomposition of the current complete9.6-9.9% throughput gap.'),
        dict(area='CPU/mixed cold configuration',
             conclusion='Public CPU Context options already accept borrowed ParallelExecutorRef and native_threads. '
                        'Engine Backend did not forward them and used native_threads=1. A narrow cold forwarding seam '
                        'can reuse those facilities; default all-core pools or global ATen setters are not justified.',
             status='Selected for implementation and finite checks separately.'),
        dict(area='Synchronous reporting',
             conclusion='Original step reporting is inside the natural consumer journey and costs about0.13ms per call '
                        'in an earlier retained diagnostic, including synchronous stream IO. Coalescing within the same '
                        'call while preserving bytes/order/format and synchronous delivery is a legitimate candidate.',
             status='Private host probe/consumer screening is separate evidence; no whole-engine gain claimed here.'),
        dict(area='Further native state and metadata ideas',
             conclusion='ik_llama direct state-copy fusion and SGLang multi-state slot operations are concrete source ideas. '
                        'Hyle old Snapshot ownership prevents blind in-place adoption; existing CopyBatch/delta metadata '
                        'routes must be measured first. DeepInfer metadata kernels and Strata residency ideas have explicit '
                        'model/hardware/cold-capacity prerequisites. deepseek-recipe inspected code is Rust protocol/token '
                        'stream processing, with no CUDA/KV mechanism in that read scope.'),
    ],
    current_full_consumer_evidence=pin(R / 'docs/evidence/performance/inference-current-window-2026-10-25.json'),
    retained_source_snapshot='bfe1bb16c; exact source hashes in archived notes. Later implementations do not retroactively change these findings.',
    limits=['No new CPU/Apple/mixed throughput result.',
            'Source presence does not prove optimality; finite read domains do not prove absence of all other opportunities.',
            'No full GDN staging, generic manager, key relaxation, extra variants or reopening closed leaf candidates.',
            'Published progress remains active; functionality/architecture closure is not whole-goal performance completion.'],
    archive=pin(archive), archive_members=len(members)+1,
)
out = D / (NAME + '.json')
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf8')
print(json.dumps(dict(report=pin(out), archive=pin(archive), members=len(members)+1), indent=2))
