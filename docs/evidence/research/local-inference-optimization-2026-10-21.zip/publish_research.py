"""Compress seven local engine reviews into a bounded Hyle action list."""
from pathlib import Path
import hashlib
import json
import zipfile

F=Path(__file__).resolve().parent
R=next(x for x in F.parents if (x/'AGENTS.md').is_file() and (x/'src').is_dir())
E=R/'docs/evidence/research'
names=['tensorrt-vllm-research.json','llama-sglang-research.json','ik-llama-research.json',
       'ds4-deepinfer-research.json','qwen-current-lt-route-confirmation.json']
def read(name): return json.loads((F/name).read_text(encoding='utf-8-sig'))
def ident(path): return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest())
t,l,i,d=map(read,names[:4])
repositories=[dict(name=x['name'],commit=x['HEAD']) for x in t['repository_identity']]
repositories += [dict(name=x['repo'],commit=x['head']) for x in l['repositories']]
repositories += [dict(name='ik_llama.cpp',commit=i['repository']['head'])]
repositories += [dict(name=k,commit=v['commit']) for k,v in d['repositories'].items()]
mechanisms=len(t['tensorrt_llm'])+len(t['vllm'])+len(l['llama_cpp_findings'])+len(l['sglang_findings'])+len(i['findings'])+len(d['ds4'])+len(d['DeepInfer'])
assert len(repositories)==7 and mechanisms==23
actions=[
dict(priority=1, work='Bounded cold tactic comparison for one actual hot BF16 direct-Lt projection',
    source=['TensorRT-LLM autotuner.py:531-553,1321-1500', 'Hyle cublas_provider.cc:448-458', names[4]],
    gap='Current provider asks for one heuristic and retains that algorithm. Actual current Qwen T1 routes103 of187 MatMuls to direct Lt, including down/head; T128 routes187 of187. Counts are not a time share.',
    current_BF16_Qwen=True,
    next='Start with one traced head or down geometry and a small number of valid Lt algorithms in the original prepared owner. Preserve source bytes, typed rounding/accumulation and workspace limits. No hot search or general autotuning service.',
    closure='Compare actual projection and complete host-token session. Adopt only with correct outputs and measured benefit; otherwise retain original algorithm and close this finite experiment.'),
dict(priority=2, work='Fuse private normalization or activation into the existing quantization prologue',
    source=['vLLM libtorch_stable/layernorm_quant_kernels.cu:69-78', 'SGLang mxfp8_epilogue.py:73-78', 'Hyle graph_route_cuda/fp8_shared_prologue_region.cc:86-145'],
    gap='Hyle already shares quantization across compatible linears; the reviewed matching does not include the preceding norm/activation. Preserve the original BF16/F16 round even when the intermediate stays in registers.',
    current_BF16_Qwen=False,
    next='Choose one actually used FP8 role with matching group/scale/order/math and private intermediate; retain ordinary decomposition for escaped outputs. MXFP8/Blackwell and NVFP4 policies are not interchangeable with existing contracts.',
    closure='Reference the unfused rounding/quantization and compare launches, traffic and full role performance. Do not claim current BF16 decode improvement from an unused FP8 path.'),
dict(priority=3, work='Tile and pipeline one contract-compatible packed4bit linear directly into MMA',
    source=['vLLM mixed_precision/marlin.py:74-200', 'vLLM marlin_template.h:697-818,1030-1088', 'Hyle compute_provider_cuda/packed_rows.cuh:19-61'],
    gap='Hyle already reads compressed weights without a whole expanded bank. The reviewed packed_rows path uses warp F32 FMA; compatible native tiled MMA is a compute/layout opportunity, not missing format support.',
    current_BF16_Qwen=False,
    next='Use a supported4bit source layout/scale/cast contract; cold immutable repack if required, separate tiny-M and prefill schedules. MLX5/6bit, mixed promoted-F32 and quantized activation are separate contracts.',
    closure='Measure a real admitted role and subsequent same-quantization consumer; retain the original math path where incompatible. No whole-bank expansion or silent low-precision reduction.'),
dict(priority=4, work='Finish original-owner cold resources and consider mutually exclusive shape workspace sharing only where legal',
    source=['llama.cpp/ik graph and context pools', 'ds4 bounded decode islands', 'DeepInfer and vLLM static graph pools'],
    gap='Finite children, captures, shared FP8 prologue, reserved workspace and leases already exist. Current two native-owner reductions are tested, with no throughput gain established.',
    current_BF16_Qwen=True,
    next='Inspect only actual first-use allocations or duplicate mutually exclusive workspace. Keep escaped old outputs, StateVersion and independent parity-slot bindings alive. Shared pointer keys/weak outputs cannot replace those proofs.',
    closure='Report first-call/full-call and sampled memory separately. Do not start a second cache/executor or delay actual first execution outside timing.'),
dict(priority=5, work='Device metadata/CPU bookkeeping overlap and bounded expert residency for a consumer that needs them',
    source=['DeepInfer worker.py:90-189', 'ik selected-expert scheduler', 'ds4 SSD upload ring'],
    gap='Hyle already has queues, Completion, file streaming and WeightSlots. Device token dependencies and useful expert residency are consumer policies, not universally missing Graph primitives.',
    current_BF16_Qwen='Conditional; a fully resident small model gains nothing from SSD expert streaming.',
    next='Use the actual MTP/large working-set consumer when reached. Include host-ID readback, waiting, cancellation/drain, cache bytes and token-visible completion. Preserve single-request semantics.',
    closure='No current implementation promise or idle experimental candidate: reconsider only at that concrete consumer; no model support expansion.')]
archive=E/'local-inference-optimization-2026-10-21.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in names: z.write(F/name,name)
    z.write(__file__,'publish_research.py')
report=dict(schema='hyle.local-inference-optimization.v1',date='2026-10-21',
    status='First bounded source review complete; optimization opportunities are not measured wins',
    scope=dict(repositories=7,mechanism_notes=mechanisms,merged_directions=len(actions),
        priority='Single-machine inference speed first; GPU memory second',
        network=0,external_repo_changes=0,external_builds=0,external_GPU_runs=0),
    repositories=repositories,
    version_limits=['Local checkout versions only, not a claim of latest upstream.',
        'TensorRT-LLM index has staged deletions/untracked source; all cited files were checked against its HEAD with line-ending normalization. Other reviewed repositories were clean.',
        'Research llama.cpp HEAD is distinct from the retained D4 benchmark peer commit; source research is not a rerun of those engines.',
        'ds4 is antirez/community, not the official DeepSeek runtime. DeepInfer SM100/Ascend and multi-GPU throughput are not RTX4070 evidence.'],
    actions=actions,
    already_present=['Cold compiled finite graph family and explicit replay modes',
        'Shared compatible FP8 activation quantization', 'Packed direct consumers for supported formats',
        'Invocation workspace, result/state leases and native retirement', 'Bounded file pipeline and same-generation WeightSlots'],
    research_records=[ident(F/name) for name in names], archive=ident(archive),
    result_standard='Every subsequent optimization comparison reports prefill, full decode, per-phase GPU-memory/peak, and a fixed multi-turn session elapsed/output throughput. Missing items stay explicitly unmeasured; no averaging of phase TPS.',
    measured_native_work='../performance/qwen-capture-resource-reuse-2026-10-21.json',
    D4_complete=False)
out=E/'local-inference-optimization-2026-10-21.json'
assert not out.exists()
out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(dict(report=ident(out),archive=report['archive']),indent=2))
