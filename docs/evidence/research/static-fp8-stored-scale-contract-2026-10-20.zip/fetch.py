from pathlib import Path
import json,urllib.request,struct,time,hashlib
S=Path('.scratch/architecture-refactor-2026-10-18/static-fp8-contract-review').resolve();S.mkdir(parents=True,exist_ok=True)
def identity(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def fetch(url,p,limit,first=None,last=None):
 headers={'User-Agent':'hyle-contract-read-only/1','Accept-Encoding':'identity'}
 if first is not None:headers['Range']=f'bytes={first}-{last}'
 receipt={'url':url,'request_headers':headers,'maximum_body_bytes':limit,'started':time.time()}
 p.parent.mkdir(parents=True,exist_ok=True)
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=40) as r:
   receipt.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower() in ['content-length','content-range','content-type','etag','x-repo-commit','last-modified']})
   if first is not None:assert r.status==206 and r.headers.get('Content-Range','').startswith(f'bytes {first}-{last}/'),receipt
   data=r.read(limit+1);assert len(data)<=limit,(len(data),limit)
   if first is not None:assert len(data)==last-first+1
  p.write_bytes(data);receipt['body']=identity(p);return data
 except Exception as e:receipt['error']=str(e);raise
 finally:receipt['finished']=time.time();save(p.with_suffix(p.suffix+'.http.json'),receipt)
ARTIFACTS=[(7,'nvidia/Qwen3.8-27B-NVFP4','482ca0f3832238542f8f5295dde86b5f22711d80','model-00001-of-00003.safetensors'),(17,'nvidia/Qwen3.8-2.4T-A95B-NVFP4','74eb734297318ecf7c48016a4ac8ce1b47cc74a9','model-00200-of-00200.safetensors'),(28,'nvidia/GLM-5.3-NVFP4','e3b8f9f2fad29727dfa95e766c5cac18ea1414bf','model-00001-of-00050.safetensors')]
if __name__=='__main__':
 import concurrent.futures
 def one(row):
  i,repo,rev,name=row;d=S/'headers'/str(i)/name;base=f'https://huggingface.co/{repo}/resolve/{rev}/{name}'
  length=struct.unpack('<Q',fetch(base+'?download=true&hyle_static_fp8_range=0-7',d/'length.bin',8,0,7))[0];assert 2<=length<=2000000,length
  h=json.loads(fetch(base+f'?download=true&hyle_static_fp8_range=8-{7+length}',d/'header.json',length,8,7+length));fp8={k:v for k,v in h.items() if isinstance(v,dict) and v.get('dtype')=='F8_E4M3'}
  summary={'artifact_index':i,'repo':repo,'revision':rev,'file':name,'header':identity(d/'header.json'),'tensor_count':len(h)-('__metadata__'in h),'fp8_count':len(fp8),'examples':dict(list(fp8.items())[:5]),'tensor_payload_bytes':0};save(d/'summary.json',summary);print(json.dumps(summary),flush=True);return summary
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(one,ARTIFACTS))
 save(S/'header-summary.json',rows)
