"""Use the cached CUDA toolchain for a tiny native capability probe only."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
s = importlib.util.spec_from_file_location('runner', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(s)
s.loader.exec_module(b)
b.W = W

if sys.argv[1] == 'compile':
    sdk = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
    host = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64')
    (W / 'bin').mkdir(exist_ok=True)
    args = [str(sdk / 'bin/nvcc.exe'), '-std=c++17', '-O2', '-arch=sm_89', '-rdc=true',
            '--cudart', 'shared', '--allow-unsupported-compiler', '-ccbin', str(host),
            str(W / 'probe.cu'), '-o', str(W / 'bin/probe.exe')]
    b.execute(args, W / 'compile/attempt1', 180)
    b.save(W / 'ready.json', dict(image=b.pin(W / 'bin/probe.exe'), source=b.pin(W / 'probe.cu'),
        nvcc=b.pin(sdk / 'bin/nvcc.exe'), sdk_version=b.read(sdk / 'version.json')))
else:
    ready = b.read(W / 'ready.json')
    b.exact(ready['image'])
    try:
        b.execute([ready['image']['path']], W / 'native/attempt1', 30)
    except SystemExit as error:
        if error.code not in (1, 2):
            raise
    text = (W / 'native/attempt1/stdout.log').read_text(encoding='utf-8')
    lines = text.splitlines()
    value = json.loads(lines[-1])
    value.update(device=[line for line in lines if line.startswith('DEVICE ')],
        cases=[line for line in lines if line.startswith('CASE ')],
        errors=[line for line in lines if line.startswith('CUDA_ERROR ')],
        process=b.read(W / 'native/attempt1/process.json'), ready=b.pin(W / 'ready.json'))
    b.save(W / 'result.json', value)
    print(json.dumps(value, ensure_ascii=False))
