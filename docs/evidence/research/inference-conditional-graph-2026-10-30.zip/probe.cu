// CUDA 13.3 native semantics probe only; no Hyle validity/performance claim.
// Suggested: nvcc -std=c++17 -O2 -arch=sm_89 -rdc=true -cudart=shared probe.cu -o probe.exe
#include <cuda_runtime.h>
#include <cuda_device_runtime_api.h>
#include <cstdio>

__global__ void set_predicate(cudaGraphConditionalHandle handle, const int *mode) {
  if (blockIdx.x == 0 && threadIdx.x == 0 && *mode >= 0)
    cudaGraphSetConditional(handle, static_cast<unsigned>(*mode != 0));
}
__global__ void write_payload(int *output, int payload) {
  if (blockIdx.x == 0 && threadIdx.x == 0) *output = payload;
}

int main() {
  int outcome = 0, error_count = 0;
  auto check = [&](cudaError_t error, const char *api, int line) {
    if (error == cudaSuccess) return true;
    ++error_count;
    std::printf("CUDA_ERROR api=%s line=%d code=%d name=%s message=%s\n",
        api, line, static_cast<int>(error), cudaGetErrorName(error), cudaGetErrorString(error));
    if (!outcome) outcome = error == cudaErrorNotSupported || error == cudaErrorNoDevice ||
        error == cudaErrorInsufficientDriver ? 2 : 1;
    return false;
  };
#define CUDA_CHECK(call) do { if (!check((call), #call, __LINE__)) return false; } while (false)
  cudaStream_t stream = nullptr;
  cudaGraph_t graph = nullptr;
  cudaGraphExec_t executable = nullptr;
  int *mode_device = nullptr, *output_device = nullptr;
  bool completed = [&] {
    int count = 0, driver = 0, runtime = 0;
    CUDA_CHECK(cudaDriverGetVersion(&driver));
    CUDA_CHECK(cudaRuntimeGetVersion(&runtime));
    CUDA_CHECK(cudaGetDeviceCount(&count));
    if (!count) { outcome = 2; std::puts("UNSUPPORTED no CUDA device"); return false; }
    CUDA_CHECK(cudaSetDevice(0));
    cudaDeviceProp properties{};
    CUDA_CHECK(cudaGetDeviceProperties(&properties, 0));
    std::printf("DEVICE index=0 name=%s cc=%d.%d driver=%d runtime=%d header=%d\n",
        properties.name, properties.major, properties.minor, driver, runtime, CUDART_VERSION);
    CUDA_CHECK(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking));
    CUDA_CHECK(cudaMalloc(reinterpret_cast<void **>(&mode_device), sizeof(int)));
    CUDA_CHECK(cudaMalloc(reinterpret_cast<void **>(&output_device), sizeof(int)));
    CUDA_CHECK(cudaGraphCreate(&graph, 0));
    cudaGraphConditionalHandle handle = 0;
    // The default is applied anew at every launch. No competing handle setter.
    CUDA_CHECK(cudaGraphConditionalHandleCreate(&handle, graph, 0, cudaGraphCondAssignDefault));
    cudaKernelNodeParams setter{};
    setter.func = reinterpret_cast<void *>(set_predicate);
    setter.gridDim = dim3(1); setter.blockDim = dim3(1);
    void *setter_arguments[] = {&handle, &mode_device};
    setter.kernelParams = setter_arguments;
    cudaGraphNode_t setter_node = nullptr, conditional_node = nullptr, body_node = nullptr;
    CUDA_CHECK(cudaGraphAddKernelNode(&setter_node, graph, nullptr, 0, &setter));
    cudaGraphNodeParams conditional{};
    conditional.type = cudaGraphNodeTypeConditional;
    conditional.conditional.handle = handle;
    conditional.conditional.type = cudaGraphCondTypeIf;
    conditional.conditional.size = 1;
    // phGraph_out is an output populated by CUDA; its body graph is CUDA-owned.
    CUDA_CHECK(cudaGraphAddNode(&conditional_node, graph, &setter_node, nullptr, 1, &conditional));
    if (!conditional.conditional.phGraph_out || !conditional.conditional.phGraph_out[0]) {
      outcome = 1; std::puts("SEMANTIC_FAILURE missing conditional body graph"); return false;
    }
    int payload = 0x12345678;
    cudaKernelNodeParams body{};
    body.func = reinterpret_cast<void *>(write_payload);
    body.gridDim = dim3(1); body.blockDim = dim3(1);
    void *body_arguments[] = {&output_device, &payload};
    body.kernelParams = body_arguments;
    CUDA_CHECK(cudaGraphAddKernelNode(&body_node, conditional.conditional.phGraph_out[0],
        nullptr, 0, &body));
    CUDA_CHECK(cudaGraphInstantiateWithFlags(&executable, graph, 0));
    const int modes[] = {0, 1, -1};
    // Final -1 leaves the handle untouched: false must come from launch-default
    // reset after the preceding true, rather than from an explicit false write.
    for (int iteration = 0; iteration != 3; ++iteration) {
      const int mode = modes[iteration], sentinel = -1000 - iteration;
      int actual = 0;
      CUDA_CHECK(cudaMemcpyAsync(mode_device, &mode, sizeof(mode), cudaMemcpyHostToDevice, stream));
      CUDA_CHECK(cudaMemcpyAsync(output_device, &sentinel, sizeof(sentinel), cudaMemcpyHostToDevice, stream));
      CUDA_CHECK(cudaGraphLaunch(executable, stream));
      CUDA_CHECK(cudaMemcpyAsync(&actual, output_device, sizeof(actual), cudaMemcpyDeviceToHost, stream));
      CUDA_CHECK(cudaStreamSynchronize(stream));
      const int expected = mode == 1 ? payload : sentinel;
      std::printf("CASE iteration=%d setter_mode=%d actual=%d expected=%d default_reset=%s status=%s\n",
          iteration, mode, actual, expected, mode < 0 ? "true" : "false", actual == expected ? "PASS" : "FAIL");
      if (actual != expected) { outcome = 1; return false; }
    }
    return true;
  }();
#undef CUDA_CHECK
  if (!completed && !outcome) outcome = 1;
  // Retire all accepted work before freeing its executable, graph or buffers.
  // Body graphs, nodes and conditional handles belong to graph; do not free them.
  if (stream) check(cudaStreamSynchronize(stream), "cleanup cudaStreamSynchronize", __LINE__);
  if (executable) check(cudaGraphExecDestroy(executable), "cleanup cudaGraphExecDestroy", __LINE__);
  if (graph) check(cudaGraphDestroy(graph), "cleanup cudaGraphDestroy", __LINE__);
  if (output_device) check(cudaFree(output_device), "cleanup cudaFree(output)", __LINE__);
  if (mode_device) check(cudaFree(mode_device), "cleanup cudaFree(mode)", __LINE__);
  if (stream) check(cudaStreamDestroy(stream), "cleanup cudaStreamDestroy", __LINE__);
  std::printf("{\"status\":\"%s\",\"cuda_errors\":%d,\"hyle_source_validity_claim\":false,\"performance_claim\":false}\n",
      outcome == 0 ? "PASS" : outcome == 2 ? "UNSUPPORTED" : "FAIL", error_count);
  return outcome;
}
