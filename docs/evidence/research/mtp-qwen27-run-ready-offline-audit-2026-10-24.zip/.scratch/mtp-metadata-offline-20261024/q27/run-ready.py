"""Offline Q27 command preparation and explicit bounded cached-image runs.

No download, SDK build, implicit preparation, server, or throughput comparison.
Only `run --case NAME` starts a model, after authenticated complete preparation.
"""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[3];B=Path(__file__).resolve().parent;PLAN=B/'run-ready-plan.json';INPUT=B/'complete-v2'
sys.path.insert(0,str(R))
def load(p):return json.loads(p.read_text(encoding='utf8'))
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf8')
def identity(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def pin(record):
 if identity(R/record['path'])!=record:raise ValueError('Retained input changed: '+record['path'])
def prepare_plan():
 if PLAN.exists():raise RuntimeError('Retained run plan already exists; do not overwrite')
 p=load(B/'pieces/plan.json');source=dict(p['source'],repository=p['repository'],revision=p['revision'])
 from engine.models.qwen35.gguf_header import read_local_header
 from engine.models.qwen35.gguf_roles import typed_inventory
 header,raw=read_local_header(R/p['raw_header_prefix']['path'],whole_file_bytes=source['size'])
 inventory=typed_inventory(header,source,header_sha256=hashlib.sha256(raw).hexdigest());g=inventory['geometry'];layers=len(g['layers'])
 assert layers==64 and inventory['physical_role_count']==866 and inventory['mtp_role_count']==15
 # All64 target FFNs and their input norms on CPU; attention/GDN and original
 # embedding/head/NextN stay on CUDA. This is a bounded functional placement,
 # not a search for best performance or a physical memory-peak guarantee.
 host_names={r['physical_name']for r in inventory['roles']if r['logical_name'].startswith(tuple(f'model.language_model.layers.{i}.'for i in range(layers)))and('.mlp.'in r['logical_name']or r['logical_name'].endswith('.post_attention_layernorm.weight'))}
 host=sum(r['bytes']for r in p['roles']if r['physical_name']in host_names);total=sum(r['bytes']for r in p['roles']);text=sum(r['bytes']for r in inventory['roles']if not r['logical_name'].startswith('mtp.'))
 cpu=R/'.scratch/qwen-pure-cpu-deployment-20261024';mixed=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2';ready=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json'
 native=load(ready)['native_runtime'];native_source=Path(native['path']);native_image=mixed/native_source.name
 if not native_image.is_file()or identity(native_image)['sha256']!=native['sha256']:raise ValueError('Retained mixed native CPU DLL is absent or changed')
 runtime={
  'cpu':dict(image=identity(cpu/'build/bin/hyle.exe'),environment=identity(cpu/'runtime-environment.json'),native=identity(cpu/'build/bin/hyle_ggml_cpu_pure_ffa4_current.dll'),source=identity(cpu/'source-identities.json')),
  'mixed':dict(image=identity(mixed/'recursive-probe.exe'),environment=identity(ready),native=identity(native_image),source=identity(mixed/'sources.json'))}
 common=['--inputs',str(INPUT),'--capacity','32','--steps','4','--max-sessions','1','--active-sequences','1','--cache-bytes','2147483648','--prefix-cache','off','--replay','commands']
 cases=[]
 for route in ['cpu','mixed']:
  for mode in ['ordinary','k1']:
   command=[str(R/runtime[route]['image']['path']),*common,'--mtp','off'if mode=='ordinary'else'on']
   if route=='mixed':command+=['--cpu-ffn-layers',str(layers)]
   cases.append(dict(name=route+'-'+mode,route=route,mtp=mode=='k1',command=command,expected_loaded_bytes=total if mode=='k1'else text,expected_host_weight_bytes=host if route=='mixed'else(total if mode=='k1'else text)))
 plan=dict(kind='Bounded mandatory Q27 complete-input CPU and mixed first journeys',runner=identity(Path(__file__).resolve()),acquisition_plan=identity(B/'pieces/plan.json'),source=p['source'],geometry=g,
  runtime=runtime,cases=cases,prompt_tokens=1,capacity=32,maximum_outputs=4,cache_limit_bytes=2147483648,resident_sessions=1,active_sequences=1,
  mixed_placement=dict(cpu_target_ffn_layers=layers,host_physical_roles=len(host_names),host_weight_bytes=host,device_weight_bytes=total-host,original_storage_preserved=True,qualification='Actual role-byte placement only. Cache/workspace/driver/allocator/native-private peaks remain separately accounted; these bytes are not a physical VRAM bound.'),
  timeout_seconds=600,automatic_retry=False,HTTP=0,SDK_builds=0,performance_claim=False)
 save(PLAN,plan);print(json.dumps(dict(plan=identity(PLAN),cases=[c['name']for c in cases],mixed_placement=plan['mixed_placement'],models_started=0)))
def checked_plan():
 plan=load(PLAN);pin(plan['runner']);pin(plan['acquisition_plan'])
 for runtime in plan['runtime'].values():
  for record in runtime.values():pin(record)
 return plan
def ready(plan):
 needed=[B/'payload-role-files.json',B/'pieces/payload-acquisition-complete.json',INPUT/'weights.tsv',INPUT/'input.json',INPUT/'prompt.ids']
 if any(not f.is_file()for f in needed):return False
 receipt=load(needed[1]);acquired=load(needed[0]);prepared=load(INPUT/'input.json');prompt=list(map(int,(INPUT/'prompt.ids').read_text().split()))
 if not receipt.get('complete')or receipt.get('full_file_lfs_sha256')!=plan['source']['lfs_sha256']or receipt.get('plan')!=plan['acquisition_plan']:raise ValueError('Original full-file LFS acquisition is not certified by the retained piece plan')
 if not acquired.get('complete')or not acquired['source'].get('full_file_sha256_verified')or len(acquired['roles'])!=866:raise ValueError('Original physical role publication is incomplete')
 if prepared['geometry']!=plan['geometry']or prepared['physical_roles']!=866 or prepared['selected_weight_bytes']!=16453443584:raise ValueError('Prepared source geometry/byte inventory differs')
 if len(prompt)!=1 or not 0<=prompt[0]<plan['geometry']['vocabulary']:raise ValueError('Finite first journey requires exactly one original prepared BOS token')
 return True
def run(plan,name):
 if not ready(plan):raise RuntimeError('Complete original LFS +866 authenticated role bindings and prepared inputs are required; no model was started')
 case=next(x for x in plan['cases']if x['name']==name);runtime=plan['runtime'][case['route']];environment=load(R/runtime['environment']['path']);image=Path(case['command'][0]);folder=B/'runs'/name
 folder.mkdir(parents=True,exist_ok=False);temporary=folder/'tmp';temporary.mkdir();env=dict(os.environ,PATH=(str(image.parent)+os.pathsep if case['route']=='mixed'else'')+environment['PATH'],TEMP=str(temporary),TMP=str(temporary))
 save(folder/'command.json',dict(case=case,plan=identity(PLAN),image=runtime['image'],HTTP=0,SDK_builds=0,performance_claim=False));started=time.time()
 with(folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
  try:
   process=subprocess.run(case['command'],cwd=R,env=env,stdout=out,stderr=err,timeout=plan['timeout_seconds'],creationflags=subprocess.CREATE_NO_WINDOW)
  except subprocess.TimeoutExpired:
   save(folder/'process.json',dict(timeout=True,seconds=time.time()-started));raise
 save(folder/'process.json',dict(exit=process.returncode,seconds=time.time()-started));
 if process.returncode:raise RuntimeError('Actual native failure retained; no automatic retry')
 reports=[json.loads(line)for line in(folder/'stdout.log').read_text(encoding='utf8').splitlines()if line.startswith('{')];report=reports[-1]
 if report['backend']!=('cpu'if case['route']=='cpu'else'cuda')or report['mtp']!=case['mtp']:raise ValueError('Actual native route differs')
 if report['cache_requested_byte_limit']!=2147483648 or report['cache_peak_requested_bytes']>2147483648:raise ValueError('Native finite session-cache budget differs')
 if report['original_host_weight_bytes']!=case['expected_host_weight_bytes']or report['original_host_weight_bytes']+report['original_device_weight_bytes']!=case['expected_loaded_bytes']:raise ValueError('Actual original weight placement differs')
 ids=report['generated_ids']
 if not 0<len(ids)<=4 or any(not 0<=x<plan['geometry']['vocabulary']for x in ids):raise ValueError('Invalid generated output domain')
 result=dict(case=name,native_exit=0,generated_ids=ids,source_id=report['source_id'],loaded_bytes=case['expected_loaded_bytes'],cache_peak_requested_bytes=report['cache_peak_requested_bytes'],score_policy=report['score_policy'],performance_claim=False,HTTP=0,SDK_builds=0)
 save(folder/'functional-result.json',result);print(json.dumps(result))
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('action',choices=['plan','check','run']);a.add_argument('--case',choices=['cpu-ordinary','cpu-k1','mixed-ordinary','mixed-k1']);args=a.parse_args()
 if args.action=='plan':prepare_plan();return
 plan=checked_plan()
 if args.action=='check':print(json.dumps(dict(ready=ready(plan),cases=plan['cases'],mixed_placement=plan['mixed_placement'],HTTP=0,models_started=0),indent=2));return
 if args.case is None:a.error('run requires exactly one explicit --case')
 run(plan,args.case)
if __name__=='__main__':main()
