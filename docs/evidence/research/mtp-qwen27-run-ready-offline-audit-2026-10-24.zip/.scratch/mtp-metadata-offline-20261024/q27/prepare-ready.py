"""Offline normalization into the product's existing GGUF range-input format.

Never uses a partial payload, downloads data, or constructs a whole GGUF copy.
"""
from pathlib import Path
import argparse, hashlib, json, sys
sys.dont_write_bytecode = True
R = Path.cwd()
sys.path.insert(0, str(R))
from engine.models.qwen35 import gguf_roles
B = R / '.scratch/mtp-metadata-offline-20261024/q27'
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as output:
        output.write(json.dumps(value, indent=2)+'\n')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('action', choices=['check', 'prepare'])
args = parser.parse_args()
plan = load(B / 'payload-plan.json')
raw = B / 'payload-role-files.json'
if not raw.exists():
    print(json.dumps(dict(ready=False, HTTP=0, reason='Authenticated complete original role bindings are not published yet.')))
    sys.exit(0 if args.action == 'check' else 2)
original = load(raw)
assert original['complete'] is True and original['source']['full_file_sha256_verified'] is True
assert original['source']['lfs_sha256'] == plan['source']['lfs_sha256']
assert (original['repository'],original['revision']) == (plan['repository'],plan['revision'])
assert len(original['roles']) == 866 and original['source_bytes'] == 16453443584
receipt = load(B / ('pieces/payload-acquisition-complete.json'
                    if (B / 'ADOPTED.q27-four-pieces.json').exists()
                    else 'payload-acquisition.json'))
assert receipt['complete'] is True and receipt['full_file_lfs_sha256'] == plan['source']['lfs_sha256']
if args.action == 'check':
    print(json.dumps(dict(ready=True, original_roles=866, HTTP=0)))
    sys.exit(0)
prefix = plan['raw_header_prefix']
prefix_path = R / prefix['path']
assert prefix_path.stat().st_size == prefix['cache_bytes']
assert hashlib.sha256(prefix_path.read_bytes()).hexdigest() == prefix['cache_sha256']
with prefix_path.open('rb') as stream: header = stream.read(prefix['used_bytes'])
assert len(header) == prefix['used_bytes']
# The general local-header reader intentionally drops tokenizer metadata.
# Keep only this scalar from the authenticated header; no tokenizer arrays.
from engine.models.qwen35.gguf_header import parse_header
metadata, _, _ = parse_header(header, 866, len(header),
    retained_metadata={'tokenizer.ggml.bos_token_id'}, whole_file_bytes=original['source']['size'])
bos = metadata['tokenizer.ggml.bos_token_id']
assert type(bos) is int and bos >= 0
header_path = B / 'complete-original-header.bin'
if header_path.exists(): assert header_path.read_bytes() == header
else:
    with header_path.open('xb') as stream: stream.write(header)
header_identity = ident(header_path)
source = dict(original['source'], repository=plan['repository'], revision=plan['revision'],
              uri=plan['uri'], header_bytes=len(header), header_sha256=header_identity['sha256'])
normalized = B / 'complete-original-role-files.json'
normalized_record = dict(signature=gguf_roles.PAYLOAD_SIGNATURE, complete=True, source=source,
                         header=header_identity, roles=original['roles'])
if normalized.exists(): assert load(normalized) == normalized_record
else: save(normalized, normalized_record)
# The unchanged product preparer verifies all actual role extents and hashes.
lines, prepared = gguf_roles.prepare_role_files(normalized, True)
assert prepared['physical_roles'] == 866 and prepared['selected_weight_bytes'] == 16453443584
assert bos < prepared['geometry']['vocabulary']
folder = B / 'complete-v2'
folder.mkdir(exist_ok=False)
with (folder / 'weights.tsv').open('x', encoding='utf-8', newline='\n') as output:
    output.write('\n'.join(lines)+'\n')
# A single declared original BOS is a finite execution fixture, not a text task.
(folder / 'prompt.ids').write_text(str(bos)+'\n', encoding='utf-8')
prepared.update(original_acquisition=ident(raw), normalized_source=ident(normalized),
    original_header=header_identity, prompt_scope='One original declared BOS for bounded ordinary/MTP execution; no task-quality claim.',
    copied_weight_bytes=0, copied_header_bytes=len(header), HTTP=0,
    product_scripts=[ident(R / 'engine/models/qwen35' / p) for p in ['gguf_roles.py','gguf_header.py','geometry.py']])
save(folder / 'input.json', prepared)
print(json.dumps(dict(ready=True, prepared=True, original_roles=866, copied_weight_bytes=0, HTTP=0)))
