"""Bounded read-only source/header audit: no payload reads, HTTP, builds or runs."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(R))
from engine.models.qwen35.gguf_header import parse_header, read_local_header
from engine.models.qwen35.gguf_roles import typed_inventory

B = Path(__file__).resolve().parent
def load(p):
    return json.loads(p.read_text(encoding='utf-8'))
def ident(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

plan = load(B / 'pieces/plan.json')
run = load(B / 'run-ready-plan.json')
source = dict(plan['source'], repository=plan['repository'], revision=plan['revision'])
header, raw = read_local_header(R / plan['raw_header_prefix']['path'], whole_file_bytes=source['size'])
inventory = typed_inventory(header, source, header_sha256=hashlib.sha256(raw).hexdigest())
assert inventory['geometry'] == run['geometry']
assert inventory['physical_role_count'] == 866
assert len(plan['roles']) == 866
assert sum(x['bytes'] for x in plan['roles']) == 16453443584
host_names = set()
for role in inventory['roles']:
    name = role['logical_name']
    prefix = 'model.language_model.layers.'
    if not name.startswith(prefix):
        continue
    index, suffix = name[len(prefix):].split('.', 1)
    if int(index) < 64 and (suffix.startswith('mlp.') or suffix == 'post_attention_layernorm.weight'):
        host_names.add(role['physical_name'])
host_bytes = sum(x['bytes'] for x in plan['roles'] if x['physical_name'] in host_names)
assert len(host_names) == 256 and host_bytes == 9863290880
metadata, tensors, metadata_count = parse_header(raw, 866, len(raw),
    retained_metadata={'tokenizer.ggml.bos_token_id', 'tokenizer.ggml.eos_token_id'},
    whole_file_bytes=source['size'])
assert metadata['tokenizer.ggml.bos_token_id'] == 248044
assert metadata['tokenizer.ggml.eos_token_id'] == 248046
assert 'tokenizer.ggml.bos_token_id' not in header['metadata']
g = run['geometry']
recurrent = 48 * (3 * 10240 * 2 + 48 * 128 * 128 * 4)
bank = (3 * 16) * (4 * 256 * 2) + 1
activation = 64 * (16 * 17408 + 32 * 5120) + 2 * 248320
budgets = {}
for mtp, rows in ((False, 1), (True, 2)):
    cache = (16 + mtp) * 2 * bank + recurrent * (2 + mtp) + 2 * 48 + ((4 * 5120 * 2 + 1) if mtp else 0)
    budgets['k1' if mtp else 'ordinary'] = dict(cache_known_backing_bytes=cache,
        per_invocation_known_workspace_cap_bytes=64 * 1024**2 + 4 * rows * activation,
        mixed_staging_cap_bytes=64 * 1024**2 + rows * (5120 * 8) * 64)
result = dict(kind='Q27 bounded offline run-ready source audit', HTTP=0, builds=0, model_runs=0,
    status='offline_audit_complete_two_concrete_pre_run_issues_identified',
    header=ident(R / plan['raw_header_prefix']['path']), parsed_structural_bytes=len(raw),
    roles=866, selected_payload_bytes=16453443584,
    codecs=load(B / 'feasibility.json')['codecs'], geometry=inventory['geometry'],
    mixed=dict(cpu_target_ffn_layers=64, host_roles=len(host_names), host_weight_bytes=host_bytes,
        device_weight_bytes=16453443584-host_bytes, ordinary_device_weight_bytes=16102434816-host_bytes),
    budgets=budgets,
    issues=[dict(kind='scratch_preparation_bos_keyerror',
        status='resolved_in_current_scratch_preparer',
        location='prepare-ready.py:69-71',
        fact='read_local_header omits tokenizer.* by default; the requested BOS key does not exist.',
        fix='Current scratch preparer uses parse_header over authenticated exact original raw header with explicit retained_metadata for only BOS; validates type/range before creating complete-v2.'),
      dict(kind='old_mixed_image_constructor_unwind_order',
        status='old_frozen_image_is_historical_new_current_source_image_supplied_by_parent',
        source='.scratch/qwen-multi-draft-20261024/geometry-cuda-check2/source/engine/models/qwen35/main.cc',
        fact='Frozen resources_ precedes Backend execution; ctor exception destroys Backend before allocated payloads. Current product and pure CPU source are fixed.',
        action='Parent supplied a fresh current-source CUDA consumer and new explicit runtime pins; immutable old image/plan remains historical.')],
    nonblocking_notes=['Old frozen prepare_family reserves 76+38*(prefix_rows-1) state ports per request; actual Q27 needs 196+98*(prefix_rows-1). This is vector reserve/overflow precheck only; dynamic pushes remain valid for the bounded N1 journey.',
        'Runner checks actual original weight bytes and cache limit, valid output domain, exit and route; it does not certify task quality or all per-layer numerics.'],
    limits=['No body hashes or model runs in this audit; source finalization and complete V2 preparation remain required.',
        'Workspace caps are per-invocation known workspace admission, shared execution budget is tracking, native CPU-private allocation size remains unknown.',
        'Original device role bytes are not a physical VRAM peak/cap; actual graph compilation and native allocation may still fail honestly.',
        '64 target FFNs on CPU is one explicit route. It does not certify arbitrary mixed placement or every backend/model configuration.'])
(B / 'audit-ready-offline.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, indent=2))
