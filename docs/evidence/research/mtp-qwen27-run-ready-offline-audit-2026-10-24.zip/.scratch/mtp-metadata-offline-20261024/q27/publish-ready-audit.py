"""Publish only source/metadata audit evidence, never weights or native images."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys
import time
import zipfile

R = Path(__file__).resolve().parents[3]
B = Path(__file__).resolve().parent
N = R / '.scratch/qwen-multi-draft-20261024/geometry-cuda-current1'
OLD = R / '.scratch/qwen-multi-draft-20261024/geometry-cuda-check2/source/engine/models/qwen35/main.cc'
CPU = R / '.scratch/qwen-pure-cpu-deployment-20261024/source/engine/models/qwen35/main.cc'
OUT = R / 'docs/evidence/research/mtp-qwen27-run-ready-offline-audit-2026-10-24'

def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def ident(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

check = B / 'offline-audit-check1'
command = [sys.executable, '-B', str(B / 'audit-ready-offline.py')]
if not check.exists():
    check.mkdir()
    save(check / 'command.json', dict(command=command, cwd=str(R), HTTP=0, models_started=0))
    start = time.monotonic()
    process = subprocess.run(command, cwd=R, capture_output=True)
    (check / 'stdout.log').write_bytes(process.stdout)
    (check / 'stderr.log').write_bytes(process.stderr)
    save(check / 'process.json', dict(exit=process.returncode, seconds=time.monotonic()-start))
if load(check / 'process.json')['exit']:
    raise RuntimeError('Offline audit failed; no evidence published')
audit = load(B / 'audit-ready-offline.json')
descriptor = load(N / 'current-image.json')
new_main = R / descriptor['main']['path']
assert ident(new_main) == descriptor['main']
assert descriptor['construction_unwind_order'] == dict(execution_declared_before_resources=True,
    execution_initialized_before_resources=True)
old_plan = load(B / 'run-ready-plan.json')
new_plan_path = R / '.scratch/qwen-multi-draft-20261024/current-image-plans/Q27.json'
new_plan = load(new_plan_path)
assert old_plan['geometry'] == new_plan['geometry']
assert old_plan['runtime']['cpu'] == new_plan['runtime']['cpu']
assert new_plan['runtime']['mixed'] == descriptor['runtime']
assert len(old_plan['cases']) == len(new_plan['cases']) == 4
for old, new in zip(old_plan['cases'], new_plan['cases']):
    assert {k:v for k,v in old.items() if k != 'command'} == {k:v for k,v in new.items() if k != 'command'}
    assert old['command'][1:] == new['command'][1:]
    if old['route'] == 'cpu':
        assert old['command'] == new['command']
assert "retained_metadata={'tokenizer.ggml.bos_token_id'}" in (B / 'prepare-ready.py').read_text()
assert (B / 'prepare-ready.py').read_text().index("assert bos < prepared['geometry']['vocabulary']") < (B / 'prepare-ready.py').read_text().index("folder.mkdir(exist_ok=False)")
(check / 'old-to-current-main.diff').write_text(''.join(difflib.unified_diff(
    OLD.read_text().splitlines(keepends=True), new_main.read_text().splitlines(keepends=True),
    fromfile=OLD.relative_to(R).as_posix(), tofile=new_main.relative_to(R).as_posix())), encoding='utf-8')
records = [Path(__file__).resolve(), B / 'audit-ready-offline.py', B / 'audit-ready-offline.json',
    B / 'prepare-ready.py', B / 'run-ready.py', B / 'run-ready-plan.json', B / 'pieces/plan.json',
    B / 'payload-plan.json', B / 'feasibility.json', B / 'file-identity.json',
    N / 'current-image.json', N / 'future-plan-audit.json', N / 'sources.json', N / 'shared-object-dependencies.json',
    N / 'compile-command.json', N / 'compile-process.json', N / 'compile.log',
    N / 'link-command.json', N / 'link-process.json', N / 'link.log', N / 'q27-check.json', N / 'q27-plan.json',
    new_plan_path, R / '.scratch/qwen-multi-draft-20261024/current-cuda-ready.py',
    R / '.scratch/qwen-pure-cpu-deployment-20261024/source-identities.json',
    R / '.scratch/qwen-pure-cpu-deployment-20261024/runtime-environment.json', OLD, CPU,
    R / 'engine/models/qwen35/gguf_header.py', R / 'engine/models/qwen35/gguf_roles.py', R / 'engine/models/qwen35/geometry.py']
records += list(check.glob('*'))
records += [p for p in (N / 'source').rglob('*') if p.is_file()]
records = sorted(set(records))
assert all(p.suffix not in ('.bin', '.obj', '.exe', '.dll', '.lib', '.pdb', '.gguf', '.safetensors') for p in records)
archive = OUT.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in records:
        z.write(p, p.relative_to(R))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
summary = dict(date='2026-10-24',
    status='OFFLINE AUDIT COMPLETE; both identified pre-run blockers corrected; complete Q27 model execution remains pending',
    scope='Actual original-header inventory, source geometry, finite role placement, cache/workspace arithmetic and explicit CPU/mixed image handoff. No Q27 inference, payload reading, SDK build or download in this audit.',
    HTTP=0, models_started=0, new_SDK_TUs=0,
    audit=audit,
    fixes=[dict(issue='scratch BOS scalar lookup was discarded by default header reader', status='resolved',
        source=ident(B / 'prepare-ready.py'),
        independent_reproduction='Same authenticated original exact header omits BOS by default, explicit scalar retention returns248044; EOS scalar248046. No tokenizer array retained.',
        boundary='No complete inputs are published before all866 original ranges and full original LFS are authenticated. This audit did not invoke prepare.'),
      dict(issue='old mixed frozen constructor unwind would destroy Backend before loaded resources', status='resolved_by_new_explicit_current_image',
        old_main=ident(OLD), pure_CPU_main=ident(CPU), new_main=ident(new_main),
        current_image=descriptor['runtime']['image'],
        construction_unwind_order=descriptor['construction_unwind_order'],
        compiler_result=load(N / 'compile-process.json'), linker_result=load(N / 'link-process.json'),
        qualification='The producer compiled one application TU against retained SDK objects. This audit only checks source/metadata. Old plan/image and completed CT evidence remain immutable; no Q27 runtime claim.')],
    new_explicit_plan=ident(new_plan_path),
    unchanged_CPU_plan_and_case_arguments=True,
    source_hashes=[ident(p) for p in records if p.suffix in ('.cc','.h','.py')],
    inherited_evidence=['docs/evidence/correctness/mtp-qwen-source-geometry-v2-preparation-2026-10-24.json',
        'docs/evidence/correctness/mtp-qwen35-pure-cpu-deployment-2026-10-24.json'],
    archive=ident(archive), archive_records=len(records))
save(OUT.with_suffix('.json'), summary)
print(json.dumps(dict(evidence=OUT.with_suffix('.json').relative_to(R).as_posix(), archive=ident(archive), records=len(records)), indent=2))
