"""Explicit current-image Q8/Q27 plans and one bounded original-weight case.

Plan/check never prepare, build, download or start a model. Only run --case
starts exactly one case after the original source validator reports ready.
Old plans, frozen images and completed CT evidence remain unchanged.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
R = B.parents[1]
DESCRIPTOR = B / 'geometry-cuda-current1/current-image.json'
PROFILES = {
    'Q8': dict(
        old_plan=R / '.scratch/qwen35-unsloth-mtp-20261024/original-run-plans/Q8.json',
        validator=R / '.scratch/qwen35-unsloth-mtp-20261024/run-original-ready.py',
        inputs=R / '.scratch/qwen35-unsloth-mtp-20261024/complete-v2/Q8',
        outputs=R / '.scratch/qwen35-unsloth-mtp-20261024/complete-v2/Q8/current-image-runs',
        gpu_route='cuda'),
    'Q27': dict(
        old_plan=R / '.scratch/mtp-metadata-offline-20261024/q27/run-ready-plan.json',
        validator=R / '.scratch/mtp-metadata-offline-20261024/q27/run-ready.py',
        inputs=R / '.scratch/mtp-metadata-offline-20261024/q27/complete-v2',
        outputs=R / '.scratch/mtp-metadata-offline-20261024/q27/runs-current-image',
        gpu_route='mixed'),
}


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def identity(path):
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def pin(record):
    if identity(R / record['path']) != record:
        raise ValueError('Pinned input/runtime changed: ' + record['path'])


def plan_path(profile):
    return B / 'current-image-plans' / (profile + '.json')


def make_plan(profile):
    settings = PROFILES[profile]
    old = load(settings['old_plan'])
    descriptor = load(DESCRIPTOR)
    plan = copy.deepcopy(old)
    route = settings['gpu_route']
    plan['runtime'][route] = copy.deepcopy(descriptor['runtime'])
    for case in plan['cases']:
        if case.get('backend', case.get('route')) == route:
            case['command'][0] = str(R / descriptor['runtime']['image']['path'])
    plan.update(
        runner=identity(Path(__file__).resolve()),
        profile=profile,
        parent_plan=identity(settings['old_plan']),
        source_validator=identity(settings['validator']),
        current_image=identity(DESCRIPTOR),
        output_root=settings['outputs'].relative_to(R).as_posix(),
        image_change='New CUDA/mixed application image fixes constructor-unwind resource order; retained source acquisition, preparation and case geometry are unchanged.',
        qualification=descriptor['qualification'],
        scope='One explicitly selected original-weight functional case; no automatic matrix, preparation, retry, HTTP, SDK build or performance claim.',
        HTTP=0, SDK_builds=0, automatic_retry=False, performance_claim=False)
    save_new(plan_path(profile), plan)
    return plan


def checked_plan(profile):
    plan = load(plan_path(profile))
    for key in ['runner', 'parent_plan', 'source_validator', 'current_image']:
        pin(plan[key])
    for key in ['inventory', 'prompt', 'explicit_preparer', 'acquisition_plan']:
        if key in plan:
            pin(plan[key])
    for runtime in plan['runtime'].values():
        for record in runtime.values():
            pin(record)
    descriptor = load(R / plan['current_image']['path'])
    if plan['runtime'][PROFILES[profile]['gpu_route']] != descriptor['runtime']:
        raise ValueError('Current CUDA/mixed runtime is not the explicit image descriptor')
    return plan


def source_ready(profile, plan):
    spec = importlib.util.spec_from_file_location('original_source_validator', R / plan['source_validator']['path'])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.prepared_ready(plan) if profile == 'Q8' else module.ready(plan)


def run_case(profile, plan, name):
    if not source_ready(profile, plan):
        raise RuntimeError('Authenticated complete original roles and explicit prepared inputs are required; no model started')
    case = next((item for item in plan['cases'] if item['name'] == name), None)
    if case is None:
        raise ValueError('Unknown case: ' + name)
    route = case.get('backend', case.get('route'))
    runtime = plan['runtime'][route]
    image = R / runtime['image']['path']
    if case['command'][0] != str(image):
        raise ValueError('Case executable differs from its pinned runtime')
    folder = R / plan['output_root'] / name
    folder.mkdir(parents=True, exist_ok=False)
    temporary = folder / 'tmp'
    temporary.mkdir()
    record = load(R / runtime['environment']['path'])
    environment = dict(os.environ, PATH=(str(image.parent) + os.pathsep if route != 'cpu' else '') + record['PATH'], TEMP=str(temporary), TMP=str(temporary))
    inputs = PROFILES[profile]['inputs']
    save_new(folder / 'command.json', dict(case=case, plan=identity(plan_path(profile)), image=runtime['image'], manifest=identity(inputs / 'weights.tsv'), HTTP=0, SDK_builds=0, performance_claim=False))
    started = time.time()
    with (folder / 'stdout.log').open('xb') as stdout, (folder / 'stderr.log').open('xb') as stderr:
        try:
            process = subprocess.run(case['command'], cwd=R, env=environment, stdout=stdout, stderr=stderr, timeout=plan['timeout_seconds'], creationflags=subprocess.CREATE_NO_WINDOW)
        except subprocess.TimeoutExpired:
            save_new(folder / 'process.json', dict(timeout=True, seconds=time.time() - started))
            raise
    save_new(folder / 'process.json', dict(exit=process.returncode, seconds=time.time() - started))
    if process.returncode:
        raise RuntimeError('Actual native failure retained; no automatic retry/fallback')
    reports = [json.loads(line) for line in (folder / 'stdout.log').read_text(encoding='utf8').splitlines() if line.startswith('{')]
    report = reports[-1]
    prepared = load(inputs / 'input.json')
    expected_backend = 'cpu' if route == 'cpu' else 'cuda'
    random = case.get('random', False)
    if (report['source_id'], report['backend'], report['mtp']) != (prepared['source_id'], expected_backend, case['mtp']):
        raise ValueError('Actual native source/backend/MTP differs')
    if report['sampling'] != ('random' if random else 'greedy') or (random and report['mtp_max_drafts'] != 4):
        raise ValueError('Actual sampling policy differs')
    cap = plan['cache_limit_bytes']
    if report['cache_requested_byte_limit'] != cap or report['cache_peak_requested_bytes'] > cap:
        raise ValueError('Actual finite cache budget differs')
    host, device = report['original_host_weight_bytes'], report['original_device_weight_bytes']
    expected_bytes = case.get('selected_original_bytes', case.get('expected_loaded_bytes'))
    expected_host = case.get('expected_host_weight_bytes', expected_bytes if route == 'cpu' else 0)
    if host + device != expected_bytes or host != expected_host:
        raise ValueError('Actual original role-byte placement differs')
    maximum = case.get('maximum_outputs', plan.get('maximum_outputs'))
    vocabulary = plan['geometry']['vocabulary'] if profile == 'Q27' else 248320
    ids = report['generated_ids']
    if not 0 < len(ids) <= maximum or len(ids) != report['generated_tokens'] or any(not 0 <= value < vocabulary for value in ids):
        raise ValueError('Generated output count/domain differs')
    result = dict(profile=profile, case=name, native_exit=0, source_id=report['source_id'], generated_ids=ids, score_policy=report['score_policy'], host_weight_bytes=host, device_weight_bytes=device, cache_peak_requested_bytes=report['cache_peak_requested_bytes'], image=runtime['image'], HTTP=0, SDK_builds=0, performance_claim=False)
    save_new(folder / 'functional-result.json', result)
    print(json.dumps(result))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('profile', choices=PROFILES)
    parser.add_argument('action', choices=['plan', 'check', 'run'])
    parser.add_argument('--case')
    args = parser.parse_args()
    if args.action == 'plan':
        plan = make_plan(args.profile)
        print(json.dumps(dict(plan=identity(plan_path(args.profile)), cases=[c['name'] for c in plan['cases']], models_started=0, HTTP=0)))
        return
    plan = checked_plan(args.profile)
    if args.action == 'check':
        print(json.dumps(dict(profile=args.profile, ready=source_ready(args.profile, plan), cases=[c['name'] for c in plan['cases']], current_image=plan['runtime'][PROFILES[args.profile]['gpu_route']]['image'], models_started=0, HTTP=0)))
        return
    if args.case is None:
        parser.error('run requires one explicit --case')
    run_case(args.profile, plan, args.case)


if __name__ == '__main__':
    main()
