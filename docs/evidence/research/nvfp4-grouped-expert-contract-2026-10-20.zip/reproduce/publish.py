"""Publish the bounded grouped-NVFP4 source/header research and verify members."""
import hashlib, json, pathlib, struct, zipfile

HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
OUT=REPO/'docs/evidence/research'
BASE='nvfp4-grouped-expert-contract-2026-10-20'
SOURCE=HERE.parent/'next-quant-functional-review'

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def blob_id(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def identity(p):return {'path':str(p),**blob_id(p.read_bytes())}
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

facts=read(HERE/'q24-header-facts.json')
design=read(HERE/'design-review.json')
producer_pin=read(SOURCE/'modelopt-producer-commit.json')['sha']
assert producer_pin=='82f1d216d1a9022e60b8e1143a77f36c00b885a4'
old_http=read(SOURCE/'http-receipt.json')
names=['nvfp4_tensor.py','fp4_kernel_hopper.py']
producer=[]
for name in names:
    p=SOURCE/'modelopt'/name
    receipt=next(r for r in old_http if r.get('file','').replace('\\','/')=='modelopt/'+name)
    assert blob_id(p.read_bytes())=={k:receipt[k] for k in ['bytes','sha256']}
    producer.append({'file':name,'source':identity(p),'cached_http_receipt':receipt})
save(HERE/'producer-provenance.json',{
    'repository':'NVIDIA/Model-Optimizer','revision':producer_pin,'files':producer,
    'source_pin_receipt':identity(SOURCE/'modelopt-producer-commit.json'),
    'meaning':'Existing Nvfp4Linear software-reference source, not a proven Q24 runtime or producer revision. These sources were already cached; no new producer requests in this task.'})

payload={}
def add(name,path):
    assert name not in payload and not pathlib.PurePosixPath(name).is_absolute()
    payload[name]=path.read_bytes()

range_count=0
for i in [1,2,3]:
    folder=HERE/'headers'/f'model-{i:05d}-of-00200.safetensors'
    length=struct.unpack('<Q',(folder/'length.bin').read_bytes())[0]
    assert len((folder/'header.json').read_bytes())==length
    receipts=read(folder/'http-receipts.json');assert len(receipts)==2
    for r,(start,end,file) in zip(receipts,[(0,7,'length.bin'),(8,length+7,'header.json')]):
        assert r['status']==206
        headers={k.lower():v for k,v in r['response_headers'].items()}
        assert headers['content-range'].startswith(f'bytes {start}-{end}/')
        assert r['request_headers']['Range']==f'bytes={start}-{end}'
        assert '/74eb734297318ecf7c48016a4ac8ce1b47cc74a9/' in r['request_url']
        assert blob_id((folder/file).read_bytes())=={k:r['body'][k] for k in ['bytes','sha256']}
        range_count+=1
    for file in ['header.json','length.bin','http-receipts.json']:
        add('headers/'+folder.name+'/'+file,folder/file)
for name in ['header-summary.json','q24-header-facts.json','design-review.json','producer-provenance.json']:
    add(name,HERE/name)
for name in names:add('producer/'+name,SOURCE/'modelopt'/name)
for name in ['fetch_headers.py','publish.py']:add('reproduce/'+name,HERE/name)
assert range_count==6
manifest=[{'entry':name,**blob_id(data)} for name,data in sorted(payload.items())]
payload['manifest.json']=(json.dumps({'members':manifest},indent=2)+'\n').encode()

OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/(BASE+'.zip');report=OUT/(BASE+'.json')
assert not archive.exists() and not report.exists(),'Do not overwrite a prior publication silently'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()):z.writestr(name,data)
verified=[]
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(payload)
    for name in sorted(z.namelist()):
        actual=z.read(name);assert actual==payload[name]
        verified.append({'entry':name,**blob_id(actual)})
    stored=json.loads(z.read('manifest.json'))
    assert stored['members']==manifest

summary={
 'status':'research_only_proposed_grouped_software_reference_not_implemented',
 'scope':'Exact bounded Q24 shard-header observations and one minimal public GroupedNvfp4Linear proposal. No whole artifact support or native FP4 GEMM numerical equivalence.',
 'artifact':{'catalog_index':17,'repository':facts['repository'],'revision':facts['revision'],
             'primary_url':'https://huggingface.co/nvidia/Qwen3.8-2.4T-A95B-NVFP4/tree/74eb734297318ecf7c48016a4ac8ce1b47cc74a9'},
 'observed':{'layers':92,'layer_range':[0,91],'expert_ids':list(range(8)),
             'projection_roles':['gate_proj','up_proj','down_proj'],'complete_four_tensor_role_sets':2208,
             'artifact_config_experts':512,'artifact_config_topk':10,
             'gate_up':{'W':'U8[2048,4096]','SF':'F8_E4M3[2048,512]'},
             'down':{'W':'U8[8192,1024]','SF':'F8_E4M3[8192,128]'},
             'globals':'Separately named F32[1] input_scale and weight_scale_2 per sampled expert/projection; no values read. Independent names do not prove different or equal values.'},
 'requests':{'exact_http_206_ranges':6,'json_header_bytes':1041976,'length_prefix_bytes':24,
             'tensor_payload_bytes':0,'full_headers_only':3,'network_scope':'First3 of200 fixed-revision shard headers, not all512 expert headers.'},
 'minimal_proposal':{'operation':'GroupedNvfp4Linear / grouped_nvfp4_linear()',
     'ports':design['public_contract']['ports_in_order'],'output':'BF16[T,S,N]',
     'geometry':'Positive T,S,E,N,K; K%16=0; A_slots=1 orS; dense or proven real zero-slot-stride A; checked I32 IDs including valid duplicates.',
     'math':'Exactly extend current Nvfp4Linear group16 software-reference QDQ and scale-first weight BF16 operand boundaries; F32 backend dot then BF16 output.',
     'critical_sharing_limit':'Selected IG[e] changes current activation QDQ. Sharing raw A does not justify one T*K quantized tensor across experts or gate/up projections. Minimal actual scratch is BF16[T,S,K], with no raw-A expansion or dense E*N*K decoded bank.',
     'reuse':'Current NativePlan/parallel routes, native CUDA Queue/status/capture, Apple integer Metal/checked status, and Vulkan phased shader/status paths. Add exact custom schema and SF carrier wiring; no new executor, model whitelist or producer-generalization mode.'},
 'current_gaps':['No public six-port grouped ModelOpt NVFP4 reference operation or checked selected-expert IG/WG routing yet.',
     'GroupedFloat4Linear uses a different group32-weight/group128-FP8-activation math; GroupedMatMul uses F32 activation/output and is not an equivalent numerical fallback.',
     'Backend grouped QDQ, selected IDs validation, real activation strides, checked workspace and narrow E4M3 SF admission still require implementation.'],
 'whole_bank_limit':{'example':'E512 gate packed W[512,2048,4096] =4294967296 U8 bytes =4GiB.',
     'confirmed_current_vulkan':'vulkan_program.cc plain U8 element_count>INT32_MAX is rejected; existing nvfp4 lowering also requires byte capacity<=UINT32_MAX and device maxStorageBufferRange.',
     'apple_boundary':'Current input_spec checks per-axis int bounds; this review does not prove an Apple4GiB total-bank rejection.',
     'consequence':'Small operator/regression coverage cannot certify the Q24 full model or bank. No new multi-buffer carrier is designed in this proposal.'},
 'source_math_pin':{'repository':'NVIDIA/Model-Optimizer','revision':producer_pin,
     'claim_limit':'Reference for existing Hyle software contract; not the Q24 actual runtime/producer revision or hardware-native W4A4 contract.'},
 'validation':{'build':0,'tests':0,'gpu':0,'model_runs':0,'product_edits':0,
     'archive_crc':'all_members_passed','archive_member_sha256':'all_members_rechecked',
     'archive_members':len(verified)},
 'evidence':{'facts_entry':'q24-header-facts.json','design_entry':'design-review.json',
     'facts':identity(HERE/'q24-header-facts.json'),'design':identity(HERE/'design-review.json'),
     'archive':{'path':archive.relative_to(REPO).as_posix(),**blob_id(archive.read_bytes())},
     'members':verified},
 'limits':['Only sampled header dtype/shape/offset metadata was read; no nibble payload, scale values, positivity, equality, quality or deployment numerics were verified.',
     'Q24 producer/runtime pin and hardware scaled-FP4 GEMM equivalence remain unknown.',
     'This record proposes a mathematical operation; it does not change the model table or mark the artifact supported.']}
save(report,summary)
receipt={'report':identity(report),'archive':identity(archive),'members':len(verified),
         'all_crc_and_member_sha256_verified':True,'payload_bytes_uncompressed':sum(len(v) for v in payload.values()),
         'product_or_model_table_changes':False}
save(HERE/'publication-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
