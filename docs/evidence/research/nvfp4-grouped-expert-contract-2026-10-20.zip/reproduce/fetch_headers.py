"""Fixed-revision HF header-only ranges; no tensor payload download."""
import concurrent.futures, hashlib, json, pathlib, struct, time, urllib.request

STAGE=pathlib.Path(__file__).resolve().parent
REV='74eb734297318ecf7c48016a4ac8ce1b47cc74a9'
REPO='nvidia/Qwen3.8-2.4T-A95B-NVFP4'

def identity(p):
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}

def one(index):
    name=f'model-{index:05d}-of-00200.safetensors'
    out=STAGE/'headers'/name;out.mkdir(parents=True,exist_ok=True)
    receipts=[]
    def fetch(start,end,tag):
        url=f'https://huggingface.co/{REPO}/resolve/{REV}/{name}?download=true&hyle_header_range={start}-{end}'
        req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}',
            'Accept-Encoding':'identity','User-Agent':'hyle-source-contract-review/1'})
        before=time.time()
        with urllib.request.urlopen(req,timeout=45) as r:
            headers=dict(r.headers)
            receipt={'request_url':url,'request_headers':dict(req.header_items()),
                     'status':r.status,'response_headers':headers,'seconds':time.time()-before}
            receipts.append(receipt)
            (out/'http-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
            assert r.status==206,(r.status,headers)
            assert r.headers.get('Content-Range','').startswith(f'bytes {start}-{end}/'),headers
            data=r.read(end-start+2)
            assert len(data)==end-start+1,len(data)
        p=out/tag;p.write_bytes(data);receipt['body']=identity(p)
        (out/'http-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
        return data
    length=struct.unpack('<Q',fetch(0,7,'length.bin'))[0]
    assert 2<=length<=1_000_000,length
    data=fetch(8,7+length,'header.json')
    header=json.loads(data)
    roles={k:v for k,v in header.items() if k!='__metadata__' and '.mlp.experts' in k}
    report={'file':name,'header_bytes':length,'tensor_count':len(header)-('__metadata__' in header),
            'expert_tensor_count':len(roles),'header':identity(out/'header.json'),
            'http':identity(out/'http-receipts.json'),'tensor_payload_bytes_downloaded':0}
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='expert_headers'}),flush=True)
    return report

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    rows=list(pool.map(one,[1,2,3]))
(STAGE/'header-summary.json').write_text(json.dumps({'repository':REPO,'revision':REV,
    'shards':rows,'scope':'First three fixed-revision shard headers only; not all shards or any tensor values.',
    'tensor_payload_bytes_downloaded':0},indent=2)+'\n')
