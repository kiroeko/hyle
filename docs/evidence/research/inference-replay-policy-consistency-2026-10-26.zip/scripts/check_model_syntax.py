"""One current Model self TU strict syntax check, no link or GPU."""
from pathlib import Path
import importlib.util,json,sys

sys.dont_write_bytecode=True
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
spec=importlib.util.spec_from_file_location('existing_host_runner',ROOT/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def read(p):return json.loads(p.read_bytes())

def main():
    pins=read(WORK/'product-pins.json')
    for row in pins['files']:
        assert h.pin(ROOT/row['path'])['sha256']==row['after']['sha256']
    original=ROOT/'.scratch/inference-current-closure-20261026/engine/model/command.json'
    command=list(read(original)['command']);compiler=command[0]
    out=WORK/'syntax1';assert not out.exists()
    command=[arg for arg in command if not arg.startswith(('/Fo','/Fd'))]
    assert command.count('/c')==1
    command[command.index('/c')]='/Zs'
    command[command.index('/sourceDependencies')+1]=str(out/'dependencies.json')
    env=h.discover_environment(compiler='msvc',cache={
        'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    result=h.execute(command,env,out,timeout=120)
    data=read(out/'dependencies.json')['Data']
    assert Path(data['Source']).resolve()==(ROOT/'engine/models/qwen35/main.cc').resolve()
    actual=[h.pin(Path(p)) for p in dict.fromkeys([data['Source'],*data['Includes']])]
    selfdeps=[row for row in actual if Path(row['path']).resolve().is_relative_to(ROOT) and not Path(row['path']).resolve().is_relative_to(ROOT/'.scratch')]
    h.save(out/'actual-dependencies.json',actual)
    h.save(out/'actual-project-dependencies.json',selfdeps)
    assert next(row for row in selfdeps if Path(row['path']).resolve()==(ROOT/'engine/models/qwen35/main.cc').resolve())['sha256']==pins['files'][0]['after']['sha256']
    text=(ROOT/'engine/models/qwen35/main.cc').read_text()
    assert text.count('select_replay_mode(')==3
    assert 'program.replay_mode = select_replay_mode(replay_policy, 1, default_sampler.enabled);' in text
    # These original sampler boundaries are deliberately not routed by the CLI preference.
    for start,end in [('  PrefixSamplingResult sample_recursive_prefix(', '  cache::SnapshotRef sample_prefix('),
                      ('  cache::SnapshotRef sample_prefix(', '  const void *math_identity()')]:
        part=text[text.index(start):text.index(end,text.index(start))]
        assert '.mode = g::ReplayMode::kCommands' in part
    summary={'status':'PASS_ONE_FULL_CURRENT_MODEL_TU_STRICT_SYNTAX_NO_RUNTIME',
        'process':result,'original_recipe':h.pin(original),'actual_command':h.pin(out/'command.json'),
        'product_pins':h.pin(WORK/'product-pins.json'),'source':pins['files'][0]['after'],
        'actual_project_dependency_count':len(selfdeps),'actual_dependency_count':len(actual),
        'default_Auto':'Phase original expression moved verbatim into pure selector; Draft knownUses1 keeps Commands.',
        'explicit_prefer':'Cold DraftProgram selection reaches original Graph PreferCapture fallback. Not newly runtime-tested here.',
        'sampler':'Random-enabled Phase/Draft forced Commands; original acceptance/frontier Commands boundaries preserved.',
        'builds':{'Model_syntax_TUs':1,'link':0,'new_executable':0,'SDK_core_provider':0},
        'runs':{'CPU_Model':0,'GPU':0,'benchmark':0},
        'limits':'Configuration/source/syntax only. Closed K2 forced-auto pilot is not enabled by Auto, not reused as product performance evidence. No capture-count or throughput claim.'}
    h.save(WORK/'summary.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
