"""Publish only the completed source/syntax batch, never compile or execute."""
from pathlib import Path
import hashlib,json,re,zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
STEM='inference-replay-policy-consistency-2026-10-26'
DEST=ROOT/'docs/evidence/research'
def read(p):return json.loads(p.read_bytes())
def digest(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def pin(p):return {'path':str(p.resolve()),**digest(p.read_bytes())}
def save(p,obj):p.write_bytes((json.dumps(obj,indent=2)+'\n').encode())

def main():
    report_path=DEST/(STEM+'.json');archive_path=DEST/(STEM+'.zip')
    assert not report_path.exists() and not archive_path.exists()
    pins=read(WORK/'product-pins.json');s=read(WORK/'summary.json')
    assert s['status']=='PASS_ONE_FULL_CURRENT_MODEL_TU_STRICT_SYNTAX_NO_RUNTIME'
    assert s['process']['exit']==0 and s['builds']['Model_syntax_TUs']==1
    assert s['actual_project_dependency_count']==144 and s['actual_dependency_count']==338
    assert s['product_pins']==pin(WORK/'product-pins.json')
    for row in pins['files']:
        for side in ['before','after']:
            b=Path(row[side]['path']).read_bytes()
            assert digest(b)=={k:row[side][k] for k in ['bytes','sha256']}
            assert b'\r' not in b,'Original LF preserved'
    actual=read(WORK/'syntax1/actual-project-dependencies.json')
    assert len(actual)==144
    compiled=next(r for r in actual if Path(r['path']).resolve()==(ROOT/'engine/models/qwen35/main.cc').resolve())
    assert compiled['sha256']==pins['files'][0]['after']['sha256']
    report={'schema':'hyle-source-compile-evidence-v1','date':'2026-10-26',
        'status':'PASS_REPLAY_CONFIGURATION_CONSISTENCY_SOURCE_AND_ONE_MODEL_SYNTAX',
        'scope':'Existing main Phase and auxiliary NextN DraftProgram now share one pure cold replay selector. One full current Model implementation TU strict syntax check only; no link, executable, SDK build, CPU/GPU inference or benchmark.',
        'implementation':{'canonical_integrated':True,'product_paths':[r['path'] for r in pins['files']],
            'source_pins':pins,'helper':'qwen35::select_replay_mode(policy, known_uses, sampling_enabled)',
            'Phase':'Uses the original planned_slot_uses and selected sampler through the same unchanged logical condition.',
            'DraftProgram':'Stores a selected replay_mode once during prepare_draft_program; execute_draft passes the stored mode to the original Invocation::prepare_replay. No hot policy choice.',
            'no_new_layer':'No new header, policy inventory, owner, pool, scheduler, Graph IR or retirement path.',
            'LF_preserved':True},
        'mode_contract':{'commands':'Main Phase and auxiliary NextN use Commands.',
            'auto_main':'Preserves the original known-use condition: uses<=1 Commands, otherwise PreferCapture, except original sampler restriction.',
            'auto_auxiliary':'No reliable auxiliary-use hint is available. known_uses=1 deliberately keeps the original Commands path and does not enable the closed forced-Auto pilot.',
            'explicit_prefer':'The newly honored auxiliary preference reaches the original Graph PreferCapture fallback; unsupported regions may remain Commands. This new explicit-prefer path was syntax-checked, not runtime-tested in this batch.',
            'sampler':'Random-enabled main Phase and DraftProgram still force Commands even with explicit prefer. Existing recursive acceptance and complete-prefix/frontier resampling helpers remain Commands.',
            'not_capture_guarantee':'PreferCapture is an original Graph preference, not a guarantee of full capture or no re-recording.'},
        'actual_check':{'process':s['process'],'command':s['actual_command'],'original_recipe':s['original_recipe'],
            'compile_flags':'Retained current Model recipe /W4 /WX /O2 /MD with /c replaced by /Zs; same CPU+CUDA capability macros and cached external include paths.',
            'source':s['source'],'actual_project_dependencies':{
                'count':144,'pin':pin(WORK/'syntax1/actual-project-dependencies.json')},
            'actual_all_dependencies':{'count':338,'pin':pin(WORK/'syntax1/actual-dependencies.json')},
            'raw_dependencies':pin(WORK/'syntax1/dependencies.json'),
            'stdout':pin(WORK/'syntax1/stdout.log'),'stderr':pin(WORK/'syntax1/stderr.log'),
            'syntax_TUs':1,'link_processes':0,'new_binary':0,'SDK_core_provider_rebuilds':0,
            'CPU_Model_runs':0,'GPU_runs':0,'performance_runs':0,'first_failures':[]},
        'source_checks':['One selector definition and two cold call sites; no duplicated selection condition.',
            'Original Phase condition moved with only parameter-name substitution. Auto auxiliary constant1 resolves Commands.',
            'Sampler acceptance and frontier functions retain their original literal Commands boundary.',
            'Only main cold selector/enum field/cold assignment/replay argument plus README changed; no model equations, input/acceptance rules, RNG, resource permissions or retirement order changed.'],
        'documentation':'README now states main and auxiliary cold selection, missing auxiliary-use hint, sampler exceptions and Graph fallback. CLI flags and defaults are unchanged.',
        'reproduction':'Archive includes the narrow patch, exact before/after pins, preparation and syntax scripts, actual /W4 /WX /Zs command/raw output and all144 project/338 total dependency identities. Requires the original local compiler and header cache; no binary or SDK is archived.',
        'limits':['Default Auto is source-equivalent and deliberately preserves auxiliary Commands; no default capture optimization is enabled.',
            'Explicit prefer auxiliary behavior is new configuration wiring and has no new runtime, capture-count, numerical, memory or throughput certification here.',
            'The earlier closed K2 forced-Auto pilot remains a different private experiment; its behavior/performance records are not evidence for this product batch and no samples are included.',
            'A full Model implementation /Zs checks the modified call sites and types but produces no executable and proves no native capture success or backend fallback execution.',
            'Actual dependency pins describe this syntax TU, not a newly linked current engine closure or all-platform certification.']}
    members={};origins={}
    def add(name,path):
        assert name not in members and path.is_file()
        assert path.suffix.lower() not in {'.obj','.exe','.lib','.dll','.pdb','.bin','.safetensors','.gguf'}
        b=path.read_bytes()
        assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})',b),name
        members[name]=b;origins[name]=str(path.resolve())
    for name in ['product.patch','product-pins.json','scope.json','applied.json','summary.json']:
        add('source/'+name,WORK/name)
    for name in ['prepare.py','check_model_syntax.py','archive.py']:
        add('scripts/'+name,WORK/name)
    add('scripts/retained-host-runner.py',ROOT/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
    for name in ['command.json','running.json','process.json','stdout.log','stderr.log','dependencies.json',
                 'actual-dependencies.json','actual-project-dependencies.json']:
        add('syntax/'+name,WORK/'syntax1'/name)
    add('reference/original-model-command.json',Path(s['original_recipe']['path']))
    members['report.json']=(json.dumps(report,indent=2)+'\n').encode()
    manifest={'members':{n:{**digest(b),**({'origin':origins[n]} if n in origins else {})} for n,b in members.items()},
        'exclusions':'No binaries, SDK/model payloads, duplicate full Model source tree or K2 pilot samples; only this narrow source/syntax evidence.'}
    members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    DEST.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in members.items():z.writestr(n,b)
    with zipfile.ZipFile(archive_path) as z:
        assert z.testzip() is None and set(z.namelist())==set(members)
        for n,row in manifest['members'].items():assert digest(z.read(n))=={k:row[k] for k in ['bytes','sha256']}
    report['archive']={'path':archive_path.relative_to(ROOT).as_posix(),**digest(archive_path.read_bytes()),
        'members':len(members),'CRC':'PASS','member_SHA256':'PASS','binary_SDK_model_payloads':False}
    save(report_path,report)
    result={'report':pin(report_path),'archive':pin(archive_path),'members':len(members),
        'CRC':'PASS','member_SHA256':'PASS','new_compilations_or_runtime':0}
    save(WORK/'archive-verification.json',result)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
