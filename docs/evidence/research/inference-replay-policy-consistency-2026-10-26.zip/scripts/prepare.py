from pathlib import Path
import difflib,hashlib,json

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
def pin(p):
    b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,obj):p.write_bytes((json.dumps(obj,indent=2)+'\n').encode())
def replace(s,a,b):
    assert s.count(a)==1,(a,s.count(a))
    return s.replace(a,b,1)

def main():
    rows=[];patch=''
    for rel in ['engine/models/qwen35/main.cc','engine/models/qwen35/README.md']:
        raw=(ROOT/rel).read_bytes();nl='\r\n' if b'\r\n' in raw else '\n'
        text=raw.decode().replace('\r\n','\n')
        if rel.endswith('.cc'):
            text=replace(text,'enum class ReplayPolicy { kAuto, kCommands, kPreferCapture };\n',
                'enum class ReplayPolicy { kAuto, kCommands, kPreferCapture };\n'
                'constexpr g::ReplayMode select_replay_mode(ReplayPolicy policy,\n'
                '    std::size_t known_uses, bool sampling_enabled) noexcept {\n'
                '  return sampling_enabled || policy == ReplayPolicy::kCommands\n'
                '      || (policy == ReplayPolicy::kAuto && known_uses <= 1)\n'
                '      ? g::ReplayMode::kCommands : g::ReplayMode::kPreferCapture;\n'
                '}\n')
            text=replace(text,'  bool head = false;\n  std::vector<Tensor> literals;',
                '  bool head = false;\n  g::ReplayMode replay_mode = g::ReplayMode::kCommands;\n  std::vector<Tensor> literals;')
            text=replace(text,'    program.rows = rows; program.head = head;\n',
                '    program.rows = rows; program.head = head;\n'
                '    // No reliable auxiliary-use hint: Auto retains the original Commands path.\n'
                '    program.replay_mode = select_replay_mode(replay_policy, 1, default_sampler.enabled);\n')
            begin=text.index('  DraftProposal execute_draft(')
            target='check(run.prepare_replay(queues, {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}));'
            at=text.index(target,begin)
            text=text[:at]+text[at:].replace(target,
                'check(run.prepare_replay(queues, {.mode = program.replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));',1)
            text=replace(text,'      phase.replay_modes[slot] = selected_sampler.enabled || replay_policy == ReplayPolicy::kCommands\n'
                '          || (replay_policy == ReplayPolicy::kAuto && phase.planned_slot_uses[slot] <= 1)\n'
                '          ? g::ReplayMode::kCommands : g::ReplayMode::kPreferCapture;',
                '      phase.replay_modes[slot] = select_replay_mode(\n'
                '          replay_policy, phase.planned_slot_uses[slot], selected_sampler.enabled);')
        else:
            old='也可显式固定其中一种模式。生成可能提前结束，不保证每份capture都会复用；'
            new=('主Phase与辅助NextN proposal／repair图使用同一冷选择。辅助图目前没有可靠使用次数提示，'
                'Auto按一次处理，保持原Commands；显式prefer-capture将PreferCapture传给原Graph，'
                '不支持捕获的范围仍按Graph合同回退Commands，不保证整图捕获。随机采样的主Phase／NextN、'
                '接受采样和完整前缀重采样辅助图保留强制Commands，显式prefer-capture不覆盖该合同。'
                '模式在冷准备时保存，不在每步重新选择。生成可能提前结束，不保证每份capture都会复用；')
            text=replace(text,old,new)
        data=text.replace('\n',nl).encode()
        bp=WORK/'before'/rel;ap=WORK/'source'/rel
        assert not ap.exists()
        bp.parent.mkdir(parents=True,exist_ok=True);ap.parent.mkdir(parents=True,exist_ok=True)
        bp.write_bytes(raw);ap.write_bytes(data)
        rows.append({'path':rel,'before':pin(bp),'after':pin(ap)})
        patch+=''.join(difflib.unified_diff(raw.decode().splitlines(True),data.decode().splitlines(True),
            fromfile='a/'+rel,tofile='b/'+rel))
    (WORK/'product.patch').write_bytes(patch.encode())
    save(WORK/'product-pins.json',{'files':rows,'patch':pin(WORK/'product.patch')})
    save(WORK/'scope.json',{'status':'PRIVATE_CONFIGURATION_CONSISTENCY_FIX',
        'default':'Auto Phase expression is identical through a pure selector; auxiliary knownUses1 stays Commands.',
        'explicit_prefer':'DraftProgram now stores the same selected PreferCapture at cold prepare and passes it to original Graph fallback; no auto auxiliary capture optimization enabled.',
        'sampling':'Original random-enabled main/draft forcing Commands, recursive acceptance sampler and frontier resampling Commands preserved.',
        'ownership':'No new header, policy object, owner, thread pool, scheduler, graph IR or resource/retirement change.',
        'limits':'Closed K2 forced-Auto pilot is not productized or evidence of benefit. No new GPU/model/TPS experiment.'})
    print(json.dumps({'patch':pin(WORK/'product.patch'),'source_pins':pin(WORK/'product-pins.json')},indent=2))

if __name__=='__main__':main()
