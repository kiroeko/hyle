"""Refresh only seven named Hyle CUDA leaves from their retained Ninja rules."""
from pathlib import Path
import concurrent.futures, ctypes, hashlib, json, os, re, subprocess, sys, time
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
sys.path.insert(0, str(R / 'scripts'))
from hyle_environment import windows_compiler_environment

def pin(path):
    p = Path(path).resolve(); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
def split_command(command):
    argc = ctypes.c_int()
    fn = ctypes.windll.shell32.CommandLineToArgvW
    fn.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    fn.restype = ctypes.POINTER(ctypes.c_wchar_p)
    argv = fn(command, ctypes.byref(argc))
    try: return [argv[i] for i in range(argc.value)]
    finally: ctypes.windll.kernel32.LocalFree(ctypes.cast(argv, ctypes.c_void_p))

def plan_one(name):
    backend = name == 'device_status_kernel'
    build = R / '.scratch' / ('build-compute-v2-dev' if backend else 'b-cuda-d5')
    module = 'compute_backend_cuda' if backend else 'compute_provider_cuda'
    ninja = build / 'build.ninja'; rules = build / 'CMakeFiles/rules.ninja'
    lines = ninja.read_text().splitlines()
    suffix = name + '.cu.obj'
    matches = [i for i, line in enumerate(lines) if line.startswith('build ') and
               line.split(': ', 1)[0].endswith('\\' + suffix)]
    assert len(matches) == 1, (name, matches)
    i = matches[0]; line = lines[i]
    old_output, rhs = line[6:].split(': ', 1)
    rule, source = rhs.split(' || ', 1)[0].split(' ', 1)
    source = Path(source.replace('$:', ':')).resolve()
    assert source == R / 'src' / module / (name + '.cu')
    variables = {}
    for row in lines[i + 1:]:
        if not row.startswith('  '): break
        key, value = row.strip().split(' = ', 1); variables[key] = value
    rule_lines = rules.read_text().splitlines()
    j = rule_lines.index('rule ' + rule)
    template = next(s.split(' = ', 1)[1] for s in rule_lines[j + 1:j + 8]
                    if s.startswith('  command = '))
    folder = W / name
    output = folder / 'unit.obj'; dep = folder / 'unit.d'
    variables.update(out=str(output), DEP_FILE=str(dep), **{'in': str(source)},
                     TARGET_COMPILE_PDB=str(folder / 'unit.pdb'), LAUNCHER='', CODE_CHECK='')
    command = re.sub(r'\$\{([^}]+)\}|\$([A-Za-z_][A-Za-z_0-9]*)',
                     lambda m: variables[m.group(1) or m.group(2)], template)
    argv = split_command(command)
    assert argv[-5:-3] != ['-c', '']
    assert str(source) in argv and str(output) in argv
    assert not any('include-freeze' in arg for arg in argv)
    return dict(name=name, source=pin(source), old_object=pin(build / old_output),
                object_path=str(output), command=argv, cwd=str(R),
                recipe=[pin(ninja), pin(rules)],
                original_build_statement=line,
                original_variables={k: v for k,v in variables.items() if k in ('DEFINES','FLAGS','INCLUDES')})

def deps_from(path):
    text = path.read_text().replace('\\\n', ' ').replace('\\\r\n', ' ')
    body = re.split(r'\s:\s', text, maxsplit=1)[1]
    paths = [Path(s.replace('\\ ', ' ')).resolve() for s in re.findall(r'(?:\\ |[^\s])+', body)]
    unique = list(dict.fromkeys(paths))
    assert all(p.is_file() for p in unique), [str(p) for p in unique if not p.is_file()]
    return [pin(p) for p in unique]

def compile_one(plan):
    out = W / plan['name']; out.mkdir(exist_ok=False); (out / 'tmp').mkdir()
    save(out / 'plan.json', plan)
    env = ENV.copy(); env['TEMP'] = env['TMP'] = str(out / 'tmp')
    start = time.perf_counter()
    record = dict(command=plan['command'], cwd=str(R), started=time.time(), timeout_seconds=600)
    save(out / 'command.json', record)
    print('START', plan['name'], flush=True)
    with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
        p = subprocess.Popen(plan['command'], cwd=R, env=env, stdout=so, stderr=se,
                             creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = p.pid; save(out / 'live.json', record)
        try: record['exit'] = p.wait(timeout=600); record['timed_out'] = False
        except subprocess.TimeoutExpired:
            p.kill(); record['exit'] = p.wait(); record['timed_out'] = True
    record.update(finished=time.time(), process_wall_seconds=time.perf_counter()-start)
    save(out / 'process.json', record)
    if record['exit'] or record['timed_out']:
        print('FAILED', plan['name'], record['exit'], flush=True)
        return dict(name=plan['name'], success=False, process=pin(out/'process.json'))
    assert pin(plan['source']['path']) == plan['source']
    dependencies = deps_from(out / 'unit.d')
    identity = dict(source=plan['source'], object=pin(plan['object_path']),
                    command=plan['command'], dependencies=dependencies, recipe=plan['recipe'])
    save(out / 'identity.json', identity)
    print('PASS', plan['name'], round(record['process_wall_seconds'], 3), len(dependencies), flush=True)
    return dict(name=plan['name'], success=True, before=plan['old_object'], after=identity['object'],
                identity=pin(out/'identity.json'), process=pin(out/'process.json'))

if __name__ == '__main__':
    names = ['native_kernel', 'norm_kernel', 'reduction_kernel', 'scatter_kernel',
             'sglang_kernel', 'sglang_norm_kernel', 'device_status_kernel']
    plans = [plan_one(n) for n in names]
    save(W / 'plan.json', dict(scope='Seven project CUDA leaf objects only; current canonical sources/headers, original flags; no SDK or runtime.',
                               max_parallel=3, jobs=plans))
    compiler = R' C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe'.strip()
    ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': compiler})
    ENV['VSLANG']='1033'
    ENV['PATH']=str(Path(compiler).parent)+os.pathsep+str(Path(plans[0]['command'][0]).parent)+os.pathsep+ENV['PATH']
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(compile_one, plans))
    save(W / 'object-map.json', dict(success=all(r['success'] for r in results), rows=results,
                                    SDK_builds=0, GPU_runs=0, source_changes=0))
    sys.exit(0 if all(r['success'] for r in results) else 1)
