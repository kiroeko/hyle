"""Link the refreshed current project objects with unchanged dependency binaries."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
BASE = ROOT / '.scratch/inference-synchronous-step-report-20261025/cuda'
spec = importlib.util.spec_from_file_location('current_compile_helpers',
    ROOT / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def exact(row):
    assert pin(row['path']) == row, row['path']


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')


final = sys.argv[1:] == ['final']
suffix = '-current' if final else ''
out = WORK / ('link-current' if final else 'link1')
resume = sys.argv[1:] == ['resume-before-link']
assert sys.argv[1:] in [[], ['resume-before-link'], ['final']]
assert (out.exists() and not (out / 'process').exists()) if resume else not out.exists()
out.mkdir(exist_ok=resume)
baseline = read(BASE / 'ready.json')
exact(baseline['image'])
original_inputs = read(BASE / 'link-inputs.json')
for row in original_inputs:
    exact(row)
mapping = {}
replacements = []
for row in read(WORK / 'headers79-summary.json')['results']:
    assert row['process']['exit'] == 0
    for dependency in row.get('current_project_dependencies', []):
        exact(dependency)
    replacements.append({'before': row['before_object'], 'after': [row['object']]})
for row in read(WORK / 'unresolved-host/object-map.json'):
    replacements.append({'before': row['before'], 'after': [row['after']]})
replacements.extend(read(WORK / 'engine/object-map.json'))
if final:
    native_map = read(WORK / 'native-current/object-map.json')
    assert native_map['success'] and len(native_map['rows']) == 7
    for row in native_map['rows']:
        assert row['success']
        exact(row['identity'])
        identity = read(Path(row['identity']['path']))
        exact(identity['source'])
        for dependency in identity['dependencies']:
            exact(dependency)
        replacements.append({'before': row['before'], 'after': [row['after']]})
assert len(replacements) == (107 if final else 100)
for row in replacements:
    exact(row['before'])
    for after in row['after']:
        exact(after)
    key = os.path.normcase(str(Path(row['before']['path']).resolve()))
    assert key not in mapping
    mapping[key] = row['after']
original = read(BASE / 'link/command.json')['command']
command, used = [], set()
for arg in original:
    key = os.path.normcase(str(Path(arg).resolve())) if not arg.startswith('/') else None
    if key in mapping:
        command.extend(row['path'] for row in mapping[key])
        used.add(key)
    elif arg.upper().startswith('/OUT:'):
        command.append('/OUT:' + str(out / 'hyle.exe'))
    elif arg.upper().startswith('/MAP:'):
        command.append('/MAP:' + str(out / 'hyle.map'))
    else:
        command.append(arg)
assert len(used) == len(mapping)
save(WORK / ('object-map'+suffix+'.json'), replacements)
save(out / 'plan.json', {'baseline_ready': pin(BASE / 'ready.json'),
    'replaced_old_objects': len(replacements), 'new_objects': sum(len(row['after']) for row in replacements),
    'sources': [pin(WORK / name) for name in ['headers79-summary.json','unresolved-host/summary.json','engine/summary.json'] +
               (['native-current/object-map.json'] if final else [])],
    'scope': 'Current self-source/dependency objects; unchanged vendor/native binaries retained with separate provenance review. '
             'No whole-platform/model/quality/throughput claim from linking.'})
compiler = read(WORK / 'engine/entry/command.json')['command'][0]
env = helper.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
    'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
result = helper.execute(command, env, out / 'process', timeout=120)
save(out / 'result.json', result)
assert result['exit'] == 0, 'Link failed; retain this attempt'
runtime = read(BASE / 'runtime.json')
native = Path(runtime['native']['path'])
target = out / Path(runtime['native_hardlink']['path']).name
os.link(native, target)
assert pin(native)['sha256'] == pin(target)['sha256']
runtime['native_hardlink'] = pin(target)
save(WORK / ('runtime'+suffix+'.json'), runtime)
inputs = []
for row in original_inputs:
    key = os.path.normcase(str(Path(row['path']).resolve()))
    inputs.extend(mapping.get(key, [row]))
save(WORK / ('link-inputs'+suffix+'.json'), inputs)
ready = {'status': 'CURRENT_PROJECT_OBJECTS_LINKED_VENDOR_BOUNDARIES_EXPLICIT',
    'image': pin(out / 'hyle.exe'), 'native': pin(native), 'runtime': pin(WORK / ('runtime'+suffix+'.json')),
    'link_inputs': pin(WORK / ('link-inputs'+suffix+'.json')), 'object_map': pin(WORK / ('object-map'+suffix+'.json')),
    'replaced_old_objects': len(replacements), 'new_objects': sum(len(row['after']) for row in replacements),
    'unchanged_absolute_inputs': len(original_inputs)-len(replacements),
    'link': result, 'command': pin(out / 'process/command.json'),
    'limits': 'Build only. Semantic provenance of retained vendor/native inputs is separate; '
              'no model behavior, throughput, memory or other-platform claim.'}
save(WORK / ('ready'+suffix+'.json'), ready)
print(json.dumps(ready, ensure_ascii=False, indent=2))
