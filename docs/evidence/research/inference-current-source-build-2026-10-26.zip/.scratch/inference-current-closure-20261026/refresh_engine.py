"""Refresh only four current engine host TUs from retained CUDA recipes."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
OUT = WORK / 'engine'
BASE = ROOT / '.scratch/inference-synchronous-step-report-20261025/cuda'
spec = importlib.util.spec_from_file_location('engine_refresh_recipe',
    ROOT / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
pin, save, execute = helper.pin, helper.save, helper.execute


def read(path):
    return json.loads(path.read_bytes())


def is_self(path):
    path = path.resolve()
    return any(path.is_relative_to(ROOT / directory) for directory in ['engine', 'include', 'src', 'tests'])


assert not OUT.exists(), 'Preserve prior outputs, never restart silently'
ready = read(BASE / 'ready.json')
assert ready['image']['sha256'] == '7030426b20990d8d5dcfcbce35f75ded435696efd16de49fd30aafefebef4b40'
old_app_command = ROOT / '.scratch/mtp-fixed-hidden-output-20261025/integrated/app/command.json'
old_weights_command = ROOT / '.scratch/inference-current-cuda-20261025/weights/command.json'
old_report_command = BASE / 'report/command.json'
units = [
    ('entry', ROOT / 'engine/main.cc', old_app_command, ready['app']),
    ('model', ROOT / 'engine/models/qwen35/main.cc', old_app_command, ready['app']),
    ('weights', ROOT / 'engine/models/qwen35/weights.cc', old_weights_command, ready['weights']),
    ('report', ROOT / 'engine/reporting/execution_report.cc', old_report_command, ready['report']),
]
sources_before = {key: pin(source) for key, source, _, _ in units}
support_before = [pin(ROOT / relative) for relative in [
    'engine/main.cc', 'engine/models/qwen35/driver.h',
    'engine/CMakeLists.txt', 'engine/models/qwen35/CMakeLists.txt']]
assert '#include "models/qwen35/driver.h"' in (ROOT / 'engine/main.cc').read_text()
assert 'target_sources(hyle_engine PRIVATE main.cc weights.cc)' in (ROOT / 'engine/models/qwen35/CMakeLists.txt').read_text()
assert '#include "engine/models/qwen35/main.cc"' in (ROOT / '.scratch/mtp-fixed-hidden-output-20261025/integrated/entry.cc').read_text()
compiler = read(old_app_command)['command'][0]
env = helper.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
    'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
OUT.mkdir()
plan = {'scope': 'Four current engine host TUs only; no link, GPU/model process, provider/core/native CUDA/SDK compilation',
    'baseline': pin(BASE / 'ready.json'), 'old_app_entry': pin(ROOT / '.scratch/mtp-fixed-hidden-output-20261025/integrated/entry.cc'),
    'entry_bridge': 'Historical app OBJ combined include(model main)+::main. Current target uses actual engine/main.cc+model main as two TUs; old app is replaced by both, without duplicated model or entry definitions.',
    'source_pins_before': sources_before, 'CMake_and_entry_support_before': support_before,
    'original_recipes': {key: pin(recipe) for key, _, recipe, _ in units},
    'macros_and_flags': 'Unmodified retained per-TU CUDA/backend/O2/Ob2/MD/NDEBUG/W4/WX flags; only source, output/dependency paths changed. No old header overlay.',
    'expected_objects': 4, 'old_engine_objects_replaced': 3,
    'link_count_effect': 'Old app1 becomes entry1+model1, total link inputs +1; root performs final link/behavior checks.'}
save(OUT / 'plan.json', plan)


def compile_one(unit):
    key, source, recipe_path, old_object = unit
    original = read(recipe_path)['command']
    sources = [arg for arg in original if Path(arg).suffix.lower() in ['.cc', '.cpp', '.cxx']]
    assert len(sources) == 1
    command = list(original)
    command[command.index(sources[0])] = str(source)
    folder = OUT / key
    obj = folder / 'unit.obj'
    command[command.index('/sourceDependencies') + 1] = str(folder / 'dependencies.json')
    command = [('/Fo' + str(obj)) if arg.startswith('/Fo') else
               ('/Fd' + str(folder / 'unit.pdb')) if arg.startswith('/Fd') else arg
               for arg in command]
    for flag in ['/c', '/O2', '/Ob2', '/MD', '/W4', '/WX', '/DHYLE_COMPUTE_CUDA=1']:
        assert flag in command
    assert not any('include-freeze' in arg or 'mtp-capture-per-record-cost' in arg for arg in command)
    process = execute(command, env, folder, timeout=120)
    data = read(folder / 'dependencies.json')['Data']
    assert Path(data['Source']).resolve() == source.resolve()
    actual = list(dict.fromkeys([data['Source'], *data['Includes']]))
    actual_pins = [pin(Path(path).resolve()) for path in actual]
    self_pins = [row for row in actual_pins if is_self(Path(row['path']))]
    assert pin(source) == sources_before[key]
    paths = {Path(row['path']).resolve() for row in self_pins}
    assert source.resolve() in paths
    if key == 'entry':
        assert (ROOT / 'engine/models/qwen35/driver.h').resolve() in paths
        assert (ROOT / 'engine/models/qwen35/main.cc').resolve() not in paths
    if key == 'model':
        assert (ROOT / 'engine/main.cc').resolve() not in paths
        for relative in ['engine/inference/backend.h', 'engine/inference/sampling_graph.h',
                         'include/hyle/compute/model_ops.h', 'include/hyle/compute/low_precision.h',
                         'include/hyle/compute/resource_leases.h', 'include/hyle/compute/resource_budget.h']:
            assert (ROOT / relative).resolve() in paths, relative
    if key == 'report':
        assert (ROOT / 'engine/reporting/execution_report.h').resolve() in paths
    save(folder / 'actual-dependencies.json', actual_pins)
    save(folder / 'actual-self-dependencies.json', self_pins)
    result = {'key': key, 'source': pin(source), 'before_object': old_object,
        'process': process, 'object': pin(obj), 'command': pin(folder / 'command.json'),
        'source_dependencies': pin(folder / 'dependencies.json'),
        'actual_dependencies': pin(folder / 'actual-dependencies.json'),
        'current_project_dependencies': self_pins,
        'current_project_dependency_manifest': pin(folder / 'actual-self-dependencies.json'),
        'macro_flags_unchanged_from': pin(recipe_path)}
    save(folder / 'result.json', result)
    return result


with ThreadPoolExecutor(max_workers=3) as executor:
    results = list(executor.map(compile_one, units))
for key, source, _, _ in units:
    assert pin(source) == sources_before[key]
for row in support_before:
    assert pin(Path(row['path'])) == row
object_map = [
    {'before': ready['app'], 'after': [results[0]['object'], results[1]['object']],
     'reason': 'Canonical engine entry and model are separate current target TUs'},
    {'before': ready['weights'], 'after': [results[2]['object']]},
    {'before': ready['report'], 'after': [results[3]['object']]},
]
save(OUT / 'object-map.json', object_map)
all_self = {}
for result in results:
    for row in result['current_project_dependencies']:
        if row['path'] in all_self:
            assert all_self[row['path']] == row, row['path']
        all_self[row['path']] = row
save(OUT / 'actual-self-dependencies.json', list(all_self.values()))
summary = {'status': 'PASS', 'scope': 'Current engine4 host TUs compilation only; root owns final link and behavior checks',
    'plan': pin(OUT / 'plan.json'), 'source_pins': sources_before,
    'results': results, 'object_map': pin(OUT / 'object-map.json'),
    'all_current_project_dependencies': pin(OUT / 'actual-self-dependencies.json'),
    'unique_current_project_dependencies': len(all_self),
    'TUs': 4, 'replaced_engine_objects': 3, 'link_inputs_count_increment': 1,
    'GPU_runs': 0, 'link_runs': 0, 'core_provider_native_CUDA_SDK_builds': 0,
    'limits': 'No current whole-image or behavior claim until root combines all selected object/dependency mappings and links. Sources/selfheaders current, original backend/precision/CRT flags retained; no five-header old overlay.'}
save(OUT / 'summary.json', summary)
print(json.dumps({'status': summary['status'], 'TUs': 4,
    'summary': pin(OUT / 'summary.json'), 'object_map': pin(OUT / 'object-map.json'),
    'processes': {result['key']: result['process'] for result in results}}, indent=2))
