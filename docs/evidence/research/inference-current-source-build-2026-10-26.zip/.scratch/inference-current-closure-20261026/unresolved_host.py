"""Resolve only remaining own host objects, using bounded adjacent provenance."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd().resolve()
WORK = Path(__file__).resolve().parent
OUT = WORK / 'unresolved-host'
FACTS = ROOT / '.scratch/mtp-capture-per-record-cost-20261026/compatibility/object-facts.json'
CACHE = ROOT / '.scratch/mtp-capture-per-record-cost-20261026/compatibility/cache-use-facts.json'
spec = importlib.util.spec_from_file_location('unresolved_local_recipe',
    ROOT / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def canonical(path):
    path = Path(path).resolve()
    for directory in ['src', 'include', 'engine', 'third_party']:
        if path.is_relative_to(ROOT / directory):
            return path
    # Only explicit source mirrors of an existing project-relative file map
    # back to canonical. Vendor source/src/ggml files have no such counterpart.
    parts = path.parts
    for index, part in enumerate(parts[:-1]):
        if part.lower() == 'source' and parts[index + 1].lower() in ['src', 'include', 'engine', 'third_party']:
            candidate = ROOT.joinpath(*parts[index + 1:])
            if candidate.is_file():
                return candidate.resolve()
    return None


def command_path(obj):
    candidates = [obj.parent / 'command.json', obj.parent / 'compile.command.json',
                  obj.parent / (obj.stem + '-compile.command.json')]
    return next((path for path in candidates if path.is_file()), None)


def manifest_path(obj):
    candidates = [obj.parent / 'actual-dependencies.json', obj.parent / 'repository-inputs.json',
                  obj.parent / (obj.stem + '-identity.json'), obj.parent / 'identity.json']
    return next((path for path in candidates if path.is_file()), None)


def prepare():
    assert not (OUT / 'plan.json').exists() and not (OUT / 'compile').exists(), 'Preserve previous classification/build'
    OUT.mkdir(exist_ok=True)
    rows = [row for row in read(FACTS)['rows'] if not row.get('identity')]
    affected = {Path(row['object']['path']).resolve() for row in read(WORK / 'all-project-header-drift.json')['affected_objects']}
    engine = {Path(row['before']['path']).resolve() for row in read(WORK / 'engine/object-map.json')}
    cache = {Path(row['object']['path']).resolve(): row for row in read(CACHE)['cache_comparison_owners']}
    tasks, reuse, excluded, unresolved = [], [], [], []
    for row in rows:
        obj = Path(row['object']['path']).resolve()
        assert pin(obj)['sha256'] == row['object']['sha256']
        if obj in affected or obj in engine:
            excluded.append({'object': row['object'], 'reason': 'already root79 or engine4 replacement'})
            continue
        source = canonical(row.get('source_path_only', '')) if row.get('source_path_only') else None
        if source is None or source.suffix.lower() != '.cc' or not source.is_relative_to(ROOT / 'src'):
            excluded.append({'object': row['object'], 'source_path_only': row.get('source_path_only'),
                             'reason': 'retained vendor/native-CUDA/SDK boundary, not an identified canonical own host TU'})
            continue
        recipe = command_path(obj)
        manifest = manifest_path(obj)
        changed, missing_hash, dependencies = [], [], []
        expected = {}
        if manifest:
            data = read(manifest)
            if isinstance(data, dict):
                if data.get('object'):
                    assert data['object']['sha256'] == row['object']['sha256'], manifest
                data = data.get('dependencies', [])
            assert isinstance(data, list), manifest
            expected = {Path(item['path']).resolve(): item for item in data if 'sha256' in item}
        raw_deps = Path(row['deps_paths_only']) if row.get('deps_paths_only') else None
        if raw_deps and raw_deps.is_file():
            dd = read(raw_deps)['Data']
            actual_paths = list(dict.fromkeys([dd['Source'], *dd['Includes']]))
        else:
            actual_paths = [str(path) for path in expected]
        source_covered = False
        for old_path in actual_paths:
            old_path = Path(old_path).resolve()
            current = canonical(old_path)
            if current is None:
                continue
            now = pin(current)
            compiled = expected.get(old_path)
            if current == source:
                source_covered = compiled is not None
            if compiled is None:
                missing_hash.append(str(old_path))
            elif compiled['sha256'] != now['sha256']:
                changed.append({'compiled': compiled, 'current': now})
            dependencies.append({'compiled_path': str(old_path), 'compiled': compiled, 'canonical': now})
        base = {'before_object': row['object'], 'source': pin(source),
                'recipe': pin(recipe) if recipe else None,
                'original_path_dependencies': pin(raw_deps) if raw_deps and raw_deps.is_file() else None,
                'original_hash_manifest': pin(manifest) if manifest else None,
                'project_dependencies': dependencies,
                'missing_hashes': missing_hash, 'changed': changed,
                'source_hash_covered': source_covered}
        if obj in cache:
            base['prior_cache_proof'] = {'manifest': pin(CACHE), 'row': cache[obj]}
        if expected and source_covered and not missing_hash and not changed:
            base['status'] = 'EXACT_CURRENT_SOURCE_AND_ALL_ACTUAL_PROJECT_DEPS_REUSED'
            base['object'] = row['object']
            reuse.append(base)
            continue
        if recipe is None:
            base['status'] = 'UNRESOLVED_NO_ADJACENT_COMPILE_RECIPE'
            unresolved.append(base)
            continue
        original = read(recipe)['command']
        command_sources = [arg for arg in original if Path(arg).suffix.lower() in ['.cc', '.cpp', '.cxx']]
        assert len(command_sources) == 1, recipe
        assert canonical(command_sources[0]) == source, recipe
        assert any(arg.startswith(('/I', '-I')) and Path(arg[2:]).resolve() == ROOT / 'include'
                   for arg in original), recipe
        name = '--'.join(source.relative_to(ROOT / 'src').parts).replace('.', '_')
        folder = OUT / 'compile' / name
        command = list(original)
        command[command.index(command_sources[0])] = str(source)
        command[command.index('/sourceDependencies') + 1] = str(folder / 'dependencies.json')
        command = [('/Fo' + str(folder / 'unit.obj')) if arg.startswith('/Fo') else
                   ('/Fd' + str(folder / 'unit.pdb')) if arg.startswith('/Fd') else arg
                   for arg in command]
        # Replace only explicit mirrored own include roots, not GGML/vendor SDK roots.
        replacements = []
        for index, arg in enumerate(command):
            if arg.startswith(('/I', '-I')):
                old_include = Path(arg[2:]).resolve()
                for marker in ['source']:
                    parts = old_include.parts
                    if marker in parts:
                        pos = max(i for i, part in enumerate(parts) if part == marker)
                        suffix = parts[pos + 1:]
                        candidate = ROOT.joinpath(*suffix)
                        if suffix and suffix[0] in ['src', 'include', 'engine'] and candidate.is_dir():
                            command[index] = arg[:2] + str(candidate)
                            replacements.append({'before': arg, 'after': command[index]})
        base.update({'status': 'NEEDS_CURRENT_HOST_COMPILE', 'folder': str(folder),
                     'command': command, 'replaced_private_self_include_roots': replacements})
        tasks.append(base)
    plan = {'scope': 'Only63 missing-adjacent-identity objects; own canonical host TUs, excluding root79/engine4/vendor/nativeCUDA/SDK',
            'facts': pin(FACTS), 'prior_cache_proof': pin(CACHE), 'tasks': tasks,
            'reuse': reuse, 'unresolved': unresolved, 'excluded_native_vendor_or_already_refreshed': excluded,
            'counts': {'original_unresolved': len(rows), 'own_host': len(tasks) + len(reuse) + len(unresolved),
                       'compile': len(tasks), 'reuse': len(reuse), 'unresolved_own_host': len(unresolved),
                       'excluded_native_vendor_or_already_refreshed': len(excluded)}}
    save(OUT / 'plan.json', plan)
    print(json.dumps({'counts': plan['counts'],
        'compile': [row['source']['path'] for row in tasks],
        'reuse': [row['source']['path'] for row in reuse],
        'unresolved': [row['source']['path'] for row in unresolved]}, indent=2))


def compile_all():
    plan = read(OUT / 'plan.json')
    tasks = plan['tasks']
    assert not (OUT / 'summary.json').exists()
    compiler = tasks[0]['command'][0] if tasks else None
    environment = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env if tasks else None

    def one(task):
        source = Path(task['source']['path'])
        assert pin(source) == task['source']
        folder = Path(task['folder'])
        process = helper.execute(task['command'], environment, folder, timeout=120)
        assert pin(source) == task['source']
        data = read(folder / 'dependencies.json')['Data']
        assert Path(data['Source']).resolve() == source.resolve()
        actual = list(dict.fromkeys([data['Source'], *data['Includes']]))
        actual_pins = [pin(Path(path)) for path in actual]
        project = [row for row in actual_pins if canonical(row['path'])]
        for row in project:
            assert Path(row['path']).resolve() == canonical(row['path']), row
        save(folder / 'actual-dependencies.json', actual_pins)
        save(folder / 'actual-project-dependencies.json', project)
        result = {'source': task['source'], 'before_object': task['before_object'],
                  'object': pin(folder / 'unit.obj'), 'process': process,
                  'command': pin(folder / 'command.json'),
                  'source_dependencies': pin(folder / 'dependencies.json'),
                  'actual_project_dependencies': project,
                  'actual_project_dependency_manifest': pin(folder / 'actual-project-dependencies.json')}
        save(folder / 'result.json', result)
        return result

    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(one, tasks))
    for row in plan['reuse']:
        assert pin(Path(row['object']['path']))['sha256'] == row['object']['sha256']
        for dependency in row['project_dependencies']:
            assert pin(Path(dependency['canonical']['path'])) == dependency['canonical']
    object_map = [{'before': row['before_object'], 'after': row['object']} for row in results]
    save(OUT / 'object-map.json', object_map)
    save(OUT / 'reuse-current.json', plan['reuse'])
    summary = {'status': 'PASS' if not plan['unresolved'] else 'PASS_BUILDS_WITH_NAMED_UNRESOLVED_HOST_BOUNDARY',
        'scope': plan['scope'], 'plan': pin(OUT / 'plan.json'), 'counts': plan['counts'],
        'results': results, 'object_map': pin(OUT / 'object-map.json'),
        'reuse_current': pin(OUT / 'reuse-current.json'),
        'unresolved_own_host': plan['unresolved'],
        'retained_native_vendor_or_already_refreshed': plan['excluded_native_vendor_or_already_refreshed'],
        'SDK_native_CUDA_GPU_links': 0}
    save(OUT / 'summary.json', summary)
    print(json.dumps({'status': summary['status'], 'counts': plan['counts'],
                      'summary': pin(OUT / 'summary.json'), 'object_map': pin(OUT / 'object-map.json')}, indent=2))


if __name__ == '__main__':
    assert sys.argv[1:] in [['prepare'], ['compile']]
    (prepare if sys.argv[1] == 'prepare' else compile_all)()
