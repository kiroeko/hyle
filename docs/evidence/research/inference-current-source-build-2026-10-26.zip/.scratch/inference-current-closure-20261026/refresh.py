"""Refresh the identified changed Hyle sources; reuse their compiler/SDK recipes."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
FACTS = ROOT / '.scratch/mtp-capture-per-record-cost-20261026/compatibility/object-facts.json'
spec = importlib.util.spec_from_file_location('existing_local_compile',
    ROOT / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def prepare(rows, label, drift_only):
    tasks = []
    reused = []
    fresh = {}
    if not drift_only:
        for row in read(WORK / 'drift8-summary.json')['results']:
            fresh[Path(row['before_object']['path']).resolve()] = row
    for row in rows:
        if drift_only and row.get('source_current_same') is not False:
            continue
        source = Path(row['source']['path'])
        cached = fresh.get(Path(row['object']['path']).resolve())
        if cached is not None:
            assert pin(source) == cached['source']
            assert pin(cached['object']['path']) == cached['object']
            for dependency in cached.get('current_project_dependencies', []):
                assert pin(dependency['path']) == dependency
            reused.append(cached)
            continue
        relative = source.relative_to(ROOT)
        name = '--'.join(relative.parts[1:]).replace('.', '_')
        folder = WORK / label / name
        assert not folder.exists(), f'Retain previous attempts: {folder}'
        command = list(row['recipe'])
        assert Path(command[0]).is_file()
        assert command.count(str(source)) == 1, source
        if source.suffix == '.cu':
            for flag, target in [('-MT', folder / 'unit.obj'), ('-MF', folder / 'unit.d'),
                                 ('-o', folder / 'unit.obj')]:
                command[command.index(flag) + 1] = str(target)
            command = [('-Xcompiler=-Fd' + str(folder / 'unit.pdb') + ',-FS')
                       if arg.startswith('-Xcompiler=-Fd') else arg for arg in command]
        else:
            command[command.index('/sourceDependencies') + 1] = str(folder / 'dependencies.json')
            command = [('/Fo' + str(folder / 'unit.obj')) if arg.startswith('/Fo') else
                       ('/Fd' + str(folder / 'unit.pdb')) if arg.startswith('/Fd') else arg
                       for arg in command]
        # These retained recipes search current project headers first. Do not
        # insert a historical self-header overlay into a current-source build.
        assert any(arg in ('/I' + str(ROOT / 'include'), '-I' + str(ROOT / 'include'))
                   for arg in command)
        assert not any('include-freeze' in arg for arg in command)
        tasks.append({'name': name, 'source': pin(source), 'before_object': row['object'],
                      'identity': row['identity'], 'folder': str(folder), 'command': command})
    assert len(tasks) + len(reused) == (8 if drift_only else 79)
    save(WORK / (label + '-plan.json'), {'scope': 'Changed project sources/actual self-header '
         'dependencies only; current self headers, no third-party SDK rebuild or model runs',
         'facts': pin(FACTS), 'tasks': tasks, 'reused_current_objects': reused})
    return tasks, reused


def compile_one(task, environment):
    source = Path(task['source']['path'])
    folder = Path(task['folder'])
    assert pin(source) == task['source']
    result = helper.execute(task['command'], environment, folder, timeout=240)
    assert pin(source) == task['source'], 'Source changed during compile'
    record = {'source': task['source'], 'before_object': task['before_object'],
              'process': result, 'command': pin(folder / 'command.json')}
    if result['exit'] == 0:
        record['object'] = pin(folder / 'unit.obj')
        if source.suffix != '.cu':
            data = read(folder / 'dependencies.json')['Data']
            assert Path(data['Source']).resolve() == source.resolve()
            project = []
            for path in dict.fromkeys([data['Source'], *data['Includes']]):
                p = Path(path).resolve()
                if p.is_relative_to(ROOT / 'include') or p.is_relative_to(ROOT / 'src'):
                    project.append(pin(p))
            record['current_project_dependencies'] = project
            record['source_dependencies'] = pin(folder / 'dependencies.json')
        else:
            record['source_dependencies'] = pin(folder / 'unit.d')
    save(folder / 'identity-current.json', record)
    print(json.dumps({'source': str(source.relative_to(ROOT)), 'process': result}), flush=True)
    return record


def main():
    assert sys.argv[1:] in [['drift8'], ['headers79']]
    label = sys.argv[1]
    drift_only = label == 'drift8'
    rows = read(FACTS)['rows'] if drift_only else read(WORK / 'all-project-header-drift.json')['affected_objects']
    tasks, reused = prepare(rows, label, drift_only)
    compiler = next(task['command'][0] for task in tasks if task['source']['path'].endswith('.cc'))
    env = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    results = list(reused)
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(compile_one, task, env) for task in tasks]
        for future in futures:
            try:
                results.append(future.result())
            except Exception as exc:
                results.append({'runner_error': repr(exc)})
    ok = all(row.get('process', {}).get('exit') == 0 for row in results)
    save(WORK / (label + '-summary.json'), {'status': 'PASS' if ok else 'INCOMPLETE',
         'scope': 'Current-source subset compilation only; image/remaining inputs unresolved',
         'reused_current_objects': len(reused), 'new_compiles': len(tasks),
         'results': results, 'GPU_runs': 0, 'SDK_rebuilds': 0})
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
