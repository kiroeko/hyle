"""Read existing object identities and find changed project-header dependencies."""
from pathlib import Path
import hashlib
import json

ROOT = Path.cwd().resolve()
WORK = Path(__file__).resolve().parent
facts = json.loads((ROOT / '.scratch/mtp-capture-per-record-cost-20261026/compatibility/object-facts.json').read_bytes())
cache = {}
rows = []
for row in facts['rows']:
    if not row.get('identity'):
        continue
    identity = json.loads(Path(row['identity']).read_bytes())
    changed = []
    for old in identity.get('dependencies', []):
        path = Path(old['path']).resolve()
        if not any(path.is_relative_to(ROOT / part) for part in ['include', 'src', 'engine', 'third_party']):
            continue
        if path not in cache:
            cache[path] = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if cache[path] != old['sha256']:
            changed.append({'path': str(path.relative_to(ROOT)),
                'compiled_sha256': old['sha256'], 'current_sha256': cache[path]})
    if changed:
        rows.append({'object': row['object'], 'identity': row['identity'],
            'source': row['source'], 'recipe': row['recipe'], 'changed_project_dependencies': changed})
result = {'scope': 'Existing131 exact object identities, all actual canonical project dependencies; '
          'unresolved identities/private overlays/SDKs remain outside this finite read-only scan',
          'identity_count': sum(bool(row.get('identity')) for row in facts['rows']),
          'unique_project_files': len(cache), 'affected_objects': rows}
(WORK / 'all-project-header-drift.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
print('Unique current project files:', len(cache), 'Affected objects:', len(rows))
paths = sorted({d['path'] for row in rows for d in row['changed_project_dependencies']})
for path in paths:
    count=sum(any(d['path']==path for d in row['changed_project_dependencies']) for row in rows)
    print(count, path)
