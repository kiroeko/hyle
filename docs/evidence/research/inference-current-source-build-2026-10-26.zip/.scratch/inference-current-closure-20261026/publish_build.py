"""Archive the completed bounded current-source build; does not build or run."""
from pathlib import Path
import collections, hashlib, json, sys, zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
C=R/'.scratch/mtp-capture-per-record-cost-20261026/compatibility'
P=R/'docs/evidence/research'
NAME='inference-current-source-build-2026-10-26'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p.relative_to(R)) if p.is_relative_to(R) else str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def same(info):
 p=Path(info['path']);p=p if p.is_absolute() else R/p
 now=pin(p)
 return now['bytes']==info['bytes'] and now['sha256']==info['sha256']
members={}
def add(p):
 p=Path(p).resolve();assert p.is_file(),p
 assert p.suffix.lower() not in {'.obj','.exe','.dll','.lib','.exp','.pdb','.bin','.gguf','.safetensors'}
 assert p.is_relative_to(R),p
 members[str(p.relative_to(R)).replace('\\','/')]=p
def add_if(p):
 if Path(p).is_file():add(p)
ready=read(W/'ready-current.json');inputs=read(W/'link-inputs-current.json');mapping=read(W/'object-map-current.json')
assert ready['link']['exit']==0 and ready['replaced_old_objects']==107 and ready['new_objects']==108
assert len(mapping)==107 and sum(len(x['after']) for x in mapping)==108
assert len(inputs)==222 and same(ready['image'])
for k in ['command','runtime','object_map','link_inputs']:assert same(ready[k]),k
headers=read(W/'headers79-summary.json');host=read(W/'unresolved-host/summary.json');engine=read(W/'engine/summary.json')
native=read(W/'native-current/object-map.json')
assert headers['status']==host['status']==engine['status']=='PASS' and native['success']
assert [len(x['results']) for x in [headers,host,engine]]==[79,18,4]
project={};sources={};processes=[]
for group in [headers,host,engine]:
 for row in group['results']:
  assert row['process']['exit']==0
  assert same(row['source']),row['source']['path']
  sources[row['source']['path']]=row['source'];processes.append(row['process'])
  for key in ['current_project_dependencies','actual_project_dependencies']:
   for d in row.get(key,[]):
    assert same(d),d['path'];project[d['path']]=d
  for key in ['command','source_dependencies','actual_dependencies','current_project_dependency_manifest','actual_project_dependency_manifest']:
   if key in row:
    assert same(row[key]);add(row[key]['path'])
  folder=Path(row['command']['path']).parent
  for name in ['process.json','result.json','stdout.log','stderr.log']:add_if(folder/name)
for row in native['rows']:
 assert row['success'];assert same(row['identity']) and same(row['process'])
 identity=read(row['identity']['path']);assert same(identity['source'])
 sources[identity['source']['path']]=identity['source']
 for d in identity['dependencies']:
  p=Path(d['path'])
  if any(p.is_relative_to(R/x) for x in ['src','include','engine','third_party']):
   assert same(d),d['path'];project[d['path']]=d
 folder=Path(row['identity']['path']).parent
 for name in ['identity.json','unit.d','command.json','process.json','stdout.log','stderr.log','plan.json']:add(folder/name)
assert len(sources)==108
after_paths={str(Path(d['path']).resolve()).lower() for row in mapping for d in row['after']}
input_paths={str(Path(d['path']).resolve()).lower() for d in inputs}
assert after_paths <= input_paths
source_review=dict(status='PASS_OFFLINE_CURRENT_SOURCE_HASH_AND_MAP_REVIEW',compiled_TUs=108,
 source_suffix_counts=dict(collections.Counter(Path(p).suffix for p in sources)),
 current_source_pins=list(sources.values()),unique_current_project_source_and_header_pins=list(project.values()),
 final_mapped_objects_present_in_link=108,final_absolute_inputs=222,
 actual_execution='Offline pin/map review only; no build or model run by publisher.')
save(W/'publication-source-review.json',source_review);add(W/'publication-source-review.json')
for rel in ['drift8-plan.json','drift8-summary.json','headers79-plan.json','headers79-summary.json','all-project-header-drift.json',
 'engine/summary.json','engine/plan.json','engine/object-map.json','engine/actual-self-dependencies.json',
 'unresolved-host/summary.json','unresolved-host/plan.json','unresolved-host/object-map.json','unresolved-host/reuse-current.json','unresolved-host/prepare-first-failure.json',
 'native-current/object-map.json','native-current/plan.json','native-current/runner-first-error.json',
 'ready-current.json','runtime-current.json','link-inputs-current.json','object-map-current.json',
 'link-current/plan.json','link-current/result.json',
 'ready.json','runtime.json','link-inputs.json','object-map.json',
 'behavior/summary.json','behavior/runs.json',
 'refresh.py','refresh_engine.py','unresolved_host.py','inspect_all_headers.py','link_current.py','behavior.py','native-current/refresh.py','publish_build.py']:
 add(W/rel)
for rel in ['link-current/process','behavior/ordinary','behavior/mtp']:
 folder=W/rel
 for name in ['command.json','process.json','result.json','stdout.log','stderr.log','non-time-differences.json']:add_if(folder/name)
for name in ['native-final-review.json','native-remaining-facts.json','native-dependency-filter.json','native-supplemental-pins.json',
             'native-bridge-additive.diff','flashinfer-native-batch-additive.diff','finish_native_review.py','native_remaining.py','object-facts.json',
             'header-use-review.json','cache-use-facts.json','inspect.py','cache_use.py']:
 add_if(C/name)
for row in read(C/'native-remaining-facts.json')['rows']:
 if row.get('record'):add(row['record'])
# Small original provenance records: no vendor source bodies or toolchain tree.
batch=R/'.scratch/inference-feature-completion-2026-10-18/windows-batch'
for name in ['canonical-source-identities.json','source-identities.json','current-vs-compiled-headers.json',
 'native-batch-portable-llp64-posenc-command.json','native-cache-portable-llp64-posenc-command.json',
 'native-attention-portable-llp64-posenc-decode-command.json','native_cache_encoder.cu.current.command.json']:
 add(batch/name)
supp=read(C/'native-supplemental-pins.json')
for job in supp['gdn_jobs']:
 for key in ['plan','process']:add(job[key]['path'])
for group in ['guard','row_codec','ggml_alloc']:
 for key in ['commands','native_manifest']:
  if key in supp[group]:add(supp[group][key]['path'])
for rel in ['.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices/source-identity.json',
 '.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer/source-identities.json',
 '.scratch/architecture-refactor-2026-10-18/generic-progress/ggml-cache/source-identities.json',
 '.scratch/architecture-refactor-2026-10-18/generic-progress/ggml-cache/object-identities.json',
 '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-proposal/changed-files.json']:
 add(R/rel)
behavior=read(W/'behavior/summary.json')
assert behavior['status']=='PASS_TWO_ORIGINAL_JOURNEYS'
assert all(x['process']['exit']==0 and x['non_time_differences']==0 for x in behavior['results'])
native_review=read(C/'native-final-review.json')
report=dict(status='PASS_CURRENT_PROJECT_INCREMENTAL_BUILD_WITH_EXPLICIT_RETAINED_VENDOR_BOUNDARIES',date='2026-10-26',
 scope='Windows CUDA consumer source/dependency closure refresh and final link, using the retained original native/vendor/toolchain closure; not all-platform or full-SDK certification.',
 build=dict(replaced_old_objects=107,new_objects=108,
  groups=[dict(name='source_and_header_drift',old=79,new=79,earlier_source_compiles=8,new_header_compiles=71),
          dict(name='missing_adjacent_identity_own_host',old=18,new=18),dict(name='engine_entry_model_weights_report',old=3,new=4),
          dict(name='project_CUDA_leaf_recipe_refresh',old=7,new=7)],
  compiler_exit_failures=0,compiled_translation_units=108,source_suffix_counts=source_review['source_suffix_counts'],
  default_backend_CRT_architecture_contract='Original actual per-TU macro, precision, CRT and sm89 flags retained; source/header references use canonical current paths. No old five-header overlay.',
  source_review=pin(W/'publication-source-review.json'),final_link=ready,
  absolute_link_inputs=222,additional_system_libraries=13,total_link_inputs=235,unchanged_absolute_inputs=114,
  product_source_edits=0,SDK_rebuilds=0,downloads=0),
 retained_native=dict(objects_reviewed=33,review=pin(C/'native-final-review.json'),groups=native_review['groups'],
  boundaries='Native source-only/grouped provenance records are identified as such; they are not promoted to complete compiler-header history. Exact old/current bridge changes are additive only. Original pinned GGML patches, FlashInfer portability overrides, Torch/CUDA/oneDNN libraries remain retained rather than newly rebuilt.'),
 first_failures=[dict(record=pin(W/'unresolved-host/prepare-first-failure.json'),kind='runner preparation before compilation',detail='Initial harness accepted /I but not existing equivalent -I include spelling; corrected path parsing, no compiler/source change.'),
                 dict(record=pin(W/'native-current/runner-first-error.json'),kind='runner recipe selection before compilation',detail='norm_kernel suffix also matched sglang_norm_kernel; exact basename separator fixed. Zero compiler processes started before correction.')],
 intermediate_behavior=dict(image=behavior['image'],results=[dict(kind=x['kind'],exit=x['process']['exit'],non_time_differences=x['non_time_differences'],generated_tokens=x['generated_tokens'],actual_graph_calls=x['actual_graph_calls']) for x in behavior['results']],
  scope='These two original two-turn ordinary/MTP behavior checks used the intermediate fa32 image before the final seven own CUDA leaves were replaced. They do not certify behavior or performance of final 2a94 image.'),
 limits=['Final 2a94 record here proves compilation/link and source/dependency/object mapping only. The subsequent full32 run and its results are outside this build archive.',
         'No new CPU/Apple/Vulkan Model, other-model, task-quality, concurrency fault-injection, or all-platform test is claimed.',
         'No throughput, memory, or speed improvement is inferred from compiler times, link success or the intermediate behavior pair.',
         'Foreign libraries and frozen native patch/template revisions are reused with the documented boundaries; this is not a latest-upstream or whole-SDK rebuild claim.',
         'Archive contains command/dependency/source-hash metadata, scripts and small logs; no OBJ/EXE/DLL/LIB/SDK/model bodies or duplicate full source tree.'])
# One ordinary manifest is enough for this evidence archive.
manifest=dict(files=[dict(archive_path=name,**pin(p)) for name,p in sorted(members.items())])
save(W/'publication-manifest.json',manifest);add(W/'publication-manifest.json')
archive=P/(NAME+'.zip');archive.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(members.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 archive_meta=dict(**pin(archive),members=len(z.infolist()),logical_bytes=sum(x.file_size for x in z.infolist()),CRC='PASS')
report['archive']=archive_meta
report['manifest']=pin(W/'publication-manifest.json')
save(P/(NAME+'.json'),report)
publication=dict(report=pin(P/(NAME+'.json')),archive=archive_meta,manifest=pin(W/'publication-manifest.json'),
 final_image=ready['image'],publication_builds=0,publication_GPU_runs=0)
save(W/'publication.json',publication)
print(json.dumps(publication,indent=2))
