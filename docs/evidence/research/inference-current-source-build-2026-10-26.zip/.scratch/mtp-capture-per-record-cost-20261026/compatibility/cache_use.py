"""Narrow actual CacheStorage owner/comparison closure; no build."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3];W=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def key(p):return str(p).replace('\\','/').lower()
objects=read(R/'.scratch/inference-synchronous-step-report-20261025/cuda/link-inputs.json')
names=['batch_layout','graph_batch--batch','native_batch_regions','native_paged_node','cpu-append','cpu-arena','flashinfer']
rows=[]
for obj in objects:
 p=Path(obj['path'])
 if p.suffix.lower()!='.obj' or not any(n in str(p.parent) for n in names):continue
 deps=p.parent/'actual-dependencies.json'
 if not deps.exists():continue
 d=read(deps)
 selected=[x for x in d if key(x['path']).endswith('/include/hyle/compute/low_precision.h')]
 assert len(selected)==1,(p,selected)
 cp=pin(R/'include/hyle/compute/low_precision.h')
 source=[x for x in d if str(x['path']).lower().endswith('.cc')]
 assert len(source)==1,(p,source)
 src=Path(source[0]['path']);path=src
 if '/source/' in key(src):path=R/key(src).split('/source/',1)[1]
 rows.append(dict(object=obj,actual_deps=pin(deps),source=source[0],current_source=pin(path),
  source_current_same=source[0]['sha256']==pin(path)['sha256'],compiled_cache_header=selected[0],cache_header_current_same=selected[0]['sha256']==cp['sha256'],
  recipe=str(p.parent/'command.json')))
facts=read(W/'object-facts.json')
changed={}
for header in ['model_ops.h','low_precision.h','resource_leases.h','resource_budget.h','quota_allocator.h']:
 relevant=[r for r in facts['rows'] if r['identity'] and any(h['path'].endswith(header) and not h['same'] for h in r['headers'])]
 changed[header]=dict(record_count=len(relevant),changed_contract_tokens=[r['source']['path'] for r in relevant
   if header=='model_ops.h' and any('DenseLinearF32' in x['text'] or 'BFloatLinearF32' in x['text'] for x in r.get('actual_use_lines',[]))])
out=dict(cache_comparison_owners=rows,known_identity_header_counts=changed,
 call_boundary='Remaining old-header batch_execution.cc passes CacheStorage by const reference to new out-of-line PagedArenaAccess::validate_storage; batch_materialize.cc calls out-of-line format(), unchanged data_type(). No direct CacheStorage== or construction in either TU. Their source bytes match canonical.',
 caveat='This only classifies the five named public-header changes. It is not an all-header/all-source compatibility certificate for every input or a current image build.')
(W/'cache-use-facts.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(objects=[dict(source=r['current_source']['path'],source_same=r['source_current_same'],header_same=r['cache_header_current_same']) for r in rows],changed=changed),indent=2))
