"""Inspect only the221 absolute input records of the pinned234-input closure."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3]
W=Path(__file__).resolve().parent
LINK=R/'.scratch/inference-synchronous-step-report-20261025/cuda/link-inputs.json'
headers=['include/hyle/compute/model_ops.h','include/hyle/compute/low_precision.h',
 'include/hyle/compute/resource_leases.h','include/hyle/compute/resource_budget.h','include/hyle/mem/quota_allocator.h']
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def key(p):return str(p).replace('\\','/').lower()
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
current={name:pin(R/name)['sha256'] for name in headers}
rows=[]
for obj in read(LINK):
 p=Path(obj['path'])
 if p.suffix.lower()!='.obj':continue
 candidates=[p.parent/'identity.json',p.parent/'records'/p.stem/'identity.json']
 identity=None;record=None
 for c in candidates:
  if not c.is_file():continue
  d=read(c)
  if d.get('object',{}).get('sha256')==obj['sha256']:
   identity=d;record=c;break
 row=dict(object=obj,identity=None,source=None,headers=[],recipe=None)
 if identity:
  row.update(identity=str(record),source=identity.get('source'),recipe=identity.get('command'))
  deps=identity.get('dependencies',[])
  for name in headers:
   hits=[x for x in deps if key(x['path']).endswith('/'+name.lower())]
   if hits:
    assert len(hits)==1,(p,name)
    row['headers'].append(dict(path=name,compiled_sha256=hits[0]['sha256'],current_sha256=current[name],same=hits[0]['sha256']==current[name]))
  if row['source']:
   src=Path(row['source']['path'])
   if src.is_file():
    row['source_current_same']=pin(src)['sha256']==row['source']['sha256']
    lines=src.read_text(encoding='utf-8-sig').splitlines()
    needles=['CacheStorage','key_storage','value_storage','capacity()==','capacity() ==','DenseLinearF32','BFloatLinearF32','bfloat_linear_f32','dense_linear_f32']
    row['actual_use_lines']=[dict(line=i+1,text=s.strip()) for i,s in enumerate(lines) if any(n in s for n in needles)]
 else:
  # MSVC actual dependency paths identify the original TU even where no hash
  # identity record exists; these are deliberately not promoted to old pins.
  for c in [p.parent/'dependencies.json',p.parent/(p.stem+'-deps.json'),p.parent/'deps.json']:
   if c.is_file():
    d=read(c)
    if 'Data' in d:
     row['deps_paths_only']=str(c);row['source_path_only']=d['Data']['Source']
     row['five_headers_in_actual_paths']=[h for h in headers if any(key(x).endswith('/'+h) for x in d['Data']['Includes'])]
     break
 rows.append(row)
out=dict(scope='Actual221 absolute inputs/234 including system13; direct per-object record lookup only, no whole-repository scan.',
 link=pin(LINK),objects=len(rows),identity_records=sum(x['identity'] is not None for x in rows),rows=rows)
(W/'object-facts.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('objects',len(rows),'identities',out['identity_records'])
for row in rows:
 if row['identity'] and (not row.get('source_current_same',True) or any(not h['same'] for h in row['headers'])):
  print(json.dumps(dict(object=Path(row['object']['path']).name,source=row.get('source',{}).get('path'),
   source_changed=not row.get('source_current_same',True),changed_headers=[x['path'] for x in row['headers'] if not x['same']],
   uses=row.get('actual_use_lines',[])[:8])))
print('unresolved',*[x['object']['path'] for x in rows if not x['identity']],sep='\n')
