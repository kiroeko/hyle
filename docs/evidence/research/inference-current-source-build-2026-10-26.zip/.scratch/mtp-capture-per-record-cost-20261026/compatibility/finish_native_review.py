"""Bounded final native table; uses only the already nominated records."""
from pathlib import Path
import collections, difflib, hashlib, json, re
R=Path(__file__).resolve().parents[3]; W=Path(__file__).resolve().parent
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve(); b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d): p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
rows=read(W/'native-remaining-facts.json')['rows']
by_name={Path(r['object']['path']).name:r for r in rows}
filtered=[]
for name in ['native-getrows.obj','native-convert.obj','native-router.obj','indexer-kernel.obj','native--mmid.obj','native--ssm-conv.obj']:
 r=by_name[name]; d=Path(r['object']['path']).with_suffix('.d')
 text=d.read_text().replace('\\ ',' ').replace('\\\n',' ').replace('\\','/').lower()
 changed=[x for x in r.get('changed_dependencies',[]) if x['path'].replace('\\','/').lower() in text]
 missing=[x for x in r.get('missing_dependencies',[]) if x.replace('\\','/').lower() in text]
 filtered.append(dict(object=name,source= r['source'],object_sha256=r['object']['sha256'],
                      record=r['record'],actual_depfile=pin(d),actual_changed=changed,actual_missing=missing,
                      declared_changed_count=len(r.get('changed_dependencies',[]))))
old=R/'.scratch/architecture-refactor-2026-10-18/paired-projection-route/before/src/compute_provider_ggml_cuda/native_bridge.h'
new=R/'src/compute_provider_ggml_cuda/native_bridge.h'
assert pin(old)['sha256']=='9f6983ad3912066fdbc03d22a240c746b1a4009305e065d07c4e606868b3e392'
diff=''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='original',tofile='current'))
(W/'native-bridge-additive.diff').write_text(diff,encoding='utf-8')
assert '-  ' not in diff
prefix='src/compute_provider_flashinfer/'
batch=R/'.scratch/inference-feature-completion-2026-10-18/windows-batch'
flash_original=read(batch/'canonical-source-identities.json')
flash_sources=[]
for name in ['native_batch.cu','native_cache.cu','native_attention.cu','native_cache_encoder.cu','native_attention.h']:
 info=next(x for x in flash_original if x['path'].replace('\\','/')==prefix+name)
 now=pin(R/info['path']);assert now['sha256']==info['sha256'];flash_sources.append(now)
old_batch=batch/'frozen/src/compute_provider_flashinfer/native_batch.h'
new_batch=R/'src/compute_provider_flashinfer/native_batch.h'
batch_diff=''.join(difflib.unified_diff(old_batch.read_text().splitlines(True),new_batch.read_text().splitlines(True),fromfile='original',tofile='current'))
(W/'flashinfer-native-batch-additive.diff').write_text(batch_diff,encoding='utf-8')
assert not [l for l in batch_diff.splitlines() if l.startswith('-') and not l.startswith('---')]
gdn=R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation'
gdn_jobs=[]
for name in ['cpu-baseline','cuda-gated-delta-attempt2']:
 plan=gdn/'native1/records'/name/'plan.json';job=read(plan)['job'];assert pin(job['source']['path'])==job['source']
 proc=plan.parent/'run/process.json';assert read(proc)['exit']==0
 gdn_jobs.append(dict(source=job['source'],plan=pin(plan),process=pin(proc)))
scale=next(x for x in read(R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-proposal/changed-files.json') if x['path'].endswith('gated_delta_scale.h'))
assert pin(R/scale['path'])['sha256']==scale['after_sha256']
guard=R/'.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices'
guard_sources=[]
for path,info in read(guard/'source-identity.json').items():
 if path.endswith(('index_guard.h','index_guard.cu')):
  assert pin(R/path)['sha256']==info['sha256'];guard_sources.append(pin(R/path))
row=R/'.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer'
row_sources=[]
for info in read(row/'source-identities.json'):
 if info['path'].endswith(('row_cache_kernel.cu','row_cache_kernel.h')):
  p=Path(info['path']);p=p if p.is_absolute() else R/p
  assert pin(p)['sha256']==info['sha256'];row_sources.append(pin(p))
row_obj=next(x for x in read(row/'artifacts.json') if x['path'].endswith('row-codec.obj'))
assert row_obj['sha256']==by_name['row-codec.obj']['object']['sha256']
alloc=R/'.scratch/architecture-refactor-2026-10-18/generic-progress/ggml-cache'
alloc_source=next(x for x in read(alloc/'source-identities.json') if x['path'].endswith('ggml-alloc.c'))
assert pin(R/alloc_source['path'])['sha256']==alloc_source['sha256']
alloc_obj=next(x for x in read(alloc/'object-identities.json') if x['path'].endswith('ggml-alloc.obj'))
assert alloc_obj==by_name['ggml-alloc.obj']['object']
refresh=R/'.scratch/inference-current-closure-20261026/native-current/object-map.json'
assert read(refresh)['success']
groups=[
 dict(status='reuse_exact_source_and_retained_dependency_hashes',count=6,
      objects=[Path(r['object']['path']).name for r in rows if r['status']=='EXACT_SOURCE_AND_RETAINED_DEPS'],
      evidence='native-remaining-facts.json: per-object matching object SHA and source/dependency pins'),
 dict(status='reuse_actual_CU_dependencies_unchanged',count=4,
      objects=['native-getrows.obj','native-convert.obj','native-router.obj','indexer-kernel.obj'],
      evidence='native-dependency-filter.json; broad manifest changes are not in actual compiler .d'),
 dict(status='reuse_precisely_additive_private_bridge',count=2,
      objects=['native--mmid.obj','native--ssm-conv.obj'],
      evidence='native-bridge-additive.diff; exact old9f payload recovered; only cstdint and new function declaration added. NativeFailure/fail and all original signatures identical. mmid has no bridge call; ssm only uses fail.'),
 dict(status='reuse_source_pinned_narrow_native_interface_full_header_history_not_available',count=5,
      objects=['norm.obj','concat_kernel.current.obj','sampling_kernel.current.obj','native_highdim.obj','diagmask-current.obj'],
      evidence='native-remaining-facts.json: exact original object+source records and recipes. These source-native pointer/scalar/vendor interfaces do not pass ResourceBudget, Graph internals or CacheStorage; no concrete current signature/layout change found.',
      limitation='Not a full original compiler-header identity proof; retained frozen vendor/toolchain contract, not newly compiled current SDK.'),
 dict(status='reuse_grouped_original_source_and_recipe',count=9,
      objects=['cpu-baseline.obj','cuda-gated-delta.obj','native-batch-portable-llp64-posenc.obj','native-cache-portable-llp64-posenc.obj','native-attention-portable-llp64-posenc-decode.obj','native_cache_encoder.current.obj','guard.obj','row-codec.obj','ggml-alloc.obj'],
      evidence='native-supplemental-pins.json: source groups, commands/exited records, native header boundary; original object pins remain in native-remaining-facts.json.',
      limitation='Some historical groups pin source+successful output path rather than one joint object/source/compiler-dependency identity record; do not label every old object current-canonical compiled.'),
 dict(status='refreshed_actual_current_source_and_compiler_dependencies',count=7,
      objects=[r['name'] for r in read(refresh)['rows']],evidence=str(refresh.relative_to(R)),
      SDK_builds=0,GPU_runs=0,max_parallel=3)
]
supplemental=dict(gdn_jobs=gdn_jobs,gdn_actual_only_own_headers=[pin(R/'src/compute_ggml_runtime/gated_delta_scale.h'),pin(new)],
 flashinfer=dict(source_pins=flash_sources,old_header=pin(old_batch),current_header=pin(new_batch),header_diff=pin(W/'flashinfer-native-batch-additive.diff'),
                source_contract=pin(batch/'source-identities.json'),portability_comparison=pin(batch/'current-vs-compiled-headers.json'),
                rule='BatchSpec/BatchFacts layout and original functions unchanged; new highdim/MLA declarations only. Original explicit MSVC portability overrides retained; no recompile solely for CacheStorage.'),
 bridge=dict(original=pin(old),current=pin(new),diff=pin(W/'native-bridge-additive.diff')),
 guard=dict(source_pins=guard_sources,commands=pin(guard/'commands.json')),
 row_codec=dict(source_pins=row_sources,object=row_obj,commands=pin(row/'commands.json')),
 ggml_alloc=dict(source=pin(R/alloc_source['path']),object=alloc_obj,commands=pin(alloc/'commands.json'),native_manifest=pin(alloc/'current-native-manifest.json')))
save(W/'native-dependency-filter.json',filtered)
save(W/'native-supplemental-pins.json',supplemental)
libraries=[x for x in read(R/'.scratch/inference-synchronous-step-report-20261025/cuda/link-inputs.json') if Path(x['path']).suffix.lower()=='.lib']
review=dict(scope='33 native/CU/vendor object rows among original identity-null63, plus library boundary; no additional library/SDK build, no runtime.',
 original_object_pins=pin(W/'native-remaining-facts.json'),object_count=33,groups=groups,
 library_boundary=dict(count=len(libraries),pins_source='.scratch/inference-synchronous-step-report-20261025/cuda/link-inputs.json',
   vendor_sdk='Frozen binary/library identities remain pinned: original patched GGML, FlashInfer template revision/portability overrides, Torch CPU/CUDA, CUDA13.3, oneDNN and mimalloc. No new dependency revision or concrete external C/C++ signature/layout change found in nominated native boundaries.',
   own_foundation='Hyle foundation library current-source audit remains Root/performance scope; this memo does not requalify those libraries or replace their audit.',
   limitation='Pinned reused foreign libraries are not claimed rebuilt from current Hyle source or latest upstream.'),
 conclusion='Seven unproven own CUDA leaves replaced by actual current compilations. No additional concrete native ABI/math/patch drift requires a vendor SDK rebuild. Narrow historical provenance limits above remain explicit.',
 changes=dict(product_source=0,CUDA_project_leaf_compiles=7,SDK_builds=0,GPU_runs=0,HTTP=0),
 evidence=[pin(W/'native-dependency-filter.json'),pin(W/'native-supplemental-pins.json'),pin(refresh)])
assert sum(x['count'] for x in groups)==33
save(W/'native-final-review.json',review)
print('WROTE',pin(W/'native-final-review.json'))
