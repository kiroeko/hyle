"""Only native rows of the known63 unresolved inputs, using adjacent records."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[3];W=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def key(p):return str(p).replace('\\','/').lower()
digest_cache={}
def sha(p):
 p=Path(p)
 if p not in digest_cache:digest_cache[p]=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
 return digest_cache[p]
def pin(p):return dict(path=str(p),sha256=sha(p))
def walk(d):
 if isinstance(d,dict):
  yield d
  for v in d.values():yield from walk(v)
 elif isinstance(d,list):
  for v in d:yield from walk(v)
def object_sha(d):
 obj=d.get('object')
 return obj.get('sha256') if isinstance(obj,dict) else d.get('object_sha256')
def source_pin(d):
 src=d.get('source')
 if isinstance(src,dict):return src
 if src and d.get('source_sha256'):return dict(path=src,sha256=d['source_sha256'])
 return None
allrows=read(W/'object-facts.json')['rows']
rows=[r for r in allrows if r['identity'] is None and
 (not r.get('source_path_only') or r['source_path_only'].lower().endswith('.cpp'))]
json_cache={};report=[]
extra=[R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/recipe-preparation/native-commands.json']
for r in rows:
 p=Path(r['object']['path'])
 candidates=[c for c in p.parent.glob('*.json') if any(s in c.name.lower() for s in ['identit','manifest','ready','plan','objects'])]
 candidates+=extra if 'gdn-output-scale-validation' in str(p) else []
 found=None
 for candidate in candidates:
  if candidate not in json_cache:
   try:json_cache[candidate]=read(candidate)
   except (ValueError,OSError):json_cache[candidate]=None
  for d in walk(json_cache[candidate]):
   if object_sha(d)==r['object']['sha256'] and source_pin(d):found=(candidate,d);break
  if found:break
 entry=dict(object=r['object'],status='UNRESOLVED_NATIVE_PROVENANCE',record=None,source=None)
 if found:
  candidate,d=found;sp=source_pin(d);entry.update(record=str(candidate),source=sp,source_present_same=sha(sp['path'])==sp['sha256'])
  changed=[];missing=[];checked=0
  for dep in d.get('dependencies',[]):
   if not isinstance(dep,dict) or 'path' not in dep or 'sha256' not in dep:continue
   checked+=1;actual=sha(dep['path'])
   if actual is None:missing.append(dep['path'])
   elif actual!=dep['sha256']:changed.append(dict(path=dep['path'],old=dep['sha256'],current=actual))
  entry.update(dependencies_checked=checked,changed_dependencies=changed,missing_dependencies=missing,
   command=d.get('command'),status='EXACT_SOURCE_AND_RETAINED_DEPS' if entry['source_present_same'] and not changed and not missing and checked else
      'EXACT_SOURCE_ONLY_NO_FULL_DEPS' if entry['source_present_same'] and not changed and not missing else 'REVIEW_REQUIRED_DRIFT')
 else:
  commands=[c for c in p.parent.glob('*.json') if 'command' in c.name.lower()]
  for candidate in commands:
   try:d=read(candidate)
   except (ValueError,OSError):continue
   for item in walk(d):
    cmd=item.get('command')
    if isinstance(cmd,list) and any(key(p)==key(a) or key(a).endswith(key(p)) for a in cmd if isinstance(a,str)):
     sources=[a for a in cmd if isinstance(a,str) and a.lower().endswith(('.cu','.cpp','.c')) and Path(a).is_file()]
     entry['command_record']=str(candidate);entry['source_path_from_command']=sources[0] if len(sources)==1 else sources;break
   if entry.get('command_record'):break
 report.append(entry)
result=dict(scope='Only native/CU/vendor.cpp rows among63 unresolved; own host rows delegated to Root/perf.',rows=report)
(W/'native-remaining-facts.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for e in report:print(Path(e['object']['path']).name,e['status'],'SOURCE',e.get('source',{}).get('path') if e.get('source') else e.get('source_path_from_command'),
 'changed',len(e.get('changed_dependencies',[])),'missing',len(e.get('missing_dependencies',[])))
print('rows',len(report),'statuses',{s:sum(e['status']==s for e in report) for s in sorted({e['status'] for e in report})})
