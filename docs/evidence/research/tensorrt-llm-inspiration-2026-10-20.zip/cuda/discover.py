from pathlib import Path
import json,urllib.request,hashlib
stage=Path('.scratch/architecture-refactor-2026-10-18/tensorrt-llm-inspiration/cuda'); commit='46d9966b54d9d11998b712e732fb20f64d4d35c0'; rows=[]
for folder in ['tensorrt_llm/_torch/compilation','tensorrt_llm/_torch/modules','cpp/tensorrt_llm/kernels/weightOnlyBatchedGemv','cpp/tensorrt_llm/kernels/fused_gated_gemm']:
 url=f'https://api.github.com/repos/NVIDIA/TensorRT-LLM/contents/{folder}?ref={commit}'
 req=urllib.request.Request(url,headers={'User-Agent':'Hyle-bounded-source-review'})
 try:
  with urllib.request.urlopen(req,timeout=30) as response:b=response.read(300000)
  j=json.loads(b); entries=[{'name':x['name'],'path':x['path'],'type':x['type'],'bytes':x['size']} for x in j]
  rows.append({'url':url,'response_bytes':len(b),'entries':entries})
  print(json.dumps({'folder':folder,'entries':entries}))
 except Exception as e: rows.append({'url':url,'error':str(e)}); print(json.dumps({'folder':folder,'error':str(e)}))
(stage/'directory-metadata.json').write_text(json.dumps({'commit':commit,'queries':rows},indent=2)+'\n',encoding='utf-8')
