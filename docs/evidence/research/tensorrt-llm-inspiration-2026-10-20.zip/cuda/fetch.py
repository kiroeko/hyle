from pathlib import Path
import json,urllib.request,hashlib
stage=Path('.scratch/architecture-refactor-2026-10-18/tensorrt-llm-inspiration/cuda'); commit='46d9966b54d9d11998b712e732fb20f64d4d35c0'
paths=['tensorrt_llm/_torch/compilation/backend.py','tensorrt_llm/_torch/compilation/piecewise_optimizer.py','tensorrt_llm/_torch/modules/low_m_gemm.py','tensorrt_llm/_torch/modules/gated_mlp.py','tensorrt_llm/_torch/modules/linear.py','cpp/tensorrt_llm/kernels/weightOnlyBatchedGemv/cudaCoreGemm.cu','tensorrt_llm/_torch/pyexecutor/cuda_graph_runner.py']
rows=[]; total=0
for path in paths:
 url=f'https://raw.githubusercontent.com/NVIDIA/TensorRT-LLM/{commit}/{path}'
 req=urllib.request.Request(url,headers={'User-Agent':'Hyle-bounded-source-review'})
 try:
  with urllib.request.urlopen(req,timeout=30) as response:
   b=response.read(400001); assert len(b)<=400000,(path,'single-file bound')
  total+=len(b); assert total<=1500000
  out=stage/'sources'/path; out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(b)
  row={'path':path,'url':url,'github':f'https://github.com/NVIDIA/TensorRT-LLM/blob/{commit}/{path}','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}; rows.append(row); print(json.dumps(row))
 except Exception as e: rows.append({'path':path,'url':url,'error':str(e)}); print(json.dumps(rows[-1]))
metadata=json.loads((stage/'directory-metadata.json').read_text()); metadata_bytes=sum(x.get('response_bytes',0) for x in metadata['queries'])
report={'commit':commit,'sources':rows,'downloaded_source_bytes':total,'directory_metadata_bytes':metadata_bytes,'tracked_download_bytes':total+metadata_bytes,'key_file_limit':10,'total_limit_bytes':2097152,'no_repo_or_submodule_clone':True}
(stage/'source-inventory.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
