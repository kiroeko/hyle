"""Retain only selected official documentation at the reviewed source commit."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request

S = Path(__file__).resolve().parent
OUT = S / 'docs'
OUT.mkdir(parents=True, exist_ok=True)
COMMIT = '46d9966b54d9d11998b712e732fb20f64d4d35c0'
PATHS = ['docs/source/developer-guide/overview.md',
         'docs/source/features/attention.md',
         'docs/source/legacy/tensorrt-backend-removal.md',
         'docs/source/developer-guide/perf-benchmarking.md']

def fetch(relative):
    url = f'https://raw.githubusercontent.com/NVIDIA/TensorRT-LLM/{COMMIT}/{relative}'
    request = urllib.request.Request(url, headers={'User-Agent': 'Hyle-source-review'})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(262145)
        assert len(data) <= 262144, 'Unexpected large documentation download'
        target = OUT / Path(relative).name
        assert not target.exists(), 'Preserve existing source receipts'
        target.write_bytes(data)
        return dict(url=url, source_path=relative, local=str(target), bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest(), status=response.status)

rows, errors = [], []
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    futures = {pool.submit(fetch, path): path for path in PATHS}
    for future, path in futures.items():
        try:
            rows.append(future.result())
        except Exception as error:
            errors.append(dict(path=path, error=str(error)))
(S / 'docs-downloads.json').write_text(json.dumps(dict(commit=COMMIT, sources=rows,
    errors=errors, repository_clone=False, submodules=False, installed=False), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(sources=len(rows), bytes=sum(row['bytes'] for row in rows), errors=errors)))
