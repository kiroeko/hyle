"""Publish the bounded source review; no product builds or inference runs."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
DEST = ROOT / 'docs/evidence/research/tensorrt-llm-inspiration-2026-10-20'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

def sha(data):
    return hashlib.sha256(data).hexdigest()

sources = read(S / 'cuda/source-inventory.json')
docs = read(S / 'docs-downloads.json')
mapping = read(S / 'cuda-map.json')
assert sources['commit'] == docs['commit'] == '46d9966b54d9d11998b712e732fb20f64d4d35c0'
assert len(sources['sources']) == 8 and len(docs['sources']) == 4 and not docs['errors']
for row in sources['sources']:
    data = (S / 'cuda/sources' / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
for row in docs['sources']:
    data = Path(row['local']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
report = dict(
    status='Bounded source/documentation research complete; no Hyle optimization or benchmark claimed',
    source_commit=sources['commit'],
    source_commit_url='https://github.com/NVIDIA/TensorRT-LLM/commit/' + sources['commit'],
    scope=dict(CUDA_sources=8, official_documents=4,
        source_and_document_bytes=sum(row['bytes'] for row in sources['sources'] + docs['sources']),
        source_directory_metadata_bytes=sources['directory_metadata_bytes'],
        full_repository_clone=False, submodules=False, installed=False,
        Hyle_product_changes=False, builds=0, GPU_runs=0, throughput_measurements=0),
    findings=[
        dict(mechanism='Current execution backend',
             fact='The pinned migration guide removes the old TensorRT engine backend and makes PyTorch the sole execution backend; custom CUDA leaves and compilation remain distinct from the former engine-build workflow.',
             source='docs/tensorrt-backend-removal.md'),
        dict(mechanism='Cold shared-activation quantization and consumer layout',
             fact='GatedMLP compares static gate/up scales after loading, shares quantization only when compatible, and can emit the two-input activation directly in the down-projection input dtype.',
             source='cuda/sources/tensorrt_llm/_torch/modules/gated_mlp.py',
             Hyle='Existing shared FP8 prologue already covers part of this principle. Quark shared A should use its expert-independent quantizer once per token. Preserve actual dtype rounding, aliases and published intermediates.'),
        dict(mechanism='Stable metadata and graph replay',
             fact='Attention CUDA-graph metadata is preallocated at warmup; runtime graph handling separates capture/replay and actual request metadata.',
             sources=['docs/attention.md', 'cuda/sources/tensorrt_llm/_torch/pyexecutor/cuda_graph_runner.py'],
             Hyle='Existing finite graph family and stable binding lifetime are the natural owners; no replacement executor or padding requirement follows from this review.'),
        dict(mechanism='Shape, dtype and architecture specific kernels',
             fact='Read unquantized SM89 linear code retains F.linear or an explicit cuBLAS wrapper. The inspected low-M/persistent specialization has SM100 conditions; the inspected CUDA-core GEMM caller requires FP8 inputs even though the kernel source instantiates BF16.',
             sources=['cuda/sources/tensorrt_llm/_torch/modules/linear.py',
                      'cuda/sources/tensorrt_llm/_torch/modules/low_m_gemm.py',
                      'cuda/sources/cpp/tensorrt_llm/thop/cudaScaledMM.cpp'],
             Hyle='Check real hot projection geometry and mathematical eligibility under the current cold planner. Neither a callable template nor SM100 results establish a4070 BF16 benefit. F.linear does not prove the exact internal cuBLAS algorithm selected at runtime.'),
        dict(mechanism='CPU/GPU overlap',
             fact='The official architecture describes launching the next GPU step while processing previous CPU results, using device-side token dependencies and accepting an additional pipelined step.',
             source='docs/overview.md',
             Hyle='Inspect actual trace gaps and token visibility in D4; revisit GPU metadata and acceptance lengths with the actual MTP consumer in step6. Preserve stop, failure, old results and real Completion retirement.')],
    performance_interpretation=dict(
        status='Analytical explanation, not a measured ceiling',
        small_batch='Decode can be constrained by weight/KV/state traffic, low parallelism and launch/synchronization gaps. Fewer kernels alone is not a throughput result.',
        large_batch='Batching reuses weights across requests and changes arithmetic intensity; aggregate tokens/s is a different metric from one-request decode.',
        comparison='Same GPU, weights/quantization, input/context, batch, speculative mode and token-visible timing boundary are required. Blackwell, FP4 and high-concurrency numbers cannot certify4070 BF16 behavior.'),
    next_actions=dict(
        existing_work='Current-work steps3/4/5 and D4; step6 for actual MTP. No added capability-package count or independent executor project.',
        D4='Inspect one actual hot projection/epilogue chain and host-token trace. Create a paired candidate only if a new routing, traffic or synchronization premise is demonstrated; otherwise record the specific decision and close this bounded review without reopening settled Top1 experiments.',
        implementation='Use the existing cold region/provider selection and shared execution/resource core. Keep hardware kernels and mathematical layout policy in backend owners.'),
    detailed_source_map='cuda-map.json',
    official_sources=[dict(url=row['url'], member='docs/' + Path(row['local']).name,
        bytes=row['bytes'], sha256=row['sha256']) for row in docs['sources']],
    limitations=['No TensorRT-LLM installation, model import or inference was executed.',
        'No proof of whole-product RTX4070 support, exact model support, numerical equivalence or throughput gain is made.',
        'The deployed latest docs observed at cc63e66 and the pinned main source are distinct revisions; the retained raw documents use the pinned source revision.'])
entries = {}
for row in mapping['hyle_source_identity']:
    data = (ROOT / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    entries['hyle-source/' + row['path']] = data
report['scope']['Hyle_source_snapshot_count'] = len(mapping['hyle_source_identity'])
for path in sorted(S.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path.name == 'package-receipt.json':
        continue
    assert path.suffix.lower() not in ['.exe', '.obj', '.lib', '.zip'], path
    entries[path.relative_to(S).as_posix()] = path.read_bytes()
entries['report-core.json'] = encoded(report)
inventory = [dict(member=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(entries.items())]
entries['inventory.json'] = encoded(dict(members=inventory, scope='All members except this inventory'))
DEST.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        archive.writestr(name, data)
with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
    assert archive.testzip() is None
    assert len(set(archive.namelist())) == len(entries)
    for name, data in entries.items():
        assert archive.read(name) == data
data = DEST.with_suffix('.zip').read_bytes()
report['archive'] = dict(path=DEST.with_suffix('.zip').relative_to(ROOT).as_posix(),
    bytes=len(data), sha256=sha(data), members=len(entries))
DEST.with_suffix('.json').write_bytes(encoded(report))
receipt = dict(report_bytes=DEST.with_suffix('.json').stat().st_size, archive=report['archive'])
(S / 'package-receipt.json').write_bytes(encoded(receipt))
print(json.dumps(receipt))
