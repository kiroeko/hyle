"""Reuse the actual duplicate-session CPU recipe for one current typed-N check."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
SOURCE = ROOT / '.scratch/inference-duplicate-session-20261025/check_cpu.py'
spec = importlib.util.spec_from_file_location('ledger_cpu_recipe', SOURCE)
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
assert recipe.ROOT == ROOT
recipe.WORK = WORK / 'verification'
MAIN_SHA = '69b4bdc92ed00e0bcc884d73e2e7e07e4016db485121687aaad54d1a66288ed7'
CASE_SHA = '1ad36aeddee338177167ac3232b7bc1d22130ad611b74df487493f39d9e0dbc7'
ATTEMPT = 'cpu1'

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'build', 'run'))
    args = parser.parse_args()
    call = argparse.Namespace(attempt=ATTEMPT, phase='current',
                              main_sha=MAIN_SHA, case_sha=CASE_SHA)
    if args.action == 'prepare':
        recipe.prepare(call)
        recipe.save(recipe.WORK / ATTEMPT / 'runner-context.json', {
            'wrapper': recipe.pin(Path(__file__).resolve()),
            'reused_recipe': recipe.pin(SOURCE),
            'ROOT': str(recipe.ROOT), 'WORK': str(recipe.WORK),
            'expected_main_sha256': MAIN_SHA, 'expected_case_sha256': CASE_SHA,
            'scope': 'One existing request-ledger case; one current app TU; no before phase, core/provider/SDK compilation, GPU or HTTP.'})
    else:
        getattr(recipe, args.action)(call)
