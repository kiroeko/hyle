# DSpark speculative decoding drafters for DeepSeek-V4-Flash-0731

Preliminary DSpark drafter modules extracted from the official
[deepseek-ai/DeepSeek-V4-Flash-0731](https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731)
checkpoint, for use with llama.cpp speculative decoding.

These are **optional add-ons**. The quants in this repo are unchanged and work exactly as
before without them. Neither file is downloaded or loaded unless you explicitly ask for it
with `--spec-type draft-dspark`.

## Files

| File | Location | Size | FP8 source weights | Markov / confidence heads | Routed experts |
|---|---|---|---|---|---|
| `dspark-DeepSeek-V4-Flash-0731-Q8_0.gguf` | repo root | 10.90 GB | Q8_0 | BF16 (source fidelity) | MXFP4 passthrough |
| `dspark-DeepSeek-V4-Flash-0731-BF16.gguf` | `dspark/` | 11.31 GB | BF16, bit exact | BF16 (source fidelity) | MXFP4 passthrough |

Both files contain 81 tensors and are `general.architecture = dflash`.

The `Q8_0` file sits at the repo root so llama.cpp auto-discovers it. One copy serves every
quant folder, so `-hf unsloth/DeepSeek-V4-Flash-0731-GGUF:UD-Q4_K_XL --spec-type draft-dspark`
picks it up with no `-md` flag. The `BF16` file stays in `dspark/` and needs an explicit path.

**Which one:** they measured identically in our testing (same acceptance rate, byte identical
output text), so `Q8_0` is the default and is the one you get automatically. Take `BF16` only
if you want a provably exact reproduction of DeepSeek's weights. There is no measured quality
difference between them.

### About the names

The 0731 checkpoint stores its drafter as 25 FP8 (`E4M3`) projections, natively FP4 routed
experts, and BF16/F32 for everything small. The two files differ **only** in how those 25 FP8
tensors are stored:

- `BF16` upcasts them exactly. FP8 `E4M3` carries 4 significant bits and its `E8M0` scale is a
  pure power of two, so BF16 (8 significant bits, full F32 exponent range) reproduces every
  value with zero error. Verified `max|diff| = 0.0` against an independent dequantisation of
  the source safetensors. This file contains **no Q8_0 tensors at all**.
- `Q8_0` stores them as Q8_0, which is what upstream `convert_hf_to_gguf.py` does by default.

The routed experts are byte identical in both files. They are already MXFP4 in the source
checkpoint and are never requantised.

Note that `ggml-org/DeepSeek-V4-Flash-0731-GGUF` publishes a file also called `BF16` which is
equivalent to our `Q8_0` (its FP8 weights are Q8_0, and only 1.3% of it is actually BF16).
Our `BF16` is the fully lossless build, which is why it is larger.

## llama.cpp version required

| Build | Why |
|---|---|
| **b10228 or newer** | Minimum. Adds DeepSeek-V4 DSpark support. |
| **b10247 or newer** | Needed for multi GPU without a custom rebuild. |
| **b10259 to b10268** | Avoid. These advertise `draft-dspark` but abort while loading the drafter. |
| **b10269 or newer** | Recommended. Clear of that window. |

On builds older than b10228 the drafter fails to load with:

```
key not found in model: dflash.attention.sliding_window_pattern
```

That is not a problem with the file. Older builds do not recognise
`dflash.hyper_connection.count` and fall back to the legacy DFlash code path, which requires a
key this architecture does not use. Update llama.cpp and it loads.

Builds **b10259 to b10268** are separately broken:
[#26531](https://github.com/ggml-org/llama.cpp/pull/26531) changed tensor loading in a way that
left the drafter unloadable, and
[#26577](https://github.com/ggml-org/llama.cpp/pull/26577) fixed it. Anything from b10269 is
clear. If your build advertises `--spec-type draft-dspark` but the drafter still will not load,
check the build number against this window first.

## Usage

Speculative decoding is opt in. Pass `--spec-type draft-dspark` or nothing happens. In
particular `--mtp` and `--spec-type draft-mtp` will **not** work with these files and will log
`MTP requested but this GGUF has no MTP head or drafter`. The 0731 checkpoint ships a DSpark
drafter, not an MTP head.

The `Q8_0` drafter at the repo root is found automatically for any quant in this repo:

```bash
llama-server -hf unsloth/DeepSeek-V4-Flash-0731-GGUF:UD-Q4_K_XL \
  --spec-type draft-dspark \
  --spec-draft-n-max 3 \
  --fit off \
  -ngl 99 -ngld 99 -fa on -c 8192
```

For the `BF16` drafter, or for local files, pass the path with `-md` / `--spec-draft-model`:

```bash
llama-server \
  -m DeepSeek-V4-Flash-0731-UD-Q4_K_XL-00001-of-00005.gguf \
  -md dspark-DeepSeek-V4-Flash-0731-BF16.gguf \
  --spec-type draft-dspark \
  --spec-draft-n-max 3 \
  --fit off \
  -ngl 99 -ngld 99 -fa on -c 8192
```

Requirements and gotchas:

- `--fit off` is recommended, not required. Under `--fit on` llama.cpp cannot build a
  standalone draft context to measure the sidecar, so it logs
  `[spec] failed to measure draft model memory` and skips the reserve. The drafter still loads
  and runs; its ~11 GB is simply missing from the fitting budget, which can push a tight GPU
  into an out-of-memory failure. Pinning the placement yourself avoids that.
- Do **not** pass `-devd` / `--spec-draft-device`. The drafter ships no token embeddings or
  output head by design and borrows the target's, so it must span the same devices as the
  target. Pinning it to one GPU fails with
  `pre-allocated tensor (output.weight) in a buffer (CUDA0) that cannot run the operation`.
- `--spec-draft-n-max` is clamped to the trained block size, which is 5 for this checkpoint
  (`dspark_block_size` in DeepSeek's own `config.json`). DeepSeek's README quotes
  `num_speculative_tokens: 7` for vLLM, but the checkpoint config says 5 and llama.cpp reads
  and enforces that value, so anything above 5 is clamped with a warning.

### Multi GPU

Fixed upstream in [ggml-org/llama.cpp#22789](https://github.com/ggml-org/llama.cpp/pull/22789)
(build **b10247** and newer), which made the scheduler's split input arrays grow on demand. No
rebuild or special flags are needed. You may see a harmless log line:

```
ggml_backend_sched_graph_inputs_grow: increasing graph inputs capacity from 30 to 60
```

On builds between b10228 and b10246, a device split target aborts with
`GGML_ASSERT(n_graph_inputs < GGML_SCHED_MAX_SPLIT_INPUTS) failed`. Either update, or rebuild
with `-DCMAKE_CXX_FLAGS="-DGGML_SCHED_MAX_SPLIT_INPUTS=48"` and the matching
`-DCMAKE_CUDA_FLAGS`. Single GPU setups were never affected.

### When DSpark does not help

DSpark pays off when the target model is resident on GPU. If you are offloading most of the
target to CPU, the drafter competes for the same VRAM and can end up **slower** than no
speculative decoding at all, since displaced target layers cost more than the drafting saves.
On such setups try `--spec-draft-n-cpu-moe`, or the smaller `Q8_0` drafter, or simply do not
use a drafter.

## Measured performance

Full write-up, plots and CSVs:
[danielhanchen/minimax-2.7-analysis](https://huggingface.co/datasets/danielhanchen/minimax-2.7-analysis/tree/main/dspark_deepseek_v4_flash_0731_2026_08_06).

Against `UD-Q4_K_XL`, greedy (`temperature 0`), a 7-turn conversation with each reply appended
before the next question, 4096 tokens per turn. Decode rate is
`sum(predicted_n) / sum(predicted_ms)`, so prompt processing is excluded and a 3-token greeting
does not weigh the same as a 2000-token program.

**4x B200, layer split, median of 3 time-blocked repetitions:**

| | tokens/s | speedup | acceptance |
|---|---|---|---|
| target only | 61.0 | 1.00x | n/a |
| `--spec-draft-n-max 2` | 92.7 | 1.52x | 0.873 |
| **`--spec-draft-n-max 3`** | **112.4** | **1.84x** | 0.847 |
| `--spec-draft-n-max 5` | 92.6 | 1.52x | 0.726 |

**1x B200:**

| | tokens/s | speedup | acceptance |
|---|---|---|---|
| target only | 62.6 | 1.00x | n/a |
| `--spec-draft-n-max 1` | 85.8 | 1.37x | 0.909 |
| `--spec-draft-n-max 2` | 105.4 | 1.68x | 0.830 |
| **`--spec-draft-n-max 3`** | **119.7** | **1.91x** | 0.764 |
| `--spec-draft-n-max 5` | 100.0 | 1.60x | 0.677 |

**Use `--spec-draft-n-max 3`**, which is also llama.cpp's default. Acceptance falls
monotonically with depth while speedup peaks at 3: deeper drafts propose more tokens but a
smaller share survive verification, and past 3 the wasted verification outweighs the extra
accepted tokens. The optimum does not move between one GPU and four.

Prompt processing costs 21 to 24%, since llama.cpp decodes the prompt into the draft context as
well. That is a good trade whenever generation dominates, and inverts only for long prompts with
very short answers.

Under 4-way concurrency the gain narrows to 1.10x at n=3 on this hardware, and community reports
on busier machines have seen a regression at n=5. Treat concurrent throughput as hardware
dependent and measure it on your own box.

### Output is not bit identical to non speculative decoding

Speculative decoding should be a pure speed optimisation, but on this model greedy output
diverges from a non speculative run of the same prompt. This is a known llama.cpp issue,
tracked at [ggml-org/llama.cpp#25618](https://github.com/ggml-org/llama.cpp/issues/25618),
and is not specific to these files.
