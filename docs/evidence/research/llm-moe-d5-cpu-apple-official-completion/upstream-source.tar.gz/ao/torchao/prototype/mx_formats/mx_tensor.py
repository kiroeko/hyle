# Copyright (c) Meta Platforms, Inc. and affiliates.
# Copyright (c) 2025, NVIDIA CORPORATION.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

"""
Defines the tensor subclasses to represent the MX format spec from
https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf

Exponent E8M0 encoding details (OCP spec section 5.4.1):
  * bias: 127
  * supported exponent range: -127 to 127
  * infinities: N/A
  * NaN: 11111111
  * Zeros: N/A
"""

import math
from dataclasses import dataclass
from typing import Optional, Union

import torch
import torch.nn.functional as F
from torch._subclasses.fake_tensor import is_fake
from torch.distributed.tensor import DTensor
from torch.utils._python_dispatch import (
    return_and_correct_aliasing,
)
from torch.utils._pytree import tree_map

from torchao.utils import is_sm_at_least_100, torch_version_at_least

if torch_version_at_least("2.12.0.dev0"):
    from torch._higher_order_ops.inline_asm_elementwise import inline_asm_elementwise

from torch.nn.functional import ScalingType, SwizzleType

from torchao.prototype.mx_formats.config import (
    MXFP8Dim0CastKernelChoice,
    ScaleCalculationMode,
)
from torchao.prototype.mx_formats.constants import (
    BLOCK_SIZE_DEFAULT,
    DTYPE_FP6_E2M3,
    DTYPE_FP6_E3M2,
    E8M0_EXPONENT_BIAS,
    E8M0_EXPONENT_NAN_VAL,
    F4_E2M1_MAX,
    F4_E2M1_MAX_POW2,
    F6_E2M3_MAX,
    F6_E2M3_MAX_POW2,
    F6_E3M2_MAX,
    F6_E3M2_MAX_POW2,
    F8E4M3_MAX,
    F8E4M3_MAX_POW2,
    F8E5M2_MAX,
    F8E5M2_MAX_POW2,
    F32_EXP_BIAS,
    SUPPORTED_ELEM_DTYPES,
)
from torchao.prototype.mx_formats.kernels import (
    f4_unpacked_to_f32,
    f6_e2m3_unpacked_to_f32,
    f6_e3m2_unpacked_to_f32,
    f32_to_f4_unpacked,
    f32_to_f6_e2m3_unpacked,
    f32_to_f6_e3m2_unpacked,
    pack_uint4,
    triton_to_mxfp8_dim0,
    unpack_uint4,
)
from torchao.prototype.mx_formats.utils import (
    _swizzle_aware_slice,
    from_blocked,
    hp_data_dims_to_swizzled_scale_dims_mx,
    to_blocked,
)
from torchao.quantization.quantize_.common import (
    QuantizeTensorKwargs,
)
from torchao.quantization.quantize_.common.kernel_preference import KernelPreference
from torchao.utils import TorchAOBaseTensor, fill_defaults

aten = torch.ops.aten

# TODO(later): read from somewhere else?
SBITS, EBITS_F32, MBITS_F32 = 1, 8, 23
EBITS_F4_E2M1, MBITS_F4_E2M1 = 2, 1
EBITS_F6_E2M3, MBITS_F6_E2M3 = 2, 3
EBITS_F6_E3M2, MBITS_F6_E3M2 = 3, 2
EBITS_F8_E4M3, MBITS_F8_E4M3 = 4, 3
EBITS_F8_E5M2, MBITS_F8_E5M2 = 5, 2

_TORCH_VERSION_AT_LEAST_2_13 = torch_version_at_least("2.13.0.dev0")
_TORCH_VERSION_AT_LEAST_2_14 = torch_version_at_least("2.14.0.dev0")


@dataclass
class QuantizeTensorToMXKwargs(QuantizeTensorKwargs):
    elem_dtype: Union[torch.dtype, str] = torch.float8_e4m3fn
    block_size: int = 32
    # TODO(future PR): flip the scaling_mode default to RCEIL
    scaling_mode: ScaleCalculationMode = ScaleCalculationMode.FLOOR
    kernel_preference: KernelPreference = KernelPreference.EMULATED
    is_swizzled_scales: bool = False


def _f32_to_e8m0_rceil(value: torch.Tensor) -> torch.Tensor:
    # We can't just use value.to(float8_e8m0fnu) because it doesn't support
    # passing round="up". See https://github.com/pytorch/pytorch/issues/175409
    value = value.to(torch.float32)
    value_bits = value.view(torch.int32)
    biased_exponent = torch.bitwise_right_shift(value_bits, MBITS_F32) & 0xFF
    mantissa = value_bits & 0x7FFFFF

    # Normal FP32 values round up when any mantissa bit is set. For FP32
    # subnormals, E8M0 byte 0 is 2^-127, so only values above that round to 1.
    needs_round_up = torch.where(
        biased_exponent == 0,
        mantissa > 0x400000,
        mantissa != 0,
    )
    e8m0_biased = biased_exponent + needs_round_up.to(torch.int32)
    return torch.where(torch.isfinite(value), e8m0_biased, E8M0_EXPONENT_NAN_VAL).to(
        torch.uint8
    )


def _e8m0_scale_to_reciprocal_fp32(
    scale_e8m0_biased: torch.Tensor,
) -> torch.Tensor:
    reciprocal_e8m0_biased = (
        2 * E8M0_EXPONENT_BIAS - scale_e8m0_biased.to(torch.int32)
    ).to(torch.uint8)

    # PyTorch 2.14 adds a fuseable Inductor lowering for E8M0-to-float casts
    # (https://github.com/pytorch/pytorch/pull/190593). Remove our fallback
    # once torchao requires PyTorch 2.14 or newer.
    if _TORCH_VERSION_AT_LEAST_2_14:
        return reciprocal_e8m0_biased.view(torch.float8_e8m0fnu).to(torch.float32)

    reciprocal_fp32_bits = torch.bitwise_left_shift(
        reciprocal_e8m0_biased.to(torch.int32), MBITS_F32
    )
    reciprocal_fp32_bits = torch.where(
        reciprocal_e8m0_biased == 0,
        0x00400000,  # E8M0 byte 0 is the FP32 subnormal 2^-127.
        reciprocal_fp32_bits,
    )
    reciprocal_fp32_bits = torch.where(
        reciprocal_e8m0_biased == E8M0_EXPONENT_NAN_VAL,
        0x7F800001,
        reciprocal_fp32_bits,
    )
    return reciprocal_fp32_bits.view(torch.float32)


def _to_mx_rceil(
    data_hp: torch.Tensor,
    max_abs: torch.Tensor,
    max_pos: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    A prototype implementation of MXFP scale factor derivation method described in
    https://docs.nvidia.com/cuda/cublas/#d-block-quantization

    For Nvidia GPU with Blackwell+ architecture, the scale factor derivation method
    is accelerated by the `cvt.rp.ue8m0x2.f32` instruction via
    `inline_asm_elementwise`, if torch.compile is on. Falls back to pure PyTorch ops
    on other hardware and in eager mode.

    Args:
        data_hp: High precision data.
        max_abs: Maximum absolute value for data_hp along specified dimension/block_size.
        max_pos: The maximum value of the low precision data type.

    Returns:
        exponent: The biased exponent with dtype E8M0 in uint8 container.
        data_lp: The targeted low precision data, in high precision container
            (requires cast to low precision data type).
    """
    descale = max_abs * (1.0 / max_pos)

    if (
        # gate the inline PTX to compile only because the functionality does
        # not work properly in eager mode due to mismatch between input and
        # output tensor dtype (limitation of JITerator).
        # Note: we use both `torch.compiler.is_compiling()` as well as `is_fake`
        # because `torch.compiler.is_compiling()` properly covers
        # microbenchmarks, and `is_fake` properly covers e2e runs where this code
        # path is hit through `__torch_dispatch__` and
        # `torch.compiler.is_compiling()` returns False.
        # Note that we need both checks, as neither of them work in both benchmark
        # and e2e use cases by themselves.
        (torch.compiler.is_compiling() or is_fake(descale))
        and is_sm_at_least_100()
        # the PyTorch Core support for inline_asm_elementwise is available in
        # 2.12.0 nightly and above
        and torch_version_at_least("2.12.0.dev0")
        and descale.is_cuda
    ):
        # Use cvt.rp.ue8m0x2.f32 to convert fp32 descale to e8m0.
        # The instruction takes two fp32 inputs, packs two e8m0 results into uint16.
        # We pass 0.0 as the first input (high byte) and descale as the second (low byte).
        # Handles NaN/Inf->255 and subnormal rounding in hardware.
        scale_e8m0_u16 = inline_asm_elementwise(
            descale.to(torch.float32),
            asm_str="cvt.rp.ue8m0x2.f32 $0, 0.0, $1;",
            constraints="=h,r",
            dtype=torch.uint16,
        )
        # Low byte contains e8m0 of our input; truncate uint16 -> uint8
        exponent = scale_e8m0_u16.to(torch.uint8)
    else:
        exponent = _f32_to_e8m0_rceil(descale)

    rcp_fp32 = _e8m0_scale_to_reciprocal_fp32(exponent)

    # Scale the data
    data_lp = data_hp * rcp_fp32

    return exponent, data_lp


def to_mx(
    data_hp: torch.Tensor,
    elem_dtype: Union[torch.dtype, str],
    block_size: int,
    scaling_mode: ScaleCalculationMode = ScaleCalculationMode.FLOOR,
    is_swizzled_scales: bool = False,
):
    """
    Takes a high precision tensor and converts to MX scale and raw data, in
    naive layout (scale and raw data are separate tensors).
    """
    assert data_hp.dtype in (
        torch.bfloat16,
        torch.float,
    ), f"{data_hp.dtype} is not supported yet"
    # TODO(future PR): consider supporting padding
    assert data_hp.shape[-1] % block_size == 0, (
        f"the last dimension of shape {data_hp.shape} must be divisible by block_size {block_size}"
    )
    assert data_hp.is_contiguous(), "unsupported"
    assert elem_dtype in SUPPORTED_ELEM_DTYPES, "unsupported"

    orig_shape = data_hp.shape
    data_hp = data_hp.reshape(
        *orig_shape[:-1], orig_shape[-1] // block_size, block_size
    )

    # find max value of the data
    # Note: this only implements the `minimally supported` version of
    # https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf
    # section 6.3.

    # Calculate max_abs normally (torch.amax returns NaN if any input is NaN)
    max_abs = torch.amax(torch.abs(data_hp), -1).unsqueeze(-1)

    # We cast to float32 here because
    # in the `max_abs_int32 = max_abs.view(hp_int_dtype)` line below,
    # if tensor parallel is enabled then the resulting shape is 2x larger
    # than it should be under some conditions, likely because of a bug in
    # the `view` op with DTensor and target dtype int16.  I reproduce in
    # torchtitan but not in a unit test, so not enough info to file a good
    # issue in pytorch/pytorch. For now, work around. In the future we should
    # debug and fix this properly.
    data_hp = data_hp.to(torch.float32)
    max_abs = max_abs.to(torch.float32)

    # Set X to be the largest power-of-two less than or equal to
    # max_abs(v), divided by the largest power of two representable
    # in the element data type, and get the mbits at the same time
    if elem_dtype == torch.float8_e4m3fn:
        target_max_pow2 = F8E4M3_MAX_POW2
        mbits = MBITS_F8_E4M3
        max_pos = F8E4M3_MAX
    elif elem_dtype == torch.float8_e5m2:
        target_max_pow2 = F8E5M2_MAX_POW2
        mbits = MBITS_F8_E5M2
        max_pos = F8E5M2_MAX
    elif elem_dtype == DTYPE_FP6_E2M3:
        target_max_pow2 = F6_E2M3_MAX_POW2
        mbits = MBITS_F6_E2M3
        max_pos = F6_E2M3_MAX
    elif elem_dtype == DTYPE_FP6_E3M2:
        target_max_pow2 = F6_E3M2_MAX_POW2
        mbits = MBITS_F6_E3M2
        max_pos = F6_E3M2_MAX
    elif elem_dtype == torch.float4_e2m1fn_x2:
        target_max_pow2 = F4_E2M1_MAX_POW2
        mbits = MBITS_F4_E2M1
        max_pos = F4_E2M1_MAX
    else:
        raise AssertionError("unsupported element dtype")

    if scaling_mode == ScaleCalculationMode.RCEIL:
        scale_e8m0_biased, data_lp = _to_mx_rceil(data_hp, max_abs, max_pos)
    else:
        assert data_hp.dtype is torch.float32
        hp_int_dtype = torch.int32
        hp_mbits = MBITS_F32
        hp_ebits = EBITS_F32
        hp_exp_bias = F32_EXP_BIAS

        # rounding before calculating the largest power of 2
        # X = 2^(floor(log2(rounding(max_abs(v)))-max_exp))
        if scaling_mode == ScaleCalculationMode.EVEN:
            nan_mask = torch.isnan(max_abs)
            max_abs = max_abs.view(hp_int_dtype)
            val_to_add = 1 << (hp_mbits - mbits - 1)
            mask = ((1 << (hp_ebits + SBITS)) - 1) << hp_mbits
            max_abs = (max_abs + val_to_add) & mask
            max_abs = max_abs.view(data_hp.dtype)
            max_abs[nan_mask] = torch.tensor(
                float("nan"), device=max_abs.device, dtype=max_abs.dtype
            )

        # Calculate the scale for different modes
        max_abs_int32 = max_abs.view(hp_int_dtype)
        # For now, use `torch.bitwise_right_shift` instead of `>>` to support DTensor
        # See https://github.com/pytorch/pytorch/issues/156533.
        extracted_pow2 = (
            (torch.bitwise_right_shift(max_abs_int32, hp_mbits)) & 0b11111111
        ) - hp_exp_bias

        if scaling_mode in (ScaleCalculationMode.FLOOR, ScaleCalculationMode.EVEN):
            scale_e8m0_unbiased = extracted_pow2 - target_max_pow2
        elif scaling_mode == ScaleCalculationMode.CEIL:
            # round up: add one to scale if the mantissa is larger than 0
            # 0x7FFFFF is equal to 23 ones
            mantissa_gt_one = (max_abs_int32 & 0x7FFFFF) > 0
            extracted_pow2 += mantissa_gt_one
            scale_e8m0_unbiased = extracted_pow2 - target_max_pow2
        else:
            raise AssertionError("unsupported scaling calculation mode")

        # Clamp to exponents that can be represented in e8m0
        # add one to positive range to capture NaNs
        scale_e8m0_unbiased = torch.clamp(
            scale_e8m0_unbiased, min=-E8M0_EXPONENT_BIAS, max=E8M0_EXPONENT_BIAS + 1
        )

        # Create the biased e8m0 representation and cast it to 8 bits
        scale_e8m0_biased = scale_e8m0_unbiased + E8M0_EXPONENT_BIAS
        scale_e8m0_biased = scale_e8m0_biased.to(torch.uint8)

        # No-saturation E8M0 conversion maps both NaN and Inf to 0xff.
        scale_e8m0_biased = torch.where(
            torch.isfinite(max_abs),
            scale_e8m0_biased,
            E8M0_EXPONENT_NAN_VAL,
        )

        inv_scale = _e8m0_scale_to_reciprocal_fp32(scale_e8m0_biased)
        data_lp = data_hp * inv_scale

        needs_eager_saturation = elem_dtype == torch.float8_e5m2 or (
            elem_dtype == torch.float8_e4m3fn and not _TORCH_VERSION_AT_LEAST_2_13
        )
        if needs_eager_saturation and not torch._dynamo.is_compiling():
            # Before PyTorch 2.13, eager casts for e4m3 did not saturate finite
            # overflow values, so torchao clamps before casting. Triton
            # casts saturate, if we are compute bound we see a speedup if we remove
            # this redundant clamp (in the case of compiling to Triton)
            # TODO(#1912): PyTorch core fixed eager saturation in
            # https://github.com/pytorch/pytorch/pull/178817 and
            # https://github.com/pytorch/pytorch/pull/177870. Remove this
            # workaround after torchao stops supporting PyTorch <2.13.
            data_lp = torch.clamp(data_lp, min=-1 * max_pos, max=max_pos)

    # cast to target dtype
    if elem_dtype in (torch.float8_e4m3fn, torch.float8_e5m2):
        data_lp = data_lp.to(elem_dtype)
        # need to reshape at the end to help inductor fuse things
        data_lp = data_lp.reshape(orig_shape)
    elif elem_dtype == DTYPE_FP6_E2M3:
        data_lp = f32_to_f6_e2m3_unpacked(data_lp)
        # need to reshape at the end to help inductor fuse things
        data_lp = data_lp.reshape(orig_shape)
    elif elem_dtype == DTYPE_FP6_E3M2:
        data_lp = f32_to_f6_e3m2_unpacked(data_lp)
        # need to reshape at the end to help inductor fuse things
        data_lp = data_lp.reshape(orig_shape)
    elif elem_dtype == torch.float4_e2m1fn_x2:
        # can't reshape at the end without handling it in the packing code,
        # punt until later since we'll need to rethink the torch.compile
        # approach for fp4x2 in any case
        data_lp = data_lp.reshape(orig_shape)
        data_lp = f32_to_f4_unpacked(data_lp)
        data_lp = pack_uint4(data_lp)
    else:
        raise AssertionError("unsupported")

    scale_e8m0_biased = scale_e8m0_biased.view(torch.float8_e8m0fnu)
    scale_e8m0_biased = scale_e8m0_biased.squeeze(-1)

    # if user requested scale swizzling, do it here
    if is_swizzled_scales:
        leading_dims, M, K = orig_shape[:-2], orig_shape[-2], orig_shape[-1]
        scale_shape = (math.prod(leading_dims) * M, K // block_size)
        scale = to_blocked(scale_e8m0_biased.view(scale_shape)).flatten()
        scale_M, scale_K = hp_data_dims_to_swizzled_scale_dims_mx(M, K)
        scale_e8m0_biased = scale.view(*leading_dims, scale_M, scale_K)

    return scale_e8m0_biased, data_lp


def get_fp_scale(scale_e8m0):
    scale_e8m0 = scale_e8m0.view(torch.uint8)
    s_offset = scale_e8m0.to(torch.int16) - E8M0_EXPONENT_BIAS
    # TODO(later): it would be nice if there was a way to do the 2^x operation
    # in PyTorch without creating a tensor of twos
    two = torch.full_like(s_offset, 2.0, dtype=torch.float32)
    # pow(two, s_offset) can be out of range of floating point formats.
    # TODO(later): handle this for float16 if we decide to support float16
    # scales.
    s_fp = torch.pow(two, s_offset)

    # If a block exponent was 255, set values of that block to NaN
    s_fp = torch.where(scale_e8m0 != E8M0_EXPONENT_NAN_VAL, s_fp, float("nan"))

    return s_fp


def to_dtype(
    data_lp,
    scale_e8m0,
    elem_dtype,
    block_size,
    target_dtype,
):
    orig_shape = data_lp.shape
    is_transposed = not data_lp.is_contiguous()
    # if the underlying data is transposed, convert to row major before
    # unpacking and unscaling
    if is_transposed:
        data_lp = data_lp.t()
        scale_e8m0 = scale_e8m0.t()
        assert data_lp.is_contiguous()
        orig_shape = (orig_shape[1], orig_shape[0])

    if elem_dtype in (torch.float8_e4m3fn, torch.float8_e5m2):
        data_hp = data_lp.to(target_dtype)
    elif elem_dtype == DTYPE_FP6_E2M3:
        data_hp = f6_e2m3_unpacked_to_f32(data_lp)
        data_hp = data_hp.to(target_dtype).reshape(orig_shape)
    elif elem_dtype == DTYPE_FP6_E3M2:
        data_hp = f6_e3m2_unpacked_to_f32(data_lp)
        data_hp = data_hp.to(target_dtype).reshape(orig_shape)
    elif elem_dtype == torch.float4_e2m1fn_x2:
        # fp4
        f4_unpacked = unpack_uint4(data_lp)
        # for now we only have a cast to f32
        # TODO(future PR): add cast directly to bf16
        f32 = f4_unpacked_to_f32(f4_unpacked)
        data_hp = f32.to(target_dtype)
        # manually adjust shape to account for the unpacking
        # TODO(future PR): clean up the shape code and remove the hack
        # below
        orig_shape = (*orig_shape[:-1], orig_shape[-1] * 2)
    else:
        raise AssertionError("unsupported")

    data_hp = data_hp.reshape(-1, block_size)
    s_fp = get_fp_scale(scale_e8m0).reshape(-1, 1).to(target_dtype)
    data_hp = data_hp * s_fp
    data_hp = data_hp.reshape(orig_shape)

    # if we converted to row-major before unscaling convert back
    if is_transposed:
        data_hp = data_hp.t()

    return data_hp


def tensor_size_hp_to_fp4x2(orig_size, is_contiguous):
    new_size = orig_size
    if is_contiguous:
        new_size = [*list(new_size[:-1]), new_size[-1] // 2]
    else:
        if len(orig_size) == 2:
            new_size = [new_size[0] // 2, *list(new_size[1:])]
        else:
            assert len(orig_size) == 3, "unsupported"
            # only supporting dim0, dim1, dim2 and dim0, dim2, dim1 orders
            new_size = [new_size[0], new_size[1] // 2, new_size[2]]
    return new_size


def tensor_size_fp4x2_to_hp(orig_size, is_contiguous):
    new_size = orig_size
    if is_contiguous:
        new_size = [*list(new_size[:-1]), new_size[-1] * 2]
    else:
        if len(orig_size) == 2:
            new_size = [new_size[0] * 2, *list(new_size[1:])]
        else:
            assert len(orig_size) == 3, "unsupported"
            # only supporting dim0, dim1, dim2 and dim0, dim2, dim1 orders
            new_size = [new_size[0], new_size[1] * 2, new_size[2]]
    return new_size


class MXTensor(TorchAOBaseTensor):
    tensor_data_names = ["qdata", "scale"]
    tensor_attribute_names = [
        "elem_dtype",
        "block_size",
        "orig_dtype",
        "kernel_preference",
        "act_quant_kwargs",
        "is_swizzled_scales",
    ]

    def __new__(
        cls,
        qdata,
        scale,
        elem_dtype,
        block_size,
        orig_dtype,
        kernel_preference,
        act_quant_kwargs,
        is_swizzled_scales,
    ):
        new_size = qdata.size()
        if elem_dtype == torch.float4_e2m1fn_x2:
            # set the tensor size to what it would be without 2x4 packing
            # Note: `is_contiguous` is going to return True for a tensor of size
            # (M, 1) regardless or the order of dims, so this logic is currently
            # broken for tensors of size (M, 1) or (1, M). Leaving broken until
            # a time when fixing this becomes important.
            new_size = tensor_size_fp4x2_to_hp(
                new_size,
                qdata.is_contiguous(),
            )
        self = torch.Tensor._make_wrapper_subclass(
            cls,
            new_size,
            strides=qdata.stride(),
            storage_offset=qdata.storage_offset(),
            layout=qdata.layout,
            dtype=orig_dtype,
            device=qdata.device,
        )
        if elem_dtype in (torch.float8_e4m3fn, torch.float8_e5m2):
            assert qdata.dtype == elem_dtype, (
                f"qdata.dtype must match elem_dtype for MXFP8 tensors, got {qdata.dtype=} and {elem_dtype=}"
            )
        assert scale.dtype == torch.float8_e8m0fnu, (
            f"scale.dtype must be `torch.float8_e8m0fnu`, got {scale.dtype}"
        )
        assert qdata.dtype in (
            torch.float8_e4m3fn,
            torch.float8_e5m2,
            torch.uint8,
        ), "unsupported"
        self.qdata = qdata
        self.scale = scale
        self.elem_dtype = elem_dtype
        self.block_size = block_size
        self.orig_dtype = orig_dtype
        self.kernel_preference = kernel_preference
        self.act_quant_kwargs = act_quant_kwargs
        self.is_swizzled_scales = is_swizzled_scales
        return self

    def __repr__(self):
        # TODO better elem dtype print for fp4
        return f"MXTensor: elem_dtype: {self.elem_dtype}, s_e8m0: {self.scale}, d: {self.qdata}, act_quant_kwargs: {self.act_quant_kwargs}, is_swizzled_scales={self.is_swizzled_scales}"  # noqa: E501

    def _quantization_type(self):
        return f"{self.elem_dtype=}, {self.block_size=}, {self.orig_dtype=}, {self.kernel_preference=}, {self.act_quant_kwargs=}"

    def dequantize(self, output_dtype: Optional[torch.dtype] = None) -> torch.Tensor:
        if output_dtype is None:
            output_dtype = self.dtype

        scale = self.scale
        if self.is_swizzled_scales:
            is_transposed = self.qdata.stride(-2) < self.qdata.stride(-1)
            if is_transposed:
                leading_dims, M, K = self.shape[:-2], self.shape[-1], self.shape[-2]
                scale = scale.transpose(-2, -1)
            else:
                leading_dims, M, K = self.shape[:-2], self.shape[-2], self.shape[-1]
            scale = from_blocked(
                scale, math.prod(leading_dims) * M, K // self.block_size
            )
            scale = scale.view(*leading_dims, M, K // self.block_size)
            if is_transposed:
                scale = scale.transpose(-2, -1)

        return to_dtype(
            self.qdata,
            scale,
            self.elem_dtype,
            self.block_size,
            output_dtype,
        )

    @staticmethod
    @torch._dynamo.allow_in_graph
    def from_qdata_and_scales(
        qdata: torch.Tensor,
        scales: torch.Tensor,
        orig_dtype: torch.dtype,
        *,
        block_size: int = BLOCK_SIZE_DEFAULT,
        kernel_preference: Optional[KernelPreference] = None,
        act_quant_kwargs: Optional[QuantizeTensorToMXKwargs] = None,
        is_swizzled_scales: bool = False,
    ) -> Union["MXTensor", DTensor]:
        assert qdata.dtype != torch.uint8, (
            "from_qdata_and_scales only supports typed MX qdata; "
            "use MXTensor(...) directly for packed uint8 payloads"
        )
        elem_dtype = qdata.dtype

        return MXTensor(
            qdata,
            scales,
            elem_dtype,
            block_size,
            orig_dtype,
            kernel_preference,
            act_quant_kwargs,
            is_swizzled_scales,
        )

    @staticmethod
    @torch._dynamo.allow_in_graph
    def to_mx(
        data_hp: torch.Tensor,
        elem_dtype: Union[torch.dtype, str],
        block_size: int = BLOCK_SIZE_DEFAULT,
        # TODO(future PR): flip the scaling_mode default to RCEIL
        scaling_mode: ScaleCalculationMode = ScaleCalculationMode.FLOOR,
        # TODO(future PR): switch default gemm to cublas
        kernel_preference: KernelPreference = KernelPreference.EMULATED,
        act_quant_kwargs: Optional[QuantizeTensorToMXKwargs] = None,
        is_swizzled_scales: bool = False,
        mxfp8_dim0_cast_kernel_choice: MXFP8Dim0CastKernelChoice = MXFP8Dim0CastKernelChoice.TORCH,
    ):
        assert mxfp8_dim0_cast_kernel_choice in (
            MXFP8Dim0CastKernelChoice.TRITON,
            MXFP8Dim0CastKernelChoice.TORCH,
        ), (
            f"unsupported kernel choice for mxfp8_dim0_cast_kernel_choice: {mxfp8_dim0_cast_kernel_choice}"
        )

        triton_kernel_supported = (
            elem_dtype == torch.float8_e4m3fn and not is_swizzled_scales
        )
        if (
            mxfp8_dim0_cast_kernel_choice == MXFP8Dim0CastKernelChoice.TORCH
            or kernel_preference == KernelPreference.EMULATED
        ):
            scale_e8m0_biased, data_lp = to_mx(
                data_hp, elem_dtype, block_size, scaling_mode, is_swizzled_scales
            )
        else:
            assert triton_kernel_supported, (
                f"triton kernel unsupported for {data_hp.dtype=}, {elem_dtype=}, {scaling_mode=}, {is_swizzled_scales=}"
            )
            data_lp, scale_e8m0_biased = triton_to_mxfp8_dim0(
                data_hp,
                inner_block_size=block_size,
                scaling_mode=scaling_mode.value,
            )
        return MXTensor(
            data_lp,
            scale_e8m0_biased,
            elem_dtype,
            block_size,
            data_hp.dtype,
            kernel_preference,
            act_quant_kwargs,
            is_swizzled_scales,
        )

    # Do not force the MXTensor type on the returned tensor
    __torch_function__ = torch._C._disabled_torch_function_impl


implements = MXTensor.implements


@implements([aten.detach.default, aten.alias.default])
def _(func, types, args, kwargs):
    return return_and_correct_aliasing(
        func, args, kwargs, args[0]._apply_fn_to_data(func)
    )


@implements([aten.is_pinned.default])
def mx_is_pinned(func, types, args, kwargs):
    return args[0].qdata.is_pinned() and args[0].scale.is_pinned()


@implements([aten._pin_memory.default])
def mx_pin_memory(func, types, args, kwargs):
    tensor = args[0]
    return MXTensor(
        tensor.qdata.pin_memory(),
        tensor.scale.pin_memory(),
        tensor.elem_dtype,
        tensor.block_size,
        tensor.orig_dtype,
        tensor.kernel_preference,
        tensor.act_quant_kwargs,
        tensor.is_swizzled_scales,
    )


def _get_gemm_choice(
    choice_a: Optional[KernelPreference], choice_b: Optional[KernelPreference]
) -> KernelPreference:
    if choice_a is not None and choice_b is not None:
        assert choice_a == choice_b, (
            "Both MXTensor inputs must have the same gemm config if specified"
        )
        return choice_a

    # Assert that at least one is set and return that one
    assert choice_a is not None or choice_b is not None, (
        "At least one gemm choice must be specified"
    )
    return choice_a if choice_a is not None else choice_b


def _addmm_mx_dispatch(
    a: torch.Tensor, b: MXTensor, aten_op, bias: Optional[torch.Tensor] = None
) -> torch.Tensor:
    """
    Core implementation shared between mx_mm and mx_addmm.
    The only difference is whether bias is None or not.
    """

    if not isinstance(a, MXTensor):
        assert b.act_quant_kwargs is not None, "weight-only quant not yet supported"
        k = b.act_quant_kwargs
        a = MXTensor.to_mx(
            a,
            k.elem_dtype,
            k.block_size,
            k.scaling_mode,
            k.kernel_preference,
            is_swizzled_scales=k.is_swizzled_scales,
        )

    gemm_choice = _get_gemm_choice(a.kernel_preference, b.kernel_preference)

    if gemm_choice == KernelPreference.AUTO:
        # real MX gemm backed by torchao's CUTLASS kernels
        M, K, N = a.shape[0], a.shape[1], b.shape[1]
        assert a.qdata.is_contiguous()
        assert b.qdata.t().is_contiguous()
        assert a.block_size == 32, f"Invalid block size {a.block_size}"
        assert b.block_size == 32, f"Invalid block size {b.block_size}"
        assert a.is_swizzled_scales == b.is_swizzled_scales

        if a.is_swizzled_scales:
            a_scale_block = a.scale
        else:
            a_scale_block = a.scale.view(M, K // a.block_size)

        if b.is_swizzled_scales:
            b_scale_block = b.scale.t()
        else:
            b_scale_block = b.scale.t().view(N, K // b.block_size)

        swizzle = (
            SwizzleType.SWIZZLE_32_4_4
            if a.is_swizzled_scales
            else SwizzleType.NO_SWIZZLE
        )
        res = F.scaled_mm(
            a.qdata.view(a.elem_dtype),
            b.qdata.view(b.elem_dtype),
            scale_a=a_scale_block.view(torch.float8_e8m0fnu),
            scale_recipe_a=ScalingType.BlockWise1x32,
            scale_b=b_scale_block.view(torch.float8_e8m0fnu),
            scale_recipe_b=ScalingType.BlockWise1x32,
            swizzle_a=swizzle,
            swizzle_b=swizzle,
            bias=bias,
            output_dtype=torch.bfloat16,
        )

    else:
        assert gemm_choice == KernelPreference.EMULATED, "unimplemented"
        # emulated MX gemm
        a_hp = a.dequantize(a.orig_dtype)
        b_hp = b.dequantize(b.orig_dtype)
        # assert memory layout we expect to be required in hardware
        assert a_hp.is_contiguous()
        assert b_hp.t().is_contiguous()

        # Call appropriate aten_op based on whether bias is provided
        if bias is not None:
            res = aten_op(bias, a_hp, b_hp)  # addmm
        else:
            res = aten_op(a_hp, b_hp)  # mm

    return res


@implements([aten.mm.default, aten.matmul.default])
def mx_mm(func, types, args, kwargs):
    a = args[0]
    b = args[1]
    assert isinstance(b, MXTensor)

    return _addmm_mx_dispatch(a, b, func)


@implements([aten.addmm.default])
def mx_addmm(func, types, args, kwargs):
    assert isinstance(args[0], torch.Tensor) and isinstance(args[2], MXTensor)
    bias = args[0]
    a = args[1]
    b = args[2]
    return _addmm_mx_dispatch(a, b, func, bias=bias)


@implements([aten.linear.default])
def mx_linear(func, types, args, kwargs):
    assert isinstance(args[0], torch.Tensor) and isinstance(args[1], MXTensor)
    a = args[0]

    # make a 2d
    orig_a_shape = a.shape
    a_2d = a.view(-1, orig_a_shape[-1])

    b = args[1].t()
    if len(args) > 2:
        bias = args[2]
        res = _addmm_mx_dispatch(a_2d, b, aten.addmm.default, bias)
    else:
        res = _addmm_mx_dispatch(a_2d, b, aten.mm.default)

    # reshape back to original shape
    res = res.view(*orig_a_shape[:-1], res.shape[-1])
    return res


@implements([aten.t.default])
def mx_t(func, types, args, kwargs):
    # For now, only transpose(input, 0, 1) is supported.
    old = args[0]
    new = MXTensor(
        old.qdata.t(),
        old.scale.t(),
        old.elem_dtype,
        old.block_size,
        old.orig_dtype,
        old.kernel_preference,
        old.act_quant_kwargs,
        old.is_swizzled_scales,
    )
    return new


@implements([aten.sum.dim_IntList])
def mx_cast_up_op(func, types, args, kwargs):
    """Be careful with this function, this is a "fallback" op that
    casts the output of the op to the original precision. And performs the op.

    We currently need this to support the backward for admmm bias.
    "addmm" -> out
    "hp_gradBias" <-"sum" <- "identity" <- gradOut <- "hp_gradOut"
    """

    def unwrap(x):
        if isinstance(x, MXTensor):
            return x.dequantize(x.orig_dtype)
        return x

    new_args = tree_map(unwrap, args)
    new_kwargs = tree_map(unwrap, kwargs)
    return func(*new_args, **new_kwargs)


@implements([aten.view.default])
def mx_view_op(func, types, args, kwargs):
    data = args[0].qdata
    new_size = args[1]
    if args[0].elem_dtype == torch.float4_e2m1fn_x2:
        # special case fp4 as we pack two elements per byte
        new_size = tensor_size_hp_to_fp4x2(new_size, data.is_contiguous())
    new_data = func(data, new_size, *args[2:], **kwargs)
    return MXTensor(
        new_data,
        args[0].scale,
        args[0].elem_dtype,
        args[0].block_size,
        args[0].orig_dtype,
        args[0].kernel_preference,
        args[0].act_quant_kwargs,
        args[0].is_swizzled_scales,
    )


@implements([aten.slice.Tensor])
def mx_slice(func, types, args, kwargs):
    x, dim, start, end, step = fill_defaults(args, 5, [0, None, None, 1])

    if step != 1:
        raise ValueError("Only support aten.slice with step=1")

    sliced_data, sliced_scale = _swizzle_aware_slice(x, dim, start, end, step)

    return return_and_correct_aliasing(
        func,
        args,
        kwargs,
        MXTensor(
            sliced_data,
            sliced_scale,
            x.elem_dtype,
            x.block_size,
            x.orig_dtype,
            x.kernel_preference,
            x.act_quant_kwargs,
            x.is_swizzled_scales,
        ),
    )


@implements([aten.cat.default])
def mx_cat(func, types, args, kwargs):
    tensors = args[0]
    dim = args[1] if len(args) > 1 else kwargs.get("dim", 0)
    # An empty list cannot dispatch to MXTensor. Reject mixed subclasses before
    # accessing their quantization metadata.
    if not all(isinstance(tensor, MXTensor) for tensor in tensors):
        raise TypeError("MXTensor.cat expects only MXTensor inputs")
    first = tensors[0]
    if dim < -first.ndim or dim >= first.ndim:
        raise IndexError(
            f"Dimension out of range (expected to be in range of "
            f"[{-first.ndim}, {first.ndim - 1}], but got {dim})"
        )
    if dim < 0:
        dim += first.ndim
    if first.ndim != 2 or dim != 0:
        raise NotImplementedError("MXTensor only supports cat of 2D tensors at dim=0")
    metadata = (
        first.elem_dtype,
        first.block_size,
        first.orig_dtype,
        first.kernel_preference,
        first.act_quant_kwargs,
        first.is_swizzled_scales,
    )
    for tensor in tensors:
        tensor_metadata = (
            tensor.elem_dtype,
            tensor.block_size,
            tensor.orig_dtype,
            tensor.kernel_preference,
            tensor.act_quant_kwargs,
            tensor.is_swizzled_scales,
        )
        if tensor_metadata != metadata:
            raise ValueError("MXTensor.cat requires matching quantization metadata")
        if tensor.ndim != 2:
            raise NotImplementedError("MXTensor.cat requires 2D tensors")
        if not tensor.qdata.is_contiguous():
            raise NotImplementedError("MXTensor.cat requires contiguous qdata")
    if first.is_swizzled_scales and any(tensor.shape[0] % 128 for tensor in tensors):
        raise NotImplementedError(
            "MXTensor.cat requires swizzled scale inputs to align to 128-row tiles"
        )

    qdata = aten.cat.default([tensor.qdata for tensor in tensors], 0)
    # Concatenate scale bytes: CUDA cat does not support every E8M0 layout.
    # Aligned swizzled inputs already contain complete row tiles in order.
    scale_bytes = [tensor.scale.view(torch.uint8) for tensor in tensors]
    scale = aten.cat.default(scale_bytes, 0)
    return MXTensor(
        qdata,
        scale.view(torch.float8_e8m0fnu),
        first.elem_dtype,
        first.block_size,
        first.orig_dtype,
        first.kernel_preference,
        first.act_quant_kwargs,
        first.is_swizzled_scales,
    )


@implements([aten.clone.default])
def mx_clone(func, types, args, kwargs):
    self = args[0]
    memory_format = kwargs.get("memory_format", None)

    if memory_format is not None:
        clone_fn = lambda x: x.clone(memory_format=memory_format)
    else:
        clone_fn = lambda x: x.clone()

    return self._apply_fn_to_data(clone_fn)


@implements([aten.select.int])
def mx_select(func, types, args, kwargs):
    old_mx_tensor, dim, index = args
    assert dim == 0, f"MXTensor aten.select.int with {dim=} is not yet supported"
    assert len(old_mx_tensor.qdata.shape) == len(old_mx_tensor.scale.shape), (
        "unsupported"
    )
    assert not old_mx_tensor.is_swizzled_scales, "unsupported"
    new_mx_tensor = old_mx_tensor.__class__(
        old_mx_tensor.qdata[index],
        old_mx_tensor.scale[index],
        old_mx_tensor.elem_dtype,
        old_mx_tensor.block_size,
        old_mx_tensor.orig_dtype,
        old_mx_tensor.kernel_preference,
        old_mx_tensor.act_quant_kwargs,
        old_mx_tensor.is_swizzled_scales,
    )
    return return_and_correct_aliasing(func, args, kwargs, new_mx_tensor)


@implements([torch.ops._c10d_functional.all_gather_into_tensor.default])
def mx_all_gather(func, types, args, kwargs):
    """
    All-gather for MXTensor

    Args:
        func: The operation (all_gather_into_tensor)
        types: Tensor types involved
        args: (mx_tensor, group_tag, ...)
        kwargs: Additional arguments
    """
    mx_tensor = args[0]
    group_tag = args[1] if len(args) > 1 else "default"

    # TODO: Add support for concat CC as a future optimization

    # Gather both data and scale
    gathered_qdata = torch.ops._c10d_functional.all_gather_into_tensor.default(
        mx_tensor.qdata,  # The quantized data
        group_tag,
        *args[2:],
        **kwargs,
    )

    gathered_scale = torch.ops._c10d_functional.all_gather_into_tensor.default(
        mx_tensor.scale.view(
            torch.uint8
        ),  # The scale factors, Need to cast to uint8 as float8_e8m0fnu is not support for all gather.
        group_tag,
        *args[2:],
        **kwargs,
    )

    gathered_scale = gathered_scale.view(torch.float8_e8m0fnu)

    # Return new MXTensor with gathered data
    return MXTensor(
        gathered_qdata,
        gathered_scale,
        mx_tensor.elem_dtype,
        mx_tensor.block_size,
        mx_tensor.orig_dtype,
        mx_tensor.kernel_preference,
        mx_tensor.act_quant_kwargs,
        mx_tensor.is_swizzled_scales,
    )


@implements([torch.ops._c10d_functional.wait_tensor.default])
def mx_wait_tensor(func, types, args, kwargs):
    """
    Wait for async collective to complete on MXTensor

    This is called after collectives like all_gather to ensure
    the operation has completed before using the tensor.
    """
    mx_tensor = args[0]

    # Wait on both components
    waited_qdata = torch.ops._c10d_functional.wait_tensor.default(
        mx_tensor.qdata, *args[1:], **kwargs
    )

    waited_scale = torch.ops._c10d_functional.wait_tensor.default(
        mx_tensor.scale, *args[1:], **kwargs
    )

    return MXTensor(
        waited_qdata,
        waited_scale,
        mx_tensor.elem_dtype,
        mx_tensor.block_size,
        mx_tensor.orig_dtype,
        mx_tensor.kernel_preference,
        mx_tensor.act_quant_kwargs,
        mx_tensor.is_swizzled_scales,
    )
