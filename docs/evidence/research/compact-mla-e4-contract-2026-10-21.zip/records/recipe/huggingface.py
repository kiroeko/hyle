# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Support quantization for huggingface layers."""

import inspect
import logging
import warnings
from contextlib import contextmanager
from functools import partial
from typing import TYPE_CHECKING

import torch
import torch.nn as nn
import transformers
from packaging import version
from torch import Tensor
from torch.nn.functional import linear
from transformers.models.t5.modeling_t5 import T5Attention

from modelopt.torch.kernels.common.attention import IS_AVAILABLE as TRITON_FA_AVAILABLE
from modelopt.torch.kernels.common.attention import (
    triton_attention_forward,
    validate_triton_attention_envelope,
)
from modelopt.torch.kernels.quantization.gemm import IS_AVAILABLE as IS_TRITON_AVAILABLE
from modelopt.torch.opt.dynamic import DynamicModule
from modelopt.torch.utils.distributed import ParallelState

from ..algorithms import AutoQuantizeGradientSearcher
from ..conversion import register
from ..nn import QuantInputBase, QuantModule, QuantModuleRegistry, TensorQuantizer
from ..nn.modules.quant_linear import _QuantLinear
from ..utils import replace_function, sync_moe_expert_amax
from ..utils.layerwise_calib import LayerActivationCollector
from .attention import register_attention_for_kv_quant
from .custom import CUSTOM_MODEL_PLUGINS, _ParallelLinear, _QuantFunctionalMixin

logger = logging.getLogger(__name__)

try:
    from torch.distributed.tensor import Shard
except ImportError:
    Shard = None

try:
    import kitchen
    from kitchen.fa import KitchenFlashAttentionModule
    from kitchen.triton_module import triton_fa_params
except ImportError:
    kitchen = None

if IS_TRITON_AVAILABLE:
    from modelopt.torch.kernels.quantization.gemm import weight_dequant
else:
    weight_dequant = None

if TYPE_CHECKING:
    from types import ModuleType

__all__ = ["register_hf_attentions_on_the_fly"]

TRANSFORMERS_VERSION_GE_5_0 = version.parse(transformers.__version__) >= version.parse("5.0.0")


class _QuantAttention(QuantModule):
    """Attention class for KV Cache quantization compatible with new_attention_interface in transformers >= 4.48.0."""

    def _setup(self):
        self.q_bmm_quantizer = TensorQuantizer()
        self.k_bmm_quantizer = TensorQuantizer()
        self.v_bmm_quantizer = TensorQuantizer()
        self.p_bmm_quantizer = TensorQuantizer()
        self.kitchen_attn_fn = None
        self.use_kitchen = False

    def _init_kitchen_attn_fn(self):
        if not self.p_bmm_quantizer.is_enabled:
            self.kitchen_attn_fn = "disabled"
            return
        self.use_kitchen = True
        if self.p_bmm_quantizer.is_mxfp(8):
            qfa_params = triton_fa_params.QTritonFAParams(
                backend="triton",
                qk_dot_precisions="bf16@bf16",
                pv_dot_precisions="mxfp8_e4m3_emulation@bf16",
                dp_v_x_do_dot_precisions="bf16@bf16",
                dp_do_x_v_dot_precisions="bf16@bf16",
                dq_ds_x_k_dot_precisions="bf16@bf16",
                dk_ds_x_q_dot_precisions="bf16@bf16",
                dv_p_x_do_dot_precisions="bf16@bf16",
                use_natural_transcendental_func=False,  # Different from default
            )
        else:
            raise NotImplementedError(f"p_bmm_quantizer not supported: {self.p_bmm_quantizer}")

        self.kitchen_attn_fn = KitchenFlashAttentionModule(
            num_attention_heads=self.config.num_attention_heads,
            kv_channels=self.config.head_dim,
            num_gqa_groups=None,  # self.config.num_key_value_heads, kitchen does not support gqa.
            attention_dropout=self.config.attention_dropout,
            qkv_format="sbhd",  # this is not used at all, but in forward, this is the only supported format.
            attn_mask_type="causal",
            window_size=getattr(self.config, "sliding_window", None),
            sequence_parallel=False,
            get_rng_state_tracker=None,
            layer_number=None,
            attention_type="self",
            softmax_scale=None,  # This will be convert to the same default as sdpa: 1/sqrt(dim_q)
            qfa_params=qfa_params,
        )

    def _p_qdq_mode(self) -> str | None:
        """Map the p_bmm_quantizer config to a Triton P quant-dequant mode.

        Returns "fp8" for per-tensor E4M3, "nvfp4" for dynamic E2M1 with
        block-16 E4M3 scales, or None when the p_bmm_quantizer is disabled
        or its format is not supported by the built-in Triton kernel
        (e.g. MXFP8, which goes through kitchen).
        """
        pq = self.p_bmm_quantizer
        if not pq.is_enabled:
            return None
        if pq.is_fp8:
            return "fp8"
        # Only dynamic NVFP4 maps to the kernel, and only at block size 16 (the kernel
        # hardcodes it). Static (calibrated) NVFP4 is excluded because is_nvfp4_dynamic
        # requires dynamically-computed block scales.
        if pq.is_nvfp4_dynamic and (pq.block_sizes or {}).get(-1, None) == 16:
            return "nvfp4"
        return None

    def _triton_qdq_attention(self, p_qdq, query_states, key_states, value_states, **kwargs):
        """Quantized attention via the built-in Triton kernel (no kitchen required).

        Fake quant-dequant of the softmax probabilities (P) is fused into the
        flash-attention kernel; see ``p_qdq`` in
        :func:`modelopt.torch.kernels.common.attention.triton_fa.attention`.

        Inputs outside the kernel/wrapper envelope (sliding window, sinks,
        softcapping, non-causal masks, ...) raise ``NotImplementedError``
        instead of silently computing wrong attention; see
        :func:`validate_triton_attention_envelope
        <modelopt.torch.kernels.common.attention.hf_triton_attention.validate_triton_attention_envelope>`.
        """
        if not TRITON_FA_AVAILABLE:
            raise RuntimeError(
                f"p_bmm_quantizer ({p_qdq}) requires the Triton attention kernel. "
                "Install triton with `pip install triton` and run on a CUDA device."
            )
        assert (
            triton_attention_forward is not None and validate_triton_attention_envelope is not None
        )
        attention_mask = kwargs.pop("attention_mask", None)
        validate_triton_attention_envelope(self, query_states, key_states, attention_mask, **kwargs)

        # Forward a user-set or calibrated per-tensor amax to the kernel, which
        # converts it to the FP8 / NVFP4 scale. Without one, the kernel default
        # amax of 1.0 applies -- the theoretical upper bound of the unnormalized
        # P's amax (P lies in [0, 1]).
        p_qdq_amax = None
        pq_amax = getattr(self.p_bmm_quantizer, "_amax", None)
        if pq_amax is not None:
            if pq_amax.numel() != 1:
                raise NotImplementedError(
                    "p_bmm_quantizer via the Triton attention kernel only supports a "
                    f"per-tensor (scalar) amax, got shape {tuple(pq_amax.shape)}."
                )
            p_qdq_amax = float(pq_amax)

        scaling = kwargs.get("scaling")
        if scaling is None:
            scaling = query_states.shape[-1] ** -0.5
        return triton_attention_forward(
            self,
            query_states,
            key_states,
            value_states,
            attention_mask,
            scaling,
            p_qdq=p_qdq,
            p_qdq_amax=p_qdq_amax,
        )

    def _eager_p_qdq_attention(
        self, original_attention_interface, query_states, key_states, value_states, **kwargs
    ):
        """Apply ``p_bmm_quantizer`` to the softmax output via an eager wrapper.

        For attention outside the causal-only Triton kernel's envelope (e.g. ViT's
        non-causal attention). Swapping ``F.softmax`` for a quantized version keeps
        the quantizer in the traced graph so ONNX / Torch-TRT export emits Q/DQ
        around the softmax probabilities. Requires an eager attention
        implementation; SDPA-fused softmax (computed inside the C++ kernel) is
        unaffected.
        """
        _pq = self.p_bmm_quantizer
        _orig_softmax = torch.nn.functional.softmax

        def _quantized_softmax(*s_args, **s_kwargs):
            return _pq(_orig_softmax(*s_args, **s_kwargs))

        with replace_function(torch.nn.functional, "softmax", _quantized_softmax):
            return original_attention_interface(
                self, query_states, key_states, value_states, **kwargs
            )

    @staticmethod
    def _quantized_attention(
        original_attention_interface,
        self,
        query_states,
        key_states,
        value_states,
        *args,
        **kwargs,
    ):
        query_states = self.q_bmm_quantizer(query_states)
        key_states = self.k_bmm_quantizer(key_states)
        value_states = self.v_bmm_quantizer(value_states)

        # FP8 / NVFP4 P quant-dequant runs on the built-in Triton kernel
        # and takes priority over kitchen (which handles MXFP8).
        p_qdq = self._p_qdq_mode()
        if p_qdq is not None:
            # The attention interface passes attention_mask as the only
            # positional argument after q/k/v; everything else is a kwarg.
            if args:
                kwargs["attention_mask"] = args[0]
            # The built-in Triton P kernel is causal-only. Non-causal attention
            # (e.g. ViT) applies p_bmm_quantizer through an eager softmax wrapper
            # that stays export-traceable for ONNX / Torch-TRT instead.
            if kwargs.get("is_causal") is False or getattr(self, "is_causal", True) is False:
                return self._eager_p_qdq_attention(
                    original_attention_interface, query_states, key_states, value_states, **kwargs
                )
            return self._triton_qdq_attention(
                p_qdq, query_states, key_states, value_states, **kwargs
            )

        if kitchen is not None and self.kitchen_attn_fn is None:
            self._init_kitchen_attn_fn()
        if not self.use_kitchen:
            return original_attention_interface(
                self, query_states, key_states, value_states, *args, **kwargs
            )

        query_sequence_length = query_states.shape[2]
        if query_states.shape[2] < key_states.shape[2]:  # For decoding stage.
            shape = list(query_states.shape)
            shape[2] = key_states.shape[2] - query_states.shape[2]
            query_states = torch.cat(
                [
                    torch.empty(shape, dtype=query_states.dtype, device=query_states.device),
                    query_states,
                ],
                dim=2,
            )

        n_repeat = self.config.num_attention_heads // self.config.num_key_value_heads
        if n_repeat > 1:
            key_states = key_states.repeat_interleave(n_repeat, dim=1)
            value_states = value_states.repeat_interleave(n_repeat, dim=1)
        # kitchen only supports sbhd. we have bhsd.
        query_states = query_states.permute(2, 0, 1, 3)
        key_states = key_states.permute(2, 0, 1, 3)
        value_states = value_states.permute(2, 0, 1, 3)
        attn_out = self.kitchen_attn_fn(query_states, key_states, value_states)
        attn_out = attn_out[-query_sequence_length:, :, :]
        # output is sb(h*d), we need bshd
        attn_out = attn_out.reshape(
            (attn_out.shape[0], attn_out.shape[1], query_states.shape[2], -1)
        ).permute(1, 0, 2, 3)
        return attn_out.contiguous(), None

    def forward(self, *args, **kwargs):
        """Forward method for KV cache quantization compatible with new_attention_interface in transformers >= 4.48.0.

        The forward method is used to patch the attention interface with _quantized_attention.
        Once output tensors are generated, it restores the original attention interface.
        """
        # In transformers>=5.0 some attention classes (e.g. BertAttention) no longer store
        # `self.config` directly; fall back to searching child modules for a config attribute.
        _config = getattr(self, "config", None)
        if _config is None:
            _config = next(
                (getattr(m, "config", None) for m in self.children() if hasattr(m, "config")),
                None,
            )
        _attn_impl = getattr(_config, "_attn_implementation", None) if _config is not None else None

        def _is_eager_attention():
            if _attn_impl is None or _attn_impl == "eager":
                return True
            return bool(_attn_impl == "sdpa" and kwargs.get("output_attentions", False))

        # Get the original transformers module before wrapped in any ModelOpt DynamicModule
        module: ModuleType = inspect.getmodule(self.get_attn_type(self))

        # Preprocessing logic to patch attention interface
        original_attention_interface = (
            module.eager_attention_forward
            if _is_eager_attention()
            else module.ALL_ATTENTION_FUNCTIONS[_attn_impl]
        )
        patch_fn = partial(self._quantized_attention, original_attention_interface)

        if _is_eager_attention():
            if not hasattr(module, "eager_attention_forward"):
                raise AssertionError(
                    f"Module {module} does not have `eager_attention_forward` to enable KV Cache quantization. "
                    "Please use a different attention implementation such as `sdpa` by setting "
                    "`model.config._attn_implementation = 'sdpa'` before quantization."
                )
            module.eager_attention_forward = patch_fn  # type: ignore[attr-defined]
        else:
            module.ALL_ATTENTION_FUNCTIONS[_attn_impl] = patch_fn

        try:
            outputs = super().forward(*args, **kwargs)
        finally:
            # Cleanup logic to restore the original attention interface
            if _is_eager_attention():
                module.eager_attention_forward = original_attention_interface  # type: ignore[attr-defined]
            else:
                module.ALL_ATTENTION_FUNCTIONS[_attn_impl] = original_attention_interface

        return outputs

    @staticmethod
    def is_compatible_attention(attn):
        # The new_attention_interface is only available in transformers >= 4.48.0
        # In addition, the new attention interface is not available for some models such as T5
        # Hence lets do a crude check here to see if the attention module is using the new_attention_interface
        # This is not foolproof but should work for most cases
        module = inspect.getmodule(attn)
        return getattr(module, "ALL_ATTENTION_FUNCTIONS", None) is not None

    @staticmethod
    def get_attn_type(attn_module) -> type:
        # If this is a DynamicModule, it means that the module class has been wrapped by ModelOpt
        # Hence, we need to get the original class by level=0
        return (
            attn_module.get_original_cls_by_level(level=0)
            if isinstance(attn_module, DynamicModule)
            else type(attn_module)
        )


class _T5QuantAttention(QuantModule):
    """Attention class for KV Cache quantization compatible with T5 Model."""

    def _quantized_matmul(self, batch1, batch2):
        # T5Attention has two matmul operations, one for the query and key and one for the attention and value.
        # The first matmul is quantized with the q_bmm_quantizer and k_bmm_quantizer. The second matmul is
        # quantized with the v_bmm_quantizer.
        if self.qk_quant_matmul:
            self.qk_quant_matmul = False
            q, k = batch1, batch2
            return torch._matmul(
                self.q_bmm_quantizer(q), self.k_bmm_quantizer(k.transpose(3, 2)).transpose(3, 2)
            )
        else:
            self.qk_quant_matmul = True
            attn, v = batch1, batch2
            return torch._matmul(attn, self.v_bmm_quantizer(v))

    def _setup(self):
        self.q_bmm_quantizer = TensorQuantizer(QuantInputBase.default_quant_desc_input)
        self.k_bmm_quantizer = TensorQuantizer(QuantInputBase.default_quant_desc_input)
        self.v_bmm_quantizer = TensorQuantizer(QuantInputBase.default_quant_desc_input)

    @staticmethod
    def is_compatible_attention(attn):
        return issubclass(attn, T5Attention)

    def forward(self, *args, **kwargs):
        # self.qk_quant_matmul is used to alternate between the two matmul operations for T5Attention
        self.qk_quant_matmul = True
        with replace_function(torch, "matmul", self._quantized_matmul):
            return super().forward(*args, **kwargs)


def _wraps_nested_attention(module):
    """Return True when ``module`` contains another Attention child on this specific instance.

    Checked per-instance (not by class) so an attention class reused as both wrapper and
    leaf is not dropped everywhere. In a 3-level hierarchy (Outer → Middle → Inner), both
    Outer and Middle are treated as wrappers and only Inner is registered for KV-cache
    quantization. Used to avoid double-patching ``eager_attention_forward`` when a wrapper
    attention module (e.g. ``ViTAttention``) delegates to a nested self-attention child
    (e.g. ``ViTSelfAttention``).
    """
    return any(
        child is not module and type(child).__name__.endswith("Attention")
        for _, child in module.named_modules()
    )


def register_hf_attentions_on_the_fly(model):
    """Find HF Attention modules in the model and register them for KV Cache quantization.

    This function attempts to find child modules ending with "Attention" in the name.
    If such child modules are not found, or the corresponding class does not contain
    identifiable attention patterns, the function will not register any new modules.
    """
    if not _is_supported_hf_model(model):
        return

    attention_cls = set()
    registered_attn_module = False

    for name, module in model.named_modules():
        # Only register attention classes that are from Huggingface transformers
        if type(module).__name__.endswith("Attention"):
            if _wraps_nested_attention(module):
                continue
            attention_type = _QuantAttention.get_attn_type(module)
            # Add modules to be registered only if they arent already registered
            if (
                QuantModuleRegistry.get(attention_type) is None
                and attention_type not in attention_cls
            ):
                if _QuantAttention.is_compatible_attention(attention_type):
                    # Lets register the attention class for KV Cache quantization
                    register(attention_type, _QuantAttention)
                    registered_attn_module = True
                    print(
                        f"Registered {attention_type} to {_QuantAttention.__name__} for KV Cache quantization"
                    )
                elif _T5QuantAttention.is_compatible_attention(attention_type):
                    register(attention_type, _T5QuantAttention)
                    registered_attn_module = True
                    print(
                        f"Registered {attention_type} to {_T5QuantAttention.__name__} for KV Cache quantization"
                    )
                else:
                    attention_cls.add(attention_type)
                    print(
                        f"Registered {attention_type} to AST based quantized class for KV Cache quantization"
                    )

    # Check if the attention class has been registered
    # For T5Attention, we want to avoid registering T5LayerCrossAttention and T5LayerSelfAttention.
    # Hence we check if the attention class has been registered.
    if registered_attn_module or not attention_cls:
        return

    # this is the case for models that do not use the new_attention_interface or transformers version < 4.48.0
    # Register the attention class for KV Cache quantization
    success = any(register_attention_for_kv_quant(cls) for cls in attention_cls)
    if not success:
        warnings.warn(
            f"Could not create a quantized attention class for  {attention_cls} from this model. "
            "To enable KV Cache quantization, please create a custom quantized attention class for this model and "
            "register it to ModelOpt using `mtq.register` "
            "(see https://nvidia.github.io/Model-Optimizer/guides/_pytorch_quantization.html#custom-quantized-module-and-quantizer-placement)"
        )


class HFParallelLinear(torch.nn.Linear, DynamicModule):
    supported_hf_tp_plans = []
    shard = None

    def _setup(self):
        if isinstance(self.weight, torch.distributed.tensor.DTensor):  # transformers<5.0
            assert self.weight.placements == self.shard, (
                f"Received unexpected shard {self.weight.placements} for {self}"
            )
            device_mesh = self.weight.device_mesh
        else:  # transformers>=5.0: weights are plain Parameters, mesh is on the module
            device_mesh = self._hf_device_mesh
        tp_group = device_mesh.get_group()
        self._parallel_state = ParallelState(data_parallel_group=-1, tensor_parallel_group=tp_group)

    @classmethod
    def is_compatible(cls, linear) -> bool:
        if not isinstance(linear, torch.nn.Linear):
            return False
        if not hasattr(linear, "_hf_tp_plan"):
            return False
        return linear._hf_tp_plan in cls.supported_hf_tp_plans

    # This is hack for now, otherwise DMRegistry treats this class same as nn.Linear
    def forward(self, x):
        return super().forward(x)


class HFColumnParallelLinear(HFParallelLinear):
    supported_hf_tp_plans = ["colwise", "colwise_rep"]
    shard = (Shard(0),) if Shard is not None else None


class HFRowParallelLinear(HFParallelLinear):
    supported_hf_tp_plans = ["rowwise", "rowwise_rep"]
    shard = (Shard(1),) if Shard is not None else None


class _QuantHFParallelLinear(_ParallelLinear):
    _functionals_to_replace = [(torch.nn.functional, "linear")]

    def fold_weight(self, keep_attrs: bool = False):
        with self.enable_weight_access_and_writeback():
            super().fold_weight(keep_attrs)

    @contextmanager
    def enable_weight_access_and_writeback(self):
        if isinstance(self.weight, torch.distributed.tensor.DTensor):  # transformers<5.0
            assert self.weight.placements == self.shard, (
                f"Received unexpected shard {self.weight.placements} for {self}"
            )
            weight = self.weight
            # TODO: To support TP + FSDP, we need to redistribute the tensor with replicate instead of shard
            self.weight = nn.Parameter(weight.to_local())
            try:
                yield
            finally:
                self.weight = weight
        else:  # transformers>=5.0: weights are already plain Parameters
            yield


@QuantModuleRegistry.register({HFColumnParallelLinear: "HFColumnParallelLinear"})
class QuantHFColumnParallelLinear(_QuantHFParallelLinear):
    _is_column_parallel = True


@QuantModuleRegistry.register({HFRowParallelLinear: "HFRowParallelLinear"})
class QuantHFRowParallelLinear(_QuantHFParallelLinear):
    _is_row_parallel = True


def convert_hf_parallel_linears_on_the_fly(model):
    """Convert nn.Linear layers that have been TP sharded by HF.

    Huggingface shards regular nn.Linear layers to rowwise or columnwise tensor-parallel layers dynamically.
    This method converts them to `HFColumnParallelLinear` and `HFRowParallelLinear` so that they
    can be treated as TP sharded layers and not like regular nn.Linear layers.
    """
    for name, module in model.named_modules():
        if HFColumnParallelLinear.is_compatible(module):
            HFColumnParallelLinear.convert(module)
        elif HFRowParallelLinear.is_compatible(module):
            HFRowParallelLinear.convert(module)


if transformers.pytorch_utils.Conv1D not in QuantModuleRegistry:
    # transformers.pytorch_utils.Conv1D used in HF-GPT2 is not a real Conv1D
    # It is actually a Linear layer where weight is transposed and torch.addmm is used
    @QuantModuleRegistry.register({transformers.pytorch_utils.Conv1D: "Conv1D"})
    class _QuantConv1D(_QuantLinear):
        @classmethod
        @torch.no_grad()
        def convert(cls, module: nn.Module) -> "_QuantConv1D":
            module.weight = nn.Parameter(module.weight.T.contiguous())
            module.out_features, module.in_features = module.weight.shape
            # We want the forward method of nn.Linear to be called instead of the forward method of Conv1D
            dyn_cls: QuantModule = QuantModuleRegistry.get(nn.Linear)
            return dyn_cls.convert(module)


class _TransposedQuantization(torch.autograd.Function):
    """Applies transposed quantization.

    This is useful for weight quantization of some MoEs such as gpt-oss or Llama4 which has expert weights
    of shape (num_experts, in_dim, out_dim). Per-channel/Per-block quantization from ModelOpt
    assumes that `in_dim` is -1 dim. Hence for quantizing such MoE weights, lets use transposed quantization.
    """

    # Note: TransposedQuantization uses STE with no clipping
    @staticmethod
    def forward(ctx, inputs, quantizer):
        return quantizer(inputs.transpose(-1, -2).contiguous()).transpose(-1, -2)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output, None


_transposed_quantize = _TransposedQuantization.apply


class _TransposedExpertsCalibMixin:
    """Weight-only calibration for BMM-style experts that quantize their weights transposed.

    ``_QuantGptOssExperts`` / ``_QuantLlama4TextExperts`` hold 3-D expert weights of shape
    ``(num_experts, in_dim, out_dim)`` and quantize them *transposed* in the forward (see
    :class:`_TransposedQuantization`: per-channel / per-block quantization expects the
    contraction ``in_dim`` as the last axis). Weight-only calibration
    (``max_calibrate`` -> ``weight_only_quantize``) must feed the weight quantizer the same
    transposed view; otherwise static-block NVFP4 locks ``_original_shape`` from the
    non-transposed weight and the forward then raises "Input shape has changed".
    Calibrating transposed also matches the orientation the unified HF export reads ``_amax``
    in (it transposes BMM expert weights before deriving scales).

    The transposed view is not made contiguous (unlike the forward's ``_transposed_quantize``,
    which needs it for the matmul): calibration only reads the shape and reduces for ``_amax``,
    both of which the quantizer handles on a non-contiguous view via ``reshape``.

    For ``_QuantGptOssExperts`` ``gate_up_proj``/``down_proj`` are dynamic attributes; weight-only
    calibration runs with weight quantization disabled, so they return the raw weight here.
    """

    def iter_weights_for_calibration(self):
        """Yield ``(transposed_weight, weight_quantizer)`` for each expert projection."""
        for weight_name in ("gate_up_proj", "down_proj"):
            weight = getattr(self, weight_name)
            yield weight.transpose(-1, -2), getattr(self, f"{weight_name}_weight_quantizer")


class _QuantSparseSequentialMoe(QuantModule):
    """Quantization wrapper for HuggingFace sparse MoE blocks.

    This base class is for Sequential MoEs (i.e each experts are implemented as standalone modules).
    Transformers>=5.0 has batched experts, no per-expert quantizers.

    Supports ``layer_sync_moe_local_experts_amax`` to sync input quantizer amax across experts.

    Optionally supports config-driven features (disabled by default):
    - ``_moe_calib_experts_ratio``: force-forward tokens to more experts during calibration.
      When set to a value > 0, also enables token counting per expert.

    When disabled, forward is a direct pass-through with zero overhead.
    """

    def _setup(self):
        self._moe_calib_experts_ratio = None
        self._token_counting_initialized = False

    def _init_token_counting(self):
        """Lazy-init token counting infra (buffer + gate hook). Called once from forward."""
        self._token_counting_initialized = True
        num_experts = 0
        for obj in [getattr(self, "gate", None), self, getattr(self, "experts", None)]:
            if obj is not None:
                for attr in ("num_experts", "n_routed_experts"):
                    if hasattr(obj, attr):
                        num_experts = getattr(obj, attr)
                        break
            if num_experts:
                break

        if num_experts == 0:
            warnings.warn(
                f"{self.__class__.__name__}: could not resolve num_experts; "
                "expert routing will not be tracked for this layer."
            )
            return

        self.register_buffer(
            "expert_token_count",
            torch.zeros(num_experts, dtype=torch.long, device=next(self.parameters()).device),
            persistent=False,
        )
        self._count_expert_tokens = False
        if hasattr(self, "gate"):
            self.gate.register_forward_hook(self._gate_forward_hook)

    def _gate_forward_hook(self, module, input, output):
        if not self._count_expert_tokens:
            return
        with torch.no_grad():
            if isinstance(output, tuple) and len(output) >= 3:
                # v5.x TopKRouter: returns (logits, scores, indices)
                indices = output[2]
            else:
                # v4.x nn.Linear gate: returns logits tensor
                logits = output if not isinstance(output, tuple) else output[0]
                top_k = self.gate.top_k if hasattr(self.gate, "top_k") else self.top_k
                _, indices = torch.topk(logits.float(), top_k, dim=-1)
            counts = torch.bincount(indices.reshape(-1), minlength=self.expert_token_count.shape[0])
            self.expert_token_count += counts.to(self.expert_token_count.device)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        if self._moe_calib_experts_ratio is None:
            return super().forward(hidden_states)

        is_calib = any(getattr(m, "_if_calib", False) for m in self.experts.modules())

        # During calibration, forward all tokens to a larger fraction of experts to improve
        # calibration coverage, then re-run with the original top_k for actual outputs.
        if is_calib:
            # Skip counting when all experts are calibrated (ratio == 1.0).
            self._count_expert_tokens = self._moe_calib_experts_ratio < 1.0
            if self._count_expert_tokens and not self._token_counting_initialized:
                self._init_token_counting()
            if TRANSFORMERS_VERSION_GE_5_0:
                assert hasattr(self, "gate") and hasattr(self.gate, "top_k")
                original_top_k = self.gate.top_k
                self.gate.top_k = max(
                    original_top_k, round(self.gate.num_experts * self._moe_calib_experts_ratio)
                )
                super().forward(hidden_states)
                self.gate.top_k = original_top_k
            else:
                # Path for transformers<5.0
                if hasattr(self, "gate") and hasattr(self.gate, "top_k"):
                    top_k_owner = self.gate
                else:
                    top_k_owner = self
                original_top_k = top_k_owner.top_k
                if hasattr(self, "num_experts"):
                    top_k_owner.top_k = max(
                        original_top_k, round(self.num_experts * self._moe_calib_experts_ratio)
                    )
                elif hasattr(self, "experts"):
                    num_experts = (
                        self.experts.num_experts
                        if hasattr(self.experts, "num_experts")
                        else len(self.experts)
                    )
                    top_k_owner.top_k = max(
                        original_top_k,
                        round(num_experts * self._moe_calib_experts_ratio),
                    )
                else:
                    raise ValueError(f"Could not find num_experts in module {self}")
                super().forward(hidden_states)
                top_k_owner.top_k = original_top_k
            self._count_expert_tokens = False

        output = super().forward(hidden_states)
        self._count_expert_tokens = False
        return output

    def layer_sync_moe_local_experts_amax(self, sync_weight_amax=False):
        """Sync input_quantizer amax across experts so all share the same amax per quantizer.

        Skipped when _moe_calib_experts_ratio is set, as each expert is calibrated independently.
        Also skipped when experts is a fused module (e.g. Llama4TextExperts) with shared quantizers.

        Args:
            sync_weight_amax: If True, also sync weight quantizer amax across experts.

        """
        if self._moe_calib_experts_ratio is not None:
            return
        sync_moe_expert_amax(self.experts, sync_weight_amax=sync_weight_amax)


class _QuantLlama4TextExperts(_TransposedExpertsCalibMixin, QuantModule):
    def _setup(self):
        self.gate_up_proj_input_quantizer = TensorQuantizer()
        self.gate_up_proj_weight_quantizer = TensorQuantizer()
        self.down_proj_input_quantizer = TensorQuantizer()
        self.down_proj_weight_quantizer = TensorQuantizer()

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = hidden_states.view(self.num_experts, -1, self.hidden_size)
        gate_up = torch.bmm(
            self.gate_up_proj_input_quantizer(hidden_states),
            _transposed_quantize(self.gate_up_proj, self.gate_up_proj_weight_quantizer),
        )
        gate, up = gate_up.chunk(2, dim=-1)  # not supported for DTensors
        next_states = torch.bmm(
            self.down_proj_input_quantizer(up * self.act_fn(gate)),
            _transposed_quantize(self.down_proj, self.down_proj_weight_quantizer),
        )
        next_states = next_states.view(-1, self.hidden_size)
        return next_states


# For more information on DbrxExpert, see https://github.com/huggingface/transformers/blob/dcdda532/src/transformers/models/dbrx/modeling_dbrx.py#L756
class _QuantDbrxExperts(QuantModule):
    def _setup(self):
        """Modify the DbrxExpert."""
        # No setup is needed for DbrxExpert, we only need to update DbrxExpertGLU

    def forward(
        self,
        x: torch.Tensor,
        top_experts: torch.LongTensor,
        top_weights: torch.Tensor,
    ) -> torch.Tensor:
        bsz, q_len, hidden_size = x.shape
        x = x.view(-1, hidden_size)
        out = torch.zeros_like(x)

        expert_mask = nn.functional.one_hot(top_experts, num_classes=self.num_experts).permute(
            2, 1, 0
        )
        for expert_idx in range(self.num_experts):
            topk_idx, token_idx = torch.where(expert_mask[expert_idx])
            if token_idx.shape[0] == 0:
                continue

            token_list = token_idx.tolist()
            topk_list = topk_idx.tolist()

            expert_tokens = x[None, token_list].reshape(-1, hidden_size)
            expert_out = (
                self.mlp(expert_tokens, expert_idx) * top_weights[token_list, topk_list, None]
            )

            out.index_add_(0, token_idx, expert_out)

        out = out.reshape(bsz, q_len, hidden_size)
        return out


class _QuantDbrxExpertGLU(QuantModule):
    def _setup(self):
        """Modify the DbrxExpertGLU by using nn.Linear layers."""
        dtype, device = self.w1.dtype, self.w1.device

        def _copy_weights(modules, weights):
            modules.to(dtype=dtype, device=device)
            for expert_idx, module in enumerate(modules):
                with torch.no_grad():
                    module.weight.copy_(weights[expert_idx].detach())

        # In transformers 5.0, DbrxExpertGLU.forward uses raw matmul: x @ w1[i] where
        # w1[i] has shape (ffn_hidden_size, hidden_size). To match via F.linear (which
        # computes x @ W.T), we store weights transposed: W = w1[i].T.
        self.w1_linear = nn.ModuleList(
            [
                nn.Linear(self.ffn_hidden_size, self.hidden_size, bias=False)
                for _ in range(self.moe_num_experts)
            ]
        )
        _copy_weights(
            self.w1_linear,
            self.w1.view(self.moe_num_experts, self.ffn_hidden_size, self.hidden_size).transpose(
                1, 2
            ),
        )
        delattr(self, "w1")

        self.v1_linear = nn.ModuleList(
            [
                nn.Linear(self.ffn_hidden_size, self.hidden_size, bias=False)
                for _ in range(self.moe_num_experts)
            ]
        )
        _copy_weights(
            self.v1_linear,
            self.v1.view(self.moe_num_experts, self.ffn_hidden_size, self.hidden_size).transpose(
                1, 2
            ),
        )
        delattr(self, "v1")

        # w2: down_proj uses intermediate.matmul(w2[i].t()) = F.linear(intermediate, w2[i])
        # so W = w2[i] directly (no extra transpose needed).
        self.w2_linear = nn.ModuleList(
            [
                nn.Linear(self.hidden_size, self.ffn_hidden_size, bias=False)
                for _ in range(self.moe_num_experts)
            ]
        )
        _copy_weights(
            self.w2_linear,
            self.w2.view(self.moe_num_experts, self.ffn_hidden_size, self.hidden_size),
        )
        delattr(self, "w2")

    def forward(self, x: torch.Tensor, expert_idx: int) -> torch.Tensor:
        x1 = self.w1_linear[expert_idx](x)
        x2 = self.v1_linear[expert_idx](x)
        x1 = self.activation_fn(x1)
        x1 = x1 * x2
        return self.w2_linear[expert_idx](x1)


class _QuantQwen3VLMoeTextExperts(QuantModule):
    """Quantized wrapper for the pre-transformers-5.12 ``Qwen3VLMoeTextExperts`` layout.

    That layout stores ``gate_up_proj`` as (num_experts, hidden_size, 2*expert_dim) and runs
    the experts through ``torch.bmm``/``@``, so it is unrolled into ``nn.Linear`` modules here.
    transformers>=5.12 moved this module to the standard fused layout handled by
    :class:`_QuantFusedExperts`; see the registration site below.
    """

    def _setup(self):
        """Modify the Qwen3VLMoeTextExperts by using nn.Linear layers."""
        from accelerate import init_empty_weights

        dtype, device = self.gate_up_proj.dtype, self.gate_up_proj.device

        def _copy_weight(module, weight):
            module.to_empty(device=device)
            with torch.no_grad():
                module.weight.data = weight.detach().data.to(dtype=dtype, device=device)

        # The attribute name was changed from `intermediate_size` to `intermediate_dim` in
        # https://github.com/huggingface/transformers/commit/0642963ba13f2dae0596fe489415569e1d91fbda
        if hasattr(self, "intermediate_size"):
            expert_dim = self.intermediate_size
        elif hasattr(self, "intermediate_dim"):
            expert_dim = self.intermediate_dim
        else:
            raise AttributeError("Could not find intermediate dimension size in model")

        with init_empty_weights():
            gate_proj = nn.ModuleList(
                [
                    nn.Linear(self.hidden_size, expert_dim, bias=False)
                    for _ in range(self.num_experts)
                ]
            )
            up_proj = nn.ModuleList(
                [
                    nn.Linear(self.hidden_size, expert_dim, bias=False)
                    for _ in range(self.num_experts)
                ]
            )
            down_proj = nn.ModuleList(
                [
                    nn.Linear(expert_dim, self.hidden_size, bias=False)
                    for _ in range(self.num_experts)
                ]
            )

        for idx in range(self.num_experts):
            _copy_weight(gate_proj[idx], self.gate_up_proj[idx, :, :expert_dim].T)
            _copy_weight(up_proj[idx], self.gate_up_proj[idx, :, expert_dim:].T)
            _copy_weight(down_proj[idx], self.down_proj[idx, :].T)

        delattr(self, "gate_up_proj")
        delattr(self, "down_proj")
        self.gate_proj = gate_proj
        self.up_proj = up_proj
        self.down_proj = down_proj

    def forward(
        self,
        hidden_states: torch.Tensor,
        routing_weights: torch.Tensor,
        router_indices: torch.Tensor,
    ) -> torch.Tensor:
        batch_size = hidden_states.shape[0]
        hidden_states = hidden_states.reshape(-1, self.hidden_size)
        next_states = torch.zeros_like(hidden_states)
        with torch.no_grad():
            expert_mask = torch.nn.functional.one_hot(router_indices, num_classes=self.num_experts)
            expert_mask = expert_mask.permute(2, 1, 0)
            expert_hit = torch.greater(expert_mask.sum(dim=(-1, -2)), 0).nonzero()
        for expert_idx in expert_hit:
            with torch.no_grad():
                _, token_idx = torch.where(expert_mask[expert_idx[0]])
            current_state = hidden_states[token_idx]
            gate = self.gate_proj[expert_idx](current_state)
            up = self.up_proj[expert_idx](current_state)
            gated_output = up * self.act_fn(gate)
            out = self.down_proj[expert_idx](gated_output)
            weighted_output = out * routing_weights[token_idx, expert_idx, None]
            next_states.index_add_(0, token_idx, weighted_output.to(hidden_states.dtype))
        next_states = next_states.view(batch_size, -1, self.hidden_size)

        return next_states


def _get_fused_expert_intermediate_dim(module):
    """Resolve the intermediate (expert) dimension from a fused expert module.

    Different transformers versions use ``intermediate_size`` or ``intermediate_dim``.
    """
    for attr in ("intermediate_dim", "intermediate_size", "moe_intermediate_size"):
        if hasattr(module, attr):
            return getattr(module, attr)
    return module.gate_up_proj.shape[1] // 2


class _QuantFusedExperts(_QuantFunctionalMixin):
    """Generic quantized wrapper for HuggingFace fused MoE expert modules.

    Handles any module following the standard HF transformers 5.0+ fused expert
    pattern (``@use_experts_implementation``):

    * ``gate_up_proj``: 3-D ``nn.Parameter`` of shape ``(num_experts, 2*intermediate_dim, hidden_dim)``
    * ``down_proj``:    3-D ``nn.Parameter`` of shape ``(num_experts, hidden_dim, intermediate_dim)``
    * ``act_fn``:       activation function applied between gate/up and down projections
    * ``forward``:      calls ``F.linear`` exactly twice per expert (gate_up then down)

    Per-expert quantization is achieved by intercepting ``F.linear`` and recovering
    the expert index from the weight tensor's storage offset into the 3-D parameter.
    Each expert gets its own weight quantizers (``nn.ModuleList``), while input
    quantizers are shared across all experts (single ``TensorQuantizer``) to match
    the shared input quantization scale used by downstream inference frameworks.

    Verified compatible models: Mixtral, Qwen2-MoE, Qwen3-MoE, Qwen3.5-MoE,
    DeepSeek-V3, Jamba, OLMoE.

    Limitation: only works when ``experts_implementation="eager"`` (default).
    ``batched_mm`` / ``grouped_mm`` backends use ``torch.bmm`` /
    ``torch._grouped_mm`` instead of ``F.linear`` and are not intercepted.

    The non-gated variant (``up_proj`` instead of ``gate_up_proj``, used by
    NemotronH) is handled by :class:`_QuantNonGatedFusedExperts` via the
    ``_first_proj_attr`` / ``_is_gated`` hooks below; each layout names the
    first-projection quantizers after its backing parameter.
    """

    # Name of the 3-D weight parameter feeding the first ``F.linear`` per expert.
    # Gated experts fuse gate+up into ``gate_up_proj``; non-gated experts use a
    # single ``up_proj`` (see _QuantNonGatedFusedExperts).
    _first_proj_attr = "gate_up_proj"
    # Whether the first projection packs a gate half that must be split on export.
    _is_gated = True

    @property
    def _first_proj_input_quantizer_attr(self) -> str:
        return f"{self._first_proj_attr}_input_quantizer"

    @property
    def _first_proj_weight_quantizers_attr(self) -> str:
        return f"{self._first_proj_attr}_weight_quantizers"

    def _get_expert_idx_from_first_proj(self, weight: torch.Tensor) -> int:
        """Recover expert index from a first-projection weight slice's storage offset.

        When HF indexes ``<first_proj>[idx]``, the result is a view sharing the
        same underlying storage.  The offset delta divided by the stride along
        dim-0 gives the expert index.

        The invariant breaks if the tensor is ``.contiguous()``-copied or
        redistributed by certain distributed wrappers (FSDP2, tensor parallel).
        """
        first_proj = getattr(self, self._first_proj_attr)
        base_offset = first_proj.storage_offset()
        stride = first_proj.stride(0)
        if stride == 0:
            return 0
        idx = (weight.storage_offset() - base_offset) // stride
        assert 0 <= idx < self.num_experts, (
            f"Computed expert index {idx} out of range [0, {self.num_experts}). "
            "This can happen if the weight was .contiguous()-copied or redistributed."
        )
        return idx

    def _setup(self):
        n = self.num_experts
        setattr(self, self._first_proj_input_quantizer_attr, TensorQuantizer())
        setattr(
            self,
            self._first_proj_weight_quantizers_attr,
            nn.ModuleList([TensorQuantizer() for _ in range(n)]),
        )
        self.down_proj_input_quantizer = TensorQuantizer()
        self.down_proj_weight_quantizers = nn.ModuleList([TensorQuantizer() for _ in range(n)])

        self._register_temp_attribute("_down_proj_linear", False)
        self._register_temp_attribute("_current_expert_idx", 0)

    @property
    def functionals_to_replace(self):
        _orig_linear = torch.nn.functional.linear

        # The HF fused expert forward calls F.linear exactly twice per expert
        # in strict alternation: first for gate_up_proj, then for down_proj.
        # forward() resets the toggle before each call to super().forward().
        def _quantized_linear(input, weight, bias=None):
            if self._down_proj_linear:
                idx = self._current_expert_idx
                input = self.down_proj_input_quantizer(input)
                weight = self.down_proj_weight_quantizers[idx](weight)
            else:
                idx = self._get_expert_idx_from_first_proj(weight)
                self._current_expert_idx = idx
                input = getattr(self, self._first_proj_input_quantizer_attr)(input)
                weight = getattr(self, self._first_proj_weight_quantizers_attr)[idx](weight)
            self._down_proj_linear = not self._down_proj_linear
            return _orig_linear(input, weight, bias)

        return [
            (torch.nn.functional, "linear", _quantized_linear),
        ]

    def forward(self, *args, **kwargs):
        self._down_proj_linear = False
        return super().forward(*args, **kwargs)

    def iter_weights_for_calibration(self):
        """Yield ``(weight_slice, quantizer)`` per-expert pairs.

        The base impl uses singular ``*_weight_quantizer`` and skips fused-
        experts modules, so weight-only calibration never reaches per-expert
        quantizers without this override.
        """
        for weight_name, quantizers_name in (
            (self._first_proj_attr, self._first_proj_weight_quantizers_attr),
            ("down_proj", "down_proj_weight_quantizers"),
        ):
            weight = getattr(self, weight_name, None)
            quantizers = getattr(self, quantizers_name, None)
            if weight is None or quantizers is None:
                continue
            for idx, q in enumerate(quantizers):
                yield weight[idx], q

    def fold_weight(self, keep_attrs: bool = False):
        """Bake each per-expert weight quantizer into its slice of the fused 3-D weight.

        The base ``fold_weight`` only handles singular ``*_weight_quantizer`` attributes and
        would skip the ``nn.ModuleList`` of per-expert quantizers used here. The per-expert
        ``(weight_slice, quantizer)`` pairs are the same ones :meth:`iter_weights_for_calibration`
        yields, so we reuse it; each fake-quant quantizer's quantization and rotation are folded
        in and disabled, and calibration buffers are dropped unless ``keep_attrs``.
        """
        for weight_slice, q in self.iter_weights_for_calibration():
            if isinstance(q, TensorQuantizer) and q.fake_quant:
                self._fold_weight_quantizer(q, (weight_slice,), keep_attrs)


class _QuantNonGatedFusedExperts(_QuantFusedExperts):
    """Quantized wrapper for non-gated fused MoE experts.

    Used by NemotronH (transformers 5.5+ ``NemotronHExperts``), whose experts
    are a *non-gated* MLP: a single ``up_proj`` (no gate half) and a ``down_proj``,
    both stored as 3-D ``nn.Parameter`` s indexed per expert.
    """

    _first_proj_attr = "up_proj"
    _is_gated = False


def _get_fused_experts_quantizer_attr_names(module):
    """Return quantizer attribute names for a converted fused-experts module."""
    first_proj_attr = getattr(module, "_first_proj_attr", "gate_up_proj")
    return (
        f"{first_proj_attr}_input_quantizer",
        f"{first_proj_attr}_weight_quantizers",
        "down_proj_input_quantizer",
        "down_proj_weight_quantizers",
    )


def _is_quant_fused_experts_module(module):
    """Return True for a converted HF fused-MoE-experts quantization wrapper."""
    return isinstance(module, _QuantFusedExperts)


class _QuantDbrxFFN(_QuantSparseSequentialMoe):
    @property
    def num_experts(self):
        return self.router.moe_num_experts

    @property
    def top_k(self):
        # In older transformers, top_k was stored on DbrxRouter as moe_top_k.
        # In transformers 5.0, DbrxFFN stores it as a plain attribute (top_k).
        if hasattr(self.router, "moe_top_k"):
            return self.router.moe_top_k
        return self.__dict__.get("top_k", 1)

    @top_k.setter
    def top_k(self, value):
        if hasattr(self.router, "moe_top_k"):
            self.router.moe_top_k = value
        else:
            self.__dict__["top_k"] = value


@contextmanager
def patch_compressed_linear_loading():
    """Context manager that patches CompressedLinear to survive custom ``_init_weights`` calls.

    When loading pack-quantized models with ``trust_remote_code=True``,
    ``compressed_tensors`` replaces ``.weight`` with ``.weight_packed`` on
    CompressedLinear modules.  Custom model code (e.g. ``modeling_deepseek.py``)
    often does ``module.weight.data.normal_(...)`` inside ``_init_weights``,
    which crashes because ``.weight`` no longer exists.

    This context manager monkey-patches ``CompressedLinear.__getattr__`` to
    return a harmless dummy for ``.weight`` accesses, and restores the original
    behaviour on exit (even if an exception is raised).

    Usage::

        from modelopt.torch.quantization.plugins.huggingface import patch_compressed_linear_loading

        with patch_compressed_linear_loading():
            model = AutoModelForCausalLM.from_pretrained(
                ckpt_path, device_map="auto", trust_remote_code=True, dtype="auto"
            )
    """
    try:
        from compressed_tensors.linear.compressed_linear import CompressedLinear
    except ImportError:
        yield
        return

    if getattr(CompressedLinear, "_modelopt_init_patched", False):
        yield
        return

    original_getattr = getattr(CompressedLinear, "__getattr__", None)

    class _DummyWeightData:
        def __getattr__(self, name):
            return lambda *args, **kwargs: self

    class _DummyWeight:
        def __init__(self):
            self.data = _DummyWeightData()

        def __getattr__(self, name):
            return lambda *args, **kwargs: self

    def patched_getattr(self, name):
        if name == "weight":
            if "_parameters" in self.__dict__ and "weight" in self._parameters:
                return self._parameters["weight"]
            if "weight" in self.__dict__:
                return self.__dict__["weight"]
            return _DummyWeight()
        if original_getattr is not None:
            return original_getattr(self, name)
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    CompressedLinear.__getattr__ = patched_getattr
    CompressedLinear._modelopt_init_patched = True
    logger.info("Patched CompressedLinear for transformers compatibility")

    try:
        yield
    finally:
        if original_getattr is not None:
            CompressedLinear.__getattr__ = original_getattr
        elif hasattr(CompressedLinear, "__getattr__"):
            del CompressedLinear.__getattr__
        CompressedLinear._modelopt_init_patched = False
        logger.info("Restored CompressedLinear original state")


class _QuantCompressedLinear(QuantModule):
    """Quantization wrapper for ``compressed_tensors`` CompressedLinear modules.

    Handles on-the-fly decompression of pack-quantized INT4 weights during
    calibration.  This avoids fully decompressing all experts into GPU memory
    at once (which would OOM for large MoE models), and also correctly handles
    the ``weight_shape`` metadata that ``compressed_tensors`` stores as a
    tensor rather than a plain list.
    """

    def _setup(self):
        self.input_quantizer = TensorQuantizer()
        self.weight_quantizer = TensorQuantizer()

    def _build_compressed_data(self):
        """Build compressed_data dict and quantization_args from module attributes.

        Returns a (compressed_data, quant_args) tuple suitable for
        ``self.compressor.decompress_weight()``.  ``weight_shape`` is
        normalised to a plain ``list[int]`` so that ``compressed_tensors``
        does not choke on a ``torch.Tensor`` value.
        """
        compressed_data = {"weight_packed": self.weight_packed}
        if hasattr(self, "weight_scale"):
            compressed_data["weight_scale"] = self.weight_scale
        if hasattr(self, "weight_shape"):
            ws = self.weight_shape
            if isinstance(ws, torch.Tensor):
                compressed_data["weight_shape"] = [int(x) for x in ws.tolist()]
            elif isinstance(ws, (list, tuple)):
                compressed_data["weight_shape"] = [int(x) for x in ws]
            else:
                compressed_data["weight_shape"] = ws
        if hasattr(self, "weight_zero_point"):
            compressed_data["weight_zero_point"] = self.weight_zero_point

        quant_args = None
        if hasattr(self, "quantization_scheme") and self.quantization_scheme:
            if hasattr(self.quantization_scheme, "weights"):
                quant_args = self.quantization_scheme.weights

        return compressed_data, quant_args

    def forward(self, input: Tensor) -> Tensor:
        from compressed_tensors.quantization import QuantizationStatus

        if self.quantization_status == QuantizationStatus.COMPRESSED:
            # Real packed weights are int32. If it's float, it's not actually compressed.
            if self.weight_packed.dtype == torch.int32:
                compressed_data, quant_args = self._build_compressed_data()
                if not hasattr(self, "_logged_on_the_fly"):
                    logger.debug("On-the-fly decompression for %s", self.__class__.__name__)
                    self._logged_on_the_fly = True
                weight_data = self.compressor.decompress_weight(
                    compressed_data=compressed_data,
                    quantization_args=quant_args,
                )
            else:
                weight_data = self.weight_packed
        else:
            weight_data = self.weight

        return linear(self.input_quantizer(input), self.weight_quantizer(weight_data), self.bias)

    def unpack_weight(self):
        from compressed_tensors.quantization import QuantizationStatus

        if self.quantization_status == QuantizationStatus.COMPRESSED:
            compressed_data, quant_args = self._build_compressed_data()

            # Skip non-pack-quantized weights (e.g., vision modules stored as BF16)
            if isinstance(compressed_data["weight_packed"], torch.Tensor):
                if compressed_data["weight_packed"].dtype != torch.int32:
                    return

            decompressed = self.compressor.decompress_weight(
                compressed_data=compressed_data,
                quantization_args=quant_args,
            )
            # Clear any placeholder before registering the real parameter
            self._parameters.pop("weight", None)
            self._buffers.pop("weight", None)
            if "weight" in self.__dict__:
                del self.__dict__["weight"]
            param = nn.Parameter(decompressed, requires_grad=False)
            self._parameters["weight"] = param
            self.__dict__["weight"] = param

        if hasattr(self, "weight_packed"):
            del self.weight_packed
        if hasattr(self, "weight_scale"):
            del self.weight_scale
        if hasattr(self, "weight_shape"):
            if "weight_shape" in self._parameters:
                del self._parameters["weight_shape"]
            else:
                delattr(self, "weight_shape")
        if self.quantization_status == QuantizationStatus.COMPRESSED:
            self.quantization_status = QuantizationStatus.FROZEN


class _QuantFP8Linear(QuantModule):
    def _setup(self):
        self.input_quantizer = TensorQuantizer()
        self.weight_quantizer = TensorQuantizer()
        assert self.weight.ndim == 2, "Weight must be 2D"
        if self.weight_scale_inv.ndim == 0:
            self.block_size = None
        else:
            assert self.weight_scale_inv.ndim == 2, "Weight scale inverse must be 0D or 2D"
            self.block_size = max(
                self.weight.shape[0] // self.weight_scale_inv.shape[0],
                self.weight.shape[1] // self.weight_scale_inv.shape[1],
            )
            assert self.block_size == 128, "Block size must be 128"

    def _get_weight_and_scale_inv(self):
        if isinstance(self.weight, torch.distributed.tensor.DTensor):
            weight = self.weight._local_tensor.contiguous()
            scale_inv = self.weight_scale_inv._local_tensor.contiguous()
        else:
            weight = self.weight.contiguous()
            scale_inv = self.weight_scale_inv.contiguous()
        return weight, scale_inv

    def _dequantize_weight(self, dtype: torch.dtype) -> Tensor:
        weight, scale_inv = self._get_weight_and_scale_inv()
        if self.block_size is None:
            return weight.to(dtype) * scale_inv.to(dtype)
        assert weight_dequant is not None, "Triton is not available"
        return weight_dequant(weight, scale_inv, self.block_size, dtype=dtype)

    def forward(self, input: Tensor) -> Tensor:
        if self.weight.element_size() == 1:
            with torch.cuda.device(self.weight.device):
                weight = self._dequantize_weight(input.dtype)
        else:
            weight = self.weight
        return linear(
            self.input_quantizer(input),
            self.weight_quantizer(weight),
            self.bias,
        )

    def unpack_weight(self):
        with torch.cuda.device(self.weight.device):
            self.weight = nn.Parameter(
                self._dequantize_weight(torch.get_default_dtype()),
                requires_grad=False,
            )
        if hasattr(self, "weight_scale_inv"):
            del self.weight_scale_inv


try:
    from transformers.models.llama4.modeling_llama4 import Llama4TextExperts

    if Llama4TextExperts not in QuantModuleRegistry:
        QuantModuleRegistry.register({Llama4TextExperts: "hf.Llama4TextExperts"})(
            _QuantLlama4TextExperts
        )
except ImportError:
    pass

try:
    from transformers.models.dbrx.modeling_dbrx import DbrxExpertGLU, DbrxExperts, DbrxFFN

    if DbrxExperts not in QuantModuleRegistry:
        QuantModuleRegistry.register({DbrxExperts: "hf.DbrxExperts"})(_QuantDbrxExperts)

    if DbrxExpertGLU not in QuantModuleRegistry:
        QuantModuleRegistry.register({DbrxExpertGLU: "hf.DbrxExpertGLU"})(_QuantDbrxExpertGLU)

    if DbrxFFN not in QuantModuleRegistry:
        QuantModuleRegistry.register({DbrxFFN: "hf.DbrxFFN"})(_QuantDbrxFFN)
except ImportError:
    pass

try:
    from transformers.models.falcon.modeling_falcon import FalconLinear

    if FalconLinear not in QuantModuleRegistry:
        QuantModuleRegistry.register({FalconLinear: "hf.FalconLinear"})(_QuantLinear)
except ImportError:
    pass

try:
    from compressed_tensors.linear.compressed_linear import CompressedLinear

    if CompressedLinear not in QuantModuleRegistry:
        QuantModuleRegistry.register({CompressedLinear: "hf.CompressedLinear"})(
            _QuantCompressedLinear
        )
except ImportError:
    pass

try:
    from transformers.models.qwen3_vl_moe.modeling_qwen3_vl_moe import Qwen3VLMoeTextExperts

    # transformers>=5.12 rewrote Qwen3VLMoeTextExperts onto the standard
    # ``@use_experts_implementation`` fused layout: ``hidden_size``/``expert_dim`` became
    # ``hidden_dim``/``intermediate_dim``, ``gate_up_proj`` was transposed to
    # (num_experts, 2*intermediate_dim, hidden_dim), and the forward now calls ``F.linear``
    # twice per expert. ``_QuantQwen3VLMoeTextExperts`` only understands the older layout,
    # so registering it against the new one crashes on ``self.hidden_size`` (nvbug 6518551).
    # The decorator sets ``_apply_gate`` on the class; use it to detect the new layout and
    # leave those modules to ``register_fused_experts_on_the_fly``, which claims them with
    # the generic ``_QuantFusedExperts``. The old layout must stay explicitly registered:
    # it is structurally indistinguishable from a generic fused-experts module, yet its
    # forward uses ``torch.bmm``/``@`` rather than ``F.linear``, so the generic wrapper
    # would silently quantize nothing.
    if Qwen3VLMoeTextExperts not in QuantModuleRegistry and not hasattr(
        Qwen3VLMoeTextExperts, "_apply_gate"
    ):
        QuantModuleRegistry.register({Qwen3VLMoeTextExperts: "hf.Qwen3VLMoeTextExperts"})(
            _QuantQwen3VLMoeTextExperts
        )
except ImportError:
    pass

try:
    from transformers.integrations.finegrained_fp8 import FP8Linear

    if FP8Linear not in QuantModuleRegistry:
        QuantModuleRegistry.register({FP8Linear: "hf.FP8Linear"})(_QuantFP8Linear)
except ImportError:
    pass


class _QuantGptOssExperts(_TransposedExpertsCalibMixin, _QuantFunctionalMixin):
    """Quantized wrapper for `transformers.GptOssExperts`.

    Quantizes `gate_up_proj` and `down_proj` weights via dynamic attributes inside `quantize_weight()`.
    Activations into `gate_up_proj` are quantized by `gate_up_proj_input_quantizer`. For `down_proj`
    activation quantization, we intercept `torch.Tensor.__matmul__`/`torch.bmm` and quantize inputs
    on every second call (since the first call computes `gate_up_proj` outputs and second call
    computes `down_proj` outputs).
    """

    @staticmethod
    def _get_quantized_weight(quantizer, module, weight):
        # MoE weight is accessed for each expert in one forward pass. so lets cache it
        if module._enable_weight_quantization:
            if hasattr(quantizer, "_cached_quant_val"):
                return getattr(quantizer, "_cached_quant_val")
            quantizer._cached_quant_val = _transposed_quantize(weight, quantizer)
            return quantizer._cached_quant_val
        return weight

    def _setup_for_weight_quantization(self):
        self._register_dynamic_attribute(
            "gate_up_proj", partial(self._get_quantized_weight, self.gate_up_proj_weight_quantizer)
        )
        self._register_dynamic_attribute(
            "down_proj", partial(self._get_quantized_weight, self.down_proj_weight_quantizer)
        )

    def _setup(self):
        assert not hasattr(self, "kernel_layer_name"), (
            "ModelOpt quantization does not support patched forward for kernel_hub"
        )
        self.gate_up_proj_input_quantizer = TensorQuantizer()
        self.gate_up_proj_weight_quantizer = TensorQuantizer()
        self.down_proj_input_quantizer = TensorQuantizer()
        self.down_proj_weight_quantizer = TensorQuantizer()

        self._register_temp_attribute("_enable_weight_quantization", False)
        self._register_temp_attribute("_down_proj_mul", False)
        self._setup_for_weight_quantization()

    @property
    def functionals_to_replace(self):
        # Use torch.ops.aten to bypass Python dispatch and avoid RecursionError
        # (torch.matmul / __matmul__ can dispatch to each other)
        _aten_bmm = torch.ops.aten.bmm
        _aten_matmul = torch.ops.aten.matmul

        def _quantized_bmm(batch1, batch2, *, out=None):
            batch1 = self.down_proj_input_quantizer(batch1) if self._down_proj_mul else batch1
            self._down_proj_mul = not self._down_proj_mul  # toggle the flag
            if out is not None:
                return torch.ops.aten.bmm.out(batch1, batch2, out=out)
            return _aten_bmm(batch1, batch2)

        def _tensor_matmul(self_t, other):
            self_t = self.down_proj_input_quantizer(self_t) if self._down_proj_mul else self_t
            self._down_proj_mul = not self._down_proj_mul
            return _aten_matmul(self_t, other)

        return [
            (torch, "bmm", _quantized_bmm),
            (torch.Tensor, "__matmul__", _tensor_matmul),
        ]

    @contextmanager
    def quantize_weight(self):
        """Context in which MoE weight is quantized."""
        self._enable_weight_quantization = True
        try:
            yield
        finally:
            for module in self.modules():
                if isinstance(module, TensorQuantizer) and hasattr(module, "_cached_quant_val"):
                    delattr(module, "_cached_quant_val")
        self._enable_weight_quantization = False

    def forward(
        self, hidden_states: torch.Tensor, router_indices=None, routing_weights=None
    ) -> torch.Tensor:
        """Forward method to add quantization."""
        hidden_states = self.gate_up_proj_input_quantizer(hidden_states)
        with self.quantize_weight():
            return super().forward(hidden_states, router_indices, routing_weights)


try:
    from transformers.models.gpt_oss.modeling_gpt_oss import GptOssExperts

    if GptOssExperts not in QuantModuleRegistry:
        QuantModuleRegistry.register({GptOssExperts: "hf.GptOssExperts"})(_QuantGptOssExperts)
except ImportError:
    pass


def register_dbrx_moe_on_the_fly(model):
    """Register DBRX MoE modules as QUANT_MODULE.

    The MoE class in DBRX is `transformers_modules.modeling_dbrx.DbrxExpertGLU`, which loads dynamically.
    """
    if type(model).__name__ == "DbrxForCausalLM":
        moe_type = type(model.transformer.blocks[0].ffn.experts.mlp)
        # Create a QuantDbrxExpertGLU class on the fly
        if QuantModuleRegistry.get(moe_type) is None:
            QuantModuleRegistry.register({moe_type: moe_type.__name__})(_QuantDbrxExpertGLU)


def register_falcon_linears_on_the_fly(model):
    """Register Falcon linear modules as a QUANT_MODULE.

    Certain falcon models (for example, falcon 40b) use remote code, which are loaded dynamically, to build their model.
    Therefore, we need to register the linear on the fly before quantization.
    """
    if type(model).__name__ in ["RWForCausalLM", "FalconForCausalLM"]:
        linear_type = type(model.transformer.h[0].self_attention.dense)
        # Create a QuantFalconLinear class on the fly
        if QuantModuleRegistry.get(linear_type) is None:
            QuantModuleRegistry.register({linear_type: linear_type.__name__})(_QuantLinear)


def _has_num_experts(obj):
    # n_routed_experts: NemotronH-style MoE
    return hasattr(obj, "num_experts") or hasattr(obj, "n_routed_experts")


def _is_sparse_sequaential_moe_block(module):
    """Check if a module is structurally a sparse sequential MoE block compatible with _QuantSparseSequentialMoe.

    All HuggingFace MoE blocks (Mixtral, Qwen3Moe, Qwen2Moe, Qwen3Next, Llama4, MiniMax,
    NemotronH, etc.) share a common structural pattern: a ``gate`` (TopKRouter) sub-module with
    routing attributes (``top_k`` and ``num_experts`` or ``n_routed_experts``), and an ``experts``
    sub-module.

    This function detects that pattern instead of relying on class names, making it forward-compatible
    with new MoE architectures.
    """
    if not hasattr(module, "experts"):
        return False

    if not hasattr(module.experts, "__iter__"):
        # transformers>=5.0 has batched experts, no per-expert quantizers
        return False

    # Primary: gate sub-module has topk/top_k + num_experts (standard TopKRouter pattern)
    if hasattr(module, "gate"):
        gate = module.gate
        if hasattr(gate, "top_k") and _has_num_experts(gate):
            return True

    # Fallback: top_k + num_experts on the block itself (older transformers, e.g. v4.x Qwen3Next)
    if hasattr(module, "top_k"):
        if not _has_num_experts(module) and hasattr(module.experts, "__len__"):
            module.num_experts = len(module.experts)
        return _has_num_experts(module)

    return False


def register_sparse_moe_on_the_fly(model):
    """Auto-detect and register MOE modules as _QuantSparseSequentialMoe.

    Walks the model tree, identifies MoE blocks by their structural attributes
    (``gate`` + ``experts``), and registers unregistered ones with ``_QuantSparseSequentialMoe``.
    """
    visited_types = set()
    for name, module in model.named_modules():
        mod_type = type(module)

        # Avoid duplicate registration: skip if we already processed this type
        # in this walk, or if it was previously registered in the QuantModuleRegistry.
        if mod_type in visited_types or QuantModuleRegistry.get(mod_type) is not None:
            continue

        visited_types.add(mod_type)

        if _is_sparse_sequaential_moe_block(module):
            print(
                f"\033[1mDetected MOE module '{name}' of type {mod_type.__name__}, "
                f"registering with _QuantSparseSequentialMoe.\033[0m"
            )
            QuantModuleRegistry.register({mod_type: f"hf.{mod_type.__name__}"})(
                _QuantSparseSequentialMoe
            )


def _fused_experts_wrapper_class(module):
    """Return the _QuantFusedExperts subclass for a fused MoE expert container, or None.

    Two 3-D fused layouts are recognized, both requiring ``num_experts`` and a
    3-D ``down_proj`` parameter:

    * gated (``_QuantFusedExperts``): a 3-D ``gate_up_proj`` fusing gate+up. Matches
      ``MixtralExperts``, ``Qwen2MoeExperts``, ``Qwen3MoeExperts``,
      ``Qwen3_5MoeExperts``, ``DeepseekV3NaiveMoe``, ``JambaExperts``,
      ``OlmoeExperts``, ``MiniMaxM2Experts``, ``MiniMaxM3VLExperts``, etc.
    * non-gated (``_QuantNonGatedFusedExperts``): a 3-D ``up_proj`` with no
      ``gate_proj`` and no ``gate_up_proj``. Matches NemotronH ``NemotronHExperts``.

    Returns ``None`` for non-standard layouts (DBRX, GptOss, GraniteMoE,
    Llama4TextExperts) which have their own explicit registrations.

    ``act_fn`` is not required: these wrappers only intercept the two ``F.linear``
    calls, so modules with a custom gated activation (e.g. ``MiniMaxM3VLExperts``)
    are still supported.
    """
    if not hasattr(module, "num_experts"):
        return None
    down = getattr(module, "down_proj", None)
    if not isinstance(down, (nn.Parameter, Tensor)) or down.dim() != 3:
        return None
    gate_up = getattr(module, "gate_up_proj", None)
    if isinstance(gate_up, (nn.Parameter, Tensor)) and gate_up.dim() == 3:
        return _QuantFusedExperts
    up = getattr(module, "up_proj", None)
    if isinstance(up, (nn.Parameter, Tensor)) and up.dim() == 3:
        # Only claim non-gated experts that alternate up_proj then down_proj.
        if getattr(module, "gate_proj", None) is None and gate_up is None:
            return _QuantNonGatedFusedExperts
    return None


def _is_fused_experts_module(module):
    """Check if a module is a fused MoE expert container compatible with _QuantFusedExperts.

    See :func:`_fused_experts_wrapper_class` for the recognized layouts (gated
    ``gate_up_proj`` and non-gated ``up_proj``).
    """
    return _fused_experts_wrapper_class(module) is not None


def register_fused_experts_on_the_fly(model):
    """Auto-detect and register fused MoE expert modules as _QuantFusedExperts.

    Walks the model tree, identifies fused expert containers by their structural
    attributes (``gate_up_proj`` + ``down_proj`` 3-D parameters), and registers
    unregistered ones with ``_QuantFusedExperts``.

    Skips modules that are already registered (e.g. Llama4TextExperts, GptOssExperts
    have their own explicit registrations with different quantization strategies).
    """
    visited_types = set()
    for name, module in model.named_modules():
        mod_type = type(module)

        if mod_type in visited_types or QuantModuleRegistry.get(mod_type) is not None:
            continue

        visited_types.add(mod_type)

        wrapper_cls = _fused_experts_wrapper_class(module)
        if wrapper_cls is not None:
            print(
                f"\033[1mDetected fused MoE experts '{name}' of type {mod_type.__name__}, "
                f"registering with {wrapper_cls.__name__}.\033[0m"
            )
            QuantModuleRegistry.register({mod_type: f"hf.{mod_type.__name__}"})(wrapper_cls)


def force_eager_experts_impl_on_the_fly(model):
    """Force HF fused-experts modules onto the eager ``F.linear``-based forward.

    HF transformers 5.0+ decorates fused-experts forwards with
    ``@use_experts_implementation``, which may dispatch to ``torch._grouped_mm``
    or ``torch.bmm`` backends. Those backends bypass ``F.linear`` and so bypass
    ``_QuantFusedExperts``'s input/weight quantizer hooks — calibration silently
    does nothing, no ``input_scale`` / ``amax`` is collected, and the exported
    checkpoint produces garbage at inference.

    Sets ``config._experts_implementation = "eager"`` on the model config (and
    recursively on ``text_config`` / ``vision_config`` / ``audio_config`` /
    ``speech_config``) whenever a fused-experts module is present.
    """
    if not any(_is_fused_experts_module(m) for m in model.modules()):
        return

    nested_cfg_attrs = ("text_config", "vision_config", "audio_config", "speech_config")

    def _force(cfg):
        if cfg is None:
            return
        if hasattr(cfg, "_experts_implementation"):
            cfg._experts_implementation = "eager"
        for sub in nested_cfg_attrs:
            if hasattr(cfg, sub):
                _force(getattr(cfg, sub))

    if hasattr(model, "config"):
        _force(model.config)


def _is_supported_hf_model(model):
    """Check if the model a valid model for transformers quantization specific support."""
    supported_models = [transformers.PreTrainedModel]
    try:
        from peft import PeftModel

        supported_models.append(PeftModel)
    except ImportError:
        pass
    return isinstance(model, tuple(supported_models))


def is_nemotron_h_model(model: nn.Module) -> bool:
    return get_nemotron_h_decoder_layers(model) is not None


def get_nemotron_h_decoder_layers(model: nn.Module) -> nn.ModuleList | None:
    if not _is_supported_hf_model(model):
        return None

    # Custom remote-code checkpoint uses model.backbone.layers;
    # native transformers NemotronHModel uses model.model.layers.
    for container_attr in ("backbone", "model"):
        container = getattr(model, container_attr, None)
        if container is not None and hasattr(container, "layers"):
            layers = container.layers
            if layers and hasattr(layers[0], "block_type"):
                return layers

    return None


def is_homogeneous_hf_model(model: nn.Module) -> bool:
    if is_nemotron_h_model(model):
        return False
    decoder_layers = get_homogeneous_hf_decoder_layers(model)
    if decoder_layers is None or len(decoder_layers) == 0:
        return False
    layer_classes = {type(layer) for layer in decoder_layers}
    return len(layer_classes) == 1


def get_homogeneous_hf_decoder_layers(model: nn.Module) -> nn.ModuleList | None:
    if not _is_supported_hf_model(model):
        return None

    decoder = model
    if hasattr(decoder, "model"):
        decoder = decoder.model
    if hasattr(decoder, "language_model"):
        decoder = decoder.language_model
    if hasattr(decoder, "layers"):
        return decoder.layers

    return None


@contextmanager
def setup_model_for_gradient_checkpointing(model: nn.Module):
    use_cache = None
    if hasattr(model, "config") and hasattr(model.config, "use_cache"):
        # Disable use_cache explicitly before forward is called
        use_cache = model.config.use_cache
        model.config.use_cache = False

    if not hasattr(model, "gradient_checkpointing_enable") or not (
        hasattr(model, "supports_gradient_checkpointing") and model.supports_gradient_checkpointing
    ):
        warnings.warn(
            "AutoQuantize: Huggingface model without gradient checkpointing support detected. "
            "AutoQuantize will consume more memory."
        )
    else:
        try:
            warnings.warn(
                "AutoQuantize: Huggingface model detected - Enabling gradient checkpointing. "
                "Disable gradient checkpointing after AutoQuantize if this is not desired!"
            )
            model.gradient_checkpointing_enable({"use_reentrant": True})
            for m in model.modules():
                if hasattr(m, "gradient_checkpointing"):
                    m.train()  # Make sure the module is in training mode to enable gradient checkpointing
                else:
                    # Eval mode for non-checkpointed modules to avoid fused kernels
                    # that bypass linear layers. E.g. in nemotron-h, the Mamba layer's
                    # training path uses a fused kernel that takes out_proj weights
                    # directly, skipping the linear module's forward (and thus quantization).
                    m.eval()
        except Exception as e:
            warnings.warn(
                f"AutoQuantize: Error enabling gradient checkpointing for huggingface model due to: {e}, "
                "AutoQuantize will consume more memory."
            )
    yield
    if use_cache is not None:
        model.config.use_cache = use_cache


def _is_param_grad_enabled_for_auto_quantize(pname, model):
    # Enable grad for embedding layers to propagate gradients through the model,
    # allowing each layer to compute its input gradients during the backward pass.
    return "embed" in pname


AutoQuantizeGradientSearcher.register_custom_support(
    _is_supported_hf_model,
    setup_model_for_gradient_checkpointing,
    _is_param_grad_enabled_for_auto_quantize,
)

# Order matters: more specific predicates must be registered first because
# the first matching entry wins.  Nemotron-H must precede the generic
# homogeneous HF discoverer (which explicitly rejects Nemotron-H).
LayerActivationCollector.register_decoder_layer_support(
    is_nemotron_h_model, get_nemotron_h_decoder_layers
)

LayerActivationCollector.register_decoder_layer_support(
    is_homogeneous_hf_model, get_homogeneous_hf_decoder_layers
)


class _QuantMoELinear(QuantModule):
    """Quantization wrapper for Step3p5 MoELinear modules (fused expert weights).

    MoELinear has weight shape [num_experts, out_features, in_features] with
    forward(x, expert_id). We expand it into per-expert nn.Linear modules so
    each expert gets its own weight_quantizer and input_quantizer, calibrated
    only on tokens actually routed to that expert.

    On export, _reconstruct_fused_moe_linear() stacks the per-expert quantized
    weights and scales back into the original 3D format.

    Note: we use expansion-then-reconstruction rather than the add_module() approach
    because vLLM requires stacked 3D scaling factors; per-expert expanded keys are
    not accepted by the downstream serving engine.
    """

    def _setup(self):
        from accelerate import init_empty_weights

        dtype, device = self.weight.dtype, self.weight.device

        with init_empty_weights():
            experts = nn.ModuleList(
                [
                    nn.Linear(self.in_features, self.out_features, bias=False)
                    for _ in range(self.num_experts)
                ]
            )

        for i in range(self.num_experts):
            experts[i].to_empty(device=device)
            with torch.no_grad():
                experts[i].weight.data = self.weight[i].detach().to(dtype=dtype, device=device)

        delattr(self, "weight")
        self.experts = experts

    def forward(self, x, expert_id):
        # experts[expert_id] is a _QuantLinear after quantization wrapping,
        # providing per-expert input_quantizer and weight_quantizer.
        # Cast input to match expert weight dtype before linear operation,
        # then cast output to float32 to match original MoELinear forward behavior.
        expert = self.experts[expert_id]
        x = x.to(expert.weight.dtype)
        return expert(x).float()


def register_step3p5_moe_on_the_fly(model):
    """Register Step3p5 MoELinear for quantization.

    Step3p5 uses a custom MoELinear class (loaded via trust_remote_code) with
    weight shape [num_experts, out_features, in_features] and forward(x, expert_id).
    We detect it by model class name, then grab the type from the first MoE layer.
    """
    if type(model).__name__ not in ("Step3p5ForCausalLM", "Step3p5Model"):
        return
    for module in model.modules():
        if type(module).__name__ == "Step3p5MoEMLP":
            moe_linear_type = type(module.up_proj)
            if QuantModuleRegistry.get(moe_linear_type) is None:
                QuantModuleRegistry.register({moe_linear_type: f"hf.{moe_linear_type.__name__}"})(
                    _QuantMoELinear
                )
            break


def _reconstruct_fused_moe_linear(model: nn.Module) -> None:
    """Reconstruct QuantMoELinear per-expert weights back to original 3D MoELinear format.

    After _process_quantized_modules, each expert's nn.Linear inside QuantMoELinear has:
      - weight: fp4-quantized tensor [out_features, in_features]
      - weight_scale, weight_scale_2: per-block / global scales
      - input_scale: activation scale (if calibrated)

    This stacks them back into the original MoELinear layout so the exported state_dict
    uses the original key names (e.g. moe.up_proj.weight with shape [N, out, in]).

    Note: QuantMoELinear is the dynamically generated class name (Quant + MoELinear),
    not _QuantMoELinear which is the implementation class.
    """
    for _name, module in model.named_modules():
        # Match QuantMoELinear (dynamically generated name) not _QuantMoELinear (implementation class)
        if type(module).__name__ != "QuantMoELinear":
            continue

        n = module.num_experts
        experts = module.experts

        # Reconstruct 3D weight: [num_experts, out_features, in_features]
        module.weight = nn.Parameter(
            torch.stack([experts[i].weight.data for i in range(n)]),
            requires_grad=False,
        )

        # Stack per-expert scales back under the original attribute names.
        # Check all experts: some may lack input_scale if they were never routed
        # during calibration, so only stack when every expert has the attribute.
        for attr in ("weight_scale", "weight_scale_2", "input_scale"):
            if all(hasattr(experts[i], attr) for i in range(n)):
                module.register_buffer(
                    attr,
                    torch.stack([getattr(experts[i], attr) for i in range(n)]),
                )

        # Remove expanded experts — the reconstructed 3D tensors replace them
        del module.experts


CUSTOM_MODEL_PLUGINS.update(
    [
        register_falcon_linears_on_the_fly,
        register_dbrx_moe_on_the_fly,
        register_step3p5_moe_on_the_fly,
        register_fused_experts_on_the_fly,
        force_eager_experts_impl_on_the_fly,
        register_sparse_moe_on_the_fly,
        register_hf_attentions_on_the_fly,
        convert_hf_parallel_linears_on_the_fly,
    ]
)
