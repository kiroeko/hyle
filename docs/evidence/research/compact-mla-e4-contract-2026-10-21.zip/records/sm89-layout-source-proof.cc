// Read-only design proof source; NOT compiled in this review.
// Fixed pinned MLA shared arrays, mapped to equally sized host integer types.
// It does not substitute for sizeof(actual CUDA KTraits) or native launch tests.
#include <cstddef>
#include <cstdint>

template<unsigned Q, unsigned KV, unsigned Rope> struct BaselinePayload {
  alignas(16) std::uint16_t q_nope[Q * 512];
  alignas(16) std::uint16_t q_pe[Q * (Rope ? Rope : 1)];
  alignas(16) std::uint8_t ckv_raw[KV * 512];
  alignas(16) std::uint8_t kpe_raw[KV * (Rope > Q ? Rope : Q)];
  alignas(16) std::uint16_t ckv_native[KV * 512];
  alignas(16) std::uint16_t kpe_native[KV * (Rope ? Rope : 1)];
  union {alignas(16) float m[2][Q];alignas(16) float d[2][Q];};
};
template<unsigned Q, unsigned KV, unsigned Rope> struct E4NonShardPayload {
  alignas(16) std::uint16_t q_nope[Q * 512];
  alignas(16) std::uint16_t q_pe[Q * (Rope ? Rope : 1)];
  alignas(16) std::uint8_t ckv_raw[KV * 512];
  alignas(16) std::uint8_t kpe_raw[KV * (Rope > Q ? Rope : Q)];
  alignas(16) std::uint16_t ckv_native[KV * 512];
  alignas(16) std::uint16_t kpe_native[KV * (Rope ? Rope : 1)];
  // QK_SHARD=false: m_wg/d_wg accesses are compile-time discarded.
};
template<unsigned Q,unsigned KV,unsigned Rope,template<unsigned,unsigned,unsigned>class Payload>
union alignas(16) Shared {
  Payload<Q,KV,Rope> data;
  alignas(16) std::uint16_t output[Q * 512];
};
static_assert(sizeof(Shared<64,32,64,BaselinePayload>)==129536);
static_assert(sizeof(Shared<64,32,0,BaselinePayload>)==117440);
static_assert(sizeof(Shared<64,16,64,BaselinePayload>)==101888);
static_assert(sizeof(Shared<64,16,64,E4NonShardPayload>)==101376);
static_assert(sizeof(Shared<64,16,0,E4NonShardPayload>)==91296);
static_assert(sizeof(Shared<32,16,64,BaselinePayload>)==64768);
// All fields are multiples of16 with explicit align16.
// Actual product code must specialize E4 only; preserve non-E4 source/layout.
