#include <cstddef>
#include <cstdint>
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <flashinfer/attention/mla.cuh>
#include <flashinfer/attention/scheduler.cuh>
namespace fi=flashinfer;
using Q=__nv_bfloat16;using E4=__nv_fp8_e4m3;
template<unsigned Rope>using Adapt=fi::mla::KernelTraits<true,1,false,512,Rope,64,16,Q,E4,Q,std::int32_t,float>;
template<unsigned Rope>using Plain=fi::mla::KernelTraits<true,1,false,512,Rope,64,16,Q,Q,Q,std::int32_t,float>;
using S576=Adapt<64>::SharedStorage;using S512=Adapt<0>::SharedStorage;
using P576=Plain<64>::SharedStorage;using P512=Plain<0>::SharedStorage;
static_assert(sizeof(Q)==2 && sizeof(E4)==1);
static_assert(Adapt<64>::CTA_TILE_Q==64 && Adapt<64>::CTA_TILE_KV==16 && Adapt<64>::NUM_THREADS==256);
static_assert(!Adapt<64>::QK_SHARD && Adapt<64>::NUM_MMA_KV==1 && Adapt<64>::NUM_STAGES==1);
static_assert(sizeof(S576)==101376 && alignof(S576)==16);
static_assert(offsetof(S576,q_smem_nope)==0 && offsetof(S576,q_smem_pe)==65536);
static_assert(offsetof(S576,ckv_smem)==73728 && offsetof(S576,kpe_p_smem)==81920);
static_assert(offsetof(S576,ckv_bf16)==82944 && offsetof(S576,kpe_bf16)==99328);
static_assert(offsetof(S576,o_smem)==0);
static_assert(sizeof(S512)==91296 && alignof(S512)==16);
static_assert(offsetof(S512,q_smem_nope)==0 && offsetof(S512,q_smem_pe)==65536);
static_assert(offsetof(S512,ckv_smem)==65664 && offsetof(S512,kpe_p_smem)==73856);
static_assert(offsetof(S512,ckv_bf16)==74880 && offsetof(S512,kpe_bf16)==91264);
static_assert(sizeof(P576)==92704 && sizeof(P512)==84640);
static_assert(Plain<64>::CTA_TILE_Q==64 && Plain<64>::CTA_TILE_KV==16 && Plain<64>::NUM_THREADS==256);
static_assert(offsetof(P576,ckv_smem)==73728 && offsetof(P576,m_wg)==92192);
// Scheduler source is unchanged, with its existing local cta_tile_q=64.
// This asserts real PlanInfo layout; source identity/context is checked by prepare.py.
static_assert(sizeof(fi::MLAPlanInfo)==18*sizeof(std::int64_t));
static_assert(offsetof(fi::MLAPlanInfo,num_blks_x)==0);
static_assert(offsetof(fi::MLAPlanInfo,partial_o_offset)==16*sizeof(std::int64_t));
static_assert(offsetof(fi::MLAPlanInfo,partial_lse_offset)==17*sizeof(std::int64_t));
// One tiny non-running device probe forces codegen for F32 multiply/BF16 RNE.
// No full attention kernel/plan is instantiated or executed in this proof.
extern "C" __global__ void proof_e4_scale_rn(const Q* input,float scale,Q* output) {
  output[threadIdx.x]=fi::mla::hyle_mla_e4_scale_rn(input[threadIdx.x],scale);
}
