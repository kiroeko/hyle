from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parents[3]
# Parent is fixed under repository .scratch; derive repository from known cwd.
R=Path.cwd()
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
plan=json.loads((P/'compile-plan.json').read_text())
if (P/'compile-result.json').exists():raise RuntimeError('Preserve existing attempt')
for key in ['actual_base_recipe','actual_base_header','candidate_header','proof_source','scheduler_unchanged','current_product_manifest']:
 assert plan[key]==ident(plan[key]['path']),key
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
compiler=plan['command'][plan['command'].index('--compiler-bindir')+1]+'\\cl.exe'
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler});env['VSLANG']='1033'
(P/'tmp').mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(P/'tmp')
command=plan['command']+['-MD','-MF',str(P/'layout-proof.d')]
record={**plan,'command':command,'environment_source':'same scripts/hyle_environment.py windows_compiler_environment as actual native MLA build; temp isolated locally; no sensitive environment serialized','started':time.time(),'compile_attempts':1,'GPU_runs':0,'SDK_rebuilds':0,'product_edits':0}
save(P/'compile-command.json',record)
start=time.monotonic()
with (P/'stdout.log').open('wb')as so,(P/'stderr.log').open('wb')as se:
 proc=subprocess.run(command,cwd=P,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
record.update(exit=proc.returncode,seconds=time.monotonic()-start,finished=time.time(),stdout=ident(P/'stdout.log'),stderr=ident(P/'stderr.log'))
if proc.returncode==0:
 record.update(object=ident(P/'layout-proof.obj'),dependencies=ident(P/'layout-proof.d'))
 record['assertions']='actual CUDA KTraits SharedStorage sizes, align16, segment offsets, nonsharded KV16/CTA_Q64/256threads; plain BF16 geometry/layout and MLAPlanInfo18xI64 layout'
for key in ['actual_base_header','scheduler_unchanged','current_product_manifest']:
 assert record[key]==ident(record[key]['path']),key
save(P/'compile-result.json',record)
print(json.dumps({'exit':proc.returncode,'seconds':record['seconds'],'result':ident(P/'compile-result.json'),'object':record.get('object')},indent=2),flush=True)
if proc.returncode:print((P/'stdout.log').read_text(errors='replace')[-6000:]);print((P/'stderr.log').read_text(errors='replace')[-2500:])
raise SystemExit(proc.returncode)
