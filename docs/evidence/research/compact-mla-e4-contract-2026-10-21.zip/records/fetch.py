from pathlib import Path
import urllib.request,urllib.error,json,hashlib,time,sys
ROOT=Path('.scratch/architecture-refactor-2026-10-18/compact-mla-e4-2026-10-21');ROOT.mkdir(exist_ok=True)
def fetch(url,name,cap=262144):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);r={'url':url,'path':name,'cap':cap,'started':time.time(),'model_payload_bytes':0}
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'Hyle-bounded-source-review','Accept':'application/vnd.github+json'if'api.github.com'in url else'text/plain'})
  with urllib.request.urlopen(request,timeout=30)as response:
   length=response.headers.get('Content-Length');assert length is None or int(length)<=cap,(length,cap)
   b=response.read(cap+1);assert len(b)<=cap
   r.update(status=response.status,headers={k:v for k,v in response.headers.items()if k.lower()in ['content-length','content-type','etag','last-modified','x-repo-commit']},bytes=len(b),sha256=hashlib.sha256(b).hexdigest());p.write_bytes(b)
 except Exception as e:r.update(error=str(e))
 r['seconds']=time.time()-r['started'];(p.with_name(p.name+'.http.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));return r
if __name__=='__main__':fetch(sys.argv[1],sys.argv[2],int(sys.argv[3])if len(sys.argv)>3 else 262144)
