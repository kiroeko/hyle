"""Merge reviewed source contracts into existing artifact rows, preserving metadata."""
from pathlib import Path
import argparse
import copy
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
catalog=ROOT/'docs/implementation/model-quantizations.json'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(data):return hashlib.sha256(data).hexdigest()


parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('audit',type=Path)
args=parser.parse_args()
audit=args.audit.resolve()
mapping=read(audit)
before=catalog.read_bytes()
original=json.loads(before)
data=copy.deepcopy(original)
indices=[]
for row in mapping['artifacts']:
    index=row['index']
    if index in indices:raise ValueError('Duplicate artifact')
    indices.append(index)
    target=data['artifacts'][index]
    if any(target[k]!=row[k] for k in ('model_id','repository','revision')):
        raise ValueError('Artifact identity drift')
    if target['provider_coverage'] is not None:
        raise ValueError('Existing reviewed coverage may not be silently replaced')
    coverage=row['provider_coverage']
    if coverage['review']!='static_contract_review' or coverage['artifact_execution_verified'] is not False:
        raise ValueError('Only bounded source reviews may be merged')
    target['provider_coverage']=coverage
for left,right in zip(original['artifacts'],data['artifacts']):
    if {k:v for k,v in left.items() if k!='provider_coverage'}!={k:v for k,v in right.items() if k!='provider_coverage'}:
        raise ValueError('Publisher metadata differs')
tag=str(min(indices))+'-'+str(max(indices))
backup=STAGE/('before-'+tag+'-catalog.json')
if backup.exists():raise ValueError('Refusing to replace a previous application')
backup.write_bytes(before)
catalog.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
receipt={'catalog':str(catalog),'before_sha256':sha(before),'after_sha256':sha(catalog.read_bytes()),
    'audit':str(audit),'audit_sha256':sha(audit.read_bytes()),'added_indices':indices,
    'total_artifacts':len(data['artifacts']),
    'source_contract_reviews':sum(x['provider_coverage'] is not None for x in data['artifacts']),
    'artifact_execution_verified':False,'publisher_metadata_changed':False}
(STAGE/('application-'+tag+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt),flush=True)
