"""Save the bounded source review without suggesting artifact execution coverage."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
DEST=ROOT/'docs/evidence/research/model-provider-coverage-2026-10-19.zip'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(data):return hashlib.sha256(data).hexdigest()


def identity(path):
    data=path.read_bytes()
    return {'path':str(path.resolve()),'bytes':len(data),'sha256':sha(data)}


if DEST.exists():raise ValueError('Refusing replacement of existing evidence')
catalog=ROOT/'docs/implementation/model-quantizations.json'
artifacts=read(catalog)['artifacts']
if len(artifacts)!=33 or any(not a['provider_coverage'] for a in artifacts):
    raise ValueError('All33 source reviews must be merged before this snapshot')
if any(a['provider_coverage']['review']!='static_contract_review' or a['provider_coverage']['artifact_execution_verified'] is not False for a in artifacts):
    raise ValueError('No artifact execution claims are part of this review')
files={}
for path in sorted(STAGE.rglob('*')):
    if path.is_file() and path.suffix in ('.json','.py') and not any(x in path.parts for x in ('__pycache__','tmp')):
        if path.name=='archive-verification.json':raise ValueError('Existing receipt')
        files['review/'+path.relative_to(STAGE).as_posix()]=path
first=STAGE.parent/'cuda-grouped-fusion/table-audit/first-eight-artifact-mapping.json'
files['review/first-eight-artifact-mapping.json']=first
for relative in ('docs/implementation/model-quantizations.json','docs/implementation/model-operators.md',
                 'docs/developer/current-work.md','docs/architecture/compute-design.md'):
    files['documentation/'+relative]=ROOT/relative
# Preserve the actual local code referred to by the source review, with no SDK,
# model, compiled object or unrelated source checkout copies.
source_pattern=re.compile(r'\b((?:src|include|third_party)/[A-Za-z0-9_./-]+\.(?:h|cc|cpp|cu|cuh|json|md))')
for path in list(files.values()):
    for relative in source_pattern.findall(path.read_text(encoding='utf-8-sig')):
        source=ROOT/relative
        if source.is_file():files['source/'+relative]=source
references=[]
for relative in ('docs/evidence/research/model-quantization-discovery-2026-10-19.zip',
                 'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'):
    path=ROOT/relative
    if path.exists():references.append(identity(path))
scope={'reviewed_artifacts':33,'models':len({a['model_id'] for a in artifacts}),
    'review':'static_contract_review','artifact_execution_verified':False,
    'discovery_exhausted':False,'per_tensor_headers_inspected':False,
    'complete_profile_role_phase_provider_matrix':False,
    'catalog':identity(catalog),'publisher_metadata_archives_referenced_without_duplicate_copy':references,
    'existing_runtime_evidence':'../performance/qwen35-full-cuda-2026-10-19/cuda-grouped-fusion.zip',
    'existing_runtime_evidence_scope':'Separate directed Q8/MXFP4 Graph fragments and BF16 Qwen regression, not these33 artifact bindings',
    'plans_are_unimplemented':True,'new_GPU_runs':0,'new_builds':0}
scope_path=STAGE/'archive-scope.json'
scope_path.write_text(json.dumps(scope,indent=2)+'\n',encoding='utf-8')
files['review/archive-scope.json']=scope_path
records=[]
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,path in sorted(files.items()):
        data=path.read_bytes()
        records.append({'entry':name,'source':str(path.resolve()),'bytes':len(data),'sha256':sha(data)})
        archive.writestr(name,data)
    archive.writestr('manifest.json',json.dumps(records,indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    if len(archive.namelist())!=len(records)+1:raise ValueError('Entry count mismatch')
    for row in records:
        data=archive.read(row['entry'])
        if len(data)!=row['bytes'] or sha(data)!=row['sha256']:raise ValueError('Payload mismatch')
receipt={**identity(DEST),'payloads':len(records),'CRC_and_every_payload_SHA_verified':True,
    'source_reviews':33,'artifact_execution_verified':False,'new_GPU_runs':0,'new_builds':0}
text=json.dumps(receipt,indent=2)+'\n'
(STAGE/'archive-verification.json').write_text(text,encoding='utf-8')
DEST.with_name('model-provider-coverage-2026-10-19-archive.json').write_text(text,encoding='utf-8')
print(text,flush=True)
