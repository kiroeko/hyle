"""Use stable artifact pointers for references into the expanding catalog."""
from pathlib import Path
import hashlib
import json
import re

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
path=ROOT/'docs/implementation/model-quantizations.json'
before=path.read_bytes()
data=json.loads(before)
pattern=re.compile(r'docs/implementation/model-quantizations\.json:\d+(?:-\d+)?(?:,\d+(?:-\d+)?)*')
changes=[]


def update(value,index):
    if isinstance(value,str):
        replacement=pattern.sub('docs/implementation/model-quantizations.json#/artifacts/'+str(index),value)
        if replacement!=value:changes.append({'artifact':index,'before':value,'after':replacement})
        return replacement
    if isinstance(value,list):return [update(x,index) for x in value]
    if isinstance(value,dict):return {k:update(v,index) for k,v in value.items()}
    return value


for index,artifact in enumerate(data['artifacts']):
    artifact['provider_coverage']=update(artifact['provider_coverage'],index)
path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt={'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
    'changes':changes,'publisher_metadata_changed':False}
(STAGE/'stable-reference-correction.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print({'stable_self_references':len(changes)},flush=True)
