"""Read retained SQLite profiles only; never starts inference or a profiler."""
from pathlib import Path
import bisect
import hashlib
import json
import sqlite3
import statistics

W = Path(__file__).resolve().parent
REPO = W.parent.parent
BASE = REPO / '.scratch/inference-b2-current-attribution-20261026'
FACTS = REPO / '.scratch/review-20261027/b2attr/facts.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def pin(path):
    return dict(path=str(path.relative_to(REPO)).replace('\\', '/'),
                bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def merged(intervals):
    out = []
    for a, b in sorted(intervals):
        if b <= a:
            continue
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def measure(intervals):
    return sum(b - a for a, b in merged(intervals))


def load_engine(name, facts):
    folder = BASE / ('hyle' if name == 'hyle' else 'peer2') / 'trace1'
    quality = read(folder / 'quality.json')
    assert quality['status'] == 'PASS' and quality['full_non_time_equal']
    roots = {r['meta']['seq']: r for r in read(folder / 'physical-roots.json')}
    db = folder / 'trace.sqlite'
    actual_pin = pin(db)
    recorded = next(x for x in quality['artifacts'] if x['path'].endswith('trace.sqlite'))
    assert (actual_pin['bytes'], actual_pin['sha256']) == (recorded['bytes'], recorded['sha256'])
    con = sqlite3.connect(db.resolve().as_uri() + '?mode=ro&immutable=1', uri=True)
    con.row_factory = sqlite3.Row
    copy_names = {r['id']: r['name'] for r in con.execute('SELECT * FROM ENUM_CUDA_MEMCPY_OPER')}
    activities = []
    for kind in ('KERNEL', 'MEMCPY', 'MEMSET'):
        for r in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_' + kind + ' ORDER BY start'):
            x = dict(r)
            x['kind'] = kind
            activities.append(x)
    con.close()
    activities.sort(key=lambda x: x['start'])
    starts = [r['start'] for r in activities]
    rows = {}
    for r in facts[name]['decode_rows']:
        seq = r['meta']['seq']
        original = roots[seq]
        a, b = r['start_ns'], r['end_ns']
        assert (a, b, r['meta']) == (original['start_ns'], original['end_ns'], original['meta'])
        pid = original['globalTid'] & ~((1 << 24) - 1)
        i = bisect.bisect_left(starts, a)
        selected = []
        while i < len(activities) and activities[i]['start'] < b:
            x = activities[i]
            if x['globalPid'] == pid:
                # The retained producer already established containment. Recheck it.
                assert a <= x['start'] < x['end'] <= b
                selected.append(x)
            i += 1
        assert selected
        kernels = [x for x in selected if x['kind'] == 'KERNEL']
        copies = [x for x in selected if x['kind'] == 'MEMCPY']
        kernel_intervals = [(x['start'], x['end']) for x in kernels]
        all_intervals = [(x['start'], x['end']) for x in selected]
        gpu = merged(all_intervals)
        kernel_union = measure(kernel_intervals)
        all_union = measure(all_intervals)
        assert all_union == r['root']['GPU_union_ns']
        first_kernel = min(x['start'] for x in kernels)
        last_kernel = max(x['end'] for x in kernels)
        inside_kernel_span = [(max(first_kernel, a), min(last_kernel, b)) for a, b in all_intervals
                              if a < last_kernel and first_kernel < b]
        out = dict(seq=seq, record=r['record'],
                   native_graph_launches=sum(v for k, v in r['capture_API_counts'].items() if 'GraphLaunch' in k),
                   wall_ns=b-a, kernel_count=len(kernels), kernel_sum_ns=sum(y-x for x, y in kernel_intervals),
                   kernel_union_ns=kernel_union, gpu_union_ns=all_union,
                   first_to_last_gpu_ns=gpu[-1][1]-gpu[0][0],
                   gpu_inner_gap_ns=gpu[-1][1]-gpu[0][0]-all_union,
                   before_first_gpu_ns=gpu[0][0]-a, after_last_gpu_ns=b-gpu[-1][1],
                   before_first_kernel_ns=first_kernel-a,
                   after_last_kernel_ns=b-last_kernel,
                   first_to_last_kernel_ns=last_kernel-first_kernel,
                   observed_idle_inside_kernel_span_ns=last_kernel-first_kernel-measure(inside_kernel_span), copies={})
        for copy_kind in sorted({x['copyKind'] for x in copies}):
            these = [x for x in copies if x['copyKind'] == copy_kind]
            ivs = [(x['start'], x['end']) for x in these]
            out['copies'][copy_names[copy_kind]] = dict(count=len(these), bytes=sum(x['bytes'] for x in these),
                                                      sum_ns=sum(y-x for x, y in ivs), union_ns=measure(ivs))
        d2d = [x for x in copies if x['copyKind'] == 8]
        out['d2d_exclusive_of_kernels_ns'] = all_union - measure(kernel_intervals +
            [(x['start'], x['end']) for x in selected if x['kind'] != 'KERNEL' and x not in d2d])
        rows[seq] = out
    return rows, dict(sqlite=actual_pin, quality=pin(folder / 'quality.json'),
                     physical_roots=pin(folder / 'physical-roots.json'))


def summarize(rows):
    n = len(rows)
    keys = ('wall_ns', 'kernel_count', 'kernel_sum_ns', 'kernel_union_ns', 'gpu_union_ns',
            'first_to_last_gpu_ns', 'gpu_inner_gap_ns', 'before_first_gpu_ns', 'after_last_gpu_ns',
            'before_first_kernel_ns', 'after_last_kernel_ns', 'first_to_last_kernel_ns',
            'observed_idle_inside_kernel_span_ns', 'd2d_exclusive_of_kernels_ns')
    mean = {k: sum(r[k] for r in rows)/n for k in keys}
    out = dict(roots=n, mean=mean,
               native_graph_launch_count_distribution={str(k): sum(r['native_graph_launches'] == k for r in rows)
                                                       for k in sorted({r['native_graph_launches'] for r in rows})},
               copies={})
    for name in sorted({k for r in rows for k in r['copies']}):
        out['copies'][name] = {k: sum(r['copies'].get(name, {}).get(k, 0) for r in rows)/n
                               for k in ('count', 'bytes', 'sum_ns', 'union_ns')}
        durations = [r['copies'].get(name, {}).get('sum_ns', 0) for r in rows]
        out['copies'][name]['per_root_sum_ns_range'] = [min(durations), max(durations)]
        out['copies'][name]['per_root_sum_ns_median'] = statistics.median(durations)
    return out


def main():
    facts = read(FACTS)
    assert FACTS.read_bytes() == (BASE / 'facts.json').read_bytes()
    h, hp = load_engine('hyle', facts)
    p, pp = load_engine('peer', facts)
    hot_h = {k: r for k, r in h.items() if not r['record']}
    hot_p = {k: r for k, r in p.items() if not r['record']}
    common = sorted(hot_h.keys() & hot_p.keys())
    assert len(common) == 90
    for seq in common:
        assert hot_h[seq]['native_graph_launches'] == hot_p[seq]['native_graph_launches'] == 1
        hm = next(r['meta'] for r in facts['hyle']['decode_rows'] if r['meta']['seq'] == seq)
        pm = next(r['meta'] for r in facts['peer']['decode_rows'] if r['meta']['seq'] == seq)
        assert hm == pm
    result = dict(status='OFFLINE_COMMON_90_ORIGINAL_TRACE_CORRECTION',
                  units='Means per physical R2 decode root; *_ns is nanoseconds. Counts and bytes are per root.',
                  source_fact=pin(FACTS), scripts={k: pin(REPO / '.scratch/review-20261027' / k)
                                               for k in ('kernels.py', 'gemm.py', 'gaps.py')},
                  origins=dict(hyle=hp, peer=pp), common_sequences=common,
                  original_not_record_groups=dict(hyle=summarize(list(hot_h.values())), peer=summarize(list(hot_p.values()))),
                  corrected_common_native_groups=dict(hyle=summarize([hot_h[k] for k in common]),
                                                       peer=summarize([hot_p[k] for k in common])),
                  excluded_peer_not_record_sequences=[dict(seq=k, native_graph_launches=hot_p[k]['native_graph_launches'])
                                                      for k in sorted(hot_p.keys()-set(common))],
                  interpretation=[
                      'Original scripts select not-record independently: Hyle90 vs peer93. Three peer roots are eager/no native GraphLaunch.',
                      'Corrected comparison uses exact shared physical seq/meta and exactly one native GraphLaunch on both sides.',
                      'GPU union contains kernels/copies/memsets, kernel sum is not wall and D2D sum is not automatically removable.',
                      'before_first_gpu is before first observed activity, not necessarily CPU self-time; before_first_kernel also includes earlier GPU copies and gaps.',
                      'One profiled process per engine, historical 2026-10-26 images; not current HEAD kernel inventory, TPS or causal optimization result.',
                      'Peer can perform equivalent state/cache updates through kernels. Absence of MEMCPY D2D does not imply absence of that logical work.',
                      'No new model, GPU, build, dependency or network operation. SQLite opened mode=ro immutable=1.'
                  ])
    output = W / 'common-90-summary.json'
    output.write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    for group in ('original_not_record_groups', 'corrected_common_native_groups'):
        print(group)
        for name, summary in result[group].items():
            print(name, summary)
    print('output', pin(output))


if __name__ == '__main__':
    main()
