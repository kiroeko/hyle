"""Package the finite offline correction; no databases or model payloads."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parent.parent
S = json.loads((W / 'common-90-summary.json').read_text())
DEST = R / 'docs/evidence/research'
NAME = 'inference-review-common90-2026-10-27'


def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def compact(group):
    result = {}
    for engine, x in group.items():
        m = x['mean']
        result[engine] = dict(roots=x['roots'], kernel_count=m['kernel_count'],
            native_graph_launch_count_distribution=x['native_graph_launch_count_distribution'],
            mean_ms={k[:-3]: round(m[k]/1e6, 9) for k in (
                'wall_ns', 'kernel_union_ns', 'gpu_union_ns', 'before_first_gpu_ns',
                'after_last_gpu_ns', 'before_first_kernel_ns', 'after_last_kernel_ns',
                'first_to_last_gpu_ns', 'observed_idle_inside_kernel_span_ns')},
            memcpy_per_root={name.replace('CUDA_MEMCPY_KIND_', ''):
                dict(count=v['count'], bytes=v['bytes'], sum_ms=round(v['sum_ns']/1e6, 9))
                for name, v in x['copies'].items()})
    return result


def main():
    inputs = [W/'common_roots.py', W/'common-90-summary.json', W/'package.py',
              R/'.scratch/review-20261027/b2attr/facts.json']
    inputs += [R/'.scratch/review-20261027'/name for name in ('kernels.py', 'gemm.py', 'gaps.py')]
    manifest = [pin(p) for p in inputs]
    for k, expected in S['scripts'].items():
        assert pin(R/expected['path']) == expected
    assert pin(R/S['source_fact']['path']) == S['source_fact']
    h = S['corrected_common_native_groups']['hyle']['mean']
    p = S['corrected_common_native_groups']['peer']['mean']
    receipt = dict(status='OFFLINE_HISTORICAL_COMMON_90_CORRECTION', date='2026-10-27',
        original_evidence='inference-b2-current-attribution-2026-10-26.json',
        original_source_scope='Historical Model dfaa530b/sampling085be10d and peer632, 99 teacher-forced R2 episodes, 1728 input rows, 198 equal decisions; each original process passed its complete non-time gate.',
        current_HEAD_at_review='2fe2916cf; historical trace is not the current kernel/copy/capture inventory',
        origins=S['origins'], original_not_record=compact(S['original_not_record_groups']),
        corrected_common_native=compact(S['corrected_common_native_groups']),
        selection=dict(common_roots=90, both_no_record=True, exact_same_seq_and_full_physical_meta=True,
                       both_exactly_one_native_graph_launch=True,
                       excluded_peer_eager_sequences=S['excluded_peer_not_record_sequences']),
        corrected_differences_ms=dict(wall=(h['wall_ns']-p['wall_ns'])/1e6,
            kernel_union=(h['kernel_union_ns']-p['kernel_union_ns'])/1e6,
            gpu_union=(h['gpu_union_ns']-p['gpu_union_ns'])/1e6),
        interpretation=[
            'The original not-record predicates independently select Hyle90 and peer93. The peer93 includes three eager/no GraphLaunch roots; the reported 12.88/11.83ms follows these different denominators.',
            'Common90 still has758/709 kernels and132/0 D2D events. Hyle D2D actual mean sum0.136589ms/root is about1.06% of its wall; event count alone is not a cost attribution.',
            'D2D is a positive component of the old GPU difference, but other kernel/copy work offsets it. Peer state/cache updates may be kernels. This does not prove the D2D work is removable or absent after indexed-state changes.',
            'Time before the first kernel includes earlier GPU copies and gaps, so it is not CPU self-time. Time after the last GPU activity is reported separately and correctly corresponds to the review table endpoint.',
            'The displayed kernel-span idle uses an explicit union-of-all-observed-activity definition. A different graph-gap definition is not automatically contradicted.',
            'Intervals are filtered to the actual process and revalidated inside each root; all GPU unions exactly match retained facts. Original SQLite hashes match original quality manifests.',
            'One historical profiled process per engine; no new TPS, causal speedup, DRAM-bandwidth, current capture count, model quality or statistical conclusion.'
        ], operations=dict(new_model_processes=0, new_GPU_processes=0, builds=0, downloads=0,
                           original_SQLite_open='mode=ro&immutable=1', original_analysis_files_changed=False),
        files=manifest)
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST/(NAME+'.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for file, identity in zip(inputs, manifest):
            z.write(file, identity['path'])
    with zipfile.ZipFile(archive) as z:
        assert z.namelist() == [x['path'] for x in manifest]
        for identity in manifest:
            data = z.read(identity['path'])
            assert len(data) == identity['bytes']
            assert hashlib.sha256(data).hexdigest() == identity['sha256']
    receipt['archive'] = pin(archive)
    public = DEST/(NAME+'.json')
    public.write_bytes((json.dumps(receipt, indent=2, ensure_ascii=False)+'\n').encode('utf-8'))
    assert json.loads(public.read_text(encoding='utf-8')) == receipt
    result = dict(status='PACKED_AND_READBACK_VERIFIED', json=pin(public), zip=pin(archive), files=len(manifest))
    (W/'package-result.json').write_bytes((json.dumps(result, indent=2)+'\n').encode())
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
