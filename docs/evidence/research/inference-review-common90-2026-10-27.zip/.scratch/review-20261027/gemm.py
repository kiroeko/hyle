import json, sqlite3, sys, collections, bisect
facts = json.load(open(sys.argv[1], encoding='utf-8'))
def run(db, engine, names):
    rows = [(r['start_ns'], r['end_ns']) for r in facts[engine]['decode_rows'] if not r['record']]
    con = sqlite3.connect('file:' + db + '?mode=ro', uri=True)
    cur = con.cursor()
    strings = dict(cur.execute('select id, value from StringIds'))
    kern = cur.execute('select start, end, shortName, gridX, gridY, gridZ, blockX, blockY, blockZ, registersPerThread, staticSharedMemory, dynamicSharedMemory from CUPTI_ACTIVITY_KIND_KERNEL order by start').fetchall()
    ks = [k[0] for k in kern]
    agg = collections.defaultdict(lambda: [0, 0])
    for s, e in rows:
        i = bisect.bisect_left(ks, s)
        while i < len(kern) and kern[i][0] < e:
            k = kern[i]; nm = strings.get(k[2], '')
            if nm in names:
                key = (nm, k[3], k[4], k[5], k[6], k[7], k[8], k[10] + k[11])
                agg[key][0] += k[1] - k[0]; agg[key][1] += 1
            i += 1
    n = len(rows)
    print('=====', engine, n, 'roots')
    for key, (t, c) in sorted(agg.items(), key=lambda x: -x[1][0]):
        print(f'  {t/n/1e3:8.1f} us/step  {c/n:5.1f}/step  {t/c/1e3:8.2f} us avg  name={key[0]} grid=({key[1]},{key[2]},{key[3]}) block=({key[4]},{key[5]},{key[6]}) smem={key[7]}')
run(sys.argv[2], 'hyle', {'Kernel2', 'arg_tiles_kernel'})
run(sys.argv[3], 'peer', {'mul_mat_f', 'mul_mat_vec_f', 'Kernel2', 'argmax_f32'})
