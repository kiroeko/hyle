import json, sqlite3, sys, collections

def load_rows(facts, engine):
    rows = facts[engine]['decode_rows']
    return [(r['start_ns'], r['end_ns'], r['record']) for r in rows]

def analyze(db, rows, label, top=28):
    con = sqlite3.connect('file:' + db + '?mode=ro', uri=True)
    cur = con.cursor()
    strings = dict(cur.execute('select id, value from StringIds'))
    kern = cur.execute('select start, end, shortName, gridX, gridY, gridZ, blockX, blockY, blockZ from CUPTI_ACTIVITY_KIND_KERNEL order by start').fetchall()
    mcpy = cur.execute('select start, end, bytes, copyKind from CUPTI_ACTIVITY_KIND_MEMCPY order by start').fetchall()
    mset = cur.execute('select start, end, bytes from CUPTI_ACTIVITY_KIND_MEMSET order by start').fetchall()
    hot = [(s, e) for s, e, rec in rows if not rec]
    by_name = collections.defaultdict(lambda: [0, 0])
    busy_total = 0; span_total = 0; nk_total = 0; ncpy = 0; cpy_ns = 0; nset = 0
    import bisect
    kstarts = [k[0] for k in kern]
    for s, e in hot:
        i = bisect.bisect_left(kstarts, s)
        ivs = []
        while i < len(kern) and kern[i][0] < e:
            ks, ke, nm = kern[i][0], kern[i][1], kern[i][2]
            name = strings.get(nm, str(nm))
            by_name[name][0] += ke - ks; by_name[name][1] += 1
            ivs.append((ks, ke)); nk_total += 1
            i += 1
        for ms, me, b, kind in mcpy:
            if s <= ms < e:
                ivs.append((ms, me)); ncpy += 1; cpy_ns += me - ms
        for ms, me, b in mset:
            if s <= ms < e:
                ivs.append((ms, me)); nset += 1
        ivs.sort()
        busy = 0; cur_s = cur_e = None
        for a, b in ivs:
            if cur_e is None or a > cur_e:
                if cur_e is not None: busy += cur_e - cur_s
                cur_s, cur_e = a, b
            else:
                cur_e = max(cur_e, b)
        if cur_e is not None: busy += cur_e - cur_s
        busy_total += busy
        if ivs: span_total += max(b for a, b in ivs) - ivs[0][0]
    n = len(hot)
    wall = sum(e - s for s, e in hot)
    print(f'===== {label}: {n} non-record decode roots')
    print(f'  wall/step {wall/n/1e6:.3f} ms; GPU busy/step {busy_total/n/1e6:.3f} ms; first->last GPU span/step {span_total/n/1e6:.3f} ms; idle inside span {(span_total-busy_total)/n/1e6:.3f} ms')
    print(f'  kernels/step {nk_total/n:.1f}; memcpy/step {ncpy/n:.1f} ({cpy_ns/n/1e3:.1f} us); memset/step {nset/n:.1f}')
    tot = sum(v[0] for v in by_name.values())
    print(f'  sum kernel time/step {tot/n/1e6:.3f} ms')
    for name, (t, c) in sorted(by_name.items(), key=lambda x: -x[1][0])[:top]:
        print(f'  {t/n/1e3:8.1f} us/step  {c/n:6.1f}/step  {t/c/1e3:7.2f} us avg  {name[:110]}')
    return by_name, n

facts = json.load(open(sys.argv[1], encoding='utf-8'))
h = analyze(sys.argv[2], load_rows(facts, 'hyle'), 'HYLE B2')
p = analyze(sys.argv[3], load_rows(facts, 'peer'), 'llama.cpp B2')
