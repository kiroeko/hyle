import json, sqlite3, sys, collections, bisect
facts = json.load(open(sys.argv[1], encoding='utf-8'))
def run(db, engine):
    rows = [(r['start_ns'], r['end_ns']) for r in facts[engine]['decode_rows'] if not r['record']]
    con = sqlite3.connect('file:' + db + '?mode=ro', uri=True)
    cur = con.cursor()
    strings = dict(cur.execute('select id, value from StringIds'))
    acts = []
    for s, e, nm in cur.execute('select start, end, shortName from CUPTI_ACTIVITY_KIND_KERNEL'):
        acts.append((s, e, 'K:' + strings.get(nm, '?')))
    kinds = dict(cur.execute('select id, name from ENUM_CUDA_MEMCPY_OPER'))
    for s, e, b, k in cur.execute('select start, end, bytes, copyKind from CUPTI_ACTIVITY_KIND_MEMCPY'):
        acts.append((s, e, 'C:%s:%d' % (kinds.get(k, k), b)))
    for s, e, b in cur.execute('select start, end, bytes from CUPTI_ACTIVITY_KIND_MEMSET'):
        acts.append((s, e, 'S:%d' % b))
    acts.sort()
    starts = [a[0] for a in acts]
    small = 0; big = 0; nbig = 0; lead = 0; tail = 0
    big_by_prev = collections.defaultdict(lambda: [0, 0])
    copy_kinds = collections.defaultdict(lambda: [0, 0, 0])
    first_kinds = collections.Counter()
    for s, e in rows:
        i = bisect.bisect_left(starts, s)
        seq = []
        while i < len(acts) and acts[i][0] < e:
            seq.append(acts[i]); i += 1
        if not seq: continue
        lead += seq[0][0] - s
        first_kinds[seq[0][2].split(':')[0] + ':' + seq[0][2].split(':')[1][:20]] += 1
        end_max = seq[0][1]
        for a, b in zip(seq, seq[1:]):
            gap = b[0] - end_max
            if gap > 0:
                if gap > 20000:
                    big += gap; nbig += 1
                    key = a[2][:40] + '  ->  ' + b[2][:40]
                    big_by_prev[key][0] += gap; big_by_prev[key][1] += 1
                else:
                    small += gap
            end_max = max(end_max, b[1])
        tail += e - end_max
        for a in seq:
            if a[2].startswith('C:'):
                _, kind, nbytes = a[2].split(':')
                copy_kinds[kind][0] += 1; copy_kinds[kind][1] += int(nbytes); copy_kinds[kind][2] += a[1] - a[0]
    n = len(rows)
    print(f'===== {engine}: {n} roots; per step: lead(host before first GPU op) {lead/n/1e3:.0f} us, small gaps(<20us) {small/n/1e3:.0f} us, big gaps(>20us) {big/n/1e3:.0f} us in {nbig/n:.1f} gaps, tail {tail/n/1e3:.0f} us')
    print('  first GPU op kinds:', first_kinds.most_common(4))
    for k, (c, b, t) in sorted(copy_kinds.items(), key=lambda x: -x[1][0]):
        print(f'  memcpy {k}: {c/n:.1f}/step, {b/c:.0f} B avg, {t/n/1e3:.1f} us/step')
    for key, (t, c) in sorted(big_by_prev.items(), key=lambda x: -x[1][0])[:12]:
        print(f'  big gap {t/n/1e3:7.1f} us/step ({c/n:4.1f}/step, {t/c/1e3:6.1f} us avg): {key}')
run(sys.argv[2], 'hyle')
run(sys.argv[3], 'peer')
