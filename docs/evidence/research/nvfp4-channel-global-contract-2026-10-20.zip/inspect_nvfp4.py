"""Bounded readonly artifact/header and pinned primary-source inspection."""
import hashlib
import json
import pathlib
import re
import struct
import urllib.error
import urllib.request
import zipfile

HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
HERE.mkdir(exist_ok=True)
records=[]
def save(n,x):(HERE/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def fetch(url,name,limit,byte_range=None):
 headers={'User-Agent':'hyle-bounded-readonly-contract-review/1'}
 if byte_range:headers['Range']=f'bytes={byte_range[0]}-{byte_range[1]}'
 req=urllib.request.Request(url,headers=headers)
 row={'url':url,'requested_range':headers.get('Range'),'maximum_bytes_read':limit}
 try:
  with urllib.request.urlopen(req,timeout=40) as r:
   row['status']=r.status
   row['headers']={k:v for k,v in r.headers.items() if k.lower() in ['content-type','content-length','content-range','etag','x-repo-commit']}
   if byte_range:
    expected=f'bytes {byte_range[0]}-{byte_range[1]}/'
    if r.status!=206 or not r.headers.get('Content-Range','').startswith(expected):
     raise RuntimeError('Refusing non-exact range response before reading body')
   body=r.read(limit+1)
   if len(body)>limit:raise RuntimeError('bounded response exceeds requested small-source limit')
   if byte_range:assert len(body)==byte_range[1]-byte_range[0]+1
  p=HERE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
  row.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),file=name)
  records.append(row);save('http-receipt.json',records)
  return body
 except Exception as e:
  row['error']=str(e);records.append(row);save('http-receipt.json',records);return None

z=zipfile.ZipFile(REPO/'docs/evidence/research/model-quantization-discovery-2026-10-19.zip')
prefix='qwen-kimi/AxionML--Qwen3.5-2B-NVFP4/'
for n in ['api-model.json','config.json','hf_quant_config.json','metadata-identity.json']:
 p=HERE/'saved-metadata'/n;p.parent.mkdir(exist_ok=True);p.write_bytes(z.read(prefix+n))

repo='AxionML/Qwen3.5-2B-NVFP4';revision='6f2ad4febe92be529de499b08f0020f5ff06bf25'
base=f'https://huggingface.co/{repo}/resolve/{revision}/model.safetensors'
b=fetch(base+'?hyle_review=length','header-length.bin',8,(0,7))
if b:
 length=struct.unpack('<Q',b)[0]
 assert 0<length<=1024*1024,length
 header=fetch(base+'?hyle_review=header','model.safetensors.header.json',length,(8,7+length))
 if header:
  tensors=json.loads(header);role='model.language_model.layers.0.mlp.gate_proj'
  save('header-role-facts.json',{'repository':repo,'revision':revision,'header_bytes':length,
   'tensor_payload_bytes_read':0,'total_tensors':len(tensors)-('__metadata__' in tensors),
   'quantized_role_tensors':{k:v for k,v in tensors.items() if k.startswith(role)},
   'scale_dtype_census':{d:sum(v.get('dtype')==d and 'scale' in k for k,v in tensors.items() if k!='__metadata__') for d in sorted({v.get('dtype') for k,v in tensors.items() if k!='__metadata__'})},
   'quantized_role_count':sum(k.endswith('.weight_scale_2') for k in tensors),
   'scale_tensor_names':[k for k in tensors if any(s in k for s in ['input_scale','weight_scale'])][:20]})
fetch('https://api.github.com/repos/NVIDIA/Model-Optimizer/commits/82f1d216d','modelopt-producer-commit.json',100000)
fetch('https://raw.githubusercontent.com/NVIDIA/Model-Optimizer/82f1d216d/modelopt/torch/quantization/qtensor/nvfp4_tensor.py','modelopt/nvfp4_tensor.py',100000)
fetch('https://raw.githubusercontent.com/NVIDIA/Model-Optimizer/82f1d216d/modelopt/torch/quantization/tensor_quant.py','modelopt/tensor_quant.py',200000)
print(json.dumps({'requests':len(records),'read_bytes':sum(r.get('bytes',0) for r in records),'errors':[r.get('error') for r in records if 'error' in r]},indent=2))
