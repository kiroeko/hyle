"""Summarize one confirmed missing contract; never runs product operators."""
import hashlib
import json
import pathlib
HERE=pathlib.Path(__file__).resolve().parent
REPO=HERE.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def identity(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
http=read(HERE/'http-receipt.json')
census=read(HERE/'full-quantized-role-census.json')
assert census['quantized_roles']==186 and not census['violations']
pin='82f1d216d1a9022e60b8e1143a77f36c00b885a4'
assert read(HERE/'modelopt-producer-commit.json')['sha']==pin
report={
 'status':'confirmed missing public storage/activation contract; source-only implementation proposal, not a runtime failure or artifact acceptance',
 'selected_next_item':'ModelOpt calibrated-global NVFP4 W4A4 group16 linear, preserving original U8 packed codes, E4M3 block scales, independent F32 weight/input global scales and original activation quantization.',
 'why_this_one':'It is a real unrepresented domain with a small fixed2B artifact and186 independently header-verified language linear roles. Its producer resolves to an exact primary-source commit. It supplies reusable group16/two-level FP4 semantics without extending the current dynamic-FP8 Cast/capture work or a model-specific engine. GPTQ and CT local-dynamic remain separate candidates, not aliases of this contract.',
 'target':{'table_pointer':'docs/implementation/model-quantizations.json#/artifacts/3',
  'repository':'AxionML/Qwen3.5-2B-NVFP4','revision':'6f2ad4febe92be529de499b08f0020f5ff06bf25',
  'producer_record':'modelopt 0.0.1.dev1+g82f1d216d','resolved_source_revision':pin,
  'header_bytes':146464,'header_prefix_bytes':8,'tensor_payload_bytes_read':0,
  'total_header_tensors':1190,'actual_quantized_language_roles':186,
  'all_quantized_role_quartets_checked':True,
  'role_contract':{'weight':'U8[N,K/2], adjacent even element in low nibble and odd element in high nibble',
   'weight_scale':'F8_E4M3[N,K/16]; producer writes torch.float8_e4m3fn',
   'weight_scale_2':'F32 scalar[]','input_scale':'F32 scalar[]'},
  'role_example':'model.language_model.layers.0.mlp.gate_proj: N6144,K2048; weight[6144,1024], scale[6144,128], two scalar F32 tensors.',
  'shape_census':census['shape_census']},
 'new_primary_source_facts':[
  {'file':'modelopt/nvfp4_tensor.py','lines':'27-28,179-197,300-305,357-376','fact':'Original E2M1 values/bounds, exported activation scale = amax/(6*448), adjacent low-first nibble packing and separate group/global weight scales.'},
  {'file':'modelopt/config.py','lines':'403-418','fact':'The producer NVFP4 default uses dynamic16-element block scales for weight/input while its global amax can be calibrated. Serialized dynamic=false must not be read as fixed per-block activation scales.'},
  {'file':'modelopt/tensor_quantizer.py','lines':'761-784','fact':'Dynamic block path passes the retained/calibrated amax to dynamic_block_quant.'},
  {'file':'modelopt/tensor_quant.py','lines':'150-180','fact':'E2M1+E4M3 dynamic block path dispatches the pinned fp4_fake_quant_block on SM>=8.9; otherwise the original CUDA MX extension. This is not the existing group32 power-of-two model roundtrip.'},
  {'file':'modelopt/fp4_kernel_hopper.py','lines':'77-138,176','fact':'Original fake-quant reference computes runtime16-value block absmax, quantizes normalized scale to E4M3, applies its small-scale guard, rounds to E2M1 and narrows back to the input dtype.'},
 ],
 'math_reference':{
  'input':'For the fixed producer BF16 fake-quant reference, g is the exported calibrated positive input_scale. b is max(abs(A)) for each current16-element block. s = F32(RNE_E4M3(min(b/(6*g),448))*g). The original reference replaces s<1e-5 by1; it also uses a positive safe denominator for invalid/nonpositive g. E2M1 uses nearest-even boundaries0.25/0.75/1.25/1.75/2.5/3.5/5, max6. Return BF16(sign(A)*E2M1(abs(A)/s)*s).',
  'weight':'Codes are original packed E2M1. Non-fast producer dequant first computes scale_product=F32(E4M3(weight_scale)*weight_scale_2), multiplies the decoded FP4 value, then converts to the requested original dtype. Preserve the original operand/storage narrowing when constructing the dense-BF16 reference.',
  'critical_rounding_qualification':'The same producer fast dequant kernel expresses (FP4*group_scale)*global_scale, whereas its non-fast path forms group_scale*global_scale first. Neither the artifact header nor this read-only review proves their bit tree universally equivalent. A new public contract must deliberately pin the chosen reference/operand rounding; hardware-native fused NVFP4 accumulation must be admitted/tested against that contract, not assumed bit-identical.',
  'not_a_runtime_result':'These are facts from the saved pinned source, not product execution or a quality comparison.',
  'useful_small_witness':'BF16 A has32 values: first16 are1.25, second16 are6; calibrated g=F32(1/448). Group16 E4M3 scale for the first block rounds near93.333 to96, giving an NVFP4 QDQ result near1.285714 before BF16 storage. Existing group32 power-of-two FP4 roundtrip sees absmax6, scale1, and rounds the first block1.25 to1. This source-derived witness distinguishes the missing activation behavior; it was not executed as a product test here.'},
 'confirmed_product_missing_paths':[
  {'path':'include/hyle/compute/model_ops.h:229','fact':'WeightArtifactFormat has NF4/nested NF4/AWQ/CT integer formats, no ModelOpt group16 E2M1+FP8+F32 decoder.'},
  {'path':'src/compute_ops/weight_decode.cc:132','fact':'ArtifactWeightDecode rejects all undeclared formats; its existing packed-int and NF4 admissions do not match this U8/E4M3/scalar tensor quartet.'},
  {'path':'include/hyle/compute/model_ops.h:323','fact':'BlockQuantizationRoundtrip has only one input, supports E2M1 group32 power-of-two scale, no calibrated F32 scalar port or group16 E4M3 scale roundtrip.'},
  {'path':'include/hyle/compute/model_ops.h:498','fact':'GroupedFloat4Linear requires opaque E2M1/F32 group32 weights plus dynamic FP8 activation group128; it is not W4A4 group16.'},
  {'path':'src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc:31','fact':'The current grouped FP4 provider selects only that distinct descriptor and four precompiled geometry families; no ModelOpt ordinary linear admission exists.'},
  {'path':'include/hyle/compute/low_precision.h:81','fact':'GGUF NVFP4 is a64-value/36-byte interleaved identity with four inline scales and no separate calibrated activation/global scalar. Its subgroup nibble order differs from ModelOpt adjacent low-first pairs. Existing gguf routes do not constitute ModelOpt W4A4 support.'},
 ],
 'space_scale':{
  'actual_original_packed_weight_bytes':census['original_packed_weight_bytes'],
  'actual_original_group_scale_bytes':census['original_group_scale_bytes'],
  'global_and_input_scalar_bytes':census['global_and_input_scalar_bytes'],
  'hypothetical_whole_quantized_bank_BF16_bytes':census['hypothetical_dense_BF16_weight_bytes'],
  'hypothetical_whole_quantized_bank_F32_bytes':census['hypothetical_dense_F32_weight_bytes'],
  'gate_example':'6144x2048: codes6MiB + block scales0.75MiB; dense BF16 would be24MiB, F32 would be48MiB.',
  'consequence':'A cold decode alone is a useful explicit reference but does not preserve this artifact activation math and would expand186 quantized banks from772153344 bytes of codes/scales to2745434112 BF16 bytes. Do not call it completed space-efficient NVFP4 support.'},
 'minimum_correct_implementation_proposal':{
  'public_shape':'One explicit ordinary Nvfp4Linear-style descriptor following existing Float8BlockLinear/MlxQuantized conventions: BF16 A[M,K], U8 W[N,K/2], E4M3FN groupScale[N,K/16], F32 weightGlobal scalar and F32 calibratedInputGlobal scalar -> BF16[M,N]; fixed group16, K complete, actual N may be16. Bias remains ordinary Add. No model whitelist or precision mode on ordinary MatMul.',
  'common':'Common inference validates exact rank/type/axes/required_bytes, independent globals, complete16 groups and output geometry. Do not reuse an unknown enum or retag GGUF/MX/DeepSeek carriers.',
  'cpu':'Reuse the original provider/context/queue and owned bindings. A scalar staged reference applies the pinned activation QDQ, decodes only a selected weight group/tile, preserves declared narrowing, and accumulates through the chosen documented reference. No whole-bank float copy per Invocation.',
  'cuda':'Use the original QueueSequence/provider preparation and fixed source numerical helpers. Quantize A once per actual row/block into existing caller-owned workspace, then read packed original W/scales/globals in bounded tiles. Mature native NVFP4 GEMM can be a hardware-qualified lowering; SM89 needs a legal packed/dequantized-tile fallback, not an assumption of Blackwell FP4 tensor-core support. Do not substitute dynamic FP8 A or allocate a whole dense bank.',
  'graph':'First an ordinary typed operator/consumer with actual constant ownership and two independent slots; later cold region recognition can fuse equivalent explicit decoder/QDQ/MatMul fragments without new executor or runtime route lookup. The current shared architecture can carry it.',
  'likely_source_owners':['include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc or a sibling format-inference TU','src/compute_provider_native/torch_cpu_program.cc and its provider registration','a separate CUDA native NVFP4 provider/kernel owner registered in existing cuda_provider.cc/default route','tests/compute_models shared independent fixture plus existing CPU/CUDA provider/Graph owner'],
  'small_real_regression':'M2,N3,K32; original adjacent-nibble bitpack, distinct group/global scale values, both16-blocks, exact E2M1 ties and the reference tiny-scale guard, two A updates, independent invocation slots and retained output. Then one real header geometry N16/K2048 and one N6144/K2048 can exercise admission/tiling without full-model payload. Do not require a large Cartesian matrix.',
  'before_claiming_artifact_equivalence':['Choose and document non-fast BF16-reference versus hardware-native accumulation/scale ordering; the two existing producer expressions are not a proof of bit equality.','Check original scalar values/domain with bounded scalar reads when actual artifact binding is attempted; this review read zero weight/scalar payload bytes.','Keep CT local-dynamic tensor_group16 separate until its own global scale axes, floor/epsilon and storage expressions are inspected.']},
 'alternatives_not_selected':{
  'CT_local_dynamic_W4A4':'Actual config has group16 E4M3 tensor_group NVFP4 and local-dynamic A4, but no tensor header/global-scale payload/source path for this exact CT artifact was read this round. Its quantizer must not be inferred from ModelOpt merely because both say NVFP4.',
  'GPTQ':'Table artifacts1/10 still have no exact GPTQ decoder. Fixed config is sym INT4 g32/g64 desc_act=false, but qzeros convention/g_idx presence and config/sidecar MTP precedence remain to inspect. Do not reuse AWQ/CT packing based on names. ModelOpt was selected because this round now resolves its original headers and producer source.'},
 'existing_sources_and_sdk_scope':{'lock':'cmake/HyleDependencyLock.json pins CT ac8e2ba82f4e and FlashInfer69ff11fc; no ModelOpt/GPTQ dependency or ModelOpt public op was found. Current Windows dependency source cache has no ModelOpt/CT/GPTQ checkout. Existing local GGUF/DeepSeek kernels were inspected as different contracts; no SDK was built or downloaded.',
  'new_small_network_reads':{'requests':len(http),'bytes':sum(r.get('bytes',0) for r in http),'artifact_tensor_payload_bytes':0,'errors':[r.get('error') for r in http if 'error' in r]},
  'primary_source_url':'https://github.com/NVIDIA/Model-Optimizer/tree/'+pin,
  'current_official_doc_context_only':'https://nvidia.github.io/Model-Optimizer/reference/generated/modelopt.torch.quantization.qtensor.nvfp4_tensor.html'},
 'execution_limits':['No product edits, compilation, link, SDK/native build, GPU run or product operator test.','No artifact weight/scalar payload, model inference, quality, performance or peak-memory result.','Header data_offsets sizes and hypothetical dense sizes are geometry arithmetic, not measured memory.'],
 'evidence':[identity(p) for p in [HERE/'http-receipt.json',HERE/'model.safetensors.header.json',HERE/'header-role-facts.json',HERE/'full-quantized-role-census.json',HERE/'modelopt-producer-commit.json',*sorted((HERE/'modelopt').glob('*.py'))]],
 'current_product_identities':[identity(REPO/p) for p in ['docs/implementation/model-quantizations.json','docs/implementation/model-operators.md','include/hyle/compute/model_ops.h','include/hyle/compute/low_precision.h','src/compute_ops/weight_decode.cc','src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc','src/compute_provider_ggml_cuda/tensor_program.cc','cmake/HyleDependencyLock.json']],
}
(HERE/'review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'report':identity(HERE/'review.json'),'quantized_roles':186,'HTTP_bytes':sum(r.get('bytes',0) for r in http),'product_execution':False},indent=2))
