"""Read small local HTTP/acquisition metadata only; never open model bodies."""
import collections
import datetime as dt
import hashlib
import json
import pathlib
import re
import subprocess
import urllib.parse

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUT = pathlib.Path(__file__).resolve().parent
NOW = dt.datetime.now(dt.timezone.utc)
SINCE = NOW - dt.timedelta(hours=24)
MAX_METADATA = 12 * 1024 * 1024

def timestamp(value):
    if isinstance(value, (int, float)) and value > 1_000_000_000:
        return dt.datetime.fromtimestamp(value, dt.timezone.utc)
    if isinstance(value, str):
        try:
            x = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
            return x.replace(tzinfo=dt.timezone.utc) if x.tzinfo is None else x.astimezone(dt.timezone.utc)
        except ValueError:
            pass
    return None

def norm_url(value):
    if not isinstance(value, str) or not value.startswith(('https://', 'http://')):
        return None
    x = urllib.parse.urlsplit(value)
    return urllib.parse.urlunsplit((x.scheme.lower(), x.netloc.lower(), x.path, '', ''))

def candidates():
    cmd = ['rg', '--files', '.scratch']
    for glob in ('*acquisition*.json', 'http-requests*.json', '*receipt*.json', '*download*.json'):
        cmd += ['-g', glob]
    for glob in ('sdk', 'SDK', 'vendor', 'upstream', 'node_modules', 'source*', 'compile*', 'tests-link*', 'before', 'next-source', 'environment'):
        cmd += ['-g', '!**/' + glob + '/**']
    p = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    return sorted(set(p.stdout.splitlines())), p.stderr.strip()

def range_of(row):
    for key in ('absolute_inclusive', 'absolute_range', 'requested_range', 'range_inclusive', 'range'):
        x = row.get(key)
        if isinstance(x, list) and len(x) == 2 and all(isinstance(z, int) for z in x):
            return x
        if isinstance(x, str):
            m = re.search(r'(?:bytes[= ]+)?(\d+)-(\d+)', x)
            if m:
                return [int(m[1]), int(m[2])]
    if isinstance(row.get('first'), int) and isinstance(row.get('last'), int):
        return [row['first'], row['last']]
    for obj, key in ((row, 'content_range'), (row.get('headers', {}), 'Content-Range'), (row.get('requested_headers', {}), 'Range')):
        x = obj.get(key) if isinstance(obj, dict) else None
        if isinstance(x, str):
            m = re.search(r'(?:bytes[= ]+)?(\d+)-(\d+)', x)
            if m:
                return [int(m[1]), int(m[2])]
    return None

def source_url(row, doc):
    for obj in (row, doc):
        for key in ('url', 'source_url', 'request_url'):
            url = norm_url(obj.get(key))
            if url:
                return url
    if doc.get('repository') and doc.get('revision') and doc.get('file'):
        return norm_url('https://huggingface.co/' + doc['repository'] + '/resolve/' + doc['revision'] + '/' + doc['file'])
    roles = doc.get('roles', [])
    if isinstance(roles, list):
        for role in roles:
            if isinstance(role, dict) and role.get('name') == row.get('role'):
                url = norm_url(role.get('url'))
                if url:
                    return url
    shards = doc.get('shards', [])
    groups = doc.get('groups', [])
    group = row.get('group')
    if isinstance(group, int) and isinstance(groups, list) and 0 <= group < len(groups):
        index = groups[group].get('source_shard')
        if isinstance(index, int) and isinstance(shards, list) and 0 <= index < len(shards):
            return norm_url(shards[index].get('url'))
    return None

events = {}
unmeasured = []
documents = []
skipped = []
unhandled = []
paths, rg_errors = candidates()
for path in paths:
    p = ROOT / path
    try:
        size = p.stat().st_size
        if size > MAX_METADATA:
            skipped.append({'path': path, 'bytes': size, 'reason': 'metadata size cap'})
            continue
        raw = p.read_bytes()
        doc = json.loads(raw.decode('utf-8-sig'))
    except (OSError, ValueError) as e:
        skipped.append({'path': path, 'reason': str(e)[:180]})
        continue
    digest = hashlib.sha256(raw).hexdigest()
    documents.append({'path': path.replace('\\', '/'), 'bytes': size, 'sha256': digest})
    root = doc if isinstance(doc, dict) else {}
    rows = root.get('requests')
    if isinstance(doc, list) and ('http-request' in p.name or 'receipt' in p.name):
        rows = doc
    if not isinstance(rows, list) and isinstance(root.get('attempts'), list) and any(isinstance(x, dict) and 'http_status' in x for x in root['attempts']):
        rows = root['attempts']
    if not isinstance(rows, list) and isinstance(root.get('roles'), list) and any(isinstance(x, dict) and 'http_status' in x for x in root['roles']):
        rows = root['roles']
    if not isinstance(rows, list) and any(k in root for k in ('started_utc', 'started_unix', 'started')) and range_of(root):
        rows = [root]
    # A standalone HTTP receipt is a certificate, not an independently timed request.
    if not isinstance(rows, list):
        if any(key in root for key in ('url', 'content_range', 'network_bytes', 'requested_range', 'http_status')):
            unmeasured.append({'path': path.replace('\\', '/'), 'reason': 'standalone certificate; not added to request traffic', 'complete': root.get('complete')})
        elif 'acquisition' in p.name:
            unhandled.append({'path': path.replace('\\', '/'), 'keys': list(root)[:25]})
        continue
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            continue
        interval = range_of(row) or range_of(root)
        url = source_url(row, root)
        started = next((timestamp(row.get(k)) for k in ('started_utc', 'started_unix', 'started', 'started_at', 'utc', 'time') if timestamp(row.get(k)) is not None), None)
        finished = next((timestamp(row.get(k)) for k in ('finished_utc', 'finished_unix', 'finished', 'finished_at') if timestamp(row.get(k)) is not None), None)
        # Same original event copied to archives/snapshots: URL+range+start is stable.
        # Untimed certificates are retained separately and cannot prove request multiplicity.
        if started is None:
            unmeasured.append({'path': path.replace('\\', '/'), 'request': index, 'reason': 'no request start timestamp', 'url': url, 'range': interval})
            continue
        if not url:
            etag = row.get('etag') or root.get('etag')
            source = 'unresolved:' + str(etag or root.get('repository') or digest) + ':' + str(root.get('revision', ''))
        else:
            source = url
        key = (source, tuple(interval or []), started.isoformat())
        body = row.get('body', row.get('payload', {}))
        received = next((row[k] for k in ('received_bytes', 'bytes_received', 'written_bytes', 'bytes') if isinstance(row.get(k), int)), None)
        if received is None and isinstance(body, dict) and isinstance(body.get('bytes'), int):
            received = body['bytes']
        if received is None and row.get('complete') is True and isinstance(row.get('content_length'), (str, int)):
            # A completed exact response with its stored payload hash proves the consumed length.
            if root.get('group_sha256') or root.get('downloaded_payload_bytes'):
                received = int(row['content_length'])
        requested = row.get('requested_bytes')
        if not isinstance(requested, int) and interval:
            requested = interval[1] - interval[0] + 1
        error = row.get('error') or row.get('error_type') or row.get('cancelled_for_parallel_resume') or row.get('cancelled')
        status = row.get('http_status', row.get('status'))
        complete = row.get('complete') is True or (status in (200, 206) and not error and received is not None and requested == received)
        kind = 'model_weight' if ('acquisition' in p.name and p.name != 'acquisition-processes.json') else 'model_metadata'
        if url and not any(x in url for x in ('huggingface.co', 'hf.co', 'xethub', 'hf-mirror')):
            kind = 'dependency_or_other'
        event = {'source': source, 'range': interval, 'requested_bytes': requested, 'received_bytes': received,
                 'complete': complete, 'error': str(error)[:250] if error else None,
                 'status': status, 'started_utc': started.isoformat(), 'finished_utc': finished.isoformat() if finished else None,
                 'category': kind, 'stage': pathlib.PurePath(path.replace('\\', '/')).parts[1],
                 'provenance': [path.replace('\\', '/') + '#requests/' + str(index)]}
        old = events.get(key)
        if old:
            old['provenance'].extend(event['provenance'])
            if kind == 'model_weight':
                old['category'] = kind
            if event['complete'] and not old['complete']:
                event['provenance'] = old['provenance']
                if old['category'] == 'model_weight':
                    event['category'] = 'model_weight'
                events[key] = event
            elif old['received_bytes'] is None and received is not None:
                old['received_bytes'] = received
        else:
            events[key] = event

def union_bytes(items):
    grouped = collections.defaultdict(list)
    for e in items:
        if e['range'] and e['complete'] and e['received_bytes'] == e['range'][1] - e['range'][0] + 1:
            grouped[e['source']].append(e['range'])
    total = 0
    for intervals in grouped.values():
        end = -1
        for first, last in sorted(intervals):
            total += max(0, last - max(end, first - 1))
            end = max(end, last)
    return total

def summarize(items):
    good = [e for e in items if e['complete']]
    failed = [e for e in items if not e['complete']]
    successful = sum(e['received_bytes'] or 0 for e in good)
    exact_ranges = [e for e in good if e['range'] and e['received_bytes'] == e['range'][1] - e['range'][0] + 1]
    repeated = sum(e['received_bytes'] for e in exact_ranges) - union_bytes(exact_ranges)
    failed_known = sum(e['received_bytes'] for e in failed if e['received_bytes'] is not None)
    unknown = [e for e in failed if e['received_bytes'] is None]
    bounded = [e for e in unknown if e['requested_bytes'] is not None]
    return {'requests': len(items), 'successful_requests': len(good), 'successful_body_bytes': successful,
            'successful_unique_source_range_bytes': union_bytes(exact_ranges), 'successful_repeated_range_bytes': repeated,
            'successful_requests_without_received_byte_count': sum(e['received_bytes'] is None for e in good),
            'failed_or_cancelled_requests': len(failed), 'failed_known_received_bytes': failed_known,
            'failed_unknown_received_requests': len(unknown),
            'failed_unknown_received_bytes': None if unknown else 0,
            'failed_unknown_requested_body_upper_bound_bytes': sum(e['requested_bytes'] for e in bounded),
            'failed_unbounded_requests': len(unknown) - len(bounded)}

all_events = list(events.values())
recent = [e for e in all_events if SINCE <= timestamp(e['started_utc']) <= NOW]
by_stage = {}
for stage in sorted(set(e['stage'] for e in recent)):
    by_stage[stage] = summarize([e for e in recent if e['stage'] == stage])
summary = {
 'audit_utc': NOW.isoformat(), 'rolling_24h_start_utc': SINCE.isoformat(),
 'scope': 'Small local request/acquisition metadata; no network, model-body reads, SDK traversal or process termination.',
 'user_reported_network_bytes': 262_000_000_000,
 'user_counter_units_assumption': '262 decimal GB for comparison only; measurement layer/window not supplied.',
 'metadata_files_read': len(documents), 'request_rows_after_event_dedup': len(all_events),
 'deduplicated_copied_request_rows': sum(len(e['provenance']) - 1 for e in all_events),
 'all_timestamped_records': summarize(all_events), 'rolling_24h': summarize(recent),
 'rolling_24h_categories': {kind: summarize([e for e in recent if e['category'] == kind]) for kind in sorted(set(e['category'] for e in recent))},
 'rolling_24h_stages': by_stage,
 'untimed_or_standalone_certificates_not_added_to_traffic': len(unmeasured),
 'metadata_skipped': skipped, 'unhandled_acquisition_schemas': unhandled, 'rg_errors': rg_errors,
 'limitations': [
  'Successful payload bytes are HTTP response bodies recorded by application, not NIC traffic; TLS, headers, redirects, transport retransmits and unlogged tools are not measured.',
  'Unknown failed response bytes remain null; requested-range lengths bound only the intended application bodies, not transport/network retries.',
  'Whole shard/file capacity, cached role capacity and catalog/bundle sizes are not added to request traffic.',
  'Standalone or untimed receipts can authenticate artifacts but do not prove another distinct HTTP request; excluded from timestamped traffic.',
  'The difference from the reported 262GB cannot be attributed from these records alone.'
 ]}
OUT.mkdir(exist_ok=True)
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(OUT / 'request-ledger.json').write_text(json.dumps(all_events, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(OUT / 'metadata-inventory.json').write_text(json.dumps({'files': documents, 'untimed_certificates': unmeasured}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: summary[k] for k in ('metadata_files_read', 'request_rows_after_event_dedup', 'deduplicated_copied_request_rows', 'rolling_24h', 'rolling_24h_categories')}, ensure_ascii=False, indent=2))
print('unhandled', len(unhandled), 'skipped', len(skipped), 'standalone/untimed', len(unmeasured))
