"""Run explicitly selected MTP range acquisitions under one cumulative limit.

Reserve the full requested range before opening it, including failed attempts.
Existing local cache reads use no budget. Tests and inference never invoke this.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import runpy
import sys
import threading
import urllib.parse
import urllib.request

sys.dont_write_bytecode = True
DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[1]
TOTAL_LIMIT = 50_000_000_000
REQUEST_LIMIT = 48_000_000_000  # Leave2GB for protocol/transport overhead.
MUTEX = threading.Lock()


def now():
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def locked():
    DIRECTORY.mkdir(parents=True, exist_ok=True)
    with MUTEX, (DIRECTORY / 'budget.lock').open('a+b') as lock:
        lock.seek(0, 2)
        if not lock.tell():
            lock.write(b'0')
            lock.flush()
        lock.seek(0)
        if sys.platform == 'win32':
            import msvcrt
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            path = DIRECTORY / 'budget.json'
            if path.exists():
                record = json.loads(path.read_text('utf-8'))
            else:
                record = dict(started=now(), total_limit_bytes=TOTAL_LIMIT,
                    request_limit_bytes=REQUEST_LIMIT, reserved_request_bytes=0,
                    accounting='Full range reserved before every HTTP attempt; failures are not refunded. Historical cache is excluded.',
                    requests=[])
            assert record['total_limit_bytes'] == TOTAL_LIMIT
            assert record['request_limit_bytes'] == REQUEST_LIMIT
            assert record['reserved_request_bytes'] == sum(x['bytes'] for x in record['requests'])
            assert 0 <= record['reserved_request_bytes'] <= REQUEST_LIMIT
            yield record
            temporary = path.with_suffix('.json.next')
            temporary.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
            temporary.replace(path)
        finally:
            lock.seek(0)
            if sys.platform == 'win32':
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def reserve(url, first, last, script):
    amount = last - first + 1
    if first < 0 or amount <= 0:
        raise ValueError('Invalid closed HTTP range')
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https':
        raise ValueError('MTP acquisitions require HTTPS')
    with locked() as record:
        remaining = REQUEST_LIMIT - record['reserved_request_bytes']
        if amount > remaining:
            raise ValueError(f'MTP cumulative download limit: request {amount}B exceeds remaining {remaining}B; no HTTP request opened')
        ordinal = len(record['requests'])
        record['requests'].append(dict(id=ordinal, script=script, started=now(),
            url=urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, '', '')),
            range=[first, last], bytes=amount, outcome='reserved', received_bytes=None))
        record['reserved_request_bytes'] += amount
    return ordinal


def update(ordinal, **fields):
    with locked() as record:
        record['requests'][ordinal].update(fields, updated=now())


def guarded(original, script):
    def open_range(request, *args, **kwargs):
        header = request.get_header('Range') if isinstance(request, urllib.request.Request) else None
        match = re.fullmatch(r'bytes=(\d+)-(\d+)', header or '')
        if not match:
            raise ValueError('MTP download requires an explicit closed Range; refusing unbounded HTTP')
        ordinal = reserve(request.full_url, *map(int, match.groups()), script)
        try:
            response = original(request, *args, **kwargs)
        except BaseException as error:
            update(ordinal, outcome='open_failed', error_type=type(error).__name__)
            raise
        update(ordinal, outcome='opened', status=getattr(response, 'status', None))
        return response
    return open_range


def status():
    with locked() as record:
        print(json.dumps(dict(total_limit_bytes=TOTAL_LIMIT, request_limit_bytes=REQUEST_LIMIT,
            reserved_request_bytes=record['reserved_request_bytes'],
            remaining_request_bytes=REQUEST_LIMIT-record['reserved_request_bytes'],
            requests=len(record['requests'])), ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('status', 'run'))
    parser.add_argument('script', nargs='?', type=Path)
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.action == 'status':
        if args.script or args.arguments:
            parser.error('status takes no script or arguments')
        status()
        return
    if args.script is None:
        parser.error('run requires a fixed local acquisition script')
    script = args.script.resolve()
    if not script.is_relative_to(ROOT / '.scratch') or not script.is_file():
        parser.error('Acquisition script must exist under this repository .scratch')
    status()
    urllib.request.urlopen = guarded(urllib.request.urlopen, script.relative_to(ROOT).as_posix())
    forwarded = args.arguments[1:] if args.arguments[:1] == ['--'] else args.arguments
    sys.argv = [str(script), *forwarded]
    runpy.run_path(str(script), run_name='__main__')


if __name__ == '__main__':
    main()
