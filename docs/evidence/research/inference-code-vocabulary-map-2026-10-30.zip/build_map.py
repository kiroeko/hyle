#!/usr/bin/env python3
"""Build an offline, code-domain Qwen token-frequency prior from local sources.

This script never downloads, invokes Git, imports a model, or reads Hyle inputs.
It deliberately does not claim that source-code frequency is a general-language
prior. Each repository contributes a sorted whole-file prefix of at most 16 MiB.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import threading
import time


SCRIPT = Path(__file__).resolve()
BATCH = SCRIPT.parent
REPO_PARENT = Path("C:/public/project-hyle")
TOKENIZER_ROOT = Path("C:/Users/kiro/Downloads/Qwen3.5-2B")
VOCABULARY = 248320
PER_REPO_BYTES = 16 * 1024 * 1024
TOTAL_BYTES = 64 * 1024 * 1024
REQUESTED_RANKS = (32768, 65536)
TOKENIZER_PINS = {
    "tokenizer.json": "5f9e4d4901a92b997e463c1f46055088b6cca5ca61a6522d1b9f64c4bb81cb42",
    "tokenizer_config.json": "49e2b6e395f959f077f1e992b338919c0d4a9732fc6e613995e06557f843500c",
    "config.json": "ed1c1723241f23f7f4e23430759cbd7dcfb4103cbdfe052bfe7626b57c2615b4",
}

REPOSITORIES = (
    ("sglang", "234ccba7f625e12639e621044496bcc6197c3758",
     ("python/sglang", "rust", "sgl-model-gateway")),
    ("vllm", "276fbcff2717bd934cfa37c8a2e4c391f3e7237b",
     ("vllm", "csrc", "rust")),
    ("TensorRT-LLM", "46d9966b54d9d11998b712e732fb20f64d4d35c0",
     ("cpp/include", "cpp/kernels", "cpp/tensorrt_llm", "tensorrt_llm", "triton_kernels")),
    ("llama.cpp", "23b0202a189c44a54625aadcb37a946dd1d6278d",
     ("src", "include", "common", "ggml/src", "ggml/include", "gguf-py/gguf")),
)
SOURCE_SUFFIXES = frozenset((
    ".py", ".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx",
    ".cu", ".cuh", ".hip", ".metal", ".rs", ".wgsl", ".cl", ".mm", ".m",
    ".go", ".swift", ".mojo",
))
EXCLUDED_DIRECTORIES = frozenset((
    ".git", ".scratch", ".cache", "__pycache__", "test", "tests", "testing",
    "bench", "benches", "benchmark", "benchmarks", "micro_benchmarks", "speed-bench",
    "doc", "docs", "generated", "vendor", "vendors", "third_party", "third-party",
    "3rdparty", "extern", "external", "externals", "deps", "node_modules", "dist",
    "target", "template-instances", "examples", "eval",
))
GENERATED_BANNER = re.compile(
    rb"auto[- ]?generated|automatically generated|generated (?:file|by)|"
    rb"(?:do not edit[^\r\n]{0,120}generated)|(?:generated[^\r\n]{0,120}do not edit)",
    re.IGNORECASE,
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def excluded_directory(name: str) -> bool:
    name = name.casefold()
    return name in EXCLUDED_DIRECTORIES or name.startswith(("build", "cmake-build", "generated"))


def excluded_file(name: str) -> bool:
    name = name.casefold()
    stem = Path(name).stem
    return (
        name.startswith(("test_", "bench_", "generated_"))
        or stem.endswith(("_test", "_bench", "_generated"))
        or "benchmark" in name
        or ".generated." in name
        or "_generated." in name
        or name.endswith((".pb.cc", ".pb.h", "_pb2.py", "_pb2_grpc.py"))
    )


def metadata_head(repo: Path) -> dict[str, str]:
    """Read local Git metadata; never launch a Git process."""
    git_dir = repo / ".git"
    if git_dir.is_file():
        declaration = git_dir.read_text(encoding="utf-8").strip()
        if not declaration.startswith("gitdir: "):
            raise ValueError(f"invalid .git indirection: {repo}")
        git_dir = (repo / declaration[8:]).resolve()
    common = git_dir
    if (git_dir / "commondir").is_file():
        common = (git_dir / (git_dir / "commondir").read_text(encoding="utf-8").strip()).resolve()
    head = (git_dir / "HEAD").read_text(encoding="ascii").strip()
    ref = head[5:] if head.startswith("ref: ") else "(detached)"
    if ref != "(detached)":
        resolved = None
        for base in (git_dir, common):
            loose = base / ref
            if loose.is_file():
                resolved = loose.read_text(encoding="ascii").strip()
                break
            packed = base / "packed-refs"
            if packed.is_file():
                for line in packed.read_text(encoding="ascii").splitlines():
                    if line and not line.startswith(("#", "^")):
                        fields = line.split()
                        if len(fields) == 2 and fields[1] == ref:
                            resolved = fields[0]
                            break
            if resolved is not None:
                break
        if resolved is None:
            raise ValueError(f"unresolved local HEAD: {repo} {ref}")
        head = resolved
    if re.fullmatch(r"[0-9a-fA-F]{40}", head) is None:
        raise ValueError(f"invalid local HEAD: {repo}")
    return {"ref": ref, "head": head.lower()}


class Progress:
    def __init__(self) -> None:
        self.state: dict[str, object] = {"phase": "starting"}
        self.lock = threading.Lock()
        self.stopped = threading.Event()
        self.thread = threading.Thread(target=self.heartbeat, daemon=True)

    def update(self, **values: object) -> None:
        with self.lock:
            self.state.update(values)

    def emit(self) -> None:
        with self.lock:
            snapshot = dict(self.state)
        print(json.dumps({"progress": snapshot}, ensure_ascii=False, sort_keys=True), file=sys.stderr, flush=True)

    def heartbeat(self) -> None:
        while not self.stopped.wait(3):
            self.emit()

    def __enter__(self) -> "Progress":
        self.emit()
        self.thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self.stopped.set()
        self.thread.join()
        self.emit()


def candidate_files(repo: Path, subtrees: tuple[str, ...]) -> tuple[list[Path], list[str]]:
    found: dict[str, Path] = {}
    missing: list[str] = []
    for subtree in subtrees:
        start = repo / subtree
        if not start.is_dir():
            missing.append(subtree)
            continue
        for directory, directories, files in os.walk(start, followlinks=False):
            parent = Path(directory)
            directories[:] = [name for name in directories if not excluded_directory(name)
                              and not (parent / name).is_symlink()
                              and not (parent / name).is_junction()]
            for name in files:
                path = parent / name
                relative = path.relative_to(repo).as_posix()
                if (path.suffix.casefold() not in SOURCE_SUFFIXES or excluded_file(name)
                        or any(excluded_directory(part) for part in Path(relative).parts[:-1])
                        or path.is_symlink() or not path.resolve().is_relative_to(repo.resolve())):
                    continue
                found[relative] = path
    return [found[name] for name in sorted(found, key=lambda value: value.encode("utf-8"))], missing


def build(output: Path, progress: Progress) -> dict[str, object]:
    if sys.version_info < (3, 12):
        raise RuntimeError("use the recorded Python 3.12 interpreter")
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    specification = importlib.util.find_spec("tokenizers")
    if specification is None:
        raise RuntimeError("the already installed tokenizers package is not available; do not download it")
    tokenizer_files: dict[str, object] = {}
    tokenizer_raw = b""
    for name, expected in TOKENIZER_PINS.items():
        data = (TOKENIZER_ROOT / name).read_bytes()
        actual = sha256(data)
        if actual != expected:
            raise ValueError(f"original tokenizer/config identity changed: {name}: {actual}")
        tokenizer_files[name] = {"path": str(TOKENIZER_ROOT / name), "bytes": len(data), "sha256": actual}
        if name == "tokenizer.json":
            tokenizer_raw = data
        elif name == "config.json" and json.loads(data)["text_config"]["vocab_size"] != VOCABULARY:
            raise ValueError("original model vocabulary is not 248320")
    import tokenizers
    # Load the exact already hashed bytes. No model/Hub or chat-template loader.
    tokenizer = tokenizers.Tokenizer.from_str(tokenizer_raw.decode("utf-8"))
    vocabulary_ids = tuple(tokenizer.get_vocab(with_added_tokens=True).values())
    if not vocabulary_ids or min(vocabulary_ids) < 0 or max(vocabulary_ids) >= VOCABULARY:
        raise ValueError("tokenizer IDs do not fit the original model vocabulary")
    counts: Counter[int] = Counter()
    manifest: dict[str, object] = {
        "schema": "hyle.code-domain-token-frequency-corpus.v1",
        "scope": "Independent reference-engine source-code prior; not general-language optimality or performance evidence.",
        "script": {"path": str(SCRIPT), "sha256": sha256(SCRIPT.read_bytes())},
        "tokenizer": {"files": tokenizer_files, "package_version": tokenizers.__version__,
                      "package_origin": specification.origin, "add_special_tokens": False,
                      "chat_template_applied": False, "model_vocabulary": VOCABULARY,
                      "tokenizer_distinct_ids": len(set(vocabulary_ids))},
        "selection": {"per_repository_byte_cap": PER_REPO_BYTES, "total_byte_cap": TOTAL_BYTES,
                      "order": "repository order below; within each repository POSIX relative-path UTF-8 byte order",
                      "budget": "whole-file prefix per repository; stop before first eligible file exceeding cap; no redistribution",
                      "text": "strict UTF-8; preserve comments, whitespace, and tokenizer's own normalization",
                      "extensions": sorted(SOURCE_SUFFIXES), "excluded_directories": sorted(EXCLUDED_DIRECTORIES),
                      "excluded_directory_prefixes": ["build", "cmake-build", "generated"],
                      "excluded_file_policy": "test_/bench_/generated_ prefix; _test/_bench/_generated stem suffix; benchmark; .generated./_generated.; protobuf generated suffixes",
                      "generated_banner_regex": GENERATED_BANNER.pattern.decode("ascii"),
                      "generated_banner_scan_bytes": 4096,
                      "symlinks_and_junctions_followed": False,
                      "hyle_and_performance_prompts_or_outputs_included": False},
        "repositories": [],
        "provenance": "HEADs are local metadata pins; selected file hashes pin actual local-worktree bytes, not a claim of clean worktrees or latest upstream.",
    }
    total_bytes = total_tokens = total_files = 0
    for name, expected_head, subtrees in REPOSITORIES:
        repo = REPO_PARENT / name
        local = metadata_head(repo)
        if local["head"] != expected_head:
            raise ValueError(f"fixed repository HEAD changed: {name}: {local['head']}")
        paths, missing = candidate_files(repo, subtrees)
        if not paths:
            raise ValueError(f"no independent source files found: {name}")
        selected: list[dict[str, object]] = []
        skipped: list[dict[str, object]] = []
        repo_bytes = repo_tokens = 0
        first_omitted = None
        for path in paths:
            relative = path.relative_to(repo).as_posix()
            progress.update(phase="tokenizing", repository=name, path=relative,
                            selected_files=total_files, source_bytes=total_bytes, tokens=total_tokens)
            size = path.stat().st_size
            with path.open("rb") as stream:
                banner = stream.read(4096)
            if GENERATED_BANNER.search(banner):
                skipped.append({"path": relative, "bytes": size, "reason": "generated_banner"})
                continue
            if size > PER_REPO_BYTES - repo_bytes or size > TOTAL_BYTES - total_bytes:
                first_omitted = {"path": relative, "bytes": size, "reason": "whole_file_byte_cap"}
                break
            raw = path.read_bytes()
            if len(raw) != size:
                raise RuntimeError(f"source file changed while reading: {name}/{relative}")
            digest = sha256(raw)
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                skipped.append({"path": relative, "bytes": size, "sha256": digest, "reason": "not_strict_utf8"})
                continue
            ids = tokenizer.encode(text, add_special_tokens=False).ids
            if ids and (min(ids) < 0 or max(ids) >= VOCABULARY):
                raise ValueError(f"encoded token ID outside original vocabulary: {name}/{relative}")
            counts.update(ids)
            selected.append({"path": relative, "bytes": size, "sha256": digest, "tokens": len(ids)})
            repo_bytes += size
            repo_tokens += len(ids)
            total_bytes += size
            total_tokens += len(ids)
            total_files += 1
        manifest["repositories"].append({
            "name": name, "root": str(repo), "expected_head": expected_head, **local,
            "subtrees": list(subtrees), "missing_subtrees": missing, "path_filtered_candidates": len(paths),
            "selected_files": selected, "selected_bytes": repo_bytes, "tokens": repo_tokens,
            "skipped_before_cap": skipped, "truncated": first_omitted is not None, "first_omitted": first_omitted,
        })
    if not total_tokens or total_bytes > TOTAL_BYTES or sum(counts.values()) != total_tokens:
        raise ValueError("empty corpus, exceeded byte cap, or inconsistent token count")
    ranked = sorted(counts, key=lambda token: (-counts[token], token))
    manifest["totals"] = {"selected_files": total_files, "source_bytes": total_bytes,
                          "tokens": total_tokens, "nonzero_frequency_ids": len(ranked),
                          "truncated": any(repo["truncated"] for repo in manifest["repositories"])}
    manifest_data = json_bytes(manifest)
    (output / "source-manifest.json").write_bytes(manifest_data)
    manifest_hash = sha256(manifest_data)
    common = {"schema": "hyle.code-domain-draft-vocabulary-map.v1", "model_vocabulary": VOCABULARY,
              "source_manifest_sha256": manifest_hash, "rank_order": "frequency descending, token ID ascending",
              "prior": "independent local reference-engine source code", "performance_claim": False}
    (output / "available_ranked.json").write_bytes(json_bytes({
        **common, "available_ranked": len(ranked), "token_ids": ranked,
        "frequencies": [counts[token] for token in ranked], "token_count": total_tokens,
    }))
    maps = []
    for rank in REQUESTED_RANKS:
        if len(ranked) < rank:
            maps.append({"rank": rank, "status": "INSUFFICIENT_NONZERO_FREQUENCY",
                         "available_ranked": len(ranked), "zero_frequency_filled": False})
            continue
        ids = ranked[:rank]
        assert len(set(ids)) == rank and all(0 <= token < VOCABULARY and counts[token] > 0 for token in ids)
        artifact = {**common, "rank": rank, "token_ids": ids, "frequencies": [counts[token] for token in ids],
                    "included_token_count": sum(counts[token] for token in ids), "token_count": total_tokens,
                    "zero_frequency_filled": False}
        payload = json_bytes(artifact)
        filename = f"map_{rank}.json"
        (output / filename).write_bytes(payload)
        maps.append({"rank": rank, "status": "CREATED", "file": filename, "sha256": sha256(payload),
                     "code_corpus_token_coverage": artifact["included_token_count"] / total_tokens})
    summary = {"status": "COMPLETE", "scope": common["prior"], "source_manifest_sha256": manifest_hash,
               **manifest["totals"], "maps": maps, "network_or_model_execution": False,
               "general_language_coverage_claim": False, "performance_claim": False}
    (output / "summary.json").write_bytes(json_bytes(summary))
    progress.update(phase="complete", selected_files=total_files, source_bytes=total_bytes,
                    tokens=total_tokens, nonzero_frequency_ids=len(ranked))
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("generated"),
                        help="new output directory inside this scratch batch; relative paths start here")
    args = parser.parse_args()
    output = (BATCH / args.out).resolve()
    if not output.is_relative_to(BATCH) or output == BATCH:
        parser.error("output must be a new child directory of this scratch batch")
    if output.exists():
        parser.error("output already exists; preserve it and select a new attempt directory")
    output.mkdir(parents=True)
    try:
        with Progress() as progress:
            summary = build(output, progress)
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True), flush=True)
        return 0
    except Exception as error:
        failure = {"status": "FAILED", "error_type": type(error).__name__, "error": str(error),
                   "network_or_model_execution": False, "performance_claim": False}
        (output / "failure.json").write_bytes(json_bytes(failure))
        print(json.dumps(failure, ensure_ascii=False, sort_keys=True), file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
