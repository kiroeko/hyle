@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
cd /d C:\hyle-scratch\r4-cuda-20260916
nvcc --expt-relaxed-constexpr --std=c++20 -O2 -arch=sm_89 --cudart=static -Xcompiler /MT -Xcompiler /EHsc -Xcompiler /utf-8 -I marlin-include marlin-preflight.cu -o marlin-preflight.exe > marlin-build.log 2>&1
if errorlevel 1 exit /b %errorlevel%
dumpbin /dependents marlin-preflight.exe > marlin-dependents.log 2>&1
