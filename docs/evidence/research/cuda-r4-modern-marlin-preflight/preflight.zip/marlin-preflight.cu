#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <vector>
#include <windows.h>
#include "kernel.h"
#include "marlin_template.h"
#include "repack_kernel.cuh"

// Disposable adapter audit, not HYLE product or a performance benchmark.
#define CUDA_OK(call) do { const auto e=(call); if(e!=cudaSuccess) { \
  std::fprintf(stderr,"%s:%d %s: %s\n",__FILE__,__LINE__,#call,cudaGetErrorString(e)); return 1; } } while(false)

template<int MBlocks, bool Small>
int run_case(int m, int sms, int smem, cudaStream_t stream) {
  constexpr int k=1024,n=1024,group=128;
  std::vector<uint32_t> gptq(k*n/8);
  std::vector<half> scales(k/group*n), packed_scales(scales.size());
  for(int c=0;c<n;++c) for(int row=0;row<k;++row) {
    const unsigned q=(row*3+c*7)%16;
    gptq[(row/8)*n+c] |= q << (4*(row%8));
  }
  for(int row=0;row<k/group;++row) for(int c=0;c<n;++c)
    scales[row*n+c]=__float2half(0.0625f*(1+((row+c)%4)));
  // Current vLLM marlin_utils.py get_scale_perms(), grouped path.
  for(size_t base=0;base<scales.size();base+=64)
    for(int i=0;i<8;++i) for(int j=0;j<8;++j)
      packed_scales[base+i*8+j]=scales[base+i+8*j];
  half *a=nullptr,*c=nullptr,*s=nullptr;
  uint32_t *raw=nullptr,*b=nullptr;
  float *tmp=nullptr; int *locks=nullptr;
  CUDA_OK(cudaMalloc(&a,m*k*sizeof(half)));
  CUDA_OK(cudaMalloc(&c,m*n*sizeof(half)));
  CUDA_OK(cudaMalloc(&raw,gptq.size()*4));
  CUDA_OK(cudaMalloc(&b,gptq.size()*4));
  CUDA_OK(cudaMalloc(&s,scales.size()*2));
  CUDA_OK(cudaMalloc(&tmp,sms*std::min(64,((m+15)/16)*16)*256*sizeof(float)));
  CUDA_OK(cudaMalloc(&locks,sms*sizeof(int)));
  CUDA_OK(cudaMemcpyAsync(raw,gptq.data(),gptq.size()*4,cudaMemcpyHostToDevice,stream));
  CUDA_OK(cudaMemcpyAsync(s,packed_scales.data(),scales.size()*2,cudaMemcpyHostToDevice,stream));
  auto repack=marlin::gptq_marlin_repack_kernel<256,4,false>;
  CUDA_OK(cudaFuncSetAttribute(repack,cudaFuncAttributeMaxDynamicSharedMemorySize,smem));
  repack<<<sms,256,smem,stream>>>(raw,b,k,n);
  CUDA_OK(cudaGetLastError());
  auto kernel=marlin::Marlin<vllm::kFloat16.id(),vllm::kU4B8.id(),
      vllm::kFloat16.id(),vllm::kFloat16.id(),128,MBlocks,4,8,Small,4,8,false>;
  CUDA_OK(cudaFuncSetAttribute(kernel,cudaFuncAttributeMaxDynamicSharedMemorySize,smem));
  CUDA_OK(cudaStreamSynchronize(stream));
  std::vector<half> input(m*k),output(m*n);
  for(int replay=0;replay<3;++replay) {
    for(int row=0;row<m;++row) for(int x=0;x<k;++x)
      input[row*k+x]=__float2half(float((x*5+row*3+replay*7)%29-14)/32.f);
    CUDA_OK(cudaMemcpyAsync(a,input.data(),input.size()*2,cudaMemcpyHostToDevice,stream));
    CUDA_OK(cudaMemsetAsync(locks,0,sms*sizeof(int),stream));
    kernel<<<sms,128,smem,stream>>>(reinterpret_cast<int4*>(a),reinterpret_cast<int4*>(b),
        reinterpret_cast<int4*>(c),reinterpret_cast<int4*>(tmp),nullptr,nullptr,
        reinterpret_cast<int4*>(s),nullptr,nullptr,m,n,k,k,locks,false,false,true,smem);
    CUDA_OK(cudaGetLastError());
    CUDA_OK(cudaMemcpyAsync(output.data(),c,output.size()*2,cudaMemcpyDeviceToHost,stream));
    CUDA_OK(cudaStreamSynchronize(stream));
    double max_error=0;
    for(int row=0;row<m;++row) for(int col=0;col<n;++col) {
      double expected=0;
      for(int x=0;x<k;++x) expected+=double(__half2float(input[row*k+x]))*
          double(((x*3+col*7)%16)-8)*double(__half2float(scales[(x/group)*n+col]));
      const double actual=__half2float(output[row*n+col]);
      const double error=std::abs(expected-actual);
      if(!std::isfinite(actual) || error>0.03+0.002*std::abs(expected)) {
        std::fprintf(stderr,"FAIL M=%d replay=%d row=%d col=%d expected=%.9g actual=%.9g\n",
                     m,replay,row,col,expected,actual); return 1;
      }
      max_error=std::max(max_error,error);
    }
    std::printf("PASS M=%d K=%d N=%d replay=%d max_error=%.9g packed=%zu scales=%zu\n",
                m,k,n,replay,max_error,gptq.size()*4,scales.size()*2);
  }
  CUDA_OK(cudaFree(locks)); CUDA_OK(cudaFree(tmp)); CUDA_OK(cudaFree(s));
  CUDA_OK(cudaFree(b)); CUDA_OK(cudaFree(raw)); CUDA_OK(cudaFree(c)); CUDA_OK(cudaFree(a));
  return 0;
}

int main() {
  SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOGPFAULTERRORBOX|SEM_NOOPENFILEERRORBOX);
  int sms=0,smem=0; cudaStream_t stream=nullptr;
  CUDA_OK(cudaDeviceGetAttribute(&sms,cudaDevAttrMultiProcessorCount,0));
  CUDA_OK(cudaDeviceGetAttribute(&smem,cudaDevAttrMaxSharedMemoryPerBlockOptin,0));
  CUDA_OK(cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking));
  std::printf("vLLM 51918e252af4 native preflight; sms=%d smem=%d; no Torch runtime\n",sms,smem);
  if(run_case<1,true>(1,sms,smem,stream) || run_case<1,true>(7,sms,smem,stream) ||
     run_case<2,false>(17,sms,smem,stream) || run_case<4,false>(64,sms,smem,stream)) return 1;
  CUDA_OK(cudaStreamDestroy(stream));
  return 0;
}
