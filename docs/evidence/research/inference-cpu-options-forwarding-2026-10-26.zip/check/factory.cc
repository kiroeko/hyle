#include <algorithm>
#include <iostream>
#include <stdexcept>
#include "engine/inference/backend.h"
#include "engine/models/qwen35/model_geometry.h"
#include "engine/models/qwen35/session_state.h"
#include "engine/models/qwen35/ffn_placement.h"
namespace qwen35 {
namespace c = hyle::compute;
using hyle::inference::Backend;
using hyle::inference::BackendKind;
using hyle::inference::BackendSelection;
// Only a declaration: cold factory's real body/headers/overload resolution are
// checked; no fake Backend, pool, budget implementation or Model is executed.
template<class T> T take(hyle::Result<T> result);
void validate_mtp_source(const ModelGeometry &geometry, bool enabled) {
  if (enabled && geometry.mtp_layers != 1)
    throw std::runtime_error("MTP requires one NextN layer in the prepared source geometry");
}
BackendSelection select_execution(BackendSelection selection, std::size_t cpu_layers) {
  if (selection.primary == BackendKind::kDefault)
    selection.primary = take(Backend::default_selection()).primary;
  if (std::ranges::find(Backend::compiled_backends(), selection.primary) == Backend::compiled_backends().end())
    throw std::runtime_error("selected backend is not compiled into this image");
  selection.cpu_assist = cpu_layers != 0;
  if (selection.cpu_assist && (selection.primary == BackendKind::kCpu ||
      std::ranges::find(Backend::compiled_backends(), BackendKind::kCpu) == Backend::compiled_backends().end()))
    throw std::runtime_error("--cpu-ffn-layers requires a GPU primary and the compiled CPU route");
  return selection;
}
Backend create_execution(const ModelGeometry &geometry, const cache::Plan &plan,
    std::size_t cpu_layers, BackendSelection selection,
    const c::cpu::DefaultContextOptions *cpu_options = nullptr) {
  geometry.validate();
  validate_mtp_source(geometry, plan.draft_cache);
  FfnPlacement::validate(cpu_layers, geometry.layers.size());
  selection = select_execution(selection, cpu_layers);
  if (selection.primary != BackendKind::kCpu && !cpu_layers) {
    if (cpu_options) return take(Backend::create(selection, {}, *cpu_options));
    return take(Backend::create(selection));
  }
  // Conservative finite admission for this graph's known workspace only.
  // Sum model-sized activation envelopes instead of assuming workspace reuse;
  // unknown native-private storage remains explicitly outside this bound.
  const auto rows = static_cast<std::size_t>(plan.max_query_rows);
  const auto activation_elements = cache::add(cache::multiply(geometry.layers.size(),
      cache::add(cache::multiply(16, geometry.intermediate), cache::multiply(32, geometry.hidden))), cache::multiply(2, geometry.vocabulary));
  const auto compute = cache::add(64u << 20, cache::multiply(cache::multiply(rows, activation_elements), sizeof(float)));
  if (selection.primary == BackendKind::kCpu) {
    std::cerr << "cpu_workspace_admission host=" << compute
        << " scope=known_per_invocation_workspace native_private_unknown=1 physical_memory_cap=0\n";
    // CPU staging aliases its host allocation domain. Give that domain one
    // finite limit; do not count the same memory as a second staging budget.
    if (cpu_options) return take(Backend::create(selection, {.host = compute}, *cpu_options));
    return take(Backend::create(selection, {.host = compute}));
  }
  const auto staging = cache::add(64u << 20,
      cache::multiply(cache::multiply(rows, cache::multiply(static_cast<std::size_t>(geometry.hidden), 8)), cpu_layers));
  std::cerr << "hybrid_workspace_admission device=" << compute << " host=" << compute
      << " staging=" << staging << " scope=known_per_invocation_workspace native_private_unknown=1 physical_vram_cap=0\n";
  if (cpu_options) return take(Backend::create(selection, {compute, compute, staging}, *cpu_options));
  return take(Backend::create(selection, {compute, compute, staging}));
}

Backend original_call(const ModelGeometry &g, const cache::Plan &p, std::size_t n, BackendSelection s) {
  return create_execution(g,p,n,s);
}
Backend configured_call(const ModelGeometry &g, const cache::Plan &p, std::size_t n,
    BackendSelection s, const c::cpu::DefaultContextOptions *options) {
  return create_execution(g,p,n,s,options);
}
}
