"""Type-check the actual cold factory slice, never a complete Model or runtime."""
from pathlib import Path
import importlib.util,json,sys

sys.dont_write_bytecode=True
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
spec=importlib.util.spec_from_file_location('existing_host_recipe',ROOT/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
pin,save,execute=helper.pin,helper.save,helper.execute
def read(p):return json.loads(p.read_bytes())

def main():
    resume=sys.argv[1:]==['resume-gpu-only']
    out=WORK/'host1';assert out.exists() if resume else not out.exists()
    out.mkdir(exist_ok=resume)
    rel='engine/models/qwen35/main.cc'
    before=(WORK/'before'/rel).read_text();after=(WORK/'source'/rel).read_text()
    begin=after.index('void validate_mtp_source(');end=after.index('// Cold graph resources',begin)
    actual=after[begin:end]
    old_factory=before[before.index('Backend create_execution('):before.index('// Cold graph resources',before.index('Backend create_execution('))]
    new_factory=after[after.index('Backend create_execution('):end]
    reverted=new_factory.replace('std::size_t cpu_layers, BackendSelection selection,\n    const c::cpu::DefaultContextOptions *cpu_options = nullptr) {',
        'std::size_t cpu_layers, BackendSelection selection) {')
    reverted='\n'.join(line for line in reverted.split('\n') if 'if (cpu_options) return take(' not in line)
    reverted=reverted.replace('  if (selection.primary != BackendKind::kCpu && !cpu_layers) {\n    return take(Backend::create(selection));\n  }',
        '  if (selection.primary != BackendKind::kCpu && !cpu_layers) return take(Backend::create(selection));')
    assert reverted==old_factory,'Only optional forwarding changed, no budget/selection formula drift'
    source=out/'factory.cc'
    header='''#include <algorithm>
#include <iostream>
#include <stdexcept>
#include "engine/inference/backend.h"
#include "engine/models/qwen35/model_geometry.h"
#include "engine/models/qwen35/session_state.h"
#include "engine/models/qwen35/ffn_placement.h"
namespace qwen35 {
namespace c = hyle::compute;
using hyle::inference::Backend;
using hyle::inference::BackendKind;
using hyle::inference::BackendSelection;
// Only a declaration: cold factory's real body/headers/overload resolution are
// checked; no fake Backend, pool, budget implementation or Model is executed.
template<class T> T take(hyle::Result<T> result);
'''
    calls='''
Backend original_call(const ModelGeometry &g, const cache::Plan &p, std::size_t n, BackendSelection s) {
  return create_execution(g,p,n,s);
}
Backend configured_call(const ModelGeometry &g, const cache::Plan &p, std::size_t n,
    BackendSelection s, const c::cpu::DefaultContextOptions *options) {
  return create_execution(g,p,n,s,options);
}
}
'''
    source.write_text(header+actual+calls,encoding='utf-8')
    save(out/'source-extraction.json',{'origin':pin(WORK/'source'/rel),'actual_slice_begin':'void validate_mtp_source(',
        'actual_slice_end':'// Cold graph resources','slice_bytes':len(actual.encode()),
        'source':pin(source),'budget_selection_and_existing_calls_literal_unchanged':True,
        'limits':'Strict compile of actual extracted cold factory plus real headers and old/new call forms; take is declared only. No link, Model construction or runtime.'})
    recipe=read(ROOT/'.scratch/inference-current-closure-20261026/drift8/graph--executable_cc/command.json')['command']
    compiler=recipe[0]
    env=helper.discover_environment(compiler='msvc',cache={
        'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    flags=[compiler,'/nologo','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/MD',
        '/DNDEBUG','/permissive-','/bigobj','/W4','/WX','/wd4324','/wd4702','/DHYLE_STATIC','/DNOMINMAX',
        '/DHYLE_IO_HAS_COROUTINE_TRANSPORT=1','/I'+str(ROOT/'include'),'/I'+str(ROOT)]
    results={}
    for name,extra in [('cpu',['/DHYLE_COMPUTE_CPU=1','/c']),('gpu-only',['/DHYLE_COMPUTE_CUDA=1','/Zs'])]:
        stage=out/(name+'2' if resume and name=='gpu-only' else name)
        if resume and name=='cpu':
            results[name]=read(stage/'process.json')
            assert results[name]['exit']==0
            continue
        command=[*flags,*extra]
        if name=='gpu-only':
            cuda_includes=[arg for arg in recipe if arg.startswith('/external:I') and 'CUDA' in arg]
            assert cuda_includes
            command.extend(['/external:W0',*cuda_includes])
        command.extend(['/sourceDependencies',str(stage/'dependencies.json'),str(source),'/Fo'+str(stage/'unit.obj')])
        if resume and stage.exists():
            assert read(stage/'command.json')['command']==command
            results[name]=read(stage/'process.json')
            assert results[name]['exit']==0
        else:
            results[name]=execute(command,env,stage,timeout=60)
        data=read(stage/'dependencies.json')['Data']
        paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
        rows=[pin(Path(p)) for p in paths]
        save(stage/'actual-dependencies.json',rows)
        assert Path(data['Source']).resolve()==source.resolve()
        assert any(Path(p).resolve()==(ROOT/'engine/inference/backend.h').resolve() for p in paths)
        if name=='gpu-only':
            assert not any(Path(p).resolve() in {(ROOT/'include/hyle/compute/cpu.h').resolve(),
                (ROOT/'include/hyle/graph/cpu.h').resolve()} for p in paths)
    summary={'status':'PASS_TWO_SMALL_HOST_COMPILE_FOR_ACTUAL_FACTORY','processes':results,
        'product_pins':pin(WORK/'product-pins.json'),'factory_source':pin(source),
        'source_extraction':pin(out/'source-extraction.json'),
        'new_full_Model_SDK_core_builds':0,'Model_CPU_GPU_runs':0,'benchmark_runs':0,
        'default_thread_or_CLI_changes':0,'GPU_only_CPU_header_or_factory_dependency_added':False,
        'first_failure':{'stage':'gpu-only','kind':'recipe','detail':'Original external CUDA include paths lacked /external:W0, so cl ignored them and could not find cuda.h. Only GPU-only syntax repeated with that original compiler option; CPU success reused.'} if resume else None,
        'offline_assertion_fix':'After gpu-only2 compile passed, an overbroad cpu.h filename assertion also caught unrelated platform/cpu.h. Narrowed to compute/cpu.h and graph/cpu.h; reused the same successful compile, no third GPU-only compilation.' if resume else None,
        'limits':'CPU strict /c and GPU-only strict /Zs compile only. No link/runtime, options2+ internal parallelism or throughput claim. No complete Model TU was compiled.'}
    save(out/'summary.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
