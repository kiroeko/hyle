from pathlib import Path
import difflib,hashlib,json

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
def pin(p):
    b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,obj):p.write_bytes((json.dumps(obj,indent=2)+'\n').encode())

pins=json.loads((WORK/'product-pins.json').read_bytes())
history=WORK/'revision1';history.mkdir(exist_ok=False)
for name in ['product-pins.json','product.patch','prepare.py']:
    (history/name).write_bytes((WORK/name).read_bytes())
user=ROOT/'docs/user/inference.md';raw=user.read_bytes();assert b'\r' not in raw
before_text=raw.decode()
begin=before_text.index('程序内的模型驱动可在共用冷构造时传入原 CPU 配置')
end=before_text.index('多轮 schedule、会话数量',begin)
old=before_text[begin:end]
short=('命令行保持原 CPU 线程默认值，不增加线程参数。程序集成可复用公开的\n'
       '`compute::cpu::DefaultContextOptions`；allocator／executor 支撑对象须活到全部派生制品和原生工作退休，\n'
       '具体组合见 [CPU executor 示例](../../samples/package/graph/cpu_executor/README.md)和[架构说明](../architecture/inference-design.md)。\n\n')
new=before_text[:begin]+short+before_text[end:]
user.write_bytes(new.encode());(WORK/'source/docs/user/inference.md').write_bytes(new.encode())
architecture=ROOT/'docs/architecture/inference-design.md';b=architecture.read_bytes();assert b'\r' not in b
text=b.decode();anchor='Qwen的冷制品准备已独立为`weights.h`／`weights.cc`'
assert text.count(anchor)==1
internal=('Qwen实现内部的`create_execution(..., cpu_options=nullptr)`继续使用原有限workspace预算公式，\n'
          '再把可选配置转发给CPU主端点或显式CPU辅助端点；省略参数保持原构造调用。\n'
          '例如实现内可用`create_execution(geometry, plan, cpu_layers, selection, &cpu_options)`，\n'
          '随后将原Backend移入Model；这不是已安装SDK导出的公共引擎API。只有GPU的选择会沿原Backend入口拒绝CPU配置，\n'
          'GPU-only构建只需配置类型的前置声明。`native_threads`不配置ATen的共享线程，\n'
          '后者仍须使用原显式启动接口；没有新增线程池、全局设置或自动核心数策略。\n\n')
text=text.replace(anchor,internal+anchor,1)
rel='docs/architecture/inference-design.md'
bp=WORK/'before'/rel;ap=WORK/'source'/rel
bp.parent.mkdir(parents=True,exist_ok=True);ap.parent.mkdir(parents=True,exist_ok=True)
bp.write_bytes(b);ap.write_bytes(text.encode());architecture.write_bytes(text.encode())
for row in pins['files']:
    if row['path']=='docs/user/inference.md':row['after']=pin(WORK/'source'/row['path'])
pins['files'].append({'path':rel,'before':pin(bp),'after':pin(ap)})
patch=''
for row in pins['files']:
    before=Path(row['before']['path']).read_bytes().decode();after=Path(row['after']['path']).read_bytes().decode()
    patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path']))
(WORK/'product.patch').write_bytes(patch.encode());pins['patch']=pin(WORK/'product.patch')
save(WORK/'product-pins.json',pins)
bridge=''.join(difflib.unified_diff(before_text.splitlines(True),new.splitlines(True),fromfile='r1/docs/user/inference.md',tofile='final/docs/user/inference.md'))
(WORK/'documentation-r1-to-final.patch').write_bytes(bridge.encode())
save(WORK/'documentation-final.json',{'status':'INTERNAL_EXAMPLE_MOVED_OUT_OF_USER_API_GUIDE',
    'user':pin(user),'architecture':pin(architecture),'LF_preserved':True,
    'compile_time_product_pins':pin(history/'product-pins.json'),
    'final_pins':pin(WORK/'product-pins.json'),
    'compiled_code_unchanged':['engine/models/qwen35/main.cc','samples/package/graph/cpu_executor/main.cc'],
    'additional_compilations_or_runs':0})
print(json.dumps({'product_patch':pin(WORK/'product.patch'),'final_pins':pin(WORK/'product-pins.json'),
    'docs':pin(WORK/'documentation-final.json')},indent=2))
