"""Publish the completed source/compile check. No compiler or runtime call."""
from pathlib import Path
import hashlib,json,re,zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
STEM='inference-cpu-options-forwarding-2026-10-26'
DEST=ROOT/'docs/evidence/research'
def read(p):return json.loads(p.read_bytes())
def digest(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def pin(p):return {'path':str(p.resolve()),**digest(p.read_bytes())}
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())

def main():
    archive=DEST/(STEM+'.zip');external=DEST/(STEM+'.json')
    assert not archive.exists() and not external.exists()
    summary=read(WORK/'host1/summary.json');pins=read(WORK/'product-pins.json')
    assert summary['status']=='PASS_TWO_SMALL_HOST_COMPILE_FOR_ACTUAL_FACTORY'
    original=read(WORK/'revision1/product-pins.json')
    assert pin(WORK/'revision1/product-pins.json')['sha256']==summary['product_pins']['sha256']
    for name in ['engine/models/qwen35/main.cc','samples/package/graph/cpu_executor/main.cc']:
        a=next(x for x in original['files'] if x['path']==name)
        b=next(x for x in pins['files'] if x['path']==name)
        assert a==b
    for x in pins['files']:
        assert digest(Path(x['before']['path']).read_bytes())=={k:x['before'][k] for k in ['bytes','sha256']}
        assert digest(Path(x['after']['path']).read_bytes())=={k:x['after'][k] for k in ['bytes','sha256']}
    assert all(b'\r' not in Path(x['after']['path']).read_bytes() for x in pins['files'] if x['path'].endswith('.md'))
    report={'schema':'hyle-source-compile-evidence-v1','date':'2026-10-26',
        'status':'PASS_EXTRACTED_COLD_FACTORY_CPU_COMPILE_AND_GPU_ONLY_SYNTAX',
        'scope':'Optional CPU cold configuration forwarded by the existing Qwen implementation factory while retaining its original finite workspace formulas. One small actual-function CPU compile and GPU-only syntax check, no complete Model compile/link or inference.',
        'implementation':{'canonical_integrated':True,'product_files':[x['path'] for x in pins['files']],
            'internal_function':'qwen35::create_execution(..., const compute::cpu::DefaultContextOptions *cpu_options = nullptr)',
            'public_boundary':'This helper has no exported public engine declaration and is documented only as an implementation composition seam. Public DefaultContextOptions and the original CPU executor sample remain the integration references.',
            'behavior':['Null options preserve all original Backend factory calls and existing CPU/mixed finite-workspace calculations.',
                'Explicit options forward to the existing three-argument Backend factory for CPU-primary/CPU-assist. Without a selected CPU endpoint the original Backend validation rejects the configuration before endpoint allocation.',
                'The GPU-only function signature needs only the existing forward declaration. No compute/cpu.h or graph/cpu.h dependency was added in that thin compilation.',
                'No new owner, pool, mutable setting, option inventory, CLI flag or automatic thread-count policy.',
                'The original Scheduler sample explicitly retains native_threads1. Documentation distinguishes borrowed executor lifetime, per-Invocation ggml budget, synchronous complete-program dispatch and separate ATen startup configuration.'],
            'source_pins':pins,
            'docs_correction':'An initial user-guide snippet named a private implementation helper without an exported header. Removed it from user instructions; user page now has two sentences linking public CPU options/sample/design. Internal forwarding and budget explanation moved beside the existing architecture CPU paragraph. LF bytes preserved.'},
        'actual_checks':{'cpu':read(WORK/'host1/cpu/process.json'),
            'GPU_only_syntax':read(WORK/'host1/gpu-only2/process.json'),
            'extracted_actual_source':pin(WORK/'host1/factory.cc'),
            'source_extraction':read(WORK/'host1/source-extraction.json'),
            'scope':'The exact modified validate_mtp_source/select_execution/create_execution bodies and real current headers are compiled with old/new caller forms. take is a declaration only; no fake Backend, mirrored budget function, link, Model or runtime.',
            'compile_time_pins':pin(WORK/'revision1/product-pins.json'),
            'compiled_code_matches_final_pins':True,
            'docs_changes_after_checks_only':True,
            'new_complete_Model_SDK_core_provider_builds':0,'CPU_GPU_model_runs':0,'benchmark_runs':0,
            'default_thread_CLI_changes':0},
        'first_failures':[
            {'stage':'source preparation','kind':'tooling assertion/command quoting','facts':read(WORK/'sourceprep-first-failure.json'),
             'scope':'Before candidate source or compilation; no product/runtime failure.'},
            {'stage':'host1/gpu-only','kind':'thin compile recipe','process':read(WORK/'host1/gpu-only/process.json'),
             'facts':summary['first_failure']['detail']},
            {'stage':'after host1/gpu-only2 compile passed','kind':'offline dependency assertion',
             'facts':summary['offline_assertion_fix']}],
        'prior_options_evidence':pin(ROOT/'docs/evidence/research/inference-cpu-cold-options-2026-10-26.json'),
        'limits':['No full Model translation unit was compiled, linked or executed. The existing CPU options Graph tests were not rerun.',
            'The modified original Scheduler sample call explicitly spells the unchanged default1; that complete sample was not rebuilt or run in this batch.',
            'No native_threads>1 execution, parallel scaling, optimal pure-CPU/hybrid policy, global process thread bound or throughput benefit is established.',
            'Existing CUDA headers were reused for GPU-only host syntax; no CUDA/native/SDK code was rebuilt and no GPU work launched.',
            'Thread/executor backings remain borrowed through all derived artifacts/native retirement. The options object itself is used only during cold construction; no new lifetime owner or process-wide ATen setter is introduced.',
            'No new public installed engine API/header is claimed. The user guide links the public Compute configuration and existing sample; the internal factory is an architecture implementation detail.']}
    members={};origins={}
    def add(name,path):
        assert name not in members and path.is_file()
        assert path.suffix.lower() not in {'.obj','.exe','.lib','.dll','.pdb','.bin','.gguf','.safetensors'}
        raw=path.read_bytes()
        assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})',raw),name
        members[name]=raw;origins[name]=str(path.resolve())
    for name in ['product.patch','product-pins.json','documentation-r1-to-final.patch','documentation-final.json',
        'scope.json','applied.json','sourceprep-first-failure.json']:
        add('source/'+name,WORK/name)
    add('source/compile-time-product-pins.json',WORK/'revision1/product-pins.json')
    for name in ['check_host.py','prepare.py','revise_docs.py','archive.py']:
        add('scripts/'+name,WORK/name)
    for name in ['factory.cc','source-extraction.json','summary.json']:
        add('check/'+name,WORK/'host1'/name)
    for stage in ['cpu','gpu-only','gpu-only2']:
        for name in ['command.json','running.json','process.json','stdout.log','stderr.log',
            'dependencies.json','actual-dependencies.json']:
            path=WORK/'host1'/stage/name
            if path.exists():add('check/'+stage+'/'+name,path)
    members['report.json']=(json.dumps(report,indent=2)+'\n').encode()
    manifest={'members':{n:{**digest(b),**({'origin':origins[n]} if n in origins else {})} for n,b in members.items()},
        'exclusions':'No binaries, models, SDK, complete Model source or duplicated source/dependency tree; exact patch, extracted actual factory, command/raw/identity records only.'}
    members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    DEST.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in members.items():z.writestr(name,raw)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(members)
        for name,row in manifest['members'].items():assert digest(z.read(name))=={k:row[k] for k in ['bytes','sha256']}
    report['archive']={'path':archive.relative_to(ROOT).as_posix(),**digest(archive.read_bytes()),
        'members':len(members),'CRC':'PASS','member_SHA256':'PASS','binaries_SDK_models':False}
    save(external,report)
    result={'report':pin(external),'archive':pin(archive),'CRC':'PASS','member_SHA256':'PASS','members':len(members)}
    save(WORK/'archive-verification.json',result)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
