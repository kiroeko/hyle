from pathlib import Path
import difflib,hashlib,json

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent

def pin(path):
    b=path.read_bytes()
    return {'path':str(path.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
def change(rel,old,new):
    path=ROOT/rel; raw=path.read_bytes(); nl='\r\n' if b'\r\n' in raw else '\n'
    s=raw.decode().replace('\r\n','\n'); assert s.count(old)==1,(rel,s.count(old))
    updated=s.replace(old,new,1).replace('\n',nl).encode()
    before=WORK/'before'/rel; after=WORK/'source'/rel
    assert not after.exists()
    before.parent.mkdir(parents=True,exist_ok=True);after.parent.mkdir(parents=True,exist_ok=True)
    before.write_bytes(raw);after.write_bytes(updated)
    return {'path':rel,'before':pin(before),'after':pin(after)}

def main():
    rel='engine/models/qwen35/main.cc'
    raw=(ROOT/rel).read_bytes(); text=raw.decode().replace('\r\n','\n')
    start=text.index('Backend create_execution(');end=text.index('// Cold graph resources',start)
    old=text[start:end]
    new=old.replace('std::size_t cpu_layers, BackendSelection selection) {',
        'std::size_t cpu_layers, BackendSelection selection,\n'
        '    const c::cpu::DefaultContextOptions *cpu_options = nullptr) {')
    new=new.replace('  if (selection.primary != BackendKind::kCpu && !cpu_layers) return take(Backend::create(selection));',
        '  if (selection.primary != BackendKind::kCpu && !cpu_layers) {\n'
        '    if (cpu_options) return take(Backend::create(selection, {}, *cpu_options));\n'
        '    return take(Backend::create(selection));\n'
        '  }')
    new=new.replace('    return take(Backend::create(selection, {.host = compute}));',
        '    if (cpu_options) return take(Backend::create(selection, {.host = compute}, *cpu_options));\n'
        '    return take(Backend::create(selection, {.host = compute}));')
    new=new.replace('  return take(Backend::create(selection, {compute, compute, staging}));',
        '  if (cpu_options) return take(Backend::create(selection, {compute, compute, staging}, *cpu_options));\n'
        '  return take(Backend::create(selection, {compute, compute, staging}));')
    assert new.count('*cpu_options)')==3
    rows=[change(rel,old,new)]
    rows.append(change('samples/package/graph/cpu_executor/main.cc',
        '        {.metadata_allocator = allocator, .executor = executor.ref()}));',
        '        {.metadata_allocator = allocator, .executor = executor.ref(), .native_threads = 1}));'))
    rows.append(change('samples/package/graph/cpu_executor/README.md',
        'using the ordinary CPU route and its supported mature programs with the same executor.\n',
        'using the ordinary CPU route and its supported mature programs with the same executor.\n\n'
        'The sample explicitly keeps `native_threads = 1`. That is the independent\n'
        'ggml budget per prepared Invocation; ggml submits its complete program as one\n'
        'executor task. Scheduler concurrency does not create ggml workers. Native\n'
        'and oneDNN work may split through the borrowed executor. ATen uses its\n'
        'separate shared runtime; configuring its threads requires the explicit\n'
        'startup `compute::cpu::configure_runtime_threads` API. None of these settings\n'
        'is a process-wide thread quota or automatic performance policy.\n'))
    rows.append(change('docs/user/inference.md',
        '多轮 schedule、会话数量、同时活动数、缓存预算、trace 与数值限制见[模型运行说明](../../engine/models/qwen35/README.md)。\n',
        '程序内的模型驱动可在共用冷构造时传入原 CPU 配置，不复制有限 workspace 预算公式：\n\n'
        '```cpp\n'
        'hyle::compute::cpu::DefaultContextOptions cpu_options{\n'
        '    .executor = borrowed_executor,\n'
        '    .native_threads = 2,  // 调用者显式选择，不是推荐默认值。\n'
        '};\n'
        'auto backend = qwen35::create_execution(\n'
        '    geometry, cache_plan, cpu_ffn_layers, selection, &cpu_options);\n'
        '// 将 backend 移入既有 Model(Backend&&, ...) 构造；不创建第二个执行器。\n'
        '```\n\n'
        '这里是模型实现的程序内组合入口，不增加 CLI 参数。省略末参保持原默认配置；\n'
        'CPU 主端点与显式 CPU 辅助端点使用同一转发，只有 GPU 的选择会拒绝 CPU 配置。\n'
        '配置对象只在冷调用中借用；其 allocator／executor 支撑对象须活到所有派生制品和原生工作退休。\n'
        '`native_threads` 是每个 ggml Invocation 的独立线程预算；executor 只调度其完整 program，\n'
        '而 Native／oneDNN 可通过 executor 拆分工作，两种并发度不能相乘当作全进程上限。\n'
        'ATen 的共享线程设置须另行在使用前显式配置，构造 Backend 不会修改它。\n'
        '纯 CPU 与 CPU＋GPU 的最优线程数分别取决于实际工作，本入口不自动选择核心数或承诺提速。\n\n'
        '多轮 schedule、会话数量、同时活动数、缓存预算、trace 与数值限制见[模型运行说明](../../engine/models/qwen35/README.md)。\n'))
    patch=''
    for row in rows:
        b=Path(row['before']['path']).read_bytes().decode();a=Path(row['after']['path']).read_bytes().decode()
        patch+=''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),
            fromfile='a/'+row['path'],tofile='b/'+row['path']))
    (WORK/'product.patch').write_bytes(patch.encode())
    save(WORK/'product-pins.json',{'files':rows,'patch':pin(WORK/'product.patch')})
    (WORK/'actual-factory-slice.cc').write_text(new,encoding='utf-8')
    save(WORK/'scope.json',{'status':'PRIVATE_COLD_FORWARDING_READY',
        'reason':'Original create_execution owns finite workspace formulas but had no CPU options parameter. An owner otherwise duplicated those formulas to reach configured Backend.',
        'change':'Optional pointer forwards original options only; null paths retain exact original Backend factory calls and all arithmetic. No new owner/pool/global state/default policy/CLI.',
        'gpu_only':'Uses pointer to existing forward declaration; no cpu.h or CPU factory added to a GPU-only TU. Explicit CPU options without a CPU endpoint preserve Backend original early rejection.',
        'canonical':'Not applied until architecture K2 frozen compile/link permits the narrow change.',
        'check':'Only extracted actual cold factory CPU and GPU-only thin host syntax checks; no Model/SDK build or runtime. Old shared Graph test not repeated.'})
    print(json.dumps({'patch':pin(WORK/'product.patch'),'files':[r['path'] for r in rows]},indent=2))

if __name__=='__main__':main()
