"""Bind every saved fixed-revision tensor header, without tensor payload."""
import collections
import hashlib
import json
import math
import pathlib
import re

BASE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path.cwd()
INDICES = (4, 5, 11, 12, 31, 32)
DTYPE_BYTES = {"BOOL": 1, "U8": 1, "I8": 1, "U16": 2, "I16": 2,
               "F16": 2, "BF16": 2, "U32": 4, "I32": 4, "F32": 4,
               "U64": 8, "I64": 8, "F64": 8}


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


def shape_key(shape):
    return "x".join(map(str, shape))


def role(name):
    return re.sub(r"(?<=\.)\d+(?=\.|$)", "{index}", name)


def config_name(index, stem):
    # An explicit artifact-binding transformation, not a runtime model whitelist.
    # README source config describes switch_mlp banks; stored GLM Flash shards
    # contain separate experts and a language_model prefix.
    if index == 32:
        stem = stem.replace("model.language_model.", "model.", 1)
        stem = re.sub(r"\.mlp\.experts\.\d+\.", ".mlp.switch_mlp.", stem)
    return stem


def analyze(index, row):
    folder = BASE / str(index)
    config = json.loads((folder / "config.json").read_text())
    q = config["quantization"]
    index_doc = json.loads((folder / "model.safetensors.index.json").read_text())
    weight_map = index_doc["weight_map"]
    shards = sorted(set(weight_map.values()))
    tensors, origins, receipt_summary = {}, {}, []
    for shard in shards:
        header_path = folder / "headers" / (shard + ".header.json")
        header_bytes = header_path.read_bytes()
        header = json.loads(header_bytes)
        receipt_path = folder / "headers" / (shard + ".receipt.json")
        receipt = json.loads(receipt_path.read_text())
        assert hashlib.sha256(header_bytes).hexdigest() == receipt["header"]["sha256"]
        assert receipt["revision"] == row["revision"] and receipt["payload_bytes_read"] == 0
        receipt_summary.append({"file": shard, "header_bytes": len(header_bytes),
                                "header_sha256": receipt["header"]["sha256"],
                                "object_bytes": int(receipt["header"]["content_range"].split("/")[-1]),
                                "tensor_count": receipt["tensor_count"]})
        for name, description in header.items():
            if name == "__metadata__":
                continue
            assert name not in tensors and weight_map[name] == shard
            assert description["dtype"] in DTYPE_BYTES
            begin, end = description["data_offsets"]
            assert end - begin == math.prod(description["shape"]) * DTYPE_BYTES[description["dtype"]]
            tensors[name], origins[name] = description, shard
    assert set(tensors) == set(weight_map)

    triples, selected_names, invalid = [], set(), []
    bank_fragments = collections.defaultdict(list)
    for name, w in tensors.items():
        if w["dtype"] != "U32" or not name.endswith(".weight"):
            continue
        stem = name[:-len(".weight")]
        sfname, bname = stem + ".scales", stem + ".biases"
        try:
            sf, bias = tensors[sfname], tensors[bname]
            assert len(w["shape"]) in (2, 3)
            assert sf["dtype"] == bias["dtype"] and sf["dtype"] in ("BF16", "F16", "F32")
            assert sf["shape"] == bias["shape"] and sf["shape"][:-1] == w["shape"][:-1]
            assert len(sf["shape"]) == len(w["shape"])
            canonical = config_name(index, stem)
            policy = {k: v for k, v in q.items() if not isinstance(v, dict)}
            policy.update(q.get(canonical, {}))
            group = policy["group_size"]
            k = sf["shape"][-1] * group
            assert k % 32 == 0
            assert (32 * w["shape"][-1]) % k == 0
            bits = (32 * w["shape"][-1]) // k
            assert bits in (4, 5, 6, 8) and bits == policy["bits"]
            assert policy.get("mode", "affine" if index == 32 else None) == "affine"
            kind = "embedding" if stem.endswith(".embed_tokens") else (
                "grouped" if len(w["shape"]) == 3 else "linear")
            expert_match = re.fullmatch(r"(.+\.mlp)\.experts\.(\d+)\.(\w+)", stem)
            if expert_match:
                kind = "expert-fragment-for-grouped-bank"
                bank_fragments[(expert_match[1], expert_match[3])].append(
                    (int(expert_match[2]), stem, bits, group, w["shape"], sf["shape"], sf["dtype"]))
            entry = {"module": stem, "config_module": canonical,
                     "kind": kind, "format": "affine", "bits": bits, "group_size": group,
                     "logical_K": k, "weight_dtype": "U32", "weight_shape": w["shape"],
                     "scale_bias_dtype": sf["dtype"], "scale_bias_shape": sf["shape"],
                     "weight_shard": origins[name], "scale_shard": origins[sfname],
                     "bias_shard": origins[bname]}
            triples.append(entry)
            selected_names.update((name, sfname, bname))
        except (AssertionError, KeyError) as error:
            invalid.append({"module": stem, "error": repr(error)})

    assert not invalid, invalid[:10]
    unknown_u32 = [name for name, t in tensors.items() if t["dtype"] == "U32" and name not in selected_names]
    dangling_affine = [name for name in tensors if name.endswith((".scales", ".biases")) and name not in selected_names]
    assert not unknown_u32 and not dangling_affine
    dense = [{"name": name, "dtype": t["dtype"], "shape": t["shape"], "shard": origins[name]}
             for name, t in tensors.items() if name not in selected_names]
    role_groups = collections.defaultdict(list)
    for t in triples:
        key = (role(t["module"]), t["kind"], t["bits"], t["group_size"],
               shape_key(t["weight_shape"]), t["scale_bias_dtype"], shape_key(t["scale_bias_shape"]))
        role_groups[key].append(t["module"])
    dense_groups = collections.defaultdict(list)
    for t in dense:
        dense_groups[(role(t["name"]), t["dtype"], shape_key(t["shape"]))].append(t["name"])
    banks = []
    text_config = config.get("text_config", config)
    experts = text_config.get("n_routed_experts")
    for (prefix, projection), fragments in sorted(bank_fragments.items()):
        fragments.sort()
        ids = [f[0] for f in fragments]
        assert ids == list(range(experts)), (prefix, projection, ids)
        assert all(f[2:] == fragments[0][2:] for f in fragments)
        first = fragments[0]
        banks.append({"bank": prefix + ".experts.{expert}." + projection,
                      "expert_count": experts, "expert_ids_complete": True,
                      "bits": first[2], "group_size": first[3],
                      "stored_fragment_weight_shape": first[4],
                      "stored_fragment_scale_bias_shape": first[5], "scale_bias_dtype": first[6],
                      "assembled_grouped_weight_shape": [experts] + first[4],
                      "assembled_grouped_scale_bias_shape": [experts] + first[5],
                      "assembly_required": True,
                      "zero_copy_rank3_reinterpretation_not_proven": True})

    # The original headers+index provide exact names/offsets. Store normalized
    # role equivalence classes and compact exact module→parameter bindings once.
    compact_fields = ["module", "config_module", "kind", "bits", "group_size", "logical_K",
                      "weight_shape", "scale_bias_dtype", "scale_bias_shape",
                      "weight_shard", "scale_shard", "bias_shard"]
    compact_path = folder / "affine-bindings.json"
    compact_path.write_text(json.dumps({"fields": compact_fields,
        "bindings": [[t[f] for f in compact_fields] for t in sorted(triples, key=lambda x: x["module"]) ]},
        separators=(",", ":")) + "\n", encoding="utf-8", newline="\n")
    save(folder / "dense-roles.json", dense)
    save(folder / "expert-bank-assembly.json", banks)
    normalized = [{"module_pattern": k[0], "kind": k[1], "bits": k[2], "group_size": k[3],
                   "weight_shape": k[4], "scale_bias_dtype": k[5], "scale_bias_shape": k[6],
                   "count": len(v), "first": min(v), "last": max(v)}
                  for k, v in sorted(role_groups.items())]
    normalized_dense = [{"tensor_pattern": k[0], "dtype": k[1], "shape": k[2],
                          "count": len(v), "first": min(v), "last": max(v)}
                         for k, v in sorted(dense_groups.items())]
    output = {
        "catalog_index": index, "repository": row["repository"], "revision": row["revision"],
        "fixed_tree_url": "https://huggingface.co/%s/tree/%s" % (row["repository"], row["revision"]),
        "scope": "all index tensors and every shard safetensors header; zero tensor payload",
        "shards": receipt_summary, "tensor_count": len(tensors), "affine_triple_count": len(triples),
        "affine_bits_counts": dict(sorted(collections.Counter(t["bits"] for t in triples).items())),
        "affine_kind_counts": dict(collections.Counter(t["kind"] for t in triples)),
        "scale_bias_dtype_counts": dict(collections.Counter(t["scale_bias_dtype"] for t in triples)),
        "dense_tensor_count": len(dense), "dense_dtype_counts": dict(collections.Counter(t["dtype"] for t in dense)),
        "unbound_u32_count": len(unknown_u32), "unbound_scale_bias_count": len(dangling_affine),
        "affine_roles": normalized, "dense_roles": normalized_dense,
        "fragment_bank_count": len(banks),
        "config_binding": "model.language_model→model; mlp.experts.<id>→mlp.switch_mlp" if index == 32 else "exact module stem",
        "mode_evidence": "fixed README explicitly affine mixed4/5/6; config mode absent; every U32/float scale+bias shape agrees" if index == 32 else "fixed config quantization.mode=affine; every header U32/float scale+bias shape agrees",
        "not_proven": ["weight payload or code contents", "whole artifact importer/execution", "exact upstream model output/numerical equivalence", "performance"],
    }
    save(folder / "role-summary.json", output)
    return output


def main():
    rows = json.loads((ROOT / "docs/implementation/model-quantizations.json").read_text(encoding="utf-8"))["artifacts"]
    summaries = [analyze(i, rows[i]) for i in INDICES]
    save(BASE / "summary.json", [{k: s[k] for k in (
        "catalog_index", "repository", "revision", "tensor_count", "affine_triple_count",
        "affine_bits_counts", "affine_kind_counts", "scale_bias_dtype_counts", "dense_tensor_count",
        "dense_dtype_counts", "unbound_u32_count", "unbound_scale_bias_count", "fragment_bank_count")} for s in summaries])
    print(json.dumps(json.loads((BASE / "summary.json").read_text()), indent=2))


if __name__ == "__main__":
    main()
