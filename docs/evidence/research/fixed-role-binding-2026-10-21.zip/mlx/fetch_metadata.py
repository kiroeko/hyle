"""Read fixed-revision JSON and safetensors metadata; never read payload bytes."""
import concurrent.futures
import hashlib
import json
import pathlib
import re
import struct
import threading
import time
import urllib.parse

import requests

BASE = pathlib.Path(__file__).resolve().parent
CATALOG = pathlib.Path("docs/implementation/model-quantizations.json")
INDICES = (4, 5, 11, 12, 31, 32)
JSON_CAP = 16 * 1024 * 1024
HEADER_CAP = 2 * 1024 * 1024
AGGREGATE_CAP = 48 * 1024 * 1024
lock = threading.Lock()
aggregate_bytes = 0


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


def request(url, expected_bytes=None, interval=None):
    headers = {"Accept-Encoding": "identity", "User-Agent": "hyle-fixed-metadata/1"}
    if interval is not None:
        headers["Range"] = "bytes=%d-%d" % interval
    with requests.get(url, headers=headers, stream=True, timeout=(20, 90)) as r:
        if interval is None:
            if r.status_code != 200:
                raise RuntimeError("JSON HTTP %s at %s" % (r.status_code, url))
            length = r.headers.get("Content-Length")
            if length is not None and int(length) > JSON_CAP:
                raise RuntimeError("JSON Content-Length %s over cap at %s (host %s)" % (length, url, urllib.parse.urlsplit(r.url).netloc))
            chunks, count = [], 0
            for c in r.iter_content(65536):
                count += len(c)
                if count > JSON_CAP:
                    raise RuntimeError("JSON body over cap")
                chunks.append(c)
            data = b"".join(chunks)
        else:
            # Validate the response before reading even the first body byte.
            if r.status_code != 206:
                raise RuntimeError("range rejected/ignored: HTTP %s at %s" % (r.status_code, url))
            match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", r.headers.get("Content-Range", ""))
            if match is None or tuple(map(int, match.group(1, 2))) != interval:
                raise RuntimeError("unexpected Content-Range %r" % r.headers.get("Content-Range"))
            if int(r.headers.get("Content-Length", "-1")) != expected_bytes:
                raise RuntimeError("range Content-Length differs from requested metadata bytes")
            if r.headers.get("Content-Encoding", "identity") != "identity":
                raise RuntimeError("encoded range response")
            # Never read beyond the requested interval, even to test EOF.
            data = r.raw.read(expected_bytes)
            if len(data) != expected_bytes:
                raise RuntimeError("short metadata range response")
        receipt = {
            "url": url,
            "status": r.status_code,
            "content_range": r.headers.get("Content-Range"),
            "content_length": r.headers.get("Content-Length"),
            "etag": r.headers.get("ETag"),
            "final_host": urllib.parse.urlsplit(r.url).netloc,
            "bytes_read": len(data),
            "sha256": sha(data),
        }
        return data, receipt


def fixed_url(row, filename):
    return "https://huggingface.co/%s/resolve/%s/%s" % (
        row["repository"], row["revision"], urllib.parse.quote(filename, safe="/")
    )


def fetch_index(index, row):
    folder = BASE / str(index)
    path = folder / "model.safetensors.index.json"
    receipt_path = folder / "index-receipt.json"
    url = fixed_url(row, path.name)
    if path.exists() and receipt_path.exists():
        data = path.read_bytes()
        receipt = json.loads(receipt_path.read_text())
        assert receipt["url"] == url and receipt["sha256"] == sha(data)
    else:
        data, receipt = request(url)
        document = json.loads(data)
        assert isinstance(document["weight_map"], dict)
        path.write_bytes(data)
        save_json(receipt_path, receipt)
    document = json.loads(data)
    return sorted(set(document["weight_map"].values()))


def fetch_header(index, row, filename):
    global aggregate_bytes
    folder = BASE / str(index) / "headers"
    folder.mkdir(exist_ok=True)
    path = folder / (filename + ".header.json")
    receipt_path = folder / (filename + ".receipt.json")
    base_url = fixed_url(row, filename)
    if path.exists() and receipt_path.exists():
        data = path.read_bytes()
        receipt = json.loads(receipt_path.read_text())
        assert receipt["fixed_url"] == base_url and receipt["header"]["sha256"] == sha(data)
        with lock:
            aggregate_bytes += len(data)
            assert aggregate_bytes <= AGGREGATE_CAP
        return {"catalog_index": index, "file": filename, "header_bytes": len(data), "reused": True}
    prefix, prefix_receipt = request(
        base_url + "?download=true&hyle_metadata_range=0-7", 8, (0, 7)
    )
    header_bytes = struct.unpack("<Q", prefix)[0]
    if not 2 <= header_bytes <= HEADER_CAP:
        raise RuntimeError("safetensors header length outside explicit cap: %s" % header_bytes)
    with lock:
        if aggregate_bytes + header_bytes > AGGREGATE_CAP:
            raise RuntimeError("aggregate metadata cap exceeded before header request")
        aggregate_bytes += header_bytes
    end = 7 + header_bytes
    data, header_receipt = request(
        base_url + "?download=true&hyle_metadata_range=8-%d" % end,
        header_bytes, (8, end)
    )
    if prefix_receipt["content_range"].split("/")[-1] != header_receipt["content_range"].split("/")[-1]:
        raise RuntimeError("total file length changed between metadata intervals")
    tensor_header = json.loads(data)
    total = int(header_receipt["content_range"].split("/")[-1])
    tensor_records = [v for k, v in tensor_header.items() if k != "__metadata__"]
    if not tensor_records or max(v["data_offsets"][1] for v in tensor_records) + header_bytes + 8 != total:
        raise RuntimeError("header payload extent differs from HTTP object total")
    path.write_bytes(data)
    receipt = {
        "fixed_url": base_url,
        "catalog_index": index,
        "repository": row["repository"],
        "revision": row["revision"],
        "prefix": prefix_receipt,
        "header": header_receipt,
        "tensor_count": len(tensor_records),
        "payload_bytes_read": 0,
    }
    save_json(receipt_path, receipt)
    return {"catalog_index": index, "file": filename, "header_bytes": header_bytes, "reused": False}


def main():
    catalog = json.loads(CATALOG.read_text(encoding="utf-8"))
    rows = {i: catalog["artifacts"][i] for i in INDICES}
    # Source catalog uses the explicit repository/revision keys below.
    save_json(BASE / "fetch-policy.json", {
        "indices": INDICES, "per_json_cap": JSON_CAP, "per_header_cap": HEADER_CAP,
        "aggregate_header_cap": AGGREGATE_CAP, "max_workers": 4,
        "payload_bytes_allowed": 0, "require_http206_exact_range_and_length": True,
        "sources": [{"catalog_index": i, "repository": r["repository"], "revision": r["revision"]} for i, r in rows.items()],
    })
    jobs = []
    for i, row in rows.items():
        shards = fetch_index(i, row)
        print(json.dumps({"index": i, "shards": len(shards)}), flush=True)
        jobs.extend((i, row, name) for name in shards)
    completed, errors = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        tasks = {pool.submit(fetch_header, *job): job for job in jobs}
        for future in concurrent.futures.as_completed(tasks):
            job = tasks[future]
            try:
                completed.append(future.result())
            except Exception as e:
                errors.append({"index": job[0], "file": job[2], "error": str(e)})
            if len(completed) % 10 == 0 or errors:
                print(json.dumps({"completed": len(completed), "errors": len(errors), "header_bytes": aggregate_bytes}), flush=True)
    save_json(BASE / "fetch-summary.json", {"completed": completed, "errors": errors, "header_bytes": aggregate_bytes, "payload_bytes_read": 0})
    if errors:
        raise SystemExit("metadata fetch failures; see fetch-summary.json")


if __name__ == "__main__":
    main()
