from pathlib import Path
import json,hashlib
S=Path(__file__).resolve().parent;R=S.parents[3];p=R/'docs/implementation/model-quantizations.json'
d=json.loads(p.read_text(encoding='utf8'))
for i in d['followup_reviews'][-1]['artifact_indices']:
 pc=d['artifacts'][i]['provider_coverage']
 pc['role_domains']=[dict(role='Fixed stored roles and producer math; full role details in fixed_source_role_binding.facts',observed=pc['mapping_status'],evidence=pc['fixed_source_role_binding']['research_evidence'],unresolved=pc['missing_capabilities'])]
pc=d['artifacts'][24]['provider_coverage']
scope='Retained generic W4A16 capability evidence only; not an equivalent implementation, default or fusion of this artifact custom W4A8 runtime. Current exact mathematical entry is BlockwiseW4A8Linear/GroupedBlockwiseW4A8Linear.'
pc['prior_generic_operation_evidence_scope']=scope
pc['fusion_coverage']='Current exact runtime is the dedicated group512 W4A8 reference leaf: quantize unique A rows then compute packed selected dots with sequential BF16 group rescale/accumulation. Four backends use their existing executor/Invocation. No automatic recognition of an arbitrary decomposed custom-A8 graph, hardware integer GEMM, complete FFN or artifact throughput claim. Earlier CT W4A16 contraction evidence remains generic capability only.'
for key in ['fusion_coverage','cpu_packed_default_policy','grouped_packed_reference_execution','cpu_packed_graph_evidence','cpu_packed_portability_evidence','native_packed_graph_evidence']:
 if isinstance(pc.get(key),dict):pc[key]['artifact_binding_scope']=scope
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
receipt=json.loads((S/'catalog-update.json').read_text(encoding='utf8'));receipt['after_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();receipt['followup']='Removed superseded role-unknown statements and delimited retained custom24 generic W4A16 evidence after independent read-only review.'
(S/'catalog-update.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
