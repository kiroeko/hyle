from pathlib import Path
import json,hashlib
S=Path(__file__).resolve().parent;F=S.parent;R=F.parents[2]
p=R/'docs/implementation/model-quantizations.json';before=p.read_bytes();d=json.loads(before)
old=S/'model-quantizations.before.json'
if old.exists():assert old.read_bytes()==before
else:old.write_bytes(before)
def read(p):return json.loads(p.read_text(encoding='utf8'))
mlx=read(F/'mlx/assessment.json');kimi=read(F/'kimi/review.json');kv=read(F/'fp8-kv/review.json');infer=read(F/'inferact/assessment.json')
research='docs/evidence/research/fixed-role-binding-2026-10-21.json'
correct='docs/evidence/correctness/blockwise-w4a8-reference-2026-10-21.json'
facts={f['catalog_index']:f for f in mlx['facts']}
updates={}
for i,f in facts.items():
 pending=['Exact producer activation/output/dequant rounding and original forward import remain unqualified; descriptor compatibility is not upstream numerical equivalence.',
   'No artifact payload or whole-model execution, Linux closure, quality or throughput acceptance.']
 if i==31:pending.insert(0,'156 attention head-bank triples require actual forward dtype/stride/head ordering qualification; candidate grouped geometry alone is not a verified importer.')
 if i==32:pending.insert(0,'37152 independent expert triples require a bounded129-bank resource/working-set bridge, not blind whole-bank concatenation; Apple complete mixed MoE remains delivery3.')
 updates[i]=dict(entry='mlx/assessment.json',summary='All stored affine W/scale/bias triples match existing affine4/5/6/8 g64 descriptor domains; no new codec/bitwidth/scale-type schema gap.',
  facts=f,remaining=pending,format='MLX affine g64, U32 continuous low-first rows; original scale/bias '+('/'.join(f['scale_bias_dtype_counts']))+'; bits '+','.join(f['affine_bits_counts']))
for i in (20,21,22,24):
 f=kimi['findings'][str(i)]
 pending={
 20:['Bind independent expert WG/IG/SF spans through working sets; retain original F32 block128 PB_WO attention scales rather than scalar SA/SW or dynamic-A quantization.',
     'Producer-specific arithmetic/import and full artifact payload/quality/performance remain unverified.'],
 21:['Qualify the ordinary BF16 CT block128 weight and dynamic group128 activation QDQ graph, including zero-scale epsilon, without substituting F32-scale code-dot math.',
     'Independent expert working sets and full artifact execution remain unverified.'],
 22:['Independent expert spans and bounded working sets remain delivery3; numeric shape-field values and payloads were not read.',
     'Select original BF16 operation precision explicitly; generic F32-A grouped witnesses do not determine a producer precision policy.'],
 24:['Independent per-expert source spans and working sets remain delivery3; no artifact payload, whole model, Linux closure, hardware integer GEMM, quality or throughput acceptance.']
 }[i]
 if i==20:summary=f['codec']+' '+f['attention']
 elif i==21:summary=f['conflict']+' '+f['mapping']
 elif i==22:summary=f['mapping']
 else:summary='Pinned published source establishes custom group512 BF16 W4A8. BlockwiseW4A8Linear/GroupedBlockwiseW4A8Linear now implement the distinct contract on CPU/CUDA/Vulkan/Apple; W4A16 and GPTQ-v1 are not equivalent.'
 updates[i]=dict(entry='kimi/review.json',summary=summary,facts=f,remaining=pending,
  format={20:'Mixed group16 ModelOpt NVFP4 experts; block128 FP8_PB_WO attention; BF16/F32 original roles',21:'Sampled E4 W + BF16 block128 SF; CT BF16 dynamic A group128, not inferred F32 code-dot',22:'Symmetric offset-binary I32 K-pack g128, BF16 SF, no activation quantizer',24:'Offset-binary low-first I32 W, F32 SF, group512 BF16 absmax/reciprocal -> truncatedI8, I32 dot and sequential BF16 group rescale/accumulation'}[i])
for i in (25,26,27,28,29):
 observations=[x for x in kv['header_observations'] if x['catalog']==i]
 if i in (25,26):
  summary='Sampled attention/shared FP8 roles use E4 W plus true E8M0 macroblock128 scales. Fixed inference source agrees with official GA dynamic group128 power2/floor1e-4 A math; scale-only cold widening may use existing dense block128 carrier.'
  pending=['Resolve scale-only importer and any grouped power2 activation quantizer before binding the corresponding routed role; do not infer grouped equivalence from dense support.', 'NVFP4 independent expert working sets and full artifact execution remain delivery3.']
 elif i==27:
  summary='Sampled attention and routed-expert FP8 roles physically store F32[ceil(N/128),ceil(K/128)] scales, despite config scale_fmt=ue8m0. Fixed inference source uses dynamic group128 A with power2 rounding and floor1e-4.'
  pending=['GroupedFloat8Linear currently lacks the matching power2 activation scale rule; extend/qualify its actual numerical domain, rather than reinterpret F32 SF as UE8M0.', 'No payload or full-role/model execution; DSpark identity remains separate.']
 else:
  summary='Mixed ModelOpt NVFP4/FP8/BF16 roles and static E4 KV declaration inspected. CacheStorage::float8(scale) alone does not supply all encoded-cache consumers.'
  pending=['Non-CUDA ordinary paged E4 KV encoder/consumer and FlashInfer compact MLA E4 domain require implementation/qualification in existing cache/batch families.',
    'Exact artifact KV scalar/producer binding remains unknown; ModelOpt constant-amax recipe29 is context, not proof of equivalence to the artifact exporter.', 'No artifact payload, full model, quality or throughput acceptance.']
 updates[i]=dict(entry='fp8-kv/review.json',summary=summary,facts=dict(header_observations=observations),remaining=pending,
  format='Actual stored role dtypes/scale grids and fixed producer math are recorded separately; config format label is not a carrier reinterpretation rule.')
updates[19]=dict(entry='inferact/assessment.json',summary=infer['facts'][0]+' '+infer['facts'][1],facts={k:infer[k] for k in ('facts','unresolved','non_claims')},remaining=infer['unresolved'],format='Sampled packed U8 expert W plus F32 micro32 SF; macro128/mbs-off declared. Producer code order, activation and rounding still unresolved; not Quark E8M0 W4A4.')
for i,u in updates.items():
 a=d['artifacts'][i];pc=a['provider_coverage'];assert pc['artifact_execution_verified'] is False
 pc['review']='fixed_revision_roles_and_bounded_operation_reference'
 pc['review_scope']='2026-10-21 fixed-source metadata/producer follow-up supersedes prior unresolved role descriptions; existing reachable entries retain only their stated generic mathematical proof. No whole-artifact execution.'
 pc['mapping_status']=u['summary'];pc['required_format_domain']=u['format']
 pc['missing_capabilities']=u['remaining'];pc['artifact_unaligned_or_unverified']=u['remaining']
 pc['fixed_source_role_binding']=dict(observed_on='2026-10-21',research_evidence=research,
   archive_entry=u['entry'],facts=u['facts'],artifact_execution_verified=False,tensor_payload_bytes_read=0)
 if i in facts or i in (19,24):
  pc['role_domains']=[dict(role='Fixed source stored roles and producer contract',observed=u['summary'],evidence=research,unresolved=u['remaining'])]
 if i==24:
  for e in pc['reachable_entry_points']:e['artifact_binding']='Retained generic W4A16/decode capability only; not an equivalent implementation of this custom group512 W4A8 runtime.'
  pc['reachable_entry_points'].append(dict(operation='BlockwiseW4A8Linear / GroupedBlockwiseW4A8Linear',providers=['CPU native','CUDA native','Apple Metal','Vulkan native'],
    execution='Original BF16 A, packed I32 W, F32 SF; unique A rows quantized once, exact group512 I32 dot -> BF16 -> multiply SA -> BF16 -> multiply BF16(SF) -> BF16 -> sequential BF16 accumulate; full IDs validation before expert addressing.',
    qualification='Bounded synthetic dense/grouped/shared/zero-stride graph and direct/runtime regressions; portable defined I8-cast domain, no producer payload or hardware GEMM claim.',evidence=correct))
  pc['blockwise_w4a8_reference']=dict(evidence=correct,mathematical_domain='Finite A; original SF finite positive; derived truncated I8 code in[-128,127]. Undefined source casts fail Completion, not saturation/wrap.',artifact_execution_verified=False)
  a['notes']='Low-download candidate retained separately; fixed base f831ab6 and publisher contract_ops.py define custom group512 BF16 W4A8 despite input_activations=null. Storage and mathematical operation are now resolved; published quantization quality remains unqualified.'
 if i==22:a['notes']='Publisher config210024bytes and first4260-tensor header now inspected: CT symmetric group128, no A quantizer, I32 low-first offset pack and BF16 scales; remaining shards/payload/import unexecuted.'
 if i==19:a['notes']='Sampled512 layer0 experts use U8 W and F32 micro32 scales; config declares micro32/macro128,mbs off,use_oas. Exact decoder/activation/macro rounding and fused gate-up order remain unresolved; retain apart from Quark W4A4.'
 if i==27:a['notes']='Fixed sampled attention and routed roles physically use F32 block128 scales; config UE8M0 label must not override dtype. Producer dynamic A uses power2 group128/floor1e-4; grouped path still needs that mode.'
d['limitations'][3]='Initial snapshot four configs exceeded200k; fixed-source follow-ups in provider_coverage record expanded bounded metadata reads. Original collection limits are historical, not current missing-file verdicts.'
d['followup_reviews']=d.get('followup_reviews',[])+[dict(observed_on='2026-10-21',evidence=research,artifact_indices=sorted(updates),scope='Sixteen fixed artifacts: complete six-MLX metadata sets and bounded sampled roles/producer code for remaining artifacts; no payload/whole-artifact execution.')]
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
after=json.loads(p.read_text(encoding='utf8'));assert len(after['artifacts'])==33
assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in after['artifacts'])
(S/'catalog-update.json').write_text(json.dumps(dict(before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),changed_indices=sorted(updates),all33_artifact_execution_verified_false=True),indent=2)+'\n',encoding='utf8')
print(sorted(updates))
