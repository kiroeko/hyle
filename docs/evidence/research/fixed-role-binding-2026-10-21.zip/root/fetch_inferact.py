from pathlib import Path
import importlib.util,json,struct,sys,zipfile,shutil
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;A=P.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('role_fetch',A/'static-fp8-contract-review/fetch.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
repo='Inferact/Qwen3.8-2.4T-A95B-MXFP4';rev='98b8fd6c5dec37c28ff28e7a0f577677ccbdc49f';dest=P/'inferact'
dest.mkdir(parents=True,exist_ok=True)
archive=ROOT/'docs/evidence/research/model-quantization-discovery-2026-10-19.zip'
with zipfile.ZipFile(archive) as z:
 prefix='qwen-kimi/'+repo.replace('/','--')+'/'
 for file in ['api-model.json','config.json','README.md','metadata-identity.json']:
  (dest/file).write_bytes(z.read(prefix+file))
assert json.loads((dest/'api-model.json').read_text(encoding='utf-8'))['sha']==rev
base=f'https://huggingface.co/{repo}/resolve/{rev}/'
old_receipt=dest/'model.safetensors.index.json.http.json'
if old_receipt.exists() and not (dest/'index-attempt1.http.json').exists():
 shutil.copyfile(old_receipt,dest/'index-attempt1.http.json')
api=json.loads((dest/'api-model.json').read_text(encoding='utf-8'))
shards=sorted(x['rfilename'] for x in api['siblings'] if x['rfilename'].endswith('.safetensors'))
first=sys.argv[1] if len(sys.argv)>1 else shards[0]
assert first in shards
file=dest/first;url=base+first
length=struct.unpack('<Q',h.fetch(url+'?download=true&hyle_fixed_role_range=0-7',file/'length.bin',8,0,7))[0]
assert 2<=length<=16*1024*1024,length
header=json.loads(h.fetch(url+f'?download=true&hyle_fixed_role_range=8-{length+7}',file/'header.json',length,8,length+7))
counts={}
for key,row in header.items():
 if key=='__metadata__':continue
 counts[row['dtype']]=counts.get(row['dtype'],0)+1
summary=dict(repository=repo,revision=rev,selected_shard=first,index='Full index exceeded4MiB; first shard chosen from the pinned cached API sibling list; no whole-index role census claimed',
 header=h.identity(file/'header.json'),tensor_count=len(header)-('__metadata__'in header),dtype_counts=counts,
 index_shards=len(shards),tensor_payload_bytes=0,
 examples=dict(list((k,v) for k,v in header.items() if k!='__metadata__')[:18]))
h.save(file/'summary.json',summary);print(json.dumps(summary,indent=2),flush=True)
