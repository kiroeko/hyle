from pathlib import Path
import hashlib,json
F=Path(__file__).resolve().parent.parent;S=F/'inferact'
def identity(p):return dict(path=str(p.relative_to(F)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def load(p):return json.loads(p.read_text(encoding='utf8'))
config=load(S/'config.json');api=load(S/'api-model.json')
rev='98b8fd6c5dec37c28ff28e7a0f577677ccbdc49f';assert api['sha']==rev
headers=[]
for p in sorted(S.glob('*/header.json')):
 d=load(p);roles={k:v for k,v in d.items() if k!='__metadata__'}
 counts={t:sum(v['dtype']==t for v in roles.values()) for t in sorted({v['dtype'] for v in roles.values()})}
 headers.append(dict(header=identity(p),tensor_count=len(roles),dtypes=counts,
   sample_roles=[dict(name=k,**v) for k,v in list(roles.items())[:6]]))
assert len(headers)==2
result=dict(observed_on='2026-10-21',catalog_index=19,repository=api['id'],revision=rev,
 config=identity(S/'config.json'),readme=identity(S/'README.md'),api=identity(S/'api-model.json'),
 source_url=f'https://huggingface.co/{api["id"]}/tree/{rev}',
 config_contract={k:(dict(count=len(v),exact_values_in_raw=True) if isinstance(v,(dict,list)) else v)
   for k,v in config['quantization_config'].items()},headers=headers,tensor_payload_bytes_read=0,
 facts=[
  'Preserved first model shard has130BF16 tensors. First mxfp4_experts shard has2048 tensors:1024U8 W and1024F32 SF, covering512 layer0 experts with down and fused gate_up.',
  'down_proj U8[8192,1024] with F32SF[8192,64]; gate_up_proj U8[4096,4096] with F32SF[4096,256]. If two codes per byte, those shapes agree with micro32 groups, but header alone does not define nibble/code order.',
  'Config micro_block32,macro_block128,mbs_mode off,use_oas true; it is not the Quark U8E8M0-scale three-port contract.',
  'Pinned API lists7preserved,92main expert and2MTP expert shards. Only two metadata headers sampled; no all-shard descriptor or payload census.'
 ],
 unresolved=[
  'Producer decoder defines E2M1 code ordering, macro/off behavior, scale application/rounding and activation quantizer. No producer implementation is present in the pinned listed repo files; copied base README has no quantization specification.',
  'Fused gate/up row order and actual forward activation dtype/layout must be established before splitting or consuming the fused matrix.',
  'Independent expert spans and working sets remain resource/import work, not proof that raw U8/F32 is an existing encoded Hyle carrier.'
 ],
 non_claims=['No mapping to Quark W4A4 by name. No activation QDQ inferred. No artifact execution, quality, hardwareFP4 or throughput claim.'],
 bounded_source_search='Pinned HF API/config/card and existing archive; read-only public GitHub code searches for mbs_mode/micro_block macro_block and named vLLM/SGLang handlers found no matching producer. Search absence is not proof no implementation exists.',
 acquisition_notes='Original19,966,795-byte index was refused by4MiB body cap; failed receipt and one expert length TLS EOF are preserved separately. Successful metadata reads are exact206 ranges with Content-Range validation. No full index needed for the sampled role findings.')
(S/'assessment.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(identity(S/'assessment.json'))
