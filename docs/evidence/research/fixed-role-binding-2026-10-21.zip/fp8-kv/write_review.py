from pathlib import Path
import collections,hashlib,json,zipfile
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/fixed-role-binding-2026-10-21/fp8-kv'
H=lambda b:hashlib.sha256(b).hexdigest()
def identity(p):
 p=Path(p);b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'bytes':len(b),'sha256':H(b)}
cat=json.loads((R/'docs/implementation/model-quantizations.json').read_bytes())['artifacts']
observations=[]
for n in (25,26,27,29):
 f={25:'model-00002-of-00066.safetensors',26:'model-00002-of-00048.safetensors',27:'model-00001-of-00058.safetensors',29:'model-00001-of-00033.safetensors'}[n]
 p=S/'headers'/str(n)/f/'header.json';h=json.loads(p.read_bytes())
 rows=[]
 if n in (25,26,27):
  for k,v in h.items():
   if any(k.endswith(x) for x in ('attn.wkv.weight','attn.wkv.scale','attn.wkv.weight_scale_inv','attn.wq_b.weight','attn.wq_b.scale','attn.wq_b.weight_scale_inv','ffn.shared_experts.w1.weight','ffn.shared_experts.w1.scale','ffn.shared_experts.w1.weight_scale_inv','ffn.experts.0.w1.weight','ffn.experts.0.w1.weight_scale','ffn.experts.0.w1.weight_scale_2','ffn.experts.0.w1.input_scale')):
    rows.append({'key':k,'dtype':v['dtype'],'shape':v['shape']})
 else:
  for suffix in ('weight','weight_scale','input_scale'):
   row=next(({'key':k,'dtype':v['dtype'],'shape':v['shape']} for k,v in h.items() if isinstance(v,dict) and '.mlp.experts.' in k and k.endswith('.'+suffix)),None)
   if row:rows.append(row)
 observations.append({'catalog':n,'repository':cat[n]['repository'],'revision':cat[n]['revision'],'header':identity(p),'tensor_count':len(h)-('__metadata__' in h),'dtype_counts':dict(collections.Counter(v['dtype'] for k,v in h.items() if k!='__metadata__')),'representative_roles':rows,'kv_scale_key_matches':[k for k in h if any(x in k.lower() for x in ('k_scale','v_scale','kv_scale','cache_scale'))]})
zpath=R/'docs/evidence/research/static-fp8-stored-scale-contract-2026-10-20.zip'
with zipfile.ZipFile(zpath) as z:
 member='headers/28/model-00001-of-00050.safetensors/header.json';b=z.read(member);h=json.loads(b)
 observations.append({'catalog':28,'repository':cat[28]['repository'],'revision':cat[28]['revision'],'header':{'archive':zpath.relative_to(R).as_posix(),'member':member,'bytes':len(b),'sha256':H(b)},'tensor_count':len(h)-('__metadata__' in h),'representative_roles':[{'key':k,'dtype':v['dtype'],'shape':v['shape']} for k,v in h.items() if k.startswith('model.layers.0.') and ('.mlp.' in k or '.self_attn.' in k) and (k.endswith('weight') or k.endswith('weight_scale') or k.endswith('input_scale'))],'kv_scale_key_matches':[k for k in h if any(x in k.lower() for x in ('k_scale','v_scale','kv_scale','cache_scale'))]})
code_paths=['include/hyle/compute/low_precision.h','include/hyle/compute/model_ops.h','src/compute_ops/low_precision.cc','src/compute_route_vulkan/vulkan_official.cc','src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_tensor.cc','src/compute_route_apple/apple_batch.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_provider_ggml/native_batch.cc','src/compute_provider_flashinfer/flashinfer_provider.cc','src/compute_provider_flashinfer/native_cache_encoder.cu','src/compute_batch/batch_materialize.cc']
base=R/'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'
with zipfile.ZipFile(base) as z:
 ga=[{'archive':base.relative_to(R).as_posix(),'member':f,'bytes':len(z.read(f)),'sha256':H(z.read(f))} for f in ['flash-0731/inference-model.py','flash-0731/inference-kernel.py']]
source_rows=json.loads((S/'source-downloads.json').read_bytes())
report={
 'status':'bounded_fixed_revision_read_only_role_binding_review',
 'date':'2026-10-21',
 'scope':{'catalog':[25,26,27,28,29],'deepseek_release':'official GA Pro-0813 / Flash-0731; no preview or V4.1 substitution','model_payload_bytes':0,'builds':0,'gpu_runs':0,'product_edits':0,'entire_artifact_execution_verified':False},
 'header_observations':sorted(observations,key=lambda x:x['catalog']),
 'primary_sources':source_rows,
 'official_ga_archive_sources':ga,
 'source_identity_facts':[
  'All six publisher-pinned inference/model.py and inference/kernel.py files (25/26/27) are byte-identical pairwise and to retained official GA model/kernel. This proves these source files were carried through, not that every quantized routed-expert role executes through this unmodified reference.',
  'Their linear() quantizes FP8 operands with act_quant group128; act_quant applies absmax floor1e-4 and power-of-two scale rounding when scale_fmt is set. ModelArgs defaults scale_dtype=fp8 and __init__ forces ue8m0 in that mode. Actual Transformers configs do not directly contain these ModelArgs globals; an adapter must resolve the runtime args rather than blindly apply the defaults.',
  '27 has config scale_fmt=ue8m0 but actual sampled macroblock scales are F32. Its README conversion-script/lossless claim is not an independently verified numeric conversion; that script is not retained in this repo source set.',
  'The fixed official ModelOpt GLM-5.3-Flash recipe imports kv_fp8_cast; its unit sets use_constant_amax=true on K/V quantizers. This is stronger than generic static-scheme metadata, but source commit4956213 is not falsely asserted identical to artifact29 producer commit a4bc45b30. No scalar value is inferred merely from constant-amax wording.'
 ],
 'role_binding':[
  {'catalog':[25,26],'role':'preserved attention and shared-expert FP8 projections','observed':'E4M3 codes [N,K] plus E8M0 [ceil(N/128),K/128], not group32 scales','candidate':'Keep original E4 code bytes; cold widen only E8M0 macroblock scales to exact F32 and pack existing Float8ScaleMode::kFloat32Block128 carrier. Float8WeightDecode can alternatively materialize one BF16/F32 weight in cold preparation when chosen memory/performance policy allows it. Never tag source macroblock128 as existing UE8 group32 storage.','remaining':'Import/widen proof and resolved activation quantizer semantics are not executed here; dense Float8BlockLinear(kPowerOfTwo,1e-4) is the closest existing dynamic-A boundary.'},
  {'catalog':[25,26],'role':'routed NVFP4 experts','observed':'Original U8 W, E4 group16 SF, and F32 rank0 input_scale/weight_scale_2, per expert tensors','candidate':'Existing Nvfp4Linear/GroupedNvfp4Linear 5/6-port geometry is the relevant family, not LocalNvfp4 or Quark MXFP4. Preserve globals and expert tensor identities.','remaining':'Header/config does not independently prove exporter scalar direction or complete W4A4 quantizer math. Publisher README says cast_mxfp4_to_nvfp4 rewrites group32 scales to16 and calibrates activations; exact fixed conversion implementation must be bound before a green numerical role declaration. Separate-expert working-set bridging remains delivery3.'},
  {'catalog':[27],'role':'FP8 attention and routed experts','observed':'E4M3 codes plus F32 macroblock128 scales; sampled wo_a remains BF16','candidate':'Existing F32 block128 carrier and Float8WeightDecode fit physical storage. The preserved GA source requests dynamic A quantization; a weight-only cold decode must not silently replace W8A8 semantics.','remaining':'GroupedFloat8Linear exposes absmax_floor but not power-of-two activation scale rounding; cannot claim equivalence to resolved GA power2 mode. The repacker numeric contract is unverified.'},
  {'catalog':[28],'role':'early dense static FP8 MLP / later NVFP4 / KV','observed':'Sampled layer0 E4 W with scalar F32 input_scale and weight_scale; sampled attention BF16. Config says static FP8 KV. No KV scale tensor in sampled first header.','candidate':'Early MLP fits recently completed static ordinary/cold contraction role in principle; NVFP4 roles require their actual shards. CacheStorage::float8(sK/sV) can represent fixed positive scalar scales.','remaining':'Sampled absence of KV scales does not establish scale1 or complete absence across artifact. Source-specific KV cast/calibration and MLA cache path must be resolved before binding.'},
  {'catalog':[29],'role':'NVFP4 experts and static FP8 KV','observed':'Header has U8 expert W, E4 group16 SF and F32 input scales, but the first shard is not a complete matched tuple of every global; original scalars may cross shards. Official recipe calls KV constant-amax cast; artifact config producer is0.47.0.dev393+ga4bc45b30.','candidate':'Keep original packed expert family; resolve exact globals via index before binding. For fixed scalar KV, use existing cache scale descriptor instead of inventing calibrated adapters by assumption.','remaining':'Recipe commit is not exact artifact producer commit, and K/V scalar values were not read from payload. Actual header includes a layer45 indexer key despite recipe comment saying MTP not exported; actual header takes precedence. Entire mixed KDA/MLA/attention journey is not established by a generic cache descriptor.'}
 ],
 'current_hyle_evidence':{
  'source_identities':[identity(R/p) for p in code_paths],
  'supported_semantics':[
   'CacheStorage::float8(scale) supports a positive finite scalar per K or V storage lifetime. Different fixed K/V scalars are structurally representable.',
   'FlashInfer ordinary batch accepts E4 K/V and applies key_scale in QK scale and value_scale in result. Its CacheEncode implements finite input divide-by-scale then SATFINITE E4 cast.',
   'Float8BlockLinear supports power-of-two scale rounding with explicit floor; all four existing backend routes have implementations. GroupedFloat8Linear currently has no corresponding rounding field.'
  ],
  'source_proven_missing_domains':[
   {'domain':'Vulkan / Apple / ggml CPU paged FP8 KV','evidence':'Their actual cache_domain/qualify functions admit same-type plain or Q8_0, not E4. Vulkan/Apple CacheEncode admits Q8_0 only. Generic materialized batch reference explicitly rejects E4 encoded caches.','smallest_next_action':'Add one truthful finite FP8 CacheEncode + encoded-cache attention consumer per backend, with fixed K/V scales and existing batch layout/lease lifetime; do not claim ordinary Cast alone supplies the consumer.'},
   {'domain':'FlashInfer compact MLA with FP8 storage','evidence':'qualify_mla explicitly requires plain K/V matching query dtype, even though ordinary batch supports E4.','smallest_next_action':'Determine exact model cache representation and extend the existing MLA family only when that scalar encoding is valid; do not conflate DeepSeek row-inline block64/BF16-tail formats with static uniform E4.'},
   {'domain':'Grouped FP8 dynamic power2 A scale','evidence':'GroupedFloat8Linear has only absmax_floor while dense Float8BlockLinear also has scale_rounding.','smallest_next_action':'Only if resolved role requires GA power2 quantizer, extend the existing grouped descriptor/cold policy and original implementation, preserving existing default math. No model whitelist or new executor.'}
  ]
 },
 'non_gaps_and_limits':[
  'F32 physical block128 scales on27 are a catalog binding correction, not missing UE8M0 functionality.',
  'UE8M0 macroblock128 source scales need an importer/storage conversion decision, not necessarily another execution format or whole-bank BF16 expansion.',
  'NVFP4 original per-expert tensors must not be force-concatenated into one huge bank as proof of working-set support; large-bank/device-range/fragmented imports remain delivery3.',
  'No whole shard tensor payload, model execution, performance, static-KV payload scalar, or full cross-platform result was established in this review.'
 ],
 'retained_receipts':['header-downloads-initial.json','header-downloads.json','header-downloads-second.json','source-downloads.json'],
 'observation_errata':'Initial header helper required more than one JSON key and classified valid single-embedding headers25/26 as failure after successful206 reads. Original receipts remain; corrected header-downloads.json recognizes them. This did not fetch payload or invalidate later headers.'
}
(S/'review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(identity(S/'review.json')))
