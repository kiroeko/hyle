from pathlib import Path
import urllib.request,urllib.error,re,struct,json,hashlib,time,concurrent.futures,zipfile
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/fixed-role-binding-2026-10-21/fp8-kv';S.mkdir(parents=True,exist_ok=True)
cat=json.loads((R/'docs/implementation/model-quantizations.json').read_bytes())['artifacts']
first={25:'model-00001-of-00066.safetensors',26:'model-00001-of-00048.safetensors',27:'model-00001-of-00058.safetensors',29:'model-00001-of-00033.safetensors'}
MAX_HEADER=1536*1024

def get_range(url,start,end,target):
 t=time.time();expected=end-start+1;req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity','User-Agent':'Hyle-bounded-header-review'})
 with urllib.request.urlopen(req,timeout=35) as response:
  status=response.status;headers=dict(response.headers.items());cr=response.headers.get('Content-Range','');m=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',cr)
  if status!=206 or not m or tuple(map(int,m.groups()[:2]))!=(start,end):raise RuntimeError(f'Range rejected {status} {cr}')
  if response.headers.get('Content-Encoding','identity') not in ('identity',''):raise RuntimeError('unexpected content encoding')
  length=response.headers.get('Content-Length');assert length is None or int(length)==expected
  raw=response.read(expected);assert len(raw)==expected
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 receipt={'url':url,'method':'GET','range':f'bytes={start}-{end}','http_status':status,'content_range':cr,'content_length':length,'response_header_subset':{k:v for k,v in headers.items() if k.lower() in ('etag','last-modified','x-repo-commit','content-type')},'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'seconds':time.time()-t,'payload_bytes':0}
 target.with_name(target.name+'.http.json').write_text(json.dumps(receipt,indent=2)+'\n');return raw,receipt

def task(n):
 a=cat[n];f=first[n];url=f"https://huggingface.co/{a['repository']}/resolve/{a['revision']}/{f}?download=true";d=S/'headers'/str(n)/f
 try:
  raw,one=get_range(url,0,7,d/'length.bin');length=struct.unpack('<Q',raw)[0]
  if not 2<=length<=MAX_HEADER:raise RuntimeError(f'header length {length} exceeds {MAX_HEADER} bounded scope')
  raw,two=get_range(url,8,7+length,d/'header.json');h=json.loads(raw)
  assert isinstance(h,dict) and len(h)>1
  return {'catalog':n,'repository':a['repository'],'revision':a['revision'],'file':f,'status':'header_only','header_length':length,'tensor_count':len(h)-('__metadata__' in h),'requests':[one,two]}
 except Exception as e:
  return {'catalog':n,'repository':a['repository'],'revision':a['revision'],'file':f,'status':'failed','error':str(e),'payload_bytes':0}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(task,first))
(S/'header-downloads.json').write_text(json.dumps(rows,indent=2)+'\n')
for x in rows:print(x['catalog'],x['status'],x.get('header_length'),x.get('tensor_count'),x.get('error'))
