from pathlib import Path
import concurrent.futures, hashlib, json, time, urllib.request
R=Path.cwd(); S=R/'.scratch/architecture-refactor-2026-10-18/fixed-role-binding-2026-10-21/fp8-kv'
cat=json.loads((S/'catalog-snapshot.json').read_bytes())
if isinstance(cat,dict): cat=cat.get('artifacts',cat)
jobs=[]
full=json.loads((R/'docs/implementation/model-quantizations.json').read_bytes())['artifacts']
for n in (25,26,27):
 a=full[n]
 for f in ('model.py','kernel.py'):
  jobs.append((str(n)+'/'+f, f"https://huggingface.co/{a['repository']}/resolve/{a['revision']}/inference/{f}", 128*1024))
commit='4956213d670c382385d9bc43e17379b9fc064e50'
for f in ('modelopt_recipes/models/zai-org/GLM-5.3-Flash/ptq/nvfp4_experts_dense_mlp-kv_fp8_cast.yaml','modelopt_recipes/configs/ptq/units/kv_fp8_cast.yaml'):
 jobs.append(('modelopt/'+f, f'https://raw.githubusercontent.com/NVIDIA/Model-Optimizer/{commit}/{f}',128*1024))
def one(job):
 name,url,cap=job; target=S/'primary'/name; started=time.time()
 try:
  req=urllib.request.Request(url,headers={'Accept-Encoding':'identity','User-Agent':'Hyle-bounded-role-source-review'})
  with urllib.request.urlopen(req,timeout=30) as response:
   status=response.status; length=response.headers.get('Content-Length')
   if status!=200 or (length and int(length)>cap): raise RuntimeError(f'source rejected: {status}, length={length}')
   raw=response.read(cap+1)
   if len(raw)>cap: raise RuntimeError('source exceeds bound')
   if length and int(length)!=len(raw): raise RuntimeError('length mismatch')
   headers={k:v for k,v in response.headers.items() if k.lower() in ('etag','last-modified','content-type','x-repo-commit')}
  target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw)
  row={'path':target.relative_to(S).as_posix(),'url':url,'http_status':status,'bytes':len(raw),'cap':cap,'sha256':hashlib.sha256(raw).hexdigest(),'headers':headers,'seconds':time.time()-started,'model_tensor_payload_bytes':0}
 except Exception as e: row={'url':url,'path':target.relative_to(S).as_posix(),'error':str(e),'model_tensor_payload_bytes':0}
 target.parent.mkdir(parents=True,exist_ok=True); target.with_name(target.name+'.http.json').write_text(json.dumps(row,indent=2)+'\n')
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: rows=list(pool.map(one,jobs))
(S/'source-downloads.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows: print(r['path'],r.get('bytes'),r.get('sha256'),r.get('error'))
