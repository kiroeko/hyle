from pathlib import Path
import concurrent.futures
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('kimi_fixed_fetch',S/'fetch.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def prefix(i):
    repo,rev=h.ARTS[i]
    dest=S/str(i)/'index-prefix-0-65535.json.part'
    if not dest.exists():
        h.fetch(f'https://huggingface.co/{repo}/resolve/{rev}/model.safetensors.index.json?download=true&hyle_fixed_role_index=0-65535',dest,65536,0,65535)
    return h.ident(dest)
jobs=[('index_prefix',i,None) for i in h.ARTS]
jobs += [('header',20,'model-00001-of-000096.safetensors'),
         ('header',21,'model-00001-of-000096.safetensors'),
         ('header',22,'model-00001-of-00142.safetensors'),
         ('header',24,'quant-layer-000.safetensors')]
def one(row):
    kind,i,name=row
    try: result=dict(kind=kind,artifact=i,file=name,body=h.header(i,name) if kind=='header' else prefix(i))
    except Exception as error: result=dict(kind=kind,artifact=i,file=name,error=str(error))
    print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(one,jobs))
h.save(S/'range-results.json',results)
