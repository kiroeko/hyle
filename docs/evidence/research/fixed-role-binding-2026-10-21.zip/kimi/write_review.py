from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent
ROOT=S.parents[3]
def ident(p):
    p=Path(p);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def lines(name,needles):
    p=S/name;text=p.read_text().splitlines()
    return dict(source=ident(p),anchors={n:[i+1 for i,line in enumerate(text) if n in line] for n in needles})

contract=dict(
    status='fixed_producer_runtime_contract_confirmed_with_explicit_nonportable_cast_domain',
    artifact_index=24,repository='open-inference/Kimi-K3-W4A8-K512-GPTQ-Mixed-Cal72-Seq1024',
    revision='dabd12ab69bf9c71fd219bae4c49a34f00249bd2',
    source_base_revision='f831ab66814297da540d832a5235f8e904f29d06',
    source_urls={n:f'https://huggingface.co/open-inference/Kimi-K3-W4A8-K512-GPTQ-Mixed-Cal72-Seq1024/blob/dabd12ab69bf9c71fd219bae4c49a34f00249bd2/{n}' for n in ('quantization/contract_ops.py','quantization/build.py','artifact-manifest.json','recipe.json','operator-validation.json','environment.txt')},
    identity='Manifest and recipe name contract kimi-k3-w4a8-k512-v1 and pin the exact contract_ops/build SHA256. Source records full-Hessian GPTQ as a calibration method; storage is CT offset-binary K-packed INT4, not GPTQ-v1 Q/Z/g_idx.',
    artifact_execution_verified=False,
    actual_ports=dict(
        single_expert=dict(A='BF16[M,K]',Q='I32[N,K/8], little-endian words; eight adjacent K codes per word, lowest K nibble at bit0',SF='F32[N,K/512]',Y='BF16[M,N]'),
        grouped_semantic=dict(A='BF16[T,1 or S,K]',Q='logical stack I32[E,N,K/8] or flat I32[E*N,K/8]; actual checkpoint uses independently named per-expert spans',SF='logical F32[E,N,K/512] or flat F32[E*N,K/512]',IDs='I32[T,S]',Y='BF16[T,S,N]'),
        header_examples=dict(w1_w3=dict(Q=[3072,448],SF=[3072,7],logical_W=[3072,3584]),w2=dict(Q=[3584,384],SF=[3584,6],logical_W=[3584,3072]),E=896),
        direction='W is row-major logical [N,K]; y[m,n] sums the K axis of A[m,k]*W[n,k]. No transpose of packed words and no AWQ/GPTQ output-axis reinterpretation.',
        no_zero_bank=True,no_g_idx=True,weight_shape='I64[2] is shape metadata only; its payload was not fetched. Logical dimensions are independently determined by Q/SF/config.'),
    packing=dict(writer='QuantWeight.tensors: q = int64(codes).reshape(N,-1,8)+8; sum(q << (4*arange(8))) -> int32.',
        unpack='((uint32(word) >> (4*(k%8))) &15)-8; int32 sign bit is storage bits, not signed nibble sign extension.',
        producer_code_range='Calibration clamps to [-7,7]; build.audit_projection verifies no decoded -8. The generic offset-binary carrier can represent -8, but that is not a claimed observed producer payload.',
        source_checksums_match_manifest=True),
    scalar_algorithm=[
        'Cast input x to BF16 before quantization. QuantWeight.__call__ uses activation_blocks(x) with cols=1, contiguous complete K blocks512.',
        'For each row/block: max = max(abs(BF16(A))); SA = BF16(max * 0.00787353515625), constant exactly BF16 bits0x3c01. This is a multiply by BF16(1/127), not exact division by127.',
        'IA = BF16(where(SA==0,0,reciprocal(SA))); then V = BF16(BF16(A)*IA). Codes = signed int8(V) with truncation toward zero for representable values. No clamp and no nearest-even integer rounding.',
        'D = int32 dot(A_codes, signed_INT4_W_codes) over this block only; D_b = BF16(D). Producer pads M only for CUDA _int_mm requirements; that padding is not part of the mathematical output.',
        'WS = BF16(original_F32_SF[n,block]); P = BF16(D_b * BF16(SA)); P2 = BF16(P * WS).',
        'R starts BF16 +0; for increasing K blocks, R=BF16(R+P2). Output remains BF16. Do not merge SA*WS, dequantize a whole W bank, accumulate all blocks in F32, or delay the BF16 boundaries.',
    ],
    domain_and_special_values=dict(
        source_input_checks='No runtime finite guard on A, no code clamp, and no explicit rule for undefined float-to-I8 conversions. Exporter checks serialized SF F32 finite and positive; calibration clamps fitted scales at1e-30 and rejects invalid scales.',
        positive_and_negative_zero='absmax is nonnegative. All +/-0 block gives SA+0 and IA+0; resulting signed BF16 zeros truncate to I8zero. Dot is zero. No SF infinity is generated from ordinary valid exported SF1.',
        tiny='SA may round to BF16zero, intentionally taking IA=0 and all I8codes0. A slightly larger tiny SA may be nonzero subnormal and reciprocal may overflow to Inf; then A*IA can be Inf/NaN. Do not insert an epsilon or floor; that would be a different algorithm.',
        NaN_Inf='NaN propagates through absmax/scale/reciprocal/product and Inf can produce Inf*0 NaN. Subsequent non-finite-to-I8 conversion has no portable guarantee. Do not assign wrapping, saturation or zero as a source guarantee.',
        truncation='For finite V whose truncation lies in [-128,127], conversion is toward zero. Values127.5 truncate to127 and are valid; test trunc(V), not an overstrict V<=127 check. +128 is out of range; -128 is representable.',
        finite_overflow='Even finite BF16 A can generate nonfinite codes via tiny reciprocals, or a finite +128 endpoint. Independent scalar enumeration records examples and counts; no actual Torch/CUDA/TPU run is asserted.',
        BF16_scale_conversion='Export SF is F32 and positive/finite; BF16(SF) is a separate earlier boundary than the current W4A16 product tree. If an admitted F32 scale rounds to BF16 Inf, later 0*Inf may yield NaN; do not silently reorder or saturate it.',
        PyTorch_primary=dict(url='https://docs.pytorch.org/docs/2.13/generated/torch.Tensor.to.html',local=ident(S/'24/torch-2.13-Tensor.to.html'),lines=[4115,4116,4117],conclusion='Fractional part truncates; a truncated value that cannot fit the target type is undefined and may vary across platforms.'),
        recommended_first_Hyle_domain='Finite BF16 A; positive finite original F32 SF (only selected expert scales need reading); for every quantized lane require finite V with trunc(V) in [-128,127]. Reject the otherwise undefined source conversion through failed Completion. Preserve SA==0 behavior and every defined IEEE BF16 rescale/add boundary. This is an explicit new portable domain, not a claim that the producer itself rejects those inputs.'),
    independent_scalar_witness=ident(S/'24/scalar-contract-results.json'),
    ordinary_composition_assessment=dict(
        mathematical='BF16 Abs/Reduce/Mul, zero-only Select and BF16 reciprocal/divide can express scale generation, while each block requires truncating I8 conversion, exact integer dot and its own BF16 rescale/add. The full source could be represented by a finite ordinary graph only after these typed contracts are implemented and tested.',
        current_Hyle='Current four-backend ordinary floating<->I8/Truncate coverage is absent. Existing CT packed reference is W4A16 with source-product/decode/operand RNE and F32 dot. Static/dynamic FP8 references have different codes/scales/rounding. None is an interchangeable implementation of this runtime.',
        do_not_substitute='An ordinary F32 MatMul over dequantized weights changes quantization and BF16 group accumulation. Even integer-coded F32 arithmetic would need a bounded exact-integer proof and the same per-block BF16 nodes, not a blanket F32MatMul replacement.'),
    minimal_design=dict(
        suggested_semantic_name='GroupwiseBFloat16Int4Int8Linear and GroupedGroupwiseBFloat16Int4Int8Linear (descriptive working names; no Kimi/version whitelist)',
        inputs='Dense3 ports A(BF16), Q(I32 K-packed offset-binary), SF(F32 per output row/group); grouped4 adds I32 IDs. Output BF16. An explicit group_size attr defaults512; initial implementation must keep complete groups and prove per-group I32 dot cannot overflow for any newly admitted width.',
        math='Document the exact0x3c01 BF16 scale factor, truncation/domain and per-group BF16 dot/rescale/add tree above. A new descriptor must be numerically distinct from ArtifactPackedLinear W4A16; no old-format alias or route by model name.',
        CPU='Reuse native nvfp4/ct_packed PreparedOperation, Mapping, Completion and workspace machinery. Cold-select dense/grouped functions without changing NativePlan layout. Store int8 activation codes M*K plus BF16 SA M*(K/group); grouped shared A quantizes T rows, distinct AS quantizes T*S. Decode W directly from original packed words in bounded row/group tiles; exact I32 dot, then explicit BF16 boundaries in increasing K groups. No E*N*K floating bank.',
        lifecycle='Reuse original Graph/custom provider lowering and slot owners. Validate complete IDs before selected source addressing. Validate all quantized activation codes before W-dependent reads/writes, retain ordinary workspace/input/output overlap checks and map close/flush errors. Invalid source-domain inputs fail Completion; outputs of a failed invocation are not consumed.',
        source_owners=['include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc','src/compute_provider_native/ct_packed.cc or one adjacent native leaf','src/compute_provider_native/native_provider.cc','src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_provider_torch_cuda/mlx_packed_kernel.cu','src/compute_route_apple/apple_ct_packed.cc','src/compute_route_vulkan/vulkan_ct_packed.cc'],
        resource_bridge='Original per-expert banks are separate named spans. The upcoming catalog/WeightSlots working-set bridge must preserve source owners and explicit global-to-local expert IDs; do not concatenate/read an entire model bank merely to exercise a small operator.',
        focused_tests=['Independent normal witness1 versus0.9921875','BF16 scale multiply versus exact divide127; fractional positive/negative truncate','SAzero/tiny handling and defined-code domain failure for NaN/Inf/+128, then fresh invocation recovery','Two512 blocks with BF16 inter-block rounding and independent F32 SF->BF16 witness','Dense/grouped shared A/AS, repeated IDs, invalid final ID before selected bank reads, two slots and retained results; normal capture paths']),
    source_anchors=[lines('24/quantization/contract_ops.py',['RECIPROCAL_127_BF16','def activation_blocks','scale =','inv =','code =','def __call__','dot =','ws =','partial =','result =','def tensors','q =','packed =','maximum =','Invalid calibrated scale']),
                    lines('24/quantization/build.py',['def audit_projection','Invalid scale export','codes =','codes == -8','scale changed','group[\'weights\']'])],
    limitations=['No weight payload downloaded; no whole-artifact execution, code/scale numeric census, GPU or Hyle build/run.',
        'Publisher operator-validation is a producer report for one real expert and TPU Pallas path; it is not a Hyle test or whole-model quality result.',
        'Source primitive definition and proposed portable invalid-domain policy must be kept distinct.'])
save(S/'24/contract-review.json',contract)

rows=[]
for i in (20,21,22,24):
    config=json.loads((S/str(i)/'config.json').read_bytes())
    rows.append(dict(artifact_index=i,config=ident(S/str(i)/'config.json'),
        headers=[ident(p) for p in sorted((S/str(i)/'headers').glob('*/header.json'))],
        fixed_sources=[ident(p) for p in sorted((S/str(i)/'producer').rglob('*.py'))] if (S/str(i)/'producer').exists() else [],
        index_scope='Only strict Range bytes0-65535 obtained. Full index Content-Length58-118MB was rejected before reading body. Header samples establish listed roles, not all artifact tensors.',
        tensor_payload_bytes_downloaded=0))
summary=dict(status='bounded_fixed_role_and_runtime_contract_review_complete',artifact_execution_verified=False,
    artifacts=rows,config_summary=ident(S/'config-summary.json'),header_role_summary=ident(S/'header-role-summary.json'),
    findings={
        '20':dict(codec='Confirmed mixed ModelOpt0.45.0: per-expert group16 NVFP4 plus FP8_PB_WO attention and original BF16/F32 roles.',
            experts='Inspected complete layer12:896 experts ×w1/w2/w3; Q U8[3072,1792]/[3584,1536], SF E4M3[3072,224]/[3584,192], WG/IG F32 scalars[]. Logical W w1/w3[3072,3584],w2[3584,3072]. Existing Nvfp4Linear/GroupedNvfp4Linear reference can express these roles after exact independent-span binding; this is not hardware NVFP4 GEMM qualification.',
            attention='Layer0 g_proj E4M3[12288,7168], SF F32[96,1,56,1]; o_proj E4M3[7168,12288], SF F32[56,1,96,1]. This is block128 weight-only storage, not scalar static FP8 or dynamic-A FP8. Current float8_weight_decode encoded carrier can represent block128 numerical storage after import/pack; separate original buffers require explicit view/broadcast bridge, not reinterpretation as an already encoded Hyle object.',
            evidence_census='Conversion report says92 expert banks/696 attention modules; config has552 group0 and2790 group1 alias targets,3342 alias quantized_layers. Do not count all aliases as physical tensors.',
            unknown='Per-artifact ModelOpt deployment/reference BF16 boundary, numeric global values and all-role payload/import remain unexecuted. No extra whole-artifact missing function inferred.'),
        '21':dict(conflict='Root CT FP8_BLOCK and nested legacy MXFP4 metadata both exist. Physical inspected layer0 MLP and all896 layer1 experts are E4M3 weights with BF16 block128 scales, no U8 MXFP4 weights in these samples. Root config matches those physical roles; nested metadata cannot override their tensor type.',
            roles='Layer0 gate/up W[33792,7168],SF BF16[264,56]; down W[7168,33792],SF[56,264]. Layer1 w1/w3 W[3072,3584],SF BF16[24,28]; w2 W[3584,3072],SF[28,24]. Attention samples remain BF16/F32. Root input activation quantization: dynamic E4M3 per contiguous group128.',
            producer='CT version0.17.2.dev32+g1f3b632.d20260723 resolves exact commit1f3b63299961bec13861825d0823a502e875091d; five snapshot identities include tree and3 math/format source files.',
            mapping='Weight dequant is E4 code cast to BF16 scale dtype then BF16 multiply. Dynamic group128 quantizer likewise retains BF16 scale/QDQ boundaries (source zero scale substitutes BF16 eps). Ordinary typed graph can describe this. Current Float8BlockLinear/GroupedFloat8Linear require F32 encoded scales/floor and code-dot math, so neither root metadata nor shape similarity alone establishes numerical equivalence. A bounded exact CT block/group consumer remains to qualify; no new broad graph mechanism required.',
            unknown='Full huge index not fetched; no claim that every untaken shard lacks legacy MXFP4. Any such role must be resolved by its physical header. No model payload execution.'),
        '22':dict(contract='New210024B config removes old200k gap. Root and nested quantization configs identical: CT symmetric INT4 group128, no activation quantizer; version0.18.1.dev23+gb56e39c;1558 exact ignore strings.',
            actual_header='First shard has4260 tensors, including1351 I32 packed matrices,1351 I64[2] shape fields and BF16 scales. Sample w1/w3 Q[3072,448],SF BF16[3072,28];w2 Q[3584,384],SF[3584,24]. Layer0 MLP/attention samples remain BF16.',
            exact_pack='Fixed CT commitb56e39ce9d082972e83426dcf47e7c6fbeed7b77 pack_to_int32 adds8 and places adjacent K nibbles low-first; default packed_dim1. No zero-point bank for symmetric format.',
            mapping='artifact_weight_decode(kCompressedTensorsSymmetric4,128,BF16), preserving source BF16 multiply boundary, plus original BF16 operation or exact expert reshape/GroupedMatMul with A widened toF32 and BF16 W operand. Current grouped package includes an exact symmetric128 BF16->F32->F32 finite witness; other allowed output trees require matching actual caller precision policy.',
            gap='No newly missing decode/grouped primitive established. Remaining independent-expert span/catalog binding and working sets are delivery3. Numeric shape-field payload, exact code/scale values and full-role binding are not inferred from a header.'),
        '24':dict(contract_review=ident(S/'24/contract-review.json'),
            conclusion='Storage and scale metadata now pinned, and repository-published fixed source defines a custom BF16 groupwise W4A8 runtime despite input_activations=null. It is a true additional numerical contract distinct from current W4A16 packed and GPTQ-v1. Proposed generic grouped/dense primitive above; no product implementation in this task.')},
    next_action='First define and implement the24 generic groupwise BF16 W4A8 numerical primitive with explicit portable derived-I8-cast domain, reusing existing PreparedOperation/Graph/slots. Do not reopen old grouped W4A16 as a decoder bug.',
    all_sources_pinned_or_historical=True,no_builds=True,no_GPU=True,no_payload=True)
save(S/'review.json',summary)
files=[ident(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name not in ('source-inventory.json',)]
save(S/'source-inventory.json',dict(files=files,total_bytes=sum(x['bytes'] for x in files),payload_bytes=0))
print(json.dumps(dict(review=ident(S/'review.json'),contract_review=ident(S/'24/contract-review.json'),inventory=ident(S/'source-inventory.json')),indent=2))
