from pathlib import Path
from collections import Counter
import json,re
S=Path(__file__).resolve().parent
for i in (20,21,22,24):
    p=S/str(i)/'index-prefix-0-65535.json.part'
    pairs=re.findall(r'"([^"]+)"\s*:\s*"([^"]+safetensors)"',p.read_text())
    print(i,'pairs',len(pairs),'first',pairs[:9],'last',pairs[-3:])
    print('mapped_shards',Counter(v for k,v in pairs))
    for hp in (S/str(i)/'headers').glob('*/header.json'):
        d=json.loads(hp.read_bytes())
        tensors={k:v for k,v in d.items() if k!='__metadata__'}
        print(hp.parent.name,'tensors',len(tensors),'types',Counter(v['dtype'] for v in tensors.values()))
        print(json.dumps(dict(list(tensors.items())[:12]),indent=2))
