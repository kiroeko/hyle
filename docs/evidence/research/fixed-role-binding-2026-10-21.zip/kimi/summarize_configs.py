from pathlib import Path
import json,re
from collections import Counter
S=Path(__file__).resolve().parent
def short(q):
    if not q:return None
    out={k:v for k,v in q.items() if k not in ('ignore','config_groups','quantized_layers','exclude_modules','quant_cfg')}
    out['ignore_count']=len(q.get('ignore',[]));out['ignore_examples']=q.get('ignore',[])[:8]
    out['groups']={}
    for name,g in q.get('config_groups',{}).items():
        out['groups'][name]={k:v for k,v in g.items() if k!='targets'}
        out['groups'][name]['target_count']=len(g.get('targets',[]))
        out['groups'][name]['target_examples']=g.get('targets',[])[:8]
    if 'quantized_layers' in q:
        v=q['quantized_layers'];out['quantized_layers_type']=type(v).__name__
        out['quantized_layers_count']=len(v)
        out['quantized_layers_examples']=dict(list(v.items())[:3]) if isinstance(v,dict) else v[:3]
    return out
summary=[]
for i in (20,21,22,24):
    d=json.loads((S/str(i)/'config.json').read_bytes())
    q=d.get('quantization_config');n=d.get('text_config',{}).get('quantization_config')
    row=dict(artifact=i,dtype=d.get('dtype'),root=short(q),nested=short(n),root_equals_nested=q==n,
        text_geometry={k:v for k,v in d['text_config'].items() if k in ('num_hidden_layers','hidden_size','num_experts','n_routed_experts','moe_intermediate_size','intermediate_size','torch_dtype','dtype')})
    summary.append(row)
(S/'config-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps(summary,indent=2)[:16500])
