from pathlib import Path
import concurrent.futures,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('kimi_source_fetch',S/'fetch.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
jobs={21:['src/compressed_tensors/compressors/naive_quantized/base.py',
          'src/compressed_tensors/quantization/lifecycle/forward_helpers.py',
          'src/compressed_tensors/quantization/utils/helpers.py'],
      22:['src/compressed_tensors/compressors/pack_quantized/base.py',
          'src/compressed_tensors/compressors/pack_quantized/helpers.py']}
def one(row):
    i,name=row
    tree=json.loads((S/str(i)/'ct-producer-tree.json').read_bytes())
    dest=S/str(i)/'producer'/name
    if not dest.exists():
        h.fetch(f'https://raw.githubusercontent.com/vllm-project/compressed-tensors/{tree["sha"]}/{name}',dest,256*1024)
    expected=next(x['sha'] for x in tree['tree'] if x['path']==name)
    raw=dest.read_bytes();import hashlib
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==expected
    return dict(artifact=i,commit=tree['sha'],git_blob=expected,source=h.ident(dest))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(one,[(i,n) for i,names in jobs.items() for n in names]))
h.save(S/'producer-identities.json',rows)
print(json.dumps(rows,indent=2))
