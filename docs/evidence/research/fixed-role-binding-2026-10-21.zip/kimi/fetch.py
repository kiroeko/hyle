from pathlib import Path
import concurrent.futures
import hashlib
import json
import re
import shutil
import struct
import sys
import time
import urllib.request
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
ARTS={20:('nvidia/Kimi-K3-NVFP4','b2428a0b83a8b712ff2e1a8448a103d4175341f1'),
      21:('RedHatAI/Kimi-K3-FP8-BLOCK','6409c37cf440abeb76f0b44ab4fb7db8c8bccb4b'),
      22:('RedHatAI/Kimi-K3-INT4','d5048a3ba6d23dd68749ea4b84abcb66d59a07e3'),
      24:('open-inference/Kimi-K3-W4A8-K512-GPTQ-Mixed-Cal72-Seq1024','dabd12ab69bf9c71fd219bae4c49a34f00249bd2')}
def ident(p):
    p=Path(p);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def fetch(url,p,limit,first=None,last=None):
    p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.exists(),f'Keep earlier actual body: {p}'
    headers={'User-Agent':'hyle-fixed-role-read-only/1','Accept-Encoding':'identity'}
    if first is not None: headers['Range']=f'bytes={first}-{last}'
    receipt=dict(url=url,request_headers=headers,maximum_body_bytes=limit,started=time.time())
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=35) as r:
            receipt.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower() in ('content-length','content-range','content-type','etag','x-repo-commit','last-modified')})
            if first is not None:
                m=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',r.headers.get('Content-Range',''))
                assert r.status==206 and m and (int(m[1]),int(m[2]))==(first,last),receipt
                assert int(m[3])>last
                receipt['remote_file_bytes']=int(m[3])
            elif r.headers.get('Content-Length'):
                assert int(r.headers['Content-Length'])<=limit,receipt
            raw=r.read(limit+1)
            assert len(raw)<=limit,(len(raw),limit)
            if first is not None: assert len(raw)==last-first+1
        p.write_bytes(raw);receipt['body']=ident(p)
        return raw
    except Exception as error:
        receipt['error']=str(error)
        raise
    finally:
        receipt['finished']=time.time();save(p.with_suffix(p.suffix+'.http.json'),receipt)

def text(i,name,limit=2*1024*1024):
    repo,rev=ARTS[i]
    dest=S/str(i)/name
    if dest.exists(): return ident(dest)
    existing=S/'existing/qwen-kimi'/repo.replace('/','--')/name
    if existing.exists():
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(existing,dest)
        save(dest.with_suffix(dest.suffix+'.reuse.json'),dict(source=ident(existing),body=ident(dest),original_archive='docs/evidence/research/model-quantization-discovery-2026-10-19.zip',new_HTTP=False))
        return ident(dest)
    fetch(f'https://huggingface.co/{repo}/resolve/{rev}/{name}',dest,limit)
    json.loads(dest.read_bytes()) if name.endswith('.json') else None
    return ident(dest)

def header(i,name):
    repo,rev=ARTS[i]
    base=f'https://huggingface.co/{repo}/resolve/{rev}/{name}'
    out=S/str(i)/'headers'/name
    if (out/'header.json').exists(): return ident(out/'header.json')
    raw=fetch(base+'?download=true&hyle_fixed_role_range=0-7',out/'length.bin',8,0,7)
    length=struct.unpack('<Q',raw)[0];assert 2<=length<=2*1024*1024,length
    raw=fetch(base+f'?download=true&hyle_fixed_role_range=8-{7+length}',out/'header.json',length,8,7+length)
    data=json.loads(raw)
    total=json.loads((out/'length.bin.http.json').read_bytes())['remote_file_bytes']
    assert total==json.loads((out/'header.json.http.json').read_bytes())['remote_file_bytes']
    entries={k:v for k,v in data.items() if k!='__metadata__'}
    assert all(0<=v['data_offsets'][0]<=v['data_offsets'][1]<=total-8-length for v in entries.values())
    save(out/'summary.json',dict(artifact_index=i,repository=repo,revision=rev,filename=name,
        header=ident(out/'header.json'),header_length=length,remote_file_bytes=total,
        tensor_count=len(entries),tensor_payload_bytes_downloaded=0))
    return ident(out/'header.json')

if __name__=='__main__':
    jobs=[(i,'config.json',2*1024*1024) for i in ARTS]
    jobs += [(i,'model.safetensors.index.json',8*1024*1024) for i in ARTS]
    jobs += [(20,'hf_quant_config.json',2*1024*1024),(24,'artifact-manifest.json',2*1024*1024),(24,'operator-validation.json',2*1024*1024)]
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures={pool.submit(text,*row):row for row in jobs}
        for f in concurrent.futures.as_completed(futures):
            row=futures[f]
            try: result=dict(artifact=row[0],file=row[1],body=f.result())
            except Exception as error: result=dict(artifact=row[0],file=row[1],error=str(error))
            results.append(result);print(json.dumps(result),flush=True)
    save(S/'metadata-results.json',results)
