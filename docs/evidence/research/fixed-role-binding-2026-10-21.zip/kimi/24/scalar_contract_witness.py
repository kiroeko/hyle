"""Independent scalar BF16 boundaries; not a Torch/CUDA/TPU execution."""
from pathlib import Path
import json,math,struct
S=Path(__file__).resolve().parent
def u32(f):
    try:return struct.unpack('<I',struct.pack('<f',f))[0]
    except OverflowError:return 0xff800000 if f<0 else 0x7f800000
def f32(v):return struct.unpack('<f',struct.pack('<I',u32(v)))[0]
def bf_bits(v):
    raw=u32(v)
    if raw&0x7fffffff>0x7f800000:return (raw>>16)|0x40
    return ((raw+0x7fff+((raw>>16)&1))>>16)&0xffff
def from_bf(raw):return struct.unpack('<f',struct.pack('<I',raw<<16))[0]
def bf(v):return from_bf(bf_bits(v))
R=0.00787353515625
def qparams(maximum):
    scale=bf(f32(maximum*R))
    inv=0.0 if scale==0 else bf(f32(1.0/scale))
    return scale,inv
def describe(value):
    return dict(value='NaN' if math.isnan(value) else '+Inf' if value==math.inf else '-Inf' if value==-math.inf else value,
                BF16_bits=f'0x{bf_bits(value):04x}')
rows=[]
for maximum in [0.0,from_bf(1),from_bf(0x0080),1.,2.,from_bf(0x7f7f)]:
    scale,inv=qparams(maximum)
    endpoint=bf(f32(maximum*inv))
    rows.append(dict(maximum=describe(maximum),scale=describe(scale),inverse=describe(inv),endpoint=describe(endpoint),
        I8_cast_portable=math.isfinite(endpoint) and -128<=math.trunc(endpoint)<=127))
first_bad=None;first_finite_bad=None;bad=0;bad_nonfinite=0;bad_finite=0
for bits in range(1,0x7f80):
    maximum=from_bf(bits);scale,inv=qparams(maximum)
    endpoint=bf(f32(maximum*inv))
    if not math.isfinite(endpoint) or not -128<=math.trunc(endpoint)<=127:
        bad+=1
        if first_bad is None:first_bad=dict(input_bits=f'0x{bits:04x}',maximum=describe(maximum),scale=describe(scale),inverse=describe(inv),endpoint=describe(endpoint))
        if math.isfinite(endpoint):
            bad_finite+=1
            if first_finite_bad is None:first_finite_bad=dict(input_bits=f'0x{bits:04x}',maximum=describe(maximum),scale=describe(scale),inverse=describe(inv),endpoint=describe(endpoint))
        else:bad_nonfinite+=1
# A[0]=1,A[1]=2; all other group512 lanes0. Wcode[0]=1, others0;
# SF32=1. This avoids undefined I8 casts and distinguishes the runtime math.
scale,inv=qparams(2.)
code=math.trunc(bf(f32(1.*inv)))
dot=bf(float(code))
partial=bf(f32(dot*scale))
source_output=bf(f32(partial*bf(1.)))
assert code==63 and source_output==0.9921875
result=dict(scope=__doc__,constant=dict(value=R,BF16_bits=f'0x{bf_bits(R):04x}'),
    normal_counterexample=dict(A_nonzeros=[1.,2.],W_codes_nonzeros=[1],SF32=1.,group_size=512,
        scale=describe(scale),inverse=describe(inv),first_I8_code=code,
        source_W4A8_output=describe(source_output),existing_W4A16_output=describe(1.)),
    endpoint_examples=rows,
    exhaustive_positive_finite_BF16_maxima=dict(count=0x7f7f,nonportable_endpoint_count=bad,
        nonfinite_endpoint_count=bad_nonfinite,finite_out_of_I8_range_count=bad_finite,
        first_nonportable=first_bad,first_finite_out_of_range=first_finite_bad),
    warning='The source has no runtime domain guard. Non-finite/out-of-I8-range conversions are intentionally not assigned fabricated portable values; actual Torch version/platform behavior is separate.')
(S/'scalar-contract-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
