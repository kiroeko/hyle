"""K3 arithmetic, adapted from the existing GLM calibrated GPTQ builder.

Canonical export is INT32 offset-binary pack-quantized along logical K.
CUDA emulates the historical BF16 block rescale/accumulation boundaries.
"""
from dataclasses import dataclass

import torch
import triton
import triton.language as tl

RECIPROCAL_127_BF16 = 0.00787353515625


def activation_blocks(x, cols=1):
    """Yield (global K offset, signed codes, FP32 scale) for each local block."""
    x = x.to(torch.bfloat16)
    if x.shape[-1] % cols:
        raise ValueError("K must divide the four contracting shards")
    local = x.shape[-1] // cols
    for shard in range(cols):
        for start in range(shard * local, (shard + 1) * local, 512):
            end = min(start + 512, (shard + 1) * local)
            block = x[..., start:end]
            # The pinned TPU compiler lowers BF16 division by the constant 127
            # to multiplication by BF16(1/127), not a correctly rounded CUDA
            # division. Saved-weight identity probes distinguish these paths.
            scale = (block.abs().amax(-1, keepdim=True) * RECIPROCAL_127_BF16).bfloat16()
            inv = torch.where(scale == 0, 0, scale.reciprocal()).bfloat16()
            code = (block * inv).bfloat16().to(torch.int8)
            yield start, code, scale.float()


def activation_qdq(x):
    return torch.cat([q.float() * s for _, q, s in activation_blocks(x)], -1)


@dataclass
class QuantWeight:
    codes: torch.Tensor  # [N,K] int8, including logical INT4
    scales: torch.Tensor  # [N,K/group] FP32
    bits: int
    group: int

    def __call__(self, x):
        shape = x.shape[:-1]
        x = x.reshape(-1, x.shape[-1])
        k, n = x.shape[-1], self.codes.shape[0]
        result = torch.zeros(x.shape[0], n, device=x.device, dtype=torch.bfloat16)
        for start, codes, scale in activation_blocks(x):
            # CUDA int8 GEMM wants M > 16, divisible by 8; K,N divisible by 16.
            rows = codes.shape[0]
            padded = ((max(rows, 32) + 7) // 8) * 8
            operand = torch.nn.functional.pad(codes, (0, 0, 0, padded - rows)).contiguous()
            weight = self.codes[:, start:start + codes.shape[-1]].T.contiguous()
            dot = torch._int_mm(operand, weight)[:rows].bfloat16()
            ws = self.scales[:, start // self.group][None].bfloat16()
            partial = (dot * scale.bfloat16()).bfloat16()
            result = (result + (partial * ws).bfloat16()).bfloat16()
        return result.bfloat16().reshape(*shape, n)

    def tensors(self, prefix):
        assert self.bits == 4 and self.group == 512
        q = self.codes.to(torch.int64).reshape(self.codes.shape[0], -1, 8) + 8
        shifts = torch.arange(8, device=q.device, dtype=torch.int64) * 4
        packed = torch.sum(q << shifts, dim=-1).to(torch.int32)
        return {prefix + ".weight_packed": packed.cpu().contiguous(),
                prefix + ".weight_scale": self.scales.cpu().contiguous(),
                prefix + ".weight_shape": torch.tensor(self.codes.shape, dtype=torch.int64)}


@triton.jit
def _gptq_block(W, H, S, Q, E, N: tl.constexpr, K: tl.constexpr,
                START, GROUP: tl.constexpr, MAXQ: tl.constexpr,
                BLOCK: tl.constexpr = 128):
    row = tl.program_id(0)
    col = tl.arange(0, BLOCK)
    w = tl.load(W + row * K + START + col)
    scale = tl.load(S + row * tl.cdiv(K, GROUP) + START // GROUP)
    for i in range(BLOCK):
        current = tl.sum(tl.where(col == i, w, 0))
        # Match torch.round: IEEE round-to-nearest, ties-to-even.
        q = tl.minimum(tl.maximum(tl.extra.cuda.libdevice.nearbyint(current / scale), -MAXQ), MAXQ)
        diagonal = tl.load(H + (START + i) * K + START + i)
        error = (current - q * scale) / diagonal
        tl.store(Q + row * K + START + i, q.to(tl.int8))
        tl.store(E + row * BLOCK + i, error)
        h = tl.load(H + (START + i) * K + START + col)
        w = w - tl.where(col >= i, error * h, 0)


def _scales(weight, importance, maximum):
    """Activation-weighted clipping search; no BF16 scale roundtrip."""
    base = weight.abs().amax(-1) / maximum
    base = base.clamp_min(1e-30)
    importance = importance / importance.mean().clamp_min(1e-30)
    best = base.clone()
    loss = torch.full_like(best, float("inf"))
    for factor in (1., .975, .95, .925, .9, .875, .85, .825, .8):
        scale = base * factor
        for _ in range(2):
            q = (weight / scale[:, None]).round().clamp(-maximum, maximum)
            denom = (q.square() * importance).sum(-1)
            fitted = (q * weight * importance).sum(-1) / denom.clamp_min(1e-30)
            scale = torch.where(denom > 0, fitted.clamp_min(1e-30), scale)
        q = (weight / scale[:, None]).round().clamp(-maximum, maximum)
        error = ((weight - q * scale[:, None]).square() * importance).sum(-1)
        choose = error < loss
        best = torch.where(choose, scale, best)
        loss = torch.minimum(error, loss)
    return best


@torch.no_grad()
def gptq(weight, inputs, bits=4, group=512, damp=.01):
    """Full-Hessian GPTQ with 128-column error propagation blocks.

    Inputs are already activation-QDQ FP32, sampled only from calibration.
    Cross-group Hessian terms are retained. FP32 source dequantization enters
    here directly; neither source values nor final scales round through BF16.
    """
    w = weight.float().contiguous().clone()
    n, k = w.shape
    if group == -1:
        group = k
    if k % 128 or k % group or group % 128:
        raise ValueError("GPTQ group and K must align to 128")
    if inputs.ndim != 2 or inputs.shape[1] != k or inputs.shape[0] == 0:
        raise ValueError("A nonempty calibration matrix is required")
    x = inputs.float()
    h = x.T @ x / x.shape[0]
    diag = h.diagonal().clone()
    damping = max(float(diag.mean()) * damp, 1e-8)
    failures = 0
    while True:
        regularized = h.clone()
        regularized.diagonal().add_(damping)
        chol, info = torch.linalg.cholesky_ex(regularized)
        if int(info) == 0:
            hinv = torch.linalg.cholesky(torch.cholesky_inverse(chol), upper=True).contiguous()
            break
        failures += 1
        if failures > 5:
            raise RuntimeError("Hessian is not positive definite after damping")
        damping *= 10
    del h, regularized, chol
    maximum = 2 ** (bits - 1) - 1
    q = torch.empty_like(w, dtype=torch.int8)
    scales = torch.empty((n, k // group), dtype=torch.float32, device=w.device)
    error = torch.empty((n, 128), dtype=torch.float32, device=w.device)
    for start in range(0, k, 128):
        if start % group == 0:
            scales[:, start // group] = _scales(
                w[:, start:start + group], diag[start:start + group], maximum)
        _gptq_block[(n,)](w, hinv, scales, q, error, n, k, start, group, maximum,
                         num_warps=4, enable_fp_fusion=False)
        if start + 128 < k:
            w[:, start + 128:].addmm_(
                error, hinv[start:start + 128, start + 128:], beta=1., alpha=-1.)
    if not bool(torch.isfinite(scales).all()) or not bool((scales > 0).all()):
        raise RuntimeError("Invalid calibrated scale")
    return QuantWeight(q, scales, bits, group), {
        "samples": len(inputs), "damping": damping,
        "zero_importance_channels": int((diag == 0).sum()),
        "cholesky_retries": failures,
    }
