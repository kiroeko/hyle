"""Resumable K3 expert-only GPTQ, streamed through one B200.

Every layer commits weights, hashes and activation state before source removal.
The source trajectory for held-out examples never enters calibration Hessians.
"""
import argparse
import gc
import json
import os
import shutil
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from safetensors import safe_open
from safetensors.torch import save_file

from contract_ops import QuantWeight, activation_qdq, gptq
from data import prepare
from source import PREFIX, REVISION, Source, digest, event, write_json

CONTRACT = 'kimi-k3-w4a8-k512-v1'


def situ(gate, up):
    g, u = gate.float(), up.float()
    return ((4 * torch.tanh(g / 4) * torch.sigmoid(g)) * (25 * torch.tanh(u / 25))).bfloat16()


class Capture(torch.nn.Module):
    def forward(self, x):
        self.value = x.detach()
        return torch.zeros_like(x)


def attention(layer, streams):
    capture = Capture()
    original = layer.block_sparse_moe
    layer.block_sparse_moe = capture
    outputs, inputs = [], []
    try:
        for stream in streams:
            x, b = stream['hidden'].cuda(), stream['blocks'].cuda()
            length = x.shape[1]
            mask = None if layer.is_linear_attn else torch.full(
                (1, 1, length, length), float('-inf'), device='cuda', dtype=x.dtype).triu(1)
            h, blocks = layer(x, block_residual=b, attention_mask=mask)
            inputs.append(capture.value.reshape(-1, x.shape[-1]))
            outputs.append({'hidden': h.cpu(), 'blocks': blocks.cpu()})
    finally:
        layer.block_sparse_moe = original
    return outputs, torch.cat(inputs)


def dense(layer, streams):
    out = []
    for s in streams:
        x, b = s['hidden'].cuda(), s['blocks'].cuda()
        h, b = layer(x, block_residual=b)
        out.append({'hidden': h.cpu(), 'blocks': b.cpu()})
    return out


def subset(x, maximum=4096):
    if len(x) <= maximum:
        return x
    return x[torch.linspace(0, len(x) - 1, maximum, device=x.device).long()]


def relative_error(reference, candidate):
    a, b = reference.float(), candidate.float()
    return float((a - b).square().sum() / a.square().sum().clamp_min(1e-20))


def audit_projection(q, tensors, prefix):
    packed, scale = tensors[prefix + '.weight_packed'], tensors[prefix + '.weight_scale']
    if scale.dtype != torch.float32 or not bool(torch.isfinite(scale).all()) or not bool((scale > 0).all()):
        raise ValueError('Invalid scale export')
    # Same offset-binary decode as the recovered loader, compared exactly.
    shifts = torch.arange(8) * 4
    codes = (((packed.long()[..., None] >> shifts) & 15) - 8).flatten(-2).to(torch.int8)
    if not torch.equal(codes, q.codes.cpu()) or bool((codes == -8).any()):
        raise ValueError('INT4 packing round-trip failure')
    if not torch.equal(scale, q.scales.cpu()):
        raise ValueError('Scale changed at serialization')


@torch.no_grad()
def moe(source, layer, index, streams, references, samples, tensors, metrics, expert_limit=None):
    partial, x = attention(layer, streams)
    ref_partial, rx = attention(layer, references)
    m = layer.block_sparse_moe
    ids, weights = m.gate(x[None])
    rids, rweights = m.gate(rx[None])
    latent, rlatent = m.routed_expert_down_proj(x), m.routed_expert_down_proj(rx)
    calmask = torch.cat([torch.full((s['hidden'].shape[1],), sample['split'] == 'calibration',
                                    device='cuda', dtype=torch.bool) for s, sample in zip(streams, samples)])
    fallback = subset(latent[calmask])
    output = torch.zeros_like(latent, dtype=torch.float32)
    rout = torch.zeros_like(rlatent, dtype=torch.float32)
    start = time.monotonic()
    prefix = PREFIX + f'layers.{index}.block_sparse_moe.experts.'
    for e in range(m.num_experts):
        ei = prefix + str(e)
        positions, slots = torch.where(ids == e)
        rpositions, rslots = torch.where(rids == e)
        calibration_positions = positions[calmask[positions]]
        count = len(calibration_positions)
        # Unrouted experts still get activation-aware GPTQ using layer inputs.
        calibration = subset(latent[calibration_positions]) if count else fallback
        w1, w3 = source.weight(ei + '.w1'), source.weight(ei + '.w3')
        pair, gate_stats = gptq(torch.cat([w1, w3]), activation_qdq(calibration))
        n = w1.shape[0]
        gate = QuantWeight(pair.codes[:n], pair.scales[:n], 4, 512)
        up = QuantWeight(pair.codes[n:], pair.scales[n:], 4, 512)
        mid = situ(gate(calibration), up(calibration))
        w2 = source.weight(ei + '.w2')
        down, down_stats = gptq(w2, activation_qdq(mid))
        for label, q in [('w1', gate), ('w3', up), ('w2', down)]:
            exported = q.tensors(ei + '.' + label)
            audit_projection(q, exported, ei + '.' + label)
            tensors.update(exported)
        if len(positions):
            qx = latent[positions]
            value = down(situ(gate(qx), up(qx)))
            output.index_add_(0, positions, value.float() * weights[positions, slots, None])
        if len(rpositions):
            sx = rlatent[rpositions]
            value = F.linear(situ(F.linear(sx, w1.bfloat16()), F.linear(sx, w3.bfloat16())), w2.bfloat16())
            rout.index_add_(0, rpositions, value.float() * rweights[rpositions, rslots, None])
        probe = calibration[:32]
        reference = F.linear(situ(F.linear(probe, w1.bfloat16()), F.linear(probe, w3.bfloat16())), w2.bfloat16())
        candidate = down(situ(gate(probe), up(probe)))
        row = {'expert': e, 'routed_calibration_tokens': count,
               'fallback': None if count else 'shared_layer_latent_inputs_GPTQ',
               'gate_up': gate_stats, 'down': down_stats,
               'calibration_probe_output_relative_mse': relative_error(reference, candidate)}
        metrics.append(row)
        if e % 8 == 0 or e == m.num_experts - 1:
            event(event='expert_quantized', layer=index, expert=e, total_experts=m.num_experts,
                  elapsed_seconds=time.monotonic() - start, coverage=count,
                  probe_relative_mse=row['calibration_probe_output_relative_mse'])
        if expert_limit is not None and e + 1 >= expert_limit:
            return None, None
        del pair, gate, up, down, w1, w2, w3, mid
    def compose(out, hidden, partial):
        out = m.routed_expert_up_proj(m.routed_expert_norm(out.bfloat16()))
        out = out + m.shared_experts(hidden)
        offset = 0
        for p in partial:
            length = p['hidden'].shape[1]
            p['hidden'] = p['hidden'] + out[offset:offset + length][None].cpu()
            if not bool(torch.isfinite(p['hidden']).all()):
                raise ValueError('Nonfinite layer output')
            offset += length
        return partial
    return compose(output, x, partial), compose(rout, rx, ref_partial)


def save_shard(output, name, tensors):
    path = output / name
    tmp = path.with_suffix('.tmp')
    save_file(tensors, tmp, metadata={'format': 'pt', 'contract_id': CONTRACT})
    os.replace(tmp, path)
    # Verify safetensors' stored dtypes/shapes and values before source deletion.
    with safe_open(path, framework='pt', device='cpu') as f:
        if set(f.keys()) != set(tensors):
            raise ValueError('Exported tensor coverage differs')
        for k, v in tensors.items():
            loaded = f.get_tensor(k)
            if loaded.dtype != v.dtype or not torch.equal(loaded, v):
                raise ValueError(f'Serialized tensor changed: {k}')
    return {'file': name, 'sha256': digest(path), 'bytes': path.stat().st_size, 'tensors': len(tensors)}


def save_state(output, index, streams, references):
    name = f'state-{index:03d}.pt'
    tmp = output / (name + '.tmp')
    torch.save({'streams': streams, 'references': references}, tmp)
    os.replace(tmp, output / name)
    return name


def configure(source, output):
    for p in source.meta.iterdir():
        if p.is_file() and p.name not in ('config.json', 'model.safetensors.index.json', '__init__.py'):
            shutil.copy2(p, output / p.name)
    config = json.loads(json.dumps(source.config))
    quant = config['text_config']['quantization_config']
    quant['format'] = 'pack-quantized'
    group = quant['config_groups']['group_0']
    group['format'] = 'pack-quantized'
    # The TPU fused-MoE selector queries synthetic gate_proj/up_proj/down_proj
    # names even though K3 serializes the original w1/w3/w2 names.
    group['targets'] = [r're:.*\.experts\.\d+\.(w1|w2|w3|gate_proj|up_proj|down_proj)$']
    group['weights'].update(type='int', num_bits=4, group_size=512, scale_dtype='torch.float32')
    quant['ignore'] = []
    write_json(output / 'config.json', config)


@torch.no_grad()
def evaluate(source, streams, refs, samples, output):
    # Evaluate every held-out text position in bounded vocabulary batches.
    native = source.native
    with torch.device('meta'):
        norm = native.KimiRMSNorm(source.c.hidden_size, source.c.rms_norm_eps)
        resnorm = native.KimiRMSNorm(source.c.hidden_size, source.c.rms_norm_eps)
        proj = torch.nn.Linear(source.c.hidden_size, 1, bias=False)
    source.load_module(norm, PREFIX + 'norm.')
    source.load_module(resnorm, PREFIX + 'output_attn_res_norm.')
    source.load_module(proj, PREFIX + 'output_attn_res_proj.')
    head = source.raw('language_model.lm_head.weight').cuda()
    totals = dict(tokens=0, source_nll=0., quant_nll=0., kl=0., agreement=0)
    held = [(s, sample) for s, sample in zip(streams, samples) if sample['split'] == 'heldout']
    for (q, sample), r in zip(held, refs):
        def final(s):
            h = native._apply_attn_res(s['hidden'].cuda().flatten(0, 1), s['blocks'].cuda(), proj, resnorm)
            return norm(h)
        qh, rh = final(q), final(r)
        labels = torch.tensor(sample['labels'], device='cuda')[1:]
        for start in range(0, len(labels), 64):
            y = labels[start:start + 64]
            mask = y != -100
            qlogits = F.linear(qh[start:start + len(y)], head).float()[mask]
            rlogits = F.linear(rh[start:start + len(y)], head).float()[mask]
            if not len(qlogits):
                continue
            qlog, rlog = qlogits.log_softmax(-1), rlogits.log_softmax(-1)
            totals['tokens'] += len(qlog)
            totals['source_nll'] += float(F.nll_loss(rlog, y[mask], reduction='sum'))
            totals['quant_nll'] += float(F.nll_loss(qlog, y[mask], reduction='sum'))
            totals['kl'] += float((rlog.exp() * (rlog - qlog)).sum())
            totals['agreement'] += int((qlog.argmax(-1) == rlog.argmax(-1)).sum())
    write_json(output / 'heldout-quality.json', totals)
    return totals


@torch.no_grad()
def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--records', type=Path, required=True)
    p.add_argument('--stop-after-layer', type=int, default=92)
    p.add_argument('--pilot-experts', type=int)
    args = p.parse_args()
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.manual_seed(42)
    output = args.root / 'checkpoint'
    output.mkdir(exist_ok=True)
    source = Source(args.root)
    configure(source, output)
    validation_path = args.root / 'operator-validation.json'
    validation = json.loads(validation_path.read_text())
    if validation.get('source_revision') != REVISION:
        raise ValueError('TPU operator validation does not target this source')
    for name in ['w1', 'w3', 'w2', 'pallas_endpoint_codes', 'pallas_endpoint_scales']:
        if validation['metrics'][name]['equal_fraction'] != 1.0:
            raise ValueError('TPU linear/A8 probe failed: ' + name)
    if validation['metrics']['fused_situ']['relative_mse'] >= 1e-4:
        raise ValueError('SITU discrepancy exceeds the recorded operator tolerance')
    recipe = {'contract_id': CONTRACT, 'source_revision': REVISION, 'seed': 42,
              'method': 'full-Hessian GPTQ', 'damping_fraction': .01,
              'block_columns': 128, 'group_size': 512, 'maximum_hessian_samples_per_expert': 4096,
              'scale_fit': 'activation-weighted clipping search and two least-squares iterations, FP32',
              'activation_reference': 'Linear and Pallas A8 match exactly on real-expert probe; SITU FP32 CUDA versus BF16 TPU is approximate, see operator validation',
              'operator_validation_sha256': digest(validation_path),
              'builder_files': {name: digest(Path(__file__).parent / name)
                                for name in ['build.py', 'source.py', 'data.py', 'contract_ops.py']},
              'quantization_quality_status': 'unqualified'}
    if (output / 'recipe.json').exists():
        old = json.loads((output / 'recipe.json').read_text())
        if old != recipe:
            raise ValueError('Recipe or builder changed; refusing to silently resume')
    else:
        write_json(output / 'recipe.json', recipe)
    progress_path = output / 'progress.json'
    if progress_path.exists():
        progress = json.loads(progress_path.read_text())
        state = torch.load(output / progress['state'], map_location='cpu', weights_only=True)
        streams, references = state['streams'], state['references']
        samples = json.loads((output / 'calibration.json').read_text())['samples']
    else:
        streams, samples = prepare(source, args.records, output)
        references = [{'hidden': s['hidden'].clone(), 'blocks': s['blocks'].clone()}
                      for s, sample in zip(streams, samples) if sample['split'] == 'heldout']
        progress = {'completed_layer': -1, 'state': save_state(output, -1, streams, references), 'shards': [], 'weight_map': {}}
        # Immutable nonlayer shards are hard-linked, byte-preserving and space-free.
        for filename in sorted({v for k, v in source.mapping.items() if not k.startswith(PREFIX + 'layers.')}):
            path = source.ensure(filename)
            target = output / filename
            if not target.exists():
                os.link(path, target)
            progress['shards'].append({'file': filename, 'sha256': source.verified[filename], 'bytes': path.stat().st_size,
                                       'preserved_source_shard': True})
            progress['weight_map'].update({k: filename for k, v in source.mapping.items() if v == filename})
        write_json(progress_path, progress)
    for i in range(progress['completed_layer'] + 1, args.stop_after_layer + 1):
        event(event='layer_start', layer=i)
        started = time.monotonic()
        layer = source.layer(i)
        prefix = PREFIX + f'layers.{i}.'
        tensors = {k: source.raw(k).contiguous() for k in source.mapping
                   if k.startswith(prefix) and '.experts.' not in k}
        metrics = []
        if i == 0:
            streams, references = dense(layer, streams), dense(layer, references)
        else:
            streams_new, references_new = moe(source, layer, i, streams, references, samples, tensors,
                                               metrics, args.pilot_experts)
            if args.pilot_experts:
                receipt = save_shard(output, f'pilot-layer-{i:03d}.safetensors', tensors)
                write_json(output / 'pilot.json', {'receipt': receipt, 'experts': metrics,
                                                  'elapsed_seconds': time.monotonic() - started})
                event(event='pilot_complete', layer=i, experts=args.pilot_experts)
                return
            streams, references = streams_new, references_new
        receipt = save_shard(output, f'quant-layer-{i:03d}.safetensors', tensors)
        write_json(output / f'metrics-{i:03d}.json', metrics)
        previous_state = progress['state']
        progress['state'] = save_state(output, i, streams, references)
        progress['completed_layer'] = i
        progress['shards'].append(receipt)
        progress['weight_map'].update({k: receipt['file'] for k in tensors})
        write_json(progress_path, progress)
        del layer, tensors
        gc.collect()
        torch.cuda.empty_cache()
        source.release_layer(i)
        (output / previous_state).unlink(missing_ok=True)
        event(event='layer_complete', layer=i, elapsed_seconds=time.monotonic() - started)
    if progress['completed_layer'] == 92:
        quality = evaluate(source, streams, references, samples, output)
        expected = set(source.mapping)
        for k in source.mapping:
            if '.experts.' in k and k.endswith('.weight_packed'):
                expected.add(k.removesuffix('.weight_packed') + '.weight_shape')
        if set(progress['weight_map']) != expected:
            raise ValueError('Final tensor coverage mismatch')
        write_json(output / 'model.safetensors.index.json', {'metadata': {'total_size': sum(s['bytes'] for s in progress['shards'])}, 'weight_map': progress['weight_map']})
        write_json(output / 'artifact-manifest.json', {'recipe': recipe, 'shards': progress['shards'], 'quality': quality})
        write_json(output / 'COMPLETE.json', {'status': 'quantized_audited_quality_unqualified', 'source_revision': REVISION,
                                             'manifest_sha256': digest(output / 'artifact-manifest.json')})
        event(event='quantization_complete', quality=quality)


if __name__ == '__main__':
    main()
