from pathlib import Path
from collections import Counter
import json,re
S=Path(__file__).resolve().parent
rows=[]
for i in (20,21,22,24):
    for p in (S/str(i)/'headers').glob('*/header.json'):
        raw=json.loads(p.read_bytes());d={k:v for k,v in raw.items() if k!='__metadata__'}
        examples={}
        for k,v in d.items():
            if re.search(r'\.experts\.(0|895)\.w[123]\.',k) or ('.layers.0.' in k and any(t in k for t in ('.self_attn.g_proj.', '.self_attn.o_proj.','.mlp.gate_proj.','.mlp.down_proj.'))):
                examples[k]=v
        # Prefix20 begins with layer12; capture any first expert if0 absent.
        if not any('.experts.' in k for k in examples) and any('.experts.' in k for k in d):
            prefix=next(k.rsplit('.',1)[0] for k in d if '.experts.' in k)
            examples.update({k:v for k,v in d.items() if k.startswith(prefix)})
        suffixes=Counter(k.split('.experts.',1)[1].split('.',1)[1] for k in d if '.experts.' in k)
        rows.append(dict(artifact=i,file=p.parent.name,tensors=len(d),dtypes=dict(Counter(v['dtype'] for v in d.values())),
            expert_suffixes=dict(suffixes),examples=examples))
(S/'header-role-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
print(json.dumps(rows,indent=2)[:28000])
