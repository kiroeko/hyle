cmake_minimum_required(VERSION 3.25)
include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
_hyle_dependency_tree_sha256("C:/public/project-hyle/hyle/third_party/iree_vulkan_runtime" tree)
message(STATUS "HYLE_IREE_TREE=${tree}")
