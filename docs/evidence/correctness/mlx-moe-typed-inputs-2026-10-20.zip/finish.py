"""Seal CPU/CUDA ordinary MoE consumer source/inputs and honest incremental counts."""
from pathlib import Path
import importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('moe_final',S/'build.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
b,c=v.b,v.c
out=S/'checks'

def main():
    freeze=c.read(S/'source-freeze.json')
    for row in freeze['files']:
        assert b.same({k:row[k] for k in ('path','bytes','sha256')}),row
    inventory={}
    owners=[]
    for name in ('cpu-test','cuda-test','cpu-route-compile'):
        path=out/(name+'-identity.json');receipt=c.read(path)
        assert b.same(receipt['source']) and b.same(receipt['object'])
        drift=[d for d in receipt['dependencies'] if not b.same(d)]
        assert not drift,drift
        owners.append(dict(owner=name,receipt=b.identity(path),source=receipt['source'],object=receipt['object'],dependencies=len(receipt['dependencies']),current_drift=drift))
    platforms={}
    for arm in ('cpu','cuda'):
        plan=c.read(out/(arm+'-link-plan.json'))
        for row in plan['inputs']:assert b.same(row),row
        assert b.same(c.read(out/(arm+'-image.json')))
        inventory[arm]=dict(actual_inputs=plan['inputs'],command=plan['command'])
        summary=c.read(out/(arm+'-summary.json'))
        assert summary['passed'] and summary['cases']==1 and not summary['skipped']
        platforms[arm]=dict(summary,successful_submissions=8,expert_banks=[3,17],independent_slots=2,content_updates_per_slot=2,
            XML=b.identity(out/(arm+'-results.xml')),run=b.identity(out/(arm+'-tests.result.json')),
            image=c.read(out/(arm+'-image.json')),actual_link_inputs=len(plan['inputs']))
    c.save(out/'actual-link-inputs.json',inventory)
    for rel in ('src/graph/executable.cc','src/graph/resources.cc','src/graph/input_sources.cc','src/graph_batch/batch.cc',
                'src/graph/resource_episode.h','src/graph/input_sources.h','include/hyle/graph/detail/region_access.h',
                'src/graph_route_cpu/compile.cc'):
        source=v.ROOT/rel;target=S/'retained-core'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    retained=[b.identity(p) for p in sorted((S/'retained-core').rglob('*')) if p.is_file()]
    c.save(out/'closure-proof.json',dict(passed=True,owners=owners,exact_sources=b.identity(S/'source-freeze.json'),
        link_inputs=b.identity(out/'actual-link-inputs.json'),retained_core=retained,
        reused_MLX_math='Same previously tested common/CPU/CUDA MLX packed implementations; no product source edit, new native kernel, graph route, executor, or precision policy.',
        stale_cache_correction='Same full Graph and test object ceased crashing in compile after only the original source-identical graph_route_cpu/compile.cc cache owner was refreshed. Original receipt lacked complete actual source dependencies; no claim identifies a specific old inline field.',
        fixtures='Independent single-bit packed writer, original unpacked code arrays, scalar separate F32 affine roundings, double 32-term dot witnesses staged to F32, scalar SiLU/selected softmax/products/slot sum; no product intermediate used.',
        lifetime='Nine Materialize constants; original source ready leases released before runs. CUDA retains actual source/destination StorageOwner for queued copy. Owned outputs prepare resources; old GraphOutput blocks its slot, permits sibling, and survives Invocation disposal.'))
    counts=dict(distinct_test_owners=2,successful_test_CXX_jobs=12,test_source_versions=6,
        diagnostic_CXX_jobs=1,unchanged_source_cache_owner_CXX_jobs=1,total_CXX_jobs=14,
        NVCC_jobs=0,SDK_rebuilds=0,link_jobs=15,
        test_processes=dict(cpu_consumer=7,cpu_diagnostic=1,cuda_consumer=4,total=12),
        final_passed_cases=2,final_skipped=0,final_successful_submissions=16,
        explanation='Counts include incremental fixture API corrections and preserved failed attempts, not only final distinct owners. Compiler recipe argument arrays stayed identical across six test source versions; versioned source snapshots retain their different bytes. One diagnostic-only test TU and one source-identical old CPU route wrapper cache refresh; no product mathematical implementation changed.')
    history=[
        dict(version='initial-compile-crash',test_CXX=2,links=2,cpu='SEH during old cached route compile; scratch probe isolates after Case/before compile returns',cuda='not run',source_snapshot='revisions/initial-compile-crash'),
        dict(version='same-source cache correction',test_CXX=0,cache_CXX=1,links=2,cpu='compile succeeds; fixture omitted owned resources; output binding rejected',cuda='not run',source_snapshot='revisions/pre-device-io'),
        dict(version='device-IO callback seam',test_CXX=2,links=2,cpu='explicit bind message confirms prepare_resources/factory.resources requirement',cuda='not run',source_snapshot='revisions/before-resource-preparation'),
        dict(version='owned output resource preparation',test_CXX=2,links=2,cpu='full consumer green',cuda='queued Materialize correctly rejects missing ready lease + StorageOwner pair',source_snapshot='revisions/before-owned-constants'),
        dict(version='CUDA real ownership',test_CXX=2,links=2,cpu='rejects ready lease without StorageOwner; existing both-or-neither contract',cuda='full consumer green',source_snapshot='revisions/owner-lease-pair'),
        dict(version='final both-or-neither constant binding',test_CXX=2,links=2,cpu='full consumer green',cuda='full consumer green',source_snapshot='revisions/before-native-output'),
        dict(version='public output ownership',test_CXX=2,links=2,cpu='full consumer green',cuda='full consumer green',source_snapshot='after'),
        dict(version='scratch boundary diagnostic',diagnostic_CXX=1,links=1,cpu='Case succeeds, old compile crashes',source_snapshot='diagnostic_test.cc')]
    c.save(out/'incremental-counts.json',dict(counts=counts,history=history))
    result=dict(passed=True,platforms=platforms,counts=counts,
        source_freeze=b.identity(S/'source-freeze.json'),closure_proof=b.identity(out/'closure-proof.json'),
        incremental_counts=b.identity(out/'incremental-counts.json'),implementation_diff=b.identity(S/'implementation.diff'),
        limitations=['Functional complete ordinary Graph consumer only; no full GLM/model artifact, quality, or throughput acceptance.',
            'F32 activation/output with BF16 affine metadata; 5/6/4-bit group32. Other formats/precisions are not covered by this case.',
            'Final consumer does not emit selected device UUID or dispatch/peak-workspace instrumentation; root independently observes the Vulkan consumer.',
            'Apple full MoE not tested. New Apple layout-only verification is a separate journey.'])
    c.save(out/'final-validation.json',result)
    print(json.dumps(dict(final=b.identity(out/'final-validation.json'),freeze=b.identity(S/'source-freeze.json'),counts=counts),indent=2),flush=True)

if __name__=='__main__':main()
