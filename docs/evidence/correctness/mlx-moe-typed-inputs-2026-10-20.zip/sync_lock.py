"""Refresh the changed local IREE adapter using existing canonical CMake hashes."""
import importlib.util
import os
import re
import shutil
import sys
from pathlib import Path
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('typed_mlx_lock', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'lock'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
path = ROOT/'cmake/HyleDependencyLock.json'
before = out/'HyleDependencyLock.before.json'
assert not before.exists()
before.write_bytes(path.read_bytes())
text = path.read_text(encoding='utf-8')

def visit(value):
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from visit(item)
    elif isinstance(value, list):
        for item in value:
            yield from visit(item)

row, = [row for row in visit(c.read(path)) if row.get('name') == 'iree_vulkan_runtime_patches']
cmake = ROOT/'cmake/HyleDependencyVersions.cmake'
script = out/'canonical.cmake'
script.write_text('cmake_minimum_required(VERSION 3.25)\ninclude("'+cmake.as_posix()+'")\n'
    '_hyle_dependency_tree_sha256("'+(ROOT/row['vendored']['path']).as_posix()+'" tree)\n'
    'message(STATUS "HYLE_IREE_TREE=${tree}")\n', encoding='utf-8')
env = dict(os.environ, TEMP=str(out/'tmp'), TMP=str(out/'tmp'))
c.execute('canonical-hash', [shutil.which('cmake'), '-P', str(script)], env, out)
match = re.search(r'HYLE_IREE_TREE=([0-9a-f]{64})', (out/'canonical-hash.stdout.log').read_text())
assert match
old, new = row['vendored']['tree_sha256'], match.group(1)
assert old != new and text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
verify = out/'verify.cmake'
verify.write_text('cmake_minimum_required(VERSION 3.25)\ninclude("'+cmake.as_posix()+'")\n'
    'hyle_audit_in_tree_dependencies(iree_vulkan_runtime_patches)\n', encoding='utf-8')
c.execute('canonical-verify', [shutil.which('cmake'), '-P', str(verify)], env, out)
c.save(out/'summary.json', dict(passed=True, before=b.identity(before), after=b.identity(path),
    dependency='iree_vulkan_runtime_patches', old_tree=old, new_tree=new,
    changed_fields=1, upstream_revision_changed=False, SDK_rebuilt=False))
print('IREE_LOCAL_TYPED_LOCK_VERIFIED', new, flush=True)
