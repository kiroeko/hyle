"""Run the single focused consumer from an existing current image."""
import importlib.util,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('moe_run_current',S/'build.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
b,c=v.b,v.c
arm=sys.argv[1];out=S/'checks';plan=c.read(out/(arm+'-link-plan.json'))
for row in plan['inputs']:assert b.same(row),row
for row in c.read(S/'source-freeze.json')['files']:
 assert b.same({k:row[k] for k in ('path','bytes','sha256')}),row
assert b.same(c.read(out/(arm+'-image.json')))
env,_=b.environment(plan['command'],[x['path'] for x in plan['inputs']],out)
image=out/(arm+'.exe');xml=out/(arm+'-results.xml')
try:c.execute(arm+'-tests',[str(image),'--gtest_filter='+v.FILTERS[arm],'--gtest_output=xml:'+str(xml)],env,out)
except RuntimeError:pass
cases=ET.parse(xml).findall('.//testcase') if xml.exists() else []
failed=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('failure')]
skipped=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('skipped')]
summary=dict(passed=len(cases)==1 and not failed and not skipped and c.read(out/(arm+'-tests.result.json'))['exit']==0,cases=len(cases),failures=failed,skipped=skipped,domains='E3/E17, each two slots and two A/logits updates; 8 submissions total; final output only.')
c.save(out/(arm+'-summary.json'),summary);print(summary,flush=True)
platforms={p:c.read(out/(p+'-summary.json')) for p in ('cpu','cuda') if (out/(p+'-summary.json')).exists()}
c.save(out/'summary.json',dict(passed=all(r['passed'] for r in platforms.values()),platforms=platforms,product_source_changes=False,test_owners=2,cache_owner_CXX=1,diagnostic_CXX=1,SDK_rebuild=False,NVCC=0))
if not summary['passed']:raise SystemExit(1)
