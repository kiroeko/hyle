from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('moe_build_diagnostic',S/'build.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
b,c=v.b,v.c
out=S/'diagnostic';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
base=c.read(S/'checks/cpu-link-plan.json');recipe=c.read(S/'checks/cpu-test-identity.json')
source=S/'diagnostic_test.cc';command=b.host_command(recipe['command'],source,'probe',out)
env,_=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
c.save(out/'source.json',b.identity(source));c.execute('compile',command,env,out)
deps=c.read(out/'probe-deps.json')['Data'];c.save(out/'identity.json',dict(command=command,source=b.identity(source),object=b.identity(out/'probe.obj'),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
image=out/'probe.exe';command=[arg for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]+[str(out/'probe.obj'),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map'))]
c.save(out/'link-plan.json',dict(command=command,inputs=base['inputs']+[b.identity(out/'probe.obj')]))
c.execute('link',command,env,out)
c.execute('tests',[str(image),'--gtest_filter=MlxMoeDiagnostic.*','--gtest_output=xml:'+str(out/'results.xml')],env,out)
