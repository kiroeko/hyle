"""Compile two existing test owners and link retained current CPU/CUDA closures."""
from pathlib import Path
import concurrent.futures
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('mlx_moe_host', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASES = dict(cpu=A/'layout-binding-lifetime/checks/link-plan.json',
    cuda=A/'layout-binding-lifetime/cuda/link-plan.json')
SOURCES = dict(cpu=ROOT/'tests/compute_route_cpu/cpu_mlx_quantized_test.cc',
    cuda=ROOT/'tests/compute_provider_torch_cuda/mlx_precision_test.cc')
FILTERS = dict(cpu='CpuMlxQuantizedGraph.MixedBitMoeKeepsTypedMetadataAndIndependentSlots',
    cuda='CudaMlxMoeGraph.MixedBitMoeKeepsTypedMetadataAndIndependentSlots')

def main():
    out = S/'checks'
    out.mkdir(exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    plans = {arm:c.read(path) for arm,path in BASES.items()}
    meta = h.metadata(plans)
    freeze = c.read(S/'source-freeze.json')
    def check():
        for row in freeze['files']:
            assert b.same({k:row[k] for k in ('path','bytes','sha256')}), row
    check()
    rows, environments = {}, {}
    for arm, base in plans.items():
        candidates = []
        for old in base['inputs']:
            assert b.same(old), old
            recipe = meta.get(c.key(old['path']))
            if not recipe or c.key(recipe['source_path']) != c.key(SOURCES[arm]):
                continue
            if arm == 'cpu' and not any('HYLE_TEST_GRAPH_ROUTE_CPU' in arg for arg in recipe['command']):
                continue
            candidates.append((old, recipe))
        assert len(candidates) == 1, (arm, candidates)
        old, recipe = candidates[0]
        tag = arm+'-test'
        rows[arm] = dict(tag=tag, source=b.identity(SOURCES[arm]), old_object=old,
            object=str(out/(tag+'.obj')), recipe=recipe['recipe'],
            command=b.host_command(recipe['command'], SOURCES[arm], tag, out))
        environments[arm], runtime = b.environment(base['command'], [x['path'] for x in base['inputs']], out)
        c.save(out/(arm+'-runtime.json'), dict(runtime=runtime, PATH=environments[arm]['PATH']))
    c.save(out/'plan.json', dict(bases={arm:b.identity(path) for arm,path in BASES.items()},
        rows=rows, product_CXX=0, test_CXX=2, NVCC=0, SDK_rebuild=False))
    print('MLX_MOE_PLAN', {arm:row['recipe'] for arm,row in rows.items()}, flush=True)
    if '--build' not in sys.argv:
        return
    def compile_one(arm):
        row = rows[arm]
        receipt = out/(row['tag']+'-identity.json')
        if receipt.exists():
            previous = c.read(receipt)
            if previous['command'] == row['command'] and b.same(previous['object']) and all(b.same(d) for d in previous['dependencies']):
                return arm, previous
        check()
        c.execute(row['tag']+'-compile', row['command'], environments[arm], out)
        check()
        deps = c.read(out/(row['tag']+'-deps.json'))['Data']
        result = dict(source=row['source'], command=row['command'], object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
        c.save(receipt, result)
        return arm, result
    compiled, errors = {}, []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one, arm) for arm in rows]):
            try:
                arm, receipt = future.result()
                compiled[arm] = receipt
            except Exception as error:
                errors.append(repr(error))
    c.save(out/'compile-summary.json', dict(passed=not errors, errors=errors, product_CXX=0,
        test_CXX=2, NVCC=0, SDK_rebuild=False))
    if errors:
        raise RuntimeError(errors)
    for arm, base in plans.items():
        old = c.key(rows[arm]['old_object']['path'])
        replacement = compiled[arm]['object']
        inputs = [replacement if c.key(row['path']) == old else row for row in base['inputs']]
        command = [replacement['path'] if c.key(arg) == old else arg for arg in base['command']
            if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out/(arm+'.exe')
        command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
        for row in inputs:
            assert b.same(row), row
        check()
        c.save(out/(arm+'-link-plan.json'), dict(command=command, inputs=inputs))
        c.execute(arm+'-link', command, environments[arm], out)
        c.save(out/(arm+'-image.json'), b.identity(image))
    if '--test' not in sys.argv:
        return
    summaries = {}
    for arm in plans:
        if '--cpu-only' in sys.argv and arm != 'cpu':
            continue
        check()
        image = out/(arm+'.exe')
        xml = out/(arm+'-results.xml')
        command = [str(image), '--gtest_filter='+FILTERS[arm], '--gtest_output=xml:'+str(xml)]
        try:
            c.execute(arm+'-tests', command, environments[arm], out)
        except RuntimeError:
            pass
        if xml.is_file():
            cases = ET.parse(xml).findall('.//testcase')
            failed = [x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('failure')]
            skipped = [x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('skipped')]
            summary = dict(passed=len(cases)==1 and not failed and not skipped and c.read(out/(arm+'-tests.result.json'))['exit']==0,
                cases=len(cases), failures=failed, skipped=skipped,
                domains='E3/E17, each two slots and two A/logits updates; 8 submissions total; final output only.')
        else:
            summary = dict(passed=False, XML_missing=True, result=c.read(out/(arm+'-tests.result.json')))
        c.save(out/(arm+'-summary.json'), summary)
        summaries[arm] = summary
    c.save(out/'summary.json', dict(passed=all(row['passed'] for row in summaries.values()), platforms=summaries,
        product_CXX=0, test_CXX=2, links=2, NVCC=0, SDK_rebuild=False))
    print('MLX_MOE_RESULTS', json.dumps(summaries), flush=True)
    if not all(row['passed'] for row in summaries.values()):
        raise SystemExit(1)

if __name__ == '__main__':
    main()
