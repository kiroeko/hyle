from pathlib import Path
import base64,hashlib,json,re,subprocess
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;A=OUT.parents[1];OLD=A/'batch-query-extent/delegated/apple'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/mlx-moe-typed-inputs/apple-layout-verification'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def ssh(code,payload):
 encoded=base64.b64encode(code.encode()).decode();argv=['ssh','kiro@172.22.10.198',"python3 -c \"import base64;exec(base64.b64decode('"+encoded+"'))\""]
 result=subprocess.run(argv,input=json.dumps(payload).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (OUT/'sync.stdout.log').write_bytes(result.stdout);(OUT/'sync.stderr.log').write_bytes(result.stderr)
 if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace')+'\n'+result.stdout.decode(errors='replace'))
 return json.loads(result.stdout)
old=json.loads((OLD/'results/summary.json').read_text(encoding='utf-8'))['compiles'];byrel={r['source']:r for r in old}
rels=['src/graph/executable.cc','src/graph/resources.cc','src/graph/input_sources.cc','src/graph_batch/batch.cc','tests/graph_batch/native_ragged_attention_test.cc']
rows=[dict(source=rel,recipe=byrel[rel]['argv'],old_object=byrel[rel]['object']) for rel in rels]
search=[ROOT,ROOT/'include',*[p for p in (ROOT/'src').iterdir() if p.is_dir()],*[p for p in (ROOT/'third_party').iterdir() if p.is_dir()]]
include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M);seen=set()
def visit(path):
 path=path.resolve()
 if not path.is_relative_to(ROOT) or path in seen or not path.is_file():return
 seen.add(path)
 if path.suffix not in ['.h','.hh','.hpp','.cc','.mm','.inc','.inl']:return
 for inc in include.findall(path.read_text(encoding='utf-8',errors='replace')):
  q=next((p for p in [path.parent/inc,*[base/inc for base in search]] if p.is_file()),None)
  if q is not None:visit(q)
for row in rows:visit(ROOT/row['source'])
files=[]
for p in sorted(seen):
 data=p.read_bytes();files.append(dict(path=p.relative_to(ROOT).as_posix(),bytes=len(data),sha256=sha(data),data=base64.b64encode(data).decode()))
for rel in [*rels,'src/graph/plan_state.h','src/graph/input_sources.h','src/graph/resource_episode.h','include/hyle/graph/detail/region_access.h']:
 assert any(r['path']==rel for r in files),rel
manifest=[{k:v for k,v in row.items() if k!='data'} for row in files];save('source-manifest.json',manifest)
BASE=A/'mlx-grouped-shared-activation/apple-verification/remote/results'
link=json.loads((BASE/'link.json').read_text(encoding='utf-8'))['argv'];inputs=json.loads((BASE/'link-inputs.json').read_text(encoding='utf-8'))
plan=dict(remote=REMOTE,files=files,compile=rows,link=link,inputs=inputs,metallib='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib')
save('plan.json',{k:v for k,v in plan.items() if k!='files'})
code="""from pathlib import Path
import base64,json,sys,hashlib,subprocess
p=json.load(sys.stdin);root=Path(p['remote']);root.mkdir(parents=True,exist_ok=True)
for row in p['files']:
 b=base64.b64decode(row['data']);assert hashlib.sha256(b).hexdigest()==row['sha256'];f=root/row['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
(root/'source-manifest.json').write_text(json.dumps([{k:v for k,v in row.items()if k!='data'}for row in p['files']],indent=2)+'\\n')
(root/'plan.json').write_text(json.dumps({k:v for k,v in p.items()if k!='files'},indent=2)+'\\n')
inputs=[]
for row in p['inputs']:
 f=Path(row['path']);got=hashlib.sha256(f.read_bytes()).hexdigest();assert got==row['sha256'],row['path'];inputs.append(row)
hardware={key:subprocess.check_output(argv,text=True).strip() for key,argv in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version']}.items()};assert hardware['model']=='Mac16,12'
(root/'hardware.json').write_text(json.dumps(hardware,indent=2)+'\\n');(root/'baseline-inputs.json').write_text(json.dumps(inputs,indent=2)+'\\n')
print(json.dumps(dict(remote=str(root),files=len(p['files']),bytes=sum(row['bytes']for row in p['files']),actual_cached_inputs=len(inputs),hardware=hardware)))
"""
save('sync.json',ssh(code,plan));print(json.dumps(json.loads((OUT/'sync.json').read_text(encoding='utf-8')),indent=2))
