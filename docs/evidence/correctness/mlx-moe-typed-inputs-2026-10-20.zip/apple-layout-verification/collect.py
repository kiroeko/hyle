from pathlib import Path
import json,base64,subprocess,hashlib
OUT=Path(__file__).resolve().parent;remote=json.loads((OUT/'plan.json').read_text(encoding='utf-8'))['remote']
code="""from pathlib import Path
import json,base64,hashlib
root=Path('"""+remote+"""');files=[]
paths=[root/name for name in ['source-manifest.json','plan.json','hardware.json','baseline-inputs.json','build.py']]+[p for p in (root/'results').rglob('*')if p.is_file()and p.suffix in ['.json','.log','.xml']]+list((root/'objects').glob('*.d'))
manifest=json.loads((root/'source-manifest.json').read_text())
paths += [root/row['path']for row in manifest]
for p in paths:
 b=p.read_bytes();rel=p.relative_to(root).as_posix()
 if rel in [r['path']for r in manifest]:rel='source/'+rel
 files.append(dict(path=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
print(json.dumps(dict(files=files)))
"""
encoded=base64.b64encode(code.encode()).decode();result=subprocess.run(['ssh','kiro@172.22.10.198',"python3 -c \"import base64;exec(base64.b64decode('"+encoded+"'))\""],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace'))
entries=json.loads(result.stdout)['files'];identities=[]
for row in entries:
 b=base64.b64decode(row['data']);assert hashlib.sha256(b).hexdigest()==row['sha256'];p=OUT/'remote'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);identities.append({k:v for k,v in row.items()if k!='data'})
(OUT/'collected.json').write_text(json.dumps(dict(remote=remote,files=identities,excluded=['objects','executables','maps','SDK','metallib payload']),indent=2)+'\n',encoding='utf-8')
summary=json.loads((OUT/'remote/results/summary.json').read_text());print(json.dumps(dict(files=len(identities),bytes=sum(row['bytes']for row in identities),summary=summary),indent=2))
