"""Keep the typed-bank fix and complete consumer evidence without build payloads."""
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def xml(path):
    cases = ET.parse(path).findall('.//testcase')
    return dict(cases=len(cases), failures=sum(bool(x.findall('failure')) for x in cases),
        skipped=sum(bool(x.findall('skipped')) for x in cases), identity=identity(path))


def main():
    reports = dict(consumer=S/'checks/final-validation.json',
        vulkan=S/'vulkan/final-validation.json', apple_layout=S/'apple-layout-verification/final-validation.json')
    actual = {name: read(path) for name, path in reports.items()}
    assert actual['consumer']['passed'] and actual['apple_layout']['passed']
    greens = set()
    for run in actual['vulkan']['runs']:
        if run['phase'].startswith('final'):
            assert run['summary']['passed']
        path = Path(run['summary']['xml']['path'])
        assert identity(path)['sha256'] == run['summary']['xml']['sha256']
        for case in ET.parse(path).findall('.//testcase'):
            assert not case.findall('skipped')
            if not case.findall('failure'):
                greens.add((case.attrib['classname'], case.attrib['name']))
    assert len(greens) == 14
    old = xml(S/'reproduction/results.xml')
    assert old['cases'] == old['failures'] == 1 and old['skipped'] == 0
    for name in ('cpu', 'cuda'):
        row = xml(S/f'checks/{name}-results.xml')
        assert row['cases'] == 1 and row['failures'] == row['skipped'] == 0
    for name in ('source-freeze.json', 'vulkan/source-freeze.json', 'vulkan/tests-source-freeze.json'):
        for row in read(S/name)['files']:
            path = Path(row['path'])
            if not path.is_absolute():
                path = ROOT/path
            proof = identity(path)
            assert proof['bytes'] == row['bytes'] and proof['sha256'] == row['sha256'], path
    assert read(S/'lock/summary.json')['passed']
    reuse = read(S/'vulkan/native-kernel-reuse.json')
    assert reuse['all_names_identical'] and reuse['all_bytes_identical']
    snapshots = []
    for rel in ('cmake/HyleDependencyLock.json', 'docs/implementation/model-operators.md',
                'docs/architecture/compute-design.md', 'docs/developer/current-work.md'):
        target = S/'snapshot'/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT/rel).read_bytes())
        snapshots.append(dict(relative=rel, source=identity(ROOT/rel), snapshot=identity(target)))
    save(S/'snapshot-manifest.json', snapshots)
    suffixes = {'.py', '.cc', '.h', '.mm', '.inc', '.json', '.log', '.xml', '.diff', '.md',
                '.cmake', '.txt', '.mlir', '.b64', '.vmfb', '.spv'}
    files = sorted((p for p in S.rglob('*') if p.is_file() and p.suffix in suffixes and
        not set(p.relative_to(S).parts) & {'tmp', '__pycache__'} and
        p.name not in {'publication.json', 'payload-sha256.json', 'cleanup-plan.json', 'cleanup-executed.json'}),
        key=lambda p: p.relative_to(S).as_posix())
    dest = ROOT/'docs/evidence/correctness/mlx-moe-typed-inputs-2026-10-20.zip'
    payloads = []
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            row = dict(**identity(path), member=path.relative_to(S).as_posix())
            archive.writestr(row['member'], path.read_bytes())
            payloads.append(row)
        archive.writestr('payload-sha256.json', json.dumps(payloads, ensure_ascii=False).encode())
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        assert all(hashlib.sha256(archive.read(row['member'])).hexdigest() == row['sha256'] for row in payloads)
    report = dict(date='2026-10-20', status='typed_affine_inputs_and_complete_MoE_consumer_executed',
        problem='Vulkan affine mixed inputs were promoted as full activation/scale/bias arrays at replay. Unselected expert metadata was widened too.',
        behavior='Original typed inputs feed offline native affine programs; only selected elements widen for the original F32 decode and grouped dot/sum. Public operation and promotion rules are unchanged.',
        original_bank_widening=dict(old_E3_bytes=96, old_E17_bytes=544, updated_bytes=0,
            observation='Logical additional F32 scale/bias banks with fixed selected IDs. This is not whole-process peak memory or timing.', old=old),
        implementation=dict(private_ABI='ProgramSpecV4 adds actual activation type; scale_type retains actual metadata type. Actual private owners refreshed.',
            offline_exports=33, original_exports=21, new_mixed_exports=12,
            native_SPIRV_byte_identical=reuse['raw_SPIRV_modules'], SDK_rebuilt=False,
            public_operations_added=0, executors_added=0, user_policies_added=0),
        actual={name: dict(summary=identity(path), report=actual[name]) for name, path in reports.items()},
        common_consumer=dict(shape='T2/S3/H64/F64, E3 and E17',
            chain='TopK -> selected Softmax -> affine5 gate/affine6 up -> ordinary SiLU/Mul -> affine4 down -> route weighting/slot sum -> final output only',
            precision='F32 activation/output; BF16 scale/bias; independent staged scalar oracle, original fixed tolerance.',
            ownership='Public output_ownership selects caller writer or invocation-owned result; no Provider branch. Source constants and executable handle are dropped; independent slots and retained results preserve original lifetime gates.'),
        diagnostics=['Initial CPU stale convenience wrapper used old by-value CompileOptions ABI; only its original owner was rebuilt.',
            'Initial fixtures omitted resource preparation, then violated queued constant owner/lease pairing, then assumed caller-owned output. Rejections, crash observation, source revisions and full actual build counts are retained. Product checks were not weakened.'],
        limitations=['Complete synthetic MoE is executed on Windows CPU/CUDA/Vulkan, not a whole selected model artifact or quality/performance acceptance.',
            'Apple in this batch verifies only the separate common layout lifecycle journey; no Apple full MoE or new Linux execution.',
            'Removing F32 promotion does not eliminate per-Invocation original-type IREE bank copies. Immutable native bank reuse remains a concrete next issue.',
            'No new Qwen/llama throughput, kernel-count or peak-memory comparison.'],
        archive=dict(**identity(dest), payloads=len(payloads), CRC_checked=True, all_payload_SHA256_checked=True))
    save(dest.with_suffix('.json'), report)
    save(S/'publication.json', dict(passed=True, report=identity(dest.with_suffix('.json')), archive=identity(dest)))
    print('MLX_MOE_EVIDENCE_PUBLISHED', len(payloads), dest.stat().st_size, flush=True)


if __name__ == '__main__':
    main()
