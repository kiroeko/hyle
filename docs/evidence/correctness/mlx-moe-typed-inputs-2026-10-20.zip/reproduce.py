"""Use the actual pre-change V3 native closure for the typed-bank witness."""
import importlib.util
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('mlx_typed_old', A/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
old = A/'mlx-grouped-shared-activation/apple-vulkan/test-checks'
base = c.read(old/'link-plan.json')
recipe = c.read(old/'compute_route_vulkan-iree-test-identity.json')
out = S/'reproduction'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
source = ROOT/'tests/compute_route_vulkan/iree_test.cc'
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
for row in base['inputs']:
    assert b.same(row), row['path']
command = b.host_command(recipe['command'], source, 'vulkan-test', out)
c.execute('vulkan-test-compile', command, env, out)
deps = c.read(out/'vulkan-test-deps.json')['Data']
fresh = dict(command=command, source=b.identity(source), object=b.identity(out/'vulkan-test.obj'),
    dependencies=[b.identity(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])])
c.save(out/'vulkan-test-identity.json', fresh)
key = c.key(recipe['object']['path'])
assert sum(c.key(row['path']) == key for row in base['inputs']) == 1
image = out/'before.exe'
command = [fresh['object']['path'] if c.key(arg) == key else arg for arg in base['command']
    if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs = [fresh['object'] if c.key(row['path']) == key else row for row in base['inputs']]
c.save(out/'link-plan.json', dict(command=command, inputs=inputs))
c.execute('link', command, env, out)
c.save(out/'image.json', b.identity(image))
command = [str(image), '--gtest_filter=VulkanIree.MixedMlxGroupedKeepsOriginalTypedBanksAcrossExpertCounts',
    '--gtest_output=xml:'+str(out/'results.xml')]
try:
    c.execute('tests', command, env, out)
except RuntimeError:
    pass
cases = ET.parse(out/'results.xml').findall('.//testcase')
summary = dict(cases=len(cases), failed=sum(bool(case.findall('failure')) for case in cases),
    skipped=sum(bool(case.findall('skipped')) for case in cases),
    properties={p.attrib['name']:p.attrib['value'] for p in ET.parse(out/'results.xml').findall('.//property')},
    exit=c.read(out/'tests.result.json')['exit'],
    scope='Actual pre-change V3 grouped mixed affine. Structural full-bank promotion invariant is red; exact selected-expert native outputs are checked independently.')
c.save(out/'summary.json', summary)
assert summary['cases'] == summary['failed'] == 1 and summary['skipped'] == 0 and summary['exit'] != 0
print('MLX_TYPED_BANK_OLD_RED', summary, flush=True)
