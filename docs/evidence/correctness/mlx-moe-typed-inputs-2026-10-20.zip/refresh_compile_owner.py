from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('moe_cached_compile',S/'build.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
b,c=v.b,v.c
out=S/'checks';base=c.read(v.BASES['cpu'])
record=c.read(S/'diagnostic/compile-owner-inventory.json')[0]
source=Path(record['source_path']);tag='cpu-route-compile'
command=b.host_command(record['command'],source,tag,out)
env,_=b.environment(base['command'],[x['path'] for x in base['inputs']],out)
c.save(out/'cache-refresh-before.json',dict(owner=record,source=b.identity(source),reason='Actual new full Graph reaches old route compile wrapper not exercised by prior leaf tests; original has no complete dependency receipt. Preserve original compile-only crash.'))
c.execute(tag+'-compile',command,env,out)
dep=c.read(out/(tag+'-deps.json'))['Data'];identity=dict(source=b.identity(source),object=b.identity(out/(tag+'.obj')),command=command,dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])])
c.save(out/(tag+'-identity.json'),identity)
c.save(out/'extra-owners.json',[dict(old_object=record['object'],receipt=b.identity(out/(tag+'-identity.json')),replacement=identity['object'])])
