#include <cstdio>
#include <gtest/gtest.h>
#include "tests/compute_models/mlx_moe_fixture.h"
#include "hyle/graph/cpu.h"
TEST(MlxMoeDiagnostic, ConstructionAndCompile) {
  namespace f=mlx_moe_test;
  std::fprintf(stderr,"MOE before context\n");std::fflush(stderr);
  auto context=hyle::graph::cpu::create_context().value();
  std::fprintf(stderr,"MOE before Case\n");std::fflush(stderr);
  f::Case data(3);
  std::fprintf(stderr,"MOE after Case\n");std::fflush(stderr);
  std::array<hyle::mem::Buffer,9> source;
  std::array<hyle::graph::ConstantBinding,9> constants;
  for(std::size_t bank=0;bank<3;++bank)for(std::size_t port=0;port<3;++port){
    const auto i=bank*3+port;
    const auto &payload=data.banks[bank].payloads[port];
    source[i]=hyle::mem::Buffer::create(hyle::mem::system_resource(),payload.size(),256).value();
    ASSERT_TRUE(source[i].view().write(payload).ok());
    constants[i]={data.constants[i],hyle::compute::ConstTensorView::create(data.banks[bank].descriptions[port],source[i].view()).value(),hyle::graph::ConstantPolicy::kMaterialize};
  }
  std::fprintf(stderr,"MOE before compile\n");std::fflush(stderr);
  auto compiled=hyle::graph::cpu::compile(data.graph,context,{.constants=constants});
  std::fprintf(stderr,"MOE after compile ok=%d\n",int(bool(compiled)));std::fflush(stderr);
  ASSERT_TRUE(compiled)<<compiled.error().message();
  std::fprintf(stderr,"MOE before slot0\n");std::fflush(stderr);
  auto first=compiled->executable.create_invocation();
  std::fprintf(stderr,"MOE after slot0 ok=%d\n",int(bool(first)));std::fflush(stderr);
  ASSERT_TRUE(first)<<first.error().message();
  auto second=compiled->executable.create_invocation();
  std::fprintf(stderr,"MOE after slot1 ok=%d\n",int(bool(second)));std::fflush(stderr);
  ASSERT_TRUE(second)<<second.error().message();
}
