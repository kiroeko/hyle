"""Incremental V4 private closure; cached SDK, deferred existing test owners."""
from pathlib import Path
import concurrent.futures,importlib.util,sys,json,base64,hashlib
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];ROOT=A.parents[1];out=S/'checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('mlx_v4_build_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
spec=importlib.util.spec_from_file_location('mlx_v4_canonical_helpers',A/'batch-query-extent/vulkan/build.py');previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
inv=c.read(S/'abi-owner-inventory.json');basepath=Path(inv['base_path']);base=c.read(basepath);metadata=h.metadata({'vulkan':base})
for obj in base['inputs']:assert h.same_identity(obj),obj['path']
frozen=[b.identity(S/'source-freeze.json'),*[b.identity(ROOT/r['path'])for r in c.read(S/'source-freeze.json')['files']]]
for row in c.read(S/'source-freeze.json')['files']:assert b.identity(ROOT/row['path'])['sha256']==row['sha256'],row['path']
prepare=ROOT/'src/compute_provider_iree_vulkan/prepare_source.py';text=prepare.read_text();start=text.index('    programs = json.loads(');end=text.index('    print(f"IREE source:',start)
gen=dict(json=json,base64=base64,sha=lambda d:hashlib.sha256(d).hexdigest(),vendor=ROOT/'third_party/iree_vulkan_runtime',generated=out/'generated');gen['generated'].mkdir(exist_ok=True)
exec('\n'.join(line[4:]if line.startswith('    ')else line for line in text[start:end].splitlines()),gen)
generated=out/'generated/programs.cc';c.save(out/'embedded-generation.json',dict(method='Exact unchanged prepare_source.py embedding block only; no source/SDK preparation',recipe=b.identity(prepare),source=b.identity(generated)))
selected={c.key(row['object']['path']):row['owner']for row in inv['private_ABI_owners']if Path(row['source']).is_relative_to(ROOT/'src')}
for row in inv['generated_program_owners']:selected[c.key(row['object']['path'])]=row['owner']
common=['src/graph/executable.cc','src/graph/resources.cc','src/graph/input_sources.cc','src/graph_batch/batch.cc','src/compute/custom_kernel.cc'];wanted={c.key(ROOT/p)for p in common}
for obj in base['inputs']:
 rec=metadata.get(c.key(obj['path']))
 if rec and c.key(rec['source_path'])in wanted:selected[c.key(obj['path'])]=rec
cache={}
for stem in ['graph-executable','graph-resources','graph-input_sources','graph_batch-batch','compute-custom_kernel']:
 path=A/'layout-binding-lifetime/checks'/(stem+'-identity.json');r=c.read(path);cache[c.key(r['source']['path'])]=(path,r)
lookup={c.key(obj['path']):obj for obj in base['inputs']};rows=[];reused=[];replacements={}
for key,rec in selected.items():
 source=Path(rec['source_path']);source=generated if source.name=='programs.cc'else source
 old=lookup[key];candidate=cache.get(c.key(source))
 if candidate:
  path,r=candidate
  if previous.canonical(rec['command'],source)==previous.canonical(r['command'],source)and h.same_identity(r['source'])and h.same_identity(r['object'])and all(h.same_identity(d)for d in r['dependencies']):
   replacements[key]=r['object'];reused.append(dict(source=r['source'],object=r['object'],recipe=b.identity(path),canonical_commands_equal=True,all_dependency_hashes_match=True));continue
 tag=source.parent.name+'-'+source.stem;tag='embedded-programs'if source==generated else tag
 command=b.host_command(rec['command'],source,tag,out)
 rows.append(dict(tag=tag,source=b.identity(source),recipe=rec['recipe'],command=command,old_object=old,object=str(out/(tag+'.obj'))))
deferred=[]
for obj in base['inputs']:
 rec=metadata.get(c.key(obj['path']))
 if not rec:continue
 source=Path(rec['source_path'])
 if source.is_relative_to(ROOT/'tests')and(source.name=='iree_test.cc'or source.name=='native_ragged_attention_test.cc'):
  deferred.append(dict(old_object=obj,owner=rec))
c.save(out/'plan.json',dict(base=b.identity(basepath),products=rows,reused_current_common=reused,deferred_test_owners=deferred,frozen=frozen,private_product_owners=23,generated_owners=1,SDK_rebuilt=False,GPU_runs=0,scope='Refresh actual V4 SourceDeps owners, embedded program and current layout lifecycle/custom provider owners only; retained backend/SDK inputs checked by object/library hash, not whole-tree freshness.'))
print('PLAN',len(rows),'CXX_PRODUCTS',len(reused),'CURRENT_COMMON_REUSED',len(deferred),'TEST_OWNERS_DEFERRED',flush=True)
env,runtime=b.environment(base['command'],[r['path']for r in base['inputs']],out);env['PYTHONDONTWRITEBYTECODE']='1';c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
def frozen_check():
 for row in frozen:assert h.same_identity(row),row['path']
compile_events=[]
def compile_one(row):
 frozen_check();rp=out/(row['tag']+'-identity.json')
 if rp.exists():
  r=c.read(rp)
  if r['command']==row['command']and h.same_identity(r['object'])and h.same_identity(r['source'])and all(h.same_identity(d)for d in r['dependencies']):
   compile_events.append(dict(tag=row['tag'],action='reuse-exact-current-receipt'));return r
 compile_events.append(dict(tag=row['tag'],action='compile'))
 c.execute(row['tag']+'-compile',row['command'],env,out);frozen_check();dep=out/(row['tag']+'-deps.json');d=c.read(dep)['Data']
 r=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=row['recipe']);c.save(rp,r);return r
if '--products'in sys.argv:
 finished=[];errors=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  for task in concurrent.futures.as_completed([pool.submit(compile_one,row)for row in rows]):
   try:finished.append(task.result())
   except Exception as e:errors.append(repr(e))
 c.save(out/'compile-summary.json',dict(passed=not errors,CXX_products=len(rows),common_reused=len(reused),errors=errors,SDK_rebuilt=False,GPU_runs=0))
 if errors:raise RuntimeError(errors)
 print('V4_PRODUCTS_COMPILED_TESTS_STILL_DEFERRED',flush=True)
testrows=[]
if '--tests'in sys.argv or '--link'in sys.argv:
 for entry in deferred:
  rec=entry['owner'];source=Path(rec['source_path']);tag='test-'+source.parent.name+'-'+source.stem
  testrows.append(dict(tag=tag,source=b.identity(source),recipe=rec['recipe'],command=b.host_command(rec['command'],source,tag,out),old_object=entry['old_object'],object=str(out/(tag+'.obj'))))
 c.save(out/'test-plan.json',dict(tests=testrows,frozen_sources=[r['source']for r in testrows],new_targets=0))
if '--tests'in sys.argv:
 for row in testrows:compile_one(row)
if '--link'in sys.argv:
 for row in [*rows,*testrows]:
  r=c.read(out/(row['tag']+'-identity.json'));assert r['command']==row['command']and h.same_identity(r['source'])and h.same_identity(r['object'])and all(h.same_identity(d)for d in r['dependencies']),row['tag'];replacements[c.key(row['old_object']['path'])]=r['object']
 command=[replacements[c.key(arg)]['path']if c.key(arg)in replacements else arg for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 image=out/'vulkan.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))];lookup.update({c.key(r['path']):r for r in replacements.values()});inputs=[lookup[c.key(arg)]for arg in command if Path(arg).is_absolute()and Path(arg).suffix.lower()in('.obj','.lib')]
 for obj in inputs:assert h.same_identity(obj),obj['path']
 frozen_check();c.save(out/'link-plan.json',dict(command=command,inputs=inputs));c.execute('vulkan-link',command,env,out);frozen_check();c.save(out/'image.json',b.identity(image));c.save(out/'summary.json',dict(passed=True,product_CXX=len(rows),common_reused=len(reused),test_owners=len(testrows),CXX_invocations_this_run=sum(e['action']=='compile'for e in compile_events),compile_events=compile_events,links=1,SDK_rebuilt=False,GPU_runs=0,image=b.identity(image)))
 print('V4_HOST_IMAGE_READY_NO_GPU',flush=True)
