"""Exact current Vulkan cases; retain each image phase and actual XML results."""
from pathlib import Path
import importlib.util,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1]
spec=importlib.util.spec_from_file_location('mlx_v4_run_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c;checks=S/'checks';phase=sys.argv[1];out=S/'validation'/phase;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
names={
 'new':['VulkanIree.MixedMlxGroupedKeepsOriginalTypedBanksAcrossExpertCounts','VulkanGraph.OrdinaryMixedMlxMoeUsesSharedInputsAndOnlyPublishesFinalResults'],
 'ragged':['NativeRaggedAttentionGraph.UnequalRequestsUpdateSlotsKeepOldOutputAndZeroCapacityTail','NativeRaggedAttentionGraph.EightRequestsUseGraphProducedPayloadsAndSharedOwnedMetadata','NativeRaggedAttentionGraph.ConcreteOneRowWithinLargeSchemaRejectsMoreActiveQueries'],
 'neighbors':['VulkanIree.MlxGroupedSharesOriginalActivationAcrossSelectedExperts','VulkanGraph.MlxGroupedSharesOriginalActivationAcrossSelectedExperts','VulkanIree.OriginalMlxBatchPreservesGroupsSourceTypesAndCheckedSlots','VulkanGraph.OriginalMlxBatchUsesOrdinaryTypedNodesAndCheckedSlots','VulkanIree.OriginalMlxAffineWidthsUseContinuousBitstreamsAndCheckedRebinding','VulkanGraph.OriginalMlxAffineWidthsUseContinuousBitstreamsAndCheckedRebinding','VulkanIree.OriginalMlxConstantsKeepBanksAcrossRebindingAndSlots','VulkanGraph.OriginalMlxConstantsKeepBanksAcrossRebindingAndSlots','VulkanIree.OriginalMlxAffineWidthsKeepDecodedWeightsInF32BeforeDot'],
 'final-moe':['VulkanGraph.OrdinaryMixedMlxMoeUsesSharedInputsAndOnlyPublishesFinalResults'],
 'final-mixed':['VulkanIree.OriginalMlxBatchPreservesGroupsSourceTypesAndCheckedSlots','VulkanGraph.OriginalMlxBatchUsesOrdinaryTypedNodesAndCheckedSlots']
}[phase]
image=c.read(checks/'image.json');link=c.read(checks/'link-plan.json');freeze=c.read(S/'source-freeze.json');testfreeze=c.read(S/'tests-source-freeze.json')
for row in [image,*link['inputs']]:assert h.same_identity(row),row['path']
for row in freeze['files']:assert b.identity(A.parents[1]/row['path'])['sha256']==row['sha256'],row['path']
for row in testfreeze['files']:assert h.same_identity(row),row['path']
env=os.environ.copy();env['PATH']=c.read(checks/'runtime-environment.json')['PATH'];env['TEMP']=env['TMP']=str(out/'tmp')
xml=out/'results.xml';command=[image['path'],'--gtest_filter='+':'.join(names),'--gtest_output=xml:'+str(xml)]
c.save(out/'plan.json',dict(image=image,selected_tests=names,link_plan=b.identity(checks/'link-plan.json'),link_inputs=link['inputs'],product_freeze=b.identity(S/'source-freeze.json'),test_freeze=b.identity(S/'tests-source-freeze.json'),full_suite=False,model=False,throughput=False))
failure=None
try:run=c.execute('tests',command,env,out)
except RuntimeError as e:failure=str(e)
doc=ET.parse(xml).getroot();actual=[x.attrib['classname']+'.'+x.attrib['name']for suite in doc.findall('testsuite')for x in suite.findall('testcase')];failures=int(doc.attrib['failures']);skips=len(doc.findall('.//skipped'));errors=int(doc.attrib['errors']);passed=not failure and sorted(actual)==sorted(names)and not failures and not skips and not errors
properties={suite.attrib['name']+'.'+case.attrib['name']:{p.attrib['name']:p.attrib['value']for p in case.findall('./properties/property')}for suite in doc.findall('testsuite')for case in suite.findall('testcase')}
c.save(out/'summary.json',dict(passed=passed,tests=len(actual),failures=failures,errors=errors,skipped=skips,selected_cases=actual,image=image,properties=properties,xml=b.identity(xml),stdout=b.identity(out/'tests.stdout.log'),error=failure,GPU_processes=1,SDK_rebuilt=False))
print(phase.upper(),len(actual),'cases',failures,'failed',skips,'skip',flush=True)
if not passed:raise SystemExit(1)
