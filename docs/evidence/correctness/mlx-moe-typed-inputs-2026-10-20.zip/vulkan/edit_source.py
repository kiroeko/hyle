"""Prepare exact assigned-source candidate; apply only after the old V3 red."""
from pathlib import Path
import hashlib,json,difflib,sys
S=Path(__file__).resolve().parent;ROOT=S.parents[3]
rows=json.loads((S/'before.json').read_text())['files'];sources={}
for row in rows:
 data=(S/'before'/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];sources[row['path']]=data.decode().replace('\r\n','\n')
def replace(p,a,b,count=1):
 assert sources[p].count(a)==count,(p,a,sources[p].count(a));sources[p]=sources[p].replace(a,b)
p='src/compute_provider_iree_vulkan/native_program.h'
replace(p,'ProgramSpecV3','ProgramSpecV4',2)
replace(p,'  ArtifactScalar scale_type = ArtifactScalar::Float32;','''  // MLX dot inputs retain their actual storage types. Mixed affine sources
  // widen only selected scalars in the original group program.
  ArtifactScalar activation_type = ArtifactScalar::Float32;
  ArtifactScalar scale_type = ArtifactScalar::Float32;''')
p='src/compute_provider_iree_vulkan/native_program.cc'
replace(p,'''  if (type >= 3 || !mlx_program(spec.kind)) return nullptr;
  constexpr std::array<std::array<const char *, 3>, 7> names''','''  if (type >= 3 || !mlx_program(spec.kind)) return nullptr;
  const auto activation = static_cast<std::size_t>(spec.activation_type);
  const auto scale = static_cast<std::size_t>(spec.scale_type);
  if (spec.kind == ProgramKind::MlxAffineLinear ||
      spec.kind == ProgramKind::MlxAffineGrouped) {
    if (activation >= 3 || scale >= 3) return nullptr;
    if (activation != scale) {
      if (spec.output_type != ArtifactScalar::Float32) return nullptr;
      constexpr std::array<std::array<const char *, 3>, 3> linear{{
          {nullptr, "module.affine_linear_f32_f16", "module.affine_linear_f32_bf16"},
          {"module.affine_linear_f16_f32", nullptr, "module.affine_linear_f16_bf16"},
          {"module.affine_linear_bf16_f32", "module.affine_linear_bf16_f16", nullptr}}};
      constexpr std::array<std::array<const char *, 3>, 3> grouped{{
          {nullptr, "module.affine_grouped_f32_f16", "module.affine_grouped_f32_bf16"},
          {"module.affine_grouped_f16_f32", nullptr, "module.affine_grouped_f16_bf16"},
          {"module.affine_grouped_bf16_f32", "module.affine_grouped_bf16_f16", nullptr}}};
      return spec.kind == ProgramKind::MlxAffineGrouped
                 ? grouped[activation][scale] : linear[activation][scale];
    }
    if (type != activation) return nullptr;
  } else if (spec.kind == ProgramKind::MlxAffineEmbedding) {
    if (type != scale) return nullptr;
  } else if (type != activation) return nullptr;
  constexpr std::array<std::array<const char *, 3>, 7> names''')
replace(p,'''      const auto type = artifact_scalar(spec.output_type);
      if (embedding) {''','''      const auto type = artifact_scalar(spec.output_type);
      const auto activation_type = artifact_scalar(spec.activation_type);
      const auto scale_type = artifact_scalar(spec.scale_type);
      if (embedding) {''')
replace(p,'allocate_view(hal, physical, type)','allocate_view(hal, physical, activation_type)')
replace(p,'allocate_view(hal, activation, type)','allocate_view(hal, activation, activation_type)')
replace(p,'affine ? type : static_cast<iree_hal_element_type_t>(IREE_HAL_ELEMENT_TYPE_SINT_8)','affine ? scale_type : static_cast<iree_hal_element_type_t>(IREE_HAL_ELEMENT_TYPE_SINT_8)')
replace(p,'state->views[3], allocate_view(hal, scales, type)','state->views[3], allocate_view(hal, scales, scale_type)')
p='src/compute_route_vulkan/vulkan_mlx.cc'
replace(p,'    spec.scale_type = spec.output_type;','''    spec.activation_type = embedding ? spec.output_type
        : scalar(program.values[step.inputs[0]].description.data_type());
    spec.scale_type = affine
        ? scalar(program.values[step.inputs[embedding ? 1 : 2]].description.data_type())
        : spec.output_type;''')
replace(p,'''    if (!embedding && affine) {
      // Schema-promoted mixed affine ports use existing qualified casts. Do
      // this cold once; the corresponding GPU work remains charged on replay.
      for (std::size_t port : {std::size_t{0}, std::size_t{2}, std::size_t{3}}) {
        const auto description = program.values[inputs[port]].description;
        if (description.data_type() == output.data_type()) continue;
        HYLE_ASSIGN_OR_RETURN(auto promoted,
            TensorDesc::dense(output.data_type(), description.dimensions()));
        const auto value = append(program, promoted);
        HYLE_RETURN_IF_ERROR(lower_native_cast(program, inputs[port], value));
        inputs[port] = value;
      }
    }
    // Promotion may have produced a compact T*1*K input; bind that actual
    // geometry rather than the source View's earlier padded stride.
    activation_geometry(inputs[0]);''','''    // Typed programs widen actual selected scalars, preserving the original
    // activation pitch and scale/bias banks instead of casting whole inputs.
    activation_geometry(inputs[0]);''')
p='third_party/iree_vulkan_runtime/programs/generate_mlx.py'
replace(p,'''def group_program(fmt, dtype, grouped):
    t = TYPES[dtype]''','''def group_program(fmt, dtype, grouped, activation_dtype=None, scale_dtype=None):
    activation_dtype = activation_dtype or dtype
    scale_dtype = scale_dtype or dtype
    t = TYPES[dtype]
    a = TYPES[activation_dtype]
    s = TYPES[scale_dtype]''')
replace(p,"a_type = f'tensor<?x{t}>' if grouped else f'tensor<?x?x{t}>'","a_type = f'tensor<?x{a}>' if grouped else f'tensor<?x?x{a}>'")
replace(p,"scale_type = f'tensor<?x?x?x{t if affine else \"i8\"}>'","scale_type = f'tensor<?x?x?x{s if affine else \"i8\"}>'")
replace(p,"    name = f'{fmt}_{\"grouped\" if grouped else \"linear\"}_{dtype}'","""    name = f'{fmt}_{"grouped" if grouped else "linear"}_{dtype}'
    if activation_dtype != scale_dtype:
        if not affine or dtype != 'f32':
            raise ValueError('only affine dots have mixed source types and F32 output')
        name = f'{fmt}_{"grouped" if grouped else "linear"}_{activation_dtype}_{scale_dtype}'""")
replace(p,"conversions, activation = wide('%av', dtype, 'activation')","conversions, activation = wide('%av', activation_dtype, 'activation')")
replace(p,"sc, s = wide('%sv', dtype, 'scale'); bc, b = wide('%bv', dtype, 'bias')","sc, s = wide('%sv', scale_dtype, 'scale'); bc, b = wide('%bv', scale_dtype, 'bias')")
replace(p,"    destination.write_text('module {\\n'", """    for activation in TYPES:
        for scale in TYPES:
            if activation == scale: continue
            for grouped in (False, True):
                text, name = group_program('affine', 'f32', grouped, activation, scale)
                entries.append(text);names.append(name)
    destination.write_text('module {\\n'""")
p='third_party/iree_vulkan_runtime/programs/compile_mlx.py'
replace(p,"    if recipe.read_text().count('%bits_arg: i32') != 9:\n        raise ValueError('expected nine affine exports with runtime bits')","""    if recipe.read_text().count('%bits_arg: i32') != sum(name.startswith('affine_') for name in exports):
        raise ValueError('every affine export requires runtime bits')""")
replace(p,"    expected.update(f'affine_embedding_{dtype}' for dtype in ('f32', 'f16', 'bf16'))","""    expected.update(f'affine_embedding_{dtype}' for dtype in ('f32', 'f16', 'bf16'))
    expected.update(f'affine_{kind}_{activation}_{scale}'
                    for kind in ('linear', 'grouped')
                    for activation in ('f32', 'f16', 'bf16')
                    for scale in ('f32', 'f16', 'bf16') if activation != scale)""")
replace(p,"        raise ValueError('original MLX export set differs')","        raise ValueError('MLX same-type and finite mixed-source export set differs')")
replace(p,"        raise ValueError('compiled MLX argument signature differs from its recipe')","""        raise ValueError('compiled MLX argument signature differs from its recipe')
    declaration_results = dict(re.findall(r'iree\\.abi\\.declaration = "async func @(\\w+)\\([^"\\n]*\\) -> \\(%output0: (tensor<[^>]+>)\\)"', text))
    source_results = dict(re.findall(r'func\\.func @(\\w+)\\([^\\n]*\\) -> (tensor<[^>]+>)', recipe.read_text()))
    if declaration_results != source_results:
        raise ValueError('compiled MLX result signature differs from its recipe')""")
replace(p,"               'affine_runtime_bits': [4, 5, 6, 8],","""               'compiled_result_signatures': declaration_results,
               'mixed_affine_sources': [dict(activation=a, scale_bias=s, output='f32')
                   for a in ('f32', 'f16', 'bf16') for s in ('f32', 'f16', 'bf16') if a != s],
               'affine_runtime_bits': [4, 5, 6, 8],""")
diffs=[];updated=[]
for row in rows:
 rel=row['path'];before=(S/'before'/rel).read_bytes();data=sources[rel].encode();data=data.replace(b'\n',b'\r\n')if b'\r\n'in before else data
 target=S/'candidate'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 diffs.append(''.join(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),fromfile='before/'+rel,tofile=rel)))
 updated.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 if '--apply'in sys.argv:
  assert (ROOT/rel).read_bytes()==before,rel
  (ROOT/rel).write_bytes(data)
(S/'source.diff').write_bytes(''.join(diffs).encode());(S/'candidate.json').write_bytes((json.dumps(dict(files=updated,applied='--apply'in sys.argv),indent=2)+'\n').encode())
print('CANDIDATE',len(updated),'applied','--apply'in sys.argv)
