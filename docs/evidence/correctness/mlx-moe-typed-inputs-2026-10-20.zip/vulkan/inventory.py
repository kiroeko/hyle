"""Read the actual V3 link/SourceDeps owners requiring a consistent V4 refresh."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('mlx_abi_inventory_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
basepath=S.parent/'reproduction/link-plan.json';base=c.read(basepath);metadata=h.metadata({'vulkan':base})
headers={c.key(ROOT/p)for p in ['src/compute_provider_iree_vulkan/native_program.h','src/compute_route_vulkan/vulkan_program_internal.h']}
owners=[];generated=[];missing=[]
for obj in base['inputs']:
 assert h.same_identity(obj),obj['path']
 if Path(obj['path']).suffix.lower()!='.obj':continue
 row=metadata.get(c.key(obj['path']))
 if not row:missing.append(obj);continue
 deps=row.get('dependencies',[])or row.get('headers',[])or row.get('hyle_headers',[])
 depfile=row.get('source_dependencies')
 # Full actual SourceDeps paths are authoritative for membership even when
 # an older receipt kept only a bounded identity subset.
 paths={c.key(d['path'])for d in deps}
 if depfile:
  path=Path(depfile['path']if isinstance(depfile,dict)else depfile)
  if path.is_file():paths.update(c.key(p)for p in c.read(path)['Data']['Includes'])
 hit=paths&headers
 if hit:owners.append(dict(object=obj,source=row['source_path'],recipe=row['recipe'],headers=sorted(hit),owner=row))
 if Path(row['source_path']).name=='programs.cc':generated.append(dict(object=obj,owner=row))
c.save(S/'abi-owner-inventory.json',dict(base_path=str(basepath),base_inputs=len(base['inputs']),private_headers=sorted(headers),private_ABI_owners=owners,generated_program_owners=generated,missing_metadata=missing,host_builds=0,GPU_runs=0))
print('ACTUAL_V4_PRIVATE_OWNERS',len(owners),'GENERATED',len(generated),'MISSING',len(missing),flush=True)
for row in owners:print(Path(row['source']).relative_to(ROOT),flush=True)
