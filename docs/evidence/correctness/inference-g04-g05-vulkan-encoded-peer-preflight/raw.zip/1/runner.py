from pathlib import Path
import hashlib,json,os,struct,subprocess,sys,time,zipfile
BASE=Path('/Users/kiro/hyle-scratch/compute-unified');OUT=BASE/'g04-vulkan-encoded-peer-preflight'
attempt=sys.argv[1];RUN=OUT/attempt;RUN.mkdir(exist_ok=False)
SOURCE=BASE/'source-c8874688';BUILD=BASE/'a-cpu-vulkan/selected-graph/static-sdk-build'
identity={k:subprocess.check_output(v,text=True).strip() for k,v in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
cache=(BUILD/'CMakeCache.txt').read_text();assert 'HYLE_STATIC:BOOL=ON' in cache and 'HYLE_SANITIZER:STRING=off' in cache
generated=BASE/'g01-native-page-vulkan-preflight/reference-shaders';original=json.loads((generated/'identity.json').read_text())
peer=BASE/'g01-original-ggml-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()==original['revision']=='456172ec733a135778adcd32d00e576a58232e45'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
for name,sha in original['source_blobs_sha256'].items():
 blob=subprocess.check_output(['git','-C',str(peer),'show',original['revision']+':src/ggml-vulkan/vulkan-shaders/'+name]);assert hashlib.sha256(blob).hexdigest()==sha
header=['#pragma once','#include <cstdint>','namespace hyle::bench::resident::spirv {']
for row in original['outputs']:
 raw=(generated/(row['name']+'.spv')).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
 words=struct.unpack('<'+'I'*(len(raw)//4),raw);header+=['inline constexpr std::uint32_t '+row['name']+'[] = {']
 header += [','.join('0x%08xu'%word for word in words[i:i+8])+',' for i in range(0,len(words),8)];header+=['};']
header+=['}'];assert (generated/'reference_spirv.h').read_bytes()==('\n'.join(header)+'\n').encode()
inputs=[]
with zipfile.ZipFile(OUT/f'input-{attempt}.zip') as archive:
 for name in ('reference.cc','reference.h','vulkan_encoded_preflight.cc'):
  raw=archive.read(name);(RUN/name).write_bytes(raw);inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()})
hook=RUN/'project.cmake';target='g04_vulkan_encoded_peer_preflight'
hook.write_text('''if(PROJECT_NAME STREQUAL "hyle")
 function(g04_encoded_original_preflight)
  add_executable(@TARGET@ "@RUN@/reference.cc" "@RUN@/vulkan_encoded_preflight.cc")
  target_compile_features(@TARGET@ PRIVATE cxx_std_23)
  target_compile_options(@TARGET@ PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_include_directories(@TARGET@ PRIVATE "@SOURCE@/src/compute_route_vulkan" "@GENERATED@")
  target_link_libraries(@TARGET@ PRIVATE hyle::compute)
  hyle_stage_runtime(@TARGET@)
 endfunction()
 cmake_language(DEFER CALL g04_encoded_original_preflight)
endif()
'''.replace('@TARGET@',target).replace('@RUN@',str(RUN)).replace('@SOURCE@',str(SOURCE)).replace('@GENERATED@',str(generated)))
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
record={'state':'RUNNING','scope':'Independent original Q8 shader adapter numeric/readonly/lifecycle preflight only; no product attention/P1 qualification','identity':identity,'inputs':inputs,'original':original,'header_sha256':hashlib.sha256((generated/'reference_spirv.h').read_bytes()).hexdigest(),'stages':[],'cumulative_seconds':0,'max_jobs':4}
def save():(RUN/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(RUN/'runner.py').write_bytes(Path(__file__).read_bytes());save()
def run(stage,args):
 log=RUN/f'{stage}.log';start=time.monotonic()
 with log.open('w') as handle:
  p=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT);(RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':p.pid}));print(stage,p.pid,flush=True);code=p.wait()
 elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed;record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 record['state']='TERMINAL_FAIL' if code else 'RUNNING';save();print(stage,code,elapsed,flush=True)
 if code:
  (RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));print(log.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(code)
run('configure',['/opt/homebrew/bin/cmake','-S',str(SOURCE),'-B',str(BUILD),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-n',target],env=env,text=True);(RUN/'dry-run.txt').write_text(dry)
assert 'Building CXX object src/' not in dry and 'Building C object src/' not in dry and 'Generating' not in dry,'unexpected dependency rebuild; inspect before any heavy build'
run('compile',['/opt/homebrew/bin/cmake','--build',str(BUILD),'--target',target,'--parallel','4'])
paths=[p/target for p in (BUILD/'bin',BUILD) if (p/target).is_file()];assert len(paths)==1
run('oracle',[str(paths[0])])
lines=(RUN/'oracle.log').read_text().splitlines();assert sum(line.startswith('ORIGINAL_Q8_PREFLIGHT ') and line.endswith(' PASS') for line in lines)==14
assert sum(line.startswith('ORIGINAL_PLAIN_CONTROL ') and line.endswith(' PASS') for line in lines)==2
record['state']='TERMINAL_PASS';save();(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
