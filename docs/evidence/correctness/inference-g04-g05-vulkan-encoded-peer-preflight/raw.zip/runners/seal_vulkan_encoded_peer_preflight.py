from pathlib import Path
import hashlib,json,re,zipfile
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'vulkan-encoded-peer-preflight';RUN=OUT/'1'
r=json.loads((RUN/'result.json').read_text());assert r['state']=='TERMINAL_PASS'
log=(RUN/'oracle.log').read_text();rows=re.findall(r'^ORIGINAL_Q8_PREFLIGHT .*max_abs_error=([0-9.e+-]+) PASS$',log,re.M)
assert len(rows)==14 and len(re.findall(r'^ORIGINAL_PLAIN_CONTROL .* PASS$',log,re.M))==2
scope=json.loads((RUN/'actual-build-scope.json').read_text())
dest=ROOT/'evidence/correctness/inference-g04-g05-vulkan-encoded-peer-preflight';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
 for name in ('vulkan_encoded_peer_preflight_air.py','launch_vulkan_encoded_peer_preflight.py','seal_vulkan_encoded_peer_preflight.py'):
  z.write(BASE/name,'runners/'+name)
 z.write(BASE/'vulkan-peer-preflight-validation-plan.json','validation-plan.json')
receipt={'kind':'G04_G05_ORIGINAL_VULKAN_Q8_ADAPTER_PREFLIGHT','verdict':'PASS_NUMERICAL_PREFLIGHT_ONLY','identity':r['identity'],'inputs':r['inputs'],'original_revision':r['original']['revision'],'original_spirv_header_sha256':r['header_sha256'],'stages':r['stages'],'cumulative_seconds':r['cumulative_seconds'],'encoded_cases':14,'plain_controls':2,'encoded_replays_per_case':4,'slots':2,'max_abs_error':max(map(float,rows)),'readonly_KV':'PASS_BYTE_IDENTICAL','split':'Q1/KV2048/D64_Dv128 window16 requires and executed four-dispatch recipe including original reduce','build_scope':scope,'limits':['No P1/AA/throughput or candidate performance verdict','No mask-opt, multi-batch, producer/growth/capture qualification','Original independent scalar non-MMQ shader; no candidate attention lowerer or shader arithmetic changes','Frozen shipping Vulkan runtime inputs; not CPU CE12 execution proof','Cold fixed F16 causal/window mask storage O(Q*KV) explicit; query/output conversion and split costs remain in native program'],'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('identity','inputs','stages','build_scope')}))
