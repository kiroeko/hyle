from pathlib import Path
import json,subprocess,sys,time,zipfile
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=sys.argv[1]
assert json.loads((BASE/'ce12/post-source-1/result.json').read_text())['state']=='TERMINAL_PASS','heavy verification remains serial'
OUT=BASE/'vulkan-encoded-peer-preflight';OUT.mkdir(exist_ok=True)
archive=OUT/f'input-{attempt}.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ('reference.cc','reference.h','vulkan_encoded_preflight.cc'):z.write(ROOT/'bench/inference_resident_sdpa'/name,name)
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g04-vulkan-encoded-peer-preflight'
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp',str(archive),str(BASE/'vulkan_encoded_peer_preflight_air.py'),host+':'+remote+'/'],check=True)
args=['ssh','-o','BatchMode=yes',host,'python3',remote+'/vulkan_encoded_peer_preflight_air.py',attempt]
log=OUT/f'launch-{attempt}.log';start=time.monotonic()
with log.open('wb') as handle:
 p=subprocess.Popen(args,stdout=handle,stderr=subprocess.STDOUT)
 (OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'RUNNING','pid':p.pid,'command':args,'log':str(log)}))
 print('remote preflight',p.pid,flush=True);code=p.wait()
elapsed=time.monotonic()-start
subprocess.run(['scp','-r',host+':'+remote+'/'+attempt,str(OUT)],check=False)
(OUT/f'launch-{attempt}.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code,'elapsed_seconds':elapsed,'command':args,'log':str(log),'remote_stage_record_present':(OUT/attempt/'result.json').is_file()},indent=2)+'\n')
(OUT/f'job-{attempt}.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code}))
print(log.read_text(errors='replace')[-4500:],flush=True)
raise SystemExit(code)
