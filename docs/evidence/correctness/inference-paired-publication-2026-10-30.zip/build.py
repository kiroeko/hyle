from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-multimodel-observation-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    base_path = R / '.scratch/inference-publication-retirement-20261030/model-link-base.json'
    base = read(base_path)
    for item in [*base['retained'], base['runtime'], base['sdk_engine_dependencies']]:
        exact(item)
    sdk = read(base['sdk_engine_dependencies']['path'])
    changed = []
    for unit in sdk['engine_consumers']:
        for item in unit['source_identities']:
            if key(item['path']) == key(R / 'engine/inference/paged_sequence.h'):
                changed.append(dict(before=item, after=pin(item['path'])))
            else:
                exact(item)
    assert len(changed) == 1
    weights = next(u for u in sdk['engine_consumers'] if any(
        key(p['path']) == key(R / 'engine/models/qwen35/weights.cc') for p in u['source_identities']))
    old_object = read(base['previous_consumer']['path'])['object']['path']
    source = (R / '.scratch/inference-publication-retirement-20261030/model.cc').read_text()
    source = source.replace('if (name == "publication")',
        'if (name == "batch") return qwen_mtp_batch_state_case::run(argv[3], kind);\n    if (name == "publication")')
    (W / 'model.cc').write_text(source)
    units = {}
    recipes = [('weights', R / 'engine/models/qwen35/weights.cc',
                read(R / '.scratch/inference-paged-sequence-20261029/compile/weights/attempt1/command.json')),
               ('sequence', R / 'tests/tools/inference_paged_sequence_test.cc', base['compile']),
               ('model', W / 'model.cc', base['compile']),
               ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc', base['compile'])]
    for name, source, recipe in recipes:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        command = []
        for index, arg in enumerate(recipe):
            if index and recipe[index - 1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(base['consumer_source']['path']):
                arg = str(source)
            command.append(arg)
        assert sum(key(arg) == key(source) for arg in command) == 1
        units[name] = dict(source=str(source), compile=command)
        if name == 'weights':
            continue
        link = []
        for arg in base['link']:
            if key(arg) == key(old_object):
                arg = str(folder / 'unit.obj')
            elif key(arg) == key(weights['object']):
                arg = str(W / 'compile/weights/unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link.append(arg)
        if name == 'sequence':
            for library in ('gtest_main.lib', 'gtest.lib'):
                path = R / '.scratch/build-compute-v2-dev/lib' / library
                if not any(key(arg) == key(path) for arg in link):
                    link.append(str(path))
        assert sum(key(arg) == key(folder / 'unit.obj') for arg in link) == 1
        assert sum(key(arg) == key(W / 'compile/weights/unit.obj') for arg in link) == 1
        units[name]['link'] = link
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    continuous = W / 'continuous-input'
    continuous.mkdir(exist_ok=True)
    for metadata in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(R / '.scratch/inference-continuous-wave-20261027/inputs/context32' / metadata, continuous / metadata)
    tiny = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    original = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    fixtures = {name: dict(directory=str(directory), manifest=pin(directory / 'weights.tsv'), prompt=pin(directory / 'prompt.ids'))
        for name, directory in [('tiny', tiny), ('original', original), ('continuous', continuous)]}
    cases = {
        'sequence-cpu': dict(unit='sequence', tests=5),
        'publication-cpu': dict(unit='model', args=['publication', 'cpu', str(tiny)]),
        'group-cuda': dict(unit='model', args=['group', 'cuda', str(tiny)]),
        'batch-cuda': dict(unit='model', args=['batch', 'cuda', str(tiny)]),
        'natural-cuda': dict(unit='model', args=['natural', 'cuda', str(original)]),
        'continuous-cuda': dict(unit='ordinary', args=['--cuda-continuous', str(continuous)])}
    save(W / 'plan.json', dict(base=pin(base_path), units=units, retained=base['retained'], runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'], original_weights=weights['object'], changed_SDK_source=changed,
        worktree_base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
        fixtures=fixtures, cases=cases))
    print('Prepared three consumers and one affected engine weights TU; 226 SDK inputs retained, no native process started.')


def seal_sdk():
    plan = read(W / 'plan.json')
    receipt = b.receipt('weights')
    sdk = read(plan['sdk']['path'])
    unit = next(u for u in sdk['engine_consumers'] if key(u['object']) == key(plan['original_weights']))
    unit.update(object=receipt['object']['path'], source_identities=receipt['source_identities'],
        engine_dependencies=[p['path'] for p in receipt['source_identities'] if Path(p['path']).is_relative_to(R / 'engine')],
        original_receipt=pin(W / 'compile/weights/receipt.json'), dependencies=pin(W / 'compile/weights/dependencies.json'))
    save(W / 'sdk-engine-dependencies.json', sdk)
    plan['retained'] = [p for p in plan['retained'] if key(p['path']) != key(plan['original_weights'])] + [receipt['object']]
    assert len(plan['retained']) == 227
    plan['sdk'] = pin(W / 'sdk-engine-dependencies.json')
    save(W / 'plan.json', plan)
    print('Refreshed original engine weights TU; 226 other SDK inputs retained.')


def run(name, attempt):
    plan = read(W / 'plan.json')
    case = plan['cases'][name]
    b.receipt(case['unit'])
    b.receipt('weights')
    image = read(W / ('ready-' + case['unit'] + '.json'))
    exact(image)
    folder = W / 'runs' / name / attempt
    args = case.get('args', [])
    if 'tests' in case:
        args = ['--gtest_color=no', '--gtest_filter=InferencePagedSequence.*', '--gtest_output=xml:' + str(folder / 'results.xml')]
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    save(folder / 'image.json', image)
    b.b.execute([image['path'], *args], folder, 600)
    if 'tests' in case:
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors') == '0'
        assert not result.findall('.//skipped')
        report = dict(status='PASS', tests=case['tests'], failures=0, skipped=0)
    else:
        report = read(folder / 'stdout.log')
        assert report['status'] == 'PASS'
    save(folder / 'report.json', report)
    print('PASS', name)


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'seal-sdk':
        seal_sdk()
    elif sys.argv[1] == 'run':
        run(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else 'attempt1')
    else:
        b.main()
