from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin = b.read, b.save, b.pin
plan = read(W / 'plan.json')
base = read(plan['base']['path'])
save(W / 'model-link-base.json', dict(schema='hyle.paired-publication.current-link-base.v1',
    base=plan['base'], compile=plan['units']['model']['compile'], link=plan['units']['model']['link'],
    consumer_source=pin(plan['units']['model']['source']), previous_consumer=pin(W / 'compile/model/receipt.json'),
    retained=plan['retained'], runtime=plan['runtime'], sdk_engine_dependencies=plan['sdk']))

current = []
for name in plan['cases']:
    attempt = 'attempt2' if name == 'sequence-cpu' else 'attempt1'
    folder = W / 'runs' / name / attempt
    report = read(folder / 'report.json')
    assert report['status'] == 'PASS'
    current.append(dict(case=name, process=read(folder / 'process.json'), report=report))
comparisons = []
for name in ('natural-cuda', 'continuous-cuda'):
    previous_attempt = 'final' if name == 'continuous-cuda' else 'reviewed'
    previous = R / '.scratch/inference-publication-retirement-20261030/runs' / name / previous_attempt / 'report.json'
    current_report = W / 'runs' / name / 'attempt1/report.json'
    equal = read(previous) == read(current_report)
    assert equal
    comparisons.append(dict(case=name, previous=pin(previous), current=pin(current_report), full_report_equal=equal))
processes = list(W.rglob('process.json'))
assert all(read(p)['state'] == 'TERMINAL' for p in processes)
counts = {kind: len([p for p in processes if p.is_relative_to(W / directory)])
    for kind, directory in [('CXX_attempts', 'compile'), ('link_attempts', 'link'), ('native_attempts', 'runs')]}
assert counts == dict(CXX_attempts=5, link_attempts=4, native_attempts=7), counts
files = [pin(p) for p in sorted((W / 'bin').iterdir()) if p.is_file()]
save(W / 'cleanup-plan.json', dict(root=str(W / 'bin'), files=files, bytes=sum(p['bytes'] for p in files)))
sources = [R / path for path in ('engine/inference/paged_sequence.h', 'engine/models/qwen35/main.cc',
    'tests/tools/inference_paged_sequence_test.cc')]
patch = subprocess.check_output(['git', 'diff', '--', *[str(p.relative_to(R)) for p in sources]], cwd=R)
(W / 'source.patch').write_bytes(patch)
evidence = dict(schema='hyle.correctness.paired-publication.v1', date='2026-10-30',
    status='PASS_WITH_PRESERVED_FIXTURE_FAILURE', base_commit=plan['worktree_base_commit'],
    change='Whole-cohort frame preflight returns the same borrowed candidate and original commit tickets for one consumption; ordinary/MTP and private draft use it without reconstructing publication edits.',
    invariants=['All surviving members preflight before any original Head swap.',
        'Original frame commit permissions, snapshots, Source, ledger, RNG and real retirement remain authoritative.',
        'Borrowed backing addresses stay stable until consumption; original retirement clears handles before candidate reuse.',
        'No allocation, payload copy, queue, executor or second state owner added.'],
    sources=[pin(p) for p in sources], counts=dict(**counts, current_passed_processes=6,
        current_component_tests=5, preserved_fixture_failures=1, SDK_engine_CXX=1,
        unchanged_SDK_engine_inputs=226, NVCC=0, downloads=0, whole_builds=0, throughput_windows=0),
    current_runs=current, comparisons=comparisons,
    preserved_failure=dict(process=read(W / 'runs/sequence-cpu/attempt1/process.json'),
        cause='The new two-bank test Graph lacked the original dependency edge between append effects; corrected only fixture depends_on, without changing product checks or assertions.'),
    limits=['A maintenance/assembly correction, not a demonstrated product numerical failure or throughput improvement.',
        'No new Apple/Vulkan run, persistent native fault injection, complete second engine model or multi-device implementation.',
        'Generic whole engine orchestration and performance milestones remain incomplete.'],
    cleanup_plan=read(W / 'cleanup-plan.json'))
stem = R / 'docs/evidence/correctness/inference-paired-publication-2026-10-30'
save(stem.with_suffix('.json'), evidence)
with zipfile.ZipFile(stem.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(W.rglob('*')):
        if not path.is_file() or path.is_relative_to(W / 'bin') or path.suffix.lower() in ('.obj', '.pdb', '.exe', '.dll', '.lib'):
            continue
        archive.write(path, path.relative_to(W).as_posix())
print(json.dumps(dict(counts=evidence['counts'], evidence=pin(stem.with_suffix('.zip')),
    cleanup_bytes=evidence['cleanup_plan']['bytes']), ensure_ascii=False))
