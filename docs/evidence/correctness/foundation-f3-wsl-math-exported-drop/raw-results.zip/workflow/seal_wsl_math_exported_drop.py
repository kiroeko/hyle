from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'; raw = scratch / 'wsl-math-logs'
job = json.loads((raw / 'job.json').read_text()); assert job['verdict'] == 'PASS_WSL_F3_MATH_ONLY'
for row in job['stages']:
    assert row['state'] == 'terminal' and row['exit_code'] == 0
    assert hashlib.sha256((raw / row['log']).read_bytes()).hexdigest() == row['sha256']
text = (raw / 'qwen.log').read_text()
assert text.count('Qwen original ') == 8 and text.count('Qwen reloaded ') == 8
assert text.count('Qwen roundtrip logical bytes=75497984; staging=2097152; peak slots=2; native bytes=226493952') == 2
cpu = scratch / 'cpu-subject-windows-1'; data = json.loads((cpu / 'job.json').read_text())
resume = next(row for row in data['resumes'] if row['attempt'] == 'exported-thread-drop')
for row in resume['inputs']:
    assert hashlib.sha256((repo / row['path']).read_bytes()).hexdigest() == row['sha256']
for row in data['stages']:
    if row['name'] not in ['build-exported-thread-drop', 'files-exported-thread-drop']: continue
    assert row['state'] == 'terminal' and row['exit_code'] == 0
    assert hashlib.sha256((cpu / row['log']).read_bytes()).hexdigest() == row['sha256']
tests = ET.parse(cpu / 'files-exported-thread-drop.xml').getroot()
assert tests.attrib['tests'] == '11' and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
out = repo / 'evidence/correctness/foundation-f3-wsl-math-exported-drop'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for path in sorted(raw.iterdir()):
        if path.is_file(): packed.writestr('wsl/' + path.name, path.read_bytes())
    for name in ['job.json', 'build-exported-thread-drop.log', 'files-exported-thread-drop.log', 'files-exported-thread-drop.xml']:
        packed.writestr('cpu/' + name, (cpu / name).read_bytes())
    packed.writestr('wsl-source.json', (scratch / ('wsl-source-' + job['candidate'][:9] + '.json')).read_bytes())
    for name in ['run_wsl_gates.py', 'prepare_wsl_inputs.py', 'seal_wsl_math_exported_drop.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1, 'product_commit': 'f3d931c47777f7fbfd35dedf1f5e0734fa28ef6c',
    'wsl_consumer_commit': job['candidate'], 'exported_drop_fixture_commit': 'c36c40bedfb960384020c117703c4eda599a9359',
    'scope': 'WSL ordinary CPU/CUDA static source Qwen/GGUF mathematical roundtrip and Windows CPU exported cross-thread result release only',
    'wsl_identity': job['identity'], 'wsl_stage_verdicts': [{'name': row['name'], 'exit_code': row['exit_code']} for row in job['stages']],
    'input': 'evidence/correctness/foundation-f3-qwen-ranges/checked-input.json',
    'sparse_mirror': json.loads((raw / 'transfer-verification.json').read_text()),
    'native_bytes_per_route': 226493952, 'staging_bytes': 2097152, 'peak_slots': 2,
    'windows_cpu_tests_passed': 11, 'windows_cpu_inputs': resume['inputs'],
    'cross_thread_risk': 'A real other thread owns exported ReadyGroup/ReadLease; main collect/admission cannot reuse its record, after actual release/join the same finite record/backing becomes available.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_WSL_CPU_CUDA_SOURCE_MATH_AND_WINDOWS_CPU_EXPORTED_CROSS_THREAD_DROP_ONLY',
    'unproven': ['Positive partial short write on POSIX', 'New F3 sanitizer/native CUDA WSL tests', 'Installed delivery and final closure'],
    'limits': 'Original four ranges only; no whole model/FFN, P1, private-driver bound or installed SDK verdict. Existing CUDA 12/13 locked leaf link warnings retained with actual successful runtime.'}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('WSL actual CPU/CUDA original math roundtrips and Windows CPU eleven/tested cross-thread release verified.')
