from pathlib import Path
import hashlib
import json
import zipfile

canonical = Path('/mnt/c/public/project-hyle/hyle')
base = Path('/root/hyle-scratch/compute-unified')
root = base / 'foundation-f3-qwen-input'; assert not root.exists(); root.mkdir()
archive = canonical / '.scratch/foundation-f3/qwen-air-checked-ranges.zip'
with zipfile.ZipFile(archive) as packed:
    checked = json.loads(packed.read('checked-input.json'))
    model = root / 'model-ranges.safetensors'
    with model.open('wb') as output:
        output.truncate(checked['file_bytes']); output.seek(0); output.write(packed.read('header.bin'))
        for index, row in enumerate(checked['ranges']):
            data = packed.read('range-' + str(index) + '.bin')
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['payload_sha256']
            output.seek(row['file_offset']); output.write(data)
    for name in packed.namelist():
        if name.endswith('.reference.txt') or name == 'checked-input.json': (root / name).write_bytes(packed.read(name))
    lines = packed.read('ranges.tsv').decode().splitlines(); lines[1] = str(model)
    (root / 'ranges.tsv').write_text('\n'.join(lines) + '\n')
with model.open('rb') as source:
    header = source.read(checked['data_base']); assert hashlib.sha256(header[8:]).hexdigest() == checked['header_sha256']
    for row in checked['ranges']:
        source.seek(row['file_offset']); assert hashlib.sha256(source.read(row['bytes'])).hexdigest() == row['payload_sha256']
gguf = base / 'foundation-f3-gguf-input'; assert not gguf.exists(); gguf.mkdir()
original = canonical / '.scratch/foundation-f3/gguf-consumer-input'
(gguf / 'mixed-fixture.gguf').write_bytes((original / 'mixed-fixture.gguf').read_bytes())
lines = (original / 'gguf-ranges.tsv').read_text().splitlines(); lines[1] = str(gguf / 'mixed-fixture.gguf')
(gguf / 'gguf-ranges.tsv').write_text('\n'.join(lines) + '\n')
record = {'source': str(model), 'capacity': model.stat().st_size, 'physical_file_bytes': model.stat().st_blocks * 512,
          'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'whole_model_transferred': False,
          'payload_verification': 'Four exact original offset SHA256 plus original header PASS',
          'gguf_sha256': hashlib.sha256((gguf / 'mixed-fixture.gguf').read_bytes()).hexdigest()}
(root / 'transfer-verification.json').write_text(json.dumps(record, indent=2)); print(json.dumps(record, indent=2))
