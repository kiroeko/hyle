"""Six single-use functional consumers. Parsing existing output never runs it."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('history_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
OLD_PARSER = R / '.scratch/inference-mtp-logits-20261028/refinement/run.py'
ARMS = {'history-cpu': ('cpu', '--history-logits'), 'history-cuda': ('cuda', '--history-logits'),
    'ordinary-history-cpu': ('cpu', '--history-ordinary'), 'ordinary-history-cuda': ('cuda', '--history-ordinary'),
    'logits-cpu': ('cpu', '--mtp-logits'), 'logits-cuda': ('cuda', '--mtp-logits')}


def prepare():
    b.prepared()
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', parser=t.pin(W / 'run.py'),
        fixture=t.pin(FIXTURE / 'weights.tsv'), regression_parser=t.pin(OLD_PARSER), order=list(ARMS),
        arms={arm: dict(backend=backend, flag=flag, output=str(W / 'runs' / arm)) for arm, (backend, flag) in ARMS.items()},
        planned_processes=6, CPU_processes=3, CUDA_processes=3, models_per_process=1,
        runtime=t.pin(W / 'runtime-plan.json'),
        expected_reports={'--history-logits':['history-finite-math', 'history-logits'],
            '--history-ordinary':['history-logits'], '--mtp-logits':['mtp-logits-modifiers']},
        policy='Each process is attempted once. Preserve failure logs; repair a parser offline rather than rerun a completed process. Validate every reported complete state check; record actual check counts rather than assume a planned count.'))
    print('RUN PLAN ONLY: history, plain ordinary history, and modifier regressions CPU/CUDA; six processes')


def complete_checks(report):
    checks = report['state_checks']; assert checks
    for check in checks:
        assert check['boundary_equal'] is True and check['numerically_equivalent'] is True
        assert check['payloads_byte_equal'] is True and check['differences'] == [], check
    return len(checks)


def history_report(reports, backend, draft):
    assert len(reports) == (2 if draft else 1), len(reports)
    by_case = {report['case']: report for report in reports}
    assert len(by_case) == len(reports)
    assert set(by_case) == ({'history-finite-math', 'history-logits'} if draft else {'history-logits'})
    if draft:
        finite = by_case['history-finite-math']
        assert finite['result'] == 'PASS' and finite['backend'] == backend
        assert (finite['neutral_nodes'], finite['hand_rows'], finite['duplicate_prefix_ids']) == (0, 4, 2)
        for field in ('p_q_bonus', 'negative_counts_rejected', 'masked_raw_nan_rejected',
            'masked_raw_inf_rejected', 'masked_bias_nan_rejected', 'readonly_counts',
            'normalized_q_unchanged', 'count_above_2pow24_exact', 'int32_overflow_rejected', 'managed_commands'):
            assert finite[field] is True, field
    journey = by_case['history-logits']
    assert (journey['status'], journey['backend'], journey['models'], journey['configurations'], journey['final_versions']) == ('PASS', backend, 1, 2, 0)
    assert journey['draft'] is draft and journey['K1_K2_greedy_random'] is draft
    for field in ('derived_vs_manual_B2', 'StateOnly_no_counts_or_draw', 'same_key_HostImage',
        'full_hit_seed_before_frontier', 'synthetic_untrained'):
        assert journey[field] is True, field
    assert journey['quality_claim'] is False and journey['performance_claim'] is False
    complete_checks(journey)
    return by_case


def parse(arm):
    backend, flag = ARMS[arm]; out = W / 'runs' / arm
    process = t.read(out / 'process.json'); assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if flag in ('--history-logits', '--history-ordinary'):
        report = history_report(reports, backend, flag == '--history-logits')
        actual_checks = len(report['history-logits']['state_checks'])
    else:
        spec = importlib.util.spec_from_file_location('history_logits_regression_parser', OLD_PARSER)
        old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
        report = old.modifiers_report(reports, backend)
        actual_checks = complete_checks(report)
    t.save(out / 'report.json', report)
    t.save(out / 'summary.json', dict(status='PASS', arm=arm, process=process, report=t.pin(out / 'report.json'),
        source_freeze=t.pin(W / 'source-freeze.json'), actual_state_checks=actual_checks,
        complete_payloads_byte_equal=True, performance_claim=False))
    print('PASS', arm, 'PID', process['pid'])


def run(arm):
    backend, flag = ARMS[arm]; b.validate(); plan = t.read(W / 'run-plan.json')
    for field in ('parser', 'fixture', 'regression_parser', 'runtime'): t.exact(plan[field])
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image']); t.exact(ready['inputs'])
    native = t.read(plan['runtime']['path'])['native']; t.exact(native)
    source = Path(native['path']); alias = W / 'bin' / source.name
    if not alias.exists(): os.link(source, alias)
    assert os.path.samefile(source, alias)
    out = W / 'runs' / arm; assert not out.exists(), 'Already attempted; parse existing output instead'
    process = t.execute([ready['image']['path'], '--' + backend, str(FIXTURE), flag], out, 300)
    t.save(out / 'as-run.json', dict(ready=t.pin(W / 'ready-tiny.json'), image=ready['image'], inputs=ready['inputs'],
        source_freeze=ready['source_freeze'], run_plan=t.pin(W / 'run-plan.json'), environment=t.pin(W / 'environment.json'),
        runtime_source=native, runtime_alias=str(alias), same_file=True, process=process))
    parse(arm)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
