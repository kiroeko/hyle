"""One canonical include-Model TU; retain the actual Phase 228-input closure."""
from pathlib import Path
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-phase-carrier-20261028'
SOURCE = 'tests/tools/qwen_host_image_test.cc'
spec = importlib.util.spec_from_file_location('history_build_tools', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W


def prepare():
    ready = t.read(BASE / 'ready-tiny.json'); t.exact(ready['inputs'])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 228
    actual = t.read(ready['compiled']['dependencies']['path'])['Data']
    assert t.key(actual['Source']) == t.key(R / SOURCE)
    original = ready['compiled']['object']
    assert sum(t.key(row['path']) == t.key(original['path']) for row in rows) == 1
    weights = t.read(BASE / 'plan.json')['weights_retained']
    assert weights['object'] in rows
    assert t.key(t.read(weights['dependencies']['path'])['Data']['Source']) == t.key(R / 'engine/models/qwen35/weights.cc')
    t.exact(weights['source'])
    before = t.command(ready['compiled']['command']['path']); args = []
    for at, arg in enumerate(before):
        if t.key(arg) == t.key(actual['Source']): arg = str(R / SOURCE)
        elif at and before[at - 1].lower() == '/sourcedependencies': arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        args.append(arg)
    assert '/MD' in args and '/O2' in args and sum(t.key(arg) == t.key(R / SOURCE) for arg in args) == 1
    t.save(W / 'recipe-tiny.json', dict(command=args, timeout_seconds=300))
    link = []
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg) == t.key(original['path']): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/MAP:', '.map'), ('/IMPLIB:', '.lib')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/tiny/unit.obj') for arg in link) == 1
    t.save(W / 'link-tiny.json', dict(command=link, timeout_seconds=240))
    stats = []
    for row in rows:
        path = Path(row['path']); st = path.stat(); assert st.st_size == row['bytes'], path
        stats.append(dict(path=str(path), bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(BASE / 'environment.json'); assert set(env) <= {'PATH', 'INCLUDE', 'LIB', 'LIBPATH'}
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']; t.save(W / 'environment.json', env)
    t.save(W / 'runtime-plan.json', dict(native=t.read(BASE / 'runtime-plan.json')['native'],
        method='Original CPU DLL same-file hardlink beside Tiny; no DLL/SDK/payload copy',
        planned_processes=6, CPU_processes=3, CUDA_processes=3,
        scope='History draft, plain ordinary history, and neutral mtp-logits each CPU/CUDA; six processes and one Tiny build'))
    t.save(W / 'plan.json', dict(status='PREPARED_NOT_SOURCE_FROZEN', baseline=t.pin(BASE / 'ready-tiny.json'),
        inputs=ready['inputs'], original_object=original, source=str(R / SOURCE),
        recipe=t.pin(W / 'recipe-tiny.json'), link=t.pin(W / 'link-tiny.json'), old_dependencies=ready['compiled']['dependencies'],
        weights_retained=weights, retained_stats=t.pin(W / 'retained-input-stats.json'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime-plan.json'),
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, downloads=0),
        compatibility='Engine Model, sampling graph and ledger/count metadata compile inside Tiny. No public SDK, PreparedWeightSource or retained weights layout change. Replace exactly one actual Tiny object; retain weights and the other 226 input identities. This is not a blanket compatibility proof for all project headers.'))
    t.save(W / 'previous-attempt.json', dict(
        original=dict(source_freeze=t.pin(W.parent / 'source-freeze.json'),
            process=t.pin(W.parent / 'logs/tiny/process.json'),
            actual_process=t.read(W.parent / 'logs/tiny/process.json'),
            reason='Finite test used Status as a RetirementObservation; two test-only observation statements were corrected.'),
        refinement=dict(source_freeze=t.pin(W.parent / 'refinement/source-freeze.json'),
            ready=t.pin(W.parent / 'refinement/ready-tiny.json'),
            process=t.pin(W.parent / 'refinement/runs/history-cpu/process.json'),
            actual_process=t.read(W.parent / 'refinement/runs/history-cpu/process.json'),
            stderr=t.pin(W.parent / 'refinement/runs/history-cpu/stderr.log'),
            reason='Actual CPU exited during cold K1 construction: symbolic value required concrete specialization; no consumer JSON. Shared update now supplies explicit logical output specs for existing Gather/Concat/Scan/Scatter.'),
        final=dict(source_freeze=t.pin(W.parent / 'final/source-freeze.json'),
            ready=t.pin(W.parent / 'final/ready-tiny.json'),
            failed_CPU=[dict(arm=arm, process=t.pin(W.parent / 'final/runs' / arm / 'process.json'),
                actual_process=t.read(W.parent / 'final/runs' / arm / 'process.json'))
                for arm in ('history-cpu','ordinary-history-cpu','logits-cpu')],
            reasons=['Expected CPU checked overflow can return synchronously from submit; preserve the same OutOfRange proof at either submit or Completion.',
                'The ordinary consumer used an MTP-only snapshot helper which read a nonexistent draft frame; snapshot collection now follows actual draft capability.',
                'The original neutral test matches the modifiers rejection message; only that diagnostic wording is restored.']),
        checks=dict(source_freeze=t.pin(W.parent / 'checks/source-freeze.json'),
            compile_process=t.pin(W.parent / 'checks/logs/tiny/process.json'),
            actual_process=t.read(W.parent / 'checks/logs/tiny/process.json'),
            reason='Only the test conditional expression Status versus ResultError was ambiguous in MSVC; explicit Status and if/else preserve the same original failure observation.',
            linked=False, model_processes=0),
        retained='Every old source/command/log/image/OBJ is preserved; no old failed object or image is used in this new link.'))
    print('PREPARED ONLY: independent verified Tiny CXX/link and six consumers; not source frozen')


def prepared():
    plan = t.read(W / 'plan.json')
    for field in ('baseline', 'inputs', 'recipe', 'link', 'old_dependencies', 'retained_stats', 'environment', 'runtime'): t.exact(plan[field])
    return plan


def freeze():
    plan = prepared(); expected = t.read(W / 'expected-sources.json')
    assert {SOURCE, 'engine/models/qwen35/main.cc', 'engine/models/qwen35/generation_ledger.h',
        'engine/inference/history_counts.h', 'engine/inference/sampling_graph.h',
        'tests/tools/inference_history_math_case.h', 'tests/tools/qwen_history_logits_case.h'} <= set(expected)
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    paths = {t.key(t.canonical(p)): t.canonical(p) for p in t.dep_paths(plan['old_dependencies']['path']) if t.project(t.canonical(p))}
    pending = [R / relative for relative in expected]; seen = set(); roots = [R / 'include', R]
    roots += [Path(arg[2:]) for arg in t.command(plan['recipe']['path']) if arg.lower().startswith('/i')]
    while pending:
        path = pending.pop().resolve()
        if t.key(path) in seen: continue
        seen.add(t.key(path)); paths[t.key(path)] = path
        for include in re.findall(r'^\s*#\s*include\s*"([^"\r\n]+)"', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((q.resolve() for root in [path.parent, *roots] if (q := root / include).is_file()), None)
            if found and t.project(found): pending.append(found)
    t.save(W / 'project-dependencies.json', [t.pin(path) for path in paths.values()])
    snapshots = []
    for relative in expected:
        source, target = R / relative, W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / 'source-freeze.json', dict(expected=t.pin(W / 'expected-sources.json'), helper=t.pin(W / 'build.py'),
        snapshots=snapshots, project_dependencies=t.pin(W / 'project-dependencies.json')))
    print('SOURCE FROZEN ONLY')


def validate():
    plan = prepared(); frozen = t.read(W / 'source-freeze.json')
    for field in ('expected', 'helper', 'project_dependencies'): t.exact(frozen[field])
    for row in frozen['snapshots']: t.exact(row['original']); t.exact(row['snapshot'])
    return plan, frozen


def compile_tiny():
    plan, frozen = validate()
    allowed = {t.key(row['path']): row for row in t.read(frozen['project_dependencies']['path'])}
    for row in allowed.values(): t.exact(row)
    out = W / 'compile/tiny'; out.mkdir(parents=True, exist_ok=False)
    proc = t.execute(t.command(plan['recipe']['path']), W / 'logs/tiny', 300)
    validate(); actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('unfrozen include', str(path))
            t.exact(allowed[t.key(path)]); actual.append(t.pin(path))
    t.save(out / 'actual-project-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / SOURCE), object=t.pin(out / 'unit.obj'),
        command=t.pin(W / 'logs/tiny/command.json'), dependencies=t.pin(out / 'dependencies.json'), process=proc))
    print('CXX PASS tiny')


def link_tiny():
    plan, _ = validate(); compiled = t.read(W / 'compile/tiny/compiled.json'); t.exact(compiled['object'])
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    rows = [compiled['object'] if t.key(row['path']) == t.key(plan['original_object']['path']) else row for row in t.read(plan['inputs']['path'])]
    assert len(rows) == 228 and plan['weights_retained']['object'] in rows
    (W / 'bin').mkdir(exist_ok=True); assert not (W / 'bin/tiny.exe').exists()
    t.save(W / 'inputs-tiny.json', rows)
    proc = t.execute(t.command(plan['link']['path']), W / 'link/tiny', 240)
    t.save(W / 'ready-tiny.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=t.pin(W / 'inputs-tiny.json'),
        compiled=compiled, recipe=t.pin(W / 'link/tiny/command.json'), process=proc,
        plan=t.pin(W / 'plan.json'), source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS tiny')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'compile': compile_tiny()
    elif action == 'link': link_tiny()
    else: raise ValueError(action)
