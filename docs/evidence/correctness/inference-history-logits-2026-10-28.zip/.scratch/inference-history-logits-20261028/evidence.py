"""Offline bounded history-logits evidence. Never builds, runs or deletes files."""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
PREVIOUS = W / 'final'
CHECKS = W / 'checks'
VERIFIED = W / 'verified'
FINAL = W / 'math-retirement'
PHASE = R / '.scratch/inference-phase-carrier-20261028'
DEST = R / 'docs/evidence/correctness/inference-history-logits-2026-10-28'
ARMS = ('history-cpu', 'history-cuda', 'ordinary-history-cpu', 'ordinary-history-cuda', 'logits-cpu', 'logits-cuda')


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def exact(row):
    path = Path(row['path']); path = path if path.is_absolute() else R / path
    current = pin(path)
    assert (current['bytes'], current['sha256']) == (row['bytes'], row['sha256']), row['path']
def proc(path, label):
    result = read(path)
    assert result['state'] == 'TERMINAL' and result['exit'] is not None, (label, result)
    return dict(label=label, **result)


def complete_checks(report):
    checks = report['state_checks']; assert checks
    return len(checks), all(check['boundary_equal'] is True and check['numerically_equivalent'] is True
        and check['payloads_byte_equal'] is True and check['differences'] == [] for check in checks)


def main():
    # Invoke only after the root has inspected the actual runs. No planned run
    # or missing receipt can be promoted to a successful process here.
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    run_roots = {arm: FINAL if arm.startswith('history-') else VERIFIED for arm in ARMS}
    for arm, root in run_roots.items(): assert (root / 'runs' / arm / 'process.json').is_file(), ('not attempted', arm)
    frozen = read(FINAL / 'source-freeze.json'); expected = read(FINAL / 'expected-sources.json')
    assert len(expected) == 7
    for row in frozen['snapshots']: exact(row['snapshot']); exact(row['original'])
    CXX = [proc(root / 'logs/tiny/process.json', label) for root, label in
        ((W, 'original'), (W / 'refinement', 'refinement'), (PREVIOUS, 'final'), (CHECKS, 'checks'),
         (VERIFIED, 'verified'), (FINAL, 'math-retirement'))]
    links = [proc(root / 'link/tiny/process.json', label) for root, label in
        ((W / 'refinement', 'refinement'), (PREVIOUS, 'final'), (VERIFIED, 'verified'), (FINAL, 'math-retirement'))]
    cold_failure = proc(W / 'refinement/runs/history-cpu/process.json', 'refinement-history-cpu')
    previous_failures = [proc(PREVIOUS / 'runs' / arm / 'process.json', 'final-' + arm)
        for arm in ('history-cpu', 'ordinary-history-cpu', 'logits-cpu')]
    assert CXX[0]['pid'] == 41832 and CXX[0]['exit'] == 2
    assert CXX[3]['pid'] == 44912 and CXX[3]['exit'] == 2
    assert cold_failure['pid'] == 48268 and cold_failure['exit'] == 1
    assert [(p['pid'], p['exit']) for p in previous_failures] == [(54360, 1), (42268, 1), (56504, 1)]
    verified_failure = proc(VERIFIED / 'runs/history-cpu/process.json', 'verified-history-cpu')
    assert (verified_failure['pid'], verified_failure['exit']) == (40508, 1)
    baseline = read(PHASE / 'ready-tiny.json'); exact(baseline['inputs'])
    old_rows = read(baseline['inputs']['path']); assert len(old_rows) == 228
    plan = read(FINAL / 'plan.json'); weights = plan['weights_retained']
    images = {}
    for root in (VERIFIED, FINAL):
        ready = read(root / 'ready-tiny.json'); exact(ready['inputs'])
        rows = read(ready['inputs']['path']); assert len(rows) == 228 and weights['object'] in rows
        assert [row for row in rows if row != ready['compiled']['object']] == [
            row for row in old_rows if row != baseline['compiled']['object']]
        images[root.name] = dict(image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'])
    assert CXX[-1]['exit'] == 0 and links[-1]['exit'] == 0
    runs = []; final_pass = True
    for arm in ARMS:
        root = run_roots[arm]; out = root / 'runs' / arm; actual = proc(out / 'process.json', arm)
        native_pass = actual['exit'] == 0 and not actual['timed_out']
        parsed_pass = (out / 'summary.json').is_file() and read(out / 'summary.json')['status'] == 'PASS'
        facts = {}; checked = False
        if native_pass and parsed_pass:
            report = read(out / 'report.json')
            if arm.startswith('logits-'):
                assert report['case'] == 'mtp-logits-modifiers' and report['status'] == 'PASS'
                n, checked = complete_checks(report)
                facts = dict(draft=True, complete_initialized_state_checks=n, all_payloads_byte_equal=checked,
                    neutral_history_original_modifiers_regression=True, final_versions=report['final_versions'])
            else:
                draft = arm.startswith('history-'); journey = report['history-logits']
                assert journey['status'] == 'PASS' and journey['draft'] is draft
                n, checked = complete_checks(journey)
                facts = dict(draft=draft, complete_initialized_state_checks=n, all_payloads_byte_equal=checked,
                    derived_vs_manual_B2=journey['derived_vs_manual_B2'],
                    partial_StateOnly_without_counts_or_draw=journey['StateOnly_no_counts_or_draw'],
                    same_key_HostImage=journey['same_key_HostImage'],
                    full_hit_seed_before_frontier=journey['full_hit_seed_before_frontier'],
                    K1_K2_greedy_random=journey['K1_K2_greedy_random'], final_versions=journey['final_versions'])
                if draft:
                    finite = report['history-finite-math']; assert finite['result'] == 'PASS'
                    facts['finite_math'] = dict(original_Graph_submissions=8, additional_Models=0,
                        neutral_nodes=finite['neutral_nodes'], hand_rows=finite['hand_rows'],
                        duplicate_prefix_ids=finite['duplicate_prefix_ids'], p_q_bonus=finite['p_q_bonus'],
                        I32_above_2pow24_exact=finite['count_above_2pow24_exact'], I32_overflow_rejected=finite['int32_overflow_rejected'],
                        readonly_counts=finite['readonly_counts'], normalized_q_unchanged=finite['normalized_q_unchanged'])
            assert facts['final_versions'] == 0
        passed = native_pass and parsed_pass and checked
        final_pass = final_pass and passed
        runs.append(dict(arm=arm, pid=actual['pid'], exit=actual['exit'], seconds=actual['seconds'],
            actual_image=root.name, native_pass=native_pass, parsed_pass=parsed_pass, complete_byte_comparison_pass=checked, facts=facts))
    references = [R / 'docs/evidence/correctness/inference-phase-carrier-2026-10-28.json',
        R / 'docs/evidence/correctness/inference-phase-carrier-2026-10-28.zip']
    evidence = dict(status='PASS_BOUNDED_HISTORY_LOGITS' if final_pass else 'FAILED_HISTORY_LOGITS_CHECK',
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        base=read(W / 'product/source-freeze.json')['base_commit'],
        implementation=[
            'LogitsPolicy.history is the sole repetition/presence/frequency policy. Empty history preserves the original graph and creates no counts cache or snapshot pool.',
            'Natural C0 derives from authoritative committed_ids plus the actual first conditional input. A metadata-budgeted ledger cache processes only newly committed records; temporary current-input increments roll back after the synchronous upload.',
            'C0 is a readonly exact I32[1,V] lease from the original bounded active-cohort pool. Full prefix hits seed it before frontier sampling; StateOnly creates no history input or draw; completed calls release C0.',
            'Existing checked Gather, exact I32 Scan+1 and Scatter Assign return a new hypothesis count row. Target prefixes advance original proposal IDs; normalized q inputs are never transformed twice. NextN keeps only current counts with two original output blocks for old-read/new-write overlap.',
            'The shared update declares fixed logical output specs explicitly, so symbolic source views are specialized by the original exact child without a premature concrete-layout lookup.'],
        counts=dict(actual_CXX=len(CXX), successful_CXX=sum(p['exit'] == 0 for p in CXX), failed_CXX=sum(p['exit'] != 0 for p in CXX),
            actual_links=len(links), successful_links=sum(p['exit'] == 0 for p in links),
            actual_model_processes=2 + len(previous_failures) + len(runs), successful_final_processes=sum(r['native_pass'] for r in runs),
            prior_failed_model_processes=2 + len(previous_failures), final_failed_model_processes=sum(not r['native_pass'] for r in runs),
            SDK_CXX=0, NVCC=0, downloads=0, automatic_reruns=0),
        build=dict(CXX=CXX, links=links, actual_successful_consumer_images=images,
            inputs_per_link=228, replaced_private_objects_per_link=1, retained_weights=weights['object']),
        prior_failures=[dict(stage='original CXX', pid=41832, exit=2,
            cause='The finite test treated Backend::drain_retired(Invocation&) Status as a RetirementObservation and accessed .retired.',
            correction='Test-only: check the original Status, then require !run.in_flight(). No product numeric or retirement contract changed.', native_processes=0),
            dict(stage='refinement cold construction', pid=48268, exit=1,
            cause='The actual history CPU consumer stopped in cold K1 graph construction: an inferred view reached a concrete-layout shortcut before specialization. No consumer JSON was emitted.',
            correction='Product shared graph builder: explicit logical output specs for the existing Gather/Concat/Scan/Scatter. Operators, integer update and penalty arithmetic are unchanged.'),
            dict(stage='final history CPU', pid=54360, exit=1,
            cause='The intended INT32 overflow arrived synchronously as CPU submit OutOfRange; the finite test incorrectly required a Completion handle first.',
            correction='Test-only: inspect the same original OutOfRange from either submit or Completion, retain unusable output, readonly input and true-retirement assertions.'),
            dict(stage='final ordinary-history CPU', pid=42268, exit=1,
            cause='A reused MTP StateImage helper unconditionally read draft frames on the intentionally draft-free ordinary Model.',
            correction='Test-only: collect complete target/state/hidden snapshot bytes according to the actual draft capability, without adding a draft bank or changing Model route gates.'),
            dict(stage='final neutral modifier CPU', pid=56504, exit=1,
            cause='The original strict replay rejection test expected the word modifiers in its error text; the new diagnostic had removed that word.',
            correction='Diagnostic-only product wording restores external logits modifiers. Rejection, mathematical policy, state and runtime behavior are unchanged.'),
            dict(stage='checks CXX', pid=44912, exit=2,
            cause='The finite test conditional expression mixed Status and ResultError conversion routes and was ambiguous in MSVC.',
            correction='Test-only: explicit hyle::Status and if/else retain the same submit-or-Completion OutOfRange observation. No link or consumer ran for this attempt.',
            native_processes=0),
            dict(stage='verified history CPU', pid=40508, exit=1,
            cause='After the intended checked overflow, drain_retired returned the original terminal nonnative OutOfRange; the test incorrectly required a successful drain Status.',
            correction='Test-only: accept that same expected nonnative OutOfRange during retirement while retaining the explicit !run.in_flight proof. The four already successful verified ordinary/modifier processes are reused, not rerun.')],
        runs=runs, source_pins=expected, final_source_freeze=pin(FINAL / 'source-freeze.json'),
        actual_project_dependencies={root.name:pin(root / 'compile/tiny/actual-project-dependencies.json') for root in (VERIFIED, FINAL)},
        compiler_dependencies={root.name:pin(root / 'compile/tiny/dependencies.json') for root in (VERIFIED, FINAL)},
        dependency_boundary='One canonical include-Model Tiny TU per attempt; the actual Phase 228-input closure changes only that private object. Retain the original independent target/draft weights object and public SDK objects. Changed engine-private declarations compile inside Tiny. This is not a blanket ABI proof for every retained header.',
        limits=[
            'Successful coverage combines four verified-image consumers with two math-retirement-image history consumers. Only an unused finite-math test retirement statement changes between those images; these are not six runs of a single new image.',
            'CPU/CUDA cached synthetic GA/H64/V64/C16 consumers only; no trained-model quality, real model EOS, all-shape/dtype, other-native-platform or throughput claim.',
            'History counts use the natural full consumed context plus actual conditioning input, not a claim of matching an output-only presence/frequency API scope.',
            'The complete 4*V-byte C0 row is synchronously uploaded for each relevant output episode. No sparse-update or zero-transfer claim. History execution uses Commands; Managed Scan capture is not claimed.',
            'I32 hypothesis updates are exact, including above 2^24 and checked INT32_MAX overflow. Penalty arithmetic still converts counts to original F32 logits arithmetic; it does not promise integer-exact frequency multiplication above 2^24.',
            'History-only strict ledger replay is wired and statically reviewed but not exercised by these consumers. Same-key partial HostImage restoration and consumed-prefix/frontier behavior are exercised; bare HostImage cannot supply missing token IDs.',
            'Native fault, unknown retirement, history-specific cancellation rollback, all-request eviction and all platform combinations were not injected or exhausted here. Per-process durations are provenance, not a speed measurement.'],
        references=[pin(path) for path in references],
        reproduction=dict(build=(FINAL / 'build.py').relative_to(R).as_posix(), run=(FINAL / 'run.py').relative_to(R).as_posix(),
            actions=['build.py prepare', 'build.py freeze', 'build.py compile', 'build.py link', 'run.py run ARM', 'run.py parse ARM'],
            new_arms=['history-cpu','history-cuda'], reused_verified_arms=[a for a in ARMS if not a.startswith('history-')],
            note='Original attempted paths are single-use. Four successful verified processes are kept; parse existing output offline rather than rerunning a successful native process.'),
        raw_manifest='manifest.json')
    members = {}; allowed = {'.py', '.json', '.h', '.cc', '.diff', '.log', '.xml'}
    def add(path):
        path = Path(path); assert path.is_file() and path.suffix.lower() in allowed, path
        name = path.relative_to(R).as_posix()
        if name not in members: members[name] = path.read_bytes()
    top = ('build.py', 'run.py', 'evidence.py', 'plan.json', 'environment.json', 'runtime-plan.json', 'runtime-plan-six.json',
        'run-plan.json', 'recipe-tiny.json', 'link-tiny.json', 'expected-sources.json', 'source-freeze.json',
        'project-dependencies.json', 'retained-input-stats.json', 'previous-attempt.json',
        'test-refinement.diff', 'source-refinement.diff', 'ready-tiny.json', 'inputs-tiny.json')
    for root in (W, W / 'refinement', PREVIOUS, CHECKS, VERIFIED, FINAL):
        for name in top:
            if (root / name).is_file(): add(root / name)
        for sub in ('logs', 'compile', 'link', 'runs'):
            for path in sorted((root / sub).rglob('*')):
                if path.is_file() and path.suffix.lower() in allowed: add(path)
    for row in frozen['snapshots']: add(row['snapshot']['path'])
    # Preserve both kinds of rejected source without copying seven files for
    # every attempt or importing any cached SDK/header/model tree.
    add(W / 'source/tests/tools/inference_history_math_case.h')
    add(W / 'refinement/source/engine/inference/sampling_graph.h')
    for relative in ('engine/models/qwen35/main.cc', 'tests/tools/inference_history_math_case.h',
        'tests/tools/qwen_history_logits_case.h'):
        add(PREVIOUS / 'source' / relative)
    add(CHECKS / 'source/tests/tools/inference_history_math_case.h')
    add(VERIFIED / 'source/tests/tools/inference_history_math_case.h')
    for path in (W / 'product/source-freeze.json', W / 'product/product.diff',
        PHASE / 'ready-tiny.json', PHASE / 'inputs-tiny.json', PHASE / 'plan.json',
        R / '.scratch/inference-indexed-store-20261028/build.py',
        R / '.scratch/inference-mtp-logits-20261028/refinement/run.py', references[0]): add(path)
    members['evidence-core.json'] = encoded(evidence)
    members['manifest.json'] = encoded(dict(files=[dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        for name, raw in sorted(members.items())], excluded=['EXE/OBJ/EXP/LIB/PDB/DLL', 'SDK/model/weights payload',
        'copied SDK/header trees', 'unrelated docs/license and editing scripts']))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(members.items()): archive.writestr(name, raw)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None
        manifest = json.loads(archive.read('manifest.json'))
        for row in manifest['files']:
            raw = archive.read(row['path'])
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
    evidence['archive'] = dict(**pin(DEST.with_suffix('.zip')), files=len(members), CRC_and_member_SHA256_verified=True)
    DEST.with_suffix('.json').write_bytes(encoded(evidence))
    print(json.dumps(dict(summary=pin(DEST.with_suffix('.json')), archive=evidence['archive'], counts=evidence['counts']), indent=2))


if __name__ == '__main__': main()
