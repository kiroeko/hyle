"""Repair harness. Snapshot now; compilation/link wait for root final freeze."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,importlib.util,json,os,shutil,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-target-graph-boundary-20261030/model-link-base.json'
DIAG=R/'.scratch/inference-graph-alias-harness-20261030'
REGION=R/'.scratch/inference-physical-spans-20261028/validation/refinement/logs/region-test/command.json'
spec=importlib.util.spec_from_file_location('repair_diagnostic_build',DIAG/'build.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
s=d.s;s.W=s.b.W=W
read,save,pin,exact,key=d.read,d.save,d.pin,d.exact,d.key
def command_sources(args):
 return [arg for arg in args if arg.lower().endswith(('.cc','.cpp','.cxx','.c'))]
def snapshot():
 assert not (W/'baseline-plan.json').exists()
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();base=read(BASE)
 assert head=='ec4b30b4dd58e09594822882e4689d78835dc4d7' and len(base['retained'])==229
 diag=read(DIAG/'compile/sdk/receipt.json');diag_plan=read(DIAG/'plan.json')
 for item in [*base['retained'],base['runtime'],diag['object'],*diag['source_identities']]:exact(item)
 graph=R/'src/graph/executable.cc';assert pin(graph)['sha256']=='8ac9a094320db5022ad1b7bd75cc48d73a41d875ffffc2516e4c9c9913c77c21'
 data=subprocess.check_output(['git','show',head+':src/graph/executable.cc'],cwd=R)
 old=diag_plan['freeze_precondition_proofs'][0]['original']
 assert hashlib.sha256(data).hexdigest()==old['sha256'] and len(data)==old['bytes']
 old_source=W/'baseline-source/original/src/graph/executable.cc';old_source.parent.mkdir(parents=True,exist_ok=True);old_source.write_bytes(data)
 copies=[]
 for relative in ('src/graph/executable.cc','tests/graph/region_provider_test.cc','src/graph/plan_state.h','src/graph/input_sources.h',
  'include/hyle/graph/executable.h','include/hyle/graph/detail/region_access.h'):
  source=R/relative;target=W/'baseline-source/diagnostic'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
  copies.append(dict(original=pin(source),snapshot=pin(target)))
 consumers={}
 for name in ('tiny','cli','session'):
  row=base['current_consumers'][name];receipt=read(row['receipt']['path']);exact(row['receipt']);exact(receipt['object'])
  for item in receipt['source_identities']:exact(item)
  consumers[name]=dict(receipt=row['receipt'],object=receipt['object'],source_identities=receipt['source_identities'])
 region=read(REGION)['command'];sources=command_sources(region)
 assert sources==[str(R/'tests/graph/region_provider_test.cc')] and '/c' in region
 assert not any(arg.lower()=='/link' or (arg.lower().endswith('.lib') and not arg.startswith('/')) for arg in region)
 assert not any(arg.lower().endswith('.obj') and not arg.lower().startswith('/fo') for arg in region)
 gtest=[R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib',R/'.scratch/build-compute-v2-dev/lib/gtest.lib']
 for path in gtest:assert path.is_file()
 save(W/'baseline-plan.json',dict(status='BASELINE_SNAPSHOT_ONLY_NO_BUILD_LINK_NATIVE',base_commit=head,base=pin(BASE),retained=base['retained'],
  runtime=base['runtime'],original_graph_object=diag_plan['original_object'],original_graph_source=old,
  original_graph_snapshot=pin(old_source),diagnostic_graph_receipt=pin(DIAG/'compile/sdk/receipt.json'),
  diagnostic_graph_object=diag['object'],diagnostic_graph_source=pin(graph),diagnostic_snapshot_files=copies,
  consumers=consumers,original_link=base['link'],original_consumer=base['current_consumers']['cli']['object'],
  graph_compile_recipe=diag_plan['original_recipe'],graph_compile=read(diag_plan['original_recipe']['path']),
  region_compile_recipe=pin(REGION),region_compile=region,gtest_libraries=[pin(path) for path in gtest],
  region_recipe_proof=dict(single_TU=True,compile_only=True,source_count=1,sources=sources,compiler=region[0],
   link_driver=False,Graph_source_compiled_by_region_recipe=False),
  planned_CXX=dict(Graph_SDK=1,region_test=1,tiny=0,cli=0,session=0,NVCC=0,max_compilers=2),
  scope='Oldtarget229 functional baseline remains distinct from diagnostic8ac SDK object. No fullSDK rebuild or region driver compiling multiple sources. Future native cases need explicit root selection; no matrix is started.'))
 print('SNAPSHOT229 originalGraph+diag separately;region /c exactly1TU;3cached consumers current;no build/link/native.')
def prepare(freeze_path):
 assert not (W/'plan.json').exists()
 baseline=read(W/'baseline-plan.json');freeze=read(freeze_path);assert freeze['sources']
 frozen=set()
 for item in freeze['sources']:exact(item);frozen.add(key(item['path']))
 changed=subprocess.check_output(['git','diff','--name-only','--','src','include','engine','tests'],cwd=R,text=True).splitlines()
 assert set(changed)=={'src/graph/executable.cc','tests/graph/region_provider_test.cc'},changed
 assert {key(R/path) for path in changed}<=frozen
 base=read(baseline['base']['path']);sdk=read(base['sdk_engine_dependencies']['path']);affected=[]
 for row in sdk['inspected']:
  dep=read(row['dependencies']['path'])['Data']
  if any(key(path) in frozen for path in [dep['Source'],*dep['Includes']]):affected.append(row)
 assert len(affected)==1 and key(affected[0]['object'])==key(baseline['original_graph_object']['path'])
 for name,row in baseline['consumers'].items():
  for item in [row['object'],*row['source_identities']]:exact(item)
 raw=baseline['graph_compile'];raw=raw if isinstance(raw,list) else raw['command']
 assert command_sources(raw)==[str(R/'src/graph/executable.cc')] and '/c' in raw
 graph=s.relocated(raw,'sdk');region=s.relocated(baseline['region_compile'],'region')
 assert command_sources(region)==[str(R/'tests/graph/region_provider_test.cc')] and '/c' in region
 save(W/'plan.json',dict(status='PREPARED_AFTER_FREEZE_NOT_BUILT',baseline=pin(W/'baseline-plan.json'),source_freeze=pin(freeze_path),
  units=dict(sdk=dict(source=str(R/'src/graph/executable.cc'),compile=graph),
   region=dict(source=str(R/'tests/graph/region_provider_test.cc'),compile=region)),
  affected_retained_dependency_rows=affected,available_dependency_rows=len(sdk['inspected']),
  unavailable_dependency_metadata=sdk['unavailable'],unchanged_retained=228,
  max_compilers=2,SDK_CXX=1,testTU_CXX=1,consumer_CXX=0,retained=229,NVCC=0,downloads=0))
 (W/'bin').mkdir(exist_ok=True);runtime=baseline['runtime'];exact(runtime);shutil.copyfile(runtime['path'],W/'bin'/Path(runtime['path']).name)
 print('PREPARED afterfreeze onlyGraph1+test1;no execution.')
def compile(attempt,names):
 p=read(W/'plan.json');assert set(names)<={'sdk','region'}
 def one(name):
  unit=p['units'][name];s.b.execute(unit['compile'],W/'compile'/name/attempt,600)
  dep=read(W/'compile'/name/'dependencies.json')['Data']
  paths=sorted({Path(path).resolve() for path in [dep['Source'],*dep['Includes']] if Path(path).is_relative_to(R)})
  save(W/'compile'/name/'receipt.json',dict(object=pin(W/'compile'/name/'unit.obj'),dependencies=pin(W/'compile'/name/'dependencies.json'),
   process=pin(W/'compile'/name/attempt/'process.json'),source_identities=[pin(path) for path in paths]))
 with ThreadPoolExecutor(max_workers=2) as pool:
  futures={pool.submit(one,name):name for name in names}
  for future in as_completed(futures):future.result();print('COMPILED',futures[future],flush=True)
def link(name,attempt,baseline_arm=False):
 p=read(W/'baseline-plan.json')
 consumer=read(W/'compile/region/receipt.json') if name=='region' else p['consumers'][name]
 replacement=None
 if not baseline_arm:
  sdk_receipt=read(W/'compile/sdk/receipt.json');replacement=sdk_receipt['object']
  for item in sdk_receipt['source_identities']:exact(item)
 for item in [consumer['object'],*consumer['source_identities'],*p['retained']]:exact(item)
 if replacement:exact(replacement)
 stem=('baseline-' if baseline_arm else '')+name
 output_stem=stem if attempt=='attempt1' else stem+'-'+attempt
 args=[];count=changed=0
 for arg in p['original_link']:
  if key(arg)==key(p['original_consumer']['path']):arg=consumer['object']['path'];count+=1
  if replacement and key(arg)==key(p['original_graph_object']['path']):arg=replacement['path'];changed+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/output_stem).with_suffix(suffix));break
  args.append(arg)
 assert count==1 and changed==(0 if baseline_arm else 1)
 if name=='region':
  for library in p['gtest_libraries']:exact(library);args.append(library['path'])
 assert not command_sources(args),'Link must never compile sourceTUs or drive a fullSDK build.'
 s.b.execute(args,W/'link'/stem/attempt,240);save(W/('ready-'+stem+'.json'),pin(W/'bin'/(output_stem+'.exe')))
def run(case,attempt,baseline_arm=False):
 row=read(W/'whole-plan.json')['cases'][case]
 stem=('baseline-' if baseline_arm else '')+row['consumer'];image=read(W/('ready-'+stem+'.json'));exact(image)
 folder=W/'runs'/('baseline' if baseline_arm else 'candidate')/case/attempt;save(folder/'image.json',image)
 args=[str(folder/'vectors') if arg=='{OUTPUT}' else arg for arg in row['args']]
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
 s.b.execute([image['path'],*args],folder,600)
 text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();values=[];offset=0
 while offset<len(text):
  while offset<len(text) and text[offset].isspace():offset+=1
  if offset==len(text):break
  value,offset=decoder.raw_decode(text,offset);values.append(value)
 assert len(values)==1,values
 result=values[0]
 if 'outputs' in row:assert result['generated_tokens']==row['outputs'] and result['live_committed_versions']==0
 else:assert result['status']=='MTP_SESSION_PROBE_COMPLETED'
 save(folder/'report.json',result);print('PASS',stem,case,flush=True)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='snapshot':snapshot()
 elif action=='prepare':prepare(Path(sys.argv[2]).resolve())
 elif action=='compile':compile(sys.argv[2],sys.argv[3:])
 elif action=='link':link(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='baseline')
 elif action=='run':run(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='baseline')
 else:raise ValueError(action)
