# Alias repair：实际计划事实的观测边界（只读检查说明）

当前仅检查现有代码/历史报告，没有运行或构建。默认消费者与数值／Session检查继续使用原无trace参数；本片不追加route trace进程，不新增用户开关、profiling或全模型consumer。

## 现有入口能直接证明什么

| 入口 | 实际可见事实 | 不能据此声称 |
| --- | --- | --- |
| 默认CLI／tiny `--engine` JSON | generated IDs、RNG/接受与调用工作量、graph calls、缓存与资源计数；CPUFFN另有workspace_domains峰值 | 没有copy步骤、copy bytes、provider路线、region/leaf逐项、replica逐项；全部非计时JSON相同只表示这些汇总字段相同，不能写逐provider相同 |
| `compiled text finite family` stderr | 子variant数量、total_compiled_storage的known bytes/unknown provider count、总搜索事实 | parent没有单一执行route；汇总相同不代表每child和每provider相同 |
| `compiled T=...` stderr（prepare_child后） | 该实际Phase所选child的step_count、workspace/slot、compiled_known_bytes、unknown provider count | 只覆盖真正prepare_child的Phase；日志没有完整FamilyKey/child索引，不能凭T唯一化全部role/packing/completion，也不是copy或provider逐项 |
| 原 `hybrid_plan` stderr | `record_execution_plan`逐Family child调用，给总activation_copy_bytes、materialized_constant_bytes、host_constants和3域workspace；原2target/3domain、host原始常量必须Domain1且无额外canonical materialization的断言先执行 | 只在非零CPUFFN时输出，默认纯GPU会早返；总copy bytes混合CPU传输等原copy，不能全部归因于新alias物化；不含provider私有未知内存 |
| 已有 `*.route.tsv` | 实际Phase child每step的kind、provider.name、implementation ID、逻辑nodes | 缺copy bytes/source/destination storage、replica/workspace逐项、provider完整身份/实例；未必覆盖所有冷child和独立draft/sampling图；文件名不是完整FamilyKey，可能覆盖 |

主要代码位置：`engine/models/qwen35/main.cc` 的 `cache_report`、`record_execution_plan`、Family child循环、`prepare_child` route writer；公开报告接口在 `include/hyle/graph/executable.h`。

## 为什么本片不添加trace对照进程

`--trace DIR --trace-level decisions` 不是纯route导出入口。已有实现把 `trace_states=false`，因此关闭GDN/conv/kv-layout导出；但 `observe_completed_evaluation` 对任何非空trace仍固定dump hidden，logits有效时还dump logits。`evaluation_output` 同时设置 `capture_tensors=true`，会保留/读回输出。没有可独立设置 `model.trace_routes` 的现成用户参数。

不设 `--layer0-probe` 时，这条trace路径没有新增layer0 probe图端口；但额外输出保留、读回与资源行为已不满足本片要求的无tensor读回，所以不作为默认两臂的干净route证据，也不取其计时。`--layer0-probe` 会发布额外probe端口，不能替代本片默认图；`--preparation-diagnostics` 仅适用fixed replay，排除自然请求和MTP，也不是copy/provider报告入口。

route文件的key还只有 default/published、role（MTP时）、可选sampling、R、T，未含完整packing/completion/imported_sources/exact child绑定；即使以后另有授权，也不能把目录内文件数当完整child数或全部provider身份。

## 具体新copy属性放在真实单位fixture的CompileReport

现公开接口已经足够，无需产品观测callback或新consumer。最终测试由root／GLM按实际候选选择，以下是可复用的检查粒度：

1. 有finite exact family时先枚举 `report.exact_variant_count()` 与 `report.exact_variant(i)`，记录child `specialization().binding(j)` 的真实dimension/value。parent的 `step_count/workspace/copy_bytes` 本来可以为空，不是所有child零copy的证据。不要把dimension0的值当作token数，它可能是last_row。
2. 在每child的 `step(i)` 区分 `kProviderRegion`、`kOperationFallback`、`kCopy`、`kView`。检查具体copy step的 `copy_bytes`、source/destination storage、输入／输出physical indices；通过 `step_input/step_output` 与 `physical_value()` 连接真实ValueId、TensorDesc、alias_source、constant、external input/output和workspace_backed属性。same-domain fallback必须仍是一次真实copy，不能仅由copy总计数猜测。
3. 用fixture独立已知的切片shape／dtype计算期望payload字节，不从实现内分支推同一个答案。检查已对齐输入不添加copy；不满足alignment的普通按值tensor可得到独立aligned边界；逻辑Graph原输入／输出与原View语义不改变。断言针对实际CompileReport与实际执行数值／资源退休，而非仅重复实现条件。
4. 检查 `workspace_bytes/storage_domain()` 和 `compiled_storage()` 的已知范围；`constant()`、materialized_constant_count/bytes及 `physical_value.constant/storage` 区分canonical常量副本。零canonical materialization不等于所有provider私有packing或系统内存为零，unknown必须保留。
5. region/leaf路线使用 `region_count/fallback_operation_count`、step.provider/implementation/policy/target/lane和该context要求的provider instance断言；实例是进程内配置slot身份，不拿原始数值作跨进程portable key。对原opaque/native Source身份合同，检查是否仍按原typed拒绝／接受与原readers/lease边界，不能为了物化成功把reference变按值或复制身份资源。

## H64与默认2B的最后措辞边界

- H64修复前没有成功compiled route，只有原两次拒绝和一次带context拒绝。因此不能写“旧copy=0，新copy=N”；真实旧事实是root_offset128不能满足alignment256。修后是否成功、hybrid每child总copy/workspace与unit fixture具体copy属性分别报告。
- 默认2B前后严格比较完整非计时JSON，并保留原stderr的finite family／实际Phase steps、known workspace/compiled storage计数。若相同，表述为输出、RNG、工作／资源汇总与这些已记录计划计数相同；逐provider／全部child copy清单未导出，明确未验证。
- 真实CPUFFN2保留原hybrid_plan host_constants、materialized bytes和域断言；不能扩大为全部混合placement通过。Session保持原无trace参数，完整逻辑向量与元数据比较的既有严格范围不变。

截至此说明，没有新增trace命令或原生运行。构建和有限case仍等待最终freeze与root授权。
