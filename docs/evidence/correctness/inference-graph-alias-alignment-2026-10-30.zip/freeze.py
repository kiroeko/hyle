"""Record exact root-applied candidate and pre-application snapshot proofs."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('repair_freeze_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
assert not (W/'source-freeze.json').exists()
source=R/'.scratch/inference-graph-alias-repair-20261030/plan.json';plan=read(source)
baseline=read(W/'baseline-plan.json');proofs=[];current=[]
for item in plan['preconditions']:
 path=Path(item['path']);actual=pin(path)
 if actual['sha256']==item['sha256'] and actual['bytes']==item['bytes']:proofs.append(dict(original=item,current_exact=True))
 else:
  snapshot=W/'baseline-source/diagnostic'/item['relative'];identity=pin(snapshot)
  assert identity['sha256']==item['sha256'] and identity['bytes']==item['bytes']
  proofs.append(dict(original=item,pre_application_snapshot=identity))
for item in plan['candidate']:
 exact(item);actual=pin(R/item['relative'])
 assert actual['sha256']==item['sha256'] and actual['bytes']==item['bytes']
 current.append(actual)
exact(plan['patch'])
save(W/'source-freeze.json',dict(sources=current,original_candidate_plan=pin(source),precondition_proofs=proofs,
 patch=plan['patch'],status='ROOT_APPLIED_EXACT_TWO_FILES_EIGHT_PRECONDITIONS'))
print('EXACT root freeze2/eight prior identities recorded.')
