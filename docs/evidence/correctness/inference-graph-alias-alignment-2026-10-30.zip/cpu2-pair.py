"""Only approved realCPU2 old229/fixed229 untraced pair."""
from pathlib import Path
import importlib.util,re,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('cpu2_repair_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def stable(value):
 if isinstance(value,dict):return {key:stable(item) for key,item in value.items() if not key.endswith('_seconds') and not key.endswith('_per_second')}
 if isinstance(value,list):return [stable(item) for item in value]
 return value
def delta(a,z,path='$'):
 if isinstance(a,dict) and isinstance(z,dict):return [r for key in sorted(a.keys()|z.keys()) for r in delta(a.get(key),z.get(key),path+'.'+key)]
 if isinstance(a,list) and isinstance(z,list):
  if len(a)!=len(z):return [dict(path=path,old_length=len(a),new_length=len(z))]
  return [r for at,(x,y) in enumerate(zip(a,z)) for r in delta(x,y,path+'['+str(at)+']')]
 return [] if a==z else [dict(path=path,old=a,new=z)]
reports={};plans={}
for arm in ('baseline','candidate'):
 args=[sys.executable,str(W/'build.py'),'run','cpu-ffn-real-cuda','attempt1']+(['baseline'] if arm=='baseline' else [])
 subprocess.run(args,cwd=R,check=True)
 folder=W/'runs'/arm/'cpu-ffn-real-cuda/attempt1';report=b.read(folder/'report.json')
 assert report['cpu_ffn_layers']==2
 stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig');lines=[line for line in stderr.splitlines() if line.startswith('hybrid_plan ')]
 facts=[{key:int(value) for key,value in re.findall(r'(host_constants|materialized_constant_bytes|activation_copy_bytes|known_workspace_device|known_workspace_host|known_workspace_staging)=(\d+)',line)} for line in lines]
 assert facts and all(row['host_constants']>0 for row in facts)
 reports[arm]=report;plans[arm]=dict(raw_lines=lines,facts=facts,original_3_domain_2_target_host_Domain1_assertions_executed=True)
differences=delta(stable(reports['baseline']),stable(reports['candidate']))
plan_differences=delta(plans['baseline'],plans['candidate'])
b.save(W/'compare-cpu-ffn-real-cuda.json',dict(status='PASS' if not differences and not plan_differences else 'FAIL',
 all_non_timing_fields_equal=not differences,differences=differences,hybrid_plan_fact_differences=plan_differences,actual_plans=plans,
 baseline=b.pin(W/'runs/baseline/cpu-ffn-real-cuda/attempt1/report.json'),candidate=b.pin(W/'runs/candidate/cpu-ffn-real-cuda/attempt1/report.json'),
 scope='Current BF16 H2048 V2 fullV source/154-ID prompt,capacity1024/auto/4outputs/CPU2,old229 versusGraph-replaced229. Actual hybrid totals compared; not everyprovider or allmixedplacements.'))
assert not differences and not plan_differences,(differences,plan_differences)
print('PASS EXACT CPU2 allnon-time and existinghybrid facts',flush=True)
