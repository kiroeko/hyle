# Graph alias repair：有限验证终态与历史记录

最终 core9f4/test6940冻结后的有限检查已完成，`verification-summary.json` 是终态：30个实际process=5CXX/8link/17native；历史1次测试宏编译失败、旧首组预算断言失败和单case诊断失败全部保留。当前7新检查、18相关检查均全部通过/skip0；H64原失败配置完成4输出；默认四对与真实CPU2两臂全部非计时精确相同；Session两臂各378payload/150,761,472B直接逐字节相同。没有trace/profile/新性能窗口或cleanup。

当前229闭包仅原位替换Graph SDK对象1，其他228复用；tiny/CLI/Session没有重编。额外测试TU共4次尝试，其中首轮同一行SCOPED_TRACE宏重名失败。当前`model-link-base.json`、实际hardware/toolchain和完整process/命令/源码冻结记录已封。以下保留迁移前规划与基线分离依据。

基线明确分为：

- `../inference-target-graph-boundary-20261030/model-link-base.json` 的原229项缓存，Graph executable 是原功能版本（源SHA `8d584dde…`）。这是未来数值／状态前后对照使用的旧闭包。
- 当前 Status 诊断版（源SHA `8ac9a094…`）是另一个已经编译的Graph对象，仅用于保留定位身份；不会冒充原Graph对象。其原始一次H64 exit1仍在独立diagnostic批次。

`baseline-plan.json` 已保存两者对象/源码身份、ec4提交、诊断前后源快照以及当前相关头。tiny/CLI/Session三种对象全部source pins仍精确，未来只要没有头/API/ABI变化便复用它们。当前runtime只记原路径身份，没有复制整个SDK或模型。

## 单TU事实与未来构建

实际核对的 region recipe：`../inference-physical-spans-20261028/validation/refinement/logs/region-test/command.json`。

- 命令首项是本机cl，明确 `/c`；源码参数恰好一个：`tests/graph/region_provider_test.cc`。
- 没有 `/link`，没有Graph `.cc`，没有对象或库作为输入；`/Fo...unit.obj`仅为输出。
- capability为CPU，`/MD /O2 /W4 /WX`。不是多源码编译／链接driver。
- 原gtest_main.lib/gtest.lib已在本机缓存，身份已记录，不获取、不重编它们。

最终冻结后，`prepare` 只给Graph executable和region测试TU分别重定位输出，`compile` 最多两个cl。预计Graph SDK1+testTU1，consumer CXX0、NVCC0。若冻结实际更改公共头，源码身份检查会停止复用，而非默认混用旧ABI。

候选链接从原229条目开始，将Graph对象原位替换一次，将CLI consumer替换为选定的tiny/CLI/Session或新region对象一次。region额外加两个缓存gtest库。链接命令禁止出现任何源码参数，不append Graph对象，不混用历史SDK；模型冷对象仍保持原有各一次。

本轮没有自动扩大到全部组合，也没有把相邻历史批次的原始payload比较重跑为当前结果。copy/provider观测范围详见`facts-check-plan.md`：默认JSON只支持汇总相同，现有selected stderr计划计数也相同；未导出全部child逐provider/physicalcopy路线。H64的hybrid数字为真实child总copy，包含CPU传输，不假定旧未成功路线copy为零。
