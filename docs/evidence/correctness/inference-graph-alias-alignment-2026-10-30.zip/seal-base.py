"""Seal229 with oneGraph replacement and unchanged model consumers."""
from pathlib import Path
import copy,importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('repair_seal_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
baseline=read(W/'baseline-plan.json');base=read(baseline['base']['path'])
sdk_receipt=read(W/'compile/sdk/receipt.json');region=read(W/'compile/region/receipt.json')
for receipt in (sdk_receipt,region):
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
old=baseline['original_graph_object'];new=sdk_receipt['object']
retained=[new if key(item['path'])==key(old['path']) else item for item in base['retained']]
assert len(retained)==229 and len({key(item['path']) for item in retained})==229
assert sum(item==new for item in retained)==1
for item in retained:exact(item)
sdk=copy.deepcopy(read(base['sdk_engine_dependencies']['path']));replaced=0
for section in ('inspected','engine_consumers','native_consumers'):
 for index,row in enumerate(sdk[section]):
  if key(row['object'])!=key(old['path']):continue
  row=dict(row,object=new['path'],dependencies=sdk_receipt['dependencies'])
  if section!='inspected':row.update(receipt=pin(W/'compile/sdk/receipt.json'),source_identities=sdk_receipt['source_identities'])
  sdk[section][index]=row
  if section=='inspected':replaced+=1
assert replaced==1
sdk['changed_library_objects']=[dict(module='graph',source=str(R/'src/graph/executable.cc'),receipt=pin(W/'compile/sdk/receipt.json'),object=new)]
sdk['scope']='Current229 closure;onlyGraph executable original object replaced by repair9f4. Other228 inputs retained byteexact.160available sourceDependency rows/69historical missing native-library metadata remain explicit. No publicheader or modelconsumer ABI change.'
save(W/'sdk-engine-dependencies.json',sdk)
current={};audit=[];historical=copy.deepcopy(base['historical_consumers'])
for name,row in base['current_consumers'].items():
 exact(row['receipt']);exact(row['object']);receipt=read(row['receipt']['path'])
 mismatch=[item for item in receipt['source_identities'] if not Path(item['path']).is_file() or pin(item['path'])!=item]
 assert not mismatch,(name,mismatch)
 current[name]=row;audit.append(dict(consumer=name,source_pin_count=len(receipt['source_identities']),all_current_exact=True,reused_object=True))
current['region']=dict(receipt=pin(W/'compile/region/receipt.json'),object=region['object'])
args=[];count=0
for arg in base['link']:
 if key(arg)==key(old['path']):arg=new['path'];count+=1
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
  if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/cli').with_suffix(suffix));break
 args.append(arg)
assert count==1
historical['pre-alias-repair-library']=dict(original_graph=old,diagnostic_graph=baseline['diagnostic_graph_object'],
 original_source=baseline['original_graph_source'],diagnostic_source=baseline['diagnostic_graph_source'],
 note='Oldfunctional target229 Graph8d and diagnostic8ac are separate historicalSDK objects; currentSDK is repair9f4.')
save(W/'current-consumer-source-audit.json',audit)
save(W/'model-link-base.json',dict(schema='hyle.current-model-link-base.v1',base=baseline['base'],compile=base['compile'],link=args,
 consumer_source=base['consumer_source'],previous_consumer=base['current_consumers']['cli']['object']['path'],
 retained=retained,runtime=base['runtime'],sdk_engine_dependencies=pin(W/'sdk-engine-dependencies.json'),
 current_consumers=current,historical_consumers=historical,model_cold_objects=base['model_cold_objects'],
 retained_categories=dict(cached_SDK_and_engine_inputs=227,model_cold_objects=2,total_retained=229,replaced_Graph=1,unchanged_retained=228),
 note='Aliasalignment materialization repair9f4;original229 withoneGraph object replacement. tiny/CLI/Session andother currentconsumers sourcepins exact andobjects reused;newcurrentregion testsource6940 separately compiled. No fullSDK/NVCC build.'))
print(json.dumps(dict(status='SEALED_CURRENT229_GRAPH_REPLACED_ONCE',retained=229,reused=228,
 current_consumers=list(current),available_dependencies=len(sdk['inspected']),unavailable_metadata=len(sdk['unavailable'])),ensure_ascii=False))
