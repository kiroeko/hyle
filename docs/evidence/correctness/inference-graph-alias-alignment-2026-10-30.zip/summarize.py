"""Final compact facts; all historical failures remain separately readable."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('repair_summary_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
attempts=[];failures=[]
for directory in ('compile','link','runs'):
 for path in sorted((W/directory).rglob('process.json')):
  process=read(path);assert process['state']=='TERMINAL' and not process['timed_out']
  row=dict(name=path.parent.relative_to(W).as_posix(),actual=process,process=pin(path),command=pin(path.parent/'command.json'))
  attempts.append(row)
  if process['exit']:failures.append(dict(**row,stdout=pin(path.parent/'stdout.log'),stderr=pin(path.parent/'stderr.log')))
counts=dict(total=len(attempts),CXX=sum(row['name'].startswith('compile/') for row in attempts),
 links=sum(row['name'].startswith('link/') for row in attempts),native=sum(row['name'].startswith('runs/') for row in attempts),
 failed_CXX=sum(row['name'].startswith('compile/') for row in failures),failed_native=sum(row['name'].startswith('runs/') for row in failures))
assert counts==dict(total=30,CXX=5,links=8,native=17,failed_CXX=1,failed_native=2)
assert {row['name'] for row in failures}=={'compile/region/attempt1','runs/first-tests/attempt1','runs/budget-diagnostic/attempt1'}
save(W/'process-inventory.json',dict(attempts=attempts,historical_failures=failures))
first=read(W/'runs/first-tests/attempt2/report.json');related=read(W/'runs/related-tests/attempt1/report.json')
for report,count in ((first,7),(related,18)):
 assert report['status']=='PASS_EXACT_EXECUTED_TEST_SET' and report['actual_case_count']==count and report['failures']==report['skipped']==0
tiny=read(W/'tiny-repair-result.json');assert tiny['status']=='PASS_ORIGINAL_H64_CONFIG_NOW_COMPLETES'
whole=read(W/'whole-cli-summary.json');assert all(row['all_non_timing_fields_equal'] and not row['differences'] for row in whole['checks'])
cpu=read(W/'compare-cpu-ffn-real-cuda.json');assert cpu['status']=='PASS' and not cpu['differences'] and not cpu['hybrid_plan_fact_differences']
session=read(W/'session-compare.json');assert session['status']=='PASS_EXACT_COMPLETE_SESSION'
vectors=read(W/'session-vector-manifest.json');assert vectors['file_count_per_arm']==378 and vectors['bytes_per_arm']==150761472
plans=read(W/'existing-plan-summary-comparison.json');assert plans['status']=='ALL_RECORDED_COLD_SUMMARIES_EQUAL'
budget=read(W/'budget-diagnostic-result.json');assert budget['classification']=='SUCCESSFUL_SELECTED_PLAN_WITHIN_ALL_DOMAIN_CAPS'
source=[pin(R/'src/graph/executable.cc'),pin(R/'tests/graph/region_provider_test.cc')]
assert [item['sha256'] for item in source]==['9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc','6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00']
base=read(W/'model-link-base.json');assert len(base['retained'])==229
for item in base['retained']:exact(item)
artifact_names=['model-link-base.json','sdk-engine-dependencies.json','process-inventory.json','current-consumer-source-audit.json',
 'whole-cli-summary.json','existing-plan-summary-comparison.json','compare-cpu-ffn-real-cuda.json','session-compare.json','session-vector-manifest.json',
 'tiny-repair-result.json','budget-diagnostic-result.json','hardware-toolchain.json','facts-check-plan.md','inventory-preparation-note.json']
summary=dict(schema='hyle.graph-alias-repair-finite.v1',status='CURRENT_FINITE_GATES_PASS_HISTORICAL_FAILURES_RETAINED',
 base_commit=read(W/'baseline-plan.json')['base_commit'],full_goal_complete=False,sources=source,attempts=counts,
 compile_scope=dict(SDK_Graph_CXX=1,testTU_CXX_attempts=4,consumer_CXX=0,retained=229,replaced_Graph=1,unchanged_retained=228,
  NVCC=0,downloads=0,full_default_CMake_build=False),
 current_tests=dict(new_actual=7,related_actual=18,failures=0,skipped=0,source='final6940strongCaller case',
  first_report=pin(W/'runs/first-tests/attempt2/report.json'),related_report=pin(W/'runs/related-tests/attempt1/report.json')),
 historical_failures=[dict(kind='TEST_CXX',scope='Initialsame-lineSCOPED_TRACE duplicate macro names; formatting-only correction.'),
  dict(kind='INITIAL_SEVEN_TEST_GROUP',scope='6pass1fail; unbounded408 route was not a minimumworkspace certificate, budget407 legitimately chose340B compatible route.'),
  dict(kind='ONE_DIAGNOSTIC_TEST',scope='Same originalassert intentionally retained while recording bothactualplans; still nativeexit1, not a fix pass.')],
 scratch_preparation_issue=dict(record=pin(W/'inventory-preparation-note.json'),scope='One PowerShell quoting preparation error; no product/build/native execution. Correctedusingapply_patch.'),
 H64=dict(status='PASS',processes=1,generated_tokens=4,final_versions=0,hybrid_child_totals=tiny['hybrid_plan_facts'],
  scope='OriginaluntrainedGA/H64/V64 CPUFFN1 now completes. Totals include preexistingCPU transfers; previousroute nevercompiled, no oldcopy0 claim.'),
 budget=dict(original_workspace=408,original_copy=68,limited_cap=407,limited_workspace=340,limited_copy=0,plan_rejections=1,
  observed_all_domain_caps_respected=True,final_strongCaller='Two hardlockedleaves force340+68 simultaneous408B,407refusal andsameconstrained recovery executed in current7group.'),
 default_fullV=dict(scenarios=4,processes=8,all_non_timing_report_fields_exact=True,differences=[],
  existing_cold_plan_summaries_exact=True,timing_diagnostics=[dict(case=row['case'],**row['timing_diagnostic']) for row in whole['checks']],
  scope='Oldtarget229 versusGraphreplaced229,ordinary/MTP single64/two128. Report equality is aggregateonly; everyprovider/physicalcopy route was not exported. One processpair each; no stable timing or speedup claim.'),
 CPU2=dict(processes=2,all_non_timing_fields_exact=True,existing_hybrid_facts_exact=True,differences=[],
  capacity=1024,replay='auto',outputs=4,source='CurrentBF16H2048 V2/154-ID fullV input',
  scope='Original3domain/2target/hostDomain1 constant assertions retained; finiteCPU2 coverage, not allmixedplacement.'),
 Session=dict(processes=2,payload_files_per_arm=378,payload_bytes_per_arm=150761472,direct_byte_equal=True,
  observation_equal_except_absolute_output_directory=True,differences=[],final_live_versions=0,
  idle_complete_head_checks=4,A_calls_after_B_stop=3,payload_known_plan_bytes=80240691),
 audits=dict(alignment_source=str(R/'.scratch/inference-cuda-port-alignment-review-20261030'),
  budget_source=str(R/'.scratch/inference-graph-alias-budget-audit-20261030'),
  selected_original_failed_provider='UNRECORDED',kernel_intrinsic_256_requirement='UNPROVEN_ALLOCATION_OR_DECLARATION_IS_NOT_KERNEL_PROOF',alignment_declaration_lowered=False),
 artifacts={name:pin(W/name) for name in artifact_names},
 final_source_review=[pin(R/'.scratch/inference-graph-alias-repair-20261030'/name) for name in ['final-source.patch','final-source-pins.json','final-review-summary.json','tests-static-review-final.json']],
 limits=['FiniteGraph ordinaryby-value alias alignment materialization repair; not wholearchitecture/function exhaustion/quality completion.',
  'No trace/profile/independent performancewindow. DefaultJSON cannot prove detailedperprovider identity.',
  'Manualexact CXX/link withcachedSDK; no fullnormalCMake build.',
  'No cleanup yet; raw Session arrays remain for independentcollector byteverification.'])
save(W/'verification-summary.json',summary)
print(json.dumps(dict(status=summary['status'],attempts=counts,current_new_tests=7,related=18,H64='PASS',default_pairs=4,CPU2='EXACT',
 Session_files_per_arm=378,Session_bytes_per_arm=150761472,Session_byte_equal=True,retained=229),ensure_ascii=False))
