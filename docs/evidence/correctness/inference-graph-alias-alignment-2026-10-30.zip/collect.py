"""Seal completed alias alignment evidence, never build/run/download/clean.

Only execute after bridge_evidence explicitly declares terminal metadata ready.
All writes stay in this scratch directory; root publishes the reviewed packet.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
REPAIR = R / '.scratch/inference-graph-alias-repair-20261030'
REFERENCES = R / '.scratch/inference-alias-reference-review-20261030'
PORT = R / '.scratch/inference-cuda-port-alignment-review-20261030'
BUDGET = R / '.scratch/inference-graph-alias-budget-audit-20261030'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def pin(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            h.update(block)
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


checked = {}


def exact(item):
    name = str(Path(item['path']).resolve()).lower()
    if name not in checked:
        checked[name] = pin(item['path'])
    actual = checked[name]
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'], item['path']
    return actual


def key(path):
    return str(Path(path).resolve()).lower()


def terminal(process, success=False):
    assert process['state'] == 'TERMINAL' and not process.get('timed_out'), process
    if success:
        assert process['exit'] == 0, process


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
                if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def normalize_root(value, root):
    if isinstance(value, str):
        return value.replace(str(root), '{VECTORS}')
    if isinstance(value, list):
        return [normalize_root(v, root) for v in value]
    if isinstance(value, dict):
        return {k: normalize_root(v, root) for k, v in value.items()}
    return value


def xml_result(folder, expected, failed):
    terminal(read(folder / 'process.json'), success=failed == 0)
    root = ET.parse(folder / 'result.xml').getroot()
    cases = root.findall('.//testcase')
    names = [c.attrib['classname'] + '.' + c.attrib['name'] for c in cases]
    errors = [c.attrib['classname'] + '.' + c.attrib['name'] for c in cases
              if c.find('failure') is not None or c.find('error') is not None]
    skipped = [n for c, n in zip(cases, names) if c.find('skipped') is not None]
    assert len(cases) == expected and len(errors) == failed and not skipped
    assert all(c.attrib.get('status', 'run') == 'run' for c in cases)
    return {'folder': str(folder), 'tests': expected, 'passed': expected - failed,
            'failed': failed, 'skipped': 0, 'names': names, 'failures': errors,
            'xml': pin(folder / 'result.xml')}


def collect(ready):
    assert ready == 'bridge-terminal-ready'
    assert not (W / 'archive-draft.json').exists(), 'Do not overwrite a sealed evidence attempt.'
    verification = read(W / 'verification-summary.json')
    base = read(W / 'model-link-base.json')
    baseline = read(W / 'baseline-plan.json')
    plan = read(W / 'plan.json')
    assert verification['full_goal_complete'] is False
    assert verification['status'] == 'CURRENT_FINITE_GATES_PASS_HISTORICAL_FAILURES_RETAINED'
    assert baseline['base_commit'] == 'ec4b30b4dd58e09594822882e4689d78835dc4d7'
    assert len(base['retained']) == len(baseline['retained']) == 229
    assert plan['unchanged_retained'] == 228 and plan['consumer_CXX'] == 0
    for item in [*baseline['retained'], *base['retained'], baseline['runtime'], base['runtime']]:
        exact(item)
    exact(baseline['original_graph_snapshot'])
    baseline_blob = subprocess.check_output(['git', 'show', baseline['base_commit'] + ':src/graph/executable.cc'], cwd=R)
    assert baseline_blob == Path(baseline['original_graph_snapshot']['path']).read_bytes()
    assert hashlib.sha256(baseline_blob).hexdigest() == baseline['original_graph_source']['sha256']
    sdk_receipt = read(W / 'compile/sdk/receipt.json')
    test_receipt = read(W / 'compile/region/receipt.json')
    for receipt in (sdk_receipt, test_receipt):
        for name in ('object', 'dependencies', 'process'):
            exact(receipt[name])
        terminal(read(receipt['process']['path']), success=True)
        for item in receipt['source_identities']:
            exact(item)
    assert next(i for i in sdk_receipt['source_identities'] if key(i['path']) == key(R / 'src/graph/executable.cc'))['sha256'] == \
        '9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc'
    assert next(i for i in test_receipt['source_identities'] if key(i['path']) == key(R / 'tests/graph/region_provider_test.cc'))['sha256'] == \
        '6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00'
    before = {key(i['path']): i for i in baseline['retained']}
    after = {key(i['path']): i for i in base['retained']}
    old_graph = key(baseline['original_graph_object']['path'])
    new_graph = key(sdk_receipt['object']['path'])
    assert set(before) - set(after) == {old_graph} and set(after) - set(before) == {new_graph}
    assert all(before[p] == after[p] for p in set(before) & set(after))
    assert after[new_graph] == sdk_receipt['object']
    consumers = []
    for name, row in baseline['consumers'].items():
        assert name in ('cli', 'tiny', 'session')
        exact(row['object'])
        for item in row['source_identities']:
            exact(item)
        consumers.append({'name': name, 'cached_object': row['object'],
            'source_pins': len(row['source_identities']), 'all_current_exact': True, 'CXX': 0})
    save(W / 'collector-source-receipt-proofs.json', {
        'SDK': sdk_receipt, 'region_test': test_receipt, 'cached_consumers': consumers,
        'original229_replaced_Graph_once': True, 'other228_byte_exact': True,
        'scope': 'Historical test object output was deliberately reused; historical source snapshots and compile/log/process receipts are retained separately, not claimed to equal the final OBJ.'})

    attempts, counts = [], {}
    for directory in ('compile', 'link', 'runs'):
        paths = sorted((W / directory).rglob('process.json'))
        counts[directory] = len(paths)
        for path in paths:
            process = read(path)
            terminal(process)
            command = path.parent / 'command.json'
            assert command.is_file()
            row = {'name': path.parent.relative_to(W).as_posix(), 'process': pin(path),
                   'command': pin(command), 'actual': process}
            if (path.parent / 'report.json').is_file():
                row['report'] = pin(path.parent / 'report.json')
            attempts.append(row)
    assert counts == {'compile': 5, 'link': 8, 'runs': 17}, counts
    failures = [r['name'] for r in attempts if r['actual']['exit'] != 0]
    assert failures == ['compile/region/attempt1', 'runs/budget-diagnostic/attempt1', 'runs/first-tests/attempt1'], failures
    assert {r['name'] for r in attempts if r['name'].startswith('compile/')} == \
        {'compile/sdk/attempt1', *('compile/region/attempt' + str(n) for n in range(1, 5))}
    actual_counts = {'total': 30, 'CXX': 5, 'Graph_SDK_CXX': 1, 'test_CXX': 4,
        'CXX_failed': 1, 'links': 8, 'links_failed': 0,
        'native': 17, 'native_pass': 15, 'native_failed': 2, 'consumer_CXX': 0, 'NVCC': 0, 'downloads': 0}
    assert verification['attempts'] == {'total': 30, 'CXX': 5, 'links': 8, 'native': 17, 'failed_CXX': 1, 'failed_native': 2}

    old_first = xml_result(W / 'runs/first-tests/attempt1', 7, 1)
    diagnostic = xml_result(W / 'runs/budget-diagnostic/attempt1', 1, 1)
    current_first = xml_result(W / 'runs/first-tests/attempt2', 7, 0)
    related = xml_result(W / 'runs/related-tests/attempt1', 18, 0)
    filters = read(REPAIR / 'test-filters.json')
    assert set(current_first['names']) == set(filters['first_new_cases'])
    assert set(related['names']) == set(filters['related_regressions'])
    assert old_first['names'] == current_first['names']
    assert old_first['failures'] == diagnostic['failures'] == \
        ['GraphRegions.AlignmentRepairKeepsWorkspaceLimitsAndRecoversAfterRefusal']
    budget = read(W / 'budget-diagnostic-result.json')
    assert budget['status'] == 'EXPECTED_DIAGNOSTIC_TEST_FAILURE_RECORDED'
    assert budget['classification'] == 'SUCCESSFUL_SELECTED_PLAN_WITHIN_ALL_DOMAIN_CAPS'
    assert budget['actual_exit'] == 1 and budget['original_assertion_unchanged'] and budget['not_a_functional_pass']
    assert budget['plans']['original']['workspace'] == 408 and budget['plans']['original']['copy'] == 68
    assert budget['plans']['limited']['workspace'] == 340 and budget['plans']['limited']['copy'] == 0
    assert budget['requested_cap'] == 407 and budget['limited_recorded_domains_within_cap']
    properties = {p.attrib['name']: p.attrib['value'] for p in ET.parse(W / 'runs/budget-diagnostic/attempt1/result.xml').findall('.//property')}
    for arm in ('original', 'limited'):
        assert properties['budget_' + arm + '_plan'] == budget['plans'][arm]['raw']
    save(W / 'collector-gtest-and-budget-readback.json', {
        'original_first7': old_first, 'original_budget_diagnostic': diagnostic,
        'current_first7': current_first, 'current_related18': related,
        'old_budget_actual_fallback_reports_xml_exact': True,
        'old_407_scope': 'Unconstrained original route:408/Copy68 -> legitimate ggml-cpu340/Copy0 within407, original assertion failed.',
        'current_407_scope': 'Separate hard-locked two-Caller unary fixture,340+68 live lower bound408;407 refusal+same-contract restoration and replay asserted by current passing budget test.',
        'historical_failures_not_relabelled_pass': True})

    whole = read(W / 'whole-cli-summary.json')
    assert whole['status'] == 'PASS_ALL_FOUR_DEFAULT_CASES' and len(whole['checks']) == 4
    cpu2 = read(W / 'compare-cpu-ffn-real-cuda.json')
    comparisons = []
    for row in [*whole['checks'], cpu2]:
        assert row['all_non_timing_fields_equal'] and not row['differences']
        for arm in ('baseline', 'candidate'):
            exact(row[arm])
        assert stable(read(row['baseline']['path'])) == stable(read(row['candidate']['path']))
        comparisons.append({'case': row.get('case', 'cpu-ffn-real-cuda'), 'all_non_timing_fields_exact': True})
    assert not cpu2['hybrid_plan_fact_differences']
    tiny = read(W / 'tiny-repair-result.json')
    assert tiny['status'] == 'PASS_ORIGINAL_H64_CONFIG_NOW_COMPLETES'
    assert tiny['generated_tokens'] == 4 and tiny['cpu_ffn_layers'] == 1 and tiny['final_versions'] == 0
    assert tiny['original_domain_and_host_constant_assertions_preserved']
    exact(tiny['report'])
    assert len(tiny['hybrid_plan_facts']) == 2
    assert all(f['host_constants'] == 5 and f['materialized_constant_bytes'] == 0 for f in tiny['hybrid_plan_facts'])

    session = read(W / 'session-compare.json')
    assert session['status'] == 'PASS_EXACT_COMPLETE_SESSION'
    assert session['payload_byte_equal'] and session['observation_equal_after_only_output_root_normalization']
    assert not session['differences'] and not session['report_differences'] and not session['ignored_semantic_fields']
    manifest = read(W / 'session-vector-manifest.json')
    assert manifest['status'] == 'PASS_EXACT_COMPLETE_VECTOR_BYTES'
    assert manifest['file_count_per_arm'] == 378 and manifest['bytes_per_arm'] == 150761472
    assert manifest['all_cross_arm_bytes_identical'] and manifest['metadata_equal_except_output_root']
    assert manifest['numerical_tolerance'] is None
    arms = manifest['arms']
    assert arms['baseline'].keys() == arms['candidate'].keys()
    for arm in ('baseline', 'candidate'):
        assert len(arms[arm]) == 378 and sum(i['bytes'] for i in arms[arm].values()) == 150761472
        for item in arms[arm].values():
            exact(item)
    for name in arms['baseline']:
        a, b = arms['baseline'][name], arms['candidate'][name]
        assert (a['bytes'], a['sha256']) == (b['bytes'], b['sha256'])
        with Path(a['path']).open('rb') as one, Path(b['path']).open('rb') as two:
            while True:
                left, right = one.read(4 << 20), two.read(4 << 20)
                assert left == right, name
                if not left:
                    break
    observations = {}
    for arm in ('baseline', 'candidate'):
        folder = W / 'runs' / arm / 'session-cuda/attempt1/vectors'
        observation = read(folder / 'observation.json')
        assert observation['status'] == 'PASS_BYTE_EXACT' and observation['all_vectors_byte_equal']
        assert observation['all_finite'] and observation['numerical_tolerance_policy'] is None
        assert observation['final_live_snapshot_versions'] == 0
        assert observation['idle_head_full_byte_checks'] == 4 and observation['A_calls_after_B_stop'] == 3
        assert observation['managed_backing_bytes'] == observation['planned_backing_bytes'] == 80240691
        for row in observation['vectors']:
            assert row['byte_equal'] and row['max_abs'] == row['squared_error'] == 0
            assert row['nonfinite_baseline'] == row['nonfinite_actual'] == 0
        observations[arm] = normalize_root(observation, folder)
    assert observations['baseline'] == observations['candidate']
    save(W / 'collector-vector-readback.json', {'status': 'PASS_ALL_HASHES_AND_DIRECT_COMPLETE_BYTE_PAIRS',
        'files_per_arm': 378, 'bytes_per_arm': 150761472, 'all_complete_pairs_byte_equal': True,
        'all_original_finite_zero_error_and_retirement_checks': True, 'numerical_tolerance': None,
        'metadata_normalization': 'Only the output directory path; every other metadata field exact.',
        'original_manifest': pin(W / 'session-vector-manifest.json')})

    final = read(REPAIR / 'final-source-pins.json')
    # The final archive preserves the full ec4 delta separately from the old
    # c340 canonical repair patch/plan which described the first failed CXX.
    final_patch = REPAIR / 'final-source.patch'
    reverse = subprocess.run(['git', 'apply', '--reverse', '--check', str(final_patch)], cwd=R,
        capture_output=True, text=True)
    assert reverse.returncode == 0, reverse.stderr
    source_rows = []
    for relative, expected in [('src/graph/executable.cc', '9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc'),
                               ('tests/graph/region_provider_test.cc', '6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00')]:
        source = R / relative
        assert pin(source)['sha256'] == expected
        assert source.read_bytes() == (REPAIR / 'candidate' / relative).read_bytes()
        snapshot = W / 'source-current' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
        source_rows.append({'relative': relative, 'source': pin(source), 'snapshot': pin(snapshot)})
    save(W / 'collector-final-source-readback.json', {'final_sources': source_rows,
        'final_source_pins': pin(REPAIR / 'final-source-pins.json'), 'full_ec4_source_patch': pin(final_patch),
        'reverse_apply_check_exit': reverse.returncode, 'source_changes_only_two_product_paths': True,
        'original_failed_c340_plan_patch_preserved_as_history': True})

    # Prove historical source pins against exact source snapshots, without
    # silently changing them to the current file hash.
    snapshot_index = {}
    snapshot_roots = [W / 'baseline-source', *W.glob('source-attempt*'), REPAIR / 'base', REPAIR / 'candidate',
                      REPAIR / 'final-source-base', *REPAIR.glob('superseded-*')]
    for directory in snapshot_roots:
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix in ('.cc', '.h'):
                item = pin(path)
                snapshot_index.setdefault((item['bytes'], item['sha256']), path)
    source_checks = []

    def source_identity(item):
        path = Path(item['path'])
        if path.is_file():
            actual = pin(path)
            if (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256']):
                source_checks.append({'original': item, 'proof': 'CURRENT_EXACT'})
                return
        snapshot = snapshot_index.get((item['bytes'], item['sha256']))
        assert snapshot is not None, ('No exact historical source snapshot', item['path'], item['sha256'])
        source_checks.append({'original': item, 'proof': 'HISTORICAL_SOURCE_SNAPSHOT_EXACT', 'snapshot': pin(snapshot)})

    for receipt_path in sorted((W / 'compile/region').rglob('receipt-at-completion.json')):
        receipt = read(receipt_path)
        for item in receipt['source_identities']:
            source_identity(item)
    def source_pin_tree(value):
        if isinstance(value, dict):
            if all(name in value for name in ('path', 'bytes', 'sha256')) and Path(value['path']).suffix in ('.cc', '.h'):
                source_identity(value)
            for item in value.values():
                source_pin_tree(item)
        elif isinstance(value, list):
            for item in value:
                source_pin_tree(item)
    source_pin_tree(final)
    mature = read(REFERENCES / 'references.json')
    assert mature['status'] == 'PASS_SELECTED_ACTUAL_LOCAL_REFERENCE_SOURCE_BYTES'
    assert sum(len(v['files']) for v in mature['references'].values()) == 10
    for repository in mature['references'].values():
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository['root'], text=True).strip()
        assert head == repository['actual_HEAD']
        for item in repository['files']:
            source_identity(item)
            blob = subprocess.check_output(['git', 'show', head + ':' + item['relative']], cwd=repository['root'])
            assert hashlib.sha256(blob).hexdigest() == item['HEAD_blob_sha256']
    port = read(PORT / 'sources.json')
    assert port['selected_failed_region_provider'] == 'UNRECORDED'
    assert port['native_runs'] == port['builds'] == port['product_edits'] == port['downloads'] == 0
    assert len(port['files']) == 24
    for item in port['files']:
        source_identity(item)
    budget_source = read(BUDGET / 'sources.json')
    for item in budget_source['sources']:
        source_identity(item)
    core_review = read(REPAIR / 'independent-core-review.json')
    assert core_review['candidate']['sha256'] == '9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc'
    assert all(core_review['checks'].values())
    strong = read(BUDGET / 'strong-caller-independent-review.json')
    assert strong['candidate_sha256'] == '6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00'
    assert strong['product_equals_candidate'] and strong['historical_diagnostic_not_pass']
    save(W / 'collector-reference-and-history-readback.json', {'source_pins': source_checks,
        'mature_selected_files': 10, 'cuda_port_selected_files': 24,
        'actual_reference_HEADs': {name: row['actual_HEAD'] for name, row in mature['references'].items()},
        'kernel_256_attribution': 'Selected failed provider remains UNRECORDED. Wrapper256/allocation alignment or peer128 is not proof of a specific kernel requirement; declarations were not weakened.'})

    dependencies = read(W / 'sdk-engine-dependencies.json')
    hardware = read(W / 'hardware-toolchain.json')
    assert dependencies and hardware
    # Verify the final actual SDK/test dependencies and preserve the original
    # unavailable old native-library metadata distinction from the harness.
    for receipt in (sdk_receipt, test_receipt):
        dependency = read(receipt['dependencies']['path'])
        assert dependency['Data']['Source']
    save(W / 'collector-attempt-readback.json', {'counts': actual_counts, 'attempts': attempts,
        'failed_attempts': failures, 'all_terminal': True, 'verification_source': pin(W / 'verification-summary.json')})

    extensions = {'.py', '.json', '.jsonl', '.log', '.xml', '.txt', '.md', '.cc', '.h', '.cmake', '.patch', '.ids', '.tsv'}
    external = []
    directories = [REPAIR, REFERENCES, PORT, BUDGET,
        R / '.scratch/inference-alias-copy-outcome-review-20261030',
        R / '.scratch/inference-alias-budget-fixture-review-20261030',
        R / '.scratch/inference-graph-alias-diagnostic-20261030']
    for directory in directories:
        assert directory.is_dir(), directory
        for source in sorted(directory.rglob('*')):
            if not source.is_file() or source.suffix not in extensions or '__pycache__' in source.parts:
                continue
            if 'final-patch-verification' in source.parts:
                continue # Exact duplicate verification tree, not unique evidence.
            destination = W / 'external-evidence' / directory.name / source.relative_to(directory)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(source.read_bytes())
            external.append(pin(destination))
    # A pre-repair native diagnosis is a separate historical process, not an
    # extra execution in the current17. Keep its small original logs/context.
    diagnosis = R / '.scratch/inference-graph-alias-harness-20261030'
    for relative in ['diagnostic-result.json', 'plan.json', 'source-freeze.json', 'README.md']:
        source = diagnosis / relative
        if source.is_file():
            destination = W / 'historical-diagnosis' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(source.read_bytes())
    for source in (diagnosis / 'runs').rglob('*'):
        if source.is_file() and source.suffix in extensions:
            destination = W / 'historical-diagnosis' / source.relative_to(diagnosis)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(source.read_bytes())

    save(W / 'collector-external-evidence-manifest.json', {'files': external,
        'scope': 'Historical source/failed-attempt records and bounded static reviews; no models, binary SDK copies or raw vectors.'})

    summary = {
        'schema': 'hyle-inference-graph-alias-alignment-v1',
        'status': verification['status'], 'base_commit': baseline['base_commit'], 'full_goal_complete': False,
        'implementation': {'product_files': 2, 'actual_diagnosis': 'ordinary internal Caller/TensorView root65+128B, input alignment256, accepts_ref0/needs_tensor1; dim0=last_row0 -> T1 from original Recipe dimension definitions',
            'repair': 'Only a qualified by-value internal caller alias gets a same-description physical copy when its static offset fails alignment. Producer/reference/external/effect identities stay original.',
            'NoQualifiedCopy': 'Typed false only for explicit exhausted qualified copy routes; required locality keeps plan decline, optional alignment keeps current reader decline. Query/native/allocation/search errors retain their actual status.',
            'late_transfer': 'Original physical-next then routes-next preserved. Malformed unowned artifact is Internal before retry flag; native-bearing errors are not softened.',
            'capacity_lifetime': 'Original V*S+V instance bound and all arrays retained; Copy uses original plan scheduling, overlapping source/destination lifetime, budget and retirement.',
            'not_claimed': 'No model-specific Copy, budget increase, changed provider declaration, general kernel alignment attribution, or final-copy-cost global optimizer.'},
        'attempts': actual_counts, 'failed_attempts': failures,
        'compile': {'unchanged_retained': 228, 'replaced_Graph': 1, 'candidate_inputs': 229,
            'cached_consumer_CXX': 0, 'final_Graph_source_sha256': '9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc',
            'final_test_source_sha256': '6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00'},
        'current_tests': {'new': 7, 'related': 18, 'passed': 25, 'failed': 0, 'skipped': 0},
        'historical_tests': {'first7': {'passed': 6, 'failed': 1}, 'budget_diagnostic': {'executed': 1, 'failed': 1, 'expected_for_fact_collection': True},
            'SCOPED_TRACE_CXX': {'exit': 2, 'cause': 'Two same-line macros generated duplicate __LINE__ symbols; whitespace-only correction retained.'}},
        'budget_scopes': {'old407': 'Actual legal fallback408/Copy68 ->340/Copy0 under407; old assertion failed.',
            'strong407': 'Two hard-locked Caller unary providers require340+68 live bytes>=408. Current test asserts407 refusal, no submit, original roles/independent placement and restored replay.'},
        'H64': {'status': tiny['status'], 'generated_tokens': 4, 'cpu_ffn_layers': 1, 'final_versions': 0,
            'hybrid_plan_facts': tiny['hybrid_plan_facts'], 'scope': tiny['copy_scope'], 'full_result': pin(W / 'tiny-repair-result.json')},
        'paired_non_timing_reports_independently_equal': comparisons,
        'Session': {'files_per_arm': 378, 'bytes_per_arm': 150761472, 'all_hashes_and_direct_bytes_equal': True,
                    'only_output_root_metadata_normalized': True, 'finite_zero_error_retirement_checks': True},
        'checks': pin(W / 'verification-summary.json'),
        'scratch_preparation_issue': {'record': pin(W / 'inventory-preparation-note.json'),
            'scope': 'A preserved script-preparation escaping error with no build/native effect; not a model test or one of the30 processes.'},
        'source_receipts': pin(W / 'collector-source-receipt-proofs.json'),
        'source_final': pin(W / 'collector-final-source-readback.json'),
        'attempt_readback': pin(W / 'collector-attempt-readback.json'),
        'gtest_budget_readback': pin(W / 'collector-gtest-and-budget-readback.json'),
        'vector_readback': pin(W / 'collector-vector-readback.json'),
        'reference_readback': pin(W / 'collector-reference-and-history-readback.json'),
        'model_link_base': pin(W / 'model-link-base.json'), 'dependency_proof': pin(W / 'sdk-engine-dependencies.json'),
        'hardware_toolchain': pin(W / 'hardware-toolchain.json'),
        'external_evidence_manifest': pin(W / 'collector-external-evidence-manifest.json'),
        'limits': [
            'Finite Graph capability and original consumers only; not whole inference goal completion or all backend/model/shape exhaustion.',
            'Current25 gtests are test-case counts, not loop subcases, implementations, GPU dispatches or a complete suite.',
            'H64 had no old successful complete plan; its reported hybrid copy totals include original CPU transfers and are not an old0/newdelta claim.',
            'Default/CPU2 JSON and logged resource totals are exact where compared. Default JSON lacks a full per-provider/all-child copy inventory; no trace/tensor-readback run was added.',
            'Wrapper256 and peer allocation128 do not identify the failed selected kernel; selected failed provider remains unrecorded. No declaration was lowered.',
            'Single finite same-argument timings diagnose obvious regressions only; no sustained speed claim, profiler, download or new performance candidate.',
            'Manual exact cached CXX/link, no normal full CMake build/install. Old unavailable native-library dependency metadata remains explicitly unavailable.',
            'Archive omits binary, model/SDK/vendor copies and raw vectors, retaining complete hashes/source versions/commands/reports and original failed attempts.',
        ]}
    save(W / 'summary-draft.json', summary)
    files = set()
    for path in W.iterdir():
        if path.is_file() and path.suffix in extensions and path.name not in ('archive-draft.json', 'retention-manifest.json'):
            files.add(path)
    for directory in ['compile', 'link', 'runs', 'baseline-source', 'source-current',
                      *[p.name for p in W.glob('source-attempt*')], 'session-input', 'external-evidence', 'historical-diagnosis']:
        for path in (W / directory).rglob('*'):
            if path.is_file() and path.suffix in extensions and '__pycache__' not in path.parts:
                files.add(path)
    forbidden = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.f32', '.bf16', '.f16', '.safetensors', '.gguf'}
    assert not any(p.suffix.lower() in forbidden for p in files)
    members = [{'member': p.relative_to(W).as_posix(), 'bytes': p.stat().st_size, 'sha256': pin(p)['sha256']} for p in sorted(files)]
    save(W / 'retention-manifest.json', {'members': members,
        'excluded': 'EXE/OBJ/PDB/DLL/LIB/EXP; model/SDK/vendor copies; raw vector bytes. Complete source/hash/HEAD/command/dependency/report/failure evidence and vector hashes retained.'})
    files.add(W / 'retention-manifest.json')
    archive = W / 'evidence-draft.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(files):
            z.write(path, path.relative_to(W).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(files)
        for item in members:
            body = z.read(item['member'])
            assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
        assert json.loads(z.read('retention-manifest.json'))['members'] == members
    result = {'archive': pin(archive), 'members': len(files), 'all_member_bytes_sha256_readback': True,
        'summary': pin(W / 'summary-draft.json'), 'retention_manifest': pin(W / 'retention-manifest.json'),
        'vector_readback': pin(W / 'collector-vector-readback.json'), 'model_link_base': pin(W / 'model-link-base.json'),
        'no_product_docs_test_ps1_write': True, 'no_cleanup': True}
    save(W / 'archive-draft.json', result)
    print(json.dumps({'status': summary['status'], 'attempts': actual_counts, 'archive_bytes': result['archive']['bytes'],
        'members': len(files), 'archive_sha256': result['archive']['sha256'], 'vector_files_per_arm': 378}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ready', required=True, choices=['bridge-terminal-ready'])
    collect(parser.parse_args().ready)
