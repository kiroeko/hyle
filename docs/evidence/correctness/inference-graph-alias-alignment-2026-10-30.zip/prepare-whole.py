"""Metadata only for root-authorized12 further processes; no model downloads."""
from pathlib import Path
import importlib.util,shutil
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('repair_whole_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
assert not (W/'whole-plan.json').exists()
sdk=b.read(W/'compile/sdk/receipt.json')
for item in [sdk['object'],*sdk['source_identities']]:b.exact(item)
assert b.pin(R/'src/graph/executable.cc')['sha256']=='9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc'
assert b.pin(R/'tests/graph/region_provider_test.cc')['sha256']=='6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00'
old=R/'.scratch/inference-target-graph-boundary-20261030';source=b.read(old/'baseline-plan.json')
cases={name:source['cases'][name] for name in ('ordinary-single','mtp-single','ordinary-two','mtp-two')}
cpu=b.read(old/'cpu-ffn-bounded-plan.json');cases['cpu-ffn-real-cuda']=dict(consumer='cli',args=cpu['real_args'],outputs=4)
local=W/'session-input';local.mkdir()
for name in ('weights.tsv','prompt.ids'):shutil.copyfile(old/'session-input'/name,local/name)
cases['session-cuda']=dict(consumer='session',args=['--backend','cuda','--inputs',str(local),'--output','{OUTPUT}','--scenario','sessions'])
b.save(W/'whole-plan.json',dict(status='AUTHORIZED_UNTRACED_FINITE_PAIRS',cases=cases,
 original_default_case_plan=b.pin(old/'baseline-plan.json'),original_CPU2_plan=b.pin(old/'cpu-ffn-bounded-plan.json'),
 Session_metadata=[b.pin(local/name) for name in ('weights.tsv','prompt.ids')],SDK_CXX=0,consumer_CXX=0,
 native_processes=12,additional_links=4,downloads=0,NVCC=0,
 scope='Fresh oldtarget229 versusGraphreplaced229. Defaultfourpairs,realCPU2/1024/auto/4outputs pair,completeSession pair only. No trace/profile/performancewindow; defaultJSON lacks detailedprovider routes.'))
print('PREPARED12finite processes/4needed links;no CXX/native executed.')
