# Graph alias 诊断：一次定位已完成

基线 HEAD `ec4b30b4dd58e09594822882e4689d78835dc4d7`，缓存为 `../inference-target-graph-boundary-20261030/model-link-base.json` 的229项。先完成只读发现，随后按 root 最终冻结 SHA8ac9a094…授权，只编译Graph executable SDK对象1、复用tiny对象链接1、运行原H64命令1。CXX/link exit0；唯一native仍 exit1，无超时，不是修复或功能通过。没有运行下列备选gtest或其他消费者。

`diagnostic-result.json` 保留完整1397B原stderr身份与完整错误行：node55/count6，port0/value42、instance69/storage0/target0，root65+128B不满足256B alignment，chain_valid1/accepts_ref0/needs_tensor1；instance/root roles0、kind0、projection0；child variant=unassigned、shape_count1/`[0=0]`，外层真实 finite index0。原拒绝分类和搜索失败仍在。基线原src与当前诊断src都已保存；`summary.json` 是本轮实际过程小汇总。

## 精确最小闭包

- `src/graph/executable.cc` 的当前对象是 `../inference-effect-domains-20261030/compile/sdk-src__graph__executable_cc/unit.obj`。原实际编译命令及其来源receipt已写入 `discovery.json`，无需重建整个Graph或SDK。
- 若补丁只改这个 `.cc`，在229项原链接中原位替换对象1，合计仍229，不 append 第二份Graph实现。其余缓存保持不动。
- 当前 tiny consumer 的246项 source pins 全部精确相同，原对象可复用；只重新链接到替换后的229闭包。没有头/API/ABI变化时不重编tiny。
- 原H64/GA/V64/C16、CPUFFN1、4输出的 `--engine` 失败命令全部参数已从原command receipt原样记录。未来诊断只运行这一个进程；旧baseline/candidate两次拒绝不会重跑冒充新结果。

## 既有CPU回归配方

可复用 `../inference-physical-spans-20261028/validation/refinement/logs/region-test/command.json` 的 `region_provider_test.cc` 编译配方。它使用本机同一 MSVC14.50路径、`/MD /O2 /W4 /WX`、CPU capability，已有 Googletest include缓存。

其历史对象仍存在，但294项依赖身份中有10项与现源码不同，不能标成当前对象复用。实际需要该CPU回归时，编译当前测试TU一次即可；不根据历史对象“存在”宣称ABI有效。具体差异路径完整记在 `discovery.json`。

链接库已经存在且是该配方原链接使用的：

- `../build-compute-v2-dev/lib/gtest_main.lib`
- `../build-compute-v2-dev/lib/gtest.lib`

将新测试对象替换当前229链接中的CLI consumer并加上述两个库；使用当前缓存闭包，不把旧physical-spans整套旧SDK再次拉进来。无须获取或重新编译gtest。

仅建议以下五个已有CPU测试过滤项供root按最终补丁选择，不跑完整region矩阵：

1. `GraphRegions.InputSliceAlignmentDeclinesRegionAndLeafBeforePreparation`：68B偏移对256B要求的region/leaf资格拒绝与低alignment候选，required instance不逃逸。
2. `GraphRegions.CopiedSliceGetsItsOwnAlignedInputBeforeCandidateQualification`：真实跨domain copy后的独立aligned输入。
3. `GraphRegions.RetryRebuildsPhysicalInstanceAlignmentsWithoutRejectedRequirements`：被拒绝分区不污染winner的alignment数组。
4. `GraphRegions.DomainConstantViewChecksActualPortAlignmentBeforeEnqueue`：domain constant view端口实际alignment。
5. `GraphRegions.LeafErrorsRemainFatalDuringBothRegionFallbackStages`：保持真正leaf错误类型与传播。

这些现有用例不等同于同domain透明alias“应物化而非拒绝”的新增能力测试。诊断补丁只给上下文时不能宣称修复；后续实际修复仍要有针对原缺项的有限回归。当前没有更改budget、改变prompt宽度或下载fixture。

原命令、编译/链接配方路径、gtest库哈希、依赖差异与过滤串均在 `discovery.json`。等待root冻结后再生成实际构建/运行计划，记录每次真实attempt。
