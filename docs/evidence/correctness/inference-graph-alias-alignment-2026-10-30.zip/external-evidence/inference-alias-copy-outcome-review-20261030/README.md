# Optional alignment Copy：拒绝与错误归属（只读）

基于当前只有 diagnostic 的 `src/graph/executable.cc`，实际病例为普通 Graph-owned
Caller/TensorView，root65+128B、要求256B、accepts_ref0/needs_tensor1。
本报告没有实现、构建、native/GPU 或产品修改。源 pin 见 `source-pins.json`。

## 最小改动边界

同意 `append_copy` 内部返回 `Result<bool>`：**false 仅代表显式没有 qualified direct target
且没有 qualified host bridge**，也就是现 `:4983–4985` 的唯一能力缺项点。
不要按错误文字或泛 `IsUnimplemented()` 把 Status 变 false。

- 原 mandatory locality / generated-carrier materialization 的 `ensure_local_instance`
  在 false 时恢复原 `rejected_plan=true + Unimplemented`。必要的跨域复制不能忽略。
- 新 optional alignment helper 的 false 返回空 optional；当前 region/leaf 调用者沿原
  `reject_suffix(preparation_prefix)` 和**唯一** `rejected_region/operation` 拒绝 strict reader，
  允许原低 alignment 候选。required provider 约束仍由原搜索保留，不能换 provider 代签。
- Status 错误原样传播，不给它另置 reader flag，不保存/清空整个 outcome 来“修正”冲突。
  新副本只属于本次 cold attempt；不增加 PlanState / Invocation owner。

## 现有错误路线

| 位置（当前行） | 真实含义与现处理 | 新 helper 必须保持 |
|---|---|---|
| `supports_copy:4896–4920` | shared Queue 先证明 TensorView/resource；已定义的 resource mismatch 返回 false；native `can_copy` 返回 Result<bool> | 不能把 `can_copy` 的 unexpected Status 当“不支持” |
| `copy_targets:4922–4941` | 仅收集 qualified target；查询错误、元数据分配错误直接返回 | 不转 false、不重试掩盖错误 |
| `select_copy_target:4944–4948` | `physical.choose` 保原累计 search budget；耗尽置 search_limit | 不把 ResourceExhausted 转 capability decline、不扩大预算 |
| `append_copy_step:4859–4884` | required_bytes、索引和 step 元数据失败直接返回；成功保原 descriptor/bytes | 不是 NoQualifiedCopy |
| `append_copy:4950–5000` | direct、再两段 host bridge；无 bridge 现置 rejected_plan | 仅这一明确无路线点拆 typed false，由 mandatory/optional caller 定归属 |
| `reserve_compilation_storage:5531` | 通过原 bool 区分真实 candidate storage budget decline；其他错误仍 fatal | 不转空 optional、不重置该 bool |
| native `prepare_copy:5539–5574` | 现内部 Status 协议将 Unimplemented 当冷 copy-route decline、replay policy 不符也拒完整计划；真实 allocator/validation/Internal 错误原样返回 | 不把这段 Status 分类扩大到新 helper；第一片保原流程 |

`ExecutionSourceAccess::can_copy` (`execution_source.cc:147–157`) 的 false 是已声明能力结果；
它的 unexpected Status 仍是错误。当前 Vulkan native `prepare_copy` 对 bytes%4 的明确
几何拒绝返回 Unimplemented (`graph_route_vulkan/execution_source.cc:203–206`)，而 allocation
返回 ResourceExhausted；Apple 的原 `input_spec` 也在 native prepare 路径。
这些是现有内部协议，不能从中推导“任意 provider 的 Unimplemented 都可重试”。

## Late native copy 不需要先引入 owner 表

现 `rejected_plan` 在 `executable.cc:5986–5993` 只记录本次完整 physical route 拒绝。
下一轮 `:4478–4489` 先 `physical.next`；物理选择耗尽后仍 `routes.next`，所以并不会永久
排除原低 alignment region/leaf。第一片保原路径，不加 copy-owner/prefix 表或两阶段搜索。

不能把每次 late Unimplemented 都直接 `reject_suffix(reader_prefix)+reader flag`：
这可能把同一 reader 的另一可行 copy target/bridge 一起丢掉。只有实际新负例证明有必要
时再做更细剪枝；届时需保留失败 copy 的选择分支并裁无关后缀，不能靠“下一 non-copy step
就是 owner”猜身份。累计预算耗尽仍是失败，不改限制来保证某个候选必能到达。

## 一处已有 late-error flag 隐患（非 H64 根因）

当前先以 `status.IsUnimplemented()` 置 `rejected_plan`，随后若 provider 返回
`state!=nullptr` 但没有可销毁的 vtable，代码把返回值改为 Internal（unowned artifact），
原 `rejected_plan` 仍 true，外层会把这个 Internal 当 plan decline。它是错误分支的已有
可审查隐患；不要为此次 helper 增加同类泛捕。若修此支，至少在 ownership validation 后
才确认 capability decline，并增加 malformed-artifact 错误不被隐藏的负例；不据此扩大
本片为完整 native transfer outcome API 重构。

## 必须保留／重述的真实测试

- `InputSliceAlignmentDeclinesRegionAndLeafBeforePreparation:4440` 的 strict+Copy 成功行为
  可以改变；但还须另造**实际 can_copy=false/无桥**使原 compatible route 成功，并保 required
  provider 不被绕过。不能只改期望计数或根据新 helper 结构写镜像断言。
- `CopiedSliceGetsItsOwnAlignedInputBeforeCandidateQualification:4503` 保已有跨 storage
  对齐副本；它不能代签新同域修复。
- `PhysicalCopyFailureBacktracksWithoutPreparingArtifacts:8471` 的两臂保能力缺项可回退、
  resource validation Internal 原样 fatal，且没有提前 heavyweight artifact。
- `UnavailableFinalOutputCopyFailsBeforeAnyArtifact:6102` 保 mandatory copy 不能省略；
  `SearchBudgetIsCumulativeAcrossTransactionalDeclines:8396` 保原累计搜索上限。
- `RegionErrorCodesDoNotGrantPermissionToRetry:10087`、
  `LeafErrorDoesNotBecomeARetryAcrossProvidersOrTargets:10792`、
  `LeafErrorsRemainFatalDuringBothRegionFallbackStages:10818` 保 typed error 即使是
  Unimplemented/ResourceExhausted 也不得被新 helper 吞掉。
- `RetryRebuildsPhysicalInstanceAlignmentsWithoutRejectedRequirements:10243`、
  `DomainConstantViewChecksActualPortAlignmentBeforeEnqueue:10280` 保回滚与 domain/external
  实际身份检查；`FinalWorkspaceRetryKeepsHardConstraintsAndBudgets:9202` 和
  `FinalWorkspaceRetryDoesNotHideRealProviderError:9242` 保预算与真实错误分离。

还需候选实际证明：aligned 路径零额外 Copy；同值多 readers 复用副本但 reference reader
仍用原 producer；Copy source/destination 生存期重叠且不被 optional inplace 合回原坏 alias；
平行实例数组及旧 reserve 上界足够或可正确增长；直接查询 Status、metadata failure 与 native
prepare failure不变成空 optional。仅按当前 copy scope 设计，不宣称这些已经通过。
