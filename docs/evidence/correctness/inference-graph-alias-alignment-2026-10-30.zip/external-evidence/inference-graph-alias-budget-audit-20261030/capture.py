"""Read bounded current source and existing failed-run metadata; no execution."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]

def pin(path):
 p=Path(path);raw=p.read_bytes()
 return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def source(relative,regions):
 p=R/relative;lines=p.read_text(encoding='utf-8-sig').splitlines()
 return dict(**pin(p),scopes=[dict(first=a,last=b,excerpt='\n'.join(lines[a-1:b])) for a,b in regions])

sources=[source('src/graph/executable.cc',[(2007,2025),(5979,6030),(7856,7911),(8165,8191),(8760,8766),(10567,10591)]),
 source('include/hyle/graph/executable.h',[(794,801),(873,881)]),
 source('tests/graph/region_provider_test.cc',[(2787,2806),(4591,4614)])]
run=R/'.scratch/inference-graph-alias-repair-harness-20261030/runs/first-tests/attempt1'
reports=[pin(run/name) for name in ['command.json','process.json','report.json','stdout.log','stderr.log']]
data=dict(status='READ_ONLY_BUDGET_FAILURE_AUDIT_NOT_A_FIX',
 base_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources=sources,existing_run=reports,
 actual='Seven new tests executed: six pass, budget fixture fails because bounded compile returned success. No winner report fields retained by that run.',
 established='Implicit and explicit environments have equivalent single system domain/compute lane. Report is one feasible plan peak; providers and legal backtracking are not fixed by region_selection=Disabled.',
 unproven='Actual bounded provider/physical winner and workspace peak, therefore no claim that it leaked budget or precisely which alternate it selected.',
 no_new_native_build_or_product_edit=True)
(W/'sources.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=data['status'],source_files=len(sources),failed_run_metadata=len(reports))))
