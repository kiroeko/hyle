# 可证明不可满足的 Caller-Copy 预算负例（scratch 设计）

不修改当前失败 case；先让其 bounded report 解释合法回溯。新负例应独立验证**固定 Caller root + aligned Caller replica 的已知 Graph workspace**，不把首次任意可行计划当全局最小值。

建议沿现 `make_slice_alignment_graph(17, true)`：外部 F32[85] → Neg → View(offset17,count17) → Neg。两个独立 RegionProbe 都设置 system_resource / bounded_unary_domain；root probe 用4B/default合法输入 alignment，reader probe用256B。不要用同一个256B probe给外部输入也加上未保证的256B地址合同。

`region_selection=Disabled`，并同时用 NodeProviderConstraint 硬锁 node0 到 root probe IID、node2 到 reader probe IID；只锁 reader 不够，root 还可换成 ggml/native 的其它计划。metadata View 保持原 intrinsic 路线。实际 graph 必须是 unary_root=true，恢复输出系数是 +1（两次 Neg），不是原 Binary Add 根的−2。

## 源码给出的下界

- `validate_bounded_unary` 支持 plain rank-one F32 Neg，dense输出且同extent；当前 row85 根必须物化完整340B，不能变成只算17个元素。leaf关闭region后也不能用融合region裁掉根。
- `prepare_single` 返回现 kUnaryPreparedVTable，普通 Compute输出按Caller TensorView规划；该vtable的 `region_alias_support` 返回空不支持alias。根不能变 generated/provider-private backing，也不能借用外部 input。原 planner 同时禁止 internal output 捐献 external input。
- 严格 reader 看到原 View 的68B offset不满足256B，必须走同域实体副本，副本是F32[17]、68B、独立非alias root；保持原 descriptor，不是拷原340B整根。
- Copy step s 读取原View；其 LifetimeRequest 的 end 至少为 s+1，View属于340B root alias group。LifetimePlanner（lifetime_plan.cc:532–556）用 group.size=max(relative_offset+request.size)、group.end=max(end)；原根340B的extent不会缩成68B子段。
- 68B目的从step s开始。Graph group_before 因 source end>s 的重叠不允许与目的共用backing chain；LifetimePlanner也不能重用同时存活的独立root。故同域 known requested workspace 至少340+68=408B，padding/对齐只可能增加。

因此 **407B** 对这组完整固定 Caller 合同确实不可行；它不是可以直接套在未锁 root 的旧图上的魔数。无需扩大预算、关闭回溯或新增用户开关。能切换为不同provider/representation的图仍应在cap内合法成功，这与该负例并不冲突。

## 建议断言和恢复

先用相同显式 Environment + 同样provider约束得到成功控制，核实 root=340B Caller/TensorView/非alias、replica=68B Caller/TensorView/非alias、实际Copy读的View属于原root、copy_bytes=68、domain0 peak≥408；root与reader选中原指定IID。不要把所有workspace精确等于408作为必要条件。

仅将该 Environment domain0 cap改为407，要求 ResourceExhausted、零enqueue；不接受其它provider代签，不吞实际准备错误。恢复cap到成功控制的已知峰值或无限值，要求原图/约束成功，copy_bytes及角色保持，domain0 peak≤实际cap，两轮replay精确得到 +input.slice，外部输入不变。报告cap对应Graph已知workspace，外部输入/外部输出caller buffer、provider-private未知成本和RSS均不是这个下界的一部分。

这些是设计与源码证明，尚无此强负例的编译/运行结果。原失败 test 的合法 bounded winner 与新独立收费负例须分别记录，不能把前者的失败删除或改名成后者已经通过。
