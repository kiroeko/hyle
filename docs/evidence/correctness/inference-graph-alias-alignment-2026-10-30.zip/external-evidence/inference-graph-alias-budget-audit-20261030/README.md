# workspace 预算 case 首轮失败：独立只读审查

当前实测是新7 tests中6 PASS、`AlignmentRepairKeepsWorkspaceLimitsAndRecoversAfterRefusal` 一项FAIL；18项相关回归与 H64 实验已停止，尚未启动。本审查没有修改产品、改变断言、构建或新增运行。

## 源码可以确认什么

1. `compile(graph, Context)`（`src/graph/executable.cc:10567`）只包装一个 system_resource StorageDomain（无限 cap）、原 Context source target0、单 compute lane。预算 case 的显式 Environment 使用相同资源/source/default-storage；缺省 lanes 在 `initialize_plan_lanes:2007` 补成同一个 target0 compute lane。因此不存在已知的“隐式另一个设备/域”差异。
2. `CompileReport::workspace_bytes()`（:8760）返回所选计划的 Graph workspace 总峰值，不是所有 provider/physical route 的最小值。`plan_workspace` 对各 backing-chain resource 的 LifetimePlan peak 求和，并按 workspace_storage 归入 domain（:7856–7908）；storage report 同样按原 LifetimePlan 求和（:8165起）。这个 case 只有一个域，总峰值应等于 domain0 峰值，并不是误把多域总量当域限额。
3. domain0 超 cap 时会设 `rejected_plan` 并返回 ResourceExhausted；`prepare_placed_steps` 随后沿 physical.next / RouteSearch.next 继续寻找计划。默认 `workspace_reuse=kExistingOrderOnly`，不是隐式启用了额外 serialization；已有 provider/physical 回溯本来就允许在相同 cap 内选择另一计划。
4. `make_context(strict)`（`tests/graph/region_provider_test.cc:2787–2805`）除了 priority100 的 strict probe，还装 ggml_cpu200、native300；预算 case 的 options 只有 region_selection=Disabled，未限制 leaf provider。**关 region 不等于锁 strict leaf。** 首个无限 cap 计划的 bytes−1 不能证明其它 provider/physical 组合全都不可能。

因此源码足以确认 fixture 使用了一个未经证明的下界假设；当前 native 成功的 bounded compile 尚不构成漏预算证据。原 `copy_bytes==68` 的 EXPECT 未失败，说明原计划确有 repair Copy；日志没有保存 bounded winner，不能先断言它具体换成了哪一个 provider、零 Copy，或多少 workspace。

## 需要的最小实际报告

仅为此失败 case 保留两份成功 CompileReport（原无限 cap、第二个 bounded 编译）的小字段即可，保持现失败断言以先诊断：

- 总 workspace/backing 数；storage_domain_count；domain0 workspace_bytes / workspace_budget_bytes / backing数，明确输入 cap=original total−1。
- 每个 physical step 的 kind、node_begin/node_count、provider_instance / implementation、target/storage/lane、workspace、copy bytes；至少确认 node2 strict leaf 是否改变。逻辑 node 数单独列。
- copy_bytes、fallback operation/region counts、materialized constants；plan/operation/region rejections、physical search states、placement attempts、是否触及搜索上限。
- target/domain/lane、workspace_reuse 和 provider约束，确认两次实际环境与源码预期一致。无需 tensor trace、GPU profile 或再跑其它消费者。

判别顺序：

1. bounded `domain0.workspace_bytes <= cap`，并且 provider/copy/schedule/packing/复用 facts 改变：预算被执行，测试的“首个可行峰值是最小值”假设错误。
2. bounded 域峰值 `> cap`：与源码最终 gate 不一致，需要检查限额是否进入同一 Plan、报告是否对应 winner，以及是否存在遗漏的 finalize 路径，才有依据修改 core。
3. 若两计划步骤/requirements 看似相同但峰值不同，比较实际 physical instance alignments/aliases、workspace requests/backing chain 和 lifetimes，不能只看逻辑节点或 provider 名称。

在这些字段出来之前，不把断言改成“成功也接受”，不调高 cap，也不改核心。后续若证实 fixture 假设错误，可选择明确锁定所要验证的 provider/资源合同，或在固定已编译 route 的 Invocation 上验证预算；需要说明验证的预算是哪一类。直接将一个非最优计划峰值−1 当成所有计划的不可行证明，不能继续使用。

## 证据边界

预算 gate 管 Graph 已知 workspace requested backing，不是物理内存/RSS/VRAM 上限，也不包办 provider-private未知成本。旧失败原日志/XML保持；当前 src/Graph 已能 CXX/link 仅说明编译通过，不能将7项中的预算失败签为 PASS。旧 SCOPED_TRACE 编译失败与其 layout-only 修正属于另一条已保存事实，不被本审查覆盖或重写。
