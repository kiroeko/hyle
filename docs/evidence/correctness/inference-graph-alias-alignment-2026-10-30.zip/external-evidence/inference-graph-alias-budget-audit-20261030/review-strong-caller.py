import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPAIR = ROOT / '.scratch/inference-graph-alias-repair-20261030'
OLD = REPAIR / 'superseded-c1/tests/graph/region_provider_test.cc'
NEW = REPAIR / 'candidate/tests/graph/region_provider_test.cc'
PRODUCT = ROOT / 'tests/graph/region_provider_test.cc'
CORE = ROOT / 'src/graph/executable.cc'
START = b'TEST(GraphRegions, AlignmentRepairKeepsWorkspaceLimitsAndRecoversAfterRefusal) {'
NEXT = b'TEST(GraphRegions, AlignmentCopyDoesNotTurnRealProviderErrorsIntoFallback) {'

def parts(raw):
    start, end = raw.index(START), raw.index(NEXT)
    return raw[:start], raw[start:end], raw[end:]

old, new = OLD.read_bytes(), NEW.read_bytes()
op, ob, os = parts(old)
np, nb, ns = parts(new)
assert op == np and os == ns
assert PRODUCT.read_bytes() == new
assert hashlib.sha256(new).hexdigest() == '6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00'
assert hashlib.sha256(CORE.read_bytes()).hexdigest() == '9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc'
assert new.count(b'\n') == new.count(b'\r\n')

report = {
    'status': 'INDEPENDENT_STATIC_REVIEW_NO_BLOCKER_FOUND',
    'candidate_sha256': hashlib.sha256(new).hexdigest(),
    'candidate_bytes': len(new),
    'core_sha256_unchanged': hashlib.sha256(CORE.read_bytes()).hexdigest(),
    'only_budget_test_changed_from_c1': True,
    'unchanged_prefix_bytes': len(op), 'unchanged_suffix_bytes': len(os),
    'product_equals_candidate': True,
    'CRLF_preserved': True,
    'native_runs_by_this_review': 0, 'builds_by_this_review': 0,
    'checks': [
        'Unary root Neg F32[85] -> View(offset17,count17) -> strict Neg; no region fusion.',
        'Distinct typed producer IID0 and strict 256B reader IID1 both hard constrained; GGML/native cannot replace either.',
        'Same explicit one-domain Environment for unlimited control, cap407 refusal, unlimited recovery; only cap changes.',
        'Control inspects original340B and replica68B Caller/TensorView/nonexternal/nonconstant/nongenerated/nonalias roots.',
        'Copy source is selected original root alias at68B; no-alias support of actual prepared root is asserted.',
        'Report preserves hard selected IIDs, known workspace>=408 and<=domaincap, exact68B copy; distinct ranges checked.',
        '407 derives from two live roots semantic sum, not an arbitrary first plan peak. Existing Copy source end=s+1/destination begin=s means overlap.',
        'Refusal remains ResourceExhausted with zero provider submission, then exact two-turn double-Neg replay multiplier+1 and input unchanged.',
        'PreparedOperation.alias_support, CompileReport physical index mapping and LifetimePlan MemoryPlacement fields checked against actual headers/source.'
    ],
    'historical_diagnostic_not_pass': 'Original c1 test failed because cap407 legally selected GGML340/noCopy; retained diagnostic proves budget backtracking, not a leak.',
    'limits': [
        'Static review does not sign CXX or native execution.',
        'Bound is Graph-known domain workspace. It excludes external caller bindings, unknown provider-private memory and process RSS.',
        'The test checks plan placements and Copy alias identity; Copy lifetime overlap is derived from unchanged planner source, not a new liveness-report API.'
    ]
}
out = Path(__file__).with_name('strong-caller-independent-review.json')
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ('status', 'candidate_sha256', 'candidate_bytes', 'only_budget_test_changed_from_c1')}))
