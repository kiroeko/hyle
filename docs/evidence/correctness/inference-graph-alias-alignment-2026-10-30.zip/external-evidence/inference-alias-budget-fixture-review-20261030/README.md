# Workspace budget fixture：首轮失败后的只读归因

真实结果：新首组 7 项中 6 通过、1 失败。预算测试的 limited compile 实际成功，原
`ASSERT_FALSE(refused)` 失败；尚未记录该成功计划的 CompileReport，所以不能先说具体
provider、Copy 消失或实现漏记预算。首轮 XML/log/process 必须保留，不能签通过。

已核源码：

- `compile(graph, context)` 在 `executable.cc:10567–10586` 创建 system resource 域0、
  target0、一个 compute lane；测试 explicit environment 的空 lanes 在 `initialize_lanes`
  补同一个 lane。source 两次 acquire 仍是同 Context owner。两者没有不同资源或额外域。
- `CompileReport::workspace_bytes` 来自所有 workspace resource peak 的和；domain0 报告
  从同一批 resource peak 累加。本夹具只有一个 domain，因此不是将多域总量当单域 cap。
- `make_context(strict)` 实际注册 strict、ggml_cpu、native 三个 provider。
  `region_selection=kDisabled` 只关 region，不锁 leaf。现预算测试没有 NodeProviderConstraint。
- 超出域 cap 会经原 rejected_plan → physical.next → routes.next 搜索下一个合法计划。
  因此首个可行计划的 peak−1 **不是所有合法计划的下界**。存在更低 workspace route 是
  有根据的候选解释，但仍须 actual report 证明本次成功 winner，而不是猜具体 provider。

最小 actual 诊断建议（当前未修改/运行）：在这一个预算 case 中，用 CompileReport 的公开
API 记录三份有界事实：implicit unlimited；同一 explicit environment 的 unlimited；limited
若成功的实际报告。每份仅记录：

1. 每域 `storage_domain(i)` 的 workspace_bytes / workspace_budget_bytes / backing_count；
   总 workspace_bytes、copy_bytes、materialized_constant_bytes 与 region/leaf 数。
2. 仅本图最多几个 step：kind、node_begin、provider family/instance/implementation、target；
   Copy 的 `step_input/step_output → physical_value` 的 storage、alias_source、workspace_backed。
3. search 的 route_plan / region / operation rejections 和 states；node2 最终 provider。

这些数据写入本次 GTest XML property 或短 report，不输出 tensor 数组。limited 成功只在
实际 domain bytes≤cap 时才是合法回溯；若报告/实际超 cap，才是对应实现问题。先保原失败，
不能直接调大 cap 或把 ASSERT_FALSE 改成成功来回避它。

若事实确认是合法回溯，强负例应检查修复路线本身：hard 锁 node2 到 strict provider，并
从固定逻辑描述建立预算下界。root 是内部 Caller F32[85]（340B），replica 是 F32[17]
（68B）；两者在 Copy step 的区间重叠（source end=s+1、destination begin=s），且 Copy
不进 optional inplace。其需求至少408B，可用407B cap 验证必须拒绝，而不依赖第一个计划
的 padding/实现 scratch peak；恢复原 cap 后仍需 strict provider、68B Copy、完整重放。
此推导适用于这个夹具的普通 Compute Caller 输出，不能推广到 native-generated 或常量。

当前无产品修改、构建或 native/GPU。arch 的独立只读分析也确认环境同义与未锁 leaf 的
测试假设缺口；最终调整仍由 root 根据 actual report 授权。
