# Alias alignment 冷拒绝诊断候选（未应用、未构建）

基线 `ec4b30b4dd58e09594822882e4689d78835dc4d7`；原 Graph 源 SHA256 `8d584ddedcb580622410e57acd600a58cdbcb092095e5ab603f474271d267e53`。完整源快照在 `base/src/graph/executable.cc` 与 `candidate/src/graph/executable.cc`，补丁为 `alias-diagnostic.patch`，完整 pin/范围在 `plan.json`，`prepare.py` 可在精确基线重现。

只新增一个 anonymous cold-error formatter，并包装原 region / operation 两个 `!aligned` 分支的 Unimplemented return。原错误文案、代码、rejected_region/operation、reject_suffix、accepts_input_alias_alignment、ensure_local_instance、Copy、provider/资源选择和预算均不改。没有新开关、日志、公共接口、测试预期或成功路径 formatter 调用；Invocation 路径也不调用它。只在已有失败分支使用原 Status.WithContext；格式缓冲是固定 1024 字节，整数用已有 to_chars，无 tensor payload、指针或无界数组输出。

字段包括 node_first/node_count（region 起始节点及数量，非假设连续）、port/value/physical instance/storage/target、alias root 与累加 offset/alignment、chain_valid、accepts_ref/needs_tensor、instance/root 的 roles/kind/projection、variant 和实际独立 ShapeBindings 的前 8 项及总数。exact_variant_index 在 child 编译成功后才赋值，因此失败时打印其实际状态 `variant=unassigned`；该字串不判断当前是 outer 还是 child。未改的外层 compile_exact_variants 失败 context 仍补充真实 variant index，options.shape 则是该 child 的真实 bindings。这里不伪造 0 或猜 T。`shape_count` 明示截取边界；维度 binding value 仍用原有符号含义，不自动将其解释成 token 数。

准备脚本已验证：两处 wrapper 与 helper 逆替换后，完整原源精确恢复；目标两个接纳函数未变；git apply --check 成功。没有 CXX/link/运行验证。root 审阅后决定是否应用/编译；不得把这些静态检查写成通过原生测试。

root 发现初稿 region callsite 引用了该 for 未声明的 `value`；当前候选已改成直接读取原 `logical_inputs[index].ordinal()`（diagnostic value 和 needs_tensor 两处）。以最新 plan.json/patch pin 为准，旧稿未应用或编译。leaf 分支的 `value` 则在同一 for 内原本已有声明。

两处原 `reject_suffix` 仍先于错误返回。它只调整 `ResourceSearch` 自己的 `cursor_` 并 pop 自己的 `path_`（原 executable.cc:3171–3176），不修改 PlanState、discovery.values 或 producer_instances；本候选也不增加任何此类修改。整候选 Plan/physical arrays 的 reset 位于外层下一轮 `prepare_placed_steps`，在本次诊断返回之后。因此 formatter 读取的 plan arrays、logical input spans 及 needs_tensor 所用 producer_instances 在此处仍有效。

## 身份边界先于后续 Copy 设计

此补丁不增加 materialization，也不改旧 required-provider 测试。未来修复不能将「accepts_reference=true」等同于可任意复制：`RegionInputRequirement`（`region_provider.h:338–344`）只允许由同一真实 source owner 提供 native/original output reference，仍须资格检查 implementation/port/description/runtime。`ensure_local_instance` 当前特意让 reference reader 继续用原 producer，即使 value×storage 已有 caller replica。

同样，按值 bytes 相同不证明资源身份相同：原 Store、slots SourceBinding、read/write projection、imported pending source、effect 资源、pool 和私有 ID 控制有自身 Graph/selected-port/owner/permission 证明。`slots.h:122–164` 要求原 pool、原 ID carrier 和真实源权限；`detail/region_access.h:370–394` 检查实际 physical reader 与透明 alias。普通 Copy 不是这些身份/权限证明，不能把副本偷偷接入 write/store/source 端口，也不能伪造原 producer/output 的引用。

因此后续 helper 应先识别实际端口语义，再仅对普通按值输入、且原 Copy 能力/读取权限/资源/budget 合同确实允许的情形做物化。reference/identity-bound 合同不成立时继续合法拒绝；不能通过放宽 alignment、node provider 或伪造 alias 通过。诊断中的 accepts_ref/needs_tensor 只是现有决策事实，不是新增的 Copy 授权。

已有 `InputSliceAlignmentDeclinesRegionAndLeafBeforePreparation` 的 hard required-provider 失败预期保持原样；先核其真实 Copy/禁止条件，再分别设计可合法物化的正例和 identity-bound / copy不可用 / budget拒绝的负例。当前候选没有提前改变这些测试合同。
