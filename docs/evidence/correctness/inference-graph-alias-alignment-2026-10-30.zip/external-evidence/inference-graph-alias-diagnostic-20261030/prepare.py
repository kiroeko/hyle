"""Prepare an unapplied failure-message-only Graph diagnostic. No build/native."""
from pathlib import Path
import difflib,hashlib,json,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
REL='src/graph/executable.cc'

def pin(path):
 p=Path(path);raw=p.read_bytes()
 return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='ec4b30b4dd58e09594822882e4689d78835dc4d7'
original=(R/REL).read_bytes()
assert hashlib.sha256(original).hexdigest()=='8d584ddedcb580622410e57acd600a58cdbcb092095e5ab603f474271d267e53'
newline='\r\n' if b'\r\n' in original else '\n'
text=original.decode().replace('\r\n','\n')
helper=r'''// Cold rejection context only. Preserve the original Status classification and
// route decision; success and Invocation paths never format this diagnostic.
Status describe_input_alias_alignment_rejection(Status reason,
    const detail::PlanState &plan, std::span<const ShapeBinding> shape,
    std::uint32_t node_first, std::size_t node_count, std::size_t port,
    std::uint32_t value, std::uint32_t instance, std::uint32_t target,
    std::size_t alignment, bool accepts_reference, bool tensor_required) noexcept {
  auto root = instance;
  std::size_t offset = 0;
  bool valid_chain = true;
  for (;;) {
    if (root >= plan.alias_sources.size()) {
      valid_chain = false;
      break;
    }
    const auto parent = plan.alias_sources[root];
    if (parent == detail::kNoInPlaceSource)
      break;
    if (parent >= root || plan.alias_offsets[root] > SIZE_MAX - offset) {
      valid_chain = false;
      break;
    }
    offset += plan.alias_offsets[root];
    root = parent;
  }
  std::array<char, 1024> context{};
  std::size_t used = 0;
  auto append = [&](std::string_view text) noexcept {
    const auto count = (std::min)(text.size(), context.size() - used);
    std::copy_n(text.data(), count, context.data() + used);
    used += count;
  };
  auto number = [&](auto numeric_value) noexcept {
    std::array<char, 32> digits{};
    const auto encoded = std::to_chars(digits.data(), digits.data() + digits.size(), numeric_value);
    if (encoded.ec == std::errc{})
      append(std::string_view(digits.data(), encoded.ptr - digits.data()));
    else
      append("?");
  };
  append("alias_input node_first="); number(node_first);
  append(" node_count="); number(node_count);
  append(" port="); number(port);
  append(" value="); number(value);
  append(" instance="); number(instance);
  append(" storage="); number(plan.instance_storage[instance]);
  append(" target="); number(target);
  append(" root="); number(root);
  append(" root_offset="); number(offset);
  append(" alignment="); number(alignment);
  append(" chain_valid="); number(static_cast<unsigned>(valid_chain));
  append(" accepts_ref="); number(static_cast<unsigned>(accepts_reference));
  append(" needs_tensor="); number(static_cast<unsigned>(tensor_required));
  append(" instance_roles="); number(static_cast<unsigned>(plan.instance_roles[instance]));
  append(" instance_kind="); number(static_cast<unsigned>(plan.instance_output_contracts[instance].kind));
  append(" instance_projection="); number(static_cast<unsigned>(plan.instance_output_contracts[instance].projection));
  if (valid_chain) {
    append(" root_roles="); number(static_cast<unsigned>(plan.instance_roles[root]));
    append(" root_kind="); number(static_cast<unsigned>(plan.instance_output_contracts[root].kind));
    append(" root_projection="); number(static_cast<unsigned>(plan.instance_output_contracts[root].projection));
  }
  append(" variant=");
  if (plan.exact_variant_index)
    number(*plan.exact_variant_index);
  else
    append("unassigned"); // The child index is assigned only after successful compile.
  append(" domain="); number(static_cast<unsigned>(plan.domain_graph.valid()));
  append(" shape_count="); number(shape.size());
  append(" shape_first8=[");
  for (std::size_t index = 0; index < (std::min)(shape.size(), std::size_t{8}); ++index) {
    if (index)
      append(",");
    number(shape[index].dimension.ordinal()); append("="); number(shape[index].value);
  }
  append("]");
  return std::move(reason).WithContext(std::string_view(context.data(), used));
}

'''
anchor='Status prepare_constant_alignments(detail::PlanState &plan) noexcept {\n'
assert text.count(anchor)==1
old_region='''          return Status::Unimplemented(
              "graph input alias offset cannot satisfy region port alignment");'''
new_region='''          return describe_input_alias_alignment_rejection(
              Status::Unimplemented(
                  "graph input alias offset cannot satisfy region port alignment"),
              plan, options.shape, region_nodes.front().ordinal(), region_nodes.size(),
              index, logical_inputs[index].ordinal(), *instance, target,
              input_requirements[index].minimum_alignment,
              input_references[index] != 0,
              needs_tensor(logical_inputs[index].ordinal(), target, input_references[index] != 0));'''
old_operation='''          return Status::Unimplemented(
              "graph input alias offset cannot satisfy operation port alignment");'''
new_operation='''          return describe_input_alias_alignment_rejection(
              Status::Unimplemented(
                  "graph input alias offset cannot satisfy operation port alignment"),
              plan, options.shape, node_index, 1, input_index, value, *instance, target,
              port_requirements[input_index].minimum_alignment, false, true);'''
assert text.count(old_region)==text.count(old_operation)==1
candidate=text.replace(anchor,helper+anchor,1).replace(old_region,new_region,1).replace(old_operation,new_operation,1)
restored=candidate.replace(new_region,old_region,1).replace(new_operation,old_operation,1).replace(helper,'',1)
assert restored==text
for function_start,function_end in [
 ('Result<bool> accepts_input_alias_alignment','Status describe_input_alias_alignment_rejection'),
 ('  auto ensure_local_instance =','  auto needs_tensor ='),
]:
 a=text.index(function_start);b=text.index(function_end,a) if function_end in text[a:] else text.index(anchor,a)
 old_section=text[a:b]
 assert old_section in candidate

base=W/'base'/REL;target=W/'candidate'/REL
base.parent.mkdir(parents=True,exist_ok=True);target.parent.mkdir(parents=True,exist_ok=True)
base.write_bytes(original);target.write_bytes(candidate.replace('\n',newline).encode())
patch='diff --git a/'+REL+' b/'+REL+'\n'+''.join(difflib.unified_diff(
 text.splitlines(True),candidate.splitlines(True),fromfile='a/'+REL,tofile='b/'+REL))
(W/'alias-diagnostic.patch').write_text(patch,encoding='utf-8',newline='\n')
inputs=['src/graph/executable.cc','src/graph/plan_state.h','src/graph/graph_state.h',
 'include/hyle/graph/executable.h','include/hyle/graph/region_provider.h','include/hyle/error/status.h',
 'include/hyle/graph/slots.h','include/hyle/graph/detail/region_access.h',
 'tests/graph/region_provider_test.cc']
plan=dict(status='SCRATCH_DIAGNOSTIC_ONLY_UNAPPLIED_UNBUILT',base_head=head,
 preconditions=[dict(relative=path,**pin(R/path)) for path in inputs],
 candidate=pin(target),patch=pin(W/'alias-diagnostic.patch'),source_line_endings=newline.encode().hex(),
 code_scope='One anonymous helper used only at the two existing false-alignment rejection returns. No behavior fix, public API, flag, test expectation or success-path call changes.',
 diagnostics=['node_first/node_count','port/value/instance/storage/target','root/root_offset/alignment/chain_valid',
  'accepts_ref/needs_tensor','instance and root roles/kind/projection','known variant or unassigned','actual independent shape bindings first8 and total count'],
 semantics=dict(original_status_text_and_code_retained=True,original_rejection_flags_and_search_unchanged=True,
  complete_original_source_recovered_exactly=True,acceptance_and_local_instance_source_unchanged=True,
  successful_and_Invocation_paths_do_not_call_formatter=True,copy_or_materialization_added=False),
 limits=['Static preparation only; no CXX/link/native validation.',
  'The child variant index is assigned only after successful compile; unassigned reports its actual state. The unchanged outer failure context adds the real variant index, and options.shape holds this child actual bindings.',
  'accepts_reference reports a capability bit, not permission to replace identity-bound resources with by-value storage.',
  'Only first8 independent bindings are printed; shape_count reports the complete count. No tensor payload or pointers are printed.'])
check=subprocess.run(['git','apply','--check',str(W/'alias-diagnostic.patch')],cwd=R,capture_output=True,text=True)
assert check.returncode==0,check.stderr
plan['git_apply_check']=dict(returncode=check.returncode,stdout=check.stdout,stderr=check.stderr)
(W/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=plan['status'],base=head,candidate_bytes=plan['candidate']['bytes'],
 patch_bytes=plan['patch']['bytes'],patch_sha256=plan['patch']['sha256'],git_apply_check=check.returncode)))
