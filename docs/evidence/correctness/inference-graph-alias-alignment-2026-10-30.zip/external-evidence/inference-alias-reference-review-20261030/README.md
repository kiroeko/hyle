# 输入对齐物化与绑定身份：本地源码核对

只读完成。没有产品修改、下载、构建或 native/GPU。实际版本及 10 个文件的 SHA256、HEAD
blob hash、精确条件与有界代码片段见 `references.json`；所有选中文件均与实际 HEAD
字节相同（也记录仅规范 CRLF 后的比较），不声称整个 checkout 干净或是最新上游。

| 本地引擎 | 实际 HEAD |
|---|---|
| TensorRT-LLM | `46d9966b54d9d11998b712e732fb20f64d4d35c0` |
| vLLM | `276fbcff2717bd934cfa37c8a2e4c391f3e7237b` |
| llama.cpp | `23b0202a189c44a54625aadcb37a946dd1d6278d` |

最直接的依据在 TRT `tensorrt_llm/_torch/modules/fla/fused_sigmoid_gating_recurrent.py`：
`:204–237` 先限定真实可用架构、BF16 state、K/V=128、标准 T=N decode；`:268–298`
明确处理 fused projection 的 a/b 切片地址 `%32 != 0`，只在不对齐时 clone 到新存储，
对齐时保持零复制。注释特别指出：size=1 的维会令带 offset 的 slice 已被判为 contiguous，
因此 `.contiguous()` 可以保持原不对齐地址；同理 int32 `.int()` 可能不复制。
偏移后的只读 state_indices 也条件性 clone。`:407–417` 的 verify 路径同样处理。
这正是“原值可有额外物理读表示”的直接实例，但它在 Torch 算子运行时分配 contiguous
副本，**不是** Hyle 冷规划器的同 TensorDesc、多 provider、预算及回滚算法。

对应的身份边界也在 TRT：
`tensorrt_llm/_torch/custom_ops/cute_dsl_kimi_k3_custom_ops.py:1190–1244` 校验
原 `state_pool` 的 F32/rank4/内维 stride、非重叠 16B slot stride、实际地址及 device；
`:1246–1291` 将其声明为 `mutates_args=(state_pool,)`，校验后把**原池**传给 runner，
不合法直接拒绝，没有悄悄 clone 可变池。GDN decode 的 `:323` 也直接传原 state source。
复制读取的 indices 不等于可以复制或替换被更新的状态身份。

另外三组是相邻机制，不能冒充同一个算法：

- vLLM `model_executor/layers/utils.py:104–144,166–188` 对 CuTe BF16 GEMM 检查实际
  32B pointer、布局等；不能实现时退回 `torch.nn.functional.linear`，没有这里所需的
  通用 alias materialization。`compilation/passes/ir/clone_elimination.py:19–36,94–146`
  保留改变 stride/storage_offset 的 clone，保护后续仍用的原输入及未 donation 的输入；
  该 pass 自己在 `:72–83` 明说 aliasing 尚未完整处理，不能拿它证明一般图正确性。
  `inplace_functionalization.py:63–88` 拒绝 donated activation 的后续使用；
  `cuda_graph.py:280–285,346–358` 的 replay 地址一致仅在 debug 检查，属于捕获身份约束。
- llama `ggml-backend.cpp:1510–1544` 对不被目标 backend 支持的异 backend buffer
  创建 reader 副本；`:889–896` 保留原 strides。这是存储兼容，不是同域 offset 对齐修复。
  `ggml-cuda/mmvf.cu:792–811` 对不满足向量 stride 对齐的候选直接返回 false，也属合法路由选择。
- llama `ggml-alloc.c:631–674` 只在 owned、非 output、同 layout、没有剩余读者/view 等条件
  下复用；`ggml-backend.cpp:2217–2228` 的 view 绑定原 buffer+offset。
  `ggml.c:3592–3611` 的 CPY 是指定 destination 的 view，`:3638–3654` 的 CONT
  则建立独立输出。这些能支持“读副本、指定写身份与 view 不是同一合同”的边界。

Hyle 必须自己保证的部分：只有允许普通 tensor 副本的 reader 可接收额外物理实例；
reference/identity-bound/mutable port 仍保原接纳身份，除非其 API 本来定义了事务 copy-back。
副本保持原逻辑描述和字节，不能凭 contiguous 例子擅改 dtype/strides/发布身份。
Copy capability、预算、lifetime、队列依赖、候选回滚、多个 reader、失败后重试都必须走 Hyle
原合同并做本地检查；参考源码不代签这些正确性。当前 H64 的实际 T/node/port/offset/alignment
仍待有界诊断；相似成熟机制不能直接推出具体根因或保证 Copy 必然成功。
