"""Pin selected actual local engine sources and bounded mechanism excerpts.

Read-only reference work: no checkout, download, compile, inference, or GPU.
"""
from pathlib import Path
import hashlib
import json
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R.parent


def digest(body):
    return hashlib.sha256(body).hexdigest()


def pin(root, relative, scopes):
    source = root / relative
    body = source.read_bytes()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    blob = subprocess.check_output(['git', 'show', head + ':' + relative], cwd=root)
    normalized_match = body.replace(b'\r\n', b'\n') == blob.replace(b'\r\n', b'\n')
    assert normalized_match, relative
    lines = body.decode('utf-8-sig').splitlines()
    return {
        'path': str(source.resolve()), 'relative': relative, 'bytes': len(body),
        'sha256': digest(body), 'actual_HEAD': head, 'HEAD_blob_sha256': digest(blob),
        'byte_equal_HEAD_blob': body == blob,
        'source_equals_actual_HEAD_after_only_CRLF_normalization': normalized_match,
        'scopes': [{'first': first, 'last': last, 'purpose': purpose,
                    'excerpt': '\n'.join(lines[first - 1:last])}
                   for first, last, purpose in scopes],
    }


selection = {
    'TensorRT-LLM': [
        ('tensorrt_llm/_torch/modules/fla/fused_sigmoid_gating_recurrent.py', [
            (204, 237, 'FlashInfer decode eligibility: supported architecture, BF16 source state, K/V128 and standard T=N decode.'),
            (239, 326, 'Direct pointer-mod32 conditional operand/index clones; explains contiguous() no-op for size1 offset slices; original state source passed through.'),
            (366, 434, 'Verify path also clones misaligned read operands/indices, keeps state/intermediate output identity and disable_state_update contract.'),
        ]),
        ('tensorrt_llm/_torch/custom_ops/cute_dsl_kimi_k3_custom_ops.py', [
            (1190, 1244, 'Indexed mutable state pool exact shape/inner-stride/slot-stride/pointer/device validation; reject instead of silently cloning pool.'),
            (1246, 1291, 'custom_op mutates_args=(state_pool,), then validator and direct same-pool runner binding.'),
        ]),
    ],
    'vllm': [
        ('vllm/model_executor/layers/utils.py', [
            (104, 144, 'CuTe BF16 route eligibility includes CUDA/family100, dtype/device/contiguity/K128 and both actual pointers mod32.'),
            (166, 188, 'If that specialized route cannot implement, use torch.functional.linear; no universal materialization algorithm here.'),
        ]),
        ('vllm/compilation/passes/ir/clone_elimination.py', [
            (19, 36, 'A clone changing stride or storage_offset is not layout-preserving.'),
            (72, 83, 'Pass explicitly calls itself unsafe and does not guarantee general alias correctness.'),
            (94, 146, 'Keep layout-changing clones, keep clones whose mutation would affect a later original use, and protect non-donated graph inputs.'),
        ]),
        ('vllm/compilation/passes/ir/inplace_functionalization.py', [
            (20, 32, 'maybe_inplace activation donation semantics.'),
            (63, 88, 'Reject later uses of a donated activation; record donated placeholder IDs.'),
        ]),
        ('vllm/compilation/cuda_graph.py', [
            (280, 285, 'Capture stores concrete input tensor data pointers.'),
            (346, 358, 'Debug replay verifies same addresses; a replay identity constraint, not the Hyle reference-port ABI.'),
        ]),
    ],
    'llama.cpp': [
        ('ggml/src/ggml-backend.cpp', [
            (888, 897, 'ggml_dup_tensor_layout copies original tensor strides.'),
            (1510, 1544, 'Different-backend unsupported buffer causes per-backend input copy, remapping only that consumer; adjacent storage compatibility mechanism.'),
            (2217, 2228, 'A view binds original buffer and original view_src.data plus view_offs.'),
        ]),
        ('ggml/src/ggml-alloc.c', [
            (631, 674, 'Inplace reuse requires owned parent, not published output, matching layout, exclusive child/view facts; external/output identities protected.'),
        ]),
        ('ggml/src/ggml-cuda/mmvf.cu', [
            (792, 811, 'Vectorized MMVF candidate declines unsupported innermost type/shape or row-stride alignment; not an automatic alias-copy fallback.'),
        ]),
        ('ggml/src/ggml.c', [
            (3592, 3611, 'CPY result is a view of caller-specified destination, with source and destination explicit.'),
            (3638, 3654, 'CONT produces a separate logical tensor/op; different from a destination-bound copy.'),
        ]),
    ],
}
references = {}
for name, files in selection.items():
    root = BASE / name
    references[name] = {'root': str(root.resolve()),
        'actual_HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'files': [pin(root, relative, scopes) for relative, scopes in files]}

report = {
    'status': 'PASS_SELECTED_ACTUAL_LOCAL_REFERENCE_SOURCE_BYTES',
    'hyle_observed_HEAD': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    'references': references,
    'conclusions': {
        'direct_alignment_materialization': {
            'reference': 'TensorRT-LLM fused_sigmoid_gating_recurrent.py:268-298 and407-417',
            'condition': 'FlashInfer eligible decode/verify operand/index actual data_ptr modulo32 is nonzero.',
            'mechanism': 'Conditionally clone into new allocator-owned aligned storage. Aligned operands retain zero-copy. Singleton-contiguous or same-dtype conversion may be no-op and cannot be relied on to realign.',
            'transferable': 'Consumer-specific physical representation can repair a read-value alignment contract without modifying the original aliased source.',
            'not_proven': 'This is operator-level runtime Torch clone into contiguous storage, not Hyle cold physical planner, same-TensorDesc strided copy, multiple-provider search, budget, rollback, reference ports or H64 root diagnosis.',
        },
        'mutable_identity_constraint': {
            'reference': 'TensorRT-LLM cute_dsl_kimi_k3_custom_ops.py:1190-1291',
            'condition': 'Indexed KDA state_pool is a declared mutates_args input, with exact dense inner dimensions, nonoverlapping16B slot stride and actual16B pointer.',
            'mechanism': 'Validate and reject illegal state pool; pass original state_pool directly to runner. Do not repair it by a silent temporary whose writes would disappear.',
            'transferable': 'A value/index operand copy does not authorize changing mutable state identity.',
            'not_proven': 'One strict mutable custom-op case does not define every reference/generated/external port rule in Hyle.',
        },
        'adjacent_fallback_and_ownership': [
            'vLLM BF16 CuTe route validates actual pointer32B and falls back to torch F.linear when can_implement is false; no claim of a matching copy planner.',
            'vLLM clone elimination preserves layout-changing clones and non-donated/later-used inputs, but explicitly lacks general alias soundness. Donation validation is useful scope evidence, not a proof for arbitrary Hyle graphs.',
            'vLLM CUDA replay debug address equality and llama view identity / external-output inplace restrictions reinforce identity and lifetime constraints; none is the Hyle reference-port ABI.',
            'llama scheduler uses layout-preserving copies only for unsupported different-backend buffers. This is storage compatibility, not evidence of same-storage alias alignment recovery.',
            'llama vectorized MMVF alignment qualification legitimately declines a candidate; this does not require every kernel/backend to copy.',
        ],
        'Hyle_own_correctness_derivation': [
            'Only a reader whose actual contract admits an ordinary copied tensor may receive a same-logical-value copy. A reference/identity-bound/mutable port must retain its original admitted identity unless its API explicitly defines transactional copy-back.',
            'A copied physical instance must preserve original logical TensorDesc and data bytes. No arbitrary contiguous reformat, dtype conversion, silent alias-offset edit, or changed published identity follows from the reference examples.',
            'Use Hyle original Copy capability, storage/queue ownership, budget, dependency/lifetime, reject_suffix and retry paths. Precise capacity, multiple-readers, rollback and failure tests are Hyle implementation obligations; none is delegated to a reference clone call.',
            'H64 concrete node/port/offset/alignment is still unknown in this reference review. A mature analogous mechanism is not a root-cause attribution or proof that every H64 refusal should be fixed with a copy.',
        ],
    },
    'limits': 'Selected actual local file bytes only, no claim of latest upstream, global working-tree cleanliness, identical algorithms, support on this host, or measured speed. No download/build/native/GPU/product changes.',
}
out = W / 'references.json'
assert not out.exists(), 'Preserve an existing immutable reference report.'
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': report['status'], 'versions': {name: item['actual_HEAD'] for name, item in references.items()},
    'files': sum(len(item['files']) for item in references.values()), 'report_bytes': out.stat().st_size}, ensure_ascii=False))
