# CUDA reader alignment: source review, 2026-10-30

The failed H64 T1 region has an actual unsatisfied **declared** reader requirement: root-relative offset 128B against 256B. The diagnostic records no provider/implementation name. This review cannot identify that selected region provider or prove its selected kernel needs 256B. No product edit, build, native process or download was performed here.

## Concrete 256B declaration path

- `src/compute_provider_ggml_cuda/program.h:21–40` supplies a default DeviceAccessible/256B `kBinding`. `boundary_alignment` uses typed alignment for F32 Add, Copy, Cast, Concat and GDN; its other operations retain 256B. Its vectorization comment states the wrapper's qualification policy; it is not an independent kernel-level proof.
- `src/graph_provider_ggml_cuda/ggml_cuda_region.cc:1528–1580` starts boundary alignments at 1 and takes the maximum `boundary_alignment` of operations using each external input/output. Indexed routes 6/7 instead use typed alignment. Thus a boundary value used by one exceptional scalar operation and one default operation still requires 256B.
- Leaf proposals use the same function (`ggml_cuda_provider.cc:1280–1293`). Compilation reconstructs the per-value maximum (`1826–1848`). Submission calls `const_pointer`/`mutable_pointer` with that actual per-value alignment (`1098–1125`); the CUDA pointer helpers reject misaligned addresses (`cuda_memory.cc:567–611`). The contract is enforced by Hyle, rather than a fabricated planner requirement.
- The GGML bridge wraps original external payload without owning it: `native_bridge_impl.h:331–347` creates a buffer context and later changes `dev_ptr`. `ggml_cuda_provider.cc:471–484,776–795` installs actual root/view addresses. Those scopes contain no additional blanket 256B assertion.

## Allocation guarantees and reader requirements differ

`compute_backend_cuda/cuda_internal.h:27` defines allocation alignment 256; `cuda_memory.cc:26–52` publishes that resource guarantee. It guarantees base allocations, not every root+offset view. GGML workspace separately uses `max(kBinding, ggml_buft_alignment)` (`ggml_cuda_provider.cc:1961–1966`); that is not the input-address requirement.

Hyle's GPU dependency lock selects GGML `456172ec733a135778adcd32d00e576a58232e45`. The locally cached original source's `ggml-cuda.cu:902–907` returns **128** from the buffer-type allocation-alignment callback. Its view init (`755–774`) accepts the original buffer and `ggml-backend.cpp:2119–2144` sets a view address to source+offset without a blanket 256B test. These facts do not prove that every vectorized, quantized, fused or library-backed operation accepts arbitrary typed offsets.

The cached source is the original locked source, not a newly established byte-for-byte snapshot of the compiled patched vendor library. The retained fixture identity says `456172ec+iq1-46cbf0e9`, source ID `f99368c68335266b`; its source `.cu` files were not retained in that fixture, while headers/identity and linked-library pins remain. `compute_ggml_runtime/CMakeLists.txt` composes in-tree patches. This review therefore does not silently substitute cached original source for the exact compiled CUDA translation unit.

## Actual local mainstream reference

Local llama.cpp HEAD is `23b0202a189c44a54625aadcb37a946dd1d6278d`. Its CUDA buffer-type alignment is also 128 (`ggml/src/ggml-cuda/ggml-cuda.cu:898–903`). Its `ggml_cuda_is_aligned` inspects pointer and strides against a supplied kernel-specific alignment (`common.cuh:381–389`). The conversion path selects vec4 only when pointers meet `alignof(cvt_vec4<...>)`, otherwise uses its ordinary conversion (`convert.cu:482–494`). The cited norm implementation uses scalar F32 indexing (`norm.cu:15–46`). These examples show operation-specific qualification and fallback; they neither identify Hyle's selected failed reader nor justify lowering every GGML reader's contract. The TensorRT 32B conditional-clone reference is not evidence for a 256B need.

Other Hyle routes likewise have distinct contracts: native gated/norm proposal uses typed alignment or 16B for its SGLang route (`cuda_provider.cc:227–238`, `norm_provider.cc:171–186`); artifact providers use descriptor alignment (`artifact_provider.cc:173–182`), and mapped Graph patterns forward the native proposal (`mapped_pattern_region.h:101–124`). CPU GGML boundaries use tensor descriptor alignment (`graph_route_cpu/ggml_region.cc:267–287`, `ggml_cpu_provider.cc:1775–1785`). Do not project one provider's 256B constant onto all CUDA/native/GGML readers.

## Consequence for this repair and next evidence

Graph's legal by-value materialization is independently useful for genuinely stricter consumers and must respect the published requirements until they are deliberately requalified. The present repair should not lower a provider requirement from allocation alignment or from unrelated kernels. Whether this particular 256B declaration is unnecessarily conservative remains open.

After the original H64 compile succeeds, inspect a bounded ordinary correctness trace/report for region first55/count6: actual provider+instance+implementation+route, graph operations and port mapping/dtype/shape/strides, inserted copy count/bytes, and final plan route. That can select the precise wrapper/native kernel to inspect. If an existing successful correctness trace includes hidden/logits readback, label it as such; do not treat it as a performance run. No extra SDK log rebuild is required for this review.

`sources.json` retains actual file byte sizes/SHA-256 and bounded source excerpts, plus observed HEADs and the compiled-vendor limitation. It contains no raw tensors or binaries.
