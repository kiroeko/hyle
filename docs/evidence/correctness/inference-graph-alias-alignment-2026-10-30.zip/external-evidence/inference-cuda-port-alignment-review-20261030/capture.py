import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
LOCKED = Path(r'C:\Users\kiro\AppData\Local\hyle\dependencies\v1\sources\ggml-456172ec733a-41b7e10fd424')
PEER = ROOT.parent / 'llama.cpp'

specs = [
    (ROOT, 'src/compute_provider_ggml_cuda/program.h', [(21, 40)]),
    (ROOT, 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc', [(1528, 1580)]),
    (ROOT, 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc', [(471, 484), (776, 795), (1098, 1125), (1280, 1293), (1826, 1848), (1961, 1966)]),
    (ROOT, 'src/compute_provider_ggml_cuda/native_bridge_impl.h', [(331, 347)]),
    (ROOT, 'src/compute_backend_cuda/cuda_internal.h', [(27, 27)]),
    (ROOT, 'src/compute_backend_cuda/cuda_memory.cc', [(26, 52), (567, 611)]),
    (ROOT, 'src/compute_provider_cuda/cuda_provider.cc', [(227, 238)]),
    (ROOT, 'src/compute_provider_cuda/norm_provider.cc', [(171, 186)]),
    (ROOT, 'src/compute_provider_cuda/artifact_provider.cc', [(173, 182)]),
    (ROOT, 'src/graph/mapped_pattern_region.h', [(29, 43), (101, 124)]),
    (ROOT, 'src/graph_route_cpu/ggml_region.cc', [(267, 287)]),
    (ROOT, 'src/compute_provider_ggml/ggml_cpu_provider.cc', [(469, 478), (1775, 1785)]),
    (ROOT, 'cmake/HyleDependencyLock.json', [(469, 486)]),
    (ROOT, 'src/compute_ggml_runtime/CMakeLists.txt', [(24, 54), (188, 207)]),
    (ROOT, '.scratch/validation/cuda-final-u3-delivery/reference-windows/identity.json', [(1, 7)]),
    (ROOT, '.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/common.cuh', [(383, 390)]),
    (LOCKED, 'src/ggml-cuda/ggml-cuda.cu', [(755, 774), (902, 907)]),
    (LOCKED, 'src/ggml-backend.cpp', [(2119, 2144)]),
    (LOCKED, 'src/ggml-cuda/norm.cu', [(1, 37)]),
    (LOCKED, 'src/ggml-cuda/convert.cu', [(452, 455)]),
    (PEER, 'ggml/src/ggml-cuda/ggml-cuda.cu', [(750, 774), (898, 903)]),
    (PEER, 'ggml/src/ggml-cuda/common.cuh', [(381, 389)]),
    (PEER, 'ggml/src/ggml-cuda/convert.cu', [(482, 494)]),
    (PEER, 'ggml/src/ggml-cuda/norm.cu', [(15, 46)]),
]

def head(path):
    return subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()

items = []
for base, rel, ranges in specs:
    path = base / rel
    raw = path.read_bytes()
    lines = raw.decode('utf-8-sig').splitlines()
    items.append({'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                  'scopes': [{'first': first, 'last': last, 'text': '\n'.join(lines[first-1:last])}
                             for first, last in ranges]})

data = {'status': 'READ_ONLY_SOURCE_REVIEW', 'hyle_head': head(ROOT), 'llama_head': head(PEER),
        'native_runs': 0, 'builds': 0, 'product_edits': 0, 'downloads': 0,
        'selected_failed_region_provider': 'UNRECORDED',
        'locked_ggml_revision': '456172ec733a135778adcd32d00e576a58232e45',
        'locked_cache_is_unpatched_source_not_a_new_claim_about_compiled_vendor_bytes': True,
        'files': items}
(OUT / 'sources.json').write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'status': data['status'], 'files': len(items), 'llama_head': data['llama_head'],
                  'sources_json_bytes': (OUT / 'sources.json').stat().st_size}))
