"""Seal frozen core+test scratch candidates; no product apply/build/native."""
from pathlib import Path
import difflib,hashlib,json,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]

def pin(path):
 p=Path(path);data=p.read_bytes()
 return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

files=['src/graph/executable.cc','tests/graph/region_provider_test.cc']
assert (W/'tests-source-pin.json').is_file(), 'Wait for independently frozen tests-source-pin.json'
test_pin=json.loads((W/'tests-source-pin.json').read_text(encoding='utf-8-sig'))
assert test_pin['relative']==files[1]
for name in ('base','candidate'):
 actual=pin(test_pin[name]['path'])
 assert actual==test_pin[name],(name,test_pin[name])
core=json.loads((W/'core-pins.json').read_text());static=json.loads((W/'core-static-report.json').read_text())
assert static['status']=='PASS_CORE_STATIC_STRUCTURE_NOT_CXX_VALIDATION'
assert static['candidate_source_sha256']==pin(W/'candidate'/files[0])['sha256']
assert core['diagnostic_base_sha256']==pin(R/files[0])['sha256']
for entry in core['preconditions']:
 actual=pin(entry['path']);assert actual['bytes']==entry['bytes'] and actual['sha256']==entry['sha256'],entry['path']
patch=''
preconditions=[];candidates=[]
for relative in files:
 base=W/'base'/relative;candidate=W/'candidate'/relative
 assert base.is_file() and candidate.is_file(),relative
 assert pin(base)['sha256']==pin(R/relative)['sha256'],relative
 old=base.read_bytes().decode();new=candidate.read_bytes().decode()
 assert old!=new,relative
 patch+='diff --git a/'+relative+' b/'+relative+'\n'
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 preconditions.append(dict(relative=relative,**pin(R/relative)))
 candidates.append(dict(relative=relative,**pin(candidate)))
path=W/'alias-repair.patch';path.write_text(patch,encoding='utf-8',newline='\n')
check=subprocess.run(['git','apply','--check',str(path)],cwd=R,capture_output=True,text=True)
assert check.returncode==0,check.stderr
headers=[dict(relative=Path(entry['path']).resolve().relative_to(R).as_posix(),**entry)
 for entry in core['preconditions'] if Path(entry['path']).resolve()!= (R/files[0]).resolve()]
preconditions.extend(headers)
plan=dict(status='SCRATCH_REPAIR_CANDIDATE_UNAPPLIED_UNBUILT',
 base_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 baseline_note='Graph base is diagnostic working-tree source SHA8ac9..., not the original Graph blob at base HEAD; exact file preconditions are authoritative.',
 preconditions=preconditions,candidate=candidates,patch=pin(path),
 core_static_report=pin(W/'core-static-report.json'),tests_source_pin=pin(W/'tests-source-pin.json'),
 independent_core_review=pin(W/'independent-core-review.json'),
 independent_tests_source_review=pin(W/'tests-static-review.json'),
 tests_notes=pin(W/'tests-review-notes.md'),
 git_apply_check=dict(returncode=check.returncode,stdout=check.stdout,stderr=check.stderr),
 limits=['No product application, CXX/link/native/ABI validation or performance claim.',
 'Actual diagnostic remains a refused process; candidate/tests have not run.',
 'Existing provider/physical first-feasible search is retained; no final-copy global optimality claim.'])
(W/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=plan['status'],files=len(candidates),patch_bytes=plan['patch']['bytes'],patch_sha256=plan['patch']['sha256'])))
