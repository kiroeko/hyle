# Graph-owned alias 对齐修复候选

**仅 scratch；未应用、未构建、未运行。** 基于 `ec4b30b4d` 上已应用的诊断 Graph 源 `8ac9a094320db5022ad1b7bd75cc48d73a41d875ffffc2516e4c9c9913c77c21`。真实病例是 internal Caller TensorView 的 root+128B 不能满足256B reader，详见原 diagnostic-result；没有硬编码该尺寸或模型。

`prepare-core.py` 生成 core 候选，GLM 独立准备 `candidate/tests/graph/region_provider_test.cc`。两份候选现已冻结：完整补丁 `alias-repair.patch`、前置/候选 pin 在 `plan.json`；GLM 的 `independent-core-review.json` 与本 agent 的 `tests-static-review.json` 分别独立读另一份候选。任何当前静态检查都不代表 CXX/ABI/native 通过，禁止以成功文案替代实际验证。

诊断 shape 现已与 Recipe 源核对：`graph_builder.cc` 中新建 GraphBuilder 后第一个 independent dimension 就是 last_row，token_rows=L+1；因此该实际 binding dim0=0 对应 T1。该判断来自维度身份，不来自 variant index 的序号猜测。

## 最终实现范围

- `try_append_copy -> Result<bool>`：只有 direct/host-visible bridge 全部明确无合法能力时返回 false；查询、搜索、metadata 分配等错误仍返回其真实 Status。旧 `append_copy -> Status` adapter 将 mandatory locality 的 false 适配为原 plan rejection。
- region/leaf 共同调用 `ensure_input_instance`。原 local instance 的 alignment 已合法就直接使用；仅原 helper 已证明的 exact Graph-owned caller alias、needs_tensor=true、实体 Caller/TensorView、无 external/constant/generated instance role 时，追加同 storage 原 Graph Copy 到独立对齐实例。无能力时只按当前 reader 原规则拒绝，不置额外 plan flag。
- 返回内部 `{instance, accepted}`，保留能力拒绝时准确的原 physical instance 用于诊断；避免为了简化 optional 返回而在错误中写成 unused destination 或非本域 producer。所有原 producer/external/binding roles、reference 快路和身份验证不改。
- value×storage 缓存具体副本；副本无 alias offset，后续更强 alignment 合并到同一实例，不再复制。原 `V*S+V` 上界、overflow 检查及12个 parallel-array 初始化体保持；一份 producer 加每 domain 至多一份 concrete，staging 也走原矩阵缓存，不倍增全图 metadata 预算。
- 原 Copy step、scheduler、alias liveness、LifetimePlanner、budget reservation/capture/Invocation 寿命不改。增加 Copy 的 source/destination 在同一 copy interval 有重叠寿命，不能相互覆写；未来 native/Source 权限仍由原校验负责。

## Copy 错误归属

现 Copy source/resource query 只把**无 native error** 的预期能力拒绝当作不可访问；native-bearing 查询错误直传。late native copy 仍用原 rejected_plan → physical.next → routes.next，不增加 copy-owner/prefix 表，不启动第二阶段搜索。该选择按 root 对最小真实病例范围的指令，取代只读设计里提出的额外晚期 provenance 小表；若实际实验发现 suffix 预算问题，再按证据处理。

另修复源码可确认的错误分类漏洞：native prepare_copy 若返回 Unimplemented 并夹一个没有合法 destroy 的 artifact，旧代码先置 rejected_plan，随后返回 Internal，可能使真正 Internal 被外层当候选拒绝继续搜索。候选先验证 ownership，再在两个合法 error-return 点分类纯 capability decline；native-bearing 错误不置该 flag。没有泛清 outcome，也没有吞真实 budget/native/Internal。

同域 shared Compute 的 can-copy 能力不能用运行时 transfer_supported=false 伪造成 cold 无能力；测试将用现 RegionProbe 的真实 Equation/runner，加窄 native Source capability adapter表达 false/Error/晚期拒绝边界，避免改变实现镜像测试。

## 成本和兼容边界

修复不无条件物化 View。现 first-feasible/provider 偏好政策未变，最终物理 Copy 成本不构成新的全局优化目标：preferred strict + Copy 可取代低 alignment 零 Copy 路线；Copy 不可用仍须回原 alternate。required-provider 不能被别的 provider 代签。aligned 默认路径不应新增 Copy，默认2B的非时间事实需在实际验证中核对；H64 原拒绝路径允许必要 Copy。记录每个 exact child 的路线、copy步/bytes、workspace/limits、replica/constant与拒绝/搜索计数，不拿逻辑节点数冒充 dispatch。

正负覆盖由 `tests-review-notes.md` 列最终实际新增内容；保留真正错误、晚期 Copy 和 Source 原负例。当前没有实际修复成功、性能收益、CMake 全构建或整体架构完成结论。

## 静态审查中修正的草稿问题

root 发现 `try_append_copy` 从 Status 改 Result<bool> 后有一处旧裸 `return plan_allocation_failure()`；当前生成器已改为 `std::unexpected(...)`，并在静态脚本对新 Result helper 禁止该类裸 Status 返回。未用编译失败冒充通过。原接纳、Copy选择、平行数组及调度/寿命块的逐段核对在 `core-static-report.json`，其状态明确为结构检查，不是 CXX 证明。
