# Scratch Graph alias alignment tests

状态：未应用产品、未编译、未 native/GPU。完整候选及 base/candidate SHA 在
`tests-source-pin.json`。原文件是 CRLF，候选保持；仅替换原 slice helper/test 局部块和
增加明确的内部 ExecutionSource 声明头，后续原测试全部字节不变。

新增／升级七项测试（原一项替换，新增六项）：

1. 同 storage 的真实 materialized root + 68B slice，region 和 leaf 都由原 strict provider
   通过一份 68B Copy 执行；64 个 F32 的 256B offset 则零 Copy。hard required provider
   仍选 strict；两个不同输入重放结果精确且原 caller input 字节不改。
2. 同一个 View 的两个 strict readers 共享同一 replica；另建相同 offset、独立 ValueId 的
   View，从原 root 经显式低对齐 provider 读取。它不可能命中第一个 View 的 replica 缓存。
   检查原 alias/root、复制源/目的和两个 strict physical inputs；两轮实际数学和原输入字节。
3. 使用两个普通 Caller UnaryNeg provider，硬锁 root 和 reader；实际 root340B 与
   replica68B 在 Copy 步重叠，407B cap 必须拒绝。控制/恢复用同域、同硬约束，断言
   Caller/TensorView、无alias/inplace、独立placement、Copy68B和domain peak≥408；恢复后
   两次Neg得到原输入slice。保留失败时有界 XML 诊断。
4. Copy 合法后，region/leaf 的真实 typed provider error（Unimplemented、ResourceExhausted）
   都保持失败，不去 compatible provider；清错误后同资源恢复。
5. 额外 shared Context 仅作为 Copy target：其自身 default 是另一合法 HostResource，所有
   logical nodes hard 放原 target，避免在 environment/operation qualification 阶段先失败。
   该 target 对实际 system source/destination 的普通 Unimplemented 是能力不适配；带
   machine-readable NativeError 的同 code 则必须原错传播。清错误后恢复。
6. 窄 native endpoint 对真实 `can_copy` 返回 false，低对齐 alternate 成功且零 Copy；
   hard target 不允许换 alternate，保持拒绝、零额外提交。
7. native `can_copy` 的 unexpected Unimplemented、prepare_copy 的纯能力 decline、
   NativeError-bearing Unimplemented、Unimplemented+unowned prepared state、真实
   ResourceExhausted 分别验证原错误或合法 physical/route fallback。每个 fatal case 后
   恢复 capability 并重放，防止旧失败污染下一次编译。

shared Compute 对已接纳的同一 resource 没有独立 cold `can_copy=false` 开关，原
`transfer_supported=false` 是后续 replay transfer 的开关，不能拿它伪造 cold capability。
因此窄 native endpoint 使用真正的 ExecutionSourceVTable bool/query/prepare 协议；它
只适配现 RegionProbe 的 delegated unary artifact/runner，没有实现成功 Copy 执行器、
没有复制产品 admission helper 或创造模型执行器。native fixture 的 root 是普通 UnaryNeg，
最终 Neg(slice) 恢复原值；与原 BinaryAdd root 的 `-2*x` 有明确区分。

复用且保持字节不变的检查包括：跨 storage copied slice；mandatory final output Copy；
搜索累计预算；真实 region/leaf errors；失败 route 的高 alignment 不污染后继；declared
domain enqueue 前 actual offset；Projected input/page/source 权限；DeferredPorts 原 source
绑定；OwnedNativeInputs 生命周期；QueuedMaterialization raw source；late transfer replay。
这些既有检查仍需实际执行，不能因其源码未变就写成这批已通过。

当前新增多 reader 试验观察原 root alias，而不是声称额外覆盖了需要 opaque reference 的
fastpath。该路径核心保持原 producer 早返回，既有 deferred/native/source 身份测试予以保留。
候选尚无实际编译，native endpoint/32-state 搜索及精确计数也待真实有限运行验证。

首次测试 TU 编译真实 exit2：两处同一行 SCOPED_TRACE 宏生成重复 __LINE__ 符号。
现仅拆开这两行并保持 CRLF/全部去空白 token，不改变测试数学或断言；旧 c340 完整源及失败命令/log/process
保留在 superseded-c340 与 harness compile/region/attempt1，修正版尚未重编。详见 trace-layout-correction.json。

预算首版错误地把first-feasible peak−1当全部路线下界，首组实际6pass1fail；随后c1诊断
单case仍exit1，明确cap407合法选择ggml-cpu340B/零Copy（原408B/Copy68B）。旧完整源、
两份实际报告与失败XML/logs保留superseded-45d、superseded-c1及harness原attempt目录。
强Caller修正版仅改该预算test，尚未编译/运行，不把此前失败改记通过。
