"""Static candidate invariants only, never a substitute for CXX/native checks."""
from pathlib import Path
import hashlib,json,re
W=Path(__file__).resolve().parent;R=W.parents[1];REL='src/graph/executable.cc'
base=(W/'base'/REL).read_text();candidate=(W/'candidate'/REL).read_text()

def segment(text,start,end):
 a=text.index(start);return text[a:text.index(end,a)]

unchanged=[]
for start,end in [
 ('Result<bool> accepts_input_alias_alignment','// Cold rejection context only.'),
 ('// Cold rejection context only.','Status prepare_constant_alignments'),
 ('  auto add_instance =','  auto append_copy_step ='),
 ('  auto append_copy_step =','  auto copy_source ='),
 ('  auto copy_source =','  auto supports_copy ='),
 ('  auto copy_targets =','  auto select_copy_target ='),
 ('  auto select_copy_target =','  auto append_copy ='),
 ('  auto ensure_local_instance =','  auto needs_tensor ='),
 ('Status schedule_steps(','ReplayRoute shared_replay_coverage'),
 ('void reset_workspace_decisions(','Status plan_workspace('),
 ('Status plan_workspace(','Status finalize_placed_steps('),
]:
 old=segment(base,start,end)
 # try_append_copy is inserted after select_copy_target; its own segment is
 # checked using the original next marker in the base and new next marker.
 if start=='  auto select_copy_target =':
  new=segment(candidate,start,'  auto try_append_copy =')
 else:
  new=segment(candidate,start,end)
 assert old==new,start
 unchanged.append(start.strip())

needs=segment(base,'  auto needs_tensor =','  for (std::uint32_t value : graph.inputs) {\n    auto instance = add_instance')
assert needs in candidate
helper=segment(candidate,'  struct InputInstanceAdmission final {','  for (std::uint32_t value : graph.inputs) {\n    auto instance = add_instance')
assert helper.count('try_append_copy(instance, created)')==1
assert helper.index('if (aligned)')<helper.index('add_instance(value, storage, 0)')
for text in ['!tensor_required','contract.kind != RegionOutputKind::kCaller',
 'contract.projection != RegionOutputProjection::kTensorView','detail::kExternalInput | detail::kExternalOutput |',
 'detail::kConstant | detail::kGeneratedOutput','InputInstanceAdmission{instance, false}',
 'InputInstanceAdmission{created, true}']:
 assert text in helper,text
assert 'outcome.' not in helper and 'producer_instances[' not in helper
assert 'external_instances[' not in helper and 'binding_roles[' not in helper

copy=segment(candidate,'  auto try_append_copy =','  auto append_copy =')
assert '-> Result<bool>' in copy
assert copy.count('return false;')==1 and copy.count('return true;')==2
assert 'if (resource_choices.empty())\n      return false;' in copy
assert 'outcome.rejected_' not in copy and '.IsUnimplemented()' not in copy
assert not re.search(r'\breturn\s+(?:Status::\w+\(|plan_allocation_failure\()',copy)
assert not re.search(r'\breturn\s+(?:Status::\w+\(|plan_allocation_failure\()',helper)
assert copy.count('HYLE_RETURN_IF_ERROR(copy_targets(')==3
required=segment(candidate,'  auto append_copy =','  auto ensure_local_instance =')
assert required.count('outcome.rejected_plan = true;')==1
assert 'if (!copied)' in required

for text in ['const std::size_t matrix_instances = value_count * storage_count;',
 'const std::size_t maximum_instances = matrix_instances + value_count;',
 'value_count > SIZE_MAX - matrix_instances','node_count > SIZE_MAX - maximum_instances']:
 assert text in base and text in candidate,text
parallel=re.findall(r'!plan\.(\w+)\.try_push_back',segment(base,'  auto add_instance =','  auto append_copy_step ='))
assert len(parallel)==12,parallel
assert candidate.count('auto admitted = ensure_input_instance(')==2
assert candidate.count('if (!admitted->accepted)')==2
assert candidate.count('const auto instance = admitted->instance;')==2
assert 'index, logical_inputs[index].ordinal(),\n              admitted->instance' in candidate
assert 'admitted->instance, target, alignment, false, true' in candidate

late=segment(candidate,'      // Validate artifact ownership before classifying','      const auto runtime = prepared.properties.runtime;')
assert late.index('return Status::Internal("native transfer returned an unowned artifact")')<late.index('outcome.rejected_plan')
assert late.count('status.IsUnimplemented() && !status.has_native_error()')==2
assert 'copy-owner' not in candidate and 'DeclineOwner' not in candidate
assert re.findall(r'^#include.*$',base,re.M)==re.findall(r'^#include.*$',candidate,re.M)

# Check delimiter balance outside literals/comments, catching accidental splice
# errors without invoking a compiler or pretending to verify C++ semantics.
stripped=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', '', candidate)
stack=[];pairs={')':'(',']':'[','}':'{'}
for token in stripped:
 if token in '([{':stack.append(token)
 elif token in ')]}':
  assert stack and stack.pop()==pairs[token],token
assert not stack

report=dict(status='PASS_CORE_STATIC_STRUCTURE_NOT_CXX_VALIDATION',
 base_source_sha256=hashlib.sha256((W/'base'/REL).read_bytes()).hexdigest(),
 candidate_source_sha256=hashlib.sha256((W/'candidate'/REL).read_bytes()).hexdigest(),
 unchanged_original_mechanisms=unchanged,
 unchanged_parallel_instance_initializers=parallel,
 instance_bound='value_count*storage_count+value_count retained. Original producer plus one concrete per storage; aligned root strengthens alignment without another instance; immutable View is excluded and generated concrete already has offset zero.',
 only_explicit_no_qualified_copy_returns_false=True,mandatory_copy_false_retains_old_plan_rejection=True,
 optional_alignment_false_uses_reader_rejection_without_extra_plan_flag=True,
 real_query_search_metadata_errors_propagated=True,
 native_bearing_copy_resource_and_prepare_errors_not_soft_declined=True,
 malformed_ownership_checked_before_pure_decline_flag=True,
 exact_rejected_instance_retained_in_diagnostics=True,
 producer_reference_external_effect_owner_mechanisms_unchanged=True,
 existing_lifetime_scheduling_workspace_and_native_copy_search_chain_unchanged=True,
 no_new_public_API_header_owner_switch_or_budget_limit=True,
 delimiters_balanced=True,
 limits=['No CXX/link/native validation.','Finite fixture tests being prepared independently; not executed.',
 'Conditional copy can change a previously feasible strict/low-alignment route preference and cost; no final-copy global optimizer claim.'])
(W/'core-static-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],parallel_arrays=len(parallel),unchanged_mechanisms=len(unchanged))))
