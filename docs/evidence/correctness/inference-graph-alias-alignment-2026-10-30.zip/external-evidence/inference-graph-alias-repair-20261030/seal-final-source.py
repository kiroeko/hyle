"""Seal current two-file source delta; write only this scratch directory."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[1]
H = R / '.scratch/inference-graph-alias-repair-harness-20261030'
BASE = 'ec4b30b4dd58e09594822882e4689d78835dc4d7'
FILES = ['src/graph/executable.cc', 'tests/graph/region_provider_test.cc']
EXPECTED = ['9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc',
            '6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00']

def pin(path):
    p = Path(path)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def preserve(source, destination):
    source, destination = Path(source), Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    raw = source.read_bytes()
    if destination.exists():
        assert destination.read_bytes() == raw, destination
    else:
        destination.write_bytes(raw)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == BASE
for rel, sha in zip(FILES, EXPECTED):
    assert pin(R / rel)['sha256'] == sha
    assert (R / rel).read_bytes() == (W / 'candidate' / rel).read_bytes()

# Preserve all original stage reports as historical, rather than relabeling them.
assert pin(W / 'alias-repair.patch')['sha256'] == 'e19412832dac0f8ac6ac25ef3733846de318d299f53b33b777ab923292b46813'
for name in ('alias-repair.patch', 'plan.json', 'tests-static-review.json', 'check-tests.py', 'finalize.py'):
    preserve(W / name, W / 'superseded-c340' / name)

history = []
for directory, sha in (
    ('superseded-c340', 'c3401339d846fc82a8a781ceedefb4484f2df89511be6507e2ded7876b51c52b'),
    ('superseded-45d', '45d423f80e5ad6efc27a9cd88960145725a23f6ff9c2bda557b0c5ff52406bbc'),
    ('superseded-c1', 'c1f96e64c242fba33a303edb5b7d99d83c8d7a09903adaf06c39012e12fe80e1')):
    p = W / directory / FILES[1]
    assert pin(p)['sha256'] == sha
    history.append(dict(stage=directory, source=pin(p)))
assert re.sub(rb'\s+', b'', (W / 'superseded-c340' / FILES[1]).read_bytes()) == re.sub(rb'\s+', b'', (W / 'superseded-45d' / FILES[1]).read_bytes())

base_pins, current_pins = [], []
for rel in FILES:
    old = subprocess.check_output(['git', 'show', BASE + ':' + rel], cwd=R)
    dst = W / 'final-source-base' / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists(): assert dst.read_bytes() == old
    else: dst.write_bytes(old)
    base_pins.append(dict(relative=rel, **pin(dst)))
    current_pins.append(dict(relative=rel, **pin(R / rel), candidate=pin(W / 'candidate' / rel)))

patch = subprocess.check_output(['git', 'diff', '--no-color', '--no-ext-diff', '--no-textconv', '--binary', '--full-index', BASE, '--', *FILES], cwd=R)
assert patch.count(b'diff --git ') == 2
patch_path = W / 'final-source.patch'
patch_path.write_bytes(patch)
checks = []
for mode, args in (
    ('forward_base_mirror_check', ['--check', '--directory=' + (W / 'final-source-base').relative_to(R).as_posix()]),
    ('reverse_current_product_check', ['--reverse', '--check'])):
    result = subprocess.run(['git', 'apply', *args, str(patch_path)], cwd=R, capture_output=True, text=True)
    assert result.returncode == 0, (mode, result.stderr)
    checks.append(dict(mode=mode, exit=result.returncode, stderr=result.stderr))

# Apply only to an isolated two-file scratch mirror, then verify exact bytes.
mirror = W / 'final-patch-verification'
for rel in FILES:
    dst = mirror / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes((W / 'final-source-base' / rel).read_bytes())
result = subprocess.run(['git', 'apply', '--whitespace=nowarn', '--directory=' + mirror.relative_to(R).as_posix(), str(patch_path)], cwd=R, capture_output=True, text=True)
assert result.returncode == 0, result.stderr
assert all((mirror / rel).read_bytes() == (R / rel).read_bytes() for rel in FILES)
checks.append(dict(mode='scratch_forward_apply_exact_final_bytes', exit=0, exact_files=2))

# Independently restore the original test island; unrelated old tests remain exact.
old_test = (W / 'final-source-base' / FILES[1]).read_bytes()
new_test = (R / FILES[1]).read_bytes()
start = b'struct SliceAlignmentGraph final {'
end = b'TEST(GraphRegions, CopiedSliceGetsItsOwnAlignedInputBeforeCandidateQualification)'
oa, ob = old_test.index(start), old_test.index(end)
na, nb = new_test.index(start), new_test.index(end)
include = b'#include "../../src/graph/execution_source_internal.h"\r\n'
assert new_test[:na].replace(include, b'', 1) + old_test[oa:ob] + new_test[nb:] == old_test
assert new_test.count(b'\r\n') == new_test.count(b'\n')
names = re.findall(rb'TEST\(GraphRegions, (\w+)\)', new_test[na:nb])
assert len(names) == 7

report = read(W / 'superseded-c340/tests-static-review.json')
report.update(status='PASS_FINAL_INDEPENDENT_STATIC_SOURCE_REVIEW_RUNTIME_EVIDENCE_SEPARATE',
              source_sha256=EXPECTED[1], source_bytes=len(new_test),
              original_c340_review=pin(W / 'superseded-c340/tests-static-review.json'),
              trace_macro_layout_only_equal_nonwhitespace=True,
              final_strong_budget_review=pin(R / '.scratch/inference-graph-alias-budget-audit-20261030/strong-caller-independent-review.json'),
              budget_scope='Final test fixes two Caller leaf producers by hard provider-instance constraints, checks original340B plus replica68B overlap-derived lower bound, rejects cap407, and recovers exact double-Neg replay. The historical unlocked graph legitimately found a different340B/noCopy route at407; no budget leak was observed.',
              limits=['This report is static source review. CXX/native results are separately pinned harness records.',
                      'No universal provider/kernel coverage, performance improvement or global copy-cost optimum claim.'])
save(W / 'tests-static-review-final.json', report)

supporting = []
for entry in read(W / 'core-pins.json')['preconditions'][1:]:
    actual = pin(entry['path'])
    assert actual == entry
    supporting.append(actual)

pins = dict(status='FROZEN_FINAL_SOURCE_TWO_FILES_EXACT', base_head=BASE,
            scope='Full source delta relative to ec4: cold rejection diagnostics plus alias repair plus final tests. Root-owned documentation excluded.',
            base_sources=base_pins, current_sources=current_pins, unchanged_supporting_headers=supporting,
            diagnostic_source=pin(W / 'base' / FILES[0]),
            patch=pin(patch_path), checks=checks, historical_test_sources=history,
            core_static_report=pin(W / 'core-static-report.json'),
            independent_core_review=pin(W / 'independent-core-review.json'),
            final_tests_static_report=pin(W / 'tests-static-review-final.json'),
            superseded_stage_files_preserved=True, product_source_edits_by_sealer=0)
save(W / 'final-source-pins.json', pins)

first = read(read(H / 'ready-first-test-gate.json')['path'])
related = read(read(H / 'ready-related-test-gate.json')['path'])
assert first['actual_case_count'] == 7 and related['actual_case_count'] == 18
assert first['failures'] == related['failures'] == first['skipped'] == related['skipped'] == 0
diagnostic = read(H / 'budget-diagnostic-result.json')
assert diagnostic['original_workspace'] == 408 and diagnostic['requested_cap'] == 407
assert diagnostic['plans']['original']['copy'] == 68 and diagnostic['plans']['limited']['workspace'] == 340 and diagnostic['plans']['limited']['copy'] == 0
assert diagnostic['plans']['limited']['plan_rejections'] == 1
summary = dict(status='FINAL_SOURCE_RESEALED_FOR_COLLECTOR', base_head=BASE,
               current_source_sha256=dict(zip(FILES, EXPECTED)), patch=pin(patch_path),
               source_pins=pin(W / 'final-source-pins.json'), final_static_report=pin(W / 'tests-static-review-final.json'),
               inherited_harness_evidence={
                   'new_cases': dict(executed=7, failures=0, skipped=0, native_processes=1,
                                     report=pin(read(H / 'ready-first-test-gate.json')['path'])),
                   'related_cases': dict(executed=18, failures=0, skipped=0, native_processes=1,
                                         report=pin(read(H / 'ready-related-test-gate.json')['path'])),
                   'original_H64': pin(H / 'tiny-repair-result.json'),
                   'default_four_cli_pairs': pin(H / 'whole-cli-summary.json'),
                   'real_CPU2_pair': pin(H / 'compare-cpu-ffn-real-cuda.json'),
                   'session_complete_byte_comparison': pin(H / 'session-compare.json')},
               distinct_budget_facts={
                   'historical_unlocked_case': dict(status='EXPECTED_TEST_FAILURE_VALID_FALLBACK_NOT_BUDGET_LEAK',
                       original_workspace=408, original_copy_bytes=68, cap=407,
                       final_workspace=340, final_copy_bytes=0, route_plan_rejections=1,
                       final_reader='ggml-cpu IID2 instead of preferred test-region IID1',
                       diagnostic_test_exit=1, report=pin(H / 'budget-diagnostic-result.json')),
                   'final_strong_Caller_case': dict(status='PASS_IN_FINAL_SEVEN_CASE_PROCESS',
                       graph='Neg85 -> View(offset17,count17) -> Neg17',
                       hard_providers='root IID0 and strict reader IID1',
                       lower_bound_bytes=408, refused_domain_cap=407,
                       checks='Caller identity, original alias,68B replica fee, disjoint placements, ResourceExhausted, no enqueue, recovery and exact two replays')},
               alignment_requirement_review=pin(R / '.scratch/inference-cuda-port-alignment-review-20261030/README.md'),
               selected_failed_provider='UNKNOWN_NOT_ADDITIONALLY_TRACED',
               limits=['No new build/native/GPU/download was run by this sealer.',
                       'Historical c340 compile failure and45d/c1 test failures remain historical failures.',
                       'Final process/build totals and current model-link-base are owned by harness final verification-summary, not old basic-summary.',
                       'Finite correctness comparisons do not establish performance speedup or full architecture completion.',
                       'Provider256 wrapper requirement is preserved; exact selected kernel necessity remains unproven.'])
save(W / 'final-review-summary.json', summary)
print(json.dumps(dict(status=summary['status'], patch_bytes=pins['patch']['bytes'],
                      patch_sha256=pins['patch']['sha256'], changed_files=2,
                      exact_forward_files=2, final_test_sha256=EXPECTED[1])))
