"""Independent bounded source review of the added finite contract fixtures."""
from pathlib import Path
import hashlib,json,re
W=Path(__file__).resolve().parent
REL='tests/graph/region_provider_test.cc'
old=(W/'base'/REL).read_bytes();new=(W/'candidate'/REL).read_bytes()
start=b'struct SliceAlignmentGraph final {'
end=b'TEST(GraphRegions, CopiedSliceGetsItsOwnAlignedInputBeforeCandidateQualification)'
oa=old.index(start);ob=old.index(end,oa);na=new.index(start);nb=new.index(end,na)
include=b'#include "../../src/graph/execution_source_internal.h"\r\n'
assert new.count(include)==1
restored=new[:na].replace(include,b'',1)+old[oa:ob]+new[nb:]
assert restored==old,'An unrelated original test changed'
block=new[na:nb].decode().replace('\r\n','\n')
names=re.findall(r'TEST\(GraphRegions, (\w+)\)',block)
assert len(names)==7,names
for text in [
 'for (const bool leaf : {false, true})', 'for (const std::int64_t offset : {17, 64})',
 'offset == 17 ? 17 * sizeof(float) : 0u', 'options.node_providers = required;',
 'const auto original_selected = builder.add', 'Unary{UnaryKind::kNeg}, original_selected',
 'graph.node_id(5).value()', 'EXPECT_NE(original_alias, *replica);',
 'plan->alias_sources[original_alias], plan->alias_sources[*alias]',
 'EXPECT_EQ(plan->alias_sources[*replica], hyle::graph::detail::kNoInPlaceSource)',
 '.workspace_budget_bytes = bytes - 1',
 'ProviderPrepareOutcome::error(error)', 'second.query_error = Status::Unimplemented',
 'second.prepare_error = Status::FromNative', 'second.malformed = true',
 'EXPECT_TRUE(result.error().IsInternal())',
 'query_error.ok()) return std::unexpected(endpoint.query_error)',
 'return endpoint.can_copy;', 'return endpoint.prepare_error;',
 'copy_probe.validation_failure = Status::FromNative',
 'EXPECT_EQ(failed.error(), copy_probe.validation_failure)',
]:
 assert text in block,text
assert block.count('for (std::size_t round = 0; round < 2; ++round)')==2
assert 'std::memcpy' not in block and '.delegated_submit =' not in block
assert 'use_delegated_runtime(*probe)' in block
assert 'supplies no successful Copy executor' not in block or 'artifact/runner' in block
assert new.count(b'\r\n')==new.count(b'\n')
report=dict(status='PASS_INDEPENDENT_TEST_SOURCE_REVIEW_UNBUILT',
 source_sha256=hashlib.sha256(new).hexdigest(),new_or_replacement_tests=names,
 replaced_tests=1,added_tests=6,all_other_original_tests_byte_identical=True,
 CRLF_preserved=True,
 mathematical_checks='Actual Unary/Binary finite Graph values and two replays; ordinary positive route uses original shared Queue Copy. No implementation-mirror equations.',
 original_alias_check='Independent ValueId View from the original root with explicit compatible reader, not a read of the replica-cache logical value.',
 no_qualified_copy_test='Narrow native ExecutionSource capability endpoint has actual bool can_copy=false, not a runtime transfer flag. Reuses existing delegated unary artifact/runner; no successful Copy executor added.',
 errors='Explicit query error, actual provider kError, native-bearing prepare error, unowned malformed artifact and injected ResourceExhausted keep classification; pure late decline retains old search behavior.',
 budget_scope='Compile-domain workspace cap is enforced and retried; injected native metadata ResourceExhausted checks propagation, not physical allocation failure. Existing resource/Source negative fixtures are unchanged and must be run as appropriate.',
 limits=['No CXX/WX/link/native validation. Fixture call counts, search bound32 and numerical assertions remain unexecuted.',
 'New tests do not newly certify every reference/Source/effect path; they preserve original fixtures byte-for-byte.'])
(W/'tests-static-review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],tests=len(names),unrelated_original_tests_unchanged=True)))
