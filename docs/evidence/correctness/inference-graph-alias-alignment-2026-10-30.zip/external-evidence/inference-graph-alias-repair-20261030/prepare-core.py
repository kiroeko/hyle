"""Prepare core-only scratch repair from the exact diagnostic Graph source."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1];REL='src/graph/executable.cc'

def pin(path):
 p=Path(path);raw=p.read_bytes()
 return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

raw=(R/REL).read_bytes()
assert hashlib.sha256(raw).hexdigest()=='8ac9a094320db5022ad1b7bd75cc48d73a41d875ffffc2516e4c9c9913c77c21'
nl='\r\n' if b'\r\n' in raw else '\n'
old=raw.decode().replace('\r\n','\n');text=old

def replace(before,after):
 global text
 assert text.count(before)==1, (before[:150],text.count(before))
 text=text.replace(before,after,1)

replace('''  // One original generated carrier may coexist with its concrete caller
  // replica in the same storage domain. The matrix caches the latter.''',
'''  // One original generated carrier or caller View may coexist with its
  // concrete aligned caller replica in the same storage domain. Each value
  // keeps one producer plus at most one concrete replica per storage; raising
  // that replica's alignment does not create another instance. The matrix
  // caches the concrete replica, while producer_instances keeps the producer.''')

copy_begin=text.index('  auto append_copy = [&](std::uint32_t source,')
copy_end=text.index('  auto ensure_local_instance =',copy_begin)
copy_old=text[copy_begin:copy_end]
copy_new=copy_old.replace('  auto append_copy =','  auto try_append_copy =',1)
copy_new=copy_new.replace('std::uint32_t destination) noexcept -> Status {',
                           'std::uint32_t destination) noexcept -> Result<bool> {',1)
copy_new=copy_new.replace('''  auto try_append_copy = [&](std::uint32_t source,
                         std::uint32_t destination)''',
'''  auto try_append_copy = [&](std::uint32_t source,
                             std::uint32_t destination)''',1)
assert copy_new.count('return plan_allocation_failure();')==1
copy_new=copy_new.replace('return plan_allocation_failure();',
                           'return std::unexpected(plan_allocation_failure());',1)
assert copy_new!=copy_old
copy_new=copy_new.replace('''      return append_copy_step(source, destination, target);''',
'''      HYLE_RETURN_IF_ERROR(append_copy_step(source, destination, target));
      return true;''',1)
assert copy_new.count('''    if (resource_choices.empty()) {
      outcome.rejected_plan = true;
      return Status::Unimplemented("storage boundary has no configured transfer bridge");
    }''')==1
copy_new=copy_new.replace('''    if (resource_choices.empty()) {
      outcome.rejected_plan = true;
      return Status::Unimplemented("storage boundary has no configured transfer bridge");
    }''',
'''    // Explicit capability exhaustion, not an error-code classification.
    // The caller owns whether this copy is a required locality boundary or
    // only an optional aligned representation for one selected reader.
    if (resource_choices.empty())
      return false;''',1)
copy_new=copy_new.replace('''    return append_copy_step(staged, destination, to);
  };
''',
'''    HYLE_RETURN_IF_ERROR(append_copy_step(staged, destination, to));
    return true;
  };

  auto append_copy = [&](std::uint32_t source,
                         std::uint32_t destination) noexcept -> Status {
    HYLE_ASSIGN_OR_RETURN(const bool copied, try_append_copy(source, destination));
    if (!copied) {
      outcome.rejected_plan = true;
      return Status::Unimplemented("storage boundary has no configured transfer bridge");
    }
    return Status::Ok();
  };
''',1)
replace(copy_old,copy_new)

# Copy capability filtering must not reinterpret native-bearing errors from a
# source/resource query as ordinary inaccessibility.
replace('''    if (!retained) {
      if (retained.error().IsUnimplemented())
        return detail::ExecutionSourceAccess::can_copy(
            plan.targets[target].source, source,
            plan.storage_domains[destination].resource);
      return std::unexpected(std::move(retained).error());
    }''',
'''    if (!retained) {
      if (retained.error().IsUnimplemented() && !retained.error().has_native_error())
        return detail::ExecutionSourceAccess::can_copy(
            plan.targets[target].source, source,
            plan.storage_domains[destination].resource);
      return std::unexpected(std::move(retained).error());
    }''')
replace('''      if (status.IsFailedPrecondition() || status.IsUnimplemented())
        return false;
      return std::unexpected(std::move(status));
    }
    return true;
  };

  auto copy_targets''',
'''      if ((status.IsFailedPrecondition() || status.IsUnimplemented()) &&
          !status.has_native_error())
        return false;
      return std::unexpected(std::move(status));
    }
    return true;
  };

  auto copy_targets''')

helper='''  struct InputInstanceAdmission final {
    std::uint32_t instance;
    bool accepted;
  };

  // Only a proved Graph-owned caller alias may acquire an aligned by-value
  // representation. Reference readers, external bindings and native output
  // identities keep the original admission path. A missing copy capability
  // declines only this reader; genuine errors preserve their original Status.
  auto ensure_input_instance =
      [&](std::uint32_t value, std::uint32_t storage, bool tensor_required,
          std::size_t alignment) noexcept
          -> Result<InputInstanceAdmission> {
    HYLE_ASSIGN_OR_RETURN(const auto instance,
        ensure_local_instance(ensure_local_instance, value, storage, tensor_required));
    HYLE_ASSIGN_OR_RETURN(const bool aligned,
        accepts_input_alias_alignment(plan, instance, alignment));
    if (aligned)
      return InputInstanceAdmission{instance, true};
    const auto contract = plan.instance_output_contracts[instance];
    const auto roles = plan.instance_roles[instance];
    if (!tensor_required || contract.kind != RegionOutputKind::kCaller ||
        contract.projection != RegionOutputProjection::kTensorView ||
        (roles & (detail::kExternalInput | detail::kExternalOutput |
                  detail::kConstant | detail::kGeneratedOutput)) != 0)
      return InputInstanceAdmission{instance, false};
    // accepts_input_alias_alignment returned false only for a static offset
    // under an internal Caller root. Never change that View's offset or its
    // producer identity. add_instance initializes every parallel plan array,
    // and its zero-offset caller replica is reused for stronger later readers.
    HYLE_ASSIGN_OR_RETURN(const auto created, add_instance(value, storage, 0));
    HYLE_ASSIGN_OR_RETURN(const bool copied, try_append_copy(instance, created));
    if (!copied)
      return InputInstanceAdmission{instance, false};
    return InputInstanceAdmission{created, true};
  };

'''
anchor='''  for (std::uint32_t value : graph.inputs) {
    auto instance = add_instance(value, plan.external_storage[value],'''
assert text.count(anchor)==1
text=text.replace(anchor,helper+anchor,1)

old_region='''        auto instance = ensure_local_instance(ensure_local_instance, logical_inputs[index].ordinal(),
                                              selected_inputs[index],
                                              needs_tensor(logical_inputs[index].ordinal(), target,
                                                  input_references[index] != 0));
        if (!instance)
          return std::move(instance).error();
        HYLE_ASSIGN_OR_RETURN(const bool aligned,
            accepts_input_alias_alignment(plan, *instance,
                input_requirements[index].minimum_alignment));
        if (!aligned) {'''
new_region='''        auto admitted = ensure_input_instance(logical_inputs[index].ordinal(),
            selected_inputs[index],
            needs_tensor(logical_inputs[index].ordinal(), target, input_references[index] != 0),
            input_requirements[index].minimum_alignment);
        if (!admitted)
          return std::move(admitted).error();
        if (!admitted->accepted) {'''
replace(old_region,new_region)
# Return the exact rejected source instance as well as the admission bit, so
# optional Copy exhaustion never replaces it with an unused destination in
# the diagnostic. Neither branch submits or binds this rejected attempt.
replace('''              index, logical_inputs[index].ordinal(), *instance, target,
              input_requirements[index].minimum_alignment,''',
'''              index, logical_inputs[index].ordinal(),
              admitted->instance, target,
              input_requirements[index].minimum_alignment,''')
replace('''        plan.instance_alignments[*instance] =
            (std::max)(plan.instance_alignments[*instance],
                       input_requirements[index].minimum_alignment);
        if (!physical_inputs.try_push_back(*instance))''',
'''        const auto instance = admitted->instance;
        plan.instance_alignments[instance] =
            (std::max)(plan.instance_alignments[instance],
                       input_requirements[index].minimum_alignment);
        if (!physical_inputs.try_push_back(instance))''')

old_leaf='''      auto instance = ensure_local_instance(ensure_local_instance, value, input_storage, true);
      if (!instance)
        return std::move(instance).error();
      if (!port_requirements.empty()) {
        HYLE_ASSIGN_OR_RETURN(const bool aligned,
            accepts_input_alias_alignment(plan, *instance,
                port_requirements[input_index].minimum_alignment));
        if (!aligned) {'''
new_leaf='''      const auto alignment = port_requirements.empty()
          ? std::size_t{1} : port_requirements[input_index].minimum_alignment;
      auto admitted = ensure_input_instance(value, input_storage, true, alignment);
      if (!admitted)
        return std::move(admitted).error();
      if (!admitted->accepted) {'''
replace(old_leaf,new_leaf)
replace('''      if (!admitted->accepted) {
          discovery.physical.reject_suffix(preparation_prefix[node_index]);
          outcome.rejected_operation = static_cast<std::size_t>(
              placement->route - discovery.operations.candidates.data());''',
'''      if (!admitted->accepted) {
        discovery.physical.reject_suffix(preparation_prefix[node_index]);
        outcome.rejected_operation = static_cast<std::size_t>(
            placement->route - discovery.operations.candidates.data());''')
replace('''          return describe_input_alias_alignment_rejection(
              Status::Unimplemented(
                  "graph input alias offset cannot satisfy operation port alignment"),
              plan, options.shape, node_index, 1, input_index, value, *instance, target,
              port_requirements[input_index].minimum_alignment, false, true);
        }
      }
      if (!port_requirements.empty())
        plan.instance_alignments[*instance] =
            (std::max)(plan.instance_alignments[*instance],
                       port_requirements[input_index].minimum_alignment);
      if (!physical_inputs.try_push_back(*instance))''',
'''        return describe_input_alias_alignment_rejection(
            Status::Unimplemented(
                "graph input alias offset cannot satisfy operation port alignment"),
            plan, options.shape, node_index, 1, input_index, value,
            admitted->instance, target, alignment, false, true);
      }
      const auto instance = admitted->instance;
      if (!port_requirements.empty())
        plan.instance_alignments[instance] =
            (std::max)(plan.instance_alignments[instance], alignment);
      if (!physical_inputs.try_push_back(instance))''')

# An unsupported return cannot pre-mark a malformed unowned native artifact
# as a rejected plan: the required Internal must remain fatal. Native-bearing
# errors also never become a pure capability rejection.
replace('''      // Unsupported geometry is a cold route decline, including when no
      // artifact was created. Actual preparation errors remain fatal.
      if (!status.ok())
        outcome.rejected_plan = status.IsUnimplemented();
      const auto *table = prepared.vtable;
      if (table == nullptr || table->destroy_prepared == nullptr) {
        if (prepared.state != nullptr || status.ok())
          return Status::Internal("native transfer returned an unowned artifact");
        return status;
      }
      detail::PreparedRegion artifact(std::move(capability), prepared, plan.allocator);
      if (!status.ok()) {
        return status;
      }''',
'''      // Validate artifact ownership before classifying a pure capability
      // decline. A malformed artifact or native-bearing error is fatal and
      // must not leave rejected_plan set while returning Internal/error.
      const auto *table = prepared.vtable;
      if (table == nullptr || table->destroy_prepared == nullptr) {
        if (prepared.state != nullptr || status.ok())
          return Status::Internal("native transfer returned an unowned artifact");
        outcome.rejected_plan = status.IsUnimplemented() && !status.has_native_error();
        return status;
      }
      detail::PreparedRegion artifact(std::move(capability), prepared, plan.allocator);
      if (!status.ok()) {
        outcome.rejected_plan = status.IsUnimplemented() && !status.has_native_error();
        return status;
      }''')

base=W/'base'/REL;candidate=W/'candidate'/REL
base.parent.mkdir(parents=True,exist_ok=True);candidate.parent.mkdir(parents=True,exist_ok=True)
base.write_bytes(raw);candidate.write_bytes(text.replace('\n',nl).encode())
inputs=[REL,'src/graph/plan_state.h','src/graph/graph_state.h','src/graph/execution_source_internal.h',
 'include/hyle/graph/region_provider.h','include/hyle/graph/executable.h','include/hyle/error/status.h']
report=dict(status='CORE_SCRATCH_CANDIDATE_UNAPPLIED_UNBUILT',preconditions=[pin(R/p) for p in inputs],
 candidate=pin(candidate),diagnostic_base_sha256=hashlib.sha256(raw).hexdigest(),
 scope='Only internal input alignment materialization, explicit Copy capability outcome and fatal malformed/native Copy classification. Late valid capability decline keeps original rejected_plan/physical.next/routes.next chain.',
 limits=['Tests owned separately and not yet frozen.','No CXX/link/native/ABI validation.'])
(W/'core-pins.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],candidate_bytes=report['candidate']['bytes'],candidate_sha256=report['candidate']['sha256'])))
