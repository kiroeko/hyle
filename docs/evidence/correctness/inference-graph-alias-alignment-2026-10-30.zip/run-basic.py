"""Only root-authorized basic gates; exact executed names/counts from XML."""
from pathlib import Path
import importlib.util,json,re,sys,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('repair_basic_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
FILTERS=R/'.scratch/inference-graph-alias-repair-20261030/test-filters.json'
def tests(group,attempt):
 f=read(FILTERS);expected=f['first_new_cases'] if group=='first' else f['related_regressions'];count=7 if group=='first' else 18
 assert len(expected)==count
 if group=='related':
  gate=read(W/'ready-first-test-gate.json');exact(gate);assert read(gate['path'])['status']=='PASS_EXACT_EXECUTED_TEST_SET'
 image=read(W/'ready-region.json');exact(image)
 folder=W/'runs'/(group+'-tests')/attempt;save(folder/'image.json',image)
 args=[image['path'],'--gtest_filter='+f[group+'_filter'],'--gtest_output=xml:'+str(folder/'result.xml')]
 b.s.b.execute(args,folder,240)
 xml=ET.parse(folder/'result.xml').getroot();cases=list(xml.iter('testcase'))
 names=[case.attrib['classname']+'.'+case.attrib['name'] for case in cases]
 failures=list(xml.iter('failure'));skips=list(xml.iter('skipped'))
 passed=(int(xml.attrib['tests'])==count and len(cases)==count and set(names)==set(expected)
  and not failures and not skips and all(case.attrib.get('status')=='run' and case.attrib.get('result')=='completed' for case in cases))
 save(folder/'report.json',dict(status='PASS_EXACT_EXECUTED_TEST_SET' if passed else 'FAIL_EXECUTED_SET_OR_RESULT',
  expected_count=count,actual_XML_count=int(xml.attrib['tests']),actual_case_count=len(cases),executed_names=names,
  expected_names=expected,failures=len(failures),skipped=len(skips),filter_source=pin(FILTERS),xml=pin(folder/'result.xml'),
  scope='One native filtered test process. Actual run/completed XML names must equal the exact approved set; zero matches is never PASS.'))
 assert passed,(names,xml.attrib)
 save(W/('ready-'+group+'-test-gate.json'),pin(folder/'report.json'))
 print('PASS actual executed',count,'tests',group,flush=True)
def tiny(attempt):
 for name in ('first','related'):
  gate=read(W/('ready-'+name+'-test-gate.json'));exact(gate);assert read(gate['path'])['status']=='PASS_EXACT_EXECUTED_TEST_SET'
 image=read(W/'ready-tiny.json');exact(image)
 old=read(R/'.scratch/inference-graph-alias-harness-20261030/plan.json')['original_failed_command']
 folder=W/'runs/tiny-cpu-ffn'/attempt;save(folder/'image.json',image)
 b.s.b.execute([image['path'],*old[1:]],folder,600)
 report=read(folder/'stdout.log');assert report['generated_tokens']==4 and report['live_committed_versions']==0 and report['cpu_ffn_layers']==1
 stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig');hybrid=[line for line in stderr.splitlines() if line.startswith('hybrid_plan ')]
 facts=[{key:int(value) for key,value in re.findall(r'(host_constants|materialized_constant_bytes|activation_copy_bytes|known_workspace_device|known_workspace_host|known_workspace_staging)=(\d+)',line)} for line in hybrid]
 assert facts and all(row['host_constants']>0 for row in facts)
 assert len(report['workspace_domains'])==3
 save(folder/'report.json',report)
 save(W/'tiny-repair-result.json',dict(status='PASS_ORIGINAL_H64_CONFIG_NOW_COMPLETES',report=pin(folder/'report.json'),
  generated_tokens=4,cpu_ffn_layers=1,final_versions=0,hybrid_plan_facts=facts,hybrid_plan_lines=hybrid,
  workspace_domains=report['workspace_domains'],original_domain_and_host_constant_assertions_preserved=True,
  old_result='Both original229 variants and diagnostic229 refused before a complete plan; no old successfulcopy0 claim.',
  copy_scope='These are actual per-child hybrid totalcopy/workspace facts, including oldCPU transfers. Specific newaliascopy properties are independently checked by the approved unitCompileReports; defaultJSON has no perprovider details.'))
 print(json.dumps(dict(status='H64_NOW_COMPLETES',generated=4,hybrid_plan_facts=facts)),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='tests':tests(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='tiny':tiny(sys.argv[2])
 else:raise ValueError(sys.argv[1])
