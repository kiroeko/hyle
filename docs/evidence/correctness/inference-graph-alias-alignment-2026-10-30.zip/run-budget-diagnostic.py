"""One expected-failed test, preserving originalassert and XML plan properties."""
from pathlib import Path
import importlib.util,json,re,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('budget_diag_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
name='GraphRegions.AlignmentRepairKeepsWorkspaceLimitsAndRecoversAfterRefusal'
image=read(W/'ready-region.json');exact(image)
folder=W/'runs/budget-diagnostic/attempt1';save(folder/'image.json',image)
try:b.s.b.execute([image['path'],'--gtest_filter='+name,'--gtest_output=xml:'+str(folder/'result.xml')],folder,240)
except BaseException as error:save(folder/'driver-exception.json',dict(type=type(error).__name__,message=str(error)))
process=read(folder/'process.json');root=ET.parse(folder/'result.xml').getroot();cases=list(root.iter('testcase'))
assert len(cases)==1 and cases[0].attrib['classname']+'.'+cases[0].attrib['name']==name
assert cases[0].attrib['status']=='run' and cases[0].attrib['result']=='completed'
properties={item.attrib['name']:item.attrib['value'] for item in cases[0].iter('property')}
assert {'budget_original_plan','budget_limited_plan'}<=properties.keys()
def parse(text):
 general={key:int(value) for key,value in re.findall(r'(?:^| )(workspace|copy|materialized_constants|regions|leaf|plan_rejections|operation_rejections|region_rejections|search_states|placement_attempts|domain_count|step_count)=(\d+)',text)}
 domains=[dict(domain=int(index),bytes=int(size),limit=int(limit),backings=int(backings)) for index,size,limit,backings
  in re.findall(r'domain\[(\d+)\]bytes=(\d+)/limit=(\d+)/backings=(\d+)',text)]
 steps=[dict(step=int(index),kind=int(kind),node=int(node),nodes=int(nodes),provider=provider,provider_instance=int(iid),
  implementation=int(impl),target=int(target),copy=int(size)) for index,kind,node,nodes,provider,iid,impl,target,size in
  re.findall(r'step\[(\d+)\]kind=(\d+)/node=(\d+)/nodes=(\d+)/provider=(.*?)/iid=(\d+)/impl=(\d+)/target=(\d+)/copy=(\d+)',text)]
 return dict(**general,domains=domains,steps=steps,raw=text)
plans={key:parse(properties['budget_'+key+'_plan']) for key in ('original','limited')}
limited=plans['limited'];observed_all_domains=limited['domain_count']==len(limited['domains'])
respected=all(item['bytes']<=item['limit'] for item in limited['domains'])
classification=('OBSERVED_DOMAIN_CAP_VIOLATION' if not respected else
 'SUCCESSFUL_SELECTED_PLAN_WITHIN_ALL_DOMAIN_CAPS' if observed_all_domains else 'RECORDED_DOMAINS_WITHIN_CAPS_OTHER_DOMAINS_UNOBSERVED')
result=dict(status='EXPECTED_DIAGNOSTIC_TEST_FAILURE_RECORDED',actual_exit=process['exit'],executed=1,failed=len(list(root.iter('failure'))),
 original_assertion_unchanged=True,not_a_functional_pass=True,classification=classification,
 limited_all_domains_observed=observed_all_domains,limited_recorded_domains_within_cap=respected,
 original_workspace=plans['original']['workspace'],requested_cap=plans['original']['workspace']-1,
 plans=plans,xml=pin(folder/'result.xml'),stdout=pin(folder/'stdout.log'),stderr=pin(folder/'stderr.log'),
 scope='One diagnostic native only. Full unbounded plan bytes are not a proof of minimal possibleworkspace. This result reports actual selected domain peaks/caps and route facts; no assertion/budget/core changed.')
save(folder/'report.json',result);save(W/'budget-diagnostic-result.json',result)
assert process['state']=='TERMINAL' and process['exit']==1 and not process['timed_out'] and result['failed']==1
print(json.dumps(dict(status=result['status'],classification=classification,original_workspace=result['original_workspace'],
 requested_cap=result['requested_cap'],limited_workspace=limited['workspace'],limited_domains=limited['domains'],
 limited_plan_rejections=limited['plan_rejections'],limited_operation_rejections=limited['operation_rejections'])),flush=True)
