"""Publish fixed original-role bindings, actual related checks and limitations."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
OUT=R/'docs/evidence/correctness/qwen-original-mtp-input-2026-10-22.json'
ZIP=OUT.with_suffix('.logs.zip')

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

assert not OUT.exists() and not ZIP.exists()
final=read(S/'checks2/summary.json')
assert final['tests']==5 and final['process']['exit']==0 and not final['process']['timed_out']
assert not any(final[key] for key in ('failures','errors','disabled','skips'))
assert identity(final['image']['path'])['sha256']==final['image']['sha256']
acquisition=read(S/'original-q27/acquisition.json')
assert acquisition['complete'] and len(acquisition['roles'])==3
assert sum(role['payload']['bytes'] for role in acquisition['roles'])==43_048_960
for role in acquisition['roles']:
    assert identity(role['payload']['path'])['sha256']==role['payload']['sha256']
files=[
    'tests/compute_models/qwen27_original_mtp_input_test.cc',
    'tests/compute_models/original_role_input.h',
    'tests/compute_models/cpu_c5_qwen_nextn.h',
    'tests/compute_models/cpu_c5_parameter_tests.h',
    'tests/graph_route_cpu/CMakeLists.txt','tests/graph_route_cuda/CMakeLists.txt',
    'docs/developer/current-work.md','docs/implementation/model-operators.md',
]
for name in files:
    target=S/'source-current'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((R/name).read_bytes())
(S/'cleanup-script.ps1').write_bytes((R/'test.ps1').read_bytes())
numerics=[]
backend=None
for line in (S/'checks2/stdout.log').read_text(encoding='utf-8').splitlines():
    if '[ RUN ' in line and 'Qwen27OriginalMtpInput.' in line:
        backend='CUDA' if '.Cuda' in line else 'CPU'
    match=re.search(r'Q27 original Q6_K (.+) maxAbs=([\deE.+-]+) rmse=([\deE.+-]+) referencePeak=([\deE.+-]+)',line)
    if match:numerics.append(dict(backend=backend,reference=match[1],max_absolute_error=float(match[2]),
        RMSE=float(match[3]),reference_peak=float(match[4])))
assert len(numerics)==12
cleanup=read(S/'cleanup-result.json')
assert cleanup['CurrentImageRetained'] and cleanup['CurrentMapRetained']
assert all(not Path(item['path']).exists() for item in cleanup['Removed'])
report=dict(date='2026-10-22',status='ORIGINAL_Q27_INPUT_AND_CURRENT_Q24_CODEC_CONSUMERS_PASS',
    goal_complete=False,changes=[identity(R/name) for name in files],final_checks=final,
    q27=dict(acquisition=acquisition,parsed_main_header=identity(S/'original-q27/header.json'),
        scope='Primary UD-Q4_K_M main GGUF embedded NextN blk64, not the Q4_K EH sidecar. Original Q6_K EH[GGUF K10240,N5120] and two F32 norm5120 roles.',
        graph='F32 h/e -> separate F32 RMSNorm epsilon1e-6F from actual metadata -> normalized embedding before hidden -> original packed Q6_K EH -> F32.',
        execution='One shared logical builder/checker; ordinary CPU and CUDA contexts, each one cold parameter binding and one Invocation with three actual submissions. Dense changed input twice then zero; bounded two-generation output pool and four old result leases remain valid after pool reuse/Invocation destruction. Original parameter bytes unchanged.',
        reference='Independent FP64 normalization and row-wise original Q6_K decode plus FP64 Neumaier dot. Both actual-joined local equation and independently normalized whole component equation checked. Decode is oracle-only with one row scratch, not an expanded model weight bank for execution.',
        tolerance='Existing strict F32 norm gate3e-5 absolute +2e-5 relative; exact concat bytes. Existing quantized-chain RMSE/max gates after existing reference-peak normalization, unchanged. CPU native Q6_KxQ8_K and CUDA small-M Q6_KxQ8_1 activation quantization differ, so no cross-backend byte equality claim.',
        numerical_observations=numerics,full_model=False,complete_MTP_state=False),
    q24=dict(profiles=['UD-IQ4_XS','Q8_0'],fixed_revision='567d3e6ac26c5474b18311e619c04350fb9a5556',
        correction='The existing generated NextN decoder consumer now uses the currently selected primary profile54 and fidelity48. Removed old UD-IQ1_M/Q2_K expert branch; named parameters carry each actual role codec.',
        primary='Q5_K attention/shared gate-up; Q4_K routed experts and vocabulary; Q6_K shared down; Q8_0 EH; F32 router/shared gate/norms.',
        fidelity='Q8_0 attention, experts, shared FFN, vocabulary and EH, with F32 router/shared gate/norms.',
        checks='Existing original-order/norm/carry case and complete NextN case both run both profiles via ordinary CPU Graph. Four embedding/decode feedback steps and full V248320 sharded head; prior state ports/oracle/tolerances unchanged.',
        original_payload=False,complete_accepted_prefix_publication=False,
        investigation=identity(S/'q24-review/review.json')),
    validation_cache=dict(
        first_run='checks1: four pass; Q24 fidelity large Q8_0 embedding Gather refused before execution.',
        reason='Retained AW provider object was compiled without HYLE_GGML_CPU_IQ1_EXTENSIONS despite using the actual fixed CPU SDK. Production CMake already propagates this capability through ggml INTERFACE. Only the mismatched C++ provider TU was rebuilt with that existing capability.',
        source='src/compute_ggml_runtime/CMakeLists.txt:239-240; src/compute_provider_ggml/ggml_cpu_provider.cc:2067-2078.',
        source_elements=2_034_237_440,source_encoded_bytes=2_161_377_280,
        product_gate_changed=False,math_changed=False,provider_forced=False,
        link_closure='First link also lacked the existing CPU public compile entry and the head checker companion test TU; both were compiled from unchanged current sources, matching their normal CMake target composition.'),
    shared_reader='Extracted authenticated read_bytes and finite little-endian read_float from the existing helper; original read_bfloat API, SHA and finite checks retained. Existing GLM original BF16 component rerun and passed3 submissions.',
    CMake='The same source is registered for CPU-only and CUDA test targets with separate backend guards; the actual run enabled both in one cached host image. Dedicated CMake configurations were not rebuilt.',
    cleanup=cleanup,
    limits=['Windows CPU/CUDA finite component checks only; no whole Q27 model, MTP proposal/acceptance or complete state claim.',
            'Q24 weights remain generated packed banks with the declared finite resident mapping. Original payloads and complete accepted-prefix composition remain.',
            'No new TPS or physical CPU/GPU memory sample. AV remains the latest four-arm performance table.',
            'No new production executor/loader/public API, SDK build, NVCC or shader build.'],
    next='Bind selected actual Q24 K/V Q5_K plus K norm (11,535,360B), verifying the fixed shard29 physical offsets first; continue applicable actual-role/state combinations rather than expanding unrelated synthetic matrices.',
)
save(S/'report-before-archive.json',report)
selected=[p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in
          {'.json','.py','.mjs','.cc','.h','.cuh','.md','.diff','.log','.xml','.txt','.ps1'} and
          '__pycache__' not in p.parts and 'tmp' not in p.parts]
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(selected):archive.write(path,path.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive:assert archive.testzip() is None
report['sources_commands_results_and_cleanup']=identity(ZIP)
report['large_original_payloads_archived']=False
save(OUT,report)
receipt=dict(result=identity(OUT),logs=identity(ZIP),goal_complete=False)
save(S/'publication-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
