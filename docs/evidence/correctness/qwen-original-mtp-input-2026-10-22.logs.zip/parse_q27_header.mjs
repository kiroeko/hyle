import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {gguf,GGMLQuantizationType} from '../hf-gguf-tools/node_modules/@huggingface/gguf/dist/index.mjs';
const folder = '.scratch/qwen-original-mtp-20261022/original-q27';
const acquisition = JSON.parse(await fs.readFile(`${folder}/acquisition.json`,'utf8'));
const raw = await fs.readFile(`${folder}/header-prefix.bin`);
if(raw.length!==acquisition.header_prefix.bytes || crypto.createHash('sha256').update(raw).digest('hex')!==acquisition.header_prefix.sha256) throw new Error('Prefix identity differs');
const parsed = await gguf(acquisition.url,{fetch:async(_url,options={})=>{
  const range = new Headers(options.headers).get('range');
  const match = /^bytes=(\d+)-(\d+)$/.exec(range||'');
  if(!match)throw new Error(`Unbounded parser request: ${range}`);
  const first=Number(match[1]),last=Number(match[2]);
  if(first>last || last>=raw.length)throw new Error('Parser exceeds authenticated finite prefix');
  return new Response(raw.subarray(first,last+1),{status:206,headers:{
    'content-range':`bytes ${first}-${last}/${acquisition.file_bytes}`,
    'content-length':String(last-first+1)}});
}});
if(BigInt(parsed.tensorDataOffset)>BigInt(raw.length))throw new Error('Header was not entirely acquired');
const tensors=parsed.tensorInfos.map(t=>({name:t.name,shape:t.shape,dtype:GGMLQuantizationType[t.dtype],dtype_code:t.dtype,offset:t.offset}));
const value={repository:acquisition.repository,revision:acquisition.revision,file:acquisition.file,
  tensor_count:tensors.length,tensor_data_offset:parsed.tensorDataOffset,
  metadata:Object.fromEntries(Object.entries(parsed.metadata).filter(([key])=>!key.startsWith('tokenizer.'))),tensors,
  parser:'Existing @huggingface/gguf package, authenticated local prefix only; no parser network access'};
await fs.writeFile(`${folder}/header.json`,JSON.stringify(value,(_key,v)=>typeof v==='bigint'?String(v):v,2)+'\n');
console.log('MAIN HEADER',tensors.length,'data base',String(parsed.tensorDataOffset));
console.log(tensors.filter(t=>/blk\.64\.nextn\.(eh_proj|enorm|hnorm)/.test(t.name)));
