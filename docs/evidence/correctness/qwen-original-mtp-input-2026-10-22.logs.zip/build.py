"""Related host consumers over the matched AX closure; reuse all native SDKs."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AX = R / '.scratch/dspark-natural-journey-20261022'
spec = importlib.util.spec_from_file_location('ay_cached', AX / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b,c,h = a.b,a.c,a.h
h.S = S
BASE = AX / 'tests-link4'
SOURCES = {
    'q27': R / 'tests/compute_models/qwen27_original_mtp_input_test.cc',
    'glm': R / 'tests/graph_route_cuda/glm_original_mtp_input_test.cc',
    'q24': R / 'tests/graph_route_cpu/d5_qwen38_official_test.cc',
    'q24-head': R / 'tests/graph_route_cpu/d5_qwen_gguf_vocabulary_test.cc',
    'cpu-compile': R / 'src/graph_route_cpu/compile.cc',
    'cpu-provider': R / 'src/compute_provider_ggml/ggml_cpu_provider.cc',
}

def compile_one(tag, attempt):
    old = c.read(AX / 'compile4/glm/identity.json')
    if tag == 'cpu-provider':
        old = c.read(R / '.scratch/dspark-mtp-integration-20261022/compile1/cpu-provider/identity.json')
        old['command'] += ['/DHYLE_GGML_CPU_IQ1_EXTENSIONS=1']
    if tag == 'q27': old['command'] += ['/DHYLE_TEST_Q27_CPU=1', '/DHYLE_TEST_Q27_CUDA=1']
    if tag in ('q24','q24-head'):
        old['command'] += ['/DHYLE_GGML_CPU_IQ1_EXTENSIONS=1', '/DHYLE_COMPUTE_GGML_CPU=1',
                           '/DHYLE_COMPUTE_TORCH_CPU=1', '/DHYLE_TEST_TORCH_CPU=1',
                           '/DHYLE_TEST_GRAPH_ROUTE_CPU=1']
    if tag in ('q27','q24','q24-head'):
        old['command'][1:1] = [
            '/external:I' + str(R / '.scratch/validation/cpu-final-f1/mixed-iq1/source/include'),
            '/external:I' + str(R / '.scratch/validation/cpu-final-f1/mixed-iq1/source/src')]
    recipe = S / 'recipes' / f'{tag}.json'
    recipe.parent.mkdir(parents=True, exist_ok=True)
    c.save(recipe, old)
    h.RECIPES[tag],h.SOURCES[tag] = recipe,SOURCES[tag]
    h.compile_one(tag,attempt)

def latest(tag):
    paths=sorted(S.glob(f'compile*/{tag}/identity.json'),key=lambda p:int(p.parents[1].name[7:]))
    assert paths,tag
    return paths[-1],c.read(paths[-1])

def link(tags,attempt):
    base=c.read(BASE / 'link-plan.json')
    remove=set()
    for item in base['compiled_records']:
        rec=c.read(item['path'])
        if '/tests/' in rec['source']['path'].replace('\\','/'):
            remove.add(c.key(rec['object']['path']))
    if 'cpu-provider' in tags:
        remove.add(c.key(R / '.scratch/dspark-mtp-integration-20261022/compile1/cpu-provider/cpu-provider.obj'))
    inputs=[item for item in base['inputs'] if c.key(item['path']) not in remove]
    command=[item for item in base['command'] if c.key(item) not in remove and
             not item.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    extra,records=[],[]
    for tag in tags:
        path,record=latest(tag)
        assert all(b.identity(item['path'])==item for item in
                   [record['source'],record['object'],*record['dependencies']])
        extra.append(record['object'])
        records.append(b.identity(path))
    inputs=extra+inputs
    command[1:1]=[item['path'] for item in extra]
    assert all(b.identity(item['path'])==item for item in inputs)
    folder=S / f'tests-link{attempt}'
    folder.mkdir()
    (folder/'tmp').mkdir()
    image=folder/'qwen-mtp-checks.exe'
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
                '/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(folder/'link-plan.json',dict(command=command,inputs=inputs,compiled_records=records,
        base=b.identity(BASE/'link-plan.json'),SDK_builds=0,NVCC_builds=0,shader_builds=0))
    env,_=b.environment(command,[item['path'] for item in inputs],folder)
    c.execute('link',command,env,folder)
    runtime=c.read(BASE/'runtime-environment.json')
    for item in runtime['staged_dlls']:
        os.link(item['path'],folder/Path(item['path']).name)
    runtime['staged_dlls']=[b.identity(path) for path in folder.glob('*.dll')]
    c.save(folder/'runtime-environment.json',runtime)
    c.save(folder/'ready.json',dict(image=b.identity(image)))
    print('LINKED',image,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('actions',nargs='+',choices=[*SOURCES,'link'])
    parser.add_argument('--attempt',type=int,default=1)
    parser.add_argument('--tags',nargs='+',choices=SOURCES,default=['q27','glm','q24','q24-head','cpu-compile','cpu-provider'])
    args=parser.parse_args()
    for action in args.actions:
        if action=='link':link(args.tags,args.attempt)
        else:compile_one(action,args.attempt)
