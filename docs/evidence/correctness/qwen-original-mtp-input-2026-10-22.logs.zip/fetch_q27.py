"""Acquire the fixed main-file GGUF header and three original NextN roles."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
F = S / 'original-q27'
repository = 'unsloth/Qwen3.8-27B-GGUF'
revision = '4ca720788d1e01f1bff70c033e0d0028fd02e502'
filename = 'Qwen3.8-27B-UD-Q4_K_M.gguf'
url = f'https://huggingface.co/{repository}/resolve/{revision}/{filename}'

def save():
    (F / 'acquisition.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

def fetch(first, count, path):
    last = first + count - 1
    item = dict(first=first, last=last, bytes=count, complete=False)
    receipt['requests'].append(item)
    save()
    request = urllib.request.Request(url, headers={
        'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity',
        'User-Agent': 'hyle-original-nextn-input/1'})
    with urllib.request.urlopen(request, timeout=45) as response:
        value = response.headers.get('Content-Range', '')
        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', value)
        assert response.status == 206 and match and (int(match[1]), int(match[2])) == (first,last), \
            'Refuse whole-file or mismatched range response before reading body'
        total = int(match[3])
        if 'file_bytes' in receipt: assert total == receipt['file_bytes']
        receipt['file_bytes'] = total
        etag = response.headers.get('ETag')
        if 'etag' in receipt: assert etag == receipt['etag']
        receipt['etag'] = etag
        length = response.headers.get('Content-Length')
        assert length is None or int(length) == count
        item.update(http_status=response.status, content_range=value, etag=etag)
        digest, remaining = hashlib.sha256(), count
        with path.open('xb') as output:
            while remaining:
                chunk = response.read(min(1 << 20, remaining))
                assert chunk, 'Truncated exact range'
                output.write(chunk)
                digest.update(chunk)
                remaining -= len(chunk)
            assert not response.read(1), 'Response exceeds requested range'
    item.update(complete=True, path=str(path), sha256=digest.hexdigest())
    save()
    return dict(path=str(path), bytes=count, sha256=item['sha256'])

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['header','roles'])
args = parser.parse_args()
if args.action == 'header':
    F.mkdir(parents=True, exist_ok=False)
    receipt = dict(repository=repository, revision=revision, file=filename, url=url,
                   whole_file_download_allowed=False, requests=[], roles=[], complete=False)
    receipt['header_prefix'] = fetch(0, 12_000_000, F / 'header-prefix.bin')
    save()
    print('Fixed main-file prefix acquired', receipt['header_prefix'], flush=True)
else:
    receipt = json.loads((F / 'acquisition.json').read_text(encoding='utf-8'))
    header = json.loads((F / 'header.json').read_text(encoding='utf-8'))
    assert header['file'] == filename and header['revision'] == revision
    assert header['tensor_count'] == 866 and not receipt['roles']
    assert int(header['tensor_data_offset']) <= receipt['header_prefix']['bytes']
    receipt['tensor_data_offset'] = int(header['tensor_data_offset'])
    specifications = [
        ('blk.64.nextn.eh_proj.weight', [10240,5120], 'Q6_K', 43_008_000, 'eh_proj.weight.q6_k'),
        ('blk.64.nextn.enorm.weight', [5120], 'F32', 20_480, 'enorm.weight.f32'),
        ('blk.64.nextn.hnorm.weight', [5120], 'F32', 20_480, 'hnorm.weight.f32'),
    ]
    for name, shape, codec, count, local in specifications:
        tensor = next(t for t in header['tensors'] if t['name'] == name)
        assert list(map(int,tensor['shape'])) == shape and tensor['dtype'] == codec
        offset = int(tensor['offset'])
        following = [int(t['offset']) for t in header['tensors'] if int(t['offset']) > offset]
        assert not following or offset + count <= min(following)
        first = receipt['tensor_data_offset'] + offset
        assert first + count <= receipt['file_bytes']
        payload = fetch(first, count, F / local)
        receipt['roles'].append(dict(name=name, GGUF_shape=shape, dtype=codec,
            relative_offset=offset, absolute_start=first, payload=payload))
        save()
        print(name, payload, flush=True)
    receipt['complete'] = True
    save()
