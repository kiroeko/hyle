"""Reuse the CUDA closure; compile only consumer/probe host sources."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
M=Path(__file__).resolve().parent;R=M.parents[1];S=R/'.scratch/qwen-topone-prepared-20261022';D=R/'.scratch/qwen-cli-batch-20261022'
spec=importlib.util.spec_from_file_location('prior',S/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c

def same(record):return b.identity(record['path'])==record

def compile_owner(tag,attempt):
    out=M/f'compile{attempt}'/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    source=R/'tools/qwen35_text/main.cc'if tag=='qwen'else M/('target_probe.cc'if tag=='target'else'math_probe.cc')
    prior=c.read(D/'compile4/qwen/identity.json');command=b.host_command(prior['command'],source,tag,out)
    assert all(x in command for x in ('/W4','/WX','/O2','/MD'))
    frozen=b.identity(source);main=b.identity(R/'tools/qwen35_text/main.cc')
    snap=out/'source'/source.relative_to(R);snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(source.read_bytes())
    c.save(out/'plan.json',dict(command=command,source=frozen,main=main,recipe=b.identity(D/'compile4/qwen/identity.json'),SDK_builds=0,native_rebuilds=0))
    env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
    data=c.read(out/f'{tag}-deps.json')['Data'];deps=list(dict.fromkeys([data['Source'],*data['Includes']]))
    assert same(frozen)and same(main)
    c.save(out/'identity.json',dict(source=frozen,main=main,object=b.identity(out/f'{tag}.obj'),command=command,dependencies=[b.identity(x)for x in deps]))
    print('COMPILED',tag,flush=True)

def link(tag,attempt):
    base_path=S/'qwen-link1/link-plan.json';base=c.read(base_path);recpath=M/f'compile{attempt}'/tag/'identity.json';rec=c.read(recpath)
    assert all(same(x)for x in(rec['source'],rec['main'],rec['object'],*rec['dependencies']))
    old=c.key(D/'compile4/qwen/qwen.obj');assert sum(c.key(x['path'])==old for x in base['inputs'])==1
    assert all(same(x)for x in base['inputs'])
    inputs=[rec['object']if c.key(x['path'])==old else x for x in base['inputs']]
    command=[rec['object']['path']if c.key(x)==old else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out=M/f'{tag}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/f'{tag}.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),compiled_record=b.identity(recpath),SDK_builds=0,native_rebuilds=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    for dll in(S/'qwen-link1').glob('*.dll'):os.link(dll,out/dll.name)
    runtime=c.read(S/'qwen-link1/runtime-environment.json');runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')];c.save(out/'runtime-environment.json',runtime)
    c.save(M/f'{tag}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=rec['source'],main=rec['main'],link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0,native_rebuilds=0))
    print('READY',tag,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('qwen','probe','target'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--link',action='store_true');a=p.parse_args()
    if a.link:link(a.mode,a.attempt)
    else:compile_owner(a.mode,a.attempt)
