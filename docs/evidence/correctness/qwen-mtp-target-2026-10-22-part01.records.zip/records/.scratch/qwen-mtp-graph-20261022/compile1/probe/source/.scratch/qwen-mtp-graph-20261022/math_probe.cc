#define main hyle_qwen35_text_consumer_main
#include "../../tools/qwen35_text/main.cc"
#undef main

namespace q = qwen35;

int main(int argc, char **argv) {
  try {
    if (argc != 4) throw std::runtime_error("math_probe MTP_weights.tsv INPUTS NEW_OUTPUT");
    const std::filesystem::path inputs(argv[2]), output(argv[3]);
    if (std::filesystem::exists(output)) throw std::runtime_error("output must be new");
    std::filesystem::create_directories(output);
    auto context = q::take(q::g::cuda::create_context());
    auto memory = q::take(q::c::StorageOwner::adopt(context,
        q::take(q::c::cuda::MemoryResource::create(context, q::c::cuda::MemoryKind::kDevice))));
    auto staging = q::take(q::c::cuda::MemoryResource::create(context, q::c::cuda::MemoryKind::kPinnedHost));
    auto queue = q::take(context.create_queue());
    std::vector<q::c::LeasePool> pools;
    std::map<std::string, q::Tensor> bank;
    const auto loaded = q::load_weight_bank(argv[1], memory, staging.ref(), queue,
        context, bank, pools, q::WeightSelection::kTextAndMtp);
    const auto storage = q::take(q::c::CacheStorage::plain(q::Type::kBFloat16));
    auto schema = q::take(q::c::BatchSchema::create({
        .storage=q::c::BatchStorage::kPaged, .query_type=q::Type::kBFloat16,
        .output_type=q::Type::kBFloat16, .key_storage=storage, .value_storage=storage,
        .max_requests=1,.max_query_rows=2,.max_kv_rows=16,.max_pages=1,.max_page_refs=1,
        .query_heads=8,.kv_heads=2,.qk_head_dim=256,.value_head_dim=256,.page_size=16}));
    auto keys = q::take(q::c::PagedArena::create(schema,q::c::BatchCacheRole::kKey,memory.ref()));
    auto values = q::take(q::c::PagedArena::create(schema,q::c::BatchCacheRole::kValue,memory.ref()));
    q::Recipe r(bank,memory,2);
    const auto ids = r.input(q::dense(q::Type::kInt32,{2}));
    const auto positions = r.input(q::dense(q::Type::kInt32,{2}));
    const auto hidden = r.input(q::dense(q::Type::kBFloat16,{2,2048}));
    const auto key = r.input(q::take(q::c::batch_cache_description(schema,q::c::BatchCacheRole::kKey)));
    const auto value = r.input(q::take(q::c::batch_cache_description(schema,q::c::BatchCacheRole::kValue)));
    const auto metadata = r.input(q::take(schema.metadata_description()));
    std::array<float,32> frequency{};
    for(std::size_t i=0;i<frequency.size();++i) frequency[i]=1.F/std::pow(10000000.F,float(i)/32.F);
    r.literals.emplace_back(memory.ref(),q::dense(q::Type::kFloat32,{32}));
    r.literals.back().write<float>(frequency);
    const auto frequencies=r.constant(r.literals.back());
    const auto projection=q::mtp::input_projection(r,ids,hidden);
    const auto kv=q::mtp::project_kv(r,projection,positions,frequencies);
    const auto head=q::mtp::full_head(r,projection,kv,positions,frequencies,
        q::mtp::PagedInputs{schema,key,value,metadata},q::f(1));
    const std::array outputs{
        std::pair{"fc.bf16",projection.fused},std::pair{"attn_input_norm.bf16",projection.normalized},
        std::pair{"key_rotary.bf16",kv.key_rows},std::pair{"value_projection.bf16",kv.value_rows},
        std::pair{"final_norm.bf16",head.hidden_rows},std::pair{"selected_hidden.bf16",head.selected_hidden},
        std::pair{"logits.f32",head.logits},std::pair{"greedy_ids.i32",head.ids}};
    for(const auto &[name,id]:outputs) { (void)name; r.publish(id); }
    auto graph=q::take(std::move(r.builder).finish());
    const std::array shape{q::g::ShapeBinding{r.last_row,1}};
    const std::array variants{q::g::ExactShapeVariant{shape}};
    auto compiled=q::take(q::g::cuda::compile(graph,context,memory,
        {.shape_policy=q::g::CompileShapePolicy::kFiniteExact,.exact_variants=variants,.constants=r.constants}));
    auto run=q::take(compiled.executable.create_invocation({.shape=shape}));
    std::vector<q::Tensor> caller_outputs;
    caller_outputs.reserve(outputs.size());
    for(std::size_t i=0;i<compiled.executable.output_count();++i) {
      if(q::take(compiled.executable.output_ownership(i))!=q::g::OutputOwnership::kCaller) continue;
      const auto port=q::take(compiled.executable.output_id(i));
      caller_outputs.emplace_back(memory.ref(),q::Model::output_description(compiled.report,port));
      q::check(run.bind(port,caller_outputs.back().view()));
    }
    q::Tensor token_tensor(memory.ref(),q::dense(q::Type::kInt32,{2})),
        position_tensor(memory.ref(),q::dense(q::Type::kInt32,{2})),
        hidden_tensor(memory.ref(),q::dense(q::Type::kBFloat16,{2,2048}));
    const auto read_ids=[&](const char *name) {
      std::ifstream stream(inputs/name); std::array<std::int32_t,2> data{};
      if(!(stream>>data[0]>>data[1])) throw std::runtime_error("short IDs input");
      return data;
    };
    token_tensor.write<std::int32_t>(read_ids("tokens.ids"));
    position_tensor.write<std::int32_t>(read_ids("positions.ids"));
    std::array<std::uint16_t,4096> h{};std::ifstream hs(inputs/"hidden.bf16",std::ios::binary);
    hs.read(reinterpret_cast<char*>(h.data()),sizeof(h));
    if(!hs) throw std::runtime_error("short hidden input");
    hidden_tensor.write<std::uint16_t>(h);
    q::check(run.bind(ids,token_tensor.read()));q::check(run.bind(positions,position_tensor.read()));
    q::check(run.bind(hidden,hidden_tensor.read()));
    const std::array<std::int32_t,2> empty{0,0}, query{0,2}, pages{0,1};
    const std::array<std::int32_t,1> page{0}, last{2}, zero{0};
    const auto old=q::take(schema.version({empty,empty,{},zero}));
    const auto next=q::take(schema.version({query,pages,page,last}));
    auto old_key=q::take(keys.read(old,{})),old_value=q::take(values.read(old,{}));
    std::array key_writer{q::take(keys.acquire(0))},value_writer{q::take(values.acquire(0))};
    auto key_append=q::take(q::g::batch::PagedAppendPages::create(keys,next,old_key,key_writer));
    auto value_append=q::take(q::g::batch::PagedAppendPages::create(values,next,old_value,value_writer));
    const std::array queues{q::g::QueueBinding{.lane=q::g::ExecutionLaneId{0},.queue=&queue}};
    const std::array layouts{q::g::batch::NodeLayout{head.attention_node,next}};
    q::check(q::g::batch::prepare(run,queues,layouts,{.host_workspace=staging.ref()}));
    q::check(q::g::batch::bind_append(run,graph,head.append_nodes.key,key,std::move(key_append)));
    q::check(q::g::batch::bind_append(run,graph,head.append_nodes.value,value,std::move(value_append)));
    q::check(run.prepare_replay(queues,{.mode=q::g::ReplayMode::kPreferCapture}));
    auto done=q::take(run.submit(queues));q::check(done.wait());
    for(const auto &[name,id]:outputs) {
      auto view=q::take(run.output(id));std::vector<std::byte> bytes(q::take(view.description().required_bytes()));
      q::check(view.storage().read(bytes));
      std::ofstream file(output/name,std::ios::binary);file.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
      if(!file) throw std::runtime_error("cannot write probe output");
    }
    auto returned_key=q::take(q::g::batch::take_append(run,head.append_nodes.key));
    auto returned_value=q::take(q::g::batch::take_append(run,head.append_nodes.value));
    auto ready_key=q::take(returned_key.ready()),ready_value=q::take(returned_value.ready());
    (void)ready_key;(void)ready_value;
    q::check(context.drain());
    std::cout<<"{\"status\":\"real MTP block executed\",\"weight_tensors\":"<<bank.size()
      <<",\"weight_bytes\":"<<loaded.bytes<<",\"graph_steps\":"<<compiled.report.step_count()
      <<",\"candidate_validation\":false,\"full_speculative_consumer\":false}\n";
    return 0;
  } catch(const std::exception &error) { std::cerr<<error.what()<<'\n';return 1; }
}
