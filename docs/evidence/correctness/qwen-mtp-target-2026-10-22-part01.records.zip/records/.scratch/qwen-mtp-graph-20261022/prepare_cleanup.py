from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]


def ident(p):
    p = p.resolve()
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=h.hexdigest())


pub = json.loads((S / 'published.json').read_text())
assert pub['archive_verified_entries'] > 0
manifest = json.loads(Path(pub['manifest']['path']).read_text(encoding='utf-8'))
archived = {x['path']: x for x in manifest['archive_files']}
aliases = {x['original']['path']: x for x in manifest['superseded_payload_aliases']}
keep = {str((S / 'qwen-link2/qwen.exe').resolve())}
targets = []
for p in S.rglob('*'):
    if not p.is_file():
        continue
    relative = p.relative_to(S)
    raw = p.suffix.lower() in ('.bf16', '.f32', '.i32', '.f16', '.bin', '.raw') and (
        'trace' in relative.parts or relative.parts[0].startswith(('math-output', 'target-output', 'reference-output')))
    if raw or p.suffix.lower() in ('.map', '.lib', '.exp') or (
        p.suffix.lower() == '.exe' and str(p.resolve()) not in keep
    ):
        item = ident(p)
        if raw:
            if item['path'] in archived:
                assert all(item[k] == archived[item['path']][k] for k in ('bytes', 'sha256'))
            else:
                alias = aliases[item['path']]
                assert item == alias['original']
                canonical = archived[alias['canonical']['path']]
                assert all(item[k] == canonical[k] for k in ('bytes', 'sha256'))
                item['archived_canonical'] = alias['canonical']['path']
        targets.append(item)
plan = dict(stage=str(S), archives=manifest['archives'], targets=targets,
            bytes=sum(x['bytes'] for x in targets), kept_images=sorted(keep),
            note='Exact stage-local leaves only. All raw payloads retained in verified ZIP or explicit SHA-identical canonical aliases. Keep inputs, all sources/objects/commands/results and final consumer image; no recursive operations. Root test.ps1 must not be rerun after completion.')
(S / 'cleanup-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print('PLAN', len(targets), 'exact leaves', plan['bytes'], 'bytes; KEEP', sorted(keep))
