$ErrorActionPreference = 'Stop'
$repository = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$stage = [IO.Path]::GetFullPath((Join-Path $repository '.scratch/qwen-mtp-graph-20261022'))
$plan = Get-Content -LiteralPath (Join-Path $stage 'cleanup-plan.json') -Raw | ConvertFrom-Json
$receipt = Join-Path $repository 'docs/evidence/correctness/qwen-mtp-target-2026-10-22.cleanup.json'
if (Test-Path -LiteralPath $receipt) { throw 'Cleanup already completed; do not rerun.' }
if ($plan.stage -ne $stage) { throw 'Stage mismatch.' }
$prefix = $stage + [IO.Path]::DirectorySeparatorChar
$archiveRoot = [IO.Path]::GetFullPath((Join-Path $repository 'docs/evidence/correctness')) + [IO.Path]::DirectorySeparatorChar
foreach ($record in $plan.archives) {
    $archive = [IO.Path]::GetFullPath($record.path)
    if (-not $archive.StartsWith($archiveRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Archive outside evidence directory.' }
    $item = Get-Item -LiteralPath $archive
    if ($item.PSIsContainer -or $item.Length -ne $record.bytes -or (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256) { throw "Archive changed: $archive" }
}
# Check every exact target before the first deletion.
foreach ($record in $plan.targets) {
    $target = [IO.Path]::GetFullPath($record.path)
    if (-not $target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Target outside exact stage: $target" }
    if ($plan.kept_images -contains $target) { throw 'Current image selected for deletion.' }
    $item = Get-Item -LiteralPath $target
    if ($item.PSIsContainer -or $item.Length -ne $record.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.sha256) { throw "Target changed: $target" }
}
foreach ($record in $plan.targets) { Remove-Item -LiteralPath $record.path -Force }
$result = [ordered]@{ status='completed'; stage=$stage; deleted_leaf_count=$plan.targets.Count; deleted_bytes=$plan.bytes; deleted=$plan.targets; kept_images=$plan.kept_images; archives=$plan.archives; recursive_deletes=0; note=$plan.note }
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receipt -Encoding utf8
Write-Output ("Removed {0} exact leaves, {1} bytes; final image and object caches retained." -f $plan.targets.Count, $plan.bytes)
