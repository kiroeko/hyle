"""Keep final finite mathematical/state data, source, commands and failures."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / 'docs/evidence/correctness'
STEM = 'qwen-mtp-target-2026-10-22'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def ident(p):
    p = Path(p).resolve()
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=h.hexdigest())


def save(p, d):
    p.write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')


for name in ('target-run2', 'probe-run3', 'reference-run1', 'r1-run2', 'batch-run2'):
    assert read(S / name / 'run.result.json')['exit'] == 0
target = read(S / 'target-output2/observation.json')
assert target['old_base_unchanged'] and target['all_compared_vectors_finite']
assert len(target['metrics']) == 228 and target['injected_acceptance']
math = read(S / 'review/mtp-math-comparison.json')
runtime = read(S / 'review/target-runtime-review.json')
review = read(S / 'review/target-implementation-review.json')
ordinary = read(S / 'review/topone-model-regression.json')
assert ordinary['total_vector_pairs'] == 90
sources = [R / f'tools/qwen35_text/{x}' for x in ('main.cc', 'session_state.h', 'mtp_graph.h', 'README.md')]
ready = {}
for tag, attempt in [('qwen', 2), ('target', 2), ('probe', 4)]:
    ready[tag] = read(S / f'{tag}-ready-attempt{attempt}.json')
    assert ident(ready[tag]['image']['path']) == ready[tag]['image']
    assert ident(sources[0]) == ready[tag]['main']

paths = sources + [R / 'docs/developer/current-work.md', R / 'docs/developer/performance/decode.md']
aliases = []
mapping = {'target-output': 'target-output2', 'math-output2': 'math-output3',
           'r1-run1': 'r1-run2', 'batch-run1': 'batch-run2'}
for p in S.rglob('*'):
    if not p.is_file():
        continue
    relative = p.relative_to(S)
    if any(x in ('tmp', '__pycache__') for x in relative.parts):
        continue
    if p.suffix.lower() in ('.obj', '.exe', '.dll', '.lib', '.exp', '.pdb', '.map') or p.name == 'published.json':
        continue
    if p.suffix.lower() in ('.bf16', '.f32', '.i32') and relative.parts[0] in mapping:
        canonical = S / mapping[relative.parts[0]] / Path(*relative.parts[1:])
        if canonical.is_file():
            a, b = ident(p), ident(canonical)
            if (a['bytes'], a['sha256']) == (b['bytes'], b['sha256']):
                aliases.append(dict(original=a, canonical=b))
                continue
    paths.append(p)
paths = sorted(set(p.resolve() for p in paths), key=lambda p: p.relative_to(R).as_posix())
files = [dict(**ident(p), entry=p.relative_to(R).as_posix()) for p in paths]
archives = []
z = None
try:
    for p, row in zip(paths, files):
        if z is None or z.fp.tell() > 80_000_000:
            if z is not None:
                z.close()
                archives.append(ident(current))
            current = P / f'{STEM}.data.part{len(archives) + 1:02}.zip'
            assert not current.exists()
            z = zipfile.ZipFile(current, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6)
        z.write(p, row['entry'])
    if z is not None:
        z.close()
        z = None
        archives.append(ident(current))
finally:
    if z is not None:
        z.close()
entries = {}
for archive in archives:
    assert archive['bytes'] < 100 * 2**20
    with zipfile.ZipFile(archive['path']) as z:
        assert z.testzip() is None
        for entry in z.infolist():
            assert entry.filename not in entries
            data = z.read(entry.filename)
            entries[entry.filename] = (len(data), hashlib.sha256(data).hexdigest())
assert len(entries) == len(files)
assert all(entries[x['entry']] == (x['bytes'], x['sha256']) for x in files)
archived = {x['path']: x for x in files}
assert all(a['canonical']['path'] in archived for a in aliases)
manifest = dict(
    schema='hyle.qwen-mtp-target.v1', date='2026-10-22',
    status='Actual one-layer MTP graph and target accepted-boundary implementation verified in finite probes; full speculative consumer and broad goal incomplete',
    sources=[ident(p) for p in sources], images=ready,
    archives=archives, archive_files=files, superseded_payload_aliases=aliases,
    archive_layout='Ordinary ZIP volumes under100MiB. Repository-relative paths. CRC and every entry SHA verified. Superseded byte-identical raw payloads refer to canonical final entries; original identities remain explicit. No checkpoint, SDK, object or executable copied.',
    implementation=[
        'Consumer-private MTP graph helper builds original15-weight projection/KV/attention/FFN/finalnorm+tied head as ordinary values/effects in one Recipe, without another executor or native API.',
        'The existing target family body is shared by ordinary/verify cold roles. VerifyT2 outputs both IDs/hidden rows, two independent conv/GDN state alternatives and separately owned carry/prior hidden rows.',
        'After original Completion retires, selection precedes state export and append take; ready T2 KV is projected to exact accepted layout. Partial acceptance drops the verified mutable tail, preserves old prefixes and follows existing COW next. Only then do original no-throw head swaps commit.',
        'Immutable snapshot slots remainN+R. Physical state poolsN+2R and carry/prior rows2(N+R) are counted separately; ordinary boundary1 has unchanged backing formula.'],
    mathematics=dict(candidate_result=ident(S / 'probe-run3/run.result.json'), reference_result=ident(S / 'reference-run1/run.result.json'), comparison=math,
                     input_provenance=read(S / 'math-inputs/provenance.json'),
                     scope='One fresh two-row MTP block, last-row logits/ID, original335 loaded tensor bank. Supplied hidden is an arbitrary valid post-norm math input, not a claim of complete prefill alignment or natural speculative generation. CPU reference independent of candidate results. No post-hoc quality tolerance.'),
    target_state=dict(result=ident(S / 'target-run2/run.result.json'), observation=target, independent_review=runtime, source_review=review,
                      scope='C64/N8/R1/boundaries2, supplied targetT2 inputs and injected a1/a2 selection. CrosspageL15 a1/a2 and samepageL16 a1, continuedT1, exact old snapshot/ownedcarry isolation. Numeric differences and equal IDs are descriptive, not quality or natural acceptance evidence.'),
    ordinary_text_regression=ordinary,
    not_completed=[
        'Real MTP prefill shifted hidden/KV catch-up integrated with target prompt in the original graph.',
        'Independent draft KV/frontier/lag and actual catchup token plus target carry/prior hidden in a complete immutable snapshot; fourteen append cleanup/retirement and actual additional MTP KV budget.',
        'One original Graph draft-ID device edge into targetT2, natural accept/reject selection and composite target+MTP commit, EOS/quota/capacity/T1 ownedcarry fallback.',
        'Actual new-path failure/cancellation retirement, emitted-stream quality, natural acceptance, matched real MTP peer performance/memory.',
        'Full three-OS/backend/model/quant architecture and image projection scope.'],
    performance='No new full throughput/memory comparison this batch. Probe timings are diagnostic. Latest ordinary four-metric window remains docs/evidence/performance/qwen-topone-prepared-2026-10-22.json.',
    incidents=[
        'Initial math probe compile omitted mandatory PagedArenaOptions; failed host compile retained. Fixed probe to state its real backing bound16385B.',
        'First actual math process returned exit1 while querying finite-family output ownership before selecting its exact child. Corrected the probe to query the selected executable/report, then actual run succeeded; no provider bypass.',
        'Root review moved the per-request110/72 port overflow/configured capacity guard before reserve. Final consumer/target/math TUs were rebuilt and all related final processes rerun; earlier outputs retained or hash-aliased, not mixed into final results.'])
save(P / f'{STEM}.json', manifest)
save(S / 'published.json', dict(manifest=ident(P / f'{STEM}.json'), archives=archives,
     archive_verified_entries=len(files), archived_bytes=sum(x['bytes'] for x in files),
     superseded_payload_aliases=len(aliases)))
print('PUBLISHED', len(files), 'entries', len(aliases), 'superseded identical payload aliases',
      len(archives), 'volumes', sum(a['bytes'] for a in archives), 'compressed bytes')
