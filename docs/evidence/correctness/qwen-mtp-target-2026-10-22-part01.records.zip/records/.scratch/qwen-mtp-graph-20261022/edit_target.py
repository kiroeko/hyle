from pathlib import Path

R = Path(__file__).resolve().parents[2]
p = R / 'tools/qwen35_text/main.cc'
s = p.read_text(encoding='utf-8')


def replace(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


replace('#include <cmath>', '#include <cmath>\n#include <compare>')
replace('#include "batch_schedule.h"', '#include "batch_schedule.h"\n#include "mtp_graph.h"')
replace('struct StatePorts final {\n  V history, recurrent, next_history, next_recurrent;\n};', '''enum class GraphRole { kText, kVerify };
struct FamilyKey final {
  std::size_t requests;
  GraphRole role;
  FamilyKey(std::size_t count, GraphRole selected = GraphRole::kText) noexcept
      : requests(count), role(selected) {}
  auto operator<=>(const FamilyKey &) const = default;
};
struct ExecutionShape final {
  std::size_t requests, tokens;
  GraphRole role = GraphRole::kText;
  auto operator<=>(const ExecutionShape &) const = default;
};
struct StatePorts final {
  V history, recurrent, next_history, next_recurrent;
  V first_history, first_recurrent; // Verify row0 owns separate material storage.
};''')
replace('  std::vector<V> state_resource_ports;','  std::vector<V> state_resource_ports;\n  std::vector<std::array<V, 2>> carry_ports;')
replace('  std::size_t requests = 1;\n  std::vector<Tensor> literals;', '  std::size_t requests = 1;\n  GraphRole role = GraphRole::kText;\n  std::vector<Tensor> literals;')
replace('  c::BatchLayoutVersion layout;\n};\nstruct StepState', '  c::BatchLayoutVersion layout;\n  std::size_t accepted_tokens = 0;\n  std::uint32_t verified_last_page = 0;\n};\nstruct StepState')
replace('  std::array<cache::StatePools, 24> state_pools;', '  std::array<cache::StatePools, 24> state_pools;\n  c::LeasePool hidden_pool;')
replace('  std::map<std::size_t, std::unique_ptr<Family>> families, probe_families;', '  std::map<FamilyKey, std::unique_ptr<Family>> families, probe_families;')
replace('  using ExecutionShape = std::pair<std::size_t, std::size_t>; // (requests, tokens/request)\n', '')
replace('    snapshot_versions.capacity = cache_plan.state_slots;', '    snapshot_versions.capacity = cache_plan.snapshot_slots;')
replace('    const auto usage = take(cache_budget.usage(memory.ref()));', '''    if (cache_plan.hidden_bytes) hidden_pool = take(c::LeasePool::create(memory.ref(),
        cache_plan.hidden_bytes, {.max_blocks = cache_plan.hidden_slots, .resource_budget = cache_budget}));
    const auto usage = take(cache_budget.usage(memory.ref()));''')
replace('''                      std::size_t requests = 1) {
    auto &selected = diagnostic ? probe_families[requests] : families[requests];''', '''                      std::size_t requests = 1, GraphRole role = GraphRole::kText) {
    if (role == GraphRole::kVerify && (diagnostic || !layer0_probe.empty() ||
        cache_plan.candidate_boundaries != 2 ||
        std::ranges::any_of(planned_chunks, [](auto t) { return t != 2; })))
      throw std::runtime_error("verification requires T2 and two independently budgeted state boundaries");
    auto &selected = diagnostic ? probe_families[{requests, role}] : families[{requests, role}];''')
replace('    definition.requests = requests;\n    definition.state_resource_ports.reserve(72 * requests);', '''    definition.requests = requests; definition.role = role;
    definition.state_resource_ports.reserve((role == GraphRole::kVerify ? 110 : 72) * requests);
    if (role == GraphRole::kVerify) definition.carry_ports.resize(requests);''')
replace('    if (requests != 1) definition.last_ids_port =', '    if (requests != 1 && role == GraphRole::kText) definition.last_ids_port =')
replace('''        for (std::size_t request = 0; request < requests; ++request)
          ports.sequences[request].next_history = r.copy(requests == 1 ? next_history :
              r.slice(next_history, 0, f(static_cast<std::int64_t>(request)), f(1)));''', '''        for (std::size_t request = 0; request < requests; ++request) {
          ports.sequences[request].next_history = r.copy(requests == 1 ? next_history :
              r.slice(next_history, 0, f(static_cast<std::int64_t>(request)), f(1)));
          if (role == GraphRole::kVerify) {
            auto first = r.slice(samples, 1, f(1), f(3));
            if (requests != 1) first = r.slice(first, 0, f(static_cast<std::int64_t>(request)), f(1));
            ports.sequences[request].first_history = r.copy(first);
          }
        }''')
replace('''        auto recurrent = r.op(c::Operation(c::GatedDeltaNet{}),''', '''        auto recurrent = r.op(c::Operation(c::GatedDeltaNet{
            .snapshot_count = role == GraphRole::kVerify ? 2u : 1u}),''')
replace('''             r.spec(state)});
        for (std::size_t request = 0; request < requests; ++request)
          ports.sequences[request].next_recurrent = requests == 1 ? recurrent[1] :
              r.copy(r.slice(recurrent[1], 0, f(static_cast<std::int64_t>(request)), f(1)));''', '''             role == GraphRole::kVerify
                 ? r.dense_spec(Type::kFloat32, {batch, f(2), f(16), f(128), f(128)}) : r.spec(state)});
        for (std::size_t request = 0; request < requests; ++request) {
          if (role == GraphRole::kVerify) {
            auto per_request = r.slice(recurrent[1], 0, f(static_cast<std::int64_t>(request)), f(1));
            ports.sequences[request].first_recurrent = r.copy(r.reshape(
                r.slice(per_request, 1, f(0), f(1)), {f(1), f(16), f(128), f(128)}));
            ports.sequences[request].next_recurrent = r.copy(r.reshape(
                r.slice(per_request, 1, f(1), f(1)), {f(1), f(16), f(128), f(128)}));
          } else ports.sequences[request].next_recurrent = requests == 1 ? recurrent[1] :
              r.copy(r.slice(recurrent[1], 0, f(static_cast<std::int64_t>(request)), f(1)));
        }''')
replace('''          r.publish(sequence.next_history); r.publish(sequence.next_recurrent);
          for (const auto port :''', '''          r.publish(sequence.next_history); r.publish(sequence.next_recurrent);
          if (role == GraphRole::kVerify) {
            r.publish(sequence.first_history); r.publish(sequence.first_recurrent);
            definition.state_resource_ports.push_back(sequence.first_history);
            definition.state_resource_ports.push_back(sequence.first_recurrent);
          }
          for (const auto port :''')
replace('''    auto last = requests == 1 ? r.copy(r.slice(normalized_last, 0, D(r.last_row), f(1))) :
        r.one(c::Gather{}, {normalized_last, definition.last_ids_port},
            r.dense_spec(Type::kBFloat16, {batch, f(hidden)}));''', '''    auto last = role == GraphRole::kVerify ? r.copy(normalized_last) :
        (requests == 1 ? r.copy(r.slice(normalized_last, 0, D(r.last_row), f(1))) :
        r.one(c::Gather{}, {normalized_last, definition.last_ids_port},
            r.dense_spec(Type::kBFloat16, {batch, f(hidden)})));
    if (role == GraphRole::kVerify) for (std::size_t request = 0; request < requests; ++request)
      for (std::size_t row = 0; row < 2; ++row) {
        const auto carry = r.copy(r.slice(normalized_last, 0,
            f(static_cast<std::int64_t>(request * 2 + row)), f(1)));
        definition.carry_ports[request][row] = carry;
        r.publish(carry); definition.state_resource_ports.push_back(carry);
      }''')
replace('''        {r.dense_spec(Type::kFloat32, {batch, f(1)}), r.dense_spec(Type::kInt32, {batch, f(1)})})[1];''', '''        {r.dense_spec(Type::kFloat32, {role == GraphRole::kVerify ? packed : batch, f(1)}),
         r.dense_spec(Type::kInt32, {role == GraphRole::kVerify ? packed : batch, f(1)})})[1];''')
# All normal callers keep the original default role and key shape.
replace('void plan_execution(std::span<const std::size_t> calls, bool either_slot = false, std::size_t requests = 1)', 'void plan_execution(std::span<const std::size_t> calls, bool either_slot = false, std::size_t requests = 1, GraphRole role = GraphRole::kText)')
replace('''      if (!families.contains(requests) || std::find(families.at(requests)->chunks.begin(), families.at(requests)->chunks.end(), tokens) == families.at(requests)->chunks.end())''', '''      if (!families.contains({requests, role}) || std::find(families.at({requests, role})->chunks.begin(), families.at({requests, role})->chunks.end(), tokens) == families.at({requests, role})->chunks.end())''')
replace('      auto &uses = planned_slot_uses[{requests, tokens}];', '      auto &uses = planned_slot_uses[{requests, tokens, role}];')
replace('    if (definition.requests != 1) check(run.bind(phase.last_ids_port, phase.last_ids.read()));', '    if (definition.requests != 1 && definition.role == GraphRole::kText) check(run.bind(phase.last_ids_port, phase.last_ids.read()));')
replace('  Phase &prepare_child(std::size_t tokens, bool diagnostic, std::size_t requests = 1) {', '  Phase &prepare_child(std::size_t tokens, bool diagnostic, std::size_t requests = 1, GraphRole role = GraphRole::kText) {')
replace('    const auto found = cache.find({requests, tokens});', '    const auto found = cache.find({requests, tokens, role});')
replace('    auto &selected = diagnostic ? probe_families[requests] : families[requests];', '    auto &selected = diagnostic ? probe_families[{requests, role}] : families[{requests, role}];')
replace('    phase.planned_slot_uses = planned_slot_uses.at({requests, tokens});', '    phase.planned_slot_uses = planned_slot_uses.at({requests, tokens, role});')
replace('''    if (requests != 1) {
      phase.last_ids = Tensor''', '''    if (requests != 1 && role == GraphRole::kText) {
      phase.last_ids = Tensor''')
replace('cache.emplace(ExecutionShape{requests, tokens}, std::move(result))', 'cache.emplace(ExecutionShape{requests, tokens, role}, std::move(result))')
replace('''                         std::size_t requests = 1) {
    if (carrier_borrowed)''', '''                         std::size_t requests = 1, GraphRole role = GraphRole::kText) {
    if (carrier_borrowed)''')
replace('''      if (!layer0_probe.empty()) prepare_child(tokens, false, requests);
      auto &phase = prepare_child(tokens, !layer0_probe.empty(), requests);''', '''      if (!layer0_probe.empty()) prepare_child(tokens, false, requests, role);
      auto &phase = prepare_child(tokens, !layer0_probe.empty(), requests, role);''')
replace('''                           PreparationObservation *preparation = nullptr) {
    if (requests.empty()''', '''                           PreparationObservation *preparation = nullptr,
                           GraphRole role = GraphRole::kText) {
    if (requests.empty()''')
replace('''      if (!layer0_probe.empty()) prepare_child(tokens, false, width);
      auto &phase = prepare_child(tokens, !layer0_probe.empty(), width);''', '''      if (!layer0_probe.empty()) prepare_child(tokens, false, width, role);
      auto &phase = prepare_child(tokens, !layer0_probe.empty(), width, role);''')
replace('''          check(run.bind(ports.next_recurrent, descriptions.recurrent, std::move(recurrent)));
        }
      std::array<g::batch::NodeLayout, 6> layouts;''', '''          check(run.bind(ports.next_recurrent, descriptions.recurrent, std::move(recurrent)));
          if (role == GraphRole::kVerify) {
            auto first_history = take(state_pools[i].history.allocate(take(descriptions.history.required_bytes())));
            auto first_recurrent = take(state_pools[i].recurrent.allocate(take(descriptions.recurrent.required_bytes())));
            check(run.bind(ports.first_history, descriptions.history, std::move(first_history)));
            check(run.bind(ports.first_recurrent, descriptions.recurrent, std::move(first_recurrent)));
          }
        }
      if (role == GraphRole::kVerify) for (const auto &ports : phase.carry_ports)
        for (const auto port : ports)
          check(run.bind(port, dense(Type::kBFloat16, {1, hidden}), take(hidden_pool.allocate(4096))));
      std::array<g::batch::NodeLayout, 6> layouts;''')
replace('''                          PreparationObservation *preparation = nullptr) {
    const std::array requests{EvaluationRequest{session.shared_from_this(), ids}};
    prepare_evaluations(requests, preparation);''', '''                          PreparationObservation *preparation = nullptr,
                          GraphRole role = GraphRole::kText) {
    const std::array requests{EvaluationRequest{session.shared_from_this(), ids}};
    prepare_evaluations(requests, preparation, role);''')
p.write_text(s, encoding='utf-8')
print('Target verify graph, independent boundary bindings and role-aware cold keys written.')
