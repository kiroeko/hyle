from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
M=Path(__file__).resolve().parent;R=M.parents[1]
sp=importlib.util.spec_from_file_location('build',M/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('mode',choices=('probe','reference','target','r1','batch'));p.add_argument('--attempt',type=int,default=1);a=p.parse_args();out=M/(a.mode+'-run'+str(a.attempt));out.mkdir(exist_ok=False)
env=os.environ.copy()
if a.mode=='reference':
 command=[sys.executable,str(M/'mtp_reference.py'),'--model',r'C:/Users/kiro/Downloads/Qwen3.5-2B','--inputs',str(M/'math-inputs'),'--output',str(M/'reference-output')]
else:
 ready=c.read(M/f'{a.mode if a.mode in("probe","target")else"qwen"}-ready-attempt{4 if a.mode=="probe"else 2}.json');assert b.identity(ready['image']['path'])==ready['image']
 env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
 if a.mode=='probe':command=[ready['image']['path'],str(R/'.scratch/qwen-mtp-weights-20261022/prepared/weights.tsv'),str(M/'math-inputs'),str(M/('math-output'+str(a.attempt)))]
 elif a.mode=='target':command=[ready['image']['path'],'--inputs',str(R/'.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/128-prefill/inputs'),'--output',str(M/('target-output'+str(a.attempt)))]
 else:
  old=c.read(R/'.scratch/qwen-topone-prepared-20261022'/f'{a.mode}-run1/run.command.json');command=old['command'].copy();command[0]=ready['image']['path'];command[command.index('--trace')+1]=str(out/'trace')
 c.save(out/'identity.json',ready)
c.save(out/'plan.json',dict(command=command,throughput_evidence=False))
c.execute('run',command,env,out)
