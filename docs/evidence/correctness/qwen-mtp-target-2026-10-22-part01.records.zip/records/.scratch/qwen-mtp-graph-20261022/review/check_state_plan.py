"""Arithmetic/source self-check only; does not compile or claim a C++ run."""
from pathlib import Path
import difflib
import hashlib
import json

R = Path(__file__).resolve().parents[3]
S = Path(__file__).resolve().parent.parent
source = R / "tools/qwen35_text/session_state.h"
before = S / "before/tools/qwen35_text/session_state.h"
old = before.read_text(encoding="utf-8")
new = source.read_text(encoding="utf-8")
assert "std::size_t candidate_boundaries = 1" in new
assert "snapshot_slots = 0, candidate_boundaries = 1, hidden_slots = 0" in new
assert "c::ReadLease carry_hidden, prior_hidden;" in new
assert "candidate_boundaries != 1 && candidate_boundaries != 2" in new
assert "multiply(recurrent_payload, result.state_slots)" in new
assert "snapshot_slots" not in old

U64 = (1 << 64) - 1
U32 = (1 << 32) - 1
I32 = (1 << 31) - 1
payload = 18 * (1 * 3 * 6144 * 2 + 1 * 16 * 128 * 128 * 4)
assert payload == 19537920


def checked(value):
    if not 0 <= value <= U64:
        raise OverflowError("size_t")
    return value


def formula(c, n, t, r, b):
    if not c or not n or not t or t > c or not r or r > n or b not in (1, 2):
        raise ValueError("plan domain")
    refs = checked(c + 15) // 16
    pages = checked(checked(refs * n) + r)
    snapshots = checked(n + r)
    states = checked(n + checked(b * r))
    hidden = checked(2 * snapshots) if b == 2 else 0
    if r >= I32 or pages > I32 or checked(refs * r) > I32 or checked(t * r) > I32 or checked(c * r) > I32 or states > U32 or hidden > U32:
        raise OverflowError("index capacity")
    bank = checked(checked(checked(pages * 16) * 1024) + 1)
    hidden_bytes = checked(checked(4096 * hidden) + 1) if hidden else 0
    backing = checked(checked(checked(bank * 12) + checked(checked(payload * states) + 36)) + hidden_bytes)
    return dict(snapshot_slots=snapshots, state_slots=states, candidate_boundaries=b,
                hidden_slots=hidden, hidden_bytes=hidden_bytes, bank_bytes=bank,
                backing_bytes=backing)


cases = []
for c, n, t, r in ((256, 1, 128, 1), (1024, 2, 256, 2),
                   (1024, 4, 256, 2), (17, 4, 2, 1), (1, 1, 1, 1)):
    first, second = formula(c, n, t, r, 1), formula(c, n, t, r, 2)
    legacy_pages = n * ((c + 15) // 16) + r
    legacy = 12 * (legacy_pages * 16 * 1024 + 1) + payload * (n + r) + 36
    assert first["backing_bytes"] == legacy
    assert first["state_slots"] == first["snapshot_slots"] == n + r
    assert first["hidden_slots"] == first["hidden_bytes"] == 0
    assert second["snapshot_slots"] == n + r
    assert second["state_slots"] == n + 2 * r
    assert second["hidden_slots"] == 2 * (n + r)
    assert second["hidden_bytes"] == 4096 * 2 * (n + r) + 1
    assert second["bank_bytes"] == first["bank_bytes"]
    assert second["backing_bytes"] - first["backing_bytes"] == payload * r + second["hidden_bytes"]
    cases.append(dict(inputs=dict(context=c, residents=n, query_rows=t, active_sequences=r),
                      default=first, verify_two=second, default_matches_legacy=True))
assert cases[0]["default"]["backing_bytes"] == 42418224
assert cases[1]["default"]["backing_bytes"] == 103710768

rejected = []
for args in ((1024, 2, 2, 1, 0), (1024, 2, 2, 1, 3),
             (1024, 2, 2, 3, 2), (1, U64, 1, 1, 2),
             (1, U32 // 2 + 1, 1, 1, 2)):
    try:
        formula(*args)
    except (ValueError, OverflowError) as error:
        rejected.append(dict(inputs=args, rejected_as=str(error)))
    else:
        raise AssertionError(("invalid plan accepted", args))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


current = S / "current/tools/qwen35_text/session_state.h"
current.parent.mkdir(parents=True, exist_ok=True)
current.write_bytes(source.read_bytes())
diff = S / "review/session-state.diff"
diff.write_text("".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                   fromfile="before/tools/qwen35_text/session_state.h",
                   tofile="tools/qwen35_text/session_state.h")), encoding="utf-8")
report = dict(status="PASS bounded arithmetic/source checks; no C++ build or native run",
              source=identity(source), before=identity(before), cases=cases,
              selfcheck_setup_correction="Initial Python check paired the retained42418224B probe reference with C1024; that reference uses C256. Corrected the self-check fixture to C256, not the product formula or reference value.",
              rejected=rejected, pool_sentinels=dict(target_kv=12, conv_gdn=36,
                    optional_hidden=1),
              limits=["Python checks the explicit arithmetic contract and representative legacy values; root must compile actual header and verify real allocation/admission.",
                      "No MTP draft KV schema/backing, target Graph output or consumer admission was implemented here."])
out = S / "review/state-plan-selfcheck.json"
out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
freeze = dict(source=identity(source), before=identity(before), current=identity(current),
              diff=identity(diff), selfcheck=identity(out), build=False, gpu=False,
              stopped_writing=True,
              interface="plan(context,residents,maxT,recurrent_payload,R=1,candidate_boundaries=1); Plan.state_slots physical pools; Plan.snapshot_slots immutable version quota")
(S / "review/state-source-freeze.json").write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
print(json.dumps(freeze, indent=2))
