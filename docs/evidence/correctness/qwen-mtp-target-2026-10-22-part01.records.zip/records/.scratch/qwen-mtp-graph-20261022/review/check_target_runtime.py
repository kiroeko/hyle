"""Offline raw-byte/float64 recomputation of the final target-only T2 probe."""
from pathlib import Path
import collections
import hashlib
import json
import math
import numpy as np

S = Path(__file__).resolve().parent.parent
R = S.parents[1]
output = S / "target-output2"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def values(data, dtype):
    if dtype == "BF16":
        return (np.frombuffer(data, dtype="<u2").astype(np.uint32) << 16).view(np.float32).astype(np.float64)
    assert dtype == "F32"
    return np.frombuffer(data, dtype="<f4").astype(np.float64)


def relative(sse, reference):
    return math.sqrt(sse / reference) if reference else (0.0 if not sse else None)


def main():
    run = read(S / "target-run2/run.result.json")
    ready = read(S / "target-ready-attempt2.json")
    actual_identity = read(S / "target-run2/identity.json")
    observation = read(output / "observation.json")
    assert run["exit"] == 0 and run["terminal"] is True
    assert run["command"][0] == ready["image"]["path"]
    assert run["command"][-2:] == ["--output", str(output)]
    assert actual_identity == ready
    assert identity(Path(ready["source"]["path"]))["sha256"] == ready["source"]["sha256"]
    assert observation["status"].startswith("PASS") and not observation["error"]
    assert observation["numeric_tolerance"] is observation["natural_acceptance_rate"] is None
    assert observation["numeric_acceptance"] is False and observation["injected_acceptance"] is True
    assert observation["capacity"] == 64 and observation["residents"] == 8
    assert observation["active_sequences"] == 1 and observation["candidate_boundaries"] == 2
    assert len(observation["metrics"]) == 228 and len(observation["steps"]) == 12
    for flag in ("old_base_unchanged", "old_row16_unchanged", "independent_carry_survived_carrier_replay",
                 "all_compared_vectors_finite"):
        assert observation[flag] is True

    layers = [i for i in range(24) if i % 4 != 3]
    expected_files = {"hidden.bf16": ("BF16", 4096, [1, 2048]),
                      "logits.f32": ("F32", 993280, [1, 248320])}
    for layer in layers:
        expected_files[f"layer{layer}.conv.bf16"] = ("BF16", 36864, [1, 3, 6144])
        expected_files[f"layer{layer}.gdn.f32"] = ("F32", 1048576, [1, 16, 128, 128])
    groups = collections.defaultdict(list)
    digest = hashlib.sha256()
    pair_bytes = 0
    max_scalar_sum_disagreement = 0.0
    for old in observation["metrics"]:
        pair, filename = old["name"].split("/", 1)
        dtype, extent, shape = expected_files[filename]
        a_path, b_path = Path(old["reference"]), Path(old["actual"])
        assert a_path.is_relative_to(output) and b_path.is_relative_to(output)
        assert a_path.name == b_path.name == filename
        a, b = a_path.read_bytes(), b_path.read_bytes()
        assert len(a) == len(b) == extent == old["bytes"]
        assert old["dtype"] == dtype
        x, y = values(a, dtype), values(b, dtype)
        assert x.size == y.size == math.prod(shape) == old["elements"]
        bad_x, bad_y = int(np.count_nonzero(~np.isfinite(x))), int(np.count_nonzero(~np.isfinite(y)))
        assert bad_x == old["nonfinite_reference"] == 0 and bad_y == old["nonfinite_actual"] == 0
        delta = y - x
        maximum, sse, ref_squared = float(np.max(np.abs(delta))), float(np.sum(delta * delta)), float(np.sum(x * x))
        assert (a == b) == old["byte_equal"] and maximum == old["max_abs"]
        # This tolerance compares float64 SUM implementations only; it is not
        # a model-output tolerance or numeric-quality acceptance.
        for derived, recorded in ((sse, old["squared_error"]), (ref_squared, old["reference_squared"])):
            assert math.isclose(derived, recorded, rel_tol=2e-12, abs_tol=1e-13), (old["name"], derived, recorded)
            max_scalar_sum_disagreement = max(max_scalar_sum_disagreement, abs(derived - recorded))
        groups[pair].append(dict(file=filename, shape=shape, dtype=dtype, bytes=extent,
                                 byte_equal=a == b, max_abs=maximum, squared_error=sse,
                                 reference_squared=ref_squared, RL2=relative(sse, ref_squared)))
        for path, data in ((a_path, a), (b_path, b)):
            digest.update(str(path.relative_to(output)).encode())
            digest.update(hashlib.sha256(data).digest())
        pair_bytes += len(a) + len(b)
    assert len(groups) == 6 and all({m["file"] for m in group} == set(expected_files) for group in groups.values())

    steps = {x["name"]: x for x in observation["steps"]}
    selection = []
    for name, step in steps.items():
        length = step["base_length"] + step["accepted_rows"]
        assert step["visible_tokens"] == length and step["pages"] == (length + 15) // 16
        directory = output / "trace" / name
        nrows = 2 if step["injected_acceptance"] else 1
        hidden = (directory / "all-hidden.bf16").read_bytes()
        logits = (directory / "all-logits.f32").read_bytes()
        assert len(hidden) == nrows * 4096 and len(logits) == nrows * 993280
        assert np.isfinite(values(hidden, "BF16")).all() and np.isfinite(values(logits, "F32")).all()
        row = step["accepted_rows"] - 1 if step["injected_acceptance"] else 0
        assert (directory / "hidden.bf16").read_bytes() == hidden[row * 4096:(row + 1) * 4096]
        assert (directory / "logits.f32").read_bytes() == logits[row * 993280:(row + 1) * 993280]
        raw_ids = [int(np.argmax(values(logits[i * 993280:(i + 1) * 993280], "F32"))) for i in range(nrows)]
        assert raw_ids == step["target_ids"][:nrows]
        assert step["next_id"] == raw_ids[row]
        if step["injected_acceptance"]:
            assert step["verified_rows"] == 2 and step["accepted_rows"] in (1, 2)
            assert step["carry_independent"] and step["carry_equals_selected_row"]
            assert (directory / "carry.bf16").read_bytes() == hidden[row * 4096:(row + 1) * 4096]
            prior = directory / "prior.bf16"
            assert prior.exists() == (step["accepted_rows"] == 2)
            if prior.exists():
                assert prior.read_bytes() == hidden[:4096]
            selection.append(dict(name=name, actual_target_argmax_ids=raw_ids,
                                  accepted=step["accepted_rows"], selected_row=row,
                                  visible_tokens=length, pages=step["pages"],
                                  carry_exact_selected_row=True, prior_exact_row0=prior.exists()))

    summaries = []
    for pair, vectors in groups.items():
        left, right = pair.split("_vs_", 1)
        a, b = steps[left], steps[right]
        assert a["visible_tokens"] == b["visible_tokens"] and a["pages"] == b["pages"]
        categories = {}
        for category in ("hidden", "logits", "conv", "gdn"):
            selected = [v for v in vectors if (v["file"].startswith(category) if category in ("hidden", "logits") else "." + category + "." in v["file"])]
            assert len(selected) == (1 if category in ("hidden", "logits") else 18)
            sse = sum(v["squared_error"] for v in selected)
            ref = sum(v["reference_squared"] for v in selected)
            worst = max(selected, key=lambda v: v["RL2"])
            categories[category] = dict(vectors=len(selected), byte_equal=sum(v["byte_equal"] for v in selected),
                                        max_abs=max(v["max_abs"] for v in selected),
                                        concatenated_RL2=relative(sse, ref), max_vector_RL2=worst["RL2"],
                                        worst_RL2_vector=worst["file"])
        earliest = next((v["file"] for v in vectors if v["file"].startswith("layer") and not v["byte_equal"]), None)
        summaries.append(dict(pair=pair, vectors=38, byte_equal=sum(v["byte_equal"] for v in vectors),
                              reference_next_id=a["next_id"], target_next_id=b["next_id"],
                              ids_equal=a["next_id"] == b["next_id"], accepted_rows=b["accepted_rows"],
                              verified_rows=b["verified_rows"], base_length=b["base_length"],
                              visible_tokens=b["visible_tokens"], pages=b["pages"],
                              first_different_recurrent_vector=earliest, categories=categories))
    assert steps["verify_a1_crosspage"]["visible_tokens"] == 16 and steps["verify_a1_crosspage"]["pages"] == 1
    assert steps["verify_a1_samepage"]["base_length"] == 16 and steps["verify_a1_samepage"]["visible_tokens"] == 17
    source = Path(ready["source"]["path"]).read_text(encoding="utf-8")
    for guard in ('require(!tail.valid()', 'old_base_unchanged = unchanged(base)',
                  'old_row16_unchanged = unchanged(row16)', 'carry_survived_replay = bytes(old_carry) == old_carry_bytes',
                  '"selected carry aliases reusable IO or differs from selected target row"'):
        assert guard in source
    report = dict(
        status="PASS offline verification of final raw statistics and exercised structural checks; numerical/model quality not accepted",
        run=identity(S / "target-run2/run.result.json"), ready=identity(S / "target-ready-attempt2.json"),
        image=ready["image"], probe_source=ready["source"], compiled_main=ready["main"],
        observation=identity(output / "observation.json"), checker=identity(Path(__file__)), numpy=np.__version__,
        raw_verification=dict(vector_pairs=228, all_declared_dtypes_shapes_extents_finite_values_verified=True,
                              raw_pair_bytes_read=pair_bytes, ordered_path_and_SHA256_digest=digest.hexdigest(),
                              byte_equal=sum(x["byte_equal"] for group in groups.values() for x in group),
                              unequal=sum(not x["byte_equal"] for group in groups.values() for x in group),
                              max_abs_and_all_recorded_metric_fields_recomputed=True,
                              float64_sum_comparison_rel_tolerance=2e-12,
                              max_absolute_float64_sum_disagreement=max_scalar_sum_disagreement),
        six_groups=summaries, actual_selection_copy_checks=selection,
        physical_structural_coverage=dict(
            actual_exit0_and_frozen_probe_guards=True,
            old15_and_old16_complete_page_state_hidden_snapshots_byte_unchanged=True,
            partial_accept_all12_tail_capabilities_invalid_at_runtime=True,
            selected_frame_has_exact_length_and_page_guard_inventory_at_runtime=True,
            independent_carry_survives_later_carrier_reuse_at_runtime=True,
            offline_raw_selected_hidden_logits_and_carry_rows_exact=True,
            managed_state_backing_bytes=observation["managed_state_backing_bytes"],
            proof_boundary="Old snapshot bytes, exact original guards and pointer nonoverlap are runtime require checks tied to exit0 source/image; the dead process cannot be re-inspected offline. Raw persisted copies independently verify chosen row content, not physical ownership."),
        limits=[
            "Only final target-run2/target-output2 are reviewed; superseded run1 is not pooled or treated as current.",
            "All six selected greedy IDs match their ordinary baselines on these actual inputs, but many raw vectors differ. No T1/T2 error tolerance, full-model quality acceptance or all-domain output-equivalence follows.",
            "Acceptance1/2 is injected by callback. There is no actual draft proposal, natural acceptance-rate observation, throughput measurement or cancellation test in this target-only probe.",
            "RL2 is sqrt(sum((actual-reference)^2)/sum(reference^2)); concatenated state categories combine18matching layer vectors only. No cutoff was imposed. Float64 accumulation comparison tolerance validates recomputation arithmetic, not model values.",
            "Ordinary R1/B2 final90byteexact check is owned by the existing root report and was not repeated here.",
        ])
    destination = S / "review/target-runtime-review.json"
    destination.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(dict(report=identity(destination), byte_equal=report["raw_verification"]["byte_equal"],
                         unequal=report["raw_verification"]["unequal"],
                         groups=[dict(pair=g["pair"], id=g["target_next_id"], id_equal=g["ids_equal"],
                                      visible=g["visible_tokens"], pages=g["pages"], byte_equal=g["byte_equal"],
                                      hidden_RL2=g["categories"]["hidden"]["concatenated_RL2"],
                                      logits_RL2=g["categories"]["logits"]["concatenated_RL2"],
                                      max_conv_RL2=g["categories"]["conv"]["max_vector_RL2"],
                                      max_gdn_RL2=g["categories"]["gdn"]["max_vector_RL2"]) for g in summaries]), indent=2))


if __name__ == "__main__":
    main()
