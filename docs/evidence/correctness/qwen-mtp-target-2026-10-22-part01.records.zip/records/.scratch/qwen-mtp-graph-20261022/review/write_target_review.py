"""Freeze the narrow target-state implementation review; filesystem work only."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parents[3]
S = Path(__file__).resolve().parent


def source(relative, copy=False):
    path = R / relative
    data = path.read_bytes()
    result = dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    if copy:
        dest = S / "source" / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        result["review_snapshot"] = str(dest.relative_to(R))
    return result


report = {
    "status": "Bounded read-only implementation advice. No product edit, compile or GPU run; the target T2 complete-state slice is not yet a runtime result.",
    "sources": [source(p, True) for p in (
        "tools/qwen35_text/main.cc", "tools/qwen35_text/session_state.h")],
    "mechanism_sources": [source(p) for p in (
        "include/hyle/compute/operation.h", "src/compute_provider_ggml_cuda/tensor_program.cc",
        "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc", "src/graph_batch/paged_append.cc",
        "src/compute_batch/paged_arena.cc")],
    "retained_plan": source(".scratch/qwen-batch-profile-20261022/review/mtp-next-implementation.json"),
    "minimal_target_slice": [
        {
            "owner": "Family/Ports/Phase keys and target output selection",
            "existing": "main.cc FamilyPorts:418-454; prepare_family:934-947,1066-1085; prepare_child:1232-1267; initialize_slot:1208-1228",
            "change": "Add a small consumer-private target output/checkpoint mode to the existing family/child/Phase key and planned-use key. Ordinary last-row mode stays its current shape. All-row mode exposes normalized_last [R*T,2048], applies the original tied LM head to every row and TopK1 to [R*T,248320], producing IDs [R*T,1]. Verify-two additionally fixes T=2 and requests two recurrent/conv checkpoints. Do not select last_ids_port in all-row mode or alias an ordinary T2 Phase with a verify T2 Phase.",
            "details": [
                "Packed row order is request-major: request j token u is j*T+u. Read and validate2R IDs at completion for verify, not current oneID/request buffer span. Row0 is target correction/check; row1 is bonus. Neither is the already-returned pending input token.",
                "All-row prefill and verify-two have different checkpoint requirements. Never compile snapshot_count2 for a T1 finite child; the public contract requires snapshot_count<=T. A bounded role/output mode prevents accidental family cross-binding, without another executor or public model-specific operator.",
                "initialize_slot must bind according to the selected child's actual output descriptions, not ordinary[R,1] assumptions. Create and bind all added per-episode output writers before batch prepare/replay, along the original try/abort cleanup. Publish only the fully bound Invocation as currently done.",
                "Keep original normalization, BF16/F32 boundaries and all downstream math. Parent's previous TopK1 capability patch permits the all-row wide greedy operation to remain Prepared/capturable; exact selection still comes from the compiled provider report.",
            ],
        },
        {
            "owner": "18 recurrent layers: two chronological output alternatives",
            "existing": "main.cc:981-1007,1022-1025; operation.h:427-444; tensor_program.cc:1116-1163; ggml_cuda_provider.cc:1504-1518",
            "change": "For verifyT2 use GatedDeltaNet{snapshot_count=2}; declare state output[R,2,16,128,128]. For every request and boundary a in{1,2}, slice request axis0 and checkpoint axis1(a-1), reshape to the original[1,16,128,128] state_schema, THEN material Copy and publish. For conv samples[R,5,6144], select three-row histories with starts a=1 and a=2, slice the request, reshape to original[1,3,6144] before material Copy. Bind both alternatives to distinct state-pool writers.",
            "details": [
                "GDN output order is already publicly chronological. Existing CUDA adapter cold snapshot_order maps native packed reverse/token-major order to public[B,K,...]. Use public descriptor indexing, never private native offsets or reversed assumptions.",
                "A chosen ReadLease subview into a packed two-state output still retains its entire root allocation. Independent one-state material output roots are required if dropping the unselected alternative should return one actual pool block. A view alone does not save backing space.",
                "Current state_resource_ports collects2inputs+2outputs per layer/request=72R ports. Verify uses2inputs+4outputs=108R before added carry outputs. Include every new leased output in unbind; adjust reserve/overflow arithmetic when changing these counts.",
            ],
        },
        {
            "owner": "Independent target hidden carry ownership",
            "existing": "main.cc:156-170 Tensor and1066-1075/1220-1222/1265-1267 fixed IO; session_state.h:171-183 Snapshot",
            "change": "Keep reusable all-hidden/logits/ID Phase buffers as transient execution IO, but give each continuation checkpoint its own material BF16 [1,2048] carry output, bound to an owned pool WriteLease and exported as ReadLease into the selected Snapshot. For verify slice j*T+(a-1) from normalized all-hidden, then Copy to the independent row. Add this output to state_resource_ports. Do not store Phase.final_hidden, a ConstTensorView, or a subview of its raw reusable Buffer as persistent carry.",
            "details": [
                "First slice needs one carry row per committed target head and two candidate output rows per active request. A complete later MTP head may also retain row0 as lag1 catch-up hidden while carry is row1; account for those distinct actual roots and publish them with the same target/draft head.",
                "Empty initial snapshots have no actual target carry. Nonempty prefix adoption is valid for MTP only when the prefix also owns the chosen carry and complete draft frontier/state; the existing model/math check alone does not fabricate these missing members.",
                "Bounded primary-source check: local C:/public/project-hyle/llama.cpp/src/models/qwen35.cpp:208-216 sets t_h_nextn after model.output_norm and before output-row cropping. This supports using normalized_last's all rows as the target hidden tap in the retained design; it is structural alignment, not cross-engine bit-identity proof.",
            ],
        },
    ],
    "finish_order_and_projection": {
        "existing": "main.cc:1575-1649; PagedAppendPages::ready:222-235; PagedArena::reframe_impl:266-337",
        "required_order": [
            "Wait the original wholeGraph Completion and release its public observer as now. Before the FIRST take_append, export every request's BOTH conv/GDN alternatives and owned hidden rows via run.result(...).storage_lease(), plus all verify IDs/probe results needed for the decision. The existing first-take output-readiness revocation is real; exporting one alternative after take is too late.",
            "Determine each request's selected a=1 or2 and its complete next length/base+ a, next_id row(a-1), recurrent36 leases and carry row(a-1). Allocate/validate fallible host metadata before no-throw head commit. Keep unselected material roots owned until original retirement/export cleanup permits release.",
            "Take each original append and call ready only after wholeGraph success. Those calls publish the ACTUAL verified two-row physical frontier. Build exact per-request accepted layout at length base+a, call each of12arena.reframe from the ready verify frame, and trim candidate PageRef inventory to ceil((base+a)/16). Query indptr can describe that exact accepted row count; next prepare uses ready history authority, not fabricated longer length.",
            "For a<2, drop all returned mutable tail capabilities for that request. Do not rollback an already published physical frontier. A reframe is a restricted read projection, not undo. Next append must COW if frontier exceeds chosen logical prefix, even if the same physical last page still contains both verified rows.",
            "For a==2, original tail frontier validation and move-back can apply. In mixed batches associate returned tail by original verified footprint before trimming accepted refs. Current final-tail loop uses final pages.back and would throw for legal rejection (samepage initialized_rows mismatch or oldL15 crossing creates an appender outside the shorter final footprint). It must explicitly handle partialaccept drops before that lookup.",
            "Unbind all old input and all alternative output state/carry ports, releasing Graph-held owners/native imports before freeing unselected blocks. Validate unchanged expected base/pending/stopping for every member, then do one nonthrowing composite head/tail/position/nextID/carry swap. No publish-then-undo, per-layer host copies or T1 recomputation substitutes.",
        ],
    },
    "physical_budget": {
        "existing": "session_state.h:30-73; main.cc:881-912,1123-1127,1439,1510-1519",
        "exact_current_payload": {"gdn_bytes_per_layer": 1048576, "conv_bytes_per_layer": 36864,
                                  "layers": 18, "complete_recurrent_payload_per_snapshot": 19537920,
                                  "bf16_hidden_row_bytes": 4096},
        "change": [
            "Split the currently conflated Plan.state_slots roles. Distinct immutable Snapshot VersionCount may stay N+R when each request reserves one final next object and keeps two alternative state sets as temporary fields. Recurrent history/recurrent pools need N+2R blocks so both alternatives coexist with N retained complete versions. Their actual backing uses payload*(N+2R)+36sentinel bytes; preserve separate aggregate pre-reserve and per-real-root pool accounting.",
            "Target-only carry pool needs N+2R independent4096B rows plus its own sentinel. For complete MTP if every retained committed version can own BOTH carry and lag1 catchup hidden, worst case is2N+2R rows, not N+2R. A root-sharing optimization must prove which row owners actually alias; logical row count alone cannot undercharge.",
            "The target KV pages continue to use one verified candidate mapping per request, then readonly accepted projection; no need to allocate separate KV candidates for a1/a2. Existing max_pages=N*ceil(C/16)+R remains the target-only bound when verified L+2<=C. A second one-layer draft KV arena pair needs its own independently charged pages/frontier and retained source heads, not hidden use of the12targetbanks.",
            "All-logits per R*T costs4*248320*R*T bytes and all-hidden2*2048*R*T in transient IO; the GDN two-checkpoint internal workspace/materialization is additional to exported state pools. Keep these owned by the existing Phase/Graph workspace accounting, not reported as zero or silently charged to the precise already-full state cache budget.",
        ],
    },
    "failure_and_retirement": {
        "existing": "main.cc StepState::try_abort:494-552/abort:555-560; prepare_evaluations:1374-1548; finish:1591-1650",
        "requirements": [
            "All new alternative state/carry writers and candidate frames must stay under the same original active_step admission and original Completion. A failure/stop cancels the whole participating batch; no candidate head is visible before complete success and selected-state validation.",
            "Original completion poll/drop and run.in_flight/take_append gates are independent. Never release candidate charges or native backing merely because a public Completion was dropped, cancelled or returned error. Retain new fields through the same actual-retirement gates.",
            "Abort may rollback only still-reserved appenders. Successfully ready/published tails cannot be rewound; on later host allocation/reframe/unbind failure drop their authority and preserve old immutable head. Original unselected/source ReadLeases retain old bytes and next attempt COWs from the old logical frontier.",
            "Keep strong Session/base pins and candidate ownership until every failed output/append has actually retired and the original slot is reset/unbound/destroyed. StepState reset must release newly added checkpoint/carry fields too; do not return serial carrier while any alternative root or result read still relies on its IO.",
        ],
    },
    "first_deliverable": "One real target verifyT2 graph using unchanged target weights/math, two greedy target IDs, all target hidden rows and independent selectable full-state alternatives; selecta1/a2 with exact KV reframe and continuation. Preserve ordinary last-row path in the same Model roles, original lifecycle and shared carriers. Real draft/MTP graph, sampling/lag, autonomous acceptance and performance are separate subsequent work, not proven by this target slice.",
    "minimal_actual_checks_for_root": [
        "TargetT2 R1 and R2 compile/run with material output identity assertions and both public chronological state alternatives; check IDs/hidden/state against an independent chosen reference with raw differences retained. Legal T2-vs-twoT1 BF16 changes must not be silently relaxed into bit-equivalence.",
        "Selecta1 at oldlength15 (verified second token crosses page), then continue from selected frame/state; selecta2 in samepage and crossing page; keep old complete snapshot readable. The first is the shortest direct regression for final-tail-loop rejection.",
        "Reuse the existing true blockedQueue/dropCompletion cancellation proof with the added two state/carry candidates and actual physical budget. No new failure-injection matrix or second executor is needed.",
    ],
}
out = S / "target-state-review.json"
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(dict(path=str(out), bytes=out.stat().st_size,
                     sha256=hashlib.sha256(out.read_bytes()).hexdigest()), indent=2))
