"""Offline comparison of only the eight published MTP mathematical outputs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


STAGE = Path(__file__).resolve().parents[1]


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def identity(path, data=None):
    if data is None:
        data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def floats(data, dtype):
    if dtype == "BF16":
        words = np.frombuffer(data, dtype="<u2").astype(np.uint32) << 16
        return words.view(np.float32).astype(np.float64)
    return np.frombuffer(data, dtype="<f4" if dtype == "F32" else "<i4").astype(np.float64)


def metrics(actual, expected, dtype):
    a, r = floats(actual, dtype), floats(expected, dtype)
    assert a.shape == r.shape
    finite_a, finite_r = bool(np.isfinite(a).all()), bool(np.isfinite(r).all())
    if not finite_a or not finite_r:
        raise ValueError("non-finite published comparison output")
    delta = a - r
    an, rn = float(np.linalg.norm(a)), float(np.linalg.norm(r))
    result = dict(elements=int(a.size), candidate_finite=finite_a,
                  reference_finite=finite_r, byte_equal=actual == expected,
                  different_numeric_elements=int(np.count_nonzero(a != r)),
                  max_absolute_error=float(np.abs(delta).max()),
                  relative_l2=float(np.linalg.norm(delta) / rn) if rn else None,
                  cosine=float(np.dot(a, r) / (an * rn)) if an and rn else None)
    return result, a, r


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=STAGE / "math-output3")
    parser.add_argument("--reference", type=Path, default=STAGE / "reference-output")
    parser.add_argument("--run", type=Path, default=STAGE / "probe-run3")
    parser.add_argument("--ready", type=Path, default=STAGE / "probe-ready-attempt4.json")
    parser.add_argument("--output", type=Path, default=STAGE / "review/mtp-math-comparison.json")
    args = parser.parse_args()
    terminal = read_json(args.run / "run.result.json")
    ready = read_json(args.ready)
    reference_report = read_json(args.reference / "report.json")
    reference_terminal = read_json(STAGE / "reference-run1/run.result.json")
    assert terminal["terminal"] and terminal["exit"] == 0
    assert reference_terminal["terminal"] and reference_terminal["exit"] == 0
    assert Path(terminal["command"][0]).resolve() == Path(ready["image"]["path"]).resolve()
    assert Path(terminal["command"][3]).resolve() == args.candidate.resolve()
    inputs = Path(terminal["command"][2])
    for entry in reference_report["inputs"]:
        p = inputs / Path(entry["path"]).name
        assert identity(p)["sha256"] == entry["sha256"]
    provenance = read_json(inputs / "provenance.json")
    hidden = (inputs / "hidden.bf16").read_bytes()
    assert len(hidden) == 8192 and hidden[:4096] == bytes(4096)
    assert hashlib.sha256(hidden[4096:]).hexdigest() == provenance["hidden_source"]["sha256"]
    assert reference_report["prior_rows"] == 0 and reference_report["positions"] == [0, 1]

    # (candidate filename, reference boundary, dtype, complete reference rows,
    #  expected candidate elements). Only the last row is selected for head IO.
    boundaries = [
        ("fc.bf16", "fc", "BF16", True, 4096),
        ("attn_input_norm.bf16", "attn_input_norm", "BF16", True, 4096),
        ("key_rotary.bf16", "key_rotary", "BF16", True, 1024),
        ("value_projection.bf16", "value_projection", "BF16", True, 1024),
        ("final_norm.bf16", "final_norm", "BF16", True, 4096),
        ("selected_hidden.bf16", "final_norm", "BF16", False, 2048),
        ("logits.f32", "logits", "F32", False, 248320),
        ("greedy_ids.i32", "greedy_ids", "I32", False, 1),
    ]
    rows = []
    cache = {}
    for filename, ref_name, dtype, full, elements in boundaries:
        candidate_path = args.candidate / filename
        ref_entry = reference_report["artifacts"][ref_name]
        reference_path = args.reference / Path(ref_entry["path"]).name
        a, original = candidate_path.read_bytes(), reference_path.read_bytes()
        assert identity(reference_path, original)["sha256"] == ref_entry["sha256"]
        r = original if full else original[len(original) // 2:]
        assert len(a) == len(r) == elements * (2 if dtype == "BF16" else 4)
        result, av, rv = metrics(a, r, dtype)
        rows.append(dict(boundary=filename, dtype=dtype,
                         candidate=identity(candidate_path, a),
                         reference=identity(reference_path, original),
                         reference_selection="all two rows" if full else "row1 only",
                         **result))
        cache[filename] = (a, r, av, rv)
    assert cache["selected_hidden.bf16"][0] == cache["final_norm.bf16"][0][4096:]
    logits_a, logits_r = cache["logits.f32"][2:]
    ids_a, ids_r = cache["greedy_ids.i32"][2:]
    ca, ra = int(np.argmax(logits_a)), int(np.argmax(logits_r))
    assert ids_a.tolist() == [ca] and ids_r.tolist() == [ra]
    assert [ra] == reference_report["greedy_ids"][-1:]

    report = dict(
        status="Eight final published boundaries compared; no tolerance/quality decision assigned",
        candidate_run=identity(args.run / "run.result.json"),
        candidate_stdout=read_json(args.run / "run.stdout.log"),
        candidate_ready=identity(args.ready), candidate_image=ready["image"],
        compiled_main=ready["main"], probe_source=ready["source"],
        reference_run=identity(STAGE / "reference-run1/run.result.json"),
        reference_report=identity(args.reference / "report.json"),
        reference_script=reference_report["script"], checker=identity(Path(__file__)),
        input_provenance=dict(record=identity(inputs / "provenance.json"), contents=provenance,
                              tokens=reference_report["tokens"], positions=reference_report["positions"],
                              prior_rows=0, candidate_and_reference_input_hashes_equal=True,
                              zero_first_hidden_row=True, second_hidden_hash_matches_archived_target_row=True),
        formula=dict(relative_l2="norm(candidate-reference)/norm(reference), F64 analysis",
                     cosine="dot(candidate,reference)/(norm(candidate)*norm(reference)), F64 analysis",
                     zero_norm="null (undefined) rather than a fabricated finite result"),
        boundaries=rows,
        greedy=dict(candidate=ca, reference=ra, equal=ca == ra,
                    each_matches_own_first_argmax=True,
                    candidate_selected_hidden_equals_last_final_norm=True),
        observations=[
            "All eight published outputs are finite. Only greedy_ids is byte-equal to CPU reference.",
            "The earliest exposed mismatch is fc (8/4096 values). Final outputs differ numerically; this report neither declares tolerance PASS nor attributes unobserved intermediate errors.",
            "Candidate publishes only last-row hidden/logits/ID; matching reference row1 is selected explicitly. Two-row KV/projection/final-norm outputs are compared in full.",
        ],
        limits=[
            "Inputs are arbitrary valid block-math inputs: zero row and an unrelated real target-normalized hidden row, not the target h0 for these tokens/positions.",
            "This is not complete MTP prefill/catch-up, verify/accept/reject generation, natural acceptance-rate, full quality or speed evidence.",
            "No extra44-boundary candidate publication, GPU run, build, product/reference edit, or post-hoc tolerance was introduced.",
        ], activity=dict(GPU_runs=0, builds=0, product_edits=0, reference_edits=0))
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(dict(report=identity(args.output), boundaries=[
        {k: r[k] for k in ("boundary", "byte_equal", "max_absolute_error", "relative_l2", "cosine")}
        for r in rows], greedy=report["greedy"])))


if __name__ == "__main__":
    main()
