"""Independent CPU reference for the fixed raw Qwen3.5-2B MTP block.

Only reads original safetensors and explicitly supplied mathematical inputs.
No candidate outputs are consulted and no tolerance/PASS policy is assigned.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct


MTP_SHAPES = {
    "mtp.fc.weight": [2048, 4096],
    "mtp.layers.0.input_layernorm.weight": [2048],
    "mtp.layers.0.mlp.down_proj.weight": [2048, 6144],
    "mtp.layers.0.mlp.gate_proj.weight": [6144, 2048],
    "mtp.layers.0.mlp.up_proj.weight": [6144, 2048],
    "mtp.layers.0.post_attention_layernorm.weight": [2048],
    "mtp.layers.0.self_attn.k_norm.weight": [256],
    "mtp.layers.0.self_attn.k_proj.weight": [512, 2048],
    "mtp.layers.0.self_attn.o_proj.weight": [2048, 2048],
    "mtp.layers.0.self_attn.q_norm.weight": [256],
    "mtp.layers.0.self_attn.q_proj.weight": [4096, 2048],
    "mtp.layers.0.self_attn.v_proj.weight": [512, 2048],
    "mtp.norm.weight": [2048],
    "mtp.pre_fc_norm_embedding.weight": [2048],
    "mtp.pre_fc_norm_hidden.weight": [2048],
}
EMBEDDING = "model.language_model.embed_tokens.weight"
HIDDEN, HEADS, KV_HEADS, DIM, VOCAB = 2048, 8, 2, 256, 248320


def small_identity(path: Path) -> dict:
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def read_ids(path: Path) -> list[int]:
    return [int(value) for value in path.read_text(encoding="ascii").split()]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, type=Path)
    parser.add_argument("--inputs", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    model, inputs, output = args.model.resolve(), args.inputs.resolve(), args.output.resolve()
    if output.exists():
        raise ValueError("output directory must be new")
    config_path = model / "config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))["text_config"]
    required = dict(hidden_size=HIDDEN, intermediate_size=6144,
                    num_attention_heads=HEADS, num_key_value_heads=KV_HEADS,
                    head_dim=DIM, vocab_size=VOCAB, mtp_num_hidden_layers=1,
                    mtp_use_dedicated_embeddings=False, tie_word_embeddings=True,
                    rms_norm_eps=1e-6)
    if any(config.get(k) != v for k, v in required.items()):
        raise ValueError("not the fixed Qwen3.5-2B MTP geometry")
    rope_config = config["rope_parameters"]
    if (rope_config.get("rope_theta") != 10000000 or
            rope_config.get("partial_rotary_factor") != 0.25 or
            rope_config.get("mrope_section") != [11, 11, 10] or
            rope_config.get("mrope_interleaved") is not True):
        raise ValueError("unexpected fixed pure-text rotary contract")
    tokens = read_ids(inputs / "tokens.ids")
    positions = read_ids(inputs / "positions.ids")
    if len(tokens) != 2 or len(positions) != 2:
        raise ValueError("this finite reference requires exactly two token/position rows")
    if any(t < 0 or t >= VOCAB for t in tokens):
        raise ValueError("token outside original vocabulary")
    if (inputs / "hidden.bf16").stat().st_size != 2 * HIDDEN * 2:
        raise ValueError("hidden.bf16 must contain BF16[2,2048]")
    prior_key, prior_value = inputs / "prior_key.bf16", inputs / "prior_value.bf16"
    if prior_key.exists() != prior_value.exists():
        raise ValueError("provide both prior_key.bf16 and prior_value.bf16, or neither")
    prior_bytes = prior_key.stat().st_size if prior_key.exists() else 0
    row_bytes = KV_HEADS * DIM * 2
    if prior_bytes % row_bytes or (prior_value.exists() and prior_value.stat().st_size != prior_bytes):
        raise ValueError("prior KV must have equal BF16[L,2,256] extents")
    prior_rows = prior_bytes // row_bytes
    if positions != [prior_rows, prior_rows + 1]:
        raise ValueError("positions must be the contiguous absolute suffix after prior KV")

    # Only import the runtime when root actually invokes this script.
    import torch
    import torch.nn.functional as functional
    from safetensors import safe_open

    if torch.get_default_dtype() != torch.float32:
        raise RuntimeError("reference requires the normal F32 default dtype")
    shard = model / "model.safetensors-00001-of-00001.safetensors"
    # Read/check metadata only, never hash or copy the complete checkpoint.
    with shard.open("rb") as stream:
        extent = struct.unpack("<Q", stream.read(8))[0]
        if extent > shard.stat().st_size - 8:
            raise ValueError("invalid original safetensors header extent")
        raw_header = stream.read(extent)
    header = json.loads(raw_header)
    for name, shape in {**MTP_SHAPES, EMBEDDING: [VOCAB, HIDDEN]}.items():
        if header[name]["dtype"] != "BF16" or header[name]["shape"] != shape:
            raise ValueError("original BF16 tensor geometry differs: " + name)
    if {k for k in header if k.startswith("mtp.")} != set(MTP_SHAPES):
        raise ValueError("unexpected original MTP tensor inventory")

    output.mkdir(parents=True)
    artifacts = {}
    weight_metadata = {}

    def dump(name, tensor):
        tensor = tensor.detach().contiguous()
        if tensor.device.type != "cpu":
            raise RuntimeError("reference unexpectedly left CPU")
        extension = {torch.bfloat16: "bf16", torch.float32: "f32", torch.int32: "i32"}[tensor.dtype]
        path = output / (name + "." + extension)
        path.write_bytes(tensor.view(torch.uint8).numpy().tobytes())
        artifacts[name] = dict(shape=list(tensor.shape), dtype=str(tensor.dtype),
                               finite=bool(torch.isfinite(tensor).all().item()), **small_identity(path))
        return tensor

    def bf16_input(path, shape):
        data = bytearray(path.read_bytes())
        expected = 2
        for size in shape:
            expected *= size
        if len(data) != expected:
            raise ValueError("input extent differs: " + str(path))
        return torch.frombuffer(data, dtype=torch.bfloat16).reshape(shape)

    with torch.inference_mode(), safe_open(str(shard), framework="pt", device="cpu") as bank:
        # get_tensor uses the original safetensors CPU mapping. In particular,
        # never widen, clone, serialize or export the full embedding/weight bank.
        def weight(name):
            tensor = bank.get_tensor(name)
            if tensor.dtype != torch.bfloat16 or tensor.device.type != "cpu":
                raise ValueError("expected original CPU BF16 weight: " + name)
            weight_metadata[name] = dict(dtype="BF16", shape=list(tensor.shape),
                                         data_offsets=header[name]["data_offsets"])
            return tensor

        def norm(x, name, boundary):
            scale = dump(boundary + "_scale", weight(name).float() + 1.0)
            wide = x.float()
            # Explicit F32 nodes, followed by the original BF16 graph boundary.
            inverse = torch.rsqrt(torch.mean(wide * wide, dim=-1, keepdim=True) + 1e-6)
            return dump(boundary, ((wide * inverse) * scale).to(torch.bfloat16))

        def linear(x, name, boundary):
            # F32 accumulation belongs to the CPU BF16 linear implementation;
            # the public output node is BF16, including the tied LM projection.
            return dump(boundary, functional.linear(x, weight(name)).to(torch.bfloat16))

        def rope(x, boundary):
            wide = x.float()
            angle = position_tensor[:, None, None] * frequencies[None, None, :]
            cosine, sine = torch.cos(angle), torch.sin(angle)
            first, second = wide[..., :32], wide[..., 32:64]
            rotated = torch.cat((first * cosine - second * sine,
                                 second * cosine + first * sine,
                                 wide[..., 64:]), dim=-1)
            return dump(boundary, rotated.to(torch.bfloat16))

        hidden = dump("hidden_input", bf16_input(inputs / "hidden.bf16", (2, HIDDEN)))
        token_tensor = torch.tensor(tokens, dtype=torch.int64)
        position_tensor = torch.tensor(positions, dtype=torch.float32)
        # Gather only the two embeddings; the complete matrix remains mapped.
        embedding = dump("embedding", weight(EMBEDDING).index_select(0, token_tensor))
        e = norm(embedding, "mtp.pre_fc_norm_embedding.weight", "embedding_norm")
        h = norm(hidden, "mtp.pre_fc_norm_hidden.weight", "hidden_norm")
        combined = dump("concat_embedding_hidden", torch.cat((e, h), dim=-1))
        projected = linear(combined, "mtp.fc.weight", "fc")
        normalized = norm(projected, "mtp.layers.0.input_layernorm.weight", "attn_input_norm")
        q_full = linear(normalized, "mtp.layers.0.self_attn.q_proj.weight", "q_full")
        per_head = q_full.reshape(2, HEADS, 2 * DIM)
        q = norm(per_head[..., :DIM], "mtp.layers.0.self_attn.q_norm.weight", "q_norm")
        gate = dump("gate", per_head[..., DIM:].contiguous())
        k = linear(normalized, "mtp.layers.0.self_attn.k_proj.weight", "key_projection").reshape(2, KV_HEADS, DIM)
        k = norm(k, "mtp.layers.0.self_attn.k_norm.weight", "key_norm")
        v = linear(normalized, "mtp.layers.0.self_attn.v_proj.weight", "value_projection").reshape(2, KV_HEADS, DIM)
        # Same finite mathematical frequencies as the existing pure-text role.
        frequencies = dump("rotary_frequencies", torch.reciprocal(torch.pow(
            torch.tensor(10000000.0, dtype=torch.float32),
            torch.arange(32, dtype=torch.float32) / 32.0)))
        q = rope(q, "query_rotary")
        k = rope(k, "key_rotary")
        if prior_rows:
            old_k = bf16_input(prior_key, (prior_rows, KV_HEADS, DIM))
            old_v = bf16_input(prior_value, (prior_rows, KV_HEADS, DIM))
            k_full = torch.cat((old_k, k), dim=0)
            v_full = torch.cat((old_v, v), dim=0)
        else:
            k_full, v_full = k, v
        dump("keys_full", k_full)
        dump("values_full", v_full)
        keys = k_full.float().repeat_interleave(HEADS // KV_HEADS, dim=1).permute(1, 0, 2)
        values = v_full.float().repeat_interleave(HEADS // KV_HEADS, dim=1).permute(1, 0, 2)
        scores = torch.matmul(q.float().permute(1, 0, 2), keys.transpose(1, 2)) * 0.0625
        future = torch.arange(prior_rows + 2)[None, :] > torch.tensor(positions)[:, None]
        masked = scores.masked_fill(future[None, :, :], float("-inf"))
        dump("attention_scores_unmasked", scores)
        # Masked scores deliberately contain -inf; dump separately, without
        # treating that required mask as a numerical comparison failure.
        dump("attention_scores_masked", masked)
        probabilities = dump("attention_probabilities", torch.softmax(masked, dim=-1))
        attention = dump("attention", torch.matmul(probabilities, values).permute(1, 0, 2).to(torch.bfloat16))
        sigmoid = dump("gate_sigmoid", torch.sigmoid(gate.float()).to(torch.bfloat16))
        gated = dump("attention_gated", (attention * sigmoid).to(torch.bfloat16))
        attended = linear(gated.reshape(2, HIDDEN), "mtp.layers.0.self_attn.o_proj.weight", "attention_projection")
        residual = dump("attention_residual", (projected + attended).to(torch.bfloat16))
        ffn_input = norm(residual, "mtp.layers.0.post_attention_layernorm.weight", "ffn_input_norm")
        ffn_gate = linear(ffn_input, "mtp.layers.0.mlp.gate_proj.weight", "ffn_gate_projection")
        activated = dump("ffn_gate_silu", functional.silu(ffn_gate.float()).to(torch.bfloat16))
        up = linear(ffn_input, "mtp.layers.0.mlp.up_proj.weight", "ffn_up_projection")
        product = dump("ffn_product", (activated * up).to(torch.bfloat16))
        down = linear(product, "mtp.layers.0.mlp.down_proj.weight", "ffn_down_projection")
        post_ffn = dump("ffn_residual", (residual + down).to(torch.bfloat16))
        final = norm(post_ffn, "mtp.norm.weight", "final_norm")
        head = linear(final, EMBEDDING, "tied_head")
        logits = dump("logits", head.float())
        ids = dump("greedy_ids", torch.argmax(logits, dim=-1).to(torch.int32))

    input_files = [inputs / n for n in ("tokens.ids", "positions.ids", "hidden.bf16")]
    if prior_key.exists():
        input_files += [prior_key, prior_value]
    report = dict(
        status="CPU reference computed; not compared with candidate", MTP_inference_reference=True,
        candidate_validation=False, tolerance=None, runtime=dict(torch=torch.__version__, device="cpu"),
        script=small_identity(Path(__file__)), config=small_identity(config_path),
        checkpoint=dict(path=str(shard), bytes=shard.stat().st_size, header_bytes=extent,
                        header_sha256=hashlib.sha256(raw_header).hexdigest(), payload_copied=False,
                        full_checkpoint_rehashed=False),
        inputs=[small_identity(p) for p in input_files], tokens=tokens, positions=positions,
        prior_rows=prior_rows, greedy_ids=ids.tolist(), weights=weight_metadata,
        contract=dict(hidden="post-target-final-RMSNorm BF16; already shifted by caller",
                      fresh_two_rows="token[x0,x1], positions[0,1], hidden[zero,target_h0]",
                      concat="embedding then hidden", raw_norm_scale="F32(raw BF16)+1 once",
                      norm="F32 square/mean/eps/rsqrt/multiply-scale then BF16",
                      linears="original BF16 weights, BF16 input/output", rotary="F32 halfsplit64 then BF16",
                      attention="F32 score/scale/causal softmax/value reduction then BF16",
                      sigmoid_silu="F32 unary evaluation then BF16", elementwise="BF16 output at every original node",
                      head="mtp.norm BF16 -> tied BF16 LM projection -> Cast F32 -> first-index greedy argmax"),
        artifacts=artifacts,
        limits=["No candidate output/state is read. This script assigns no accuracy tolerance or PASS result.",
                "CPU Torch reduction/GEMM/unary implementations need not be bit-identical to selected GPU kernels.",
                "Pure-text two-row, single trained MTP block only; prior KV is supplied chronological already-rotated BF16."],
        activity=dict(GPU=False, model_conversion=False, copied_checkpoint=False))
    (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(status=report["status"], output=str(output), greedy_ids=report["greedy_ids"],
                          boundaries=len(artifacts), candidate_validation=False)))


if __name__ == "__main__":
    main()
