from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
sources=['engine/models/qwen35/main.cc','engine/models/qwen35/mtp_graph.h',
 'tests/tools/qwen_host_image_test.cc','tests/tools/qwen_mtp_ragged_prefill_case.h']
for p in sources:
 out=W/'source'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((R/p).read_bytes())
tiny={}
for backend in ('cpu','cuda'):
 path=W/('tiny-'+backend+'-run/report.json');a=read(path)
 assert a['status']=='PASS' and len(a['batches'])==7 and a['numerically_equivalent']
 assert (a['actual_target_rows'],a['physical_target_rows'],a['committed_target_rows'])==(36,46,32)
 assert (a['actual_draft_rows'],a['physical_draft_rows'])==(32,42)
 assert a['final_lengths']==a['final_frontiers']==[16,16] and a['final_rng_draws']==[5,5]
 assert a['old_checkpoints_byte_unchanged'] and a['rng_and_epochs_equal'] and a['actual_i32_selectors_checked']
 assert a['final_versions']==a['final_images']==a['final_native_episodes']==0
 diffs=[d for b in a['batches'] for m in b['members'] for d in m['state']['differences']]
 assert all(d['role']==3 and not d['nonfinite_differences'] for d in diffs)
 tiny[backend]=dict(report=pin(path),status='PASS',batches=7,member_publications=14,
  target_rows=dict(actual=36,physical=46,committed=32),draft_rows=dict(actual=32,physical=42),
  maximum_absolute_gdn_error=max([d['maximum_absolute'] for d in diffs],default=0),
  actual_selectors_checked=True,old_checkpoints_byte_unchanged=True,rng_and_epochs_equal=True,
  final_lengths=[16,16],final_frontiers=[16,16],final_rng_draws=[5,5],
  final_versions=0,final_images=0,final_native_episodes=0)
path=W/'cli-mtp-run/report.json';cli=read(path)
assert cli['mtp'] and cli['packed_prefill_calls']==1 and cli['cold_exact_admissions']==0
assert (cli['packed_prefill_active_rows'],cli['packed_prefill_physical_rows'])==(191,308)
assert cli['batches'][0]['input_rows']==[154,37] and cli['batches'][0]['requests']==2
assert [s['result']['generated_ids'] for s in cli['sessions']]==[[71093,12305,198,464],[279,1879,1103,13]]
regression=read(W/'r1-cuda-regression-run/report.json');assert regression['status']=='PASS'
processes=[]
for p in sorted(W.rglob('process.json')):
 x=read(p);assert x['exit']==0 and not x['timed_out'];processes.append(dict(path=str(p),**x))
target=R/'docs/evidence/correctness/inference-mtp-ragged-prefill-2026-10-28.json'
data=dict(date='2026-10-28',base_commit='4ff1204f3',status='Finite checks passed',
 scope='B2 unequal-length MTP prefill/catchup; not bounded MTP StateOnly, full varlen closure or performance comparison.',
 sources=[pin(R/p) for p in sources],
 implementation=['Packed R1/B2 MTP use checked Gather from original carry/prior/target hidden and lag1 token sources with per-member real lengths.',
  'Original PhaseIo owns cold-reserved fixed I32 selectors, completely initialized before binding; no new owner, queue, permission or retirement system.',
  'Target and draft keep independent original Batch offsets/positions. Natural cold families and grouping allow unequal Li with the same role/lag/completion/sampler.',
  'Exact Single/Verify/decode and original recursive repair remain unchanged.'],
 tiny=tiny,real_cli=dict(image=read(W/'ready-model.json')['image'],report=pin(path),
  first_input_rows=[154,37],active_rows=191,physical_rows=308,cold_exact_admissions=0,
  generated_ids=[s['result']['generated_ids'] for s in cli['sessions']],performance_claim=False),
 r1_mtp_regression=dict(backend='cuda',report=pin(W/'r1-cuda-regression-run/report.json'),status='PASS'),
 numerical_contract='Only recomputed finite F32 GDN payloads use the existing 3e-6 component absolute budget. All other payloads, previous checkpoints, metadata and RNG stay strict.',
 processes=processes,cost=dict(CXX=2,links=2,consumer_processes=4,SDK_builds=0,NVCC=0,downloads=0),
 remaining=['MTP bounded prefill and StateOnly including Li1 and partial restore',
  'Other platform/provider/dtype combinations','Shared execution architecture and current full performance comparison'],
 limits=['Controlled verifier accepts two of three true rows and executes original NextN repair; no natural acceptance-rate claim.',
  'Tiny inputs are synthetic and untrained. Real CLI uses cached complete 2B original weights.',
  'Carrier R=B*C can contain substantial padding; support is not a claim of optimal memory or speed.',
  'No refreshed full performance or cross-engine window.'])
save(target,data)
files={'evidence.json':target}
for p in W.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.json','.log','.py','.h','.cc'} and '__pycache__' not in p.parts:
  files['run/'+str(p.relative_to(W)).replace('\\','/')]=p
manifest=[dict(name=k,**pin(v)) for k,v in sorted(files.items())]
archive=target.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,v in sorted(files.items()):z.write(v,k)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
save(W/'packaged.json',dict(evidence=pin(target),archive=pin(archive),members=len(manifest)+1))
print(json.dumps(read(W/'packaged.json'),indent=2))
