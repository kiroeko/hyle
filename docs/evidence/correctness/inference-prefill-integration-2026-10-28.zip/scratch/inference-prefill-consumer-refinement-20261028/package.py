from pathlib import Path
import hashlib, json, zipfile, xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[2]
W=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
S=R/'.scratch'
initial=S/'inference-prefill-integration-20261028'
offset=S/'inference-prefill-offset-refinement-20261028'
host=S/'inference-prefill-partition-20261028'
cli=read(W/'cli-natural-run/stdout.log')
real=read(W/'chunked-real-run/stdout.log')
tiny={b:read(W/('tiny-'+b+'-run/report.json')) for b in ('cpu','cuda')}
assert real['status']=='PASS' and real['actual_committed_input_rows']==304 and real['physical_committed_input_rows']==514
assert real['partial_state_kv_and_carry_byte_equal'] and real['cancelled_state_kv_and_carry_byte_unchanged']
assert cli['cold_exact_admissions']==0 and cli['packed_prefill_calls']==3
assert (cli['packed_prefill_active_rows'],cli['packed_prefill_physical_rows'])==(154,192)
assert [b['tokens'] for b in cli['batches']]==[64,64,26]+[1]*7
assert [b['generation'] for b in cli['batches']]==[False]*3+[True]*7
for b,x in tiny.items():
    assert x['status']=='PASS' and x['numerically_equivalent'] and not x['payloads_byte_equal']
    assert x['old_checkpoints_byte_unchanged'] and x['rng_and_epochs_equal']
    assert len(x['steps'])==8
    assert max(d['maximum_absolute'] for s in x['steps'] for d in s['differences'])<=4.65661e-10
    assert all(d['role']==3 and d['nonfinite_differences']==0 for s in x['steps'] for d in s['differences'])
xml=ET.parse(offset/'offsets-run/results.xml').getroot()
cuda=[x for x in xml.findall('.//testcase') if x.attrib['name'].endswith('Cuda')]
assert len(cuda)==1 and not cuda[0].findall('failure') and not cuda[0].findall('skipped')
cpu=ET.parse(offset/'offsets-cpu-runtime-run/results.xml').getroot()
assert cpu.attrib['tests']=='1' and cpu.attrib['failures']=='0' and not cpu.findall('.//skipped')
assert read(host/'summary.json')['status']=='PASS'
sources=['engine/inference/prefill_plan.h','engine/models/qwen35/main.cc',
 'include/hyle/graph/batch.h','src/graph_batch/batch.cc','tests/graph_batch/query_offsets_case.h',
 'tests/graph_batch/paged_append_graph_test.cc','tests/graph_batch/paged_append_cuda_consumer.cc',
 'tests/tools/inference_prefill_plan_test.cc','tests/tools/qwen_packed_prefill_case.h',
 'tests/tools/qwen_host_image_test.cc','tests/tools/qwen_chunked_prefill_case.h']
processes=[]
for folder in (host,initial,offset,W):
    for p in sorted(folder.rglob('process.json')):
        processes.append(dict(record=pin(p),relative=str(p.relative_to(S)),**read(p)))
evidence={
 'date':'2026-10-28','scope':'Ordinary R1 CPU/CUDA packed-capacity prefill; public original-mirror offsets; real CUDA Q64 consumer and natural CLI.',
 'status':'Finite checks passed; full varlen scope remains incomplete',
 'base_commits':dict(packed_math_append='abba6ca50',shared_slot_transactions='86e8f4a37'),
 'sources':[pin(R/p) for p in sources],
 'changes':[
  'Shared PrefillPolicy consumes min(remaining, quantum); monotonic division/remainder count and at most two capacity/completion keys.',
  'Public query_offsets returns exact original I32[B+1] mirror sublease; no copied mirror, Queue or permission model.',
  'Ordinary R1 Recipe uses packed GDN/conv, active KV append, actual-last-row sampling and original Store transactions.',
  'Physical R and actual L remain separate; no simultaneous packed/exact prefill inventory on supported cold routes; original T1 decode is independent.',
  'Only cold Unimplemented without native error selects original exact fallback; device errors are not hidden.'
 ],
 'checks':{
  'host_partition':read(host/'summary.json'),
  'offset_projection':dict(unique_tests=2,cuda_xml=pin(offset/'offsets-run/results.xml'),cpu_xml=pin(offset/'offsets-cpu-runtime-run/results.xml'),
      scope='Each test covers owned and explicit real layouts, B2 I32 Copy consumer, exact bounded alias, in-flight/prepared gates and update after unbind/release.'),
  'tiny':dict(untrained=True,geometry='GA H64 V64 C16 local fixture',reports=tiny,
      bound='Existing packed_sequence_case.h FP64 state absolute-error budget 3e-6; applied only to recomputed finite F32 GDN payloads.',
      maximum_observed_absolute_error=4.65661e-10,
      interpretation='F32 arithmetic agreement, not bitwise equality or full-model FP64/quality evidence. All other payloads, old snapshots, IDs, epoch and RNG remain strict.'),
  'real_chunked':real,
  'natural_cli':dict(image=read(W/'ready-model.json')['image'],command=pin(W/'cli-natural-run/command.json'),
      report=pin(W/'cli-natural-run/stdout.log'),prefill_actual_rows=154,prefill_physical_rows=192,
      prefill_calls=3,decode_calls=7,cold_exact_admissions=0,
      generated_ids=cli['sessions'][0]['result']['generated_ids'],performance_claim=False)
 },
 'preserved_failures':[
  dict(process=pin(initial/'offsets-run/process.json'),reason='Test expected Unavailable after settled Completion; explicit layout correctly consumed prepared token and returned FailedPrecondition. Product unchanged; corrected test retains real in-flight gate.'),
  dict(process=pin(offset/'offsets-run/process.json'),reason='CUDA test passed; CPU missing original native runtime DLL. Added hardlink to cached identical DLL and ran only CPU.'),
  dict(processes=[pin(initial/('tiny-'+b+'-run/process.json')) for b in ('cpu','cuda')],reason='All semantic/lifecycle steps completed, but cross-algorithm F32 bit equality assertion rejected normal arithmetic differences. Raw exit1 and full diagnostics preserved; final test applies existing numerical contract only to recomputed GDN states.'),
  dict(process=pin(initial/'chunked-real-run/process.json'),reason='Root selected old CUDA-only compile recipe against current CPU+CUDA Backend closure. Corrected consumer macro recipe; no product change for this harness failure.')
 ],
 'numerical_attribution':[
  'CPU packed uses sequential FMA; actual cached ggml CPU source uses AVX2 grouped/tree dot and vector update.',
  'CUDA packed rounds decayed state before dot; actual cached ggml scalar-gate path dots old state before multiplying by decay; key reduction groups differ.',
  'Zero-state L1 matches bytewise; subsequent differences only finite F32 GDN, <=4.65661e-10. This is consistent with arithmetic-order differences; all intermediate ports were not separately observed.'
 ],
 'processes':processes,
 'cost':dict(incremental_CXX=10,links=7,host_CXX=1,host_link=1,NVCC=0,SDK_builds=0,downloads=0),
 'remaining':['MTP prefill shift/lag integration','Different-Li B2/ragged model execution','Apple/Vulkan build and device checks','Current packed-path throughput and memory A/B; no performance gain is claimed'],
 'measurement_limits':['No refreshed cross-engine performance window; existing speed board is unchanged.',
     'Real journey committed304/physical514 excludes separately reported cancelled64 and reconstructed64; submission does not establish hardware completion at cancellation.',
     'Private padded rows are not logical tokens; fewer graph calls are not proof of speedup.']
}
target=R/'docs/evidence/correctness/inference-prefill-integration-2026-10-28.json'
archive=target.with_suffix('.zip')
save(target,evidence)
files={}
allowed={'.json','.log','.py','.h','.cc','.xml','.d'}
for folder in (host,initial,offset,W):
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix.lower() in allowed and '__pycache__' not in p.parts:
            files['scratch/'+str(p.relative_to(S)).replace('\\','/')]=p
for p in sources:files['final-source/'+p]=R/p
files['retained-helpers/indexed-store-build.py']=S/'inference-indexed-store-20261028/build.py'
files['retained-helpers/packed-sequence-build.py']=S/'inference-packed-sequence-20261028/build.py'
files['evidence.json']=target
manifest=[dict(name=name,**pin(path)) for name,path in sorted(files.items())]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.write(path,name)
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
save(W/'packaged.json',dict(evidence=pin(target),archive=pin(archive),members=len(manifest)+1))
print(json.dumps(read(W/'packaged.json'),indent=2))
