"""Canonical-source increments over retained object closures; no SDK rebuild."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, R/path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod
t = module('retained', '.scratch/inference-indexed-store-20261028/build.py')
p = module('recipes', '.scratch/inference-packed-sequence-20261028/build.py')
p.W = W
UNITS = {
 'batch': ('src/graph_batch/batch.cc', '.scratch/inference-indexed-store-20261028/recipes/batch.json'),
 'cpu-test': ('tests/graph_batch/paged_append_graph_test.cc', '.scratch/inference-packed-sequence-20261028/recipes/append-cpu-test.json'),
 'cuda-test': ('tests/graph_batch/paged_append_cuda_consumer.cc', '.scratch/inference-packed-sequence-20261028/recipes/append-cuda-test.json'),
 'tiny': ('tests/tools/qwen_host_image_test.cc', '.scratch/inference-slot-cohort-refinement-20261028/recipes/tiny.json'),
 'model': ('engine/models/qwen35/main.cc', '.scratch/inference-slot-cohort-refinement-20261028/recipes/model.json'),
 'probe': ('engine/models/qwen35/batch_probe.cc', '.scratch/inference-slot-cohort-refinement-20261028/recipes/probe.json'),
 'chunked': ('.scratch/inference-chunked-prefill-tail-20261027/consumer.cc', '.scratch/inference-slot-cohort-refinement-20261028/recipes/tiny.json'),
}
def compile_one(name):
    source, template = UNITS[name]
    out = W/'compile'/name; out.mkdir(parents=True, exist_ok=False)
    command = p.recipe(name, R/source, R/template)['command']
    if name in ('tiny', 'model', 'probe', 'chunked'):
        command.insert(1, '/I'+str(R/'engine/models/qwen35'))
    process = t.execute(command, W/'logs'/name, 300)
    deps = [t.pin(x) for x in dict.fromkeys(t.dep_paths(out/'dependencies.json'))]
    for row in deps:
        path=Path(row['path'])
        if t.project(t.canonical(path)) and t.key(path)!=t.key(t.canonical(path)):
            raise RuntimeError('stale project include: '+str(path))
        if t.project(path):
            dest=W/'source'/path.relative_to(R)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if not dest.exists(): dest.write_bytes(path.read_bytes())
    t.save(out/'actual-dependencies.json',deps)
    t.save(out/'compiled.json',dict(source=t.pin(R/source),object=t.pin(out/'unit.obj'),
        process=process,command=t.pin(W/'logs'/name/'command.json'),
        actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('CXX_PASS',name)
def link(name):
    component=name=='component'
    base_path=(R/'.scratch/inference-packed-sequence-append-fix-20261028/ready.json' if component
        else R/'.scratch/inference-slot-cohort-refinement-20261028'/('ready-model.json' if name in ('model','probe') else 'ready-tiny.json'))
    base=t.read(base_path); rows=t.read(base['inputs']['path'])
    replace={}; add=[]; remove=set()
    def replacement(old, unit):
        obj=t.read(W/'compile'/unit/'compiled.json')['object']
        replace[t.key(old)]=obj
    batch=R/'.scratch/inference-indexed-store-20261028/compile/batch/unit.obj'
    replacement(batch,'batch')
    if component:
        replacement(R/'.scratch/inference-packed-sequence-append-fix-20261028/compile/append-cpu-test/unit.obj','cpu-test')
        replacement(R/'.scratch/inference-packed-sequence-20261028/compile/append-cuda-test/unit.obj','cuda-test')
    else:
        old_plan=t.read(R/'.scratch/inference-packed-sequence-20261028/plan.json')
        for unit in ('native-provider','native-sequence','cuda-provider','cuda-sequence','cuda-status','sequence-kernel','append'):
            info=old_plan['units'][unit]
            obj=t.read(R/'.scratch/inference-packed-sequence-20261028/compile'/unit/'compiled.json')['object']
            if info['old_object']: replace[t.key(info['old_object']['path'])]=obj
            else: add.append(obj)
        old=R/'.scratch/inference-slot-cohort-refinement-20261028/compile'/('model' if name in ('model','probe') else 'tiny')/'unit.obj'
        if name=='probe':
            remove.add(t.key(old))
            entry=[x for x in rows if 'inference-current-closure-20261026/engine/entry/unit.obj' in x['path'].replace('\\','/')]
            assert len(entry)==1; remove.add(t.key(entry[0]['path']))
            add.append(t.read(W/'compile/probe/compiled.json')['object'])
        else: replacement(old,name)
    assert all(sum(t.key(x['path'])==k for x in rows)==1 for k in replace)
    inputs=[replace.get(t.key(x['path']),x) for x in rows if t.key(x['path']) not in remove]+add
    assert len(inputs)==len({t.key(x['path']) for x in inputs})
    for row in inputs:t.exact(row)
    image=W/'bin'/(name+'.exe'); image.parent.mkdir(exist_ok=True); assert not image.exists()
    command=[]; seen=set()
    for arg in t.command(base['recipe']['path']):
        key=t.key(arg)
        if key in remove:continue
        if key in replace:arg=replace[key]['path'];seen.add(key)
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if arg.upper().startswith(prefix):arg=prefix+str(image.with_suffix(suffix));break
        command.append(arg)
    assert seen==set(replace)
    command += [x['path'] for x in add]
    t.save(W/('inputs-'+name+'.json'),inputs)
    process=t.execute(command,W/'link'/name,240)
    t.save(W/('ready-'+name+'.json'),dict(image=t.pin(image),inputs=t.pin(W/('inputs-'+name+'.json')),
        recipe=t.pin(W/'link'/name/'command.json'),process=process))
    print('LINK_PASS',name,len(inputs))
if __name__=='__main__':
    if sys.argv[1]=='compile':compile_one(sys.argv[2])
    elif sys.argv[1]=='link':link(sys.argv[2])
    else:raise ValueError(sys.argv[1])
