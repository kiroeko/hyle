from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained', R/'.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
HEADER = R/'engine/inference/prefill_plan.h'
SOURCE = R/'tests/tools/inference_prefill_plan_test.cc'

def build():
    t.save(W/'sources.json', [t.pin(HEADER), t.pin(SOURCE)])
    for p in (HEADER, SOURCE):
        out = W/'source'/p.relative_to(R); out.parent.mkdir(parents=True,exist_ok=True)
        with out.open('xb') as stream: stream.write(p.read_bytes())
    obj = W/'compile/unit.obj'; obj.parent.mkdir(exist_ok=False)
    old = t.read(R/'.scratch/inference-prefill-facts-20261027/host-compile-plan.json')['command']
    args = []
    for index, arg in enumerate(old):
        if arg.casefold().startswith('/fo'): arg = '/Fo'+str(obj)
        elif index and old[index-1].casefold() == '/sourcedependencies': arg = str(obj.parent/'dependencies.json')
        args.append(arg)
    process = t.execute(args,W/'compile/log',60)
    for row in t.read(W/'sources.json'): t.exact(row)
    t.save(W/'compiled.json',dict(process=process,object=t.pin(obj),sources=t.pin(W/'sources.json'),
        dependencies=t.pin(obj.parent/'dependencies.json')))
    image = W/'bin/prefill-partition-test.exe'; image.parent.mkdir(exist_ok=False)
    old = t.read(R/'.scratch/inference-prefill-facts-20261027/host-link-plan.json')['command']
    args = [('/OUT:'+str(image) if arg.upper().startswith('/OUT:')
             else str(obj) if arg.lower().endswith('.obj') else arg) for arg in old]
    process = t.execute(args,W/'link',60)
    t.save(W/'ready.json',dict(image=t.pin(image),process=process))
    print('CXX/link PASS; only the original host partition contract')

def run():
    ready = t.read(W/'ready.json'); t.exact(ready['image'])
    for row in t.read(W/'sources.json'): t.exact(row)
    assert not (W/'run').exists()
    process = t.execute([ready['image']['path']],W/'run',30)
    t.save(W/'summary.json',dict(status='PASS',process=process,image=ready['image'],
        groups=6,scope='Real input chunks, monotonic episode counts and bounded physical capacities; no Model/GPU.'))
    print('Six original host contract groups PASS')

if __name__ == '__main__':
    if sys.argv[1]=='build': build()
    elif sys.argv[1]=='run': run()
    else: raise ValueError(sys.argv[1])
