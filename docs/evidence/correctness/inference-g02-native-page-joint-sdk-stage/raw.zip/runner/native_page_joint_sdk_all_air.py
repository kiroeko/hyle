from pathlib import Path
import json,subprocess,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g02-native-page-joint-sdk-stage';out.mkdir(exist_ok=True)
job=base/'g02-native-page-joint-host-sanitizers/vulkan-job-attempt2.json'
while json.loads(job.read_bytes())['state']!='TERMINAL':
    print('WAIT exact current Vulkan host sanitizer job; heavy jobs serial',flush=True);time.sleep(15)
assert json.loads(job.read_bytes())['exit_code']==0,'sanitizer failure must be inspected first'
rows=[];start=time.monotonic()
for route in ['apple','vulkan']:
    for mode in ['static','shared']:
        log=out/f'{route}-{mode}-attempt1.log';assert not log.exists()
        with log.open('w') as stream:
            process=subprocess.Popen(['/usr/bin/python3',str(base/'native_page_joint_sdk_air.py'),route,mode],stdout=stream,stderr=subprocess.STDOUT)
            record={'state':'RUNNING','pid':process.pid,'route':route,'mode':mode,'log':str(log),'completed':rows}
            (out/'job.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);code=process.wait()
        rows.append({'route':route,'mode':mode,'exit_code':code})
        if code:
            record.update(state='TERMINAL',exit_code=code,completed=rows,elapsed_seconds=time.monotonic()-start)
            (out/'job.json').write_text(json.dumps(record,indent=2)+'\n');print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
record.update(state='TERMINAL',exit_code=0,completed=rows,elapsed_seconds=time.monotonic()-start)
(out/'job.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
