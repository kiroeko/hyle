from pathlib import Path
import hashlib,json,os,subprocess,sys,time
route,mode=sys.argv[1:];assert route in ['apple','vulkan'] and mode in ['static','shared']
candidate='1cd0893979e1672a0f6fac98b783a6a3bfcabbca'
base=Path('/Users/kiro/hyle-scratch/compute-unified');canonical=base/'source-c8874688'
producer=base/f'a-cpu-{route}/selected-graph/{mode}-sdk-build';assert producer.is_dir()
out=base/f'g02-native-page-joint-{route}-{mode}-sdk';out.mkdir(exist_ok=True)
source=out/'consumer-source';source.mkdir(exist_ok=True);build=out/'consumer-build'
stage=out/'staging';prefix=out/'relocated';record=out/'result.json'
rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
identity={n:subprocess.check_output(a,text=True).strip() for n,a in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def run(name,args):
    number=1+sum(r['stage']==name for r in rows);log=out/f'{name}-{number}.log';start=time.monotonic()
    with log.open('w') as stream:result=subprocess.run(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
    row={'stage':name,'command':args,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    record.write_text(json.dumps({'candidate':candidate,'route':route,'mode':mode,'identity':identity,
        'scope':'relocated public hyle::graph only, actual CPU/native page/CPU mathematics, two-node/exact refusal/empty/cold budget+OOM and standalone headers; no internal products/hooks',
        'stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n');print(json.dumps(row),flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(result.returncode)
def done(name):return next((r for r in reversed(rows) if r['stage']==name),{}).get('exit_code')==0
if not done('producer-build'):
    run('producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target',
        f'hyle_graph_route_cpu_{route}','hyle_graph_batch','hyle_compute_batch',f'hyle_compute_route_{route}','--parallel','4'])
if not done('install'):
    assert not prefix.exists();run('install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
oracle='''#pragma once
#include <bit>
#include <cstdint>
namespace page_oracle {
struct float16_t {std::uint16_t bits;};
inline float16_t f32_to_f16(float x){return {std::bit_cast<std::uint16_t>(static_cast<_Float16>(x))};}
}
'''
(source/'oracle_dtype.h').write_text(oracle)
files=['tests/graph_batch/native_paged_joint_consumer.cc','tests/graph_batch/native_paged_joint_risk_fixture.h',
       'tests/compute_batch/native_paged_risk_fixture.h','tests/compute_batch/allocation_fault_fixture.h']
inputs=[]
for name in files:
    original=(canonical/name).read_bytes();data=original.replace(b'#include <hyle/simd/dtype.h>',b'#include "oracle_dtype.h"').replace(b'hyle::simd::',b'page_oracle::')
    dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    inputs.append({'path':name,'canonical_sha256':hashlib.sha256(original).hexdigest(),'consumer_sha256':hashlib.sha256(data).hexdigest()})
(out/'consumer-inputs.json').write_text(json.dumps({'files':inputs,'oracle_sha256':hashlib.sha256(oracle.encode()).hexdigest()},indent=2)+'\n')
device='n::MemoryResource::create(native)' if route=='apple' else 'n::MemoryResource::create(native,n::MemoryKind::kDevice)'
staging='n::MemoryResource::create(native)' if route=='apple' else 'n::MemoryResource::create(native,n::MemoryKind::kStaging)'
(source/'domains.cc').write_text('''#include "tests/graph_batch/native_paged_joint_risk_fixture.h"
namespace r=hyle_joint_page_risk;namespace n=r::n;
hyle::Status run(){HYLE_ASSIGN_OR_RETURN(auto cpu,r::g::cpu::create_context());HYLE_ASSIGN_OR_RETURN(auto native,n::Context::create());
HYLE_ASSIGN_OR_RETURN(auto device,'''+device+''');HYLE_ASSIGN_OR_RETURN(auto staging,'''+staging+''');
HYLE_ASSIGN_OR_RETURN(auto data,r::r::inputs(native,device,staging));
HYLE_RETURN_IF_ERROR(r::domain_checks(cpu,native,device,staging,data));return r::cold_failures(cpu,native,device,staging,data);}
int main(){auto status=run();if(!status.ok()){std::fprintf(stderr,"FAIL: %.*s\\n",int(status.message().size()),status.message().data());return 1;}return 0;}
''')
for index,header in enumerate(['batch.h',f'cpu_{route}.h','cpu.h']):(source/f'header-{index}.cc').write_text(f'#include <hyle/graph/{header}>\n')
definitions='target_compile_definitions(${t} PRIVATE HYLE_JOINT_PAGE_APPLE=1)' if route=='apple' else ''
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g02_joint_page_public_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph)
add_executable(joint tests/graph_batch/native_paged_joint_consumer.cc)
add_executable(domains domains.cc)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc)
foreach(t joint domains headers)
  target_compile_features(${t} PRIVATE cxx_std_23)
  target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(${t} PRIVATE hyle::graph)
  target_include_directories(${t} PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
  '''+definitions+'''
endforeach()
hyle_stage_runtime(joint)
hyle_stage_runtime(domains)
''')
run('consumer-configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
run('consumer-build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','joint','domains','headers','--parallel','4'])
commands=json.loads((build/'compile_commands.json').read_bytes())
for item in commands:
    assert str(canonical) not in item['command'] and str(prefix/'include') in item['command'],item['command']
(out/'public-compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
run('joint',[str(build/'joint')]);run('domains',[str(build/'domains')])
print('TERMINAL PASS',route,mode,'public relocated graph',flush=True)
