#pragma once
#include <bit>
#include <cstdint>
namespace page_oracle {
struct float16_t {std::uint16_t bits;};
inline float16_t f32_to_f16(float x){return {std::bit_cast<std::uint16_t>(static_cast<_Float16>(x))};}
}
