#include "tests/graph_batch/native_paged_joint_risk_fixture.h"
namespace r=hyle_joint_page_risk;namespace n=r::n;
hyle::Status run(){HYLE_ASSIGN_OR_RETURN(auto cpu,r::g::cpu::create_context());HYLE_ASSIGN_OR_RETURN(auto native,n::Context::create());
HYLE_ASSIGN_OR_RETURN(auto device,n::MemoryResource::create(native));HYLE_ASSIGN_OR_RETURN(auto staging,n::MemoryResource::create(native));
HYLE_ASSIGN_OR_RETURN(auto data,r::r::inputs(native,device,staging));
HYLE_RETURN_IF_ERROR(r::domain_checks(cpu,native,device,staging,data));return r::cold_failures(cpu,native,device,staging,data);}
int main(){auto status=run();if(!status.ok()){std::fprintf(stderr,"FAIL: %.*s\n",int(status.message().size()),status.message().data());return 1;}return 0;}
