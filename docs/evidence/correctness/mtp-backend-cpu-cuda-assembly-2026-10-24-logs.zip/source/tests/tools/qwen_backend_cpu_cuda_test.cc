#include "../../engine/models/qwen35/backend.h"

#include <array>
#include <cmath>
#include <gtest/gtest.h>
#include "hyle/graph/progress.h"
#include "hyle/sched/blocking.h"

namespace {
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace mixed=g::cpu_cuda;
namespace m=hyle::mem;

struct Example final {
  g::Graph graph;
  g::ValueId input,weight,output;
  std::array<g::NodePlacement,4> placements;
  std::array<g::ExternalResourceContract,2> external;
};
Example example(c::TensorDesc desc) {
  auto builder=g::GraphBuilder::create().value();
  const auto x=builder.input(desc).value(),w=builder.constant(desc).value();
  const auto abs=builder.add(c::Unary{c::UnaryKind::kAbs},x).value();
  const auto sum=builder.add(c::Binary{},abs,w).value();
  const auto neg=builder.add(c::Unary{c::UnaryKind::kNeg},sum).value();
  const auto y=builder.add(c::Unary{c::UnaryKind::kAbs},neg).value();
  EXPECT_TRUE(builder.publish(y).ok());
  auto graph=std::move(builder).finish().value();
  const std::array placements{
      g::NodePlacement{graph.node_id(0).value(),mixed::kCpuTarget,g::PlacementStrength::kRequired},
      g::NodePlacement{graph.node_id(1).value(),mixed::kCpuTarget,g::PlacementStrength::kRequired},
      g::NodePlacement{graph.node_id(2).value(),mixed::kCudaTarget,g::PlacementStrength::kRequired},
      g::NodePlacement{graph.node_id(3).value(),mixed::kCpuTarget,g::PlacementStrength::kRequired}};
  return {std::move(graph),x,w,y,placements,
      {g::ExternalResourceContract{x,mixed::kHostStorage},g::ExternalResourceContract{y,mixed::kHostStorage}}};
}

TEST(QwenBackendCpuCuda, DefaultRemainsOneCudaEndpoint) {
  auto created=qwen35::Backend::create();ASSERT_TRUE(created)<<created.error().message();
  auto backend=std::move(*created);
  EXPECT_FALSE(backend.has_cpu_endpoint());EXPECT_FALSE(backend.host_device().valid());
  ASSERT_EQ(backend.queue_bindings().size(),1U);
  EXPECT_EQ(backend.queue_bindings()[0].queue,&backend.common_queue());
  const auto desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{17}).value();
  auto builder=g::GraphBuilder::create().value();const auto x=builder.input(desc).value();
  const auto y=builder.add(c::Unary{c::UnaryKind::kNeg},x).value();ASSERT_TRUE(builder.publish(y).ok());
  auto graph=std::move(builder).finish().value();
  auto compiled=backend.compile(graph,{});ASSERT_TRUE(compiled)<<compiled.error().message();
  EXPECT_EQ(compiled->report.target_count(),1U);EXPECT_EQ(compiled->report.storage_domain_count(),1U);
  EXPECT_EQ(compiled->report.lane_count(),1U);
}

TEST(QwenBackendCpuCuda, OriginalOwnersQueuesBorrowedReplicaAndRetirement) {
  auto created=qwen35::Backend::create_cpu_cuda();ASSERT_TRUE(created)<<created.error().message();
  auto before=std::move(*created);const auto staging=before.staging();
  const auto context=before.storage_owner().context_identity();ASSERT_NE(context,nullptr);
  auto backend=std::move(before);
  ASSERT_TRUE(backend.has_cpu_endpoint());EXPECT_EQ(staging,backend.staging());
  ASSERT_EQ(backend.queue_bindings().size(),2U);
  EXPECT_EQ(backend.queue_bindings()[0].queue,&backend.common_queue());
  EXPECT_EQ(backend.queue_bindings()[1].lane,g::ExecutionLaneId{1});
  EXPECT_NE(backend.queue_bindings()[0].queue,backend.queue_bindings()[1].queue);
  const auto staging_owner=backend.storage_owner_for(staging).value();
  EXPECT_EQ(staging_owner.context_identity(),context);
  EXPECT_EQ(backend.storage_owner_for(backend.device())->context_identity(),context);
  EXPECT_FALSE(backend.storage_owner_for(backend.host_device())->valid());
  EXPECT_FALSE(backend.storage_owner_for({}));
  constexpr std::size_t count=17;const auto bytes=count*sizeof(float);
  const auto desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{count}).value();
  const auto e=example(desc);
  const std::array limits{c::ResourceBudgetLimit{backend.device(),64*1024*1024},
      c::ResourceBudgetLimit{backend.host_device(),64*1024*1024},c::ResourceBudgetLimit{backend.staging(),4*1024*1024}};
  auto budget=c::ResourceBudget::create({.limits=limits,.allow_unattributed=true}).value();
  std::array<std::size_t,3> baseline{};
  for(std::size_t i=0;i<limits.size();++i)baseline[i]=budget.usage(limits[i].resource)->live_bytes;
  {
    auto input=m::Buffer::create(backend.host_device(),bytes,256).value();
    auto output=m::Buffer::create(backend.host_device(),bytes,256).value();
    auto weights=m::Buffer::create(backend.device(),bytes,256).value();
    std::array<float,count> w{},x{},actual{};
    for(std::size_t i=0;i<count;++i)w[i]=float(i+1)/16.F;
    ASSERT_TRUE(backend.write(weights.view(),std::as_bytes(std::span(w))).ok());
    c::ReadLease frozen;ASSERT_TRUE(backend.freeze(weights,frozen).ok());
    auto host=m::Buffer::create(backend.host_device(),bytes,256).value();
    auto host_lease=backend.adopt_buffer(std::move(host));ASSERT_TRUE(host_lease)<<host_lease.error().message();
    const auto view=c::ConstTensorView::create(desc,frozen.view().value()).value();
    const std::array constants{g::ConstantBinding{.value=e.weight,.tensor=view,.policy=g::ConstantPolicy::kBorrow,
        .owner=backend.storage_owner_for(view.storage().resource()).value(),.lease=frozen}};
    auto compiled=backend.compile(e.graph,constants,{.resource_budget=budget,.node_placements=e.placements,.external_resources=e.external});
    ASSERT_TRUE(compiled)<<compiled.error().message();
    EXPECT_EQ(compiled->report.target_count(),2U);EXPECT_EQ(compiled->report.storage_domain_count(),3U);
    EXPECT_EQ(compiled->report.lane_count(),2U);
    const auto constant=compiled->report.constant().value();
    EXPECT_EQ(constant.policy,g::ConstantPolicy::kBorrow);EXPECT_EQ(constant.storage,mixed::kDeviceStorage);
    EXPECT_GE(constant.materialized_bytes,bytes); // A real additional host replica is legal with kBorrow.
    EXPECT_GT(compiled->report.copy_bytes(),0U);
    hyle::sched::Scheduler scheduler(2,m::system_allocator(),64);
    hyle::sched::BlockingPool workers(m::system_allocator(),2);
    struct Drain {hyle::sched::Scheduler &scheduler;~Drain(){scheduler.drain();}} drain{scheduler};
    auto invocation=compiled->executable.create_invocation();ASSERT_TRUE(invocation)<<invocation.error().message();
    ASSERT_TRUE(g::prepare_progress(*invocation,scheduler,workers).ok());
    ASSERT_TRUE(invocation->bind(e.input,c::ConstTensorView::create(desc,input.view()).value()).ok());
    ASSERT_TRUE(invocation->bind(e.output,c::TensorView::create(desc,output.view()).value()).ok());
    for(int replay=0;replay<2;++replay) {
      for(std::size_t i=0;i<count;++i)x[i]=float(int(i)-8)/8.F+float(replay)/32.F;
      ASSERT_TRUE(backend.write(input.view(),std::as_bytes(std::span(x))).ok());
      const auto queues=backend.queue_bindings();ASSERT_TRUE(invocation->prepare_replay(queues).ok());
      auto done=invocation->submit(queues);ASSERT_TRUE(done)<<done.error().message();ASSERT_TRUE(done->wait().ok());
      ASSERT_TRUE(backend.read(output.view(),std::as_writable_bytes(std::span(actual))).ok());
      for(std::size_t i=0;i<count;++i)EXPECT_EQ(actual[i],std::abs(std::abs(x[i])+w[i]));
    }
    ASSERT_TRUE(invocation->drain().ok());EXPECT_FALSE(invocation->submit(backend.queue_bindings()));
    ASSERT_TRUE(backend.collect_retired().ok());
  }
  // The live budget owns its own control metadata. All graph/constant/episode
  // charges must retire back to that actual pre-compile baseline.
  for(std::size_t i=0;i<limits.size();++i)
    EXPECT_EQ(budget.usage(limits[i].resource)->live_bytes,baseline[i]);
}

TEST(QwenBackendCpuCuda, ZeroStagingWorkspaceRejectsRequiredCrossings) {
  auto created=qwen35::Backend::create_cpu_cuda({.staging=0});
  ASSERT_TRUE(created)<<created.error().message();auto backend=std::move(*created);
  const auto desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{17}).value();
  auto builder=g::GraphBuilder::create().value();const auto x=builder.input(desc).value();
  const auto a=builder.add(c::Unary{c::UnaryKind::kAbs},x).value();
  const auto b=builder.add(c::Unary{c::UnaryKind::kNeg},a).value();
  const auto y=builder.add(c::Unary{c::UnaryKind::kAbs},b).value();ASSERT_TRUE(builder.publish(y).ok());
  auto graph=std::move(builder).finish().value();
  const std::array placements{
      g::NodePlacement{graph.node_id(0).value(),mixed::kCpuTarget,g::PlacementStrength::kRequired},
      g::NodePlacement{graph.node_id(1).value(),mixed::kCudaTarget,g::PlacementStrength::kRequired},
      g::NodePlacement{graph.node_id(2).value(),mixed::kCpuTarget,g::PlacementStrength::kRequired}};
  const std::array external{g::ExternalResourceContract{x,mixed::kHostStorage},
      g::ExternalResourceContract{y,mixed::kHostStorage}};
  const auto compiled=backend.compile(graph,{},{.node_placements=placements,.external_resources=external});
  EXPECT_FALSE(compiled)<<"required host/device crossings must honor the configured zero pinned workspace";
}
} // namespace
