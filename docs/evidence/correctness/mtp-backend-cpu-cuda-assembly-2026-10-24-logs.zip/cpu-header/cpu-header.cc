#include "C:/public/project-hyle/hyle/engine/models/qwen35/backend.h"
static_assert(qwen35::Backend::host_only);
hyle::Result<qwen35::Backend> cold_cpu() {return qwen35::Backend::create();}
