from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];O=S/'backend-cpu-cuda-check6/cpu-header'
O.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
source=O/'cpu-header.cc'
source.write_text('#include "'+(R/'engine/models/qwen35/backend.h').as_posix()+'"\nstatic_assert(qwen35::Backend::host_only);\nhyle::Result<qwen35::Backend> cold_cpu() {return qwen35::Backend::create();}\n')
old=b.read(S/'dense-cpu-check1/provider/identity.json');cc=old['command'][0]
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
flags=[];skip=False
for arg in old['command'][1:]:
 if skip:skip=False;continue
 if arg.lower()=='/sourcedependencies':skip=True;continue
 if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith('.cc'):continue
 flags.append(arg)
obj=O/'compile/cpu-header.obj'
cmd=[cc,*flags,'/DHYLE_COMPUTE_CPU=1','/sourceDependencies',str(O/'compile/dependencies.json'),str(source),'/Fo'+str(obj)]
b.execute(cmd,env.env,O/'compile',60)
b.save(O/'summary.json',dict(passed=True,source=b.identity(source),header=b.identity(R/'engine/models/qwen35/backend.h'),
    object=b.identity(obj),CPU_only_compile=True,native_or_model_run=False))
print('PASS CPU-only header branch; no native/model run')
