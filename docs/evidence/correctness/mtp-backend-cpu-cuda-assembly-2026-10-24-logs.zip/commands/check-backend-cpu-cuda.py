from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];OUT=S/'backend-cpu-cuda-check6';OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=b.read(S/'dense-cpu-check1/provider/identity.json');cc=old['command'][0]
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
flags=[];skip=False
for arg in old['command'][1:]:
 if skip:skip=False;continue
 if arg.lower()=='/sourcedependencies':skip=True;continue
 if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith('.cc'):continue
 flags.append(arg)
cuda=b.read(R/'.scratch/qwen-mtp-quality-20261022/current-refresh-20261024/compile2/qwen/identity.json')
for arg in cuda['command']:
 if arg.startswith(('/I','/external:I')) and arg not in flags:flags.append(arg)
flags+=['/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_CUDA=1']
source=R/'tests/tools/qwen_backend_cpu_cuda_test.cc';frozen=b.identity(source);obj=OUT/'compile/backend-test.obj'
cmd=[cc,*flags,'/sourceDependencies',str(OUT/'compile/dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(OUT/'compile/backend-test.pdb')]
b.execute(cmd,env.env,OUT/'compile',120);assert b.identity(source)==frozen
dep=b.read(OUT/'compile/dependencies.json')['Data']
b.save(OUT/'identity.json',dict(source=frozen,object=b.identity(obj),command=cmd,dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]))
oldlink=b.read(S/'dense-cpu-check1/link-plan.json')
cmd=[arg for arg in oldlink['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
image=OUT/'link/backend-check.exe';cmd+=[str(obj),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map'))]
b.save(OUT/'link-plan.json',dict(command=cmd,fresh_TUs=1,SDK_builds=0,native_builds=0))
b.execute(cmd,env.env,OUT/'link',90)
for dll in (S/'dense-cpu-check1/link').glob('*.dll'):os.link(dll,OUT/'link'/dll.name)
ready=b.read(R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/ready.json')
result=b.execute([str(image),'--gtest_filter=QwenBackendCpuCuda.*','--gtest_output=json:'+str(OUT/'gtest-results.json')],dict(env.env,PATH=ready['PATH']),OUT/'run',120)
b.save(OUT/'summary.json',dict(process=result,image=b.identity(image),new_TUs=1,SDK_builds=0,HTTP=0,full_MTP_model=False))
print((OUT/'run/stdout.log').read_text())
