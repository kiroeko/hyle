$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/dspark-mtp-integration-20261022').Path
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$prefix = $taskRoot.TrimEnd('\') + '\'
$keep = [System.IO.Path]::GetFullPath($plan.keep)
$targets = @($plan.entries)
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $targets) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if (-not $target.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside task root: $target" }
    if ((Split-Path -Parent $target) -eq $keep) { throw "Current image protected: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe', '.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = $targets
    Bytes = $plan.bytes
    CurrentImageRetained = (Test-Path -LiteralPath (Join-Path $keep 'dspark-checks.exe'))
    CurrentMapRetained = (Test-Path -LiteralPath (Join-Path $keep 'dspark-checks.map'))
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object Bytes, CurrentImageRetained, CurrentMapRetained
