"""Fetch only the two fixed BF16 Markov roles, never the 10.9GB sidecar."""
from pathlib import Path
import hashlib
import json
import time
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
headers = json.loads((R / '.scratch/validation/cpu-quant-mtp-c1/headers.json').read_text(encoding='utf-8'))
source = next(item for item in headers.values()
              if item.get('file') == 'dspark-DeepSeek-V4-Flash-0731-Q8_0.gguf')
assert source['revision'] == 'fbbb5b93fb787c21338159b0af3318bb3f4d9768'
roles = [next(item for item in source['tensors'] if item['name'] == name)
         for name in ['markov_w1.weight', 'markov_w2.weight']]
folder = S / 'original-markov'
folder.mkdir(exist_ok=False)
receipt = dict(repository=source['repository'], revision=source['revision'],
               file=source['file'], tensor_table_sha256=source['tensor_table_sha256'],
               tensor_data_offset=int(source['tensor_data_offset']),
               whole_file_download_allowed=False, roles=[], complete=False)


def save():
    (folder / 'acquisition.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


save()
for role in roles:
    assert role['dtype'] == 'BF16' and role['shape'] == ['256', '129280']
    count = 256 * 129280 * 2
    first = int(source['tensor_data_offset']) + int(role['offset'])
    last = first + count - 1
    path = folder / (role['name'] + '.bf16')
    record = dict(role=role, requested_bytes=count, absolute_range=[first, last],
                  started_unix=time.time(), status='REQUESTING')
    receipt['roles'].append(record)
    save()
    try:
        request = urllib.request.Request(source['url'], headers={
            'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity',
            'User-Agent': 'hyle-original-role-consumer/1'})
        with urllib.request.urlopen(request, timeout=45) as response:
            content_range = response.headers.get('Content-Range', '')
            record.update(http_status=response.status, content_range=content_range,
                          content_length=response.headers.get('Content-Length'),
                          etag=response.headers.get('ETag'))
            assert response.status == 206 and content_range == f'bytes {first}-{last}/10896057440', \
                'Refuse whole file or incorrect range before reading response body'
            if record['content_length'] is not None:
                assert int(record['content_length']) == count
            digest = hashlib.sha256()
            remaining = count
            with path.open('xb') as output:
                while remaining:
                    chunk = response.read(min(1 << 20, remaining))
                    assert chunk, 'Truncated exact role response'
                    output.write(chunk)
                    digest.update(chunk)
                    remaining -= len(chunk)
                assert not response.read(1), 'Response exceeds exact role'
        record.update(status='ACQUIRED_EXACT_ROLE', payload=dict(
            path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest()))
        print(role['name'], record['payload'], flush=True)
    except Exception as error:
        record.update(status='ACQUISITION_FAILED_NO_WHOLE_FILE', error=repr(error))
        raise
    finally:
        record['finished_unix'] = time.time()
        save()
receipt['complete'] = True
save()
