"""Host test overlays on the retained AV closure; no SDK/NVCC/shader builds."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AV = R / '.scratch/qwen-mtp-next-20261022'
spec = importlib.util.spec_from_file_location('aw_cached', AV / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = AV / 'hyle-link4'
SOURCES = {
    'confidence': R / 'tests/graph_route_cuda/dspark_original_confidence_test.cc',
    'complete': R / 'tests/graph_route_cuda/dspark_complete_consumer_test.cc',
    'state': R / 'tests/compute_state/dspark_prefix_consumer_test.cc',
    'legacy-state': R / 'tests/compute_state/deepseek_sparse_prefix_consumer.cc',
    'cpu-context': R / 'src/graph_route_cpu/cpu_context.cc',
    'cpu-packed': R / 'src/graph_route_cpu/ct_packed_linear_region.cc',
    'cpu-ggml': R / 'src/graph_route_cpu/ggml_region.cc',
    'cpu-onednn': R / 'src/graph_provider_onednn/onednn_region_provider.cc',
    'cpu-provider': R / 'src/compute_provider_ggml/ggml_cpu_provider.cc',
    'diagnostic': S / 'provider_probe.cc',
}
RECIPE = R / '.scratch/qwen-capture-reuse-20261022/compile1/cuda-test/identity.json'


def compile_one(tag, attempt):
    h.RECIPES[tag] = (R / '.scratch/architecture-refactor-2026-10-18/ct-packed-cross-platform/checks/src--graph_route_cpu--cpu_context-identity.json') if tag.startswith('cpu-') or tag == 'diagnostic' else RECIPE
    if tag in ('cpu-ggml', 'cpu-provider'):
        h.RECIPES[tag] = R / '.scratch/paged-append-20261021/checks/attempt5/compute_provider_ggml--ggml_cpu_provider/identity.json'
    if tag == 'cpu-onednn':
        h.RECIPES[tag] = R / '.scratch/architecture-refactor-2026-10-18/cuda-coarse-capture-tests/compute_provider_onednn--onednn_provider-identity.json'
    h.SOURCES[tag] = SOURCES[tag]
    h.compile_one(tag, attempt)


def latest(tag):
    paths = sorted(S.glob(f'compile*/{tag}/identity.json'),
                   key=lambda path: int(path.parents[1].name[7:]))
    assert paths, tag
    return paths[-1], c.read(paths[-1])


def link(tags, attempt):
    assert 'legacy-state' not in tags, 'The preserved standalone entry is compile-only here'
    base = c.read(BASE / 'link-plan.json')
    main = c.key(c.read(R / '.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json')['object']['path'])
    inputs = [item for item in base['inputs'] if c.key(item['path']) != main]
    command = [item for item in base['command'] if c.key(item) != main and
               not item.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    if 'state' in tags and list(S.glob('compile*/cpu-provider/identity.json')):
        _, record = latest('cpu-provider')
        old = next(item for item in inputs if 'compute_provider_ggml--ggml_cpu_provider.obj' in item['path'])
        assert all(b.identity(item['path']) == item for item in
                   [record['source'], record['object'], *record['dependencies']])
        inputs = [record['object'] if item == old else item for item in inputs]
        command = [record['object']['path'] if c.key(item) == c.key(old['path']) else item for item in command]
    extra, records = [], []
    for tag in tags:
        path, record = latest(tag)
        assert all(b.identity(item['path']) == item
                   for item in [record['source'], record['object'], *record['dependencies']])
        extra.append(record['object'])
        records.append(b.identity(path))
    extra += [b.identity(R / '.scratch/build-compute-v2-dev/lib/gtest_main.lib'),
              b.identity(R / '.scratch/build-compute-v2-dev/lib/gtest.lib')]
    if 'state' in tags or 'diagnostic' in tags:
        for tag in ['cpu-context', 'cpu-packed', 'cpu-ggml', 'cpu-onednn']:
            path, record = latest(tag)
            assert all(b.identity(item['path']) == item for item in
                       [record['source'], record['object'], *record['dependencies']])
            extra.append(record['object'])
            records.append(b.identity(path))
        cpu_program_path = R / '.scratch/paged-append-20261021/checks/attempt7/compute_ggml_runtime--cpu_program/identity.json'
        cpu_program = c.read(cpu_program_path)
        assert all(b.identity(item['path']) == item for item in
                   [cpu_program['source'], cpu_program['object'], *cpu_program['dependencies']])
        extra += [cpu_program['object'], b.identity(R / '.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/native-baseline.obj')]
        records.append(b.identity(cpu_program_path))
    inputs = extra + inputs
    command[1:1] = [item['path'] for item in extra]
    assert all(b.identity(item['path']) == item for item in inputs)
    folder = S / f'tests-link{attempt}'
    folder.mkdir()
    (folder / 'tmp').mkdir()
    image = folder / 'dspark-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(folder / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=records, base=b.identity(BASE / 'link-plan.json'),
        SDK_builds=0, NVCC_builds=0, shader_builds=0))
    env, _ = b.environment(command, [item['path'] for item in inputs], folder)
    c.execute('link', command, env, folder)
    runtime = c.read(BASE / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        os.link(item['path'], folder / Path(item['path']).name)
    if 'state' in tags or 'diagnostic' in tags:
        cpu_dll = R / '.scratch/paged-append-20261021/cpu-link7/hyle_ggml_cpu_append_hyca.dll'
        os.link(cpu_dll, folder / cpu_dll.name)
    runtime['staged_dlls'] = [b.identity(path) for path in folder.glob('*.dll')]
    c.save(folder / 'runtime-environment.json', runtime)
    c.save(folder / 'ready.json', dict(image=b.identity(image)))
    print('LINKED', image, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('actions', nargs='+', choices=[*SOURCES, 'link'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--tags', nargs='+', choices=SOURCES, default=['confidence'])
    args = parser.parse_args()
    for action in args.actions:
        if action == 'link':
            link(args.tags, args.attempt)
        else:
            compile_one(action, args.attempt)
