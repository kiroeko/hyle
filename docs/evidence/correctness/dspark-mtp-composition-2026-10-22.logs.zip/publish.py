"""Publish the implemented finite compositions and failures; execute nothing."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = R / 'docs/evidence/correctness/dspark-mtp-composition-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def ident(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def save(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


assert not OUT.exists() and not ZIP.exists()
checks = read(S / 'checks6/summary.json')
assert checks['tests'] == 4 and not any(checks[key] for key in ['failures', 'errors', 'disabled', 'skips'])
assert checks['process']['exit'] == 0 and not checks['process']['timed_out']
assert ident(checks['image']['path'])['sha256'] == checks['image']['sha256']
acquisition = read(S / 'original-markov/acquisition.json')
assert acquisition['complete'] and len(acquisition['roles']) == 2
for role in acquisition['roles']:
    assert role['status'] == 'ACQUIRED_EXACT_ROLE'
    assert ident(role['payload']['path'])['sha256'] == role['payload']['sha256']
    assert role['payload']['bytes'] == 66191360
cleanup = read(S / 'cleanup-result.json')
assert len(cleanup['Removed']) == 14 and cleanup['Bytes'] == 1184792791
assert cleanup['CurrentImageRetained'] and cleanup['CurrentMapRetained']
assert all(not Path(item['path']).exists() for item in cleanup['Removed'])
products = [
    'src/compute_provider_ggml/ggml_cpu_provider.cc',
    'tests/compute_models/original_role_input.h',
    'tests/compute_models/dspark_original_roles.h',
    'tests/compute_models/dspark_complete_graph_fixture.h',
    'tests/graph_route_cuda/dspark_complete_consumer_test.cc',
    'tests/graph_route_cuda/dspark_original_confidence_test.cc',
    'tests/graph_route_cuda/CMakeLists.txt',
    'tests/compute_state/deepseek_sparse_prefix_consumer.cc',
    'tests/compute_state/deepseek_sparse_prefix_fixture.h',
    'tests/compute_state/dspark_accepted_prefix_fixture.h',
    'tests/compute_state/dspark_prefix_consumer_test.cc',
    'tests/compute_state/CMakeLists.txt',
]
documents = ['docs/developer/current-work.md', 'docs/implementation/model-operators.md']
for rel in products:
    destination = S / 'source-current' / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((R / rel).read_bytes())
for rel in documents:
    destination = S / 'documentation' / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((R / rel).read_bytes())
save(S / 'source-current/identities.json', [ident(R / path) for path in products])
(S / 'cleanup-script.ps1').write_bytes((R / 'test.ps1').read_bytes())
stdout = (S / 'checks6/stdout.log').read_text(encoding='utf-8')
numeric = [dict(former_single_projection_gate_exceedances=int(a), max_absolute_error=float(b),
                max_F32_bound_ratio=float(c)) for a,b,c in re.findall(
    r'prior_single_projection_gate_exceedances=(\d+) maxAbs=([\deE.+-]+) maxBoundRatio=([\deE.+-]+)', stdout)]
assert len(numeric) == 3 and max(row['max_F32_bound_ratio'] for row in numeric) < 0.0063
report = dict(
    status='IMPLEMENTED_TWO_FINITE_DSPARK_COMPOSITIONS_PASS_NOT_WHOLE_ORIGINAL_MODEL',
    date='2026-10-22', goal_complete=False,
    changes=[ident(R / path) for path in products],
    documentation=[ident(R / path) for path in documents],
    final_checks=checks,
    complete_draft=dict(
        backend='Windows RTX4070 CUDA ordinary Graph', hidden=4096, heads=64, head_depth=512,
        stages=3, proposal_rows=5, full_vocabulary=129280, temperature=0,
        original_roles=['markov_w1.weight BF16[129280,256]', 'markov_w2.weight BF16[129280,256]',
                        'conf_proj.weight BF16[1,4352]'],
        original_role_bytes=132391424,
        generated_roles='Stage parameters, embedding and shared LM are format-valid generated test banks, not trained payloads.',
        cold='One ordinary cold Graph widens LM, W2 and confidence BF16 source to original F32 parameters once; all five rows share those parameters. Full cold outputs checked in bounded chunks.',
        hot='Three submissions reuse one Invocation. Actual produced TopK I32 token_i feeds the next Markov Gather in the same Graph; no teacher token or observed host value is fed between rows.',
        checks='Original six stage/state/hidden outputs retain independent chain oracle; head uses observed BF16-boundary hidden/norm as a separately declared local numerical boundary and independent trained-weight FP64 Neumaier oracle. All IDs/Markov bits match. Prior ten result leases survive pool reuse and Invocation destruction.',
        persistent='Only three verified main-KV rings persist. The five-row proposal KV remains private attention intermediates.'),
    accepted_prefix=dict(
        backend='Windows CPU ordinary Graph with existing matched CPU program and providers',
        target_boundary='Projected attention inputs with F32 storage and explicit original BF16/FP8 boundaries; not complete target layers or packed KV storage.',
        ratio4_target_resources=11, ratio128_target_resources=6,
        additional_resources='Three independent stage main-KV rings and one main_x carry', host_metadata_bytes=28,
        counts='Verify six target inputs: previous pending plus five proposals. Accepted input rows0..6: zero is abort; rows1..6 correspond to matching0..5 drafts. Full acceptance also continues the next seventh projected input.',
        dependencies='Real target Sink output ReadLease feeds a deliberately finite first-head-to-main_x bridge, then original model-linear/Norm/RoPE/cache-quant main-KV updates. Bridge is not checkpoint main_proj.',
        publication='Complete target windows/phase/raw/index caches, three caught-up main rings, carry/frontiers/pending publish as one StateHead candidate. Staged replacement failure and stale-head publication leave committed state unchanged.',
        checks='Every acceptance boundary compared with independent one-input continuation; ring position/wrap has independent projection oracle; untouched rows and prior full snapshot bytes remain unchanged.',
        successful_Graph_submissions_from_completed_fixed_control_flow=54,
        natural_acceptance_driver=False),
    original_markov_acquisition=acquisition,
    original_confidence=read(R / '.scratch/qwen-mtp-next-20261022/original-confidence/acquisition.json'),
    numerical_investigation=dict(
        initial_failure='checks1 applied a single-MatMul empirical relative gate to adjusted LM+Markov logits. Three-stage outputs, all selected IDs and gathered Markov bits passed before this failure.',
        witness=dict(index=259870, LM=0.690673828125, exact_Markov_bias=-0.6583220362663269,
                     sum_absolute_products=87.262913405895233, actual=0.032350540161132812,
                     exact_sum=0.032351791858673096, F32_bound=0.0013420857159967433),
        correction='Original Graph and product math/precision unchanged. Exact BF16 products plus at most256 F32 additions use gamma256*(abs(LM)+sum(abs(products))), with conservative FP64 oracle error. Product representability, a sufficient normal quantum and finite/no-overflow domain are explicitly checked. This is necessary numerical compatibility, not proof of vendor internal reduction.',
        unchanged='Raw confidence retains the previous 1e-6 absolute plus1e-6 relative projection gate. No model precision, token selection, weight data or provider route was changed to pass.',
        final_three_replays=numeric),
    validation_cache_resolution=dict(
        provider_probe=ident(S / 'provider-contracts1/stdout.log'),
        provider_result='Cached oneDNN region14 versus common provider17; all other probed factories17. Recompiled current oneDNN region and the missing CPU graph factory/regions with cached host recipes.',
        runtime_result='The CUDA-derived closure retained an older CPU program without the Hadamard ABI2 field. Reused the already built, source/header-verified ABI2 CPU program object and its known baseline/AVX2 runtime closure. No SDK rebuild or operation substitution.',
        product_diagnostic='Native lowering mismatch now identifies operation name, recipe node and actual/expected output count.'),
    historical_runs=[dict(folder=f'checks{i}', summary=read(S / f'checks{i}/summary.json')) for i in range(1,6)],
    limits=[
        'Two related compositions are checked separately; this is not one natural full proposal->original target verify->accept/catchup journey.',
        'Full original draft/LM parameter bindings, other applicable actual model/quantized roles and complete adapters remain. No new public math/state/loader API was shown necessary.',
        'These new compositions ran on Windows CPU/CUDA only, not Linux, Apple or Vulkan; prior cross-platform Qwen evidence retains its own scope.',
        'No new Qwen ordinary/MTP TPS, memory-peak, model-quality or natural acceptance-rate comparison was run. Current-work AV performance table remains authoritative for its own image/window.',
        'Standalone previous target-prefix main was recompiled after helper extraction; its previous full acceptance matrix was not rerun. Current new two target-prefix cases execute the extracted target graph and same route.',
    ],
    cleanup=cleanup, retained_image=checks['image'],
    SDK_builds=0, NVCC_builds=0, shader_builds=0, public_API_changed=False,
)
save(S / 'report-before-archive.json', report)
selected = [path for path in S.rglob('*') if path.is_file() and
            path.suffix.lower() in {'.json','.py','.cc','.h','.diff','.log','.xml','.txt','.ps1'} and
            '__pycache__' not in path.parts and 'tmp' not in path.parts]
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(selected):
        archive.write(path, path.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist()))
    assert archive.testzip() is None
report['archived_sources_commands_results_and_cleanup'] = ident(ZIP)
report['large_role_payloads_in_archive'] = False
save(OUT, report)
receipt = dict(result=ident(OUT), logs=ident(ZIP), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
