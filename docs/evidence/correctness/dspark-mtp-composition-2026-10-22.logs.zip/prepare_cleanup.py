"""Write exact obsolete exe/map deletion targets to root test.ps1; no deletion."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
keep = S / 'tests-link9'
entries = []
for folder in sorted(S.glob('tests-link*')):
    if folder == keep:
        continue
    for name in ['dspark-checks.exe', 'dspark-checks.map']:
        path = folder / name
        if path.is_file():
            assert path.resolve().is_relative_to(S)
            entries.append(dict(path=str(path), bytes=path.stat().st_size,
                                sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
plan = dict(root=str(S), keep=str(keep), entries=entries,
            bytes=sum(item['bytes'] for item in entries), recursive=False)
(S / 'cleanup-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
script = r'''$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/dspark-mtp-integration-20261022').Path
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$prefix = $taskRoot.TrimEnd('\') + '\'
$keep = [System.IO.Path]::GetFullPath($plan.keep)
$targets = @($plan.entries)
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $targets) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if (-not $target.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside task root: $target" }
    if ((Split-Path -Parent $target) -eq $keep) { throw "Current image protected: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe', '.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = $targets
    Bytes = $plan.bytes
    CurrentImageRetained = (Test-Path -LiteralPath (Join-Path $keep 'dspark-checks.exe'))
    CurrentMapRetained = (Test-Path -LiteralPath (Join-Path $keep 'dspark-checks.map'))
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object Bytes, CurrentImageRetained, CurrentMapRetained
'''
(R / 'test.ps1').write_text(script, encoding='utf-8')
print(json.dumps(dict(files=len(entries), bytes=plan['bytes'], paths=[item['path'] for item in entries]), indent=2))
