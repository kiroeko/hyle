#pragma once

#include "cpu_c4_model_branches.h"

#include <bit>
#include <cstring>
#include <span>

// Test-only composition of the existing full Flash draft and its actual
// five-row greedy feedback. No executor, teacher tape or model-specific API.
namespace dspark_complete_graph {
namespace base = cpu_c4_model_branches;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace c = hyle::compute;
using sem::ValueId;
inline constexpr std::int64_t hidden = 4096, rank = 256;
inline constexpr auto rows = base::block, vocabulary = base::vocabulary;

enum Input : std::size_t {
  kMain, kFirst, kMainPosition, kDraftPositions, kWriting, kMask,
  kCache0, kCache1, kCache2, kInputs
};
enum Output : std::size_t {
  kState, kNextCache0, kNextCache1, kNextCache2, kHidden, kNormalized,
  kIds, kMarkov, kLogits, kConfidence, kOutputs
};
struct HeadParameters final {
  std::span<const std::uint16_t> markov_w1_bf16{}, markov_w2_bf16{}, confidence_bf16{};
};
struct ColdWidening final {
  std::size_t output;
  ValueId source;
};
struct CompleteProgram final {
  sem::Fragment fragment;
  // Cold F32 outputs can be checked in bounded chunks against their actual
  // BF16 source, without an additional 2GiB host F32 LM reference bank.
  std::vector<ColdWidening> cold_widenings;
};
inline std::uint16_t encode(float value) {
  auto bits = std::bit_cast<std::uint32_t>(value);
  bits += 0x7fffu + ((bits >> 16u) & 1u);
  return static_cast<std::uint16_t>(bits >> 16u);
}
inline float widen(std::uint16_t bits) {
  return std::bit_cast<float>(std::uint32_t{bits} << 16u);
}

// The old sparse BF16-source construction rule, applied to one complete
// vocabulary bank shared by all five rows. Shard-local seeds are not reused.
// This is a
// generated test LM, never claimed to be an original trained LM payload.
inline std::size_t lm_column(std::size_t token) {
  return (17 * token + 491) % hidden;
}
inline float lm_coefficient(std::size_t token) {
  return widen(encode(0.5F + float((token + 491) % 13) / 32.0F));
}
inline std::vector<float> lm_reference(std::span<const float> normalized) {
  if (normalized.size() != std::size_t(rows * hidden))
    throw std::runtime_error("DSpark LM reference input extent");
  std::vector<float> result(rows * vocabulary);
  for (std::size_t row = 0; row < std::size_t(rows); ++row)
    for (std::size_t token = 0; token < std::size_t(vocabulary); ++token)
      result[row * vocabulary + token] = float(
          double(normalized[row * hidden + lm_column(token)]) * lm_coefficient(token));
  return result;
}

// Remove only the former teacher-fed Markov/confidence branch. The original
// three stages, their constants, six outputs and independent oracle remain.
inline void remove_teacher_branch(sem::Fragment &f) {
  f.outputs.resize(kIds);
  std::vector<bool> live(f.descriptions.size());
  for (auto value : f.outputs) live[value.ordinal()] = true;
  std::vector<bool> needed(f.nodes.size());
  for (std::size_t i = f.nodes.size(); i-- > 0;) {
    for (auto output : f.nodes[i].outputs) needed[i] = needed[i] || live[output.ordinal()];
    if (needed[i]) for (auto input : f.nodes[i].inputs) live[input.ordinal()] = true;
  }
  std::vector<sem::recipe::DirectNode> nodes;
  for (std::size_t i = 0; i < f.nodes.size(); ++i)
    if (needed[i]) nodes.push_back(std::move(f.nodes[i]));
  f.nodes = std::move(nodes);
  std::vector<ValueId> constants;
  std::vector<std::vector<std::byte>> payloads;
  const auto old_prepared = f.prepared_constants;
  std::vector<std::size_t> slots(f.constants.size(),std::numeric_limits<std::size_t>::max());
  for (std::size_t i = 0; i < f.constants.size(); ++i) {
    const auto found = std::find(f.prepared_constants.begin(), f.prepared_constants.end(), i);
    if (!live[f.constants[i].ordinal()]) {
      if (found != f.prepared_constants.end())
        throw std::runtime_error("teacher removal would discard a stage cold parameter");
      continue;
    }
    slots[i]=constants.size();
    constants.push_back(f.constants[i]);
    payloads.push_back(std::move(f.constant_bytes[i]));
  }
  f.constants = std::move(constants); f.constant_bytes = std::move(payloads);
  f.prepared_constants.clear();
  for (const auto old_slot : old_prepared) f.prepared_constants.push_back(slots[old_slot]);
  if (f.inputs.size() != 10 || live[f.inputs[2].ordinal()])
    throw std::runtime_error("unexpected complete draft teacher boundary");
  f.inputs.erase(f.inputs.begin() + 2);
  f.state_ports = {{kCache0, kNextCache0}, {kCache1, kNextCache1}, {kCache2, kNextCache2}};
  f.exact_outputs.clear();
  for (auto &replay : f.replays) {
    replay.inputs.erase(replay.inputs.begin() + 2);
    replay.outputs.resize(kIds);
  }
}

inline std::vector<std::byte> parameter_bytes(std::span<const std::uint16_t> source,
                                             std::int64_t n, std::int64_t k, int seed) {
  if (!source.empty()) {
    if (source.size() != std::size_t(n * k))
      throw std::runtime_error("DSpark injected BF16 role extent mismatch");
    return sem::bytes(source);
  }
  std::vector<std::byte> result(std::size_t(n * k) * sizeof(std::uint16_t));
  for (std::int64_t row = 0; row < n; ++row) {
    const auto column = (17 * row + seed) % k;
    const auto value = encode(0.5F + float((row + seed) % 13) / 32.0F);
    std::memcpy(result.data() + (row * k + column) * sizeof(value), &value, sizeof(value));
  }
  return result;
}
inline ValueId cold_f32(CompleteProgram &program, std::int64_t n, std::int64_t k,
                        std::vector<std::byte> source) {
  auto &f = program.fragment;
  if (f.preparation && f.preparation.use_count() != 1)
    throw std::runtime_error("complete DSpark cold bank is not uniquely owned");
  auto cold = f.preparation ? std::const_pointer_cast<sem::Fragment>(f.preparation)
                           : std::make_shared<sem::Fragment>(sem::Fragment{.profile=f.profile,.region=0x0c04010b});
  if (cold->replays.empty()) cold->replays.push_back({{}, {}});
  const auto stored = cold->constant(sem::dense({n,k}, c::DataType::kBFloat16), std::move(source));
  const auto output = cold->one(c::Operation(c::Cast{c::DataType::kFloat32}), {stored});
  program.cold_widenings.push_back({cold->outputs.size(), stored});
  cold->outputs.push_back(output);
  // These large outputs use the chunked source-byte checker instead of
  // materializing a second dense F32 expected payload in Replay.
  cold->replays[0].outputs.emplace_back();
  f.preparation = std::move(cold);
  f.prepared_constants.push_back(f.constants.size());
  return f.constant(sem::dense({n,k}), {});
}

inline CompleteProgram build_flash(HeadParameters parameters = {}) {
  auto original = base::complete_draft(base::models[1]);
  CompleteProgram result{std::move(original.fragment), {}};
  auto &f = result.fragment;
  remove_teacher_branch(f);
  f.region = 0x0c04010a;
  const auto table = f.constant(sem::dense({vocabulary,rank}, c::DataType::kBFloat16),
      parameter_bytes(parameters.markov_w1_bf16, vocabulary, rank, 419));
  const auto lm = base::ds::permute(f, cold_f32(result, vocabulary, hidden,
      parameter_bytes({}, vocabulary, hidden, 491)), {1,0});
  const auto mw = base::ds::permute(f, cold_f32(result, vocabulary, rank,
      parameter_bytes(parameters.markov_w2_bf16, vocabulary, rank, 431)), {1,0});
  const auto cw = base::ds::permute(f, cold_f32(result, 1, hidden+rank,
      parameter_bytes(parameters.confidence_bf16, 1, hidden+rank, 409)), {1,0});
  const auto base_logits = f.one(c::Operation(c::MatMul{}), {f.outputs[kNormalized],lm});
  std::array<ValueId,rows+1> ids;
  std::array<ValueId,rows> embeddings, logits, confidence;
  ids[0] = f.inputs[kFirst];
  for (std::size_t row = 0; row < std::size_t(rows); ++row) {
    // This index is the real preceding TopK output within this same Graph.
    embeddings[row] = f.one(c::Operation(c::Gather{}), {table,ids[row]});
    const auto markov = f.one(c::Operation(c::Cast{c::DataType::kFloat32}), {embeddings[row]});
    const auto bias = f.one(c::Operation(c::MatMul{}), {markov,mw});
    logits[row] = base::core::binary(f,c::BinaryKind::kAdd,
        base::ds::slice(f,base_logits,0,std::int64_t(row),1),bias);
    auto top = f.append(c::Operation(c::TopK{.count=1,.stable=true}), {logits[row]}, 2);
    ids[row+1] = base::core::reshape(f,top[1],{1});
    // Source confidence is raw F32; sigmoid is a separate sidecar policy.
    const auto joined = base::ds::concat(f,
        base::ds::slice(f,f.outputs[kHidden],0,std::int64_t(row),1),markov,1);
    confidence[row] = f.one(c::Operation(c::MatMul{}), {joined,cw});
  }
  auto concatenate = [&](const auto &values) {
    auto output = values[0];
    for (std::size_t i=1;i<values.size();++i) output=base::ds::concat(f,output,values[i],0);
    return output;
  };
  f.outputs.push_back(concatenate(ids));
  f.outputs.push_back(concatenate(embeddings));
  f.outputs.push_back(concatenate(logits));
  f.outputs.push_back(concatenate(confidence));
  // Only 1..3 are persistent main KV. Each stage's five proposal KV rows
  // remain private intermediates of its attention, never a published state.
  return result;
}
} // namespace dspark_complete_graph
