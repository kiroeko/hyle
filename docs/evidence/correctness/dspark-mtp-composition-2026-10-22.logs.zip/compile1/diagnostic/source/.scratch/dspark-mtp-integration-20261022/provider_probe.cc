#include <cstdio>
#include "hyle/compute/providers/native.h"
#include "hyle/compute/providers/onednn.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/providers/onednn.h"
#include "src/compute/provider_internal.h"
#include "src/compute_provider_native/default_rules.h"
#include "src/compute_provider_native/torch_cpu_program.h"
#include "src/graph_route_cpu/ggml_region.h"

int main() {
  namespace c = hyle::compute;
  const auto show = [](const char *name, const c::Provider &provider) {
    const auto table = c::detail::ProviderAccess::vtable(provider);
    std::printf("%s contract=%u expected=%u\n", name,
                table ? table->contract_version : 0, c::detail::kProviderContractVersion);
  };
  show("onednn-leaf", c::onednn::provider());
  show("ggml-leaf", c::ggml_cpu::provider());
  show("aten-leaf", c::aten_cpu::provider());
  show("native-default", c::native::internal::default_provider(
      {}, c::native::internal::DefaultRuleScope::kGraph, true));
  show("onednn-region", hyle::graph::onednn::provider());
  show("ggml-region", hyle::graph::cpu::internal::ggml_regions({}));
}
