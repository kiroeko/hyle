from pathlib import Path
p=Path('tests/compute_state/deepseek_sparse_prefix_consumer.cc')
s=p.read_text()
body, main=s.split('int main(int argc, char **argv) {',1)
body=body.replace('namespace {\n','namespace deepseek_sparse_prefix_fixture {\n',1)
body=body.replace('} // namespace\n','} // namespace deepseek_sparse_prefix_fixture\n')
# Standalone consumers and combined gtests share one definition of each helper.
for signature in ('Status require(', 'c::TensorDesc dense(', 'std::array<c::TensorDesc, kStates> state_descriptions(',
                  'std::array<c::TensorDesc, 9> token_descriptions(', 'ValueId copy(', 'ValueId write_row(',
                  'ValueId replace_cache(', 'sem::Fragment make_fragment(', 'Cursor cursor(', 'Status close(', 'Status run('):
    body=body.replace(signature,'inline '+signature)
body=body.replace('double state_max_error = 0, oracle_max_error = 0;','inline double state_max_error = 0, oracle_max_error = 0;')
# Share setup rather than copy its state/feature generation into the new consumer.
a=body.index('  const auto descriptions = state_descriptions(mode);', body.index('inline Status run('))
b=body.index('  std::vector<c::StateEntrySpec> specs;',a)
setup=body[a:b]
setup=setup.replace('  const auto inputs = [&](const std::vector<c::ReadLease> &state, int first, int count) -> Result<std::vector<c::ReadLease>> {\n    auto result = state;\n    for (const auto p : token_roles) {\n      const auto row_bytes = tokens[p].size() / kTokens;\n      HYLE_ASSIGN_OR_RETURN(auto selected, tokens[p].subview(first * row_bytes, count * row_bytes)); result.push_back(std::move(selected));\n    }\n    return result;\n  };\n','')
setup=setup.replace('  std::array<std::vector<float>, kStates> initial;\n  std::vector<c::ReadLease> base_values;\n','')
setup=setup.replace('  std::array<std::vector<float>, 8> features;\n','').replace('  std::array<c::ReadLease, 9> tokens;\n','')
for name in ('initial','base_values','features','tokens'):
    import re
    setup=re.sub(r'\b'+name+r'\b','result.'+name,setup)
helper='''struct PreparedInputs final {
  std::array<std::vector<float>, kStates> initial;
  std::vector<c::ReadLease> base_values;
  std::array<std::vector<float>, 8> features;
  std::array<c::ReadLease, 9> tokens;
  Result<std::vector<c::ReadLease>> inputs(const Case &mode,
      std::span<const c::ReadLease> state, int first, int count) const {
    HYLE_RETURN_IF_ERROR(require(first >= 0 && count > 0 && first + count <= kTokens,
                                "projected target token interval"));
    std::vector<c::ReadLease> result(state.begin(), state.end());
    for (const auto role : mode.tokens()) {
      const auto row_bytes = tokens[role].size() / kTokens;
      HYLE_ASSIGN_OR_RETURN(auto selected, tokens[role].subview(
          std::size_t(first) * row_bytes, std::size_t(count) * row_bytes));
      result.push_back(std::move(selected));
    }
    return result;
  }
};
inline Result<PreparedInputs> prepare_inputs(Route &route, const Case &mode) {
  PreparedInputs result;
  const auto state_roles = mode.states(), token_roles = mode.tokens();
'''+setup+'''  return result;
}

'''
# helper uses cursor(), and is inserted after cursor/close before run.
point=body.index('inline Status run(')
body=body[:point]+helper+body[point:]
a=body.index('  const auto descriptions = state_descriptions(mode);',body.index('inline Status run('))
b=body.index('  std::vector<c::StateEntrySpec> specs;',a)
body=body[:a]+'''  const auto descriptions = state_descriptions(mode);
  HYLE_ASSIGN_OR_RETURN(auto prepared, prepare_inputs(route, mode));
  auto &initial = prepared.initial;
  auto &base_values = prepared.base_values;
  auto &features = prepared.features;
  const auto inputs = [&](const std::vector<c::ReadLease> &state, int first, int count) {
    return prepared.inputs(mode, state, first, count);
  };
'''+body[b:]
Path('tests/compute_state/deepseek_sparse_prefix_fixture.h').write_text('#pragma once\n\n'+body)
p.write_text('#include "deepseek_sparse_prefix_fixture.h"\n\nint main(int argc, char **argv) {\n  using namespace deepseek_sparse_prefix_fixture;'+main)
