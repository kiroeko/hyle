from pathlib import Path
import hashlib,json,difflib,re
stage=Path('.scratch/dspark-mtp-integration-20261022/accepted-prefix')
old=(stage/'before/tests/compute_state/deepseek_sparse_prefix_consumer.cc').read_text()
header=Path('tests/compute_state/deepseek_sparse_prefix_fixture.h').read_text()
# Restore the factored setup and remove only header/ODR syntax to prove the
# previous target graph, Route, oracle and whole old run remain byte-for-byte.
old_body=old.split('int main(int argc, char **argv) {',1)[0]
a=old_body.index('  const auto descriptions = state_descriptions(mode);',old_body.index('Status run('))
b=old_body.index('  std::vector<c::StateEntrySpec> specs;',a)
old_setup=old_body[a:b]
reconstructed=header.removeprefix('#pragma once\n\n')
a=reconstructed.index('struct PreparedInputs final {')
b=reconstructed.index('inline Status run(',a)
reconstructed=reconstructed[:a]+reconstructed[b:]
a=reconstructed.index('  const auto descriptions = state_descriptions(mode);',reconstructed.index('inline Status run('))
b=reconstructed.index('  std::vector<c::StateEntrySpec> specs;',a)
reconstructed=reconstructed[:a]+old_setup+reconstructed[b:]
reconstructed=reconstructed.replace('namespace deepseek_sparse_prefix_fixture {','namespace {',1).replace('} // namespace deepseek_sparse_prefix_fixture','} // namespace')
reconstructed=re.sub(r'^inline ', '', reconstructed, flags=re.M)
assert reconstructed==old_body, 'original target graph/Route/oracle/run drifted beyond data setup extraction'
paths=['tests/compute_state/deepseek_sparse_prefix_consumer.cc','tests/compute_state/deepseek_sparse_prefix_fixture.h','tests/compute_state/dspark_accepted_prefix_fixture.h','tests/compute_state/dspark_prefix_consumer_test.cc']
files=[];patch=[]
for name in paths:
 p=Path(name);data=p.read_bytes();dest=stage/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 files.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 baseline=(stage/'before'/name)
 patch.extend(difflib.unified_diff(baseline.read_text().splitlines(True) if baseline.exists() else [],p.read_text().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
(stage/'implementation.diff').write_text(''.join(patch))
report={'scope':'source-only projected-boundary accepted-prefix fixture; no compilation/native execution',
 'tests':['DSparkAcceptedPrefix.Ratio4TargetIndexAndThreeMainRingsPublishAtomically','DSparkAcceptedPrefix.Ratio128HalfWindowsAndThreeMainRingsPublishAtomically'],
 'source':files,'original_target_graph_route_oracle_and_run_unchanged_after_setup_reconstruction':True,
 'full_states':{'ratio4':'11 target resources +3 stage main-KV rings +carry +28B metadata','ratio128':'6 target resources +3 stage main-KV rings +carry +28B metadata'},
 'counts':{'verify_inputs':6,'matched_draft_outcomes':'0..5 correspond to accepted input rows1..6; row0 abort','actual_graph_submissions_per_test':27,'actual_graph_submissions_both_tests':54},
 'checks':['target block-selected prefix versus original one-row target state','three real Graph FP8/Norm/RoPE/QAT main-KV updates per prefix','independent projection/position/ring-wrap oracle','unchanged old snapshot bytes','untouched ring rows exact','actual finite target score/TopK fresh pending','atomic StateDraft+StateHead publication','wrong-extent staged replacement rejected without partial head publish','stale head identity rejected','one-row state continuation after all-five accepted'],
 'limits':['Injected accepted-prefix selector counts; no natural acceptance-rate claim','Finite target Sink->4096 main_x bridge, not original three-selected-layer main_proj or43-layer target','Token projections are existing external fixture boundary, not original embedding/greedy token ledger','Three-stage proposal+full-vocabulary head is another component; this fixture does not run it','No packedBF16/paged/full-payload/Graph-fault-injection/cancellation claim'],
 'evidence':{'shared_KV_branch':'tests/compute_models/cpu_c4_model_branches.h:239-248 seed443','fixed_GA_decode_main_x':'inference-model.py:752-785 accepts one decode main row; proposal KV temporary','StateHead':'include/hyle/compute/state_versions.h:177-189'},
 'build':'parent only; CMake registration owned by root; new gtest source uses same CPU Graph Route as original main'}
(stage/'report.json').write_text(json.dumps(report,indent=2)+'\n')
freeze={'status':'frozen-source-only-no-build','files':files,'report_sha256':hashlib.sha256((stage/'report.json').read_bytes()).hexdigest(),'diff_sha256':hashlib.sha256((stage/'implementation.diff').read_bytes()).hexdigest()}
(stage/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(freeze,indent=2))
