from pathlib import Path
p=Path('tests/compute_state/dspark_accepted_prefix_fixture.h')
s=p.read_text().replace('    for (std::size_t i = 0; i < result.size(); ++i)\n      HYLE_ASSIGN_OR_RETURN(result[i], version.member(entries[ring_entry() + i]));', '    for (std::size_t i = 0; i < result.size(); ++i) {\n      HYLE_ASSIGN_OR_RETURN(result[i], version.member(entries[ring_entry() + i]));\n    }')
p.write_text(s)
p=Path('tests/compute_state/dspark_prefix_consumer_test.cc')
s=p.read_text().replace('// proposals. No proposal-local KV is accepted as a persistent main-KV row.','// proposals. These are injected selector outcomes, not measured acceptance.\n// Token projections are supplied at the existing fixture boundary. No\n// proposal-local KV is accepted as a persistent main-KV row.')
s=s.replace('// the block-selected and one-input reference then consume the next row via\n  // the same original Graph route and atomically publish every state member.','// the block-selected and one-input reference then evaluate the next supplied\n  // projected row via the same Graph route and publish every state member.\n  // This is a state continuation check, not a claim that the finite bridge\n  // implements original target embeddings or a natural greedy token ledger.')
p.write_text(s)
