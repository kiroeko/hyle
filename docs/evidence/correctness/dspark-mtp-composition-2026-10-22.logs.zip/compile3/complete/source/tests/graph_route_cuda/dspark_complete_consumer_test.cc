#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <span>
#include <string>
#include <type_traits>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/storage_owner.h"
#include "hyle/graph/cuda.h"
#include "../compute_models/dspark_complete_graph_fixture.h"
#include "../compute_models/dspark_original_roles.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace fixture = dspark_complete_graph;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace original = dspark_original_roles;
using Bytes = std::vector<std::byte>;
static_assert(std::is_same_v<decltype(std::declval<const c::ReadLease &>().view()),
                             hyle::Result<m::ConstBufferView>>);

template<class T> T take(hyle::Result<T> result, std::string_view where) {
  if (!result) throw std::runtime_error(std::string(where)+": "+std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status, std::string_view where) {
  if (!status.ok()) throw std::runtime_error(std::string(where)+": "+std::string(status.message()));
}
c::WorkloadContext workload(const sem::Fragment &fragment) {
  return {take(c::ModelArtifactProfile::create(*fragment.profile), "actual DSpark profile"),
          fragment.phase, {0x48594c454d4f444cULL, fragment.region, 1}};
}
std::string environment(const char *name) {
#if defined(_WIN32)
  char *value = nullptr; std::size_t size = 0;
  if (_dupenv_s(&value, &size, name) != 0) throw std::runtime_error("cannot read original-role environment");
  const std::unique_ptr<char, decltype(&std::free)> owner(value, &std::free);
  return value ? value : "";
#else
  const auto value = std::getenv(name); return value ? value : "";
#endif
}
m::Buffer buffer(const c::StorageOwner &owner, std::size_t size) {
  return take(m::Buffer::create(owner.ref(),size,256),"real device allocation");
}
c::ReadLease upload(const c::StorageOwner &owner, std::span<const std::byte> bytes) {
  auto output = buffer(owner,bytes.size());
  check(output.view().write(bytes),"upload actual immutable input");
  return take(c::ReadLease::adopt(std::move(output)),"own input permission");
}
Bytes read(const c::ReadLease &lease) {
  Bytes output(lease.size());
  check(take(lease.view(),"readonly independent view").read(output),"read actual result");
  return output;
}
template<class T> std::vector<T> decode(const Bytes &bytes) {
  if (bytes.size()%sizeof(T)) throw std::runtime_error("typed result byte extent");
  std::vector<T> output(bytes.size()/sizeof(T));
  std::memcpy(output.data(),bytes.data(),bytes.size()); return output;
}

// One cold Graph prepares every original stage output parameter and losslessly
// widens the shared BF16 LM/Markov/confidence sources. Nothing is rebuilt per
// replay. Check its outputs in bounded chunks, including the complete LM bank.
std::vector<m::Buffer> prepare_constants(fixture::CompleteProgram &program,
    c::Context &context, const c::StorageOwner &owner, c::Queue &queue) {
  const auto &cold = *program.fragment.preparation;
  if (!cold.inputs.empty() || cold.preparation) throw std::runtime_error("unexpected nested cold program");
  const auto logical = sem::make_graph(cold);
  std::vector<m::Buffer> sources, outputs;
  std::vector<g::ConstantBinding> constants;
  for (std::size_t i=0;i<cold.constants.size();++i) {
    sources.push_back(buffer(owner,cold.constant_bytes[i].size()));
    check(sources.back().view().write(cold.constant_bytes[i]),"cold source upload");
    constants.push_back({logical.constants[i],take(c::ConstTensorView::create(
        cold.description(cold.constants[i]),sources.back().view()),"cold immutable binding")});
  }
  auto compiled = take(g::cuda::compile(logical.graph,context,owner,
      {.constants=constants,.workload=workload(cold)}),"single cold parameter Graph");
  auto run = take(compiled.executable.create_invocation(),"cold Invocation");
  for (std::size_t i=0;i<cold.outputs.size();++i) {
    const auto &desc = cold.description(cold.outputs[i]);
    outputs.push_back(buffer(owner,take(desc.required_bytes(),"cold output extent")));
    check(run.bind(logical.outputs[i],take(c::TensorView::create(desc,outputs.back().view()),"cold output view")),"bind cold output");
  }
  check(g::cuda::prepare_replay(run,queue,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}),"prepare cold Graph");
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
  {
    auto completion = take(run.submit(queues),"strict cold Graph submission");
    check(completion.wait(),"cold actual retirement");
  }
  constexpr std::size_t chunk_elements = 262144;
  for (std::size_t port=0;port<outputs.size();++port) {
    const auto type = cold.description(cold.outputs[port]).data_type();
    const std::size_t width = type==c::DataType::kFloat32 ? 4 : 2;
    if (type!=c::DataType::kFloat32 && type!=c::DataType::kBFloat16)
      throw std::runtime_error("unexpected DSpark cold output dtype");
    const auto widening = std::find_if(program.cold_widenings.begin(),program.cold_widenings.end(),
        [&](const auto &entry){return entry.output==port;});
    const Bytes *source = nullptr;
    if (widening!=program.cold_widenings.end()) {
      const auto it = std::find_if(cold.constants.begin(),cold.constants.end(),
          [&](auto value){return value.ordinal()==widening->source.ordinal();});
      if (it==cold.constants.end() || type!=c::DataType::kFloat32)
        throw std::runtime_error("cold BF16 source metadata mismatch");
      source=&cold.constant_bytes[std::size_t(it-cold.constants.begin())];
      if (source->size()*2!=outputs[port].size()) throw std::runtime_error("cold widening extent mismatch");
    } else if (cold.replays.at(0).outputs.at(port).size()*width!=outputs[port].size()) {
      throw std::runtime_error("stage cold oracle extent mismatch");
    }
    const auto elements=outputs[port].size()/width;
    for (std::size_t first=0;first<elements;first+=chunk_elements) {
      const auto count=std::min(chunk_elements,elements-first);
      Bytes chunk(count*width);
      check(take(outputs[port].view().subview(first*width,chunk.size()),"cold chunk").read(chunk),"read cold parameter chunk");
      for (std::size_t i=0;i<count;++i) {
        float actual;
        if (type==c::DataType::kFloat32) std::memcpy(&actual,chunk.data()+i*width,4);
        else {std::uint16_t bits;std::memcpy(&bits,chunk.data()+i*width,2);actual=fixture::widen(bits);}
        float expected;
        if (source) {std::uint16_t bits;std::memcpy(&bits,source->data()+(first+i)*2,2);expected=fixture::widen(bits);}
        else expected=cold.replays[0].outputs[port][first+i];
        if (actual!=expected) throw std::runtime_error("cold parameter mismatch at output "+std::to_string(port)+" element "+std::to_string(first+i));
      }
    }
  }
  return outputs;
}

bool projection_equal(std::span<const float> actual,std::span<const float> expected,
                      std::string_view name) {
  if (actual.size()!=expected.size()) {ADD_FAILURE()<<name<<" extent";return false;}
  for (std::size_t i=0;i<actual.size();++i) {
    // Existing F32 projection gate, cublas_provider_test.cc:151. The BF16
    // multi-stage allowance is used ONLY above this head's explicit boundary.
    const double tolerance=1.0e-6*std::abs(double(expected[i]))+1.0e-6;
    if (!std::isfinite(actual[i]) || std::abs(double(actual[i])-expected[i])>tolerance) {
      ADD_FAILURE()<<name<<"["<<i<<"] actual="<<actual[i]<<" reference="<<expected[i]<<" tolerance="<<tolerance;
      return false;
    }
  }
  return true;
}

bool adjusted_logits_equal(std::span<const float> actual,
    std::span<const float> base_logits, const original::HeadReference &expected) {
  if (actual.size() != expected.exact_logits.size()) {
    ADD_FAILURE() << "adjusted logit extent";
    return false;
  }
  // Each trained Markov product is exact in F32 (two BF16 operands), and
  // this generated LM has one exact BF16 product per logit. There are 257
  // exact terms and at most256 F32 additions, including the final Add.
  // A single-projection relative gate on their possibly cancelling result
  // does not propagate reduction error. Keep the ORIGINAL Graph unchanged.
  constexpr double u32 = 0x1p-24, u64 = 0x1p-53;
  constexpr double gamma32 = 256 * u32 / (1 - 256 * u32);
  constexpr double gamma64 = 256 * u64 / (1 - 256 * u64);
  std::size_t former_gate_exceedances = 0;
  double maximum_error = 0, maximum_ratio = 0;
  for (std::size_t i = 0; i < actual.size(); ++i) {
    const double error = std::abs(double(actual[i]) - expected.exact_logits[i]);
    const double terms_upper = expected.logit_absolute_terms[i] / (1 - gamma64);
    const double bound = std::nextafter((gamma32 + gamma64) * terms_upper,
                                       std::numeric_limits<double>::infinity());
    maximum_error = std::max(maximum_error, error);
    maximum_ratio = std::max(maximum_ratio, bound ? error / bound : 0);
    if (!std::isfinite(actual[i]) || error > bound) {
      ADD_FAILURE() << "adjusted logit[" << i << "] actual=" << actual[i]
                    << " exact=" << expected.exact_logits[i]
                    << " error=" << error << " F32 reduction bound=" << bound;
      return false;
    }
    const double old_gate = 1.0e-6 * std::abs(double(expected.logits[i])) + 1.0e-6;
    if (std::abs(double(actual[i]) - expected.logits[i]) > old_gate) {
      if (former_gate_exceedances++ == 0)
        std::printf("DSpark composed logit index=%zu L=%.17g B=%.17g S=%.17g actual=%.17g exact=%.17g bound=%.17g\n",
            i, double(base_logits[i]), expected.exact_bias[i],
            expected.bias_absolute_products[i], double(actual[i]), expected.exact_logits[i], bound);
    }
  }
  std::printf("DSpark composed F32 logits: prior_single_projection_gate_exceedances=%zu maxAbs=%.17g maxBoundRatio=%.17g\n",
              former_gate_exceedances, maximum_error, maximum_ratio);
  return true;
}

TEST(CudaDSparkComplete, FullFlashStagesFeedOriginalMarkovGreedyRowsAndRetainPriorState) {
  const auto markov_directory=environment("HYLE_DSPARK_MARKOV_DIR");
  const auto confidence_path=environment("HYLE_DSPARK_CONFIDENCE_BF16");
  if (markov_directory.empty() || confidence_path.empty())
    GTEST_SKIP()<<"Set HYLE_DSPARK_MARKOV_DIR and HYLE_DSPARK_CONFIDENCE_BF16 to fixed authenticated roles";
  const auto roles=original::load(markov_directory,confidence_path);
  auto program=fixture::build_flash({roles.w1,roles.w2,roles.confidence});
  auto &fragment=program.fragment;
  ASSERT_EQ(fragment.inputs.size(),fixture::kInputs);
  ASSERT_EQ(fragment.outputs.size(),fixture::kOutputs);
  ASSERT_EQ(fragment.replays.size(),3u);
  auto context=take(g::cuda::create_context(),"default CUDA context");
  const auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(
      context,c::cuda::MemoryKind::kDevice),"device resource")),"real allocation domain");
  auto queue=take(context.create_queue(),"one original Queue");
  std::vector<m::Buffer> prepared;
  {
    prepared=prepare_constants(program,context,owner,queue);
    ASSERT_EQ(prepared.size(),fragment.prepared_constants.size());
  } // Cold Graph/source buffers are gone before compiling the hot program.
  fragment.preparation.reset();
  const auto logical=sem::make_graph(fragment);
  std::vector<m::Buffer> parameters(fragment.constants.size());
  std::vector<g::ConstantBinding> constants;
  for (std::size_t i=0;i<parameters.size();++i) {
    const auto slot=std::find(fragment.prepared_constants.begin(),fragment.prepared_constants.end(),i);
    if (slot!=fragment.prepared_constants.end()) parameters[i]=std::move(prepared[std::size_t(slot-fragment.prepared_constants.begin())]);
    else {
      parameters[i]=buffer(owner,fragment.constant_bytes[i].size());
      check(parameters[i].view().write(fragment.constant_bytes[i]),"one-time stage constant upload");
    }
    constants.push_back({logical.constants[i],take(c::ConstTensorView::create(
        fragment.description(fragment.constants[i]),parameters[i].view()),"immutable hot constant")});
  }
  fragment.constant_bytes.clear();
  auto compiled=take(g::cuda::compile(logical.graph,context,owner,
      {.constants=constants,.workload=workload(fragment)}),"full three-stage and feedback Graph");
  std::array<c::TensorDesc,fixture::kOutputs> descriptions;
  std::size_t generation_bytes=0;
  for (std::size_t i=0;i<descriptions.size();++i) {
    descriptions[i]=fragment.description(fragment.outputs[i]);
    const auto bytes=take(descriptions[i].required_bytes(),"published extent");
    generation_bytes+=(bytes+255u)/256u*256u;
    ASSERT_EQ(take(compiled.executable.output_ownership(i),"output ownership"),g::OutputOwnership::kCaller);
  }
  ASSERT_EQ(descriptions[fixture::kIds].data_type(),c::DataType::kInt32);
  ASSERT_EQ(descriptions[fixture::kMarkov].data_type(),c::DataType::kBFloat16);
  auto pool=take(c::LeasePool::create(owner.ref(),generation_bytes*2,
      {.max_blocks=fixture::kOutputs*2,.backing_alignment=256}),"bounded two-generation result pool");
  std::array<c::ReadLease,fixture::kOutputs> oldest;
  std::array<Bytes,fixture::kOutputs> oldest_bytes;
  {
    auto run=take(compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"single reused Invocation");
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
    for (std::size_t step=0;step<fragment.replays.size();++step) {
      SCOPED_TRACE(step);
      const auto &expected=fragment.replays[step];
      ASSERT_EQ(expected.outputs.size(),fixture::kIds);
      for (std::size_t i=0;i<fragment.inputs.size();++i) {
        c::ReadLease input;
        if (!expected.reset_state && i>=fixture::kCache0)
          input=oldest[fixture::kNextCache0+i-fixture::kCache0];
        else input=upload(owner,expected.inputs[i]);
        check(run.bind(logical.inputs[i],fragment.description(fragment.inputs[i]),std::move(input)),"bind actual stage input or previous mainKV lease");
      }
      for (std::size_t i=0;i<descriptions.size();++i)
        check(run.bind(logical.outputs[i],descriptions[i],take(pool.allocate(
            take(descriptions[i].required_bytes(),"new output bytes")),"fresh whole result writer")),"bind new result permission");
      check(g::cuda::prepare_replay(run,queue,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}),"prepare complete ordinary Graph");
      {
        auto completion=take(run.submit(queues),"strict complete Graph submit");
        check(completion.wait(),"real complete retirement");
      }
      ASSERT_FALSE(run.in_flight());
      std::array<c::ReadLease,fixture::kOutputs> current;
      std::array<Bytes,fixture::kOutputs> actual;
      for (std::size_t i=0;i<current.size();++i) {
        auto output=take(run.result(logical.outputs[i]),"successful output");
        current[i]=take(output.storage_lease(),"independent readonly output");
        actual[i]=read(current[i]);
      } // Drop all GraphOutput/Completion objects before slot reuse.
      for (std::size_t i=0;i<fixture::kIds;++i) {
        const auto values=decode<float>(actual[i]);
        sem::expect_output(fragment,values,expected.outputs[i],{},false,nullptr,true,i);
      }
      ASSERT_FALSE(HasFailure()); // Do not sign head correctness after a failed stage.
      // Observation is checker-only: Graph feedback was already executed;
      // no host token, hidden or oracle state is supplied to a later row.
      const auto hidden=decode<float>(actual[fixture::kHidden]);
      const auto normalized=decode<float>(actual[fixture::kNormalized]);
      const auto first=decode<std::int32_t>(expected.inputs[fixture::kFirst]).at(0);
      const auto base_logits=fixture::lm_reference(normalized);
      const auto reference=original::reference(roles,base_logits,hidden,first);
      EXPECT_EQ(decode<std::int32_t>(actual[fixture::kIds]),reference.tokens);
      EXPECT_EQ(decode<std::uint16_t>(actual[fixture::kMarkov]),reference.markov);
      ASSERT_TRUE(adjusted_logits_equal(decode<float>(actual[fixture::kLogits]),base_logits,reference));
      ASSERT_TRUE(projection_equal(decode<float>(actual[fixture::kConfidence]),reference.confidence,"original raw confidence"));
      check(run.reset(),"withdraw completed input/output permissions");
      EXPECT_FALSE(run.submit(queues).has_value());
      if (step==0) {oldest=std::move(current);oldest_bytes=actual;}
      else for (std::size_t i=0;i<oldest.size();++i) EXPECT_EQ(read(oldest[i]),oldest_bytes[i]);
    }
  } // Independent old results outlive the original Invocation.
  for (std::size_t i=0;i<oldest.size();++i) EXPECT_EQ(read(oldest[i]),oldest_bytes[i]);
  oldest={};
  EXPECT_EQ(pool.stats().live_blocks,0u);
  EXPECT_EQ(pool.stats().active_uses,0u);
  RecordProperty("scope","Flash H4096/heads64/D512/three stages/five greedy rows/full V129280; generated stage+LM weights, original W1/W2/confidence only");
  RecordProperty("actual_hot_submissions",3);
  RecordProperty("adjusted_logit_check","exact BF16 products; gamma256 F32 reduction plus FP64 oracle bound; normal-quantum/finite range checked; necessary numerical compatibility, not vendor-internal proof");
  RecordProperty("markov_w1_sha256",original::w1_sha256);
  RecordProperty("markov_w2_sha256",original::w2_sha256);
  RecordProperty("confidence_sha256",original::confidence_sha256);
}
} // namespace
