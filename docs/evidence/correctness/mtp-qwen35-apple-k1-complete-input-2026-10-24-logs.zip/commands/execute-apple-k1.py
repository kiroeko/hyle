from pathlib import Path
import json,shlex,subprocess
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024'
D=json.loads((O/'plan.json').read_text())['remote']
code='''from pathlib import Path
import json,os
D=Path(REMOTE)
prefix=(D/'run.py').read_text().split("for row in plan['source_inputs']:",1)[0]
exec(prefix,globals())
records=json.loads((D/'records.json').read_text())
metallib=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/qwen-native-assembly-20261022/mlx.metallib')
assert metallib.is_file()
if not (D/'mlx.metallib').exists():os.symlink(metallib,D/'mlx.metallib')
save('mlx-metallib-identity.json',dict(original=identity(metallib),symlink=str(D/'mlx.metallib'),copies=0))
results=[]
for mtp in ('off','on'):
 for policy in ('greedy','random'):
  tag='mtp-'+mtp+'-'+policy
  command=[str(D/'hyle-apple'),'--inputs',str(D/'inputs'),'--mtp',mtp,'--steps','4','--capacity','256',
     '--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--sampling',policy]
  if policy=='random':command+=['--temperature','0.8','--top-k','40','--top-p','0.95','--seed','42']
  result=run(tag,command,180)
  objects=[]
  for line in (D/(tag+'.stdout.log')).read_text().splitlines():
   try:value=json.loads(line)
   except json.JSONDecodeError:continue
   if 'generated_ids'in value:objects.append(value)
  assert len(objects)==1 and len(objects[0]['generated_ids'])==4
  results.append(dict(tag=tag,process=result,report=objects[0]))
  save('functional-results.json',dict(runs=results,scope='Four frozen K1 complete BF16 Apple P154+4 runs only',deployment='14.4',performance_claim=False,all_functionality_claim=False))
  print(tag,objects[0]['generated_ids'],flush=True)
print('COMPLETE',flush=True)
'''.replace('REMOTE',repr(D))
(O/'execute.py').write_text(code)
subprocess.run(['scp',str(O/'execute.py'),'kiro@172.22.10.198:'+D+'/execute.py'],check=True,timeout=30)
print(D)
