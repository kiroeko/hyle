from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024'
D='/Users/kiro/hyle-scratch/compute-unified/qwen-k1-functional-20261024/attempt1'
cache=json.loads((O/'cache-plans.json').read_text())
frozen=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/frozen-k1-source'
selected=[
 'src/compute/resource_budget.cc','src/compute/resource_leases.cc','src/compute_ops/low_precision.cc',
 'src/compute_batch/batch_layout.cc','src/compute_batch/batch_paged_native.cc','src/compute_batch/paged_arena.cc',
 'src/compute_batch/batch_materialize.cc','src/compute_batch/batch_execution.cc',
 'src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc','src/graph_batch/paged_append.cc',
 'src/graph_route_apple/native_ragged_region.cc','src/graph_route_apple/native_paged_region.cc',
 'src/compute_route_apple/apple_batch.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_static_fp8.cc',
 'src/compute_provider_ggml/native_batch.cc',
]
def ident(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files={}
files['run.py']=Path(__file__).with_name('run-apple-k1.py')
catalog={}
for group in ('include','src'):
 for p in (R/group).rglob('*'):
  if p.is_file() and p.suffix in ('.h','.hpp','.cc','.mm'):
   catalog[p.relative_to(R).as_posix()]=ident(p)
(O/'current-source-digests.json').write_text(json.dumps(catalog,indent=2))
files['current-source-digests.json']=O/'current-source-digests.json'
for rel in selected:files['source/'+rel]=R/rel
changed=json.loads((O/'changed-current-files.json').read_text())
for x in changed:
 if x['relative'].startswith('include/'):files['source/'+x['relative']]=R/x['relative']
# Freeze only the already-authored engine-private input snapshot and public
# Dense descriptor, not a second public SDK or a source checkout.
for p in frozen.rglob('*'):
 if p.is_file():files['model/'+p.relative_to(frozen).as_posix()]=p
wrapper=O/'entry.cc';wrapper.write_text('#include "driver.h"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
files['model/entry.cc']=wrapper
source_inputs=R/'.scratch/qwen-mtp-window-20261022/inputs/mtp'
lines=(source_inputs/'weights.tsv').read_text().splitlines();assert lines[0]=='HYLE_QWEN35_TEXT_MTP_V1' and len(lines)==338
lines[1]='/Users/kiro/hyle-scratch/compute-unified/models/qwen35-2b/model.safetensors'
(O/'weights.tsv').write_text('\n'.join(lines)+'\n');files['inputs/weights.tsv']=O/'weights.tsv'
files['inputs/prompt.ids']=source_inputs/'prompt.ids'
jobs=[]
all_jobs=[*cache['gdn-scale']['commands.json']['host'],*cache['graph-bridge']['commands.json']['host']]
for rel in selected:
 prior=next(x for x in all_jobs if any(v.endswith('/source/'+rel) for v in x['argv']))
 cmd=[];it=iter(prior['argv'])
 for arg in it:
  if arg in ('-o','-MF'):next(it);continue
  if arg.endswith('/source/'+rel):continue
  cmd.append(arg)
 cmd[1:1]=['-I'+D+'/source/include']
 out=D+'/objects/'+rel.replace('/','--')+'.o'
 cmd+=['-MMD','-MF',out+'.d','-c',D+'/source/'+rel,'-o',out]
 # Source commands already carry -c; duplicates are removed for clarity.
 removed=False;clean=[]
 for arg in cmd:
  if arg=='-c':
   if removed:continue
   removed=True
  clean.append(arg)
 jobs.append(dict(tag=rel,argv=clean,source_identity=ident(R/rel),object=out))
old=cache['qwen-rev4']['ready.json']['records'][0]['command'];cmd=[];it=iter(old)
for arg in it:
 if arg in ('-o','-MF'):next(it);continue
 if arg.endswith('/revision4/main.cc'):continue
 cmd.append(arg)
cmd[1:1]=['-I'+D+'/model/public','-I'+D+'/source/include','-I'+D+'/model',
 '-I'+cache['graph-bridge']['commands.json']['remote_directory']+'/source/include',
 '-I'+cache['gdn-scale']['commands.json']['remote_directory']+'/source/include']
cmd+=['-MMD','-MF',D+'/objects/model.o.d',D+'/model/main.cc','-o',D+'/objects/model.o']
jobs.append(dict(tag='frozen-k1-model',argv=cmd,source_identity=ident(frozen/'main.cc'),object=D+'/objects/model.o'))
entry=[x for x in cmd if x not in (D+'/model/main.cc',D+'/objects/model.o',D+'/objects/model.o.d')]
# Use a small direct entry command rather than carrying orphaned output flags.
entry=['/usr/bin/c++','-std=c++23','-O3','-DNDEBUG','-DHYLE_STATIC','-I'+D+'/model','-c',D+'/model/entry.cc','-o',D+'/objects/entry.o']
jobs.append(dict(tag='entry',argv=entry,source_identity=ident(wrapper),object=D+'/objects/entry.o'))
base=cache['graph-bridge']['commands.json']['link']['metal']['argv'];link=[base[0],*[x['object'] for x in jobs]]
it=iter(base[1:])
for arg in it:
 if arg=='-o':next(it);continue
 if arg.startswith('-Wl,-map,') or arg.endswith('/probe3.o') or 'libgtest' in arg:continue
 if arg.endswith('/metal-provider.o'):
  arg='/Users/kiro/hyle-scratch/compute-unified/dense-linear-20261024/attempt1/metal-provider.o'
 link.append(arg)
link[1:1]=cache['qwen-assembly']['plan.json']['extra_original_objects']
link+=['/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib/libhyle_io_core.a',
 '-o',D+'/hyle-apple','-Wl,-map,'+D+'/hyle-apple.map']
native_scale=cache['gdn-scale']['commands.json']['remote_directory']
expected_model=next(x for x in json.loads((R/'docs/implementation/tasks/compute/qwen35-2b-local-input.json').read_text())['files']if x['path'].startswith('model.safetensors-'))
plan=dict(remote=D,jobs=jobs,link=link,model=expected_model,actual_model_path=lines[1],
 frozen_model=ident(frozen/'main.cc'),source_inputs=[dict(archive=name,**ident(p))for name,p in sorted(files.items())],
 cached_plan='cache-plans.json',scope='Frozen K1 complete BF16 Apple short functional probes only; not all model/backends or performance proof',
 native_objects=[native_scale+'/metal-native-ops.o',native_scale+'/metal-gdn-embed.o'],SDK_builds=0,native_builds=0,HTTP=0)
(O/'plan.json').write_text(json.dumps(plan,indent=2));files['plan.json']=O/'plan.json'
with tarfile.open(O/'focused-sources.tar.gz','w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
print(json.dumps(dict(remote=D,product_TUs=len(selected),model_TUs=1,entry_TUs=1,source_bytes=sum(p.stat().st_size for p in files.values()),archive=ident(O/'focused-sources.tar.gz')),indent=2))
