from pathlib import Path
import hashlib,json,os,shlex,struct,subprocess,time
D=Path(__file__).resolve().parent;plan=json.loads((D/'plan.json').read_text());assert str(D)==plan['remote']
(D/'objects').mkdir(exist_ok=True)
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(4*1024*1024),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(name,value):(D/name).write_text(json.dumps(value,indent=2)+'\n')
records=[]
def run(tag,argv,timeout=180):
 print('START',tag,flush=True);t=time.time();out=D/(tag+'.stdout.log');err=D/(tag+'.stderr.log')
 with out.open('wb') as a,err.open('wb') as b:
  process=subprocess.Popen(argv,cwd=D,stdout=a,stderr=b,env={**os.environ,'MLX_METAL_PATH':str(D/'mlx.metallib')})
  try:exit=process.wait(timeout=timeout);timed_out=False
  except subprocess.TimeoutExpired:process.kill();process.wait();exit=process.returncode;timed_out=True
 item=dict(tag=tag,command=argv,cwd=str(D),exit=exit,timed_out=timed_out,seconds=time.time()-t)
 records.append(item);save('records.json',records);save(tag+'.json',item);print('END',tag,exit,round(item['seconds'],3),flush=True)
 if exit or timed_out:raise RuntimeError('failed '+tag)
 return item
for row in plan['source_inputs']:
 actual=identity(D/row['archive']);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],row['archive']
native=[identity(p)for p in plan['native_objects']]
assert native[0]['sha256']=='b325229d4023d64878d7ead97560e07254ea7e82b959ad754e93954408e3d48a'
assert native[1]['sha256']=='a70f096e524984090dfcc45aaa58d2a96409683911e63e8ff87aad4fc93fda97'
inputs=[identity(p)for p in dict.fromkeys(x for x in plan['link']if x.endswith(('.a','.o')) and not x.startswith(str(D)+'/'))]
save('cached-closure-identities.json',inputs)
hardware=[]
for args in [['uname','-a'],['sysctl','-n','hw.model'],['sysctl','-n','hw.memsize'],['/usr/bin/c++','--version']]:
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);hardware.append(dict(command=args,exit=p.returncode,output=p.stdout.decode()))
save('hardware.json',hardware)
# The full original file is already present. A single streamed hash verifies
# the source identity without creating another checkpoint or reading vision
# into a tensor bank. Metadata still gates every selected text role's extent.
model=identity(plan['actual_model_path']);assert model['bytes']==plan['model']['size_bytes'] and model['sha256']==plan['model']['sha256']
with Path(model['path']).open('rb') as f:
 n=struct.unpack('<Q',f.read(8))[0];assert 0<n<16*1024*1024;raw=f.read(n);assert len(raw)==n;header=json.loads(raw)
lines=(D/'inputs/weights.tsv').read_text().splitlines();checked=0
for line in lines[3:]:
 fields=line.split();name,dtype,rank=fields[:3];rank=int(rank);shape=list(map(int,fields[3:3+rank]));offset,count=map(int,fields[3+rank:])
 role=header[name];assert role['dtype']==dtype and role['shape']==shape and offset==8+n+role['data_offsets'][0] and count==role['data_offsets'][1]-role['data_offsets'][0]
 checked+=1
assert checked==335
save('model-identity.json',dict(original=model,header_sha256=hashlib.sha256(raw).hexdigest(),header_bytes=8+n,checked_text_MTP_roles=checked,weight_copies=0,HTTP=0))
catalog=json.loads((D/'current-source-digests.json').read_text());dependencies=[]
for i,job in enumerate(plan['jobs']):
 run('compile'+str(i),job['argv'])
 p=Path(job['object']+'.d')
 if p.exists():
  text=p.read_text().replace('\\\n',' ');paths=shlex.split(text.split(': ',1)[1]);bad=[]
  for path in paths:
   if '/source/'not in path:continue
   rel=path.split('/source/',1)[1]
   if rel not in catalog:continue
   value=identity(path);dependencies.append(dict(translation_unit=job['tag'],relative=rel,**value))
   if value['sha256']!=catalog[rel]['sha256']:bad.append(dependencies[-1])
  save('actual-current-dependencies.json',dependencies)
  if bad:save('stale-dependencies.json',bad);raise RuntimeError('stale product source/header dependency in '+job['tag'])
run('link',plan['link'])
save('ready.json',dict(image=identity(D/'hyle-apple'),current_source_dependencies=dependencies,SDK_builds=0,native_builds=0,HTTP=0))
print('READY',flush=True)
