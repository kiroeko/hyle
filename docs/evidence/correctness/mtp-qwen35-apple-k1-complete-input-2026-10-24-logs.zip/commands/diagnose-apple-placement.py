from pathlib import Path
import difflib,hashlib,json,shlex,subprocess
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024';D=json.loads((O/'plan.json').read_text())['remote']
source=R/'src/graph/executable.cc';old=source.read_text();text=old.replace('#include <cstring>','#include <cstring>\n#include <cstdio>',1)
needle='''    if (placement_attempts == options.max_placement_attempts) {'''
trace='''    const auto trace_decline = [&](const Status &reason, std::span<const NodeId> nodes = {}) {
      const auto message = reason.message();
      std::uint64_t key = hash_word(1469598103934665603ULL, step.node_begin);
      key = hash_word(key, static_cast<std::uint64_t>(reason.code()));
      for (const auto ch : message) key = hash_word(key, static_cast<unsigned char>(ch));
      thread_local std::array<std::uint64_t, 16> seen{};
      thread_local std::size_t used = 0;
      for (std::size_t i = 0; i < used; ++i) if (seen[i] == key) return;
      if (used == seen.size()) return;
      seen[used++] = key;
      const auto name = graph.nodes[step.node_begin].view_index()
          ? compute::operation_name(graph.nodes[step.node_begin].kind())
          : compute::operation_name(graph.nodes[step.node_begin].operation());
      std::fprintf(stderr, "placement_decline unique=%zu attempt=%zu begin=%u op=%.*s code=%u reason=%.*s nodes=",
          used, placement_attempts, step.node_begin, int(name.size()), name.data(), unsigned(reason.code()), int(message.size()), message.data());
      for (std::size_t i = 0; i < nodes.size() && i < 12; ++i) std::fprintf(stderr, "%u,", nodes[i].ordinal());
      std::fprintf(stderr, " total=%zu\\n", nodes.size());
      const auto describe = [&](const char *kind, const auto &descriptions, const auto &resources) {
        for (std::size_t port = 0; port < descriptions.size(); ++port) {
          const auto &desc = descriptions[port];
          std::size_t domain = SIZE_MAX;
          for (std::size_t i = 0; i < plan.storage_domains.size(); ++i) if (plan.storage_domains[i].resource == resources[port]) domain = i;
          std::fprintf(stderr, "  %s%zu dtype=%u plain=%d dense=%d domain=%zu shape=", kind, port, unsigned(desc.data_type()), desc.is_plain(), desc.is_dense(), domain);
          for (const auto dim : desc.dimensions()) std::fprintf(stderr, "%lld,", static_cast<long long>(dim));
          std::fprintf(stderr, "\\n");
        }
      };
      describe("input", inputs, input_resources); describe("output", outputs, output_resources);
    };
'''
assert text.count(needle)==1;text=text.replace(needle,trace+needle)
needle='''      if (!attempt->succeeded()) {
        discovery.physical.reject_suffix'''
assert text.count(needle)==1;text=text.replace(needle,'''      if (!attempt->succeeded()) {
        trace_decline(attempt->reason);
        discovery.physical.reject_suffix''')
needle='''      if (!attempt->prepared.valid()) {
        // Shared packing'''
assert text.count(needle)==1;text=text.replace(needle,'''      if (!attempt->prepared.valid()) {
        trace_decline(attempt->reason, candidate_nodes(candidate, all_region_nodes));
        // Shared packing''')
p=O/'executable.diagnostic.cc';p.write_text(text)
(O/'placement-diagnostic.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='src/graph/executable.cc',tofile='private/executable.diagnostic.cc')))
cache=json.loads((O/'cache-plans.json').read_text())
prior=next(x for x in cache['graph-bridge']['commands.json']['host']if x['name']=='src--graph--executable.cc')
cmd=[];it=iter(prior['argv'])
for arg in it:
 if arg in ('-o','-MF'):next(it);continue
 if arg.endswith('/source/src/graph/executable.cc'):continue
 cmd.append(arg)
cmd[1:1]=['-I'+D+'/source/include'];cmd+=['-MMD','-MF',D+'/objects/executable-diagnostic.o.d',D+'/source/src/graph/executable.diagnostic.cc','-o',D+'/objects/executable-diagnostic.o']
retry=json.loads((O/'retry-plan.json').read_text());link=retry['link_command'];link[1:1]=[D+'/objects/executable-diagnostic.o']
record=dict(compile=cmd,link=link,scope='Private first16 unique artifact-decline diagnostics; no product search limit or math change',source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(O/'placement-plan.json').write_text(json.dumps(record,indent=2))
runner='''from pathlib import Path
import json
D=Path(__file__).resolve().parent
exec((D/'run.py').read_text().split("for row in plan['source_inputs']:",1)[0],globals())
records=json.loads((D/'records.json').read_text())
diagnostic=json.loads((D/'placement-plan.json').read_text())
run('compile-executable-diag',diagnostic['compile'])
run('link-executable-diag',diagnostic['link'])
command=[str(D/'hyle-apple'),'--inputs',str(D/'inputs'),'--mtp','on','--steps','4','--capacity','256','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--sampling','random','--temperature','0.8','--top-k','40','--top-p','0.95','--seed','42']
try:run('mtp-on-random-placement-diag',command,180)
except RuntimeError:pass
log=(D/'mtp-on-random-placement-diag.stderr.log').read_text().splitlines();selected=[]
for i,line in enumerate(log):
 if line.startswith('placement_decline'):
  selected.append(line)
  for nextline in log[i+1:]:
   if not nextline.startswith('  '):break
   selected.append(nextline)
 elif 'consumer:' in line:selected.append(line)
(D/'placement-declines.txt').write_text('\\n'.join(selected)+'\\n')
save('placement-diag-ready.json',dict(image=identity(D/'hyle-apple'),source=diagnostic['source_sha256']))
print('\\n'.join(selected),flush=True)
'''
(O/'placement.py').write_text(runner)
subprocess.run(['ssh','kiro@172.22.10.198','mkdir -p '+shlex.quote(D+'/source/src/graph')],check=True,timeout=30)
for name,target in [('executable.diagnostic.cc','source/src/graph/executable.diagnostic.cc'),('placement-plan.json','placement-plan.json'),('placement.py','placement.py')]:
 subprocess.run(['scp',str(O/name),'kiro@172.22.10.198:'+D+'/'+target],check=True,timeout=30)
