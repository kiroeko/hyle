from pathlib import Path
import hashlib,json,shlex,subprocess
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024';O.mkdir(exist_ok=True)
B='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation'
requests={
 'gdn-scale':f'{B}/gdn-output-scale-20261024/attempt2',
 'graph-bridge':f'{B}/gdn-graph-bridge-20261024/attempt1',
 'paged-effects':f'{B}/native-paged-effects-20261022',
 'paged-capacity':f'{B}/native-paged-capacity-20261022',
 'qwen-assembly':f'{B}/qwen-native-assembly-20261022',
 'qwen-rev4':f'{B}/qwen-native-assembly-20261022/revision4',
}
code='''import json
from pathlib import Path
requests=REQUESTS
answer={}
for tag,base in requests.items():
 p=Path(base);answer[tag]={}
 for name in ['commands.json','sync-manifest.json','plan.json','ready.json','actual-summary.json']:
  q=p/name
  if q.exists():answer[tag][name]=json.loads(q.read_text())
print(json.dumps(answer))
'''.replace('REQUESTS',repr(requests))
p=subprocess.run(['ssh','-oBatchMode=yes','-oConnectTimeout=10','kiro@172.22.10.198','python3 -c '+shlex.quote(code)],capture_output=True,timeout=45,check=True)
d=json.loads(p.stdout);(O/'cache-plans.json').write_text(json.dumps(d,indent=2))
changed=[]
for group in ('gdn-scale','graph-bridge'):
 for row in d[group]['sync-manifest.json']['files']:
  old=row['local'];name=Path(old['path']);new=R/str(name).replace('C:\\public\\project-hyle\\hyle\\','').replace('\\','/')
  if not new.is_file():continue
  actual=hashlib.sha256(new.read_bytes()).hexdigest()
  if actual!=old['sha256']:changed.append(dict(group=group,relative=new.relative_to(R).as_posix(),old=old,current_sha256=actual,bytes=new.stat().st_size))
(O/'changed-current-files.json').write_text(json.dumps(changed,indent=2))
print(json.dumps(dict(changed=[dict(group=x['group'],relative=x['relative'],bytes=x['bytes']) for x in changed]),indent=2))
