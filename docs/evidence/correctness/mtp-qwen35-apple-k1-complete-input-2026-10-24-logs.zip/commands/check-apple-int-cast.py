from pathlib import Path
import hashlib,json,shlex,subprocess
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024';D=json.loads((O/'plan.json').read_text())['remote']
cache=json.loads((O/'cache-plans.json').read_text());prior=cache['graph-bridge']['commands.json']['probe'][0]['argv'];cmd=[];it=iter(prior)
for arg in it:
 if arg in ('-o','-MF'):next(it);continue
 if arg.endswith('/gdn_graph_bridge_test.cc'):continue
 cmd.append(arg)
cmd[1:1]=['-I'+D+'/source/include'];cmd+=['-MMD','-MF',D+'/objects/int-cast-test.o.d',D+'/source/tests/compute_route_apple/tensor_test.cc','-o',D+'/objects/int-cast-test.o']
model=json.loads((O/'cast-plan.json').read_text())['link'];link=[x for x in model if not x.endswith(('/objects/model.o','/objects/entry.o'))]
gtest=[x for x in cache['graph-bridge']['commands.json']['link']['metal']['argv']if 'libgtest' in x]
link[1:1]=[D+'/objects/int-cast-test.o',*gtest]
files=['tests/compute_route_apple/tensor_test.cc','tests/compute_route_apple/tensor_test_support.h','tests/compute_route_apple/sink_attention_test_support.h','tests/compute_provider_native/half_test_support.h']
plan=dict(compile=cmd,test_link=link,model_link=model,sources=[dict(relative=p,bytes=(R/p).stat().st_size,sha256=hashlib.sha256((R/p).read_bytes()).hexdigest())for p in files])
(O/'cast-test-plan.json').write_text(json.dumps(plan,indent=2))
runner='''from pathlib import Path
import json
D=Path(__file__).resolve().parent
exec((D/'run.py').read_text().split("for row in plan['source_inputs']:",1)[0],globals())
records=json.loads((D/'records.json').read_text());test=json.loads((D/'cast-test-plan.json').read_text());error=None
run('compile-int-cast-tests',test['compile'])
try:
 run('link-int-cast-tests',test['test_link'])
 image=identity(D/'hyle-apple')
 run('int-cast-tests',[str(D/'hyle-apple'),'--gtest_filter=AppleTensor.Int32ToFloat32*:AppleTensor.CategoricalChoice*','--gtest_output=json:'+str(D/'cast-gtest-results.json')])
 result=json.loads((D/'cast-gtest-results.json').read_text());assert result['tests']==2 and result['failures']==0
 save('cast-test-results.json',dict(image=image,tests=2,failures=0,scope='True Apple I32->F32 native Cast extremes/ties/noncontiguous input, then0/1 I32->F32->Bool->Select acceptance chain'))
 print((D/'int-cast-tests.stdout.log').read_text(),flush=True)
except Exception as caught:error=caught
finally:
 run('restore-model-image',test['model_link'])
 ready=json.loads((D/'ready.json').read_text());ready['image']=identity(D/'hyle-apple');save('ready.json',ready)
if error:raise error
'''
(O/'cast-tests.py').write_text(runner)
for rel in files:
 subprocess.run(['ssh','kiro@172.22.10.198','mkdir -p '+shlex.quote(D+'/source/'+str(Path(rel).parent).replace('\\','/'))],check=True,timeout=30)
 subprocess.run(['scp',str(R/rel),'kiro@172.22.10.198:'+D+'/source/'+rel],check=True,timeout=30)
for name in ('cast-test-plan.json','cast-tests.py'):
 subprocess.run(['scp',str(O/name),'kiro@172.22.10.198:'+D+'/'+name],check=True,timeout=30)
