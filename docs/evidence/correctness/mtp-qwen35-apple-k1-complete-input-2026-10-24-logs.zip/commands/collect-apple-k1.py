from pathlib import Path
import json,shlex,subprocess,tarfile
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024';D=json.loads((O/'plan.json').read_text())['remote']
code='''from pathlib import Path
import hashlib,json,tarfile
D=Path(REMOTE);C=D/'evidence';C.mkdir(exist_ok=True)
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for name in ['plan.json','ready.json','cast-plan.json','cast-test-plan.json','retry-plan.json','placement-plan.json','records.json',
    'hardware.json','model-identity.json','cached-closure-identities.json','actual-current-dependencies.json',
    'actual-model-dependencies.json','functional-results.json','cast-test-results.json','cast-gtest-results.json',
    'mlx-metallib-identity.json','input-line-ending-normalization.json','placement-declines.txt']:
 (C/name).write_bytes((D/name).read_bytes())
for name in ['mtp-off-greedy','mtp-off-random','mtp-on-greedy','mtp-on-random-int-cast-fixed','int-cast-tests']:
 for suffix in ['.json','.stdout.log']:(C/(name+suffix)).write_bytes((D/(name+suffix)).read_bytes())
 text=(D/(name+'.stderr.log')).read_text().splitlines()
 selected=[x for x in text if x.startswith(('resident ','weights_load','weight_loader ','compile ','compiled ','shared_cache','Qwen','mtp_shape','mtp_tensors'))]
 (C/(name+'.stderr-selected.log')).write_text('\\n'.join(selected)+'\\n')
for name in ['compile17','compile17-macos144','link144','compile-apple-int-cast','link-int-cast','compile-int-cast-tests','link-int-cast-tests','restore-model-image']:
 for suffix in ['.json','.stderr.log']:
  p=D/(name+suffix)
  if p.exists():(C/(name+suffix)).write_bytes(p.read_bytes())
for name in ['mtp-on-random','mtp-on-random-diag','mtp-on-random-fixed','mtp-on-random-placement-diag']:
 lines=(D/(name+'.stderr.log')).read_text().splitlines()
 selected=[x for x in lines if x.startswith(('compile ','compiled ','topk_diag','Qwen'))]
 (C/(name+'.failure-selected.log')).write_text('\\n'.join(selected)+'\\n')
for relative in ['inputs/weights.tsv','inputs/prompt.ids','model/main.apple.cc','model/mtp_graph.h','model/public/hyle/compute/model_ops.h']:
 p=D/relative;target=C/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
link_map=(D/'hyle-apple.map').read_text()
anchors=[x for x in link_map.splitlines()if any(t in x for t in ['metal-native-ops.o','metal-gdn-embed.o','metal-provider.o','apple-int-cast.o','_ggml_hyle_metal_gdn_output_scale_contract','_ggml_metallib_gated_delta_net_start'])]
assert any('metal-native-ops.o'in x for x in anchors) and 'executable-diagnostic.o'not in link_map
final_link=json.loads((D/'cast-plan.json').read_text())['link']
objects=[identity(x)for x in final_link if x.endswith(('.a','.o'))]
(C/'final-closure.json').write_text(json.dumps(dict(image=identity(D/'hyle-apple'),actual_objects=objects,actual_map_anchors=anchors,private_graph_diagnostic_in_final=False),indent=2))
(C/'manifest.json').write_text(json.dumps([identity(p)for p in C.rglob('*')if p.is_file()],indent=2))
with tarfile.open(D/'evidence.tar.gz','w:gz')as tar:
 for p in C.rglob('*'):
  if p.is_file():tar.add(p,arcname=p.relative_to(C).as_posix(),recursive=False)
print(json.dumps(identity(D/'evidence.tar.gz')))
'''.replace('REMOTE',repr(D))
(O/'collect-remote.py').write_text(code)
subprocess.run(['scp',str(O/'collect-remote.py'),'kiro@172.22.10.198:'+D+'/collect.py'],check=True,timeout=30)
subprocess.run(['ssh','kiro@172.22.10.198','python3 '+shlex.quote(D+'/collect.py')],check=True,timeout=30)
subprocess.run(['scp','kiro@172.22.10.198:'+D+'/evidence.tar.gz',str(O/'evidence.tar.gz')],check=True,timeout=30)
with tarfile.open(O/'evidence.tar.gz')as tar:
 assert all(m.isfile() and '..'not in Path(m.name).parts and not Path(m.name).is_absolute()for m in tar.getmembers());tar.extractall(O/'results',filter='data')
print('collected source/commands/results only; no objects, SDK, image or weights')
