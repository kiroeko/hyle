from pathlib import Path
import hashlib,json,shlex,subprocess
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024';D=json.loads((O/'plan.json').read_text())['remote']
cache=json.loads((O/'cache-plans.json').read_text());rel='src/compute_route_apple/apple_tensor.cc'
prior=next(x for x in cache['graph-bridge']['commands.json']['host'] if x['name']=='src--compute_route_apple--apple_tensor.cc')
cmd=[];it=iter(prior['argv'])
for arg in it:
 if arg in ('-o','-MF'):next(it);continue
 if arg.endswith('/source/'+rel):continue
 cmd.append(arg)
cmd[1:1]=['-I'+D+'/source/include'];cmd+=['-MMD','-MF',D+'/objects/apple-int-cast.o.d',D+'/source/'+rel,'-o',D+'/objects/apple-int-cast.o']
link=json.loads((O/'retry-plan.json').read_text())['link_command'];link[1:1]=[D+'/objects/apple-int-cast.o']
source=R/rel
plan=dict(compile=cmd,link=link,source=dict(path=str(source),bytes=source.stat().st_size,sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
 scope='Only actual I32-to-F32 Cast is added; untouched4096 placement limit, ordinary Apple MLX astype; no generic integer-cast promise')
(O/'cast-plan.json').write_text(json.dumps(plan,indent=2))
runner='''from pathlib import Path
import json
D=Path(__file__).resolve().parent
exec((D/'run.py').read_text().split("for row in plan['source_inputs']:",1)[0],globals())
records=json.loads((D/'records.json').read_text());cast=json.loads((D/'cast-plan.json').read_text())
run('compile-apple-int-cast',cast['compile'])
run('link-int-cast',cast['link'])
command=[str(D/'hyle-apple'),'--inputs',str(D/'inputs'),'--mtp','on','--steps','4','--capacity','256','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--sampling','random','--temperature','0.8','--top-k','40','--top-p','0.95','--seed','42']
result=run('mtp-on-random-int-cast-fixed',command,180)
objects=[]
for line in (D/'mtp-on-random-int-cast-fixed.stdout.log').read_text().splitlines():
 try:value=json.loads(line)
 except json.JSONDecodeError:continue
 if 'generated_ids'in value:objects.append(value)
assert len(objects)==1 and len(objects[0]['generated_ids'])==4 and objects[0]['sampling_draw_cursor']>1
ready=json.loads((D/'ready.json').read_text());ready['image']=identity(D/'hyle-apple');ready['apple_cast']=cast['source'];ready['contains_graph_diagnostics']=False
save('ready.json',ready)
old=json.loads((D/'functional-results.json').read_text());old['runs'].append(dict(tag='mtp-on-random-int-cast-fixed',process=result,report=objects[0],image=ready['image'],source=ready['source_identity']))
assert len(old['runs'])==4;save('functional-results.json',old)
print(json.dumps(dict(generated_ids=objects[0]['generated_ids'],sampling_draw_cursor=objects[0]['sampling_draw_cursor'],image=ready['image']),indent=2),flush=True)
'''
(O/'cast.py').write_text(runner)
for source,target in [(source,'source/'+rel),(O/'cast-plan.json','cast-plan.json'),(O/'cast.py','cast.py')]:
 subprocess.run(['scp',str(source),'kiro@172.22.10.198:'+D+'/'+target],check=True,timeout=30)
