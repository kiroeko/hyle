from pathlib import Path
import difflib,hashlib,json,shlex,subprocess
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-apple-k1-20261024'
plan=json.loads((O/'plan.json').read_text());D=plan['remote'];frozen=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/frozen-k1-source/main.cc'
old=frozen.read_text();needle='Sampling sampling_configuration = {})';assert old.count(needle)==1
text=old.replace(needle,'Sampling sampling_configuration = {false, {}, 0})')
first='else if (option == "--temperature" || option == "--top-p") {'
last='else if (option == "--top-k" || option == "--seed") {'
current=(R/'engine/models/qwen35/main.cc').read_text()
old_start,old_end=text.index(first),text.index(last)
new_start,new_end=current.index(first),current.index(last)
text=text[:old_start]+current[new_start:new_end]+text[old_end:]
assert 'std::locale::classic()' in text[old_start:text.index(last)]
text=text.replace('#include <limits>','#include <limits>\n#include <locale>',1)
portable=O/'main.apple-portable-k1.cc';portable.write_text(text)
assert hashlib.sha256(portable.read_bytes()).hexdigest()=='faf6fcf7367aae0940fa4f1a9226b9ec14e4e446eaba214e88d8500feef2c566'
old_selected='definition.draft_id_port = head.ids;'
new_selected='''if (!sampler.enabled) definition.draft_id_port = r.op(c::Operation(c::TopK{.count = 1}),
              {head.logits}, {r.dense_spec(Type::kFloat32, {batch, f(1)}),
              r.dense_spec(Type::kInt32, {batch, f(1)})})[1];'''
assert text.count(old_selected)==1;text=text.replace(old_selected,new_selected)
helper=R/'engine/models/qwen35/mtp_graph.h'
assert 'Value ids;'not in helper.read_text() and 'Token selection belongs to the caller' in helper.read_text()
(O/'mtp_graph.apple.h').write_bytes(helper.read_bytes())
(O/'mtp-head-policy.patch').write_text(''.join(difflib.unified_diff((frozen.parent/'mtp_graph.h').read_text().splitlines(True),helper.read_text().splitlines(True),fromfile='frozen-k1-mtp_graph.h',tofile='mtp_graph.h')))
source=O/'main.apple.cc';source.write_text(text)
(O/'clang-portability.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='frozen-k1-main.cc',tofile='main.apple.cc')))
job=plan['jobs'][17];assert job['tag']=='frozen-k1-model'
cmd=[x.replace(D+'/model/main.cc',D+'/model/main.apple.cc') for x in job['argv']]
retry=dict(original_source=job['source_identity'],private_source=dict(path=str(source),bytes=source.stat().st_size,sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
  adaptations=['Explicit aggregate default {false, {}, 0} for Clang nested class frontend',
    'Exact current CLI stream/classic locale/noskipws/full consumption float parsing; preserves deployment14.4',
    'Same product Head/math-policy fix: full_head returns logits, caller builds greedy TopK only for greedy policy'],
  model_command=cmd,entry_command=[*plan['jobs'][18]['argv'],'-mmacosx-version-min=14.4'],
  link_command=[x for x in plan['link']if not x.endswith('/src--compute_provider_ggml--native_batch.cc.o')])
(O/'retry-plan.json').write_text(json.dumps(retry,indent=2))
runner='''from pathlib import Path
import json
D=Path(__file__).resolve().parent
prefix=(D/'run.py').read_text().split("for row in plan['source_inputs']:",1)[0]
exec(prefix,globals())
records=json.loads((D/'records.json').read_text())
retry=json.loads((D/'retry-plan.json').read_text())
run('compile17-macos144',retry['model_command'])
catalog=json.loads((D/'current-source-digests.json').read_text());dependencies=[]
text=(D/'objects/model.o.d').read_text().replace('\\\\\\n',' ')
for path in shlex.split(text.split(': ',1)[1]):
 if '/source/' not in path:continue
 rel=path.split('/source/',1)[1]
 if rel not in catalog:continue
 value=identity(path);dependencies.append(dict(relative=rel,**value))
 if value['sha256']!=catalog[rel]['sha256']:
  save('stale-model-dependencies.json',dependencies);raise RuntimeError('stale model header '+path)
save('actual-model-dependencies.json',dependencies)
run('compile18-macos144',retry['entry_command'])
run('link144',retry['link_command'])
save('ready.json',dict(image=identity(D/'hyle-apple'),private_adaptations=retry['adaptations'],source_identity=retry['private_source'],SDK_builds=0,native_builds=0,HTTP=0))
print('READY',flush=True)
'''
(O/'retry.py').write_text(runner)
for name,dest in [('main.apple.cc','model/main.apple.cc'),('mtp_graph.apple.h','model/mtp_graph.h'),('retry-plan.json','retry-plan.json'),('retry.py','retry.py')]:
 subprocess.run(['scp',str(O/name),'kiro@172.22.10.198:'+D+'/'+dest],check=True,timeout=30)
print(json.dumps(dict(private_adaptations=retry['adaptations']),indent=2))
