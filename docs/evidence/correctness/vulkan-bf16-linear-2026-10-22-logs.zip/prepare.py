"""Freeze only this batch's current owners, not a checkout or dependency copy."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1]
names=['src/compute_route_vulkan/vulkan_region.cc','src/compute_route_vulkan/vulkan_program.cc','src/compute_provider_ggml_vulkan/region.cc','docs/developer/current-work.md','tools/qwen35_text/README.md','test.ps1']
records=[]
for name in names:
    p=R/name;b=p.read_bytes();q=S/'before'/name;q.parent.mkdir(parents=True,exist_ok=True)
    assert not q.exists();q.write_bytes(b)
    records.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(S/'before.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8')
print('Frozen',len(records),'small current source/document owners.')
