"""Pure-host summary of the existing thresholded Vulkan allocation logs."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[3]
AN = ROOT / ".scratch/vulkan-bf16-linear-20261022"
AM = ROOT / ".scratch/vulkan-qwen-assembly-20261022"
THRESHOLD = 16 * 1024**2


def identity(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def parse(stage, name):
    directory = stage / name
    text = (directory / "stderr.log").read_text(encoding="utf-8")
    begins, allocated, failed, large = {}, {}, [], []
    for line_number, line in enumerate(text.splitlines(), 1):
        if m := re.fullmatch(r"AM_REGION_BEGIN id=(\d+) nodes=(\d+) input=(\d+) output=(\d+) internal_gross=(\d+)", line):
            values = list(map(int, m.groups()))
            region = values.pop(0)
            assert region not in begins
            begins[region] = {"line": line_number, **dict(zip(
                ("nodes", "input_bytes", "output_bytes", "internal_gross_bytes"), values))}
        elif m := re.fullmatch(r"AM_REGION_ALLOCATED id=(\d+) private=(\d+)", line):
            region, size = map(int, m.groups())
            assert region not in allocated
            allocated[region] = size
        elif m := re.fullmatch(r"AM_REGION_FAIL id=(\d+)", line):
            failed.append(int(m[1]))
        elif m := re.fullmatch(r"AM_REGION_LARGE id=(\d+) node=(\d+) op=(\S+) type=(\S+) bytes=(\d+) shape=(\S+)", line):
            large.append({"region": int(m[1]), "operation": m[3],
                          "dtype": m[4], "bytes": int(m[5])})
    assert list(begins) == list(range(1, len(begins) + 1))
    assert set(begins) == set(allocated) | set(failed)
    assert not set(allocated).intersection(failed)
    assert all(item["region"] in begins and item["bytes"] >= THRESHOLD for item in large)
    terminal = json.loads((directory / "result.json").read_text(encoding="utf-8"))
    assert terminal["state"] == "terminal" and terminal["exit"] == 1
    return text, begins, allocated, failed, large, terminal


def group(name, ids, begins, allocated):
    assert ids and all(i in allocated for i in ids)
    sizes = [allocated[i] for i in ids]
    return {"name": name, "first_region": ids[0], "last_region": ids[-1],
            "regions": len(ids), "private_requested_bytes": sum(sizes),
            "private_requested_mib": sum(sizes) / 1024**2,
            "zero_private_regions": sizes.count(0),
            "max_single_region_private_bytes": max(sizes),
            "begin_log_lines": [begins[ids[0]]["line"], begins[ids[-1]]["line"]]}


def main():
    new = parse(AN, "qwen-plain-run2")
    old = parse(AM, "qwen-plain-run3")
    text, begins, allocated, failed, large, terminal = new
    assert len(allocated) == 2349 and not failed and not large
    lines = text.splitlines()
    t1_line = next(i for i, line in enumerate(lines, 1) if line.startswith("compiled T=1 "))
    ready_line = next(i for i, line in enumerate(lines, 1) if line.startswith("initialized model_seconds="))
    t15 = [i for i, r in begins.items() if r["line"] < t1_line]
    t1 = [i for i, r in begins.items() if t1_line < r["line"] < ready_line]
    assert len(t15) == 789 and len(t1) == 1542
    half = len(t1) // 2
    def signature(ids):
        return [(tuple(r[k] for k in ("nodes", "input_bytes", "output_bytes", "internal_gross_bytes")), allocated[i])
                for i in ids for r in [begins[i]]]
    assert signature(t1[:half]) == signature(t1[half:])
    groups = [group("cold_T15_slot0", t15, begins, allocated),
              group("cold_T1_slot1", t1[:half], begins, allocated),
              group("cold_T1_slot0", t1[half:], begins, allocated)]
    cursor = ready_line
    for m in re.finditer(r"^prepared T=(\d+) visible=(\d+) .*$", text, re.MULTILINE):
        line = text.count("\n", 0, m.start()) + 1
        ids = [i for i, r in begins.items() if cursor < r["line"] < line]
        assert len(ids) == 6 and all(begins[i]["nodes"] == 7 for i in ids)
        groups.append(group(f"dynamic_paged_T{m[1]}_visible{m[2]}", ids, begins, allocated))
        cursor = line
    assert len(groups) == 6
    assert sum(g["regions"] for g in groups) == len(allocated)
    assert sum(g["private_requested_bytes"] for g in groups) == sum(allocated.values())
    old_text, old_begins, old_allocated, old_failed, old_large, old_terminal = old
    assert len(old_allocated) == 573 and old_failed == [574]
    old_large_success = [r for r in old_large if r["region"] in old_allocated]
    large_by_operation = {}
    for op in sorted({r["operation"] for r in old_large}):
        successful = [r for r in old_large_success if r["operation"] == op]
        attempted = [r for r in old_large if r["operation"] == op]
        large_by_operation[op] = {"successful_nodes": len(successful),
            "successful_node_bytes": sum(r["bytes"] for r in successful),
            "attempted_nodes": len(attempted), "attempted_node_bytes": sum(r["bytes"] for r in attempted)}
    paths = [AN / "qwen-plain-run2/stderr.log", AN / "qwen-plain-run2/result.json",
             AM / "qwen-plain-run3/stderr.log", AM / "qwen-plain-run3/result.json",
             AM / "diagnostic/source/region.cc", Path(__file__)]
    report = {
        "status": "ACTUAL_LOGS_RECOMPUTED_HOST_ONLY",
        "scope": "Thresholded native Region allocation counters; both runs exit1. No model/build/GPU execution by reviewer.",
        "images": {"after": terminal["image"], "before": old_terminal["image"]},
        "after": {"creation_attempts": len(begins), "successful_regions": len(allocated),
            "failed_regions": failed, "sum_private_requested_bytes": sum(allocated.values()),
            "groups": groups, "large_node_threshold_bytes": THRESHOLD,
            "logged_large_nodes": len(large), "logged_large_CPY_nodes": 0, "logged_large_CONT_nodes": 0,
            "terminal": "Ready, prefill, decode1 and decode2 completed; decode3 preparation then failed with Vulkan batch native output retained.",
            "observed_ids": list(map(int, re.findall(r"^(?:prefill|decode\d+) .* next=(\d+)$", text, re.MULTILINE))),
            "cold_slot_attribution": "Source-inferred from prepare_execution([15,1,1,1]) with initial parity0, alternating after every ordered call: T15 slot0 then T1 slot1 then T1 slot0. Logs explicitly delimit T15 versus T1 and ready. They do not print slot labels; the two 771-region T1 blocks have exactly equal nodes/input/output/internal/private signatures.",
            "source_anchors": ["tools/qwen35_text/main.cc:1587-1613", "tools/qwen35_text/main.cc:1735-1746", "tools/qwen35_text/main.cc:3908-3915"],
            "two_T1_cold_block_signatures_equal": True},
        "before_incomplete": {"creation_attempts": len(old_begins), "successful_regions": len(old_allocated),
            "failed_regions": old_failed, "sum_successful_private_requested_bytes": sum(old_allocated.values()),
            "large_node_threshold_bytes": THRESHOLD, "large_nodes_by_operation": large_by_operation,
            "coverage": "Only the first 573 successful nested regions of the initial T15 slot0; region574 failed allocation. No ready/inference or T1 slot was reached."},
        "limits": [
            "New cumulative counters span three completed cold slots and 18 dynamic paged Regions; old counters span an incomplete first cold slot. No matched-whole-run percentage is claimed.",
            "AM_REGION_ALLOCATED private is requested native graph private storage; summing allocations without free events is not simultaneously live storage or physical VRAM peak. It excludes original weights, common buffers, staging, native imports, driver allocations and other workspace.",
            "AM_REGION_LARGE logs only internal no-buffer/no-view-source nodes of at least16MiB. Zero after CPY/CONT above that threshold proves removal of those logged large expansions, not absence of smaller Copies, all weight representations, or all native allocations.",
            "Nested native Region counts are not public Graph step counts. No TPS, performance win, completed full-Qwen pass, or quality acceptance follows from these failed functional runs."],
        "sources": [identity(p) for p in paths],
        "recompute": "python .scratch/vulkan-bf16-linear-20261022/review/check_storage_after.py"}
    output = AN / "review/storage-after.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"report": identity(output), "after_private_bytes": sum(allocated.values()),
                      "before_incomplete_private_bytes": sum(old_allocated.values())}, indent=2))


if __name__ == "__main__":
    main()
