# AN: exact superseded images/linker outputs; current native images and objects stay.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = Join-Path $workspace '.scratch\vulkan-bf16-linear-20261022'
$targets = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\diagnostic-link1\qwen.exe'; Bytes = 68980736; SHA256 = 'd9e79e4845a16e04a00ebccefde6b8c2745d1e2e8c75dc25a048465bd1f4245b' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\diagnostic-link1\qwen.exp'; Bytes = 24982; SHA256 = '22009680a8100986dc81512bcb7e55de013196852f6186db9b817c5192f9f181' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\diagnostic-link1\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\diagnostic-link1\qwen.map'; Bytes = 32551065; SHA256 = 'df9c930dc67933f3b30c9e362f3b650aeeabc46c21463c46779795dacd6e3365' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\qwen-link1\qwen.exp'; Bytes = 24976; SHA256 = '22e67cf5af4aa42af22d49cb9f7b01a73fdefe2b8087dfb078939a8c7400d425' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\qwen-link1\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\qwen-link1\qwen.map'; Bytes = 32551930; SHA256 = '8b78e22ba5031fd1c7fd582506a9f226587032c965665011e0fc640aef2d5ca3' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link1\test.exe'; Bytes = 67933696; SHA256 = '9ca3838c908169ad24e2959d2be27e9b230c7131f567462fc8e7aa1b6aa2fed6' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link1\test.exp'; Bytes = 24976; SHA256 = '5bea5cbb89d9e758bbb3c7ee1b248d8aab0e2d5a7ba292c1a96860e9d938a7ac' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link1\test.lib'; Bytes = 41384; SHA256 = 'e8b2f56b280c09b2f7a259f184ba9923439c597a6227843d256c824b87a691fa' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link1\test.map'; Bytes = 30477202; SHA256 = 'd0e2efb920991d59ff4d66880c84f5685430e1de2758d14f3928dd7ec3b02dc9' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link2\test.exp'; Bytes = 24976; SHA256 = '235ad70fde682906280f5b95f60e069c3ff16dd0c918c0f31aabe834a639dd2c' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link2\test.lib'; Bytes = 41384; SHA256 = 'e8b2f56b280c09b2f7a259f184ba9923439c597a6227843d256c824b87a691fa' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-bf16-linear-20261022\test-link2\test.map'; Bytes = 30476714; SHA256 = 'c1f16c8541ed0d329467446a08dfa4a977768a61b8fe80d8848acc36d8566fe4' }
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  if ($leaf.PSIsContainer -or -not $leaf.FullName.StartsWith($allowed + '\', [StringComparison]::OrdinalIgnoreCase) -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
