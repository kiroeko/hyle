"""Replace the Vulkan current failure with the actual result of this batch."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
p=R/'docs/developer/current-work.md';t=p.read_text(encoding='utf8')
before='Vulkan保留预算身份和device Buffer IO本批已实现并实测，完整普通推理当前因权重重复展开的私有存储耗尽而失败，见下。'
after='Vulkan预算身份及device IO已实测，整权重F32展开造成的OOM本批已修；普通版已完成prefill及两次decode，第三次槽复用仍被旧输出引用计数门拒绝，见下。'
assert t.count(before)==1;t=t.replace(before,after)
start=t.index('**Vulkan完整普通推理尚未跑通。**');end=t.index('最新四臂的64token续文',start)
t=t[:start]+'''**[Vulkan BF16矩阵路径已修复并实际越过OOM](../evidence/correctness/vulkan-bf16-linear-2026-10-22.json)。** 原native MatMul已有BF16权重／F32累加及最终BF16舍入，现按真实资格优先走该路径，避免上层wrapper抢先升宽整权重。自然permute权重复用原payload；dense逻辑RHS需要的不可变冷转置保持原dtype，native／promote两类pack按不同key复用。没有改模型数学、公共API、Provider算法或其它BF16算子的后备。

新永久消费者实际通过T1／T15各两次不同输入，三输出共12,288元素：原stored[N,K]→permute与同义dense[K,N]常量的BF16 MatMul、原权重直接F32 scores；按decoded-BF16独立FP64点积核数值、BF16舍入、F32近tie及极端指数范围，原权重／输入全字节和只读权限保持。首轮fixture漏符号输出spec，构图失败后已修；未改数值阈值。只增量编译两产品TU与小测试，未重建SDK／shader。

同原P15／4、C64／N1／R1及256MiB缓存额度，完整320份权重已加载、T15单槽和T1双槽已初始化；普通版实际prefill／decode1／decode2返回1328／5675／11，第三次decode准备报`Vulkan batch native output retained`。本批复用旧单TU诊断对象，不加产品日志：新2349个region私有分配累计198,830,080字节，阈值≥16MiB的大CPY／CONT为0；其中冷T15为132,346,240，两个T1块各32,824,128，动态reader另计。旧窗仅前573成功就达7,760,350,944字节并OOM，两者覆盖不同，这些累计值不能当物理显存峰或TPS收益。

**下一步补分页／ragged reader的旧输出复用接线。** 普通region已有整block轮换；两种reader尚先走旧output-owner计数门。需将真实退休后的冷布局编辑、同一次输出epoch准备／重试、完整bind与最终seal串好，继续保旧readonly、原Run／Program／endpoint和严格submit；不能把变化后的计数直接改成基线。当前失败仅证明计数不一致，尚不能区分外逃读者增加与下游私有引用减少。完整Vulkan普通版和MTP尚未通过，本批没有新完整速度／显存对照，页末性能表保持。

''' +t[end:]
for before,after in {
'完整消费者首次准备因权重F32展开／cont私有内存耗尽而失败，需修底座':'整权重F32展开的OOM已修，完整消费者完成prefill及两次decode；接下来补paged／ragged reader输出epoch复用',
'完整普通版先修权重重复展开导致的OOM。随后补Apple前缀／原生取消组合与数值质量':'权重重复展开OOM已修，完整普通版仍需补paged／ragged输出复用。随后补Apple前缀／原生取消组合与数值质量'
}.items():
    assert t.count(before)==1,before;t=t.replace(before,after)
p.write_text(t,encoding='utf8')
p=R/'tools/qwen35_text/README.md';t=p.read_text(encoding='utf8')
before='[本批实际运行](../../docs/evidence/correctness/qwen-vulkan-assembly-2026-10-22.json)加载全部文本权重并编译冷图，但首次执行准备因大权重重复F32转换／物化耗尽私有存储而失败，尚未完成普通推理或MTP。'
after='[装配与IO结果](../../docs/evidence/correctness/qwen-vulkan-assembly-2026-10-22.json)之后，[BF16矩阵修复](../../docs/evidence/correctness/vulkan-bf16-linear-2026-10-22.json)已消除大权重重复F32展开的OOM，完整普通版实际完成prefill及两次decode，第三次槽复用仍报`Vulkan batch native output retained`。完整普通推理和MTP尚未通过。'
assert t.count(before)==1;t=t.replace(before,after);p.write_text(t,encoding='utf8')
print('Replaced current Vulkan status; complete performance table unchanged.')
