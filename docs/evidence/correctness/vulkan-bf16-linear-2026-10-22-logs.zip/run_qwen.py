"""Same original Qwen inputs and finite functional journey as AM."""
from pathlib import Path
import argparse,importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('an_qwen_run',R/'.scratch/vulkan-qwen-assembly-20261022/run_qwen.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.S=S;m.R=R
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['plain','mtp']);p.add_argument('--attempt',type=int,default=1);p.add_argument('--image-attempt',type=int,default=1);p.add_argument('--diagnostic',action='store_true');a=p.parse_args()
    m.run(a.mode,a.attempt,a.image_attempt,a.diagnostic)
