"""Freeze this bounded implementation and actual red/green evidence."""
from pathlib import Path
import argparse,difflib,hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1];E=R/'docs/evidence/correctness';NAME='vulkan-bf16-linear-2026-10-22'
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def read(p):return json.loads(p.read_bytes())
def ident(p):
    p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def prepare():
    assert read(S/'live.json')['state']=='terminal'
    keep={'qwen-link1/qwen.exe','test-link2/test.exe'}
    paths=[p for root in S.glob('*-link*')for p in root.iterdir()if p.is_file()and(p.suffix in ['.map','.lib','.exp']or(p.suffix=='.exe'and p.relative_to(S).as_posix()not in keep))]
    for p in paths:assert p.resolve().is_relative_to(S.resolve())
    records=[ident(p)for p in paths]
    rows=['  @{ Path = '+"'"+str(R/x['path'])+"'; Bytes = "+str(x['bytes'])+"; SHA256 = '"+x['sha256']+"' }"for x in records]
    text='''# AN: exact superseded images/linker outputs; current native images and objects stay.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = Join-Path $workspace '.scratch\\vulkan-bf16-linear-20261022'
$targets = @(
'''+ '\n'.join(rows)+'''
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  if ($leaf.PSIsContainer -or -not $leaf.FullName.StartsWith($allowed + '\\', [StringComparison]::OrdinalIgnoreCase) -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
'''
    p=R/'test.ps1';p.write_text(text,encoding='utf8');(S/'cleanup-test.ps1').write_bytes(p.read_bytes())
    save(S/'cleanup-plan.json',dict(executed_from=ident(p),frozen_script=ident(S/'cleanup-test.ps1'),targets=records,logical_file_bytes=sum(x['bytes']for x in records)))
    print(json.dumps(dict(script=ident(p),targets=len(paths),logical_file_bytes=sum(x['bytes']for x in records))))

def publish():
    plan=read(S/'cleanup-plan.json');assert all(not(R/x['path']).exists()for x in plan['targets'])
    assert read(S/'test-run1/run.result.json')['exit']==1
    assert read(S/'test-run2/run.result.json')['exit']==0
    assert '12288 checked output elements'in(S/'test-run2/run.stdout.log').read_text()
    assert 'symbolic operation requires explicit output tensor specs'in(S/'test-run1/run.stderr.log').read_text()
    runs=[read(S/f'qwen-plain-run{i}/result.json')for i in [1,2]]
    for i,x in enumerate(runs,1):
        assert x['state']=='terminal'and x['exit']==1
        t=(S/f'qwen-plain-run{i}/stderr.log').read_text()
        assert all(x in t for x in ['next=1328','next=5675','next=11','Vulkan batch native output retained'])
        assert 'ErrorOutOfDeviceMemory'not in t
    changes=[];patch=[]
    before={p.relative_to(S/'before').as_posix():p for p in(S/'before').rglob('*')if p.is_file()and p.name!='test.ps1'}
    before['tests/graph_route_vulkan/bfloat_linear_consumer.cc']=None
    for rel,p in sorted(before.items()):
        q=R/rel;previous=p.read_bytes()if p else b'';current=q.read_bytes()
        if previous==current:continue
        changes.append(dict(before=ident(p)if p else None,current=ident(q)))
        frozen=S/'source'/rel;frozen.parent.mkdir(parents=True,exist_ok=True);frozen.write_bytes(current)
        patch+=list(difflib.unified_diff(previous.decode('utf8').splitlines(True),current.decode('utf8').splitlines(True),fromfile='before/'+rel,tofile='current/'+rel))
    (S/'changes.diff').write_text(''.join(patch),encoding='utf8');save(S/'current-source.json',changes)
    for tag,attempt in [('route-region',1),('route-program',1),('test',2)]:
        v=read(S/f'compile{attempt}/{tag}/identity.json')
        assert hashlib.sha256(Path(v['source']['path']).read_bytes()).hexdigest()==v['source']['sha256']
    marker='## 最新完整性能对比'
    assert (S/'before/docs/developer/current-work.md').read_text(encoding='utf8').split(marker)[1]==(R/'docs/developer/current-work.md').read_text(encoding='utf8').split(marker)[1]
    storage=read(S/'review/storage-after.json')
    z=E/(NAME+'-logs.zip');count=0
    with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
        for p in sorted(S.rglob('*')):
            if not p.is_file()or p.suffix.lower()not in ['.py','.json','.log','.cc','.h','.md','.txt','.diff','.ps1','.tsv']:continue
            if 'tmp'in p.relative_to(S).parts or p.stat().st_size>1024*1024:continue
            archive.write(p,p.relative_to(S).as_posix());count+=1
    with zipfile.ZipFile(z)as archive:assert archive.testzip()is None
    report=dict(date='2026-10-22',status='bf16_matrix_fix_passed_full_qwen_reuse_incomplete',
      implementation=['Prefer the existing qualified BF16 native MatMul instead of the full-F32 wrapper','Preserve BF16 immutable dense RHS during necessary cold transpose packing','Separate native and promoted pack replacements for the same source'],
      contracts=dict(native_provider_changed=False,consumer_mathematics_changed=False,public_API_changed=False,other_BF16_operation_fallback_changed=False,weight_dtype='BF16',accumulation='F32',ordinary_output='BF16',scores='F32'),
      changed_files=changes,regression=dict(result=ident(S/'test-run2/run.result.json'),image=read(S/'test-run2/image.json'),log=ident(S/'test-run2/run.stdout.log'),checked_output_elements=12288,rows=[1,15],different_inputs_per_shape=2,independent_reference='FP64 dots of decoded original BF16; nearest/even BF16 output oracle',checks=['stored[N,K] permute and same-dtype dense[K,N] cold packing','ordinary BF16 outputs and native F32 near-tie scores','BF16 exponent range: exact 2^30 * 2^-30 = 1; no silent F16 narrowing','original activation and both constant payloads byte-identical; readonly permissions and exact output resources']),
      failed_fixture=dict(result=ident(S/'test-run1/run.result.json'),failure='symbolic operation requires explicit output tensor specs',fix='Three symbolic operations now provide explicit BF16/F32 TensorSpecs; mathematical fixture and tolerances unchanged'),
      qwen_runs=runs,qwen_actual=dict(loaded_text_tensors=320,loaded_requested_bytes=3763655360,parameters='Original AM P15/natural4, C64, N1/R1, cache256MiB, prefix off, commands',completed_ids=[1328,5675,11],failure='Vulkan batch native output retained before third decode preparation',complete_plain_pass=False,mtp_run=False),
      storage_diagnostic=dict(original_AM_diagnostic_object_reused=True,product_logging_changed=False,report=ident(S/'review/storage-after.json'),successful_regions=2349,cumulative_private_allocation_bytes=198830080,large_weight_CPY_CONT_threshold_bytes=16777216,large_weight_CPY_CONT_nodes=0,old_partial_successful_regions=573,old_partial_private_bytes=7760350944,old_next_region_failed=True,coverage_differs=True,physical_vram_peak_measured=False),
      next_action='Connect existing whole-block retained-output epochs to paged/ragged readers; preserve pure native retirement, one pending cold epoch through failed export/retry, full binding and final seal before strict submit. Do not update owner baselines to absorb readers.',
      limitations=['Only the listed finite regression and partial actual full-model flow; no complete quality claim','No new complete performance/memory comparison; current-work final table unchanged','No CMake configure or SDK/shader/NVCC rebuild; exact cached closure with two incremental product TUs','No new CPU/Apple native run because their implementation was not changed'],
      cleanup=plan,evidence_zip=ident(z),archive_files=count)
    save(E/(NAME+'.json'),report)
    print(json.dumps(dict(report=ident(E/(NAME+'.json')),logs=ident(z),removed_logical_file_bytes=plan['logical_file_bytes'])))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','publish']);a=p.parse_args();prepare()if a.action=='prepare'else publish()
