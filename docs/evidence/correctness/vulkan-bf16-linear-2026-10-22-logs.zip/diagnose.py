"""Reuse the existing AM cold-storage diagnostic object, with current AN routing."""
from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];AM=R/'.scratch/vulkan-qwen-assembly-20261022'
spec=importlib.util.spec_from_file_location('an_diag_build',S/'build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c=m.b,m.c
base=c.read(S/'qwen-link1/link-plan.json')
old=c.read(m.m.owner('src/compute_provider_ggml_vulkan/region.cc'))['object']
record=c.read(AM/'compile2/diag-region/identity.json');new=record['object']
assert b.identity(record['source']['path'])==record['source']and b.identity(new['path'])==new
origin=c.read(AM/'diagnostic/recipe.json')['source'];assert b.identity(origin['path'])==origin
assert sum(c.key(x['path'])==c.key(old['path'])for x in base['inputs'])==1
out=S/'diagnostic-link1';out.mkdir();(out/'tmp').mkdir();image=out/'qwen.exe'
command=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[new if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
for x in inputs:assert b.identity(x['path'])==x
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,diagnostic_only=True,reused_AM_diagnostic_object=b.identity(AM/'compile2/diag-region/identity.json'),SDK_builds=0,NVCC=0))
env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
c.save(out/'runtime-environment.json',c.read(S/'qwen-link1/runtime-environment.json'));c.save(out/'ready.json',dict(image=b.identity(image)))
