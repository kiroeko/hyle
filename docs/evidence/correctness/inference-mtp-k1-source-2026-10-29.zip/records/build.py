"""One current Tiny CXX/link and three explicit consumers; no automatic retry."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OLD = R / '.scratch/inference-mtp-device-packet-20261029'
BASE = OLD / 'model-link-base.json'
PREVIOUS = OLD / 'refinement/compile/tiny/compiled.json'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
SOURCE = R / 'tests/tools/qwen_host_image_test.cc'
CASES = {'relay-cpu': ('cpu', '--mtp-relay'),
         'relay-cuda': ('cuda', '--mtp-relay'),
         'mixed-cuda': ('cuda', '--mtp-mixed-lag')}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


b = module(R / '.scratch/inference-mixed-lag-20261029/run.py', 'k1_source_existing_driver')
t = b.t
b.W = t.W = W
b.CASES = CASES


def prepare():
    base = t.read(BASE); previous = t.read(PREVIOUS)
    assert len(base['retained']) == 227
    assert len(previous['project_dependencies']) == 224
    retained_keys = {t.key(row['path']) for row in base['retained']}
    assert len(retained_keys) == 227
    for row in base['retained']: t.exact(row)
    compile_args = []
    for index, arg in enumerate(base['compile']):
        if index and base['compile'][index - 1].casefold() == '/sourcedependencies':
            arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        compile_args.append(arg)
    assert sum(t.key(arg) == t.key(SOURCE) for arg in compile_args) == 1
    consumers = [arg for arg in base['link'] if arg.casefold().endswith('.obj')
                 and t.key(arg) not in retained_keys]
    assert len(consumers) == 1
    link_args = []
    for arg in base['link']:
        if t.key(arg) == t.key(consumers[0]): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/tiny/unit.obj') for arg in link_args) == 1
    assert all(sum(t.key(arg) == key for arg in link_args) == 1 for key in retained_keys)
    paths = {t.key(row['path']): row['path'] for row in previous['project_dependencies']}
    for relative in ('engine/models/qwen35/main.cc', 'engine/inference/submission_views.h',
                     'engine/inference/execution_episode.h', 'tests/tools/qwen_host_image_test.cc',
                     'tests/tools/qwen_mtp_relay_case.h'):
        paths[t.key(R / relative)] = str(R / relative)
    env = t.read(OLD / 'refinement/environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local execution only; never print/archive values.
    t.save(W / 'plan.json', dict(base=t.pin(BASE), previous_consumer=t.pin(PREVIOUS),
        compile=compile_args, link=link_args, retained=base['retained'], runtime=base['runtime'],
        sources=list(paths.values()), fixture=t.pin(PLAIN / 'weights.tsv'), prompt=t.pin(PLAIN / 'prompt.ids'),
        helpers=[t.pin(__file__), t.pin(R / '.scratch/inference-mixed-lag-20261029/run.py'),
                 t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        cases={name: dict(backend=backend, flag=flag) for name, (backend, flag) in CASES.items()},
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=228, retained_inputs=227,
                    native_processes=3, downloads=0)))
    print('PREPARED 227 retained inputs, one fresh Tiny CXX/link, three explicit consumers')


def validate():
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    plan = t.read(W / 'plan.json')
    for row in plan['helpers']: t.exact(row)
    t.exact(plan['base']); t.exact(plan['previous_consumer'])
    return plan


b.validate = validate
freeze = b.freeze
compile = b.compile
parse_compile = b.parse_compile
link = b.link


def parse(name):
    if name == 'mixed-cuda':
        b.parse(name)  # Preserve the actual mixed-lag state/numeric oracle.
        return
    backend, _ = CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    assert len(reports) == 1
    report = reports[0]
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['quality_claim'] is False and report['performance_claim'] is False
    t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'])


def run(name):
    plan = validate(); backend, flag = CASES[name]
    ready = t.read(W / 'ready-tiny.json')
    t.exact(ready['image']); t.exact(plan['fixture']); t.exact(plan['prompt'])
    # The original recorder writes command/process/stdout/stderr before parsing.
    t.execute([ready['image']['path'], '--' + backend, str(PLAIN), flag], W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'freeze', 'validate', 'compile', 'parse_compile', 'link'): globals()[action]()
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
