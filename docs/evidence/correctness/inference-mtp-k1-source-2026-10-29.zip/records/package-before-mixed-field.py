"""Offline collector for this finite K1 Source batch; starts no tools or models."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-mtp-k1-source-2026-10-29'


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'k1_archive_recorder')
audit = module(W / 'audit_reports.py', 'k1_archive_report_audit')


def terminal(directory, success=False):
    process = t.read(directory / 'process.json')
    assert process['state'] == 'TERMINAL' and isinstance(process['exit'], int), directory
    if success: assert process['exit'] == 0 and not process['timed_out'], directory
    return process


def report(directory, ready_path, backend, relay=True):
    process = terminal(directory, True)
    ready = t.read(ready_path)
    assert t.key(t.command(directory / 'command.json')[0]) == t.key(ready['image']['path']), directory
    rows = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
            if line.startswith('{')]
    assert len(rows) == 1 and rows[0] == t.read(directory / 'report.json'), directory
    value = rows[0]
    if relay: audit.check_report(value, backend)
    else:
        assert value['status'] == 'PASS' and value['mode'] == 'mtp_mixed_lag' and value['backend'] == backend
        assert value['quality_claim'] is False and value['performance_claim'] is False
        assert value['state_checks']
        for row in value['state_checks']:
            assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
            assert row['payloads_byte_equal'] is (not row['differences'])
            for difference in row['differences']:
                assert difference['role'] == 3 and difference['nonfinite_differences'] == 0
                assert math.isfinite(difference['maximum_absolute']) and 0 <= difference['maximum_absolute'] <= 3e-6
    return dict(directory=str(directory.relative_to(W)), process=process,
        ready=t.pin(ready_path), image=ready['image'],
        case=value.get('case', value.get('mode')), backend=backend,
        state_comparisons=len(value['state_checks']),
        byte_exact_state_comparisons=sum(row['payloads_byte_equal'] for row in value['state_checks']),
        actual_counts={key: value[key] for key in ('arms', 'native_submissions', 'source_submissions',
            'successor_submissions', 'successor_discards', 'priming_submissions',
            'cpu_optional_source_declines', 'target_submissions', 'mixed_target_submissions') if key in value})


def main(final_run, final_ready):
    final_run, final_ready = (W / final_run).resolve(), (W / final_ready).resolve()
    assert final_run.is_relative_to(W) and final_ready.is_relative_to(W)
    previous_ready = W / 'refinement2/ready-tiny.json'
    successes = [report(W / 'refinement2/runs/relay-cpu', previous_ready, 'cpu'),
                 report(W / 'refinement2/runs/mixed-cuda', previous_ready, 'cuda', False),
                 report(final_run, final_ready, 'cuda')]
    fixed = t.read(final_ready)
    assert len(fixed['inputs']) == 228 and fixed['process']['state'] == 'TERMINAL'
    assert fixed['process']['exit'] == 0 and not fixed['process']['timed_out']
    assert t.read(W / 'plan.json')['counts']['retained_inputs'] == 227
    members, source_index, compiled_index, process_index = {}, [], [], []
    metadata_suffixes = {'.json', '.log', '.py', '.patch', '.xml', '.md', '.txt', '.d'}

    def add(path, name=None, expected=None):
        path = Path(path).resolve()
        assert path.is_file() and 'environment' not in path.name.casefold(), path
        assert path.suffix.casefold() in metadata_suffixes | {'.h', '.hh', '.hpp', '.cc', '.cpp', '.cu', '.c', '.cuh'}, path
        body = path.read_bytes(); digest = hashlib.sha256(body).hexdigest()
        if expected: assert (len(body), digest) == (expected['bytes'], expected['sha256']), path
        name = name or 'records/' + path.relative_to(W).as_posix()
        assert name not in members or members[name] == body, name
        members[name] = body
        return name

    # Only this bounded batch is enumerated. SDK inputs are pins, never payloads.
    metadata = sorted(path for path in W.rglob('*') if path.is_file() and
        path.suffix.casefold() in metadata_suffixes and 'environment' not in path.name.casefold())
    for path in metadata: add(path)
    bodies = [path for path in W.rglob('*') if path.is_file() and
              path.suffix.casefold() in {'.h', '.hh', '.hpp', '.cc', '.cpp', '.cu', '.c', '.cuh', '.py'}]
    body_pins = {}

    def source(row, receipt):
        original = Path(row['path']).resolve()
        candidates = [original, *bodies]
        found = None
        for path in candidates:
            if not path.is_file() or path.stat().st_size != row['bytes']: continue
            if path not in body_pins: body_pins[path] = t.pin(path)
            if body_pins[path]['sha256'] == row['sha256']: found = path; break
        assert found is not None, ('missing exact historical source body', receipt, row)
        name = f"sources/{row['sha256']}/{original.name}"
        add(found, name, row)
        source_index.append(dict(receipt=receipt, original=row, archive=name, found_at=str(found)))

    freezes = sorted(W.rglob('source-freeze.json'))
    assert {W / 'source-freeze.json', W / 'refinement/source-freeze.json',
            W / 'refinement2/source-freeze.json'}.issubset(set(freezes))
    inventories = {}
    for path in freezes:
        rows = t.read(path); assert isinstance(rows, list) and rows
        inventories[path.parent] = {t.key(row['path']): row for row in rows}
        for row in rows: source(row, str(path.relative_to(W)))
    for path in sorted(W.rglob('compiled.json')):
        value = t.read(path); assert value['process']['state'] == 'TERMINAL' and value['process']['exit'] == 0
        frozen = inventories[path.parents[2]]
        dependencies = value['project_dependencies']
        if path in (W / 'refinement/compile/tiny/compiled.json', W / 'refinement2/compile/tiny/compiled.json'):
            assert len(dependencies) == 225
        for row in [value['source'], *dependencies]:
            expected = frozen.get(t.key(row['path']))
            assert expected and (expected['bytes'], expected['sha256']) == (row['bytes'], row['sha256']), (path, row)
            source(row, str(path.relative_to(W)))
        compiled_index.append(dict(receipt=str(path.relative_to(W)), source=value['source'],
            project_dependencies=len(dependencies), object=value['object'], process=value['process']))
    diagnostic_objects = {t.key(row['object']['path']) for row in compiled_index
                          if row['source']['path'].replace('\\', '/').startswith(str(W).replace('\\', '/') + '/diagnostic')}
    assert not diagnostic_objects.intersection(t.key(row['path']) for row in fixed['inputs'])
    # Explicit original SDK body and source pins, including diagnostic overlays.
    for path in sorted(W.rglob('plan.json')):
        value = t.read(path)
        for key in ('before', 'product', 'source'):
            row = value.get(key)
            if isinstance(row, dict) and Path(row.get('path', '')).suffix.casefold() in {'.cc', '.h', '.cu'}:
                source(row, str(path.relative_to(W)))
        references = [value[key] for key in ('base', 'previous_consumer', 'recipe') if key in value]
        references += value.get('helpers', [])
        for row in value.get('helpers', []): source(row, str(path.relative_to(W)))
        references += [value['original_sdk'][key] for key in ('receipt', 'dependencies')
                       if key in value.get('original_sdk', {})]
        for row in references:
            path = Path(row['path']).resolve()
            if path.is_relative_to(W): continue
            assert path.is_relative_to(R) and path.suffix.casefold() in {'.json', '.py', '.patch'}, path
            add(path, 'references/' + path.relative_to(R).as_posix(), row)
    for path in sorted(W.rglob('process.json')):
        terminal(path.parent)
        args = t.command(path.parent / 'command.json'); program = Path(args[0]).name.casefold()
        kind = ('CXX' if program in ('cl.exe', 'clang++', 'clang++.exe') else
                'link' if program in ('link.exe', 'lld-link.exe') else
                'native' if '/runs/' in path.as_posix() or path.parent.name == 'run-cuda' else 'tooling')
        process_index.append(dict(kind=kind, receipt=str(path.relative_to(W)), process=t.read(path)))
    manifest = dict(schema='hyle.finite-k1-source.archive.v1',
        files=[dict(path=name, bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
               for name, body in sorted(members.items())], source_versions=source_index)
    members['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    out_json, out_zip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not out_json.exists() and not out_zip.exists(), 'do not overwrite an earlier evidence artifact'
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, body in sorted(members.items()): archive.writestr(name, body)
    with zipfile.ZipFile(out_zip) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(members)
        for name, body in members.items():
            saved = archive.read(name)
            assert len(saved) == len(body) and hashlib.sha256(saved).digest() == hashlib.sha256(body).digest(), name
    summary = dict(schema='hyle.inference-mtp-k1-source.v1', status='PASS_FINITE_SCOPE',
        final_run=str(final_run.relative_to(W)), final_ready=t.pin(final_ready), successes=successes,
        state_comparisons=sum(row['state_comparisons'] for row in successes),
        byte_exact_state_comparisons=sum(row['byte_exact_state_comparisons'] for row in successes),
        actual_processes=process_index,
        counts={kind: sum(row['kind'] == kind for row in process_index) for kind in ('CXX', 'link', 'native')},
        failed_processes=[row for row in process_index if row['process']['exit'] != 0 or row['process']['timed_out']],
        compiled=compiled_index, initial_SDK_input_roster_identity_only=227,
        sources=dict(version_references=len(source_index), unique_content=len({row['archive'] for row in source_index})),
        limits=['Finite synthetic GA R1 greedy K1 full/partial/quota/cancel consumers; CPU proves typed Source decline and serial continuation only.',
            'CUDA priming and submitted successor facts are the actual consumer report; no simultaneous-native-inflight claim.',
            'Preserve every failed attempt and diagnostic; no natural RequestLoop K1 or continuous MTP pipeline completion claim.',
            'No sampled K1, model-EOS journey, Apple/Vulkan, quality or performance conclusion; mixed-lag CUDA is a separate finite regression.'],
        archive={**t.pin(out_zip), 'members': len(members), 'crc_and_every_member_sha256_readback': True})
    t.save(out_json, summary)
    print(json.dumps(dict(summary=t.pin(out_json), archive=summary['archive']), ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--final-run', required=True, help='Actual successful CUDA run directory relative to this batch')
    parser.add_argument('--final-ready', required=True, help='Actual linked ready JSON used by that final CUDA process')
    options = parser.parse_args()
    main(options.final_run, options.final_ready)
