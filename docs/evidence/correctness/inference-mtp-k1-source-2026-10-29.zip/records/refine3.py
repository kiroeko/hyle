"""Fresh Tiny only, with the already compiled production Store SDK fix."""
from pathlib import Path
import contextlib
import importlib.util
import io
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('refined_k1_source3', ROOT / 'build.py')
x = importlib.util.module_from_spec(spec); spec.loader.exec_module(x)
x.W = x.b.W = x.t.W = ROOT / 'refinement3'
x.BASE = ROOT / 'refinement3-base.json'
x.CASES = x.b.CASES = {'relay-cuda': ('cuda', '--mtp-relay')}
original_validate = x.validate


def validate():
    plan = original_validate()
    overlay = x.t.read(x.BASE)
    for field in ('receipt', 'compiled_source'):
        x.t.exact(overlay['sdk_replacement'][field])
    return plan


x.validate = x.b.validate = validate


def prepare():
    overlay = x.t.read(x.BASE)
    fix = x.t.read(overlay['sdk_replacement']['receipt']['path'])
    assert fix['process']['state'] == 'TERMINAL' and fix['process']['exit'] == 0 and not fix['process']['timed_out']
    for row in fix['project_dependencies']: x.t.exact(row)
    # Reuse the original metadata builder; replace its fixed three-case label
    # and count before this new, independent plan is frozen.
    with contextlib.redirect_stdout(io.StringIO()): x.prepare()
    path = x.W / 'plan.json'; plan = x.t.read(path)
    plan['counts']['native_processes'] = 1
    plan['helpers'].extend((x.t.pin(__file__), x.t.pin(ROOT / 'audit_reports.py')))
    plan['sdk_replacement'] = overlay['sdk_replacement']
    path.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PREPARED refinement3: one Tiny CXX/link, production Store OBJ retained, only relay-cuda')


def auditor():
    spec = importlib.util.spec_from_file_location('k1_reprime_strict_audit', ROOT / 'audit_reports.py')
    audit = importlib.util.module_from_spec(spec); spec.loader.exec_module(audit)
    return audit


def parse(name):
    assert name == 'relay-cuda'
    out = x.W / 'runs' / name; process = x.t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 1
    report = auditor().check_report(reports[0], 'cuda')
    x.t.save(out / 'report.json', report)
    print('PASS relay-cuda PID', process['pid'], 'six state comparisons; native44/priming15')


x.parse = parse


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action in ('freeze', 'validate', 'compile', 'parse_compile', 'link'): getattr(x, action)()
    elif action in ('run', 'parse'):
        assert sys.argv[2] == 'relay-cuda'
        getattr(x, action)(sys.argv[2])
    elif action == 'audit': auditor().audit(x.W / 'runs/relay-cuda', 'cuda')
    else: raise SystemExit(action)
