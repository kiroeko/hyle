"""Explicit one-production-TU/link/one-CUDA run; all failures retain raw facts."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'k1_fix_driver_recorder')
t.W = W


def validate():
    plan = t.read(W / 'plan.json')
    for field in ('base', 'source', 'before', 'recipe', 'tiny', 'tiny_object', 'source_freeze', 'production_executable'):
        t.exact(plan[field])
    for row in plan['helpers'] + t.read(W / 'source-freeze.json'): t.exact(row)
    return plan


def parse_compile():
    plan = validate(); process = t.read(W / 'logs/slots-region/process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    depfile = W / 'compile/slots-region/dependencies.json'
    assert t.key(t.read(depfile)['Data']['Source']) == t.key(plan['source']['path'])
    deps = [t.pin(path) for path in t.dep_paths(depfile) if t.project(path)]
    frozen = {t.key(row['path']): row for row in t.read(W / 'source-freeze.json')}
    assert all(t.key(row['path']) in frozen and
               (row['bytes'], row['sha256']) == (frozen[t.key(row['path'])]['bytes'], frozen[t.key(row['path'])]['sha256'])
               for row in deps)
    t.save(W / 'compile/slots-region/compiled.json', dict(source=plan['source'], object=t.pin(W / 'compile/slots-region/unit.obj'),
        process=process, command=t.pin(W / 'logs/slots-region/command.json'), dependencies=t.pin(depfile), project_dependencies=deps))
    print('CXX METADATA PASS', process['pid'])


def compile():
    plan = validate(); (W / 'compile/slots-region').mkdir(parents=True)
    t.execute(plan['compile'], W / 'logs/slots-region', 300)
    parse_compile()


def link():
    plan = validate(); compiled = t.read(W / 'compile/slots-region/compiled.json'); t.exact(compiled['object'])
    for row in plan['retained'] + [plan['tiny_object']]: t.exact(row)
    t.exact(plan['runtime']); (W / 'bin').mkdir()
    alias = W / 'bin' / Path(plan['runtime']['path']).name
    alias.hardlink_to(plan['runtime']['path']); assert alias.samefile(plan['runtime']['path'])
    process = t.execute(plan['link'], W / 'logs/link', 240)
    inputs = list(plan['retained']); inputs.insert(plan['original_sdk']['index'], compiled['object'])
    inputs.append(plan['tiny_object']); assert len(inputs) == 228
    assert inputs[47] == plan['production_executable']
    t.save(W / 'ready-tiny.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=inputs, compiled=compiled,
        reused_tiny=plan['tiny_object'], process=process, runtime=plan['runtime'], source_freeze=plan['source_freeze']))
    print('LINK PASS', process['pid'])


def auditor():
    return module(W.parent / 'audit_reports.py', 'k1_fix_strict_report_audit')


def parse():
    out = W / 'run-cuda'; process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 1
    report = auditor().check_report(reports[0], 'cuda')
    t.save(out / 'report.json', report)
    print('PARSED mtp-relay CUDA PID', process['pid'], 'six state comparisons')


def run():
    plan = validate(); ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    t.exact(plan['fixture']); t.exact(plan['prompt'])
    fixture = str(Path(plan['fixture']['path']).parent)
    t.execute([ready['image']['path'], '--cuda', fixture, '--mtp-relay'], W / 'run-cuda', 300)
    parse()


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('validate', 'compile', 'parse_compile', 'link', 'run', 'parse'): globals()[action]()
    elif action == 'audit': auditor().audit(W / 'run-cuda', 'cuda')
    else: raise ValueError(action)
