"""Offline preparation: one production slots_region TU, original Tiny and SDK."""
from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
PARENT = W.parent / 'refinement2'
BASE = R / '.scratch/inference-mtp-device-packet-20261029/model-link-base.json'
SOURCE = R / 'src/graph/slots_region.cc'


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'k1_source_fix_recorder')
t.W = W


def main():
    base = t.read(BASE); tiny_path = PARENT / 'compile/tiny/compiled.json'; tiny = t.read(tiny_path)
    assert len(base['retained']) == 227 and len(tiny['project_dependencies']) == 225
    assert tiny['process']['state'] == 'TERMINAL' and tiny['process']['exit'] == 0 and not tiny['process']['timed_out']
    t.exact(tiny['object'])
    matches, graph_matches = [], []
    for index, row in enumerate(base['retained']):
        deps = Path(row['path']).parent / 'dependencies.json'
        if not deps.is_file(): continue
        actual = t.read(deps).get('Data', {}).get('Source', '')
        if not actual: continue
        canonical = t.canonical(actual)
        if t.key(canonical) == t.key(SOURCE): matches.append((index, row, deps, actual))
        if t.key(canonical) == t.key(R / 'src/graph/executable.cc'): graph_matches.append((index, row))
    assert len(matches) == len(graph_matches) == 1
    index, replaced, deps, actual = matches[0]
    assert index == 218 and replaced['sha256'] == 'a22d65c1e4c990845baa629f76eaad1523882e971de82bda776b1d1bca9dc325'
    assert graph_matches[0][0] == 47 and graph_matches[0][1]['sha256'] == '8199cdcf68801effed711293aaf32e2e212cb6c5668f552bb8af837c01c102dc'
    receipt = Path(replaced['path']).parent / 'compiled.json'; original = t.read(receipt)
    t.exact(original['command']); recipe = original['command']
    for row in base['retained']: t.exact(row)
    command = t.command(recipe['path']); rewritten = []
    for position, arg in enumerate(command):
        if t.key(arg) == t.key(SOURCE): arg = str(SOURCE)
        elif position and command[position - 1].casefold() == '/sourcedependencies':
            arg = str(W / 'compile/slots-region/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/slots-region/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/slots-region/unit.pdb')
        rewritten.append(arg)
    assert sum(t.key(arg) == t.key(SOURCE) for arg in rewritten) == 1
    retained_keys = {t.key(row['path']) for row in base['retained']}
    consumer = [arg for arg in base['link'] if arg.casefold().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(consumer) == 1
    link = []
    for arg in base['link']:
        if t.key(arg) == t.key(replaced['path']): arg = str(W / 'compile/slots-region/unit.obj')
        elif t.key(arg) == t.key(consumer[0]): arg = tiny['object']['path']
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    retained = [row for i, row in enumerate(base['retained']) if i != index]
    assert len(retained) == 226
    assert sum(sum(t.key(arg) == t.key(row['path']) for row in retained + [tiny['object']]) for arg in link) == 227
    assert sum(t.key(arg) == t.key(W / 'compile/slots-region/unit.obj') for arg in link) == 1
    assert all(sum(t.key(arg) == t.key(row['path']) for arg in link) == 1 for row in retained + [tiny['object']])
    paths = {t.key(SOURCE): SOURCE}
    for path in t.dep_paths(deps):
        canonical = t.canonical(path)
        if t.project(canonical): paths[t.key(canonical)] = canonical
    for row in tiny['project_dependencies']:
        t.exact(row); paths[t.key(row['path'])] = Path(row['path'])
    t.save(W / 'source-freeze.json', [t.pin(path) for path in paths.values()])
    before = W.parent / 'sdk-before/slots_region.cc'
    (W / 'changes.patch').write_text(''.join(difflib.unified_diff(
        before.read_text(encoding='utf-8-sig').splitlines(True), SOURCE.read_text(encoding='utf-8-sig').splitlines(True),
        fromfile='sdk-before/slots_region.cc', tofile='src/graph/slots_region.cc')), encoding='utf-8', newline='\n')
    env = t.read(PARENT / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local only; never print/archive values.
    fixture = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    t.save(W / 'plan.json', dict(status='PREPARED_PRODUCTION_FIX_NOT_RUN', base=t.pin(BASE),
        source=t.pin(SOURCE), before=t.pin(before), recipe=recipe,
        original_sdk=dict(index=index, object=replaced, actual_source=actual, dependencies=t.pin(deps), receipt=t.pin(receipt)),
        production_executable=graph_matches[0][1], compile=rewritten, link=link, retained=retained,
        tiny=t.pin(tiny_path), tiny_object=tiny['object'], runtime=base['runtime'],
        fixture=t.pin(fixture / 'weights.tsv'), prompt=t.pin(fixture / 'prompt.ids'),
        source_freeze=t.pin(W / 'source-freeze.json'), helpers=[t.pin(__file__), t.pin(W / 'driver.py'),
            t.pin(W.parent / 'audit_reports.py'), t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        counts=dict(CXX=1, Tiny_CXX=0, links=1, inputs=228, retained_SDK=226, replaced_SDK=1,
                    native_processes=1, NVCC=0, downloads=0)))
    print('PREPARED production slots SDK replacement at retained index', index, '; no native tools started')


if __name__ == '__main__': main()
