"""Offline-only capture-miss source/recipe preparation. Never invokes native tools."""
from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
PARENT = W.parent / 'refinement2'
BASE = R / '.scratch/inference-mtp-device-packet-20261029/model-link-base.json'
GENERATOR = R / '.scratch/inference-capture-miss-20261027/prepare.py'
RECIPE = R / '.scratch/inference-model-submission-source-20261027/logs/executable/command.json'
PRODUCT = R / 'src/graph/executable.cc'


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'k1_diag_recorder')
t.W = W


def main():
    base = t.read(BASE); tiny = t.read(PARENT / 'compile/tiny/compiled.json')
    assert len(base['retained']) == 227
    assert tiny['process']['exit'] == 0 and tiny['process']['state'] == 'TERMINAL'
    t.exact(tiny['object'])
    matches = []
    for index, row in enumerate(base['retained']):
        deps = Path(row['path']).parent / 'dependencies.json'
        if deps.is_file():
            actual = t.read(deps).get('Data', {}).get('Source', '')
            if actual and t.key(t.canonical(actual)) == t.key(PRODUCT):
                matches.append((index, row, deps, actual))
    assert len(matches) == 1, matches
    index, replaced, deps, actual = matches[0]
    assert index == 47 and replaced['sha256'] == '8199cdcf68801effed711293aaf32e2e212cb6c5668f552bb8af837c01c102dc'
    for row in base['retained']: t.exact(row)
    # Reuse only the old generator's pure source transformation, ending before
    # its old recipe/output metadata. No old helper is imported or executed.
    generator = GENERATOR.read_text(encoding='utf-8-sig')
    begin = generator.index("source = R/'src/graph/executable.cc'")
    end = generator.index("prior = R/'.scratch/inference-model-submission-source-20261027'")
    namespace = {'R': R, 'W': W}
    exec(generator[begin:end], namespace)
    diagnostic = W / 'source/executable.cc'
    assert diagnostic.is_file() and len(namespace['reasons']) == 9
    original = PRODUCT.read_text(encoding='utf-8-sig')
    instrumented = diagnostic.read_text(encoding='utf-8-sig')
    (W / 'diagnostic.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),
        instrumented.splitlines(True), fromfile='src/graph/executable.cc', tofile='diagnostic/source/executable.cc')),
        encoding='utf-8', newline='\n')
    command = t.command(RECIPE); rewritten = []
    for position, arg in enumerate(command):
        if t.key(arg) == t.key(PRODUCT): arg = str(diagnostic)
        elif position and command[position - 1].casefold() == '/sourcedependencies':
            arg = str(W / 'compile/executable/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/executable/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/executable/unit.pdb')
        rewritten.append(arg)
    rewritten.insert(1, '/I' + str(R / 'src/graph'))
    assert sum(t.key(arg) == t.key(diagnostic) for arg in rewritten) == 1
    assert not any(t.key(arg) == t.key(PRODUCT) for arg in rewritten)
    retained_keys = {t.key(row['path']) for row in base['retained']}
    consumer = [arg for arg in base['link'] if arg.casefold().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(consumer) == 1
    link = []
    for arg in base['link']:
        if t.key(arg) == t.key(replaced['path']): arg = str(W / 'compile/executable/unit.obj')
        elif t.key(arg) == t.key(consumer[0]): arg = tiny['object']['path']
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    retained = [row for i, row in enumerate(base['retained']) if i != index]
    assert len(retained) == 226
    assert sum(arg.casefold().endswith('.obj') for arg in link) == 228
    assert all(sum(t.key(arg) == t.key(row['path']) for arg in link) == 1 for row in retained + [tiny['object']])
    paths = {t.key(PRODUCT): PRODUCT, t.key(diagnostic): diagnostic}
    for path in t.dep_paths(deps):
        canonical = t.canonical(path)
        if t.project(canonical): paths[t.key(canonical)] = canonical
    for row in tiny['project_dependencies']:
        t.exact(row); paths[t.key(row['path'])] = Path(row['path'])
    frozen = [t.pin(path) for path in paths.values()]
    t.save(W / 'source-freeze.json', frozen)
    env = t.read(PARENT / 'environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local only: no printed/archived values.
    t.save(W / 'plan.json', dict(status='PREPARED_DIAGNOSTIC_ONLY_NOT_RUN', base=t.pin(BASE),
        generator=t.pin(GENERATOR), recipe=t.pin(RECIPE), product=t.pin(PRODUCT), source=t.pin(diagnostic),
        original_executable=dict(index=index, object=replaced, actual_source=actual, dependencies=t.pin(deps),
                                 receipt=t.pin(Path(replaced['path']).parent / 'compiled.json')),
        compile=rewritten, link=link, retained=retained, tiny=t.pin(PARENT / 'compile/tiny/compiled.json'),
        tiny_object=tiny['object'], runtime=base['runtime'], fixture=t.pin(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input/weights.tsv'),
        prompt=t.pin(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input/prompt.ids'),
        source_freeze=t.pin(W / 'source-freeze.json'), helpers=[t.pin(__file__), t.pin(W / 'driver.py'),
            t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        reasons=[dict(reason=reason, original_line=line) for reason, line in zip(namespace['reasons'], namespace['return_lines'])],
        counts=dict(CXX=1, Tiny_CXX=0, links=1, inputs=228, retained_SDK=226, replaced_SDK=1,
                    native_processes=1, NVCC=0, downloads=0)))
    print('PREPARED diagnostic executable SDK replacement at retained index', index, '; no native tools started')


if __name__ == '__main__': main()
