"""Explicit one-TU/link/one-CUDA diagnostic actions; never automatically retries."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'k1_diag_driver_recorder')
t.W = W


def validate():
    plan = t.read(W / 'plan.json')
    for field in ('base', 'generator', 'recipe', 'product', 'source', 'tiny', 'tiny_object', 'source_freeze'):
        t.exact(plan[field])
    for row in plan['helpers'] + t.read(W / 'source-freeze.json'): t.exact(row)
    return plan


def parse_compile():
    plan = validate(); process = t.read(W / 'logs/executable/process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    depfile = W / 'compile/executable/dependencies.json'
    assert t.key(t.read(depfile)['Data']['Source']) == t.key(plan['source']['path'])
    deps = [t.pin(path) for path in t.dep_paths(depfile) if t.project(path)]
    frozen = {t.key(row['path']): row for row in t.read(W / 'source-freeze.json')}
    assert all(t.key(row['path']) in frozen and
               (row['bytes'], row['sha256']) == (frozen[t.key(row['path'])]['bytes'], frozen[t.key(row['path'])]['sha256'])
               for row in deps)
    t.save(W / 'compile/executable/compiled.json', dict(source=plan['source'], product=plan['product'],
        object=t.pin(W / 'compile/executable/unit.obj'), process=process, command=t.pin(W / 'logs/executable/command.json'),
        dependencies=t.pin(depfile), project_dependencies=deps))
    print('CXX METADATA PASS', process['pid'])


def compile():
    plan = validate(); (W / 'compile/executable').mkdir(parents=True)
    t.execute(plan['compile'], W / 'logs/executable', 300)
    parse_compile()


def link():
    plan = validate(); compiled = t.read(W / 'compile/executable/compiled.json')
    t.exact(compiled['object'])
    for row in plan['retained'] + [plan['tiny_object']]: t.exact(row)
    t.exact(plan['runtime']); (W / 'bin').mkdir()
    alias = W / 'bin' / Path(plan['runtime']['path']).name
    alias.hardlink_to(plan['runtime']['path']); assert alias.samefile(plan['runtime']['path'])
    process = t.execute(plan['link'], W / 'logs/link', 240)
    inputs = list(plan['retained']); inputs.insert(plan['original_executable']['index'], compiled['object'])
    inputs.append(plan['tiny_object']); assert len(inputs) == 228
    t.save(W / 'ready-tiny.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=inputs,
        compiled=compiled, reused_tiny=plan['tiny_object'], process=process, runtime=plan['runtime'],
        source_freeze=plan['source_freeze']))
    print('LINK PASS', process['pid'])


def parse():
    out = W / 'run-cuda'; process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and not process['timed_out'], process
    stderr = (out / 'stderr.log').read_text(encoding='utf-8-sig')
    trace = [line for line in stderr.splitlines() if line.startswith('CAPTURE_MISS ')]
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    success = process['exit'] == 0 and len(reports) == 1
    if success:
        report = reports[0]
        success = (report.get('status') == 'PASS' and report.get('case') == 'mtp-relay' and
                   report.get('backend') == 'cuda' and report.get('quality_claim') is False and
                   report.get('performance_claim') is False)
    t.save(out / 'diagnostic-result.json', dict(status='DIAGNOSTIC_CONSUMER_PASS' if success else 'DIAGNOSTIC_CONSUMER_FAILURE',
        process=process, capture_miss_lines=trace, reports=reports, scope='One diagnostic process; no performance claim.'))
    print('DIAGNOSTIC', 'PASS' if success else 'FAIL', 'PID', process['pid'], 'exit', process['exit'], 'trace lines', len(trace))
    if not success: raise SystemExit(1)


def run():
    plan = validate(); ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    t.exact(plan['fixture']); t.exact(plan['prompt'])
    fixture = str(Path(plan['fixture']['path']).parent)
    # Actual command/process/stdout/stderr are recorded before parsing. A
    # native failure stays a failure; use the separate parse action offline.
    t.execute([ready['image']['path'], '--cuda', fixture, '--mtp-relay'], W / 'run-cuda', 300)
    parse()


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('validate', 'compile', 'parse_compile', 'link', 'run', 'parse'): globals()[action]()
    else: raise ValueError(action)
