from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
src=Path(__file__).with_name('build.py')
spec=importlib.util.spec_from_file_location('refined_k1_source',src)
x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)
x.W=x.b.W=x.t.W=Path(__file__).with_name('refinement')
x.W.mkdir(exist_ok=True)
action=sys.argv[1]
if action in ('prepare','freeze','compile','parse_compile','link','validate'):getattr(x,action)()
elif action in ('run','parse'):getattr(x,action)(sys.argv[2])
else:raise SystemExit(action)
