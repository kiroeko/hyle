"""Offline-only capture-miss source/recipe preparation. Never invokes native tools."""
from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
PARENT = W.parent / 'refinement2'
BASE = R / '.scratch/inference-mtp-device-packet-20261029/model-link-base.json'
GENERATOR = R / '.scratch/inference-capture-miss-20261027/prepare.py'
RECIPE = R / '.scratch/inference-model-submission-source-20261027/logs/executable/command.json'
PRODUCT = R / 'src/graph/executable.cc'


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'k1_diag_recorder')
t.W = W



def refine_instrumentation(text):
    saved_anchor = """    if (saved == state.capture_rebuilds.end() || !saved->qualification_valid ||
        !saved->preserves_private_arguments)"""
    saved_diagnostic = r"""    if (saved == state.capture_rebuilds.end()) {
      std::fprintf(stderr,"CAPTURE_MISS saved state=%p range=%u+%u found=0 rebuilds=%zu retained=%zu\n",
          static_cast<const void*>(&state),candidate.step_begin,candidate.step_count,
          state.capture_rebuilds.size(),state.captured_ranges.size());
    } else {
      std::fprintf(stderr,"CAPTURE_MISS saved state=%p range=%u+%u found=1 qualification=%u private=%u active=%u key0=%u key1=%u commands0=%u commands1=%u storage=%u\n",
          static_cast<const void*>(&state),candidate.step_begin,candidate.step_count,
          unsigned(saved->qualification_valid),unsigned(saved->preserves_private_arguments),
          unsigned(saved->active_variant),unsigned(saved->variants[0].key_valid),unsigned(saved->variants[1].key_valid),
          unsigned(saved->variants[0].commands.valid()),unsigned(saved->variants[1].commands.valid()),unsigned(saved->storage.valid()));
    }
"""
    assert text.count(saved_anchor) == 1
    text = text.replace(saved_anchor, saved_diagnostic + saved_anchor, 1)
    invalidate_anchor = """void invalidate_recording(detail::InvocationState &invocation,
                          std::uint32_t selected_step,
                          CaptureInvalidation mode) noexcept {
  HYLE_FATAL_ASSERT(selected_step < invocation.step_bindings.size());"""
    invalidate_diagnostic = r"""
  // Diagnostic-only observation BEFORE any revision/key/qualification mutation.
  // Do not filter by current qualification: its first invalidation must remain.
  if (!invocation.capture_rebuilds.empty()) {
    const auto &diagnostic_step = invocation.plan->steps[selected_step];
    const auto diagnostic_provider = diagnostic_step.provider();
    const int diagnostic_operation = diagnostic_step.region.valid() ? -2 :
        diagnostic_step.operation.valid() ? static_cast<int>(diagnostic_step.operation.kind()) : -1;
    std::fprintf(stderr,"CAPTURE_MISS invalidate state=%p selected_step=%u mode=%u provider=%.*s opkind=%d region=%u stepkind=%u rebuilds=%zu\n",
        static_cast<const void*>(&invocation),selected_step,unsigned(mode),
        int(diagnostic_provider.name.size()),diagnostic_provider.name.empty()?"":diagnostic_provider.name.data(),
        diagnostic_operation,unsigned(diagnostic_step.region.valid()),unsigned(diagnostic_step.kind),invocation.capture_rebuilds.size());
    for (const auto &diagnostic_saved : invocation.capture_rebuilds)
      if (selected_step >= diagnostic_saved.step_begin &&
          selected_step - diagnostic_saved.step_begin < diagnostic_saved.step_count)
        std::fprintf(stderr,"CAPTURE_MISS invalidate-before state=%p selected_step=%u mode=%u range=%u+%u qualification=%u private=%u active=%u key0=%u key1=%u commands0=%u commands1=%u storage=%u\n",
            static_cast<const void*>(&invocation),selected_step,unsigned(mode),diagnostic_saved.step_begin,diagnostic_saved.step_count,
            unsigned(diagnostic_saved.qualification_valid),unsigned(diagnostic_saved.preserves_private_arguments),
            unsigned(diagnostic_saved.active_variant),unsigned(diagnostic_saved.variants[0].key_valid),unsigned(diagnostic_saved.variants[1].key_valid),
            unsigned(diagnostic_saved.variants[0].commands.valid()),unsigned(diagnostic_saved.variants[1].commands.valid()),unsigned(diagnostic_saved.storage.valid()));
  }
"""
    assert text.count(invalidate_anchor) == 1
    text = text.replace(invalidate_anchor, invalidate_anchor + invalidate_diagnostic, 1)
    begin = text.index('Status qualify_capture_variants(')
    end = text.index('\nbool capture_key_matches(', begin)
    block = text[begin:end]
    qualify_diagnostic = r"""  const auto diagnostic_qualification_miss = [&](std::size_t index) noexcept {
    const auto &diagnostic_step = invocation.plan->steps[index];
    const auto diagnostic_provider = diagnostic_step.provider();
    const int diagnostic_operation = diagnostic_step.region.valid() ? -2 :
        diagnostic_step.operation.valid() ? static_cast<int>(diagnostic_step.operation.kind()) : -1;
    std::fprintf(stderr,"CAPTURE_MISS qualify-private state=%p range=%u+%u step=%zu provider=%.*s opkind=%d region=%u stepkind=%u native_inputs=%u stable_binding=%u\n",
        static_cast<const void*>(&invocation),saved.step_begin,saved.step_count,index,
        int(diagnostic_provider.name.size()),diagnostic_provider.name.empty()?"":diagnostic_provider.name.data(),
        diagnostic_operation,unsigned(diagnostic_step.region.valid()),unsigned(diagnostic_step.kind),
        unsigned(invocation.step_bindings[index].native_inputs),unsigned(invocation.step_bindings[index].stable_binding_identity));
  };
"""
    assert block.count('  bool preserves = true;\n') == 1
    block = block.replace('  bool preserves = true;\n', qualify_diagnostic + '  bool preserves = true;\n', 1)
    native_anchor = """    if (invocation.step_bindings[index].native_inputs) {
      preserves = false;
      break;
    }"""
    assert block.count(native_anchor) == 1
    block = block.replace(native_anchor, native_anchor.replace('      break;',
        '      diagnostic_qualification_miss(index);\n      break;'), 1)
    ordinary_anchor = '    if (!preserves)\n      break;'
    assert block.count(ordinary_anchor) == 1
    block = block.replace(ordinary_anchor,
        '    if (!preserves) {\n      diagnostic_qualification_miss(index);\n      break;\n    }', 1)
    return text[:begin] + block + text[end:]


def main():
    base = t.read(BASE); tiny = t.read(PARENT / 'compile/tiny/compiled.json')
    assert len(base['retained']) == 227
    assert tiny['process']['exit'] == 0 and tiny['process']['state'] == 'TERMINAL'
    t.exact(tiny['object'])
    matches = []
    for index, row in enumerate(base['retained']):
        deps = Path(row['path']).parent / 'dependencies.json'
        if deps.is_file():
            actual = t.read(deps).get('Data', {}).get('Source', '')
            if actual and t.key(t.canonical(actual)) == t.key(PRODUCT):
                matches.append((index, row, deps, actual))
    assert len(matches) == 1, matches
    index, replaced, deps, actual = matches[0]
    assert index == 47 and replaced['sha256'] == '8199cdcf68801effed711293aaf32e2e212cb6c5668f552bb8af837c01c102dc'
    for row in base['retained']: t.exact(row)
    # Reuse only the old generator's pure source transformation, ending before
    # its old recipe/output metadata. No old helper is imported or executed.
    generator = GENERATOR.read_text(encoding='utf-8-sig')
    begin = generator.index("source = R/'src/graph/executable.cc'")
    end = generator.index("prior = R/'.scratch/inference-model-submission-source-20261027'")
    namespace = {'R': R, 'W': W}
    exec(generator[begin:end], namespace)
    diagnostic = W / 'source/executable.cc'
    assert diagnostic.is_file() and len(namespace['reasons']) == 9
    original = PRODUCT.read_text(encoding='utf-8-sig')
    instrumented = diagnostic.read_text(encoding='utf-8-sig')
    instrumented = refine_instrumentation(instrumented)
    diagnostic.write_bytes(instrumented.encode('utf-8'))
    (W / 'diagnostic.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),
        instrumented.splitlines(True), fromfile='src/graph/executable.cc', tofile='diagnostic/source/executable.cc')),
        encoding='utf-8', newline='\n')
    command = t.command(RECIPE); rewritten = []
    for position, arg in enumerate(command):
        if t.key(arg) == t.key(PRODUCT): arg = str(diagnostic)
        elif position and command[position - 1].casefold() == '/sourcedependencies':
            arg = str(W / 'compile/executable/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/executable/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/executable/unit.pdb')
        rewritten.append(arg)
    rewritten.insert(1, '/I' + str(R / 'src/graph'))
    assert sum(t.key(arg) == t.key(diagnostic) for arg in rewritten) == 1
    assert not any(t.key(arg) == t.key(PRODUCT) for arg in rewritten)
    retained_keys = {t.key(row['path']) for row in base['retained']}
    consumer = [arg for arg in base['link'] if arg.casefold().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(consumer) == 1
    link = []
    for arg in base['link']:
        if t.key(arg) == t.key(replaced['path']): arg = str(W / 'compile/executable/unit.obj')
        elif t.key(arg) == t.key(consumer[0]): arg = tiny['object']['path']
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    retained = [row for i, row in enumerate(base['retained']) if i != index]
    assert len(retained) == 226
    assert sum(sum(t.key(arg) == t.key(row['path']) for row in retained + [tiny['object']]) for arg in link) == 227
    assert sum(t.key(arg) == t.key(W / 'compile/executable/unit.obj') for arg in link) == 1
    assert all(sum(t.key(arg) == t.key(row['path']) for arg in link) == 1 for row in retained + [tiny['object']])
    paths = {t.key(PRODUCT): PRODUCT, t.key(diagnostic): diagnostic}
    for path in t.dep_paths(deps):
        canonical = t.canonical(path)
        if t.project(canonical): paths[t.key(canonical)] = canonical
    for row in tiny['project_dependencies']:
        t.exact(row); paths[t.key(row['path'])] = Path(row['path'])
    frozen = [t.pin(path) for path in paths.values()]
    t.save(W / 'source-freeze.json', frozen)
    env = t.read(PARENT / 'environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local only: no printed/archived values.
    t.save(W / 'plan.json', dict(status='PREPARED_DIAGNOSTIC_ONLY_NOT_RUN', base=t.pin(BASE),
        generator=t.pin(GENERATOR), recipe=t.pin(RECIPE), product=t.pin(PRODUCT), source=t.pin(diagnostic),
        diagnostic_version=2, parent_diagnostic=t.pin(W.parent / 'diagnostic/plan.json'),
        original_executable=dict(index=index, object=replaced, actual_source=actual, dependencies=t.pin(deps),
                                 receipt=t.pin(Path(replaced['path']).parent / 'compiled.json')),
        compile=rewritten, link=link, retained=retained, tiny=t.pin(PARENT / 'compile/tiny/compiled.json'),
        tiny_object=tiny['object'], runtime=base['runtime'], fixture=t.pin(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input/weights.tsv'),
        prompt=t.pin(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input/prompt.ids'),
        source_freeze=t.pin(W / 'source-freeze.json'), helpers=[t.pin(__file__), t.pin(W / 'driver.py'),
            t.pin(R / '.scratch/inference-indexed-store-20261028/build.py'), t.pin(W.parent / 'diagnostic/plan.json')],
        reasons=[dict(reason=reason, original_line=line) for reason, line in zip(namespace['reasons'], namespace['return_lines'])],
        counts=dict(CXX=1, Tiny_CXX=0, links=1, inputs=228, retained_SDK=226, replaced_SDK=1,
                    native_processes=1, NVCC=0, downloads=0)))
    print('PREPARED diagnostic executable SDK replacement at retained index', index, '; no native tools started')


if __name__ == '__main__': main()
