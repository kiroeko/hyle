from pathlib import Path
import collections,hashlib,json,zipfile,datetime
S=Path(__file__).resolve().parent;B=S.parent;R=B.parents[1];E=R/'docs/evidence/correctness'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
plan=read(B/'original-run-plans/CT.json');prepared=read(B/'complete-v2/CT/input.json');acquired=read(R/plan['acquired_roles_path'])
assert acquired['complete'] and len(acquired['roles'])==649 and sum(x['bytes']for x in acquired['roles'])==1838357584
cases=[];raw={}
for name in ['cpu-ordinary','cpu-k1','cpu-k4-random','cuda-ordinary','cuda-k4-random']:
 p=B/'complete-v2/CT'/('retained-'+name);process=read(p/'process.json');functional=read(p/'functional-result.json')
 report=[json.loads(x)for x in(p/'stdout.log').read_text().splitlines()if x.startswith('{')][-1];raw[name]=report
 assert process['exit']==0 and not process.get('timeout',False) and functional['native_exit']==0
 assert functional['source_id']==prepared['source_id'] and report['cache_peak_requested_bytes']<=268435456
 assert functional['host_weight_bytes']+functional['device_weight_bytes']==(1792067552 if name.endswith('ordinary')else 1838357584)
 assert len(functional['generated_ids'])==(6 if name.endswith('random')else 4)
 fields=['sampling','sampling_policy_order','sampling_temperature','sampling_top_k','sampling_top_p','sampling_seed','mtp_max_drafts','sampling_draw_cursor','actual_target_rows','actual_draft_rows','verified_target_rows','committed_target_rows','consumed_drafts','draft_rounds','visible_tokens','draft_frontier','draft_lag','cache_budget_scope','cache_metadata_requested_bytes','native_execution_private_bytes_unknown','physical_vram_limit_known','rounds']
 cases.append(dict(**functional,functional_status='PASS_bounded_original_role_run',process=ident(p/'process.json'),command=ident(p/'command.json'),native_report_fields={k:report.get(k)for k in fields}))
assert all(raw[x]['generated_ids']==[71093,12305,198,464]for x in ['cpu-ordinary','cpu-k1','cuda-ordinary'])
assert raw['cpu-k4-random']['generated_ids']==[71093,12305,198,464,19298,198]
assert raw['cuda-k4-random']['generated_ids']==[71093,12305,198,464,54572,198]
result=dict(schema='hyle.qwen35.original-ct-mtp-functional.v1',updated=datetime.datetime.now().isoformat(timespec='seconds'),status='five specified finite CPU/CUDA cases completed with native exit0; stochastic backend divergence retained',source=dict(repository=prepared['source_repository'],revision=prepared['source_revision'],hf='https://huggingface.co/'+prepared['source_repository']+'/tree/'+prepared['source_revision'],original_safetensors=plan['source'],whole_file_lfs_computed=False,selected_physical_roles=649,logical_text_roles=320,logical_mtp_roles=15,all_selected_original_bytes=1838357584,text_selected_original_bytes=1792067552,mtp_selected_original_bytes=46290032,physical_dtypes=dict(collections.Counter(x['dtype']for x in acquired['roles'])),physical_contract='Original CT signed symmetric INT4 I32 packed words, BF16 group scales and I64 original [N,K] shapes; repository AWQ label is not the codec.',roles_receipt=ident(R/plan['acquired_roles_path']),prepared_input=ident(B/'complete-v2/CT/input.json'),manifest=ident(B/'complete-v2/CT/weights.tsv'),source_id=prepared['source_id'],qualification='All649 selected text/MTP original roles have acquired role SHA records. Vision is excluded; original full-file LFS is an authenticated source identity, not a digest computed over this partial acquisition.'),configuration=dict(P=154,C=256,maximum_outputs={'ordinary':4,'k1':4,'k4-random':6},cache_requested_byte_limit=268435456,prefix_cache='off',replay='commands',prompt=plan['prompt'],runner=plan['runner'],runtime=plan['runtime']),cases=cases,backend_divergence=dict(cpu_ids=raw['cpu-k4-random']['generated_ids'],cuda_ids=raw['cuda-k4-random']['generated_ids'],first_different_output_one_based=5,cpu_first_k4_consumed_drafts=2,cuda_first_k4_consumed_drafts=3,cpu_draw_cursor=13,cuda_draw_cursor=11,observed='The first four output IDs agree. CPU commits current+2 accepted draft rows in the first K4 block and subsequently runs K1 with pending464; CUDA commits current+3 and consumes its sampled bonus54572 before a tail T1. The changed draw frontier follows the different accepted prefix.',cause='Not yet determined. These logs do not distinguish legal backend arithmetic/sampling sensitivity from a CT connection error.',correctness_claim='No cross-backend identical-continuation or task-quality pass.'),prior_finite_math_proofs=['docs/evidence/correctness/mtp-qwen35-ct-original-projection-2026-10-24.json','docs/evidence/correctness/mtp-qwen35-ct-declared-exporter-2026-10-24.json'],limits=['These are retained, pinned consumers; this evidence is not a certification of the current working-tree source.','CUDA K1 and cross-session/prefix-cache CT matrices were not added. CPU K1 and actual CUDA K4 are reported separately.','Requested cache backing and original placed weight bytes are logical accounting, not measured RAM/VRAM peaks. CPU execution-private allocation is explicitly unknown.','Existing reports include timings in raw logs; no throughput comparison or performance claim is made.','No new HTTP, SDK build, implicit fallback, model-body duplication or seed/answer adjustment was performed by these five run commands.','The stochastic CPU/CUDA row2 discrepancy needs a single-prefix p/q/proposal/uniform investigation; no publisher or task matrix is required.'])
proof_name='qwen35-original-ct-mtp-2026-10-24';archive=E/(proof_name+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in [Path(__file__).resolve(),B/'original-run-plans/CT.json',B/'run-original-ready.py',B/'run-ready-v2.py',B/'complete-v2/CT/input.json',B/'complete-v2/CT/weights.tsv',B/'complete-v2/CT/prompt.ids',R/plan['inventory']['path'],R/plan['acquired_roles_path']]:z.write(p,p.relative_to(R).as_posix())
 for name in ['cpu-ordinary','cpu-k1','cpu-k4-random','cuda-ordinary','cuda-k4-random']:
  p=B/'complete-v2/CT'/('retained-'+name)
  for q in p.iterdir():
   if q.is_file()and q.suffix in ['.json','.log']:z.write(q,q.relative_to(R).as_posix())
 for backend,runtime in plan['runtime'].items():
  for field in ['environment','source']:z.write(R/runtime[field]['path'],R.joinpath(runtime[field]['path']).relative_to(R).as_posix())
  records=read(R/runtime['source']['path']);base=R/'.scratch/qwen-pure-cpu-deployment-20261024/source'if backend=='cpu'else R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2/source'
  for row in records:
   rel=Path(row['path']);rel=rel.relative_to(R)if rel.is_absolute()else rel
   if rel.suffix!='.h'and rel.name!='main.cc':continue
   p=base/rel
   if not p.exists():continue
   assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
   z.write(p,'frozen-'+backend+'/'+rel.as_posix())
result['archive']=ident(archive);p=E/(proof_name+'.json');p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(ident(p));print(ident(archive))
