from pathlib import Path
import hashlib,json,posixpath,sys
R=Path.cwd();P=R/'.scratch/architecture-refactor-2026-10-18/delivery2-gpu-state-lifetime-2026-10-21';O=P/'apple/mac'/(sys.argv[1]if len(sys.argv)>1 else'final')
overrides={}
def identify(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def local(p):
 n=posixpath.normpath(p)
 for prefix in('include/hyle/','tests/','src/','third_party/'):
  start=n.find('/'+prefix)
  while start>=0:
   q=R/n[start+1:]
   if q.is_file():return q
   start=n.find('/'+prefix,start+1)
 return None
records=json.loads((O/'results/compile-summary.json').read_text())['compiles'];drifts=[];unique={};audits=[]
for c in records:
 assert c['exit']==0 and c['source_drifts']==[]
 own=[];external=[]
 for d in c['dependencies']:
  q=local(d['path'])
  if q is None:external.append(d);continue
  rel=q.relative_to(R).as_posix();diagnostic=rel in overrides;actual=identify(overrides[rel]if diagnostic else q)
  row=dict(actual=d,expected=actual,diagnostic_override=diagnostic,equal=d['sha256']==actual['sha256']and d['bytes']==actual['bytes']);own.append(row);unique[rel]=actual
  if not row['equal']:drifts.append(row)
 audits.append(dict(source=c['source'],exit=c['exit'],dependencies=len(c['dependencies']),canonical_or_diagnostic=own,external=external))
result=dict(status='current_canonical_project_sources_and_headers'if not drifts else'drift',diagnostic_nonproduct=False,translation_units=len(records),unique_project_files=len(unique),actual_dependency_references=sum(len(c['dependencies'])for c in records),project_dependency_references=sum(len(c['canonical_or_diagnostic'])for c in audits),diagnostic_sources=list(overrides),accidental_drift=len(drifts),drifts=drifts,compiles=audits)
(P/'apple/actual-dependencies-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in('compiles','drifts')},indent=2));assert not drifts
