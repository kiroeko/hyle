"""Publish the bounded current native StateClone lifetime evidence, without binaries."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

L = Path(__file__).resolve().parent
R = L.parents[2]
PUBLIC = R / 'docs/evidence/correctness'
NAME = 'state-native-lifetimes-2026-10-21'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def raw_json(data):
    return (json.dumps(data, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    freeze = read(L / 'consumer-source-freeze.json')
    for row in freeze['files']:
        assert identity(R / row['path'])['sha256'] == row['sha256']
    windows = read(L / 'windows/build-report.json')
    apple = read(L / 'apple/final-validation.json')
    assert windows['root_executed_GPU_processes'] == 2 and windows['Windows_PASS_lines'] == 9
    assert apple['exit'] == 0 and apple['journeys'] == 6 and apple['source_drift'] == 0
    assert read(L / 'independent-consumer-source-review.json')['result'] == 'no_blocking_findings'
    assert read(L / 'apple/actual-dependencies-audit.json')['accidental_drift'] == 0
    members = {}

    def add(path, name=None):
        assert path.is_file(), path
        if name is None:
            name = 'evidence/' + path.relative_to(L).as_posix()
        assert name not in members
        assert path.suffix.lower() not in ['.exe', '.obj', '.o', '.lib', '.a', '.dll', '.dylib', '.zip', '.map']
        members[name] = path.read_bytes()

    current = [row['path'] for row in freeze['files']] + [
        'include/hyle/compute/state_clone.h', 'include/hyle/compute/state_versions.h',
        'include/hyle/compute/detail/state_clone_access.h',
        'src/compute_state/state_versions.cc', 'src/compute_state/state_internal.h',
        'src/compute/batch_transfer.cc', 'src/compute_backend_cuda/cuda_batch_transfer.cc',
        'src/compute_route_vulkan/vulkan_copy_program.cc', 'src/compute_route_apple/apple_copy_program.cc',
        'src/compute_backend_cuda/CMakeLists.txt', 'src/compute_route_apple/CMakeLists.txt',
        'src/compute_route_vulkan/CMakeLists.txt']
    current_rows = []
    for name in current:
        add(R / name, 'source/current/' + name)
        current_rows.append(dict(relative=name, **{k:v for k,v in identity(R/name).items() if k != 'path'}))
    for row in freeze['files']:
        add(L / 'source-before' / row['path'], 'source/before/' + row['path'])
    for name in ['consumer.diff', 'consumer-source-freeze.json', 'plan.json',
                 'independent-consumer-source-review.json', 'package.py']:
        add(L / name)
    for folder in ['windows', 'cuda/checks/link1', 'cuda/validation/attempt1',
                   'vulkan/checks/link1', 'vulkan/validation/attempt1']:
        for path in sorted((L / folder).rglob('*')):
            if path.is_file() and path.suffix.lower() in ['.json', '.log', '.py'] and path.name != 'live.json':
                add(path)
    for name in ['final-validation.json', 'source-freeze.json', 'actual-dependencies-audit.json',
                 'cleanup-inventory.json', 'prepare_mac.py', 'build_mac.py', 'collect_mac.py', 'audit_dependencies.py']:
        add(L / 'apple' / name)
    for name in ['plan.json', 'hardware.json', 'source-manifest.json', 'reused-source-manifest.json']:
        add(L / 'apple/mac/final' / name)
    for path in sorted((L / 'apple/mac/final/results').iterdir()):
        if path.is_file() and path.suffix.lower() in ['.json', '.log']:
            add(path)
    references = []
    old_names = ['state-writer-slice-2026-10-20.json', 'state-clone-observer-close-2026-10-20.json',
                 'state-clone-slot-ownership-2026-10-20.json',
                 'ga-bf16-indexer-state-reference-2026-10-21.json',
                 'ga-ratio4-producer-reference-2026-10-21.json', 'ga-mhc-reference-2026-10-21.json']
    for name in old_names:
        references.append(dict(relative='docs/evidence/correctness/' + name,
            **{k:v for k,v in identity(PUBLIC/name).items() if k != 'path'}))
    cpu = read(PUBLIC / 'state-clone-slot-ownership-2026-10-20.json')['actual_tests']['arms']['after']
    assert cpu['passed'] and cpu['cases'] == 37 and cpu['skipped'] == 0
    state_source = next(row for row in current_rows if row['relative'] == 'src/compute_state/state_versions.cc')
    assert state_source['sha256'] == '1d344d6c0c37cd1e18b7ee765a56bb58e1ab9aa24095208f453a4c3065b5fe99'
    report = dict(schema='hyle.state-native-lifetimes.v1', date='2026-10-21',
        scope='Finite native StateWriter/Clone ownership, publication, pending failure/cancellation, observers and original retirement.',
        decision='This delivery-2 column is complete within the listed public-resource and native-copy scope.',
        changes=dict(product_mathematics=0, common_state_product=0,
            test_consumer='Strengthen the existing original 256-byte native-copy consumer.',
            CMake='Register one standalone consumer using already enabled backend routes; no new options.'),
        actual_validation=dict(standalone_GPU_processes=3, exit_codes=[0,0,0],
            stdout_PASS_journeys=dict(cuda=5,vulkan=4,apple=6,total=15), skipped=0,
            new_clone_reuse_journeys=6, existing_pending_retirement_journeys=9,
            count_kind='Standalone program journeys, not GoogleTest cases.',
            Windows_execution_owner='root', Apple_execution_owner='Apple agent',
            windows_report='evidence/windows/build-report.json',
            apple_report='evidence/apple/final-validation.json'),
        build=dict(CXX=3, links=3, product_CXX=0, NVCC=0, SDK_rebuilds=0,
            current_consumer_and_state_headers_recompiled=True, selected_dependency_drift=0),
        witnesses=['Cancelled and failed-observation old Ticket/Draft survive original retirement and cold rearm; old controls cannot touch the new same-slot copy.',
            'A successful writer publishes a new version; original and new readers retain distinct bytes after draft/version/route/store/schema teardown.',
            'CUDA/Apple concurrent close/collection/rearm checks begin only after the explicit observer has entered the typed native wait-forwarding boundary.',
            'Original CUDA pending serial/concurrent close, Apple MLX prefix failure and Vulkan unknown-retirement cancel/abandon remain real backend journeys.'],
        reused_proof=dict(common_CPU_tests=37, rerun_here=False,
            current_StateCore_source_matches_latest_CPU_proof=state_source,
            same_day_StateVersion_scope='Existing GA indexer/ratio4/mHC journeys separately cover imported GraphOutput/read leases, old generations and teardown; they are not counted as clone tests here.',
            references=references),
        boundaries=['Borrowed Context/MemoryResource still outlive escaped device readers; no post-device-owner access is promised.',
            'Failed-observation injection follows a successful original native wait; it does not manufacture a failing GPU kernel.',
            'Vulkan unknown-fence handling uses the existing test-only dispatch observation boundary.',
            'Existing post-wait metadata cleanup polling is not the observer-admission synchronization.',
            'No full Goal/MTP/model, numerical/performance, Linux native-copy execution or complete SDK binary distribution is claimed.'],
        sources=current_rows, current_source_count=len(current_rows),
        archive=NAME+'.zip', archived_binaries=False)
    members['report.json'] = raw_json(report)
    inventory = [dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(members.items())]
    members['manifest.json'] = raw_json(dict(members=inventory, integrity='Every listed member has a SHA-256; manifest excludes itself.'))
    plan = dict(report=report, members=len(members), uncompressed_bytes=sum(map(len,members.values())),
        current_source_count=len(current_rows), executes=0, deletes=0)
    (L / 'publication-plan.json').write_bytes(raw_json(plan))
    if not args.publish:
        print(json.dumps({key:value for key,value in plan.items() if key != 'report'},indent=2))
        return
    public_json, public_zip = PUBLIC/(NAME+'.json'), PUBLIC/(NAME+'.zip')
    assert not public_json.exists() and not public_zip.exists(), 'Preserve prior public files'
    public_json.write_bytes(members['report.json'])
    with zipfile.ZipFile(public_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(2026,10,21,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16
            archive.writestr(info,data)
    with zipfile.ZipFile(public_zip) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(members)
        for name,data in members.items():
            assert archive.read(name) == data
        assert archive.read('report.json') == public_json.read_bytes()
    verified=dict(report=identity(public_json), archive=identity(public_zip), members=len(members),
        CRC='all_members_pass', per_member_SHA256='all_match_manifest', current_source_count=len(current_rows),
        executed_during_packaging=0, deletes=0)
    (L/'publication-verification.json').write_bytes(raw_json(verified))
    print(json.dumps(verified,indent=2))


if __name__ == '__main__':
    main()
