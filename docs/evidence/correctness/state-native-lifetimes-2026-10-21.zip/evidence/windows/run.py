"""Root-owned sequential execution of one original standalone GPU consumer."""
from pathlib import Path
import importlib.util
import os
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
L = S.parent
spec = importlib.util.spec_from_file_location('native_copy_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
arm = sys.argv[1]
assert arm in ('cuda', 'vulkan')
assert b.identity(h.SOURCE)['sha256'] == h.EXPECTED_SOURCE
plan_path = L / arm / 'checks/link1/link-plan.json'
plan = c.read(plan_path)
assert all(h.same(row) for row in plan['inputs'])
image = Path(next(x[5:] for x in plan['command'] if x.upper().startswith('/OUT:')))
assert b.identity(image) == c.read(image.parent / 'image.json')
out = L / arm / 'validation' / (sys.argv[2] if len(sys.argv) > 2 else 'attempt1')
out.mkdir(parents=True, exist_ok=True)
(out / 'tmp').mkdir(exist_ok=True)
assert not (out / 'tests.result.json').exists(), 'Preserve actual attempts'
env, runtime = b.environment(plan['command'], [x['path'] for x in plan['inputs']], out)
names = sorted({x.decode('ascii') for x in re.findall(
    rb'hyle_ggml_cpu_avx2_[A-Za-z0-9_]+\.dll(?=\x00)', image.read_bytes())})
modules = []
for name in names:
    source = next((Path(folder) / name for folder in runtime if (Path(folder) / name).is_file()), None)
    assert source is not None, name
    destination = image.parent / name
    if not destination.exists():
        os.link(source, destination)
    assert os.path.samefile(source, destination)
    modules.append(dict(source=b.identity(source), destination=b.identity(destination), hardlink=True))
c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime, private_modules=modules))
c.save(out / 'image-before.json', b.identity(image))
c.execute('tests', [str(image)], env, out)
c.save(out / 'receipt.json', dict(passed=True, standalone_main=True, backend=arm,
    image=b.identity(image), source=b.identity(h.SOURCE), link_plan=b.identity(plan_path),
    result=b.identity(out / 'tests.result.json'), stdout=b.identity(out / 'tests.stdout.log'),
    scope='Original fixed256B native StateClone and pending/cancel/failure/close retirement consumers.'))
print(str(out / 'receipt.json'), flush=True)
