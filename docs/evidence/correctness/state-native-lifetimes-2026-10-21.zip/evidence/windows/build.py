"""Freshly compile the original native-copy consumer; link only, never run."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
L = S.parent
A = L.parent
R = A.parents[1]
Z = A / 'quark-block128-scale-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_scale_host', Z / 'windows/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
SOURCE = R / 'tests/compute_state/native_fault_consumer.cc'
EXPECTED_SOURCE = 'bfa11767652942aec202910530bb26bcd8df83e3e2896c0ba5bc917d055a7be2'


def same(row):
    return b.identity(row['path']) == row


def prepare(arm, attempt):
    base_path = Z / arm / 'checks/link1/link-plan.json'
    base = c.read(base_path)
    wrapper = next(x for x in base['replacements'] if x['source']['path'].endswith('fp8_scale_policy_test.cc'))
    recipe_path = Path(wrapper['object']['path']).parent / 'identity.json'
    template = c.read(recipe_path)['command']
    out = S / 'checks' / attempt / arm
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    tag = arm + '-native-consumer'
    command = b.host_command(template, SOURCE, tag, out)
    # The cached wrappers already carry the original backend macro/header domain.
    assert '/DHYLE_COMPUTE_' + arm.upper() + '=1' in command
    source = b.identity(SOURCE)
    assert source['sha256'] == EXPECTED_SOURCE
    c.save(out / 'compile-plan.json', dict(command=command, source=source,
        recipe=b.identity(recipe_path), original_wrapper=wrapper, GPU_runs=0, SDK_builds=0))
    return arm, out, tag, command, base_path, base, wrapper, source


def compile_one(row):
    arm, out, tag, command, base_path, base, wrapper, source = row
    assert not (out / 'compile.result.json').exists()
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    dep_path = out / (tag + '-deps.json')
    deps = c.read(dep_path)['Data']
    dependencies = [b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    assert same(source) and all(same(x) for x in dependencies)
    record = dict(source=source, object=b.identity(out / (tag + '.obj')), command=command,
        recipe=c.read(out / 'compile-plan.json')['recipe'], dependencies=dependencies,
        source_dependencies=b.identity(dep_path), GPU_runs=0, SDK_builds=0)
    c.save(out / 'identity.json', record)
    print('COMPILED', arm, flush=True)
    return row, record


def link_one(row, record, folder):
    arm, _, _, _, base_path, base, wrapper, _ = row
    # The source has its own main. Drop only the exact old test object plus the
    # two GoogleTest archives; native-main.obj is a product owner, not main().
    removed = [x for x in base['inputs'] if
        c.key(x['path']) == c.key(wrapper['object']['path']) or
        Path(x['path']).name.lower() in ['gtest.lib', 'gtest_main.lib']]
    assert len(removed) == 3
    removed_keys = {c.key(x['path']) for x in removed}
    kept = [x for x in base['inputs'] if c.key(x['path']) not in removed_keys]
    assert all(same(x) for x in kept)
    inputs = [record['object'], *kept]
    out = L / arm / 'checks' / folder
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    command = [x for x in base['command'] if c.key(x) not in removed_keys and
        not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command.insert(1, record['object']['path'])
    image = out / (arm + '-state-native.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    args = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ['.obj', '.lib']]
    assert list(map(c.key, args)) == [c.key(x['path']) for x in inputs]
    # Verify the latest common StateVersions product retained by this baseline.
    state = next(x for x in inputs if Path(x['path']).name == 'after-state_versions.obj')
    assert state['sha256'] == 'c1139ced882083f359aaa31fe1e3600a97f162c066e6e670f2464271b1a6e2e4'
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(base_path), removed_test_inputs=removed, new_consumer=record['object'],
        retained_state_product=state, GPU_runs=0, SDK_builds=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    print('LINKED', arm, flush=True)
    return dict(arm=arm, image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        standalone_main=True, status='compiled_and_linked_not_executed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='attempt1')
    parser.add_argument('--link-dir', default='link1')
    parser.add_argument('--arm', action='append', choices=['cuda', 'vulkan'])
    args = parser.parse_args()
    rows = [prepare(arm, args.attempt) for arm in (args.arm or ['cuda', 'vulkan'])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        compiled = list(pool.map(compile_one, rows))
    ready = [link_one(row, record, args.link_dir) for row, record in compiled]
    c.save(S / 'ready-for-root-run.json', dict(arms=ready, CXX=len(rows), links=len(rows),
        NVCC=0, SDK_builds=0, agent_GPU_runs=0,
        source_freeze=b.identity(L / 'consumer-source-freeze.json')))
    print(str(S / 'ready-for-root-run.json'), flush=True)


if __name__ == '__main__':
    main()
