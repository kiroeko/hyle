"""Bind root's actual Windows executions to the two focused compile/link records."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('state_native_host', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
arms = []
for arm, expected in [('cuda', 5), ('vulkan', 4)]:
    identity = c.read(S / 'checks/attempt1' / arm / 'identity.json')
    assert all(h.same(row) for row in [identity['source'], identity['object'], *identity['dependencies']])
    link = h.L / arm / 'checks/link1'
    plan = c.read(link / 'link-plan.json')
    assert all(h.same(row) for row in plan['inputs'])
    validation = h.L / arm / 'validation/attempt1'
    receipt = c.read(validation / 'receipt.json')
    assert receipt['passed'] and h.same(receipt['image']) and h.same(receipt['source'])
    result = c.read(validation / 'tests.result.json')
    assert result['exit'] == 0 and result['terminal']
    lines = (validation / 'tests.stdout.log').read_text().splitlines()
    passed = [line for line in lines if line.endswith(' PASS')]
    assert len(passed) == expected
    relevant = [row for row in identity['dependencies'] if Path(row['path']).name in
        ['state_clone.h', 'state_versions.h', 'state_clone_access.h']]
    assert len(relevant) == 3
    arms.append(dict(backend=arm, compile_identity=b.identity(S / 'checks/attempt1' / arm / 'identity.json'),
        link_plan=b.identity(link / 'link-plan.json'), image=receipt['image'],
        validation_receipt=b.identity(validation / 'receipt.json'),
        runtime_environment=b.identity(validation / 'runtime-environment.json'),
        pass_lines=passed, standalone_exit_code=0, skipped=0,
        current_compiled_state_headers=relevant, execution_owner='root'))
files = []
for p in h.L.rglob('*'):
    if p.is_file() and p.suffix.lower() in ['.exe', '.map']:
        files.append(dict(identity=b.identity(p), disposition='rebuildable_after_evidence_archive_verification'))
modules = []
for arm in ['cuda', 'vulkan']:
    runtime = c.read(h.L / arm / 'validation/attempt1/runtime-environment.json')
    modules.extend(runtime['private_modules'])
c.save(S / 'cleanup-inventory.json', dict(delete_candidates=files, staged_private_modules=modules,
    retain='All .obj, compile/link/source/dependency/runtime/validation records and cached source DLLs',
    deletes_executed=0))
c.save(S / 'build-report.json', dict(scope='Original 256-byte StateClone native-copy lifetimes only',
    source_freeze=b.identity(h.L / 'consumer-source-freeze.json'), arms=arms,
    CXX=2, links=2, product_CXX=0, NVCC=0, SDK_builds=0, agent_GPU_runs=0,
    root_executed_GPU_processes=2, Windows_PASS_lines=9,
    successful_clone_publication=True, retained_old_cancelled_failed_controls_same_slot=True,
    real_forwarded_wait_admission=True, original_native_retirement_preserved=True,
    common_state_product_unchanged=True, current_selected_TU_dependency_drift=0,
    cmake_usage_audit=b.identity(S / 'cmake-usage-audit.json'),
    boundary=['Failed-observation injection follows a successful original native wait; it is not a failing GPU kernel.',
              'Vulkan unknown-fence error is the existing test dispatch observation boundary.',
              'Escaped readers retain backing after route/store/schema teardown while the borrowed backend Context/MemoryResource remains alive.',
              'No model mathematics, throughput, full-model, Linux or Apple execution is claimed by this Windows report.'],
    cleanup_inventory=b.identity(S / 'cleanup-inventory.json')))
print(b.identity(S / 'build-report.json'))
