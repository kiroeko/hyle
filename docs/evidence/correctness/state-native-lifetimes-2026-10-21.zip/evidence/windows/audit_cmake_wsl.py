from pathlib import Path
import hashlib
import json

R = Path('/mnt/c/public/project-hyle/hyle')
L = R / '.scratch/architecture-refactor-2026-10-18/delivery2-gpu-state-lifetime-2026-10-21'
name = 'src/compute_backend_cuda/CMakeLists.txt'
source = R / name
text = source.read_text()
assert 'target_link_libraries(hyle_compute_backend_cuda\n    PUBLIC CUDA::cudart\n    PRIVATE CUDA::cuda_driver)' in text
rows = []
for p in Path('/root/hyle-scratch/active-cpu-z/build/CMakeFiles/Export').rglob('HyleTargets-factor_compute_backend_cuda.cmake'):
    content = p.read_text()
    marker = 'add_library(hyle::_factor_compute_backend_cuda'
    if marker in content:
        start = content.index(marker)
        end = content.find('\n# Load information for each installed configuration.', start + len(marker))
        section = content[start:end if end >= 0 else None]
        assert 'CUDA::cudart' in section
        rows.append(dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest(), section=section))
assert rows
(L / 'windows/cmake-usage-audit.json').write_text(json.dumps(dict(
    source=dict(path=str(source), sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
    actual_generated_export=rows,
    conclusion='compute_backend_cuda publishes CUDA::cudart as PUBLIC usage, including Toolkit headers and runtime link. No additional direct test CUDA link is required.',
    consumer_target='hyle_compute_state_native_fault_consumer',
    consumer_links_backend_directly=True, SDK_configures=0, GPU_runs=0), indent=2))
print('Verified actual generated PUBLIC CUDA::cudart usage:', len(rows))
