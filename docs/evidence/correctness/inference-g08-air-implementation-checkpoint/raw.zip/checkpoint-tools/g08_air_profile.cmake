if(PROJECT_NAME STREQUAL "hyle")
  function(g08_air_holdouts)
    if(HYLE_COMPUTE_APPLE_ENABLED)
      add_executable(g08_apple_topk_holdout
        "${PROJECT_SOURCE_DIR}/tests/compute_route_apple/reduction_test.cc"
        "${PROJECT_SOURCE_DIR}/tests/graph_route_apple/reduction_test.cc")
      target_compile_features(g08_apple_topk_holdout PRIVATE cxx_std_23)
      target_link_libraries(g08_apple_topk_holdout PRIVATE
        hyle_compute_route_apple hyle_graph_route_apple GTest::gtest_main)
      hyle_stage_runtime(g08_apple_topk_holdout)
    endif()
    if(HYLE_COMPUTE_VULKAN_ENABLED)
      add_executable(g08_vulkan_topk_holdout
        "${PROJECT_SOURCE_DIR}/tests/compute_route_vulkan/topk_test.cc"
        "${PROJECT_SOURCE_DIR}/tests/graph_route_vulkan/topk_test.cc")
      target_compile_features(g08_vulkan_topk_holdout PRIVATE cxx_std_23)
      target_include_directories(g08_vulkan_topk_holdout PRIVATE
        "${PROJECT_SOURCE_DIR}/src/compute_route_vulkan" "${PROJECT_SOURCE_DIR}/src/compute")
      get_target_property(g08_ggml_src ggml SOURCE_DIR)
      target_include_directories(g08_vulkan_topk_holdout SYSTEM PRIVATE "${g08_ggml_src}")
      target_link_libraries(g08_vulkan_topk_holdout PRIVATE hyle_graph_route_vulkan
        hyle_compute_provider_ggml_vulkan hyle_compute_ggml_runtime GTest::gtest_main ggml)
      hyle_stage_runtime(g08_vulkan_topk_holdout)
    endif()
  endfunction()
  if(HYLE_BUILD_TESTS)
    cmake_language(DEFER CALL g08_air_holdouts)
  endif()
endif()
