from pathlib import Path
import json,os,re,subprocess
base=Path('/Users/kiro/hyle-scratch/compute-unified')
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
r=dict(identity={name:subprocess.check_output(cmd,env=env,text=True).strip() for name,cmd in [
    ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
    ('compiler',['xcrun','clang','--version']),('metal',['xcrun','-sdk','macosx','metal','--version'])]},trees=[])
names={'ninja','cmake','clang','clang++','cc1','metal','metallib'}
r['live_build_processes']=[line for line in subprocess.check_output(['ps','-axo','pid,comm'],text=True).splitlines()
    if line.split() and Path(line.split()[-1]).name in names]
keys=['CMAKE_HOME_DIRECTORY','CMAKE_CXX_COMPILER','CMAKE_BUILD_TYPE','HYLE_STATIC','HYLE_BUILD_TESTS','HYLE_INSTALL',
      'HYLE_SANITIZER','HYLE_PRODUCTS','HYLE_MODULES','HYLE_DEV_FACTORS','HYLE_COMPUTE_APPLE','HYLE_COMPUTE_VULKAN',
      'HYLE_TEST_INSTRUMENTATION','HYLE_APPLE_MLX_SOURCE_DIR','HYLE_MLX_SOURCE_DIR']
for p in sorted(base.glob('*/selected-graph/*/CMakeCache.txt')):
    facts={}
    for line in p.read_text().splitlines():
        if not line.startswith(('#','//')) and '=' in line and ':' in line.split('=')[0]:
            name,value=line.split('=',1);key=name.split(':')[0]
            if key in keys:facts[key]=value
    r['trees'].append(dict(path=str(p.parent),cache=facts))
(base/'g08-air-inventory.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
