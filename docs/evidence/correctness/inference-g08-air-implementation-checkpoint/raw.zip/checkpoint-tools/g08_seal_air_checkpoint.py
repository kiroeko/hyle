from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[2]
scratch=root/'.scratch/inference-gaps'
out=root/'evidence/correctness/inference-g08-air-implementation-checkpoint'
out.mkdir(exist_ok=False)
names=[f'g08-apple-source-a{i}' for i in range(1,5)]+[f'g08-vulkan-source-v{i}' for i in range(1,6)]
records=[json.loads((scratch/name/'result.json').read_text()) for name in names]
with zipfile.ZipFile(out/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in names:
        for p in sorted((scratch/name).iterdir()):
            if p.is_file():z.write(p,f'{name}/{p.name}')
    for name in ['g08_air_source.py','g08_air_profile.cmake','g08_air_inventory.py','g08-air-inventory.json',
                 'g08_vulkan_discovery.py','g08-vulkan-discovery.json','g08_seal_air_checkpoint.py']:
        p=scratch/name
        if p.is_file():z.write(p,'checkpoint-tools/'+name)
receipt=dict(schema='hyle.g08-air-implementation-checkpoint/v1',state='IN_PROGRESS_NOT_ACCEPTED',
    checkpoint_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    closure_card='docs/implementation/tasks/compute/inference-g08-output-selection.md',
    prior_cpu_cuda_checkpoint='evidence/correctness/inference-g08-implementation-checkpoint/receipt.json',
    source_batches=records,
    accepted_ordinary_facts=[
        'Air Mem244/schema3 and CPU Direct in a2; CPU Graph including independent categorical ports in a3 PASS.',
        'Actual Metal1048772 open64 endpoint/corpus pairs and CPU+Apple65-step24-byte joint in a2 PASS.',
        'Apple Direct/Graph complete numerical/distribution/full-vocabulary65-step and independent ports, four original TopK holdouts in a4 PASS.',
        'Actual Vulkan1048772 open64 endpoint/corpus pairs in v3 PASS with validation explicitly disabled.',
        'Vulkan Direct/Graph complete numerical/distribution/full-vocabulary65-step, independent ports, byte origins1/3/17; CPU+Vulkan joint and original17TopK holdouts in v5 PASS with validation explicitly disabled.'
    ],
    retained_failures=[
        'a1 original dry-run preflight retained across resume; test const array.wait compile errors retained.',
        'a2 old float keys fail TopK and common Graph rebinding transient alias; wrong private holdout path leaves SETUP_FAIL after real passed stages.',
        'a3 count3/smallest negative-subnormal old argsort key failure retained despite original4TopK holdouts passing.',
        'v1 newly added origin fixture syntax compile failure retained.',
        'v2 validation-requested native failures retained; discovery confirms original layer directory absent and enumerated layers empty.',
        'v3/V4 large-offset selected logprob precision failures and v3 structural old-region test expectation retained.',
        'Additional same-binary --origins-only command failed with native fragment unaligned range before unused raw binding fix; output observed in session, elapsed time UNKNOWN.'
    ],
    costs=dict(source_batch_elapsed_seconds=sum(r['elapsed_seconds'] for r in records),
               complete_cost='UNKNOWN: transfer/packing/inspection and the extra origin-only diagnosis were not timed; no zero-cost claim or budget reset.'),
    pending=[
        'WSL CPU/CUDA newly added independent Graph publication tests; original CPU/CUDA TopK axis/stride/dtype/empty holdouts.',
        'Applicable host sanitizers, CUDA memcheck/racecheck, actual Vulkan validation layer qualification and remaining native risks.',
        'Remaining source/static/shared relocated SDK and public-header qualification including Mem changed backings.',
        'Immutable candidate freeze, S1 exact timing/CHARGED-DEFERRED preflight and qualified P1 four routes plus Apple count3 holdout.',
        'P0 final ledger, user documentation, independent review and G08 terminal verdict; G09/G10 unstarted.'
    ],
    coarse_estimates=dict(g08_percent=70,g07_g10_goal_percent=44,formally_accepted_items=1,total_items=4,
                          meaning='Implementation estimate, not passed acceptance-gate percentage.'),
    raw_archive=dict(path='raw.zip',sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest()))
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
summaries={
    'mem':'G08 M1 AUDITED: mature mi_free_aligned fixes original Buffer884/alignment256 allocation-only crash. WSL and Air source244/244 PASS; Windows/static/shared/host risks pending. Natural path/layout/quota/vendor unchanged.',
    'compute_ops':'G08 AUDITED: typed random/categorical schema, official Philox KAT3/3 and four-route main Direct/Graph numerical/distribution consumers PASS. Full risk/delivery/finite acceptance pending.',
    'compute_route_apple':'G08 AUDITED: Apple Direct/Graph full numerical/distribution/65-step, independent categorical ports, actual Metal1048772-pair endpoints, CPU+Apple joint and original4TopK holdouts PASS. SDK/risks/S1 P1 pending.',
    'compute_route_vulkan':'G08 AUDITED: Vulkan Direct/Graph full numerical/distribution/65-step/independent ports/byte origins1/3/17, device1048772-pair math, CPU+Vulkan joint and original17TopK holdouts PASS without validation. Validation layer/risks/SDK/S1 P1 pending.',
    'graph_route_vulkan':'G08 AUDITED: original plan/liveness/status/owners carry random/categorical, including ID-only/score-only/both and origin-preserving View producers; source consumers PASS without validation. Actual validation/SDK qualification pending.'
}
p=root/'docs/implementation/module-status.json';before=p.read_bytes();registry=json.loads(before)
for row in registry['modules']:
    if row['module'] in summaries:
        assert row['state']=='AUDITED' and row['record'].endswith('inference-g08-output-selection.md')
        row['summary']=summaries[row['module']]
text=json.dumps(registry,indent=2,ensure_ascii=False)+'\n'
if b'\r\n' in before:text=text.replace('\n','\r\n')
p.write_bytes(text.encode('utf-8'))
print(json.dumps(dict(out=str(out),known_source_batch_seconds=receipt['costs']['source_batch_elapsed_seconds'],raw_bytes=(out/'raw.zip').stat().st_size)))
