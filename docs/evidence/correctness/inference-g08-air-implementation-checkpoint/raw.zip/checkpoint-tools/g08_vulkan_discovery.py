from pathlib import Path
import ctypes,json,os
base=Path('/Users/kiro/hyle-scratch/compute-unified')
layer=Path('/Users/kiro/hyle-verify/r6-vulkan-20260917/tools/vulkan-validationlayers/1.4.357.0/share/vulkan/explicit_layer.d')
os.environ['VK_LAYER_PATH']=str(layer)
class Layer(ctypes.Structure):
    _fields_=[('name',ctypes.c_char*256),('spec',ctypes.c_uint32),('implementation',ctypes.c_uint32),('description',ctypes.c_char*256)]
vk=ctypes.CDLL('/opt/homebrew/lib/libvulkan.1.dylib')
count=ctypes.c_uint32();fn=vk.vkEnumerateInstanceLayerProperties
fn.argtypes=[ctypes.POINTER(ctypes.c_uint32),ctypes.POINTER(Layer)];fn.restype=ctypes.c_int
assert fn(ctypes.byref(count),None)==0
layers=(Layer*count.value)();assert fn(ctypes.byref(count),layers)==0
r=dict(layer_directory=str(layer),exists=layer.is_dir(),manifests=[dict(path=str(p),data=json.loads(p.read_text())) for p in layer.glob('*.json')],
    layers=[dict(name=x.name.decode(),spec=x.spec,implementation=x.implementation) for x in layers],
    driver_manifest=dict(path='/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json',exists=Path('/opt/homebrew/etc/vulkan/icd.d/MoltenVK_icd.json').is_file()))
(base/'g08-vulkan-discovery.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
