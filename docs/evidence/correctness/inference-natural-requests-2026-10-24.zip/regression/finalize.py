"""Small publishable finite proof, including failures; excludes weights/binaries/SDK."""
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
post=read(D/'summary.json');assert post['state']=='passed'
reports=read(D/'current4/reports.json');text=next(x for x in reports if x.get('mtp')is False and'sessions'in x);mtp=next(x for x in reports if x.get('mtp')is True and'sessions'in x)
facts={x['private_facts']:x for x in reports if'private_facts'in x}
fail2=dict(state='failed',process=read(D/'current2/run/process.json'),source=pin(D/'current2/source/engine/models/qwen35/main.cc'),
  reason='Actual second same R2/T1 ordinary decode prepare_replay: Vulkan retained output private owners changed. Generic native region did not enter original native rearm boundary before rebind. First prefill+decode actual IDs [36,42] -> [8,11].',
  original_logs_preserved=True,SDK_builds=0,HTTP=0)
save(D/'current2/failure.json',fail2)
summary=dict(state='passed',scope='Untrained A-only, Windows Vulkan, finite shared natural Text/MTP lifecycle. No trained-model quality, throughput or all-engine claim.',
  final_app_source=pin(D/'current3/source/engine/models/qwen35/main.cc'),final_image=pin(D/'current4/link/probe.exe'),
  final_native_region=pin(D/'native-region-fixed2/source/native_region.cc'),final_native_program=pin(D/'native-program-fixed/source/vulkan_program.cc'),
  exact_source_and_object_pins=pin(D/'current4/link/pins.json'),postrun_audit=pin(D/'summary.json'),old_reference=pin(D/'old-mtp-reference.json'),
  old_reference_qualification='Original old24c7d459 failed on second initial128B hidden row (257B pool vs256B allocate alignment). Oldcontrol changes only three pool capacity expressions and adds the same alignment helper; old math/lifecycle/roles/shapes/N2/R2/16MiB remain original. Original failure preserved; do not call this an unchanged old binary.',
  capacity_only_diff=pin(D/'oldcontrol/capacity-only.diff'),capacity_only_proof=pin(D/'oldcontrol/capacity-only-proof.json'),
  Text=dict(N=2,R=2,user_count=4,turns=8,outputs=20,quota=[3,2],seed=123,streams=[0,1,2,3],draws=[5,5,5,5],
    actual_R2_batches=sum(b['requests']==2 for b in text['batches']),all_actual_Graph_roles_text=True,mtp_weights=0,draft_arenas=0,draft_programs=0,
    peak_resident=text['peak_resident_requests'],peak_committed_versions=text['peak_committed_versions'],idle_evictions=text['idle_evictions'],
    rebuilds=text['restore_count'],restored_target_rows=text['restored_target_rows'],new_request_full_hits=1,new_request_partial_hits=1,reused_rows=8,
    full_hit_new_stream=2,full_hit_actual_categorical_graph_calls=1,first_wave_peer_prefix_hits=0,
    full_hit_token_note='u2 fresh random first token39 happens to equal u0 historical last token39; real categorical graph call1 and independent stream2/draw5 establish re-sampling, rather than claiming token inequality.',
    all_consumed_journal_hashes_lengths_and_RNG_checked=True,final_pending_excluded_from_consumed_journal=True,
    users=[dict(id=s['session_id'],generated=s['result']['generated_ids'],draw=s['result']['sampling_draw_cursor'],length=s['result']['visible_tokens'],records=len(s['ledger']))for s in text['sessions']]),
  greedy_and_late_IO=facts['greedy-recovery-and-late-io'],
  MTP=dict(N=2,R=2,user_count=2,outputs=8,quota=4,K=2,actual_R2=True,actual_K2=True,exact_old_ledger_equal=post['MTP_exact_ledger_equal'],
    exact_old_math_fields=post['MTP_math_fields_equal'],exact_old_batch_dispatch_equal=True,users=[dict(id=s['session_id'],generated=s['result']['generated_ids'],draw=s['result']['sampling_draw_cursor'],records=len(s['ledger']))for s in mtp['sessions']]),
  actual_processes=[dict(version=v,**read(D/v/'run/process.json'))for v in['old','oldcontrol','current2','current4']],
  known_bad_source_not_run=[pin(D/'current/not-run.json'),pin(D/'current3/not-run.json')],
  private_compile_failure='native-region-fixed/compile: missing native_region.h after moving source into isolated folder; no GPU executed. Preserved, corrected only by adding explicit original source include directory in fixed2.',
  builds=dict(app_strict_compilations=5,native_region_compilations=2,native_region_first_private_include_failure=True,native_program_compilations=1,new_route_archives=1,app_links=6,SDK_builds=0,current4_app_object_reused=True),
  final_process=read(D/'current4/run/process.json'),SDK_builds=0,HTTP=0,model_downloads=0,weights_duplicated=False,quality_claim=False,performance_claim=False)
save(D/'proof-summary.json',summary)
included=[]
with zipfile.ZipFile(D/'proof.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in D.rglob('*'):
    if p.is_file()and p.suffix.lower()in{'.cc','.h','.py','.json','.log','.diff','.patch','.md','.txt'}and p.name!='proof-pins.json':
      z.write(p,p.relative_to(D).as_posix());included.append(p.relative_to(D).as_posix())
publication=dict(state='passed',summary=pin(D/'proof-summary.json'),postrun=pin(D/'summary.json'),archive=pin(D/'proof.zip'),files=len(included),excluded=['weight payloads','obj/exe/pdb/lib/dll','SDK','model downloads'],actual_final_processes=1)
save(D/'proof-pins.json',publication);print(json.dumps(publication),flush=True)
