"""One old MTP reference and one current Text/MTP small consumer; no SDK build."""
from pathlib import Path
import difflib,importlib.util,json,os,shutil,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
PREVIOUS=R/'.scratch/mtp-round-preparation-20261024/regression/attempt2'
FIXTURE=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def require(ok,message):
    if not ok:raise ValueError(message)
def freeze(version):
    target=D/version/'source';target.mkdir(parents=True,exist_ok=False);rows=[]
    if version.startswith('old'):
        basis=PREVIOUS/'source'if version=='old'else D/'old/source';sources=[p for p in(basis/'engine').rglob('*')if p.is_file()]
    else:
        basis=R;sources=[R/'engine/models/qwen35/main.cc',*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h')]
    for p in sources:
        out=target/p.relative_to(basis);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
        rows.append(dict(original=b.pin(p),frozen=b.pin(out)))
    probe=D/'old/source/probe.cc'if version=='oldcontrol'else D/'probe.cc'
    shutil.copyfile(probe,target/'probe.cc');rows.append(dict(original=b.pin(probe),frozen=b.pin(target/'probe.cc')))
    b.save(D/version/'source-pins.json',rows)
    b.save(D/version/'fixture-pins.json',[b.pin(p)for p in FIXTURE.glob('*')if p.is_file()])
    if version=='old':require(b.pin(target/'engine/models/qwen35/main.cc')['sha256']=='24c7d4594c82428a6829205d45a06239884b179deaa1f5ab45f79c545a404d2b','Wrong old MTP generation baseline')
    if version=='oldcontrol':
        product=R/'engine/models/qwen35/session_state.h';raw=product.read_text(encoding='utf8')
        start=raw.index('// State pools use this alignment explicitly');end=raw.index('// Target and draft inventories',start);helper=raw[start:end]
        header=target/'engine/models/qwen35/session_state.h';main=target/'engine/models/qwen35/main.cc';changes=[]
        before=header.read_text(encoding='utf8');marker='// Target and draft inventories'
        require(before.count(marker)==1 and'state_pool_backing_bytes'not in before,'Unexpected baseline helper header')
        after=before.replace(marker,helper+marker);header.write_text(after,encoding='utf8',newline='\n');changes.append((header,before,after))
        before=main.read_text(encoding='utf8');after=before
        replacements=[('cache::add(cache::multiply(take(description.history.required_bytes()), history_slots), 1)','cache::state_pool_backing_bytes(take(description.history.required_bytes()), history_slots)'),
          ('cache::add(cache::multiply(take(description.recurrent.required_bytes()), recurrent_slots), 1)','cache::state_pool_backing_bytes(take(description.recurrent.required_bytes()), recurrent_slots)'),
          ('cache::add(cache::multiply(geometry.hidden_bytes(), slots), 1)','cache::state_pool_backing_bytes(geometry.hidden_bytes(), slots)')]
        for old,new in replacements:require(after.count(old)==1,'Unexpected original state pool capacity expression');after=after.replace(old,new)
        main.write_text(after,encoding='utf8',newline='\n');changes.append((main,before,after))
        delta=''.join(''.join(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='original/'+p.name,tofile='capacity-only/'+p.name))for p,a,z in changes)
        (D/version/'capacity-only.diff').write_text(delta,encoding='utf8')
        b.save(D/version/'capacity-only-proof.json',dict(basis=b.pin(D/'old/source/engine/models/qwen35/main.cc'),original_failure=b.pin(D/'first-failure.json'),shared_helper_source=b.pin(product),helper_text=helper,changed_frozen_files=[b.pin(p)for p,_,_ in changes],scope='Only shared alignment256 backing-capacity formula added and applied to history/recurrent/hidden pools; old math, trained roles, lifecycle, shapes, slot counts, N2/R2,16MiB budget and allocate default256 unchanged. Original old static Plan estimate retained (not used as fixed finite limit).',Plan_static_changed=False,product_writes=0))
        b.save(D/version/'source-pins-final.json',[b.pin(p)for p in target.rglob('*')if p.is_file()])
def build(version):
    target=D/version/'source';folder=D/version/'compile';original=b.args(PREVIOUS/'compile/command.json')
    command=[original[0],'/I'+str(target)];skip=False
    if version.startswith('old'):command.append('/DHYLE_PRIVATE_OLD_GENERATION_REFERENCE=1')
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        if lower.startswith('/i')and '/.scratch/'in lower and lower.endswith('/source'):continue
        command.append(word)
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(target/'probe.cc'),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.environment(command[0]);b.execute(command,folder,env,180)
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    leaks=[str(p)for p in deps if p.is_relative_to(R/'engine')or(p.is_relative_to(R/'.scratch')and not p.is_relative_to(target))]
    require(not leaks,'Frozen engine/private headers leaked: '+repr(leaks))
    now=[b.pin(p)for p in deps if p.is_relative_to(R)];b.save(folder/'self-header-pins.json',now)
    prior={x['path'].lower():x for x in b.read(PREVIOUS/'compile/self-header-pins.json')if Path(x['path']).is_relative_to(R/'include')}
    require(all(x['path'].lower()in prior and all(x[f]==prior[x['path'].lower()][f]for f in['bytes','sha256'])for x in now if Path(x['path']).is_relative_to(R/'include')),'Changed public ABI inputs; inspect retained closure')
    previous=b.args(PREVIOUS/'link/command.json');out=D/version/'link';old=str(PREVIOUS/'compile/unit.obj');require(previous.count(old)==1,'Wrong retained entry')
    link=[str(folder/'unit.obj')if word==old else word for word in previous if not word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    if version=='current3':
        original_native=str(R/'.scratch/qwen-vulkan-k1-20261024/build1/src--graph_route_vulkan--native_region-cc/unit.obj')
        require(link.count(original_native)==1,'Expected explicit old native region object')
        link=[str(D/'native-region-fixed2/compile/unit.obj')if x==original_native else x for x in link]
    link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')];b.execute(link,out,env,120)
    for dll in(PREVIOUS/'link').glob('*.dll'):os.link(dll,out/dll.name)
    b.save(out/'pins.json',dict(image=b.pin(out/'probe.exe'),object=b.pin(folder/'unit.obj'),retained_closure=b.pin(PREVIOUS/'link/command.json'),native=[b.pin(p)for p in out.glob('*.dll')],SDK_builds=0))
def native_leaf(unused):
    root=D/'native-region-fixed2';source=root/'source/native_region.cc';source.parent.mkdir(parents=True,exist_ok=False)
    canonical=R/'src/graph_route_vulkan/native_region.cc';source.write_bytes(canonical.read_bytes())
    require(b.pin(source)['sha256']=='a61e34433492e0faac7f9dca390414ba0c321469ca0ed4633b6b2992adc3bfe8','Unexpected approved native epoch fix source')
    old=b.read(R/'.scratch/qwen-vulkan-k1-20261024/build1/src--graph_route_vulkan--native_region-cc/identity.json')
    original=old['command'];folder=root/'compile';command=[original[0],'/I'+str(R/'src/graph_route_vulkan')];skip=False
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        command.append(word)
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.environment(command[0]);b.execute(command,folder,env,120)
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    b.save(root/'identity.json',dict(source=b.pin(source),canonical=b.pin(canonical),old_source=old['source'],old_object=old['object'],object=b.pin(folder/'unit.obj'),dependencies=[b.pin(p)for p in deps if p.is_relative_to(R)],SDK_builds=0,scope='Only generic sealed native Graph region calls existing prepare_bindings before prepare_outputs; no owner guard relaxation or mathematical change.'))
def program_fix(version):
    require(version=='current4','One bounded native Program correction only')
    root=D/'native-program-fixed';source=root/'source/vulkan_program.cc';source.parent.mkdir(parents=True,exist_ok=False)
    canonical=R/'src/compute_route_vulkan/vulkan_program.cc';source.write_bytes(canonical.read_bytes())
    require(b.pin(source)['sha256']=='decf99a01020e2a957eaf63068f0683aec8a02248fd37737f00afc796930d64d','Unexpected approved alias-preserving program source')
    old=b.read(R/'.scratch/gdn-vulkan-output-scale-20261024/compile1/route--vulkan_program/identity.json')
    command=[old['command'][0],'/I'+str(R/'src/compute_route_vulkan')];folder=root/'compile';skip=False
    for word in old['command'][1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        command.append(word)
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.environment(command[0]);b.execute(command,folder,env,120)
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    b.save(root/'identity.json',dict(source=b.pin(source),old_source=old['source'],old_object=old['object'],object=b.pin(folder/'unit.obj'),dependencies=[b.pin(p)for p in deps if p.is_relative_to(R)],SDK_builds=0))
    archive=b.read(R/'.scratch/gdn-vulkan-output-scale-20261024/link1/route-archive-plan.json')['command'];archive_dir=root/'archive'
    require(archive.count(old['object']['path'])==1,'Old Program member absent from retained archive recipe')
    archive=[str(folder/'unit.obj')if word==old['object']['path']else word for word in archive if not word.upper().startswith('/OUT:')]
    archive+=['/OUT:'+str(archive_dir/'route.lib')];b.execute(archive,archive_dir,env,120)
    prior=b.args(D/'current3/link/command.json');out=D/version/'link';oldlib=str(R/'.scratch/gdn-vulkan-output-scale-20261024/link1/route.lib')
    require(prior.count(oldlib)==1,'Retained original route archive absent')
    link=[str(archive_dir/'route.lib')if word==oldlib else word for word in prior if not word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')];b.execute(link,out,env,120)
    for dll in(D/'current3/link').glob('*.dll'):os.link(dll,out/dll.name)
    shutil.copyfile(D/'current3/fixture-pins.json',D/version/'fixture-pins.json')
    b.save(out/'pins.json',dict(image=b.pin(out/'probe.exe'),app_object=b.pin(D/'current3/compile/unit.obj'),app_source=b.pin(D/'current3/source/engine/models/qwen35/main.cc'),program_object=b.pin(folder/'unit.obj'),new_archive=b.pin(archive_dir/'route.lib'),native_region=b.pin(D/'native-region-fixed2/compile/unit.obj'),app_recompiled=False,SDK_builds=0))
def rows(version):return[json.loads(s)for s in(D/version/'run/stdout.log').read_text().splitlines()if s.startswith('{')]
def run(version):
    app_version='current3'if version=='current4'else version
    env=b.environment(b.args(D/app_version/'compile/command.json')[0]);env.update({k:v for k,v in b.read(b.VK/'runtime.json').items()if isinstance(v,str)})
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');env['PATH']=str(D/version/'link')+';'+env['PATH']
    for row in b.read(D/version/'fixture-pins.json'):
        current=b.pin(Path(row['path']));require(all(current[k]==row[k]for k in['bytes','sha256']),'Cached original A fixture changed')
    b.execute([str(D/version/'link/probe.exe'),str(FIXTURE/'weights.tsv'),str(D/version/'output')],D/version/'run',env,90)
    reports=rows(version);mtp=[r for r in reports if r.get('mtp')is True and 'sessions'in r]
    require(len(mtp)==1 and mtp[0]['session_count']==2 and mtp[0]['generated_tokens']==8,'Natural MTP 2x4 outputs missing')
    require(any(x['requests']==2 for x in mtp[0]['batches']),'Natural MTP R2 batch missing')
    require(any(x['proposals']==2 for s in mtp[0]['sessions']for x in s['result']['rounds']),'Natural MTP K2 round missing')
    b.save(D/version/'reports.json',reports)
    if version.startswith('old'):
        b.save(D/'old-mtp-reference.json',dict(state='passed',version=version,report=mtp[0],source=b.pin(D/version/'source/engine/models/qwen35/main.cc'),process=b.read(D/version/'run/process.json'),image=b.pin(D/version/'link/probe.exe'),original_old_had_capacity_failure=True,capacity_only_proof=b.pin(D/version/'capacity-only-proof.json')if version=='oldcontrol'else None,quality_claim=False,performance_claim=False,HTTP=0))
        print(json.dumps(dict(old_MTP='passed',source=b.pin(D/version/'source/engine/models/qwen35/main.cc'),reference=b.pin(D/'old-mtp-reference.json'))),flush=True)
    else:audit(version)
def audit(version='current'):
    current=rows(version);reference=b.read(D/'old-mtp-reference.json')['report']
    mtp=[r for r in current if r.get('mtp')is True and 'sessions'in r]
    text=[r for r in current if r.get('mtp')is False and 'sessions'in r]
    require(len(mtp)==len(text)==1,'Current natural Text/MTP reports missing')
    # Time, resource observations and labels are not numerical/replay oracles.
    old_sessions={s['session_id']:s for s in reference['sessions']};new_sessions={s['session_id']:s for s in mtp[0]['sessions']}
    require(old_sessions.keys()==new_sessions.keys(),'MTP session identities changed')
    keys=['generated_ids','sampling_draw_cursor','sampling_stream','visible_tokens','draft_frontier','draft_lag','rounds','prefill_target_rows','prefill_draft_rows','draft_rows','draft_rounds','agreements','consumed_drafts']
    for name in old_sessions:
        before=old_sessions[name];after=new_sessions[name]
        require(before['ledger']==after['ledger'],'Natural MTP full committed ledger changed for '+name)
        for key in keys:require(before['result'].get(key)==after['result'].get(key),'Natural MTP mathematical field changed: '+name+'.'+key)
    for key in['dispatch','batches','generated_tokens','committed_target_rows','draft_rows','verified_target_rows']:
        require(reference.get(key)==mtp[0].get(key),'Natural MTP actual dispatch/geometry changed: '+key)
    t=text[0]
    for key,value in dict(session_count=4,turn_count=8,max_sessions=2,active_sequences=2,requested_output_tokens=20,generated_tokens=20,pending_flushed_tokens=4,retired_requests=4,mtp_tensors=0).items():
        require(t.get(key)==value,'Natural Text finite count mismatch: '+key)
    require(t['prefix_cache']and t['peak_resident_requests']<=2 and t['peak_committed_versions']<=2,'Natural Text prefix/admission bound failed')
    require(any(x['requests']==2 for x in t['batches']),'Natural Text never submitted actual R2')
    require(all(x['role']==0 for x in t['batches']),'Natural Text submitted an MTP Graph role')
    require(t['idle_evictions']>0 and t['restore_count']>0 and t['restored_target_rows']>0,'Actual idle eviction and committed-input rebuild were not observed')
    sessions={s['session_id']:s for s in t['sessions']};inputs={'u0':[1,2],'u1':[1,2],'u2':[1,2,36,8],'u3':[1,2,36,8,5]}
    require(set(sessions)==set(inputs),'Natural Text user count/identities changed')
    first=sessions['u0']['result']['generated_ids']
    require(first[:2]==[36,8],'Cached full/partial prefix fixture identity did not occur; do not claim unobserved hits')
    def hash_ids(ids):
        value=1469598103934665603
        for token in ids:value=((value^(token&0xffffffff))*1099511628211)&0xffffffffffffffff
        return value
    journal_oracles={}
    for index,name in enumerate(inputs):
        s=sessions[name];result=s['result'];ids=result['generated_ids'];turns=result['turns']
        require(len(ids)==5 and result['sampling_draw_cursor']==5 and result['sampling_stream']==index,'Natural Text request mixed quota/cursor/independent stream: '+name)
        require(len(turns)==2 and turns[0]['output_begin']==0 and turns[0]['output_end']==3 and turns[1]['output_begin']==3 and turns[1]['output_end']==5,'Natural Text turn output boundary mismatch: '+name)
        require(turns[1]['pending_flushed']==1 and turns[1]['input_ids']==[ids[2],3],'Previous pending not consumed exactly once before next user prompt: '+name)
        expected=inputs[name]+ids[:2]+[ids[2],3]+[ids[3]]
        require(turns[0]['context_after']==len(inputs[name])+2 and turns[1]['context_after']==len(expected) and result['visible_tokens']==len(expected),'Natural Text complete context differs from actual consumption: '+name)
        position=0;draw=0
        for record in s['ledger']:
            count=record['input_rows'];part=expected[position:position+count]
            require(count>0 and len(part)==count and record['before_length']==position and record['after_length']==position+count,'Text committed journal has a gap, duplicated pending or unconsumed final token: '+name)
            require(record['role']==0 and record['input_hash']==hash_ids(part) and record['first_input']==part[0],'Text journal differs from actual consumed input bytes: '+name)
            if record['generation']:require(count==1 and record['committed_input_ids']==part,'Text decode journal contains speculative or unconsumed inputs: '+name)
            require(record['before_frontier']==record['after_frontier']==record['before_lag']==record['after_lag']==record['draft_rows']==0,'Text journal contains draft state: '+name)
            require(record['sampling_seed']==123 and record['sampling_stream']==index and record['sampling_draw_before']==draw,'Text journal crossed user RNG identity or replayed a sampling event: '+name)
            draw=record['sampling_draw_after'];position+=count
        require(position==len(expected)and draw==5 and s['ledger'][-1]['next_id']==ids[-1],'Final emitted pending leaked into consumed journal or changed during restore: '+name)
        journal_oracles[name]=dict(consumed_ids=expected,last_pending=ids[-1],draw=draw)
    full=sessions['u2']['result'];partial=sessions['u3']['result']
    require(full['prefix_full_hits']==1 and full['reused_tokens']==4 and full['prefix_sampling_graph_calls']==1 and full['sampling_stream']==2,'New-request full hit did not sample its own initial stream')
    require(partial['prefix_hits']==1 and partial['prefix_full_hits']==0 and partial['reused_tokens']==4,'Actual nonempty partial-prefix suffix was not exercised')
    require(all(sessions[name]['result']['prefix_hits']==0 for name in['u0','u1']),'A same-wave initial request observed its peer new checkpoint')
    facts={r['private_facts']:r for r in current if 'private_facts'in r};require(facts['Text']['all_roles_text']and facts['Text']['draft_arenas']==0,'Text private no-draft facts missing')
    require(facts['greedy-recovery-and-late-io']['duplicate_outputs']==0 and facts['greedy-recovery-and-late-io']['historical_pending']!=facts['greedy-recovery-and-late-io']['fresh_top1'],'Real greedy restore / postcommit IO failure control missing')
    summary=dict(state='passed',scope='Finite untrained A-only natural Text/MTP request lifecycle; actual N2/R2, new-user full/partial prefix, idle rebuild, pending journal, greedy historical restore and postcommit diagnostic failure.',reports=current,old_MTP_reference=b.pin(D/'old-mtp-reference.json'),MTP_exact_ledger_equal=True,MTP_math_fields_equal=keys,Text_consumed_journal_oracles=journal_oracles,HTTP=0,SDK_builds=0,quality_claim=False,performance_claim=False)
    b.save(D/'summary.json',summary)
    print(json.dumps(dict(state='passed',summary=b.pin(D/'summary.json'))),flush=True)
if __name__=='__main__':
    action,version=sys.argv[1:3]
    {'freeze':freeze,'build':build,'run':run,'native':native_leaf,'program':program_fix}[action](version)
