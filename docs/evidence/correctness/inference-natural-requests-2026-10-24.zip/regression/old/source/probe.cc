// Finite existing A fixture. Ordinary uses real Text roles and no NextN resources.
#include "engine/models/qwen35/main.cc"

namespace q=qwen35;
#if defined(HYLE_PRIVATE_OLD_GENERATION_REFERENCE)
using Schedule=q::benchmark::MtpSessionSchedule;
#else
using Schedule=q::benchmark::GenerationSessionSchedule;
#endif
void require(bool yes,const char* message){if(!yes)throw std::runtime_error(message);}
q::ModelGeometry geometry(){
  q::ModelGeometry s;s.hidden=64;s.intermediate=128;s.vocabulary=64;
  s.query_heads=s.kv_heads=1;s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=s.gdn_value_heads=1;s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4;s.context_limit=16;s.rope_theta=10000;s.epsilon=1.e-6F;
  s.tied_head=true;s.layers="A";s.mtp_layers=1;s.validate();return s;
}
std::vector<q::cache::TokenPlanRef> plans(const std::vector<Schedule>& schedules){
  std::vector<q::cache::TokenPlanRef> result;
  for(const auto& schedule:schedules){
    const std::array phases{q::benchmark::Phase{q::benchmark::PhaseKind::kPrompt,schedule.turns.front().prompt,1}};
    result.push_back(q::cache::token_plan(phases,16));
  }
  return result;
}
void retired(const q::Model& model){
  require(!model.active_step&&!model.carrier_borrowed&&model.snapshot_versions.live==0,
    "natural request run retained an admitted state or execution carrier");
}
void mtp(const std::filesystem::path& manifest){
  const auto shape=geometry();const auto plan=q::cache::plan(shape,16,2,3,
    q::recurrent_bytes(q::state_schema_for(shape,16),shape),2,3,true,true);
  q::Model model(manifest,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
    {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
  model.configure_draft_policy({.max_drafts=2});
  const std::vector<Schedule> schedules{{"m0",{{{1,2},4}}},{"m1",{{{1,2},4}}}};
  const auto input=plans(schedules);const auto start=q::Clock::now();
#if defined(HYLE_PRIVATE_OLD_GENERATION_REFERENCE)
  require(q::run_mtp_sessions(model,schedules,{},false,start,start,true,input)==0,"old natural MTP run failed");
#else
  require(q::run_generation_sessions<q::GenerationMode::kMtp>(model,schedules,{},false,start,start,true,input)==0,"current natural MTP run failed");
#endif
  retired(model);require(model.draft_program_graph_calls>0&&model.prefix_decision_graph_calls>0,"natural K2 proposal/acceptance graph was not executed");
  std::cout<<"{\"private_facts\":\"MTP\",\"retired\":true,\"K2_requested\":true,\"draft_calls\":"<<model.draft_program_graph_calls
    <<",\"prefix_decision_calls\":"<<model.prefix_decision_graph_calls<<",\"full_model\":false,\"HTTP\":0}\n";
}
#if !defined(HYLE_PRIVATE_OLD_GENERATION_REFERENCE)
std::filesystem::path text_manifest(const std::filesystem::path& original,const std::filesystem::path& folder){
  const auto inventory=q::prepared::parameter_inventory(false,geometry());std::set<std::string> required;
  for(const auto& [name,unused]:inventory){(void)unused;required.insert(name);}
  std::ifstream source(original);require(bool(source),"existing cached manifest is absent");
  const auto path=folder/"text-weights.tsv";std::ofstream target(path);require(bool(target),"cannot create finite Text-only role manifest");
  std::string line;for(int i=0;i<3;++i){require(bool(std::getline(source,line)),"cached role preamble missing");target<<line<<'\n';}
  std::size_t found=0;
  while(std::getline(source,line)){std::istringstream fields(line);std::string name;fields>>name;if(required.erase(name)){target<<line<<'\n';++found;}}
  require(source.eof()&&required.empty()&&found==inventory.size()&&bool(target),"Text manifest did not select exactly all original Text roles");return path;
}
void text(const std::filesystem::path& manifest,const std::filesystem::path& folder){
  const auto shape=geometry();const auto selected=text_manifest(manifest,folder);
  const auto plan=q::cache::plan(shape,16,2,5,q::recurrent_bytes(q::state_schema_for(shape,16),shape),2,1,false,true);
  q::Model model(selected,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
    {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
  // User2 extends the original user0 complete first-turn input: two prompt
  // tokens plus the two consumed generated IDs, then one new user token.
  // Real report must independently demonstrate whether this is a partial hit.
  const std::vector<Schedule> schedules{{"u0",{{{1,2},3},{{3},2}}},
    {"u1",{{{1,2},3},{{3},2}}},{"u2",{{{1,2,36,8,5},3},{{3},2}}}};
  const auto input=plans(schedules);const auto start=q::Clock::now();
  require(q::run_generation_sessions<q::GenerationMode::kText>(model,schedules,{},false,start,start,true,input)==0,"natural Text run failed");
  retired(model);require(!model.cache_plan.draft_cache&&model.cache_plan.candidate_boundaries==1&&model.physical_mtp_roles==0,
    "ordinary natural request loaded draft roles or used a draft cache plan");
  require(model.draft_programs.empty()&&model.prefix_sampling_programs.empty()&&model.draft_inventory.keys.empty()&&model.draft_inventory.values.empty()&&
    model.draft_program_graph_calls==0&&model.prefix_decision_graph_calls==0,"ordinary natural request prepared or executed NextN state/programs");
  for(const auto& [key,family]:model.families){(void)key;require(family->role==q::GraphRole::kText,"ordinary finite family used an MTP role");}
  for(const auto& [name,value]:model.weights){(void)value;require(!name.starts_with("mtp."),"ordinary source bank contains an MTP weight");}
  std::cout<<"{\"private_facts\":\"Text\",\"retired\":true,\"mtp_weights\":0,\"draft_cache\":false,\"draft_programs\":0,\"draft_arenas\":0,\"all_roles_text\":true,\"full_model\":false,\"HTTP\":0}\n";
}
#endif
int main(int argc,char** argv){
  try{
    require(argc==3,"natural-requests EXISTING_MANIFEST PRIVATE_OUTPUT");const std::filesystem::path out=argv[2];std::filesystem::create_directories(out);
#if !defined(HYLE_PRIVATE_OLD_GENERATION_REFERENCE)
    text(argv[1],out);
#endif
    mtp(argv[1]);return 0;
  }catch(const std::exception& error){std::cerr<<"natural request regression: "<<error.what()<<'\n';return 1;}
}
