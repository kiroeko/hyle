"""One standard-library parser TU; no SDK, model, or network dependency."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[3]
D = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_check', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

source = R / 'tests/tools/qwen_generation_schedule_test.cc'
header = R / 'engine/models/qwen35/generation_schedule.h'
compiler = b.args(b.CPU / 'compile-command.json')[0]
env = b.environment(compiler)
out = D / (sys.argv[1] if len(sys.argv) > 1 else 'check1')
out.mkdir(exist_ok=False)
paths = [source, header, R / 'engine/models/qwen35/session_schedule.h',
         R / 'engine/models/qwen35/schedule.h', R / 'tests/CMakeLists.txt']
before = [b.pin(p) for p in paths]
b.save(out / 'source-pins.json', before)
image = out / 'compile/parser.exe'
command = [compiler, '/nologo', '/std:c++latest', '/EHsc', '/W4', '/WX', '/utf-8',
           '/permissive-', '/Zc:__cplusplus', '/O2', '/MD',
           '/sourceDependencies', str(out / 'compile/dependencies.json'), str(source),
           '/Fo' + str(out / 'compile/parser.obj'), '/Fe' + str(image)]
b.execute(command, out / 'compile', env, 60)
b.execute([str(image), str(out / 'fixtures')], out / 'run', env, 30)
after = [b.pin(p) for p in paths]
if before != after:
    raise RuntimeError('Canonical parser sources changed during the check')
patch = []
for old, new in [('mtp_schedule.h', header), ('qwen_mtp_schedule_test.cc', source),
                 ('CMakeLists.txt', R / 'tests/CMakeLists.txt')]:
    patch.extend(difflib.unified_diff((D / 'before' / old).read_text().splitlines(True),
        new.read_text().splitlines(True), fromfile=old, tofile=str(new.relative_to(R))))
(D / 'migration.patch').write_text(''.join(patch), encoding='utf8')
summary = {'state': 'passed', 'kind': 'standard-library-only parser regression',
    'canonical_header_tested': True, 'compile': b.read(out / 'compile/process.json'),
    'run': b.read(out / 'run/process.json'), 'source_pins': before,
    'source_sha_unchanged': before == after, 'sdk_builds': 0, 'model_runs': 0,
    'http_requests': 0, 'cmake_registration_edited_not_configured': True,
    'cases': ['explicit/default 129 and exact context bounds',
        'multi-turn pending counted once and session error context',
        'SIZE_MAX quota/parse overflow and I32 position bounds',
        'invalid quota and fixed-input rejection by generation parser',
        'whole-file directive preflight including late mix/unknown/incomplete turns',
        'neutral prompt-only plus natural/fixed peers',
        'cross-session mixed grammar rejected before token-file reads',
        'quoted relative input path and CRLF']}
b.save(out / 'summary.json', summary)
print(json.dumps(summary, indent=2))
