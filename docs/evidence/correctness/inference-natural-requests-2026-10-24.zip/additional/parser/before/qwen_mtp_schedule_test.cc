// Standard-library-only parser regression. No model, SDK, or device is loaded.
// Build this single translation unit and pass a scratch directory to the test.
#include "../../engine/models/qwen35/mtp_schedule.h"

#include <cstdio>
#include <string_view>

namespace {
namespace b = qwen35::benchmark;
namespace fs = std::filesystem;

void require(bool condition, const char *message) {
  if (!condition) throw std::runtime_error(message);
}

void write(const fs::path &path, std::string_view contents) {
  std::ofstream output(path);
  output << contents;
  require(static_cast<bool>(output), "cannot write schedule parser fixture");
}

template<class Read>
void rejects(Read &&read, std::string_view diagnostic) {
  try { read(); }
  catch (const std::runtime_error &error) {
    if (std::string_view(error.what()).find(diagnostic) != std::string_view::npos) return;
    throw std::runtime_error(std::string("unexpected parser diagnostic: ") + error.what());
  }
  throw std::runtime_error("invalid schedule was accepted");
}

void positive_quotas_use_the_real_context(const fs::path &directory) {
  const auto explicit_turn = directory / "explicit.turns";
  write(explicit_turn, "prompt two.ids\ngenerate 129\n");
  const auto parsed = b::read_mtp_schedule(explicit_turn, 10, 130, 4);
  require(parsed.size() == 1 && parsed[0].prompt == std::vector<std::int32_t>{1, 2} &&
      parsed[0].steps == 129, "a valid explicit quota above 128 was rejected or altered");
  require(b::schedule_generates(explicit_turn), "natural generation grammar was lost");
  rejects([&] { (void)b::read_mtp_schedule(explicit_turn, 10, 129, 4); }, "exceed context capacity");
  rejects([&] { (void)b::read_mtp_schedule(explicit_turn, 10, 130, 4, true); }, "exclusive with --steps");

  const auto shorthand = directory / "default.turns";
  write(shorthand, "prompt two.ids\n");
  const auto defaults = b::read_mtp_schedule(shorthand, 10, 130, 129, true);
  require(defaults.size() == 1 && defaults[0].steps == 129,
      "a valid shorthand --steps quota above 128 was rejected or altered");
  rejects([&] { (void)b::read_mtp_schedule(shorthand, 10, 129, 129); }, "exceed context capacity");
}

void multiturn_and_session_bounds_count_pending_once(const fs::path &directory) {
  const auto turns = directory / "two-turns.turns";
  write(turns, "prompt two.ids\ngenerate 129\nprompt two.ids\ngenerate 129\n");
  // Two prompts + 258 outputs - the last unconsumed pending = 261 rows.
  const auto parsed = b::read_mtp_schedule(turns, 10, 261, 4);
  require(parsed.size() == 2 && parsed[0].steps == 129 && parsed[1].steps == 129,
      "two-turn quotas lost their actual per-turn output counts");
  rejects([&] { (void)b::read_mtp_schedule(turns, 10, 260, 4); }, "exceed context capacity");
  const auto sessions = directory / "sessions.txt";
  write(sessions, "a two-turns.turns\nb explicit.turns\n");
  const auto multiple = b::read_mtp_session_schedules(sessions, 10, 261, 2, 4);
  require(multiple.size() == 2 && multiple[0].turns.size() == 2 &&
      multiple[1].turns[0].steps == 129, "session wrapper altered a valid large quota");
  rejects([&] { (void)b::read_mtp_session_schedules(sessions, 10, 260, 2, 4); }, "session a:");
}

void quota_and_position_overflow_is_rejected(const fs::path &directory) {
  const auto path = directory / "limits.turns";
  const auto maximum = (std::numeric_limits<std::size_t>::max)();
  write(path, "prompt two.ids\ngenerate " + std::to_string(maximum) + "\n");
  rejects([&] { (void)b::read_mtp_schedule(path, 10, 130, 4); }, "exceed context capacity");
  write(path, "prompt two.ids\ngenerate " + std::to_string(maximum) + "0\n");
  rejects([&] { (void)b::read_mtp_schedule(path, 10, 130, 4); }, "supported size range");
  write(path, "prompt two.ids\n");
  rejects([&] { (void)b::read_mtp_schedule(path, 10, 130, maximum); }, "exceed context capacity");
  rejects([&] { (void)b::read_mtp_schedule(path, 10, 130, 0); }, "positive generation quota");

  const auto positions = static_cast<std::size_t>((std::numeric_limits<std::int32_t>::max)());
  write(path, "prompt one.ids\ngenerate " + std::to_string(positions) + "\n");
  // Parsing the quota never allocates a generated-token array of that size.
  const auto bounded = b::read_mtp_schedule(path, 10, positions, 4);
  require(bounded.size() == 1 && bounded[0].steps == positions,
      "I32 context limit acquired an unrelated artificial output bound");
  rejects([&] { (void)b::read_mtp_schedule(path, 10, positions + 1, 4); }, "within I32 positions");
  rejects([&] { (void)b::read_mtp_schedule(path, 10, 0, 4); }, "within I32 positions");
}

void invalid_quota_syntax_still_fails_before_execution(const fs::path &directory) {
  const auto path = directory / "invalid.turns";
  for (const auto quota : {"0", "-1", "129x"}) {
    write(path, std::string("prompt two.ids\ngenerate ") + quota + "\n");
    rejects([&] { (void)b::read_mtp_schedule(path, 10, 130, 4); }, "positive integer output quota");
  }
  write(path, "prompt two.ids\ndecode one.ids\n");
  rejects([&] { (void)b::read_mtp_schedule(path, 10, 130, 4); }, "natural MTP uses generate");
}
} // namespace

int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("pass the scratch fixture directory");
    const fs::path directory = argv[1];
    fs::create_directories(directory);
    write(directory / "one.ids", "1\n");
    write(directory / "two.ids", "1 2\n");
    positive_quotas_use_the_real_context(directory);
    multiturn_and_session_bounds_count_pending_once(directory);
    quota_and_position_overflow_is_rejected(directory);
    invalid_quota_syntax_still_fails_before_execution(directory);
    std::puts("PASS explicit/default129, multi-turn/session capacity, size/I32 limits, invalid grammar");
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "%s\n", error.what());
    return 1;
  }
}
