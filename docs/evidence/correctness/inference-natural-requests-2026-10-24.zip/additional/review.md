# 自然请求统一：独立只读复审

审查旧基线 `main.cc` SHA `24c7d4594c82428a6829205d45a06239884b179deaa1f5ab45f79c545a404d2b`，及本批实现；最终复核 main SHA `23a5ddd70aecd63d998a7b2bdd8d159f856f54ec81d5d24ee2b1abe08cdff1a5`，session_state.h SHA `2ebcc76d89fbeba6943b2c245f8102241f6ec7d48aedab098777b6b9955fd5e3`。
本轮未编辑产品、构建、运行测试／模型或联网；下面是源码结论，不替代另一代理的实际回归。

## 发现并已由实现方修正的两项

1. **Text 首次 finish 被旧 MTP journal 门禁拒绝。** 初版在 main:3852–3853 对任何 generation_ledger 都要求 draft_cache。新 Text runner 总传 ledger，因此 native 提交后、发布前会错误退出。已改为实际 MTP role 才要求完整 draft participant；原 role/base/输入记录校验仍在，未放松事务。
2. **普通 P>1 的 decode1 carrier 由冷准备落入首次 decode。** 初版共同 runner 只在 ready 前 prepare 首 prefill，旧普通入口则预备已知 T1。最终 main:5339–5342 在 Text 且 decode_bound>0 时显式 prepare_execution({1},1,kText)，恢复该已知 cold/hot 边界；未预造全后端或批宽矩阵。

## Text／MTP 与发布边界

- Text 模式检查 Plan 的 draft_cache=false（5224–5230）；Model 按它只选 Text weights/projections（1911–1915），不是 maxK0 MTP。冷 shapes 只含 kText，未调用递归 draft/prefix helper；初始 Snapshot 不创建 draft、NextN KV 或 draft hidden（3232–3238）。
- Text 的 prompt/decode 选择 kText（4832、4871、4890），共同 execute 仍用 prepare_evaluations/submit_evaluations/finish_evaluations（5033–5039）；decode 消费一个实际 pending、产生一个输出，没有接受算法替代普通数学。
- 逐段比较旧基线与最终源码，归一 journal/boundary/expected 字段重命名后，propose_recursive、repair_recursive_draft、finish_recursive_mtp、finish_mtp_rounds 四个函数正文相同。没有以生命周期统一为由改 MTP p/q、接受前缀、EOS/quota 或修复数学。
- 普通 record 的 draft rows/frontier/lag 为0（generation_boundary、4002–4004），只记录真实 consumed pending；MTP 继续保留 verification_inputs、接受输入及完整 draft 状态。
- finish 先等待原 Completion（3869），完成 state/readback、expected-base 和记录验证，再一批换 head 并标 journal committed（4050–4070）；后续诊断 IO 不回滚已提交 head/RNG。
- observer 由 ledger_observed 去重，输出和观察容器按全部 quota 冷预留（4563–4610、5240–5267）；批次 finish 晚 IO 抛错后仍观察所有成员（5054–5056），不会因返回异常漏记已发布 token。
- full prefix hit 在 trailing trace IO 前设置 generated/prefilled/done，并以 prefilled 门禁防重复观察（4926–4975）；该源码门禁正确，实际故障注入由回归代理负责。

## N/R、wave、prefix 与恢复

- active 无 Session 的新成员仍占预约 head 名额；只淘汰不在 active 内的 idle Session（5368–5380）。真实版本去重与释放预测用 canonical state_identity，PrefixCache::retains 也归一该身份（prefix_cache.h:318–322）。
- 全 wave 先 lookup/admit，再按相同 role/真实 rows/full-hit 分桶；MTP EOS 后不同宽度再次拆组，无 padding（4986–5008、5412–5439）。全部执行后才发布本 wave 的 prompt/completed checkpoints（5459–5466）。
- warm_inputs 每 turn 有独立稳定 owner；只填尚未执行的当前 turn 首个旧 pending。prompt span/ledger owner 不转到本轮 scratch；verification_ids/q leases 跨 proposal/分组/target 验证继续各自持有。
- 新请求完整 prefix hit 在原 evaluated hidden 上使用新请求 cursor 采样；同请求 completed checkpoint 恢复则用最后 committed record 的 pending/cursor fork（4839–4864、5384–5392），二者没有混用旧 next_id 快捷路径。
- rebuild 仅取 committed_ids，逐块验证连续上下文，再按 Text/MTP 选择原角色重算；每块完成后恢复历史 pending/cursor，MTP 最后核归一 lag0（4705–4780）。这不是同 R/T 的逐位严格回放，也不重新向用户输出历史预测。
- 最终 emitted token 不入 consumed checkpoint；下一 turn 才把它放入一次输入（5400–5406）。checkpoint 的 TokenPlan/ReplayHistory 自有稳定 owner，不借短命 bucket span。

## 普通单用户开销与抽象范围

- prefix off 时没有每 token prefix hash/目录查找；自然 future token 不进入固定 make_schedule_waves。input_hash 仅最终 JSON 输出阶段计算（5558–5559），不在 decode Graph 调度前。
- 普通没有新增全词表 CPU 读回、dtype 转换、provider 选择或执行器；保留原 ID/valid 小 readback。InputPreparationScratch 仍只共享同步上传的整数，原 Tensor/lease/capture 身份不变。
- 新普通路径确实增加有限提交 journal/round 观察元数据：按 quota 冷预留，热路径复制少量 ID/事实。不能宣称零 CPU 开销或已提升 TPS；没有发现本批引入需要立即另起框架解决的重复全历史拷贝。
- 共用外层是一个有限模板模式和原 Request/Call；数学、state repair、严格 MTP replay 保留各自边界，没有把测试故障控制器或所有状态容器泛化进公共层。

## state pool 对齐

- 每池同尺寸 payload=P、slots=S：新公式 P×S+padding(P)×(S−1)+1（session_state.h:34–41），与真实 allocate(...,256) 对齐一致；P 已对齐时保原公式。
- hidden Plan/实际 pool 同用 state_pool_backing_bytes；recurrent Plan 把每层 history/recurrent 的各自 padding 乘 S−1，再叠原 payload×S 与每池末字节（82、112–125）。实际已解析 TensorDesc 计算 pool 容量（main:2178–2192）。
- 初始和调用方写 state/hidden 的各处 allocate 均显式 state_pool_alignment（2876、3236–3241、3756、3766），LeasePool backing_alignment 默认同为256（resource_leases.h:24）。有限预算仍统计实际 backing，不是增大上限或掩盖对齐失败。

## 当前实际回归另暴露的 Vulkan 门禁（未解决）

根代理／回归代理的 current2 实跑已过 R2/P2 和首次 R2/T1，第二次 R2/T1 在 prepare_replay 报 `Vulkan retained output private owners changed`；本审查仅读取其原日志，没有自行重跑。日志模式为 commands，并非关闭 capture 可解释的问题。
throw 位于 `vulkan_program.cc:975–977`：`!rearm` 时当前输出 Buffer use_count 小于先前 seal 的私有 baseline。该拒绝正确保护资源合同，不能减小 baseline 或放宽 readers。
当前源码期望 `resources.cc:301–320` validate 后 reverse release，`native_region.cc:746–751` 调 detach_inputs，再由 `vulkan_program.cc:1174–1177` 标 `output_rearm_required=true`；下一 bind 必须完成实际 owned block 选择／重绑与 seal，不能沿旧 baseline 写回。
需由现有诊断确定失败 output/root、constant/input alias、count/baseline 与 sealed/preparing/rearm/epoch flags，并核实际链接对象是否包含该释放合同；单凭错误字符串不能区分遗漏 withdraw 传播、旧缓存或状态机缺陷。新 journal 无 Snapshot/ReadLease，不构成直接额外 native owner 来源。

结论：上述两项源码遗漏已修；本次只读范围未再发现新执行器／抽象需要，但实际 Vulkan 复用门禁仍阻塞完成，不能把本笔记签成整体通过。未对整项目、所有并发调用或性能作完成声明。

后续有限设计复审：初版在每个 generic bind 调 prepare_bindings 后，根代理原 UnifiedInvocation 输入别名回归暴露 owned_output_block 拒绝；不能把 boundary-input alias 当新自有 writer。实现方新 `vulkan_program.cc` SHA `decf99a01020e2a957eaf63068f0683aec8a02248fd37737f00afc796930d64d` 已自然分 owned／input-root／constant：computed alias 沿 owned whole-block，input alias 保 exact 旧 reader gate 且不复制输入，constant 不轮换。
独立读新 diff：prepare_bindings 全输出资格校验后才改 flags；prepare_outputs 在整 classification loop 后才分配／选择 native backing。alias 拒绝时 rearm_required 保 true、epoch_pending 未发布，重试不能命中 prepared 早返；sealed bind 每次先检查 alias，pending epoch 不绕过旧 reader。原 count/baseline、ResultSlot、direct 和 detach 门禁未放宽。此项仅源码认可，原 boundary/current runtime 结果仍待回归代理，不在本笔记冒签通过。
