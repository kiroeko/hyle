from pathlib import Path
import hashlib, json, zipfile
R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
O = R / 'docs/evidence/correctness'
name = 'inference-natural-requests-2026-10-24'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p): return {'path':p.relative_to(R).as_posix(), 'bytes':p.stat().st_size, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
regression = read(D / 'regression/proof-summary.json')
parser = read(D / 'parser/check2/summary.json')
alignment = read(D / 'alignment/summary.json')
boundary = read(D / 'vulkan-boundary/fixed/summary.json')
assert regression['state'] == parser['state'] == boundary['state'] == 'passed'
assert alignment['status'] == 'PASS'
checks = [(R/'engine/models/qwen35/main.cc',regression['final_app_source']),
          (R/'src/graph_route_vulkan/native_region.cc',regression['final_native_region']),
          (R/'src/compute_route_vulkan/vulkan_program.cc',regression['final_native_program'])]
for product, source in checks: assert pin(product)['sha256'] == source['sha256']
archive = O / (name + '.zip')
assert not archive.exists()
suffixes = {'.cc','.h','.py','.md','.json','.log','.patch','.diff','.txt','.ps1'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    with zipfile.ZipFile(D / 'regression/proof.zip') as original:
        for item in original.infolist():
            assert not item.is_dir() and Path(item.filename).suffix in suffixes
            out.writestr('regression/' + item.filename, original.read(item))
    for folder in ['alignment','parser','vulkan-boundary','vulkan-epoch']:
        for p in sorted((D/folder).rglob('*')):
            if p.is_file() and p.suffix in suffixes:
                out.write(p, 'additional/' + p.relative_to(D).as_posix())
    for p in [D/'review.md',D/'implementation-note.md',D/'performance-boundaries.md',
              D/'changes.patch',D/'before-pins.json',D/'after-pins.json',D/'publish.py']:
        out.write(p, 'additional/' + p.relative_to(D).as_posix())
    for p in [R/'engine/models/qwen35/session_state.h',R/'tests/tools/qwen_prefix_cache_test.cc',
              R/'tests/tools/qwen_generation_schedule_test.cc',R/'engine/models/qwen35/generation_schedule.h',
              R/'tests/CMakeLists.txt',R/'tests/graph_route_vulkan/native_region_test.cc']:
        out.write(p,'canonical/' + p.relative_to(R).as_posix())
report = {
 'state':'passed', 'date':'2026-10-24',
 'scope':'Finite Windows CPU pool/parser checks and Vulkan untrained A-only natural Text/MTP request lifecycle; global architecture remains in progress.',
 'changes':[
  'One natural Text/MTP request/turn/admission/batch/cache/rebuild lifecycle; genuine Text loading, plans and Graph role, no draft resources.',
  'Shared atomic consumed-input/pending/RNG journal and ordinal postcommit observer; explicit fixed-token replay remains distinct.',
  'New-request frontier versus same-request historical pending restored separately, including greedy canonical-root output.',
  'State-pool capacities include 256-byte alignment gaps; actual allocations and backing alignment explicit; aligned Q35/Q27 budgets unchanged.',
  'Vulkan generic sealed binding enters the next output epoch. Constants, input aliases and owned output writers retain distinct original ownership rules.'
 ],
 'sources':[pin(p) for p,_ in checks]+[pin(R/'engine/models/qwen35/session_state.h')],
 'parser':parser,
 'CPU_state_capacity':alignment,
 'Vulkan_existing_alias_and_owner_case':boundary,
 'natural_requests':regression,
 'preserved_failures':[
  'Unmodified old baseline fails its second 128-byte initial hidden allocation; capacity-only old control is explicitly qualified, not an unchanged old pass.',
  'Early source-only draft guard/known Text cold preparation omissions fixed before actual current integration.',
  'current2 actual Text second R2/T1 reuse failed private owner gate; current3 known alias limitation was not run as an app.',
  'Existing native alias case actually rejected naive output-epoch gate; final same existing case passes with exact reader guards retained.',
  'Private parser wrong language flag, CPU launcher missing retained runtime PATH and native leaf missing implicit include path preserved; fixes affect private launcher only.'
 ],
 'not_claimed':['trained-model task quality','full-model TPS/memory improvements','complete multi-platform regression','complete cross-model architecture','all ordinary-engine functions'],
 'SDK_builds':0, 'downloads_bytes':0, 'HTTP_requests':0,
 'archive':pin(archive),
 'cleanup':'Rebuildable check images/objects will be removed through root test.ps1; patched production Vulkan leaf cache is retained for reuse.'
}
(O/(name+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'report':pin(O/(name+'.json')), 'archive':pin(archive)}))
