from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[3]
D = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
if (D / 'link/probe.exe').exists():
    env = b.environment(b.args(b.CPU / 'compile-command.json')[0])
    image = D / 'link/probe.exe'
else:
    env = b.compile(D / 'probe.cc', D / 'compile')
    image = b.link(D / 'compile/unit.obj', D / 'link', env)
env.update({k: v for k, v in b.read(b.CPU / 'runtime-environment.json').items() if isinstance(v, str)})
b.execute([str(image)], D / 'run2', env, 30)
b.save(D / 'summary.json', {'status': 'PASS', 'test': 'canonical qwen prefix/cache capacity tests including real aligned state pools',
    'source': [b.pin(R / 'engine/models/qwen35/session_state.h'), b.pin(R / 'tests/tools/qwen_prefix_cache_test.cc')],
    'commands': [str(D / x / 'command.json') for x in ['compile','link','run2']],
    'failed_attempt': 'run: private launcher omitted retained runtime PATH; image failed before main, preserved; corrected launcher only, same image',
    'models_downloaded': 0, 'model_execution': False, 'gpu_execution': False})
print(json.dumps(b.read(D / 'summary.json')))
