#define HYLE_PREFIX_CACHE_STANDALONE 1
#include "tests/tools/qwen_prefix_cache_test.cc"
