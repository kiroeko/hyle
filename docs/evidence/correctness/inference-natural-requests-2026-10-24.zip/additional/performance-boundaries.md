# 自然请求统一：性能与寿命边界

只读基线：`engine/models/qwen35/main.cc` SHA256 `24c7d4594c82428a6829205d45a06239884b179deaa1f5ab45f79c545a404d2b`。
结合 `request-unification-next.md`；本轮只写本笔记，不修改产品、编测、下载或测量吞吐。

## 普通路径必须保持真实 Text

- 在请求入口一次选择 Text/MTP 策略；共享 turn、admission、idle、wave 和计时，不新增每 token 后端选择。
- Text 的 Plan 必须 `draft_cache=false`；构造时仍按它选择 `WeightSelection::kText`，只绑定文本投影（main:1911–1915）。
- 同一份含 MTP 的清单可完整校验后只选文本角色（1358–1366），不能为统一循环常驻 draft 权重／cache。
- Text 冷准备仅 `prepare_family/plan_execution/prepare_execution(...,kText)`；普通 `run_plain_turns:5573–5574` 已是该路径。
- Text 批次仍 `prepare_evaluations(...,kText)→submit_evaluations→finish_evaluations`；3579–3582 会拒绝把 draft Plan 冒充 Text。
- Text 每次消费一个真实 pending 后采样下一 token；不能调用 `prepare_mtp_call(maximum=0)`，后者仍读 draft lag、走 MTP role（4855–4863）。
- 不为 Text 准备 NextN、prefix verifier、修复程序或 `MtpRoundResult`；随机策略继续用现有共同 sampler 和本会话 draw。

## 不能盲目合并或改成一份 scratch 的持有者

- `warm_inputs` 的每 turn owner（4488、5228–5235）被 prompt span 和 ledger 的 `input_owner/prompt_ids` 借用（4506–4521）。
  只在该 turn 尚未执行时填其首个 pending（5370）；不能清空、搬移底层数组或复用为另一请求的拼接区。
- 普通 turns 当前也在冷阶段分配每 turn 的 `[旧pending?,新prompt...]`（5562–5571）；统一后保留该稳定 owner，无需每轮重新复制全部历史。
- `PreparedMtpCall.verification_ids` 与 `draft_log_probabilities`（4765–4779）须跨全部 proposal、实际宽度分桶和 target 完成存活。
  `execute_mtp_calls:4952–4972` 先逐请求产出 q，再按 EOS/threshold 后的真实宽度分组；不可让第二请求覆盖第一请求的 ids/q。
- `call.ids()` 可能指向 call 自身的 pending，也可能指向 verification vector；构造 EvaluationRequest spans 后，call 容器不能再增长或搬移。
- q 的 ReadLease 保留原全词表设备分布和原 producer pin；不能用浅裸 view、CPU 全词表读回或重算 q 替代该寿命。
- `ReplayHistory`、普通 `consumed` 与 MTP ledger 不同：普通固定 tape 的输入可能与 generated 不同（5992、6483–6485）。
  自然生成的 journal 只能记录实际已消费输入；MTP 还保留接受前缀、draft frontier/lag、原 cursor，不应压成一个 next_id 数组。
- 旧 history 可能被 prefix 目录共享；恢复应另建 metadata，不能就地覆盖别的会话历史（6333–6337、6364–6391）。
- `round_emitted` 冷容量会移交给永久 round 记录（5237–5239、4555–4567）；它不是能每轮 clear 的共用临时输出。
- completed checkpoint 借 committed chunks 后创建自己的 token/history owner（5029–5040）；不能只留指向短命 bucket 的 span。
- Snapshot/StateHead、页尾权限、ReadLease 和未退休 Invocation 不进入 host scratch；保留原 N/版本计费和成功后发布。

## 可共享的最小元数据与容量

- 现 Model `InputPreparationScratch` 仅纯整数，按实际 Phase Tensor 冷 reserve；同步 write 返回后可复用（1158–1171、3431、3634–3647）。
- target/draft positions 仍分开；经典 T2 的 pending 输入为 R 而位置为 2R，catchup prefill 为 R×(T+1)，不能统一成一个“rows”长度。
- prefix sampler 的 identity 容量是 `4×(m+1)`，普通／经典随机是 `12R`；同一 vector 取已准备 Tensor 的最大值，不重复乘 R（2970–2971）。
- 这种共享依赖现单 carrier 和外部串行调用；若增加并发 slot，须改为每 slot 一份，普通 bool 不是线程同步。
- 外层 prepared/input/output/next/member 临时数组可在 runner 冷 reserve R，wave 内 clear；固定普通批次已有范例（6279–6292）。
- 统一时不新建另一层装箱、虚调用、`std::function`、输出 Tensor 或 dtype 转换；不把大请求对象逐 bucket 深拷贝。
- 请求输出按所有 turn quota 预留，长期 journal/rounds 按有限实际消费与候选边界预留；Text 不付 MTP 的 K 倍记录空间。
- MTP 不同宽度组当前 move 其 call（4969–4972）；后续若去除这些热临时，只能用稳定索引/预留组存储，不能提前释放 q。

## 调度、恢复与测量边界

- 固定 tape 的 `make_schedule_waves` 预知输入（6046）；自然生成未来 token 未知，不能预造 tape 或对候选 padding 来复用波次表。
- 可共享“整 wave 先 lookup/admit、后逐 exact-role/exact-row bucket、最后发布”的协议（5377–5429；普通6293、6496–6505）。
- N 同时计真实 head 与无 Session 的预约名额（5333–5339），R 只计实际执行批宽；保留 idle 退休、prefix alias 与 finite budget 判定。
- 新请求完整 prefix hit 要按新 cursor 采样 first token；同请求 checkpoint restore 保旧 pending/cursor，二者不可共用旧 next_id 快捷分支。
- 恢复可共用外层预算/owner 协议，保留 Text committed-input 重算和 MTP 完整 draft 修复；恢复采样不得推进请求 cursor。
- 最后 emitted token 仍 pending；下 turn 只消费一次（5551–5553、5586），EOS/quota 依据实际输出，失败先观察已提交 head/journal。
- 保留连续 turn/wave 区间，proposal/restore/prefix-frontier/发布成本不可移出测量；吞吐按 wave 墙钟计一次，不能累加各会话等待（5414–5418、6454–6456）。
- 此迁移不承诺 TPS 改善；先保证普通无额外 draft 加载、图节点、转换、搬运和等待，实际性能随后用既有方法测量。
