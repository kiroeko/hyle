# 普通/MTP 自然请求：最小实施切片

只读基线 main SHA `24c7d4594c82428a6829205d45a06239884b179deaa1f5ab45f79c545a404d2b`。建议直接扩现有自然请求循环，分两步接通；不另起 scheduler/执行器/配置 registry。

## 两条旧路径的真实差异

- `run_plain_turns:5554–5645` 是自然生成：每轮用户 prompt 前补上次最终 pending 一次；prefill 产首输出，随后每步消费刚输出的 pending；EOS 只结束本轮。它真实走 `kText`，但只有一个常驻 Session，无 N/R、prefix 或淘汰恢复。
- CLI 内 `SessionRun:5984+` 是固定输入 replay：`calls/chunks/generated/consumed` 与 `make_schedule_waves` 从已知 prompt/decode IDS tape 预算。恢复 (`6173+`) 重放历史指定输入，再恢复 saved RNG/pending；重新计算的预测仅作诊断。不能把 generated 结果填回 tape，或据此预排自然未来 token。
- `run_mtp_sessions:5212–5435` 已有自然 waiting/active/idle、预占 head 名额、有限 N/R、实际 role/rows 分桶、turn pending 拼接、波次后 prefix 发布和淘汰恢复，应作为共同外层。

## 第一步：让同一循环真正执行 Text（先内部接通，不提前删旧入口）

1. 给现 `run_mtp_sessions` 一个冷选择的 Text/Mtp 模式（两个模板实例或等价有限静态分支即可），不建 strategy 类层级。共享 admission/turn/dispatch/计时/完成代码；只有 role、执行结束和恢复的模型状态分支不同。
2. `prepare_mtp_call:4784–4862`、`execute_mtp_calls:4946–5018` 扩为共同自然 call：Text prompt 与 decode 都是 `GraphRole::kText`；decode 输入严格为已提交 head 的 pending，一行、输出一个。Text 用原 `finish_evaluations`；MTP 保原 recursive/fused finish、接受前缀和 draft 修复。
3. `5212–5309` 的冷形状计划按模式生成：Text 只准备实际 prompt(+前轮 pending)、decode1、必要 R1 重建 chunks 和可达 R 批宽；不调用 prepare_recursive_round_programs、不准备 MTP family。Model 仍用普通 `cache::plan(...draft_cache=false)` 和 Text 权重选择，head.draft 必须为空；不是 MTP maxK0。
4. 请求公共字段先留当前驱动附近即可；不必为本次单模型复用先迁到 engine/inference。只保留一套请求/turn/warm_inputs/dispatch 容器；MTP 额外统计与 ledger 细节保持明确，不让 Text 分配 draft KV/pool/权重。

## 必须同批补的提交事实边界

- 当前 MTP ledger 不能原样给 Text：`finish_selected_evaluations:3981+` 的 commit_record 路径直接访问 `member.next->draft`，prompt import、rebuild、publish 也写死 MTP role/lag。
- 最小方向是扩**原提交 witness/journal**为普通+MTP均能表达的已消费输入记录，沿原 head-swap 前填充、同次标 committed、观察序号去重；不要在 Text 另建一套独立事务/缓存管理器。
- Text 每条只记录真实 consumed IDs（prompt owner 或按值 pending）、after length/pending/Cursor、endpoint；draft rows/lag 为0。原 MTP 仍保验证输入/宽度/接受前缀和 draft 边界，不能丢掉原严格 episode 记录。
- 现 `observe_mtp_commits:4545+` 的“诊断 IO 抛错后仍观察已提交记录”必须延续到 Text；不能只在 evaluate 成功返回后 push generated，否则 head 已提交但 trace 失败会漏记/重抽样。
- 不新增热分配：记录、输出容量按请求总 quota 预留；普通单行输入存记录值，prompt span 保原 warm owner。最终输出 pending 不进入 consumed key。

## 第二步：普通 N/R、恢复和 prefix 完成后再切 CLI/删旧循环

1. `5346–5375` admission：Text checkpoint hit 复用完整 Snapshot，并保本请求历史 pending/Cursor；miss 沿原 committed journal 用 `kText` 重建已消费输入，再 restore_sampling，不重抽历史输出。MTP 原 ledger repair/lag 归一逻辑不改。
2. `rebuild_mtp_session:4690–4763` 按 Text/Mtp 选原角色，Text 不读 draft->lag；committed chunk 长度、恢复后 context、最终 pending/Cursor 均核对。不可把消耗 token 重建宣称原 R/K 数值逐位 replay。
3. `make_mtp_room/make_mtp_batch_room` 的实际版本计数与 idle 真退休规则自然复用；保持同 wave 的未建 head 预占、全查找/接纳先于执行、全部执行后再发布，不能让同 wave 相互命中新 checkpoint。
4. `publish_mtp_prompt/completed:5020–5040` 共用真实 consumed_checkpoint。Text 无 lag 检查；MTP 保 lag/完整状态检查。已有完整/部分命中需要的实际 suffix 仍走有界 cold exact admission，不预编 context 全长度。
5. `mtp_schedule.h` 的 prompt/generate 数据和 parser 改为自然生成名称，仍与固定 decode tape 语法分开；CLI `5827–5856` 对单/多会话都先判 grammar，再完整读取所有文件。混合 replay/generate 清楚拒绝，不能因 --mtp off 就强选 tape parser。
6. Text 自然 schedule 从 `run_plain_turns` 切入共同循环后删除旧实现；R1 单请求同样复用该循环。固定 `--decode-ids`、prompt/decode schedule 与现 SessionRun replay 保留显式路径和测量含义。单请求 --inputs/--steps 的自然模式也可归一成一个 turn，显式 forced tape 继续分流。

## 一个有限验收，不展开矩阵

沿现 CPU tiny Model 构造三会话两轮、N2/R2、quota3再2、固定 seed/不同 stream、prefix on 的真实 Text 旅程：出现 R2 与一次 idle 淘汰/恢复；draft 角色/权重/资源全为0；每用户5输出且 draw5，前轮最后 pending 只在次轮消费一次，最终 pending 不入 KV/key。验证实际 journal 与重建 context、pending/Cursor，失败/取消不重复输出；不要求 R1/R2 token 位相等。再复用旧 MTP K2/N2R2 最小回归确认共同外层未改接受数学，固定 tape 只查入口未被重新解释。

第一步不能宣称“普通自然多会话完成”；最终交付必须包含第二步的 N/R、真实淘汰恢复与完整/部分 checkpoint。普通生命周期收敛比移动 MTP 命名更重要。

未编辑 canonical、构建、运行模型或访问网络。
