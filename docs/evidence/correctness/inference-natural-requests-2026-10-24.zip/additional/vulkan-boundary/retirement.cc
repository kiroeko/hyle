// The retained compiler helper adds the existing GoogleTest include cache for
// this source name; the actual selected test is the native region owner case.
#include "tests/graph_route_vulkan/native_region_test.cc"
