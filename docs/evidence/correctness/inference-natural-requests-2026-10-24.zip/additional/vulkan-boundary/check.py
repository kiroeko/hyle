from pathlib import Path
import importlib.util, json, os, sys
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[3]
D = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
if sys.argv[1] == 'compile':
    b.compile(D / 'retirement.cc', D / 'compile', vulkan=True)
elif sys.argv[1] == 'run':
    version = sys.argv[2]
    base = D.parent / 'regression' / version
    attempt = D if len(sys.argv) < 4 else D / sys.argv[3]
    command_file = base / 'link/command.json'
    if len(sys.argv) > 4: command_file = R / sys.argv[4]
    original = b.args(command_file)
    old = str(base / 'compile/unit.obj')
    if original.count(old) != 1: raise RuntimeError('Expected exactly one original main image object')
    command = [str(D / 'compile/unit.obj') if p == old else p for p in original
        if not p.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:'))]
    command += [str(R / '.scratch/build-compute-v2-dev/lib' / name) for name in ['gtest.lib', 'gtest_main.lib']]
    command += ['/OUT:' + str(attempt / 'link/probe.exe'), '/PDB:' + str(attempt / 'link/probe.pdb')]
    env = b.environment(b.args(base / 'compile/command.json')[0])
    b.execute(command, attempt / 'link', env, 120)
    for dll in (base / 'link').glob('*.dll'): os.link(dll, attempt / 'link' / dll.name)
    env.update({k:v for k,v in b.read(b.VK / 'runtime.json').items() if isinstance(v,str)})
    env['PATH'] = str(attempt / 'link') + ';' + env['PATH']
    b.execute([str(attempt / 'link/probe.exe'), '--gtest_filter=VulkanNativeRegion.UnifiedInvocationKeepsGeneratedViewsSlotsAndOwners'], attempt / 'run', env, 60)
    b.save(attempt / 'summary.json', {'state':'passed', 'test':'VulkanNativeRegion.UnifiedInvocationKeepsGeneratedViewsSlotsAndOwners',
        'scope':'Actual native two-slot generated outputs, computed and input alias views, escaped readonly lease gate and post-owner lifetime',
        'test_source':b.pin(R / 'tests/graph_route_vulkan/native_region_test.cc'),
        'product_source':b.pin(R / 'src/graph_route_vulkan/native_region.cc'),
        'link_basis':b.pin(command_file), 'performance_claim':False, 'SDK_builds':0, 'HTTP':0})
    print(json.dumps(b.read(attempt / 'summary.json')))
else: raise RuntimeError('compile | run current-version')
