"""Offline strict audit of the actual K1 relay report; never starts native work."""
from pathlib import Path
import argparse
import json
import math

W = Path(__file__).resolve().parent
COUNTS = {
    'cpu': {'source_submissions': 0, 'successor_submissions': 0,
            'successor_discards': 0, 'cpu_optional_source_declines': 4, 'native_submissions': 26,
            'priming_submissions': 0},
    'cuda': {'source_submissions': 4, 'successor_submissions': 4,
             'successor_discards': 3, 'cpu_optional_source_declines': 0, 'native_submissions': 44,
             'priming_submissions': 15},
}
BACKEND_FLAGS = {'cpu': {'replay_commands_only': True, 'cold_ready_tuple_priming': False},
                 'cuda': {'replay_commands_only': False, 'cold_ready_tuple_priming': True}}
TRUE_FLAGS = ('full_accept_two', 'partial_accept_one_retry',
              'quota_terminal_discard', 'cancel_after_A_commit', 'no_publication_before_A_finish',
              'original_ledger_preserved', 'old_checkpoints_byte_unchanged',
              'real_successor_retirement', 'greedy_rng_unchanged', 'synthetic_untrained')
FALSE_FLAGS = ('quality_claim', 'performance_claim', 'natural_RequestLoop_claim',
               'simultaneous_native_inflight_claim', 'model_eos_run')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def check_report(report, backend):
    assert backend in COUNTS
    assert report['status'] == 'PASS' and report['case'] == 'mtp-relay'
    assert report['backend'] == backend
    for field, expected in {'models': 1, 'arms': 4, 'final_versions': 0, **COUNTS[backend]}.items():
        actual = report[field]
        assert type(actual) is int and actual == expected, (field, actual, expected)
    for field in TRUE_FLAGS:
        assert report[field] is True, field
    for field in FALSE_FLAGS:
        assert report[field] is False, field
    for field, expected in BACKEND_FLAGS[backend].items():
        assert report[field] is expected, (field, report[field], expected)
    # The retained CPU counter name denotes four pre-submit Source-preparation
    # declines followed by original serial A; it proves no CPU async successor.
    rows = report['state_checks']
    assert isinstance(rows, list) and len(rows) == 6
    for index, row in enumerate(rows):
        assert row['boundary_equal'] is True, ('boundary', index)
        assert row['exact_next'] == row['bucket_next'], ('next_id', index)
        assert row['numerically_equivalent'] is True, ('numeric', index)
        differences = row['differences']
        assert isinstance(differences, list)
        assert row['payloads_byte_equal'] is (not differences), ('byte_equal', index)
        for difference in differences:
            assert difference['role'] == 3 and difference['nonfinite_differences'] == 0, (index, difference)
            absolute = difference['maximum_absolute']
            assert math.isfinite(absolute) and 0 <= absolute <= 3e-6, (index, difference)
    # Whole KV/metadata and immutable checkpoints are checked inside the CXX
    # consumer. Do not invent an aggregate byte-equality field absent from JSON.
    return report


def audit(directory, backend):
    directory = Path(directory)
    process = read(directory / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out'], process
    command = read(directory / 'command.json')
    args = command['command'] if isinstance(command, dict) else command
    assert '--' + backend in args and '--mtp-relay' in args
    reports = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    assert len(reports) == 1
    report = check_report(reports[0], backend)
    result = {'status': 'PASS_OFFLINE_REPORT_AUDIT', 'case': report['case'], 'backend': backend,
              'process': process, 'state_comparisons': len(report['state_checks']),
              'byte_exact_state_comparisons': sum(row['payloads_byte_equal'] for row in report['state_checks']),
              'actual_counts': {field: report[field] for field in COUNTS[backend]},
              'actual_route_facts': {field: report[field] for field in BACKEND_FLAGS[backend]},
              'claims': {field: report[field] for field in FALSE_FLAGS}}
    with (directory / 'audit-result.json').open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print('AUDITED', report['case'], backend, 'PID', process['pid'], 'six state comparisons')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case', choices=('relay-cpu', 'relay-cuda'))
    parser.add_argument('--runs', type=Path, default=W / 'refinement2/runs')
    options = parser.parse_args()
    audit(options.runs / options.case, options.case.removeprefix('relay-'))
