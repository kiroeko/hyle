"""Two explicit CXX/link actions; every consumer is separately requested."""
from pathlib import Path
import importlib.util
import csv
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OLD = R / '.scratch/inference-mtp-k1-source-20261029'
BASE = OLD / 'model-link-base.json'
HOST_RECIPE = R / '.scratch/inference-successor-ledger-20261027/attempt2/logs/compile/command.json'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
NATURAL = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
SOURCES = {'tiny': R / 'tests/tools/qwen_host_image_test.cc',
           'ledger': R / 'tests/tools/qwen_generation_ledger_test.cc'}
CASES = {'ledger': ('ledger', None, None),
         'natural-cpu': ('tiny', 'cpu', '--mtp-natural-relay'),
         'natural-cuda': ('tiny', 'cuda', '--mtp-natural-relay')}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'natural_existing_recorder')
t.W = W


def prepare():
    base = t.read(BASE); previous_path = Path(base['previous_consumer']['path'])
    previous = t.read(previous_path)
    assert len(base['retained']) == 227
    retained_keys = {t.key(row['path']) for row in base['retained']}
    assert len(retained_keys) == 227
    for row in base['retained']: t.exact(row)
    old_consumers = [arg for arg in base['link'] if arg.lower().endswith('.obj')
                     and t.key(arg) not in retained_keys]
    assert len(old_consumers) == 1
    units = {}
    for name, source in SOURCES.items():
        original = base['compile'] if name == 'tiny' else t.command(HOST_RECIPE)
        compile_args = []
        for index, arg in enumerate(original):
            if index and original[index - 1].lower() == '/sourcedependencies':
                arg = str(W / 'compile' / name / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile' / name / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile' / name / 'unit.pdb')
            compile_args.append(arg)
        if not any(arg.lower().startswith('/fd') for arg in compile_args):
            compile_args.append('/Fd' + str(W / 'compile' / name / 'unit.pdb'))
        assert sum(t.key(arg) == t.key(source) for arg in compile_args) == 1
        link_args = []
        for arg in base['link']:
            if t.key(arg) == t.key(old_consumers[0]): arg = str(W / 'compile' / name / 'unit.obj')
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix)); break
            link_args.append(arg)
        assert sum(t.key(arg) == t.key(W / 'compile' / name / 'unit.obj') for arg in link_args) == 1
        assert all(sum(t.key(arg) == key for arg in link_args) == 1 for key in retained_keys)
        units[name] = dict(source=str(source), compile=compile_args, link=link_args)
    paths = {t.key(t.canonical(row['path'])): str(t.canonical(row['path']))
             for row in previous['project_dependencies']}
    for rel in ('engine/models/qwen35/main.cc', 'engine/models/qwen35/generation_ledger.h',
                'engine/inference/request_loop.h', 'engine/inference/request_wave_execution.h',
                'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_generation_ledger_test.cc',
                'tests/tools/qwen_mtp_natural_relay_case.h'):
        paths[t.key(R / rel)] = str(R / rel)
    env = t.read(OLD / 'refinement3/environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local only. Never print/archive environment values.
    weight_sources = {}
    with (NATURAL / 'weights.tsv').open(encoding='utf-8-sig', newline='') as stream:
        for fields in list(csv.reader(stream, delimiter='\t'))[3:]:
            if not fields: continue
            rank = int(fields[2]); path = Path(fields[3 + rank]).resolve()
            start, length = map(int, fields[4 + rank:6 + rank])
            stat = path.stat()
            assert start >= 0 and length >= 0 and start + length <= stat.st_size
            weight_sources[t.key(path)] = dict(path=str(path), bytes=stat.st_size,
                mtime_ns=stat.st_mtime_ns, file_id=stat.st_ino)
    assert weight_sources
    t.save(W / 'plan.json', dict(base=t.pin(BASE), previous_consumer=t.pin(previous_path),
        host_recipe=t.pin(HOST_RECIPE), units=units, retained=base['retained'], runtime=base['runtime'],
        sources=list(paths.values()), fixture=t.pin(NATURAL / 'weights.tsv'), prompt=t.pin(NATURAL / 'prompt.ids'),
        natural=str(NATURAL), plain=str(PLAIN), local_weight_sources=list(weight_sources.values()),
        local_weight_identity_scope='Existing verified local files: manifest SHA, file identity/size/mtime and all referenced extents; no payload rehash or network.',
        helpers=[t.pin(__file__), t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        cases=CASES, counts=dict(CXX=2, links=2, SDK_CXX=0, NVCC=0, inputs_per_link=228,
                               retained_inputs=227, downloads=0)))
    print('PREPARED ledger/Tiny; two CXX, two links, no execution')


def freeze():
    plan = t.read(W / 'plan.json')
    t.save(W / 'source-freeze.json', [t.pin(path) for path in plan['sources']])
    print('SOURCE FROZEN', len(plan['sources']))


def validate():
    plan = t.read(W / 'plan.json')
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    for row in [plan['base'], plan['previous_consumer'], plan['host_recipe'], *plan['helpers']]: t.exact(row)
    for row in plan['local_weight_sources']:
        stat = Path(row['path']).stat()
        assert (stat.st_size, stat.st_mtime_ns, stat.st_ino) == (row['bytes'], row['mtime_ns'], row['file_id'])
    return plan


def parse_compile(name):
    validate(); process = t.read(W / 'logs' / ('compile-' + name) / 'process.json')
    assert process['exit'] == 0 and process['state'] == 'TERMINAL' and not process['timed_out']
    frozen = {t.key(row['path']): row for row in t.read(W / 'source-freeze.json')}
    actual = [t.pin(path) for path in dict.fromkeys(t.dep_paths(W / 'compile' / name / 'dependencies.json'))]
    project = [row for row in actual if t.project(row['path'])]
    for row in project:
        assert t.key(row['path']) in frozen, ('unfrozen actual dependency', row['path'])
        old = frozen[t.key(row['path'])]
        assert (row['bytes'], row['sha256']) == (old['bytes'], old['sha256'])
    t.save(W / 'compile' / name / 'compiled.json', dict(source=t.pin(SOURCES[name]),
        object=t.pin(W / 'compile' / name / 'unit.obj'), process=process,
        project_dependencies=project, actual_dependencies=actual))
    print('CXX METADATA PASS', name, process['pid'])


def compile(name):
    plan = validate(); (W / 'compile' / name).mkdir(parents=True, exist_ok=False)
    t.execute(plan['units'][name]['compile'], W / 'logs' / ('compile-' + name), 300)
    parse_compile(name)


def link(name):
    plan = validate(); compiled = t.read(W / 'compile' / name / 'compiled.json'); t.exact(compiled['object'])
    for row in plan['retained']: t.exact(row)
    t.exact(plan['runtime']); (W / 'bin').mkdir(exist_ok=True)
    alias = W / 'bin' / Path(plan['runtime']['path']).name
    if alias.exists(): assert alias.samefile(plan['runtime']['path'])
    else: alias.hardlink_to(plan['runtime']['path'])
    process = t.execute(plan['units'][name]['link'], W / 'logs' / ('link-' + name), 240)
    t.save(W / ('ready-' + name + '.json'), dict(image=t.pin(W / 'bin' / (name + '.exe')),
        inputs=plan['retained'] + [compiled['object']], compiled=compiled, process=process,
        runtime=plan['runtime'], source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS', name, process['pid'])


def parse(name):
    unit, backend, _ = CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    assert len(reports) == 1 and reports[0]['status'] == 'PASS'
    report = reports[0]
    if unit == 'ledger': assert report['groups'] == 8 and report['device_execution'] is False
    else:
        assert report['case'] == 'mtp-natural-relay' and report['backend'] == backend
        assert report['quality_claim'] is False and report['performance_claim'] is False
        assert report['natural_RequestLoop'] is True and report['controlled_acceptance'] is False
        assert report['models'] == 1 and report['journeys'] == 2 and report['output_limit'] == 40
        assert report['final_versions'] == 0 and len(report['state_checks']) == 1
        for field in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
            assert report[field] is True, field
        state = report['state_checks'][0]
        assert state['boundary_equal'] and state['numerically_equivalent'] and state['exact_next'] == state['bucket_next']
        assert state['payloads_byte_equal'] == (not state['differences'])
        for diff in state['differences']:
            assert diff['role'] == 3 and diff['nonfinite_differences'] == 0 and 0 <= diff['maximum_absolute'] <= 3e-6
        if backend == 'cuda':
            for field in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                          'deferred_waves', 'reserved_two_grants'): assert report[field] > 0, field
    t.save(out / 'report.json', report); print('PASS', name, 'PID', process['pid'])


def run(name):
    plan = validate(); unit, backend, flag = CASES[name]
    ready = t.read(W / ('ready-' + unit + '.json')); t.exact(ready['image'])
    argv = [ready['image']['path']]
    if backend:
        t.exact(plan['fixture']); t.exact(plan['prompt']); argv += ['--' + backend, plan['natural'], flag]
    t.execute(argv, W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'freeze', 'validate'): globals()[action]()
    elif action in ('compile', 'parse_compile', 'link', 'run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
