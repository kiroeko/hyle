"""Test-only refinement; preserve every initial recipe, freeze and result."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('natural_original_build', ROOT / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.t.W = ROOT / 'refinement3'


def prepare():
    # Add this sidecar's identity before the original exclusive plan write.
    # All original source/SDK recipes and helpers remain pinned unchanged.
    original_save = b.t.save

    def save(path, value):
        if Path(path) == b.W / 'plan.json':
            value['helpers'].append(b.t.pin(__file__))
            value['refinement'] = dict(reason='Release completed model-only publication views after head commit; check exact N1/R1/D2 capacity and reuse successful host ledger test.',
                initial_plan=b.t.pin(ROOT / 'plan.json'),
                initial_source_freeze=b.t.pin(ROOT / 'source-freeze.json'))
        original_save(path, value)

    b.t.save = save
    try: b.prepare()
    finally: b.t.save = original_save


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action in ('freeze', 'validate'): getattr(b, action)()
    elif action in ('compile', 'parse_compile', 'link', 'run', 'parse'):
        getattr(b, action)(sys.argv[2])
    else: raise ValueError(action)
