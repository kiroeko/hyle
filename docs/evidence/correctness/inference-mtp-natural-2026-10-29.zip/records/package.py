"""Offline finite natural-K1 evidence. No build, model, environment or network action."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-mtp-natural-2026-10-29'
spec = importlib.util.spec_from_file_location('natural_archive_recorder',
    R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)


def terminal(directory):
    value = t.read(directory / 'process.json')
    assert value['state'] == 'TERMINAL' and value['exit'] == 0 and not value['timed_out'], directory
    return value


def checked_report(directory):
    process = terminal(directory)
    rows = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
            if line.startswith('{')]
    value = t.read(directory / 'report.json')
    assert rows == [value] and value['status'] == 'PASS', directory
    return process, value


def main(natural_run, natural_ready, ledger_run, engine_run):
    natural_run, ledger_run = (W / natural_run).resolve(), (W / ledger_run).resolve()
    natural_ready = (W / natural_ready).resolve() if natural_ready else natural_run.parents[1] / 'ready-tiny.json'
    assert all(path.is_relative_to(W) for path in (natural_run, natural_ready, ledger_run))
    process, report = checked_report(natural_run)
    ledger_process, ledger_report = checked_report(ledger_run)
    assert ledger_report['groups'] == 8 and ledger_report['device_execution'] is False
    assert report['case'] == 'mtp-natural-relay' and report['backend'] == 'cuda'
    assert report['models'] == 1 and report['journeys'] == 2 and report['output_limit'] == 40
    assert (report['resident_capacity'], report['state_slots'], report['hidden_slots']) == (1, 5, 6)
    assert report['natural_RequestLoop'] is True and report['controlled_acceptance'] is False
    assert report['quality_claim'] is False and report['performance_claim'] is False and report['final_versions'] == 0
    for name in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
        assert report[name] is True, name
    for name in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                 'deferred_waves', 'reserved_two_grants'):
        assert report[name] > 0, name
    assert len(report['state_checks']) == 1 and len(report['ids']) == report['outputs']
    for state in report['state_checks']:
        assert state['boundary_equal'] and state['numerically_equivalent'] and state['exact_next'] == state['bucket_next']
        assert state['payloads_byte_equal'] == (not state['differences'])
        for difference in state['differences']:
            assert difference['role'] == 3 and difference['nonfinite_differences'] == 0
            assert math.isfinite(difference['maximum_absolute']) and 0 <= difference['maximum_absolute'] <= 3e-6
    ready = t.read(natural_ready)
    assert ready['process']['state'] == 'TERMINAL' and ready['process']['exit'] == 0
    assert not ready['process']['timed_out'] and len(ready['inputs']) == 228
    assert t.key(t.command(natural_run / 'command.json')[0]) == t.key(ready['image']['path'])
    winning_plan = t.read(natural_ready.parent / 'plan.json')
    retained = {t.key(row['path']): (row['bytes'], row['sha256']) for row in winning_plan['retained']}
    assert len(retained) == 227
    assert all(retained[t.key(row['path'])] == (row['bytes'], row['sha256'])
               for row in ready['inputs'] if t.key(row['path']) in retained)
    assert sum(t.key(row['path']) in retained for row in ready['inputs']) == 227
    ledger_ready_path = ledger_run.parents[1] / 'ready-ledger.json'
    ledger_ready = t.read(ledger_ready_path)
    assert t.key(t.command(ledger_run / 'command.json')[0]) == t.key(ledger_ready['image']['path'])
    ledger_header = next(row for row in ledger_ready['compiled']['project_dependencies']
                         if Path(row['path']).name == 'generation_ledger.h')
    final_ledger_header = next(row for row in ready['compiled']['project_dependencies']
                               if Path(row['path']).name == 'generation_ledger.h')
    assert (ledger_header['bytes'], ledger_header['sha256']) == (final_ledger_header['bytes'], final_ledger_header['sha256'])
    # Earlier N=4 success is a separate source/image boundary, never the final
    # N=1 result. Its full raw report and actual source pins remain available.
    previous = None
    prior_run = W / 'refinement2/runs/natural-cuda'
    if prior_run != natural_run and (prior_run / 'report.json').is_file():
        prior_process, prior_report = checked_report(prior_run)
        prior_ready_path = prior_run.parents[1] / 'ready-tiny.json'
        prior_ready = t.read(prior_ready_path)
        prior_source = W / 'refinement2-replaced/tests/tools/qwen_mtp_natural_relay_case.h'
        prior_pin = next(row for row in prior_ready['compiled']['project_dependencies']
                         if Path(row['path']).name == prior_source.name)
        body = prior_source.read_bytes()
        assert (len(body), hashlib.sha256(body).hexdigest()) == (prior_pin['bytes'], prior_pin['sha256'])
        assert b'cache::plan(geometry, source.cache_row_bytes, capacity, 4,' in body
        assert t.key(t.command(prior_run / 'command.json')[0]) == t.key(prior_ready['image']['path'])
        previous = dict(scope='Earlier N=4 boundary; not the final N=1 product proof.', resident_capacity=4,
            directory=str(prior_run), process=prior_process, ready=t.pin(prior_ready_path),
            image=prior_ready['image'], consumer_source=prior_pin, report=prior_report)
    entry = None
    entry_run = (W / engine_run).resolve() if engine_run else natural_ready.parent / 'runs/engine-mtp-auto'
    assert entry_run.is_relative_to(W)
    if (entry_run / 'process.json').is_file():
        entry_process = t.read(entry_run / 'process.json')
        if entry_process['exit'] == 0:
            terminal(entry_run)
            entry_report = t.read(entry_run / 'report.json')
            rows = [json.loads(line) for line in (entry_run / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
                    if line.startswith('{')]
            assert rows == [entry_report]
            assert t.key(t.command(entry_run / 'command.json')[0]) == t.key(ready['image']['path'])
            assert entry_report['mtp'] is True and entry_report['decode_overlap'] is True
            assert entry_report['decode_overlap_available'] is True and entry_report['max_sessions'] == 1
            assert entry_report['active_sequences'] == 1 and entry_report['live_committed_versions'] == 0
            assert entry_report['overlap_successor_submissions'] > 0 and entry_report['overlap_successor_publications'] > 0
            entry = dict(directory=str(entry_run), process=entry_process, image=ready['image'], report=entry_report)
        else:
            assert engine_run is None, ('Explicit engine run did not succeed', entry_run)
    def cli_summary(directory, mtp):
        terminal(directory)
        value = t.read(directory / 'report.json')
        rows = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
                if line.startswith('{')]
        assert rows == [value] and t.key(t.command(directory / 'command.json')[0]) == t.key(ready['image']['path'])
        assert value['mtp'] is mtp and value['backend'] == 'cuda' and value['generated_tokens'] == 40
        assert value['decode_overlap'] is True and value['decode_overlap_available'] is True
        assert value['max_sessions'] == 1 and value['active_sequences'] == 1 and value['live_committed_versions'] == 0
        assert value['overlap_successor_submissions'] > 0 and value['overlap_successor_publications'] > 0
        fields = ('mtp', 'backend', 'generated_tokens', 'max_sessions', 'active_sequences', 'live_committed_versions',
            'decode_overlap', 'decode_overlap_available', 'overlap_successor_submissions',
            'overlap_successor_publications', 'overlap_successor_discards', 'overlap_successor_refusals')
        return dict(directory=str(directory), process=terminal(directory), image=ready['image'],
            report_member='records/' + (directory / 'report.json').relative_to(W).as_posix(),
            facts={field: value[field] for field in fields})
    if entry: entry = cli_summary(entry_run, True)
    text_run = natural_ready.parent / 'runs/engine-text-auto'
    text_entry = cli_summary(text_run, False) if (text_run / 'process.json').is_file() else None
    relay_run = natural_ready.parent / 'runs/relay-regression'
    relay, relay_plan = None, None
    if (relay_run / 'process.json').is_file():
        relay_process, relay_report = checked_report(relay_run)
        assert t.key(t.command(relay_run / 'command.json')[0]) == t.key(ready['image']['path'])
        relay_plan = t.read(natural_ready.parent / 'relay-regression-plan.json')
        assert relay_plan['image'] == ready['image']
        t.exact(relay_plan['auditor'])
        spec = importlib.util.spec_from_file_location('natural_prior_source_audit', relay_plan['auditor']['path'])
        auditor = importlib.util.module_from_spec(spec); spec.loader.exec_module(auditor)
        assert auditor.check_report(relay_report, 'cuda') == relay_report
        audit = t.read(relay_run / 'audit-result.json')
        assert audit['status'] == 'PASS_OFFLINE_REPORT_AUDIT' and audit['process'] == relay_process
        assert audit['state_comparisons'] == len(relay_report['state_checks']) == 6
        assert audit['byte_exact_state_comparisons'] == sum(row['payloads_byte_equal'] for row in relay_report['state_checks'])
        relay = dict(directory=str(relay_run), process=relay_process, image=ready['image'], audit=audit,
            report_member='records/' + (relay_run / 'report.json').relative_to(W).as_posix(),
            auditor=relay_plan['auditor'])
    members, sources, compiles, processes = {}, [], [], []
    text_types = {'.json', '.log', '.py', '.patch', '.xml', '.txt', '.md', '.d'}
    source_types = {'.h', '.hh', '.hpp', '.c', '.cc', '.cpp', '.cu', '.cuh', '.py'}

    def add(path, name, row=None):
        path = Path(path).resolve()
        assert path.is_file() and path.suffix.lower() in text_types | source_types | {'.tsv', '.ids'}, path
        assert not (path.suffix.lower() == '.json' and ('environment' in path.name.lower() or path.name.lower() == 'env.json')), path
        body = path.read_bytes()
        if row: assert (len(body), hashlib.sha256(body).hexdigest()) == (row['bytes'], row['sha256']), path
        assert name not in members or members[name] == body, name
        members[name] = body
        return name

    # Enumerate only this batch, not historical SDK/cache trees. Environments
    # and every executable/object/library/model payload are excluded by suffix.
    metadata = sorted(path for path in W.rglob('*') if path.is_file() and
                      path.suffix.lower() in text_types and 'environment' not in path.name.lower()
                      and path.name.lower() != 'env.json')
    bodies = [path for path in W.rglob('*') if path.is_file() and path.suffix.lower() in source_types]
    cached = {}

    def source(row, receipt):
        original = Path(row['path'])
        if not original.is_absolute(): original = R / original
        cache_key = (row['bytes'], row['sha256'])
        if cache_key not in cached:
            found = None
            for candidate in [original, *bodies]:
                if not candidate.is_file() or candidate.stat().st_size != row['bytes']: continue
                if hashlib.sha256(candidate.read_bytes()).hexdigest() == row['sha256']:
                    found = candidate; break
            assert found is not None, ('Missing exact historical source/helper body', row, receipt)
            cached[cache_key] = add(found, 'sources/' + row['sha256'] + '/' + original.name, row)
        sources.append(dict(original=str(original), receipt=receipt, pin=row, member=cached[cache_key]))

    for path in metadata:
        relative = path.relative_to(W).as_posix()
        add(path, 'records/' + relative)
        if path.name == 'process.json':
            value = t.read(path)
            assert value['state'] == 'TERMINAL', relative
            kind = ('CXX' if path.parent.name.startswith('compile-') else
                    'link' if path.parent.name.startswith('link-') else
                    'native' if 'runs' in path.relative_to(W).parts else 'tooling')
            processes.append(dict(record=relative, kind=kind, **value))
        if path.name == 'source-freeze.json':
            for row in t.read(path): source(row, relative)
        if path.name == 'plan.json':
            plan = t.read(path)
            for row in plan.get('helpers', []): source(row, relative)
            for field in ('base', 'previous_consumer', 'host_recipe'):
                row = plan.get(field)
                if row: add(row['path'], 'referenced/' + row['sha256'] + '/' + Path(row['path']).name, row)
        if path.name == 'compiled.json':
            value = t.read(path)
            for row in value['project_dependencies']: source(row, relative)
            compiles.append(dict(receipt=relative, process=value['process'], source=value['source'],
                object=value['object'], project_dependencies=len(value['project_dependencies'])))
            frozen = {t.key(t.canonical(row['path'])): (row['bytes'], row['sha256'])
                      for row in t.read(path.parents[2] / 'source-freeze.json')}
            for row in value['project_dependencies']:
                assert frozen[t.key(t.canonical(row['path']))] == (row['bytes'], row['sha256']), row
    for path in bodies:
        if path.suffix.lower() != '.py': source(t.pin(path), path.relative_to(W).as_posix())
    for label, row in (('real/weights.tsv', winning_plan['fixture']), ('real/prompt.ids', winning_plan['prompt'])):
        add(row['path'], 'fixtures/' + label, row)
    if relay_plan:
        for label, field in (('tiny/weights.tsv', 'fixture'), ('tiny/prompt.ids', 'prompt')):
            add(relay_plan[field]['path'], 'fixtures/' + label, relay_plan[field])
        source(relay_plan['auditor'], 'refinement3/relay-regression-plan.json')
    product = [row for row in ready['compiled']['project_dependencies'] if
               Path(row['path']).name in ('main.cc', 'generation_ledger.h')]
    assert {Path(row['path']).name for row in product} == {'main.cc', 'generation_ledger.h'}
    fixture = dict(weights_manifest=winning_plan['fixture'], prompt=winning_plan['prompt'],
        local_weight_sources=winning_plan['local_weight_sources'], scope=winning_plan['local_weight_identity_scope'])
    manifest = dict(schema='hyle.inference-mtp-natural.archive.v1', source_index=sources,
        compiled=compiles, processes=processes,
        members={name: dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
                 for name, body in sorted(members.items())})
    members['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    DEST.parent.mkdir(parents=True, exist_ok=True)
    archive = DEST.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, body in sorted(members.items()): output.writestr(name, body)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(members)
        for name, body in members.items():
            actual = check.read(name)
            assert len(actual) == len(body) and hashlib.sha256(actual).digest() == hashlib.sha256(body).digest(), name
    compact = dict(schema='hyle.inference-mtp-natural.v1', status='PASS_FINITE_NATURAL_K1_SOURCE',
        product_sources=product, fixture=fixture, natural_run=dict(directory=str(natural_run), process=process,
            ready=t.pin(natural_ready), image=ready['image'], report=report),
        prior_roomy_resident_boundary=previous, real_engine_entry=entry, ordinary_engine_entry=text_entry,
        source_lifetime_regression=relay,
        latest_state_comparisons=dict(natural=len(report['state_checks']),
            source_regression=relay['audit']['state_comparisons'] if relay else 0,
            total=len(report['state_checks']) + (relay['audit']['state_comparisons'] if relay else 0),
            byte_exact=sum(row['payloads_byte_equal'] for row in report['state_checks']) +
                (relay['audit']['byte_exact_state_comparisons'] if relay else 0),
            earlier_N4_separate=len(previous['report']['state_checks']) if previous else 0),
        ledger_host=dict(directory=str(ledger_run), process=ledger_process, report=ledger_report,
            ready=t.pin(ledger_ready_path), image=ledger_ready['image'], product_header=ledger_header),
        actual_process_counts={kind: dict(total=sum(p['kind'] == kind for p in processes),
            passed=sum(p['kind'] == kind and p['exit'] == 0 for p in processes),
            failed=sum(p['kind'] == kind and p['exit'] != 0 for p in processes))
            for kind in ('CXX', 'link', 'native', 'tooling')},
        preserved_failures=[p for p in processes if p['exit'] != 0],
        sdk=dict(retained_inputs=227, source_cxx=0, nvcc=0,
            identity='Prior immutable SDK/weights object pins only; consumer source closure is separately content-addressed. No binary payload rehash/copy.'),
        limits=['Final CUDA real cached prompt: serial/automatic natural greedy RequestLoop, K1/R1, N=1, state slots=5, hidden slots=6.',
            'The earlier N=4 success uses its own older product/test image and does not replace final N=1 validation.',
            'Current real MTP/ordinary CLI and synthetic Source regression are separately identified on the final image.',
            'One final complete state comparison, with the existing F32 GDN 3e-6 budget; other payloads/metadata exact.',
            'Eight host ledger groups are independent of device execution. All failed compilation/test attempts remain archived.',
            'No simultaneous native-inflight, quality, speed, full device acceptance, general pipeline or other-platform conclusion.',
            'Only small real/tiny weight manifests, prompt IDs and frozen project sources/headers are archived; no referenced tensors, SDK objects/libraries, binary or environment.'],
        archive=t.pin(archive), archive_members=len(members), crc_and_member_sha256_readback=True)
    t.save(DEST.with_suffix('.json'), compact)
    print('ARCHIVE WRITTEN', archive.name, compact['archive']['bytes'], compact['archive']['sha256'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--natural-run', required=True)
    parser.add_argument('--natural-ready')
    parser.add_argument('--ledger-run', default='refinement/runs/ledger')
    parser.add_argument('--engine-run', help='Optional explicit successful real engine-entry run, on the final ready image.')
    args = parser.parse_args()
    main(args.natural_run, args.natural_ready, args.ledger_run, args.engine_run)
