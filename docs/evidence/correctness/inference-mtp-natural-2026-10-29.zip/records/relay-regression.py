"""Explicit finite lifetime regression after publication-view retirement."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('natural_regression',ROOT/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=b.t.W=ROOT/'refinement3'
W=b.W
spec=importlib.util.spec_from_file_location('previous_relay_auditor',ROOT.parent/'inference-mtp-k1-source-20261029/audit_reports.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

def run():
    b.validate();ready=b.t.read(W/'ready-tiny.json');b.t.exact(ready['image'])
    plan=dict(image=ready['image'],fixture=b.t.pin(b.PLAIN/'weights.tsv'),prompt=b.t.pin(b.PLAIN/'prompt.ids'),
        source_freeze=b.t.pin(W/'source-freeze.json'),auditor=b.t.pin(ROOT.parent/'inference-mtp-k1-source-20261029/audit_reports.py'))
    b.t.save(W/'relay-regression-plan.json',plan)
    b.t.execute([ready['image']['path'],'--cuda',str(b.PLAIN),'--mtp-relay'],W/'runs/relay-regression',300)
    parse()

def parse():
    out=W/'runs/relay-regression';p=b.t.read(out/'process.json')
    assert p['state']=='TERMINAL' and p['exit']==0 and not p['timed_out']
    reports=[json.loads(x) for x in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if x.startswith('{')]
    assert len(reports)==1
    report=a.check_report(reports[0],'cuda');b.t.save(out/'report.json',report)
    a.audit(out,'cuda')
    print('SOURCE LIFETIME REGRESSION PASS PID',p['pid'])

if __name__=='__main__':
    if sys.argv[1]=='run':run()
    elif sys.argv[1]=='parse':parse()
    else:raise SystemExit(sys.argv[1])
