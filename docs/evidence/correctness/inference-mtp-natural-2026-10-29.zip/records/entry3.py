"""Explicit current engine entry check; no rebuild or automatic rerun."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('natural_entry',ROOT/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=b.t.W=ROOT/'refinement3'
W=b.W

def run():
    plan=b.validate();ready=b.t.read(W/'ready-tiny.json');b.t.exact(ready['image'])
    b.t.exact(plan['fixture']);b.t.exact(plan['prompt'])
    args=[ready['image']['path'],'--engine','--inputs',str(b.NATURAL),'--steps','40','--capacity','256',
        '--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct',
        '--replay','auto','--mtp','on','--backend','cuda','--sampling','greedy']
    b.t.execute(args,W/'runs/engine-mtp-auto',300)
    parse()

def parse():
    out=W/'runs/engine-mtp-auto';proc=b.t.read(out/'process.json')
    assert proc['state']=='TERMINAL' and proc['exit']==0 and not proc['timed_out'],proc
    rows=[json.loads(x) for x in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if x.startswith('{')]
    assert len(rows)==1
    report=rows[0]
    assert report['decode_overlap'] is True and report['decode_overlap_available'] is True
    assert report['overlap_successor_submissions']>0 and report['overlap_successor_publications']>0
    b.t.save(out/'report.json',report)
    print('ENGINE DEFAULT MTP AUTO PASS PID',proc['pid'])

if __name__=='__main__':
    action=sys.argv[1]
    if action=='run':run()
    elif action=='parse':parse()
    else:raise SystemExit(action)
