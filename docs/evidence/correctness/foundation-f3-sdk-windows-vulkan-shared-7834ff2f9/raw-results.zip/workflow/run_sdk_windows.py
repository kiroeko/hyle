from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys

repo = Path.cwd(); profile, mode = sys.argv[1:]
assert profile in ['cpu-cuda', 'vulkan'] and mode in ['static', 'shared']
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'])
assert not subprocess.check_output(['git', 'diff', '--name-only', '97858fbc88a6b5a87f109290b956eeaeee632dd2', 'HEAD', '--', 'src', 'include', 'cmake', 'CMakeLists.txt'])
routes = 'cpu;cuda' if profile == 'cpu-cuda' else 'vulkan'
if profile == 'cpu-cuda' and mode == 'static':
    producer = Path('C:/h7/w-cpu-cuda/selected-graph/source-build'); producer_source = producer.parent / 'source-parent'
else:
    producer = Path('C:/h7/' + ('w-cuda' if profile == 'cpu-cuda' else 'w-vulkan') + '/selected-graph/' + mode + '-sdk-build')
    producer_source = repo
cache = (producer / 'CMakeCache.txt').read_text()
assert 'HYLE_STATIC:BOOL=' + ('ON' if mode == 'static' else 'OFF') in cache
if profile == 'cpu-cuda' and mode == 'static':
    parent_text = (producer_source / 'CMakeLists.txt').read_text()
    assert 'set(HYLE_BUILD_TESTS OFF)' in parent_text and 'set(HYLE_INSTALL ON)' in parent_text
else:
    assert 'HYLE_BUILD_TESTS:BOOL=OFF' in cache and 'HYLE_INSTALL:BOOL=ON' in cache
workspace = Path('C:/h7/foundation-f3-sdk'); workspace.mkdir(exist_ok=True)
root = workspace / ('windows-' + profile + '-' + mode + '-' + candidate[:9]); assert not root.exists(); root.mkdir()
stage, prefix, consumer = [root / name for name in ['staging', 'relocated', 'consumer']]
logs = repo / '.scratch/foundation-f3' / ('sdk-windows-' + profile + '-' + mode + '-' + candidate[:9]); assert not logs.exists(); logs.mkdir()
spec = importlib.util.spec_from_file_location('header_env', repo / 'scripts/header-self-contained.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
compiler = 'C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'
env = module.visual_studio_environment('', 'x64', '', compiler); env['VSLANG'] = '1033'
env['CUDA_PATH'] = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3'
env['VULKAN_SDK'] = 'C:/public/tools/hyle-vulkan/1.4.357.0'
env['PATH'] = env['VULKAN_SDK'] + '/Bin;C:/public/tools/glslang/bin;' + env['CUDA_PATH'] + '/bin;' + env['PATH']
cmake = shutil.which('cmake', path=env['PATH'])
record = {'candidate': candidate, 'product_commit': '97858fbc88a6b5a87f109290b956eeaeee632dd2',
          'profile': profile, 'mode': mode, 'routes': routes, 'producer': str(producer),
          'scope': 'F3 installed relocated ordinary Graph file/math/Qwen consumer plus changed ON/OFF headers only',
          'compiler': compiler, 'parallel': 1, 'stages': []}
class MemoryStatus(ctypes.Structure):
    _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [(str(i), ctypes.c_ulonglong) for i in range(7)]
def run(name, command, timeout=300, expected_failure=False):
    memory = MemoryStatus(); memory.length = ctypes.sizeof(memory)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)); available = getattr(memory, '1')
    assert available >= 4 * 1024**3
    if '--parallel' in command:
        parallel = 4 if available >= 12 * 1024**3 else 2 if available >= 8 * 1024**3 else 1
        command = list(command); command[command.index('--parallel') + 1] = str(parallel)
        record['parallel'] = parallel; record['test_parallel'] = 1
    runtime = env.copy()
    if name in ['math', 'qwen']: runtime['PATH'] = str(consumer) + ';C:/Windows/System32;C:/Windows'
    log = logs / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=repo, env=runtime, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'available_bytes': available, 'log': log.name}
        record['stages'].append(row); (logs / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            process.wait(); row.update(state='terminal', verdict='TIMEOUT')
            (logs / 'job.json').write_text(json.dumps(record, indent=2)); raise
        passed = code != 0 if expected_failure else code == 0
        row.update(state='terminal', exit_code=code, verdict=('PASS_EXPECTED_ABSENT' if expected_failure else 'PASS') if passed else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (logs / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if not passed: raise SystemExit(code or 1)
    return log.read_text(encoding='utf-8', errors='replace')
run('identity', ['nvidia-smi', '--query-gpu=name,uuid,driver_version', '--format=csv,noheader'], 30)
run('configure', [cmake, '-S', str(producer_source), '-B', str(producer)])
build = [cmake, '--build', str(producer), '--parallel', '1']
if profile == 'cpu-cuda' and mode == 'static': build += ['--target', 'hyle_f3_file_streaming', 'hyle_f3_qwen_file_streaming']
run('producer', build, 1800)
if profile == 'cpu-cuda' and mode == 'static':
    run('source-math', [str(producer / 'hyle_f3_file_streaming.exe'), str(repo / '.scratch/foundation-f3/gguf-consumer-input/gguf-ranges.tsv')], 180)
    run('source-qwen', [str(producer / 'hyle_f3_qwen_file_streaming.exe'), str(repo / '.scratch/foundation-f3/qwen-consumer-input/ranges.tsv')], 180)
run('install', [cmake, '--install', str(producer), '--prefix', str(stage)], 600)
for path in [stage, prefix]: assert path.resolve().parent == root.resolve() and path.resolve().is_relative_to(workspace.resolve())
assert stage.exists() and not prefix.exists(); stage.rename(prefix)
for path in (prefix / 'lib/cmake/Hyle').rglob('*.cmake'):
    text = path.read_text().replace('\\', '/')
    assert all(str(value).replace('\\', '/') not in text for value in [repo, producer, stage]), path
record['relocation'] = {'original': str(stage), 'relocated': str(prefix), 'original_absent': not stage.exists(), 'Hyle_metadata_no_source_build_staging_paths': True}
run('consumer-configure', [cmake, '-S', str(repo / 'samples/package/graph/file_streaming'), '-B', str(consumer), '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=' + compiler, '-DCMAKE_PREFIX_PATH=' + str(prefix),
    '-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1', '-DHYLE_COMPUTE_ROUTES=' + routes])
run('consumer-build', [cmake, '--build', str(consumer), '--parallel', '1'], 1800)
record['runtime_dlls'] = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in consumer.glob('*.dll')}
dumpbin = str(Path(compiler).parent / 'dumpbin.exe')
for target in ['hyle_file_streaming_sample', 'hyle_file_streaming_qwen']:
    run('imports-' + target, [dumpbin, '/DEPENDENTS', str(consumer / (target + '.exe'))], 30)
if mode == 'shared':
    assert 'hyle_compute_stream.dll' in record['runtime_dlls']
run('math', [str(consumer / 'hyle_file_streaming_sample.exe'), str(repo / '.scratch/foundation-f3/gguf-consumer-input/gguf-ranges.tsv')], 180)
run('qwen', [str(consumer / 'hyle_file_streaming_qwen.exe'), str(repo / '.scratch/foundation-f3/qwen-consumer-input/ranges.tsv')], 180)
route_headers = {'cpu': 'cpu.h', 'cuda': 'backends/cuda.h', 'apple': 'apple_memory.h', 'vulkan': 'vulkan_memory.h'}
selected_routes = routes.split(';')
headers = ['file_stream.h', 'detail/file_stream_access.h', 'detail/file_stream_copy.h', 'detail/copy_stream_access.h',
           'detail/lease_access.h'] + [route_headers[name] for name in selected_routes]
parent = root / 'headers'; parent.mkdir()
files = []
for index, header in enumerate(headers):
    path = parent / ('header-' + str(index) + '.cc'); path.write_text('#include <hyle/compute/' + header + '>\n')
    files.append('"' + path.as_posix() + '"')
(parent / 'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.25)\nproject(hyle_f3_headers LANGUAGES CXX)\n'
    'set(HYLE_COMPUTE_ROUTES "' + routes + '")\nfind_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)\n'
    'add_library(headers OBJECT ' + ' '.join(files) + ')\ntarget_link_libraries(headers PRIVATE hyle::graph)\n')
header_build = root / 'header-build'
run('headers-configure', [cmake, '-S', str(parent), '-B', str(header_build), '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
    '-DCMAKE_CXX_COMPILER=' + compiler, '-DCMAKE_PREFIX_PATH=' + str(prefix), '-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1'])
run('headers-build', [cmake, '--build', str(header_build), '--parallel', '1'], 300)
record['header_scope'] = {'count': len(headers), 'CUDA': 'ON' if profile == 'cpu-cuda' else 'OFF', 'Apple': 'OFF', 'Vulkan': 'ON' if profile == 'vulkan' else 'OFF', 'source_include_directory_requested': False}
for route, header in route_headers.items():
    if route in selected_routes: continue
    assert not (prefix / 'include/hyle/compute' / header).exists()
    probe = root / ('absence-' + route); probe.mkdir()
    (probe / 'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.25)\nproject(hyle_absence LANGUAGES CXX)\n'
        'set(HYLE_COMPUTE_ROUTES "' + route + '")\nfind_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)\n')
    output = run('absence-route-' + route, [cmake, '-S', str(probe), '-B', str(root / ('absence-build-' + route)), '-G', 'Ninja',
        '-DCMAKE_CXX_COMPILER=' + compiler, '-DCMAKE_PREFIX_PATH=' + str(prefix), '-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1'], 300, True)
    assert "does not contain requested compute route '" + route + "'" in ' '.join(output.lower().split())
record['absent_headers_and_route_diagnostics'] = [name for name in route_headers if name not in selected_routes]
record['verdict'] = 'PASS_WINDOWS_F3_' + profile.upper().replace('-', '_') + '_' + mode.upper() + '_RELOCATED_SDK_ONLY'
(logs / 'job.json').write_text(json.dumps(record, indent=2)); print(str(logs), flush=True)
