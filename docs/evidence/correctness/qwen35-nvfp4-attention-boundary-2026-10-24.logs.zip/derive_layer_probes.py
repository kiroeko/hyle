"""Derive diagnostics from an explicitly frozen engine source, no product edits."""
from pathlib import Path
import hashlib,json,re,sys
if len(sys.argv)!=4:raise SystemExit('usage: derive_layer_probes.py FROZEN_MAIN EXPECTED_SHA256 OUTPUT_MAIN')
source=Path(sys.argv[1]);expected=sys.argv[2];output=Path(sys.argv[3]);raw=source.read_bytes()
if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('frozen source identity differs')
text=raw.decode('utf8').replace('\r\n','\n')
def exactly(old,new):
 global text
 if text.count(old)!=1:raise RuntimeError('source anchor count differs: '+old[:120])
 text=text.replace(old,new)
match=re.search(r'constexpr std::array<const char \*, 9> layer0_probe_names\{.*?\};',text,re.S)
if not match:raise RuntimeError('probe name declaration absent')
names=['00-embedding']+[f'{i+1:02d}-layer-{i:02d}-output' for i in range(24)]
exactly(match.group(), 'constexpr std::array<const char *, 25> layer0_probe_names{\n    '+',\n    '.join('"'+s+'"' for s in names)+'};')
for old,new in [('std::array<V, 9> probe_ports','std::array<V, 25> probe_ports'),
 ('std::array<Tensor, 9> probe_outputs','std::array<Tensor, 25> probe_outputs'),
 ('std::array<bool, 9> probe_caller','std::array<bool, 25> probe_caller'),
 ('std::array<c::ConstTensorView, 9> probe_views','std::array<c::ConstTensorView, 25> probe_views'),
 ('std::array<c::ReadLease, 9> probe_owners','std::array<c::ReadLease, 25> probe_owners')]:exactly(old,new)
for line in ['        if (i == 0) definition.probe_ports[0] = y;\n',
 '        if (i == 0) definition.probe_ports[1] = y; // Same BF16 payload before its metadata-only out_proj reshape.\n',
 '        if (i == 0) definition.probe_ports[2] = mixed;\n']:exactly(line,'')
exactly('      x = r.ffn(r.binary(c::BinaryKind::kAdd, x, mixed), prefix,\n                i == 0 ? std::span<V>(definition.probe_ports) : std::span<V>{});\n      if (i == 0) definition.probe_ports[4] = x;',
 '      x = r.ffn(r.binary(c::BinaryKind::kAdd, x, mixed), prefix);\n      definition.probe_ports[i + 1] = x;')
exactly('    // Writer-only draft maintenance has no attention data edge into target.',
 '    definition.probe_ports[0] = x;\n    // Writer-only draft maintenance has no attention data edge into target.')
if re.search(r'array<[^;\n]+, 9> probe_',text):raise RuntimeError('unconverted probe array')
output.parent.mkdir(exist_ok=True,parents=True);output.write_text(text,encoding='utf8',newline='\n')
record=dict(original=dict(path=str(source),bytes=len(raw),sha256=expected),derived=dict(path=str(output),bytes=output.stat().st_size,
 sha256=hashlib.sha256(output.read_bytes()).hexdigest()),purpose='Only existing diagnostic publication points changed: embedding and24 BF16 layer exits; no copied model math.',
 diagnostic_tensor_bytes_per_backend_P15=25*15*2048*2,product_source_modified=False,performance_claim=False)
output.with_suffix('.source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
