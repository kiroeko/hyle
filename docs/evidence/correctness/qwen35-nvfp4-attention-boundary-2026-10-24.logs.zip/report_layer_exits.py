from pathlib import Path
import hashlib,json
import numpy as np
R=Path.cwd();W=Path(__file__).resolve().parent/'layer-exits';Q=W.parents[1]
def comp(a,b,dtype='<u2'):
 aa=np.fromfile(a,dtype=dtype);bb=np.fromfile(b,dtype=dtype)
 if aa.size!=bb.size:raise RuntimeError('lengths differ '+str(a))
 rawdifferent=aa!=bb
 av=(aa.astype('u4')<<16).view('f4') if dtype=='<u2' else aa
 bv=(bb.astype('u4')<<16).view('f4') if dtype=='<u2' else bb
 delta=av.astype('f8')-bv;indices=np.flatnonzero(rawdifferent)
 return dict(elements=int(aa.size),different=int(indices.size),finite=bool(np.isfinite(av).all() and np.isfinite(bv).all()),
  max_absolute=float(abs(delta).max()),rms=float(np.sqrt(np.mean(delta*delta))),
  first_differences=[dict(index=int(i),left=float(av[i]),right=float(bv[i])) for i in indices[:8]],
  left_sha256=hashlib.sha256(Path(a).read_bytes()).hexdigest(),right_sha256=hashlib.sha256(Path(b).read_bytes()).hexdigest())
same=[];source=[]
for backend in ('cpu','cuda'):
 for name,dtype in [('logits.f32','<f4'),('hidden.bf16','<u2')]:
  ordinary=W/(backend+'-ordinary')/'trace/prefill'/name
  probe=W/(backend+'-probe')/'trace/prefill'/name
  same.append(dict(backend=backend,boundary=name,**comp(ordinary,probe,dtype)))
  old=Q/'engine-check'/('Q03-P15-'+backend+'-numerics')/'trace/prefill'/name
  source.append(dict(backend=backend,boundary=name,**comp(old,ordinary,dtype)))
names=['00-embedding']+[f'{i+1:02d}-layer-{i:02d}-output' for i in range(24)]
layers=[]
for name in names:
 result=comp(W/'cpu-probe/probe/prefill'/(name+'.bf16'),W/'cuda-probe/probe/prefill'/(name+'.bf16'))
 if result['elements']!=15*2048:raise RuntimeError('unexpected P15 layer extent')
 layers.append(dict(boundary=name,**result))
result=dict(scope='Same frozen model source, same original Q03 weights and P15, ordinary MTPoff; diagnostic cold publications only',
 probe_does_not_change_same_version_final_outputs=all(x['different']==0 for x in same),same_version_probe_effect=same,
 current_no_probe_vs_presampling_reference=source,layer_exits=layers,
 first_different_layer_exit=next((x['boundary'] for x in layers if x['different']),None),
 cross_backend_final_logits=comp(W/'cpu-probe/trace/prefill/logits.f32',W/'cuda-probe/trace/prefill/logits.f32','<f4'),
 downloads=0,SDK_builds=0,fresh_consumer_TUs=2,performance_claim=False,quality_claim=False)
(W/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PROBE NUMERICALLY NEUTRAL',result['probe_does_not_change_same_version_final_outputs'])
for row in same:print('SAME-VERSION',row['backend'],row['boundary'],row['different'],'different')
for row in source:print('OLD-SOURCE',row['backend'],row['boundary'],row['different'],'different')
for row in layers:print(row['boundary'],'different',row['different'],'RMS',row['rms'],'max',row['max_absolute'])
print('FIRST',result['first_different_layer_exit']);print('LOGITS',result['cross_backend_final_logits'])
