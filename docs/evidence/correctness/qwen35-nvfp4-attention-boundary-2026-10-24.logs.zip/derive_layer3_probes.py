"""L3 publication-only derivation from frozen original source; no math copied."""
from pathlib import Path
import hashlib,json,re,sys
if len(sys.argv)!=4:raise SystemExit('usage: derive_layer3_probes.py FROZEN_MAIN SHA OUTPUT')
source=Path(sys.argv[1]);sha=sys.argv[2];output=Path(sys.argv[3]);raw=source.read_bytes()
if hashlib.sha256(raw).hexdigest()!=sha:raise RuntimeError('frozen source identity')
text=raw.decode('utf8').replace('\r\n','\n')
def exactly(old,new):
 global text
 if text.count(old)!=1:raise RuntimeError('anchor count: '+old[:100])
 text=text.replace(old,new)
names=['00-l2-output','01-l3-input-norm','02-q-projection','03-k-projection','04-v-projection','05-q-norm','06-k-norm',
 '07-q-rope','08-k-rope','09-attention','10-gated-attention','11-o-projection','12-post-attn-residual','13-post-attn-norm',
 '14-gate-projection','15-up-projection','16-down-input','17-l3-output']
match=re.search(r'constexpr std::array<const char \*, 9> layer0_probe_names\{.*?\};',text,re.S)
if not match:raise RuntimeError('name anchor')
exactly(match.group(),'constexpr std::array<const char *, 18> layer0_probe_names{\n    '+',\n    '.join('"'+s+'"' for s in names)+'};')
for name in ('V','Tensor','bool','c::ConstTensorView','c::ReadLease'):
 suffix={'V':'probe_ports','Tensor':'probe_outputs','bool':'probe_caller','c::ConstTensorView':'probe_views','c::ReadLease':'probe_owners'}[name]
 exactly(f'std::array<{name}, 9> '+suffix,f'std::array<{name}, 18> '+suffix)
for line in ['        if (i == 0) definition.probe_ports[0] = y;\n',
 '        if (i == 0) definition.probe_ports[1] = y; // Same BF16 payload before its metadata-only out_proj reshape.\n',
 '        if (i == 0) definition.probe_ports[2] = mixed;\n']:exactly(line,'')
exactly('      auto normalized = r.norm(x, prefix + "input_layernorm.weight");',
 '      auto normalized = r.norm(x, prefix + "input_layernorm.weight");\n      if (i == 3) definition.probe_ports[1] = normalized;')
exactly('        auto projected = r.reshape(r.linear(normalized, prefix + "self_attn.q_proj.weight"), {batch, t, f(8), f(512)});',
 '        auto q_projected = r.linear(normalized, prefix + "self_attn.q_proj.weight");\n        auto projected = r.reshape(q_projected, {batch, t, f(8), f(512)});\n        if (i == 3) definition.probe_ports[2] = q_projected;')
exactly('        auto k = r.norm(r.reshape(r.linear(normalized, prefix + "self_attn.k_proj.weight"), {batch, t, f(2), f(256)}), prefix + "self_attn.k_norm.weight");',
 '        auto k_projected = r.linear(normalized, prefix + "self_attn.k_proj.weight");\n        auto k = r.norm(r.reshape(k_projected, {batch, t, f(2), f(256)}), prefix + "self_attn.k_norm.weight");\n        if (i == 3) definition.probe_ports[3] = k_projected;')
exactly('        auto v = r.linear(normalized, prefix + "self_attn.v_proj.weight");',
 '        auto v = r.linear(normalized, prefix + "self_attn.v_proj.weight");\n        if (i == 3) { definition.probe_ports[4] = v; definition.probe_ports[5] = q; definition.probe_ports[6] = k; }')
exactly('        k = r.same(rope, {k, definition.position_port, frequencies}, k);',
 '        k = r.same(rope, {k, definition.position_port, frequencies}, k);\n        if (i == 3) { definition.probe_ports[7] = q; definition.probe_ports[8] = k; }')
exactly('        check(r.builder.depends_on(definition.attention_nodes[layer], value_append));',
 '        check(r.builder.depends_on(definition.attention_nodes[layer], value_append));\n        if (i == 3) definition.probe_ports[9] = attention;')
exactly('        mixed = r.linear(gated, prefix + "self_attn.o_proj.weight");',
 '        mixed = r.linear(gated, prefix + "self_attn.o_proj.weight");\n        if (i == 3) { definition.probe_ports[10] = gated; definition.probe_ports[11] = mixed; }')
exactly('      probes[3] = product; probes[5] = x; probes[6] = normalized;\n      probes[7] = projected_gate; probes[8] = up;',
 '      probes[16] = product; probes[12] = x; probes[13] = normalized;\n      probes[14] = projected_gate; probes[15] = up;')
exactly('                i == 0 ? std::span<V>(definition.probe_ports) : std::span<V>{});\n      if (i == 0) definition.probe_ports[4] = x;',
 '                i == 3 ? std::span<V>(definition.probe_ports) : std::span<V>{});\n      if (i == 2) definition.probe_ports[0] = x;\n      if (i == 3) definition.probe_ports[17] = x;')
output.parent.mkdir(exist_ok=True,parents=True);output.write_text(text,encoding='utf8',newline='\n')
output.with_suffix('.source.json').write_text(json.dumps(dict(original_sha256=sha,derived_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
 scope='Original frozen model math; only18 BF16 L3 publication ports. K projection expression factored into a local variable without new operations.',
 names=names,product_source_modified=False),indent=2)+'\n')
print('Derived18 L3 cuts from frozen original',sha,flush=True)
