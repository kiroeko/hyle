from pathlib import Path
import hashlib,json,sys
import numpy as np
R=Path.cwd();W=Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else 'layer3-cuts');B=W.parent/'layer-exits'
def comp(a,b,dtype='<u2'):
 aa=np.fromfile(a,dtype=dtype);bb=np.fromfile(b,dtype=dtype)
 if aa.size!=bb.size:raise RuntimeError('length mismatch')
 av=(aa.astype('u4')<<16).view('f4') if dtype=='<u2' else aa
 bv=(bb.astype('u4')<<16).view('f4') if dtype=='<u2' else bb
 d=av.astype('f8')-bv;indices=np.flatnonzero(aa!=bb)
 return dict(elements=int(aa.size),different=int(indices.size),finite=bool(np.isfinite(av).all() and np.isfinite(bv).all()),max_absolute=float(abs(d).max()),
  rms=float(np.sqrt(np.mean(d*d))),first_differences=[dict(index=int(i),cpu=float(av[i]),cuda=float(bv[i]),cpu_bits=int(aa[i]),cuda_bits=int(bb[i])) for i in indices[:8]],
  left_sha256=hashlib.sha256(Path(a).read_bytes()).hexdigest(),right_sha256=hashlib.sha256(Path(b).read_bytes()).hexdigest())
names=json.loads((W/'source/main-probes.source.json').read_text())['names'];cuts=[];effect=[]
for name in names:
 cuts.append(dict(boundary=name,**comp(W/'cpu-probe/probe/prefill'/(name+'.bf16'),W/'cuda-probe/probe/prefill'/(name+'.bf16'))))
for backend in ('cpu','cuda'):
 for name,dtype in [('logits.f32','<f4'),('hidden.bf16','<u2')]:
  effect.append(dict(backend=backend,boundary=name,**comp(B/(backend+'-ordinary')/'trace/prefill'/name,W/(backend+'-probe')/'trace/prefill'/name,dtype)))
result=dict(scope='Actual original Q03 L3 cuts, same frozen source/weights/P15, original model math; no MTP',
 probe_does_not_change_same_version_final_outputs=all(r['different']==0 for r in effect),same_version_probe_effect=effect,cuts=cuts,
 first_different_cut=next((r['boundary'] for r in cuts if r['different']),None),performance_claim=False,quality_claim=False)
(W/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PROBE NUMERICALLY NEUTRAL',result['probe_does_not_change_same_version_final_outputs'])
for r in effect:print('PROBE EFFECT',r['backend'],r['boundary'],r['different'])
for r in cuts:print(r['boundary'],'different',r['different'],'/',r['elements'],'RMS',r['rms'],'max',r['max_absolute'])
print('FIRST',result['first_different_cut'])
