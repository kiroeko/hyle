from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd();W=Path(__file__).resolve().parent;D=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_text())
def identity(p):return dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
layers=read(W/'layer-exits/result.json');cuts=read(W/'layer3-cuts2/result.json');reference=read(W/'layer3-cuts2/attention-reference.json')
if not layers['probe_does_not_change_same_version_final_outputs'] or not cuts['probe_does_not_change_same_version_final_outputs']:raise RuntimeError('diagnostic changed numerics')
typed=next(row for row in reference['independent_probability_staging_variants'] if row['backend']=='cuda' and row['staging']=='bf16_exp_renormalized')
if typed['different_from_staged_rounded']!=0:raise RuntimeError('typed independent reference differs')
header=R/'.scratch/g04-bf16-product-c6-vendor/materialized-canonical/include/flashinfer/attention/prefill.cuh'
lines=header.read_text(encoding='utf8').splitlines();excerpt=W/'native-probability-excerpt.txt'
excerpt.write_text('Actual retained kernel include: '+str(header)+'\nSHA256 '+identity(header)['sha256']+'\n'+
 '\n'.join(str(i+1)+': '+lines[i] for i in range(1854,1894))+'\n')
summary=dict(scope='Q03 P15 ordinary CPU/CUDA discrepancy: finite first-propagating-layer and attention-boundary attribution; not all MTP numerical/quality completion',
 artifact=dict(id='Q03',repository='AxionML/Qwen3.5-2B-NVFP4',revision='6f2ad4febe92be529de499b08f0020f5ff06bf25'),
 configuration=dict(prompt_rows=15,generated_steps=1,mtp='off',capacity=256,requests=1,source='frozen aa91e19d3fa9051b987c574488695582085f2bcc95e7e7444511846cb9f9394b'),
 findings=['Embedding and layer0,1,2 BF16 exits are bitwise identical. First propagating difference is full-attention layer3.',
  'At layer3 input norm, original NVFP4 Q/K/V projections, Q/K norm and RoPE are all bitwise identical. First cut difference is PagedAttention output.',
  'Actual CPU route is ggml-cpu; CUDA route is FlashInfer. Same Qrope/Krope/V, causal T15/Hq8/Hkv2/D256, QKscale1/16, plain BF16 cache.',
  'Independent F64 mathematical attention followed by BF16 store matches CPU30718/30720 values, remaining2 differ by one BF16 code. CPU is not used as oracle.',
  'Independent unnormalized exp -> BF16 tile -> row renormalization -> V -> BF16 store matches all30720 CUDA values. FP16 staging and BF16 after normalization do not reproduce it.',
  'This is the documented native BF16 probability boundary, not extra source projection/cache/MTP corruption observed in this case. Later norm/quantization propagates and amplifies the difference.',
  'Both diagnostic publication batches preserve each backends final hidden/logits bitwise, including against the pre-sampling reference.'],
 first_layer=layers['first_different_layer_exit'],first_cut=cuts['first_different_cut'],
 attention_cross_backend=next(r for r in cuts['cuts'] if r['boundary']=='09-attention'),
 layer3_cross_backend=next(r for r in cuts['cuts'] if r['boundary']=='17-l3-output'),
 final_logits_cross_backend=layers['cross_backend_final_logits'],
 independent_reference_results=reference['results'],typed_probability_reference=typed,
 error_decomposition=reference['bounded_actual_case_error_decomposition'],
 contract_audit=dict(existing_declaration='docs/architecture/compute-design.md already distinguishes BF16 unnormalized attention weights from F32 online state; docs/user/compute.md also describes BF16 probability tiles.',
  clarification='docs/user/batch-attention.md and BatchPlanReport::bf16_partials comment now distinguish the probability tile from optional split-KV partial storage.',
  no_new_ABI=True,no_new_precision_option=True,no_math_or_default_route_change=True),
 regression=dict(test='FlashinferProbabilityPrecision.BfloatProbabilityTileIsIndependentOfSplitKvPartials',
  geometry='synthetic causal ragged T2/H1/D64 BF16, exact QKscores[0,1] and V[1,-3/8]',tests=1,failures=0,
  source=identity(R/'tests/compute_provider_flashinfer/probability_precision_test.cc'),registration='tests/compute_provider_flashinfer/CMakeLists.txt',
  purpose='Independent F64 ideal and BF16-staged references differ; actual CUDA follows staged value while bf16_partials remains false. No model payload.'),
 validation=dict(downloads=0,SDK_builds=0,full_model_runs='Six P15 steps1 ordinary diagnostic/reference runs total for final two batches; first failed probe retained separately.',
  runtime_identity='Retained current static closure; CPU native DLL6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f.',
  source_header_overlay='Only old BFloatLinearF32 class region restored in a private scratch model_ops.h; full SHA67d6e6d00e7c5db80f42d4df78695cbc5673ecc2f48b6f104f2885ac6a72c27c matches retained dependency. Product WIP untouched.'),
 limits=['One ordinary P15 prefix, two concrete providers and one selected NVFP4 artifact; no general full-model quality guarantee.',
  'No new acceptance-rate, long-task quality, all-context/all-prompt or all-MTP-mathematics claim.',
  'F64 and independent typed references establish this observed source; they are not a universal FlashInfer F32/exp2 error theorem.',
  'No provider is disabled and no precision is raised for bitwise agreement. Performance has not been investigated in this task.'])
files=[]
for name in ['derive_layer_probes.py','derive_layer3_probes.py','run_layer_exits.py','report_layer_exits.py','report_layer3.py','attention_reference.py',
 'check_probability_precision.py','publish_attention_evidence.py','native-probability-excerpt.txt','public-snapshot/restoration.json','public-snapshot/hyle/compute/model_ops.h']:
 files.append(W/name)
for phase in ['layer-exits','layer3-cuts2']:
 p=W/phase
 for f in p.glob('*.json'):files.append(f)
 for f in (p/'source').glob('*.h'):files.append(f)
 files += [p/'source/main.cc',p/'source/main-probes.cc',p/'source/main-probes.source.json']
 for run in ['cpu-probe','cuda-probe']+(['cpu-ordinary','cuda-ordinary'] if phase=='layer-exits' else []):
  for name in ['command.json','process.json','stdout.log','stderr.log']:files.append(p/run/name)
  if run.endswith('probe'):
   for f in (p/run/'probe').glob('*.tsv'):files.append(f)
   if phase=='layer3-cuts2':files.extend((p/run/'probe/prefill').glob('*.bf16'))
 for backend in ['cpu','cuda']:
  for job in ['compile','link']:
   for name in ['command.json','process.json','stdout.log','stderr.log']:files.append(p/(job+'-'+backend)/name)
for f in (W/'probability-regression').iterdir():
 if f.suffix in ('.json','.xml','.log'):files.append(f)
for name in ['command.json','process.json','stderr.log','stdout.log']:
 p=W/'layer3-cuts/cpu-probe'/name
 if p.exists():files.append(p)
files.append(R/'tests/compute_provider_flashinfer/probability_precision_test.cc')
archive=D/'qwen35-nvfp4-attention-boundary-2026-10-24.logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in dict.fromkeys(files):
  if p.is_file():z.write(p,str(p.relative_to(W)) if p.is_relative_to(W) else 'regression/'+p.name)
 z.writestr('README.txt','Read layer-exits/result.json, layer3-cuts2/result.json and attention-reference.json. Numeric .bf16 members are bounded original activation traces, not model weights. Source is frozen; no executable/object/SDK/model weights included.\n')
with zipfile.ZipFile(archive) as z:
 if z.testzip():raise RuntimeError('zip integrity')
 if any(Path(n).suffix in ('.obj','.exe','.dll','.bin') for n in z.namelist()):raise RuntimeError('large binaries included')
summary['evidence_archive']=identity(archive)
(D/'qwen35-nvfp4-attention-boundary-2026-10-24.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['evidence_archive'],indent=2))
