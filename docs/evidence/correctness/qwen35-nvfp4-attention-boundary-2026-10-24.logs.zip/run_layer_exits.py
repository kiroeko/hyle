"""Two frozen consumer TUs; four P15 functional runs; retained ABI closure only."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.stdout.reconfigure(encoding='utf8',errors='replace')
R=Path.cwd();stage3=len(sys.argv)>1 and sys.argv[1]=='layer3'
W=Path(__file__).resolve().parent/(sys.argv[2] if stage3 and len(sys.argv)>2 else 'layer3-cuts' if stage3 else 'layer-exits');E=R/'.scratch/mtp-random-20261024/engine-integration'
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
def identity(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(x,indent=2)+'\n')
def execute(label,command,env,timeout):
 folder=W/label;folder.mkdir(exist_ok=True,parents=True)
 save(folder/'command.json',dict(command=command,cwd=str(R),timeout_seconds=timeout,downloads=0,performance_claim=False,quality_claim=False))
 print('START',label,flush=True);start=time.time()
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
  p=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save(folder/'live.json',dict(pid=p.pid,started=start))
  try:code=p.wait(timeout)
  except subprocess.TimeoutExpired:p.kill();p.wait();raise
 save(folder/'process.json',dict(exit=code,elapsed_seconds=time.time()-start))
 print('END',label,code,flush=True)
 if code:
  print((folder/'stderr.log').read_text(encoding='utf8',errors='replace')[-10000:],flush=True)
  print((folder/'stdout.log').read_text(encoding='utf8',errors='replace')[-10000:],flush=True)
  raise RuntimeError(label+' failed')
 if (folder/'trace/prefill/logits.f32').exists():print('LOGITS',identity(folder/'trace/prefill/logits.f32'),flush=True)
W.mkdir(exist_ok=True,parents=True);source=W/'source';source.mkdir(exist_ok=True)
if not (W/'source-snapshot.json').exists():
 origin=W.parent/'layer-exits/source' if stage3 else R/'engine/models/qwen35'
 files=[origin/'main.cc',*origin.glob('*.h')];sources=[]
 for p in files:
  raw=p.read_bytes();target=source/p.name
  if target.exists() and target.read_bytes()!=raw:raise RuntimeError('frozen source target occupied')
  target.write_bytes(raw);sources.append(dict(original=identity(p),frozen=identity(target)))
 save(W/'source-snapshot.json',dict(files=sources,SDK_copies=0,weight_copies=0))
snapshot=json.loads((W/'source-snapshot.json').read_text())
for row in snapshot['files']:
 if identity(row['frozen']['path'])!=row['frozen']:raise RuntimeError('frozen source changed')
frozen=next(row['frozen'] for row in snapshot['files'] if Path(row['frozen']['path']).name=='main.cc')
derived=source/'main-probes.cc'
derive='derive_layer3_probes.py' if stage3 else 'derive_layer_probes.py'
if not derived.exists():subprocess.run([sys.executable,str(W.parent/derive),frozen['path'],frozen['sha256'],str(derived)],check=True)
for backend in ('cpu','cuda'):
 label='model'+('-cuda' if backend=='cuda' else '');recipe=json.loads((E/label/'identity.json').read_text())['command']
 native=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 folder=W/('compile-'+backend);folder.mkdir(exist_ok=True)
 command=[]
 for arg in recipe:
  if arg.endswith('main.cc'):arg=str(derived)
  arg=arg.replace(str(E/label),str(folder))
  command.append(arg)
 overlay=W.parent/'public-snapshot'
 if stage3 and (overlay/'hyle/compute/model_ops.h').is_file():command.insert(1,'/I'+str(overlay))
 execute('compile-'+backend,command,native,180)
 save(folder/'identity.json',dict(source=identity(derived),object=identity(folder/'qwen.obj')))
 link=[]
 for arg in json.loads((E/('link-'+backend+'.json')).read_text())['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:')):continue
  link.append(str(folder/'qwen.obj') if arg==str(E/label/'qwen.obj') else arg)
 runtime=W/'native-current';runtime.mkdir(exist_ok=True);image=runtime/('hyle-'+backend+'.exe')
 link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 save(W/('link-'+backend+'.json'),dict(command=link,retained_closure=identity(E/('link-'+backend+'.json'))))
 execute('link-'+backend,link,native,120)
 ready=json.loads((E/('ready-'+backend+'.json')).read_text());dll=ready['native_runtime']
 if identity(dll['path'])!=dll:raise RuntimeError('native DLL identity')
 target=runtime/Path(dll['path']).name
 if target.exists():
  if identity(target)['sha256']!=dll['sha256']:raise RuntimeError('native target identity')
 else:os.link(dll['path'],target)
 env=dict(os.environ,PATH=str(runtime)+os.pathsep+ready['PATH'])
 save(W/('ready-'+backend+'.json'),dict(image=identity(image),PATH=env['PATH'],native_runtime=dll))
 for mode in (('probe',) if stage3 else ('ordinary','probe')):
  runfolder=W/(backend+'-'+mode)
  if runfolder.exists():raise RuntimeError('run directory occupied; no overwrite of vectors')
  command=[str(image),'--inputs',str(W.parents[1]/'inputs-Q03-P15'),'--steps','1','--capacity','256',
   '--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--mtp','off',
   '--trace',str(runfolder/'trace'),'--trace-level','decisions']
  if mode=='probe':command+=['--layer0-probe',str(runfolder/'probe')]
  execute(backend+'-'+mode,command,env,180)
print('DONE 2 consumer TUs, 4 same-version P15 ordinary/probe functional runs; no performance claim',flush=True)
