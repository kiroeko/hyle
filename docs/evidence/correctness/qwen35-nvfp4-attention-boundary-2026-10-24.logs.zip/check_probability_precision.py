from pathlib import Path
import json,os,subprocess,sys,time,hashlib
R=Path.cwd();W=Path(__file__).resolve().parent/'probability-regression';E=R/'.scratch/mtp-random-20261024/engine-integration'
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
W.mkdir(exist_ok=True);sys.stdout.reconfigure(encoding='utf8',errors='replace')
recipe=json.loads((E/'model-cuda/identity.json').read_text())['command'];command=[];skip=False
for x in recipe:
 if skip:skip=False;continue
 if x=='/sourceDependencies':skip=True;continue
 if x.endswith('main.cc') or x.startswith(('/Fo','/Fd')):continue
 command.append(x)
source=R/'tests/compute_provider_flashinfer/probability_precision_test.cc'
command+=['/DHYLE_COMPUTE_FLASHINFER=1',str(source),'/Fo'+str(W/'test.obj'),'/Fd'+str(W/'test.pdb')]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
link=[x for x in json.loads((E/'link-cuda.json').read_text())['command'] if not x.endswith(('entry.obj','qwen.obj')) and not x.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
old=json.loads((R/'.scratch/dspark-block5-tail-20261024/link-command.json').read_text())
link+=[x for x in old if Path(x).name.lower() in ('gtest.lib','gtest_main.lib')]
link+=[str(W/'test.obj'),'/OUT:'+str(W/'checks.exe')]
ready=json.loads((E/'ready-cuda.json').read_text())
for name,args in [('compile',command),('link',link),('run',[str(W/'checks.exe'),'--gtest_output=xml:'+str(W/'tests.xml')])]:
 (W/(name+'-command.json')).write_text(json.dumps(args,indent=2)+'\n');start=time.time();print('START',name,flush=True)
 p=subprocess.run(args,cwd=R,env=dict(env,PATH=str(W)+os.pathsep+ready['PATH']),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
 (W/(name+'.log')).write_bytes(p.stdout)
 (W/(name+'-process.json')).write_text(json.dumps(dict(exit=p.returncode,seconds=time.time()-start),indent=2)+'\n')
 print('END',name,p.returncode,p.stdout.decode('utf8','replace')[-8000:],flush=True)
 if p.returncode:sys.exit(p.returncode)
(W/'identity.json').write_text(json.dumps(dict(source=dict(path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
 image=dict(path=str(W/'checks.exe'),sha256=hashlib.sha256((W/'checks.exe').read_bytes()).hexdigest()),downloads=0,SDK_builds=0,fresh_test_TUs=1),indent=2)+'\n')
