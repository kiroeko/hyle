"""Independent F64 causal GQA from the identical actual published Q/K/V."""
from pathlib import Path
import hashlib,json
import numpy as np
W=Path(__file__).resolve().parent/'layer3-cuts2'
def read(backend,name):
 raw=(W/(backend+'-probe/probe/prefill')/(name+'.bf16')).read_bytes();bits=np.frombuffer(raw,dtype='<u2')
 return bits,(bits.astype('u4')<<16).view('f4')
def round_bf16(x):
 bits=np.asarray(x,dtype='f4').view('u4');return ((bits+0x7fff+((bits>>16)&1))>>16).astype('u2')
def wider(bits):return (bits.astype('u4')<<16).view('f4')
for name in ('07-q-rope','08-k-rope','04-v-projection'):
 if not np.array_equal(read('cpu',name)[0],read('cuda',name)[0]):raise RuntimeError('same-QKV prerequisite')
q=read('cpu','07-q-rope')[1].reshape(15,8,256).astype('f8')
k=read('cpu','08-k-rope')[1].reshape(15,2,256).astype('f8')
v=read('cpu','04-v-projection')[1].reshape(15,2,256).astype('f8')
expected=np.zeros((15,8,256),dtype='f8');scores=np.full((15,8,15),-np.inf,dtype='f8');prob=np.zeros_like(scores)
staged={name:np.zeros_like(expected) for name in ('bf16_exp_renormalized','fp16_exp_renormalized','bf16_normalized_probability')}
probability_bound=np.zeros_like(expected)
for t in range(15):
 for h in range(8):
  # Standard contiguous GQA group size4, causal bottom-right15 queries/15keys.
  s=np.sum(q[t,h][None,:]*k[:t+1,h//4,:],axis=1)*0.0625
  p=np.exp(s-np.max(s));p/=np.sum(p)
  scores[t,h,:t+1]=s;prob[t,h,:t+1]=p
  expected[t,h]=np.sum(p[:,None]*v[:t+1,h//4,:],axis=0)
  e=np.exp(s-np.max(s))
  eb=wider(round_bf16(e)).astype('f8');eh=e.astype('f2').astype('f8');pb=wider(round_bf16(p)).astype('f8')
  staged['bf16_exp_renormalized'][t,h]=np.sum(eb[:,None]*v[:t+1,h//4,:],axis=0)/np.sum(eb)
  probability_bound[t,h]=np.sum(abs(eb/np.sum(eb)-p)[:,None]*abs(v[:t+1,h//4,:]),axis=0)
  staged['fp16_exp_renormalized'][t,h]=np.sum(eh[:,None]*v[:t+1,h//4,:],axis=0)/np.sum(eh)
  staged['bf16_normalized_probability'][t,h]=np.sum(pb[:,None]*v[:t+1,h//4,:],axis=0)
reference=round_bf16(expected).reshape(-1);center=expected.reshape(-1)
actual={};comparison=[]
for backend in ('cpu','cuda'):
 bits,values=read(backend,'09-attention');actual[backend]=(bits,values)
 distance=abs(values.astype('f8')-center)
 numeric_sign=bits.astype('i4');numeric_sign=np.where((numeric_sign&0x8000)!=0,0x8000-(numeric_sign&0x7fff),0x8000+numeric_sign)
 refsign=reference.astype('i4');refsign=np.where((refsign&0x8000)!=0,0x8000-(refsign&0x7fff),0x8000+refsign)
 ulp=np.abs(numeric_sign-refsign)
 pertoken=[dict(token=t,different_from_rounded_F64=int(np.count_nonzero(bits.reshape(15,-1)[t]!=reference.reshape(15,-1)[t])),
   max_absolute_from_F64=float(distance.reshape(15,-1)[t].max())) for t in range(15)]
 comparison.append(dict(backend=backend,elements=int(bits.size),same_as_F64_rounded=int(np.count_nonzero(bits==reference)),
  different_from_F64_rounded=int(np.count_nonzero(bits!=reference)),max_bf16_ordered_code_distance=int(ulp.max()),
  above_1_bf16_code=int(np.count_nonzero(ulp>1)),max_absolute_from_F64=float(distance.max()),rms_from_F64=float(np.sqrt(np.mean(distance**2))),
  first_token_equals_original_V_for_all_GQA_heads=bool(np.array_equal(bits.reshape(15,8,256)[0],np.repeat(read('cpu','04-v-projection')[0].reshape(15,2,256)[0],4,axis=0))),per_token=pertoken))
different=np.flatnonzero(actual['cpu'][0]!=actual['cuda'][0]);samples=[]
for i in different[:12]:
 t,h,d=np.unravel_index(i,(15,8,256));samples.append(dict(index=int(i),token=int(t),head=int(h),lane=int(d),F64=float(center[i]),
  rounded_F64=float(wider(reference[i:i+1])[0]),cpu=float(actual['cpu'][1][i]),cuda=float(actual['cuda'][1][i]),
  cpu_bits=int(actual['cpu'][0][i]),cuda_bits=int(actual['cuda'][0][i]),F64_reference_bits=int(reference[i])))
result=dict(scope='Independent mathematical F64 causal GQA reference, actual identical BF16 Qrope/Krope/V, T15,Hq8,Hkv2,D256,scale1/16',
 reference_precision='F64 dot/exp/softmax/value reduction, then one F32->BF16 storage for proximity diagnostics; not a declared F32 error interval certificate.',
 results=comparison,samples_on_cross_backend_differences=samples,
 interpretation='Measures proximity only; does not certify arbitrary tolerance or explain any approximation until provider source/boundaries are checked.',
 source_identity=[dict(name=n,sha256=hashlib.sha256((W/'cpu-probe/probe/prefill'/(n+'.bf16')).read_bytes()).hexdigest()) for n in ('07-q-rope','08-k-rope','04-v-projection')])
(W/'attention-reference.json').write_text(json.dumps(result,indent=2)+'\n')
for row in comparison:print({k:v for k,v in row.items() if k!='per_token'})
staging_results=[]
for name,reference_float in staged.items():
 rounded=round_bf16(reference_float).reshape(-1)
 for backend in ('cpu','cuda'):
  ab,av=actual[backend];delta=av.astype('f8')-reference_float.reshape(-1)
  staging_results.append(dict(staging=name,backend=backend,same_as_staged_rounded=int(np.count_nonzero(ab==rounded)),
    different_from_staged_rounded=int(np.count_nonzero(ab!=rounded)),rms_from_staged_F64=float(np.sqrt(np.mean(delta**2))),max_absolute_from_staged_F64=float(abs(delta).max())))
result['independent_probability_staging_variants']=staging_results
typed_center=staged['bf16_exp_renormalized'].reshape(-1)
typed_bits=round_bf16(typed_center);typed_stored=wider(typed_bits).astype('f8')
# Separate a documented probability boundary from the final storage rounding.
# A local BF16 rounding cell is asymmetric at powers of2; use its larger half.
following=wider((typed_bits.astype('u4')+1).astype('u2')).astype('f8')
preceding=wider((typed_bits.astype('u4')-1).astype('u2')).astype('f8')
half_cell=np.maximum(abs(following-typed_stored),abs(preceding-typed_stored))/2
half_cell=np.where((typed_bits&0x7fff)==0,2.**-134,half_cell)
stage_radius=probability_bound.reshape(-1)
observed=actual['cuda'][1].astype('f8')
f64_allowance=np.finfo('f8').eps*64*(abs(center)+stage_radius+half_cell)
inside=abs(observed-center)<=stage_radius+half_cell+f64_allowance
if not np.all(inside):raise RuntimeError('actual CUDA outside independently decomposed probability+BF16-storage interval')
result['bounded_actual_case_error_decomposition']=dict(
 definition='Per coordinate |sum((p_BF16-renormalized - p_F64)*V)| <= sum(abs(p_BF16-renormalized-p_F64)*abs(V)); add the final BF16 rounding cell half-width. No chosen absolute tolerance.',
 actual_CUDA_elements_inside_interval=int(np.count_nonzero(inside)),elements=int(inside.size),
 max_probability_boundary_bound=float(stage_radius.max()),max_final_BF16_half_cell=float(half_cell.max()),
 max_actual_pre_output_boundary_change=float(abs(typed_center-center).max()),
 limitation='This finite actual case matches the independent typed reference at every stored output. It is not a universal FlashInfer F32/exp2 error theorem or a full-model quality threshold.')
(W/'attention-reference.json').write_text(json.dumps(result,indent=2)+'\n')
for row in staging_results:print(row)
print(json.dumps(samples[:4],indent=2))
