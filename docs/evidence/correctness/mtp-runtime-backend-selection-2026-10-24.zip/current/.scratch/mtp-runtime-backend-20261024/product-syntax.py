"""Bounded current-consumer syntax checks; reuse the existing toolchain only."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[1]
spec = importlib.util.spec_from_file_location('runtime_product_tools', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
OUT = D/'product-syntax1'
OUT.mkdir(exist_ok=False)
paths = [R/'engine/models/qwen35/main.cc', R/'engine/models/qwen35/mtp_session_probe.cc',
         R/'engine/models/qwen35/native_gate.cc', *(R/'engine/models/qwen35').glob('*.h'),
         *(R/'engine/inference').glob('*.h')]
pins = [b.pin(path) for path in paths]
b.save(OUT/'source-pins.json', pins)
base = b.args(R/'.scratch/qwen-cpu-gpu-backend-20261024/header-check1/cpu-cuda/command.json')
env = b.environment(base[0])
checks = []
for name, relative, vulkan in [
    ('cuda-main', 'engine/models/qwen35/main.cc', False),
    ('cuda-vulkan-main', 'engine/models/qwen35/main.cc', True),
    ('cuda-session-probe', 'engine/models/qwen35/mtp_session_probe.cc', False),
    ('cuda-native-gate', 'engine/models/qwen35/native_gate.cc', False),
]:
    command = [base[0]]
    skip = False
    for word in base[1:]:
        if skip: skip = False; continue
        if word == '/sourceDependencies': skip = True; continue
        if word.lower().endswith(('.cc', '.cpp')) or word.lower().startswith(('/fo', '/fd')): continue
        command.append(word)
    if vulkan:
        command += ['/DHYLE_COMPUTE_VULKAN=1', '/external:IC:/public/tools/hyle-dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f/include']
    command += ['/Zs', '/sourceDependencies', str(OUT/name/'dependencies.json'), str(R/relative)]
    b.execute(command, OUT/name, env, 60)
    checks.append({'configuration': name, 'process': b.read(OUT/name/'process.json')})
assert pins == [b.pin(path) for path in paths], 'Product source changed during checks'
b.save(OUT/'summary.json', {'checks': checks, 'scope': 'Strict current C++ consumer syntax; no SDK build, link, model, HTTP or multi-native runtime claim'})
