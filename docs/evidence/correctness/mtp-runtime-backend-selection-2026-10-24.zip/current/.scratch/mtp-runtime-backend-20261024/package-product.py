"""Publish one bounded runtime-selection result without binaries or model data."""
from pathlib import Path
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p): return {'path': p.relative_to(R).as_posix(), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
win = read(D/'verification1/summary.json')
mac = read(D/'mac-product-check1/summary.json')
syntax = read(D/'product-syntax1/summary.json')
cpu = read(R/'.scratch/mtp-extraction-regression-20261024/runtimebackend1/syntax/process.json')
assert win['state'] == 'complete' and win['canonical_source_unchanged_since_freeze']
assert mac['source_pins_unchanged'] and all(c['exit'] == 0 for c in mac['checks'])
assert all(c['process']['exit'] == 0 for c in syntax['checks']) and cpu['exit'] == 0
assert hashlib.sha256((R/'engine/inference/backend.h').read_bytes()).hexdigest() == win['product_backend_sha256']
assert hashlib.sha256((R/'engine/models/qwen35/main.cc').read_bytes()).hexdigest() == win['product_main_sha256']
for source in read(D/'product-syntax1/source-pins.json'):
    p = Path(source['path']); assert p.stat().st_size == source['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest() == source['sha256']
out = R/'docs/evidence/correctness/mtp-runtime-backend-selection-2026-10-24'
archive = out.with_suffix('.zip')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
    for name, source in [('windows', D/'verification1/logs.zip'), ('apple', D/'mac-product-check1/results.zip')]:
        with zipfile.ZipFile(source) as previous:
            assert previous.testzip() is None
            for entry in previous.infolist():
                if not entry.is_dir(): target.writestr(name+'/'+entry.filename, previous.read(entry))
    for base in [D/'product-syntax1', R/'.scratch/mtp-extraction-regression-20261024/runtimebackend1/syntax']:
        for p in base.rglob('*'):
            if p.is_file() and p.suffix in {'.json', '.log'}: target.write(p, 'strict/'+p.relative_to(R/'.scratch').as_posix())
    for p in [Path(__file__), D/'product-syntax.py', R/'engine/models/qwen35/mtp_session_probe.cc']:
        target.write(p, 'current/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as check: assert check.testzip() is None
result = {
    'status': 'PASS bounded runtime backend selection integration',
    'scope': 'Behavior-preserving cold assembly and current consumer integration; not whole-engine function or performance closure',
    'changes': [
        'Compiled route availability is independent of explicit BackendSelection and engine --backend.',
        'One stable State owns original native endpoints, fixed domains, queues and retirement callbacks; moving Backend preserves addresses.',
        'Primary CPU selection in CPU+CUDA executes real CPU work with CUDA devices hidden; no unused GPU context is created.',
        'Model host predicate encoding, cache defaults, workspace budget, weight placement and reports follow the selected instance.',
        'Generic MTP session diagnostic accepts explicit --backend and preserves its non-CUDA prefix-only scope.'
    ],
    'windows': {'cuda_cpu_tests': win['cuda_cpu_image'], 'cpu_hidden_cuda': win['cpu_with_cuda_devices_hidden'],
        'vulkan_retirement': win['vulkan_retirement_readback'], 'vulkan_tiny': win['vulkan_tiny_model'],
        'summary': pin(D/'verification1/summary.json')},
    'apple': {'checks': mac['checks'], 'summary': pin(D/'mac-product-check1/summary.json'),
        'scope': 'CPU/Apple/mixed factory, moves, actual domains/queues and 16-byte read/write; model and native gate strict syntax'},
    'strict_consumers': {'cpu': cpu, 'other': syntax['checks']},
    'source': [pin(R/p) for p in ['engine/inference/backend.h', 'engine/models/qwen35/main.cc',
        'engine/models/qwen35/mtp_session_probe.cc', 'tests/tools/qwen_backend_cpu_cuda_test.cc', 'tests/tools/qwen_resource_retirement_test.cc']],
    'limits': ['No complete trained model rerun for this architecture batch.',
        'CPU+CUDA+Vulkan coexisting model syntax passed; combined native SDK link/runtime was not run.',
        'No throughput, quality, allocation-free whole-engine or arbitrary device placement claim.',
        'Existing FP8 functional baseline runs independently with frozen model code.'],
    'SDK_builds': 0, 'HTTP': 0, 'performance_claim': False, 'archive': pin(archive)
}
out.with_suffix('.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
print(json.dumps({'summary': pin(out.with_suffix('.json')), 'archive': pin(archive)}))
