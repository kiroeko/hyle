from pathlib import Path
import hashlib, json, os, platform, subprocess, sys, time

D = Path('/Users/kiro/hyle-scratch/compute-unified/mtp-runtime-backend-20261024/product-check1')
B = Path('/Users/kiro/hyle-scratch/compute-unified/qwen-cpu-apple-functional-20261024/attempt1')
source = D / 'source'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
    MLX_METAL_PATH='/Users/kiro/hyle-scratch/compute-unified/qwen-k1-functional-20261024/attempt1/mlx.metallib',
    OMP_NUM_THREADS='4', VECLIB_MAXIMUM_THREADS='4')

def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def pin(path):
    return dict(path=str(path), bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def run(name, command, timeout=60):
    out = D / name
    out.mkdir(exist_ok=False)
    save(out / 'command.json', dict(command=command, cwd=str(D),
        environment={k:env[k] for k in ['MLX_METAL_PATH','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']}))
    start = time.monotonic()
    with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
        result = subprocess.run(command, cwd=D, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
    record = dict(exit=result.returncode, seconds=time.monotonic()-start)
    save(out/'process.json', record)
    print(name, json.dumps(record), flush=True)
    if result.returncode:
        print((out/'stderr.log').read_text(errors='replace'), flush=True)
        raise SystemExit(result.returncode)
    return record

pins = json.loads((D/'source-pins.json').read_text())
for entry in pins:
    p = source / entry['relative']
    assert pin(p)['sha256'] == entry['sha256'], p
save(D/'hardware.json', {key: subprocess.check_output(command,text=True).strip() for key,command in [
    ('uname',['uname','-srm']),('os',['sw_vers']),('model',['sysctl','-n','hw.model']),
    ('memory_bytes',['sysctl','-n','hw.memsize']),('disk',['df','-k',str(D)]),
    ('compiler',['/usr/bin/c++','--version'])]})
old = next(job['command'] for job in json.loads((B/'plan.json').read_text())['jobs'] if job['tag']=='model')
base = [old[0], '-I'+str(source)]
skip = False
for value in old[1:]:
    if skip: skip = False; continue
    if value in {'-o','-MF'}: skip=True; continue
    if value=='-c' or value.endswith(('.cc','.cpp')): continue
    base.append(value)
checks=[]
for name,relative in [('syntax-model','engine/models/qwen35/main.cc'),
                      ('syntax-native-gate','engine/models/qwen35/native_gate_apple.mm')]:
    checks.append(dict(name=name,**run(name,base+['-fsyntax-only','-MF',str(D/name/'dependencies.d'),str(source/relative)])))
obj = D/'smoke.o'
checks.append(dict(name='compile-smoke',**run('compile-smoke',base+['-MF',str(D/'smoke.d'),'-c',str(D/'smoke.cc'),'-o',str(obj)])))
linkrecord = json.loads((B/'link5/command.json').read_text())
link=[]
for value in linkrecord['command']:
    if value == str(B/'objects/model.o'): value=str(obj)
    elif value == str(B/'hyle-cpu-apple-current5'): value=str(D/'smoke')
    elif value.startswith('-Wl,-map,'): value='-Wl,-map,'+str(D/'smoke.map')
    link.append(value)
assert str(obj) in link
save(D/'retained-link-inputs.json',[pin(Path(x)) for x in link if x.endswith(('.o','.a','.dylib')) and Path(x).is_file()])
checks.append(dict(name='link-smoke',**run('link-smoke',link,120)))
checks.append(dict(name='run-smoke',**run('run-smoke',[str(D/'smoke')],90)))
for entry in pins:
    assert pin(source/entry['relative'])['sha256']==entry['sha256']
save(D/'summary.json',dict(status='PASS_BOUNDED_MAC_RUNTIME_BACKEND_PRODUCT_CHECK',checks=checks,
    image=pin(D/'smoke'),source_pins_unchanged=True,SDK_builds=0,model_runs=0,HTTP=0,
    limits=['Strict model and Objective-C++ syntax only; no linked whole-model consumer',
            'Smoke creates only CPU, Apple and CPU+Apple endpoints, moves them and checks actual domains/queues/16-byte buffers',
            'No model inference, performance comparison or SDK reconstruction']))
