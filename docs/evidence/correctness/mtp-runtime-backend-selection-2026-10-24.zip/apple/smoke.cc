#include "engine/inference/backend.h"

#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

namespace i = hyle::inference;
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;

void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
template<class T> T take(hyle::Result<T> value) {
  if (!value) throw std::runtime_error(std::string(value.error().message()));
  return std::move(*value);
}
void check(hyle::Status value) {
  if (!value.ok()) throw std::runtime_error(std::string(value.message()));
}

void episode(i::BackendSelection selection, std::size_t domain_count,
             std::size_t queue_count) {
  auto original = take(i::Backend::create(selection, {.device=8192,.host=12288,.staging=16384}));
  const auto resource = original.device();
  const auto staging = original.staging();
  const auto host = original.host_device();
  auto queues = original.queue_bindings();
  require(queues.size() == queue_count, "wrong original queue count");
  c::Queue *queue = queues.empty() ? nullptr : queues.front().queue;
  auto *cpu = selection.primary == i::BackendKind::kCpu || selection.cpu_assist
      ? take(original.cpu_context()) : nullptr;
  auto *apple = selection.primary == i::BackendKind::kApple
      ? take(original.apple_context()) : nullptr;
  auto backend = std::move(original);
  require(original.queue_bindings().empty(), "moved-from backend kept queue borrows");
  require(backend.kind() == selection.primary && backend.selection().cpu_assist == selection.cpu_assist,
          "selection changed during move");
  require(backend.host_only() == (selection.primary == i::BackendKind::kCpu), "host-only fact differs");
  require(backend.native_generated_storage() == (selection.primary == i::BackendKind::kApple),
          "native output fact differs");
  require(backend.has_cpu_endpoint() == selection.cpu_assist, "CPU assistance fact differs");
  require(backend.device() == resource && backend.staging() == staging && backend.host_device() == host,
          "resource identity changed during move");
  require(take(backend.resource_for(g::StorageDomainId{0})) == resource, "primary domain differs");
  if (selection.cpu_assist) {
    require(take(backend.resource_for(g::StorageDomainId{1})) == host, "host domain differs");
    require(take(backend.resource_for(g::StorageDomainId{2})) == staging, "mixed staging domain differs");
    require(backend.queue_bindings().front().lane == g::ExecutionLaneId{1}, "Apple assist must bind CPU lane1 only");
  } else if (selection.primary == i::BackendKind::kApple) {
    require(take(backend.resource_for(g::StorageDomainId{1})) == staging, "native staging domain differs");
  } else {
    require(host == resource && staging == resource, "CPU aliases lost their real resource identity");
    require(take(backend.common_queue()) == queue, "CPU common queue changed");
  }
  auto absent = backend.resource_for(g::StorageDomainId{static_cast<std::uint32_t>(domain_count)});
  require(!absent && absent.error().IsOutOfRange(), "missing domain did not fail explicitly");
  auto invalid = backend.resource_for({});
  require(!invalid && invalid.error().IsInvalidArgument(), "invalid domain did not fail explicitly");
  require(backend.queue_bindings().size() == queue_count, "queue count changed after move");
  if (queue) require(backend.queue_bindings().front().queue == queue, "original queue borrow moved");
  if (cpu) require(take(backend.cpu_context()) == cpu, "original CPU Context moved");
  if (apple) require(take(backend.apple_context()) == apple, "original Apple Context moved");
  if (selection.primary == i::BackendKind::kApple) {
    require(!backend.common_context() && !backend.common_queue(), "Apple forged a common endpoint");
  } else require(!backend.apple_context(), "CPU created an unselected Apple endpoint");
  require(!take(backend.storage_owner_for(resource)), "CPU/Apple domain gained a fabricated StorageOwner");
  auto buffer = take(m::Buffer::create(resource, 4 * sizeof(float), 256));
  const std::array values{1.0F,-2.0F,3.5F,0.0F};
  std::array<float,4> actual{};
  check(backend.write(buffer.view(), std::as_bytes(std::span(values))));
  check(backend.read(buffer.view(), std::as_writable_bytes(std::span(actual))));
  require(actual == values, "original resource read/write differs");
  check(backend.collect_retired());
  std::cout << "{\"episode\":\"" << backend.name() << (selection.cpu_assist ? "+cpu" : "")
            << "\",\"domains\":" << domain_count << ",\"queues\":" << queue_count
            << ",\"moved_original_contexts\":true,\"read_write_bytes\":16}" << std::endl;
}

int main() {
  try {
    const auto defaults = take(i::Backend::default_selection());
    require(defaults.primary == i::BackendKind::kApple && !defaults.cpu_assist,
            "single native route default differs");
    require(i::Backend::compiled_backends().size() == 2, "unexpected compiled backend set");
    auto bad = i::Backend::create({.primary=i::BackendKind::kCpu,.cpu_assist=true});
    require(!bad && bad.error().IsInvalidArgument(), "CPU assistance on CPU primary accepted");
    auto missing = i::Backend::create({.primary=i::BackendKind::kCuda});
    require(!missing && missing.error().IsUnimplemented(), "uncompiled CUDA selection accepted");
    episode({.primary=i::BackendKind::kCpu}, 1, 1);
    episode({.primary=i::BackendKind::kApple}, 2, 0);
    episode({.primary=i::BackendKind::kApple,.cpu_assist=true}, 3, 1);
    std::cout << "{\"status\":\"PASS_RUNTIME_BACKEND_FACTORY_MOVE_DOMAINS\",\"model_weights\":0,\"model_runs\":0}" << std::endl;
    return 0;
  } catch (const std::exception &error) {
    std::cerr << error.what() << std::endl;
    return 1;
  }
}
