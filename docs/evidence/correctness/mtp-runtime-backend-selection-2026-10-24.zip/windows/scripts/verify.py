"""Bounded current BackendSelection regressions; retained SDK/objects only."""
from pathlib import Path
import importlib.util
import os
import re
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent / 'verification1'
S = D / 'source'
spec = importlib.util.spec_from_file_location('retained_tools', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
CUDA = R / '.scratch/qwen-cpu-gpu-backend-20261024/cuda-regression1'

def freeze():
    D.mkdir(exist_ok=False)
    S.mkdir()
    sources = [R / 'engine/models/qwen35/main.cc',
        *(R / 'engine/models/qwen35').glob('*.h'),
        *(R / 'engine/inference').glob('*.h'),
        R / 'tests/tools/qwen_backend_cpu_cuda_test.cc',
        R / 'tests/tools/qwen_resource_retirement_test.cc']
    # Only the existing retirement fixture's relative private header closure.
    pending = [R / 'src/compute_route_vulkan/vulkan_internal.h']
    private = set()
    while pending:
        source = pending.pop().resolve()
        if source in private: continue
        private.add(source)
        for relative in re.findall(r'^#include "([^"]+)"', source.read_text(), re.M):
            child = (source.parent / relative).resolve()
            if child.is_file() and child.is_relative_to(R / 'src'): pending.append(child)
    sources += sorted(private)
    pins = []
    for original in sources:
        frozen = S / original.relative_to(R)
        frozen.parent.mkdir(parents=True, exist_ok=True)
        frozen.write_bytes(original.read_bytes())
        pins.append({'canonical': b.pin(original), 'frozen': b.pin(frozen)})
    b.save(D / 'source-pins.json', pins)
    (S / 'retirement.cc').write_text('#include "tests/tools/qwen_resource_retirement_test.cc"\n')
    old_tiny = R / '.scratch/mtp-phase-readback-regression-20261024/tiny.cc'
    tiny = old_tiny.read_text()
    before = '16 * 1024 * 1024, {.enabled = true, .policy = {1.F, 8, .9F}, .seed = 123});'
    after = ('16 * 1024 * 1024, {.enabled = true, .policy = {1.F, 8, .9F}, .seed = 123},\n'
        '        0, {.primary = hyle::inference::BackendKind::kVulkan});')
    assert tiny.count(before) == 1
    tiny = tiny.replace(before, after).replace('q::host_predicate_type',
        '(model.execution.native_generated_storage() ? q::Type::kFloat32 : q::Type::kBool)')
    assert tiny.count('q::Backend::name()') == 1
    tiny = tiny.replace('q::Backend::name()', 'model.execution.name()')
    (S / 'tiny.cc').write_text(tiny)
    b.save(D / 'tiny-migration.json', {'original': b.pin(old_tiny), 'current': b.pin(S / 'tiny.cc'),
        'changes': ['explicit Vulkan Model constructor argument 11',
            'predicate expectation uses selected instance storage representation', 'diagnostic name uses instance'],
        'math_graph_state_rng_changes': False})

def compile_tu(previous, source, folder, gtest=False):
    original = b.args(previous)
    command = [original[0], '/I' + str(S)]
    skip = False
    for word in original[1:]:
        if skip: skip = False; continue
        if word == '/sourceDependencies': skip = True; continue
        lower = word.lower().replace('\\', '/')
        if lower.startswith(('/fo', '/fd')) or lower.endswith(('.cc', '.cpp')): continue
        if lower.startswith('/i') and '/.scratch/' in lower and lower.endswith('/source'): continue
        command.append(word)
    command += ['/I' + str(R), '/I' + str(R / 'include')]
    if gtest:
        command.append('/external:IC:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
    command += ['/sourceDependencies', str(folder / 'dependencies.json'), str(source),
        '/Fo' + str(folder / 'unit.obj'), '/Fd' + str(folder / 'unit.pdb')]
    env = b.environment(command[0]); b.execute(command, folder, env, 180)
    dependencies = b.read(folder / 'dependencies.json')['Data']['Includes']
    owned = [Path(p) for p in dependencies if Path(p).is_relative_to(R)]
    b.save(folder / 'hyle-header-pins.json', [b.pin(p) for p in owned])
    return env

def run(command, folder, env):
    old_root = b.R
    b.R = folder
    try: b.execute(command, folder, env, 60)
    finally: b.R = old_root

def cuda():
    env = compile_tu(CUDA / 'compile/command.json', S / 'tests/tools/qwen_backend_cpu_cuda_test.cc', D / 'cuda-compile')
    previous = b.args(CUDA / 'link/command.json')
    old_object = str(CUDA / 'compile/backend-test.obj')
    assert old_object in previous
    link = []
    for word in previous:
        if word.upper().startswith(('/OUT:', '/MAP:', '/PDB:', '/IMPLIB:')): continue
        link.append(str(D / 'cuda-compile/unit.obj') if word == old_object else word)
    image = D / 'cuda-link/backend-check.exe'; link.append('/OUT:' + str(image))
    b.execute(link, D / 'cuda-link', env, 120)
    native = []
    for source in (CUDA / 'link').glob('*.dll'):
        os.link(source, image.parent / source.name); native.append(b.pin(source))
    b.save(image.parent / 'native.json', native)
    env['PATH'] = b.read(CUDA / 'ready.json')['PATH']
    run([str(image), '--gtest_filter=QwenBackendCpuCuda.*',
        '--gtest_output=json:' + str(D / 'cuda-gtests.json')], D / 'cuda-run', env)

def vulkan(mode):
    source = S / ('retirement.cc' if mode == 'retirement' else 'tiny.cc')
    env = compile_tu(b.VK / 'compile/command.json', source, D / (mode + '-compile'), gtest=mode == 'retirement')
    image = b.link(D / (mode + '-compile/unit.obj'), D / (mode + '-link'), env, vulkan=True, gtest=mode == 'retirement')
    env.update({k: v for k, v in b.read(b.VK / 'runtime.json').items() if isinstance(v, str)})
    args = ['--gtest_filter=QwenResourceRetirement.*', '--gtest_output=json:' + str(D / 'retirement-gtests.json')] if mode == 'retirement' else [str(D / 'tiny-run')]
    run([str(image), *args], D / (mode + '-run'), env)

def cpu_without_cuda_device():
    original = b.args(CUDA / 'compile/command.json')
    env = b.environment(original[0]); env['PATH'] = b.read(CUDA / 'ready.json')['PATH']
    env['CUDA_VISIBLE_DEVICES'] = '-1'
    b.save(D / 'cpu-no-cuda-device-environment.json', {'CUDA_VISIBLE_DEVICES': '-1',
        'compiled_backends': ['cpu', 'cuda'], 'runtime_environment_base': b.pin(CUDA / 'ready.json')})
    run([str(D / 'cuda-link/backend-check.exe'),
        '--gtest_filter=QwenBackendCpuCuda.ExplicitCpuExecutesOriginalQueueAfterMove',
        '--gtest_output=json:' + str(D / 'cpu-no-cuda-device-gtests.json')], D / 'cpu-no-cuda-device-run', env)

if __name__ == '__main__':
    {'freeze': freeze, 'cuda': cuda, 'cpu-no-cuda-device': cpu_without_cuda_device, 'retirement': lambda: vulkan('retirement'),
        'tiny': lambda: vulkan('tiny')}[sys.argv[1]]()
