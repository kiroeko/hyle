from pathlib import Path
import hashlib
import importlib.util
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent / 'verification1'
spec = importlib.util.spec_from_file_location('retained_tools', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
pins = b.read(D / 'source-pins.json')
cuda = b.read(D / 'cuda-gtests.json')
retirement = b.read(D / 'retirement-gtests.json')
cpu = b.read(D / 'cpu-no-cuda-device-gtests.json')
tiny = json.loads((D / 'tiny-run/stdout.log').read_text().strip())
steps = {}
for name in ['cuda-compile', 'cuda-link', 'cuda-run', 'cpu-no-cuda-device-run',
        'retirement-compile', 'retirement-link', 'retirement-run', 'tiny-compile', 'tiny-link', 'tiny-run']:
    result = b.read(D / name / 'process.json')
    assert result['exit'] == 0 and not result['timeout']
    steps[name] = {'process': result, 'command': b.pin(D / name / 'command.json'),
        'stdout': b.pin(D / name / 'stdout.log'), 'stderr': b.pin(D / name / 'stderr.log')}
for group in [cuda, retirement, cpu]:
    assert not group['failures'] and not group['errors']
assert tiny['status'] == 'PASS_TINY_PHASE_READBACK' and tiny['backend'] == 'vulkan'
assert tiny['fixture_bytes'] == 206336 and tiny['classic_cursors'] == [4, 4]
source_unchanged = all(b.pin(Path(p['canonical']['path']))['sha256'] == p['canonical']['sha256'] for p in pins)
summary = {
    'state': 'complete', 'bounded_functional_verification': True,
    'source_pins': b.pin(D / 'source-pins.json'), 'canonical_source_unchanged_since_freeze': source_unchanged,
    'product_backend_sha256': next(p['canonical']['sha256'] for p in pins if p['canonical']['path'].endswith('engine\\inference\\backend.h')),
    'product_main_sha256': next(p['canonical']['sha256'] for p in pins if p['canonical']['path'].endswith('engine\\models\\qwen35\\main.cc')),
    'cuda_cpu_image': {'tests': cuda['tests'], 'passed': cuda['tests'],
        'permanent_tests': b.pin(R / 'tests/tools/qwen_backend_cpu_cuda_test.cc'),
        'new_cases': ['explicit CPU selection keeps original CPU Context/Queue and system resource after move; 17 exact Neg outputs',
            'invalid enum, CPU-assist with CPU primary and all uncompiled backends reject without fallback'],
        'retained_cases': ['explicit CUDA single endpoint', 'CPU-CUDA-CPU transfers/borrowed constant/move/retirement',
            'finite zero staging rejects required crossing', 'original CPU file endpoint exports immutable host lease and retires budget']},
    'cpu_with_cuda_devices_hidden': {'CUDA_VISIBLE_DEVICES': '-1', 'tests': cpu['tests'], 'passed': cpu['tests'],
        'same_image_as_cuda_suite': True, 'original_cpu_graph_actually_executed': True},
    'vulkan_retirement_readback': {'tests': retirement['tests'], 'passed': retirement['tests'],
        'permanent_tests': b.pin(R / 'tests/tools/qwen_resource_retirement_test.cc'),
        'cases': ['Session retires original work after Model destruction', 'last callback releases scope without application owners',
            'actual Bool alias valid replay and nonbinary byte rejection',
            'actual F32 alias valid replay, .5/Inf/NaN and undersized scratch rejection with canaries']},
    'vulkan_tiny_model': {'result': tiny, 'migration': b.pin(D / 'tiny-migration.json'),
        'math_and_graph_unchanged': True, 'final_all_versions_retired_assertion': True,
        'explicit_runtime_selection': 'vulkan', 'full_model_quality_claim': False},
    'steps': steps,
    'retained_closures': [b.pin(R / '.scratch/qwen-cpu-gpu-backend-20261024/cuda-regression1/compile/command.json'),
        b.pin(R / '.scratch/qwen-cpu-gpu-backend-20261024/cuda-regression1/link/command.json'),
        b.pin(b.VK / 'compile/command.json'), b.pin(b.VK / 'link-plan.json')],
    'newly_compiled_consumer_translation_units': 3,
    'SDK_builds': 0, 'HTTP_requests': 0, 'download_bytes': 0, 'full_trained_model_runs': 0,
    'performance_claim': False, 'cross_backend_bitwise_claim': False,
    'limitations': ['Windows actual cached CPU+CUDA and CPU+Vulkan images only',
        'multiple GPU backend simultaneous linking/running was not part of this bounded verification',
        'Apple runtime was not repeated; prior candidate CPU+Apple syntax-only proof remains separate',
        'no instrumentation claim about CUDA driver loading; CPU-only selected resource, queue and actual execution verified with CUDA devices hidden']}
b.save(D / 'summary.json', summary)
archive = D / 'logs.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for path in [D.parent / 'verify.py', D.parent / 'package-verification.py']:
        z.write(path, 'scripts/' + path.name)
    for path in sorted(D.rglob('*')):
        if not path.is_file() or path == archive: continue
        relative = path.relative_to(D)
        if 'fixture' in relative.parts: continue
        if path.suffix not in {'.json', '.log', '.h', '.cc'}: continue
        if path.name in {'live.json', 'dependencies.json'}: continue
        z.write(path, str(relative))
print(json.dumps({'summary': b.pin(D / 'summary.json'), 'archive': b.pin(archive),
    'canonical_source_unchanged_since_freeze': source_unchanged}, indent=2))
