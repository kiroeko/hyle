"""Finite GLM architecture checks; current SDK objects and local weights only."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('cached', R / '.scratch/inference-source-binding-20261030/build.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
s.W = s.b.W = W
read, save, pin, exact, key = s.read, s.save, s.pin, s.exact, s.key
BASE = R / '.scratch/inference-cross-turn-warmth-20261030/model-link-base.json'


def prepare():
    assert not (W / 'plan.json').exists(), 'Do not overwrite a previous batch.'
    base = read(BASE)
    for item in [*base['retained'], base['runtime']]:
        exact(item)
    assert len(base['retained']) == 227
    old = read(base['current_consumers']['cli']['receipt']['path'])
    prior = read(R / '.scratch/inference-glm-step-20261030/plan.json')
    unit = prior['consumers']['glm']
    current = dict(unit, compile=s.relocated(unit['compile'], 'glm'))
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    save(W / 'plan.json', dict(base=pin(BASE), base_commit='11f511cd7',
        retained=base['retained'], runtime=base['runtime'], original_link=base['link'],
        original_consumer=old['object']['path'], units={}, consumers={'glm': current},
        environment=prior['environment'], cases=prior['cases'],
        SDK_CXX=0, NVCC=0, downloads=0, performance_experiments=0))
    print('Prepared one GLM consumer and227 retained current SDK objects.', flush=True)


def link(attempt):
    p = read(W / 'plan.json')
    receipt = read(W / 'compile/glm/receipt.json')
    for item in [receipt['object'], *p['retained']]:
        exact(item)
    for item in receipt['source_identities']:
        exact(item)
    args = []
    replacements = 0
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']):
            arg = receipt['object']['path']
            replacements += 1
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/glm').with_suffix(suffix))
                break
        args.append(arg)
    assert replacements == 1
    args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / name) for name in ('gtest_main.lib', 'gtest.lib'))
    s.b.execute(args, W / 'link/glm' / attempt, 240)
    save(W / 'ready-glm.json', pin(W / 'bin/glm.exe'))


def run(name, attempt):
    p = read(W / 'plan.json')
    case = p['cases'][name]
    image = read(W / 'ready-glm.json')
    exact(image)
    folder = W / 'runs' / name / attempt
    save(folder / 'image.json', image)
    os.environ.update(p['environment'])
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
        HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0', HYLE_GLM_MLX_WAIT_FOR_EXPERTS='0', HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS='0')
    s.b.execute([image['path'], '--gtest_color=no', '--gtest_fail_fast', '--gtest_filter=' + case['filter'],
        '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
    result = ET.parse(folder / 'results.xml').getroot()
    assert result.get('tests') == str(case['tests']) and result.get('failures') == result.get('errors', '0') == '0'
    assert not result.findall('.//skipped')
    report = dict(status='PASS', tests=case['tests'], failures=0, skipped=0,
        cases=[dict(name=t.get('classname') + '.' + t.get('name'),
            properties={v.get('name'): v.get('value') for v in t.findall('./properties/property')})
            for t in result.findall('.//testcase')])
    save(folder / 'report.json', report)
    print('PASS', name, flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': s.compile_one('glm', sys.argv[2])
    elif action == 'link': link(sys.argv[2])
    elif action == 'run': run(sys.argv[2], sys.argv[3])
    else: raise ValueError(action)
