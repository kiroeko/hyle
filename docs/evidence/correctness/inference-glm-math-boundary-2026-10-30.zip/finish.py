from pathlib import Path
import importlib.util
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('current_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact = b.read, b.save, b.pin, b.exact
p = read(W / 'plan.json')
receipt = read(W / 'compile/glm/receipt.json')
for item in [receipt['object'], *receipt['source_identities'], *p['retained']]:
    exact(item)
cases = []
for name in ('greedy-cuda', 'request-cuda'):
    current = W / 'runs' / name / 'attempt1'
    previous = R / '.scratch/inference-glm-step-20261030/runs' / name / 'attempt1/report.json'
    report = read(current / 'report.json')
    baseline = read(previous)
    assert report['status'] == baseline['status'] == 'PASS'
    assert report['tests'] == 1 and report['skipped'] == report['failures'] == 0
    actual = report['cases'][0]['properties']
    expected = baseline['cases'][0]['properties']
    assert actual == expected, name
    process = read(current / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    cases.append(dict(name=name, test=report['cases'][0]['name'], status='PASS', skipped=0,
        non_timing_properties=len(actual), previous_properties_identical=True,
        prior=pin(previous), report=pin(current / 'report.json'), process=process))
source = R / 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
body = source.read_text(encoding='utf-8')
pure = body.split('template<class Runtime> struct GlmStepRuntime final {', 1)[1].split('struct GlmRequestDirectory final {', 1)[0]
assert all(term not in pure for term in ('EXPECT_', 'ASSERT_', 'reference::', 'observe_step_execution', 'observe_target('))
(W / 'source-change.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', str(source)], cwd=R))
base = read(p['base']['path'])
base['base'] = p['base']
base.setdefault('current_consumers', {})['glm-math-boundary'] = dict(
    receipt=pin(W / 'compile/glm/receipt.json'), object=receipt['object'])
base['note'] = 'Same SDK ABI and CLI inputs; added independently checked GLM consumer. No common step-driver completion or performance claim.'
save(W / 'model-link-base.json', base)
summary = dict(schema='hyle.glm-math-observation-boundary.v1', date='2026-10-30', base_commit=p['base_commit'],
    status='FINITE_CHECKS_PASSED', source=pin(source),
    implementation=[
        'execute_step returns original input/output leases and uncommitted StateVersion; reference/exact-row/EXPECT checks are explicit observers.',
        'TargetFrame retains original inputs/outputs/state for explicit target observation.',
        'GlmStepRuntime advance/ordinary/verify/repair form actual results without reference or EXPECT; scenarios observe and release temporary versions/leases.',
        'MoE observations use each completed execution selection ordinal; original upload report scalars are captured before their WeightBatch expires.',
        'Original StateStore version/draft limits, resident capacities, graph recipes, publication, RNG and retirement mechanisms retained.'
    ], cases=cases,
    build=dict(consumer_cxx=1, SDK_CXX=0, NVCC=0, downloads=0, retained_sdk_objects=227,
        compile=read(W / 'compile/glm/attempt1/process.json'), link=read(W / 'link/glm/attempt1/process.json')),
    cleanup=read(W / 'cleanup-report.json'),
    limits=[
        'Original target77/NextN78 finite components with explicit upstream activation and initial cache fixtures, not complete GLM prompt generation.',
        'RequestLoop GLM wave is still synchronous and pending_count is zero; shared complete step driver and second-model continuation remain unfinished.',
        'Official K2, NextN-only, B09/B10, CPU and Apple/Vulkan variants were not run in this batch.',
        'No throughput, physical-memory or cross-engine performance conclusion.'
    ], next='Implement actual common current/successor and cross-pump control, with static model facts and original Graph execution authority.')
save(W / 'summary.json', summary)
dest = R / 'docs/evidence/correctness'
dest.mkdir(parents=True, exist_ok=True)
save(dest / 'inference-glm-math-boundary-2026-10-30.json', summary)
archive = dest / 'inference-glm-math-boundary-2026-10-30.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as out:
    for relative in ('build.py', 'finish.py', 'summary.json', 'plan.json', 'source-change.patch',
            'compile/glm/receipt.json', 'compile/glm/attempt1/command.json', 'compile/glm/attempt1/process.json',
            'link/glm/attempt1/command.json', 'link/glm/attempt1/process.json',
            'cleanup-targets.json', 'cleanup-report.json', 'cleanup.ps1'):
        out.write(W / relative, relative)
    for name in ('greedy-cuda', 'request-cuda'):
        for item in ('command.json', 'process.json', 'report.json', 'results.xml', 'stdout.log', 'stderr.log', 'image.json'):
            relative = f'runs/{name}/attempt1/{item}'
            out.write(W / relative, relative)
print(json.dumps(dict(status=summary['status'], cases=len(cases), identical_properties=sum(c['non_timing_properties'] for c in cases), archive_bytes=archive.stat().st_size)))
