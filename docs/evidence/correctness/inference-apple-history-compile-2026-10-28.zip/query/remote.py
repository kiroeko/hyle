
from pathlib import Path
import hashlib, json, subprocess

base = Path('/Users/kiro/hyle-scratch/compute-unified')
r3 = base / 'inference-native-program-io-20261028/refinement3'
sdk = base / 'architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21'
ready = json.loads((r3 / 'ready.json').read_text())
plan = json.loads((r3 / 'plan.json').read_text())
inputs_doc = json.loads(Path(ready['inputs']['path']).read_text())
rows = inputs_doc if isinstance(inputs_doc, list) else inputs_doc.get('inputs', inputs_doc.get('rows'))
if not isinstance(rows, list):
    raise ValueError('unknown actual R3 inputs schema')
mlx_rows = [row for row in rows if Path(row['path']).name == 'libmlx.a']
if len(mlx_rows) != 1:
    raise ValueError('R3 must contain exactly one actual libmlx.a')
archive = Path(mlx_rows[0]['path'])

def stat(path):
    path = Path(path)
    if not path.exists():
        return {'path': str(path), 'exists': False}
    s = path.stat()
    return {'path': str(path), 'exists': True, 'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns}

def run(argv):
    p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30)
    return {'command': argv, 'exit': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}

build = sdk / 'build'
directories = [build]
deps = build / '_deps'
dep_entries = sorted(deps.glob('*mlx*')) if deps.exists() else []
for entry in dep_entries:
    if entry.is_dir():
        directories += [entry, entry / 'build']
directories += [build / '_deps/mlx-91aee008db1a5528/build',
                build / '_deps/mlx-91aee008db1a5528-build']
directories = list(dict.fromkeys(directories))
result = {
    'scope': 'read-only metadata/source inventory; no compiler, linker, inference, or remote write',
    'ready': stat(r3 / 'ready.json'), 'image': ready['image'],
    'inputs': ready['inputs'], 'actual_input_count': len(rows),
    'libmlx_original_receipt': mlx_rows[0], 'libmlx_actual_stat': stat(archive),
    'runtime_overrides': ready.get('runtime', plan.get('runtime')),
    'fixture': plan.get('fixture'), 'sdk_root': str(sdk),
    'mlx_dependency_entries': [stat(p) for p in dep_entries],
    'candidate_files': [], 'compile_commands': [], 'ninja_compile_blocks': [],
    'compiler_cache_fields': [], 'make_flags': [], 'make_compile_blocks': [], 'sources': [],
}
sources = set()
for directory in directories:
    for name in ('compile_commands.json', 'build.ninja', 'CMakeCache.txt', 'CMakeFiles/rules.ninja',
                 'CMakeFiles/mlx.dir/flags.make', 'CMakeFiles/mlx.dir/build.make',
                 'mlx/CMakeFiles/mlx.dir/flags.make', 'mlx/CMakeFiles/mlx.dir/build.make'):
        path = directory / name
        result['candidate_files'].append(stat(path))
        if not path.is_file():
            continue
        if name == 'compile_commands.json':
            for row in json.loads(path.read_text()):
                source = str(row.get('file', ''))
                if source.endswith('/mlx/compile.cpp') or source == 'mlx/compile.cpp':
                    result['compile_commands'].append({'recipe_file': str(path), **row})
                    resolved = Path(source)
                    if not resolved.is_absolute():
                        resolved = Path(row['directory']) / resolved
                    sources.add(resolved.resolve())
        elif name == 'build.ninja':
            lines = path.read_text().splitlines()
            for i, line in enumerate(lines):
                if line.startswith('build ') and ('/mlx/compile.cpp' in line or 'compile.cpp.o:' in line):
                    block = [line]
                    for later in lines[i + 1:i + 18]:
                        if not later.strip():
                            break
                        block.append(later)
                    result['ninja_compile_blocks'].append({'path': str(path), 'line': i + 1, 'block': block})
        elif name == 'CMakeCache.txt':
            keys = ('CMAKE_CXX_COMPILER:', 'CMAKE_CXX_COMPILER_LAUNCHER:', 'CMAKE_CXX_FLAGS',
                    'CMAKE_OSX_', 'MLX_BUILD', 'mlx_SOURCE_DIR:', 'mlx_BINARY_DIR:')
            result['compiler_cache_fields'].append({'path': str(path),
                'fields': [line for line in path.read_text().splitlines() if line.startswith(keys)]})
        elif name.endswith('flags.make'):
            result['make_flags'].append({'path': str(path), 'text': path.read_text()})
        elif name.endswith('build.make'):
            lines = path.read_text().splitlines()
            for i, line in enumerate(lines):
                if 'compile.cpp.o:' in line:
                    block = [line]
                    for later in lines[i + 1:i + 12]:
                        if not later.strip():
                            break
                        block.append(later)
                    result['make_compile_blocks'].append({'path': str(path), 'line': i + 1, 'block': block})

# Preserve the actual Ninja rule command as well as each compile.cpp input block.
rules = []
for item in result['ninja_compile_blocks']:
    rule = item['block'][0].split(':', 1)[1].strip().split()[0]
    parent = Path(item['path']).parent
    path = parent / 'CMakeFiles/rules.ninja'
    if path.is_file():
        lines = path.read_text().splitlines()
        for i, line in enumerate(lines):
            if line == 'rule ' + rule:
                block = [line]
                for later in lines[i + 1:i + 12]:
                    if not later.strip():
                        break
                    block.append(later)
                rules.append({'path': str(path), 'line': i + 1, 'block': block})
result['ninja_rules'] = rules
sources.add((build / '_deps/mlx-91aee008db1a5528/source/mlx/compile.cpp').resolve())
for source in sorted(sources):
    row = stat(source)
    if source.is_file():
        row['sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
    result['sources'].append(row)
listed = run(['/usr/bin/ar', '-t', str(archive)])
members = listed['stdout'].splitlines()
result['archive_listing'] = {'command': listed['command'], 'exit': listed['exit'],
    'stderr': listed['stderr'], 'member_count': len(members),
    'compile_named_members': [name for name in members if 'compile' in name.lower()]}
result['compiler_version'] = run(['/usr/bin/c++', '--version'])
print(json.dumps(result, indent=2))
