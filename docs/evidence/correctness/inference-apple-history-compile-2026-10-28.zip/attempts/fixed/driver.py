"""Root-executed Mac actions for one isolated MLX diagnostic TU/archive."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def exact(row):
    actual = pin(row['path'])
    if any(actual[key] != row[key] for key in ('bytes', 'sha256')):
        raise ValueError('pin mismatch: ' + row['path'])
    return actual


def stat_matches(row):
    s = Path(row['path']).stat()
    if s.st_size != row['bytes'] or ('mtime_ns' in row and s.st_mtime_ns != row['mtime_ns']):
        raise ValueError('retained file stat mismatch: ' + row['path'])


def execute(argv, directory, cwd=None, timeout=240, env_overrides=None):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'command.json', dict(command=argv, cwd=str(cwd or W),
         timeout_seconds=timeout, environment_overrides=env_overrides or {}))
    tick = time.perf_counter()
    started = datetime.now(timezone.utc).isoformat()
    env = os.environ.copy()
    env.update(env_overrides or {})
    with (directory / 'stdout.log').open('wb') as stdout, (directory / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=cwd or W, env=env, stdout=stdout, stderr=stderr)
        save(directory / 'running.json', dict(pid=process.pid, started_utc=started))
        timed_out = False
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            process.wait()
    result = dict(pid=process.pid, exit=process.returncode, timeout=timed_out,
        started_utc=started, ended_utc=datetime.now(timezone.utc).isoformat(),
        seconds=time.perf_counter() - tick)
    save(directory / 'process.json', result)
    print(json.dumps(result), flush=True)
    return result


def require_success(process):
    if process['exit'] != 0 or process['timeout']:
        raise RuntimeError('actual command failed; preserve this attempt')


def verify():
    exact(P['source'])
    exact(P['original_ready'])
    exact(P['original_inputs'])
    exact(P['original_mlx_source'])
    return read(P['original_ready']['path'])


def compile_one():
    verify()
    obj = Path(P['object'])
    obj.parent.mkdir(parents=True, exist_ok=True)
    if obj.exists():
        raise FileExistsError(obj)
    process = execute(P['compile_command'], W / 'compile/logs', P['compile_cwd'])
    require_success(process)
    save(W / 'compiled.json', dict(source=exact(P['source']), object=pin(obj), process=process,
        recipe_origin=P['compile_recipe_origin'], dependencies=str(W / 'compile/dependencies.d')))


def isolate_archive():
    verify()
    compiled = read(W / 'compiled.json')
    require_success(compiled['process'])
    exact(compiled['object'])
    original = P['original_archive']
    stat_matches(original)
    original_pin = pin(original['path'])
    archive = Path(P['archive'])
    archive.parent.mkdir(parents=True, exist_ok=True)
    # Reuse only our existing private diagnostic archive, not the SDK archive.
    exact(P['reuse_archive'])
    listed = execute(['/usr/bin/ar', '-t', original['path']], W / 'archive/original-list', timeout=30)
    require_success(listed)
    old_members = (W / 'archive/original-list/stdout.log').read_text().splitlines()
    if old_members.count(P['member']) != 1:
        raise ValueError('original compile member is not unique')
    changed = execute(['/usr/bin/ar', '-r', str(archive), P['object']], W / 'archive/replace', timeout=30)
    require_success(changed)
    indexed = execute(['/usr/bin/ranlib', str(archive)], W / 'archive/ranlib', timeout=30)
    require_success(indexed)
    listed = execute(['/usr/bin/ar', '-t', str(archive)], W / 'archive/isolated-list', timeout=30)
    require_success(listed)
    new_members = (W / 'archive/isolated-list/stdout.log').read_text().splitlines()
    if Counter(old_members) != Counter(new_members):
        raise ValueError('archive member names/counts changed')
    extracted = execute(['/usr/bin/ar', '-p', str(archive), P['member']], W / 'archive/member-bytes', timeout=30)
    require_success(extracted)
    replacement_sha = hashlib.sha256((W / 'archive/member-bytes/stdout.log').read_bytes()).hexdigest()
    if replacement_sha != compiled['object']['sha256']:
        raise ValueError('archive does not contain the new exact compile object')
    stat_matches(original)
    if pin(original['path']) != original_pin:
        raise ValueError('original archive changed')
    save(W / 'archive.json', dict(original=original_pin, isolated=pin(archive), member=P['member'],
        member_count=len(new_members), replacement=compiled['object'], original_untouched=True,
        identity_note='Original SHA admitted now after the historical bytes/mtime receipt matched.'))


def link():
    ready = verify()
    compiled = read(W / 'compiled.json')
    require_success(compiled['process'])
    exact(compiled['object'])
    archive = read(W / 'archive.json')
    exact(archive['isolated'])
    old_rows = read(ready['inputs']['path'])
    rows = []
    changed = 0
    for row in old_rows:
        stat_matches(row)
        if row['path'] == P['original_archive']['path']:
            rows.append(archive['isolated'])
            changed += 1
        else:
            rows.append(row)
    if len(rows) != 120 or changed != 1:
        raise ValueError('link must retain 119 inputs and replace only libmlx.a')
    Path(P['image']).parent.mkdir(parents=True, exist_ok=True)
    process = execute(P['link_command'], W / 'link/logs')
    require_success(process)
    save(W / 'inputs.json', rows)
    save(W / 'ready.json', dict(image=pin(P['image']), inputs=pin(W / 'inputs.json'),
        original_ready=P['original_ready'], compiled=compiled, archive=archive,
        process=process, runtime=P['runtime'], counts=dict(CXX=1, links=1, inputs=120, retained=119),
        diagnostic_only=True))


def history():
    ready = read(W / 'ready.json')
    exact(ready['image'])
    exact(ready['inputs'])
    out = W / 'runs/history'
    argv = list(P['history_command'])
    argv[0] = ready['image']['path']
    process = execute(argv, out, env_overrides=P['runtime'])
    text = (out / 'stderr.log').read_text(errors='replace')
    tags = [line for line in text.splitlines() if 'HYLE_MLX_MAP_MISS' in line]
    save(out / 'observation.json', dict(status='FIXED_COMPILER_OBSERVED', process=process,
        tags=tags, image=ready['image'], expected_original_at_retained=True,
        other_Apple_arms_not_rerun=True, performance_claim=False))
    print(json.dumps(dict(tags=tags, native_exit=process['exit'])), flush=True)
    raise SystemExit(124 if process['timeout'] else process['exit'])


actions = dict(compile=compile_one, archive=isolate_archive, link=link, history=history)
if len(sys.argv) != 2 or sys.argv[1] not in actions:
    raise SystemExit('usage: driver.py compile|archive|link|history')
actions[sys.argv[1]]()
