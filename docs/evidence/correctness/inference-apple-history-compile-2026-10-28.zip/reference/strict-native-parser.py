"""Four finite original consumers. Parse existing output without rerunning it."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('native_program_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
ARMS = {kind: ('vulkan', flag) for kind, flag in [('logits', '--mtp-logits'),
    ('history', '--history-logits'), ('replay', '--history-replay'), ('control', '--history-control')]}


def prepare():
    plan = b.prepared()
    t.save(W / 'run-plan.json', dict(parser=t.pin(__file__), fixture=plan['fixture_manifest'],
        runtime=plan['runtime'], order=list(ARMS), actual_planned_model_processes=4,
        arms={arm: dict(backend=backend, flag=flag) for arm, (backend, flag) in ARMS.items()},
        scope='Four Vulkan-only cached synthetic Model consumers. CPU/CUDA use the separate 228-input image. Original modifier finite Graphs, exact I32 history finite Graphs, K1/K2 replay and bounded cancellation/restore. Missing native Scan/lowering is a real failure; no alternate operator, silent skip, or CPU fallback is added.'))
    print('PREPARED four finite process commands; no execution')


def parse_output(arm, backend, out, source_freeze):
    out = Path(out)
    proc = t.read(out / 'process.json')
    timeout = proc['timed_out'] if 'timed_out' in proc else proc['timeout']
    assert proc['exit'] == 0 and timeout is False, proc
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    by_case = {report['case']: report for report in reports}; assert len(reports) == len(by_case)
    cases = {'logits': 'mtp-logits-modifiers', 'history': 'history-logits', 'replay': 'history-replay', 'control': 'history-control'}
    expected = {'history-finite-math', 'history-logits'} if arm == 'history' else {cases[arm]}
    assert set(by_case) == expected, (arm, set(by_case))
    report = by_case[cases[arm]]
    assert report['status'] == 'PASS' and report['backend'] == backend and report['models'] == 1
    assert report['configurations'] == (1 if arm == 'control' else 2) and report['final_versions'] == 0
    assert report['quality_claim'] is False and report['performance_claim'] is False
    if arm == 'history':
        assert report['draft'] is True
        fields = ('K1_K2_greedy_random', 'derived_vs_manual_B2', 'StateOnly_no_counts_or_draw',
            'same_key_HostImage', 'full_hit_seed_before_frontier', 'synthetic_untrained')
        finite = by_case['history-finite-math']; assert finite['backend'] == backend and finite['result'] == 'PASS'
        assert (finite['neutral_nodes'], finite['hand_rows'], finite['duplicate_prefix_ids']) == (0, 4, 2)
        for field in ('p_q_bonus', 'negative_counts_rejected', 'masked_raw_nan_rejected', 'masked_raw_inf_rejected',
            'masked_bias_nan_rejected', 'readonly_counts', 'normalized_q_unchanged', 'count_above_2pow24_exact',
            'int32_overflow_rejected', 'managed_commands'): assert finite[field] is True, field
    elif arm == 'logits':
        assert report['finite_math_branches'] == 2 and report['numeric_q_failures'] == 2
        fields = ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
            'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage', 'prefix_frontier_numeric_failure',
            'new_prefix_policy_payload', 'strict_modifier_replay_rejected', 'historical_StateOnly_rebuild',
            'known_key_metadata_zero_native', 'same_key_retry', 'synthetic_untrained')
    elif arm == 'replay':
        fields = ('history_only', 'strict_K1_K2_greedy_random', 'StateOnly_history', 'HostImage_same_ledger',
            'post_replay_K1_K2', 'full_hit_explicit_C0', 'synthetic_untrained')
    else:
        fields = ('history_only', 'cancelled_B2_K2', 'whole_episode_retired', 'postsubmit_cancel_returned_normally',
            'peer_same_key_R1', 'committed_counts_only', 'escaped_readonly_C0', 'bounded_pool_refusal',
            'release_then_retry', 'idle_HostImage_restore', 'idle_resident_versions_zero', 'old_checkpoints_unchanged')
    for field in fields: assert report[field] is True, field
    checks = report['state_checks']; assert checks
    for check in checks:
        assert check['boundary_equal'] is True and check['numerically_equivalent'] is True
        assert check['payloads_byte_equal'] is True and check['differences'] == [], check
    t.save(out / 'report.json', by_case)
    t.save(out / 'summary.json', dict(status='PASS', arm=arm, process=proc, actual_state_checks=len(checks),
        all_payloads_byte_equal=True, report=t.pin(out / 'report.json'), source_freeze=t.pin(source_freeze),
        quality_claim=False, performance_claim=False))
    print('PARSED PASS', arm, proc['pid'], 'state_checks', len(checks))


def parse(arm):
    backend, _ = ARMS[arm]
    parse_output(arm, backend, W / 'runs' / arm, W / 'source-freeze.json')


def run(arm):
    plan, _ = b.validate(); rp = t.read(W / 'run-plan.json')
    for field in ('parser', 'fixture', 'runtime'): t.exact(rp[field])
    ready = t.read(W / 'ready.json'); t.exact(ready['image']); t.exact(ready['native_hardlink'])
    runtime = t.read(plan['runtime']['path']); assert os.path.samefile(runtime['native']['path'], runtime['hardlink_on_link'])
    backend, flag = ARMS[arm]; out = W / 'runs' / arm
    assert not out.exists(), 'Already attempted; retain raw process and parse offline'
    try:
        t.execute([ready['image']['path'], '--' + backend, plan['fixture'], flag], out, 300, runtime=True)
    finally:
        if (out / 'process.json').is_file():
            t.save(out / 'as-run.json', dict(ready=t.pin(W / 'ready.json'), image=ready['image'], inputs=ready['inputs'],
                source_freeze=ready['source_freeze'], run_plan=t.pin(W / 'run-plan.json'),
                native=ready['native_hardlink'], same_file=True, process=t.read(out / 'process.json')))
    parse(arm)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
