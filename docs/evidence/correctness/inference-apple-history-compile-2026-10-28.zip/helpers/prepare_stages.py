"""Prepare only first-broken-edge logs at the three MLX transformation stages."""
from pathlib import Path
import hashlib
import json
import difflib

W = Path(__file__).resolve().parent
D = W / 'stages'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-apple-history-compile-20261028'


def pin(path, remote=None):
    data = Path(path).read_bytes()
    return dict(path=remote or str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


CHECK = r'''// Scratch diagnostic only: borrow existing handles; never repair/evaluate.
static void hyle_diag_tape_stage(
    const char* stage,
    const std::vector<array>& tape,
    const std::vector<array>& trace_inputs,
    const ParentsMap& parents_map) {
  for (size_t oi = 0; oi < tape.size(); ++oi) {
    const auto& owner = tape[oi];
    for (size_t ii = 0; ii < owner.inputs().size(); ++ii) {
      const auto& input = owner.inputs()[ii];
      bool ready = false;
      for (const auto& trace_input : trace_inputs) {
        ready |= trace_input.id() == input.id();
      }
      for (size_t pi = 0; pi < oi && !ready; ++pi) {
        ready |= tape[pi].id() == input.id();
        for (const auto& sibling : tape[pi].siblings()) {
          ready |= sibling.id() == input.id();
        }
      }
      if (ready) {
        continue;
      }
      long long input_position = -1;
      const char* input_role = "absent";
      for (size_t pi = 0; pi < tape.size(); ++pi) {
        if (tape[pi].id() == input.id()) {
          input_position = static_cast<long long>(pi);
          input_role = "direct";
          break;
        }
        for (const auto& sibling : tape[pi].siblings()) {
          if (sibling.id() == input.id()) {
            input_position = static_cast<long long>(pi);
            input_role = "sibling";
            break;
          }
        }
        if (input_position >= 0) {
          break;
        }
      }
      const auto parents = parents_map.find(input.id());
      bool has_owner = false;
      if (parents != parents_map.end()) {
        for (const auto& parent : parents->second) {
          has_owner |= parent.first.id() == owner.id() && parent.second == ii;
        }
      }
      std::fprintf(stderr,
          "HYLE_MLX_STAGE first_broken=%s owner_position=%zu owner=%llu owner_name=%s input_port=%zu input=%llu input_name=%s input_position=%lld input_role=%s parent_map_has_key=%d parent_map_contains_owner=%d tape_size=%zu\n",
          stage, oi, static_cast<unsigned long long>(owner.id()),
          owner.has_primitive() ? owner.primitive().name() : "<none>", ii,
          static_cast<unsigned long long>(input.id()),
          input.has_primitive() ? input.primitive().name() : "<none>",
          input_position, input_role, int(parents != parents_map.end()), int(has_owner), tape.size());
      std::fflush(stderr);
      return; // Only the first broken edge per phase; preserve original execution.
    }
  }
}

'''


def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('non-unique stage insertion: ' + old)
    return text.replace(old, new, 1)


def main():
    source = W / 'details/source/compile.cpp'
    before = source.read_text(encoding='utf-8')
    if pin(source)['sha256'] != '72aba228fe396530ea5714a41853d26ec2294c0e4200d68b75b05490c3e2ca0e':
        raise ValueError('second diagnostic source changed')
    after = once(before, 'std::vector<array> compile_replace(\n', CHECK + 'std::vector<array> compile_replace(\n')
    for stage, statement in [
        ('dfs', '          compile_dfs(entry.inputs, entry.outputs, inputs);\n'),
        ('simplify', '            entry.tape, parents_map, entry.outputs, /* passes */ 3);\n'),
        ('fuse', '        compile_fuse(entry.tape, parents_map, entry.inputs, entry.outputs);\n')]:
        indent = '      ' if stage == 'dfs' else '        '
        after = once(after, statement, statement + indent +
            f'hyle_diag_tape_stage("{stage}", entry.tape, entry.inputs, parents_map);\n')
    if after.count('.at(') != 5 or '.outputs()' in CHECK:
        raise ValueError('original at or borrowed-array contract changed')
    D.mkdir(exist_ok=False)
    (D / 'source').mkdir()
    (D / 'source/compile.cpp').write_text(after, encoding='utf-8', newline='\n')
    (D / 'cast.patch').write_bytes((W / 'cast.patch').read_bytes())
    (D / 'diagnostic.patch').write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True), fromfile='dependency-diagnostic/compile.cpp',
        tofile='stage-diagnostic/compile.cpp')), encoding='utf-8', newline='\n')
    save(D / 'source.json', dict(source=pin(D / 'source/compile.cpp', REMOTE + '/stages/source/compile.cpp'),
        previous_source=pin(source), previous_model_process=json.loads((W / 'details/readback/runs/history/process.json').read_text(encoding='utf-8')),
        scope='First broken topological input per DFS/simplify/fuse phase; only borrowed handles and logging, original execution unchanged',
        original_five_at_retained=True, stage_patch=pin(D / 'diagnostic.patch')))
    plan = json.loads((W / 'details/plan.json').read_text(encoding='utf-8'))
    plan['source'] = pin(D / 'source/compile.cpp', REMOTE + '/stages/source/compile.cpp')
    plan['source_receipt'] = pin(D / 'source.json')
    plan['compile_command'] = [x.replace(REMOTE + '/details/', REMOTE + '/stages/') for x in plan['compile_command']]
    plan['object'] = REMOTE + '/stages/compile/compile.cpp.o'
    plan['image'] = REMOTE + '/stages/bin/tiny'
    plan['link_command'] = [x.replace(REMOTE + '/details/', REMOTE + '/stages/') for x in plan['link_command']]
    plan['reuse_archive'] = json.loads((W / 'details/readback/archive.json').read_text(encoding='utf-8'))['isolated']
    plan['scope'] = 'Third stage-consistency diagnostic; reuse the same private archive; both earlier source/object/image/log attempts retained'
    save(D / 'plan.json', plan)
    (D / 'driver.py').write_bytes((W / 'details/driver.py').read_bytes())
    print(json.dumps(dict(source=plan['source'], reuse_archive=plan['reuse_archive'], native_actions_performed=0)))


if __name__ == '__main__':
    main()
