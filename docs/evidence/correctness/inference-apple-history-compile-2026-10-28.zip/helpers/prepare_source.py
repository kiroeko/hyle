"""Prepare only the pinned MLX diagnostic source; never build, link, or run."""
from pathlib import Path
import difflib
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
ORIGINAL = Path('C:/public/project-hyle/mlx/mlx/compile.cpp')
PATCHES = R / 'third_party/mlx_cast/patches.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('diagnostic replacement is not unique: ' + before)
    return text.replace(before, after, 1)


def missing_check(indent, tag, original_line, map_name, key, extra_format, extra_args):
    return (
        f'{indent}if ({map_name}.find({key}) == {map_name}.end()) {{\n'
        f'{indent}  std::fprintf(stderr, "HYLE_MLX_MAP_MISS tag={tag} '
        f'original_line={original_line} key=%llu map_size=%zu {extra_format}\\n",\n'
        f'{indent}      static_cast<unsigned long long>({key}), '
        f'{map_name}.size(), {extra_args});\n'
        f'{indent}  std::fflush(stderr);\n'
        f'{indent}}}\n'
    )


def main():
    before = ORIGINAL.read_bytes()
    patches = json.loads(PATCHES.read_text(encoding='utf-8'))
    entry = next(row for row in patches['files'] if row['path'] == 'mlx/compile.cpp')
    if sha(before) != entry['before_sha256']:
        raise ValueError('original compile.cpp differs from the cast patch input')
    original = before.decode('utf-8')
    cast = original
    for edit in entry['edits']:
        cast = once(cast, edit['before'], edit['after'])
    if sha(cast.encode()) != entry['after_sha256']:
        raise ValueError('cast-patched source does not match the known patch output')

    result = once(cast, '#include <cstdlib>\n', '#include <cstdlib>\n#include <cstdio>\n')
    sites = [
        ('simplify-output', 687, 'output_map', 'o.id()', '      ',
         'output_count=%zu tape_count=%zu', 'outputs.size(), tape.size()',
         '    tape = std::move(new_tape);\n    for (auto& o : outputs) {\n',
         '      o = output_map.at(o.id());\n'),
        ('fuse-parent', 873, 'parents_map', 'a.id()', '        ',
         'depth=%lld cache_size=%zu', 'static_cast<long long>(depth), cache.size()',
         '        // recursion.\n',
         '        auto& parents = parents_map.at(a.id());\n'),
        ('fuse-output', 1043, 'output_map', 'o.id()', '    ',
         'output_count=%zu tape_count=%zu', 'outputs.size(), tape.size()',
         '  // Replace output with potentially compiled output\n  for (auto& o : outputs) {\n',
         '    o = output_map.at(o.id());\n'),
        ('replace-input', 1072, 'trace_to_real', 'in.id()', '        ',
         'owner=%llu input_count=%zu resolved_inputs=%zu',
         'static_cast<unsigned long long>(a.id()), a.inputs().size(), real_inputs.size()',
         '      for (auto& in : a.inputs()) {\n',
         '        real_inputs.push_back(trace_to_real.at(in.id()));\n'),
        ('replace-output', 1109, 'trace_to_real', 'o.id()', '    ',
         'trace_output_count=%zu resolved_outputs=%zu', 'trace_outputs.size(), outputs.size()',
         '  for (auto& o : trace_outputs) {\n',
         '    outputs.push_back(trace_to_real.at(o.id()));\n'),
    ]
    for tag, line, map_name, key, indent, fmt, args, context, statement in sites:
        result = once(result, context + statement,
                      context + missing_check(indent, tag, line, map_name, key, fmt, args) + statement)
    if result.count('.at(') != 5 or result.count('HYLE_MLX_MAP_MISS') != 5:
        raise ValueError('original five at calls or diagnostic sites were changed')

    source = W / 'source/compile.cpp'
    artifacts = {
        source: result.encode(),
        W / 'cast.patch': ''.join(difflib.unified_diff(original.splitlines(True), cast.splitlines(True),
            fromfile='original/mlx/compile.cpp', tofile='cast-patched/mlx/compile.cpp')).encode(),
        W / 'diagnostic.patch': ''.join(difflib.unified_diff(cast.splitlines(True), result.splitlines(True),
            fromfile='cast-patched/mlx/compile.cpp', tofile='diagnostic/mlx/compile.cpp')).encode(),
    }
    if any(path.exists() for path in [*artifacts, W / 'source.json']):
        raise FileExistsError('diagnostic source preparation already exists; retain it unchanged')
    source.parent.mkdir(parents=True, exist_ok=True)
    for path, data in artifacts.items():
        path.write_bytes(data)
    receipt = {
        'purpose': 'scratch-only MLX map-miss diagnostic; no CXX/link/run performed',
        'original': pin(ORIGINAL), 'cast_patch_manifest': pin(PATCHES),
        'cast_patched_sha256': entry['after_sha256'], 'source': pin(source),
        'cast_patch': pin(W / 'cast.patch'), 'diagnostic_patch': pin(W / 'diagnostic.patch'),
        'helper': pin(Path(__file__).resolve()),
        'sites': [{'tag': row[0], 'original_line': row[1]} for row in sites],
        'semantics': 'find/log only on missing key, then original at; no array copies, insertion, evaluation, or fallback',
        'remote_recipe_and_archive_admission': 'pending root-provided actual recipe/member information',
    }
    (W / 'source.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'source': receipt['source'], 'sites': len(sites), 'at_calls_retained': 5}))


if __name__ == '__main__':
    main()
