"""Original transport, clean compiler payload, and the existing finite parser."""
import importlib.util
import io
from pathlib import Path
import shlex
import sys
import zipfile

W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_mlx_transport', W / 'build.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.W = W / 'fixed'
base.REMOTE += '/fixed'


def sync():
    payload = io.BytesIO()
    with zipfile.ZipFile(payload, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name in ('driver.py', 'plan.json', 'source.json', 'source/compile.cpp', 'cast.patch', 'compiler-fix.patch'):
            z.write(base.W / name, name)
    script = "from pathlib import Path; import io,sys,zipfile; w=Path(" + repr(base.REMOTE) + "); w.mkdir(parents=True,exist_ok=False); z=zipfile.ZipFile(io.BytesIO(sys.stdin.buffer.read())); z.extractall(w); print(str(w))"
    base.transport('sync', ['ssh', '-o', 'BatchMode=yes', base.HOST, 'python3 -c ' + shlex.quote(script)], payload.getvalue(), 60)


def parse():
    path = W.parents[1] / '.scratch/inference-native-program-io-20261028/run.py'
    spec = importlib.util.spec_from_file_location('existing_native_history_parser', path)
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    parser.parse_output('history', 'apple', base.W / 'readback/runs/history', base.W / 'source.json')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('usage: fixed_build.py sync|compile|archive|link|history|fetch|parse')
    if sys.argv[1] == 'sync':
        sync()
    elif sys.argv[1] == 'parse':
        parse()
    elif sys.argv[1] == 'prepare':
        raise SystemExit('Run prepare_fixed.py once; original prepare is not used.')
    else:
        base.main()
