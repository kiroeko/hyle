"""Local metadata and root-only transport; nothing runs during import/prepare."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import io
import json
import shlex
import subprocess
import time
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-apple-history-compile-20261028'
HOST = 'kiro@172.22.10.198'
R3 = R / '.scratch/inference-native-program-io-20261028/apple/refinement3/readback-final/records'


def pin(path, remote=None):
    data = Path(path).read_bytes()
    return dict(path=remote or str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def prepare():
    inventory = json.loads((W / 'query/inventory.json').read_text())
    source = json.loads((W / 'source.json').read_text())
    ready = json.loads((R3 / 'ready.json').read_text())
    recipe, = inventory['compile_commands']
    old_source, = inventory['sources']
    if old_source['sha256'] != source['cast_patched_sha256']:
        raise ValueError('actual remote source differs from the original cast-patched source')
    argv = shlex.split(recipe['command'])
    if argv.count(recipe['file']) != 1 or argv.count('-o') != 1:
        raise ValueError('unexpected actual compile command')
    argv[argv.index(recipe['file'])] = REMOTE + '/source/compile.cpp'
    argv[argv.index('-o') + 1] = REMOTE + '/compile/compile.cpp.o'
    argv += ['-MMD', '-MF', REMOTE + '/compile/dependencies.d']
    link = json.loads((R3 / 'link/logs/command.json').read_text())['command']
    original_archive = inventory['libmlx_original_receipt']
    if link.count(original_archive['path']) != 1:
        raise ValueError('original link does not contain exactly one actual libmlx.a')
    link[link.index(original_archive['path'])] = REMOTE + '/lib/libmlx.a'
    link[link.index('-o') + 1] = REMOTE + '/bin/tiny'
    link = [('-Wl,-map,' + REMOTE + '/link/image.map') if x.startswith('-Wl,-map,') else x for x in link]
    run = json.loads((R3 / 'runs/history/command.json').read_text())['command']
    if run[1:] != ['--apple', inventory['fixture'], '--history-logits']:
        raise ValueError('unexpected original history command')
    save(W / 'plan.json', dict(scope='one MLX CXX, one isolated archive member replacement, same 120-input link, one history diagnostic',
        source=pin(W / 'source/compile.cpp', REMOTE + '/source/compile.cpp'),
        source_receipt=pin(W / 'source.json'), query=pin(W / 'query/inventory.json'),
        original_ready=pin(R3 / 'ready.json', str(Path(ready['image']['path']).parents[1] / 'ready.json').replace('\\', '/')),
        original_inputs=ready['inputs'], original_mlx_source=old_source,
        original_archive=original_archive, member='compile.cpp.o',
        compile_command=argv, compile_cwd=recipe['directory'], compile_recipe_origin=recipe,
        object=REMOTE + '/compile/compile.cpp.o', archive=REMOTE + '/lib/libmlx.a',
        link_command=link, image=REMOTE + '/bin/tiny', history_command=run,
        runtime=inventory['runtime_overrides'], fixture=inventory['fixture'],
        prior_Apple=dict(logits='PASS10', replay='PASS9', control='PASS2', history='FAIL cold .at; diagnostic only'),
        counts=dict(CXX=1, links=1, model_processes=1), performance_claim=False))
    print(str(W / 'plan.json'))


def transport(label, command, payload=None, timeout=300, binary_stdout=False):
    out = W / 'invocations' / label
    out.mkdir(parents=True, exist_ok=False)
    save(out / 'command.json', dict(command=command, timeout_seconds=timeout))
    tick = time.perf_counter()
    started = datetime.now(timezone.utc).isoformat()
    p = subprocess.Popen(command, stdin=subprocess.PIPE if payload is not None else subprocess.DEVNULL,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    timed_out = False
    try:
        stdout, stderr = p.communicate(payload, timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        p.kill()
        stdout, stderr = p.communicate()
    (out / ('stdout.zip' if binary_stdout else 'stdout.log')).write_bytes(stdout)
    (out / 'stderr.log').write_bytes(stderr)
    process = dict(pid=p.pid, exit=p.returncode, timeout=timed_out, started_utc=started,
        ended_utc=datetime.now(timezone.utc).isoformat(), seconds=time.perf_counter() - tick)
    save(out / 'process.json', process)
    print(json.dumps(process))
    if timed_out or p.returncode:
        raise SystemExit(124 if timed_out else p.returncode)
    return stdout


def sync():
    payload = io.BytesIO()
    with zipfile.ZipFile(payload, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name in ('driver.py', 'plan.json', 'source.json', 'source/compile.cpp', 'cast.patch', 'diagnostic.patch'):
            z.write(W / name, name)
    script = "from pathlib import Path; import io,sys,zipfile; w=Path(" + repr(REMOTE) + "); w.mkdir(parents=True,exist_ok=False); z=zipfile.ZipFile(io.BytesIO(sys.stdin.buffer.read())); z.extractall(w); print(str(w))"
    transport('sync', ['ssh', '-o', 'BatchMode=yes', HOST, 'python3 -c ' + shlex.quote(script)], payload.getvalue(), 60)


def fetch():
    script = """from pathlib import Path
import io,sys,zipfile
w=Path(REMOTE_PATH)
out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(w.rglob('*')):
  if p.is_file() and p.suffix in ('.json','.py','.patch','.cpp','.d','.log') and 'member-bytes' not in p.parts:
   z.write(p,str(p.relative_to(w)))
sys.stdout.buffer.write(out.getvalue())
""".replace('REMOTE_PATH', repr(REMOTE))
    data = transport('fetch', ['ssh', '-o', 'BatchMode=yes', HOST, 'python3 -c ' + shlex.quote(script)], timeout=60, binary_stdout=True)
    out = W / 'readback'
    out.mkdir(exist_ok=False)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        if z.testzip() is not None:
            raise ValueError('readback CRC failure')
        for name in z.namelist():
            if Path(name).is_absolute() or '..' in Path(name).parts:
                raise ValueError('unsafe readback path')
        z.extractall(out)
    print(str(out))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('prepare', 'sync', 'compile', 'archive', 'link', 'history', 'fetch'))
    action = parser.parse_args().action
    if action == 'prepare':
        prepare()
    elif action == 'sync':
        sync()
    elif action == 'fetch':
        fetch()
    else:
        transport(action, ['ssh', '-o', 'BatchMode=yes', HOST,
            'python3 ' + shlex.quote(REMOTE + '/driver.py') + ' ' + action], timeout=300)


if __name__ == '__main__':
    main()
