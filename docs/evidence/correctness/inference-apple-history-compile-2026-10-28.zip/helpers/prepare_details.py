"""Prepare the second, missing-dependency-only diagnostic; no native action."""
from pathlib import Path
import hashlib
import json
import difflib

W = Path(__file__).resolve().parent
D = W / 'details'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-apple-history-compile-20261028'


def pin(path, remote=None):
    data = Path(path).read_bytes()
    return dict(path=remote or str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


DETAILS = r'''          std::fprintf(stderr,
              "HYLE_MLX_DEP owner_name=%s owner_type=%s owner_primitive=%llu input_name=%s input_type=%s input_primitive=%llu input_has_primitive=%d input_available=%d input_tracer=%d input_siblings=%zu\n",
              a.primitive().name(), typeid(a.primitive()).name(),
              static_cast<unsigned long long>(a.primitive_id()),
              in.has_primitive() ? in.primitive().name() : "<none>",
              in.has_primitive() ? typeid(in.primitive()).name() : "<none>",
              static_cast<unsigned long long>(in.primitive_id()),
              int(in.has_primitive()), int(in.is_available()), int(in.is_tracer()), in.siblings().size());
          for (size_t ti = 0; ti < trace_inputs.size(); ++ti) {
            if (trace_inputs[ti].id() == in.id()) {
              std::fprintf(stderr, "HYLE_MLX_DEP trace_input_position=%zu\n", ti);
            }
          }
          for (size_t ti = 0; ti < trace_outputs.size(); ++ti) {
            if (trace_outputs[ti].id() == in.id()) {
              std::fprintf(stderr, "HYLE_MLX_DEP trace_output_position=%zu\n", ti);
            }
          }
          for (size_t ti = 0; ti < tape.size(); ++ti) {
            const auto& node = tape[ti];
            if (node.id() == a.id() || node.id() == in.id()) {
              std::fprintf(stderr,
                  "HYLE_MLX_DEP tape_position=%zu role=%s id=%llu name=%s siblings=%zu\n", ti,
                  node.id() == a.id() ? "owner" : "missing-direct",
                  static_cast<unsigned long long>(node.id()),
                  node.has_primitive() ? node.primitive().name() : "<none>", node.siblings().size());
            }
            for (size_t si = 0; si < node.siblings().size(); ++si) {
              const auto& sibling = node.siblings()[si];
              if (sibling.id() == in.id()) {
                std::fprintf(stderr,
                    "HYLE_MLX_DEP tape_position=%zu role=missing-sibling representative=%llu sibling_position=%zu representative_name=%s\n",
                    ti, static_cast<unsigned long long>(node.id()), si,
                    node.has_primitive() ? node.primitive().name() : "<none>");
              }
            }
          }
          for (size_t si = 0; si < in.siblings().size(); ++si) {
            const auto& sibling = in.siblings()[si];
            std::fprintf(stderr, "HYLE_MLX_DEP input_sibling=%zu id=%llu mapped=%d\n", si,
                static_cast<unsigned long long>(sibling.id()),
                int(trace_to_real.find(sibling.id()) != trace_to_real.end()));
          }
          for (size_t ii = 0; ii < in.inputs().size() && ii < 16; ++ii) {
            const auto& dependency = in.inputs()[ii];
            std::fprintf(stderr, "HYLE_MLX_DEP missing_input_dependency=%zu id=%llu name=%s mapped=%d\n", ii,
                static_cast<unsigned long long>(dependency.id()),
                dependency.has_primitive() ? dependency.primitive().name() : "<none>",
                int(trace_to_real.find(dependency.id()) != trace_to_real.end()));
          }
'''


def main():
    source = W / 'source/compile.cpp'
    if pin(source)['sha256'] != '3b95c9a087f88512d1c1ecc919f54bf98a3c8a9cd8acb7ccf3700558b433f44b':
        raise ValueError('first diagnostic source changed')
    before = source.read_text(encoding='utf-8')
    needle = '          std::fflush(stderr);\n        }\n        real_inputs.push_back(trace_to_real.at(in.id()));'
    if before.count(needle) != 1:
        raise ValueError('missing-input diagnostic block is not unique')
    after = before.replace(needle, DETAILS + needle, 1)
    # All inspections borrow existing arrays by reference. In particular, do not
    # call outputs(): it constructs a new vector of owning array handles.
    if after.count('.at(') != 5 or '.outputs()' in DETAILS:
        raise ValueError('original at calls or borrowed-array diagnostic changed')
    D.mkdir(exist_ok=False)
    (D / 'source').mkdir()
    (D / 'source/compile.cpp').write_text(after, encoding='utf-8', newline='\n')
    (D / 'cast.patch').write_bytes((W / 'cast.patch').read_bytes())
    (D / 'diagnostic.patch').write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True), fromfile='first-diagnostic/compile.cpp',
        tofile='dependency-diagnostic/compile.cpp')), encoding='utf-8', newline='\n')
    save(D / 'source.json', dict(source=pin(D / 'source/compile.cpp', REMOTE + '/details/source/compile.cpp'),
        previous_source=pin(source), previous_model_process=json.loads((W / 'readback/runs/history/process.json').read_text()),
        scope='Only missing-input metadata; no eval, outputs(), array copies, fallback, or math/order change',
        original_five_at_retained=True, details_patch=pin(D / 'diagnostic.patch')))
    plan = json.loads((W / 'plan.json').read_text())
    previous_archive = json.loads((W / 'readback/archive.json').read_text())['isolated']
    plan['source'] = pin(D / 'source/compile.cpp', REMOTE + '/details/source/compile.cpp')
    plan['source_receipt'] = pin(D / 'source.json')
    plan['compile_command'] = [x.replace(REMOTE + '/source/compile.cpp', REMOTE + '/details/source/compile.cpp')
        .replace(REMOTE + '/compile/', REMOTE + '/details/compile/') for x in plan['compile_command']]
    plan['object'] = REMOTE + '/details/compile/compile.cpp.o'
    plan['image'] = REMOTE + '/details/bin/tiny'
    plan['link_command'] = [x.replace(REMOTE + '/bin/tiny', plan['image'])
        .replace(REMOTE + '/link/image.map', REMOTE + '/details/link/image.map') for x in plan['link_command']]
    plan['reuse_archive'] = previous_archive
    plan['scope'] = 'second metadata-only diagnostic; reuse the one existing isolated archive; original first image/object/logs retained'
    save(D / 'plan.json', plan)
    driver = (W / 'driver.py').read_text()
    old = '''    if archive.exists():
        raise FileExistsError(archive)
    # The only binary copy: this one archive, never the SDK or original source.
    shutil.copy2(original['path'], archive)
    if pin(archive)['sha256'] != original_pin['sha256']:
        raise ValueError('isolated archive copy differs')
'''
    new = '''    # Reuse only our existing private diagnostic archive, not the SDK archive.
    exact(P['reuse_archive'])
'''
    if driver.count(old) != 1:
        raise ValueError('original archive-copy code changed')
    (D / 'driver.py').write_text(driver.replace(old, new, 1), encoding='utf-8', newline='\n')
    print(json.dumps(dict(source=plan['source'], reuse_archive=plan['reuse_archive'], native_actions_performed=0)))


if __name__ == '__main__':
    main()
