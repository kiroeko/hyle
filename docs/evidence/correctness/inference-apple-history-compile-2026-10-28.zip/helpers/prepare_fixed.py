"""Freeze only the clean compiler fix and reuse the original native recipes."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
D = W / 'fixed'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-apple-history-compile-20261028'


def pin(path, remote=None):
    data = Path(path).read_bytes()
    return dict(path=remote or str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    entry = next(x for x in json.loads((R / 'third_party/mlx_cast/patches.json').read_text(encoding='utf-8'))['files']
                 if x['path'] == 'mlx/compile.cpp')
    source = Path('C:/public/project-hyle/mlx/mlx/compile.cpp').read_bytes()
    if hashlib.sha256(source).hexdigest() != entry['before_sha256']:
        raise ValueError('original source pin changed')
    text = source.decode('utf-8')
    for edit in entry['edits']:
        if text.count(edit['before']) != 1:
            raise ValueError('non-unique exact product edit')
        text = text.replace(edit['before'], edit['after'], 1)
    if (hashlib.sha256(text.encode()).hexdigest() != entry['after_sha256'] or
            (D / 'source/compile.cpp').read_bytes() != text.encode() or 'HYLE_MLX_' in text):
        raise ValueError('clean fixed source differs from the exact product manifest')
    product = [pin(R / name) for name in ('third_party/mlx_cast/patches.json',
        'third_party/mlx_cast/NOTICE.md', 'cmake/HyleDependencyLock.json')]
    save(D / 'source.json', dict(source=pin(D / 'source/compile.cpp', REMOTE + '/fixed/source/compile.cpp'),
        before_sha256=entry['before_sha256'], cast_after_sha256='d228e64777bec074a04f37c7333bde88b53f33330063eb547768a75197f37a3c',
        fixed_after_sha256=entry['after_sha256'], products=product, added_compiler_lines=27,
        clean_fix=pin(D / 'compiler-fix.patch'), diagnostics=False,
        model_and_all_other_119_inputs='Retained original R3 frozen image closure; unrelated current engine changes are not compiled.',
        boundary='Final outputs/order and fused primitives retained; only outer graph scheduling is rebuilt, without evaluation/deep copy.',
        evidence_limit='Fusion was proven to break tape closure. Whether the observed Squeeze was dead or a still-live old branch was not separately established.'))
    plan = json.loads((W / 'stages/plan.json').read_text(encoding='utf-8'))
    plan['source'] = pin(D / 'source/compile.cpp', REMOTE + '/fixed/source/compile.cpp')
    plan['source_receipt'] = pin(D / 'source.json')
    plan['compile_command'] = [x.replace(REMOTE + '/stages/', REMOTE + '/fixed/') for x in plan['compile_command']]
    plan['object'] = REMOTE + '/fixed/compile/compile.cpp.o'
    plan['image'] = REMOTE + '/fixed/bin/tiny'
    plan['link_command'] = [x.replace(REMOTE + '/stages/', REMOTE + '/fixed/') for x in plan['link_command']]
    plan['reuse_archive'] = json.loads((W / 'stages/readback/archive.json').read_text(encoding='utf-8'))['isolated']
    plan['scope'] = 'Clean compiler fix; same isolated archive and 120-input current native consumer closure; only history is run'
    plan['diagnostics'] = False
    save(D / 'plan.json', plan)
    driver = (W / 'stages/driver.py').read_text(encoding='utf-8')
    driver = driver.replace("save(out / 'summary.json', dict(status='DIAGNOSTIC_OBSERVED'", 
                            "save(out / 'observation.json', dict(status='FIXED_COMPILER_OBSERVED'", 1)
    (D / 'driver.py').write_text(driver, encoding='utf-8', newline='\n')
    (D / 'cast.patch').write_bytes((W / 'cast.patch').read_bytes())
    print(json.dumps(dict(source=plan['source'], reuse_archive=plan['reuse_archive'], products=product,
        native_actions_performed=0)))


if __name__ == '__main__':
    main()
