"""Offline evidence only. No native/SSH/compiler/git action is performed."""
from pathlib import Path
import difflib
import hashlib
import json
import zlib
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-apple-history-compile-2026-10-28'
OLD = R / 'docs/evidence/correctness/inference-program-io-native-2026-10-28'
R3 = R / '.scratch/inference-native-program-io-20261028/apple/refinement3/readback-final/records'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def checked(row):
    actual = pin(row['path'])
    assert all(actual[key] == row[key] for key in ('bytes', 'sha256')), row['path']


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def main():
    output_json, output_zip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not output_json.exists() and not output_zip.exists(), 'Retain previous artifacts; do not overwrite'
    members = {}

    def add(name, data):
        assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
        assert b'\0' not in data, 'Unexpected binary payload: ' + name
        members[name] = data

    def file(name, path):
        add(name, Path(path).read_bytes())

    attempts = []
    labels = [('first', W), ('details', W / 'details'), ('stages', W / 'stages'), ('fixed', W / 'fixed')]
    for label, base in labels:
        records = base / 'readback'
        compiled, ready = read(records / 'compiled.json'), read(records / 'ready.json')
        model, link = read(records / 'runs/history/process.json'), read(records / 'link/logs/process.json')
        assert compiled['process']['exit'] == link['exit'] == 0
        assert not compiled['process']['timeout'] and not link['timeout'] and not model['timeout']
        assert model['exit'] == (0 if label == 'fixed' else 1)
        assert ready['counts'] == dict(CXX=1, links=1, inputs=120, retained=119)
        local_source = base / 'source/compile.cpp'
        assert sha(local_source.read_bytes()) == compiled['source']['sha256']
        stderr = (records / 'runs/history/stderr.log').read_text(encoding='utf-8')
        if label != 'fixed':
            assert 'tag=replace-input original_line=1072' in stderr and 'unordered_map::at: key not found' in stderr
        if label == 'stages':
            assert 'first_broken=fuse' in stderr
            assert 'first_broken=dfs' not in stderr and 'first_broken=simplify' not in stderr
        attempts.append(dict(attempt=label, CXX_pid=compiled['process']['pid'], link_pid=link['pid'],
            model_pid=model['pid'], model_exit=model['exit'], source_sha256=compiled['source']['sha256'],
            image_sha256=ready['image']['sha256']))
        for path in sorted(records.rglob('*')):
            if path.is_file():
                assert path.suffix in ('.json', '.py', '.cpp', '.patch', '.d', '.log'), path
                assert 'member-bytes' not in path.parts
                file('attempts/' + label + '/' + path.relative_to(records).as_posix(), path)
        invocations = base / 'invocations'
        for path in sorted(invocations.rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.log'):
                file('transport/' + label + '/' + path.relative_to(invocations).as_posix(), path)

    final = W / 'fixed/readback/runs/history'
    summary, report = read(final / 'summary.json'), read(final / 'report.json')
    assert summary['status'] == 'PASS' and summary['actual_state_checks'] == 17
    assert summary['process']['pid'] == 30563 and summary['all_payloads_byte_equal'] is True
    assert set(report) == {'history-finite-math', 'history-logits'}
    finite, journey = report['history-finite-math'], report['history-logits']
    assert finite['result'] == journey['status'] == 'PASS'
    assert finite['backend'] == journey['backend'] == 'apple'
    assert (finite['neutral_nodes'], finite['hand_rows'], finite['duplicate_prefix_ids']) == (0, 4, 2)
    finite_flags = ['p_q_bonus', 'negative_counts_rejected', 'masked_raw_nan_rejected', 'masked_raw_inf_rejected',
        'masked_bias_nan_rejected', 'readonly_counts', 'normalized_q_unchanged', 'count_above_2pow24_exact',
        'int32_overflow_rejected', 'managed_commands']
    assert all(finite[key] is True for key in finite_flags)
    assert journey['models'] == 1 and journey['configurations'] == 2 and journey['draft'] is True
    assert journey['final_versions'] == 0 and not journey['quality_claim'] and not journey['performance_claim']
    checks = journey['state_checks']
    assert len(checks) == 17
    assert all(c['boundary_equal'] and c['numerically_equivalent'] and c['payloads_byte_equal'] and c['differences'] == [] for c in checks)
    for key in ['K1_K2_greedy_random', 'derived_vs_manual_B2', 'StateOnly_no_counts_or_draw',
                'same_key_HostImage', 'full_hit_seed_before_frontier', 'synthetic_untrained']:
        assert journey[key] is True
    checked(summary['report'])
    checked(summary['source_freeze'])

    product = read(W / 'fixed/source.json')['products']
    for row in product:
        checked(row)
        file('product/' + Path(row['path']).relative_to(R).as_posix(), row['path'])
    original = Path('C:/public/project-hyle/mlx/mlx/compile.cpp')
    assert pin(original)['sha256'] == 'b95efbcaa0a0173d6d2184f43e49b75af43c376ab2eb970012ef344d694358f7'
    file('reference/original-compile.cpp', original)
    before = next(x for x in read(W / 'fixed/manifest-before.json')['files'] if x['path'] == 'mlx/compile.cpp')
    after = next(x for x in read(R / 'third_party/mlx_cast/patches.json')['files'] if x['path'] == 'mlx/compile.cpp')
    assert len(before['edits']) == 1 and len(after['edits']) == 2 and before['edits'][0] == after['edits'][0]
    add('product/compile-entry-before.json', encoded(before))
    add('product/compile-entry.diff', ''.join(difflib.unified_diff(encoded(before).decode().splitlines(True),
        encoded(after).decode().splitlines(True), fromfile='before/compile-entry.json', tofile='after/compile-entry.json')).encode())
    file('product/compiler-fix.patch', W / 'fixed/compiler-fix.patch')
    assert 'HYLE_MLX_' not in (W / 'fixed/source/compile.cpp').read_text(encoding='utf-8')

    old_json, old_zip = OLD.with_suffix('.json'), OLD.with_suffix('.zip')
    prior_summary = read(old_json)
    checked(prior_summary['archive'])
    previous = []
    with zipfile.ZipFile(old_zip) as archive:
        assert archive.testzip() is None
        for arm, count in [('logits', 10), ('replay', 9), ('control', 2)]:
            prefix = 'apple/refinement3/readback-final/records/runs/' + arm + '/'
            proc = json.loads(archive.read(prefix + 'process.json'))
            old_report = json.loads(archive.read(prefix + 'report.json'))
            value = next(v for v in old_report.values() if 'state_checks' in v)
            assert proc['exit'] == 0 and not proc['timeout']
            assert len(value['state_checks']) == count
            assert all(c['payloads_byte_equal'] and c['differences'] == [] for c in value['state_checks'])
            previous.append(dict(arm=arm, pid=proc['pid'], state_checks=count, rerun_with_fixed_MLX=False))
    prior = dict(summary=pin(old_json), archive=pin(old_zip), archive_CRC_verified=True,
        status_as_run=prior_summary['status'], retained_results=previous,
        image=read(R3 / 'ready.json')['image'], source_freeze=read(R3 / 'ready.json')['source_freeze'])
    add('reference/prior-evidence.json', encoded(prior))
    parser = R / '.scratch/inference-native-program-io-20261028/run.py'
    file('reference/strict-native-parser.py', parser)
    for name in ['qwen_history_logits_case.h', 'inference_history_math_case.h', 'qwen_host_image_test.cc']:
        source = R / '.scratch/inference-native-program-io-20261028/apple/refinement1/source/tests/tools' / name
        file('reference/frozen-consumer/' + name, source)
    for path in sorted(W.glob('*.py')):
        file('helpers/' + path.name, path)
    for name in ['inventory.json', 'command.json', 'process.json', 'stdout.log', 'stderr.log', 'remote.py']:
        file('query/' + name, W / 'query' / name)

    core = dict(schema=1, title='Apple history: fusion output-DAG tape reconstruction', date='2026-10-28', status='PASS_BOUNDED',
        result='The same frozen Apple history consumer passes after a clean one-TU MLX compiler fix.',
        actual_counts=dict(MLX_CXX=4, CXX_passed=4, links=4, links_passed=4, model_processes=4,
            diagnostic_exit1=3, fixed_exit0=1, other_consumer_or_SDK_TUs_recompiled=0, isolated_archive_copies=1),
        attempts=attempts,
        diagnosis=dict(confirmed='compile_replace lacked Squeeze -> LogicalOr input after fusion; DFS and simplify tape checks were closed.',
            bounds_mask='Less + GreaterEqual matches a checked index-bound predicate, not the Scan overflow predicate.',
            exact_local_parent_map_fault_identified=False, live_vs_dead_Squeeze_separately_proven=False,
            unrelated_sibling_order_change=False),
        fix=dict(added_cpp_lines=27, raw_source_before=before['before_sha256'], cast_patched_source=before['after_sha256'],
            clean_fixed_source=after['after_sha256'], product_files=product,
            contract='After output rewriting, schedule the final outer DAG in postorder; trace-input boundaries, sibling deduplication, all status outputs/order retained. No evaluation, deep-copy, fusion disable or new executor.',
            dependency_lock='hyle-apple-native-patches-v7; vendored tree 4fbeeba0f2a94d88fb610f27e2966da7741564ba93c2fdd8134edf8b5fa816b3'),
        fixed_history=dict(pid=30563, models=1, configurations=2, state_checks=17, all_payloads_byte_equal=True,
            groups=[dict(checks=4, coverage='Raw K1 and recursive K2 controls for greedy and random history policies'),
                    dict(checks=4, coverage='Same-key partial StateOnly HostImage restore, two members in derived/manual journeys'),
                    dict(checks=8, coverage='B2 derived C0 versus explicit manual counts over three Q1 chunks and a real generation round'),
                    dict(checks=1, coverage='Full-prefix hit seeds history before frontier sampling versus explicit C0')],
            finite=dict(hand_rows=4, duplicate_prefix_ids=2, neutral_nodes=0, checked_true=finite_flags), final_versions=0),
        prior_Apple_results=previous,
        cumulative_Apple_state_checks=dict(prior_image=21, fixed_image_new_history=17, total_across_two_images=38,
            all_38_rerun_on_fixed_image=False),
        provenance=dict(prior_evidence_summary=pin(old_json), prior_evidence_zip=pin(old_zip),
            fixed_image=read(W / 'fixed/readback/ready.json')['image'], link_inputs=120, retained_inputs=119,
            runtime=read(W / 'fixed/plan.json')['runtime'],
            compiler=read(W / 'query/inventory.json')['compiler_version']['stdout'].splitlines()[0],
            consumer='Original frozen R3 Tiny/weights/SDK closure; only libmlx compile.cpp member changed. Current unrelated engine changes are not represented.'),
        limits=['Finite cached synthetic input, one Apple M4 host; no trained quality or new native platform claim.',
                'No TPS, latency, peak-memory or cross-window performance claim; functional durations remain raw only.',
                'A still-live old pure branch may be scheduled separately from a fused kernel. Performance impact was not measured.',
                'The prior evidence remains partial as run. Its 21 passing checks are reused, not rerun with the fixed MLX image.',
                'Prior LLDB permission denial launched no target; it is recorded by the referenced prior evidence, outside these four model processes.',
                'No download, complete SDK rebuild, shader build, weights copy or new consumer compilation occurred in this batch.'])
    add('analysis.json', encoded(core))
    manifest_rows = [dict(name=name, bytes=len(data), sha256=sha(data), crc32=f'{zlib.crc32(data) & 0xffffffff:08x}')
                     for name, data in sorted(members.items())]
    manifest = encoded(dict(algorithm='SHA256 bytes and CRC32; all other members', members=manifest_rows))
    members['member-manifest.json'] = manifest
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output_zip, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 28, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    with zipfile.ZipFile(output_zip) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(members)
        for row in manifest_rows:
            data = archive.read(row['name'])
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            assert f'{zlib.crc32(data) & 0xffffffff:08x}' == row['crc32']
        assert archive.read('member-manifest.json') == manifest
    core['archive'] = dict(**pin(output_zip), members=len(members), member_manifest_sha256=sha(manifest),
        all_member_SHA256_and_CRC_readback=True, excludes='Binaries, object/archive payloads, SDK/weights/fixtures; prior complete evidence referenced by identity')
    output_json.write_bytes(encoded(core))
    receipt = dict(summary=pin(output_json), archive=core['archive'], native_actions_performed=0)
    (W / 'package-readback.json').write_bytes(encoded(receipt))
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
