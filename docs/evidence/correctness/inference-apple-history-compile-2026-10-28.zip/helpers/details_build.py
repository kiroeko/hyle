"""Reuse the original transport for the independent second diagnostic paths."""
import importlib.util
from pathlib import Path

W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_mlx_diagnostic_transport', W / 'build.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.W = W / 'details'
base.REMOTE += '/details'
if __name__ == '__main__':
    import sys
    if len(sys.argv) == 2 and sys.argv[1] == 'prepare':
        raise SystemExit('Run prepare_details.py once; original prepare is not used.')
    base.main()
