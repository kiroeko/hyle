"""Reuse 227 current SDK inputs; one fresh Tiny TU/link, four explicit cases."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
BASE = R / '.scratch/inference-packed-gdn-prefixes-20261029/model-link-base.json'
OLD = R / '.scratch/inference-mixed-lag-20261029'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
SOURCE = R / 'tests/tools/qwen_host_image_test.cc'
CASES = {'varlen-cpu': ('cpu','--mtp-varlen-verify'), 'varlen-cuda': ('cuda','--mtp-varlen-verify'),
         'mixed-cuda': ('cuda','--mtp-mixed-lag'), 'ragged-cpu': ('cpu','--mtp-ragged-prefill')}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name,path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


b = module(OLD / 'run.py','varlen_existing_tiny_recipe')
t = b.t
b.W = t.W = W
b.CASES = CASES
_validate = b.validate


def prepare():
    base = t.read(BASE); assert len(base['retained']) == 227
    retained_keys = {t.key(row['path']) for row in base['retained']}
    assert len(retained_keys) == 227
    for row in base['retained']: t.exact(row)
    compile_args = []
    for index,arg in enumerate(base['compile']):
        if index and base['compile'][index-1].casefold() == '/sourcedependencies': arg = str(W/'compile/tiny/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo'+str(W/'compile/tiny/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd'+str(W/'compile/tiny/unit.pdb')
        compile_args.append(arg)
    assert sum(t.key(arg) == t.key(SOURCE) for arg in compile_args) == 1
    consumer = [arg for arg in base['link'] if arg.casefold().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(consumer) == 1
    link_args = []
    for arg in base['link']:
        if t.key(arg) == t.key(consumer[0]): arg = str(W/'compile/tiny/unit.obj')
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(prefix): arg = prefix+str((W/'bin/tiny').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W/'compile/tiny/unit.obj') for arg in link_args) == 1
    assert all(sum(t.key(arg) == key for arg in link_args) == 1 for key in retained_keys)
    paths = {t.key(row['path']):row['path'] for row in t.read(OLD/'compile/tiny/compiled.json')['project_dependencies']}
    for rel in ('engine/models/qwen35/main.cc','engine/models/qwen35/execution_mode.h',
                'engine/inference/packed_rows.h','tests/tools/inference_packed_prefix_rows_case.h',
                'tests/tools/qwen_mtp_varlen_verify_case.h','tests/tools/qwen_host_image_test.cc'):
        paths[t.key(R/rel)] = str(R/rel)
    env = t.read(OLD/'environment.json'); env['PATH'] = str(W/'bin')+';'+env['PATH']
    t.save(W/'environment.json',env) # Local execution only; never archive its values.
    t.save(W/'plan.json',dict(base=t.pin(BASE), compile=compile_args, link=link_args,
        retained=base['retained'],runtime=base['runtime'],sources=list(paths.values()),
        fixture=t.pin(PLAIN/'weights.tsv'),prompt=t.pin(PLAIN/'prompt.ids'),
        helpers=[t.pin(__file__),t.pin(OLD/'run.py'),t.pin(R/'.scratch/inference-indexed-store-20261028/build.py')],
        cases={name:dict(backend=backend,flag=flag) for name,(backend,flag) in CASES.items()},
        counts=dict(CXX=1,links=1,SDK_CXX=0,NVCC=0,inputs=228,retained_inputs=227,native_processes=4,downloads=0)))
    print('PREPARED 227 retained SDK inputs, one fresh Tiny; no build/native executed')


def validate():
    plan = _validate()
    for row in plan['helpers']: t.exact(row)
    return plan


b.validate = validate
freeze = b.freeze
compile = b.compile
parse_compile = b.parse_compile
link = b.link


def parse(name):
    if name == 'mixed-cuda':
        b.parse(name); return
    backend,_ = CASES[name]; out = W/'runs'/name; process = t.read(out/'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if name.startswith('varlen-'):
        assert len(reports) == 2; host,report = reports
        assert host['status'] == 'PASS' and host['case'] == 'packed-prefix-rows' and host['models'] == 0 and host['manual_orders'] == 2
        for field in ('allocation_free_selector','zero_history','late_failure_preserves_outputs','overlap_preserves_outputs'):
            assert host[field] is True,field
        assert report['mode'] == 'mtp_varlen_verify' and report['models'] == 1 and report['requests'] == 2
        assert (report['physical_rows_per_member'],report['active_rows'],report['physical_rows']) == (3,4,6)
        assert report['length_orders'] == [[1,3],[3,1],[1,3]] and report['controlled_accepted'] == [[1,2],[3,1]]
        assert (report['target_submissions'],report['bounded_target_submissions']) == (11,3)
        assert report['natural_proposal_rows'] == [0,2] and report['natural_rng_draws'] == [1,5]
        for field in ('old_checkpoints_unchanged','accepted_prefixes_1_2_3','fixed_carrier_reused',
                      'engine_unequal_lengths_one_submission','original_q_identity_and_release','natural_R1_results_equal'):
            assert report[field] is True,field
        assert report['full_request_history_import_coverage'] is False and report['quality_claim'] is False
        assert len(report['natural_processed_target']) == len(report['natural_processed_draft']) == 2
        assert report['natural_processed_target'][0] == 1 and 1 <= report['natural_processed_target'][1] <= 3
        assert report['natural_processed_draft'][0] == 2 # Actual max0+lag1 repair, no discarded proposal.
        rows = report['state_checks']; assert len(rows) == 6
        t.save(out/'host-report.json',host)
    else:
        assert name == 'ragged-cpu' and len(reports) == 1; report = reports[0]
        assert report['mode'] == 'mtp_ragged_prefill' and report['width'] == 2 and len(report['batches']) == 7
        assert (report['actual_target_rows'],report['physical_target_rows'],report['committed_target_rows'],
                report['actual_draft_rows'],report['physical_draft_rows']) == (36,46,32,32,42)
        for field in ('actual_i32_selectors_checked','rng_and_epochs_equal','old_checkpoints_byte_unchanged'):
            assert report[field] is True,field
        assert report['final_images'] == report['final_native_episodes'] == 0
        assert report['gdn_state_absolute_budget'] == 3e-6 and report['natural_acceptance_claim'] is False
        rows = [member['state'] for batch in report['batches'] for member in batch['members']]
        assert len(rows) == 14
    assert report['status'] == 'PASS' and report['backend'] == backend and report['performance_claim'] is False
    assert report['synthetic_untrained'] is True and report['final_versions'] == 0
    b.check_states(report,rows)
    t.save(out/'report.json',report)
    print('PASS',name,'PID',process['pid'],'state comparisons',len(rows))


def run(name):
    plan = validate(); backend,flag = CASES[name]
    ready = t.read(W/'ready-tiny.json'); t.exact(ready['image']); t.exact(plan['fixture']); t.exact(plan['prompt'])
    t.execute([ready['image']['path'],'--'+backend,str(PLAIN),flag],W/'runs'/name,300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare','freeze','compile','parse_compile','link'): globals()[action]()
    elif action in ('run','parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
