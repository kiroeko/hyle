"""One current Tiny TU/link and four bounded cases; every action is explicit."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
BASE = R / '.scratch/inference-input-progress-20261029'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
SOURCE = R / 'tests/tools/qwen_host_image_test.cc'
SOURCES = ('engine/models/qwen35/main.cc', 'engine/models/qwen35/execution_mode.h',
    'engine/models/qwen35/mtp_graph.h', 'tests/tools/qwen_host_image_test.cc',
    'tests/tools/qwen_chunked_prefill_case.h', 'tests/tools/qwen_packed_prefill_case.h',
    'tests/tools/qwen_ragged_prefill_case.h', 'tests/tools/qwen_mtp_chunked_prefill_case.h',
    'tests/tools/qwen_mtp_packed_prefill_case.h', 'tests/tools/qwen_mtp_ragged_prefill_case.h',
    'tests/tools/qwen_mtp_mixed_lag_case.h')
CASES = {'mixed-cpu': ('cpu', '--mtp-mixed-lag'), 'mixed-cuda': ('cuda', '--mtp-mixed-lag'),
         'ragged-cuda': ('cuda', '--mtp-ragged-prefill'), 'chunked-cpu': ('cpu', '--mtp-chunked-prefill')}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'mixed_lag_recorder')
t.W = W


def prepare():
    prior = t.read(BASE / 'plan.json'); old = prior['units']['tiny']
    assert len(prior['retained']) == 227
    previous = t.read(BASE / 'ready-tiny.json')
    assert previous['inputs'] == prior['retained'] + [previous['compiled']['object']]
    for row in prior['retained']: t.exact(row)
    compile_args = []
    for index, arg in enumerate(old['compile']):
        if index and old['compile'][index - 1].casefold() == '/sourcedependencies': arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        compile_args.append(arg)
    assert sum(t.key(arg) == t.key(SOURCE) for arg in compile_args) == 1
    link_args = []
    for arg in old['link']:
        if t.key(arg) == t.key(previous['compiled']['object']['path']): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/tiny/unit.obj') for arg in link_args) == 1
    paths = {t.key(R / rel): str(R / rel) for rel in SOURCES}
    for row in previous['compiled']['project_dependencies']:
        path = t.canonical(row['path'])
        if t.project(path): paths[t.key(path)] = str(path)
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'plan.json', dict(base=t.pin(BASE / 'plan.json'), baseline_ready=t.pin(BASE / 'ready-tiny.json'),
        compile=compile_args, link=link_args, retained=prior['retained'], runtime=prior['runtime'],
        fixture=t.pin(PLAIN / 'weights.tsv'), prompt=t.pin(PLAIN / 'prompt.ids'), sources=list(paths.values()),
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=228, retained_inputs=227, native_processes=4, downloads=0)))
    print('PREPARED one Tiny CXX/link and four finite cases; no native process started')


def freeze():
    plan = t.read(W / 'plan.json')
    t.save(W / 'source-freeze.json', [t.pin(path) for path in plan['sources']])
    print('SOURCE FROZEN', len(plan['sources']))


def validate():
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    return t.read(W / 'plan.json')


def parse_compile():
    validate(); process = t.read(W / 'logs/compile-tiny/process.json')
    assert process['exit'] == 0 and process['state'] == 'TERMINAL' and not process['timed_out']
    deps = [t.pin(path) for path in t.dep_paths(W / 'compile/tiny/dependencies.json') if t.project(path)]
    t.save(W / 'compile/tiny/compiled.json', dict(source=t.pin(SOURCE), object=t.pin(W / 'compile/tiny/unit.obj'),
                                               process=process, project_dependencies=deps))
    print('CXX METADATA PASS', process['pid'])


def compile():
    plan = validate(); (W / 'compile/tiny').mkdir(parents=True)
    t.execute(plan['compile'], W / 'logs/compile-tiny', 300)
    parse_compile()


def link():
    plan = validate(); compiled = t.read(W / 'compile/tiny/compiled.json'); t.exact(compiled['object'])
    for row in plan['retained']: t.exact(row)
    t.exact(plan['runtime']); (W / 'bin').mkdir()
    alias = W / 'bin' / Path(plan['runtime']['path']).name
    alias.hardlink_to(plan['runtime']['path']); assert alias.samefile(plan['runtime']['path'])
    process = t.execute(plan['link'], W / 'logs/link-tiny', 240)
    t.save(W / 'ready-tiny.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=plan['retained'] + [compiled['object']],
        compiled=compiled, process=process, runtime=plan['runtime'], source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS', process['pid'])


def check_states(report, rows):
    assert rows and report['numerically_equivalent'] is True
    assert report['payloads_byte_equal'] == all(row['payloads_byte_equal'] for row in rows)
    for row in rows:
        assert row['boundary_equal'] is True and row['numerically_equivalent'] is True
        assert row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for difference in row['differences']:
            assert difference['role'] == 3 and difference['nonfinite_differences'] == 0
            assert 0 <= difference['maximum_absolute'] <= 3e-6


def parse(name):
    backend, _ = CASES[name]; out = W / 'runs' / name; process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 1; report = reports[0]
    assert report['status'] == 'PASS' and report['backend'] == backend and report['performance_claim'] is False
    assert report['synthetic_untrained'] is True and report['final_versions'] == 0
    if name.startswith('mixed-'):
        assert report['mode'] == 'mtp_mixed_lag' and report['requests'] == 2
        assert report['base_lags'] == [0, 1] and report['controlled_accepted'] == [1, 2]
        assert (report['mixed_target_submissions'], report['target_submissions'], report['target_rows_per_member'],
                report['actual_draft_rows'], report['physical_draft_rows']) == (2, 13, 2, 3, 4)
        assert report['hidden_indices'] == [0, 3, 1, 0] and report['token_indices'] == [2, 1, 3, 0]
        assert report['natural_processed_draft'] == [1, 2]
        for field in ('old_checkpoints_unchanged', 'StateOnly_no_pending_or_draw', 'natural_R1_results_equal',
                      'mixed_engine_single_submission', 'original_member_roles_committed', 'retired_head_rejected_before_prepare'):
            assert report[field] is True, field
        assert report['natural_acceptance_quality_claim'] is False and report['full_request_history_import_coverage'] is False
        rows = report['state_checks']
    elif name == 'ragged-cuda':
        assert report['mode'] == 'mtp_ragged_prefill' and report['width'] == 2 and len(report['batches']) == 7
        assert (report['actual_target_rows'], report['physical_target_rows'], report['committed_target_rows'],
                report['actual_draft_rows'], report['physical_draft_rows']) == (36, 46, 32, 32, 42)
        assert report['actual_i32_selectors_checked'] is True and report['rng_and_epochs_equal'] is True
        assert report['old_checkpoints_byte_unchanged'] is True and report['final_images'] == report['final_native_episodes'] == 0
        assert report['gdn_state_absolute_budget'] == 3e-6 and report['natural_acceptance_claim'] is False
        rows = [member['state'] for batch in report['batches'] for member in batch['members']]
    else:
        assert name == 'chunked-cpu' and report['mode'] == 'mtp_chunked_prefill'
        assert report['A']['state_only_commits'] == 3 and report['A']['no_early_output_or_prefix'] is True
        assert report['B']['parts'] == [2, 2, 1] and report['B']['host_restored_pending'] == -1
        assert (report['C']['state_only_target_rows'], report['C']['state_only_draft_rows'], report['C']['state_only_pending']) == (1, 2, -1)
        for field in ('old_checkpoints_byte_unchanged', 'partial_restore_byte_equal', 'state_only_score_sampler_id_ports_absent'):
            assert report[field] is True, field
        assert report['final_images'] == report['final_native_episodes'] == 0 and report['gdn_state_absolute_budget'] == 3e-6
        assert report['natural_acceptance_claim'] is False
        rows = [report[key]['comparison'] for key in ('A', 'B', 'C')]
    check_states(report, rows)
    t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'], 'state comparisons', len(rows))


def run(name):
    plan = validate(); backend, flag = CASES[name]
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image']); t.exact(plan['fixture']); t.exact(plan['prompt'])
    t.execute([ready['image']['path'], '--' + backend, str(PLAIN), flag], W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'freeze', 'compile', 'parse_compile', 'link'): globals()[action]()
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    elif action == 'package': module(W / 'package.py', 'mixed_lag_offline_package').main()
    else: raise ValueError(action)
