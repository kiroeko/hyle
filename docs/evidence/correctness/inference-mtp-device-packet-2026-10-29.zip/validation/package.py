"""Offline evidence for two actual Tiny versions; never compile or execute."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-mtp-device-packet-2026-10-29'
spec = importlib.util.spec_from_file_location('packet_evidence_reader', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t


def encode(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
def sha(body): return hashlib.sha256(body).hexdigest()
def terminal(process, exit=0):
    assert process['state'] == 'TERMINAL' and process['exit'] == exit and not process['timed_out'], process


def main():
    outjson, outzip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not outjson.exists() and not outzip.exists(), 'Preserve existing evidence'
    archive, stages, events, cases, failures, states = {}, {}, [], [], [], []

    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert path.name.casefold() != 'environment.json'
        assert path.suffix.lower() not in ('.exe', '.obj', '.dll', '.lib', '.pdb', '.bin', '.bf16', '.f32', '.gguf', '.safetensors')
        body = path.read_bytes()
        if name in archive: assert archive[name] == body, name
        else: archive[name] = body
        return name

    def logs(folder):
        for name in ('command.json', 'process.json', 'running.json', 'stdout.log', 'stderr.log'):
            path = folder / name
            if path.exists(): add(path)
        events.append(dict(record=folder.relative_to(W).as_posix(), process=t.read(folder / 'process.json')))

    for name in ('build.py', 'refine.py', 'package.py'): add(W / name)
    for name, directory in (('initial', W), ('refinement', W / 'refinement')):
        plan, frozen, compiled, ready = map(t.read, (directory / 'plan.json', directory / 'source-freeze.json',
            directory / 'compile/tiny/compiled.json', directory / 'ready-tiny.json'))
        pins = {t.key(row['path']): row for row in frozen}
        dependencies = {t.key(row['path']): row for row in compiled['project_dependencies']}
        assert len(pins) == len(dependencies) == 224 and pins == dependencies
        cxx, link = t.read(directory / 'logs/compile-tiny/process.json'), t.read(directory / 'logs/link-tiny/process.json')
        terminal(cxx); terminal(link)
        assert compiled['process'] == cxx and ready['compiled'] == compiled and ready['process'] == link
        assert t.command(directory / 'logs/compile-tiny/command.json') == plan['compile']
        assert t.command(directory / 'logs/link-tiny/command.json') == plan['link']
        assert len(plan['retained']) == 227 and ready['inputs'] == plan['retained'] + [compiled['object']]
        assert len(ready['inputs']) == len({t.key(row['path']) for row in ready['inputs']}) == 228
        t.exact(ready['source_freeze']); t.exact(plan['base']); t.exact(plan['fixture']); t.exact(plan['prompt'])
        for relative in ('plan.json', 'source-freeze.json', 'compile/tiny/compiled.json',
                         'compile/tiny/dependencies.json', 'ready-tiny.json'):
            add(directory / relative)
        logs(directory / 'logs/compile-tiny'); logs(directory / 'logs/link-tiny')
        stages[name] = dict(directory=directory, plan=plan, pins=pins, compiled=compiled, ready=ready, cxx=cxx, link=link)
    initial, refined = stages['initial'], stages['refinement']
    assert initial['plan']['retained'] == refined['plan']['retained']
    assert set(initial['pins']) == set(refined['pins'])
    changed = [key for key in initial['pins'] if initial['pins'][key] != refined['pins'][key]]
    assert set(changed) == {t.key(R / 'engine/models/qwen35/main.cc'), t.key(R / 'tests/tools/inference_mtp_packet_case.h')}
    for name, stage in stages.items():
        source_members = []
        for key, row in stage['pins'].items():
            relative = Path(row['path']).relative_to(R).as_posix()
            if key in changed:
                source = W / 'initial-replaced' / relative if name == 'initial' else Path(row['path'])
                member = 'source/' + name + '/' + relative
            else:
                source = Path(row['path']); member = 'source/common/' + relative
            body = source.read_bytes()
            assert len(body) == row['bytes'] and sha(body) == row['sha256'], source
            add(source, member)
            source_members.append(dict(**row, member=member))
        archive['source/' + name + '-224-members.json'] = encode(source_members)
    for row in refined['plan']['helpers']:
        t.exact(row)
        if t.key(row['path']) != t.key(W / 'build.py'):
            add(row['path'], 'helpers/' + Path(row['path']).relative_to(R).as_posix())
    add(refined['plan']['base']['path'], 'inherited/model-link-base.json')
    inherited = t.pin(R / 'docs/evidence/correctness/inference-varlen-verify-2026-10-29.json')
    order = [('initial', 'packet-cpu', 1), ('initial', 'varlen-cpu', 0), ('initial', 'varlen-cuda', 0),
             ('initial', 'logits-cpu', 1), ('refinement', 'packet-cpu', 0), ('refinement', 'packet-cuda', 0),
             ('refinement', 'logits-cpu', 0), ('refinement', 'logits-cuda', 0)]
    for ordinal, (stage_name, name, exit) in enumerate(order, 1):
        stage = stages[stage_name]; directory = stage['directory'] / 'runs' / name
        process = t.read(directory / 'process.json'); terminal(process, exit)
        backend, flag = b.CASES[name]
        command = t.command(directory / 'command.json')
        expected = [stage['ready']['image']['path'], '--' + backend]
        if flag != '--mtp-packet': expected.append(str(b.PLAIN))
        assert command == expected + [flag]
        logs(directory)
        if exit:
            assert not (directory / 'report.json').exists()
            diagnostic = (directory / 'stderr.log').read_text(encoding='utf-8-sig').strip().splitlines()[-1]
            failures.append(dict(ordinal=ordinal, stage=stage_name, name=name, process=process, diagnostic=diagnostic,
                outcome='FAILED_NOT_PASS', image=stage['ready']['image']))
            continue
        report = t.read(directory / 'report.json')
        raw = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert report['status'] == 'PASS' and report['backend'] == backend and report['performance_claim'] is False
        if name.startswith('varlen-'):
            host = t.read(directory / 'host-report.json'); assert raw == [host, report]
            assert host['status'] == 'PASS' and host['case'] == 'packed-prefix-rows' and host['models'] == 0
            for field in ('allocation_free_selector', 'zero_history', 'late_failure_preserves_outputs', 'overlap_preserves_outputs'):
                assert host[field] is True, field
            assert host['manual_orders'] == 2 and report['mode'] == 'mtp_varlen_verify'
            assert report['length_orders'] == [[1, 3], [3, 1], [1, 3]] and report['controlled_accepted'] == [[1, 2], [3, 1]]
            assert (report['models'], report['requests'], report['physical_rows_per_member'], report['active_rows'], report['physical_rows']) == (1, 2, 3, 4, 6)
            assert (report['target_submissions'], report['bounded_target_submissions']) == (11, 3)
            assert report['natural_proposal_rows'] == [0, 2] and report['natural_rng_draws'] == [1, 5]
            assert report['natural_processed_target'] == [1, 3] and report['natural_processed_draft'] == [2, 4]
            for field in ('old_checkpoints_unchanged', 'accepted_prefixes_1_2_3', 'fixed_carrier_reused',
                          'engine_unequal_lengths_one_submission', 'original_q_identity_and_release', 'natural_R1_results_equal'):
                assert report[field] is True, field
            assert report['full_request_history_import_coverage'] is False and report['quality_claim'] is False
            rows = report['state_checks']; assert len(rows) == 6
            b.b.check_states(report, rows); add(directory / 'host-report.json')
        else:
            assert raw == [report]
            if name.startswith('packet-'):
                assert report['case'] == 'mtp-packet'
                assert (report['models'], report['graphs'], report['native_submissions'], report['packet_readbacks']) == (0, 3, 14, 14)
                for field in ('host_oracle_exact', 'all_fixed_fields_checked', 'validated_ids_checked', 'quota_and_stop_checked',
                              'ignore_eos_and_extra_stop_checked', 'invalid_later_not_hidden', 'large_i32_ids_exact', 'real_retirement_checked'):
                    assert report[field] is True, field
                rows = []
            else:
                assert report['case'] == 'mtp-logits-modifiers'
                assert (report['models'], report['configurations'], report['finite_math_branches'], report['numeric_q_failures']) == (1, 2, 2, 2)
                for field in ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
                              'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage', 'prefix_frontier_numeric_failure',
                              'new_prefix_policy_payload', 'strict_modifier_replay_rejected', 'historical_StateOnly_rebuild',
                              'known_key_metadata_zero_native', 'same_key_retry', 'target_terminal_numeric_failure',
                              'target_terminal_retired_without_publish', 'target_terminal_resources_returned'):
                    assert report[field] is True, field
                rows = report['state_checks']; assert len(rows) == 10
            assert report['quality_claim'] is False
        for row in rows:
            assert row['boundary_equal'] is True and row['numerically_equivalent'] is True and row['exact_next'] == row['bucket_next']
            assert row['payloads_byte_equal'] == (not row['differences'])
            for part in row['differences']:
                assert part['role'] == 3 and part['nonfinite_differences'] == 0 and 0 <= part['maximum_absolute'] <= 3e-6
        if rows:
            assert report['synthetic_untrained'] is True and report['final_versions'] == 0
        states.extend(rows); add(directory / 'report.json')
        facts = {key: value for key, value in report.items() if not isinstance(value, (dict, list))}
        cases.append(dict(ordinal=ordinal, stage=stage_name, name=name, process=process, image=stage['ready']['image'],
                          state_comparisons=len(rows), facts=facts, report=t.pin(directory / 'report.json')))
    assert len(states) == 32 and len(cases) == 6 and len(failures) == 2
    assert len({(event['process']['pid'], event['process']['started']) for event in events}) == 12
    for name, row in (('weights.tsv', refined['plan']['fixture']), ('prompt.ids', refined['plan']['prompt'])):
        add(row['path'], 'fixture/' + name)
    archive['fixture/identity.json'] = encode(dict(manifest=refined['plan']['fixture'], prompt=refined['plan']['prompt'], payloads_included=False))
    manifest = encode([dict(name=name, bytes=len(body), sha256=sha(body)) for name, body in sorted(archive.items())])
    archive['MANIFEST.json'] = manifest
    outzip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, body in sorted(archive.items()): z.writestr(name, body)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and len(z.namelist()) == len(archive) and set(z.namelist()) == set(archive)
        for name, body in archive.items(): assert sha(z.read(name)) == sha(body), name
    exact = sum(row['payloads_byte_equal'] for row in states)
    differences = [part for row in states for part in row['differences']]
    result = dict(schema='hyle.correctness.mtp-device-packet.v1', date='2026-10-29', status='PASS_SIX_FINITE_CASES_ACROSS_TWO_IMAGES',
        change='Existing private sampled-prefix Graph folds accepted/quota/stop gates and returns one exact I32 decision packet; modifier profiles return one validated-ID packet.',
        counts=dict(CXX_attempts=2, successful_CXX=2, successful_links=2, native_attempts=8, successful_native=6, failed_native=2,
                    SDK_CXX=0, NVCC=0, downloads=0, inherited_SDK_inputs=227, inputs_per_image=228, project_sources_per_image=224),
        builds=[dict(stage=name, compile=stage['cxx'], link=stage['link'], image=stage['ready']['image'],
            main=stage['pins'][t.key(R / 'engine/models/qwen35/main.cc')], source_freeze=t.pin(stage['directory'] / 'source-freeze.json'),
            actual_sources_archive_member='source/' + name + '-224-members.json') for name, stage in stages.items()],
        refinement=dict(changed_sources=[str(Path(initial['pins'][key]['path']).relative_to(R)) for key in changed],
            reason='Bind the packet test Recipe independent dimension to exact zero; reshape greedy modifier TopK [1,1] IDs to the packet scalar [1] contract.',
            initial_passes_not_rerun=['varlen-cpu', 'varlen-cuda'], single_current_image_six_pass_claim=False),
        checks=dict(complete_state_comparisons=len(states), payload_byte_exact=exact, comparisons_with_GDN_rounding=len(states)-exact,
            GDN_absolute_budget=3e-6, maximum_observed_GDN_absolute_difference=max((part['maximum_absolute'] for part in differences), default=0),
            pure_packet_graph_submissions=28, pure_packet_readbacks=28),
        cases=cases, failures=failures, recorded_processes=events, inherited_SDK_evidence=inherited,
        limits=['Two actual images: initial varlen CPU/CUDA passed; corrected image packet CPU/CUDA and logits CPU/CUDA passed. Initial packet/logits CPU failures remain failed and are archived; this is not six passes on one current image.',
            'All 224 actual project source bodies for each image are preserved through versioned source-member maps; 222 identical bodies are shared and the two changed bodies are stored for both versions. SDK identity/recipes are retained without copying SDK binaries.',
            'Pure packet checks compare all I32 fields and actual consumed outputs with the original host oracle, including m0/m1/m2, quota/EOS/ignore-EOS/extra-stop, later invalidity and IDs above 2^24. They do not compute model distributions.',
            '32 synthetic full-state comparisons use the unchanged GDN-only absolute 3e-6 budget; all other payload/boundary comparisons remain exact. Logits cases check real terminal failure, retirement, no publication, resource recovery and same-key retry.',
            'This changes the existing private sampled-prefix decision fold/packet observation and modifier-profile packet, not ordinary greedy or K1 execution design. The private prefix episode and existing sampling/capture restrictions remain.',
            'No device KV commit, continuous MTP successor, full RequestLoop, trained quality, cross-platform or throughput claim. No environment values, weights, tensor payloads or SDK/executable/object binaries are archived.'],
        archive=dict(**t.pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', member_SHA256='PASS'))
    with outjson.open('xb') as out: out.write(encode(result))
    assert t.read(outjson)['checks']['complete_state_comparisons'] == 32
    receipt = dict(JSON=t.pin(outjson), ZIP=t.pin(outzip), members=len(archive), CRC='PASS', member_SHA256='PASS')
    t.save(W / 'package-readback.json', receipt); print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
