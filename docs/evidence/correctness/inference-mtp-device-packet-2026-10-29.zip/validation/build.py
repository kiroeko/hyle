"""One current Tiny CXX/link, six explicit finite consumers; no automatic retries."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OLD = R / '.scratch/inference-varlen-verify-20261029'
BASE = OLD / 'model-link-base.json'
PREVIOUS = OLD / 'refinement2/compile/tiny/compiled.json'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
SOURCE = R / 'tests/tools/qwen_host_image_test.cc'
CASES = {'packet-cpu': ('cpu', '--mtp-packet'), 'packet-cuda': ('cuda', '--mtp-packet'),
         'varlen-cpu': ('cpu', '--mtp-varlen-verify'), 'varlen-cuda': ('cuda', '--mtp-varlen-verify'),
         'logits-cpu': ('cpu', '--mtp-logits'), 'logits-cuda': ('cuda', '--mtp-logits')}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


v = module(OLD / 'build.py', 'device_packet_existing_varlen_parser')
b, t = v.b, v.t
v.W = b.W = t.W = W
v.CASES = b.CASES = CASES


def prepare():
    base = t.read(BASE); assert len(base['retained']) == 227
    retained_keys = {t.key(row['path']) for row in base['retained']}
    assert len(retained_keys) == 227
    for row in base['retained']: t.exact(row)
    compile_args = []
    for index, arg in enumerate(base['compile']):
        if index and base['compile'][index - 1].casefold() == '/sourcedependencies': arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        compile_args.append(arg)
    assert sum(t.key(arg) == t.key(SOURCE) for arg in compile_args) == 1
    consumers = [arg for arg in base['link'] if arg.casefold().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(consumers) == 1
    link_args = []
    for arg in base['link']:
        if t.key(arg) == t.key(consumers[0]): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/tiny/unit.obj') for arg in link_args) == 1
    assert all(sum(t.key(arg) == key for arg in link_args) == 1 for key in retained_keys)
    previous = t.read(PREVIOUS); assert len(previous['project_dependencies']) == 222
    paths = {t.key(row['path']): row['path'] for row in previous['project_dependencies']}
    for rel in ('engine/models/qwen35/main.cc', 'engine/inference/mtp_acceptance.h',
                'engine/inference/mtp_acceptance_graph.h', 'tests/tools/inference_mtp_packet_case.h',
                'tests/tools/qwen_host_image_test.cc'):
        paths[t.key(R / rel)] = str(R / rel)
    env = t.read(OLD / 'refinement2/environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local execution only, never archive values.
    t.save(W / 'plan.json', dict(base=t.pin(BASE), previous_consumer=t.pin(PREVIOUS),
        compile=compile_args, link=link_args, retained=base['retained'], runtime=base['runtime'],
        sources=list(paths.values()), fixture=t.pin(PLAIN / 'weights.tsv'), prompt=t.pin(PLAIN / 'prompt.ids'),
        helpers=[t.pin(__file__), t.pin(OLD / 'build.py'),
                 t.pin(R / '.scratch/inference-mixed-lag-20261029/run.py'),
                 t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        cases={name: dict(backend=backend, flag=flag, fixture=(flag != '--mtp-packet'))
               for name, (backend, flag) in CASES.items()},
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=228, retained_inputs=227,
                    native_processes=6, packet_graph_submissions_per_process=14, downloads=0)))
    print('PREPARED 227 retained SDK inputs, one fresh Tiny, six explicit processes; no compiler/native started')


def validate():
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    plan = t.read(W / 'plan.json')
    for row in plan['helpers']: t.exact(row)
    return plan


b.validate = validate
freeze = b.freeze
compile = b.compile
parse_compile = b.parse_compile
link = b.link


def parse(name):
    if name.startswith('varlen-'):
        # Same dual-JSON selector and model oracle, including all six original
        # state comparisons and the original GDN-only 3e-6 budget.
        v.parse(name)
        return
    backend, flag = CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    assert len(reports) == 1; report = reports[0]
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['quality_claim'] is False and report['performance_claim'] is False
    if flag == '--mtp-packet':
        assert report['case'] == 'mtp-packet'
        assert (report['models'], report['graphs'], report['native_submissions'], report['packet_readbacks']) == (0, 3, 14, 14)
        for field in ('host_oracle_exact', 'all_fixed_fields_checked', 'validated_ids_checked',
                      'quota_and_stop_checked', 'ignore_eos_and_extra_stop_checked',
                      'invalid_later_not_hidden', 'large_i32_ids_exact', 'real_retirement_checked'):
            assert report[field] is True, field
        rows = []
    else:
        assert flag == '--mtp-logits' and report['case'] == 'mtp-logits-modifiers'
        for field in ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
                      'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage',
                      'prefix_frontier_numeric_failure', 'new_prefix_policy_payload', 'strict_modifier_replay_rejected',
                      'historical_StateOnly_rebuild', 'known_key_metadata_zero_native', 'same_key_retry',
                      'target_terminal_numeric_failure', 'target_terminal_retired_without_publish',
                      'target_terminal_resources_returned', 'synthetic_untrained'):
            assert report[field] is True, field
        assert (report['models'], report['configurations'], report['finite_math_branches'],
                report['numeric_q_failures'], report['final_versions']) == (1, 2, 2, 2, 0)
        rows = report['state_checks']; assert len(rows) == 10
        # This report has no aggregate numeric/byte-equal fields. Audit its
        # actual original state rows instead of manufacturing missing values.
        for row in rows:
            assert row['boundary_equal'] is True and row['numerically_equivalent'] is True
            assert row['exact_next'] == row['bucket_next']
            assert row['payloads_byte_equal'] == (not row['differences'])
            for difference in row['differences']:
                assert difference['role'] == 3 and difference['nonfinite_differences'] == 0
                assert 0 <= difference['maximum_absolute'] <= 3e-6
    t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'], 'state comparisons', len(rows))


def run(name):
    plan = validate(); backend, flag = CASES[name]
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    args = [ready['image']['path'], '--' + backend]
    if flag != '--mtp-packet':
        t.exact(plan['fixture']); t.exact(plan['prompt']); args.append(str(PLAIN))
    args.append(flag)
    t.execute(args, W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'freeze', 'compile', 'parse_compile', 'link'): globals()[action]()
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
