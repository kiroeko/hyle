#include <filesystem>
#include <fstream>
#include <vector>
#include <cstdint>
#include <cstddef>
#include <climits>
#include <limits>
#include <locale>
#include <string_view>
#include <charconv>
#include <stdexcept>
#include <iostream>
#include <iomanip>
#include <string>
std::vector<std::int32_t> read_ids(const std::filesystem::path &path, std::int64_t vocabulary = INT32_MAX,
                                   std::size_t maximum_tokens = SIZE_MAX) {
  std::ifstream stream(path); if (!stream) throw std::runtime_error("cannot open token IDs");
  stream.imbue(std::locale::classic());
  if (vocabulary <= 0 || vocabulary > INT32_MAX) throw std::runtime_error("invalid token vocabulary");
  std::vector<std::int32_t> ids;
  // Every supported token ID fits in eleven characters including a sign.
  // Bound lexical input too; do not allocate for an arbitrarily long word.
  std::string word;
  while (stream >> std::setw(31) >> word) {
    const auto next = stream.peek();
    if (next != std::char_traits<char>::eof() &&
        std::string_view(" \t\r\n\f\v").find(static_cast<char>(next)) == std::string_view::npos)
      throw std::runtime_error("input token length exceeds 31 characters");
    if (ids.size() == maximum_tokens)
      throw std::runtime_error("input token count exceeds configured capacity");
    std::int64_t value = 0;
    const auto end = word.data() + word.size();
    const auto parsed = std::from_chars(word.data(), end, value);
    if (parsed.ec != std::errc{} || parsed.ptr != end) throw std::runtime_error("malformed input IDs");
    if (value < 0 || value >= vocabulary) throw std::runtime_error("input token outside vocabulary");
    ids.push_back(static_cast<std::int32_t>(value));
  }
  if (stream.bad() || !stream.eof()) throw std::runtime_error("malformed input IDs");
  return ids;
}

int main(int argc,char**argv){try{
 if(argc!=2)throw std::runtime_error("pass scratch dir");
 const std::filesystem::path root=argv[1];std::filesystem::create_directories(root);auto p=root/"tokens.ids";int checks=0;
 auto put=[&](std::string text){std::ofstream f(p,std::ios::binary);f<<text;};
 auto good=[&](std::string text,std::int64_t vocab,std::size_t cap,std::vector<std::int32_t>expected){put(text);if(read_ids(p,vocab,cap)!=expected)throw std::runtime_error("valid token result differs");++checks;};
 auto bad=[&](std::string text,std::int64_t vocab,std::size_t cap,std::string expected){put(text);try{(void)read_ids(p,vocab,cap);}catch(const std::runtime_error&e){if(std::string_view(e.what()).find(expected)!=std::string_view::npos){++checks;return;}throw;}throw std::runtime_error("bad token input accepted");};
 good("0 3\r\n",4,2,{0,3});good("0",1,1,{0});good("2147483646",INT32_MAX,1,{2147483646});good("",1,0,{});
 bad("4",4,2,"outside vocabulary");bad("-1",4,2,"outside vocabulary");bad("0",0,2,"invalid token vocabulary");bad("0 1 2",4,2,"exceeds configured capacity");
 bad("1 9223372036854775808",4,2,"malformed");bad("1 -9223372036854775809",4,2,"malformed");bad(std::string(80,'0'),4,2,"length exceeds");bad("1 2x",4,2,"malformed");bad("1.5",4,2,"malformed");bad("2147483647",INT32_MAX,1,"outside vocabulary");
 good("0\t1\n2\f3\v0\r",4,5,{0,1,2,3,0});good("3 0",4,2,{3,0});bad(std::string("1\0",2),4,2,"malformed");bad(std::string("1\0x",3),4,2,"malformed");
 std::cout<<"PASS "<<checks<<" actual read_ids boundary checks\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
