#include <filesystem>
#include <fstream>
#include <vector>
#include <cstdint>
#include <cstddef>
#include <climits>
#include <limits>
#include <locale>
#include <string_view>
#include <charconv>
#include <stdexcept>
#include <iostream>
std::vector<std::int32_t> read_ids(const std::filesystem::path &path, std::int64_t vocabulary = INT32_MAX) {
  std::ifstream stream(path); if (!stream) throw std::runtime_error("cannot open token IDs");
  std::vector<std::int32_t> ids; std::int64_t value = 0;
  while (stream >> value) {
    if (value < 0 || value >= vocabulary) throw std::runtime_error("input token outside vocabulary");
    ids.push_back(static_cast<std::int32_t>(value));
  }
  if (!stream.eof()) throw std::runtime_error("malformed input IDs");
  return ids;
}

int main(int argc,char**argv){if(argc!=2)return 2;const std::filesystem::path p=argv[1];
 {std::ofstream f(p);f<<"4";}auto a=read_ids(p);if(a!=std::vector<std::int32_t>{4})return 3;
 {std::ofstream f(p);f<<"1 9223372036854775808";}auto b=read_ids(p,4);if(b!=std::vector<std::int32_t>{1})return 4;
 {std::ofstream f(p);f<<"0 1 2";}auto c=read_ids(p,4);if(c.size()!=3)return 5;
 std::cout<<"REPRODUCED: default vocabulary accepted model-outside token; int64 overflow at EOF silently truncated final token; no per-read capacity bound\n";return 0;}
