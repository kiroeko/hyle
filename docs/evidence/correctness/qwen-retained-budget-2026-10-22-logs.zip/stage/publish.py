"""Publish bounded current-state evidence; never copies SDKs or model payloads."""
from pathlib import Path
import difflib,hashlib,json,zipfile
R=Path.cwd();S=Path(__file__).resolve().parent
OUT=R/'docs/evidence/correctness';OUT.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_bytes())
def identity(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def small_run(p):
    x=read(p)
    if 'record'in x:return dict(process=x['record'],output=json.loads(x['stdout']),report=x.get('report'))
    return x
main=identity(R/'tools/qwen35_text/main.cc');probe=identity(R/'tools/qwen35_text/retained_budget_probe.cc')
assert read(S/'compile1/main/identity.json')['source']['sha256']==main['sha256']
for label in ['consumer1','probe1']:
    plan=read(S/('apple-'+label+'-plan.json'));expected=probe if label=='probe1'else main
    source=next(x for x in plan['files']if x['path']==Path(expected['path']).relative_to(R).as_posix());assert source['sha256']==expected['sha256']
    assert read(S/('apple-'+label+'.json'))['all_exit_zero']
sources=['tools/qwen35_text/main.cc','tools/qwen35_text/retained_budget_probe.cc','tools/qwen35_text/CMakeLists.txt','tools/qwen35_text/README.md','docs/developer/current-work.md']
for name in sources:
    old=S/'before'/name;new=R/name
    if not old.is_file():continue
    diff=''.join(difflib.unified_diff(old.read_text(encoding='utf8').splitlines(keepends=True),new.read_text(encoding='utf8').splitlines(keepends=True),fromfile='before/'+name,tofile=name))
    target=S/'diff'/Path(name).with_suffix(Path(name).suffix+'.diff');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(diff,encoding='utf8')
cuda=[]
for mode in ['plain','mtp']:
    root=S/('cuda-'+mode);rec=read(root/'result.json');assert rec['exit']==0 and rec['state']=='terminal'
    cuda.append(dict(mode=mode,process=rec,output=read(root/'stdout.log'),comparison=read(root/'comparison.json')))
native=[]
for case in ['plain','mtp','N1R1','N2R2','probe']:
    x=small_run(S/('apple-'+case+'-run1.json'));assert x['process']['exit']==0 and x['process']['state']=='terminal'
    if case=='probe':assert x['report']['status']=='PASS_LIMITED_NATIVE_RETENTION_REJECTION_RETRY'
    else:x['comparison']=read(S/('apple-'+case+'-comparison.json'))
    native.append(dict(case=case,**x))
entries={}
for p in S.rglob('*'):
    if p.is_file()and p.suffix in ['.py','.json','.log','.diff','.md','.cc','.ps1','.txt']and 'vulkan'not in p.relative_to(S).parts:
        entries['stage/'+p.relative_to(S).as_posix()]=p
for label in ['consumer1','probe1']:
    for x in read(S/('apple-'+label+'-plan.json'))['files']:
        p=R/x['path'];assert identity(p)['sha256']==x['sha256'];entries['source/'+x['path']]=p
for name in sources:entries['source/'+name]=R/name
archive=OUT/'qwen-retained-budget-2026-10-22-logs.zip';inventory=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,p in sorted(entries.items()):
        raw=p.read_bytes();z.writestr(name,raw);inventory.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with zipfile.ZipFile(archive)as z:
    assert len(set(z.namelist()))==len(inventory)
    for x in inventory:
        raw=z.read(x['path']);assert len(raw)==x['bytes']and hashlib.sha256(raw).hexdigest()==x['sha256']
manifest=dict(schema='hyle.qwen-retained-budget.v1',date='2026-10-22',status='PASS_LIMITED_CONSUMER_RETENTION',
    scope=['Actual Qwen plain and greedy K1; 335 original MTP/target weights, original math and Graph retirement',
           'Selected 36 conv/GDN, carry/prior retained storage admitted before every take_append and head/ledger publication',
           'Shared backing admission reuses prior library mechanism; no payload copy, second executor or Provider vtable change'],
    changes=['CUDA keeps exact shared pool plan and same-scope idempotent charges',
             'Native auto has no byte limit; finite explicit cap uses actual pool and completed output admission, not CUDA capacity formula',
             'Unified Model-global cache report for single/scheduled plain and MTP; per-session copies of these figures must not be summed',
             'Only admitted retained output backings plus shared pools counted; weights, execution/private intermediate/driver peak remain outside'],
    sources=[identity(R/x)for x in sources],
    build=dict(CUDA_CXX=1,Apple_CXX=2,SDK_builds=0,NVCC=0,CMake_configure_run=False,
               CUDA=read(S/'cuda-link1/ready.json'),Apple_consumer=read(S/'apple-consumer1.json'),Apple_probe=read(S/'apple-probe1.json'),
               shared_common_libraries='docs/evidence/correctness/native-state-ownership-2026-10-22.json'),
    CUDA=cuda,Apple=native,
    limitations=['Finite C64/P15 or three-session/two-turn fixtures, not full numerical/model-quality validation',
                 'Quota pressure is a real budget Reservation after actual native completion; it does not allocate device bytes or simulate a device failure',
                 '52-component comparisons cover all committed logical KV ranges, states and hidden rows; unused physical KV tails are not read',
                 'No physical/driver/MLX execution peak cap; no new full TPS or GPU-memory side sampling',
                 'Apple prefix/native cancellation combinations and other selected MTP model/quantization profiles remain',
                 'Vulkan rotation/rebinding is separate implementation in progress, not covered by these passing native results'],
    read_only_reviews=[read(S/'review/integration-review.json'),read(S/'review/final-main-review.json')],
    archive=identity(archive),archive_entries=inventory)
cleanup=S/'cleanup-receipt.json'
if cleanup.is_file():
    receipt=json.loads(cleanup.read_text(encoding='utf-8-sig'))
    assert all(not Path(x['Path']).exists()for x in receipt['removed'])
    assert identity(R/'test.ps1')['sha256']==identity(S/'cleanup-test.ps1')['sha256']
    manifest['cleanup']=dict(receipt=receipt,script=identity(R/'test.ps1'),executed=True,do_not_rerun=True)
path=OUT/'qwen-retained-budget-2026-10-22.json';path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(manifest=identity(path),archive=identity(archive),entries=len(inventory),CUDA_runs=len(cuda),Apple_runs=len(native))))
