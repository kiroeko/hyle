"""Compile one consumer TU with current retained-state common libraries."""
from pathlib import Path
import argparse,base64,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('al_apple',R/'.scratch/qwen-native-assembly-20261022/apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
m=h.m;AJ=m.REMOTE;ROOT=m.BASE+'/qwen-retained-budget-20261022'
def build(revision,probe):
    remote=ROOT+('/probe'+str(revision) if probe else '/consumer'+str(revision));m.REMOTE=remote
    source='tools/qwen35_text/retained_budget_probe.cc'if probe else'tools/qwen35_text/main.cc'
    row=next(x for x in json.loads((R/'.scratch/native-paged-effects-20261022/apple/mac-cached-closure.json').read_bytes())['compile']if x['file'].endswith('/src/graph_route_apple/native_region.cc'))
    obj=remote+'/consumer.o';command=m.overlay_command(row,source,obj)
    files=[]
    for path in m.include_closure([source],[command]):
        entry=m.ident(path);entry['path']=path.relative_to(R).as_posix();entry['data']=base64.b64encode(path.read_bytes()).decode();files.append(entry)
    core=json.loads((R/'.scratch/native-state-ownership-20261022/apple-core2-plan.json').read_bytes())['libraries']
    link=json.loads((R/'.scratch/qwen-native-assembly-20261022/apple/revision4.json').read_bytes())['records'][1]['command']
    link=[obj if x==AJ+'/revision4/main.o'else next((l['path']for l in core if x==l['old']),x)for x in link]
    image=remote+'/qwen';link[link.index('-o')+1]=image
    payload=dict(remote=remote,sdk=m.SDK,files=files,actions=[['compile',command],['link',link]],image=image,metallib=AJ+'/mlx.metallib')
    name=('probe'if probe else'consumer')+str(revision)
    m.save(S/('apple-'+name+'-plan.json'),{**payload,'files':[{k:v for k,v in x.items()if k!='data'}for x in files]})
    result=m.ssh(r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);root.mkdir(parents=True);source=root/'source';source.mkdir()
for x in p['files']:
 target=source/x['path'];target.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(x['data']);assert len(raw)==x['bytes']and hashlib.sha256(raw).hexdigest()==x['sha256'];target.write_bytes(raw)
hardware={x:subprocess.check_output(['/usr/sbin/sysctl','-n',x],text=True).strip()for x in ['hw.model','hw.memsize']};assert hardware['hw.model']=='Mac16,12'
records=[]
for action,argv in p['actions']:
 record=dict(command=argv,cwd=p['sdk']+'/build',started=time.time())
 with(root/(action+'.stdout.log')).open('wb')as so,(root/(action+'.stderr.log')).open('wb')as se:
  child=subprocess.Popen(argv,cwd=record['cwd'],env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
 record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(root/(action+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 if child.returncode:break
result=dict(records=records,hardware=hardware,all_exit_zero=len(records)==len(p['actions'])and all(x['exit']==0 for x in records))
if result['all_exit_zero']:
 os.link(p['metallib'],root/'mlx.metallib');image=Path(p['image']);raw=image.read_bytes();result['image']=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
else:result['stderr']=(root/(p['actions'][len(records)-1][0]+'.stderr.log')).read_text(errors='replace')
(root/'ready.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
''',payload,timeout=240)
    m.save(S/('apple-'+name+'.json'),result);print(json.dumps(dict(all_exit_zero=result['all_exit_zero'],image=result.get('image'),records=[dict(exit=x['exit'],pid=x['pid'],seconds=x['seconds'])for x in result['records']],stderr=result.get('stderr'))))
    if not result['all_exit_zero']:raise SystemExit(1)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--revision',type=int,default=1);p.add_argument('--probe',action='store_true');a=p.parse_args();build(a.revision,a.probe)
