"""Incremental Qwen retained-budget consumer; reuse the original CUDA closure."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('al_host',R/'.scratch/native-paged-effects-20261022/build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
BASE=R/'.scratch/qwen-native-assembly-20261022/cuda-link3'
base=c.read(BASE/'link-plan.json')
main_record=R/'.scratch/qwen-native-assembly-20261022/compile3/main/identity.json'
h.S=S;h.RECIPES={'main':main_record};h.SOURCES={'main':R/'tools/qwen35_text/main.cc'}
def link(attempt):
    rec=c.read(S/f'compile{attempt}/main/identity.json')
    replacements={c.key(c.read(main_record)['object']['path']):rec['object']}
    ak=R/'.scratch/native-state-ownership-20261022'
    for old,new in [
      (R/'.scratch/architecture-refactor-2026-10-18/cold-copy-retirement/checks/20261019T053001-df70e294/src--compute--resource_budget-identity.json',ak/'compile1/budget/identity.json'),
      (R/'.scratch/paged-exclusive-20261021/compile1/leases/identity.json',ak/'compile2/leases/identity.json'),
      (R/'.scratch/native-paged-effects-20261022/compile1/resources/identity.json',ak/'compile1/resources/identity.json')]:
        replacements[c.key(c.read(old)['object']['path'])]=c.read(new)['object']
    for key in replacements:assert sum(c.key(x['path'])==key for x in base['inputs'])==1,key
    for x in base['inputs']:assert b.identity(x['path'])==x
    for x in replacements.values():assert b.identity(x['path'])==x
    out=S/f'cuda-link{attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'qwen.exe'
    command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,consumer=b.identity(S/f'compile{attempt}/main/identity.json'),base=b.identity(BASE/'link-plan.json'),SDK_builds=0,NVCC=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(BASE/'runtime-environment.json')
    for x in runtime['staged_dlls']:assert b.identity(x['path'])==x;os.link(x['path'],out/Path(x['path']).name)
    runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image),consumer=rec['source']))
    print('LINKED retained-budget CUDA consumer',flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['compile','link']);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    if a.action=='compile':h.compile_one('main',a.attempt)
    else:link(a.attempt)
