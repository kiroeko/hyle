# AK exact obsolete leaves. Already-run scripts must not be rerun.
$ErrorActionPreference = 'Stop'
$taskRoot = Join-Path $PSScriptRoot '.scratch/native-state-ownership-20261022'
$plan = Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') | ConvertFrom-Json
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'docs/evidence/correctness/native-state-ownership-2026-10-22.json') | ConvertFrom-Json
$archive = Join-Path $PSScriptRoot $manifest.evidence_archive.path
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.evidence_archive.sha256) { throw 'Evidence archive changed' }
$allowedRoot = [IO.Path]::GetFullPath($taskRoot).TrimEnd('\') + '\'
foreach ($item in $plan.windows) {
    $absolute = [IO.Path]::GetFullPath($item.path)
    if (-not $absolute.StartsWith($allowedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task: $absolute" }
    $file = Get-Item -LiteralPath $absolute -Force
    if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -ne $item.bytes -or (Get-FileHash -LiteralPath $absolute -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "Identity changed: $absolute" }
}
foreach ($item in $plan.windows) { Remove-Item -LiteralPath $item.path -Force }
python (Join-Path $taskRoot 'cleanup.py') native
if ($LASTEXITCODE -ne 0) { throw 'Native cleanup failed; inspect exact state before retry' }
Write-Output "Removed $($plan.windows.Count) Windows obsolete leaves and one native archive; no recursive delete."
