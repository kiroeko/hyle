"""Serial, finite retained-budget regressions. No TPS/performance conclusion."""
from pathlib import Path
import argparse,importlib.util,json,os,subprocess,time,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('al_run',S/'apple.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def save(path,value):h.m.save(path,value)
def check(before,now):
    keys=['generated_ids','actual_graph_calls','actual_target_rows','actual_draft_rows','committed_target_rows']
    if now.get('mtp'):keys+=['draft_frontier','draft_lag','rounds']
    values={k:before.get(k)==now.get(k)for k in keys};assert all(values.values()),values;return values
def cuda():
    root=S/'cuda-link1'
    for mode,folder in [('plain','text'),('mtp','mtp')]:
        out=S/('cuda-'+mode);out.mkdir();image=root/'qwen.exe'
        command=[str(image),'--inputs',str(R/'.scratch/qwen-native-assembly-20261022/inputs'/folder),'--steps','4','--capacity','64','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--mtp','on'if mode=='mtp'else'off']
        record=dict(command=command,cwd=str(R),started=time.time(),image=h.m.ident(image),performance_comparison=False)
        with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
            child=subprocess.Popen(command,cwd=R,env=dict(os.environ,PATH=json.loads((root/'runtime-environment.json').read_bytes())['PATH']),stdout=so,stderr=se);record.update(pid=child.pid,state='running');save(out/'command.json',record);save(S/'live.json',record);child.wait()
        record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);save(out/'result.json',record);save(S/'live.json',record)
        if child.returncode:print((out/'stderr.log').read_text(errors='replace')[-4000:]);raise SystemExit(1)
        now=json.loads((out/'stdout.log').read_bytes());before=json.loads((R/'.scratch/qwen-native-assembly-20261022'/('cuda-'+mode+'-current3')/'stdout.log').read_bytes())
        values=check(before,now);assert now['cache_live_requested_bytes']==now['cache_shared_backing_bytes'];assert now['cache_peak_requested_bytes']==now['cache_requested_byte_limit']
        save(out/'comparison.json',dict(fields=values,cache={k:v for k,v in now.items()if k.startswith('cache_')},before=h.m.ident(R/'.scratch/qwen-native-assembly-20261022'/('cuda-'+mode+'-current3')/'stdout.log')))
        print(json.dumps(dict(mode=mode,exit=record['exit'],seconds=record['seconds'],generated=now['generated_ids'],equal=values,live=now['cache_live_requested_bytes'])),flush=True)
def apple(case):
    root=h.ROOT;image=json.loads((S/('apple-probe1.json'if case=='probe'else'apple-consumer1.json')).read_bytes())['image']
    command=[image['path'],'--inputs',h.AJ+'/inputs/'+('text'if case=='plain'else'mtp')]
    if case=='probe':command+=['--out',root+'/probe-run1/observations']
    else:
        command+=['--mtp','off'if case=='plain'else'on','--capacity','64','--prefix-cache','off','--progress','direct','--replay','commands']
        if case in ['plain','mtp']:command+=['--steps','4','--max-sessions','1','--active-sequences','1','--cache-bytes',str(256*1024*1024)]
        else:command+=['--session-schedules',h.m.BASE+'/native-state-ownership-20261022/fixtures/sessions.txt','--max-sessions','1'if case=='N1R1'else'2','--active-sequences','1'if case=='N1R1'else'2','--cache-bytes',str(256*1024*1024)if case=='N1R1'else'auto']
    result=h.m.ssh(r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['root']);out=root/(p['case']+'-run1');out.mkdir()
image=Path(p['image']['path']);raw=image.read_bytes();assert hashlib.sha256(raw).hexdigest()==p['image']['sha256']
record=dict(command=p['command'],cwd=str(image.parent),image=p['image'],started=time.time(),performance_comparison=False)
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
 child=subprocess.Popen(p['command'],cwd=image.parent,env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_LIBRARY_PATH=p['sdk']+'/relocated/sdk/lib'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n')
result=dict(record=record,stdout=(out/'stdout.log').read_text(errors='replace'),stderr=(out/'stderr.log').read_text(errors='replace'))
if p['case']=='probe'and(out/'observations/observation.json').is_file():result['report']=json.loads((out/'observations/observation.json').read_text())
print(json.dumps(result))
''',dict(root=root,sdk=h.m.SDK,case=case,image=image,command=command),timeout=1800)
    save(S/('apple-'+case+'-run1.json'),result)
    if result['record']['exit']:print(json.dumps(result,ensure_ascii=False));raise SystemExit(1)
    if case=='probe':
        report=result['report'];print(json.dumps(dict(record=result['record'],status=report['status'],components=report['complete_old_components'],before=report['bytes_before_pressure'],released=report['bytes_after_pressure_release'],retained_output=report['actual_retained_output_backing_bytes'],retry=report['retry_matches_reference_whole_payload']),ensure_ascii=False));return
    now=json.loads(result['stdout']);fields={}
    if case in ['plain','mtp']:
        old_name='plain-run5.json' if case=='plain' else 'mtp-run2.json'
        before=json.loads(json.loads((R/'.scratch/qwen-native-assembly-20261022/apple'/old_name).read_bytes())['stdout']);fields=check(before,now)
    else:
        before=json.loads(json.loads((R/'.scratch/native-state-ownership-20261022'/(case+'-run1.json')).read_bytes())['stdout'])
        fields={k:now[k]==before[k]for k in ['actual_graph_calls','generated_tokens','restore_count','restored_graph_calls','restored_target_rows','restored_draft_rows','normalized_lag_rows','recomputed_decision_changes','idle_evictions']}
        fields['session_ids']=all(a['result']['generated_ids']==b['result']['generated_ids']for a,b in zip(now['sessions'],before['sessions']));assert all(fields.values()),fields
    assert now['cache_live_requested_bytes']>=now['cache_shared_backing_bytes'] and now['cache_peak_requested_bytes']>now['cache_shared_backing_bytes']
    save(S/('apple-'+case+'-comparison.json'),dict(fields=fields,cache={k:v for k,v in now.items()if k.startswith('cache_')},performance_comparison=False))
    print(json.dumps(dict(case=case,exit=result['record']['exit'],seconds=result['record']['seconds'],fields=fields,cache={k:v for k,v in now.items()if k.startswith('cache_')})),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('case',choices=['cuda','plain','mtp','N1R1','N2R2','probe']);a=p.parse_args();cuda()if a.case=='cuda'else apple(a.case)
