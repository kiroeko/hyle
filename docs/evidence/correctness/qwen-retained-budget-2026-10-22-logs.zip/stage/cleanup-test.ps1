# AL: exact rebuildable linker side products; latest image and objects stay.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = Join-Path $workspace '.scratch\qwen-retained-budget-20261022\cuda-link1'
$targets = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\cuda-link1\qwen.map'; Bytes = 59031932; SHA256 = '4cdf6d3f41b97c1935dcf8d597cf38c183170a13c26474db19668f9931c7dcb2' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\cuda-link1\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\cuda-link1\qwen.exp'; Bytes = 24978; SHA256 = '5b2455f96f33a79da3f4b4a34914b8ce0a80402988a320839db1955c21941335' }
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  if ($leaf.PSIsContainer -or $leaf.DirectoryName -ne $allowed -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
