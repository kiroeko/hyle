"""Offline MTP modifier evidence; requires actual successful receipts first.

Never compiles, links, starts a consumer, or substitutes missing results.
"""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import difflib
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
A = W / 'refinement'
DEST = R / 'docs/evidence/correctness/inference-mtp-logits-2026-10-28'
AUTHORS = R / '.scratch/inference-mtp-modifiers-20261028'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def pin(path):
    path = Path(path); value = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(value), sha256=hashlib.sha256(value).hexdigest())


def need(value, message):
    if not value: raise RuntimeError(message)


def actual_process(path):
    value = read(path)
    need(value['exit'] == 0 and not value['timed_out'], 'Actual failure/missing success: ' + str(path))
    return dict(pid=value['pid'], exit=value['exit'], seconds=value['seconds'])


def main():
    need(not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Do not overwrite evidence')
    freeze = read(A / 'source-freeze.json'); expected = read(freeze['expected']['path'])
    sources = []
    for entry in freeze['snapshots']:
        source = pin(entry['snapshot']['path'])
        need(source['sha256'] == entry['original']['sha256'], 'Frozen source snapshot mismatch')
        need(pin(entry['original']['path'])['sha256'] == source['sha256'], 'Canonical source changed after execution')
        sources.append(dict(source=entry['original']['path'], **source))
    need(len(expected) >= 6, 'Main/math/request factory/comment/new consumer/driver must be frozen')
    ready = read(A / 'ready-tiny.json'); compiled = ready['compiled']
    cxx = actual_process(A / 'logs/tiny/process.json'); link = actual_process(A / 'link/tiny/process.json')
    first_cxx = read(W / 'logs/tiny/process.json')
    need(first_cxx['pid'] == 48268 and first_cxx['exit'] == 2 and not first_cxx['timed_out'], 'Preserve original actual ADL CXX failure')
    first_output = (W / 'logs/tiny/stdout.log').read_bytes()
    need(b'C2668' in first_output, 'Missing actual compiler diagnostic')
    need(compiled['process']['pid'] == cxx['pid'] and ready['process']['pid'] == link['pid'], 'Build ready/receipt mismatch')
    inputs = read(ready['inputs']['path'])
    need(len(inputs) == 228 and sum(x['path'].casefold() == compiled['object']['path'].casefold() for x in inputs) == 1,
         'Exactly one current Tiny object must replace the retained 228-input object')
    runs = []
    for backend in ('cpu', 'cuda'):
        out = A / 'runs' / ('mods-' + backend); process = actual_process(out / 'process.json')
        summary, report = read(out / 'summary.json'), read(out / 'report.json')
        need(summary['status'] == 'PASS' and summary['process']['pid'] == process['pid'], 'Modifier parse incomplete')
        need(report['status'] == 'PASS' and report['backend'] == backend and report['case'] == 'mtp-logits-modifiers', 'Wrong actual case')
        for name in ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
                     'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage',
                     'prefix_frontier_numeric_failure', 'new_prefix_policy_payload', 'strict_modifier_replay_rejected',
                     'historical_StateOnly_rebuild', 'known_key_metadata_zero_native', 'same_key_retry'):
            need(report[name] is True, 'Missing actual modifier proof: ' + name)
        need((report['models'], report['configurations'], report['finite_math_branches'], report['numeric_q_failures'],
              report['final_versions']) == (1, 2, 2, 2, 0), 'Finite consumer scope differs')
        checks = report['state_checks']; need(len(checks) == 10, 'Expected ten actual state comparisons')
        need(all(x['boundary_equal'] and x['numerically_equivalent'] for x in checks), 'State oracle mismatch')
        differences = [part for item in checks for part in item['differences']]
        need(all(x['role'] == 3 and x['maximum_absolute'] <= 3e-6 and x['nonfinite_differences'] == 0 for x in differences),
             'Non-GDN/tolerance mismatch')
        runs.append(dict(backend=backend, **process, models=1, state_comparisons=len(checks),
            all_initialized_payloads_byte_equal=all(x['payloads_byte_equal'] for x in checks),
            max_recorded_GDN_absolute_difference=max([0.] + [x['maximum_absolute'] for x in differences]),
            other_initialized_payloads_exact=True, finite_math_branches=2, numeric_q_failures=2,
            original_B2_episode_guards=True, engine_live_versions=0,
            target_and_draft_page_inventories_fully_free=True, host_images_live=0))
    regressions = []
    for arm in ('sampler-cpu', 'preflight-cpu'):
        out = A / 'runs' / arm; process = actual_process(out / 'process.json')
        summary, report = read(out / 'summary.json'), read(out / 'report.json')
        need(summary['status'] == 'PASS' and summary['process']['pid'] == process['pid'], 'Regression parse incomplete')
        if arm == 'sampler-cpu':
            manual, natural, final = report['manual'], report['natural'], report['final']
            need(len(manual['state_checks']) == 17 and manual['completed_q_released'] is True and
                 manual['actual_B2_simultaneous_q'] == 4 and final['natural_recursive_cold_plan'] is True and
                 len(natural['sessions']) == 3, 'Original sampler regression differs')
            facts = dict(state_comparisons=17, actual_B2_simultaneous_q=4, sequential_models=2, natural_R=1, natural_configuration_groups=3)
        else:
            need(report['case'] == 'logits-preflight' and report['preflight_submissions'] == 0 and
                 report['typed_invalid_argument'] is True and report['original_key'] is True and
                 report['same_key_peer_continued'] is True and report['final_versions'] == 0,
                 'Original preflight regression differs')
            facts = dict(models=1, preflight_submissions=0, batch_position=report['batch_position'], key_slot=report['key_slot'])
        regressions.append(dict(arm=arm, **process, facts=facts))

    # Bounded object-local review, not a new SDK qualification/build.
    changed = {str(R / name).casefold(): name for name in expected}
    dependency_hits = []; missing = 0
    for row in inputs:
        dep = Path(row['path']).parent / 'dependencies.json'
        if not dep.exists(): missing += 1; continue
        data = read(dep).get('Data', {})
        hits = [changed[x.casefold()] for x in [data.get('Source', '')] + data.get('Includes', []) if x.casefold() in changed]
        if hits: dependency_hits.append(dict(object=row['path'], source=data.get('Source'), changed=sorted(set(hits))))
    need(missing == 105, 'Retained metadata inventory changed')
    prior_comment = subprocess.run(['git', 'show', '5e52d4a0e:engine/inference/evaluation_failure.h'], cwd=R,
        check=True, capture_output=True).stdout
    now_comment = (R / 'engine/inference/evaluation_failure.h').read_bytes()
    tokens = lambda value: re.sub(r'\s+', '', re.sub(r'//[^\n]*', '', value.decode('utf-8')))
    need(tokens(prior_comment) == tokens(now_comment), 'Retained weights dependency changed beyond comments')
    review = dict(inputs=228, missing_adjacent_dependency_metadata=missing, changed_header_users=dependency_hits,
        retained_weights_exception='evaluation_failure.h is comment-only; executable tokens are unchanged.',
        old_comment_header_sha256=hashlib.sha256(prior_comment).hexdigest(), current_comment_header=pin(R / 'engine/inference/evaluation_failure.h'),
        blanket_ABI_proof=False)
    (W / 'dependency-reuse-review.json').write_bytes(encoded(review))
    (W / 'evaluation-comment.diff').write_text(''.join(difflib.unified_diff(
        prior_comment.decode('utf-8').splitlines(True), now_comment.decode('utf-8').splitlines(True),
        fromfile='5e52d4a0e/evaluation_failure.h', tofile='current/evaluation_failure.h')), encoding='utf-8')

    members = {}; allowed = {'.py', '.json', '.log', '.xml', '.cc', '.h', '.diff', '.tsv'}

    def add(path, name=None):
        path = Path(path); name = name or path.relative_to(R).as_posix()
        need(path.is_file() and path.suffix.lower() in allowed, 'Missing/excluded member: ' + str(path))
        need(name not in members, 'Duplicate archive path: ' + name)
        members[name] = path.read_bytes()

    # This window only, explicit small roots; never traverse SDK/model trees.
    for attempt in (W, A):
        for path in sorted(attempt.iterdir()):
            if path.is_file() and path.suffix.lower() in {'.py', '.json', '.diff', '.log'}: add(path)
        for sub in ('compile', 'logs', 'link', 'runs'):
            if (attempt / sub).exists():
                for path in sorted((attempt / sub).rglob('*')):
                    if path.is_file() and path.suffix.lower() in {'.json', '.log', '.xml'}: add(path)
    for entry in freeze['snapshots']: add(entry['snapshot']['path'])
    old_freeze = read(W / 'source-freeze.json')
    old_test = next(x for x in old_freeze['snapshots'] if x['original']['path'].endswith('qwen_mtp_logits_case.h'))
    add(old_test['snapshot']['path'])
    old_text = Path(old_test['snapshot']['path']).read_text(encoding='utf-8')
    new_text = Path(next(x for x in freeze['snapshots'] if x['original']['path'].endswith('qwen_mtp_logits_case.h'))['snapshot']['path']).read_text(encoding='utf-8')
    need(new_text.replace('qwen_mtp_logits_case::unchanged(', 'unchanged(') == old_text, 'Retry source changed beyond ADL qualification')
    final_by_source = {x['original']['path']: x for x in freeze['snapshots']}
    equivalents = []
    for old in old_freeze['snapshots']:
        new = final_by_source[old['original']['path']]
        if old['original']['sha256'] == new['original']['sha256']:
            equivalents.append(dict(original_snapshot=old['snapshot'], archived_identical_snapshot=new['snapshot']))
    members['unchanged-initial-source-equivalence.json'] = encoded(equivalents)
    for sub in ('product-main', 'sampling-graph'):
        for path in sorted((AUTHORS / sub).iterdir()):
            if path.is_file() and path.suffix.lower() in {'.py', '.json', '.diff'}: add(path)
    # The new case's independent Philox oracle is an original small test
    # source; it is not a second executor or a copied SDK dependency tree.
    oracle = R / 'tests/compute_models/sampling_fixture.h'
    actual_deps = {x['path'].casefold(): x for x in read(A / 'compile/tiny/actual-project-dependencies.json')}
    need(pin(oracle)['sha256'] == actual_deps[str(oracle).casefold()]['sha256'], 'Actual oracle source drift')
    for entry in freeze['snapshots']:
        need(entry['original']['sha256'] == actual_deps[entry['original']['path'].casefold()]['sha256'], 'Actual source dependency mismatch')
    add(oracle, 'shared/tests/compute_models/sampling_fixture.h')
    run_plan = read(A / 'run-plan.json'); fixture = run_plan['fixture_manifest']
    need(pin(fixture['path'])['sha256'] == fixture['sha256'], 'Cached fixture manifest drift')
    add(fixture['path'], 'fixture/weights.tsv')
    retained = R / '.scratch/inference-mtp-sampling-20261028/refinement-v4'
    for name in ('build.py', 'run.py'): add(retained / name, 'retained-tools/sampling-' + name)
    add(R / '.scratch/inference-indexed-store-20261028/build.py', 'retained-tools/base-build.py')
    references = []
    for name in ('inference-mtp-request-sampling-2026-10-28.json', 'inference-logits-preflight-2026-10-28.json'):
        path = R / 'docs/evidence/correctness' / name; references.append(pin(path)); add(path, 'references/' + name)
    add(retained / 'ready-tiny.json', 'references/baseline-ready-tiny.json')
    add(read(retained / 'ready-tiny.json')['inputs']['path'], 'references/baseline-inputs-tiny.json')
    evidence = dict(status='PASS_BOUNDED_MTP_REQUEST_MODIFIERS', created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        baseline='5e52d4a0e; retained sampling-v4 228-input CPU/CUDA consumer closure',
        sources=sources, counts=dict(actual_CXX=2, successful_CXX=1, failed_CXX=1, actual_links=1, successful_links=1,
            actual_model_processes=4, successful_model_processes=4, sequential_model_instances=5,
            standalone_Model_CXX=0, SDK_CXX=0, NVCC=0, downloads=0),
        build=dict(failed_initial_CXX=first_cxx, successful_CXX=cxx, link=link, inputs=228, original_inputs_reused=227,
            image=ready['image'], ready=pin(A / 'ready-tiny.json'), actual_dependencies=pin(A / 'compile/tiny/dependencies.json')),
        retained_failure=dict(cause='C2668: two unqualified test unchanged calls collided with SavedRequest ADL.',
            correction='Only qualify those two test calls; no product, oracle assertion, driver or runtime-policy change.',
            failed_case_sha256=old_test['original']['sha256'], retry_case_sha256=final_by_source[old_test['original']['path']]['original']['sha256'],
            patch=pin(A / 'source-refinement.diff'), model_processes_before_correction=0),
        modifier_runs=runs, regressions=regressions,
        finite_math=dict(branches_per_backend=2, submissions_per_backend=2, total_submissions=4,
            reference='Independent double probability normalization and original test Philox; CPU inverse-CDF / CUDA Gumbel checked against actual residual-rejection and bonus-acceptance branches.',
            repeat_transform_distinguished='Finite identity search chooses draws that differ if q or bonus is incorrectly processed twice; the normalized q input stays unchanged.'),
        graph_contract=['process_logits extracts the original raw NaN/+Inf and finite-bias checks before allowed-mask application.',
            'Empty modifiers return raw/nullopt before Recipe work; original distribution and decision mathematics remain source-identical after EOL normalization.',
            'Processed distribution/selection join raw pre-mask and post-processing validity. Each target conditional row receives the same admitted snapshot; normalized q_i is never transformed again.',
            'Caller reuses one processed distribution for stochastic selection/threshold. Greedy recursive modifiers use real per-row IDs/valid flags, without q/RNG ports.'],
        ownership_contract=['One original ready [1,V] ReadLease snapshot per episode, copied into call/Step; replacing request payload after prepare cannot replace the admitted guards.',
            'Original Model/Graph/Queue/Completion, successful q retirement and checked R*bound pools remain the only execution/resource owners.',
            'Explicit numeric flag0 maps only to an original member or known complete key after real private-validator retirement; native/unknown/pending errors remain unqualified.',
            'Modifier payload is not in KV/ledger/HostImage history. Strict modifier replay rejects; committed-token StateOnly rebuild restores the recorded pending/cursor.'],
        preparation=dict(exclusive_save_FileExists='Root reported initial refinement of prepared metadata hit exclusive save; no CXX/link/model was started, original preparation-before receipts retained.',
            common_math_EOL_check='A separate static source comparison required CRLF/LF normalization; its original attempt and correction are retained, no compile/runtime failure.',
            archive_only_encoding='Initial package helper tried UTF-8 for the original MSVC Chinese raw log; it now checks ASCII diagnostic bytes without re-encoding the archived log. No archive or consumer was produced by that failed packaging call.',
            offline_summary_KeyError='Root temporary statistics guessed bytes_equal rather than actual payloads_byte_equal; corrected by reading the existing reports, with no model rerun.'),
        dependency_reuse='No public SDK layout/vtable changed. Adjacent actualdeps identify the replaced Tiny plus retained weights (evaluation_failure.h comment-only, executable tokens equal). 105/228 inputs lack adjacent MSVC metadata; no blanket dependency/ABI proof is claimed. See dependency-reuse-review.json.',
        limits=['Cached untrained GA/H64/V64/C16; no quality, acceptance-rate, target-only random trajectory or new upstream claim.',
            'CPU/CUDA finite consumers only; no cross-backend bit identity or new Apple/Vulkan/native fault proof.',
            'Mask/bias is one immutable per-episode [1,V] snapshot; no per-prefix grammar, changing penalty/history table or MTP cross-episode overlap is implemented.',
            'GDN-only inherited absolute tolerance is 3e-6; all other initialized state roles remain exact. Actual payload equality is listed separately.',
            'No performance window or TPS claim; recorded process durations are provenance only. Engine inventory/live-version checks do not imply native allocator live-zero.'],
        references=references, reproduction=dict(directory=A.relative_to(R).as_posix(),
            actions='build.py compile; build.py link; run.py run mods-cpu; mods-cuda; sampler-cpu; preflight-cpu',
            failures='Every action single-use. Preserve failure; use run.py parse ARM offline, never rerun a successful process for parser repair.'),
        implementation_scope='Per-episode bias and allowed-mask only. Row/prefix-dependent grammar and history-dependent penalties remain design work, not implemented evidence.',
        raw_manifest='manifest.json')
    members['evidence-core.json'] = encoded(evidence)
    members['manifest.json'] = encoded(dict(files=[dict(path=name, bytes=len(value), sha256=hashlib.sha256(value).hexdigest())
        for name, value in sorted(members.items())], excluded=['EXE/OBJ/PDB/DLL/LIB/binary', 'SDK/source trees', 'model payload', 'unrelated user docs/license']))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, value in sorted(members.items()): archive.writestr(name, value)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        need(archive.testzip() is None and set(archive.namelist()) == set(members), 'ZIP CRC/member mismatch')
        for name, value in members.items(): need(archive.read(name) == value, 'ZIP readback mismatch: ' + name)
    evidence['archive'] = dict(pin(DEST.with_suffix('.zip')), files=len(members), verified_readback=True)
    DEST.with_suffix('.json').write_bytes(encoded(evidence))
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')), archive=evidence['archive'], counts=evidence['counts']), indent=2))


if __name__ == '__main__':
    main()
