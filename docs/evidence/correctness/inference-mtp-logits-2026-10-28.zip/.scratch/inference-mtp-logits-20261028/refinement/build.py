"""Reuse the retained Tiny closure; compilation and linking are explicit actions."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
BASE = R / '.scratch/inference-mtp-sampling-20261028/refinement-v4'
spec = importlib.util.spec_from_file_location('retained_sampling_build', BASE / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W, b.R, b.BASE, b.t.W = W, R, BASE, W
t = b.t


def prepare():
    b.prepare()
    refine_plan()


def refine_plan():
    assert not (W / 'source-freeze.json').exists()
    plan = b.prepared()
    runtime = t.read(W / 'runtime-plan.json')
    t.save(W / 'preparation-before-runtime.json', runtime)
    t.save(W / 'preparation-before-plan.json', plan)
    runtime.update(consumer='mtp-logits', method='Original CPU DLL same-file hardlink beside the current consumer',
        model_order='Finite modifiers consumer and original regression arms; actual Model counts recorded by each case',
        CPU_processes=3, CUDA_processes=1)
    runtime.pop('sampling_models_per_process', None)
    (W / 'runtime-plan.json').write_text(json.dumps(runtime, indent=2) + '\n', encoding='utf-8')
    plan.update(runtime=t.pin(W / 'runtime-plan.json'),
        CPU_processes=3, CUDA_processes=1,
        compatibility='The include-main consumer recompiles engine-private math and request headers; no public SDK layout or retained object ABI changes.')
    (W / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    print('CURRENT PLAN REFINED before source freeze; no CXX/link/inference')


def freeze():
    plan = b.prepared()
    expected = t.read(W / 'expected-sources.json')
    required = {'engine/models/qwen35/main.cc', 'engine/inference/sampling_graph.h',
        'engine/inference/request_execution_failure.h', 'engine/inference/evaluation_failure.h',
        'tests/tools/qwen_host_image_test.cc'}
    assert required <= set(expected)
    assert any(name.startswith('tests/tools/') and name.endswith('.h') for name in expected), 'Freeze the new consumer header too'
    for relative, sha in expected.items():
        assert t.pin(R / relative)['sha256'] == sha, relative
    project = [t.pin(path) for path in b.project_paths(plan, expected)]
    t.save(W / 'project-dependencies.json', project)
    snapshots = []
    for relative in expected:
        source, target = R / relative, W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / 'source-freeze.json', dict(expected=t.pin(W / 'expected-sources.json'),
        project_dependencies=t.pin(W / 'project-dependencies.json'), snapshots=snapshots,
        base=t.pin(BASE / 'ready-tiny.json'),
        note='Author-frozen canonical include-main TU; no copied SDK or model payload.'))
    print('SOURCE FROZEN; no compilation or inference')


def validate():
    plan, frozen = b.prepared(), t.read(W / 'source-freeze.json')
    for field in ('expected', 'project_dependencies', 'base'):
        t.exact(frozen[field])
    for item in frozen['snapshots']:
        t.exact(item['original'])
        t.exact(item['snapshot'])
    return plan, frozen


b.validate = validate
if __name__ == '__main__':
    {'prepare': prepare, 'refine-plan': refine_plan, 'freeze': freeze, 'compile': b.compile_one, 'link': b.link}[sys.argv[1]]()
