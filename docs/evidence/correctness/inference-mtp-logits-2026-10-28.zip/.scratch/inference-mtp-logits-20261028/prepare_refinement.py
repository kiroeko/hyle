"""Independent test-only ADL refinement metadata; no CXX/link/inference."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
W = P / 'refinement'
R = P.parents[1]
assert not W.exists(), 'Do not overwrite any actual attempt'
W.mkdir()
build = (P / 'build.py').read_text(encoding='utf-8')
assert 'R = W.parents[1]' in build
(W / 'build.py').write_text(build.replace('R = W.parents[1]', 'R = W.parents[2]'), encoding='utf-8')
(W / 'run.py').write_bytes((P / 'run.py').read_bytes())
spec = importlib.util.spec_from_file_location('mtp_logits_refinement', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
failure = t.read(P / 'logs/tiny/process.json')
assert failure['pid'] == 48268 and failure['exit'] == 2 and not failure['timed_out']
expected = t.read(P / 'expected-sources.json')
relative = 'tests/tools/qwen_mtp_logits_case.h'
expected[relative] = '7facbb77023e56289c586bbe7f65b67b1404d803e4d1ce3dafbeb4c0357d26e8'
for name, sha in expected.items(): assert t.pin(R / name)['sha256'] == sha, name
before = (P / 'source' / relative).read_text(encoding='utf-8')
after = (R / relative).read_text(encoding='utf-8')
assert after.count('qwen_mtp_logits_case::unchanged(') == 2
assert after.replace('qwen_mtp_logits_case::unchanged(', 'unchanged(') == before
with (W / 'source-refinement.diff').open('x', encoding='utf-8') as stream:
    stream.write(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile='initial/' + relative, tofile='refinement/' + relative)))
t.save(W / 'expected-sources.json', expected)
t.save(W / 'amendment.json', dict(reason='C2668: unqualified test helper collides with SavedRequest ADL candidate.',
    correction='Qualify exactly two calls as qwen_mtp_logits_case::unchanged; no test assertion/product/driver change.',
    changed_test_only=True, first_failure=t.pin(P / 'logs/tiny/process.json'),
    first_source_freeze=t.pin(P / 'source-freeze.json'), source_patch=t.pin(W / 'source-refinement.diff'),
    actual_new_CXX=0, actual_new_links=0, actual_new_inference=0))
b.prepare()
spec = importlib.util.spec_from_file_location('mtp_logits_refinement_run', W / 'run.py')
run = importlib.util.module_from_spec(spec); spec.loader.exec_module(run)
run.prepare()
b.freeze()
print('REFINEMENT READY: source frozen; original ADL CXX failure retained; 0 CXX/link/GPU execution')
