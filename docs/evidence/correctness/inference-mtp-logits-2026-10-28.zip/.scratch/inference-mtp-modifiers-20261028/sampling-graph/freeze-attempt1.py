"""Bounded source/static-equivalence receipt; no compilation or execution."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[2]
relative = 'engine/inference/sampling_graph.h'
source = R / relative
before_bytes = subprocess.run(['git', 'show', 'HEAD:' + relative], cwd=R, capture_output=True, check=True).stdout
assert hashlib.sha256(before_bytes).hexdigest() == '085be10d28ae789a7fb576d372c23b8cdefede0bbc6ac4c8e4c66328d75a17d5'
before, after = before_bytes.decode('utf-8'), source.read_text(encoding='utf-8')


def function(text, name):
    start = text.index(name)
    # Mask comments/strings before matching the original C++ brace extent.
    masked = re.sub(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"', lambda x: ' ' * len(x[0]), text, flags=re.S)
    opening = masked.index(') {', start) + 2
    depth = 1; at = opening + 1
    while depth:
        depth += (masked[at] == '{') - (masked[at] == '}'); at += 1
    return text[start:at]


for name in ('DistributionFor<Value> distribution(', 'DecisionFor<Value> decision('):
    assert function(before, name) == function(after, name), name
process = function(after, 'ProcessedLogitsFor<Value> process_logits(')
assert process.index('if (!inputs.bias && !inputs.allowed) return {raw, {}};') < process.index('r.spec(raw)')
selection = function(after, 'SelectionFor<Value> processed_selection(')
assert 'if (!processed.valid) return {r.op(c::Operation(c::TopK{.count = 1}), {processed.logits}).at(1), {}};' in selection
normalization = function(after, 'DistributionFor<Value> processed_distribution(')
assert 'auto p = distribution(r, processed.logits, policy);' in normalization
assert 'if (processed.valid)' in normalization
prefix = function(after, 'PrefixDecisionsFor<Value> speculative_prefix(')
assert 'LogitsInputsFor<Value> inputs = {}' in prefix
assert prefix.count('process_logits(') == 1 and 'result.q.push_back(r.input(*q_description));' in prefix
assert 'decision(r,target[row].log_probabilities,result.q.back(),' in prefix
assert function(before, 'SelectionFor<Value> ordinary_selection(').split(') {', 1)[0] == function(after, 'SelectionFor<Value> ordinary_selection(').split(') {', 1)[0]
subprocess.run(['git', 'diff', '--check', '--', relative], cwd=R, check=True)
snapshot = W / 'source' / relative
snapshot.parent.mkdir(parents=True, exist_ok=True)
with snapshot.open('xb') as stream: stream.write(source.read_bytes())
patch = W / 'sampling-graph.diff'
with patch.open('xb') as stream:
    stream.write(subprocess.run(['git', 'diff', '--', relative], cwd=R, capture_output=True, check=True).stdout)


def pin(path):
    value = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(value), sha256=hashlib.sha256(value).hexdigest())


receipt = dict(status='SOURCE_FROZEN_NO_BUILD', base=subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=R, capture_output=True, text=True, check=True).stdout.strip(),
    source=pin(source), snapshot=pin(snapshot), patch=pin(patch), baseline_sha256=hashlib.sha256(before_bytes).hexdigest(),
    APIs=['ProcessedLogitsFor<Value>{Value logits; optional<Value> valid;}',
        'process_logits(r,raw,LogitsInputsFor<Value>={})',
        'processed_distribution(r,ProcessedLogitsFor<Value>,Policy={})',
        'processed_selection(r,ProcessedLogitsFor<Value>,optional<Value> identity,Policy={})',
        'ordinary_selection retains its original signature',
        'speculative_prefix appends LogitsInputsFor<Value> inputs={}'],
    static_checks=dict(distribution_source_unchanged=True, decision_source_unchanged=True, ordinary_signature_unchanged=True,
        empty_process_early_identity_before_any_recipe_call=True, empty_consumer_original_TopK_or_distribution_then_categorical=True,
        normalized_q_inputs_not_processed=True, git_diff_check='PASS'),
    contract='Nonempty processing retains the original raw NaN/+Inf and bias-finite checks before allowed-mask application. Its optional valid is a pre-mask proof; the final distribution/greedy consumer joins post-processing support validity.',
    caller_reuse='Process once. If categorical or threshold already needs a distribution, share one processed_distribution rather than construct a second one through processed_selection.',
    ownership='Cold graph fragment only; no new invocation/queue/Completion/lease/RNG/state owner.',
    CXX=0, links=0, GPU=0, downloads=0, limits='Static source/empty-path reasoning only; no compile, node-trace, numeric or runtime PASS claimed.')
with (W / 'source-freeze.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
