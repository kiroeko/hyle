from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
def pin(path):
    path = Path(path); data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
source = R/'src/graph/executable.cc'
original = source.read_text(encoding='utf-8'); text = original
start = text.index('Result<ReplayRoute> reusable_capture_tuple(')
end = text.index('\nStatus prepare_replay_impl(', start)
block = text[start:end]
helper = r'''
void capture_miss_tensor(const char*kind,std::size_t step,std::size_t port,std::size_t instance,
    compute::ConstTensorView expected,compute::ConstTensorView actual) noexcept {
  const auto a=expected.storage(),b=actual.storage();
  std::fprintf(stderr,"CAPTURE_MISS tuple kind=%s step=%zu port=%zu instance=%zu desc_same=%u old_valid=%u old_resource=%p old_handle=%p old_offset=%zu old_bytes=%zu new_valid=%u new_resource=%p new_handle=%p new_offset=%zu new_bytes=%zu\n",
      kind,step,port,instance,unsigned(expected.description()==actual.description()),unsigned(expected.valid()),
      a.resource()?static_cast<void*>(&a.resource().resource()):nullptr,a.native_handle(),a.offset(),a.size(),unsigned(actual.valid()),
      b.resource()?static_cast<void*>(&b.resource().resource()):nullptr,b.native_handle(),b.offset(),b.size());
}
'''
anchor = '  const auto &plan = *state.plan;\n'
assert block.count(anchor) == 1
block = block.replace(anchor, anchor+r'''  const auto miss=[&](const char*reason,std::size_t line) noexcept {
    std::fprintf(stderr,"CAPTURE_MISS reject state=%p reason=%s original_line=%zu\n",static_cast<const void*>(&state),reason,line);
    return DIAGNOSTIC_UNPREPARED;
  };
''', 1)
reasons = ['topology-or-empty-command', 'actual-queue', 'actual-shared-coverage',
    'unstable-or-native-inputs', 'region-private-contract', 'operation-private-contract',
    'unsupported-step-kind', 'missing-or-unqualified-saved-range', 'no-matching-live-recording']
base_line = original[:start].count('\n')+1
return_lines = [base_line+i for i, line in enumerate(original[start:end].splitlines())
    if 'return ReplayRoute::kUnprepared;' in line]
assert block.count('return ReplayRoute::kUnprepared;') == len(reasons) == len(return_lines)
for reason, line in zip(reasons, return_lines):
    block = block.replace('return ReplayRoute::kUnprepared;', f'return miss("{reason}",{line});', 1)
block = block.replace('DIAGNOSTIC_UNPREPARED', 'ReplayRoute::kUnprepared')
old = '''          if (port == variant.bindings.size() || !tensor.valid() ||
              !same_physical_tensor(variant.bindings[port++], tensor))
            return false;'''
new = '''          const auto diagnostic_port=port;
          if (port == variant.bindings.size() || !tensor.valid() ||
              !same_physical_tensor(variant.bindings[port++], tensor)) {
            capture_miss_tensor("input",index,input,instance,
                diagnostic_port < variant.bindings.size() ? variant.bindings[diagnostic_port] : compute::ConstTensorView{},tensor);
            return false;
          }'''
assert block.count(old) == 1; block = block.replace(old, new)
old = '''          if (port == variant.bindings.size() || !tensor.valid() ||
              !same_physical_tensor(variant.bindings[port++], tensor.as_const()))
            return false;'''
new = '''          const auto diagnostic_port=port;
          if (port == variant.bindings.size() || !tensor.valid() ||
              !same_physical_tensor(variant.bindings[port++], tensor.as_const())) {
            capture_miss_tensor("output",index,output,plan.node_outputs[step.output_begin+output],
                diagnostic_port < variant.bindings.size() ? variant.bindings[diagnostic_port] : compute::ConstTensorView{},tensor.as_const());
            return false;
          }'''
assert block.count(old) == 1; block = block.replace(old, new)
old = '      if (!variant.key_valid) return false;'
new = r'''      if (!variant.key_valid) {
        std::fprintf(stderr,"CAPTURE_MISS invalid-key range=%u+%u variant=%zu\n",saved->step_begin,saved->step_count,std::size_t(&variant-saved->variants.data()));
        return false;
      }'''
assert block.count(old) == 1; block = block.replace(old, new)
old = '    if (!found) return miss("no-matching-live-recording",'
new = r'''    if (!found) std::fprintf(stderr,"CAPTURE_MISS records range=%u+%u active=%u key0=%u commands0=%u key1=%u commands1=%u retained=%zu\n",
        saved->step_begin,saved->step_count,unsigned(saved->active_variant),unsigned(saved->variants[0].key_valid),unsigned(saved->variants[0].commands.valid()),
        unsigned(saved->variants[1].key_valid),unsigned(saved->variants[1].commands.valid()),state.captured_ranges.size());
    if (!found) return miss("no-matching-live-recording",'''
assert block.count(old) == 1; block = block.replace(old, new)
text = text[:start]+helper+block+text[end:]
start = text.index('Result<bool> detail::ReplayAccess::can_reuse_capture(')
end = text.index('\nStatus detail::ReplayAccess::prepare_reuse(', start)
block = text[start:end]
old = '      if (!unchanged) return false;'
new = r'''      if (!unchanged) {
        std::fprintf(stderr,"CAPTURE_MISS alias input=%u root=%u state=%p\n",input.ordinal(),plan.external_instances[input.ordinal()],static_cast<const void*>(state));
        capture_miss_tensor("alias",0,input.ordinal(),plan.external_instances[input.ordinal()],state->readable[plan.external_instances[input.ordinal()]],replacement.tensor);
        return false;
      }'''
assert block.count(old) == 1; block = block.replace(old, new)
text = '#include <cstdio>\n'+text[:start]+block+text[end:]
copy = W/'source/executable.cc'
copy.parent.mkdir(parents=True, exist_ok=True); copy.write_bytes(text.encode('utf-8'))
prior = R/'.scratch/inference-model-submission-source-20261027'
recipe = prior/'logs/executable/command.json'
command = json.loads(recipe.read_text())['command']
out = W/'compile/executable'; out.mkdir(parents=True, exist_ok=False)
oldout = prior/'compile/executable'
command = [str(copy) if Path(x) == source else x.replace(str(oldout),str(out)) for x in command]
assert str(copy) in command and str(source) not in command
include = '/I'+str(R/'src/graph')
if include not in command: command.insert(1, include)
save(W/'plan.json', dict(status='PREPARED_DIAGNOSTIC_ONLY', product=pin(source), source=pin(copy),
    recipe=pin(recipe), command=command,
    scope='Scratch executable.cc diagnostics only: 1 CXX; no link/run/SDK/native rebuild.',
    reasons=[dict(reason=a,original_line=b) for a,b in zip(reasons,return_lines)]))
save(W/'preparation-failure.json',dict(kind='SCRIPT_ONLY',compiler_attempts=0,
    reason='Initial nested Python string caused SyntaxError before writing prepare.py; corrected script retained here.'))
print(json.dumps(pin(copy)),flush=True)
