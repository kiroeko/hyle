from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-model-submission-source-20261027/check_current.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,h=p.b,p.h
plan=b.read(W/'plan.json');b.exact(plan['source']);b.exact(plan['product'])
out=W/'compile/executable'
process=h.execute(plan['command'],p.environment('cli'),W/'logs/executable',timeout=180)
b.exact(plan['source']);b.exact(plan['product'])
raw=b.read(out/'dependencies.json')['Data']
assert b.key(raw['Source'])==b.key(plan['source']['path'])
deps=[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])]
b.save(out/'actual-dependencies.json',deps)
baseline=b.read(R/'.scratch/inference-model-submission-source-20261027/compile/executable/actual-dependencies.json')
old={b.key(x['path']):x for x in baseline if b.key(x['path'])!=b.key(plan['product']['path'])}
new={b.key(x['path']):x for x in deps if b.key(x['path'])!=b.key(plan['source']['path'])}
changed=[dict(path=x,old=old[x]['sha256'],new=new[x]['sha256']) for x in old.keys()&new.keys() if old[x]['sha256']!=new[x]['sha256']]
result=dict(status='COMPILED_NOT_LINKED_NOT_RUN',source=plan['source'],product=plan['product'],object=b.pin(out/'unit.obj'),
    dependencies=b.pin(out/'actual-dependencies.json'),process=process,changed_common_dependencies=changed,
    added_dependencies=[new[x] for x in new.keys()-old.keys()],removed_dependencies=[old[x] for x in old.keys()-new.keys()],
    counts=dict(distinct_translation_units=1,compiler_attempts=1,links=0,runs=0))
b.save(W/'compiled.json',result)
print(result['object'],flush=True)
