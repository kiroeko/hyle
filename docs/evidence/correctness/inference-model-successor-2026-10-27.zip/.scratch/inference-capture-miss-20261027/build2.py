from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-model-submission-source-20261027/check_current.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,h=p.b,p.h
prior=b.read(W/'compiled.json');b.exact(prior['source']);b.exact(prior['product'])
text=Path(prior['source']['path']).read_text(encoding='utf-8')
old='        if (!preserves) return miss("operation-private-contract",9649);'
new=r'''        if (!preserves) {
          const auto provider=step.provider();
          std::fprintf(stderr,"CAPTURE_MISS operation-private step=%zu provider=%.*s op=%u\n",i,
              static_cast<int>(provider.name.size()),provider.name.data(),unsigned(step.operation.kind()));
          return miss("operation-private-contract",9649);
        }'''
assert text.count(old)==1;text=text.replace(old,new)
source=W/'source/executable2.cc';source.write_bytes(text.encode('utf-8'))
pin=b.pin(source)
plan=b.read(W/'plan.json');out=W/'compile/executable2';out.mkdir(parents=True,exist_ok=False)
command=[str(source) if b.key(x)==b.key(prior['source']['path']) else x.replace(str(W/'compile/executable'),str(out)) for x in plan['command']]
b.save(W/'plan2.json',dict(source=pin,product=prior['product'],command=command,previous=b.pin(W/'compiled.json'),
    change='Only operation-private-contract diagnostic adds step/provider/OperationKind. Original source/object preserved.'))
process=h.execute(command,p.environment('cli'),W/'logs/executable2',timeout=180)
b.exact(pin);b.exact(prior['source']);b.exact(prior['product'])
raw=b.read(out/'dependencies.json')['Data'];assert b.key(raw['Source'])==b.key(source)
deps=[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])]
b.save(out/'actual-dependencies.json',deps)
olddeps={b.key(x['path']):x for x in b.read(prior['dependencies']['path']) if b.key(x['path'])!=b.key(prior['source']['path'])}
newdeps={b.key(x['path']):x for x in deps if b.key(x['path'])!=b.key(source)}
assert olddeps==newdeps,'Includes changed beyond diagnostic source'
result=dict(status='COMPILED_NOT_LINKED_NOT_RUN',source=pin,product=prior['product'],object=b.pin(out/'unit.obj'),
    dependencies=b.pin(out/'actual-dependencies.json'),process=process,previous=b.pin(W/'compiled.json'),
    counts=dict(distinct_translation_units=1,compiler_attempts=2,links=0,runs=0),unchanged_includes=True)
b.save(W/'compiled2.json',result);print(result['object'],flush=True)
