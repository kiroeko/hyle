from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-model-submission-source-20261027'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


m = module('successor_kv_recipe', R / '.scratch/inference-relay-carriers-20261027/prepare.py')
m.W = W
prior = module('successor_kv_executor', R / '.scratch/inference-pending-indexed-source-20261027/check.py')
h = prior.h
TESTS = [
    'GraphPagedAppendSourceCuda.PendingPreviousAppendAndAttentionAdmitEveryInheritedPrefix',
    'GraphPagedAppendSourceCuda.PageBoundaryAppendRetainsSourceWithoutCowReads',
    'GraphPagedAppendSourceCuda.PendingAppendCopiesOriginalTailAndInheritsPublishedPages',
]
SOURCES = [
    ('append', 'src/graph_batch/paged_append.cc', '9c664fb682035b7ed37c47c8f42629dcde8d7cbafed8d37e37c3545c5b697fc4'),
    ('test', 'tests/graph_batch/paged_append_source_test.cc', '7b5e081ad459575a30834f33724a648517ebfc9030339921cf5a87523846b8d4'),
]


def exact(row):
    actual = m.pin(row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']


def run():
    assert not (W / 'plan.json').exists(), 'Do not overwrite an attempted window'
    baseline = BASE / 'test-link-inputs-delivery.json'
    rows = m.read(baseline)
    assert len(rows) == 239
    selected = m.index(rows)
    units = []
    for name, relative, expected in SOURCES:
        source = m.pin(R / relative)
        assert source['sha256'] == expected, (relative, source['sha256'])
        old = selected[m.key(R / relative)]
        recipe = (BASE / 'logs/append-fix/command.json' if name == 'append'
                  else Path(old['object']['path']).parent / 'command.json')
        template = m.read(recipe)['command']
        assert sum(m.key(arg) == m.key(R / relative) for arg in template
                   if arg.lower().endswith('.cc')) == 1
        out = W / 'compile' / name
        out.mkdir(parents=True)
        command = []
        for index, arg in enumerate(template):
            if index and template[index - 1].lower() == '/sourcedependencies':
                arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith('.cc'):
                arg = str(R / relative)
            command.append(arg)
        assert m.build_contract(command) == m.build_contract(template)
        frozen = W / 'source' / relative
        frozen.parent.mkdir(parents=True, exist_ok=True)
        frozen.write_bytes(Path(source['path']).read_bytes())
        units.append(dict(name=name, source=source, snapshot=m.pin(frozen), old=old['object'],
            old_dependencies=old['dependencies'], recipe=m.pin(recipe), command=command,
            compiler_contract=m.build_contract(command)))
    runtime = m.read(BASE / 'runtime.json')
    plan = dict(status='FROZEN_NOT_BUILT_NOT_RUN', baseline=m.pin(baseline),
        runtime=m.pin(BASE / 'runtime.json'), units=units, tests=TESTS,
        link_template=m.pin(BASE / 'link-test-delivery/command.json'),
        counts=dict(CXX=2, links=1, processes=1, tests=3, file_inputs=239, SDK=0, NVCC=0, downloads=0),
        scope='Independent pending-previous KV append/COW plus original attention; no Model/main, pipeline throughput, other backends or fault injection.')
    m.save(W / 'plan.json', plan)
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': units[0]['command'][0], 'CMAKE_CXX_COMPILER': units[0]['command'][0],
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = str(W / 'bin') + os.pathsep + runtime.get('test_PATH', runtime['PATH'])
    for key in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE'):
        env[key] = '1'
    m.save(W / 'environment.json', {key: env.get(key, '') for key in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    for row in rows:
        exact(row)
    compiled = []
    replacements = {}
    for unit in units:
        exact(unit['source'])
        process = h.execute(unit['command'], env, W / 'logs' / unit['name'], timeout=180)
        out = W / 'compile' / unit['name']
        dependencies = m.read(out / 'dependencies.json')['Data']
        assert m.key(dependencies['Source']) == m.key(unit['source']['path'])
        actual = []
        for item in [dependencies['Source'], *dependencies.get('Includes', [])]:
            path = Path(item)
            if path.is_relative_to(R) and '.scratch' not in path.relative_to(R).parts and path.is_file():
                actual.append(m.pin(path))
        m.save(out / 'actual-dependencies.json', actual)
        obj = m.pin(out / 'unit.obj')
        replacements[m.key(unit['old']['path'])] = obj
        compiled.append(dict(name=unit['name'], source=unit['source'], object=obj,
            dependencies=m.pin(out / 'dependencies.json'), actual_dependencies=m.pin(out / 'actual-dependencies.json'),
            process=process))
    inputs = [replacements.get(m.key(row['path']), row) for row in rows]
    assert len(inputs) == 239 and len(replacements) == 2
    m.save(W / 'link-inputs.json', inputs)
    (W / 'bin').mkdir()
    native_cpu = runtime['native_cpu']
    exact(native_cpu)
    alias = W / 'bin' / Path(native_cpu['path']).name
    os.link(native_cpu['path'], alias)
    m.save(W / 'runtime.json', dict(original=plan['runtime'], PATH=env['PATH'],
        original_native_cpu=native_cpu, alias=m.pin(alias), action='Hardlink existing DLL, no payload copy'))
    image = W / 'bin/successor-kv-test.exe'
    command = m.link_command(m.read(BASE / 'link-test-delivery/command.json')['command'],
        {key: row['path'] for key, row in replacements.items()}, [], image)
    linked = h.execute(command, env, W / 'link', timeout=180)
    ready = dict(status='BUILT_NOT_RUN', plan=m.pin(W / 'plan.json'), compiled=compiled,
        inputs=m.pin(W / 'link-inputs.json'), image=m.pin(image), link=linked,
        runtime=m.pin(W / 'runtime.json'))
    m.save(W / 'ready.json', ready)
    for unit in units:
        exact(unit['source'])
    xml = W / 'run/results.xml'
    command = [str(image), '--gtest_color=no', '--gtest_filter=' + ':'.join(TESTS), '--gtest_output=xml:' + str(xml)]
    process = h.execute(command, env, W / 'run', timeout=180)
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    names = [case.attrib['classname'] + '.' + case.attrib['name'] for case in cases]
    assert sorted(names) == sorted(TESTS) and len(cases) == 3
    assert all(case.find('failure') is None and case.find('skipped') is None for case in cases)
    result = dict(status='PASS', ready=m.pin(W / 'ready.json'), process=process,
        tests=names, test_count=3, xml=m.pin(xml), stdout=m.pin(W / 'run/stdout.log'),
        stderr=m.pin(W / 'run/stderr.log'), counts=plan['counts'], scope=plan['scope'])
    m.save(W / 'summary.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    try:
        run()
    except Exception:
        m.save(W / 'failure.json', dict(status='FAILED_ATTEMPT_RETAINED', traceback=traceback.format_exc()))
        raise
