from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def exact(row):
    assert pin(row['path']) == row, row['path']

def execute(command, env, label, timeout):
    out = W/'logs'/label
    out.mkdir(parents=True, exist_ok=False)
    started = time.time()
    save(out/'command.json', dict(command=command, cwd=str(R), timeout_seconds=timeout))
    process = subprocess.run(command, cwd=R, env=env, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, timeout=timeout, check=False)
    (out/'stdout.log').write_bytes(process.stdout)
    (out/'stderr.log').write_bytes(process.stderr)
    result = dict(exit_code=process.returncode, elapsed_seconds=time.time()-started,
                  started_utc=datetime.datetime.fromtimestamp(started, datetime.timezone.utc).isoformat(),
                  command=pin(out/'command.json'), stdout=pin(out/'stdout.log'), stderr=pin(out/'stderr.log'))
    save(out/'process.json', result)
    print(label, result['exit_code'], round(result['elapsed_seconds'], 3), flush=True)
    if process.returncode:
        print(process.stdout.decode('utf-8', errors='replace'), flush=True)
        print(process.stderr.decode('utf-8', errors='replace'), flush=True)
        raise RuntimeError(label+' failed; actual process/logs preserved')
    return result

spec = importlib.util.spec_from_file_location('cached_check', R/'.scratch/inference-metadata-queue-20261027/check.py')
cached = importlib.util.module_from_spec(spec); spec.loader.exec_module(cached)
compiler = Path(read(R/'.scratch/inference-request-progress-20261025/host/qwen_generation_schedule_test/compile/command.json')['command'][0])
env = cached.h.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': str(compiler), 'CMAKE_CXX_COMPILER': str(compiler), 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
save(W/'environment.json', {key: env.get(key) for key in ['PATH', 'INCLUDE', 'LIB', 'LIBPATH']})
owned = ['engine/models/qwen35/execution_mode.h', 'engine/models/qwen35/generation_ledger.h',
         'tests/tools/qwen_generation_ledger_test.cc']
frozen = [pin(R/path) for path in owned]
save(W/'source-freeze.json', frozen)
for path in owned:
    source = W/'source'/path
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes((R/path).read_bytes())

def frozen_check():
    for row in frozen: exact(row)

for directory in ['compile', 'bin']:
    (W/directory).mkdir(exist_ok=False)
obj = W/'compile/unit.obj'
command = [str(compiler), '/nologo', '/c', '/std:c++latest', '/EHsc', '/MD', '/O2', '/DNDEBUG',
           '/W4', '/WX', '/wd4324', '/permissive-', '/Zc:preprocessor', '/Zc:__cplusplus',
           '/utf-8', '/DHYLE_STATIC', '/DNOMINMAX', '/I'+str(R/'include'),
           '/sourceDependencies', str(W/'compile/dependencies.json'),
           str(R/'tests/tools/qwen_generation_ledger_test.cc'), '/Fo'+str(obj)]
frozen_check()
compilation = execute(command, env, 'compile', 60)
frozen_check()
deps = read(W/'compile/dependencies.json')['Data']
dependencies = [pin(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])]
save(W/'compile/actual-dependencies.json', dependencies)
for row in dependencies: exact(row)
libraries = [row for row in read(R/'.scratch/inference-model-submission-source-20261027/cli-link-inputs.json')
             if Path(row['path']).name == 'mimalloc_static.lib']
assert len(libraries) == 1
for row in libraries: exact(row)
linker = compiler.with_name('link.exe')
image = W/'bin/qwen-generation-ledger-test.exe'
command = [str(linker), '/NOLOGO', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO',
           '/OPT:REF', '/OPT:ICF', '/NODEFAULTLIB:LIBCMT', '/VERBOSE:LIB',
           '/OUT:'+str(image), str(obj), libraries[0]['path'],
           'kernel32.lib', 'bcrypt.lib', 'advapi32.lib', 'psapi.lib']
save(W/'link-inputs.json', [pin(obj), *libraries])
link = execute(command, env, 'link', 60)
frozen_check()
link_text = (W/'logs/link/stdout.log').read_text(encoding='utf-8', errors='replace')
resolved = []
for entry in re.findall(r'(?im)^\s*Searching\s+(.+?\.lib):\s*$', link_text):
    path = Path(entry)
    if path.is_file() and str(path.resolve()) not in [row['path'] for row in resolved]:
        resolved.append(pin(path))
save(W/'resolved-link-libraries.json', resolved)
image_pin = pin(image)
run = execute([str(image)], env, 'run', 30)
frozen_check(); exact(image_pin)
payload = json.loads((W/'logs/run/stdout.log').read_text(encoding='utf-8'))
assert payload == dict(status='PASS', groups=4, device_execution=False), payload
save(W/'result.json', dict(status='PASS', scope='Standalone host ledger only',
    counts=dict(compilations=1, links=1, processes=1, host_test_groups=4),
    sources=frozen, toolchain=[pin(compiler), pin(linker)],
    environment=pin(W/'environment.json'), dependencies=pin(W/'compile/actual-dependencies.json'),
    compilation=compilation, link=link, run=run, image=image_pin,
    resolved_link_libraries=pin(W/'resolved-link-libraries.json'),
    sdk_rebuilds=0, model_executions=0, downloads=0, performance_claim=False))
print('PASS: 1 CXX / 1 minimal link / 1 process / 4 host groups', flush=True)
