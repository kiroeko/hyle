from pathlib import Path
import subprocess
import sys

W = Path(__file__).resolve().parent
source = (W/'check.py').read_text(encoding='utf-8')
assert source.count('W = Path(__file__).resolve().parent\nR = W.parents[1]') == 1
source = source.replace('W = Path(__file__).resolve().parent\nR = W.parents[1]',
    'W = Path(__file__).resolve().parent\nR = W.parents[2]')
target = W/'attempt2/check.py'
target.parent.mkdir(exist_ok=False)
target.write_text(source, encoding='utf-8')
result = subprocess.run([sys.executable, str(target)], check=False)
raise SystemExit(result.returncode)
