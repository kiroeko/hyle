from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R/'.scratch/inference-model-submission-source-20261027'
KV = R/'.scratch/inference-successor-kv-20261027'

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result

m = module('deferred_bind_recipe', R/'.scratch/inference-relay-carriers-20261027/prepare.py')
m.W = W
prior = module('deferred_bind_executor', R/'.scratch/inference-pending-indexed-source-20261027/check.py')
h = prior.h

def exact(row):
    actual = m.pin(row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']

def run():
    assert not (W/'plan.json').exists(), 'Do not overwrite an attempted build'
    baseline_path = BASE/'test-link-inputs-delivery.json'
    rows = m.read(baseline_path)
    assert len(rows) == 239
    selected = m.index(rows)
    specs = [
        ('resources', 'src/graph/resources.cc', BASE/'logs/resources-v2/command.json',
         '6d42d5726834b8b79a4792588f8610adb79d7d3918ecab4028b20bfcc2768f16'),
        ('output_source', 'tests/graph/output_source_cuda_test.cc', BASE/'logs/output_source/command.json',
         'c3aea02b1e47494c3b7f429a5a4c246aa86345eb0f8ce99b0a9b7ed8709bb92e'),
    ]
    units = []
    for name, relative, recipe, expected in specs:
        source = m.pin(R/relative)
        assert source['sha256'] == expected, (relative, source['sha256'])
        old = selected[m.key(R/relative)]
        template = m.read(recipe)['command']
        assert sum(m.key(arg) == m.key(old['data']['Source']) for arg in template if arg.lower().endswith('.cc')) == 1
        out = W/'compile'/name
        out.mkdir(parents=True, exist_ok=False)
        command = []
        for i, arg in enumerate(template):
            if i and template[i-1].lower() == '/sourcedependencies':
                arg = str(out/'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo'+str(out/'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd'+str(out/'unit.pdb')
            elif arg.lower().endswith('.cc'):
                arg = str(R/relative)
            command.append(arg)
        assert m.build_contract(command) == m.build_contract(template)
        snapshot = W/'source'/relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(Path(source['path']).read_bytes())
        units.append(dict(name=name, source=source, snapshot=m.pin(snapshot), old=old['object'],
            old_dependencies=old['dependencies'], recipe=m.pin(recipe), command=command,
            compiler_contract=m.build_contract(command)))
    append_source = R/'src/graph_batch/paged_append.cc'
    old_append = selected[m.key(append_source)]
    kv_ready = m.read(KV/'ready.json')
    current_append = next(row for row in kv_ready['compiled'] if m.key(row['source']['path']) == m.key(append_source))
    assert m.key(current_append['object']['path']) == m.key(KV/'compile/append/unit.obj')
    dep_path, dep = m.dependency(current_append['object'])
    assert m.key(dep['Source']) == m.key(append_source)
    exact(current_append['object'])
    runtime = m.read(BASE/'runtime.json')
    tests = [
        'GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges',
        'GraphOutputSourceCuda.PendingI32ReusesRealNativeRegionCaptureWithoutRecording',
        'GraphOutputSourceCuda.CapturedManagedI32ProducerRetainsItsOriginalSubmission',
        'GgmlCudaMixedReadySource.RealTokenStoreAndKvWarmHybridThenReusePending',
    ]
    plan = dict(status='FROZEN_NOT_BUILT_NOT_RUN', baseline=m.pin(baseline_path),
        baseline_ready=m.pin(BASE/'ready-delivery.json'), units=units,
        reused_append=dict(old=old_append['object'], current=current_append,
            compiler_dependencies=m.pin(dep_path), ready=m.pin(KV/'ready.json')),
        runtime=m.pin(BASE/'runtime.json'), link_template=m.pin(BASE/'link-test-delivery/command.json'),
        tests=tests, counts=dict(CXX=2, links=1, processes=0, inputs=239, SDK=0, NVCC=0, downloads=0),
        scope='Compile/link deferred Source authority binding and final prepare/submit tuple rejection; GPU test execution deferred to root.')
    m.save(W/'plan.json', plan)
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': units[0]['command'][0], 'CMAKE_CXX_COMPILER': units[0]['command'][0],
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = str(W/'bin')+os.pathsep+runtime.get('test_PATH', runtime['PATH'])
    for key in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE'):
        env[key] = '1'
    m.save(W/'environment.json', {key: env.get(key, '') for key in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    for row in rows: exact(row)
    compiled, replacements, dependencies = [], {}, []
    for unit in units:
        for frozen in units: exact(frozen['source'])
        process = h.execute(unit['command'], env, W/'logs'/unit['name'], timeout=180)
        out = W/'compile'/unit['name']
        raw = m.read(out/'dependencies.json')['Data']
        assert m.key(raw['Source']) == m.key(unit['source']['path'])
        actual = [m.pin(path) for path in dict.fromkeys([raw['Source'], *raw.get('Includes', [])])]
        for frozen in units: exact(frozen['source'])
        m.save(out/'actual-dependencies.json', actual)
        dependencies.extend(actual)
        obj = m.pin(out/'unit.obj')
        replacements[m.key(unit['old']['path'])] = obj
        compiled.append(dict(name=unit['name'], source=unit['source'], object=obj,
            dependencies=m.pin(out/'dependencies.json'), actual_dependencies=m.pin(out/'actual-dependencies.json'), process=process))
        m.save(W/'compiled-partial.json', compiled)
    replacements[m.key(old_append['object']['path'])] = current_append['object']
    inputs = [replacements.get(m.key(row['path']), row) for row in rows]
    assert len(inputs) == 239 and len(replacements) == 3
    for row in inputs: exact(row)
    m.save(W/'test-link-inputs.json', inputs)
    m.save(W/'replacement-map.json', [dict(source=unit['source']['path'], old=unit['old'],
        current=next(row['object'] for row in compiled if row['name'] == unit['name'])) for unit in units]+[
        dict(source=str(append_source), old=old_append['object'], current=current_append['object'])])
    (W/'bin').mkdir(exist_ok=False)
    native_cpu = runtime['native_cpu']; exact(native_cpu)
    alias = W/'bin'/Path(native_cpu['path']).name
    os.link(native_cpu['path'], alias)
    m.save(W/'runtime.json', dict(original=plan['runtime'], PATH=env['PATH'],
        original_native_cpu=native_cpu, alias=m.pin(alias), action='Hardlink existing DLL; no copy or rebuild'))
    image = W/'bin/deferred-source-bind-test.exe'
    command = m.link_command(m.read(BASE/'link-test-delivery/command.json')['command'],
        {key: row['path'] for key, row in replacements.items()}, [], image)
    linked = h.execute(command, env, W/'link', timeout=180)
    for unit in units: exact(unit['source'])
    for row in dependencies: exact(row)
    for row in inputs: exact(row)
    xml = W/'run/results.xml'
    run_command = [str(image), '--gtest_color=no', '--gtest_filter='+':'.join(tests), '--gtest_output=xml:'+str(xml)]
    m.save(W/'run-plan.json', dict(status='PREPARED_NOT_RUN', command=run_command, cwd=str(R),
        timeout_seconds=180, expected_test_count=len(tests), tests=tests,
        runtime=m.pin(W/'runtime.json'), xml=str(xml), execution_owner='root'))
    ready = dict(status='BUILT_NOT_RUN', plan=m.pin(W/'plan.json'), compiled=compiled,
        inputs=m.pin(W/'test-link-inputs.json'), replacements=m.pin(W/'replacement-map.json'),
        reused_append=current_append, image=m.pin(image), link=linked,
        runtime=m.pin(W/'runtime.json'), run_plan=m.pin(W/'run-plan.json'), counts=plan['counts'])
    m.save(W/'ready.json', ready)
    print(json.dumps(dict(status=ready['status'], resources=compiled[0]['object'],
        output_source=compiled[1]['object'], image=ready['image'], ready=m.pin(W/'ready.json'),
        run_plan=ready['run_plan']), indent=2), flush=True)

if __name__ == '__main__':
    try: run()
    except Exception:
        m.save(W/'failure.json', dict(status='FAILED_ATTEMPT_RETAINED', traceback=traceback.format_exc()))
        raise
