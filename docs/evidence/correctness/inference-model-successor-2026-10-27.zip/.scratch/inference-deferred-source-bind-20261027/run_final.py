from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
W = BASE/'attempt-final'
R = BASE.parents[1]
KV = R/'.scratch/inference-successor-kv-20261027'
NATIVE = R/'.scratch/inference-native-capture-bindings-20261027'
spec = importlib.util.spec_from_file_location('deferred_build', BASE/'build.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
m, h, exact = old.m, old.h, old.exact
m.W = W

def run():
    W.mkdir(exist_ok=False)
    rows = m.read(BASE/'test-link-inputs.json')
    assert len(rows) == 239
    replacements = m.read(NATIVE/'replacements.json')
    assert len(replacements) == 6
    substitutions, review = {}, []
    paths = {m.key(row['path']): row for row in rows}
    for replacement in replacements:
        key = m.key(replacement['old']['path'])
        assert paths[key] == replacement['old'], key
        for row in [replacement['old'], replacement['new'], replacement['source'], replacement['dependencies']]: exact(row)
        substitutions[key] = replacement['new']
        review.append(replacement)
    kv_plan, kv_ready = m.read(KV/'plan.json'), m.read(KV/'ready.json')
    unit = next(unit for unit in kv_plan['units'] if unit['name'] == 'test')
    current = next(unit for unit in kv_ready['compiled'] if unit['name'] == 'test')
    assert paths[m.key(unit['old']['path'])] == unit['old']
    assert m.key(current['object']['path']) == m.key(KV/'compile/test/unit.obj')
    metadata, data = m.dependency(current['object'])
    assert m.key(data['Source']) == m.key(R/'tests/graph_batch/paged_append_source_test.cc')
    exact(current['object']); exact(current['source'])
    substitutions[m.key(unit['old']['path'])] = current['object']
    review.append(dict(name='paged_append_source_test', old=unit['old'], new=current['object'],
        source=current['source'], dependencies=m.pin(metadata), original_ready=m.pin(KV/'ready.json')))
    inputs = [substitutions.get(m.key(row['path']), row) for row in rows]
    assert len(substitutions) == 7 and len(inputs) == 239
    for row in inputs: exact(row)
    m.save(W/'test-link-inputs.json', inputs); m.save(W/'replacements.json', review)
    tests = m.read(BASE/'run-plan.json')['tests'] + m.read(KV/'summary.json')['tests']
    assert len(tests) == len(set(tests)) == 7
    runtime = m.read(BASE/'runtime.json')
    previous_command = m.read(BASE/'link/command.json')['command']
    compiler = m.read(BASE/'plan.json')['units'][0]['command'][0]
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = str(W/'bin')+os.pathsep+runtime['PATH']
    for key in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE'): env[key] = '1'
    m.save(W/'environment.json', {key: env.get(key, '') for key in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    (W/'bin').mkdir()
    cpu = runtime['original_native_cpu']; exact(cpu)
    alias = W/'bin'/Path(cpu['path']).name
    os.link(cpu['path'], alias)
    m.save(W/'runtime.json', dict(original=m.pin(BASE/'runtime.json'), PATH=env['PATH'],
        original_native_cpu=cpu, alias=m.pin(alias), action='Existing DLL hardlink, no copy/rebuild'))
    image = W/'bin/deferred-source-bind-final-test.exe'
    command = m.link_command(previous_command, {key: row['path'] for key, row in substitutions.items()}, [], image)
    m.save(W/'plan.json', dict(status='FROZEN_NOT_LINKED_NOT_RUN', baseline=m.pin(BASE/'test-link-inputs.json'),
        native_replacements=m.pin(NATIVE/'replacements.json'), input_count=239, substitutions=7,
        sources=[row['source'] for row in review], tests=tests,
        counts=dict(CXX=0, links=1, processes=1, tests=7, SDK=0, NVCC=0, downloads=0)))
    linked = h.execute(command, env, W/'link', timeout=180)
    for row in inputs: exact(row)
    for row in review: exact(row['source'])
    ready = dict(status='LINKED_NOT_RUN', plan=m.pin(W/'plan.json'), inputs=m.pin(W/'test-link-inputs.json'),
        replacements=m.pin(W/'replacements.json'), image=m.pin(image), link=linked, runtime=m.pin(W/'runtime.json'))
    m.save(W/'ready.json', ready)
    xml = W/'run/results.xml'
    command = [str(image), '--gtest_color=no', '--gtest_filter='+':'.join(tests), '--gtest_output=xml:'+str(xml)]
    process = h.execute(command, env, W/'run', timeout=180)
    root = ET.parse(xml).getroot()
    cases = root.findall('./testsuite/testcase')
    actual = [case.attrib['classname']+'.'+case.attrib['name'] for case in cases]
    assert sorted(actual) == sorted(tests) and len(cases) == 7, actual
    assert all(case.find('failure') is None and case.find('error') is None and case.find('skipped') is None for case in cases)
    assert int(root.attrib.get('failures', 0)) == int(root.attrib.get('disabled', 0)) == int(root.attrib.get('errors', 0)) == 0
    for row in review: exact(row['source'])
    summary = dict(status='PASS', ready=m.pin(W/'ready.json'), process=process, tests=actual, test_count=7,
        failures=0, skipped=0, xml=m.pin(xml), stdout=m.pin(W/'run/stdout.log'), stderr=m.pin(W/'run/stderr.log'),
        counts=m.read(W/'plan.json')['counts'], scope='Finite final Source binding/capture and KV component checks only; no Model throughput claim.')
    m.save(W/'summary.json', summary)
    print(json.dumps(summary, indent=2), flush=True)

if __name__ == '__main__':
    try: run()
    except Exception:
        m.save(W/'failure.json', dict(status='FAILED_ATTEMPT_RETAINED', traceback=traceback.format_exc()))
        raise
