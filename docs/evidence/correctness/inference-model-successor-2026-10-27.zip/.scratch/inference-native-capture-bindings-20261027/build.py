from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location(
    'previous', R / '.scratch/inference-model-submission-source-20261027/check_current.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
b, h = p.b, p.h

UNITS = [
    ('registration', 'cuda_provider.cc', '.scratch/inference-causal-conv-20261026/compile/registration'),
    ('causal_conv', 'causal_conv_provider.cc', '.scratch/inference-causal-conv-20261026/compile/provider'),
    ('tensor', 'tensor_provider.cc', '.scratch/inference-current-closure-20261026/headers79/compute_provider_cuda--tensor_provider_cc'),
    ('norm', 'norm_provider.cc', '.scratch/inference-current-closure-20261026/headers79/compute_provider_cuda--norm_provider_cc'),
    ('reduction', 'reduction_provider.cc', '.scratch/inference-current-closure-20261026/headers79/compute_provider_cuda--reduction_provider_cc'),
    ('concat', 'concat_provider.cc', '.scratch/inference-current-closure-20261026/headers79/compute_provider_cuda--concat_provider_cc'),
]
FILES = [x[1] for x in UNITS] + [
    'causal_conv_provider.h', 'tensor_provider.h', 'norm_provider.h',
    'reduction_provider.h', 'concat_provider.h',
]


def prepare():
    assert not (W / 'source-freeze.json').exists()
    frozen = []
    for name in FILES:
        source = b.pin(R / 'src/compute_provider_cuda' / name)
        snapshot = W / 'source/src/compute_provider_cuda' / name
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(Path(source['path']).read_bytes())
        b.exact(source)
        frozen.append(dict(**source, snapshot=b.pin(snapshot)))
    b.save(W / 'source-freeze.json', frozen)
    baseline = b.read(R / '.scratch/inference-model-successor-20261027/probe-link-inputs.json')
    plans = []
    for name, filename, old_directory in UNITS:
        old = R / old_directory
        original = b.pin(old / 'unit.obj')
        assert any(b.key(row['path']) == b.key(original['path']) and
                   row['sha256'] == original['sha256'] for row in baseline), name
        recipe = b.read(old / 'command.json')
        out = W / 'compile' / name
        command = [arg.replace(str(old), str(out)) for arg in recipe['command']]
        source = R / 'src/compute_provider_cuda' / filename
        assert sum(b.key(arg) == b.key(source) for arg in command) == 1, name
        assert any(arg == '/WX' for arg in command)
        assert not any('nvcc' in arg.lower() for arg in command)
        b.save(W / 'recipes' / (name + '.json'), dict(command=command, original_recipe=b.pin(old / 'command.json')))
        plans.append(dict(name=name, source=b.pin(source), original_object=original,
                          original_dependencies=b.pin(old / 'dependencies.json'),
                          recipe=b.pin(W / 'recipes' / (name + '.json')), output=str(out)))
    b.save(W / 'plan.json', dict(units=plans,
        baseline_inputs=b.pin(R / '.scratch/inference-model-successor-20261027/probe-link-inputs.json'),
        scope='Six affected CXX units only; additive private helper functions, no layout changes. No link, SDK/NVCC, or GPU run.'))
    print('SOURCE_FROZEN: 11 files; 6 CXX recipes; 0 builds/runs', flush=True)


def build():
    plan = b.read(W / 'plan.json')
    frozen = b.read(W / 'source-freeze.json')
    changed_keys = {b.key(row['path']) for row in frozen}
    compiled = []
    for unit in plan['units']:
        for row in frozen:
            b.exact({key: value for key, value in row.items() if key != 'snapshot'})
        b.exact(unit['original_object'])
        out = Path(unit['output'])
        out.mkdir(parents=True, exist_ok=False)
        command = b.read(unit['recipe']['path'])['command']
        process = h.execute(command, p.environment('cli'), W / 'logs' / unit['name'], timeout=180)
        for row in frozen:
            b.exact({key: value for key, value in row.items() if key != 'snapshot'})
        raw = b.read(out / 'dependencies.json')['Data']
        assert b.key(raw['Source']) == b.key(unit['source']['path'])
        dependencies = [b.pin(x) for x in dict.fromkeys([raw['Source'], *raw['Includes']])]
        b.save(out / 'actual-dependencies.json', dependencies)
        old_raw = b.read(unit['original_dependencies']['path'])['Data']
        old_keys = {b.key(x) for x in [old_raw['Source'], *old_raw['Includes']]}
        new_keys = {b.key(row['path']) for row in dependencies}
        added = sorted(new_keys - old_keys)
        removed = sorted(old_keys - new_keys)
        assert not removed, (unit['name'], removed)
        assert all(x.endswith('/hyle/compute/detail/capture_bindings.h') or
                   x.endswith('\\hyle\\compute\\detail\\capture_bindings.h') for x in added), (unit['name'], added)
        item = dict(name=unit['name'], source=unit['source'], original_object=unit['original_object'],
            object=b.pin(out / 'unit.obj'), process=process,
            actual_dependencies=b.pin(out / 'actual-dependencies.json'),
            dependency_set_delta=dict(added=added, removed=removed),
            intentional_changed_inputs=[row for row in dependencies if b.key(row['path']) in changed_keys])
        compiled.append(item)
        b.save(W / 'compiled.json', compiled)
    b.save(W / 'ready.json', dict(status='COMPILED_NOT_LINKED_NOT_RUN', compiled=compiled,
        source_freeze=b.pin(W / 'source-freeze.json'), plan=b.pin(W / 'plan.json'),
        distinct_tus=len(compiled), compiler_attempts=len(compiled), links=0, gpu_processes=0,
        scope='Exact local Prepared/vtable CaptureBindings proofs for causal convolution and audited fixed native leaves. Unknown routes remain false. No runtime flags, math kernels, public layout or Graph gate changes.'))
    print('READY: six CXX objects, no link/run', flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'build':
        build()
    else:
        raise ValueError(sys.argv[1])
