from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-model-submission-source-20261027/check_current.py')
p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
b,h=p.b,p.h

def compile_unit(name,source,prior):
    out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
    recipe=b.read(prior/'command.json')['command']
    command=[x.replace(str(prior),str(out)) for x in recipe]
    pin=b.pin(source)
    target=W/'source'/source.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
    process=h.execute(command,p.environment('cli'),W/'logs'/name,timeout=180)
    b.exact(pin)
    raw=b.read(out/'dependencies.json')['Data']
    deps=[b.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])]
    b.save(out/'actual-dependencies.json',deps)
    result=dict(name=name,source=pin,object=b.pin(out/'unit.obj'),process=process,dependencies=b.pin(out/'actual-dependencies.json'))
    b.save(out/'compiled.json',result)
    print('COMPILED '+name,flush=True)
    return result

if __name__=='__main__':
    if sys.argv[1]=='model':
        name=sys.argv[2] if len(sys.argv)>2 else 'model'
        compile_unit(name,R/'engine/models/qwen35/main.cc',R/'.scratch/inference-model-submission-source-20261027/compile/model')
    elif sys.argv[1]=='probe':
        name=sys.argv[2] if len(sys.argv)>2 else 'probe'
        compile_unit(name,R/'tests/tools/qwen_submission_source_probe.cc',R/'.scratch/inference-model-submission-source-20261027/compile/probe')
    else:raise ValueError(sys.argv[1])
