from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('cleanup_build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
targets=[W/'bin/qwen-relay-diag.exe',W/'bin/qwen-relay-diag2.exe',
 R/'.scratch/inference-successor-kv-20261027/bin/successor-kv-test.exe',
 R/'.scratch/inference-deferred-source-bind-20261027/bin/deferred-source-bind-test.exe',
 R/'.scratch/inference-model-submission-source-20261027/bin/submission-source-test.exe']
targets += [W/'compile'/x/'unit.obj' for x in ['model','model2','model3','probe','probe2','probe3','probe4']]
targets += [R/'.scratch/inference-capture-miss-20261027/compile'/x/'unit.obj' for x in ['executable','executable2']]
kept=[W/'bin/hyle.exe',W/'bin/qwen-submission-source-probe.exe',
 R/'.scratch/inference-deferred-source-bind-20261027/attempt-final/bin/deferred-source-bind-final-test.exe']
def rows(paths):
 return '\n'.join("    @{ relative = '%s'; bytes = %s; sha256 = '%s' }" %(str(p.relative_to(R)).replace('/','\\'),m.b.pin(p)['bytes'],m.b.pin(p)['sha256']) for p in paths)
script=r'''param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$prefix = $workspace.TrimEnd('\') + '\'
$targets = @(
__TARGETS__
)
$kept = @(
__KEPT__
)
$checked = foreach ($item in @($targets) + @($kept)) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $item.relative))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped workspace' }
    $file = Get-Item -LiteralPath $path
    if ($file.PSIsContainer -or $file.Length -ne $item.bytes) { throw "File identity changed: $path" }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "Hash changed: $path" }
}
$deleted = @($targets | ForEach-Object { [ordered]@{path = [IO.Path]::GetFullPath((Join-Path $workspace $_.relative)); bytes = $_.bytes; sha256 = $_.sha256} })
$result = [ordered]@{action = 'preview'; targets = $deleted; kept = $kept; bytes = ($targets | Measure-Object -Property bytes -Sum).Sum}
$receipt = Join-Path $workspace '.scratch\inference-model-successor-20261027\cleanup'
New-Item -ItemType Directory -Path $receipt -Force | Out-Null
if ($Execute) {
    foreach ($item in $deleted) { Remove-Item -LiteralPath $item.path -Force }
    $result.action = 'deleted'
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $receipt 'executed.ps1')
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $receipt ($result.action + '.json')) -Encoding UTF8
$result | ConvertTo-Json -Depth 6
'''.replace('__TARGETS__',rows(targets)).replace('__KEPT__',rows(kept))
(R/'test.ps1').write_text(script,encoding='utf-8-sig')
print('Wrote exact cleanup script for %d superseded files; %.2f MiB' %(len(targets),sum(p.stat().st_size for p in targets)/2**20))
