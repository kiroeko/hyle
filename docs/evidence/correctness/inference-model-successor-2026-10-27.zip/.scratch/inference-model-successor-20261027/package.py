from pathlib import Path
import importlib.util
import hashlib
import json
import subprocess
import sys
import zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('latest_build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b=m.b
native=R/'.scratch/inference-native-capture-bindings-20261027'
deferred=R/'.scratch/inference-deferred-source-bind-20261027'
kv=R/'.scratch/inference-successor-kv-20261027'
ledger=R/'.scratch/inference-successor-ledger-20261027'
diagnostic=R/'.scratch/inference-capture-miss-20261027'
owned=['engine/models/qwen35/main.cc','engine/models/qwen35/execution_mode.h',
 'engine/models/qwen35/generation_ledger.h','include/hyle/graph/detail/output_source.h',
 'src/graph/resources.cc','src/graph_batch/paged_append.cc','tests/CMakeLists.txt',
 'tests/graph/output_source_cuda_test.cc','tests/graph_batch/paged_append_source_test.cc',
 'tests/tools/qwen_generation_ledger_test.cc','tests/tools/qwen_submission_source_probe.cc',
 'docs/architecture/inference-design.md','docs/developer/inference-progress.md']
owned += [str(Path(x['path']).relative_to(R)).replace('\\','/') for x in b.read(native/'source-freeze.json')]
owned=list(dict.fromkeys(owned))
for root in [W,native,deferred,kv,ledger,diagnostic]:assert root.is_dir()
ready=b.read(W/'ready4.json')
for unit in ready['compiled']:
    b.exact(unit['source']);b.exact(unit['object'])
for artifact in ready['artifacts']:
    b.exact(artifact['image'])
    for row in b.read(artifact['inputs']['path']):b.exact(row)
for row in b.read(native/'source-freeze.json'):
    assert b.pin(row['path'])=={k:row[k] for k in ['path','bytes','sha256']}
tiny=b.read(W/'run-relay-tiny4/summary.json');real=b.read(W/'run-relay-real4/summary.json')
assert all(x['report']['status']=='PASS' and x['report']['rejected_successor_preserved_predecessor'] for x in [tiny,real])
component=b.read(deferred/'attempt-final/summary.json');assert component['status']=='PASS' and component['test_count']==7
cli=b.read(W/'cli4-summary.json');assert cli['status']=='PASS' and len(cli['runs'])==4
failures=[]
for name in ['run-relay-tiny','run-relay-real','run-relay-tiny2','run-relay-tiny3','run-relay-tiny-diag','run-relay-tiny-diag2']:
    raw=b.read(W/name/'process.json')
    assert raw['exit']!=0
    failures.append(dict(run=name,process=raw,stderr=b.pin(W/name/'stderr.log')))
destination=R/'docs/evidence/correctness';destination.mkdir(parents=True,exist_ok=True)
archive=destination/'inference-model-successor-2026-10-27.zip'
files={R/p for p in owned}
files.add(R/'test.ps1')
allowed={'.json','.py','.log','.xml','.cc','.h','.ps1'}
for root in [W,native,deferred,kv,ledger,diagnostic]:
    files.update(p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in allowed
      and p.name not in ['environment.json'])
for label,model in [('tiny',R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'),
                    ('real',R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')]:
    files.add(model/'weights.tsv')
inventory=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(files,key=lambda x:str(x).casefold()):
        name=str(path.relative_to(R)).replace('\\','/')
        row=b.pin(path);inventory.append(dict(name=name,bytes=row['bytes'],sha256=row['sha256']))
        z.write(path,name)
    manifest=('path\tbytes\tsha256\n'+''.join('%s\t%s\t%s\n'%(x['name'],x['bytes'],x['sha256']) for x in inventory)).encode('utf-8')
    z.writestr('manifest.tsv',manifest)
record=dict(status='PASS_WITH_EXPLICIT_REMAINING_SCOPE',date='2026-10-27',
 baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 hardware=dict(gpu='NVIDIA GeForce RTX 4070',driver='617.14',reported_memory_mib=12282),
 scope='Original Model ordinary greedy T1, three physical carriers and two candidate depth; finite controlled pair, not continuous request scheduling or a throughput result.',
 changes=[
  'Exact inherited KV read admissions include actual local attention, not only COW copies.',
  'Source binding establishes authority; final capture tuple remains checked at both preparation and submission.',
  'Exact immutable native CUDA Prepared artifacts describe their capture bindings; unknown routes remain rejected.',
  'Real ready frames fork metadata; pending candidates remain non-ready and use the original complete token/Store/KV Source.',
  'Reject live predecessor carrier before claiming its run; defer rejected successor destruction until actual predecessor retirement and never promote it.',
  'GenerationLedger separately reserves unknown successor input and binds only after the real predecessor commit is observed.'],
 final_sources=[b.pin(R/p) for p in owned],
 complete_model_checks=[dict(model='tiny',**tiny),dict(model='qwen35_2b',**real)],
 final_component=component,ledger=b.read(ledger/'summary.json'),final_cli=cli,
 cleanup=b.read(W/'cleanup/deleted.json'),
 counts=dict(cxx_invocations=23,links=15,test_processes=21,passed_test_processes=14,
   failed_test_processes=7,final_component_cases=7,host_ledger_groups=4,
   complete_model_processes=2,model_arms_per_process=3,final_cpu_cuda_ordinary_mtp_b2_processes=4,
   sdk_rebuilds=0,nvcc_invocations=0,model_download_bytes=0),
 earlier_model_failures=failures,
 diagnoses=[
  'Initial artificial context limit rejection, then sealed ready frame rejected; corrected without widening actual model capacity.',
  'Pending capture refusal reproduced before and after deferred final-tuple checking; deferred checking alone did not solve the Model issue.',
  'Two scratch-only instrumented Graph objects localized the actual refusal to operation-private-contract, hyle-cuda custom op at step 17; native causal convolution lacked the exact extension.',
  'Unsubmitted cleanup can destroy CUDA capture/workspace and synchronize another stream; original 30s watchdog exposed it. Exact blocking free was not timed. Rejected-successor check now returns before watchdog release.'],
 boundaries=[
  'Not connected to the natural RequestLoop or a continuous two-episode pipeline.',
  'Finite greedy ordinary R1 proof only; MTP accepted subsets, sampling relay, output credit, EOS and cancellation require their own owner integration.',
  'No new throughput, memory peak, quality, Apple/Vulkan or real native-driver-fault-injection result.',
  'Earlier CLI/Source test images are separately recorded; the final seven component cases were run together in one final image.',
  'Archive includes current source, commands, logs, manifests and dependency identities, not model weights, binaries, SDKs or every overwritten intermediate source revision.'],
 remaining=['Natural two-step decode quantum within actual output credit; EOS/cancel/pause and exact cold-tuple recovery.',
   'Continuous bounded handoff, MTP accepted-subset relay and owner-level ordered observation.',
   'Migration review plus complete prefill/decode/memory/combined comparisons after functional integration.'],
 archive=b.pin(archive),archive_inventory=dict(file='manifest.tsv',entries=len(inventory),
   bytes=len(manifest),sha256=hashlib.sha256(manifest).hexdigest()))
b.save(destination/'inference-model-successor-2026-10-27.json',record)
print(json.dumps(dict(status=record['status'],archive_bytes=archive.stat().st_size,files=len(inventory),owned_files=len(owned),counts=record['counts'])),flush=True)
