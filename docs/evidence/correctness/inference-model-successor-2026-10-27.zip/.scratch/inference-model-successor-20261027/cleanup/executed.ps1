﻿param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$prefix = $workspace.TrimEnd('\') + '\'
$targets = @(
    @{ relative = '.scratch\inference-model-successor-20261027\bin\qwen-relay-diag.exe'; bytes = 141864960; sha256 = '254a497446ecffc2bb7e85de5aa470ee76c7dc41b7dbdc8ce98956b2924f16c6' }
    @{ relative = '.scratch\inference-model-successor-20261027\bin\qwen-relay-diag2.exe'; bytes = 141865472; sha256 = '332e72cc4f31feb6af9e747275b8140833fa344c940cd4633e2971e34d814821' }
    @{ relative = '.scratch\inference-successor-kv-20261027\bin\successor-kv-test.exe'; bytes = 146667520; sha256 = 'c6d22c77d4ac29e5a1120216931787d0df438ee8d7cd5f6e6020d937b3fba784' }
    @{ relative = '.scratch\inference-deferred-source-bind-20261027\bin\deferred-source-bind-test.exe'; bytes = 146642944; sha256 = 'fb585adb3fa6710cb5e2405ae853143a714ceeaffcf960018141c93c17491636' }
    @{ relative = '.scratch\inference-model-submission-source-20261027\bin\submission-source-test.exe'; bytes = 146634240; sha256 = '017306e4dec963d26517159419c6456a2ee09a7587f4e44c833731b261d7631b' }
    @{ relative = '.scratch\inference-model-successor-20261027\compile\model\unit.obj'; bytes = 15844313; sha256 = '62b4f4e2b3a13d0cdd6f4bed05721b5fc2391e3ec4bce813a8fc86a7750af689' }
    @{ relative = '.scratch\inference-model-successor-20261027\compile\model2\unit.obj'; bytes = 15845938; sha256 = 'a0276e2feecc25877a9ec7159fb446b51301a23534b321930f5ce278fa4b0f06' }
    @{ relative = '.scratch\inference-model-successor-20261027\compile\model3\unit.obj'; bytes = 15845938; sha256 = '653e51b32576bf95f60b3afb40aecbb9c66216d05a8f6be0fba9f0fa9afbd664' }
    @{ relative = '.scratch\inference-model-successor-20261027\compile\probe\unit.obj'; bytes = 16255981; sha256 = '0acf62933b9d92460e3a2f1ce9a756c6ffcff1f7252bfd8343bea278332d68ee' }
    @{ relative = '.scratch\inference-model-successor-20261027\compile\probe2\unit.obj'; bytes = 16257658; sha256 = 'ef3e46b3c0c291cc2d0d970524498021d86a3591203b861242e868e343bf64c8' }
    @{ relative = '.scratch\inference-model-successor-20261027\compile\probe3\unit.obj'; bytes = 16258548; sha256 = '6eb43b816f2dd55673ab44e3f82d7d3d8f333c1d38094197e34660b72f908c0b' }
    @{ relative = '.scratch\inference-model-successor-20261027\compile\probe4\unit.obj'; bytes = 16263280; sha256 = '2adbf797fed4068bd378f4420debd4838f424c58bc6e11c64d5ff07ff215afc4' }
    @{ relative = '.scratch\inference-capture-miss-20261027\compile\executable\unit.obj'; bytes = 5217824; sha256 = 'e638fcab646f664bc1e12c10c60133389d89b1e620f5746ea76011f779a7bc2c' }
    @{ relative = '.scratch\inference-capture-miss-20261027\compile\executable2\unit.obj'; bytes = 5218225; sha256 = 'd0034f589d0c3ec3cce7f946080ca035ee6439f63e914d8a8045c48169cf3fae' }
)
$kept = @(
    @{ relative = '.scratch\inference-model-successor-20261027\bin\hyle.exe'; bytes = 142330880; sha256 = 'e0dfd15537365a19a82285cd6e87212d01d61f59aed52df24a143a071cc334aa' }
    @{ relative = '.scratch\inference-model-successor-20261027\bin\qwen-submission-source-probe.exe'; bytes = 141864960; sha256 = '6aa76dd332f33cad1b8b22e9a144d71401215ecb23fb81dea56ff4ab75e342bb' }
    @{ relative = '.scratch\inference-deferred-source-bind-20261027\attempt-final\bin\deferred-source-bind-final-test.exe'; bytes = 146670592; sha256 = '0a58380552e27399e07bc3ca02dc0e1c2ff2717b12e210744e2ebb239bb20926' }
)
$checked = foreach ($item in @($targets) + @($kept)) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $item.relative))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped workspace' }
    $file = Get-Item -LiteralPath $path
    if ($file.PSIsContainer -or $file.Length -ne $item.bytes) { throw "File identity changed: $path" }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "Hash changed: $path" }
}
$deleted = @($targets | ForEach-Object { [ordered]@{path = [IO.Path]::GetFullPath((Join-Path $workspace $_.relative)); bytes = $_.bytes; sha256 = $_.sha256} })
$result = [ordered]@{action = 'preview'; targets = $deleted; kept = $kept; bytes = ($targets | Measure-Object -Property bytes -Sum).Sum}
$receipt = Join-Path $workspace '.scratch\inference-model-successor-20261027\cleanup'
New-Item -ItemType Directory -Path $receipt -Force | Out-Null
if ($Execute) {
    foreach ($item in $deleted) { Remove-Item -LiteralPath $item.path -Force }
    $result.action = 'deleted'
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $receipt 'executed.ps1')
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $receipt ($result.action + '.json')) -Encoding UTF8
$result | ConvertTo-Json -Depth 6
