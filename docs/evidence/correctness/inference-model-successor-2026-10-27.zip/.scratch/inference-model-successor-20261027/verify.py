from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('current_link',W/'link_run.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b,h=m.b,m.h

def component():
    root=R/'.scratch/inference-deferred-source-bind-20261027'
    plan=b.read(root/'run-plan.json');ready=b.read(root/'ready.json')
    b.exact(ready['image'])
    for row in b.read(root/'test-link-inputs.json'):b.exact(row)
    env=m.env();env['PATH']=b.read(root/'runtime.json')['PATH']
    process=h.execute(plan['command'],env,root/'run',timeout=plan['timeout_seconds'])
    cases=ET.parse(plan['xml']).getroot().findall('./testsuite/testcase')
    assert len(cases)==plan['expected_test_count']==4
    assert {x.attrib['classname']+'.'+x.attrib['name'] for x in cases}==set(plan['tests'])
    assert all(x.attrib.get('status')=='run' and not x.findall('failure') and not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(root/'run-summary.json',dict(status='PASS',process=process,tests=[x.attrib for x in cases],image=ready['image']))
    print('PASS four actual source/capture cases',flush=True)

def cli():
    ready=b.read(W/'ready4.json');image=next(x['image'] for x in ready['artifacts'] if x['name']=='cli');b.exact(image)
    rows=b.read(R/'.scratch/inference-metadata-queue-20261027/run-plan.json')['cli']
    results=[]
    for row in rows:
        command=row['command'][:];command[0]=image['path'];out=W/'cli4'/row['name']
        process=h.execute(command,m.env(),out,timeout=row['timeout_seconds'])
        report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
        baseline=b.read(R/'.scratch/inference-metadata-queue-20261027/runs'/row['name']/'report.json')
        for key in ['backend','mtp','session_count','admitted_requests','retired_requests','live_committed_versions','generated_tokens','requested_output_tokens']:
            assert report[key]==baseline[key],(row['name'],key)
        actual=[(x['session_id'],x['result']['generated_ids']) for x in report['sessions']]
        assert actual==[(x['session_id'],x['result']['generated_ids']) for x in baseline['sessions']]
        assert report['generated_tokens']==report['requested_output_tokens']==16
        assert report['active_sequences']==2 and len(report['sessions'])==2
        assert any(x['requests']==2 and len(x['session_ids'])==2 for x in report['batches'])
        b.save(out/'report.json',report)
        results.append(dict(name=row['name'],process=process,ids=actual,report=b.pin(out/'report.json')))
        b.save(W/'cli4-partial.json',results)
    b.save(W/'cli4-summary.json',dict(status='PASS',image=image,runs=results,performance_claim=False))
    print('PASS CPU/CUDA ordinary/MTP B2 paths',flush=True)

if sys.argv[1]=='component':component()
elif sys.argv[1]=='cli':cli()
else:raise ValueError(sys.argv[1])
