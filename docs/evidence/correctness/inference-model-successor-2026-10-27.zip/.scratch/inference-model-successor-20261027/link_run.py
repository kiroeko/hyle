from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b,h,p=m.b,m.h,m.p
prior=R/'.scratch/inference-model-submission-source-20261027'

def env():
    result=p.environment('cli')
    seen=set();paths=[]
    for part in [str(W/'bin'),*result['PATH'].split(';')]:
        if not part or part.casefold() in seen:continue
        seen.add(part.casefold());paths.append(part)
    result['PATH']=';'.join(paths)
    return result

def link():
    compiled=[b.read(W/'compile'/name/'compiled.json') for name in ['model4','probe5']]
    kv=b.read(R/'.scratch/inference-successor-kv-20261027/ready.json')
    append=b.pin(R/'.scratch/inference-successor-kv-20261027/compile/append/unit.obj')
    b.save(W/'reused-kv.json',dict(ready=b.pin(R/'.scratch/inference-successor-kv-20261027/ready.json'),object=append))
    replacements={b.key(prior/'compile/model/unit.obj'):compiled[0]['object']['path'],
      b.key(prior/'compile/probe-v2/unit.obj'):compiled[1]['object']['path'],
      b.key(prior/'compile/resources-v2/unit.obj'):str(R/'.scratch/inference-deferred-source-bind-20261027/compile/resources/unit.obj'),
      b.key(prior/'compile/append-fix/unit.obj'):append['path']}
    for replacement in b.read(R/'.scratch/inference-native-capture-bindings-20261027/replacements.json'):
        replacements[b.key(replacement['old']['path'])]=replacement['new']['path']
    artifacts=[]
    (W/'bin').mkdir(parents=True,exist_ok=True)
    runtime=b.read(prior/'runtime.json');b.exact(runtime['native_cpu'])
    alias=W/'bin'/Path(runtime['native_cpu']['path']).name
    if not alias.exists():os.link(runtime['native_cpu']['path'],alias)
    runtime['PATH']=env()['PATH'];runtime['native_cpu_hardlink']=b.pin(alias)
    b.save(W/'runtime.json',runtime)
    for name,count in [('cli',224),('probe',223)]:
        for unit in compiled:b.exact(unit['source']);b.exact(unit['object'])
        inputs=[]
        for row in b.read(prior/(name+'-link-inputs-delivery.json')):
            if b.key(row['path']) in replacements:row=b.pin(replacements[b.key(row['path'])])
            b.exact(row);inputs.append(row)
        assert len(inputs)==count
        b.save(W/(name+'-link-inputs.json'),inputs)
        command=b.read(prior/('link-'+name+'-delivery/command.json'))['command']
        command=[replacements.get(b.key(x),x) for x in command]
        command=[('/OUT:'+str(W/'bin'/('hyle.exe' if name=='cli' else 'qwen-submission-source-probe.exe'))) if x.upper().startswith('/OUT:') else x for x in command]
        process=h.execute(command,env(),W/('link-'+name+'4'),timeout=120)
        image=Path(next(x[5:] for x in command if x.upper().startswith('/OUT:')))
        artifacts.append(dict(name=name,image=b.pin(image),process=process,inputs=b.pin(W/(name+'-link-inputs.json'))))
    b.save(W/'ready4.json',dict(compiled=compiled,artifacts=artifacts,runtime=b.pin(W/'runtime.json'),scope='Model explicit successor carriers, deferred failure cleanup, exact native capture contracts and KV inherited-prefix fix.'))
    print('READY 2 model CXX / 2 links; original SDK, kernels and frozen closure reused',flush=True)

def run(name,mode):
    ready=b.read(W/'ready4.json')
    artifact=next(x for x in ready['artifacts'] if x['name']=='probe');b.exact(artifact['image'])
    root=R/('.scratch/inference-paged-frame-20261026/tiny-recursive-input' if name=='tiny' else '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')
    manifest=b.pin(root/'weights.tsv')
    command=[artifact['image']['path'],*(['--relay'] if mode=='relay' else []),'--cuda',str(root)]
    out=W/('run-'+mode+'-'+name+'4')
    process=h.execute(command,env(),out,timeout=180)
    report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
    assert report['status']=='PASS' and report['old_checkpoint_unchanged'] and report['rng_cursor_unchanged'] and report['final_live_versions']==0 and not report['performance_claim']
    b.save(out/'report.json',report)
    b.save(out/'summary.json',dict(status='PASS',process=process,report=report,manifest=manifest,image=artifact['image']))
    print(json.dumps(report),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='link':link()
    elif sys.argv[1]=='run':run(sys.argv[2],sys.argv[3])
    else:raise ValueError(sys.argv[1])
