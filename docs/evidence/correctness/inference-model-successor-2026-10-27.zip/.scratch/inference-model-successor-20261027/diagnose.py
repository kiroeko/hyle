from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('link_current',W/'link_run.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b,h=m.b,m.h
diag=R/'.scratch/inference-capture-miss-20261027/compile/executable2/unit.obj'
prior=R/'.scratch/inference-model-submission-source-20261027/compile/executable/unit.obj'
rows=[b.pin(diag) if b.key(x['path'])==b.key(prior) else x for x in b.read(W/'probe-link-inputs.json')]
for x in rows:b.exact(x)
b.save(W/'diag2-link-inputs.json',rows)
image=W/'bin/qwen-relay-diag2.exe'
command=b.read(W/'link-probe3/command.json')['command']
command=[str(diag) if b.key(x)==b.key(prior) else '/OUT:'+str(image) if x.upper().startswith('/OUT:') else x for x in command]
linked=h.execute(command,m.env(),W/'link-probe-diag2',timeout=120)
b.save(W/'diag2-ready.json',dict(image=b.pin(image),inputs=b.pin(W/'diag2-link-inputs.json'),link=linked))
root=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
h.execute([str(image),'--relay','--cuda',str(root)],m.env(),W/'run-relay-tiny-diag2',timeout=180)
