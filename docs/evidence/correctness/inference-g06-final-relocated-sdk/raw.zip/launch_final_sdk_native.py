from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';route,mode,attempt=sys.argv[1:4];extra=sys.argv[4:]
assert route in ['cuda','apple','vulkan'] and mode in ['static','shared']
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
registry=json.loads((root/'docs/implementation/module-status.json').read_text(encoding='utf-8'));assert all(m['state']=='CANDIDATE' for m in registry['modules'] if 'inference-g06' in m.get('record',''))
product='669121418669b31f6849c74f64362aaf8d6eb919'
assert not subprocess.check_output(['git','diff','--name-only',product,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
tag=f'{route}-{mode}-{attempt}';out=base/'final-sdk';out.mkdir(exist_ok=True);archive=out/f'source-{tag}.zip'
assert not archive.exists()
inputs=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for name in subprocess.check_output(['git','ls-files'],text=True).splitlines():
  if name.startswith(('evidence/','.scratch/','.git')):continue
  p=root/name
  if p.is_file():
   raw=p.read_bytes();inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()});z.writestr(name,raw)
 z.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
 z.writestr('snapshot.json',json.dumps({'product_candidate':product,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}))
(out/f'runner-{tag}.py').write_bytes((base/'final_sdk_native.py').read_bytes())
if route=='cuda':
 code=subprocess.call(['wsl','-e','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/final_sdk_native.py',route,mode,attempt])
else:
 host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g06-final-sdk'
 subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
 for p in [archive,base/'final_sdk_native.py',base/'sdk_consumer_recipe.py',base/'final-sdk-headers.json']:
  subprocess.run(['scp','-q',str(p),host+':'+remote+'/'],check=True)
 code=subprocess.call(['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15',host,'/usr/bin/python3',remote+'/final_sdk_native.py',route,mode,attempt,*extra])
 # Fetch records and logs only; the relocated SDK/artifacts remain on Air.
 pack="from pathlib import Path;import zipfile;root=Path("+repr(remote)+");tag="+repr(tag)+";z=zipfile.ZipFile(root/('raw-'+tag+'.zip'),'w',zipfile.ZIP_DEFLATED);[(z.write(p,p.name)) for p in root.iterdir() if p.is_file() and tag in p.name and p.suffix in ['.json','.log','.xml','.cmake','.py','.ninja']];z.close()"
 import shlex
 subprocess.run(['ssh','-o','BatchMode=yes',host,'/usr/bin/python3 -c '+shlex.quote(pack)],check=True)
 subprocess.run(['scp','-q',host+':'+remote+'/raw-'+tag+'.zip',str(out)],check=True)
 with zipfile.ZipFile(out/('raw-'+tag+'.zip')) as z:z.extractall(out)
raise SystemExit(code)
