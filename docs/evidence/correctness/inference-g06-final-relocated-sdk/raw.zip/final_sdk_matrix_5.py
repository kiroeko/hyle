from pathlib import Path
import json, os, subprocess, sys, time

root=Path.cwd();base=root/'.scratch/inference-gaps/g06'
out=base/'final-sdk-matrix-5.json';assert not out.exists()
prior=json.loads((base/'final-sdk-matrix-4.json').read_text())
assert prior['state']=='TERMINAL_FAIL' and prior['stage']=='vulkan-static'
assert [(s['stage'],s['exit_code']) for s in prior['stages']]==[('cuda-static',0),('cuda-shared',0),('apple-static',0),('apple-shared',0),('vulkan-static',1)]
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
product='669121418669b31f6849c74f64362aaf8d6eb919'
assert not subprocess.check_output(['git','diff','--name-only',product,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
record={'state':'RUNNING','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'product_candidate':product,'stages':[],'prior_matrix':str(base/'final-sdk-matrix-4.json'),'scope':'Resume only two remaining Vulkan shipping SDK modes. Six actual passed configurations retained without rerun. Original static1 pre-build guard failure/cost retained. Max4 C++ workers, zero shader generation or CUDA compilation.'}
env=os.environ.copy();env['PYTHONUTF8']='1'
for mode,attempt,extra in [('static','2',['1']),('shared','1',[])]:
    args=[sys.executable,'-X','utf8','-u',str(base/'launch_final_sdk_native.py'),'vulkan',mode,attempt,*extra]
    start=time.monotonic();process=subprocess.Popen(args,env=env)
    record.update(stage='vulkan-'+mode,child_pid=process.pid)
    out.write_text(json.dumps(record,indent=2)+'\n');print('G06_SERIAL_SDK','vulkan-'+mode,'pid',process.pid,flush=True)
    code=process.wait();record['stages'].append({'stage':'vulkan-'+mode,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start})
    record['state']='TERMINAL_FAIL' if code else 'RUNNING';record.pop('child_pid',None);out.write_text(json.dumps(record,indent=2)+'\n')
    if code:raise SystemExit(code)
record['state']='TERMINAL_PASS';out.write_text(json.dumps(record,indent=2)+'\n');print('G06_FINAL_SDK_MATRIX_PASS',flush=True)
