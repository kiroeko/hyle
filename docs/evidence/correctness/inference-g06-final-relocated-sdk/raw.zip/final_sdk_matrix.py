from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';out=base/'final-sdk-matrix.json'
assert not out.exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
product='669121418669b31f6849c74f64362aaf8d6eb919'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',product,head,'--','include','src','cmake','CMakeLists.txt'],text=True).strip()
assert json.loads((base/'graph-page-final-risk-batch.json').read_text())['state']=='TERMINAL_PASS'
record={'state':'RUNNING','head':head,'product_candidate':product,'stages':[],'scope':'G06 serial final23-header/real public consumer relocated static/shared WindowsCPU,WSLCUDA,actualAirApple/Vulkan qualification. Max4 ordinaryworkers; no overlappingheavyjobs/P1.'}
jobs=[('cpu-'+mode,[sys.executable,'-u',str(base/'final_sdk_windows.py'),mode,'1']) for mode in ['static','shared']]
for route in ['cuda','apple','vulkan']:
 for mode in ['static','shared']:
  jobs.append((route+'-'+mode,[sys.executable,'-u',str(base/'launch_final_sdk_native.py'),route,mode,'1']))
for name,args in jobs:
 start=time.monotonic();process=subprocess.Popen(args)
 record.update(stage=name,child_pid=process.pid);out.write_text(json.dumps(record,indent=2)+'\n');print('G06_SERIAL_SDK',name,'pid',process.pid,flush=True)
 code=process.wait();record['stages'].append({'stage':name,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start})
 record['state']='TERMINAL_FAIL' if code else 'RUNNING';record.pop('child_pid',None);out.write_text(json.dumps(record,indent=2)+'\n')
 if code:raise SystemExit(code)
record['state']='TERMINAL_PASS';out.write_text(json.dumps(record,indent=2)+'\n');print('G06_FINAL_SDK_MATRIX_PASS',flush=True)
