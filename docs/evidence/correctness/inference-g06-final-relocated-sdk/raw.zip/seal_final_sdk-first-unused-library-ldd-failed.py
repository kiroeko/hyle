from pathlib import Path
import datetime
import hashlib
import json
import shlex
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path.cwd()
BASE = ROOT / '.scratch/inference-gaps/g06'
OUT = ROOT / 'evidence/correctness/inference-g06-final-relocated-sdk'
PRODUCT = '669121418669b31f6849c74f64362aaf8d6eb919'
assert not OUT.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', PRODUCT, 'HEAD', '--', 'include', 'src', 'cmake', 'CMakeLists.txt'], text=True).strip()
matrix = json.loads((BASE / 'final-sdk-matrix-5.json').read_text())
assert matrix['state'] == 'TERMINAL_PASS' and len(matrix['stages']) == 2
headers = set(json.loads((BASE / 'final-sdk-headers.json').read_text()))
assert len(headers) == 23


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def xml_result(path):
    root = ET.parse(path).getroot()
    assert all(root.attrib.get(k, '0') == '0' for k in ('failures', 'errors', 'disabled')), path
    assert not list(root.iter('skipped')), path
    cases = [c for c in root.iter('testcase')]
    assert len(cases) == int(root.attrib['tests']), path
    assert all(c.get('status') == 'run' and c.get('result') == 'completed' for c in cases), path
    return {'tests': len(cases), 'failures': 0, 'skips': 0, 'cases': [c.get('classname') + '.' + c.get('name') for c in cases]}


# Recheck the actual installed libraries, installed public inputs, consumers and
# their live dependency resolution on their own execution machines. No rebuild.
REMOTE_CHECK = r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys
folder,tag,route=json.loads(sys.argv[1])
base=Path(folder)
if route=='cuda':os.environ['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
record=json.loads((base/('result-'+tag+'.json')).read_text())
prefix=Path(record['prefix']);producer=record['producer']
artifacts=json.loads((base/('artifacts-'+tag+'.json')).read_text())
for row in artifacts:
 p=Path(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p
public=json.loads((base/('public-inputs-'+tag+'.json')).read_text())
consumer=prefix.parent/'consumer';build=prefix.parent/'build'
for row in public['headers']:
 assert hashlib.sha256((prefix/'include/hyle'/row['path']).read_bytes()).hexdigest()==row['sha256']
for row in public['consumers']:
 assert hashlib.sha256((consumer/row['path']).read_bytes()).hexdigest()==row['sha256']
names=['cpu','cpu_math','cpu_ragged','common','native','native_math']
names+=['capture_public','capture_hybrid','capture_pending'] if route=='cuda' else ['native_ragged','native_joint']
if route=='apple':names+=['metal_lifetime']
binaries=[];dependencies={}
for name in names:
 p=build/name;assert p.is_file()
 binaries.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 command=['ldd',str(p)] if route=='cuda' else ['otool','-L',str(p)]
 dependencies[name]=subprocess.check_output(command,text=True)
 assert producer not in dependencies[name] and '/staging/' not in dependencies[name]
 if route=='cuda':
  assert 'not found' not in dependencies[name]
  for line in dependencies[name].splitlines():
   if 'libhyle_' in line:
    assert str(prefix) in line,line
for row in artifacts:
 if Path(row['path']).suffix in ['.so','.dylib']:
  text=subprocess.check_output(['ldd',row['path']] if route=='cuda' else ['otool','-L',row['path']],text=True)
  assert producer not in text and '/staging/' not in text
  if route=='cuda':
   assert 'not found' not in text
   for line in text.splitlines():
    if 'libhyle_' in line:assert str(prefix) in line,line
  dependencies[row['path']]=text
print(json.dumps({'artifacts':len(artifacts),'artifact_bytes':sum(r['bytes'] for r in artifacts),'headers':len(public['headers']),'consumer_files':len(public['consumers']),'binaries':binaries,'dependencies':dependencies}))
'''

configurations = []
raw_files = set()
union = set()
for route in ['cpu', 'cuda', 'apple', 'vulkan']:
    for mode in ['static', 'shared']:
        attempt = '3' if (route, mode) == ('cpu', 'static') else '2' if (route, mode) == ('vulkan', 'static') else '1'
        tag = f'{route}-{mode}-{attempt}'
        folder = BASE / ('final-windows-sdk' if route == 'cpu' else 'final-sdk')
        record = json.loads((folder / f'result-{tag}.json').read_text())
        assert record['state'] == 'TERMINAL_PASS' and record['product_candidate'] == PRODUCT
        assert all(s['exit_code'] == 0 for s in record['stages'])
        for row in record['inputs']:
            assert digest(ROOT / row['path']) == row['sha256'], row['path']
        recipe = json.loads((folder / f'recipe-{tag}.json').read_text())
        applicable = set(recipe['independent_headers'])
        omitted = {r['path'] for r in recipe['not_applicable_headers']}
        assert len(applicable) == (20 if route in ('apple', 'vulkan') else 17)
        assert applicable.isdisjoint(omitted) and applicable | omitted == headers
        assert record['header_scope']['applicable'] == recipe['independent_headers']
        union.update(applicable)
        commands = json.loads((folder / f'consumer-commands-{tag}.json').read_text())
        assert len(commands) == recipe['compile_units']
        assert all(str(Path(record['prefix']) / 'include').replace('\\', '/') in r['command'].replace('\\', '/') for r in commands)
        shipping = json.loads((folder / f'shipping-{tag}.json').read_text())
        assert shipping and all('HYLE_TESTING' not in r['command'] and '-fsanitize=' not in r['command'] for r in shipping)
        tests = {}
        for path in folder.glob(f'*-{tag}.xml'):
            tests[path.name[:-len('-' + tag + '.xml')]] = xml_result(path)
        assert {k: tests[k]['tests'] for k in ['cpu', 'cpu_math', 'cpu_ragged', 'common']} == {'cpu': 4, 'cpu_math': 17, 'cpu_ragged': 4, 'common': 66}
        standalone = []
        if route == 'cuda':
            assert tests['native']['tests'] == 3 and tests['native_math']['tests'] == 16
            assert record['native_object_reuse']['state'] == 'PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
            assert 'Building CUDA object' not in (folder / f'producer-build-{tag}.log').read_text()
            standalone = ['capture_public', 'capture_hybrid', 'capture_pending']
        elif route in ('apple', 'vulkan'):
            assert record['identity']['model'] == 'Mac16,12' and record['identity']['arch'] == 'arm64'
            assert all(k in tests and tests[k]['tests'] > 0 for k in ['native', 'native_math', 'native_ragged'])
            standalone = ['native_joint']
        for name in standalone:
            assert 'PASS' in (folder / f'{name}-{tag}.log').read_text(), (tag, name)
        if route == 'cpu':
            artifact_rows = json.loads((folder / f'artifacts-{tag}.json').read_text())
            assert all(Path(r['path']).stat().st_size == r['bytes'] and digest(Path(r['path'])) == r['sha256'] for r in artifact_rows)
            staged = json.loads((folder / f'staged-runtime-{tag}.json').read_text())
            assert all(digest(Path(r['installed'])) == r['sha256'] == digest(Path(r['staged'])) for r in staged)
            if mode == 'shared':
                assert staged and any(Path(r['staged']).name == 'hyle_graph.dll' for r in staged)
            prefix = Path(record['prefix'])
            assert not (prefix.parent / 'staging').exists()
            for name in applicable:
                assert (prefix / 'include/hyle' / name).read_bytes() == (ROOT / 'include/hyle' / name).read_bytes()
            assert all((prefix.parent/'consumer'/name).read_bytes()==(ROOT/name).read_bytes() for name in recipe['copied_test_inputs'])
            binaries = []
            for name in tests:
                path = prefix.parent / 'build' / (name + '.exe')
                assert path.is_file()
                binaries.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)})
            recheck = {'artifacts': len(artifact_rows), 'artifact_bytes': sum(r['bytes'] for r in artifact_rows), 'headers': len(applicable), 'staged_dlls': len(staged), 'binaries': binaries}
        else:
            remote_folder = '/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/final-sdk' if route == 'cuda' else '/Users/kiro/hyle-scratch/compute-unified/g06-final-sdk'
            payload = json.dumps([remote_folder, tag, route])
            if route == 'cuda':
                output = subprocess.check_output(['wsl', '-e', 'python3', '-c', REMOTE_CHECK, payload], text=True)
            else:
                output = subprocess.check_output(['ssh', '-o', 'BatchMode=yes', 'kiro@172.22.10.198', '/usr/bin/python3 -c ' + shlex.quote(REMOTE_CHECK) + ' ' + shlex.quote(payload)], text=True)
            recheck = json.loads(output)
        recheck_file = BASE / ('sdk-artifact-recheck-' + tag + '.json')
        recheck_file.write_text(json.dumps(recheck, indent=2) + '\n')
        raw_files.add(recheck_file)
        for path in folder.iterdir():
            if path.is_file() and tag in path.name and path.suffix in ('.json', '.log', '.xml', '.cmake', '.py', '.ninja'):
                raw_files.add(path)
        configurations.append({'route': route, 'mode': mode, 'attempt': attempt, 'tests': tests, 'test_count': sum(t['tests'] for t in tests.values()), 'standalone_consumers': standalone, 'headers': recipe['independent_headers'], 'not_applicable_headers': recipe['not_applicable_headers'], 'compile_units': len(commands), 'identity': record['identity'], 'prefix': record['prefix'], 'producer': record['producer'], 'stages': record['stages'], 'stage_seconds': record['cumulative_seconds'], 'artifact_recheck': recheck, 'reused_installed': record.get('reused_installed'), 'reused_consumer': record.get('reused_consumer'), 'configuration_reused_from': record.get('configuration_reused_from'), 'shader_generator_qualification':record.get('shader_generator_qualification')})
assert union == headers
assert len(configurations) == 8
failures = []
for attempt in ['1', '2']:
    path = BASE / f'final-windows-sdk/result-cpu-static-{attempt}.json'
    failed = json.loads(path.read_text())
    assert failed['state'] == 'TERMINAL_FAIL'
    failures.append({'record': str(path.relative_to(BASE)), 'reason': failed.get('setup_error'), 'stages': failed['stages'], 'stage_seconds': failed['cumulative_seconds']})
    for p in path.parent.iterdir():
        if p.is_file() and f'cpu-static-{attempt}' in p.name and p.suffix in ('.json', '.log', '.xml', '.cmake', '.py'):
            raw_files.add(p)
path=BASE/'final-sdk/result-vulkan-static-1.json'
failed=json.loads(path.read_text());assert failed['state']=='TERMINAL_FAIL'
failures.append({'record':str(path.relative_to(BASE)),'reason':failed.get('setup_error'),'stages':failed['stages'],'stage_seconds':failed['cumulative_seconds']})
for p in path.parent.iterdir():
    if p.is_file() and 'vulkan-static-1' in p.name and p.suffix in ('.json','.log','.xml','.cmake','.py','.ninja'):
        raw_files.add(p)
for p in BASE.glob('final-sdk-matrix*.json'):
    raw_files.add(p)
for name in ['final_sdk_matrix.py', 'final_sdk_matrix_2.py', 'final_sdk_matrix_3.py', 'final_sdk_matrix_4.py', 'final_sdk_matrix_5.py', 'final_sdk_native-before-vulkan-guard-failed.py', 'launch_final_sdk_native-before-vulkan-resume.py', 'final_sdk_native.py', 'final_sdk_windows.py', 'final_sdk_windows-before-header-resume.py', 'sdk_consumer_recipe.py', 'sdk_consumer_recipe-first-union-failed.py', 'sdk_consumer_recipe-second-link-failed.py', 'launch_final_sdk_native.py', 'launch_final_sdk_native-before-utf8-failed.py', 'final-sdk-headers.json']:
    raw_files.add(BASE / name)
raw_files.add(Path(__file__).resolve())
OUT.mkdir(parents=True)
with zipfile.ZipFile(OUT / 'raw.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(raw_files):
        archive.write(path, path.relative_to(BASE).as_posix())
receipt = {
    'state': 'PASS_FOUR_ROUTE_RELOCATED_STATIC_SHARED_SDK',
    'product_candidate': PRODUCT,
    'source_snapshot': matrix['head'],
    'record': 'docs/implementation/tasks/compute/inference-g06-metadata-decode.md',
    'configurations': configurations,
    'independent_header_union': sorted(union),
    'failed_private_harness_attempts': failures,
    'prior_native_launcher_failure': {'reason': 'Windows default GBK registry read failed before native archive/build; fixed private UTF8 read only.', 'source': 'final-sdk-matrix-3.json', 'seconds': json.loads((BASE / 'final-sdk-matrix-3.json').read_text())['stages'][-1]['elapsed_seconds']},
    'native_serial_stages': json.loads((BASE/'final-sdk-matrix-4.json').read_text())['stages']+matrix['stages'],
    'raw_sha256': digest(OUT / 'raw.zip'),
    'limits': ['Actual shipped SDK only: HYLE_TESTING and sanitizers off; independent Apple/Vulkan headers are qualified only on their enabled native route, omitted-route headers are semantically NOT_APPLICABLE to that selected package.', 'Only public CPU ragged cases are in SDK: source-internal accepted-failure hook stays source-only and has separately qualified source/risk evidence.', 'No vendor/math change or full-model/tokens-per-second/P1/G04-G05 performance verdict.', 'Stage elapsed times overlap serial-wrapper totals; failures, paid static producer stages and earlier source/risk costs retained. Unmeasured investigation, editing and orchestration costs remain UNKNOWN.', 'Driver/shader/private-pool cost and original NVIDIA LSan/diagnostic-thread limits remain as in the active card.'],
    'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(OUT / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'state': receipt['state'], 'configurations': len(configurations), 'headers': len(union), 'tests': [(c['route'], c['mode'], c['test_count']) for c in configurations], 'raw_files': len(raw_files), 'receipt': str(OUT.relative_to(ROOT))}))
