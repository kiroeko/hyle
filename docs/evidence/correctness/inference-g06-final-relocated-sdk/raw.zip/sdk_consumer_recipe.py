from pathlib import Path

import re



def emit(source,prefix,route,consumer,headers,gtest,windows=False):

 platform_headers={'apple':{'compute/apple.h','compute/apple_batch.h','compute/detail/apple_batch_access.h'},'vulkan':{'compute/vulkan.h','compute/vulkan_batch.h','compute/detail/vulkan_batch_access.h'}}
 omitted=[{'path':name,'owner_route':owner,'reason':'Native route absent from this selected SDK; this header is qualified in its actual enabled native route, not through an empty guard.'} for owner,names in platform_headers.items() if owner!=route for name in sorted(names) if name in headers]
 headers=[name for name in headers if not any(name==row['path'] for row in omitted)]
 targets={

 'cpu':(['tests/compute_batch/encoded_page_common_consumer.cc'],True,[]),

 'cpu_math':(['tests/compute_provider_ggml/native_paged_test.cc'],True,[]),

 'cpu_ragged':(['tests/compute_provider_ggml/native_ragged_test.cc'],True,['HYLE_PUBLIC_SDK_ONLY=1']),

 'common':(['tests/compute_batch/batch_layout_test.cc','tests/compute_batch/batch_materialize_test.cc',

    'tests/compute_batch/native_paged_metadata_test.cc','tests/compute_batch/paged_arena_test.cc',

    'tests/graph_batch/materialized_graph_test.cc','tests/graph_batch/native_paged_node_test.cc'],True,[])}

 if route=='cuda':

  targets['native_math']=(['tests/compute_provider_flashinfer/native_cache_test.cc'],True,[])

  targets['native']=(['tests/compute_batch/encoded_page_common_consumer.cc'],True,['HYLE_ENCODED_CUDA=1'])

  for key,name in [('public','public_batch_cuda_consumer.cc'),('hybrid','public_hybrid_batch_consumer.cc'),('pending','pending_paged_receiver_cuda_consumer.cc')]:

   targets['capture_'+key]=(['tests/compute_batch/'+name],False,['HYLE_G06_CAPTURE_REPLAY=1'])

 elif route in ['apple','vulkan']:

  targets['native']=(['tests/compute_batch/encoded_page_native_consumer.cc'],True,['HYLE_ENCODED_APPLE=1'] if route=='apple' else [])

  targets['native_math']=([f'tests/compute_route_{route}/native_cache_test.cc'],True,[])

  targets['native_ragged']=([f'tests/compute_route_{route}/native_ragged_test.cc'],True,[])

  targets['native_joint']=(['tests/graph_batch/native_paged_joint_consumer.cc'],False,['HYLE_JOINT_PAGE_APPLE=1'] if route=='apple' else [])

 copied=set();excluded=[]

 def copy(name):

  if name in copied:return

  file=source/name;assert file.is_file(),name

  raw=file.read_bytes();dest=consumer/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);copied.add(name)

  for item in re.findall(r'^#include\s+"([^"]+)"',raw.decode(),re.M):

   if item.startswith('hyle/'):continue

   p=(file.parent/item).resolve()

   if not p.is_relative_to((source/'tests').resolve()):

    assert name=='tests/compute_provider_ggml/native_ragged_test.cc' and item=='../../src/compute/context_state.h',(name,item)

    excluded.append({'file':name,'include':item,'reason':'HYLE_PUBLIC_SDK_ONLY explicitly excludes only source-internal failure fixture; all original public runtime/numeric/OOM tests retained.'});continue

   copy(p.relative_to(source.resolve()).as_posix())

 for files,_,_ in targets.values():

  for name in files:copy(name)

 for i,name in enumerate(headers):

  assert (prefix/'include/hyle'/name).read_bytes()==(source/'include/hyle'/name).read_bytes(),name

  (consumer/f'header-{i}.cc').write_text(f'#include <hyle/{name}>\n')

 body='cmake_minimum_required(VERSION 3.25)\nproject(g06_final_sdk LANGUAGES CXX)\nfind_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\nset(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\n'

 body+='add_subdirectory("'+str(gtest).replace('\\','/')+'" gtest EXCLUDE_FROM_ALL)\n'

 for key,(files,testing,defines) in targets.items():

  body+='add_executable('+key+' '+' '.join(files)+')\n'

  body+='target_compile_features('+key+' PRIVATE cxx_std_23)\ntarget_link_libraries('+key+' PRIVATE hyle::compute hyle::graph'+(' GTest::gtest_main' if testing else '')+')\n'

  if defines:body+='target_compile_definitions('+key+' PRIVATE '+' '.join(defines)+')\n'

  # Independent public headers and ordinary standalone consumers use strict warnings.

  flags=('/W4 /wd4324 /utf-8'+(' /WX' if not testing else '')) if windows else ('-Wall -Wextra -Wpedantic'+(' -Werror' if not testing else ''))

  body+='target_compile_options('+key+' PRIVATE '+flags+')\nhyle_stage_runtime('+key+')\n'

 body+='add_library(headers OBJECT '+' '.join(f'header-{i}.cc' for i in range(len(headers)))+')\n'

 body+='target_compile_features(headers PRIVATE cxx_std_23)\ntarget_link_libraries(headers PRIVATE hyle::compute hyle::graph)\n'

 body+='target_compile_options(headers PRIVATE '+('/W4 /WX /wd4324 /utf-8' if windows else '-Wall -Wextra -Wpedantic -Werror')+')\n'

 (consumer/'CMakeLists.txt').write_text(body)

 return targets,{'copied_test_inputs':sorted(copied),'excluded_source_internal':excluded,'independent_headers':headers,'not_applicable_headers':omitted,'compile_units':len(headers)+sum(len(row[0]) for row in targets.values())}

