from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,zipfile

route,mode,attempt=sys.argv[1:4]
assert route in ('apple','vulkan','cuda') and mode in ('static','shared')
air=os.uname().sysname=='Darwin'
assert air==(route!='cuda')
BASE=Path('/Users/kiro/hyle-scratch/compute-unified' if air else '/root/hyle-scratch/compute-unified')
SOURCE=BASE/('source-c8874688' if air else 'source-7a7b4c3b')
OUT=(BASE/'g06-final-sdk' if air else Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/final-sdk'))
HELPER=Path(__file__).parent
OUT.mkdir(parents=True,exist_ok=True)
tag=f'{route}-{mode}-{attempt}';result_file=OUT/f'result-{tag}.json'
assert not result_file.exists() and SOURCE.is_dir() and not (SOURCE/'.git').exists()
with zipfile.ZipFile(OUT/f'source-{tag}.zip') as archive:
    snapshot=json.loads(archive.read('snapshot.json'))
    inputs=json.loads(archive.read('source-manifest.json'))
    for row in inputs:
        relative=Path(row['path']);assert not relative.is_absolute() and '..' not in relative.parts
        data=archive.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
        destination=SOURCE/relative
        if not destination.exists() or destination.read_bytes()!=data:
            destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
identity={name:subprocess.check_output(args,text=True).strip() for name,args in (
    [('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]
    if air else [('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'])])}
if air:assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
cmake='/opt/homebrew/bin/cmake' if air else 'cmake';ninja='/opt/homebrew/bin/ninja' if air else 'ninja'
env=os.environ.copy()
env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
producer=BASE/f'{"a" if air else "l"}-cpu-{route}/selected-graph/{mode}-sdk-build'
cache=(producer/'CMakeCache.txt').read_text()
assert f'CMAKE_HOME_DIRECTORY:INTERNAL={SOURCE}' in cache and 'HYLE_SANITIZER:STRING=off' in cache
folder=(OUT/tag if air else BASE/'g06-final-sdk'/tag)
folder.parent.mkdir(parents=True,exist_ok=True);folder.mkdir(exist_ok=False)
staging=folder/'staging';prefix=folder/'relocated';consumer=folder/'consumer';consumer.mkdir();build=folder/'build'
record={'state':'RUNNING','route':route,'mode':mode,'attempt':attempt,'identity':identity,'inputs':inputs,'source_snapshot':snapshot,'max_jobs':4,'stages':[],'cumulative_seconds':0,
        'product_candidate':'669121418669b31f6849c74f64362aaf8d6eb919','scope':'G06 frozen final relocated shipping SDK and route-applicable independent headers from the23-header union; actual runtime,common metadata and capture native/joint consumers; no product-private source headers/instrumentation/P1/full-model verdict.',
        'producer':str(producer),'prefix':str(prefix),'prior_project_include':[s for s in cache.splitlines() if s.startswith('CMAKE_PROJECT_INCLUDE:')]}

def failed_setup(kind,error,traceback):
    record['state']='TERMINAL_FAIL';record['setup_error']=repr(error)
    result_file.write_text(json.dumps(record,indent=2)+'\n')
    (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','setup_error':repr(error)}))
    sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed_setup
def run(stage,args):
    log=OUT/f'{stage}-{tag}.log';start=time.monotonic()
    with log.open('w') as handle:
        process=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'RUNNING','pid':process.pid,'stage':stage,'log':str(log)}))
        print(tag,stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start
    record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    record['cumulative_seconds']+=elapsed;record['state']='TERMINAL_FAIL' if code else 'RUNNING'
    result_file.write_text(json.dumps(record,indent=2)+'\n')
    print(tag,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}))
        print(log.read_text(errors='replace')[-6500:],flush=True);raise SystemExit(code)

args=[cmake,'-S',str(SOURCE),'-B',str(producer),'-UCMAKE_PROJECT_INCLUDE','-DHYLE_BUILD_TESTS=OFF',
      '-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_COMPONENTS=compute;graph']
if route=='cuda':args+=['-DCMAKE_PROJECT_INCLUDE=/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce19_cuda_compile.cmake']
run('producer-configure',args)
configured_cache=(producer/'CMakeCache.txt').read_text()
assert 'HYLE_BUILD_TESTS:BOOL=OFF' in configured_cache and 'HYLE_INSTALL:BOOL=ON' in configured_cache
commands=json.loads(subprocess.check_output([ninja,'-C',str(producer),'-t','compdb'],env=env,text=True))
shipping=[r for r in commands if r['file'].startswith(str(SOURCE/'src')+'/')]
assert shipping and all('HYLE_TESTING' not in r['command'] and '-fsanitize=' not in r['command'] for r in shipping)
(OUT/f'shipping-{tag}.json').write_text(json.dumps(shipping,indent=2)+'\n')
targets=['hyle_compute','hyle_compute_batch','hyle_compute_state','hyle_compute_stream','hyle_graph','hyle_graph_batch',f'hyle_graph_route_cpu_{route}']
if route!='cuda':targets += [f'hyle_compute_route_{route}',f'hyle_graph_route_{route}']
else:targets += ['hyle_compute_provider_flashinfer','hyle_compute_state']
run('producer-prepare-manifest',[ninja,'-C',str(producer),'build.ninja'])
if route=='cuda':
 helper=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce28_shipping_native_reuse_wsl.py')
 run('native-reuse-proof',['python3',str(helper),mode,'g06-sdk-'+attempt])
 parent=helper.parent/('ce28-'+mode+'-native-reuse-g06-sdk-'+attempt)
 proof=json.loads((parent/'result.json').read_text());assert proof['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
 assert hashlib.sha256((producer/'build.ninja').read_bytes()).hexdigest()==proof['original_manifest_sha256']
 manifest=parent/'reuse.ninja';record['native_object_reuse']=proof
else:
 manifest=OUT/f'exact-build-{tag}.ninja';manifest.write_bytes((producer/'build.ninja').read_bytes())
run('producer-plan',[ninja,'-C',str(producer),'-f',str(manifest),'-n',*targets])
plan=(OUT/f'producer-plan-{tag}.log').read_text()
assert not any(x in plan for x in ['Re-running CMake','Building CUDA object','vulkan-shaders-gen','vulkan_shaders.cc']),'Unplanned native/vendor rebuild'
run('producer-build',[ninja,'-C',str(producer),'-f',str(manifest),'-j','4' if air else '2',*targets])
run('install',[cmake,'--install',str(producer),'--prefix',str(staging)])
staging.rename(prefix);assert not staging.exists()
headers=json.loads((HELPER/'final-sdk-headers.json').read_text())
import sys as _sys
_sys.path.insert(0,str(HELPER))
from sdk_consumer_recipe import emit
matches=[Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6')] if air else [Path('/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6'),Path('/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6')]
gtest=next(p for p in matches if p.is_dir())
consumer_targets,recipe=emit(SOURCE,prefix,route,consumer,headers,gtest)
(OUT/f'recipe-{tag}.json').write_text(json.dumps(recipe,indent=2)+'\n')
headers=recipe['independent_headers']
record['header_scope']={'applicable':headers,'not_applicable':recipe['not_applicable_headers']}
(OUT/f'consumer-project-{tag}.cmake').write_bytes((consumer/'CMakeLists.txt').read_bytes())
args=[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
if route=='cuda':args+=['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3']
run('consumer-configure',args)
run('consumer-build',[cmake,'--build',str(build),'--target',*consumer_targets,'headers','--parallel','4' if air else '2'])
actual=[r for r in json.loads((build/'compile_commands.json').read_text()) if r['file'].startswith(str(consumer)+'/')]
assert len(actual)==recipe['compile_units'],(len(actual),recipe['compile_units'])
assert all(str(SOURCE) not in r['command'] and str(producer) not in r['command'] and str(prefix/'include') in r['command'] for r in actual)
(OUT/f'consumer-commands-{tag}.json').write_text(json.dumps(actual,indent=2)+'\n')
for name,(files,testing,defines) in consumer_targets.items():
 command=[str(build/name)]
 if testing:command+=['--gtest_output=xml:'+str(OUT/f'{name}-{tag}.xml')]
 run(name,command)
if route=='apple':
    header=prefix/'include/metal_cpp/Foundation/NSSharedPtr.hpp'
    assert hashlib.sha256(header.read_bytes()).hexdigest()=='d93f38effcc9556aa2cd2dec13db0cdcf37cd36bfd217bcbeedeb7e6c55fd2f4'
    manifest=json.loads((SOURCE/'third_party/mlx_cast/patches.json').read_text())
    allocator_header=next(f for f in manifest['files'] if f['path']=='mlx/backend/metal/allocator.h')
    assert hashlib.sha256((prefix/'include/mlx/backend/metal/allocator.h').read_bytes()).hexdigest()==allocator_header['after_sha256']
    lifetime=consumer/'metal_shared_ptr_lifetime.cc';lifetime.write_bytes((SOURCE/'tests/compute_route_apple/metal_shared_ptr_lifetime.cc').read_bytes())
    run('installed-metal-lifetime-compile',['xcrun','clang++','-std=c++20','-O3','-g','-Wall','-Wextra','-Wpedantic','-Werror','-fsanitize=undefined','-fno-sanitize-recover=all','-isystem',str(prefix/'include/metal_cpp'),str(lifetime),'-framework','Foundation','-framework','Metal','-o',str(build/'metal_lifetime')])
    run('installed-metal-lifetime',[str(build/'metal_lifetime')])
    license=prefix/'share/licenses/Hyle/mlx-metal-cpp-LICENSE.txt'
    assert license.read_bytes()==(SOURCE/'third_party/mlx_cast/metal-cpp-LICENSE.txt').read_bytes()
    assert (prefix/'share/licenses/Hyle/mlx-cast-NOTICE.md').read_bytes()==(SOURCE/'third_party/mlx_cast/NOTICE.md').read_bytes()
artifacts=[p for p in (prefix/'lib').rglob('*') if p.is_file() and p.name.startswith('libhyle') and p.suffix in ('.a','.dylib','.so')]
assert artifacts and any(p.name.startswith('libhyle_graph_batch') for p in artifacts)
(OUT/f'artifacts-{tag}.json').write_text(json.dumps([{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in artifacts],indent=2)+'\n')
(OUT/f'public-inputs-{tag}.json').write_text(json.dumps({'headers':[{'path':name,'sha256':hashlib.sha256((prefix/'include/hyle'/name).read_bytes()).hexdigest()} for name in headers],
    'consumers':[{'path':str(p.relative_to(consumer)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in consumer.rglob('*') if p.is_file()]},indent=2)+'\n')
assert all(hashlib.sha256((SOURCE/i['path']).read_bytes()).hexdigest()==i['sha256'] for i in inputs)
record['state']='TERMINAL_PASS';result_file.write_text(json.dumps(record,indent=2)+'\n')
(OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
print(tag,'ALL SHIPPING SDK STAGES PASS',flush=True)
