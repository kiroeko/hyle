from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
mode,attempt=sys.argv[1:3];assert mode in ('static','shared')
OUT=ROOT/'.scratch/inference-gaps/g06/final-windows-sdk';OUT.mkdir(exist_ok=True)
tag=f'cpu-{mode}-{attempt}';result_file=OUT/f'result-{tag}.json';assert not result_file.exists()
producer=ROOT/'.scratch/build-compute-v2-dev'
reuse_installed=sys.argv[sys.argv.index('--reuse-installed')+1] if '--reuse-installed' in sys.argv else None
reuse_consumer=sys.argv[sys.argv.index('--reuse-consumer')+1] if '--reuse-consumer' in sys.argv else None
folder=Path('C:/h7')/f'g06-sdk-cpu-{mode}-{reuse_installed}' if reuse_installed else Path('C:/h7')/f'g06-sdk-{tag}'
assert folder.resolve().parent==Path('C:/h7').resolve()
if not reuse_installed:
 assert not folder.exists();folder.parent.mkdir(parents=True,exist_ok=True);folder.mkdir()
staging=folder/'staging';prefix=folder/'relocated';consumer=folder/'consumer';build=folder/'build'
if reuse_installed:
 assert prefix.is_dir() and consumer.is_dir() and (bool(reuse_consumer)==build.exists())
else:consumer.mkdir()
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.stdout.splitlines() if '=' in line and not line.startswith('=')))
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs=[{'path':name,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in sorted(set(paths)) if (ROOT/name).is_file() and not name.startswith(('evidence/','.scratch/','.git'))]
record={'state':'RUNNING','mode':mode,'attempt':attempt,'max_jobs':4,'product_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'identity':{'host':env.get('COMPUTERNAME'),'compiler':env.get('VCTOOLSVERSION'),'routes':'cpu'},'inputs':inputs,'producer':str(producer),'prefix':str(prefix),
        'product_candidate':'669121418669b31f6849c74f64362aaf8d6eb919','scope':'G06 Windows CPU-only final relocated shipping static/shared SDK,route-applicable independent headers from23-header union,original public metadata/decode/runtime consumers; same original producer tree with explicit mode switch; no source-internal product headers.',
        'stages':[],'cumulative_seconds':0}
(OUT/f'runner-{tag}.py').write_bytes(Path(__file__).read_bytes())
(OUT/f'input-manifest-{tag}.json').write_text(json.dumps(inputs,indent=2)+'\n')

def failed_setup(kind,error,traceback):
    record['state']='TERMINAL_FAIL';record['setup_error']=repr(error)
    result_file.write_text(json.dumps(record,indent=2)+'\n')
    (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','setup_error':repr(error)}))
    sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed_setup
def run(stage,args):
    log=OUT/f'{stage}-{tag}.log';start=time.monotonic()
    with log.open('wb') as handle:
        process=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'RUNNING','pid':process.pid,'stage':stage,'log':str(log)}))
        print(tag,stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start;record['cumulative_seconds']+=elapsed
    record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    record['state']='TERMINAL_FAIL' if code else 'RUNNING';result_file.write_text(json.dumps(record,indent=2)+'\n')
    print(tag,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}))
        print(log.read_text(encoding='utf-8',errors='replace')[-6500:],flush=True);raise SystemExit(code)
if not reuse_installed:
 run('producer-configure',['cmake','-S',str(ROOT),'-B',str(producer),'-UCMAKE_PROJECT_INCLUDE',
     '-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF')])
cache=(producer/'CMakeCache.txt').read_text();assert 'HYLE_COMPUTE_ROUTES:STRING=cpu\n' in cache and 'HYLE_SANITIZER:STRING=off' in cache
ggml=next(s.split('=',1)[1] for s in cache.splitlines() if s.startswith('FETCHCONTENT_SOURCE_DIR_GGML_CPU:'))
assert 'ggml_cpu-ffa4e8b80930-' in ggml
record['identity']['ggml_source']=ggml
commands=json.loads(subprocess.check_output(['ninja','-C',str(producer),'-t','compdb'],env=env,text=True))
shipping=[r for r in commands if '/src/' in r['file'].replace('\\','/') and str(ROOT).replace('\\','/') in r['file'].replace('\\','/')]
assert shipping and all('HYLE_TESTING' not in c['command'] and '-fsanitize=' not in c['command'] for c in shipping)
(OUT/f'shipping-{tag}.json').write_text(json.dumps(shipping,indent=2)+'\n')
if not reuse_installed:
 run('producer-build',['cmake','--build',str(producer),'--target','hyle_compute','hyle_compute_batch','hyle_compute_stream','hyle_compute_state','hyle_compute_backend_cpu','hyle_compute_provider_ggml','hyle_compute_route_cpu','hyle_graph','hyle_graph_batch','--parallel','4'])
 run('install',['cmake','--install',str(producer),'--prefix',str(staging)])
 staging.rename(prefix);assert not staging.exists()
else:
 prior_path=OUT/f'result-cpu-{mode}-{reuse_installed}.json';prior=json.loads(prior_path.read_text())
 assert prior['state']=='TERMINAL_FAIL' and len(prior['stages'])==3 and all(row['exit_code']==0 for row in prior['stages'])
 assert [row['stage'] for row in prior['stages']]==['producer-configure','producer-build','install']
 assert prior['inputs']==inputs and prior['product_candidate']==record['product_candidate']
 assert prior['prefix']==str(prefix) and ('HYLE_STATIC:BOOL='+('ON' if mode=='static' else 'OFF')) in cache
 artifacts=[]
 for installed in prefix.rglob('hyle_*.lib'):
  actual=producer/'bin'/installed.name;assert actual.is_file(),actual
  digest=hashlib.sha256(installed.read_bytes()).hexdigest();assert hashlib.sha256(actual.read_bytes()).hexdigest()==digest
  artifacts.append({'path':str(installed),'sha256':digest,'bytes':installed.stat().st_size})
 assert artifacts
 record['reused_installed']={'prior':str(prior_path),'prior_state':prior['state'],'original_stages':prior['stages'],'artifacts':artifacts,'reason':'Only private SDK header applicability fixed; exact existing relocated installation/source/toolchain/mode reused, no producer stage reset or rebuild.'}
 if reuse_consumer:
  prior_consumer_path=OUT/f'result-cpu-{mode}-{reuse_consumer}.json';prior_consumer=json.loads(prior_consumer_path.read_text())
  assert prior_consumer['state']=='TERMINAL_FAIL' and prior_consumer['prefix']==str(prefix) and prior_consumer['inputs']==inputs
  assert prior_consumer['stages'][-1]['stage']=='consumer-build' and any(row['stage']=='consumer-configure' and row['exit_code']==0 for row in prior_consumer['stages'])
  record['reused_consumer']={'prior':str(prior_consumer_path),'original_stages':prior_consumer['stages'],'reason':'Fixture explicitly consumes both Compute State and Graph APIs; add both public product targets, preserve existing objects/install.'}

sys.path.insert(0,str(Path(__file__).parent))
from sdk_consumer_recipe import emit
headers=json.loads((Path(__file__).parent/'final-sdk-headers.json').read_text())
consumer_targets,recipe=emit(ROOT,prefix,'cpu',consumer,headers,Path('C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6'),windows=True)
(OUT/f'recipe-{tag}.json').write_text(json.dumps(recipe,indent=2)+'\n')
record['header_scope']={'applicable':recipe['independent_headers'],'not_applicable':recipe['not_applicable_headers']}
(OUT/f'consumer-project-{tag}.cmake').write_bytes((consumer/'CMakeLists.txt').read_bytes())
run('consumer-configure',['cmake','-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
run('consumer-build',['cmake','--build',str(build),'--target',*consumer_targets,'headers','--parallel','4'])
actual=[r for r in json.loads((build/'compile_commands.json').read_text()) if str(consumer).replace('\\','/') in r['file'].replace('\\','/')]
assert len(actual)==recipe['compile_units'],(len(actual),recipe['compile_units'])
for row in actual:
 command=row['command'].replace('\\','/')
 assert str(ROOT).replace('\\','/') not in command and str(prefix/'include').replace('\\','/') in command,command
(OUT/f'consumer-commands-{tag}.json').write_text(json.dumps(actual,indent=2)+'\n')
for name in consumer_targets:
 run(name,[str(build/(name+'.exe')),'--gtest_output=xml:'+str(OUT/f'{name}-{tag}.xml')])
artifacts=[p for p in prefix.rglob('*') if p.is_file() and p.suffix in ('.dll','.lib') and p.name.startswith('hyle_')]
assert artifacts
(OUT/f'artifacts-{tag}.json').write_text(json.dumps([{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in artifacts],indent=2)+'\n')
staged=[]
for runtime in [p for p in build.rglob('hyle_*.dll') if p.is_file()]:
    installed_matches=[p for p in artifacts if p.name==runtime.name and p.suffix=='.dll']
    assert len(installed_matches)==1,(runtime,installed_matches)
    installed=installed_matches[0]
    digest=hashlib.sha256(installed.read_bytes()).hexdigest()
    assert hashlib.sha256(runtime.read_bytes()).hexdigest()==digest,runtime
    staged.append({'installed':str(installed),'staged':str(runtime),'sha256':digest})
if mode=='shared':assert staged and any(Path(p['staged']).name=='hyle_graph.dll' for p in staged)
(OUT/f'staged-runtime-{tag}.json').write_text(json.dumps(staged,indent=2)+'\n')
assert all(hashlib.sha256((ROOT/i['path']).read_bytes()).hexdigest()==i['sha256'] for i in inputs)
record['state']='TERMINAL_PASS';result_file.write_text(json.dumps(record,indent=2)+'\n')
(OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
print(tag,'ALL CPU-ONLY SHIPPING SDK STAGES PASS',flush=True)
