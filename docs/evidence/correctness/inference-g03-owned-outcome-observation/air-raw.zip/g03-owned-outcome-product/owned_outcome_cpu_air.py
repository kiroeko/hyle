from pathlib import Path
import hashlib, json, os, subprocess, time
base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
out = base / 'g03-owned-outcome-product'
parent = out / 'apple-parent'
build = out / 'apple-build'
record = out / 'result.json'
data = json.loads(record.read_bytes())
name = 'tests/compute_batch/owned_outcome_cpu_consumer.cc'
data['inputs'].append({'path': name, 'sha256': hashlib.sha256((source / name).read_bytes()).hexdigest()})
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']
body = (parent / 'CMakeLists.txt').read_text()
if 'add_executable(native_cpu ' not in body:
    body += f'\nadd_executable(native_cpu "{source / name}")\ntarget_compile_features(native_cpu PRIVATE cxx_std_23)\ntarget_compile_options(native_cpu PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(native_cpu PRIVATE hyle::compute)\nhyle_stage_runtime(native_cpu)\n'
    (parent / 'CMakeLists.txt').write_text(body)
for stage, args in [('cpu-configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build)]),
    ('cpu-build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', 'native_cpu', '--parallel', '4']),
    ('native-cpu', [str(build / 'native_cpu')])]:
    attempt = 1 + sum(row['stage'] == stage for row in data['stages'])
    log = out / f'{stage}-{attempt}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.Popen(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
        (out / 'job.json').write_text(json.dumps({'state': 'RUNNING', 'pid': process.pid, 'log': str(log)}))
        print('RUN', stage, process.pid, flush=True)
        code = process.wait()
    data['stages'].append({'route': 'cpu', 'stage': stage, 'command': args, 'exit_code': code, 'elapsed_seconds': time.monotonic() - start, 'log': str(log)})
    data['cumulative_seconds'] = sum(row['elapsed_seconds'] for row in data['stages'])
    record.write_text(json.dumps(data, indent=2) + '\n')
    if code:
        print(log.read_text(errors='replace')[-4000:], flush=True)
        (out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': code}))
        raise SystemExit(code)
(out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': 0}))
