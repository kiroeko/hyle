from pathlib import Path
import hashlib, json, os, subprocess, time
base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
out = base / 'g03-owned-outcome-host'
out.mkdir(exist_ok=True)
inputs = json.loads((base / 'g03-owned-outcome-product/result.json').read_bytes())['inputs']
for row in inputs:
    assert hashlib.sha256((source / row['path']).read_bytes()).hexdigest() == row['sha256']
models = [
    (base / 'g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h', '2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'),
    (base / 'g01-metal-callback-tsan-probe/tsan-metal-cpp/Metal/MTLCommandBuffer.hpp', '4a58c6e564e3a7efcdf5c7709eeee99ec7b7c40594e2ada5ec5c91012171d504')]
for path, sha in models: assert hashlib.sha256(path.read_bytes()).hexdigest() == sha
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1', TSAN_OPTIONS='halt_on_error=1')
record = out / 'result.json'
rows = json.loads(record.read_bytes()).get('stages', []) if record.exists() else []
def run(route, mode, stage, args):
    attempt = 1 + sum(row['route'] == route and row['mode'] == mode and row['stage'] == stage for row in rows)
    log = out / f'{route}-{mode}-{stage}-{attempt}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.Popen(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
        (out / 'job.json').write_text(json.dumps({'state': 'RUNNING', 'pid': process.pid, 'log': str(log), 'route': route, 'mode': mode}))
        print('RUN', route, mode, stage, process.pid, flush=True)
        code = process.wait()
    rows.append({'route': route, 'mode': mode, 'stage': stage, 'command': args, 'exit_code': code, 'elapsed_seconds': time.monotonic() - start, 'log': str(log)})
    record.write_text(json.dumps({'scope': 'OO actual native/core lifecycle host instrumentation; existing two explicit TSan boundary models only; no LSan/driver/shader/private-pool qualification', 'inputs': inputs, 'models': [{'path': str(path), 'sha256': sha} for path, sha in models], 'stages': rows, 'cumulative_seconds': sum(row['elapsed_seconds'] for row in rows)}, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
    if code:
        print(log.read_text(errors='replace')[-6000:], flush=True)
        (out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': code}))
        raise SystemExit(code)
for route in ['apple', 'vulkan']:
    for mode in ['asan', 'ubsan', 'tsan']:
        root = base / f'foundation-f5-native-host-{route}-{mode}'
        parent = root / 'parent'
        build = root / 'build'
        targets = [('g03_oo_native', f'tests/compute_batch/pending_outcome_owner_{route}_probe.cc', 'hyle::compute'),
                   ('g03_oo_completion', 'tests/compute/completion_test.cc', 'hyle::compute GTest::gtest_main'),
                   ('g03_oo_copy_cpu', 'tests/compute_backend_cpu/copy_program_test.cc', 'hyle::compute GTest::gtest_main')]
        body = (parent / 'CMakeLists.txt').read_text()
        for target, name, link in targets:
            if f'add_executable({target} ' not in body:
                body += f'\nadd_executable({target} "{source / name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE {link})\nhyle_apply_sanitizer({target})\nhyle_stage_runtime({target})\n'
                if target == 'g03_oo_completion': body += f'target_include_directories({target} PRIVATE "{source / "src/compute"}")\n'
                if mode == 'tsan':
                    body += f'target_include_directories({target} BEFORE PRIVATE "{base / "g02-refcount-fence-probe/tsan-headers"}")\n'
                    if route == 'apple': body += f'target_include_directories({target} BEFORE PRIVATE "{base / "g01-metal-callback-tsan-probe/tsan-metal-cpp"}")\n'
        (parent / 'CMakeLists.txt').write_text(body)
        run(route, mode, 'configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build), '-DHYLE_COMPUTE_ROUTES=cpu;' + route])
        run(route, mode, 'build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target'] + [target for target, _, _ in targets] + ['--parallel', '4'])
        commands = json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja', '-C', str(build), '-t', 'compdb'], env=env, text=True))
        flag = '-fsanitize=' + {'asan': 'address', 'ubsan': 'undefined', 'tsan': 'thread'}[mode]
        names = ['src/compute/retained_completion.cc', 'src/compute/batch_transfer.cc', f'src/compute_route_{route}/{route}_copy_program.cc'] + [name for _, name, _ in targets]
        checked = []
        for name in names:
            found = [item for item in commands if item['file'].endswith(name)]
            assert found and all(flag in item['command'] for item in found), name
            checked.extend(found)
        (out / f'{route}-{mode}-instrumented-inputs.json').write_text(json.dumps(checked, indent=2) + '\n')
        for target, _, _ in targets: run(route, mode, target, [str(build / target)])
(out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': 0}))
