from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def pin(p):
 p=Path(p);v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
ready=read(W/'ready.json');summary=read(W/'summary.json');sources=read(W/'source-freeze.json')
for row in sources:assert pin(row['path'])==row
for row in read(W/'link-inputs.json'):assert pin(row['path'])==row
assert pin(ready['image']['path'])==ready['image']
assert summary['status']=='PASS' and len(summary['tests'])==1
files=[W/name for name in ['build.py','archive.py','plan.json','closure.json','source-freeze.json','compiled-partial.json','link-inputs.json','runtime.json','ready.json','summary.json','results.xml']]
files += [p for p in (W/'source').rglob('*') if p.is_file()]
for folder in ['compile/executable','compile/resources','compile/test','link','run']:
 files += [W/folder/name for name in ['command.json','process.json','stdout.log','stderr.log','dependencies.json','actual-dependencies.json'] if (W/folder/name).is_file()]
files=list(dict.fromkeys(files));members=[dict(member=p.relative_to(W).as_posix(),**pin(p)) for p in files]
old=R/'docs/evidence/correctness/inference-graph-output-region-2026-10-27.json'
receipt=dict(schema='hyle.inference.graph-output-capture.correctness.v1',date='2026-10-27',status='PASS',base_head_observed_before_edits='8c67b415d0dd88c453f8698b12a15c54b8123920',
 scope='One fixed caller-owned I32 output from an ordinary prepared CUDA producer feeds an already captured, original native checked Gather+Add consumer on the same actual Queue. Reuse-only preparation does not record pending data or change ggml runtime declarations.',
 implementation=dict(api=['detail::ReplayAccess::can_reuse_capture(const Invocation&, ValueId, ConstTensorView) -> Result<bool>','detail::ReplayAccess::prepare_reuse(Invocation&, span<const QueueBinding>) -> Status','OutputSource bind/prepare/submit keep one explicitly selected Commands or existing-Captured route'],facts=[
 'The pure capture query checks actual existing artifacts, complete command coverage, exact physical tuple, actual retained Queue and existing backend/private-argument preservation. It does not compile, bind, prepare, record or allocate device resources.',
 'The ordinary Invocation::prepare_replay and detail reuse-only entry share the original implementation. Public ReplayOptions and provider runtime declarations are unchanged; original rejects_unknown capture budget checks remain.',
 'Reuse-only first checks every current range/key and original Queue before metadata preparation, then checks every range again before artifact selection. A miss rejects before capture begin or variant eviction and never selects ordinary Commands.',
 'Source binding accepts managed runtime only when actual complete dormant capture qualifies. The selected consumer mode remains fixed; preparation and submission recheck physical identity and the original Queue.',
 'Original metadata/resource-only provider binding and seal hooks, InputSource device dependency/status reconciliation, ordered_read_unique and actual retirement remain authoritative. A plain Invocation::submit cannot bypass missing pending read authority.' ]),
 checks=dict(process=summary['process'],tests=summary['tests'],passed=1,failed=0,skipped=0,assertions=[
 'The selected consumer is one actual native Gather+Add region containing two nodes, with operation fallback rejected. Its original SharedQueue/Managed/blocks_host=true compile properties remain.',
 'A real initialized ready token block is bound to the consumer and legally captured before pending work; initial report records one capture and reuses zero.',
 'A different genuine embedding block makes pure query false and prepare_reuse reject; no replay report or Commands route is published. Restoring the old tuple preserves the recorded artifact.',
 'Original consumer unbind releases its real read alias; external final ReadLease.try_write succeeds and preserves resource, native handle, offset, size and generation. The resulting original writer is moved to the producer.',
 'An original CUDA Queue host gate proves the producer is pending. A bad tuple rejects Source binding without consuming its one consumer identity; restoring it permits Source binding.',
 'Pending preparation remains Captured with recorded_capture_range_count=0, reused_capture_range_count=1 and one device source wait, zero host source waits. No capture is recorded on pending data.',
 'Ordinary public consumer submit rejects. Original ordered submit is genuinely pending until the gate releases; after original completion retirement the consumer returns [60,62] from newly generated token2 rather than warm token1.',
 'The ten-second gate watchdog does not fire. Both Invocations retire, native use counts return to zero and final handle release returns the output blocks.' ]),
 counts=dict(distinct_CXX_TUs=3,compiler_attempts=3,successful_compiles=3,failed_compiles=0,links=1,images=1,test_processes=1,test_cases=1,NVCC=0,SDK_rebuilds=0,downloads=0,model_processes=0,benchmarks=0),failures=[],sources=sources,source_freeze=ready['source_freeze'],image=ready['image'],ready=pin(W/'ready.json'),compiled=ready['compiled'],link=ready['link'],retained_inputs=ready['inputs'],
 baseline=dict(receipt=pin(old),archive=pin(old.with_suffix('.zip')),ready=pin(R/'.scratch/inference-graph-output-region-20261027/ready2.json'),replacement_count=3,retained_inputs=227,total_inputs=230,note='Exact original 230-input closure retained, replacing executable.cc/resources.cc/test only. No object, binary, SDK, model or header tree is archived; actual dependency identities and source snapshots are retained.'),
 environment=dict(runtime=ready['runtime'],note='Same local Windows CUDA runtime/SDK/native object closure as the referenced prior evidence; no new toolchain/hardware measurement or SDK compilation in this batch.'),
 limits=[
 'This is a single actual shared Queue, one original prepared producer and one pre-recorded captured consumer component case. It does not enable managed Commands producers, multi-segment/native-island composition, full model/state/KV/MTP overlap or sustained finite-slot rotation.',
 'Pending inputs must never cause new recording or fallback to managed Commands. Missing artifacts, unsupported aliases, opaque native carriers, changed physical tuples or foreign Queues remain rejected.',
 'No performance or token/s claim, driver/native-fault injection, GPU spin kernel, model inference or download. Gate timing only proves an in-flight dependency, not throughput.',
 'The prior four GraphOutputSourceCuda cases were compiled but not rerun in this batch; their earlier receipts retain their actual observations.',
 'Original external pool roots, Graph metadata allocator lifetimes and actual StorageOwner retention contracts are unchanged.' ],archive_members=members)
local=W/'receipt.json';local.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive=W/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for path in files:z.write(path,path.relative_to(W).as_posix())
 z.write(local,'receipt.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in members:assert hashlib.sha256(z.read(row['member'])).hexdigest()==row['sha256']
public=R/'docs/evidence/correctness/inference-graph-output-capture-2026-10-27.json';assert not public.exists() and not public.with_suffix('.zip').exists()
public.with_suffix('.zip').write_bytes(archive.read_bytes());receipt['archive']=pin(public.with_suffix('.zip'));local.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');public.write_bytes(local.read_bytes())
publication=dict(receipt=pin(public),archive=pin(public.with_suffix('.zip')),members=len(files)+1,image=ready['image'],ready=pin(W/'ready.json'))
(W/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8');print(json.dumps(publication,indent=2))
