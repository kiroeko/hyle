from pathlib import Path
import importlib.util,json,os,sys,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];OLD=R/'.scratch/inference-graph-output-region-20261027'
HELPERS=R/'.scratch/inference-graph-output-source-20261027'
spec=importlib.util.spec_from_file_location('source_recipe',HELPERS/'build.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,m,h=p.b,p.m,p.h
SOURCES=['include/hyle/graph/detail/replay_access.h','include/hyle/graph/detail/output_source.h','src/graph/executable.cc','src/graph/resources.cc','tests/graph/output_source_cuda_test.cc']
def freeze():
    assert not (W/'source-freeze.json').exists()
    pins=[b.pin(R/s) for s in SOURCES];b.save(W/'source-freeze.json',pins)
    for s in SOURCES:
        target=W/'source'/s;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/s).read_bytes())
    old=b.read(OLD/'ready2.json');oldinputs=b.read(OLD/'link-inputs2.json');assert len(oldinputs)==230
    units=[]
    for name,src,template in [('executable',R/'src/graph/executable.cc',R/'.scratch/inference-stream-padding-20261026/compile/graph-executable/command.json'),('resources',R/'src/graph/resources.cc',OLD/'compile/resources/command.json'),('test',R/'tests/graph/output_source_cuda_test.cc',OLD/'compile2/test/command.json')]:
        original={'object':next(x for x in oldinputs if b.key(x['path'])==b.key(template.parent/'unit.obj'))}
        argv=b.read(template)['command'];out=W/'compile'/name;command=[]
        for i,a in enumerate(argv):
            if i and argv[i-1].lower()=='/sourcedependencies':a=str(out/'dependencies.json')
            elif a.lower().startswith('/fo'):a='/Fo'+str(out/'unit.obj')
            elif a.lower().startswith('/fd'):a='/Fd'+str(out/'unit.pdb')
            command.append(a)
        units.append(dict(name=name,source=b.pin(src),baseline_object=original['object'],template=b.pin(template),command=command))
    closure=m.c.closure([u['source']['path'] for u in units],[u['template']['path'] for u in units]);b.save(W/'closure.json',closure)
    b.save(W/'plan.json',dict(units=units,source_freeze=b.pin(W/'source-freeze.json'),baseline_ready=b.pin(OLD/'ready2.json'),baseline_inputs=b.pin(OLD/'link-inputs2.json'),counts=dict(CXX_TUs=3,links=1,images=1,test_processes=1,test_cases=1,NVCC=0,SDK=0)))
def env(plan):
    cl=plan['units'][0]['command'][0]
    return h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def check():
    for row in b.read(W/'source-freeze.json'):b.exact(row)
def build():
    plan=b.read(W/'plan.json');check();before=b.read(OLD/'link-inputs2.json')
    for row in before:b.exact(row)
    own={b.key(x['path']):x for x in b.read(W/'closure.json')};environment=env(plan);done=[]
    for u in plan['units']:
        out=W/'compile'/u['name'];assert not out.exists()
        process=h.execute(u['command'],environment,out,timeout=180)
        d=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([d['Source'],*d['Includes']])];b.save(out/'actual-dependencies.json',actual)
        for row in actual:
            if Path(row['path']).is_relative_to(R) and not Path(row['path']).is_relative_to(R/'.scratch'):assert own[b.key(row['path'])]['sha256']==row['sha256']
        check();done.append(dict(name=u['name'],source=u['source'],object=b.pin(out/'unit.obj'),process=process,dependencies=b.pin(out/'actual-dependencies.json')));b.save(W/'compiled-partial.json',done)
    repl={b.key(u['baseline_object']['path']):c['object'] for u,c in zip(plan['units'],done)}
    inputs=[repl.get(b.key(x['path']),x) for x in before];assert len(inputs)==230;b.save(W/'link-inputs.json',inputs)
    image=W/'bin/output-capture-test.exe';image.parent.mkdir(parents=True,exist_ok=True);command=[]
    for a in b.read(OLD/'link2/command.json')['command']:
        if b.key(a) in repl:a=repl[b.key(a)]['path']
        elif a.lower().startswith('/out:'):a='/OUT:'+str(image)
        elif a.lower().startswith('/pdb:'):a='/PDB:'+str(image.with_suffix('.pdb'))
        command.append(a)
    linked=h.execute(command,environment,W/'link',timeout=120)
    runtime=b.read(OLD/'runtime2.json');native=runtime['native_cpu'];b.exact(native);os.link(native['path'],image.parent/Path(native['path']).name);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(image=b.pin(image),compiled=done,link=linked,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),source_freeze=b.pin(W/'source-freeze.json')));print('READY',flush=True)
def run():
    ready=b.read(W/'ready.json');b.exact(ready['image']);check();environment=env(b.read(W/'plan.json'));environment['PATH']=b.read(W/'runtime.json')['PATH'];xml=W/'results.xml'
    process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter=GraphOutputSourceCuda.PendingI32ReusesRealNativeRegionCaptureWithoutRecording','--gtest_output=xml:'+str(xml)],environment,W/'run',timeout=60)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase');assert len(cases)==1 and int(root.attrib['tests'])==1
    assert all(c.attrib.get('status')=='run' and not c.findall('failure') and not c.findall('error') and not c.findall('skipped') for c in cases)
    b.save(W/'summary.json',dict(status='PASS',process=process,tests=[c.attrib for c in cases],image=ready['image'],source_freeze=ready['source_freeze'],scope='One pending I32 producer feeds a genuinely pre-recorded native Gather+Add region on the same Queue. Exact original block ready-to-unbind-to-writer handoff; tuple miss refuses without recording; pending consumer records zero and reuses one range. No managed producer, multi-segment/model/state/KV/full rotating pipeline or speed claim.'));print('PASS 1',flush=True)
if __name__=='__main__':
    try:{'freeze':freeze,'build':build,'run':run}[sys.argv[1]]()
    except Exception:
        b.save(W/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc(),note='Original sources/process/log/XML preserved; no automatic retry.'));raise
