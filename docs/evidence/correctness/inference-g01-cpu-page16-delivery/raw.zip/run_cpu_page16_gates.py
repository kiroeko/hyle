from pathlib import Path
import json, os, subprocess, sys, time
out=Path('.scratch/inference-gaps/g01');job=out/'cpu-page16-final-gates-job.json';rows=[]
steps=[(mode,['wsl.exe','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g01/run_cpu_paged_san.py',mode]) for mode in ('ubsan','tsan')]
steps += [(mode+'3-sdk',[sys.executable,str(out/'run_cpu_paged_sdk.py'),mode,'3']) for mode in ('static','shared')]
steps += [('air-mixed-cpu',['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3','kiro@172.22.10.198','/usr/bin/python3 /Users/kiro/hyle-scratch/compute-unified/g01-cpu-paged-portable/run.py'])]
for name,args in steps:
 job.write_text(json.dumps({'state':'RUNNING','pid':os.getpid(),'current':name,'stages':rows},indent=2)+'\n',encoding='utf-8');print('START '+name,flush=True);started=time.monotonic();r=subprocess.run(args)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started};rows.append(row);print(json.dumps(row),flush=True)
 if r.returncode:
  job.write_text(json.dumps({'state':'TERMINAL','exit_code':r.returncode,'failed_stage':name,'stages':rows},indent=2)+'\n',encoding='utf-8');raise SystemExit(r.returncode)
job.write_text(json.dumps({'state':'TERMINAL','exit_code':0,'stages':rows},indent=2)+'\n',encoding='utf-8')
