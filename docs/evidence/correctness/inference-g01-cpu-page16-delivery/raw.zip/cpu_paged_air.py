from pathlib import Path
import hashlib, json, os, subprocess, time, zipfile

base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
parent = base / 'a-cpu-apple/selected-graph/source-parent'
build = base / 'a-cpu-apple/selected-graph/source-build'
out = base / 'g01-cpu-paged-portable'
out.mkdir(exist_ok=True)
assert source.is_dir() and not (source / '.git').exists()
assert build.is_dir() and (parent / 'CMakeLists.txt').is_file()
assert subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip() == 'Mac16,12'
cache = (build / 'CMakeCache.txt').read_text()
routes = next(x.split('=', 1)[1] for x in cache.splitlines() if x.startswith('HYLE_COMPUTE_ROUTES:'))
assert 'cpu' in routes.split(';') and 'apple' in routes.split(';'), routes
assert str(parent) == next(x.split('=', 1)[1] for x in cache.splitlines() if x.startswith('CMAKE_HOME_DIRECTORY:'))
previous_sync = json.loads((out / 'synced-inputs.json').read_text()) if (out / 'synced-inputs.json').exists() else {}
with zipfile.ZipFile(out / 'input.zip') as archive:
    manifest = json.loads(archive.read('input-manifest.json'))
    changed = []
    for item in manifest:
        relative = Path(item['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        data = archive.read(item['path'])
        assert hashlib.sha256(data).hexdigest() == item['sha256']
        dest = source / relative
        if not dest.exists() or dest.read_bytes() != data:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            changed.append(item['path'])
        assert hashlib.sha256(dest.read_bytes()).hexdigest() == item['sha256']
(out / 'synced-inputs.json').write_text(json.dumps({'candidate': '42f98b94f33bdbb252b9259ece33533cf763fa41',
    'one_way': True, 'destination': str(source), 'inputs': manifest, 'changed': changed}, indent=2) + '\n')
identity = {name: subprocess.check_output(args, text=True).strip() for name, args in [
    ('model', ['/usr/sbin/sysctl', '-n', 'hw.model']), ('arch', ['uname', '-m']),
    ('os', ['sw_vers']), ('clang', ['xcrun', 'clang', '--version']),
    ('cpu', ['/usr/sbin/sysctl', '-n', 'hw.ncpu']), ('memory', ['/usr/sbin/sysctl', '-n', 'hw.memsize'])]}
hook = out / 'project.cmake'
body = '''if(PROJECT_NAME STREQUAL "hyle")
 function(g01_cpu_paged_portable)
  add_executable(g01_cpu_paged_tests "@SOURCE@/tests/compute_provider_ggml/native_paged_test.cc" "@SOURCE@/tests/compute_provider_ggml/native_ragged_test.cc" "@SOURCE@/tests/compute_provider_ggml/layout_broadcast_test.cc")
  target_compile_features(g01_cpu_paged_tests PRIVATE cxx_std_23)
  target_compile_options(g01_cpu_paged_tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(g01_cpu_paged_tests PRIVATE hyle::compute GTest::gtest_main)
  hyle_stage_runtime(g01_cpu_paged_tests)
 endfunction()
 cmake_language(DEFER CALL g01_cpu_paged_portable)
endif()
'''.replace('@SOURCE@', str(source))
hook_changed = not hook.exists() or hook.read_text() != body
if hook_changed:
    hook.write_text(body)
result_file = out / 'result.json'
rows = json.loads(result_file.read_text())['stages'] if result_file.exists() else []
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']

def run(name, args):
    attempt = 1 + sum(x['stage'] == name for x in rows)
    log = out / (name + '-' + str(attempt) + '.log')
    started = time.monotonic()
    with log.open('w') as f:
        result = subprocess.run(args, env=env, stdout=f, stderr=subprocess.STDOUT)
    row = {'stage': name, 'command': args, 'exit_code': result.returncode,
           'elapsed_seconds': time.monotonic() - started, 'log': str(log)}
    rows.append(row)
    result_file.write_text(json.dumps({'candidate': '42f98b94f33bdbb252b9259ece33533cf763fa41',
        'scope': 'actual CPU arm64 in mixed CPU+Apple core; no GPU run/hybrid paging claim',
        'identity': identity, 'stages': rows}, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        with log.open('rb') as f:
            f.seek(max(0, log.stat().st_size - 2500))
            print(f.read(2500).decode('utf-8', errors='replace'), flush=True)
        raise SystemExit(result.returncode)

config_inputs = lambda entries: [x for x in entries if x['path'].endswith(('.cmake', 'CMakeLists.txt', 'patches.json', 'HyleDependencyLock.json'))]
configured = next((x for x in reversed(rows) if x['stage'] == 'configure'), {}).get('exit_code') == 0
if hook_changed or not configured or config_inputs(previous_sync.get('inputs', [])) != config_inputs(manifest):
    run('configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build),
                      '-DCMAKE_PROJECT_INCLUDE=' + str(hook), '-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES'])
else:
    print(json.dumps({'configure': 'reused identical hook/CMake/lock/patch inputs'}), flush=True)
run('build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', 'g01_cpu_paged_tests', '--parallel', '4'])
commands = json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja', '-C', str(build), '-t', 'compdb'], text=True))
checked = []
for name in ('src/compute_provider_ggml/native_batch.cc', 'src/compute_provider_ggml/ggml_cpu_provider.cc', 'src/ggml-cpu/ops.cpp'):
    found = [x for x in commands if x['file'].endswith(name)]
    assert found, name
    checked.extend(found)
(out / 'compiled-inputs.json').write_text(json.dumps(checked, indent=2) + '\n')
for path in build.glob('**/g01_cpu_paged_tests'):
    if path.is_file() and os.access(path, os.X_OK):
        exe = path
        break
else:
    raise SystemExit('CPU test executable not found')
run('run', [str(exe)])
