"""Publish the finite seven-case result without duplicating its cached SDK."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import re
import zipfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
E = R / 'docs/evidence/correctness'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path.read_bytes()))


def relative_pin(path):
    row = pin(path)
    row['path'] = path.relative_to(R).as_posix()
    return row


summary = read(W / 'summary.json')
assert summary['tests'] == 7 and summary['failures'] == 0
ready = read(W / 'ready2.json')
assert pin(Path(ready['image']['path'])) == ready['image']
assert not (W / 'run2').exists()
preparation = read(W / 'build-preparation.json')
native = read(W / 'native-plan.json')
cpp = read(W / 'cpp-plan2.json')
for row in native['canonical']:
    assert pin(Path(row['path'])) == row
for item in cpp['source']:
    assert pin(Path(item['canonical']['path'])) == item['canonical']
    assert pin(Path(item['snapshot']['path'])) == item['snapshot']
lock = read(R / 'cmake/HyleDependencyLock.json')
deps = {row['name']: row for row in lock['dependencies']}
identity = [
    ('ggml_runtime_patches vendored tree', deps['ggml_runtime_patches']['vendored']['tree_sha256']),
    ('ggml_cpu_runtime_patches vendored tree', deps['ggml_cpu_runtime_patches']['vendored']['tree_sha256']),
    ('prepare_mixed_cpu_manifest.py raw SHA256', sha((R / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes())),
    ('prepare_cuda_iq1_manifest.py raw SHA256', sha((R / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes())),
    ('ggml_cuda_runtime_patches vendored tree', deps['ggml_cuda_runtime_patches']['vendored']['tree_sha256']),
    ('gated_delta_scale.h raw SHA256', sha((R / 'src/compute_ggml_runtime/gated_delta_scale.h').read_bytes()))]
version = '456172ec+iq1-46cbf0e9-resource-' + sha(''.join(value for _, value in identity).encode())[:16]
assert version == cpp['version'] and version in (W / 'provider-version.h').read_text()
formula = dict(source='src/compute_ggml_runtime/CMakeLists.txt:58,83,176-189',
    selected_native_flavor='Original CPU+CUDA source composition, no Metal/Vulkan native source patches in this NVCC closure.',
    concatenated_inputs=[dict(name=name, sha256=value) for name, value in identity],
    formula='SHA256(concatenate the six lower-case hex strings in this order), first16; prefix 456172ec+iq1-46cbf0e9-resource-',
    actual_version=version, actual_forced_include=pin(W / 'provider-version.h'),
    actual_provider_dependency='compile/provider/actual-dependencies.json')
(W / 'provider-version-identity.json').write_text(json.dumps(formula, indent=2) + '\n')
mapping = (W / 'link2/image.map').read_text(errors='replace')
markers = [line for line in mapping.splitlines() if ('ggml_hyle_cuda_conv_indexed_state_contract' in line or
    'ggml_hyle_cuda_gdn_indexed_state_contract' in line or 'ggml_cuda_op_ssm_conv_indexed' in line or
    'ggml_cuda_op_gated_delta_net_indexed' in line) and '$' not in line]
assert len(markers) == 4
(W / 'linked-markers.json').write_text(json.dumps(dict(map_file=pin(W / 'link2/image.map'),
    exact_selected_lines=markers, note='Both native contracts/entries are present. Exact direct object identities and sole replacements are in link2/command.json plus link2-inputs.json; object basenames alone are not unique.'), indent=2) + '\n')
runtime = read(W / 'runtime2.json')
process_tags = [('compile/conv', 'NVCC'), ('compile/dispatcher', 'NVCC'),
    ('compile/provider', 'CXX'), ('compile/tensor', 'CXX'), ('compile/graph', 'CXX'),
    ('compile/test', 'CXX first test, unrun image'), ('compile2/test', 'CXX final capture assertions'),
    ('link', 'first unrun image'), ('link2', 'final image'), ('run1', 'sole GPU test process')]
processes = [dict(stage=name, kind=kind, **read(W / name / 'process.json')) for name, kind in process_tags]
assert all(item['exit'] == 0 for item in processes)
base_json = E / 'inference-cpu-storage-gather-2026-10-27.json'
base_zip = E / 'inference-cpu-storage-gather-2026-10-27.zip'
facts = dict(schema=1, batch='inference-indexed-conv-graph-20261027', status='PASS',
    recorded_at=datetime.now(timezone(timedelta(hours=8))).isoformat(),
    scope='One RTX4070 Windows CUDA consumer image, seven Graph cases: four indexed causal-convolution cases and the three existing indexed GDN cases. No full inference-engine/model/performance conclusion.',
    actual_results=dict(distinct_TUs=6, native_NVCC_TUs=2, product_CXX_TUs=3, test_CXX_TUs=1,
        compiler_processes_for_build=7, compile_failures=0, link_processes=2, built_images=2,
        first_image_status='BUILT_NOT_RUN; superseded before any GPU run to strengthen capture assertions',
        final_image=ready['image'], final_test_processes=1, tests=7, failures=0, processes=processes),
    cases=summary['cases'],
    verified=[
        'The four new cases use the existing public Graph slots prepare/bind/take API and its original permissions/retirement owner; existing indexed GDN three-case public-binding regressions remain passing.',
        'F32 B2/C128/D4/T1/K1 uses one selected indexed-conv region/dispatch. Two real RequireCapture submissions pass: first record1/reuse0, then record0/reuse1 after exchanging destination slot IDs. A third prepared episode is reset and cannot execute with withdrawn authority.',
        'BF16 B2/C128/D4/T35/K3 covers the long-token path, chronological last-prefix history, actual source/unused-slot/padding preservation.',
        'F16 B2/C128/D4/T2/K2 preserves raw history bytes including NaN payloads/negative zero; finite activation bits match the original dense explicit-Cast-plus-convolution path, NaN activations are compared by classification.',
        'Publishing the BF16 Gather result legally rejects the fusion while the ordinary checked projected-read fallback still executes and returns the same history/activation results.',
        'Original Completion and result/lease retirement gates, exact destination recovery and reset invalidation remain checked. No full pool is presented as an initialized read lease.'
    ],
    capture=dict(case='GgmlCudaIndexedConvGraph.Float32BatchedFinalWindowUsesOriginalStateAndReset',
        actual_submissions=2, required_mode='RequireCapture', first=dict(recorded=1, reused=0),
        second=dict(recorded=0, reused=1, destination_IDs_changed=True),
        third_preparation_reset_without_submission=True, fallback_to_Commands=False),
    source_identity=dict(native_freeze=pin(W / 'source-freeze.json'), root_freeze=pin(W / 'root-freeze.json'),
        native_actual_snapshots=native['snapshots'], final_cpp_actual_sources=cpp['source'],
        initial_test_snapshot=next(item for item in read(W / 'cpp-plan.json')['source']
            if item['canonical']['path'].endswith('indexed_conv_test.cc')),
        private_ABI='Node/Recipe layouts unchanged; program.h is comment-only; existing indexed_state flag reused. New private indexed-conv declarations/marker do not change GGML enums/tensor/backend/legacy fused-state layouts.',
        generated_source='Exact locked base→CPU→CUDA→IQ1 composition includes the existing indexed GDN and new indexed conv dispatcher. Retained GDN normalized sources match current canonical GDN math/header.',
        canonical=read(W / 'source-freeze.json')['canonical'], provider_version=formula),
    hardware=read(W / 'hardware.json'), compiler_versions=read(W / 'compiler-versions.json'),
    runtime_provenance=dict(record=pin(W / 'runtime2.json'), DLL_origin_record=runtime['runtime'],
        native=runtime['native'], native_cpu=runtime['native_cpu'],
        native_cpu_final_hardlink=runtime['native_cpu_hardlink'],
        source='All DLLs/toolkits reuse the prior qualified closure or original installed CUDA/MSVC paths. No SDK/model download or rebuild.'),
    reuse=dict(baseline_inputs=227, final_inputs=228, replaced_objects=5, new_test_object=1,
        prior_public_receipt=relative_pin(base_json), prior_public_archive=relative_pin(base_zip),
        retained_GDN_object=preparation['retained_gdn_object'], retained_common40d4_object=preparation['retained_common_object'],
        source_closure='The previous public evidence supplies the unchanged SDK/source/dependency closure; it is referenced, not recopied.'),
    retained_failures=[],
    test_strengthening='The initial Commands-only test object and first built image were never executed. The same existing F32 case was strengthened before the sole GPU run; only that test was recompiled/relinked. This is not a failed experiment.',
    limits=['Only the recorded C128/D4/B2 shapes/dtypes and one RTX4070/driver617.14 were exercised; no all-GPU/all-shape claim.',
        'No full engine/model or engine state-pool integration was run in this batch.',
        'No native GPU fault injection, concurrent cancellation or new performance measurement; no speedup is inferred from these timings.'],
    SDK_shader_rebuilds=0, model_runs=0, engine_runs=0, HTTP=0, native_fault_injection=False, performance_claim=False)
(W / 'receipt.json').write_text(json.dumps(facts, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

files = ['build-preparation.py', 'build-preparation.json', 'build.py', 'publish.py', 'design.json',
    'native-plan.json', 'native-ready.json', 'native-partial.json', 'source-freeze.json',
    'root-freeze.json', 'cpp-plan.json', 'cpp-plan2.json', 'cpp-partial.json',
    'ready.json', 'ready2.json', 'link-inputs.json', 'link2-inputs.json', 'runtime.json', 'runtime2.json',
    'hardware.json', 'compiler-versions.json', 'provider-version.h', 'provider-version-identity.json',
    'linked-markers.json', 'results.xml', 'summary.json', 'receipt.json']
for directory in ('build-source', 'build-source2'):
    files += [path.relative_to(W).as_posix() for path in (W / directory).rglob('*') if path.is_file()]
for name, _ in process_tags:
    files += [path.relative_to(W).as_posix() for path in (W / name).iterdir()
        if path.is_file() and path.suffix in ('.json', '.log', '.d')]
canonical = {Path(row['path']) for row in native['canonical']}
archive = E / 'inference-indexed-conv-graph-2026-10-27.zip'
assert not archive.exists()
members = []
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as out:
    for name in sorted(set(files)):
        raw = (W / name).read_bytes()
        out.writestr(name, raw)
        members.append(dict(path=name, bytes=len(raw), sha256=sha(raw)))
    for path in sorted(canonical):
        raw = path.read_bytes()
        name = 'canonical/' + path.relative_to(R).as_posix()
        out.writestr(name, raw)
        members.append(dict(path=name, bytes=len(raw), sha256=sha(raw)))
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None
    for row in members:
        assert sha(source.read(row['path'])) == row['sha256']
facts['archive'] = dict(**relative_pin(archive), members=len(members), all_member_bytes_verified=True,
    included='Necessary native/CXX snapshots (including initial unrun test), canonical patch pins, recipes, logs, actual dependencies, XML, version formula and compact receipt.',
    excluded='EXE/OBJ/PDB/DLL/static SDK/shader/model payload, full 63MB MAP, previous 900-header closure.')
output = E / 'inference-indexed-conv-graph-2026-10-27.json'
assert not output.exists()
output.write_text(json.dumps(facts, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status='PASS', tests=7, receipt=relative_pin(output), archive=relative_pin(archive))))
