"""Explicit finite CUDA native/CXX phases; no implicit build or GPU run."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import shlex
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('prior_finite_recipe', R / '.scratch/inference-slot-source-fallback-20261027/build.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
b, m = old.b, old.m


def environment():
    compiler = b.read(W / 'build-preparation.json')['units'][2]['command_template'][0]
    helper = b.helper()
    return helper, helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env


def check_native():
    plan = b.read(W / 'native-plan.json')
    b.exact(plan['original_native_freeze'])
    for row in plan['canonical'] + plan['snapshots']:
        b.exact(row)
    return plan


def native_plan():
    assert not (W / 'native-plan.json').exists()
    source = b.read(W / 'source-freeze.json')
    for row in source['canonical']:
        b.exact(row)
    preparation = b.read(W / 'build-preparation.json')
    composition = {row['path']: row for row in preparation['source_composition_observed']}
    for name in ('src/ggml-cuda/gated_delta_net.cu', 'src/ggml-cuda/gated_delta_net.cuh'):
        assert composition[name]['composed_normalized_sha256'] == composition[name]['previous_indexed_GDN_normalized_sha256'], name
    snapshots = []
    for row in source['native_sources']:
        b.exact(row['source'])
        original = Path(row['source']['path'])
        assert hashlib.sha256(original.read_bytes().replace(b'\r\n', b'\n')).hexdigest() == composition[original.relative_to(W / 'native-overlay').as_posix()]['composed_normalized_sha256']
        target = W / 'build-source/native' / original.relative_to(W / 'native-overlay')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(original.read_bytes())
        snapshots.append(b.pin(target))
    # The retained GDN object's exact private header must shadow old overlays.
    original = R / '.scratch/inference-indexed-state-20261027/native-overlay/src/ggml-cuda/gated_delta_net.cuh'
    target = W / 'build-source/native/src/ggml-cuda/gated_delta_net.cuh'
    target.write_bytes(original.read_bytes())
    snapshots.append(b.pin(target))
    units = []
    for unit in preparation['units'][:2]:
        command = [arg.replace(str(W / 'native-overlay'), str(W / 'build-source/native')) for arg in unit['command_template']]
        actual_source = Path(command[command.index('-c') + 1])
        units.append(dict(name=unit['name'], source=b.pin(actual_source), command=command,
                          replaces=unit['replaces'], original_recipe=unit['recipe']))
    b.save(W / 'native-plan.json', dict(status='FROZEN_NOT_BUILT', original_native_freeze=b.pin(W / 'source-freeze.json'),
        canonical=source['canonical'], snapshots=snapshots, units=units,
        retained_gdn_object=preparation['retained_gdn_object'], NVCC_TUs=2, SDK_builds=0,
        actual_source_boundary='Independent small snapshots of both native TUs and their changed/required private headers; no SDK/cache mutation.'))
    print('NATIVE_PLAN', json.dumps(b.pin(W / 'native-plan.json')), flush=True)


def native_build():
    plan = check_native()
    assert not (W / 'native-ready.json').exists()
    helper, environment_base = environment()
    compiled = []
    for unit in plan['units']:
        out = W / 'compile' / unit['name']
        temporary = W / 'native-tmp' / unit['name']
        temporary.mkdir(parents=True, exist_ok=False)
        env = environment_base.copy()
        env['PATH'] = str(Path(unit['command'][0]).parent) + ';' + env['PATH']
        env['TEMP'] = str(temporary)
        env['TMP'] = str(temporary)
        result = helper.execute(unit['command'], env, out, timeout=1800)
        raw = (out / 'unit.d').read_text().split(' : ', 1)[1].replace('\\\n', ' ')
        dependencies = [b.pin(Path(name)) for name in dict.fromkeys(shlex.split(raw))]
        b.save(out / 'actual-dependencies.json', dependencies)
        item = dict(name=unit['name'], source=unit['source'], object=b.pin(out / 'unit.obj'),
            process=result, actual_dependencies=b.pin(out / 'actual-dependencies.json'))
        compiled.append(item)
        b.save(W / 'native-partial.json', compiled)
        check_native()
        print('COMPILED', unit['name'], json.dumps(result), flush=True)
    b.save(W / 'native-ready.json', dict(status='TWO_NATIVE_TUS_BUILT_NOT_RUN', compiled=compiled,
        plan=b.pin(W / 'native-plan.json'), SDK_builds=0, model_runs=0, downloads=0))
    print('NATIVE_READY', json.dumps(b.pin(W / 'native-ready.json')), flush=True)


def cpp_plan():
    assert not (W / 'cpp-plan.json').exists()
    check_native()
    expected = {str(R / row['path']): row['sha256'] for row in b.read(W / 'root-freeze.json')['sources']}
    expected.update({str(R / name): digest for name, digest in {
        'src/graph_provider_ggml_cuda/ggml_cuda_region.cc': 'ba42101c043a68bd7666466afe68e199cc92338157bc419c18f450e780a409fa',
        'tests/graph_provider_ggml_cuda/indexed_conv_test.cc': '495e92b198be974485fed80f6f3582c7557b35a43a781d7e214ac1f22792c1c6',
        'tests/graph_provider_ggml_cuda/CMakeLists.txt': '01bbce9891f45ed14a92254430e70565ed63ed6f663fa2014c8cbd6fb8361ab1'}.items()})
    source = []
    for name, digest in expected.items():
        original = Path(name)
        assert b.pin(original)['sha256'] == digest, name
        target = W / 'build-source/cxx' / original.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(original.read_bytes())
        source.append(dict(canonical=b.pin(original), snapshot=b.pin(target)))
    preparation = b.read(W / 'build-preparation.json')
    version = preparation['provider_version']['observed_derived_version']
    (W / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "' + version + '"\n')
    units = []
    for unit in preparation['units'][2:]:
        command = [arg.replace(str(W / 'native-overlay'), str(W / 'build-source/native')) for arg in unit['command_template']]
        units.append(dict(name=unit['name'], source=b.pin(R / unit['source']), command=command,
            replaces=unit['replaces'], original_recipe=unit['recipe']))
    old_test = R / 'tests/graph_provider_ggml_cuda/indexed_state_test.cc'
    new_test = R / 'tests/graph_provider_ggml_cuda/indexed_conv_test.cc'
    suites = []
    for path, suite, count in ((old_test, 'GgmlCudaIndexedStateGraph', 3), (new_test, 'GgmlCudaIndexedConvGraph', 4)):
        actual = re.findall(r'^TEST\(' + suite + r',\s*(\w+)\)', path.read_text(), re.M)
        assert len(actual) == count, (str(path), actual)
        suites += [suite + '.' + name for name in actual]
    b.save(W / 'cpp-plan.json', dict(status='FROZEN_NOT_BUILT', source=source, units=units,
        root_freeze=b.pin(W / 'root-freeze.json'), provider_version=b.pin(W / 'provider-version.h'),
        version=version, old_test_source=b.pin(old_test), exact_tests=suites,
        filter='GgmlCudaIndexedConvGraph.*:GgmlCudaIndexedStateGraph.*', tests=7,
        baseline=preparation['baseline'], link_command=preparation['link_command_template'],
        retained_gdn_object=preparation['retained_gdn_object'], retained_common_object=preparation['retained_common_object'],
        CXX_TUs=4, NVCC_TUs=2, images=1, SDK_builds=0, model_runs=0, downloads=0))
    print('CPP_PLAN', json.dumps(b.pin(W / 'cpp-plan.json')), flush=True)


def check_cpp(second=False):
    check_native()
    plan = b.read(W / ('cpp-plan2.json' if second else 'cpp-plan.json'))
    b.exact(plan['root_freeze'])
    b.exact(plan['provider_version'])
    b.exact(plan['old_test_source'])
    for item in plan['source']:
        b.exact(item['canonical'])
        b.exact(item['snapshot'])
    return plan


def cpp_build():
    plan = check_cpp()
    native = b.read(W / 'native-ready.json')
    for unit in native['compiled']:
        b.exact(unit['object'])
    assert not (W / 'ready.json').exists()
    for row in b.read(plan['baseline']['link_inputs']['path']):
        b.exact(row)
    helper, env = environment()
    compiled = []
    for unit in plan['units']:
        out = W / 'compile' / unit['name']
        result = helper.execute(unit['command'], env, out, timeout=180)
        deps = b.read(out / 'dependencies.json')['Data']
        actual = [b.pin(name) for name in dict.fromkeys([deps['Source'], *deps['Includes']])]
        b.save(out / 'actual-dependencies.json', actual)
        compiled.append(dict(name=unit['name'], source=unit['source'], object=b.pin(out / 'unit.obj'),
            process=result, actual_dependencies=b.pin(out / 'actual-dependencies.json')))
        b.save(W / 'cpp-partial.json', compiled)
        check_cpp()
        print('COMPILED', unit['name'], json.dumps(result), flush=True)
    linked = helper.execute(plan['link_command'], env, W / 'link', timeout=120)
    preparation = b.read(W / 'build-preparation.json')
    replace = {b.key(unit['replaces']['path']): b.pin(W / 'compile' / unit['name'] / 'unit.obj')
        for unit in preparation['units'] if unit['replaces']}
    inputs = [replace.get(b.key(row['path']), row) for row in b.read(plan['baseline']['link_inputs']['path'])]
    inputs.append(b.pin(W / 'compile/test/unit.obj'))
    assert len(inputs) == 228
    b.save(W / 'link-inputs.json', inputs)
    image = W / 'link/indexed-conv-test.exe'
    runtime = b.read(plan['baseline']['runtime']['path'])
    original = runtime['native_cpu']
    b.exact(original)
    alias = image.parent / Path(original['path']).name
    os.link(original['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), native=native['compiled'],
        compiled=compiled, link=linked, inputs=b.pin(W / 'link-inputs.json'), runtime=b.pin(W / 'runtime.json'),
        cpp_plan=b.pin(W / 'cpp-plan.json'), distinct_TUs=6, SDK_builds=0, model_runs=0))
    print('READY', json.dumps(b.pin(W / 'ready.json')), flush=True)


def revised_test_plan():
    check_native()
    assert not (W / 'cpp-plan2.json').exists()
    plan = b.read(W / 'cpp-plan.json')
    name = R / 'tests/graph_provider_ggml_cuda/indexed_conv_test.cc'
    current = b.pin(name)
    assert current['sha256'] == '0dc275d842b87900f61e7c29c00aee5cf87ae161101d1a2d36fff08227ea14e0'
    for row in plan['source']:
        if row['canonical']['path'] == str(name):
            target = W / 'build-source2/cxx/tests/graph_provider_ggml_cuda/indexed_conv_test.cc'
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(name.read_bytes())
            row.update(canonical=current, snapshot=b.pin(target))
        else:
            b.exact(row['canonical'])
            b.exact(row['snapshot'])
    unit = plan['units'][-1]
    assert unit['name'] == 'test'
    unit['source'] = current
    unit['command'] = [arg.replace(str(W / 'compile/test'), str(W / 'compile2/test')) for arg in unit['command']]
    plan['link_command'] = [arg.replace(str(W / 'compile/test/unit.obj'), str(W / 'compile2/test/unit.obj'))
        .replace(str(W / 'link'), str(W / 'link2')) for arg in plan['link_command']]
    plan['revision_reason'] = 'Before any GPU run, root strengthened the existing F32 case with two real RequireCapture submissions and exact record/reuse counters across changed destination IDs. The first test/image stays unrun; only the test is recompiled and the image relinked.'
    plan['previous_plan'] = b.pin(W / 'cpp-plan.json')
    b.save(W / 'cpp-plan2.json', plan)
    print('CPP_PLAN2', json.dumps(b.pin(W / 'cpp-plan2.json')), flush=True)


def revised_test_build():
    plan = check_cpp(True)
    first = b.read(W / 'ready.json')
    assert not (W / 'ready2.json').exists()
    for row in first['native'] + first['compiled'][:-1]:
        b.exact(row['object'])
    helper, env = environment()
    unit = plan['units'][-1]
    out = W / 'compile2/test'
    result = helper.execute(unit['command'], env, out, timeout=180)
    deps = b.read(out / 'dependencies.json')['Data']
    actual = [b.pin(name) for name in dict.fromkeys([deps['Source'], *deps['Includes']])]
    b.save(out / 'actual-dependencies.json', actual)
    test = dict(name='test', source=unit['source'], object=b.pin(out / 'unit.obj'), process=result,
        actual_dependencies=b.pin(out / 'actual-dependencies.json'))
    check_cpp(True)
    linked = helper.execute(plan['link_command'], env, W / 'link2', timeout=120)
    inputs = b.read(first['inputs']['path'])
    matches = [index for index, row in enumerate(inputs) if row['path'] == first['compiled'][-1]['object']['path']]
    assert len(matches) == 1
    inputs[matches[0]] = test['object']
    b.save(W / 'link2-inputs.json', inputs)
    image = W / 'link2/indexed-conv-test.exe'
    runtime = b.read(first['runtime']['path'])
    original = runtime['native_cpu']
    alias = image.parent / Path(original['path']).name
    os.link(original['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'runtime2.json', runtime)
    b.save(W / 'ready2.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), native=first['native'],
        compiled=first['compiled'][:-1] + [test], link=linked, inputs=b.pin(W / 'link2-inputs.json'),
        runtime=b.pin(W / 'runtime2.json'), cpp_plan=b.pin(W / 'cpp-plan2.json'),
        distinct_TUs=6, compiler_processes=7, links=2, built_images=2, executed_images=0,
        previous_unrun_image=first['image'], SDK_builds=0, model_runs=0))
    print('READY2', json.dumps(b.pin(W / 'ready2.json')), flush=True)


def run(second=False):
    plan = check_cpp(second)
    ready_path = W / ('ready2.json' if second else 'ready.json')
    ready = b.read(ready_path)
    b.exact(ready['image'])
    helper, env = environment()
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    result = helper.execute([ready['image']['path'], '--gtest_color=no', '--gtest_filter=' + plan['filter'],
        '--gtest_output=xml:' + str(W / 'results.xml')], env, W / 'run1', timeout=120)
    root = ET.parse(W / 'results.xml').getroot()
    cases = list(root.iter('testcase'))
    assert int(root.attrib['tests']) == 7 and int(root.attrib['failures']) == 0 and len(cases) == 7
    assert sorted(case.attrib['classname'] + '.' + case.attrib['name'] for case in cases) == sorted(plan['exact_tests'])
    assert all(case.attrib['result'] == 'completed' and case.find('skipped') is None for case in cases)
    b.save(W / 'summary.json', dict(status='SEVEN_GRAPH_INDEXED_STATE_CASES_PASS', tests=7, failures=0,
        process=result, cases=[case.attrib for case in cases], results=b.pin(W / 'results.xml'), ready=b.pin(ready_path),
        scope='Four indexed-conv Graph cases and three existing indexed-GDN Graph cases in one image/process. No other suite, model or performance run.',
        distinct_TUs=6, images=1, SDK_builds=0, model_runs=0, downloads=0, performance_claim=False))
    print('SUMMARY', json.dumps(b.pin(W / 'summary.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['native-plan']:
        native_plan()
    elif sys.argv[1:] == ['native-build']:
        native_build()
    elif sys.argv[1:] == ['cpp-plan']:
        cpp_plan()
    elif sys.argv[1:] == ['cpp-build']:
        cpp_build()
    elif sys.argv[1:] == ['revised-test-plan']:
        revised_test_plan()
    elif sys.argv[1:] == ['revised-test-build']:
        revised_test_build()
    elif sys.argv[1:] == ['run']:
        run()
    elif sys.argv[1:] == ['run-final']:
        run(True)
    else:
        print(__doc__)
