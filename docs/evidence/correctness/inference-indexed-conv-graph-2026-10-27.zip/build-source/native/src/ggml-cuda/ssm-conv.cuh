#include "common.cuh"

void ggml_cuda_op_ssm_conv(ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_tensor * bias_add_node = nullptr, ggml_tensor * silu_dst = nullptr);

// Metadata-only qualification of original F32 and private BF16 samples.
bool ggml_cuda_supports_ssm_conv(const ggml_tensor * dst);

// Private convolution-history v1 carrier; old SSM parameters/ports and all
// ggml enum/tensor/backend layouts are unchanged outside this explicit mode.
inline constexpr int ggml_cuda_conv_indexed_parameter = 4;
inline constexpr int32_t ggml_cuda_conv_indexed_contract = 0x43444931;
inline bool ggml_cuda_conv_is_indexed(const ggml_tensor * node) {
    return node && node->op == GGML_OP_SSM_CONV &&
        ggml_get_op_params_i32(node, ggml_cuda_conv_indexed_parameter) == ggml_cuda_conv_indexed_contract;
}
// src0: actual TX chunk [T,C,B], with real channel/time/batch byte strides.
// src1: original F32 weights [D,C]. src2: actual TX pool [C,D-1,P],
// contiguous within one history item and with its actual outer slot stride.
// src3: I32[B] source slots. src4: I32[K,B], dst[b*K+c] in memory.
// dst: original F32 activation [C,T,B], with no packed history tail.
// op_params0=K in [1,T], selecting only p=T-K+1,...,T chronological prefixes.
// TX is the same F32/F16/BF16 storage in chunk and pool. F16 is private to
// indexed mode; the legacy F32/BF16 SSM domain is not expanded.
// Metadata does not inspect device IDs or grant storage permission. The sole
// caller is an admitted Hyle lowering retaining exact original lease-to-I32
// encodings: IDs in [0,P), unique whole destinations disjoint from every
// source, actual read/write guards and original Graph Store effects. Arbitrary
// device index tensors do not authorize a Gather exemption or pool mutation.
extern "C" int32_t ggml_hyle_cuda_conv_indexed_state_contract();
bool ggml_cuda_supports_ssm_conv_indexed(const ggml_tensor * dst);
void ggml_cuda_op_ssm_conv_indexed(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

