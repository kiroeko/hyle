#include "common.cuh"
#include "ggml.h"

// fused-kernel recurrent-state output; strides in elements (per-seq stride is always D, set in-kernel)
struct ggml_cuda_gated_delta_net_fused_cache {
    float * data;        // rollback slot 0
    int64_t slot_stride; // between rollback slots (0 when K==1)
};

void ggml_cuda_op_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

// same op, but writes the snapshot(s) into the cache instead of dst (see ggml_cuda_try_gdn_cache_fusion)
void ggml_cuda_op_gated_delta_net_fused_cache(ggml_backend_cuda_context & ctx, ggml_tensor * dst,
                                              ggml_cuda_gated_delta_net_fused_cache cache);

// Metadata-only qualification for private typed V/beta loads; no address is required.
bool ggml_cuda_supports_gated_delta_net_typed(const ggml_tensor * dst);

// Private indexed-state v1 carrier. This does not change ggml op/tensor/backend
// layout or the legacy fused-cache struct. op_params 0/1/2/3 retain K, direct-
// state planning and the output-scale contract; only slot 4 selects this mode.
inline constexpr int ggml_cuda_gdn_indexed_parameter = 4;
inline constexpr int32_t ggml_cuda_gdn_indexed_contract = 0x47444931;
inline bool ggml_cuda_gdn_is_indexed(const ggml_tensor * node) {
    return node && node->op == GGML_OP_GATED_DELTA_NET &&
        ggml_get_op_params_i32(node, ggml_cuda_gdn_indexed_parameter) == ggml_cuda_gdn_indexed_contract;
}

// src[0..4]: original Q/K/V/log-decay/beta and their original types/strides.
// src[5]: one actual F32 pool [S,S,H,P], with its real outer slot stride.
// src[6]: contiguous I32[B] source slots.
// src[7]: contiguous I32[K,B] in ggml order, dst_slots[b*K+c] in memory.
// dst: contiguous F32 activation [S,H,T,B], no packed state tail.
// K=1 writes the final state; K>1 writes the last K post-token boundaries in
// chronological order: c=t-(T-K). K remains in [1,T], as in the public schema.
// Metadata qualification DOES NOT inspect device index values or grant pool
// permissions. The sole caller is an admitted Hyle indexed-state lowering:
// it must encode stable actual lease addresses, prove 0<=IDs<P, unique whole
// destination slots disjoint from every source slot, retain the exact pools/
// tables, and declare the selected pool writes as the original Graph effect.
// Arbitrary mutable I32 tensors are not a checked-index capability. No ordinary
// Compute Gather guard may be skipped on account of this private contract.
// The C++ lowering must check this real linked native symbol before using the mode.
extern "C" int32_t ggml_hyle_cuda_gdn_indexed_state_contract();
bool ggml_cuda_supports_gated_delta_net_indexed(const ggml_tensor * dst);
void ggml_cuda_op_gated_delta_net_indexed(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

