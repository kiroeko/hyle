#include "common.cuh"
#include "ssm-conv.cuh"
#include "unary.cuh"
#include "convert.cuh"

#include <cstring>


extern "C" int32_t ggml_hyle_cuda_conv_indexed_state_contract() {
    return ggml_cuda_conv_indexed_contract;
}

bool ggml_cuda_supports_ssm_conv_indexed(const ggml_tensor * dst) {
    if (!ggml_cuda_conv_is_indexed(dst) || dst->type != GGML_TYPE_F32) return false;
    const auto * x = dst->src[0], * w = dst->src[1], * pool = dst->src[2];
    const auto * sources = dst->src[3], * destinations = dst->src[4];
    if (!x || !w || !pool || !sources || !destinations ||
        (x->type != GGML_TYPE_F32 && x->type != GGML_TYPE_F16 && x->type != GGML_TYPE_BF16) ||
        pool->type != x->type || w->type != GGML_TYPE_F32 ||
        sources->type != GGML_TYPE_I32 || destinations->type != GGML_TYPE_I32) return false;
    for (int port = 5; port < GGML_MAX_SRC; ++port) if (dst->src[port]) return false;
    const int64_t T = x->ne[0], C = x->ne[1], B = x->ne[2], D = w->ne[0], P = pool->ne[2];
    const int K = ggml_get_op_params_i32(dst, 0);
    if (T <= 0 || C <= 0 || C % 128 || B <= 0 || x->ne[3] != 1 ||
        (D != 3 && D != 4 && D != 5 && D != 9 && D != 15) ||
        P <= 0 || P > INT32_MAX || K < 1 || K > T ||
        w->ne[1] != C || w->ne[2] != 1 || w->ne[3] != 1 ||
        pool->ne[0] != C || pool->ne[1] != D-1 || pool->ne[3] != 1 ||
        sources->ne[0] != B || sources->ne[1] != 1 || sources->ne[2] != 1 || sources->ne[3] != 1 ||
        destinations->ne[0] != K || destinations->ne[1] != B || destinations->ne[2] != 1 || destinations->ne[3] != 1 ||
        dst->ne[0] != C || dst->ne[1] != T || dst->ne[2] != B || dst->ne[3] != 1) return false;
    // Prove signed offsets and every complete actual view before byte helpers.
    const ggml_tensor * tensors[] = {x, w, pool, sources, destinations, dst};
    for (const auto * tensor : tensors) {
        const size_t element = ggml_type_size(tensor->type);
        uint64_t bytes = element;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0 || tensor->nb[axis] > uint64_t(INT64_MAX) || tensor->nb[axis] % element) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
    }
    const uint64_t unit = ggml_type_size(x->type);
    if (uint64_t(C) > uint64_t(INT64_MAX) / unit / uint64_t(D-1) ||
        uint64_t(C) > uint64_t(INT64_MAX) / sizeof(float) / uint64_t(T) / uint64_t(B) ||
        uint64_t(K) > uint64_t(INT64_MAX) / sizeof(int32_t) / uint64_t(B) ||
        T > INT64_MAX - (D-1)) return false;
    const uint64_t row_bytes = uint64_t(C) * unit;
    if (x->nb[1] != unit || x->nb[0] < row_bytes ||
        uint64_t(T-1) > (uint64_t(INT64_MAX)-row_bytes) / x->nb[0]) return false;
    const uint64_t chunk_bytes = uint64_t(T-1) * x->nb[0] + row_bytes;
    return (B == 1 || x->nb[2] >= chunk_bytes) &&
        pool->nb[0] == unit && pool->nb[1] == row_bytes && pool->nb[2] >= uint64_t(D-1) * row_bytes &&
        w->nb[0] == sizeof(float) && w->nb[1] >= uint64_t(D) * sizeof(float) &&
        ggml_is_contiguous(sources) && ggml_is_contiguous(destinations) && ggml_is_contiguous(dst);
}

// Same-TX raw history is independent of the original F32 arithmetic window.
// No structure here crosses a native TU or changes the legacy fused ABI.
struct ssm_conv_indexed_args {
    void * pool = nullptr;
    const int32_t * sources = nullptr;
    const int32_t * destinations = nullptr;
    int64_t slot_bytes = 0;
    int64_t slots = 0;
    int64_t snapshots = 0;
    int64_t channels = 0;
};
template <typename TX, size_t D>
static __device__ __forceinline__ const TX * ssm_conv_indexed_sample(
        const TX * chunk, int64_t stride_x, int64_t stride_t, int tid,
        int64_t channel, int64_t time, int32_t source_slot, ssm_conv_indexed_args state) {
    if (time < int64_t(D-1)) {
        const auto * history = reinterpret_cast<const TX *>(static_cast<const char *>(state.pool) + int64_t(source_slot) * state.slot_bytes);
        return history + time * state.channels + channel;
    }
    return chunk + int64_t(tid) * stride_x + (time-int64_t(D-1)) * stride_t;
}
template <typename TX, size_t D>
static __device__ __forceinline__ void ssm_conv_indexed_prefix(
        const TX * chunk, int64_t stride_x, int64_t stride_t, int tid,
        int64_t channel, int64_t token, int64_t n_t, int batch,
        int32_t source_slot, ssm_conv_indexed_args state) {
    if (token < n_t-state.snapshots) return;
    const int64_t c = token-(n_t-state.snapshots);
    const int32_t destination = state.destinations[int64_t(batch)*state.snapshots+c];
    // Defensive address guards do not validate arbitrary device-ID programs.
    if (destination < 0 || int64_t(destination) >= state.slots) return;
    auto * history = reinterpret_cast<TX *>(static_cast<char *>(state.pool) + int64_t(destination) * state.slot_bytes);
#pragma unroll
    for (size_t r = 0; r < D-1; ++r) {
        const TX * sample = ssm_conv_indexed_sample<TX,D>(chunk, stride_x, stride_t, tid, channel,
            token+1+int64_t(r), source_slot, state);
        // Copy the original payload bits, including F16/BF16 NaNs/signed zero.
        // Casting the float ring/shared cell back to TX would change that contract.
        memcpy(history+int64_t(r)*state.channels+channel, sample, sizeof(TX));
    }
}

// Metadata-only qualification of the actual SSM carrier; sizing has no addresses.
bool ggml_cuda_supports_ssm_conv(const ggml_tensor * dst) {
    if (ggml_cuda_conv_is_indexed(dst)) return ggml_cuda_supports_ssm_conv_indexed(dst);
    if (!dst || dst->op != GGML_OP_SSM_CONV || dst->type != GGML_TYPE_F32) return false;
    const ggml_tensor * const x = dst->src[0], * const w = dst->src[1];
    if (!x || !w || (x->type != GGML_TYPE_BF16 && x->type != GGML_TYPE_F32) || w->type != GGML_TYPE_F32) return false;
    const int64_t W = x->ne[0], C = x->ne[1], B = x->ne[2], K = w->ne[0];
    if (W <= 0 || C <= 0 || C % 128 || B <= 0 || x->ne[3] != 1 ||
        (K != 3 && K != 4 && K != 5 && K != 9 && K != 15) || W < K ||
        w->ne[1] != C || w->ne[2] != 1 || w->ne[3] != 1 ||
        dst->ne[0] != C || dst->ne[1] != W - K + 1 || dst->ne[2] != B || dst->ne[3] != 1) return false;
    // Prove the kernel's signed offsets and all span calculations first.
    const ggml_tensor * const tensors[] = {x, w, dst};
    for (const auto * tensor : tensors) {
        const size_t element = ggml_type_size(tensor->type);
        uint64_t bytes = element;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0 || tensor->nb[axis] > uint64_t(INT64_MAX) ||
                tensor->nb[axis] % element) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
    }
    if (C > INT64_MAX / int64_t(sizeof(float)) / K ||
        C > INT64_MAX / int64_t(sizeof(float)) / dst->ne[1] / B) return false;
    if (w->nb[0] != sizeof(float) || w->nb[1] < uint64_t(K) * sizeof(float) ||
        dst->nb[0] != sizeof(float) || (dst->ne[1] > 1 && dst->nb[1] < uint64_t(C) * sizeof(float))) return false;
    const uint64_t output_batch_bytes = uint64_t(dst->ne[1] - 1) * dst->nb[1] + uint64_t(C) * sizeof(float);
    if (B > 1 && dst->nb[2] < output_batch_bytes) return false;
    if (x->type == GGML_TYPE_F32) {
        // Preserve the old F32 carrier's exact time-contiguous layout domain.
        return x->nb[0] == sizeof(float) && x->nb[1] == uint64_t(W) * sizeof(float) &&
            (B == 1 || x->nb[2] >= uint64_t(W) * uint64_t(C) * sizeof(float));
    }
    const uint64_t channel_bytes = uint64_t(C) * sizeof(nv_bfloat16);
    // Native BF16 [W,C,B] is the permutation of channel-contiguous rows.
    // Padding is legal, broadcast/overlapping time or batch rows are not.
    if (x->nb[1] != sizeof(nv_bfloat16) || x->nb[0] < channel_bytes ||
        uint64_t(W - 1) > (uint64_t(INT64_MAX) - channel_bytes) / x->nb[0]) return false;
    const uint64_t batch_bytes = uint64_t(W - 1) * x->nb[0] + channel_bytes;
    return (B == 1 || x->nb[2] >= batch_bytes) && ggml_is_contiguous(dst);
}


template <bool apply_silu, size_t split_d_inner, size_t d_conv, typename TX, bool Indexed = false>
static __global__ void ssm_conv_f32(const TX * src0_ptr, const float * src1_ptr,
                                    const float * bias_ptr,
                                    const int64_t src0_nb0, const int64_t src0_nb1, const int64_t src0_nb2, const int64_t src1_nb1,
                                    float * dst_ptr, const int64_t dst_nb0, const int64_t dst_nb1, const int64_t dst_nb2,
                                    const int64_t n_t, ssm_conv_indexed_args state = {}) {
    ggml_cuda_pdl_lc();
    const TX * GGML_CUDA_RESTRICT src0 = src0_ptr;
    const float * GGML_CUDA_RESTRICT src1 = src1_ptr;
    const float * GGML_CUDA_RESTRICT bias = bias_ptr;
    float       * GGML_CUDA_RESTRICT dst  = dst_ptr;
    const int tid  = threadIdx.x;
    const int bidx = blockIdx.x;
    const int bidy = blockIdx.y;

    const TX * x_block = (const TX *) ((const char *) src0 + bidx * src0_nb2 + bidy * split_d_inner * src0_nb1);
    const float * w_block = (const float *) ((const char *) src1 + bidy * split_d_inner * src1_nb1);
    float *       y_block = (float *) ((char *) dst + bidx * dst_nb2 + bidy * split_d_inner * dst_nb0);

    const int64_t stride_x = src0_nb1 / sizeof(TX);
    const int64_t stride_t = src0_nb0 / sizeof(TX);
    const int64_t stride_w = src1_nb1 / sizeof(float);
    const int64_t stride_y = dst_nb1 / sizeof(float);

    float x[d_conv] = { 0.0f };
    float w[d_conv] = { 0.0f };

    ggml_cuda_pdl_sync();
    // Private index tables are real inputs: never read them before PDL sync.
    int32_t source_slot = 0;
    if constexpr (Indexed) {
        source_slot = state.sources[bidx];
        if (source_slot < 0 || int64_t(source_slot) >= state.slots) return;
    }
#pragma unroll
    for (size_t j = 0; j < d_conv; j++) {
        w[j] = w_block[tid * stride_w + j];
    }

    float b = bias != nullptr ? bias[bidy * split_d_inner + tid] : 0.0f;

    for (int64_t i = 0; i < n_t; i++) {
        float sumf = 0.0f;

        if (i == 0) {
            for (size_t j = 0; j < d_conv; j++) {
                if constexpr (Indexed) {
                    x[j] = ggml_cuda_cast<float>(*ssm_conv_indexed_sample<TX,d_conv>(x_block, stride_x, stride_t, tid,
                        int64_t(bidy)*split_d_inner+tid, int64_t(j), source_slot, state));
                } else {
                    x[j] = ggml_cuda_cast<float>(x_block[tid * stride_x + j * stride_t]);
                }
            }
        } else {
            if constexpr (Indexed) {
                x[(i - 1) % d_conv] = ggml_cuda_cast<float>(*ssm_conv_indexed_sample<TX,d_conv>(x_block, stride_x, stride_t, tid,
                    int64_t(bidy)*split_d_inner+tid, i+d_conv-1, source_slot, state));
            } else {
                x[(i - 1) % d_conv] = ggml_cuda_cast<float>(x_block[tid * stride_x + (i + d_conv - 1) * stride_t]);
            }
        }

#pragma unroll
        for (size_t j = 0; j < d_conv; j++) {
            sumf += x[(i + j) % d_conv] * w[j];
        }
        sumf += b;
        y_block[i * stride_y + tid] = apply_silu ? ggml_cuda_op_silu_single(sumf) : sumf;
        if constexpr (Indexed) ssm_conv_indexed_prefix<TX,d_conv>(x_block, stride_x, stride_t, tid,
            int64_t(bidy)*split_d_inner+tid, i, n_t, bidx, source_slot, state);
    }
}

template <bool apply_silu, size_t split_d_inner, size_t d_conv, int64_t split_n_t, typename TX, bool Indexed = false>
static __global__ void ssm_conv_long_token_f32(const TX * __restrict__ src0, const float * __restrict__ src1,
                                               const float * __restrict__ bias,
                                               const int64_t src0_nb0, const int64_t src0_nb1, const int64_t src0_nb2,
                                               const int64_t src1_nb1, float * __restrict__ dst, const int64_t dst_nb0,
                                               const int64_t dst_nb1, const int64_t dst_nb2, const int64_t n_t, ssm_conv_indexed_args state = {}) {
    const int tid  = threadIdx.x;
    const int bidx = blockIdx.x;
    const int bidy = blockIdx.y;
    const int bidz = blockIdx.z;
    int32_t source_slot = 0;
    if constexpr (Indexed) {
        source_slot = state.sources[bidx];
        if (source_slot < 0 || int64_t(source_slot) >= state.slots) return;
    }

    const TX * x_block = (const TX *) ((const char *) src0 + bidx * src0_nb2 + bidy * split_d_inner * src0_nb1 +
                                             (Indexed ? 0 : bidz * split_n_t * src0_nb0));
    const float * w_block = (const float *) ((const char *) src1 + bidy * split_d_inner * src1_nb1);
    float *       y_block =
        (float *) ((char *) dst + bidx * dst_nb2 + bidz * split_n_t * dst_nb1 + bidy * split_d_inner * dst_nb0);

    const int64_t stride_x = src0_nb1 / sizeof(TX);
    const int64_t stride_t = src0_nb0 / sizeof(TX);
    const int64_t stride_w = src1_nb1 / sizeof(float);
    const int64_t stride_y = dst_nb1 / sizeof(float);

    const int64_t local_n_t = min(split_n_t, n_t - bidz * split_n_t);
    const int     n_cols    = d_conv - 1 + split_n_t;

    extern __shared__ float smem[];

    constexpr int load_cols   = d_conv - 1 + split_n_t;
    constexpr int total_elems = split_d_inner * load_cols;
    if constexpr (Indexed || std::is_same_v<TX, nv_bfloat16>) {
        // BF16 samples are channel-contiguous. Adjacent lanes load adjacent
        // channels, then fill the same F32 shared cells as the legacy loader.
#pragma unroll
        for (int col = 0; col < load_cols; ++col) {
            if constexpr (Indexed) {
                smem[tid * n_cols + col] = col < local_n_t + d_conv - 1
                    ? ggml_cuda_cast<float>(*ssm_conv_indexed_sample<TX,d_conv>(x_block, stride_x, stride_t, tid,
                        int64_t(bidy)*split_d_inner+tid, int64_t(bidz)*split_n_t+col, source_slot, state)) : 0.0f;
            } else {
                smem[tid * n_cols + col] = col < local_n_t + d_conv - 1
                    ? ggml_cuda_cast<float>(x_block[tid * stride_x + int64_t(col) * stride_t]) : 0.0f;
            }
        }
    } else {
        int row = tid / load_cols;
        int col = tid % load_cols;
    #pragma unroll
        for (int idx = 0; idx < total_elems; idx += split_d_inner) {
            if (row < (int)split_d_inner) {
                // The last tile only owns local_n_t + K - 1 source samples.
                // Zero-fill unused columns; every valid MAC input is unchanged.
                smem[row * n_cols + col] = col < local_n_t + d_conv - 1
                    ? ggml_cuda_cast<float>(x_block[row * stride_x + int64_t(col) * stride_t]) : 0.0f;
            }

            col += split_d_inner;
            row += col / load_cols;
            col  = col % load_cols;
            if (idx >= total_elems - tid - split_d_inner) {
                break;
            }
        }
    }
    __syncthreads();

    // Load weights into registers (done once, small)
    float w[d_conv] = { 0.0f };
#pragma unroll
    for (size_t j = 0; j < d_conv; j++) {
        w[j] = w_block[tid * stride_w + j];
    }

    float b = bias != nullptr ? bias[bidy * split_d_inner + tid] : 0.0f;

    // Compute from shared memory
    for (int64_t i = 0; i < local_n_t; i++) {
        float sumf = 0.0f;
#pragma unroll
        for (size_t j = 0; j < d_conv; j++) {
            sumf += smem[tid * n_cols + i + j] * w[j];
        }
        sumf += b;
        y_block[i * stride_y + tid] = apply_silu ? ggml_cuda_op_silu_single(sumf) : sumf;
        if constexpr (Indexed) ssm_conv_indexed_prefix<TX,d_conv>(x_block, stride_x, stride_t, tid,
            int64_t(bidy)*split_d_inner+tid, int64_t(bidz)*split_n_t+i, n_t, bidx, source_slot, state);
    }
}

template <bool apply_silu, typename TX, bool Indexed = false>
static void ssm_conv_f32_cuda(const TX * src0, const float * src1, const float * bias, const int64_t src0_nb0, const int64_t src0_nb1,
                              const int64_t src0_nb2, const int64_t src1_nb1, float * dst, const int64_t dst_nb0, const int64_t dst_nb1,
                              const int64_t dst_nb2, const int64_t nc, const int64_t nr, const int64_t n_t,
                              const int64_t n_s, cudaStream_t stream, ssm_conv_indexed_args state = {}) {
    const int threads = 128;
    GGML_ASSERT(nr % threads == 0);

    auto launch_kernel = [&](auto NC) {
        constexpr int kNC = decltype(NC)::value;
        if (n_t <= 32) {
            const dim3 blocks(n_s, (nr + threads - 1) / threads, 1);
            const ggml_cuda_kernel_launch_params launch_params = ggml_cuda_kernel_launch_params(blocks, threads, 0, stream);
            ggml_cuda_kernel_launch(ssm_conv_f32<apply_silu, threads, kNC, TX, Indexed>, launch_params, src0, src1, bias, src0_nb0, src0_nb1,
                                                                        src0_nb2, src1_nb1, dst, dst_nb0, dst_nb1, dst_nb2, n_t, state);
        } else {
            const int64_t split_n_t = 32;
            dim3          blocks(n_s, (nr + threads - 1) / threads, (n_t + split_n_t - 1) / split_n_t);
            const size_t  smem_size = threads * (kNC - 1 + split_n_t) * sizeof(float);
            ssm_conv_long_token_f32<apply_silu, threads, kNC, split_n_t, TX, Indexed><<<blocks, threads, smem_size, stream>>>(
                src0, src1, bias, src0_nb0, src0_nb1, src0_nb2, src1_nb1, dst, dst_nb0, dst_nb1, dst_nb2, n_t, state);
        }
    };

    switch (nc) {
        case 3:  launch_kernel(std::integral_constant<int, 3 >{}); break;
        case 4:  launch_kernel(std::integral_constant<int, 4 >{}); break;
        case 5:  launch_kernel(std::integral_constant<int, 5 >{}); break;
        case 9:  launch_kernel(std::integral_constant<int, 9 >{}); break;
        case 15: launch_kernel(std::integral_constant<int, 15>{}); break;
        default: GGML_ABORT("Only support kernel sizes 3, 4, 5, 9, 15 right now.");
    }
}

template <typename TX>
static void ggml_cuda_op_ssm_conv_impl(ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_tensor * bias_add_node, ggml_tensor * silu_dst) {
    const struct ggml_tensor * src0 = dst->src[0];  // conv_x
    const struct ggml_tensor * src1 = dst->src[1];  // conv1d.weight
    const bool fuse_bias = bias_add_node != nullptr;
    const bool fuse_silu = silu_dst != nullptr;

    // bias always comes with silu.
    GGML_ASSERT(!fuse_bias || fuse_silu);

    // The bias (when fused) is the non-conv operand of the ADD node.
    const struct ggml_tensor * bias = fuse_bias ? (bias_add_node->src[0] == dst ? bias_add_node->src[1] : bias_add_node->src[0]) : nullptr;

    // When fusing, write to silu_dst (the node downstream references).
    const struct ggml_tensor * out = fuse_silu ? silu_dst : dst;

    const int64_t nc  = src1->ne[0];                // d_conv
    const int64_t nr  = src0->ne[1];                // d_inner
    const int64_t n_t = out->ne[1];                 // tokens per sequence
    const int64_t n_s = out->ne[2];                 // number of sequences in the batch

    GGML_ASSERT(out->ne[0] == nr);
    if constexpr (std::is_same_v<TX, float>) {
        GGML_ASSERT(src0->nb[0] == sizeof(float));
        GGML_ASSERT(src0->nb[1] == src0->ne[0] * sizeof(float));
    }
    GGML_ASSERT(src1->nb[0] == sizeof(float));

    const TX * src0_d = (const TX *) src0->data;
    const float * src1_d = (const float *) src1->data;
    const float * bias_d = fuse_bias ? (const float *) bias->data : nullptr;
    float *       dst_d  = (float *) out->data;
    cudaStream_t  stream = ctx.stream();

    GGML_ASSERT(src0->type == (std::is_same_v<TX, float> ? GGML_TYPE_F32 : GGML_TYPE_BF16));
    GGML_ASSERT(out->type == GGML_TYPE_F32);
    if (fuse_bias) {
        GGML_ASSERT(bias->type == GGML_TYPE_F32);
        GGML_ASSERT(ggml_is_contiguous(bias));
        GGML_ASSERT(ggml_nelements(bias) == nr);
    }

    if (fuse_silu) {
        ssm_conv_f32_cuda<true>(src0_d, src1_d, bias_d, src0->nb[0], src0->nb[1], src0->nb[2], src1->nb[1], dst_d, out->nb[0], out->nb[1],
                          out->nb[2], nc, nr, n_t, n_s, stream);
    } else {
        ssm_conv_f32_cuda<false>(src0_d, src1_d, bias_d, src0->nb[0], src0->nb[1], src0->nb[2], src1->nb[1], dst_d, out->nb[0], out->nb[1],
                          out->nb[2], nc, nr, n_t, n_s, stream);
    }
}


void ggml_cuda_op_ssm_conv(ggml_backend_cuda_context & ctx, ggml_tensor * dst,
        ggml_tensor * bias_add_node, ggml_tensor * silu_dst) {
    if (dst->src[0]->type == GGML_TYPE_BF16) {
        if (!ggml_cuda_supports_ssm_conv(dst)) {
            hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid typed SSM convolution metadata");
        }
        ggml_cuda_op_ssm_conv_impl<nv_bfloat16>(ctx, dst, bias_add_node, silu_dst);
    } else {
        ggml_cuda_op_ssm_conv_impl<float>(ctx, dst, bias_add_node, silu_dst);
    }
}


template <typename TX>
static void ggml_cuda_op_ssm_conv_indexed_impl(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const auto * x = dst->src[0], * w = dst->src[1], * pool = dst->src[2];
    const ssm_conv_indexed_args state{pool->data,
        static_cast<const int32_t *>(dst->src[3]->data), static_cast<const int32_t *>(dst->src[4]->data),
        int64_t(pool->nb[2]), pool->ne[2], ggml_get_op_params_i32(dst, 0), x->ne[1]};
    ssm_conv_f32_cuda<false,TX,true>(static_cast<const TX *>(x->data), static_cast<const float *>(w->data), nullptr,
        x->nb[0], x->nb[1], x->nb[2], w->nb[1], static_cast<float *>(dst->data),
        dst->nb[0], dst->nb[1], dst->nb[2], w->ne[0], x->ne[1], x->ne[0], x->ne[2], ctx.stream(), state);
}
void ggml_cuda_op_ssm_conv_indexed(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    if (!ggml_cuda_supports_ssm_conv_indexed(dst)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid indexed SSM convolution metadata");
    }
    switch (dst->src[0]->type) {
        case GGML_TYPE_F32: ggml_cuda_op_ssm_conv_indexed_impl<float>(ctx, dst); break;
        case GGML_TYPE_F16: ggml_cuda_op_ssm_conv_indexed_impl<half>(ctx, dst); break;
        case GGML_TYPE_BF16: ggml_cuda_op_ssm_conv_indexed_impl<nv_bfloat16>(ctx, dst); break;
        default: hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid indexed SSM convolution type");
    }
}
