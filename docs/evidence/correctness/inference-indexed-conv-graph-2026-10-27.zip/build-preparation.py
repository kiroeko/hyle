"""Read actual cached recipes and write a bounded plan; never compile or patch."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
B = R / '.scratch/inference-cpu-storage-gather-20261027'
G = R / '.scratch/inference-indexed-state-20261027'
F = R / '.scratch/inference-slot-source-fallback-20261027'
U = Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def norm(raw):
    return raw.replace(b'\r\n', b'\n').replace(b'\r', b'\n')


def pin(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path.read_bytes()))


inputs = read(B / 'link-inputs.json')
assert len(inputs) == 227


def selected(tail):
    result = [row for row in inputs if row['path'].endswith(tail)]
    assert len(result) == 1, tail
    row = result[0]
    assert pin(Path(row['path'])) == row
    return row


names = ['src/ggml-cuda/ssm-conv.cu', 'src/ggml-cuda/ssm-conv.cuh',
         'src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/gated_delta_net.cu',
         'src/ggml-cuda/gated_delta_net.cuh', 'src/ggml-cuda/common.cuh', 'include/ggml.h']
manifests = [R / ('third_party/' + name) for name in (
    'ggml_runtime/patches.json', 'ggml_cpu_runtime/patches.json',
    'ggml_cuda_runtime/patches.json', 'ggml_cuda_runtime/iq1-patches.json')]
composed = []
for name in names:
    original = norm((U / name).read_bytes())
    raw = original
    stages = []
    for manifest in manifests:
        for entry in read(manifest)['files']:
            if entry['path'] != name:
                continue
            for edit in entry['edits']:
                before = edit['before'].encode()
                assert raw.count(before) == 1, (name, str(manifest))
                raw = raw.replace(before, edit['after'].encode(), 1)
            stages.append(str(manifest.relative_to(R)))
    previous = G / 'native-overlay' / name
    composed.append(dict(path=name, upstream_sha256=sha(original), composed_normalized_sha256=sha(raw),
        manifests=stages, previous_indexed_GDN_normalized_sha256=sha(norm(previous.read_bytes())) if previous.exists() else None))

ssm = R / '.scratch/architecture-refactor-2026-10-18/bf16-grouped-bank/checks/native1'
specs = [
    ('conv', ssm / 'native--ssm-conv-compile.command.json', 'src/ggml-cuda/ssm-conv.cu', selected('bf16-grouped-bank\\checks\\native1\\native--ssm-conv.obj'), 'NVCC'),
    ('dispatcher', G / 'compile2/dispatcher/command.json', 'src/ggml-cuda/ggml-cuda.cu', selected('inference-indexed-state-20261027\\compile2\\dispatcher\\unit.obj'), 'NVCC'),
    ('provider', F / 'compile4/provider/command.json', 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc', selected('inference-slot-source-fallback-20261027\\compile4\\provider\\unit.obj'), 'CXX'),
    ('tensor', G / 'graph-integration/compile/tensor/command.json', 'src/compute_provider_ggml_cuda/tensor_program.cc', selected('graph-integration\\compile\\tensor\\unit.obj'), 'CXX'),
    ('graph', F / 'compile/graph-provider/command.json', 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc', selected('inference-slot-source-fallback-20261027\\compile\\graph-provider\\unit.obj'), 'CXX'),
    ('test', F / 'compile3/cuda-test/command.json', 'tests/graph_provider_ggml_cuda/indexed_conv_test.cc', None, 'CXX')]
units = []
for tag, recipe, source, replaces, language in specs:
    command = list(read(recipe)['command'])
    out = W / 'compile' / tag
    if language == 'NVCC':
        removed = [arg for arg in command if arg.startswith('-I') and not Path(arg[2:]).is_dir()]
        command = [arg for arg in command if arg not in removed]
        command[1:1] = ['-I' + str(W / 'native-overlay/src/ggml-cuda'), '-I' + str(W / 'native-overlay/src'), '-I' + str(W / 'native-overlay/include')]
        old_obj = command[command.index('-o') + 1]
        command[command.index('-c') + 1] = str(W / 'native-overlay' / source)
        for flag, value in [('-o', out / 'unit.obj'), ('-MT', out / 'unit.obj'), ('-MF', out / 'unit.d')]:
            command[command.index(flag) + 1] = str(value)
        command = [arg.replace(str(Path(old_obj).with_suffix('.pdb')), str(out / 'unit.pdb')) for arg in command]
        assert '-use_fast_math' in command and '--generate-code=arch=compute_89,code=[sm_89]' in command
    else:
        removed = []
        command = [str(R / source) if arg.endswith(('.cc', '.cpp')) else arg for arg in command]
        for index, arg in enumerate(command):
            if arg.startswith('/Fo'): command[index] = '/Fo' + str(out / 'unit.obj')
            elif arg.startswith('/Fd'): command[index] = '/Fd' + str(out / 'unit.pdb')
            elif arg.startswith('/FI') and arg.endswith('provider-version.h'): command[index] = '/FI' + str(W / 'provider-version.h')
            elif arg == '/sourceDependencies': command[index + 1] = str(out / 'dependencies.json')
        command[1:1] = ['/I' + str(R / 'include'), '/I' + str(R), '/I' + str(W / 'native-overlay/src/ggml-cuda')]
    units.append(dict(name=tag, language=language, source=source, recipe=pin(recipe), replaces=replaces,
        command_template=command, removed_dead_include_directories=removed))

gdn = selected('inference-indexed-state-20261027\\compile\\gdn\\unit.obj')
common = selected('windows-vulkan\\compile\\common\\unit.obj')
ready = read(B / 'ready.json')
link = list(read(B / 'link/command.json')['command'])
replace = {unit['replaces']['path'].casefold(): str(W / 'compile' / unit['name'] / 'unit.obj') for unit in units if unit['replaces']}
count = 0
for index, arg in enumerate(link):
    if arg.casefold() in replace: link[index] = replace[arg.casefold()]; count += 1
    elif arg.upper().startswith('/OUT:'): link[index] = '/OUT:' + str(W / 'link/indexed-conv-test.exe')
    elif arg.upper().startswith('/PDB:'): link[index] = '/PDB:' + str(W / 'link/indexed-conv-test.pdb')
    elif arg.upper().startswith('/IMPLIB:'): link[index] = '/IMPLIB:' + str(W / 'link/indexed-conv-test.lib')
assert count == 5
link += [str(W / 'compile/test/unit.obj'), '/MAP:' + str(W / 'link/image.map')]
lock = read(R / 'cmake/HyleDependencyLock.json')
deps = {item['name']: item for item in lock['dependencies']}
identity_inputs = [deps['ggml_runtime_patches']['vendored']['tree_sha256'],
    deps['ggml_cpu_runtime_patches']['vendored']['tree_sha256'],
    sha((R / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes()),
    sha((R / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes()),
    deps['ggml_cuda_runtime_patches']['vendored']['tree_sha256'],
    sha((R / 'src/compute_ggml_runtime/gated_delta_scale.h').read_bytes())]
version = '456172ec+iq1-46cbf0e9-resource-' + sha(''.join(identity_inputs).encode())[:16]
plan = dict(status='READ_ONLY_PREPARATION_WAITING_SOURCE_FROZEN', builds=0, runs=0, downloads=0, SDK_copies=0,
    baseline=dict(ready=pin(B / 'ready.json'), link_inputs=pin(B / 'link-inputs.json'), inputs=227,
        link_recipe=pin(B / 'link/command.json'), runtime=ready['runtime']),
    replacements=5, added_test_object=1, final_inputs=228, NVCC_TUs=2, CXX_TUs=4, images=1, units=units,
    retained_gdn_object=gdn, retained_common_object=common,
    source_composition_observed= composed, canonical_observed=[pin(R / 'cmake/HyleDependencyLock.json'), *[pin(path) for path in manifests]],
    native_generation=['After the native owner freezes canonical patches, compose exactly base -> CPU -> CUDA -> IQ1 from the locked existing upstream cache into a new small native-overlay. Never copy the whole SDK or mutate a shared cache.',
        'Write only ssm-conv.cu/.cuh, ggml-cuda.cu and required exact GDN-private headers; current combined GDN .cu/.cuh must normalize-equal the sources for retained native GDN object, otherwise its reuse must be revisited.',
        'Every edit context must be unique. CUDA manifest after hashes describe its standalone stage; IQ1 standalone before/after pins cannot be confused with the final combined dispatcher hash.',
        'The new dispatcher must retain existing indexed GDN support/entry/contract and both old-fusion exclusions as well as the new indexed conv mode; do not compile a legacy pre-GDN dispatcher.'],
    provider_version=dict(observed_recipe_header=str(R / '.scratch/architecture-refactor-2026-10-18/gdn-direct-state-output/provider-version.h'),
        observed_derived_version=version, formula='Original CPU+CUDA/no-Metal/no-Vulkan source identity, compute_ggml_runtime/CMakeLists.txt:58,83,176-189.',
        action='After final lock/tree freeze, regenerate this scratch provider-version.h with the same formula and replace /FI. Never mutate the old header/cache.'),
    header_ABI=['program.h changes comments only; reuse existing Node.indexed_state bool and Recipe.effect_roots fields without adding layout.',
        'New indexed_conv.h helper and ssm-conv.cuh declarations are private/additive. Rebuild their actual provider/tensor/Graph/native consumers only; no GGML enum/tensor/backend/legacy fused-state struct changes.',
        'Old native GDN and current common40d4 objects remain exactly pinned. New Graph effect StoreBinding carrier/vtable layout must stay unchanged; no second owner or ID upload.'],
    link_command_template=link,
    planned_filter=dict(filter='GgmlCudaIndexedConvGraph.*:GgmlCudaIndexedStateGraph.*', expected_tests=7,
        status='Awaiting final test freeze/root confirmation; no new CPU/shared/SDK/model/performance run planned.'))
(W / 'build-preparation.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print(json.dumps(pin(W / 'build-preparation.json')))
