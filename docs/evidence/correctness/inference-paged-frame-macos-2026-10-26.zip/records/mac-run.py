"""In the fixed new Mac directory: build or run. No default action/retry."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-paged-frame-20261026')
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def read(p):return json.loads(p.read_text())
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def execute(tag,args,timeout):
    out=W/tag;out.mkdir(exist_ok=False);p=read(W/'plan.json');env=os.environ.copy();env.update(p['environment'])
    save(out/'command.json',dict(command=args,cwd=str(W),environment=p['environment']))
    start=time.perf_counter()
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        proc=subprocess.Popen(args,cwd=W,env=env,stdout=stdout,stderr=stderr);save(out/'running.json',dict(pid=proc.pid))
        try:code=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:proc.kill();code=proc.wait(timeout=5)
    result=dict(pid=proc.pid,exit=code,seconds=time.perf_counter()-start);save(out/'process.json',result)
    print(tag,json.dumps(result),flush=True)
    if code:raise RuntimeError(tag+' failed; stopped without retry')
    return result
def build():
    p=read(W/'plan.json');assert p['remote']==str(W)
    own={str(W/'source'/x['path']):x for x in read(W/'source-freeze.json')}
    for path,row in own.items():assert pin(Path(path))['sha256']==row['sha256'],path
    for path in p['reused_current_objects']:assert Path(path).is_file(),path
    inputs=[Path(x) for x in p['jobs'][-1]['command'] if x.endswith(('.o','.a','.dylib')) and not x.startswith(str(W)+'/')]
    save(W/'reused-inputs.json',[pin(x) for x in inputs])
    results=[]
    for job in p['jobs']:
        result=execute(job['tag'],job['command'],job['timeout']);results.append(dict(tag=job['tag'],process=result))
        if '-c' in job['command']:
            dep=Path(job['command'][job['command'].index('-MF')+1]);raw=dep.read_text();save(W/job['tag']/'dependencies.json',dict(makefile=raw))
            paths=re.split(r'\s+',raw.replace('\\\n',' ').split(': ',1)[1].strip())
            used=[]
            for path in paths:
                if path.startswith(str(W)+'/source/'):
                    assert path in own,path
                    assert pin(Path(path))['sha256']==own[path]['sha256'],path
                    used.append(pin(Path(path)))
                elif '/source/include/hyle/' in path or '/source/src/' in path or '/source/engine/' in path:
                    raise RuntimeError('old project shadow dependency: '+path)
            save(W/job['tag']/'actual-project-dependencies.json',used)
    save(W/'ready.json',dict(image=pin(W/'host-image'),processes=results,compiled_TUs=11,SDK_builds=0,scope=p['scope']))
def run():
    ready=read(W/'ready.json');image=ready['image'];assert pin(Path(image['path']))==image
    fixture=W/'fixture';assert pin(fixture/'untrained-bf16.bin')['sha256']==read(W/'fixture.json')['bin_sha256']
    rows=[]
    for tag,extra in [('run-ordinary-mtp',[]),('run-lag1',['--mtp-lag1'])]:
        rows.append(dict(tag=tag,process=execute(tag,[image['path'],'--apple',str(fixture),*extra],60)))
    save(W/'summary.json',dict(status='TWO_FINITE_APPLE_PROCESSES_EXIT_ZERO',processes=rows,scope=read(W/'plan.json')['scope'],quality_claim=False,performance_claim=False))
if __name__=='__main__':
    if sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
