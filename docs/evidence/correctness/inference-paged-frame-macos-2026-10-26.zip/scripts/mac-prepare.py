"""Explicit local preparation of one small current-source Apple overlay."""
from pathlib import Path
import hashlib,json,re,sys,zipfile
R=Path(__file__).resolve().parents[2]
W=Path(__file__).resolve().parent/'mac'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-paged-frame-20261026'
B=R/'.scratch/inference-native-host-image-20261026/mac-model-attempt4'
M=R/'.scratch/inference-native-host-image-20261026/mac-model-attempt2'
C=R/'.scratch/inference-copy-public-retention-20261026/mac/records'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def prepare():
    assert not (W/'plan.json').exists()
    oldjobs=read(B/'plan.json')['jobs']
    generic=next(x['command'] for x in oldjobs if x['tag']=='compile-src--graph--resources.cc')
    specs=[('layout','src/compute_batch/batch_layout.cc'),('arena','src/compute_batch/paged_arena.cc'),
      ('append','src/graph_batch/paged_append.cc'),('resources','src/graph/resources.cc'),
      ('stream','src/compute_stream/file_stream.cc'),('tensor','src/compute/tensor_view.cc'),
      ('executable','src/graph/executable.cc'),('submission','src/graph/submission.cc'),
      ('transform','src/compute_provider_native/transform.cc'),
      ('weights','engine/models/qwen35/weights.cc'),('model','tests/tools/qwen_host_image_test.cc')]
    roots=[R,R/'include',*[R/'src'/x for x in ('compute','graph','compute_batch','compute_provider_native','compute_stream')]]
    files={};todo=[R/s for _,s in specs]
    while todo:
        p=todo.pop().resolve();name=p.relative_to(R).as_posix()
        if name in files:continue
        assert not name.startswith('.scratch/')
        raw=p.read_bytes();files[name]=raw
        for inc in re.findall(r'^\s*#\s*include\s*["<]([^">\r\n]+)[">]',raw.decode('utf-8-sig'),re.M):
            for base in [p.parent,*roots]:
                q=(base/inc).resolve()
                if q.is_file() and q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                    todo.append(q);break
    prefix=['-I'+REMOTE+'/source/include','-I'+REMOTE+'/source',
      *['-I'+REMOTE+'/source/src/'+x for x in ('compute','graph','compute_batch','compute_provider_native','compute_stream')]]
    jobs=[]
    for tag,source in specs:
        args=list(read(M/('compile-'+tag)/'command.json')['command']) if tag in ('model','weights') else list(generic)
        args=args[:1]+prefix+args[1:]
        args[args.index('-c')+1]=REMOTE+'/source/'+source
        args[args.index('-o')+1]=REMOTE+'/'+tag+'.o'
        args[args.index('-MF')+1]=REMOTE+'/'+tag+'.o.d'
        jobs.append(dict(tag='compile-'+tag,command=args,source=source,timeout=180))
    link=read(B/'link/command.json')['command']
    needles={'layout':'model-attempt4/src--compute_batch--batch_layout.cc.o',
      'arena':'model-attempt4/src--compute_batch--paged_arena.cc.o',
      'append':'model-attempt4/src--graph_batch--paged_append.cc.o',
      'resources':'model-attempt4/src--graph--resources.cc.o',
      'weights':'model-attempt2/weights.o','model':'model-attempt2/model.o',
      'stream':'architecture-refactor-20261019-apple-page-invocation/src--compute_stream--file_stream.o',
      'executable':'qwen-cpu-apple-functional-20261024/attempt1/objects/current--src--graph--executable.cc.o',
      'transform':'qwen-pure-cpu-functional-20261024/attempt1/objects/src--compute_provider_native--transform.cc.o'}
    replacements=[]
    for tag,tail in needles.items():
        found=[x for x in link if x.endswith(tail)];assert len(found)==1,(tag,found)
        replacements.append(dict(before=found[0],after=REMOTE+'/'+tag+'.o'))
        link.remove(found[0])
    assert not any('force_load' in x or 'all_load' in x for x in link)
    reuse=[('/Users/kiro/hyle-scratch/compute-unified/inference-copy-public-retention-20261026/'+n+'.o')
      for n in ('device','batch_transfer2','apple_copy_program')]
    reuse+=['/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026/completion.o']
    assert not any(x in link for x in reuse)
    link[1:1]=[REMOTE+'/'+tag+'.o' for tag,_ in specs]+reuse
    link[link.index('-o')+1]=REMOTE+'/host-image'
    link=[('-Wl,-map,'+REMOTE+'/image.map') if x.startswith('-Wl,-map,') else x for x in link]
    jobs.append(dict(tag='link',command=link,timeout=180))
    private=[];details=[]
    for label,freeze in [('full-model',read(B/'source-freeze.json')),('retention',read(C/'source-freeze.json'))]:
        for row in freeze:
            name=row['path'];p=R/name
            if not p.is_file():continue
            if name.startswith('src/') and p.suffix=='.h':
                now=sha(p.read_bytes());private.append(dict(cache=label,path=name,old=row['sha256'],current=now,identical=now==row['sha256']))
            elif name.startswith('include/hyle/compute/detail/'):
                now=sha(p.read_bytes())
                if now!=row['sha256']:details.append(dict(cache=label,path=name,old=row['sha256'],current=now))
    assert all(x['identical'] for x in private)
    save(W/'abi-boundaries.json',dict(private_headers=private,changed_installed_detail=details,
      detail_changes='batch_provider adds new footprint type/static function; paged_arena_access adds overloads. Existing carrier/vtable fields unchanged. BatchLayoutData stays opaque inside rebuilt layout TU.',
      graph_padding='Rebuild executable/submission/native transform for initialized P and logical copy behavior, although private struct headers are unchanged.',
      reuse='Current retention direct objects precede unchanged lazy archives; no whole/force-load or ignored duplicates. Existing report observation/header pins unchanged.'))
    fixture=R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    binary=(fixture/'untrained-bf16.bin').read_bytes()
    assert len(binary)==298628 and sha(binary)=='2fbd8f01edd4fc71c2dd5b7fe57b8173a3aace490819b320719fd82add57bf14'
    manifest=(fixture/'weights.tsv').read_text(encoding='utf-8')
    bins=set(re.findall(r'"([^"\r\n]*untrained-bf16\.bin)"',manifest))
    assert len(bins)==1,bins
    modified=manifest.replace(next(iter(bins)),REMOTE+'/fixture/untrained-bf16.bin')
    frozen=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(files.items())]
    save(W/'source-freeze.json',frozen)
    save(W/'fixture.json',dict(original_manifest_sha256=sha((fixture/'weights.tsv').read_bytes()),
      adapted_manifest_sha256=sha(modified.encode()),bin_sha256=sha(binary),bin_bytes=len(binary),
      adaptation='Only binary file path in validation manifest; geometry/roles/offsets/bytes unchanged.',HTTP=0))
    plan=dict(remote=REMOTE,jobs=jobs,compiled_TUs=11,replacements=replacements,reused_current_objects=reuse,
      baseline_link=str(B/'link/command.json'),environment=dict(MLX_METAL_PATH='/Users/kiro/hyle-scratch/compute-unified/qwen-k1-functional-20261024/attempt1/mlx.metallib',OMP_NUM_THREADS='4',VECLIB_MAXIMUM_THREADS='4'),
      scope='One CPU+Apple canonical host-image consumer, tiny ordinary/MTP byte+lifetime roundtrip and lag1. No quality/performance/full-platform claim.',
      quality_claim=False,performance_claim=False,SDK_builds=0,HTTP=0)
    save(W/'plan.json',plan)
    with zipfile.ZipFile(W/'source.zip','x',zipfile.ZIP_DEFLATED) as z:
        for n,raw in sorted(files.items()):z.writestr('source/'+n,raw)
        for n in ('plan.json','source-freeze.json','fixture.json','abi-boundaries.json'):z.write(W/n,n)
        z.write(W.parent/'mac-run.py','mac-run.py')
        z.writestr('fixture/weights.tsv',modified.encode());z.writestr('fixture/untrained-bf16.bin',binary)
    print(json.dumps(dict(files=len(files),zip_bytes=(W/'source.zip').stat().st_size,compiled_TUs=11,remote=REMOTE)),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['prepare']:prepare()
    else:print(__doc__)
