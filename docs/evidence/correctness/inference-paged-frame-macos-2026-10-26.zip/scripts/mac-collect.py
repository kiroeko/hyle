"""Collect only explicit small records from this already-complete Mac attempt."""
from pathlib import Path
import hashlib,json,zipfile
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-paged-frame-20261026')
p=json.loads((W/'plan.json').read_text())
names=['plan.json','source-freeze.json','abi-boundaries.json','fixture.json','ready.json',
       'reused-inputs.json','summary.json','mac-run.py','mac-run2.py','fixture/weights.tsv']
for job in p['jobs']:
    tag=job['tag']
    names += [tag+'/'+x for x in ('command.json','running.json','process.json','stdout.log','stderr.log')]
    if '-c' in job['command']:
        names += [tag+'/dependencies.json',tag+'/actual-project-dependencies.json']
for tag in ('run-ordinary-mtp','run-lag1'):
    names += [tag+'/'+x for x in ('command.json','running.json','process.json','stdout.log','stderr.log')]
names=list(dict.fromkeys(names))
assert all((W/n).is_file() for n in names)
rows=[dict(path=n,bytes=(W/n).stat().st_size,sha256=hashlib.sha256((W/n).read_bytes()).hexdigest()) for n in names]
shadow=[]
for job in p['jobs']:
    if '-c' not in job['command']:continue
    dep=json.loads((W/job['tag']/'dependencies.json').read_text())['makefile']
    for token in dep.replace('\\\n',' ').split():
        path=Path(token)
        if '/include/hyle/' in token and not str(path.resolve()).startswith(str(W)+'/source/'):
            shadow.append(dict(unit=job['tag'],path=str(path)))
result=dict(status='APPLE_TINY_ORDINARY_MTP_AND_LAG1_PASS',
    image=json.loads((W/'ready.json').read_text())['image'],compiled_TUs=11,
    compile_processes=11,link_processes=1,model_processes=2,SDK_builds=0,HTTP=0,
    records=rows,unexpected_cached_Hyle_public_headers=shadow,
    script_correction='First build continuation stopped after four successful TUs because a ../ dependency spelling was not normalized. mac-run2 resolves paths and reused all four recorded successes; no compile or model retry.',
    limitations=['Small untrained GA/MTP fixture is byte/lifetime coverage, not task-quality oracle.',
      'No full335/other-model matrix or speed benchmark was run on Mac in this batch.',
      'Old cached vendor/SDK objects and report reused; changed layout/arena/append/resources/stream/tensor/executable/submission/transform/weights/Model rebuilt.',
      'Original fixture binary bytes preserved; only manifest binary path adapted in the validation copy.'])
assert not shadow,shadow
(W/'final-summary.json').write_text(json.dumps(result,indent=2)+'\n')
names+=['final-summary.json']
with zipfile.ZipFile(W/'records.zip','x',zipfile.ZIP_DEFLATED) as z:
    for n in names:z.write(W/n,n)
print(json.dumps(dict(files=len(names),zip_bytes=(W/'records.zip').stat().st_size,
    sha256=hashlib.sha256((W/'records.zip').read_bytes()).hexdigest())))
