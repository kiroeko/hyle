$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$vulkanBuild = 'C:/hyle-scratch/r6-vulkan-20260917/build-native-v2'
$vulkanLogs = 'C:/hyle-scratch/r6-vulkan-20260917/native-corrected-02'
$vulkanTools = 'C:/hyle-scratch/r6-vulkan-20260917/tools/validation-1.4.357.0'
New-Item -ItemType Directory -Path $vulkanLogs -ErrorAction Stop | Out-Null
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_PARALLEL_LEVEL = '1'
& cmake --build $vulkanBuild --parallel 2 --target hyle_compute_route_vulkan_tests hyle_graph_route_vulkan_tests *> "$vulkanLogs/build.log"
if ($LASTEXITCODE -ne 0) {
  Get-Content "$vulkanLogs/build.log" -Tail 90
  exit $LASTEXITCODE
}
$vulkanBin = Join-Path $vulkanBuild 'bin'
Copy-Item -LiteralPath "$vulkanTools/VkLayer_khronos_validation.dll" -Destination $vulkanBin
Copy-Item -LiteralPath "$vulkanTools/VkLayer_khronos_validation.json" -Destination $vulkanBin
$env:VK_LAYER_PATH = $vulkanBin
$env:VK_LOADER_LAYERS_DISABLE = '~implicit~'
$env:HYLE_VULKAN_VALIDATION = '1'
$env:VK_KHRONOS_VALIDATION_VALIDATE_SYNC = 'true'
$env:VK_KHRONOS_VALIDATION_DEBUG_ACTION = 'VK_DBG_LAYER_ACTION_LOG_MSG'
& ctest --test-dir $vulkanBuild --output-on-failure --no-tests=error --timeout 120 -L '^(compute_route_vulkan|graph_route_vulkan)$' *> "$vulkanLogs/ctest.log"
$vulkanTestExit = $LASTEXITCODE
Copy-Item -LiteralPath "$vulkanBuild/Testing/Temporary/LastTest.log" -Destination "$vulkanLogs/LastTest.log"
Copy-Item -LiteralPath "$vulkanBuild/CMakeCache.txt" -Destination "$vulkanLogs/CMakeCache.txt"
Get-Content "$vulkanLogs/ctest.log" -Tail 100
if ($vulkanTestExit -ne 0) { exit $vulkanTestExit }
$vulkanErrors = Select-String -Path "$vulkanLogs/LastTest.log" -Pattern 'Validation Error|VUID-|SYNC-HAZARD'
if ($vulkanErrors) {
  $vulkanErrors | Select-Object -First 30
  exit 3
}
Write-Output 'PASS first native numerical/lifecycle tests and Vulkan validation; no delivery/P1 claim.'
