from pathlib import Path
import ctypes, hashlib, json, subprocess, time

ctypes.windll.kernel32.SetErrorMode(0x8003)
root = Path('C:/hyle-scratch/r6-vulkan-20260917')
status = Path('C:/hyle-scratch/r5-apple-20260917/serial-final/status.json')
record = root / 'native-corrected-02-controller.json'
assert not record.exists(), 'inspect the existing finite run before resuming'
record.write_text(json.dumps({'status': 'WAITING_R5'}) + '\n')
print('Waiting for all serial R5 gates; no concurrent heavy build or GPU validation.', flush=True)
while True:
    previous = json.loads(status.read_text())
    if previous['status'] == 'PASS':
        break
    if previous['status'] == 'STOPPED':
        record.write_text(json.dumps({'status': 'STOPPED', 'reason': 'R5 needs review'}) + '\n')
        raise SystemExit(2)
    time.sleep(15)

canonical = Path('C:/public/project-hyle/hyle')
paths = subprocess.check_output(['git', 'ls-files', '--', 'CMakeLists.txt', 'cmake',
    'include', 'src', 'tests/compute_route_vulkan', 'tests/graph_route_vulkan',
    'third_party/ggml_vulkan_shaders'], cwd=canonical, text=True).splitlines()
inputs = {p: hashlib.sha256((canonical / p).read_bytes()).hexdigest() for p in paths}
start = time.time()
row = {'status': 'RUNNING', 'started_utc_seconds': start,
       'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=canonical, text=True).strip(),
       'scope': 'Mutable implementation checkpoint, native correctness/validation only; not a frozen P1 candidate.',
       'inputs': inputs}
record.write_text(json.dumps(row, indent=2) + '\n')
with (root / 'native-corrected-02-controller.log').open('w') as log:
    result = subprocess.run(['pwsh', '-NoProfile', '-File', str(root / 'run-native-corrected-02.ps1')],
        cwd=canonical, stdout=log, stderr=subprocess.STDOUT, timeout=900)
unchanged = all(hashlib.sha256((canonical / p).read_bytes()).hexdigest() == digest
                for p, digest in inputs.items())
row.update(status='PASS' if result.returncode == 0 and unchanged else 'FAIL',
           exit_code=result.returncode, product_inputs_unchanged=unchanged,
           finished_utc_seconds=time.time())
record.write_text(json.dumps(row, indent=2) + '\n')
print((root / 'native-corrected-02-controller.log').read_text()[-10000:], flush=True)
print(row['status'], 'native checkpoint; product_inputs_unchanged=', unchanged, flush=True)
raise SystemExit(0 if row['status'] == 'PASS' else 1)
