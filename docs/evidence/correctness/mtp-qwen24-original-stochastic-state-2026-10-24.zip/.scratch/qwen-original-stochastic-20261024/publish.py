from pathlib import Path
import json,hashlib,zipfile,difflib,xml.etree.ElementTree as ET
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p);return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
tree=ET.parse(S/'run1/results.xml').getroot();assert tree.attrib['tests']=='1' and tree.attrib['failures']==tree.attrib['errors']==tree.attrib['disabled']=='0'
item=next(tree.iter('testcase'));assert item.find('skipped') is None
properties={p.attrib['name']:p.attrib['value'] for p in item.iter('property')};assert properties['random_committed_draws']=='4'
old=(R/'.scratch/glm-random-mtp-20261024/source/tests/compute_models/glm_target_verifier_fragment.h').read_text();old=old[old.index('struct RandomProposalPorts final'):old.index('struct K1Decision final')]
old=old.replace('model_sampling_fragment::Builder r(fragment);','Builder r(fragment);').replace('append_random_proposal','append_proposal').replace('append_random_decision','append_decision')
new=(R/'tests/compute_models/model_sampling_fragment.h').read_text();new=new[new.index('struct RandomProposalPorts final'):new.index('} // namespace model_sampling_fragment')];assert old==new
(S/'helper-relocation-proof.json').write_text(json.dumps(dict(equal_after_only_namespace_and_function_name_changes=True,normalized_body_bytes=len(old.encode()),normalized_sha256=hashlib.sha256(old.encode()).hexdigest(),source='Frozen actual GLM Flash source',destination='model_sampling_fragment.h',sampling_math_changes=0),indent=2)+'\n')
old=(S/'source/tests/compute_models/qwen_mtp_state_consumer_test.cc').read_text();current=(R/'tests/compute_models/qwen_mtp_state_consumer_test.cc').read_text()
(S/'post-run-cpu-include-guard.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),current.splitlines(True),fromfile='executed-Q24-source',tofile='current-Qwen-source')))
records=[S/x for x in ('source-records.json','cpu-syntax3-source.json','link-inputs.json','ready.json','run1-inputs.json','helper-relocation-proof.json','post-run-cpu-include-guard.patch','build.py','publish.py')]
for sub in ('compile1','link1','run1','cpu-syntax3'):
 records.extend(p for p in (S/sub).glob('*') if p.is_file() and p.suffix in ('.json','.log','.xml'))
records.extend(p for p in (S/'source').rglob('*') if p.is_file())
g=R/'.scratch/glm-random-mtp-20261024'
for sub in ('moved-helper-syntax-flash','moved-helper-syntax-pro'):
 records.extend(p for p in (g/sub).glob('*') if p.is_file() and p.suffix in ('.json','.log'));records.append(g/(sub+'-source.json'))
records.append(R/'tests/compute_models/qwen_mtp_state_consumer_test.cc')
out=R/'docs/evidence/correctness/mtp-qwen24-original-stochastic-state-2026-10-24';archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(records)):z.write(p,p.relative_to(R))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
summary=dict(date='2026-10-24',result='PASS finite actual Q24 original-GGUF MoE stochastic K1 and residual continuation',
 discovery='The preexisting shared Q27/Q24 original-role controller computed actual q/target full logits but only compared TopK proposal==target_id0 and bound target TopK pending leases. Identity/role inventory completion did not cover stochastic consumer wiring.',
 changes=['Use shared typed fragment proposal/decision declarations and unchanged hyle::inference sampling math; model-free declarations moved from the GLM header with exact normalized body equality proof.',
  'Retain actual NextN F32 q logits, categorical-sample actual I32 proposal, feed it into target row1, use real p0/q/p1 decision and actual residual/bonus pending lease.',
  'Existing twelve target/NextN resources plus optional shared Cursor HostMetadata publish together through the existing expected-base StateHead. Cancelled/invalid/stale attempts keep the original committed cursor.',
  'Actual residual/bonus enters the original target and NextN continuation. A separate ordinary single-row projection borrows the same original target head, samples its true target pending, and commits one additional draw with the complete prefix.',
  'CPU-only strict compile exposed an old unconditional CPU+CUDA header/report dependency. It is now guarded by actual route macros; the final pure-CPU test source compiles without CUDA headers.'],
 process=read(S/'run1/process.json'),image=read(S/'ready.json')['image'],test=item.attrib,properties=properties,
 actual_transitions=[line for line in (S/'run1/stdout.log').read_text(errors='replace').splitlines() if 'QWEN RANDOM K1 ' in line],
 counts=dict(new_HTTP_bytes=0,new_weight_bytes=0,new_SDK_or_provider_TUs=0,consumer_TUs=1,real_cuda_cases=1),
 cpu_syntax=dict(process=read(S/'cpu-syntax3/process.json'),source=read(S/'cpu-syntax3-source.json'),actual_CPU_feature_macro='HYLE_GGML_CPU_IQ1_EXTENSIONS=1, matching this cached/CMake-selected expanded GGUF consumer',cuda_headers_required=False,CPU_runtime_case=False),
 inherited_evidence=['docs/evidence/correctness/mtp-qwen24-target-verifier-2026-10-23.json','docs/evidence/correctness/mtp-q24-original-nextn-2026-10-23.json','docs/evidence/correctness/mtp-glm-original-stochastic-state-2026-10-24.json'],
 limitations=['This is target91+NextN92 with explicit synthetic previous-layer input/history, not a complete trained92-layer target or full-model quality result.',
  'Only one natural trial ran and it rejected. No Q24 stochastic accepted/bonus branch, natural acceptance rate, throughput or measured physical memory claim.',
  'The common controller is shared by Q27/Q24/derived component recipes, but this one actual Q24 run is not a rerun or certification of every source/quantization/CPU/backend identity. Q27 full-model weights remain separately in progress.',
  'The executed CUDA source and final CPU-only header guard delta are archived exactly; the guard does not change CUDA mathematics. The moved GLM declarations are mathematically identical and both affected GLM consumer TUs passed strict CPU syntax after relocation, without another large-bank run.',
  'Existing MixedPlacement CPU-vocabulary stochastic sampler domains are a separate follow-up. This evidence covers the single-native-domain route only.'],
 archive=ident(archive),archive_records=len(set(records)))
out.with_suffix('.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf8');print(out.with_suffix('.json'));print(ident(archive))
