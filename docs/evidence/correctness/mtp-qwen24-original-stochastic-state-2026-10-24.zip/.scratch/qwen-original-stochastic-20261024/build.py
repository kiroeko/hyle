from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('glib',R/'.scratch/glm-random-mtp-20261024/build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def compile(attempt):
 out=S/f'compile{attempt}';base=m.read(R/'.scratch/qwen27-target-verifier-20261023/compile1/qwen-state/compile.command.json')['command'];command=[];skip=False
 for flag in base:
  if skip:skip=False;continue
  if flag=='/sourceDependencies':skip=True;continue
  if flag.startswith(('/Fo','/Fd')) or flag.endswith('qwen_mtp_state_consumer_test.cc'):continue
  command.append(flag)
 source=R/'tests/compute_models/qwen_mtp_state_consumer_test.cc'
 command+=['/sourceDependencies',str(out/'deps.json'),str(source),'/Fo'+str(out/'consumer.obj')]
 env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 before=m.ident(source);m.b.execute(command,env,out,timeout=240);assert m.ident(source)==before
 m.save(out/'identity.json',dict(source=before,object=m.ident(out/'consumer.obj'),dependencies=[m.ident(p) for p in m.read(out/'deps.json')['Data']['Includes']]))
def link(attempt):
 base=m.read(R/'.scratch/dspark-random-mtp-20261024/link-command.json');command=[x for x in base if not x.upper().startswith(('/OUT:','/IMPLIB:','/MAP:','/PDB:')) and not x.endswith('dspark-random-mtp-20261024\\consumer.obj')]
 command.insert(1,str(S/f'compile{attempt}/consumer.obj'));command+=['/OUT:'+str(S/'checks.exe'),'/IMPLIB:'+str(S/'checks.lib')]
 compiler=str(Path(command[0]).with_name('cl.exe'));env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
 m.save(S/'link-inputs.json',[m.ident(x) for x in command if x.lower().endswith(('.obj','.lib')) and Path(x).is_absolute()]);m.b.execute(command,env,S/f'link{attempt}')
 m.save(S/'ready.json',dict(image=m.ident(S/'checks.exe'),new_SDK_TUs=0,consumer_TUs=1))
 dll=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
 if not (S/dll.name).exists():os.link(dll,S/dll.name)
def run(attempt):
 env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_QWEN')}
 env['PATH']=str(S)+';'+m.read(R/'.scratch/dspark-random-mtp-20261024/runtime.json')['PATH']
 env.update(HYLE_QWEN24_MTP_KV_DIR=str(R/'.scratch/qwen24-original-mtp-20261022/original-q24'),HYLE_QWEN24_ORIGINAL_NEXTN_DIR=str(R/'.scratch/q24-original-nextn-20261023/original-q24-nextn'),HYLE_QWEN24_ORIGINAL_TARGET_DIR=str(R/'.scratch/q24-target-verifier-20261023/original-target91'))
 m.save(S/f'run{attempt}-inputs.json',{k:v for k,v in env.items() if k.startswith('HYLE_QWEN')})
 command=[str(S/'checks.exe'),'--gtest_filter=QwenMtpStateConsumer.CudaQ24OriginalTargetAndNextNRandomVerifierContinuesAtomically','--gtest_output=xml:'+str(S/f'run{attempt}/results.xml')]
 m.b.execute(command,env,S/f'run{attempt}',timeout=600)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('actions',nargs='+',choices=['compile','link','run']);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
 for action in a.actions:globals()[action](a.attempt)
