import ctypes
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

repo = Path('C:/hyle-scratch/r5-validation-6f3ff7ca')
task = Path('C:/hyle-scratch/r5-apple-20260917/selected-windows')
ctypes.windll.kernel32.SetErrorMode(0x8003)
# Bound this validation process and its children; no user/global policy change.
ctypes.windll.kernel32.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
assert ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.c_void_p(-1), 0x14)
assert ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(-1), 0x20)
os.environ['HYLE_DEP_SOURCE_CACHE'] = 'C:/public/project-hyle/.deps'
(task / 'logs').mkdir(parents=True, exist_ok=True)
os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] = '2'
os.environ['CMAKE_GENERATOR'] = 'Ninja'
os.environ.pop('CMAKE_GENERATOR_PLATFORM', None)
os.environ.pop('CMAKE_GENERATOR_TOOLSET', None)
os.environ['CTEST_PARALLEL_LEVEL'] = '1'
os.environ['CTEST_INTERACTIVE_DEBUG_MODE'] = '0'
spec = importlib.util.spec_from_file_location('hyle_selector', repo / 'scripts/validation-select.py')
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
context = Path('C:/public/project-hyle/hyle/.scratch/validation/windows-msvc-context.json')
candidate = '6f3ff7cae99ff141fe5ccc44ff842c0fd60a1e3d'
cache = task / 'selected-receipts'
scratch_base = Path('C:/hvs5')
plan = selector.make_plan(repo, '3f6fe5d4', candidate, context=context, cache=cache)
assert plan['verdict'] != 'BLOCKED', plan
remaining = [g['id'] for g in plan['gates'] if g['status']=='SELECTED']
print('Resume only: '+str(remaining),flush=True)
assert all(g.startswith('delivery:') for g in remaining), remaining
identity = selector.environment_identity(context, native=True)
scratch = scratch_base / selector.digest({'tree': plan['candidate_tree'], 'context': identity})[:20]
build = scratch / ('build-' + selector.digest({'tree': plan['candidate_tree'], 'context': identity, 'factors': plan['selected_factors']})[:20])
for gate in plan['gates']:
    for command in gate['commands']:
        for arg in command:
            if arg.startswith('-DHYLE_SMOKE_ROOT='):
                target = Path(arg.split('=',1)[1].replace('{scratch}',str(scratch))).resolve()
                target.relative_to(scratch_base.resolve())
                assert target != scratch_base.resolve(), target
build_bin = build / 'bin'
build_bin.mkdir(parents=True, exist_ok=True)
dlls = [Path('C:/Windows/System32') / name for name in ('msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll')]
dlls += [Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64') / name for name in ('cudart64_13.dll','cublasLt64_13.dll')]
for dll in dlls:
    shutil.copyfile(dll, build_bin / dll.name)
(task/'logs/selected-paths.json').write_text(json.dumps({'candidate': candidate,'scratch':str(scratch),'build':str(build),'context':str(context),'DLLs':[str(p) for p in dlls]},indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'Exact selected native gates: {build}; actual CUDA/CRT DLLs staged before tests',flush=True)
selector.execute(repo, plan, cache, scratch_base, context=context)
selector.write_json(task/'logs/selected-result.json', selector.public_report(plan))
print(f'Selected gates verdict: {plan["verdict"]}',flush=True)
sys.exit(0 if plan['verdict']=='PASS' else 2)
