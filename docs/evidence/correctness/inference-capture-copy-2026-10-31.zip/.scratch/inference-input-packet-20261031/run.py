"""Finite normal-shared packet verification. Explicit actions, no retries."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,time
W=Path(__file__).resolve().parent; R=W.parent.parent; B=R/'.scratch/build-compute-v2-dev'
P=R/'.scratch/inference-input-packet-review-20261031'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve(); raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def save(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def environment():
    env=dict(os.environ);env.update(read(R/'.scratch/inference-default-product-build-20261031/environment.json'))
    for k in ('CL','_CL_','CFLAGS','CXXFLAGS','LDFLAGS','CUDAFLAGS','CUDAARCHS','CUDACXX','CXX','CC','TORCH_INSTALL_PREFIX','CMAKE_PREFIX_PATH'):env.pop(k,None)
    temp=W/'tmp';temp.mkdir(exist_ok=True);env['TEMP']=env['TMP']=str(temp)
    env['PATH']=str(B/'bin')+os.pathsep+env['PATH']
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
    return env
def check_product():
    f=read(W/'source-freeze.json')
    for row in f['source_pins']:
        actual=pin(R/row['relative']);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],row['relative']
    for row in read(W/'control/control-ready.json')['observed_runtime_current_readback']:assert pin(row['path'])==row,row['path']
    return f
def check_tests():
    for row in read(W/'test-source-freeze.json')['source_pins']:assert pin(row['path'])==row,row['path']
def native_cases():
    link_receipt=max((W/'host-link').glob('attempt*/process.json'),key=lambda p:int(p.parent.name[7:]))
    linked=read(link_receipt);assert linked['exit_code']==0
    moved=read(W/'host-fixture-ready.json');image=Path(moved['image']['path'])
    assert moved['image']==pin(image) and moved['image']['sha256']==linked['image']['sha256']
    check_product();check_tests()
    tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    cases=[('packet-cpu','--cpu','--input-packet'),('packet-cuda','--cuda','--input-packet'),
           ('phase-cpu','--cpu','--phase-preparation'),('host-cpu','--cpu',None),('host-cuda','--cuda',None),
           ('packed-cuda','--cuda','--packed-prefill'),('history-ordinary-cuda','--cuda','--history-ordinary')]
    plan=[{'name':name,'command':[str(image),backend,str(tiny)]+([flag] if flag else [])} for name,backend,flag in cases]
    restart=len(sys.argv)>2 and sys.argv[2] in ('attempt2','attempt3')
    assert restart,'First relocated native attempt is preserved; only the root-authorized setup correction may continue.'
    save(W/('tiny-plan-'+sys.argv[2]+'.json'),{'status':'AUTHORIZED_FINITE_SEVEN_SERIAL_AFTER_EXPLICIT_FIX','image':pin(image),'cases':plan,'downloads':0,'automatic_retries':0,'manual_setup_repeat_CPU':1,'manual_fixture_plan_repeat_CPU':int(sys.argv[2]=='attempt3'),'performance_comparison':False})
    spec=importlib.util.spec_from_file_location('normal_module_observation',R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py')
    sample=importlib.util.module_from_spec(spec);spec.loader.exec_module(sample)
    summaries=[]
    for case in plan:
        check_product();check_tests()
        attempt=sys.argv[2] if case['name']=='packet-cpu' else 'attempt1'
        out=W/'runs'/case['name']/attempt;out.mkdir(parents=True,exist_ok=False)
        save(out/'command.json',{'command':case['command'],'cwd':str(R),'image':pin(image),'normal_environment':pin(R/'.scratch/inference-default-product-build-20261031/environment.json'),'normal_bin_first':str(B/'bin'),'TEMP_TMP':str(W/'tmp')})
        started=now();tick=time.monotonic();observed={};errors={}
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            child=subprocess.Popen(case['command'],cwd=R,env=environment(),stdout=stdout,stderr=stderr)
            save(out/'process.json',{'state':'RUNNING','pid':child.pid,'start_utc':started})
            print(json.dumps({'case':case['name'],'state':'RUNNING','pid':child.pid}),flush=True)
            handle=sample.KERNEL.OpenProcess(0x400|0x10,False,child.pid)
            while child.poll() is None:
                if handle:
                    paths,error=sample.modules(handle);observed.update({p.lower():p for p in paths})
                    if error:errors[str(error)]=errors.get(str(error),0)+1
                time.sleep(.01)
            if handle:sample.KERNEL.CloseHandle(handle)
        result={'state':'TERMINAL','pid':child.pid,'start_utc':started,'end_utc':now(),'exit_code':child.returncode,
            'elapsed_seconds':time.monotonic()-tick,'observed_modules':sorted(observed.values()),'module_sample_errors':errors,
            'module_scope':'10ms finite live snapshots, not complete loader-event tracing'}
        save(out/'process.json',result)
        actual=[]
        for path in observed.values():
            p=Path(path)
            if p.suffix.lower()=='.dll' and p.name.lower().startswith(('hyle_','ggml')):
                assert p.parent.resolve()==(B/'bin').resolve(),str(p)
                actual.append(pin(p))
        save(out/'runtime-pins.json',{'image':pin(image),'actual_observed_Hyle_GGML_DLLs':actual,'module_sample_errors':errors,'scope':result['module_scope']})
        if child.returncode:
            print(json.dumps({'case':case['name'],'status':'FAIL_STOP','exit_code':child.returncode}),flush=True)
            raise SystemExit(child.returncode)
        report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'));assert report['status']=='PASS',case['name']
        save(out/'report.json',report);summaries.append({'case':case['name'],'exit_code':0,'report':pin(out/'report.json'),'runtime':pin(out/'runtime-pins.json')})
        print(json.dumps({'case':case['name'],'status':'PASS','elapsed_seconds':result['elapsed_seconds'],'observed_DLLs':len(actual)}),flush=True)
    save(W/'tiny-summary.json',{'status':'PASS_SEVEN_SERIAL','native_processes':len(summaries),'cases':summaries,'downloads':0,
        'automatic_retries':0,'prior_failed_native_attempts':2,'total_tiny_native_processes':9,
        'prior_failures':[pin(W/'runs/packet-cpu'/f'attempt{i}'/'process.json') for i in (1,2)],'performance_claim':False})
def execute(stage,command,extra=None):
    attempt=sys.argv[2] if len(sys.argv)>2 else 'attempt1'
    assert attempt.startswith('attempt') and attempt[7:].isdigit()
    out=W/stage/attempt;out.mkdir(parents=True,exist_ok=False)
    save(out/'command.json',{'command':command,'cwd':str(B),'environment':pin(R/'.scratch/inference-default-product-build-20261031/environment.json'),'TEMP_TMP':str(W/'tmp')})
    started=now();tick=time.monotonic()
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=B,env=environment(),stdout=subprocess.PIPE if stage=='build' else stdout,stderr=stderr)
        save(out/'process.json',{'state':'RUNNING','pid':child.pid,'start_utc':started})
        print(json.dumps({'stage':stage,'state':'RUNNING','pid':child.pid}),flush=True)
        if stage=='build':
            for raw in child.stdout:
                stdout.write(raw);stdout.flush()
                line=raw.decode(errors='replace')
                if 'Building ' in line and ('CUDA' in line or 'CXX object src' in line or 'C object src' in line):
                    subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True)
                    print(json.dumps({'stage':stage,'unexpected_SDK_build_line':line.strip()}),flush=True)
        code=child.wait()
    result={'state':'TERMINAL','pid':child.pid,'start_utc':started,'end_utc':now(),'exit_code':code,'elapsed_seconds':time.monotonic()-tick}
    if extra and code==0:result.update(extra())
    save(out/'process.json',result);print(json.dumps({'stage':stage,**result}),flush=True)
    if code:raise SystemExit(code)
    return out,result
def main():
    command=read(P/'commands.json');stage=sys.argv[1];check_product()
    if stage=='verify-globs':
        cmake=command['host_fixture_link'][0]
        execute('verify-globs',[cmake,'-P',str(B/'CMakeFiles/VerifyGlobs.cmake')])
    elif stage in ('dry-run','dry-run-after-globs'):
        args=command['prebuild_dry_run_command']
        if stage=='dry-run-after-globs':args=[*args,'-d','norebuild']
        out,_=execute(stage,args)
        lines=[x for x in (out/'stdout.log').read_text(errors='replace').splitlines() if x.startswith('[')]
        cxx=[x for x in lines if 'Building CXX object' in x];links=[x for x in lines if 'Linking CXX executable bin\\hyle.exe' in x]
        expected=['models\\qwen35\\main.cc.obj','models\\qwen35\\phase_preparation.cc.obj','models\\qwen35\\auxiliary_programs.cc.obj']
        assert len(cxx)==3 and len(links)==1 and len(lines)==4,(lines,expected)
        assert all(any(name in x for x in cxx) for name in expected)
        save(out/'summary.json',{'status':'PASS_ONLY_THREE_APP_CXX_ONE_LINK','commands':lines,'SDK_CXX':0,'NVCC':0})
    elif stage=='build':
        metadata=read(P/'normal-ninja-metadata.json')
        affected=[Path(x['object']['path']).name for x in metadata['objects'] if x['phase_dependency_hits']]
        assert affected==['main.cc.obj','phase_preparation.cc.obj','auxiliary_programs.cc.obj']
        attempt=sys.argv[2] if len(sys.argv)>2 else 'attempt1'
        save(W/('build-admission-'+attempt+'.json'),{'status':'AUTHORIZED_ACTUAL_DEPS_AND_COMMANDS_AFTER_PHONY_GLOB_DRY_RUN',
            'normal_metadata':pin(P/'normal-ninja-metadata.json'),'verify_globs':pin(W/'verify-globs/attempt1/process.json'),
            'first_dry_run':pin(W/'dry-run/attempt1/process.json'),
            'unsupported_debug_flag_attempt':pin(W/'dry-run-after-globs/attempt1/process.json'),
            'affected_app_objects':affected,'expected_SDK_CXX':0,'expected_NVCC':0,
            'note':'Root explicitly authorized actual deps/commands admission if Ninja dry-run only predicts the phony manifest check; this Ninja has no norebuild debug switch. No repeated dry-run or cache reconfiguration.'})
        before=read(P/'normal-ninja-metadata.json')['objects'];libs=[]
        for token in command['host_fixture_link']:
            p=Path(token)
            if p.is_absolute() and p.suffix.lower()=='.lib' and p.is_file():libs.append(pin(p))
        # Keep this input receipt outside execute()'s exclusive attempt folder.
        save(W/('prebuild-inputs-'+attempt+'.json'),{'product_freeze':pin(W/'source-freeze.json'),'objects':[x['object'] for x in before],'import_libraries':libs})
        out,result=execute('build',command['incremental_product_command'],lambda:{'image':pin(B/'bin/hyle.exe')})
        changed=[];retained=[]
        for row in before:
            actual=pin(row['object']['path']);(retained if actual==row['object'] else changed).append(actual)
        assert len(changed)==3 and len(retained)==6,(len(changed),len(retained))
        for p in libs:assert pin(p['path'])==p,p['path']
        check_product()
        save(out/'receipt.json',{'status':'PASS_NORMAL_SHARED_INCREMENTAL','process':pin(out/'process.json'),'image':result['image'],'changed_app_objects':changed,'retained_app_objects':retained,'import_libraries_unchanged':len(libs),'SDK_CXX':0,'NVCC':0})
    elif stage in ('host-compile','host-link'):
        receipt=max((W/'build').glob('attempt*/receipt.json'),key=lambda p:int(p.parent.name[7:]))
        assert read(receipt)['status']=='PASS_NORMAL_SHARED_INCREMENTAL'
        check_tests()
        if stage=='host-compile':
            attempt=sys.argv[2] if len(sys.argv)>2 else 'attempt1'
            original_folder=Path(command['host_fixture_image']).parent
            folder=original_folder.parent/attempt;folder.mkdir(parents=True,exist_ok=True)
            unit=folder/'qwen_host_image_test.cc.obj'
            cxx=[x.replace(str(original_folder),str(folder)) for x in command['host_fixture_cxx']]
            if int(attempt[7:])>=2:cxx.insert(cxx.index('/showIncludes'),'/bigobj')
            execute(stage,cxx,lambda:{'object':pin(unit),'actual_dependencies':pin(folder/'dependencies.json'),
                'compile_delta':'Root-authorized /bigobj for this large test TU; same shared codegen/MD/Release otherwise.' if int(attempt[7:])>=2 else 'None'})
        else:
            source=max((W/'host-compile').glob('attempt*/process.json'),key=lambda p:int(p.parent.name[7:]))
            compiled=read(source);assert compiled['exit_code']==0
            assert pin(compiled['object']['path'])==compiled['object']
            folder=Path(compiled['object']['path']).parent;original_folder=Path(command['host_fixture_image']).parent
            link=[x.replace(str(original_folder),str(folder)) for x in command['host_fixture_link']]
            library_pins={x['path']:x for x in read(W/'prebuild-inputs-attempt2.json')['import_libraries']}
            for token in link:
                p=Path(token)
                if p.is_absolute() and p.suffix.lower() in ('.obj','.lib') and p.is_file():
                    if p.suffix.lower()=='.obj':assert p.is_relative_to(B) or p==Path(compiled['object']['path'])
                    else:assert pin(p)==library_pins[str(p)],str(p)
            execute(stage,link,lambda:{'image':pin(folder/'qwen-host-image.exe'),'compiled':pin(source)})
    elif stage=='tiny':native_cases()
    else:raise RuntimeError('Unknown action')
if __name__=='__main__':main()
