from pathlib import Path
p=Path('.scratch/inference-captured-graph-copy-20261031/cpu-tests-addition.cc')
s=p.read_text(encoding='utf-8-sig')
s=s.replace('std::array<std::size_t, 2> copy_steps{};', 'std::array<std::uint32_t, 2> copy_steps{};').replace('copy_steps[copies++] = i;', 'copy_steps[copies++] = static_cast<std::uint32_t>(i);')
s=s.replace('EXPECT_TRUE(different_queue.IsUnavailable()) << different_queue.message();','EXPECT_TRUE(different_queue.IsInvalidArgument()) << different_queue.message();')
p.write_text(s,encoding='utf-8')
