from pathlib import Path
import json,hashlib,subprocess
R=Path.cwd();B=R/'.scratch/inference-captured-graph-copy-20261031';p=R/'src/graph/resources.cc';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='18a523e4a6683d63ac47c2f168f472af9bae64c7d131886fbc37c754d1ac633b'
old=B/'superseded-13-line-candidate';old.mkdir(exist_ok=True)
for rel in ['source-freeze.json','graph-copy.patch']:(old/rel).write_bytes((B/rel).read_bytes())
(old/'resources.cc').write_bytes(raw)
needle=b'''        if (idle && !preserves && arguments.stable_binding_identity && !arguments.native_inputs &&\n            !step.region.valid() && step.kind == PlanStepKind::kCopy) {\n          // Only read authority is withdrawn. Plain Graph Copy records keep\n          // their full source/destination key; they own no private arguments.\n          preserves = true;\n        }\n'''
assert raw.count(needle)==1
new=raw.replace(needle,b'',1);assert new==(B/'baseline/src/graph/resources.cc').read_bytes();p.write_bytes(new)
r=subprocess.run(['git','diff','--binary','--','src/graph/executable.cc'],capture_output=True);assert r.returncode==0;(B/'final-graph-copy.patch').write_bytes(r.stdout)
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
f={'status':'FINAL_EXECUTABLE7_FROZEN_RESOURCES_BASELINE_RESTORED_PENDING_REBUILD','source_pins':[pin(R/'src/graph/executable.cc'),pin(p)],'patch':pin(B/'final-graph-copy.patch'),'product_API_layout_changes':0,'executable_insertions':7,'resources_changes':0,'tests_pins':json.loads((B/'tests-applied-receipt.json').read_text())['source_pins'],'reason':str(B/'resources-branch-reachability.md'),'previous_13_line_freeze_preserved':str(old),'builds_after_resources_rollback':0,'native_after_rollback':0}
(B/'final-source-freeze.json').write_text(json.dumps(f,indent=2)+'\n');r=subprocess.run(['git','diff','--check','--','src/graph/executable.cc','src/graph/resources.cc','tests/graph/region_provider_test.cc','tests/graph/output_source_cuda_test.cc'],capture_output=True);assert r.returncode==0,r.stderr
print(json.dumps({'status':f['status'],'resources':f['source_pins'][1],'patch':f['patch']}))
