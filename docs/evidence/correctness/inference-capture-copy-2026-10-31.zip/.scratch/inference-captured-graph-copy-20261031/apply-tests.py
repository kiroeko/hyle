from pathlib import Path
import hashlib,json,subprocess
R=Path.cwd();B=R/'.scratch/inference-captured-graph-copy-20261031';f=json.loads((B/'tests-source-freeze.json').read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for x in f['tests']:
 dst=R/x['relative']; assert pin(dst)['sha256']==x['base']['sha256'];base=B/'baseline'/x['relative'];base.parent.mkdir(parents=True,exist_ok=True);base.write_bytes(dst.read_bytes())
for x in f['tests']:
 dst=R/x['relative'];dst.write_bytes((B/'candidate'/x['relative']).read_bytes());assert pin(dst)['sha256']==x['candidate']['sha256']
r=subprocess.run(['git','apply','--reverse','--check',str(B/'capture-copy-tests.patch')],capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run(['git','diff','--check','--','tests/graph/region_provider_test.cc','tests/graph/output_source_cuda_test.cc'],capture_output=True,text=True);assert r.returncode==0,r.stderr
out={'status':'TWO_TEST_FILES_APPLIED_FROZEN_NO_BUILD','source_pins':[pin(R/x['relative']) for x in f['tests']],'patch':pin(B/'capture-copy-tests.patch'),'reverse_apply_check':True,'diff_check':True,'CXX':0,'link':0,'native':0,'extent_fix':'Full row9 backing initialized with 9 F32 values; from_initialized_storage preserves 36B and explicit 32/36 asserts prove actual changed extent; old 3015 draft saved.'}
(B/'tests-applied-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'patch_sha256':out['patch']['sha256'],'source_pins':out['source_pins']}))
