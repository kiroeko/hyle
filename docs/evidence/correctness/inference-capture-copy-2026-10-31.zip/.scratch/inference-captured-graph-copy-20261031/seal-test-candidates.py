from pathlib import Path
import hashlib,json,difflib,subprocess
R=Path.cwd(); B=R/'.scratch/inference-captured-graph-copy-20261031'
pins=[]
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(rel,s):
 p=B/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8'));pins.append({'relative':rel,'base':pin(R/rel),'candidate':pin(p)});return p
rel='tests/graph/region_provider_test.cc';raw=(R/rel).read_bytes(); nl='\r\n' if b'\r\n' in raw else '\n';s=raw.decode();a=(B/'cpu-tests-addition.cc').read_text(encoding='utf-8-sig').replace('\n',nl)
anchor='TEST(GraphRegions, StablePrivateCaptureVariantsReuseBothBoundPortsAfterPreparation) {'
assert s.count(anchor)==1
p=save(rel,s.replace(anchor,a+nl+anchor))
assert p.read_bytes().replace((a+nl).encode(),b'',1)==raw
rel='tests/graph/output_source_cuda_test.cc';raw=(R/rel).read_bytes();nl='\r\n' if b'\r\n' in raw else '\n';s=raw.decode(); start=s.index('TEST(GraphOutputSourceCuda, HybridPendingTokenAndStoreReuseOnlyExistingRanges) {');end=s.index('// Raw exactly representable finite values',start);body=s[start:end]; original=body
old='  const std::array domains{g::StorageDomain{.resource = storage.ref(), .owner = storage}};'
new='''  // A second real resource on this same CUDA Context forces compiler-owned
  // physical transfers around the selected mathematical region. Source
  // state/Store identity remains on the original storage and Queue.
  auto replica_memory = c::cuda::MemoryResource::create(context,
      c::cuda::MemoryKind::kDevice).value();
  auto replica_storage = c::StorageOwner::adopt(context, std::move(replica_memory)).value();
  const std::array domains{
      g::StorageDomain{.resource = storage.ref(), .owner = storage},
      g::StorageDomain{.resource = replica_storage.ref(), .owner = replica_storage}};
  const std::array placements{
      g::NodePlacement{copy0, g::ExecutionTargetId{0}, g::PlacementStrength::kRequired,
                       g::StorageDomainId{1}},
      g::NodePlacement{copy1, g::ExecutionTargetId{0}, g::PlacementStrength::kRequired,
                       g::StorageDomainId{1}}};
  const std::array external{
      g::ExternalResourceContract{copied_token, g::StorageDomainId{0}}};'''.replace('\n',nl)
assert body.count(old)==1;body=body.replace(old,new)
old='      {.storage_domains = domains, .targets = targets}, {}, adapters);'
new='      {.storage_domains = domains, .targets = targets},\n      {.node_placements = placements, .external_resources = external}, adapters);'.replace('\n',nl)
assert body.count(old)==1;body=body.replace(old,new)
old='  bool captured_math = false, prepared_gap = false;'
new='  bool captured_math = false, prepared_gap = false, copied_source_input = false;\n  std::size_t physical_copies = 0;'.replace('\n',nl)
assert body.count(old)==1;body=body.replace(old,new)
old='    bool has_copy = false, has_store = false;'
new='''    if (step.kind == g::CompileStepKind::kCopy) {
      ++physical_copies;
      ASSERT_EQ(step.input_count, 1u);
      ASSERT_EQ(step.output_count, 1u);
      const auto source_instance = consumer_plan->report.step_input(i, 0).value();
      const auto source_value = consumer_plan->report.physical_value(source_instance).value();
      copied_source_input |= source_value.value == token_input && source_value.external_input;
    }
    bool has_copy = false, has_store = false;'''.replace('\n',nl)
assert body.count(old)==1;body=body.replace(old,new)
old='  ASSERT_TRUE(captured_math); ASSERT_TRUE(prepared_gap);'
new='''  ASSERT_TRUE(captured_math); ASSERT_TRUE(prepared_gap);
  ASSERT_GT(physical_copies, 0u);
  ASSERT_TRUE(copied_source_input); // Graph kCopy, not the provider Concat region.
  EXPECT_GT(consumer_plan->report.copy_bytes(), 0u);'''.replace('\n',nl)
assert body.count(old)==1;body=body.replace(old,new)
old='  const auto restored = gd::ReplayAccess::prepare_reuse(consumer, queues);'
new='''  const auto same_tuple = gd::ReplayAccess::can_reuse_capture(consumer,
      std::array{gd::ReplayInputBinding{token_input, token_view}});
  ASSERT_TRUE(same_tuple) << same_tuple.error().message();
  ASSERT_TRUE(*same_tuple);
  const auto restored = gd::ReplayAccess::prepare_reuse(consumer, queues);'''.replace('\n',nl)
assert body.count(old)==1;body=body.replace(old,new)
# Only existing Source readiness and lifetime assertions are strengthened here.
# Direct projection-with-Copy retention is not falsely claimed: token OutputSource
# is Caller-scoped; projected Store Gather footprint remains unchanged.
new_s=s[:start]+body+s[end:];p=save(rel,new_s)
assert new_s[:start]==s[:start] and new_s[start+len(body):]==s[end:]
patch=''
for pair in pins:
 rel=pair['relative'];a=(R/rel).read_bytes().decode();b=(B/'candidate'/rel).read_bytes().decode()
 patch+=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
(B/'capture-copy-tests.patch').write_bytes(patch.encode())
res=subprocess.run(['git','apply','--check',str(B/'capture-copy-tests.patch')],cwd=R,capture_output=True,text=True)
assert res.returncode==0,res.stderr
receipt={'status':'SCRATCH_ONLY_UNBUILT','tests':pins,'patch':pin(B/'capture-copy-tests.patch'),'git_apply_check':True,'new_CPU_tests':2,'CUDA_existing_test_strengthened':1,'source_no_product_edits':True,'builds':0,'native':0,'CPU_mock_scope':'Full physical tuple, Queue and invalidation controls; mock captured launch does not replay Copy bytes.','CUDA_scope':'Existing actual pending OutputSource+StoreSource, both real compiled Graph Copy and provider math, original math/guard/lifetime assertions unchanged. Projected Store footprint is not transferred.','uncovered':'Direct qualified ready/projected Source withdrawal on a Copy physical reader is not claimed by this fixture.'}
(B/'tests-source-freeze.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'patch':receipt['patch'],'tests':[{'relative':x['relative'],'bytes':x['candidate']['bytes'],'sha256':x['candidate']['sha256']} for x in pins],'apply_check':True}))
