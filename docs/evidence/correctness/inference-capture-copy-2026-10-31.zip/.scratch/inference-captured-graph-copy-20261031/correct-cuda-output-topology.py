from pathlib import Path
import hashlib,json,difflib,subprocess
R=Path.cwd();B=R/'.scratch/inference-captured-graph-copy-20261031';H=B/'superseded-cuda-native-attempt1';H.mkdir(exist_ok=True)
for rel in ['tests-source-freeze.json','tests-applied-receipt.json','capture-copy-tests.patch','validation-plan.json','final-source-freeze.json','candidate/tests/graph/output_source_cuda_test.cc']:
 p=B/rel;q=H/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
p=R/'tests/graph/output_source_cuda_test.cc';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='51fd30c46d4ba04b7dafc56566543c7f9df66980368eb92eb75d0d0f32eb65a5';s=raw.decode();nl='\r\n' if b'\r\n' in raw else '\n';s=s.replace('#include <span>'+nl,'#include <span>'+nl+'#include <string>'+nl,1)
s=s.replace('bool captured_math = false, prepared_gap = false, copied_source_input = false;', 'bool captured_math = false, prepared_gap = false, copied_result_output = false;')
old='''      const auto source_instance = consumer_plan->report.step_input(i, 0).value();
      const auto source_value = consumer_plan->report.physical_value(source_instance).value();
      copied_source_input |= source_value.value == token_input && source_value.external_input;'''.replace('\n',nl)
new='''      EXPECT_EQ(step.node_count, 0u);
      EXPECT_FALSE(step.provider.valid()); // Plain shared-Queue Graph Copy.
      const auto source_instance = consumer_plan->report.step_input(i, 0).value();
      const auto destination_instance = consumer_plan->report.step_output(i, 0).value();
      const auto source_value = consumer_plan->report.physical_value(source_instance).value();
      const auto destination_value = consumer_plan->report.physical_value(destination_instance).value();
      RecordProperty("physical_copy_" + std::to_string(i),
          (::testing::Message() << "src_instance=" << source_instance
           << " src_value=" << source_value.value.ordinal()
           << " src_storage=" << source_value.storage.ordinal()
           << " src_external_input=" << source_value.external_input
           << " src_external_output=" << source_value.external_output
           << " dst_instance=" << destination_instance
           << " dst_value=" << destination_value.value.ordinal()
           << " dst_storage=" << destination_value.storage.ordinal()
           << " dst_external_input=" << destination_value.external_input
           << " dst_external_output=" << destination_value.external_output).GetString());
      copied_result_output |= source_value.value == copied_token &&
          destination_value.value == copied_token && !source_value.external_input &&
          !source_value.external_output && destination_value.external_output &&
          source_value.storage == g::StorageDomainId{1} &&
          destination_value.storage == g::StorageDomainId{0};'''.replace('\n',nl)
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('ASSERT_TRUE(copied_source_input); // Graph kCopy, not the provider Concat region.', 'ASSERT_TRUE(copied_result_output); // Internal math result to the original external writer.')
after=s.encode();p.write_bytes(after);(B/'candidate/tests/graph/output_source_cuda_test.cc').write_bytes(after)
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
f=json.loads((B/'tests-source-freeze.json').read_text());f['tests'][1]['candidate']=pin(B/'candidate/tests/graph/output_source_cuda_test.cc');patch=''
for x in f['tests']:
 rel=x['relative'];a=(B/'baseline'/rel).read_bytes().decode();b=(R/rel).read_bytes().decode();patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(B/'capture-copy-tests.patch').write_bytes(patch.encode());f['patch']=pin(B/'capture-copy-tests.patch');f['status']='APPLIED_FROZEN_CUDA_OUTPUT_COPY_TOPOLOGY_CORRECTION';f['CUDA_scope']='Actual Source->native Concat->plain Graph output Copy->original external writer plus all original Store/permission/retirement/numeric assertions. GPU direct Source input Copy is not claimed; CPU covers input and output tuple keys.';(B/'tests-source-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
a=json.loads((B/'tests-applied-receipt.json').read_text());a['source_pins'][1]=pin(p);a['patch']=f['patch'];a['status']=f['status'];(B/'tests-applied-receipt.json').write_text(json.dumps(a,indent=2)+'\n');f=json.loads((B/'final-source-freeze.json').read_text());f['tests_pins']=a['source_pins'];(B/'final-source-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
v=json.loads((B/'validation-plan.json').read_text());row=v['cases'][1];row['source']=a['source_pins'][1];old=str(B/'formal-tests/cuda/attempt1');new=str(B/'formal-tests/cuda/attempt2');Path(new).mkdir(parents=True,exist_ok=True);row['compile']=[x.replace(old,new) for x in row['compile']];row['link']=[x.replace(old,new) for x in row['link']];row['object']=row['object'].replace(old,new);row['image']=row['image'].replace(old,new);(B/'validation-plan.json').write_text(json.dumps(v,indent=2)+'\n')
r=subprocess.run(['git','diff','--check','--','tests/graph/output_source_cuda_test.cc'],capture_output=True);assert r.returncode==0
(B/'cuda-output-copy-correction.patch').write_bytes(''.join(difflib.unified_diff(raw.decode().splitlines(True),s.splitlines(True),fromfile='a/tests/graph/output_source_cuda_test.cc',tofile='b/tests/graph/output_source_cuda_test.cc')).encode())
print(json.dumps({'source':a['source_pins'][1],'patch':a['patch'],'correction':pin(B/'cuda-output-copy-correction.patch')}))
