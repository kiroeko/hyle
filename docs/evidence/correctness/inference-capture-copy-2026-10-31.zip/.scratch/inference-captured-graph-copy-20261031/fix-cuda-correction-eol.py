from pathlib import Path
p=Path('.scratch/inference-captured-graph-copy-20261031/correct-cuda-output-topology.py');s=p.read_text();s=s.replace("nl='\\r\\n';s=s.replace", "nl='\\r\\n' if b'\\r\\n' in raw else '\\n';s=s.replace");p.write_text(s)
