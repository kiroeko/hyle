"""Two existing normal-product commands; finite correctness, no peer window."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/build-compute-v2-dev'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def non_time(value):
    if isinstance(value, dict):
        return {k: non_time(v) for k, v in value.items()
                if not k.endswith(('_seconds', '_tokens_per_second'))}
    if isinstance(value, list):
        return [non_time(v) for v in value]
    return value


def delta(a, b, path='$'):
    if isinstance(a, dict) and isinstance(b, dict):
        return [d for k in sorted(a.keys() | b.keys()) for d in delta(a.get(k), b.get(k), path + '.' + k)]
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [{'path': path, 'old_length': len(a), 'new_length': len(b)}]
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in delta(x, y, path + f'[{i}]')]
    return [] if a == b else [{'path': path, 'old': a, 'new': b}]


def main():
    resume = sys.argv[1:] == ['--continue-mtp']
    assert not sys.argv[1:] or resume
    spec = importlib.util.spec_from_file_location('normal_copy_smoke_observer',
        R / '.scratch/inference-default-product-build-20261031/inspect-smoke.py')
    observer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(observer)
    observer.HERE = W / 'normal-product-smoke'
    observer.IMAGE = B / 'bin/hyle.exe'
    assert observer.identity(observer.IMAGE)['sha256'] == 'aff519dde6174b0fdd0dd74aab269cf49c1d0f57218a4c95af6c5398a7b9a407'
    window = R / '.scratch/inference-default-product-window-20261031/peer-window'
    original_plan = read(window / 'two-turn-timing-plan.json')
    selected = [next(c for c in original_plan['commands'] if c['arm'] == arm)
                for arm in ('hyle_auto', 'hyle_mtp')]
    env = dict(os.environ)
    env.update(read(R / '.scratch/inference-default-product-build-20261031/environment.json'))
    for key in ('CL', '_CL_', 'CUDAARCHS', 'TORCH_INSTALL_PREFIX', 'CMAKE_PREFIX_PATH'):
        env.pop(key, None)
    env['PATH'] = str(B / 'bin') + os.pathsep + env['PATH']
    source_pins = [observer.identity(R / p) for p in ('src/graph/executable.cc', 'src/graph/resources.cc')]
    graph_dll = observer.identity(B / 'bin/hyle_graph.dll')
    if resume:
        previous_plan = read(observer.HERE / 'plan.json')
        assert previous_plan['cases'] == selected
        assert previous_plan['source_pins'] == source_pins and previous_plan['graph_dll'] == graph_dll
    else:
        observer.HERE.mkdir(parents=True, exist_ok=False)
        save(observer.HERE / 'plan.json', {'cases': selected, 'source_pins': source_pins,
            'graph_dll': graph_dll, 'performance_claim': False, 'model_downloads': 0,
            'scope': 'Two finite current-product correctness runs; compared to existing normal default reports. No trace or peer run.'})
    cases = []
    for entry in selected:
        command = list(entry['command'])
        command[0] = str(observer.IMAGE)
        if resume and entry['arm'] == 'hyle_auto':
            folder = observer.HERE / 'checks/hyle_auto/attempt1'
            process = read(folder / 'process.json')
            assert process['state'] == 'TERMINAL' and process['exit_code'] == 0
            assert read(folder / 'command.json')['command'] == command
            report = read(folder / 'report.json')
        else:
            folder, process = observer.execute(entry['arm'], command, env)
            report = read(folder / 'stdout.log')
            save(folder / 'report.json', report)
        old = read(Path(entry['folder']) / 'stdout.log')
        differences = delta(non_time(old), non_time(report))
        save(folder / 'raw-non-time-differences.json', differences)
        loaded = [Path(p) for p in process['observed_modules']
                  if Path(p).name.lower().startswith(('hyle_', 'ggml'))]
        assert all(p.parent.resolve() == (B / 'bin').resolve() for p in loaded)
        assert (B / 'bin/hyle_graph.dll').resolve() in {p.resolve() for p in loaded}
        runtime = [observer.identity(p) for p in loaded]
        save(folder / 'runtime-pins.json', runtime)
        assert observer.identity(B / 'bin/hyle_graph.dll') == graph_dll
        assert report['generated_tokens'] == 128
        assert all(report[k] == 0 for k in ('draft_vocabulary_requested_rows', 'draft_vocabulary_rows',
            'draft_vocabulary_weight_bytes', 'draft_vocabulary_map_bytes'))
        # Preserve every real difference instead of hiding new capture/relay work.
        assert not differences, 'Actual non-time report changed; inspect preserved differences before claiming PASS'
        cases.append({'arm': entry['arm'], 'report': observer.identity(folder / 'report.json'),
            'process': observer.identity(folder / 'process.json'), 'non_time_differences': 0,
            'generated_tokens': 128, 'live_module_sampling_errors': process['module_sample_errors'],
            'reused_existing_successful_native': resume and entry['arm'] == 'hyle_auto'})
    assert [observer.identity(R / p) for p in ('src/graph/executable.cc', 'src/graph/resources.cc')] == source_pins
    save(observer.HERE / 'summary.json', {'status': 'PASS_TWO_FINITE_NORMAL_PRODUCT_RUNS',
        'cases': cases, 'source_pins': source_pins, 'graph_dll': graph_dll,
        'performance_claim': False, 'full_2B_Session_bytes_exported': False,
        'wrapper_history': 'Initial comparison used the old normalized schema and failed after successful ordinary native; raw-to-raw comparison corrected offline, ordinary was not rerun.',
        'limits': 'Finite module snapshots are not complete loader-event tracing. Original CLI reports omit full logical KV/carry/prior/raw RNG blobs.'})
    print(json.dumps({'status': 'PASS', 'native_runs': 2, 'non_time_differences': 0}), flush=True)


if __name__ == '__main__':
    main()
