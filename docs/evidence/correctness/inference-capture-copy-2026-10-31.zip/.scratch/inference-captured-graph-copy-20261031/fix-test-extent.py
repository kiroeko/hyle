from pathlib import Path
import json,hashlib
B=Path('.scratch/inference-captured-graph-copy-20261031'); old=B/'superseded-tests-3015';old.mkdir(exist_ok=True)
for rel in ['cpu-tests-addition.cc','capture-copy-tests.patch','tests-source-freeze.json','test-build-plan.json','candidate/tests/graph/region_provider_test.cc','candidate/tests/graph/output_source_cuda_test.cc']:
 p=B/rel;q=old/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
p=B/'cpu-tests-addition.cc';s=p.read_text(encoding='utf-8')
s=s.replace('  auto other_input = make_tensor(row(8));\n','  auto other_input = make_tensor(row(8));\n  constexpr std::array<float, 9> initialized{1, 2, 3, 4, 5, 6, 7, 8, 9};\n  write(input_backing, initialized); // Include the entire extra storage tail.\n')
s=s.replace('  const auto larger_input = TensorView::create(row(8), input_backing.buffer.view()).value();','  const auto larger_input = ConstTensorView::from_initialized_storage(\n      row(8), input_backing.buffer.view().as_const()).value();\n  ASSERT_EQ(input.storage().size(), 8u * sizeof(float));\n  ASSERT_EQ(larger_input.storage().size(), 9u * sizeof(float));')
s=s.replace('shifted_input.as_const(), larger_input.as_const(),','shifted_input.as_const(), larger_input,')
p.write_text(s,encoding='utf-8')
