import pathlib,json,hashlib
R=pathlib.Path.cwd();B=R/'.scratch/inference-captured-graph-copy-20261031'; D=R/'.scratch/inference-cross-turn-capture-review-20261031/buffered/diagnostic-plan.json'
p=json.loads(D.read_text()); out={'status':'PREPARED_ONLY_NOT_AUTHORIZED_TO_EXECUTE','compile_count':2,'link_count':2,'SDK_CXX':0,'NVCC':0,'normal_cache_reconfigure':False,'SDK_copies':0,'native_authorized':0,'environment':p['environment'],'cases':[]}
base=p['compile']; cl=base[0]; body=[]
i=1
while i<len(base):
 x=base[i]
 if x=='/sourceDependencies':i+=2;continue
 if x.startswith(('/Fo','/Fd')) or x in ['/showIncludes','/FS','-c'] or x.endswith('diagnostic-probe.cc'):i+=1;continue
 if 'engine\\models\\qwen35' not in x:body.append(x)
 i+=1
body += ['/WX','/IC:'+str(R)[2:]+'\\tests\\graph','/I'+str(R/'src/compute_provider_ggml_cuda'),'/external:IC:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include']
# Reuse normal shared compiler/CRT/macros; never import any HYLE_STATIC recipe.
assert not any('STATIC' in x for x in body)
libs=[x for x in p['link'] if x.lower().endswith('.lib') and not x.startswith(('/implib:','/out:'))]
libs += [str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
for tag,rel in [('cpu','tests/graph/region_provider_test.cc'),('cuda','tests/graph/output_source_cuda_test.cc')]:
 d=B/'test-build'/tag/'attempt1';unit=d/'unit.obj'; exe=d/(tag+'-copy-capture-test.exe'); src=B/'candidate'/rel
 compile=[cl,*body,'/Gy','/c',str(src),'/sourceDependencies',str(d/'dependencies.json'),'/Fo'+str(unit),'/Fd'+str(d/'compile.pdb')]
 head=p['link'][:p['link'].index('--')+2]
 # Preserve the actual CMake vs_link_exe rule and native import libraries.
 head=[('--intdir='+str(d/'intdir')) if x.startswith('--intdir=') else x for x in head]
 link=[*head,'/nologo',str(unit),'/out:'+str(exe),'/implib:'+str(d/'test.lib'),'/pdb:'+str(d/'test.pdb'),'/version:0.0','/machine:x64','/INCREMENTAL:NO','/subsystem:console','/OPT:REF',*libs]
 out['cases'].append({'name':tag,'source':str(src),'compile':compile,'link':link,'filter':'GraphRegions.PlainGraphCopyCapture*' if tag=='cpu' else 'GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges'})
def pin(path):
 path=pathlib.Path(path);b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
out['input_pins']=[pin(x) for x in dict.fromkeys([cl,*libs,str(D),str(B/'tests-source-freeze.json'),str(R/'.scratch/build-compute-v2-dev/bin/hyle_graph.dll'),str(B/'control-runtime/hyle_graph.dll')]) if pathlib.Path(x).is_file()]
out['execution_limit']='Prepare only. Parent must authorize apply/CXX/link/native. Stage EXE alone in normal bin for current; old-red CPU EXE may relocate beside saved old Graph DLL with all other runtime normal-bin PATH; verify actual module path/hash, keep all attempts. Never copy SDK tree.'
(B/'test-build-plan.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'CXX':len(out['cases']),'link':len(out['cases']),'inputs':len(out['input_pins']),'SDK_CXX':0,'NVCC':0,'native':0,'static_macros':0}))
