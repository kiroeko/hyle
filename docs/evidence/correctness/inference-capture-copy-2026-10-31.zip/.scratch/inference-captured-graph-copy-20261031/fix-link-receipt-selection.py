from pathlib import Path
p=Path('.scratch/inference-captured-graph-copy-20261031/validate.py');s=p.read_text();s=s.replace("assert read(W/(tag+'-cxx')/'attempt1/process.json')['exit_code']==0", "receipt = W/(tag+'-cxx')/('attempt2' if tag=='cpu' else 'attempt1')/'process.json'\n  assert read(receipt)['exit_code']==0 and pin(row['object'])==read(receipt)['object']");p.write_text(s)
