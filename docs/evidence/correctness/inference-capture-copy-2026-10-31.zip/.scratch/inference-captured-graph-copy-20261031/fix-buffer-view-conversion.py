from pathlib import Path
import json,hashlib,difflib,subprocess
R=Path.cwd();B=R/'.scratch/inference-captured-graph-copy-20261031';H=B/'superseded-cpu-cxx-attempt1';H.mkdir(exist_ok=True)
for rel in ['tests-source-freeze.json','tests-applied-receipt.json','capture-copy-tests.patch','validation-plan.json','final-source-freeze.json','cpu-tests-addition.cc','candidate/tests/graph/region_provider_test.cc']:
 p=B/rel;q=H/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
p=R/'tests/graph/region_provider_test.cc';before=p.read_bytes();assert hashlib.sha256(before).hexdigest()=='6df139d734a2407e220d30a7c4886f22ca2e2bddebbf30fcae0346215aa652cf';needle=b'row(8), input_backing.buffer.view().as_const()).value();';assert before.count(needle)==1;after=before.replace(needle,b'row(8), input_backing.buffer.view()).value();',1);p.write_bytes(after);(B/'candidate/tests/graph/region_provider_test.cc').write_bytes(after)
p=B/'cpu-tests-addition.cc';s=p.read_text();assert 'input_backing.buffer.view().as_const()' in s;s=s.replace('input_backing.buffer.view().as_const()','input_backing.buffer.view()');p.write_text(s)
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
f=json.loads((B/'tests-source-freeze.json').read_text());f['tests'][0]['candidate']=pin(B/'candidate/tests/graph/region_provider_test.cc');patch=''
for x in f['tests']:
 rel=x['relative'];a=(B/'baseline'/rel).read_bytes().decode();b=(R/rel).read_bytes().decode();patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(B/'capture-copy-tests.patch').write_bytes(patch.encode());f['patch']=pin(B/'capture-copy-tests.patch');f['status']='APPLIED_FROZEN_ONE_BUFFER_VIEW_CONVERSION_FIX_PENDING_CXX';(B/'tests-source-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
a=json.loads((B/'tests-applied-receipt.json').read_text());a['source_pins'][0]=pin(R/'tests/graph/region_provider_test.cc');a['patch']=f['patch'];a['status']=f['status'];(B/'tests-applied-receipt.json').write_text(json.dumps(a,indent=2)+'\n')
f=json.loads((B/'final-source-freeze.json').read_text());f['tests_pins']=a['source_pins'];(B/'final-source-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
v=json.loads((B/'validation-plan.json').read_text());row=v['cases'][0];row['source']=a['source_pins'][0];old=str(B/'formal-tests/cpu/attempt1');new=str(B/'formal-tests/cpu/attempt2');Path(new).mkdir(parents=True,exist_ok=True);row['compile']=[x.replace(old,new) for x in row['compile']];row['link']=[x.replace(old,new) for x in row['link']];row['object']=row['object'].replace(old,new);row['image']=row['image'].replace(old,new);v['narrow_fixture_correction']='BufferView implicitly constructs ConstBufferView per buffer.h129; remove nonexistent as_const only. Attempt1 CXX preserved.';(B/'validation-plan.json').write_text(json.dumps(v,indent=2)+'\n')
r=subprocess.run(['git','diff','--check','--','tests/graph/region_provider_test.cc'],capture_output=True);assert r.returncode==0
print(json.dumps({'source':a['source_pins'][0],'patch':a['patch'],'change':'one nonexistent as_const removed; all assertions unchanged'}))
