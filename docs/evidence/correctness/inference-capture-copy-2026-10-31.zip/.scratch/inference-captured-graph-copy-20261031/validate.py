from pathlib import Path
import ctypes,importlib.util,json,re,sys,subprocess,time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;B=R/'.scratch/build-compute-v2-dev'
spec=importlib.util.spec_from_file_location('finite_shared_driver',R/'.scratch/inference-input-packet-20261031/run.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d);d.W=W;d.R=R;d.B=B
read,pin,save=d.read,d.pin,d.save
def args(command):
 n=ctypes.c_int();f=ctypes.windll.shell32.CommandLineToArgvW;f.argtypes=(ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int));f.restype=ctypes.POINTER(ctypes.c_wchar_p);p=f(command,ctypes.byref(n));assert p
 try:return[p[x] for x in range(n.value)]
 finally:ctypes.windll.kernel32.LocalFree(ctypes.cast(p,ctypes.c_void_p))
def check():
 for x in read(W/'final-source-freeze.json')['source_pins']+read(W/'tests-applied-receipt.json')['source_pins']:assert pin(x['path'])==x,x['path']
check();stage=sys.argv[1]
cache=(B/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',cache,re.M)[1]
if stage=='sdk-dryrun':
 out,res=d.execute(stage,[ninja,'-C',str(B),'-n','hyle_graph']);lines=[x for x in(out/'stdout.log').read_text(errors='replace').splitlines() if x.startswith('[')]
 cxx=[x for x in lines if 'Building CXX object' in x];links=[x for x in lines if 'Linking CXX shared library' in x]
 assert len(cxx)==1 and cxx[0].endswith('resources.cc.obj') and len(links)==1 and links[0].endswith('hyle_graph.dll'),lines
 assert not any('CUDA' in x or ('Building' in x and x not in cxx) for x in lines),lines
 save(out/'summary.json',{'status':'PASS_ONE_RESOURCES_CXX_ONE_GRAPH_DLL','actions':lines,'SDK_CXX':1,'NVCC':0})
elif stage=='sdk-build':
 assert read(W/'sdk-dryrun/attempt1/process.json')['exit_code']==0 # Parent explicitly authorized phony VerifyGlobs limitation; preserve first wrapper rejection.
 out=W/stage/'attempt1';out.mkdir(parents=True,exist_ok=False)
 command=[ninja,'-C',str(B),'-j','1','hyle_graph'];save(out/'command.json',{'command':command,'cwd':str(B),'manifest':pin(B/'build.ninja'),'allowed_CXX':'resources.cc only','allowed_link':'hyle_graph.dll only'})
 tick=time.monotonic();started=d.now()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  child=subprocess.Popen(command,cwd=B,env=d.environment(),stdout=subprocess.PIPE,stderr=stderr);save(out/'process.json',{'state':'RUNNING','pid':child.pid,'start_utc':started});print(json.dumps({'stage':stage,'state':'RUNNING','pid':child.pid}),flush=True)
  for raw in child.stdout:
   stdout.write(raw);stdout.flush();line=raw.decode(errors='replace')
   if ('Building ' in line and not ('Building CXX object' in line and 'resources.cc.obj' in line)) or ('Linking CXX' in line and 'hyle_graph.dll' not in line):
    subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);print(json.dumps({'unexpected_action':line.strip()}),flush=True)
  code=child.wait()
 res={'state':'TERMINAL','pid':child.pid,'start_utc':started,'end_utc':d.now(),'exit_code':code,'elapsed_seconds':time.monotonic()-tick}
 if code==0:res.update(Graph_DLL=pin(B/'bin/hyle_graph.dll'),Graph_import=pin(B/'bin/hyle_graph.lib'))
 save(out/'process.json',res);print(json.dumps({'stage':stage,**res}),flush=True);assert code==0,code
 lines=[x for x in(out/'stdout.log').read_text(errors='replace').splitlines() if x.startswith('[')]
 cxx=[x for x in lines if 'Building CXX object' in x];assert len(cxx)==1 and cxx[0].endswith('resources.cc.obj') and not any('Building CUDA' in x for x in lines),lines
 save(out/'summary.json',{'status':'PASS_RESOURCES_ROLLBACK_COMPILED','actions':lines,'SDK_CXX':1,'NVCC':0,'Graph_DLL':res['Graph_DLL'],'Graph_import':res['Graph_import']})
elif stage=='prepare-tests':
 assert read(W/'sdk-build/attempt1/process.json')['exit_code']==0
 formal=read(R/'.scratch/inference-kimi-component-boundary-20261031/validation/formal-graph-recipes/recipes.json');old=read(W/'normal-test-commands.json')
 cases=[]
 for tag,row,orig in zip(('cpu','cuda'),formal['translation_units'],old['cases']):
  assert pin(row['source']['path'])==row['source'];out=W/'formal-tests'/tag/'attempt1';out.mkdir(parents=True,exist_ok=True)
  comp=args(row['compile_command']);assert not any('STATIC' in x for x in comp)
  if tag=='cpu':assert any(x.startswith('-I') and Path(x[2:]).resolve()==(R/'src/graph').resolve() for x in comp),comp
  comp=[('/Fo'+str(out/'unit.obj')) if x.startswith('/Fo') else ('/Fd'+str(out/'compile.pdb')) if x.startswith('/Fd') else x for x in comp]
  libs=[x for x in orig['actual_link_argv'] if x.lower().endswith('.lib') and not x.startswith('/implib:')]
  newlibs=args('x '+next(x for x in row['canonical_link_block'] if x.startswith('  LINK_LIBRARIES = ')).split(' = ',1)[1])[1:]
  assert libs==newlibs,(libs,newlibs)
  link=[]
  for x in orig['actual_link_argv']:
   if x in orig['actual_link_objects']:
    if Path(row['source']['path']).name+'.obj' in x:link.append(str(out/'unit.obj'))
    continue
   if x.startswith('--intdir='):x='--intdir='+str(out/'intdir')
   elif x.startswith('/out:'):x='/out:'+str(out/(tag+'-copy-capture-test.exe'))
   elif x.startswith('/implib:'):x='/implib:'+str(out/'test.lib')
   elif x.startswith('/pdb:'):x='/pdb:'+str(out/'test.pdb')
   link.append(x)
  assert sum(x.endswith('.obj') for x in link)==1
  cases.append({'name':tag,'source':row['source'],'compile':comp,'link':link,'object':str(out/'unit.obj'),'image':str(out/(tag+'-copy-capture-test.exe')),'libraries':[pin(B/x) if not Path(x).is_absolute() else pin(x) for x in libs if (B/x).is_file() or Path(x).is_file()]})
 save(W/'validation-plan.json',{'status':'AUTHORIZED_FORMAL_TWO_TU_SHARED_COMMANDS','formal_recipe':pin(R/'.scratch/inference-kimi-component-boundary-20261031/validation/formal-graph-recipes/recipes.json'),'restored_manifest':pin(B/'build.ninja'),'gtest':formal['gtest_libraries'],'cases':cases,'narrowing':'Only scratch Fo/Fd/intdir/out/implib/pdb and exclusion of other test TU objects. Original formal defines/include/CRT/flags/import libraries unchanged.','CXX':2,'link':2,'new_SDK':0,'NVCC':0})
 print(json.dumps({'status':'PREPARED_FORMAL_TWO_TU','CXX':2,'link':2,'SDK':0,'NVCC':0}),flush=True)
elif stage in('cpu-cxx','cuda-cxx','cpu-link','cuda-link'):
 tag,action=stage.split('-');p=read(W/'validation-plan.json');row=next(x for x in p['cases'] if x['name']==tag);assert pin(row['source']['path'])==row['source']
 for x in row['libraries']:assert pin(x['path'])==x
 if action=='cxx':d.execute(stage,row['compile'],lambda:{'object':pin(row['object'])})
 else:
  receipt = W/(tag+'-cxx')/'attempt2'/'process.json'
  assert read(receipt)['exit_code']==0 and pin(row['object'])==read(receipt)['object']
  d.execute(stage,row['link'],lambda:{'image':pin(row['image'])})
else:raise RuntimeError('Unknown or unauthorized action')
