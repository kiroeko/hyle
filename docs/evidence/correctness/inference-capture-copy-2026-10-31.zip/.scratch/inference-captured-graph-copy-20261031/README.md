# Plain Graph Copy capture-key fix (unbuilt)

The buffered diagnostic of the original six-step policy reached a real capture range containing plain Graph `PlanStepKind::kCopy`: first negative step39, range1/99; prefill step40, range1/100. Successful replay preparation had cached qualification=true/private=false and no retained keys. Earlier live Operation/Region preservation callbacks passed. Both diagnostic failures remain failures; the first had intrusive stderr I/O and neither substitutes for an uninstrumented control.

The two product changes only recognize a plain Copy when `step.region` is invalid. Region-backed/provider copies retain their original first branch and callbacks. Graph submission derives the plain Copy's request exclusively from the exact input/output TensorViews and calls `TransferAccess::enqueue_prevalidated_copy` (`submission.cc:399`); it has no separate private invocation arguments.

- `qualify_capture_variants` can reserve the existing full port keys for this Copy. The existing native-input exclusion, allocation/budget errors and ordinary qualification machinery remain.
- `reusable_capture_tuple` permits the same plain kind, then still compares every source/destination description, resource, native allocation, offset and extent against the recorded variant. Existing stable-identity/native-input, original Queue, Captured/Hybrid and Source/lease checks remain.
- Ready/Source input withdrawal preserves only idle, stable-identity, non-native-input plain Copies. It still revokes replay readiness and the actual read authority; the borrowed recorded key owns no payload or permission. Close/failure/queue/native/configuration invalidation is unchanged.

No public API/layout, owner, executor, backend requirement, readiness counter, six-step policy, transfer fallback or search budget changes. This fixes the diagnosed obstruction; it does not complete cross-turn reuse. The V2 any-variant early Qwen gate remains unapplied because a miss uses destructive recovery and can discard the recording. Slot `preparation_uses>=2` plus real necessary facts remains a proposal pending actual supported per-range behavior.

The diagnostic classifier in the retained buffered binary mirrors the **old** kind whitelist. After this fix, its raw stored flags/key counts are useful, but its `reason4/kCopy` must not be represented as the new qualification result. The original numeric/Source/ledger assertions are unchanged.

Tests are being prepared against an actual compiled generated Copy (`CompileStepKind::kCopy`, not a provider `compute::Copy`) and existing capture/Source fixtures. No build or native run has validated the two product changes yet.
