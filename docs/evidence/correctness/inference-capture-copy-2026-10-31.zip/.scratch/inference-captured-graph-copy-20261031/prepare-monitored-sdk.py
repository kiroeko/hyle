from pathlib import Path
p=Path('.scratch/inference-captured-graph-copy-20261031/validate.py');s=p.read_text();s=s.replace('import ctypes,importlib.util,json,re,sys','import ctypes,importlib.util,json,re,sys,subprocess,time')
s=s.replace(" out,res=d.execute(stage,[ninja,'-C',str(B),'-j','1','hyle_graph'],lambda:{'Graph_DLL':pin(B/'bin/hyle_graph.dll'),'Graph_import':pin(B/'bin/hyle_graph.lib')})",''' out=W/stage/'attempt1';out.mkdir(parents=True,exist_ok=False)
 command=[ninja,'-C',str(B),'-j','1','hyle_graph'];save(out/'command.json',{'command':command,'cwd':str(B),'manifest':pin(B/'build.ninja'),'allowed_CXX':'resources.cc only','allowed_link':'hyle_graph.dll only'})
 tick=time.monotonic();started=d.now()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  child=subprocess.Popen(command,cwd=B,env=d.environment(),stdout=subprocess.PIPE,stderr=stderr);save(out/'process.json',{'state':'RUNNING','pid':child.pid,'start_utc':started});print(json.dumps({'stage':stage,'state':'RUNNING','pid':child.pid}),flush=True)
  for raw in child.stdout:
   stdout.write(raw);stdout.flush();line=raw.decode(errors='replace')
   if ('Building ' in line and not ('Building CXX object' in line and 'resources.cc.obj' in line)) or ('Linking CXX' in line and 'hyle_graph.dll' not in line):
    subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);print(json.dumps({'unexpected_action':line.strip()}),flush=True)
  code=child.wait()
 res={'state':'TERMINAL','pid':child.pid,'start_utc':started,'end_utc':d.now(),'exit_code':code,'elapsed_seconds':time.monotonic()-tick}
 if code==0:res.update(Graph_DLL=pin(B/'bin/hyle_graph.dll'),Graph_import=pin(B/'bin/hyle_graph.lib'))
 save(out/'process.json',res);print(json.dumps({'stage':stage,**res}),flush=True);assert code==0,code''')
s=s.replace(" assert read(W/'sdk-dryrun/attempt1/summary.json')['status'].startswith('PASS_')", " assert read(W/'sdk-dryrun/attempt1/process.json')['exit_code']==0 # Parent explicitly authorized phony VerifyGlobs limitation; preserve first wrapper rejection.")
p.write_text(s,encoding='utf-8')
