from pathlib import Path
import importlib.util,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/build-compute-v2-dev'
spec=importlib.util.spec_from_file_location('driver',R/'.scratch/inference-input-packet-20261031/run.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d);d.W=W
spec=importlib.util.spec_from_file_location('module_observer',R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py');o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
read,pin,save=d.read,d.pin,d.save
name=sys.argv[1];attempt=sys.argv[2] if len(sys.argv)>2 else 'attempt1';assert name in('cpu-current','cpu-control-old-graph','cuda-source')
for x in read(W/'final-source-freeze.json')['source_pins']+read(W/'tests-applied-receipt.json')['source_pins']:assert pin(x['path'])==x
plan=read(W/'validation-plan.json');tag='cuda' if name=='cuda-source' else 'cpu';case=next(x for x in plan['cases'] if x['name']==tag);linked=read(W/(tag+'-link')/('attempt2' if tag=='cuda' else 'attempt1')/'process.json');assert linked['exit_code']==0 and pin(case['image'])==linked['image']
if name!='cpu-current':assert read(W/'checks/cpu-current/attempt1/process.json')['exit_code']==0
if name=='cuda-source':assert read(W/'checks/cpu-control-old-graph/attempt1/comparison.json')['status']=='EXPECTED_OLD_GRAPH_RED'
image=(W/'control-runtime/cpu-copy-capture-test.exe') if name=='cpu-control-old-graph' else B/('bin/hyle-graph-copy-'+tag+'-20261031'+('-attempt2' if attempt=='attempt2' else '')+'.exe');assert not image.exists();image.write_bytes(Path(case['image']).read_bytes());assert pin(image)['sha256']==linked['image']['sha256']
expected=pin(W/'control-runtime/hyle_graph.dll') if name=='cpu-control-old-graph' else read(W/'sdk-build/attempt1/process.json')['Graph_DLL']
out=W/'checks'/name/attempt;out.mkdir(parents=True,exist_ok=False);xml=out/'results.xml';filter='GraphRegions.PlainGraphCopyCapture*' if name=='cpu-current' else 'GraphRegions.PlainGraphCopyCaptureKeepsFullPhysicalTuple' if name=='cpu-control-old-graph' else 'GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges';command=[str(image),'--gtest_filter='+filter,'--gtest_fail_fast','--gtest_output=xml:'+str(xml)]
save(out/'command.json',{'command':command,'cwd':str(R),'image':pin(image),'expected_Graph_DLL':expected,'environment':pin(R/'.scratch/inference-default-product-build-20261031/environment.json'),'SDK_copy':0,'automatic_retries':0,'scope':'Actual formal shared test fixture; old Graph control expected failure is explicit.'})
observed={};errors={};start=d.now();tick=time.monotonic()
with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
 child=subprocess.Popen(command,cwd=R,env=d.environment(),stdout=stdout,stderr=stderr);save(out/'process.json',{'state':'RUNNING','pid':child.pid,'start_utc':start});print(json.dumps({'case':name,'state':'RUNNING','pid':child.pid}),flush=True);h=o.KERNEL.OpenProcess(0x400|0x10,False,child.pid)
 while child.poll() is None:
  if h:
   found,error=o.modules(h);observed.update({x.lower():x for x in found})
   if error:errors[str(error)]=errors.get(str(error),0)+1
  time.sleep(.001)
 if h:o.KERNEL.CloseHandle(h)
result={'state':'TERMINAL','pid':child.pid,'exit_code':child.returncode,'start_utc':start,'end_utc':d.now(),'elapsed_seconds':time.monotonic()-tick,'observed_modules':sorted(observed.values()),'module_errors':errors};save(out/'process.json',result)
actual=[pin(x)for x in observed.values()if Path(x).name.lower().startswith(('hyle_','ggml'))and Path(x).suffix.lower()=='.dll'];save(out/'runtime-pins.json',{'image':pin(image),'observed_Hyle_GGML_DLLs':actual,'expected_Graph_DLL':expected,'snapshot_errors':errors,'scope':'1ms finite live sampling, not complete loader events or a performance measurement.'});print(json.dumps({'case':name,'state':'TERMINAL','pid':child.pid,'exit_code':child.returncode,'observed_Hyle_GGML_DLLs':len(actual)}),flush=True)
assert expected in actual,'Expected actual Graph DLL was not observed'
tree=ET.parse(xml).getroot();failed=[x.attrib.get('name')for x in tree.iter('testcase')if x.find('failure')is not None];skipped=[x.attrib.get('name')for x in tree.iter('testcase')if x.find('skipped')is not None];tests=list(tree.iter('testcase'))
if name=='cpu-control-old-graph':
 assert child.returncode==1 and failed==['PlainGraphCopyCaptureKeepsFullPhysicalTuple'] and not skipped,(child.returncode,failed,skipped)
 text=(out/'stdout.log').read_text(errors='replace');assert '*reusable' in text,text
 status='EXPECTED_OLD_GRAPH_RED'
else:
 assert child.returncode==0 and not failed and not skipped,(child.returncode,failed,skipped);assert len(tests)==(2 if name=='cpu-current' else 1);status='PASS'
save(out/'comparison.json',{'status':status,'test_count':len(tests),'failed':failed,'skipped':skipped,'expected_Graph_DLL_actually_observed':True,'same_cpu_EXE_SHA':linked['image']['sha256']if tag=='cpu'else None,'scope':'No performance claim; Graph Copy differs from provider Concat/Copy by explicit public report assertions.'});print(json.dumps({'case':name,'status':status,'tests':len(tests),'failed':len(failed),'skipped':len(skipped),'Graph_SHA':expected['sha256']}),flush=True)
