"""Freeze fixed-buffer diagnostic; preserve product and original six-step gate."""
from pathlib import Path
import difflib,hashlib,json
W=Path(__file__).resolve().parent;R=W.parent.parent;D=W/'buffered';D.mkdir(exist_ok=True)
def pin(p):
    p=Path(p).resolve();v=p.read_bytes();return {'path':str(p),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
main=R/'engine/models/qwen35/main.cc';raw=main.read_bytes();s=raw.decode();nl='\r\n' if b'\r\n' in raw else '\n'
decl='void diagnostic_capture_prepared(const Phase &, std::size_t, const g::Invocation &) noexcept;'+nl
s=s.replace('namespace qwen35 {'+nl,'namespace qwen35 {'+nl+decl,1)
marker='      check(step.execution.prepare_replay({.mode = phase.slots[slot].replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));'+nl
call='      diagnostic_capture_prepared(phase, slot, run);'+nl
assert s.count(marker)==1;s=s.replace(marker,marker+call,1)
assert s.replace(decl,'',1).replace(call,'',1).encode()==raw
clone=D/'qwen-main-diagnostic.cc';clone.write_bytes(s.encode())
probe=R/'tests/tools/qwen_generation_batch_relay_probe.cc';pr=probe.read_bytes();s=pr.decode();nl='\r\n' if b'\r\n' in pr else '\n'
names=['../../engine/models/qwen35/main.cc','qwen_generation_state_case.h','qwen_continuous_generation_case.h']
for name in names:
    target=clone if name==names[0] else (probe.parent/name).resolve();s=s.replace('#include "'+name+'"','#include "'+target.as_posix()+'"',1)
prefix='\n'.join(['#include "'+(R/'src/graph/plan_state.h').as_posix()+'"',
    '#include "'+(R/'src/compute/provider_internal.h').as_posix()+'"','#include <charconv>'])+'\n';prefix=prefix.replace('\n',nl)
extra=(W/'buffered-extra.inc').read_text().replace('\n',nl)
facts=(W/'facts-logger.inc').read_text().replace('std::cerr','fact_out').replace('\n',nl)
extra=extra.replace('} // namespace capture_diag'+nl,facts+nl+'} // namespace capture_diag'+nl,1)
s=prefix+s;s=s.replace('namespace {'+nl,extra+nl+'namespace {'+nl,1)
hooks=[('  const auto completed_before = continuation.completed_steps;',
        '  capture_diag::current_mode = static_cast<int>(mode); capture_diag::current_relay = relay;'+nl+'  capture_diag::capture_facts("arm_begin", model, continuation, static_cast<int>(mode), relay);'+nl),
       ('    const auto submitted = [&] {','    capture_diag::capture_facts("before_wave", model, continuation, static_cast<int>(mode), relay);'+nl),
       ('      ++result.submits;','      capture_diag::capture_submit(model, continuation, static_cast<int>(mode), relay);'+nl),
       ('  continuation.reset();'+nl+'  for (const auto &source : sources)','  capture_diag::capture_facts("arm_end", model, continuation, static_cast<int>(mode), relay);'+nl),
       ('int main(int argc, char **argv) {'+nl,'')]
for marker,addition in hooks[:-1]:
    assert s.count(marker)==1;s=s.replace(marker,addition+marker,1)
guard='  capture_diag::DumpFacts dump_facts;'+nl
s=s.replace(hooks[-1][0],hooks[-1][0]+guard,1)
candidate=D/'diagnostic-probe.cc';candidate.write_bytes(s.encode())
restored=s.replace(guard,'',1)
for marker,addition in reversed(hooks[:-1]):restored=restored.replace(addition+marker,marker,1)
restored=restored.replace(prefix,'',1).replace(extra+nl,'',1)
for name in names:
    target=clone if name==names[0] else (probe.parent/name).resolve();restored=restored.replace('#include "'+target.as_posix()+'"','#include "'+name+'"',1)
assert restored.encode()==pr
for src,new,title in [(main,clone,'main-hook'),(probe,candidate,'probe-buffered')]:
    (D/(title+'.patch')).write_text(''.join(difflib.unified_diff(src.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=src.relative_to(R).as_posix(),tofile=new.name)))
old=json.loads((W/'diagnostic-plan.json').read_text());oldout=W/'build/attempt1';out=D/'build/attempt1';out.mkdir(parents=True,exist_ok=True)
cxx=[x.replace(str(oldout),str(out)).replace(str(W/'diagnostic-probe.cc'),str(candidate)) for x in old['compile']]
cxx.insert(cxx.index('/showIncludes'),'-I'+str(R/'engine/models/qwen35'))
image=D/'bin/capture-facts-buffered.exe';image.parent.mkdir(exist_ok=True)
link=[x.replace(str(oldout),str(out)) for x in old['link']]
for i,x in enumerate(link):
    if x.startswith('/out:'):link[i]='/out:'+str(image)
    elif x.startswith('/implib:'):link[i]='/implib:'+str(image.with_suffix('.lib'))
    elif x.startswith('/pdb:'):link[i]='/pdb:'+str(image.with_suffix('.pdb'))
old.update(status='PREPARED_BUFFERED_ORIGINAL_POLICY',source=pin(probe),candidate=pin(candidate),main_original=pin(main),main_clone=pin(clone),
    helper=pin(W/'buffered-extra.inc'),patch=pin(D/'probe-buffered.patch'),main_patch=pin(D/'main-hook.patch'),compile=cxx,link=link,image=str(image),
    inverse_original_main_bytes_exact=True,inverse_original_probe_bytes_exact=True,after_submit='Fixed primitive counters only; no callbacks/I/O/allocation/growth.',
    after_prepare='One typed scratch-only hook after successful original replay preparation, before original submit; first live negative per range/provider.',
    dump='Fixed 2MiB buffer; dump only at outer main exit, after original Model cleanup. Overflow reported.',
    normal_inputs_scope='Historical unchanged compile/link recipe; Kimi configure may regenerate manifest but no SDK binaries/objects were rebuilt.')
save(D/'diagnostic-plan.json',old)
print(json.dumps({'status':old['status'],'probe':pin(candidate),'main_clone':pin(clone),'inverse_both_exact':True,'CXX_started':0,'native_started':0}))
