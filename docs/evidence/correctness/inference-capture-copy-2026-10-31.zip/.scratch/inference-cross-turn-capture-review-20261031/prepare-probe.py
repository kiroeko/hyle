"""Diagnostic consumer only; original product policy/SDK stay unchanged."""
from pathlib import Path
import difflib,hashlib,importlib.util,json,re,subprocess
W=Path(__file__).resolve().parent;R=W.parent.parent;B=R/'.scratch/build-compute-v2-dev'
def pin(p):
    p=Path(p).resolve();v=p.read_bytes();return {'path':str(p),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
original=R/'tests/tools/qwen_generation_batch_relay_probe.cc';raw=original.read_bytes();s=raw.decode();nl='\r\n' if b'\r\n' in raw else '\n'
includes=['../../engine/models/qwen35/main.cc','qwen_generation_state_case.h','qwen_continuous_generation_case.h']
for name in includes:
    absolute=(original.parent/name).resolve().as_posix();s=s.replace('#include "'+name+'"','#include "'+absolute+'"',1)
s='#include "'+(R/'src/graph/plan_state.h').as_posix()+'"'+nl+s
helper=(W/'facts-logger.inc').read_text().replace('\n',nl)
marker='void check_captured_sources('
assert s.count(marker)==1;s=s.replace(marker,helper+nl+marker,1)
hooks=[('  const auto completed_before = continuation.completed_steps;','  capture_facts("arm_begin", model, continuation, static_cast<int>(mode), relay);'+nl),
       ('    const auto submitted = [&] {','    capture_facts("before_wave", model, continuation, static_cast<int>(mode), relay);'+nl),
       ('      ++result.submits;','      capture_facts("after_submit", model, continuation, static_cast<int>(mode), relay);'+nl),
       ('  continuation.reset();'+nl+'  for (const auto &source : sources)', '  capture_facts("arm_end", model, continuation, static_cast<int>(mode), relay);'+nl)]
for marker,addition in hooks:
    assert s.count(marker)==1,(marker,s.count(marker));s=s.replace(marker,addition+marker,1)
candidate=W/'diagnostic-probe.cc';candidate.write_bytes(s.encode())
restored=s
for marker,addition in reversed(hooks):restored=restored.replace(addition+marker,marker,1)
restored=restored.replace(helper+nl,'',1);restored=restored.split(nl,1)[1]
for name in includes:restored=restored.replace('#include "'+(original.parent/name).resolve().as_posix()+'"','#include "'+name+'"',1)
assert restored.encode()==raw
(W/'diagnostic-probe.patch').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True),s.splitlines(True),fromfile='original-probe.cc',tofile='diagnostic-probe.cc')),newline='')
old=json.loads((R/'.scratch/inference-input-packet-review-20261031/commands.json').read_text())
out=W/'build/attempt1';out.mkdir(parents=True,exist_ok=True)
oldfolder=Path(old['host_fixture_image']).parent
cxx=[x.replace(str(oldfolder),str(out)).replace(str(R/'tests/tools/qwen_host_image_test.cc'),str(candidate)).replace('qwen_host_image_test.cc.obj','capture-facts-probe.cc.obj') for x in old['host_fixture_cxx']]
cxx.insert(cxx.index('/showIncludes'),'/bigobj')
for name in ('graph','compute'):cxx.insert(cxx.index('/showIncludes'),'-I'+str(R/'src'/name))
image=W/'bin/capture-facts-probe.exe';image.parent.mkdir(exist_ok=True)
link=[x.replace(str(oldfolder),str(out)).replace('qwen_host_image_test.cc.obj','capture-facts-probe.cc.obj') for x in old['host_fixture_link']]
for i,x in enumerate(link):
    if x.startswith('/out:'):link[i]='/out:'+str(image)
    elif x.startswith('/implib:'):link[i]='/implib:'+str(image.with_suffix('.lib'))
    elif x.startswith('/pdb:'):link[i]='/pdb:'+str(image.with_suffix('.pdb'))
files=[]
for x in link:
    p=Path(x)
    if p.is_absolute() and p.is_file() and p.suffix.lower() in ('.obj','.lib'):files.append(pin(p))
plan={'status':'PREPARED_DIAGNOSTIC_ONLY_ORIGINAL_POLICY','source':pin(original),'candidate':pin(candidate),
      'helper':pin(W/'facts-logger.inc'),'patch':pin(W/'diagnostic-probe.patch'),'inverse_original_probe_bytes_exact':True,
      'compile':cxx,'link':link,'cwd':str(B),'image':str(image),'retained_objects_and_imports':files,
      'normal_inputs':json.loads((W/'normal-dependency-inventory.json').read_text())['normal_inputs'],
      'product_sources':[pin(R/x) for x in ['engine/models/qwen35/main.cc','src/graph/executable.cc','src/graph/plan_state.h','include/hyle/graph/detail/replay_access.h']],
      'environment':pin(R/'.scratch/inference-default-product-build-20261031/environment.json'),
      'native_command':['{STAGED_IMAGE}','--warm-cohort',str(R/'.scratch/inference-continuous-wave-20261027/inputs/context32')],
      'CXX':1,'link_count':1,'SDK_CXX':0,'NVCC':0,'authorized_native':1,'automatic_retries':0,
      'scope':'Private state inspection only in diagnostic consumer; original six-step policy, all numeric/Source/ledger/retirement assertions and product source bytes unchanged. No same-session second-turn extension.'}
save(W/'diagnostic-plan.json',plan)
print(json.dumps({'status':plan['status'],'candidate':pin(candidate),'inverse_exact':True,'CXX':1,'SDK_CXX':0,'runs_started':0}))
