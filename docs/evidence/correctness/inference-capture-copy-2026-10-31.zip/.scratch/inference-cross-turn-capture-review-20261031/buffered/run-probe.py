"""One explicitly authorized diagnostic CXX/link/native; no SDK work."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[2];B=R/'.scratch/build-compute-v2-dev'
spec=importlib.util.spec_from_file_location('normal_finite_driver',R/'.scratch/inference-input-packet-20261031/run.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
driver.W=W;driver.R=R;driver.B=B
read,pin,save=driver.read,driver.pin,driver.save
plan=read(W/'diagnostic-plan.json')
for key in ('source','candidate','helper','patch','environment','main_original','main_clone','main_patch'):assert pin(plan[key]['path'])==plan[key],key
for row in plan['product_sources']+plan['retained_objects_and_imports']:assert pin(row['path'])==row,row['path']
stage=sys.argv[1]
if stage=='compile':
    unit=W/'build/attempt1/capture-facts-probe.cc.obj'
    driver.execute('compile',plan['compile'],lambda:{'object':pin(unit),'actual_dependencies':pin(W/'build/attempt1/dependencies.json')})
elif stage=='link':
    compiled=read(W/'compile/attempt1/process.json');assert compiled['exit_code']==0
    assert pin(compiled['object']['path'])==compiled['object']
    driver.execute('link',plan['link'],lambda:{'image':pin(plan['image'])})
elif stage=='run':
    linked=read(W/'link/attempt1/process.json');assert linked['exit_code']==0
    original=linked['image'];assert pin(original['path'])==original
    target=B/'bin/hyle-capture-facts-buffered-20261031.exe';assert not target.exists()
    target.write_bytes(Path(original['path']).read_bytes());image=pin(target)
    assert image['bytes']==original['bytes'] and image['sha256']==original['sha256']
    save(W/'staged-image.json',{'image':image,'linked_image':original,'SDK_copied':0})
    spec=importlib.util.spec_from_file_location('normal_module_observer',R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py')
    sample=importlib.util.module_from_spec(spec);spec.loader.exec_module(sample);sample.HERE=W;sample.ROOT=R;sample.IMAGE=target
    args=[str(target),*plan['native_command'][1:]]
    folder,process=sample.execute('warm-cohort',args,driver.environment())
    actual=[]
    for name in process['observed_modules']:
        p=Path(name)
        if p.suffix.lower()=='.dll' and p.name.lower().startswith(('hyle_','ggml')):
            assert p.parent.resolve()==(B/'bin').resolve(),str(p);actual.append(pin(p))
    save(folder/'runtime-pins.json',{'actual_observed_Hyle_GGML_DLLs':actual,'errors':process['module_sample_errors'],'scope':process['scope']})
    report=json.loads((folder/'stdout.log').read_text(encoding='utf-8-sig'));assert report['status']=='PASS'
    save(folder/'report.json',report)
    print(json.dumps({'status':'PASS_ORIGINAL_WARM_COHORT_DIAGNOSTIC','report':pin(folder/'report.json'),'observed_DLLs':len(actual)}))
else:raise RuntimeError('Unknown action')
