"""One root-authorized reuse of the same binary against the repaired SDK."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[2];B=R/'.scratch/build-compute-v2-dev';D=W/'copy-fix-run'
spec=importlib.util.spec_from_file_location('existing_finite_driver',R/'.scratch/inference-input-packet-20261031/run.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver);driver.W=D
read,pin,save=driver.read,driver.pin,driver.save
freeze=read(R/'.scratch/inference-captured-graph-copy-20261031/source-freeze.json')
for row in freeze['source_pins']:assert pin(row['path'])==row,row['path']
image=read(W/'staged-image.json')['image'];assert pin(image['path'])==image
graph=pin(B/'bin/hyle_graph.dll')
old=pin(R/'.scratch/inference-captured-graph-copy-20261031/control-runtime/hyle_graph.dll')
assert graph['sha256']!=old['sha256']
plan=read(W/'diagnostic-plan.json')
save(D/'binding.json',{'status':'AUTHORIZED_SAME_DIAGNOSTIC_BINARY_NEW_COPY_SDK','image':image,'Graph_DLL':graph,'old_Graph_control':old,
     'source_freeze':pin(R/'.scratch/inference-captured-graph-copy-20261031/source-freeze.json'),
     'note':'No recompile. Original six-step strategy/assertions remain. reason4 classifier mirrors pre-fix kinds; use actual stored flags/keys and original assertions.',
     'normal_runtime_scope':'Unified current SDK also includes authorized SIMD regeneration; this is not an isolated two-DLL performance comparison.'})
spec=importlib.util.spec_from_file_location('normal_module_observer',R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py')
sample=importlib.util.module_from_spec(spec);spec.loader.exec_module(sample);sample.HERE=D;sample.ROOT=R;sample.IMAGE=Path(image['path'])
folder,process=sample.execute('warm-cohort',[image['path'],*plan['native_command'][1:]],driver.environment())
actual=[pin(Path(x)) for x in process['observed_modules'] if Path(x).suffix.lower()=='.dll' and Path(x).name.lower().startswith(('hyle_','ggml'))]
assert graph in actual,'Actual repaired Graph DLL was not observed'
save(folder/'runtime-pins.json',{'actual_Hyle_GGML_DLLs':actual,'module_errors':process['module_sample_errors'],'scope':process['scope']})
report=json.loads((folder/'stdout.log').read_text(encoding='utf-8-sig'));save(folder/'report.json',report);assert report['status']=='PASS'
print(json.dumps({'status':'PASS_ORIGINAL_WARM_COHORT_NEW_COPY_SDK','report':pin(folder/'report.json'),'Graph_DLL':graph}))
