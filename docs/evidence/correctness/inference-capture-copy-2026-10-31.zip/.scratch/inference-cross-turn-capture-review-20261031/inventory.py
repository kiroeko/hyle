"""Read current normal Ninja dependencies; no build/configure/model run."""
from pathlib import Path
import hashlib,json,re,subprocess
W=Path(__file__).resolve().parent;R=W.parent.parent;B=R/'.scratch/build-compute-v2-dev'
def pin(p):
    p=Path(p).resolve();v=p.read_bytes();return {'path':str(p),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
ninja_text=(B/'build.ninja').read_text(encoding='utf-8-sig')
cache=(B/'CMakeCache.txt').read_text(encoding='utf-8-sig')
ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.*)$',cache,re.M).group(1)
configured={x.replace('\\','/').lower() for x in re.findall(r'^build ([^\r\n]+?\.obj): (?:CXX|CUDA|C)_COMPILER_',ninja_text,re.M)}
query=subprocess.run([ninja,'-C',str(B),'-t','deps'],capture_output=True,text=True)
assert query.returncode==0,query.stderr
dependents=[]
for block in query.stdout.split('\n\n'):
    lines=block.splitlines()
    if not lines or ': #deps ' not in lines[0]:continue
    obj=lines[0].split(': #deps ',1)[0]
    includes=[x.strip() for x in lines[1:] if x.startswith('    ')]
    hit=[x for x in includes if x.replace('\\','/').endswith('/graph/detail/replay_access.h')]
    if hit:
        dependents.append({'object':pin(B/obj),'configured_now':obj.replace('\\','/').lower() in configured,
            'dependency_count':len(includes),'matched_headers':[pin(Path(x) if Path(x).is_absolute() else B/x) for x in hit]})
app=[]
for block in ninja_text.split('\n\n'):
    if block.startswith('build engine\\CMakeFiles\\hyle_engine.dir\\') and ': CXX_COMPILER_' in block.splitlines()[0]:
        edge=block.splitlines();obj=edge[0].split(': CXX_COMPILER_',1)[0][6:]
        app.append({'object':pin(B/obj),'compile_edge':edge})
assert len(app)==9,len(app)
result={'status':'READ_ONLY_CURRENT_CACHE_DEPENDENCY_INVENTORY','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        'normal_inputs':[pin(B/'build.ninja'),pin(B/'CMakeFiles/rules.ninja'),pin(B/'CMakeCache.txt')],
        'replay_access_dependents':dependents,'normal_app_objects':app,
        'replay_report_candidate_expected_sdk_CXX':len([x for x in dependents if x['configured_now']]),
        'qwen_gate_candidate_additional_app_CXX':1,'retained_app_objects_if_main_only':8,'retained_cold_objects':6,
        'diagnostic_probe_only_expected_SDK_CXX':0,'diagnostic_probe_only_expected_CXX':1,'diagnostic_probe_only_expected_link':1,
        'tests_configuration':'HYLE_BUILD_TESTS=OFF; any finite test/probe consumer needs explicit normal-shared recipe and actual current include closure.',
        'gtest_cached':[pin(B/'lib/gtest.lib'),pin(B/'lib/gtest_main.lib')],
        'builds':0,'native':0,'GPU':0}
(W/'normal-dependency-inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'configured_replay_access_dependents':[Path(x['object']['path']).name for x in dependents if x['configured_now']],
                  'stale_cached_dependents':len([x for x in dependents if not x['configured_now']]),'app_objects':len(app),'builds':0}))
