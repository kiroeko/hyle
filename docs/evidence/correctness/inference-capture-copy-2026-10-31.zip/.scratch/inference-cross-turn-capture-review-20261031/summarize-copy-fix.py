import json,pathlib,collections
r=pathlib.Path('.scratch/inference-cross-turn-capture-review-20261031/buffered/copy-fix-run')
facts=[]; prepared=[]; submits=[]
for line in (r/'checks/warm-cohort/attempt1/stderr.log').read_text(encoding='utf-8').splitlines():
 for p,a in [('capture_facts ',facts),('capture_prepared ',prepared),('capture_submit ',submits)]:
  if line.startswith(p): a.append(json.loads(line[len(p):]))
out={'status':'PASS_ORIGINAL_SIX_STEP_AND_ASSERTS','native_processes':1,'same_EXE_no_CXX':True,'source_gate_changed':False,'same_session_second_turn_tested':False,'key_diff_limitation':'Fixed log retains key counts, masks and equality, not individual per-port coordinates; no actual token-only key-diff claim.','old_live_classifier_limitation':'reason4 classifier predates Copy fix; stored cached_private plus original complete assertions are authoritative for repaired SDK.','modes':[]}
for mode in sorted({x['mode'] for x in facts}):
 f=[x for x in facts if x['mode']==mode]; s=[x for x in submits if x['mode']==mode]; rows=[]
 for req in (1,2):
  for slot in range(3):
   ff=[x for x in f if x['requests']==req and x['slot']==slot and x['ranges']]
   transitions=[]
   for x in ff:
    v=(x['uses'],tuple((z['distinct_records'],z['record_mask'],z['key_mask'],z['qualified'],z['private_arguments']) for z in x['ranges']))
    if not transitions or transitions[-1]!=v: transitions.append(v)
   rows.append({'requests':req,'slot':slot,'observed_use_and_record_transitions':transitions,'Invocation_states':len({x['state'] for x in f if x['requests']==req and x['slot']==slot and x['state']!='0x0'})})
 out['modes'].append({'mode':mode,'slots':rows,'max_successors':max((x['successors'] for x in s),default=0),'max_refusals':max((x['refusals'] for x in s),default=0)})
(r/'distribution-summary.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':out['status'],'modes':len(out['modes']),'fact_snapshots':len(facts),'prepared_snapshots':len(prepared),'submit_snapshots':len(submits),'normal_mode':out['modes'][0]},separators=(',',':')))
