from pathlib import Path
import subprocess, os, json, time
root = Path.cwd()
out = root / '.scratch/inference-gaps/g01'
vs = r'C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat'
batch = out / 'replay-vs-environment.cmd'
batch.write_text(f'@echo off\ncall "{vs}" -arch=x64 -host_arch=x64 >nul\nif errorlevel 1 exit /b 1\nset\n')
captured = subprocess.check_output(['cmd', '/d', '/c', str(batch)], text=True)
env = os.environ.copy()
for line in captured.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key] = value
args = ['cmake', '--build', 'C:/h7/inference-g01-native-vulkan/build', '--target', 'resident', 'attention_cache', '--parallel', '4']
log = out / 'replay-native-build-3.log'
assert not log.exists()
started = time.monotonic()
with log.open('w', encoding='utf-8') as stream:
    result = subprocess.run(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
receipt = {'command': args, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started, 'log': str(log), 'scope': 'Windows compile only; no local GPU execution'}
(out / 'replay-native-build-3-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
with log.open('rb') as stream:
    stream.seek(max(0, log.stat().st_size - 2200))
    print(stream.read().decode('utf-8', errors='replace'))
raise SystemExit(result.returncode)
