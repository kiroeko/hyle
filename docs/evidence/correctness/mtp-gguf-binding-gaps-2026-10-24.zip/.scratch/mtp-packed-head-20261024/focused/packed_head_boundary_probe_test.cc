#include "../proposal/next-source/tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc"

#include <algorithm>
#include <cstddef>
#include <span>
#include <string>
#include <vector>

namespace {
namespace m = hyle::mem;

// Generated legal Q8_0 test data only. This is NOT a B07 original weight or
// model-quality check. The native read of the final34B block is beyond I32.
TEST(GgmlCudaPackedLargeRead, GeneratedQ8TailBeyondI32RunsM1AndM2) {
  auto context = c::Context::create(c::cuda::device(0).value(),
                                  c::ggml_cuda::provider()).value();
  const auto environment = c::cuda::environment(context).value();
  if (environment.sm_major == 8 && environment.sm_minor == 7)
    GTEST_SKIP() << "This frozen proposal retains the conservative Orin M1 cap; it cannot validate M2 there";
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  constexpr auto f32 = c::DataType::kFloat32;
  constexpr std::int64_t width = 8192, vocabulary = 248320;
  constexpr std::size_t weight_bytes = 2161377280ULL, block_bytes = 34;
  const auto description = c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,
      f32, width, vocabulary).value();
  ASSERT_EQ(description.required_bytes().value(), weight_bytes);
  constexpr auto tail_offset = weight_bytes - block_bytes;
  static_assert(tail_offset > std::size_t{INT32_MAX});
  auto bank = m::Buffer::create(memory.ref(), weight_bytes, 256);
  ASSERT_TRUE(bank) << bank.error().message();
  ASSERT_TRUE(bank->fill(0, weight_bytes, std::byte{0}).ok());
  // Q8_0 block = IEEE F16 d=1 followed by32 signed int8 coefficients.
  std::array<std::byte, block_bytes> first{}, last{};
  first[1] = last[1] = std::byte{0x3c};
  std::fill(first.begin()+2, first.end(), std::byte{1});
  std::fill(last.begin()+2, last.end(), std::byte{3});
  ASSERT_TRUE(bank->write(0, first).ok());
  ASSERT_TRUE(bank->write(tail_offset, last).ok());
  const auto weight = c::ConstTensorView::create(description, bank->view()).value();
  auto queue = context.create_queue().value();
  for (const auto batch : std::array<std::int64_t, 2>{1, 2}) {
    SCOPED_TRACE(batch);
    const auto a_desc = dense(f32, {batch, width}), y_desc = dense(f32, {batch, vocabulary});
    auto prepared = prepare(context, memory.ref(), a_desc, description, y_desc);
    ASSERT_TRUE(prepared) << prepared.error().message();
    EXPECT_EQ(prepared->provider().id, c::ggml_cuda::kProviderId);
    const auto workspace = prepared->workspace_requirement();
    // The admitted MMVQ needs activation scratch, never an8.14GB F32 W.
    ASSERT_LT(workspace.size, 64ULL*1024*1024);
    auto scratch = m::Buffer::create(memory.ref(), workspace.size,
        std::max(std::size_t{256}, workspace.alignment));
    ASSERT_TRUE(scratch) << scratch.error().message();
    auto activation = m::Buffer::create(memory.ref(), a_desc.required_bytes().value(), 256);
    auto output = m::Buffer::create(memory.ref(), y_desc.required_bytes().value(), 256);
    ASSERT_TRUE(activation) << activation.error().message();
    ASSERT_TRUE(output) << output.error().message();
    std::vector<float> values(std::size_t(batch*width));
    for (std::int64_t row = 0; row < batch; ++row)
      std::fill_n(values.begin()+row*width, std::size_t(width), row == 0 ? 127.F : -127.F);
    ASSERT_TRUE(activation->write(0, std::as_bytes(std::span(values))).ok());
    ASSERT_TRUE(output->fill(0, output->size(), std::byte{0x7f}).ok());
    auto invocation = prepared->create_invocation(scratch->view());
    ASSERT_TRUE(invocation) << invocation.error().message();
    const auto input = c::ConstTensorView::create(a_desc, activation->view()).value();
    const auto result = c::TensorView::create(y_desc, output->view()).value();
    auto completion = invocation->submit(queue, input, weight, result);
    ASSERT_TRUE(completion) << completion.error().message();
    const auto waited = completion->wait();
    ASSERT_TRUE(waited.ok()) << waited.message();
    std::vector<float> actual(std::size_t(batch*vocabulary));
    ASSERT_TRUE(output->read(0, std::as_writable_bytes(std::span(actual))).ok());
    // Uniform +/-127 activates exact AQ8_1 d=1 and codes+/-127. Integer
    // dot products are exactly representable:32*127=4064 and*3=12192.
    for (std::int64_t row = 0; row < batch; ++row) {
      const float sign = row == 0 ? 1.F : -1.F;
      ASSERT_EQ(actual[std::size_t(row*vocabulary)], sign*4064.F);
      ASSERT_EQ(actual[std::size_t((row+1)*vocabulary-1)], sign*12192.F);
      for (std::int64_t column = 1; column+1 < vocabulary; ++column)
        if (actual[std::size_t(row*vocabulary+column)] != 0.F)
          FAIL() << "Generated zero Q8 row changed at M=" << batch << " row=" << row << " column=" << column;
    }
    ::testing::Test::RecordProperty("generated_q8_workspace_M"+std::to_string(batch), std::to_string(workspace.size));
  }
  ::testing::Test::RecordProperty("generated_only_not_B07", "true");
  ::testing::Test::RecordProperty("generated_weight_bytes", std::to_string(weight_bytes));
  ::testing::Test::RecordProperty("actual_tail_block_offset", std::to_string(tail_offset));
  ::testing::Test::RecordProperty("tail_reference", "F16 scale1; Q8 codes1/3; AQ8_1 scale1 and +/-127; full output checked exactly");
}
} // namespace
