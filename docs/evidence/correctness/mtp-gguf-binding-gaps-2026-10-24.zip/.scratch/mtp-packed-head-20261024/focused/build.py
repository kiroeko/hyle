"""Root-only two-host-TU packed-head boundary probe on the frozen B10 closure.

plan is offline. compile/link/run execute only when explicitly selected. No
HTTP, model loader, CUDA compiler, SDK build or canonical-source edit occurs.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
R = S.parents[2]
B10 = R / '.scratch/glm-gguf-selected-20261023/B10/native-integration/build.py'
METADATA = P / 'current-closure-metadata.json'
TAGS = ('tensor-program', 'probe')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


base = module('_packed_head_frozen_b10', B10)
read, save, identity, require, resolve = base.read, base.save, base.identity, base.require, base.resolve


def sources():
    for fact in read(P / 'proposal/source-facts.json'):
        for root, prefix in ((R, 'before'), (P / 'proposal/next-source', 'after')):
            actual = identity(root / fact['path'])
            if actual['bytes'] != fact[prefix + '_bytes'] or actual['sha256'] != fact[prefix + '_sha256']:
                raise ValueError('Frozen live-before/proposal-after source changed: ' + str(root / fact['path']))
    return {
        'tensor-program': P / 'proposal/next-source/src/compute_provider_ggml_cuda/tensor_program.cc',
        'probe': S / 'packed_head_boundary_probe_test.cc',
    }


def recipes():
    metadata = read(METADATA)
    rows = metadata['tensor_program_records']
    if len(rows) != 1:
        raise ValueError('Expected exactly one current tensor_program.cc object')
    tensor_record = resolve(rows[0]['record'])
    base.check_record(tensor_record)
    plan, ready, runtime, consumer, records = base.closure()
    if len(records) != 131:
        raise ValueError('Frozen closure no longer contains131 host records')
    return metadata, tensor_record, plan, ready, runtime, consumer, records


def prepared_recipes(attempt):
    source = sources()
    metadata, tensor_record, plan, _, _, consumer, _ = recipes()
    destination = S / f'prepared{attempt}'
    destination.mkdir(exist_ok=False)
    values = {'tensor-program': read(tensor_record), 'probe': consumer}
    result = {}
    for tag, value in values.items():
        value = dict(value)
        value['command'] = [arg for arg in value['command']
                            if not arg.startswith('/DHYLE_TEST_GLM_')]
        value.update(preparation_only=True, original_recipe=identity(tensor_record) if tag == 'tensor-program'
                     else plan['consumer_record'], generated_only_not_B07=(tag == 'probe'))
        path = destination / f'{tag}.json'
        save(path, value)
        result[tag] = path
    return source, result


def plan(attempt):
    source, prepared = prepared_recipes(attempt)
    h = base.helpers()
    rows = []
    for tag in TAGS:
        out = S / f'compile{attempt}' / tag
        command = h.b.host_command(read(prepared[tag])['command'], source[tag], tag, out)
        if not all(flag in command for flag in ('/W4', '/WX', '/O2', '/MD')):
            raise ValueError('Focused host compiler flags changed')
        rows.append(dict(tag=tag, source=identity(source[tag]), recipe=identity(prepared[tag]), command=command))
    metadata, tensor_record, original, _, runtime, consumer, records = recipes()
    save(S / f'commands{attempt}.json', dict(
        preparation_only=True, executed=False, compile=rows,
        base_build_tool=identity(B10), base_link_plan=identity(base.BASE / 'link-plan.json'),
        runtime_environment=identity(runtime), current_host_records=len(records),
        header_consumers=metadata['tensor_program_header_consumers'],
        replaced_objects=[read(tensor_record)['object'], consumer['object']],
        header_changes=0, rebuilt_product_host_TUs=1, rebuilt_test_TUs=1,
        SDK_builds=0, NVCC_builds=0, native_builds=0,
        generated_Q8=dict(original_model_payload=False, K=8192, N=248320,
                          weight_bytes=2161377280, tail_block_offset=2161377246,
                          exact_output_M1=[4064, 12192], exact_output_M2=[-4064, -12192],
                          all_other_outputs=0, maximum_workspace_bytes=64 * 1024 * 1024),
        root_commands=[
            [sys.executable, str(Path(__file__)), 'compile', '--attempt', str(attempt)],
            [sys.executable, str(Path(__file__)), 'link', '--attempt', str(attempt)],
            [sys.executable, str(Path(__file__)), 'run', '--attempt', str(attempt)],
        ]))
    print('PREPARED', S / f'commands{attempt}.json')


def compile_hosts(attempt):
    source = sources()
    recipes()
    h = base.helpers()
    h.S = S
    h.SOURCES = source
    h.RECIPES = {tag: S / f'prepared{attempt}' / f'{tag}.json' for tag in TAGS}
    commands = read(S / f'commands{attempt}.json')
    for row in commands['compile']:
        require(row['source'])
        require(row['recipe'])
    for tag in TAGS:
        h.compile_one(tag, attempt)
        base.check_record(S / f'compile{attempt}' / tag / 'identity.json')


def link(attempt):
    sources()
    _, tensor_record, original, _, runtime_path, old_consumer, records = recipes()
    fresh = {tag: base.check_record(S / f'compile{attempt}' / tag / 'identity.json') for tag in TAGS}
    replacements = {
        str(resolve(read(tensor_record)['object']['path'])).lower(): fresh['tensor-program']['object']['path'],
        str(resolve(old_consumer['object']['path'])).lower(): fresh['probe']['object']['path'],
    }
    counts = dict.fromkeys(replacements, 0)
    command = []
    for arg in original['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        key = str(resolve(arg)).lower() if arg.lower().endswith('.obj') else None
        if key in replacements:
            counts[key] += 1
            arg = replacements[key]
        command.append(arg)
    if set(counts.values()) != {1}:
        raise ValueError('Each replaced current object must occur exactly once')
    objects = {str(resolve(arg)).lower() for arg in command if arg.lower().endswith('.obj')}
    known = {str(resolve(row['object']['path'])).lower() for row in fresh.values()}
    checked = []
    for row in base.native_inputs():
        known.add(str(resolve(row['object']['path'])).lower())
    for info in original['retained_inputs']:
        require(info)
        known.add(str(resolve(info['path'])).lower())
    for path in records:
        record = read(path)
        if str(resolve(record['object']['path'])).lower() in objects:
            base.check_record(path)
            checked.append(identity(path))
            known.add(str(resolve(record['object']['path'])).lower())
    if not objects <= known:
        raise ValueError('Unaccounted retained object: ' + repr(objects - known))
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'packed-head-boundary.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    save(out / 'link-plan.json', dict(command=command, base=identity(base.BASE / 'link-plan.json'),
         fresh_records=[identity(S / f'compile{attempt}' / tag / 'identity.json') for tag in TAGS],
         removed_objects=list(replacements), retained_host_records=checked,
         retained_inputs=original['retained_inputs'],
         native_input_manifest=identity(base.S / 'native-inputs.json'),
         SDK_builds=0, NVCC_builds=0, native_builds=0, product_host_TUs=1, test_TUs=1))
    h = base.helpers()
    env, _ = h.b.environment(command, [], out)
    h.c.execute('link', command, env, out)
    runtime = read(runtime_path)
    for info in runtime['staged_dlls']:
        require(info)
        dll = resolve(info['path'])
        os.link(dll, out / dll.name)
    runtime['PATH'] = str(out) + os.pathsep + runtime['PATH'].replace(str(base.BASE_IMAGE), str(out))
    runtime.update(previous=identity(runtime_path), staged_dlls=[identity(path) for path in out.glob('*.dll')],
                   product_host_TUs=1, test_TUs=1, SDK_builds=0, NVCC_builds=0)
    save(out / 'runtime-environment.json', runtime)
    save(out / 'ready.json', dict(image=identity(image), link_plan=identity(out / 'link-plan.json'),
         runtime_environment=identity(out / 'runtime-environment.json'),
         compiled_records=[identity(S / f'compile{attempt}' / tag / 'identity.json') for tag in TAGS],
         generated_only_not_B07=True, native_result=False))


def run(attempt, timeout):
    sources()
    image_dir = S / f'tests-link{attempt}'
    ready = read(image_dir / 'ready.json')
    for key in ('image', 'link_plan', 'runtime_environment'):
        require(ready[key])
    for info in ready['compiled_records']:
        require(info)
        base.check_record(resolve(info['path']))
    runtime = read(image_dir / 'runtime-environment.json')
    for info in runtime['staged_dlls']:
        require(info)
    out = S / f'run{attempt}'
    out.mkdir(exist_ok=False)
    env = os.environ.copy()
    env['PATH'] = runtime['PATH']
    command = [ready['image']['path'],
               '--gtest_filter=GgmlCudaPackedBounds.*:GgmlCudaPackedLargeRead.*',
               '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'gtest.xml')]
    runner = module('_packed_head_bounded_native_runner', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    save(out / 'plan.json', dict(command=command, image=ready['image'], timeout=timeout,
         generated_only_not_B07=True, model_HTTP=0, SDK_builds=0, NVCC_builds=0))
    process = runner.execute(command, env, out / 'native', timeout=timeout)
    xml = ET.parse(out / 'gtest.xml').getroot() if (out / 'gtest.xml').exists() else None
    cases = xml.findall('.//testcase') if xml is not None else []
    passed = process['exit'] == 0 and not process['timed_out'] and len(cases) == 4 and all(
        not case.findall('failure') and not case.findall('skipped') for case in cases)
    save(out / 'summary.json', dict(process=process, passed=passed, cases=len(cases),
         gtest=identity(out / 'gtest.xml') if xml is not None else None,
         generated_only_not_B07=True, original_model_result=False))
    if not passed:
        raise SystemExit(process['exit'] or 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'compile', 'link', 'run'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    if min(args.attempt, args.timeout) <= 0:
        raise ValueError('Positive attempt/timeout required')
    if args.action == 'plan':
        plan(args.attempt)
    elif args.action == 'compile':
        compile_hosts(args.attempt)
    elif args.action == 'link':
        link(args.attempt)
    else:
        run(args.attempt, args.timeout)


if __name__ == '__main__':
    main()
