"""Preserve bounded common-binding compilation and actual packed-tail checks."""
from pathlib import Path
import hashlib
import importlib.util
import json
import zipfile
import xml.etree.ElementTree as ET

S = Path(__file__).resolve().parent
R = S.parents[1]
F = R / '.scratch/glm-gguf-selected-20261023/flash-consumer-proposal'
P = R / '.scratch/mtp-packed-head-20261024'
O = R / 'docs/evidence/correctness/mtp-gguf-binding-gaps-2026-10-24.json'

def identity(path):
    path = Path(path)
    return dict(path=str(path.relative_to(R)), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

spec = importlib.util.spec_from_file_location('binding_current_record', R / '.scratch/glm-gguf-selected-20261023/B10/native-integration/build.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
compile_record = F / 'compile2/flash-state/identity.json'
record = c.check_record(compile_record)
if any('HYLE_TEST_GLM_B12_ARTIFACTS_HEADER' in x or 'HYLE_TEST_GLM_B13_ARTIFACTS_HEADER' in x for x in record['command']):
    raise RuntimeError('Original B12/B13 pins must not be invented')
for tag in ('tensor-program', 'probe'):
    c.check_record(P / ('focused/compile1/' + tag + '/identity.json'))
run = P / 'focused/run1'
result = read(run / 'summary.json')
xml = ET.parse(run / 'gtest.xml').getroot()
cases = list(xml.iter('testcase'))
if not result['passed'] or result['process']['exit'] != 0 or result['process']['timed_out'] or len(cases) != 4 or list(xml.iter('failure')) or list(xml.iter('skipped')):
    raise RuntimeError('Require the four actual passing GPU checks')
properties = {n.get('name'): n.get('value') for n in xml.iter('property')}
if properties['actual_tail_block_offset'] != '2161377246' or properties['generated_only_not_B07'] != 'true':
    raise RuntimeError('Require actual >I32 generated-tail coverage')
sources = ['tests/compute_models/' + name for name in (
    'glm_gguf_flash_fragment.h', 'glm_gguf_flash_reference.h', 'glm_gguf_mtp_reference.h',
    'glm_gguf_flash_source.h', 'glm_gguf_runtime_source.h', 'glm_mtp_state_consumer_test.cc')]
files = [R / x for x in sources] + [Path(__file__), compile_record,
    F / 'compile_current.py', F / 'ready.json', F / 'source.patch', F / 'applied.json',
    F / 'compile2/flash-state/compile.command.json', F / 'compile2/flash-state/compile.result.json',
    F / 'compile2/flash-state/compile.stdout.log', F / 'compile2/flash-state/compile.stderr.log',
    F / 'compile1/flash-state/flash-fragment-before-adl-fix.h',
    R / '.scratch/glm-gguf-selected-20261023/flash-reference-proposal/source.patch',
    R / '.scratch/glm-gguf-selected-20261023/flash-reference-proposal/compile2/pro-reference-before-warning-fix.h',
    P / 'proposal/source.patch', P / 'review/findings.json', P / 'review/native-source-facts.json',
    P / 'proposal/next-source/src/compute_provider_ggml_cuda/tensor_program.cc',
    P / 'proposal/next-source/tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc',
    P / 'focused/build.py', P / 'focused/packed_head_boundary_probe_test.cc',
    P / 'focused/commands1.json', P / 'focused/tests-link1/link-plan.json',
    P / 'focused/tests-link1/runtime-environment.json', run / 'summary.json', run / 'gtest.xml',
    run / 'plan.json', run / 'native/stdout.log', run / 'native/stderr.log']
for tag in ('tensor-program', 'probe'):
    root = P / ('focused/compile1/' + tag)
    files += [root / name for name in ('identity.json', 'compile.command.json', 'compile.result.json', 'compile.stdout.log', 'compile.stderr.log')]
files = list(dict.fromkeys(files))
for path in files:
    if path.suffix.lower() in ('.obj', '.exe', '.dll', '.pdb', '.bin') or not path.is_file():
        raise RuntimeError('Archive excludes binary weights/objects and requires every exact file: ' + str(path))
if O.exists() or O.with_suffix('.zip').exists():
    raise RuntimeError('Preserve published evidence immutably')
with zipfile.ZipFile(O.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        archive.write(path, path.relative_to(R).as_posix())
proof = dict(date='2026-10-24', archive=identity(O.with_suffix('.zip')),
    common_flash_binding=dict(status='applied-and-full-consumer-compiled', source=record['source'],
        compile_record=identity(compile_record), original_B12_B13_pins_enabled=False,
        new_controller=False, new_global_cache=False, static_source_shared_by_three_stages=True,
        observer='Original packed bytes and actual intermediate/state inputs; NextN/target43/target44.',
        fixes=['Explicit namespace qualification removes geometry ADL ambiguity.', 'Distinct local name removes /WX shadow warning.'],
        original_B12_B13_execution=False),
    packed_tail=dict(status='candidate-native-checked-canonical-merge-pending',
        hardware=dict(name='NVIDIA GeForce RTX 4070', driver='617.14', memory_total_MiB=12282),
        process_exit=0, tests=4, failures=0, skips=0, generated_only_not_B07=True,
        K=8192, N=248320, original_Q8_layout_bytes=2161377280,
        actual_tail_block_offset=2161377246, actual_batches=[1, 2], all_logits_checked=True,
        declared_workspace_bytes={'M1': int(properties['generated_q8_workspace_M1']), 'M2': int(properties['generated_q8_workspace_M2'])},
        no_full_F32_shadow_basis='Retained F32/K%512/small-batch native MMVQ dispatch and typed packed-block addressing; workspace is not a physical-memory measurement.',
        run=identity(run / 'summary.json'), result=identity(run / 'gtest.xml')),
    original_identity_count_unchanged=16, original_identity_total=25,
    remaining=['Actual independent B12/B13 headers, static pins and selected expert bodies.',
        'Actual original-weight CPU/CUDA state execution for B12/B13 and B07.',
        'Apply packed-tail and codec-specific Orin cold facts after priority Q09/Q10 runs; refresh only affected host objects.',
        'Orin hardware is unavailable; neither this 4070 check nor source review is an Orin execution result.'],
    throughput_evidence=False, physical_memory_evidence=False,
    repository_sources=[identity(R / x) for x in sources], archive_files=[identity(x) for x in files])
O.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(proof=identity(O), archive=identity(O.with_suffix('.zip')))))
