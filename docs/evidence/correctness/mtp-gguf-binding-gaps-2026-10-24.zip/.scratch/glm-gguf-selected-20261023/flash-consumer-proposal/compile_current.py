"""Compile the actual common Flash consumer TU, with existing genuine Q30 pins.

No B12/B13 pins are fabricated or enabled. This is a build, not an original
artifact execution. Existing Graph/provider/SDK objects are not rebuilt.
"""
from pathlib import Path
import importlib.util
import argparse
import json
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

c = module('flash_consumer_current_closure', R / '.scratch/glm-gguf-selected-20261023/B10/native-integration/build.py')
h = c.helpers()
recipe = R / '.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/consumer1/records/flash-state-attempt2/identity.json'
h.S = S
h.SOURCES = {'flash-state': R / 'tests/compute_models/glm_mtp_state_consumer_test.cc'}
h.RECIPES = {'flash-state': recipe}
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', type=int, default=1)
args = parser.parse_args()
h.compile_one('flash-state', args.attempt)
path = S / ('compile' + str(args.attempt)) / 'flash-state/identity.json'
record = c.check_record(path)
record.update(scope='Actual full common Flash consumer compilation; genuine existing Q30 pins only. B12/B13 original data execution remains pending.',
              tool=c.identity(Path(__file__)), new_consumer_TUs=1,
              SDK_builds=0, NVCC_builds=0, product_TUs=0)
c.save(path, record)
print('COMPILED full common Flash consumer; no B12/B13 original execution claimed', flush=True)
