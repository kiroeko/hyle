"""One fixed-state diagnostic process; no speed or physical-memory claim."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
R=B.parents[1]
s=importlib.util.spec_from_file_location('build',B/'build_hyle.py')
h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
b,c=h.b,h.c
ready=c.read(B/'mtp_session-ready-attempt1.json')
assert all(h.same(ready[k])for k in('image','source','main'))
out=B/'probe-run1';out.mkdir(exist_ok=False)
command=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),
 '--scenario','numerics','--output',str(out/'vectors')]
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
c.save(out/'plan.json',dict(command=command,ready=ready,diagnostic=True,performance_evidence=False))
c.execute('run',command,env,out)
print('TERMINAL: fixed-state numerics diagnostic completed.',flush=True)
