"""Read only named AA ZIP payloads via their canonical archive mapping."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
S = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'docs/evidence/correctness/qwen-mtp-batch-2026-10-22.json'
ARCHIVE = MANIFEST.with_name('qwen-mtp-batch-2026-10-22.data.zip')
OLD = '.scratch/qwen-mtp-batch-20261022/'
VOCAB = 248320
entries = json.loads(MANIFEST.read_text())['archive_files']
mapping = {e['path'].replace('\\', '/').split('/hyle/', 1)[1]: e for e in entries}
READ = {}
CACHE = {}


def payload(z, original):
    e = mapping[original]
    if e['entry'] not in CACHE:
        b = z.read(e['entry'])
        assert len(b) == e['bytes'] and hashlib.sha256(b).hexdigest() == e['sha256']
        CACHE[e['entry']] = b
    b = CACHE[e['entry']]
    assert hashlib.sha256(b).hexdigest() == e['sha256']
    READ[original] = {k: e[k] for k in ('entry', 'bytes', 'sha256')}
    return b


def obj(z, original):
    return json.loads(payload(z, original))


def vector(z, original):
    b = payload(z, original)
    if original.endswith('.bf16'):
        return (np.frombuffer(b, '<u2').astype(np.uint32) << 16).view(np.float32).reshape(-1, 2048)
    return np.frombuffer(b, '<f4').reshape(-1, VOCAB)


def metric(a, b):
    assert a.shape == b.shape
    x, y = a.astype(np.float64), b.astype(np.float64)
    finite = np.isfinite(x) & np.isfinite(y)
    diff = y - x
    idx = int(np.argmax(np.abs(diff)))
    den = float(np.linalg.norm(x))
    return {'elements': a.size, 'nonfinite_left': int((~np.isfinite(x)).sum()), 'nonfinite_right': int((~np.isfinite(y)).sum()),
            'differing_elements': int(np.count_nonzero(a != b)), 'max_abs': float(np.max(np.abs(diff))),
            'relative_l2': float(np.linalg.norm(diff) / den) if den else None,
            'max_abs_element': idx, 'left_at_max': float(x.flat[idx]), 'right_at_max': float(y.flat[idx])}


def top(row, other_ids):
    # Descending score, lower original ID for exact ties, independently of GPU selection.
    order = np.lexsort((np.arange(row.size), -row))[:5]
    tied = np.flatnonzero(row == row[order[0]])
    return {'argmax_lowest_id': int(order[0]), 'top5': [{'id': int(i), 'value': float(row[i])} for i in order],
            'top2_margin': float(row[order[0]] - row[order[1]]), 'equal_top_count': int(tied.size),
            'competing_ids': {str(i): float(row[i]) for i in sorted(set(other_ids))}}


def bf16_rne(value):
    # Select the closest BF16 to the F64 dot, with even low BF16 bit on a tie.
    # Checking neighbours avoids silently assuming a prior F32 rounding step.
    bits = int(np.array(value, dtype=np.float32).view(np.uint32)) & 0xffff0000
    candidates = [(b, float(np.array(b, dtype=np.uint32).view(np.float32)))
                  for b in (bits - 0x10000, bits, bits + 0x10000)]
    best = min(candidates, key=lambda item: (abs(item[1] - value), (item[0] >> 16) & 1))
    return best[1]


def projection_check(z, cases):
    manifest = ROOT / '.scratch/qwen-mtp-weights-20261022/prepared/weights.tsv'
    lines = manifest.read_text().splitlines()
    fields = next(line.split('\t') for line in lines if line.startswith('model.language_model.embed_tokens.weight\t'))
    assert fields[1:5] == ['BF16', '2', str(VOCAB), '2048']
    offset, length = map(int, fields[5:])
    shard = Path(lines[1]); assert shard.stat().st_size >= offset + length
    row_data = {}; row_identities = []
    with shard.open('rb') as f:
        header_bytes = int.from_bytes(f.read(8), 'little')
        header = json.loads(f.read(header_bytes))
        tensor = header[fields[0]]
        assert tensor['dtype'] == 'BF16' and tensor['shape'] == [VOCAB, 2048]
        assert 8 + header_bytes + tensor['data_offsets'][0] == offset
        assert tensor['data_offsets'][1] - tensor['data_offsets'][0] == length
        for token in (198, 271):
            begin = offset + token * 4096
            f.seek(begin); data = f.read(4096); assert len(data) == 4096
            row_data[token] = ((np.frombuffer(data, '<u2').astype(np.uint32) << 16).view(np.float32)).astype(np.float64)
            assert np.isfinite(row_data[token]).all()
            row_identities.append({'token': token, 'absolute_offset': begin, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    checks = []
    for case, trace, row_index in [(cases[0], 'mtp3', 1), (cases[1], 'round2_mtp2', 0)]:
        for arm in (case['left_arm'], case['right_arm']):
            sid = case['session']; parsed = obj(z, OLD + f'cli-runs1/{arm}/parsed.json')
            index = next(i for i, s in enumerate(parsed['sessions']) if s['session_id'] == sid)
            base = OLD + f'cli-runs1/{arm}/trace/session{index}_{sid}/{trace}/'
            h = vector(z, base + 'hidden.bf16')[row_index].astype(np.float64)
            logits = vector(z, base + 'logits.f32')[row_index]
            values = []
            for token, weight in row_data.items():
                dot = float(np.dot(h, weight)); rounded = bf16_rne(dot); actual = float(logits[token])
                values.append({'token': token, 'fp64_dot': dot, 'bf16_rne_of_fp64_dot': rounded,
                               'actual_logit': actual, 'actual_minus_fp64_dot': actual - dot,
                               'actual_matches_bf16_rne_of_fp64_dot': actual == rounded})
            checks.append({'arm': arm, 'session': sid, 'trace': trace, 'row': row_index, 'values': values,
                           'fp64_dot_margin_271_minus_198': values[1]['fp64_dot'] - values[0]['fp64_dot']})
    return {'scope': 'Two original BF16 tied-embedding rows only, against the two archived differing target rows in each arm.',
            'manifest': str(manifest.relative_to(ROOT)), 'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
            'recorded_artifact_identity': lines[2], 'original_shard': str(shard), 'shard_bytes': shard.stat().st_size,
            'shard_full_hash_recomputed': False, 'header_bytes_read': 8 + header_bytes,
            'row_bytes_read': 8192, 'weight_rows': row_identities, 'checks': checks,
            'meaning': 'Finite last-projection arithmetic check only. Inputs are actual rounded hiddenBF16 and original weightBF16; this is not an independent full-model reference or a precision policy change.'}


def batch_for(p, sid, wanted):
    remaining = {s['session_id']: [x for x in s['ledger'] if not x['imported']] for s in p['sessions']}
    cursor = {s: 0 for s in remaining}
    for batch in p['batches']:
        for member in batch['session_ids']:
            record = remaining[member][cursor[member]]; cursor[member] += 1
            if member == sid and record['index'] == wanted:
                return batch
    raise AssertionError((sid, wanted))


def episode(z, left, right, sid, trace, competitors):
    li = next(i for i, s in enumerate(left['sessions']) if s['session_id'] == sid)
    ri = next(i for i, s in enumerate(right['sessions']) if s['session_id'] == sid)
    le = next(x for x in left['sessions'][li]['ledger'] if x['trace_name'] == trace)
    re = next(x for x in right['sessions'][ri]['ledger'] if x['trace_name'] == trace)
    bases = [OLD + f'cli-runs1/{arm}/trace/session{i}_{sid}/{trace}/' for arm, i in [(left['_arm'], li), (right['_arm'], ri)]]
    ha, hb = [vector(z, b + 'hidden.bf16') for b in bases]
    la, lb = [vector(z, b + 'logits.f32') for b in bases]
    assert ha.shape[0] == la.shape[0] == hb.shape[0] == lb.shape[0]
    rows = []
    for j in range(la.shape[0]):
        ids = [e['target_first'] if j == 0 else e['target_second'] for e in (le, re)]
        # Multirow prefill exports only its selected last row, unlike generation verify.
        if not le['generation']:
            ids = [le['next_id'], re['next_id']]
        lt, rt = top(la[j], competitors + ids), top(lb[j], competitors + ids)
        assert ids[0] == lt['argmax_lowest_id'] and ids[1] == rt['argmax_lowest_id']
        rows.append({'row': j, 'actual_selected_ids': ids, 'hidden': metric(ha[j], hb[j]), 'logits': metric(la[j], lb[j]),
                     'left_top': lt, 'right_top': rt})
    keys = ('index', 'role', 'requests', 'member_index', 'generation', 'first_input', 'input_hash', 'input_rows', 'quota',
            'before_length', 'before_frontier', 'before_lag', 'before_next_id', 'draft', 'target_first', 'target_second',
            'accepted', 'committed_input_ids', 'after_length', 'after_frontier', 'after_lag', 'next_id')
    return {'trace_name': trace, 'left_record': {k: le[k] for k in keys}, 'right_record': {k: re[k] for k in keys},
            'left_batch': batch_for(left, sid, le['index']), 'right_batch': batch_for(right, sid, re['index']),
            'same_token_input_hash': le['input_hash'] == re['input_hash'],
            'same_declared_L_D_lag': all(le[k] == re[k] for k in ('before_length', 'before_frontier', 'before_lag')),
            'prior_complete_state_bytes_recorded_in_this_CLI_trace': False,
            'initial_zero_origin_by_source_contract': le['before_length'] == 0,
            'selected_hidden_rows': ha.shape[0], 'rows': rows}


def main():
    cases = []
    with ZipFile(ARCHIVE) as z:
        for description, larm, rarm, sid, names, competitors in [
            ('main A first sixth-output divergence', 'r1-resident', 'r2-resident', 'A', ['prefill', 'mtp1', 'mtp2', 'mtp3'], [271, 198]),
            ('warm B first fifth-output divergence', 'r1-warm', 'r2-warm', 'B', ['prefill', 'mtp1', 'round2_prefill', 'round2_mtp2'], [271, 198])]:
            left, right = [obj(z, OLD + f'cli-runs1/{arm}/parsed.json') for arm in (larm, rarm)]
            left['_arm'], right['_arm'] = larm, rarm
            lo = next(s['result']['generated_ids'] for s in left['sessions'] if s['session_id'] == sid)
            ro = next(s['result']['generated_ids'] for s in right['sessions'] if s['session_id'] == sid)
            first = next(i for i, (a, b) in enumerate(zip(lo, ro)) if a != b)
            observations = [episode(z, left, right, sid, name, competitors) for name in names]
            earliest = next({'episode': e['trace_name'], 'row': row['row'], 'hidden': row['hidden'], 'logits': row['logits']}
                            for e in observations for row in e['rows'] if row['hidden']['differing_elements'] or row['logits']['differing_elements'])
            cases.append({'case': description, 'session': sid, 'left_arm': larm, 'right_arm': rarm,
                          'first_output_difference': {'index_zero_based': first, 'ordinal': first + 1, 'left_id': lo[first], 'right_id': ro[first]},
                          'first_archived_observed_error': earliest, 'episodes': observations})
        projection = projection_check(z, cases)
    report = {
        'status': 'FINITE_SCOPED_CROSS_GEOMETRY_OBSERVATIONS; no correctness side selected',
        'source': {'main_sha256': 'fec0ae846af8cac287bf590a6dbaec69cc3879634aaf50406764a8870b494ce7', 'main_bytes': 270575},
        'archive': str(ARCHIVE.relative_to(ROOT)), 'mapping_manifest': str(MANIFEST.relative_to(ROOT)),
        'read_scope': {'original_paths_read': len(READ), 'unique_canonical_entries_read': len(CACHE),
                       'unique_uncompressed_bytes_read': sum(len(b) for b in CACHE.values()), 'full_archive_extracted': False,
                       'all_archive_CRC_or_SHA_rescan': False},
        'cases': cases, 'last_projection_check': projection, 'selected_original_to_canonical': READ,
        'interpretation': [
            'Every archived target row selected ID equals an independent lowest-ID argmax of its own full F32 logits. The selected GPU decisions are consistent with their archived scores.',
            'Both cases already differ in the initial prompt last normalized hidden/logits, before any output ID differs. Same token sequence, role and L/D/lag do not establish identical prior conv/GDN/KV/draft/carry tensors.',
            'At main A mtp3 both arms consume pending271 and draft248068 at L18/D18/lag0, but the request width is R1 versus R2 and their earlier hidden/logits were already different. Target row1 emits 271 versus198. No isolated current-call or specific kernel cause is proved.',
            'At warm B the old history and actual warm prompt token hash agree, but warm target/carry and draft history may already differ. The report quantifies observations without calling one R geometry incorrect or assigning an invented quality threshold.'
            , 'The two selected original BF16 weight rows independently reproduce every one of the eight differing-call candidate logits after BF16 RNE. Before that rounding, candidate271 exceeds candidate198 in all four F64 dots; this is only a two-candidate last-projection observation, not a full-vocabulary F64 argmax or independent model quality result.'
            , 'Initial prefill starts at source-defined zero/empty state in both arms and already has different final hidden/logits under R1 versus R2. At the later ID flip, complete prior tensors are not recorded in these CLI traces, so equal token history cannot isolate the current round from accumulated shape-sensitive arithmetic.'
        ],
        'next_minimal_control': {
            'scope': 'One original MTP episode from the same immutable complete input Snapshot, once R1 and once R2 with a fixed real partner; no new model/executor/padding.',
            'setup': 'Choose the main A pre-mtp3 complete L18/D18/lag0 head and retain it. Fork two Sessions from that exact Snapshot; preserve an actual fixed partner head for R2. Cold-plan only actual R1/R2 role3 T2 shapes and enough N/R owners. Use the same emitted pending271 and quota4, original Model/Queue/prepare-submit-finish path.',
            'observations': 'Verify old full head bytes unchanged. Record fresh draft IDs and both target hidden/logits rows, top2 margins and per-member boundaries; do not force a draft. If fresh draft IDs differ, target row1 no longer has equal input and cannot isolate target arithmetic alone.',
            'meaning': 'Same full input head removes accumulated state differences. A remaining difference measures current execution-geometry sensitivity; absence of the observed flip shows accumulated prior numerical state matters. Neither outcome alone establishes model quality or which result is correct.',
            'optional_followup_only_if_needed': 'Use each of the two actually different historical heads under one fixed geometry to separate prior-state contribution. This is a second control, not a reason to rerun a full matrix.',
            'budget': 'Keep all retained originals/forks/partner and actual candidates inside the existing finite N+R plan; a debug Snapshot pin is an external owner and cannot be ignored for admission.'
        },
        'limitations': ['Only named last-hidden/target-logit payloads and their small parsed ledgers were opened. Full layer/KV/RNN/carry state is not present in CLI decisions traces.',
                        'The first archived difference is a final normalized hidden boundary; it is not localization of the first divergent internal layer or operator.',
                        'MTP draft logits are not exported by these CLI traces; draft IDs are real ledger observations, not independently re-argmaxed here.',
                        'No product changes, build, native/GPU/model run, numerical threshold, throughput claim or independent quality acceptance.']
    }
    out = S / 'review/first-divergence.json'
    out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'report': str(out), 'bytes': out.stat().st_size, 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'read_scope': report['read_scope']}))
    for c in cases:
        print(c['case'], c['first_output_difference'])
        for e in c['episodes']:
            print(e['trace_name'], [{'row': x['row'], 'hidden_maxabs': x['hidden']['max_abs'], 'hidden_relL2': x['hidden']['relative_l2'],
                                    'logits_maxabs': x['logits']['max_abs'], 'logits_relL2': x['logits']['relative_l2'],
                                    'top': [x['left_top']['top5'][:2], x['right_top']['top5'][:2]],
                                    'margin': [x['left_top']['top2_margin'], x['right_top']['top2_margin']]} for x in e['rows']])
    print('last projection', projection['checks'])


if __name__ == '__main__':
    main()
