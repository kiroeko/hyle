"""Read retained W ZIP/source facts; no native process or model computation."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import re
import statistics
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
W = ".scratch/qwen-mtp-divergence-20261022"
MANIFEST = "docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json"
ARCHIVE = "docs/evidence/performance/qwen-mtp-divergence-2026-10-22.data.zip"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = (ROOT / path).read_bytes()
    return {"path": path, "bytes": len(data), "sha256": sha(data)}


def load(path):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


manifest = load(MANIFEST)
entry_manifest = {item["entry"]: item for item in manifest["archive_files"]}
archive = zipfile.ZipFile(ROOT / ARCHIVE)
read_entries = {}


def read_entry(entry):
    # ZipFile.read also verifies the entry CRC. Bind every selected entry to
    # the published SHA, rather than trusting a similarly named live scratch.
    data = archive.read(entry)
    expected = entry_manifest[entry]
    assert len(data) == expected["bytes"] and sha(data) == expected["sha256"], entry
    info = archive.getinfo(entry)
    read_entries[entry] = {"entry": entry, "bytes": len(data), "sha256": sha(data), "crc32": f"{info.CRC:08x}"}
    return data


fixed_main_entry = W + "/compile1/qwen/source/tools/qwen35_text/main.cc"
fixed_main = read_entry(fixed_main_entry)
assert sha(fixed_main) == "c6dc3d58a6b6bad811226fd972b6588b0507cd0901c8168c3f785a186306b71a"
link_plan = json.loads(read_entry(W + "/qwen-link1/link-plan.json"))
link_inputs = {item["path"]: item for item in link_plan["inputs"]}
owner_specs = [
    ("executable", ".scratch/qwen-prefix-20261021/core-checks/diagnostic2/identity.json",
     ".scratch/qwen-prefix-20261021/perf-review/diagnostic/source/src/graph/executable.cc"),
    ("resources", ".scratch/qwen-mtp-round-20261022/compile1/resources/identity.json",
     ".scratch/qwen-mtp-round-20261022/compile1/resources/source/src/graph/resources.cc"),
    ("batch", ".scratch/qwen-mtp-round-20261022/compile1/batch/identity.json",
     ".scratch/qwen-mtp-round-20261022/compile1/batch/source/src/graph_batch/batch.cc"),
    ("append", ".scratch/qwen-mtp-round-20261022/compile1/append/identity.json",
     ".scratch/qwen-mtp-round-20261022/compile1/append/source/src/graph_batch/paged_append.cc"),
]
owner_proofs = []
for label, record, frozen in owner_specs:
    d = load(record)
    actual = identity(frozen)
    assert actual["sha256"] == d["source"]["sha256"] and actual["bytes"] == d["source"]["bytes"]
    assert link_inputs[d["object"]["path"]]["sha256"] == d["object"]["sha256"]
    owner_proofs.append({"owner": label, "compiled_identity": identity(record),
                         "source_snapshot": actual, "linked_object_record": d["object"]})


def parse_run(folder):
    root = W + "/performance/timing/" + folder
    text = read_entry(root + "/stderr.log").decode("utf-8")
    result = json.loads(read_entry(root + "/stdout.log"))
    prepared = [dict(re.findall(r"(\w+)=([^\s]+)", line))
                for line in text.splitlines() if line.startswith("prepared ")]
    assert len(prepared) == 35 and len(result["rounds"]) == 34
    assert int(prepared[0]["T"]) == 154 and prepared[0]["replay"] == "commands"
    length, draft, lag = 154, 154, 0
    seen = set()
    groups = defaultdict(lambda: {"calls": 0, "recorded_ranges": 0, "reused_ranges": 0, "cold_batch_seconds": 0.0})
    events = []
    pattern = []
    first_cold = extra_cold = zero_cold = 0.0
    for ordinal, (p, decision) in enumerate(zip(prepared[1:], result["rounds"]), 1):
        assert int(p["T"]) == 2 and p["replay"] == "hybrid"
        assert decision["draft_rows"] == 1 + lag
        role = "kMtpCatchupRound" if lag else "kMtpRound"
        # In this frozen successful sequence prefill uses initial parity0,
        # then each complete transaction flips once, including reject1.
        slot = ordinal % 2
        pair = (role, slot)
        first = pair not in seen
        seen.add(pair)
        recorded, reused = int(p["capture_recorded"]), int(p["capture_reused"])
        assert recorded + reused == 2
        cold = float(p["cold_batch_seconds"])
        group = groups[pair]
        group["calls"] += 1
        group["recorded_ranges"] += recorded
        group["reused_ranges"] += reused
        group["cold_batch_seconds"] += cold
        if first:
            assert recorded == 2
            first_cold += cold
        elif recorded:
            extra_cold += cold
        else:
            zero_cold += cold
        accepted = decision["committed_target_rows"]
        assert accepted == (2 if decision["accepted_draft"] else 1)
        assert int(p["visible"]) == length + accepted
        if recorded:
            events.append({"round": ordinal, "role": role, "slot": slot,
                           "first_role_slot": first, "recorded_ranges": recorded,
                           "reused_ranges": reused, "target_before": length,
                           "draft_before": draft, "lag_before": lag,
                           "target_tail_rows_before": length % 16,
                           "draft_tail_rows_before": draft % 16,
                           "target_page_count_after_verify": (length + 2 + 15) // 16,
                           "draft_page_count_after_work": (draft + 1 + lag + 15) // 16})
        pattern.append((role, slot, recorded, reused))
        draft += 1 + lag
        length += accepted
        lag = length - draft
        assert lag == (1 if decision["accepted_draft"] else 0)
    assert (length, draft, lag) == (217, 216, 1)
    assert sum(g["recorded_ranges"] for g in groups.values()) == 18
    assert sum(g["reused_ranges"] for g in groups.values()) == 50
    return {"folder": folder, "groups": [dict(role=k[0], slot=k[1], **v) for k, v in groups.items()],
            "cold_batch_seconds": {"all_decode": first_cold + extra_cold + zero_cold,
                                   "first_role_slot_calls": first_cold,
                                   "subsequent_recording_calls": extra_cold,
                                   "zero_record_calls": zero_cold},
            "recording_events": events}, pattern


current_runs = []
patterns = []
for folder in ("02-after_MTP", "04-after_MTP", "09-after_MTP"):
    r, pattern = parse_run(folder)
    current_runs.append(r)
    patterns.append(pattern)
before_patterns = []
for folder in ("01-before_MTP", "06-before_MTP", "08-before_MTP"):
    r, pattern = parse_run(folder)
    before_patterns.append(pattern)
assert all(x == patterns[0] for x in patterns + before_patterns)


def anchor(path, line, fact):
    return {"path": path, "line": line, "fact": fact}


flashinfer = identity("src/compute_provider_flashinfer/flashinfer_provider.cc")
assert flashinfer["sha256"] == "7f7d4d036c187fd206955a61f9e9f7a7873d2ab56f4eb8ee6e5476f44f9674e7"
state_header = identity("tools/qwen35_text/session_state.h")
main_compile = load(W + "/compile1/qwen/identity.json")
state_dep = next(d for d in main_compile["dependencies"] if d["path"].endswith("\\session_state.h"))
assert state_dep["sha256"] == state_header["sha256"] == "9cd094e7778ff48567b87c2983e138597940b9683e63023409562d0e562c35cd"
report = {
    "status": "FROZEN_W_LOG_GROUPING_CONFIRMED; TEN_SUBSEQUENT_RANGES_NOT_UNIQUELY_ATTRIBUTABLE",
    "scope": "Only the published W carrier window and exact retained linked source owners. No new native execution, build, profiler or product change.",
    "authority": {"manifest": identity(MANIFEST), "archive_path": ARCHIVE,
                  "published_archive_identity": manifest["archives"][0],
                  "archive_validation": "Selected entries verified against published SHA/size and ZIP CRC; no whole archive extraction or SDK scan.",
                  "fixed_main": read_entries[fixed_main_entry], "owners": owner_proofs,
                  "flashinfer_source_matching_prior_frozen_review": flashinfer,
                  "state_plan_header_matching_W_compiled_dependency": state_header},
    "important_version_boundary": "18record/50reuse belongs to W main c6dc3d58 and its fixed single-session P154/64-output window. Current AA main is different. Shared Graph/batch/append source identities still match these linked owner snapshots, but this report does not transfer old counts to newer multi-session MTP images.",
    "proven": [
        "All three W after_MTP processes have the same 34 T2 decode calls, 18 recorded ranges and 50 reused ranges; all three before_MTP processes have the identical recording/reuse pattern.",
        "First actual role/slot pairs appear at rounds1/2/3/12 and each records two ranges: exactly8 initial ranges. This role/slot mapping is derived from frozen control flow and actual draft-row/acceptance ledger, not an unprinted slot label.",
        "The other10 ranges occur at rounds4(+1),7(+1),8(+1),10(+1),13(+2),14(+2),15(+2). Rounds16..34 all report0 recorded /2 reused, despite changing logical positions, page layouts and new lease episodes.",
        "No T1 fallback executes in this window. Each reused T2 role/slot keeps its compiled shape and caller IO/workspace carrier; ordinary input byte updates are not a new TensorView tuple. A new logical layout or lease generation alone therefore cannot explain every-step rerecording.",
        "Current logs identify neither which of the two ranges was removed nor the step/port/callback that removed it. The10 subsequent recordings remain a finite diagnostic target, not an established planner/cache bug."
    ],
    "after_runs": [{k: v for k, v in r.items() if k != "recording_events"} for r in current_runs],
    "common_recording_events": current_runs[0]["recording_events"],
    "cold_bucket_limit": "cold_batch_seconds includes layout/resource preparation, allocation, descriptor/batch updates, replay preparation and capture. Recording-call bucket sums are not capture self-time or removable cost and predict no TPS gain.",
    "state_and_carry_pool_boundary": {
        "fixed_window": {"N": 1, "R": 1, "candidate_boundaries": 2,
                         "state_blocks_per_history_or_recurrent_pool": 3,
                         "hidden_rows_in_carry_pool": 4},
        "formulas": {"state_slots": "N+2R", "hidden_slots": "2*(N+R)"},
        "anchors": [
            anchor("tools/qwen35_text/session_state.h", 56,
                   "Finite pool capacities are shared by the Model, not separate permanently pinned state buffers per role/Invocation slot."),
            anchor(W + "/current/tools/qwen35_text/main.cc", 958,
                   "Each layer's history/recurrent LeasePool is built once from state_slots; the shared hidden pool uses hidden_slots."),
            anchor(W + "/current/tools/qwen35_text/main.cc", 1773,
                   "A verify binds the committed old readers, then allocates genuine row1 and row0 history/recurrent output writers from those pools on each episode."),
            anchor(W + "/current/tools/qwen35_text/main.cc", 1786,
                   "Both carry row outputs receive new owned WriteLeases from the same finite hidden pool."),
            anchor(W + "/current/tools/qwen35_text/main.cc", 1919,
                   "Accept2 retains carry from row1 and prior from row0; accept1 retains carry from row0 and does not retain the rejected row1 as prior. The next role therefore consumes the actually selected head owners.")
        ],
        "interpretation": "Fixed capacity and a fixed role/Invocation slot do not imply that its old/new state or carry/prior ports use the same physical range as last time. Acceptance selects owners, and reclaimed pool ranges can be reused in a different order. Such a changed actual tuple would legitimately invalidate a covering recording. Conversely each new WriteLease/generation does not imply a changed tuple. W contains no pool block/offset/port history, so this is a concrete source-supported possibility, not attribution of any of the10 ranges. Do not retain otherwise dead head/permission owners merely to manufacture an address pattern."
    },
    "source_mechanisms": [
        anchor(W + "/current/tools/qwen35_text/main.cc", 1773,
               "Every verify binds prior state and allocates two genuine conv/GDN output boundaries. Carry/prior are selected from the actual accepted target row. Pool-backed physical addresses may or may not differ from the same role/slot's previous use; these addresses were not logged."),
        anchor("src/graph/executable.cc", 1103,
               "same_physical_tensor compares validity, full description, resource, native handle, offset and size, rather than ReadLease identity or generation."),
        anchor("src/graph/executable.cc", 1221,
               "prepare_command_bindings invalidates on missing actual-backend stable-identity proof, revision mismatch, changed physical input/output tuple, or owned/native imports requiring preparation. A truly changed carrier must invalidate its covering range."),
        anchor("src/graph/resources.cc", 310,
               "Selective unbind preserves dormant recordings only for actual stable bindings whose exact selected artifact borrows TensorViews only; bindings/owners and replay authority are still withdrawn."),
        anchor("src/graph/resources.cc", 841,
               "take/release can preserve native append/projected-reader recordings under their private positive proofs. Fresh permission withdrawal is not blanket command invalidation."),
        anchor("src/graph_batch/paged_append.cc", 429,
               "Descriptor words include resolved old-tail source IDs and new destination IDs. Changes upload data into an idle stable mirror; changed instruction contents alone need not change commands. Shared-to-split group, changed Queue/resource/capacity or changed mirror/arena tuple can replace a carrier and invalidate before replacement."),
        anchor("src/graph_batch/batch.cc", 355,
               "Native batch before_command_change invalidates the changed slot and all consumers of its metadata owner before mutation. Real schedule/workspace/metadata topology changes must retain this callback; mere layout-generation change is not proof such a callback occurred."),
        anchor("src/graph/executable.cc", 7888,
               "Invalidation increments the selected step revision and destroys only retained ranges covering that step. prepare_replay counts each still-retained range as reuse, otherwise records the missing range; counts do not identify the reason or denote kernels/whole Graphs.")
    ],
    "unproven_candidates_not_causes": [
        "Different accepted output boundary/pool address changes for recurrent state or carry/prior.",
        "Actual append descriptor carrier split/replacement as old partial-tail source mapping changes.",
        "Actual native attention schedule/workspace/metadata topology mutation, including a legitimate before_command_change callback.",
        "Owned native producer outputs or other physical ports changing during prepare_replay. The earlier independent Copy fixture diagnosis is not evidence that this W Model has the same failing port."
    ],
    "minimum_future_diagnostic": {
        "execution": "One existing deterministic W-compatible natural journey would suffice if root authorizes it later; no new workload matrix or performance claim is needed. This script does not run it.",
        "identity": [
            "episode ordinal, actual role, shape, Invocation slot address/index and pre/post retained range (step_begin, step_count)",
            "at invalidate_step_recording: selected step, revision before/after and first removing call-site/reason (port tuple / native-import / batch callback / append carrier / explicit reset)",
            "for a changed port: input/output ordinal, old/new full physical description plus resource/native_handle/offset/size; old/current native_inputs and stable_binding_identity flags",
            "for append: selected node/step, old/new mirror metadata tuple and bank tuple, group identity, split/reuse/upload branch, complete instruction-word fingerprint including old-tail coordinates",
            "for native batch callback: original slot and metadata_owner identity, exact layout generation, schedule/workspace topology facts and affected selected steps"
        ],
        "minimal_stages": "snapshot before state/append binds, after batch.prepare, after each append bind, after take/unbind, and inside prepare_command_bindings. Capture the first actual invalidation event rather than attributing later revision mismatches again.",
        "safety": "Use bounded scratch diagnostic records, print after the original host endpoint, never keep page leases/results alive for logging, never suppress before-change/retirement gates. Resource/lease identities may be logged for provenance but cannot authorize reuse."
    },
    "recommendation": "Do not change cache retention or native invalidation based on these aggregate logs. Preserve exact-tuple/stable-backend and real-retirement gates; obtain the first invalidating step/port or topology callback before selecting any further optimization.",
    "selected_archived_entries": list(read_entries.values()),
    "builds": 0, "GPU_runs": 0, "product_edits": 0
}
OUT.mkdir(parents=True, exist_ok=True)
path = OUT / "capture-causes.json"
path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
freeze = {"status": "SOURCE_AND_ARCHIVE_READ_ONLY_FREEZE", "report": identity(path.relative_to(ROOT).as_posix()),
          "script": identity(Path(__file__).relative_to(ROOT).as_posix())}
(OUT / "capture-causes-freeze.json").write_text(json.dumps(freeze, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": freeze["report"], "recorded": 18, "reused": 50,
                  "first_role_slot_ranges": 8, "subsequent_unattributed_ranges": 10}, ensure_ascii=False))
