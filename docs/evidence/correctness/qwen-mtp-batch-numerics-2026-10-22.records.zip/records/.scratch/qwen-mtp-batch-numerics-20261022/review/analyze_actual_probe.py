"""Offline AB numerical probe review. Reads each unique raw payload once."""
from pathlib import Path
import hashlib
import json
import math
import numpy as np

S = Path(__file__).resolve().parents[1]
R = S.parents[1]
DATA = S / 'probe-run1/vectors'
V = 248320
RAW = {}
CHECKS = 0


def check(value, label):
    global CHECKS
    CHECKS += 1
    if not value:
        raise AssertionError(label)


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def identity(p):
    b = p.read_bytes()
    return {'path': str(p.relative_to(R)).replace('\\', '/'), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def vector(record):
    p = Path(record['path']).resolve()
    check(p.is_relative_to(DATA.resolve()), 'raw record stays within actual new probe data')
    if p not in RAW:
        b = p.read_bytes()
        if record['dtype'] == 'BF16':
            a = (np.frombuffer(b, '<u2').astype(np.uint32) << 16).view(np.float32)
        else:
            check(record['dtype'] == 'F32', 'known numeric payload type')
            a = np.frombuffer(b, '<f4')
        RAW[p] = {'bytes': b, 'array': a, 'sha256': hashlib.sha256(b).hexdigest(), 'nonfinite': int((~np.isfinite(a)).sum())}
    value = RAW[p]
    check(len(value['bytes']) == record['bytes'], 'raw exact extent')
    check(value['nonfinite'] == 0, 'all actual raw elements finite')
    return value


def metrics(a, b):
    x, y = a['array'].astype(np.float64), b['array'].astype(np.float64)
    check(x.size == y.size, 'pair has equal real extent')
    delta = y - x
    squared, reference = float(np.dot(delta, delta)), float(np.dot(x, x))
    return {'elements': x.size, 'byte_equal': a['bytes'] == b['bytes'],
            'nonfinite_left': a['nonfinite'], 'nonfinite_right': b['nonfinite'],
            'max_abs': float(np.max(np.abs(delta))) if delta.size else 0.0,
            'squared_error': squared, 'reference_squared': reference,
            'relative_l2': math.sqrt(squared / reference) if reference else (0.0 if not squared else None)}


def category(name):
    if name.startswith('layer'):
        return 'conv' if '.conv.' in name else 'GDN'
    if name.startswith('target'): return 'target_KV'
    if name.startswith('draft'): return 'draft_KV'
    if name.startswith('output.'): return name.split('.')[1]
    return 'carry_prior'


def compare(left, right):
    la, ra = {x['name']: x for x in left['vectors']}, {x['name']: x for x in right['vectors']}
    check(la.keys() == ra.keys(), 'complete component set equal')
    rows = []
    for name in la:
        check(la[name]['dtype'] == ra[name]['dtype'], 'same component dtype')
        row = metrics(vector(la[name]), vector(ra[name])); row.update(name=name, category=category(name))
        rows.append(row)
    groups = {}
    for row in rows:
        group = groups.setdefault(row['category'], {'components': 0, 'byte_equal_components': 0, 'max_abs': 0, 'max_component_relative_l2': 0})
        group['components'] += 1; group['byte_equal_components'] += int(row['byte_equal'])
        group['max_abs'] = max(group['max_abs'], row['max_abs'])
        if row['relative_l2'] is not None: group['max_component_relative_l2'] = max(group['max_component_relative_l2'], row['relative_l2'])
    return {'left': left['label'], 'right': right['label'], 'components': len(rows),
            'byte_equal_components': sum(x['byte_equal'] for x in rows),
            'differing_names': [x['name'] for x in rows if not x['byte_equal']],
            'groups': groups, 'components_metrics': rows}


def top(row):
    order = np.lexsort((np.arange(row.size), -row))[:2]
    return {'argmax_lowest_id': int(order[0]), 'top2': [{'id': int(i), 'value': float(row[i])} for i in order],
            'margin': float(row[order[0]] - row[order[1]]), 'value198': float(row[198]), 'value271': float(row[271]),
            'equal_top_count': int(np.count_nonzero(row == row[order[0]]))}


def main():
    ready = read(S / 'mtp_session-ready-attempt1.json')
    receipt = read(S / 'probe-run1/run.result.json')
    check(receipt['terminal'] and receipt['exit'] == 0 and receipt['command'][0] == ready['image']['path'], 'actual terminal identity')
    check(ready['main']['sha256'] == 'fec0ae846af8cac287bf590a6dbaec69cc3879634aaf50406764a8870b494ce7', 'unchanged product main')
    check(identity(Path(ready['source']['path']))['sha256'] == ready['source']['sha256'], 'actual frozen probe source')
    for p in (S / 'compile1/mtp_session/compile.result.json', S / 'mtp_session-link1/link.result.json'):
        v = read(p); check(v['terminal'] and v['exit'] == 0, 'actual host compile/link terminal')
    obs = read(DATA / 'observation.json')
    check(obs['actual_graph_calls'] == 10 and len(obs['images']) == obs['image_count'] == 13 and not obs['skipped_controls'], '10 actual Graphs/13 images/no skip')
    check(obs['model_objects'] == 1 and obs['weight_tensors'] == 335 and obs['capacity'] == 64, 'same full real model')
    check(obs['resident_limit'] == 6 and obs['active_sequences'] == 2 and obs['peak_live_snapshot_versions'] == 5 and
          obs['final_live_snapshot_versions'] == 0 and obs['managed_backing_bytes'] == obs['planned_backing_bytes'] == 201408563, 'finite versions and exact backing budget')
    images = {x['label']: x for x in obs['images']}
    names = {f'layer{i}.{suffix}' for i in range(24) if i % 4 != 3 for suffix in ('conv.bf16', 'gdn.f32')}
    names |= {f'target{i}.{suffix}.bf16' for i in range(6) for suffix in ('key', 'value')}
    names |= {'draft.key.bf16', 'draft.value.bf16', 'carry.bf16', 'prior.bf16', 'output.logits.f32', 'output.hidden.bf16'}
    for image in images.values():
        check(len(image['vectors']) == 54 and {x['name'] for x in image['vectors']} == names, 'full54=52 state+2 outputs')
        m = image['metadata']; check(m['length'] - m['draft_frontier'] == m['lag'], 'real frontier/lag')
        for record in image['vectors']: vector(record)
    episodes = {e['name']: e for e in obs['episodes']}
    logits_rows = []
    for label, image in images.items():
        episode = episodes[label]; r = episode['record']; m = image['metadata']
        check(r['committed'] and m['length'] == r['after']['length'] and m['draft_frontier'] == r['after']['frontier'] and m['lag'] == r['after']['lag'] and m['next_id'] == r['after']['next_id'], 'image bound to actual committed ledger')
        record = next(x for x in image['vectors'] if x['name'] == 'output.logits.f32')
        rows = vector(record)['array'].reshape(-1, V)
        ids = [r['target_first'], r['target_second']] if r['generation'] else [r['target_first']]
        check(len(ids) == rows.shape[0], 'real published target rows')
        for i, (row, expected) in enumerate(zip(rows, ids)):
            scores = top(row); check(scores['argmax_lowest_id'] == expected, 'own target logits agree with actual selected ID')
            logits_rows.append({'image': label, 'row': i, 'selected_id': expected, **scores})
        check(episode['requests'] in (1, 2) and episode['member_index'] < episode['requests'], 'true member geometry')
        if r['generation']:
            check(r['inputs'] == [r['before']['next_id']], 'actual chosen pending for these controls')
            accepted = r['draft'] == r['target_first'] and r['quota'] >= 2 and r['target_first'] not in (248044, 248046)
            check(r['accepted_tokens'] == 1 + int(accepted), 'actual fresh natural acceptance')
    pairs = [
        ('seed_R1', 'seed_R2_0'), ('seed_R2_0', 'seed_R2_1'),
        ('source0_R1_step0', 'source1_R1_step0'), ('source0_R1_step1', 'source1_R1_step1'),
        ('control_source0_R1', 'control_source0_R2_member0'), ('control_source0_R2_member0', 'control_source0_R2_member1'),
        ('control_source1_R1', 'control_source1_R2_member0'), ('control_source1_R2_member0', 'control_source1_R2_member1')]
    comparisons = [compare(images[a], images[b]) for a, b in pairs]
    # Check every source-produced metric against actual canonical bytes. Aliases
    # are retained as aliases, never called independently stored second copies.
    for reported in obs['vectors']:
        a = RAW[Path(reported['baseline']).resolve()]; b = RAW[Path(reported['actual']).resolve()]
        actual = metrics(a, b)
        check(actual['byte_equal'] == reported['byte_equal'] and actual['max_abs'] == reported['max_abs'], 'reported byte/maxabs recomputes')
        for field in ('squared_error', 'reference_squared'):
            check(math.isclose(actual[field], reported[field], rel_tol=2e-12, abs_tol=1e-12), 'reported sum recomputes ' + field)
    controls = []
    for c in obs['controls']:
        source = c['source']; prefix = f'control_source{source}'
        check(c['same_old_snapshot_pointer'] and c['independent_R2_sessions'] and c['old_full52_bytes_unchanged'], 'actual same old Snapshot precondition')
        old = c['old_boundary']; check(old['length'] == old['draft_frontier'] == 18 and old['lag'] == 0 and c['pending'] == 271, 'natural old boundary')
        equal_inputs = c['R1_draft'] == c['R2_drafts'][0] == c['R2_drafts'][1]
        check(equal_inputs == c['target_two_rows_use_identical_inputs'], 'target equality conditional on actual fresh proposal')
        comparison = next(x for x in comparisons if x['left'] == prefix + '_R1')
        target = [x for x in comparison['components_metrics'] if x['category'] != 'draft_KV']
        check(equal_inputs and len(target) == 52 and all(x['byte_equal'] for x in target), 'target-related52 agree for this actual same-state/same-input control')
        controls.append({**c, 'full_image_byte_equal_components': comparison['byte_equal_components'],
                         'target_related_components_excluding_draft_KV': 52, 'target_related_all_byte_equal': True,
                         'draft_KV_metrics': [x for x in comparison['components_metrics'] if x['category'] == 'draft_KV']})
    check(obs['seed_full52_unchanged_checks'] == 2 and obs['control_full52_unchanged_checks'] == 4, 'actual original native full52 unchanged assertions')
    inventory = [{'path': str(p.relative_to(R)).replace('\\', '/'), 'bytes': len(v['bytes']), 'sha256': v['sha256'], 'nonfinite': v['nonfinite']} for p, v in RAW.items()]
    hash_path = S / 'review/actual-raw-identities.json'
    hash_path.write_text(json.dumps(inventory, indent=2) + '\n')
    report = {
        'status': 'PASS_SCOPED_ACTUAL_CONTROLS_AND_FINITE_RECOMPUTATION; no full-model numeric threshold',
        'scope': 'New AB numerics probe only. Old 36-path AA archive analysis was not rerun. No build/GPU/model/source edits.',
        'source': ready['source'], 'main': ready['main'], 'recorded_image': ready['image'],
        'receipt': identity(S / 'probe-run1/run.result.json'), 'observation': identity(DATA / 'observation.json'),
        'checks': CHECKS, 'actual_graph_calls': 10, 'image_count': 13, 'complete_components_per_image': 54,
        'component_definition': {'state52': '36 conv/GDN + 12 target KV + 2 draft KV + carry/prior (empty prior remains an explicit empty component)',
                                 'image54': 'state52 + target output logits/hidden',
                                 'target_related52': 'image54 minus draft KV2; do not call this all54 equal'},
        'raw_scope': {'image_component_references': 13 * 54, 'unique_payload_paths': len(RAW),
                      'bytes_read_once': sum(len(x['bytes']) for x in RAW.values()),
                      'nonfinite_unique_elements': sum(x['nonfinite'] for x in RAW.values()),
                      'canonical_alias_references': 13 * 54 - len(RAW), 'identity_manifest': identity(hash_path)},
        'budget': {k: obs[k] for k in ('capacity', 'resident_limit', 'active_sequences', 'peak_live_snapshot_versions', 'final_live_snapshot_versions', 'managed_backing_bytes', 'planned_backing_bytes')},
        'controls': controls, 'comparisons': comparisons, 'target_logit_rows': logits_rows,
        'conclusions': [
            'Both complete old-state controls met their natural L18/D18/lag0/pending271 prerequisites. The real source asserts exact shared Snapshot pointer and independent mutable R2 Sessions; no recomputation or forced proposal substitutes for those inputs.',
            'Within each fixed old-state control all fresh drafts were248068, so both target rows really consume [271,248068]. All52 target-related image components are byte-equal between R1 and R2; the two draft KV components differ. The full54 image is therefore not wholly byte-equal.',
            'source0 and source1 are different complete old states, derived from R1 versus R2 P15 and then two common R1 rounds. They share L/D/lag and emitted IDs but are not byte-equal inputs. Source0 selects [248068,271], source1 [248068,198] under both R1 and R2 control geometries.',
            'This actual control localizes the observed later target flip to the differing inherited state in these samples, rather than a remaining target difference caused solely by current R1/R2 width on one fixed input head. It does not prove all batch shapes, equal draft logits or a general error bound.',
            'Every selected target ID agrees with an independent argmax of its own complete archived logits; exact ties use the lower original token ID. No sampler-row mismatch is observed here.',
            'All new raw components are finite. Existing original-head full52 unchanged checks are source+successful-runtime assertions; canonical file aliases are not claimed as independent second raw payloads.'
        ],
        'limitations': ['No model quality gate, external full-model oracle, numerical tolerance, throughput comparison or claim that R2 is wrong.',
                        'A max/relative-L2 value is descriptive. Components have different physical meanings; no pooled whole-head metric is used as quality acceptance.',
                        'Same-state target equality is conditional on the actually equal fresh draft IDs. Different proposals would invalidate a same-target-row1-input claim.',
                        'Recorded managed backing is the preallocated state budget, not physical GPU peak; IO/workspace/runtime overhead is separate.',
                        'The readonly host pass verifies actual payload SHA/bytes/finite and reported metrics. Device-pointer sharing and old-native-head unchanged facts are tied to the frozen probe source and its exit0/observation, not inferred from equal metadata alone.']
    }
    out = S / 'review/actual-analysis.json'; out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'path': str(out), 'bytes': out.stat().st_size, 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'checks': CHECKS, 'unique_payloads': len(RAW)}))
    for p in comparisons:
        print(p['left'], 'vs', p['right'], p['byte_equal_components'], '/', p['components'], 'groups', p['groups'])


if __name__ == '__main__':
    main()
