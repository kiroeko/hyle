"""Publish finite same-Snapshot batch controls and bounded host research."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
B=Path(__file__).resolve().parent;R=B.parents[1];A=R/'.scratch/qwen-mtp-batch-20261022'
O=R/'docs/evidence/correctness';NAME='qwen-mtp-batch-numerics-2026-10-22'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for x in iter(lambda:f.read(8<<20),b''):h.update(x)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
sources=['tools/qwen35_text/'+n for n in ('main.cc','mtp_graph.h','mtp_session_probe.cc','README.md')]+['docs/developer/current-work.md']
frozen=[]
for name in sources:
 p=R/name;before=B/'before'/name
 if not before.exists():
  original=A/'current'/name;assert original.exists()and p.read_bytes()==original.read_bytes(),name
  before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(original.read_bytes())
 snapshot=B/'current'/name;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(p.read_bytes())
 diff=B/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
 diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
 check=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
 assert check.returncode in(0,1)and not(check.stdout.strip()or check.stderr.strip()),(name,check.stdout,check.stderr)
 frozen.append(dict(source=identity(p),snapshot=identity(snapshot),before=identity(before),diff=identity(diff)))
save(B/'product-freeze.json',dict(files=frozen))
ready=read(B/'mtp_session-ready-attempt1.json');current_cli=read(A/'qwen-ready-attempt1.json')
assert all(identity(v[k]['path'])==v[k]for v in(ready,current_cli)for k in('source','main','image'))
link=read(ready['link_plan']['path']);compiled=read(link['compiled_record']['path'])
assert len(link['inputs'])==195 and all(identity(d['path'])==d for d in compiled['dependencies'])
assert link['inputs'][1:]==read(link['base']['path'])['inputs'][1:]
obs=read(B/'probe-run1/vectors/observation.json');terminal=read(B/'probe-run1/run.result.json')
assert terminal['terminal']and terminal['exit']==0
assert obs['status']=='DIAGNOSTIC_COMPLETE_NUMERICAL_METRICS_ONLY'
assert obs['actual_graph_calls']==10 and obs['image_count']==13 and len(obs['images'])==13
assert all(len(i['vectors'])==54 for i in obs['images'])and not obs['skipped_controls']and not obs['extent_changes']
assert obs['final_live_snapshot_versions']==0 and obs['peak_live_snapshot_versions']==5
assert obs['managed_backing_bytes']==obs['planned_backing_bytes']==201408563
assert obs['seed_full52_unchanged_checks']==2 and obs['control_full52_unchanged_checks']==4
assert len(obs['controls'])==2 and all(c['same_old_snapshot_pointer']and c['target_two_rows_use_identical_inputs']for c in obs['controls'])
assert obs['controls'][0]['R1_target_ids']==[248068,271]and obs['controls'][1]['R1_target_ids']==[248068,198]
assert all(c['R2_target_ids']==[c['R1_target_ids']]*2 for c in obs['controls'])
reports={p.name:read(p)for p in sorted((B/'review').glob('*.json'))}
assert 'actual-analysis.json'in reports
actual=reports['actual-analysis.json'];assert str(actual['status']).startswith('PASS')
summary=dict(status='Finite identical-Snapshot CUDA MTP controls locate this A continuation divergence in existing prefill-state differences; no current-round target result-routing defect observed; full quality and broader goal remain open',date='2026-10-22',
 product_freeze=identity(B/'product-freeze.json'),ready=ready,current_CLI_unchanged=current_cli,
 build_scope=dict(host_compile_attempts=1,successful_host_compiles=1,successful_links=1,consumer_TUs=1,library_TUs=0,SDK_builds=0,NVCC_builds=0,full_configures=0,reused_link_inputs=194),
 actual_diagnostic_model_processes=1,actual_graph_calls=10,
 actual_run=dict(command=terminal['command'],terminal=identity(B/'probe-run1/run.result.json'),stdout=identity(B/'probe-run1/run.stdout.log'),stderr=identity(B/'probe-run1/run.stderr.log'),diagnostic=True,performance_evidence=False),
 observation=obs,reports=reports,performance_window_performed=False,
 findings=[
  'Only the existing mtp_session_probe.cc gains a numerics scenario; original main.cc, MTP helper and library execution remain unchanged. Existing scenarios retain their old code. One335-weight Model and original Graph/Queue/Completion/append/state mechanism execute all controls.',
  'One R1 P15 Graph and one real R2 P15 Graph create two actual source heads. Each source advances through two natural R1 MTP rounds to L18/D18/lag0/pending271. No draft, token, acceptance boundary or historical state is injected.',
  'Each source then lends the exact same complete immutable Snapshot pointer to independent R1 and R2 mutable Sessions. Both R2 members really share that same read-only source, use pending271 and naturally propose248068. Two target candidate rows therefore have identical actual inputs within each same-source comparison.',
  'For the R1-prefill source, both current widths produce target[248068,271]. For the R2-prefill source, both widths produce[248068,198]. Each same-source R1/R2 comparison has52/54 byte-equal components; only the two draft K/V payloads differ. Both identical-prefix members within each B2 are byte equal. The deciding output in this scene follows the old source state, not current width.',
  'Thirteen54-component state/output images and their raw numerical metrics are retained. Old source52 components are checked unchanged twice after seed derivation and four times after controls. Peak committed versions5 withinN6, final0, shared backing201408563B. This is not a physical GPU-memory peak.',
  'Independent bounded inspection of the previous AA archive observes differing hidden/logits already at P15 despite nextID198 matching. MainA first deciding row: R1 logits198/271=21.75/21.875; R2=22/22. WarmB first deciding row: R1=21.5/21.5; R2=21.5/21.625. Original GPU greedy IDs match their own actual rows and tie rule.',
  'For the eight selected198/271 scores, original BF16 hidden and two original BF16 weight rows are dotted independently in FP64; BF16 round-to-nearest-even reproduces all eight observed scores. This final-projection arithmetic check is not a full-model oracle or validation of upstream states.',
  'Ordinary MatMul retains same-dtype output; a F32 trace cast does not undo prior BF16 projection rounding. Existing public BFloatLinearF32 explicitly supports BF16 activation/weight to F32 scores and has a GGML CUDA route. It is a next candidate, not implemented or benchmarked by this batch; no new precision API or hidden dtype change is needed.',
  'Fixed old W logs consistently group8 first-role/slot capture ranges and10 later ranges; recording stops after round15 in all three after processes. Logs lack first-invalidating step/port/tuple, so the10 remain not uniquely attributable. Fixed pool geometry and changing lease objects alone do not prove a native address or topology change.',
  'All native activity here is one diagnostic process and one host-TU compile/link using194 unchanged inputs. No speed, physical-memory, other native backend or complete model-quality window was run. Latest current-work performance footer is unchanged.'],
 limitations=[
  'The same-Snapshot target equality applies to this fixed L18 scene, not every layer/shape, warm prompt, model/quantization or whole-model quality.',
  'Initial prefill state differences are real; the exact first differing kernel and acceptable full-model quality budget remain unproven. Current provider counts and source inspection do not establish identical native algorithms or physical accumulation.',
  'Draft K/V retain real cross-width differences. Same IDs or targets do not imply all MTP state byte invariance.',
  'The warmB tie explanation uses bounded archived logits/hidden, not a new same-oldstate warm-native control.',
  'Explicit F32 score projection changes the score-rounding contract. It needs its own numerical/work/performance check and cannot be introduced as a byte-preserving fusion.',
  'The10 later capture ranges belong to old W and are not transferred as counts to current AA/AB. Future diagnostics must observe actual first invalidation before choosing an optimization.',
  'Other backend/model/quant, image projection and the full architecture goal remain active.'],
 previous_evidence=['docs/evidence/correctness/qwen-mtp-batch-2026-10-22.json','docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json'],
 next_actions=['Explicitly evaluate the existing BF16-to-F32 terminal score projection contract while retaining BF16 weights/activations; compare real numerical decisions and appropriate four-metric windows.',
  'Obtain first actual capture-invalidating step/port identity before further cache changes; continue remaining backend/model/quant/image and architecture implementation.'])
save(B/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in B.rglob('*')if p.is_file()and p.suffix.lower()not in excluded
 and not any(x in('tmp','__pycache__')for x in p.relative_to(B).parts)
 and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1','postconditions.json'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[];unique={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);key=(e['bytes'],e['sha256']);canonical=unique.get(key)
  if canonical is None:canonical=p.relative_to(R).as_posix();unique[key]=canonical;z.write(p,canonical)
  else:e['identical_content_alias']=True
  e['entry']=canonical;entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(unique)
 for(size,sha),entry in unique.items():
  raw=z.read(entry);assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,
 archive_verified=dict(CRC=True,all_unique_entry_SHA256=True,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique),content_deduplication='Every source path retains identity and canonical entry; byte-identical payloads stored once.')))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(B/'published.json',published)
print(json.dumps(dict(**published,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique)),indent=2))
