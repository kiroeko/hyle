from pathlib import Path
import json,hashlib,subprocess,tarfile,time
O=Path('/Users/kiro/hyle-scratch/compute-unified/apple-sampling-mass-20261024/attempt1')
with tarfile.open(O/'source.tar.gz')as t:
 for m in t.getmembers():
  if not m.isfile()or Path(m.name).is_absolute()or'..'in Path(m.name).parts:raise RuntimeError('invalid archive member')
 t.extractall(O)
p=json.loads((O/'plan.json').read_text())
def ident(path):
 path=Path(path);return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
for f in p['files']:assert ident(O/'model'/f['relative'])['sha256']==f['sha256']
for f in p['cached_objects']+[p['new_memory']]:assert ident(f['path'])==f

def execute(tag,cmd):
 folder=O/tag;folder.mkdir(exist_ok=True);(folder/'command.json').write_text(json.dumps(dict(command=cmd),indent=2));t=time.monotonic()
 with(folder/'stdout.log').open('w')as a,(folder/'stderr.log').open('w')as b:r=subprocess.run(cmd,cwd=O,stdout=a,stderr=b,timeout=180)
 result=dict(exit=r.returncode,seconds=time.monotonic()-t);(folder/'process.json').write_text(json.dumps(result,indent=2));print(tag,result,flush=True)
 if r.returncode:print((folder/'stderr.log').read_text()[-5000:]);raise RuntimeError(tag)
execute('compile',p['command']);execute('link',p['link']);(O/'ready.json').write_text(json.dumps(dict(image=ident(O/'sampling-mass'),object=ident(O/'toy.o'),new_memory=p['new_memory'],SDK_builds=0,native_builds=0,HTTP=0),indent=2));execute('run',[str(O/'sampling-mass')]);print((O/'run/stdout.log').read_text());print((O/'run/stderr.log').read_text())
