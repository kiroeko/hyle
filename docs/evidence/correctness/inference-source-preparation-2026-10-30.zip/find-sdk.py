from pathlib import Path
import json

R=Path(__file__).resolve().parents[2]
base=json.loads((R/'.scratch/inference-view-storage-20261030/model-link-base.json').read_text())
sdk=json.loads(Path(base['sdk_engine_dependencies']['path']).read_text())
for item in sdk['inspected']:
    raw=json.loads(Path(item['dependencies']['path']).read_text(encoding='utf-8-sig'))['Data']
    if str(raw['Source']).lower().endswith('src\\graph_batch\\paged_append.cc'):
        print(json.dumps(item,ensure_ascii=False,indent=2))
