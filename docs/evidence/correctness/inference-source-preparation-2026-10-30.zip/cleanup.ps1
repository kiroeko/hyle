﻿param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-source-preparation-20261030'
$AllowedRoot = [IO.Path]::GetFullPath((Join-Path $TaskRoot 'bin'))
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
if ([IO.Path]::GetFullPath($Plan.root) -ne $AllowedRoot) { throw 'Unexpected cleanup root' }
foreach ($Receipt in Get-ChildItem -LiteralPath $TaskRoot -Filter 'process.json' -File -Recurse) {
    if ((Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json).state -ne 'TERMINAL') { throw "Process still running: $($Receipt.FullName)" }
}
foreach ($Entry in $Plan.files) {
    $TargetPath = [IO.Path]::GetFullPath($Entry.path)
    if ([IO.Path]::GetDirectoryName($TargetPath) -ne $AllowedRoot) { throw "Outside exact cleanup root: $TargetPath" }
    $Item = Get-Item -LiteralPath $TargetPath
    if ($Item.PSIsContainer -or ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not an ordinary file: $TargetPath" }
    if ($Item.Length -ne $Entry.bytes -or (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Entry.sha256) { throw "File identity changed: $TargetPath" }
}
if (-not $Execute) {
    [pscustomobject]@{Files=$Plan.files.Count; Bytes=$Plan.bytes; Root=$AllowedRoot}
    return
}
foreach ($Entry in $Plan.files) { Remove-Item -LiteralPath $Entry.path -Force }
$Report = [pscustomobject]@{status='COMPLETE'; files=$Plan.files.Count; bytes=$Plan.bytes; scope='Only this batch native images/link outputs and copied DLL; five current consumer objects, one refreshed GraphBatch object and 226 other SDK/engine inputs retained.'}
$Report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-report.json') -Encoding utf8
$Report
