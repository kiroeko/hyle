from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('batch',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin=b.read,b.save,b.pin


def report():
    plan=read(W/'plan.json')
    for unit in plan['units']:b.b.receipt(unit)
    for identity in plan['retained']:b.exact(identity)
    save(W/'model-link-base.json',dict(schema='hyle.source-preparation.current-link-base.v1',base=plan['base'],
        compile=plan['units']['model']['compile'],link=plan['units']['model']['link'],
        consumer_source=pin(plan['units']['model']['source']),previous_consumer=pin(W/'compile/model/receipt.json'),
        retained=plan['retained'],runtime=plan['runtime'],sdk_engine_dependencies=plan['sdk']))
    current=[]
    for case in plan['cases']:
        folder=W/'runs'/case/'attempt1';result=read(folder/'report.json');assert result['status']=='PASS'
        current.append(dict(case=case,report=pin(folder/'report.json'),process=read(folder/'process.json'),tests=result.get('tests')))
    comparisons=[]
    for case in ('natural-cuda','continuous-cuda'):
        prior=R/'.scratch/inference-view-storage-20261030/runs'/case/'attempt1/report.json'
        actual=W/'runs'/case/'attempt1/report.json';assert read(prior)==read(actual)
        comparisons.append(dict(case=case,previous=pin(prior),current=pin(actual),full_report_equal=True))
    processes=list(W.rglob('process.json'));assert all(read(p)['state']=='TERMINAL' for p in processes)
    counts={kind:len([p for p in processes if p.is_relative_to(W/directory)]) for kind,directory in
        [('CXX_attempts','compile'),('link_attempts','link'),('native_processes','runs')]}
    assert counts==dict(CXX_attempts=6,link_attempts=5,native_processes=5),counts
    files=[pin(p) for p in sorted((W/'bin').iterdir()) if p.is_file()]
    save(W/'cleanup-plan.json',dict(root=str(W/'bin'),files=files,bytes=sum(p['bytes'] for p in files)))
    changed=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
    sources=[R/p for p in changed if p.startswith(('src/','engine/','tests/'))]
    (W/'source.patch').write_bytes(subprocess.check_output(['git','diff','--',*[str(p.relative_to(R)) for p in sources]],cwd=R))
    evidence=dict(schema='hyle.correctness.source-preparation.v1',date='2026-10-30',status='PASS',
        base_commit=plan['worktree_base_commit'],sources=[pin(p) for p in sources],
        change='Use the actual single append target directly instead of allocating/sorting a temporary lookup; reuse the cold ordinary-input inventory after Source withdrawal instead of rebuilding it per successor.',
        invariants=[
            'A single target reads its current original page ID only during prepare. No identity, guard, ticket or version is cached across episodes.',
            'Zero and multiple targets preserve original membership results; multi-target lookup retains its original sorted vector and failure behavior.',
            'Original page owner, transaction/layout, footprint, inherited/ready prefixes, full and append tickets remain checked each episode.',
            'Imported Phase checks actual token/catchup and original Store Gather capacity/ID ports once against its ordinary inventory before publication.',
            'Runtime reader_binding and bind_outputs retain original source/generation/permission checks.',
            'release_consumers first withdraws Source and records bound=false, then releases the borrowed ordinary list; a late refusal retains incoming owner/predecessor for original recovery.',
            'No new pool/executor, per-step metadata mirror, relaxed Graph gate or input payload path.'],
        counts=dict(**counts,current_gtest_cases=10,custom_model_processes=3,SDK_CXX=1,unchanged_SDK_engine_inputs=226,
            NVCC=0,downloads=0,whole_builds=0,throughput_windows=0),
        current_runs=current,comparisons=comparisons,
        finite_relay_facts=read(W/'runs/relay-cuda/attempt1/report.json'),
        limits=[
            'No throughput claim or current host time attribution: removed allocation/scans are structural facts, not a measured speedup.',
            'Ordinary-input scan removal applies to modifier-bearing relays; default configurations already have an empty ordinary list.',
            'Directed page tests cover real single/multiple-target, COW and inherited pending/ready chains; no new native device-fault injection.',
            'Kimi7 includes original23-role components, not complete Kimi generation. No new CPU/Apple/Vulkan/multi-device run.',
            'Whole common engine orchestration, public Source interface convergence and performance milestones remain incomplete.'],
        cleanup_plan=read(W/'cleanup-plan.json'))
    save(W/'evidence.json',evidence)
    print(json.dumps(dict(counts=evidence['counts'],comparisons=comparisons,cleanup_bytes=evidence['cleanup_plan']['bytes'])))


def pack():
    evidence=read(W/'evidence.json');cleanup=read(W/'cleanup-report.json');assert cleanup['status']=='COMPLETE';evidence['cleanup']=cleanup
    stem=R/'docs/evidence/correctness/inference-source-preparation-2026-10-30';save(stem.with_suffix('.json'),evidence)
    with zipfile.ZipFile(stem.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or path.is_relative_to(W/'bin') or path.suffix.lower() in ('.obj','.pdb','.exe','.dll','.lib','.exp','.map'):continue
            archive.write(path,path.relative_to(W).as_posix())
    print(json.dumps(dict(evidence=pin(stem.with_suffix('.json')),archive=pin(stem.with_suffix('.zip')))))


if __name__=='__main__':{'report':report,'pack':pack}[sys.argv[1]]()
