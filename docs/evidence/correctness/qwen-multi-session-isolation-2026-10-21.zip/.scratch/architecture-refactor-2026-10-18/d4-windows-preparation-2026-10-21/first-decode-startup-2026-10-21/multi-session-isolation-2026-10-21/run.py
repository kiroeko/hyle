"""Root-only serial GPU state-isolation checks. No throughput evidence."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
F = S.parent
spec = importlib.util.spec_from_file_location('multiturn', F / 'multiturn/multiturn_run.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
RESUME = False


def run(folder, ready, extra, families=1):
    image = m.ready_image(ready)
    receipt = m.read(ready)
    environment = os.environ.copy()
    environment['PATH'] = m.read(receipt['runtime_environment']['path'])['PATH']
    original, _ = m.original_commands()
    command = [image['path'], '--inputs', original[original.index('--inputs') + 1],
               *extra, '--capacity', '256', '--progress', 'direct', '--replay', 'auto',
               '--trace', str(folder / 'trace'), '--trace-level', 'decisions']
    if folder.exists() and RESUME:
        completed = m.read(folder / 'result.json')
        assert completed['command'] == command and completed['image'] == image
        assert completed['exit'] == 0 and not completed.get('timeout')
        return m.read(folder / 'observation.json')
    folder.mkdir(parents=True, exist_ok=False)
    record = dict(command=command, cwd=str(m.ROOT), image=image, ready=m.identity(ready),
                  runtime_environment=m.identity(receipt['runtime_environment']['path']),
                  purpose='session isolation correctness', throughput_evidence=False,
                  gpu_concurrent_execution=False, started_unix_ns=time.time_ns())
    m.save(folder / 'command.json', record)
    process = None
    with (folder / 'stdout.log').open('wb') as so, (folder / 'stderr.log').open('wb') as se:
        try:
            process = subprocess.Popen(command, cwd=m.ROOT, env=environment, stdout=so,
                stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
            record['pid'] = process.pid
            try:
                record['exit'] = process.wait(timeout=180)
            except subprocess.TimeoutExpired:
                record['timeout'] = True
                process.kill()
                record['exit'] = process.wait()
        finally:
            if process is not None and process.poll() is None:
                process.kill()
                process.wait()
            record['finished_unix_ns'] = time.time_ns()
            m.save(folder / 'result.json', record)
    if record.get('exit') != 0 or record.get('timeout'):
        raise RuntimeError('Consumer failed, logs retained: ' + str(folder))
    lines = (folder / 'stdout.log').read_text(encoding='utf-8').splitlines()
    observation = json.loads(lines[-1])
    m.save(folder / 'observation.json', observation)
    stderr = (folder / 'stderr.log').read_text(encoding='utf-8')
    assert stderr.count('resident text weights: 320 tensors, 3763655360 bytes') == 1
    assert stderr.count('compile full text finite family variants=') == families
    return observation


def check_session(observation, case):
    assert observation['visible_tokens'] == case['processed_tokens']
    assert observation['processed_tokens'] == case['processed_tokens']
    assert observation['generated_tokens'] == case['generated_tokens']
    assert len(observation['generated_ids']) == len(case['calls']) == 9
    assert observation['phase_count'] == 4 and observation['turn_count'] == 2
    for index, phase in enumerate(observation['phases']):
        calls = [c for c in case['calls'] if c['phase'] == index]
        assert phase['calls'] == phase['generated_tokens'] == len(calls)
        assert phase['input_tokens'] == sum(len(c['ids']) for c in calls)
        assert phase['context_after'] == calls[-1]['visible_tokens']
        assert phase['context_before'] == calls[0]['visible_tokens'] - len(calls[0]['ids'])
    assert observation['decode_input_ids'] == [c['ids'][0] for c in case['calls'] if len(c['ids']) == 1]


def check_vectors(baseline, actual, calls):
    expected = {f"{c['name']}/{name}" for c in calls for name in ('hidden.bf16', 'logits.f32')}
    for path in (baseline, actual):
        found = {p.relative_to(path).as_posix() for p in path.rglob('*')
                 if p.is_file() and p.suffix in ('.bf16', '.f32')}
        assert found == expected, (str(path), sorted(found ^ expected))
    comparisons = []
    for relative in sorted(expected):
        a, b = baseline / relative, actual / relative
        ai, bi = m.identity(a), m.identity(b)
        same = a.read_bytes() == b.read_bytes()
        comparisons.append(dict(vector=relative, baseline=ai, actual=bi, byte_equal=same))
    return comparisons


def main():
    global RESUME
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    out = args.output.resolve()
    RESUME = args.resume
    if RESUME:
        previous = m.read(out / 'summary.json')
        m.save(out / 'summary-before-checker-fix.json', previous)
    else:
        out.mkdir(parents=True, exist_ok=False)
    plan = m.read(S / 'inputs/plan.json')
    new_ready = S / 'cli-ready-for-root.json'
    old_ready = F / 'layout-workspace-facts-reuse-2026-10-21/ready-for-root.json'
    new = m.read(new_ready)
    frozen = Path(new['image']['path']).parent / 'source/tools/qwen35_text/main.cc'
    assert m.identity(frozen)['sha256'] == new['source']['sha256']
    result = dict(passed=False, policy=plan['policy'], throughput_evidence=False,
                  new_ready=m.identity(new_ready), baseline_ready=m.identity(old_ready),
                  runner=m.identity(__file__), input_plan=m.identity(S / 'inputs/plan.json'),
                  input_files=[m.identity(p) for p in sorted((S / 'inputs').rglob('*')) if p.is_file()],
                  baseline_sessions={}, interleaved={})
    if RESUME:
        result['previous_summary'] = m.identity(out / 'summary-before-checker-fix.json')
        result['checker_correction'] = 'Decision vectors exclude routes/*.tsv metadata. Reuse only terminal exit-0 runs with exact command and image identity; no GPU rerun for completed cases.'
    m.save(out / 'summary.json', result)
    # Two-session check is a gate before the four-session workload.
    for count in (2, 4):
        target = plan['manifests'][str(count)]
        for session_id in target['session_ids']:
            if session_id in result['baseline_sessions']:
                continue
            case = plan['cases'][session_id]
            folder = out / 'baseline' / session_id
            observed = run(folder, old_ready, ['--schedule', case['schedule']['path']])
            check_session(observed, case)
            result['baseline_sessions'][session_id] = dict(folder=str(folder), generated_ids=observed['generated_ids'])
            m.save(out / 'summary.json', result)
            print('baseline ' + session_id + ' passed', flush=True)
        folder = out / f'interleaved{count}'
        observed = run(folder, new_ready, ['--session-schedules', target['manifest']['path'], '--max-sessions', '4'])
        assert observed['execution'] == 'round_robin_serial'
        assert observed['session_count'] == count
        assert observed['dispatch_session_ids'] == target['dispatch_order']
        assert observed['processed_tokens'] == target['processed_tokens']
        assert observed['generated_tokens'] == target['generated_tokens']
        assert [x['session_id'] for x in observed['sessions']] == target['session_ids']
        summary = dict(passed=False, session_count=count, vector_count=0, sessions={})
        for session in observed['sessions']:
            sid = session['session_id']
            case = plan['cases'][sid]
            check_session(session, case)
            assert session['generated_ids'] == result['baseline_sessions'][sid]['generated_ids']
            comparisons = check_vectors(out / 'baseline' / sid / 'trace',
                folder / 'trace' / session['trace_subdirectory'], case['calls'])
            summary['sessions'][sid] = dict(generated_ids=session['generated_ids'],
                visible_tokens=session['visible_tokens'], vectors=comparisons,
                passed=all(x['byte_equal'] for x in comparisons))
            summary['vector_count'] += len(comparisons)
        summary['passed'] = all(x['passed'] for x in summary['sessions'].values())
        result['interleaved'][str(count)] = summary
        m.save(out / 'summary.json', result)
        assert summary['passed'], 'Vector mismatch; retained actual/baseline logs and bytes'
        print(f'interleaved{count}: {summary["vector_count"]} vectors byte-identical', flush=True)
    result['passed'] = True
    result['gpu_model_processes'] = len(result['baseline_sessions']) + len(result['interleaved'])
    m.save(out / 'summary.json', result)


if __name__ == '__main__':
    main()
