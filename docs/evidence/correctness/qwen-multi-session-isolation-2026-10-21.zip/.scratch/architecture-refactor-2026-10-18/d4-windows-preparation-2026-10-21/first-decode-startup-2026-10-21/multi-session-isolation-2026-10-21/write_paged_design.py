from pathlib import Path
import hashlib
import json

D = Path(__file__).resolve().parent
R = next(p for p in D.parents if (p / 'AGENTS.md').is_file())

def source(path, ranges, fact):
    data = (R / path).read_bytes()
    return dict(path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), line_ranges=ranges, fact=fact)

report = dict(
    schema='hyle.paged-append.graph-design.v1', date='2026-10-21',
    scope='Source-only design. No main/product modification, build or GPU. Proposed names describe responsibilities, not implemented APIs.',
    conclusion='Add a small typed paged-append node and an exact mutable-page/source-proof binding in the existing Graph resource mechanism. Existing custom kernels can implement its computation, but do not currently provide the missing page-write/within-Graph reader/publication protocol.',
    facts=[
        'PagedArena owns one physical backing split into independent original page lease blocks. acquire is exclusive and does not allocate; read grants exactly the referenced initialized pages.',
        'PagedPageWriter publish/complete update an initialized prefix only after successful writes; consumed reservations cannot be reclaimed merely because a public handle was cancelled or dropped.',
        'Existing PagedArenaPendingRead records CopyResourceId, original root/generation and required initialized ranges. Its admission checks CopyBatchUpdate/CopyStreamAccess input and covers, so it cannot truthfully certify a write performed by a node later in this same Graph.',
        'Current Graph projected-resource binding is a checked read-input mechanism. It rejects projected capacity as an ordinary output, aliases and materializing/copy consumers without exact selected-reader qualification.',
        'EffectResourceBinding is fixed at compile. Memory effects are explicitly prohibited from overlapping Graph tensor storage. Using an object identity for addressable arena bytes would violate the public footprint contract.',
        'CustomKernel enqueue records into an existing admitted QueueSequence and reports accepted prefixes. It must not call a second submit/submit_host. It does not itself own arbitrary paged permissions or certify subsequent readers.',
        'StateStore members are fixed-size ready ReadLease resources or host metadata, and import/finalize require a complete fixed schema. It cannot directly hold a PagedArenaRead or variable vector of page leases as one resource member.',
        'StateHead atomically publishes one StateVersion using expected-base identity; it is not an atomic transaction across several independent cache/state heads.'
    ],
    options=[
        dict(id='existing_external_copy_chain', selected=False,
             description='Projection Graph completes, original F2 copies into page writers, existing pending-read Graph consumes the accepted copy update.',
             assessment='Correct reference using existing interfaces, but projection output is available only after producer submission; repeating producer/copy/consumer host orchestration at each layer creates exactly the requested seam. Do not make it the new inference architecture.'),
        dict(id='typed_append_in_one_graph', selected=True,
             description='Graph-native append plus exact owned dirty-page binding and same-plan producer-to-reader proof. Reuse original Plan/Invocation/Queue/Completion/resource episode.',
             assessment='Smallest maintainable product direction. Requires a real writable-page projection and publication contract, not only another numerical kernel.'),
        dict(id='append_attention_fusion_only', selected=False,
             description='Implement only a backend-private combined append+attention island.',
             assessment='Useful optional lowering after the logical contract exists. Making it the sole API would require every backend to supply the same large fusion and would make model/backend upgrades expensive. Keep a composable append+attention baseline.')
    ],
    selected_design=dict(
        graph_shape='K/V projection -> typed PagedAppend node(s) -> typed PagedAttention. A typed graph helper wires the producer/read dependency once during graph construction; the engine does not orchestrate per-layer submissions at runtime.',
        public_shape=[
            'A typed append descriptor identifies schema/cache role/storage semantics and mathematical new rows. It has no model name, ProviderId, native pointer or user routing macro.',
            'A proposed cold PagedAppendBinding supplies the exact old/new owned layout, retained old prefix permissions, original dirty PagedPageWriter reservations, and append-row mapping. A helper may prepare/bind the bounded set of all model append sites once per step.',
            'The logical append-to-attention boundary is a typed next-cache reference/proof over the original capacity owner. It is not a published dense whole-arena tensor or a whole-arena writable TensorView.',
            'After successful complete Graph retirement, a typed result exports the real individual ready dirty pages and their initialized prefixes. Unchanged ready pages stay shared; no full cache materialization or readback is required.'
        ],
        exact_source_and_write_proof=[
            'For every target: original arena/schema/role, resource/allocation handle, exact page offset/bytes, lease root/generation, previous initialized rows, required rows and logical request-row mapping.',
            'Validate all IDs, duplicate/conflicting writes, bounds and overflow before any target address is used or native work accepted. Owned append metadata must describe the same generation as the attention layout.',
            'Retain the old prefix source only for an actual COW copy. A fresh target starts with initialized_rows0: coverage must include both the preserved prefix copy and appended rows, not only the suffix.',
            'The selected prepared append implementation declares the exact source reads, target writes and initialized-prefix coverage it actually performs. Source/reader qualification is tied to that original implementation and this Invocation, never a schema/provider-family whitelist.',
            'Attention admits old ready page guards plus ordered reads from these exact new writer pages only if the same Plan proves the append precedes every such read and actual cross-lane dependencies are supported. Reuse existing writer use/ordered-read primitives; do not manufacture a CopyBatchUpdate or ready lease.',
            'Core must understand this exact mutable projection when checking alias/effect footprints. Preserve rejection for arbitrary whole-arena tensor writes/copies and unrelated overlapping effects. The current static effect binding must not simply be relaxed globally.'
        ],
        minimum_implementation_surfaces=[
            'Typed append descriptor/helper and cold binding/result owner in graph_batch/compute_batch, adjacent to existing paged layout/permissions. Page allocation and eviction remain caller policy.',
            'One selected-artifact access proof for exact page writes and same-Graph writer/read lineage, extending the existing projected-resource contract and generic resource alias/admission checks. This new resource semantic warrants a small common contract change; it must not add concrete op/Provider checks to the execution cursor.',
            'Provider-local append implementations over actual page destinations. Plain storage first can use row copies or an append kernel; encoded caches require their explicit codec/rounding contract. Backend fusion is an optional cold candidate.',
            'Reuse the original Invocation resource payload, permission use pool, submission lifetime and completion/result gates. No second graph, executor, per-layer host producer or new global retirement owner.'
        ],
        shared_queue_and_native_source=[
            'CPU/CUDA/Vulkan shared-Queue implementations record prefix copy plus new-row write into the already-admitted original QueueSequence. They must never start another submit inside enqueue.',
            'A delegated native runtime uses its existing Source/native result/completion and dependency frontier; do not invent a Queue or raw buffer import for MLX/Metal.',
            'Required imports, copies, metadata updates and host waits are explicit and costed. No promise that every platform is zero-copy/capture-compatible. Backend capability rejection occurs before work; a real accepted native failure does not trigger silent fallback.'
        ],
        cold_and_hot=[
            'Cold: validate owned append layout and exact page set, reserve finite metadata/use/result capacity, configure selected native programs, and invalidate only affected physical bindings/captures.',
            'Hot: fixed prepared kernels/copies consume real new K/V graph values. No provider discovery, heap growth, re-encoding of old whole cache, per-layer host wait or new host submission chain.',
            'Appending beyond a prepared shape/page-count domain returns need-prepare/capacity status. Capacity alone does not prove an unchanged native attention plan or capture topology.'
        ]
    ),
    lifecycle=[
        dict(stage='Before native acceptance', rule='Preflight every binding and ownership transfer. Rejection leaves old session head and caller page reservations intact, or returns the original consumed reservations through one typed take-back path. Do not advance positions or initialized-prefix metadata.'),
        dict(stage='Accepted write/read prefix', rule='Original Graph submission lifetime retains every dirty writer, old prefix reader, metadata owner and original native progress/completion. A failure or cancellation stops successors as supported but does not release accepted native work.'),
        dict(stage='Actual successful terminal', rule='Publish dirty writers to ready leases and complete each PagedPageWriter with its exact initialized prefix; form ready typed page frames. Per-page readiness remains private until whole-session commit.'),
        dict(stage='Failure/cancel after acceptance', rule='Keep the old complete snapshot. Do not publish partial K/V, conv/GDN or position changes. Retain poisoned/unknown dirty pages through real retirement; discard/reacquire only under existing original-page proof.'),
        dict(stage='Old result/version retained', rule='Old pages remain protected and charged. An available directory slot or public Completion observation is not proof that an original page can be reused.')
    ],
    whole_snapshot=dict(
        owner='Engine/session layer owns one immutable SessionSnapshot head, not separate independently visible heads for each layer.',
        members=['Per-layer exact key/value PagedArenaRead frames and owned layouts',
                 'A StateVersion for ready recurrent/conv resources where useful',
                 'Logical length/positions and relevant branch/sampling identity'],
        commit='Prepare the complete candidate privately, then replace one outer snapshot pointer under the session lock or expected-base CAS after Graph success and cancellation/generation checks. Readers see either the old or new complete snapshot.',
        no_new_state_container='Retain the ready page frames directly alongside StateVersion in the engine snapshot. Do not serialize pointers into host metadata, create a fake arena-wide ReadLease or add thousands of inactive fixed StateStore members.',
        state_store_use='StateDraft replace/finalize can produce the candidate recurrent StateVersion without publishing a component head. A finalization/capacity failure preserves the outer old head; completed candidate resources may remain retained for bounded retry/reclamation.',
        cow_tail='Because the old whole snapshot must survive until success, even an otherwise single-session tail page is still held by an old ReadLease. With current block-granular permissions it needs a distinct dirty COW page; in-place tail overwrite requires actual exclusivity, never a refcount guess.',
        atomicity_limit='This is atomic visibility of a ready immutable host snapshot. It is not a distributed/device-memory transaction, nor rollback of writes to published old pages.'
    ),
    first_useful_implementation=['Plain BF16 K/V append across a partial-page boundary, with a shared old prefix and distinct new tail; one ordinary Graph includes projection/append/attention.',
        'Two independently retained sessions and an old snapshot use the same immutable weights/plan while their dirty writers and recurrent state remain independent.',
        'Check a pre-acceptance bad target and one failure/cancel after native acceptance: old snapshot stays usable, dirty page cannot be reacquired until actual retirement.',
        'Inspect the real step path and resource report for whole-bank copies, hidden host waits/allocations or duplicate executor state; do only the affected incremental build/consumer checks.'],
    not_claimed=['Paged append is implemented', 'Existing pure custom kernels alone satisfy mutable page ownership',
                 'All cache encodings or native platforms support the proposed path', 'Known throughput gain or unchanged capture for all KV lengths'],
    sources=[
        source('include/hyle/compute/paged_arena.h', [[25,77],[89,120]], 'Exact original page ownership, initialized prefixes, pending/read interfaces and discard.'),
        source('src/compute_batch/paged_arena.cc', [[17,40],[144,163],[229,309],[316,345],[390,420]], 'Original exclusive acquisition, copy-source pending coverage and page completion.'),
        source('include/hyle/compute/detail/paged_arena_access.h', [[8,33],[35,100]], 'Trusted exact footprints, ordered reads and explicit CopyUpdate input/covers proof.'),
        source('include/hyle/compute/detail/lease_access.h', [[32,57]], 'Existing original writer and ordered-reader native lifetime primitives.'),
        source('src/compute/resource_leases.cc', [[200,241],[334,344]], 'Original block admission/failure accounting; ordered read is not ordinary ready permission.'),
        source('include/hyle/graph/batch.h', [[137,159]], 'Current ready/pending input binding and external CopyBatchUpdate submission.'),
        source('src/graph_batch/batch.cc', [[1040,1119]], 'Current pending source validation, original Queue admission and dependent completion.'),
        source('include/hyle/graph/detail/region_access.h', [[69,113],[163,194]], 'Read-only selected projection and original optional resource payload/submission callbacks.'),
        source('src/graph/resources.cc', [[413,450],[580,590],[1099,1166]], 'Projected input/output restrictions, real output writers and original permission/submission admission.'),
        source('src/graph/executable.cc', [[599,660],[7910,7919]], 'Fixed effect binding and effect-memory/tensor overlap rejection.'),
        source('include/hyle/compute/custom_kernel.h', [[21,35],[155,179]], 'Native enqueue in the existing QueueSequence, not nested submission.'),
        source('include/hyle/compute/state_versions.h', [[20,35],[94,109],[119,136],[155,169],[182,193]], 'Fixed ready resource/host metadata schema and version/head publication.'),
        source('src/compute_state/state_versions.cc', [[189,202],[331,354],[475,513],[537,551]], 'Complete fixed resource imports, candidate finalization and expected-base atomic publication.')
    ])

P = D / 'paged-write-design.json'
assert not P.exists()
P.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(path=str(P), bytes=P.stat().st_size, sha256=hashlib.sha256(P.read_bytes()).hexdigest())))
