"""Preserve source, commands, logs and bounded correctness receipts in docs."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[4]
V = R / '.scratch/multi-session-20261021'
E = R / 'docs/evidence/correctness'
name = 'qwen-multi-session-isolation-2026-10-21'
artifact = E / (name + '.json')
bundle = E / (name + '.zip')
assert not artifact.exists() and not bundle.exists()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


single = read(S / 'validation/single/attempt1/summary.json')
isolation = read(V / 'attempt2/summary.json')
probe = read(V / 'probe/summary.json')
final = read(V / 'final4/summary.json')
assert all(x['passed'] for x in (single, isolation, probe, final))
assert single['vector_count'] == 64
assert isolation['interleaved']['2']['vector_count'] == 36
assert isolation['interleaved']['4']['vector_count'] == 72
assert probe['decision_vector_count'] == 36 and probe['boundary_vector_count'] == 162
assert final['vector_count'] == 72
files = set()
for root in (V, S / 'inputs', S / 'parser', S / 'probe-directory-fix',
             S / 'validation/single/attempt1', S / 'cli/checks/attempt1', S / 'cli/checks/attempt2',
             S / 'validation/isolation/attempt1'):
    for path in root.rglob('*'):
        if path.is_file() and path.suffix.lower() in ('.json', '.txt', '.log', '.py', '.cc', '.h', '.diff', '.tsv'):
            files.add(path)
for path in S.iterdir():
    if path.is_file() and path.suffix in ('.json', '.py', '.diff'):
        files.add(path)
for path in (S / 'cli').glob('*.json'):
    files.add(path)
E.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(bundle, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(R).as_posix())
result = dict(date='2026-10-21', purpose='Shared immutable Model and isolated full-state Sessions; fixed teacher-forced CUDA consumer correctness.',
    throughput_evidence=False,
    final_source=read(S / 'probe-ready-for-root.json')['source'],
    final_image=read(S / 'probe-ready-for-root.json')['image'],
    first_shared_consumer=read(S / 'cli-ready-for-root.json')['image'],
    baseline=read(S.parent / 'layout-workspace-facts-reuse-2026-10-21/ready-for-root.json')['image'],
    implementation=dict(shared='One 320-tensor weight bank, immutable finite family and selected child per shape.',
        isolated='Per-session 24-layer dense KV, conv/GDN ping-pong state, position/parity, IO, workspace and invocation slots.',
        execution='One original queue; complete evaluate calls alternate round-robin, no concurrent submits.',
        lifetime='Sessions declared after Model, drain and release slots before state and before Model destruction.'),
    results=dict(original_single_session=single, initial_two_and_four_sessions=isolation,
                 final_two_session_probe=probe, final_four_session_normal=final),
    independent_review=read(S / 'isolation-independent-review.json'),
    limitations=['No shared-prefix/COW or automatic cache eviction delivered in this batch.',
        '--max-sessions (default16) validates admission count, not a byte budget or preallocation of16 caches.',
        'Configured limit1 has no new kernel route; an actual single-session input already uses one session.',
        'All vector export runs are diagnostics; no new tokens/s, memory saving or service concurrency claim.',
        'Endpoint vectors and ownership inspection do not prove all internal state bits, arbitrary journeys or failure/cancel paths.',
        'Per-session wall includes other interleaved sessions; source clock bucket moved state allocation into shape preparation.'],
    corrected_validation_issues=['First deep trace path exceeded Windows path length; retained failing exit/logs, used short repo-local output.',
        'Initial checker counted route TSVs as vectors; corrected exact decision-file set and reused only recorded exact-image/command exit-0 processes.',
        'Multi-session layer0 probe output collision fixed using indexed session subdirectories; original single-session paths unchanged.'],
    next=['Bound cache sessions, active sequences and actual cache bytes; engine evicts idle entries, Hyle retains resources until native retirement.',
          'Typed paged append with exact dirty-page writers and same-graph successor-read proof; shared prefix/COW and complete state snapshot publication.'],
    bundle=identity(bundle), bundle_files=len(files), binary_vectors_archived=False,
    reproduction='Bundle contains frozen consumer sources/headers, input IDs, scripts, identities, commands, raw logs and comparison hashes. Reuse existing matching dependencies/model resources; no weights, SDKs, executables or generated vector payloads copied into docs.')
artifact.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
print(identity(artifact))
print(identity(bundle), 'members', len(files))
