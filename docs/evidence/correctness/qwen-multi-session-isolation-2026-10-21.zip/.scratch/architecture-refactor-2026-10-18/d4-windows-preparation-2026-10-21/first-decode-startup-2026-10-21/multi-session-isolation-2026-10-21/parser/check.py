"""One standalone Windows C++ parser check; no Hyle SDK or GPU dependency."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

stage = Path(__file__).resolve().parent
repo = next(p for p in stage.parents if (p / 'AGENTS.md').is_file() and (p / 'src').is_dir())
attempt = sys.argv[1] if len(sys.argv) == 2 else 'attempt1'
if not attempt or any(not (value.isascii() and (value.isalnum() or value in '_-')) for value in attempt):
    raise SystemExit('invalid attempt name')
out = stage / 'checks' / attempt
out.mkdir(parents=True, exist_ok=False)
data = out / 'data'
(data / 'nested schedules').mkdir(parents=True)
(data / 'token data').mkdir()
fixtures = {
    'token data/prompt.ids': '1 2\n',
    'token data/decode.ids': '3 4\n',
    'token data/next.ids': '5\n',
    'token data/end.ids': '6\n',
    'token data/bad.ids': '16\n',
    'nested schedules/one.txt': 'prompt "../token data/prompt.ids"\ndecode "../token data/decode.ids"\nprompt "../token data/next.ids"\ndecode "../token data/end.ids"\n',
    'nested schedules/bad.txt': 'prompt "../token data/bad.ids"\ndecode "../token data/end.ids"\n',
    'sessions.txt': '# Two distinct sessions may use the same fixed input.\n\n Alpha_1 "nested schedules/one.txt"\nb-2 "nested schedules/one.txt"\n',
    'empty.txt': ' # comment only\n\t\n',
    'duplicate.txt': 'Alpha_1 "nested schedules/one.txt"\nAlpha_1 missing.txt\n',
    'invalid-id.txt': 'bad/id "nested schedules/one.txt"\n',
    'invalid-start.txt': '_bad "nested schedules/one.txt"\n',
    'extra.txt': 'ok "nested schedules/one.txt" extra\n',
    'too-many.txt': 'ok "nested schedules/one.txt"\nother missing.txt\n',
    'missing.txt': 'ok missing-schedule.txt\n',
    'bad-token.txt': 'ok "nested schedules/bad.txt"\n',
}
for name, contents in fixtures.items():
    (data / name).write_text(contents, encoding='utf-8')

msvc = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717')
sdk = Path('C:/Program Files (x86)/Windows Kits/10')
sdk_version = '10.0.26100.0'
compiler = msvc / 'bin/Hostx64/x64/cl.exe'
env = os.environ.copy()
env['INCLUDE'] = ';'.join(str(p) for p in [msvc / 'include', *(sdk / 'Include' / sdk_version / name for name in ('ucrt', 'shared', 'um', 'winrt', 'cppwinrt'))])
env['LIB'] = ';'.join(str(p) for p in [msvc / 'lib/x64', *(sdk / 'Lib' / sdk_version / name / 'x64' for name in ('ucrt', 'um'))])
env['PATH'] = str(compiler.parent) + os.pathsep + env['PATH']
headers = [repo / 'tools/qwen35_text/schedule.h', repo / 'tools/qwen35_text/session_schedule.h']

def identity(path):
    content = path.read_bytes()
    return {'path': str(path), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}

sources = [identity(path) for path in [*headers, stage / 'parser_check.cc', Path(__file__)]]
image = out / 'parser_check.exe'
command = [str(compiler), '/nologo', '/std:c++17', '/W4', '/WX', '/permissive-', '/EHsc', '/utf-8', '/O2', '/MD', '/DNOMINMAX', '/I' + str(headers[0].parent), str(stage / 'parser_check.cc'), '/Fo' + str(out / 'parser_check.obj'), '/Fe' + str(image), '/link', '/INCREMENTAL:NO', '/MAP:' + str(out / 'parser_check.map')]
records = []
for name, cmd in [('compile-link', command), ('run', [str(image), str(data)])]:
    (out / (name + '.command.json')).write_text(json.dumps({'command': cmd, 'cwd': str(out)}, indent=2) + '\n', encoding='utf-8')
    started = time.monotonic()
    result = subprocess.run(cmd, cwd=out, env=env, capture_output=True, timeout=60)
    (out / (name + '.stdout.log')).write_bytes(result.stdout)
    (out / (name + '.stderr.log')).write_bytes(result.stderr)
    record = {'command': cmd, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started}
    records.append(record)
    (out / (name + '.result.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode('utf-8', errors='replace'))
        print(result.stderr.decode('utf-8', errors='replace'))
        raise SystemExit(result.returncode)
assert sources == [identity(path) for path in [*headers, stage / 'parser_check.cc', Path(__file__)]]
report = {'status': 'passed', 'sources': sources, 'compiler': identity(compiler), 'sdk_include_root': str(sdk / 'Include' / sdk_version), 'runs': records, 'positive_cases': 1, 'expected_rejections': 12, 'CXX': 1, 'links': 1, 'SDK_builds': 0, 'GPU_runs': 0, 'object': identity(out / 'parser_check.obj'), 'image': identity(image)}
(stage / 'parser-result.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print('SESSION_PARSER_READY', json.dumps(identity(headers[1])), flush=True)
