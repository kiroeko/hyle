"""Root-only diagnostic namespace check; original baseline vs two sessions."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('isolation', S / 'run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
out = m.ROOT / '.scratch/multi-session-20261021/probe'
out.mkdir(parents=True, exist_ok=False)
plan = m.read(S / 'inputs/plan.json')
old_ready = S.parent / 'layout-workspace-facts-reuse-2026-10-21/ready-for-root.json'
new_ready = S / 'probe-ready-for-root.json'
result = dict(passed=False, throughput_evidence=False, runner=m.identity(__file__),
              helper=m.identity(S / 'run.py'), baseline_ready=m.identity(old_ready),
              new_ready=m.identity(new_ready), sessions={})
m.save(out / 'summary.json', result)
baselines = {}
for sid in ('alice', 'bob'):
    folder = out / 'baseline' / sid
    baselines[sid] = h.run(folder, old_ready,
        ['--schedule', plan['cases'][sid]['schedule']['path'], '--layer0-probe', str(folder / 'probe')], families=2)
    h.check_session(baselines[sid], plan['cases'][sid])
    print('probe baseline ' + sid + ' passed', flush=True)
folder = out / 'interleaved2'
observed = h.run(folder, new_ready,
    ['--session-schedules', plan['manifests']['2']['manifest']['path'], '--max-sessions', '4',
     '--layer0-probe', str(folder / 'probe')], families=2)
assert observed['dispatch_session_ids'] == plan['manifests']['2']['dispatch_order']
names = ('01-gdn-output', '02-out-proj-input', '03-out-proj-output', '04-down-proj-input',
         '05-layer-output', '06-post-attn-residual', '07-post-attn-norm',
         '08-gate-proj-output', '09-up-proj-output')
for session in observed['sessions']:
    sid = session['session_id']
    case = plan['cases'][sid]
    h.check_session(session, case)
    assert session['generated_ids'] == baselines[sid]['generated_ids']
    decisions = h.check_vectors(out / 'baseline' / sid / 'trace',
        folder / 'trace' / session['trace_subdirectory'], case['calls'])
    baseline = out / 'baseline' / sid / 'probe'
    actual = folder / 'probe' / session['trace_subdirectory']
    expected = {f"{call['name']}/{name}.bf16" for call in case['calls'] for name in names}
    for p in (baseline, actual):
        assert {f.relative_to(p).as_posix() for f in p.rglob('*.bf16')} == expected
    boundaries = []
    for name in sorted(expected):
        a, b = baseline / name, actual / name
        boundaries.append(dict(vector=name, baseline=m.identity(a), actual=m.identity(b),
                               byte_equal=a.read_bytes() == b.read_bytes()))
    result['sessions'][sid] = dict(decisions=decisions, boundaries=boundaries,
        passed=all(x['byte_equal'] for x in decisions + boundaries))
result['decision_vector_count'] = sum(len(s['decisions']) for s in result['sessions'].values())
result['boundary_vector_count'] = sum(len(s['boundaries']) for s in result['sessions'].values())
result['gpu_model_processes'] = 3
result['passed'] = all(s['passed'] for s in result['sessions'].values())
m.save(out / 'summary.json', result)
assert result['passed'], 'Diagnostic vectors differ; exact files/logs retained'
print('probe: 36 decisions and 162 boundaries byte-identical; per-session directories retained', flush=True)
