"""Consumer-only Session split, fresh1CXX+current190input link; no GPU."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;F=S.parent;W=F/"layout-workspace-facts-reuse-2026-10-21"
spec=importlib.util.spec_from_file_location("session_existing_build",W/"build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,R=h.b,h.c,h.R

def main():
 out=S/"cli/checks/attempt2";out.mkdir(parents=True,exist_ok=False);(out/"tmp").mkdir()
 recipe_path=F/"layout-preparation-diagnostic-2026-10-21/checks/attempt1/identity.json";recipe=c.read(recipe_path)
 source=R/"tools/qwen35_text/main.cc";frozen=b.identity(source);header=b.identity(R/"tools/qwen35_text/schedule.h")
 assert frozen["sha256"]==c.read(S/"cli/probe-source-freeze.json")["source"]["sha256"]
 command=b.host_command(recipe["command"],source,"main",out)
 assert all(flag in command for flag in ("/WX","/W4","/MD","/O2"))
 c.save(out/"compile-plan.json",dict(command=command,source=frozen,header=header,recipe=b.identity(recipe_path),CXX=1,NVCC=0,SDK_builds=0,GPU_runs=0))
 env,_=b.environment(command,[],out);c.execute("compile",command,env,out)
 deps_path=out/"main-deps.json";deps=c.read(deps_path)["Data"]
 dependencies=[b.identity(p) for p in dict.fromkeys([deps["Source"],*deps["Includes"]])]
 assert h.same(frozen) and all(h.same(x) for x in dependencies)
 obj=b.identity(out/"main.obj")
 c.save(out/"identity.json",dict(command=command,source=frozen,header=header,object=obj,dependencies=dependencies,source_dependencies=b.identity(deps_path),recipe=b.identity(recipe_path),CXX=1,NVCC=0,SDK_builds=0,GPU_runs=0))
 for p in (source,R/"tools/qwen35_text/schedule.h",R/"tools/qwen35_text/session_schedule.h"):
  q=out/"source"/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
 base_path=W/"checks/attempt1/link-plan.json";base=c.read(base_path)
 assert len(base["inputs"])==190 and all(h.same(x) for x in base["inputs"])
 old=c.key(recipe["object"]["path"]);assert sum(c.key(x["path"])==old for x in base["inputs"])==1
 inputs=[obj if c.key(x["path"])==old else x for x in base["inputs"]]
 image=out/"qwen.exe"
 link=[obj["path"] if c.key(x)==old else x for x in base["command"] if not x.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:"))]
 link += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
 c.save(out/"link-plan.json",dict(command=link,inputs=inputs,base=b.identity(base_path),CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
 env,runtime=b.environment(link,[x["path"] for x in inputs],out);c.execute("link",link,env,out)
 original=c.read(W/"checks/attempt1/runtime-environment.json")["staged_CPU_modules"][0]["destination"]
 assert h.same(original);target=out/Path(original["path"]).name;os.link(original["path"],target)
 c.save(out/"runtime-environment.json",dict(PATH=env["PATH"],runtime=runtime,staged_CPU_modules=[dict(source=original,destination=b.identity(target),hardlink=True)]))
 assert all(h.same(x) for x in inputs) and all(h.same(x) for x in dependencies)
 c.save(S/"probe-ready-for-root.json",dict(status="consumer_session_manifest_built_not_run",image=b.identity(image),source=frozen,header=header,identity=b.identity(out/"identity.json"),link_plan=b.identity(out/"link-plan.json"),runtime_environment=b.identity(out/"runtime-environment.json"),source_freeze=b.identity(S/"cli/probe-source-freeze.json"),CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0,baseline_retained=True,pending="Root runtime single-session regression plus distinct interleaved sessions against retained baseline."))
 print("SESSION_SPLIT_READY",image,flush=True)
if __name__=="__main__":main()
