"""Independent host-only check of fixed completed session-isolation evidence. Never launches a model."""
from pathlib import Path
import hashlib,json,re,shlex
S=Path(__file__).resolve().parent
R=next(x for x in S.parents if (x/"AGENTS.md").is_file() and (x/"src").is_dir())
A=R/".scratch/multi-session-20261021/attempt2"
cache={}
def load(p):return json.loads(Path(p).read_text(encoding="utf8"))
def identity(p):
 p=Path(p).resolve()
 if p not in cache:
  data=p.read_bytes();cache[p]=dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 return cache[p]
def match(row):
 actual=identity(row["path"]);assert all(actual[k]==row[k] for k in ("bytes","sha256"));return actual

def schedule(path):
 path=Path(path);phases=[];calls=[];visible=0
 for line in path.read_text().splitlines():
  words=shlex.split(line,comments=True)
  if not words:continue
  assert len(words)==2
  kind,file=words;assert kind==("prompt" if len(phases)%2==0 else "decode")
  ids=[int(x) for x in (path.parent/file).read_text().split()]
  assert ids and all(0<=x<248320 for x in ids)
  turn=len(phases)//2+1;prefix=f"round{turn}_"+("prefill" if kind=="prompt" else "decode")
  start=visible
  for local,values in enumerate([ids] if kind=="prompt" else [[x] for x in ids]):
   visible+=len(values);assert visible<=256
   calls.append(dict(name=prefix if kind=="prompt" else prefix+str(local+1),ids=values,visible_tokens=visible,phase=len(phases)))
  phases.append(dict(turn=turn,kind="prefill" if kind=="prompt" else "decode",name=prefix,input_tokens=len(ids),calls=1 if kind=="prompt" else len(ids),generated_tokens=1 if kind=="prompt" else len(ids),context_before=start,context_after=visible))
 assert len(phases)==4 and len(calls)==9
 return phases,calls

summary=load(A/"summary.json");plan=load(S/"inputs/plan.json")
assert summary["passed"] and summary["gpu_model_processes"]==6
for row in summary["input_files"]:match(row)
for key in ("new_ready","baseline_ready","input_plan","previous_summary"):match(summary[key])
assert identity(A/"runner-corrected.py")["sha256"]==summary["runner"]["sha256"]
ready_new=load(S/"cli-ready-for-root.json");ready_old=load(S.parent/"layout-workspace-facts-reuse-2026-10-21/ready-for-root.json")
for ready in (ready_new,ready_old):
 match(ready["image"]);match(ready["runtime_environment"])
frozen=Path(ready_new["image"]["path"]).parent/"source/tools/qwen35_text/main.cc"
assert identity(frozen)["sha256"]==ready_new["source"]["sha256"]
parsed={sid:schedule(case["schedule"]["path"]) for sid,case in plan["cases"].items()}
for sid,(_,calls) in parsed.items():assert calls==plan["cases"][sid]["calls"]
processes=[]
step_re=re.compile(r"^(round\d+_(?:prefill|decode\d+)) tokens=(\d+) visible=(\d+) .* next=(-?\d+)$",re.M)

def verify_session(obs,sid):
 phases,calls=parsed[sid]
 assert obs["source_id"]=="4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155" and obs["text_tensors"]==320
 assert obs["fixed_decode"] and obs["schedule"] and obs["diagnostic"]
 assert obs["phase_count"]==4 and obs["turn_count"]==2
 assert obs["visible_tokens"]==obs["processed_tokens"]==calls[-1]["visible_tokens"]
 assert obs["generated_tokens"]==len(obs["generated_ids"])==9
 assert obs["decode_input_ids"]==[c["ids"][0] for c in calls if "decode" in c["name"]]
 for actual,expected in zip(obs["phases"],phases):
  assert all(actual[k]==v for k,v in expected.items())
 return dict(session_id=sid,generated_ids=obs["generated_ids"],visible_tokens=obs["visible_tokens"],phase_boundaries=[dict(name=p["name"],before=p["context_before"],after=p["context_after"]) for p in phases])

def process(folder,ready,session_ids,multi,probe=False):
 command=load(folder/"command.json");result=load(folder/"result.json");obs=load(folder/"observation.json")
 assert result["exit"]==0 and not result.get("timeout")
 assert command["command"]==result["command"] and command["image"]==result["image"]==ready["image"]
 match(command["ready"]);match(command["runtime_environment"])
 argv=result["command"]
 assert argv[0]==ready["image"]["path"]
 assert argv[argv.index("--inputs")+1]==str(R/".scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/128-prefill/inputs")
 if multi:assert argv[argv.index("--session-schedules")+1]==str(S/f"inputs/sessions{len(session_ids)}.txt")
 else:assert argv[argv.index("--schedule")+1]==plan["cases"][session_ids[0]]["schedule"]["path"]
 if probe:assert argv[argv.index("--layer0-probe")+1]==str(folder/"probe")
 for key,value in (("--capacity","256"),("--progress","direct"),("--replay","auto"),("--trace-level","decisions")):
  assert argv[argv.index(key)+1]==value
 assert argv[argv.index("--trace")+1]==str(folder/"trace")
 assert json.loads((folder/"stdout.log").read_text().splitlines()[-1])==obs
 text=(folder/"stderr.log").read_text()
 weights=text.count("resident text weights: 320 tensors, 3763655360 bytes")
 family=len(re.findall(r"^compile full text finite family variants=",text,re.M))
 assert weights==1 and family==(2 if probe else 1)
 observations=obs["sessions"] if multi else [obs]
 assert len(observations)==len(session_ids)
 logged=step_re.findall(text);assert len(logged)==9*len(session_ids)
 replay=re.findall(r"^planned_replay T=(\d+) slot0_uses=(\d+) slot1_uses=(\d+) slot0=(\S+) slot1=(\S+)$",text,re.M)
 expected_replay=[]
 for sid in session_ids:
  shapes={}
  for i,call in enumerate(parsed[sid][1]):shapes.setdefault(len(call["ids"]),[0,0])[i%2]+=1
  for _ in range(2 if probe else 1):
   for size,counts in shapes.items():expected_replay.append((str(size),str(counts[0]),str(counts[1]),*("commands" if n<=1 else "prefer-capture" for n in counts)))
 assert replay==expected_replay
 checked=[]
 for index,(sid,observed) in enumerate(zip(session_ids,observations)):
  if multi:assert observed["session_id"]==sid
  checked.append(verify_session(observed,sid))
  for call,predicted,row in zip(parsed[sid][1],observed["generated_ids"],logged[index*9:(index+1)*9]):
   assert row==(call["name"],str(len(call["ids"])),str(call["visible_tokens"]),str(predicted))
 route_files=[p for p in (folder/"trace").rglob("*.tsv")]
 assert all(p.parent.name=="routes" for p in route_files)
 row=dict(name=folder.relative_to(R/".scratch/multi-session-20261021").as_posix(),exit=0,pid=result["pid"],started_unix_ns=result["started_unix_ns"],finished_unix_ns=result["finished_unix_ns"],image=result["image"],records=[identity(folder/x) for x in ("command.json","result.json","stdout.log","stderr.log","observation.json")],weight_loads=weights,family_compiles=family,decision_calls=len(logged),planned_replay_counts_match_per_session=True,excluded_route_metadata_files=len(route_files),sessions=checked)
 processes.append(row);return obs

baseline={}
for sid in parsed:baseline[sid]=process(A/"baseline"/sid,ready_old,[sid],False)
comparisons={}
for count in (2,4):
 words=[shlex.split(x,comments=True) for x in (S/f"inputs/sessions{count}.txt").read_text().splitlines() if x.strip()]
 ids=[x[0] for x in words]
 assert all(len(x)==2 and (S/"inputs"/x[1]).resolve()==Path(plan["cases"][x[0]]["schedule"]["path"]).resolve() for x in words)
 actual=process(A/f"interleaved{count}",ready_new,ids,True)
 expected_order=[sid for i in range(max(len(parsed[sid][1]) for sid in ids)) for sid in ids if i<len(parsed[sid][1])]
 assert actual["execution"]=="round_robin_serial" and actual["session_count"]==count
 assert actual["dispatch_session_ids"]==expected_order==plan["manifests"][str(count)]["dispatch_order"]
 assert actual["processed_tokens"]==sum(parsed[sid][1][-1]["visible_tokens"] for sid in ids)
 assert actual["generated_tokens"]==9*count
 rows=[]
 for index,(sid,observed) in enumerate(zip(ids,actual["sessions"])):
  assert observed["generated_ids"]==baseline[sid]["generated_ids"]
  old=A/"baseline"/sid/"trace";new=A/f"interleaved{count}"/"trace"/observed["trace_subdirectory"]
  expected={f"{c['name']}/{name}" for c in parsed[sid][1] for name in ("hidden.bf16","logits.f32")}
  for directory in (old,new):
   found={p.relative_to(directory).as_posix() for p in directory.rglob("*") if p.is_file() and p.suffix in (".bf16",".f32")}
   assert found==expected
  for relative in sorted(expected):
   oa,na=identity(old/relative),identity(new/relative)
   assert oa["bytes"]==na["bytes"]==(4096 if relative.endswith("hidden.bf16") else 993280)
   assert oa["sha256"]==na["sha256"] and (old/relative).read_bytes()==(new/relative).read_bytes()
   rows.append(dict(session_id=sid,name=relative,bytes=oa["bytes"],sha256=oa["sha256"]))
 assert len(rows)==summary["interleaved"][str(count)]["vector_count"]==18*count
 comparisons[str(count)]=dict(session_ids=ids,dispatches=len(expected_order),dispatch_order=expected_order,processed_tokens=actual["processed_tokens"],decision_vector_comparisons=len(rows),byte_identical=True,rows=rows)
# Latest image adds only diagnostic output namespacing; keep its evidence separate.
ready_final=load(S/"probe-ready-for-root.json");match(ready_final["image"]);match(ready_final["runtime_environment"])
final_source=Path(ready_final["image"]["path"]).parent/"source/tools/qwen35_text/main.cc"
assert identity(final_source)["sha256"]==ready_final["source"]["sha256"]
old_text=frozen.read_text();new_text=final_source.read_text()
normalized=new_text.replace("#include <string_view>\n","").replace("PreparationObservation *preparation = nullptr,\n                        std::string_view probe_subdirectory = {})", "PreparationObservation *preparation = nullptr)")
normalized=normalized.replace("      const auto probe_directory = probe_subdirectory.empty() ? layer0_probe / name\n          : layer0_probe / std::filesystem::path(probe_subdirectory) / name;\n      std::filesystem::create_directories(probe_directory);", "      std::filesystem::create_directories(layer0_probe / name);")
normalized=normalized.replace("std::ofstream stream(probe_directory /", "std::ofstream stream(layer0_probe / name /")
normalized=normalized.replace("preparation_diagnostics ? &run.preparation[index] : nullptr,\n            multiple_schedules ? std::string_view(run.trace_subdirectory) : std::string_view{});", "preparation_diagnostics ? &run.preparation[index] : nullptr);")
assert normalized==old_text,"probe fix changes more than the declared diagnostic namespace"
final_folder=R/".scratch/multi-session-20261021/final4"
final_summary=load(final_folder/"summary.json");assert final_summary["passed"] and final_summary["session_count"]==4
final_obs=process(final_folder,ready_final,list(parsed),True)
assert final_obs["dispatch_session_ids"]==plan["manifests"]["4"]["dispatch_order"]
assert final_obs["processed_tokens"]==239 and final_obs["generated_tokens"]==36
final_rows=[]
for observed in final_obs["sessions"]:
 sid=observed["session_id"];assert observed["generated_ids"]==baseline[sid]["generated_ids"]
 for row in final_summary["sessions"][sid]["vectors"]:
  ai,bi=match(row["baseline"]),match(row["actual"])
  assert Path(ai["path"]).is_relative_to(A/"baseline"/sid) and Path(bi["path"]).is_relative_to(final_folder/"trace"/observed["trace_subdirectory"])
  assert ai["bytes"]==bi["bytes"] and ai["sha256"]==bi["sha256"] and Path(ai["path"]).read_bytes()==Path(bi["path"]).read_bytes()
  final_rows.append(dict(session_id=sid,name=row["vector"],bytes=bi["bytes"],sha256=bi["sha256"]))
 assert {x["name"] for x in final_rows if x["session_id"]==sid}=={f"{c['name']}/{name}" for c in parsed[sid][1] for name in ("hidden.bf16","logits.f32")}
assert len(final_rows)==final_summary["vector_count"]==72
P=R/".scratch/multi-session-20261021/probe";probe_summary=load(P/"summary.json")
assert probe_summary["passed"] and probe_summary["gpu_model_processes"]==3
match(probe_summary["runner"]);match(probe_summary["helper"])
probe_baseline={sid:process(P/"baseline"/sid,ready_old,[sid],False,True) for sid in ("alice","bob")}
probe_actual=process(P/"interleaved2",ready_final,["alice","bob"],True,True)
assert probe_actual["dispatch_session_ids"]==plan["manifests"]["2"]["dispatch_order"]
assert probe_actual["processed_tokens"]==185 and probe_actual["generated_tokens"]==18
probe_rows=[]
names=("01-gdn-output","02-out-proj-input","03-out-proj-output","04-down-proj-input","05-layer-output","06-post-attn-residual","07-post-attn-norm","08-gate-proj-output","09-up-proj-output")
for observed in probe_actual["sessions"]:
 sid=observed["session_id"];assert observed["generated_ids"]==probe_baseline[sid]["generated_ids"]
 for category in ("decisions","boundaries"):
  expected={f"{call['name']}/{name}" for call in parsed[sid][1] for name in (("hidden.bf16","logits.f32") if category=="decisions" else tuple(n+".bf16" for n in names))}
  directory="trace" if category=="decisions" else "probe"
  original=P/"baseline"/sid/directory;actual_dir=P/"interleaved2"/directory/observed["trace_subdirectory"]
  for base_dir in (original,actual_dir):
   assert {p.relative_to(base_dir).as_posix() for p in base_dir.rglob("*") if p.is_file() and p.suffix in (".bf16",".f32")}==expected
  rows=probe_summary["sessions"][sid][category];assert {x["vector"] for x in rows}==expected
  for row in rows:
   ai,bi=match(row["baseline"]),match(row["actual"])
   assert Path(ai["path"])==original/row["vector"] and Path(bi["path"])==actual_dir/row["vector"]
   assert ai["bytes"]==bi["bytes"] and ai["sha256"]==bi["sha256"] and Path(ai["path"]).read_bytes()==Path(bi["path"]).read_bytes()
   probe_rows.append(dict(session_id=sid,category=category,name=row["vector"],bytes=bi["bytes"],sha256=bi["sha256"]))
 assert len([x for x in probe_rows if x["session_id"]==sid and x["category"]=="boundaries"])==81
assert len([x for x in probe_rows if x["category"]=="decisions"])==probe_summary["decision_vector_count"]==36
assert len([x for x in probe_rows if x["category"]=="boundaries"])==probe_summary["boundary_vector_count"]==162
ordered=sorted(processes,key=lambda x:x["started_unix_ns"])
assert len({x["pid"] for x in ordered})==10 and all(a["finished_unix_ns"]<=b["started_unix_ns"] for a,b in zip(ordered,ordered[1:]))
initial=load(A/"summary-before-checker-fix.json")
assert initial["passed"] is False and list(initial["baseline_sessions"])==["alice","bob"]
assert identity(A/"runner-initial.py")["sha256"]==initial["runner"]["sha256"]
report=dict(schema="hyle.multi-session-isolation-independent-review.v1",status="pass_with_explicit_finite_scope",source=identity(frozen),new_image=ready_new["image"],baseline_image=ready_old["image"],input_plan=identity(S/"inputs/plan.json"),summary=identity(A/"summary.json"),reviewer_script=identity(__file__),processes=processes,comparisons=comparisons,totals=dict(model_processes=6,baseline_processes=4,interleaved_processes=2,interleaved_full_model_calls=54,baseline_full_model_calls=36,paired_decision_vectors=108,distinct_baseline_session_decision_vectors=72,all_ids_equal=True,all_phase_and_context_counts_match=True,concurrent_process_windows=False),checker_correction=dict(initial_runner=identity(A/"runner-initial.py"),final_runner=identity(A/"runner-corrected.py"),current_probe_helper=identity(S/"run.py"),initial_summary=identity(A/"summary-before-checker-fix.json"),classification="Host checker originally counted route TSV metadata as numeric vectors. Corrected suffix filter plus exact expected decision-file set. Resume accepts only exact command/image identity, completed exit0/no-timeout results. Existing alice/bob/interleaved2 process results were reused; carol/dave/interleaved4 then completed. No model/source/math/tolerance change or repeated execution of the completed first three processes is needed by this correction."),ownership_source_anchors=[dict(path="tools/qwen35_text/main.cc",snapshot_sha256=ready_new["source"]["sha256"],lines="542-562",fact="Session owns all24layer mutable state plus per-shape Invocation/IO maps and drains each slot before resources die"),dict(path="tools/qwen35_text/main.cc",lines="799-835",fact="Each create_session allocates separate six dense KVpairs and18dual-generation conv/GDNstates; replay count starts at this session parity0; no weight load or compile"),dict(path="tools/qwen35_text/main.cc",lines="918-949",fact="Each invocation binds only its session state and own PhaseIO, while shared Family child handles remain model owned"),dict(path="tools/qwen35_text/main.cc",lines="1190-1309",fact="One sharedModel/family union before per-session creation; serial dispatch calls evaluate on the selected Session without resetting other sessions")],conclusion="The frozen ownership split plus byte-identical full-model decision outputs under two/four distinct histories, different lengths, repeated decode shapes and second prefills supports functional isolation of the complete dense KV/conv/GDN session owners in this finite serial consumer. No cross-session interference was observed.",not_claimed=["All internal KV/conv/GDN tensor bytes are equal: decisions-only traces contain final hidden/logits, not complete internal state dumps","Failure/cancellation isolation or resource-exhaustion admission was not exercised by these six successful processes","No concurrent device execution, service latency/throughput, memory-cost comparison or performance win: tracing marks all runs diagnostic and interleaved phase wall times include time spent servicing other sessions","No pooled pagedKV, prefix reuse/fork/COW, cache eviction, prefix quality equivalence or full-model quality qualification","One family compile per interleaved process is verified by logs/source; exact physical storage sharing/peakVRAM is not measured here"],validation=dict(reviewer_model_runs=0,reviewer_GPU_runs=0,reviewer_builds=0,product_edits=0))
report["additional_final_source_validation"]=dict(final_source=identity(final_source),final_image=ready_final["image"],diagnostic_fix_diff=identity(S/"probe-directory-fix/diagnostic-directory.diff"),declared_fix_only_normalized_byte_equal=True,normal_final4=dict(summary=identity(final_folder/"summary.json"),decision_vector_comparisons=72,byte_identical=True,baseline="Same four original W standalone runs in attempt2; no additional baseline process",rows=final_rows),probe_final2=dict(summary=identity(P/"summary.json"),model_processes=3,decision_vector_comparisons=36,layer0_boundary_comparisons=162,byte_identical=True,rows=probe_rows),scope="The final865708e source/image is separately bound. The diagnostic namespace fix changes no arithmetic, final host-token endpoint or normal trace path; the optional layer0 dump already occurs after that endpoint. Probe traces additionally expose nine layer0 intermediates, not full24-layer state.")
report["totals"]=dict(model_processes=10,baseline_processes=6,interleaved_processes=4,attempt2=dict(model_processes=6,decision_vector_comparisons=108,windows=["2sessions36vectors","4sessions72vectors"]),final_source=dict(model_processes=4,decision_vector_comparisons=108,layer0_boundary_comparisons=162,windows=["normal4sessions72vectors","probe2sessions36decisions+162boundaries"]),all_frozen_processes_serial_by_recorded_intervals=True,reviewer_model_runs=0,reviewer_GPU_runs=0,reviewer_builds=0)
# Existing frozen summaries already carry the per-vector SHA inventory; avoid duplicating it.
for row in report["comparisons"].values():row.pop("rows")
report["additional_final_source_validation"]["normal_final4"].pop("rows")
report["additional_final_source_validation"]["probe_final2"].pop("rows")
report["vector_inventory_policy"]="All expected numeric files were independently read byte-for-byte and rehashed, with exact path/file-set checks. Complete per-vector SHA inventories remain in the three explicitly hashed original summary files; they are not duplicated here."
(S/"isolation-independent-review.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
print(json.dumps({"report":identity(S/"isolation-independent-review.json"),"counts":report["totals"],"compared":{k:v["decision_vector_comparisons"] for k,v in comparisons.items()}}))
