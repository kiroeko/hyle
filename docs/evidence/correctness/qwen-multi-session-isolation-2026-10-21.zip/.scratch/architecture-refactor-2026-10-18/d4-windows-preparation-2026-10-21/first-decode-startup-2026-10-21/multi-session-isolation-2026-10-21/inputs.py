"""Small distinct fixed journeys for shared-model session isolation checks."""
from pathlib import Path
import hashlib
import json


S = Path(__file__).resolve().parent
F = S.parent
ROOT = next(p for p in S.parents if (p / 'AGENTS.md').is_file())


def identity(path):
    p = Path(path).resolve()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def put(path, text):
    b = text.encode('utf-8')
    if path.exists():
        assert path.read_bytes() == b, 'Preserve changed input: ' + str(path)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b)


def main():
    original = json.loads((F / 'multiturn/inputs/plan.json').read_text(encoding='utf-8'))
    short = original['plans']['short']
    prompt = short['phases'][0]['ids']
    tape = short['phases'][1]['ids'] + short['phases'][2]['ids'] + short['phases'][3]['ids']
    assert len(prompt) == 128 and len(tape) == 39
    plans = {
        'alice': [('prompt', prompt), ('decode', tape[:4]), ('prompt', tape[4:20]), ('decode', tape[20:23])],
        'bob': [('prompt', list(reversed(prompt[:23]))), ('decode', tape[8:11]), ('prompt', tape[24:28]), ('decode', tape[28:32])],
        'carol': [('prompt', prompt[-16:]), ('decode', tape[2:4]), ('prompt', tape[14:18]), ('decode', tape[33:38])],
        'dave': [('prompt', prompt[31:35]), ('decode', tape[18:23]), ('prompt', list(reversed(prompt[48:64]))), ('decode', tape[36:38])],
    }
    cases = {}
    for name, phases in plans.items():
        directory = S / 'inputs' / name
        lines, calls, visible = [], [], 0
        for i, (kind, ids) in enumerate(phases):
            filename = f'{i + 1:02}-{kind}.ids'
            put(directory / filename, ' '.join(map(str, ids)) + '\n')
            lines.append(f'{kind} {filename}')
            turn = i // 2 + 1
            count = 1 if kind == 'prompt' else len(ids)
            for j in range(count):
                chunk = ids if kind == 'prompt' else [ids[j]]
                visible += len(chunk)
                label = f'round{turn}_' + ('prefill' if kind == 'prompt' else f'decode{j + 1}')
                calls.append(dict(name=label, ids=chunk, visible_tokens=visible, phase=i))
        put(directory / 'schedule.txt', '\n'.join(lines) + '\n')
        assert len(calls) == 9 and visible <= 256
        cases[name] = dict(schedule=identity(directory / 'schedule.txt'), calls=calls,
            generated_tokens=len(calls), processed_tokens=visible, capacity=256)
    manifests = {}
    for count in (2, 4):
        path = S / 'inputs' / f'sessions{count}.txt'
        names = list(cases)[:count]
        put(path, ''.join(f'{name} {name}/schedule.txt\n' for name in names))
        manifests[str(count)] = dict(manifest=identity(path), session_ids=names,
            dispatch_order=[name for _ in range(9) for name in names],
            generated_tokens=sum(cases[name]['generated_tokens'] for name in names),
            processed_tokens=sum(cases[name]['processed_tokens'] for name in names))
    result = dict(source=identity(F / 'multiturn/inputs/plan.json'), cases=cases, manifests=manifests,
        policy='Teacher-forced inputs from existing fixed IDs. Compare exact same per-session journey against the retained single-session consumer. Round-robin is one full evaluate call at a time on one original queue; no simultaneous execution or service throughput claim.',
        expected_vectors_per_session=18, GPU_runs=0, builds=0)
    path = S / 'inputs/plan.json'
    if path.exists():
        assert json.loads(path.read_text(encoding='utf-8')) == result
    path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({name: {key: case[key] for key in ('generated_tokens', 'processed_tokens')} for name, case in cases.items()}, indent=2))


if __name__ == '__main__':
    main()
