#include "session_schedule.h"

#include <iostream>
#include <string_view>

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  const std::filesystem::path root(argv[1]);
  const auto sessions = qwen35::benchmark::read_session_schedules(
      root / "sessions.txt", 16, 6, 2);
  if (sessions.size() != 2 || sessions[0].id != "Alpha_1" || sessions[1].id != "b-2" ||
      sessions[0].phases.size() != 4 || sessions[1].phases.size() != 4 ||
      sessions[0].phases[0].ids != std::vector<std::int32_t>({1, 2}) ||
      sessions[1].phases[3].ids != std::vector<std::int32_t>({6}) ||
      sessions[0].phases[2].turn != 2 || sessions[1].phases[3].turn != 2 ||
      qwen35::benchmark::phase_name(sessions[1].phases[3], 0) != "round2_decode1")
    return 3;
  // Each session fits exactly six tokens; their aggregate twelve is legal.
  std::cout << "PASS relative_quoted_paths_and_independent_complete_turns\n";
  std::size_t rejected = 0;
  const auto rejects = [&](const char *name, std::size_t capacity,
                           std::size_t max_sessions, std::string_view expected) {
    try {
      (void)qwen35::benchmark::read_session_schedules(root / name, 16, capacity, max_sessions);
    } catch (const std::runtime_error &error) {
      if (std::string_view(error.what()).find(expected) != std::string_view::npos) {
        ++rejected;
        std::cout << "PASS reject_" << name << '\n';
        return true;
      }
      std::cerr << "wrong rejection for " << name << ": " << error.what() << '\n';
      return false;
    }
    std::cerr << "accepted " << name << '\n';
    return false;
  };
  if (!rejects("empty.txt", 6, 2, "at least one session") ||
      !rejects("duplicate.txt", 6, 2, "duplicate session ID") ||
      !rejects("invalid-id.txt", 6, 2, "only ASCII") ||
      !rejects("invalid-start.txt", 6, 2, "must start") ||
      !rejects("extra.txt", 6, 2, "expected SESSION_ID") ||
      !rejects("too-many.txt", 6, 1, "exceeds max_sessions") ||
      !rejects("missing.txt", 6, 2, "cannot open schedule") ||
      !rejects("bad-token.txt", 6, 2, "token ID outside vocabulary") ||
      !rejects("sessions.txt", 5, 2, "exceeds context capacity") ||
      !rejects("not-present.txt", 6, 0, "finite positive max_sessions") ||
      !rejects("not-present.txt", 6, (std::numeric_limits<std::size_t>::max)(), "finite positive max_sessions") ||
      !rejects("not-present.txt", 0, 2, "context capacity"))
    return 4;
  std::cout << "SESSION_MANIFEST_PASS positive=1 expected_rejections=" << rejected << '\n';
}
