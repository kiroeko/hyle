from pathlib import Path
import json,os,subprocess,sys,time,hashlib,shutil
R=Path.cwd();W=Path(__file__).resolve().parent;E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check'
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
sys.stdout.reconfigure(encoding='utf8',errors='replace');folder=W/'cpu-check1';folder.mkdir(exist_ok=True)
source=folder/'source';local=source/'engine/models/qwen35';local.mkdir(parents=True,exist_ok=True)
files=[]
for p in (R/'engine/models/qwen35').iterdir():
 if p.suffix in ('.h','.cc'):
  out=local/p.name;shutil.copyfile(p,out);files.append(dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
shutil.copyfile(W/'integration_probe.cc',source/'probe.cc')
(folder/'sources.json').write_text(json.dumps(files,indent=2)+'\n')
recipe=json.loads((E/'model/identity.json').read_text())['command'];command=[];skip=False
for arg in recipe:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 if arg.startswith(('/Fo','/Fd')):continue
 if arg.endswith('main.cc'):arg=str(source/'probe.cc')
 command.append(arg)
command+=['/Fo'+str(folder/'test.obj'),'/Fd'+str(folder/'test.pdb')]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
link=[arg for arg in json.loads((E/'link-cpu-dense.json').read_text())['command'] if not arg.endswith(('qwen.obj','entry.obj')) and not arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
link+=[str(folder/'test.obj'),'/OUT:'+str(folder/'recursive-probe.exe')]
ready=json.loads((E/'ready-cpu.json').read_text());dll=Path(ready['native_runtime']['path']);outdll=folder/dll.name
if not outdll.exists():os.link(dll,outdll)
runtime=dict(env,PATH=str(folder)+os.pathsep+ready['PATH'])
for label,args in [('compile',command),('link',link)]:
 (folder/(label+'-command.json')).write_text(json.dumps(args,indent=2)+'\n');print('START',label,flush=True);start=time.time()
 with (folder/(label+'.log')).open('wb') as f:p=subprocess.run(args,cwd=R,env=runtime,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 (folder/(label+'-process.json')).write_text(json.dumps(dict(exit=p.returncode,seconds=time.time()-start),indent=2)+'\n')
 print('END',label,p.returncode,(folder/(label+'.log')).read_text(encoding='utf8',errors='replace')[-3000:],flush=True)
 if p.returncode:sys.exit(p.returncode)
(folder/'identity.json').write_text(json.dumps(dict(image_sha256=hashlib.sha256((folder/'recursive-probe.exe').read_bytes()).hexdigest(),fresh_TUs=1,downloads=0,SDK_builds=0),indent=2)+'\n')
inputs=R/'.scratch/qwen-mtp-window-20261022/inputs/mtp'
cases=[('strict-and-failure',[str(folder/'recursive-probe.exe'),str(inputs)])]
for mode,k in [('greedy',0),('greedy',1),('greedy',2),('greedy',4),('random',2),('random',4)]:
 args=[str(folder/'recursive-probe.exe'),'--engine','--inputs',str(inputs),'--mtp','on','--mtp-max-drafts',str(k),'--capacity','256','--steps','8','--prefix-cache','off','--sampling',mode,'--replay','commands']
 if mode=='random':args+=['--top-k','8','--seed','123']
 cases.append((mode+'-K'+str(k),args))
schedule=folder/'schedules';schedule.mkdir(exist_ok=True)
prompt=(inputs/'prompt.ids').read_text();(schedule/'prompt.ids').write_text(prompt);(schedule/'next.ids').write_text('16 8\n')
for who in ('a','b','c'):(schedule/(who+'.txt')).write_text('prompt prompt.ids\ngenerate 4\nprompt next.ids\ngenerate 4\n')
(schedule/'sessions.txt').write_text('a a.txt\nb b.txt\nc c.txt\n')
for mode,n,r in [('greedy',2,2),('random',2,2),('greedy',1,1)]:
 args=[str(folder/'recursive-probe.exe'),'--engine','--inputs',str(inputs),'--mtp','on','--mtp-max-drafts','4','--capacity','256','--session-schedules',str(schedule/'sessions.txt'),'--max-sessions',str(n),'--active-sequences',str(r),'--prefix-cache','off','--sampling',mode,'--replay','commands']
 if mode=='random':args+=['--top-k','8','--seed','123']
 cases.append((mode+'-sessions-N'+str(n)+'-R'+str(r),args))
base_ids=[int(v) for v in prompt.split()]
for mode,generated in [('greedy',[71093,12305,198,464,19298,198,1445,18904]),('random',[71093,12305,198,1445,18904,1120,36760,11])]:
 checkpoint=schedule/(mode+'-checkpoints');checkpoint.mkdir(exist_ok=True)
 consumed=base_ids+generated[:-1]
 (checkpoint/'a.ids').write_text(' '.join(map(str,base_ids))+'\n')
 (checkpoint/'full.ids').write_text(' '.join(map(str,consumed))+'\n')
 suffix1=[16,8,11,13,17,19,23];suffix2=[31,33,37,41,43,47,53,59,61,67,71]
 (checkpoint/'partial1.ids').write_text(' '.join(map(str,consumed+suffix1))+'\n')
 (checkpoint/'partial2.ids').write_text(' '.join(map(str,consumed+suffix1+suffix2))+'\n')
 (checkpoint/'a.txt').write_text('prompt a.ids\ngenerate 8\n')
 (checkpoint/'full.txt').write_text('prompt full.ids\ngenerate 2\n')
 (checkpoint/'partial1.txt').write_text('prompt partial1.ids\ngenerate 1\n')
 (checkpoint/'partial2.txt').write_text('prompt partial2.ids\ngenerate 2\n')
 for kind,text in [('full','a a.txt\nb full.txt\n'),('partial-churn','a a.txt\nb partial1.txt\nc partial2.txt\n')]:
  manifest=checkpoint/(kind+'.manifest.txt');manifest.write_text(text)
  args=[str(folder/'recursive-probe.exe'),'--engine','--inputs',str(inputs),'--mtp','on','--mtp-max-drafts','4','--capacity','256','--session-schedules',str(manifest),'--max-sessions','1','--active-sequences','1','--prefix-cache','auto','--sampling',mode,'--replay','commands']
  if mode=='random':args+=['--top-k','8','--seed','123']
  cases.append((mode+'-checkpoint-'+kind,args))
cases=[(name,args) for name,args in cases if name in ('strict-and-failure','greedy-K4','random-K4')]
ones=schedule/'one.txt';(schedule/'one.ids').write_text('7\n');ones.write_text('prompt one.ids\ngenerate 1\n')
for mode in ('greedy','random'):
 args=[str(folder/'recursive-probe.exe'),'--engine','--inputs',str(inputs),'--mtp','on','--mtp-max-drafts','4','--capacity','1','--schedule',str(ones),'--prefix-cache','off','--sampling',mode,'--replay','commands']
 if mode=='random':args+=['--top-k','8','--seed','123']
 cases.append((mode+'-context1',args))
summary=[]
for label,args in cases:
 case=folder/label;case.mkdir(exist_ok=True);(case/'command.json').write_text(json.dumps(args,indent=2)+'\n');start=time.time();print('START',label,flush=True)
 with (case/'stdout.log').open('wb') as out,(case/'stderr.log').open('wb') as err:p=subprocess.run(args,cwd=R,env=runtime,stdout=out,stderr=err,timeout=180)
 info=dict(exit=p.returncode,seconds=time.time()-start);(case/'process.json').write_text(json.dumps(info,indent=2)+'\n')
 print('END',label,info,flush=True)
 if p.returncode:print((case/'stderr.log').read_text(encoding='utf8',errors='replace')[-3000:],flush=True)
 else:
  lines=(case/'stdout.log').read_text(encoding='utf8',errors='replace').splitlines();parsed=[json.loads(s) for s in lines if s.startswith('{')];(case/'parsed.json').write_text(json.dumps(parsed,indent=2)+'\n');print([(d.get('generated_ids'),d.get('sampling_cursor_draw')) for d in parsed],flush=True)
 summary.append(dict(case=label,**info))
(folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
sys.exit(1 if any(d['exit'] for d in summary) else 0)
