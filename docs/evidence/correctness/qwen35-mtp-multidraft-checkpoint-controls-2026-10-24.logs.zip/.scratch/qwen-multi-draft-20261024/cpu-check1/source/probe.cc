#include "engine/models/qwen35/main.cc"
namespace q=qwen35;
void require(bool value,const char*why){if(!value)throw std::runtime_error(why);}
int main(int argc,char**argv){try{
 if(argc>1&&std::string_view(argv[1])=="--engine")return q::run(argc-1,argv+1);
 if(argc!=2)throw std::runtime_error("integration-probe INPUTS");
 const std::filesystem::path input=argv[1];auto owner=std::make_shared<std::vector<std::int32_t>>(q::read_ids(input/"prompt.ids"));const auto &prompt=*owner;
 constexpr std::size_t context=256;auto plan=q::cache::plan(context,1,prompt.size(),q::recurrent_bytes(q::state_schema_for(context)),1,5,true);
 q::Model::Sampling policy;policy.enabled=true;policy.policy.top_k=8;policy.seed=123;
 q::Model model(input/"weights.tsv",context,plan,{},false,q::ReplayPolicy::kCommands,SIZE_MAX,policy);model.max_drafts=4;
 std::vector<std::size_t> prefills{prompt.size(),2,3,4,5};model.prepare_family(prefills,false,1,q::GraphRole::kMtpPrefill);
 for(auto rows:prefills)model.plan_replay_uses(rows,1,30,q::GraphRole::kMtpPrefill);
 const std::array<std::size_t,5> widths{1,2,3,4,5};model.prepare_family(widths,false,1,q::GraphRole::kVerify);
 for(auto rows:widths){model.plan_replay_uses(rows,1,30,q::GraphRole::kVerify);model.prepare_draft_program(rows,false);if(rows>1)model.prepare_prefix_sampling(rows-1);}
 for(auto rows:{std::size_t{1},std::size_t{2}})model.prepare_draft_program(rows,true);
 const std::array single{std::size_t{1}},prefill{prompt.size()};
 for(auto role:{q::GraphRole::kMtpSingle,q::GraphRole::kMtpCatchupSingle}){model.prepare_family(single,false,1,role);model.plan_replay_uses(1,1,30,role);}
 auto session=model.create_session(prefill,{},q::GraphRole::kMtpPrefill,q::cache::SamplingCursor{123,7,0});q::MtpReplayLedger ledger(32,5);
 q::prepare_mtp_replay_record(ledger,*session,q::GraphRole::kMtpPrefill,prompt,false,0,0,owner);
 model.prepare_evaluation(*session,prompt,nullptr,q::GraphRole::kMtpPrefill);model.submit_evaluation(*session);model.finish_evaluation(*session,"prefill",{},false,nullptr,nullptr,nullptr,nullptr,{},&ledger);
 const auto first_boundary=q::mtp_boundary(*session->head);auto first_head=session->head;
 const std::array<std::int32_t,2> eos{248044,248046};
 {
  std::vector<q::c::ReadLease> goodq;auto proposals=model.propose_recursive(*session,2,eos,&goodq);require(proposals.size()==3,"fixture ended during sampler failure check");
  q::Tensor logits(model.execution.device(),q::dense(q::Type::kFloat32,{3,q::vocabulary}));std::vector<float> zeros(3*q::vocabulary);logits.write<float>(zeros);
  q::Tensor bad(model.execution.device(),q::dense(q::Type::kFloat32,{1,q::vocabulary}));std::vector<float> empty(q::vocabulary,-std::numeric_limits<float>::infinity());bad.write<float>(empty);bad.freeze(model.execution);
  std::vector<q::c::ReadLease> invalid{bad.ready,goodq[1]};bool failed=false;
  try{(void)model.sample_recursive_prefix(logits.read(),std::span<const std::int32_t>(proposals).subspan(1),invalid,session->head->sampling);}catch(const std::exception&){failed=true;}
  require(failed&&session->head==first_head&&q::mtp_boundary(*session->head)==first_boundary,"invalid q published head/RNG");
  auto retry=model.sample_recursive_prefix(logits.read(),std::span<const std::int32_t>(proposals).subspan(1),goodq,session->head->sampling);require(retry.accepted.size()==2&&retry.final_ids.size()==2,"sampler failed to release pins/retry original finite program");
 }
 first_head.reset();
 for(std::size_t round=0;round<3&&!q::is_end_of_generation(session->head->next_id);++round){
  const auto pending=session->head->next_id;std::vector<q::c::ReadLease> qs;auto ids=model.propose_recursive(*session,4,eos,&qs);
  q::prepare_mtp_replay_record(ledger,*session,q::GraphRole::kVerify,std::span(&pending,1),true,16,0,{},4);
  const std::array in{q::EvaluationRequest{session,ids}};const std::array out{q::EvaluationOutput{.session=session,.name="recursive",.trace_states=false,.mtp_ledger=&ledger}};
  model.prepare_evaluations(in,nullptr,q::GraphRole::kVerify);model.submit_evaluations();const std::array select{q::MtpGenerationSelection{session,pending,16,qs}};std::array<q::MtpRoundResult,1> result;model.finish_recursive_mtp(select,eos,out,result);
 }
 const auto expected=q::mtp_boundary(*session->head);require(ledger.committed_count>1,"no recursive ledger episode");
 q::check(session->stop());require(q::take(session->try_retire()),"original session not retired");session.reset();
 // The earlier source alias is intentionally released before N=1 restoration.
 first_head.reset();
 auto restored=q::restore_mtp_session(model,ledger,{},false);require(q::mtp_boundary(*restored->head)==expected,"strict random replay changed the actual acceptance/RNG/lag boundary");
 q::check(restored->stop());require(q::take(restored->try_retire()),"strict session not retired");restored.reset();
 auto rebuilt=q::rebuild_mtp_session(model,ledger,{},false);require(rebuilt->length()==expected.length&&rebuilt->head->next_id==expected.next_id&&rebuilt->head->sampling==expected.sampling&&rebuilt->head->draft->lag==0,"committed rebuild did not preserve historical pending/RNG or normalize lag");
 // An actual completed Snapshot from an admitted family survives its retired
 // Phase/Family eviction; the next exact user suffix is prepared cold only.
 for(auto rows:{std::size_t{7},std::size_t{11}}){
  model.admit_exact_shape(rows,1,q::GraphRole::kMtpPrefill);
  std::vector<std::int32_t> more(rows,16);more[0]=rebuilt->head->next_id;
  model.prepare_evaluation(*rebuilt,more,nullptr,q::GraphRole::kMtpPrefill);model.submit_evaluation(*rebuilt);model.finish_evaluation(*rebuilt,"late_suffix");
 }
 require(model.exact_admissions==2&&model.exact_evictions==1&&model.admitted_exact_keys.size()==1,"late exact family/phase inventory was not bounded by N*R");
 std::cout<<"{\"strict_random_episodes\":"<<ledger.committed_count<<",\"strict_boundary_match\":true,\"committed_rebuild_pending_rng_match\":true,\"invalid_q_atomic_and_retry\":true,\"exact_admissions\":2,\"exact_evictions\":1,\"draw\":"<<expected.sampling.draw<<",\"length\":"<<expected.length<<",\"performance_claim\":false,\"quality_claim\":false}\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
