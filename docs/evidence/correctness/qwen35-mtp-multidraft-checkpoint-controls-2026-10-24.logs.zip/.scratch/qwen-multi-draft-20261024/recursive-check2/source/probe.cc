#include "engine/models/qwen35/main.cc"
namespace q=qwen35;
void require(bool value,const char *why){if(!value)throw std::runtime_error(why);}
int main(int argc,char**argv){try{
 if(argc>1&&std::string_view(argv[1])=="--engine")return q::run(argc-1,argv+1);
 if(argc!=2)throw std::runtime_error("recursive-probe INPUTS");
 const std::filesystem::path input=argv[1]; auto prompt=q::read_ids(input/"prompt.ids");prompt.resize(15);
 constexpr std::size_t context=64,max_width=5;
 const auto plan=q::cache::plan(context,2,15,q::recurrent_bytes(q::state_schema_for(context)),1,max_width,true);
 q::Model model(input/"weights.tsv",context,plan,{},false,q::ReplayPolicy::kCommands);
 const std::array prompt_shape{prompt.size()},single{std::size_t{1}};const std::array<std::size_t,5> widths{1,2,3,4,5};
 model.prepare_family(prompt_shape,false,1,q::GraphRole::kMtpPrefill);model.plan_execution(prompt_shape,1,q::GraphRole::kMtpPrefill);
 model.prepare_family(widths,false,1,q::GraphRole::kVerify);
 for(auto width:widths){model.plan_replay_uses(width,1,30,q::GraphRole::kVerify);model.prepare_draft_program(width,false);}
 for(auto width:{std::size_t{1},std::size_t{2}})model.prepare_draft_program(width,true);
 for(auto role:{q::GraphRole::kMtpSingle,q::GraphRole::kMtpCatchupSingle}){model.prepare_family(single,false,1,role);model.plan_replay_uses(1,1,30,role);}
 auto original=model.create_session(prompt_shape,{},q::GraphRole::kMtpPrefill);
 model.prepare_evaluation(*original,prompt,nullptr,q::GraphRole::kMtpPrefill);model.submit_evaluation(*original);model.finish_evaluation(*original,"prefill");
 const auto base=original->head;const std::array<std::int32_t,2> eos{248044,248046}; std::size_t cases=0;
 for(auto width:{std::size_t{3},std::size_t{5}}){
  auto ids=model.propose_recursive(*original,width-1,eos);require(ids.size()==width,"fixture proposal terminated early");
  require(original->head==base,"proposal published state");
  for(std::size_t n=1;n<=width;++n){
   auto session=model.create_session({},base,q::GraphRole::kMtpSingle);
   const std::array requests{q::EvaluationRequest{session,ids}};const std::array outputs{q::EvaluationOutput{.session=session,.name="forced_prefix"}};
   model.prepare_evaluations(requests,nullptr,q::GraphRole::kVerify);model.submit_evaluations();std::array<std::int32_t,1> next{-1};
   model.finish_selected_evaluations(outputs,next,[&](auto candidates,q::StepState&step,auto selected){step.members[0].accepted_tokens=n;selected[0]=16; (void)candidates;},[&](q::StepState&step){model.repair_recursive_draft(step);});
   require(session->length()==base->length+n,"wrong target prefix");require(session->head->draft->lag==(n==1?0u:1u),"wrong canonical lag");
   require(session->head->draft->frontier+session->head->draft->lag==session->length(),"draft frontier did not match target");
   require(session->head->draft->catchup_token==(n==1?-1:ids[n-1]),"wrong draft catchup token");
   require(session->head->sampling==base->sampling,"greedy repair changed RNG");
   auto continuation=model.propose_recursive(*session,2,eos);const std::array req2{q::EvaluationRequest{session,continuation}};const std::array out2{q::EvaluationOutput{.session=session,.name="recursive_continuation"}};
   model.prepare_evaluations(req2,nullptr,q::GraphRole::kVerify);model.submit_evaluations();const std::array selects{q::MtpGenerationSelection{session,continuation[0],3}};std::array<q::MtpRoundResult,1> results;
   model.finish_recursive_mtp(selects,eos,out2,results);require(!results[0].emitted.empty(),"recursive continuation emitted nothing");
   require(original->head==base,"repair changed immutable source");std::cout<<"PASS K="<<width-1<<" consumed_prefix="<<n<<" repair_and_recursive_continue\n";++cases;
  }
 }
 auto session=model.create_session({},base,q::GraphRole::kMtpSingle);auto ids=model.propose_recursive(*session,2,eos);const std::array req{q::EvaluationRequest{session,ids}};const std::array out{q::EvaluationOutput{.session=session,.name="failure"}};
 model.prepare_evaluations(req,nullptr,q::GraphRole::kVerify);model.submit_evaluations();std::array<std::int32_t,1> next{-1};bool failed=false;
 try{model.finish_selected_evaluations(out,next,[&](auto candidates,q::StepState&step,auto selected){step.members[0].accepted_tokens=2;selected[0]=candidates[1];},[&](q::StepState&step){model.repair_recursive_draft(step);throw std::runtime_error("injected after repair, before publication");});}catch(const std::exception&){failed=true;}
 require(failed&&session->head==base&&session->head->sampling==base->sampling,"repair failure changed head or RNG");
 std::cout<<"{\"forced_prefix_cases\":"<<cases<<",\"recursive_continuations\":"<<cases<<",\"atomic_failure_check\":true,\"performance_claim\":false,\"quality_claim\":false}\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}

