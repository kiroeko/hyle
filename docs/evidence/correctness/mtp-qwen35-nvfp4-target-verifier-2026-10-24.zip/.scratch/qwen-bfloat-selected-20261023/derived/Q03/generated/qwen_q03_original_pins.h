#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>
#include <span>
#include <vector>
#include "qwen_bfloat_original_roles.h"
#include "qwen_nvfp4_target_fragment.h"

// Actual original source metadata/pins. No loader/executor or generated weights.
// specs() binds49 original physical roles; nextn_specs() remains16 unique.
// Original NVFP4 quartets stay packed and execute through Nvfp4Linear.
// A generated pin header/case registration is not a numerical pass.
namespace qwen_bfloat_original_artifacts::q03 {
namespace roles=qwen_bfloat_original_roles;
inline constexpr qwen_original_mtp_roles::Identity kIdentity{
    "AxionML/Qwen3.5-2B-NVFP4","6f2ad4febe92be529de499b08f0020f5ff06bf25","NVFP4","model.safetensors"};
inline constexpr qwen_full_attention_fragment::Geometry kGeometry{
    2048,8,2,256,64,1.e-6F,0.F,hyle::compute::DataType::kBFloat16};
inline constexpr std::int64_t kIntermediate=6144,kVocabulary=248320;
inline constexpr float kRopeTheta=10'000'000.F;
inline constexpr std::uint64_t kOriginalBytes=1168279608ULL;
inline constexpr std::string_view kPlanSha256="c0932a8073d2421826100aa4d41c03a69216308ec1310800a28678012e6ded31";
inline constexpr std::string_view kReceiptSha256="325b95e7c1ac4f7d1ba9d7a5ccfbb6f639425d34518beed00ced80e9eda5e469";
inline constexpr std::string_view kManifestSha256="3a71be91f6ed16ed4b7366715b722c2fb4a1c8b83bdc17f201aa71a35c4078fd";
inline constexpr std::string_view kTargetLayer="model.language_model.layers.23";
inline constexpr std::string_view kTargetNorm="model.language_model.norm.weight";
inline constexpr roles::VocabularyNames kVocabularyNames{
    "model.language_model.embed_tokens.weight","model.language_model.embed_tokens.weight"};
// The pinned publisher does not identify an official Qwen base
// revision. Both model/artifact identities below therefore name the
// exact publisher artifact, never an assumed upstream commit.
inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{
    .model_publisher="AxionML",
    .model_repository="AxionML/Qwen3.5-2B-NVFP4",
    .model_family="qwen3.5",
    .model_name="Qwen3.5-2B-NVFP4",
    .model_revision="6f2ad4febe92be529de499b08f0020f5ff06bf25",
    .configuration_digest="34141891d73c478d2ba087c470a62b3fbd70ce07fff4e14265d762bb44d4aa40",
    .artifact_repository=kIdentity.repository,.artifact_revision=kIdentity.revision,
    .variant=kIdentity.variant,
    // Whole pinned safetensors header identity, not whole body SHA.
    .manifest_digest="446f550bc6ff9f578b60779bbf3ac49718cf03f86ab0b4486db8273fd30b0c8a",
    .format_family="safetensors"};
static_assert(kProfile.complete());
// Fixed Qwen3_5 RMSNorm and NextN source stores F32(1+BF16delta).
inline constexpr roles::DenseNormConventions kNormConventions{
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,
    roles::NormConvention::kDeltaPlusOne};
inline constexpr std::array<roles::PinnedFile,16> kNextnFiles{{
    {"mtp.pre_fc_norm_hidden.weight.bf16","cde85c36a07008e762cc65a25a3e778d0aecd3df643dd579f764d5ed134aff2a"},
    {"mtp.pre_fc_norm_embedding.weight.bf16","74b00671922e5f220913a5ce2ba95c3a1b37c772aa033bf34ffc469865246534"},
    {"mtp.fc.weight.bf16","04a296fcc7c41188d9551afc386a38ae75b2ade3ccefe0a75d85f7472f04b60c"},
    {"mtp.layers.0.input_layernorm.weight.bf16","01af4181b176c9f1f0c9d99f3881161ab1c63c6e666255ab808cf293d1611525"},
    {"mtp.layers.0.self_attn.q_proj.weight.bf16","7b45fe45a43ea32ce66fd5357e29ee122f7ccadbc724663d9c63c8e5f0a25ce4"},
    {"mtp.layers.0.self_attn.k_proj.weight.bf16","ebe58f1ab9fda4a8368ed9e95ad1fdfc1c60d4c55ad3c562cba8792c5d88feeb"},
    {"mtp.layers.0.self_attn.v_proj.weight.bf16","5ecec5c2354fa5fecf20ab5da3b9dfdf040fc9484ec28f2db5908c7c76db0e6c"},
    {"mtp.layers.0.self_attn.o_proj.weight.bf16","5fa2b6fc75e80099387274afe6468069f643b015a7336877fcb85ad7d3038d18"},
    {"mtp.layers.0.self_attn.q_norm.weight.bf16","2f54ef9aae55165775c5974b7cf0a329f1df5050cb18fc8e13699272dbeb3dbf"},
    {"mtp.layers.0.self_attn.k_norm.weight.bf16","9f5ddb8c876889339b54277ac29d454432ada6db7ae514999fe5408a4fc8bf63"},
    {"mtp.layers.0.post_attention_layernorm.weight.bf16","19f28dcd9ecf86ce8e15d148522f8eb2107869786b7ebc760fbc2c5a9a01552d"},
    {"mtp.layers.0.mlp.gate_proj.weight.bf16","8ecbb1330b7e5e7b8e5a84dffdac6ac3c8ff535661ab6d51eedd526ab3ae34a7"},
    {"mtp.layers.0.mlp.up_proj.weight.bf16","4f19bbf4ccc04b3919e674fbd7d58b042ebbcb24b66a0a3b6990fee716dd66fc"},
    {"mtp.layers.0.mlp.down_proj.weight.bf16","4c67381e935cd66110fe2c5a297757d68462bfce6b0fbb499e985d374a43d43a"},
    {"mtp.norm.weight.bf16","50a5dcfd925e824ca6abd9c3b5f4cd9a5222c65256ed8d4bf08a6eadfe64259f"},
    {"model.language_model.embed_tokens.weight.bf16","b222b11204158144e369ae8fca02cab9cb63b0a8cde1dd59dd4d0c60690824ed"},
}};
inline auto nextn_specs() {
  return roles::dense_specs(kGeometry,kIntermediate,kVocabulary,kNextnFiles,kVocabularyNames);
}
// rank0 retains the original F32 scalar shape []; unused shape slots are0.
struct RawRolePin final {
  std::string_view name,file,sha256,dtype;
  std::array<std::int64_t,2> shape;std::size_t rank;std::uint64_t bytes;
};
inline constexpr std::array<RawRolePin,49> kRawPins{{
    {"model.language_model.layers.23.mlp.down_proj.input_scale","model.language_model.layers.23.mlp.down_proj.input_scale.f32","741e3c22b7c9973d5957c573216b768266d610ab1828db23ccf34099692dc355","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.mlp.down_proj.weight_scale_2","model.language_model.layers.23.mlp.down_proj.weight_scale_2.f32","8d1a4c83ae9035403da43cbd9e70f7c5e2396bba9cffc0f4a446c3003c8ed7e2","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.mlp.gate_proj.input_scale","model.language_model.layers.23.mlp.gate_proj.input_scale.f32","db61ba4ffc4c64eea29d84b3db1c04685cc2f62d871009c79fbd3fb8ab79c092","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.mlp.gate_proj.weight_scale_2","model.language_model.layers.23.mlp.gate_proj.weight_scale_2.f32","6d62f7799d9041cef7a3b7cd8bdb1fdc17c4585eb9362f57ecc99e0b7f206c8a","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.mlp.up_proj.input_scale","model.language_model.layers.23.mlp.up_proj.input_scale.f32","db61ba4ffc4c64eea29d84b3db1c04685cc2f62d871009c79fbd3fb8ab79c092","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.mlp.up_proj.weight_scale_2","model.language_model.layers.23.mlp.up_proj.weight_scale_2.f32","6d62f7799d9041cef7a3b7cd8bdb1fdc17c4585eb9362f57ecc99e0b7f206c8a","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.k_proj.input_scale","model.language_model.layers.23.self_attn.k_proj.input_scale.f32","db7aa383c72a852feea796d0f55c131d54ccf4004e4a96e0edcb949445a6bd23","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.k_proj.weight_scale_2","model.language_model.layers.23.self_attn.k_proj.weight_scale_2.f32","3269d7a96f0683ba4d4266a9e373a85488201b10b9c4a95c91614b752f22d6fc","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.o_proj.input_scale","model.language_model.layers.23.self_attn.o_proj.input_scale.f32","bbd59dc5092293cbfee83d94509633036b1ae72c36e47e8794de7a511d2d206c","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.o_proj.weight_scale_2","model.language_model.layers.23.self_attn.o_proj.weight_scale_2.f32","b557db0d8fe7c9e774a616d6a611ba9c530c9126c9992bdbf8edf1c36a57bcfd","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.q_proj.input_scale","model.language_model.layers.23.self_attn.q_proj.input_scale.f32","db7aa383c72a852feea796d0f55c131d54ccf4004e4a96e0edcb949445a6bd23","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.q_proj.weight_scale_2","model.language_model.layers.23.self_attn.q_proj.weight_scale_2.f32","3269d7a96f0683ba4d4266a9e373a85488201b10b9c4a95c91614b752f22d6fc","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.v_proj.input_scale","model.language_model.layers.23.self_attn.v_proj.input_scale.f32","db7aa383c72a852feea796d0f55c131d54ccf4004e4a96e0edcb949445a6bd23","F32",{0,0},0,4ULL},
    {"model.language_model.layers.23.self_attn.v_proj.weight_scale_2","model.language_model.layers.23.self_attn.v_proj.weight_scale_2.f32","3269d7a96f0683ba4d4266a9e373a85488201b10b9c4a95c91614b752f22d6fc","F32",{0,0},0,4ULL},
    {"model.language_model.embed_tokens.weight","model.language_model.embed_tokens.weight.bf16","b222b11204158144e369ae8fca02cab9cb63b0a8cde1dd59dd4d0c60690824ed","BF16",{248320,2048},2,1017118720ULL},
    {"model.language_model.layers.23.input_layernorm.weight","model.language_model.layers.23.input_layernorm.weight.bf16","fdc9d0c7b47d967d646d3b4bd8e5f5606ef46839f5b21e68b63c40b10b0ad824","BF16",{2048,0},1,4096ULL},
    {"model.language_model.layers.23.post_attention_layernorm.weight","model.language_model.layers.23.post_attention_layernorm.weight.bf16","72a235413e983f39082d677cce90f28b18516b2aa3f5de96a92d59707598d4c0","BF16",{2048,0},1,4096ULL},
    {"model.language_model.layers.23.self_attn.k_norm.weight","model.language_model.layers.23.self_attn.k_norm.weight.bf16","2a4412bc2388b7d4b7aca3a0b221cec7da8ca0f9fa56f031a5ea731e8103812a","BF16",{256,0},1,512ULL},
    {"model.language_model.layers.23.self_attn.q_norm.weight","model.language_model.layers.23.self_attn.q_norm.weight.bf16","a365f9f976d7b19e6476c69ccad2fd0fb5c98f2594c18f9c709c2946b595b9f0","BF16",{256,0},1,512ULL},
    {"model.language_model.norm.weight","model.language_model.norm.weight.bf16","0df050ad8e61ea06a06b50c0eb0ae6975d97fb5712dfb0dec2d0b154c0676dd5","BF16",{2048,0},1,4096ULL},
    {"mtp.fc.weight","mtp.fc.weight.bf16","04a296fcc7c41188d9551afc386a38ae75b2ade3ccefe0a75d85f7472f04b60c","BF16",{2048,4096},2,16777216ULL},
    {"mtp.layers.0.input_layernorm.weight","mtp.layers.0.input_layernorm.weight.bf16","01af4181b176c9f1f0c9d99f3881161ab1c63c6e666255ab808cf293d1611525","BF16",{2048,0},1,4096ULL},
    {"mtp.layers.0.mlp.down_proj.weight","mtp.layers.0.mlp.down_proj.weight.bf16","4c67381e935cd66110fe2c5a297757d68462bfce6b0fbb499e985d374a43d43a","BF16",{2048,6144},2,25165824ULL},
    {"mtp.layers.0.mlp.gate_proj.weight","mtp.layers.0.mlp.gate_proj.weight.bf16","8ecbb1330b7e5e7b8e5a84dffdac6ac3c8ff535661ab6d51eedd526ab3ae34a7","BF16",{6144,2048},2,25165824ULL},
    {"mtp.layers.0.mlp.up_proj.weight","mtp.layers.0.mlp.up_proj.weight.bf16","4f19bbf4ccc04b3919e674fbd7d58b042ebbcb24b66a0a3b6990fee716dd66fc","BF16",{6144,2048},2,25165824ULL},
    {"mtp.layers.0.post_attention_layernorm.weight","mtp.layers.0.post_attention_layernorm.weight.bf16","19f28dcd9ecf86ce8e15d148522f8eb2107869786b7ebc760fbc2c5a9a01552d","BF16",{2048,0},1,4096ULL},
    {"mtp.layers.0.self_attn.k_norm.weight","mtp.layers.0.self_attn.k_norm.weight.bf16","9f5ddb8c876889339b54277ac29d454432ada6db7ae514999fe5408a4fc8bf63","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.k_proj.weight","mtp.layers.0.self_attn.k_proj.weight.bf16","ebe58f1ab9fda4a8368ed9e95ad1fdfc1c60d4c55ad3c562cba8792c5d88feeb","BF16",{512,2048},2,2097152ULL},
    {"mtp.layers.0.self_attn.o_proj.weight","mtp.layers.0.self_attn.o_proj.weight.bf16","5fa2b6fc75e80099387274afe6468069f643b015a7336877fcb85ad7d3038d18","BF16",{2048,2048},2,8388608ULL},
    {"mtp.layers.0.self_attn.q_norm.weight","mtp.layers.0.self_attn.q_norm.weight.bf16","2f54ef9aae55165775c5974b7cf0a329f1df5050cb18fc8e13699272dbeb3dbf","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.q_proj.weight","mtp.layers.0.self_attn.q_proj.weight.bf16","7b45fe45a43ea32ce66fd5357e29ee122f7ccadbc724663d9c63c8e5f0a25ce4","BF16",{4096,2048},2,16777216ULL},
    {"mtp.layers.0.self_attn.v_proj.weight","mtp.layers.0.self_attn.v_proj.weight.bf16","5ecec5c2354fa5fecf20ab5da3b9dfdf040fc9484ec28f2db5908c7c76db0e6c","BF16",{512,2048},2,2097152ULL},
    {"mtp.norm.weight","mtp.norm.weight.bf16","50a5dcfd925e824ca6abd9c3b5f4cd9a5222c65256ed8d4bf08a6eadfe64259f","BF16",{2048,0},1,4096ULL},
    {"mtp.pre_fc_norm_embedding.weight","mtp.pre_fc_norm_embedding.weight.bf16","74b00671922e5f220913a5ce2ba95c3a1b37c772aa033bf34ffc469865246534","BF16",{2048,0},1,4096ULL},
    {"mtp.pre_fc_norm_hidden.weight","mtp.pre_fc_norm_hidden.weight.bf16","cde85c36a07008e762cc65a25a3e778d0aecd3df643dd579f764d5ed134aff2a","BF16",{2048,0},1,4096ULL},
    {"model.language_model.layers.23.mlp.down_proj.weight_scale","model.language_model.layers.23.mlp.down_proj.weight_scale.e4m3","2d5e0ed757454375331579faa1c1fd429b83a638dad6b707d626571317ee51f3","F8_E4M3",{2048,384},2,786432ULL},
    {"model.language_model.layers.23.mlp.gate_proj.weight_scale","model.language_model.layers.23.mlp.gate_proj.weight_scale.e4m3","fe598f033c70992397f4e7494fb824ed92dd075d2104bef0ba5f34735184033e","F8_E4M3",{6144,128},2,786432ULL},
    {"model.language_model.layers.23.mlp.up_proj.weight_scale","model.language_model.layers.23.mlp.up_proj.weight_scale.e4m3","706cacc2a913cba9ea121c9a8842cd17402d9414e402a8ae167874770243c8e6","F8_E4M3",{6144,128},2,786432ULL},
    {"model.language_model.layers.23.self_attn.k_proj.weight_scale","model.language_model.layers.23.self_attn.k_proj.weight_scale.e4m3","4b4f2f4266f3a3ed83a077579273ef703f22899d80dc2f6b2e8855b3ee78897a","F8_E4M3",{512,128},2,65536ULL},
    {"model.language_model.layers.23.self_attn.o_proj.weight_scale","model.language_model.layers.23.self_attn.o_proj.weight_scale.e4m3","4c4f6b56c9e4fb8503a786b1d3dd4978a6f9379896514fba0bb7a9121619930d","F8_E4M3",{2048,128},2,262144ULL},
    {"model.language_model.layers.23.self_attn.q_proj.weight_scale","model.language_model.layers.23.self_attn.q_proj.weight_scale.e4m3","82199e817ceb446861cc7df6ff9953e054e0de134e14f8db149366208f424668","F8_E4M3",{4096,128},2,524288ULL},
    {"model.language_model.layers.23.self_attn.v_proj.weight_scale","model.language_model.layers.23.self_attn.v_proj.weight_scale.e4m3","eb066c3d5044c98745c7ee1d6ce6a5573c6f3acdb4471587d29453c16234f58e","F8_E4M3",{512,128},2,65536ULL},
    {"model.language_model.layers.23.mlp.down_proj.weight","model.language_model.layers.23.mlp.down_proj.weight.u8","f16558c605215822d7fcde295ab6bd8f8be96bd17e6cab054898d629649519cf","U8",{2048,3072},2,6291456ULL},
    {"model.language_model.layers.23.mlp.gate_proj.weight","model.language_model.layers.23.mlp.gate_proj.weight.u8","4d89f408d18fce8b1d29faed6af3e52028fba6eecf3941b214399c97051e39fa","U8",{6144,1024},2,6291456ULL},
    {"model.language_model.layers.23.mlp.up_proj.weight","model.language_model.layers.23.mlp.up_proj.weight.u8","a9ba108cb051cb33d4de558bb7261477f79ca5fa1c1d36129334e6e5e0be08bd","U8",{6144,1024},2,6291456ULL},
    {"model.language_model.layers.23.self_attn.k_proj.weight","model.language_model.layers.23.self_attn.k_proj.weight.u8","b4f39dee33e399cf828b73d319efbf711b1a3b564ad330efd96678f95e6748b4","U8",{512,1024},2,524288ULL},
    {"model.language_model.layers.23.self_attn.o_proj.weight","model.language_model.layers.23.self_attn.o_proj.weight.u8","05d661fc40df57a7b0ba2195d05232fc9e91123519f03b41dcb81bd3fc653bd4","U8",{2048,1024},2,2097152ULL},
    {"model.language_model.layers.23.self_attn.q_proj.weight","model.language_model.layers.23.self_attn.q_proj.weight.u8","388ef4bd53acb24c524d13e1e005f26bafa3fa7b01c89a5a9d465f935e1f2d04","U8",{4096,1024},2,4194304ULL},
    {"model.language_model.layers.23.self_attn.v_proj.weight","model.language_model.layers.23.self_attn.v_proj.weight.u8","884d93cb486d3c4f8041234f59a43f05725f22d8d9e0ff0ed0e526a0ee828434","U8",{512,1024},2,524288ULL},
}};
struct Nvfp4ProjectionPins final {
  std::string_view prefix;std::int64_t outputs,reduction;
  std::size_t codes,scales,weight_scale_2,input_scale;
};
inline constexpr std::array<Nvfp4ProjectionPins,7> kTargetProjections{{
    {"model.language_model.layers.23.self_attn.q_proj",4096,2048,47,40,11,10},
    {"model.language_model.layers.23.self_attn.k_proj",512,2048,45,38,7,6},
    {"model.language_model.layers.23.self_attn.v_proj",512,2048,48,41,13,12},
    {"model.language_model.layers.23.self_attn.o_proj",2048,2048,46,39,9,8},
    {"model.language_model.layers.23.mlp.gate_proj",6144,2048,43,36,3,2},
    {"model.language_model.layers.23.mlp.up_proj",6144,2048,44,37,5,4},
    {"model.language_model.layers.23.mlp.down_proj",2048,6144,42,35,1,0},
}};
inline constexpr std::array<std::string_view,5> kTargetNormNames{
    "model.language_model.layers.23.input_layernorm.weight",
    "model.language_model.layers.23.post_attention_layernorm.weight",
    "model.language_model.layers.23.self_attn.q_norm.weight",
    "model.language_model.layers.23.self_attn.k_norm.weight",
    "model.language_model.norm.weight",
};
inline const RawRolePin &raw_pin(std::string_view name) {
  const auto found=std::find_if(kRawPins.begin(),kRawPins.end(),[&](const auto &row){return row.name==name;});
  if(found==kRawPins.end())throw std::runtime_error("Q03 original role is absent from the authenticated header");
  return *found;
}
inline void check_spec(const roles::Spec &spec) {
  const auto &raw=raw_pin(spec.name);const auto &description=spec.description;
  const auto dtype=description.data_type()==hyle::compute::DataType::kBFloat16?"BF16":
      description.data_type()==hyle::compute::DataType::kUInt8?"U8":
      description.data_type()==hyle::compute::DataType::kFloat8E4M3FN?"F8_E4M3":
      description.data_type()==hyle::compute::DataType::kFloat32?"F32":"unsupported";
  if(spec.file!=raw.file||spec.sha256!=raw.sha256||raw.dtype!=dtype||description.rank()!=raw.rank||
      !std::equal(description.dimensions().begin(),description.dimensions().end(),raw.shape.begin())||
      qwen_original_mtp_roles::detail::take(description.required_bytes(),"Q03 exact typed extent")!=raw.bytes)
    throw std::runtime_error("Q03 schema differs from its actual original name/dtype/shape/bytes/SHA");
}
inline std::vector<roles::Spec> specs() {
  auto result=nextn_specs();result.reserve(kRawPins.size());
  for(const auto &projection:kTargetProjections) {
    const std::array indexes{projection.codes,projection.scales,projection.weight_scale_2,projection.input_scale};
    std::array<std::string_view,4> names;std::array<roles::PinnedFile,4> files;
    for(std::size_t slot=0;slot<indexes.size();++slot) {
      const auto &pin=kRawPins.at(indexes[slot]);names[slot]=pin.name;files[slot]={pin.file,pin.sha256};
    }
    const auto quartet=roles::nvfp4_projection_specs(projection.outputs,projection.reduction,names,files);
    result.insert(result.end(),quartet.begin(),quartet.end());
  }
  for(const auto name:kTargetNormNames) {
    const auto &pin=raw_pin(name);
    const auto width=name.ends_with("q_norm.weight")||name.ends_with("k_norm.weight")?kGeometry.depth:kGeometry.hidden;
    result.push_back({pin.name,pin.file,pin.sha256,roles::sem::dense({width},hyle::compute::DataType::kBFloat16)});
  }
  std::uint64_t bytes=0;
  if(result.size()!=kRawPins.size())throw std::runtime_error("Q03 must bind exactly49 unique physical roles");
  for(std::size_t slot=0;slot<result.size();++slot) {
    check_spec(result[slot]);
    for(std::size_t previous=0;previous<slot;++previous)if(result[slot].name==result[previous].name)
      throw std::runtime_error("Q03 cannot alias a second physical vocabulary name");
    bytes+=raw_pin(result[slot].name).bytes;
  }
  if(bytes!=kOriginalBytes)throw std::runtime_error("Q03 original role payload total differs");
  return result;
}
inline std::array<qwen_nvfp4_target_fragment::ProjectionNames,7> target_projection_names() {
  std::array<qwen_nvfp4_target_fragment::ProjectionNames,7> result;
  for(std::size_t slot=0;slot<result.size();++slot) {
    const auto &projection=kTargetProjections[slot];
    result[slot]={kRawPins.at(projection.codes).name,kRawPins.at(projection.scales).name,
        kRawPins.at(projection.weight_scale_2).name,kRawPins.at(projection.input_scale).name};
  }
  return result;
}
} // namespace qwen_bfloat_original_artifacts::q03
