"""Root-only actual Q03 single-TU adapter on the published integration ABI.

No action runs on import. Missing/incomplete49-role acquisition or generated
pins rejects compile/link/run. Plan may describe a blocked future build without
creating a header. Reuses GQ lifecycle; no SDK/NVCC/worker/download workflow.
"""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ARTIFACT_DIR = S.parent
SCRIPT = Path(__file__).resolve()
ARTIFACT_TAG = 'Q03'
ORIGINAL_ROLES, ORIGINAL_BYTES = 49, 1168279608
ENVIRONMENT = 'HYLE_QWEN_Q03_ORIGINAL_DIR'
RUN_SOURCE = 'Q03 actual NVFP4 target23 plus BF16 NextN24 and one tied original vocabulary'
RUN_SCOPE = 'Actual selected49 original Q03 roles, same K1/12-member Head/accepted-prefix repair; upstream target22 input/history fixture; no whole-model quality or TPS claim'
R = S.parents[4]
QB = R / '.scratch/qwen-bfloat-selected-20261023'
GQ = R / '.scratch/qwen-gguf-selected-20261023'
PREVIOUS = QB / 'derived/integration'
SUPPORT = GQ / 'build.py'
SUPPORT_SHA = 'c7d66b79c345206a89bce7aec369f488e0cfb62d514b15006ebced426aecdd4b'
HEADER = ARTIFACT_DIR / 'generated/qwen_q03_original_pins.h'
MACRO = '/DHYLE_TEST_QWEN_Q03_ARTIFACTS_HEADER='
OLD_MACRO = '/DHYLE_TEST_QWEN_GGUF_ARTIFACTS_HEADER='
FORBIDDEN = ('/DHYLE_TEST_QWEN_B04_ARTIFACTS_HEADER=', '/DHYLE_TEST_QWEN_Q01_ARTIFACTS_HEADER=')
SUFFIX = 'Q03OriginalNvfp4TargetAndBFloatNextNFullVocabularyVerifierPublishesRepairedPrefix'
CASES = {key: 'QwenMtpStateConsumer.' + backend + SUFFIX
         for key, backend in (('cpu', 'Cpu'), ('cuda', 'Cuda'))}


def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()  # Only explicit small metadata/script inputs.
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def generator():
    return load('q03_real_pin_metadata', ARTIFACT_DIR / 'generate_pins.py')


def artifacts(header):
    header = Path(header).resolve()
    assert header == HEADER and header.is_file(), 'Actual generated Q03 header is required'
    gen = generator()
    plan, _, rows = gen.checked_metadata()  # Requires all49 original loose files and complete receipts.
    receipt = gen.fetch.identity(ARTIFACT_DIR / 'original-roles/acquisition.json')
    manifest = gen.fetch.identity(ARTIFACT_DIR / 'original-roles/manifest.json')
    actual_header = gen.header(plan, rows, receipt['sha256'], manifest['sha256'])
    assert header.read_text(encoding='utf-8-sig') == actual_header
    pins_path = header.with_suffix('.json')
    pins = read(pins_path)
    assert (pins['repository'], pins['revision'], pins['original_roles'], pins['source_bytes']) == (
        'AxionML/Qwen3.5-2B-NVFP4', '6f2ad4febe92be529de499b08f0020f5ff06bf25', 49, 1168279608)
    assert pins['source_receipt'] == receipt and pins['manifest'] == manifest
    assert pins['source_plan'] == gen.fetch.identity(ARTIFACT_DIR / 'roles-plan.json')
    assert pins['header'] == gen.fetch.identity(header)
    assert pins['body_rehashed'] is False and pins['artifact_executed'] is False
    # The generated file must contain the actual49-role schema, not merely
    # the old16 BF16 NextN subset or an S01 header sharing a similar API.
    assert 'namespace qwen_bfloat_original_artifacts::q03' in actual_header
    assert 'specs()' in actual_header and 'target_projection_names()' in actual_header
    paths = [header, pins_path, ARTIFACT_DIR / 'roles-plan.json',
        ARTIFACT_DIR / 'original-roles/acquisition.json', ARTIFACT_DIR / 'original-roles/manifest.json',
        ARTIFACT_DIR / 'original-roles/nextn-manifest.json', ARTIFACT_DIR / 'original-roles/target-manifest.json',
        ARTIFACT_DIR / 'generate_pins.py', ARTIFACT_DIR / 'fetch_roles.py']
    return [identity(path) for path in paths]


def configured():
    assert identity(SUPPORT)['sha256'] == SUPPORT_SHA
    job = load('q03_gq_lifecycle', SUPPORT)
    job.S, job.BASE = S, PREVIOUS / 'tests-link1'
    job.RECIPE = PREVIOUS / 'compile4/qwen-state/identity.json'
    job.MACRO, job.artifacts = MACRO, artifacts
    job.CASES = CASES
    job.legacy_environment = lambda: {ENVIRONMENT: ARTIFACT_DIR / 'original-roles'}
    original_command = job.b.host_command

    def host_command(recipe, source, tag, out):
        assert not any(arg.startswith((MACRO, *FORBIDDEN)) for arg in recipe)
        existing = [arg for arg in recipe if arg.startswith(OLD_MACRO)]
        assert existing == [OLD_MACRO + '"' + (GQ / 'S01/generated/qwen_gguf_original_artifacts.h').as_posix() + '"']
        # This image registers the explicitly configured artifact only. No old S01 generated macro, unrelated
        # artifact inputs or original-role environments are carried forward.
        return original_command([arg for arg in recipe if not arg.startswith(OLD_MACRO)], source, tag, out)
    job.b.host_command = host_command

    def report(*args, **kwargs):
        # Lifecycle is unchanged; correct its historical human-readable S01
        # compile label because this adapter's primary pins are explicit.
        args = tuple(arg.replace('real S01 pin dependency', 'real ' + ARTIFACT_TAG + ' pin dependency')
                     if isinstance(arg, str) else arg for arg in args)
        builtins.print(*args, **kwargs)
    job.print = report
    return job


def adapter():
    return dict(script=identity(SCRIPT), support=identity(SUPPORT),
        primary_artifact=ARTIFACT_TAG + ' actual' + str(ORIGINAL_ROLES) + ' roles', generated_macro=MACRO,
        legacy_S01_macro=False, B04_macro=False, cached_product_objects=13,
        new_host_TUs=1, SDK_builds=0, NVCC_builds=0, worker_builds=0, network_requests=0)


def annotate(job, path, **extra):
    value = read(path)
    value[ARTIFACT_TAG + '_adapter'] = adapter()
    value.update(extra)
    job.c.save(path, value)


def plan(job, attempt):
    gen = generator()
    range_plan, selected = gen.fetch.checked_plan()  # Metadata only; never invokes fetch main.
    base_path = PREVIOUS / 'tests-link1/link-plan.json'
    base = read(base_path)
    assert read(base_path.with_name('link.result.json'))['exit'] == 0
    records = [(item, read(item['path'])) for item in base['compiled_records']]
    products = [item for item, record in records
        if job.c.key(record['source']['path']) != job.c.key(job.SOURCE)]
    assert len(records) == 14 and len(products) == 13
    command = job.b.host_command(read(job.RECIPE)['command'], job.SOURCE, job.TAG, S / f'compile{attempt}' / job.TAG)
    command.insert(1, MACRO + '"' + HEADER.as_posix() + '"')
    assert sum(arg.startswith(MACRO) for arg in command) == 1
    assert not any(arg.startswith((OLD_MACRO, *FORBIDDEN)) for arg in command)
    actual_pins = artifacts(HEADER) if HEADER.is_file() else None
    proof, _ = job.retained_proof()
    destination = S / f'plan{attempt}.json'
    assert not destination.exists()
    job.c.save(destination, dict(prepared_only=True, source=identity(job.SOURCE),
        source_recipe=identity(job.RECIPE), base_link=identity(base_path),
        selected_roles=ORIGINAL_ROLES, selected_original_bytes=ORIGINAL_BYTES,
        actual_range_plan=identity(range_plan), original_range_plan=identity(ARTIFACT_DIR / 'roles-plan.json'), vocabulary=selected['vocabulary'],
        proposed_compile_command=command, actual_artifact_inputs=actual_pins,
        blocked_pending_actual_pins=actual_pins is None, generated_header_expected=str(HEADER),
        cached_product_records=products, retained_exact_comment_header_proof=proof,
        expected_cases=CASES, environment={ENVIRONMENT: str(ARTIFACT_DIR / 'original-roles')},
        CUDA_entry_placement='ordinary CUDA Context and device owner; no implicit CPU body',
        cpp_compiled=False, linked=False, native_executed=False, **{ARTIFACT_TAG + '_adapter': adapter()}))
    print(json.dumps(dict(plan=identity(destination), blocked_pending_actual_pins=actual_pins is None)))


def compile_one(job, attempt):
    job.host(attempt, HEADER)  # artifact guard runs before output-directory creation or compiler launch.
    folder = S / f'compile{attempt}/qwen-state'
    record = read(folder / 'identity.json')
    assert sum(arg.startswith(MACRO) for arg in record['command']) == 1
    assert not any(arg.startswith((OLD_MACRO, *FORBIDDEN)) for arg in record['command'])
    assert record['artifact_inputs'] == artifacts(HEADER)
    for name in ('identity.json', 'plan.json'):
        annotate(job, folder / name)


def link_one(job, attempt, compile_attempt):
    job.link(attempt, compile_attempt)
    folder = S / f'tests-link{attempt}'
    annotate(job, folder / 'link-plan.json')
    annotate(job, folder / 'ready.json', link_plan=identity(folder / 'link-plan.json'))


def run_one(job, attempt, link_attempt, case, timeout, listing):
    inputs = artifacts(HEADER)  # Reject absent/partial data before trying an image.
    try:
        job.run(link_attempt, attempt, case, timeout, listing)
    finally:
        folder = S / (f'listing{attempt}' if listing else f'checks{attempt}')
        summary = folder / 'summary.json'
        if summary.is_file():
            annotate(job, summary, source=RUN_SOURCE,
                actual_artifact_inputs=inputs, driver=None, cached_only=True, automatic_expert_fetch=False,
                placement='CUDA Context/device only' if case == 'cuda' else 'CPU Context/system owner only',
                scope=RUN_SCOPE)
        request = S / 'run-plans' / (folder.name + '.json')
        if request.is_file():
            annotate(job, request, environment_config=identity(SCRIPT), actual_artifact_inputs=inputs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['plan', 'compile', 'link', 'list', 'run'])
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--case', choices=list(CASES), default='cpu')
    parser.add_argument('--timeout', type=int, default=1800)
    args = parser.parse_args()
    assert min(args.attempt, args.compile_attempt, args.link_attempt, args.timeout) > 0
    job = configured()
    if args.action == 'plan':
        plan(job, args.attempt)
    elif args.action == 'compile':
        compile_one(job, args.attempt)
    elif args.action == 'link':
        link_one(job, args.attempt, args.compile_attempt)
    else:
        run_one(job, args.attempt, args.link_attempt, args.case, args.timeout, args.action == 'list')


if __name__ == '__main__':
    main()
