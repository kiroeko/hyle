"""Root-only Q03 selected49-role acquisition; no whole-shard download.

Uses the pinned QB downloader and the already reviewed B04 request-cap
adapter: new HTTP ranges<=8MiB, old authenticated chunks<=128MiB,1MiB IO,
3workers. Strict206/ETag/range/length/EOF/SHA and transport retries remain.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
QB = S.parents[1]
REPO, REV = 'AxionML/Qwen3.5-2B-NVFP4', '6f2ad4febe92be529de499b08f0020f5ff06bf25'
PLAN_SHA = 'c0932a8073d2421826100aa4d41c03a69216308ec1310800a28678012e6ded31'
SHARED = QB / 'fetch_roles.py'
SHARED_SHA = '1b34877ca22ab16eeaeb508e781dd84d0abf6555a73454b37f48e6d6a7e5cca3'
REQUEST_ADAPTER = R / '.scratch/qwen-gguf-selected-20261023/offline/request-chunk/next-source/fetch_roles.py'
REQUEST_ADAPTER_SHA = '2fc0a5a81251b0a621940baac8f5b08ea3217f4ecc9ef121130b4a45548a2b29'
COUNT, BODY = 49, 1168279608
CHUNK, IO, WORKERS = 128 * 1024 * 1024, 1024 * 1024, 3
# CHUNK remains the authenticated legacy-prefix/suffix bound.
REQUEST_CHUNK = 8 * 1024 * 1024


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()  # Only small plan/receipt/manifest/script metadata.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked_plan():
    path = S / 'roles-plan.json'
    assert identity(path)['sha256'] == PLAN_SHA
    plan = read(path)
    assert (plan['repository'], plan['revision'], plan['original_roles'], plan['source_bytes']) == (REPO, REV, COUNT, BODY)
    assert plan['metadata_only'] and plan['complete_absolute_ranges'] and plan['tensor_payload_bytes'] == 0
    assert len(plan['roles']) == len({row['name'] for row in plan['roles']}) == len({row['filename'] for row in plan['roles']}) == COUNT
    assert plan['vocabulary']['embedding'] == plan['vocabulary']['head'] and plan['vocabulary']['unique_banks'] == 1
    assert all(Path(row['filename']).name == row['filename'] for row in plan['roles'])
    for entry in plan['source_entries']:
        assert identity(R / entry['extracted']['path']) == entry['extracted']
    assert len(plan['shards']) == 1
    shard = plan['shards'][0]
    raw = (R / shard['header']['path']).read_bytes()
    assert identity(R / shard['header']['path']) == shard['header'] and len(raw) == 146464
    assert shard['data_base'] == len(raw) + 8 and shard['whole_file_bytes'] == 2575006840
    assert shard['url'] == f'https://huggingface.co/{REPO}/resolve/{REV}/model.safetensors'
    assert shard['etag'] == '"e9c1dda1bf1c6c43b4658be8fda6a2eb26b065aeeabab7c296b258b4616b7f11"'
    header = json.loads(raw)
    widths = {'BF16': 2, 'F32': 4, 'U8': 1, 'F8_E4M3': 1}
    total = 0
    for row in plan['roles']:
        actual = header[row['name']]
        assert row['source_shard'] == 0 and row['dtype'] == actual['dtype'] and row['shape'] == actual['shape']
        assert row['data_relative_half_open'] == actual['data_offsets']
        first, end = actual['data_offsets']
        assert row['bytes'] == end - first == math.prod(row['shape']) * widths[row['dtype']] > 0
        assert row['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
        assert row['absolute_inclusive'][1] < shard['whole_file_bytes']
        total += row['bytes']
    assert total == BODY and 'lm_head.weight' not in header
    return path, plan


def shared_downloader():
    assert identity(SHARED)['sha256'] == SHARED_SHA
    spec = importlib.util.spec_from_file_location('q03_pinned_qb_download', SHARED)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # Its guarded main is not invoked.
    assert (module.CHUNK, module.IO, module.WORKERS) == (CHUNK, IO, WORKERS)
    assert identity(REQUEST_ADAPTER)['sha256'] == REQUEST_ADAPTER_SHA
    capped_spec = importlib.util.spec_from_file_location('q03_existing_request_cap', REQUEST_ADAPTER)
    capped = importlib.util.module_from_spec(capped_spec)
    capped_spec.loader.exec_module(capped)  # Definitions only, never its main.
    assert (capped.CHUNK, capped.IO, capped.WORKERS) == (CHUNK, IO, WORKERS)
    capped.R, capped.HELPER, capped.HELPER_SHA = module.R, module.HELPER, module.HELPER_SHA
    # Exactly B04's adapter: one new-request AST Name substitution; the
    # pinned fixed helper and both128MiB legacy-resume checks are unchanged.
    module.downloader = lambda record, receipt: capped.downloader(
        record, receipt, request_chunk_bytes=REQUEST_CHUNK)
    return module


def manifests(out, record, plan):
    rows = {row['name']: row for row in record['roles']}
    groups = {'manifest.json': [row['name'] for row in record['roles']],
              'nextn-manifest.json': plan['nextn_order'],
              'target-manifest.json': [row['name'] for row in record['roles'] if row['section'] in ('target23', 'target_norm')]}
    for filename, names in groups.items():
        roles = [dict(name=name, file=rows[name]['filename'], sha256=rows[name]['payload']['sha256'],
            dtype=rows[name]['dtype'], shape=rows[name]['shape'], bytes=rows[name]['bytes'],
            section=rows[name]['section'], absolute_inclusive=rows[name]['absolute_inclusive']) for name in names]
        value = dict(repository=REPO, revision=REV, file='model.safetensors', variant='NVFP4',
            directory=out.relative_to(R).as_posix(), original_roles=len(roles),
            source_bytes=sum(row['bytes'] for row in roles), roles=roles, complete=True,
            source_plan=identity(S / 'roles-plan.json'), source_receipt=identity(out / 'acquisition.json'),
            vocabulary=plan['vocabulary'], artifact_executed=False,
            scope='Actual unchanged selected ranges. One tied BF16 embedding/head bank; target NVFP4 code/SF/global/input-scale roles stay distinct. No whole-file content SHA or native pass is asserted.')
        (out / filename).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    plan_path, plan = checked_plan()
    shared = shared_downloader()
    assert shared.sha(shared.HELPER.read_bytes()) == shared.HELPER_SHA
    out = S / 'original-roles'
    if args.plan_only:
        print(json.dumps(dict(repository=REPO, revision=REV, roles=COUNT, body_bytes=BODY,
            output_directory=out.relative_to(R).as_posix(), source_plan=identity(plan_path),
            reused_downloader=identity(SHARED), request_cap_adapter=identity(REQUEST_ADAPTER),
            request_chunk_bytes=REQUEST_CHUNK, authenticated_chunk_limit_bytes=CHUNK, stream_buffer_bytes=IO,
            workers=WORKERS, maximum_live_stream_bytes=WORKERS * IO, network_requests=0)))
        return
    out.mkdir(exist_ok=True)
    with shared.single_writer(out / '.fetch.lock'):
        receipt = out / 'acquisition.json'
        shard = plan['shards'][0]
        roles = [dict(row, url=shard['url'], etag=shard['etag'], whole_file_bytes=shard['whole_file_bytes'],
            complete=False, chunks=[], payload=dict(path=(out / row['filename']).relative_to(R).as_posix(),
                bytes=row['bytes'], sha256=None)) for row in plan['roles']]
        expected = dict(repository=REPO, revision=REV, file=plan['file'],
            source_plan=plan_path.relative_to(R).as_posix(), source_plan_sha256=PLAN_SHA,
            expected_role_payload_bytes=BODY, downloader=identity(shared.HELPER), wrapper=identity(SHARED))
        if receipt.exists():
            record = read(receipt)
            assert all(record[key] == value for key, value in expected.items())
            for actual, wanted in zip(record['roles'], roles, strict=True):
                assert all(actual[key] == value for key, value in wanted.items() if key not in ('complete', 'chunks', 'payload'))
                assert actual['payload']['path'] == wanted['payload']['path'] and actual['payload']['bytes'] == wanted['payload']['bytes']
        else:
            assert not any((R / row['payload']['path']).exists() for row in roles), 'No unrecorded file is an authenticated resume prefix'
            record = dict(expected, complete=False, original_roles=COUNT, whole_shard_downloaded=False,
                chunk_bytes=CHUNK, stream_buffer_bytes=IO, requests=[], roles=roles)
        functions = shared.downloader(record, receipt)
        with functions['LOCK']:
            record.update(complete=False, chunk_bytes=CHUNK, stream_buffer_bytes=IO, parallel_role_workers=WORKERS,
                request_chunk_bytes=REQUEST_CHUNK, authenticated_chunk_limit_bytes=CHUNK,
                request_cap_adapter=identity(REQUEST_ADAPTER))
            functions['save']()
        errors = []
        with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='q03-role') as executor:
            futures = [executor.submit(functions['acquire_role'], row) for row in record['roles']]
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as error:
                    errors.append(error)
        if errors:
            with functions['LOCK']:
                record['complete'] = False
                functions['save']()
            raise errors[0]
        with functions['LOCK']:
            assert all(row['complete'] and row['payload']['sha256'] for row in record['roles'])
            payload_bytes = sum(row['payload']['bytes'] for row in record['roles'])
            request_bytes = sum(row['bytes'] for row in record['requests'] if row['complete'])
            assert payload_bytes == request_bytes == BODY
            record.update(complete=True, role_payload_bytes=payload_bytes,
                successful_request_body_bytes=request_bytes, finished_utc=functions['now']())
            functions['save']()
        manifests(out, record, plan)
        print(json.dumps(dict(complete=True, roles=COUNT, role_payload_bytes=BODY,
            receipt=identity(receipt), manifest=identity(out / 'manifest.json'))))


if __name__ == '__main__':
    main()
