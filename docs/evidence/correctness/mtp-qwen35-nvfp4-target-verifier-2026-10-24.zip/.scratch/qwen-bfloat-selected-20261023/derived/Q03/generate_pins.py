"""Generate Q03 actual pins only after complete49-role authenticated acquisition.

Reads small metadata and stats original files; never rehashes/loads the1.168GB
body. No fake/default SHA, tensor conversion, build or execution path exists.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
spec = importlib.util.spec_from_file_location('q03_exact_range_metadata', S / 'fetch_roles.py')
fetch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fetch)


def pinned(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def checked_metadata():
    _, plan = fetch.checked_plan()
    out = S / 'original-roles'
    receipt_path, manifest_path = out / 'acquisition.json', out / 'manifest.json'
    receipt, manifest = fetch.read(receipt_path), fetch.read(manifest_path)
    for item in (receipt, manifest):
        assert item.get('complete') is True, 'Actual complete acquisition is required; no pins generated'
        assert (item['repository'], item['revision'], item['original_roles']) == (fetch.REPO, fetch.REV, fetch.COUNT)
        assert item['file'] == 'model.safetensors' and len(item['roles']) == fetch.COUNT
    assert receipt['source_plan_sha256'] == fetch.PLAN_SHA
    assert receipt['source_plan'] == (S / 'roles-plan.json').relative_to(R).as_posix()
    assert receipt['expected_role_payload_bytes'] == receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == fetch.BODY
    assert receipt['whole_shard_downloaded'] is False and manifest['source_bytes'] == fetch.BODY
    assert manifest['source_receipt'] == fetch.identity(receipt_path)
    assert manifest['source_plan'] == fetch.identity(S / 'roles-plan.json')
    rows = {row['name']: row for row in manifest['roles']}
    acquired = {row['name']: row for row in receipt['roles']}
    assert len(rows) == len(acquired) == fetch.COUNT
    assert set(rows) == set(acquired) == {row['name'] for row in plan['roles']}
    assert len({row['file'] for row in rows.values()}) == fetch.COUNT
    for expected in plan['roles']:
        name = expected['name']
        row, actual = rows[name], acquired[name]
        assert actual['complete'] and pinned(actual['payload']['sha256']), name
        for key in ('name', 'section', 'dtype', 'shape', 'bytes', 'absolute_inclusive'):
            assert row[key] == actual[key] == expected[key], (name, key)
        assert actual['filename'] == row['file'] == expected['filename']
        assert actual['data_relative_half_open'] == expected['data_relative_half_open']
        assert row['bytes'] == actual['payload']['bytes'] and row['sha256'] == actual['payload']['sha256']
        assert pinned(row['sha256']) and Path(row['file']).name == row['file']
        path = out / row['file']
        assert path.resolve() == (R / actual['payload']['path']).resolve() and path.stat().st_size == row['bytes']
        offset = 0
        for chunk in actual['chunks']:
            assert chunk['offset'] == offset and 0 < chunk['bytes'] <= fetch.CHUNK and pinned(chunk['sha256'])
            first = expected['absolute_inclusive'][0] + offset
            assert chunk['absolute_range_inclusive'] == [first, first + chunk['bytes'] - 1]
            offset += chunk['bytes']
        assert offset == row['bytes']
    nextn_path = out / 'nextn-manifest.json'
    nextn = fetch.read(nextn_path)
    assert nextn['complete'] and nextn['original_roles'] == len(plan['nextn_order']) == 16
    assert [row['name'] for row in nextn['roles']] == plan['nextn_order']
    assert nextn['vocabulary'] == plan['vocabulary'] and nextn['vocabulary']['embedding'] == nextn['vocabulary']['head']
    assert all(row == rows[row['name']] for row in nextn['roles'])
    return plan, manifest, rows


def quoted(value):
    return json.dumps(value, ensure_ascii=True)


def header(plan, rows, receipt_sha, manifest_sha):
    order = [row['name'] for row in plan['roles']]
    ordinals = {name: index for index, name in enumerate(order)}
    lines = [
        '#pragma once', '', '#include <array>', '#include <cstddef>', '#include <cstdint>',
        '#include <string_view>', '#include <span>', '#include <vector>',
        '#include "qwen_bfloat_original_roles.h"', '#include "qwen_nvfp4_target_fragment.h"', '',
        '// Actual original source metadata/pins. No loader/executor or generated weights.',
        '// specs() binds49 original physical roles; nextn_specs() remains16 unique.',
        '// Original NVFP4 quartets stay packed and execute through Nvfp4Linear.',
        '// A generated pin header/case registration is not a numerical pass.',
        'namespace qwen_bfloat_original_artifacts::q03 {',
        'namespace roles=qwen_bfloat_original_roles;',
        'inline constexpr qwen_original_mtp_roles::Identity kIdentity{',
        f'    {quoted(fetch.REPO)},{quoted(fetch.REV)},"NVFP4","model.safetensors"}};',
        'inline constexpr qwen_full_attention_fragment::Geometry kGeometry{',
        '    2048,8,2,256,64,1.e-6F,0.F,hyle::compute::DataType::kBFloat16};',
        'inline constexpr std::int64_t kIntermediate=6144,kVocabulary=248320;',
        'inline constexpr float kRopeTheta=10\'000\'000.F;',
        'inline constexpr std::uint64_t kOriginalBytes=1168279608ULL;',
        f'inline constexpr std::string_view kPlanSha256={quoted(fetch.PLAN_SHA)};',
        f'inline constexpr std::string_view kReceiptSha256={quoted(receipt_sha)};',
        f'inline constexpr std::string_view kManifestSha256={quoted(manifest_sha)};',
        'inline constexpr std::string_view kTargetLayer="model.language_model.layers.23";',
        'inline constexpr std::string_view kTargetNorm="model.language_model.norm.weight";',
        'inline constexpr roles::VocabularyNames kVocabularyNames{',
        '    ' + quoted(plan['vocabulary']['embedding']) + ',' + quoted(plan['vocabulary']['head']) + '};',
        '// The pinned publisher does not identify an official Qwen base',
        '// revision. Both model/artifact identities below therefore name the',
        '// exact publisher artifact, never an assumed upstream commit.',
        'inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{',
        '    .model_publisher="AxionML",',
        '    .model_repository="AxionML/Qwen3.5-2B-NVFP4",',
        '    .model_family="qwen3.5",',
        '    .model_name="Qwen3.5-2B-NVFP4",',
        '    .model_revision="6f2ad4febe92be529de499b08f0020f5ff06bf25",',
        '    .configuration_digest="34141891d73c478d2ba087c470a62b3fbd70ce07fff4e14265d762bb44d4aa40",',
        '    .artifact_repository=kIdentity.repository,.artifact_revision=kIdentity.revision,',
        '    .variant=kIdentity.variant,',
        '    // Whole pinned safetensors header identity, not whole body SHA.',
        '    .manifest_digest="446f550bc6ff9f578b60779bbf3ac49718cf03f86ab0b4486db8273fd30b0c8a",',
        '    .format_family="safetensors"};',
        'static_assert(kProfile.complete());',
        '// Fixed Qwen3_5 RMSNorm and NextN source stores F32(1+BF16delta).',
        'inline constexpr roles::DenseNormConventions kNormConventions{',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,',
        '    roles::NormConvention::kDeltaPlusOne};',
        'inline constexpr std::array<roles::PinnedFile,16> kNextnFiles{{',
    ]
    for name in plan['nextn_order']:
        row = rows[name]
        lines.append(f'    {{{quoted(row["file"])},{quoted(row["sha256"])}}},')
    lines += ['}};', 'inline auto nextn_specs() {',
        '  return roles::dense_specs(kGeometry,kIntermediate,kVocabulary,kNextnFiles,kVocabularyNames);', '}',
        '// rank0 retains the original F32 scalar shape []; unused shape slots are0.',
        'struct RawRolePin final {',
        '  std::string_view name,file,sha256,dtype;',
        '  std::array<std::int64_t,2> shape;std::size_t rank;std::uint64_t bytes;', '};',
        'inline constexpr std::array<RawRolePin,49> kRawPins{{']
    for name in order:
        row = rows[name]
        shape = row['shape'] + [0] * (2 - len(row['shape']))
        assert len(shape) == 2
        lines.append(f'    {{{quoted(name)},{quoted(row["file"])},{quoted(row["sha256"])},{quoted(row["dtype"])},'
            f'{{{shape[0]},{shape[1]}}},{len(row["shape"])},{row["bytes"]}ULL}},')
    lines += ['}};', 'struct Nvfp4ProjectionPins final {',
        '  std::string_view prefix;std::int64_t outputs,reduction;',
        '  std::size_t codes,scales,weight_scale_2,input_scale;', '};',
        'inline constexpr std::array<Nvfp4ProjectionPins,7> kTargetProjections{{']
    for matrix in plan['target_projections']:
        names = matrix['roles']
        indexes = [ordinals[names[role]] for role in ('weight', 'weight_scale', 'weight_scale_2', 'input_scale')]
        lines.append(f'    {{{quoted(matrix["prefix"])},{matrix["outputs"]},{matrix["reduction"]},' + ','.join(map(str, indexes)) + '},')
    lines += ['}};', 'inline constexpr std::array<std::string_view,5> kTargetNormNames{']
    lines += ['    ' + quoted(name) + ',' for name in plan['target_norms']]
    lines += ['};',
        'inline const RawRolePin &raw_pin(std::string_view name) {',
        '  const auto found=std::find_if(kRawPins.begin(),kRawPins.end(),[&](const auto &row){return row.name==name;});',
        '  if(found==kRawPins.end())throw std::runtime_error("Q03 original role is absent from the authenticated header");',
        '  return *found;',
        '}',
        'inline void check_spec(const roles::Spec &spec) {',
        '  const auto &raw=raw_pin(spec.name);const auto &description=spec.description;',
        '  const auto dtype=description.data_type()==hyle::compute::DataType::kBFloat16?"BF16":',
        '      description.data_type()==hyle::compute::DataType::kUInt8?"U8":',
        '      description.data_type()==hyle::compute::DataType::kFloat8E4M3FN?"F8_E4M3":',
        '      description.data_type()==hyle::compute::DataType::kFloat32?"F32":"unsupported";',
        '  if(spec.file!=raw.file||spec.sha256!=raw.sha256||raw.dtype!=dtype||description.rank()!=raw.rank||',
        '      !std::equal(description.dimensions().begin(),description.dimensions().end(),raw.shape.begin())||',
        '      qwen_original_mtp_roles::detail::take(description.required_bytes(),"Q03 exact typed extent")!=raw.bytes)',
        '    throw std::runtime_error("Q03 schema differs from its actual original name/dtype/shape/bytes/SHA");',
        '}',
        'inline std::vector<roles::Spec> specs() {',
        '  auto result=nextn_specs();result.reserve(kRawPins.size());',
        '  for(const auto &projection:kTargetProjections) {',
        '    const std::array indexes{projection.codes,projection.scales,projection.weight_scale_2,projection.input_scale};',
        '    std::array<std::string_view,4> names;std::array<roles::PinnedFile,4> files;',
        '    for(std::size_t slot=0;slot<indexes.size();++slot) {',
        '      const auto &pin=kRawPins.at(indexes[slot]);names[slot]=pin.name;files[slot]={pin.file,pin.sha256};',
        '    }',
        '    const auto quartet=roles::nvfp4_projection_specs(projection.outputs,projection.reduction,names,files);',
        '    result.insert(result.end(),quartet.begin(),quartet.end());',
        '  }',
        '  for(const auto name:kTargetNormNames) {',
        '    const auto &pin=raw_pin(name);',
        '    const auto width=name.ends_with("q_norm.weight")||name.ends_with("k_norm.weight")?kGeometry.depth:kGeometry.hidden;',
        '    result.push_back({pin.name,pin.file,pin.sha256,roles::sem::dense({width},hyle::compute::DataType::kBFloat16)});',
        '  }',
        '  std::uint64_t bytes=0;',
        '  if(result.size()!=kRawPins.size())throw std::runtime_error("Q03 must bind exactly49 unique physical roles");',
        '  for(std::size_t slot=0;slot<result.size();++slot) {',
        '    check_spec(result[slot]);',
        '    for(std::size_t previous=0;previous<slot;++previous)if(result[slot].name==result[previous].name)',
        '      throw std::runtime_error("Q03 cannot alias a second physical vocabulary name");',
        '    bytes+=raw_pin(result[slot].name).bytes;',
        '  }',
        '  if(bytes!=kOriginalBytes)throw std::runtime_error("Q03 original role payload total differs");',
        '  return result;',
        '}',
        'inline std::array<qwen_nvfp4_target_fragment::ProjectionNames,7> target_projection_names() {',
        '  std::array<qwen_nvfp4_target_fragment::ProjectionNames,7> result;',
        '  for(std::size_t slot=0;slot<result.size();++slot) {',
        '    const auto &projection=kTargetProjections[slot];',
        '    result[slot]={kRawPins.at(projection.codes).name,kRawPins.at(projection.scales).name,',
        '        kRawPins.at(projection.weight_scale_2).name,kRawPins.at(projection.input_scale).name};',
        '  }',
        '  return result;',
        '}',
        '} // namespace qwen_bfloat_original_artifacts::q03', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=S / 'generated/qwen_q03_original_pins.h')
    args = parser.parse_args()
    plan, manifest, rows = checked_metadata()  # Fails before producing any header on partial data.
    receipt = fetch.identity(S / 'original-roles/acquisition.json')
    manifest_identity = fetch.identity(S / 'original-roles/manifest.json')
    text = header(plan, rows, receipt['sha256'], manifest_identity['sha256'])
    output = args.output.resolve()
    assert output.is_relative_to(R) and output.suffix == '.h'
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        assert output.read_text(encoding='utf-8-sig') == text, 'Refuse to replace a different original pin header'
    else:
        output.write_text(text, encoding='utf-8')
    pins = dict(repository=fetch.REPO, revision=fetch.REV, original_roles=fetch.COUNT,
        source_bytes=fetch.BODY, source_plan=fetch.identity(S / 'roles-plan.json'),
        source_receipt=receipt, manifest=manifest_identity, header=fetch.identity(output),
        vocabulary=plan['vocabulary'], nextn_order=plan['nextn_order'], roles=manifest['roles'],
        target_projections=plan['target_projections'], body_rehashed=False, artifact_executed=False,
        required_source_adapter='Apply the reviewed combined source plus Q03 entry increment. specs() binds49 unique physical roles; target_projection_names() selects the existing Nvfp4Linear leaf in the same K1 runner. A generated header is not an execution pass.')
    destination = output.with_suffix('.json')
    destination.write_text(json.dumps(pins, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(header=fetch.identity(output), pins=fetch.identity(destination),
        source_roles=49, unique_nextn_roles=16, generated_from_actual_complete_receipt=True)))


if __name__ == '__main__':
    main()
