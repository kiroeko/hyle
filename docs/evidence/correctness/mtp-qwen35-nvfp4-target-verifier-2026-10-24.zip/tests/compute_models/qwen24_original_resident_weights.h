#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <span>

#include "qwen24_original_nextn_roles.h"
#include "hyle/compute/resource_leases.h"
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
#include "hyle/compute/cuda_weights.h"
#endif

// Finite supply for the actual Q24 Top10 union. All original512 IDs remain
// logical; only their explicit mapped original planes enter E10. GGUF and
// plain BF16 keep their actual bytes; no expert F32 shadow is prepared.
namespace qwen24_original_resident_weights {
namespace original = qwen24_original_nextn_roles;
namespace c = hyle::compute;
namespace m = hyle::mem;
using hyle::Result;
using hyle::Status;
inline constexpr std::size_t kCapacity = original::kResidentCapacity;
inline constexpr std::array<std::uint64_t, 4> kBankIds{10, 20, 30, 40};
inline constexpr std::array<original::Leg, 3> kLegs{
    original::Leg::kGate, original::Leg::kUp, original::Leg::kDown};

// Cold physical facts from the actual three original banks. Logical MoE
// geometry does not imply a codec or a common byte stride across its legs.
// Once created, callers can only inspect this bounded immutable layout.
class PackedExpertLayout final {
 public:
  static Result<PackedExpertLayout> create(const std::array<c::TensorDesc, 3> &sources) {
    PackedExpertLayout result;
    for (std::size_t leg = 0; leg < sources.size(); ++leg) {
      const auto &source = sources[leg];
      const auto codec = c::gguf_quantized_type(source.storage_format());
      const auto n = leg == 2 ? original::kHidden : original::kIntermediate;
      const auto k = leg == 2 ? original::kIntermediate : original::kHidden;
      if (source.rank() != 3 || source.dimensions()[0] != original::kExpertDomain ||
          source.dimensions()[1] != n || source.dimensions()[2] != k ||
          source.byte_strides().size() != 3 || source.byte_strides()[0] <= 0)
        return std::unexpected(Status::InvalidArgument("Q24 expert source needs its actual full-domain grouped geometry"));
      if (std::uint64_t(source.byte_strides()[0]) > std::uint64_t(std::numeric_limits<std::size_t>::max()))
        return std::unexpected(Status::OutOfRange("Q24 original expert stride exceeds size_t"));
      c::TensorDesc resident;
      std::size_t plane_bytes = 0;
      if (codec && source.data_type() == c::DataType::kFloat32) {
        HYLE_ASSIGN_OR_RETURN(auto canonical, c::gguf_grouped_weight_description(*codec,
            c::DataType::kFloat32, original::kExpertDomain, n, k));
        if (source != canonical)
          return std::unexpected(Status::InvalidArgument("Q24 expert layout differs from its native GGUF codec"));
        HYLE_ASSIGN_OR_RETURN(resident, c::gguf_grouped_weight_description(*codec,
            c::DataType::kFloat32, std::int64_t(kCapacity), n, k));
        plane_bytes = std::size_t(source.byte_strides()[0]);
      } else if (source.is_plain() && source.data_type() == c::DataType::kBFloat16) {
        // A gate/up plane is a view of [E,2I,H]: expert stride includes the
        // other half. Copy only this plane, compactly, into the E10 bank.
        HYLE_ASSIGN_OR_RETURN(auto plane, c::TensorDesc::dense(c::DataType::kBFloat16, std::array{n, k}));
        HYLE_ASSIGN_OR_RETURN(plane_bytes, plane.required_bytes());
        if (source.byte_strides()[2] != 2 || source.byte_strides()[1] != k * 2 ||
            std::uint64_t(source.byte_strides()[0]) < plane_bytes)
          return std::unexpected(Status::InvalidArgument("Q24 BF16 selected expert rows must be contiguous within each plane"));
        HYLE_ASSIGN_OR_RETURN(resident, c::TensorDesc::dense(c::DataType::kBFloat16,
            std::array{std::int64_t(kCapacity), n, k}));
      } else return std::unexpected(Status::InvalidArgument("unsupported Q24 selected expert storage"));
      HYLE_ASSIGN_OR_RETURN(auto bank_bytes, resident.required_bytes());
      const auto stride = std::uint64_t(source.byte_strides()[0]);
      if (stride > std::uint64_t(std::numeric_limits<std::size_t>::max()) ||
          stride > std::uint64_t(std::numeric_limits<std::int64_t>::max()) ||
          plane_bytes > std::numeric_limits<std::size_t>::max() / kCapacity ||
          bank_bytes != plane_bytes * kCapacity)
        return std::unexpected(Status::OutOfRange("Q24 expert stride or resident extent overflows"));
      result.sources_[leg] = source;
      result.residents_[leg] = resident;
      // Native sliced assembly preserves a plain bank's scalar type. Only
      // encoded banks use raw U8 fragments; the bytes are never converted.
      const auto upload_type = resident.is_plain() ? resident.data_type() : c::DataType::kUInt8;
      const auto upload_width = c::data_type_size(upload_type);
      if (upload_width == 0 || plane_bytes % upload_width != 0)
        return std::unexpected(Status::InvalidArgument("Q24 upload plane has a partial scalar"));
      HYLE_ASSIGN_OR_RETURN(result.uploads_[leg], c::TensorDesc::dense(upload_type,
          std::array<std::int64_t, 1>{std::int64_t(plane_bytes / upload_width)}));
      result.expert_bytes_[leg] = plane_bytes;
      result.bank_bytes_[leg] = bank_bytes;
      HYLE_ASSIGN_OR_RETURN(auto aligned, align(bank_bytes));
      HYLE_RETURN_IF_ERROR(add(result.slot_bytes_, aligned));
      HYLE_RETURN_IF_ERROR(add(result.logical_bytes_, bank_bytes));
    }
    HYLE_ASSIGN_OR_RETURN(result.map_, c::TensorDesc::dense(c::DataType::kInt32,
        std::array<std::int64_t, 1>{original::kExpertDomain}));
    HYLE_ASSIGN_OR_RETURN(result.map_bytes_, result.map_.required_bytes());
    HYLE_ASSIGN_OR_RETURN(auto aligned_map, align(result.map_bytes_));
    HYLE_RETURN_IF_ERROR(add(result.slot_bytes_, aligned_map));
    HYLE_RETURN_IF_ERROR(add(result.logical_bytes_, result.map_bytes_));
    if (result.slot_bytes_ > std::numeric_limits<std::size_t>::max() / 2)
      return std::unexpected(Status::OutOfRange("Q24 two-generation resident capacity overflows"));
    return result;
  }
  const c::TensorDesc &source(std::size_t leg) const { return sources_.at(leg); }
  const c::TensorDesc &resident(std::size_t leg) const { return residents_.at(leg); }
  const c::TensorDesc &upload_description(std::size_t leg) const { return uploads_.at(leg); }
  std::size_t expert_bytes(std::size_t leg) const { return expert_bytes_.at(leg); }
  std::size_t bank_bytes(std::size_t leg) const { return bank_bytes_.at(leg); }
  const c::TensorDesc &map_description() const noexcept { return map_; }
  std::size_t map_bytes() const noexcept { return map_bytes_; }
  std::size_t logical_bytes() const noexcept { return logical_bytes_; }
  std::size_t slot_bytes() const noexcept { return slot_bytes_; }
  constexpr std::size_t fragment_count() const noexcept { return 3 * kCapacity + 1; }
  constexpr std::size_t capacity() const noexcept { return kCapacity; }
  constexpr std::int64_t domain() const noexcept { return original::kExpertDomain; }
  template<class Source> Status validate_source(const Source &source_data) const {
    for (std::size_t leg = 0; leg < kLegs.size(); ++leg)
      if (source_data.expert_description(kLegs[leg]) != sources_[leg])
        return Status::InvalidArgument("Q24 supplied source differs from the cold resident layout");
    return Status::Ok();
  }
 private:
  static Result<std::size_t> align(std::size_t bytes) {
    if (bytes > std::numeric_limits<std::size_t>::max() - 255)
      return std::unexpected(Status::OutOfRange("Q24 resident alignment overflows"));
    return (bytes + 255) & ~std::size_t{255};
  }
  static Status add(std::size_t &total, std::size_t bytes) {
    if (total > std::numeric_limits<std::size_t>::max() - bytes)
      return Status::OutOfRange("Q24 resident byte capacity overflows");
    total += bytes; return Status::Ok();
  }
  std::array<c::TensorDesc, 3> sources_, residents_, uploads_;
  std::array<std::size_t, 3> expert_bytes_{}, bank_bytes_{};
  c::TensorDesc map_;
  std::size_t map_bytes_ = 0, logical_bytes_ = 0, slot_bytes_ = 0;
};
inline Status validate(const original::Selection &selected) {
  if (selected.globals.empty() || selected.globals.size() > kCapacity)
    return Status::InvalidArgument("Q24 resident union must contain1..10 original IDs");
  std::array<std::int32_t, original::kExpertDomain> expected;
  expected.fill(-1);
  std::int32_t previous = -1;
  for (std::size_t local = 0; local < selected.globals.size(); ++local) {
    const auto global = selected.globals[local];
    if (global < 0 || global >= original::kExpertDomain || global <= previous)
      return Status::InvalidArgument("Q24 resident IDs must be sorted, unique and within0..511");
    expected[std::size_t(global)] = std::int32_t(local);
    previous = global;
  }
  if (selected.map != expected) return Status::InvalidArgument("Q24 resident map differs from the exact original union");
  return Status::Ok();
}
inline std::int32_t original_at(const original::Selection &selected, std::size_t local) {
  // Full initialization includes unused capacity. Repeated valid source rows
  // in that tail get no map entry and cannot change a real global expert ID.
  return local < selected.globals.size() ? selected.globals[local] : selected.globals.front();
}
struct CpuBatch final {
  c::StorageOwner owner;
  std::array<c::ReadLease, 4> banks;
};
class CpuSupply final {
 public:
  static Result<CpuSupply> create(const c::StorageOwner &owner,
      const std::array<c::TensorDesc, 3> &sources) {
    if (!owner) return std::unexpected(Status::InvalidArgument("Q24 CPU supply needs its actual storage owner"));
    CpuSupply result; result.owner_ = owner;
    HYLE_ASSIGN_OR_RETURN(result.layout_, PackedExpertLayout::create(sources));
    HYLE_ASSIGN_OR_RETURN(result.pool_, c::LeasePool::create(owner.ref(), 2 * result.layout_.slot_bytes(),
        {.max_blocks = 8, .backing_alignment = 256}));
    return result;
  }
  template<class Source>
  Result<CpuBatch> upload(const original::Selection &selected, const Source &source) {
    HYLE_RETURN_IF_ERROR(validate(selected));
    HYLE_RETURN_IF_ERROR(layout_.validate_source(source));
    CpuBatch result{.owner = owner_};
    std::array<c::WriteLease, 4> writers;
    for (std::size_t leg = 0; leg < kLegs.size(); ++leg) {
      HYLE_ASSIGN_OR_RETURN(writers[leg], pool_.allocate(layout_.bank_bytes(leg)));
      HYLE_ASSIGN_OR_RETURN(auto destination, writers[leg].view());
      for (std::size_t local = 0; local < kCapacity; ++local) {
        HYLE_ASSIGN_OR_RETURN(auto slice, destination.subview(local * layout_.expert_bytes(leg), layout_.expert_bytes(leg)));
        const auto raw = source.expert_bytes(kLegs[leg], original_at(selected, local));
        if (raw.size() != layout_.expert_bytes(leg))
          return std::unexpected(Status::InvalidArgument("Q24 selected expert extent differs from its original description"));
        HYLE_RETURN_IF_ERROR(slice.write(raw));
      }
    }
    HYLE_ASSIGN_OR_RETURN(writers[3], pool_.allocate(layout_.map_bytes()));
    HYLE_ASSIGN_OR_RETURN(auto map, writers[3].view());
    HYLE_RETURN_IF_ERROR(map.write(std::as_bytes(std::span(selected.map))));
    for (std::size_t bank = 0; bank < writers.size(); ++bank) {
      HYLE_ASSIGN_OR_RETURN(result.banks[bank], writers[bank].publish());
    }
    return result;
  }
  c::LeasePoolStats stats() const noexcept { return pool_.stats(); }
  const PackedExpertLayout &layout() const noexcept { return layout_; }
 private:
  c::StorageOwner owner_;
  PackedExpertLayout layout_;
  c::LeasePool pool_;
};

#if defined(HYLE_TEST_QWEN_STATE_CUDA)
class CudaSupply final {
 public:
  static Result<CudaSupply> create(const c::Context &context, const c::StorageOwner &owner,
      const c::cuda::MemoryResource &device, const std::array<c::TensorDesc, 3> &sources) {
    if (!owner || owner.ref() != device.ref() || device.kind() != c::cuda::MemoryKind::kDevice)
      return std::unexpected(Status::InvalidArgument("Q24 CUDA supply needs the compiled device resource and real owner"));
    CudaSupply result; result.state_ = std::make_unique<State>();
    result.state_->device_owner = owner;
    HYLE_ASSIGN_OR_RETURN(result.state_->layout, PackedExpertLayout::create(sources));
    HYLE_ASSIGN_OR_RETURN(result.state_->host, c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
    std::array<c::cuda::WeightSpec, 4> catalog;
    for (std::size_t leg = 0; leg < kLegs.size(); ++leg)
      catalog[leg] = {kBankIds[leg], result.state_->layout.resident(leg)};
    const auto &map = result.state_->layout.map_description();
    catalog[3] = {kBankIds[3], map};
    HYLE_ASSIGN_OR_RETURN(result.state_->slots, c::cuda::WeightSlots::create(context,
        result.state_->host, device, catalog, result.state_->layout.slot_bytes(), {.max_fragments = result.state_->layout.fragment_count()}));
    HYLE_ASSIGN_OR_RETURN(result.state_->map, m::Buffer::create(m::system_resource(), result.state_->layout.map_bytes(), 256));
    return result;
  }
  template<class Source>
  Result<c::cuda::WeightBatch> upload(std::size_t slot, const original::Selection &selected,
      const Source &source, c::Queue &queue) {
    HYLE_RETURN_IF_ERROR(validate(selected));
    if (!state_) return std::unexpected(Status::FailedPrecondition("empty Q24 CUDA supply"));
    HYLE_RETURN_IF_ERROR(state_->layout.validate_source(source));
    HYLE_RETURN_IF_ERROR(state_->map.view().write(std::as_bytes(std::span(selected.map))));
    std::array<c::WeightSlice, 3 * kCapacity + 1> slices;
    std::size_t count = 0;
    for (std::size_t leg = 0; leg < kLegs.size(); ++leg) {
      const auto &upload = state_->layout.upload_description(leg);
      for (std::size_t local = 0; local < kCapacity; ++local) {
        const auto view = source.expert_view(kLegs[leg], original_at(selected, local));
        if (view.size() != state_->layout.expert_bytes(leg))
          return std::unexpected(Status::InvalidArgument("Q24 selected expert view extent differs from its original description"));
        HYLE_ASSIGN_OR_RETURN(auto tensor, c::ConstTensorView::create(upload, view));
        slices[count++] = {kBankIds[leg], tensor, local * state_->layout.expert_bytes(leg)};
      }
    }
    HYLE_ASSIGN_OR_RETURN(auto tensor, c::ConstTensorView::create(state_->layout.map_description(), state_->map.view()));
    slices[count++] = {kBankIds[3], tensor, 0};
    // Synchronous staging finishes borrowing the mapped originals/map before
    // returning. The immutable batch retains the real pending upload; caller
    // keeps this Supply through all readers and ordinary Invocation resets.
    return state_->slots.upload_slices(slot, std::span(slices).first(count), queue);
  }
  Result<c::WeightUploadReport> report(std::size_t slot) const {
    if (!state_) return std::unexpected(Status::FailedPrecondition("empty Q24 CUDA supply"));
    return state_->slots.report(slot);
  }
  Status close() { return state_ ? state_->slots.close() : Status::Ok(); }
  const PackedExpertLayout &layout() const { return state_->layout; }
 private:
  struct State final {
    // Stable heap address protects borrowed resource identity across moves.
    // close drains uploads before pinned storage or the deviceowner goes away.
    c::StorageOwner device_owner;
    PackedExpertLayout layout;
    c::cuda::MemoryResource host;
    c::cuda::WeightSlots slots;
    m::Buffer map;
    ~State() { slots.close().IgnoreError(); }
  };
  std::unique_ptr<State> state_;
};
#endif
} // namespace qwen24_original_resident_weights
