from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'e8m0-block128-import-reference/cpu';C=S/'checks/attempt1';C.mkdir(parents=True,exist_ok=True);B=A/'paged-e4-kv-reference/cpu/checks/attempt2/link-plan.json'
def read(p):return json.loads(Path(p).read_bytes())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def ident(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def recipe(obj):
 for p in Path(obj).parent.glob('*identity.json'):
  d=read(p)
  if Path(d.get('object',{}).get('path',''))==Path(obj):return p
 raise ValueError(obj)
base=read(B);env=os.environ.copy();p=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in p.stdout.splitlines():
 if '=' in line and not line.startswith('='):k,v=line.split('=',1);env[k.upper()]=v
(S/'tmp').mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(S/'tmp')
runtime=next(x['path'] for x in base['inputs'] if Path(x['path']).stem.endswith('resource_leases'));product_recipe=recipe(runtime);test_recipe=A/'paged-e4-kv-reference/cpu/checks/test4/identity.json'
def one(args):
 tag,source,r=args;cmd=[];skip=False
 for arg in read(r)['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  cmd.append(arg)
 cmd+=['/sourceDependencies',str(C/(tag+'-deps.json')),str(source),'/Fo'+str(C/(tag+'.obj')),'/Fd'+str(C/(tag+'.pdb'))];start=time.time();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace');save(C/(tag+'-command.json'),dict(command=cmd,cwd=str(R),exit_code=p.returncode,seconds=time.time()-start));(C/(tag+'-stdout.txt')).write_text(p.stdout);(C/(tag+'-stderr.txt')).write_text(p.stderr);print(tag,p.returncode,flush=True)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr)[-5000:])
 d=read(C/(tag+'-deps.json'))['Data'];save(C/(tag+'-identity.json'),dict(command=cmd,recipe=ident(r),source=ident(source),object=ident(C/(tag+'.obj')),dependencies=[ident(x) for x in dict.fromkeys([d['Source'],*d['Includes']])]))
C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True)
one(('weight-import',R/'src/compute/weight_import.cc',product_recipe))
save(C/'objects-ready.json',dict(CXX_success=2,CXX_failed_prior=1,links=0,runs=0,SDK_builds=0,baseline=ident(B),product=ident(C/'weight-import.obj'),test=ident(S/'checks/attempt1/weight-import-test.obj'),filter='Float8WeightImport.*'))
