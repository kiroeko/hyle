#include "hyle/compute/weight_import.h"

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <utility>

#include "hyle/compute/low_precision.h"

namespace hyle::compute {
namespace {

bool host_identity(mem::ConstBufferView view) noexcept {
  const auto flags = view.resource().properties();
  return flags.has(mem::MemoryProperty::kHostAccessible) &&
         flags.has(mem::MemoryProperty::kHostAddressIdentity);
}

bool overlapping(std::size_t x, std::size_t nx, std::size_t y,
                 std::size_t ny) noexcept {
  return x <= y ? y - x < nx : x - y < ny;
}

bool metadata_overlap(mem::ConstBufferView a,
                      mem::ConstBufferView b) noexcept {
  return a.resource() == b.resource() &&
         a.native_handle() == b.native_handle() &&
         overlapping(a.offset(), a.size(), b.offset(), b.size());
}

bool address_bounded(const mem::HostMapping &mapping) noexcept {
  const auto bytes = mapping.bytes();
  const auto address = reinterpret_cast<std::uintptr_t>(bytes.data());
  return bytes.data() && bytes.size() <= UINTPTR_MAX - address;
}

bool address_overlap(const mem::HostMapping &a,
                     const mem::HostMapping &b) noexcept {
  return overlapping(reinterpret_cast<std::uintptr_t>(a.bytes().data()),
                     a.bytes().size(),
                     reinterpret_cast<std::uintptr_t>(b.bytes().data()),
                     b.bytes().size());
}

Status source_domain(ConstTensorView view, DataType type) noexcept {
  if (!view.valid() || !view.storage().valid() ||
      !view.description().is_plain() || view.description().rank() != 2 ||
      view.description().data_type() != type)
    return Status::InvalidArgument("FP8 import needs plain E4 weight and U8 scale matrices");
  for (const auto stride : view.description().byte_strides())
    if (!std::in_range<std::size_t>(stride))
      return Status::OutOfRange("FP8 import source stride is outside host size domain");
  return Status::Ok();
}

} // namespace

Status import_float8_block128_weight(ConstTensorView weight,
                                    ConstTensorView scales,
                                    TensorView output) noexcept {
  HYLE_RETURN_IF_ERROR(source_domain(weight, DataType::kFloat8E4M3FN));
  HYLE_RETURN_IF_ERROR(source_domain(scales, DataType::kUInt8));
  if (!output.valid() || !output.storage().valid())
    return Status::InvalidArgument("FP8 import output is invalid");
  const auto n = weight.description().dimensions()[0];
  const auto k = weight.description().dimensions()[1];
  HYLE_ASSIGN_OR_RETURN(auto canonical,
      float8_weight_description(k, n, Float8ScaleMode::kFloat32Block128));
  if (output.description() != canonical ||
      scales.description().dimensions()[0] != n / 128 + (n % 128 != 0) ||
      scales.description().dimensions()[1] != k / 128)
    return Status::InvalidArgument("FP8 import scale grid or canonical output differs");
  HYLE_ASSIGN_OR_RETURN(const auto weight_bytes, weight.description().required_bytes());
  HYLE_ASSIGN_OR_RETURN(const auto scale_bytes, scales.description().required_bytes());
  HYLE_ASSIGN_OR_RETURN(const auto output_bytes, canonical.required_bytes());
  HYLE_ASSIGN_OR_RETURN(auto weight_range, weight.storage().subview(0, weight_bytes));
  HYLE_ASSIGN_OR_RETURN(auto scale_range, scales.storage().subview(0, scale_bytes));
  HYLE_ASSIGN_OR_RETURN(auto output_range, output.storage().subview(0, output_bytes));
  if (!host_identity(weight_range) || !host_identity(scale_range) ||
      !host_identity(output_range))
    return Status::Unimplemented("FP8 import requires canonical host mappings without device transfer");
  if (metadata_overlap(weight_range, output_range) ||
      metadata_overlap(scale_range, output_range))
    return Status::InvalidArgument("FP8 import output overlaps source storage");

  mem::HostMapping weight_map, scale_map, output_map;
  bool wrote = false;
  const auto finish = [&](Status status) {
    if (wrote && !output_range.resource().properties().has(
                     mem::MemoryProperty::kHostDeviceCoherent))
      preserve_first_error(status, output_map.flush());
    preserve_first_error(status, output_map.close());
    preserve_first_error(status, scale_map.close());
    preserve_first_error(status, weight_map.close());
    return status;
  };
  auto mapped_weight = weight_range.map_host();
  if (!mapped_weight) return finish(std::move(mapped_weight).error());
  weight_map = std::move(*mapped_weight);
  auto mapped_scale = scale_range.map_host();
  if (!mapped_scale) return finish(std::move(mapped_scale).error());
  scale_map = std::move(*mapped_scale);
  auto mapped_output = output_range.map_host(mem::HostAccess::kWrite);
  if (!mapped_output) return finish(std::move(mapped_output).error());
  output_map = std::move(*mapped_output);
  if (!address_bounded(weight_map) || !address_bounded(scale_map) ||
      !address_bounded(output_map))
    return finish(Status::OutOfRange("FP8 import host address range overflows"));
  if (address_overlap(weight_map, output_map) || address_overlap(scale_map, output_map))
    return finish(Status::InvalidArgument("FP8 import mapped output overlaps source storage"));
  if (!weight_range.resource().properties().has(mem::MemoryProperty::kHostDeviceCoherent)) {
    const auto status = weight_map.invalidate();
    if (!status.ok()) return finish(status);
  }
  if (!scale_range.resource().properties().has(mem::MemoryProperty::kHostDeviceCoherent)) {
    const auto status = scale_map.invalidate();
    if (!status.ok()) return finish(status);
  }
  auto writable = output_map.writable_bytes();
  if (!writable) return finish(std::move(writable).error());
  const auto source = weight_map.bytes();
  const auto scale_source = scale_map.bytes();
  auto target = *writable;
  const auto rows = static_cast<std::size_t>(n);
  const auto columns = static_cast<std::size_t>(k);
  const auto wr = static_cast<std::size_t>(weight.description().byte_strides()[0]);
  const auto wc = static_cast<std::size_t>(weight.description().byte_strides()[1]);
  wrote = true;
  for (std::size_t row = 0; row < rows; ++row) {
    if (wc == 1)
      std::memcpy(target.data() + row * columns, source.data() + row * wr, columns);
    else
      for (std::size_t column = 0; column < columns; ++column)
        target[row * columns + column] = source[row * wr + column * wc];
  }
  const auto sr = static_cast<std::size_t>(scales.description().byte_strides()[0]);
  const auto sc = static_cast<std::size_t>(scales.description().byte_strides()[1]);
  const auto scale_columns = columns / 128;
  const auto scale_rows = rows / 128 + (rows % 128 != 0);
  for (std::size_t row = 0; row < scale_rows; ++row)
    for (std::size_t column = 0; column < scale_columns; ++column) {
      const auto code = std::to_integer<std::uint32_t>(scale_source[row * sr + column * sc]);
      const std::uint32_t bits = code == 0 ? 0x00400000u :
                                 code == 255 ? 0x7f800001u : code << 23;
      std::memcpy(target.data() + rows * columns +
                      (row * scale_columns + column) * sizeof(bits), &bits, sizeof(bits));
    }
  return finish(Status::Ok());
}

} // namespace hyle::compute
