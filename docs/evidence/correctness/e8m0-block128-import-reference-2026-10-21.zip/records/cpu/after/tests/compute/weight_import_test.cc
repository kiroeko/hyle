#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <span>
#include <vector>

#include "hyle/compute/low_precision.h"
#include "hyle/compute/weight_import.h"

namespace {
namespace c = hyle::compute;
namespace m = hyle::mem;
using hyle::Status;

c::TensorDesc dense(c::DataType type, std::int64_t rows, std::int64_t columns) {
  return c::TensorDesc::dense(type, std::array{rows, columns}).value();
}
m::Buffer buffer(std::size_t bytes) {
  return m::Buffer::create(m::system_resource(), bytes, 64).value();
}
c::ConstTensorView input(const c::TensorDesc &desc, m::ConstBufferView storage) {
  return c::ConstTensorView::create(desc, storage).value();
}
c::TensorView output(const c::TensorDesc &desc, m::BufferView storage) {
  return c::TensorView::create(desc, storage).value();
}
std::vector<std::byte> contents(m::ConstBufferView storage) {
  std::vector<std::byte> bytes(storage.size());
  EXPECT_TRUE(storage.read(bytes).ok());
  return bytes;
}
std::uint32_t word(std::span<const std::byte> bytes, std::size_t offset) {
  std::uint32_t result;
  std::memcpy(&result, bytes.data() + offset, sizeof(result));
  return result;
}
std::uint32_t oracle(unsigned code) {
  if (code == 0) return 0x00400000u;
  if (code == 255) return 0x7f800001u;
  return std::bit_cast<std::uint32_t>(std::ldexp(1.0F, int(code) - 127));
}

TEST(Float8WeightImport, AllExponentBytesPreserveOriginalWeightAndRawNaN) {
  constexpr std::int64_t n = 1, k = 32768;
  const auto wd = dense(c::DataType::kFloat8E4M3FN, n, k);
  const auto sd = dense(c::DataType::kUInt8, 1, 256);
  const auto yd = c::float8_weight_description(k, n, c::Float8ScaleMode::kFloat32Block128).value();
  auto w = buffer(wd.required_bytes().value());
  auto s = buffer(256);
  auto y = buffer(yd.required_bytes().value());
  std::vector<std::byte> codes(std::size_t(k), std::byte{0});
  for (std::size_t i = 0; i < codes.size(); ++i) codes[i] = std::byte(i & 255u);
  std::array<std::byte, 256> scales{};
  for (unsigned i = 0; i < scales.size(); ++i) scales[i] = std::byte(i);
  ASSERT_TRUE(w.view().write(codes).ok());
  ASSERT_TRUE(s.view().write(scales).ok());
  ASSERT_TRUE(c::import_float8_block128_weight(input(wd, w.view()), input(sd, s.view()),
                                               output(yd, y.view())).ok());
  const auto actual = contents(y.view());
  EXPECT_TRUE(std::equal(codes.begin(), codes.end(), actual.begin()));
  for (unsigned code = 0; code < 256; ++code)
    EXPECT_EQ(word(actual, std::size_t(k) + code * 4), oracle(code)) << code;
  EXPECT_EQ(contents(w.view()), codes);
  EXPECT_EQ(contents(s.view()), (std::vector<std::byte>{scales.begin(), scales.end()}));
}

TEST(Float8WeightImport, PartialNAndSourceStridesKeepPaddingAndAxisOrder) {
  constexpr std::int64_t n = 129, k = 256;
  const auto wd = c::TensorDesc::strided_bytes(c::DataType::kFloat8E4M3FN,
      std::array{n, k}, std::array<std::int64_t, 2>{519, 2}).value();
  const auto sd = c::TensorDesc::strided_bytes(c::DataType::kUInt8,
      std::array<std::int64_t, 2>{2, 2}, std::array<std::int64_t, 2>{9, 3}).value();
  const auto yd = c::float8_weight_description(k, n, c::Float8ScaleMode::kFloat32Block128).value();
  auto w = buffer(wd.required_bytes().value() + 10);
  auto s = buffer(sd.required_bytes().value() + 6);
  auto y = buffer(yd.required_bytes().value() + 32);
  std::vector<std::byte> wb(w.size(), std::byte{0xa5});
  std::vector<std::byte> sb(s.size(), std::byte{0xa5});
  for (std::size_t row = 0; row < std::size_t(n); ++row)
    for (std::size_t col = 0; col < std::size_t(k); ++col)
      wb[5 + row * 519 + col * 2] = std::byte((row * 17 + col * 29) & 255u);
  constexpr std::array<unsigned, 4> scales{0, 127, 1, 254};
  for (std::size_t row = 0; row < 2; ++row)
    for (std::size_t col = 0; col < 2; ++col) sb[3 + row * 9 + col * 3] = std::byte(scales[row * 2 + col]);
  ASSERT_TRUE(w.view().write(wb).ok());
  ASSERT_TRUE(s.view().write(sb).ok());
  ASSERT_TRUE(y.view().fill(std::byte{0x6d}).ok());
  ASSERT_TRUE(c::import_float8_block128_weight(
      input(wd, w.view().subview(5, wd.required_bytes().value()).value()),
      input(sd, s.view().subview(3, sd.required_bytes().value()).value()),
      output(yd, y.view().subview(16, yd.required_bytes().value()).value())).ok());
  const auto actual = contents(y.view());
  for (std::size_t i = 0; i < 16; ++i) EXPECT_EQ(actual[i], std::byte{0x6d});
  for (std::size_t i = actual.size() - 16; i < actual.size(); ++i) EXPECT_EQ(actual[i], std::byte{0x6d});
  for (std::size_t row = 0; row < std::size_t(n); ++row)
    for (std::size_t col = 0; col < std::size_t(k); ++col)
      ASSERT_EQ(actual[16 + row * std::size_t(k) + col], wb[5 + row * 519 + col * 2]);
  for (unsigned i = 0; i < 4; ++i)
    EXPECT_EQ(word(actual, 16 + std::size_t(n * k) + i * 4), oracle(scales[i]));
  EXPECT_EQ(contents(w.view()), wb);
  EXPECT_EQ(contents(s.view()), sb);
}

TEST(Float8WeightImport, InvalidGeometryAndAliasesRejectBeforeWriting) {
  const auto wd = dense(c::DataType::kFloat8E4M3FN, 1, 128);
  const auto sd = dense(c::DataType::kUInt8, 1, 1);
  const auto yd = c::float8_weight_description(128, 1, c::Float8ScaleMode::kFloat32Block128).value();
  auto w = buffer(256), s = buffer(16), y = buffer(256);
  ASSERT_TRUE(w.view().fill(std::byte{0x38}).ok());
  ASSERT_TRUE(s.view().fill(std::byte{127}).ok());
  ASSERT_TRUE(y.view().fill(std::byte{0x6d}).ok());
  const auto original = contents(y.view());
  const auto source = input(wd, w.view());
  const auto scales = input(sd, s.view());
  const auto target = output(yd, y.view());
  EXPECT_FALSE(c::import_float8_block128_weight({}, scales, target).ok());
  EXPECT_FALSE(c::import_float8_block128_weight(
      input(dense(c::DataType::kUInt8, 1, 128), w.view()), scales, target).ok());
  EXPECT_FALSE(c::import_float8_block128_weight(
      source, input(dense(c::DataType::kUInt8, 1, 2), s.view()), target).ok());
  EXPECT_FALSE(c::import_float8_block128_weight(
      input(dense(c::DataType::kFloat8E4M3FN, 1, 129), w.view()), scales, target).ok());
  EXPECT_FALSE(c::import_float8_block128_weight(source, scales,
      output(dense(c::DataType::kUInt8, 1, 132), y.view())).ok());
  EXPECT_FALSE(c::TensorView::create(yd, y.view().subview(0, 131).value()));
  EXPECT_EQ(contents(y.view()), original);
  EXPECT_FALSE(c::import_float8_block128_weight(
      input(wd, y.view()), scales, target).ok());
  EXPECT_FALSE(c::import_float8_block128_weight(source,
      input(sd, y.view().subview(128, 1).value()), target).ok());
  EXPECT_EQ(contents(y.view()), original);
}

class ImportHostResource final : public m::MemoryResource {
 public:
  explicit ImportHostResource(std::span<std::byte> bytes) : bytes_(bytes) {}
  bool identity = true, coherent = true, fail_flush = false, fail_close = false;
  unsigned maps = 0, closes = 0, flushes = 0;
  std::string_view name() const noexcept override { return "import-host-test"; }
  m::MemoryProperties properties() const noexcept override {
    auto flags = m::MemoryProperty::kHostAccessible;
    if (identity) flags |= m::MemoryProperty::kHostAddressIdentity;
    if (coherent) flags |= m::MemoryProperty::kHostDeviceCoherent;
    return {flags, 4, bytes_.size(), {this, 1}};
  }
  hyle::Result<m::ResourceAllocation> allocate(std::size_t, std::size_t) noexcept override {
    return std::unexpected(Status::Unimplemented("test uses adopted host storage"));
  }
  void deallocate(m::ResourceAllocation) noexcept override {}
  hyle::Result<m::ResourceHostMapping> map_host(
      void *, std::size_t offset, std::size_t size, m::HostAccess) noexcept override {
    ++maps;
    if (offset > bytes_.size() || size > bytes_.size() - offset)
      return std::unexpected(Status::OutOfRange("test map range"));
    return m::ResourceHostMapping{bytes_.data() + offset, nullptr};
  }
  Status unmap_host(void *, void *, std::size_t, std::size_t, m::HostAccess) noexcept override {
    ++closes;
    return fail_close ? Status::Unavailable("test import unmap failure") : Status::Ok();
  }
  Status flush(void *, std::size_t, std::size_t) noexcept override {
    ++flushes;
    return fail_flush ? Status::Unavailable("test import flush failure") : Status::Ok();
  }
 private:
  std::span<std::byte> bytes_;
};

TEST(Float8WeightImport, CanonicalAddressProofAndMappingFailuresRemainObservable) {
  const auto wd = dense(c::DataType::kFloat8E4M3FN, 1, 128);
  const auto sd = dense(c::DataType::kUInt8, 1, 1);
  const auto yd = c::float8_weight_description(128, 1, c::Float8ScaleMode::kFloat32Block128).value();
  alignas(64) std::array<std::byte, 256> backing{};
  backing.fill(std::byte{0x6d});
  ImportHostResource source_resource(backing), output_resource(backing);
  int source_token = 0, output_token = 0;
  auto adopted_source = m::Buffer::adopt(m::MemoryResourceRef(source_resource),
      {&source_token, backing.size(), 64}).value();
  auto adopted_output = m::Buffer::adopt(m::MemoryResourceRef(output_resource),
      {&output_token, backing.size(), 64}).value();
  auto scales = buffer(1);
  ASSERT_TRUE(scales.view().fill(std::byte{127}).ok());
  const auto original = backing;
  EXPECT_FALSE(c::import_float8_block128_weight(input(wd, adopted_source.view()),
      input(sd, scales.view()), output(yd, adopted_output.view())).ok());
  EXPECT_EQ(backing, original); // Different resource/handles still physically alias.
  EXPECT_EQ(source_resource.closes, 1u);
  EXPECT_EQ(output_resource.closes, 1u);
  output_resource.identity = false;
  const auto prior_maps = output_resource.maps;
  EXPECT_FALSE(c::import_float8_block128_weight(input(wd, adopted_source.view()),
      input(sd, scales.view()), output(yd, adopted_output.view())).ok());
  EXPECT_EQ(output_resource.maps, prior_maps);
  EXPECT_EQ(backing, original);

  auto weights = buffer(128);
  ASSERT_TRUE(weights.view().fill(std::byte{0x38}).ok());
  output_resource.identity = true;
  output_resource.coherent = false;
  output_resource.fail_flush = true;
  auto status = c::import_float8_block128_weight(input(wd, weights.view()),
      input(sd, scales.view()), output(yd, adopted_output.view()));
  EXPECT_EQ(status.message(), "test import flush failure");
  EXPECT_EQ(output_resource.flushes, 1u);
  output_resource.coherent = true;
  output_resource.fail_flush = false;
  output_resource.fail_close = true;
  status = c::import_float8_block128_weight(input(wd, weights.view()),
      input(sd, scales.view()), output(yd, adopted_output.view()));
  EXPECT_EQ(status.message(), "test import unmap failure");
}
} // namespace
