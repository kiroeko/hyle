from pathlib import Path
P=Path(__file__).resolve().parents[1];R=P.parents[2]
p=R/'docs/developer/current-work.md';s=p.read_text(encoding='utf8')
old='真实E8M0 macroblock128 scale-only导入，不能套group32格式。'
new='真实E8M0 macroblock128冷导入已通过[4项单测与4端Graph消费](../evidence/correctness/e8m0-block128-import-reference-2026-10-21.json)，不能套group32格式；所选payload／精确角色绑定仍未签。'
assert s.count(old)==1
p.write_text(s.replace(old,new),encoding='utf8')
