from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1];D=A/'compact-mla-e4-2026-10-21'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
producer=read(D/'producer-review.json');architecture=read(D/'architecture-review.json');proof=read(D/'nvcc-proof/summary.json')
entries={};suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c','.md','.cu','.yaml','.yml','.d','.sass'}
for p in D.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes:entries['records/'+p.relative_to(D).as_posix()]=p
def collect(value):
 if isinstance(value,list):
  for x in value:collect(x)
 elif isinstance(value,dict):
  if isinstance(value.get('path'),str) and value.get('sha256'):
   p=Path(value['path']);p=p if p.is_absolute() else R/p
   if p.is_file() and p.is_relative_to(R) and p.suffix.lower() in suffixes and p.stat().st_size<2000000:
    assert sha(p)==value['sha256'],str(p)
    entries.setdefault('referenced/'+p.relative_to(R).as_posix(),p)
  for x in value.values():collect(x)
collect(producer);collect(architecture)
archive=R/'docs/evidence/research/compact-mla-e4-contract-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
doc=dict(observed_on='2026-10-21',status='primary_source_contract_review_and_isolated_SM89_static_layout_proof_not_product_execution',
 conclusions=[
  'ModelOpt fixed recipe4956213 quantizes expandedK/V at attention_interface after originalcache.update; constantamax448 gives unit FP8QDQ. It does not establish compressedCKV/KPE cache bytes. Artifact29 exactproducer a4bc45b30 source unavailable; no equivalence asserted.',
  'UniformcompactE4 runtime need independently established from pinned official SGLang/vLLM implementations. RawTRTLLM MLA has one512B CKV row, or576B CKV512+KPE64 row, V is sharedfirst512prefix. One shared latent scale applies to both QK andPV; SGLang rawwrite unitcast is not proof of arbitrary nonunit equivalence.',
  'Catalog29 pinnedREADME explicitly selects fp8_e4m3+TRTLLM prefill/decode. Catalog28 does not fix cache dtype/backend; do not claim its default deployment is E4. Runtime snapshotcommits do not identify publisher unpinnedcontainer.',
  'ScaledDSA is another representation: E4CKV512+fourF32group128scales+BF16KPE64=656B, or528B NoPE. Neither uniformE4 nor current Hyle584B rowcache describes it.',
  'Current public MLA couples Q/cache/Y dtype and only plainF16/BF16 qualification. Natural next change separates query/output dtype from one shared CacheStorage, retaining existing CKV physical row/Vprefix and original execution core.',
  'PinnedFlashInfer E4 defaultKV32 one-stage exceeds SM89 dynamicsharedblock99KiB. Isolated candidate keepsQ64/256threads/scheduler, selectsE4KV16 and removes512B deadnonshardedm/dscratch. Actual NVCC static assertions prove Rope64 sizeof101376B, NoPE91296B, align16, alloffsets; originalplainBF16 byte layouts andPlanInfo unchanged.',
  'E4 candidate supports BF16Q/Y only. ScaleF32 multiply precedes final BF16RNE; isolated helper SASS is FMUL withoutFTZ thenF2FP.BF16.F32. OriginalBF16scale-first path gives an independently recorded1ULP discrepancy.'
 ],
 next_action='Productize homogeneous compact CacheStorage in existing MLA schema/planner and original four backend readers; use BF16Q/E4KV fixedsharedscale initialCUDA domain, preserving originalplain routes. Apply verifiedvendorcandidate through normalmanifest, instantiate realkernel and run bounded numerical/geometry/lifetime cases. No new executor or model whitelist.',
 source_reviews=dict(producer=producer,architecture=architecture,isolated_NVCC=proof),
 limits=['No product/manifest/currentnative owner changes, no fullMLA kernel instantiation, no link or GPUexecution from isolatedproof.',
 'No exactartifactproducer a4bc source, weightpayload, wholemodel, Linux, quality or throughput acceptance.',
 'Staticsharedsize equalsSM89 limit; runtimefunction attributes/resource feasibility and actualkernel remain to be tested. This is a concretecandidate, not a signedworkingCUDApath.',
 'Uniformfixedscale compactE4 does not imply dynamicgroup-scale mixedDSA supported. F16Q E4 is not exposed.'],
 archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
save(P/'root/compact-research-package.json',dict(report=ident(archive.with_suffix('.json')),archive=doc['archive']))
print(json.dumps(dict(report=ident(archive.with_suffix('.json')),archive=doc['archive']),ensure_ascii=False))
