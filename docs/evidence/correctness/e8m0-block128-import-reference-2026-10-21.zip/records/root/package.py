from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def check(row):
 p=Path(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
def archive(entries,path):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
  for name,p in sorted(entries.items()):z.write(p,name)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and len(z.namelist())==len(entries)
  for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
 return dict(**ident(path),members=len(entries))

records=[];cases=set();graph_submissions=0
for arm in ['cpu','cuda','vulkan']:
 receipt=P/arm/'validation/attempt1/receipt.json';d=read(receipt)
 assert d['passed'] and not d['failed'] and not d['skipped'];check(d['xml']);check(d['image']);check(d['link_plan'])
 xml=ET.parse(d['xml']['path']).findall('.//testcase')
 names=[x.get('classname')+'.'+x.get('name') for x in xml]
 assert names==d['names'] and all(x.find('failure') is None and x.find('skipped') is None for x in xml)
 cases.update((arm,n) for n in names);records.append(dict(backend=arm,receipt=ident(receipt),names=names))
 graph_submissions+=sum(int(p['value']) for row in d['properties'] for p in row['properties'] if p['name']=='successful_submissions')
applepath=P/'apple/final-validation.json';apple=read(applepath)
assert apple['tests']==1 and apple['failed']==apple['skipped']==0;check(apple['gtest'])
xml=ET.parse(apple['gtest']['path']).findall('.//testcase')
assert len(xml)==1 and all(x.find('failure') is None and x.find('skipped') is None for x in xml)
cases.update(('apple',x.get('classname')+'.'+x.get('name')) for x in xml)
graph_submissions+=apple['successful_submissions'];assert len(cases)==8 and graph_submissions==16

sources={'include/hyle/compute/weight_import.h','src/compute/weight_import.cc','src/compute/CMakeLists.txt',
 'tests/compute/weight_import_test.cc','tests/compute/CMakeLists.txt',
 'tests/compute_models/e8m0_weight_import_fixture.h','tests/compute_models/nvfp4_reference_fixture.h',
 'include/hyle/compute/low_precision.h','src/compute_ops/low_precision.cc',
 'docs/user/compute.md','docs/developer/current-work.md','docs/implementation/model-operators.md',
 'docs/implementation/model-quantizations.json'}
for arm in ['cpu','cuda','vulkan','apple']:
 sources.update(f'tests/graph_route_{arm}/{n}' for n in ['e8m0_weight_import_test.cc','CMakeLists.txt'])
for row in read(P/'cpu/source-freeze.json')['files']:
 p=Path(row['source']);assert sha(p)==row['after']['sha256']
for row in read(P/'apple/source-freeze.json')['sources']:check(row)
for file in ['cpu/checks/attempt2/weight-import-identity.json','cpu/checks/attempt1/weight-import-test-identity.json',
             'cpu/checks/attempt1/test-identity.json','cuda/checks/attempt1/test-identity.json','vulkan/checks/attempt2/test-identity.json']:
 d=read(P/file);check(d['source']);check(d['object'])
 for row in d.get('dependencies',[]):check(row)
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c','.md'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
design=A/'e8m0-block128-import-2026-10-21'
for p in design.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes:
  entries['research/'+p.relative_to(design).as_posix()]=p
target=R/'docs/evidence/correctness/e8m0-block128-import-reference-2026-10-21.zip'
z=archive(entries,target)
doc=dict(observed_on='2026-10-21',status='cold_host_import_and_four_backend_original_dense_linear_reference_passed',
 public_entry='hyle::compute::import_float8_block128_weight(ConstTensorView E4[N,K], ConstTensorView U8[ceil(N/128),K/128], TensorView canonical)',
 architecture='New compute runtime cold leaf; no Graph operation/provider dispatch/executor added. Caller allocates host canonical float8_weight_description(K,N,kFloat32Block128), uploads once if required, and binds original constant to existing Float8BlockLinear. E4 codes copied unchanged; only the small E8 grid is widened. No N*K floating weight bank is produced by the importer.',
 storage_math='K whole128 blocks, N positive/tail allowed. Scale codes1..254 have F32 bits code<<23;0 has0x00400000 (2^-127);255 has raw0x7f800001 matching fixed PyTorch2.8 conversion. No FP operation on that NaN during import. Source two-axis valid nonnegative byte strides supported; canonical output exact opaque descriptor.',
 resources='HostAccessible plus HostAddressIdentity for all ports; source readiness/publication/synchronization/transfer remain caller-owned. Geometry/capacity/resource+handle and canonical-address overlap checked before write; all three maps obtained before write. Mapping/invalidate/flush/close errors observable, no rollback promised after write. No implicit device readback/upload or unknown shadow mapping.',
 regression=dict(distinct_backend_scoped_cases=8,host_unit_cases=4,graph_cases=4,failed=0,skipped=0,
  graph_successful_submissions=16,windows=records,apple=ident(applepath),names=[dict(backend=a,name=n) for a,n in sorted(cases)],
  host_scope='All256 rawcodes and unchanged E4 payload; N129/K256 nonsquare2x2 grid, padding/nonunitK/canaries; malformed shapes/capacity/metadata+canonical-address aliases rejected beforewrite; noidentity rejected; flush/unmap errors returned.',
  graph_scope='Each backend: one coldimport, originalBF16 dense Float8BlockLinear(PowerOfTwo,1e-4), M2/N129/K256, originalE4 bank and independent scale grid. Twoinvocations x2contentphases, realGraphOutput blocks reuse; oldresults remain valid after invocation/executable/constants destroyed. CUDA RequireCapture checked captured route.',
  oracle='Independent literal E4 coefficients, ldexp host scale widening and scalar BF16/F32 operations. Chosen per128 activation amax=448*(1or2) makes QDQ exactly identity; finite Graph witness is not a general quantization oracle and does not distinguishNone/Power2.'),
 builds=dict(Windows_CXX_success=5,Windows_CXX_failed_prior=1,Windows_links=3,Apple_CXX_success=2,Apple_links=1,SDK_rebuilt=0,NVCC=0,
  reuse='One provider-neutral Windows import object reused across three original actual link closures. Only leaf/unit/newGraph wrappers compiled. Existing SDK/provider/native objects and Apple metallib reused.'),
 failures_retained=['First product compile referenced a provider-private preserve_first_error helper; corrected to publicStatus::Update, prior source/log retained.',
 'Root Vulkan wrapper helper first selected an unsuitable archived command; strict recipe check rejected before compiler launch. Selected original strict groupedGraph CXX recipe; no product change.'],
 limits=['Synthetic original-format bytes only; no publisher weight payload/exact role binding, wholemodel, Linux, quality or throughput acceptance.',
 'Scale specialcodes0/255 are import-byte unit coverage, not GPU numerical execution coverage. Downstream finite/NaN restrictions remain its own contract.',
 'New Graph witness is dense only; previous groupedpower2 tests remain separate. No native FP8GEMM or all-shape/backend temporary-memory claim.',
 'Hostmapping/flusherror failure may occur after writes; failed output must not be published. Source/output address proof conservatively rejects overlapping accessed spans including padding.'],
 independent_source_review=ident(P/'root/fixture-source-review.json'),
 research=ident(design/'design.json'),current_sources=[ident(R/s) for s in sorted(sources)],archive=z,
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(target.with_suffix('.json'),doc)
summary=dict(evidence=ident(target.with_suffix('.json')),archive=z,current_sources=len(sources),cases=8,skipped=0)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
