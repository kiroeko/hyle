from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('e8_import_build',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];assert arm in ['cpu','cuda','vulkan']
recipes={
 'cpu':A/'grouped-fp8-power2-reference/cpu/checks/attempt1/power-test-plan.json',
 'cuda':A/'grouped-fp8-power2-reference/cuda/checks/new-wrapper/attempt3/compile-command.json',
 'vulkan':A/'grouped-fp8-power2-reference/vulkan/checks/test2/grouped-power-compile.command.json'}
recipe=recipes[arm]
old=c.read(recipe);out=P/arm/'checks'/sys.argv[2]
out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
source=R/f'tests/graph_route_{arm}/e8m0_weight_import_test.cc';tag='import-consumer'
assert not (out/(tag+'.result.json')).exists()
command=b.host_command(old['command'],source,tag,out)
c.save(out/'compile-plan.json',dict(command=command,recipe=b.identity(recipe),source=b.identity(source)))
env,_=b.environment(command,[],out);c.execute(tag,command,env,out)
deps=c.read(out/(tag+'-deps.json'))['Data']
c.save(out/'test-identity.json',dict(command=command,source=b.identity(source),object=b.identity(out/(tag+'.obj')),
 source_dependencies=b.identity(out/(tag+'-deps.json')),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
print(out/'test-identity.json')
