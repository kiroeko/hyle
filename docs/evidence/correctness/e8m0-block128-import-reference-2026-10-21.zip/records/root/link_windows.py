from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent
spec=importlib.util.spec_from_file_location('e8_import_link',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];assert arm in ['cpu','cuda','vulkan']
bases={
 'cpu':A/'paged-e4-kv-reference/cpu/checks/attempt2/link-plan.json',
 'cuda':A/'paged-e4-kv-reference/cuda/checks/attempt4/link-plan.json',
 'vulkan':A/'paged-e4-kv-reference/vulkan/checks/q8-neighbor/link-plan.json'}
basepath=bases[arm];base=c.read(basepath)
ready=c.read(P/'cpu/checks/attempt2/objects-ready.json')
testpath=P/arm/'checks'/('attempt2' if arm=='vulkan' else 'attempt1')/'test-identity.json'
extra=[ready['product'],c.read(testpath)['object']]
if arm=='cpu':extra.append(ready['test'])
inputs=[*extra,*base['inputs']]
assert len({c.key(r['path']) for r in inputs})==len(inputs)
assert all(b.same(r) for r in inputs)
out=P/arm/'checks'/sys.argv[2];out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'link.result.json').exists()
command=[x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command[1:1]=[r['path'] for r in extra]
image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),
 append_only_leaf=True,SDK_builds=0,NVCC=0))
env,runtime=b.environment(command,[r['path'] for r in inputs],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print(out/'link-plan.json')
