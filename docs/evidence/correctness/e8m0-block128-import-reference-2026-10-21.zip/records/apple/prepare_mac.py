from pathlib import Path
import json,hashlib,base64,re,runpy
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'e8m0-block128-import-reference/apple';S.mkdir(exist_ok=True);O=S/'mac';O.mkdir(exist_ok=True)
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/e8m0-block128-import-reference/apple'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,o):Path(p).write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
old=A/'paged-e4-kv-reference/apple/mac/remote';oldplan=read(old/'plan.json')
plan=dict(oldplan,remote=REMOTE,image='e8m0-weight-import',filter='AppleE8M0WeightImport.*',compile=[],link=read(old/'results/link.command.json')['argv'],inputs=read(old/'results/link-inputs.json'))
for source,recipefile in [('src/compute/weight_import.cc','src--compute_route_apple--apple_static_fp8.cc-compile.command.json'),('tests/graph_route_apple/e8m0_weight_import_test.cc','tests--graph_route_apple--paged_e4_kv_test.cc-compile.command.json')]:
 plan['compile'].append(dict(source=source,recipe=read(old/'results'/recipefile)['argv'],old_object=''))
plan['include_roots']=[x for x in plan['include_roots']if x!='native'];plan['include_roots'].insert(0,oldplan['remote']+'/native')
plan['source_basis']={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()for name in ['include/hyle/compute/weight_import.h','src/compute/weight_import.cc','tests/compute_models/e8m0_weight_import_fixture.h','tests/graph_route_apple/e8m0_weight_import_test.cc']}
search=[ROOT,ROOT/'include',*[x for x in(ROOT/'src').iterdir()if x.is_dir()],*[x for x in(ROOT/'third_party').iterdir()if x.is_dir()]]
seen=set();include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M)
def visit(path):
 path=path.resolve()
 if path in seen or not path.is_relative_to(ROOT)or not path.is_file():return
 if path.suffix not in ['.h','.hpp','.hh','.cc','.mm','.inc','.inl','.cuh']:return
 seen.add(path)
 for name in include.findall(path.read_text(encoding='utf-8',errors='replace')):
  target=next((base/name for base in [path.parent,*search]if(base/name).is_file()),None)
  if target:visit(target)
for row in plan['compile']:visit(ROOT/row['source'])
files=[]
for path in sorted(seen):
 b=path.read_bytes();files.append(dict(path=path.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
save(O/'source-manifest.json',[{k:v for k,v in row.items()if k!='data'}for row in files]);save(O/'plan.json',plan)
script=(A/'paged-e4-kv-reference/apple/build_mac.py').read_bytes();(S/'build_mac.py').write_bytes(script)
payload=dict(plan=plan,files=files,script=base64.b64encode(script).decode())
code=r'''
from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p['plan']['remote']);r.mkdir(parents=True,exist_ok=True);assert not r.is_symlink()
for row in p['files']:
 b=base64.b64decode(row['data']);assert hashlib.sha256(b).hexdigest()==row['sha256'];q=r/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/'source-manifest.json').write_text(json.dumps([{k:v for k,v in row.items()if k!='data'}for row in p['files']],indent=2)+'\n');(r/'plan.json').write_text(json.dumps(p['plan'],indent=2)+'\n');(r/'build_mac.py').write_bytes(base64.b64decode(p['script']))
for row in p['plan']['inputs']:
 q=Path(row['path']);assert q.stat().st_size==row['bytes'];assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'],row['path']
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'space':['df','-h',str(r)]}.items()};assert h['model']=='Mac16,12';(r/'hardware.json').write_text(json.dumps(h,indent=2)+'\n')
print(json.dumps({'remote':str(r),'files':len(p['files']),'bytes':sum(x['bytes']for x in p['files']),'compile_owners':len(p['plan']['compile']),'hardware':h}))
'''
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];result=ssh(code,payload);save(O/'sync.result.json',result);print(json.dumps(result,indent=2))