from pathlib import Path
import hashlib,json,runpy,xml.etree.ElementTree as E
ROOT=Path.cwd();S=ROOT/'.scratch/architecture-refactor-2026-10-18/e8m0-block128-import-reference/apple';R=S/'mac/remote';O=R/'results'
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,o):Path(p).write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
files=['include/hyle/compute/weight_import.h','src/compute/weight_import.cc','tests/compute_models/e8m0_weight_import_fixture.h','tests/graph_route_apple/e8m0_weight_import_test.cc']
for rel in files:
 p=S/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/rel).read_bytes())
manifest=read(S/'mac/source-manifest.json');assert all(identity(ROOT/x['path'])['sha256']==x['sha256']for x in manifest)
compiles=read(O/'compile-summary.json')['compiles'];assert len(compiles)==2 and all(x['exit']==0 and not x['source_drifts']for x in compiles)
cases=E.parse(O/'tests.xml').getroot().findall('.//testcase');assert len(cases)==1 and all(not x.findall('failure')and not x.findall('skipped')for x in cases)
assert read(O/'run.result.json')['exit']==0 and read(O/'link.result.json')['exit']==0
freeze=dict(status='current_canonical_source_and_actual_Mac_objects',sources=[identity(ROOT/x)for x in files],test_CMake=identity(ROOT/'tests/graph_route_apple/CMakeLists.txt'),canonical_remote_files=len(manifest),all_hashes_current=True,product_edits_by_Apple_agent=0,compile_owners=[x['source']for x in compiles],SDK_rebuilt=False,prior_link_closure='paged-e4-kv-reference/apple/mac/remote/results/link.command.json and link-inputs.json',dependency_check='Every retained object/archive/dylib from prior actual link input verified by bytes and SHA before compile; new TU dependency hashes recorded.')
save(S/'source-freeze.json',freeze)
validation=dict(status='actual_Mac16_12_Metal_pass',source_freeze=identity(S/'source-freeze.json'),source_manifest=identity(S/'mac/source-manifest.json'),hardware=identity(R/'hardware.json'),runtime=identity(R/'runtime-identity.json'),tests=1,failed=0,skipped=0,cold_weight_imports=1,successful_submissions=4,expected_failed_completions=0,
 cases=[dict(name=x.get('classname')+'.'+x.get('name'),properties={p.get('name'):p.get('value')for p in x.findall('./properties/property')})for x in cases],compiles=[dict(source=x['source'],object=x['object_identity'],exit=x['exit'],dependency_count=len(x['dependencies']),source_drifts=x['source_drifts'])for x in compiles],actual_commands='mac/remote/results/*command.json',link=identity(O/'link.result.json'),run=identity(O/'run.result.json'),gtest=identity(O/'tests.xml'),
 scope=['Cold host E4[N129,K256] + E8[2,2] importer preserves all code bytes and independently widened F32 macroblock scale order.','Imported compressed bank consumed by original Float8BlockLinear(kPowerOfTwo,1e-4) on BF16 A[M2,K256], BF16 Y[M2,N129].','Two invocation slots, four actual content submissions, retained result blocks reuse and remains correct after invocation/executable destruction.'],
 limitations=['Product CPU unit tests were not repeated on the Mac; root owns their Windows actual results.','This Apple execution witness uses ordinary finite scale bytes126/128/127/129; raw E8 codes0/255 and mapping failures belong to product unit tests, not this GPU witness.','No model weight payload/importer model binding, throughput or numerical claim beyond the shared finite fixture.'],performance_claim=False,product_modified=False)
save(S/'final-validation.json',validation)
ssh=runpy.run_path(str(ROOT/'.scratch/architecture-refactor-2026-10-18/batch-query-extent/delegated/apple/validate.py'))['ssh'];remote=read(S/'mac/plan.json')['remote']
code=r'''
from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['remote'])
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
files=[r/'e8m0-weight-import',r/'e8m0-weight-import.map'];ps=subprocess.run(['ps','-axo','pid=,command='],capture_output=True,text=True)
o=dict(remote=str(r),root_is_symlink=r.is_symlink(),deletable_files=[identity(x)for x in files if x.is_file()and not x.is_symlink()],retain_objects=[identity(x)for x in sorted((r/'objects').glob('*.o'))],dSYM=[str(x)for x in r.glob('*.dSYM')],process_matches=[x for x in ps.stdout.splitlines()if str(r)in x and 'python3 -c'not in x and '/bin/sh -c'not in x],metallib=dict(path=str(r/'mlx.metallib'),is_symlink=(r/'mlx.metallib').is_symlink(),target=str((r/'mlx.metallib').resolve())),lsof=[],action='Read-only; retained images until root evidence and test.ps1 cleanup.')
for x in files:
 p=subprocess.run(['lsof',str(x)],capture_output=True,text=True);o['lsof'].append(dict(path=str(x),exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
print(json.dumps(o))
'''
cleanup=ssh(code,dict(remote=remote));save(S/'cleanup-readonly-inventory.json',cleanup)
print(json.dumps(dict(freeze=identity(S/'source-freeze.json'),validation=identity(S/'final-validation.json'),cleanup=identity(S/'cleanup-readonly-inventory.json'),deletable_bytes=sum(x['bytes']for x in cleanup['deletable_files']),retained_object_bytes=sum(x['bytes']for x in cleanup['retain_objects']),process_matches=cleanup['process_matches']),indent=2))