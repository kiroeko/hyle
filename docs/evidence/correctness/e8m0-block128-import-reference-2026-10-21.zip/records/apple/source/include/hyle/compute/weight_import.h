#pragma once

#include "hyle/compute/tensor.h"

namespace hyle::compute {

// Cold host import of original E4M3FN [N,K] weight bytes and unsigned E8M0
// macroblock scales [ceil(N/128),K/128]. Sources may have valid nonnegative
// byte strides. K must contain complete128-value blocks. Output is the exact
// float8_weight_description(K,N,kFloat32Block128) carrier: unchanged row-major
// E4 bytes followed by native F32 scale storage. This never expands the weight
// matrix to floating point and performs no activation quantization.
//
// All views must expose stable canonical host addresses (HostAccessible and
// HostAddressIdentity). Device transfers and unknown shadow mappings are not
// implicit. Output must not overlap either source, including through another
// resource/handle. Geometry, capacity and aliases are checked before writing.
// The caller owns allocation, source readiness, synchronization and publication.
//
// Scale bytes0..254 widen exactly;0 is2^-127. Byte255 is stored as F32 raw
// bits0x7f800001, matching the fixed PyTorch2.8 E8M0 conversion. No floating
// operation quiets that NaN during import. Flush/unmap failures are returned;
// a failure after writing does not guarantee rollback or grant ready content.
HYLE_COMPUTE_API Status import_float8_block128_weight(
    ConstTensorView weight, ConstTensorView scales, TensorView output) noexcept;

} // namespace hyle::compute
