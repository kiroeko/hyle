from pathlib import Path
import hashlib,json,time,urllib.request,urllib.error
S=Path('.scratch/architecture-refactor-2026-10-18/e8m0-block128-import-2026-10-21');rows=[]
requests=[('25-convert.py','https://huggingface.co/nvidia/DeepSeek-V4-Pro-0813-NVFP4/resolve/949138637e8e8fe190335be2396af62187dc8a83/inference/convert.py',131072),('26-convert.py','https://huggingface.co/nvidia/DeepSeek-V4-Flash-0731-NVFP4/resolve/f1caa71142bd0be02f728c79f75042ac1e461579/inference/convert.py',131072),('Float8_e8m0fnu-inl.h','https://raw.githubusercontent.com/pytorch/pytorch/v2.8.0/c10/util/Float8_e8m0fnu-inl.h',16384)]
for name,url,cap in requests:
 row=dict(url=url,cap_bytes=cap,model_payload_bytes=0);t=time.time()
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Hyle bounded source review'}),timeout=20) as r:
   length=r.headers.get('Content-Length');assert not length or int(length)<=cap
   b=r.read(cap+1);assert len(b)<=cap;row.update(status=r.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),headers={k:r.headers[k] for k in ['Content-Type','ETag','X-Repo-Commit'] if k in r.headers});(S/'sources'/name).write_bytes(b);row['path']=str(S/'sources'/name)
 except urllib.error.HTTPError as e:row.update(status=e.code,error=str(e),bytes_downloaded=0)
 row['seconds']=time.time()-t;rows.append(row);print(name,row.get('status'),row.get('bytes',0),flush=True)
(S/'source-downloads.json').write_text(json.dumps(rows,indent=2)+'\n')
