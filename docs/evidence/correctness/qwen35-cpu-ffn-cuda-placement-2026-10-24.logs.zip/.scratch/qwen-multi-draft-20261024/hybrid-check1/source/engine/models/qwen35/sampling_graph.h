#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <initializer_list>
#include <limits>
#include <stdexcept>

#include "hyle/compute/sampling_ops.h"
#include "hyle/graph/graph.h"

// Cold K=1 speculative-sampling mathematics. This appends ordinary public
// Compute nodes to the caller's existing Recipe/Graph; it owns no invocation,
// callback, random generator, token policy, session cursor or output storage.
namespace qwen35::sampling {
namespace c = hyle::compute;
namespace g = hyle::graph;
using Value = g::ValueId;
using Type = c::DataType;
constexpr auto fixed(std::int64_t n) noexcept { return g::Dimension::fixed(n); }

struct Decision final {
  Value accepted; // Bool[1]. Accepts the caller's proposal as the first output.
  Value final_id; // I32[1]. Accepted: target bonus; rejected: residual token.
  Value valid;    // Bool[1]. All outputs are unusable until this is checked.
  // Optional scalar diagnostics, not implicitly published Graph outputs.
  Value p_valid, q_valid, bonus_valid, proposal_valid, residual_positive;
};

struct Policy final {
  float temperature = 1;
  std::size_t top_k = 0; // Zero disables top-k; a positive value must fit V.
  float top_p = 1;
};
struct Distribution final {
  Value log_probabilities; // F32[1,V], in original vocabulary order.
  Value valid;             // Bool[1]; caller must check before using the row.
};

// Fixed stochastic policy: temperature -> top-k -> top-p -> normalization.
// This is not an arbitrary sampler chain. Temperature is finite and positive;
// top_p is in (0,1]. Greedy temperature==0 belongs to the caller's greedy path.
// Stable TopK breaks equal-logit ties by original token ID. The nucleus keeps
// the smallest descending prefix whose mass reaches/exceeds top_p: entries
// whose PRIOR cumulative mass equals top_p are excluded. The first token is
// always retained. top_p<1 with top_k==0 requires a complete vocabulary sort.
// NaN/+Inf/all--Inf rows are invalid before filtering can hide bad columns.
// Invalid rows can have safe placeholder probabilities for eager execution;
// valid MUST join the decision/session publication check, never be ignored.
template<class R>
Distribution distribution(R &r, Value logits, Policy policy = {}) {
  const auto spec = r.spec(logits);
  if (spec.data_type() != Type::kFloat32 || spec.rank() != 2 || spec.dimensions()[0] != fixed(1) ||
      !spec.dimensions()[1].is_fixed() || spec.dimensions()[1].fixed_value() <= 0 ||
      spec.dimensions()[1].fixed_value() > (std::numeric_limits<std::int32_t>::max)())
    throw std::runtime_error("sampling policy requires one F32[1,V] row with positive I32 vocabulary");
  const auto vocabulary_size = static_cast<std::size_t>(spec.dimensions()[1].fixed_value());
  if (!std::isfinite(policy.temperature) || policy.temperature <= 0 || !std::isfinite(policy.top_p) ||
      policy.top_p <= 0 || policy.top_p > 1 || policy.top_k > vocabulary_size)
    throw std::runtime_error("sampling policy requires positive finite temperature, top_p in (0,1], top_k <= V");
  const auto zero = r.scalar(0), one = r.scalar(1);
  const auto no = r.cast(zero, Type::kBool), yes = r.cast(one, Type::kBool);
  const auto select = [&](Value condition, Value a, Value b) { return r.one(c::Select{}, {condition, a, b}); };
  const auto reduce = [&](c::ReductionKind kind, Value value) {
    return r.copy(r.reshape(r.one(c::Reduce{.kind = kind, .accumulation_type = Type::kFloat32}, {value}), {fixed(1)}));
  };
  const auto valid_mass = [&](Value log_weights) {
    const auto mass = reduce(c::ReductionKind::kSum, r.unary(c::UnaryKind::kExp, log_weights));
    const auto bad = r.cast(r.binary(c::BinaryKind::kSubtract,
        r.binary(c::BinaryKind::kDivide, mass, mass), one), Type::kBool);
    return select(bad, no, yes);
  };
  // Shift before temperature to avoid overflowing large, finite positive
  // logits. The original full row is checked before any TopK/Select masks it.
  const auto centered = r.binary(c::BinaryKind::kSubtract, logits, reduce(c::ReductionKind::kMaximum, logits));
  const auto input_valid = valid_mass(centered);
  auto selected = r.binary(c::BinaryKind::kDivide, select(input_valid, centered, zero), r.scalar(policy.temperature));
  if ((policy.top_k && policy.top_k < vocabulary_size) || policy.top_p < 1) {
    const auto count = policy.top_k ? policy.top_k : vocabulary_size;
    const auto ranked = r.op(c::Operation(c::TopK{.count = count}), {selected});
    auto values = ranked.at(0);
    const auto indices = r.copy(r.reshape(ranked.at(1), {fixed(static_cast<std::int64_t>(count))}));
    if (policy.top_p < 1) {
      const auto probabilities = r.one(c::Softmax{.axis = 1}, {values});
      const auto prior = r.one(c::Scan{.axis = 1, .exclusive = true}, {probabilities});
      const auto under_cutoff = r.cast(r.unary(c::UnaryKind::kRelu,
          r.binary(c::BinaryKind::kSubtract, r.scalar(policy.top_p), prior)), Type::kBool);
      // Exclusive CDF begins at exact zero. Keep that first entry explicitly,
      // rather than relying on a possibly subnormal top_p arithmetic result.
      const auto first = select(r.cast(prior, Type::kBool), no, yes);
      const auto keep = select(first, yes, under_cutoff);
      values = select(keep, values, r.scalar(-(std::numeric_limits<float>::infinity)()));
    }
    const auto shape = c::TensorShape::create(std::array<std::int64_t, 2>{1, static_cast<std::int64_t>(vocabulary_size)});
    if (!shape) throw std::runtime_error("sampling vocabulary fill shape differs");
    const auto empty = r.one(c::Fill{.output_shape = *shape, .output_type = Type::kFloat32,
        .value = c::ScalarValue(-(std::numeric_limits<float>::infinity)())}, {});
    selected = r.one(c::Scatter{.axis = 1}, {empty, indices, values});
  }
  const auto normalized = r.one(c::Softmax{.axis = 1, .kind = c::SoftmaxKind::kLogSoftmax}, {selected});
  return {normalized, select(input_valid, valid_mass(normalized), no)};
}

// log_p/log_q/log_bonus are F32[1,V], already normalized AFTER the caller's
// temperature/top-k/top-p policy. log_p verifies proposal; log_bonus is the
// target's next conditional distribution after that proposal. -Inf means zero
// mass. Normalization is a caller precondition, not silently recomputed here.
// Entire rows are checked for NaN/+Inf/all-zero probability, including columns
// that were not proposed. A proposed q(y)==0 is invalid, even when p(y)==0.
// proposal is I32[1]; out-of-range IDs fail the existing checked Gather.
// The two U32[1,4] identities are independent key/draw addresses, also distinct
// from the draw that produced proposal. The caller commits/restores their draw
// cursor with its original session transaction.
// Eager evaluation of an unselected zero residual is safe. A residual with no
// positive support on an actual rejection is invalid; no fallback is published.
template<class R>
Decision decision(R &r, Value log_p, Value log_q, Value log_bonus, Value proposal,
                  Value accept_identity, Value final_identity) {
  const auto p = r.spec(log_p);
  if (p.data_type() != Type::kFloat32 || p.rank() != 2 || p.dimensions()[0] != fixed(1) ||
      !p.dimensions()[1].is_fixed() || p.dimensions()[1].fixed_value() <= 0 ||
      p.dimensions()[1].fixed_value() > (std::numeric_limits<std::int32_t>::max)())
    throw std::runtime_error("sampling requires one normalized F32[1,V] row with positive I32 vocabulary");
  for (const auto value : {log_q, log_bonus}) {
    const auto spec = r.spec(value);
    if (spec.data_type() != p.data_type() || !std::ranges::equal(spec.dimensions(), p.dimensions()))
      throw std::runtime_error("sampling p/q/bonus row shapes or types differ");
  }
  const auto require_port = [&](Value value, Type type, std::initializer_list<g::Dimension> shape) {
    const auto spec = r.spec(value);
    if (spec.data_type() != type || spec.rank() != shape.size() ||
        !std::equal(spec.dimensions().begin(), spec.dimensions().end(), shape.begin()))
      throw std::runtime_error("sampling proposal or key/draw port differs");
  };
  require_port(proposal, Type::kInt32, {fixed(1)});
  require_port(accept_identity, Type::kUInt32, {fixed(1), fixed(4)});
  require_port(final_identity, Type::kUInt32, {fixed(1), fixed(4)});

  const auto zero = r.scalar(0), one = r.scalar(1);
  const auto no = r.cast(zero, Type::kBool), yes = r.cast(one, Type::kBool);
  const auto select = [&](Value condition, Value a, Value b) {
    return r.one(c::Select{}, {condition, a, b});
  };
  const auto negate_bool = [&](Value value) { return select(value, no, yes); };
  const auto both = [&](Value a, Value b) { return select(a, b, no); };
  const auto either = [&](Value a, Value b) { return select(a, yes, b); };
  const auto sum = [&](Value value) {
    // There is exactly one request. Reducing all axes avoids a second row
    // convention while keeping the public output a one-element scalar port.
    return r.copy(r.reshape(r.one(c::Reduce{.kind = c::ReductionKind::kSum,
        .accumulation_type = Type::kFloat32}, {value}), {fixed(1)}));
  };
  const auto row_valid = [&](Value log_weights) {
    const auto mass = sum(r.unary(c::UnaryKind::kExp, log_weights));
    // Runtime division is intentional IEEE domain checking: finite positive
    // s yields 1, while 0/0, Inf/Inf and NaN yield NaN (truth under Bool Cast).
    // Do not replace this with a fast-math identity or a min/max reduction,
    // which could hide a NaN in an unselected vocabulary column.
    const auto invalid = r.binary(c::BinaryKind::kSubtract,
        r.binary(c::BinaryKind::kDivide, mass, mass), one);
    return negate_bool(r.cast(invalid, Type::kBool));
  };
  const auto p_valid = row_valid(log_p), q_valid = row_valid(log_q), bonus_valid = row_valid(log_bonus);
  const auto safe_p = select(p_valid, log_p, zero), safe_q = select(q_valid, log_q, zero);
  const auto safe_bonus = select(bonus_valid, log_bonus, zero);
  const auto selected = [&](Value logits) {
    return r.copy(r.reshape(r.one(c::Gather{.axis = 1}, {logits, proposal}), {fixed(1)}));
  };
  const auto raw_qy = selected(log_q);
  const auto proposal_valid = negate_bool(r.cast(
      r.binary(c::BinaryKind::kSubtract, raw_qy, raw_qy), Type::kBool));
  const auto qy = select(proposal_valid, raw_qy, zero);
  const auto log_accept = r.binary(c::BinaryKind::kMinimum,
      r.binary(c::BinaryKind::kSubtract, selected(safe_p), qy), zero);
  // log(1-exp(a)) = softplus(a) + log(tanh(-a/2)), a<=0.
  // It preserves both exact endpoints (a=0 and a=-Inf) without cancellation.
  const auto minus_half = r.scalar(-0.5F);
  const auto log_one_minus = [&](Value a) {
    return r.binary(c::BinaryKind::kAdd, r.unary(c::UnaryKind::kSoftplus, a),
        r.unary(c::UnaryKind::kLog, r.unary(c::UnaryKind::kTanh,
            r.binary(c::BinaryKind::kMultiply, a, minus_half))));
  };
  const auto log_reject = log_one_minus(log_accept);
  const auto accept_weights = r.one(c::Concat{.axis = 1}, {
      r.copy(r.reshape(log_accept, {fixed(1), fixed(1)})),
      r.copy(r.reshape(log_reject, {fixed(1), fixed(1)}))});
  const auto choice = r.one(c::sampling_ops::categorical(), {accept_weights, accept_identity});
  const auto accepted = negate_bool(r.cast(r.cast(choice, Type::kFloat32), Type::kBool));

  // Construct log(max(p-q,0)) directly. Subtracting rounded exp(lp)-exp(lq)
  // would erase real residual mass for adjacent F32 log values. Per-column
  // support masks also avoid eager (-Inf)-(-Inf) and permit q(i)==0 away from y.
  const auto finite = [&](Value value) {
    return negate_bool(r.cast(r.binary(c::BinaryKind::kSubtract, value, value), Type::kBool));
  };
  const auto p_support = finite(safe_p), q_support = finite(safe_q);
  const auto finite_p = select(p_support, safe_p, zero), finite_q = select(q_support, safe_q, zero);
  const auto positive_difference = r.cast(r.unary(c::UnaryKind::kRelu,
      r.binary(c::BinaryKind::kSubtract, finite_p, finite_q)), Type::kBool);
  const auto residual_support = both(p_support, either(negate_bool(q_support), positive_difference));
  const auto negative_infinity = r.scalar(-(std::numeric_limits<float>::infinity)());
  const auto gap = select(q_support, r.binary(c::BinaryKind::kMinimum,
      r.binary(c::BinaryKind::kSubtract, finite_q, finite_p), zero), negative_infinity);
  const auto log_residual = select(residual_support,
      r.binary(c::BinaryKind::kAdd, finite_p, log_one_minus(gap)), negative_infinity);
  const auto residual_positive = r.cast(sum(r.cast(residual_support, Type::kFloat32)), Type::kBool);
  const auto safe_residual = select(residual_positive, log_residual, safe_p);
  // Only the selected branch enters Categorical, so p==q never submits an
  // all--Inf residual row. The final draw is independent of the accept draw.
  const auto final_weights = select(accepted, safe_bonus, safe_residual);
  const auto final_id = r.one(c::sampling_ops::categorical(), {final_weights, final_identity});
  const auto valid = both(both(p_valid, q_valid), both(bonus_valid,
      both(proposal_valid, either(accepted, residual_positive))));
  return {accepted, final_id, valid, p_valid, q_valid, bonus_valid, proposal_valid, residual_positive};
}
} // namespace qwen35::sampling
