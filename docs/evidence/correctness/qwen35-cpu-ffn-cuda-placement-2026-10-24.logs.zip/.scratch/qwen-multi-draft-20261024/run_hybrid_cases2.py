from pathlib import Path
import os,json,subprocess,time,sys
R=Path.cwd();W=R/'.scratch/qwen-multi-draft-20261024';F=W/'hybrid-check2';E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check';exe=F/'recursive-probe.exe';ready=json.loads((E/'ready-cuda.json').read_text());env=dict(os.environ,PATH=str(F)+os.pathsep+ready['PATH']);inputs=R/'.scratch/qwen-mtp-window-20261022/inputs/mtp'
cases=[]
for label,mtp,k,mode,layers in [('ordinary-greedy','off',0,'greedy',2),('mtp-K1-greedy','on',1,'greedy',2),('mtp-K4-greedy','on',4,'greedy',2),('mtp-K4-random','on',4,'random',2),('gpu-only-default','off',0,'greedy',0)]:
 args=[str(exe),'--engine','--inputs',str(inputs),'--mtp',mtp,'--cpu-ffn-layers',str(layers),'--capacity','256','--steps','8','--prefix-cache','off','--sampling',mode,'--replay','commands']
 if mtp=='on':args+=['--mtp-max-drafts',str(k)]
 if mode=='random':args+=['--top-k','8','--seed','123']
 cases.append((label,args))
cases.append(('strict-and-failure',[str(exe),str(inputs)]))
schedule=F/'schedule';schedule.mkdir(exist_ok=True);(schedule/'prompt.ids').write_text((inputs/'prompt.ids').read_text());(schedule/'next.ids').write_text('16 8\n')
for who in ['a','b','c']:(schedule/(who+'.txt')).write_text('prompt prompt.ids\ngenerate 4\nprompt next.ids\ngenerate 4\n')
(schedule/'sessions.txt').write_text('a a.txt\nb b.txt\nc c.txt\n')
cases.append(('mtp-random-sessions',[str(exe),'--engine','--inputs',str(inputs),'--mtp','on','--mtp-max-drafts','4','--cpu-ffn-layers','2','--capacity','256','--session-schedules',str(schedule/'sessions.txt'),'--max-sessions','2','--active-sequences','2','--prefix-cache','off','--sampling','random','--top-k','8','--seed','123','--replay','commands']))
if len(sys.argv)>1:cases=[case for case in cases if case[0] in sys.argv[1:]]
summary=[]
for label,args in cases:
 folder=F/label;folder.mkdir(exist_ok=True);(folder/'command.json').write_text(json.dumps(args,indent=2)+'\n');print('START',label,flush=True);start=time.time()
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:p=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err,timeout=180)
 info=dict(exit=p.returncode,seconds=time.time()-start);(folder/'process.json').write_text(json.dumps(info,indent=2)+'\n');print('END',label,info,flush=True)
 if p.returncode:print((folder/'stderr.log').read_text(encoding='utf8',errors='replace')[-4000:],flush=True)
 else:
  parsed=[json.loads(line) for line in (folder/'stdout.log').read_text(encoding='utf8',errors='replace').splitlines() if line.startswith('{')];(folder/'parsed.json').write_text(json.dumps(parsed,indent=2)+'\n');print([(value.get('generated_ids'),value.get('backend'),value.get('original_host_weight_bytes'),value.get('cpu_ffn_layers')) for value in parsed],flush=True)
 summary.append(dict(case=label,**info))
 if p.returncode:break
(F/('summary-'+('-'.join(sys.argv[1:]) or 'all')+'.json')).write_text(json.dumps(summary,indent=2)+'\n');sys.exit(1 if any(value['exit'] for value in summary) else 0)
