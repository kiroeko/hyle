# 当前工作计划

更新：**2026-10-23**。进入“实际推理驱动的性能、功能与架构收敛”阶段。
范围仍是Windows／Linux／macOS的单机CPU、单GPU和CPU＋一张GPU；多模态限图片encoder／projector（mmproj）到文本。
Qwen3.5-2B是检验底座的真实测试消费者；架构还要承载其他已选模型、量化格式、算子和后端。

**当前优先级（用户2026-10-22确认）：先把MTP做完。** Qwen3.5-2B greedy K1主链、列明有限正确性检查及四臂性能对照已有；其它适用制品的原角色／codec和完整状态组合仍在补齐。多模态图片完整链路等前三项完成后开始，连续批处理调度扩展暂后置。

本轮MTP明确排除Kimi（用户2026-10-23确认）：已选原版及两主选GGUF均无原生MTP权重。Kimi普通推理、量化与通用算子支持仍在原范围内。

## 现在的位置

旧阶段8个能力包、3个交付包已完成各自列明范围，不代表架构已全量审完、全部模型已完整执行。现有冷编译、不可变计划、独立Invocation、状态版本、分页权限和真实CUDA文本推理基础，继续推进性能、功能与架构三条主线。
旧阶段见[归档](../evidence/planning/current-work-through-2026-10-21.md)；截至AY的数值调查、逐批回归及其限制见[本次归档](../evidence/planning/current-work-through-2026-10-22-ay.md)。源码、日志和数据保留在原证据中，不将历史实验自动重开为任务。

**最新完整性能仍是[页末AV四臂窗口](#最新完整性能对比)**：普通Hyle／llama.cpp prefill为2349.076／1553.955tok/s，decode99.764／105.224；MTP为2137.322／1499.623、123.162／139.532。普通共用成本和MTP增量分别调查，不能用总TPS判定MTP逻辑错误；本次原角色接线没有新TPS或显存数据。

## MTP当前剩项

**分开交付和报告：** Qwen3.5-2B完整消费者、其它模型／量化制品覆盖、最终性能收尾分别判断；局部尾部链不能代签完整模型，量化身份条目数也不代表独立执行器数量。不再用一个总百分比混合这三类进度；每批完成后在下表明确实际范围及剩项，只做受改动影响的必要检查，不追加全组合验证。

覆盖范围已按固定元数据整理为[有限制品清单](../evidence/research/mtp-artifact-scope-2026-10-23.json)：25个确认含MTP的精确身份中，9个已有原角色的有限状态实跑，16个原供给接线尚未完成；三项曾缺失的物理schema已补齐。两项GPTQ制品的MTP实际均为15个BF16角色，可归入已有BF16接线；Quark GLM Flash的完整1760角色仍需其明确的FP8量化策略。另列Flash主GGUF词表组合，不重复计draft身份。按实际schema复用已有加载、计算和状态流程，不为16个身份各建执行器；无MTP权重、待确认和已执行范围分开记录，不把身份数当开发完成率。

**最近已验证进展：** [同版本Flash主GGUF原Q8词表组合](../evidence/correctness/mtp-dspark-main-gguf-q8-vocabulary-2026-10-23.json)已通过CPU／CUDA各87次Graph，受影响的正式BF16 CUDA回归45次也通过，三项共219次。保留原Q8／MXFP4三层draft、原target40→41→42、全V六行verifier及30成员K5状态；两份新增原Q8词表共约1.13GB。此项完成已有S02的词表组合，不增加身份完成数，不代签整个主UD-Q4模型或TPS。

[正式DeepSeek Flash原FP8三层draft／原target40→41→42／全词表K5](../evidence/correctness/mtp-dspark-formal-flash-2026-10-23.json)已通过CPU／CUDA，共用命名源后的Pro CPU／CUDA回归也通过，四项180次Graph。Flash新增97角色约595MB，借用已有target／词表；实际专家按选中ID获取，无整库或重复词表副本。上游layer39输入及初始历史仍是fixture。

[Qwen官方BF16 Q27 target63／NextN／全词表K1](../evidence/correctness/mtp-qwen-bfloat-target-verifier-2026-10-23.json)已通过CPU／CUDA，连同受影响的原GGUF F32回归共四项92次Graph；原29角色约6.68GB，含接受0／1、实际target tap修复草稿KV和12资源同Head续算。首轮失败是检查器读取已释放冷常量，已改读实际参数租约，计算及容差未改；上游输入／初始历史仍是fixture。

此前[DeepSeek Pro原target58／59／60＋正式三层draft／全词表K5](../evidence/correctness/mtp-dspark-pro-target-verifier-2026-10-23.json)，CPU／CUDA各45次Graph通过，含30成员同Head接受、pending续算、旧读者、取消及有界回收；共享执行代码的Flash CPU／CUDA回归各87次Graph也通过，合计四项264次Graph。layer57输入和有限初始历史仍是fixture，不代签完整61层模型、任务质量、自然接受率或TPS。此前[GLM Pro target77→NextN78及原78回归](../evidence/correctness/mtp-glm-pro-target-verifier-2026-10-23.json)的四项140次Graph及其上游边界继续保留。

**本轮正在做：** Qwen原始BF16 MoE的33份静态原参数、共用K1／两phase及按需专家供给已接通。CPU／CUDA混合运行保持两原词表在host、主体／状态在CUDA，由普通Graph搬运；混合有限状态链已通过1项43次Graph提交，含接受／拒绝、草稿KV修复和12资源同Head续算；CPU路径已使用同一镜像开始检查，尚未报通过。已修消费者的闲置lane队列绑定、原BF16切片误标U8，以及供给的有界Early EOF续传；参考器仅补解析FTZ误差项，保留正常域原界。最新修复了公共Graph遗漏较早segment退休守卫、导致wait成功却无法发布结果的问题：[同一回归旧版本复现、新版本通过，4项退休检查全通过](../evidence/correctness/graph-segment-retirement-2026-10-23.json)。修复后的混合消费者已完成本次有限状态旅程。未下载整份约51.5GB专家bank，暂无新TPS。下一组Qwen GGUF的共享角色加载器、独立target词表、Q3_K参考及同一K1消费者补丁已离线准备；S01的18个原角色正在获取，尚未完整。DeepSeek BF16/MXFP4 sidecar的原81tensor头已核定，复用已有Q8词表，静态参数与按需专家供给待接；两组均未报新制品通过。

安全批宽属于Provider冷准备事实：超出通用表示／scratch资格界的大packed矩阵，当前非Orin NVIDIA的额外MMVQ放行域为1～4行，新多行须偶数N；原canonical／K%512／I32索引、encoded字节与stride界不变。本次Flash原Q8词表在通用界内，六行已实际通过，无需扩大上述门。Orin的大矩阵例外仍保持单行，其M2和更大批次的MMQ资格仍待补，不能由本机结果推断全设备支持。模型消费者无需知道该设备分支；真实target／完整verifier仍按下表推进。

Q27／Q24共用target attention、M2 head、K1状态流程及相应纯数学参考，模型各自保留dense／MoE、原参数和数值边界；未增加执行器、公共算子或模型白名单。[Q27验证链](../evidence/correctness/mtp-qwen27-target-verifier-2026-10-23.json)、[Q24验证链](../evidence/correctness/mtp-qwen24-target-verifier-2026-10-23.json)、[packed M2](../evidence/correctness/mtp-packed-head-m2-2026-10-23.json)与[GLM Pro原NextN](../evidence/correctness/mtp-glm-pro-nextn-2026-10-23.json)的实际范围保留在原证据中。

| 模型／制品 | 已验证的实际范围 | 仍需完成 |
| --- | --- | --- |
| Qwen3.5-2B BF16 | 原335权重的greedy K1，含多会话／多轮／B2、完整前缀、有界重建和列明三平台取消／退休／预算恢复；[8项QKV差异](../evidence/correctness/qwen-mtp-quality-prefix-2026-10-22.json)指向普通单／双行稳定浮点差异 | 最终普通／MTP性能复测与热点；不将有限数值检查外推为所有形状或任务质量 |
| Q27主UD-Q4_K_M | [原17角色](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)完整NextN／全V词表；本轮加原target63／global norm、实际tap的M2 verifier、接受0／1与target-conditioned草稿缓存修复，12资源同Head续算，CPU／CUDA通过 | 其它已确认量化及必要后端；完整上游主干／初始历史仍保边界 |
| Q27官方BF16 | [原29角色target63／NextN／两原词表](../evidence/correctness/mtp-qwen-bfloat-target-verifier-2026-10-23.json)，保原BF16 store／delta norm，实际M2全V及12资源K1接受修复／续算，CPU／CUDA通过 | 同组其它制品；上游layer62输入及初始历史仍保边界 |
| Q24主UD-IQ4_XS | [原22角色](../evidence/correctness/mtp-q24-original-nextn-2026-10-23.json)完整NextN／两原词表；本轮加原target91／global norm、真实512域Top10 IQ4_XS专家、M2 verifier及接受后缓存修复，12资源同Head续算，CPU／CUDA通过 | 其它已确认量化及必要后端；完整上游主干／初始历史仍保边界 |
| GLM Flash官方 | [完整原NextN1762角色](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)，以及[独立原43→44→NextN](../evidence/correctness/mtp-glm-original-target43-2026-10-23.json)、原全V双行验证、真实pending和34资源＋Epoch的K1接受／续算 | 其它适用producer／verifier、已确认量化；layer42输入与有限初始历史仍是fixture |
| GLM Pro官方 | [真实原target77→NextN78](../evidence/correctness/mtp-glm-pro-target-verifier-2026-10-23.json)、独立model.norm与全V反馈，14资源＋Epoch的接受修复／index追赶／续算，CPU／CUDA通过；原78回归也通过 | 其它已确认量化和必要后端；上游74选择、layer76输入及初始历史仍保边界 |
| 正式DeepSeek V4 Pro | [原58→59→60＋正式三层draft](../evidence/correctness/mtp-dspark-pro-target-verifier-2026-10-23.json)，216静态／词表角色、实际选中384域原专家、全V K5及30成员完整状态接受／pending续算，CPU／CUDA通过 | 其它适用制品；layer57输入及初始历史仍保边界 |
| 正式DeepSeek V4 Flash | [原40→41→42＋正式原FP8三层draft](../evidence/correctness/mtp-dspark-formal-flash-2026-10-23.json)、独立末端HC／norm、原全V K5及30成员接受／pending续算，CPU／CUDA通过；[S02同版本主UD-Q4原Q8词表组合](../evidence/correctness/mtp-dspark-main-gguf-q8-vocabulary-2026-10-23.json)CPU／CUDA也通过 | 其它适用制品；上游layer39输入／初始历史仍保边界 |
| Kimi原版及两主选GGUF | 原版NextN层数为0；Unsloth固定版本的UD-Q4_K_XL／UD-Q8_K_XL已分别清点完整2573个tensor，均无MTP／NextN角色，仓库文件清单也无独立draft／MTP制品；见[制品清单](../evidence/research/mtp-artifact-scope-2026-10-23.json) | 这三个固定制品均无原生MTP接线任务，普通推理的量化／算子支持仍在范围内；不外推其它版本 |

**接下来的顺序：**

1. 接通Qwen MoE原始BF16的真实静态角色及按需专家供给，复用已通过的dense BF16输入／词表和同一K1状态流程。
2. 按有限清单的6组实现schema补其它已确认MTP制品／量化接线；正式Flash组已完成；原元数据组已查清并入BF16组。复用实际可共用的数学／供给／状态，不为每种制品复制执行器。
3. 按新制品继续核权重／状态组合。Qwen GGUF专家codec／stride和K1重复接线本轮已收敛；Orin／更大批次的packed MMQ能力继续保留为明确剩项。
4. 做必要回归、普通／MTP完整性能对照与实测热点处理，之后进入图片完整链路。

动态E4 codes＋F32 scales已有四端逐bit、失败恢复与寿命检查；indexer采用PowerOfTwo／floor1e-4，原MLA／MoE采用Divide／floor1e-10。CUDA公共I32→F32 Cast边界、状态、页权限、只读租约、预算和原子发布继续共用，范围见[总表](../implementation/model-operators.md)。未执行的模型、系统、codec或完整质量不写成通过；角色数不作为完成百分比，页末AV仍是最新完整性能窗口。


## 执行顺序与近期进度

| 顺序 | 工作 | 状态与下一动作 |
| --- | --- | --- |
| 1 | 容量参数与初始化 | 消费者已接上下文、缓存会话数、活跃序列数与状态字节预算，支持auto和提前拒绝；状态预算不冒充全显存上限 |
| 2 | 多会话缓存与执行 | Radix／LRU、COW／独占尾权、共享执行资源、完全命中、有界恢复及真实B2已接。三平台有限完整前缀、取消／退休及额度恢复已有；跨形状数值／质量、实际性能和其它模型状态组合仍按真实范围推进 |
| 3 | MTP | 当前优先；Q27／Q24、GLM Pro／Flash及正式DeepSeek Flash的列明原target／draft／全V verifier、接受后续算已有CPU／CUDA检查。继续Qwen MoE原BF16及已确认量化／sidecar，最后完整性能对照；详细边界见上表 |
| 4 | 图片encoder／projector | 等前三项完成后开完整链路；已有297个BF16视觉张量、24层H1024 encoder及4096→4096→2048 merger身份。后续RGB／patch→视觉Graph→文本embedding、多轴位置／delta、图片前缀身份与寿命；原LayerNorm weight＋bias |
| 并行 | 已知性能慢项 | 普通／MTP decode差距、descriptor上传依赖、随历史增长的页组织、cached-prefill首用与合法拓扑变化继续按实际热点处理，见[性能计划](performance/decode.md) |
| 贯穿 | 架构审查与实现收敛 | 保性能、职责、数值及寿命正确；检查其它已选模型／算子／后端，普通扩展不反复修改共同调度核心 |

用户顺序仍是多会话缓存／推理→MTP→图片；当前先收MTP已有明确剩项。单请求延迟、多人总吞吐、缓存命中和重建成本分别报告，不把一次CUDA结果外推到全部系统／制品，也不把完整KV以外状态丢掉后宣称可任意截断前缀。

**连续批处理调度扩展后置。** 参考llama-server可在线接纳新请求、按token预算混合兼容prompt／decode；当前消费者采用预定wave及T／role／lag桶。引擎负责调度政策，底座仍需承载可变活跃子集、变长计算、完整状态与有界资源复用；当前MTP任务不扩建server或新增多执行器。

## 性能：借鉴成熟实现，落到真实瓶颈

已有[本地7个引擎的优化研究](../evidence/research/local-inference-optimization-2026-10-21.json)，包括TensorRT-LLM、vLLM、SGLang、llama.cpp、ik_llama.cpp、DeepInfer和ds4；其他既有研究由旧计划保留链接。
先查当前准备／重录成本，再试实际热点的少量合法冷算法；量化链再检查保原舍入的融合、packed分块计算及多余转换／搬运。
匹配完整数学、设备和工作量后才采用。量化路线的改进不自动算成BF16 Qwen收益，源码启发也不算实测收益。

最新完整对比固定放在本页末尾；阶段归因与实验决策见[性能计划](performance/decode.md#三轮共享缓存的四项基线2026-10-21)。
此前约22%改善属于一次cached16输入续算，不是整体decode提升。

每次完整对比固定报告**prefill、完整decode、显存变化、多轮综合速度**；加载／冷准备与热执行分列，
测速和显存旁采分开，保同输入、精度、缓存、状态、完成与计时边界，见[统一口径](performance/README.md#推理对比固定报告)。
先排除工作量不等价和测量分辨率，再优化时间复杂度、显存复杂度与实际常数成本。

## 功能：引擎表达意图，底座承载机制

[容量参数研究](../evidence/research/engine-capacity-2026-10-21.json)提出下面四种主要意图，现已在[测试消费者](../../tools/qwen35_text/README.md)提供相应参数及auto解析；它们不是Hyle库要求用户手填的内部字段。

| 用户可表达的意图 | 必须分清的含义 |
| --- | --- |
| 单序列上下文上限 | 一条序列的历史容量，不等于物理KV池 |
| 缓存会话数 | 保留的活跃＋空闲会话，不等于同时执行数 |
| 同时执行序列数 | 正在调度的序列并发，不等于执行槽或用户总数 |
| 缓存字节预算 | 各层KV、conv／GDN、分支写入及保留版本总成本，不等于全进程显存 |

总内存预算可选；步长、执行槽数和常用准备形状通常自动推导。启动报告实际容量、已准备域、已知／未知资源和超限行为。
参数支持预分配与准入，不能承诺固定tokens/s或控制驱动／其他进程的显存。
当前测试消费者按turn接纳活跃请求，空闲会话可按数量或状态字节限制淘汰；再使用时按原输入chunk重建完整状态。默认auto按本次输入与预算解析，没有固定的用户数要求。
上限不预先分配对应数量的会话，单用户decode直达自己的Session，不逐token查询LRU／预算。单序列冷准备由同时执行数表达，不把缓存数量限制误当加速开关。
缓存必须同时受会话数和字节预算约束；共享物理页只计一次，conv／GDN、COW暂存、旧版本和待退休页仍计实际占用，不能把移出目录当作显存已释放。
当前Qwen将12份arena backing及36份状态池统一预留、计费一次，包含最多R份批次候选版本与COW尾页；不再用旧dense每会话公式计算。容量256、R1保留1／2会话时分别预留42,418,224／65,101,872字节，N2／R2为84,836,400字节；IO、workspace与未知原生私有存储另计。保留旧前缀也消耗版本／页额度，缓存数量限制不是无界检查点许可。
先由引擎按最久未使用顺序淘汰空闲缓存；全部在用或在途退休后仍无空间时排队或拒绝，不覆盖活跃状态。Hyle提供预算与真实退休后的安全回收，不承担用户目录和淘汰策略。淘汰设备缓存不等于删除对话记录；重建所需token等输入由引擎保留。
用户的单台DGX Spark四人编码服务属于未来模型选型场景；当前开发验证继续使用已有验证机器。多会话机制支持可配置容量，缓存会话数另计；服务评估需看总吞吐、每路速度、首token和延迟分布，不由单请求速度相乘推算。

- **多会话缓存**：共享只读权重／计划，隔离完整KV、conv／GDN和位置状态；精确前缀匹配、只读共享、显式写时复制，取消／淘汰后仍保护在途与旧读者。
  会话目录、准入／淘汰和批次策略归引擎；状态、页权限、预准备、独立执行槽与退休归Hyle。不能按会话复制整份模型冒充复用，也不以仅有多序列布局算完成。
- **MTP**：模型格式、tokenizer、draft／verify及接受策略归消费者；Hyle提供计算、完整状态、页权限、搬运和真实退休。Qwen当前目标T2与草拟缓存沿同次Graph／Completion，逐成员选择接受边界后原子发布；已消费前缀、fresh预测与未消费pending分开保存。当前剩项见[上表](#mtp当前剩项)，长期合同见[生成记录与缓存重算](../architecture/compute-design.md#生成记录与缓存重算)。
- **图片投影**：预处理和模型图片语义归消费者；Hyle补真实计算、布局、特征与文本绑定、搬运及资源寿命。先做图片，不扩展音频／视频。

既有自然轮次、EOS、取消／丢Completion、B2与有界重建、独立CPU／peer对照和数值调查保留在[AY前归档](../evidence/planning/current-work-through-2026-10-22-ay.md)及其原证据。已确认的完整状态、预算和退休能力继续复用；不同形状浮点差异、未验证的质量或物理资源峰不写成通过。

## 架构审查：性能成立，边界清楚，修改集中

审查目标是**实现是否满足这些边界**，不是再造一套抽象或统一所有原生执行细节。
共同点依据实际计算提取，允许后端保有原生算法、融合、布局和资源；引擎中间层不判断具体Provider／原生算子。

| 审查面 | 要确认并修复的内容 |
| --- | --- |
| 职责与扩展成本 | 模型表达数学／状态，Compute承载算子合同，Provider实现计算，Graph负责计划与依赖；新增算子／融合／后端不反复改共同调度、租约和提交核心，新模型尽量复用已有能力 |
| 冷规划与热执行 | 选路、融合、packing、容量和常见形状尽量冷生成；明确布局变化何时使原计划失效，只有实际依赖变化才重准备，避免隐藏搜索、重复分配／转换／同步 |
| 数值与布局合同 | dtype、量化与scale、累积／舍入、stride、alias、状态副作用可明确描述；融合覆盖真实DAG及读者，跨Provider边界明确import／copy与代价 |
| 不可变共享与可变隔离 | 代码／权重／常量可共享；Invocation、workspace、绑定和会话状态按实际并发要求隔离；分支、批次、旧结果不会相互覆盖 |
| 状态与异步寿命 | KV、recurrent／conv、位置和接受前缀属于完整续算状态；发布、失败、取消、关闭与真实native退休一致，旧版本、结果和设备在途使用都有owner |
| 资源与调度 | 冷／热内存、页池、执行槽、搬运和准备成本可解释；超限行为明确，未知私有内存不记零；混合CPU＋GPU不复制一套执行器，放置／同步按实际依赖处理 |
| 公共接口与可维护性 | 跨系统／设备调用形状一致，错误可定位到层和阶段；普通引擎调用不要求第三方类型、内部宏／Provider开关，明确的原生互操作入口保留；模块可独立升级，支持范围和实现保持一致 |

同时检查Direct与Graph共用合同、依赖和模块方向、缓存／制品身份及失效、能力发现与合法后备，避免隐式全局可变状态和第二套执行路径。
能力声明、路由与支持表应复用事实，减少重复名单和接线；设备或后端的真实限制在准备期说明，不强行抹平差异。
不追求“加算子零改动”：新语义可能需要新公共合同；普通扩展应集中在自己的实现和必要声明，新语义才修改共同合同。
用真实变更检验维护成本：换一个Provider实现、增加一种精度／融合、接入一种不同状态的模型，看改动是否局限于所属层，并检查完整推理速度与资源成本。
接线暴露的架构问题随当前任务逐步修复：Flash／Pro共用普通Graph执行与MoE几何／供给，Qwen共用attention和K1状态流程，专家上传按实际codec／stride派生布局，大packed head安全批宽归Provider冷准备。目标tap、递归草稿hidden及缓存补算的时序属于模型消费者，状态层只承载完整版本；数学参考与执行也分开。继续用其它正式制品核权重绑定和状态组合，保留模型数学与数值边界，持续推进MTP收尾。
长期设计依据在[Compute](../architecture/compute-design.md)和[Graph](../architecture/graph-design.md)；已选模型／量化／角色／融合范围以[总表](../implementation/model-operators.md)为准，原制品未完整执行的条目继续如实标记。

## 工作方式

沿现有公共执行链补缺口，删除重复旧路径，不保兼容分支；不恢复治理、资格或审批流程。
只运行与改动相关的增量构建、数值／状态／寿命检查与真实消费者，复用三平台工具链、依赖和对象缓存，不因计划更新重跑全库。
保留必要源码、命令、失败和结果到[证据目录](../evidence/README.md)；新阶段是否完成按上述实际剩余工作判断，不按旧清单完成数推算总进度。

## 最新完整性能对比

**2026-10-22，MTP消费者接线与共用能力补齐后的完整四臂窗口（AV）。** 北京时间18:15:19～18:15:52；Qwen3.5-2B、RTX 4070、全CUDA、BF16权重，相同P154提示词、自然greedy输出64枚、C1024／N1／R1、前缀关闭、replay auto。每臂3个新进程交错测速，共12次；另各1个独立进程旁采内存，共4次。各臂沿用AU相应模型数学、权重与自然工作；历史窗口不合并。

| 当前模式 | prefill tok/s | 完整decode tok/s | 综合输出 tok/s |
| --- | ---: | ---: | ---: |
| Hyle普通 | 2349.076 | 99.764 | 91.816 |
| Hyle MTP K1 | 2137.322 | 123.162 | 109.669 |
| llama.cpp普通 | 1553.955 | 105.224 | 91.713 |
| llama.cpp MTP K1 | 1499.623 | 139.532 | 115.482 |

普通版Hyle相对参考prefill +51.17%，decode -5.19%，综合 +0.11%；MTP分别 +42.52%／-11.73%／-5.03%。综合为64输出／（完整prefill＋decode），不含加载；本窗单轮，不冒充多轮或多人吞吐。

| 当前模式 | prefill范围 tok/s | decode范围 tok/s | 综合范围 tok/s | 加载s | 入口至ready s | 入口至末输出s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Hyle普通 | 2079.09～2407.99 | 99.24～100.37 | 90.28～92.54 | 0.841 | 1.187 | 1.884 |
| Hyle MTP K1 | 2049.64～2207.36 | 116.90～123.31 | 104.22～110.22 | 0.891 | 1.671 | 2.252 |
| llama.cpp普通 | 1545.17～1637.81 | 103.57～105.94 | 90.40～92.93 | 1.555 | 1.584 | 2.282 |
| llama.cpp MTP K1 | 1498.01～1508.31 | 135.85～139.91 | 112.97～115.86 | 1.672 | 1.706 | 2.260 |

速度为3个独立进程比率的中位数并保留最小～最大范围，加载／ready／末输出也各取进程中位数；样本少，不作显著性结论。decode计prefill后63枚新输出的完整host端点，包含准备／捕获／等待／结果处理。加载边界依消费者实现；入口不含OS装载DLL，末输出不含销毁，不将其称为同一加载算法的胜负。

| 当前模式 | GPU dedicated峰 GiB | GPU shared峰 MiB | 同采样GPU总峰 GiB | CPU WS峰 GiB | CPU private commit峰 GiB |
| --- | ---: | ---: | ---: | ---: | ---: |
| Hyle普通 | 3.888 | 92.00 | 3.964 | 1.052 | 5.510 |
| Hyle MTP K1 | 4.048 | 92.00 | 4.124 | 1.142 | 5.784 |
| llama.cpp普通 | 3.728 | 82.00 | 3.808 | 4.071 | 4.673 |
| llama.cpp MTP K1 | 3.896 | 94.00 | 3.987 | 4.220 | 5.081 |

内存是独立Windows PSAPI／PDH旁采观测峰，非精确物理分配或TPS样本。dedicated与shared分列峰不可直接相加，总峰只在同一有效采样点相加；WS／commit／GPU shared也非互斥量。请求间隔10ms，实际间隔中位15.1～15.2ms、最大21.1ms；短prefill只有6～9个样本，ready基线无样本仍为null，GPU无实例时也不填零。四臂GPU采样峰与AU完全相同，不把它当精确分配不变的证明。

**实际工作与可比边界：** 各臂3次输出ID、实际工作及非计时轮次决策均稳定，与AU对应臂保持一致；全部输出64枚，未触发EOS。普通均计算154行prefill＋63行decode。Hyle MTP为34轮、29次接受（85.29%），验证68行、draft decode 62行；peer为33轮、30次接受（90.91%），验证66行、draft decode同为62行，两者最终提交decode均63行。两边MTP prefill各有154行target／draft，但Hyle只算所需draft K/V，peer走原完整MTP块。两对续文仍从第19枚起不同；Hyle中间BF16、末分数F32，peer原生算术／状态／host carry也不同，报告自然性能，不称同token或数学完全一致。

**窗口变化与性能主线：** AU已将普通／MTP decode恢复到91.44／112.29；本窗为99.764／123.162，但peer也从95.08／125.65升到105.224／139.532。两边都更快，不能把Hyle约9%的变化归因为本批优化收益。普通共用路径相对参考的差距继续按实际热点处理，与Qwen K1已列明的MTP状态／接受逻辑检查区分；其它适用MTP制品仍未完成。

**[AV共用能力与检查](../evidence/correctness/mtp-consumer-wiring-2026-10-22.json)：** 输入租约候选表仅在真实native输入需要时构造，原F1权限、alias、seal及退休门不变；F32 Add按实际标量carrier补4B对齐声明，保留V17夹具。owned alias与候选不相容时提前冷拒，保合法后续选路；29项相关回归0失败／0跳过。

[本轮12次计时、4次独立内存旁采及实际命令／结果](../evidence/performance/qwen-mtp-assembly-2026-10-22.json)。[AU有界捕获变体](../evidence/performance/qwen-capture-variants-2026-10-22.json)保留包含active在内的两变体、实际prepared资格与完整tuple／失效门，以及24项检查和15次Graph／534项向量回归；[AT诊断](../evidence/performance/qwen-capture-recording-cost-2026-10-22.json)、[AS可执行更新](../evidence/performance/qwen-capture-rebuild-2026-10-22.json)、[AR单槽回退](../evidence/performance/qwen-mtp-current-carrier-2026-10-22.json)、[AF单槽前窗口](../evidence/performance/qwen-mtp-steady-profile-2026-10-22.json)保留各自历史口径，不混算。
