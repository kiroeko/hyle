"""B05 source configuration for the existing owned-process supply driver."""
import importlib.util
from pathlib import Path
import sys

S = Path(__file__).resolve().parent
R = S.parents[2]
DRIVER = R / '.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'


def main():
    spec = importlib.util.spec_from_file_location('_hyle_b05_supply_driver', DRIVER)
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing native supply driver was not found')
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.S, driver.R = S, R
    driver.DOMAIN, driver.SECTIONS = 512, ('nextn', 'target91')
    driver.WAIT_ENV = 'HYLE_QWEN_BFLOAT_WAIT_FOR_EXPERTS'
    driver.FRONTIER_ENV = 'HYLE_QWEN_BFLOAT_FRONTIER_FILE'
    return driver.main()


if __name__ == '__main__':
    sys.exit(main())
