"""Root-only acquisition of the33 declared B05 loose original BF16 roles.

The common checked-plan, Range downloader, authenticated recovery, single-writer
lock and filtered manifests are reused unchanged. Only the fixed source facts
are configured here. Full expert banks are not part of the static plan.
Apply fetch-roles-parameters.patch to the common helper before invoking main().
"""
import importlib.util
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[2]
REPO = 'Qwen/Qwen3.8-2.4T-A95B'
REV = '207bd685a7e3696cfaff12ded7c6a7ea0f88c996'


def configured_helper():
    spec = importlib.util.spec_from_file_location('_hyle_b05_bfloat_roles', S.parent / 'fetch_roles.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing common loose-role acquisition helper was not found')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    if not all(hasattr(helper, field) for field in ('ARTIFACT_DIR', 'TARGET_SECTION', 'NEXTN_COUNT', 'TARGET_COUNT')):
        raise RuntimeError('Apply B05/fetch-roles-parameters.patch to the common helper first')
    helper.ARTIFACT_DIR, helper.R = S, R
    helper.REPO, helper.REV = REPO, REV
    helper.COUNT, helper.BODY = 33, 10301376512
    helper.TARGET_SECTION = 'target91'
    helper.NEXTN_COUNT, helper.TARGET_COUNT = 19, 14
    helper.__doc__ = __doc__
    return helper


def main():
    configured_helper().main()


if __name__ == '__main__':
    main()
