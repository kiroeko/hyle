"""Publish only completed B05 CPU and mixed-placement K1 runs.

Root runs this AFTER successful native results and documentation updates:
  python B05/publish.py --runs N M --current-compile C
Each run keeps its own image/link/source identity. This script never downloads,
builds, executes a model, hashes weight bodies, or counts failed attempts as pass.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
Q, R = S.parent, S.parents[2]
CA = R / '.scratch/dspark-pro-target-draft-20261023'
spec = importlib.util.spec_from_file_location('qb_publisher', Q / 'publish.py')
qb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qb)
shared = qb.shared
read, identity, verify, add = shared.read, shared.identity, shared.verify, shared.add
resolve, number, successful = shared.resolve, shared.number, shared.successful
shared.TEXT |= {'.patch', '.tsv', '.cu', '.cuh', '.inl', '.inc', '.def'}
REPO = 'Qwen/Qwen3.8-2.4T-A95B'
REV = '207bd685a7e3696cfaff12ded7c6a7ea0f88c996'
MANIFEST = 'abc95f30f8c549e0e7f6bbc47e94aa1c42bc3cf221d98703efbf9ff3ee365f09'
EXPERT_PLAN = '7fea129068439f515d38f44f93c944ccf8b526ee8a91f88d297954a43b7f8c51'
SUFFIX = 'Q24OriginalBFloatTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'
EXPECTED = {'Cpu' + SUFFIX, 'Mixed' + SUFFIX}
PRIOR = R / 'docs/evidence/correctness/mtp-qwen-bfloat-target-verifier-2026-10-23.json'
RETIREMENT = R / 'docs/evidence/correctness/graph-segment-retirement-2026-10-23.json'
extra = {}  # Only small historical source entries recovered from prior evidence.


def retain(folder):
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix.lower() in shared.TEXT and path.stat().st_size < 10_000_000:
            add(path)


def requests(receipt):
    for row in receipt['requests']:
        if row.get('complete'):
            assert row['http_status'] == 206
            assert row['bytes'] == row['requested_bytes'] == row['last'] - row['first'] + 1
            assert row['content_range'].startswith(f"bytes {row['first']}-{row['last']}/")
            assert re.fullmatch('[0-9a-f]{64}', row['sha256'])


def static_roles():
    folder = S / 'original-roles'
    manifest_path, receipt_path = add(folder / 'manifest.json'), add(folder / 'acquisition.json')
    manifest, receipt = read(manifest_path), read(receipt_path)
    assert identity(manifest_path)['sha256'] == MANIFEST
    assert manifest['complete'] is receipt['complete'] is True
    assert (manifest['repository'], manifest['revision'], manifest['original_roles'], manifest['source_bytes']) == (REPO, REV, 33, 10301376512)
    assert (receipt['repository'], receipt['revision'], receipt['original_roles']) == (REPO, REV, 33)
    assert receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == 10301376512
    assert receipt['whole_shard_downloaded'] is False
    plan_path = add(receipt['source_plan'])
    assert identity(plan_path)['sha256'] == receipt['source_plan_sha256']
    plan = read(plan_path)
    assert (plan['repository'], plan['revision'], plan['original_roles'], plan['source_bytes']) == (REPO, REV, 33, 10301376512)
    headers = []
    for shard in plan['shards']:
        raw = add(verify(shard['header'])).read_bytes()
        assert shard['data_base'] == len(raw) + 8
        assert shard['url'] == f"https://huggingface.co/{REPO}/resolve/{REV}/{shard['file']}"
        headers.append(json.loads(raw))
    by_name = {row['name']:row for row in manifest['roles']}
    assert len(by_name) == len(plan['roles']) == len(receipt['roles']) == 33
    for planned, actual in zip(plan['roles'], receipt['roles'], strict=True):
        item = by_name[planned['name']]
        for key in ('name', 'section', 'dtype', 'shape', 'filename', 'source_shard', 'bytes',
                    'data_relative_half_open', 'absolute_inclusive'):
            assert actual[key] == planned[key], (planned['name'], key)
        assert item['dtype'] == planned['dtype'] == 'BF16' and actual['complete']
        assert (item['file'], item['shape'], item['bytes']) == (planned['filename'], planned['shape'], planned['bytes'])
        payload = actual['payload']
        assert payload['bytes'] == planned['bytes'] and payload['sha256'] == item['sha256']
        assert resolve(payload['path']) == folder / item['file']
        assert resolve(payload['path']).stat().st_size == planned['bytes']  # Never open/hash body.
        shard = plan['shards'][planned['source_shard']]
        header = headers[planned['source_shard']][planned['name']]
        assert (header['dtype'], header['shape'], header['data_offsets']) == ('BF16', planned['shape'], planned['data_relative_half_open'])
        first, end = header['data_offsets']
        assert end-first == planned['bytes'] and planned['absolute_inclusive'] == [shard['data_base']+first, shard['data_base']+end-1]
        offset = 0
        for chunk in actual['chunks']:
            assert chunk['offset'] == offset and 0 < chunk['bytes'] <= 128*1024*1024
            assert chunk['absolute_range_inclusive'] == [planned['absolute_inclusive'][0]+offset,
                planned['absolute_inclusive'][0]+offset+chunk['bytes']-1]
            assert re.fullmatch('[0-9a-f]{64}', chunk['sha256'])
            offset += chunk['bytes']
        assert offset == planned['bytes']
    requests(receipt)
    source = add(R / 'tests/compute_models/qwen_bfloat_q24_artifacts.h').read_text(encoding='utf-8-sig')
    assert MANIFEST in source and all(row['sha256'] in source for row in manifest['roles'])
    for name in ('model.embed_tokens.weight', 'lm_head.weight'):
        assert by_name[name]['shape'] == [248320, 8192] and by_name[name]['bytes'] == 4068474880
    assert sum(row['bytes'] for row in plan['roles'] if row['section']=='target91') == 947979264
    return dict(repository=REPO, revision=REV, manifest=identity(manifest_path), acquisition=identity(receipt_path),
                plan=identity(plan_path), static_roles=33, static_bytes=10301376512,
                vocabulary_bytes=8136949760, body_rehashed=False, body_archived=False)


def expert_cache():
    plan_path = add(S / 'expert-source-plan.json')
    assert identity(plan_path)['sha256'] == EXPERT_PLAN
    plan = read(plan_path)
    assert (plan['repository'], plan['revision'], plan['original_roles']) == (REPO, REV, 4)
    result = []
    for ready_path in sorted((S / 'original-experts').glob('*/expert*/ready.json')):
        ready = read(add(ready_path))
        assert ready['complete'] is True and ready['source_plan_sha256'] == EXPERT_PLAN
        section, globals_ = ready['section'], ready['globals']
        assert section in ('nextn', 'target91') and len(globals_) == 1 and globals_[0] in range(512)
        gid = globals_[0]
        folder = S / 'original-experts' / section / f'expert{gid:03d}'
        assert folder == ready_path.parent == resolve(ready['directory'])
        catalogue = add(folder / 'catalog.tsv')
        assert identity(catalogue)['sha256'] == ready['catalog']['sha256']
        assert catalogue.stat().st_size == ready['catalog']['bytes'] and ready['catalog']['file'] == 'catalog.tsv'
        lines = catalogue.read_bytes().decode('utf8').splitlines()
        assert lines[0].split('\t') == ['HYQBF001', section, EXPERT_PLAN, '1'] and len(lines)==2
        fields = lines[1].split('\t')
        assert len(fields)==4 and fields[0]==str(gid)
        receipt_path = add(verify(ready['acquisition']))
        assert receipt_path == folder / 'acquisition.json'
        receipt = read(receipt_path)
        assert receipt['complete'] is True and receipt['source_plan_sha256']==EXPERT_PLAN
        assert (receipt['section'], receipt['globals'], receipt['original_roles']) == (section, [gid], 3)
        assert receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == 100663296
        assert receipt['whole_shard_downloaded'] is False
        planned = read(add(verify(receipt['acquisition_plan'])))
        assert planned['section']==section and planned['globals']==[gid] and planned['source_plan_sha256']==EXPERT_PLAN
        assert len(planned['roles'])==len(receipt['roles'])==3
        for index, (role, acquired) in enumerate(zip(planned['roles'], receipt['roles'], strict=True)):
            leg = ('gate', 'up', 'down')[index]
            assert acquired['complete'] and role['leg']==leg and role['global_id']==gid
            assert role['bytes']==33554432 and role['dtype']=='BF16'
            physical = next(item for item in plan['roles'] if item['name']==role['source_name'])
            assert physical['section']==section and physical['source_file']==role['source_file']
            leg_spec = next(item for item in physical['selected_slices']['legs'] if item['leg']==leg)
            first = physical['absolute_inclusive'][0]+gid*physical['selected_slices']['expert_stride_bytes']+leg_spec['expert_relative_offset']
            assert role['absolute_inclusive']==[first,first+leg_spec['plane_bytes']-1]
            assert acquired['payload']['bytes']==role['bytes']==leg_spec['plane_bytes']
            assert acquired['absolute_inclusive']==role['absolute_inclusive']
            assert acquired['payload']['sha256']==fields[index+1]
            assert re.fullmatch('[0-9a-f]{64}', fields[index+1])
            body = resolve(acquired['payload']['path'])
            assert body == folder / f'expert-{gid:03d}-{leg}.bf16' and body.stat().st_size==33554432
        requests(receipt)
        retain(folder)  # Text only, not the three BF16 planes.
        result.append(dict(section=section, global_id=gid, original_plane_bytes=100663296,
            catalogue=identity(catalogue), acquisition=identity(receipt_path), planes=[row['payload'] for row in receipt['roles']]))
    assert result and {row['section'] for row in result}=={'nextn','target91'}
    return dict(source_plan=identity(plan_path), acquired_sets=result, acquired_plane_bytes=len(result)*100663296,
                scope='Authenticated cached original selected planes; not every cached ID is claimed to execute in every successful run.',
                full_512_banks_downloaded=False, body_rehashed=False, body_archived=False)


def source_snapshot(row, folder):
    """Match each historical input by its recorded bytes/SHA, not live equality."""
    original = resolve(row['path'])
    if not original.is_relative_to(R):
        return dict(original=row, external_dependency=True)  # Existing SDK identity is recorded, not copied.
    relative = original.relative_to(R)
    candidates = [folder / 'source' / relative, folder / original.name, original,
                  S / 'retry' / (original.stem+'-before'+original.suffix)]
    for path in candidates:
        if path.is_file() and path.stat().st_size==row['bytes'] and identity(path)['sha256']==row['sha256']:
            add(path)
            return dict(original=row, archived_source=identity(path))
    # Older unchanged B02 source proof may be the only remaining historical
    # copy (notably the pre-FTZ reference). Recover just the exact small entry.
    prior = read(PRIOR)
    archive = resolve(prior['archive']['path'])
    if archive.is_file():
        with zipfile.ZipFile(archive) as zipped:
            name = relative.as_posix()
            if name in zipped.namelist() and zipped.getinfo(name).file_size==row['bytes']:
                raw = zipped.read(name)
                if hashlib.sha256(raw).hexdigest()==row['sha256']:
                    key = f'historical-source/{row["sha256"][:16]}/{name}'
                    extra[key]=raw
                    return dict(original=row, archived_entry=key, prior_evidence=identity(PRIOR))
    raise AssertionError(f'Missing exact historical source snapshot: {row}')


def linked(image, record_identity):
    folder = resolve(image['path']).parent
    ready = read(add(folder / 'ready.json'))
    assert ready['image']==image and ready['source_record']==record_identity
    verify(image)
    successful(folder / 'link.result.json')
    plan = read(add(folder / 'link-plan.json'))
    runtime = read(add(folder / 'runtime-environment.json'))
    assert plan['host_translation_units']>=1
    assert all(plan[k]==0 for k in ('SDK_builds','native_CPU_builds','NVCC_builds','shaders'))
    host = add(verify(record_identity))
    successful(host.with_name('compile.result.json'))
    record = read(host)
    assert record['object'] in plan['inputs']
    verify(record['object'])
    sources = [source_snapshot(row,host.parent) for row in (record['source'],*record['dependencies'])]
    product_sources = []
    for item in plan['compiled_records']:
        record_path = add(verify(item))
        product = read(record_path)
        source = resolve(product['source']['path'])
        # New Graph retirement/capacity fixes are ordinary host TUs. Retain
        # their actual inputs when this link uses that source revision; older
        # product records stay separate rather than pretending live equality.
        if source in (R / 'src/graph/executable.cc', R / 'src/graph/submission.cc') and (
                source.stat().st_size==product['source']['bytes'] and identity(source)['sha256']==product['source']['sha256']):
            product_sources.append(dict(record=item,inputs=[source_snapshot(row,record_path.parent)
                for row in (product['source'],*product['dependencies'])]))
    retain(host.parent)
    retain(folder)
    for row in runtime['staged_dlls']:
        verify(row)
    return dict(image=image, source_record=record_identity, source_inputs=sources, current_product_source_inputs=product_sources,
                host_translation_units=plan['host_translation_units'],
                link_plan=identity(folder / 'link-plan.json'), runtime=identity(folder / 'runtime-environment.json'))


def run(attempt, passing):
    folder = Q / f'checks{attempt}'
    summary_path = add(folder / 'summary.json')
    summary = read(summary_path)
    process = summary['process']
    assert 'exit' in process and 'finished' in process and not process['timed_out']
    assert summary['throughput_evidence'] is summary['physical_memory_evidence'] is summary['whole_original_model'] is False
    assert summary['artifact_manifest']['sha256']==MANIFEST
    driver = summary['supply_driver_record']['record']
    assert summary['native_command']==driver['native']['command']
    assert resolve(summary['native_command'][0])==resolve(summary['image']['path'])
    image = linked(summary['image'],summary['source_record'])
    retain(folder)
    for row in summary['supply_driver'].values():
        if isinstance(row,dict) and {'path','bytes','sha256'} <= row.keys():
            source_snapshot(row, S / 'retry')
    if not passing:
        assert process['exit']!=0
        return dict(attempt=attempt, summary=identity(summary_path), process=process,
                    native=driver['native'], linked=image, counted_as_pass=False)
    assert process['exit']==driver['native']['exit']==driver['exit']==0 and not driver['native']['stopped_by_driver']
    assert summary['tests']==len(summary['cases'])==1
    assert not any(summary[k] for k in ('failures','errors','disabled','skips'))
    tree = ET.parse(add(folder / 'results.xml')).getroot()
    actual = [dict(attributes=case.attrib,properties={p.attrib['name']:p.attrib['value'] for p in case.iter('property')}) for case in tree.iter('testcase')]
    assert actual==summary['cases']
    a,p = actual[0]['attributes'],actual[0]['properties']
    assert a['name'] in EXPECTED and a['classname']=='QwenMtpStateConsumer' and a['status']=='run' and a['result']=='completed'
    assert (p['artifact_repository'],p['artifact_revision'],p['artifact_variant'],p['original_bfloat_manifest_sha256']) == (REPO,REV,'official-bf16',MANIFEST)
    exact = dict(original_role_count=33,original_static_role_count=33,original_role_bytes=10301376512,
        original_target_roles=14,original_target_source_bytes=947979264,
        target_verifier_submissions=3,original_native_reference_submissions=0,
        natural_k1_trials=1,controlled_matching_trials=1,controlled_rejection_trials=1,
        complete_target_draft_resources=12,target_expert_domain=512,target_resident_capacity=10,
        first_full_target_verifier_values=496640,target_verifier_full_vocabulary=248320,
        target_verifier_matmuls=1,target_verifier_rows=2,first_full_nextn_head_values=248320,
        target_resident_slot_bytes=1006635008,nextn_resident_slot_bytes=1006635008)
    for key,value in exact.items():
        assert number(p,key)==value,(a['name'],key,p.get(key))
    for key in ('actual_submissions','target_submissions','nextn_submissions','accepted_target_conditioned_repairs',
                'whole_state_publications','cancelled_unpublished_drafts','rejected_stale_publishes','actual_target_reseed_checks',
                'first_full_target_projection_values','selected_expert_source_attachments'):
        assert number(p,key)>0
    assert p['target_expert_source_codec']==p['nextn_expert_source_codec']=='BF16'
    assert number(p,'accepted_zero_drafts')+number(p,'accepted_one_draft')==3
    assert number(p,'accepted_target_conditioned_repairs')==number(p,'accepted_one_draft')
    assert number(p,'actual_accepted_kv_repair_submissions')==2*number(p,'accepted_target_conditioned_repairs')
    assert number(p,'natural_accepted_drafts') in (0,1) and number(p,'natural_proposal')<248320
    assert number(p,'actual_submissions')==sum(number(p,k) for k in ('target_submissions','nextn_submissions','target_verifier_submissions'))
    assert number(p,'peak_state_backing_bytes')<=number(p,'state_budget_bytes')
    assert number(p,'selected_expert_plane_files')==3*number(p,'selected_expert_source_attachments')
    # B05's BF16 observer does not emit the packed-Q24 full_head_provider
    # property. Keep the actual verifier provider fact; CPU placement of the
    # draft vocabulary is separately required by the mixed compile checks.
    assert p['target_verifier_provider']=='ggml-cpu'
    if a['name'].startswith('Mixed'):
        assert p['backend']=='ordinary mixed CPU vocabulary + CUDA body Graph'
        assert number(p,'mixed_host_vocabulary_bytes')==8136949760
        assert number(p,'mixed_device_static_bytes')==2164426752
        assert number(p,'mixed_full_vocabulary_device_instances')==0
    else:
        assert p['backend']=='ordinary CPU Graph'
    return dict(attempt=attempt,summary=identity(summary_path),process=process,native=driver['native'],
                linked=image,cases=actual,graph_submissions=number(p,'actual_submissions'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs',type=int,nargs='+',required=True)
    parser.add_argument('--current-compile',type=int,required=True)
    parser.add_argument('--history',type=int,nargs='+')
    args = parser.parse_args()
    if args.history is None:
        args.history=sorted(int(path.name[6:]) for path in Q.glob('checks*')
            if path.is_dir() and path.name[6:].isdigit() and int(path.name[6:])>=4 and int(path.name[6:]) not in args.runs)
    assert len(args.runs)==len(set(args.runs))==2 and not set(args.runs)&set(args.history)
    protected = shared.protect()
    source, sparse = static_roles(), expert_cache()
    # Keep the independent same-fixture before/after proof distinct from the
    # B05 finite model runs. Its native case count is not added to Graph TPS
    # or to the two original-artifact consumer cases below.
    retirement = read(add(RETIREMENT))
    assert retirement['counts'] == dict(expected_old_failure_cases=1,
        new_passed_cases=4, new_failed_cases=0, new_skipped_cases=0)
    assert retirement['runs'][0]['classification']=='expected_old_bug'
    assert retirement['runs'][1]['classification']=='new_graph_regression_pass'
    assert retirement['runs'][0]['summary']['process']['exit']==1
    assert retirement['runs'][1]['summary']['process']['exit']==0
    retirement_archive = verify(retirement['archive'])
    runs = [run(n,True) for n in args.runs]
    assert {item['cases'][0]['attributes']['name'] for item in runs}==EXPECTED
    history = [run(n,False) for n in args.history]
    current = CA / f'compile{args.current_compile}/qwen-state-bfloat/identity.json'
    assert any(resolve(item['linked']['source_record']['path'])==current for item in runs)
    successful(current.with_name('compile.result.json'))
    for folder in (S / 'mixed',S / 'integration',S / 'retry'):
        if folder.is_dir():retain(folder)
    for path in S.glob('*.py'):add(path)
    add(S / 'publication-attempt1.json')
    for path in (S / 'static-plan.json',S / 'physical-schema.json',S / 'summary.json',
                 Q / 'build.py',Q / 'publish.py',CA / 'publish.py',PRIOR):add(path)
    for document in ('docs/developer/current-work.md','docs/implementation/model-operators.md','docs/architecture/compute-design.md'):
        add(R / document)
    destination = R / 'docs/evidence/correctness/mtp-qwen24-bfloat-target-verifier-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists() and shared.protect()==protected
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
        for path in sorted(shared.files):zipped.write(path,path.relative_to(R).as_posix())
        for name,raw in sorted(extra.items()):zipped.writestr(name,raw)
    result = dict(date='2026-10-23',stage='QB-B05',goal_complete=False,
        conclusion='Finite original B05 target91/NextN/full-V K1 passed CPU and explicit CPU-vocabulary/CUDA-body placement, with original selected BF16 expert planes.',
        artifact=source,selected_original_experts=sparse,
        graph_retirement_regression=dict(evidence=identity(RETIREMENT),
            archive=identity(retirement_archive),counts=retirement['counts'],
            counted_as_original_artifact_cases=False),
        validation=dict(tests=2,failures=0,errors=0,skips=0,graph_submissions=sum(item['graph_submissions'] for item in runs),
                        runs=runs,retained_failed_attempts=history,single_process_or_image_claim=False,
                        current_host_compile_record=identity(current),SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
        implementation=dict(state='Same ordinary Program/segmented Graphs/K1 and12-member StateHead. Accept0 keeps after-current; accepted recursive draft KV is target-conditioned repaired before publication. Actual verifier I32 leases become pending; readonly readers/cancel/stale/budget/continuation remain checked.',
            numerics='Original BF16 bytes/actual predecessors, explicit raw/store boundaries and full512 router with Top10. Tiny normal-source BF16 products use analytical F32 FTZ absolute bound2K*2^-126/(1-K*2^-24); old normal-product domain is unchanged. Source subnormals/nonfinite/overflow remain separately rejected. No empirical tolerance increase.',
            placement='Two original BF16 vocabulary banks total8,136,949,760B are CPU-resident; body/expert compute/state/pending are CUDA-required in the mixed case. Actual compile physical report requires0 full-vocabulary device instances. This is not all-CUDA or a physical-VRAM measurement.',
            failed_history='CPU4 stopped at the reference-domain guard; CPU5 was stopped by the external driver after a failed expert download. Mixed6 exposed an extra inactive phase queue; mixed7 exposed U8 upload metadata for plain BF16. Later mixed execution exposed a public Graph multi-segment retirement/cold-capacity bug, repaired in ordinary host TUs. Exact failed attempt images/source records/logs remain separate; none is a passing runtime.'),
        limitations=['Layer90 upstream input and initial histories remain finite fixtures; not a full trained model or prompt-to-output quality result.',
            'One natural K1 and separate controlled match/reject trials do not estimate natural acceptance rate.',
            'F32-fused RoPE/BF16 store is an explicit implementation policy, not HF eager intermediate-bit equivalence.',
            'Only actual selected original expert planes were acquired; no fake sparse full-bank SHA or full512 bank download is claimed.',
            'Declared source/slot/state capacities are not measured VRAM, loading time or throughput. No TPS or overall MTP completion claim.'],
        protection=protected,archive=identity(archive),archive_items=len(shared.files)+len(extra))
    destination.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    publication=dict(evidence=identity(destination),archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf8')
    assert shared.protect()==protected
    print(json.dumps(dict(**publication,tests=2,graphs=result['validation']['graph_submissions'])))


if __name__=='__main__':
    main()
