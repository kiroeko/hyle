"""Generate the B05 Q24 metadata header from completed, authenticated receipts.

This reads small metadata and stats loose payloads; it never hashes/loads weight
bodies, fetches data, compiles, or treats partial acquisition as complete.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re

S = Path(__file__).resolve().parent
R = S.parents[2]
REPO = 'Qwen/Qwen3.8-2.4T-A95B'
REV = '207bd685a7e3696cfaff12ded7c6a7ea0f88c996'
STATIC_PIN = '838bfae63e6a640789229b60bb1ae1e59eac0c40756f36c34f896bc48ffa74c0'
EXPERT_PIN = '7fea129068439f515d38f44f93c944ccf8b526ee8a91f88d297954a43b7f8c51'
COUNT, BODY = 33, 10301376512
OUTPUT = R / 'tests/compute_models/qwen_bfloat_q24_artifacts.h'
TARGET = 'model.layers.91'
TARGET_NAMES = [TARGET + '.' + suffix for suffix in (
    'input_layernorm.weight', 'self_attn.q_proj.weight',
    'self_attn.k_proj.weight', 'self_attn.v_proj.weight',
    'self_attn.q_norm.weight', 'self_attn.k_norm.weight',
    'self_attn.o_proj.weight', 'post_attention_layernorm.weight',
    'mlp.gate.weight', 'mlp.shared_expert_gate.weight',
    'mlp.shared_expert.gate_proj.weight', 'mlp.shared_expert.up_proj.weight',
    'mlp.shared_expert.down_proj.weight')] + ['model.norm.weight']


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def metadata(path, expected=None):
    raw = path.read_bytes()
    require(expected is None or sha(raw) == expected, f'Unexpected metadata identity: {path}')
    result = json.loads(raw)
    require((result['repository'], result['revision']) == (REPO, REV),
            f'Wrong original artifact identity: {path}')
    return result, sha(raw)


def pinned(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def checked_metadata():
    plan, _ = metadata(S / 'static-plan.json', STATIC_PIN)
    expert, _ = metadata(S / 'expert-source-plan.json', EXPERT_PIN)
    require(plan['original_roles'] == COUNT and plan['source_bytes'] == BODY,
            'Static role count or capacity differs from the fixed B05 plan')
    require(expert['original_roles'] == 4 and expert['full_bank_download_allowed'] is False,
            'The expert contract must describe four selected-source banks only')
    g = plan['geometry']
    require(g == expert['geometry'], 'Static and expert source geometries differ')
    require((g['hidden_size'], g['num_attention_heads'], g['num_key_value_heads'],
             g['head_dim'], g['moe_intermediate_size'], g['shared_expert_intermediate_size'],
             g['vocab_size'], g['num_experts'], g['num_experts_per_tok'], g['target_layer']) ==
            (8192, 64, 4, 256, 2048, 2048, 248320, 512, 10, 91), 'Unexpected B05 geometry')
    require(g['partial_rotary_factor'] == .25 and g['rms_norm_eps'] == 1.e-6 and
            g['rope_parameters']['rope_theta'] == 10000000 and
            g['target_layer_type'] == 'full_attention' and not g['mtp_use_dedicated_embeddings'] and
            not g['tie_word_embeddings'], 'Unexpected B05 source convention')
    out = S / 'original-roles'
    receipt, _ = metadata(out / 'acquisition.json')
    require(receipt.get('complete') is True and receipt['original_roles'] == COUNT and
            len(receipt['roles']) == COUNT and all(row.get('complete') is True for row in receipt['roles']),
            'B05 acquisition is not complete; no header was generated')
    require(receipt['source_plan_sha256'] == STATIC_PIN and
            receipt['expected_role_payload_bytes'] == BODY and not receipt['whole_shard_downloaded'],
            'Completed receipt does not authenticate the fixed static-only plan')
    manifest, manifest_sha = metadata(out / 'manifest.json')
    require(manifest.get('complete') is True and manifest['original_roles'] == COUNT and
            manifest['source_bytes'] == BODY and len(manifest['roles']) == COUNT,
            'B05 complete manifest count/capacity mismatch')
    rows = {row['name']: row for row in manifest['roles']}
    receipts = {row['name']: row for row in receipt['roles']}
    require(len(rows) == len(receipts) == COUNT and set(rows) == set(receipts) ==
            {row['name'] for row in plan['roles']}, 'Manifest has duplicate or different original roles')
    require(len({row['file'] for row in rows.values()}) == COUNT, 'Loose payload paths must be unique')
    for expected in plan['roles']:
        row, acquired = rows[expected['name']], receipts[expected['name']]
        require(row['dtype'] == expected['dtype'] == 'BF16' and row['shape'] == expected['shape'] and
                row['bytes'] == expected['bytes'] == 2 * math.prod(row['shape']) and
                row['file'] == expected['filename'] and row['section'] == expected['section'],
                f'Original role metadata mismatch: {expected["name"]}')
        payload = acquired['payload']
        require(pinned(row['sha256']) and row['sha256'] == payload['sha256'] and
                payload['bytes'] == row['bytes'] and Path(row['file']).name == row['file'],
                f'Original payload pin mismatch: {expected["name"]}')
        require((out / row['file']).resolve() == (R / payload['path']).resolve() and
                (out / row['file']).stat().st_size == row['bytes'],
                f'Original loose payload extent mismatch: {expected["name"]}')
    require(sum(row['section'] == 'nextn' for row in rows.values()) == 19 and
            sum(row['section'] == 'target91' for row in rows.values()) == 14 and
            all(name in rows for name in TARGET_NAMES), 'B05 NextN/target role split mismatch')
    return plan, expert, manifest, manifest_sha


def quoted(value):
    return json.dumps(value, ensure_ascii=True)


def description(shape):
    return 'roles::sem::dense({' + ','.join(map(str, shape)) + '},hyle::compute::DataType::kBFloat16)'


def bank_source(plan, section, suffix):
    matches = [row for row in plan['roles'] if row['section'] == section and row['name'].endswith(suffix)]
    require(len(matches) == 1, f'Expert source bank is missing or duplicated: {section}/{suffix}')
    row = matches[0]
    expected = [512, 4096, 8192] if suffix == 'gate_up_proj' else [512, 8192, 2048]
    shard = plan['shards'][row['source_shard']]
    first, last = row['absolute_inclusive']
    require(row['dtype'] == 'BF16' and row['shape'] == expected and
            row['bytes'] == 2 * math.prod(expected) == last - first + 1 and
            row['source_file'] == shard['file'] and
            first == shard['data_base'] + row['data_relative_half_open'][0] and
            last < shard['whole_file_bytes'] and row['acquire_full_role'] is False,
            f'Expert source bank geometry/range mismatch: {row["name"]}')
    return '{' + ','.join((quoted(row['name']), quoted(row['source_file']),
                           description(row['shape']), str(first) + 'ULL',
                           str(shard['whole_file_bytes']) + 'ULL')) + '}'


def render(expert, manifest, manifest_sha):
    lines = ['#pragma once', '', '#include "qwen_bfloat_selected_experts.h"', '',
        '// Fixed source metadata generated from the complete B05 33-role manifest.',
        '// Specs authenticate original BF16 bytes. Expert contracts describe the original',
        '// full banks; selected planes have separate actual acquisition hashes.',
        '// This header adds no loader, executor, converted bank or acquisition policy.',
        'namespace qwen_bfloat_original_artifacts {', 'namespace q24 {',
        'namespace roles=qwen_bfloat_original_roles;',
        'inline constexpr qwen_original_mtp_roles::Identity kIdentity{',
        f'    {quoted(REPO)},{quoted(REV)},',
        '    "official-bf16","model.safetensors.index.json"};',
        'inline constexpr qwen_full_attention_fragment::Geometry kGeometry{',
        '    8192,64,4,256,64,1.e-6F,0.F,hyle::compute::DataType::kBFloat16};',
        'inline constexpr std::int64_t kIntermediate=2048,kVocabulary=248320;',
        "inline constexpr float kRopeTheta=10'000'000.F;",
        f'inline constexpr std::uint64_t kOriginalBytes={BODY}ULL;',
        f'inline constexpr std::string_view kManifestSha256={quoted(manifest_sha)};', '',
        '// HF original RMS weights are BF16 deltas: F32 (1 + delta), then BF16 store.',
        'inline constexpr roles::DenseNormConventions kNormConventions{',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,',
        '    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,',
        '    roles::NormConvention::kDeltaPlusOne};',
        'inline constexpr roles::VocabularyNames kVocabularyNames{',
        '    "model.embed_tokens.weight","lm_head.weight"};',
        'inline constexpr std::array<std::string_view,14> kTargetNames{']
    lines += ['    ' + quoted(name) + ',' for name in TARGET_NAMES]
    lines += ['};', '', 'inline std::array<roles::Spec,33> specs() {', '  return {{']
    for row in manifest['roles']:
        lines += ['    {' + quoted(row['name']) + ',' + quoted(row['file']) + ',',
                  '     ' + quoted(row['sha256']) + ',', '     ' + description(row['shape']) + '},']
    lines += ['  }};', '}', '',
        'inline qwen_bfloat_selected_experts::Contract expert_contract(',
        '    qwen_bfloat_selected_experts::Section section) {',
        '  namespace selected=qwen_bfloat_selected_experts;',
        '  switch(section) {']
    for section, enum in [('nextn', 'kNextn'), ('target91', 'kTarget91')]:
        lines += [f'    case selected::Section::{enum}:return {{',
                  f'      {quoted(REPO)},{quoted(REV)},',
                  f'      {quoted(EXPERT_PIN)},section,',
                  '      ' + bank_source(expert, section, 'gate_up_proj') + ',',
                  '      ' + bank_source(expert, section, 'down_proj') + '};']
    lines += ['    default:throw std::runtime_error("unknown original Q24 BF16 expert section");',
              '  }', '}', '} // namespace q24', '} // namespace qwen_bfloat_original_artifacts', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Check the existing header without writing it')
    args = parser.parse_args()
    _, expert, manifest, manifest_sha = checked_metadata()
    source = render(expert, manifest, manifest_sha)
    if args.check:
        require(OUTPUT.read_text(encoding='utf-8') == source, 'Generated Q24 metadata header is stale')
    else:
        OUTPUT.write_text(source, encoding='utf-8', newline='\n')
    print(json.dumps(dict(header=OUTPUT.relative_to(R).as_posix(), bytes=len(source.encode()),
                          sha256=sha(source.encode()), manifest_sha256=manifest_sha,
                          static_roles=COUNT, original_bytes=BODY, expert_source_plan_sha256=EXPERT_PIN,
                          weight_bodies_read=0, generated=not args.check), indent=2))


if __name__ == '__main__':
    main()
