"""Root-only incremental Graph retirement build; no SDK/NVCC/native execution.

  python compile_graph.py --attempt 1              # Two product TUs, parallel
  python compile_graph.py --attempt 1 --retirement-test  # Just the small test TU
The test tag uses the current cached Qwen recipe, without Qwen case defines.
"""
from concurrent.futures import ThreadPoolExecutor
import argparse
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
QB = S.parents[1]
R = QB.parents[1]
CA = R / '.scratch/dspark-pro-target-draft-20261023'
spec = importlib.util.spec_from_file_location('graph_retirement_cached_build', CA / 'build.py')
cached = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cached)
b, c, h = cached.b, cached.c, cached.h
RECIPES = {
    'graph-executable': R / '.scratch/qwen-mtp-next-20261022/compile4/executable/identity.json',
    'graph-submission': R / '.scratch/qwen-capture-variants-20261022/compile3/submission/identity.json',
}
SOURCES = {
    'graph-executable': R / 'src/graph/executable.cc',
    'graph-submission': R / 'src/graph/submission.cc',
    'retirement-test': R / 'tests/graph/aggregate_native_retirement_test.cc',
}


def record(tag, attempt):
    path = S / f'compile{attempt}' / tag / 'identity.json'
    result = c.read(path.with_name('compile.result.json'))
    assert result['exit'] == 0 and result.get('terminal', True)
    value = c.read(path)
    assert Path(value['source']['path']) == SOURCES[tag]
    assert all(b.identity(item['path']) == item for item in [value['source'], value['object'], *value['dependencies']])
    return path, value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--retirement-test', action='store_true')
    parser.add_argument('--qwen-compile-attempt', type=int, default=9)
    args = parser.parse_args()
    assert min(args.attempt, args.qwen_compile_attempt) > 0
    tags = ['retirement-test'] if args.retirement_test else list(RECIPES)
    recipes = dict(RECIPES)
    if args.retirement_test:
        original = CA / f'compile{args.qwen_compile_attempt}/qwen-state-bfloat/identity.json'
        assert c.read(original.with_name('compile.result.json'))['exit'] == 0
        recipe = c.read(original)
        recipe['command'] = [arg for arg in recipe['command'] if not arg.startswith('/DHYLE_TEST_QWEN_STATE_')]
        for directory in (R / 'src/graph', R / 'src/compute'):
            flag = '/I' + str(directory)
            if flag not in recipe['command']:
                recipe['command'].insert(1, flag)
        folder = S / 'recipes'
        folder.mkdir(exist_ok=True)
        recipe_path = folder / f'retirement-test-from-qwen{args.qwen_compile_attempt}-attempt{args.attempt}.json'
        assert not recipe_path.exists()
        c.save(recipe_path, recipe)
        recipes['retirement-test'] = recipe_path
    # Configure shared helper globals before starting either compile worker.
    h.S = S
    for tag in tags:
        h.RECIPES[tag] = recipes[tag]
        h.SOURCES[tag] = SOURCES[tag]
    errors = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(h.compile_one, tag, args.attempt) for tag in tags]
        for future in futures:
            try:
                future.result()
            except Exception as error:
                errors.append(error)
    if errors:
        raise errors[0]
    for tag in tags:
        path, _ = record(tag, args.attempt)
        print('READY', tag, path, flush=True)


if __name__ == '__main__':
    main()
