"""Root-only small Graph retirement image, from the unchanged cached closure.

python link_retirement.py --attempt 1 --graph-compile-attempt 1 --test-compile-attempt 1
Only links; it never runs the image. The Qwen test object is not included.
"""
import argparse
import importlib.util
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
QB = S.parents[1]
spec = importlib.util.spec_from_file_location('retirement_qwen_link_support', QB / 'build.py')
qb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qb)
b, c = qb.b, qb.c
spec_graph = importlib.util.spec_from_file_location('retirement_graph_compile_support', S / 'compile_graph.py')
graph = importlib.util.module_from_spec(spec_graph)
spec_graph.loader.exec_module(graph)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--graph-compile-attempt', type=int)
    parser.add_argument('--test-compile-attempt', type=int, required=True)
    args = parser.parse_args()
    assert min(args.attempt, args.test_compile_attempt) > 0
    assert args.graph_compile_attempt is None or args.graph_compile_attempt > 0
    path, compiled = graph.record('retirement-test', args.test_compile_attempt)
    base_path = qb.BASE / 'link-plan.json'
    base = c.read(base_path)
    replacements, graph_records = (qb.graph_overlay(base, args.graph_compile_attempt)
        if args.graph_compile_attempt is not None else ({}, []))
    remove, retained, removed = set(), [], []
    for info in base['compiled_records']:
        assert b.identity(info['path']) == info
        record = c.read(info['path'])
        key = c.key(record['object']['path'])
        if '/tests/' in record['source']['path'].replace('\\', '/'):
            remove.add(key)
            removed.append(info)
        elif key not in replacements:
            retained.append(info)
    assert removed and c.key(compiled['object']['path']) not in remove
    inputs = [compiled['object']] + [replacements.get(c.key(info['path']), info)
        for info in base['inputs'] if c.key(info['path']) not in remove]
    assert all(b.identity(info['path']) == info for info in inputs)
    command = [replacements[c.key(arg)]['path'] if c.key(arg) in replacements else arg
        for arg in base['command'] if c.key(arg) not in remove and
        not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [compiled['object']['path']]
    out = S / f'tests-link{args.attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'graph-retirement-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    records = [b.identity(path), *retained, *graph_records]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=records, removed_test_records=removed, base=b.identity(base_path),
        host_translation_units=1+len(graph_records), product_host_translation_units=len(graph_records),
        graph_compile_attempt=args.graph_compile_attempt,
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [info['path'] for info in inputs], out)
    c.execute('link', command, env, out)
    runtime_path = qb.BASE / 'runtime-environment.json'
    runtime = c.read(runtime_path)
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(qb.BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    runtime.pop('identical_executable', None)
    runtime['previous'] = b.identity(runtime_path)
    runtime['full_SDK_builds'] = runtime['native_CPU_TUs'] = runtime['NVCC_builds'] = 0
    runtime['host_translation_units'] = 1+len(graph_records)
    runtime['product_host_translation_units'] = len(graph_records)
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image), source_record=b.identity(path),
        graph_source_records=graph_records,
        suggested_filter='GraphNativeRetirement.LeasedWaitRetiresEarlierQueuePrefixesBeforePublishingResults',
        executed=False))
    print('LINKED small Graph retirement image', image, flush=True)


if __name__ == '__main__':
    main()
