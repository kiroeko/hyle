"""B05 metadata only:33 immutable roles and four fused-source headers.

Root runs this after reviewing header-plan.json. --plan-only does no network.
The same bounded206 helper used by B02 handles all HTTP/header/cache logic.
No tensor payload, complete fused expert bank, build or native run is allowed.
"""
import argparse
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
BASE = S.parent
R = S.parents[2]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    common = load('b02_header_wiring', BASE / 'fetch_headers.py')
    plan_path = S / 'header-plan.json'
    plan = common.read(plan_path)
    repo, revision = plan['repository'], plan['revision']
    assert (repo, revision) == ('Qwen/Qwen3.8-2.4T-A95B', '207bd685a7e3696cfaff12ded7c6a7ea0f88c996')
    assert len(plan['roles']) == 37 and len(plan['shards']) == 9
    assert plan['static_role_count'] == 33 and plan['static_source_bytes'] == 10301376512
    assert plan['expert_metadata_only']['full_bank_download_allowed'] is False
    index_id = plan['source']['index']
    assert common.identity(R / index_id['path']) == index_id
    index = common.read(R / index_id['path'])['weight_map']
    assert len(index) == 1609 and all(index[row['name']] == row['source_file'] for row in plan['roles'])
    helper = load('b05_bounded206', common.HELPER)
    helper.S = BASE
    helper.MAX_TOTAL = len(plan['shards']) * (helper.MAX_HEADER + 8)
    if args.plan_only:
        print(dict(roles=37, immutable_roles=33, immutable_bytes=10301376512,
                   fused_source_headers=4, header_shards=9, network_requests=0,
                   maximum_header_network_bytes=helper.MAX_TOTAL, tensor_payload_bytes=0))
        return
    receipts, roles = [], []
    try:
        for number, shard in enumerate(plan['shards']):
            tensors, receipt = helper.header('B05', repo, revision, shard['file'])
            receipts.append(receipt)
            for row in plan['roles']:
                if row['source_file'] != shard['file']:
                    continue
                actual = tensors[row['name']]
                assert (actual['dtype'], actual['shape'], actual['data_offsets']) == (
                    row['dtype'], row['shape'], row['data_relative_half_open']), row['name']
                first, end = actual['data_offsets']
                assert end - first == row['bytes']
                roles.append(dict(row, source_shard=number,
                                  absolute_inclusive=[receipt['data_base'] + first, receipt['data_base'] + end - 1]))
        assert len(roles) == len({row['name'] for row in roles}) == 37
        assert {row['name'] for row in roles if row['name'].startswith('mtp.')} == {
            name for name in index if name.startswith('mtp.')}
        assert {row['name'] for row in roles if row['name'].startswith('model.layers.91.')} == {
            name for name in index if name.startswith('model.layers.91.')}
        shards = [dict(file=row['file'], url=row['url'], header=row['header'], etag=row['etag'],
                       data_base=row['data_base'], whole_file_bytes=row['whole_file_bytes']) for row in receipts]
        outputs = []
        selections = [('static-plan.json', lambda row:row['acquire_full_role']),
                      ('nextn-plan.json', lambda row:row['acquire_full_role'] and row['section']=='nextn'),
                      ('target-plan.json', lambda row:row['acquire_full_role'] and row['section']=='target91'),
                      ('expert-source-plan.json', lambda row:not row['acquire_full_role']),
                      ('physical-schema.json', lambda row:True)]
        for filename, select in selections:
            chosen = sorted((dict(row) for row in roles if select(row)),
                            key=lambda row:(row['source_shard'], row['data_relative_half_open'][0]))
            for ordinal, row in enumerate(chosen):
                row['ordinal'] = ordinal
            value = dict(id='B05', repository=repo, revision=revision, hf=plan['hf'],
                         original_roles=len(chosen), source_bytes=sum(row['bytes'] for row in chosen),
                         shards=shards, roles=chosen, geometry=plan['geometry'],
                         source_header_plan=common.identity(plan_path), header_receipts=receipts,
                         metadata_only=True, complete_absolute_ranges=True,
                         full_bank_download_allowed=False, tensor_payload_bytes=0,
                         whole_shards_downloaded=False, artifact_executed=False, native_builds=0)
            path = S / filename
            common.save(path, value)
            outputs.append(common.identity(path))
        common.save(S / 'summary.json', dict(repository=repo, revision=revision, complete=True,
            complete_absolute_ranges=True, plans=outputs, headers=receipts,
            reused_b02_wiring=common.identity(BASE / 'fetch_headers.py'), helper=common.identity(common.HELPER),
            network_metadata_bytes=sum(row['bytes'] for row in helper.requests if row.get('complete')),
            metadata_network_limit=helper.MAX_TOTAL, tensor_payload_bytes=0,
            immutable_roles=33, immutable_bytes=10301376512,
            expert_source_roles=4, full_expert_bank_download_allowed=False,
            scope='NextN17 immutable+two vocabulary, target91 thirteen immutable+one global norm; four fused original source ranges and per-ID plane formulas. No full50GB bank or tensor payload.'))
        print(common.read(S / 'summary.json'))
    finally:
        common.save(S / 'http-requests.json', helper.requests)


if __name__ == '__main__':
    main()
