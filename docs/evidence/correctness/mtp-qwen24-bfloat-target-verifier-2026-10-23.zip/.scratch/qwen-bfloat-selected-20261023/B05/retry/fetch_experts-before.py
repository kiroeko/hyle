"""Acquire only explicitly requested B05 original BF16 expert planes.

Each immutable expertNNN directory has three loose original plane files and a
one-ID HYQBF001 catalog. --plan-only authenticates only small cached metadata;
it never creates payload files or sends requests. Native/model execution is not
part of this script. The existing loose-role Range/resume implementation is
reused without changing its HTTP or authenticated-prefix rules.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import json
import os
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[2]
REPO = 'Qwen/Qwen3.8-2.4T-A95B'
REV = '207bd685a7e3696cfaff12ded7c6a7ea0f88c996'
PLAN_SHA = '7fea129068439f515d38f44f93c944ccf8b526ee8a91f88d297954a43b7f8c51'
DOMAIN, PLANE_BYTES, EXPERT_BYTES, WORKERS = 512, 33554432, 100663296, 3
SECTIONS = ('nextn', 'target91')
LEGS = ('gate', 'up', 'down')


def helper():
    spec = importlib.util.spec_from_file_location('_hyle_b05_plane_downloader', S.parent / 'fetch_roles.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing original loose-role helper is missing')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(condition, message):
    if not condition:
        raise ValueError(message)


def emit(event, **fields):
    print(json.dumps(dict(event=event, **fields), separators=(',', ':')), flush=True)


def atomic_json(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def checked_plan(common):
    path = S / 'expert-source-plan.json'
    require(common.sha(path.read_bytes()) == PLAN_SHA, 'B05 expert source plan pin differs')
    plan, proof = common.read(path), common.read(S / 'summary.json')
    require((plan['repository'], plan['revision'], plan['original_roles']) == (REPO, REV, 4),
            'B05 source repository/revision/four fused roles differ')
    require(proof['complete'] is True and proof['complete_absolute_ranges'] is True
            and proof['tensor_payload_bytes'] == 0 and common.identity(path) in proof['plans'],
            'Expected the actual complete small-header receipt')
    require(plan['metadata_only'] is True and plan['complete_absolute_ranges'] is True
            and plan['full_bank_download_allowed'] is False and len(plan['roles']) == 4,
            'Only authenticated selected ranges are allowed')
    result = {}
    for row in plan['roles']:
        section = row['section']
        require(section in SECTIONS and row['acquire_full_role'] is False, 'Invalid source section/full-bank permission')
        shard = plan['shards'][row['source_shard']]
        info = shard['header']
        raw = (R / info['path']).read_bytes()
        require(len(raw) == info['bytes'] <= 1024 * 1024 and common.sha(raw) == info['sha256'],
                'Actual source header authentication failed')
        header = json.loads(raw)
        actual = header[row['name']]
        fused = row['name'].endswith('.gate_up_proj')
        prefix = 'mtp.layers.0' if section == 'nextn' else 'model.layers.91'
        expected_name = prefix + '.mlp.experts.' + ('gate_up_proj' if fused else 'down_proj')
        shape = [DOMAIN, 4096, 8192] if fused else [DOMAIN, 8192, 2048]
        require(row['name'] == expected_name and actual['dtype'] == row['dtype'] == 'BF16'
                and actual['shape'] == row['shape'] == shape, 'Original fused source role/shape differs')
        require(shard['data_base'] == len(raw) + 8 and shard['file'] == row['source_file']
                and shard['url'] == f"https://huggingface.co/{REPO}/resolve/{REV}/{shard['file']}"
                and shard['etag'].startswith('"') and shard['etag'].endswith('"'),
                'Original shard URL/data base/ETag differs')
        first, end = actual['data_offsets']
        stride = PLANE_BYTES * (2 if fused else 1)
        require(type(first) is int and type(end) is int and first >= 0
                and row['data_relative_half_open'] == [first, end]
                and end - first == row['bytes'] == DOMAIN * stride
                and row['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
                and shard['data_base'] + end <= shard['whole_file_bytes'], 'Original fused source range differs')
        for leg in (('gate', 'up') if fused else ('down',)):
            key = (section, leg)
            require(key not in result, 'Duplicate original expert leg')
            result[key] = dict(source_name=row['name'], source_file=shard['file'],
                source_header=info, url=shard['url'], etag=shard['etag'], whole_file_bytes=shard['whole_file_bytes'],
                tensor_relative_first=first, tensor_absolute_first=shard['data_base'] + first,
                expert_stride=stride, leg_offset=PLANE_BYTES if leg == 'up' else 0,
                shape=[8192, 2048] if leg == 'down' else [2048, 8192])
    require(set(result) == {(section, leg) for section in SECTIONS for leg in LEGS}, 'Incomplete original leg set')
    return result, common.identity(path)


def request_args(args, common):
    if args.frontier_file is not None:
        require(args.section is None and args.stage is None and args.ids is None,
                'Use a frontier file or explicit section/stage/IDs')
        request = common.read(args.frontier_file)
        section, stage = request['section'], request['stage']
        ids, globals_ = request['missing_ids'], request['global_ids']
        require(isinstance(globals_, list) and all(type(i) is int and 0 <= i < DOMAIN for i in globals_)
                and globals_ == sorted(set(globals_)), 'Frontier globals must be sorted unique original IDs')
        require(isinstance(ids, list) and set(ids) <= set(globals_), 'Missing IDs must belong to the actual frontier')
    else:
        require(args.section is not None and args.ids is not None, 'Explicit section and IDs are required')
        section, stage, ids = args.section, 0 if args.stage is None else args.stage, args.ids
    require(section in SECTIONS and type(stage) is int and stage == 0, 'B05 requires section nextn/target91 and stage0')
    require(isinstance(ids, list) and all(type(i) is int and 0 <= i < DOMAIN for i in ids)
            and ids == sorted(set(ids)), 'Requested IDs must be sorted unique originals in [0,512)')
    return section, ids


def expert_plan(templates, plan_identity, section, global_id):
    rows = []
    for leg in LEGS:
        source = templates[(section, leg)]
        first = source['tensor_absolute_first'] + global_id * source['expert_stride'] + source['leg_offset']
        relative = source['tensor_relative_first'] + global_id * source['expert_stride'] + source['leg_offset']
        rows.append(dict(source, name=f"{source['source_name']}#expert{global_id:03d}/{leg}",
            section=section, global_id=global_id, leg=leg, dtype='BF16', bytes=PLANE_BYTES,
            filename=f'expert-{global_id:03d}-{leg}.bf16', data_relative_half_open=[relative, relative + PLANE_BYTES],
            absolute_inclusive=[first, first + PLANE_BYTES - 1]))
        require(first + PLANE_BYTES <= source['whole_file_bytes'], 'Selected plane exceeds its original shard')
    return dict(repository=REPO, revision=REV, section=section, stage=0, globals=[global_id],
        source_plan_sha256=plan_identity['sha256'], original_roles=3, source_bytes=EXPERT_BYTES,
        full_bank_download_allowed=False, whole_shards_downloaded=False, roles=rows)


def acquire_one(common, templates, plan_identity, section, global_id):
    directory = S / 'original-experts' / section / f'expert{global_id:03d}'
    directory.mkdir(parents=True, exist_ok=True)
    with common.single_writer(directory / '.fetch.lock'):
        plan = expert_plan(templates, plan_identity, section, global_id)
        plan_path, receipt = directory / 'plan.json', directory / 'acquisition.json'
        if plan_path.exists():
            require(common.read(plan_path) == plan, 'Existing per-ID source plan differs')
        else:
            atomic_json(plan_path, plan)
        rows = [dict(row, complete=False, chunks=[], payload=dict(
            path=(directory / row['filename']).relative_to(R).as_posix(), bytes=PLANE_BYTES, sha256=None)) for row in plan['roles']]
        expected = dict(repository=REPO, revision=REV, section=section, stage=0, globals=[global_id],
            directory=directory.relative_to(R).as_posix(), source_plan_sha256=plan_identity['sha256'],
            acquisition_plan=common.identity(plan_path), expected_role_payload_bytes=EXPERT_BYTES,
            downloader=common.identity(common.HELPER))
        if receipt.exists():
            record = common.read(receipt)
            require(all(record[key] == value for key, value in expected.items()), 'Existing expert receipt identity differs')
            for prior, wanted in zip(record['roles'], rows, strict=True):
                require(all(prior[key] == value for key, value in wanted.items() if key not in ('complete', 'chunks', 'payload'))
                        and prior['payload']['path'] == wanted['payload']['path']
                        and prior['payload']['bytes'] == PLANE_BYTES, 'Existing plane receipt differs')
        else:
            require(not any((R / row['payload']['path']).exists() for row in rows), 'Unrecorded plane is not an authenticated prefix')
            record = dict(expected, complete=False, original_roles=3, whole_shard_downloaded=False,
                chunk_bytes=common.CHUNK, stream_buffer_bytes=common.IO, requests=[], roles=rows)
        functions = common.downloader(record, receipt)
        record['complete'] = False
        functions['save']()
        # Three expert futures run concurrently; each processes its own three
        # planes serially. At most three HTTP streams / 3 MiB IO are live.
        for row in record['roles']:
            functions['acquire_role'](row)
        require(all(row['complete'] and row['payload']['sha256'] for row in record['roles']), 'Partial expert cannot publish a catalog')
        hashes = {row['leg']: row['payload']['sha256'] for row in record['roles']}
        catalog = ('HYQBF001\t' + section + '\t' + plan_identity['sha256'] + '\t1\n'
            + str(global_id) + '\t' + '\t'.join(hashes[leg] for leg in LEGS) + '\n').encode('utf-8')
        catalog_path = directory / 'catalog.tsv'
        if catalog_path.exists():
            require(catalog_path.read_bytes() == catalog, 'Immutable expert catalog cannot be rebound')
        else:
            temporary = directory / 'catalog.tsv.next'
            with temporary.open('wb') as stream:
                stream.write(catalog)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, catalog_path)
        catalog_info = dict(file='catalog.tsv', bytes=len(catalog), sha256=common.sha(catalog))
        request_bytes = sum(item.get('bytes', 0) for item in record['requests'] if item['complete'])
        require(request_bytes == EXPERT_BYTES, 'Complete exact-Range bytes differ from one expert')
        record.update(complete=True, role_payload_bytes=EXPERT_BYTES, successful_request_body_bytes=request_bytes,
            catalog=catalog_info, finished_utc=functions['now']())
        functions['save']()
        ready = dict(complete=True, section=section, source_plan_sha256=plan_identity['sha256'], globals=[global_id],
            directory=directory.relative_to(R).as_posix(), catalog=catalog_info, acquisition=common.identity(receipt))
        atomic_json(directory / 'ready.json', ready)
        emit('expert_complete', **ready)
        return ready


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--section', choices=SECTIONS)
    parser.add_argument('--stage', type=int)
    parser.add_argument('--ids', nargs='+', type=int)
    parser.add_argument('--frontier-file', type=Path)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    common = helper()
    templates, plan_identity = checked_plan(common)
    section, ids = request_args(args, common)
    require(common.sha(common.HELPER.read_bytes()) == common.HELPER_SHA, 'Pinned Range implementation differs')
    if args.plan_only:
        emit('expert_plan', complete=True, section=section, stage=0, globals=ids, source_plan=plan_identity,
            plane_bytes=PLANE_BYTES, expert_payload_bytes=EXPERT_BYTES, requested_payload_bytes=EXPERT_BYTES * len(ids),
            expert_workers=WORKERS, maximum_live_stream_bytes=WORKERS * common.IO, range_bytes=common.CHUNK,
            per_id_plans=[expert_plan(templates, plan_identity, section, global_id) for global_id in ids], network_requests=0)
        return
    output = S / 'original-experts' / section
    output.mkdir(parents=True, exist_ok=True)
    # One external frontier writer per section; per-ID locks also protect
    # explicit single-ID acquisitions without trusting stale PID markers.
    with common.single_writer(output / '.frontier.lock'):
        ready_path = output / 'ready.json'
        ready = dict(complete=False, repository=REPO, revision=REV, section=section, stage=0, globals=ids,
            source_plan_sha256=plan_identity['sha256'], sets=[], errors=[])
        atomic_json(ready_path, ready)
        with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='qwen-bfloat-expert') as executor:
            futures = {executor.submit(acquire_one, common, templates, plan_identity, section, global_id): global_id for global_id in ids}
            for future in as_completed(futures):
                try:
                    ready['sets'].append(future.result())
                except Exception as error:
                    ready['errors'].append(dict(global_id=futures[future], type=type(error).__name__, error=str(error)))
        ready['sets'].sort(key=lambda item: item['globals'][0])
        ready['complete'] = not ready['errors'] and len(ready['sets']) == len(ids)
        atomic_json(ready_path, ready)
        if not ready['complete']:
            emit('frontier_failed', **ready, ready_file=ready_path.relative_to(R).as_posix())
            raise RuntimeError('One or more original selected experts failed; completed per-ID caches remain reusable')
        emit('frontier_complete', **ready, ready_file=ready_path.relative_to(R).as_posix())


if __name__ == '__main__':
    main()
