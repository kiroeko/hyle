from pathlib import Path
import difflib
import hashlib
import json

repo=Path(__file__).resolve().parents[4]
stage=Path(__file__).resolve().parent
path=repo/'tests/compute_models/qwen_mtp_state_consumer_test.cc'
raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='c042a590bf4263da9caf48ca93b7a67dbeff7ded1db7b9452df6847e12493a24'
before=raw.decode().replace('\r\n','\n')
text=before
def replace(old,new):
 global text
 assert text.count(old)==1,old[:160]
 text=text.replace(old,new)

replace('#include "qwen_bfloat_original_artifacts.h"', '''#include "qwen_bfloat_original_artifacts.h"
#include "qwen_bfloat_moe_reference.h"
#include "qwen_bfloat_moe_target_fragment.h"''')
replace('namespace bfloat27=qwen_bfloat_original_artifacts::q27;', '''namespace bfloat27=qwen_bfloat_original_artifacts::q27;
namespace bfloat_moe=qwen_bfloat_moe_reference;
namespace bfloat_moe_target=qwen_bfloat_moe_target_fragment;''')
replace('''  ExpertSource source;
  std::shared_ptr<resident24::CpuSupply> cpu;''','''  ExpertSource source;
  // Optional explicit fixture frontier hook. An external supply driver may
  // attach authenticated original slices here; raw lookup never fetches.
  std::function<void(std::span<const std::int32_t>)> before_upload;
  std::shared_ptr<resident24::CpuSupply> cpu;''')
replace('''        selected=full24::select(typed<std::int32_t>(live.at(boundary.ids.ordinal())));''','''        selected=full24::select(typed<std::int32_t>(live.at(boundary.ids.ordinal())));
        if(supply->before_upload)supply->before_upload(selected->globals);''')
replace('''    Program p;p.recipe=std::move(recipe);p.supply=std::move(supply);p.logical=sem::make_graph(p.recipe.fragment);p.cuda_backend=cuda;''','''    if(recipe.bfloat_moe) {
      auto raw=bfloat_moe::linear_stores(recipe.fragment,recipe.bfloat_moe->moe);
      raw.visit_values([&](Value &value) {
        const auto found=std::find_if(recipe.bfloat_ports.begin(),recipe.bfloat_ports.end(),[&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
        if(found==recipe.bfloat_ports.end())recipe.bfloat_ports.push_back({value,expose(recipe,value)});
      });
    }
    Program p;p.recipe=std::move(recipe);p.supply=std::move(supply);p.logical=sem::make_graph(p.recipe.fragment);p.cuda_backend=cuda;''')
replace('''  if(!r.original_bfloat||!r.bfloat_dense||!r.bfloat_dense->block.trace)
    throw std::runtime_error("BF16 selected MoE observer requires its explicit independent selected source checks");''','''  if(!r.original_bfloat||(!r.bfloat_dense&&!r.bfloat_moe))
    throw std::runtime_error("BF16 observation needs its actual original dense or selected-MoE result");''')
replace('''  const auto &prefix=r.bfloat_dense->prefix.ports;''','''  const auto &prefix=r.bfloat_dense?r.bfloat_dense->prefix.ports:r.bfloat_moe->prefix.ports;''')
replace('''  const auto &block=r.bfloat_dense->block;const auto &trace=*block.trace;''','''  const auto &maybe_trace=r.bfloat_dense?r.bfloat_dense->block.trace:r.bfloat_moe->attention.trace;
  ASSERT_TRUE(maybe_trace);const auto &trace=*maybe_trace;
  const auto &attention_ports=r.bfloat_dense?static_cast<const attention::TargetAttentionPorts&>(r.bfloat_dense->block.ports):r.bfloat_moe->attention.ports;''')
replace('''  observe_bfloat_attention(program,output,block.ports,trace,state.member(from,kKey),state.member(from,kValue),cursor,position);''','''  observe_bfloat_attention(program,output,attention_ports,trace,state.member(from,kKey),state.member(from,kValue),cursor,position);''')
replace('''  ASSERT_TRUE(trace.ffn_silu);
  ASSERT_TRUE(bfloat_reference::expect_unary(bits(*trace.ffn_silu),get(r.dense_ffn_ports[0]),true,"BF16 dense SiLU"));
  ASSERT_TRUE(bfloat_reference::expect_binary(get(r.dense_ffn_ports[2]),bits(*trace.ffn_silu),get(r.dense_ffn_ports[1]),true,"BF16 dense SwiGLU"));''','''  if(r.bfloat_moe) {
    ASSERT_TRUE(program.supply);ASSERT_TRUE(program.supply->source.owner);
    const auto parameters=bfloat_moe::from_source(source,"mtp.layers.0.mlp.gate.weight","mtp.layers.0.mlp.shared_expert_gate.weight",
        std::array<std::string_view,3>{"mtp.layers.0.mlp.shared_expert.gate_proj.weight","mtp.layers.0.mlp.shared_expert.up_proj.weight","mtp.layers.0.mlp.shared_expert.down_proj.weight"});
    const auto actual=[&](Value value){return read(output[bfloat_port(r,value)]);};
    bfloat_moe::observe(r.fragment,parameters,r.bfloat_moe->moe,bfloat_moe::linear_stores(r.fragment,r.bfloat_moe->moe),
        program.supply->source,actual,full,program.original_full_values);
    ASSERT_FALSE(::testing::Test::HasFailure());
    observe_bfloat_trace(program,output,r.bfloat_moe->tail_trace,full);ASSERT_FALSE(::testing::Test::HasFailure());
    ASSERT_EQ(program.supply->episodes,std::size_t(program.submissions));ASSERT_FALSE(program.supply->selections.empty());
    EXPECT_EQ(typed<std::int32_t>(output[bfloat_port(r,r.bfloat_moe->moe.ports.values.map)]),
        std::vector<std::int32_t>(program.supply->selections.back().map.begin(),program.supply->selections.back().map.end()));
  } else {
    ASSERT_TRUE(trace.ffn_silu);
    ASSERT_TRUE(bfloat_reference::expect_unary(bits(*trace.ffn_silu),get(r.dense_ffn_ports[0]),true,"BF16 dense SiLU"));
    ASSERT_TRUE(bfloat_reference::expect_binary(get(r.dense_ffn_ports[2]),bits(*trace.ffn_silu),get(r.dense_ffn_ports[1]),true,"BF16 dense SwiGLU"));
  }''')
replace('''  std::optional<target24_model::Result> result24;''','''  std::optional<target24_model::Result> result24;
  std::optional<bfloat_moe_target::Result> result_bfloat_moe;
  bfloat_moe_target::Names bfloat_moe_names;''')

factory='''// Same ordinary two-phase Program and target six-member state. The actual
// target static roles/selected source remain distinct from NextN's roles.
TargetPlan prepare_bfloat_moe_target(const Model &model,std::shared_ptr<const bfloat::Bound> parameters,
    const bfloat::DenseNormConventions &rules,const bfloat_moe_target::Names &names,
    std::shared_ptr<ExpertSupply> supply,c::Context &context,const c::StorageOwner &owner,bool cuda) {
  if(model.storage!=c::DataType::kBFloat16||!model.moe||!parameters||!parameters->source||!supply||!supply->source.owner)
    throw std::runtime_error("BF16 MoE target requires actual static roles and a bounded selected original source");
  Recipe recipe{.model=model,.fragment={.profile=model.profile,.region=0x51424631364d5447ULL}};
  recipe.original_bfloat=parameters;recipe.bfloat_rules=rules;auto &f=recipe.fragment;
  const auto input=f.input(sem::dense({1,model.hidden},model.storage));
  const auto old_key=f.input(descriptions(model)[kKey]),old_value=f.input(descriptions(model)[kValue]);
  const auto cursor=f.input(sem::dense({1},c::DataType::kInt32)),position=f.input(sem::dense({1},c::DataType::kInt32));
  const std::array banks{f.input(supply->layout().resident(0)),f.input(supply->layout().resident(1)),f.input(supply->layout().resident(2))};
  const auto map=f.input(supply->layout().map_description());
  const auto frequency=f.constant(sem::dense({model.rotary/2}),sem::bytes(text_frequencies(model)));
  TargetPlan plan;plan.bfloat_parameters=parameters;
  for(std::size_t slot=0;slot<names.size();++slot)plan.bfloat_moe_names[slot]=parameters->at(names[slot]).name;
  plan.result_bfloat_moe=bfloat_moe_target::append(f,input,old_key,old_value,cursor,position,frequency,*parameters,names,rules,
      {model.hidden,model.heads,model.kv_heads,model.depth,model.rotary,1.e-6F,model.score_scale,model.storage},banks,map);
  const auto &actual=*plan.result_bfloat_moe;
  for(const auto &constant:actual.constants) {
    const auto found=std::find_if(f.constants.begin(),f.constants.end(),[&](Value value){return value.ordinal()==constant.value.ordinal();});
    if(found==f.constants.end())throw std::runtime_error("BF16 target parameter lost its original constant identity");
    recipe.external.push_back({std::size_t(found-f.constants.begin()),constant.role});
  }
  recipe.moe=moe24::Result{actual.feed_forward.output,actual.feed_forward.ports.values,actual.feed_forward.boundary};
  const auto expose_value=[&](Value value) {
    const auto found=std::find_if(plan.observed.begin(),plan.observed.end(),[&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
    if(found!=plan.observed.end())return found->second;
    const auto port=expose(recipe,value);plan.observed.push_back({value,port});return port;
  };
  plan.result_bfloat_moe->visit_values([&](Value &value){(void)expose_value(value);});
  auto linear=bfloat_moe::linear_stores(f,actual.feed_forward);
  linear.visit_values([&](Value &value){(void)expose_value(value);});
  plan.members={expose_value(actual.attention.key),expose_value(actual.attention.value),expose_value(increment(f,cursor)),
      expose_value(increment(f,position)),expose_value(actual.post_ffn),expose_value(actual.normalized_tap)};
  recipe.bfloat_ports=plan.observed;
  recipe.state_ports[kKey]=plan.members[kTargetKey];recipe.state_ports[kValue]=plan.members[kTargetValue];recipe.state_ports[kHidden]=plan.members[kTargetTap];
  const auto &ap=actual.attention.ports;
  recipe.qg=plan.port(ap.qg);recipe.key=plan.port(ap.key);recipe.value=plan.port(ap.value);recipe.query=plan.port(ap.query);recipe.gate=plan.port(ap.gate);
  recipe.rotated_key=plan.port(ap.rotated_key);recipe.attended=plan.port(ap.attended);recipe.oproj=plan.port(ap.oproj);recipe.residual=plan.port(ap.residual);
  recipe.ffn_input=plan.port(ap.ffn_input);recipe.ffn_output=plan.port(actual.feed_forward.output);recipe.post_ffn=plan.port(actual.post_ffn);
  plan.role_count=recipe.external.size();plan.source_bytes=0;
  for(const auto &binding:recipe.external)plan.source_bytes+=take(binding.role.description.required_bytes(),"actual BF16 MoE target source extent");
  plan.program=Program::create(std::move(recipe),context,owner,cuda,true,std::move(supply));plan.program.report_bfloat_roles(owner);return plan;
}
'''
replace('''TargetPlan prepare_target(std::shared_ptr<const target_roles::Bound> parameters,c::Context &context,''',factory+'''TargetPlan prepare_target(std::shared_ptr<const target_roles::Bound> parameters,c::Context &context,''')

branch='''  if(plan.result_bfloat_moe) {
    ASSERT_TRUE(plan.bfloat_parameters);const auto &actual=*plan.result_bfloat_moe;
    ASSERT_TRUE(actual.attention.trace);const auto &trace=*actual.attention.trace;
    const auto bits=[&](Value value){return typed<std::uint16_t>(output[plan.port(value)]);};
    const auto observed=[&](Value value){return read(output[plan.port(value)]);};
    observe_bfloat_trace(plan.program,output,trace,!plan.full_checked);ASSERT_FALSE(::testing::Test::HasFailure());
    observe_bfloat_attention(plan.program,output,actual.attention.ports,trace,input[1],input[2],cursor,position);
    ASSERT_FALSE(::testing::Test::HasFailure());ASSERT_TRUE(plan.program.supply);
    const auto role_name=[&](bfloat_moe_target::Role role){return plan.bfloat_moe_names[std::size_t(role)];};
    const auto parameters=bfloat_moe::from_source(*plan.bfloat_parameters->source,role_name(bfloat_moe_target::Role::kRouter),
        role_name(bfloat_moe_target::Role::kSharedGate),std::array<std::string_view,3>{role_name(bfloat_moe_target::Role::kSharedProjectionGate),
        role_name(bfloat_moe_target::Role::kSharedUp),role_name(bfloat_moe_target::Role::kSharedDown)});
    bfloat_moe::observe(plan.program.recipe.fragment,parameters,actual.feed_forward,
        bfloat_moe::linear_stores(plan.program.recipe.fragment,actual.feed_forward),plan.program.supply->source,
        observed,!plan.full_checked,plan.program.original_full_values);
    ASSERT_FALSE(::testing::Test::HasFailure());
    ASSERT_TRUE(bfloat_reference::expect_binary(bits(actual.post_ffn),bits(actual.attention.ports.residual),bits(actual.feed_forward.output),false,"BF16 target MoE residual"));
    observe_bfloat_trace(plan.program,output,actual.tail_trace,!plan.full_checked);ASSERT_FALSE(::testing::Test::HasFailure());
    ASSERT_EQ(plan.program.supply->episodes,std::size_t(plan.program.submissions));ASSERT_FALSE(plan.program.supply->selections.empty());
    EXPECT_EQ(typed<std::int32_t>(output[plan.port(actual.feed_forward.ports.values.map)]),
        std::vector<std::int32_t>(plan.program.supply->selections.back().map.begin(),plan.program.supply->selections.back().map.end()));
    EXPECT_EQ(typed<std::int32_t>(output[plan.members[kTargetCursor]]),std::vector<std::int32_t>{cursor+1});
    EXPECT_EQ(typed<std::int32_t>(output[plan.members[kTargetPosition]]),std::vector<std::int32_t>{position+1});
    if(!plan.full_checked)plan.full_projection_values=plan.program.original_full_values;
    if(!::testing::Test::HasFailure())plan.full_checked=true;return;
  }
'''
replace('''  if(plan.bfloat_parameters) {
    ASSERT_TRUE(plan.result.trace);''',branch+'''  if(plan.bfloat_parameters) {
    ASSERT_TRUE(plan.result.trace);''')
replace('''    ::testing::Test::RecordProperty("target_expert_source_codec","IQ4_XS");
    ::testing::Test::RecordProperty("nextn_expert_source_codec","Q4_K");''','''    ::testing::Test::RecordProperty("target_expert_source_codec",draft.recipe.original_bfloat?"BF16":"IQ4_XS");
    ::testing::Test::RecordProperty("nextn_expert_source_codec",draft.recipe.original_bfloat?"BF16":"Q4_K");''')
replace('''"original BF16 dense Qwen target layer and complete original BF16 NextN retain their distinct actual source roles;''','''"original BF16 Qwen target layer and complete original BF16 NextN retain their distinct actual source roles;''')

entry='''// Actual B05 caller supplies authenticated static roles and separate target /
// NextN selected sources. This only delegates to the existing K1 controller.
[[maybe_unused]] void run_bfloat_moe_target_verifier(const Model &model,std::shared_ptr<const bfloat::Bound> source,
    const bfloat::DenseNormConventions &rules,const bfloat_moe_target::Names &target_names,
    std::shared_ptr<ExpertSupply> nextn_supply,std::shared_ptr<ExpertSupply> target_supply,
    bfloat::VocabularyNames vocabulary,c::Context &context,const c::StorageOwner &owner,bool cuda) {
  if(!source||!source->source||!model.profile||!model.moe||model.storage!=c::DataType::kBFloat16||
      !nextn_supply||!target_supply||!nextn_supply->source.owner||!target_supply->source.owner||
      model.profile->artifact_repository!=source->source->identity().repository||
      model.profile->artifact_revision!=source->source->identity().revision)
    throw std::runtime_error("BF16 MoE K1 requires its actual original static and selected-source owners");
  const std::array resident{nextn_supply->layout().resident(0),nextn_supply->layout().resident(1),nextn_supply->layout().resident(2)};
  auto draft=Program::create(build_bfloat(model,source,rules,resident,vocabulary),context,owner,cuda,false,std::move(nextn_supply));
  auto target=prepare_bfloat_moe_target(model,std::move(source),rules,target_names,std::move(target_supply),context,owner,cuda);
  run_original_target_verifier(std::move(draft),std::move(target),context,owner,cuda);
}

'''
replace('''TEST(OriginalRoleInput, BoundedSha256AuthenticatesBlockAndPaddingBoundaries) {''',entry+'''TEST(OriginalRoleInput, BoundedSha256AuthenticatesBlockAndPaddingBoundaries) {''')

output=stage/'qwen_mtp_state_consumer_test.cc'
output.write_text(text,encoding='utf-8',newline='\n')
patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),text.splitlines(keepends=True),
    fromfile='a/tests/compute_models/qwen_mtp_state_consumer_test.cc',tofile='b/tests/compute_models/qwen_mtp_state_consumer_test.cc'))
(stage/'integration.patch').write_text(patch,encoding='utf-8',newline='\n')
(stage/'identity.json').write_text(json.dumps({'base_source':str(path.relative_to(repo)),
    'base_sha256':hashlib.sha256(raw).hexdigest(),'proposal_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
    'patch_sha256':hashlib.sha256((stage/'integration.patch').read_bytes()).hexdigest(),
    'applied':False,'compiled':False,'native_run':False,'new_test_cases':0,
    'public_product_changes':0,'shared_header_changes':0,'controller_algorithm_changed':False,
    'controller_reporting_only_changed':True,'sparse_source_implemented':False,
    'explicit_before_upload_frontier_hook_only':True},indent=2)+'\n')
print((stage/'identity.json').read_text())
