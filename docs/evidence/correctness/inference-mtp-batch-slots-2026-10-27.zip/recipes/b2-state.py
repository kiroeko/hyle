"""One combined test TU, old mixed weights, two finite B2 K3 processes."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
N = W / 'b2-mtp-state'
spec = importlib.util.spec_from_file_location('retained_mixed_recipe', W / 'mixed.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
b, m = old.b, old.helper_module


def build():
    assert not (N / 'freeze.json').exists() and not (N / 'ready.json').exists()
    baseline = b.read(W / 'mixed/ready.json')
    prior = next(row for row in baseline['compiled'] if row['name'] == 'probe')
    source = R / 'tests/tools/qwen_host_image_test.cc'
    header = R / 'tests/tools/qwen_mtp_batch_state_case.h'
    assert b.pin(source)['sha256'] == 'cd9fa9959ed0397b3ed53f6d6910990871fcbce8f74fc58eb3663bd544dd7911'
    assert b.pin(header)['sha256'] == '1a214d3c2df71a1659eba486ea4c2bd71a2cbbc51fe1ed75eeaebf14231042b3'
    assert b.pin(R / 'engine/models/qwen35/main.cc')['sha256'] == '3b1a2c6996a8c7a3cd3c654526abd1bbb9a033a0a809e68ff6063ede8b61812f'
    out = N / 'compile'
    command = m.command(Path(prior['object']['path']).parent / 'command.json', source, out)
    b.save(N / 'recipe.json', dict(command=command, cwd=str(R), timeout_seconds=180))
    frozen = m.c.closure([source], [N / 'recipe.json'])
    b.save(N / 'source-freeze.json', frozen)
    snapshots = []
    for path in [source, header, R / 'engine/models/qwen35/main.cc', R / 'engine/models/qwen35/session_state.h']:
        target = N / 'source' / path.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes()); snapshots.append(b.pin(target))
    b.save(N / 'freeze.json', dict(source=b.pin(source), header=b.pin(header), snapshots=snapshots,
        source_freeze=b.pin(N / 'source-freeze.json'), baseline=b.pin(W / 'mixed/ready.json'),
        replaced_object=prior['object'], recipe=b.pin(N / 'recipe.json'),
        counts=dict(CXX_TUs=1, images=1, reused_weights=True, NVCC=0, SDK=0, downloads=0)))
    h = b.helper()
    cl = command[0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': cl,
        'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    process = h.execute(command, env, out, timeout=180)
    deps = b.read(out / 'dependencies.json')['Data']
    actual = [b.pin(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])]
    b.save(out / 'actual-dependencies.json', actual)
    own = {b.key(row['path']): row for row in frozen}
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
            assert own[b.key(path)]['sha256'] == row['sha256'], str(path)
    print('COMPILE_AND_ACTUAL_DEPS_FINAL', json.dumps(process), flush=True)
    image = N / 'link/b2-state-test.exe'
    link = []
    for arg in b.read(W / 'mixed/link/command.json')['command']:
        if b.key(arg) == b.key(prior['object']['path']): arg = str(out / 'unit.obj')
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        link.append(arg)
    linked = h.execute(link, env, N / 'link', timeout=120)
    inputs = [b.pin(out / 'unit.obj') if b.key(row['path']) == b.key(prior['object']['path']) else row
              for row in b.read(baseline['inputs']['path'])]
    assert len(inputs) == 223
    b.save(N / 'link-inputs.json', inputs)
    runtime = b.read(baseline['runtime']['path'])
    native = runtime['native_cpu']; b.exact(native)
    alias = image.parent / Path(native['path']).name
    os.link(native['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(N / 'runtime.json', runtime)
    b.save(N / 'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), object=b.pin(out / 'unit.obj'),
        compile=process, link=linked, actual_dependencies=b.pin(out / 'actual-dependencies.json'),
        runtime=b.pin(N / 'runtime.json'), inputs=b.pin(N / 'link-inputs.json'), frozen=b.pin(N / 'freeze.json')))
    print('READY', json.dumps(b.pin(N / 'ready.json')), flush=True)


def run(backend):
    assert backend in ['cpu', 'cuda']
    ready = b.read(N / 'ready.json'); b.exact(ready['image'])
    h = b.helper()
    cl = b.read(N / 'recipe.json')['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': cl,
        'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    command = [ready['image']['path'], '--' + backend,
        str(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'), '--mtp-batch-state']
    out = N / ('run-' + backend)
    assert not out.exists()
    process = h.execute(command, env, out, timeout=90)
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    assert report['status'] == 'PASS' and report['backend'] == backend and report['final_versions'] == 0
    b.save(out / 'report.json', report)
    b.save(out / 'success.json', dict(process=process, image=ready['image'], report=b.pin(out / 'report.json')))
    print('PASS', backend, flush=True)


if __name__ == '__main__':
    try:
        if sys.argv[1] == 'build': build()
        else:
            assert sys.argv[1] == 'run'
            run(sys.argv[2])
    except Exception:
        b.save(N / ('failure-' + '-'.join(sys.argv[1:]) + '.json'), dict(error=traceback.format_exc(), note='Stopped; first source/command/process/output retained. No automatic retry.'))
        raise
