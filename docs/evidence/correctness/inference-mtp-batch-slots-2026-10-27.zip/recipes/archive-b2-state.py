from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd(); W=R/'.scratch/inference-engine-slot-state-20261027'; B=W/'b2-mtp-state'
P=R/'docs/evidence/correctness/inference-mtp-batch-slots-2026-10-27'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def data(j):return (json.dumps(j,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def h(b):return hashlib.sha256(b).hexdigest()
def save(p,j):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data(j))
summary=read(B/'run-summary.json')
base_json=R/'docs/evidence/correctness/inference-engine-slot-state-2026-10-27.json';base_zip=base_json.with_suffix('.zip')
baseline=read(W/'mixed/link-inputs.json'); final=read(B/'attempt3/link-inputs.json')
key=lambda x:(x['path'].casefold(),x['sha256'])
bm={key(x):x for x in baseline};fm={key(x):x for x in final}
removed=[x for k,x in bm.items() if k not in fm];added=[x for k,x in fm.items() if k not in bm]
assert len(baseline)==len(final)==223 and len(removed)==len(added)==1 and len(set(bm)&set(fm))==222
closure={'baseline_public_receipt':pin(base_json),'baseline_public_archive':pin(base_zip),
 'baseline_member':'records/mixed/link-inputs.json','baseline_input_manifest':pin(W/'mixed/link-inputs.json'),
 'final_input_manifest':pin(B/'attempt3/link-inputs.json'),'baseline_inputs':223,'final_inputs':223,'identical_reused_inputs':222,
 'removed':removed,'added':added,'derivation':'Retain the 222 exact baseline inputs and replace only the old combined probe object with the final compiled combined probe. The original weights/report/common/native objects and SDKs are reused, not rebuilt.',
 'standalone_Model_or_engine_entry_object_included':False,'new_translation_unit':'tests/tools/qwen_host_image_test.cc (includes the exact frozen main.cc and all case headers)'}
save(B/'closure-delta.json',closure)
# Keep only bounded metadata and source snapshots. No glob of the SDK or model payload.
entries={}
def add(p,name):
 assert p.is_file(),str(p)
 assert p.suffix.lower() not in ['.exe','.obj','.pdb','.dll','.lib','.bin','.safetensors'],str(p)
 assert name not in entries,name
 entries[name]=p.read_bytes()
for script in ['b2-state.py','b2-state2.py','b2-state3.py','archive-b2-state.py']:
 add(W/script,'recipes/'+script)
for relative in ['run-summary.json','closure-delta.json','freeze.json','source-freeze.json','recipe.json','failure-build.json']:
 add(B/relative,'records/attempt1/'+relative)
for f in ['command.json','process.json','stdout.log','stderr.log','dependencies.json']:
 add(B/'compile'/f,'records/attempt1/compile/'+f)
for attempt in ['attempt2','attempt3']:
 for f in ['freeze.json','source-freeze.json','recipe.json','ready.json','runtime.json']:
  add(B/attempt/f,'records/'+attempt+'/'+f)
 for phase in ['compile','link']:
  for f in ['command.json','process.json','stdout.log','stderr.log']:
   add(B/attempt/phase/f,'records/'+attempt+'/'+phase+'/'+f)
 for f in ['dependencies.json','actual-dependencies.json']:
  add(B/attempt/'compile'/f,'records/'+attempt+'/compile/'+f)
for attempt,arm in [('attempt2','cpu'),('attempt3','cpu'),('attempt3','cuda')]:
 for f in ['command.json','process.json','stdout.log','stderr.log']:
  add(B/attempt/('run-'+arm)/f,'records/'+attempt+'/run-'+arm+'/'+f)
 if attempt=='attempt3':
  for f in ['report.json','success.json']:
   add(B/attempt/('run-'+arm)/f,'records/'+attempt+'/run-'+arm+'/'+f)
add(B/'attempt2/failure-run-cpu.json','records/attempt2/failure-run-cpu.json')
for label,p in [('attempt1',B/'source/tests/tools/qwen_mtp_batch_state_case.h'),('attempt2',B/'attempt2/source/tests/tools/qwen_mtp_batch_state_case.h'),('final',B/'attempt3/source/tests/tools/qwen_mtp_batch_state_case.h')]:
 add(p,'source/case-'+label+'.h')
add(B/'attempt3/source/tests/tools/qwen_host_image_test.cc','source/tests/tools/qwen_host_image_test.cc')
add(B/'attempt3/source/engine/models/qwen35/main.cc','source/engine/models/qwen35/main-2709af3d.cc')
# Session header and main3b are byte-identical to the prior evidence, referenced by member.
with zipfile.ZipFile(base_zip) as old:
 for member,sha in [('source/engine/models/qwen35/main.cc','3b1a2c6996a8c7a3cd3c654526abd1bbb9a033a0a809e68ff6063ede8b61812f'),('source/engine/models/qwen35/session_state.h','e393af9522901f73bab16801054e7c4761ca836f87b15003902f6b7c279ce2bd')]:
  assert h(old.read(member))==sha,(member,sha)
manifest=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input/weights.tsv'
add(manifest,'fixture/weights.tsv')
receipt={
 'date':'2026-10-27','platform':'Windows, existing mixed CPU/CUDA validation closure','status':'PASS_WITH_PRESERVED_TEST_AUTHORING_FAILURES',
 'purpose':'Real B2/K3 MTP verification commits different accepted prefixes into the original per-layer conv/GDN lease pools, then continues with reversed lengths. This is controlled state-wiring coverage, not natural acceptance quality.',
 'counts':summary['counts'],'source_versions':[
  {'attempts':['compile1 failed','compile2 and its CPU setup-failure process'],'main_sha256':'3b1a2c6996a8c7a3cd3c654526abd1bbb9a033a0a809e68ff6063ede8b61812f','main_archive_reference':'prior engine-slot-state ZIP source/engine/models/qwen35/main.cc'},
  {'attempts':['compile3','final CPU and CUDA processes'],'main_sha256':'2709af3dc68494634b106cc2d0b7bce6efcde0de4ff023838a6f10080b469a42','main_archive_member':'source/engine/models/qwen35/main-2709af3d.cc','performance_measured':False}],
 'session_header_sha256':'e393af9522901f73bab16801054e7c4761ca836f87b15003902f6b7c279ce2bd',
 'observed_independent_pool_indices':summary['observed_independent_pool_indices'],
 'fixture_manifest':pin(manifest),'scope':summary['scope'],'successful_runs':summary['successful_runs'],
 'preserved_failures':summary['preserved_failures'],'actual_final_ready':summary['ready'],
 'compile_processes':[read(B/'compile/process.json'),read(B/'attempt2/compile/process.json'),read(B/'attempt3/compile/process.json')],
 'link_processes':[read(B/'attempt2/link/process.json'),read(B/'attempt3/link/process.json')],
 'closure':closure,'limitations':summary['limits'],
 'archive_policy':'Only new source snapshots, commands, dependency identities, bounded receipts and stdout/stderr are included. Baseline 223-input closure and identical sources are referenced by exact prior public archive. No SDK/header tree, weights payload, OBJ, library, executable or PDB is archived.'}
entries['receipt.json']=data(receipt)
member_manifest=[{'path':name,'bytes':len(value),'sha256':h(value)} for name,value in sorted(entries.items())]
entries['members.json']=data(member_manifest)
P.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(P.with_suffix('.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,value in sorted(entries.items()):z.writestr(name,value)
with zipfile.ZipFile(P.with_suffix('.zip')) as z:
 assert z.testzip() is None
 for row in member_manifest:assert h(z.read(row['path']))==row['sha256']
 assert not any(n.endswith(('.obj','.exe','.dll','.lib','.pdb','.safetensors')) for n in z.namelist())
receipt['archive']={**pin(P.with_suffix('.zip')),'entries':len(entries),'uncompressed_bytes':sum(map(len,entries.values())),'member_sha256_and_crc_verified':True}
save(P.with_suffix('.json'),receipt)
print(json.dumps({'receipt':pin(P.with_suffix('.json')),'archive':receipt['archive']}))
