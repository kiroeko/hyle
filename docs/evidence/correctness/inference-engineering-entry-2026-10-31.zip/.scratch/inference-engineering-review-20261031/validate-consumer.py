from pathlib import Path
import json,os,subprocess,sys,time
D=Path(__file__).resolve().parent;R=D.parents[1]
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'scripts'))
import hyle_support as support
from hyle_environment import discover_environment
cache=support.read_cache(D/'util-build');e=discover_environment(cache=cache)
e.env['TMP']=e.env['TEMP']=str(D/'temp')
steps=[('consumer-configure',[e.cmake,'-S',str(D/'consumer'),'-B',str(D/'consumer-build'),'-G',e.generator,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(D/'util-install'),'-DCMAKE_CXX_COMPILER='+e.cxx,'-DCMAKE_MAKE_PROGRAM='+e.definitions['CMAKE_MAKE_PROGRAM']]),('consumer-build',[e.cmake,'--build',str(D/'consumer-build'),'--parallel','2']),('consumer-run',[str(D/'consumer-build/util_consumer.exe')])]
results=[]
for name,command in steps:
    tick=time.monotonic()
    with (D/(name+'.stdout.log')).open('wb') as out,(D/(name+'.stderr.log')).open('wb') as err:
        code=subprocess.run(command,cwd=R,env=e.env,stdout=out,stderr=err).returncode
    row=dict(stage=name,command=command,exit_code=code,seconds=time.monotonic()-tick);results.append(row)
    (D/'consumer-results.json').write_text(json.dumps(dict(state='RUNNING' if code==0 else 'FAILED',results=results),indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if code:raise SystemExit(code)
(D/'consumer-results.json').write_text(json.dumps(dict(state='PASS_INSTALLED_UTIL_CONFIGURE_BUILD_RUN',results=results,model_or_GPU_processes=0,download_requests=0),indent=2)+'\n')
