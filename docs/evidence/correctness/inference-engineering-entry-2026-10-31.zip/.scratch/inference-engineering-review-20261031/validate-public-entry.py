from pathlib import Path
import contextlib,datetime,hashlib,json,os,sys,time
R=Path(__file__).resolve().parents[2]
D=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'scripts'))
import hyle_support as support
# Redirect only the test's current-selection metadata; use the real source,
# tool discovery, CMake subprocesses, build and install implementation.
support._current=lambda:D/'selected.json'
temp=D/'temp';temp.mkdir(exist_ok=True)
os.environ['TMP']=os.environ['TEMP']=str(temp)
steps=[('init','init',['--build-dir',str(D/'util-build'),'--components','util','--cache-dir','C:/public/tools/hyle-dependencies/v1','--offline']),('repeat-init','init',[]),('build-install','build',['--install',str(D/'util-install')])]
results=[]
for name,action,args in steps:
    tick=time.monotonic()
    with (D/(name+'.stdout.log')).open('w',encoding='utf-8') as out,(D/(name+'.stderr.log')).open('w',encoding='utf-8') as err:
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):code=support.main(action,args)
    results.append(dict(stage=name,action=action,args=args,exit_code=code,seconds=time.monotonic()-tick))
    (D/'real-entry-results.json').write_text(json.dumps(dict(state='RUNNING' if code==0 else 'FAILED',results=results),indent=2)+'\n')
    print(json.dumps(results[-1]),flush=True)
    if code:raise SystemExit(code)
cache=support.read_cache(D/'util-build')
assert cache['HYLE_COMPONENTS']=='util'
assert cache['HYLE_BUILD_TESTS']=='OFF' and cache['HYLE_STATIC']=='OFF'
assert cache['FETCHCONTENT_FULLY_DISCONNECTED']=='ON' and cache['FETCHCONTENT_UPDATES_DISCONNECTED']=='ON'
assert not cache.get('HYLE_COMPUTE_ROUTES')
assert (D/'util-install/lib/cmake/Hyle/HyleConfig.cmake').is_file()
summary=dict(state='PASS_REAL_OFFLINE_INIT_REPEAT_BUILD_INSTALL',results=results,source=str(R),components=cache['HYLE_COMPONENTS'],routes=cache.get('HYLE_COMPUTE_ROUTES'),shared=True,tests=False,offline=True,selection_metadata_redirected_only=str(D/'selected.json'),model_or_GPU_processes=0,download_requests=0,limits='Real Windows installed tools and selected util closure only; no cross-platform or all-product build claim.')
(D/'real-entry-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'state':summary['state'],'stages':len(results)}),flush=True)
