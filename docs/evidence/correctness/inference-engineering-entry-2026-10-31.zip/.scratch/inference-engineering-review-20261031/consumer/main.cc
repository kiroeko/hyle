#include <hyle/util/demangle.h>
#include <cstring>
int main() { char output[32]{}; return hyle::util::demangle("literal", output, sizeof(output)) == 7 && std::strcmp(output, "literal") == 0 ? 0 : 1; }
