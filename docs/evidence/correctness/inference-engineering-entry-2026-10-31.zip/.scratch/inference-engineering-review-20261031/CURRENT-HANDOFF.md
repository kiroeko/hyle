# 当前接续：工程入口复审已交付，继续架构与普通流水

main/origin/main：`f3173816059d6023af3958d276b8521a77ed4b3e`，已push；当前产品工作树干净。完整goal仍active，不完成或缩小。源库Windows为准，下载PAUSED，不启动额外模型获取。

## 用户最新顺序

先完成共同执行架构与普通连续流水的真实剩余项；CMake、初始化脚本和文档也纳入工程复审。独立性能候选和后续比较暂缓。相关有限正确性、真实费用及明显退化检查可继续。不要再把架构95%和普通流水81%改说全部完成，不重开已完成MTP／多模态功能穷尽。

权威完整目标：docs/implementation/inference-roadmap.md#当前-goal-范围全部-review-应对。当前任务与约83%整体、95%架构、81%普通流水都在已精简为约100行的docs/developer/inference-progress.md；100仅当前已列范围。

## 已交付，不重复

- 76a9c95f0：正常shared GPU产品首轮真实C2375，修batch.h三friend导出宏后同cache59步/59.688s成功；CPU ordinary/CUDA K1各4输出、外部3符号import/export通过。正常镜像80ab6462…41a3，源18pins含batch.h。两个公开shared/fullV证据包均由root独立全成员bytes/SHA核验后提交。
- 正常default fullV32进程全部exit0，24timing/8memory；ordinary单/双99.07467/101.33430 vs101.96072/102.07512，MTP121.46985/133.88423 vs135.73388/140.88282。MTP仍落后10.51%/4.97%。16Hyle vocab四字段0、实际relay及versions0；全部ready未知，2次Enum299有限快照缺口保留。peer精确d9e03f10+GGML456172ec及资源/错误清理patch，不称最新。
- 当前f31738160：hyle_support.py按key presence拒绝空DEV_FACTORS，匹配CMake DEFINED；修custom dependency/source layout错误提示。回归旧代码真red，最终68脚本测试通过。
- 真实Windows离线util init/repeat-init/build-install、独立find_package util consumer配置/编译/运行全0；无GPU/模型/下载。验证只将_current元数据重定向到本scratch，未改用户当前配置。结果real-entry-results.json、consumer-results.json、final-checks.json（643链接）在本目录。
- 四入门页重组：默认CPU/Release/shared/engine先可见；具名init/build一致；scripts不重复setup；README旧性能表只链接唯一记录；codec/量化验证细节后移。保README CRLF和另3页原LF。正常help5项、69链接/21示例的原核验在.scratch/inference-engineering-docs-edit-20261031，root后续改了更明确的应用API文字并统一检查643链接。
- CMake正式static/tests/install/bench/trace/sanitizer/WERROR/ISA均有真实语义；未找到可批量删除开关，不为数量删能力。不凭一次normal构建代签所有平台/产品/安装组合。

## 跟踪现在是什么状态

.scratch/inference-default-profile-20261031只新增1main CXX+1link的NVTX镜像1d5d86d7…c23d6，保8app/6cold和正常SDK。StepState布局不改，main-only旁表标注，原default image不覆盖。
仅r1-auto已实际运行，Nsys3292 exit0/6.792s，真实CUDA PID12220；wrapper初次exit1为stdout提取StopIteration，原producer在SQLite ProcessStreams。已从原SQLite离线补齐，完整非时间报告对normal ordinary baseline差异0，64 roots/63decode，begun=ended64/unfinished0/归属冲突0。GPU union612.707388ms+idle61.474122ms，仅结构诊断，不是TPS。原失败保留、0模型重跑。
r1-peer/mtp-hyle/mtp-peer未启动，runs目录不存在；profile-steering-stop.json明确停后续。不要自动续4臂。

## 下一项普通流水工作

实际未完：跨turn时reset_reuse清direction_warm/ready_steps，planned只建carrier不capture；稳态仍有分项同步IO/每step装配。跨pump核心控制/credit/取消/背压/16臂已有实现与有限证据，不重开。

具体可行性稿：.scratch/inference-input-upload-feasibility-20261031/README.md、packet-api-sketch.cc、source-pins.json。UNCOMPILED/UNAPPLIED，尚无产品修改/通过结论。

推荐每exact Phase/physical slot一个原Tensor持有对齐packet，原端口用BufferView.subview和ConstTensorView.create裁成exact ranges，经ProgramIo.add_fixed借用；token起0，position起align_up(token_bytes,256)，同slot host staging一次write。原Tensor预算分支仍pool/writer，默认nonbudget仍Buffer；绝不强制转owner来套CopyBatch。CUDA现write是HtoD+默认流sync，两字段可以合一次；padding和host staging要真实计费/上传。

先核真实接口和上下游后实现：不能跨slot共享，继续原carrier.borrow/Source/三槽退休门；无效extent先拒，write失败走原未提交episode abort，下一submit前整包重新写完，真实device error不自动重试。relay token必须仍来自primary_output.reader_binding，不复制未知device token。普通R1稳态relay本来只有positions一次上传，首片非imported普通tokens+positions不能宣称稳态提速或40%叶完成；后续其它确定字段/metadata/读回/捕获复用继续。

## 资源与操作

正常CMake cache .scratch/build-compute-v2-dev已完整ready，优先复用。旧手工closure依赖的12static库已隔离到.scratch/inference-default-product-build-20261031/baseline-libs；若后续手工重链用aux-preserved-model-link-base.json/m2-preserved-model-link-base.json，不能用已被normal shared build替换的原bin库。
root旧test.ps1是已执行790文件清理脚本，不再运行。任何新清理先写精准目标并验证。无后台工作时仍需实际CIM/session核对，不能依此文假定。
