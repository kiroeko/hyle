from pathlib import Path
import hashlib,json,re,subprocess,sys,time,unicodedata
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
files=['README.md','scripts/README.md','docs/developer/setup/README.md','docs/user/inference.md','docs/developer/inference-progress.md','docs/implementation/inference-roadmap.md','docs/developer/performance/decode.md','docs/architecture/inference-design.md']
def slug(text):
    text=text.strip().lower()
    text=''.join(c for c in text if not unicodedata.category(c).startswith(('P','S')) or c in '-_')
    return text.replace(' ','-')
links=[];issues=[]
for name in files:
    path=R/name;text=path.read_text(encoding='utf-8-sig')
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)',text):
        if re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:',target):continue
        part,sep,anchor=target.partition('#');dest=(path.parent/part).resolve() if part else path
        if not dest.exists():issues.append(dict(source=name,target=target,error='missing target'));continue
        if anchor and dest.suffix=='.md':
            headings=[slug(h) for h in re.findall(r'^#{1,6}\s+(.+?)\s*$',dest.read_text(encoding='utf-8-sig'),re.M)]
            explicit=re.findall(r'(?:id|name)=["\']([^"\']+)',dest.read_text(encoding='utf-8-sig'))
            if anchor not in headings+explicit:issues.append(dict(source=name,target=target,error='missing heading'))
        links.append(dict(source=name,target=target))
assert not issues,issues
stages=[]
for filename in ['development_scripts_test.py','bootstrap_environment_test.py','bootstrap_resources_test.py']:
    command=[sys.executable,'-B',str(R/'tests/tooling'/filename)];tick=time.monotonic()
    q=subprocess.run(command,cwd=R,capture_output=True)
    (D/(filename+'.stdout.log')).write_bytes(q.stdout);(D/(filename+'.stderr.log')).write_bytes(q.stderr)
    count=re.search(rb'Ran (\d+) tests?',q.stdout+q.stderr)
    stages.append(dict(command=command,exit_code=q.returncode,tests=int(count.group(1)) if count else None,seconds=time.monotonic()-tick))
    assert q.returncode==0,filename
for key in ['HYLE_DEP_BUILD_DIR','CMAKE_HOME_DIRECTORY']:
    q=subprocess.run([sys.executable,'-B',str(R/'scripts/init.py'),'--dry-run','-D',key+'=custom'],cwd=R,capture_output=True)
    assert q.returncode==2 and b'CMake directly' in q.stderr and b'--build-dir' in q.stderr
    stages.append(dict(case='unsupported custom layout: '+key,exit_code=q.returncode,expected_rejection=True))
for name,state in [('real-entry-results.json','PASS_REAL_OFFLINE_INIT_REPEAT_BUILD_INSTALL'),('consumer-results.json','PASS_INSTALLED_UTIL_CONFIGURE_BUILD_RUN')]:assert json.loads((D/name).read_text())['state']==state
summary=dict(status='PASS_ENGINEERING_ENTRY_REVIEW_CHECKS',unit_tests=sum(x.get('tests',0) or 0 for x in stages),checked_local_links=len(links),stages=stages,files=[dict(path=name,bytes=(R/name).stat().st_size,sha256=hashlib.sha256((R/name).read_bytes()).hexdigest()) for name in files+['scripts/hyle_support.py','tests/tooling/development_scripts_test.py']],real_tools='Windows actual offline init/repeat/build/install and independent installed util consumer passed; only selection metadata redirected inside scratch.',limitations='No new model/GPU or cross-platform execution; CMake public options reviewed from current source, not a proof of every build combination.',preserved_history='New cache regression was red on old code; first edit assertion did not change source, later corrected with original LF preserved. No native/model reruns.')
(D/'final-checks.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k in ('status','unit_tests','checked_local_links')}))
