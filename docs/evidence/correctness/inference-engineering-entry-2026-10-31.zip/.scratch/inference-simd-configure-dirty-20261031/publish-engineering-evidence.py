"""Seal existing finite engineering receipts; no builds or tests are run."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
ENTRY = ROOT / '.scratch/inference-engineering-review-20261031'
DOCS = ROOT / '.scratch/inference-engineering-docs-edit-20261031'
VALIDATION = ROOT / '.scratch/inference-kimi-component-boundary-20261031/validation'
COMMIT = 'f3173816059d6023af3958d276b8521a77ed4b3e'
DEST = ROOT / 'docs/evidence/correctness/inference-engineering-entry-2026-10-31'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def rel(path):
    return Path(path).relative_to(ROOT).as_posix()

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

files = {}
def add(path):
    path = Path(path)
    assert path.is_file(), path
    assert path.suffix.lower() not in {'.exe', '.dll', '.obj', '.lib', '.sqlite', '.ncu-rep', '.nsys-rep'}
    name = rel(path)
    data = path.read_bytes()
    if name in files:
        assert files[name]['data'] == data
    files[name] = {'data': data, 'source': name}

engineering = load(BATCH / 'engineering-evidence-draft.json')
final = load(ENTRY / 'final-checks.json')
real = load(ENTRY / 'real-entry-results.json')
consumer = load(ENTRY / 'consumer-results.json')
docs = load(DOCS / 'verification.json')
assert final['unit_tests'] == 68
for filename, expected in [('development_scripts_test.py', 41),
                           ('bootstrap_environment_test.py', 22),
                           ('bootstrap_resources_test.py', 5)]:
    text = (ENTRY / (filename + '.stderr.log')).read_text()
    assert re.search(r'Ran ' + str(expected) + r' tests?\b', text) and '\nOK\n' in text
assert all(item['exit_code'] == 0 for item in real['results'] + consumer['results'])
assert docs['actual_help_commands'] == 5
for name in ['init', 'build', 'test', 'engine', 'prepare']:
    assert load(DOCS / 'help' / name / 'result.json')['exit_code'] == 0

# Historical source identities are taken from their actual commit, never from
# the changing current board or a new file labelled as the older source.
snapshot = BATCH / 'entry-source-f31738160'
source_paths = ['scripts/hyle_support.py', 'scripts/init.py', 'scripts/build.py',
    'scripts/test.py', 'tests/tooling/development_scripts_test.py',
    'tests/tooling/bootstrap_environment_test.py', 'tests/tooling/bootstrap_resources_test.py',
    'README.md', 'scripts/README.md', 'docs/developer/setup/README.md', 'docs/user/inference.md']
historical_pins = []
for relative in source_paths:
    result = subprocess.run(['git', 'show', COMMIT + ':' + relative], cwd=ROOT,
                            capture_output=True, check=True)
    path = snapshot / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == result.stdout
    else:
        path.write_bytes(result.stdout)
    add(path)
    historical_pins.append({'path': relative, 'commit': COMMIT,
        'bytes': len(result.stdout), 'sha256': digest(result.stdout), 'archive_member': rel(path)})
for item in final['files']:
    if item['path'] in source_paths:
        actual = next(pin for pin in historical_pins if pin['path'] == item['path'])
        assert actual['sha256'] == item['sha256'], item['path']

for path in ENTRY.iterdir():
    if path.is_file() and path.suffix in {'.json', '.py', '.log', '.md'}:
        add(path)
for path in (ENTRY / 'consumer').glob('*'):
    if path.is_file() and path.suffix in {'.cc', '.txt'}:
        add(path)
for name in ['verification.json', 'verification-uniform-crlf-superseded.json',
             'before-pins.json', 'eol-correction.json', 'verify.py']:
    add(DOCS / name)
for path in (DOCS / 'help').rglob('*'):
    if path.is_file() and path.name in {'result.json', 'stdout.log', 'stderr.log'}:
        add(path)
for path in (DOCS / 'before').rglob('*'):
    if path.is_file() and path.suffix == '.md':
        add(path)

for name in ['summary.json', 'engineering-evidence-draft.json',
             'engineering-draft-preparation-attempt1.json', 'normal-generated-before-fix.json',
             'simd-configure-stability.patch', 'HEAD-HyleDispatch.cmake',
             'old-module-only-include.diff', 'old-module-regression.py',
             'prepare-engineering-evidence.py', 'publish-engineering-evidence.py']:
    add(BATCH / name)
for path in (BATCH / 'old-red-attempt1').iterdir():
    if path.is_file(): add(path)
for path in (BATCH / 'baseline').rglob('*'):
    if path.is_file(): add(path)
for item in engineering['source_pins']:
    path = ROOT / item['path']
    data = path.read_bytes()
    assert digest(data) == item['sha256']
    add(path)

fixture_names = ['configure-06spqf9v', 'configure-0ed9982c', 'configure-nveo_ncf',
                 'configure-lz4yew46', 'configure-oiznvghx']
for name in fixture_names:
    directory = ROOT / '.scratch/validation/simd-configure-generation' / name
    for attempt in directory.glob('configure-*'):
        for path in attempt.iterdir():
            if path.is_file(): add(path)
    if (directory / 'verification.json').exists(): add(directory / 'verification.json')
    for path in (directory / 'source').iterdir():
        if path.is_file(): add(path)

control = VALIDATION / 'control'
for folder in ['configure/attempt1', 'configure/attempt2', 'explain/attempt1',
               'build/attempt1', 'build/attempt2', 'build/attempt3',
               'module-configure/attempt1', 'module-configure/attempt2',
               'module-configure/attempt3', 'module-build/attempt1', 'module-ctest/attempt1']:
    for name in ['command.json', 'process.json', 'result.json', 'stdout.log',
                 'stderr.log', 'simd-generated-stability.json']:
        path = control / folder / name
        if path.is_file(): add(path)
for name in ['approved-consumer-state-owner.json', 'approved-consumer-graph-private-include.json']:
    add(VALIDATION / name)
add(ROOT / '.scratch/inference-captured-graph-copy-20261031/normal-test-commands.json')
add(ROOT / '.scratch/inference-captured-graph-copy-20261031/prepare-normal-test-commands.py')
add(ROOT / '.scratch/build-compute-v2-dev/tests/CTestTestfile.cmake')

public = {
    'schema': 'hyle.finite-engineering-evidence.v1',
    'date': '2026-10-31', 'status': 'PASS_WITH_RETAINED_HISTORICAL_FAILURES_AND_LIMITS',
    'scope': 'Engineering entry scripts/docs, Windows offline util install/consumer, configure-time SIMD stability, existing test ownership and private include correction. No new model/GPU/performance claim.',
    'entry_commit': COMMIT, 'historical_source_pins': historical_pins,
    'current_engineering_source_pins': engineering['source_pins'],
    'checks': {
        'script_unit_tests': {'passed': 68, 'groups': [41, 22, 5],
            'expected_custom_layout_rejections': 2, 'expected_exit_code': 2,
            'receipt': rel(ENTRY / 'final-checks.json')},
        'windows_offline_util': {'passed_stages': [item['stage'] for item in real['results'] + consumer['results']],
            'all_six_stage_exits_zero': True, 'components': 'util', 'shared': True,
            'offline': True, 'tests_enabled': False,
            'selection_metadata_redirected_only': True,
            'receipts': [rel(ENTRY / name) for name in ['real-entry-results.json', 'consumer-results.json']]},
        'docs': {'actual_help_commands_passed': 5, 'help_names': ['init', 'build', 'test', 'engine', 'prepare'],
            'original_document_local_links': 69, 'examples_checked_against_real_help': 21,
            'later_full_document_local_links': 643,
            'link_counts_are_distinct_reviews_not_added': True,
            'original_EOL_preserved': True,
            'receipts': [rel(DOCS / 'verification.json'), rel(ENTRY / 'final-checks.json')],
            'historical_note': 'The earlier docs verification preceded final root wording; final f317 source pins are authoritative. The superseded uniform-CRLF result is retained as history, not current proof.'},
        'simd_generator': {'one_regression_test_configurations': 9,
            'manual_full_passes': 2, 'registered_ctest_full_passes': 1,
            'same_configuration_bytes_and_mtime_stable': True,
            'fat_exact_roundtrip': True, 'multi_target_own_target_union': True,
            'removed_kernels_reclaimed': True, 'unowned_outputs_preserved': True,
            'current_normal_generated_inputs_exact': 29,
            'old_code_red': {'actual_configure_exits': [0, 0], 'python_exit': 1,
                'same_generated_hashes': 5, 'changed_generated_mtimes': 5,
                'unrelated_outputs_deleted': ['keep.txt', 'foreign/foreign_scalar.cc'],
                'only_test_change_was_included_module': True},
            'details': rel(BATCH / 'engineering-evidence-draft.json')},
        'registered_ctest': {'exit_code': 0, 'passed': 2, 'failed': 0,
            'names': ['hyle_engine_components_test', 'hyle_simd_configure_generation_test'],
            'simd_labels': ['tooling', 'build', 'simd'], 'explicit_actual_CMAKE_COMMAND': True,
            'new_registration_switch': False, 'existing_gate': 'HYLE_BUILD_TESTS',
            'receipt': rel(control / 'module-ctest/attempt1/process.json')},
        'test_entry_repairs': engineering['test_entry_repairs']},
    'actual_cost': engineering['actual_one_time_simd_rebuild'],
    'retained_failures': [
        {'kind': 'expected old generator red', 'python_exit': 1, 'new_product_failure': False},
        {'kind': 'initial SIMD Python regression Windows separator KeyError',
         'underlying_configure_exits': [0, 0, 0],
         'limit': 'History note preserved; no independent initial wrapper process/stderr receipt was saved.'},
        {'kind': 'mixed normal build attempt1 Kimi ADD_FAILURE compile error', 'exit_code': 2,
         'scope': 'Not a SIMD compile failure; mixed build receipt retained. Kimi correctness is outside this engineering bundle.'},
        {'kind': 'module configure attempt1 missing native_fault_consumer owner', 'exit_code': 1,
         'fixed_by': 'Existing helper HYLE_TEST_MODULE metadata only; aggregate and CTest already existed.'},
        {'kind': 'offline evidence preparation assumption about missing old outputs.json',
         'exit_code': 1, 'configure_build_native_reruns': 0,
         'receipt': rel(BATCH / 'engineering-draft-preparation-attempt1.json')},
        {'kind': 'earlier entry empty-factor-cache regression red and first edit assertion',
         'receipt': rel(ENTRY / 'final-checks.json'),
         'limit': 'Retained original handoff/history statement; no separate raw old-red process receipt supplied, so no invented process count.'}],
    'limits': [
        'Windows installed tools and selected util closure only; not all products, platforms, build/install combinations or SIMD numerical kernels.',
        'LANGUAGES NONE fixtures prove actual CMake output generation and cleanup, not CXX/ISA execution.',
        '38 already-dirty SIMD CXX actions were genuinely paid once; old compiled generated-content pins were unavailable, and old mtimes were never restored.',
        'The 49.5-second mixed failed process includes 38 SIMD, 2 Graph and 4 Kimi CXX actions; no isolated SIMD wall time exists.',
        'Repeated output hash+mtime checks prove the inspected configurations, not every future generator use.',
        'The formal Graph test private-include fix was configured successfully; Graph test compile/link/native validation remains in its own evidence batch.',
        'Original superseded receipts remain historical. No util-build/install tree, SDK, models, DLLs, objects, binaries or SQLite is archived.',
        'This packaging step ran no configure, CXX, link, native model, GPU or download.']}

summary_bytes = (json.dumps(public, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
files['engineering-summary.json'] = {'data': summary_bytes, 'source': 'generated:summary-before-archive-binding'}
manifest = {'schema': 'hyle.archive-manifest.v1',
    'self_rule': 'manifest.json is checked by exact authored bytes and public manifest SHA; entries hash every other member, avoiding a self-referential hash.',
    'entries': [{'member': name, 'bytes': len(value['data']), 'sha256': digest(value['data']),
                 'source': value['source']} for name, value in sorted(files.items())]}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
files['manifest.json'] = {'data': manifest_bytes, 'source': 'generated:manifest'}
zip_path = DEST.with_suffix('.zip')
json_path = DEST.with_suffix('.json')
assert not zip_path.exists() and not json_path.exists(), 'Preserve published outputs'
zip_path.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, value in sorted(files.items()):
        archive.writestr(name, value['data'])
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(files)
    for name, value in files.items():
        assert archive.read(name) == value['data']
        if not value['source'].startswith('generated:'):
            assert (ROOT / value['source']).read_bytes() == value['data']
public['archive'] = {'path': rel(zip_path), 'bytes': zip_path.stat().st_size,
    'sha256': digest(zip_path.read_bytes()), 'members': len(files),
    'manifest_sha256': digest(manifest_bytes), 'readback': 'ALL_MEMBER_BYTES_SHA256_AND_CRC_PASS'}
json_path.write_text(json.dumps(public, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
receipt = {'public_json': {'path': rel(json_path), 'bytes': json_path.stat().st_size,
            'sha256': digest(json_path.read_bytes())}, 'archive': public['archive'],
    'archive_source_file_bytes_readback_passed': True, 'product_source_edits': 0,
    'configure_CXX_link_native_GPU_downloads': 0}
(BATCH / 'engineering-publication-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
