"""Re-read retained engineering receipts only; no configure/build/test execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
VALIDATION = ROOT / '.scratch/inference-kimi-component-boundary-20261031/validation'
FIXTURES = ROOT / '.scratch/validation/simd-configure-generation'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def relative(path):
    return Path(path).relative_to(ROOT).as_posix()

def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': relative(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

def fixture(name):
    directory = FIXTURES / name
    configurations = []
    for attempt in sorted(directory.glob('configure-*'),
                          key=lambda path: int(path.name.split('-')[-1])):
        result = read(attempt / 'result.json')
        assert result['exit_code'] == 0
        outputs = read(attempt / 'outputs.json') if (attempt / 'outputs.json').exists() else None
        configurations.append({'number': int(attempt.name.split('-')[-1]),
            'exit_code': result['exit_code'], 'outputs': outputs,
            'argv': read(attempt / 'command.json')})
    return directory, configurations

case_names = ['fat', 'same-fat-preserving-foreign-files', 'exact-avx2',
    'same-exact-avx2', 'back-to-fat', 'two-own-target-union-with-obsolete-family',
    'same-two-target-union', 'own-target-shrink-and-remove-obsolete-family',
    'same-shrunk-own-target']

def inspect_pass(name):
    directory, configurations = fixture(name)
    assert len(configurations) == 9
    if any(entry['outputs'] is None for entry in configurations):
        verification = read(directory / 'verification.json')
        assert verification['status'] == 'PASS'
        return {'fixture': relative(directory), 'verification': pin(directory / 'verification.json'),
            'configure_exits': [entry['exit_code'] for entry in configurations],
            'independent_recomputed_output_hash_and_mtime_assertions': False,
            'limit': 'Earlier manual pass retained configure results and verification but predates per-configure outputs.json; do not reconstruct missing historical output receipts.'}
    outputs = [entry['outputs'] for entry in configurations]
    for left, right in [(2, 3), (5, 6), (7, 8)]:
        assert outputs[left] == outputs[right]
    assert all(outputs[0][key] == outputs[1][key] for key in outputs[0])
    assert outputs[0]['kernel/kernel_avx2.cc'] == outputs[2]['kernel/kernel_avx2.cc']
    assert outputs[0]['kernel/kernel_avx2.cc'] == outputs[4]['kernel/kernel_avx2.cc']
    assert sum(key.startswith('shared/') for key in outputs[5]) == 4
    assert sum(key.startswith('obsolete/') for key in outputs[5]) == 4
    assert not any(key.startswith('kernel/') for key in outputs[5])
    assert sum(key.startswith('shared/') for key in outputs[7]) == 2
    assert not any(key.startswith('obsolete/') for key in outputs[7])
    for key in ['shared/shared_scalar.cc', 'shared/shared_avx2.cc']:
        assert outputs[5][key] == outputs[7][key]
    for key in ['foreign/foreign_scalar.cc', 'keep.txt']:
        assert outputs[1][key] == outputs[8][key]
    verification = read(directory / 'verification.json')
    assert verification['status'] == 'PASS'
    assert verification['configure_processes'] == 9
    return {'fixture': relative(directory), 'verification': pin(directory / 'verification.json'),
        'configurations': [{'number': entry['number'], 'case': case_names[index],
            'exit_code': 0, 'output_files': len(entry['outputs'])}
            for index, entry in enumerate(configurations)],
        'independent_recomputed_output_hash_and_mtime_assertions': True}

summary = read(BATCH / 'summary.json')
source_pins = [pin(ROOT / item) for item in [
    'cmake/HyleDispatch.cmake', 'tests/CMakeLists.txt',
    'tests/tooling/simd_configure_generation_test.py',
    'tests/compute_state/CMakeLists.txt', 'tests/graph/CMakeLists.txt']]
for old_pin in summary['source_pins']:
    actual = next(item for item in source_pins if item['path'] == old_pin['path'])
    assert actual['sha256'] == old_pin['sha256']

initial_directory, initial = fixture('configure-06spqf9v')
assert len(initial) == 3
passes = [inspect_pass(name) for name in [
    'configure-0ed9982c', 'configure-nveo_ncf', 'configure-oiznvghx']]
old_directory, old_runs = fixture('configure-lz4yew46')
assert len(old_runs) == 2
first, second = (entry['outputs'] for entry in old_runs)
assert set(first) == set(second)
assert all(first[key][0] == second[key][0] for key in first)
changed_mtimes = sum(first[key][1] != second[key][1] for key in first)
assert changed_mtimes == len(first) == 5
red = read(BATCH / 'old-red-attempt1/proof.json')
assert red['python_exit'] == 1
current_test = (ROOT / 'tests/tooling/simd_configure_generation_test.py').read_bytes()
old_test = (BATCH / 'old-module-regression.py').read_bytes()
old_include = b"            'include(\"" + (BATCH / 'HEAD-HyleDispatch.cmake').as_posix().encode() + b"\")\\n'"
current_include = b"            f'include(\"{ROOT.as_posix()}/cmake/HyleDispatch.cmake\")\\n'"
assert old_test.count(old_include) == 1
assert old_test.replace(old_include, current_include) == current_test

before = read(BATCH / 'normal-generated-before-fix.json')['files']
assert len(before) == 29
current_same = 0
for entry in before:
    path = Path(entry['path'])
    data = path.read_bytes()
    assert len(data) == entry['bytes']
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    assert path.stat().st_mtime_ns == entry['mtime_ns']
    current_same += 1

build = read(VALIDATION / 'control/build/attempt1/result.json')
simd_actions = [line for line in build['actions'] if 'Building CXX object src\\simd\\' in line]
assert len(simd_actions) == 38
later_builds = []
for folder in ['build/attempt2', 'build/attempt3', 'module-build/attempt1']:
    path = VALIDATION / 'control' / folder / 'result.json'
    data = read(path)
    assert data['receipt']['exit_code'] == 0
    assert not any('Building CXX object src\\simd\\' in line for line in data['actions'])
    later_builds.append({'receipt': pin(path), 'simd_cxx_actions': 0,
        'total_cxx_actions': data['cxx']})
ctest_dir = VALIDATION / 'control/module-ctest/attempt1'
ctest = read(ctest_dir / 'process.json')
ctest_stdout = (ctest_dir / 'stdout.log').read_text()
assert ctest['state'] == 'TERMINAL' and ctest['exit_code'] == 0
assert '100% tests passed out of 2' in ctest_stdout
assert 'hyle_simd_configure_generation_test ...   Passed' in ctest_stdout
registration = (ROOT / '.scratch/build-compute-v2-dev/tests/CTestTestfile.cmake').read_text()
assert '"--cmake" "C:/Program Files/CMake/bin/cmake.exe"' in registration
assert 'LABELS "tooling;build;simd"' in registration

configure_states = []
for relative_dir in ['configure/attempt2', 'module-configure/attempt1',
                     'module-configure/attempt2', 'module-configure/attempt3']:
    directory = VALIDATION / 'control' / relative_dir
    process = read(directory / 'process.json')
    configure_states.append({'name': relative_dir, 'process': pin(directory / 'process.json'),
        'exit_code': process['exit_code'], 'elapsed_seconds': process['elapsed_seconds']})

report = {
    'status': 'SCRATCH_ENGINEERING_EVIDENCE_DRAFT_RECOMPUTED_FROM_RETAINED_RECEIPTS',
    'date': '2026-10-31', 'source_pins': source_pins,
    'scope': 'SIMD configure output stability and two existing normal test registration repairs; not inference performance or general architecture completion.',
    'implementation_review': {
        'root_cause': 'The old manifest helper recursively deleted generated/simd-dispatch before file(CONFIGURE), rewriting equal headers/wrappers and deleting unrelated outputs.',
        'change': 'Keep file(CONFIGURE) write-if-changed; one configure-global union of selected outputs; root DEFER cleanup restricted to unselected known wrapper basename and exact own generated first-line marker.',
        'multi_target': 'Same binary directory, same NAME/IMPL, distinct target tier sets retain the union until all calls finish. This is derived configure metadata, not a product runtime owner.',
        'registration_switch_review': 'No new product/cache switch is needed or added. The existing HYLE_BUILD_TESTS gates tests/. The CTest is unconditionally registered inside that existing test scope, with tooling;build;simd and actual CMAKE_COMMAND; --cmake is only a regression script argument.',
        'limits': 'Fixture stubs hyle_set_isa and uses LANGUAGES NONE/custom targets: it proves generation ownership, selection, content/mtime and CMake APIs, not SIMD instruction semantics, compilation or ISA runtime.'},
    'initial_development_failure': {
        'classification': 'Python harness path normalization failure, not a CMake/native failure',
        'reason': 'KeyError kernel/kernel_avx2.cc because Windows relative path keys used backslashes; changed outputs() to as_posix.',
        'available_history': pin(BATCH / 'summary.json'),
        'fixture': relative(initial_directory), 'actual_configure_exits': [item['exit_code'] for item in initial],
        'separate_python_process_or_stderr_receipt': None,
        'receipt_limit': 'The exact first wrapper process/trace was not separately saved; the history note and all three actual configure receipts remain. No fabricated process receipt.'},
    'old_code_red': {
        'proof': pin(BATCH / 'old-red-attempt1/proof.json'),
        'process': pin(BATCH / 'old-red-attempt1/process.json'),
        'stderr': pin(BATCH / 'old-red-attempt1/stderr.log'),
        'old_module': pin(BATCH / 'HEAD-HyleDispatch.cmake'),
        'only_test_difference': pin(BATCH / 'old-module-only-include.diff'),
        'inverse_include_substitution_byte_exact': True,
        'configure_exits': [item['exit_code'] for item in old_runs],
        'python_exit': 1, 'classification': 'EXPECTED_OLD_RED_NOT_NEW_FAILURE',
        'same_generated_hashes': 5, 'changed_generated_mtimes': changed_mtimes,
        'unrelated_outputs_deleted': ['keep.txt', 'foreign/foreign_scalar.cc']},
    'regression_passes': passes,
    'ctest': {'process': pin(ctest_dir / 'process.json'),
        'command': pin(ctest_dir / 'command.json'), 'stdout': pin(ctest_dir / 'stdout.log'),
        'exit_code': 0, 'tests_passed': 2, 'tests_failed': 0,
        'names': ['hyle_engine_components_test', 'hyle_simd_configure_generation_test'],
        'elapsed_seconds': ctest['elapsed_seconds'],
        'simd_test_is_one_python_test_with_nine_real_configure_processes': True,
        'actual_generated_registration': pin(ROOT / '.scratch/build-compute-v2-dev/tests/CTestTestfile.cmake')},
    'normal_output_stability': {'baseline': pin(BATCH / 'normal-generated-before-fix.json'),
        'current_bytes_sha256_and_mtime_all_exact': current_same,
        'files': 29,
        'limits': 'These prove unchanged selected generated inputs across the new configurations. Historical compiled-content pins were unavailable; timestamps were never restored. This does not make the previous 38 dirty objects free or prove all future configurations.'},
    'actual_one_time_simd_rebuild': {
        'receipt': pin(VALIDATION / 'control/build/attempt1/result.json'),
        'simd_cxx_actions': 38, 'other_graph_sdk_cxx_actions': 2,
        'kimi_consumer_cxx_actions': 4, 'total_cxx_actions': build['cxx'],
        'cuda_actions': build['cuda'], 'whole_mixed_process_elapsed_seconds': build['receipt']['elapsed_seconds'],
        'whole_mixed_process_exit_code': build['receipt']['exit_code'],
        'whole_process_failure': 'Kimi test helper ADD_FAILURE identifier missing; separate retained CXX failure, not SIMD compile failure.',
        'isolated_simd_wall_seconds': None,
        'subsequent_builds': later_builds},
    'normal_configurations': configure_states,
    'test_entry_repairs': [
        {'file': 'tests/compute_state/CMakeLists.txt',
         'receipt': pin(VALIDATION / 'approved-consumer-state-owner.json'),
         'old_failure': pin(VALIDATION / 'control/module-configure/attempt1/stderr.log'),
         'fix': 'Set HYLE_TEST_MODULE compute_state on existing native_fault_consumer; aggregate dependency and CTest already existed.',
         'actual_after': 'module-configure attempt2 exit0; no new backend or test scope.'},
        {'file': 'tests/graph/CMakeLists.txt',
         'receipt': pin(VALIDATION / 'approved-consumer-graph-private-include.json'),
         'before_commands': pin(ROOT / '.scratch/inference-captured-graph-copy-20261031/normal-test-commands.json'),
         'fix': 'Add PRIVATE src/graph beside existing src/compute for formal hyle_graph_executable_test; bare private includes otherwise unresolved.',
         'actual_after': 'module-configure attempt3 exit0; successful configure does not itself prove Graph test CXX/link/native.'}],
    'read_only_review_actions': {'product_edits': 0, 'configure': 0, 'CXX': 0,
        'link': 0, 'native': 0, 'GPU': 0, 'downloads': 0},
    'preserved_history': 'Older summary.json says CTest not yet run; retain it as historical. This draft records later actual module CTest receipts without rewriting that history.'}
destination = BATCH / 'engineering-evidence-draft.json'
assert not destination.exists()
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'draft': str(destination), 'bytes': destination.stat().st_size,
    'manual_full_passes': 2, 'ctest_full_passes': 1, 'old_red': True,
    'normal_unchanged_generated_files': current_same, 'actual_simd_cxx': 38,
    'new_execution': 0}))
