"""Read actual Ninja recipes; never invoke a build or configuration."""
import ctypes
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
BUILD = ROOT / '.scratch/build-compute-v2-dev'
NINJA = Path(r'C:/Program Files/Python314/Scripts/ninja.exe')
cache = (BUILD / 'CMakeCache.txt').read_text(encoding='utf-8')
NINJA = Path(re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$', cache, re.M)[1])

def pin(path):
    path = Path(path)
    if not path.is_file():
        return {'path': str(path), 'exists': False}
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

def argv(command):
    count = ctypes.c_int()
    call = ctypes.windll.shell32.CommandLineToArgvW
    call.argtypes = (ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int))
    call.restype = ctypes.POINTER(ctypes.c_wchar_p)
    result = call(command, ctypes.byref(count))
    if not result:
        raise ctypes.WinError()
    try:
        return [result[i] for i in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree(ctypes.cast(result, ctypes.c_void_p))

manifest = pin(BUILD / 'build.ninja')
queries = []
def query(arguments):
    actual = [str(NINJA), *arguments]
    result = subprocess.run(actual, cwd=BUILD, capture_output=True, text=True)
    queries.append({'argv': actual, 'cwd': str(BUILD),
                    'exit_code': result.returncode, 'stderr': result.stderr,
                    'stdout_bytes_utf8': len(result.stdout.encode('utf-8'))})
    result.check_returncode()
    return result.stdout

targets = [('cpu', 'region_provider_test.cc', 'hyle_graph_executable_test'),
           ('cuda', 'output_source_cuda_test.cc', 'hyle_graph_slots_cuda_test')]
rules = ['CXX_COMPILER__' + target + '_unscanned_Release' for _, _, target in targets]
database = json.loads(query(['-t', 'compdb', '-x', *rules]))
cases = []
for name, filename, target in targets:
    entries = [entry for entry in database
               if Path(entry['file']).name == filename]
    assert len(entries) == 1, (filename, len(entries))
    compile_entry = entries[0]
    compile_argv = argv(compile_entry['command'])
    raw_lines = query(['-t', 'commands', 'bin/' + target + '.exe']).splitlines()
    links = [line for line in raw_lines
             if 'vs_link_exe' in line and '/out:bin\\' + target + '.exe' in line]
    assert len(links) == 1, (target, len(links))
    raw_link = links[0]
    start = raw_link.lower().index('"c:\\program files\\cmake\\bin\\cmake.exe"')
    end = raw_link.index(' &&', start)
    link_argv = argv(raw_link[start:end])
    link_objects = [value for value in link_argv if value.lower().endswith('.obj')]
    link_libraries = [value for value in link_argv if value.lower().endswith('.lib')]
    imports = [pin(BUILD / value) if not Path(value).is_absolute() else pin(value)
               for value in link_libraries if value.startswith(('bin\\', 'lib\\'))]
    output = BATCH / 'normal-test-build' / name / 'attempt1'
    narrow_compile = [('/Fo' + str(output / 'unit.obj')) if item.startswith('/Fo')
        else ('/Fd' + str(output / 'compile.pdb')) if item.startswith('/Fd')
        else item for item in compile_argv]
    narrow_link = []
    for item in link_argv:
        if item in link_objects:
            if filename + '.obj' in item:
                narrow_link.append(str(output / 'unit.obj'))
            continue
        if item.startswith('--intdir='):
            item = '--intdir=' + str(output / 'intdir')
        elif item.startswith('/out:'):
            item = '/out:' + str(output / (name + '-copy-capture-test.exe'))
        elif item.startswith('/implib:'):
            item = '/implib:' + str(output / 'test.lib')
        elif item.startswith('/pdb:'):
            item = '/pdb:' + str(output / 'test.pdb')
        narrow_link.append(item)
    cases.append({'name': name, 'normal_target': target,
        'source': pin(ROOT / 'tests/graph' / filename),
        'actual_compile': compile_entry, 'actual_compile_argv': compile_argv,
        'actual_defines': [item for item in compile_argv if item.startswith(('-D', '/D'))],
        'actual_link_command': raw_link, 'actual_link_argv': link_argv,
        'actual_link_objects': link_objects, 'actual_link_libraries': link_libraries,
        'normal_import_and_gtest_pins': imports,
        'narrow_compile_argv': narrow_compile, 'narrow_link_argv': narrow_link,
        'narrow_cwd': str(BUILD),
        'narrow_changes': 'Only this TU, scratch Fo/Fd, one-object link, scratch intdir/out/implib/pdb; compiler flags/macros and actual normal link libraries unchanged.',
        'execution_status': 'NOT_EXECUTED'})

assert manifest == pin(BUILD / 'build.ninja'), 'Ninja manifest changed during query'
report = {'status': 'PREPARED_FROM_ACTUAL_NORMAL_NINJA_NOT_EXECUTED',
    'normal_build': str(BUILD), 'manifest': manifest,
    'rules': pin(BUILD / 'CMakeFiles/rules.ninja'),
    'cache': pin(BUILD / 'CMakeCache.txt'),
    'environment': pin(ROOT / '.scratch/inference-default-product-build-20261031/environment.json'),
    'queries': queries, 'cases': cases,
    'blockers': ['Actual hyle_graph_executable_test compile lacks src/graph include, while region_provider_test.cc includes plan_state.h, region_discovery.h, submission_internal.h and submission_lifetime.h without relative prefixes. Root owns a narrow tests/graph/CMakeLists.txt correction. Do not treat the older manual /I src/graph recipe as validation of this formal entry.'],
    'limits': ['No configure, CXX, link, native, model, GPU or download executed.',
        'ninja -t compdb/commands are recipe inspection only.',
        'Normal full targets own 10 and 2 test objects respectively; narrow recipes deliberately retain only the reviewed TU.',
        'Private declarations without export annotations may still expose existing shared-link failures; actual link remains required. No static product macro or cached static SDK closure is substituted.',
        'Some methods/tests from these same large TUs may need additional existing public facade libraries; those are not silently borrowed from the historical hand-written plan.'],
    'counts_executed': {'configure': 0, 'CXX': 0, 'link': 0, 'native': 0}}
destination = BATCH / 'normal-test-commands.json'
assert not destination.exists(), 'Preserve existing receipt instead of overwriting it'
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'file': str(destination), 'cases': len(cases),
    'compile_defines': [case['actual_defines'] for case in cases],
    'link_objects': [len(case['actual_link_objects']) for case in cases],
    'link_libraries': [len(case['actual_link_libraries']) for case in cases],
    'blockers': len(report['blockers'])}))
