// Configure-only kernel body.
