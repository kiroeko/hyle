from pathlib import Path
import hashlib,json,re,shlex,subprocess,unicodedata
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
FILES=('README.md','scripts/README.md','docs/developer/setup/README.md','docs/user/inference.md')
def read(p):return Path(p).read_text(encoding='utf-8')
def slug(text):
    text=re.sub(r'[`*_]','',text).lower()
    text=''.join(ch for ch in text if ch=='-' or ch.isspace() or unicodedata.category(ch)[0] in ('L','N'))
    return re.sub(r'\s','-',text.strip())
links=[];examples=[];line_endings=[];headers=[]
for rel in FILES:
    p=R/rel;s=read(p);b=p.read_bytes()
    original=(W/'before'/rel).read_bytes()
    expected='CRLF' if original.count(b'\r\n')==original.count(b'\n') and b'\r\n' in original else 'LF'
    if expected=='CRLF':assert b.count(b'\r\n')==b.count(b'\n') and b'\r\n' in b,rel
    else:assert b'\r' not in b and b'\n' in b,rel
    line_endings.append(dict(path=rel,original_EOL=expected,CRLF=b.count(b'\r\n'),bareLF=b.count(b'\n')-b.count(b'\r\n'),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
    fenced=False;prior=''
    for i,line in enumerate(s.splitlines()):
        if line.startswith('```'):fenced=not fenced;prior=line;continue
        if not fenced and re.match(r'^#{1,6} ',line):
            assert i==0 or prior=='',(rel,i+1,'heading missing blank line')
            assert i+1==len(s.splitlines()) or s.splitlines()[i+1]=='',(rel,i+1,'heading missing following blank')
            headers.append((rel,line))
        prior=line
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',s):
        if re.match(r'\w+://',target):continue
        path,_,fragment=target.partition('#');q=(p.parent/path).resolve() if path else p
        assert q.exists(),(rel,target)
        if fragment and q.suffix=='.md':
            anchors={slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$',read(q),re.M)}
            assert fragment in anchors,(rel,target,'anchor missing')
        links.append(dict(source=rel,target=target))
    for line in s.splitlines():
        if line.startswith('python scripts/') or line.startswith('python engine/'):
            args=shlex.split(line);tool=Path(args[1]).stem
            help_text=read(W/'help'/('prepare' if args[1].startswith('engine/') else tool)/'stdout.log')
            flags=[a for a in args[2:] if a.startswith('--')]
            assert all(flag in help_text for flag in flags),(rel,line,flags)
            examples.append(dict(source=rel,command=line,all_flags_in_actual_help=True))
        elif line.startswith('<build-dir>/bin/hyle '):
            flags=re.findall(r'--[a-z-]+',line);assert all(f in read(W/'help/engine/stdout.log') for f in flags)
            assert '--mtp off' in line and '.scratch/qwen-input' in line
            examples.append(dict(source=rel,command=line,all_flags_in_actual_help=True,ordinary_first=True))
# Match every named build/test example to an explicit named init in that guide.
named=[]
for rel in FILES:
    rows=[x['command'] for x in examples if x['source']==rel]
    names={re.search(r'--name (\S+)',line)[1] for line in rows if line.startswith('python scripts/init.py') and '--name ' in line}
    for line in rows:
        if line.startswith(('python scripts/build.py','python scripts/test.py')) and '--name ' in line:
            assert re.search(r'--name (\S+)',line)[1] in names,(rel,line)
    named.append(dict(path=rel,named_init_build_test_consistent=True))
old=read(W/'before/docs/user/inference.md');new=read(R/'docs/user/inference.md')
supported=old[old.index('当前完整文本模型为'):old.index('目前使用准备后的本地权重清单')].strip()
fp=old[old.index('原 CT channel/token FP8'):old.index('`--steps` 是最多输出数')].strip()
assert supported in new and fp in new
for phrase in ('通用模型目录加载','C++ tokenizer','聊天服务','图片输入','组件级','不会自动安装它或获取模型',
               '不下载模型','不复制整份权重','不代表可以直接加载任意量化模型目录','完整 27B 模型未运行'):
    assert phrase in new,phrase
for name in ('init','build','test','engine','prepare'):
    assert json.loads(read(W/'help'/name/'result.json'))['exit_code']==0
check=subprocess.run(['git','diff','--check','--',*FILES],cwd=R,capture_output=True,text=True)
assert check.returncode==0,check.stdout+check.stderr
normal_stat=subprocess.check_output(['git','diff','--stat','--',*FILES],cwd=R,text=True)
substantive_stat=subprocess.check_output(['git','diff','--ignore-space-at-eol','--stat','--',*FILES],cwd=R,text=True)
value=dict(status='PASS_DOCUMENT_LINKS_EXAMPLES_HELP_ORIGINAL_EOL_AND_LIMITS',files=line_endings,
    local_links_checked=len(links),code_examples_checked=len(examples),named_examples=named,
    complete_old_model_codec_scope_paragraphs_preserved=True,complete_old_CT_FP8_E4_constraints_preserved=True,
    actual_help_commands=5,init_or_configure_runs=0,builds=0,model_runs=0,profiles=0,downloads=0,
    diff_check=True,diffstat=normal_stat,substantive_diffstat_ignoring_EOL=substantive_stat,
    limits='Only Windows installed normal-product --help and script --help were run. No fresh initialization or platform/model matrix was rerun; existing cited finite evidence remains the capability boundary.')
(W/'verification.json').write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=value['status'],local_links=value['local_links_checked'],examples=value['code_examples_checked'],help=5,
    codec_paragraphs_preserved=True,original_EOLS_preserved=True),ensure_ascii=False))
print(substantive_stat)
