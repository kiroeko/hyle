#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_retirement_observation_case.h"
#include "tests/tools/qwen_turn_context_case.h"

int main(int argc, char **argv) {
  try {
    if (argc == 1) return 77;
    if (argc != 3) throw std::runtime_error("retirement-check MODE PRIVATE_CACHED_FIXTURE_DIRECTORY");
    const std::filesystem::path input(argv[2]);
    if (std::string_view(argv[1]) == "--retirement-observation")
      return qwen_retirement_observation_case::run(input);
    if (std::string_view(argv[1]) == "--turn-context")
      return qwen_turn_context_case::run(input);
    throw std::runtime_error("unknown finite CPU check mode");
  } catch (const std::exception &error) {
    std::cerr << "retirement_check_failure=" << error.what() << '\n';
    return 1;
  }
}
