"""One CPU app TU and two finite original Model checks; no core/provider build."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = R/'.scratch/inference-ordinary-boundaries-20261025/retirement-implementation'
OLD = R/'.scratch/inference-ordinary-boundaries-20261025/implementation'
CACHED = OLD/'attempt2/candidate'
spec = importlib.util.spec_from_file_location('retained_commands', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8', newline='\n')


def commands():
    original = b.args(CACHED/'compile/command.json')
    command = [original[0], '/I'+str(W/'source')]
    skip = False
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        if 'inference-ordinary-boundaries-20261025' in arg:
            continue
        command.append(arg)
    command += [str(W/'consumer.cc'), '/sourceDependencies', str(W/'attempt1/compile/dependencies.json'),
                '/Fo'+str(W/'attempt1/compile/unit.obj'), '/Fd'+str(W/'attempt1/compile/unit.pdb')]
    link, replaced = [], 0
    for arg in b.args(CACHED/'link/command.json'):
        if arg.lower().startswith(('/out:', '/pdb:', '/implib:')):
            continue
        if Path(arg) == CACHED/'compile/unit.obj':
            arg = str(W/'attempt1/compile/unit.obj')
            replaced += 1
        link.append(arg)
    assert replaced == 1
    link += ['/OUT:'+str(W/'attempt1/link/component.exe'), '/PDB:'+str(W/'attempt1/link/component.pdb'),
             '/IMPLIB:'+str(W/'attempt1/link/component.lib')]
    return command, link


def plan():
    # Only the previously consumed self-written quoted headers are borrowed.
    # Keep their before copies so they are not presented as new source changes.
    actual = b.read(CACHED/'compile/repository-inputs.json')
    support = []
    for item in actual:
        path = Path(item['path'])
        if not path.is_relative_to(OLD/'source'):
            continue
        assert b.pin(path) == item
        relative = path.relative_to(OLD/'source')
        before, after = W/'before'/relative, W/'source'/relative
        if not before.exists():
            before.parent.mkdir(parents=True, exist_ok=True)
            before.write_bytes(path.read_bytes())
        if not after.exists():
            after.parent.mkdir(parents=True, exist_ok=True)
            after.write_bytes(path.read_bytes())
        support.append(dict(relative=relative.as_posix(), original=item, actual=b.pin(after)))
    command, link = commands()
    common = [b.pin(Path(x)) for x in link if Path(x).is_absolute() and
              Path(x).suffix.lower() in {'.obj', '.lib'} and Path(x) != W/'attempt1/compile/unit.obj']
    assert len(common) == 129, len(common)
    prior = b.read(OLD/'execution-plan2.json')
    source = [b.pin(p) for p in sorted((W/'source').rglob('*')) if p.is_file()]
    source.append(b.pin(W/'consumer.cc'))
    save(W/'execution-plan.json', dict(status='AUTHORIZED_FINITE_CPU_CHECK_READY',
        baseline_commit='32c0fb38046cec89fae02c66f30825cb70249c8f',
        baseline_main=b.pin(W/'before/engine/models/qwen35/main.cc'),
        actual_main=b.pin(W/'source/engine/models/qwen35/main.cc'),
        source=source, support_sources=support,
        compile_template=b.pin(CACHED/'compile/command.json'), link_template=b.pin(CACHED/'link/command.json'),
        compile=command, link=link, common_input_count=len(common), total_link_inputs=len(common)+1,
        common_inputs=common, native=prior['native'], runtime=prior['runtime'],
        fixture=prior['fixture'], fixture_body=prior['fixture_body'],
        modes=['--retirement-observation', '--turn-context'], watchdog_seconds=120,
        scope='one pure CPU thin driver app TU, two CPU processes; actual existing cached untrained A/H64/FFN128/V64 fixture',
        intentional_faults='Synthetic host Status fields on real prepared non-submitted episodes; no native/device failure injection',
        unexecuted='Whole lifecycle dispatch TU and CUDA/Vulkan/probe consumers migrated source-only; no full lifecycle/GPU matrix',
        SDK_TUs=0, core_TUs=0, provider_TUs=0, GPU=False, HTTP=0))
    print('PLAN: 1 app TU + 129 retained object/library inputs; 2 CPU processes; no core/provider/SDK build.')


def build():
    plan = b.read(W/'execution-plan.json')
    for item in [*plan['source'], *plan['common_inputs'], plan['native'], plan['runtime'], plan['fixture'], plan['fixture_body']]:
        assert b.pin(Path(item['path'])) == item
    command, link = commands()
    assert command == plan['compile'] and link == plan['link']
    env = b.environment(command[0])
    b.execute(command, W/'attempt1/compile', env, 150)
    dep = b.read(W/'attempt1/compile/dependencies.json')['Data']
    own = []
    for name in [dep['Source'], *dep['Includes']]:
        path = Path(name)
        if path.is_relative_to(R):
            own.append(b.pin(path))
        assert not path.is_relative_to(R/'engine'), ('canonical engine leak', path)
        assert not path.is_relative_to(OLD/'source'), ('old private source leak', path)
    assert any(Path(x['path']) == W/'source/engine/models/qwen35/main.cc' for x in own)
    assert any(Path(x['path']) == W/'source/engine/inference/retirement_observation.h' for x in own)
    assert any(Path(x['path']) == W/'source/engine/inference/session_cache.h' for x in own)
    save(W/'attempt1/compile/repository-inputs.json', own)
    b.execute(link, W/'attempt1/link', env, 90)
    native = Path(plan['native']['path'])
    os.link(native, W/'attempt1/link'/native.name)
    save(W/'attempt1/link/ready.json', dict(image=b.pin(W/'attempt1/link/component.exe'),
        app=b.pin(W/'attempt1/compile/unit.obj'), native=b.pin(native),
        actual_inputs=[b.pin(Path(x)) for x in link if Path(x).is_absolute() and Path(x).suffix.lower() in {'.obj', '.lib'}]))
    for item in plan['source']:
        assert b.pin(Path(item['path'])) == item
    print('BUILD READY: exact private source dependencies; one app TU and original cached closure.')


def run(mode):
    plan = b.read(W/'execution-plan.json')
    assert mode in plan['modes']
    ready = b.read(W/'attempt1/link/ready.json')
    for item in [ready['image'], ready['native'], *ready['actual_inputs'], plan['fixture'], plan['fixture_body']]:
        assert b.pin(Path(item['path'])) == item
    env = b.environment(plan['compile'][0])
    env['PATH'] = str(W/'attempt1/link')+';'+b.read(Path(plan['runtime']['path']))['PATH']
    env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
    folder = W/'attempt1'/mode.removeprefix('--')
    b.execute([ready['image']['path'], mode, str(Path(plan['fixture']['path']).parent)], folder, env, 120)
    data = json.loads((folder/'stdout.log').read_text(encoding='utf-8').strip().splitlines()[-1])
    assert data['status'] == 'PASS' and not data['GPU'] and not data['HTTP']
    save(folder/'result.json', data)
    print(json.dumps(data))


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'plan': plan()
    elif mode == 'build': build()
    elif mode == 'run': run(sys.argv[2])
    else: raise SystemExit('plan | build | run --retirement-observation|--turn-context')
