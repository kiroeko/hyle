import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
CORE = WORK / 'retirement-implementation'
HOST = WORK / 'session-cache-test-proposal'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

core = json.loads((CORE / 'source-pins.json').read_text())['files']
host = json.loads((HOST / 'after-pins.json').read_text())
assert len(core) == 15 and len(host) == 2
items = [(CORE, item) for item in core] + [(HOST, item) for item in host]
assert len({item['path'] for _, item in items}) == 17

# All source comparisons happen before the first write. Existing unrelated
# work, including the progress-board update, is outside these exact paths.
for owner, item in items:
    path = item['path']
    source = owner / 'source' / path
    target = ROOT / path
    assert digest(source) == item['sha256'], path
    before = owner / 'before' / path
    if before.exists():
        assert target.read_bytes() == before.read_bytes(), path
    elif owner == HOST and path == 'tests/CMakeLists.txt':
        before_pin = json.loads((HOST / 'before-pins.json').read_text())[0]
        assert digest(target) == before_pin['sha256'], path
    else:
        assert not target.exists(), path

for owner, item in items:
    target = ROOT / item['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((owner / 'source' / item['path']).read_bytes())
    assert digest(target) == item['sha256']

(WORK / 'retirement-integration.json').write_text(json.dumps({
    'status': 'REVIEWED_SOURCE_INTEGRATED',
    'files': [item for _, item in items],
    'scope': 'Exact private reviewed source bytes only; no build or run performed by this copy',
}, indent=2) + '\n')
print('Integrated 17 reviewed source/test paths; unrelated changes preserved.')
