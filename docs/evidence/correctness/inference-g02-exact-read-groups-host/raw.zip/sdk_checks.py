from pathlib import Path
import subprocess,json,time,sys,shutil

base=Path('/root/hyle-scratch/compute-unified')
source=base/'source-7a7b4c3b'
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g02')
mode=sys.argv[1]
assert mode in ('static','shared')
build=base/('l-cpu-cuda/selected-graph/'+mode+'-sdk-build')
prefix=base/('g02-sdk-'+mode+'-prefix')
relocated=base/('g02-sdk-'+mode+'-relocated')
parent=base/('g02-sdk-'+mode+'-consumer')
consumer_build=parent/'build'
assert build.is_dir()
parent.mkdir(parents=True,exist_ok=True)
lines=['cmake_minimum_required(VERSION 3.25)','project(g02_installed_consumer LANGUAGES CXX)',
       'find_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS compute graph)']
for name,filename in (('hybrid','public_hybrid_batch_consumer.cc'),('native','native_graph_consumer.cc'),('public_cuda','public_batch_cuda_consumer.cc')):
    lines += [f'add_executable({name} "{source}/tests/compute_batch/{filename}")',
              f'target_compile_features({name} PRIVATE cxx_std_23)',
              f'target_link_libraries({name} PRIVATE hyle::compute hyle::graph)',f'hyle_stage_runtime({name})']
(parent/'CMakeLists.txt').write_text('\n'.join(lines)+'\n')
result_file=out/(mode+'-sdk-result.json')
records=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
def run(label,argv):
    attempt=1+sum(x['stage']==label for x in records)
    log=out/(mode+'-sdk-'+label+('' if attempt==1 else '-'+str(attempt))+'.log')
    started=time.monotonic()
    with log.open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
    record={'stage':label,'command':argv,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)}
    records.append(record)
    (out/(mode+'-sdk-result.json')).write_text(json.dumps({'mode':mode,'stages':records},indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if r.returncode:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-25:]),flush=True)
        sys.exit(r.returncode)

if not relocated.exists():
    run('producer-build',['cmake','--build',str(build),'--parallel','12'])
    run('install',['cmake','--install',str(build),'--prefix',str(prefix)])
    assert prefix.resolve().parent==base and relocated.resolve().parent==base
    prefix.rename(relocated)
run('consumer-configure',['cmake','-S',str(parent),'-B',str(consumer_build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(relocated),'-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCUDA_cudart_LIBRARY=/usr/local/cuda-13.3/targets/x86_64-linux/lib/libcudart.so'])
run('consumer-build',['cmake','--build',str(consumer_build),'--parallel','4'])
for name in ('hybrid','native','public_cuda'):run('run-'+name,[str(consumer_build/name)])
print(mode+' installed/relocated hybrid/native/public consumers PASS',flush=True)
