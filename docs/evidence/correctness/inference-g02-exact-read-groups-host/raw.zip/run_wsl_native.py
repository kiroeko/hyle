from pathlib import Path
import subprocess,json,sys,time
root=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g02')
script_dir=Path('/root/hyle-scratch/compute-unified')
kind=sys.argv[1]
label=sys.argv[2] if len(sys.argv)>2 else 'debug'
target='hyle_g02_hybrid' if label.startswith('hybrid') else 'hyle_f5_native_graph'
commands={
    'configure':['cmake','-S',str(script_dir/'l-cpu-cuda/selected-graph/source-parent'),'-B',str(script_dir/'l-cpu-cuda/selected-graph/source-build')],
    'build':['cmake','--build',str(script_dir/'l-cpu-cuda/selected-graph/source-build'),'--target',target,'--parallel','12'],
    'run':[str(script_dir/'l-cpu-cuda/selected-graph/source-build'/target)],
}
started=time.monotonic()
log=root/(kind+'-native-'+label+'.log')
with log.open('w') as f:
    result=subprocess.run(commands[kind],stdout=f,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-started
record={'command':commands[kind],'exit_code':result.returncode,'elapsed_seconds':elapsed,'log':str(log)}
(root/(kind+'-native-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
print('\n'.join(log.read_text(errors='replace').splitlines()[-14:]),flush=True)
sys.exit(result.returncode)
