from pathlib import Path
import json,hashlib,subprocess,zipfile,io
root=Path.cwd();scratch=root/'.scratch/inference-gaps/g02';dest=root/'evidence/correctness/inference-g02-common'
old=json.loads((dest/'receipt.json').read_text()); old_raw=(dest/'raw.zip').read_bytes()
snapshot=json.loads((scratch/'candidate-validation-checkpoint.json').read_text())
windows=json.loads((scratch/'windows-selected-result.json').read_text())
required=['configure','factor:compute_batch','factor:graph','headers:graph','factor:graph_batch','headers:graph_batch','factor:graph_provider_ggml_cuda','factor:graph_provider_onednn','factor:graph_route_cpu','factor:graph_route_cpu_cuda','factor:graph_route_cpu_vulkan','factor:graph_route_cuda','factor:graph_route_vulkan']
unproven=[]
for gate in required:
 rows=[x for x in windows['stages'] if x['gate']==gate]
 count=1 if gate=='configure' or gate.startswith('headers:') else 2
 for index in range(count):
  latest=next((x for x in reversed(rows) if x['command_index']==index),None)
  if latest is None or latest['exit_code']!=0:unproven.append({'gate':gate,'command_index':index,'verdict':'UNPROVEN','reason':'interrupted for desktop resource pressure or not yet executed; not PASS'})
air=json.loads((scratch/'air-result.json').read_text())
assert air['stages'] and all(next(x for x in reversed(air['stages']) if x['stage']==stage)['exit_code']==0 for stage in {x['stage'] for x in air['stages']}), 'Apple affected interface latest proof required; original FAIL retained'
files={}
with zipfile.ZipFile(io.BytesIO(old_raw)) as z:
 for name in z.namelist():files['historical-stage/'+name]=z.read(name)
files['historical-stage/receipt.json']=json.dumps(old,indent=2).encode()
for p in scratch.rglob('*'):
 if p.is_file() and p.suffix in ('.log','.json','.py','.cc') and p.name!='source-manifest.json':files['candidate/'+str(p.relative_to(scratch)).replace('\\','/')]=p.read_bytes()
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
inputs=['include/hyle/graph/batch.h','include/hyle/graph/detail/region_access.h','src/graph/region_access.cc','src/graph_batch/batch.cc','tests/graph/region_provider_test.cc','tests/compute_batch/public_batch_cuda_consumer.cc','tests/compute_batch/public_hybrid_batch_consumer.cc','tests/compute_batch/native_graph_consumer.cc','tests/compute_batch/native_graph_faults.h','tests/compute_batch/native_arena_graph_consumer.h','tests/compute_batch/native_ragged_graph_append_consumer.h','tests/graph_route_cpu_cuda/CMakeLists.txt','tests/graph_route_cpu_apple/CMakeLists.txt','tests/graph_route_cpu_vulkan/CMakeLists.txt']
hashes=[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in inputs]
candidate=snapshot['candidate']
for p in inputs[:11]:
 original=subprocess.check_output(['git','show',candidate+':'+p]);assert hashlib.sha256(original).hexdigest()==next(x['sha256'] for x in hashes if x['path']==p),p
receipt={'kind':'G02 common slice partial candidate validation; Windows interrupted gates unproven, not module closure','baseline':old['baseline'],'candidate':candidate,'product_api_commit':old['product_api_commit'],'maintenance_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'inputs':hashes,'source_hybrid':snapshot['source_hybrid'],'delivery':snapshot['sdk'],'risk':{'sanitizers':snapshot['sanitizers'],'oom':snapshot['oom'],'limits':snapshot['limitations'],'driver_controls':['evidence/correctness/foundation-f5-native-cuda-host-asan/README.md','evidence/correctness/foundation-f5-native-cuda-host-tsan/README.md']},'windows_selected':{'receipt':'raw.zip:candidate/windows-selected-result.json','plan':'raw.zip:candidate/windows-selected-plan.json','applicable_gates':required,'local_not_applicable':windows.get('local_not_applicable',[]),'failed_attempts_preserved':True,'unproven':unproven},'apple_affected_interface':air,'p0':{'cold':'O(lane capacity + active bindings + regions) bounded metadata, retained original native slots','warm':'original full QueueBindings prepare_replay once and submit; no second queue/runtime/plan per step','product_physical_diff':'+63/-12 = +51','self_written_native_net':43,'loc_snapshot':'26d7c2cb7','repository_code':2835108,'self_written_native_code':174381,'graph_conventional_directory_code':14875,'graph_batch_src_only_code':345,'boundary_warning':'graph directory includes split route headers; graph_batch count excludes public graph/batch.h; exact reports in raw.zip'},'raw':[{'path':name,'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())],'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest(),'separated_source_review':snapshot['separated_source_review'],'remaining':['native Apple/Vulkan joint paged G02 scope','G01 and G03-G10; full inference engine outside this goal']}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'logs_and_inputs':len(files),'archive_bytes':(dest/'raw.zip').stat().st_size,'candidate':candidate}),flush=True)
