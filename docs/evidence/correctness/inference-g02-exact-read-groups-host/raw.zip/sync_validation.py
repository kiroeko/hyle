from pathlib import Path
import hashlib,json,shutil

canonical=Path('/mnt/c/public/project-hyle/hyle')
destination=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
assert destination.is_dir() and destination.resolve().parent==Path('/root/hyle-scratch/compute-unified')
manifest=json.loads((canonical/'.scratch/inference-gaps/g02/source-manifest.json').read_text())
prefixes=('include/','src/','cmake/','third_party/','tests/','samples/','scripts/')
roots={'CMakeLists.txt','CMakePresets.json','README.md','AGENTS.md','docs/implementation/module-status.json'}
copied=[];checked=0
for record in manifest['files']:
    name=record['path']
    if not (name.startswith(prefixes) or name in roots):continue
    relative=Path(name)
    assert not relative.is_absolute() and '..' not in relative.parts
    source=canonical/relative;target=destination/relative
    data=source.read_bytes()
    assert hashlib.sha256(data).hexdigest()==record['sha256'],name
    checked+=1
    if target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest()==record['sha256']:continue
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target);copied.append(name)
receipt={'kind':'disposable validation inputs from Windows canonical; unchanged timestamps preserved',
         'candidate':manifest['candidate'],'destination':str(destination),'files_checked':checked,'copied':copied}
(canonical/'.scratch/inference-gaps/g02/wsl-sync.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'candidate':receipt['candidate'],'checked':checked,'copied':len(copied)}),flush=True)
