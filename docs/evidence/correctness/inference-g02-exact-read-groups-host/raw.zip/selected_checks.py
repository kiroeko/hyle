from pathlib import Path
import json,subprocess,sys,time,os

root=Path.cwd()
out=root/'.scratch/inference-gaps/g02'
plan_file=out/'windows-selected-plan.json'
context=root/'.scratch/validation/windows-msvc-sm89-context.json'
argv=[sys.executable,'scripts/validation-select.py','plan','--base','743783f7b','--candidate','070609442806ebfe6a0dc8d6594b7388c494f20b','--context',str(context),'--output',str(plan_file)]
r=subprocess.run(argv,cwd=root)
if r.returncode:sys.exit(r.returncode)
plan=json.loads(plan_file.read_text())
assert plan['verdict']=='READY',plan.get('reason')
build=Path('C:/h7/inference-g02-impacted')
scratch=Path('C:/h7/inference-g02-impact-delivery')
receipt_file=out/'windows-selected-result.json'
previous=json.loads(receipt_file.read_text()) if receipt_file.exists() else None
if previous:assert previous['candidate']==plan['candidate_commit'],'cannot reuse another candidate'
records=previous['stages'] if previous else []
local_skips=previous.get('local_not_applicable',[]) if previous else []
for gate in plan['selected_gates']:
    if gate['kind'] not in ('build','correctness','headers'):continue
    if gate['id']=='factor:graph_route_cpu_apple' and sys.platform=='win32':
        skip={'gate':gate['id'],'verdict':'NOT_APPLICABLE','reason':'Apple requires Darwin/aarch64 in cmake/HyleComputeRoutes.cmake; tests/graph_route_cpu_apple/CMakeLists.txt registers no tests without the Apple route. Windows empty aggregate is not native Apple validation. Original empty-CTest FAIL retained; Apple proof remains required on MacBook Air.'}
        if skip not in local_skips:local_skips.append(skip)
        if previous:
            previous['local_not_applicable']=local_skips
            receipt_file.write_text(json.dumps(previous,indent=2)+'\n')
        print(json.dumps(skip),flush=True)
        continue
    latest=[next((x for x in reversed(records) if x['gate']==gate['id'] and x['command_index']==index),None) for index in range(len(gate['commands']))]
    if all(x is not None and x['exit_code']==0 for x in latest):continue
    for index,command in enumerate(gate['commands']):
        args=[x.replace('{root}',str(root)).replace('{build}',str(build)).replace('{scratch}',str(scratch)).replace('{python}',sys.executable) for x in command]
        if gate['id']=='headers:graph':
            args=[sys.executable,'scripts/header-self-contained.py','--module','graph','--include-dir',str(root/'include'),'--extra-include-dir','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include','--cxx',json.loads(context.read_text())['toolchain']['compiler_path'],'--cxx-compiler-id','MSVC','--cxx-frontend','MSVC']
        if '--parallel' in args:args[args.index('--parallel')+1]='4'
        if gate['id']=='configure':
            args+=['-DCMAKE_CXX_COMPILER='+plan['toolchain']['compiler_path']] if 'toolchain' in plan else ['-DCMAKE_CXX_COMPILER='+json.loads(context.read_text())['toolchain']['compiler_path']]
            args+=['-DHYLE_DEP_SOURCE_CACHE=C:/public/tools/hyle-dependencies/v1','-DCMAKE_CUDA_ARCHITECTURES=89-real']
            args+=['-DVulkan_INCLUDE_DIR=C:/public/tools/hyle-vulkan/1.4.357.0/include','-DVulkan_LIBRARY=C:/public/tools/hyle-vulkan/1.4.357.0/Lib/vulkan-1.lib','-DVulkan_GLSLC_EXECUTABLE=C:/public/tools/hyle-vulkan/1.4.357.0/Bin/glslc.exe']
            args+=['-DSPIRV-Headers_DIR=C:/public/tools/hyle-vulkan/1.4.357.0/Lib/cmake/SPIRV-Headers']
            flags=json.loads(context.read_text())['toolchain']['flags']
            args+=['-D'+k+'='+v for k,v in flags.items()]
        attempt=1+sum(x['gate']==gate['id'] and x['command_index']==index for x in records)
        log=out/(gate['id'].replace(':','-')+'-selected-'+str(index)+'-'+str(attempt)+'.log')
        started=time.monotonic()
        with log.open('w') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
        row={'gate':gate['id'],'command_index':index,'command':args,'original_selector_recipe':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)}
        records.append(row)
        receipt={'kind':'actual selected gates; historical compile jobs12, desktop-pressure resume jobs4, same header checker with actual CUDA include; not selector cache receipt','candidate':plan['candidate_commit'],'context':json.loads(context.read_text()),'stages':records,'skipped_gates':plan['skipped_gates'],'local_not_applicable':local_skips,'delivery_evidence':'ordinary Linux source + relocated static/shared SDK in separate receipts'}
        receipt_file.write_text(json.dumps(receipt,indent=2)+'\n')
        print(json.dumps(row),flush=True)
        if r.returncode:
            print('\n'.join(log.read_text(errors='replace').splitlines()[-30:]),flush=True);sys.exit(r.returncode)
print('selected Windows build/correctness/headers recipes PASS; delivery independently recorded',flush=True)
