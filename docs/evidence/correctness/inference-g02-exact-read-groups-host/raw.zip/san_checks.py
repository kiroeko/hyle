from pathlib import Path
import subprocess,json,time,sys,os

base=Path('/root/hyle-scratch/compute-unified')
source=base/'source-7a7b4c3b'
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g02')
mode=sys.argv[1]
assert mode in ('asan','ubsan','tsan')
root=base/('foundation-f5-native-host-cuda-'+mode)
build=root/'build';parent=root/'parent'
assert build.is_dir() and parent.is_dir()
p=parent/'CMakeLists.txt';text=p.read_text()
if 'add_executable(hybrid ' not in text:
    links='hyle::compute hyle::graph' if mode=='asan' else 'hyle_compute_state hyle_graph_batch hyle_compute_provider_flashinfer hyle_compute_backend_cuda hyle_graph_route_cpu hyle_graph_route_cpu_cuda'
    text+=f'\nadd_executable(hybrid "{source}/tests/compute_batch/public_hybrid_batch_consumer.cc")\ntarget_compile_features(hybrid PRIVATE cxx_std_23)\ntarget_link_libraries(hybrid PRIVATE {links})\nhyle_apply_sanitizer(hybrid)\nhyle_stage_runtime(hybrid)\n'
    p.write_text(text)
result_file=out/(mode+'-result.json')
records=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
def run(label,argv,env=None):
    attempt=1+sum(x['stage']==label for x in records)
    log=out/(mode+'-'+label+'-'+str(attempt)+'.log')
    started=time.monotonic()
    with log.open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=env)
    record={'stage':label,'command':argv,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)}
    if env:record['san_options']={k:env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','TSAN_OPTIONS') if k in env}
    records.append(record);result_file.write_text(json.dumps({'sanitizer':mode,'stages':records},indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if r.returncode:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-30:]),flush=True);sys.exit(r.returncode)

configure_source=parent
argv_extra=[]
if mode!='asan':
    configure_source=source
    additions=root/'factor-consumers.cmake'
    original=additions.read_text()
    if 'g02_add_hybrid' not in original:
        original+=f'\nfunction(g02_add_hybrid)\nadd_executable(hybrid "{source}/tests/compute_batch/public_hybrid_batch_consumer.cc")\ntarget_compile_features(hybrid PRIVATE cxx_std_23)\ntarget_link_libraries(hybrid PRIVATE hyle_compute_state hyle_graph_batch hyle_compute_provider_flashinfer hyle_compute_backend_cuda hyle_graph_route_cpu hyle_graph_route_cpu_cuda)\nhyle_apply_sanitizer(hybrid)\nhyle_stage_runtime(hybrid)\nendfunction()\ncmake_language(DEFER CALL g02_add_hybrid)\n'
        additions.write_text(original)
    argv_extra=['-DHYLE_DEV_FACTORS=graph_batch;compute_provider_flashinfer;compute_backend_cuda;compute_state;graph_route_cpu;graph_route_cpu_cuda','-DCMAKE_PROJECT_TOP_LEVEL_INCLUDES='+str(additions)]
argv=['cmake','-S',str(configure_source),'-B',str(build),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',*argv_extra]
if not any(x['stage']=='configure' and x['exit_code']==0 for x in records):run('configure',argv)
if not any(x['stage']=='build' and x['exit_code']==0 for x in records):run('build',['cmake','--build',str(build),'--target','graph','hybrid','public_cuda','--parallel','12'])
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
required=['src/graph/region_access.cc','src/graph_batch/batch.cc','tests/compute_batch/native_graph_consumer.cc','tests/compute_batch/public_hybrid_batch_consumer.cc']
flag={'asan':'-fsanitize=address','ubsan':'-fsanitize=undefined','tsan':'-fsanitize=thread'}[mode]
checked=[]
for name in required:
    matches=[x for x in commands if x['file'].endswith(name)]
    assert matches and all(flag in x['command'] for x in matches),name
    checked+=matches
(out/(mode+'-instrumented-inputs.json')).write_text(json.dumps(checked,indent=2)+'\n')
env=os.environ.copy()
env.update({'asan':{'ASAN_OPTIONS':'halt_on_error=1:protect_shadow_gap=0:detect_leaks=0'},'ubsan':{'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'tsan':{'TSAN_OPTIONS':'halt_on_error=1:report_thread_leaks=0'}}[mode])
for name in ('graph','hybrid','public_cuda'):
    executable=build/name
    if not executable.is_file():executable=build/'bin'/name
    assert executable.is_file(),str(executable)
    argv=[str(executable)]
    if mode=='tsan':argv=['setarch',os.uname().machine,'-R',*argv]
    run('run-'+name,argv,env)
print(mode+' actual native consumers PASS; vendor/driver whole process limits retained',flush=True)
