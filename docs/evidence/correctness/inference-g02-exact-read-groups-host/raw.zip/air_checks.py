from pathlib import Path
import subprocess,json,time,os,sys
out=Path('/Users/kiro/hyle-scratch/compute-unified/g02-checks');out.mkdir(exist_ok=True)
source=Path('/Users/kiro/hyle-scratch/compute-unified/source-c8874688')
parent=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-parent')
build=parent.parent/'source-build'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
result_file=out/'result.json';previous=json.loads(result_file.read_text()) if result_file.exists() else None
records=previous['stages'] if previous else []
def run(stage,args):
 latest=next((x for x in reversed(records) if x['stage']==stage),None)
 if latest and latest['exit_code']==0:return
 attempt=1+sum(x['stage']==stage for x in records);log=out/(stage+'-'+str(attempt)+'.log')
 started=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 record={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(record)
 result_file.write_text(json.dumps({'candidate':'26d7c2cb7212f5abdd3866baaf886b8fdbca02e5','machine':'MacBook Air Mac16,12 / 10 cores / 16 GiB / macOS 27.0.1 / AppleClang21.0.0 / CMake4.3.4','scope':'affected graph/common interface and original native Apple/CPU+Apple consumers, not new hybrid paging','stages':records},indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if r.returncode:print('\n'.join(log.read_text(errors='replace').splitlines()[-20:]),flush=True);sys.exit(r.returncode)
cmake='/opt/homebrew/bin/cmake'
run('configure',[cmake,'-S',str(parent),'-B',str(build)])
targets=['hyle_h2_cpu_apple','hyle_h2_contracts','hyle_foundation_a_apple','hyle_f5_public_batch_native']
run('build',[cmake,'--build',str(build),'--target',*targets,'--parallel','10'])
for target in targets:run('run-'+target,[str(build/target)])
headers=['graph.h','compile_report.h','executable.h','native_variants.h','leased_invocation.h','region_provider.h','visibility.h','batch.h','cpu.h']
header_args=[arg for name in headers for arg in ('--header',name)]
run('graph-headers',['/usr/bin/python3',str(source/'scripts/header-self-contained.py'),'--module','graph','--header-dir','graph',*header_args,'--include-dir',str(source/'include'),'--cxx','/usr/bin/clang++','--cxx-compiler-id','AppleClang','--cxx-frontend','GNU'])
print('affected Apple common interface consumers PASS; native hybrid paging remains a separate missing G02 scope',flush=True)
