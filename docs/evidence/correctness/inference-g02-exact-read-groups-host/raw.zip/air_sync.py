from pathlib import Path
import hashlib,json,subprocess,tarfile,io
root=Path.cwd();out=root/'.scratch/inference-gaps/g02'
prefixes=('include/','src/','cmake/','third_party/','tests/','samples/','scripts/')
roots={'CMakeLists.txt','CMakePresets.json','README.md','AGENTS.md','docs/implementation/module-status.json'}
paths=[p for p in subprocess.check_output(['git','ls-files'],text=True).splitlines() if p.startswith(prefixes) or p in roots]
files=[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths]
manifest={'candidate':'26d7c2cb7212f5abdd3866baaf886b8fdbca02e5','maintenance_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'destination':'/Users/kiro/hyle-scratch/compute-unified/source-c8874688','files':files}
(out/'air-input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
remote_script='''from pathlib import Path
import json,hashlib
p=json.load(open("/Users/kiro/hyle-scratch/compute-unified/g02-input-manifest.json"));r=Path(p["destination"])
assert r.is_dir() and not (r/".git").exists()
changed=[]
for x in p["files"]:
 f=r/x["path"]
 if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=x["sha256"]:changed.append(x["path"])
print(json.dumps(changed))
'''
subprocess.run(['scp',str(out/'air-input-manifest.json'),'kiro@172.22.10.198:/Users/kiro/hyle-scratch/compute-unified/g02-input-manifest.json'],check=True)
changed=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -'],input=remote_script,text=True))
archive=out/'air-changed-inputs.tar'
with tarfile.open(archive,'w') as t:
 for p in changed:t.add(root/p,arcname=p,recursive=False)
subprocess.run(['scp',str(archive),'kiro@172.22.10.198:/Users/kiro/hyle-scratch/compute-unified/g02-changed-inputs.tar'],check=True)
apply_script='''from pathlib import Path
import json,hashlib,tarfile
p=json.load(open("/Users/kiro/hyle-scratch/compute-unified/g02-input-manifest.json"));r=Path(p["destination"])
assert r.resolve()==Path("/Users/kiro/hyle-scratch/compute-unified/source-c8874688") and not (r/".git").exists()
with tarfile.open("/Users/kiro/hyle-scratch/compute-unified/g02-changed-inputs.tar") as t:
 for m in t.getmembers():
  assert m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts
  target=r/m.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read())
for x in p["files"]:assert hashlib.sha256((r/x["path"]).read_bytes()).hexdigest()==x["sha256"],x["path"]
print("all canonical product/test inputs matched; unchanged timestamps preserved")
'''
result=subprocess.check_output(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -'],input=apply_script,text=True)
(out/'air-sync.json').write_text(json.dumps({'candidate':manifest['candidate'],'maintenance_commit':manifest['maintenance_commit'],'checked':len(files),'changed':changed,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'result':result},indent=2)+'\n')
print(json.dumps({'checked':len(files),'changed':len(changed),'result':result}),flush=True)
