from pathlib import Path
import subprocess,json,sys,time

base=Path('/root/hyle-scratch/compute-unified')
canonical=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g02')
root=base/'g02-oom-consumer'
root.mkdir(parents=True,exist_ok=True)
source=canonical/'public_hybrid_oom_consumer.cc'
sdk=base/'g02-sdk-static-relocated'
assert sdk.is_dir()
(root/'CMakeLists.txt').write_text(f'''cmake_minimum_required(VERSION 3.25)
project(g02_public_oom LANGUAGES CXX)
find_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS compute graph)
add_executable(oom "{source}")
target_compile_features(oom PRIVATE cxx_std_23)
target_link_libraries(oom PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime(oom)
''')
records=[]
for name,argv in [
 ('configure',['cmake','-S',str(root),'-B',str(root/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(sdk),'-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCUDA_cudart_LIBRARY=/usr/local/cuda-13.3/targets/x86_64-linux/lib/libcudart.so']),
 ('build',['cmake','--build',str(root/'build'),'--parallel','1']),
 ('run',[str(root/'build/oom')])]:
    log=canonical/('oom-'+name+'.log')
    started=time.monotonic()
    with log.open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
    row={'stage':name,'command':argv,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)}
    records.append(row);(canonical/'oom-result.json').write_text(json.dumps({'stages':records},indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if r.returncode:
        print('\n'.join(log.read_text(errors='replace').splitlines()[-20:]),flush=True);sys.exit(r.returncode)
print('\n'.join(log.read_text().splitlines()[-10:]),flush=True)
