$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$slotRoot = 'C:/hyle-scratch/r4-cuda-20260916/retirement'
$slotSource = "$slotRoot/source-a116280b"
$slotBuild = 'C:/hyle-scratch/r3-cpu-20260916/w1-source-shared'
$slotHarness = 'C:/hyle-scratch/r3-cpu-20260916/consumer'
$slotLogs = "$slotRoot/w1-consumers"
function Invoke-SlotCheck([string]$Name, [scriptblock]$Action) {
 & $Action *> "$slotLogs/$Name.log"
 if ($LASTEXITCODE -ne 0) { Get-Content "$slotLogs/$Name.log" -Tail 55; throw "Validation failed: $Name" }
}
Invoke-SlotCheck static-configure {
 cmake -S $slotHarness -B $slotBuild -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=ON -DBUILD_SHARED_LIBS=OFF -DHYLE_BUILD_TESTS=OFF -DHYLE_INSTALL=ON -DHYLE_WERROR=ON -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_COMPUTE_ONEDNN=AUTO -DHYLE_COMPUTE_CUDA=OFF "-DHYLE_SOURCE_DIR=$slotSource" "-DHYLE_SAMPLE_SOURCE_ROOT=$slotSource"
}
Invoke-SlotCheck static-build { cmake --build $slotBuild --parallel 2 }
$slotStage = [IO.Path]::GetFullPath("$slotRoot/w1-sdk-static")
$slotSdk = [IO.Path]::GetFullPath("$slotRoot/w1-sdk-static-relocated")
$slotBoundary = [IO.Path]::GetFullPath($slotRoot).TrimEnd('\') + '\'
if (-not $slotStage.StartsWith($slotBoundary,[StringComparison]::OrdinalIgnoreCase) -or -not $slotSdk.StartsWith($slotBoundary,[StringComparison]::OrdinalIgnoreCase)) { throw 'SDK move escaped validation root' }
if ((Test-Path -LiteralPath $slotStage) -or (Test-Path -LiteralPath $slotSdk)) { throw 'SDK paths already populated' }
Invoke-SlotCheck static-install { cmake --install $slotBuild --prefix $slotStage }
Move-Item -LiteralPath $slotStage -Destination $slotSdk
$slotConsumer = "$slotRoot/w1-consume-static"
Invoke-SlotCheck static-consumer-configure { cmake -S $slotHarness -B $slotConsumer -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$slotSdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$slotSource" }
# Runtime copying into a shared exe directory is serialized.
Invoke-SlotCheck static-consumer-build { cmake --build $slotConsumer --parallel 1 --target r3_consume_compute r3_consume_graph r3_consume_cpu_executor }
if (Test-Path "$slotSdk/bin") {
 foreach ($slotDll in Get-ChildItem -LiteralPath "$slotSdk/bin" -Filter '*.dll' -File) { Copy-Item -LiteralPath $slotDll.FullName -Destination $slotConsumer -Force }
}
foreach ($slotDll in @('msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll')) { Copy-Item -LiteralPath "C:/Windows/System32/$slotDll" -Destination $slotConsumer -Force }
Invoke-SlotCheck static-consumer-tests { ctest --test-dir $slotConsumer --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 -R '^r3_consume_(compute|graph|cpu_executor)$' }
Copy-Item -LiteralPath "$slotConsumer/Testing/Temporary/LastTest.log" -Destination "$slotLogs/static-last-test.log"
Copy-Item -LiteralPath "$slotBuild/CMakeCache.txt" -Destination "$slotLogs/static-CMakeCache.txt"
Get-Content "$slotLogs/static-consumer-tests.log" -Tail 14
