$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$slotSource = 'C:/public/project-hyle/hyle'
$slotRoot = 'C:/hyle-scratch/r4-cuda-20260916/retirement'
$slotBuild = 'C:/hyle-scratch/r3-cpu-20260916/w1-source-shared'
$slotHarness = 'C:/hyle-scratch/r3-cpu-20260916/consumer'
$slotLogs = "$slotRoot/w1-consumers"
New-Item -ItemType Directory -Path $slotLogs -Force | Out-Null
function Invoke-SlotCheck([string]$Name, [scriptblock]$Action) {
  & $Action *> "$slotLogs/$Name.log"
  if ($LASTEXITCODE -ne 0) {
    Get-Content -LiteralPath "$slotLogs/$Name.log" -Tail 60
    throw "Execution-slot validation failed: $Name"
  }
}
Invoke-SlotCheck source-configure {
  cmake -S $slotHarness -B $slotBuild -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=ON -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_COMPUTE_ONEDNN=AUTO -DHYLE_COMPUTE_CUDA=OFF "-DHYLE_SOURCE_DIR=$slotSource" "-DHYLE_SAMPLE_SOURCE_ROOT=$slotSource"
}
Invoke-SlotCheck source-build {
  cmake --build $slotBuild --parallel 2 --target hyle_compute_provider_onednn_test hyle_compute_provider_onednn_composition_test hyle_compute_provider_onednn_graph_test hyle_compute_route_cpu_test hyle_graph_provider_onednn_test hyle_graph_route_cpu_test hyle_graph_route_cpu_cpu_executor_test r3_consume_compute r3_consume_graph r3_consume_cpu_executor
}
# Use the actual producer DLLs and stage them beside every selected executable.
$slotDlls = @(Get-ChildItem -LiteralPath "$slotBuild/hyle_build/src" -Recurse -Filter '*.dll' -File) + @(Get-ChildItem -LiteralPath "$slotBuild/bin" -Filter '*.dll' -File)
if (@($slotDlls | Group-Object Name | Where-Object Count -gt 1).Count -ne 0) { throw 'Ambiguous DLL producer' }
$slotDirectories = @($slotBuild) + @(Get-ChildItem -LiteralPath "$slotBuild/hyle_build/tests" -Recurse -Filter '*.exe' -File | ForEach-Object DirectoryName | Sort-Object -Unique)
$slotCrt = @('msvcp140.dll','msvcp140_atomic_wait.dll','vcruntime140.dll','vcruntime140_1.dll')
foreach ($slotDir in $slotDirectories) {
  foreach ($slotDll in $slotDlls) { Copy-Item -LiteralPath $slotDll.FullName -Destination (Join-Path $slotDir $slotDll.Name) -Force }
  foreach ($slotDll in $slotCrt) { Copy-Item -LiteralPath "C:/Windows/System32/$slotDll" -Destination (Join-Path $slotDir $slotDll) -Force }
}
$slotDlls | ForEach-Object { [ordered]@{ Source=$_.FullName; Sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash } } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$slotLogs/source-dlls.json" -Encoding utf8
Invoke-SlotCheck source-tests {
  ctest --test-dir $slotBuild --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 -R '^hyle_(compute_provider_onednn|compute_route_cpu|graph_provider_onednn|graph_route_cpu)(_header_self_contained|_composition|_graph|_cpu_executor)?_test$|^r3_consume_(compute|graph|cpu_executor)$'
}
Copy-Item -LiteralPath "$slotBuild/Testing/Temporary/LastTest.log" -Destination "$slotLogs/source-last-test.log"
Copy-Item -LiteralPath "$slotBuild/CMakeCache.txt" -Destination "$slotLogs/source-CMakeCache.txt"
Get-Content -LiteralPath "$slotLogs/source-tests.log" -Tail 18
# Switch this validation build to the ordinary SDK configuration before install.
Invoke-SlotCheck shared-configure {
  cmake -S $slotHarness -B $slotBuild -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=OFF -DHYLE_INSTALL=ON -DHYLE_WERROR=ON -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_COMPUTE_ONEDNN=AUTO -DHYLE_COMPUTE_CUDA=OFF "-DHYLE_SOURCE_DIR=$slotSource" "-DHYLE_SAMPLE_SOURCE_ROOT=$slotSource"
}
Invoke-SlotCheck shared-build { cmake --build $slotBuild --parallel 2 }

$slotStage = [IO.Path]::GetFullPath("$slotRoot/w1-sdk-shared")
$slotSdk = [IO.Path]::GetFullPath("$slotRoot/w1-sdk-shared-relocated")
$slotBoundary = [IO.Path]::GetFullPath($slotRoot).TrimEnd('\') + '\'
if (-not $slotStage.StartsWith($slotBoundary,[StringComparison]::OrdinalIgnoreCase) -or -not $slotSdk.StartsWith($slotBoundary,[StringComparison]::OrdinalIgnoreCase)) { throw 'SDK move escaped validation root' }
if ((Test-Path -LiteralPath $slotStage) -or (Test-Path -LiteralPath $slotSdk)) { throw 'SDK paths are not fresh' }
Invoke-SlotCheck shared-install { cmake --install $slotBuild --prefix $slotStage }
Move-Item -LiteralPath $slotStage -Destination $slotSdk
$slotConsumer = "$slotRoot/w1-consume-shared"
Invoke-SlotCheck shared-consumer-configure { cmake -S $slotHarness -B $slotConsumer -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$slotSdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$slotSource" }
Invoke-SlotCheck shared-consumer-build { cmake --build $slotConsumer --parallel 2 --target r3_consume_compute r3_consume_graph r3_consume_cpu_executor }
foreach ($slotDll in Get-ChildItem -LiteralPath "$slotSdk/bin" -Filter '*.dll' -File) { Copy-Item -LiteralPath $slotDll.FullName -Destination $slotConsumer -Force }
foreach ($slotDll in $slotCrt) { Copy-Item -LiteralPath "C:/Windows/System32/$slotDll" -Destination $slotConsumer -Force }
Invoke-SlotCheck shared-consumer-tests { ctest --test-dir $slotConsumer --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -j 1 -R '^r3_consume_(compute|graph|cpu_executor)$' }
Copy-Item -LiteralPath "$slotConsumer/Testing/Temporary/LastTest.log" -Destination "$slotLogs/shared-last-test.log"
Get-Content -LiteralPath "$slotLogs/shared-consumer-tests.log" -Tail 12
