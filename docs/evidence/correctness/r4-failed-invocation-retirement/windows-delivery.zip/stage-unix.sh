#!/usr/bin/env bash
set -euo pipefail
slot_root=$1
slot_archive=$2
case "$slot_root" in
 /root/hyle-validation/r4-slot-a116280b|/Users/kiro/hyle-validation/r4-slot-a116280b) ;;
 *) exit 2 ;;
esac
if command -v sha256sum >/dev/null; then slot_hash=$(sha256sum "$slot_archive" | cut -d' ' -f1); else slot_hash=$(shasum -a 256 "$slot_archive" | cut -d' ' -f1); fi
[ "$slot_hash" = edac1b9c6c7a02196b838272d9fd6fae8ef71c3afaeecbd161385862ecec188b ]
test ! -e "$slot_root/source/CMakeLists.txt"
mkdir -p "$slot_root/source"
tar -xzf "$slot_archive" -C "$slot_root/source"
printf '%s\n' a116280bd73678db2790de6ea1d2758ea34b1bf0 > "$slot_root/candidate.txt"
printf '%s\n' "$slot_hash" > "$slot_root/archive.sha256"
echo 'Full canonical a116280b archive staged and verified'
