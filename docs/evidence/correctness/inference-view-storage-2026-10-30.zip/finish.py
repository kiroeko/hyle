from pathlib import Path
import importlib.util
import json
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('batch', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin = b.read, b.save, b.pin


def report():
    plan = read(W / 'plan.json')
    for name in plan['units']:
        b.b.receipt(name)
    for identity in plan['retained']:
        b.exact(identity)
    save(W / 'model-link-base.json', dict(schema='hyle.view-storage.current-link-base.v1',
        base=plan['base'], compile=plan['units']['model']['compile'], link=plan['units']['model']['link'],
        consumer_source=pin(plan['units']['model']['source']), previous_consumer=pin(W / 'compile/model/receipt.json'),
        retained=plan['retained'], runtime=plan['runtime'], sdk_engine_dependencies=plan['sdk']))
    current = []
    for case in plan['cases']:
        folder = W / 'runs' / case / 'attempt1'
        result = read(folder / 'report.json')
        assert result['status'] == 'PASS'
        current.append(dict(case=case, report=pin(folder / 'report.json'), process=read(folder / 'process.json'),
            tests=result.get('tests')))
    comparisons = []
    for case in ('natural-cuda', 'continuous-cuda'):
        prior = R / '.scratch/inference-kimi-source-lifecycle-20261030/runs' / case / 'attempt2/report.json'
        current_report = W / 'runs' / case / 'attempt1/report.json'
        assert read(prior) == read(current_report)
        comparisons.append(dict(case=case, previous=pin(prior), current=pin(current_report), full_report_equal=True))
    processes = list(W.rglob('process.json'))
    assert all(read(path)['state'] == 'TERMINAL' for path in processes)
    counts = {kind: len([p for p in processes if p.is_relative_to(W / directory)])
        for kind, directory in [('CXX_attempts', 'compile'), ('link_attempts', 'link'), ('native_attempts', 'runs')]}
    files = [pin(path) for path in sorted((W / 'bin').iterdir()) if path.is_file()]
    save(W / 'cleanup-plan.json', dict(root=str(W / 'bin'), files=files, bytes=sum(p['bytes'] for p in files)))
    paths = subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).splitlines()
    paths += ['tests/tools/inference_submission_views_test.cc']
    sources = [R / p for p in sorted(set(paths)) if p.startswith(('src/', 'engine/', 'tests/'))]
    (W / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *[str(p.relative_to(R)) for p in sources]], cwd=R))
    (W / 'inference_submission_views_test.cc').write_bytes((R / 'tests/tools/inference_submission_views_test.cc').read_bytes())
    evidence = dict(schema='hyle.correctness.view-storage.v1', date='2026-10-30', status='PASS',
        base_commit=plan['worktree_base_commit'], sources=[pin(path) for path in sources],
        change='SubmissionViews borrows each selected output, Store and page view actual StorageOwner instead of imposing one owner for every resource; original SubmissionSource metadata owner remains separate.',
        invariants=[
            'OutputCapture, StoreCapture and PageCapture borrow their actual owner only during the original synchronous prepare/capture call.',
            'Qwen projects original Store/append arrays with standard transform views; no transient vector, owner copy, callback storage, new memory pool or executor.',
            'SubmissionSource success-only Completion transfer, original Queue/Context/owner/extent checks and late partial failure recovery stay authoritative.',
            'Wrong second output owner leaves the transferred original SubmissionSource and first view alive for original retirement and withdrawal.',
            'Qwen keeps actual role/state/NextN rules; Kimi uses the same original single-output convenience with empty resource ranges.'],
        current_runs=current, comparisons=comparisons,
        counts=dict(**counts, retained_SDK_engine_inputs=227, SDK_rebuilds=0, NVCC=0, downloads=0,
            whole_builds=0, throughput_windows=0),
        reviewed_boundaries=[
            dict(files=['engine/inference/cold_shape_plan.h','engine/inference/prepared_program_family.h','engine/inference/program_slots.h',
                'engine/models/qwen35/main.cc:find_child/admit_exact_shape/prepare_child'],
                finding='Existing cold admission, rollback, child validation, IO and stable slot installation already share mechanisms. Remaining role/packing/diagnostic selection and tensor/state mappings are model facts; no additional Family or ModelOps wrapper justified.'),
            dict(files=['engine/models/qwen35/main.cc:prepare_generation_call/finish_recursive_mtp/finish_mtp_rounds/finish_selected_evaluations',
                'engine/inference/mtp_acceptance.h','engine/inference/mtp_acceptance_graph.h'],
                finding='K1 and recursive paths share host acceptance and real resource/repair/ledger/Head publication sequence; random recursive validation keeps its device packet. Result/ledger field projection alone does not justify a new generic algorithm or owner.'),
            dict(files=['src/graph/resources.cc:OutputSource::create/StoreSource::prepare/ResourceSource::prepare',
                'src/graph_batch/paged_append.cc'],
                finding='Per-view original owner is valid within actual Graph Context gates; one Queue/source producer and current Backend endpoint assembly remain real capability limits, not removed by this change.')],
        limits=[
            'Directed test covers two real storage resources in one CUDA Context and one original Graph/Queue; not multi-GPU or distributed execution.',
            'No new mixed-owner Store/page native fixture; Qwen finite runs exercise their new borrowed descriptors with original same-owner state and pages.',
            'Kimi original23-role component is not a complete second engine or token generation.',
            'No new Apple, Vulkan, CPU, simultaneous GPU overlap, complete engine C++ API or throughput claim.',
            'Common complete-step/state publication boundaries and performance remain unfinished; review findings do not mark the whole architecture complete.'],
        cleanup_plan=read(W / 'cleanup-plan.json'))
    save(W / 'evidence.json', evidence)
    print(json.dumps(dict(counts=counts, comparisons=comparisons, cleanup_bytes=evidence['cleanup_plan']['bytes'])))


def pack():
    evidence = read(W / 'evidence.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'COMPLETE'
    evidence['cleanup'] = cleanup
    stem = R / 'docs/evidence/correctness/inference-view-storage-2026-10-30'
    save(stem.with_suffix('.json'), evidence)
    with zipfile.ZipFile(stem.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or path.is_relative_to(W / 'bin') or path.suffix.lower() in ('.obj','.pdb','.exe','.dll','.lib','.exp','.map'):
                continue
            archive.write(path, path.relative_to(W).as_posix())
    print(json.dumps(dict(evidence=pin(stem.with_suffix('.json')), archive=pin(stem.with_suffix('.zip')))))


if __name__ == '__main__':
    {'report':report,'pack':pack}[sys.argv[1]]()
