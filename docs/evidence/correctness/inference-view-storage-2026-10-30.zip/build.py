from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-multimodel-observation-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    base_path = R / '.scratch/inference-kimi-source-lifecycle-20261030/model-link-base.json'
    base = read(base_path)
    for item in [*base['retained'], base['runtime'], base['sdk_engine_dependencies']]:
        exact(item)
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']:
            exact(item)
    prior = read(R / '.scratch/inference-kimi-source-lifecycle-20261030/plan.json')['units']['kimi']
    folder = W / 'compile/kimi'
    folder.mkdir(parents=True, exist_ok=True)
    command = []
    for index, arg in enumerate(prior['compile']):
        if index and prior['compile'][index - 1].lower() == '/sourcedependencies':
            arg = str(folder / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(folder / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(folder / 'unit.pdb')
        command.append(arg)
    old_object = read(base['previous_consumer']['path'])['object']['path']
    link = []
    for arg in base['link']:
        if key(arg) == key(old_object):
            arg = str(folder / 'unit.obj')
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/kimi').with_suffix(suffix))
                break
        link.append(arg)
    for library in ('gtest_main.lib', 'gtest.lib'):
        path = R / '.scratch/build-compute-v2-dev/lib' / library
        if not any(key(arg) == key(path) for arg in link):
            link.append(str(path))
    assert sum(key(arg) == key(folder / 'unit.obj') for arg in link) == 1
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    fixture = R / '.scratch/inference-kimi-original-binding-20261025/payload-only/attempt1'
    assert fixture.is_dir()
    units = {'kimi': dict(source=prior['source'], compile=command, link=link)}
    shutil.copyfile(R / '.scratch/inference-kimi-source-lifecycle-20261030/model.cc', W / 'model.cc')
    for name, source in [('model', W / 'model.cc'), ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index - 1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(base['consumer_source']['path']):
                arg = str(source)
            args.append(arg)
        links = []
        for arg in base['link']:
            if key(arg) == key(old_object):
                arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            links.append(arg)
        assert sum(key(arg) == key(source) for arg in args) == 1
        assert sum(key(arg) == key(folder / 'unit.obj') for arg in links) == 1
        units[name] = dict(source=str(source), compile=args, link=links)
    folder = W / 'compile/views'
    folder.mkdir(parents=True, exist_ok=True)
    source = R / 'tests/tools/inference_submission_views_test.cc'
    args = []
    for index, arg in enumerate(command):
        if index and command[index - 1].lower() == '/sourcedependencies':
            arg = str(folder / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(folder / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(folder / 'unit.pdb')
        elif key(arg) == key(prior['source']):
            arg = str(source)
        args.append(arg)
    links = []
    for arg in link:
        if key(arg) == key(W / 'compile/kimi/unit.obj'):
            arg = str(folder / 'unit.obj')
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/views').with_suffix(suffix))
                break
        links.append(arg)
    assert sum(key(arg) == key(source) for arg in args) == 1
    units['views'] = dict(source=str(source), compile=args, link=links)
    continuous = W / 'continuous-input'
    continuous.mkdir(exist_ok=True)
    for file in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(R / '.scratch/inference-continuous-wave-20261027/inputs/context32' / file, continuous / file)
    original = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    save(W / 'plan.json', dict(base=pin(base_path), units=units,
        retained=base['retained'], runtime=base['runtime'], sdk=base['sdk_engine_dependencies'],
        worktree_base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
        original_fixture=dict(directory=str(fixture), complete=pin(fixture / 'complete.json')),
        environment=dict(HYLE_KIMI_ORIGINAL_ATTENTION_DIR=str(fixture)),
        cases={'views-cuda': dict(unit='views', filter='InferenceSubmissionViewsCuda.*', tests=2),
            'kimi-cuda': dict(unit='kimi', filter='KimiHeterogeneousStatePlan.*:KimiHeterogeneousState.*', tests=7),
            'natural-cuda': dict(unit='model', args=['natural', 'cuda', str(original)]),
            'continuous-cuda': dict(unit='ordinary', args=['--cuda-continuous', str(continuous)])}))
    print('Prepared owner-view test, Kimi and two affected Qwen TUs; all 227 SDK/engine inputs retained; no download.')


def run(name, attempt):
    plan = read(W / 'plan.json')
    case = plan['cases'][name]
    b.receipt(case['unit'])
    image = read(W / ('ready-' + case['unit'] + '.json'))
    exact(image)
    folder = W / 'runs' / name / attempt
    os.environ.update(plan['environment'], HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    save(folder / 'image.json', image)
    if 'tests' in case:
        b.b.execute([image['path'], '--gtest_color=no', '--gtest_filter=' + case['filter'],
            '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors', '0') == '0'
        assert not result.findall('.//skipped')
        report = dict(status='PASS', tests=case['tests'], failures=0, skipped=0,
            cases=[dict(name=t.get('classname') + '.' + t.get('name'), seconds=t.get('time'),
                properties={p.get('name'): p.get('value') for p in t.findall('./properties/property')})
                for t in result.findall('.//testcase')])
    else:
        b.b.execute([image['path'], *case['args']], folder, 600)
        report = read(folder / 'stdout.log')
        assert report['status'] == 'PASS'
    save(folder / 'report.json', report)
    print('PASS', name)


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'run':
        run(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else 'attempt1')
    else:
        b.main()
