"""Prepare exact disposable leaf identities only; never delete or write test.ps1."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

Q = Path(__file__).resolve().parent
R = Q.parents[1]


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path=Path(path).resolve()
    with path.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest)


def main():
    out=Q/'cleanup-plan.json'; assert not out.exists(), 'Never overwrite a prior cleanup plan'
    published=read(Q/'published.json'); report=read(published['manifest']['path'])
    assert identity(published['manifest']['path'])==published['manifest']
    assert identity(published['archive']['path'])==published['archive']
    keep=read(Q/'qwen-ready-attempt3.json')['image']; assert identity(keep['path'])==keep
    assert report['current_image']==keep
    targets=[]
    for folder in sorted(Q.glob('*-link[123]')):
        assert folder.is_dir() and folder.resolve().parent==Q
        stem=folder.name.rsplit('-link',1)[0]
        if stem not in ('qwen','probe','batch-probe','prefix-tests'): continue
        suffixes=('.map','.lib','.exp') if folder.name=='qwen-link3' else ('.exe','.map','.lib','.exp')
        for suffix in suffixes:
            path=(folder/(stem+suffix)).resolve()
            if not path.exists(): continue
            assert path.is_file() and path.parent==folder and path.is_relative_to(Q)
            assert suffix in ('.exe','.map','.lib','.exp') and path!=Path(keep['path'])
            targets.append(identity(path))
    counts={suffix:sum(Path(x['path']).suffix=='.'+suffix for x in targets) for suffix in ('exe','map','lib','exp')}
    value=dict(created_utc=datetime.now(timezone.utc).isoformat(),status='PLAN ONLY; nothing deleted',allowed_root=str(Q),
        publication=published,keep_latest_image=keep,targets=targets,counts=counts,target_count=len(targets),
        total_bytes=sum(x['bytes'] for x in targets),total_GiB=sum(x['bytes'] for x in targets)/(1024**3),
        raw_policy='Keep ALL Q raw vectors in this simple plan, including old duplicates. Only images/maps/import/export tables are selected; no raw-deletion or alias-recovery framework.',
        keep='Keep qwen-link3/qwen.exe, every object, runtimeDLL, source, command, recipe, metadata, log, review, vector, archive and fixed dependency/SDK cache.',
        execution='Root must write verified exact leaf operations into repository test.ps1 and execute separately. This script never writes that file, deletes anything, or performs recursive removal.')
    with out.open('x',encoding='utf-8') as stream: json.dump(value,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(plan=identity(out),counts=counts,bytes=value['total_bytes'],GiB=value['total_GiB']),indent=2))


if __name__=='__main__': main()
