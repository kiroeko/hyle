from pathlib import Path
R=Path(__file__).resolve().parents[2];Q=Path(__file__).resolve().parent
p=R/'tools/qwen35_text/main.cc';s=p.read_text(encoding='utf-8')
s=s.replace('std::unique_ptr<Family> family, probe_family;', 'std::map<std::size_t, std::unique_ptr<Family>> families, probe_families;')
s=s.replace('std::map<std::size_t, std::unique_ptr<Phase>> phases, probe_phases;', 'using ExecutionShape = std::pair<std::size_t, std::size_t>; // (requests, tokens/request)\n  std::map<ExecutionShape, std::unique_ptr<Phase>> phases, probe_phases;')
s=s.replace('std::map<std::size_t, std::array<std::size_t, 2>> planned_slot_uses;', 'std::map<ExecutionShape, std::array<std::size_t, 2>> planned_slot_uses;')
s=s.replace('  ~Model() {\n', '  ~Model() {\n    abort_episode().IgnoreError();\n')
start=s.index('  void prepare_cache(');end=s.index('  void prepare_family(',start)
section=s[start:end]
section=section.replace('void prepare_cache(std::size_t max_query_rows)', 'void prepare_cache()')
section=section.replace('''      if (attention_schema.capacity().max_query_rows != max_query_rows)
        throw std::runtime_error("shared Qwen cache schema was prepared for another finite family");
''','')
section=section.replace('.max_requests = 1, .max_query_rows = static_cast<std::uint32_t>(max_query_rows),\n        .max_kv_rows = static_cast<std::uint32_t>(capacity),', '.max_requests = cache_plan.max_requests, .max_query_rows = cache_plan.max_query_rows,\n        .max_kv_rows = cache_plan.max_kv_rows,')
s=s[:start]+section+s[end:]
s=s.replace('auto &selected = diagnostic ? probe_family : family;', 'auto &selected = diagnostic ? probe_families[requests] : families[requests];')
s=s.replace('prepare_cache(max_query_rows);', '''if (requests > cache_plan.active_sequences || cache::multiply(requests, max_query_rows) > cache_plan.max_query_rows)
      throw std::runtime_error("finite family exceeds the configured batch capacity");
    prepare_cache();''')
s=s.replace('return layer0_probe.empty() ? family.get() : probe_family.get();', 'return layer0_probe.empty() ? static_cast<const void *>(&families) : static_cast<const void *>(&probe_families);')
s=s.replace('void plan_execution(std::span<const std::size_t> calls, bool either_slot = false)', 'void plan_execution(std::span<const std::size_t> calls, bool either_slot = false, std::size_t requests = 1)')
s=s.replace('''if (!family || std::find(family->chunks.begin(), family->chunks.end(), tokens) == family->chunks.end())''', '''if (!families.contains(requests) || std::find(families.at(requests)->chunks.begin(), families.at(requests)->chunks.end(), tokens) == families.at(requests)->chunks.end())''')
s=s.replace('auto &uses = planned_slot_uses[tokens];', 'auto &uses = planned_slot_uses[{requests, tokens}];')
s=s.replace('if (!family || (!layer0_probe.empty() && !probe_family))', 'if (!families.contains(1) || (!layer0_probe.empty() && !probe_families.contains(1)))')
s=s.replace('{family.get(), layer0_probe.empty() ? nullptr : probe_family.get()}', '{families.at(1).get(), layer0_probe.empty() ? nullptr : probe_families.at(1).get()}')
s=s.replace('planned_slot_uses.contains(tokens)', 'planned_slot_uses.contains({1, tokens})')
s=s.replace('definition.last_row, phase.tokens.description.dimensions()[0] - 1', 'definition.last_row, phase.tokens.description.dimensions()[0] / static_cast<std::int64_t>(definition.requests) - 1')
s=s.replace('check(run.bind(phase.position_port, phase.positions.read()));', 'check(run.bind(phase.position_port, phase.positions.read()));\n    if (definition.requests != 1) check(run.bind(phase.last_ids_port, phase.last_ids.read()));')
s=s.replace('Phase &prepare_child(std::size_t tokens, bool diagnostic)', 'Phase &prepare_child(std::size_t tokens, bool diagnostic, std::size_t requests = 1)')
s=s.replace('const auto found = cache.find(tokens);', 'const auto found = cache.find({requests, tokens});')
s=s.replace('phase.planned_slot_uses = planned_slot_uses.at(tokens);', 'phase.planned_slot_uses = planned_slot_uses.at({requests, tokens});')
s=s.replace('''phase.tokens = Tensor(memory.ref(), dense(Type::kInt32, {t}));
    phase.positions = Tensor(memory.ref(), phase.tokens.description);''', '''phase.tokens = Tensor(memory.ref(), dense(Type::kInt32, {t * static_cast<std::int64_t>(requests)}));
    phase.positions = Tensor(memory.ref(), requests == 1 ? dense(Type::kInt32, {t})
        : dense(Type::kInt32, {static_cast<std::int64_t>(requests), t}));
    if (requests != 1) {
      phase.last_ids = Tensor(memory.ref(), dense(Type::kInt32, {static_cast<std::int64_t>(requests)}));
      std::vector<std::int32_t> last_ids(requests);
      for (std::size_t j = 0; j < requests; ++j) last_ids[j] = static_cast<std::int32_t>((j + 1) * tokens - 1);
      phase.last_ids.write<std::int32_t>(last_ids);
    }''')
s=s.replace('cache.emplace(tokens, std::move(result))', 'cache.emplace(ExecutionShape{requests, tokens}, std::move(result))')
s=s.replace('std::string(label) + "-T"', 'std::string(label) + "-R" + std::to_string(requests) + "-T"')
start=s.index('  // One original episode is prepared without submitting')
end=s.index('\n};\n\nstd::vector<std::int32_t> read_ids',start)
s=s[:start]+(Q/'evaluation.inc').read_text(encoding='utf-8')+s[end:]
s=s.replace('tensor.buffer.view().as_const()', 'mem::ConstBufferView(tensor.buffer.view())')
s=s.replace('model.plan_execution(run.chunks, prefix_enabled);', 'model.plan_execution(run.chunks, prefix_enabled || multiple_schedules);')
# The episode carries strong Session owners. Detach links before releasing those
# owners, including when Model shutdown is the final outstanding owner.
start=s.index('\nstd::vector<std::int32_t> read_ids')
s=s[:start]+'''
hyle::Status Session::stop() noexcept {
  if (stopping) return hyle::Status::Ok();
  stopping = true;
  if (pending) {
    pending->cancelled = true;
    if (pending->completion.valid()) {
      const auto cancelled = pending->completion.request_cancel();
      if (!cancelled.IsUnimplemented()) retirement_status.Update(cancelled);
    }
    if (pending->run) pending->run->close().IgnoreError();
  }
  return retirement_status;
}
hyle::Result<bool> Session::try_retire() noexcept {
  if (!stopping) return std::unexpected(hyle::Status::FailedPrecondition("stop the Qwen session before retirement"));
  if (pending) {
    HYLE_ASSIGN_OR_RETURN(auto retired, model_->try_retire_episode());
    if (!retired) return false;
  }
  tails = {}; tail_head = nullptr; head.reset(); return true;
}
hyle::Status Session::drain() noexcept {
  hyle::Status status;
  if (pending) status.Update(model_->abort_episode());
  status.Update(retirement_status); return status;
}
Session::~Session() { drain().IgnoreError(); }
''' + s[start:]
p.write_text(s,encoding='utf-8',newline='\n')
