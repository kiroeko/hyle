from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'docs/developer/current-work.md';s=p.read_text(encoding='utf-8')
s=s.replace('更新：**2026-10-21**。','更新：**2026-10-22**。',1)
old='**当前正在做：执行资源已改为Model按实际并发复用，相关状态／寿命回归和两组完整性能对照已完成；下一步接真实多序列batch。**'
new='**当前正在做：真实Qwen B2／T1已用一次Graph执行跑通，正在补批次取消／退休和调度入口。** KV及row-cache的typed页帧组合／投影已完成；统一执行路径支持独立Conv／GDN状态、各自历史与结果分流，候选状态按N＋R计费。普通CLI调度仍是串行交错，尚未接批次调度或测多人吞吐。'
assert old in s;s=s.replace(old,new,1)
anchor='| 2d | 多序列批处理与其它后端 |'
rows=s.splitlines()
for i,row in enumerate(rows):
    if row.startswith(anchor):
        rows[i]='| 2d | 多序列批处理与其它后端 | **[typed组合／投影已完成](../evidence/correctness/paged-frame-reframe-2026-10-21.json)，真实Qwen B2／T1数学链已跑通**。同一次Graph处理两份不同长度历史，返回各自KV／36份状态及next ID，之后可分别B1续算；152组向量指标已保存，跨B数值并非逐字节相同，不以greedy ID相同代替质量验收。正在完成批次取消／退休，再接CLI等T调度与N份committed准入，最后做完整四项性能对照。Apple／Vulkan原生新写页及完整消费者另有缺口 |'
s='\n'.join(rows)+'\n'
s=s.replace('近期顺序：**执行资源复用及本批相关回归／两组对照已完成 → typed页帧组合与真实多序列batch → MTP真实消费者 → 图片链路**。','近期顺序：**typed页帧与真实B2计算已接通 → 批次取消／退休及CLI等T调度 → 真batch完整性能对照 → MTP真实消费者 → 图片链路**。')
s=s.replace('本轮资源复用已收尾，实际结果见页末。','执行资源复用的完整性能窗口保留在页末；新增B2代码尚未完成新的性能对照。')
needle='每批有实际结果就更新本页状态；'
insert='本批公共页帧有27项arena、7项row-cache检查及CPU／CUDA双请求实际Graph检查；只选来源允许的行和目标页，旧帧权限与字节不变。统一Qwen执行改造的原单会话／多会话及前缀回归继续核对；B1基线与B2的MatMul形状／合法归约可能不同，跨B误差、模型质量和速度分别报告。\n'
s=s.replace(needle,insert+needle,1)
p.write_text(s,encoding='utf-8',newline='\n')
p=R/'tools/qwen35_text/README.md';s=p.read_text(encoding='utf-8')
s=s.replace('一次替换会话head。失败保留旧head并按真实退休回收候选，不发布部分状态。','对全部参与会话检查expected base后，以无抛交换提交整批head。失败保留全部旧head并按真实退休回收候选，不发布部分状态。',1)
s=s.replace('`stop`只撤回本会话提交／发布资格并关闭自己的pending槽，不关闭Model共享池；`try_retire`只在原Completion及页权限退休门通过后清理本会话状态。','Model拥有一个批次episode及参与Session的强引用，Session只借用pending链接。`stop`停止任一参与者时采用整批取消政策，关闭本次借用而不关闭Model池；其它会话保原head，退休后可以重试。`try_retire`只在原Completion及页权限退休门通过后清理本会话状态。',1)
s=s.replace('没有新增多候选并发调度。','批内多候选由同一episode持有，没有第二套执行器。普通CLI尚未接入此批次API。',1)
s=s.replace('会话parity按自己的实际Graph调用前进，完整命中不翻转，采用前缀新会话从0开始；轮次切换不重置parity，也不执行预热。','物理槽parity归Model，按实际成功Graph批次前进；完整命中不翻转，采用前缀或切换会话不重置槽，也不执行预热。',1)
s=s.replace('前缀命中会跳调用或重置会话parity，因此对各可能slot及真实检查点suffix保守计数。','前缀命中会跳调用、多会话会改变实际槽次序，因此对各可能slot及真实检查点suffix保守计数。',1)
start=s.index('当前页大小16。设容量为C、实际可保留会话／完整快照数为N，')
end=s.index('\n\n',start)
s=s[:start]+'''当前页大小16。设每序列容量C、可保留完整快照数N、一次批次最多R条序列（1≤R≤N）：12份KV arena各容纳`N*ceil(C/16)+R`页，36份conv/GDN池各有N＋R个块。单版本有效载荷合计19,537,920字节，各backing另有1字节尾部；总额为`12*((N*ceil(C/16)+R)*16*1024+1)+19,537,920*(N+R)+36`。query／KV行和page refs的schema上限是批内各请求之和，物理页池按不同物理页计数。CLI当前仍按R1的串行执行准备额度；C256、N1／N2为42,418,224／65,101,872字节。额外候选不是历史检查点额度；调度方还须保证发布后的distinct committed版本不超过N。显式保留的旧Snapshot继续占版本／页，同一Snapshot别名不重复计版本。

独立`hyle_qwen35_batch_probe`用同一Model执行真实B2／T1：普通线性层使用packed行，Conv／GDN用独立B维，历史通过普通Graph的Concat收集、结果Slice／Copy回各自输出租约，KV用公共`PagedArena::reframe`组合与投影。一次submit对应一个原Invocation／Completion，不是两次evaluate合并统计。第一步只支持等T矩形批次；不同T须由引擎分桶，不能用会改变recurrent状态的虚假padding。运行传`--inputs DIR --output NEW_DIR`，使用原P128输入，不复制权重。探针比较独立B1同分块、旧状态、结果分流和继续推理；B变化可改变合法矩阵归约，原始误差指标与greedy ID分别记录，未定义跨B完整模型质量阈值。状态打包／拆分的搬运成本仍待真batch性能窗口测量；普通CLI的`--active-sequences`暂不启用此路径。''' +s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
p=R/'docs/architecture/compute-design.md';s=p.read_text(encoding='utf-8')
old='分页路径收齐12份KV帧与36份conv/GDN结果、撤回已退休状态绑定后一次提交；单会话与四会话交错淘汰重建已逐字节对照。'
new='分页路径在一个批次episode内收齐每个参与者的12份KV帧与36份conv/GDN结果、撤回已退休状态绑定，并验证全部expected base后提交各head。Model持有参与Session直至真实退休，Session仅借用pending链接；整批取消保留所有旧head。N份已提交版本和R份同时候选分开计费，前端仍负责发布后N份版本的准入／淘汰。单会话与四会话交错淘汰重建已逐字节对照；真实B2／T1另核分流、旧帧和继续推理，不以跨B输出逐字节相同为默认承诺。'
assert old in s;s=s.replace(old,new,1);p.write_text(s,encoding='utf-8',newline='\n')
