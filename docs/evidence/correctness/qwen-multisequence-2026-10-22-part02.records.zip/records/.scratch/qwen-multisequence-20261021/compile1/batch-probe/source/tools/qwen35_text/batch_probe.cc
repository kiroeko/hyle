// Explicit native correctness consumer of the original unified Model path.
// No throughput result, alternative executor or oracle feedback into inputs.
#define main hyle_qwen35_text_consumer_main
#include "main.cc"
#undef main

#include <cstring>
#include "hyle/compute/detail/paged_arena_access.h"

namespace {
namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;

void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}

std::string json_string(std::string_view text) {
  std::ostringstream out; out << '"';
  for (const auto value : text) {
    const auto ch = static_cast<unsigned char>(value);
    if (ch == '"' || ch == '\\') out << '\\' << value;
    else if (ch == '\n') out << "\\n";
    else if (ch == '\r') out << "\\r";
    else if (ch == '\t') out << "\\t";
    else if (ch < 32) out << "\\u00" << std::hex << std::setw(2) << std::setfill('0') << unsigned(ch) << std::dec;
    else out << value;
  }
  out << '"'; return out.str();
}

Bytes read_lease(const c::ReadLease &lease) {
  Bytes result(lease.size()); q::check(q::take(lease.view()).read(result)); return result;
}

Bytes read_file(const std::filesystem::path &path, std::size_t expected) {
  std::ifstream stream(path, std::ios::binary | std::ios::ate);
  require(static_cast<bool>(stream), "missing actual output vector");
  require(stream.tellg() == static_cast<std::streamoff>(expected), "per-Session trace has an unexpected byte extent");
  stream.seekg(0); Bytes bytes(expected);
  stream.read(reinterpret_cast<char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
  require(static_cast<bool>(stream), "cannot read complete actual output vector"); return bytes;
}

struct Metric final {
  std::string name, baseline_path, batch_path, dtype;
  std::size_t bytes = 0, elements = 0, nonfinite_baseline = 0, nonfinite_batch = 0, zero_reference_mismatches = 0;
  double max_abs = 0, squared_error = 0, reference_squared = 0, batch_squared = 0, dot = 0, max_relative_nonzero_reference = 0;
  bool byte_equal = false;
};

Metric compare(const std::filesystem::path &baseline, const std::filesystem::path &batch,
               std::string name, std::size_t bytes, bool bf16) {
  const auto a = read_file(baseline, bytes), b = read_file(batch, bytes);
  Metric result; result.name = std::move(name); result.baseline_path = baseline.string(); result.batch_path = batch.string();
  result.dtype = bf16 ? "BF16" : "F32"; result.bytes = bytes;
  const auto width = bf16 ? sizeof(std::uint16_t) : sizeof(float);
  require(bytes % width == 0, "output extent is not scalar aligned"); result.elements = bytes / width;
  result.byte_equal = a == b;
  const auto scalar = [&](const Bytes &data, std::size_t index) {
    if (bf16) {
      std::uint16_t word = 0; std::memcpy(&word, data.data() + index * width, sizeof(word));
      return std::bit_cast<float>(std::uint32_t(word) << 16);
    }
    float value = 0; std::memcpy(&value, data.data() + index * width, sizeof(value)); return value;
  };
  for (std::size_t i = 0; i < result.elements; ++i) {
    const double x = scalar(a, i), y = scalar(b, i);
    result.nonfinite_baseline += !std::isfinite(x); result.nonfinite_batch += !std::isfinite(y);
    if (!std::isfinite(x) || !std::isfinite(y)) continue;
    const auto error = std::abs(y - x); result.max_abs = (std::max)(result.max_abs, error);
    result.squared_error += error * error; result.reference_squared += x * x; result.batch_squared += y * y; result.dot += x * y;
    if (x != 0) result.max_relative_nonzero_reference = (std::max)(result.max_relative_nonzero_reference, error / std::abs(x));
    else result.zero_reference_mismatches += y != 0;
  }
  return result;
}

struct Observation final {
  std::filesystem::path output;
  std::vector<Metric> metrics;
  std::array<std::int32_t, 4> baseline_ids{}, batch_ids{};
  std::array<std::int32_t, 7> teacher_forced{};
  bool ids_equal = true, finite = true, old_unchanged = false, independent_frames = false, independent_states = false;
  bool one_batch_episode = false, continued_independently = false;
  void write(std::string_view status, std::string_view error = {}) const {
    std::ofstream stream(output / "observation.json"); require(static_cast<bool>(stream), "cannot write batch probe observation");
    stream << std::setprecision(17) << "{\"status\":" << json_string(status) << ",\"error\":" << json_string(error)
      << ",\"capacity\":256,\"resident_limit\":8,\"max_active\":2,\"batch_requests\":2,\"tokens_per_request\":1"
      << ",\"one_batch_episode\":" << (one_batch_episode ? "true" : "false")
      << ",\"ids_equal\":" << (ids_equal ? "true" : "false") << ",\"all_finite\":" << (finite ? "true" : "false")
      << ",\"old_snapshots_byte_unchanged\":" << (old_unchanged ? "true" : "false")
      << ",\"independent_ready_frames\":" << (independent_frames ? "true" : "false")
      << ",\"nonoverlapping_recurrent_outputs\":" << (independent_states ? "true" : "false")
      << ",\"independent_B1_continuation\":" << (continued_independently ? "true" : "false")
      << ",\"timing_comparison\":false,\"cancel_tested\":false,\"numerical_tolerance_policy\":null"
      << ",\"numerical_scope\":\"No full-model B1-versus-B2 error budget exists here. Metrics and raw38vectors per pair are reported; no byte-equivalence or bounded-error claim is inferred from finite values and equal greedyIDs.\"";
    const auto ids = [&](const char *name, const auto &values) {
      stream << ",\"" << name << "\":[";
      for (std::size_t i = 0; i < values.size(); ++i) stream << (i ? "," : "") << values[i];
      stream << ']';
    };
    ids("teacher_forced_ids", teacher_forced); ids("baseline_ids", baseline_ids); ids("batch_and_continuation_ids", batch_ids);
    stream << ",\"vectors\":[";
    for (std::size_t i = 0; i < metrics.size(); ++i) {
      const auto &value = metrics[i];
      stream << (i ? "," : "") << "{\"name\":" << json_string(value.name) << ",\"baseline\":" << json_string(value.baseline_path)
        << ",\"batch\":" << json_string(value.batch_path) << ",\"dtype\":" << json_string(value.dtype)
        << ",\"bytes\":" << value.bytes << ",\"elements\":" << value.elements
        << ",\"byte_equal\":" << (value.byte_equal ? "true" : "false") << ",\"nonfinite_baseline\":" << value.nonfinite_baseline
        << ",\"nonfinite_batch\":" << value.nonfinite_batch << ",\"max_abs\":" << value.max_abs
        << ",\"rmse\":" << std::sqrt(value.squared_error / static_cast<double>(value.elements))
        << ",\"max_relative_nonzero_reference\":" << value.max_relative_nonzero_reference
        << ",\"zero_reference_mismatches\":" << value.zero_reference_mismatches << ",\"cosine\":";
      if (value.reference_squared && value.batch_squared) stream << value.dot / std::sqrt(value.reference_squared * value.batch_squared);
      else stream << "null";
      stream << '}';
    }
    stream << "]}\n"; require(static_cast<bool>(stream), "cannot finish batch probe observation");
  }
};

struct SavedSnapshot final {
  q::cache::SnapshotRef head;
  std::vector<Bytes> kv, recurrent;
};

SavedSnapshot save(q::cache::SnapshotRef head) {
  require(static_cast<bool>(head), "missing committed snapshot"); SavedSnapshot result; result.head = std::move(head);
  for (std::size_t i = 0; i < result.head->keys.size(); ++i)
    for (const auto *frame : {&result.head->keys[i], &result.head->values[i]})
      for (const auto &guard : c::detail::PagedArenaAccess::pages(*frame)) result.kv.push_back(read_lease(guard));
  for (const auto &state : result.head->state)
    for (const auto *lease : {&state.history, &state.recurrent}) if (lease->valid()) result.recurrent.push_back(read_lease(*lease));
  require(result.recurrent.size() == 36, "snapshot is missing a conv/GDN resource"); return result;
}

bool unchanged(const SavedSnapshot &old) {
  const auto current = save(old.head); return current.kv == old.kv && current.recurrent == old.recurrent;
}

bool disjoint(const c::ReadLease &a, const c::ReadLease &b) {
  const auto x = q::take(a.view()), y = q::take(b.view());
  return x.resource() != y.resource() || x.native_handle() != y.native_handle() ||
      q::cache::add(x.offset(), x.size()) <= y.offset() || q::cache::add(y.offset(), y.size()) <= x.offset();
}

void check_frames(const q::cache::Snapshot &a, const q::cache::Snapshot &b) {
  require(a.length == 131 && b.length == 132, "B2 publication used a common position instead of individual histories");
  require(a.pages.back().page() != b.pages.back().page(), "batch requests share a dirty physical tail");
  for (const auto *head : {&a, &b}) {
    for (std::size_t bank = 0; bank < head->keys.size(); ++bank)
      for (const auto *frame : {&head->keys[bank], &head->values[bank]}) {
        const auto layout = frame->layout(); const auto host = layout.host();
        require(layout.facts().requests == 1 && layout.facts().query_rows == 1, "public Session frame still exposes the packed batch");
        require(host.page_indices.size() == head->pages.size(), "projected frame has another Session's footprint");
        for (std::size_t i = 0; i < head->pages.size(); ++i)
          require(host.page_indices[i] == static_cast<std::int32_t>(head->pages[i].page()), "projected frame mapping differs from its Session inventory");
      }
  }
}

void compare_case(Observation &observation, q::Model &model, std::string_view baseline, std::string_view batch) {
  const auto root = observation.output / "trace";
  const auto add = [&](std::string filename, std::size_t bytes, bool bf16) {
    auto value = compare(root / baseline / filename, root / batch / filename,
        std::string(baseline) + "_vs_" + std::string(batch) + "/" + filename, bytes, bf16);
    observation.finite = observation.finite && value.nonfinite_baseline == 0 && value.nonfinite_batch == 0;
    observation.metrics.push_back(std::move(value));
  };
  add("hidden.bf16", static_cast<std::size_t>(q::hidden) * sizeof(std::uint16_t), true);
  add("logits.f32", static_cast<std::size_t>(q::vocabulary) * sizeof(float), false);
  for (std::size_t layer = 0; layer < model.state_schema.size(); ++layer) if (layer % 4 != 3) {
    const auto prefix = "layer" + std::to_string(layer);
    add(prefix + ".conv.bf16", q::take(model.state_schema[layer].history.required_bytes()), true);
    add(prefix + ".gdn.f32", q::take(model.state_schema[layer].recurrent.required_bytes()), false);
  }
  observation.write("RUNNING");
}

void run(const std::filesystem::path &inputs, const std::filesystem::path &output) {
  std::filesystem::create_directories(output);
  require(!std::filesystem::exists(output / "observation.json") && !std::filesystem::exists(output / "trace"),
          "batch probe output already contains results");
  Observation observation; observation.output = output;
  try {
    const auto prompt = q::read_ids(inputs / "prompt.ids");
    require(prompt.size() == 128, "batch probe needs original P128 input");
    for (std::size_t i = 0; i < observation.teacher_forced.size(); ++i) observation.teacher_forced[i] = prompt[i];
    const auto &ids = observation.teacher_forced;
    constexpr std::size_t capacity = 256, residents = 8, requests = 2;
    const auto plan = q::cache::plan(capacity, residents, prompt.size(), q::recurrent_bytes(q::state_schema_for(capacity)), requests);
    q::Model model(inputs / "weights.tsv", capacity, plan);
    const std::array<std::size_t, 2> chunks{128, 1}; const std::array<std::size_t, 1> singleton{1};
    model.prepare_family(chunks, false, 1); model.prepare_family(singleton, false, requests);
    const std::array<std::size_t, 11> b1_calls{128,1,1,1,1,1,1,1,1,1,1};
    model.plan_execution(b1_calls, true, 1); model.plan_execution(singleton, true, requests);
    const auto trace = output / "trace";
    auto seed = model.create_session(chunks);
    (void)model.evaluate(*seed, prompt, "seed_prefill");
    (void)model.evaluate(*seed, std::span(&ids[0], 1), "seed129");
    require(seed->length() == 129, "shared seed is not P128 plus one T1");
    auto origin_a = model.create_session(singleton, seed->head);
    const std::array<std::size_t, 2> twice{1,1}; auto origin_b = model.create_session(twice, seed->head);
    (void)model.evaluate(*origin_a, std::span(&ids[1], 1), "origin_a130");
    (void)model.evaluate(*origin_b, std::span(&ids[2], 1), "origin_b130");
    (void)model.evaluate(*origin_b, std::span(&ids[3], 1), "origin_b131");
    const std::array old{save(seed->head), save(origin_a->head), save(origin_b->head)};
    auto baseline_a = model.create_session(twice, origin_a->head), baseline_b = model.create_session(twice, origin_b->head);
    auto batch_a = model.create_session(twice, origin_a->head), batch_b = model.create_session(twice, origin_b->head);
    observation.baseline_ids[0] = model.evaluate(*baseline_a, std::span(&ids[4], 1), "b1_a", trace);
    observation.baseline_ids[1] = model.evaluate(*baseline_b, std::span(&ids[5], 1), "b1_b", trace);
    std::array evaluations{q::EvaluationRequest{batch_a, std::span(&ids[4], 1)}, q::EvaluationRequest{batch_b, std::span(&ids[5], 1)}};
    model.prepare_evaluations(evaluations);
    require(model.active_step && model.active_step->members.size() == requests && batch_a->pending == model.active_step.get() && batch_b->pending == model.active_step.get(),
        "B2 prepare did not retain one original shared episode");
    require(model.active_step->phase && model.active_step->phase->family->requests == requests &&
        model.active_step->phase->attention_layout.facts().requests == requests && model.active_step->phase->attention_layout.facts().query_rows == requests,
        "prepared native Graph is not actual B2/T1");
    require(batch_a->head == origin_a->head && batch_b->head == origin_b->head, "prepare prematurely published a candidate head");
    observation.one_batch_episode = true;
    model.submit_evaluations();
    std::array outputs{q::EvaluationOutput{.session=batch_a,.name="b2_a",.trace=&trace}, q::EvaluationOutput{.session=batch_b,.name="b2_b",.trace=&trace}};
    std::array<std::int32_t, 2> batch_ids{-1,-1}; model.finish_evaluations(outputs, batch_ids);
    observation.batch_ids[0] = batch_ids[0]; observation.batch_ids[1] = batch_ids[1];
    require(!model.active_step && !batch_a->pending && !batch_b->pending, "finished batch did not return its original execution loan");
    check_frames(*batch_a->head, *batch_b->head); observation.independent_frames = true;
    for (std::size_t layer = 0; layer < model.state_schema.size(); ++layer) if (layer % 4 != 3) {
      require(disjoint(batch_a->head->state[layer].history, batch_b->head->state[layer].history) &&
          disjoint(batch_a->head->state[layer].recurrent, batch_b->head->state[layer].recurrent), "two Sessions share overlapping writable recurrent results");
    }
    observation.independent_states = true;
    compare_case(observation, model, "b1_a", "b2_a"); compare_case(observation, model, "b1_b", "b2_b");
    observation.baseline_ids[2] = model.evaluate(*baseline_a, std::span(&ids[6], 1), "b1_a_continue", trace);
    observation.batch_ids[2] = model.evaluate(*batch_a, std::span(&ids[6], 1), "b2_a_continue", trace);
    observation.baseline_ids[3] = model.evaluate(*baseline_b, std::span(&ids[6], 1), "b1_b_continue", trace);
    observation.batch_ids[3] = model.evaluate(*batch_b, std::span(&ids[6], 1), "b2_b_continue", trace);
    compare_case(observation, model, "b1_a_continue", "b2_a_continue"); compare_case(observation, model, "b1_b_continue", "b2_b_continue");
    observation.continued_independently = batch_a->length() == 132 && batch_b->length() == 133;
    observation.old_unchanged = std::all_of(old.begin(), old.end(), [](const auto &value) { return unchanged(value); });
    observation.ids_equal = observation.baseline_ids == observation.batch_ids;
    observation.write("COMPLETE");
    require(model.snapshot_versions.live <= residents, "retained committed snapshots exceed the explicit N8 budget");
    require(observation.old_unchanged && observation.continued_independently, "batch/continuation changed an old prefix or another Session's position");
    require(observation.ids_equal && observation.finite, "B1/B2 greedy IDs differ or raw model/state output is nonfinite; see unchanged raw vectors and metrics");
    require(observation.metrics.size() == 152, "did not compare hidden/logits and all36states for four same-partition pairs");
    observation.write("PASS structural isolation, finite outputs and greedy IDs; numeric metrics only");
    std::cout << "Qwen real B2/T1 finite/ID/isolation and independent B1 continuation PASS; numerical error metrics only, no approved cross-batch tolerance\n";
  } catch (const std::exception &error) {
    try { observation.write("FAIL", error.what()); } catch (...) {}
    throw;
  }
}
} // namespace

int main(int argc, char **argv) {
  try {
    std::filesystem::path inputs, output;
    for (int i = 1; i < argc; i += 2) {
      if (i + 1 == argc) throw std::runtime_error("batch probe option lacks its value");
      const std::string_view option(argv[i]);
      if (option == "--inputs") inputs = argv[i + 1];
      else if (option == "--output") output = argv[i + 1];
      else throw std::runtime_error("unknown batch probe option");
    }
    if (inputs.empty() || output.empty()) throw std::runtime_error("usage: hyle_qwen35_batch_probe --inputs DIR --output DIR");
    run(inputs, output); return 0;
  } catch (const std::exception &error) {
    std::cerr << "Qwen batch probe: " << error.what() << '\n'; return 1;
  }
}
