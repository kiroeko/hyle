"""Freeze/publish this finite Qwen batch; no build, inference or deletion."""
from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, json, xml.etree.ElementTree as ET, zipfile

Q = Path(__file__).resolve().parent
R = Q.parents[1]
STEM = 'qwen-multisequence-2026-10-22'
MODES = {'qwen': (3, 4), 'probe': (2, 2), 'batch-probe': (2, 2), 'prefix-tests': (1, 1)}
SOURCES = {
    'tools/qwen35_text/main.cc': '9fe44673c74d5453c08ded73649181e5f03600d5c89439fbba23d195ad969249',
    'tools/qwen35_text/session_state.h': '4cf1293d48cfc1d95e0f41fdbc694644fc1e75028b504845eefe7bfe3cb86843',
    'tools/qwen35_text/retirement_probe.cc': 'c2ded62293f564a9f6dabedce74481bf5eece9cd659b64e8bc6d4ce3d27349d4',
    'tools/qwen35_text/batch_probe.cc': 'c90fddc477e8aa7105846ae0040d67c6562a202f587def9ab3e2ae466a4ffd01',
    'tests/tools/qwen_prefix_cache_test.cc': '65afb0849d52743c74955276450f9bbd33d474356417a72c53a7a667d2bed283',
}
EXTRA = ['tools/qwen35_text/CMakeLists.txt', 'tools/qwen35_text/README.md',
         'docs/developer/current-work.md', 'docs/architecture/compute-design.md']
SMALL = {'.h', '.cc', '.cpp', '.inc', '.diff', '.patch', '.json', '.log', '.xml', '.py', '.ps1', '.tsv', '.md', '.txt'}
RAW = {'.bf16', '.f32'}
CACHE = {}


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    if path not in CACHE:
        with path.open('rb') as stream: digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        CACHE[path] = dict(path=str(path), bytes=path.stat().st_size, sha256=digest)
    return CACHE[path]


def verify(record): assert identity(record['path']) == record, 'Identity drift: ' + record['path']


def save_new(path, value):
    path = Path(path)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')


def terminal(folder):
    value = read(Q / folder / 'result.json')
    assert value['exit'] == 0 and not value.get('timeout'), folder
    return value


def frozen_copy(path, base):
    path = Path(path).resolve(); target = base / path.relative_to(R)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream: stream.write(path.read_bytes())
    return identity(target)


def raw_files(folder): return sorted(p for p in Path(folder).rglob('*') if p.is_file() and p.suffix.lower() in RAW)


def main():
    manifest = R / 'docs/evidence/correctness' / (STEM + '.json')
    archive = manifest.with_suffix('.zip')
    for path in (manifest, archive, Q/'published.json', Q/'current', Q/'diffs', Q/'finalrecords'):
        assert not path.exists(), 'Refuse to overwrite: ' + str(path)
    ready, compiled = {}, {}
    for mode, (link_attempt, compile_attempt) in MODES.items():
        ready_path = Q / f'{mode}-ready-attempt{link_attempt}.json'; value = read(ready_path)
        verify(value['source']); verify(value['link_plan']); verify(value['runtime_environment'])
        record_path = Q / f'compile{compile_attempt}' / mode / 'identity.json'; record = read(record_path)
        verify(record['source']); verify(record['object']); assert record['source'] == value['source']
        result_path = record_path.parent / 'compile.result.json'; assert read(result_path)['exit'] == 0
        plan = read(value['link_plan']['path'])
        assert any(x == identity(record_path) for x in plan['compiled_records'])
        assert plan['NVCC'] == plan['SDK_builds'] == 0
        for dependency in record['dependencies']:
            if Path(dependency['path']).name in ('main.cc', 'session_state.h', 'prefix_cache.h'): verify(dependency)
        ready[mode] = value
        compiled[mode] = dict(ready=identity(ready_path), identity=identity(record_path), compile_result=identity(result_path),
            source=record['source'], object=record['object'], model_dependencies=[x for x in record['dependencies'] if Path(x['path']).name in ('main.cc','session_state.h','prefix_cache.h')])
    for relative, digest in SOURCES.items(): assert identity(R/relative)['sha256'] == digest, relative
    b_manifest = R/'docs/evidence/correctness/paged-frame-reframe-2026-10-21.json'
    assert b_manifest.is_file(), 'Publish the typed frame module first'
    final_review_path = Q/'review/runtime-comparison-final.json'; final_review = read(final_review_path)
    assert final_review['ready'] == identity(Q/'qwen-ready-attempt3.json')
    assert final_review['decision_vectors'] == 142 and final_review['all_byte_equal']
    assert final_review['finite_proof']['nonfinite_elements'] == 0
    r1, raw_aliases, raw_final = {}, [], set()
    for name, count in [('single',18), ('multi',72), ('main',22), ('pressure',30)]:
        folder = Q/f'{name}-run3'; old = Q/f'{name}-run2'; reference = R/f'.scratch/shared-execution-20261021/{name}-run2'
        process = terminal(folder.name); assert process['image'] == ready['qwen']['image']
        files = raw_files(folder); assert len(files) == count
        vectors = []
        for path in files:
            relative = path.relative_to(folder); current = identity(path)
            previous, baseline = identity(old/relative), identity(reference/relative)
            assert current['sha256'] == previous['sha256'] == baseline['sha256'] and current['bytes'] == previous['bytes'] == baseline['bytes']
            raw_final.add(path.resolve())
            vectors.append(dict(relative=relative.as_posix(), current=current, baseline=baseline))
            raw_aliases.append(dict(omitted=previous, archive_target=path.relative_to(R).as_posix(), target=current))
        r1[name] = dict(result=identity(folder/'result.json'), vectors=count, all_byte_equal=True, raw=vectors)
    probe_process = terminal('probe-run2'); assert probe_process['image'] == ready['probe']['image']
    probe = read(Q/'probe-run2/observation.json'); assert probe['status'] == 'PASS'
    batch_folder = Q/'batch-probe-run2'; batch_process = terminal(batch_folder.name)
    assert batch_process['image'] == ready['batch-probe']['image']
    batch_path = batch_folder/'data/observation.json'; batch = read(batch_path); metrics = batch['vectors']
    assert len(metrics) == 152 and batch['baseline_ids'] == batch['batch_and_continuation_ids']
    for flag in ('one_batch_episode','ids_equal','all_finite','old_snapshots_byte_unchanged','independent_ready_frames',
                 'nonoverlapping_recurrent_outputs','independent_B1_continuation','cancel_tested','dropped_live_completion',
                 'blocked_candidates_pending_versions_backing_retained','cancelled_heads_byte_unchanged','R2_retry_same_carrier_slot'):
        assert batch[flag] is True, flag
    assert (batch['blocked_retirement_checks'],batch['cancel_versions_before'],batch['cancel_versions_blocked'],batch['cancel_versions_retired']) == (1,2,4,2)
    assert batch['managed_backing_bytes'] == 220938288 and batch['numerical_tolerance_policy'] is None and batch['timing_comparison'] is False
    equal = 0; metric_files = set()
    for value in metrics:
        a, b = identity(value['baseline']), identity(value['batch'])
        assert a['bytes'] == b['bytes'] == value['bytes'] and value['nonfinite_baseline'] == value['nonfinite_batch'] == 0
        same = a['sha256'] == b['sha256']; assert same == value['byte_equal']; equal += same
        metric_files.update((Path(a['path']),Path(b['path'])))
    actual_batch_files = {p.resolve() for p in raw_files(batch_folder)}
    assert len(actual_batch_files) == 304 and metric_files == actual_batch_files
    raw_final.update(actual_batch_files)
    for old_path in raw_files(Q/'batch-probe-run1'):
        target = batch_folder / old_path.relative_to(Q/'batch-probe-run1')
        a, b = identity(old_path), identity(target)
        if a['bytes'] == b['bytes'] and a['sha256'] == b['sha256']:
            raw_aliases.append(dict(omitted=a, archive_target=target.relative_to(R).as_posix(), target=b))
        else: raw_final.add(old_path.resolve()) # Preserve any real old difference rather than silently dropping it.
    prefix_process = terminal('prefix-tests-run1'); assert prefix_process['image'] == ready['prefix-tests']['image']
    xml = ET.parse(Q/'prefix-tests-run1/gtest.xml').getroot()
    assert xml.attrib['failures'] == xml.attrib['errors'] == '0'
    assert all(x.attrib['result']=='completed' for x in xml.findall('.//testcase'))

    for name in ('current','diffs','finalrecords'): (Q/name).mkdir()
    snapshots, diffs = [], []
    for relative in (*SOURCES, *EXTRA):
        path = R/relative; snapshots.append(dict(current=identity(path), snapshot=frozen_copy(path,Q/'current')))
        before = Q/'before'/relative
        if before.is_file() or relative == 'tools/qwen35_text/batch_probe.cc':
            target = Q/'diffs'/(relative.replace('/','--')+'.diff')
            text = ''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True) if before.is_file() else [],path.read_text(encoding='utf-8').splitlines(True),
                fromfile=('before/'+relative if before.is_file() else '/dev/null'),tofile=relative))
            with target.open('x',encoding='utf-8') as stream: stream.write(text)
            diffs.append(dict(diff=identity(target), new_file=not before.is_file()))
    dependency_snapshot = frozen_copy(R/'tools/qwen35_text/prefix_cache.h',Q/'current')
    history = [dict(record=identity(p),exit=read(p)['exit']) for p in sorted(Q.glob('compile*/*/compile.result.json'))]
    facts = dict(snapshots=snapshots,diffs=diffs,unchanged_prefix_dependency=dependency_snapshot,compiled=compiled,R1=r1,
        final_R1_independent_review=identity(final_review_path),batch_observation=identity(batch_path),batch_pair_count=152,
        batch_byte_equal_pairs=equal,batch_non_byte_equal_pairs=152-equal,batch_native_cancel={k:v for k,v in batch.items() if k!='vectors'},
        raw_aliases=raw_aliases,host_compile_history=history,prior_typed_frame_manifest=identity(b_manifest))
    record_path = Q/'finalrecords/final.json'; save_new(record_path,facts)
    omitted = {Path(x['omitted']['path']).resolve() for x in raw_aliases}
    paths = {}
    for path in Q.rglob('*'):
        if not path.is_file() or any(part in ('tmp','__pycache__') for part in path.relative_to(Q).parts) or path.name=='published.json': continue
        if path.suffix.lower() in SMALL or (path.resolve() in raw_final and path.resolve() not in omitted):
            paths[path.relative_to(R).as_posix()] = path
    archived_paths = {p.resolve() for p in paths.values()}
    assert raw_final <= archived_paths
    inventory = [dict(archive_path=name,**identity(path)) for name,path in sorted(paths.items())]
    # All final raw bytes are retained; old equal raw files are precisely
    # addressed by final.json aliases, while original metadata/logs stay intact.
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
        for name,path in sorted(paths.items()): output.write(path,name)
        output.writestr('archive-inventory.json',json.dumps(dict(files=inventory,omitted_equal_raw=raw_aliases),indent=2))
    with zipfile.ZipFile(archive) as check: assert check.testzip() is None
    report = dict(date='2026-10-22',created_utc=datetime.now(timezone.utc).isoformat(),
        status='Unified single/batched Model execution and finite actual B2/T1 correctness/lifetime consumer implemented; CLI batching and performance remain pending.',
        archive=identity(archive),archive_files=len(inventory),final_records=identity(record_path),compiled=compiled,current_image=ready['qwen']['image'],
        state_header=identity(R/'tools/qwen35_text/session_state.h'),
        docs=[identity(R/p) for p in EXTRA[1:]],reviews=[identity(p) for p in sorted((Q/'review').glob('*.json'))],
        prior_typed_frame_manifest=identity(b_manifest),R1=dict(decision_vectors=142,all_byte_equal=True,reference='Same partitions, original S run2 and Q run2 raw bytes.',
            independent_review=identity(final_review_path),finite='Final raw matches the independently finite-checked Q run2 vectors; no second numeric decode in publisher.'),
        B2=dict(pair_metrics=152,byte_equal_pairs=equal,non_byte_equal_pairs=152-equal,observation=identity(batch_path),result=identity(batch_folder/'result.json'),
            greedy_ids=batch['batch_and_continuation_ids'],retry_ids=batch['retired_R2_retry_ids'],all_finite=True,numerical_tolerance_policy=None,
            hidden_max_abs=max(x['max_abs'] for x in metrics if x['name'].endswith('/hidden.bf16')),
            logits_max_abs=max(x['max_abs'] for x in metrics if x['name'].endswith('/logits.f32')),
            native_cancel='One member stops the shared B2 episode, drops its live Completion, retains both candidates/heads/backing while Queue blocked, actual retirement4→2versions, same R2 carrier slot retries.',
            version_counts=[2,4,2],managed_backing_bytes=batch['managed_backing_bytes'],no_native_preemption=True),
        original_retirement=dict(result=identity(Q/'probe-run2/result.json'),observation=identity(Q/'probe-run2/observation.json')),
        prefix_host_tests=dict(result=identity(Q/'prefix-tests-run1/result.json'),xml=identity(Q/'prefix-tests-run1/gtest.xml'),tests=int(xml.attrib['tests'])),
        history='All original commands, failed compilations, parser false alarms, raw logs and older reviews are retained unchanged; old run2 R1 and B2run1 claims are not relabeled as final.',
        raw_storage=dict(final_R1_vectors=142,final_B2_vectors=304,old_equal_raw_aliases=len(raw_aliases),reference_map=identity(record_path)),
        reproduction='Use archived source/before/diffs/compile sourceDependencies and exact command/link/runtime records with the fixed retained compiler/SDK/object/native-DLL caches. SDKs, objects, models and executables are not duplicated.',
        cleanup='prepare_cleanup.py only prepares exact image/map/import/export leaf identities; it never deletes or writes root test.ps1.',
        limits=[f'B2 compares actual hidden/logits/36 state vectors, but {152-equal} pairs differ bitwise. Finite values/equal greedy IDs do not approve a full-model cross-batch numeric tolerance or quality policy.',
            'The non-timing native B2 probe is one finite CUDA B2/T1 case plus one real blocked cancel/drop/retire/retry case, not concurrent throughput, all models/quantization, CLI scheduling or other native backend coverage.',
            'R1 byte equality applies to142decision vectors, not every hidden state byte or a new performance result.',
            'No build/inference/device query or deletion is performed by publication. Existing outputs and revision records are never overwritten.'])
    save_new(manifest,report); save_new(Q/'published.json',dict(manifest=identity(manifest),archive=identity(archive),final_records=identity(record_path)))
    print(json.dumps(read(Q/'published.json'),indent=2))


if __name__=='__main__': main()
