from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/qwen35_text/main.cc'
s=p.read_text(encoding='utf-8')
start=s.index('// One original Graph episode owns')
end=s.index('// Each original device allocation',start)
old=s[start:end]
old=old.replace('struct StepState final {\n  cache::SnapshotRef base;\n  std::shared_ptr<cache::Snapshot> next;', '''class Session;
struct StepMember final {
  std::shared_ptr<Session> session;
  cache::SnapshotRef base;
  std::shared_ptr<cache::Snapshot> next;
  std::array<c::PagedPageAppender, 12> next_tails;
  c::BatchLayoutVersion layout;
};
struct StepState final {
  // Model owns the episode; these strong pins outlive all accepted native work.
  // Session's pending link borrows this owner and never creates a cycle.
  std::vector<StepMember> members;''')
old=old.replace('std::array<c::PagedPageAppender, 12> tails;', 'std::array<std::vector<c::PagedPageAppender>, 12> tails;')
old=old.replace('bool prepared = false, submitted = false;', 'bool prepared = false, submitted = false, cancelled = false;')
old=old.replace('for (auto &tail : tails) {', 'for (auto &bank : tails) for (auto &tail : bank) {')
old=old.replace('next.reset(); base.reset(); run = nullptr; phase = nullptr;', 'for (auto &member : members) { member.next.reset(); member.base.reset(); }\n    run = nullptr; phase = nullptr;')
s=s[:start]+old+s[end:]
start=s.index('class Session final {')
end=s.index('\nclass Model final {',start)
s=s[:start]+'''class Session final : public std::enable_shared_from_this<Session> {
  friend class Model;
  Model *model_;
  explicit Session(Model &model) noexcept : model_(&model) {}
public:
  cache::SnapshotRef head;
  std::array<c::PagedPageAppender, 12> tails;
  const cache::Snapshot *tail_head = nullptr;
  StepState *pending = nullptr; // Borrowed from Model; episode pins this Session.
  bool failed = false, stopping = false;
  hyle::Status retirement_status;
  std::size_t length() const noexcept { return head ? head->length : 0; }
  Session(const Session &) = delete;
  Session &operator=(const Session &) = delete;
  // Stopping any member aborts the whole shared batch. No head is published.
  hyle::Status stop() noexcept;
  hyle::Result<bool> try_retire() noexcept;
  hyle::Status drain() noexcept;
  ~Session();
};
struct EvaluationRequest final {
  std::shared_ptr<Session> session;
  std::span<const std::int32_t> ids;
};
struct EvaluationOutput final {
  std::shared_ptr<Session> session;
  std::string_view name;
  const std::filesystem::path *trace = nullptr;
  bool trace_states = true;
  double *complete_seconds = nullptr;
  Clock::time_point *host_endpoint = nullptr;
  StepObservation *observation = nullptr;
  PreparationObservation *preparation = nullptr;
  std::string_view probe_subdirectory;
};
''' + s[end:]
s=s.replace('bool serial_candidate_active = false;', '''bool carrier_borrowed = false;
  std::unique_ptr<StepState> active_step;
  std::size_t execution_parity = 0;''')
s=s.replace('serial_candidate_active','carrier_borrowed')
s=s.replace('std::unique_ptr<Session> create_session', 'std::shared_ptr<Session> create_session')
s=s.replace('auto session = std::unique_ptr<Session>(new Session(*this));','auto session = std::shared_ptr<Session>(new Session(*this));')
s=s.replace('std::unique_ptr<qwen35::Session> session;','std::shared_ptr<qwen35::Session> session;')
p.write_text(s,encoding='utf-8',newline='\n')
