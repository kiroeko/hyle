"""Incremental host-only consumer build; reuse SDKs, native objects and DLLs."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent;R=Q.parents[1]
S=R/'.scratch/shared-execution-20261021';B=R/'.scratch/multisequence-batch-20261021';E=R/'.scratch/paged-exclusive-20261021'
spec=importlib.util.spec_from_file_location('retained_build',E/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
def base(mode):
    if mode=='prefix-tests':return B/'arena-tests-ready-attempt2.json',B/'compile2/arena-tests/arena-tests.obj'
    tag='qwen'if mode=='qwen'else'probe'
    return S/f'{tag}-ready-attempt2.json',S/f'compile2/{"main"if mode=="qwen"else"probe"}/{"main"if mode=="qwen"else"probe"}.obj'
def compile_owner(mode,attempt):
    prior,old=base(mode);plan=c.read(c.read(prior)['link_plan']['path'])
    records=[(Path(x['path']),c.read(x['path']))for x in plan['compiled_records']]
    matched=[(rp,rec)for rp,rec in records if c.key(rec['object']['path'])==c.key(old)]
    assert len(matched)==1
    source={'qwen':'main.cc','probe':'retirement_probe.cc','batch-probe':'batch_probe.cc','prefix-tests':'../../tests/tools/qwen_prefix_cache_test.cc'}[mode]
    source=(R/'tools/qwen35_text'/source).resolve()
    h.S=Q;h.RECIPES[mode]=(source.relative_to(R).as_posix(),matched[0][0])
    return h.compile_owner(mode,attempt)
def link(mode,attempt,owner_attempt):
    prior_path,old_owner=base(mode);prior=c.read(prior_path);plan=c.read(prior['link_plan']['path'])
    record_path=Q/f'compile{owner_attempt}/{mode}/identity.json';record=c.read(record_path)
    assert all(h.same(x)for x in [record['source'],record['object'],*record['dependencies']])
    arena_path=B/'compile2/arena/identity.json';arena=c.read(arena_path)
    assert all(h.same(x)for x in [arena['source'],arena['object'],*arena['dependencies']])
    replacements={c.key(old_owner):record['object']}
    if mode!='prefix-tests':replacements[c.key(E/'compile1/arena/arena.obj')]=arena['object']
    assert all(sum(c.key(row['path'])==key for row in plan['inputs'])==1 for key in replacements)
    assert all(h.same(x)for x in plan['inputs'])
    out=Q/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/(mode+'.exe')
    inputs=[replacements.get(c.key(row['path']),row)for row in plan['inputs']]
    command=[replacements.get(c.key(x),{}).get('path',x)for x in plan['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(prior['link_plan']['path']),compiled_records=[b.identity(record_path),b.identity(arena_path)],replaced_inputs=[dict(before=x,after=replacements[c.key(x['path'])])for x in plan['inputs']if c.key(x['path'])in replacements],NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):os.link(dll,out/dll.name)
    runtime=c.read(prior['runtime_environment']['path']);runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime)
    c.save(Q/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=record['source'],link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),NVCC=0,SDK_builds=0))
    print('READY',mode,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('qwen','probe','batch-probe','prefix-tests'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--owner-attempt',type=int,default=1);p.add_argument('--link',action='store_true');a=p.parse_args()
    if a.link:link(a.mode,a.attempt,a.owner_attempt)
    else:compile_owner(a.mode,a.attempt)
