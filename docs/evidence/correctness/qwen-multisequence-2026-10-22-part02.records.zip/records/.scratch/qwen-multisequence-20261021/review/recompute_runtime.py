"""Pure host reread of completed Q evidence; never launches an inference process."""
from pathlib import Path
import hashlib
import json
import math

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
Q = ROOT / '.scratch/qwen-multisequence-20261021'
S = ROOT / '.scratch/shared-execution-20261021'
OUT = Q / 'review'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
                if k != 'seconds' and not k.endswith('_seconds')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def normalized_command(command):
    result = list(command)
    result[0] = 'EXE'
    if '--trace' in result:
        result[result.index('--trace') + 1] = 'TRACE'
    return result


def decode(data, dtype):
    if dtype == 'BF16':
        return (np.frombuffer(data, dtype='<u2').astype(np.uint32) << 16).view(np.float32).astype(np.float64)
    assert dtype == 'F32'
    return np.frombuffer(data, dtype='<f4').astype(np.float64)


def digest_manifest(manifest):
    return hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


ready = read(Q / 'qwen-ready-attempt2.json')
baseline_ready = read(S / 'qwen-ready-attempt2.json')
compiled = read(Q / 'compile3/qwen/identity.json')
assert ready['source'] == compiled['source']
assert compiled['source']['sha256'] == 'bb3965fd3d2e520eac4ea8820c9c683f3c235ff457e5247604e5af4b4acbd123'
assert identity(Q / 'compile3/qwen/source/tools/qwen35_text/main.cc')['sha256'] == compiled['source']['sha256']
assert read(Q / 'compile3/qwen/compile.result.json')['exit'] == 0
assert len(read(ready['link_plan']['path'])['inputs']) == 195

cases = {}
total = dict(decision_vectors=0, bf16_elements=0, f32_elements=0, nonfinite_elements=0)
for name, expected in [('single-run2', 18), ('multi-run2', 72), ('main-run2', 22), ('pressure-run2', 30)]:
    current, baseline = Q / name, S / name
    result, old_result = read(current / 'result.json'), read(baseline / 'result.json')
    assert result['exit'] == old_result['exit'] == 0
    assert result['image'] == ready['image'] and old_result['image'] == baseline_ready['image']
    assert normalized_command(result['command']) == normalized_command(old_result['command'])
    observation, original = read(current / 'stdout.log'), read(baseline / 'stdout.log')
    assert observation == read(current / 'observation.json')
    assert original == read(baseline / 'observation.json')
    assert stable(observation) == stable(original)
    paths = lambda root: {p.relative_to(root / 'trace').as_posix(): p for p in (root / 'trace').rglob('*')
                          if p.name in ('hidden.bf16', 'logits.f32')}
    actual, prior = paths(current), paths(baseline)
    assert actual.keys() == prior.keys() and len(actual) == expected
    manifest = []
    for relative in sorted(actual):
        a, b = actual[relative].read_bytes(), prior[relative].read_bytes()
        assert a == b, (name, relative)
        dtype = 'BF16' if relative.endswith('.bf16') else 'F32'
        values = decode(a, dtype)
        nonfinite = int(np.count_nonzero(~np.isfinite(values)))
        assert nonfinite == 0
        total['decision_vectors'] += 1
        total['bf16_elements' if dtype == 'BF16' else 'f32_elements'] += len(values)
        total['nonfinite_elements'] += nonfinite
        manifest.append(dict(relative=relative, bytes=len(a), sha256=hashlib.sha256(a).hexdigest()))
    fullhits = []
    for path in (current / 'trace').rglob('cache-hit.json'):
        relative = path.relative_to(current / 'trace')
        metadata = read(path)
        assert metadata == read(baseline / 'trace' / relative)
        assert metadata['graph_calls'] == 0 and metadata['tensor_payload_available'] is False
        assert not (path.parent / 'hidden.bf16').exists() and not (path.parent / 'logits.f32').exists()
        fullhits.append(dict(relative=relative.as_posix(), contents=metadata))
    sessions = observation.get('sessions', [observation])
    cases[name] = dict(
        result=identity(current / 'result.json'), baseline_result=identity(baseline / 'result.json'),
        stdout=identity(current / 'stdout.log'), baseline_stdout=identity(baseline / 'stdout.log'),
        decision_vectors=expected, all_raw_bytes_equal=True, nonfinite_elements=0,
        equal_raw_manifest_sha256=digest_manifest(manifest),
        same_command_except_image_and_trace=True, all_non_timing_stdout_fields_equal=True,
        fields_excluded=['seconds', '*_seconds'],
        statistics={k: v for k, v in stable(observation).items() if k not in ['sessions', 'phases', 'generated_ids', 'decode_input_ids']},
        sessions=[dict(session_id=item.get('session_id'), visible_tokens=item['visible_tokens'],
                       generated_ids=item['generated_ids'], restored_calls=item['restored_calls'],
                       restored_tokens=item['restored_tokens'],
                       phase_columns=['name', 'input_tokens', 'context_before', 'context_after', 'calls'],
                       phases=[[phase[k] for k in ['name', 'input_tokens', 'context_before', 'context_after', 'calls']] for phase in item['phases']]) for item in sessions],
        full_hits=fullhits)
assert total['decision_vectors'] == 142

probe = read(Q / 'probe-run1/stdout.log')
assert probe == read(Q / 'probe-run1/observation.json')
probe_result, probe_ready = read(Q / 'probe-run1/result.json'), read(Q / 'probe-ready-attempt1.json')
assert probe_result['exit'] == 0 and probe_result['image'] == probe_ready['image']
probe_compiled = read(Q / 'compile1/probe/identity.json')
assert probe_compiled['source'] == probe_ready['source']
assert ready['source'] in probe_compiled['dependencies']
assert probe_compiled['object'] in read(probe_ready['link_plan']['path'])['inputs']
assert probe['status'] == 'PASS'
for key in ['dropped_live_public_completion', 'same_page_exclusive_suffix',
            'old_kv_guards_and_bytes_unchanged', 'idle_stop_preserved_other_execution_loan',
            'retired_aborted_slot_rebuilt_in_same_model_bundle', 'retired_model_episode_detached_all_pending_links',
            'post_commit_trace_error_preserved_head_and_returned_loan',
            'different_session_continued_after_report_error']:
    assert probe[key] is True
assert probe['busy_prepare_rejections'] == 3
assert probe['old_recurrent_resources_byte_unchanged'] == 36
assert probe['head_alias_sessions_added_distinct_versions'] == 0
assert probe['final_tokens'] == 131 and probe['old_prefix_tokens'] == 129
assert probe['native_error_injected'] is False and probe['cancel_means_native_preemption'] is False
stderr = (Q / 'probe-run1/stderr.log').read_text(encoding='utf-8-sig')
for stage in ['native_pending', 'stopped_native_pending', 'dropped_completion_native_pending']:
    assert stderr.count('shared_execution_prepare_rejected stage=' + stage + ' ') == 1
assert stderr.count('shared_execution_post_commit_trace_rejected reason=') == 1
assert 'weights.tsv' in stderr and 'retirement_after_report_error tokens=1 visible=131 ' in stderr

batch_path = Q / 'batch-probe-run1/data/observation.json'
batch = read(batch_path)
batch_result, batch_ready = read(Q / 'batch-probe-run1/result.json'), read(Q / 'batch-probe-ready-attempt1.json')
assert batch_result['exit'] == 0 and batch_result['image'] == batch_ready['image']
batch_compiled = read(Q / 'compile1/batch-probe/identity.json')
assert batch_compiled['source'] == batch_ready['source']
assert ready['source'] in batch_compiled['dependencies']
assert batch_compiled['object'] in read(batch_ready['link_plan']['path'])['inputs']
assert batch['error'] == '' and len(batch['vectors']) == 152
assert batch['numerical_tolerance_policy'] is None
for key in ['one_batch_episode', 'ids_equal', 'all_finite', 'old_snapshots_byte_unchanged',
            'independent_ready_frames', 'nonoverlapping_recurrent_outputs', 'independent_B1_continuation']:
    assert batch[key] is True
assert not batch['timing_comparison'] and not batch['cancel_tested']
assert batch['baseline_ids'] == batch['batch_and_continuation_ids']

pair_summaries, batch_manifest = {}, []
metric_match = dict(metrics=0, scalar_values=0, nonfinite_baseline=0, nonfinite_batch=0)
for original in batch['vectors']:
    name = original['name']
    pair, tensor = name.split('/', 1)
    a_bytes, b_bytes = Path(original['baseline']).read_bytes(), Path(original['batch']).read_bytes()
    assert len(a_bytes) == len(b_bytes) == original['bytes']
    x, y = decode(a_bytes, original['dtype']), decode(b_bytes, original['dtype'])
    assert len(x) == original['elements']
    finite_x, finite_y = np.isfinite(x), np.isfinite(y)
    nonfinite_x, nonfinite_y = int((~finite_x).sum()), int((~finite_y).sum())
    assert nonfinite_x == nonfinite_y == 0
    d = y - x
    ss = float(np.sum(d * d, dtype=np.float64))
    reference_ss = float(np.sum(x * x, dtype=np.float64))
    batch_ss = float(np.sum(y * y, dtype=np.float64))
    reference_nonzero = x != 0
    metric = dict(bytes=len(a_bytes), elements=len(x), byte_equal=a_bytes == b_bytes,
                  nonfinite_baseline=nonfinite_x, nonfinite_batch=nonfinite_y,
                  max_abs=float(np.max(np.abs(d))), rmse=math.sqrt(ss / len(x)),
                  max_relative_nonzero_reference=float(np.max(np.abs(d[reference_nonzero] / x[reference_nonzero]))),
                  zero_reference_mismatches=int(np.count_nonzero((~reference_nonzero) & (y != 0))),
                  cosine=float(np.sum(x * y, dtype=np.float64)) / math.sqrt(reference_ss * batch_ss))
    for k, v in metric.items():
        if isinstance(v, float):
            # Agreement of two host reduction implementations, not a model-output tolerance.
            assert math.isclose(v, original[k], rel_tol=1e-10, abs_tol=1e-13), (name, k, v, original[k])
        else:
            assert v == original[k], (name, k, v, original[k])
    metric['relative_l2'] = math.sqrt(ss / reference_ss)
    unequal = np.flatnonzero(x != y)
    if len(unequal):
        first = int(unequal[0])
        metric['first_numeric_difference'] = dict(element=first, baseline=float(x[first]), batch=float(y[first]))
    item = pair_summaries.setdefault(pair, dict(vector_metrics=0, byte_equal_metrics=0,
                                               nonfinite_elements=0, summary={}))
    item['vector_metrics'] += 1
    item['byte_equal_metrics'] += int(metric['byte_equal'])
    item['nonfinite_elements'] += nonfinite_x + nonfinite_y
    if tensor in ['hidden.bf16', 'logits.f32', 'layer0.conv.bf16', 'layer0.gdn.f32']:
        item['summary'][tensor] = metric
    if tensor.startswith('layer') and len(unequal) and 'first_different_recurrent_tensor' not in item:
        item['first_different_recurrent_tensor'] = tensor
    if tensor == 'logits.f32':
        item['baseline_argmax_id'], item['batch_argmax_id'] = int(np.argmax(x)), int(np.argmax(y))
    metric_match['metrics'] += 1
    metric_match['scalar_values'] += len(x)
    metric_match['nonfinite_baseline'] += nonfinite_x
    metric_match['nonfinite_batch'] += nonfinite_y
    batch_manifest.append(dict(name=name, baseline_sha256=hashlib.sha256(a_bytes).hexdigest(),
                               batch_sha256=hashlib.sha256(b_bytes).hexdigest(), bytes=len(a_bytes)))

pair_order = ['b1_a_vs_b2_a', 'b1_b_vs_b2_b', 'b1_a_continue_vs_b2_a_continue', 'b1_b_continue_vs_b2_b_continue']
assert [pair_summaries[p]['baseline_argmax_id'] for p in pair_order] == batch['baseline_ids']
assert [pair_summaries[p]['batch_argmax_id'] for p in pair_order] == batch['batch_and_continuation_ids']
assert all(p['vector_metrics'] == 38 for p in pair_summaries.values())

report = dict(
    status='R1 same-partition regression PASS: all142 decision vectors byte-identical. B2 metrics remain unbounded observations.',
    checker=identity(__file__), baseline_stage=str(S), current_ready=identity(Q / 'qwen-ready-attempt2.json'),
    current_source=ready['source'], current_image=ready['image'], baseline_image=baseline_ready['image'],
    compile_identity=identity(Q / 'compile3/qwen/identity.json'),
    closure=dict(recorded_inputs=195, policy='Recorded ready/receipt identities and compiled frozen main source checked; no large executable, weight, SDK or old whole-closure rehash.'),
    canonical_vectors=90, prefix_pressure_vectors=52, total_r1_vectors=142,
    all_r1_byte_equal=True, counts=total, cases=cases,
    probe=dict(result=identity(Q / 'probe-run1/result.json'), ready=identity(Q / 'probe-ready-attempt1.json'),
               compiled_source=probe_ready['source'], image=probe_ready['image'],
               compile_identity=identity(Q / 'compile1/probe/identity.json'), compiled_main_dependency=ready['source'],
               stdout=identity(Q / 'probe-run1/stdout.log'), stderr=identity(Q / 'probe-run1/stderr.log'),
               observation=probe, three_native_pending_rejections_and_postcommit_exception_verified_in_stderr=True,
               scope='Existing native-gate assertions plus unified Model episode detachment; no injected native error or preemption claim.'),
    batch_probe=dict(result=identity(Q / 'batch-probe-run1/result.json'), ready=identity(Q / 'batch-probe-ready-attempt1.json'),
                     compiled_source=batch_ready['source'], image=batch_ready['image'], observation=identity(batch_path),
                     compile_identity=identity(Q / 'compile1/batch-probe/identity.json'), compiled_main_dependency=ready['source'],
                     scope={k: v for k, v in batch.items() if k != 'vectors'},
                     independently_recomputed=metric_match, all152_recorded_metrics_match_host_reread=True,
                     host_reduction_agreement='rel1e-10/abs1e-13 solely checks numeric metric serialization/reduction; not a B1/B2 model-error acceptance criterion.',
                     raw_pair_manifest_sha256=digest_manifest(batch_manifest), pairs=pair_summaries,
                     conclusion='All four comparisons are finite and have equal independently recomputed greedyIDs, but hidden/logits and layer0 recurrent outputs differ. No B1/B2 error budget or independent quality oracle was applied; these152 metrics are excluded from the142 R1 byte-equality count.'),
    limits=['Pure host analysis of completed processes; no build, GPU, model execution or source edit.',
            'R1 observations match every non-timing JSON field, including phase/context/dispatch, IDs, Graph work, restore/prefix/budget statistics. Preparation/capture diagnostic strategy is not a mathematical oracle.',
            'R1 hidden/logits byte equality is a same-partition regression, not all model/state bits, concurrency, multi-sequence throughput or quality proof.',
            'B2 snapshot/frame/isolation flags are assertions executed by the probe. Raw output metrics and greedyIDs were independently reread here; no independent raw snapshot dump exists for rederiving those flags.',
            'This report makes no performance or physical GPU-memory-peak claim.'])
destination = OUT / 'runtime-comparison.json'
destination.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(destination), counts=total,
                     batch_metrics=metric_match,
                     summaries={p: {k: v for k, v in d.items() if k != 'summary'} for p, d in pair_summaries.items()}), indent=2))
