"""Host-only final Q R1 regression check; preserves the earlier run2/B2 report."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
Q = ROOT / '.scratch/qwen-multisequence-20261021'
S = ROOT / '.scratch/shared-execution-20261021'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    data = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items() if k != 'seconds' and not k.endswith('_seconds')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def norm_command(command):
    result = list(command)
    result[0] = 'EXE'
    result[result.index('--trace') + 1] = 'TRACE'
    return result


prior_path = Q / 'review/runtime-comparison.json'
assert identity(prior_path)['sha256'] == '3035b66c8471dc2ce00d1be61260e21eb039bb704f5522653d056a91cad3f458'
prior_review = read(prior_path)
assert prior_review['all_r1_byte_equal'] and prior_review['counts']['nonfinite_elements'] == 0
ready = read(Q / 'qwen-ready-attempt3.json')
baseline_ready = read(S / 'qwen-ready-attempt2.json')
compiled = read(Q / 'compile4/qwen/identity.json')
assert ready['source'] == compiled['source']
assert ready['source']['sha256'] == '9fe44673c74d5453c08ded73649181e5f03600d5c89439fbba23d195ad969249'
assert identity(Q / 'compile4/qwen/source/tools/qwen35_text/main.cc')['sha256'] == ready['source']['sha256']
assert read(Q / 'compile4/qwen/compile.result.json')['exit'] == 0
plan = read(ready['link_plan']['path'])
assert len(plan['inputs']) == 195 and compiled['object'] in plan['inputs']

cases = {}
count = 0
for current_name, baseline_name, expected in [('single-run3', 'single-run2', 18), ('multi-run3', 'multi-run2', 72),
                                               ('main-run3', 'main-run2', 22), ('pressure-run3', 'pressure-run2', 30)]:
    current, reference, finite_reference = Q / current_name, S / baseline_name, Q / baseline_name
    result, old_result = read(current / 'result.json'), read(reference / 'result.json')
    assert result['exit'] == old_result['exit'] == 0
    assert result['image'] == ready['image'] and old_result['image'] == baseline_ready['image']
    assert norm_command(result['command']) == norm_command(old_result['command'])
    observation = read(current / 'stdout.log')
    assert observation == read(current / 'observation.json')
    assert stable(observation) == stable(read(reference / 'stdout.log')) == stable(read(finite_reference / 'stdout.log'))
    def vectors(directory):
        return {p.relative_to(directory / 'trace').as_posix(): p for p in (directory / 'trace').rglob('*')
                if p.name in ('hidden.bf16', 'logits.f32')}
    a, b, c = vectors(current), vectors(reference), vectors(finite_reference)
    assert a.keys() == b.keys() == c.keys() and len(a) == expected
    manifest = []
    for relative in sorted(a):
        data = a[relative].read_bytes()
        assert data == b[relative].read_bytes() == c[relative].read_bytes(), (current_name, relative)
        manifest.append([relative, len(data), hashlib.sha256(data).hexdigest()])
    hits = []
    for path in (current / 'trace').rglob('cache-hit.json'):
        relative = path.relative_to(current / 'trace')
        value = read(path)
        assert value == read(reference / 'trace' / relative) == read(finite_reference / 'trace' / relative)
        assert value['graph_calls'] == 0 and not value['tensor_payload_available']
        assert not (path.parent / 'hidden.bf16').exists() and not (path.parent / 'logits.f32').exists()
        hits.append(dict(relative=relative.as_posix(), contents=value))
    sessions = observation.get('sessions', [observation])
    keys = ['processed_tokens', 'generated_tokens', 'actual_graph_calls', 'actual_graph_tokens',
            'prefix_hits', 'prefix_misses', 'prefix_full_hits', 'reused_tokens', 'cache_shared_backing_bytes',
            'cache_committed_version_limit', 'cache_live_snapshot_versions', 'cache_peak_committed_versions',
            'prefix_entries', 'prefix_evictions', 'dispatch_session_ids', 'evicted_session_ids']
    cases[current_name] = dict(result=identity(current / 'result.json'), stdout=identity(current / 'stdout.log'),
        baseline_run=str(reference), finite_reference_run=str(finite_reference), decision_vectors=expected,
        byte_equal_to_both_references=True, every_non_timing_stdout_field_equal=True,
        equal_raw_manifest_sha256=hashlib.sha256(json.dumps(manifest, separators=(',', ':')).encode()).hexdigest(),
        non_timing_observation_sha256=hashlib.sha256(json.dumps(stable(observation), sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        statistics={k: observation[k] for k in keys if k in observation},
        sessions=[dict(id=s.get('session_id'), generated_ids=s['generated_ids'], visible_tokens=s['visible_tokens'],
                       restored_calls=s['restored_calls'], restored_tokens=s['restored_tokens']) for s in sessions],
        full_hits=hits)
    count += expected
assert count == 142

probe_ready = read(Q / 'probe-ready-attempt2.json')
probe_compiled = read(Q / 'compile2/probe/identity.json')
assert probe_compiled['source'] == probe_ready['source']
assert ready['source'] in probe_compiled['dependencies']
assert probe_compiled['object'] in read(probe_ready['link_plan']['path'])['inputs']
assert read(Q / 'compile2/probe/compile.result.json')['exit'] == 0
probe_result = read(Q / 'probe-run2/result.json')
assert probe_result['exit'] == 0 and probe_result['image'] == probe_ready['image']
probe = read(Q / 'probe-run2/stdout.log')
assert probe == read(Q / 'probe-run2/observation.json')
assert probe['status'] == 'PASS'
for key in ['dropped_live_public_completion', 'same_page_exclusive_suffix', 'old_kv_guards_and_bytes_unchanged',
            'idle_stop_preserved_other_execution_loan', 'retired_aborted_slot_rebuilt_in_same_model_bundle',
            'retired_model_episode_detached_all_pending_links', 'post_commit_trace_error_preserved_head_and_returned_loan',
            'different_session_continued_after_report_error']:
    assert probe[key] is True
assert probe['busy_prepare_rejections'] == 3 and probe['old_recurrent_resources_byte_unchanged'] == 36
assert probe['head_alias_sessions_added_distinct_versions'] == 0 and probe['final_tokens'] == 131
assert not probe['native_error_injected'] and not probe['cancel_means_native_preemption']
stderr = (Q / 'probe-run2/stderr.log').read_text(encoding='utf-8-sig')
for stage in ['native_pending', 'stopped_native_pending', 'dropped_completion_native_pending']:
    assert stderr.count('shared_execution_prepare_rejected stage=' + stage + ' ') == 1
assert stderr.count('shared_execution_post_commit_trace_rejected reason=') == 1
assert 'weights.tsv' in stderr and 'retirement_after_report_error tokens=1 visible=131 ' in stderr

report = dict(status='PASS final R1 same-partition142-vector regression and original retirement probe; B2 excluded.',
    checker=identity(__file__), preserved_prior_review=identity(prior_path),
    ready=identity(Q / 'qwen-ready-attempt3.json'), compiled_identity=identity(Q / 'compile4/qwen/identity.json'),
    source=ready['source'], image=ready['image'], recorded_link_inputs=195,
    canonical_vectors=90, prefix_pressure_vectors=52, decision_vectors=142, all_byte_equal=True,
    finite_proof=dict(method='All final raw vectors byte-identical both to S run2 and Q run2; finite status inherited from independently decoded Q run2 raw values.',
                      bf16_elements=145408, f32_elements=17630720, nonfinite_elements=0),
    cases=cases,
    probe=dict(result=identity(Q / 'probe-run2/result.json'), ready=identity(Q / 'probe-ready-attempt2.json'),
               compiled_identity=identity(Q / 'compile2/probe/identity.json'), compiled_source=probe_compiled['source'],
               actual_compiled_main_dependency=ready['source'], image=probe_ready['image'],
               stdout=identity(Q / 'probe-run2/stdout.log'), stderr=identity(Q / 'probe-run2/stderr.log'), observation=probe),
    limits=['No inference/build/GPU or product/source edit. No executable/weights/SDK/old whole-closure rehash.',
            'All non-time observations match: IDs, contexts/phases/dispatch, Graph work, prefix/restore and budget statistics. Capture/preparation diagnostics may differ.',
            'B2run1 remains separately bound in the preserved report to main bb3965fd and probe58c1234e; no B2 vector enters142 or gains a bounded-error/quality claim.',
            'The newly added B2 cancellation probe c90fddc4 is not reviewed or signed by this final R1 report.',
            'R1 byte equality is not all model state bits, concurrent throughput, numerical quality, physical GPU-memory peak or performance proof.'])
destination = Q / 'review/runtime-comparison-final.json'
destination.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(destination), decision_vectors=count, all_byte_equal=True,
                     final_source=ready['source']['sha256'], final_image=ready['image']['sha256'],
                     probe_image=probe_ready['image']['sha256']), indent=2))
