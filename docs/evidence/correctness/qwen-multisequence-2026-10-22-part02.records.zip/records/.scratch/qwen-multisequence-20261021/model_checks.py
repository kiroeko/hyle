"""Root-only original canonical18/72 and prefix52 process entry points."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
source=(R/'.scratch/qwen-prefix-20261021/run.py').read_text(encoding='utf-8')
source=source.replace('m = h.m', '''m = h.m
import inspect
# The consumer now also reports R. Keep the retained raw checker unchanged;
# accept the common finite-family prefix in this task-local runner only.
helper = inspect.getsource(h.run).replace(
    "stderr.count('compile full text finite family variants=')",
    "stderr.count('compile full text finite family ')")
exec(compile(helper, str(Path(__file__).resolve()), 'exec'), h.__dict__)
# Resume only exact same-command/image processes whose exit was already reaped.
h.RESUME = True''')
for old,new in [
    ("plan = m.read(S / 'inputs/plan.json')","plan = m.read(R / '.scratch/qwen-prefix-20261021/inputs/plan.json')"),
    ("S / f'ready-attempt{args.attempt}.json'","S / f'qwen-ready-attempt{args.attempt}.json'")]:
    assert source.count(old)==1;source=source.replace(old,new)
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
