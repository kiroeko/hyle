from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
Q=Path(__file__).resolve().parent;R=Q.parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
p=argparse.ArgumentParser();p.add_argument('mode',choices=('prefix-tests','batch-probe'));p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
ready_path=Q/f'{a.mode}-ready-attempt{a.attempt}.json';ready=read(ready_path)
assert hashlib.sha256(Path(ready['image']['path']).read_bytes()).hexdigest()==ready['image']['sha256']
out=Q/f'{a.mode}-run{a.attempt}';out.mkdir(exist_ok=False)
command=[ready['image']['path']]
if a.mode=='prefix-tests':command+=['--gtest_filter=Qwen*','--gtest_output=xml:'+str(out/'gtest.xml')]
else:command+=['--inputs',str(R/'.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/128-prefill/inputs'),'--output',str(out/'data')]
env=os.environ.copy();env['PATH']=read(ready['runtime_environment']['path'])['PATH']
record=dict(command=command,image=ready['image'],ready=str(ready_path),throughput_evidence=False,cwd=str(R),started_unix_ns=time.time_ns())
save(out/'command.json',record);process=None
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
    try:
        process=subprocess.Popen(command,cwd=R,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW);record['pid']=process.pid
        try:record['exit']=process.wait(timeout=180)
        except subprocess.TimeoutExpired:record['timeout']=True;process.kill();record['exit']=process.wait()
    finally:
        if process is not None and process.poll()is None:process.kill();process.wait()
        record['finished_unix_ns']=time.time_ns();save(out/'result.json',record)
print((out/'stdout.log').read_text(encoding='utf-8-sig'))
if record['exit']:print((out/'stderr.log').read_text(encoding='utf-8-sig')[-6000:])
assert record['exit']==0 and not record.get('timeout'),out
