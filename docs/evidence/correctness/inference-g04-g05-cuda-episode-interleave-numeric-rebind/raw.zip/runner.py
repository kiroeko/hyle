from pathlib import Path
import copy,hashlib,json,os,re,subprocess,time,zipfile
root=Path('/mnt/c/public/project-hyle/hyle')
build=Path('/root/hyle-scratch/compute-unified/g04-cuda-encoded-p1-fresh-5')
source=Path('/root/hyle-scratch/compute-unified/g04-cuda-encoded-p1-source-5')
out=root/'.scratch/inference-gaps/g04-g05/cuda-interleave-numeric-rebind-1';out.mkdir(exist_ok=False)
old_file=root/'evidence/correctness/inference-g04-g05-cuda-encoded-page-preflight/receipt.json'
old=json.loads(old_file.read_text());n=copy.deepcopy(old['successful_run'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert old['state']=='TERMINAL_PASS'
old_inputs={x['path']:x['sha256'] for x in n['snapshot']['benchmark_inputs']}
changed=[x for x,h in old_inputs.items() if sha(root/x)!=h]
assert changed==['bench/inference_resident_sdpa/cuda_encoded_page_bench.cc']
for x in n['snapshot']['benchmark_inputs']:
 assert sha(root/x['path'])==sha(source/x['path'])
 x['sha256']=sha(root/x['path'])
for x in n['sdk_artifacts']:assert sha(Path(x['path']))==x['sha256']
cache=dict(x.split('=',1) for x in (build/'CMakeCache.txt').read_text().splitlines() if '=' in x and not x.startswith(('#','//')))
sdk=Path(cache['Hyle_DIR:PATH']).parents[2]
for x in n['sdk_recipes']+n['sdk_native_archives']:assert sha(sdk/x['path'])==x['sha256']
original=json.loads((build/'original-peer/original-flashinfer-source.json').read_text())
for k in ('revision','inputs','all_original_headers','adaptation','status'):assert original[k]==n['original_source'][k]
stages=[];binaries=[];env=os.environ.copy();env['HYLE_BENCH_VERIFY_ONLY']='1';env['CUDA_VISIBLE_DEVICES']='0'
for variant,stem in (('primary','g04_cuda_encoded_bench'),('placement','g04_cuda_encoded_bench_placement')):
 binary=build/'bin'/stem;binaries.append(dict(variant=variant,path=str(binary),sha256=sha(binary)))
 cmd=[str(binary)];t=time.monotonic();log=out/(variant+'.log')
 with log.open('w') as f:code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 elapsed=time.monotonic()-t;stages.append(dict(stage=variant,command=cmd,exit_code=code,elapsed_seconds=elapsed,log=str(log)))
 assert code==0 and sha(binary)==binaries[-1]['sha256']
 text=log.read_text();values=re.findall(r'# CUDA_ENCODED_CORRECTNESS max_abs_error=([^ ]+)',text)
 assert len(values)==24 and max(map(float,values))<=8e-3 and text.count('# CUDA_FP8_PAIR ')==3
 facts=[re.sub(r' original=[01]$','',line) for line in text.splitlines() if line.startswith('# CUDA_ENCODED_ENV ')]
 assert len(facts)==6 and set(facts)=={n['native_environment']}
 assert text.count('# CUDA_ENCODED_ORIGINAL_COLD ')==3
 print(variant,'PASS',elapsed,flush=True)
for x in n['sdk_artifacts']:assert sha(Path(x['path']))==x['sha256']
n.update(stages=stages,cumulative_seconds=sum(x['elapsed_seconds'] for x in stages),binary=binaries[0],binaries=binaries,
 original_source=original,actual_compile_steps=[],rebind_only=True,readonly='PASS',state='TERMINAL_PASS')
n['snapshot']['canonical_head']=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
n['max_abs_error']=max(float(x) for v in ('primary','placement') for x in re.findall(r'# CUDA_ENCODED_CORRECTNESS max_abs_error=([^ ]+)',(out/(v+'.log')).read_text()))
(out/'successful_run.json').write_text(json.dumps(n,indent=2)+'\n')
(out/'runner.py').write_bytes(Path(__file__).read_bytes());(out/'ninja-build.log').write_bytes((build/'.ninja_log').read_bytes())
dest=root/'evidence/correctness/inference-g04-g05-cuda-episode-interleave-numeric-rebind';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.iterdir()):z.write(p,p.name)
receipt=dict(state='TERMINAL_PASS',kind='CUDA_ENCODED_NUMERIC_REBIND_FOR_EPISODE_INTERLEAVE',successful_run=n,
 previous_receipt=str(old_file.relative_to(root)),previous_receipt_sha256=sha(old_file),
 changed_benchmark_inputs=changed,reused_native_and_sdk='All original headers/SDK artifact/recipe/native archive SHAs verified unchanged before and after actual two-binary oracle; zero build commands.',
 limits=['48 actual independent double-oracle replays across3 shapes/2 variants/2 arms/4 replays;readonly all physical bytes checked by original fixture',
 'No timing/A/A/product throughput or GPU sanitizer verdict. Existing original failures and cost remain; private pools UNKNOWN'],
 measured_seconds=n['cumulative_seconds'],raw_zip_sha256=sha(dest/'raw.zip'))
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('TERMINAL_PASS',receipt['measured_seconds'],flush=True)
