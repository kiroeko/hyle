"""Collect only frozen source, recipes and logs; no native/model payload."""
from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(p):return json.loads(Path(p).read_text())
summary=read(W/'summary.json');assert summary['status']=='ORDINARY_AND_MTP_K3_APPLE_CLI_PASS'
ready=read(W/'ready.json');assert pin(ready['image']['path'])==ready['image']
for row in read(W/'source-freeze.json'):assert pin(W/'source'/row['path'])['sha256']==row['sha256']
for row in read(W/'reused-inputs.json'):assert pin(row['path'])==row
members={}
for p in W.rglob('*'):
 if p.is_file() and (p.is_relative_to(W/'source') or p.suffix in {'.json','.py','.log','.tsv','.ids'}):
  members[p.relative_to(W).as_posix()]=p.read_bytes()
manifest=[dict(name=n,bytes=len(v),sha256=sha(v)) for n,v in sorted(members.items())]
members['archive-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=W/'records.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(dest) as z:
 assert set(z.namelist())==set(members) and z.testzip() is None
 for n,b in members.items():assert z.read(n)==b
print(json.dumps(dict(archive=pin(dest),members=len(members),ready=pin(W/'ready.json'),summary=pin(W/'summary.json'))))
