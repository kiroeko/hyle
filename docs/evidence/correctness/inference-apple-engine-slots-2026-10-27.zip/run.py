"""Remote finite six-TU cached build and two real CLI processes."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,traceback
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-apple-engine-slots-20261027')
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as s:
  for chunk in iter(lambda:s.read(1<<20),b''):h.update(chunk)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def execute(tag,args,timeout):
 out=W/tag;out.mkdir(exist_ok=False);plan=read(W/'plan.json');env=os.environ.copy();env.update(plan['environment'])
 save(out/'command.json',dict(command=args,cwd=str(W),environment=plan['environment']))
 start=time.perf_counter()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  p=subprocess.Popen(args,cwd=W,env=env,stdout=stdout,stderr=stderr);save(out/'running.json',dict(pid=p.pid));expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:expired=True;p.kill();code=p.wait(timeout=5)
 result=dict(pid=p.pid,exit=code,seconds=time.perf_counter()-start,timeout=expired);save(out/'process.json',result);print(tag,json.dumps(result),flush=True)
 if code or expired:raise RuntimeError(tag+' failed; no automatic retry')
 return result
def build():
 p=read(W/'plan.json');frozen={str((W/'source'/r['path']).resolve()):r for r in read(W/'source-freeze.json')}
 for name,row in frozen.items():assert pin(name)['sha256']==row['sha256'],name
 for r in p['reused_source_objects']:assert pin(r['source'])['sha256']==r['expected_current_source_sha256'],r['source']
 payload=pin(p['fixture']['binary']);assert payload['bytes']==p['fixture']['expected_bytes'] and payload['sha256']==p['fixture']['expected_sha256']
 assert pin(W/'fixture/weights.tsv')['sha256']==p['fixture']['adapted_manifest_sha256']
 save(W/'fixture.json',dict(payload=payload,manifest=pin(W/'fixture/weights.tsv'),prompt=pin(W/'fixture/prompt.ids'),quality_claim=False))
 save(W/'hardware.json',dict(model=subprocess.check_output(['sysctl','-n','hw.model'],text=True),memory=subprocess.check_output(['sysctl','-n','hw.memsize'],text=True),
  clang=subprocess.check_output(['/usr/bin/c++','--version'],text=True),os=subprocess.check_output(['sw_vers'],text=True),space=subprocess.check_output(['df','-Pk',str(W)],text=True)))
 current={str(W/(n+'.o')) for n in ('resources','slots','slots_region','model','weights','entry')}
 args=p['jobs'][-1]['command'];used=[]
 for a in args:
  q=Path(a)
  if a not in current and q.is_file() and q.suffix in ('.o','.a','.dylib'):used.append(pin(q))
 save(W/'reused-inputs.json',used)
 results=[]
 for job in p['jobs']:
  result=execute(job['tag'],job['command'],job['timeout']);results.append(dict(tag=job['tag'],process=result))
  if '-c' in job['command']:
   dep=Path(job['command'][job['command'].index('-MF')+1]);raw=dep.read_text();save(W/job['tag']/'dependencies.json',dict(makefile=raw))
   actual=[]
   for s in re.split(r'\s+',raw.replace('\\\n',' ').split(': ',1)[1].strip()):
    name=str(Path(s).resolve())
    if name in frozen:
     fact=pin(name);assert fact['sha256']==frozen[name]['sha256'],name;actual.append(fact)
    elif '/source/include/hyle/' in name or ('/source/src/' in name and '/hyle-scratch/' in name) or '/source/engine/' in name:
     raise RuntimeError('unfrozen project dependency '+name)
   save(W/job['tag']/'actual-project-dependencies.json',actual)
  save(W/'partial-build.json',results)
 for fact in used:assert pin(fact['path'])==fact
 mapping=(W/'image.map').read_text().split('# Object files:',1)[1].split('# Sections:',1)[0]
 for n in ('resources','slots','slots_region','model','weights','entry'):assert str(W/(n+'.o')) in mapping,n
 assert '/inference-paged-frame-20261026/model.o' not in mapping and '/test.o' not in mapping
 assert not any(x in mapping for x in ('/libgtest','native_slot_store_region.cc.o)','apple_copy_recording.mm.o)'))
 save(W/'linked-object-map.json',dict(raw=mapping,current_objects=[pin(W/(n+'.o')) for n in ('resources','slots','slots_region','model','weights','entry')],no_whole_archive=True,no_duplicate_ignore=True))
 save(W/'ready.json',dict(image=pin(W/'hyle'),processes=results,compiled_TUs=6,SDK_builds=0,window=p['window']))
def run():
 image=read(W/'ready.json')['image'];assert pin(image['path'])==image
 args=[image['path'],'--inputs',str(W/'fixture'),'--backend','apple','--replay','commands','--progress','direct','--capacity','16','--max-sessions','4','--active-sequences','1','--prefix-cache','off','--steps','8','--sampling','greedy','--mtp','off']
 rows=[]
 for name in ('ordinary','mtp-k3'):
  cmd=list(args)
  if name=='mtp-k3':cmd[-1]='on';cmd+=['--mtp-max-drafts','3']
  proc=execute('run-'+name,cmd,90)
  reports=[json.loads(x) for x in (W/('run-'+name)/'stdout.log').read_text().splitlines() if x.startswith('{')];assert len(reports)==1
  r=reports[0];assert r['backend']=='apple' and r['generated_tokens']==8 and r['live_committed_versions']==0 and r['retired_requests']==1
  assert r['cpu_ffn_layers']==0 and r['original_host_weight_bytes']==0
  assert r['mtp']==(name=='mtp-k3')
  if name=='mtp-k3':assert r['mtp_max_drafts']==3 and r['draft_program_graph_calls']>0
  ids=r['sessions'][0]['result']['generated_ids'];assert len(ids)==8 and all(isinstance(x,int) and 0<=x<64 for x in ids)
  rows.append(dict(name=name,process=proc,report=r,generated_ids=ids));save(W/'partial-run.json',rows)
 save(W/'summary.json',dict(status='ORDINARY_AND_MTP_K3_APPLE_CLI_PASS',image=image,runs=rows,processes=2,quality_claim=False,performance_claim=False,window=read(W/'ready.json')['window']))
if __name__=='__main__':
 try:{'build':build,'run':run}[sys.argv[1]]()
 except Exception:save(W/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc()));raise
