"""Freeze only project source for one cached Apple CLI; no SDK/payload copy."""
from pathlib import Path
import hashlib,json,re,zipfile
R=Path(__file__).resolve().parents[2]
W=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-apple-engine-slots-20261027'
BASE='/Users/kiro/hyle-scratch/compute-unified'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((R/'engine/models/qwen35/main.cc').read_bytes())=='14323839a114921a6aff72ccccd25a3b3b5ef355bdcbdc7c3caebd85a33564b4'
assert not (W/'plan.json').exists()
P=R/'.scratch/inference-paged-frame-20261026/mac/records'
B=R/'.scratch/inference-native-slot-byte-ranges-20261027/records'
common=read(R/'.scratch/inference-native-slot-store-20261027/records/plan4.json')
base=read(B/'plan3.json')
specs=[('resources','src/graph/resources.cc'),('slots','src/graph/slots.cc'),
 ('slots_region','src/graph/slots_region.cc'),('model','engine/models/qwen35/main.cc'),
 ('weights','engine/models/qwen35/weights.cc'),('entry','engine/main.cc')]
roots=[R,R/'include',R/'engine',*[R/'src'/s for s in ('compute','graph','compute_batch','compute_provider_native','compute_stream','compute_route_apple','graph_route_apple')]]
files={};todo=[R/p for _,p in specs]
while todo:
 p=todo.pop().resolve();name=p.relative_to(R).as_posix()
 if name in files:continue
 raw=p.read_bytes();files[name]=raw
 for inc in re.findall(r'^\s*#\s*include\s*["<]([^">\r\n]+)[">]',raw.decode('utf-8-sig'),re.M):
  for d in [p.parent,*roots]:
   q=(d/inc).resolve()
   if q.is_file() and q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
    todo.append(q);break
prefix=['-I'+REMOTE+'/source/include','-I'+REMOTE+'/source','-I'+REMOTE+'/source/engine',*['-I'+REMOTE+'/source/src/'+s for s in ('compute','graph','compute_batch','compute_provider_native','compute_stream','compute_route_apple','graph_route_apple')]]
jobs=[]
for tag,source in specs:
 if tag in ('model','weights','entry'):
  template=read(P/('compile-weights' if tag=='weights' else 'compile-model')/'command.json')['command']
 else:template=next(j['command'] for j in common['jobs'] if j.get('source')==source)
 args=[a for a in template if not(a.startswith('-I') and ('/source/include' in a or '/source/src/' in a or a.endswith('/source') or '/model' in a or a.endswith('/public')))]
 args=args[:1]+prefix+args[1:]
 args[args.index('-c')+1]=REMOTE+'/source/'+source
 args[args.index('-o')+1]=REMOTE+'/'+tag+'.o'
 args[args.index('-MF')+1]=REMOTE+'/'+tag+'.o.d'
 assert '-DHYLE_COMPUTE_APPLE=1' in args and '-DHYLE_COMPUTE_CPU=1' in args
 jobs.append(dict(tag='compile-'+tag,source=source,command=args,timeout=180))
link=list(next(j['command'] for j in base['jobs'] if j['tag']=='link'))
removed=[a for a in link if a.endswith('/test.o') or a.endswith('/libgtest_main.a') or a.endswith('/libgtest.a')]
assert len(removed)==3
link=[a for a in link if a not in removed]
replacements=[]
for name in ('resources','slots','slots_region'):
 old=BASE+'/inference-native-slot-store-20261027/'+name+'.o';assert link.count(old)==1
 new=REMOTE+'/'+name+'.o';link[link.index(old)]=new;replacements.append(dict(before=old,after=new))
report=BASE+'/inference-native-host-image-20261026/model-attempt2/report.o'
link[1:1]=[REMOTE+'/'+x+'.o' for x in ('model','weights','entry')]+[report]
link[link.index('-o')+1]=REMOTE+'/hyle'
link=[('-Wl,-map,'+REMOTE+'/image.map') if a.startswith('-Wl,-map,') else a for a in link]
assert not any('force_load' in a or 'all_load' in a or 'allow_duplicate' in a for a in link)
jobs.append(dict(tag='link',command=link,timeout=180))
frozen=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(files.items())]
save(W/'source-freeze.json',frozen)
reused=[]
for object_name,rel,where in [
 ('leases.o','src/compute/resource_leases.cc','inference-native-slot-store-20261027'),
 ('float2.o','src/compute_route_apple/apple_mature_float.cc','inference-native-slot-store-20261027'),
 ('native.o','src/graph_route_apple/native_region.cc','inference-native-slot-store-20261027'),
 ('copy.o','src/compute_route_apple/apple_copy_recording.mm','inference-native-slot-byte-ranges-20261027'),
 ('store.o','src/graph_route_apple/native_slot_store_region.cc','inference-native-slot-byte-ranges-20261027')]:
 reused.append(dict(object=BASE+'/'+where+'/'+object_name,source=BASE+'/'+where+'/source/'+rel,
   expected_current_source_sha256=sha((R/rel).read_bytes()),windows_source=rel))
manifest=(R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input/weights.tsv').read_bytes()
old='C:/public/project-hyle/hyle/.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture/untrained-bf16.bin'
binary=BASE+'/inference-paged-frame-20261026/fixture/untrained-bf16.bin'
adapted=manifest.decode('utf-8-sig').replace(old,binary).encode('utf-8')
assert old not in adapted.decode() and binary in adapted.decode()
save(W/'plan.json',dict(remote=REMOTE,jobs=jobs,compiled_TUs=6,replacements=replacements,removed_test_inputs=removed,
 baseline_plan=str(B/'plan3.json'),baseline_plan_sha256=sha((B/'plan3.json').read_bytes()),environment=base['environment'],
 window=dict(windows_head='bfe7159d4ab9f6824c5ca4c78ab99904ec0f0100',main_sha256=sha(files['engine/models/qwen35/main.cc']),
   semantics='Actual frozen Windows bytes; later Windows edits do not change this validation source window.'),
 reused_source_objects=reused,fixture=dict(binary=binary,expected_bytes=298628,expected_sha256='2fbd8f01edd4fc71c2dd5b7fe57b8173a3aace490819b320719fd82add57bf14',
   windows_manifest_sha256=sha(manifest),adapted_manifest_sha256=sha(adapted),input=REMOTE+'/fixture'),
 scope='Current CPU+Apple formal CLI, ordinary and MTPK3 only; tiny recursive+attention BF16 fixture. No complete model, task quality, performance or old suite rerun.',
 SDK_builds=0,HTTP=0,shader_builds=0))
with zipfile.ZipFile(W/'source.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in files.items():z.writestr('source/'+name,raw)
 for name in ('plan.json','source-freeze.json','run.py'):z.write(W/name,name)
 z.writestr('fixture/weights.tsv',adapted);z.writestr('fixture/prompt.ids',b'1 2 3\n')
print(json.dumps(dict(project_files=len(files),project_bytes=sum(map(len,files.values())),zip_bytes=(W/'source.zip').stat().st_size,TUs=6,main_sha256=sha(files['engine/models/qwen35/main.cc']))))
