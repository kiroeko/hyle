"""Synchronize the frozen small project overlay to the fixed Mac root."""
from pathlib import Path
import hashlib,json,shlex,subprocess,sys,time
W=Path(__file__).resolve().parent
HOST='kiro@172.22.10.198'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-apple-engine-slots-20261027'
def execute(tag,args):
 start=time.perf_counter();p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (W/(tag+'-stdout.log')).write_bytes(p.stdout);(W/(tag+'-stderr.log')).write_bytes(p.stderr)
 (W/(tag+'-process.json')).write_text(json.dumps(dict(command=args,exit=p.returncode,seconds=time.perf_counter()-start),indent=2)+'\n')
 if p.returncode:raise RuntimeError(tag+' failed')
 return p.stdout
code='from pathlib import Path; Path('+repr(REMOTE)+').mkdir(exist_ok=False)'
execute('mkdir',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',HOST,shlex.join(['python3','-c',code])])
execute('scp',['scp','-o','BatchMode=yes',str(W/'source.zip'),HOST+':'+REMOTE+'/source.zip'])
digest=hashlib.sha256((W/'source.zip').read_bytes()).hexdigest()
code='import hashlib,zipfile; from pathlib import Path; w=Path('+repr(REMOTE)+'); p=w/"source.zip"; assert hashlib.sha256(p.read_bytes()).hexdigest()=='+repr(digest)+'; z=zipfile.ZipFile(p); assert all(not x.startswith("/") and ".." not in Path(x).parts for x in z.namelist()); z.extractall(w); print(len(z.namelist()))'
print(execute('extract',['ssh','-o','BatchMode=yes',HOST,shlex.join(['python3','-c',code])]).decode(),end='')
