"""Publish a separately frozen Apple consumer window; no new execution."""
from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
assert pin(W/'records.zip')['sha256']=='385ccb68b6815c4fe4c8bdc583410f62acb245f8f87fe3ee38cf4f0b6580d92c'
with zipfile.ZipFile(W/'records.zip') as z:
 assert z.testzip() is None
 members={n:z.read(n) for n in z.namelist()}
old_manifest=json.loads(members['archive-manifest.json'])
for row in old_manifest:
 raw=members[row['name']];assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
def read(n):return json.loads(members[n])
plan=read('plan.json');ready=read('ready.json');summary=read('summary.json');frozen=read('source-freeze.json')
assert summary['status']=='ORDINARY_AND_MTP_K3_APPLE_CLI_PASS'
assert len(ready['processes'])==7 and all(x['process']['exit']==0 for x in ready['processes'])
assert ready['compiled_TUs']==6 and ready['SDK_builds']==0
with zipfile.ZipFile(W/'source.zip') as z:
 for row in frozen:
  name='source/'+row['path'];assert z.read(name)==members[name]
  assert len(members[name])==row['bytes'] and sha(members[name])==row['sha256']
assert ready['window']==summary['window']==plan['window']
assert ready['window']['main_sha256']=='14323839a114921a6aff72ccccd25a3b3b5ef355bdcbdc7c3caebd85a33564b4'
observations=[]
for row in summary['runs']:
 report=row['report'];s=report['sessions'][0]['result']
 raw=members['run-'+row['name']+'/stdout.log'].decode()
 assert [json.loads(x) for x in raw.splitlines() if x.startswith('{')]==[report]
 assert row['process']['exit']==0 and report['backend']=='apple' and report['generated_tokens']==8
 assert report['retired_requests']==1 and report['live_committed_versions']==0
 observations.append(dict(name=row['name'],process=row['process'],generated_ids=row['generated_ids'],
  backend=report['backend'],mtp=report['mtp'],mtp_max_drafts=report['mtp_max_drafts'],
  actual_graph_calls=report['actual_graph_calls'],draft_graph_calls=report['draft_program_graph_calls'],verified_target_rows=report['verified_target_rows'],
  draft_rounds=s.get('draft_rounds'),consumed_drafts=s.get('consumed_drafts'),
  retired_requests=report['retired_requests'],live_committed_versions=report['live_committed_versions'],
  host_weight_bytes=report['original_host_weight_bytes'],cpu_ffn_layers=report['cpu_ffn_layers']))
assert len(observations)==2 and observations[0]['generated_ids']==observations[1]['generated_ids']
assert observations[1]['mtp_max_drafts']==3 and observations[1]['draft_graph_calls']==21
assert observations[1]['consumed_drafts']==0
# Preserve original remote records and add local freeze/transport commands, without
# embedding another source ZIP or any OBJ, executable, SDK, metallib or model file.
for name in ('prepare.py','ship.py','publish.py','mkdir-process.json','mkdir-stdout.log','mkdir-stderr.log','scp-process.json','scp-stdout.log','scp-stderr.log','extract-process.json','extract-stdout.log','extract-stderr.log'):
 members['windows/'+name]=(W/name).read_bytes()
hardware=read('hardware.json')
receipt=dict(schema=1,date='2026-10-27',title='Apple provider-independent indexed state tiny CLI',
 status='FINITE_ORDINARY_AND_MTP_K3_CLI_PASS',window=ready['window'],hardware=hardware,
 source_scope='Windows product bytes frozen at bfe7159d4/main14323839 before later root edits, synchronized only to the fixed Hyle Mac work directory. No product modification or reverse synchronization from Mac. This receipt is independent of subsequent Windows source and the earlier Vulkan window.',
 source_freeze=dict(project_files=len(frozen),project_bytes=sum(x['bytes'] for x in frozen),
  windows_archive=pin(W/'source.zip'),actual_mac_manifest_sha256=sha(members['source-freeze.json']),
  proof='Every Mac source snapshot checked against its actual frozen SHA and the original Windows source ZIP. Actual makefile dependencies for all six compiles resolve project files only within that frozen overlay; original external toolchain/SDK includes remain cached.'),
 changes='None to product code; six necessary consumers/shared implementations are incrementally compiled for the new state protocol.',
 build=dict(CXX_TUs=6,compiler_processes=6,links=1,processes=ready['processes'],image=ready['image'],
  new_units=[j['source'] for j in plan['jobs'] if 'source' in j],
  reused_input_count=len(read('reused-inputs.json')),
  reuse='Latest native Apple selected-row Gather, Store, exact host byte-copy, and LeaseSlots objects reused with original initialized copy/transfer/Completion, resource and SDK closure. Rebuilt resources/slots/slots_region after batching changes. Model, weights and entry use matching CPU+Apple macros; old weights depended on changed session_state, so it is rebuilt. No old hostprobe Model/GTest or old Store/CopyRecording archive member is extracted; actual linked map section is retained.',
  ABI='The changed model/session types are compiled together in Model and weights. StoreBinding remains opaque in its unchanged private header; native Store and CopyRecording source identities match their prior independently validated snapshots, with original opaque definitions. New Graph resource episode/control-batch state is private to rebuilt TUs. No native SDK/shared public struct layout change is introduced by this validation.',
  SDK_rebuilds=0,offline_shader_rebuilds=0,downloads=0),
 fixture=dict(**read('fixture.json'),roles=42,purpose='Existing 298628-byte untrained BF16 GA target layers plus MTP roles, 3 prompt IDs, C16/N4/R1, 8 generated IDs. Manifest only adapts the original binary path. No model payload copied/downloaded or included in archive.'),
 execution=dict(actual_processes=2,observations=observations,
  result='Both CLI processes exited zero once. Eight legal vocabulary IDs match in this fixture, actual backend Apple with no CPU FFN/host weight placement. Both retire the request with zero live committed versions.',
  acceptance_boundary='MTPK3 executes six draft rounds/21 draft graph calls/22 verified target rows, but consumed_drafts=0. This proves candidate generation, verification, rejection/repair and resource retirement in this fixture; it does not prove a positive accepted prefix longer than one on Apple.',
  timing='Raw process elapsed and native CLI timing fields are diagnostic only. Ordinary first-run 19.185s includes preparation; its cause was not attributed. No throughput comparison or benchmark claim.',
  quality_claim=False,performance_claim=False),
 failures='No preparation, compiler, link or native CLI failure/retry in this batch. Earlier cached receipts remain independent, with their own original failures and boundaries.',
 unverified=['Untrained hidden64/two-target-layer fixture, not complete Qwen3.5-2B weights or task quality.',
  'No positive multi-token draft acceptance, B2 multi-request, randomized sampling, capture, host-image/lag1 rerun, native fault injection or exhaustive shape/device matrix in this batch.',
  'Normal MLX runtime preparation uses its original cached facilities; this receipt asserts no SDK/offline shader rebuild, not that native runtime preparation performs zero work.',
  'Other Windows changes made after this frozen source window are not covered by this Apple image.'],
 remote_archive=pin(W/'records.zip'),
 members=[dict(name=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())])
manifest=(json.dumps(receipt,indent=2)+'\n').encode();members['manifest.json']=manifest
dest=R/'docs/evidence/correctness';stem='inference-apple-engine-slots-2026-10-27';public=dest/(stem+'.json');archive=dest/(stem+'.zip')
assert not public.exists() and not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members) and z.testzip() is None
 for n,b in members.items():assert z.read(n)==b and sha(z.read(n))==sha(b)
receipt['archive']=pin(archive);receipt['archive_manifest_sha256']=sha(manifest)
receipt['integrity']='Original remote member manifest verified; public ZIP reopened per member and compared bytes/SHA256 with CRC check. Frozen Windows ZIP versus Mac actual source/command/dependency records verified. No executable/object/SDK/model payload included.'
public.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
result=dict(receipt=pin(public),archive=pin(archive),members=len(members));(W/'published.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
