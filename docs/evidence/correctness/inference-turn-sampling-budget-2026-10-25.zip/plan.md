# Ordinary turn sampling-address admission — private draft

- Baseline HEAD `b9096abc65a9c85d7cb226e874154f992cfb4f1a`, canonical main `f8fbb80d369cc8a2c1dfcc5e6442b57af21047cef0be9de2b32ce74111c3cd7b`.
- Product change is model-local main arithmetic only. No new reservation, cursor owner, sampling graph, RequestProgress state or Model math.
- `preflight_generation_sampling` skips greedy and MTP, proves `cursor.advanced(remaining turn outputs)` before the first admission mutation. Live head is authoritative; an evicted committed request uses its original ledger's last after; a new request uses initial_sampling, even on a full prefix hit.
- Before begin_turn, read the current immutable scheduled quota (not stale previous turn_output_begin); after begin use remaining_outputs. State-only chunks retain the same cursor and proof endpoint. Prefill/full-hit consumes one of these outputs; final pending is not an extra sample. MAX-1/quota1 is valid and ends at MAX; MAX/quota1 rejects.
- Calls: prepare_generation_call before begin/bind/input; restore before lookup/rebuild; finite waiting admission before eviction/restore/begin/Window.admitted. Cursor policy/ledger validation remains original.
- Raw prepare_evaluations now proves ordinary Text EmitNext advanced(1) in original full preflight, before exact-family admission/StepState/carrier/input writes. Old late Text proof removed; actual next cursor remains unchanged. MTP 3-draw proof/order unchanged.

Finite CPU plan (one thin app TU, one process, no separate host/SKD/provider/core build):
1. Same tiny A/H64/FFN128/V64 fixture and original 129 absolute common link inputs/native DLL. P2/C16, random and a cold greedy sampler on same Model.
2. New initial MAX-1/quota2 rejection: no turn begin, Session/version, ledger binding/commit, input offset or carrier. Same request initial MAX-2 retry -> two outputs, draw MAX. Separate MAX-1/quota1 -> MAX and complete.
3. Actual completed-prefix publication with low publisher cursor; new MAX-1/quota2 request must reject before lookup/import; legal new cursor retries full hit and next decode to MAX. No publisher cursor inheritance.
4. Started later turn and current-head/evicted-ledger recovery cursor checks; already consumed state-only chunks do not spend draw; true prepared-state boundary remains immutable on rejection, legal retry works. No synthetic native failure.
5. Raw Text random cursor MAX rejected with head and episode state untouched; StateOnly at MAX remains legal and consumes no draw. Greedy at MAX remains legal.
6. EOF actual no active step/carrier/live Snapshot versions, all original values finite/valid. Derived IDs are checked against actual ledger/head, not invented expected sample at max address.

Reuse recipe: `.scratch/inference-request-stop-policy-20261025/recipe.json` / its check.py; replace only app TU and freeze current self-written quoted headers. App includes main and one reusable formal helper; avoid full lifecycle TU's CUDA-only symbols. SourceDependencies records actual private main/helper plus current sampler/retirement/output-delivery; DLL hardlink next to exe as before. Existing CPU fixture, 120s watchdog, 0 HTTP/GPU. No performance claim.

Current state: source-only, not compiled or run. Test helper and exact recipe are being prepared. No canonical files modified.
