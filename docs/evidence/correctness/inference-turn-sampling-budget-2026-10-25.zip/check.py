from pathlib import Path
import difflib
import importlib.util
import json
import os
import re
import subprocess
import sys
sys.dont_write_bytecode = True
R = Path.cwd()
W = R / '.scratch/inference-turn-sampling-budget-20261025'
S = W / 'source'
B = W / 'before'
A = W / (sys.argv[2] if len(sys.argv) > 2 else 'app1')
OLD = R / '.scratch/inference-request-stop-policy-20261025'
spec = importlib.util.spec_from_file_location('cached', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
PRODUCT = ['engine/models/qwen35/main.cc', 'tests/tools/qwen_request_lifecycle_test.cc',
           'tests/tools/qwen_sampling_budget_case.h']

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')

def patch():
    lines = []
    pins = []
    for rel in PRODUCT:
        old = B / rel
        new = S / rel
        before = old.read_bytes() if old.exists() else b''
        after = new.read_bytes()
        lines.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                     fromfile='a/' + rel if old.exists() else '/dev/null', tofile='b/' + rel))
        pins.append(dict(path=rel, before=b.pin(old) if old.exists() else None, after=b.pin(new),
                         before_CRLF=before.count(b'\r\n'), after_CRLF=after.count(b'\r\n')))
    (W / 'source.patch').write_bytes(''.join(lines).encode())
    save(W / 'source-pins.json', dict(baseline_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                                     product_files=pins))

def prepare():
    # Freeze only self-written engine dependencies consumed by the prior actual
    # thin CPU TU, with current canonical bytes. No SDK or model copies.
    for item in b.read(OLD / 'app1/compile/repository-inputs.json'):
        p = Path(item['path'])
        if p.is_relative_to(OLD / 'source'):
            rel = p.relative_to(OLD / 'source')
            if rel.parts[0] == 'engine' and not (S / rel).exists():
                for base in [B, S]:
                    dest = base / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes((R / rel).read_bytes())
    visited = set()
    def quoted(p):
        if p in visited:
            return
        visited.add(p)
        for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"', p.read_text(encoding='utf8'), re.M):
            target = (p.parent / name).resolve()
            if not target.exists():
                original = ((R / p.relative_to(S)).parent / name).resolve()
                if original.exists() and original.is_relative_to(R):
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(original.read_bytes())
                    old = B / target.relative_to(S)
                    old.parent.mkdir(parents=True, exist_ok=True)
                    if not old.exists():
                        old.write_bytes(target.read_bytes())
            if target.exists() and target.suffix in {'.cc', '.h', '.inc'}:
                quoted(target)
    quoted(S / 'engine/models/qwen35/main.cc')
    quoted(S / 'tests/tools/qwen_sampling_budget_case.h')
    (W / 'consumer.cc').write_text('#include "source/engine/models/qwen35/main.cc"\n'
        '#include "source/tests/tools/qwen_sampling_budget_case.h"\n'
        'int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("sampling-budget PREPARED_INPUTS");'
        'return qwen_sampling_budget_case::run(argv[1]);}catch(const std::exception &e){'
        'std::cerr<<"sampling_budget_failure="<<e.what()<<"\\n";return 1;}}\n', encoding='utf8')
    old = b.read(OLD / 'recipe.json')
    command = []
    skip = False
    for arg in old['compile']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')) or str(OLD).lower() in arg.lower():
            continue
        command.append(arg)
    command.insert(1, '/I' + str(S))
    command += [str(W / 'consumer.cc'), '/sourceDependencies', str(W / 'app1/compile/dependencies.json'),
                '/Fo' + str(W / 'app1/compile/unit.obj'), '/Fd' + str(W / 'app1/compile/unit.pdb')]
    link = []
    replacements = 0
    for arg in old['link']:
        if arg.lower().startswith(('/out:', '/pdb:', '/implib:')):
            continue
        if Path(arg) == OLD / 'app1/compile/unit.obj':
            arg = str(W / 'app1/compile/unit.obj')
            replacements += 1
        link.append(arg)
    assert replacements == 1
    link += ['/OUT:' + str(W / 'app1/link/component.exe'), '/PDB:' + str(W / 'app1/link/component.pdb'),
             '/IMPLIB:' + str(W / 'app1/link/component.lib')]
    plan = dict(status='AUTHORIZED_ONE_THIN_CPU_TU_ONE_PROCESS', compile=command, link=link,
                common_inputs=old['common_inputs'], native=old['native'], runtime=old['runtime'],
                fixture=old['fixture'], fixture_body=old['fixture_body'],
                process_argv=[str(W / 'app1/link/component.exe'), str(Path(old['fixture']['path']).parent)],
                retained_common_inputs=129, total_link_inputs=130, watchdog_seconds=120,
                SDK_TUs=0, core_TUs=0, provider_TUs=0, GPU=False, HTTP=0)
    save(W / 'recipe.json', plan)
    patch()
    print('Prepared one app TU, exact 129 retained inputs, one CPU process.')

def actual_plan():
    plan = b.read(W / 'recipe.json')
    def replace(value):
        if isinstance(value, str):
            return value.replace(str(W / 'app1'), str(A))
        if isinstance(value, list):
            return [replace(v) for v in value]
        if isinstance(value, dict):
            return {k: replace(v) for k, v in value.items()}
        return value
    plan = replace(plan)
    save(A / 'recipe.json', plan)
    return plan

def build():
    plan = actual_plan()
    for item in [*plan['common_inputs'], plan['native'], plan['runtime'], plan['fixture'], plan['fixture_body']]:
        assert b.pin(Path(item['path'])) == item, item['path']
    sources = [b.pin(p) for p in sorted(S.rglob('*')) if p.is_file()] + [b.pin(W / 'consumer.cc')]
    save(A / 'source-pins.json', sources)
    env = b.environment(plan['compile'][0])
    b.execute(plan['compile'], A / 'compile', env, 120)
    data = b.read(A / 'compile/dependencies.json')['Data']
    inputs = []
    for name in [data['Source'], *data['Includes']]:
        p = Path(name)
        if p.is_relative_to(R):
            inputs.append(b.pin(p))
        assert not p.is_relative_to(R / 'engine') and not p.is_relative_to(R / 'tests'), p
    for rel in ['engine/models/qwen35/main.cc', 'tests/tools/qwen_sampling_budget_case.h',
                'engine/inference/sampling_graph.h', 'engine/inference/request_progress.h',
                'engine/inference/request_stop_policy.h', 'engine/inference/retirement_observation.h']:
        assert any(Path(x['path']) == S / rel for x in inputs), rel
    save(A / 'compile/repository-inputs.json', inputs)
    b.execute(plan['link'], A / 'link', env, 90)
    native = Path(plan['native']['path'])
    os.link(native, A / 'link' / native.name)
    save(A / 'link/ready.json', dict(image=b.pin(A / 'link/component.exe'),
        app=b.pin(A / 'compile/unit.obj'), native=b.pin(native)))
    for item in sources:
        assert b.pin(Path(item['path'])) == item, item['path']

def run():
    plan = actual_plan()
    for item in [*b.read(A / 'link/ready.json').values(), *plan['common_inputs'], plan['fixture'], plan['fixture_body']]:
        assert b.pin(Path(item['path'])) == item, item['path']
    env = b.environment(plan['compile'][0])
    env['PATH'] = str(A / 'link') + ';' + b.read(Path(plan['runtime']['path']))['PATH']
    env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
    b.execute(plan['process_argv'], A / 'run', env, 120)
    result = json.loads((A / 'run/stdout.log').read_text().strip().splitlines()[-1])
    assert result['status'] == 'PASS'
    save(A / 'run/result.json', result)
    print(json.dumps(result))

if __name__ == '__main__':
    {'prepare': prepare, 'build': build, 'run': run, 'patch': patch}[sys.argv[1]]()
