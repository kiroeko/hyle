from pathlib import Path
import hashlib
import json
R = Path.cwd()
W = R / '.scratch/inference-turn-sampling-budget-20261025'
def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
    return dict(path=str(p.relative_to(R)).replace('\\', '/'), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
products = read(W / 'source-pins.json')['product_files']
for item in products:
    old = W / 'before' / item['path']
    current = R / item['path']
    assert old.read_bytes() == current.read_bytes() if old.exists() else not current.exists(), item['path']
for attempt in ['app1', 'app2']:
    for item in read(W / attempt / 'compile/repository-inputs.json'):
        p = Path(item['path'])
        if p == W / 'source/tests/tools/qwen_sampling_budget_case.h' and attempt == 'app1':
            p = W / 'app1/failed-source/tests/tools/qwen_sampling_budget_case.h'
        assert p.stat().st_size == item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256'], str(p)
cleanup_files = [W / 'app1/compile/unit.obj', W / 'app1/link/component.exe', W / 'app1/link/component.exp',
                 W / 'app1/link/component.lib', W / 'app1/link/hyle_ggml_cpu_pure_ffa4_current.dll']
assert all(p.is_file() for p in cleanup_files)
cleanup = dict(scope='Only first failed app1 rebuildable outputs; root may remove via test.ps1, no deletion performed',
               files=[pin(p) for p in cleanup_files], count=len(cleanup_files),
               logical_bytes=sum(p.stat().st_size for p in cleanup_files),
               retain='Success app2, all source/commands/logs/first-failure snapshot/dependencies, 129 common inputs/native originals/fixture')
(W / 'cleanup-candidates.json').write_text(json.dumps(cleanup, indent=2) + '\n')
summary = dict(status='FINITE_ACTUAL_ORDINARY_CPU_PASS', baseline_commit='b9096abc65a9c85d7cb226e874154f992cfb4f1a',
    product_files=products,
    product_scope='Model-local ordinary random turn admission and raw Text output preflight; no math, Graph, lease, retirement, precision or mutable cursor owner changes',
    interface='qwen35::preflight_generation_sampling(const Model&,const GenerationRequest&)',
    placement=['prepare_generation_call before begin_turn/bind/input', 'restore_generation_session before lookup/rebuild',
               'finite waiting owner before eviction/restore/begin/Window.admitted',
               'raw Text EmitNext advanced(1) in original full member preflight, before exact-family/StepState/carrier/input'],
    cursor_authority=['live idle head', 'otherwise committed original ledger.last.after', 'otherwise initial_sampling, never cached publisher'],
    before_begin='Read immutable current turn quota, rather than stale previous turn_output_begin; started turns use remaining_outputs. O(1), no new allocation.',
    actual_runs=[dict(attempt=a, compile=read(W / a / 'compile/process.json'), link=read(W / a / 'link/process.json'),
                     run=read(W / a / 'run/process.json')) for a in ['app1', 'app2']],
    first_failure=read(W / 'app1/first-failure.json'),
    correction='Only helper assertion changed: pending-only later turn is prefill, so inspect actual record.ids()[0], not generation-only pending_input. Product main unchanged between both actual apps.',
    runtime_result=read(W / 'app2/run/result.json'),
    source_dependencies=dict(actual='app2/compile/repository-inputs.json', no_canonical_engine_or_tests_leak=True,
        first_attempt_verified_using_preserved_failed_helper=True,
        current_headers=[pin(W / 'source' / p) for p in ['engine/inference/sampling_graph.h',
            'engine/inference/request_progress.h', 'engine/inference/request_stop_policy.h', 'engine/inference/retirement_observation.h']]),
    recipe=pin(W / 'recipe.json'), actual_recipe=pin(W / 'app2/recipe.json'), source_patch=pin(W / 'source.patch'),
    commands=['python .scratch/inference-turn-sampling-budget-20261025/check.py prepare',
              'python .scratch/inference-turn-sampling-budget-20261025/check.py build',
              'python .scratch/inference-turn-sampling-budget-20261025/check.py run',
              'python .scratch/inference-turn-sampling-budget-20261025/check.py build app2',
              'python .scratch/inference-turn-sampling-budget-20261025/check.py run app2'],
    retained_common_inputs=129, total_link_inputs=130, SDK_TUs=0, core_TUs=0, provider_TUs=0, GPU=False, HTTP=0,
    source_bridge='Formal helper compiled in actual thin driver. Full lifecycle --sampling-budget dispatch source-adapted only, no CUDA-heavy TU rebuild or CTest run.',
    scope=['Cached untrained A/H64/FFN128/V64 CPU only', 'No pretrained/GPU certification or throughput claim',
           'No MTP rerun; original MTP proof/order unchanged, greedy skips RNG bound', 'No actual native fault injection'],
    cleanup=cleanup)
(W / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(summary=pin(W / 'summary.json'), patch=pin(W / 'source.patch'),
                     products=[dict(path=p['path'], after=p['after']) for p in products],
                     cleanup_count=cleanup['count'], cleanup_bytes=cleanup['logical_bytes']), indent=2))
