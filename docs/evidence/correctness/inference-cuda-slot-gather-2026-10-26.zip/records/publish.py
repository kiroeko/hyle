"""Publish completed plain-row Gather evidence only; no native execution."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import hashlib,json,sys,xml.etree.ElementTree as ET,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def publish():
    dest=R/'docs/evidence/correctness/inference-cuda-slot-gather-2026-10-26.json';archive=dest.with_suffix('.zip')
    assert not dest.exists() and not archive.exists()
    ready=read(W/'ready2.json');plan=read(W/'plan2.json');payload={}
    for row in ready['compiled']:
        source=Path(row['source']['path']);raw=source.read_bytes()
        assert sha(raw)==row['source']['sha256'] and len(raw)==row['source']['bytes']
        payload['source/'+source.relative_to(R).as_posix()]=raw
    assert [x['source']['sha256'] for x in ready['compiled']]==[
      '21c8e824f28837b765512254f74f61a5dd2b418f1d2a11741953b6c91a1538b5',
      '663caf8eb3ba42293368b9bc75567afb1357782ab0104d93150aec0070710fed']
    names=['build.py','publish.py','plan.json','plan2.json','ready2.json','source-freeze.json',
      'link-inputs.json','runtime.json','results.xml','summary.json']
    for tag in ['compile/program','compile/test','compile2/test','link2','run1']:
        names += [tag+'/'+n for n in ('command.json','process.json','running.json','stdout.log','stderr.log')]
        if tag in ['compile/program','compile2/test']:
            names += [tag+'/dependencies.json',tag+'/actual-dependencies.json']
    for n in names:payload['records/'+n]=(W/n).read_bytes()
    assert not any(Path(n).suffix.lower() in ['.obj','.exe','.pdb','.lib','.dll','.bin'] for n in payload)
    tree=ET.parse(W/'results.xml').getroot();assert int(tree.attrib['tests'])==3 and int(tree.attrib['failures'])==0
    cases=[]
    for case in tree.iter('testcase'):
        assert case.attrib['result']=='completed' and case.find('skipped') is None
        cases.append(case.attrib)
    stages=[dict(stage=n,**read(W/n/'process.json')) for n in ['compile/program','compile/test','compile2/test','link2','run1']]
    assert [x['exit'] for x in stages]==[0,2,0,0,0]
    files=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(payload.items())]
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for n,raw in sorted(payload.items()):z.writestr(n,raw)
    with zipfile.ZipFile(archive) as z:
        assert z.namelist()==[x['path'] for x in files]
        for row in files:
            raw=z.read(row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
    assert archive.stat().st_size<2_000_000
    data=dict(schema=1,batch='inference-cuda-slot-gather-20261026',status='THREE_CASES_PASS',
      published_at=datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8))).isoformat(),
      test_started_at=tree.attrib['timestamp'],test_timestamp_timezone='Asia/Shanghai (UTC+08:00); original GTest timestamp has no offset',
      scope='Plain row Gather carrier only: same-type F32/F16/BF16 rows, padded row storage, raw-bit preservation and checked row IDs; inner-stride refusal; existing target GGUF embedding formats/bounds regression.',
      hardware=plan['hardware_readonly_observation'],source_identity=[x['source'] for x in ready['compiled']],
      image=ready['image'],process_stages=stages,test_cases=cases,tests=3,failures=0,skipped=0,
      compile_contract='Original CUDA/GGML_CUDA /O2 /W4 /WX CXX flags and pinned native header/source closure. No NVCC invocation.',
      successful_distinct_TUs=2,compile_processes=3,link_processes=1,test_processes=1,
      recipe_failure=dict(stage='compile/test',exit=2,message='fatal error C1083: cannot open include file ggml.h',
        cause='Reused bfloat test recipe did not need ggml.h, while the full tensor test TU does.',
        correction='plan2 adds only the same cached native-source/include and native-source/src external include flags from the already successful product recipe; keeps product source/object unchanged and recompiles only the failed test TU.',
        record='records/compile/test/stdout.log',product_recompiles=0,product_changes_for_failure=0,runtime_retries=0),
      reuse=dict(original_inputs=223,result_inputs=221,
        baseline=plan['baseline'],replaced_program=plan['replace_program'],reused_current_LeaseSlots_core=plan['replace_core'],
        removed_engine_objects=plan['remove'],retained='Existing ggml CUDA native objects/libraries, GPU dependencies, core Compute and GoogleTest. No archive rewrite or third-party update.',
        runtime_adaptation='Use the original runtime PATH plus the existing baseline image directory for its retained native alias; no SDK or native DLL copy.'),
      limits=['This finite result does not establish complete-model speedup, decode throughput, or task quality.',
        'Projected-read resource permission and whole-engine slot-index wiring are outside this plain row Gather check.',
        'Only the three listed cases ran on the recorded RTX 4070; no other GPU/platform matrix was run.'],
      quality_claim=False,performance_claim=False,SDK_builds=0,NVCC_builds=0,model_runs=0,HTTP=0,
      archive=dict(path=archive.relative_to(R).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),file_count=len(files),files=files))
    dest.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(summary=dict(path=str(dest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes())),
      archive={k:v for k,v in data['archive'].items() if k!='files'},published_at=data['published_at'],test_started_at=data['test_started_at'],tests=3,failures=0),ensure_ascii=False,indent=2))
if __name__=='__main__':
    if sys.argv[1:]==['publish']:publish()
    else:print(__doc__)
