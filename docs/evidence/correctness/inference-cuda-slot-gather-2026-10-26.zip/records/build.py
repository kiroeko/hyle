"""Explicit two CXX TUs and one three-case RTX4070 check; no NVCC or SDK build."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-paged-frame-20261026/engine/cuda'
spec=importlib.util.spec_from_file_location('cached_frame',R/'.scratch/inference-paged-frame-20261026/build.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);m,b=f.m,f.b
SPECS=[('program','src/compute_provider_ggml_cuda/tensor_program.cc',R/'.scratch/inference-causal-conv-20261026/compile/ggml-supports/command.json'),
 ('test','tests/compute_provider_ggml_cuda/tensor_test.cc',R/'.scratch/dense-linear-f32-20261024/test-ggml/command.json')]
EXPECTED=['21c8e824f28837b765512254f74f61a5dd2b418f1d2a11741953b6c91a1538b5','663caf8eb3ba42293368b9bc75567afb1357782ab0104d93150aec0070710fed']
OLD=R/'.scratch/inference-causal-conv-20261026/compile/ggml-supports/unit.obj'
OLDCORE=R/'.scratch/inference-storage-freeze-20261026/compile/core/unit.obj'
CORE=R/'.scratch/inference-lease-slots-20261026/compile/core/unit.obj'
REMOVE=[R/'.scratch/inference-paged-frame-20261026/engine/compile/cuda/unit.obj',
 R/'.scratch/inference-review-fixes-20261026/product2/report/unit.obj',
 R/'.scratch/inference-reusable-state-20261026/cuda2/compile/weights/unit.obj']
FILTER='GgmlCudaTensor.PlainGather*:GgmlCudaTensor.NativeEmbeddingRowsUseTargetGgufFormatsAndCheckBounds'
def plan():
    assert not (W/'plan.json').exists()
    units=[dict(name=n,source=b.pin(R/s),recipe=b.pin(recipe),command=m.command(recipe,R/s,W/'compile'/n)) for n,s,recipe in SPECS]
    for u,h in zip(units,EXPECTED):
        assert u['source']['sha256']==h
        assert '/DHYLE_COMPUTE_CUDA=1' in u['command'] and '/DHYLE_COMPUTE_GGML_CUDA=1' in u['command']
        assert all(x in u['command'] for x in ('/O2','/W4','/WX'))
        assert not any(x.startswith('/I') and b.key(R/'.scratch') in b.key(x) for x in u['command'])
    frozen=m.c.closure([u['source']['path'] for u in units],[r for _,_,r in SPECS]);b.save(W/'source-freeze.json',frozen)
    inputs=b.read(B/'link-inputs.json');assert len(inputs)==223
    for row in inputs:b.exact(row)
    for path in [OLD,OLDCORE,*REMOVE]:assert sum(b.key(x['path'])==b.key(path) for x in inputs)==1,str(path)
    for row in b.read(CORE.parent/'actual-dependencies.json'):b.exact(row)
    forced=[b.pin(x[3:]) for u in units for x in u['command'] if x.startswith('/FI')]
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(W/'source-freeze.json'),forced_headers=forced,
      baseline=dict(command=b.pin(B/'link/command.json'),inputs=b.pin(B/'link-inputs.json'),runtime=b.pin(B/'runtime.json')),
      replace_program=b.pin(OLD),replace_core=dict(before=b.pin(OLDCORE),after=b.pin(CORE),source_dependencies=b.pin(CORE.parent/'actual-dependencies.json')),
      remove=[str(p) for p in REMOVE],test_filter=FILTER,compiled_TUs=2,images=1,SDK_NVCC_Model_weight_report_builds=0,
      scope='Two new PlainGather tests and one existing GGUF embedding format/bounds test only; exact retained ggml CUDA native/dependency closure, no third-party changes.',
      hardware_readonly_observation=dict(command=['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],output='NVIDIA GeForce RTX 4070, GPU-e7376560-6f5d-ec19-6ee4-3dd3a2c81ef8, 617.14')))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['units'][0]['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def plan2():
    p=b.read(W/'plan.json');assert not (W/'plan2.json').exists()
    for row in b.read(p['source_freeze']['path']):b.exact(row)
    native=[x for x in p['units'][0]['command'] if x.startswith('/external:I') and (x.endswith('native-source\\include') or x.endswith('native-source\\src'))]
    assert len(native)==2 and Path(native[0][11:]).joinpath('ggml.h').is_file()
    u=p['units'][1];u['command']=u['command'][:1]+native+[x.replace(str(W/'compile/test'),str(W/'compile2/test')) for x in u['command'][1:]]
    p.update(previous_plan=b.pin(W/'plan.json'),status='TEST_NATIVE_INCLUDE_RECIPE_CORRECTED',
      correction='Current tensor_test includes public ggml.h unlike the old bfloat test TU. Reuse exact cached native include/src flags from the successful product recipe. Program object/source unchanged; only failed test recompiled into compile2.')
    b.save(W/'plan2.json',p);print('PLAN2',json.dumps(b.pin(W/'plan2.json')),flush=True)
def build(second=False):
    p=b.read(W/('plan2.json' if second else 'plan.json'));assert not (W/('ready2.json' if second else 'ready.json')).exists()
    if not second:assert not (W/'compile').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for row in [*frozen,*p['forced_headers']]:b.exact(row)
    for row in b.read(p['baseline']['inputs']['path']):b.exact(row)
    h,env=environment(p);objects={};results=[]
    for unit in p['units']:
        out=W/('compile2' if second and unit['name']=='test' else 'compile')/unit['name'];reused=second and unit['name']=='program'
        if reused:
            process=b.read(out/'process.json');assert process['exit']==0 and b.read(out/'command.json')['command']==unit['command']
            for row in b.read(out/'actual-dependencies.json'):b.exact(row)
        else:process=h.execute(unit['command'],env,out,timeout=180)
        dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q=Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):assert own[b.key(q)]['sha256']==row['sha256'],str(q)
        if not reused:b.save(out/'actual-dependencies.json',actual)
        objects[unit['name']]=b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json'),reused_compile=reused))
        for row in [*frozen,*p['forced_headers']]:b.exact(row)
    replace={b.key(OLD):objects['program']['path'],b.key(OLDCORE):str(CORE)};remove={b.key(x) for x in p['remove']}
    link_folder=W/('link2' if second else 'link');image=link_folder/'cuda-gather-test.exe';args=[];counts=[0,0]
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in remove:counts[1]+=1;continue
        if b.key(arg) in replace:arg=replace[b.key(arg)];counts[0]+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert counts==[2,3];args.append(objects['test']['path'])
    process=h.execute(args,env,link_folder,timeout=90)
    inputs=[b.pin(replace.get(b.key(x['path']),x['path'])) for x in b.read(p['baseline']['inputs']['path']) if b.key(x['path']) not in remove]+[objects['test']]
    assert len(inputs)==221;b.save(W/'link-inputs.json',inputs)
    rt=b.read(p['baseline']['runtime']['path']);rt['PATH']=str(B/'link')+';'+rt['PATH'];rt['adaptation']='Prepend existing baseline image directory for its retained native alias; no SDK copy/hardlink creation.';b.save(W/'runtime.json',rt)
    output=W/('ready2.json' if second else 'ready.json')
    b.save(output,dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=process,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/('plan2.json' if second else 'plan.json')),SDK_NVCC_Model_builds=0))
    print('READY',json.dumps(b.pin(output)),flush=True)
def run():
    p=b.read(W/'plan.json');ready_path=W/('ready2.json' if (W/'ready2.json').exists() else 'ready.json');ready=b.read(ready_path);b.exact(ready['image']);h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH']
    result=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+FILTER,'--gtest_output=xml:'+str(W/'results.xml')],env,W/'run1',timeout=90)
    tree=ET.parse(W/'results.xml').getroot();assert int(tree.attrib['tests'])==3 and int(tree.attrib['failures'])==0
    b.save(W/'summary.json',dict(status='THREE_CUDA_GATHER_CASES_PASS',process=result,tests=3,failures=0,ready=b.pin(ready_path),results=b.pin(W/'results.xml'),hardware=p['hardware_readonly_observation'],SDK_NVCC_Model_builds=0,scope=p['scope']))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['plan2']:plan2()
    elif sys.argv[1:]==['build2']:build(True)
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
