exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
consumer=repo/'.scratch/validation/cpu-final-f4/delivery-consumer'
for route in ('cuda','vulkan'):
    b=Path('C:/hv/m2b1-cuda' if route=='cuda' else 'C:/hv/m2vk')
    out=repo/('.scratch/validation/cpu-final-f4/mixed-'+route+'-windows')
    out.mkdir(parents=True,exist_ok=True);records=[]
    overlay=out/'source-overlay.cmake'
    overlay.write_text('function(f4_mixed_hook)\nadd_executable(f4_mixed_source "'+str((consumer/'main.cc').as_posix())+'")\ntarget_compile_features(f4_mixed_source PRIVATE cxx_std_23)\ntarget_link_libraries(f4_mixed_source PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(f4_mixed_source)\nendfunction()\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\ncmake_language(DEFER CALL f4_mixed_hook)\nendif()\n',encoding='utf-8')
    sdk_root=Path('C:/hv/cpu-final-f4-mixed-'+route);sdk_root.mkdir(exist_ok=True)
    for shape in ('static','shared'):
        prefix=sdk_root/(shape+'-staging');relocated=sdk_root/(shape+'-relocated')
        assert not prefix.exists() and not relocated.exists()
        run(shape+'-configure',['cmake','-S',repo,'-B',b,'-DHYLE_COMPONENTS=compute,graph','-U','HYLE_DEV_FACTORS',
            '-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA='+('ON' if route=='cuda' else 'OFF'),
            '-DHYLE_COMPUTE_VULKAN='+('ON' if route=='vulkan' else 'OFF'),'-DHYLE_COMPUTE_APPLE=OFF',
            '-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),
            '-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_PROJECT_INCLUDE='+str(overlay),
            '-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DHYLE_DEP_SOURCE_CACHE=C:/Users/kiro/AppData/Local/hyle/dependencies/v1'])
        run(shape+'-build',['cmake','--build',b,'--parallel','2'])
        run(shape+'-source-43-40',[b/'bin/f4_mixed_source.exe'])
        run(shape+'-install',['cmake','--install',b])
        assert prefix.resolve().parent==sdk_root.resolve() and relocated.resolve().parent==sdk_root.resolve()
        prefix.rename(relocated)
        cb=sdk_root/(shape+'-consumer')
        run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
            '-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
        run(shape+'-consumer-build',['cmake','--build',cb,'--parallel','2'])
        for name in ('torch_cpu.dll','torch.dll','c10.dll'):assert (cb/name).is_file()
        previous_path=env['PATH'];env['PATH']=os.environ['SystemRoot']+'/System32;'+os.environ['SystemRoot']
        try:run(shape+'-consumer-43-40',[cb/'cpu_final_delivery.exe'])
        finally:env['PATH']=previous_path
        if shape=='shared':run('shared-export',['python',repo/'scripts/check-shared-export-hygiene.py','--root',relocated])
