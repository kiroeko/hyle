import subprocess
from pathlib import Path

repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f4/mixed-linux';out.mkdir(exist_ok=True)
template=(repo/'.scratch/validation/cpu-final-f4/delivery-linux/resume-driver.py').read_text()
functions=template[template.index('records=json.loads'):template.index('build=root/')]
functions=functions.replace("records=json.loads((out/'receipt.json').read_text())","records=[]")
loop=template[template.index('build=root/'):]
loop=loop.replace("('static','shared')", "('shared','static')")
loop=loop.replace("'f4-'+shape", "'f4-mixed-'+shape")
loop=loop.replace("'-DHYLE_COMPUTE_CUDA=OFF'", "'-DHYLE_COMPUTE_CUDA=ON'")
prefix='''import json,pathlib,subprocess,time,os
root=pathlib.Path('/root/hyle-scratch/active-cpu-z').resolve();source=root/'source';consumer=root/'f4-consumer';overlay=root/'f4-overlay.cmake';out=root/'f4-mixed-result';out.mkdir(exist_ok=True)
assert 'hyle_stage_runtime_dependencies' in overlay.read_text()
'''
script=out/'driver.py';script.write_text(prefix+functions+loop,encoding='utf-8')
with (out/'driver.log').open('wb') as log:
    r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3',
        '/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/mixed-linux/driver.py'],
        stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/'driver.log').read_text(errors='replace')[-6500:],flush=True)
copy="from pathlib import Path; import shutil; a=Path('/root/hyle-scratch/active-cpu-z/f4-mixed-result'); b=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/mixed-linux'); [shutil.copyfile(p,b/p.name) for p in a.iterdir() if p.is_file()]"
subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',copy],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
r.check_returncode()
