import hashlib,json,shlex,subprocess
from pathlib import Path

repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f4/mixed-mac';out.mkdir(exist_ok=True)
archive=repo/'.scratch/validation/cpu-final-f4/source.tar'
# This immutable archive has the frozen a7ccfc66 product; later commits are evidence only.
sha=hashlib.sha256(archive.read_bytes()).hexdigest();candidate='64304e9e691cc78d2ead05a7c88fa485f9b8adc4'
remote='/Users/kiro/hyle-verify/cpu-final-mixed-e0388fbd'
flags={'creationflags':subprocess.CREATE_NO_WINDOW};ssh='C:/Windows/System32/OpenSSH/ssh.exe';scp='C:/Windows/System32/OpenSSH/scp.exe'
def call(args):
    r=subprocess.run(args,capture_output=True,timeout=55,**flags);r.check_returncode();return r.stdout.decode(errors='replace')+r.stderr.decode(errors='replace')
call([scp,'-q','-o','BatchMode=yes',str(archive),'kiro@172.22.10.198:'+remote+'/f4-source.tar'])
code='''import hashlib,json,pathlib,subprocess,tarfile,os
root=pathlib.Path(ROOT).resolve();source=(root/'source').resolve()
assert source.parent==root and source.is_dir() and not source.is_symlink()
ps=subprocess.check_output(['ps','-eo','pid=,args='],text=True)
assert not any(str(root) in line and any(word in line for word in ('cmake --build','ctest --test-dir','ninja -C')) for line in ps.splitlines() if line.strip().split(None,1)[0]!=str(os.getpid()))
archive=root/'f4-source.tar';assert hashlib.sha256(archive.read_bytes()).hexdigest()==SHA
updated=[];names=set()
with tarfile.open(archive) as t:
 for m in t.getmembers():
  if m.isdir():continue
  assert m.isfile();p=(source/m.name).resolve();assert p.is_relative_to(source);names.add(m.name);data=t.extractfile(m).read()
  if not p.exists() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);updated.append(m.name)
  if m.mode & 0o111:p.chmod(p.stat().st_mode|0o111)
 for folder in ('src','include','tests','cmake','third_party','scripts','samples','bench','docs'):
  for p in (source/folder).rglob('*'):
   if p.is_file() and p.relative_to(source).as_posix() not in names:assert p.resolve().is_relative_to(source);p.unlink()
result={'candidate':CANDIDATE,'archive_sha256':SHA,'updated':updated,'canonical':'Windows archive; no reverse source sync.'}
(root/'f4-sync.json').write_text(json.dumps(result,indent=2)+'\\n');(root/'f4-consumer').mkdir(exist_ok=True)
print(json.dumps({'candidate':CANDIDATE,'updated':len(updated)}))
'''.replace('ROOT',repr(remote)).replace('SHA',repr(sha)).replace('CANDIDATE',repr(candidate))
log=call([ssh,'-o','BatchMode=yes','kiro@172.22.10.198','python3 -c '+shlex.quote(code)])
(out/'sync.log').write_text(log);print(log,flush=True)
for name in ('main.cc','CMakeLists.txt'):
    call([scp,'-q','-o','BatchMode=yes',str(repo/'.scratch/validation/cpu-final-f4/delivery-consumer'/name),'kiro@172.22.10.198:'+remote+'/f4-consumer/'+name])
call([scp,'-q','-o','BatchMode=yes','kiro@172.22.10.198:'+remote+'/f4-sync.json',str(out/'sync.json')])
