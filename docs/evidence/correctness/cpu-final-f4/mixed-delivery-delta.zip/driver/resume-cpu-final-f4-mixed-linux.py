import subprocess
from pathlib import Path

repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f4/mixed-linux'
text=(out/'driver.py').read_text()
prefix=text[:text.index("for shape in ('shared','static'):")]
prefix=prefix.replace('records=[];env=',"records=json.loads((out/'receipt.json').read_text());env=")
prefix=prefix.replace("def run(name,args):", "env.update(CC='gcc-14',CXX='g++-14');env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env.pop('LD_LIBRARY_PATH',None)\ndef run(name,args):")
tail='''shape='shared';relocated=root/'f4-mixed-shared-relocated';b=root/'f4-mixed-shared-consumer'
run('shared-consumer-configure-corrected',['cmake','-S',consumer,'-B',b,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_PREFIX_PATH='+str(relocated),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('shared-consumer-build',['cmake','--build',b,'--parallel','2'])
run('shared-consumer-run',[b/'cpu_final_delivery'])
run('shared-loader',['ldd',b/'cpu_final_delivery'])
run('shared-export',['python3',source/'scripts/check-shared-export-hygiene.py','--root',relocated])
'''
loop=text[text.index("for shape in ('shared','static'):"):].replace("('shared','static')", "('static',)")
loop=loop.replace("'-DCMAKE_PREFIX_PATH='+str(relocated)","'-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH='+str(relocated)")
script=out/'resume-driver.py';script.write_text(prefix+tail+loop,encoding='utf-8')
with (out/'resume.log').open('wb') as log:
    r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/mixed-linux/resume-driver.py'],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/'resume.log').read_text(errors='replace')[-6500:],flush=True)
copy="from pathlib import Path; import shutil; a=Path('/root/hyle-scratch/active-cpu-z/f4-mixed-result'); b=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f4/mixed-linux'); [shutil.copyfile(p,b/p.name) for p in a.iterdir() if p.is_file()]"
subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',copy],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
r.check_returncode()
