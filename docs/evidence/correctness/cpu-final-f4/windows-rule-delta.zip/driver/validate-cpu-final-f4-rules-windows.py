exec(open('.scratch/cpu-ggml-isa-product-validate.py', encoding='utf-8').read().split("run('configure'")[0])
out = repo / '.scratch/validation/cpu-final-f4/rules-windows'
out.mkdir(parents=True, exist_ok=True)
records = []
env['OMP_NUM_THREADS'] = '1'
env['MKL_NUM_THREADS'] = '1'
run('configure', ['cmake', '-S', repo, '-B', build, '-DHYLE_BUILD_TESTS=ON',
                  '-DHYLE_INSTALL=OFF', '-DHYLE_BUILD_BENCH=OFF', '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build-rule-consumers', ['cmake', '--build', build, '--target',
                           'hyle_compute_route_cpu_tests', 'hyle_graph_route_cpu_tests',
                           'hyle_compute_provider_native_tests', '--parallel', '2'])
for mode, executable in [('direct', 'hyle_compute_route_cpu_test.exe'),
                         ('graph', 'hyle_graph_route_cpu_test.exe')]:
    import ctypes
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(), 4)
    run('current-rules-' + mode,
        [build / 'bin' / executable, '--gtest_filter=CpuCurrentRules.*:CpuDefaultContext.MatureDefaultsHavePolicyWithoutModelOrHardwareProfile:CpuDefaultContext.ColdFailureReleasesPartialProviderAssembly:CpuDefaultGraph.FullConstantFfnUsesQualifiedGateAcrossTwoReplays',
         '--gtest_output=xml:' + str(out / (mode + '.xml'))])
run('recipe-negative-space', ['ctest', '--test-dir', build, '--no-tests=error', '--output-on-failure',
                             '-R', '^compute_provider_native_default_rule_build_contract$', '-j', '1'])
