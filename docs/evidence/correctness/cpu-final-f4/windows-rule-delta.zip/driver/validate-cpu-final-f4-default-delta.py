exec(open('.scratch/validate-cpu-final-f4-rules-windows.py', encoding='utf-8').read().split("\nrun('configure'")[0])
records = json.loads((out / 'receipt.json').read_text(encoding='utf-8'))
run('build-final-default-delta', ['cmake', '--build', build, '--target',
                                'hyle_compute_route_cpu_tests', 'hyle_graph_route_cpu_tests',
                                'hyle_compute_provider_native_tests', '--parallel', '2'])
for mode, executable in [('direct', 'hyle_compute_route_cpu_test.exe'),
                         ('graph', 'hyle_graph_route_cpu_test.exe')]:
    run('ordinary-default-delta-' + mode,
        [build / 'bin' / executable, '--gtest_filter=CpuCurrentRules.*:CpuDefaultContext.*:CpuDefaultGraph.FullConstantFfnUsesQualifiedGateAcrossTwoReplays',
         '--gtest_output=xml:' + str(out / ('ordinary-delta-' + mode + '.xml'))])
run('native-owner-regression', ['ctest', '--test-dir', build, '--no-tests=error', '--output-on-failure',
                              '-L', '^compute_provider_native$', '-LE', 'headers', '-j', '1',
                              '--output-junit', out / 'native-owner.xml'])
