exec(open('.scratch/validate-cpu-final-f4-rules-windows.py', encoding='utf-8').read().split("\nrun('configure'")[0])
records = json.loads((out / 'receipt.json').read_text(encoding='utf-8'))
run('build-test-seam-correction', ['cmake', '--build', build, '--target',
                                 'hyle_compute_route_cpu_tests', 'hyle_graph_route_cpu_tests', '--parallel', '2'])
import ctypes
kernel = ctypes.windll.kernel32
kernel.GetCurrentProcess.restype = ctypes.c_void_p
kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
original_mask = ctypes.c_size_t()
system_mask = ctypes.c_size_t()
kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
assert kernel.GetProcessAffinityMask(kernel.GetCurrentProcess(), ctypes.byref(original_mask), ctypes.byref(system_mask))
assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(), 4)
for mode, executable in [('direct', 'hyle_compute_route_cpu_test.exe'),
                         ('graph', 'hyle_graph_route_cpu_test.exe')]:
    run('pinned-current-rules-' + mode,
        [build / 'bin' / executable, '--gtest_filter=CpuCurrentRules.*:CpuDefaultContext.MatureDefaultsHavePolicyWithoutModelOrHardwareProfile:CpuDefaultContext.ColdFailureReleasesPartialProviderAssembly:CpuDefaultGraph.FullConstantFfnUsesQualifiedGateAcrossTwoReplays',
         '--gtest_output=xml:' + str(out / ('pinned-' + mode + '.xml'))])
    import xml.etree.ElementTree as ET
    xml = ET.parse(out / ('pinned-' + mode + '.xml'))
    assert xml.find('.//property[@name="qualified_default_environment"]').get('value') == '1'
assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(), original_mask.value)
for mode, executable in [('direct', 'hyle_compute_route_cpu_test.exe'),
                         ('graph', 'hyle_graph_route_cpu_test.exe')]:
    run('unrestricted-current-rules-' + mode,
        [build / 'bin' / executable, '--gtest_filter=CpuCurrentRules.*',
         '--gtest_output=xml:' + str(out / ('unrestricted-' + mode + '.xml'))])
    xml = ET.parse(out / ('unrestricted-' + mode + '.xml'))
    assert xml.find('.//property[@name="qualified_default_environment"]').get('value') == '0'
run('recipe-negative-space', ['ctest', '--test-dir', build, '--no-tests=error', '--output-on-failure',
                             '-R', '^compute_provider_native_default_rule_build_contract$', '-j', '1'])
