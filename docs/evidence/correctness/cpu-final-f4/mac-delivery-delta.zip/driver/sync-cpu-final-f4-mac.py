import hashlib
import json
from pathlib import Path
import shlex
import subprocess

ROOT=Path.cwd()
out=ROOT/'.scratch/validation/cpu-final-f4'
archive=out/'source.tar'
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
candidate=subprocess.check_output(['git','rev-parse','64304e9e6'],text=True).strip()
remote='/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8'
ssh='C:/Windows/System32/OpenSSH/ssh.exe'
scp='C:/Windows/System32/OpenSSH/scp.exe'
flags={'creationflags':subprocess.CREATE_NO_WINDOW}
def call(args,timeout=45):
    result=subprocess.run(args,capture_output=True,timeout=timeout,**flags)
    result.check_returncode()
    return result.stdout.decode(errors='replace')+result.stderr.decode(errors='replace')
call([scp,'-q','-o','BatchMode=yes',str(archive),'kiro@172.22.10.198:'+remote+'/f4-source.tar'],timeout=55)
code='''import hashlib,json,pathlib,tarfile,subprocess,os
root=pathlib.Path(ROOT).resolve()
source=(root/'hyle-0.1.0-source').resolve()
assert source.parent==root and source.is_dir() and not source.is_symlink()
live=subprocess.check_output(['ps','-eo','pid=,args='],text=True)
assert not any(str(root) in line and any(term in line for term in ('cmake --build','ctest --test-dir','ninja -C')) for line in live.splitlines() if line.strip().split(None,1)[0]!=str(os.getpid()))
archive=root/'f4-source.tar'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==SHA
names=set();updated=[];removed=[]
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  if member.isdir():continue
  assert member.isfile(),member.name
  path=(source/member.name).resolve()
  assert path.is_relative_to(source)
  names.add(member.name)
  data=tar.extractfile(member).read()
  if not path.exists() or path.read_bytes()!=data:
   path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);updated.append(member.name)
  if member.mode & 0o111:path.chmod(path.stat().st_mode|0o111)
 for folder in ('src','include','tests','cmake','third_party','scripts','samples','bench','docs'):
  for path in (source/folder).rglob('*'):
   if path.is_file() and path.relative_to(source).as_posix() not in names:
    assert path.resolve().is_relative_to(source);path.unlink();removed.append(path.relative_to(source).as_posix())
receipt={'candidate':CANDIDATE,'archive_sha256':SHA,'bytes':archive.stat().st_size,'updated':updated,'removed':removed,'canonical':'Windows immutable archive; Mac is a disposable validation copy.'}
(root/'f4-sync.json').write_text(json.dumps(receipt,indent=2)+'\\n')
print(json.dumps({'candidate':CANDIDATE,'updated':len(updated),'removed':len(removed),'archive_bytes':archive.stat().st_size}))
'''.replace('ROOT',repr(remote)).replace('SHA',repr(sha)).replace('CANDIDATE',repr(candidate))
log=call([ssh,'-o','BatchMode=yes','kiro@172.22.10.198','python3 -c '+shlex.quote(code)],timeout=55)
(out/'mac-sync.log').write_text(log,encoding='utf-8');print(log,flush=True)
call([ssh,'-o','BatchMode=yes','kiro@172.22.10.198','mkdir -p '+shlex.quote(remote+'/f4-consumer')])
for name in ('CMakeLists.txt','main.cc'):
    call([scp,'-q','-o','BatchMode=yes',str(out/'delivery-consumer'/name),'kiro@172.22.10.198:'+remote+'/f4-consumer/'+name])
call([scp,'-q','-o','BatchMode=yes','kiro@172.22.10.198:'+remote+'/f4-sync.json',str(out/'mac-sync.json')])
