"""One test-only correction, then only the original 26 unexecuted gates."""
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path('C:/hyle-scratch/r6-vulkan-20260917')
canonical = Path('C:/public/project-hyle/hyle')
source = root / 'candidate-8e45b104'
task = root / 'selector-recovery-756d6220'
task.mkdir(exist_ok=False)
context = root / 'selected-w1-v2/context.json'
scratch_base = Path('C:/hv6')
ctypes.windll.kernel32.SetErrorMode(0x8003)
ctypes.windll.kernel32.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
assert ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.c_void_p(-1), 0x14)
assert ctypes.windll.kernel32.SetPriorityClass(ctypes.c_void_p(-1), 0x20)
os.environ.update(HYLE_DEP_SOURCE_CACHE='C:/public/project-hyle/.deps', CMAKE_BUILD_PARALLEL_LEVEL='2',
    CMAKE_GENERATOR='Ninja', CTEST_PARALLEL_LEVEL='1', CTEST_INTERACTIVE_DEBUG_MODE='0',
    VK_LOADER_LAYERS_DISABLE='~implicit~')
os.environ.pop('CMAKE_GENERATOR_PLATFORM', None)
os.environ.pop('CMAKE_GENERATOR_TOOLSET', None)
spec = importlib.util.spec_from_file_location('selector', source / 'scripts/validation-select.py')
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)


def write(name, value):
    selector.write_json(task / name, value)


def git(*args, cwd=canonical):
    return subprocess.check_output(['git', *args], cwd=cwd)


candidate = git('rev-parse', '756d6220').decode().strip()
assert git('rev-parse', 'HEAD').decode().strip() == candidate
assert not git('status', '--porcelain')
assert not git('diff', '3894b72e', candidate, '--', 'CMakeLists.txt', 'cmake', 'src',
               'include', 'third_party', 'scripts', 'samples')
assert git('diff', '--name-only', '3894b72e', candidate, '--', 'tests').decode().splitlines() == [
    'tests/sched/task_scope_test.cc']
proof = {'original_snapshot': '3894b72e3b4fbbda9457e2c31730e48bd0d43c49',
    'corrected_test_snapshot': candidate, 'shipping_projection_diff': [],
    'test_diff': ['tests/sched/task_scope_test.cc'], 'tree_identity': {},
    'public_selector_sha256': hashlib.sha256((source / 'scripts/validation-select.py').read_bytes()).hexdigest()}
for name in ('CMakeLists.txt', 'cmake', 'src', 'include', 'third_party', 'scripts', 'samples'):
    old = git('rev-parse', '3894b72e:' + name).decode().strip()
    new = git('rev-parse', candidate + ':' + name).decode().strip()
    assert old == new
    proof['tree_identity'][name] = old
write('unchanged-product.json', proof)

corrected_cache = task / 'corrected-receipts'
corrected = selector.make_plan(canonical, '2435e08d', candidate, context=context, cache=corrected_cache)
assert corrected['verdict'] == 'READY'
assert {g['id'] for g in corrected['gates'] if g['status'] == 'SELECTED'} == {
    'docs', 'closure', 'configure', 'factor:sched'}
write('corrected-plan.json', selector.public_report(corrected))
native = selector.environment_identity(context, native=True)
scratch = scratch_base / selector.digest({'tree': corrected['candidate_tree'], 'context': native})[:20]
build = scratch / ('build-' + selector.digest({'tree': corrected['candidate_tree'], 'context': native,
                                              'factors': corrected['selected_factors']})[:20])
bin_dir = build / 'bin'
bin_dir.mkdir(parents=True, exist_ok=True)
for name in ('msvcp140.dll', 'msvcp140_atomic_wait.dll', 'vcruntime140.dll', 'vcruntime140_1.dll'):
    shutil.copyfile(Path('C:/Windows/System32') / name, bin_dir / name)
write('corrected-paths.json', {'build': str(build), 'context': str(context), 'source': str(canonical)})
print('BEGIN corrected Sched selected gates', flush=True)
selector.execute(canonical, corrected, corrected_cache, scratch_base, context=context)
write('corrected-result.json', selector.public_report(corrected))
assert corrected['verdict'] == 'PASS', 'Corrected selected gate failed; no retry authorized'
exe = bin_dir / 'hyle_sched_test.exe'
assert exe.is_file()
command = [str(exe), '--gtest_filter=TaskScope.AggregatesFirstStatusFailureAndStillDrains',
           '--gtest_repeat=32']
with (task / 'corrected-repeat.log').open('wb') as stream:
    repeated = subprocess.run(command, cwd=canonical, stdout=stream, stderr=subprocess.STDOUT)
output = (task / 'corrected-repeat.log').read_text(encoding='utf-8')
passes = len(re.findall(r'\[\s+PASSED\s+\]\s+1 test\.', output))
write('corrected-repeat.json', {'command': command, 'exit_code': repeated.returncode,
    'passed_iterations': passes, 'expected_iterations': 32,
    'executable_sha256': hashlib.sha256(exe.read_bytes()).hexdigest(),
    'log_sha256': hashlib.sha256((task / 'corrected-repeat.log').read_bytes()).hexdigest()})
assert repeated.returncode == 0 and passes == 32
print('PASS corrected Sched and 32 ordered-case repetitions', flush=True)

parent = json.loads((root / 'selected-final-windows/result.json').read_text(encoding='utf-8'))
assert parent['verdict'] == 'BLOCKED'
pending = {g['id'] for g in parent['selected_gates'] if g['status'] == 'BLOCKED'}
assert len(pending) == 26 and 'factor:sched' not in pending
assert [g['id'] for g in parent['selected_gates'] if g['status'] == 'FAIL'] == ['factor:sched']
original_cache = root / 'selected-final-windows/receipts'
remaining = selector.make_plan(source, 'a767bdc4', '3894b72e', context=context, cache=original_cache)
assert remaining['verdict'] == 'READY'
original_by_id = {g['id']: g for g in parent['selected_gates']}
for gate in remaining['gates']:
    if gate['id'] in original_by_id:
        assert gate['identity'] == original_by_id[gate['id']]['identity'], gate['id']
remaining['gates'] = [g for g in remaining['gates'] if g['id'] in pending]
assert len(remaining['gates']) == 26 and all(g['status'] == 'SELECTED' for g in remaining['gates'])
remaining['execution_scope'] = {
    'kind': 'ONLY_PREVIOUSLY_UNEXECUTED_GATES', 'count': 26,
    'parent_result': str(root / 'selected-final-windows/result.json'),
    'parent_result_sha256': hashlib.sha256((root / 'selected-final-windows/result.json').read_bytes()).hexdigest(),
    'excluded_original_pass_gates': 84,
    'original_failure': 'factor:sched, retained FAIL; corrected test snapshot is separately validated',
    'corrected_test_snapshot': candidate,
    'not_a_full_selector_pass': True}
original_paths = json.loads((root / 'selected-final-windows/paths.json').read_text(encoding='utf-8'))
same_scratch = scratch_base / selector.digest({'tree': remaining['candidate_tree'], 'context': native})[:20]
assert same_scratch.resolve() == Path(original_paths['scratch']).resolve()
for gate in remaining['gates']:
    for command in gate['commands']:
        for token in command:
            if token.startswith('-DHYLE_SMOKE_ROOT='):
                target = Path(token.split('=', 1)[1].replace('{scratch}', str(same_scratch))).resolve()
                target.relative_to(scratch_base.resolve())
                assert target != scratch_base.resolve()
write('remaining-plan.json', selector.public_report(remaining))
print('BEGIN original 26 unexecuted gates, same original product/test snapshot; no passed-gate rerun', flush=True)
selector.execute(source, remaining, original_cache, scratch_base, context=context)
write('remaining-result.json', selector.public_report(remaining))
print('END remaining subset:', remaining['verdict'], flush=True)
sys.exit(0 if remaining['verdict'] == 'PASS' else 2)
