"""Archive honest R6 gate coverage, retaining the original failed test receipt."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root = Path('C:/hyle-scratch/r6-vulkan-20260917')
repo = Path('C:/public/project-hyle/hyle')
original = root / 'selected-final-windows'
recovery = root / 'selector-recovery-756d6220'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parent = read(original / 'result.json')
remaining = read(recovery / 'remaining-result.json')
corrected = read(recovery / 'corrected-result.json')
repeat = read(recovery / 'corrected-repeat.json')
proof = read(recovery / 'unchanged-product.json')
assert parent['verdict'] == 'BLOCKED'
assert Counter(g['status'] for g in parent['selected_gates']) == {'PASS': 84, 'FAIL': 1, 'BLOCKED': 26}
assert remaining['verdict'] == 'PASS' and corrected['verdict'] == 'PASS'
assert len(remaining['selected_gates']) == 26 and all(g['status'] == 'PASS' for g in remaining['selected_gates'])
assert {g['id'] for g in remaining['selected_gates']} == {
    g['id'] for g in parent['selected_gates'] if g['status'] == 'BLOCKED'}
assert len(corrected['selected_gates']) == 4 and all(g['status'] == 'PASS' for g in corrected['selected_gates'])
assert repeat['exit_code'] == 0 and repeat['passed_iterations'] == 32
assert sha(recovery / 'corrected-repeat.log') == repeat['log_sha256']
assert not proof['shipping_projection_diff']
assert proof['test_diff'] == ['tests/sched/task_scope_test.cc']
assert corrected['candidate_commit'] == proof['corrected_test_snapshot']
assert remaining['candidate_commit'] == parent['candidate_commit'] == proof['original_snapshot']
assert remaining['candidate_tree'] == parent['candidate_tree']

files = {}
for prefix, path, names in (
    ('original', original, ('plan.json', 'result.json', 'paths.json')),
    ('recovery', recovery, ('corrected-plan.json', 'corrected-result.json', 'corrected-paths.json',
        'corrected-repeat.json', 'corrected-repeat.log', 'corrected-full-sched.log', 'remaining-plan.json', 'remaining-result.json',
        'unchanged-product.json'))):
    for name in names:
        files[prefix + '/' + name] = path / name
files['controller/original.log'] = root / 'remaining-acceptance-93c228da/windows-final-selector.log'
files['controller/recovery.log'] = root / 'selector-recovery-756d6220.log'
for name in ('run-selected-windows.py', 'run-r6-selector-recovery.py', 'run-r6-selector-recovery.ps1',
             'archive-final-selector-coverage.py'):
    files['controller/' + name] = root / name
files['context.json'] = root / 'selected-w1-v2/context.json'


def retain(gate, prefix, candidate):
    p = Path(gate['receipt'])
    receipt = read(p)
    assert receipt['verdict'] == gate['status']
    assert receipt['candidate_commit'] == candidate
    assert receipt['identity'] == gate['identity']
    files[prefix + '/' + p.name] = p
    for log in receipt['logs']:
        path = p.parent / log['path']
        assert sha(path) == log['sha256']
        files[prefix + '/' + log['path'].replace('\\', '/')] = path
    return {'receipt': prefix + '/' + p.name, 'sha256': sha(p), 'snapshot': candidate}


coverage = {}
original_by_id = {g['id']: g for g in parent['selected_gates']}
for gate in parent['selected_gates']:
    if gate['status'] in ('PASS', 'FAIL'):
        evidence = retain(gate, 'original-receipts', parent['candidate_commit'])
        if gate['status'] == 'PASS':
            coverage[gate['id']] = dict(id=gate['id'], verdict='PASS', basis='ORIGINAL_PASS', **evidence)
for gate in remaining['selected_gates']:
    assert gate['identity'] == original_by_id[gate['id']]['identity']
    evidence = retain(gate, 'continuation-receipts', remaining['candidate_commit'])
    coverage[gate['id']] = dict(id=gate['id'], verdict='PASS', basis='ORIGINAL_SNAPSHOT_CONTINUATION', **evidence)
for gate in corrected['selected_gates']:
    evidence = retain(gate, 'corrected-test-receipts', corrected['candidate_commit'])
    if gate['id'] == 'factor:sched':
        old = original_by_id[gate['id']]
        assert old['status'] == 'FAIL'
        for key in ('toolchain', 'machine_profile', 'observed_host'):
            assert old['identity'][key] == gate['identity'][key]
        log = (recovery / 'corrected-full-sched.log').read_text(encoding='utf-8', errors='replace')
        assert re.search(r'\[==========\] 251 tests from', log)
        assert re.search(r'\[\s+PASSED\s+\] 251 tests\.', log)
        coverage[gate['id']] = dict(id=gate['id'], verdict='PASS', basis='CORRECTED_TEST_SAME_PRODUCT',
            original_verdict='FAIL', original_receipt_retained=True, test_count=251,
            targeted_repetitions=32, **evidence)
assert set(coverage) == set(original_by_id) and len(coverage) == 111
assert not any(g == 'p1' or g.startswith('p1:') for g in coverage)
for projection, oid in proof['tree_identity'].items():
    actual = subprocess.check_output(['git', 'rev-parse', corrected['candidate_commit'] + ':' + projection],
                                     cwd=repo, text=True).strip()
    assert actual == oid

# Confirm the actual three ordinary consumers inside each retained delivery log.
delivery_journeys = []
for gate in remaining['selected_gates']:
    if not gate['id'].startswith('delivery:'):
        continue
    product_name = gate['id'].split(':', 1)[1]
    receipt_path = Path(gate['receipt'])
    receipt = read(receipt_path)
    logs = [(receipt_path.parent / item['path']).read_text(encoding='utf-8', errors='replace')
            for item in receipt['logs']]
    transcript = '\n'.join(logs)
    projects = re.findall(r'^Test project (.+)$', transcript, re.MULTILINE)
    modes = ('source-build', 'shared-consumer', 'static-consumer')
    assert len(projects) == 3, (gate['id'], projects)
    assert all(sum(path.rstrip().replace('\\', '/').endswith('/' + mode)
                   for path in projects) == 1 for mode in modes), (gate['id'], projects)
    passed = [int(value) for value in re.findall(r'100% tests passed[^\n]*out of (\d+)', transcript)]
    assert len(passed) == 3 and all(value > 0 for value in passed), (gate['id'], passed)
    marker = 'HYLE selected product smoke passed: ' + product_name + ' (source, shared, static, relocated consumers)'
    assert marker in transcript, gate['id']
    delivery_journeys.append(dict(id=gate['id'], consumer_modes=list(modes),
        tests_passed_by_journey=passed, relocated_consumer_marker=True,
        receipt=coverage[gate['id']]['receipt']))
assert len(delivery_journeys) == 15

entries = {name: {'sha256': sha(path), 'bytes': path.stat().st_size}
           for name, path in sorted(files.items())}
output = root / 'archive-final-selector-coverage'
output.mkdir(exist_ok=False)
with zipfile.ZipFile(output / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.writestr('archive-manifest.json', json.dumps(entries, indent=2) + '\n')
with zipfile.ZipFile(output / 'raw.zip') as z:
    for name, item in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == item['sha256']
identity = {'product_candidate': '8e45b10423686a0753aaa9d461c4ef3b117412c5',
    'coverage_verdict': 'PASS', 'selected_gate_count': 111,
    'original_selector_verdict': 'BLOCKED', 'original_snapshot': parent['candidate_commit'],
    'corrected_test_snapshot': corrected['candidate_commit'],
    'basis_counts': dict(Counter(g['basis'] for g in coverage.values())),
    'gate_coverage': [coverage[g['id']] for g in parent['selected_gates']],
    'original_skipped_gates': parent['skipped_gates'],
    'delivery_journeys': delivery_journeys,
    'receipt_identity_and_log_integrity': 'PASS', 'p1_run': False,
    'archive': {'file': 'raw.zip', 'sha256': sha(output / 'raw.zip'), 'entries': len(entries),
                'per_entry_integrity': 'PASS'}}
(output / 'identity.json').write_bytes((json.dumps(identity, indent=2) + '\n').encode())
print(json.dumps({k:v for k,v in identity.items() if k not in ('gate_coverage', 'original_skipped_gates')}, indent=2))
