$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:PATH = 'C:/public/tools/glslang;' + $env:PATH
python C:/hyle-scratch/r6-vulkan-20260917/run-r6-selector-recovery.py *> C:/hyle-scratch/r6-vulkan-20260917/selector-recovery-756d6220.log
exit $LASTEXITCODE
