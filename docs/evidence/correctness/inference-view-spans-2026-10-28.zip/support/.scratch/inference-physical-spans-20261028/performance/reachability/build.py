"""Temporary physical-span reachability: 1 CXX, 1 link, 2 explicit runs.

All actions are root-only. This image's timings are diagnostic and unusable as
performance measurements. Product sources, fixtures and original runs stay intact.
"""
from pathlib import Path
import copy
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
PARENT = W.parent
R = Path(r'C:\public\project-hyle\hyle')
spec = importlib.util.spec_from_file_location('reachability_retained_screen', PARENT / 'build.py')
s = importlib.util.module_from_spec(spec); spec.loader.exec_module(s)
t = s.t; t.W = W
SOURCE = W / 'executable-reachability.cc'
ORIGINAL = R / 'src/graph/executable.cc'
SDK_RECEIPT = PARENT.parent / 'validation/refinement/compile/executable/compiled.json'


def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve every prepared plan'
    ready = t.read(PARENT / 'ready-candidate.json')
    assert ready['process']['exit'] == 0
    for key in ('image', 'inputs', 'recipe', 'runtime'): t.exact(ready[key])
    unit = t.read(SDK_RECEIPT); assert unit['process']['exit'] == 0 and not unit['process']['timed_out']
    t.exact(unit['object']); t.exact(unit['source'])
    manifest = t.read(W / 'diagnostic-source.json')
    for key in ('original', 'diagnostic', 'patch'): t.exact(manifest[key])
    assert manifest['original'] == t.pin(ORIGINAL) and manifest['diagnostic'] == t.pin(SOURCE)
    old_recipe = t.read(unit['command']['path']); command = []
    for arg in old_recipe['command']:
        if t.key(arg) == t.key(ORIGINAL): arg = str(SOURCE)
        elif arg.upper().startswith('/FO'): arg = '/Fo' + str(W / 'compile/unit.obj')
        elif arg.upper().startswith('/FD'): arg = '/Fd' + str(W / 'compile/unit.pdb')
        command.append(arg)
    index = command.index('/sourceDependencies'); command[index + 1] = str(W / 'compile/dependencies.json')
    include = '/I' + str(R / 'src/graph')
    if include not in command: command.insert(1, include)
    current, changed = [], []
    for previous in t.read(unit['actual_dependencies']['path']):
        if t.project(previous['path']) and t.key(previous['path']) != t.key(ORIGINAL):
            row = t.pin(previous['path']); current.append(row)
            if row != previous: changed.append(dict(previous=previous, current=row))
    current.append(t.pin(SOURCE))
    original_inputs = t.read(ready['inputs']['path']); assert len(original_inputs) == 229
    assert original_inputs[47] == unit['object']
    assert sum(row == unit['object'] for row in original_inputs) == 1
    stats = []
    for row in original_inputs:
        stat = Path(row['path']).stat()
        stats.append(dict(path=row['path'], bytes=stat.st_size, mtime_ns=stat.st_mtime_ns,
                          retained_sha256=row['sha256']))
        assert stat.st_size == row['bytes']
    link = t.read(ready['recipe']['path'])['command']; replacement = []
    for arg in link:
        if t.key(arg) == t.key(unit['object']['path']): arg = str(W / 'compile/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/hyle-span-reachability').with_suffix(suffix)); break
        replacement.append(arg)
    environment = t.read(PARENT / 'environment.json'); runtime = t.read(ready['runtime']['path'])
    runtime['PATH'] = str(W / 'bin') + ';' + runtime['PATH']
    t.save(W / 'environment.json', environment); t.save(W / 'runtime.json', runtime)
    t.save(W / 'compile-recipe.json', dict(command=command, timeout_seconds=300))
    t.save(W / 'link-recipe.json', dict(command=replacement, timeout_seconds=240))
    t.save(W / 'project-dependencies.json', current); t.save(W / 'retained-input-stats.json', stats)
    frozen = dict(helper=t.pin(__file__), original_screen_helper=t.pin(PARENT / 'build.py'),
        original=t.pin(ORIGINAL), diagnostic=t.pin(SOURCE), diagnostic_manifest=t.pin(W / 'diagnostic-source.json'),
        retained_ready=t.pin(PARENT / 'ready-candidate.json'), original_unit=t.pin(SDK_RECEIPT),
        current_project_dependencies=t.pin(W / 'project-dependencies.json'),
        project_dependency_changes_since_sdk_compile=changed,
        scope='Only executable.cc is instrumented. Same updated resources and all 228 other inputs, including retained 4ca9 Model ff22. No diagnostic TPS claim.')
    t.save(W / 'source-freeze.json', frozen)
    t.save(W / 'plan.json', dict(status='PREPARED_NOT_RUN', frozen=t.pin(W / 'source-freeze.json'),
        compile=t.pin(W / 'compile-recipe.json'), link=t.pin(W / 'link-recipe.json'),
        original_inputs=ready['inputs'], retained=t.pin(W / 'retained-input-stats.json'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        counts=dict(CXX=1, NVCC=0, links=1, inputs=229, model_runs=2), performance_claim=False))
    print('PREPARED only: root may inspect current project dependency changes before compile')


def validate():
    plan = t.read(W / 'plan.json')
    for key in ('frozen', 'compile', 'link', 'original_inputs', 'retained', 'environment', 'runtime'): t.exact(plan[key])
    frozen = t.read(plan['frozen']['path'])
    for key in ('helper', 'original_screen_helper', 'original', 'diagnostic', 'diagnostic_manifest',
                'retained_ready', 'original_unit', 'current_project_dependencies'): t.exact(frozen[key])
    for row in t.read(frozen['current_project_dependencies']['path']): t.exact(row)
    for row in t.read(plan['retained']['path']):
        stat = Path(row['path']).stat()
        assert (stat.st_size, stat.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    return plan, frozen


def parse_compile():
    plan, frozen = validate(); process = t.read(W / 'logs/compile/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    allowed = {t.key(row['path']): row for row in t.read(frozen['current_project_dependencies']['path'])}
    actual = []
    for path in dict.fromkeys(t.dep_paths(W / 'compile/dependencies.json')):
        row = t.pin(path)
        if t.project(path) or t.key(path) == t.key(SOURCE):
            assert allowed[t.key(row['path'])] == row, ('Parser metadata error: never recompile successful CXX', row)
        actual.append(row)
    s.keep(W / 'compile/actual-dependencies.json', actual)
    s.keep(W / 'compile/compiled.json', dict(source=frozen['original'], snapshot=frozen['diagnostic'],
        object=t.pin(W / 'compile/unit.obj'), process=process, command=t.pin(W / 'logs/compile/command.json'),
        dependencies=t.pin(W / 'compile/dependencies.json'), actual_dependencies=t.pin(W / 'compile/actual-dependencies.json')))
    print('COMPILE METADATA READY')


def compile_unit():
    plan, _ = validate(); (W / 'compile').mkdir(exist_ok=False)
    t.execute(t.command(plan['compile']['path']), W / 'logs/compile', 300); parse_compile()


def parse_link():
    plan, frozen = validate(); process = t.read(W / 'link/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    assert t.command(W / 'link/command.json') == t.command(plan['link']['path'])
    s.keep(W / 'ready.json', dict(image=t.pin(W / 'bin/hyle-span-reachability.exe'),
        inputs=t.pin(W / 'inputs.json'), process=process, compiled=t.read(W / 'compile/compiled.json'),
        recipe=t.pin(W / 'link/command.json'), runtime=plan['runtime'], source_freeze=plan['frozen'],
        performance_claim=False, scope=frozen['scope']))
    print('DIAGNOSTIC LINK READY')


def link():
    plan, _ = validate(); compiled = t.read(W / 'compile/compiled.json'); t.exact(compiled['object'])
    inputs = t.read(plan['original_inputs']['path']); inputs[47] = compiled['object']
    assert len(inputs) == 229 and sum(a != c for a, c in zip(inputs, t.read(plan['original_inputs']['path']))) == 1
    t.save(W / 'inputs.json', inputs); (W / 'bin').mkdir(exist_ok=True)
    native = t.read(plan['runtime']['path'])['native']; alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    t.execute(t.command(plan['link']['path']), W / 'link', 240); parse_link()


def prepare_runs():
    plan, _ = validate(); ready = t.read(W / 'ready.json'); t.exact(ready['image'])
    groups = []
    for ordinal, role in enumerate(('ordinary', 'mtp'), 1):
        cfg = copy.deepcopy(t.read(PARENT / ('single-' + role + '-plan.json')))
        original = next(row for row in cfg['commands'] if row['variant'] == 'candidate')
        expected = Path(original['folder']) / 'consumer-result.json'
        assert t.read(Path(original['folder']) / 'result.json')['exit'] == 0
        entry = dict(original, ordinal=1, window_ordinal=ordinal, variant='diagnostic',
            folder=str(W / 'runs' / role), command=[ready['image']['path'], *original['command'][1:]],
            image=ready['image'], environment=plan['runtime'], ready=t.pin(W / 'ready.json'))
        cfg.update(commands=[entry], arm_order=['diagnostic'], timing_processes=0, memory_processes=0,
            diagnostic_processes=1, performance_claim=False, binding=t.pin(W / 'source-freeze.json'))
        path = W / (role + '-plan.json'); t.save(path, cfg)
        groups.append(dict(role=role, plan=t.pin(path), expected_full_report=t.pin(expected)))
    t.save(W / 'run-plan.json', dict(helper=t.pin(__file__), groups=groups,
        diagnostic_processes=2, performance_claim=False, original_screen_summary=t.pin(PARENT / 'summary.json')))
    print('TWO DIAGNOSTIC RUNS PREPARED; no native run started')


def run_config(role):
    assert role in ('ordinary', 'mtp'); plan = t.read(W / 'run-plan.json'); t.exact(plan['helper'])
    group = next(row for row in plan['groups'] if row['role'] == role)
    t.exact(group['plan']); t.exact(group['expected_full_report'])
    return t.read(group['plan']['path']), group


def analyze(role):
    cfg, group = run_config(role); entry = cfg['commands'][0]
    s.n.parse_one(entry, cfg)  # Original complete producer/partition/acceptance parser.
    folder = Path(entry['folder']); report = t.read(folder / 'consumer-result.json')
    actual = s.f.facts_parser.non_time(report)
    expected = s.f.facts_parser.non_time(t.read(group['expected_full_report']['path']))
    differences = s.f.differences(expected, actual)
    marker = 'HYLE_PHYSICAL_SPAN_REACHABILITY '
    rows = [line[len(marker):] for line in (folder / 'stderr.log').read_text(encoding='utf-8', errors='strict').splitlines()
            if line.startswith(marker)]
    assert len(rows) == 1, ('Expected one orderly process-tail counter report', len(rows))
    counts = json.loads(rows[0]); assert counts['schema'] == 1 and counts['capacity'] == 64
    assert len(counts['plans']) <= 64
    assert [row['ordinal'] for row in counts['plans']] == list(range(1, len(counts['plans']) + 1))
    for row in [counts['totals'], counts['overflow'], *(p['counts'] for p in counts['plans'])]:
        assert row['decisions'] == row['reused'] + row['full']
        assert 0 <= row['full_input_sources'] <= row['full']
    for key, value in counts['totals'].items():
        assert sum(p['counts'][key] for p in counts['plans']) + counts['overflow'][key] == value
    value = dict(status='PASS_DIAGNOSTIC_FACTS' if not differences else 'PRESERVED_FACT_DIFFERENCES',
        role=role, counts=counts, full_non_time_differences=differences,
        expected=group['expected_full_report'], process=t.pin(folder / 'result.json'),
        actual_work=s.n.work_facts(report, role), performance_claim=False,
        limits=['Only two single-turn finite diagnostics, retained Model ff22.',
                'Counts only the existing reuse_spans decision after completeness checks; early prepared seals and incomplete configurations excluded.',
                'Counters keyed by actual PlanState pointer, metadata copied on first observation; overflow calls retained separately.',
                'Diagnostic TPS is invalid and excluded from conclusions.'])
    s.b.save(folder / 'analysis.json', value)
    assert not differences, 'No model reruns or fact whitelist'
    print(json.dumps(dict(role=role, counts=counts, full_non_time_equal=True, performance_claim=False)))


def run(role):
    cfg, _ = run_config(role); entry = cfg['commands'][0]
    t.exact(entry['ready']); t.exact(entry['environment'])
    env = os.environ.copy(); env['PATH'] = t.read(entry['environment']['path'])['PATH']
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
    s.b.load_helpers().execute(Path(entry['folder']), entry['arm'], entry['command'], env, False)
    analyze(role)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': compile_unit()
    elif action == 'parse-compile': parse_compile()
    elif action == 'link': link()
    elif action == 'parse-link': parse_link()
    elif action == 'prepare-runs': prepare_runs()
    elif action == 'run': run(sys.argv[2])
    elif action == 'analyze': analyze(sys.argv[2])
    else: raise SystemExit('prepare | compile | parse-compile | link | parse-link | prepare-runs | run/analyze ordinary|mtp')
