"""Isolate two Graph objects in the retained 4ca9 CLI; root executes actions.

prepare/window-prepare/analyze/summary are metadata-only. link is one native
linker process; run is four fresh model processes. No compile or download path.
"""
from pathlib import Path
import copy
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
CONTROL = R / '.scratch/inference-small-projection-20261028/model-candidate/attempt2'
OLD = R / '.scratch/inference-program-io-window-20261028'
SDK = W.parent / 'validation'
STAGES = (('single', 'ordinary'), ('single', 'mtp'), ('two-turn', 'ordinary'), ('two-turn', 'mtp'))
ORDER = ('control', 'candidate', 'candidate', 'control')
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second',
           'session_output_tokens_per_second', 'session_processed_tokens_per_second')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


DRIVER = R / '.scratch/inference-indexed-store-20261028/build.py'
t = module('physical_screen_build_driver', DRIVER); t.W = W
n = module('physical_screen_retained_window', CONTROL / 'window/window.py')
f, b = n.f, n.b


def keep(path, value):
    if Path(path).exists():
        assert t.read(path) == value, ('Preserve prior metadata', str(path))
    else:
        t.save(path, value)


def prepare():
    assert not (W / 'build-plan.json').exists(), 'Preserve the original plan'
    ready_path = CONTROL / 'ready-control.json'; ready = t.read(ready_path)
    assert ready['process']['exit'] == ready['compiled']['process']['exit'] == 0
    for name in ('image', 'inputs', 'recipe', 'source_freeze', 'runtime'):
        t.exact(ready[name])
    assert ready['image']['sha256'] == '0c6227e048997fbf9f830153664371558b40bf2fc011ff587772a525cf4b76d9'
    assert ready['compiled']['object']['sha256'] == 'ff22d11a294a5aa507034b09efeb475b1aedd514f473b974c970436f24f51e52'
    original = t.read(ready['inputs']['path']); assert len(original) == 229
    statistics = {t.key(row['path']): row for row in t.read(CONTROL / 'retained-input-stats.json')}
    retained = []
    for row in original:
        known = statistics[t.key(row['path'])]; stat = Path(row['path']).stat()
        assert (known['bytes'], known['retained_sha256']) == (row['bytes'], row['sha256'])
        assert (stat.st_size, stat.st_mtime_ns) == (known['bytes'], known['mtime_ns']), row['path']
        retained.append(known)
    receipt_paths = {'resources': SDK / 'compile/resources/compiled.json',
                    'executable': SDK / 'refinement/compile/executable/compiled.json'}
    indices = {'resources': 52, 'executable': 47}
    receipts, changes = {}, []
    candidate = list(original)
    for name, path in receipt_paths.items():
        receipt = t.read(path)
        assert receipt['process']['exit'] == 0 and not receipt['process']['timed_out']
        for field in ('source', 'object', 'command', 'dependencies', 'actual_dependencies'):
            t.exact(receipt[field])
        old_path = (R / '.scratch/inference-store-cohort-20261028/compile/resources/compiled.json'
                    if name == 'resources' else
                    R / '.scratch/inference-identical-capture-inputs-20261027/compile/executable/compiled.json')
        old = t.read(old_path); index = indices[name]
        assert original[index] == old['object']
        before = R / '.scratch/inference-fixed-projection-spans-20261028/product' / (name + '-before.cc')
        assert t.pin(before)['sha256'] == old['source']['sha256']
        assert sum(t.key(row['path']) == t.key(old['object']['path']) for row in original) == 1
        candidate[index] = receipt['object']
        receipts[name] = dict(receipt=t.pin(path), compiled=receipt, prior_receipt=t.pin(old_path), prior_source=old['source'])
        changes.append(dict(name=name, index=index, original=old['object'], replacement=receipt['object']))
    assert sum(a != c for a, c in zip(original, candidate)) == 2
    assert len({t.key(row['path']) for row in candidate}) == 229
    replacement = {t.key(row['original']['path']): row['replacement']['path'] for row in changes}
    recipe = t.read(ready['recipe']['path']); command = []
    for arg in recipe['command']:
        arg = replacement.get(t.key(arg), arg)
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/hyle-physical-spans').with_suffix(suffix)); break
        command.append(arg)
    for row in candidate:
        assert sum(t.key(arg) == t.key(row['path']) for arg in command) == 1, row['path']
    environment = t.read(SDK / 'environment.json')
    runtime = t.read(ready['runtime']['path'])
    runtime['PATH'] = str(W / 'bin') + ';' + runtime['PATH']
    t.exact(runtime['native'])
    t.save(W / 'environment.json', environment); t.save(W / 'runtime.json', runtime)
    t.save(W / 'inputs-candidate.json', candidate); t.save(W / 'retained-input-stats.json', retained)
    t.save(W / 'link-recipe.json', dict(command=command, timeout_seconds=240))
    frozen = dict(helper=t.pin(__file__), driver=t.pin(DRIVER), control_ready=t.pin(ready_path),
                  control=ready, sdk=receipts, replacements=changes,
                  scope='Retained 4ca9 Model/CLI, not current b1b whole engine. Exactly two Graph SDK objects differ; all 227 other inputs including Model ff22 remain unchanged.')
    t.save(W / 'source-freeze.json', frozen)
    t.save(W / 'build-plan.json', dict(status='PREPARED_ONE_LINK_NOT_RUN', frozen=t.pin(W / 'source-freeze.json'),
        inputs=t.pin(W / 'inputs-candidate.json'), retained=t.pin(W / 'retained-input-stats.json'),
        recipe=t.pin(W / 'link-recipe.json'), environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        counts=dict(CXX=0, NVCC=0, links=1, inputs_each=229, replaced_sdk_objects=2)))
    print('PREPARED metadata only: one link, zero CXX/NVCC, isolated two-object Graph change')


def validate():
    plan = t.read(W / 'build-plan.json')
    for key in ('frozen', 'inputs', 'retained', 'recipe', 'environment', 'runtime'):
        t.exact(plan[key])
    frozen = t.read(plan['frozen']['path'])
    for key in ('helper', 'driver', 'control_ready'): t.exact(frozen[key])
    for unit in frozen['sdk'].values():
        t.exact(unit['receipt']); t.exact(unit['compiled']['object'])
    for row in t.read(plan['retained']['path']):
        stat = Path(row['path']).stat()
        assert (stat.st_size, stat.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    return plan, frozen


def record_link():
    plan, frozen = validate(); process = t.read(W / 'link/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    assert t.command(W / 'link/command.json') == t.command(plan['recipe']['path'])
    ready = dict(image=t.pin(W / 'bin/hyle-physical-spans.exe'), inputs=plan['inputs'],
        process=process, recipe=t.pin(W / 'link/command.json'), runtime=plan['runtime'],
        source_freeze=plan['frozen'], compiled=frozen['control']['compiled'], sdk=frozen['sdk'],
        closure_inputs=229, role='candidate', scope=frozen['scope'])
    keep(W / 'ready-candidate.json', ready)
    keep(W / 'ready-control.json', dict(frozen['control'], runtime=plan['runtime']))
    print('LINK READY: only resources/executable changed, retained Model ff22')


def link():
    plan, _ = validate(); (W / 'bin').mkdir(exist_ok=True)
    native = t.read(plan['runtime']['path'])['native']; alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    t.execute(t.command(plan['recipe']['path']), W / 'link', 240)
    record_link()


def window_prepare():
    validate(); versions = {v: t.read(W / ('ready-' + v + '.json')) for v in ('control', 'candidate')}
    for ready in versions.values():
        assert ready['process']['exit'] == 0
        for key in ('image', 'inputs', 'runtime'): t.exact(ready[key])
    assert versions['control']['runtime'] == versions['candidate']['runtime']
    old = t.read(OLD / 'binding.json'); work = {key: old[key] for key in ('prompt', 'input_manifest', 'schedule')}
    for row in work.values(): t.exact(row)
    binding = dict(versions={v: dict(ready=t.pin(W / ('ready-' + v + '.json')), **versions[v]) for v in versions},
        work=work, runtime=versions['control']['runtime'], build_plan=t.pin(W / 'build-plan.json'),
        protocol=t.pin(OLD / 'window.py'), retained_n32_window=t.pin(CONTROL / 'window/window.py'),
        scope='Fresh 16-process timing screen of two Graph objects in the retained 4ca9 CLI. No current-engine or historical-sample claim.')
    t.save(W / 'binding.json', binding); plans = []; ordinal = 0
    for scenario, role in STAGES:
        original = t.read(OLD / (scenario + '-timing-plan.json'))
        arm = 'hyle_auto' if role == 'ordinary' else 'hyle_mtp'
        template = next(row for row in original['commands'] if row['arm'] == arm)
        assert '--trace' not in template['command'] and '--probe' not in template['command']
        cfg = copy.deepcopy(original)
        for key in ('canonical_main', 'configuration', 'retained_plan'): cfg.pop(key, None)
        commands = []
        for local, variant in enumerate(ORDER, 1):
            ordinal += 1; version = binding['versions'][variant]
            commands.append(dict(ordinal=local, window_ordinal=ordinal, variant=variant, scenario=scenario, role=role,
                arm=arm, folder=str(W / 'runs' / (scenario + '-' + role) / (f'{local:02d}-' + variant)),
                command=[version['image']['path'], *template['command'][1:]], image=version['image'],
                environment=binding['runtime'], ready=version['ready']))
        cfg.update(commands=commands, arm_order=list(ORDER), binding=t.pin(W / 'binding.json'), script=t.pin(__file__),
            mode='timing', timing_processes=4, memory_processes=0, independent_memory_processes=0,
            processes=4, workload=scenario, retained_parser_arm=arm, plan_only=True,
            historical_samples_pooled=False, causal_architecture_benefit_claim=False)
        path = W / (scenario + '-' + role + '-plan.json'); t.save(path, cfg)
        plans.append(dict(scenario=scenario, role=role, plan=t.pin(path)))
    assert ordinal == 16
    t.save(W / 'window-plan.json', dict(status='PREPARED16_NOT_RUN', helper=t.pin(__file__),
        binding=t.pin(W / 'binding.json'), groups=plans, timing_processes=16, memory_processes=0,
        samples_each=2, order=list(ORDER), automatic_retries=0,
        contract='Original prefill/decode/session endpoints, greedy IDs and actual work. Complete non-time producer reports must match within/cross variant; no whitelist. Two samples are descriptive screening only.'))
    print('PREPARED16 timing only; root runs one scenario/role at a time')


def config(scenario, role):
    assert (scenario, role) in STAGES
    plan = t.read(W / 'window-plan.json'); t.exact(plan['helper']); t.exact(plan['binding'])
    group = next(row for row in plan['groups'] if (row['scenario'], row['role']) == (scenario, role))
    t.exact(group['plan']); return t.read(group['plan']['path'])


def analyze(scenario, role):
    cfg = config(scenario, role); records = [n.parse_one(entry, cfg) for entry in cfg['commands']]
    complete, groups, actual = {}, {}, []
    for variant in ('control', 'candidate'):
        selected = [row for row in records if row['variant'] == variant]; assert len(selected) == 2
        facts = [f.facts_parser.non_time(t.read(Path(row['folder']) / 'consumer-result.json')) for row in selected]
        complete[variant] = facts[0]
        groups[variant] = dict(within_variant_differences=f.differences(facts[0], facts[1]),
            metrics={key: b.stats([row['observation']['metrics'][key] for row in selected]) for key in METRICS})
        for row in selected:
            process = row['process']; raw = t.read(Path(row['folder']) / 'consumer-result.json')
            actual.append(dict(variant=variant, ordinal=row['window_ordinal'], pid=process['pid'],
                started_unix_ns=process['started_unix_ns'], result=t.pin(Path(row['folder']) / 'result.json'),
                actual_work=n.work_facts(raw, role)))
    differences = f.differences(complete['control'], complete['candidate'])
    passed = not differences and not any(row['within_variant_differences'] for row in groups.values())
    output = W / 'runs' / (scenario + '-' + role)
    b.save(output / 'complete-non-time-differences.json', differences)
    value = dict(status='COMPLETE_STABLE' if passed else 'PRESERVED_FACT_DIFFERENCES', scenario=scenario, role=role,
        timing_processes=4, memory_processes=0, groups=groups, complete_non_time_equal=not differences,
        actual_processes=actual, records=records, cross_variant_differences=differences,
        descriptive_median_delta_percent={key: 100 * (groups['candidate']['metrics'][key]['median'] /
            groups['control']['metrics'][key]['median'] - 1) for key in METRICS},
        limitations=['Retained 4ca9 consumer, not the current whole CLI.', 'Two samples per variant; no significance or final performance claim.',
                     'No memory measurements; no historical timing samples pooled.'])
    b.save(output / 'summary.json', value)
    assert passed, 'Preserve full fact differences; no native retry or broad whitelist'
    print('COMPLETE_STABLE', scenario, role)
    return value


def run(scenario, role):
    cfg = config(scenario, role); output = W / 'runs' / (scenario + '-' + role)
    for previous in STAGES[:STAGES.index((scenario, role))]:
        assert t.read(W / 'runs' / ('-'.join(previous)) / 'summary.json')['status'] == 'COMPLETE_STABLE'
    output.mkdir(parents=True, exist_ok=False); t.save(output / 'inputs.json', cfg)
    runner = b.load_helpers(); runner.gpu_snapshot(output, 'window-before')
    try:
        for entry in cfg['commands']:
            t.exact(entry['ready']); t.exact(entry['environment'])
            env = os.environ.copy(); env['PATH'] = t.read(entry['environment']['path'])['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
            print('BEGIN', scenario, role, entry['ordinal'], entry['variant'], flush=True)
            runner.execute(Path(entry['folder']), entry['arm'], entry['command'], env, False)
            process = t.read(Path(entry['folder']) / 'result.json')
            assert process['exit'] == 0 and not process.get('timeout') and not process.get('reader_errors'), process
            print('END', scenario, role, entry['ordinal'], entry['variant'], flush=True)
    finally:
        runner.gpu_snapshot(output, 'window-after')
    analyze(scenario, role)


def summary():
    rows = [t.read(W / 'runs' / (scenario + '-' + role) / 'summary.json') for scenario, role in STAGES]
    assert all(row['status'] == 'COMPLETE_STABLE' for row in rows)
    identities = [(p['pid'], p['started_unix_ns']) for row in rows for p in row['actual_processes']]
    assert len(identities) == len(set(identities)) == 16
    b.save(W / 'summary.json', dict(status='COMPLETE16_TWO_GRAPH_OBJECT_SCREEN', groups=rows,
        binding=t.pin(W / 'binding.json'), timing_processes=16, memory_processes=0, sample_count_each=2,
        scope='Isolated resources/executable SDK changes in retained 4ca9 consumer, unchanged Model ff22; not current b1b engine or final four-metric milestone.'))
    print('COMPLETE16_TWO_GRAPH_OBJECT_SCREEN')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'preflight': validate(); print('PREFLIGHT PASS')
    elif action == 'link': link()
    elif action == 'parse-link': record_link()
    elif action == 'window-prepare': window_prepare()
    elif action == 'run': run(*sys.argv[2:])
    elif action == 'analyze': analyze(*sys.argv[2:])
    elif action == 'summary': summary()
    else: raise SystemExit('prepare | preflight | link | parse-link | window-prepare | run/analyze single|two-turn ordinary|mtp | summary')
