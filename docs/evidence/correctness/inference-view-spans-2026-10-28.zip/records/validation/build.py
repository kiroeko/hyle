"""Root-only incremental private-Plan rebuild; no action runs on import.

Normal: nine actual private-header SDK consumers and one existing test TU.
Diagnostic: mechanically rebase the original bounded counter on the new source.
No Model/NVCC compile, SDK copy, weights copy, or implicit consumer run.
"""
from pathlib import Path
import importlib.util
import os
import re
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
R = Path(r'C:\public\project-hyle\hyle')
W = Path(__file__).resolve().parent
DRIVER = R / '.scratch/inference-indexed-store-20261028/build.py'
spec = importlib.util.spec_from_file_location('view_spans_retained_executor', DRIVER)
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
t.R = R; t.W = W
BASE = R / '.scratch/inference-source-spans-20261028'
NORMAL = BASE / 'performance/ready-normal.json'
GTEST = BASE / 'ready.json'
REFINED_TEST = BASE / 'refinement/compile/output-source-test/compiled.json'
COUNTER = R / '.scratch/inference-physical-spans-20261028/performance/reachability/executable-reachability.cc'
SDK = {
    'executable': (47, 'src/graph/executable.cc'),
    'submission': (48, 'src/graph/submission.cc'),
    'constant-artifact': (51, 'src/graph/constant_artifact.cc'),
    'resources': (52, 'src/graph/resources.cc'),
    'region-access': (54, 'src/graph/region_access.cc'),
    'input-sources': (55, 'src/graph/input_sources.cc'),
    'resource-report': (56, 'src/graph/resource_report.cc'),
    'progress': (128, 'src/graph_progress/progress.cc'),
    'slots-region': (218, 'src/graph/slots_region.cc'),
}
EXTRA_CASES = [
    'InputSourceBundle.InvalidLastTensorPreservesOriginalPreparedBindings',
    'InputSourceBundle.SameProducerReplacesBothInputsAndDeduplicatesReadiness',
    'GraphOutputSourceCuda.PendingI32ReusesRealNativeRegionCaptureWithoutRecording',
    'GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges',
    'GraphOutputSourceCuda.ProducerCheckedFailureRejectsConsumerPublicationAfterRetirement',
]
PRIVATE = R / 'src/graph/plan_state.h'


def metadata(row):
    value = t.retained_metadata(row)
    assert value and value['command'], ('Missing actual CXX receipt', row['path'])
    return value


def has_private(meta):
    return any(t.key(path) == t.key(PRIVATE) for path in meta['includes'])


def recipe(original, source, name):
    args = []; original_args = t.command(original['command']['path'])
    for i, arg in enumerate(original_args):
        if t.key(arg) == t.key(original['source']): arg = str(source)
        elif i and original_args[i - 1].lower() == '/sourcedependencies':
            arg = str(W / f'compile/{name}/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
        args.append(arg)
    assert all(flag in args for flag in ('/c', '/O2', '/MD', '/WX'))
    assert sum(t.key(arg) == t.key(source) for arg in args) == 1
    if name == 'diagnostic-executable': args.insert(1, '/I' + str(R / 'src/graph'))
    path = W / f'recipes/{name}.json'
    t.save(path, dict(command=args, timeout_seconds=300))
    return t.pin(path)


def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve every prepared plan and attempt'
    normal, test = t.read(NORMAL), t.read(GTEST)
    for ready, count in ((normal, 229), (test, 232)):
        assert ready['process']['exit'] == 0
        t.exact(ready['inputs']); t.exact(ready['recipe'])
        assert len(t.read(ready['inputs']['path'])) == count
    assert normal['image']['sha256'] == 'e8cc7388072ebc844bbaaed0139e8a6519fb463f272e03929283857d17482da9'
    assert normal['compiled']['object']['sha256'] == 'ff22d11a294a5aa507034b09efeb475b1aedd514f473b974c970436f24f51e52'
    rows = t.read(normal['inputs']['path']); tests = t.read(test['inputs']['path'])
    units = {}
    for name, (index, source) in SDK.items():
        prior = metadata(rows[index])
        assert t.key(prior['source']) == t.key(R / source) and has_private(prior)
        units[name] = dict(source=source, compile_source=str(R / source), original=prior,
            original_index=index, recipe=recipe(prior, R / source, name))
    prior = metadata(test['compiled']['configuration-test']['object'])
    assert has_private(prior)
    units['configuration-test'] = dict(source='tests/graph/configuration_input_test.cc',
        compile_source=str(R / 'tests/graph/configuration_input_test.cc'), original=prior,
        recipe=recipe(prior, R / 'tests/graph/configuration_input_test.cc', 'configuration-test'))
    prior = units['executable']['original']
    units['diagnostic-executable'] = dict(source='src/graph/executable.cc',
        compile_source=str(W / 'executable-reachability.cc'), original=prior,
        recipe=recipe(prior, W / 'executable-reachability.cc', 'diagnostic-executable'))
    refined = t.read(REFINED_TEST); assert refined['process']['exit'] == 0
    assert refined['source']['sha256'] == '09d6340b4b3715d9e4da3795dc9de305b0332659d0299e5b0cb4ca142599e4a2'
    t.exact(refined['source']); t.exact(refined['command']); t.exact(refined['dependencies'])
    for row in (test['compiled']['input-source-test']['object'], refined['object'],
                rows[63], rows[227]):
        assert not has_private(metadata(row)), ('Private layout consumer must be refreshed', row)
    replacement_sources = {t.key(R / unit['source']): name for name, unit in units.items()
                           if name != 'diagnostic-executable'}
    mappings = {}
    for role, old_rows in (('normal', rows), ('gtest', tests)):
        changes = {}
        for i, row in enumerate(old_rows):
            meta = t.retained_metadata(row)
            name = replacement_sources.get(t.key(meta['source'])) if meta else None
            if name and (role == 'gtest' or name != 'configuration-test'):
                assert name not in changes.values(), ('Duplicate source in closure', name)
                changes[str(i)] = name
            elif meta and has_private(meta): raise AssertionError(('Unaccounted private header consumer', role, meta))
        assert set(changes.values()) == (set(SDK) | ({'configuration-test'} if role == 'gtest' else set()))
        mappings[role] = changes
    old_output = test['compiled']['output-source-test']['object']
    output_indices = [i for i, row in enumerate(tests) if row == old_output]
    assert len(output_indices) == 1
    links = {}
    for role, ready, old_rows in (('normal', normal, rows), ('gtest', test, tests)):
        replacements = {t.key(old_rows[int(i)]['path']): str(W / f'compile/{name}/unit.obj')
                        for i, name in mappings[role].items()}
        if role == 'gtest': replacements[t.key(old_output['path'])] = refined['object']['path']
        args = []
        for arg in t.command(ready['recipe']['path']):
            arg = replacements.get(t.key(arg), arg)
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / ('bin/view-spans-' + role)).with_suffix(suffix)); break
            args.append(arg)
        path = W / f'recipes/link-{role}.json'
        t.save(path, dict(command=args, timeout_seconds=240)); links[role] = t.pin(path)
    args = []
    for arg in t.command(links['normal']['path']):
        if t.key(arg) == t.key(W / 'compile/executable/unit.obj'):
            arg = str(W / 'compile/diagnostic-executable/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/view-spans-diagnostic').with_suffix(suffix)); break
        args.append(arg)
    t.save(W / 'recipes/link-diagnostic.json', dict(command=args, timeout_seconds=240))
    links['diagnostic'] = t.pin(W / 'recipes/link-diagnostic.json')
    all_rows = {t.key(row['path']): row for row in rows + tests + [refined['object']]}
    stats = []
    for row in all_rows.values():
        st = Path(row['path']).stat(); assert st.st_size == row['bytes'], row['path']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime.json', t.read(normal['runtime']['path']))
    t.save(W / 'retained-input-stats.json', stats)
    t.save(W / 'plan.json', dict(status='PREPARED_NOT_FROZEN_OR_RUN', units=units,
        bases=dict(normal=t.pin(NORMAL), gtest=t.pin(GTEST)),
        original_inputs=dict(normal=normal['inputs'], gtest=test['inputs']),
        original_recipes=dict(normal=normal['recipe'], gtest=test['recipe']), mappings=mappings,
        refined_test=dict(receipt=t.pin(REFINED_TEST), compiled=refined, index=output_indices[0]),
        model=normal['compiled'], links=links, counter_template=t.pin(COUNTER), executor=t.pin(DRIVER),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        retained_stats=t.pin(W / 'retained-input-stats.json'),
        counts=dict(normal_CXX=9, test_CXX=1, diagnostic_CXX=1, normal_inputs=229,
                    gtest_inputs=232, links=3, NVCC=0, gtest_processes=1),
        boundary='Retained old 4ca9 Model ff22. Refresh all nine actual private-Plan consumers. '
                 'GTest also refreshes configuration and reuses the corrected 09d6 Hybrid fixture. '
                 'Counter is scratch-only and its timings are not performance evidence.'))
    print('PREPARED recipes only: 10 normal/test CXX, optional 1 diagnostic CXX; no freeze or native')


def plan():
    p = t.read(W / 'plan.json')
    for key in ('executor', 'counter_template', 'environment', 'runtime', 'retained_stats'): t.exact(p[key])
    for group in ('bases', 'original_inputs', 'original_recipes', 'links'):
        for row in p[group].values(): t.exact(row)
    t.exact(p['refined_test']['receipt'])
    for unit in p['units'].values():
        t.exact(unit['recipe']); t.exact(unit['original']['command']); t.exact(unit['original']['dependencies'])
    return p


def freeze():
    p = plan()
    original = (R / 'src/graph/executable.cc').read_bytes()
    text = original.decode('utf-8'); newline = '\r\n' if '\r\n' in text else '\n'
    old = COUNTER.read_text(encoding='utf-8-sig')
    start = old.index('// Temporary diagnostics only. This counter never changes invocation state.')
    stop = old.index('Status\nprepare_invocation_bindings', start)
    block = old[start:stop].replace('\n', newline)
    anchor = 'Status' + newline + 'prepare_invocation_bindings(detail::InvocationState &invocation) noexcept {'
    decision = '  const bool reuse_spans = detail::reusable_configuration_spans(invocation);' + newline
    call = '  record_physical_span_reachability(invocation, reuse_spans);' + newline
    includes = '#include <atomic>' + newline + '#include <cstdio>' + newline
    assert text.count(anchor) == text.count(decision) == 1
    diagnostic = text.replace('#include <algorithm>' + newline, includes + '#include <algorithm>' + newline, 1)
    diagnostic = diagnostic.replace(anchor, block + anchor, 1).replace(decision, decision + call, 1)
    assert diagnostic.replace(includes, '', 1).replace(block, '', 1).replace(call, '', 1).encode('utf-8') == original
    with (W / 'executable-reachability.cc').open('xb') as out: out.write(diagnostic.encode('utf-8'))
    paths = {t.key(PRIVATE): PRIVATE}; roots = [R / 'include', R]
    for unit in p['units'].values():
        for path in t.dep_paths(unit['original']['dependencies']['path']):
            path = t.canonical(path)
            if t.project(path): paths[t.key(path)] = path
        roots += [Path(arg[2:]) for arg in t.command(unit['recipe']['path']) if arg.lower().startswith('/i')]
    pending = [R / unit['source'] for unit in p['units'].values()] + [PRIVATE]
    seen = set()
    while pending:
        path = pending.pop().resolve()
        if t.key(path) in seen: continue
        seen.add(t.key(path)); paths[t.key(path)] = path
        for kind, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((candidate.resolve() for root in ([path.parent] if kind == '"' else []) + roots
                          if (candidate := root / name).is_file()), None)
            if found is not None and t.project(found): pending.append(found)
    paths[t.key(W / 'executable-reachability.cc')] = W / 'executable-reachability.cc'
    snapshots = []
    for relative in dict.fromkeys([unit['source'] for unit in p['units'].values()] + ['src/graph/plan_state.h']):
        path = R / relative; target = W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as out: out.write(path.read_bytes())
        snapshots.append(dict(original=t.pin(path), snapshot=t.pin(target)))
    t.save(W / 'project-dependencies.json', [t.pin(path) for path in paths.values()])
    cases = ['ConfigurationInput.' + name for name in re.findall(
        r'TEST\s*\(\s*ConfigurationInput\s*,\s*(\w+)\s*\)',
        (R / 'tests/graph/configuration_input_test.cc').read_text(encoding='utf-8-sig'))] + EXTRA_CASES
    assert len(cases) == len(set(cases)) and len(cases) >= 12
    t.save(W / 'source-freeze.json', dict(helper=t.pin(__file__), plan=t.pin(W / 'plan.json'),
        dependencies=t.pin(W / 'project-dependencies.json'), sources=snapshots, cases=cases,
        diagnostic=dict(original=t.pin(R / 'src/graph/executable.cc'), source=t.pin(W / 'executable-reachability.cc'),
            template=p['counter_template'], reconstruction='Removing exactly the two includes, fixed 64-bucket block and one record call reproduces canonical source bytes.')))
    print('FROZEN current sources/private header and bounded dependency closure; no CXX')


def validate():
    p = plan(); f = t.read(W / 'source-freeze.json')
    for key in ('helper', 'plan', 'dependencies'): t.exact(f[key])
    for row in t.read(f['dependencies']['path']): t.exact(row)
    for row in f['sources']: t.exact(row['original']); t.exact(row['snapshot'])
    return p, f


def parse_compile(name):
    p, f = validate(); assert name in p['units']
    unit = p['units'][name]; out = W / 'compile' / name
    proc = t.read(W / f'logs/{name}/process.json')
    assert proc['exit'] == 0 and not proc['timed_out'], proc
    allowed = {t.key(row['path']): row for row in t.read(f['dependencies']['path'])}
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path) or t.key(path) == t.key(W / 'executable-reachability.cc'):
            assert t.key(path) in allowed, ('Successful CXX: repair parser only, do not rerun', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / unit['source']),
        snapshot=t.pin(unit['compile_source']) if name == 'diagnostic-executable' else None,
        object=t.pin(out / 'unit.obj'), process=proc, command=t.pin(W / f'logs/{name}/command.json'),
        dependencies=t.pin(out / 'dependencies.json'), actual_dependencies=t.pin(out / 'actual-dependencies.json')))
    print('CXX PASS', name, proc['pid'])


def compile_one(name):
    p, _ = validate(); assert name in p['units']
    (W / 'compile' / name).mkdir(parents=True, exist_ok=False)
    t.execute(t.command(p['units'][name]['recipe']['path']), W / 'logs' / name, 300)
    parse_compile(name)


def link(role):
    p, _ = validate(); assert role in ('gtest', 'normal', 'diagnostic')
    for row in t.read(p['retained_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    base_role = 'normal' if role == 'diagnostic' else role
    inputs = list(t.read(p['original_inputs'][base_role]['path'])); compiled = {}
    for index, name in p['mappings'][base_role].items():
        if role == 'diagnostic' and name == 'executable': name = 'diagnostic-executable'
        info = t.read(W / f'compile/{name}/compiled.json'); assert info['process']['exit'] == 0
        t.exact(info['object']); compiled[name] = info; inputs[int(index)] = info['object']
    if role == 'gtest': inputs[p['refined_test']['index']] = p['refined_test']['compiled']['object']
    count = 232 if role == 'gtest' else 229
    assert len(inputs) == count == len({t.key(row['path']) for row in inputs})
    args = t.command(p['links'][role]['path'])
    assert all(sum(t.key(arg) == t.key(row['path']) for arg in args) == 1 for row in inputs)
    t.save(W / f'inputs-{role}.json', inputs); (W / 'bin').mkdir(exist_ok=True)
    proc = t.execute(args, W / 'links' / role, 240)
    native = t.read(p['runtime']['path'])['native']; t.exact(native)
    target = W / 'bin' / Path(native['path']).name
    if target.exists(): assert os.path.samefile(target, native['path'])
    else: os.link(native['path'], target)
    t.save(W / f'ready-{role}.json', dict(image=t.pin(W / f'bin/view-spans-{role}.exe'),
        inputs=t.pin(W / f'inputs-{role}.json'), recipe=t.pin(W / f'links/{role}/command.json'),
        process=proc, compiled=compiled if role == 'gtest' else p['model'], units=compiled,
        retained_model=p['model'], frozen=t.pin(W / 'source-freeze.json'),
        native=t.pin(target), environment=p['environment'], runtime=p['runtime'],
        diagnostic=(role == 'diagnostic'), scope=p['boundary']))
    print('LINK PASS', role, count, proc['pid'])


def parse_gtest():
    f = t.read(W / 'source-freeze.json'); proc = t.read(W / 'run-gtest/process.json')
    assert proc['exit'] == 0 and not proc['timed_out'], proc
    cases = []
    for case in ET.parse(W / 'run-gtest/results.xml').getroot().iter('testcase'):
        name = case.attrib['classname'] + '.' + case.attrib['name']
        assert case.find('failure') is None and case.find('skipped') is None, name
        cases.append(name)
    assert sorted(cases) == sorted(f['cases']), cases
    t.save(W / ('summary-gtest-' + str(time.time_ns()) + '.json'), dict(status='PASS',
        process=proc, passed=len(cases), skipped=0, tests=cases,
        xml=t.pin(W / 'run-gtest/results.xml'), image=t.read(W / 'ready-gtest.json')['image'],
        scope='Finite configuration/source/capture tests only; no trained Model, throughput or complete architecture claim.'))
    print('GTEST PASS', len(cases), proc['pid'])


def run_gtest():
    _, f = validate(); ready = t.read(W / 'ready-gtest.json')
    t.exact(ready['image']); t.exact(ready['native'])
    t.execute([ready['image']['path'], '--gtest_filter=' + ':'.join(f['cases']),
        '--gtest_fail_fast', '--gtest_output=xml:' + str(W / 'run-gtest/results.xml')], W / 'run-gtest', 180)
    parse_gtest()


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'freeze': freeze()
        elif action == 'compile': compile_one(sys.argv[2])
        elif action == 'parse-compile': parse_compile(sys.argv[2])
        elif action == 'link': link(sys.argv[2])
        elif action == 'run-gtest': run_gtest()
        elif action == 'parse-gtest': parse_gtest()
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True, exist_ok=True)
        (W / ('failure-' + '-'.join(sys.argv[1:3]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
