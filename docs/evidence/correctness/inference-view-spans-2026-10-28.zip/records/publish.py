"""One offline evidence package from already completed view-span checks."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import difflib
import hashlib
import json
import zipfile

import report as r

W, V, R = r.W, r.V, r.R
OUT = R / 'docs/evidence/correctness/inference-view-spans-2026-10-28'
ALLOWED = {'.json', '.py', '.cc', '.h', '.patch', '.log', '.xml', '.ids'}


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def exact(info):
    path = Path(info['path'])
    actual = r.pin(path)
    assert (actual['bytes'], actual['sha256']) == (info['bytes'], info['sha256']), str(path)
    return path


def beijing(ns):
    return datetime.fromtimestamp(ns / 1e9, timezone(timedelta(hours=8))).isoformat(timespec='milliseconds')


def main():
    assert not OUT.with_suffix('.zip').exists() and not OUT.with_suffix('.json').exists(), 'Do not replace immutable evidence'
    report = r.build_report(W/'performance/diagnostic/runs/ordinary',
        W/'performance/diagnostic/runs/mtp', W/'performance/summary.json')
    assert report['status'] == 'FINITE_RESULTS_PRESENT'
    assert report['native']['gtest']['passed'] == 14 and not report['native']['gtest']['skipped']
    freeze = r.read(V/'source-freeze.json')
    notes = r.read(W/'evidence-notes.json')
    for source in notes['sources']:
        exact(dict(source, path=str(R/source['path'])))

    header = next(s for s in notes['sources'] if s['path']=='src/graph/plan_state.h')
    layout_closure = []
    for name in r.SDK:
        compiled = r.read(V/'compile'/name/'compiled.json')
        deps = r.read(exact(compiled['actual_dependencies']))
        proof = [d for d in deps if d['path'].replace('\\','/').endswith('/src/graph/plan_state.h')]
        assert len(proof)==1 and proof[0]['sha256']==header['sha256'], name
        assert report['compile_processes'][name]['status']=='PASS'
        layout_closure.append(dict(unit=name, source=compiled['source'], object=compiled['object'],
            actual_dependencies=compiled['actual_dependencies'], private_header=proof[0]))

    ready = {role:r.read(V/f'ready-{role}.json') for role in ('gtest','normal','diagnostic')}
    inputs = {role:r.read(V/f'inputs-{role}.json') for role in ready}
    assert {k:len(x) for k,x in inputs.items()}==dict(gtest=232, normal=229, diagnostic=229)
    normal = ready['normal']; model = normal['retained_model']
    binding = r.read(W/'performance/screen/binding.json')
    screen = r.read(W/'performance/summary.json')
    assert screen['status']=='COMPLETE8_VIEW_SPAN_SCREEN'
    assert (screen['timing_processes'],screen['memory_processes'],screen['diagnostic_processes'])==(8,0,2)
    assert all(g['complete_non_time_equal'] and not g['cross_variant_differences']
        and all(not v['within_variant_differences'] for v in g['groups'].values()) for g in screen['groups'])
    records = []
    for item in screen['actual_processes']:
        rec = r.read(exact(item['result']))
        assert rec['exit']==0 and rec['pid']==item['pid']
        records.append(dict(variant=item['variant'],ordinal=item['ordinal'],pid=rec['pid'],exit=rec['exit'],
            started_unix_ns=rec['started_unix_ns'],finished_unix_ns=rec['finished_unix_ns']))
    assert len({x['pid'] for x in records})==8
    groups=[]
    for group in screen['groups']:
        compact={name:{metric:{field:value[field] for field in ('count','median','min','max','samples')}
            for metric,value in variant['metrics'].items()} for name,variant in group['groups'].items()}
        groups.append(dict(scenario=group['scenario'],role=group['role'],order=['control','candidate','candidate','control'],
            complete_non_time_equal=True,within_variant_equal=True,metrics=compact,
            descriptive_median_delta_percent=group['descriptive_median_delta_percent']))

    diagnoses={}
    for role in ('ordinary','mtp'):
        base=W/'performance/diagnostic/runs'/role
        parsed=r.read(base/'analysis.json'); proc=r.read(base/'result.json')
        assert parsed['status']=='PASS_DIAGNOSTIC_FACTS' and not parsed['full_non_time_differences']
        assert proc['exit']==0 and not any(parsed['counts']['overflow'].values())
        diagnoses[role]=dict(pid=proc['pid'],exit=proc['exit'],counts=parsed['counts'],
            full_non_time_difference_count=0,performance_claim=False,
            started_unix_ns=proc['started_unix_ns'],finished_unix_ns=proc['finished_unix_ns'])
    assert diagnoses['ordinary']['counts']['totals']==dict(decisions=64,reused=58,full=6,full_input_sources=4)
    assert diagnoses['mtp']['counts']['totals']==dict(decisions=35,reused=32,full=3,full_input_sources=0)

    summary=dict(schema='hyle.inference.readonly-full-view-spans.evidence.v1',
        status='PASS_FINITE_CORRECTNESS_AND_REACHABILITY',date='2026-10-28',
        baseline=notes['baseline'],scope=notes['scope'],sources=notes['sources'],
        implementation=notes['implementation'],prior_basis=notes['prior_basis'],
        build=dict(CXX_processes=11,SDK_CXX_processes=9,test_CXX_processes=1,diagnostic_CXX_processes=1,
            link_processes=3,NVCC_processes=0,errors=0,
            private_layout_closure=layout_closure,input_counts={k:len(x) for k,x in inputs.items()},
            compile_records=report['compile_processes'],link_records=report['link_processes']),
        provenance=dict(model=model,model_scope='Retained 4ca9 Model source 41199a / object ff22; not the latest engine Model.',
            candidate_images={k:v['image'] for k,v in ready.items()},control_image=binding['versions']['control']['image'],
            source_freeze=r.pin(V/'source-freeze.json'),project_dependencies=r.pin(V/'project-dependencies.json'),
            runtime=normal['runtime'],environment=normal['environment'],
            diagnostic_derivative=freeze['diagnostic']),
        correctness=dict(native_processes=1,passed_test_cases=14,failed_test_cases=0,skipped_test_cases=0,
            gtest=report['native']['gtest'],scope='Finite ConfigurationInput, InputSourceBundle and GraphOutputSourceCuda cases; full names and XML retained.'),
        reachability=dict(native_processes=2,diagnostics=diagnoses,
            scope='Counts the existing reuse_spans decision after completeness checks; early already-prepared seals and missing configurations excluded. Scratch counters only.'),
        screening=dict(status=screen['status'],native_processes=8,memory_processes=0,MTP_timing_processes=0,
            samples_each=2,groups=groups,processes=records,
            started_beijing=beijing(min(p['started_unix_ns'] for p in records)),
            finished_beijing=beijing(max(p['finished_unix_ns'] for p in records)),
            full_non_time_equal=True,stable_net_speedup_established=False,
            interpretation='Single decode +0.4283%, two-turn decode -0.1990%: descriptive small-sample screening, no stable net benefit. No memory arm or formal TPS/table update.'),
        totals=dict(compile_processes=11,link_processes=3,native_processes=11,GTest_test_cases=14,diagnostic_processes=2,timing_processes=8,
            native_failures=0,native_retries=0),
        limits=notes['limits']+[
            'Do not infer physical span hits from TPS or capture_reused. The dedicated counter proves only its actual decision points.',
            'Source route/identity/readiness/ordering and new-epoch seal still execute. Complete alias permission inventory remains intact.',
            'No Apple/Vulkan, B2 performance, trained quality, unknown native failure, or across-window causal speedup claim.',
            'The previous 16-process screen is historical motivation only, not pooled or duplicated here; no retained-peer performance table update.'
        ],trained_quality_claim=False,all_platforms_claim=False)

    # Archive only bounded source/metadata/raw groups. Never follow SDK/object,
    # image or weight pins into payloads.
    files={}
    def add(path, name=None):
        path=Path(path).resolve()
        assert path.suffix.lower() in ALLOWED, str(path)
        if name is None:
            name='records/'+path.relative_to(W).as_posix()
        assert name not in files or files[name]==path
        files[name]=path
    for filename in ('evidence-notes.json','report.py','publish.py','test-source-freeze-final.json','test-changes-final.patch'):
        add(W/filename)
    for p in (W/'before').rglob('*'):
        if p.is_file():add(p)
    for p in (V/'source').rglob('*'):
        if p.is_file():add(p)
    for name in ('build.py','plan.json','source-freeze.json','project-dependencies.json','environment.json','runtime.json','executable-reachability.cc'):
        add(V/name)
    for pattern in ('ready-*.json','inputs-*.json','summary-gtest-*.json'):
        for p in V.glob(pattern):add(p)
    for folder in ('compile','recipes','logs','links','run-gtest'):
        for p in (V/folder).rglob('*'):
            if p.is_file() and p.suffix.lower() in ALLOWED and p.name!='running.json':add(p)
    add(W/'performance/build.py');add(W/'performance/summary.json')
    for folder in ('diagnostic','screen'):
        for p in (W/'performance'/folder).rglob('*'):
            if p.is_file() and p.suffix.lower() in ALLOWED:add(p)
    # Include the retained Model's actual source/recipe/dependency identity;
    # its old binary and weights are never needed in this evidence ZIP.
    for field in ('snapshot','command','dependencies','actual_dependencies'):
        p=exact(model[field]);add(p,'retained-model/'+p.name)
    parentfiles=set()
    for path in [W/'performance/diagnostic/run-plan.json',W/'performance/screen/window-plan.json',
        W/'performance/screen/single-ordinary-plan.json',W/'performance/screen/two-turn-ordinary-plan.json',
        W/'performance/diagnostic/ordinary-plan.json',W/'performance/diagnostic/mtp-plan.json']:
        def referenced(value):
            if isinstance(value,dict):
                if {'path','sha256','bytes'}<=value.keys():
                    p=Path(value['path'])
                    if p.suffix in ('.py','.ids') or p.name=='input.json':parentfiles.add(exact(value))
                for v in value.values():referenced(v)
            elif isinstance(value,list):
                for v in value:referenced(v)
        referenced(r.read(path))
    for p in sorted(parentfiles):
        if not p.is_relative_to(W):add(p,'support/'+p.relative_to(R).as_posix())

    changes=[]
    for source in notes['sources']:
        old=W/'before'/source['path']; new=R/source['path']
        changes.extend(difflib.unified_diff(old.read_text(encoding='utf-8-sig').splitlines(keepends=True),
            new.read_text(encoding='utf-8-sig').splitlines(keepends=True),fromfile='before/'+source['path'],tofile=source['path']))
    generated={'changes.patch':''.join(changes).encode('utf-8'),
        'summary.json':dump(summary),'actual-report.json':dump(report)}
    manifest=[]; payload={}
    for name,path in sorted(files.items()):
        data=path.read_bytes();payload[name]=data
        manifest.append(dict(member=name,source_path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    for name,data in generated.items():
        payload[name]=data;manifest.append(dict(member=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    payload['manifest.json']=dump(dict(schema='hyle.evidence.members.v1',members=manifest,
        excluded_payloads=['OBJ','EXE','PDB','DLL','SDK archive','weights','prior 16-process raw screen']))
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(OUT.with_suffix('.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(payload.items()):z.writestr(name,data)
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(payload)
        for member in manifest:
            data=z.read(member['member'])
            assert len(data)==member['bytes'] and hashlib.sha256(data).hexdigest()==member['sha256']
    archive=r.pin(OUT.with_suffix('.zip'))
    summary['archive']=dict(path=OUT.with_suffix('.zip').relative_to(R).as_posix(),
        bytes=archive['bytes'],sha256=archive['sha256'],members=len(payload),
        crc_readback='PASS',member_sha256_readback='PASS',member_manifest='manifest.json')
    OUT.with_suffix('.json').write_bytes(dump(summary))
    receipt=dict(status='OFFLINE_PACKAGE_COMPLETE',public_json=r.pin(OUT.with_suffix('.json')),
        archive=archive,members=len(payload),crc_readback='PASS',member_sha256_readback='PASS',
        scripts=[r.pin(W/'report.py'),r.pin(W/'publish.py')])
    (W/'publish-receipt.json').write_bytes(dump(receipt))
    print(json.dumps(receipt,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
