"""Run-only view-span diagnostics and optional eight fresh ordinary timings.

Root explicitly invokes every action. No compiler/linker, download, SDK copy,
memory process, MTP timing, automatic retry or historical timing pooling.
"""
from pathlib import Path
import copy
import importlib.util
import sys

sys.dont_write_bytecode = True
R = Path(r'C:\public\project-hyle\hyle')
W = Path(__file__).resolve().parent
V = W.parent / 'validation'
BASE = R / '.scratch/inference-source-spans-20261028/performance'
TEMPLATE = BASE / 'build.py'
spec = importlib.util.spec_from_file_location('view_spans_existing_run_protocol', TEMPLATE)
x = importlib.util.module_from_spec(spec); spec.loader.exec_module(x)
d, s, t = x.d, x.s, x.t
d.W = W / 'diagnostic'; s.W = W / 'screen'; t.W = W
s.STAGES = (('single', 'ordinary'), ('two-turn', 'ordinary'))
ORDER = ('control', 'candidate', 'candidate', 'control')


def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve all plans and actual attempts'
    paths = dict(control=BASE / 'ready-normal.json', candidate=V / 'ready-normal.json',
                 diagnostic=V / 'ready-diagnostic.json')
    versions = {name: t.read(path) for name, path in paths.items()}
    assert versions['control']['image']['sha256'] == 'e8cc7388072ebc844bbaaed0139e8a6519fb463f272e03929283857d17482da9'
    for name, ready in versions.items():
        assert ready['process']['exit'] == 0
        for key in ('image', 'inputs', 'recipe', 'runtime'): t.exact(ready[key])
        assert ready['compiled']['object']['sha256'] == 'ff22d11a294a5aa507034b09efeb475b1aedd514f473b974c970436f24f51e52'
        assert len(t.read(ready['inputs']['path'])) == 229
        if name != 'control': t.exact(ready['frozen'])
    normal = t.read(versions['candidate']['inputs']['path'])
    diagnostic = t.read(versions['diagnostic']['inputs']['path'])
    assert [i for i, (a, b) in enumerate(zip(normal, diagnostic)) if a != b] == [47]
    t.save(W / 'runtime.json', t.read(versions['candidate']['runtime']['path']))
    t.save(W / 'plan.json', dict(status='PREPARED_RUNS_NOT_STARTED', helper=t.pin(__file__),
        template=t.pin(TEMPLATE), versions={name: dict(ready=t.pin(paths[name]), **ready) for name, ready in versions.items()},
        runtime=t.pin(W / 'runtime.json'), source_freeze=t.pin(V / 'source-freeze.json'),
        counts=dict(CXX=0, NVCC=0, links=0, diagnostic_processes=2, optional_timing_processes=8, memory_processes=0),
        scope='Retained 4ca9 Model ff22 with current private-Plan-compatible nine SDK objects; not the complete current engine. '
              'Compare complete non-time facts first; preserve any cold metadata differences for offline classification without model reruns.'))
    prior = t.read(BASE / 'diagnostic/run-plan.json'); groups = []
    for ordinal, group in enumerate(prior['groups'], 1):
        role = group['role']; assert role in ('ordinary', 'mtp')
        t.exact(group['plan']); t.exact(group['expected_full_report'])
        cfg = copy.deepcopy(t.read(group['plan']['path'])); old = cfg['commands'][0]
        ready = versions['diagnostic']
        entry = dict(old, ordinal=1, window_ordinal=ordinal, variant='diagnostic',
            folder=str(d.W / 'runs' / role), command=[ready['image']['path'], *old['command'][1:]],
            image=ready['image'], environment=t.pin(W / 'runtime.json'), ready=t.pin(paths['diagnostic']))
        cfg.update(commands=[entry], binding=t.pin(V / 'source-freeze.json'),
            timing_processes=0, memory_processes=0, diagnostic_processes=1, performance_claim=False)
        path = d.W / (role + '-plan.json'); t.save(path, cfg)
        groups.append(dict(role=role, plan=t.pin(path), expected_full_report=group['expected_full_report']))
    assert len(groups) == 2
    t.save(d.W / 'run-plan.json', dict(helper=t.pin(d.__file__), adapter=t.pin(__file__),
        groups=groups, diagnostic_processes=2, performance_claim=False,
        original_screen_summary=prior['original_screen_summary']))
    print('PREPARED 2 diagnostics only; no native/CXX/link started')


def plan():
    p = t.read(W / 'plan.json')
    for key in ('helper', 'template', 'runtime', 'source_freeze'): t.exact(p[key])
    for ready in p['versions'].values():
        for key in ('ready', 'image', 'inputs', 'recipe'): t.exact(ready[key])
    return p


def diagnostic(role, execute):
    plan()
    if execute: d.run(role)
    else: d.analyze(role)


def screen_prepare():
    p = plan()
    for role in ('ordinary', 'mtp'):
        assert t.read(d.W / 'runs' / role / 'analysis.json')['status'] == 'PASS_DIAGNOSTIC_FACTS', \
            'Preserve and classify full differences offline before any timing; never rerun successful native'
    versions = {name: dict(p['versions'][name], runtime=p['runtime']) for name in ('control', 'candidate')}
    for name, ready in versions.items(): t.save(s.W / ('ready-' + name + '.json'), ready)
    original_binding = t.read(R / '.scratch/inference-physical-spans-20261028/performance/binding.json')
    work = original_binding['work']
    for row in work.values(): t.exact(row)
    binding = dict(versions={name: dict(versions[name], ready=t.pin(s.W / ('ready-' + name + '.json')))
                             for name in versions},
        work=work, runtime=p['runtime'], adapter=t.pin(__file__), source_freeze=p['source_freeze'],
        scope='Eight fresh ordinary-only timings, Source-spans e8cc versus view-spans normal. '
              'Same retained Model ff22. No counter in either image, MTP timing, memory measurement or historical timing pooling.')
    t.save(s.W / 'binding.json', binding); groups = []; ordinal = 0
    for scenario, role in s.STAGES:
        cfg = copy.deepcopy(t.read(R / '.scratch/inference-physical-spans-20261028/performance' /
                                   (scenario + '-ordinary-plan.json')))
        template = next(row for row in cfg['commands'] if row['variant'] == 'candidate')
        assert '--trace' not in template['command'] and '--probe' not in template['command']
        commands = []
        for local, variant in enumerate(ORDER, 1):
            ordinal += 1; ready = binding['versions'][variant]
            commands.append(dict(ordinal=local, window_ordinal=ordinal, variant=variant,
                scenario=scenario, role=role, arm='hyle_auto',
                folder=str(s.W / 'runs' / (scenario + '-' + role) / (f'{local:02d}-' + variant)),
                command=[ready['image']['path'], *template['command'][1:]], image=ready['image'],
                environment=p['runtime'], ready=ready['ready']))
        cfg.update(commands=commands, arm_order=list(ORDER), binding=t.pin(s.W / 'binding.json'), script=t.pin(__file__),
            timing_processes=4, memory_processes=0, independent_memory_processes=0, processes=4,
            historical_samples_pooled=False, causal_architecture_benefit_claim=False)
        path = s.W / (scenario + '-ordinary-plan.json'); t.save(path, cfg)
        groups.append(dict(scenario=scenario, role=role, plan=t.pin(path)))
    assert ordinal == 8
    t.save(s.W / 'window-plan.json', dict(helper=t.pin(s.__file__), adapter=t.pin(__file__),
        binding=t.pin(s.W / 'binding.json'), groups=groups, timing_processes=8, memory_processes=0,
        samples_each=2, order=list(ORDER), automatic_retries=0,
        contract='Complete producer non-time facts stable and equal; preserve differences rather than whitelist. '
                 'Original endpoints and args; fresh two samples per arm/workload only.'))
    print('PREPARED8 ordinary-only timing screen; no native started')


def summary():
    p = plan()
    rows = [t.read(s.W / 'runs' / (scenario + '-' + role) / 'summary.json') for scenario, role in s.STAGES]
    assert all(row['status'] == 'COMPLETE_STABLE' for row in rows)
    actual = [record for row in rows for record in row['actual_processes']]
    assert len(actual) == len({(record['pid'], record['started_unix_ns']) for record in actual}) == 8
    s.b.save(W / 'summary.json', dict(status='COMPLETE8_VIEW_SPAN_SCREEN', groups=rows,
        actual_processes=actual, source_freeze=p['source_freeze'], timing_processes=8,
        diagnostic_processes=2, memory_processes=0, samples_each=2,
        scope=p['scope'], limitations=['Descriptive two-sample screening; not a complete performance milestone.',
            'No MTP timing, memory comparison or historical timing pooling; diagnostics are not timed evidence.']))
    print('COMPLETE8_VIEW_SPAN_SCREEN')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'diagnostic': diagnostic(sys.argv[2], True)
    elif action == 'analyze-diagnostic': diagnostic(sys.argv[2], False)
    elif action == 'screen-prepare': screen_prepare()
    elif action == 'screen-run': plan(); s.run(sys.argv[2], 'ordinary')
    elif action == 'screen-analyze': plan(); s.analyze(sys.argv[2], 'ordinary')
    elif action == 'summary': summary()
    else: raise ValueError(action)
