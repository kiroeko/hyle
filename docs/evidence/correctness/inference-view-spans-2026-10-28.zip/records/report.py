"""Offline compact-report skeleton. Reads explicit actual records only; never runs builders/native or archives."""
from pathlib import Path
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
W = Path(__file__).resolve().parent
V = W / 'validation'
R = W.parents[1]
SDK = ['executable','submission','constant-artifact','resources','region-access','input-sources','resource-report','progress','slots-region']

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def process(path):
    path = Path(path)
    if not path.exists(): return dict(status='PENDING', expected_record=str(path))
    value = read(path)
    terminal = value.get('exit') is not None
    result = dict(status=('PASS' if value['exit']==0 and not value.get('timed_out',False) else 'FAILED') if terminal else 'PENDING',
        record=pin(path), pid=value.get('pid'), exit=value.get('exit'), timed_out=value.get('timed_out'),
        started_unix_ns=value.get('started_unix_ns'), finished_unix_ns=value.get('finished_unix_ns'))
    # The actual CXX/link/GTest driver records a floating-point Unix start
    # and elapsed seconds, not nanosecond wall-clock endpoints. Preserve its
    # precision instead of reporting an unknown start or invented exact ns.
    if 'started' in value: result['started_unix_seconds'] = value['started']
    if 'seconds' in value: result['elapsed_seconds'] = value['seconds']
    return result

def gtest():
    base = V / 'run-gtest'; result = process(base / 'process.json')
    xml = base / 'results.xml'
    if not xml.exists():
        if result['status']=='PASS': result['status']='PENDING'
        return result
    cases = list(ET.parse(xml).getroot().iter('testcase'))
    result.update(xml=pin(xml), cases=[dict(name=c.attrib['classname']+'.'+c.attrib['name'],
        status='FAILED' if c.find('failure') is not None else 'SKIPPED' if c.find('skipped') is not None else c.attrib.get('result')) for c in cases])
    result['passed'] = sum(c.find('failure') is None and c.find('skipped') is None and c.attrib.get('result')=='completed' for c in cases)
    result['failed'] = sum(c.find('failure') is not None for c in cases)
    result['skipped'] = sum(c.find('skipped') is not None for c in cases)
    if result['failed']: result['status']='FAILED'
    elif result['skipped']: result['status']='INCOMPLETE'
    freeze=V/'source-freeze.json'
    if freeze.exists():
        expected=read(freeze).get('cases',[])
        result['expected_cases_equal']=sorted(expected)==sorted(c['name'] for c in result['cases'])
        if expected and not result['expected_cases_equal']:result['status']='INCOMPLETE'
    return result

def diagnostic(folder):
    if folder is None: return dict(status='PENDING',performance_claim=False)
    base=Path(folder); candidates=[base/name for name in ('result.json','process.json') if (base/name).exists()]
    if not candidates:return dict(status='PENDING',directory=str(base),performance_claim=False)
    result=process(candidates[0]); result['performance_claim']=False
    if len(candidates)>1:
        a,b=map(read,candidates)
        assert (a.get('pid'),a.get('exit'))==(b.get('pid'),b.get('exit')), 'Distinct process records require explicit selection'
    analysis=base/'analysis.json'
    if not analysis.exists():
        result['analysis_status']='PENDING'
        if result['status']=='PASS':result['status']='PENDING'
        return result
    value=read(analysis);counts=value.get('counts',{})
    differences=value.get('full_non_time_differences')
    result.update(analysis=pin(analysis),analysis_status=value.get('status'),counts=counts,
        full_non_time_difference_count=None if differences is None else len(differences))
    if differences:result['status']='FACT_DIFFERENCES'
    elif not counts.get('totals') or differences is None:
        if result['status']=='PASS':result['status']='PENDING'
    return result

def timing(path):
    if path is None:return dict(status='NOT_REQUESTED_OR_NOT_RUN',performance_claim=False)
    value=read(path);groups=[]
    for g in value.get('groups',[]):
        variants={}
        for name,variant in g.get('groups',{}).items():
            variants[name]={k:{f:metric[f] for f in ('count','median','min','max') if f in metric} for k,metric in variant.get('metrics',{}).items()}
        groups.append(dict(scenario=g.get('scenario'),role=g.get('role'),status=g.get('status'),
            complete_non_time_equal=g.get('complete_non_time_equal'),metrics=variants))
    return dict(status=value.get('status'),summary=pin(path),timing_processes=value.get('timing_processes'),
        memory_processes=value.get('memory_processes'),groups=groups,
        scope='This optional new ordinary single/two-turn screen only; never the prior 16-process window. Diagnostic timing excluded.')

def build_report(ordinary_dir=None, mtp_dir=None, timing_summary=None):
    notes=read(W/'evidence-notes.json')
    compile_records={name:process(V/'logs'/name/'process.json') for name in SDK+['configuration-test','diagnostic-executable']}
    links={role:process(V/'links'/role/'process.json') for role in ('gtest','normal','diagnostic')}
    native=dict(gtest=gtest(),ordinary_diagnostic=diagnostic(ordinary_dir),mtp_diagnostic=diagnostic(mtp_dir))
    states=[row['status'] for row in list(compile_records.values())+list(links.values())+list(native.values())]
    status='HAS_FAILURES' if any(s in ('FAILED','FACT_DIFFERENCES') for s in states) else 'PENDING' if any(s!='PASS' for s in states) else 'FINITE_RESULTS_PRESENT'
    return dict(schema='hyle.readonly-full-view-spans.report.v1',status=status,scope=notes['scope'],
        sources=notes['sources'],baseline=notes['baseline'],prior_basis=notes['prior_basis'],
        compile_processes=compile_records,link_processes=links,native=native,timing=timing(timing_summary),
        trained_quality_claim=False,all_platforms_claim=False,limits=notes['limits'])

def main():
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument('--ordinary-dir',type=Path);args.add_argument('--mtp-dir',type=Path)
    args.add_argument('--timing-summary',type=Path)
    args.add_argument('--output',type=Path,default=W/'report-draft.json')
    a=args.parse_args()
    report=build_report(a.ordinary_dir,a.mtp_dir,a.timing_summary)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(report['status'],a.output)

if __name__=='__main__':main()
