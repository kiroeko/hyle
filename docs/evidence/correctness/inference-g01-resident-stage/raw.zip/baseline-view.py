from pathlib import Path
import subprocess,json,time
p=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g01')
root=Path('/root/hyle-scratch/compute-unified/g01-baseline-view');root.mkdir(exist_ok=True)
(root/'CMakeLists.txt').write_bytes((p/'baseline-view.CMakeLists.txt').read_bytes())
commands=[['cmake','-S',str(root),'-B',str(root/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCMAKE_PREFIX_PATH=/root/hyle-scratch/compute-unified/g02-sdk-static-relocated','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3','-DCUDA_cudart_LIBRARY=/usr/local/cuda-13.3/targets/x86_64-linux/lib/libcudart.so'],['cmake','--build',str(root/'build'),'--parallel','2'],[str(root/'build/baseline')]]
stages=[]
for i,args in enumerate(commands):
 log=p/('baseline-view-'+str(i)+'.log');t=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 row={'command':args,'exit_code':r.returncode,'elapsed':time.monotonic()-t,'log':str(log)};stages.append(row);print(json.dumps(row),flush=True)
 (p/'baseline-view-result.json').write_text(json.dumps({'candidate':'26d7c2cb7212f5abdd3866baaf886b8fdbca02e5','scope':'original installed SDK before G01 changes, tiny CPU-only rejection consumer','stages':stages},indent=2)+'\n')
 if r.returncode:print(log.read_text()[-2000:]);raise SystemExit(r.returncode)
print((p/'baseline-view-2.log').read_text())
