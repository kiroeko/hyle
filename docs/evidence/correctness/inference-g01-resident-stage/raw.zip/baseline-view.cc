#include <hyle/compute/backends/cpu.h>
#include <hyle/compute/cpu.h>
#include <hyle/compute/prepared_operation.h>
#include <hyle/compute/providers/ggml_cpu.h>
#include <array>
#include <cstdio>
int main() {
  namespace c=hyle::compute;
  auto context=c::cpu::create_context({.native_threads=1});
  if(!context)return 1;
  const std::array<std::int64_t,4> qshape{1,8,1,256},kvshape{1,2,7,256},capacity{1,2,16,256};
  auto q=c::TensorDesc::dense(c::DataType::kBFloat16,qshape);
  auto physical=c::TensorDesc::dense(c::DataType::kBFloat16,capacity);
  if(!q||!physical)return 2;
  auto cache=c::TensorDesc::strided_bytes(c::DataType::kBFloat16,kvshape,physical->byte_strides());
  if(!cache)return 3;
  auto prepared=c::prepare(*context,c::ScaledDotProductAttention{.layout=c::AttentionLayout::kBatchHeadSequenceDepth,.scale=0.0625F},*q,*cache,*cache);
  if(prepared){
    const auto owner=prepared->provider();
    std::printf("original public BF16 GQA8/2 D256 resident view chose provider %.*s instead of fused ggml\n",int(owner.name.size()),owner.name.data());
    return owner.id==c::ggml_cpu::kProviderId?4:0;
  }
  std::printf("original public BF16 GQA8/2 D256 resident cache view rejected: %.*s\n",int(prepared.error().message().size()),prepared.error().message().data());
  return prepared.error().IsUnimplemented()?0:5;
}
