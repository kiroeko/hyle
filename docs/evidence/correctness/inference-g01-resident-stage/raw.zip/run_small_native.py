from pathlib import Path
import subprocess,time,json,sys
out=Path.cwd()/'.scratch/inference-gaps/g01'
tag=sys.argv[1];args=sys.argv[2:];log=out/(tag+'.log');started=time.monotonic()
with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
row={'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)}
(out/(tag+'-result.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
print(json.dumps(row),flush=True)
with log.open('rb') as f:
 f.seek(max(0,log.stat().st_size-2400));print(f.read(2400).decode('utf-8',errors='replace'))
sys.exit(r.returncode)
