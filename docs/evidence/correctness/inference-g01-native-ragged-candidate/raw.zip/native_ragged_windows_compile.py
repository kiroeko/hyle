from pathlib import Path
import subprocess,os,json,time
root=Path.cwd();out=root/'.scratch/inference-gaps/g01';env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1);env[key]=value
attempt=1+len(list(out.glob('native-ragged-windows-compile-*.log')));log=out/f'native-ragged-windows-compile-{attempt}.log';start=time.monotonic()
args=['cmake','--build','C:/h7/inference-g01-native-vulkan/build','--target','hyle_compute_route_vulkan','--parallel','4']
with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
row={'candidate':'280f6f92ea97bf3b424113346f0264fb7b20df16','command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'scope':'Windows affected Vulkan library compile only, four jobs, no GPU/math run','log':str(log)}
(out/f'native-ragged-windows-compile-{attempt}.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2000));print(f.read(2000).decode(errors='replace'))
raise SystemExit(r.returncode)
