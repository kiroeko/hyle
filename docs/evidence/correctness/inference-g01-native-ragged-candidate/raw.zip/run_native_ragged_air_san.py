from pathlib import Path
import subprocess,time,json,sys
out=Path.cwd()/'.scratch/inference-gaps/g01';route,mode=sys.argv[1:];assert route in ('apple','vulkan') and mode in ('asan','ubsan','tsan')
script=out/'native_ragged_air_san.py';remote='/Users/kiro/hyle-scratch/compute-unified/native_ragged_air_san.py'
subprocess.run(['scp',str(script),'kiro@172.22.10.198:'+remote],check=True)
attempt=1+len(list(out.glob(f'native-ragged-air-{route}-{mode}-san-*.log')));log=out/f'native-ragged-air-{route}-{mode}-san-{attempt}.log';start=time.monotonic()
args=['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3','kiro@172.22.10.198',f'/usr/bin/python3 {remote} {route} {mode}']
with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
row={'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)}
(out/f'native-ragged-air-{route}-{mode}-san-{attempt}.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1900));print(f.read(1900).decode(errors='replace'))
raise SystemExit(r.returncode)
