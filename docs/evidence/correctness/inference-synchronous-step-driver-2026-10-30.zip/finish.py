from pathlib import Path
import importlib.util
import json
import subprocess
import zipfile
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('current_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
p=read(W/'plan.json')
def stable(x):
 if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if not k.endswith('_seconds') and not k.endswith('_per_second')}
 if isinstance(x,list):return [stable(v) for v in x]
 return x
names=['logits-cpu','logits-cuda','varlen-cuda','wave-cpu','commit-cpu','publication-cpu','mtp']
checks=[]
for name in names:
 folder=W/'runs'/name/'attempt1';data=read(folder/'report.json');proc=read(folder/'process.json')
 assert proc['state']=='TERMINAL' and proc['exit']==0 and not proc['timed_out']
 if name!='mtp':assert data['status']=='PASS'
 checks.append(dict(name=name,report=pin(folder/'report.json'),process=proc))
packed=[]
for name in ('logits-cpu','logits-cuda'):
 data=read(W/'runs'/name/'attempt1/report.json')
 journeys=[dict(StateOnly=x['StateOnly_commits'],Verify=x['Verify_commits'],packed_prefill=x['natural_report']['packed_prefill_calls']) for x in data['journeys']]
 assert all(x['StateOnly']>0 and x['packed_prefill']>0 for x in journeys)
 assert all(x['Verify']>0 for x in journeys[:2])
 packed.append(dict(name=name,journeys=journeys))
varlen=read(W/'runs/varlen-cuda/attempt1/report.json')['reports'][1]
assert varlen['engine_unequal_lengths_one_submission'] and varlen['original_q_identity_and_release']
assert varlen['numerically_equivalent'] and varlen['old_checkpoints_unchanged']
old_mtp=R/'.scratch/inference-common-step-driver-20261030/runs/mtp/attempt1/report.json'
assert stable(read(old_mtp))==stable(read(W/'runs/mtp/attempt1/report.json'))
receipts={}
for name in ('cli','tiny'):
 path=W/'compile'/name/'receipt.json';v=read(path)
 for item in [v['object'],*v['source_identities']]:exact(item)
 receipts[name]=dict(receipt=pin(path),object=v['object'])
for item in p['retained']:exact(item)
base=read(p['base']['path']);base['base']=p['base'];base['compile']=p['consumers']['cli']['compile']
link=read(W/'link/cli/attempt1/command.json');base['link']=link if isinstance(link,list) else link['command']
# Existing relay objects included the old main.cc; do not advertise them as
# source-current consumers after this architecture change.
for name in ('relay','warm-cohort'):
 if name in base.get('current_consumers',{}):base.setdefault('historical_consumers',{})[name]=base['current_consumers'].pop(name)
base['current_consumers'].update(receipts)
base['note']='Architecture-only synchronous target migration. Current cli/tiny reflect main.cc; previous relay/warm-cohort moved to historical_consumers because their source dependencies changed. Same retained SDK ABI; no standalone performance experiment.'
save(W/'model-link-base.json',base)
(W/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','engine/models/qwen35/main.cc'],cwd=R))
summary=dict(schema='hyle.synchronous-step-driver.v1',date='2026-10-30',base_commit=p['base_commit'],status='FINITE_CHECKS_PASSED',
 implementation=[
  'SynchronousGenerationStepAdapter uses the same drive_steps synchronous branch as real GLM ordinary execution, alongside the existing Qwen continuous adapter.',
  'Actual packed prefill, exact target and varlen recursive target preparation remain static model actions; proposal mathematics, grouping, selection, Head publication and optional CPU ahead remain model-specific.',
  'The common driver owns prepare/submit/control/cancel/finish and failure recovery, not an opaque whole-loop callback. No new executor, Completion, resource authority, ledger or persistent callback.',
  'Prepare/submit and later failure cleanup now use original retire_failed_publication. Original first error, actual retirement and published peers are retained; late observer failure additionally releases CPU ahead cache hints.'
 ],sources=[pin(R/'engine/models/qwen35/main.cc')],checks=checks,natural_packed_paths=packed,
 varlen_target=dict(active_rows=varlen['batch_active_rows'],physical_rows=varlen['batch_physical_rows'],one_engine_submission=varlen['engine_unequal_lengths_one_submission'],q_identity_and_release=varlen['original_q_identity_and_release'],numerically_equivalent=varlen['numerically_equivalent'],payloads_byte_equal=varlen['payloads_byte_equal']),
 real_qwen_K1=dict(previous=pin(old_mtp),all_non_timing_fields_equal=True,generated_tokens=64),
 build=dict(consumer_translation_units=2,compiler_processes=2,max_compiler_concurrency=2,retained_sdk_inputs=227,SDK_CXX=0,NVCC=0,downloads=0,missing_cached_dependency_records=len(p['missing_cached_dependency_records']),missing_dependency_scope='Unchanged native-kernel objects and library inputs; changed engine consumer CXX source dependencies were checked.'),
 harness_note='The successful varlen native process prints two PASS JSON lines. The initial post-process parser expected one document; report reconstructed from the same original stdout after fixing parser, without native rerun.',
 cleanup=read(W/'cleanup-report.json'),
 remaining_architecture=['Model-result/request-publication boundary: model still performs some ledger preflight/result projection/replay checks and borrows request records.','Re-review actual differing model phases and shared failure/publication semantics; no claim of GLM cross-pump, complete second engine, arbitrary model support or multiple devices.'],
 limits=['No independent performance candidate, profiler run or complete peer performance/memory window. Existing full table unchanged.','Finite synthetic cases are untrained; varlen comparisons retain existing numerical tolerance and are not byte-equal or model-quality claims.','No new test on Apple/Vulkan, hybrid full model, multi-GPU/multi-machine or other full artifacts.'])
save(W/'summary.json',summary)
dest=R/'docs/evidence/correctness';dest.mkdir(parents=True,exist_ok=True)
save(dest/'inference-synchronous-step-driver-2026-10-30.json',summary)
archive=dest/'inference-synchronous-step-driver-2026-10-30.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as out:
 for name in ('build.py','finish.py','plan.json','summary.json','original-synchronous.cc','source-change.patch','cleanup.ps1','cleanup-targets.json','cleanup-report.json'):
  out.write(W/name,name)
 for path in W.rglob('*'):
  if path.is_file() and (path.name in ('command.json','process.json','receipt.json','report.json','image.json') or (path.name in ('stdout.log','stderr.log') and any(x in path.parts for x in ('runs','compile')))):
   out.write(path,str(path.relative_to(W)))
print(json.dumps(dict(status=summary['status'],checks=len(checks),archive_bytes=archive.stat().st_size,remaining='request publication boundary, architecture before performance')))
