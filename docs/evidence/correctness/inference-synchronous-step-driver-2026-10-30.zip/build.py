"""Architecture-only synchronous step checks, current cached SDK, no downloads."""
from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('previous',R/'.scratch/inference-common-step-driver-20261030/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=b.s.W=b.s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
BASE=R/'.scratch/inference-common-step-driver-20261030/model-link-base.json'

def prepare():
    assert not (W/'plan.json').exists()
    base=read(BASE); prior=read(BASE.parent/'plan.json')
    for item in [*base['retained'],base['runtime']]:exact(item)
    changed={key(R/x) for x in subprocess.check_output(['git','diff','--name-only','--','include','src','engine'],cwd=R,text=True).splitlines()}
    assert changed=={key(R/'engine/models/qwen35/main.cc')},changed
    sdk=read(base['sdk_engine_dependencies']['path'])
    rows={key(x['object']):x for x in [*sdk['inspected'],*sdk['engine_consumers']] if 'dependencies' in x}
    affected=[];missing=[]
    for item in base['retained']:
        obj=Path(item['path']);row=rows.get(key(obj))
        for candidate in [obj.parent/'dependencies.json',obj.parent/(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')]:
            if candidate.is_file() and 'Data' in read(candidate):row=dict(dependencies=pin(candidate));break
        if row is None:missing.append(str(obj));continue
        d=read(row['dependencies']['path'])['Data']
        if any(key(x) in changed for x in [d['Source'],*d['Includes']]):affected.append(d['Source'])
    assert not affected,affected
    wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
    sources={'cli':wrapper,'tiny':R/'tests/tools/qwen_host_image_test.cc'}
    consumers={name:dict(source=str(source),compile=b.s.relocated(base['compile'],name,source)) for name,source in sources.items()}
    fixture=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    cases={
        'logits-cpu':['--cpu',str(fixture),'--natural-logits'],
        'logits-cuda':['--cuda',str(fixture),'--natural-logits'],
        'varlen-cuda':['--cuda',str(fixture),'--mtp-varlen-verify'],
        'wave-cpu':['--cpu',str(fixture),'--generation-wave'],
        'commit-cpu':['--cpu',str(fixture),'--commit-failure']}
    (W/'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    cli=read(base['current_consumers']['cli']['receipt']['path'])
    save(W/'plan.json',dict(base=pin(BASE),base_commit='34721e391',retained=base['retained'],runtime=base['runtime'],
        original_link=base['link'],original_consumer=cli['object']['path'],units={},consumers=consumers,
        sdk=base['sdk_engine_dependencies'],missing_cached_dependency_records=missing,sdk_affected_sources=affected,
        SDK_CXX=0,NVCC=0,downloads=0,max_compilers=2,args=prior['args'],cases=cases))
    print('Prepared two consumer translation units; unchanged227 SDK inputs; no SDK CXX/NVCC/downloads.',flush=True)

def run(name,attempt):
    p=read(W/'plan.json');os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    consumer='cli' if name=='mtp' else 'tiny'
    args=p['args'] if name=='mtp' else p['cases'][name]
    image=read(W/('ready-'+consumer+'.json'));exact(image)
    folder=W/'runs'/name/attempt;save(folder/'image.json',image)
    b.s.b.execute([image['path'],*args],folder,600)
    text=(folder/'stdout.log').read_text(encoding='utf-8-sig')
    lines=[__import__('json').loads(line) for line in text.splitlines() if line.strip()]
    result=lines[0] if len(lines)==1 else dict(status='PASS',reports=lines)
    if len(lines)>1:assert all(x.get('status')=='PASS' for x in lines)
    if name=='mtp':assert result['generated_tokens']==64 and result['live_committed_versions']==0
    else:assert result['status']=='PASS'
    save(folder/'report.json',result);print('PASS',name,flush=True)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':b.compile_group(sys.argv[2],sys.argv[3:])
    elif action=='link':b.link(sys.argv[2],sys.argv[3])
    elif action=='run':run(sys.argv[2],sys.argv[3])
    else:raise ValueError(action)
