$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$batch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-synchronous-step-driver-20261030'))
$bin = [IO.Path]::GetFullPath((Join-Path $batch 'bin'))
$manifest = Get-Content -LiteralPath (Join-Path $batch 'cleanup-targets.json') -Raw | ConvertFrom-Json
if ($manifest.workspace -cne $workspace -or $manifest.batch -cne $batch -or -not $batch.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected cleanup boundary' }
$targets = @($manifest.targets)
if ($targets.Count -ne 7) { throw 'Unexpected exact target count' }
$total = [long]0
foreach ($pin in $targets) {
  $target = [IO.Path]::GetFullPath($pin.path)
  if ([IO.Path]::GetDirectoryName($target) -cne $bin -or [IO.Path]::GetExtension($target).ToLowerInvariant() -notin @('.exe','.dll','.lib','.exp')) { throw ('Target escaped exact recreatable image scope: ' + $target) }
  $item = Get-Item -LiteralPath $target
  if ($item.PSIsContainer -or $item.Length -ne $pin.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pin.sha256) { throw ('Changed target: ' + $target) }
  $total += $item.Length
}
foreach ($pin in $targets) { Remove-Item -LiteralPath $pin.path -Force }
$report = @{status='REMOVED_EXACT_RECREATABLE_IMAGES';files=$targets.Count;bytes=$total;boundary=$batch;retained='SDK and current consumer objects, original cached weights, source, commands and reports'}
$report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $batch 'cleanup-report.json') -Encoding utf8
$report | ConvertTo-Json
