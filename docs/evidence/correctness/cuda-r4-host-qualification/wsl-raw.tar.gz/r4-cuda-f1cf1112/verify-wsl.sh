#!/usr/bin/env bash
set -euo pipefail
r4_mode=${1:?pass off, asan, ubsan or tsan}
case "$r4_mode" in off|asan|ubsan|tsan) ;; *) exit 2;; esac
r4_root=/root/hyle-validation/r4-cuda-f1cf1112
r4_source="$r4_root/source"
r4_build="$r4_root/build-$r4_mode"
r4_logs="$r4_root/logs/$r4_mode"
export PATH="/usr/local/cuda-13.3/bin:$PATH"
export CMAKE_BUILD_PARALLEL_LEVEL=2
export CTEST_PARALLEL_LEVEL=1
mkdir -p "$r4_logs"
cd "$r4_source"
run() {
  local r4_log=$1
  shift
  printf 'RUN %q ' "$@" >> "$r4_logs/commands.log"
  printf '\n' >> "$r4_logs/commands.log"
  if ! "$@" >"$r4_logs/$r4_log" 2>&1; then
    tail -n 80 "$r4_logs/$r4_log"
    return 1
  fi
}
run environment.log bash -c 'uname -a; /usr/bin/g++-14 --version; nvcc --version; nvidia-smi --query-gpu=name,driver_version,compute_cap,memory.total --format=csv'
run configure.log bash scripts/hyle-unix.sh /usr/bin/cmake -S . -B "$r4_build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14 -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
  -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_ONEDNN=OFF \
  '-DHYLE_DEV_FACTORS=compute_backend_cuda;compute_provider_cublas;compute_provider_marlin;compute_provider_cuda;compute_route_cuda;graph_route_cuda' \
  -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_STATIC=OFF \
  -DHYLE_WERROR=ON -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_SANITIZER="$r4_mode"
run build.log cmake --build "$r4_build" --parallel 2 --target \
  hyle_compute_backend_cuda_tests hyle_compute_provider_cublas_tests hyle_compute_provider_marlin_tests \
  hyle_compute_provider_cuda_tests hyle_compute_route_cuda_tests hyle_graph_route_cuda_tests
r4_ctest=(ctest --test-dir "$r4_build" --output-on-failure --no-tests=error --timeout 120 -j 1
  -L '^(compute_backend_cuda|compute_provider_cublas|compute_provider_marlin|compute_provider_cuda|compute_route_cuda|graph_route_cuda)$')
if [[ "$r4_mode" == tsan ]]; then
  run tests.log setarch "$(uname -m)" -R "${r4_ctest[@]}"
else
  run tests.log "${r4_ctest[@]}"
fi
cp "$r4_build/CMakeCache.txt" "$r4_logs/CMakeCache.txt"
cp "$r4_build/compile_commands.json" "$r4_logs/compile_commands.json"
cp "$r4_build/Testing/Temporary/LastTest.log" "$r4_logs/LastTest.log"
tail -n 22 "$r4_logs/tests.log"
printf '%s\n' "$r4_mode host qualification finished; no device-code instrumentation claim."
