#include <cstdio>
#include <cuda_runtime_api.h>

int main() {
  int count = 0;
  const auto result = cudaGetDeviceCount(&count);
  std::printf("cudaGetDeviceCount=%d (%s), count=%d\n", static_cast<int>(result),
              cudaGetErrorString(result), count);
  std::fflush(stdout);
  if (result != cudaSuccess)
    return 1;
  const auto reset = cudaDeviceReset();
  std::printf("cudaDeviceReset=%d (%s)\n", static_cast<int>(reset), cudaGetErrorString(reset));
  std::fflush(stdout);
  return reset == cudaSuccess ? 0 : 2;
}
