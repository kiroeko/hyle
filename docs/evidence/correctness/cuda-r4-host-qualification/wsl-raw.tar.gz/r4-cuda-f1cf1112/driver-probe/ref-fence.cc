#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <thread>

struct Owner {
  std::atomic<int> references{2};
  int payload = 0;
  void drop() {
#if defined(ACQ_REL_MODEL)
    const int prior = references.fetch_sub(1, std::memory_order_acq_rel);
#else
    const int prior = references.fetch_sub(1, std::memory_order_release);
#endif
    if (prior == 1) {
      std::atomic_thread_fence(std::memory_order_acquire);
#if defined(LOAD_MODEL)
      (void)references.load(std::memory_order_acquire);
#endif
      if (payload != 42)
        std::abort();
      delete this;
    }
  }
};

int main() {
  for (int i = 0; i < 32; ++i) {
    auto *owner = new Owner;
    std::thread worker([owner] { owner->payload = 42; owner->drop(); });
    // Relaxes only test scheduling; publication is the release sequence and
    // final acquire fence, exactly like the shipping intrusive refcount.
    while (owner->references.load(std::memory_order_relaxed) != 1)
      std::this_thread::yield();
    owner->drop();
    worker.join();
  }
  std::puts("all final destructors observed the published payload");
}
