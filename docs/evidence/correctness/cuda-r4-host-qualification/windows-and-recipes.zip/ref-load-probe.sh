#!/usr/bin/env bash
set -euo pipefail
r4_probe=/root/hyle-validation/r4-cuda-f1cf1112/driver-probe
cp /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/ref-fence-probe.cc "$r4_probe/ref-fence.cc"
g++-14 -std=c++23 -O1 -g -fsanitize=thread -Wno-tsan -DLOAD_MODEL=1 "$r4_probe/ref-fence.cc" -o "$r4_probe/ref-load"
setarch "$(uname -m)" -R "$r4_probe/ref-load" > "$r4_probe/ref-load.log" 2>&1
cat "$r4_probe/ref-load.log"
