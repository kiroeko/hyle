#!/usr/bin/env bash
set -euo pipefail
r4_root=/root/hyle-validation/r4-cuda-f1cf1112
cp /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/asan-driver.supp "$r4_root/driver-probe/driver.supp"
export ASAN_OPTIONS=protect_shadow_gap=0
export LSAN_OPTIONS="suppressions=$r4_root/driver-probe/driver.supp:print_suppressions=1"
ctest --test-dir "$r4_root/build-asan" --rerun-failed --verbose --no-tests=error --timeout 120 -j1 > "$r4_root/logs/asan/qualified-tests.log" 2>&1
python3 - <<'PY'
from pathlib import Path
import re
p=Path('/root/hyle-validation/r4-cuda-f1cf1112/logs/asan/qualified-tests.log')
t=p.read_text()
rows=re.findall(r'^\d+:\s+(\d+)\s+(\d+)\s+libcuda\.so\.1\s*$',t,re.M)
assert len(rows)==7, rows
assert all(row==('2','280') for row in rows), rows
assert '100% tests passed, 0 tests failed out of 7' in t
print('7/7 CUDA executables passed; each suppresses exactly the two standalone-driver allocations (280 bytes). Six unchanged headers already passed.')
PY
cp "$r4_root/build-asan/compile_commands.json" "$r4_root/logs/asan/compile_commands.json"
cp "$r4_root/build-asan/CMakeCache.txt" "$r4_root/logs/asan/CMakeCache.txt"
cp "$r4_root/build-asan/Testing/Temporary/LastTest.log" "$r4_root/logs/asan/LastTest.log"
