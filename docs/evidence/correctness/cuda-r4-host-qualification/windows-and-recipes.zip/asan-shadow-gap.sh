#!/usr/bin/env bash
set -euo pipefail
r4_root=/root/hyle-validation/r4-cuda-f1cf1112
r4_probe="$r4_root/driver-probe"
cp /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/asan-driver-probe.cc "$r4_probe/probe.cc"
g++-14 -std=c++23 -O1 -fsanitize=address -fno-omit-frame-pointer "$r4_probe/probe.cc" -I/usr/local/cuda-13.3/include -L/usr/local/cuda-13.3/lib64 -Wl,-rpath,/usr/local/cuda-13.3/lib64 -lcudart -o "$r4_probe/asan"
set +e
"$r4_probe/asan" > "$r4_probe/asan-flushed.log" 2>&1
printf 'default=%s\n' "$?" > "$r4_probe/correction-status.log"
ASAN_OPTIONS=protect_shadow_gap=0 "$r4_probe/asan" > "$r4_probe/asan-shadow-gap.log" 2>&1
printf 'shadow-gap=%s\n' "$?" >> "$r4_probe/correction-status.log"
ASAN_OPTIONS=protect_shadow_gap=0 ctest --test-dir "$r4_root/build-asan" --rerun-failed --output-on-failure --no-tests=error --timeout 120 -j1 > "$r4_root/logs/asan/shadow-gap-no-supp.log" 2>&1
result=$?
printf 'tests=%s\n' "$result"
tail -n 20 "$r4_root/logs/asan/shadow-gap-no-supp.log"
exit "$result"
