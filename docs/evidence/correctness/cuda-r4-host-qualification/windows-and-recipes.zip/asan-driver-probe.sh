#!/usr/bin/env bash
set -euo pipefail
r4_probe=/root/hyle-validation/r4-cuda-f1cf1112/driver-probe
mkdir -p "$r4_probe"
cp /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/asan-driver-probe.cc "$r4_probe/probe.cc"
g++-14 -std=c++23 -O1 "$r4_probe/probe.cc" -I/usr/local/cuda-13.3/include -L/usr/local/cuda-13.3/lib64 -Wl,-rpath,/usr/local/cuda-13.3/lib64 -lcudart -o "$r4_probe/plain"
g++-14 -std=c++23 -O1 -fsanitize=address -fno-omit-frame-pointer "$r4_probe/probe.cc" -I/usr/local/cuda-13.3/include -L/usr/local/cuda-13.3/lib64 -Wl,-rpath,/usr/local/cuda-13.3/lib64 -lcudart -o "$r4_probe/asan"
set +e
"$r4_probe/plain" > "$r4_probe/plain.log" 2>&1
printf 'plain=%s\n' "$?"
"$r4_probe/asan" > "$r4_probe/asan.log" 2>&1
printf 'asan=%s\n' "$?"
head -n 12 "$r4_probe/plain.log"
head -n 12 "$r4_probe/asan.log"
