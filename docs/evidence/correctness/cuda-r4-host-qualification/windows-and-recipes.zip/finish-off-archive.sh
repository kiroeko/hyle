#!/usr/bin/env bash
set -euo pipefail
r4_root=/root/hyle-validation/r4-cuda-f1cf1112
cp /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/verify-wsl-f1cf1112.sh "$r4_root/verify-wsl.sh"
cd "$r4_root/source"
bash scripts/hyle-unix.sh cmake -S . -B "$r4_root/build-off" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$r4_root/logs/off/export-compile-commands.log" 2>&1
cp "$r4_root/build-off/compile_commands.json" "$r4_root/logs/off/compile_commands.json"
cp "$r4_root/build-off/CMakeCache.txt" "$r4_root/logs/off/CMakeCache.txt"
cp "$r4_root/build-off/Testing/Temporary/LastTest.log" "$r4_root/logs/off/LastTest.log"
printf '%s\n' 'Original build and 13/13 tests passed. Only final archive cp failed because compile command export was not enabled. Enabled export by configure; no tests or build rerun.' > "$r4_root/logs/off/archive-correction.txt"
echo 'Ordinary CUDA qualification archive completed without rerunning tests.'
