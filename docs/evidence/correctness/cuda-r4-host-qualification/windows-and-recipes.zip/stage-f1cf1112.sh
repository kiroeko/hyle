#!/usr/bin/env bash
set -euo pipefail
qroot=/root/hyle-validation/r4-cuda-f1cf1112
test ! -e "$qroot/source"
mkdir -p "$qroot/source" "$qroot/logs"
sha256sum /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/f1cf1112.tar.gz > "$qroot/archive.sha256"
tar -xzf /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/f1cf1112.tar.gz -C "$qroot/source"
cp /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/verify-wsl-f1cf1112.sh "$qroot/verify-wsl.sh"
printf '%s\n' f1cf11121b5d4ad9529e3079b82b7e19717e2420 > "$qroot/candidate.txt"
exec bash "$qroot/verify-wsl.sh" off
