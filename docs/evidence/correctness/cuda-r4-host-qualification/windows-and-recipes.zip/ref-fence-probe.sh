#!/usr/bin/env bash
set -euo pipefail
r4_probe=/root/hyle-validation/r4-cuda-f1cf1112/driver-probe
cp /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/ref-fence-probe.cc "$r4_probe/ref-fence.cc"
for r4_mode in fence acq_rel; do
  args=()
  if [[ "$r4_mode" == acq_rel ]]; then args+=(-DACQ_REL_MODEL=1); fi
  g++-14 -std=c++23 -O1 -g -fsanitize=thread -Wno-tsan "${args[@]}" "$r4_probe/ref-fence.cc" -o "$r4_probe/ref-$r4_mode"
  set +e
  setarch "$(uname -m)" -R "$r4_probe/ref-$r4_mode" > "$r4_probe/ref-$r4_mode.log" 2>&1
  printf '%s=%s\n' "$r4_mode" "$?"
  set -e
  tail -n 5 "$r4_probe/ref-$r4_mode.log"
done
