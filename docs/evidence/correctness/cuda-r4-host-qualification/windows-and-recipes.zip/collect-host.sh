#!/usr/bin/env bash
set -euo pipefail
r4_base=/root/hyle-validation/r4-cuda-f1cf1112
r4_final=/root/hyle-validation/r4-cuda-a8c98249
# The failed initial TSan run stops before the normal archival copy step.
cp "$r4_base/build-tsan/CMakeCache.txt" "$r4_base/logs/tsan/CMakeCache.txt"
cp "$r4_base/build-tsan/compile_commands.json" "$r4_base/logs/tsan/compile_commands.json"
cp "$r4_base/build-tsan/Testing/Temporary/LastTest.log" "$r4_base/logs/tsan/LastTest.log"
tar -czf /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/host-wsl-raw.tar.gz \
  -C /root/hyle-validation r4-cuda-f1cf1112/logs r4-cuda-f1cf1112/driver-probe \
  r4-cuda-f1cf1112/archive.sha256 r4-cuda-f1cf1112/candidate.txt r4-cuda-f1cf1112/verify-wsl.sh \
  r4-cuda-a8c98249/logs r4-cuda-a8c98249/archive.sha256 \
  r4-cuda-b0f1eb67/logs/off
echo 'Host qualification logs and standalone probes archived.'
