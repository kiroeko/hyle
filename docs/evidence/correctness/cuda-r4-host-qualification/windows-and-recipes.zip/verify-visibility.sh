#!/usr/bin/env bash
set -euo pipefail
r4_root=/root/hyle-validation/r4-cuda-a8c98249
test ! -e "$r4_root/source"
mkdir -p "$r4_root/source" "$r4_root/logs"
sha256sum /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/a8c98249.tar.gz > "$r4_root/archive.sha256"
tar -xzf /mnt/c/hyle-scratch/r4-cuda-20260916/qualification/a8c98249.tar.gz -C "$r4_root/source"
cd "$r4_root/source"
export PATH="/usr/local/cuda-13.3/bin:$PATH"
export CMAKE_BUILD_PARALLEL_LEVEL=2
export CTEST_PARALLEL_LEVEL=1
bash scripts/hyle-unix.sh cmake -S . -B "$r4_root/build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-14 -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
  -DHYLE_COMPUTE_CUDA=ON -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_ONEDNN=OFF \
  '-DHYLE_DEV_FACTORS=compute_backend_cuda;graph_route_cuda' \
  -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_STATIC=OFF \
  -DHYLE_WERROR=ON -DHYLE_TEST_INSTRUMENTATION=OFF -DHYLE_SANITIZER=tsan > "$r4_root/logs/configure.log" 2>&1
cmake --build "$r4_root/build" --parallel 2 --target hyle_compute_backend_cuda_tests hyle_graph_route_cuda_tests > "$r4_root/logs/build.log" 2>&1
set +e
setarch "$(uname -m)" -R ctest --test-dir "$r4_root/build" --output-on-failure --no-tests=error --timeout 120 -j1 \
  -R '^(hyle_compute_backend_cuda_test|hyle_graph_route_cuda_test)$' > "$r4_root/logs/tests.log" 2>&1
r4_result=$?
set -e
cp "$r4_root/build/CMakeCache.txt" "$r4_root/logs/CMakeCache.txt"
cp "$r4_root/build/compile_commands.json" "$r4_root/logs/compile_commands.json"
cp "$r4_root/build/Testing/Temporary/LastTest.log" "$r4_root/logs/LastTest.log"
tail -n 35 "$r4_root/logs/tests.log"
exit "$r4_result"
