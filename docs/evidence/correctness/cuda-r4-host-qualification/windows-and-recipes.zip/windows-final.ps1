$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CTEST_PARALLEL_LEVEL = '1'
$env:CTEST_INTERACTIVE_DEBUG_MODE = '0'
$r4FinalLogs = 'C:/hyle-scratch/r4-cuda-20260916/qualification/windows-tail'
$r4FinalBuild = 'C:/hyle-scratch/r4-cuda-20260916/marlin-shared'
New-Item -ItemType Directory -Force -Path $r4FinalLogs | Out-Null
& cmake --build $r4FinalBuild --parallel 2 --target hyle_compute_backend_cuda_tests hyle_compute_provider_cublas_tests hyle_compute_provider_marlin_tests hyle_compute_provider_cuda_tests hyle_compute_route_cuda_tests hyle_graph_route_cuda_tests *> "$r4FinalLogs/build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r4FinalLogs/build.log" -Tail 60; throw 'Windows CUDA qualification build failed' }
foreach ($r4Dll in @('cudart64_13.dll', 'cublasLt64_13.dll')) {
    Copy-Item -LiteralPath "C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64/$r4Dll" -Destination "$r4FinalBuild/bin" -Force
}
foreach ($r4Dll in @('msvcp140.dll', 'msvcp140_atomic_wait.dll', 'vcruntime140.dll', 'vcruntime140_1.dll')) {
    Copy-Item -LiteralPath "C:/Windows/System32/$r4Dll" -Destination "$r4FinalBuild/bin" -Force
}
& ctest --test-dir $r4FinalBuild --output-on-failure --no-tests=error --timeout 120 -j1 -L '^(compute_backend_cuda|compute_provider_cublas|compute_provider_marlin|compute_provider_cuda|compute_route_cuda|graph_route_cuda)$' *> "$r4FinalLogs/tests.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$r4FinalLogs/tests.log" -Tail 65; throw 'Windows CUDA qualification tests failed' }
Copy-Item -LiteralPath "$r4FinalBuild/Testing/Temporary/LastTest.log" -Destination "$r4FinalLogs/LastTest.log"
Copy-Item -LiteralPath "$r4FinalBuild/CMakeCache.txt" -Destination "$r4FinalLogs/CMakeCache.txt"
Get-Content "$r4FinalLogs/tests.log" -Tail 23
