#!/usr/bin/env bash
set -euo pipefail
r4_probe=/root/hyle-validation/r4-cuda-f1cf1112/driver-probe
for r4_mode in undefined thread; do
  g++-14 -std=c++23 -O1 -fsanitize="$r4_mode" -fno-omit-frame-pointer "$r4_probe/probe.cc" -I/usr/local/cuda-13.3/include -L/usr/local/cuda-13.3/lib64 -Wl,-rpath,/usr/local/cuda-13.3/lib64 -lcudart -o "$r4_probe/$r4_mode"
  set +e
  if [[ "$r4_mode" == thread ]]; then
    setarch "$(uname -m)" -R "$r4_probe/$r4_mode" > "$r4_probe/$r4_mode.log" 2>&1
  else
    "$r4_probe/$r4_mode" > "$r4_probe/$r4_mode.log" 2>&1
  fi
  r4_status=$?
  set -e
  printf '%s=%s\n' "$r4_mode" "$r4_status"
  head -n 15 "$r4_probe/$r4_mode.log"
done
