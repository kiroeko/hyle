"""Bounded six-CXX/one-link recipe. Every execution phase is explicit."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import re
import sys
import traceback
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
_helpers = None


def helpers():
    global _helpers
    if _helpers is None:
        path = R / '.scratch/inference-slot-source-fallback-20261027/build.py'
        spec = importlib.util.spec_from_file_location('retained_slot_recipe', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _helpers = module.b, module.m
    return _helpers


def failure(stage):
    b, _ = helpers()
    path = W / (stage + '-failure.json')
    if not path.exists():
        b.save(path, dict(stage=stage, error=traceback.format_exc(),
                         note='Original command, process, stdout/stderr and XML remain in place. No automatic retry.'))


def frozen():
    b, _ = helpers()
    p = b.read(W / 'frozen-plan.json')
    b.exact(p['prepared_plan'])
    b.exact(p['source_freeze'])
    for row in b.read(p['source_freeze']['path']):
        b.exact(row)
    for unit in p['units']:
        b.exact(unit['command_template'])
    return p


def freeze(extra):
    b, m = helpers()
    assert not (W / 'frozen-plan.json').exists(), 'Preserve each frozen attempt'
    prepared = b.read(W / 'plan.json')
    units = prepared['units']
    for unit in units:
        unit['source'] = b.pin(unit['source'])
        unit['source_frozen'] = True
    extra_paths = [R / 'include/hyle/graph/slots.h', *[(R / path).resolve() for path in extra]]
    assert all(path.is_relative_to(R) and not path.is_relative_to(R / '.scratch') for path in extra_paths)
    canonical = m.c.closure([unit['source']['path'] for unit in units] + extra_paths,
                            [unit['command_template']['path'] for unit in units])
    b.save(W / 'source-freeze.json', canonical)  # Hash metadata only; no 900-header copy.
    own = {b.key(row['path']): row for row in canonical}
    for unit in units:
        assert own[b.key(unit['source']['path'])] == unit['source']
    snapshot = []
    for path in dict.fromkeys([Path(unit['source']['path']) for unit in units] + extra_paths):
        target = W / 'source' / path.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        assert b.pin(target)['sha256'] == own[b.key(path)]['sha256']
        snapshot.append(b.pin(target))
    tests = []
    for unit in units:
        path = Path(unit['source']['path'])
        if path.is_relative_to(R / 'tests'):
            tests.extend(suite.strip() + '.' + name.strip() for suite, name in
                         re.findall(r'\bTEST(?:_F)?\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', path.read_text(encoding='utf-8-sig')))
    # The retained CUDA GDN/conv test objects and their source identities are already in the baseline.
    retained_tests = ['tests/graph_provider_ggml_cuda/indexed_state_test.cc',
                      'tests/graph_provider_ggml_cuda/indexed_conv_test.cc']
    retained_pins = []
    for source in retained_tests:
        path = R / source
        row = b.pin(path)
        old_ready = b.read(prepared['baseline']['ready']['path'])
        if source.endswith('indexed_conv_test.cc'):
            expected = next(x['source'] for x in old_ready['compiled'] if x['name'] == 'test')
        else:
            deps = b.read(R / '.scratch/inference-slot-source-fallback-20261027/compile5/cuda-test/actual-dependencies.json')
            expected = next(x for x in deps if b.key(x['path']) == b.key(path))
        assert row['sha256'] == expected['sha256'], 'Retained test source changed: ' + source
        retained_pins.append(row)
        tests.extend(suite + '.' + name for suite, name in
                     re.findall(r'\bTEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', path.read_text(encoding='utf-8-sig')))
    assert len(tests) == len(set(tests)), 'Duplicate test names'
    groups = prepared['groups']
    for group in groups:
        exact = []
        for suite, count in group['expected_by_suite'].items():
            selected = [name for name in tests if name.startswith(suite + '.')]
            assert len(selected) == count, (suite, len(selected), count, selected)
            exact.extend(selected)
        group['exact_tests'] = exact
        group['expected_count'] = len(exact)
        group['status'] = 'FROZEN_NOT_RUN'
    b.save(W / 'frozen-plan.json', dict(status='SOURCE_FROZEN_NOT_BUILT',
        prepared_plan=b.pin(W / 'plan.json'), source_freeze=b.pin(W / 'source-freeze.json'),
        snapshots=snapshot, retained_test_sources=retained_pins, units=units, groups=groups,
        baseline=prepared['baseline'], image=prepared['image'], counts=prepared['counts'],
        link_template=prepared['link_template']))
    print('FROZEN', json.dumps(b.pin(W / 'frozen-plan.json')), flush=True)


def environment(p):
    b, _ = helpers()
    h = b.helper()
    cl = b.read(p['units'][0]['command_template']['path'])['command'][0]
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': cl, 'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    return h, env


def build():
    b, _ = helpers()
    p = frozen()
    assert not (W / 'compile').exists() and not (W / 'ready.json').exists(), 'Preserve prior attempts'
    for row in p['baseline'].values():
        b.exact(row)
    before = b.read(p['baseline']['inputs']['path'])
    assert len(before) == 228
    for row in before:
        b.exact(row)
    h, env = environment(p)
    own = {b.key(row['path']): row for row in b.read(p['source_freeze']['path'])}
    compiled = []
    for unit in p['units']:
        out = W / 'compile' / unit['name']
        process = h.execute(b.read(unit['command_template']['path'])['command'], env, out, timeout=180)
        deps = b.read(out / 'dependencies.json')['Data']
        actual = [b.pin(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])]
        b.save(out / 'actual-dependencies.json', actual)
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert own[b.key(path)]['sha256'] == row['sha256'], str(path)
        compiled.append(dict(name=unit['name'], source=unit['source'], object=b.pin(out / 'unit.obj'),
                             process=process, actual_dependencies=b.pin(out / 'actual-dependencies.json')))
        b.save(W / 'compiled-partial.json', compiled)
    frozen()
    image = Path(p['image'])
    image.parent.mkdir(parents=True, exist_ok=True)
    linked = h.execute(b.read(p['link_template']['path'])['command'], env, W / 'link', timeout=120)
    objects = {row['name']: row['object'] for row in compiled}
    replacements = {b.key(unit['baseline_object']['path']): objects[unit['name']]
                    for unit in p['units'] if unit['action'] == 'replace'}
    additions = [objects[unit['name']] for unit in p['units'] if unit['action'] == 'add']
    inputs = [replacements.get(b.key(row['path']), row) for row in before] + additions
    assert len(inputs) == 229 and len(replacements) == 5 and len(additions) == 1
    b.save(W / 'link-inputs.json', inputs)
    runtime = b.read(p['baseline']['runtime']['path'])
    native = runtime['native_cpu']
    b.exact(native)
    alias = image.parent / Path(native['path']).name
    os.link(native['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), compiled=compiled,
        link=linked, inputs=b.pin(W / 'link-inputs.json'), runtime=b.pin(W / 'runtime.json'),
        frozen_plan=b.pin(W / 'frozen-plan.json'), counts=dict(CXX_TUs=6, links=1, images=1, NVCC=0, SDK=0)))
    print('READY', json.dumps(b.pin(W / 'ready.json')), flush=True)


def run(name):
    b, _ = helpers()
    ready = b.read(W / 'ready.json')
    b.exact(ready['frozen_plan'])
    p = b.read(ready['frozen_plan']['path'])
    b.exact(ready['image'])
    group = next(row for row in p['groups'] if row['name'] == name)
    xml = W / ('results-' + name + '.xml')
    command = [ready['image']['path'], '--gtest_color=no',
               '--gtest_filter=' + ':'.join(group['exact_tests']), '--gtest_output=xml:' + str(xml)]
    out = W / ('run-' + name)
    if (out / 'process.json').exists():
        # Revalidate preserved XML without re-executing a successful process.
        assert b.read(out / 'command.json')['command'] == command
        process = b.read(out / 'process.json')
        assert process['exit'] == 0, 'Failed original process retained; no automatic retry'
    else:
        assert not out.exists(), 'Incomplete original run retained; do not start another process'
        h, env = environment(p)
        env['PATH'] = b.read(ready['runtime']['path'])['PATH']
        process = h.execute(command, env, out, timeout=120)
    root = ET.parse(xml).getroot()
    cases = root.findall('./testsuite/testcase')
    actual = [case.attrib['classname'] + '.' + case.attrib['name'] for case in cases]
    assert sorted(actual) == sorted(group['exact_tests'])
    assert len(cases) == group['expected_count'] == int(root.attrib['tests'])
    assert int(root.attrib.get('failures', '0')) == int(root.attrib.get('errors', '0')) == 0
    assert int(root.attrib.get('disabled', '0')) == 0
    assert all(case.attrib.get('status') == 'run' and case.attrib.get('result', 'completed') == 'completed'
               and not case.findall('failure') and not case.findall('error') and not case.findall('skipped')
               for case in cases)
    b.save(W / ('summary-' + name + '.json'), dict(status='PASS', group=name, process=process,
        tests=[case.attrib for case in cases], count=len(cases), failures=0, skipped=0,
        image=ready['image'], command=b.pin(out / 'command.json'), results=b.pin(xml),
        scope='Finite slot-control contracts and retained component regressions; no model, benchmark or fault injection.'))
    print('PASS', name, len(cases), flush=True)


def archive():
    b, _ = helpers()
    ready = b.read(W / 'ready.json')
    b.exact(ready['frozen_plan'])
    p = b.read(ready['frozen_plan']['path'])
    summaries = [b.read(W / ('summary-' + name + '.json')) for name in ['cpu', 'cuda']]
    assert all(row['status'] == 'PASS' for row in summaries)
    target = W / 'evidence.zip'
    assert not target.exists(), 'Preserve original archive'
    files = [W / name for name in ['prepare.py', 'build.py', 'plan.json', 'frozen-plan.json',
        'source-freeze.json', 'link-command-template.json', 'link-inputs.json', 'runtime.json',
        'ready.json', 'summary-cpu.json', 'summary-cuda.json', 'results-cpu.xml', 'results-cuda.xml']]
    files += [Path(row['path']) for row in p['snapshots']]
    original = b.read(W / 'frozen-plan.json')
    files += [Path(row['path']) for row in original['snapshots']]
    files += [W / name for name in ['build-attempt1.py', 'continue.py', 'frozen-plan2.json',
              'source-freeze2.json', 'link-command-template2.json'] if (W / name).is_file()]
    files += list((W / 'recipes').glob('*.json'))
    files += list((W / 'recipes2').glob('*.json'))
    for folder in [W / 'link', W / 'run-cpu', W / 'run-cuda',
                   *[Path(row['object']['path']).parent for row in ready['compiled']],
                   *([W / 'compile/common'] if (W / 'compile/common').exists() else [])]:
        files += [folder / name for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log',
                                            'actual-dependencies.json'] if (folder / name).is_file()]
    files += list(W.glob('*-failure.json'))
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for path in dict.fromkeys(files):
            assert path.is_relative_to(W)
            z.write(path, path.relative_to(W).as_posix())
    b.save(W / 'archive.json', dict(archive=b.pin(target), files=len(set(files)),
        baseline=p['baseline'], prior_closure='Refer to inference-indexed-conv-graph-2026-10-27 public evidence; no SDK/header tree duplication.',
        image=ready['image'], tests=sum(row['count'] for row in summaries),
        scopes='Component correctness only; no engine/model/performance/native fault claim.'))
    print('ARCHIVE', json.dumps(b.pin(W / 'archive.json')), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['freeze', 'build', 'run-cpu', 'run-cuda', 'archive'])
    parser.add_argument('--extra', action='append', default=[], help='Additional changed canonical header to snapshot at freeze')
    args = parser.parse_args()
    try:
        if args.phase == 'freeze':
            freeze(args.extra)
        elif args.phase == 'build':
            build()
        elif args.phase.startswith('run-'):
            run(args.phase[4:])
        else:
            archive()
    except Exception:
        failure(args.phase)
        raise
