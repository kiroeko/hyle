"""Authorized fixture-only two-TU rebuild and three-case retry; no product rebuild."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('batch_recipe', W / 'build.py')
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
b, m = recipe.helpers()
EXPECTED = {
    'cpu-test': 'ca744f82c2ac2a4457414e807d849cb32b72a8a6a31a2cc91b047da47871c780',
    'cuda-test': 'ad73749cad5d10de65a2c9e4754bc8ffee9a429c6d832311a466ffe6129e7bf0',
}


def build():
    assert not (W / 'frozen-plan3.json').exists() and not (W / 'ready2.json').exists()
    first = b.read(W / 'ready.json')
    p = b.read(first['frozen_plan']['path'])
    old_frozen = b.read(p['source_freeze']['path'])
    own = {b.key(row['path']): row for row in old_frozen}
    changed = []
    for unit in p['units']:
        if unit['name'] not in EXPECTED:
            continue
        source = Path(unit['source']['path'])
        current = b.pin(source)
        assert current['sha256'] == EXPECTED[unit['name']]
        assert current['sha256'] != unit['source']['sha256']
        changed.append(b.key(source))
        unit['source'] = current
        out = W / 'compile3' / unit['name']
        path = W / 'recipes3' / (unit['name'] + '.json')
        b.save(path, dict(command=m.command(unit['recipe']['path'], source, out), cwd=str(R), timeout_seconds=180))
        unit['command_template'] = b.pin(path)
        unit['planned_object'] = str(out / 'unit.obj')
        snapshot = W / 'source3' / source.relative_to(R)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
        p['snapshots'] = [row for row in p['snapshots'] if not row['path'].replace('\\', '/').endswith('/' + source.relative_to(R).as_posix())]
        p['snapshots'].append(b.pin(snapshot))
    updated = m.c.closure([unit['source']['path'] for unit in p['units']],
                          [unit['command_template']['path'] for unit in p['units']])
    newer = {b.key(row['path']): row for row in updated}
    assert own.keys() == newer.keys()
    assert sorted(key for key in own if own[key]['sha256'] != newer[key]['sha256']) == sorted(changed)
    b.save(W / 'source-freeze3.json', updated)
    p['previous_frozen_plan'] = first['frozen_plan']
    p['source_freeze'] = b.pin(W / 'source-freeze3.json')
    image = W / 'bin2/batched-slot-controls-test.exe'
    p['image'] = str(image)
    replacements = {b.key(row['object']['path']): str(W / 'compile3' / row['name'] / 'unit.obj')
                    for row in first['compiled'] if row['name'] in EXPECTED}
    command = []
    for arg in b.read(p['link_template']['path'])['command']:
        if b.key(arg) in replacements:
            arg = replacements[b.key(arg)]
        elif arg.upper().startswith('/OUT:'):
            arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    b.save(W / 'link-command-template3.json', dict(command=command, cwd=str(R), timeout_seconds=120))
    p['link_template'] = b.pin(W / 'link-command-template3.json')
    b.save(W / 'frozen-plan3.json', p)
    h, env = recipe.environment(p)
    compiled = list(first['compiled'])
    for unit in p['units']:
        if unit['name'] not in EXPECTED:
            existing = next(row for row in compiled if row['name'] == unit['name'])
            b.exact(existing['object'])
            for row in b.read(existing['actual_dependencies']['path']):
                path = Path(row['path'])
                if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                    assert newer[b.key(path)]['sha256'] == row['sha256'], str(path)
            continue
        out = W / 'compile3' / unit['name']
        process = h.execute(b.read(unit['command_template']['path'])['command'], env, out, timeout=180)
        deps = b.read(out / 'dependencies.json')['Data']
        actual = [b.pin(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])]
        b.save(out / 'actual-dependencies.json', actual)
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert newer[b.key(path)]['sha256'] == row['sha256'], str(path)
        new = dict(name=unit['name'], source=unit['source'], object=b.pin(out / 'unit.obj'),
                   process=process, actual_dependencies=b.pin(out / 'actual-dependencies.json'))
        compiled = [new if row['name'] == unit['name'] else row for row in compiled]
        b.save(W / 'compiled-partial3.json', compiled)
    for row in updated:
        b.exact(row)
    image.parent.mkdir(parents=True, exist_ok=True)
    linked = h.execute(command, env, W / 'link2', timeout=120)
    objects = {b.key(row['object']['path']): row['object'] for row in compiled}
    # Keep the exact original 229-input order, replacing only the two test objects.
    tests = {b.key(row['object']['path']): next(x['object'] for x in compiled if x['name'] == row['name'])
             for row in first['compiled'] if row['name'] in EXPECTED}
    inputs = [tests.get(b.key(row['path']), row) for row in b.read(first['inputs']['path'])]
    assert len(inputs) == 229 and sum(row['path'] in replacements.values() for row in inputs) == 2
    b.save(W / 'link2-inputs.json', inputs)
    runtime = b.read(first['runtime']['path'])
    native = runtime['native_cpu']
    b.exact(native)
    alias = image.parent / Path(native['path']).name
    os.link(native['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'runtime2.json', runtime)
    b.save(W / 'ready2.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), compiled=compiled,
        link=linked, inputs=b.pin(W / 'link2-inputs.json'), runtime=b.pin(W / 'runtime2.json'),
        frozen_plan=b.pin(W / 'frozen-plan3.json'), previous_ready=b.pin(W / 'ready.json'),
        counts=dict(distinct_CXX_TUs=6, compiler_attempts=9, failed_compiles=1, links=2, images=2,
                    previous_test_processes=2, NVCC=0, SDK=0)))
    print('READY2', json.dumps(b.pin(W / 'ready2.json')), flush=True)


def run(name):
    ready = b.read(W / 'ready2.json')
    b.exact(ready['image'])
    p = b.read(ready['frozen_plan']['path'])
    names = ['GraphSlotsExecution.BatchedStoresShareFixedControlSlicesAndRequireTheWholeGroup',
             'GraphSlotsExecution.BatchedStoresLateReadPermissionFailureReturnsEveryOriginalTransaction'] if name == 'cpu' else [
             'GraphSlotsCudaExecution.TwoStoresShareFixedControlsAndKeepIndependentPoolSlots']
    xml = W / ('results2-' + name + '.xml')
    command = [ready['image']['path'], '--gtest_color=no', '--gtest_filter=' + ':'.join(names),
               '--gtest_output=xml:' + str(xml)]
    out = W / ('run2-' + name)
    if (out / 'process.json').exists():
        assert b.read(out / 'command.json')['command'] == command
        process = b.read(out / 'process.json')
        assert process['exit'] == 0, 'Original failure retained; no automatic retry'
    else:
        assert not out.exists(), 'Preserve incomplete original process'
        h, env = recipe.environment(p)
        env['PATH'] = b.read(ready['runtime']['path'])['PATH']
        process = h.execute(command, env, out, timeout=120)
    root = ET.parse(xml).getroot()
    cases = root.findall('./testsuite/testcase')
    assert sorted(case.attrib['classname'] + '.' + case.attrib['name'] for case in cases) == sorted(names)
    assert int(root.attrib['tests']) == len(cases) == len(names)
    assert int(root.attrib.get('failures', '0')) == int(root.attrib.get('errors', '0')) == 0
    assert all(case.attrib.get('status') == 'run' and case.attrib.get('result', 'completed') == 'completed'
               and not case.findall('failure') and not case.findall('error') and not case.findall('skipped') for case in cases)
    b.save(W / ('summary2-' + name + '.json'), dict(status='PASS', process=process,
        image=ready['image'], tests=[case.attrib for case in cases], count=len(cases), skipped=0,
        command=b.pin(out / 'command.json'), results=b.pin(xml),
        scope='Only originally failed fixture cases, after explicit Store dependency repair. The other 26 cases were not rerun.'))
    print('PASS', name, len(cases), flush=True)


if __name__ == '__main__':
    try:
        if sys.argv[1] == 'build':
            build()
        else:
            assert sys.argv[1] in ['run-cpu', 'run-cuda']
            run(sys.argv[1][4:])
    except Exception:
        b.save(W / ('fixture-' + sys.argv[1] + '-failure.json'), dict(error=traceback.format_exc(), note='Stopped; original outputs retained.'))
        raise
