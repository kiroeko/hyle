"""Authorized narrow continuation: keep two successful objects, retry common only."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('batch_recipe', W / 'build.py')
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
b, m = recipe.helpers()


def main():
    assert not (W / 'frozen-plan2.json').exists() and not (W / 'ready.json').exists()
    original = b.read(W / 'frozen-plan.json')
    previous = b.read(original['source_freeze']['path'])
    changed = R / 'src/graph/slots_region.cc'
    assert b.pin(changed)['sha256'] == '02e741f9ceec0c976ef094f66051e7c7b18d5912d6432946ddf6d8acad88d3ca'
    updated = m.c.closure([unit['source']['path'] for unit in original['units']],
                          [unit['command_template']['path'] for unit in original['units']])
    old_by_key = {b.key(row['path']): row for row in previous}
    own = {b.key(row['path']): row for row in updated}
    assert own.keys() == old_by_key.keys()
    assert [key for key in own if own[key]['sha256'] != old_by_key[key]['sha256']] == [b.key(changed)]
    b.save(W / 'source-freeze2.json', updated)
    target = W / 'source2/src/graph/slots_region.cc'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(changed.read_bytes())
    p = original
    p['previous_frozen_plan'] = b.pin(W / 'frozen-plan.json')
    p['source_freeze'] = b.pin(W / 'source-freeze2.json')
    p['snapshots'] = [row for row in p['snapshots'] if not row['path'].replace('\\', '/').endswith('/src/graph/slots_region.cc')]
    p['snapshots'].append(b.pin(target))
    unit = next(row for row in p['units'] if row['name'] == 'common')
    unit['source'] = b.pin(changed)
    command = m.command(unit['recipe']['path'], changed, W / 'compile2/common')
    b.save(W / 'recipes2/common.json', dict(command=command, cwd=str(R), timeout_seconds=180))
    unit['command_template'] = b.pin(W / 'recipes2/common.json')
    unit['planned_object'] = str(W / 'compile2/common/unit.obj')
    command = b.read(p['link_template']['path'])['command']
    before = str(W / 'compile/common/unit.obj')
    assert command.count(before) == 1
    command = [unit['planned_object'] if arg == before else arg for arg in command]
    b.save(W / 'link-command-template2.json', dict(command=command, cwd=str(R), timeout_seconds=120))
    p['link_template'] = b.pin(W / 'link-command-template2.json')
    b.save(W / 'frozen-plan2.json', p)
    compiled = b.read(W / 'compiled-partial.json')
    assert [row['name'] for row in compiled] == ['resources', 'slots']
    for row in compiled:
        b.exact(row['object'])
        for dependency in b.read(row['actual_dependencies']['path']):
            path = Path(dependency['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert own[b.key(path)]['sha256'] == dependency['sha256'], str(path)
    h, env = recipe.environment(p)
    for unit in p['units'][2:]:
        out = W / ('compile2/common' if unit['name'] == 'common' else 'compile/' + unit['name'])
        process = h.execute(b.read(unit['command_template']['path'])['command'], env, out, timeout=180)
        deps = b.read(out / 'dependencies.json')['Data']
        actual = [b.pin(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])]
        b.save(out / 'actual-dependencies.json', actual)
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert own[b.key(path)]['sha256'] == row['sha256'], str(path)
        compiled.append(dict(name=unit['name'], source=unit['source'], object=b.pin(out / 'unit.obj'),
            process=process, actual_dependencies=b.pin(out / 'actual-dependencies.json')))
        b.save(W / 'compiled-partial2.json', compiled)
    for row in updated:
        b.exact(row)
    image = Path(p['image'])
    image.parent.mkdir(parents=True, exist_ok=True)
    linked = h.execute(b.read(p['link_template']['path'])['command'], env, W / 'link', timeout=120)
    before = b.read(p['baseline']['inputs']['path'])
    objects = {row['name']: row['object'] for row in compiled}
    replacements = {b.key(unit['baseline_object']['path']): objects[unit['name']]
                    for unit in p['units'] if unit['action'] == 'replace'}
    inputs = [replacements.get(b.key(row['path']), row) for row in before]
    inputs += [objects[unit['name']] for unit in p['units'] if unit['action'] == 'add']
    assert len(before) == 228 and len(inputs) == 229
    b.save(W / 'link-inputs.json', inputs)
    runtime = b.read(p['baseline']['runtime']['path'])
    native = runtime['native_cpu']
    b.exact(native)
    alias = image.parent / Path(native['path']).name
    os.link(native['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), compiled=compiled,
        link=linked, inputs=b.pin(W / 'link-inputs.json'), runtime=b.pin(W / 'runtime.json'),
        frozen_plan=b.pin(W / 'frozen-plan2.json'),
        counts=dict(distinct_CXX_TUs=6, compiler_attempts=7, failed_compiles=1, links=1, images=1,
                    test_processes=0, NVCC=0, SDK=0), first_failure=b.pin(W / 'build-failure.json')))
    print('READY', json.dumps(b.pin(W / 'ready.json')), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        b.save(W / 'continue-failure.json', dict(error=traceback.format_exc(), note='Original outputs retained; stopped without automatic retry.'))
        raise
