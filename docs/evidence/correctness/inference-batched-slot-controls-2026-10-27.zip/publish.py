"""Archive the actual two-image result; no builds, tests, binaries, or SDK copying."""
from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
PUBLIC = R / 'docs/evidence/correctness/inference-batched-slot-controls-2026-10-27.json'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    Path(path).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def xml_run(xml, folder, image):
    root = ET.parse(xml).getroot()
    cases = []
    for case in root.findall('./testsuite/testcase'):
        assert case.attrib.get('status') == 'run'
        assert case.attrib.get('result', 'completed') == 'completed'
        assert not case.findall('skipped')
        failures = [child.attrib.get('message', '') or child.text or '' for child in case.findall('failure')]
        cases.append(dict(name=case.attrib['classname'] + '.' + case.attrib['name'],
                          status='FAIL' if failures else 'PASS', attributes=case.attrib, failures=failures))
    assert len(cases) == int(root.attrib['tests'])
    assert int(root.attrib.get('disabled', '0')) == int(root.attrib.get('errors', '0')) == 0
    assert sum(case['status'] == 'FAIL' for case in cases) == int(root.attrib['failures'])
    return dict(image=image, process=read(folder / 'process.json'), process_receipt=pin(folder / 'process.json'),
                command=pin(folder / 'command.json'), xml=pin(xml), tests=cases,
                count=len(cases), passed=sum(case['status'] == 'PASS' for case in cases),
                failed=sum(case['status'] == 'FAIL' for case in cases), skipped=0)


def main():
    assert not PUBLIC.exists() and not PUBLIC.with_suffix('.zip').exists()
    assert not (W / 'evidence.zip').exists()
    first, second = read(W / 'ready.json'), read(W / 'ready2.json')
    runs = [xml_run(W / ('results-' + kind + '.xml'), W / ('run-' + kind), first['image']) for kind in ['cpu', 'cuda']]
    runs += [xml_run(W / ('results2-' + kind + '.xml'), W / ('run2-' + kind), second['image']) for kind in ['cpu', 'cuda']]
    assert [(row['count'], row['passed'], row['failed']) for row in runs] == [(20, 18, 2), (9, 8, 1), (2, 2, 0), (1, 1, 0)]
    failed = {case['name'] for row in runs[:2] for case in row['tests'] if case['status'] == 'FAIL'}
    retried = {case['name'] for row in runs[2:] for case in row['tests']}
    assert len(failed) == 3 and failed == retried
    all_first = [case['name'] for row in runs[:2] for case in row['tests']]
    assert len(all_first) == len(set(all_first)) == 29
    final = {case['name']: dict(status=case['status'], image=row['image'], pid=row['process']['pid'])
             for row in runs for case in row['tests']}
    assert len(final) == 29 and all(row['status'] == 'PASS' for row in final.values())
    compile_dirs = [W / path for path in ['compile/resources', 'compile/slots', 'compile/common',
        'compile2/common', 'compile/bindings-test', 'compile/cpu-test', 'compile/cuda-test',
        'compile3/cpu-test', 'compile3/cuda-test']]
    compiles = []
    for directory in compile_dirs:
        command = read(directory / 'command.json')['command']
        source = next(arg for arg in command if arg.casefold().endswith('.cc'))
        compiles.append(dict(source=source, process=read(directory / 'process.json'),
                             command=pin(directory / 'command.json')))
    assert len({row['source'].casefold() for row in compiles}) == 6
    assert sum(row['process']['exit'] != 0 for row in compiles) == 1
    baseline = read(W / 'plan.json')['baseline']
    final_plan = read(second['frozen_plan']['path'])
    prior_receipt = R / 'docs/evidence/correctness/inference-indexed-conv-graph-2026-10-27.json'
    receipt = dict(
        status='29_UNIQUE_COMPONENT_CASES_PASS_ACROSS_TWO_IMAGES', date='2026-10-27',
        scope='SlotBindings metadata reuse/refill and grouped private slot controls; CPU/CUDA component contracts only.',
        counts=dict(distinct_CXX_translation_units=6, compiler_attempts=9, successful_compiles=8,
                    failed_compiles=1, links=2, built_images=2, executed_images=2,
                    test_processes=4, test_executions=32, unique_cases=29, final_unique_passes=29,
                    initial_case_failures=3, skipped=0, NVCC=0, SDK_builds=0,
                    model_runs=0, benchmarks=0, downloads=0),
        outcome='Image 1 ran CPU20 and CUDA9: 26 passed, three new batch fixtures failed before their intended execution. Only those three fixtures were rebuilt and retried on image 2; all passed. Image 2 did not rerun the other 26 cases.',
        implementation=[
            'SlotBindings::clear releases old lease/address facts while retaining prepared metadata and counts; refill checks all original domain/generation/extent facts before consuming any caller writer.',
            'Common Store controls group by actual resource, ExecutionSource and original Queue identity; one fixed I32 carrier holds disjoint per-Store source/destination slices and uploads once per original group.',
            'Batch bind validates a complete cohort, duplicate owners and real permissions before moving transactions. A late read-projection failure withdraws earlier installed permissions and returns all original caller transactions.',
            'A partial take cannot overwrite a shared carrier while another transaction remains. Real result/completion retirement and reset revocation retain the original guards and owner-return contracts.',
            'The two resource reservation callers now pass only their new required reads; reserve_reads itself already includes the existing bindings.'
        ],
        checked_contracts=dict(
            refill='Two new GraphSlots cases verify unchanged metadata addresses and no new attempts from the rejecting metadata allocator, old read guards released, live-writer/count/foreign-domain rejection and unchanged caller ownership.',
            accounting='The retained metadata-failure case checks failed-allocation cleanup, metadata-only ResourceBudget charges, unchanged payload pool allocation, clear retaining its metadata charge, and full refund when the transaction owner is destroyed.',
            batch_cpu='Two new cases check same carrier/different slice offsets over two rounds, changed slot order via refill, partial/duplicate cohort rejection, partial-take gating, reset recovery and a deliberately late real permission failure with successful retry after removing only the blocker.',
            batch_cuda='The new double-Store case runs two rounds on the original CUDA Queue, verifies one device carrier with fixed disjoint offsets and changed IDs, checks copied values and untouched sentinel slots; partial bind leaves caller owners intact.',
            retained_cuda_regressions='The original indexed GDN3 and conv4 cases all passed on image 1 after the product changes, including the conv F32 two RequireCapture submissions with record1/reuse0 then changed-destination record0/reuse1, BF16 long chunk, F16 raw history bits, and legal escaping-Gather fallback.'),
        boundaries=[
            'No claim that the whole bind/submit path performs zero allocations: only the explicit refill metadata allocator contract and fixed carrier identities were tested.',
            'The Apple/Vulkan original-native ExecutionSource upload branch was not run in this batch. Its temporary helper metadata uses the selected/budget allocator; queried native payload scratch is separately reserved and refunded on success, retained on possibly accepted failure. This is source-reviewed accounting, not native-fault injection or a measured no-allocation claim.',
            'CPU direct-host and common CUDA Queue controls executed. CUDA Store/GDN/conv kernels did execute; zero NVCC means no native recompilation, not absence of GPU execution.',
            'No real GPU fault, unknown-retirement fault injection, full model/engine run, MTP quality assessment, tokens/s measurement, memory performance comparison or speedup conclusion.',
            'GTest/process durations are preserved for provenance and are not performance benchmarks.',
            'The complete final image did not rerun all 29 cases: final status combines 26 prior passes with three successful fixture-only retries.'
        ],
        failures=[
            dict(kind='C++ compile', source='src/graph/slots_region.cc:850', pid=12580,
                 observed='Unqualified single-request wrapper bind with std::array participated in std::bind overload resolution; C2440.',
                 correction='Qualify the existing slots::bind overload and pass an explicit span. The same final source also clears borrowed scratch references on every return without allocation.',
                 retained_source=pin(W / 'source/src/graph/slots_region.cc'),
                 corrected_source=pin(W / 'source2/src/graph/slots_region.cc')),
            dict(kind='Three test-fixture failures', observed='Three new batch fixtures threw Bad expected access.',
                 diagnosis='Source inspection located the unchecked GraphBuilder.finish result: two unknown external Store effects lacked the required explicit ordering edge.',
                 correction='Only CPU/CUDA test fixtures add Store1 depends_on Store0 and clearer Result status diagnostics. Product objects are identical between the two executed images.',
                 original_sources=[pin(W / 'source/tests/graph/slots_execution_test.cc'), pin(W / 'source/tests/graph/slots_cuda_execution_test.cc')],
                 corrected_sources=[pin(W / 'source3/tests/graph/slots_execution_test.cc'), pin(W / 'source3/tests/graph/slots_cuda_execution_test.cc')],
                 retried_exact_cases=sorted(retried))
        ],
        provenance=dict(baseline=baseline, original_closure=pin(prior_receipt),
            original_closure_archive=pin(prior_receipt.with_suffix('.zip')),
            original_inputs=228, final_inputs=229, initial_replaced_objects=5, initial_added_objects=1,
            second_image_replaced_objects=2, product_objects_rebuilt_for_second_image=0,
            final_input_metadata=pin(W / 'link2-inputs.json'),
            first_input_metadata=pin(W / 'link-inputs.json'),
            images=[first['image'], second['image']],
            ready=[pin(W / 'ready.json'), pin(W / 'ready2.json')],
            freezes=[pin(W / ('frozen-plan' + suffix + '.json')) for suffix in ['', '2', '3']],
            source_closure_hash_records=[pin(W / ('source-freeze' + suffix + '.json')) for suffix in ['', '2', '3']],
            source_hash_record_count=len(read(W / 'source-freeze3.json')),
            compiler_attempts=compiles,
            links=[dict(process=read(W / name / 'process.json'), command=pin(W / name / 'command.json')) for name in ['link', 'link2']],
            runtime=[pin(W / 'runtime.json'), pin(W / 'runtime2.json')],
            hardware='Actual CUDA stderr reports NVIDIA GeForce RTX 4070, capability 8.9, 12281 MiB; full toolchain/device identities are referenced from the unchanged indexed-conv baseline receipt, not freshly queried here.'),
        runs=runs, final_unique_case_results=final,
        archive_policy='Only necessary new source snapshots, commands, logs, XML, dependency and object-closure hash metadata. No SDK/header tree, executable, object, library, DLL or model payload.')
    save(W / 'receipt.json', receipt)
    files = [W / name for name in ['prepare.py', 'build.py', 'build-attempt1.py', 'continue.py',
        'retry-fixtures.py', 'publish.py', 'plan.json', 'frozen-plan.json', 'frozen-plan2.json',
        'frozen-plan3.json', 'source-freeze.json', 'source-freeze2.json', 'source-freeze3.json',
        'link-command-template.json', 'link-command-template2.json', 'link-command-template3.json',
        'link-inputs.json', 'link2-inputs.json', 'runtime.json', 'runtime2.json', 'ready.json', 'ready2.json',
        'receipt.json', 'results-cpu.xml', 'results-cuda.xml', 'results2-cpu.xml', 'results2-cuda.xml',
        'summary2-cpu.json', 'summary2-cuda.json']]
    files += list(W.glob('*-failure.json'))
    for name in ['source', 'source2', 'source3', 'recipes', 'recipes2', 'recipes3']:
        files += [path for path in (W / name).rglob('*') if path.is_file()]
    for folder in [*compile_dirs, W / 'link', W / 'link2',
                   W / 'run-cpu', W / 'run-cuda', W / 'run2-cpu', W / 'run2-cuda']:
        files += [folder / name for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log',
                  'actual-dependencies.json', 'dependencies.json'] if (folder / name).is_file()]
    files = sorted(set(files))
    assert all(path.is_relative_to(W) and path.suffix.casefold() not in ['.obj', '.exe', '.lib', '.dll', '.pdb'] for path in files)
    manifest = [dict(archive_path=path.relative_to(W).as_posix(), **pin(path)) for path in files]
    save(W / 'archive-files.json', manifest)
    archive = W / 'evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for path in files + [W / 'archive-files.json']:
            z.write(path, path.relative_to(W).as_posix())
    shutil.copyfile(archive, PUBLIC.with_suffix('.zip'))
    receipt['archive'] = pin(PUBLIC.with_suffix('.zip'))
    receipt['archived_files'] = len(files) + 1
    receipt['archive_manifest'] = pin(W / 'archive-files.json')
    save(PUBLIC, receipt)
    save(W / 'publication.json', dict(receipt=pin(PUBLIC), archive=receipt['archive'],
        archived_files=receipt['archived_files'], status=receipt['status']))
    print(json.dumps(read(W / 'publication.json'), ensure_ascii=False))


if __name__ == '__main__':
    main()
