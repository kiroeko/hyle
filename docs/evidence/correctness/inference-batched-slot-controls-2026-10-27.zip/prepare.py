"""Prepare recipes only. This script never compiles, links, or executes tests."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-indexed-conv-20261027'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path = Path(path)
    assert path.is_relative_to(W)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def key(path):
    return str(path).replace('/', '\\').casefold()


def command(recipe, source, out):
    """Retarget the existing CXX recipe without changing its compiler/macros."""
    result = []
    skip_next = False
    source_count = 0
    for argument in read(recipe)['command']:
        if skip_next:
            result.append(str(out / 'dependencies.json'))
            skip_next = False
        elif argument.casefold() == '/sourcedependencies':
            result.append(argument)
            skip_next = True
        elif argument.casefold().startswith('/fo'):
            result.append('/Fo' + str(out / 'unit.obj'))
        elif argument.casefold().startswith('/fd'):
            result.append('/Fd' + str(out / 'unit.pdb'))
        elif argument.casefold().endswith(('.cc', '.cpp', '.cxx')):
            result.append(str(source))
            source_count += 1
        else:
            result.append(argument)
    assert source_count == 1 and not skip_next
    assert all(flag in result for flag in ['/O2', '/W4', '/WX', '/MD', '/DHYLE_STATIC'])
    return result


def prepare():
    baseline = read(B / 'link2-inputs.json')
    assert len(baseline) == 228
    baseline_by_key = {key(row['path']): row for row in baseline}
    assert len(baseline_by_key) == 228
    specs = [
        ('resources', 'src/graph/resources.cc',
         '.scratch/inference-slot-source-fallback-20261027/compile/resources', True),
        ('slots', 'src/graph/slots.cc',
         '.scratch/inference-slot-bindings-20261027/compile/slots', True),
        ('common', 'src/graph/slots_region.cc',
         '.scratch/inference-native-slot-store-20261027/windows-vulkan/compile/common', True),
        ('bindings-test', 'tests/graph/slot_bindings_test.cc',
         '.scratch/inference-slot-bindings-20261027/compile/test', False),
        ('cpu-test', 'tests/graph/slots_execution_test.cc',
         '.scratch/inference-cpu-storage-gather-20261027/compile2/slots-test', True),
        ('cuda-test', 'tests/graph/slots_cuda_execution_test.cc',
         '.scratch/inference-slot-store-20261027/attempt2/compile/cuda-test', True),
    ]
    units = []
    replacements = {}
    addition = None
    for name, source, original, replace in specs:
        original = R / original
        before = pin(original / 'unit.obj')
        is_linked = key(before['path']) in baseline_by_key
        assert is_linked == replace, name
        if replace:
            assert before == baseline_by_key[key(before['path'])], name
        actual = original / 'actual-dependencies.json'
        if not actual.exists():
            actual = original / 'actual-canonical-dependencies.json'
        dependencies = read(actual)
        if isinstance(dependencies, dict):
            dependencies = dependencies.get('dependencies', dependencies.get('canonical'))
        assert isinstance(dependencies, list), str(actual)
        source_rows = [row for row in dependencies if key(row['path']) == key(R / source)]
        assert len(source_rows) == 1, name
        out = W / 'compile' / name
        recipe_path = W / 'recipes' / (name + '.json')
        save(recipe_path, dict(command=command(original / 'command.json', R / source, out),
             cwd=str(R), timeout_seconds=180, status='TEMPLATE_SOURCE_NOT_FROZEN'))
        after = str(out / 'unit.obj')
        if replace:
            replacements[key(before['path'])] = after
        else:
            addition = after
        units.append(dict(name=name, source=str(R / source), source_frozen=False,
            recipe=pin(original / 'command.json'), command_template=pin(recipe_path),
            actual_old_dependencies=pin(actual), old_compiled_source=source_rows[0],
            baseline_object=before if replace else None,
            unlinked_old_test_object=before if not replace else None,
            action='replace' if replace else 'add', planned_object=after))
    assert len(replacements) == 5 and addition
    image = W / 'bin/batched-slot-controls-test.exe'
    link = []
    changed = 0
    for argument in read(B / 'link2/command.json')['command']:
        if key(argument) in replacements:
            link.append(replacements[key(argument)])
            changed += 1
        elif argument.upper().startswith('/OUT:'):
            link.append('/OUT:' + str(image))
        elif argument.upper().startswith('/PDB:'):
            link.append('/PDB:' + str(image.with_suffix('.pdb')))
        elif argument.upper().startswith('/IMPLIB:'):
            link.append('/IMPLIB:' + str(image.with_suffix('.lib')))
        elif argument.upper().startswith('/MAP:'):
            continue
        else:
            link.append(argument)
    assert changed == 5
    link.append(addition)
    save(W / 'link-command-template.json', dict(command=link, cwd=str(R),
         timeout_seconds=120, status='TEMPLATE_NOT_LINKED'))
    save(W / 'plan.json', dict(status='PREPARED_WAITING_FOR_SOURCE_FREEZE',
        counts=dict(CXX_TUs=6, native_TUs=0, SDK_builds=0, images_planned=1,
                    baseline_inputs=228, replacements=5, additions=1,
                    final_inputs=229, reused_inputs=223,
                    actual_compiles=0, actual_links=0, actual_test_processes=0),
        baseline={name: pin(B / path) for name, path in [
            ('ready', 'ready2.json'), ('inputs', 'link2-inputs.json'),
            ('command', 'link2/command.json'), ('runtime', 'runtime2.json')]},
        prior_evidence=pin(R / 'docs/evidence/correctness/inference-indexed-conv-graph-2026-10-27.json'),
        units=units, link_template=pin(W / 'link-command-template.json'),
        image=str(image),
        runtime='Reuse baseline runtime2.json PATH and exact native_cpu DLL. If needed, make one hard link in the new bin; do not copy SDK/native DLL trees.',
        ABI=dict(expected='Additive entry points and pimpl-only changes; no public/private Node, Recipe, StoreRegionVTable, provider, native, or Graph plan layout change.',
                 status='Owner-reported; confirm against final source freeze before compiling. No unfinished product source has been read or pinned by this preparation.'),
        groups=[
            dict(name='cpu', filter='GraphSlots.*:GraphSlotsExecution.*:CpuStorageGather.*',
                 expected_by_suite={'GraphSlots': 8, 'GraphSlotsExecution': 10, 'CpuStorageGather': 2},
                 exact_tests=None, status='Planned counts; enumerate final frozen sources before running.'),
            dict(name='cuda', filter='GraphSlotsCudaExecution.*:GgmlCudaIndexedStateGraph.*:GgmlCudaIndexedConvGraph.*',
                 expected_by_suite={'GraphSlotsCudaExecution': 2, 'GgmlCudaIndexedStateGraph': 3, 'GgmlCudaIndexedConvGraph': 4},
                 exact_tests=None, status='Existing GDN3+conv4 unchanged; new CUDA batch case name pending root freeze.'),
        ],
        reusable_helpers=dict(module=str(R / '.scratch/inference-slot-source-fallback-20261027/build.py'),
            import_note='Set sys.dont_write_bytecode=True before importlib import. Import has a main guard.',
            APIs=['b.read(path)', 'b.save(path,value)', 'b.pin(path)', 'b.exact(pin)', 'b.key(path)',
                  'm.command(recipe,canonical_source,outdir)', 'm.c.closure(sources,recipes)',
                  'b.helper().discover_environment(...)', 'helper.execute(command,env,outdir,timeout=...)'],
            phase_boundary='Prepare only now. Later freeze/snapshot actual source+headers, compile6 and link1 separately from two explicit run commands. Preserve actual sourceDependencies and first failures; stop on failure.'),
        exclusions=['No NVCC, SDK, shaders or native library rebuild.',
                    'No model, benchmark, server, network, or download.',
                    'No execution or source freeze in this preparation.',
                    'No changes outside this new scratch directory.']))
    print(json.dumps(dict(plan=pin(W / 'plan.json'), units=6, final_inputs=229,
                         compiles=0, links=0, runs=0)))


if __name__ == '__main__':
    prepare()
