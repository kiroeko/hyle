"""Finite state and changed grouped-FP8 checks; never a throughput benchmark."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BA = R / '.scratch/glm-mtp-carry-20261022'
spec = importlib.util.spec_from_file_location('state_run', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
parser = argparse.ArgumentParser()
parser.add_argument('--link-attempt', type=int, default=1)
parser.add_argument('--run-attempt', type=int, default=1)
parser.add_argument('--gtest-filter', default='*')
parser.add_argument('--expected-tests', type=int, required=True)
args = parser.parse_args()
folder = S / f'tests-link{args.link_attempt}'
image = h.read(folder / 'ready.json')['image']
assert h.ident(image['path']) == image
env = os.environ.copy()
env['PATH'] = h.read(folder / 'runtime-environment.json')['PATH']
env['HYLE_GLM_MTP_INPUT_DIR'] = str(R / '.scratch/dspark-natural-journey-20261022/original-glm-input')
env['HYLE_GLM_MTP_QUERY_DIR'] = str(BA / 'original-glm-q-a')
env['HYLE_GLM_MTP_CHAIN_DIAGNOSTICS_DIR'] = str(S / f'diagnostics{args.run_attempt}')
out = S / f'checks{args.run_attempt}'
xml = out / 'results.xml'
command = [image['path'], '--gtest_filter=' + args.gtest_filter, '--gtest_output=xml:' + str(xml)]
print('START finite GLM state / grouped-original / scale-neighbor checks', flush=True)
process = h.execute(command, env, out, timeout=600)
result = dict(process=process, image=image, throughput_evidence=False, memory_evidence=False,
              whole_original_model=False)
if xml.is_file():
    root = ET.parse(xml).getroot()
    result.update(tests=int(root.attrib['tests']), failures=int(root.attrib['failures']),
        errors=int(root.attrib['errors']), disabled=int(root.attrib['disabled']),
        skips=sum(case.find('skipped') is not None for case in root.iter('testcase')),
        cases=[dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value']
            for p in case.iter('property')}) for case in root.iter('testcase')])
h.save(out / 'summary.json', result)
assert process['exit'] == 0 and not process['timed_out'], process
assert result.get('tests') == args.expected_tests, result
assert not any(result[k] for k in ('failures', 'errors', 'disabled', 'skips')), result
print('PASS finite GLM checks', result['tests'], flush=True)
