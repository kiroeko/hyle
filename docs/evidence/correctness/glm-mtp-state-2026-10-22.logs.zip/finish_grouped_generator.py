"""Keep the existing checked-ID kernel and compare maintainer header payloads."""
from pathlib import Path
import argparse
import hashlib
import json
import re

S = Path(__file__).resolve().parent
R = S.parents[1]
T = R / 'third_party/sglang_activation/fp8/grouped'

def arrays(path):
    text = path.read_text(encoding='utf-8')
    return {name: bytes(int(v, 16) for v in re.findall(r'0x([0-9a-fA-F]{2})', body))
        for name, body in re.findall(r'unsigned char (\w+)\[\] = \{([^}]+)\};', text, re.S)}

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['align-input', 'compare'])
args = parser.parse_args()
old = arrays(S / 'grouped-repair/before/sglang_grouped_fp8_sm89.h')
current = arrays(T / 'sglang_grouped_fp8_sm89.h')
assert old['kCheckedAlign'] == current['kCheckedAlign']
assert hashlib.sha256(current['kCheckedAlign']).hexdigest() == json.loads((T / 'align-compilation.json').read_text())['cubin_sha256']
if args.action == 'align-input':
    (S / 'maintainer-grouped/checked_original_align.cubin').write_bytes(current['kCheckedAlign'])
else:
    generated = arrays(S / 'maintainer-grouped/sglang_grouped_fp8_sm89.h')
    assert generated == current
    report = dict(generated_payloads_match_installed=True, align_image_unchanged=True,
        images={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in current.items()},
        grouped_shared_bytes={x['label']: x['metadata']['shared'] for x in json.loads((T / 'compilation.json').read_text())['kernels']})
    (S / 'maintainer-grouped/receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
