# MTP 剩项收敛：通用机制、模型接线与覆盖限制

日期：2026-10-22。只读审查；未改产品或正式文档，未编译、下载、执行模型或重跑检查。
范围仍为当前八个正式文本模型和已选量化／provider 路由；不加 preview、新模型、八套完整引擎或组合验证矩阵。

## 结论

本次未发现必须先新建公共 MTP 算子、状态 API、执行器或模型缓存管理器的证据。真正尚未闭合的是**模型定义的状态成员与实际 producer 输出，沿现有 Graph／ReadLease／StateDraft／StateHead 组合**，以及原制品所需参数能够替换生成参数的接线。

“通用状态机制已具备”和“某模型的完整续算状态已接对”必须分别判断。不能用小组件通过代签整个模型，也不能因为没有加载完整 43 层／27B／2.4T 原模型，就自动创造另一套完整推理引擎任务。

本审查基于本轮开始时工作树；新 GLM 完整状态消费者仍由主代理实现，其未执行部分不在这里写成通过。

## 已有机制，不应重造

| 已有源码／证据 | 已承载内容 | 没有代签的内容 |
| --- | --- | --- |
| `include/hyle/compute/state_versions.h` | 任意有限 schema；资源／不解释的 host metadata；成功只读成员；有界版本／字节；Draft 原子完成、StateHead 按旧 identity 发布；旧读者保 owner | 库不替模型猜哪些成员属于同一接受边界，也不解释位置／epoch |
| `tests/compute_state/mtp_prefix_consumer.h` | 实际 GDN chronological snapshot 子区间＋conv tail＋K/V＋长度，接受 0～4 后继续计算，Direct／Graph | K/V 是有限输入 bank；不是已选 GLM 的 MLA／pool／tail 组合，也不是完整原模型 |
| `tests/compute_state/mtp_hybrid_consumer.h` | 选中的真实 snapshot／conv tail，经 CopyBatch／StateCloneRoute 搬运 CPU↔CUDA 后继续 Direct／Graph；只搬实际接受范围 | 不代表所有 GLM dtype／codec 的混合放置已运行 |
| `tests/compute_state/kda_prefix_consumer.h` | GLM Flash projected QKV／gate 边界 H64/D128，conv→SiLU→规范化→逐 channel decay GDN；接受 0～3，真实 snapshot＋history＋cursor 原子发布后续算；失败不换 head | 参数及投影输入生成；不包含 GLM 完整 target，也不使 NextN 本身成为 KDA 层 |
| `tests/compute_models/glm_mtp_index_carry_test.cc`、`docs/evidence/correctness/glm-mtp-carry-2026-10-22.json` | CPU／CUDA 各 7 Graph：实际 I32 producer lease→无 indexer 的 Gather／SDPA→StateHead；IDs／key／gate／epoch 四成员；begin／真 seed／finally／旧只读边界 | skip query／MLA cache 外部生成，未与完整 NextN／target 状态同时选择 |
| `tests/compute_models/glm_original_mtp_chain_test.cc`、同份 GLM 证据 | 原 layer45 七角色 73,429,504B；原 norm／EH→input norm→FP8 q_a→qnorm 的真实输出租约进入生成 BF16 wq_b，CPU／CUDA 各三代 6 Graph；已修实际暴露的 CUDA FP8 dot 数值问题 | 后继 wq_b 仍生成，未到完整 indexer、MLA／pool-tail 或接受前缀状态 |
| `tests/compute_state/dspark_accepted_prefix_fixture.h`、`dspark_prefix_consumer_test.cc` | ratio4／128 target 资源＋三 main rings＋carry＋pending／frontier；verify6／接受输入 0～6；失败／stale head／下一输入续算；原子 StateHead | projected target 与生成 catchup 参数，不能证明原 trained target 或所有原 stage 参数 |

上表是已存在的机制及列明证据；本轮没有再次执行。旧源码中的 `check_index_carry` 经 host 观察再构造输入的限制，已由实际 I32 lease 消费者补上一段，不能继续笼统列为“没有 index carry”。

## GLM：下一批具体代码应组合什么

### 必要状态按实际模型语义确定

1. **Target 自己的续算状态**：普通 GLM 的 MLA latent／RoPE／位置与 index history；Flash target 中实际 KDA 层的 recurrence＋conv tail，以及实际 MLA／index 层的历史和位置。不能复制 Qwen 固定成员数。Flash NextN 是普通 NoPE MLA／DSA＋FFN residual，**不应添加假的 NextN KDA／mHC 状态**。
2. **Draft NextN 的输入／输出边界**：采用 source 要求的 hidden 来源、自己的 MLA cache 和有效位置；其当前 `mtp_decoder` 虽有 hidden／history ports，但与 indexer 是分开的有限片段。需要按同一真实输入前沿接起来，不能仅将两份各自通过的片段列为完成。
3. **Index 所需的可续算历史**：index keys，Flash 的 learned gates／K4 尾部及必要偏移／validity，当前选择对应的 query／history 来源。APE、norm、投影参数为只读权重，不是每轮可变状态。保存实际表示足以完整续算即可；若保存 raw key／gate 并显式重算 pooled rows，不必再强制保存重复的 raw＋pooled 全银行，但重算成本须如实计入。若使用增量 pooled cache，则完整保存已完成池和未满 K4 尾窗。
4. **同迭代选择 carry**：实际 I32 lease 和 epoch／producer／history 资格。固定 SGLang 的 `mtp_iteration` 默认清空、显式真 seed 才保留、finally 清空并禁止复用。旧 lease 可读不等于新迭代可复用；不能把 ephemeral selection 永久当成所有后续 query 的缓存。
5. **协议边界**：已消费 target／draft frontier、位置／长度、未消费 pending、所选 hidden／lag，以及本模型需要的分支状态。接受前缀时所有成员必须对应同一输入前沿；不得仅截 MLA 长度却保验证尾部的 KDA／pool／carry。

### 可完成的接线步骤

| 具体工作 | 直接复用的位置／机制 | 结束条件与保留限制 |
| --- | --- | --- |
| 将实际原 query 输出接入 indexer 后继，补完整 sparse attention 的实际输入依赖 | 原链 qnorm ReadLease；`d5_glm_remaining_fragments.h::indexer`／`sparse_attention`；现有 typed bind | query／indexer／MLA 使用同一版本输入；不经 host 读回重造 producer tensor。仍可保明确的 projected 输入边界，但不能称其为原 target hidden |
| 从实际 MLA、index key／gate、K4 pool／tail 生产者取得候选状态 | 上述 fragment 已有 cache feedback ports；既有 GDN snapshots／conv tails | 将实际结果租约或其有权限的 subview 存入 schema；不把 oracle 上传当运行状态。当前 indexer 的固定 history eviction 是 fixture 语义，不能未经说明外推任意长上下文 |
| 对同一次 verify 的所有必要状态选同一接受前缀，并实际继续一个新输入 | `StateStore::begin`→replace 各资源及 metadata→finalize→`StateHead::publish`；KDA／prefix 现有 recipe | 续算直接读已发布 head 的成员；prefix0 保原 head；未接受尾部不可见；旧版本仍只读可用。不要只用改 host cursor 演示回滚 |
| 将单层／projected 消费者的 scope 写清，同时保留完整模型所需成员描述 | 一个模型消费者内的 parameterized schema 和边界定义 | 可以证明已声明组件边界及通用组合，不替代未运行完整 trunk；若实际 target 相关成员未接，应继续明确列未完成 |

优先顺序建议：**状态组合优先于继续逐个下载互不相接的原 tensor**。原 query 链和实际 index carry 都已具备，下一次进展应使真实状态从同一个已发布版本进入后继并回来。若此过程暴露公共合同／provider bug，应修所属层，不用新 wrapper 隐藏。

## DSpark：缺参数与 target tap 接线，非缺通用接受机制

已存在的 `dspark_complete_graph_fixture.h::build_flash` 只允许注入原 W1／W2／confidence；其 stage 和共享 LM 仍生成，`main_bridge` 仍将有限 target attention 重复扩成 4096 hidden、用 17-token head 验证。这是明确边界，不是原 target captures。

具体代码项：

1. **参数供给扩展**：让已有三 stage Graph 从所选正式制品的 typed role bank 取得 main_proj／main_norm、attention／FFN／norm／mHC 及共享 embedding／LM；保实际 codec／scale、权重身份和共享 owner。先补缺的参数入口／布局适配，不能把“没有下载每一个同合同 tensor”全部误称为公共功能缺口。
2. **Target captures 入口**：用声明的只读 Graph 输出租约接三个实际 layer taps，按固定正式模型定义的层顺序、dtype、位置、批行／接受前沿 concat→main_proj→main_norm。Flash 是 40／41／42，Pro 是 58／59／60；不能将 Flash 参数或 preview 作为 Pro 来源。可以由外部真实 target 提供 taps，Hyle 消费者不必拥有完整原 target 引擎；但人工输入或重复投影不得叫真实 captures。
3. **Verified-main catchup**：每个 stage 用自身实际参数更新持久 main KV；只接 verified main 历史，proposal 的私有 KV 不发布。三 rings／carry／target 资源／frontier／pending 继续用现有完整 candidate 一次发布，不再造接受状态框架。
4. **共享 LM 与输出语义**：绑定真实归属的共享 head，而非为每个 draft 复制模型；保持 raw collapsed hidden 用于官方 confidence，LM 用 normalized hidden，sidecar sigmoid 策略另列。

把原 stage 参数换进去以及 tap provenance 接对，是具体剩余实现；未跑完整 GA target 的 TPS、接受率、质量为覆盖限制。现有自然旅程四轮均拒绝 proposal 不能证明原模型接受率；独立接受 0～6 的状态检查也不能代替真实自然接受分布。

## 其它模型／量化应保留的具体范围

- Q27／Q24：已有原 EH／norm、原 Q24 K/V 及各自 generated NextN recipe。还应把所选主制品实际角色／codec供给接到对应组件，描述 target＋draft 完整状态边界。Q27 的历史 C4 sidecar 与主 GGUF 不同；Q24 当前 primary Q5_K／Q4_K／Q6_K／Q8_0 混合不能退回旧 UD-IQ1_M。是否缺新公共算子，要由实际接口／格式失败证明，不能仅由原 payload 未全部载入推定。
- 已确认带 MTP 的已选派生格式，其真实 codec／scale／packing 是实际接线范围；不排除它们来缩小完成定义。33 条发现记录不是 33 个已确认完整引擎任务，未知存在性应列 metadata 未核，而非默认“缺实现”。
- Kimi 固定原制品 nextn=0；Qwen3.5 两个 baseline GGUF 明确排除 R13。没有肯定制品证据时，不从模型 family 或量化名字创造 MTP 任务。

## 只应报告为覆盖限制的事项

- 未运行完整原 Q27／Q24／GLM／DeepSeek trunk，未执行所有平台／codec 组合；这不等于通用机制不存在，也不使一个小组件通过变成整模型通过。
- 还有未读取的同合同原 tensor 值、未核定的精确 derivative MTP 元数据；若缺少值会妨碍已选实际消费者，则明确剩余绑定，不机械创建每张量测试或要求全量大模型下载。
- CPU／CUDA 的本批证明不签 Linux、Apple、Vulkan 原 payload 全组合；修实际问题，保未验证项，不新增穷举门。
- 当前最新完整速度／显存仍是 AV；本轮 GLM 原角色和 state source review 不带来新 TPS、接受率或物理内存结论。

## 查阅入口

- 当前需求：`docs/developer/current-work.md`；角色总表：`docs/implementation/model-operators.md`。
- 先前剩项审查：`.scratch/qwen24-original-mtp-20261022/review/remaining-mtp.json`，其中“Q24 在做”“GLM 原 q_a／carry 未过”已由 AZ 和本轮实际证据更新，不能当当前未完成列表照抄。
- 当前 GLM：`docs/evidence/correctness/glm-mtp-carry-2026-10-22.json`，`checks1/summary.json` 与 `chain-checks4/summary.json`。
- DSpark：`docs/evidence/correctness/mtp-natural-journey-2026-10-22.json`，`dspark-mtp-composition-2026-10-22.json`；原参数读者 `tests/compute_models/dspark_original_roles.h`；完整状态定义见前表。
- 固定 SGLang `06992c92ad4494fe9f9636e75be3e35040512447`：本次以 `git show` 读取 `models/glm5_next_nextn.py` 和 `layers/attention/index_topk_share.py`，不把工作副本当前 HEAD `234ccba7f625e12639e621044496bcc6197c3758` 默认为同一来源。ds4 中新 V4.1 的路径不作为八个既定模型的新支持依据。

操作：只读本地 source／已有结果，并仅新增本文件；没有更改 docs／产品、编译、下载、运行或扩展验证矩阵。
