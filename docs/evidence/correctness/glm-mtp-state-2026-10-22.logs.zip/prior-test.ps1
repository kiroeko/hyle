$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/glm-mtp-carry-20261022').Path
$scratchRoot = (Resolve-Path -LiteralPath '.scratch').Path
$scratchPrefix = $scratchRoot.TrimEnd('\') + '\'
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$keep = [System.IO.Path]::GetFullPath($plan.keep)
$allowed = @($plan.allowed_parents | ForEach-Object { [System.IO.Path]::GetFullPath($_) })
foreach ($parent in $allowed) {
    if (-not $parent.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace scratch: $parent" }
    if ($parent -eq (Split-Path -Parent $keep)) { throw 'Current image directory is protected' }
}
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $plan.entries) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if ((Split-Path -Parent $target) -notin $allowed) { throw "Outside exact old image directories: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe','.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
if (-not (Test-Path -LiteralPath $keep -PathType Leaf)) { throw 'Final image missing' }
foreach ($entry in $plan.entries) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = @($plan.entries)
    Bytes = $plan.bytes
    CurrentImageRetained = (Test-Path -LiteralPath $keep)
    CurrentMapRetained = (Test-Path -LiteralPath ([System.IO.Path]::ChangeExtension($keep,'.map')))
    PriorReproductionInputsRetained = $plan.retained
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object Bytes, CurrentImageRetained, CurrentMapRetained
