"""Replace current GLM scope; preserve the latest real performance window."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
R = S.parents[1]

def replace_once(text, before, after):
    assert text.count(before) == 1, before[:100]
    return text.replace(before, after, 1)

path = R / 'docs/developer/current-work.md'
before = path.read_bytes()
text = before.decode('utf-8')
performance = text[text.index('## 最新完整性能对比'):]
text = replace_once(text,
'GLM-Flash原输入→q_a→qnorm的7个原角色73,429,504B已在CPU／CUDA各执行三代6次Graph，实际qnorm租约进入生成参数wq_b；已修CUDA FP8 dot的数值问题。继续补GLM其余原角色／完整状态、Q27／Q24其余适用原角色与共享权重、DSpark原stage／LM及target hidden taps；按制品布局、scale与舍入接线，不由其它格式代签',
'GLM原7角色输入／query链已接实际后继，并补grouped FP8同源数值修复；其它GLM／Q27／Q24适用角色、共享权重和已确认MTP量化接线仍待补。DSpark正式Flash／Pro原角色元数据已知，需接原stage／共享LM和实际target taps；按制品布局、scale与舍入，不由其它格式代签')
text = replace_once(text,
'将实际target KV／conv／GDN、draft KV／carry／pending及位置一起保存、选择与发布。GLM实际I32输出租约→skip-indexer消费者→StateHead已通过CPU／CUDA有限检查；仅IDs／index-key／gate／epoch四成员，target、MLA／pool-tail及完整接受前缀仍待组合。DSpark三stage持久环只接verified main历史；现有输入、单层KV或indexcarry不代签完整组合',
'GLM生成参数的一层NextN已将MLA／raw key／gate／pool／hidden／pending／I32选择／独立游标共14资源及epoch原子发布，CPU／CUDA接受prefix1后续算等有限检查通过。仍需target KDA／conv等状态组合、下一轮已接受skip的indexer追赶与重新选择；不能用单NextN代签完整target。Q27／Q24完整组合和DSpark各stage真实参数的verified-main历史仍待接')
text = replace_once(text,
'下一步继续GLM完整indexer／target／接受前缀状态组合及其它已选原角色，再补DSpark原stage／LM和target hidden来源。沿现有Graph、权重绑定和状态机制推进；模型、量化与provider范围仍以[总表](../implementation/model-operators.md)为准。',
'下一步补GLM跨轮indexer追赶／reseed及target状态组合，再接DSpark实际target taps／原stage／共享LM、Q27／Q24剩余角色与已确认MTP量化；最后补必要回归和普通／MTP四臂完整对照，再进入图片。沿现有Graph、权重绑定和状态机制推进；模型、量化与provider范围仍以[总表](../implementation/model-operators.md)为准。')
start = text.index('- **GLM-Flash**：')
end = text.index('\n- **DSpark**：', start)
text = text[:start] + '- **GLM-Flash**：[本轮NextN状态与grouped FP8修复](../evidence/correctness/glm-mtp-state-2026-10-22.json)最终10项通过、0失败／0跳过：原7角色链CPU／CUDA各9次Graph，生成参数整层NextN各7次，另6项CUDA量化邻居。NextN实际I32选择直入MLA／MoE，pool4闭池及同轮整个indexer跳过，保不同producer游标；prefix1发布、纠正pending、拒绝尾、独立base重算、旧分支与取消均核。grouped E4 dot已沿原数值门修复，保FP8存储／scale，仅寄存器tile无损转BF16。它仍是固定tail3边界，target KDA／conv组合、跨轮catchup／reseed、其它原角色与缓存编码待补；无新TPS或物理内存结论。此前四成员carry及原输入调查见[原证据](../evidence/correctness/glm-mtp-carry-2026-10-22.json)。' + text[end:]
text = replace_once(text,
'当前优先，按上表补原角色／codec与完整状态；GLM原FP8输入链及有限indexcarry已CPU／CUDA通过，继续其完整状态与其它原角色。已有Qwen K1和有限组件不代签全部制品',
'当前优先；GLM整层NextN有限状态已CPU／CUDA通过，继续跨轮追赶／target组合、DSpark及Q27／Q24实际角色／codec接线，随后完整性能对照。已有Qwen K1和有限组件不代签全部制品')
assert text[text.index('## 最新完整性能对比'):] == performance
folder = S / 'docs-before'; folder.mkdir()
(folder / 'current-work.md').write_bytes(before)
path.write_bytes(text.encode('utf-8'))

path = R / 'docs/implementation/model-operators.md'
before = path.read_bytes(); text = before.decode('utf-8')
text = replace_once(text,
'K4窗口和尾部必须成套保留；有限同迭代indexcarry已接实际输出租约，尚无完整状态组合／多会话消费者',
'K4窗口与尾部成套保留；生成参数一层NextN的14资源／epoch及prefix1续算已核，跨轮indexer追赶／target组合、原缓存编码及完整多会话仍待接')
start = text.index('[GLM原FP8链与同迭代indexcarry]')
end = text.index('\n## 25 个 custom descriptor', start)
text = text[:start] + '''[GLM本轮NextN状态与grouped FP8修复](../evidence/correctness/glm-mtp-state-2026-10-22.json)最终10项通过、0失败／0跳过：CPU／CUDA各9次原角色链Graph、7次生成参数NextN Graph，另6项CUDA量化邻居。原layer45的7角色73,429,504B仍保实际qnorm租约→生成wq_b，并新增实际inputnorm租约→grouped E1／slot1原q_a。grouped原E4 dot出现同源数值越界，已保FP8存储／量化／scale和原误差门，仅将寄存器tile无损转BF16再F32累加；两份AOT和16KiB共享内存常量由维护脚本重生成对齐。此前单线性修复与四成员carry见[原证据](../evidence/correctness/glm-mtp-carry-2026-10-22.json)。

新NextN将MLA latent、raw key／gate六槽环、已pool缓存、hidden／qresidual／pending、MLA与indexer独立游标、pool数量／尾部及实际I32选择共14资源和epoch同时发布；固定tail3闭pool4，I32实际租约进入稀疏MLA／MoE，同轮skip保整个indexer原租约及游标。prefix1纠正pending后续算与独立base重算逐字一致，拒绝尾、旧prefix2分支、取消和stale提交均核。它是生成参数primary GGUF／F32的一层完整组件，未证明target KDA／conv／mHC组合、新轮accepted-skip catchup／reseed、所有effective_n、官方缓存编码或完整原模型；其它原角色仍待接，无新TPS或物理内存数据。

DSpark正式Flash／Pro原角色headers已知；实际三stage512维main KV仍需原wkv／norm接线，旧128维投影fixture不能代签。target taps是block后HC mean；GGUF的Flash[41,42,43]是converter的layer+1约定，对应官方[40,41,42]，不是不同层。无共享embedding／LM的sidecar必须从匹配target借只读权重，实际tap输出租约与接受前沿仍需接入。
''' + text[end:]
(folder / 'model-operators.md').write_bytes(before)
path.write_bytes(text.encode('utf-8'))
summary = dict(performance_section_unchanged=True, performance_utf8_sha256=hashlib.sha256(performance.encode('utf-8')).hexdigest())
(S / 'docs-update.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
