"""Maintain exact E4-to-BF16 tiles for the existing grouped FP8 GEMMs."""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import re
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
T = R / 'third_party/sglang_activation/fp8/grouped'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def save(path, value): Path(path).write_text(json.dumps(value, indent=2, default=str) + '\n', encoding='utf-8')

def prepare():
    before = S / 'grouped-repair/before'
    before.mkdir(parents=True, exist_ok=False)
    for name in ['source.json', 'rebuild.py', 'compilation.json', 'sglang_grouped_fp8_sm89.h']:
        (before / name).write_bytes((T / name).read_bytes())
    source = read(T / 'source.json')
    original = (T / 'original_kernels.py').read_bytes()
    assert hashlib.sha256(original).hexdigest() == source['module_sha256']
    text = original.decode('utf-8').replace('\r\n', '\n')
    for name in ('runtime_top_k', 'scale_order'):
        adapter = source[name]
        assert text.count(adapter['before']) == 1
        text = text.replace(adapter['before'], adapter['after'])
        assert hashlib.sha256(text.encode()).hexdigest() == adapter['module_sha256']
    adapter = dict(description='For the qualified block128 FP8 jobs, exactly widen finite E4M3FN register tiles to BF16 before the F32 dot. Keep original packed storage, quantizer, scale order, expert sorting and output conversions.',
        input_module_sha256=hashlib.sha256(text.encode()).hexdigest(),
        before='block_dot = tl.dot(a, b)',
        after='block_dot = tl.dot(a.to(tl.bfloat16), b.to(tl.bfloat16))')
    assert text.count(adapter['before']) == 1
    adapted = text.replace(adapter['before'], adapter['after'])
    adapter['module_sha256'] = hashlib.sha256(adapted.encode()).hexdigest()
    source['dot_precision'] = adapter
    save(T / 'source.json', source)
    code = (T / 'rebuild.py').read_text(encoding='utf-8')
    old = "for name in ('runtime_top_k', 'scale_order'):"
    assert code.count(old) == 1
    code = code.replace(old, "for name in ('runtime_top_k', 'scale_order', 'dot_precision'):")
    old = "        lines += ['// SHA256 cubin: '+digest, f'alignas(16) inline constexpr unsigned char {name}[] = {{']"
    assert code.count(old) == 1
    new = "        if label != 'checked_original_align':\n            shared = next(job['metadata']['shared'] for job in jobs if job['label'] == label)\n            lines += [f'inline constexpr unsigned {name}SharedBytes = {shared};']\n" + old
    code = code.replace(old, new)
    (T / 'rebuild.py').write_text(code, encoding='utf-8', newline='\n')
    save(S / 'grouped-repair/adaptation.json', adapter)

def compile_candidates():
    os.environ['TRITON_CACHE_DIR'] = str(R / '.scratch/tools/d5-triton/cache')
    sys.path.insert(0, str(R / '.scratch/tools/d5-triton/unpacked'))
    import triton
    import triton.language as tl
    from triton.backends.compiler import GPUTarget
    from triton.compiler import ASTSource
    assert triton.__version__ == '3.8.0'
    out = S / 'grouped-bf16-tiles'
    out.mkdir(exist_ok=False)
    source = read(T / 'source.json')
    text = (T / 'original_kernels.py').read_text(encoding='utf-8')
    for name in ('runtime_top_k', 'scale_order', 'dot_precision'):
        adapter = source[name]
        assert text.count(adapter['before']) == 1
        text = text.replace(adapter['before'], adapter['after'])
        assert hashlib.sha256(text.encode()).hexdigest() == adapter['module_sha256']
    path = out / 'adapted_kernels.py'
    path.write_text(text, encoding='utf-8', newline='\n')
    spec = importlib.util.spec_from_file_location('grouped_adapted', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    records = []
    for job in read(T / 'compilation.json')['kernels']:
        constants = dict(job['constexprs'])
        constants['compute_type'] = tl.float32 if constants['compute_type'] == 'fp32' else tl.bfloat16
        compiled = triton.compile(ASTSource(fn=module.fused_moe_kernel,
            signature=job['signature'], constexprs=constants), target=GPUTarget('cuda', 89, 32), options=job['options'])
        blob, ptx = compiled.asm['cubin'], compiled.asm['ptx']
        assert '.f32.bf16.bf16.f32' in ptx and '.f32.e4m3.e4m3.f32' not in ptx
        (out / (job['label'] + '.cubin')).write_bytes(blob)
        (out / (job['label'] + '.ptx')).write_text(ptx, encoding='utf-8', newline='\n')
        record = copy.deepcopy(job)
        record['cubin_sha256'] = hashlib.sha256(blob).hexdigest()
        record['metadata'] = compiled.metadata._asdict()
        record['metadata']['target'] = dict(backend='cuda', arch=89, warp_size=32)
        record.pop('seconds', None)
        records.append(record)
        save(out / 'compilation.json', dict(compiler='3.8.0', target='cuda:89:32', kernels=records,
            adapted_module_sha256=source['dot_precision']['module_sha256']))
        print(job['label'], record['cubin_sha256'], record['metadata']['shared'], flush=True)

def install():
    records = read(S / 'grouped-bf16-tiles/compilation.json')
    assert len(records['kernels']) == 2
    save(T / 'compilation.json', records)
    header = (T / 'sglang_grouped_fp8_sm89.h').read_text(encoding='utf-8')
    for job, symbol in zip(records['kernels'], ['kGroupedF32', 'kGroupedBf16']):
        blob = (S / 'grouped-bf16-tiles' / (job['label'] + '.cubin')).read_bytes()
        assert hashlib.sha256(blob).hexdigest() == job['cubin_sha256']
        old = r'// SHA256 cubin: [0-9a-f]{64}\nalignas\(16\) inline constexpr unsigned char ' + symbol + r'\[\] = \{.*?\n\};'
        assert len(re.findall(old, header, re.S)) == 1
        lines = ['// Exact E4-to-BF16 register tiles; quantization/storage/scales unchanged.',
            'inline constexpr unsigned ' + symbol + 'SharedBytes = ' + str(job['metadata']['shared']) + ';',
            '// SHA256 cubin: ' + job['cubin_sha256'],
            'alignas(16) inline constexpr unsigned char ' + symbol + '[] = {']
        lines += ['  ' + ','.join('0x%02x' % b for b in blob[i:i+32]) + ',' for i in range(0, len(blob), 32)]
        lines += ['};']
        header = re.sub(old, lambda _: '\n'.join(lines), header, count=1, flags=re.S)
    (T / 'sglang_grouped_fp8_sm89.h').write_text(header, encoding='utf-8', newline='\n')
    print('Installed two grouped images; align and quantizer images unchanged.')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'compile', 'install'])
    args = parser.parse_args()
    {'prepare': prepare, 'compile': compile_candidates, 'install': install}[args.action]()
