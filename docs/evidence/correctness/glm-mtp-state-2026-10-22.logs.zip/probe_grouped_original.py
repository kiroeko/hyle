"""One existing grouped FP8 GEMM with the prior authenticated dense E4 pair."""
from pathlib import Path
import argparse
import ctypes as ct
import importlib.util
import json
import struct
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BA = R / '.scratch/glm-mtp-carry-20261022'
spec = importlib.util.spec_from_file_location('driver_probe', BA / 'review/native_quant_probe.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
T = R / 'third_party/sglang_activation/fp8/grouped'
job = next(x for x in json.loads((T / 'compilation.json').read_text())['kernels'] if x['label'] == 'grouped_bf16')
blob, _ = p.header_array(T / 'sglang_grouped_fp8_sm89.h', 'kGroupedBf16', job['cubin_sha256'])
A = (BA / 'diagnostics2/native-quant-probe1/cuda-codes.e4m3').read_bytes() + (BA / 'diagnostics2/native-quant-probe1/cuda-scales.f32').read_bytes()
B = (BA / 'original-glm-q-a/q_a.weight.e4m3').read_bytes() + (BA / 'original-glm-q-a/q_a.weight_scale.f32').read_bytes()
expected = (BA / 'diagnostics2/cuda-generation-0-reference.bf16').read_bytes()
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', type=int, default=2)
args = parser.parse_args()
out = S / f'grouped-probe{args.attempt}'
out.mkdir(exist_ok=False)
driver = p.Driver()
device, previous, primary, stream = ct.c_int(), ct.c_void_p(), ct.c_void_p(), ct.c_void_p()
allocations = []
module = ct.c_void_p()
retained = False

def allocate(raw):
    pointer = ct.c_uint64()
    driver.call('mem_alloc', ct.byref(pointer), len(raw))
    allocations.append(pointer)
    data = ct.create_string_buffer(raw)
    driver.call('htod', pointer, ct.cast(data, ct.c_void_p), len(raw))
    return pointer.value

try:
    driver.call('cuInit', 0)
    driver.call('cuCtxGetCurrent', ct.byref(previous))
    driver.call('cuDeviceGet', ct.byref(device), 0)
    driver.call('cuDevicePrimaryCtxRetain', ct.byref(primary), device)
    retained = True
    driver.call('cuCtxSetCurrent', primary)
    driver.call('cuStreamCreate', ct.byref(stream), 0)
    binary = ct.create_string_buffer(blob)
    driver.call('cuModuleLoadData', ct.byref(module), ct.cast(binary, ct.c_void_p))
    function = ct.c_void_p()
    driver.call('cuModuleGetFunction', ct.byref(function), module, b'fused_moe_kernel')
    a, b = allocate(A), allocate(B)
    c = allocate(bytes(1536 * 2))
    sorted_ids = allocate(struct.pack('<64i', 0, *([1] * 63)))
    experts = allocate(struct.pack('<i', 0))
    post = allocate(struct.pack('<i', 64))
    pointers = [a, b, c, a + 4096, b + 1536 * 4096, sorted_ids, experts, post]
    integers = [1536, 4096, 64, 1, 4096, 1, 1536 * 4096, 1, 4096,
                0, 0, 1536, 1, 32, 1, 12 * 32, 1, 32, 1]
    args = [ct.c_uint64(x) for x in pointers] + [ct.c_int(x) for x in integers] + [ct.c_uint64(), ct.c_uint64()]
    driver.launch(function, 12, 128, int(job['metadata']['shared']), stream, args)
    driver.call('cuStreamSynchronize', stream)
    result = ct.create_string_buffer(1536 * 2)
    driver.call('dtoh', ct.cast(result, ct.c_void_p), c, len(result))
    actual = result.raw
    (out / 'actual.bf16').write_bytes(actual)
    wide = lambda w: struct.unpack('<f', struct.pack('<I', w << 16))[0]
    av, ev = [list(map(wide, struct.unpack('<1536H', x))) for x in (actual, expected)]
    failed = [i for i, (x, y) in enumerate(zip(av, ev)) if abs(x - y) > .008 * abs(y) + .0001]
    report = dict(scope='One expert/slot raw grouped GEMM diagnostic, original q_a E4 pair; no claim about an original FFN or complete model.', source=p.identity(Path(__file__)),
        cubin_sha256=job['cubin_sha256'], launch=dict(grid=12, threads=128, shared=job['metadata']['shared'], arguments=len(args)),
        expected_bf16_equal=actual == expected, failed_unchanged_gate=failed,
        max_absolute_error=max(abs(x-y) for x, y in zip(av, ev)),
        row25=dict(actual=av[25], independent=ev[25]), SDK_builds=0, native_compilations=0)
    (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
finally:
    if stream.value:
        driver.call('cuStreamSynchronize', stream)
    for address in reversed(allocations):
        driver.call('mem_free', address)
    if module.value:
        driver.call('cuModuleUnload', module)
    if stream.value:
        driver.call('stream_destroy', stream)
    driver.call('cuCtxSetCurrent', previous)
    if retained:
        driver.call('primary_release', device)
