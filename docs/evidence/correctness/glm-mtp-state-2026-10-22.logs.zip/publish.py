"""Publish finite NextN state evidence and the independently fixed grouped path."""
from pathlib import Path
import hashlib
import json
import zipfile
S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = R / 'docs/evidence/correctness/glm-mtp-state-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def ident(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

assert not OUT.exists() and not ZIP.exists()
checks = read(S / 'checks2/summary.json')
assert checks['tests'] == 10 and checks['process']['exit'] == 0 and not checks['process']['timed_out']
assert not any(checks[k] for k in ('failures', 'errors', 'disabled', 'skips'))
assert ident(checks['image']['path'])['sha256'] == checks['image']['sha256']
states = [x for x in checks['cases'] if x['attributes']['classname'] == 'GlmMtpStateConsumer']
chains = [x for x in checks['cases'] if x['attributes']['classname'] == 'GlmOriginalMtpChain']
assert len(states) == len(chains) == 2
assert all(x['properties']['actual_submissions'] == '7' for x in states)
assert all(x['properties']['actual_submissions'] == '9' and x['properties']['grouped_submissions'] == '3' for x in chains)
old, fixed = (read(S / p / 'result.json') for p in ('grouped-probe1', 'grouped-probe2'))
assert old['failed_unchanged_gate'] == [25] and not old['expected_bf16_equal']
assert fixed['failed_unchanged_gate'] == [] and fixed['expected_bf16_equal'] and fixed['max_absolute_error'] == 0
generated = read(S / 'maintainer-grouped/receipt.json')
assert generated['generated_payloads_match_installed'] and generated['align_image_unchanged']
assert set(generated['grouped_shared_bytes'].values()) == {16384}
changes = [
    'tests/compute_models/glm_original_mtp_chain_test.cc',
    'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'tests/graph_route_cpu/CMakeLists.txt',
    'tests/graph_route_cuda/CMakeLists.txt',
    'src/compute_provider_cuda/grouped_fp8_provider.cc',
    'third_party/sglang_activation/fp8/grouped/source.json',
    'third_party/sglang_activation/fp8/grouped/rebuild.py',
    'third_party/sglang_activation/fp8/grouped/compilation.json',
    'third_party/sglang_activation/fp8/grouped/sglang_grouped_fp8_sm89.h',
    'docs/developer/current-work.md',
    'docs/implementation/model-operators.md',
]
for name in changes:
    dst = S / 'source-current' / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes((R / name).read_bytes())
assert ident(R / 'tests/compute_models/glm_mtp_state_consumer_test.cc')['sha256'] == read(S / 'source/source-freeze.json')['sha256']
doc_receipt = read(S / 'docs-update.json')
text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
performance = text[text.index('## 最新完整性能对比'):].encode('utf-8')
assert hashlib.sha256(performance).hexdigest() == doc_receipt['performance_utf8_sha256']
report = dict(
    date='2026-10-22', status='GLM_SINGLE_NEXTN_STATE_AND_GROUPED_FP8_REPAIR_PASS', goal_complete=False,
    checks=checks, actual_new_consumer_graph_submissions=32, original_role_chain_graph_submissions=18,
    whole_NextN_component_graph_submissions=14, existing_CUDA_scale_neighbor_cases=6,
    changes=[ident(R / p) for p in changes],
    original_role_and_single_FP8_predecessor=ident(R / 'docs/evidence/correctness/glm-mtp-carry-2026-10-22.json'),
    state_component=dict(
        scope='Generated selected primary GGUF/F32 single complete NextN component, not the full original target model.',
        math='EH->input norm->q_a/qnorm->absorbed MLA query and current latent->pool4 indexer actual I32 selection->sparse MLA->residual/MoE->normalized next hidden. Ordinary Graph outputs are directly rebound; host oracles are observation only.',
        boundary='14 native resource leases plus24-byte explicit epoch policy: MLA latent;6-slot raw key/gate rings; completed pool bank; hidden/query carry; pending; MLA and indexer separate cursors; pool count; ring offset; tail validity/start; I32 selection.',
        fresh='Actual base position2055/tail3 closes pool513 and exposes514 complete pools, selects512 pools->2048 valid token IDs, pads3 slots with-1. Only valid IDs are fed into checked Gather/attention.',
        skip='Within the same MTP epoch, the entire indexer is absent. Actual old raw key/gate/pool/counter leases are retained while MLA/hidden/pending advance. Producer cursors are not falsely made equal.',
        accepted_prefix='Fresh A->same-epoch skip B; explicit policy chooses prefix1 and corrects pending through an actual Copy Graph; atomic publish and continuation from actual head. Independent old-base recomputation gives byte-identical whole state. Prefix0 old base and prefix2 separate branch retained.',
        isolation='Rejected MLA append absent from prefix1; old byte images unchanged; stale head publish refused; cancelled incomplete/invalid member transaction cannot expose partial state; store/output live allocations retire; parameters unchanged.',
        unfinished=['Target KDA/conv/mHC and target MLA/index history composition with NextN.',
            'Next-epoch accepted-skip indexer catchup from actual accepted input features, then qualified reseed.',
            'Other applicable original parameter bindings and official cache codec boundaries.',
            'All effective_n/pool-tail combinations and full original vocabulary/natural acceptance were not executed; this finite check does not certify them.']),
    grouped_FP8_repair=dict(
        before=old, after=fixed,
        witness='Reused authenticated original q_a E4 codes/scales and actual BF16 input from the previously published original GLM chain. E1/slot1 grouped invocation is a diagnostic of the real grouped primitive, not an original FFN bank.',
        repair='Keep original E4 storage, quantizer/scale bits, sequential activation-scale then weight-scale arithmetic, expert IDs/alignment and output conversions. Exact finite E4->BF16 register-tile casts before F32 dot avoid the observed SM89 loss, following the independently fixed single route.',
        graph_regression='Original actual inputnorm output ReadLease is directly bound into grouped E1/slot1 q_a Graph on CPU/CUDA for three generations each. Existing qa_reference/close_bfloat gates unchanged.',
        unchanged='No resident BF16 shadow bank, new public option, provider/executor split, vendor module edit, quantizer change or tolerance relaxation.',
        maintainer_generation=generated,
        actual_aot_images_regenerated=2, shared_memory_bytes_per_image=16384,
        performance_claim=False),
    fixed_source=read(S / 'review/source-state.json'),
    remaining_review=ident(S / 'review/remaining.md'),
    DSpark_exact_binding=read(S / 'review/dspark-next-binding.json'),
    validation=dict(platform='Windows CPU/CUDA on existing matched native closure; CUDA SM89 RTX4070.',
        SDK_builds=0, NVCC_builds=0, shader_builds=0,
        method='Four related host TUs incrementally compiled; existing libs/objects/DLLs reused. Cached Triton regenerates only2 grouped GEMM AOT images. No SDK/full-tree rebuild or new platform matrix.',
        throughput_evidence=False, physical_memory_evidence=False,
        performance_section_unchanged=doc_receipt),
    cleanup=read(S / 'cleanup-result.json'),
    remaining=['Finish GLM next-epoch indexer catchup/reseed and target-state composition; connect remaining applicable original parameters/codecs.',
        'DSpark formal Flash/Pro original stage/shared-head suppliers and real qualified target capture leases; existing128-wide synthetic rings do not certify original512-wide per-stage histories.',
        'Q27/Q24 remaining applicable original role/codec and complete target/draft/pending/frontier composition, and confirmed-MTP selected derivative formats.',
        'Necessary focused regressions and final ordinary/MTP prefill/decode/combined/physical-memory comparison; then image encoder/projector.'],
    limits=['No full original GLM/DeepSeek/Q27/Q24 target execution in this batch; do not count undispatched whole-model payloads as new API work.',
        'No new Apple/Linux/Vulkan native validation or broad codec matrix.',
        'No new TPS, acceptance-rate or physical memory measurements; AV remains the latest full four-arm performance comparison.'])
next_steps = S / 'review/glm-next-steps.json'
if next_steps.is_file():
    report['GLM_next_implementation_design'] = read(next_steps)
save(S / 'report-before-archive.json', report)
extensions = {'.json', '.py', '.cc', '.h', '.md', '.diff', '.log', '.xml', '.txt', '.ps1', '.ptx'}
files = [p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in extensions and '__pycache__' not in p.parts]
files += [p for sub in ('grouped-probe1', 'grouped-probe2') for p in (S / sub).glob('*.bf16')]
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in sorted(files):
        archive.write(p, p.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
report['sources_commands_and_results'] = ident(ZIP)
report['large_original_payloads_archived'] = False
save(OUT, report)
receipt = dict(evidence=ident(OUT), archive=ident(ZIP), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
