"""Build a finite CPU factor closure from authenticated existing objects.

Only two canonical upstream files are materialized. Existing third-party
trees, libraries and objects are read, never modified or copied.
"""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
sys.path.insert(0, str(R / 'scripts'))
from hyle_environment import discover_environment

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
def save(p, j):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(j, indent=2) + '\n')
def q(p): return '[==[' + str(p).replace('\\', '/') + ']==]'

PURE = R / '.scratch/build-compute-v2-dev/src/compute_ggml_runtime/source-e74fc9bb8964d04f'
UP = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml_cpu-ffa4e8b80930-ac5706fbc134')
LIB = R / '.scratch/build-compute-v2-dev/bin'
manifest = read(R / 'third_party/ggml_cpu_runtime/patches.json')
assert manifest['upstream_revision'] == 'ffa4e8b80930029a35991f94e7c8a93cd67730ab'
native_changes = []
for patch in manifest['files']:
    cached = PURE / patch['path']
    if sha(cached) == patch['after_sha256']: continue
    assert patch['path'] in ['src/ggml-cpu/ops.cpp', 'src/ggml-alloc.c']
    raw = (UP / patch['path']).read_bytes().replace(b'\r\n', b'\n')
    assert hashlib.sha256(raw).hexdigest() == patch['before_sha256']
    for edit in patch['edits']:
        old, new = edit['before'].encode(), edit['after'].encode()
        assert raw.count(old) == 1, patch['path']
        raw = raw.replace(old, new, 1)
    assert hashlib.sha256(raw).hexdigest() == patch['after_sha256']
    output = S / 'native-source' / patch['path']
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists(): assert output.read_bytes() == raw
    else: output.write_bytes(raw)
    native_changes.append(dict(original=ident(cached), updated=ident(output)))
assert len(native_changes) == 2
save(S / 'native-source-identities.json', native_changes)

plan = read(R / '.scratch/qwen-multi-draft-20261024/geometry-cpu-check3/link-command.json')
if isinstance(plan, dict): plan = plan['command']
factors = (S / 'catalog-build/factors.txt').read_text().strip().split(';')
assert not any(any(gpu in x for gpu in ['cuda', 'vulkan', 'apple']) for x in factors)
objects = {factor: [] for factor in factors}
extra_map = {
 'cpu-file-stream.obj': 'compute_stream_cpu', 'budget.obj': 'compute', 'leases.obj': 'compute',
 'low-precision.obj': 'compute_ops', 'layout.obj': 'compute_batch',
 'executable.obj': 'graph', 'native-paged.obj': 'compute_batch',
 'mem-resource.obj': 'mem',
}
excluded = []
for value in plan:
    if not value.lower().endswith('.obj'): continue
    path = Path(value)
    factor = path.name.split('--')[0] if '--' in path.name else extra_map.get(path.name)
    if path.name.startswith('io-'): factor = 'io_core'
    if path.name.startswith('stream-'): factor = 'compute_stream'
    # All GGML-header users are recompiled against the real ffa4 header family.
    if factor in ['compute_provider_ggml', 'compute_ggml_runtime']:
        excluded.append(value); continue
    if factor == 'graph_route_cpu' and path.name.endswith('ggml_region.obj'):
        excluded.append(value); continue
    if factor in objects:
        assert path.exists(), value
        objects[factor].append(value)
    else: excluded.append(value)
assert all(not any(t in p.lower() for t in ['cuda', 'cublas', 'flashinfer'])
           for paths in objects.values() for p in paths if Path(p).name != 'mem-resource.obj')

# Native CPU defaults use only these provider factories; no CUDA or bridge
# object is admitted merely because it was present in the mixed probe plan.
causal = {j['label']: j['argv'] for j in read(R / '.scratch/perf-review-2026-10-18/cpu-native-causal/commands.json')}
compiler = causal['ffa4-native-baseline'][0]
environment = discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
    'CMAKE_GENERATOR': 'Ninja'}, backends=())
save(S / 'environment.json', dict(compiler=compiler, generator=environment.generator))

def clean_flags(command):
    flags = []; skip = False
    for a in command[1:]:
        if skip: skip = False; continue
        if a.lower() == '/sourcedependencies': skip = True; continue
        if a.lower().startswith(('/fo', '/fd')) or a.lower() == '/c': continue
        if a.lower().endswith(('.c', '.cc', '.cpp')): continue
        if a.startswith('/DHYLE_GGML_CPU_PROVIDER_VERSION='): continue
        if a.startswith('/DHYLE_GGML_CPU_PROGRAM_LIBRARY='): continue
        if a.lower().startswith(('/external:i', '/i', '-i')) and any(
            word in a.lower() for word in ['mixed-iq1', 'source-e74fc9bb8964d04f']): continue
        flags.append(a)
    return flags

native_baseline = clean_flags(causal['ffa4-native-baseline'])
native_avx = clean_flags(causal['ffa4-native-avx2'])
native_export = clean_flags(causal['ffa4-program-export'])
cpp_recipe = read(R / '.scratch/qwen35-unsloth-mtp-20261024/dense-cpu-check1/provider/identity.json')['command']
cpp_flags = clean_flags(cpp_recipe)
cpp_flags = [a for a in cpp_flags if 'HYLE_TEST_GGML_CPU' not in a]
main_flags = clean_flags(read(R / '.scratch/qwen-input-boundary-20261024/main-cpu-syntax/command.json')['command'])
main_flags = [a for a in main_flags if a != '/Zs']

lines = ['cmake_minimum_required(VERSION 3.25)', 'project(hyle_cpu_cached_closure LANGUAGES C CXX)',
 'set(CMAKE_MSVC_RUNTIME_LIBRARY MultiThreadedDLL)', 'set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")',
 'set(CMAKE_LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")', 'set(CMAKE_CXX_STANDARD 23)',
 'set(CMAKE_CXX_STANDARD_REQUIRED ON)', 'set(CMAKE_CXX_EXTENSIONS OFF)']

def options(target, flags):
    lines.append('target_compile_options(' + target + ' PRIVATE ' + ' '.join(q(a) for a in flags) + ')')
    lines.append('target_include_directories(' + target + ' PRIVATE ' + ' '.join(q(p) for p in [
        PURE / 'include', PURE / 'src', PURE / 'src/ggml-cpu', R / 'src/compute_ggml_runtime']) + ')')

for factor, paths in objects.items():
    if paths:
        lines += ['add_library(cache_' + factor + ' OBJECT IMPORTED GLOBAL)',
            'set_property(TARGET cache_' + factor + ' PROPERTY IMPORTED_OBJECTS ' + ' '.join(q(p) for p in paths) + ')']
    else: lines += ['add_library(cache_' + factor + ' INTERFACE)']

def fresh(target, paths, flags):
    lines.append('add_library(' + target + ' OBJECT ' + ' '.join(q(p) for p in paths) + ')')
    options(target, flags)

fresh('cpu_ops_baseline', [S / 'native-source/src/ggml-cpu/ops.cpp'], native_baseline)
fresh('cpu_ops_avx', [S / 'native-source/src/ggml-cpu/ops.cpp'], native_avx)
fresh('cpu_export', [R / 'src/compute_ggml_runtime/cpu_program_export.cc'], native_export)
# Use the actual old pure-C compiler flags, not C++ flags for this C object.
compdb = read(R / '.scratch/build-compute-v2-dev/compile_commands.json')
alloc_recipe = next(j for j in compdb if j['file'].replace('\\','/').endswith('/ggml-alloc.c'))
import ctypes
count = ctypes.c_int(); split = ctypes.windll.shell32.CommandLineToArgvW
split.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
split.restype = ctypes.POINTER(ctypes.c_wchar_p)
argv = split(alloc_recipe['command'], ctypes.byref(count))
try: alloc_flags = clean_flags([argv[i] for i in range(count.value)])
finally: ctypes.windll.kernel32.LocalFree(argv)
fresh('cpu_alloc', [S / 'native-source/src/ggml-alloc.c'], alloc_flags)

for name in ['ggml', 'ggml-base', 'ggml-cpu']:
    lines += ['add_library(pure_' + name.replace('-','_') + ' STATIC IMPORTED GLOBAL)',
        'set_property(TARGET pure_' + name.replace('-','_') + ' PROPERTY IMPORTED_LOCATION ' + q(LIB / (name + '.lib')) + ')']

avx_cached = [Path(a) for a in causal['ffa4-module-link'] if a.lower().endswith('.obj')
              and 'hyle_ggml_cpu_avx2.dir' in a]
assert len(avx_cached) >= 10
lines += ['add_library(cpu_program MODULE $<TARGET_OBJECTS:cpu_ops_avx> $<TARGET_OBJECTS:cpu_export> '
          '$<TARGET_OBJECTS:cpu_alloc> ' + ' '.join(q(p) for p in avx_cached) + ')',
 'set_target_properties(cpu_program PROPERTIES LINKER_LANGUAGE CXX OUTPUT_NAME hyle_ggml_cpu_pure_ffa4_current)',
 'target_link_libraries(cpu_program PRIVATE pure_ggml_base bcrypt PowrProf Synchronization advapi32 user32 shell32 ole32 ws2_32)']

fresh('cpu_ggml_runtime', [R / 'src/compute_ggml_runtime' / n for n in
    ['cpu_execution.cc', 'metadata_arena.cc', 'cpu_program.cc']], cpp_flags)
lines += ['target_compile_definitions(cpu_ggml_runtime PRIVATE HYLE_GGML_CPU_AVX2_PROGRAM=1 '
          'HYLE_GGML_CPU_PROGRAM_LIBRARY="$<TARGET_FILE_NAME:cpu_program>")',
          'add_dependencies(cpu_ggml_runtime cpu_program)']
fresh('cpu_ggml_provider', [R / 'src/compute_provider_ggml' / n for n in
    ['ggml_cpu_provider.cc', 'native_batch.cc', 'standard_index.cc']], cpp_flags)
lines.append('target_compile_definitions(cpu_ggml_provider PRIVATE HYLE_GGML_CPU_F32_FLASH=1 '
             'HYLE_GGML_CPU_IQ1_EXTENSIONS=1 HYLE_GGML_CPU_PROVIDER_VERSION="ffa4e8b8-current-pure-cpu-closure")')
fresh('cpu_ggml_region', [R / 'src/graph_route_cpu/ggml_region.cc'], cpp_flags)

lines.append('add_executable(hyle_cpu ' + q(R / 'engine/main.cc') + ' ' + q(R / 'engine/models/qwen35/main.cc') + ')')
options('hyle_cpu', main_flags)
lines.append('target_compile_definitions(hyle_cpu PRIVATE HYLE_STATIC HYLE_IO_HAS_COROUTINE_TRANSPORT=1 HYLE_COMPUTE_CPU=1)')
lines.append('set_target_properties(hyle_cpu PROPERTIES OUTPUT_NAME hyle LINKER_LANGUAGE CXX)')
link_targets = ['cache_' + f for f in factors]
link_targets += ['cpu_ggml_runtime', 'cpu_ggml_provider', 'cpu_ggml_region', 'cpu_ops_baseline', 'cpu_alloc',
                 'pure_ggml', 'pure_ggml_cpu', 'pure_ggml_base']
foundation = ['hyle_container', 'hyle_mem', 'mimalloc_static', 'hyle_platform', 'hyle_error',
              'hyle_platform_thread', 'hyle_time', 'hyle_simd', 'hyle_sched', 'hyle_mem_vm', 'hyle_platform_fs', 'dnnl']
link_targets += [q(LIB / (name + '.lib')) for name in foundation]
torch = Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib')
link_targets += [q(torch / (name + '.lib')) for name in ['torch', 'torch_cpu', 'c10']]
link_targets += ['bcrypt', 'PowrProf', 'Synchronization', 'advapi32', 'user32', 'shell32', 'ole32', 'ws2_32', 'gdi32',
                 'winspool', 'oleaut32', 'uuid', 'comdlg32']
lines.append('target_link_libraries(hyle_cpu PRIVATE ' + ' '.join(link_targets) + ')')
lines.append('add_dependencies(hyle_cpu cpu_program)')
(S / 'project').mkdir(exist_ok=True)
(S / 'project/CMakeLists.txt').write_text('\n'.join(lines) + '\n')
save(S / 'closure.json', dict(factors=factors, cached_objects=objects, excluded_mixed_inputs=excluded,
    native_changes=native_changes, unchanged_native_files=10,
    pure_native_static_libraries=[ident(LIB / (n + '.lib')) for n in ['ggml','ggml-base','ggml-cpu']],
    fresh_hyle_TUs=7, fresh_native_TUs=4, fresh_engine_TUs=2,
    SDK_rebuilds=0, HTTP=0, third_party_tree_copies=0))
command = [environment.cmake, '-S', str(S/'project'), '-B', str(S/'build'), '-G', 'Ninja',
           '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_C_COMPILER='+compiler, '-DCMAKE_CXX_COMPILER='+compiler]
save(S/'configure-command.json', dict(command=command, cwd=str(R)))
result = subprocess.run(command, env=environment.env, cwd=R, text=True, capture_output=True,
                        creationflags=subprocess.CREATE_NO_WINDOW)
(S/'configure-stdout.log').write_text(result.stdout);(S/'configure-stderr.log').write_text(result.stderr)
save(S/'configure-process.json', dict(exit=result.returncode))
print(result.stdout); print(result.stderr)
sys.exit(result.returncode)
