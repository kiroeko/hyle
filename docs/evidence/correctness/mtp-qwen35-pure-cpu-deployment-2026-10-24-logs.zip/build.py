from pathlib import Path
import hashlib, json, os, subprocess, sys, time
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
sys.path.insert(0, str(R/'scripts'))
from hyle_environment import discover_environment

def ident(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,j): Path(p).write_text(json.dumps(j,indent=2)+'\n')
environment=discover_environment(compiler='msvc',cache={
    'CMAKE_C_COMPILER':json.loads((S/'environment.json').read_text())['compiler'],
    'CMAKE_CXX_COMPILER':json.loads((S/'environment.json').read_text())['compiler'],
    'CMAKE_GENERATOR':'Ninja'},backends=())
sources=list((R/'engine/models/qwen35').glob('*.h'))+[R/'engine/models/qwen35/main.cc',R/'engine/main.cc']
before=[ident(p) for p in sources]
snapshot=S/'source'
for p in sources:
    dest=snapshot/p.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists(): assert dest.read_bytes()==p.read_bytes()
    else:dest.write_bytes(p.read_bytes())
save(S/'source-identities.json',before)
command=[environment.cmake,'--build',str(S/'build'),'--target','hyle_cpu','--parallel','2']
save(S/'build-command.json',dict(command=command,cwd=str(R)))
start=time.monotonic()
with (S/'build-stdout.log').open('wb') as out,(S/'build-stderr.log').open('wb') as err:
    p=subprocess.run(command,cwd=R,env=environment.env,stdout=out,stderr=err,
                     timeout=240,creationflags=subprocess.CREATE_NO_WINDOW)
save(S/'build-process.json',dict(exit=p.returncode,seconds=time.monotonic()-start))
after=[ident(p) for p in sources]
save(S/'source-unchanged.json',dict(unchanged=before==after,after=after))
print('build',p.returncode,'source unchanged',before==after)
sys.exit(p.returncode)
