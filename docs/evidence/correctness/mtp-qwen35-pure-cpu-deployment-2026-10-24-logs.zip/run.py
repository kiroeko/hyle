from pathlib import Path
import ctypes, ctypes.wintypes as w, hashlib, json, os, re, subprocess, time
S=Path(__file__).resolve().parent
R=S.parents[1]
BIN=S/'build/bin'
TOOL=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/dumpbin.exe')
TORCH=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib')
def save(p,j):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,indent=2)+'\n')
def identity(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def forbidden(s):return any(x in s.lower() for x in ['cuda','cublas','cudnn','nvrtc','nvcuda','nvfat','nv_fat','flashinfer'])
env=dict(os.environ,PATH=os.pathsep.join(str(p) for p in [BIN,TORCH,Path(os.environ['SystemRoot'])/'System32',Path(os.environ['SystemRoot'])]))
save(S/'runtime-environment.json',dict(PATH=env['PATH'],CUDA_path_present=False))
imports={}
queue=[BIN/'hyle.exe',BIN/'hyle_ggml_cpu_pure_ffa4_current.dll']
seen=set()
while queue:
    path=queue.pop(0)
    if path.name.lower() in seen:continue
    seen.add(path.name.lower())
    result=subprocess.run([str(TOOL),'/DEPENDENTS',str(path)],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0,(path,result.stdout,result.stderr)
    names=re.findall(r'^\s+([\w.\-]+\.dll)\s*$',result.stdout,re.M|re.I)
    assert all(not forbidden(n) for n in names),(path,names)
    imports[path.name]=dict(file=identity(path),imports=names)
    out=S/'imports'/path.name
    out.mkdir(parents=True,exist_ok=True)
    (out/'dependents.txt').write_text(result.stdout)
    headers=subprocess.run([str(TOOL),'/HEADERS',str(path)],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert headers.returncode==0
    assert not forbidden('\n'.join(line for line in headers.stdout.splitlines() if 'name' in line.lower() and '.nv' in line.lower()))
    (out/'headers.txt').write_text(headers.stdout)
    for name in names:
        child=next((folder/name for folder in [BIN,TORCH] if (folder/name).exists()),None)
        if child:queue.append(child)
save(S/'imports/closure.json',imports)

psapi=ctypes.WinDLL('psapi',use_last_error=True)
psapi.EnumProcessModulesEx.argtypes=[w.HANDLE,ctypes.POINTER(w.HMODULE),w.DWORD,ctypes.POINTER(w.DWORD),w.DWORD]
psapi.EnumProcessModulesEx.restype=w.BOOL
psapi.GetModuleFileNameExW.argtypes=[w.HANDLE,w.HMODULE,w.LPWSTR,w.DWORD]
psapi.GetModuleFileNameExW.restype=w.DWORD
def modules(process):
    array=(w.HMODULE*2048)();size=w.DWORD()
    if not psapi.EnumProcessModulesEx(int(process._handle),array,ctypes.sizeof(array),ctypes.byref(size),3):return []
    result=[]
    for module in array[:min(len(array),size.value//ctypes.sizeof(w.HMODULE))]:
        text=ctypes.create_unicode_buffer(32768)
        if psapi.GetModuleFileNameExW(int(process._handle),module,text,len(text)):result.append(text.value)
    return result

summary=[]
for mode in ['ordinary','k1']:
    out=S/('run-'+mode)
    out.mkdir(exist_ok=False)
    command=[str(BIN/'hyle.exe'),'--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/complete-v2/Q4'),
        '--capacity','256','--steps','4','--cache-bytes','268435456','--prefix-cache','off',
        '--replay','commands','--mtp','off' if mode=='ordinary' else 'on']
    save(out/'command.json',dict(command=command,cwd=str(R),image=identity(BIN/'hyle.exe')))
    start=time.monotonic();observed=set()
    with (out/'stdout.log').open('wb') as a,(out/'stderr.log').open('wb') as b:
        p=subprocess.Popen(command,env=env,cwd=R,stdout=a,stderr=b,creationflags=subprocess.CREATE_NO_WINDOW)
        while p.poll() is None:
            observed.update(modules(p))
            if time.monotonic()-start>180:p.kill();raise RuntimeError('bounded CPU run exceeded180s')
            time.sleep(.02)
        code=p.wait()
    save(out/'process.json',dict(exit=code,seconds=time.monotonic()-start,pid=p.pid))
    save(out/'loaded-modules.json',sorted(observed))
    assert code==0,(mode,code)
    assert all(not forbidden(Path(name).name) for name in observed),(mode,observed)
    assert any(Path(name).name=='hyle_ggml_cpu_pure_ffa4_current.dll' for name in observed)
    output=json.loads((out/'stdout.log').read_text().strip().splitlines()[-1])
    save(out/'output.json',output)
    assert output['generated_tokens']==4,output
    summary.append(dict(mode=mode,exit=code,generated_ids=output['generated_ids'],actual_loaded_modules=len(observed),
        CUDA_loaded=False,output=identity(out/'output.json'),image=identity(BIN/'hyle.exe')))
    save(S/'run-summary.json',summary)
    print(mode,'PASS',output['generated_ids'],flush=True)
