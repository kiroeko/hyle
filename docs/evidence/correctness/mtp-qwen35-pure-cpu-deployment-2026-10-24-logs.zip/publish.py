from pathlib import Path
import hashlib,json,subprocess,zipfile
S=Path(__file__).resolve().parent
R=S.parents[1]
D=R/'docs/evidence/correctness'
stem='mtp-qwen35-pure-cpu-deployment-2026-10-24'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p).resolve();return dict(path=str(p.relative_to(R)) if p.is_relative_to(R) else str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
closure=read(S/'closure.json')
for update in closure['native_changes']:
 assert ident(update['original']['path'])['sha256']==update['original']['sha256'],'original cache changed'
 assert ident(update['updated']['path'])['sha256']==update['updated']['sha256']
fresh_objects=[ident(p) for p in (S/'build/CMakeFiles').rglob('*.obj')
               if 'CompilerId' not in str(p) and 'ShowIncludes' not in str(p)]
assert len(fresh_objects)==13
cached_objects=[ident(p) for values in closure['cached_objects'].values() for p in values]
(S/'objects.json').write_text(json.dumps(dict(fresh=fresh_objects,cached=cached_objects),indent=2)+'\n')
ninja=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe')
result=subprocess.run([str(ninja),'-C',str(S/'build'),'-t','commands','hyle_cpu'],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
assert result.returncode==0
(S/'ninja-commands.txt').write_text(result.stdout)
files={}
for folder in ['catalog','catalog-build','project','source','native-source','imports','run-ordinary','run-k1']:
 for path in (S/folder).rglob('*'):
  if path.is_file() and path.suffix in ['.json','.log','.txt','.cc','.h','.cpp','.c'] and 'CMakeFiles' not in str(path):
   files[path.relative_to(S).as_posix()]=path.read_bytes()
for path in S.iterdir():
 if path.is_file() and path.suffix in ['.json','.log','.txt','.py']:files[path.name]=path.read_bytes()
files['build/.ninja_log']=(S/'build/.ninja_log').read_bytes()
files['build/build.ninja']=(S/'build/build.ninja').read_bytes()
files['build/CMakeCache.txt']=(S/'build/CMakeCache.txt').read_bytes()
for source in ['cmake/HyleComponents.cmake','cmake/HyleComputeRoutes.cmake',
               'src/compute_ggml_runtime/CMakeLists.txt','src/compute_ggml_runtime/cpu_program.cmake',
               'src/compute_provider_ggml/CMakeLists.txt','third_party/ggml_cpu_runtime/patches.json']:
 files['product-contract/'+source]=(R/source).read_bytes()
for source in ['cpu_execution.cc','metadata_arena.cc','cpu_program.cc','cpu_program_export.cc',
               'cpu_program_abi.h','cpu_program.h','metadata_arena.h','cpu_execution.h','gated_delta_scale.h']:
 files['product-source/src/compute_ggml_runtime/'+source]=(R/'src/compute_ggml_runtime'/source).read_bytes()
for source in ['ggml_cpu_provider.cc','native_batch.cc','standard_index.cc','program.h','native_batch.h','standard_index.h']:
 files['product-source/src/compute_provider_ggml/'+source]=(R/'src/compute_provider_ggml'/source).read_bytes()
files['product-source/src/graph_route_cpu/ggml_region.cc']=(R/'src/graph_route_cpu/ggml_region.cc').read_bytes()
archive=D/(stem+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
cases=[]
for case in read(S/'run-summary.json'):
 folder=S/('run-'+case['mode']);out=read(folder/'output.json')
 case.update(process=read(folder/'process.json'),
             original_host_weight_bytes=out['original_host_weight_bytes'],
             original_device_weight_bytes=out['original_device_weight_bytes'],
             cache_peak_requested_bytes=out['cache_peak_requested_bytes'],
             cache_requested_byte_limit=out['cache_requested_byte_limit'],
             native_execution_private_bytes_unknown=out['native_execution_private_bytes_unknown'],
             loaded_module_record=ident(folder/'loaded-modules.json'))
 cases.append(case)
proof=dict(date='2026-10-24',status='PASS finite current pure CPU runtime/deployment dependency closure',
 scope='Current Qwen private engine ordinary and MTP K1 use original complete Q4 source, true pure-CPU GGML ffa4 family and CPU-only runtime libraries. This is a focused CMake cache-target closure proof, not a fresh top-level SDK/install/relocation qualification.',
 rationale='Previous CPU consumer executed CPU math but its mixed whole-object link imported TorchCUDA/cuBLAS and embedded GPU fatbin. That proof did not establish CPU-only deployment.',
 organization=dict(selector='HYLE_COMPONENTS=engine; HYLE_COMPUTE_ROUTES=cpu',
   resolver='Unmodified product cmake/HyleComponents.cmake and HyleComputeRoutes.cmake; real CMake project, no SDK discovery or downloads.',
   factors=closure['factors'],cached_cpu_and_generic_objects=len(cached_objects),
   cache_target_assembly='Each selected factor owns its imported object target. No unselected GPU/bridge factor is admitted from the previous mixed link plan. The real private Graph/Compute executors are unchanged.',
   source_family='Pure CPU ffa4e8b80930029a35991f94e7c8a93cd67730ab; ten canonical patched files match the retained pure tree. Only changed ops.cpp and ggml-alloc.c are materialized separately from authenticated original cache bytes.',
   fresh_TUs={'native':4,'Hyle_GGML_header_boundary':7,'engine_entry_and_current_Model':2},
   header_boundary='Every retained consumer of ggml_tensor internals in the Hyle CPU provider/runtime/region is rebuilt against the same pure ffa4 headers. CPU provider/native_batch use the real pure F32_FLASH and IQ1 capabilities, not mixed-family tensor layout assumptions.',
   immutable_cache=True,third_party_tree_copies=0,HTTP=0,whole_SDK_builds=0,
   startup_configuration='Native AVX module is an explicit hyle_cpu CMake build dependency; staged beside the executable. No product variable or provider selector was added.'),
 source=dict(evidence=ident(D/'mtp-qwen35-original-gguf-q4-cpu-2026-10-24.json'),
             source_id='39daef4a62aeef1437121f3ea2556a0a451255a5a78caa0a743c2df5fb6c5a40',
             original_roles=335,original_selected_MTP_payload_bytes=1373938944,
             prompt_tokens=154,capacity=256,requested_outputs=4,cache_byte_limit=268435456,
             no_model_weight_download=True),
 images=[ident(S/'build/bin/hyle.exe'),ident(S/'build/bin/hyle_ggml_cpu_pure_ffa4_current.dll')],
 dependency_check=dict(recursive_PE_imports=ident(S/'imports/closure.json'),
   CUDA=False,TorchCUDA=False,cuBLAS=False,CUDA_fatbin_sections=False,
   non_system_runtime='torch_cpu.dll and c10.dll plus their CPU-only dependencies; new native CPU AVX module depends only on system/CRT libraries.',
   restricted_PATH=read(S/'runtime-environment.json')['PATH'],
   actual_process_module_sampling='EnumProcessModulesEx on each running ordinary/K1 process; 32/31 unique modules, original new AVX module seen, no GPU library names. This supplements static PE imports and the restricted PATH.'),
 native_changes=closure['native_changes'],source_unchanged_during_build=read(S/'source-unchanged.json')['unchanged'],
 tests=cases,
 result='Both processes exit0, complete final JSON and normal destruction. Ordinary/K1 both emit [71093,12305,198,464], equal to prior short CPU/CUDA Q4 cases; no general numerical or task-quality equivalence is inferred.',
 limits=['No fresh top-level source configure/install/package/relocation run was performed; future engineering validation must cover that distribution path.',
         'Only the requested ordinary/K1 finite CPU closure cases were run. MultiK, random sampling, long context and other artifact/hardware combinations are not re-signed by this proof.',
         'Reported cache limit is a requested resource budget. Native opaque workspace remains explicitly unknown; no physical RAM peak or throughput comparison is claimed.',
         'No GPU runtime was needed by either test. CPU Torch/oneDNN and platform runtime dependencies remain part of the ordinary complete CPU route.'],
 archive=ident(archive))
(D/(stem+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'proof':ident(D/(stem+'.json')),'archive':ident(archive),'fresh_TUs':len(fresh_objects),'cached_objects':len(cached_objects)},indent=2))
