"""Freeze a source-only numeric review. Does not import CUDA/Torch or run a test."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import re

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ARCH = STAGE.parent


def identity(path):
    path = Path(path).resolve()
    payload = path.read_bytes()
    return dict(path=str(path), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


paths = [
    'include/hyle/compute/model_ops.h',
    'include/hyle/compute/operation.h',
    'src/compute_ops/low_precision.cc',
    'src/compute_provider_cuda/grouped_fp8_provider.cc',
    'src/compute_provider_cuda/fp8_provider.cc',
    'src/compute_provider_native/torch_cpu_program.cc',
    'third_party/torchao_cpu/torchao_cpu.h',
    'third_party/sglang_activation/fp8/grouped/original_kernels.py',
    'third_party/sglang_activation/fp8/grouped/source.json',
    'third_party/sglang_activation/fp8/grouped/compilation.json',
    'third_party/sglang_activation/fp8/grouped/rebuild.py',
    'third_party/sglang_activation/fp8/original_kernels.py',
    'third_party/sglang_activation/fp8/source.json',
    'tests/compute_provider_cuda/grouped_fp8_test.cc',
    'tests/compute_provider_cuda/CMakeLists.txt',
    'docs/user/compute.md',
]
sources = []
for relative in paths:
    path = ROOT / relative
    snapshot = STAGE / 'source' / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    row = dict(relative=relative, source=identity(path), snapshot=identity(snapshot))
    assert row['source']['sha256'] == row['snapshot']['sha256']
    sources.append(row)

header = ROOT / 'third_party/sglang_activation/fp8/grouped/sglang_grouped_fp8_sm89.h'
text = header.read_text(encoding='utf-8')
compilation = json.loads((ROOT / 'third_party/sglang_activation/fp8/grouped/compilation.json').read_text())
embedded = []
for name, label in [('kGroupedF32', 'grouped_fp32'), ('kGroupedBf16', 'grouped_bf16')]:
    found = re.search(r'\b' + name + r'\[\]\s*=\s*\{(.*?)\};', text, re.S)
    assert found
    payload = bytes(int(value, 16) for value in re.findall(r'0x([0-9a-fA-F]{2})', found.group(1)))
    job = next(value for value in compilation['kernels'] if value['label'] == label)
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == job['cubin_sha256']
    assert job['constexprs']['BLOCK_SIZE_N'] == job['constexprs']['group_n'] == 128
    embedded.append(dict(name=name, label=label, bytes=len(payload), sha256=digest,
                         compilation_matches=True, constexprs=job['constexprs'],
                         compiler_metadata=job['metadata']))

recipe = ARCH / 'cuda-grouped-fp8-slots/validation/final-recipes.json'
prior = json.loads(recipe.read_text())
current_link = ARCH / 'gdn-direct-state-output/checks/native1/tests-link-plan.json'
save(STAGE / 'recipe-sources.json', dict(
    host_compile_recipe=dict(file=identity(recipe), key='grouped-test',
                             command=prior['grouped-test']['command']),
    link_base=identity(current_link),
    reusable_helpers=identity(ARCH / 'gdn-direct-state-output/build.py'),
    instruction='Root may compile only stage test.cc with cached /W4 /WX host recipe, '
                'add its object to current CUDA test link, and run only '
                'CudaGroupedFp8ScaleOrder.ZeroCodesAndFiniteScalesKeepZeroProducts. '
                'No AOT/provider/SDK rebuild is needed for actual-before reproduction.',
    staged_test=identity(STAGE / 'test.cc'),
    expected_scope=dict(gtest_cases=1, activation_types=['F32', 'BF16'], gpu_runs=0,
                        product_changes=0, AOT_changes=0),
))
save(STAGE / 'sourceids.json', dict(
    created_utc=dt.datetime.now(dt.timezone.utc).isoformat(), sources=sources,
    AOT_header=identity(header), verified_embedded_images=embedded,
    staged_test=identity(STAGE / 'test.cc'),
    review_recorder=identity(Path(__file__)),
))
review = dict(
    status='source_review_complete_actual_GPU_reproduction_pending',
    product_changed=False, GPU_executed=False, compiled=False,
    public_contract=dict(
        activation='Finite dense BF16/F32 activations; ordinary F32 group128 scales. '
                   'Grouped quantization follows Float8BlockLinear.',
        weights='Canonical E4M3FN [E,N,K] payload and following F32 scale table. '
                'No public upper bound on finite F32 weight scales exists.',
        precision='OperationTraits declares F32 accumulation. It does not explicitly order '
                  'the two scale multiplies or promise finite output for all finite inputs.',
        zero_case='A finite scale times an encoded zero represents an exact zero weight. '
                  'This witness has no nonzero decoded weight or overflowing dot/output; '
                  'only the implementation-created product As*Bs overflows.',
        limitation='An explicit scaling-order clause is missing; source provenance alone '
                   'does not establish that producing NaN for this zero-weight case is reasonable.'),
    admission=dict(
        description='E=1,N=128,K=128,T=1,A=1,S=1, default absmax_floor=1e-10; '
                    'both F32/BF16 activation descriptors satisfy public inference.',
        native_shape='e<=1022; selected=1; slots=1; n*k=16384; indexing and padded grid pass. '
                     'capacity=192; rows=1; quant_groups=1; small align=true.',
        payload='All E4M3FN codes positive zero, one F32 weight scale 2^127 finite; '
                'A[0]=896, all other A=+0, ID=0. Submitted buffers align to 256.',
        checks='Prepared selection validates descriptors/layout/index capacity and SM89. '
               'There is no scale-payload upper bound scan or payload restriction rejecting '
               'this finite scale. No runtime admission has been claimed yet.'),
    arithmetic=dict(
        quantization='896 / 448 = 2 exactly; reciprocal=0.5 and 896*0.5=448 exactly. '
                     'BF16 896 is exact. Thus this witness avoids ordinary division/reciprocal '
                     'and code-rounding ambiguities.',
        dot='All weight codes are zero, so every native MMA product and its accumulated '
            'dot are exactly zero, independently of ordinary F32-vs-native-FP8 dot issues.',
        CUDA_source='BLOCK_SIZE_N=group_n=128 selects accumulator += '
                    'tl.dot(a,b) * (a_scale[:,None] * b_scale). '
                    'As*Bs=2^128 overflows F32 to Inf; zero times Inf is NaN.',
        CPU_source='block_dot/grouped_block_dot compute scaled = dots * activation_scales; '
                   'next = prior + scaled * weight_scales. Zero remains zero.',
        single_linear_source='The pinned single-linear kernel spells '
                             'accumulator += tl.dot(a,b) * a_s[:,None] * b_s[None,:]. '
                             'This is source evidence; actual single-linear GPU was not run.',
        compiler_limit='Compilation metadata and embedded cubin digests are verified, '
                       'but actual CUDA arithmetic/output must be observed before confirming '
                       'the runtime defect. No AOT recompilation or disassembly was performed.'),
    regression=dict(
        file=str(STAGE / 'test.cc'),
        test='CudaGroupedFp8ScaleOrder.ZeroCodesAndFiniteScalesKeepZeroProducts',
        checks='One semantic gtest covers both output dtypes. Independent volatile host '
               'IEEE arithmetic proves zero for dot-first scaling and NaN for prescaled '
               'overflow. Actual SGLang provider preparation/submission/Completion then '
               'must produce 128 finite zeros. NaN/Inf/finite-nonzero counts and first '
               'F32 bits are recorded in XML. No tolerance is enlarged.',
        actual_results='Not run by this agent. Root owns compilation and GPU execution.'),
    decision_after_reproduction='If actual CUDA produces NaN, treat as an admitted-domain '
                                'semantic hole. Establish the intended scale-multiply '
                                'contract and preserve exact zero/finite scale semantics '
                                'across actual implementations; do not justify NaN by '
                                'upstream provenance or silently narrow the public domain. '
                                'Do not change AOT or existing thresholds before root observes it.',
    incidental_docs='docs/user/compute.md still says S=8, but current product admission '
                    'and prior S3/6/10/16 evidence allow runtime slots. This stale prose '
                    'does not constrain actual admission; not modified in this review.',
)
save(STAGE / 'review.json', review)
print(json.dumps(dict(source_files=len(sources), embedded_images=len(embedded),
                      test=identity(STAGE / 'test.cc'), review=identity(STAGE / 'review.json')),
                 ensure_ascii=False))
