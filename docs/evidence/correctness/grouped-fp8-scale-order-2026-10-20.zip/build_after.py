"""Compile one changed grouped owner and its current regression TU only."""
import concurrent.futures
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('fp8_scale_after_helpers', A/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'checks'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
inventory = c.read(S/'final-owner-inventory.json')
base = c.read(inventory['base_path'])
owner = inventory['grouped_owner']
rows = []
for tag, source, recipe in [
    ('grouped-provider', ROOT/'src/compute_provider_cuda/grouped_fp8_provider.cc', owner['owner']['command']),
    ('grouped-test', ROOT/'tests/compute_provider_cuda/grouped_fp8_test.cc', c.read(A/'bf16-grouped-bank/checks/native1/grouped-test-identity.json')['command'])]:
    rows.append(dict(tag=tag, source=b.identity(source), command=b.host_command(recipe, source, tag, out),
        object=str(out/(tag+'.obj'))))
frozen = [row['after'] for row in c.read(S/'source-fix.json')['product_sources']]
frozen += [row['after'] for row in c.read(S/'aot-product-freeze.json')['files']]
frozen += [row['source'] for row in rows]
original_test = c.read(S/'reproduction/scale-test-identity.json')
for row in original_test['dependencies']:
    assert b.same(row), row['path']
state = c.read(A/'state-clone-observer-close/checks/after-state_versions-identity.json')
for row in state['dependencies']:
    assert b.same(row), row['path']
frozen += [original_test['object'], state['object']]
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
plan = dict(compile=rows, frozen=frozen, base=inventory['base_path'], host_TUs=2,
    native_TUs=0, offline_Triton_jobs=2, SDK_rebuild=False, retained_fresh_state_owner=state['object'])
c.save(out/'plan.json', plan)
c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))

def check():
    for row in frozen:
        assert b.same(row), row['path']

def compile_one(row):
    check()
    c.execute(row['tag']+'-compile', row['command'], env, out)
    check()
    dep = c.read(out/(row['tag']+'-deps.json'))['Data']
    receipt = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
        dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])])
    c.save(out/(row['tag']+'-identity.json'), receipt)
    return row['tag'], receipt

finished = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in concurrent.futures.as_completed([pool.submit(compile_one, row) for row in rows]):
        tag, result = future.result()
        finished[tag] = result
replacement = {c.key(owner['old_object']['path']): finished['grouped-provider']['object'],
    c.key(inventory['state_header_owners'][0]['old_object']['path']): state['object']}
lookup = {c.key(row['path']): row for row in base['inputs']}
added = [finished['grouped-test']['object'], original_test['object']]
lookup.update({c.key(row['path']): row for row in [*replacement.values(), *added]})
command = [replacement.get(c.key(arg), {}).get('path', arg) for arg in base['command']
    if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
command[1:1] = [row['path'] for row in added]
image = out/'tests.exe'
command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs = [lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
assert len(inputs)==len({c.key(row['path']) for row in inputs})
for row in inputs:
    assert b.same(row), row['path']
check()
c.execute('tests-link', command, env, out)
check()
c.save(out/'tests-link-plan.json', dict(command=command, inputs=inputs))
c.save(out/'tests-image.json', b.identity(image))
plan['link'] = dict(command=command, inputs=inputs)
c.save(out/'plan.json', plan)
c.save(out/'summary.json', dict(passed=True, host_TUs=2, native_TUs=0, offline_Triton_jobs=2,
    SDK_rebuild=False, fresh_state_header_owner_reused=True))
print('GROUPED_SCALE_AFTER_BUILT', flush=True)
