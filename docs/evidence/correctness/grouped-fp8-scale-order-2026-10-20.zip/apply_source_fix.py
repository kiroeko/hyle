"""Apply only the reviewed adapter, regression and narrowly related prose."""
from pathlib import Path
import hashlib
import json
import difflib

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
paths = [
    'third_party/sglang_activation/fp8/grouped/source.json',
    'third_party/sglang_activation/fp8/grouped/rebuild.py',
    'third_party/sglang_activation/NOTICE',
    'docs/user/compute.md',
    'tests/compute_provider_cuda/grouped_fp8_test.cc',
]


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def identity(path):
    blob = path.read_bytes()
    return dict(path=str(path), bytes=len(blob), sha256=sha(blob))


originals = {}
for relative in paths:
    path = ROOT / relative
    snapshot = STAGE / 'before-source-fix' / relative
    assert not snapshot.exists(), snapshot
    originals[relative] = path.read_bytes()
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(originals[relative])

relative = paths[0]
source = json.loads(originals[relative])
upstream = ROOT / 'third_party/sglang_activation/fp8/grouped/original_kernels.py'
assert sha(upstream.read_bytes()) == source['module_sha256']
text = upstream.read_text(encoding='utf-8').replace('\r\n', '\n')
adapter = source['runtime_top_k']
assert text.count(adapter['before']) == 1
text = text.replace(adapter['before'], adapter['after'])
assert sha(text.encode()) == adapter['module_sha256']
before = '                    accumulator += tl.dot(a, b) * (a_scale[:, None] * b_scale)'
after = '''                    # HYLE: preserve dot -> activation scale -> weight scale.
                    # Explicit F32 RNE prevents reassociation/FFMA from creating
                    # an overflowing As*Bs for otherwise finite zero weights.
                    block_dot = tl.dot(a, b)
                    scaled_dot = tl.inline_asm_elementwise(
                        "mul.rn.f32 $0, $1, $2;", "=f,f,f",
                        [block_dot, a_scale[:, None]], dtype=tl.float32,
                        is_pure=True, pack=1,
                    )
                    scaled_dot = tl.inline_asm_elementwise(
                        "mul.rn.f32 $0, $1, $2;", "=f,f,f",
                        [scaled_dot, b_scale], dtype=tl.float32,
                        is_pure=True, pack=1,
                    )
                    accumulator += scaled_dot'''
assert text.count(before) == 1
text = text.replace(before, after)
assert 'scale_order' not in source
source['scale_order'] = dict(
    description='For the qualified block128 jobs, scale the F32 code dot by the '
                'activation scale, then by the weight scale, with two explicit '
                'F32 RNE multiplies before the original F32 accumulation. Do not '
                'form As*Bs first: finite scales can overflow even for zero weights. '
                'The pinned upstream body, quantizer, dot, output conversion, '
                'sorting, tiles and launch ABI remain unchanged.',
    input_module_sha256=adapter['module_sha256'], before=before, after=after,
    module_sha256=sha(text.encode()),
)
(ROOT / relative).write_text(json.dumps(source, indent=2) + '\n', encoding='utf-8', newline='\n')
(STAGE / 'adapted-kernels.py').write_text(text, encoding='utf-8', newline='\n')

relative = paths[1]
text = originals[relative].decode().replace('\r\n', '\n')
before = '''    # Only the indexing divisor becomes a runtime argument. Keep the pinned
    # upstream source intact and prove the exact adapted module before AOT.
    adapter = source['runtime_top_k']
    text = original.read_text(encoding='utf-8').replace('\\r\\n', '\\n')
    assert text.count(adapter['before']) == 1
    text = text.replace(adapter['before'], adapter['after'])
    assert hashlib.sha256(text.encode()).hexdigest() == adapter['module_sha256']
    adapted = args.output/'runtime_top_k_kernels.py'
    adapted.write_text(text, encoding='utf-8', newline='\\n')
    spec = importlib.util.spec_from_file_location('grouped_runtime_top_k', adapted)'''
after = '''    # Preserve the pinned body; prove the exact indexing and numeric adapters
    # in sequence before importing the final module for either output dtype.
    text = original.read_text(encoding='utf-8').replace('\\r\\n', '\\n')
    for name in ('runtime_top_k', 'scale_order'):
        adapter = source[name]
        if 'input_module_sha256' in adapter:
            assert hashlib.sha256(text.encode()).hexdigest() == adapter['input_module_sha256']
        assert text.count(adapter['before']) == 1
        text = text.replace(adapter['before'], adapter['after'])
        assert hashlib.sha256(text.encode()).hexdigest() == adapter['module_sha256']
    adapted = args.output/'adapted_kernels.py'
    adapted.write_text(text, encoding='utf-8', newline='\\n')
    spec = importlib.util.spec_from_file_location('grouped_adapted', adapted)'''
assert text.count(before) == 1
(ROOT / relative).write_text(text.replace(before, after), encoding='utf-8', newline='\n')

relative = paths[2]
text = originals[relative].decode().replace('\r\n', '\n')
text = text.replace('device error code; valid sorting/scan/GEMM arithmetic is unchanged. Two',
                    'device error code; valid sorting/scan arithmetic is unchanged. Two')
before = '''The grouped FP8 adapter makes only the original top_k indexing divisor a
runtime I32 argument, supplied from the actual prepared activation/ID shape.
Shared inputs pass the selected slot count; distinct per-slot inputs pass 1.
F32/BF16 variants retain the original quantizer, F32 dot/scaling and output
conversion. The pinned Python body is unchanged; source.json records the
single annotation replacement used only during offline AOT. No Top-K or
model-name whitelist, activation replication or runtime compiler is required.
'''
after = '''The grouped FP8 indexing adapter makes the original top_k divisor a runtime
I32 argument, supplied from the actual prepared activation/ID shape. Shared
inputs pass the selected slot count; distinct per-slot inputs pass 1.
The numeric adapter scales each F32 code dot by its activation scale, then
its weight scale, with two explicit mul.rn.f32 operations before the original
F32 accumulation. It avoids an overflowing As*Bs and NaN for finite zero
weights, matching the CPU scaling order. The original quantizer, dot, output
conversion, tiles and checked alignment are retained. The pinned Python body
is unchanged; source.json records and hashes both offline-only adaptations.
No Top-K or model-name whitelist, activation replication or runtime compiler
is required.
'''
assert text.count(before) == 1
(ROOT / relative).write_text(text.replace(before, after), encoding='utf-8', newline='\n')

relative = paths[3]
text = originals[relative].decode().replace('\r\n', '\n')
before = '''当前 CUDA 支持条件为 SM89、`S=8`、`1<=E<=1022` 和完整 K128 分组，
使用普通 F32 scale、默认 floor `1e-10`。其它域在准备阶段明确拒绝。激活需16字节对齐，'''
after = '''当前 CUDA 支持条件为 SM89、`1<=E<=1022` 和完整 K128 分组；S为实际选中slot数，不固定为8，
并受原生索引和padding容量约束。使用普通 F32 scale、默认 floor `1e-10`。其它域在准备阶段明确拒绝。激活需16字节对齐，'''
assert text.count(before) == 1
text = text.replace(before, after)
before = '''host 调度、ID读回或权重解码。负数及越界 ID 安全返回失败 Completion；失败输出不可消费。
单expert的 `N*K`'''
after = '''host 调度、ID读回或权重解码。负数及越界 ID 安全返回失败 Completion；失败输出不可消费。
每个K128代码点积先乘本组activation scale，再乘weight scale；两次乘法分别按F32 RNE舍入，随后F32累加。
不能先合并两份scale：例如零权重codes、activation scale为2、有限weight scale为`2^127`时，
预乘scale会溢出并把本应为零的点积变成NaN。此顺序不保证所有有限输入的非零结果都不会溢出。
单expert的 `N*K`'''
assert text.count(before) == 1
(ROOT / relative).write_text(text.replace(before, after), encoding='utf-8', newline='\n')

# Keep the already executed before witness as a separate immutable stage TU;
# land its same semantic assertions in the existing product test owner.
relative = paths[4]
text = originals[relative].decode().replace('\r\n', '\n')
assert '#include <string>\n' not in text
text = text.replace('#include <span>\n', '#include <span>\n#include <string>\n')
staged = (STAGE / 'test.cc').read_text(encoding='utf-8')
start = staged.index('// This is a semantic witness,')
body = staged[start:].removesuffix('} // namespace\n')
body = body.replace('TEST(CudaGroupedFp8ScaleOrder,', 'TEST(CudaGroupedFp8,')
# The existing owner's reader losslessly widens its result to double.
body = body.replace('std::bit_cast<std::uint32_t>(actual.front())',
                    'std::bit_cast<std::uint32_t>(static_cast<float>(actual.front()))')
assert text.endswith('} // namespace\n')
text = text.removesuffix('} // namespace\n') + '\n' + body + '} // namespace\n'
(ROOT / relative).write_text(text, encoding='utf-8', newline='\n')

rows, diffs = [], []
for relative in paths:
    path = ROOT / relative
    before = STAGE / 'before-source-fix' / relative
    after = STAGE / 'source-fix' / relative
    after.parent.mkdir(parents=True, exist_ok=True)
    after.write_bytes(path.read_bytes())
    rows.append(dict(relative=relative, before=identity(before), after=identity(path),
                     snapshot=identity(after)))
    diffs.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
                                    after.read_text(encoding='utf-8').splitlines(True),
                                    fromfile='a/' + relative, tofile='b/' + relative))
(STAGE / 'source-fix.diff').write_text(''.join(diffs), encoding='utf-8', newline='\n')
result = dict(product_sources=rows, upstream_unchanged=identity(upstream),
              adapted_module=identity(STAGE / 'adapted-kernels.py'),
              source_adapter_sha256=source['scale_order']['module_sha256'],
              build_executed=False, GPU_executed=False,
              AOT_header_updated=False, compilation_json_updated=False,
              lock_update='Root must update sglang vendored tree and NOTICE SHA256 after final AOT/header and compilation.json.')
(STAGE / 'source-fix.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(changed=len(rows), adapted_sha256=source['scale_order']['module_sha256'],
                      original_sha256=identity(upstream)['sha256'])))
