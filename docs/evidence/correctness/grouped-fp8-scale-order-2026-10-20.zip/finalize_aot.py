"""Embed the two actual new cubins, retain checked align, update source identity."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
vendor = ROOT/'third_party/sglang_activation'
grouped = vendor/'fp8/grouped'

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def identity(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

changed = ['third_party/sglang_activation/fp8/grouped/compilation.json',
           'third_party/sglang_activation/fp8/grouped/sglang_grouped_fp8_sm89.h',
           'cmake/HyleDependencyLock.json']
before = []
for name in changed:
    source = ROOT/name
    snapshot = S/'before-aot'/name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    if snapshot.exists():
        assert snapshot.read_bytes()==source.read_bytes(), snapshot
    else:
        shutil.copyfile(source, snapshot)
    before.append(dict(relative=name, original=identity(source), snapshot=identity(snapshot)))
old_lock = read(ROOT/'cmake/HyleDependencyLock.json')
entry = next(row for row in old_lock['dependencies'] if row['name']=='sglang_activation')
old_overrides = {row['relative']: Path(row['before']['path']) for row in read(S/'source-fix.json')['product_sources']}
old_overrides.update({row['relative']: Path(row['snapshot']['path']) for row in before})

def tree(overrides):
    lines = []
    for p in sorted(vendor.rglob('*'), key=lambda p:p.relative_to(vendor).as_posix()):
        if not p.is_file():
            continue
        assert not p.is_symlink()
        actual = overrides.get(p.relative_to(ROOT).as_posix(), p)
        content = actual.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
        lines.append(p.relative_to(vendor).as_posix()+'|'+hashlib.sha256(content).hexdigest()+'\n')
    return hashlib.sha256(''.join(lines).encode()).hexdigest()

assert tree(old_overrides)==entry['vendored']['tree_sha256']
text = (grouped/'sglang_grouped_fp8_sm89.h').read_text(encoding='utf-8')
match = re.search(r'inline constexpr unsigned char kCheckedAlign\[\] = \{(.*?)\};', text, re.S)
assert match
align = bytes(int(token, 16) for token in re.findall(r'0x([0-9a-fA-F]{2})', match.group(1)))
assert hashlib.sha256(align).hexdigest()==read(grouped/'align-compilation.json')['cubin_sha256']
(S/'aot/checked_original_align.cubin').write_bytes(align)
new_jobs = read(S/'new-compilation.json')
old_jobs = read(grouped/'compilation.json')
for new, old in zip(new_jobs['kernels'], old_jobs['kernels'], strict=True):
    for key in ('label', 'signature', 'constexprs', 'options'):
        assert new[key]==old[key]
    assert identity(S/'aot'/(new['label']+'.cubin'))['sha256']==new['cubin_sha256']
shutil.copyfile(S/'new-compilation.json', grouped/'compilation.json')
command = [sys.executable, str(grouped/'rebuild.py'), '--stage', 'header', '--output', str(S/'aot')]
subprocess.run(command, check=True)
shutil.copyfile(S/'aot/sglang_grouped_fp8_sm89.h', grouped/'sglang_grouped_fp8_sm89.h')
new_text = (grouped/'sglang_grouped_fp8_sm89.h').read_text(encoding='utf-8')
current_align = re.search(r'inline constexpr unsigned char kCheckedAlign\[\] = \{(.*?)\};', new_text, re.S)
assert match.group(1)==current_align.group(1)
entry['vendored']['tree_sha256'] = tree({})
notice = next(row for row in entry['license']['files'] if row['path']=='third_party/sglang_activation/NOTICE')
notice['sha256'] = identity(vendor/'NOTICE')['sha256']
save(ROOT/'cmake/HyleDependencyLock.json', old_lock)
rows = []
for row in before:
    actual = ROOT/row['relative']
    frozen = S/'product-aot'/row['relative']
    frozen.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(actual, frozen)
    rows.append(dict(**row, after=identity(actual), frozen=identity(frozen)))
save(S/'aot-product-freeze.json', dict(files=rows, fixed_source=identity(grouped/'original_kernels.py'),
    adapted_module=identity(S/'aot/adapted_kernels.py'), new_compilation=identity(S/'new-compilation.json'),
    checked_align_unchanged=True, job_geometry_and_ABI_unchanged=True, header_command=command,
    old_tree_reconstructed_and_verified=True, new_vendored_tree=entry['vendored']['tree_sha256']))
print('GROUPED_SCALE_AOT_EMBEDDED', entry['vendored']['tree_sha256'], flush=True)
