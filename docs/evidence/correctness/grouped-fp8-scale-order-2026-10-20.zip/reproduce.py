"""One focused fresh test TU against the retained actual CUDA product closure."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('fp8_scale_repro_helpers', A/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'reproduction'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
base_path = A/'gdn-direct-state-output/checks/native1/tests-link-plan.json'
base = c.read(base_path)
recipe = c.read(A/'bf16-grouped-bank/checks/native1/grouped-test-identity.json')['command']
source = S/'test.cc'
command = b.host_command(recipe, source, 'scale-test', out)
for row in base['inputs']:
    assert b.same(row), row['path']
frozen = b.identity(source)
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
c.save(out/'inputs.json', dict(source=frozen, base_path=str(base_path), runtime=runtime,
    compiler_command=command, SDK_rebuild=False, product_changed=False))
c.execute('scale-test-compile', command, env, out)
assert b.same(frozen)
obj = b.identity(out/'scale-test.obj')
dep = c.read(out/'scale-test-deps.json')['Data']
c.save(out/'scale-test-identity.json', dict(command=command, source=frozen, object=obj,
    dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]))
lookup = {c.key(row['path']): row for row in base['inputs']}
lookup[c.key(obj['path'])] = obj
argv = [arg for arg in base['command'] if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
argv.insert(1, obj['path'])
image = out/'tests.exe'
argv += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs = [lookup[c.key(arg)] for arg in argv if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
assert len(inputs) == len({c.key(row['path']) for row in inputs})
c.save(out/'link-plan.json', dict(command=argv, inputs=inputs))
c.execute('tests-link', argv, env, out)
c.save(out/'image.json', b.identity(image))
try:
    c.execute('tests', [str(image), '--gtest_filter=CudaGroupedFp8ScaleOrder.*',
        '--gtest_output=xml:'+str(out/'results.xml')], env, out)
except RuntimeError:
    assert c.read(out/'tests.result.json')['exit'] == 1
cases = ET.parse(out/'results.xml').findall('.//testcase')
assert len(cases) == 1 and cases[0].find('skipped') is None
properties = {row.attrib['name']: row.attrib['value'] for row in cases[0].findall('properties/property')}
confirmed = cases[0].find('failure') is not None and properties.get('f32_nan_count') == '128' and properties.get('bf16_nan_count') == '128'
c.save(out/'summary.json', dict(executed=True, defect_confirmed=confirmed, cases=1,
    properties=properties, exit=c.read(out/'tests.result.json')['exit'],
    failures=[f.text for f in cases[0].findall('failure')],
    expected_red=True, no_product_edit=True, native_or_SDK_compilations=0))
assert confirmed, properties
print('GROUPED_FP8_SCALE_ORDER_REPRODUCED', properties, flush=True)
