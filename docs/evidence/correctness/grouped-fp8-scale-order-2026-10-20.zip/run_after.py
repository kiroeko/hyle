"""Original failure witness plus the current Direct/Graph/checked-ID neighbors."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fp8_scale_after_test_helpers', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'tests'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
link = c.read(S/'checks/tests-link-plan.json')
image = c.read(S/'checks/tests-image.json')
assert b.same(image)
env, runtime = b.environment(link['command'], [row['path'] for row in link['inputs']], out)
filters = 'CudaGroupedFp8.*:CudaGroupedFp8ScaleOrder.*'
c.save(out/'inputs.json', dict(image=image, filters=filters, runtime=runtime, expected_cases=5))
c.execute('tests', [image['path'], '--gtest_filter='+filters, '--gtest_output=xml:'+str(out/'results.xml')], env, out)
cases = ET.parse(out/'results.xml').findall('.//testcase')
failures = [dict(name=row.attrib['classname']+'.'+row.attrib['name'], details=[f.text for f in row.findall('failure')])
    for row in cases if row.find('failure') is not None]
skipped = sum(row.find('skipped') is not None for row in cases)
assert len(cases)==5 and not skipped and not failures
properties = {row.attrib['name']: row.attrib['value'] for case in cases for row in case.findall('properties/property')}
for kind in ('f32', 'bf16'):
    assert properties[kind+'_nan_count']=='0' and properties[kind+'_finite_nonzero_count']=='0'
c.save(out/'summary.json', dict(passed=True, cases=5, skipped=skipped, failures=failures, properties=properties,
    actual=[row.attrib['classname']+'.'+row.attrib['name'] for row in cases], image=image,
    limits='Actual SM89 Direct, common Graph, checked IDs and finite-zero scale witness. No new Qwen/model quality, throughput or cross-platform run.'))
print('GROUPED_SCALE_AFTER_TESTS', len(cases), properties, flush=True)
