"""Inspect actual native cubins and the dependency's own CMake tree identity."""
import importlib.util
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fp8_scale_inspect_helpers', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'native-inspection'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
base = c.read(S/'gpu-owner-inventory.json')
link = c.read(base['base_path'])
env, runtime = b.environment(link['command'], [row['path'] for row in link['inputs']], out)
nvdisasm = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/nvdisasm.exe')
assert nvdisasm.is_file()
commands = {label:[str(nvdisasm), str(S/'aot'/(label+'.cubin'))] for label in ('grouped_fp32', 'grouped_bf16')}
commands['vendored'] = [shutil.which('cmake'), '-P', str(S/'verify-vendored.cmake')]
assert commands['vendored'][0]
c.save(out/'inputs.json', dict(commands=commands, runtime=runtime, offline=True))
for tag, command in commands.items():
    c.execute(tag, command, env, out)
print('GROUPED_SCALE_NATIVE_INSPECTED', flush=True)
