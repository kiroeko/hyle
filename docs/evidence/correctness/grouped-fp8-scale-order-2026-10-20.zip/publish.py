"""Publish the confirmed admitted-domain FP8 scaling defect and narrow fix."""
from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identity(path):
    path = Path(path).resolve()
    payload = path.read_bytes()
    return dict(path=str(path), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())


def same(row):
    return identity(row['path']) == {key: row[key] for key in ('path', 'bytes', 'sha256')}


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


before = read(S / 'reproduction/summary.json')
after = read(S / 'tests/summary.json')
build = read(S / 'checks/summary.json')
review = read(S / 'independent-native-review.json')
source = read(S / 'source-fix.json')
aot = read(S / 'aot-product-freeze.json')
regeneration = read(S / 'native-inspection/canonical-gemm-rebuild.result.json')
assert regeneration['exit'] == 0 and regeneration['terminal']
assert 'third_party/sglang_activation/fp8/grouped/rebuild.py' in regeneration['command']
assert before['defect_confirmed'] and before['expected_red'] and before['exit'] == 1
assert before['properties']['f32_nan_count'] == before['properties']['bf16_nan_count'] == '128'
assert after['passed'] and after['cases'] == 5 and after['skipped'] == 0 and not after['failures']
assert all(value == '0' for value in after['properties'].values())
assert build['passed'] and build['host_TUs'] == 2 and build['native_TUs'] == 0
assert not review['blocking_findings'] and review['status'].endswith('review_complete')
assert aot['checked_align_unchanged'] and aot['job_geometry_and_ABI_unchanged']
for row in source['product_sources']:
    assert same(row['after']) and same(row['snapshot'])
for row in aot['files']:
    assert same(row['after']) and same(row['frozen'])
assert same(aot['fixed_source']) and same(aot['adapted_module'])
assert ET.parse(S / 'reproduction/results.xml').getroot().attrib['failures'] == '1'
green = ET.parse(S / 'tests/results.xml').getroot()
assert green.attrib['tests'] == '5' and green.attrib['failures'] == '0'

old_test = read(S / 'reproduction/scale-test-identity.json')
green_link = read(S / 'checks/tests-link-plan.json')
retained = [row for row in green_link['inputs'] if row['path'] == old_test['object']['path']]
assert len(retained) == 1 and retained[0] == old_test['object'] and same(retained[0])

docs = []
for relative in ('docs/developer/current-work.md', 'docs/implementation/model-operators.md'):
    path = ROOT / relative
    snapshot = S / 'documentation' / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    docs.append(dict(path=relative, current=identity(path), snapshot=identity(snapshot)))
save(S / 'documentation-freeze.json', docs)

suffixes = {'.py', '.cc', '.h', '.json', '.log', '.xml', '.diff', '.cmake',
            '.md', '.ptx', '.llir', '.ttir', '.ttgir'}
files = []
for path in S.rglob('*'):
    if not path.is_file():
        continue
    relative = path.relative_to(S)
    if any(part.lower() in ('cache', 'tmp', '__pycache__') for part in relative.parts):
        continue
    if any('cleanup' in part.lower() for part in relative.parts):
        continue
    if path.name in ('archive-manifest.json', 'archive-receipt.json'):
        continue
    if path.suffix.lower() not in suffixes and path.name != 'NOTICE':
        continue
    # The exact new embedded header is already retained under product-aot;
    # cubins are represented there without duplicating binary payloads.
    if relative.as_posix() == 'aot/sglang_grouped_fp8_sm89.h':
        continue
    files.append(path)
files.sort(key=lambda path: path.relative_to(S).as_posix())

archive_path = ROOT / 'docs/evidence/correctness/grouped-fp8-scale-order-2026-10-20.zip'
rows = []
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        row = dict(**identity(path), member=path.relative_to(S).as_posix())
        rows.append(row)
        archive.writestr(row['member'], path.read_bytes())
    manifest = json.dumps(rows, indent=2, ensure_ascii=False).encode()
    archive.writestr('payload-sha256.json', manifest)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(rows) + 1
    assert json.loads(archive.read('payload-sha256.json')) == rows
    for row in rows:
        payload = archive.read(row['member'])
        assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']

body = dict(
    date='2026-10-20',
    scope='GroupedFloat8Linear canonical block128 SM89 F32/BF16 native variants; admitted finite-zero weight case.',
    defect='The native grouped kernel formed As*Bs before scaling its code dot. Two individually '
           'finite F32 scales could overflow, turning an exactly zero weight/dot result into NaN.',
    witness=dict(E=1, T=1, S=1, N=128, K=128,
                 activation='896 at index0, positive zero elsewhere; both F32 and BF16 inputs',
                 weight_codes='All positive zero E4M3FN', weight_scale='F32 2^127 finite',
                 exact_activation_scale=2,
                 independent_arithmetic='dot=0; (dot*As)*Bs=0, but As*Bs=Inf and dot*Inf=NaN',
                 before='Actual SM89: successful Completion but 128 NaNs for each output dtype; same staged gtest exits1 as expected.',
                 after='Actual SM89 with new AOT: both output dtypes contain 128 zeros; original staged test object is reused.'),
    fix='Keep pinned original_kernels.py unchanged. Apply existing runtime_top_k adaptation, then '
        'an independently hashed scale_order replacement: FP8 code dot, explicit mul.rn.f32 by As, '
        'explicit mul.rn.f32 by Bs, then original F32 outer accumulation/output conversion. '
        'No scale-domain narrowing, widened tolerance, new public precision policy, extra copy or executor.',
    actual_before=before, actual_after=after, build=build,
    canonical_regeneration=dict(
        result=regeneration,
        description='Actual product rebuild.py --stage gemm under WSL Triton3.8 completed '
                    'successfully using the existing cache, with both new cubin SHA256 '
                    'assertions inside the canonical script. No SDK rebuild.',
        records=[identity(S / 'native-inspection' / ('canonical-gemm-rebuild' + ending))
                 for ending in ('.command.json', '.result.json', '.stdout.log', '.stderr.log')]),
    same_test_object=retained[0],
    source_freeze=source, generated_AOT_freeze=aot,
    independent_native_review=review,
    numerical_boundaries=dict(
        PTX_and_SASS='Both actual new variants retain 128 FMUL and64 FADD instructions around the original64 FP8 MMA instructions; reviewer verified scale dataflow and no FTZ on these arithmetic operations.',
        unchanged='Pinned source, quantizer, FP8 MMA, two job signatures/constexprs/options, sorting, tile geometry, launch ABI and checked align payload.',
        public_header='model_ops.h was not modified. CUDA user documentation describes the two scale multiplies and correct runtime slot domain.'),
    tooling_failure=dict(record=read(S / 'finalize-initial-result.json'),
                         resolution='Match CMake portable relative-string case-sensitive sorting. '
                                    'Old vendored tree reconstructed before mutation, new source tree verified by actual CMake script.',
                         old_and_corrected_scripts='finalize_aot-before-path-sort.py and finalize_aot.py are archived.'),
    archive=identity(archive_path), payload_count=len(rows),
    payloads=rows, archive_verified=dict(CRC=True, all_payload_SHA256=True),
    archive_policy='Includes old-red logs/XML, same-test green logs/XML, recipes/identities, old/new '
                   'source and embedded AOT headers, compilation/lock records, actual PTX/SASS and '
                   'independent review. Excludes executables, objects, libraries, maps, scratch cache '
                   'and cleanup records. Standalone cubins are not duplicated because their exact '
                   'bytes are present in archived embedded headers.',
    limits=[
        'Five actual CUDA cases, zero skips: existing Direct/Graph/runtime-slot/checked-ID coverage, product semantic regression and original staged witness.',
        'CPU source establishes the scaling order; this batch did not execute new CPU, Apple or Vulkan tests and does not prove universal cross-platform bit parity.',
        'Native FP8 MMA keeps its original numerical behavior. F32 accumulation naming does not prove ordinary decoded IEEE F32 MatMul equivalence.',
        'This fixes an admitted finite-zero-weight defect. Nonzero dot, scaled products or sums can still overflow; no finite-output guarantee for all finite inputs is claimed.',
        'No selected FP8 artifact/full model execution, model quality evaluation, throughput test, other GPU architecture or peak-memory measurement was performed for this fix.',
    ],
)
save(archive_path.with_suffix('.json'), body)
save(S / 'archive-manifest.json', rows)
save(S / 'archive-receipt.json', dict(archive=identity(archive_path),
                                    public_record=identity(archive_path.with_suffix('.json')),
                                    payloads=len(rows), CRC=True, all_SHA256=True,
                                    deletion_performed=False))
print('GROUPED_FP8_SCALE_PUBLISHED', len(rows), archive_path.stat().st_size, flush=True)
