"""Offline compile exactly the two existing jobs with the frozen scale adapter."""
import dataclasses
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
OUT = S/'aot'
OUT.mkdir(exist_ok=True)
os.environ['TRITON_CACHE_DIR'] = str(OUT/'cache')
sys.path.insert(0, str(ROOT/'.scratch/tools/d5-triton/unpacked'))
import triton
import triton.language as tl
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource

assert triton.__version__ == '3.8.0'
vendor = ROOT/'third_party/sglang_activation/fp8/grouped'
origin = json.loads((vendor/'source.json').read_bytes())
original = (vendor/'original_kernels.py').read_bytes()
assert hashlib.sha256(original).hexdigest() == origin['module_sha256']
text = original.decode().replace('\r\n', '\n')
for name in ('runtime_top_k', 'scale_order'):
    adapter = origin[name]
    if 'input_module_sha256' in adapter:
        assert hashlib.sha256(text.encode()).hexdigest() == adapter['input_module_sha256']
    assert text.count(adapter['before']) == 1
    text = text.replace(adapter['before'], adapter['after'])
    assert hashlib.sha256(text.encode()).hexdigest() == adapter['module_sha256']
assert text.encode() == (S/'adapted-kernels.py').read_bytes()
adapted = OUT/'adapted_kernels.py'
adapted.write_text(text, encoding='utf-8', newline='\n')
spec = importlib.util.spec_from_file_location('grouped_adapted', adapted)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
record = json.loads((vendor/'compilation.json').read_bytes())
assert [job['label'] for job in record['kernels']] == ['grouped_fp32', 'grouped_bf16']

def metadata_json(value):
    if dataclasses.is_dataclass(value):
        return dataclasses.asdict(value)
    raise TypeError(type(value).__name__)

for job in record['kernels']:
    constants = dict(job['constexprs'])
    constants['compute_type'] = tl.float32 if constants['compute_type']=='fp32' else tl.bfloat16
    start = time.monotonic()
    compiled = triton.compile(ASTSource(fn=module.fused_moe_kernel,
        signature=job['signature'], constexprs=constants), target=GPUTarget('cuda', 89, 32),
        options=job['options'])
    blob = compiled.asm['cubin']
    job['seconds'] = round(time.monotonic()-start, 4)
    job['metadata'] = compiled.metadata._asdict()
    job['cubin_sha256'] = hashlib.sha256(blob).hexdigest()
    (OUT/(job['label']+'.cubin')).write_bytes(blob)
    for kind in ('ptx', 'llir', 'ttir', 'ttgir'):
        (OUT/(job['label']+'.'+kind)).write_text(compiled.asm[kind], encoding='utf-8')
    print(job['label'], len(blob), job['cubin_sha256'], flush=True)
(S/'new-compilation.json').write_text(json.dumps(record, indent=2, default=metadata_json)+'\n', encoding='utf-8')
print('TWO_GROUPED_SCALE_JOBS_COMPILED', flush=True)
