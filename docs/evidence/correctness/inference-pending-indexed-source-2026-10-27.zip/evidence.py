"""Offline packaging of the already completed finite check; no build or run."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-pending-indexed-source-2026-10-27'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def exact(path, expected):
    actual = pin(path)
    assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256']), path
    return actual


plan, ready, summary = (read(W / x) for x in ('plan.json', 'ready.json', 'summary.json'))
assert summary['status'] == 'PASS' and summary['process']['exit'] == 0
assert summary['process']['pid'] == 59368
assert len(plan['units']) == len(ready['compiled']) == 12
assert ready['link']['exit'] == 0 and all(x['process']['exit'] == 0 for x in ready['compiled'])
assert summary['image'] == ready['image']
exact(W / 'plan.json', ready['plan'])
exact(W / 'link-inputs.json', ready['inputs'])
cases = ET.parse(W / 'results.xml').getroot().findall('./testsuite/testcase')
assert len(cases) == len(plan['tests']) == 38
assert {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases} == set(plan['tests'])
assert all(x.attrib.get('status') == 'run' and not any(x.findall(tag)
    for tag in ('failure', 'error', 'skipped')) for x in cases)

baseline_path = Path(plan['baseline']['path'])
exact(baseline_path, plan['baseline'])
baseline, linked = read(baseline_path), read(W / 'link-inputs.json')
assert len(baseline) == 233 and len(linked) == 234
retained = [x for x in baseline if x in linked]
removed = [x for x in baseline if x not in linked]
compiled = [x['object'] for x in ready['compiled']]
assert len(retained) == 222 and len(removed) == 11
assert {x['path'] for x in removed} == {x['old']['path'] for x in plan['units'] if x['old']}
assert [x for x in linked if x not in baseline] == [
    next(y for y in compiled if y['path'] == x['path']) for x in linked if x not in baseline]
assert {x['path'] for x in linked if x not in baseline} == {x['path'] for x in compiled}

members = {}


def add(path, archive):
    path = Path(path)
    assert archive not in members
    assert path.suffix.lower() in {'.py', '.json', '.log', '.xml', '.cc', '.h', '.txt'}
    members[archive] = path.read_bytes()


sources = []
for original in plan['sources']:
    relative = Path(original['path']).relative_to(R)
    snapshot = W / 'source' / relative
    exact(snapshot, original)
    archive = 'source/' + relative.as_posix()
    add(snapshot, archive)
    sources.append({**original, 'archive': archive, 'origin': 'as-run frozen snapshot'})

# CMake registration is not a compiler input of the manually linked check.
registration_path = R / 'tests/graph_provider_ggml_cuda/CMakeLists.txt'
registration = pin(registration_path)
assert 'pending_indexed_state_test.cc' in registration_path.read_text(encoding='utf-8-sig')
registration['archive'] = 'registration/tests/graph_provider_ggml_cuda/CMakeLists.txt'
registration['origin'] = 'registration at publication; not an as-run compiler dependency'
add(registration_path, registration['archive'])
for name in ('check.py', 'plan.json', 'ready.json', 'compiled.json', 'link-inputs.json',
             'summary.json', 'results.xml'):
    add(W / name, 'records/' + name)
for unit in plan['units']:
    stage = W / 'compile' / unit['name']
    deps = read(stage / 'dependencies.json')
    assert Path(deps['Data']['Source']).resolve() == Path(unit['source']['path']).resolve()
    assert read(stage / 'process.json')['exit'] == 0
    for name in ('command.json', 'dependencies.json', 'process.json', 'stdout.log', 'stderr.log'):
        add(stage / name, 'records/compile/' + unit['name'] + '/' + name)
for stage in ('link', 'run'):
    assert read(W / stage / 'process.json')['exit'] == 0
    for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'):
        add(W / stage / name, 'records/' + stage + '/' + name)
runtime = Path(ready['runtime']['path'])
exact(runtime, ready['runtime'])
add(runtime, 'records/runtime.json')
add(baseline_path, 'baseline/link-inputs.json')
add(baseline_path.parent / 'check.py', 'baseline/check.py')
add(__file__, 'evidence.py')

manifest = [dict(archive=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
            for name, data in sorted(members.items())]
archive_path = OUT.with_suffix('.zip')
receipt_path = OUT.with_suffix('.json')
assert not archive_path.exists() and not receipt_path.exists()
archive_path.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members) | {'manifest.json'}
    for item in manifest:
        data = archive.read(item['archive'])
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    assert json.loads(archive.read('manifest.json')) == manifest
assert archive_path.stat().st_size < 2_000_000

receipt = {
    'date': '2026-10-27', 'status': 'PASS',
    'scope': 'Real CUDA original Store-ready to pending indexed GDN/conv relay, with one common submission terminal and a previously recorded exact native capture.',
    'environment': {
        'platform': 'Windows', 'gpu': 'NVIDIA GeForce RTX 4070',
        'compute_capability': '8.9', 'VRAM_MiB_reported': 12281,
        'basis': 'Original run/stderr.log; no new hardware query, exclusive-device or fixed-frequency claim.',
        'compiler': plan['units'][0]['command'][0], 'runtime': ready['runtime'],
    },
    'build': {
        'CXX_TUs': 12, 'product_TUs': 6, 'test_TUs': 6,
        'compile_attempts': 12, 'compile_failures': 0,
        'link_attempts': 1, 'successful_links': 1, 'test_processes': 1,
        'NVCC_TUs': 0, 'SDK_rebuilds': 0, 'downloads': 0,
        'baseline_inputs': 233, 'replaced_inputs': 11, 'retained_inputs': 222,
        'additional_inputs': 1, 'final_inputs': 234,
        'baseline_closure': plan['baseline'],
        'baseline_receipt': 'inference-inherited-page-source-2026-10-27.json',
        'compiled': ready['compiled'], 'link': ready['link'], 'closure': ready['inputs'],
        'reuse_boundary': 'Actual Data.Source mapping refreshed every selected original OutputBinding/SourceBinding ABI user (11 old objects), plus the new pending-indexed test TU. Other 222 exact input records retain the preceding successful closure, including native GDN/conv kernels; no SDK, native kernel, Model, weights or report compilation occurred.',
        'native_receipts': ['inference-indexed-gdn-native-2026-10-27.json',
                            'inference-indexed-conv-graph-2026-10-27.json'],
        'registration': registration,
    },
    'execution': {
        'process': summary['process'], 'image': summary['image'],
        'passed': 38, 'failed': 0, 'skipped': 0,
        'new_tests': [x for x in plan['tests'] if x.startswith('GgmlCudaPendingIndexedState.')],
        'adjacent_regressions': 35,
        'suite_counts': dict(Counter(x.attrib['classname'] for x in cases)),
        'local_test_timestamps': {'first': min(x.attrib['timestamp'] for x in cases),
                                  'last': max(x.attrib['timestamp'] for x in cases)},
        'all_tests': plan['tests'], 'command': 'records/run/command.json',
        'xml': 'records/results.xml', 'failures_in_this_window': [],
        'duration_is_not_a_benchmark': True,
    },
    'checks': [
        'Original A actually submits a checked Gather plus Store, retires, detaches, returns its original writers and publishes true bounded ready guards. A warm B imported transaction owns zero source leases and the real independent destinations.',
        'Warm B binds complete Store-ready guards authenticated against original ticket root, generation, slot coordinates and precise range. The original F32 indexed GDN route6/implementation7 or conv route7/implementation8 is one selected region with native dispatch_count=1.',
        'B genuinely records and executes the first ready capture. After real retirement, imported take returns only destination writers; release_outputs withdraws the exact source bundle while retaining only the dormant physical capture tuple. No whole-Invocation reset or arbitrary ready projection is used.',
        'A next generation of submission rewrites the same physical source slots and original private ID carrier. B rebinds the empty-ready pending Source and independent original destinations, then reuses the existing capture with recorded_capture_range_count=0 and reused_capture_range_count=1.',
        'The same-ID path retains the actual successful metadata carrier and skips mutation/upload/wait only when complete fixed geometry and values match. Both real host gates complete without timing out; changed IDs retain the original native upload/guard checks. This is a finite contract check, not a measured latency claim.',
        'The actual B dependency reports source_count=1, device_wait_count=1 and host_wait_count=0; ordinary submit is rejected. A truly retires and publishes its original destination while B remains gate-pending, and publication does not reopen writes.',
        'GDN B2/T4/K1/H2/S16 and conv B2/T1/K1/L3/C128 use noncontiguous source slots [1,5], destination slots [3,7], real capacity P8 and padded strides. Original dense public operations provide the mathematical reference; output/state match bitwise and whole-bank sentinel, old snapshots and padding remain exact.',
        'A real checked-Gather out-of-range failure remains the complete predecessor verdict: Store publication returns the same error, B receives that error and exposes no activation. After actual B retirement and Completion release, imported destinations can be taken and the failed source bundle can be released without publishing failed state.',
    ],
    'interface_negatives': [
        'A complete same-count/same-length ready array with one genuine untouched but wrong-root/slot guard is InvalidArgument; the authentic complete array then binds and executes normally.',
        'Retired warm B cannot release its source bundle before taking the nominated writers; the subsequent real take and release succeed, proving refusal did not partially withdraw it.',
        'B pending behind its actual gate cannot release the source bundle; its later success or full failure verdict and cleanup remain intact.',
        'The checked-failure case returns the real imported writers and successfully releases only after actual retirement; it never publishes failed B state.',
    ],
    'sources': sources,
    'limits': [
        'New pending indexed cases cover F32 and the complete destination count K1 only. Existing adjacent BF16/F16 or multi-prefix tests do not prove pending MTP noncontiguous accepted subsets.',
        'No complete model continuous state rotation, engine pipeline integration, CPU-ahead interaction, TPS/speedup, memory benchmark, multi-platform or new driver/native fault-injection claim.',
        'Cold Source/bundle/transaction metadata still allocates. No zero-allocation binding or metadata-preparation cost claim is made.',
        'The source is the original shared Queue submission and complete mathematical verdict. Passing raw capacity/ID carriers alone never establishes source read authority.',
        'This offline archive contains frozen source and exact commands/dependency paths plus records, not a standalone SDK. The runner refers to the preserved baseline cache helper; all direct commands are archived independently.',
    ],
    'archive': {**pin(archive_path), 'path': archive_path.relative_to(R).as_posix(),
        'member_count': len(manifest) + 1, 'payload_bytes': sum(x['bytes'] for x in manifest),
        'verification': 'Every member was decompressed and its length/SHA-256 checked against manifest.json. No EXE/OBJ/PDB/LIB/DLL/SDK/model payload.'},
}
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = {'receipt': pin(receipt_path), 'archive': pin(archive_path),
          'members_verified': len(manifest) + 1, 'tests_passed': len(cases)}
(W / 'publish-result.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
