from pathlib import Path
import importlib.util
import re
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-inherited-pages-20261027'
spec = importlib.util.spec_from_file_location('inherited_recipe', BASE / 'check.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b, h = q.b, q.h
ADDED = 'tests/graph_provider_ggml_cuda/pending_indexed_state_test.cc'
EXPLICIT = ['src/graph/resources.cc', 'src/graph/input_sources.cc',
    'src/graph/slots_region.cc', 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc']
HEADERS = ['include/hyle/graph/detail/output_source.h',
    'include/hyle/graph/detail/region_access.h', 'include/hyle/graph/detail/store_source.h',
    'include/hyle/graph/slots.h', 'src/graph/slots_region.h', 'src/graph/input_sources.h']
GROUPS = ['GraphSlotsExecution', 'GgmlCudaIndexedStateGraph',
    'GgmlCudaIndexedConvGraph', 'GgmlCudaPendingIndexedState']


def source_of(row):
    metadata = Path(row['path']).parent / 'dependencies.json'
    return b.read(metadata).get('Data', {}).get('Source') if metadata.is_file() else None


def environment(command):
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': command[0], 'CMAKE_CXX_COMPILER': command[0],
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = b.read(Path(b.read(BASE / 'ready.json')['runtime']['path']))['PATH']
    return env


def freeze():
    assert not (W / 'plan.json').exists()
    inputs = b.read(BASE / 'link-inputs.json')
    selected = {}
    for row in inputs:
        path = source_of(row)
        if not path:
            continue
        path = Path(path)
        if not path.is_relative_to(R) or not path.is_file():
            continue
        relative = path.relative_to(R).as_posix()
        text = path.read_text(encoding='utf-8-sig')
        if relative in EXPLICIT or re.search(r'\b(?:OutputBinding|SourceBinding)\b', text):
            assert relative not in selected, relative
            selected[relative] = row
    assert set(EXPLICIT) <= set(selected)
    template = selected['tests/graph_provider_ggml_cuda/indexed_conv_test.cc']
    selected[ADDED] = template
    units = []
    for index, (source, old) in enumerate(selected.items()):
        name = f'{index:02d}-' + Path(source).stem
        out = W / 'compile' / name
        argv = b.read(Path(old['path']).parent / 'command.json')['command']
        command = []
        for i, arg in enumerate(argv):
            if i and argv[i-1].lower() == '/sourcedependencies':
                arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith('.cc'):
                arg = str(R / source)
            command.append(arg)
        units.append({'name': name, 'source': b.pin(R / source),
            'old': old if source != ADDED else None, 'command': command})
    sources = [b.pin(R / x) for x in [*selected, *HEADERS]]
    for row in sources:
        dest = W / 'source' / Path(row['path']).relative_to(R)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(Path(row['path']).read_bytes())
    tests = list(b.read(BASE / 'plan.json')['tests'])
    for source in selected:
        if not source.startswith('tests/'):
            continue
        for group, case in re.findall(r'TEST\((\w+),\s*(\w+)\)',
                (R / source).read_text(encoding='utf-8-sig')):
            if group in GROUPS:
                tests.append(group + '.' + case)
    tests = list(dict.fromkeys(tests))
    assert any(x.startswith('GgmlCudaPendingIndexedState.') for x in tests)
    b.save(W / 'plan.json', {'units': units, 'sources': sources, 'tests': tests,
        'baseline': b.pin(BASE / 'link-inputs.json'), 'input_count': len(inputs),
        'scope': 'Original Store-ready/pending Source and native indexed GDN/conv, bounded finite CPU/CUDA regression; no model throughput or full continuous engine claim.'})
    print('FROZEN', len(units), 'CXX,', len(tests), 'tests', flush=True)


def check(plan):
    for row in plan['sources']:
        b.exact(row)


def build():
    plan = b.read(W / 'plan.json')
    check(plan)
    env = environment(plan['units'][0]['command'])
    inputs = b.read(BASE / 'link-inputs.json')
    for row in inputs:
        b.exact(row)
    compiled, replacements, additional = [], {}, []
    for unit in plan['units']:
        out = W / 'compile' / unit['name']
        assert not out.exists()
        process = h.execute(unit['command'], env, out, timeout=180)
        check(plan)
        obj = b.pin(out / 'unit.obj')
        assert b.key(source_of(obj)) == b.key(unit['source']['path'])
        if unit['old']:
            replacements[b.key(unit['old']['path'])] = obj
        else:
            additional.append(obj)
        compiled.append({'name': unit['name'], 'object': obj, 'process': process})
        b.save(W / 'compiled.json', compiled)
    linked = [replacements.get(b.key(x['path']), x) for x in inputs] + additional
    b.save(W / 'link-inputs.json', linked)
    image = W / 'bin/pending-indexed-test.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    command = []
    for arg in b.read(BASE / 'link/command.json')['command']:
        if b.key(arg) in replacements:
            arg = replacements[b.key(arg)]['path']
        elif arg.lower().startswith('/out:'):
            arg = '/OUT:' + str(image)
        elif arg.lower().startswith('/pdb:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.lower().startswith('/implib:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    command += [x['path'] for x in additional]
    link = h.execute(command, env, W / 'link', timeout=120)
    b.save(W / 'ready.json', {'image': b.pin(image), 'compiled': compiled, 'link': link,
        'inputs': b.pin(W / 'link-inputs.json'), 'plan': b.pin(W / 'plan.json'),
        'runtime': b.read(BASE / 'ready.json')['runtime']})
    print('READY', flush=True)


def run():
    plan, ready = b.read(W / 'plan.json'), b.read(W / 'ready.json')
    check(plan)
    b.exact(ready['image'])
    xml = W / 'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter=' + ':'.join(plan['tests']), '--gtest_output=xml:' + str(xml)],
        environment(plan['units'][0]['command']), W / 'run', timeout=90)
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    actual = {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases}
    ok = actual == set(plan['tests']) and all(x.attrib.get('status') == 'run' and
        not x.findall('failure') and not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(W / 'summary.json', {'status': 'PASS' if ok else 'FAIL', 'process': process,
        'tests': [x.attrib for x in cases], 'image': ready['image'], 'sources': plan['sources']})
    assert ok
    print('PASS', len(cases), flush=True)


if __name__ == '__main__':
    try:
        {'freeze': freeze, 'build': build, 'run': run}[sys.argv[1]]()
    except Exception:
        b.save(W / (sys.argv[1] + '-failure.json'), {'error': traceback.format_exc()})
        raise
