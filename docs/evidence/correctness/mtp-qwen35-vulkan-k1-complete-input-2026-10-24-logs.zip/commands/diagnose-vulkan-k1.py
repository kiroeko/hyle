from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';A=O/'build1'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
recipe=b.read(R/'.scratch/gdn-vulkan-output-scale-20261024/compile1/compute_provider_ggml_vulkan--native_graph/identity.json')
out=A/'diagnostic-native-graph';out.mkdir(exist_ok=True);source=out/'native_graph.cc'
text=(R/'src/compute_provider_ggml_vulkan/native_graph.cc').read_text();needle='''    HYLE_RETURN_IF_ERROR(state.device.allocate_graph(
        graph, state.imports != nullptr, &state.storage, &state.bytes));'''
replacement='''    const auto allocated = state.device.allocate_graph(graph, state.imports != nullptr, &state.storage, &state.bytes);
    if (!allocated.ok()) {
      auto backend = state.device.create_backend();
      if (backend) {
        unsigned shown=0;
        for (int i=0; i<ggml_graph_n_nodes(graph) && shown<8; ++i) {
          const auto* n=ggml_graph_node(graph,i);
          if (ggml_backend_supports_op(*backend,n)) continue;
          ++shown;
          std::fprintf(stderr,"native_unsupported index=%d op=%s type=%s ne=%lld,%lld,%lld,%lld nb=%zu,%zu,%zu,%zu\\n",i,ggml_op_name(n->op),ggml_type_name(n->type),(long long)n->ne[0],(long long)n->ne[1],(long long)n->ne[2],(long long)n->ne[3],n->nb[0],n->nb[1],n->nb[2],n->nb[3]);
          for(unsigned j=0;j<GGML_MAX_SRC;++j)if(n->src[j]) {const auto*s=n->src[j];std::fprintf(stderr," source%u type=%s ne=%lld,%lld,%lld,%lld nb=%zu,%zu,%zu,%zu\\n",j,ggml_type_name(s->type),(long long)s->ne[0],(long long)s->ne[1],(long long)s->ne[2],(long long)s->ne[3],s->nb[0],s->nb[1],s->nb[2],s->nb[3]);}
        }
        ggml_backend_free(*backend);
      }
      return std::unexpected(allocated);
    }'''
assert text.count(needle)==1;source.write_text('#include <cstdio>\n#include "ggml-backend.h"\n'+text.replace(needle,replacement))
cc=recipe['command'][0];env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[];skip=False
for x in recipe['command']:
 if skip:skip=False;continue
 if x.lower()=='/sourcedependencies':skip=True;continue
 if x.lower().startswith(('/fo','/fd'))or x.lower().endswith('.cc'):continue
 cmd.append(x)
cmd.insert(1,'/I'+str(R/'src/compute_provider_ggml_vulkan'));cmd+=[str(source),'/Fo'+str(out/'diagnostic.obj'),'/Fd'+str(out/'diagnostic.pdb')]
b.execute(cmd,env,A/'diagnostic-compile2',180)
link=b.read(A/'link2-plan.json');image=b.read(A/'ready.json')['image'];b.save(A/'diagnostic-original-image.json',image)
cmd=[x for x in link['command']if not x.upper().startswith('/MAP:')];cmd.insert(1,str(out/'diagnostic.obj'));cmd+=['/MAP:'+str(A/'diagnostic-link/hyle.map')]
b.save(A/'diagnostic-link-plan.json',dict(command=cmd,source=b.identity(source),object=b.identity(out/'diagnostic.obj'),not_final_proof=True))
b.execute(cmd,env,A/'diagnostic-link',120)
print('DIAGNOSTIC_READY',flush=True)
