from pathlib import Path
import importlib.util,json,os,subprocess,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';A=O/'build1'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(A/'ready.json');b.require(ready['image'])
env=dict(os.environ,PATH=b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/native-runtime-readiness/vulkan-real/ready.json')['PATH'])
hardware=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'],capture_output=True,text=True,timeout=15)
b.save(O/'hardware.json',dict(command=hardware.args,exit=hardware.returncode,stdout=hardware.stdout,stderr=hardware.stderr))
inputs=R/'.scratch/qwen-mtp-window-20261022/inputs/mtp'
b.save(O/'inputs.json',dict(files=[b.identity(inputs/x)for x in ('weights.tsv','prompt.ids')],weight_copies=0,HTTP=0))
results=[]
for mtp in ('off','on'):
 for policy in ('greedy','random'):
  tag='mtp-'+mtp+'-'+policy;folder=O/'runs-current'/tag
  command=[ready['image']['path'],'--inputs',str(inputs),'--mtp',mtp,'--steps','4','--capacity','256','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--sampling',policy]
  if policy=='random':command+=['--temperature','0.8','--top-k','40','--top-p','0.95','--seed','42']
  process=b.execute(command,env,folder,240)
  reports=[]
  for line in (folder/'stdout.log').read_text().splitlines():
   try:report=json.loads(line)
   except json.JSONDecodeError:continue
   if 'generated_ids'in report:reports.append(report)
  assert len(reports)==1 and len(reports[0]['generated_ids'])==4
  results.append(dict(case=tag,process=process,report=reports[0],image=ready['image']))
  b.save(O/'functional-results.json',dict(runs=results,scope='Frozen K1 original BF16 complete Vulkan P154+4/C256/N1/R1 only',performance_claim=False,all_functionality_claim=False))
  print(tag,reports[0]['generated_ids'],flush=True)
print('COMPLETE',flush=True)
