from pathlib import Path
import hashlib,importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';A=O/'build1';A.mkdir(exist_ok=True)
assert not list(A.iterdir()), 'only an empty initial attempt may be reused'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,identity=b.read,b.save,b.identity
audit=read(O/'audit.json');gdn=read(R/'.scratch/gdn-vulkan-output-scale-20261024/plan.json')
base=read(R/'.scratch/qwen35-unsloth-mtp-20261024/native-runtime-readiness/vulkan-real/link-plan.json')['command']
route=read(R/'.scratch/gdn-vulkan-output-scale-20261024/compile1/route--vulkan_batch/identity.json')
cc=route['command'][0];env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
records={}
for row in gdn['current_public_records']:
 d=read(row['path']);records[Path(d['source']['path']).relative_to(R).as_posix()]=d
for row in audit['graph_records']:
 d=read(row['record']['path']);records[Path(d['source']['path']).relative_to(R).as_posix()]=d
for rel,p in {
 'src/compute/resource_budget.cc':'.scratch/engine-product-20261024/cpu-budget-fix1/budget/identity.json',
 'src/compute/resource_leases.cc':'.scratch/engine-product-20261024/cpu-budget-fix1/leases/identity.json',
 'src/compute_batch/batch_layout.cc':'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2/layout/identity.json',
 'src/compute_ops/low_precision.cc':'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2/low-precision/identity.json',
 'src/compute_batch/batch_paged_native.cc':'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2/native-paged/identity.json',
}.items():
 d=read(R/p);assert d['source']['sha256']==identity(R/rel)['sha256'],rel;records[rel]=d
def command(old,source,out,extra=()):
 args=[];skip=False
 for x in old[1:]:
  if skip:skip=False;continue
  if x.lower()=='/sourcedependencies':skip=True;continue
  if x.lower().startswith(('/fo','/fd')) or x.lower().endswith(('.cc','.mm','.cpp')):continue
  args.append(x)
 return [cc,'/I'+str(R/'include'),'/I'+str(R/'src/compute'),'/I'+str(R/'src/graph'),*args,*extra,
   '/sourceDependencies',str(out/'dependencies.json'),str(source),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
compiled=[]
def compile(rel,old,extra=()):
 source=R/rel;out=A/rel.replace('/','--').replace('.','-');before=identity(source);cmd=command(old,source,out,extra)
 b.execute(cmd,env,out,180);assert identity(source)==before
 dep=read(out/'dependencies.json')['Data'];data=dict(source=before,object=identity(out/'unit.obj'),command=cmd,
   dependencies=[identity(p)for p in dict.fromkeys([dep['Source'],*dep['Includes']])]);save(out/'identity.json',data);compiled.append(data);return data
# Only actual CacheStorage construction/comparison/paged consumers get a
# fresh header build; shared neutral source-matching core objects are reused.
for rel in ['src/compute_batch/paged_arena.cc','src/compute_batch/batch_materialize.cc','src/compute_batch/batch_execution.cc',
 'src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc','src/graph_batch/paged_append.cc']:
 records[rel]=compile(rel,records[rel]['command'])
graph_recipe=read(R/'.scratch/architecture-refactor-2026-10-18/quark-fp8-side-2026-10-21/windows/checks/attempt1/vulkan-native-region/identity.json')['command']
for source in sorted((R/'src/graph_route_vulkan').glob('*.cc')):
 rel=source.relative_to(R).as_posix();records[rel]=compile(rel,graph_recipe,('/DHYLE_COMPUTE_VULKAN=1','/DHYLE_GRAPH_ROUTE_VULKAN_BUILD'))
for rel in ('src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_tensor.cc'):
 old=read(R/('.scratch/gdn-vulkan-output-scale-20261024/compile1/route--'+Path(rel).stem+'/identity.json'))
 records[rel]=compile(rel,old['command'])
loader=compile('src/compute_stream_vulkan/file_stream.cc',route['command'],('/DHYLE_COMPUTE_STREAM_VULKAN_BUILD',))
frozen=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/frozen-k1-source';model=A/'model';model.mkdir()
for p in frozen.rglob('*'):
 if p.is_file():
  dst=model/p.relative_to(frozen);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
shutil.copyfile(R/'.scratch/qwen-apple-k1-20261024/main.apple.cc',model/'main.cc')
shutil.copyfile(R/'.scratch/qwen-apple-k1-20261024/mtp_graph.apple.h',model/'mtp_graph.h')
out=A/'model-compile';cmd=command(route['command'],model/'main.cc',out,('/DHYLE_COMPUTE_VULKAN=1','/I'+str(model/'public')))
# Public frozen Dense descriptor is first and is the same current public ID.
cmd.insert(1,'/I'+str(model/'public'))
b.execute(cmd,env,out,180);model_identity=dict(source=identity(model/'main.cc'),object=identity(out/'unit.obj'),command=cmd);save(out/'identity.json',model_identity)
entry=read(R/'.scratch/engine-product-20261024/cpu-build1/entry/identity.json');b.require(entry['object'])
cmd=[x for x in base if not x.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:')) and 'gtest'not in x.lower() and not x.lower().endswith('test.obj')]
objects=[d['object']['path']for rel,d in records.items()if Path(d['source']['path']).parent.name in ('graph','graph_batch','graph_route_vulkan','graph_progress','compute_state')or rel in audit['changed_sources']]
# Select changed public records explicitly; paths in the audit use native separators.
for rel in ['src/compute/resource_budget.cc','src/compute/resource_leases.cc','src/compute_ops/low_precision.cc','src/compute_batch/batch_layout.cc','src/compute_batch/batch_paged_native.cc','src/compute_batch/paged_arena.cc','src/compute_batch/batch_materialize.cc','src/compute_batch/batch_execution.cc','src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_tensor.cc']:
 objects.append(records[rel]['object']['path'])
objects=[*dict.fromkeys(objects)]
io=read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/link-cuda-dense.json')['command']
support=[x for x in io if Path(x).name.startswith(('io-','io--')) or Path(x).name=='hyle_io_core.lib']
assert len(support)>=2
cmd[1:1]=[entry['object']['path'],model_identity['object']['path'],loader['object']['path'],*objects,*support]
image=A/'link/hyle-vulkan.exe';cmd+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map'))]
save(A/'link-plan.json',dict(command=cmd,changed_records=[dict(source=x['source'],object=x['object'])for x in compiled],model=model_identity,SDK_builds=0,native_builds=0,HTTP=0,private_graph_diagnostics=False))
b.execute(cmd,env,A/'link',120)
save(A/'ready.json',dict(image=identity(image),command=cmd,product_TUs=len(compiled),model_TUs=1,SDK_builds=0,native_builds=0,HTTP=0))
print('READY',image,flush=True)
