from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';A=O/'build1'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=b.read(A/'link-plan.json');cc=b.read(A/'src--compute_stream_vulkan--file_stream-cc/identity.json')['command'][0]
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
fresh=[]
for stem in ('file_stream','stream_sources'):
 record=b.read(R/('.scratch/architecture-refactor-2026-10-18/qwen-pinned-weight-load/checks/stream-'+stem+'-identity.json'))
 source=R/('src/compute_stream/'+stem+'.cc');out=A/('stream-core-'+stem);cmd=[];skip=False
 for x in record['command']:
  if skip:skip=False;continue
  if x.lower()=='/sourcedependencies':skip=True;continue
  if x.lower().startswith(('/fo','/fd'))or x.lower().endswith('.cc')or any(z in x for z in ('/DGGML_USE_CUDA','/DHYLE_COMPUTE_CUDA','/DHYLE_COMPUTE_GGML_CUDA')):continue
  cmd.append(x)
 cmd+=['/sourceDependencies',str(out/'dependencies.json'),str(source),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
 before=b.identity(source);b.execute(cmd,env,out,180);assert b.identity(source)==before
 data=dict(source=before,object=b.identity(out/'unit.obj'),command=cmd);b.save(out/'identity.json',data);fresh.append(data)
command=[x for x in old['command']if not x.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
command[1:1]=[d['object']['path']for d in fresh]
image=A/'link2/hyle-vulkan.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map'))]
old.update(command=command,stream_core_records=fresh);b.save(A/'link2-plan.json',old)
b.execute(command,env,A/'link2',120)
b.save(A/'ready.json',dict(image=b.identity(image),command=command,product_TUs=len(old['changed_records'])+len(fresh),model_TUs=1,SDK_builds=0,native_builds=0,HTTP=0,private_graph_diagnostics=False))
print('READY',image,flush=True)
