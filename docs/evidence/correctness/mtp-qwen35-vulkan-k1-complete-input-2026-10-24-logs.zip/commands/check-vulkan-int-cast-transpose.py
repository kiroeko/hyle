from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';A=O/'build1';F=A/'int-cast'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=b.read(F/'test/identity.json');out=F/'test-transpose';cmd=[];skip=False
for x in old['command']:
 if skip:skip=False;continue
 if x.lower()=='/sourcedependencies':skip=True;continue
 if x.lower().startswith(('/fo','/fd'))or x.lower().endswith('.cc'):continue
 cmd.append(x)
source=R/'tests/compute_route_vulkan/tensor_test.cc';cmd+=['/sourceDependencies',str(out/'dependencies.json'),str(source),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
cc=cmd[0];env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
env['PATH']=b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/native-runtime-readiness/vulkan-real/ready.json')['PATH']
before=b.identity(source);b.execute(cmd,env,out,120);assert b.identity(source)==before
deps=b.read(out/'dependencies.json')['Data'];record=dict(source=before,object=b.identity(out/'unit.obj'),command=cmd,dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])]);b.save(out/'identity.json',record)
test=b.read(F/'test-link-plan.json');cmd=[record['object']['path']if x==old['object']['path']else x for x in test['command']if not x.upper().startswith('/MAP:')];cmd+=['/MAP:'+str(F/'test-transpose-link/hyle.map')];b.save(F/'test-transpose-link-plan.json',dict(command=cmd,source_record=record))
b.execute(cmd,env,F/'test-transpose-link',120)
image=next(x[5:]for x in cmd if x.upper().startswith('/OUT:'))
try:
 b.execute([image,'--gtest_filter=VulkanTensor.Int32ToFloat32RoundsBoundaryAndStridedValues:VulkanTensor.CategoricalChoiceInt32Float32BoolAcceptanceChain:VulkanTensor.UnaryBinaryAndCastUseIndependentFloatingOracles'],env,F/'focused-transpose-run',90)
finally:
 cmd=[x for x in b.read(F/'model-link-plan.json')['command']if not x.upper().startswith('/MAP:')];cmd+=['/MAP:'+str(F/'model-restore-link/hyle.map')];b.execute(cmd,env,F/'model-restore-link',120)
ready=b.read(A/'ready.json');ready.update(image=b.identity(image),command=cmd);b.save(A/'ready.json',ready)
print('FOCUSED_TRANSPOSE_PASSED; MODEL_RESTORED',flush=True)
