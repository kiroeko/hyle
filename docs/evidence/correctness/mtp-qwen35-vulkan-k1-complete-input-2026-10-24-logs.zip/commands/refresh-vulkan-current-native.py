from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';A=O/'build1'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
manifest=R/'third_party/ggml_vulkan_runtime/patches.json';mp=b.read(manifest)
patch=next(x for x in mp['files']if x['path']=='src/ggml-vulkan/ggml-vulkan.cpp')
source=R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-proposal/native-after/src/ggml-vulkan/ggml-vulkan.cpp'
actual=b.identity(source);assert actual['sha256']==patch['after_sha256']
generated=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan/generated'
blob=b.read(R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan/checks/attempt1/page-blob-identity.json')
b.require(blob['source']);b.require(blob['object'])
old=b.read(R/'.scratch/gdn-vulkan-output-scale-20261024/compile1/native/identity.json');cc=old['command'][0]
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[];skip=False
for x in old['command']:
 if skip:skip=False;continue
 if x.lower()=='/sourcedependencies':skip=True;continue
 if x.lower().startswith(('/fo','/fd'))or x.lower().endswith(('.cpp','.cc')):continue
 cmd.append(x)
out=A/'current-native';cmd.insert(1,'/I'+str(generated));cmd+=['/sourceDependencies',str(out/'dependencies.json'),str(source),'/Fo'+str(out/'native.obj'),'/Fd'+str(out/'native.pdb')]
b.execute(cmd,env,out,300);assert b.identity(source)==actual
deps=b.read(out/'dependencies.json')['Data'];data=dict(source=actual,manifest=b.identity(manifest),object=b.identity(out/'native.obj'),command=cmd,dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])],SDK_builds=0,native_TUs=1,shader_builds=0)
b.save(out/'identity.json',data)
link=b.read(A/'link2-plan.json');cmd=[data['object']['path']if x==old['object']['path']else x for x in link['command']if not x.upper().startswith('/MAP:')];assert data['object']['path']in cmd
cmd.insert(1,blob['object']['path']);cmd+=['/MAP:'+str(A/'current-native-link/hyle.map')]
assert not any('diagnostic'in x for x in cmd)
link.update(command=cmd,native=data,original_cached_native=old['object'],reused_e4_blob=dict(source=blob['source'],object=blob['object']),private_graph_diagnostics=False)
b.save(A/'current-native-link-plan.json',link);b.execute(cmd,env,A/'current-native-link',120)
image=next(x[5:]for x in cmd if x.upper().startswith('/OUT:'))
b.save(A/'ready.json',dict(image=b.identity(image),command=cmd,product_TUs=len(link['changed_records'])+len(link['stream_core_records']),model_TUs=1,native_TUs=1,SDK_builds=0,shader_builds=0,HTTP=0,private_graph_diagnostics=False))
print('READY_CURRENT_NATIVE',flush=True)
