from pathlib import Path
import importlib.util,json,os,re,struct,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';A=O/'build1';F=A/'int-cast';F.mkdir()
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
route=b.read(A/'src--compute_route_vulkan--vulkan_tensor-cc/identity.json');cc=route['command'][0]
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
runtime=b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/native-runtime-readiness/vulkan-real/ready.json');env['PATH']=runtime['PATH']
shader_source=R/'src/compute_route_vulkan/shaders/tensor.comp';shader_hash=b.identity(shader_source)
compiler=R/'../..'/'tools/glslang/glslangValidator.exe';compiler=Path('C:/public/tools/glslang/glslangValidator.exe')
spv=F/'tensor.spv';command=[str(compiler),'-V','--target-env','vulkan1.2','--preamble-text','#extension GL_GOOGLE_include_directive : require\n','-I'+str(shader_source.parent),'-S','comp','-o',str(spv),str(shader_source)]
b.execute(command,env,F/'shader-build',60);assert b.identity(shader_source)==shader_hash
raw=spv.read_bytes();assert len(raw)%4==0;words=struct.unpack('<'+'I'*(len(raw)//4),raw);assert words[0]==0x07230203 and words[1]<=0x00010500
at=5
while at<len(words):
 n,op=words[at]>>16,words[at]&65535;assert n and at+n<=len(words)
 if op==17:assert n==2 and words[at+1]==1
 at+=n
generated=b.read(R/'.scratch/architecture-refactor-2026-10-18/quark-fp8-side-2026-10-21/windows/checks/attempt2/vulkan-shaders/identity.json');b.require(generated['source']);b.require(generated['object'])
text=Path(generated['source']['path']).read_text();start='namespace { constexpr std::uint32_t tensor_words[] = {';end='std::span<const std::uint32_t> tensor() noexcept { return tensor_words; }'
assert text.count(start)==1 and text.count(end)==1
head,tail=text.split(start);_,tail=tail.split(end,1);array='\n'.join('  '+', '.join(f'0x{x:08x}u'for x in words[i:i+8])+','for i in range(0,len(words),8))
new=F/'vulkan_shaders.cc';new.write_text(head+start+'\n'+array+'\n}; }\n'+end+tail)
def compile(name,source,recipe,includes=()):
 out=F/name;cmd=[];skip=False
 for x in recipe['command']:
  if skip:skip=False;continue
  if x.lower()=='/sourcedependencies':skip=True;continue
  if x.lower().startswith(('/fo','/fd'))or x.lower().endswith(('.cc','.cpp')):continue
  cmd.append(x)
 cmd[1:1]=['/I'+str(p)for p in includes];cmd+=['/sourceDependencies',str(out/'dependencies.json'),str(source),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
 before=b.identity(source);b.execute(cmd,env,out,180);assert b.identity(source)==before
 deps=b.read(out/'dependencies.json')['Data'];rec=dict(source=before,object=b.identity(out/'unit.obj'),command=cmd,dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])]);b.save(out/'identity.json',rec);return rec
shaders=compile('embedded',new,generated,(Path(generated['source']['path']).parent,))
tensor=compile('tensor',R/'src/compute_route_vulkan/vulkan_tensor.cc',route)
test=compile('test',R/'tests/compute_route_vulkan/tensor_test.cc',route,(R/'tests/compute_route_vulkan',))
link=b.read(A/'current-native-link-plan.json');cmd=[x for x in link['command']if not x.upper().startswith('/MAP:')]
cmd=[tensor['object']['path']if x==route['object']['path']else x for x in cmd];assert tensor['object']['path']in cmd
cmd.insert(1,shaders['object']['path']);cmd+=['/MAP:'+str(F/'model-link/hyle.map')]
model_image=next(x[5:]for x in cmd if x.upper().startswith('/OUT:'));original=b.read(A/'ready.json')['image'];b.save(F/'original-image.json',original)
testcmd=[x for x in cmd if x not in (b.read(R/'.scratch/engine-product-20261024/cpu-build1/entry/identity.json')['object']['path'],link['model']['object']['path'])and not x.upper().startswith(('/OUT:','/MAP:'))]
testcmd.insert(1,test['object']['path']);testcmd += [x for x in b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/native-runtime-readiness/vulkan-real/link-plan.json')['command']if 'gtest' in x.lower()]
testcmd+=['/OUT:'+model_image,'/MAP:'+str(F/'test-link/hyle.map')]
b.save(F/'test-link-plan.json',dict(command=testcmd,source_records=[shaders,tensor,test],shader_source=shader_hash,shader=b.identity(spv),compiler=b.identity(compiler),SDK_builds=0))
b.execute(testcmd,env,F/'test-link',120)
try:
 result=b.execute([model_image,'--gtest_filter=VulkanTensor.Int32ToFloat32RoundsBoundaryAndStridedValues:VulkanTensor.CategoricalChoiceInt32Float32BoolAcceptanceChain:VulkanTensor.UnaryBinaryAndCastUseIndependentFloatingOracles'],env,F/'focused-run',90)
finally:
 b.save(F/'model-link-plan.json',dict(command=cmd,source_records=[shaders,tensor],shader_source=shader_hash,shader=b.identity(spv),private_graph_diagnostics=False));b.execute(cmd,env,F/'model-link',120)
ready=b.read(A/'ready.json');ready.update(image=b.identity(model_image),command=cmd,int_cast_records=[shaders,tensor],shader_source=shader_hash,shader=b.identity(spv),private_graph_diagnostics=False);b.save(A/'ready.json',ready)
process=b.execute(b.read(O/'runs-current/mtp-on-random/command.json')['command'],env,O/'runs-current/mtp-on-random-int-cast-fixed',240)
reports=[json.loads(line)for line in (O/'runs-current/mtp-on-random-int-cast-fixed/stdout.log').read_text().splitlines()if line.startswith('{')]
report=next(x for x in reports if 'generated_ids'in x);assert len(report['generated_ids'])==4
results=b.read(O/'functional-results.json');results['runs'].append(dict(case='mtp-on-random-int-cast-fixed',process=process,report=report,image=ready['image']));b.save(O/'functional-results.json',results)
print('FOURTH_COMPLETE',report['generated_ids'],flush=True)
