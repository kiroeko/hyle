from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen-vulkan-k1-20261024';O.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def ident(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
base=read(R/'.scratch/qwen35-unsloth-mtp-20261024/native-runtime-readiness/vulkan-real/link-plan.json')
gdn=read(R/'.scratch/gdn-vulkan-output-scale-20261024/plan.json')
host=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation'
records=[]
for p in (host/'host1/records').glob('*/identity.json'):
 d=read(p)
 if Path(d['source']['path']).parent.name in ('graph','graph_batch'):records.append((p,d))
for p in (host/'support1/records').glob('*/identity.json'):
 d=read(p)
 if Path(d['source']['path']).parent.name in ('graph_progress','compute_state'):records.append((p,d))
changes=[]
for p,d in records:
 now=ident(d['source']['path'])
 if now['sha256']!=d['source']['sha256']:changes.append(str(Path(d['source']['path']).relative_to(R)))
 print(Path(d['source']['path']).relative_to(R),now['sha256']==d['source']['sha256'])
for row in gdn['current_public_records']:
 d=read(row['path']);now=ident(d['source']['path'])
 if now['sha256']!=d['source']['sha256']:changes.append(str(Path(d['source']['path']).relative_to(R)))
(O/'audit.json').write_text(json.dumps(dict(graph_records=[dict(record=ident(p),source=d['source'],object=d['object'])for p,d in records],changed_sources=changes),indent=2))
print('graph_records',len(records),'changed',changes)
