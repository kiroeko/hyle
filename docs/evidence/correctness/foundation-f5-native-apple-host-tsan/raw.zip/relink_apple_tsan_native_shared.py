from pathlib import Path
import hashlib,json,os,shlex,signal,subprocess,time
root=Path('/Users/kiro/hyle-scratch/compute-unified/foundation-f5-native-host-apple-tsan')
job=json.loads((root/'job.json').read_text());build=Path(job['build'])
assert all(r['state']=='terminal' for r in job['stages'])
library=Path('/Users/kiro/hyle-scratch/compute-unified/foundation-f5-sdk-apple-shared-77df1c10c/relocated/lib/libmlx.dylib')
assert library.is_file()
env=os.environ.copy();env['TSAN_OPTIONS']='halt_on_error=1'
commands=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','commands','native','public_native'],text=True)
job['native_shared_link']={'scope':'same instrumented HYLE/consumer objects, vendor MLX separated in already-qualified same-candidate native DSO; no suppressions','library':str(library),'sha256':hashlib.sha256(library.read_bytes()).hexdigest(),'library_otool':subprocess.check_output(['/usr/bin/otool','-L',str(library)],text=True),'TSAN_OPTIONS':env['TSAN_OPTIONS'],'vendor_instrumented':False}
def run(name,command,group,total):
    old=[r for r in job['stages'] if r['name']==name]
    assert not old,'inspect existing stage before retry'
    remaining=total-sum(r.get('elapsed',0) for r in job['stages'] if r.get('budget_group')==group)
    assert remaining>0
    log=root/(name+'.log');start=time.monotonic()
    with log.open('w') as f:
        p=subprocess.Popen(command,cwd=build,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        row={'name':name,'budget_group':group,'command':command,'pid':p.pid,'state':'running','log':log.name}
        job['stages'].append(row);(root/'job.json').write_text(json.dumps(job,indent=2))
        try:code=p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code=-9
    row.update(state='terminal',elapsed=time.monotonic()-start,exit_code=code,verdict='PASS' if code==0 else 'TIMEOUT' if code==-9 else 'FAIL',sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    (root/'job.json').write_text(json.dumps(job,indent=2));print(name,code,flush=True)
    if code:raise SystemExit(code)
for target in ('public_native','native'):
    line=next(l for l in commands.splitlines() if ' -o '+target+' ' in l and '&&' in l)
    command=shlex.split(line.split('&&')[1].strip())
    index=next(i for i,v in enumerate(command) if v.endswith('/libmlx.a'))
    command[index]=str(library)
    command[command.index('-o')+1]=str(build/(target+'-native-shared'))
    command+=['-Wl,-rpath,'+str(library.parent)]
    run('relink-'+target+'-native-shared',command,'build',1800)
for target in ('public_native','native'):
    binary=build/(target+'-native-shared')
    job.setdefault('relinked_artifacts',{})[target]={'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'otool':subprocess.check_output(['/usr/bin/otool','-L',str(binary)],text=True)}
    run('run-'+target+'-native-shared',[str(binary)],'consumer',180)
job['verdict']='PASS_F5_ACTUAL_APPLE_HOST_TSAN_NATIVE_DSO'
job['vendor_whole_process_tsan']='INCONCLUSIVE_MLX_METAL_UNINSTRUMENTED; original static two FAIL reports preserved'
(root/'job.json').write_text(json.dumps(job,indent=2));print(job['verdict'])
