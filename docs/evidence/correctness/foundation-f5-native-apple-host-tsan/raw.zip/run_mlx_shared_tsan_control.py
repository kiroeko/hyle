from pathlib import Path
p=Path('/Users/kiro/hyle-scratch/compute-unified/foundation-f5-native-host-apple-tsan/run_mlx_tsan_control.py')
s=p.read_text()
s=s.replace('mlx_tsan_control.cc','mlx_tsan_deleter_control.cc').replace('mlx-control','mlx-shared-control')
s=s.replace('control-compile','shared-control-compile').replace('control-run','shared-control-run')
s=s.replace("str(build/'hyle/_deps/mlx-build/libmlx.a')","'/Users/kiro/hyle-scratch/compute-unified/foundation-f5-sdk-apple-shared-77df1c10c/relocated/lib/libmlx.dylib','-Wl,-rpath,/Users/kiro/hyle-scratch/compute-unified/foundation-f5-sdk-apple-shared-77df1c10c/relocated/lib'")
exec(compile(s,str(p),'exec'))
