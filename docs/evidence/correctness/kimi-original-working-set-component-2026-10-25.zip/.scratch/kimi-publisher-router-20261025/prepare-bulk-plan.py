from pathlib import Path
import json,hashlib
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025';p=json.loads((W/'phase2-derived-plan.json').read_bytes());shapes=json.loads((W/'shape-payload/complete.json').read_bytes());assert shapes['checked_shapes']==48 and shapes['original_metadata_bytes']==768
roles=[r for r in p['logical_roles']if not r['role'].endswith('weight_shape')];assert len(roles)==209 and sum(r['bytes']for r in roles)==1090009600
parents=[]
for role in sorted(roles,key=lambda r:(r['catalog_index'],r['first'])):
 source=next(x for x in p['requests']if x['catalog_index']==role['catalog_index'])
 if parents and parents[-1]['catalog_index']==role['catalog_index']and parents[-1]['last']+1==role['first']:
  parents[-1]['last']=role['last'];parents[-1]['bytes']+=role['bytes'];parents[-1]['roles'].append(role)
 else:parents.append(dict(catalog_index=role['catalog_index'],url=source['url'],source_etag=source['source_etag'],source_bytes=source['source_bytes'],revision=source['revision'],first=role['first'],last=role['last'],bytes=role['bytes'],roles=[role]))
requests=[]
for j,parent in enumerate(parents):
 assert parent['bytes']==parent['last']-parent['first']+1==sum(r['bytes']for r in parent['roles']);parent['parent_ordinal']=j
 for first in range(parent['first'],parent['last']+1,64*1024*1024):
  last=min(parent['last'],first+64*1024*1024-1);row={k:parent[k]for k in ['catalog_index','url','source_etag','source_bytes','revision','parent_ordinal']};row.update(ordinal=len(requests),first=first,last=last,exact_bytes=last-first+1,output=f'range-{len(requests):03d}.bin',role_intersections=[dict(role=r['role'],first=max(first,r['first']),last=min(last,r['last']))for r in parent['roles']if r['first']<=last and first<=r['last']]);assert sum(r['last']-r['first']+1 for r in row['role_intersections'])==row['exact_bytes'];requests.append(row)
plan=dict(status='AUTHORIZED_REMAINING_SOURCE_PHASE2_EXACT_EXECUTION_PLAN',source_plan_sha256=hashlib.sha256((W/'phase2-derived-plan.json').read_bytes()).hexdigest(),shape_source_receipt_sha256=hashlib.sha256((W/'shape-payload/complete.json').read_bytes()).hexdigest(),original_selected_IDs=p['source_bank_union'],logical_roles=roles,contiguous_parents=parents,requests=requests,request_count=len(requests),maximum_new_bytes=1090009600,maximum_response_bytes=64*1024*1024,max_workers=4,automatic_retries=0,reused_verified_I64_metadata_bytes=768,whole_LFS_hash_verified=False,budget_helper_sha256=hashlib.sha256((R/'.scratch/mtp-download-budget-20261023/budget.py').read_bytes()).hexdigest(),scope='Exactly the209 remaining selected expert/consumed static numeric roles, not the already acquired48 I64 roles or router+bias. Split large required intervals without reading extra gaps.',authorized=True)
(W/'phase2-execution-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(requests=len(requests),parents=len(parents),roles=len(roles),new_bytes=sum(r['exact_bytes']for r in requests),maximum_range=max(r['exact_bytes']for r in requests),shapes_reused=768)))
