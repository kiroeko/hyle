from pathlib import Path
import json,hashlib,zipfile,collections,sys
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025';C=W/'component';PUB=R/'docs/evidence/correctness';PUB.mkdir(parents=True,exist_ok=True)
NAME='kimi-original-working-set-component-2026-10-25';Z=PUB/(NAME+'.zip');J=PUB/(NAME+'.json')
assert not Z.exists() and not J.exists()
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files=set()
def add(p):
 p=Path(p);assert p.is_file(),p
 assert p.stat().st_size<8*1024*1024,('unexpected large proof input',str(p))
 assert p.suffix.lower()not in('.obj','.exe','.dll','.lib','.exp','.map','.pdb','.npz'),p
 files.add(p)
def small_tree(folder,extensions):
 if folder.exists():
  for p in folder.rglob('*'):
   if p.is_file()and p.suffix.lower()in extensions:add(p)
# Fully retained own source, commands, initial warning failure and actual outputs.
small_tree(C,{'.py','.h','.cc','.json','.log','.md','.patch'})
for p in(C/'actual-run1/results').rglob('*.bin'):add(p)
for p in(C/'reference-prepared').glob('*.bf16'):add(p)
# Authoritative original source metadata/range/HTTP receipts; never weight bodies.
for name in ['source-roles.json','bulk-fetch-summary.json','shape-fetch-summary.json','phase2-derived-plan.json','phase2-execution-plan.json','phase2-k512-shapes-only-plan.json','root-phase2-review.json','bulk-authorized-window.json','original-component-design.md','index-original-roles.py','derive-phase2.py','prepare-bulk-plan.py','prepare-component-roles.py','fetch-bulk.py','fetch-bulk.ps1','fetch-shapes.py','fetch-shapes.ps1','run-fetch-shapes.py','review-phase2.py']:
 add(W/name)
for folder in ['bulk-payload','shape-payload','bulk-fetch-run1','shape-fetch-run1']:
 small_tree(W/folder,{'.json','.log'})
for p in(W/'shape-payload').glob('*.bin'):add(p)
# Referenced authentic router proof already public; no need to duplicate25MBbody.
for p in [W/'fetch-plan.json',W/'fetch-summary.json',W/'payload/complete.json',W/'payload/source.json',W/'source-payload-aliases.json',W/'f32-frontier-witness.json']:add(p)
# Preserve actual private3core source and recorded dependencies, no OBJ/SDK.
for kind in ['budget','leases','arena']:
 D=R/'.scratch/inference-cache-shared-source-20261025/attempt1'/kind
 for name in ['command.json','repository-inputs.json','process.json','stdout.log','stderr.log']:
  if(D/name).is_file():add(D/name)
 for row in read(D/'repository-inputs.json'):
  p=Path(row['path'])
  try:rel=p.resolve().relative_to(R.resolve()).as_posix()
  except ValueError:continue
  if rel.startswith('.scratch/inference-cache-shared-source-20261025/source/'):
   assert pin(p)['sha256']==row['sha256'];add(p)
for p in [R/'.scratch/inference-cache-shared-source-20261025/source.patch',R/'.scratch/inference-cache-shared-source-20261025/source-before-atomic.patch']:
 if p.is_file():add(p)
# Existing tool helper supplies environment/execute; source only.
add(R/'.scratch/mtp-extraction-regression-20261024/check.py')
# Exact private rebuildable binary inventory. Shared3core/SDK/source/model/cache excluded.
candidates=[]
for folder in [C/'build1',C/'build2']:
 for p in folder.rglob('*'):
  if p.is_file()and p.suffix.lower()in('.obj','.exe','.dll','.lib','.exp','.map','.pdb'):candidates.append(pin(p))
candidates.sort(key=lambda x:x['path']);cleanup=dict(status='EXACT_PRIVATE_REBUILDABLE_COMPONENT_BINARIES_ONLY',performed=False,files=candidates,logical_bytes=sum(x['bytes']for x in candidates),shared_core_objects_preserved=True,source_payloads_and_raw_outputs_preserved=True,scope='Only these private component paths; native DLL is a private hardlink, original retained. No deletion performed.')
(C/'cleanup-candidates.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8');add(C/'cleanup-candidates.json')
audit=read(C/'actual-run1/numerical-audit.json');native=read(C/'actual-run1/result.json');assert audit['failure']is None and audit['status'].startswith('PASS_') and native['process']['exit']==0
counts=collections.defaultdict(lambda:dict(checks=0,values=0))
for rec in audit['checks']:counts[rec['gate']]['checks']+=1;counts[rec['gate']]['values']+=rec['values']
raws=[pin(p)for p in sorted((C/'actual-run1/results').rglob('*.bin'))]
summary=dict(schema='hyle.correctness_evidence.v1',status='PASS_AUTHENTIC_SELECTED_KIMI_WORKING_SET_COMPONENT',date='2026-10-25',scope='Original selected publisher roles and generated hidden-input boundary; not complete Kimi/model execution, quality or TPS.',source=dict(index=pin(W/'source-roles.json'),logical_roles=261,cached_original_parts=76,total_original_range_bytes=1115707648,bulk_numeric_bytes=1090009600,original_I64_shape_bytes=768,previous_router_bias_bytes=25697280,whole_LFS_hash_verified=False,all_acquisition_hosts='https://hf-mirror.net',acquisition_auto_retries=0,PAUSED_restored=True,geometry=dict(hidden=7168,experts=896,TopK=16,latent=3584,intermediate=3072,shared=6144),selected_expert_ids=[79,156,210,220,250,260,305,365,366,404,444,593,619,634,731,878],same_IDs_for_two_inputs_and_artifacts=True,source_binding='Original typed physical bytes and exact I64 logical shapes; cold byte assembly only; no dequantized persistent bank.',prior_router_proof='docs/evidence/correctness/kimi-original-router-frontier-2026-10-25.json'),execution=dict(native_processes=1,native=pin(C/'actual-run1/process.json'),native_seconds=native['process']['seconds'],CPU_audits=1,CPU_audit=pin(C/'audit-run1/process.json'),CPU_audit_seconds=audit['seconds'],GPU_released=True,core='Exact3 reviewed private cache-source core objects from source/command pins; unchanged public layout. No SDK/core rebuild in component task.',compile_attempts=2,successful_entry_TUs=1,compile_first_failure='build1 strict C4456 report-loop local source shadowed source adapter; no link/native run. build2 renamed selected_source only.',successful_compile_seconds=read(C/'build2/compile/process.json')['seconds'],successful_link_seconds=read(C/'build2/link/process.json')['seconds'],engine_or_core_product_edits=False),runtime=read(C/'build2/summary.json'),lifecycle=dict(banks=7,upload_generations_per_codec=2,graph_submissions_per_codec=5,Quark_slot_logical_bytes=280759808,K512_slot_logical_bytes=268373504,total_upload_logical_bytes=1098266624,total_upload_staged_bytes=1098266624,total_upload_submitted_bytes=1098266624,total_upload_completed_bytes=1098266624,unknown_copy_bytes=False,old_readers_unchanged=True,busy_old_slot_refused=True,rejected_last_bank_binding_preserved_original_complete_execution=True),numerical=dict(status=audit['status'],stage_checks=len(audit['checks']),gate_counts=dict(counts),BF16_total_checked_values=1022208,reference_formula_wrong_intermediate_BF16_witnesses=sum(x.get('wrong_intermediate_BF16_witnesses',0)for x in audit['checks']),reference_witness_scope='Independent full-F32 formula differs from hypothetical intermediate-BF16 reference at these positions; not an extra bitwise rejection gate on all actual outputs.',actual_audit=pin(C/'actual-run1/numerical-audit.json'),executed_reference=pin(C/'audit-run1/reference-executed.py'),static_reference_preparation=pin(C/'reference-prepared/summary.json'),static_references_recomputed_after_finite_fix=False,source_equivalence=pin(C/'reference-source-equivalence2.json'),finite_guard_checks=pin(C/'finite-guard-host-check.json'),raw_stage_files=len(raws),raw_stage_bytes=sum(p['bytes']for p in raws),raw_stage_payloads=raws),failures_and_corrections=[dict(kind='PRIVATE_CONSUMER_STRICT_COMPILE_FAILURE',process=pin(C/'build1/compile/process.json'),logs='component/build1/compile',correction='Report-only local variable rename; source1/source2 frozen and preserved.'),dict(kind='SOURCE_REVIEW_FOUND_ORACLE_NONFINITE_REJECTION_GAP_BEFORE_GPU',correction='Explicit finite(actual/expected) and finite(actual/gate/up/reference/tolerance); no finite formula/tolerance change, no numerical failure overwritten.',old_reference=pin(C/'frozen/reference.py'),executed_reference=pin(C/'frozen2/reference.py'))],limitations=['Generated fixed hidden inputs and authenticated original selected source roles; not original full model or all896 experts.','Selected Top16 are identical for both inputs and artifacts; no artificial expert rotation/seed search. Two immutable generations retain the same IDs and encoded bytes with different actual activations.','A32/BF16 dense use complete F64 dots and conservative arbitrary-F32-summation bounds with final BF16 RNE endpoints; passing does not certify correct rounding or exact internal arithmetic.','Downstream independent equations are conditional on previously validated actual preceding tensors; not a bitwise whole-layer CPU trajectory.','K512 QA/internal integer/group checkpoints are independently computed, not captured native internal tensors. Exact final BF16 gates preserve the complete group equation.','FP8 token scale/quantized A/dot intermediates are not separately captured; only independent source/input equations and actual final128 BF16 outputs are checked.','Inherited nonlinear tolerance remains unchanged; no task-quality/TPS/Apple/CPU-full-component or full publisher artifact execution claim.','Only successful Completion outputs are captured; no failed native output-read contract asserted.','Large original weight bodies, tools/SDK, OBJ/EXE and prepared reference NPZ are intentionally excluded; source/receipts/SHA and reference generator suffice with the retained cache.'],cleanup=cleanup)
# The packer's source is itself archived after writing this file.
add(Path(__file__).resolve())
manifest=[pin(p)for p in sorted(files)];(C/'proof-payloads.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8');add(C/'proof-payloads.json')
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(Z)as z:
 assert z.testzip()is None;entries=len(z.infolist())
 summary['archive']=pin(Z);summary['archive']['entries']=entries;summary['archive']['CRC_verified']=True
J.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
(C/'public-proposal.json').write_text(json.dumps(dict(summary=pin(J),archive=pin(Z),cleanup=pin(C/'cleanup-candidates.json')),indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(summary=pin(J),archive=pin(Z),entries=entries,cleanup_files=len(candidates),cleanup_logical_bytes=cleanup['logical_bytes'])))
