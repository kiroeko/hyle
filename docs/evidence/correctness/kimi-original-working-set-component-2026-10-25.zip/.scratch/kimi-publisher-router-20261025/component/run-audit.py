from pathlib import Path
import json,sys,subprocess,time,hashlib,shutil
R=Path.cwd();C=R/'.scratch/kimi-publisher-router-20261025/component';D=C/'audit-run1';D.mkdir(exist_ok=False)
source=C/'reference.py';expected='8f5286d73f0911dbc96c44e5dd4d3f1209bde13271e3d77c5eb26cd6141ad724';assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
shutil.copyfile(source,D/'reference-executed.py')
cmd=[sys.executable,str(source),'--audit',str(C/'actual-run1/results')]
(D/'command.json').write_text(json.dumps(dict(argv=cmd,cwd=str(R),executed_source_sha256=expected,archived_source='reference-executed.py',GPU=False,HTTP=False),indent=2)+'\n',encoding='utf8')
t=time.time();p=subprocess.run(cmd,cwd=R,capture_output=True,timeout=600)
(D/'stdout.log').write_bytes(p.stdout);(D/'stderr.log').write_bytes(p.stderr)
(D/'process.json').write_text(json.dumps(dict(exit_code=p.returncode,seconds=time.time()-t,source_sha256=expected,GPU=False,HTTP=False),indent=2)+'\n',encoding='utf8')
print(p.stdout.decode('utf8',errors='replace'));print(p.stderr.decode('utf8',errors='replace'));sys.exit(p.returncode)
