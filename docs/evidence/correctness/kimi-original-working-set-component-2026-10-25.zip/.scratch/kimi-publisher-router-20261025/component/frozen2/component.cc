// Authentic selected original source roles; generated hidden input boundary.
// Shared Graph, WeightSlots and seven-bank supplier from the generated
// regression.
#include "engine/inference/artifact_digest.h"
#include "engine/inference/prepared_output.h"
#include "tests/compute_models/model_plane_resident_weights.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/cuda.h"
#include <bit>
#include <cmath>
#include <cstring>
#include <iostream>
#include <numeric>
#include <set>
#include <map>
#include <functional>

#include "original_source.h"
#include <filesystem>
#include <fstream>
namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace supply = model_plane_resident_weights;
namespace inf = hyle::inference;
using T = c::DataType;
using V = g::ValueId;
using Bytes = std::vector<std::byte>;
template <class X> X take(hyle::Result<X> r) {
  if (!r)
    throw std::runtime_error(std::string(r.error().message()));
  return std::move(*r);
}
void check(hyle::Status s) {
  if (!s.ok())
    throw std::runtime_error(std::string(s.message()));
}
void require(bool b, const char *message) {
  if (!b)
    throw std::runtime_error(message);
}
c::TensorDesc dense(T t, std::initializer_list<std::int64_t> s) {
  return take(c::TensorDesc::dense(t, {s.begin(), s.size()}));
}
template <class X> Bytes raw(std::span<const X> x) {
  auto b = std::as_bytes(x);
  return {b.begin(), b.end()};
}
template <class X> Bytes raw(const std::vector<X> &x) {
  return raw(std::span<const X>(x));
}
std::uint16_t bf(float x) {
  const auto u = std::bit_cast<std::uint32_t>(x);
  return static_cast<std::uint16_t>((u + 0x7fffU + ((u >> 16U) & 1U)) >> 16U);
}
constexpr std::int64_t H = 7168, E = 896, S = 16, L = 3584, I = 3072, SH = 6144;
enum class Codec { Quark, K512 };
struct Selection {
  std::vector<std::int32_t> globals, map;
};
Selection select(std::span<const std::int32_t> ids) {
  Selection r;
  r.map.assign(E, -1);
  r.globals.assign(ids.begin(), ids.end());
  std::ranges::sort(r.globals);
  r.globals.erase(std::unique(r.globals.begin(), r.globals.end()),
                  r.globals.end());
  require(r.globals.size() == S, "true Top16 must contain16 distinct experts");
  for (std::size_t j = 0; j < r.globals.size(); ++j) {
    require(r.globals[j] >= 0 && r.globals[j] < E, "global expert outside896");
    r.map[std::size_t(r.globals[j])] = static_cast<std::int32_t>(j);
  }
  return r;
}
std::int64_t n_for(unsigned leg) { return leg == 2 ? L : I; }
std::int64_t k_for(unsigned leg) { return leg == 2 ? I : L; }
constexpr std::string_view prefix =
    "language_model.model.layers.1.block_sparse_moe.";
std::filesystem::path repository_root, result_root;
std::string expert_role(std::size_t p, std::int32_t id, Codec codec) {
  constexpr std::array<unsigned, 3> legs{1, 3, 2};
  return std::string(prefix) + "experts." + std::to_string(id) + ".w" +
         std::to_string(legs[p / 2]) +
         (p % 2                   ? ".weight_scale"
          : codec == Codec::Quark ? ".weight"
                                  : ".weight_packed");
}
struct Sources {
  std::map<std::pair<std::size_t, std::int32_t>, const m::Buffer *> storage;
  std::vector<std::string> hashes;
  Sources(original_kimi_roles::Source &source, Codec codec,
          const Selection &selected) {
    const auto catalog = codec == Codec::Quark ? 23 : 24;
    for (std::size_t p = 0; p < 6; ++p)
      for (auto id : selected.globals) {
        const auto name = expert_role(p, id, codec);
        const auto &role = source.role(catalog, name);
        require(
            role.bytes ==
                std::size_t(n_for(unsigned(p / 2)) * k_for(unsigned(p / 2))) /
                    (p % 2 ? (codec == Codec::Quark ? 32u : 128u) : 2u),
            "actual expert plane extent");
        hashes.emplace_back(role.sha256);
        storage.emplace(std::pair{p, id}, &source.buffer(catalog, name));
        if (codec == Codec::K512 && p % 2 == 0) {
          const auto shape_name =
              name.substr(0,
                          name.size() - std::string("weight_packed").size()) +
              "weight_shape";
          auto bytes = source.bytes(catalog, shape_name);
          std::array<std::int64_t, 2> shape{};
          require(bytes.size() == sizeof(shape), "original I64 shape extent");
          std::memcpy(shape.data(), bytes.data(), bytes.size());
          require(shape == std::array<std::int64_t, 2>{n_for(unsigned(p / 2)),
                                                       k_for(unsigned(p / 2))},
                  "original I64 logical shape differs");
        }
      }
  }
  m::ConstBufferView plane_view(std::size_t p, std::int32_t id) const {
    return storage.at({p, id})->view();
  }
};
std::vector<c::TensorDesc> expert_planes(Codec codec) {
  std::vector<c::TensorDesc> d;
  for (unsigned leg = 0; leg < 3; ++leg) {
    const auto n = n_for(leg), k = k_for(leg);
    d.push_back(dense(codec == Codec::Quark ? T::kUInt8 : T::kInt32,
                      {n, k / (codec == Codec::Quark ? 2 : 8)}));
    d.push_back(dense(codec == Codec::Quark ? T::kUInt8 : T::kFloat32,
                      {n, k / (codec == Codec::Quark ? 32 : 512)}));
  }
  return d;
}
struct SharedMemory {
  std::shared_ptr<c::cuda::MemoryResource> resource;
  m::MemoryResourceRef ref() const noexcept { return resource->ref(); }
};
struct Device {
  c::Context context = take(g::cuda::create_context());
  std::shared_ptr<c::cuda::MemoryResource> memory =
      std::make_shared<c::cuda::MemoryResource>(
          take(c::cuda::MemoryResource::create(context,
                                               c::cuda::MemoryKind::kDevice)));
  c::StorageOwner owner =
      take(c::StorageOwner::adopt(context, SharedMemory{memory}));
  c::Queue queue = take(context.create_queue()),
           transfer = take(context.create_queue());
  c::ReadLease upload(c::TensorDesc description,
                      std::span<const std::byte> data) {
    require(take(description.required_bytes()) == data.size(),
            "exact source tensor byte extent");
    auto b = take(m::Buffer::create(memory->ref(), data.size(), 256));
    check(b.view().write(data));
    return take(owner.adopt_buffer(std::move(b)));
  }
};
struct Graph {
  Device &device;
  original_kimi_roles::Source &source;
  int catalog;
  g::GraphBuilder b = take(g::GraphBuilder::create());
  std::vector<g::ConstantBinding> constants;
  std::vector<c::ReadLease> literals;
  std::vector<V> outputs;
  Graph(Device &d, original_kimi_roles::Source &source_data, int source_catalog)
      : device(d), source(source_data), catalog(source_catalog) {}
  V original(std::string_view name) {
    return constant(source.description(catalog, name),
                    source.bytes(catalog, name));
  }
  V input(c::TensorDesc d) { return take(b.input(d)); }
  V one(c::Operation op, std::initializer_list<V> args) {
    return take(b.result(take(b.add_node(op, {args.begin(), args.size()}))));
  }
  template <class Op> V one(Op op, std::initializer_list<V> args) {
    return one(c::Operation(op), args);
  }
  V constant(c::TensorDesc d, Bytes data) {
    auto value = take(b.constant(d));
    literals.push_back(device.upload(d, data));
    constants.push_back({value, take(literals.back().tensor(d)),
                         g::ConstantPolicy::kBorrow, device.owner,
                         literals.back()});
    return value;
  }
  V number(float x) {
    return one(c::Fill{.output_shape = take(c::TensorShape::create(
                           std::array<std::int64_t, 1>{1})),
                       .output_type = T::kFloat32,
                       .value = c::ScalarValue(x)},
               {});
  }
  V cast(V v, T t) { return one(c::Cast{t}, {v}); }
  V binary(c::BinaryKind kind, V a, V z) {
    return one(c::Binary{kind}, {a, z});
  }
  V unary(c::UnaryKind kind, V x) { return one(c::Unary{kind}, {x}); }
  V reshape(V x, std::initializer_list<std::int64_t> s) {
    return one(take(c::View::reshape(
                   take(c::TensorShape::create({s.begin(), s.size()})))),
               {x});
  }
  V sum(V x, std::int32_t axis) {
    return one(c::Reduce{.kind = c::ReductionKind::kSum,
                         .axes = take(c::Axes::from(std::array{axis})),
                         .accumulation_type = T::kFloat32},
               {x});
  }
  V situ(V gate, V up) {
    gate = cast(gate, T::kFloat32);
    up = cast(up, T::kFloat32);
    const auto a = binary(
        c::BinaryKind::kMultiply,
        binary(c::BinaryKind::kMultiply, number(4.F),
               unary(c::UnaryKind::kTanh,
                     binary(c::BinaryKind::kMultiply, gate, number(.25F)))),
        unary(c::UnaryKind::kSigmoid, gate));
    const auto z =
        binary(c::BinaryKind::kMultiply, number(25.F),
               unary(c::UnaryKind::kTanh,
                     binary(c::BinaryKind::kMultiply, up, number(.04F))));
    return cast(binary(c::BinaryKind::kMultiply, a, z), T::kBFloat16);
  }
  V dense_weight(std::int64_t n, std::int64_t k, unsigned seed) {
    const auto suffix = seed == 33    ? "routed_expert_down_proj.weight"
                        : seed == 44  ? "routed_expert_up_proj.weight"
                        : seed == 100 ? "shared_experts.gate_proj.weight"
                        : seed == 101 ? "shared_experts.up_proj.weight"
                        : seed == 102 ? "shared_experts.down_proj.weight"
                                      : nullptr;
    require(suffix != nullptr, "unknown static role");
    const auto name = std::string(prefix) + suffix;
    const auto d = source.description(catalog, name);
    require(d == dense(T::kBFloat16, {n, k}), "actual BF16 static descriptor");
    return original(name);
  }
  V dense_projection(V a, std::int64_t n, std::int64_t k, unsigned seed) {
    const auto w = dense_weight(n, k, seed);
    return one(
        c::MatMul{.accumulation_type = T::kFloat32},
        {a,
         one(take(c::View::permute(std::array<std::int32_t, 2>{1, 0})), {w})});
  }
  V fixed_projection(Codec codec, V a, std::int64_t n, std::int64_t k,
                     unsigned leg) {
    if (codec == Codec::K512)
      return dense_projection(a, n, k, 100 + leg);
    constexpr std::array<std::string_view, 3> names{"gate_proj", "up_proj",
                                                    "down_proj"};
    const auto name =
        std::string(prefix) + "shared_experts." + std::string(names[leg]);
    require(source.description(catalog, name + ".weight") ==
                dense(T::kUInt8, {n, k / 2}),
            "actual MX static descriptor");
    require(source.description(catalog, name + ".weight_scale") ==
                dense(T::kUInt8, {n, k / 32}),
            "actual MX SF descriptor");
    return one(
        c::model_ops::mxfp4_linear(),
        {a, original(name + ".weight"), original(name + ".weight_scale")});
  }
  void publish(V v) {
    check(b.publish(v));
    outputs.push_back(v);
  }
  g::CompiledGraph compile() {
    auto graph = take(std::move(b).finish());
    return take(g::cuda::compile(graph, device.context, device.owner,
                                 {.constants = constants}));
  }
};
struct Router {
  Graph graph;
  V x, ids, weights, latent;
  g::CompiledGraph compiled;
  Router(Device &device, original_kimi_roles::Source &source, int catalog)
      : graph(device, source, catalog) {
    x = graph.input(dense(T::kBFloat16, {1, H}));
    const auto rw = graph.original(std::string(prefix) + "gate.weight");
    auto logits = graph.one(c::model_ops::dense_linear_f32(), {x, rw});
    auto scores = graph.unary(c::UnaryKind::kSigmoid, logits);
    const auto select_scores = graph.binary(
        c::BinaryKind::kAdd, scores,
        graph.original(std::string(prefix) + "gate.e_score_correction_bias"));
    const auto node = take(graph.b.add_node(c::Operation(c::TopK{.count = S}),
                                            std::span(&select_scores, 1)));
    ids = take(graph.b.result(node, 1));
    auto chosen = graph.one(
        c::model_ops::gather_elements(-1, c::IndexBoundsPolicy::kUnchecked),
        {scores, ids});
    weights = graph.binary(c::BinaryKind::kDivide, chosen,
                           graph.reshape(graph.sum(chosen, 1), {1, 1}));
    latent = graph.dense_projection(x, L, H, 33);
    for (auto out :
         {ids, weights, latent, logits, scores, select_scores, chosen})
      graph.publish(out);
    compiled = graph.compile();
  }
};
struct Expert {
  Graph graph;
  V x, ids, weights, latent;
  std::array<V, 7> banks;
  std::vector<g::WeightBinding> bindings;
  g::CompiledGraph compiled;
  Codec codec;
  Expert(Device &device, Codec chosen, const supply::Layout &layout,
         original_kimi_roles::Source &source)
      : graph(device, source, chosen == Codec::Quark ? 23 : 24), codec(chosen) {
    x = graph.input(dense(T::kBFloat16, {1, H}));
    ids = graph.input(dense(T::kInt32, {1, S}));
    weights = graph.input(dense(T::kFloat32, {1, S}));
    latent = graph.input(dense(T::kBFloat16, {1, L}));
    for (std::size_t p = 0; p < 6; ++p) {
      banks[p] = graph.input(layout.resident[p]);
      bindings.push_back({banks[p], p + 1});
    }
    banks[6] = graph.input(layout.map_description());
    bindings.push_back({banks[6], 7});
    auto local = graph.one(c::Gather{.bounds = c::IndexBoundsPolicy::kChecked},
                           {banks[6], ids});
    const auto grouped = [&](V a, unsigned leg) {
      return graph.one(codec == Codec::Quark
                           ? c::model_ops::grouped_mxfp4_linear()
                           : c::model_ops::grouped_blockwise_w4a8_linear(),
                       {a, banks[2 * leg], banks[2 * leg + 1], local});
    };
    auto a = graph.reshape(latent, {1, 1, L});
    auto gate = grouped(a, 0), up = grouped(a, 1),
         activated = graph.situ(gate, up), down = grouped(activated, 2);
    auto combined =
        graph.cast(graph.sum(graph.binary(c::BinaryKind::kMultiply,
                                          graph.cast(down, T::kFloat32),
                                          graph.reshape(weights, {1, S, 1})),
                             1),
                   T::kBFloat16);
    const auto gamma = graph.cast(
        graph.original(std::string(prefix) + "routed_expert_norm.weight"),
        T::kFloat32);
    auto normalized =
        graph.cast(graph.one(c::RmsNorm{.epsilon = 1.e-5F},
                             {graph.cast(combined, T::kFloat32), gamma}),
                   T::kBFloat16);
    auto routed = graph.dense_projection(normalized, H, L, 44);
    auto sg = graph.fixed_projection(codec, x, SH, H, 0),
         su = graph.fixed_projection(codec, x, SH, H, 1);
    auto sa = graph.situ(sg, su),
         shared = graph.fixed_projection(codec, sa, H, SH, 2);
    auto result = graph.binary(c::BinaryKind::kAdd, routed, shared);
    for (auto out : {gate, up, activated, down, combined, normalized, routed,
                     sg, su, sa, shared, result})
      graph.publish(out);
    // The source E4 projection is an independent attention-frontier branch.
    // It is never inserted as a fictional extra FFN stage.
    if (codec == Codec::Quark) {
      const auto wf = graph.original(
          "language_model.model.layers.1.self_attn.f_a_proj.weight");
      const auto sf = graph.original(
          "language_model.model.layers.1.self_attn.f_a_proj.weight_scale");
      auto xf = graph.cast(x, T::kFloat32);
      auto max = graph.one(
          c::Reduce{.kind = c::ReductionKind::kMaximum,
                    .axes = take(c::Axes::from(std::array<std::int32_t, 1>{1})),
                    .keep_dimensions = true,
                    .accumulation_type = T::kFloat32},
          {graph.unary(c::UnaryKind::kAbs, xf)});
      auto scale =
          graph.binary(c::BinaryKind::kMultiply, max,
                       graph.number(std::bit_cast<float>(0x3b124925U)));
      auto inverse =
          graph.binary(c::BinaryKind::kDivide, graph.number(1.F), scale);
      auto q = graph.cast(graph.binary(c::BinaryKind::kMultiply, xf, inverse),
                          T::kFloat8E4M3FN);
      auto dot = graph.one(
          c::MatMul{.accumulation_type = T::kFloat32},
          {graph.cast(q, T::kFloat32),
           graph.one(take(c::View::permute(std::array<std::int32_t, 2>{1, 0})),
                     {graph.cast(wf, T::kFloat32)})});
      graph.publish(graph.cast(
          graph.binary(c::BinaryKind::kMultiply,
                       graph.binary(c::BinaryKind::kMultiply, dot, sf), scale),
          T::kBFloat16));
    }
    compiled = graph.compile();
  }
};
struct Episode {
  g::Invocation invocation;
  std::vector<c::ReadLease> outputs;
  std::vector<c::LeasePool> caller_pools;
  std::vector<Bytes> saved;
};
struct Input {
  V id;
  c::TensorDesc description;
  c::ReadLease read;
};
Episode
execute(Device &device, const g::CompiledGraph &compiled,
        std::span<const V> outputs, std::span<const Input> inputs,
        const std::function<void(g::Invocation &)> &external = {},
        const std::function<void(g::Invocation &)> &after_prepare = {}) {
  Episode episode;
  episode.invocation = take(compiled.executable.create_invocation());
  check(episode.invocation.prepare_resources());
  for (const auto &input : inputs)
    check(episode.invocation.bind(input.id, input.description, input.read));
  if (external)
    external(episode.invocation);
  std::vector<inf::PreparedOutputFacts> facts;
  for (auto id : outputs) {
    auto f = take(inf::prepare_output(compiled, id));
    facts.push_back(f);
    if (f.caller_owned()) {
      const auto size = take(f.description.required_bytes());
      episode.caller_pools.push_back(take(
          c::LeasePool::create(device.memory->ref(), size, {.max_blocks = 1})));
      check(episode.invocation.bind(
          id, f.description, take(episode.caller_pools.back().allocate(size))));
    }
  }
  const std::array queues{
      g::QueueBinding{g::ExecutionLaneId{0}, &device.queue}};
  check(episode.invocation.prepare_replay(
      queues, {.mode = g::ReplayMode::kCommands,
               .host_wait = g::HostWaitPolicy::kAllow}));
  if (after_prepare)
    after_prepare(episode.invocation);
  {
    auto done = take(episode.invocation.submit(queues));
    check(done.wait());
  }
  for (const auto &f : facts) {
    auto ready = take(inf::retain_output(episode.invocation, f));
    Bytes data(ready.size());
    check(take(ready.view()).read(data));
    episode.saved.push_back(std::move(data));
    episode.outputs.push_back(std::move(ready));
  }
  return episode;
}
template <class X> std::vector<X> values(const Bytes &bytes) {
  require(bytes.size() % sizeof(X) == 0, "typed output bytes");
  std::vector<X> result(bytes.size() / sizeof(X));
  std::memcpy(result.data(), bytes.data(), bytes.size());
  return result;
}
void unchanged(const Episode &episode) {
  for (std::size_t p = 0; p < episode.outputs.size(); ++p) {
    Bytes current(episode.outputs[p].size());
    check(take(episode.outputs[p].view()).read(current));
    require(current == episode.saved[p],
            "old read lease changed after other generation");
  }
}

std::vector<std::uint16_t> activation(unsigned epoch) {
  std::vector<std::uint16_t> x(H);
  constexpr std::array<float, 4> v{1.F, 2.F, -.75F, -1.F};
  for (std::size_t j = 0; j < x.size(); ++j)
    x[j] = bf(v[j % 4]);
  for (std::size_t j = 0; j < 17; ++j)
    x[j] = bf((2.F + float(epoch ? 16 - j : j) / 8.F) / 64.F);
  return x;
}
void dump(std::string_view role, unsigned epoch, const Episode &e) {
  const auto path =
      result_root / std::string(role) / ("epoch" + std::to_string(epoch));
  std::filesystem::create_directories(path);
  for (std::size_t j = 0; j < e.saved.size(); ++j) {
    std::ofstream f(path / ("output-" + std::to_string(j) + ".bin"),
                    std::ios::binary);
    f.write(reinterpret_cast<const char *>(e.saved[j].data()),
            static_cast<std::streamsize>(e.saved[j].size()));
    require(bool(f), "stage dump write failed");
  }
}
std::array<Input, 4> expert_inputs(const Expert &expert, const c::ReadLease &x,
                                   const Episode &route) {
  return {{{expert.x, dense(T::kBFloat16, {1, H}), x},
           {expert.ids, dense(T::kInt32, {1, S}), route.outputs[0]},
           {expert.weights, dense(T::kFloat32, {1, S}), route.outputs[1]},
           {expert.latent, dense(T::kBFloat16, {1, L}), route.outputs[2]}}};
}
void run(Codec codec) {
  original_kimi_roles::Source source(repository_root);
  Device device;
  const auto catalog = codec == Codec::Quark ? 23 : 24;
  const auto planes = expert_planes(codec);
  const auto layout = take(supply::Layout::create(planes, E, S));
  require(layout.logical_bytes ==
              (codec == Codec::Quark ? 280759808u : 268373504u),
          "actual seven-bank bounded extent");
  Router router(device, source, catalog);
  Expert expert(device, codec, layout, source);
  auto resident = take(supply::CudaSupply::create(device.context, device.owner,
                                                  *device.memory, layout));
  std::array<Episode, 2> routes, episodes;
  std::array<c::ReadLease, 2> xready;
  std::array<c::cuda::WeightBatch, 2> batches;
  std::array<Selection, 2> selections;
  std::array<std::unique_ptr<Sources>, 2> sources;
  std::vector<c::WeightUploadReport> reports;
  std::vector<std::vector<std::int32_t>> actual_ids;
  for (unsigned epoch = 0; epoch < 2; ++epoch) {
    const auto x = activation(epoch);
    xready[epoch] = device.upload(dense(T::kBFloat16, {1, H}), raw(x));
    const std::array inputs{
        Input{router.x, dense(T::kBFloat16, {1, H}), xready[epoch]}};
    routes[epoch] =
        execute(device, router.compiled, router.graph.outputs, inputs);
    const auto ids = values<std::int32_t>(routes[epoch].saved[0]);
    dump("catalog" + std::to_string(catalog) + "/router", epoch, routes[epoch]);
    const std::vector<std::int32_t> expected_ids{220, 210, 79,  156, 404, 593,
                                                 444, 305, 365, 731, 634, 250,
                                                 366, 260, 878, 619};
    require(ids == expected_ids, "actual authentic router ID frontier changed");
    actual_ids.push_back(ids);
    selections[epoch] = select(ids);
    sources[epoch] =
        std::make_unique<Sources>(source, codec, selections[epoch]);
    batches[epoch] = take(resident.upload(epoch, selections[epoch],
                                          *sources[epoch], device.transfer));
    const auto input = expert_inputs(expert, xready[epoch], routes[epoch]);
    episodes[epoch] = execute(
        device, expert.compiled, expert.graph.outputs, input,
        [&](auto &invocation) {
          check(g::cuda::bind(invocation, expert.bindings, batches[epoch]));
        });
    dump("catalog" + std::to_string(catalog) + "/expert", epoch,
         episodes[epoch]);
    check(batches[epoch].wait());
    reports.push_back(take(batches[epoch].report()));
    require(reports.back().logical_bytes == layout.logical_bytes &&
                reports.back().staged_bytes == layout.logical_bytes &&
                reports.back().completed_bytes ==
                    reports.back().submitted_bytes &&
                !reports.back().copied_bytes_unknown,
            "real seven-bank upload accounting");
  }
  require(actual_ids[0] == actual_ids[1],
          "the authenticated equal-ID two-input frontier changed");
  unchanged(episodes[0]);
  unchanged(episodes[1]);
  require(!resident.upload(0, selections[0], *sources[0], device.transfer),
          "old immutable batch slot reused while still retained");
  const auto input = expert_inputs(expert, xready[0], routes[0]);
  auto probe = execute(
      device, expert.compiled, expert.graph.outputs, input,
      [&](auto &invocation) {
        check(g::cuda::bind(invocation, expert.bindings, batches[0]));
      },
      [&](auto &invocation) {
        auto bad = expert.bindings;
        bad.back().id = 999999;
        require(!g::cuda::bind(invocation, bad, batches[1]).ok(),
                "missing final bank binding accepted");
      });
  require(probe.saved == episodes[0].saved,
          "rejected final bank replaced part of original bindings/preparation");
  unchanged(episodes[0]);
  unchanged(episodes[1]);
  std::cout
      << "{\"codec\":\"" << (codec == Codec::Quark ? "QuarkA32" : "K512")
      << "\",\"status\":\"PASS_AUTHENTIC_ROLES_LIFECYCLE_PENDING_INDEPENDENT_NUMERIC_AUDIT\",\"hidden\":7168,\"global_experts\":896,\"top_k\":16,\"latent\":3584,\"intermediate\":3072,\"shared\":6144,\"banks\":7,\"upload_generations\":2,\"graph_submissions\":5,\"logical_bytes_per_slot\":"
      << layout.logical_bytes
      << ",\"old_reader_unchanged\":true,\"rejected_last_binding_preserved_and_executed\":true,\"publisher_payload\":true,\"source_plane_sha256\":[";
  bool first = true;
  for (const auto &selected_source : sources)
    for (const auto &hash : selected_source->hashes) {
      if (!first)
        std::cout << ',';
      first = false;
      std::cout << '"' << hash << '"';
    }
  std::cout << "],\"actual_global_ids\":[";
  for (unsigned epoch = 0; epoch < 2; ++epoch) {
    if (epoch)
      std::cout << ',';
    std::cout << '[';
    for (std::size_t j = 0; j < actual_ids[epoch].size(); ++j) {
      if (j)
        std::cout << ',';
      std::cout << actual_ids[epoch][j];
    }
    std::cout << ']';
  }
  std::cout << "],\"output_SHA256\":[";
  for (unsigned epoch = 0; epoch < 2; ++epoch) {
    if (epoch)
      std::cout << ',';
    std::cout << '[';
    for (std::size_t j = 0; j < episodes[epoch].saved.size(); ++j) {
      if (j)
        std::cout << ',';
      std::cout << '"' << inf::artifact::sha256(episodes[epoch].saved[j])
                << '"';
    }
    std::cout << ']';
  }
  std::cout << "],\"upload_reports\":[";
  for (std::size_t j = 0; j < reports.size(); ++j) {
    if (j)
      std::cout << ',';
    const auto &r = reports[j];
    std::cout << "{\"logical_bytes\":" << r.logical_bytes
              << ",\"staged_bytes\":" << r.staged_bytes
              << ",\"submitted_bytes\":" << r.submitted_bytes
              << ",\"completed_bytes\":" << r.completed_bytes
              << ",\"copied_bytes_unknown\":"
              << (r.copied_bytes_unknown ? "true" : "false") << '}';
  }
  std::cout << "]}\n";
  probe = Episode{};
  episodes = {};
  routes = {};
  batches = {};
  check(resident.close());
}

} // namespace

int main(int argc, char **argv) {
  try {
    require(argc == 4 && std::string_view(argv[1]) == "--run",
            "expected --run repository_root result_directory");
    repository_root = std::filesystem::path(argv[2]);
    result_root = std::filesystem::path(argv[3]);
    require(!std::filesystem::exists(result_root),
            "refuse to overwrite actual output");
    std::filesystem::create_directories(result_root);
    run(Codec::Quark);
    run(Codec::K512);
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "FAIL: " << e.what() << '\n';
    return 1;
  }
}
