from pathlib import Path
import json,hashlib,difflib,sys,importlib.util,shutil
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025';C=W/'component';F=C/'frozen';F.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for name in ['component.cc','original_source.h','original_roles.h']:shutil.copyfile(C/'source'/name,F/name)
shutil.copyfile(C/'reference.py',F/'reference.py')
includes=b.read(R/'.scratch/kimi-mixed-working-set-20261025/strict2/dependencies.json')['Data']['Includes']
for name in includes:
 p=Path(name)
 try:rel=p.resolve().relative_to(R.resolve())
 except ValueError:continue
 if str(rel).lower().startswith(('include\\','engine\\')):
  target=F/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
p=R/'tests/compute_models/model_plane_resident_weights.h';q=F/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
# Reference is executed from its stable authoritative location, frozen copy is proof.
old=R/'tests/compute_models/kimi_mixed_working_set_consumer_test.cc'
(C/'actual-source.patch').write_text(''.join(difflib.unified_diff(old.read_text(encoding='utf8').splitlines(True),(F/'component.cc').read_text(encoding='utf8').splitlines(True),fromfile=old.relative_to(R).as_posix(),tofile=(F/'component.cc').relative_to(R).as_posix())),encoding='utf8')
A=C/'build1';oldargs=b.args(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json');cmd=[oldargs[0],'/I'+str(F),'/I'+str(F/'include'),'/I'+str(R)];skip=False
for word in oldargs[1:]:
 if skip:skip=False;continue
 if word=='/sourceDependencies':skip=True;continue
 low=word.lower().replace('\\','/')
 if low.startswith(('/fo','/fd')) or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(word)
cmd+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(F/'component.cc'),'/Fo'+str(A/'compile/component.obj'),'/Fd'+str(A/'compile/component.pdb')]
save(C/'planned-compile.json',dict(argv=cmd,cwd=str(R),executed=False))
base=b.args(R/'.scratch/nf4-packed-contraction-20261025/component3/link/command.json');replace={str(R/'.scratch/nf4-packed-contraction-20261025/component3/compile/component.obj'):str(A/'compile/component.obj')}
core=[]
for kind,expected,nbytes in [('budget','c7895c54bd0ddc99b9badd0acaabd026af318658056c37fa6465c81719b68f69',245205),('leases','7689336cef6bb036007c41003f39b1ff513dc597f6d9ddd48ebdc688a8b0bd4c',463196),('arena','a4fec250a87cc07472d43fe19d08d5b93cc939633c028d6bf164a291260b11f1',1142006)]:
 p=R/'.scratch/inference-cache-shared-source-20261025/attempt1'/kind/'unit.obj';v=pin(p);assert v['sha256']==expected and v['bytes']==nbytes
 if kind in ('budget','leases'):
  candidates=[str(R/'.scratch/engine-product-20261024/cpu-budget-fix1'/kind/(kind+'.obj'))]
  if kind=='budget':candidates.append(str(R/'.scratch/inference-shared-requested-budget-20261025/attempt1/core/unit.obj'))
  matches=[x for x in candidates if x in base]
 else:matches=[x for x in base if x.lower().replace('\\','/').endswith('/compute_batch--paged_arena.obj')]
 assert len(matches)==1,(kind,matches);replace[matches[0]]=str(p)
 deps=p.parent/'repository-inputs.json';core.append(dict(kind=kind,object=v,actual_repository_inputs=pin(deps),original_command=pin(p.parent/'command.json')))
assert all(base.count(x)==1 for x in replace)
link=[replace.get(x,x)for x in base if not x.lower().startswith(('/out:','/pdb:','/map:','/implib:'))]
missing=[]
for x in link[1:]:
 if Path(x).is_absolute()and x.lower().endswith(('.obj','.lib'))and x!=str(A/'compile/component.obj')and not Path(x).is_file():missing.append(x)
assert not missing,missing
link+=['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')]
save(C/'planned-link.json',dict(argv=link,cwd=str(R),executed=False,exact_replacements=replace,core_inputs=core))
pins=[pin(p)for p in sorted(F.rglob('*'))if p.is_file()]
save(C/'frozen-pins.json',pins)
save(C/'execution-plan.json',dict(status='SOURCE_ORACLE_AND_EXACT_1TU_CLOSURE_FROZEN_NOT_COMPILED_NOT_RUN',source_baseline=pin(old),source_index=pin(W/'source-roles.json'),source_pins=pin(C/'frozen-pins.json'),reference=pin(C/'reference.py'),prepared_reference=pin(C/'reference-prepared/summary.json'),compile=pin(C/'planned-compile.json'),link=pin(C/'planned-link.json'),GPU_authorized=False,HTTP_authorized=False,SDK_rebuild=False,planned_native_processes=1,planned_native_argv=[str(A/'link/component.exe'),'--run',str(R),str(C/'actual-run1/results')],runtime_source='.scratch/mtp-performance-convergence-20261025/baseline/runtime.json',native_DLL_source='.scratch/mtp-performance-convergence-20261025/baseline/link/hyle_ggml_cpu_gdn_scale_v3.dll',native_limit_seconds=120,postprocess_argv=[sys.executable,str(C/'reference.py'),'--audit',str(C/'actual-run1/results')],input_scope='Two frozen generated hidden inputs; original actual router IDs equal in both episodes and both artifacts. No alternate seed or experts.',math_scope='Dense genuine source, no sparse exact substitution. A32 and BF16 dense use independent complete F64 dots/arbitrary-F32-order intervals; K512 complete integer dot and original BF16 checkpoints; stage references conditional on validated actual predecessors. Not a bitwise full-model oracle.',source_scope='261 fixed typed roles/76 exact cached parts. SHA verified before use; no expanded bank, network or wholeLFS claim.',lifecycle_scope='Existing same seven-bank CudaSupply/WeightSlots, two generations per codec, readonly-old-output checks, busy retained batch refusal, rejected final-bank binding followed by original complete execution.',outputs=dict(raw_stage_bytes=2088192,expert_outputs_per_episode=dict(Quark=13,K512=12),router_outputs_per_episode=7),core_inputs=core))
print(json.dumps(dict(status='FROZEN_NO_BUILD_GPU_HTTP',files=len(pins),source_sha256=pin(F/'component.cc')['sha256'],plan_sha256=pin(C/'execution-plan.json')['sha256'],core_replacements=3,link_input_count=len(base))))
