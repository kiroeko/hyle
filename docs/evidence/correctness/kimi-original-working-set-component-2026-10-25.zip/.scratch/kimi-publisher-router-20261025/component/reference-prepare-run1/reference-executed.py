"""Independent original-byte equations. Never imports a Hyle codec/kernel.
Cold preparation is CPU-only; audit is conditional on already checked actual
predecessors, not a bitwise full-model oracle or quality/performance claim.
"""
from pathlib import Path
import argparse, hashlib, json, os, sys, time
os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
os.environ.setdefault('OMP_NUM_THREADS','4')
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
WORK=ROOT/'.scratch/kimi-publisher-router-20261025'
COMP=WORK/'component'
P='language_model.model.layers.1.block_sparse_moe.'
H,E,S,L,I,SH=7168,896,16,3584,3072,6144
IDS=np.array([220,210,79,156,404,593,444,305,365,731,634,250,366,260,878,619],dtype=np.int32)
MAG=np.array([0,.5,1,1.5,2,3,4,6],dtype=np.float64)
U32=np.float64(2.0**-24);U64=np.float64(2.0**-53)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bf_bits(x):
    y=np.asarray(x,dtype=np.float32);u=y.view(np.uint32)
    return ((u+np.uint32(0x7fff)+((u>>16)&1))>>16).astype(np.uint16)
def wide(bits):return (np.asarray(bits,dtype=np.uint16).astype(np.uint32)<<16).view(np.float32)
def bf(x):return wide(bf_bits(x))
def f32(x):return np.asarray(x,dtype=np.float32)
def gamma(n,u=U32):return n*u/(1-n*u)
def finite(x,where):
    if not np.all(np.isfinite(x)):raise ValueError('nonfinite '+where)
    return x
class Source:
    def __init__(self):
        self.index=json.loads((WORK/'source-roles.json').read_bytes())
        self.roles={(x['catalog_index'],x['name']):x for x in self.index['roles']}
        self.checked=set()
    def role(self,cat,name):return self.roles[cat,name]
    def raw(self,cat,name):
        r=self.role(cat,name); pieces=r['pieces']
        if len(pieces)==1:
            p=pieces[0];out=np.memmap(ROOT/p['path'],dtype=np.uint8,mode='r',offset=p['offset'],shape=(p['bytes'],))
        else:
            out=np.empty(r['bytes'],np.uint8);cursor=0
            for p in pieces:
                view=np.memmap(ROOT/p['path'],dtype=np.uint8,mode='r',offset=p['offset'],shape=(p['bytes'],))
                out[cursor:cursor+p['bytes']]=view;cursor+=p['bytes']
            assert cursor==r['bytes']
        if (cat,name) not in self.checked:
            assert hashlib.sha256(out).hexdigest()==r['role_sha256'],name
            self.checked.add((cat,name))
        return out
    def array(self,cat,name):
        r=self.role(cat,name);types={'BF16':'<u2','U8':'u1','I32':'<u4','I64':'<i8','F32':'<f4','F8_E4M3':'u1'}
        return self.raw(cat,name).view(types[r['dtype']]).reshape(r['physical_shape'])
def activation(epoch):
    a=np.resize(np.array([1,2,-.75,-1],dtype=np.float32),H)
    for j in range(17):a[j]=(2+((16-j) if epoch else j)/8)/64
    return bf(a)
def dense_reference(x,wb):
    # All BF16 products are exact in F32; bound arbitrary F32 sum order.
    x=np.asarray(x,dtype=np.float64);n,k=wb.shape;assert x.shape==(k,)
    center=np.empty(n,np.float64);error=np.empty(n,np.float64)
    for row in range(0,n,128):
        w=wide(wb[row:row+128]).astype(np.float64)
        finite(w,'original BF16 W');c=w@x;s=np.abs(w)@np.abs(x)
        center[row:row+128]=c
        error[row:row+128]=(gamma(k-1)+gamma(k,U64))*s+np.ldexp(float(k),-126)
    return center,error
def a32_activation(x):
    a=np.asarray(x,np.float32).reshape(-1,32);maximum=np.max(np.abs(a),axis=1)
    fraction,exponent=np.frexp(maximum.astype(np.float64))
    exp=np.clip(exponent-np.where(fraction>=.875,2,3),-127,127)
    exp=np.where(maximum==0,-127,exp)
    scale=np.ldexp(np.ones(len(exp),np.float64),exp).astype(np.float32)
    normalized=bf(a.astype(np.float64)/scale[:,None])
    # Ascending code enumeration with even-code tie preference, independent of
    # product bitmask/packed quantizer. Preserve negative zero sign.
    distance=np.abs(np.abs(normalized.astype(np.float64))[:,:,None]-MAG)
    best=np.zeros(normalized.shape,np.int64);current=distance[:,:,0]
    for code in range(1,8):
        update=(distance[:,:,code]<current)|((distance[:,:,code]==current)&((code&1)==0))
        best=np.where(update,code,best);current=np.where(update,distance[:,:,code],current)
    q=np.copysign(MAG[best],normalized)
    return bf(q*scale[:,None]).reshape(-1)
def mx_reference(x,w,sf):
    # Temporary row tiles only, no persistent decoded source bank.
    a=a32_activation(x).astype(np.float64);n,k2=w.shape;k=k2*2
    assert a.shape==(k,) and sf.shape==(n,k//32)
    assert np.all(sf<255),'undefined E8M0 source sentinel'
    center=np.empty(n,np.float64);error=np.empty(n,np.float64)
    for row in range(0,n,64):
        tile=w[row:row+64];codes=np.empty((len(tile),k),np.uint8)
        codes[:,0::2]=tile&15;codes[:,1::2]=tile>>4
        signed=np.where((codes&8)!=0,-MAG[codes&7],MAG[codes&7])
        scales=np.repeat(sf[row:row+64].astype(np.int16)-127,32,axis=1)
        decoded=bf(np.ldexp(signed,scales)).astype(np.float64)
        finite(decoded,'original MX W');c=decoded@a;s=np.abs(decoded)@np.abs(a)
        center[row:row+64]=c;error[row:row+64]=(gamma(k-1)+gamma(k,U64))*s+np.ldexp(float(k),-126)
    return center,error
def k512_reference(x,w,sf):
    # Complete I64 dot for every512 group, then original BF16 checkpoints.
    a=np.asarray(x,np.float32);n,k8=w.shape;k=k8*8
    assert a.shape==(k,) and sf.shape==(n,k//512)
    result=np.zeros(n,np.float32);domain_count=0;max_qa=0
    for group in range(k//512):
        block=a[group*512:(group+1)*512]
        scale=bf(np.max(np.abs(block)).astype(np.float64)*.00787353515625)
        inverse=bf(0 if scale==0 else 1/float(scale))
        qa=np.trunc(bf(block.astype(np.float64)*float(inverse))).astype(np.int64)
        assert np.all((qa>=-128)&(qa<=127)),'undefined original K512 I8 input'
        max_qa=max(max_qa,int(np.max(np.abs(qa))));domain_count+=len(qa)
        for row in range(0,n,128):
            tile=w[row:row+128,group*64:(group+1)*64]
            codes=((tile[:,:,None]>>(np.arange(8,dtype=np.uint32)*4))&15).astype(np.int64).reshape(len(tile),512)-8
            total=codes@qa
            dot=bf(total.astype(np.float64))
            first=bf(dot.astype(np.float64)*float(scale))
            weightscale=bf(sf[row:row+128,group])
            value=bf(first.astype(np.float64)*weightscale.astype(np.float64))
            result[row:row+128]=bf(result[row:row+128].astype(np.float64)+value.astype(np.float64))
    return result,dict(activation_I8_values=domain_count,max_abs_I8=max_qa)
def e4decode(code):
    code=np.asarray(code,np.uint8);mag=code&127;exponent=mag>>3;fraction=mag&7
    result=np.where(exponent==0,np.ldexp(fraction.astype(np.float64),-9),np.ldexp(1+fraction.astype(np.float64)/8,exponent.astype(np.int16)-7))
    result=np.where((code&128)!=0,-result,result)
    return np.where(mag==127,np.nan,result).astype(np.float32)
def e4encode(x):
    x=np.asarray(x,np.float32);m=np.abs(x.astype(np.float64));table=e4decode(np.arange(127,dtype=np.uint8)).astype(np.float64)
    low=np.clip(np.searchsorted(table,m,side='right')-1,0,126)
    high=np.minimum(low+1,126);dl=m-table[low];dh=table[high]-m
    code=np.where((dh<dl)|((dh==dl)&((low&1)!=0)),high,low)
    code=np.where(m>=448,126,code).astype(np.uint8)
    return code|(np.signbit(x).astype(np.uint8)<<7)
def fp8_reference(x,w,sf):
    literal=np.array([0x3b124925],np.uint32).view(np.float32)[0]
    scale=f32(float(np.max(np.abs(x)))*float(literal));inverse=f32(1/float(scale))
    a=e4decode(e4encode(f32(x.astype(np.float64)*float(inverse)))).astype(np.float64)
    decoded=e4decode(w).astype(np.float64);center=decoded@a;s=np.abs(decoded)@np.abs(a)
    error=(gamma(H-1)+gamma(H,U64))*s+np.ldexp(float(H),-126)
    low=f32(f32(center-error).astype(np.float64)*sf.astype(np.float64));high=f32(f32(center+error).astype(np.float64)*sf.astype(np.float64))
    lower=np.minimum(low,high);upper=np.maximum(low,high)
    low=f32(lower.astype(np.float64)*float(scale));high=f32(upper.astype(np.float64)*float(scale))
    return low.astype(np.float64),high.astype(np.float64),dict(token_scale=float(scale),channel_scale_min=float(sf.min()),channel_scale_max=float(sf.max()))
def stage_projection(source,cat,name,x):
    if cat==23 and ('experts.' in name or 'shared_experts.' in name):
        return mx_reference(x,source.array(cat,name+'.weight'),source.array(cat,name+'.weight_scale'))
    return dense_reference(x,source.array(cat,name+'.weight'))
def save_reference(folder,label,center,error):
    np.savez(folder/(label+'.npz'),center=center,error=error)
    return dict(values=len(center),center_min=float(center.min()),center_max=float(center.max()),maximum_accumulation_error_bound=float(error.max()),file=label+'.npz')
def prepare():
    target=COMP/'reference-prepared'
    if target.exists():raise ValueError('refuse to overwrite CPU reference preparation')
    target.mkdir(parents=True);source=Source();records=[];started=time.time()
    for cat in (23,24):
        gamma_weight=wide(source.array(cat,P+'routed_expert_norm.weight'))
        finite(gamma_weight,'source norm gamma')
        for epoch in (0,1):
            x=activation(epoch);prefix=f'catalog{cat}-epoch{epoch}'
            xbits=bf_bits(x);xbits.tofile(target/(prefix+'-input.bf16'))
            for label,suffix in [('latent','routed_expert_down_proj'),('shared_gate','shared_experts.gate_proj'),('shared_up','shared_experts.up_proj')]:
                c,e=stage_projection(source,cat,P+suffix,x)
                records.append(dict(catalog=cat,epoch=epoch,stage=label,**save_reference(target,prefix+'-'+label,c,e)))
            if cat==23:
                lo,hi,extra=fp8_reference(x,source.array(cat,'language_model.model.layers.1.self_attn.f_a_proj.weight'),source.array(cat,'language_model.model.layers.1.self_attn.f_a_proj.weight_scale'))
                np.savez(target/(prefix+'-fp8.npz'),low=lo,high=hi)
                records.append(dict(catalog=cat,epoch=epoch,stage='independent_fp8',values=128,**extra))
    result=dict(status='CPU_INDEPENDENT_STATIC_REFERENCE_PREPARED_NO_COMPONENT_GPU',seconds=time.time()-started,numpy=np.__version__,script_sha256=sha(__file__),source_index_sha256=sha(WORK/'source-roles.json'),records=records,source_roles_authenticated=len(source.checked),policy='F64 complete dot; arbitrary F32 accumulation gamma(K-1); BF16 RNE endpoint interval. A32 activation/weight decoding enumerated independently. No Hyle codec, sparse oracle or full-model quality claim.',postrun_conditional='Expert/down/combine/norm/routed/shared-down/final use previously validated actual predecessors; K512 complete integer dots and original BF16 checkpoints. All numerical gates frozen before actual component execution.')
    (target/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(status=result['status'],records=len(records),seconds=result['seconds'])))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');args=p.parse_args()
    if args.prepare:prepare()
