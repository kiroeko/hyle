from pathlib import Path
import json,hashlib,importlib.util,os,sys
R=Path.cwd();C=R/'.scratch/kimi-publisher-router-20261025/component';A=C/'build2'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
plan=load(C/'execution-plan2.json');assert plan['status']=='CORRECTED_FROZEN_PLAN_RETRY_PRIVATE_W4_SHADOW_AND_FINITE_AUDIT_ONLY_NO_GPU'
for v in load(C/'frozen-pins.json'):
 p=R/v['path'];assert pin(p)==v,v['path']
for v in load(C/'corrected-pins.json'):
 p=R/v['path'];assert pin(p)==v,v['path']
for key in ('compile','link'):
 v=plan[key];assert pin(R/v['path'])==v
A.mkdir(exist_ok=False)
b.save(A/'before.json',dict(execution_plan=pin(C/'execution-plan2.json'),source_pins=pin(C/'frozen-pins.json'),reference=pin(C/'reference.py'),core_inputs=plan['core_inputs'],GPU=False,HTTP=False,SDK_rebuild=False))
compile=load(C/'planned-compile2.json')['argv'];env=b.environment(compile[0]);b.execute(compile,A/'compile',env,120)
linkplan=load(C/'planned-link2.json');link=linkplan['argv']
for v in plan['core_inputs']:
 p=R/v['object']['path'];assert pin(p)==v['object']
b.execute(link,A/'link',env,120)
native=R/plan['native_DLL_source'];os.link(native,A/'link'/native.name)
b.save(A/'summary.json',dict(status='ONE_ENTRY_TU_COMPILED_LINKED_READY_NO_GPU_HTTP',compile=b.read(A/'compile/process.json'),link=b.read(A/'link/process.json'),execution_plan=pin(C/'execution-plan2.json'),source=pin(C/'frozen2/component.cc'),image=pin(A/'link/component.exe'),native=pin(native),exact_link_replacements=linkplan['exact_replacements'],GPU_started=False,SDK_rebuilt=False,compiler_TUs=1))
print(json.dumps(b.read(A/'summary.json')))
