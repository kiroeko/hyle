from pathlib import Path
import json,hashlib,copy
R=Path.cwd();C=R/'.scratch/kimi-publisher-router-20261025/component';F=C/'frozen2';F.mkdir(exist_ok=False);A1=C/'build1';A2=C/'build2'
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
s=(C/'frozen/component.cc').read_text(encoding='utf8');old='for (const auto &source : sources)\n    for (const auto &hash : source->hashes)';new='for (const auto &selected_source : sources)\n    for (const auto &hash : selected_source->hashes)';assert s.count(old)==1;s=s.replace(old,new);(F/'component.cc').write_bytes((C/'frozen/component.cc').read_bytes().replace(b'for (const auto &source : sources)',b'for (const auto &selected_source : sources)').replace(b'source->hashes',b'selected_source->hashes'))
for name in ('original_source.h','original_roles.h'):(F/name).write_bytes((C/'frozen'/name).read_bytes())
p=C/'reference.py';s=p.read_text(encoding='utf8')
s=s.replace('def exact_check(label,actual,expected,details=None):\n    a=','def exact_check(label,actual,expected,details=None):\n    finite(actual,label+\' actual\');finite(expected,label+\' expected\')\n    a=')
s=s.replace('def situ_check(label,actual,gate,up):\n    x=','def situ_check(label,actual,gate,up):\n    finite(actual,label+\' actual\');finite(gate,label+\' gate\');finite(up,label+\' up\')\n    x=')
s=s.replace('    error=np.abs(np.asarray(actual,dtype=np.float64)-ref.astype(np.float64));bad=',"    finite(ref,label+' reference');finite(tolerance,label+' tolerance')\n    error=np.abs(np.asarray(actual,dtype=np.float64)-ref.astype(np.float64));bad=")
assert s.count("finite(actual,label+' actual');finite(expected,label+' expected')")==1
assert s.count("finite(actual,label+' actual');finite(gate,label+' gate');finite(up,label+' up')")==1
assert s.count("finite(ref,label+' reference');finite(tolerance,label+' tolerance')")==1
p.write_text(s,encoding='utf8');(F/'reference.py').write_bytes(p.read_bytes())
plan=json.loads((C/'execution-plan.json').read_bytes());oldcompile=json.loads((C/'planned-compile.json').read_bytes());oldlink=json.loads((C/'planned-link.json').read_bytes())
compile=[]
for x in oldcompile['argv']:
 x=x.replace(str(A1),str(A2))
 if x==str(C/'frozen/component.cc'):x=str(F/'component.cc')
 compile.append(x)
compile.insert(1,'/I'+str(F))
link=[x.replace(str(A1),str(A2))for x in oldlink['argv']]
replacements={x:y.replace(str(A1),str(A2))for x,y in oldlink['exact_replacements'].items()}
save(C/'planned-compile2.json',dict(argv=compile,cwd=str(R),executed=False))
save(C/'planned-link2.json',dict(argv=link,cwd=str(R),executed=False,exact_replacements=replacements,core_inputs=oldlink['core_inputs']))
pins=[pin(p)for p in sorted(F.iterdir())if p.is_file()];save(C/'corrected-pins.json',pins)
plan['status']='CORRECTED_FROZEN_PLAN_RETRY_PRIVATE_W4_SHADOW_AND_FINITE_AUDIT_ONLY_NO_GPU'
plan['prior_plan']=pin(C/'execution-plan.json');plan['retained_first_compile_failure']=pin(A1/'compile/process.json');plan['correction_scope']='C++ report loop variable source -> selected_source only; oracle rejects nonfinite inputs/reference/tolerance explicitly without changing any finite-value formula or tolerance. No reference recomputation.'
plan['source_pins']=pin(C/'corrected-pins.json');plan['base_unchanged_header_pins']=pin(C/'frozen-pins.json');plan['reference']=pin(C/'reference.py');plan['compile']=pin(C/'planned-compile2.json');plan['link']=pin(C/'planned-link2.json');plan['planned_native_argv'][0]=str(A2/'link/component.exe')
save(C/'execution-plan2.json',plan)
save(C/'corrected-source-delta.json',dict(initial_compile_failure=pin(A1/'compile/process.json'),initial_stdout=pin(A1/'compile/stdout.log'),original_reference=pin(C/'frozen/reference.py'),corrected_reference=pin(C/'reference.py'),original_cpp=pin(C/'frozen/component.cc'),corrected_cpp=pin(F/'component.cc'),finite_numerical_formulas_or_gates_changed=False,static_references_recomputed=False,GPU=False,HTTP=False))
print(json.dumps(dict(source=pin(F/'component.cc'),reference=pin(C/'reference.py'),plan=pin(C/'execution-plan2.json'))))
