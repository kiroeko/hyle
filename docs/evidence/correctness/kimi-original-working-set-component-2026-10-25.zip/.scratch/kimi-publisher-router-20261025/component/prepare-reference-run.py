from pathlib import Path
import json,sys,subprocess,time,hashlib
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025/component';D=W/'reference-prepare-run1';D.mkdir(exist_ok=False)
cmd=[sys.executable,str(W/'reference.py'),'--prepare']
(D/'command.json').write_text(json.dumps(dict(argv=cmd,cwd=str(R)),indent=2)+'\n')
t=time.time();p=subprocess.run(cmd,cwd=R,capture_output=True,timeout=600)
(D/'stdout.log').write_bytes(p.stdout);(D/'stderr.log').write_bytes(p.stderr)
(D/'process.json').write_text(json.dumps(dict(exit_code=p.returncode,seconds=time.time()-t,source_sha256=hashlib.sha256((W/'reference.py').read_bytes()).hexdigest(),GPU=False,HTTP=False),indent=2)+'\n')
print(p.stdout.decode('utf8',errors='replace'));print(p.stderr.decode('utf8',errors='replace'));sys.exit(p.returncode)
