from pathlib import Path
import sys,importlib.util,json,os,hashlib
sys.dont_write_bytecode=True
R=Path.cwd();C=R/'.scratch/kimi-publisher-router-20261025/component';A=C/'build2'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
plan=b.read(C/'execution-plan2.json');summary=b.read(A/'summary.json');exe=R/summary['image']['path'];assert pin(exe)==summary['image'];assert pin(R/summary['source']['path'])==summary['source']
assert pin(C/'reference.py')==plan['reference']
assert (C/'reference.py').read_bytes()==(C/'frozen2/reference.py').read_bytes()
assert not(C/'actual-run1').exists();runtime=R/plan['runtime_source'];env=os.environ.copy();env['PATH']=str(exe.parent)+os.pathsep+b.read(runtime)['PATH']
b.save(C/'actual-run-plan.json',dict(status='FROZEN_BEFORE_UNIQUE_AUTHENTIC_COMPONENT_PROCESS',command=plan['planned_native_argv'],source=summary['source'],image=summary['image'],reference=pin(C/'reference.py'),source_index=pin(R/'.scratch/kimi-publisher-router-20261025/source-roles.json'),runtime=pin(runtime),prior_plan=pin(C/'execution-plan2.json'),native_processes=1,watchdog_seconds=120,HTTP=False))
b.execute(plan['planned_native_argv'],C/'actual-run1',env,120)
rows=[json.loads(s)for s in(C/'actual-run1/stdout.log').read_text().splitlines()if s.startswith('{')];assert len(rows)==2
b.save(C/'actual-run1/result.json',dict(status='AUTHENTIC_COMPONENT_NATIVE_LIFECYCLE_PASS_PENDING_INDEPENDENT_CPU_AUDIT',process=b.read(C/'actual-run1/process.json'),rows=rows,image=summary['image'],source=summary['source'],GPU_released=True))
print(json.dumps(dict(status='NATIVE_LIFECYCLE_PASS_PENDING_CPU_AUDIT',GPU_released=True,codecs=len(rows),process=b.read(C/'actual-run1/process.json'))))
