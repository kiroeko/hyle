#pragma once
#include "original_roles.h"
#include "engine/inference/artifact_digest.h"
#include "hyle/mem/buffer.h"
#include <filesystem>
#include <fstream>
#include <map>
#include <limits>
#include <vector>
#include <stdexcept>
#include <string>
namespace original_kimi_roles {
// Cold byte transport only. Values stay in the original encoding; no numerical
// decoder, device selection, expert scheduling or persistent floating bank.
class Source final {
  std::filesystem::path root_;
  std::map<std::pair<int, std::string>, hyle::mem::Buffer> buffers_;

public:
  explicit Source(std::filesystem::path root) : root_(std::move(root)) {}
  const Role &role(int catalog, std::string_view name) const {
    for (const auto &r : roles)
      if (r.catalog == catalog && r.name == name)
        return r;
    throw std::runtime_error("uncached original role: " +
                             std::to_string(catalog) + ":" + std::string(name));
  }
  hyle::compute::TensorDesc description(int catalog,
                                        std::string_view name) const {
    const auto &r = role(catalog, name);
    auto d = c::TensorDesc::dense(r.type, std::span(r.shape).first(r.rank));
    if (!d || !d->required_bytes() || *d->required_bytes() != r.bytes)
      throw std::runtime_error("original descriptor extent differs");
    return *d;
  }
  const hyle::mem::Buffer &buffer(int catalog, std::string_view name) {
    const auto key = std::pair{catalog, std::string(name)};
    if (auto it = buffers_.find(key); it != buffers_.end())
      return it->second;
    const auto &r = role(catalog, name);
    std::vector<std::byte> payload(r.bytes);
    std::size_t cursor = 0;
    for (const auto &piece : r.pieces) {
      if (piece.bytes > payload.size() - cursor)
        throw std::runtime_error("original piece overflow");
      std::ifstream in(root_ / std::filesystem::path(piece.path),
                       std::ios::binary);
      if (!in || piece.offset >
                     std::size_t(std::numeric_limits<std::streamoff>::max()))
        throw std::runtime_error("original piece file/offset invalid");
      in.seekg(static_cast<std::streamoff>(piece.offset));
      in.read(reinterpret_cast<char *>(payload.data() + cursor),
              static_cast<std::streamsize>(piece.bytes));
      if (in.gcount() != static_cast<std::streamsize>(piece.bytes))
        throw std::runtime_error("original piece short read");
      cursor += piece.bytes;
    }
    if (cursor != payload.size() ||
        hyle::inference::artifact::sha256(payload) != r.sha256)
      throw std::runtime_error("original role SHA mismatch");
    auto storage = hyle::mem::Buffer::create(hyle::mem::system_resource(),
                                             payload.size(), 256);
    if (!storage)
      throw std::runtime_error(std::string(storage.error().message()));
    auto status = storage->view().write(payload);
    if (!status.ok())
      throw std::runtime_error(std::string(status.message()));
    return buffers_.emplace(key, std::move(*storage)).first->second;
  }
  std::vector<std::byte> bytes(int catalog, std::string_view name) {
    const auto &r = role(catalog, name);
    std::vector<std::byte> result(r.bytes);
    auto status = buffer(catalog, name).view().read(result);
    if (!status.ok())
      throw std::runtime_error(std::string(status.message()));
    return result;
  }
};
} // namespace original_kimi_roles
