#pragma once
#include <array>
#include <span>
#include <string_view>
#include "hyle/compute/tensor_desc.h"
namespace original_kimi_roles {
namespace c=hyle::compute;
struct Piece {std::string_view path;std::size_t offset,bytes;};
struct Role {int catalog;std::string_view name;c::DataType type;std::array<std::int64_t,2> shape;std::size_t rank,bytes;std::string_view sha256;std::span<const Piece> pieces;};
inline constexpr std::array<Piece,1> p0{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-000.bin",0,512},
}};
inline constexpr std::array<Piece,1> p1{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-001.bin",0,51380224},
}};
inline constexpr std::array<Piece,1> p2{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-001.bin",51380224,7168},
}};
inline constexpr std::array<Piece,2> p3{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-001.bin",51387392,15721472},
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-002.bin",0,35658752},
}};
inline constexpr std::array<Piece,1> p4{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-003.bin",0,917504},
}};
inline constexpr std::array<Piece,1> p5{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-004.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p6{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-004.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p7{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-004.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p8{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-004.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p9{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-004.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p10{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-004.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p11{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-005.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p12{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-005.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p13{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-005.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p14{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-005.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p15{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-005.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p16{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-005.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p17{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-006.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p18{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-006.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p19{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-006.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p20{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-006.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p21{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-006.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p22{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-006.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p23{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-007.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p24{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-007.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p25{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-007.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p26{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-007.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p27{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-007.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p28{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-007.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p29{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-008.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p30{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-008.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p31{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-008.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p32{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-008.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p33{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-008.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p34{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-008.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p35{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-009.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p36{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-009.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p37{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-009.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p38{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-009.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p39{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-009.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p40{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-009.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p41{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p42{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p43{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p44{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p45{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p46{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p47{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",17547264,5505024},
}};
inline constexpr std::array<Piece,1> p48{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",23052288,344064},
}};
inline constexpr std::array<Piece,1> p49{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",23396352,5505024},
}};
inline constexpr std::array<Piece,1> p50{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",28901376,344064},
}};
inline constexpr std::array<Piece,1> p51{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",29245440,5505024},
}};
inline constexpr std::array<Piece,1> p52{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-010.bin",34750464,344064},
}};
inline constexpr std::array<Piece,1> p53{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-011.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p54{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-011.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p55{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-011.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p56{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-011.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p57{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-011.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p58{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-011.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p59{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-012.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p60{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-012.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p61{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-012.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p62{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-012.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p63{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-012.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p64{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-012.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p65{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-013.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p66{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-013.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p67{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-013.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p68{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-013.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p69{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-013.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p70{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-013.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p71{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-014.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p72{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-014.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p73{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-014.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p74{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-014.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p75{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-014.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p76{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-014.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p77{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-015.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p78{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-015.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p79{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-015.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p80{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-015.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p81{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-015.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p82{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-015.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p83{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-016.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p84{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-016.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p85{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-016.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p86{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-016.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p87{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-016.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p88{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-016.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p89{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-017.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p90{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-017.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p91{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-017.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p92{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-017.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p93{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-017.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p94{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-017.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p95{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-018.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p96{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-018.bin",5505024,344064},
}};
inline constexpr std::array<Piece,1> p97{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-018.bin",5849088,5505024},
}};
inline constexpr std::array<Piece,1> p98{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-018.bin",11354112,344064},
}};
inline constexpr std::array<Piece,1> p99{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-018.bin",11698176,5505024},
}};
inline constexpr std::array<Piece,1> p100{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-018.bin",17203200,344064},
}};
inline constexpr std::array<Piece,1> p101{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-019.bin",0,22020096},
}};
inline constexpr std::array<Piece,1> p102{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-019.bin",22020096,1376256},
}};
inline constexpr std::array<Piece,1> p103{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-019.bin",23396352,22020096},
}};
inline constexpr std::array<Piece,1> p104{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-019.bin",45416448,1376256},
}};
inline constexpr std::array<Piece,2> p105{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-019.bin",46792704,20316160},
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-020.bin",0,1703936},
}};
inline constexpr std::array<Piece,1> p106{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-020.bin",1703936,1376256},
}};
inline constexpr std::array<Piece,1> p107{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-021.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p108{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-021.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p109{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-021.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p110{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-022.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p111{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-022.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p112{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-022.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p113{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-023.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p114{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-023.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p115{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-023.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p116{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-024.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p117{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-024.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p118{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-024.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p119{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-025.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p120{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-025.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p121{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-025.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p122{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-026.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p123{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-026.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p124{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-026.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p125{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-027.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p126{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-027.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p127{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-027.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p128{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-027.bin",258048,86016},
}};
inline constexpr std::array<Piece,1> p129{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-027.bin",344064,86016},
}};
inline constexpr std::array<Piece,1> p130{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-027.bin",430080,86016},
}};
inline constexpr std::array<Piece,1> p131{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-028.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p132{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-028.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p133{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-028.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p134{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-029.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p135{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-029.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p136{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-029.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p137{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-030.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p138{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-030.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p139{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-030.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p140{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-031.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p141{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-031.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p142{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-031.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p143{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-032.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p144{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-032.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p145{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-032.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p146{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-033.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p147{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-033.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p148{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-033.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p149{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-034.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p150{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-034.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p151{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-034.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p152{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-035.bin",0,86016},
}};
inline constexpr std::array<Piece,1> p153{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-035.bin",86016,86016},
}};
inline constexpr std::array<Piece,1> p154{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-035.bin",172032,86016},
}};
inline constexpr std::array<Piece,1> p155{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-036.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p156{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-036.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p157{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-036.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p158{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-037.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p159{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-037.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p160{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-037.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p161{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-038.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p162{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-038.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p163{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-038.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p164{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-039.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p165{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-039.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p166{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-039.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p167{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-040.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p168{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-040.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p169{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-040.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p170{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-041.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p171{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-041.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p172{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-041.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p173{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-042.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p174{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-042.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p175{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-042.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p176{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-042.bin",16515072,5505024},
}};
inline constexpr std::array<Piece,1> p177{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-042.bin",22020096,5505024},
}};
inline constexpr std::array<Piece,1> p178{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-042.bin",27525120,5505024},
}};
inline constexpr std::array<Piece,1> p179{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-043.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p180{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-043.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p181{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-043.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p182{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-044.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p183{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-044.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p184{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-044.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p185{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-045.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p186{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-045.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p187{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-045.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p188{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-046.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p189{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-046.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p190{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-046.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p191{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-047.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p192{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-047.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p193{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-047.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p194{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-048.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p195{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-048.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p196{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-048.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p197{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-049.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p198{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-049.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p199{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-049.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p200{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-050.bin",0,5505024},
}};
inline constexpr std::array<Piece,1> p201{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-050.bin",5505024,5505024},
}};
inline constexpr std::array<Piece,1> p202{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-050.bin",11010048,5505024},
}};
inline constexpr std::array<Piece,1> p203{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-051.bin",0,51380224},
}};
inline constexpr std::array<Piece,1> p204{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-051.bin",51380224,7168},
}};
inline constexpr std::array<Piece,2> p205{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-051.bin",51387392,15721472},
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-052.bin",0,35658752},
}};
inline constexpr std::array<Piece,2> p206{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-052.bin",35658752,31450112},
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-053.bin",0,56630272},
}};
inline constexpr std::array<Piece,3> p207{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-053.bin",56630272,10478592},
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-054.bin",0,67108864},
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-055.bin",0,10492928},
}};
inline constexpr std::array<Piece,2> p208{{
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-055.bin",10492928,56615936},
{".scratch/kimi-publisher-router-20261025/bulk-payload/range-056.bin",0,31464448},
}};
inline constexpr std::array<Piece,1> p209{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-00.bin",0,16},
}};
inline constexpr std::array<Piece,1> p210{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-00.bin",16,16},
}};
inline constexpr std::array<Piece,1> p211{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-00.bin",32,16},
}};
inline constexpr std::array<Piece,1> p212{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-01.bin",0,16},
}};
inline constexpr std::array<Piece,1> p213{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-01.bin",16,16},
}};
inline constexpr std::array<Piece,1> p214{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-01.bin",32,16},
}};
inline constexpr std::array<Piece,1> p215{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-02.bin",0,16},
}};
inline constexpr std::array<Piece,1> p216{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-02.bin",16,16},
}};
inline constexpr std::array<Piece,1> p217{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-02.bin",32,16},
}};
inline constexpr std::array<Piece,1> p218{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-03.bin",0,16},
}};
inline constexpr std::array<Piece,1> p219{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-03.bin",16,16},
}};
inline constexpr std::array<Piece,1> p220{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-03.bin",32,16},
}};
inline constexpr std::array<Piece,1> p221{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-04.bin",0,16},
}};
inline constexpr std::array<Piece,1> p222{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-04.bin",16,16},
}};
inline constexpr std::array<Piece,1> p223{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-04.bin",32,16},
}};
inline constexpr std::array<Piece,1> p224{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-05.bin",0,16},
}};
inline constexpr std::array<Piece,1> p225{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-05.bin",16,16},
}};
inline constexpr std::array<Piece,1> p226{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-05.bin",32,16},
}};
inline constexpr std::array<Piece,1> p227{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-06.bin",0,16},
}};
inline constexpr std::array<Piece,1> p228{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-06.bin",16,16},
}};
inline constexpr std::array<Piece,1> p229{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-06.bin",32,16},
}};
inline constexpr std::array<Piece,1> p230{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-06.bin",48,16},
}};
inline constexpr std::array<Piece,1> p231{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-06.bin",64,16},
}};
inline constexpr std::array<Piece,1> p232{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-06.bin",80,16},
}};
inline constexpr std::array<Piece,1> p233{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-07.bin",0,16},
}};
inline constexpr std::array<Piece,1> p234{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-07.bin",16,16},
}};
inline constexpr std::array<Piece,1> p235{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-07.bin",32,16},
}};
inline constexpr std::array<Piece,1> p236{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-08.bin",0,16},
}};
inline constexpr std::array<Piece,1> p237{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-08.bin",16,16},
}};
inline constexpr std::array<Piece,1> p238{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-08.bin",32,16},
}};
inline constexpr std::array<Piece,1> p239{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-09.bin",0,16},
}};
inline constexpr std::array<Piece,1> p240{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-09.bin",16,16},
}};
inline constexpr std::array<Piece,1> p241{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-09.bin",32,16},
}};
inline constexpr std::array<Piece,1> p242{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-10.bin",0,16},
}};
inline constexpr std::array<Piece,1> p243{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-10.bin",16,16},
}};
inline constexpr std::array<Piece,1> p244{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-10.bin",32,16},
}};
inline constexpr std::array<Piece,1> p245{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-11.bin",0,16},
}};
inline constexpr std::array<Piece,1> p246{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-11.bin",16,16},
}};
inline constexpr std::array<Piece,1> p247{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-11.bin",32,16},
}};
inline constexpr std::array<Piece,1> p248{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-12.bin",0,16},
}};
inline constexpr std::array<Piece,1> p249{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-12.bin",16,16},
}};
inline constexpr std::array<Piece,1> p250{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-12.bin",32,16},
}};
inline constexpr std::array<Piece,1> p251{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-13.bin",0,16},
}};
inline constexpr std::array<Piece,1> p252{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-13.bin",16,16},
}};
inline constexpr std::array<Piece,1> p253{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-13.bin",32,16},
}};
inline constexpr std::array<Piece,1> p254{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-14.bin",0,16},
}};
inline constexpr std::array<Piece,1> p255{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-14.bin",16,16},
}};
inline constexpr std::array<Piece,1> p256{{
{".scratch/kimi-publisher-router-20261025/shape-payload/shape-14.bin",32,16},
}};
inline constexpr std::array<Piece,1> p257{{
{".scratch/kimi-publisher-router-20261025/payload/catalog-23-router.bf16",0,12845056},
}};
inline constexpr std::array<Piece,1> p258{{
{".scratch/kimi-publisher-router-20261025/payload/catalog-23-bias.f32",0,3584},
}};
inline constexpr std::array<Piece,1> p259{{
{".scratch/kimi-publisher-router-20261025/payload/catalog-24-router.bf16",0,12845056},
}};
inline constexpr std::array<Piece,1> p260{{
{".scratch/kimi-publisher-router-20261025/payload/catalog-24-bias.f32",0,3584},
}};
inline constexpr std::array<Role,261> roles{{
{23,"language_model.model.layers.1.self_attn.f_a_proj.weight_scale",c::DataType::kFloat32,{128,0},1,512,"c517e0df2383beae3a00b8c9a0582616be17091bb541b91a05ffd0cbf037c5c6",p0},
{23,"language_model.model.layers.1.block_sparse_moe.routed_expert_down_proj.weight",c::DataType::kBFloat16,{3584,7168},2,51380224,"39bfe48649bd6452944185b32eb6486dbf0552da401c83f5d4f6ef2b3c0a3ca6",p1},
{23,"language_model.model.layers.1.block_sparse_moe.routed_expert_norm.weight",c::DataType::kBFloat16,{3584,0},1,7168,"4f9aaa834cd9c0deb04c14e6d1f092f829b5fb91f8f0a1016b460fb57c561a37",p2},
{23,"language_model.model.layers.1.block_sparse_moe.routed_expert_up_proj.weight",c::DataType::kBFloat16,{7168,3584},2,51380224,"89949f7919a90006dd3c5f5da8e063d7ce023e2549c8dc0ce6a93b78fb4ffe76",p3},
{23,"language_model.model.layers.1.self_attn.f_a_proj.weight",c::DataType::kFloat8E4M3FN,{128,7168},2,917504,"b75a61adc924095df2ad815f34938451be4cd79cd5dd1a695e992bbdcd7b71d7",p4},
{23,"language_model.model.layers.1.block_sparse_moe.experts.156.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"c92400a5d227f670a526e6d0d9ccc802b75d595c259d40c7d128dd0fb37bae97",p5},
{23,"language_model.model.layers.1.block_sparse_moe.experts.156.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"49a9438c39d49bf10d5b5121d8c17efe6f4409a97c8ceaa95fde176b47571dda",p6},
{23,"language_model.model.layers.1.block_sparse_moe.experts.156.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"f831935a9844c1c92ebf87e00ca250cd43d4ce20adc11bb0e288b0a9417c94bd",p7},
{23,"language_model.model.layers.1.block_sparse_moe.experts.156.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"6ce9fdb43f3f4a989942dc5d63f1d3a1b440f4fd455115f045ae18ca1d54f041",p8},
{23,"language_model.model.layers.1.block_sparse_moe.experts.156.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"8a94e80959787eb03fd3bc1c6c81412187d3bcae3ffe81309f9764e3edd2781f",p9},
{23,"language_model.model.layers.1.block_sparse_moe.experts.156.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"48d157bc889bb23b4f4fd50653b85ae3c6941befc89a33122fa792e356dd6752",p10},
{23,"language_model.model.layers.1.block_sparse_moe.experts.210.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"4bb9b931d3d6c5b424bf45c05a72e6da4a67fec7d133a514204088c5f71b7bae",p11},
{23,"language_model.model.layers.1.block_sparse_moe.experts.210.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"d4a0075aee6b8c9db7b90426a42c3f6ae889e989b1d728168ddc51d69ff3b5d5",p12},
{23,"language_model.model.layers.1.block_sparse_moe.experts.210.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"8312dfd6f7ec953a8e397c4648f1bdac67f0b267a05759913e7332ad64c66e23",p13},
{23,"language_model.model.layers.1.block_sparse_moe.experts.210.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"d22cc66825d5dfacb57d0ed50ab98ac5dca6b343b03d3451c434cce3b8a6de71",p14},
{23,"language_model.model.layers.1.block_sparse_moe.experts.210.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"9592eeac6a819dbc523e1d711b2913241403baad1e2a2fcf47f547b132c0a388",p15},
{23,"language_model.model.layers.1.block_sparse_moe.experts.210.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"c99eae92db4568b2d5c5b4f05607881a6c11045bf4d6b6ad40884e7db61069e6",p16},
{23,"language_model.model.layers.1.block_sparse_moe.experts.220.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"56d2cb216b466248b8f299b22e59116dfa663131f4b4ac09a3e881da97a67825",p17},
{23,"language_model.model.layers.1.block_sparse_moe.experts.220.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"f1665ba477041b7f5edb02bf7cfbd899c4abfc067a63222914620c5c1d3e0629",p18},
{23,"language_model.model.layers.1.block_sparse_moe.experts.220.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"0637e3e3dd2985b73f78a3a3cb418e36f135e2ea24d5b5b7cfd7c29a7955ae9a",p19},
{23,"language_model.model.layers.1.block_sparse_moe.experts.220.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"a504a7ba7ae8cdd9d5d0bf7ad9ef0a9b13a7fba770da9e59636e92407342534f",p20},
{23,"language_model.model.layers.1.block_sparse_moe.experts.220.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"cc353255ba1e79c60e55322efee95fc32295dde2f5de5f9cf96afb434142da0d",p21},
{23,"language_model.model.layers.1.block_sparse_moe.experts.220.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"99447959b3d48f748567282963789e7c82f1522d2b3a82868be8dc1dc1f3782b",p22},
{23,"language_model.model.layers.1.block_sparse_moe.experts.250.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"45b840e329c330c800de3bd56a9aa82be8f9e221db4db745bf6b09690794bd7e",p23},
{23,"language_model.model.layers.1.block_sparse_moe.experts.250.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"42fb0e1185bbb72d400351170419f8286148587bc4a6f37e5a4f7efb7559abea",p24},
{23,"language_model.model.layers.1.block_sparse_moe.experts.250.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"d5ddb2cc9b787d26ce07483820443bce7c4513dc653a1191ba1fc4eaf32dc2c0",p25},
{23,"language_model.model.layers.1.block_sparse_moe.experts.250.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"e8819d4cdf865835dbacb28ca9138cfbca811d200ac50742ce4805f6299a321b",p26},
{23,"language_model.model.layers.1.block_sparse_moe.experts.250.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"0808c9933c2b8ae9c24323f4a6d2a8c58d84efa12bb0d39ad55e5a861de81c7b",p27},
{23,"language_model.model.layers.1.block_sparse_moe.experts.250.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"20b625ff51ad92e620110972bc69478cfe9cf67820d8d1b6588c09d6e3e865fd",p28},
{23,"language_model.model.layers.1.block_sparse_moe.experts.260.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"6fbc7f05a6f5cb6be7d24513b9310e3a92c54763cc63a6b56c3dd62f905578d9",p29},
{23,"language_model.model.layers.1.block_sparse_moe.experts.260.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"0d97061747c01c3f797b485e3c61cd50e33238828e0ff8bcf3483149f87854ff",p30},
{23,"language_model.model.layers.1.block_sparse_moe.experts.260.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"b5e25cef9f05b7a0faf9ac881157ad74b423df78b71ce5c2b0750dcb42bc86bb",p31},
{23,"language_model.model.layers.1.block_sparse_moe.experts.260.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"718ab640eb55a773113a22bb14760b7d3389895e3f18235cccd75c1835b1fff0",p32},
{23,"language_model.model.layers.1.block_sparse_moe.experts.260.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"0e8b70f1a1d641d75e873cc882021da328dbca0478e84b789d52ee5468236a5d",p33},
{23,"language_model.model.layers.1.block_sparse_moe.experts.260.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"4599a1639408b0b22a3c14157ba0684c5ecf8c96187f63ec9017edded00b69ed",p34},
{23,"language_model.model.layers.1.block_sparse_moe.experts.305.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"2f8dee88894342fa83feaaef4ac4aba5d780678a297dea23c6729fe539f9285c",p35},
{23,"language_model.model.layers.1.block_sparse_moe.experts.305.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"7998e557001c001f6ab9e53ce2550cf8e77e1028695a70f693f98c099cd8c744",p36},
{23,"language_model.model.layers.1.block_sparse_moe.experts.305.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"61e638446deacf6c1a465426b1745271cbcef41cf47c01061f0df2497988879f",p37},
{23,"language_model.model.layers.1.block_sparse_moe.experts.305.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"21cdeca373a95ed25a5f0a319503b1007a3acd3129573b1d45fb1a6748d91a9c",p38},
{23,"language_model.model.layers.1.block_sparse_moe.experts.305.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"0aaa1f04a9a7ac7ba47f73d8521d4e41bbd0d564a33924f991da05626161431d",p39},
{23,"language_model.model.layers.1.block_sparse_moe.experts.305.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"620402aad28e2c0bdad498a34de72cecbaa8dc12799521b5e57de6df1d89b417",p40},
{23,"language_model.model.layers.1.block_sparse_moe.experts.365.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"8452cb04b597ec45971ba1bde7ed4557c36407f3d128d33667643684db16d608",p41},
{23,"language_model.model.layers.1.block_sparse_moe.experts.365.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"03620ec1632f97559af3b0a2e668aecbe614a0e213925e5f3de44aafb366deab",p42},
{23,"language_model.model.layers.1.block_sparse_moe.experts.365.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"f5688b907f34efaceb39e0125a197f0ad38f3b902ba841ff6c759fcda8895e60",p43},
{23,"language_model.model.layers.1.block_sparse_moe.experts.365.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"2b14d7590d416870d9282faf5147f33a4cd996109fb81c18f76a8b36fdc9c8c3",p44},
{23,"language_model.model.layers.1.block_sparse_moe.experts.365.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"b7157ca68e575bec561081e0e304103b930b53ccce0c5ba53936d20223fe3a34",p45},
{23,"language_model.model.layers.1.block_sparse_moe.experts.365.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"0cc005e65a6e1f7d2bbf22d86888d831c9d1ca4e8ec0e764502a501b7a53010b",p46},
{23,"language_model.model.layers.1.block_sparse_moe.experts.366.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"5cf2a6b5472a073f72215c03a7925d94d5c32309d73bbf1fb965e1560cff3eee",p47},
{23,"language_model.model.layers.1.block_sparse_moe.experts.366.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"e05ebb002ba6947c25f9777543ecac9eb63ff135daa7faa86852ad3d5e4922a4",p48},
{23,"language_model.model.layers.1.block_sparse_moe.experts.366.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"98476d85e6fa1f5041ee84d09e19e4f6e68d8d96c6ad274d5a6263a1e44c33b7",p49},
{23,"language_model.model.layers.1.block_sparse_moe.experts.366.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"82a4c0ef5a50ec38df35a418a16fa57dfb86fed008540cdb96691289b67f1ecb",p50},
{23,"language_model.model.layers.1.block_sparse_moe.experts.366.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"ef76a5f47832cd3544676b8d83abb8b7cc993ced3dea72e81154f78015256031",p51},
{23,"language_model.model.layers.1.block_sparse_moe.experts.366.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"f98ec902608002016dc808b463738f6a910b5c550ac7e9154019e653b43824d5",p52},
{23,"language_model.model.layers.1.block_sparse_moe.experts.404.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"21691776338d08231281d6da2c4596de594aa78d2ff117c1a9d2fe64dac87041",p53},
{23,"language_model.model.layers.1.block_sparse_moe.experts.404.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"facf3035304b2bf732b154803566fc330f78d84ef65d4bb2bbb4f4a64820eb99",p54},
{23,"language_model.model.layers.1.block_sparse_moe.experts.404.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"17b475442b798014e1da6e14695511158ca397be5fee5ac3c94231ea24f9aed2",p55},
{23,"language_model.model.layers.1.block_sparse_moe.experts.404.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"3b029c76137ee1a379b0c7bb6a9d535856dbde032f711e1cbeceb4a2ef2efef3",p56},
{23,"language_model.model.layers.1.block_sparse_moe.experts.404.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"57df1ec62f5c0dfa9ae93865ad300e5cd7f343b017f33e9fd3ed92da6690cc34",p57},
{23,"language_model.model.layers.1.block_sparse_moe.experts.404.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"90079f1dbd341670c1a5f5f8a0648abb155f52f44784e9b2d664e57b37208f25",p58},
{23,"language_model.model.layers.1.block_sparse_moe.experts.444.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"b29466ec0876b5d63812552f4fbf2905f539da33d21b085e9ef7bc0cd9fbde5e",p59},
{23,"language_model.model.layers.1.block_sparse_moe.experts.444.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"f91e1da67f328e8161c31a8609932a75d5bfc336d630b729431368ae927ec4bf",p60},
{23,"language_model.model.layers.1.block_sparse_moe.experts.444.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"c972617b4d95df2fef20da7c8ade99de13293bfa1c77ed6fced3b3cf06e566e4",p61},
{23,"language_model.model.layers.1.block_sparse_moe.experts.444.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"5feaa7a524c607473940096a54b4c3c1da14d2916aa2bf8236181ada63872dc5",p62},
{23,"language_model.model.layers.1.block_sparse_moe.experts.444.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"0b1a32d03195089309f8afd4f55b8a26b8ef76fc7f07f7a8cfe79522be8b97e0",p63},
{23,"language_model.model.layers.1.block_sparse_moe.experts.444.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"fc47be9c8ba203da1a34e680188d5fd00c26a29aae40909cd3fb643b89b73132",p64},
{23,"language_model.model.layers.1.block_sparse_moe.experts.593.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"26d86e8f12a6ae392f60c1fa8a82bd043e5f6793e3a17d822ffd8cadd77bb421",p65},
{23,"language_model.model.layers.1.block_sparse_moe.experts.593.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"67c0a4e88d4df39e53d842c422b5dfc43ac04b8989f2b9cf43eb1b56aab1d859",p66},
{23,"language_model.model.layers.1.block_sparse_moe.experts.593.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"2c864f119b81282f6a8a63e04d6481e5df8779d766835930c7343b63ffc5323b",p67},
{23,"language_model.model.layers.1.block_sparse_moe.experts.593.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"fdd204e1caf3bb200d27778056daa854f3ad5dfec943b5d49f75b932df214ee5",p68},
{23,"language_model.model.layers.1.block_sparse_moe.experts.593.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"2d91106f4058a0670bfec3e41aa2b52c3855bebff61cd3a7560b16d9e6be37b2",p69},
{23,"language_model.model.layers.1.block_sparse_moe.experts.593.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"60d112a542f6f49e7063541ec28ee8e69fc42f9976bb4f4e50fc44ef89088791",p70},
{23,"language_model.model.layers.1.block_sparse_moe.experts.619.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"3200425da44e1f7a5b7477e24a3e2242e2a119ceb1b987bbc1cdc820f9b27f56",p71},
{23,"language_model.model.layers.1.block_sparse_moe.experts.619.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"8a8961577cefb235f4b961c637fdbbb038b450de04469d35f7c4ebd32799e9b6",p72},
{23,"language_model.model.layers.1.block_sparse_moe.experts.619.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"6f2afe76a5197c919bef96f7e21f75642f02a7e581695cf8c9e4fe35fa062447",p73},
{23,"language_model.model.layers.1.block_sparse_moe.experts.619.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"3024cb613865cd05b4899ac09de3ece6d658612a35a279ca25e7efb50fd5023c",p74},
{23,"language_model.model.layers.1.block_sparse_moe.experts.619.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"c9767bc58e71c1daf0217d194619b2360605b47fae97db5d1c3e3908d97fffe5",p75},
{23,"language_model.model.layers.1.block_sparse_moe.experts.619.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"15b8a9bbbbf315ca5c553e5da1f18900290f95a838ee2b0d9f218fc2faa62ce0",p76},
{23,"language_model.model.layers.1.block_sparse_moe.experts.634.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"e3bead2452d1eb76ff006336e1ec68b40563cfd6418ac83dd92c28fecaa551c6",p77},
{23,"language_model.model.layers.1.block_sparse_moe.experts.634.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"1b6cc67e3a2f7d42b41b8213b114d0974b3bf7ab9cf8079d214b75b36220e3f6",p78},
{23,"language_model.model.layers.1.block_sparse_moe.experts.634.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"f34b90fa416e0d568964a95b67803b4cf21a6bad79f5d4f5d9c5096367566619",p79},
{23,"language_model.model.layers.1.block_sparse_moe.experts.634.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"c623c2a00290f65a5a695f952a32e92277449225971579c180eba734ef98966a",p80},
{23,"language_model.model.layers.1.block_sparse_moe.experts.634.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"28f3a714cd6a4bf58b216d67157e714e1b1b2b41d71105753b51b4c498b00ab9",p81},
{23,"language_model.model.layers.1.block_sparse_moe.experts.634.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"3fe580a87622eaaa71989e8cbf639a317f7a6b17083e79738a2370598ef7e9a6",p82},
{23,"language_model.model.layers.1.block_sparse_moe.experts.731.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"664dde1db916262c889bd4eaad50546dbdd3659b5bf4f18662c648cc3b66f090",p83},
{23,"language_model.model.layers.1.block_sparse_moe.experts.731.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"9e054817411654d92b447e9c0238b545dee97f18cd624b36f74a0cd41f3815a0",p84},
{23,"language_model.model.layers.1.block_sparse_moe.experts.731.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"2d774ed7540a5d6f10f7ae67beca1fd6d7073d28e8a25c9717d17627f439b00c",p85},
{23,"language_model.model.layers.1.block_sparse_moe.experts.731.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"f4281dcdf475cb3094c2b099e5a195b88f09dc2da5be8d501c724050a5d3ae4f",p86},
{23,"language_model.model.layers.1.block_sparse_moe.experts.731.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"761a239246601ae2fd5d1f435a306ae486bac3ba2fddccadb23a99f413adec89",p87},
{23,"language_model.model.layers.1.block_sparse_moe.experts.731.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"ad8e8442e02b901c5a4964fc67a44982a1b673293df8d126d88c31cae2fd0a19",p88},
{23,"language_model.model.layers.1.block_sparse_moe.experts.79.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"24a3323e3dd8d707fbbbce11ab9fb11a6363ea6b58ffb6899729eea7d27801be",p89},
{23,"language_model.model.layers.1.block_sparse_moe.experts.79.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"8786c9bc254bc2ecdb8cca34e8a8f043b8efcdf16f136d7769c8af229f1d619b",p90},
{23,"language_model.model.layers.1.block_sparse_moe.experts.79.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"b5af73ce579b2198d5301d62b22456733f3656bd2bd29d910b6eea713d4c1aa7",p91},
{23,"language_model.model.layers.1.block_sparse_moe.experts.79.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"3378b5ebb3dfd95d913f8030be24cbc36997b7e9c825f125fbd72236d26aaa64",p92},
{23,"language_model.model.layers.1.block_sparse_moe.experts.79.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"cd4af2d72db6c56431f68a655a5e45fcacd0193dd0ed1962349481c3eabbe3a8",p93},
{23,"language_model.model.layers.1.block_sparse_moe.experts.79.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"3b3e4f896c547d7b6ed19d45729931bcbd2e22b01e41dc1912ccc24806087bf0",p94},
{23,"language_model.model.layers.1.block_sparse_moe.experts.878.w1.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"5144f83e25f2140d1bafaafee8c594a13465e199661526f6f5395e6e6ca78f04",p95},
{23,"language_model.model.layers.1.block_sparse_moe.experts.878.w1.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"24b73e9a728d2c744d7dc9b5c8e7044b6a5fb69353243e5d7fb1340fb9221bf7",p96},
{23,"language_model.model.layers.1.block_sparse_moe.experts.878.w2.weight",c::DataType::kUInt8,{3584,1536},2,5505024,"263e16778509206fb1f74674a40d1a6ec0eddd962b2beb1b8824e8ef48442aef",p97},
{23,"language_model.model.layers.1.block_sparse_moe.experts.878.w2.weight_scale",c::DataType::kUInt8,{3584,96},2,344064,"a469466ed1de3cc5032e47724c69ebf46a98caff75752f9e3c33c73f1886149b",p98},
{23,"language_model.model.layers.1.block_sparse_moe.experts.878.w3.weight",c::DataType::kUInt8,{3072,1792},2,5505024,"3149f52bc8ca552bb65dbc772f51b6446d9283cef68e231feabc6259851a0e1e",p99},
{23,"language_model.model.layers.1.block_sparse_moe.experts.878.w3.weight_scale",c::DataType::kUInt8,{3072,112},2,344064,"725105871e331aeed29fcfa2c94f8139c13d8d6d8f3bf0bf65d3fcff59549515",p100},
{23,"language_model.model.layers.1.block_sparse_moe.shared_experts.down_proj.weight",c::DataType::kUInt8,{7168,3072},2,22020096,"d81d5fce1ab8c01152d29c14ffc683f848978008402c22b069733552a630dce9",p101},
{23,"language_model.model.layers.1.block_sparse_moe.shared_experts.down_proj.weight_scale",c::DataType::kUInt8,{7168,192},2,1376256,"3e639ffa0f06f1503a005f09497668d2c2f4632c59ea5c71c31554b29bb0b973",p102},
{23,"language_model.model.layers.1.block_sparse_moe.shared_experts.gate_proj.weight",c::DataType::kUInt8,{6144,3584},2,22020096,"cdf191a8138d9a9bdcf6b584e109f734132cfd06e5863c786920c4fad92b8682",p103},
{23,"language_model.model.layers.1.block_sparse_moe.shared_experts.gate_proj.weight_scale",c::DataType::kUInt8,{6144,224},2,1376256,"83d6b984826cdcc52f56fe5c3e7e2eb9d65d440cb8c3855605bd822e8cc36bee",p104},
{23,"language_model.model.layers.1.block_sparse_moe.shared_experts.up_proj.weight",c::DataType::kUInt8,{6144,3584},2,22020096,"cb94187dcae24d4f4c41c05c1c00e57948a7530ac8e89aa234026b761bf922f6",p105},
{23,"language_model.model.layers.1.block_sparse_moe.shared_experts.up_proj.weight_scale",c::DataType::kUInt8,{6144,224},2,1376256,"a068cf36feebef80ff2fb1fb30870cb13727046c09f451f529c6aaa5ee254b1c",p106},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"7e5c6a8070d65ab27e30274d40dc01b6047bad25558a0f47b63f3a543320f129",p107},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"69942bf5dbc7cb2bca465cf984a80ec4b79b5da81a3b27c3ad5a1238da250bae",p108},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"64eff49ef6e7dd3dd3db6b8c7a17b43220758709f5581d05703bd6694422557b",p109},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"bb3a7702da6626c6644be6d57b87591995e1545f5631a2a90e43cf663bfd8503",p110},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"af62ce273bfd481e2c328e9311678f9de43eb4fd177438286cd9b88570431af3",p111},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"571f9bfc7758c2b55d4a1a781c2190e57c7c788b8a79231816992c2d1f8581a0",p112},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"d036427a61abd3f3774f6e5f504c739b855c08c83933b8178170c2759c4b0765",p113},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"e8471d75e4b3687ab87634abbe76a2ba5dde9f8300e840fef1120bab236fbbf8",p114},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"eef12af4595983524a3ba7bee824b5367cca1d9c54951a7ad5903748704d233c",p115},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"62e7009ac3ba5e99c2a8b01c61fb9c3674235794aa11c917dae29c86da629f62",p116},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"4ca78dcf4e1c4c24242389e14008ef01532e5044aec20e6369f22c7b2c3fb5f6",p117},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"8f7b4a2467f84e7b1212798058424eee7f0ac77a387e74234863a877fccf9ed3",p118},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"fff05006ebf83a478a4ee84ed5825d94ccbce0b36f5901ba6cf714a593428490",p119},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"7938c936ff9c995cf0f4c09f94dbdf2e6b8122a93440b3807cbacf9803e599ea",p120},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"b20ac10d77076c25e48b2201b1851a1dd06baefde9ae025efa5056feeef1fd1d",p121},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"dab41a8c0a702217b65a8dd11105f3d307c42ff1bedc5f940b20a47de6b61ceb",p122},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"c1cea1ee80fba2c7956c495c4e4fb4163460c8e5976c9b87d33da214ddcc1253",p123},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"3477377aaadbc8719becbf83c514b210532b2ac30821dc889eefac3867fd40ac",p124},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"4684c5f2eec854bff607647a6d4b3452482b211f640d7112045280235073aece",p125},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"6397cb11eb5b352ebd33812853048187de0f8ef3243cf4a39d2322e1d5756cca",p126},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"3e18afe5a695287b89fcd17e71dbe3ec222d26a44cbc4d1c4879f705d6ce7150",p127},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"7e8ff2b32a6cf1915114e861a4fadbb8f832cb8a5affaab87df795923b9d4171",p128},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"e152082971a4982d2231f63b29e1798e8e4025031ccd4a358a30d25f4d7dbfa4",p129},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"2f5d1f8decc06f52c3fb3b7d8af929ff09e6330d9627565d16740d726557956c",p130},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"e87330d986d61e3f124007f8c4cc9c88252a9aa7308780e64de69d1541aeeb28",p131},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"b23fa66c50becfe66cb95417440e9c1c8ba797045257e7c241dda96806c96b2c",p132},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"ccb9ffe3b3430c377c47952075af55cf6a2df7a2f69e50cf252ada12a789dbde",p133},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"3e8793a3ae8cf12df5d29a94308a57feb02f3e826d37d112c83d91fad0f370e7",p134},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"7621075b2202e527d327ea681068519ca054608819be89eded9599b4708157e9",p135},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"c48865d2f8e6714e95b555278f8a3392fda8e3a419c6ccea67db09e4b99d5a31",p136},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"41f77dd7d2ed57c1b79be394566f6d5e7bc58280999a65aa7773900a89da7165",p137},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"4a7445f958c607b96b832054dac1d0fead038b8b10c4e748b2929c5e6536478a",p138},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"de13a14526b185cb40213ae3d207fbd1172edf74114a90a0d72258e3f2c0a336",p139},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"0cba7cd4d46e28a7ee3e6e0e0fb96d21ee19fb0fcee68d1f41911496b61d943f",p140},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"31a174f4daa68e84457a12839af97c87cca9033c97b8861d6db6eb11924cf2e9",p141},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"6bccfdc3e47db60e5a7022a411358649b464e00f29f47d7ab12c3736a6c4a0a6",p142},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"32ba7b2dab9b1fb7e1f850af9ab123a41526fb5b5824a685c01728f0876bd9d6",p143},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"5ec96effcb27b52a78d6f505edbbfae5530e7a6df8f315c54fabeeb7650278f5",p144},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"b54ef4fe7eb7668537700aa64b0d1a6b9c99083ff05e1fa96667e00231090e63",p145},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"bccaef8aa79dfe918cc22aa04f0dd80f64d2f0717ea6cbdb23d3670b2aee863a",p146},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"a62aa35745965a26cc7cb3cde07114c8a12d8907f9b8203e252986a7df839edf",p147},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"7e35bf14e930d03d396aa8499c31c370beee83deed5aeaa45100d2a68c082158",p148},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"33c0a75d6b18f50091cbc8973509c4c8ec6fbb1b04b8e64309af4c4f33d40a7c",p149},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"14b28495f15136d185e012201f4de121a9a06a8db97cea416eeb89cf06e6ffdf",p150},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"e857aa55cfec530b7d5ef2f2fc4a3537511021931668c2853b8cf5d79d1d7b4f",p151},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w1.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"d2fbceb528cf53fb1543475e2ab92a5a9e782311c82fc4d963fc382e82376feb",p152},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w2.weight_scale",c::DataType::kFloat32,{3584,6},2,86016,"1b5604142d1f10857a9f0d7b43baf97368d29f22df1ff330612cac97c346a723",p153},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w3.weight_scale",c::DataType::kFloat32,{3072,7},2,86016,"953a8b8bedfae037bb7881bbc94e5a2cc930dce92dad7718e51ad45af5444f43",p154},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"72b73435320f995aba3a4c1684814831fa8582551d89bb97ac208f52ef01956a",p155},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"e0fa357551bb15eb6afc741abd89fe7647ce1391f3ac2fbdda7bd9be50d3333e",p156},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"fce82e96cdb8de4597d7a0e8e00ef879ce50974787db6af59589092cf84ac187",p157},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"3eddb3c9bdb2597d09fcc2bdb983f61985eef7212fe6541d65d0e8d554e60328",p158},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"ee750e1a45df4f24dea6203e8bedd1110222cf995631f4c8bbe2f007dbc469e4",p159},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"f76a4f769d3e006b4756e55abc6680b1486163bf7833b0a5837723397d3d69d5",p160},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"aa34aa8e1d47ebe9eb3d948d848ac35f8b15782a8a7f88e1ce00f2a8c80fac39",p161},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"525b92c14310c5276809b6dcbbdbf00840b0e10f6973c48460f862145d61b0ec",p162},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"476830e1e50e823570f82a795dbd9e32117300a5a0deeb16d74d5a2aea4b4483",p163},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"ea9bd5cb846a70c914ff8dd6113163289aa61cbd2b0c2012e055464990da037b",p164},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"b566537e36651fe3f58576ab11bd1f387bc82bfcef4c4ff837e472c5ee50101a",p165},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"cf89b41fbdae997bbb748d87f3230e17e5e36088619f970c83f8f0f8991d6388",p166},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"99c3461d7d704061ff5c1c367011395e0927151eda9dd8b84a848cab05ac9d31",p167},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"3d3be6074f926f936e6cc2cdada53d30e9289caa99f3823e0800707860d3eedb",p168},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"1f9304b6907f74bd2a7f67965dc1ae67d62fc1e32e817eeb561363a23d71922b",p169},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"c2a569f2bcea899ca8c45b640d1683a45799baeff63dd1528d5d63ba12a1f352",p170},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"9cf264962fc31d75d6bf5d333c68ef7aff3d76a73ecbd3f2d1e024c73e05458c",p171},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"e20c1949dcf407ad5fabd4e8ddfea9578f2f5d52f5ba8c59afb91a28f268b805",p172},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"7ce4a797baa891095b2b2bbf0d3ddbc3b1ac6221f3fc2804f26fa0d47c744aa5",p173},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"50b5c3a24bafa91555442a967cef8d4985a8e6b88b19dc7daa8da253d62ec8cf",p174},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"8b204f7d661fd288ccb8f38ffaea2148387cd1a9873bd6d0b195514d3b9e90b3",p175},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"b5f58467ea79ffe25201d7bfd7be345e1ef33a9ca0ef21fc13a3b7ec0c971714",p176},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"2f4f1dca0537154dbfc98d8b0d11f7dab5a765d840e7bac43bcb9d6a3cb77ca5",p177},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"747395c848b61f929c4d80a124b38fcfcb687fa1d68597f709796543a81e6bd1",p178},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"b81bc3655bcab2184f929ae728cb3fd33cd5f62a882a4a356c1235e2875c0dec",p179},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"b4974e4d40c89ac26fc9826cc707e67bd66672e63df7d9a379ac961e9efb84cc",p180},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"634ae429ee863b75c2fcc315edd80211b79533fd4a5948977386e37d7b17b909",p181},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"3e3bdbd58e5374148999eb26b1e8a95d4cb4646d0f2c01df6f0789efde97e9d5",p182},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"2526dba50058260dc93de49bcf56c5c6ec87bf3febdadd73cd9b85b91ea91b24",p183},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"e4982f6adffdd27985aee08285943adb4d065f0009782d7df46c9c2145829f46",p184},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"a8d95b3dfd0be171b48860c5b4cf985302076754251f00253915d5e7193a185c",p185},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"a705b20da93528ba476cfc3119a0d1af592a5bf5d50f6ae210b3386a6d501007",p186},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"17f2d4477e5a9c3c23d08d5787f660cfa178a0f578ce4d82f739fb81693cc8be",p187},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"61b525c7fdfc582bb13fd5f24f6e6c8a6df39f0163df7afb235e24335f3afb56",p188},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"db47d95cf7b506e50f2af9315abe05ba3c00ba9141070a9f98d7d176e702d8dc",p189},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"df14ef1b30c5cdbbb6a3de39de3de74681ba7cd11f116d28bf6038fb73209b56",p190},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"ade6f905389f58b7496a3548f726447153b52a987cb274807f1907e87acc1d52",p191},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"c40b9e853f7a02e7564425b2c9c7a04a8dfb3604f2e9a78c42ee7fbd5ac3ce4a",p192},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"47e82280cf62973db18c8afcb99e0b32cd7f11d6eed224813a26fcc14b18e1b9",p193},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"5ba659e85e42a1d0957b2607677fc5f5f09e4b4867fa05e0c7ce1fcf1c7a704e",p194},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"f03f04aa9ed9c031f469373df6179f9afaf7f030792d8647f257beec6bc44e77",p195},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"62b9bf984fc6ce4f4a7b9d50f886ee77e7402f9ce79c8bda240c831a64784247",p196},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"914e7a607a5e3a9cefadb1429c1980920f6860afcbb12e1ff831fdd597820a5b",p197},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"286b280f7ec7f5dd598895ab19e7083ae878b79355a03b023bad8b2d608fb960",p198},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"ef26c3944ec8a38a347b19789115b9b95df8bc236dafdcb53588c4053ee27a94",p199},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w1.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"059986a821e442b2d7bf7e33f112f1262b43853a31282ea03f80f7ba382969dd",p200},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w2.weight_packed",c::DataType::kInt32,{3584,384},2,5505024,"84662c496f7de77edfc97f3607cf6513b8d93ae7d1f9e05c70fa52773657b632",p201},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w3.weight_packed",c::DataType::kInt32,{3072,448},2,5505024,"de5333036ae3d28b656b9cdc10431279c6fd1c0b0b4d5660d042bd87768666d1",p202},
{24,"language_model.model.layers.1.block_sparse_moe.routed_expert_down_proj.weight",c::DataType::kBFloat16,{3584,7168},2,51380224,"39bfe48649bd6452944185b32eb6486dbf0552da401c83f5d4f6ef2b3c0a3ca6",p203},
{24,"language_model.model.layers.1.block_sparse_moe.routed_expert_norm.weight",c::DataType::kBFloat16,{3584,0},1,7168,"4f9aaa834cd9c0deb04c14e6d1f092f829b5fb91f8f0a1016b460fb57c561a37",p204},
{24,"language_model.model.layers.1.block_sparse_moe.routed_expert_up_proj.weight",c::DataType::kBFloat16,{7168,3584},2,51380224,"89949f7919a90006dd3c5f5da8e063d7ce023e2549c8dc0ce6a93b78fb4ffe76",p205},
{24,"language_model.model.layers.1.block_sparse_moe.shared_experts.down_proj.weight",c::DataType::kBFloat16,{7168,6144},2,88080384,"53bdfc43ad3596241d5dacaf9fb002d40d0480c31ebc32a92ed37733f757bf7b",p206},
{24,"language_model.model.layers.1.block_sparse_moe.shared_experts.gate_proj.weight",c::DataType::kBFloat16,{6144,7168},2,88080384,"a0000660f0bd22d6232b126cc7608843e1a56d81c9073b0585d40c9d6ee3ee86",p207},
{24,"language_model.model.layers.1.block_sparse_moe.shared_experts.up_proj.weight",c::DataType::kBFloat16,{6144,7168},2,88080384,"d07b321c3b5f3e96a2ebfa2057048b09f21b9a756d2203bf07764267dfa34718",p208},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p209},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p210},
{24,"language_model.model.layers.1.block_sparse_moe.experts.156.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p211},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p212},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p213},
{24,"language_model.model.layers.1.block_sparse_moe.experts.210.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p214},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p215},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p216},
{24,"language_model.model.layers.1.block_sparse_moe.experts.220.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p217},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p218},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p219},
{24,"language_model.model.layers.1.block_sparse_moe.experts.250.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p220},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p221},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p222},
{24,"language_model.model.layers.1.block_sparse_moe.experts.260.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p223},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p224},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p225},
{24,"language_model.model.layers.1.block_sparse_moe.experts.305.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p226},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p227},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p228},
{24,"language_model.model.layers.1.block_sparse_moe.experts.365.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p229},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p230},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p231},
{24,"language_model.model.layers.1.block_sparse_moe.experts.366.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p232},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p233},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p234},
{24,"language_model.model.layers.1.block_sparse_moe.experts.404.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p235},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p236},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p237},
{24,"language_model.model.layers.1.block_sparse_moe.experts.444.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p238},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p239},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p240},
{24,"language_model.model.layers.1.block_sparse_moe.experts.593.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p241},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p242},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p243},
{24,"language_model.model.layers.1.block_sparse_moe.experts.619.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p244},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p245},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p246},
{24,"language_model.model.layers.1.block_sparse_moe.experts.634.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p247},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p248},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p249},
{24,"language_model.model.layers.1.block_sparse_moe.experts.731.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p250},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p251},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p252},
{24,"language_model.model.layers.1.block_sparse_moe.experts.79.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p253},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w1.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p254},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w2.weight_shape",c::DataType::kInt64,{2,0},1,16,"ff4ecfe7ef03632403c0d4f3da8735530551296cbb38f0f99ee405299796e4e4",p255},
{24,"language_model.model.layers.1.block_sparse_moe.experts.878.w3.weight_shape",c::DataType::kInt64,{2,0},1,16,"4e2a92d1b2b1058c8de69cea55eb6a5c797928fdef442d34c045b690b29f6f1a",p256},
{23,"language_model.model.layers.1.block_sparse_moe.gate.weight",c::DataType::kBFloat16,{896,7168},2,12845056,"25ebb27dfe797648f0d815f433fb2cf36f5617987bc2208e01d071588e79a957",p257},
{23,"language_model.model.layers.1.block_sparse_moe.gate.e_score_correction_bias",c::DataType::kFloat32,{896,0},1,3584,"853727cc546c18e82efe23f124519049f001feb3d429123876ba8ec5484e5a1d",p258},
{24,"language_model.model.layers.1.block_sparse_moe.gate.weight",c::DataType::kBFloat16,{896,7168},2,12845056,"25ebb27dfe797648f0d815f433fb2cf36f5617987bc2208e01d071588e79a957",p259},
{24,"language_model.model.layers.1.block_sparse_moe.gate.e_score_correction_bias",c::DataType::kFloat32,{896,0},1,3584,"853727cc546c18e82efe23f124519049f001feb3d429123876ba8ec5484e5a1d",p260},
}};
} // namespace original_kimi_roles
