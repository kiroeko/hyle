"""Independent original-byte equations. Never imports a Hyle codec/kernel.
Cold preparation is CPU-only; audit is conditional on already checked actual
predecessors, not a bitwise full-model oracle or quality/performance claim.
"""
from pathlib import Path
import argparse, hashlib, json, os, sys, time
os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
os.environ.setdefault('OMP_NUM_THREADS','4')
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
WORK=ROOT/'.scratch/kimi-publisher-router-20261025'
COMP=WORK/'component'
P='language_model.model.layers.1.block_sparse_moe.'
H,E,S,L,I,SH=7168,896,16,3584,3072,6144
IDS=np.array([220,210,79,156,404,593,444,305,365,731,634,250,366,260,878,619],dtype=np.int32)
MAG=np.array([0,.5,1,1.5,2,3,4,6],dtype=np.float64)
U32=np.float64(2.0**-24);U64=np.float64(2.0**-53)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bf_bits(x):
    y=np.asarray(x,dtype=np.float32);u=y.view(np.uint32)
    return ((u+np.uint32(0x7fff)+((u>>16)&1))>>16).astype(np.uint16)
def wide(bits):return (np.asarray(bits,dtype=np.uint16).astype(np.uint32)<<16).view(np.float32)
def bf(x):return wide(bf_bits(x))
def f32(x):return np.asarray(x,dtype=np.float32)
def gamma(n,u=U32):return n*u/(1-n*u)
def finite(x,where):
    if not np.all(np.isfinite(x)):raise ValueError('nonfinite '+where)
    return x
class Source:
    def __init__(self):
        self.index=json.loads((WORK/'source-roles.json').read_bytes())
        self.roles={(x['catalog_index'],x['name']):x for x in self.index['roles']}
        self.checked=set()
    def role(self,cat,name):return self.roles[cat,name]
    def raw(self,cat,name):
        r=self.role(cat,name); pieces=r['pieces']
        if len(pieces)==1:
            p=pieces[0];out=np.memmap(ROOT/p['path'],dtype=np.uint8,mode='r',offset=p['offset'],shape=(p['bytes'],))
        else:
            out=np.empty(r['bytes'],np.uint8);cursor=0
            for p in pieces:
                view=np.memmap(ROOT/p['path'],dtype=np.uint8,mode='r',offset=p['offset'],shape=(p['bytes'],))
                out[cursor:cursor+p['bytes']]=view;cursor+=p['bytes']
            assert cursor==r['bytes']
        if (cat,name) not in self.checked:
            assert hashlib.sha256(out).hexdigest()==r['role_sha256'],name
            self.checked.add((cat,name))
        return out
    def array(self,cat,name):
        r=self.role(cat,name);types={'BF16':'<u2','U8':'u1','I32':'<u4','I64':'<i8','F32':'<f4','F8_E4M3':'u1'}
        return self.raw(cat,name).view(types[r['dtype']]).reshape(r['physical_shape'])
def activation(epoch):
    a=np.resize(np.array([1,2,-.75,-1],dtype=np.float32),H)
    for j in range(17):a[j]=(2+((16-j) if epoch else j)/8)/64
    return bf(a)
def dense_reference(x,wb):
    # All BF16 products are exact in F32; bound arbitrary F32 sum order.
    x=np.asarray(x,dtype=np.float64);n,k=wb.shape;assert x.shape==(k,)
    center=np.empty(n,np.float64);error=np.empty(n,np.float64)
    for row in range(0,n,128):
        w=wide(wb[row:row+128]).astype(np.float64)
        finite(w,'original BF16 W');c=w@x;s=np.abs(w)@np.abs(x)
        center[row:row+128]=c
        error[row:row+128]=(gamma(k-1)+gamma(k,U64))*s+np.ldexp(float(k),-126)
    return center,error
def a32_activation(x):
    a=np.asarray(x,np.float32).reshape(-1,32);maximum=np.max(np.abs(a),axis=1)
    fraction,exponent=np.frexp(maximum.astype(np.float64))
    exp=np.clip(exponent-np.where(fraction>=.875,2,3),-127,127)
    exp=np.where(maximum==0,-127,exp)
    scale=np.ldexp(np.ones(len(exp),np.float64),exp).astype(np.float32)
    normalized=bf(a.astype(np.float64)/scale[:,None])
    # Ascending code enumeration with even-code tie preference, independent of
    # product bitmask/packed quantizer. Preserve negative zero sign.
    distance=np.abs(np.abs(normalized.astype(np.float64))[:,:,None]-MAG)
    best=np.zeros(normalized.shape,np.int64);current=distance[:,:,0]
    for code in range(1,8):
        update=(distance[:,:,code]<current)|((distance[:,:,code]==current)&((code&1)==0))
        best=np.where(update,code,best);current=np.where(update,distance[:,:,code],current)
    q=np.copysign(MAG[best],normalized)
    return bf(q*scale[:,None]).reshape(-1)
def mx_reference(x,w,sf):
    # Temporary row tiles only, no persistent decoded source bank.
    a=a32_activation(x).astype(np.float64);n,k2=w.shape;k=k2*2
    assert a.shape==(k,) and sf.shape==(n,k//32)
    assert np.all(sf<255),'undefined E8M0 source sentinel'
    center=np.empty(n,np.float64);error=np.empty(n,np.float64)
    for row in range(0,n,64):
        tile=w[row:row+64];codes=np.empty((len(tile),k),np.uint8)
        codes[:,0::2]=tile&15;codes[:,1::2]=tile>>4
        signed=np.where((codes&8)!=0,-MAG[codes&7],MAG[codes&7])
        scales=np.repeat(sf[row:row+64].astype(np.int16)-127,32,axis=1)
        decoded=bf(np.ldexp(signed,scales)).astype(np.float64)
        finite(decoded,'original MX W');c=decoded@a;s=np.abs(decoded)@np.abs(a)
        center[row:row+64]=c;error[row:row+64]=(gamma(k-1)+gamma(k,U64))*s+np.ldexp(float(k),-126)
    return center,error
def k512_reference(x,w,sf):
    # Complete I64 dot for every512 group, then original BF16 checkpoints.
    a=np.asarray(x,np.float32);n,k8=w.shape;k=k8*8
    assert a.shape==(k,) and sf.shape==(n,k//512)
    result=np.zeros(n,np.float32);domain_count=0;max_qa=0
    for group in range(k//512):
        block=a[group*512:(group+1)*512]
        scale=bf(np.max(np.abs(block)).astype(np.float64)*.00787353515625)
        inverse=bf(0 if scale==0 else 1/float(scale))
        qa=np.trunc(bf(block.astype(np.float64)*float(inverse))).astype(np.int64)
        assert np.all((qa>=-128)&(qa<=127)),'undefined original K512 I8 input'
        max_qa=max(max_qa,int(np.max(np.abs(qa))));domain_count+=len(qa)
        for row in range(0,n,128):
            tile=w[row:row+128,group*64:(group+1)*64]
            codes=((tile[:,:,None]>>(np.arange(8,dtype=np.uint32)*4))&15).astype(np.int64).reshape(len(tile),512)-8
            total=codes@qa
            dot=bf(total.astype(np.float64))
            first=bf(dot.astype(np.float64)*float(scale))
            weightscale=bf(sf[row:row+128,group])
            value=bf(first.astype(np.float64)*weightscale.astype(np.float64))
            result[row:row+128]=bf(result[row:row+128].astype(np.float64)+value.astype(np.float64))
    return result,dict(activation_I8_values=domain_count,max_abs_I8=max_qa)
def e4decode(code):
    code=np.asarray(code,np.uint8);mag=code&127;exponent=mag>>3;fraction=mag&7
    result=np.where(exponent==0,np.ldexp(fraction.astype(np.float64),-9),np.ldexp(1+fraction.astype(np.float64)/8,exponent.astype(np.int16)-7))
    result=np.where((code&128)!=0,-result,result)
    return np.where(mag==127,np.nan,result).astype(np.float32)
def e4encode(x):
    x=np.asarray(x,np.float32);m=np.abs(x.astype(np.float64));table=e4decode(np.arange(127,dtype=np.uint8)).astype(np.float64)
    low=np.clip(np.searchsorted(table,m,side='right')-1,0,126)
    high=np.minimum(low+1,126);dl=m-table[low];dh=table[high]-m
    code=np.where((dh<dl)|((dh==dl)&((low&1)!=0)),high,low)
    code=np.where(m>=448,126,code).astype(np.uint8)
    return code|(np.signbit(x).astype(np.uint8)<<7)
def fp8_reference(x,w,sf):
    literal=np.array([0x3b124925],np.uint32).view(np.float32)[0]
    scale=f32(float(np.max(np.abs(x)))*float(literal));inverse=f32(1/float(scale))
    a=e4decode(e4encode(f32(x.astype(np.float64)*float(inverse)))).astype(np.float64)
    decoded=e4decode(w).astype(np.float64);center=decoded@a;s=np.abs(decoded)@np.abs(a)
    error=(gamma(H-1)+gamma(H,U64))*s+np.ldexp(float(H),-126)
    low=f32(f32(center-error).astype(np.float64)*sf.astype(np.float64));high=f32(f32(center+error).astype(np.float64)*sf.astype(np.float64))
    lower=np.minimum(low,high);upper=np.maximum(low,high)
    low=f32(lower.astype(np.float64)*float(scale));high=f32(upper.astype(np.float64)*float(scale))
    return low.astype(np.float64),high.astype(np.float64),dict(token_scale=float(scale),channel_scale_min=float(sf.min()),channel_scale_max=float(sf.max()))
def stage_projection(source,cat,name,x):
    if cat==23 and ('experts.' in name or 'shared_experts.' in name):
        return mx_reference(x,source.array(cat,name+'.weight'),source.array(cat,name+'.weight_scale'))
    return dense_reference(x,source.array(cat,name+'.weight'))
def save_reference(folder,label,center,error):
    np.savez(folder/(label+'.npz'),center=center,error=error)
    return dict(values=len(center),center_min=float(center.min()),center_max=float(center.max()),maximum_accumulation_error_bound=float(error.max()),file=label+'.npz')
def prepare():
    target=COMP/'reference-prepared'
    if target.exists():raise ValueError('refuse to overwrite CPU reference preparation')
    target.mkdir(parents=True);source=Source();records=[];started=time.time()
    for cat in (23,24):
        gamma_weight=wide(source.array(cat,P+'routed_expert_norm.weight'))
        finite(gamma_weight,'source norm gamma')
        for epoch in (0,1):
            x=activation(epoch);prefix=f'catalog{cat}-epoch{epoch}'
            xbits=bf_bits(x);xbits.tofile(target/(prefix+'-input.bf16'))
            for label,suffix in [('latent','routed_expert_down_proj'),('shared_gate','shared_experts.gate_proj'),('shared_up','shared_experts.up_proj')]:
                c,e=stage_projection(source,cat,P+suffix,x)
                records.append(dict(catalog=cat,epoch=epoch,stage=label,**save_reference(target,prefix+'-'+label,c,e)))
            if cat==23:
                lo,hi,extra=fp8_reference(x,source.array(cat,'language_model.model.layers.1.self_attn.f_a_proj.weight'),source.array(cat,'language_model.model.layers.1.self_attn.f_a_proj.weight_scale'))
                np.savez(target/(prefix+'-fp8.npz'),low=lo,high=hi)
                records.append(dict(catalog=cat,epoch=epoch,stage='independent_fp8',values=128,**extra))
    result=dict(status='CPU_INDEPENDENT_STATIC_REFERENCE_PREPARED_NO_COMPONENT_GPU',seconds=time.time()-started,numpy=np.__version__,script_sha256=sha(__file__),source_index_sha256=sha(WORK/'source-roles.json'),records=records,source_roles_authenticated=len(source.checked),policy='F64 complete dot; arbitrary F32 accumulation gamma(K-1); BF16 RNE endpoint interval. A32 activation/weight decoding enumerated independently. No Hyle codec, sparse oracle or full-model quality claim.',postrun_conditional='Expert/down/combine/norm/routed/shared-down/final use previously validated actual predecessors; K512 complete integer dots and original BF16 checkpoints. All numerical gates frozen before actual component execution.')
    (target/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(status=result['status'],records=len(records),seconds=result['seconds'])))

# Numerical comparison gates below are frozen before the component GPU run.
# Every downstream equation explicitly names its actual checked predecessors.
CHECKS=[]
def interval_check(label,actual,low,high,details=None):
    actual=np.asarray(actual,np.float32).reshape(-1);low=bf(np.asarray(low,np.float64)).reshape(-1);high=bf(np.asarray(high,np.float64)).reshape(-1)
    finite(actual,label+' actual');finite(low,label+' lower');finite(high,label+' upper')
    assert actual.shape==low.shape==high.shape,label+' extent'
    lo=np.minimum(low,high);hi=np.maximum(low,high);bad=np.flatnonzero((actual<lo)|(actual>hi))
    record=dict(stage=label,gate='BF16_RNE_endpoint_interval',values=len(actual),unique_BF16_rounding_values=int(np.count_nonzero(lo==hi)),maximum_interval_width=float(np.max(hi.astype(np.float64)-lo.astype(np.float64))),passed=not len(bad))
    if details:record.update(details)
    if len(bad):
        j=int(bad[0]);record['first_difference']=dict(index=j,actual=float(actual[j]),low=float(lo[j]),high=float(hi[j]))
    CHECKS.append(record)
    if len(bad):raise AssertionError(label+' first numerical failure: '+json.dumps(record['first_difference']))
def dot_check(label,actual,center,error):
    interval_check(label,actual,center-error,center+error,dict(maximum_F32_accumulation_bound=float(np.max(error)),maximum_absolute_error_from_F64=float(np.max(np.abs(np.asarray(actual,dtype=np.float64).reshape(-1)-np.asarray(center).reshape(-1))))))
def exact_check(label,actual,expected,details=None):
    a=bf_bits(actual).reshape(-1);e=bf_bits(expected).reshape(-1);assert a.shape==e.shape,label+' extent';bad=np.flatnonzero(a!=e)
    record=dict(stage=label,gate='bit_exact_original_BF16_checkpoints',values=len(a),passed=not len(bad))
    if details:record.update(details)
    if len(bad):
        j=int(bad[0]);record['first_difference']=dict(index=j,actual_bits=int(a[j]),expected_bits=int(e[j]))
    CHECKS.append(record)
    if len(bad):raise AssertionError(label+' first numerical failure: '+json.dumps(record['first_difference']))
def situ_check(label,actual,gate,up):
    x=np.asarray(gate,np.float32);z=np.asarray(up,np.float32)
    sigmoid=f32(1/(1+np.exp(-x.astype(np.float64))))
    g0=f32(4*f32(np.tanh(f32(x.astype(np.float64)*.25).astype(np.float64))).astype(np.float64))
    g1=f32(g0.astype(np.float64)*sigmoid.astype(np.float64))
    u0=f32(25*f32(np.tanh(f32(z.astype(np.float64)*float(np.float32(.04))).astype(np.float64))).astype(np.float64))
    ref=f32(g1.astype(np.float64)*u0.astype(np.float64))
    # Existing scalar-source test's independently declared F32/transcendental
    # error + final BF16 half-ULP envelope. No tolerance fitted to actual data.
    tolerance=8e-5+(.00390625+4e-5)*np.abs(ref.astype(np.float64))
    error=np.abs(np.asarray(actual,dtype=np.float64)-ref.astype(np.float64));bad=np.flatnonzero(error>tolerance)
    wrong=bf(bf(bf(g0).astype(np.float64)*bf(sigmoid).astype(np.float64)).astype(np.float64)*bf(u0).astype(np.float64))
    record=dict(stage=label,gate='inherited_independent_F32_transcendental_plus_BF16_interval',values=actual.size,maximum_absolute_error=float(error.max()),wrong_intermediate_BF16_witnesses=int(np.count_nonzero(bf_bits(wrong)!=bf_bits(ref))),passed=not len(bad))
    CHECKS.append(record)
    if len(bad):raise AssertionError(label+' SiTU interval first difference '+str(int(bad[0])))
def read_output(base,kind,epoch,index,dtype,count):
    path=base/kind/('epoch'+str(epoch))/('output-'+str(index)+'.bin')
    v=np.fromfile(path,dtype=dtype);assert len(v)==count,str(path)+' exact extent'
    return wide(v) if dtype=='<u2' else v

def audit(base):
    base=Path(base).resolve();source=Source();prepared=COMP/'reference-prepared';records=[];started=time.time()
    try:
        for cat in (23,24):
            for epoch in (0,1):
                label=f'catalog{cat}.epoch{epoch}';x=activation(epoch)
                r=lambda j,dtype,count:read_output(base,'catalog'+str(cat)+'/router',epoch,j,dtype,count)
                out=lambda j,count:read_output(base,'catalog'+str(cat)+'/expert',epoch,j,'<u2',count)
                ids=r(0,'<i4',S);weights=r(1,'<f4',S);latent=r(2,'<u2',L);logits=r(3,'<f4',E);prob=r(4,'<f4',E);corrected=r(5,'<f4',E);chosen=r(6,'<f4',S)
                center,error=dense_reference(x,source.array(cat,P+'gate.weight'))
                bad=np.flatnonzero(np.abs(logits.astype(np.float64)-center)>error)
                CHECKS.append(dict(stage=label+'.router_logits',gate='F64_dot_arbitrary_F32_accumulation_bound',values=E,maximum_absolute_error=float(np.max(np.abs(logits-center))),maximum_bound=float(error.max()),published_non_BF16_grid_values=int(np.count_nonzero(logits.view(np.uint32)&65535)),passed=not len(bad)))
                assert not len(bad),label+' router logits'
                expected=f32(1/(1+np.exp(-logits.astype(np.float64))));assert np.max(np.abs(prob-expected))<=2e-7,label+' sigmoid'
                expected_corrected=f32(prob.astype(np.float64)+source.array(cat,P+'gate.e_score_correction_bias').astype(np.float64))
                assert np.array_equal(corrected.view(np.uint32),expected_corrected.view(np.uint32)),label+' bias addition'
                expected_ids=np.lexsort((np.arange(E),-corrected))[:S].astype(np.int32)
                assert np.array_equal(ids,IDS) and np.array_equal(ids,expected_ids),label+' actual Top16 IDs'
                assert np.array_equal(chosen.view(np.uint32),prob[ids].view(np.uint32)),label+' gathered raw probabilities'
                expected_weights=f32(chosen.astype(np.float64)/float(f32(np.sum(chosen,dtype=np.float64))))
                assert np.max(np.abs(weights-expected_weights))<=2e-7,label+' normalization'
                CHECKS.append(dict(stage=label+'.router_selection',gate='independent_sigmoid_bias_Top16_gather_normalization',values=E*2+S*3,passed=True,actual_IDs=ids.tolist()))
                q=np.load(prepared/f'catalog{cat}-epoch{epoch}-latent.npz');dot_check(label+'.latent_down',latent,q['center'],q['error'])
                gate=out(0,S*I).reshape(S,I);up=out(1,S*I).reshape(S,I);activated=out(2,S*I).reshape(S,I);down=out(3,S*L).reshape(S,L)
                for leg,actual,name in [(1,gate,'expert_gate'),(3,up,'expert_up'),(2,down,'expert_down')]:
                    cs=[];es=[];exact_rows=[];domain=0;max_qa=0
                    for slot,expert in enumerate(ids):
                        role=P+f'experts.{int(expert)}.w{leg}'
                        a=activated[slot] if leg==2 else latent
                        if cat==23:
                            c,e=mx_reference(a,source.array(cat,role+'.weight'),source.array(cat,role+'.weight_scale'));cs.append(c);es.append(e)
                        else:
                            expected,meta=k512_reference(a,source.array(cat,role+'.weight_packed'),source.array(cat,role+'.weight_scale'));exact_rows.append(expected);domain+=meta['activation_I8_values'];max_qa=max(max_qa,meta['max_abs_I8'])
                    if cat==23:dot_check(label+'.'+name,actual,np.concatenate(cs),np.concatenate(es))
                    else:exact_check(label+'.'+name,actual,np.concatenate(exact_rows),dict(checked_defined_I8_values=domain,maximum_abs_I8=max_qa))
                    # SiTU must be validated before it becomes down's input.
                    if leg==3:situ_check(label+'.expert_SiTU',activated,gate,up)
                combined=out(4,L);normalized=out(5,L);routed=out(6,H);sg=out(7,SH);su=out(8,SH);sa=out(9,SH);shared=out(10,H);final=out(11,H)
                terms=f32(down.astype(np.float64)*weights.astype(np.float64)[:,None]);center=terms.sum(axis=0,dtype=np.float64);error=(gamma(S-1)+gamma(S,U64))*np.abs(terms).sum(axis=0,dtype=np.float64)
                dot_check(label+'.weighted_combine',combined,center,error)
                square=float(np.dot(combined.astype(np.float64),combined.astype(np.float64)));err=(gamma(L-1)+gamma(L,U64))*square
                eps=float(np.float32(1e-5));norm_gamma=wide(source.array(cat,P+'routed_expert_norm.weight')).astype(np.float64)
                lowden=np.sqrt(max(0,square-err)/L+eps);highden=np.sqrt((square+err)/L+eps)
                a=combined.astype(np.float64)*norm_gamma
                low=np.minimum(a/lowden,a/highden);high=np.maximum(a/lowden,a/highden);extra=gamma(8)*np.maximum(np.abs(low),np.abs(high))
                interval_check(label+'.direct_gamma_RMSNorm',normalized,low-extra,high+extra)
                c,e=dense_reference(normalized,source.array(cat,P+'routed_expert_up_proj.weight'));dot_check(label+'.latent_up',routed,c,e)
                for name,actual in [('shared_gate',sg),('shared_up',su)]:
                    q=np.load(prepared/f'catalog{cat}-epoch{epoch}-{name}.npz');dot_check(label+'.'+name,actual,q['center'],q['error'])
                situ_check(label+'.shared_SiTU',sa,sg,su)
                c,e=stage_projection(source,cat,P+'shared_experts.down_proj',sa);dot_check(label+'.shared_down',shared,c,e)
                exact_check(label+'.final_add',final,bf(routed.astype(np.float64)+shared.astype(np.float64)))
                if cat==23:
                    q=np.load(prepared/f'catalog{cat}-epoch{epoch}-fp8.npz');interval_check(label+'.separate_FP8_outer',out(12,128),q['low'],q['high'])
                records.append(dict(catalog=cat,epoch=epoch,status='ALL_STAGES_NUMERIC_PASS',IDs=ids.tolist()))
        status='PASS_AUTHENTIC_SELECTED_COMPONENT_INDEPENDENT_CONDITIONAL_NUMERIC_AUDIT';failure=None
    except Exception as exc:
        status='FIRST_NUMERIC_OR_AUDIT_FAILURE';failure=dict(type=type(exc).__name__,message=str(exc))
    result=dict(status=status,seconds=time.time()-started,script_sha256=sha(__file__),source_index_sha256=sha(WORK/'source-roles.json'),actual_output_directory=str(base),records=records,checks=CHECKS,failure=failure,scope='Original dense/encoded publisher role bytes; generated hidden input; conditional stage references, not bitwise full-model oracle or quality/TPS result.')
    (base.parent/'numerical-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(status=status,checks=len(CHECKS),seconds=result['seconds'],failure=failure)))
    return 0 if failure is None else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--audit',type=Path);args=p.parse_args()
    if args.prepare:prepare()
    elif args.audit:sys.exit(audit(args.audit))
    else:p.error('expected --prepare or --audit RESULT_DIRECTORY')
