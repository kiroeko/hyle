from pathlib import Path
import ast,json,hashlib,zipfile
R=Path.cwd();C=R/'.scratch/kimi-publisher-router-20261025/component'
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
old=C/'reference-prepare-run1/reference-executed.py';current=C/'reference.py';frozen=C/'frozen/reference.py'
expected=json.loads((C/'reference-prepare-run1/process.json').read_bytes())['source_sha256']
assert pin(old)['sha256']==expected
assert current.read_bytes()==frozen.read_bytes()
a=ast.parse(old.read_text(encoding='utf-8-sig'));b=ast.parse(current.read_text(encoding='utf-8-sig'))
def nodes(tree):return {n.name:ast.dump(n,include_attributes=False)for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
na,nb=nodes(a),nodes(b);checks=[]
for name in na:
 assert name in nb and na[name]==nb[name],name
 checks.append(dict(name=name,AST_identical=True))
# All common non-definition assignments/imports preceding audit are identical;
# only the command-line dispatcher changed to add --audit.
def prefix(tree):
 out=[]
 for n in tree.body:
  if isinstance(n,ast.FunctionDef)and n.name=='interval_check':break
  if isinstance(n,ast.If)and isinstance(n.test,ast.Compare):break
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):continue
  if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='CHECKS'for x in n.targets):continue
  out.append(ast.dump(n,include_attributes=False))
 return out
assert prefix(a)==prefix(b)
references=[]
j=json.loads((C/'reference-prepared/summary.json').read_bytes())
for rec in j['records']:
 name=f"catalog{rec['catalog']}-epoch{rec['epoch']}-"+('fp8'if rec['stage']=='independent_fp8'else rec['stage'].replace('shared_','shared_'))
 # latent/shared labels are exactly save_reference names in the prepared manifest.
 p=C/'reference-prepared'/(rec.get('file')or name+'.npz')
 assert p.is_file(),p
 with zipfile.ZipFile(p)as z:members=[dict(name=i.filename,bytes=i.file_size,CRC=i.CRC)for i in z.infolist()]
 references.append(dict(catalog=rec['catalog'],epoch=rec['epoch'],stage=rec['stage'],values=rec['values'],payload=pin(p),npz_members=members))
for name in ('component.cc','original_source.h','original_roles.h'):
 assert (C/'source'/name).read_bytes()==(C/'frozen'/name).read_bytes()
result=dict(status='SOURCE_EQUIVALENCE_AND14_PREPARED_REFERENCES_VERIFIED_WITHOUT_RECOMPUTATION',executed_prepare_source=pin(old),actual_prepare_process=pin(C/'reference-prepare-run1/process.json'),current_executed_postprocess_source=pin(current),frozen_evidence_copy=pin(frozen),all_original_functions_classes_AST_identical=checks,common_imports_constants_AST_identical=True,static_prepared_records=references,counts=dict(prepared_records=len(references),functions_classes=len(checks)),runtime_note='Only component/reference.py is executable by the recorded plan. frozen/reference.py is a byte-identical source evidence copy at a different depth; do not execute it in place.',GPU=False,HTTP=False,compiler=False,references_recomputed=False)
(C/'reference-source-equivalence.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(status=result['status'],functions_classes=len(checks),references=len(references),postprocess_sha256=pin(current)['sha256'])))
