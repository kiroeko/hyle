$ErrorActionPreference = 'Stop'
$kimiTaskRoot = 'C:\public\project-hyle\hyle'
$kimiPauseMarker = Join-Path $kimiTaskRoot '.scratch/mtp-download-budget-20261023/PAUSED'
$kimiHeldMarker = Join-Path $PSScriptRoot 'download-paused-before-kimi-bulk'
$kimiRunDirectory = Join-Path $PSScriptRoot 'bulk-fetch-run1'
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ne (Join-Path $kimiTaskRoot '.scratch/kimi-publisher-router-20261025')) { throw 'Unexpected bulk acquisition directory' }
if (!(Test-Path -LiteralPath $kimiPauseMarker -PathType Leaf) -or (Test-Path -LiteralPath $kimiHeldMarker) -or (Test-Path -LiteralPath $kimiRunDirectory)) { throw 'Expected fresh bounded acquisition and unchanged pause marker' }
New-Item -ItemType Directory -Path $kimiRunDirectory | Out-Null
$kimiCommand = @('python',(Join-Path $kimiTaskRoot '.scratch/mtp-download-budget-20261023/budget.py'),'run',(Join-Path $PSScriptRoot 'fetch-bulk.py'))
@{command=$kimiCommand;cwd=$kimiTaskRoot;parent_pid=$PID;automatic_retries=0} | ConvertTo-Json | Set-Content (Join-Path $kimiRunDirectory 'command.json') -Encoding utf8
$kimiClock = [System.Diagnostics.Stopwatch]::StartNew()
$kimiExit = -1
Move-Item -LiteralPath $kimiPauseMarker -Destination $kimiHeldMarker
try {
  & python (Join-Path $kimiTaskRoot '.scratch/mtp-download-budget-20261023/budget.py') run (Join-Path $PSScriptRoot 'fetch-bulk.py') 1> (Join-Path $kimiRunDirectory 'stdout.log') 2> (Join-Path $kimiRunDirectory 'stderr.log')
  $kimiExit = $LASTEXITCODE
  if ($kimiExit -ne 0) { throw "Planned Kimi bulk acquisition failed, exit $kimiExit; partial evidence retained, no retry" }
} finally {
  $kimiClock.Stop()
  if ((Test-Path -LiteralPath $kimiPauseMarker) -or !(Test-Path -LiteralPath $kimiHeldMarker -PathType Leaf)) { throw 'Pause marker changed during bulk acquisition' }
  Move-Item -LiteralPath $kimiHeldMarker -Destination $kimiPauseMarker
  @{exit=$kimiExit;seconds=$kimiClock.Elapsed.TotalSeconds;timeout=$false;PAUSED_restored=$true} | ConvertTo-Json | Set-Content (Join-Path $kimiRunDirectory 'process.json') -Encoding utf8
}
