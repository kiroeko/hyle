from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,importlib.util,inspect,json,struct,sys,urllib.request
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/mtp-download-budget-20261023/budget.py';F=R/'.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py';SCRIPT=Path(__file__).resolve().relative_to(R).as_posix()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def main():
 plan=json.loads((W/'phase2-k512-shapes-only-plan.json').read_bytes());assert plan['bytes']==768 and plan['request_count']==15 and plan['logical_roles']==48
 assert sha(B.read_bytes())=='24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17'and sha(F.read_bytes())=='3dc89fb1efc369615d7a3132bd08b3aabcf125259498b5f8581cec83d559a7da'
 spec=importlib.util.spec_from_file_location('kimi_retained_shape_transport',F);transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport);transport.SCRIPT=SCRIPT;budget=transport.module();budget.require_enabled();guard=urllib.request.urlopen;assert Path(guard.__code__.co_filename).resolve()==B.resolve()and inspect.getclosurevars(guard).nonlocals['script']==SCRIPT
 output=W/'shape-payload';output.mkdir(exist_ok=False);save(output/'source.json',dict(plan_sha256=sha((W/'phase2-k512-shapes-only-plan.json').read_bytes()),scope='Only48 original I64[2] metadata tensors; no expert weight/scale/static body.',whole_LFS_hash_verified=False))
 def fetch(item):
  assert item['bytes']==item['last']-item['first']+1==sum(r['bytes']for r in item['roles'])
  folder=output/f'request-{item["ordinal"]:02d}';folder.mkdir();row=dict(repository='open-inference/Kimi-K3-W4A8-K512-GPTQ-Mixed-Cal72-Seq1024',revision=item['revision'],file='quant-layer-001.safetensors',uri=item['url']);client=transport.Fetch(budget,row,timeout=45,receipt_dir=folder)
  raw,response=client.get(item['first'],item['last'],source=dict(size=item['source_bytes'],etag=item['source_etag']));p=output/f'shape-{item["ordinal"]:02d}.bin';p.write_bytes(raw);checked=[]
  for role in item['roles']:
   at=role['first']-item['first'];value=list(struct.unpack('<qq',raw[at:at+16]));checked.append(dict(role=role['role'],global_expert=role['global_expert'],actual_I64_values=value,expected_I64_values=role['expected_original_I64_values'],matches=value==role['expected_original_I64_values']))
  result=dict(ordinal=item['ordinal'],path=p.relative_to(R).as_posix(),range=[item['first'],item['last']],bytes=len(raw),sha256=sha(raw),response=response,checked=checked);save(folder/'complete.json',result)
  assert all(r['matches']for r in checked),'Original selected K512 I64 values differ from packed/scales/contract geometry'
  return result
 completed=[];failure=None
 with ThreadPoolExecutor(max_workers=4)as pool:
  futures=[pool.submit(fetch,item)for item in plan['requests']]
  try:
   for future in as_completed(futures):
    completed.append(future.result());completed.sort(key=lambda x:x['ordinal']);save(output/'verified-parts.json',dict(complete=False,parts=completed))
  except BaseException as e:
   failure=e
   for f in futures:f.cancel()
   save(output/'failed.json',dict(status='FIRST_FAILURE_PRESERVED_NO_RETRY',error_type=type(e).__name__,error=str(e)))
 if failure:raise failure
 assert len(completed)==15 and sum(x['bytes']for x in completed)==768 and sum(len(x['checked'])for x in completed)==48
 result=dict(status='ALL48_ORIGINAL_SELECTED_K512_I64_SHAPES_VERIFIED',parts=completed,original_metadata_bytes=768,HTTP_requests=15,checked_shapes=48,only_HTTPS_host='hf-mirror.net',whole_LFS_hash_verified=False,bulk_weight_scale_static_bytes=0,GPU_started=False)
 save(output/'complete.json',result);print(json.dumps({k:v for k,v in result.items()if k!='parts'}),flush=True)
if __name__=='__main__':main()
