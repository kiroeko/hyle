from pathlib import Path
import json,hashlib,mmap
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025'
def read(p):return json.loads(p.read_bytes())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
plan=read(W/'phase2-execution-plan.json');complete=read(W/'bulk-payload/complete.json');shapes=read(W/'shape-payload/complete.json');router=read(W/'payload/complete.json');assert complete['bytes']==1090009600 and len(complete['parts'])==57
# Once-per-source-part SHA after terminal acquisition; avoid copying large banks.
for part in complete['parts']+shapes['parts']+router['parts']:
 p=R/part['path'];q=pin(p);assert q['bytes']==part['bytes']and q['sha256']==part['sha256'];assert part['response']['status']==206 and part['response']['final_url'].startswith('https://hf-mirror.net/')
index=[]
def add_role(catalog,name,dtype,shape,first,last,parts):
 pieces=[];position=first;digest=hashlib.sha256()
 for part in sorted(parts,key=lambda x:x['range'][0]):
  a,b=part['range'];start=max(first,a);end=min(last,b)
  if start>end:continue
  assert start==position,'Missing/overlapping source role interval';offset=start-a;size=end-start+1;path=R/part['path']
  with path.open('rb')as source,mmap.mmap(source.fileno(),0,access=mmap.ACCESS_READ)as mm:digest.update(mm[offset:offset+size])
  pieces.append(dict(path=part['path'],offset=offset,bytes=size,source_absolute_range=[start,end],source_part_sha256=part['sha256']));position=end+1
 assert position==last+1 and sum(x['bytes']for x in pieces)==last-first+1
 index.append(dict(catalog_index=catalog,name=name,dtype=dtype,physical_shape=shape,original_absolute_range=[first,last],bytes=last-first+1,role_sha256=digest.hexdigest(),pieces=pieces))
for role in plan['logical_roles']:
 add_role(role['catalog_index'],role['role'],role['dtype'],role['physical_shape'],role['first'],role['last'],[p for p in complete['parts']if p['catalog_index']==role['catalog_index']])
for part in shapes['parts']:
 for checked in part['checked']:
  row=next(r for r in read(W/'phase2-derived-plan.json')['logical_roles']if r['role']==checked['role']and r['catalog_index']==24)
  add_role(24,row['role'],'I64',[2],row['first'],row['last'],shapes['parts'])
for part in router['parts']:add_role(part['catalog_index'],part['role'],part['dtype'],part['shape'],*part['range'],[part])
assert len(index)==261 and len({(x['catalog_index'],x['name'])for x in index})==261
ledger=read(R/'.scratch/mtp-download-budget-20261023/budget.json');attempts=[r for r in ledger['requests']if r['script']=='.scratch/kimi-publisher-router-20261025/fetch-bulk.py'];assert len(attempts)==57 and sum(r['received_bytes']for r in attempts)==1090009600 and all(r['outcome']=='downloaded'and r['received_bytes']==r['bytes']and r['final_host']=='hf-mirror.net'for r in attempts)
assert(R/'.scratch/mtp-download-budget-20261023/PAUSED').is_file()and not(W/'download-paused-before-kimi-bulk').exists()
summary=dict(status='ALL_REQUIRED_SOURCE_PARTS_AND261_ROLE_VIEWS_SHA_VERIFIED',original_source_parts=len(complete['parts'])+len(shapes['parts'])+len(router['parts']),logical_roles=261,numeric_role_bodies_bytes=1090009600,verified_I64_metadata_bytes_reused=768,previous_router_and_bias_bytes_reused=25697280,total_original_range_bytes=1115707648,bulk_attempts=57,bulk_received_bytes=1090009600,bulk_retries=0,process=read(W/'bulk-fetch-run1/process.json'),all_initial_and_final_hosts='https://hf-mirror.net',whole_LFS_hash_verified=False,PAUSED_restored=True,GPU_component_executed=False,body_assembly_files_created=0,banks_decoded_or_generated=False,roles=index)
save(W/'source-roles.json',summary);save(W/'bulk-fetch-summary.json',{k:v for k,v in summary.items()if k!='roles'});print(json.dumps({k:v for k,v in summary.items()if k!='roles'},indent=2))
