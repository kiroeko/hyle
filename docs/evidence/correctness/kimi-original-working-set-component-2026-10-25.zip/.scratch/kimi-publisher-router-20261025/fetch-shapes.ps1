$ErrorActionPreference = 'Stop'
$kimiTaskRoot = 'C:\public\project-hyle\hyle'
$kimiPauseMarker = Join-Path $kimiTaskRoot '.scratch/mtp-download-budget-20261023/PAUSED'
$kimiHeldMarker = Join-Path $PSScriptRoot 'download-paused-before-kimi-shapes'
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ne (Join-Path $kimiTaskRoot '.scratch/kimi-publisher-router-20261025')) { throw 'Unexpected shape acquisition directory' }
if (!(Test-Path -LiteralPath $kimiPauseMarker -PathType Leaf) -or (Test-Path -LiteralPath $kimiHeldMarker)) { throw 'Expected unchanged pause marker' }
Move-Item -LiteralPath $kimiPauseMarker -Destination $kimiHeldMarker
try {
  & python (Join-Path $kimiTaskRoot '.scratch/mtp-download-budget-20261023/budget.py') run (Join-Path $PSScriptRoot 'fetch-shapes.py')
  if ($LASTEXITCODE -ne 0) { throw "Planned Kimi shape acquisition failed, exit $LASTEXITCODE; partial evidence retained" }
} finally {
  if ((Test-Path -LiteralPath $kimiPauseMarker) -or !(Test-Path -LiteralPath $kimiHeldMarker -PathType Leaf)) { throw 'Pause marker changed during shape acquisition' }
  Move-Item -LiteralPath $kimiHeldMarker -Destination $kimiPauseMarker
}
