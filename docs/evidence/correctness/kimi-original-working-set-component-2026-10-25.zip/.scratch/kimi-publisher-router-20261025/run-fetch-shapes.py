from pathlib import Path
import sys,os,importlib.util
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.execute(['C:/Program Files/PowerShell/7/pwsh.exe','-NoProfile','-File',str(W/'fetch-shapes.ps1')],W/'shape-fetch-run1',os.environ.copy(),180)
