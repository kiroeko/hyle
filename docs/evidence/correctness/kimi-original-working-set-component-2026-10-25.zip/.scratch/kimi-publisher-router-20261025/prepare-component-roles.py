from pathlib import Path
import json,hashlib
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025';C=W/'component';S=C/'source';S.mkdir(parents=True,exist_ok=True);index=json.loads((W/'source-roles.json').read_bytes());assert len(index['roles'])==261
T={'BF16':'kBFloat16','F32':'kFloat32','U8':'kUInt8','I32':'kInt32','I64':'kInt64','F8_E4M3':'kFloat8E4M3FN'}
lines=['#pragma once','#include <array>','#include <span>','#include <string_view>','#include "hyle/compute/tensor_desc.h"','namespace original_kimi_roles {','namespace c=hyle::compute;','struct Piece {std::string_view path;std::size_t offset,bytes;};','struct Role {int catalog;std::string_view name;c::DataType type;std::array<std::int64_t,2> shape;std::size_t rank,bytes;std::string_view sha256;std::span<const Piece> pieces;};']
for j,row in enumerate(index['roles']):
 lines.append(f'inline constexpr std::array<Piece,{len(row["pieces"])}> p{j}{{{{')
 for piece in row['pieces']:lines.append('{'+json.dumps(piece['path'])+','+str(piece['offset'])+','+str(piece['bytes'])+'},')
 lines.append('}};')
lines.append('inline constexpr std::array<Role,261> roles{{')
for j,row in enumerate(index['roles']):
 shape=row['physical_shape'];assert 1<=len(shape)<=2;shape=shape+[0]*(2-len(shape));lines.append('{'+str(row['catalog_index'])+','+json.dumps(row['name'])+',c::DataType::'+T[row['dtype']]+',{'+','.join(map(str,shape))+'},'+str(len(row['physical_shape']))+','+str(row['bytes'])+','+json.dumps(row['role_sha256'])+',p'+str(j)+'},')
lines+=['}};','} // namespace original_kimi_roles'];p=S/'original_roles.h';p.write_text('\n'.join(lines)+'\n',encoding='utf8')
(C/'source-plan.json').write_text(json.dumps(dict(status='PRIVATE_AUTHENTIC_COMPONENT_SOURCE_PREPARATION_NO_GPU',source_index_sha256=hashlib.sha256((W/'source-roles.json').read_bytes()).hexdigest(),generated_role_header=dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),numeric_role_bytes_expanded=False,roles=261,scope='Source identity/typed bytes only; no alternate supplier, decoder, IR or model engine. Cold role byte assembly does not dequantize.'),indent=2)+'\n',encoding='utf8')
