import difflib
from pathlib import Path
import re

root = Path(__file__).resolve().parents[3]
stage = Path(__file__).resolve().parent
name = 'tests/compute_models/grouped_fp8_power2_fixture.h'
target = root / name
before = target.read_bytes()
backup = stage / 'fixture-before' / name
backup.parent.mkdir(parents=True, exist_ok=True)
assert not backup.exists()
backup.write_bytes(before)
text = before.decode().replace('\r\n', '\n')
text = re.sub(r'\bRounding\b', 'Policy', text)
text = re.sub(r'\brounding\b', 'scale_policy', text)
text = text.replace('floor(policy==Policy::kDivide?1.e-10F:1.e-4F)',
                    'floor(policy==Policy::kPowerOfTwo?1.e-4F:1.e-10F)')
text = text.replace('d.a[base+1]=scalar::bf16(phase%2?-secondary[pattern]:secondary[pattern]);',
    'const auto entry=scale_policy==Policy::kMultiplyReciprocal&&pattern==4?\n'
    '          .006866455078125F:secondary[pattern];\n'
    '      d.a[base+1]=scalar::bf16(phase%2?-entry:entry);')
text = text.replace('    int exponent=0;const auto fraction=std::frexp(raw,&exponent);',
                    '    if (policy==Policy::kMultiplyReciprocal) return raw;\n'
                    '    int exponent=0;const auto fraction=std::frexp(raw,&exponent);')
text = text.replace('const auto normalized=scalar::f32(double(scalar::wide(d.a[base+k]))/double(sa));',
    'const auto normalized=scale_policy==Policy::kMultiplyReciprocal&&!wrong_none\n'
    '            ?scalar::multiply(scalar::wide(d.a[base+k]),scalar::f32(1./double(sa)))\n'
    '            :scalar::f32(double(scalar::wide(d.a[base+k]))/double(sa));')
text = text.replace('void run(m::MemoryResourceRef resource,std::span<const g::QueueBinding> queues,\n'
    '         Compile compile,Write write,Read read,Prepare prepare,c::StorageOwner owner={},bool ordinary=false) {',
    'void run_with_policy(m::MemoryResourceRef resource,std::span<const g::QueueBinding> queues,\n'
    '         Compile compile,Write write,Read read,Prepare prepare,c::StorageOwner owner,Policy policy) {')
text = text.replace('<<"shared="<<shared<<" ordinary="<<ordinary', '<<"shared="<<shared<<" policy="<<unsigned(policy)')
text = text.replace('Case f(shared,ordinary?Policy::kDivide:Policy::kPowerOfTwo);\n    if (!ordinary) {',
                    'Case f(shared,policy);\n    if (policy==Policy::kPowerOfTwo) {')
anchor = '    auto bound=constant(f,resource,write,owner);'
text = text.replace(anchor,
    '    if (policy==Policy::kMultiplyReciprocal) {\n'
    '      const auto d=f.data(2);const auto y=f.oracle(d);const auto wrong=f.oracle(d,false,true);\n'
    '      ASSERT_NE(y,wrong);ASSERT_EQ(y[0],0x3bc1U);ASSERT_EQ(wrong[0],0x3c01U);\n'
    '    }\n' + anchor, 1)
marker = 'template<class Compile,class Write,class Read,class Prepare>\nvoid run_checked_ids('
wrapper = ('template<class Compile,class Write,class Read,class Prepare>\n'
    'void run(m::MemoryResourceRef resource,std::span<const g::QueueBinding> queues,\n'
    '         Compile compile,Write write,Read read,Prepare prepare,c::StorageOwner owner={},bool ordinary=false) {\n'
    '  run_with_policy(resource,queues,compile,write,read,prepare,owner,\n'
    '      ordinary?Policy::kDivide:Policy::kPowerOfTwo);\n'
    '}\n\n')
assert marker in text
text = text.replace(marker, wrapper + marker)
text = text.replace('Compile compile,Write write,Read read,Prepare prepare,c::StorageOwner owner={}) {\n  Case f(false);',
                    'Compile compile,Write write,Read read,Prepare prepare,c::StorageOwner owner={},\n'
                    '                     Policy policy=Policy::kPowerOfTwo) {\n  Case f(false,policy);')
assert 'ordinary' not in text[:text.index(wrapper)]
target.write_text(text, encoding='utf-8', newline='\n')
(stage / 'grouped-fixture.diff').write_text(''.join(difflib.unified_diff(
    before.decode().replace('\r\n','\n').splitlines(True),text.splitlines(True),
    fromfile='before/'+name,tofile='after/'+name)),encoding='utf-8')
print('updated ' + name)
