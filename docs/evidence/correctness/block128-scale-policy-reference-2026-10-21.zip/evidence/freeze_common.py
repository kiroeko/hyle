import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
stage = Path(__file__).resolve().parent
names = ['include/hyle/compute/model_ops.h',
         'src/compute_provider_native/torch_cpu_program.cc',
         'tests/compute_ops/operation_test.cc',
         'tests/compute_models/grouped_fp8_power2_fixture.h',
         'tests/compute_models/fp8_scale_policy_fixture.h']
inventory = []
for name in names:
    data = (root / name).read_bytes()
    dest = stage / 'common-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    inventory.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
header_name = '.scratch/architecture-refactor-2026-10-18/quark-mxfp4-contract-review/artifact/30/model-00001-of-00062.safetensors/header.json'
header_bytes = (root / header_name).read_bytes()
header = json.loads(header_bytes)
weight_key = 'model.language_model.layers.45.mlp.experts.0.gate_proj.weight'
scale_key = weight_key.replace('.weight', '.weight_scale')
assert header[weight_key]['shape'] == [2048,4096] and header[weight_key]['dtype'] == 'F8_E4M3'
assert header[scale_key]['shape'] == [16,32] and header[scale_key]['dtype'] == 'F32'
report = {
    'status': 'common/CPU/schema and shared fixtures source frozen; not built or executed by this owner',
    'sources': inventory,
    'API': {'header': 'tests/compute_models/fp8_scale_policy_fixture.h',
            'namespace': 'fp8_scale_policy_test',
            'functions': ['run_dense','run_source_role','run_grouped','run_checked_ids'],
            'signature': '(resource,queues,compile,write,read,prepare,owner={})',
            'planned_submissions': {'run_dense': 12,'run_source_role': 4,'run_grouped': 8,
                                    'run_checked_ids': {'success': 3,'expected_failed_completion': 2}}},
    'fixture_equations': 'Independent original scalar E4 table and BF16 bit helpers; original grouped oracle scale helper is shared by new dense reference. New policy uses F32 multiply-reciprocal formation and separate reciprocal-multiply normalization. Source sparse one-term code dots avoid reduction-tree ambiguity; group sums retain fixed F32 order.',
    'legacy': 'grouped_fp8_power2_test::run and run_checked_ids keep old default PowerOfTwo, and run(...ordinary=true) remains Divide. Existing payload/oracle paths are unchanged for0/1 apart from names. New450/tiny entry is conditional on policy2 only.',
    'witness': {'maximum_BF16': 450, 'secondary_BF16': 0.006866455078125,
                'divide_scale': '3f809249','multiply_reciprocal_scale':'3f80924a',
                'divide_code':'04','multiply_reciprocal_code':'03',
                'final_BF16': {'Divide':'3c01','MultiplyReciprocal':'3bc1'},
                'weight': 'E4code38(+1),F32SF1'},
    'actual_role': {'catalog': 30,'repository':'amd/GLM-5.3-Flash-Quark-MXFP4',
                   'revision':'b5688f25491202978c19c4d036eef579f61bbe07',
                   'header': {'path':header_name,'bytes':len(header_bytes),'sha256':hashlib.sha256(header_bytes).hexdigest()},
                   'weight_key':weight_key,'weight_entry':header[weight_key],
                   'scale_key':scale_key,'scale_entry':header[scale_key],
                   'logical_linear_weight':'[K,N]=[4096,2048];original code plane remains stored row-major[N,K]',
                   'carrier':'8388608 E4bytes + 2048 F32SFbytes = 8390656B',
                   'scale_interpretation':'F32 multipliers indexed [ceil(N/128),K/128], no E8 reinterpretation or BF16 scale pre-cast',
                   'reference':'M1,policy2 only, finite artificial code/SF bytes, no checkpoint numerical payload read'},
    'resources': 'New dense reference reuses original Graph constant/ReadLease and two real invocations with two generations, retained old results and owner destruction checks. Grouped and invalid-ID recovery reuse the existing original helpers. CPU retains original per-block weight decode; no whole float weight bank added.',
    'upload_note': 'Actual-role bank is8390656B; use the wrapper existing bounded/chunked write helper if a backend transfer staging limit is4MiB. No hidden source prepacking or public capacity increase.',
    'not_verified': ['No CXX/link/NVCC/GPU execution by this owner.',
                     'Artificial bytes at fixed header geometry do not certify checkpoint payload/model/quality.',
                     'Strict-F32 reference does not certify AMD approximate rcpf or all tuned block GEMM epilogues.']
}
(stage / 'common-source-freeze.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'sources':inventory, 'header_sha256':hashlib.sha256(header_bytes).hexdigest()},indent=2))
