"""Compile only the shared-prologue test and link a dedicated current-product image; never run."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
Z = D.parent
spec = importlib.util.spec_from_file_location('z_host_helpers', Z / 'windows/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R = h.b, h.c, h.R

def main():
    recipe = Z.parent / 'fp8-shared-prologue/checks/host1/graph_route_cuda--fp8_shared_prologue_test-identity.json'
    original = c.read(recipe)
    base_path = Z / 'cuda/checks/link1/link-plan.json'
    plan = c.read(base_path)
    old_test = c.read(Z / 'windows/checks/attempt1/cuda-scale-policy-test/identity.json')['object']
    row = dict(source=b.identity(R / 'tests/graph_route_cuda/fp8_shared_prologue_test.cc'),
               command=original['command'], old_object=old_test, recipe=b.identity(recipe))
    record = h.compile_one('cuda-shared-prologue-test', row, 'pair1', [row['source']])
    assert all(h.same(item) for item in plan['inputs'])
    assert sum(c.key(item['path']) == c.key(old_test['path']) for item in plan['inputs']) == 1
    inputs = [record['object'] if c.key(item['path']) == c.key(old_test['path']) else item for item in plan['inputs']]
    command = [record['object']['path'] if c.key(arg) == c.key(old_test['path']) else arg
               for arg in plan['command']
               if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = D / 'checks/link1'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / 'cuda-pair.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    arguments = [arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ['.obj', '.lib']]
    assert list(map(c.key, arguments)) == [c.key(item['path']) for item in inputs]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path),
        replacements=[dict(source=record['source'], old_object=old_test, object=record['object'])],
        GPU_runs=0, SDK_builds=0))
    env, runtime = b.environment(command, [item['path'] for item in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    names = ['MultiplyReciprocalBfloatSiblingsKeepTheirOriginalQuantizerAcrossCapturedSlots',
             'BfloatSiblingsKeepBothOriginalLinearResultsAcrossCapturedSlots',
             'DifferentContractsOrValueIdsAndPackedSingleLinearStayStandalone']
    ready = dict(status='one_test_CXX_one_link_ready_not_executed', image=b.identity(image),
        link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        filter=':'.join('CudaFp8SharedPrologue.' + name for name in names), expected_tests=3,
        CXX=1, links=1, NVCC=0, SDK_builds=0, agent_GPU_runs=0)
    c.save(D / 'ready-for-root-run.json', ready)
    print(str(D / 'ready-for-root-run.json'), flush=True)

if __name__ == '__main__':
    main()
