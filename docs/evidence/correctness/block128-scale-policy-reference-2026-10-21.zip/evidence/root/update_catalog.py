"""Record the bounded GLM block128 reference without claiming artifact execution."""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[4]
path=R/'docs/implementation/model-quantizations.json'
document=json.loads(path.read_text('utf-8'))
evidence='docs/evidence/correctness/block128-scale-policy-reference-2026-10-21.json'
assert (R/evidence).is_file(),'Publish only after actual final package exists'
result=json.loads((R/evidence).read_text('utf-8'))

def rename(value):
    if isinstance(value,str):
        return value.replace('Float8ScaleRounding','Float8ScalePolicy').replace('scale_rounding','scale_policy')
    if isinstance(value,list):return [rename(x) for x in value]
    if isinstance(value,dict):return {k:rename(v) for k,v in value.items()}
    return value
document=rename(document)
artifact=next(a for a in document['artifacts'] if a['repository']=='amd/GLM-5.3-Flash-Quark-MXFP4')
coverage=artifact['provider_coverage']
coverage['mapping_status']='Portable original group32 MXFP4 dense/grouped primitives remain supported. The separate FP8 block128 overrides now have explicit MultiplyReciprocal scale policy and four-backend finite source-role geometry checks. Exact payload/import, remaining roles, bounded mixed working-set journey and whole artifact execution remain unverified.'
role=next(r for r in coverage['role_domains'] if r['role']=='FP8 role overrides')
role['observed']+=' Pinned recommended SGLang/Aiter forms scale with F32(max(absmax,1e-10)*F32(1/448)), then separately rounds F32(1/scale) and F32(A*inverse). Float8ScalePolicy::kMultiplyReciprocal preserves these stages without BF16 intermediates.'
role['evidence']=evidence
role['unresolved']='Finite artificial E4/F32 bytes at layer45 expert0 gate_proj N2048/K4096, not original checkpoint values, every override, complete MTP/model, AMD approximate reciprocal/GEMM equivalence, Linux or throughput.'
coverage['missing_capabilities']=[
    'Exact mixed Quark MXFP4/FP8 bank import and bounded working-set consumer journey; generic slice assembly and atomic bank binding are implemented, without this codec-specific resource journey',
    'Remaining exact GLM mixed MXFP4/FP8-block128/BF16 payload/import and complete role bindings; the selected dynamic FP8 scale policy itself is implemented']
coverage['artifact_unaligned_or_unverified']=[
    'The924 FP8 overrides remain separate from MXFP4 and are not all-layer FP8. Pinned scale policy and a finite layer45 expert0 geometry now execute on four backends; other roles and numerical payload bindings remain unverified' if item.startswith('The924 FP8 override') else item
    for item in coverage['artifact_unaligned_or_unverified']]
coverage['reachable_entry_points'].append(dict(
    operation='float8_block_linear / grouped_float8_linear(Float8ScalePolicy::kMultiplyReciprocal,1e-10F)',
    execution='Dynamic group128 F32 scale multiply, separate reciprocal and normalization multiply; original E4 W and F32 macroblock128 SF; shared grouped A quantized once per token',
    providers=['CPU native ATen','CUDA SM89 quantizer plus original dense/grouped GEMMs','Apple native Metal/MLX','Vulkan official native program'],
    evidence=evidence,
    qualification='Finite BF16 primitive, exact source-role geometry, old policies, checked failures, two slots/old results. No whole-artifact/payload, Linux, full F32 domain, AMD reciprocal/GEMM or throughput claim.'))
coverage['fp8_block128_scale_reference']=dict(evidence=evidence,
    finite_role='layer45.mlp.experts.0.gate_proj:M1,N2048,K4096,E4W/F32SF[16,32]',
    original_payload=False,artifact_execution_verified=False,
    scale_policy='Float8ScalePolicy::kMultiplyReciprocal',
    domain='Existing positive normal floor/448 admission retained; public dense and grouped descriptors remain8bytes with new typed IDs; no compatibility alias')
if not any(r.get('evidence')==evidence for r in document['followup_reviews']):
    document['followup_reviews'].append(dict(observed_on='2026-10-21',evidence=evidence,artifact_indices=[30],
        scope='Explicit dynamic block128 multiply-reciprocal policy and finite synthetic fixed-role geometry on four backends; separate CUDA shared-prologue regression, no whole artifact.',
        artifact_execution_verified=False))
assert len(document['artifacts'])==33
assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in document['artifacts'])
path.write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Updated catalog30 and current public names; all33 whole-artifact execution flags remain false.')
