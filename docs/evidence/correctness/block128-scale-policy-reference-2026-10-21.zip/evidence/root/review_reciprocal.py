"""Independent integer-rational check of the new Vulkan normal-SF reciprocal."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,random

S=Path(__file__).resolve().parent
R=S.parents[3]
source=R/'third_party/iree_vulkan_runtime/programs/generate_official.py'

def shader_model(bits):
    m=(bits&0x7fffff)|0x800000
    e=bits>>23
    exact=m==0x800000
    numerator=0x800000 if exact else 0x1000000
    out_e=(254 if exact else 253)-e
    q,r=1,numerator-m
    for _ in range(23):
        r<<=1
        bit=r>=m
        r-=m if bit else 0
        q=(q<<1)|int(bit)
        assert 0<=r<m and r<0x1000000
    q+=int(2*r>m or (2*r==m and q&1))
    if q>=0x1000000:q>>=1;out_e+=1
    assert 1<=out_e<=254
    return (out_e<<23)|(q&0x7fffff)

def exact_reference(bits):
    m=(bits&0x7fffff)|0x800000
    e=(bits>>23)-150
    x=Fraction(m,1)*(Fraction(2)**e)
    inverse=1/x
    exponent=inverse.numerator.bit_length()-inverse.denominator.bit_length()
    if inverse<Fraction(2)**exponent:exponent-=1
    significand=inverse/(Fraction(2)**(exponent-23))
    q,r=divmod(significand.numerator,significand.denominator)
    q+=int(2*r>significand.denominator or (2*r==significand.denominator and q&1))
    if q==0x1000000:q>>=1;exponent+=1
    assert 0x800000<=q<0x1000000 and -126<=exponent<=127
    return ((exponent+127)<<23)|(q&0x7fffff)

def main():
    boundary=[0,1,2,3,0x1fffff,0x200000,0x3ffffe,0x3fffff,
              0x400000,0x400001,0x7ffffd,0x7ffffe,0x7fffff]
    inputs={e<<23|m for e in range(1,247) for m in boundary}
    rng=random.Random(20261021)
    inputs.update(rng.randrange(1,247)<<23|rng.randrange(0x800000) for _ in range(8192))
    for value in sorted(inputs):
        actual,expected=shader_model(value),exact_reference(value)
        assert actual==expected,(hex(value),hex(actual),hex(expected))
    report=dict(passed=True,checked=len(inputs),seed=20261021,
        source=dict(path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
        scope='Independent Fraction-based finite host check of U32 reciprocal; not exhaustive/device/F32-input execution',
        normal_scale_exponent_domain=[1,246],
        domain_reason='Existing floor/448 must be normal; multiply by RNE(1/448) is no smaller. Finite F32 max times reciprocal448 has exponent at most 246; its reciprocal remains normal.',
        bounds='Remainder < significand < 2^24; shifted remainder < 2^25; no U32 overflow.',
        script=dict(path=str(Path(__file__).resolve()),sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    out=S/'reciprocal-review.json'
    out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))

if __name__=='__main__':main()
