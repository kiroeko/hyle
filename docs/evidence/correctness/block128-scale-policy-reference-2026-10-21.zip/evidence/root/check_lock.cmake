get_filename_component(repo "${CMAKE_CURRENT_LIST_DIR}/../../../.." ABSOLUTE)
include("${repo}/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(sglang_activation iree_vulkan_runtime_patches)
message(STATUS "The two changed vendored source trees and license records match the lock")
