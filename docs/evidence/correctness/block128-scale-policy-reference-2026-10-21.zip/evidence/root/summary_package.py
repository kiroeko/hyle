"""Summarize actual finite runs and publish their small, reproducible evidence.

--check writes only a scratch preview. --publish writes the final JSON/ZIP.
The caller supplies final extra-run paths after those runs actually finish.
No build, GPU execution, cleanup, or product-document editing is performed.
"""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

P=Path(__file__).resolve().parent.parent
R=P.parents[2]
OUT=R/'docs/evidence/correctness'
NAME='block128-scale-policy-reference-2026-10-21'

def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(Path(p).read_text('utf-8'))
def relative(p):return Path(p).resolve().relative_to(R).as_posix()
def ident(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=relative(p),bytes=len(b),sha256=sha(b))
def save(p,value):
    Path(p).parent.mkdir(parents=True,exist_ok=True)
    Path(p).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def stage_path(text):
    p=Path(text)
    if p.is_absolute():return p
    return (R/p if text.startswith(('.scratch/','docs/','include/','src/','tests/','cmake/','third_party/')) else P/p)

MAIN_CASES={
 'cpu':[
  ('CpuFp8ScalePolicy.ThreePoliciesKeepDistinctFiniteQuantizers','new',12,0),
  ('CpuFp8ScalePolicy.FixedHeaderRoleKeepsOriginalBlockAxes','new',4,0),
  ('CpuFp8ScalePolicy.GroupedSharedAndPerSlotInputsKeepReciprocalPolicy','new',8,0),
  ('CpuFp8ScalePolicy.InvalidIdsFailAndFreshInvocationRecovers','new',3,2),
  ('CpuFp8ScalePolicy.OriginalPowerOfTwoNeighbor','neighbor',8,0),
  ('CpuFp8ScalePolicy.OriginalDivideNeighbor','neighbor',8,0)],
 'cuda':[
  ('CudaFp8ScalePolicy.ThreePoliciesKeepDistinctFiniteQuantizers','new',12,0),
  ('CudaFp8ScalePolicy.FixedHeaderRoleKeepsOriginalBlockAxes','new',4,0),
  ('CudaFp8ScalePolicy.GroupedSharedAndPerSlotInputsKeepReciprocalPolicy','new',8,0),
  ('CudaFp8ScalePolicy.InvalidIdsFailAndFreshInvocationRecovers','new',3,2),
  ('CudaFp8ScalePolicy.OriginalPowerOfTwoNeighbor','neighbor',8,0),
  ('CudaFp8ScalePolicy.OriginalDivideNeighbor','neighbor',8,0)],
 'vulkan':[
  ('VulkanFp8ScalePolicy.ThreePoliciesKeepDistinctFiniteQuantizers','new',12,0),
  ('VulkanFp8ScalePolicy.FixedHeaderRoleKeepsOriginalBlockAxes','new',4,0),
  ('VulkanFp8ScalePolicy.GroupedSharedAndPerSlotInputsKeepReciprocalPolicy','new',8,0),
  ('VulkanFp8ScalePolicy.InvalidIdsFailAndFreshInvocationRecovers','new',3,2),
  ('VulkanFp8ScalePolicy.OriginalPowerOfTwoNeighbor','neighbor',8,0),
  ('VulkanFp8ScalePolicy.OriginalDivideNeighbor','neighbor',8,0)],
 'apple':[
  ('AppleFp8ScalePolicy.DensePoliciesKeepSeparateRoundingTrees','new',12,0),
  ('AppleFp8ScalePolicy.FixedSourceRoleKeepsOriginalBlock128Bank','new',4,0),
  ('AppleFp8ScalePolicy.GroupedReciprocalMathRetainsOldResults','new',8,0),
  ('AppleFp8ScalePolicy.CheckedIdsFailAndFreshInvocationRecovers','new',3,2),
  ('AppleFp8ScalePolicy.OriginalGroupedPowerKeepsItsQuantizer','neighbor',8,0),
  ('AppleFp8ScalePolicy.OriginalGroupedDivideKeepsItsQuantizer','neighbor',8,0)]}

def parse_run(arm,xml,receipt,expected):
    xml=stage_path(xml);receipt=stage_path(receipt)
    actual=ET.parse(xml).findall('.//testcase')
    wanted={r[0]:r for r in expected}
    assert len(wanted)==len(expected)
    assert len(actual)==len(expected),(arm,len(actual),len(expected))
    records=[]
    for case in actual:
        name=case.get('classname')+'.'+case.get('name')
        assert name in wanted and not case.findall('failure') and not case.findall('skipped'),name
        assert case.get('status')=='run' and case.get('result')=='completed',case.attrib
        props={p.get('name'):p.get('value') for p in case.findall('properties/property')}
        raw_submits=props.get('successful_submissions',props.get('actual_submissions'))
        submits=int(raw_submits) if raw_submits is not None else None
        failures=int(props.get('expected_failed_completions',props.get('failed_completions','0')))
        contract=wanted[name]
        _,kind,count,fail=contract[:4]
        assert kind in ('new','neighbor','schema')
        # Counts are read from actual XML, then checked against the final
        # caller-provided run contract. They are never filled into missing XML.
        assert submits==count and failures==fail,(name,submits,failures,count,fail)
        row=dict(name=name,classification=kind,successful_submissions=submits,
            expected_failed_completions=failures,properties=props)
        if len(contract)>4:
            assert count is None and not props
            row.update(source_counted_submissions=contract[4],source_counted_detail=contract[5],
                submission_count_not_reported_by_XML=True)
        records.append(row)
    names=[r['name'] for r in records]
    assert len(names)==len(set(names)) and set(names)==set(wanted)
    data=read(receipt)
    if 'passed' in data:assert data['passed'] is True
    if 'exit' in data:assert data['exit']==0
    assert not data.get('failed') and not data.get('skipped')
    assert (data.get('tests') or data.get('cases'))==len(actual)
    if isinstance(data.get('names'),list):assert set(data['names'])==set(names)
    return dict(backend=arm,passed=True,tests=records,cases=len(records),
        successful_submissions=sum(r['successful_submissions'] or 0 for r in records),
        source_counted_additional_submissions=sum(r.get('source_counted_submissions',0) for r in records),
        expected_failed_completions=sum(r['expected_failed_completions'] for r in records),
        receipt=ident(receipt),xml=ident(xml),failed=0,skipped=0)

def summarize(config):
    runs=[]
    for arm in ('cpu','cuda','vulkan','apple'):
        default=(dict(xml='apple/mac/final/results/tests.xml',receipt='apple/final-validation.json') if arm=='apple'
          else dict(xml=f'{arm}/validation/attempt1/tests.xml',receipt=f'{arm}/validation/attempt1/receipt.json'))
        row=config.get('main_runs',{}).get(arm,default)
        runs.append(parse_run(arm,row['xml'],row['receipt'],MAIN_CASES[arm]))
    assert sum(x['cases'] for x in runs)==24
    assert sum(x['successful_submissions'] for x in runs)==172
    assert sum(x['expected_failed_completions'] for x in runs)==8
    main=list(runs)
    for row in config.get('extra_runs',[]):
        assert row['backend'] in ('cpu','cuda','vulkan','apple')
        runs.append(parse_run(row['backend'],row['xml'],row['receipt'],row['expected_cases']))
    cases=[dict(backend=x['backend'],**c) for x in runs for c in x['tests']]
    unique={(x['backend'],x['name']) for x in cases}
    assert len(unique)==len(cases),'Do not double-count a case repeated in two chosen final runs'
    return dict(passed=True,scope='Explicit block128 FP8 scale policies and finite original-bank consumers in the existing four backend execution systems',
      cases=len(cases),new_cases=sum(c['classification']=='new' for c in cases),
      neighbors=sum(c['classification']=='neighbor' for c in cases),schema_cases=sum(c['classification']=='schema' for c in cases),
      successful_submissions=sum(c['successful_submissions'] or 0 for c in cases),
      successful_submissions_accounting='Only numeric properties present in the actual XML are summed here; CUDA pair counts absent from XML stay null and are separately source-counted.',
      source_counted_additional_submissions=sum(c.get('source_counted_submissions',0) for c in cases),
      cases_without_XML_submission_count=sum(c['successful_submissions'] is None for c in cases),
      expected_failed_completions=sum(c['expected_failed_completions'] for c in cases),failed=0,skipped=0,
      main_four_backend=dict(cases=24,new_cases=16,neighbors=8,successful_submissions=172,expected_failed_completions=8),
      runs=runs,tests=cases,
      semantics=dict(public='Float8ScalePolicy:uint32 {kDivide=0,kPowerOfTwo=1,kMultiplyReciprocal=2}; dense descriptor ID2 and grouped ID3, both8B; no compatibility alias',
        divide='Original F32 maximum/floor divided by448; original normalization tree retained',
        power='Original F32 maximum/floor times F32 reciprocal448, ceil power2, original normalization retained',
        multiply_reciprocal='F32 max(abs(A),floor)*F32literal(1/448), strict F32 reciprocal, then a separate strict F32 A*reciprocal before SATFINITE E4 RNE; not direct division',
        dot='Original E4 code dot, separate activation-scale then block-weight-scale F32 products, per-group F32 accumulation and original final dtype',
        activation='Dense and grouped BF16/F32 activation contracts; shared A1 quantized before slot broadcast',
        witnesses='Finite BF16 maximum450 plus tiny0.006866455078125 yields Divide0x3c01 versus MultiplyReciprocal0x3bc1 at final BF16'),
      source_role=dict(artifact=30,role='layer45 expert0 gate_proj',A='BF16[1,4096]',W='original E4[2048,4096]',SF='stored F32[16,32]',
        carrier_bytes=8390656,kind='finite artificial original bytes at fixed header geometry',
        original_checkpoint_payload=False,full_artifact_execution=False,AMD_rcpf_bit_equivalence=False),
      resources=dict(full_floating_weight_bank=False,
        Apple='Original dense SF repeat remains: source role logical262144B repeatedSF versus2048B storedSF, no physical allocation count measured. Grouped native compactSF remains selected-indexed without S expansion.',
        note='Correctness/lease tests do not measure hot allocation frequency, traffic or throughput.'),
      source_reader_contract=ident(P.parent/'quark-fp8-side-2026-10-21/review/selected-reader-contract.json'),
      independent_reciprocal_review=ident(P/'root/reciprocal-review.json'),
      retained_failures=['Windows initial3 CXX all succeeded, then the driver failed saving metadata because cpu/ did not exist; that driver attempt did not link. No Windows compiler failure is claimed.',
        'Vulkan offline attempt1 used False as i32 and failed MLIR parsing. Attempt2 succeeded but had no tiny-input guard; attempt3 is the final successful native program.',
        'Apple RANK template argument was size_t but the original MLX template API accepts int; explicit int conversion fixed the compile error without changing math.',
        'CUDA pair-attempt1 filter misspelled the new test name, so only2 existing tests ran. The actual new test was then run once in pair-reciprocal-attempt1; neither attempt is reported as first-run3PASS.'],
      no_new_decode_measurement=True,
      not_verified=['Original checkpoint payload or complete model/artifact','Linux','AMD approximate reciprocal/FTZ hardware equivalence','Every possible native GEMM reduction bit pattern','Quality or throughput'],
      remaining=['Delivery3: bounded resource/import/ordinary consumer integration, warm metadata conversion and default route costs',
        'Final end-to-end comparison, then MTP and mmproj'])

SOURCE_ROOTS=('include/','src/','tests/','third_party/','cmake/')
def canonical_source(path):
    p=Path(path)
    if p.is_absolute():
        if not p.is_relative_to(R):return None
        rel=p.relative_to(R).as_posix()
    else:rel=str(path).replace('\\','/')
    return R/rel if rel.startswith(SOURCE_ROOTS) and (R/rel).is_file() else None

def freeze_sources(config):
    sources=set()
    # Mechanical migration gives the finite set of live enum/ID callers.
    for row in read(P/'mechanical-source-freeze.json')['files']:
        p=canonical_source(row['path'])
        if p:sources.add(p)
    for arm in ('cpu','cuda','vulkan','apple'):
        sources.update([R/f'tests/graph_route_{arm}/fp8_scale_policy_test.cc',R/f'tests/graph_route_{arm}/CMakeLists.txt'])
    required_freezes=['common-source-freeze.json','apple/source-freeze.json','cuda/final-source-freeze.json','vulkan/final-source-freeze.json']
    required_freezes+=config.get('extra_source_freezes',[])
    checked=[]
    for name in required_freezes:
        path=stage_path(name);document=read(path);checked.append(ident(path))
        for row in document.get('sources',[document]):
            item=row.get('source',row)
            if not isinstance(item,dict) or not {'path','bytes','sha256'}<=item.keys():continue
            p=canonical_source(item['path'])
            if p:
                assert ident(p)['sha256']==item['sha256'] and p.stat().st_size==item['bytes'],(path,item)
                sources.add(p)
    sources.update(R/x for x in [
      'src/compute_shader_shared/nvfp4_f32.h','cmake/HyleDependencyLock.json',
      'third_party/sglang_activation/NOTICE','third_party/iree_vulkan_runtime/NOTICE.md'])
    sources.update(stage_path(x) for x in config.get('extra_sources',[]))
    assert all(p.is_file() and p.resolve().is_relative_to(R) and not p.is_symlink() for p in sources)
    records=[]
    for p in sorted(sources):
        assert canonical_source(relative(p)) is not None,p
        q=P/'source'/relative(p);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
        records.append(ident(p))
    result=dict(status='current_finite_product_and_test_sources_frozen_after_actual_final_runs',sources=records,
      checked_final_backend_freezes=checked,
      note='Canonical generated runtime code/header text needed by the locked native paths is retained; SDK, images, objects, maps and temporary embedding programs.cc are not source members.')
    save(P/'root/source-freeze.json',result)
    return result

EXCLUDED_SUFFIXES={'.o','.obj','.exe','.map','.lib','.dll','.pdb','.pyc','.spv','.vmfb','.metallib','.dylib','.a','.cubin','.fatbin','.ptx','.tgz','.gz','.zip','.ilk','.exp'}
TEXT_SUFFIXES={'.py','.json','.xml','.log','.txt','.diff','.patch','.ps1','.d','.h','.hpp','.hh','.cc','.cu','.cuh','.c','.mm','.inc','.inl','.mlir','.md','.b64','.cmake','.yaml','.yml'}

def package(report,source,config):
    archive=OUT/(NAME+'.zip');target=OUT/(NAME+'.json')
    assert not archive.exists() and not target.exists(),'Do not overwrite published evidence'
    files={};aliases={};identities={};originals={};dedup={}
    def put(name,data,deduplicate=True):
        digest=sha(data)
        if deduplicate and digest in dedup:
            aliases[name]=dedup[digest]
        else:
            assert name not in files;files[name]=data;dedup[digest]=name
    def ref_identity(value):
        key=sha(json.dumps(value,sort_keys=True,separators=(',',':')).encode())
        identities.setdefault(key,value)
        return {'$identity':key}
    def compact(value):
        if isinstance(value,list):return [compact(x) for x in value]
        if not isinstance(value,dict):return value
        if {'path','bytes','sha256'}<=value.keys():
            base={k:value[k] for k in ('path','bytes','sha256')}
            return dict(ref_identity(base),**{k:compact(v) for k,v in value.items() if k not in base})
        return {k:compact(v) for k,v in value.items()}
    def restore(value):
        if isinstance(value,list):return [restore(x) for x in value]
        if not isinstance(value,dict):return value
        if '$identity' in value:
            return dict(identities[value['$identity']],
                **{k:restore(v) for k,v in value.items() if k!='$identity'})
        return {k:restore(v) for k,v in value.items()}
    for row in source['sources']:
        p=R/row['path'];data=p.read_bytes();assert sha(data)==row['sha256']
        put('source/'+row['path'],data,deduplicate=False)
    skipped=[]
    for p in sorted(P.rglob('*')):
        if not p.is_file() or p.is_symlink():continue
        rel=p.relative_to(P);name='evidence/'+rel.as_posix()
        if any(x in ('__pycache__','tmp') for x in rel.parts):continue
        if p.name in ('source-freeze.json','final-results.json') and p.parent==P/'root':pass
        if p.name in ('archive-result.json','preview-summary.json','package-contents.json'):continue
        if p.suffix.lower() in EXCLUDED_SUFFIXES:continue
        if p.suffix.lower() not in TEXT_SUFFIXES and p.name not in ('NOTICE','LICENSE'):continue
        data=p.read_bytes()
        if rel.as_posix()=='vulkan/generated/programs.cc':
            skipped.append(dict(**ident(p),reason='Reproducible large generated embedding; canonical MLIR, generator, VMFB text, manifest, exact commands and digest retained.'))
            continue
        assert len(data)<8*1024*1024,p
        # Large compile/dependency records repeat the same SDK/path hashes.
        # Preserve one identity registry with lossless references, while raw
        # command JSONs, receipts, freezes and actual error logs stay exact.
        if p.suffix=='.json' and len(data)>128*1024 and not p.name.endswith('.command.json'):
            original=json.loads(data)
            condensed=compact(original)
            assert restore(condensed)==original,p
            encoded=(json.dumps(condensed,ensure_ascii=False,separators=(',',':'))+'\n').encode()
            originals[name]=dict(original=ident(p),encoding='JSON identity dictionaries replaced losslessly by $identity references into dependency-identities.json')
            put(name,encoded)
        else:put(name,data)
    external=[P.parent/'quark-fp8-side-2026-10-21/review/selected-reader-contract.json']
    external+= [stage_path(x) for x in config.get('external_evidence',[])]
    for p in external:
        assert p.is_file() and p.stat().st_size<1024*1024
        put('evidence/external/'+relative(p).replace('.scratch/architecture-refactor-2026-10-18/',''),p.read_bytes())
    put('evidence/dependency-identities.json',(json.dumps(dict(identities=identities),ensure_ascii=False,indent=2)+'\n').encode(),False)
    put('evidence/file-index.json',(json.dumps(dict(aliases=aliases,compacted_records=originals,generated_omissions=skipped,
      note='Source members are original bytes. An alias resolves to another member with identical bytes; compacted dependency JSON restores each $identity from dependency-identities.json. No executable/object/map/SDK is stored.'),ensure_ascii=False,indent=2)+'\n').encode(),False)
    manifest=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())]
    files['manifest.json']=(json.dumps(dict(files=manifest),indent=2)+'\n').encode()
    OUT.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for name,data in sorted(files.items()):z.writestr(name,data)
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(files) and z.testzip() is None
        for row in manifest:assert sha(z.read(row['path']))==row['sha256']
        for alias,member in aliases.items():assert member in files and sha(z.read(member))==sha(files[member])
    summary=dict(report,archive=ident(archive),source_freeze=ident(P/'root/source-freeze.json'),
      manifest_members=len(manifest),source_members=len(source['sources']),evidence_aliases=len(aliases),
      compacted_dependency_records=len(originals),shared_identity_records=len(identities),
      package_scope='Finite sources, locked native code/data, actual commands/failures/XML/receipts and source identities; no images/objects/maps/SDK or model payload.')
    save(target,summary)
    result=dict(summary=ident(target),archive=ident(archive),members=len(files),source_members=len(source['sources']),
      aliases=len(aliases),compacted_records=len(originals),identities=len(identities))
    save(P/'root/archive-result.json',result)
    print(json.dumps(result,ensure_ascii=False,indent=2))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--inputs',type=Path,default=P/'root/package-inputs.json')
    parser.add_argument('--publish',action='store_true')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    config=read(args.inputs) if args.inputs.exists() else {}
    report=summarize(config)
    if not args.publish:
        save(P/'root/preview-summary.json',report)
        print(json.dumps({k:report[k] for k in ('passed','cases','new_cases','neighbors','schema_cases','successful_submissions','expected_failed_completions','failed','skipped')},indent=2))
        return
    # The explicit final list prevents publishing while the requested extra
    # CUDA pair run is still absent; it is actual-run accounting, not approval.
    assert config.get('extra_runs'),'Wait for the actual requested final CUDA pair run, then supply its receipt/XML/cases'
    assert any(x['backend']=='cuda' for x in config['extra_runs'])
    source=freeze_sources(config)
    save(P/'root/final-results.json',report)
    package(report,source,config)

if __name__=='__main__':main()
