"""Write the exact cleanup plan and test.ps1 after the evidence is published."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent.parent
R=P.parents[2]

def ident(path):
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=digest)

def regular(path):
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(P.resolve()),path
    assert not any(q.is_symlink() or q.is_junction() for q in [path,*path.parents] if q.is_relative_to(P)),path
    return ident(path)

remove=[regular(p) for p in sorted(P.rglob('*')) if p.is_file() and p.suffix.lower() in ('.exe','.map','.dll')]
keep=[regular(p) for p in sorted(P.rglob('*.obj'))]
mac=json.loads((P/'apple/cleanup-inventory.json').read_text('utf-8'))
assert len(mac['deletable_files'])==2 and len(mac['retained_objects'])==3
remote=dict(allowed_mac=mac['remote_root'],remove_mac=mac['deletable_files'],keep_mac=mac['retained_objects'])
old_plan=json.loads((P.parent/'quark-fp8-side-2026-10-21/root/cleanup-plan.json').read_text('utf-8'))
cache=[ident(Path(x['path'])) for x in old_plan['keep_runtime_cache']]
stem='block128-scale-policy-reference-2026-10-21'
plan=dict(allowed_windows=str(P.resolve()),remove_windows=remove,keep_windows=keep,keep_runtime_cache=cache,
    evidence=ident(R/f'docs/evidence/correctness/{stem}.json'),
    archive=ident(R/f'docs/evidence/correctness/{stem}.zip'),mac=remote,
    note='Exact regular test images/maps/staged private-module hardlinks only. Bytes are logical sizes, not physical storage savings.')
(P/'root/cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=(R/'test.ps1').read_text('utf-8-sig')
assert 'quark-fp8-side-2026-10-21' in script and 'No recursive directory removal' in script
(P/'root/previous-cleanup-script.ps1').write_text(script,encoding='utf-8')
script=script.replace('FP8 outer-scale','FP8 block128 scale-policy').replace('quark-fp8-side-2026-10-21',P.name)
script=script.replace('fp8-outer-scale-reference-2026-10-21',stem)
lines=script.splitlines();found=0
for i,line in enumerate(lines):
    if line.startswith('plan=json.loads('):
        lines[i]='plan=json.loads('+repr(json.dumps(remote))+')';found+=1
assert found==1
(R/'test.ps1').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(remove_files=len(remove),logical_windows_bytes=sum(x['bytes'] for x in remove),
    retained_objects=len(keep),mac_files=2,logical_mac_bytes=sum(x['bytes'] for x in remote['remove_mac']),
    windows_targets=[x['path'] for x in remove]),indent=2))
