"""One standalone quantizer AOT and four exact host owners. No link or GPU."""
from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];R=A.parents[1]
spec=importlib.util.spec_from_file_location('prior_outer_build',A/'quark-fp8-side-2026-10-21/windows/build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.c.read(A/'quark-fp8-side-2026-10-21/review/block128-cuda-implementation-plan.json')
NVCC='C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/nvcc.exe'
CCBIN='C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64'
rows=[]
for row in plan['bounded_build']['product_CXX']:
    source=Path(row['source']['path'])
    rows.append(dict(source=b.b.identity(source),old_object=row['actual_linked_object'],command=row['canonical_command'],recipe=row['recipe']))
TAGS=['fp8-provider','grouped-fp8-provider','cuda-provider','fp8-shared-prologue-region']
UNTOUCHED=['third_party/sglang_activation/fp8/sglang_fp8_sm89.h','third_party/sglang_activation/fp8/sglang_fp8_dynamic_sm89.h','third_party/sglang_activation/fp8/grouped/sglang_grouped_fp8_sm89.h']
unchanged=[b.b.identity(R/p) for p in UNTOUCHED]
out=S/'checks/quantizer-attempt1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'aot.result.json').exists()
command=[sys.executable,str(R/'third_party/sglang_activation/fp8/rebuild_cuda_quant.py'),'--output',str(out),'--nvcc',NVCC,'--ccbin',CCBIN]
env,_=b.b.environment(rows[0]['command'],[],out)
b.c.execute('aot',command,env,out)
metadata=b.c.read(out/'cuda-quant-compilation.json')
assert len(metadata['entry_points'])==4 and metadata['launch_argument_count']==11
assert metadata['source_sha256']==b.b.identity(R/'third_party/sglang_activation/fp8/original_cuda_quant.cu')['sha256']
assert all(b.b.same(row) for row in unchanged)
for name in ['sglang_fp8_quantize_cuda_sm89.h','cuda-quant-compilation.json']:
    (R/'third_party/sglang_activation/fp8'/name).write_bytes((out/name).read_bytes())
b.c.save(S/'quantizer-artifact-proof.json',dict(AOT_build=b.b.identity(out/'cuda-quant-build.json'),source=b.b.identity(R/'third_party/sglang_activation/fp8/original_cuda_quant.cu'),header=b.b.identity(R/'third_party/sglang_activation/fp8/sglang_fp8_quantize_cuda_sm89.h'),metadata=b.b.identity(R/'third_party/sglang_activation/fp8/cuda-quant-compilation.json'),unchanged_Power2_GEMM_align_headers=unchanged,entry_points=metadata['entry_points'],NVCC=1,GEMM_builds=0,SDK_builds=0,GPU_runs=0))
names=['include/hyle/compute/model_ops.h','src/compute_provider_cuda/fp8_shared_linear.h',*[str(Path(row['source']['path']).relative_to(R)) for row in rows],'third_party/sglang_activation/fp8/original_cuda_quant.cu','third_party/sglang_activation/fp8/rebuild_cuda_quant.py','third_party/sglang_activation/fp8/cuda-quant-compilation.json','third_party/sglang_activation/fp8/sglang_fp8_quantize_cuda_sm89.h','third_party/sglang_activation/NOTICE']
frozen=[]
for name in names:
    source=R/name;dest=S/'source-first'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    assert not dest.exists();dest.write_bytes(source.read_bytes());frozen.append(b.b.identity(source))
b.c.save(S/'source-freeze-first.json',dict(sources=frozen,source_count=len(frozen),snapshots=str(S/'source-first'),GPU_runs=0))
# compile_job uses its module P/windows/checks directory. Change only that local build
# helper's output parent to this stage; no product or recipe substitution occurs.
b.P=S;b.S=S
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    products=list(pool.map(lambda job:b.compile_job(job[0],job[1],'attempt1',frozen),zip(rows,TAGS)))
assert all(b.b.same(row) for row in frozen)
b.c.save(S/'objects-ready.json',dict(status='strict_products_ready_no_link_no_GPU',records=products,CXX=4,NVCC=1,GEMM_builds=0,SDK_builds=0,GPU_runs=0,actual_base=b.b.identity(Path(plan['bounded_build']['actual_base']['path'])),required_current_CUDA_weights=next(row for row in b.c.read(plan['bounded_build']['actual_base']['path'])['inputs'] if 'bank-alignment-product1' in row['path'])))
print(b.b.identity(S/'objects-ready.json'))
