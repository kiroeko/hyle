"""Compile one Vulkan test owner and link the seven exact replacement objects; never run."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('z_host_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R, Z = h.b, h.c, h.R, h.Z

def main():
    names = ['tests/graph_route_vulkan/fp8_scale_policy_test.cc',
             'tests/graph_route_vulkan/CMakeLists.txt',
             'tests/compute_models/fp8_scale_policy_fixture.h',
             'tests/compute_models/grouped_fp8_power2_fixture.h',
             'include/hyle/compute/model_ops.h']
    rows = []
    for name in names:
        source = R / name
        dest = S / 'source-vulkan1' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            assert dest.read_bytes() == source.read_bytes()
        else:
            dest.write_bytes(source.read_bytes())
        rows.append(dict(source=b.identity(source), snapshot=b.identity(dest)))
    c.save(S / 'vulkan-source-freeze.json', dict(sources=rows, GPU_runs=0, SDK_builds=0))
    test = h.compile_one('vulkan-scale-policy-test', h.wrapper_row('vulkan'),
                         'attempt3', [row['source'] for row in rows])
    torch = c.read(S / 'checks/attempt1/torch-cpu/identity.json')
    products = c.read(Z / 'vulkan/objects-ready.json')
    records = [torch, test, *products['records']]
    path, plan = h.base('vulkan')
    assert len(records) == 7
    replacements = {c.key(row['old_object']['path']): row['object'] for row in records}
    assert len(replacements) == len(records)
    assert all(h.same(row) for row in plan['inputs'])
    used = [row for row in records if any(c.key(old['path']) == c.key(row['old_object']['path']) for old in plan['inputs'])]
    assert len(used) == len(records)
    inputs = [replacements.get(c.key(row['path']), row) for row in plan['inputs']]
    assert all(h.same(row) for row in inputs)
    command = [replacements[c.key(arg)]['path'] if c.key(arg) in replacements else arg
               for arg in plan['command']
               if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = Z / 'vulkan/checks/link1'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / 'vulkan.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    arguments = [arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ['.obj', '.lib']]
    assert list(map(c.key, arguments)) == [c.key(row['path']) for row in inputs]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(path),
        replacements=[dict(source=row['source'], old_object=row['old_object'], object=row['object']) for row in used],
        GPU_runs=0, SDK_builds=0))
    env, runtime = b.environment(command, [row['path'] for row in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    ready = dict(status='strict_test_CXX_and_link_ready_not_executed', arm='vulkan',
        image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        filter='VulkanFp8ScalePolicy.*', expected_tests=6,
        planned_successful_submissions=43, planned_expected_failed_completions=2,
        CXX=1, links=1, NVCC=0, SDK_builds=0, agent_GPU_runs=0)
    c.save(S / 'vulkan-ready-for-root-run.json', ready)
    print(str(S / 'vulkan-ready-for-root-run.json'), flush=True)

if __name__ == '__main__':
    main()
