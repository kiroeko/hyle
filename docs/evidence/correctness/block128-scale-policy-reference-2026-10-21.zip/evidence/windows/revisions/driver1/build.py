"""Compile only the shared Torch CPU owner and focused wrappers; link, never run."""
import argparse
import concurrent.futures
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;Z=S.parent;A=Z.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('prior_outer_build',A/'quark-fp8-side-2026-10-21/windows/build.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
b,c=prior.b,prior.c
Y=A/'quark-fp8-side-2026-10-21'
TORCH_RECIPE=A/'mlx-weight-orientation-2026-10-21/cpu-cuda/checks/attempt1/torch-cpu/identity.json'

def same(row):
    path=Path(row['path'])
    return path.exists() and path.stat().st_size==row['bytes'] and b.identity(path)['sha256']==row['sha256']

def freeze(attempt):
    names=['include/hyle/compute/model_ops.h','src/compute_provider_native/torch_cpu_program.cc',
        'tests/compute_ops/operation_test.cc','tests/compute_models/grouped_fp8_power2_fixture.h',
        'tests/compute_models/fp8_scale_policy_fixture.h',
        *[f'tests/graph_route_{arm}/fp8_scale_policy_test.cc' for arm in ['cpu','cuda']],
        *[f'tests/graph_route_{arm}/CMakeLists.txt' for arm in ['cpu','cuda']]]
    rows=[]
    for name in names:
        data=(R/name).read_bytes();dest=S/('source-'+attempt)/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
        rows.append(dict(source=b.identity(R/name),snapshot=b.identity(dest)))
    c.save(S/('source-freeze-'+attempt+'.json'),dict(sources=rows,GPU_runs=0,SDK_builds=0))
    return [row['source'] for row in rows]

def base(arm):
    path=Y/arm/'checks/link4/link-plan.json'
    return path,c.read(path)

def wrapper_row(arm):
    _,plan=base(arm)
    old=next(row for row in plan['replacements'] if row['source']['path'].endswith('fp8_outer_scale_test.cc'))
    recipe=Path(old['object']['path']).parent/'identity.json'
    return dict(source=b.identity(R/f'tests/graph_route_{arm}/fp8_scale_policy_test.cc'),
                command=c.read(recipe)['command'],old_object=old['object'],recipe=b.identity(recipe))

def compile_one(tag,row,attempt,frozen):
    out=S/'checks'/attempt/tag;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists(),out
    source=Path(row['source']['path']);template=row['command']
    command=b.host_command(template,source,tag,out)
    for flag in ['/W4','/WX']:
        if flag not in command:command.append(flag)
    source_id=b.identity(source)
    c.save(out/'compile-plan.json',dict(command=command,source=source_id,old_object=row['old_object'],recipe=row['recipe'],GPU_runs=0,SDK_builds=0))
    env,_=b.environment(command,[],out)
    c.execute('compile',command,env,out)
    dep_path=out/(tag+'-deps.json');deps=c.read(dep_path)['Data']
    paths=list(dict.fromkeys([deps['Source'],*deps['Includes']]))
    dependencies=[b.identity(path) for path in paths]
    keys={c.key(x['path']) for x in dependencies}
    assert all(same(x) for x in [source_id,*dependencies,*[x for x in frozen if c.key(x['path']) in keys]])
    record=dict(command=command,source=source_id,old_object=row['old_object'],object=b.identity(out/(tag+'.obj')),
        recipe=row['recipe'],dependencies=dependencies,source_dependencies=b.identity(dep_path),GPU_runs=0,SDK_builds=0)
    c.save(out/'identity.json',record);print('COMPILED',tag,flush=True)
    return record

def link(arm,torch,test,folder):
    path,plan=base(arm)
    records=[torch,test]
    if arm=='cuda':records+=c.read(Z/'cuda/objects-ready.json')['records']
    replacements={c.key(x['old_object']['path']):x['object'] for x in records}
    assert all(same(row) for row in plan['inputs'])
    inputs=[replacements.get(c.key(row['path']),row) for row in plan['inputs']]
    used=[x for x in records if any(c.key(row['path'])==c.key(x['old_object']['path']) for row in plan['inputs'])]
    assert len(used)==(6 if arm=='cuda' else 2),(arm,[x['source']['path'] for x in used])
    assert all(same(row) for row in inputs)
    command=[replacements[c.key(arg)]['path'] if c.key(arg) in replacements else arg for arg in plan['command']
             if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out=Z/arm/'checks'/folder;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists(),out
    image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    arguments=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ['.obj','.lib']]
    assert list(map(c.key,arguments))==[c.key(row['path']) for row in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(path),
        replacements=[dict(source=x['source'],old_object=x['old_object'],object=x['object']) for x in used],GPU_runs=0,SDK_builds=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    print('LINKED',arm,flush=True)
    return dict(arm=arm,image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),
        runtime_environment=b.identity(out/'runtime-environment.json'),
        filter=('Cpu' if arm=='cpu' else 'Cuda')+'Fp8ScalePolicy.*',expected_tests=6,
        planned_successful_submissions=43,planned_expected_failed_completions=2)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt',default='attempt1');parser.add_argument('--link-dir',default='link1')
    parser.add_argument('--phase',choices=['all','compile','link'],default='all')
    parser.add_argument('--compile-attempt',default='attempt1')
    args=parser.parse_args();frozen=freeze(args.attempt)
    if args.phase in ['all','compile']:
        old=c.read(TORCH_RECIPE)
        torch_row=dict(source=b.identity(R/'src/compute_provider_native/torch_cpu_program.cc'),
            old_object=old['object'],command=old['command'],recipe=b.identity(TORCH_RECIPE))
        jobs=[('torch-cpu',torch_row),('cpu-scale-policy-test',wrapper_row('cpu')),('cuda-scale-policy-test',wrapper_row('cuda'))]
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            records=dict(pool.map(lambda job:(job[0],compile_one(job[0],job[1],args.attempt,frozen)),jobs))
        c.save(S/('compiles-'+args.attempt+'.json'),dict(records=records,CXX=3,NVCC=0,SDK_builds=0,GPU_runs=0))
        c.save(Z/'cpu/objects-ready.json',dict(records=[records['torch-cpu']],status='fresh_shared_TorchCPU_object_for_all_Windows_arms'))
    else:records=c.read(S/('compiles-'+args.compile_attempt+'.json'))['records']
    if args.phase in ['all','link']:
        ready=[link(arm,records['torch-cpu'],records[arm+'-scale-policy-test'],args.link_dir) for arm in ['cpu','cuda']]
        c.save(S/'ready-for-root-run.json',dict(status='strict_CXX_and_links_ready_not_executed',arms=ready,
            CXX=3,links=2,NVCC=0,SDK_builds=0,agent_GPU_runs=0))
        print(str(S/'ready-for-root-run.json'),flush=True)

if __name__=='__main__':main()
