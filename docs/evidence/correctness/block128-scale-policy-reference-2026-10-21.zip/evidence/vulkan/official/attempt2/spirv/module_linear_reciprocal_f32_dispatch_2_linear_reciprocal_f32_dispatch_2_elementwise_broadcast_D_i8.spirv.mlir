spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst255_i32 = spirv.Constant 255 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst126_i32 = spirv.Constant 126 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst_f32 = spirv.Constant 4.480000e+02 : f32
    %cst_f32_0 = spirv.Constant -4.480000e+02 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %14 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %15 = spirv.CompositeExtract %14[0 : i32] : vector<3xi32>
    %16 = spirv.IMul %13, %cst64_i32 : i32
    %17 = spirv.IMul %15, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
      %19 = spirv.SLessThan %18, %3 : i32
      spirv.BranchConditional %19, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %20 = spirv.ISub %3, %18 : i32
      %21 = spirv.GL.SMin %20, %cst64_i32 : i32
      %22 = spirv.SGreaterThan %21, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %22, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %24 = spirv.IAdd %18, %11 : i32
        %25 = spirv.GL.SAbs %24 : i32
        %26 = spirv.GL.SAbs %7 : i32
        %27 = spirv.UMod %25, %26 : i32
        %28 = spirv.IEqual %24, %25 : i32
        %29 = spirv.SNegate %27 : i32
        %30 = spirv.Select %28, %27, %29 : i1, i32
        %31 = spirv.SDiv %24, %7 : i32
        %32 = spirv.UDiv %30, %cst128_i32 : i32
        %33 = spirv.IMul %31, %7 : i32
        %34 = spirv.IAdd %33, %30 : i32
        %35 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %36 = spirv.Load "StorageBuffer" %35 : f32
        %37 = spirv.IMul %31, %9 : i32
        %38 = spirv.IAdd %37, %32 : i32
        %39 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %38] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %40 = spirv.Load "StorageBuffer" %39 : f32
        %41 = spirv.FMul %36, %40 : f32
        %42 = spirv.GL.FMax %41, %cst_f32_0 : f32
        %43 = spirv.IsNan %41 : f32
        %44 = spirv.IsNan %cst_f32_0 : f32
        %45 = spirv.Select %43, %41, %42 : i1, f32
        %46 = spirv.Select %44, %cst_f32_0, %45 : i1, f32
        %47 = spirv.GL.FMin %46, %cst_f32 : f32
        %48 = spirv.IsNan %46 : f32
        %49 = spirv.IsNan %cst_f32 : f32
        %50 = spirv.Select %48, %46, %47 : i1, f32
        %51 = spirv.Select %49, %cst_f32, %50 : i1, f32
        %52 = spirv.GL.FAbs %51 : f32
        %53 = spirv.GL.FMin %52, %cst_f32 : f32
        %54 = spirv.IsNan %52 : f32
        %55 = spirv.Select %54, %52, %53 : i1, f32
        %56 = spirv.Select %49, %cst_f32, %55 : i1, f32
        %57 = spirv.Variable : !spirv.ptr<i32, Function>
        %58 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst126_i32 : i32, i32)
        ^bb1(%98: i32, %99: i32):  // 2 preds: ^bb0, ^bb2
          %100 = spirv.ULessThan %98, %99 : i32
          spirv.Store "Function" %57, %98 : i32
          spirv.Store "Function" %58, %99 : i32
          spirv.BranchConditional %100, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %101 = spirv.IAdd %98, %99 : i32
          %102 = spirv.IAdd %101, %cst1_i32 : i32
          %103 = spirv.UDiv %102, %cst2_i32 : i32
          %104 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %103] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %105 = spirv.Load "StorageBuffer" %104 : f32
          %106 = spirv.FOrdLessThanEqual %105, %56 : f32
          %107 = spirv.ISub %103, %cst1_i32 : i32
          %108 = spirv.Select %106, %103, %98 : i1, i32
          %109 = spirv.Select %106, %99, %107 : i1, i32
          spirv.Branch ^bb1(%108, %109 : i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %59 = spirv.Load "Function" %58 : i32
        %60 = spirv.Load "Function" %57 : i32
        %61 = spirv.IAdd %60, %cst1_i32 : i32
        %62 = spirv.GL.UMin %61, %cst126_i32 : i32
        %63 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %60] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %64 = spirv.Load "StorageBuffer" %63 : f32
        %65 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %62] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %66 = spirv.Load "StorageBuffer" %65 : f32
        %67 = spirv.FSub %56, %64 : f32
        %68 = spirv.FSub %56, %66 : f32
        %69 = spirv.GL.FAbs %67 : f32
        %70 = spirv.GL.FAbs %68 : f32
        %71 = spirv.FOrdLessThan %70, %69 : f32
        %72 = spirv.FOrdEqual %70, %69 : f32
        %73 = spirv.BitwiseAnd %60, %cst1_i32 : i32
        %74 = spirv.BitwiseAnd %62, %cst1_i32 : i32
        %75 = spirv.INotEqual %73, %cst0_i32 : i32
        %76 = spirv.IEqual %74, %cst0_i32 : i32
        %77 = spirv.LogicalAnd %72, %76 : i1
        %78 = spirv.LogicalAnd %77, %75 : i1
        %79 = spirv.LogicalOr %71, %78 : i1
        %80 = spirv.Select %79, %62, %60 : i1, i32
        %81 = spirv.Bitcast %51 : f32 to i32
        %82 = spirv.ShiftRightLogical %81, %cst24_i32 : i32, i32
        %83 = spirv.BitwiseAnd %82, %cst128_i32 : i32
        %84 = spirv.BitwiseOr %80, %83 : i32
        %85 = spirv.BitwiseAnd %84, %cst255_i32 : i32
        %86 = spirv.IAdd %1, %18 : i32
        %87 = spirv.IAdd %86, %11 : i32
        %88 = spirv.UMod %87, %cst4_i32 : i32
        %89 = spirv.IMul %88, %cst8_i32 : i32
        %90 = spirv.ShiftLeftLogical %cst255_i32, %89 : i32, i32
        %91 = spirv.Not %90 : i32
        %92 = spirv.BitwiseAnd %85, %cst255_i32 : i32
        %93 = spirv.ShiftLeftLogical %92, %89 : i32, i32
        %94 = spirv.SDiv %87, %cst4_i32 : i32
        %95 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %94] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %96 = spirv.AtomicAnd <Device> <AcquireRelease|UniformMemory> %95, %91 : !spirv.ptr<i32, StorageBuffer>
        %97 = spirv.AtomicOr <Device> <AcquireRelease|UniformMemory> %95, %93 : !spirv.ptr<i32, StorageBuffer>
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %23 = spirv.IAdd %18, %17 : i32
      spirv.Branch ^bb1(%23 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 "SignedZeroInfNanPreserve", 32
}