module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #hal.device.target<"vulkan", [#hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>]> : !hal.device
  util.global private @__constant_tensor_127xf32 : !stream.resource<constant>
  util.initializer {
    %c0 = arith.constant 0 : index
    %c0_i64 = arith.constant 0 : i64
    %0 = stream.timepoint.immediate => !stream.timepoint
    %buffer_cst = util.buffer.constant {alignment = 64 : index} : !util.buffer = #util.composite<512xi8, [
    dense<"0x000000000000003B0000803B0000C03B0000003C0000203C0000403C0000603C0000803C0000903C0000A03C0000B03C0000C03C0000D03C0000E03C0000F03C0000003D0000103D0000203D0000303D0000403D0000503D0000603D0000703D0000803D0000903D0000A03D0000B03D0000C03D0000D03D0000E03D0000F03D0000003E0000103E0000203E0000303E0000403E0000503E0000603E0000703E0000803E0000903E0000A03E0000B03E0000C03E0000D03E0000E03E0000F03E0000003F0000103F0000203F0000303F0000403F0000503F0000603F0000703F0000803F0000903F0000A03F0000B03F0000C03F0000D03F0000E03F0000F03F000000400000104000002040000030400000404000005040000060400000704000008040000090400000A0400000B0400000C0400000D0400000E0400000F040000000410000104100002041000030410000404100005041000060410000704100008041000090410000A0410000B0410000C0410000D0410000E0410000F041000000420000104200002042000030420000404200005042000060420000704200008042000090420000A0420000B0420000C0420000D0420000E0420000F042000000430000104300002043000030430000404300005043000060430000704300008043000090430000A0430000B0430000C0430000D0430000E043"> : tensor<127xf32>,
    dense<0> : vector<4xi8>,
]>
    %c512 = arith.constant 512 : index
    %did_map, %result = stream.resource.try_map on(#hal.device.affinity<@__device_0>) %buffer_cst[%c0] : !util.buffer -> i1, !stream.resource<constant>{%c512}
    cf.cond_br %did_map, ^bb2(%0, %result : !stream.timepoint, !stream.resource<constant>), ^bb1
  ^bb1:  // pred: ^bb0
    %1 = stream.resource.alloc uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<constant>{%c512}
    %file = stream.file.constant on(#hal.device.affinity<@__device_0>) %buffer_cst[%c0 for %c512] : !util.buffer{%c512} -> !stream.file
    %2 = stream.file.read on(#hal.device.affinity<@__device_0>) await(%0) => %file[%c0_i64], %1[%c0], %c512 : !stream.file -> !stream.resource<constant>{%c512} => !stream.timepoint
    cf.br ^bb2(%2, %1 : !stream.timepoint, !stream.resource<constant>)
  ^bb2(%3: !stream.timepoint, %4: !stream.resource<constant>):  // 2 preds: ^bb0, ^bb1
    %5 = stream.timepoint.await sync %3 => %4 : !stream.resource<constant>{%c512}
    util.global.store %5, @__constant_tensor_127xf32 : !stream.resource<constant>
    util.return
  }
  hal.executable private @weight_decode_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @weight_decode_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @weight_decode_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant 0x7FC00000 : f32
          %c128 = arith.constant 128 : index
          %c127_i32 = arith.constant 127 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<umin = 0, umax = 9223372036854775807>, 
              %19<umin = 0, umax = 9007199254740991>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %35#0, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 1 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 2 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 3 : index
          %40 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 4 : index
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%37, %38}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%39, %40}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%37, %38], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%37, %38} -> tensor<?x?xi8>
          %45 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0], sizes = [%39, %40], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%39, %40} -> tensor<?x?xf32>
          %46 = tensor.empty(%36) : tensor<?xf32>
          %47 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%46 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %48 = linalg.index 0 : index
            %49 = arith.remsi %48, %38 : index
            %50 = arith.divsi %48, %38 : index
            %51 = arith.divui %50, %c128 : index
            %52 = arith.divui %49, %c128 : index
            %extracted = tensor.extract %44[%50, %49] : tensor<?x?xi8>
            %53 = arith.extui %extracted : i8 to i32
            %54 = arith.bitcast %extracted : i8 to f8E4M3FN
            %55 = arith.extf %54 : f8E4M3FN to f32
            %56 = arith.andi %53, %c127_i32 : i32
            %57 = arith.cmpi eq, %56, %c127_i32 : i32
            %58 = arith.select %57, %cst, %55 : f32
            %extracted_0 = tensor.extract %45[%51, %52] : tensor<?x?xf32>
            %59 = arith.mulf %58, %extracted_0 : f32
            linalg.yield %59 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %47, %43, offsets = [0], sizes = [%36], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          return
        }
        iree_codegen.dispatch_config @weight_decode_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @weight_decode_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.fence, %arg3: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @weight_decode_f32(%input0: tensor<?x?xi8>, %input1: tensor<?x?xf32>) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg2 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5, %6]) type(%element_type_f32) encoding(%dense_row_major)
    %7 = arith.muli %5, %c4 : index
    %8 = arith.muli %7, %6 : index
    %9 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf32>{%5, %6} in !stream.resource<external>{%8}
    %10 = arith.muli %0, %1 overflow<nsw> : index
    %11 = arith.muli %10, %c4 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%11} => !stream.timepoint
    %12 = arith.index_castui %10 : index to i64
    %13 = arith.index_castui %10 : index to i32
    %14 = arith.shrui %12, %c32_i64 : i64
    %15 = arith.trunci %14 : i64 to i32
    %16 = arith.index_castui %0 : index to i64
    %17 = arith.index_castui %0 : index to i32
    %18 = arith.shrui %16, %c32_i64 : i64
    %19 = arith.trunci %18 : i64 to i32
    %20 = arith.index_castui %1 : index to i64
    %21 = arith.index_castui %1 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %5 : index to i64
    %25 = arith.index_castui %5 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %6 : index to i64
    %29 = arith.index_castui %6 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg4: !stream.resource<external>{%2}, %9 as %arg5: !stream.resource<external>{%8}, %result as %arg6: !stream.resource<external>{%11}) {
      stream.cmd.dispatch @weight_decode_f32_dispatch_0::@vulkan_spirv_fb::@weight_decode_f32_dispatch_0_elementwise_broadcast_D_f32[%10, %0, %1, %5, %6](%13, %15, %17, %19, %21, %23, %25, %27, %29, %31 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg4[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg5[%c0 for %8] : !stream.resource<external>{%8},
        wo %arg6[%c0 for %11] : !stream.resource<external>{%11}
      }
    } => !stream.timepoint
    %33 = arith.muli %0, %c4 : index
    %34 = arith.muli %33, %1 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %32 => (%arg3 : !hal.fence)
    %35 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%34} -> !hal.buffer_view
    util.return %35 : !hal.buffer_view
  }
  hal.executable private @weight_decode_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @weight_decode_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @weight_decode_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant 0x7FC00000 : f32
          %c128 = arith.constant 128 : index
          %c127_i32 = arith.constant 127 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<umin = 0, umax = 9223372036854775807>, 
              %19<umin = 0, umax = 9007199254740991>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %35#0, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 1 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 2 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 3 : index
          %40 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 4 : index
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%37, %38}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%39, %40}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%36}
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%37, %38], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%37, %38} -> tensor<?x?xi8>
          %45 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0], sizes = [%39, %40], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%39, %40} -> tensor<?x?xf32>
          %46 = tensor.empty(%36) : tensor<?xi16>
          %47 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%46 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %48 = linalg.index 0 : index
            %49 = arith.remsi %48, %38 : index
            %50 = arith.divsi %48, %38 : index
            %51 = arith.divui %50, %c128 : index
            %52 = arith.divui %49, %c128 : index
            %extracted = tensor.extract %44[%50, %49] : tensor<?x?xi8>
            %53 = arith.extui %extracted : i8 to i32
            %54 = arith.bitcast %extracted : i8 to f8E4M3FN
            %55 = arith.extf %54 : f8E4M3FN to f32
            %56 = arith.andi %53, %c127_i32 : i32
            %57 = arith.cmpi eq, %56, %c127_i32 : i32
            %58 = arith.select %57, %cst, %55 : f32
            %extracted_0 = tensor.extract %45[%51, %52] : tensor<?x?xf32>
            %59 = arith.mulf %58, %extracted_0 : f32
            %60 = arith.truncf %59 : f32 to bf16
            %61 = arith.bitcast %60 : bf16 to i16
            linalg.yield %61 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %47, %43, offsets = [0], sizes = [%36], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%36}
          return
        }
        iree_codegen.dispatch_config @weight_decode_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @weight_decode_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.fence, %arg3: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @weight_decode_bf16(%input0: tensor<?x?xi8>, %input1: tensor<?x?xf32>) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg2 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5, %6]) type(%element_type_f32) encoding(%dense_row_major)
    %7 = arith.muli %5, %c4 : index
    %8 = arith.muli %7, %6 : index
    %9 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf32>{%5, %6} in !stream.resource<external>{%8}
    %10 = arith.muli %0, %1 overflow<nsw> : index
    %11 = arith.muli %10, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%11} => !stream.timepoint
    %12 = arith.index_castui %10 : index to i64
    %13 = arith.index_castui %10 : index to i32
    %14 = arith.shrui %12, %c32_i64 : i64
    %15 = arith.trunci %14 : i64 to i32
    %16 = arith.index_castui %0 : index to i64
    %17 = arith.index_castui %0 : index to i32
    %18 = arith.shrui %16, %c32_i64 : i64
    %19 = arith.trunci %18 : i64 to i32
    %20 = arith.index_castui %1 : index to i64
    %21 = arith.index_castui %1 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %5 : index to i64
    %25 = arith.index_castui %5 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %6 : index to i64
    %29 = arith.index_castui %6 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg4: !stream.resource<external>{%2}, %9 as %arg5: !stream.resource<external>{%8}, %result as %arg6: !stream.resource<external>{%11}) {
      stream.cmd.dispatch @weight_decode_bf16_dispatch_0::@vulkan_spirv_fb::@weight_decode_bf16_dispatch_0_elementwise_broadcast_D_i16[%10, %0, %1, %5, %6](%13, %15, %17, %19, %21, %23, %25, %27, %29, %31 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg4[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg5[%c0 for %8] : !stream.resource<external>{%8},
        wo %arg6[%c0 for %11] : !stream.resource<external>{%11}
      }
    } => !stream.timepoint
    %33 = arith.muli %0, %c2 : index
    %34 = arith.muli %33, %1 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %32 => (%arg3 : !hal.fence)
    %35 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%34} -> !hal.buffer_view
    util.return %35 : !hal.buffer_view
  }
  hal.executable private @fp8_roundtrip_64_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp8_roundtrip_64_dispatch_0_reduction_D_i16xi32 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp8_roundtrip_64_dispatch_0_reduction_D_i16xi32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [1, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c32640_i32 = arith.constant 32640 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = util.assume.int %6<umin = 0, umax = 9223372036854775807> : index
          %8 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<i32>>
          %9 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
          %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi16>>{%9}
          %11 = iree_tensor_ext.dispatch.tensor.load %10, offsets = [0], sizes = [%9], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi16>>{%9} -> tensor<?xi16>
          %12 = tensor.empty() : tensor<i32>
          %13 = linalg.fill ins(%c0_i32 : i32) outs(%12 : tensor<i32>) -> tensor<i32>
          %14 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> ()>], iterator_types = ["reduction"]} ins(%11 : tensor<?xi16>) outs(%13 : tensor<i32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = []>} {
          ^bb0(%in: i16, %out: i32):
            %15 = arith.extui %in : i16 to i32
            %16 = arith.andi %15, %c32640_i32 : i32
            %17 = arith.cmpi eq, %16, %c32640_i32 : i32
            %18 = arith.extui %17 : i1 to i32
            %19 = arith.ori %out, %18 : i32
            linalg.yield %19 : i32
          } -> tensor<i32>
          iree_tensor_ext.dispatch.tensor.store %14, %8, offsets = [], sizes = [], strides = [] : tensor<i32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<i32>>
          return
        }
        iree_codegen.dispatch_config @fp8_roundtrip_64_dispatch_0_reduction_D_i16xi32 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @fp8_roundtrip_64_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp8_roundtrip_64_dispatch_1_reduction_Dx64_i16xf32 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp8_roundtrip_64_dispatch_1_reduction_Dx64_i16xf32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8388607_i32 = arith.constant 8388607 : i32
          %c23_i32 = arith.constant 23 : i32
          %cst = arith.constant 0.00223214296 : f32
          %cst_0 = arith.constant 9.99999974E-5 : f32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = util.assume.int %6<umin = 0, umax = 9223372036854775807> : index
          %8 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
          %9 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x64xi16>>{%8}
          %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%8}
          %11 = iree_tensor_ext.dispatch.tensor.load %9, offsets = [0, 0], sizes = [%8, 64], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x64xi16>>{%8} -> tensor<?x64xi16>
          %12 = tensor.empty(%8) : tensor<?xf32>
          %13 = linalg.fill ins(%cst_0 : f32) outs(%12 : tensor<?xf32>) -> tensor<?xf32>
          %14 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0)>], iterator_types = ["parallel", "reduction"]} ins(%11 : tensor<?x64xi16>) outs(%13 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: i16, %out: f32):
            %16 = arith.bitcast %in : i16 to bf16
            %17 = arith.extf %16 : bf16 to f32
            %18 = math.absf %17 : f32
            %19 = arith.maximumf %18, %out : f32
            linalg.yield %19 : f32
          } -> tensor<?xf32>
          %15 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%14 : tensor<?xf32>) outs(%12 : tensor<?xf32>) {
          ^bb0(%in: f32, %out: f32):
            %16 = arith.mulf %in, %cst : f32
            %17 = arith.bitcast %16 : f32 to i32
            %18 = arith.shrui %17, %c23_i32 : i32
            %19 = arith.andi %17, %c8388607_i32 : i32
            %20 = arith.cmpi ne, %19, %c0_i32 : i32
            %21 = arith.extui %20 : i1 to i32
            %22 = arith.addi %18, %21 : i32
            %23 = arith.shli %22, %c23_i32 : i32
            %24 = arith.bitcast %23 : i32 to f32
            linalg.yield %24 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %15, %10, offsets = [0], sizes = [%8], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%8}
          return
        }
        iree_codegen.dispatch_config @fp8_roundtrip_64_dispatch_1_reduction_Dx64_i16xf32 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @fp8_roundtrip_64_dispatch_2 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp8_roundtrip_64_dispatch_2_elementwise_broadcast_D_i8 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp8_roundtrip_64_dispatch_2_elementwise_broadcast_D_i8() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c128_i32 = arith.constant 128 : i32
          %c24_i32 = arith.constant 24 : i32
          %c1_i32 = arith.constant 1 : i32
          %c126 = arith.constant 126 : index
          %c2 = arith.constant 2 : index
          %c1 = arith.constant 1 : index
          %c64 = arith.constant 64 : index
          %cst = arith.constant 4.480000e+02 : f32
          %cst_0 = arith.constant -4.480000e+02 : f32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 {stream.alignment = 64 : index} : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<udiv = 64>, 
              %19<umin = 0, umax = 9223372036854775807>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 140737488355327>
            : index, index, index, index, index
          %36 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(ReadOnly) : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>>
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 0 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 1 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 2 : index
          %40 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 3 : index
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%38, %39}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%35#0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%38, %39} -> tensor<?x?xi16>
          %45 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0], sizes = [%38, %40], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40} -> tensor<?x?xf32>
          %46 = iree_tensor_ext.dispatch.tensor.load %36, offsets = [0], sizes = [127], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>> -> tensor<127xf32>
          %47 = tensor.empty(%37) : tensor<?xi8>
          %48 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%47 : tensor<?xi8>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i8):
            %49 = linalg.index 0 : index
            %50 = arith.remsi %49, %39 : index
            %51 = arith.divsi %49, %39 : index
            %52 = arith.divui %50, %c64 : index
            %extracted = tensor.extract %44[%51, %50] : tensor<?x?xi16>
            %53 = arith.bitcast %extracted : i16 to bf16
            %54 = arith.extf %53 : bf16 to f32
            %extracted_1 = tensor.extract %45[%51, %52] : tensor<?x?xf32>
            %55 = arith.divf %54, %extracted_1 : f32
            %56 = arith.maximumf %55, %cst_0 : f32
            %57 = arith.minimumf %56, %cst : f32
            %58 = math.absf %57 : f32
            %59 = arith.minimumf %58, %cst : f32
            %60:2 = scf.while (%arg0 = %c0, %arg1 = %c126) : (index, index) -> (index, index) {
              %84 = arith.cmpi ult, %arg0, %arg1 : index
              scf.condition(%84) %arg0, %arg1 : index, index
            } do {
            ^bb0(%arg0: index, %arg1: index):
              %84 = arith.addi %arg0, %arg1 : index
              %85 = arith.addi %84, %c1 : index
              %86 = arith.divui %85, %c2 : index
              %extracted_4 = tensor.extract %46[%86] : tensor<127xf32>
              %87 = arith.cmpf ole, %extracted_4, %59 : f32
              %88 = arith.subi %86, %c1 : index
              %89 = arith.select %87, %86, %arg0 : index
              %90 = arith.select %87, %arg1, %88 : index
              scf.yield %89, %90 : index, index
            }
            %61 = arith.addi %60#0, %c1 : index
            %62 = arith.minui %61, %c126 : index
            %extracted_2 = tensor.extract %46[%60#0] : tensor<127xf32>
            %extracted_3 = tensor.extract %46[%62] : tensor<127xf32>
            %63 = arith.subf %59, %extracted_2 : f32
            %64 = arith.subf %59, %extracted_3 : f32
            %65 = math.absf %63 : f32
            %66 = math.absf %64 : f32
            %67 = arith.cmpf olt, %66, %65 : f32
            %68 = arith.cmpf oeq, %66, %65 : f32
            %69 = arith.index_castui %60#0 : index to i32
            %70 = arith.index_castui %62 : index to i32
            %71 = arith.andi %69, %c1_i32 : i32
            %72 = arith.andi %70, %c1_i32 : i32
            %73 = arith.cmpi ne, %71, %c0_i32 : i32
            %74 = arith.cmpi eq, %72, %c0_i32 : i32
            %75 = arith.andi %68, %74 : i1
            %76 = arith.andi %75, %73 : i1
            %77 = arith.ori %67, %76 : i1
            %78 = arith.select %77, %70, %69 : i32
            %79 = arith.bitcast %57 : f32 to i32
            %80 = arith.shrui %79, %c24_i32 : i32
            %81 = arith.andi %80, %c128_i32 : i32
            %82 = arith.ori %78, %81 : i32
            %83 = arith.trunci %82 : i32 to i8
            linalg.yield %83 : i8
          } -> tensor<?xi8>
          iree_tensor_ext.dispatch.tensor.store %48, %43, offsets = [0], sizes = [%37], strides = [1] : tensor<?xi8> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          return
        }
        iree_codegen.dispatch_config @fp8_roundtrip_64_dispatch_2_elementwise_broadcast_D_i8 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @fp8_roundtrip_64_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp8_roundtrip_64_dispatch_3_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp8_roundtrip_64_dispatch_3_elementwise_broadcast_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant 0x7FC00000 : f32
          %c64 = arith.constant 64 : index
          %c127_i32 = arith.constant 127 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 {stream.alignment = 64 : index} : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<udiv = 64>, 
              %19<umin = 0, umax = 9223372036854775807>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 140737488355327>
            : index, index, index, index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 1 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 2 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 3 : index
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%35#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%38, %37}
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c64) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%36}
          %43 = iree_tensor_ext.dispatch.tensor.load %40, offsets = [0, 0], sizes = [%38, %37], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%38, %37} -> tensor<?x?xi8>
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39} -> tensor<?x?xf32>
          %45 = tensor.empty(%36) : tensor<?xi16>
          %46 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%45 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %47 = linalg.index 0 : index
            %48 = arith.remsi %47, %37 : index
            %49 = arith.divsi %47, %37 : index
            %50 = arith.divui %48, %c64 : index
            %extracted = tensor.extract %43[%49, %48] : tensor<?x?xi8>
            %51 = arith.extui %extracted : i8 to i32
            %52 = arith.bitcast %extracted : i8 to f8E4M3FN
            %53 = arith.extf %52 : f8E4M3FN to f32
            %54 = arith.andi %51, %c127_i32 : i32
            %55 = arith.cmpi eq, %54, %c127_i32 : i32
            %56 = arith.select %55, %cst, %53 : f32
            %extracted_0 = tensor.extract %44[%49, %50] : tensor<?x?xf32>
            %57 = arith.mulf %56, %extracted_0 : f32
            %58 = arith.truncf %57 : f32 to bf16
            %59 = arith.bitcast %58 : bf16 to i16
            linalg.yield %59 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %46, %42, offsets = [0], sizes = [%36], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%36}
          return
        }
        iree_codegen.dispatch_config @fp8_roundtrip_64_dispatch_3_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @fp8_roundtrip_64(%arg0: !hal.buffer_view, %arg1: !hal.fence, %arg2: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @fp8_roundtrip_64(%input0: tensor<?x?xi16>) -> (%output0: tensor<?x?xi16>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c512 = arith.constant 512 : index
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg1 : (!hal.fence) => !stream.timepoint
    %6 = arith.muli %0, %1 overflow<nsw> : index
    %7 = arith.muli %6, %c2 : index
    %8 = arith.divui %1, %c64 : index
    %9 = arith.muli %0, %8 overflow<nsw> : index
    %10 = arith.muli %9, %c4 : index
    %11 = util.align %7, %c64 : index
    %12 = arith.addi %11, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%12} => !stream.timepoint
    %13 = stream.resource.subview %result[%c0] : !stream.resource<external>{%12} -> !stream.resource<external>{%c4}
    %14 = stream.resource.subview %result[%c64] : !stream.resource<external>{%12} -> !stream.resource<external>{%7}
    %15 = util.align %10, %c64 : index
    %16 = util.align %6, %c64 : index
    %17 = arith.addi %15, %16 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%17} => !stream.timepoint
    %18 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %19 = arith.index_castui %6 : index to i64
    %20 = arith.index_castui %6 : index to i32
    %21 = arith.shrui %19, %c32_i64 : i64
    %22 = arith.trunci %21 : i64 to i32
    %23 = arith.index_castui %9 : index to i64
    %24 = arith.index_castui %9 : index to i32
    %25 = arith.shrui %23, %c32_i64 : i64
    %26 = arith.trunci %25 : i64 to i32
    %27 = arith.index_castui %15 : index to i64
    %28 = arith.index_castui %15 : index to i32
    %29 = arith.shrui %27, %c32_i64 : i64
    %30 = arith.trunci %29 : i64 to i32
    %31 = arith.index_castui %0 : index to i64
    %32 = arith.index_castui %0 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %1 : index to i64
    %36 = arith.index_castui %1 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %8 : index to i64
    %40 = arith.index_castui %8 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%18) => with(%4 as %arg3: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg4: !stream.resource<constant>{%c512}, %result as %arg5: !stream.resource<external>{%12}, %result_0 as %arg6: !stream.resource<transient>{%17}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @fp8_roundtrip_64_dispatch_0::@vulkan_spirv_fb::@fp8_roundtrip_64_dispatch_0_reduction_D_i16xi32[%6](%20, %22 : i32, i32) {
          ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg5[%c0 for %12] : !stream.resource<external>{%12}
        }
        stream.cmd.dispatch @fp8_roundtrip_64_dispatch_1::@vulkan_spirv_fb::@fp8_roundtrip_64_dispatch_1_reduction_Dx64_i16xf32[%9](%24, %26 : i32, i32) {
          ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg6[%c0 for %17] : !stream.resource<transient>{%17}
        }
      }
      stream.cmd.dispatch @fp8_roundtrip_64_dispatch_2::@vulkan_spirv_fb::@fp8_roundtrip_64_dispatch_2_elementwise_broadcast_D_i8[%6, %0, %1, %8](%28, %30, %20, %22, %32, %34, %36, %38, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg6[%c0 for %17] : !stream.resource<transient>{%17},
        ro %arg4[%c0 for %c512] : !stream.resource<constant>{%c512},
        wo %arg6[%c0 for %17] : !stream.resource<transient>{%17}
      }
      stream.cmd.dispatch @fp8_roundtrip_64_dispatch_3::@vulkan_spirv_fb::@fp8_roundtrip_64_dispatch_3_elementwise_broadcast_D_i16[%6, %1, %0, %8](%28, %30, %20, %22, %36, %38, %32, %34, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %17] : !stream.resource<transient>{%17},
        wo %arg5[%c0 for %12] : !stream.resource<external>{%12}
      }
    } => !stream.timepoint
    %44 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%43) => %result_0 : !stream.resource<transient>{%17} => !stream.timepoint
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %44 => (%arg2 : !hal.fence)
    %45 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %14 : tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3} -> !hal.buffer_view
    %46 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %13 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %45, %46 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @fp8_roundtrip_128_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp8_roundtrip_128_dispatch_1_reduction_Dx128_i16xf32 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp8_roundtrip_128_dispatch_1_reduction_Dx128_i16xf32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8388607_i32 = arith.constant 8388607 : i32
          %c23_i32 = arith.constant 23 : i32
          %cst = arith.constant 0.00223214296 : f32
          %cst_0 = arith.constant 9.99999974E-5 : f32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = util.assume.int %6<umin = 0, umax = 9223372036854775807> : index
          %8 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
          %9 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x128xi16>>{%8}
          %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%8}
          %11 = iree_tensor_ext.dispatch.tensor.load %9, offsets = [0, 0], sizes = [%8, 128], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x128xi16>>{%8} -> tensor<?x128xi16>
          %12 = tensor.empty(%8) : tensor<?xf32>
          %13 = linalg.fill ins(%cst_0 : f32) outs(%12 : tensor<?xf32>) -> tensor<?xf32>
          %14 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0)>], iterator_types = ["parallel", "reduction"]} ins(%11 : tensor<?x128xi16>) outs(%13 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: i16, %out: f32):
            %16 = arith.bitcast %in : i16 to bf16
            %17 = arith.extf %16 : bf16 to f32
            %18 = math.absf %17 : f32
            %19 = arith.maximumf %18, %out : f32
            linalg.yield %19 : f32
          } -> tensor<?xf32>
          %15 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%14 : tensor<?xf32>) outs(%12 : tensor<?xf32>) {
          ^bb0(%in: f32, %out: f32):
            %16 = arith.mulf %in, %cst : f32
            %17 = arith.bitcast %16 : f32 to i32
            %18 = arith.shrui %17, %c23_i32 : i32
            %19 = arith.andi %17, %c8388607_i32 : i32
            %20 = arith.cmpi ne, %19, %c0_i32 : i32
            %21 = arith.extui %20 : i1 to i32
            %22 = arith.addi %18, %21 : i32
            %23 = arith.shli %22, %c23_i32 : i32
            %24 = arith.bitcast %23 : i32 to f32
            linalg.yield %24 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %15, %10, offsets = [0], sizes = [%8], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%8}
          return
        }
        iree_codegen.dispatch_config @fp8_roundtrip_128_dispatch_1_reduction_Dx128_i16xf32 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @fp8_roundtrip_128_dispatch_2 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c128_i32 = arith.constant 128 : i32
          %c24_i32 = arith.constant 24 : i32
          %c1_i32 = arith.constant 1 : i32
          %c126 = arith.constant 126 : index
          %c2 = arith.constant 2 : index
          %c1 = arith.constant 1 : index
          %c128 = arith.constant 128 : index
          %cst = arith.constant 4.480000e+02 : f32
          %cst_0 = arith.constant -4.480000e+02 : f32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 {stream.alignment = 64 : index} : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<udiv = 64>, 
              %19<umin = 0, umax = 9223372036854775807>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 70368744177663>
            : index, index, index, index, index
          %36 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(ReadOnly) : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>>
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 0 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 1 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 2 : index
          %40 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 3 : index
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%38, %39}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%35#0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%38, %39} -> tensor<?x?xi16>
          %45 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0], sizes = [%38, %40], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40} -> tensor<?x?xf32>
          %46 = iree_tensor_ext.dispatch.tensor.load %36, offsets = [0], sizes = [127], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>> -> tensor<127xf32>
          %47 = tensor.empty(%37) : tensor<?xi8>
          %48 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%47 : tensor<?xi8>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i8):
            %49 = linalg.index 0 : index
            %50 = arith.remsi %49, %39 : index
            %51 = arith.divsi %49, %39 : index
            %52 = arith.divui %50, %c128 : index
            %extracted = tensor.extract %44[%51, %50] : tensor<?x?xi16>
            %53 = arith.bitcast %extracted : i16 to bf16
            %54 = arith.extf %53 : bf16 to f32
            %extracted_1 = tensor.extract %45[%51, %52] : tensor<?x?xf32>
            %55 = arith.divf %54, %extracted_1 : f32
            %56 = arith.maximumf %55, %cst_0 : f32
            %57 = arith.minimumf %56, %cst : f32
            %58 = math.absf %57 : f32
            %59 = arith.minimumf %58, %cst : f32
            %60:2 = scf.while (%arg0 = %c0, %arg1 = %c126) : (index, index) -> (index, index) {
              %84 = arith.cmpi ult, %arg0, %arg1 : index
              scf.condition(%84) %arg0, %arg1 : index, index
            } do {
            ^bb0(%arg0: index, %arg1: index):
              %84 = arith.addi %arg0, %arg1 : index
              %85 = arith.addi %84, %c1 : index
              %86 = arith.divui %85, %c2 : index
              %extracted_4 = tensor.extract %46[%86] : tensor<127xf32>
              %87 = arith.cmpf ole, %extracted_4, %59 : f32
              %88 = arith.subi %86, %c1 : index
              %89 = arith.select %87, %86, %arg0 : index
              %90 = arith.select %87, %arg1, %88 : index
              scf.yield %89, %90 : index, index
            }
            %61 = arith.addi %60#0, %c1 : index
            %62 = arith.minui %61, %c126 : index
            %extracted_2 = tensor.extract %46[%60#0] : tensor<127xf32>
            %extracted_3 = tensor.extract %46[%62] : tensor<127xf32>
            %63 = arith.subf %59, %extracted_2 : f32
            %64 = arith.subf %59, %extracted_3 : f32
            %65 = math.absf %63 : f32
            %66 = math.absf %64 : f32
            %67 = arith.cmpf olt, %66, %65 : f32
            %68 = arith.cmpf oeq, %66, %65 : f32
            %69 = arith.index_castui %60#0 : index to i32
            %70 = arith.index_castui %62 : index to i32
            %71 = arith.andi %69, %c1_i32 : i32
            %72 = arith.andi %70, %c1_i32 : i32
            %73 = arith.cmpi ne, %71, %c0_i32 : i32
            %74 = arith.cmpi eq, %72, %c0_i32 : i32
            %75 = arith.andi %68, %74 : i1
            %76 = arith.andi %75, %73 : i1
            %77 = arith.ori %67, %76 : i1
            %78 = arith.select %77, %70, %69 : i32
            %79 = arith.bitcast %57 : f32 to i32
            %80 = arith.shrui %79, %c24_i32 : i32
            %81 = arith.andi %80, %c128_i32 : i32
            %82 = arith.ori %78, %81 : i32
            %83 = arith.trunci %82 : i32 to i8
            linalg.yield %83 : i8
          } -> tensor<?xi8>
          iree_tensor_ext.dispatch.tensor.store %48, %43, offsets = [0], sizes = [%37], strides = [1] : tensor<?xi8> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          return
        }
        iree_codegen.dispatch_config @fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @fp8_roundtrip_128_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp8_roundtrip_128_dispatch_3_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp8_roundtrip_128_dispatch_3_elementwise_broadcast_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant 0x7FC00000 : f32
          %c128 = arith.constant 128 : index
          %c127_i32 = arith.constant 127 : i32
          %c0 = arith.constant 0 : index
          %c64 = arith.constant 64 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 {stream.alignment = 64 : index} : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<udiv = 64>, 
              %19<umin = 0, umax = 9223372036854775807>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 70368744177663>
            : index, index, index, index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 1 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 2 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 3 : index
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%35#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%38, %37}
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c64) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%36}
          %43 = iree_tensor_ext.dispatch.tensor.load %40, offsets = [0, 0], sizes = [%38, %37], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%38, %37} -> tensor<?x?xi8>
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39} -> tensor<?x?xf32>
          %45 = tensor.empty(%36) : tensor<?xi16>
          %46 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%45 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %47 = linalg.index 0 : index
            %48 = arith.remsi %47, %37 : index
            %49 = arith.divsi %47, %37 : index
            %50 = arith.divui %48, %c128 : index
            %extracted = tensor.extract %43[%49, %48] : tensor<?x?xi8>
            %51 = arith.extui %extracted : i8 to i32
            %52 = arith.bitcast %extracted : i8 to f8E4M3FN
            %53 = arith.extf %52 : f8E4M3FN to f32
            %54 = arith.andi %51, %c127_i32 : i32
            %55 = arith.cmpi eq, %54, %c127_i32 : i32
            %56 = arith.select %55, %cst, %53 : f32
            %extracted_0 = tensor.extract %44[%49, %50] : tensor<?x?xf32>
            %57 = arith.mulf %56, %extracted_0 : f32
            %58 = arith.truncf %57 : f32 to bf16
            %59 = arith.bitcast %58 : bf16 to i16
            linalg.yield %59 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %46, %42, offsets = [0], sizes = [%36], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%36}
          return
        }
        iree_codegen.dispatch_config @fp8_roundtrip_128_dispatch_3_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @fp8_roundtrip_128(%arg0: !hal.buffer_view, %arg1: !hal.fence, %arg2: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @fp8_roundtrip_128(%input0: tensor<?x?xi16>) -> (%output0: tensor<?x?xi16>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c512 = arith.constant 512 : index
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c128 = arith.constant 128 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg1 : (!hal.fence) => !stream.timepoint
    %6 = arith.muli %0, %1 overflow<nsw> : index
    %7 = arith.muli %6, %c2 : index
    %8 = arith.divui %1, %c128 : index
    %9 = arith.muli %0, %8 overflow<nsw> : index
    %10 = arith.muli %9, %c4 : index
    %11 = util.align %7, %c64 : index
    %12 = arith.addi %11, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%12} => !stream.timepoint
    %13 = stream.resource.subview %result[%c0] : !stream.resource<external>{%12} -> !stream.resource<external>{%c4}
    %14 = stream.resource.subview %result[%c64] : !stream.resource<external>{%12} -> !stream.resource<external>{%7}
    %15 = util.align %10, %c64 : index
    %16 = util.align %6, %c64 : index
    %17 = arith.addi %15, %16 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%17} => !stream.timepoint
    %18 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %19 = arith.index_castui %6 : index to i64
    %20 = arith.index_castui %6 : index to i32
    %21 = arith.shrui %19, %c32_i64 : i64
    %22 = arith.trunci %21 : i64 to i32
    %23 = arith.index_castui %9 : index to i64
    %24 = arith.index_castui %9 : index to i32
    %25 = arith.shrui %23, %c32_i64 : i64
    %26 = arith.trunci %25 : i64 to i32
    %27 = arith.index_castui %15 : index to i64
    %28 = arith.index_castui %15 : index to i32
    %29 = arith.shrui %27, %c32_i64 : i64
    %30 = arith.trunci %29 : i64 to i32
    %31 = arith.index_castui %0 : index to i64
    %32 = arith.index_castui %0 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %1 : index to i64
    %36 = arith.index_castui %1 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %8 : index to i64
    %40 = arith.index_castui %8 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%18) => with(%4 as %arg3: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg4: !stream.resource<constant>{%c512}, %result as %arg5: !stream.resource<external>{%12}, %result_0 as %arg6: !stream.resource<transient>{%17}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @fp8_roundtrip_64_dispatch_0::@vulkan_spirv_fb::@fp8_roundtrip_64_dispatch_0_reduction_D_i16xi32[%6](%20, %22 : i32, i32) {
          ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg5[%c0 for %12] : !stream.resource<external>{%12}
        }
        stream.cmd.dispatch @fp8_roundtrip_128_dispatch_1::@vulkan_spirv_fb::@fp8_roundtrip_128_dispatch_1_reduction_Dx128_i16xf32[%9](%24, %26 : i32, i32) {
          ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg6[%c0 for %17] : !stream.resource<transient>{%17}
        }
      }
      stream.cmd.dispatch @fp8_roundtrip_128_dispatch_2::@vulkan_spirv_fb::@fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8[%6, %0, %1, %8](%28, %30, %20, %22, %32, %34, %36, %38, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg6[%c0 for %17] : !stream.resource<transient>{%17},
        ro %arg4[%c0 for %c512] : !stream.resource<constant>{%c512},
        wo %arg6[%c0 for %17] : !stream.resource<transient>{%17}
      }
      stream.cmd.dispatch @fp8_roundtrip_128_dispatch_3::@vulkan_spirv_fb::@fp8_roundtrip_128_dispatch_3_elementwise_broadcast_D_i16[%6, %1, %0, %8](%28, %30, %20, %22, %36, %38, %32, %34, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %17] : !stream.resource<transient>{%17},
        wo %arg5[%c0 for %12] : !stream.resource<external>{%12}
      }
    } => !stream.timepoint
    %44 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%43) => %result_0 : !stream.resource<transient>{%17} => !stream.timepoint
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %44 => (%arg2 : !hal.fence)
    %45 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %14 : tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3} -> !hal.buffer_view
    %46 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %13 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %45, %46 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @fp4_roundtrip_32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp4_roundtrip_32_dispatch_1_reduction_DxD_i16xi32 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp4_roundtrip_32_dispatch_1_reduction_DxD_i16xi32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8388607_i32 = arith.constant 8388607 : i32
          %c23_i32 = arith.constant 23 : i32
          %c16_i32 = arith.constant 16 : i32
          %c32767_i32 = arith.constant 32767 : i32
          %c448_i32 = arith.constant 448 : i32
          %cst = arith.constant 6.000000e+00 : f32
          %c0 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = util.assume.int %6<umin = 0, umax = 9223372036854775807> : index
          %8 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
          %9 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%8, %c32}
          %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi32>>{%8}
          %11 = iree_tensor_ext.dispatch.tensor.load %9, offsets = [0, 0], sizes = [%8, 32], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%8, %c32} -> tensor<?x32xi16>
          %12 = tensor.empty(%8) : tensor<?xi32>
          %13 = linalg.fill ins(%c448_i32 : i32) outs(%12 : tensor<?xi32>) -> tensor<?xi32>
          %14 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0)>], iterator_types = ["parallel", "reduction"]} ins(%11 : tensor<?x32xi16>) outs(%13 : tensor<?xi32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: i16, %out: i32):
            %16 = arith.extui %in : i16 to i32
            %17 = arith.andi %16, %c32767_i32 : i32
            %18 = arith.maxui %17, %out : i32
            linalg.yield %18 : i32
          } -> tensor<?xi32>
          %15 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%14 : tensor<?xi32>) outs(%12 : tensor<?xi32>) {
          ^bb0(%in: i32, %out: i32):
            %16 = arith.shli %in, %c16_i32 : i32
            %17 = arith.bitcast %16 : i32 to f32
            %18 = arith.divf %17, %cst : f32
            %19 = arith.bitcast %18 : f32 to i32
            %20 = arith.shrui %19, %c23_i32 : i32
            %21 = arith.andi %19, %c8388607_i32 : i32
            %22 = arith.cmpi ne, %21, %c0_i32 : i32
            %23 = arith.extui %22 : i1 to i32
            %24 = arith.addi %20, %23 : i32
            linalg.yield %24 : i32
          } -> tensor<?xi32>
          iree_tensor_ext.dispatch.tensor.store %15, %10, offsets = [0], sizes = [%8], strides = [1] : tensor<?xi32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi32>>{%8}
          return
        }
        iree_codegen.dispatch_config @fp4_roundtrip_32_dispatch_1_reduction_DxD_i16xi32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @fp4_roundtrip_32_dispatch_2 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %cst = arith.constant 7.812500e-03 : f32
          %cst_0 = arith.constant 3.906250e-03 : f32
          %cst_1 = arith.constant 6.000000e+00 : f32
          %cst_2 = arith.constant 5.000000e-01 : f32
          %cst_3 = arith.constant 1.000000e+00 : f32
          %cst_4 = arith.constant 1.500000e+00 : f32
          %cst_5 = arith.constant 2.000000e+00 : f32
          %cst_6 = arith.constant 3.000000e+00 : f32
          %cst_7 = arith.constant 4.000000e+00 : f32
          %cst_8 = arith.constant dense<[0.000000e+00, 5.000000e-01, 1.000000e+00, 1.500000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 6.000000e+00]> : tensor<8xf32>
          %c32 = arith.constant 32 : index
          %c32767_i32 = arith.constant 32767 : i32
          %c16_i32 = arith.constant 16 : i32
          %c23_i32 = arith.constant 23 : i32
          %c7_i32 = arith.constant 7 : i32
          %c127_i32 = arith.constant 127 : i32
          %c128_i32 = arith.constant 128 : i32
          %c1_i32 = arith.constant 1 : i32
          %c4_i32 = arith.constant 4 : i32
          %c2_i32 = arith.constant 2 : i32
          %c1 = arith.constant 1 : index
          %c2 = arith.constant 2 : index
          %c3 = arith.constant 3 : index
          %c4 = arith.constant 4 : index
          %c5 = arith.constant 5 : index
          %c6 = arith.constant 6 : index
          %c7 = arith.constant 7 : index
          %c4194304_i32 = arith.constant 4194304 : i32
          %c32768_i32 = arith.constant 32768 : i32
          %c64 = arith.constant 64 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = arith.extui %1 : i32 to i64
          %9 = arith.shli %8, %c32_i64 : i64
          %10 = arith.extui %0 : i32 to i64
          %11 = arith.ori %10, %9 : i64
          %12 = arith.index_castui %11 : i64 to index
          %13 = arith.extui %3 : i32 to i64
          %14 = arith.shli %13, %c32_i64 : i64
          %15 = arith.extui %2 : i32 to i64
          %16 = arith.ori %15, %14 : i64
          %17 = arith.index_castui %16 : i64 to index
          %18 = arith.extui %5 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %4 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 : i64 to index
          %23 = arith.extui %7 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %6 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28:4 = util.assume.int 
              %12<umin = 0, umax = 9223372036854775807>, 
              %17<umin = 0, umax = 9007199254740991>, 
              %22<umin = 0, umax = 9007199254740991>, 
              %27<umin = 0, umax = 281474976710655>
            : index, index, index, index
          %29 = iree_tensor_ext.dispatch.workload.ordinal %28#0, 0 : index
          %30 = iree_tensor_ext.dispatch.workload.ordinal %28#1, 1 : index
          %31 = iree_tensor_ext.dispatch.workload.ordinal %28#2, 2 : index
          %32 = iree_tensor_ext.dispatch.workload.ordinal %28#3, 3 : index
          %33 = hal.interface.binding.subspan layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%30, %31}
          %34 = hal.interface.binding.subspan layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%30, %32}
          %35 = hal.interface.binding.subspan layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c64) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%29}
          %36 = iree_tensor_ext.dispatch.tensor.load %33, offsets = [0, 0], sizes = [%30, %31], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%30, %31} -> tensor<?x?xi16>
          %37 = iree_tensor_ext.dispatch.tensor.load %34, offsets = [0, 0], sizes = [%30, %32], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%30, %32} -> tensor<?x?xi32>
          %38 = tensor.empty(%29) : tensor<?xi16>
          %39 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%38 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %40 = linalg.index 0 : index
            %41 = arith.remsi %40, %31 : index
            %42 = arith.divsi %40, %31 : index
            %43 = arith.divui %41, %c32 : index
            %extracted = tensor.extract %36[%42, %41] : tensor<?x?xi16>
            %44 = arith.extui %extracted : i16 to i32
            %45 = arith.andi %44, %c32767_i32 : i32
            %46 = arith.shli %45, %c16_i32 : i32
            %47 = arith.bitcast %46 : i32 to f32
            %extracted_9 = tensor.extract %37[%42, %43] : tensor<?x?xi32>
            %48 = arith.shli %extracted_9, %c23_i32 : i32
            %49 = arith.bitcast %48 : i32 to f32
            %50 = arith.divf %47, %49 : f32
            %51 = arith.shrui %45, %c7_i32 : i32
            %52 = arith.andi %44, %c127_i32 : i32
            %53 = arith.cmpi eq, %51, %c0_i32 : i32
            %54 = arith.select %53, %c0_i32, %c128_i32 : i32
            %55 = arith.ori %52, %54 : i32
            %56 = arith.maxui %51, %c1_i32 : i32
            %57 = arith.minui %56, %c4_i32 : i32
            %58 = arith.subi %57, %c1_i32 : i32
            %59 = arith.shli %55, %58 : i32
            %60 = arith.uitofp %59 : i32 to f32
            %61 = arith.cmpi eq, %extracted_9, %c1_i32 : i32
            %62 = arith.select %61, %cst, %cst_0 : f32
            %63 = arith.mulf %60, %62 : f32
            %64 = arith.cmpi ule, %extracted_9, %c2_i32 : i32
            %65 = arith.select %64, %63, %50 : f32
            %66 = arith.minimumf %65, %cst_1 : f32
            %67 = math.absf %66 : f32
            %68 = arith.subf %66, %cst_2 : f32
            %69 = math.absf %68 : f32
            %70 = arith.cmpf olt, %69, %67 : f32
            %71 = arith.select %70, %c1, %c0 : index
            %72 = arith.select %70, %69, %67 : f32
            %73 = arith.subf %66, %cst_3 : f32
            %74 = math.absf %73 : f32
            %75 = arith.cmpf olt, %74, %72 : f32
            %76 = arith.cmpf oeq, %74, %72 : f32
            %77 = arith.index_castui %71 : index to i32
            %78 = arith.andi %77, %c1_i32 : i32
            %79 = arith.cmpi ne, %78, %c0_i32 : i32
            %80 = arith.andi %76, %79 : i1
            %81 = arith.ori %75, %80 : i1
            %82 = arith.select %81, %c2, %71 : index
            %83 = arith.select %81, %74, %72 : f32
            %84 = arith.subf %66, %cst_4 : f32
            %85 = math.absf %84 : f32
            %86 = arith.cmpf olt, %85, %83 : f32
            %87 = arith.select %86, %c3, %82 : index
            %88 = arith.select %86, %85, %83 : f32
            %89 = arith.subf %66, %cst_5 : f32
            %90 = math.absf %89 : f32
            %91 = arith.cmpf olt, %90, %88 : f32
            %92 = arith.cmpf oeq, %90, %88 : f32
            %93 = arith.index_castui %87 : index to i32
            %94 = arith.andi %93, %c1_i32 : i32
            %95 = arith.cmpi ne, %94, %c0_i32 : i32
            %96 = arith.andi %92, %95 : i1
            %97 = arith.ori %91, %96 : i1
            %98 = arith.select %97, %c4, %87 : index
            %99 = arith.select %97, %90, %88 : f32
            %100 = arith.subf %66, %cst_6 : f32
            %101 = math.absf %100 : f32
            %102 = arith.cmpf olt, %101, %99 : f32
            %103 = arith.select %102, %c5, %98 : index
            %104 = arith.select %102, %101, %99 : f32
            %105 = arith.subf %66, %cst_7 : f32
            %106 = math.absf %105 : f32
            %107 = arith.cmpf olt, %106, %104 : f32
            %108 = arith.cmpf oeq, %106, %104 : f32
            %109 = arith.index_castui %103 : index to i32
            %110 = arith.andi %109, %c1_i32 : i32
            %111 = arith.cmpi ne, %110, %c0_i32 : i32
            %112 = arith.andi %108, %111 : i1
            %113 = arith.ori %107, %112 : i1
            %114 = arith.select %113, %c6, %103 : index
            %115 = arith.select %113, %106, %104 : f32
            %116 = arith.subf %66, %cst_1 : f32
            %117 = math.absf %116 : f32
            %118 = arith.cmpf olt, %117, %115 : f32
            %119 = arith.select %118, %c7, %114 : index
            %extracted_10 = tensor.extract %cst_8[%119] : tensor<8xf32>
            %120 = arith.mulf %extracted_10, %49 : f32
            %121 = arith.bitcast %120 : f32 to i32
            %122 = arith.index_castui %119 : index to i32
            %123 = arith.cmpi eq, %122, %c1_i32 : i32
            %124 = arith.andi %61, %123 : i1
            %125 = arith.select %124, %c4194304_i32, %121 : i32
            %126 = arith.cmpi eq, %122, %c0_i32 : i32
            %127 = arith.select %126, %c0_i32, %125 : i32
            %128 = arith.andi %44, %c32768_i32 : i32
            %129 = arith.shli %128, %c16_i32 : i32
            %130 = arith.ori %127, %129 : i32
            %131 = arith.shrui %130, %c16_i32 : i32
            %132 = arith.trunci %131 : i32 to i16
            linalg.yield %132 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %39, %35, offsets = [0], sizes = [%29], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%29}
          return
        }
        iree_codegen.dispatch_config @fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @fp4_roundtrip_32(%arg0: !hal.buffer_view, %arg1: !hal.fence, %arg2: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @fp4_roundtrip_32(%input0: tensor<?x?xi16>) -> (%output0: tensor<?x?xi16>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c32 = arith.constant 32 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg1 : (!hal.fence) => !stream.timepoint
    %6 = arith.divui %1, %c32 : index
    %7 = arith.muli %0, %1 overflow<nsw> : index
    %8 = arith.muli %7, %c2 : index
    %9 = arith.muli %0, %6 overflow<nsw> : index
    %10 = arith.muli %9, %c4 : index
    %11 = util.align %8, %c64 : index
    %12 = arith.addi %11, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%12} => !stream.timepoint
    %13 = stream.resource.subview %result[%c0] : !stream.resource<external>{%12} -> !stream.resource<external>{%c4}
    %14 = stream.resource.subview %result[%c64] : !stream.resource<external>{%12} -> !stream.resource<external>{%8}
    %15 = util.align %10, %c64 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%15} => !stream.timepoint
    %16 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %17 = arith.index_castui %7 : index to i64
    %18 = arith.index_castui %7 : index to i32
    %19 = arith.shrui %17, %c32_i64 : i64
    %20 = arith.trunci %19 : i64 to i32
    %21 = arith.index_castui %9 : index to i64
    %22 = arith.index_castui %9 : index to i32
    %23 = arith.shrui %21, %c32_i64 : i64
    %24 = arith.trunci %23 : i64 to i32
    %25 = arith.index_castui %0 : index to i64
    %26 = arith.index_castui %0 : index to i32
    %27 = arith.shrui %25, %c32_i64 : i64
    %28 = arith.trunci %27 : i64 to i32
    %29 = arith.index_castui %1 : index to i64
    %30 = arith.index_castui %1 : index to i32
    %31 = arith.shrui %29, %c32_i64 : i64
    %32 = arith.trunci %31 : i64 to i32
    %33 = arith.index_castui %6 : index to i64
    %34 = arith.index_castui %6 : index to i32
    %35 = arith.shrui %33, %c32_i64 : i64
    %36 = arith.trunci %35 : i64 to i32
    %37 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%16) => with(%4 as %arg3: !stream.resource<external>{%3}, %result as %arg4: !stream.resource<external>{%12}, %result_0 as %arg5: !stream.resource<transient>{%15}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @fp8_roundtrip_64_dispatch_0::@vulkan_spirv_fb::@fp8_roundtrip_64_dispatch_0_reduction_D_i16xi32[%7](%18, %20 : i32, i32) {
          ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg4[%c0 for %12] : !stream.resource<external>{%12}
        }
        stream.cmd.dispatch @fp4_roundtrip_32_dispatch_1::@vulkan_spirv_fb::@fp4_roundtrip_32_dispatch_1_reduction_DxD_i16xi32[%9, %c32](%22, %24 : i32, i32) {
          ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg5[%c0 for %15] : !stream.resource<transient>{%15}
        }
      }
      stream.cmd.dispatch @fp4_roundtrip_32_dispatch_2::@vulkan_spirv_fb::@fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16[%7, %0, %1, %6](%18, %20, %26, %28, %30, %32, %34, %36 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg3[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg5[%c0 for %15] : !stream.resource<transient>{%15},
        wo %arg4[%c0 for %12] : !stream.resource<external>{%12}
      }
    } => !stream.timepoint
    %38 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%37) => %result_0 : !stream.resource<transient>{%15} => !stream.timepoint
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %38 => (%arg2 : !hal.fence)
    %39 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %14 : tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3} -> !hal.buffer_view
    %40 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %13 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %39, %40 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @linear_normal_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_normal_f32_dispatch_0_reduction_D_f32xi32 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_normal_f32_dispatch_0_reduction_D_f32xi32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [1, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c2139095040_i32 = arith.constant 2139095040 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = util.assume.int %6<umin = 0, umax = 9223372036854775807> : index
          %8 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<i32>>
          %9 = iree_tensor_ext.dispatch.workload.ordinal %7, 0 : index
          %10 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%9}
          %11 = iree_tensor_ext.dispatch.tensor.load %10, offsets = [0], sizes = [%9], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%9} -> tensor<?xf32>
          %12 = tensor.empty() : tensor<i32>
          %13 = linalg.fill ins(%c0_i32 : i32) outs(%12 : tensor<i32>) -> tensor<i32>
          %14 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> ()>], iterator_types = ["reduction"]} ins(%11 : tensor<?xf32>) outs(%13 : tensor<i32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = []>} {
          ^bb0(%in: f32, %out: i32):
            %15 = arith.bitcast %in : f32 to i32
            %16 = arith.andi %15, %c2139095040_i32 : i32
            %17 = arith.cmpi eq, %16, %c2139095040_i32 : i32
            %18 = arith.extui %17 : i1 to i32
            %19 = arith.ori %out, %18 : i32
            linalg.yield %19 : i32
          } -> tensor<i32>
          iree_tensor_ext.dispatch.tensor.store %14, %8, offsets = [], sizes = [], strides = [] : tensor<i32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<i32>>
          return
        }
        iree_codegen.dispatch_config @linear_normal_f32_dispatch_0_reduction_D_f32xi32 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @linear_normal_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_normal_f32_dispatch_1_reduction_DxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_normal_f32_dispatch_1_reduction_DxD_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c9_i32 = arith.constant 9 : i32
          %c8_i32 = arith.constant 8 : i32
          %c255_i32 = arith.constant 255 : i32
          %c23_i32 = arith.constant 23 : i32
          %c4_i32 = arith.constant 4 : i32
          %c7_i32 = arith.constant 7 : i32
          %c3_i32 = arith.constant 3 : i32
          %c2_i32 = arith.constant 2 : i32
          %c14680064_i32 = arith.constant 14680064 : i32
          %c8388608_i32 = arith.constant 8388608 : i32
          %c8388607_i32 = arith.constant 8388607 : i32
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %0 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = arith.extui %1 : i32 to i64
          %4 = arith.shli %3, %c32_i64 : i64
          %5 = arith.extui %0 : i32 to i64
          %6 = arith.ori %5, %4 : i64
          %7 = arith.index_castui %6 : i64 to index
          %8 = arith.bitcast %2 : i32 to f32
          %9 = util.assume.int %7<umin = 0, umax = 9223372036854775807> : index
          %10 = iree_tensor_ext.dispatch.workload.ordinal %9, 0 : index
          %11 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128}
          %12 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          %13 = iree_tensor_ext.dispatch.tensor.load %11, offsets = [0, 0], sizes = [%10, 128], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128} -> tensor<?x128xf32>
          %14 = tensor.empty(%10) : tensor<?xf32>
          %15 = linalg.fill ins(%8 : f32) outs(%14 : tensor<?xf32>) -> tensor<?xf32>
          %16 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0)>], iterator_types = ["parallel", "reduction"]} ins(%13 : tensor<?x128xf32>) outs(%15 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: f32):
            %18 = math.absf %in : f32
            %19 = arith.maximumf %18, %out : f32
            linalg.yield %19 : f32
          } -> tensor<?xf32>
          %17 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%16 : tensor<?xf32>) outs(%14 : tensor<?xf32>) {
          ^bb0(%in: f32, %out: f32):
            %18 = arith.bitcast %in : f32 to i32
            %19 = arith.andi %18, %c8388607_i32 : i32
            %20 = arith.ori %19, %c8388608_i32 : i32
            %21 = arith.cmpi uge, %20, %c14680064_i32 : i32
            %22 = arith.select %21, %c2_i32, %c3_i32 : i32
            %23 = arith.shli %20, %22 : i32
            %24 = arith.divui %23, %c7_i32 : i32
            %25 = arith.remui %23, %c7_i32 : i32
            %26 = arith.cmpi uge, %25, %c4_i32 : i32
            %27 = arith.extui %26 : i1 to i32
            %28 = arith.addi %24, %27 : i32
            %29 = arith.shrui %18, %c23_i32 : i32
            %30 = arith.andi %29, %c255_i32 : i32
            %31 = arith.select %21, %c8_i32, %c9_i32 : i32
            %32 = arith.subi %30, %31 : i32
            %33 = arith.shli %32, %c23_i32 : i32
            %34 = arith.andi %28, %c8388607_i32 : i32
            %35 = arith.ori %33, %34 : i32
            %36 = arith.bitcast %35 : i32 to f32
            %37 = arith.cmpi eq, %30, %c255_i32 : i32
            %38 = arith.select %37, %in, %36 : f32
            linalg.yield %38 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %17, %12, offsets = [0], sizes = [%10], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          return
        }
        iree_codegen.dispatch_config @linear_normal_f32_dispatch_1_reduction_DxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @linear_normal_f32_dispatch_2 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c128_i32 = arith.constant 128 : i32
          %c24_i32 = arith.constant 24 : i32
          %c1_i32 = arith.constant 1 : i32
          %c126 = arith.constant 126 : index
          %c2 = arith.constant 2 : index
          %c1 = arith.constant 1 : index
          %c128 = arith.constant 128 : index
          %cst = arith.constant 4.480000e+02 : f32
          %cst_0 = arith.constant -4.480000e+02 : f32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 {stream.alignment = 64 : index} : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<udiv = 64>, 
              %19<umin = 0, umax = 9223372036854775807>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 70368744177663>
            : index, index, index, index, index
          %36 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(ReadOnly) : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>>
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 0 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 1 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 2 : index
          %40 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 3 : index
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%35#0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39} -> tensor<?x?xf32>
          %45 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0], sizes = [%38, %40], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40} -> tensor<?x?xf32>
          %46 = iree_tensor_ext.dispatch.tensor.load %36, offsets = [0], sizes = [127], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>> -> tensor<127xf32>
          %47 = tensor.empty(%37) : tensor<?xi8>
          %48 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%47 : tensor<?xi8>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i8):
            %49 = linalg.index 0 : index
            %50 = arith.remsi %49, %39 : index
            %51 = arith.divsi %49, %39 : index
            %52 = arith.divui %50, %c128 : index
            %extracted = tensor.extract %44[%51, %50] : tensor<?x?xf32>
            %extracted_1 = tensor.extract %45[%51, %52] : tensor<?x?xf32>
            %53 = arith.divf %extracted, %extracted_1 : f32
            %54 = arith.maximumf %53, %cst_0 : f32
            %55 = arith.minimumf %54, %cst : f32
            %56 = math.absf %55 : f32
            %57 = arith.minimumf %56, %cst : f32
            %58:2 = scf.while (%arg0 = %c0, %arg1 = %c126) : (index, index) -> (index, index) {
              %82 = arith.cmpi ult, %arg0, %arg1 : index
              scf.condition(%82) %arg0, %arg1 : index, index
            } do {
            ^bb0(%arg0: index, %arg1: index):
              %82 = arith.addi %arg0, %arg1 : index
              %83 = arith.addi %82, %c1 : index
              %84 = arith.divui %83, %c2 : index
              %extracted_4 = tensor.extract %46[%84] : tensor<127xf32>
              %85 = arith.cmpf ole, %extracted_4, %57 : f32
              %86 = arith.subi %84, %c1 : index
              %87 = arith.select %85, %84, %arg0 : index
              %88 = arith.select %85, %arg1, %86 : index
              scf.yield %87, %88 : index, index
            }
            %59 = arith.addi %58#0, %c1 : index
            %60 = arith.minui %59, %c126 : index
            %extracted_2 = tensor.extract %46[%58#0] : tensor<127xf32>
            %extracted_3 = tensor.extract %46[%60] : tensor<127xf32>
            %61 = arith.subf %57, %extracted_2 : f32
            %62 = arith.subf %57, %extracted_3 : f32
            %63 = math.absf %61 : f32
            %64 = math.absf %62 : f32
            %65 = arith.cmpf olt, %64, %63 : f32
            %66 = arith.cmpf oeq, %64, %63 : f32
            %67 = arith.index_castui %58#0 : index to i32
            %68 = arith.index_castui %60 : index to i32
            %69 = arith.andi %67, %c1_i32 : i32
            %70 = arith.andi %68, %c1_i32 : i32
            %71 = arith.cmpi ne, %69, %c0_i32 : i32
            %72 = arith.cmpi eq, %70, %c0_i32 : i32
            %73 = arith.andi %66, %72 : i1
            %74 = arith.andi %73, %71 : i1
            %75 = arith.ori %65, %74 : i1
            %76 = arith.select %75, %68, %67 : i32
            %77 = arith.bitcast %55 : f32 to i32
            %78 = arith.shrui %77, %c24_i32 : i32
            %79 = arith.andi %78, %c128_i32 : i32
            %80 = arith.ori %76, %79 : i32
            %81 = arith.trunci %80 : i32 to i8
            linalg.yield %81 : i8
          } -> tensor<?xi8>
          iree_tensor_ext.dispatch.tensor.store %48, %43, offsets = [0], sizes = [%37], strides = [1] : tensor<?xi8> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          return
        }
        iree_codegen.dispatch_config @linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @linear_normal_f32_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c128 = arith.constant 128 : index
          %cst = arith.constant 0x7FC00000 : f32
          %c127_i32 = arith.constant 127 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 {stream.alignment = 64 : index} : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:3 = util.assume.int 
              %14[<udiv = 64>, <udiv = 64>, <umin = 0, umax = 0>, <udiv = 64>], 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %19, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 2 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 3 : index
          %39 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%35#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%37, %38}
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          %41 = iree_tensor_ext.dispatch.workload.ordinal %24, 1 : index
          %42 = iree_tensor_ext.dispatch.tensor.load %39, offsets = [0, 0], sizes = [%37, %38], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%37, %38} -> tensor<?x?xi8>
          %43 = tensor.empty(%36) : tensor<?xf32>
          %44 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%43 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %45 = linalg.index 0 : index
            %46 = arith.remsi %45, %c128 : index
            %47 = arith.divsi %45, %c128 : index
            %48 = arith.addi %41, %46 : index
            %extracted = tensor.extract %42[%47, %48] : tensor<?x?xi8>
            %49 = arith.extui %extracted : i8 to i32
            %50 = arith.bitcast %extracted : i8 to f8E4M3FN
            %51 = arith.extf %50 : f8E4M3FN to f32
            %52 = arith.andi %49, %c127_i32 : i32
            %53 = arith.cmpi eq, %52, %c127_i32 : i32
            %54 = arith.select %53, %cst, %51 : f32
            linalg.yield %54 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %44, %40, offsets = [0], sizes = [%36], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          return
        }
        iree_codegen.dispatch_config @linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @linear_normal_f32_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %cst = arith.constant 0x7FC00000 : f32
          %c127_i32 = arith.constant 127 : i32
          %0 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = arith.extui %1 : i32 to i64
          %13 = arith.shli %12, %c32_i64 : i64
          %14 = arith.extui %0 : i32 to i64
          %15 = arith.ori %14, %13 : i64
          %16 = arith.index_castui %15 : i64 to index
          %17 = arith.extui %3 : i32 to i64
          %18 = arith.shli %17, %c32_i64 : i64
          %19 = arith.extui %2 : i32 to i64
          %20 = arith.ori %19, %18 : i64
          %21 = arith.index_castui %20 : i64 to index
          %22 = arith.extui %5 : i32 to i64
          %23 = arith.shli %22, %c32_i64 : i64
          %24 = arith.extui %4 : i32 to i64
          %25 = arith.ori %24, %23 : i64
          %26 = arith.index_castui %25 : i64 to index
          %27 = arith.extui %7 : i32 to i64
          %28 = arith.shli %27, %c32_i64 : i64
          %29 = arith.extui %6 : i32 to i64
          %30 = arith.ori %29, %28 : i64
          %31 = arith.index_castui %30 : i64 to index
          %32 = arith.extui %9 : i32 to i64
          %33 = arith.shli %32, %c32_i64 : i64
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.ori %34, %33 : i64
          %36 = arith.index_castui %35 : i64 to index
          %37 = arith.extui %11 : i32 to i64
          %38 = arith.shli %37, %c32_i64 : i64
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.ori %39, %38 : i64
          %41 = arith.index_castui %40 : i64 to index
          %42:3 = util.assume.int 
              %31<umin = 0, umax = 9007199254740991>, 
              %36<umin = 0, umax = 9007199254740991>, 
              %41<umin = 0, umax = 9007199254740991>
            : index, index, index
          %43 = iree_tensor_ext.dispatch.workload.ordinal %21, 0 : index
          %44 = iree_tensor_ext.dispatch.workload.ordinal %42#0, 2 : index
          %45 = iree_tensor_ext.dispatch.workload.ordinal %42#1, 3 : index
          %46 = iree_tensor_ext.dispatch.workload.ordinal %42#2, 4 : index
          %47 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%44, %45, %46}
          %48 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%16) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%43}
          %49 = iree_tensor_ext.dispatch.workload.ordinal %26, 1 : index
          %50 = iree_tensor_ext.dispatch.tensor.load %47, offsets = [0, 0, 0], sizes = [%44, %45, %46], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%44, %45, %46} -> tensor<?x?x?xi8>
          %51 = tensor.empty(%43) : tensor<?xf32>
          %52 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%51 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %53 = linalg.index 0 : index
            %54 = arith.remsi %53, %c128 : index
            %55 = arith.divsi %53, %c128 : index
            %56 = arith.addi %49, %54 : index
            %extracted = tensor.extract %50[%c0, %55, %56] : tensor<?x?x?xi8>
            %57 = arith.extui %extracted : i8 to i32
            %58 = arith.bitcast %extracted : i8 to f8E4M3FN
            %59 = arith.extf %58 : f8E4M3FN to f32
            %60 = arith.andi %57, %c127_i32 : i32
            %61 = arith.cmpi eq, %60, %c127_i32 : i32
            %62 = arith.select %61, %cst, %59 : f32
            linalg.yield %62 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %52, %48, offsets = [0], sizes = [%43], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%43}
          return
        }
        iree_codegen.dispatch_config @linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @linear_normal_f32_dispatch_5 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_normal_f32_dispatch_5_matmul_DxDxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_normal_f32_dispatch_5_matmul_DxDxD_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant 0.000000e+00 : f32
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %0 = hal.interface.constant.load layout(<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = arith.extui %1 : i32 to i64
          %5 = arith.shli %4, %c32_i64 : i64
          %6 = arith.extui %0 : i32 to i64
          %7 = arith.ori %6, %5 : i64
          %8 = arith.index_castui %7 : i64 to index
          %9 = arith.extui %3 : i32 to i64
          %10 = arith.shli %9, %c32_i64 : i64
          %11 = arith.extui %2 : i32 to i64
          %12 = arith.ori %11, %10 : i64
          %13 = arith.index_castui %12 : i64 to index
          %14:2 = util.assume.int 
              %8<umin = 0, umax = 9007199254740991>, 
              %13<umin = 0, umax = 9007199254740991>
            : index, index
          %15 = iree_tensor_ext.dispatch.workload.ordinal %14#0, 1 : index
          %16 = iree_tensor_ext.dispatch.workload.ordinal %14#1, 2 : index
          %17 = hal.interface.binding.subspan layout(<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%15, %c128}
          %18 = hal.interface.binding.subspan layout(<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%16, %c128}
          %19 = hal.interface.binding.subspan layout(<constants = 4, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x?xf32>>{%15, %16}
          %20 = iree_tensor_ext.dispatch.tensor.load %17, offsets = [0, 0], sizes = [%15, 128], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%15, %c128} -> tensor<?x128xf32>
          %21 = iree_tensor_ext.dispatch.tensor.load %18, offsets = [0, 0], sizes = [%16, 128], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%16, %c128} -> tensor<?x128xf32>
          %22 = tensor.empty(%15, %16) : tensor<?x?xf32>
          %23 = linalg.fill ins(%cst : f32) outs(%22 : tensor<?x?xf32>) -> tensor<?x?xf32>
          %24 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d1, d2)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iterator_types = ["parallel", "parallel", "reduction"]} ins(%20, %21 : tensor<?x128xf32>, tensor<?x128xf32>) outs(%23 : tensor<?x?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[1, 64], [1, 1]]>} {
          ^bb0(%in: f32, %in_0: f32, %out: f32):
            %25 = arith.mulf %in, %in_0 : f32
            %26 = arith.addf %out, %25 : f32
            linalg.yield %26 : f32
          } -> tensor<?x?xf32>
          iree_tensor_ext.dispatch.tensor.store %24, %19, offsets = [0, 0], sizes = [%15, %16], strides = [1, 1] : tensor<?x?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x?xf32>>{%15, %16}
          return
        }
        iree_codegen.dispatch_config @linear_normal_f32_dispatch_5_matmul_DxDxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @linear_normal_f32_dispatch_6 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %0 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = arith.extui %1 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %0 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 {stream.alignment = 64 : index} : i64 to index
          %23 = arith.extui %3 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %2 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28 = arith.extui %5 : i32 to i64
          %29 = arith.shli %28, %c32_i64 : i64
          %30 = arith.extui %4 : i32 to i64
          %31 = arith.ori %30, %29 : i64
          %32 = arith.index_castui %31 : i64 to index
          %33 = arith.extui %7 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %6 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 : i64 to index
          %38 = arith.extui %9 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %8 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %11 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %10 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %13 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %12 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %15 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %14 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %17 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %16 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63:7 = util.assume.int 
              %22<udiv = 64>, 
              %37<umin = 0, umax = 9007199254740991>, 
              %42<umin = 0, umax = 70368744177663>, 
              %47<umin = 0, umax = 9007199254740991>, 
              %52<umin = 0, umax = 9007199254740991>, 
              %57<umin = 0, umax = 9007199254740991>, 
              %62<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index
          %64 = iree_tensor_ext.dispatch.workload.ordinal %63#1, 2 : index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %63#6, 7 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %27, 0 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %63#2, 3 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %63#3, 4 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %63#4, 5 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %63#5, 6 : index
          %71 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%64, %67}
          %72 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%68, %69, %70}
          %73 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%64, %65}
          %74 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%63#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%64, %65}
          %75 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%66}
          %76 = iree_tensor_ext.dispatch.workload.ordinal %32, 1 : index
          %77 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0, 0], sizes = [%64, %67], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%64, %67} -> tensor<?x?xf32>
          %78 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0, 0], sizes = [%68, %69, %70], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%68, %69, %70} -> tensor<?x?x?xf32>
          %79 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%64, %65], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%64, %65} -> tensor<?x?xf32>
          %80 = iree_tensor_ext.dispatch.tensor.load %74, offsets = [0, 0], sizes = [%64, %65], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%64, %65} -> tensor<?x?xf32>
          %81 = tensor.empty(%66) : tensor<?xf32>
          %82 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%81 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %83 = linalg.index 0 : index
            %84 = arith.remsi %83, %65 : index
            %85 = arith.divsi %83, %65 : index
            %86 = arith.divui %84, %c128 : index
            %extracted = tensor.extract %77[%85, %76] : tensor<?x?xf32>
            %extracted_0 = tensor.extract %78[%c0, %86, %76] : tensor<?x?x?xf32>
            %extracted_1 = tensor.extract %79[%85, %84] : tensor<?x?xf32>
            %extracted_2 = tensor.extract %80[%85, %84] : tensor<?x?xf32>
            %87 = arith.mulf %extracted_1, %extracted : f32
            %88 = arith.mulf %87, %extracted_0 : f32
            %89 = arith.addf %extracted_2, %88 : f32
            linalg.yield %89 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %82, %75, offsets = [0], sizes = [%66], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%66}
          return
        }
        iree_codegen.dispatch_config @linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @linear_normal_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: f32, %arg4: !hal.fence, %arg5: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @linear_normal_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi8>, %input2: tensor<?x?x?xf32>, %input3: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i8) encoding(%dense_row_major)
    %9 = arith.muli %6, %7 : index
    %10 = arith.muli %9, %8 : index
    %11 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi8>{%6, %7, %8} in !stream.resource<external>{%10}
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%12, %13, %14]) type(%element_type_f32) encoding(%dense_row_major)
    %15 = arith.muli %12, %c4 : index
    %16 = arith.muli %15, %13 : index
    %17 = arith.muli %16, %14 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%12, %13, %14} in !stream.resource<external>{%17}
    %19 = arith.divui %1, %c128 : index
    %20 = arith.muli %0, %1 overflow<nsw> : index
    %21 = arith.muli %0, %19 overflow<nsw> : index
    %22 = arith.muli %21, %c4 : index
    %23 = arith.muli %2, %7 : index
    %24 = util.align %23, %c64 : index
    %25 = arith.addi %24, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%25} => !stream.timepoint
    %26 = stream.resource.subview %result[%c0] : !stream.resource<external>{%25} -> !stream.resource<external>{%c4}
    %27 = util.align %22, %c64 : index
    %28 = util.align %20, %c64 : index
    %29 = arith.addi %27, %28 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%29} => !stream.timepoint
    %30 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %31 = arith.index_castui %20 : index to i64
    %32 = arith.index_castui %20 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %21 : index to i64
    %36 = arith.index_castui %21 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.bitcast %arg3 : f32 to i32
    %40 = arith.index_castui %27 : index to i64
    %41 = arith.index_castui %27 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %0 : index to i64
    %45 = arith.index_castui %0 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %1 : index to i64
    %49 = arith.index_castui %1 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %19 : index to i64
    %53 = arith.index_castui %19 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%30) => with(%4 as %arg6: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg7: !stream.resource<constant>{%c512}, %result as %arg8: !stream.resource<external>{%25}, %result_0 as %arg9: !stream.resource<transient>{%29}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%20](%32, %34 : i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg8[%c0 for %25] : !stream.resource<external>{%25}
        }
        stream.cmd.dispatch @linear_normal_f32_dispatch_1::@vulkan_spirv_fb::@linear_normal_f32_dispatch_1_reduction_DxD_f32[%21, %c128](%36, %38, %39 : i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_2::@vulkan_spirv_fb::@linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8[%20, %0, %1, %19](%41, %43, %32, %34, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg9[%c0 for %29] : !stream.resource<transient>{%29},
          ro %arg7[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29}
        }
        stream.cmd.fill %c0_i8, %arg8[%c64 for %23] : i8 -> !stream.resource<external>{%25}
      }
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %c64, %23, %56 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%57: index, %58: !stream.resource<external>, %59: index, %60: index, %61: index, %62: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %63 = arith.cmpi slt, %57, %19 : index
    cf.cond_br %63, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %64 = arith.muli %57, %c128 : index
    %65 = arith.muli %0, %c128 overflow<nsw> : index
    %66 = arith.muli %0, %c512 : index
    %67 = arith.muli %7, %c128 overflow<nsw> : index
    %68 = arith.muli %7, %c512 : index
    %69 = arith.addi %66, %68 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%56) => !stream.resource<transient>{%69} => !stream.timepoint
    %70 = arith.index_castui %65 : index to i64
    %71 = arith.index_castui %65 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = arith.index_castui %64 : index to i64
    %75 = arith.index_castui %64 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = arith.index_castui %66 : index to i64
    %79 = arith.index_castui %66 : index to i32
    %80 = arith.shrui %78, %c32_i64 : i64
    %81 = arith.trunci %80 : i64 to i32
    %82 = arith.index_castui %67 : index to i64
    %83 = arith.index_castui %67 : index to i32
    %84 = arith.shrui %82, %c32_i64 : i64
    %85 = arith.trunci %84 : i64 to i32
    %86 = arith.index_castui %6 : index to i64
    %87 = arith.index_castui %6 : index to i32
    %88 = arith.shrui %86, %c32_i64 : i64
    %89 = arith.trunci %88 : i64 to i32
    %90 = arith.index_castui %7 : index to i64
    %91 = arith.index_castui %7 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %8 : index to i64
    %95 = arith.index_castui %8 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%result_0 as %arg6: !stream.resource<transient>{%29}, %11 as %arg7: !stream.resource<external>{%10}, %result_2 as %arg8: !stream.resource<transient>{%69}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_3::@vulkan_spirv_fb::@linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32[%65, %64, %0, %1](%41, %43, %71, %73, %75, %77, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %69] : !stream.resource<transient>{%69}
      }
      stream.cmd.dispatch @linear_normal_f32_dispatch_4::@vulkan_spirv_fb::@linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32[%67, %64, %6, %7, %8](%79, %81, %83, %85, %75, %77, %87, %89, %91, %93, %95, %97 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %10] : !stream.resource<external>{%10},
        wo %arg8[%c0 for %69] : !stream.resource<transient>{%69}
      }
    } => !stream.timepoint
    %99 = stream.timepoint.await %98 => %result_2 : !stream.resource<transient>{%69}
    %100 = stream.resource.subview %99[%c0] : !stream.resource<transient>{%69} -> !stream.resource<transient>{%66}
    %101 = stream.resource.subview %99[%66] : !stream.resource<transient>{%69} -> !stream.resource<transient>{%68}
    %102 = util.optimization_barrier %100 : !stream.resource<transient>
    %103 = util.optimization_barrier %101 : !stream.resource<transient>
    %104 = arith.muli %0, %7 overflow<nsw> : index
    %105 = arith.muli %104, %c4 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%62) => !stream.resource<external>{%105} => !stream.timepoint
    %106 = arith.addi %24, %24 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%62) => !stream.resource<transient>{%106} => !stream.timepoint
    %107 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %108 = arith.index_castui %24 : index to i64
    %109 = arith.index_castui %24 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %104 : index to i64
    %113 = arith.index_castui %104 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %57 : index to i64
    %117 = arith.index_castui %57 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = arith.index_castui %12 : index to i64
    %121 = arith.index_castui %12 : index to i32
    %122 = arith.shrui %120, %c32_i64 : i64
    %123 = arith.trunci %122 : i64 to i32
    %124 = arith.index_castui %13 : index to i64
    %125 = arith.index_castui %13 : index to i32
    %126 = arith.shrui %124, %c32_i64 : i64
    %127 = arith.trunci %126 : i64 to i32
    %128 = arith.index_castui %14 : index to i64
    %129 = arith.index_castui %14 : index to i32
    %130 = arith.shrui %128, %c32_i64 : i64
    %131 = arith.trunci %130 : i64 to i32
    %132 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%107) => with(%102 as %arg6: !stream.resource<transient>{%66}, %103 as %arg7: !stream.resource<transient>{%68}, %58 as %arg8: !stream.resource<external>{%59}, %result_0 as %arg9: !stream.resource<transient>{%29}, %18 as %arg10: !stream.resource<external>{%17}, %result_4 as %arg11: !stream.resource<external>{%105}, %result_6 as %arg12: !stream.resource<transient>{%106}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_5::@vulkan_spirv_fb::@linear_normal_f32_dispatch_5_matmul_DxDxD_f32[%c128, %0, %7](%45, %47, %91, %93 : i32, i32, i32, i32) {
        ro %arg6[%c0 for %66] : !stream.resource<transient>{%66},
        ro %arg7[%c0 for %68] : !stream.resource<transient>{%68},
        wo %arg12[%c0 for %106] : !stream.resource<transient>{%106}
      }
      stream.cmd.copy %arg8[%60], %arg12[%24], %23 : !stream.resource<external>{%59} -> !stream.resource<transient>{%106}
      stream.cmd.dispatch @linear_normal_f32_dispatch_6::@vulkan_spirv_fb::@linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32[%104, %57, %0, %19, %12, %13, %14, %7](%109, %111, %113, %115, %117, %119, %45, %47, %53, %55, %121, %123, %125, %127, %129, %131, %91, %93 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %29] : !stream.resource<transient>{%29},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg12[%c0 for %106] : !stream.resource<transient>{%106},
        wo %arg11[%c0 for %105] : !stream.resource<external>{%105}
      }
    } => !stream.timepoint
    %133 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%132) => %result_6 : !stream.resource<transient>{%106} => !stream.timepoint
    %134 = arith.addi %57, %c1 : index
    cf.br ^bb1(%134, %result_4, %105, %c0, %105, %133 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %135 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%62) => %result_0 : !stream.resource<transient>{%29} => !stream.timepoint
    %136 = stream.resource.subview %58[%60] : !stream.resource<external>{%59} -> !stream.resource<external>{%61}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %135 => (%arg5 : !hal.fence)
    %137 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %136 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%23} -> !hal.buffer_view
    %138 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %26 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %137, %138 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @linear_power_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_power_f32_dispatch_1_reduction_DxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_power_f32_dispatch_1_reduction_DxD_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8388607_i32 = arith.constant 8388607 : i32
          %c23_i32 = arith.constant 23 : i32
          %cst = arith.constant 0.00223214296 : f32
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = arith.extui %1 : i32 to i64
          %4 = arith.shli %3, %c32_i64 : i64
          %5 = arith.extui %0 : i32 to i64
          %6 = arith.ori %5, %4 : i64
          %7 = arith.index_castui %6 : i64 to index
          %8 = arith.bitcast %2 : i32 to f32
          %9 = util.assume.int %7<umin = 0, umax = 9223372036854775807> : index
          %10 = iree_tensor_ext.dispatch.workload.ordinal %9, 0 : index
          %11 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128}
          %12 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          %13 = iree_tensor_ext.dispatch.tensor.load %11, offsets = [0, 0], sizes = [%10, 128], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128} -> tensor<?x128xf32>
          %14 = tensor.empty(%10) : tensor<?xf32>
          %15 = linalg.fill ins(%8 : f32) outs(%14 : tensor<?xf32>) -> tensor<?xf32>
          %16 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0)>], iterator_types = ["parallel", "reduction"]} ins(%13 : tensor<?x128xf32>) outs(%15 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: f32):
            %18 = math.absf %in : f32
            %19 = arith.maximumf %18, %out : f32
            linalg.yield %19 : f32
          } -> tensor<?xf32>
          %17 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%16 : tensor<?xf32>) outs(%14 : tensor<?xf32>) {
          ^bb0(%in: f32, %out: f32):
            %18 = arith.mulf %in, %cst : f32
            %19 = arith.bitcast %18 : f32 to i32
            %20 = arith.shrui %19, %c23_i32 : i32
            %21 = arith.andi %19, %c8388607_i32 : i32
            %22 = arith.cmpi ne, %21, %c0_i32 : i32
            %23 = arith.extui %22 : i1 to i32
            %24 = arith.addi %20, %23 : i32
            %25 = arith.shli %24, %c23_i32 : i32
            %26 = arith.bitcast %25 : i32 to f32
            linalg.yield %26 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %17, %12, offsets = [0], sizes = [%10], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          return
        }
        iree_codegen.dispatch_config @linear_power_f32_dispatch_1_reduction_DxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @linear_power_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: f32, %arg4: !hal.fence, %arg5: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @linear_power_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi8>, %input2: tensor<?x?x?xf32>, %input3: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i8) encoding(%dense_row_major)
    %9 = arith.muli %6, %7 : index
    %10 = arith.muli %9, %8 : index
    %11 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi8>{%6, %7, %8} in !stream.resource<external>{%10}
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%12, %13, %14]) type(%element_type_f32) encoding(%dense_row_major)
    %15 = arith.muli %12, %c4 : index
    %16 = arith.muli %15, %13 : index
    %17 = arith.muli %16, %14 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%12, %13, %14} in !stream.resource<external>{%17}
    %19 = arith.divui %1, %c128 : index
    %20 = arith.muli %0, %1 overflow<nsw> : index
    %21 = arith.muli %0, %19 overflow<nsw> : index
    %22 = arith.muli %21, %c4 : index
    %23 = arith.muli %2, %7 : index
    %24 = util.align %23, %c64 : index
    %25 = arith.addi %24, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%25} => !stream.timepoint
    %26 = stream.resource.subview %result[%c0] : !stream.resource<external>{%25} -> !stream.resource<external>{%c4}
    %27 = util.align %22, %c64 : index
    %28 = util.align %20, %c64 : index
    %29 = arith.addi %27, %28 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%29} => !stream.timepoint
    %30 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %31 = arith.index_castui %20 : index to i64
    %32 = arith.index_castui %20 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %21 : index to i64
    %36 = arith.index_castui %21 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.bitcast %arg3 : f32 to i32
    %40 = arith.index_castui %27 : index to i64
    %41 = arith.index_castui %27 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %0 : index to i64
    %45 = arith.index_castui %0 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %1 : index to i64
    %49 = arith.index_castui %1 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %19 : index to i64
    %53 = arith.index_castui %19 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%30) => with(%4 as %arg6: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg7: !stream.resource<constant>{%c512}, %result as %arg8: !stream.resource<external>{%25}, %result_0 as %arg9: !stream.resource<transient>{%29}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%20](%32, %34 : i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg8[%c0 for %25] : !stream.resource<external>{%25}
        }
        stream.cmd.dispatch @linear_power_f32_dispatch_1::@vulkan_spirv_fb::@linear_power_f32_dispatch_1_reduction_DxD_f32[%21, %c128](%36, %38, %39 : i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_2::@vulkan_spirv_fb::@linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8[%20, %0, %1, %19](%41, %43, %32, %34, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg9[%c0 for %29] : !stream.resource<transient>{%29},
          ro %arg7[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29}
        }
        stream.cmd.fill %c0_i8, %arg8[%c64 for %23] : i8 -> !stream.resource<external>{%25}
      }
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %c64, %23, %56 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%57: index, %58: !stream.resource<external>, %59: index, %60: index, %61: index, %62: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %63 = arith.cmpi slt, %57, %19 : index
    cf.cond_br %63, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %64 = arith.muli %57, %c128 : index
    %65 = arith.muli %0, %c128 overflow<nsw> : index
    %66 = arith.muli %0, %c512 : index
    %67 = arith.muli %7, %c128 overflow<nsw> : index
    %68 = arith.muli %7, %c512 : index
    %69 = arith.addi %66, %68 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%56) => !stream.resource<transient>{%69} => !stream.timepoint
    %70 = arith.index_castui %65 : index to i64
    %71 = arith.index_castui %65 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = arith.index_castui %64 : index to i64
    %75 = arith.index_castui %64 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = arith.index_castui %66 : index to i64
    %79 = arith.index_castui %66 : index to i32
    %80 = arith.shrui %78, %c32_i64 : i64
    %81 = arith.trunci %80 : i64 to i32
    %82 = arith.index_castui %67 : index to i64
    %83 = arith.index_castui %67 : index to i32
    %84 = arith.shrui %82, %c32_i64 : i64
    %85 = arith.trunci %84 : i64 to i32
    %86 = arith.index_castui %6 : index to i64
    %87 = arith.index_castui %6 : index to i32
    %88 = arith.shrui %86, %c32_i64 : i64
    %89 = arith.trunci %88 : i64 to i32
    %90 = arith.index_castui %7 : index to i64
    %91 = arith.index_castui %7 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %8 : index to i64
    %95 = arith.index_castui %8 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%result_0 as %arg6: !stream.resource<transient>{%29}, %11 as %arg7: !stream.resource<external>{%10}, %result_2 as %arg8: !stream.resource<transient>{%69}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_3::@vulkan_spirv_fb::@linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32[%65, %64, %0, %1](%41, %43, %71, %73, %75, %77, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %69] : !stream.resource<transient>{%69}
      }
      stream.cmd.dispatch @linear_normal_f32_dispatch_4::@vulkan_spirv_fb::@linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32[%67, %64, %6, %7, %8](%79, %81, %83, %85, %75, %77, %87, %89, %91, %93, %95, %97 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %10] : !stream.resource<external>{%10},
        wo %arg8[%c0 for %69] : !stream.resource<transient>{%69}
      }
    } => !stream.timepoint
    %99 = stream.timepoint.await %98 => %result_2 : !stream.resource<transient>{%69}
    %100 = stream.resource.subview %99[%c0] : !stream.resource<transient>{%69} -> !stream.resource<transient>{%66}
    %101 = stream.resource.subview %99[%66] : !stream.resource<transient>{%69} -> !stream.resource<transient>{%68}
    %102 = util.optimization_barrier %100 : !stream.resource<transient>
    %103 = util.optimization_barrier %101 : !stream.resource<transient>
    %104 = arith.muli %0, %7 overflow<nsw> : index
    %105 = arith.muli %104, %c4 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%62) => !stream.resource<external>{%105} => !stream.timepoint
    %106 = arith.addi %24, %24 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%62) => !stream.resource<transient>{%106} => !stream.timepoint
    %107 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %108 = arith.index_castui %24 : index to i64
    %109 = arith.index_castui %24 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %104 : index to i64
    %113 = arith.index_castui %104 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %57 : index to i64
    %117 = arith.index_castui %57 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = arith.index_castui %12 : index to i64
    %121 = arith.index_castui %12 : index to i32
    %122 = arith.shrui %120, %c32_i64 : i64
    %123 = arith.trunci %122 : i64 to i32
    %124 = arith.index_castui %13 : index to i64
    %125 = arith.index_castui %13 : index to i32
    %126 = arith.shrui %124, %c32_i64 : i64
    %127 = arith.trunci %126 : i64 to i32
    %128 = arith.index_castui %14 : index to i64
    %129 = arith.index_castui %14 : index to i32
    %130 = arith.shrui %128, %c32_i64 : i64
    %131 = arith.trunci %130 : i64 to i32
    %132 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%107) => with(%102 as %arg6: !stream.resource<transient>{%66}, %103 as %arg7: !stream.resource<transient>{%68}, %58 as %arg8: !stream.resource<external>{%59}, %result_0 as %arg9: !stream.resource<transient>{%29}, %18 as %arg10: !stream.resource<external>{%17}, %result_4 as %arg11: !stream.resource<external>{%105}, %result_6 as %arg12: !stream.resource<transient>{%106}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_5::@vulkan_spirv_fb::@linear_normal_f32_dispatch_5_matmul_DxDxD_f32[%c128, %0, %7](%45, %47, %91, %93 : i32, i32, i32, i32) {
        ro %arg6[%c0 for %66] : !stream.resource<transient>{%66},
        ro %arg7[%c0 for %68] : !stream.resource<transient>{%68},
        wo %arg12[%c0 for %106] : !stream.resource<transient>{%106}
      }
      stream.cmd.copy %arg8[%60], %arg12[%24], %23 : !stream.resource<external>{%59} -> !stream.resource<transient>{%106}
      stream.cmd.dispatch @linear_normal_f32_dispatch_6::@vulkan_spirv_fb::@linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32[%104, %57, %0, %19, %12, %13, %14, %7](%109, %111, %113, %115, %117, %119, %45, %47, %53, %55, %121, %123, %125, %127, %129, %131, %91, %93 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %29] : !stream.resource<transient>{%29},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg12[%c0 for %106] : !stream.resource<transient>{%106},
        wo %arg11[%c0 for %105] : !stream.resource<external>{%105}
      }
    } => !stream.timepoint
    %133 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%132) => %result_6 : !stream.resource<transient>{%106} => !stream.timepoint
    %134 = arith.addi %57, %c1 : index
    cf.br ^bb1(%134, %result_4, %105, %c0, %105, %133 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %135 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%62) => %result_0 : !stream.resource<transient>{%29} => !stream.timepoint
    %136 = stream.resource.subview %58[%60] : !stream.resource<external>{%59} -> !stream.resource<external>{%61}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %135 => (%arg5 : !hal.fence)
    %137 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %136 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%23} -> !hal.buffer_view
    %138 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %26 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %137, %138 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @grouped8_f32_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @grouped8_f32_dispatch_3_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @grouped8_f32_dispatch_3_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %cst = arith.constant 0x7FC00000 : f32
          %c1 = arith.constant 1 : index
          %c127_i32 = arith.constant 127 : i32
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 {stream.alignment = 64 : index} : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:3 = util.assume.int 
              %18<udiv = 64>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 4 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 5 : index
          %53 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%49#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%51, %52}
          %54 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          %55 = iree_tensor_ext.dispatch.workload.ordinal %28, 1 : index
          %56 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %38, 3 : index
          %58 = iree_tensor_ext.dispatch.tensor.load %53, offsets = [0, 0], sizes = [%51, %52], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%51, %52} -> tensor<?x?xi8>
          %59 = tensor.empty(%50) : tensor<?xf32>
          %60 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%59 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %61 = linalg.index 0 : index
            %62 = arith.remsi %61, %c128 : index
            %63 = arith.divsi %61, %c128 : index
            %64 = arith.addi %55, %62 : index
            %65 = arith.divui %63, %56 : index
            %66 = arith.remui %63, %56 : index
            %67 = arith.cmpi eq, %57, %c1 : index
            %68 = arith.select %67, %c0, %66 : index
            %69 = arith.muli %65, %57 : index
            %70 = arith.addi %69, %68 : index
            %extracted = tensor.extract %58[%70, %64] : tensor<?x?xi8>
            %71 = arith.extui %extracted : i8 to i32
            %72 = arith.bitcast %extracted : i8 to f8E4M3FN
            %73 = arith.extf %72 : f8E4M3FN to f32
            %74 = arith.andi %71, %c127_i32 : i32
            %75 = arith.cmpi eq, %74, %c127_i32 : i32
            %76 = arith.select %75, %cst, %73 : f32
            linalg.yield %76 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %60, %54, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          return
        }
        iree_codegen.dispatch_config @grouped8_f32_dispatch_3_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @grouped8_f32_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @grouped8_f32_dispatch_4_reduction_DxDxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @grouped8_f32_dispatch_4_reduction_DxDxD_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c127_i32 = arith.constant 127 : i32
          %c255_i32 = arith.constant 255 : i32
          %c8_i32 = arith.constant 8 : i32
          %c4 = arith.constant 4 : index
          %cst = arith.constant 0.000000e+00 : f32
          %cst_0 = arith.constant 0x7FC00000 : f32
          %c0 = arith.constant 0 : index
          %c1 = arith.constant 1 : index
          %c128 = arith.constant 128 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:4 = util.assume.int 
              %19<umin = 0, umax = 9007199254740991>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index, index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %35#0, 1 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 2 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 5 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 6 : index
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%38}
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%36, %39, %37}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%38, %c1, %c128}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x?xf32>>{%38, %39}
          %44 = iree_tensor_ext.dispatch.workload.ordinal %14, 0 : index
          %45 = iree_tensor_ext.dispatch.tensor.load %40, offsets = [0], sizes = [%38], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%38} -> tensor<?xi32>
          %46 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0, 0], sizes = [%36, %39, %37], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%36, %39, %37} -> tensor<?x?x?xi32>
          %47 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0, 0], sizes = [%38, 1, 128], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%38, %c1, %c128} -> tensor<?x1x128xf32>
          %48 = tensor.empty(%38, %39) : tensor<?x?xf32>
          %49 = linalg.fill ins(%cst : f32) outs(%48 : tensor<?x?xf32>) -> tensor<?x?xf32>
          %50 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, 0, d2)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iterator_types = ["parallel", "parallel", "reduction"]} ins(%47 : tensor<?x1x128xf32>) outs(%49 : tensor<?x?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[1, 64], [1, 1]]>} {
          ^bb0(%in: f32, %out: f32):
            %51 = linalg.index 0 : index
            %52 = linalg.index 1 : index
            %53 = linalg.index 2 : index
            %54 = arith.addi %44, %53 : index
            %extracted = tensor.extract %45[%51] : tensor<?xi32>
            %55 = arith.index_cast %extracted : i32 to index
            %56 = arith.divui %54, %c4 : index
            %57 = arith.remui %54, %c4 : index
            %extracted_1 = tensor.extract %46[%55, %52, %56] : tensor<?x?x?xi32>
            %58 = arith.index_castui %57 : index to i32
            %59 = arith.muli %58, %c8_i32 : i32
            %60 = arith.shrui %extracted_1, %59 : i32
            %61 = arith.andi %60, %c255_i32 : i32
            %62 = arith.trunci %61 : i32 to i8
            %63 = arith.bitcast %62 : i8 to f8E4M3FN
            %64 = arith.extf %63 : f8E4M3FN to f32
            %65 = arith.andi %60, %c127_i32 : i32
            %66 = arith.cmpi eq, %65, %c127_i32 : i32
            %67 = arith.select %66, %cst_0, %64 : f32
            %68 = arith.mulf %in, %67 : f32
            %69 = arith.addf %out, %68 : f32
            linalg.yield %69 : f32
          } -> tensor<?x?xf32>
          iree_tensor_ext.dispatch.tensor.store %50, %43, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : tensor<?x?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x?xf32>>{%38, %39}
          return
        }
        iree_codegen.dispatch_config @grouped8_f32_dispatch_4_reduction_DxDxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @grouped8_f32_dispatch_5 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @grouped8_f32_dispatch_5_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @grouped8_f32_dispatch_5_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %c1 = arith.constant 1 : index
          %0 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = arith.extui %1 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %0 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 {stream.alignment = 64 : index} : i64 to index
          %29 = arith.extui %3 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %2 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %5 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %4 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %7 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %6 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %9 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %8 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49 = arith.extui %11 : i32 to i64
          %50 = arith.shli %49, %c32_i64 : i64
          %51 = arith.extui %10 : i32 to i64
          %52 = arith.ori %51, %50 : i64
          %53 = arith.index_castui %52 : i64 to index
          %54 = arith.extui %13 : i32 to i64
          %55 = arith.shli %54, %c32_i64 : i64
          %56 = arith.extui %12 : i32 to i64
          %57 = arith.ori %56, %55 : i64
          %58 = arith.index_castui %57 : i64 to index
          %59 = arith.extui %15 : i32 to i64
          %60 = arith.shli %59, %c32_i64 : i64
          %61 = arith.extui %14 : i32 to i64
          %62 = arith.ori %61, %60 : i64
          %63 = arith.index_castui %62 : i64 to index
          %64 = arith.extui %17 : i32 to i64
          %65 = arith.shli %64, %c32_i64 : i64
          %66 = arith.extui %16 : i32 to i64
          %67 = arith.ori %66, %65 : i64
          %68 = arith.index_castui %67 : i64 to index
          %69 = arith.extui %19 : i32 to i64
          %70 = arith.shli %69, %c32_i64 : i64
          %71 = arith.extui %18 : i32 to i64
          %72 = arith.ori %71, %70 : i64
          %73 = arith.index_castui %72 : i64 to index
          %74 = arith.extui %21 : i32 to i64
          %75 = arith.shli %74, %c32_i64 : i64
          %76 = arith.extui %20 : i32 to i64
          %77 = arith.ori %76, %75 : i64
          %78 = arith.index_castui %77 : i64 to index
          %79 = arith.extui %23 : i32 to i64
          %80 = arith.shli %79, %c32_i64 : i64
          %81 = arith.extui %22 : i32 to i64
          %82 = arith.ori %81, %80 : i64
          %83 = arith.index_castui %82 : i64 to index
          %84:8 = util.assume.int 
              %28<udiv = 64>, 
              %53<umin = 0, umax = 9007199254740991>, 
              %58<umin = 0, umax = 70368744177663>, 
              %63<umin = 0, umax = 9007199254740991>, 
              %68<umin = 0, umax = 9007199254740991>, 
              %73<umin = 0, umax = 9007199254740991>, 
              %78<umin = 0, umax = 9007199254740991>, 
              %83<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index
          %85 = iree_tensor_ext.dispatch.workload.ordinal %84#6, 9 : index
          %86 = iree_tensor_ext.dispatch.workload.ordinal %84#7, 10 : index
          %87 = iree_tensor_ext.dispatch.workload.ordinal %33, 0 : index
          %88 = iree_tensor_ext.dispatch.workload.ordinal %84#1, 4 : index
          %89 = iree_tensor_ext.dispatch.workload.ordinal %84#2, 5 : index
          %90 = iree_tensor_ext.dispatch.workload.ordinal %84#3, 6 : index
          %91 = iree_tensor_ext.dispatch.workload.ordinal %84#4, 7 : index
          %92 = iree_tensor_ext.dispatch.workload.ordinal %84#5, 8 : index
          %93 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%85}
          %94 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%88, %89}
          %95 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%90, %91, %92}
          %96 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86}
          %97 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%84#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86}
          %98 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%87}
          %99 = iree_tensor_ext.dispatch.workload.ordinal %38, 1 : index
          %100 = iree_tensor_ext.dispatch.workload.ordinal %43, 2 : index
          %101 = iree_tensor_ext.dispatch.workload.ordinal %48, 3 : index
          %102 = iree_tensor_ext.dispatch.tensor.load %93, offsets = [0], sizes = [%85], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%85} -> tensor<?xi32>
          %103 = iree_tensor_ext.dispatch.tensor.load %94, offsets = [0, 0], sizes = [%88, %89], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%88, %89} -> tensor<?x?xf32>
          %104 = iree_tensor_ext.dispatch.tensor.load %95, offsets = [0, 0, 0], sizes = [%90, %91, %92], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%90, %91, %92} -> tensor<?x?x?xf32>
          %105 = iree_tensor_ext.dispatch.tensor.load %96, offsets = [0, 0], sizes = [%85, %86], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86} -> tensor<?x?xf32>
          %106 = iree_tensor_ext.dispatch.tensor.load %97, offsets = [0, 0], sizes = [%85, %86], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86} -> tensor<?x?xf32>
          %107 = tensor.empty(%87) : tensor<?xf32>
          %108 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%107 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %109 = linalg.index 0 : index
            %110 = arith.remsi %109, %86 : index
            %111 = arith.divsi %109, %86 : index
            %112 = arith.divui %111, %99 : index
            %113 = arith.remui %111, %99 : index
            %114 = arith.cmpi eq, %100, %c1 : index
            %115 = arith.select %114, %c0, %113 : index
            %116 = arith.muli %112, %100 : index
            %117 = arith.addi %116, %115 : index
            %extracted = tensor.extract %102[%111] : tensor<?xi32>
            %118 = arith.index_cast %extracted : i32 to index
            %119 = arith.divui %110, %c128 : index
            %extracted_0 = tensor.extract %103[%117, %101] : tensor<?x?xf32>
            %extracted_1 = tensor.extract %104[%118, %119, %101] : tensor<?x?x?xf32>
            %extracted_2 = tensor.extract %105[%111, %110] : tensor<?x?xf32>
            %extracted_3 = tensor.extract %106[%111, %110] : tensor<?x?xf32>
            %120 = arith.mulf %extracted_2, %extracted_0 : f32
            %121 = arith.mulf %120, %extracted_1 : f32
            %122 = arith.addf %extracted_3, %121 : f32
            linalg.yield %122 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %108, %98, offsets = [0], sizes = [%87], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%87}
          return
        }
        iree_codegen.dispatch_config @grouped8_f32_dispatch_5_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @grouped8_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: f32, %arg7: !hal.fence, %arg8: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @grouped8_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf32>, %input3: tensor<?xi32>, %input4: i32, %input5: i32, %input6: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f32) encoding(%dense_row_major)
    %16 = arith.muli %13, %c4 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20]) type(%element_type_i32) encoding(%dense_row_major)
    %21 = arith.muli %20, %c4 : index
    %22 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%20} in !stream.resource<external>{%21}
    %23 = arith.divui %1, %c128 : index
    %24 = arith.muli %0, %1 overflow<nsw> : index
    %25 = arith.muli %0, %23 overflow<nsw> : index
    %26 = arith.muli %25, %c4 : index
    %27 = arith.muli %21, %7 : index
    %28 = util.align %27, %c64 : index
    %29 = arith.addi %28, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%29} => !stream.timepoint
    %30 = stream.resource.subview %result[%c0] : !stream.resource<external>{%29} -> !stream.resource<external>{%c4}
    %31 = util.align %26, %c64 : index
    %32 = util.align %24, %c64 : index
    %33 = arith.addi %31, %32 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%33} => !stream.timepoint
    %34 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %35 = arith.index_castui %24 : index to i64
    %36 = arith.index_castui %24 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %25 : index to i64
    %40 = arith.index_castui %25 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = arith.bitcast %arg6 : f32 to i32
    %44 = arith.index_castui %31 : index to i64
    %45 = arith.index_castui %31 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %0 : index to i64
    %49 = arith.index_castui %0 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %1 : index to i64
    %53 = arith.index_castui %1 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %23 : index to i64
    %57 = arith.index_castui %23 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%34) => with(%4 as %arg9: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg10: !stream.resource<constant>{%c512}, %result as %arg11: !stream.resource<external>{%29}, %result_0 as %arg12: !stream.resource<transient>{%33}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%24](%36, %38 : i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg11[%c0 for %29] : !stream.resource<external>{%29}
        }
        stream.cmd.dispatch @linear_normal_f32_dispatch_1::@vulkan_spirv_fb::@linear_normal_f32_dispatch_1_reduction_DxD_f32[%25, %c128](%40, %42, %43 : i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg12[%c0 for %33] : !stream.resource<transient>{%33}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_2::@vulkan_spirv_fb::@linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8[%24, %0, %1, %23](%45, %47, %36, %38, %49, %51, %53, %55, %57, %59 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg12[%c0 for %33] : !stream.resource<transient>{%33},
          ro %arg10[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg12[%c0 for %33] : !stream.resource<transient>{%33}
        }
        stream.cmd.fill %c0_i8, %arg11[%c64 for %27] : i8 -> !stream.resource<external>{%29}
      }
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %29, %c64, %27, %60 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%61: index, %62: !stream.resource<external>, %63: index, %64: index, %65: index, %66: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %67 = arith.cmpi slt, %61, %23 : index
    cf.cond_br %67, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %68 = arith.muli %61, %c128 : index
    %69 = arith.muli %20, %c128 overflow<nsw> : index
    %70 = arith.index_cast %arg5 : i32 to index
    %71 = arith.index_cast %arg4 : i32 to index
    %72 = arith.muli %20, %c512 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%60) => !stream.resource<transient>{%72} => !stream.timepoint
    %73 = arith.index_castui %69 : index to i64
    %74 = arith.index_castui %69 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %68 : index to i64
    %78 = arith.index_castui %68 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %71 : index to i64
    %82 = arith.index_castui %71 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = arith.index_castui %70 : index to i64
    %86 = arith.index_castui %70 : index to i32
    %87 = arith.shrui %85, %c32_i64 : i64
    %88 = arith.trunci %87 : i64 to i32
    %89 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%result_0 as %arg9: !stream.resource<transient>{%33}, %result_2 as %arg10: !stream.resource<transient>{%72}) {
      stream.cmd.dispatch @grouped8_f32_dispatch_3::@vulkan_spirv_fb::@grouped8_f32_dispatch_3_elementwise_broadcast_D_f32[%69, %68, %71, %70, %0, %1](%45, %47, %74, %76, %78, %80, %82, %84, %86, %88, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %33] : !stream.resource<transient>{%33},
        wo %arg10[%c0 for %72] : !stream.resource<transient>{%72}
      }
    } => !stream.timepoint
    %90 = stream.timepoint.await %89 => %result_2 : !stream.resource<transient>{%72}
    %91 = util.optimization_barrier %90 : !stream.resource<transient>
    %92 = arith.muli %20, %7 overflow<nsw> : index
    %93 = arith.muli %92, %c4 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%66) => !stream.resource<external>{%93} => !stream.timepoint
    %94 = arith.addi %28, %28 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%66) => !stream.resource<transient>{%94} => !stream.timepoint
    %95 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %96 = arith.index_castui %6 : index to i64
    %97 = arith.index_castui %6 : index to i32
    %98 = arith.shrui %96, %c32_i64 : i64
    %99 = arith.trunci %98 : i64 to i32
    %100 = arith.index_castui %8 : index to i64
    %101 = arith.index_castui %8 : index to i32
    %102 = arith.shrui %100, %c32_i64 : i64
    %103 = arith.trunci %102 : i64 to i32
    %104 = arith.index_castui %20 : index to i64
    %105 = arith.index_castui %20 : index to i32
    %106 = arith.shrui %104, %c32_i64 : i64
    %107 = arith.trunci %106 : i64 to i32
    %108 = arith.index_castui %7 : index to i64
    %109 = arith.index_castui %7 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %28 : index to i64
    %113 = arith.index_castui %28 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %92 : index to i64
    %117 = arith.index_castui %92 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = arith.index_castui %61 : index to i64
    %121 = arith.index_castui %61 : index to i32
    %122 = arith.shrui %120, %c32_i64 : i64
    %123 = arith.trunci %122 : i64 to i32
    %124 = arith.index_castui %13 : index to i64
    %125 = arith.index_castui %13 : index to i32
    %126 = arith.shrui %124, %c32_i64 : i64
    %127 = arith.trunci %126 : i64 to i32
    %128 = arith.index_castui %14 : index to i64
    %129 = arith.index_castui %14 : index to i32
    %130 = arith.shrui %128, %c32_i64 : i64
    %131 = arith.trunci %130 : i64 to i32
    %132 = arith.index_castui %15 : index to i64
    %133 = arith.index_castui %15 : index to i32
    %134 = arith.shrui %132, %c32_i64 : i64
    %135 = arith.trunci %134 : i64 to i32
    %136 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%95) => with(%22 as %arg9: !stream.resource<external>{%21}, %12 as %arg10: !stream.resource<external>{%11}, %91 as %arg11: !stream.resource<transient>{%72}, %62 as %arg12: !stream.resource<external>{%63}, %result_0 as %arg13: !stream.resource<transient>{%33}, %19 as %arg14: !stream.resource<external>{%18}, %result_4 as %arg15: !stream.resource<external>{%93}, %result_6 as %arg16: !stream.resource<transient>{%94}) {
      stream.cmd.dispatch @grouped8_f32_dispatch_4::@vulkan_spirv_fb::@grouped8_f32_dispatch_4_reduction_DxDxD_f32[%68, %6, %8, %c1, %c128, %20, %7](%78, %80, %97, %99, %101, %103, %105, %107, %109, %111 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg10[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg11[%c0 for %72] : !stream.resource<transient>{%72},
        wo %arg16[%c0 for %94] : !stream.resource<transient>{%94}
      }
      stream.cmd.copy %arg12[%64], %arg16[%28], %27 : !stream.resource<external>{%63} -> !stream.resource<transient>{%94}
      stream.cmd.dispatch @grouped8_f32_dispatch_5::@vulkan_spirv_fb::@grouped8_f32_dispatch_5_elementwise_broadcast_D_f32[%92, %71, %70, %61, %0, %23, %13, %14, %15, %20, %7](%113, %115, %117, %119, %82, %84, %86, %88, %121, %123, %49, %51, %57, %59, %125, %127, %129, %131, %133, %135, %105, %107, %109, %111 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg13[%c0 for %33] : !stream.resource<transient>{%33},
        ro %arg14[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg16[%c0 for %94] : !stream.resource<transient>{%94},
        wo %arg15[%c0 for %93] : !stream.resource<external>{%93}
      }
    } => !stream.timepoint
    %137 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%136) => %result_6 : !stream.resource<transient>{%94} => !stream.timepoint
    %138 = arith.addi %61, %c1 : index
    cf.br ^bb1(%138, %result_4, %93, %c0, %93, %137 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %139 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%66) => %result_0 : !stream.resource<transient>{%33} => !stream.timepoint
    %140 = stream.resource.subview %62[%64] : !stream.resource<external>{%63} -> !stream.resource<external>{%65}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %139 => (%arg8 : !hal.fence)
    %141 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %140 : tensor<?x?xf32>{%20, %7} in !stream.resource<external>{%27} -> !hal.buffer_view
    %142 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %30 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %141, %142 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @grouped4_f32_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @grouped4_f32_dispatch_3_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @grouped4_f32_dispatch_3_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %cst = arith.constant 0x7FC00000 : f32
          %c1 = arith.constant 1 : index
          %c127_i32 = arith.constant 127 : i32
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 {stream.alignment = 64 : index} : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:3 = util.assume.int 
              %18<udiv = 64>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 4 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 5 : index
          %53 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%49#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%51, %52}
          %54 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          %55 = iree_tensor_ext.dispatch.workload.ordinal %28, 1 : index
          %56 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %38, 3 : index
          %58 = iree_tensor_ext.dispatch.tensor.load %53, offsets = [0, 0], sizes = [%51, %52], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%51, %52} -> tensor<?x?xi8>
          %59 = tensor.empty(%50) : tensor<?xf32>
          %60 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%59 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %61 = linalg.index 0 : index
            %62 = arith.remsi %61, %c32 : index
            %63 = arith.divsi %61, %c32 : index
            %64 = arith.addi %55, %62 : index
            %65 = arith.divui %63, %56 : index
            %66 = arith.remui %63, %56 : index
            %67 = arith.cmpi eq, %57, %c1 : index
            %68 = arith.select %67, %c0, %66 : index
            %69 = arith.muli %65, %57 : index
            %70 = arith.addi %69, %68 : index
            %extracted = tensor.extract %58[%70, %64] : tensor<?x?xi8>
            %71 = arith.extui %extracted : i8 to i32
            %72 = arith.bitcast %extracted : i8 to f8E4M3FN
            %73 = arith.extf %72 : f8E4M3FN to f32
            %74 = arith.andi %71, %c127_i32 : i32
            %75 = arith.cmpi eq, %74, %c127_i32 : i32
            %76 = arith.select %75, %cst, %73 : f32
            linalg.yield %76 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %60, %54, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          return
        }
        iree_codegen.dispatch_config @grouped4_f32_dispatch_3_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @grouped4_f32_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @grouped4_f32_dispatch_4_reduction_DxDxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @grouped4_f32_dispatch_4_reduction_DxDxD_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c15_i32 = arith.constant 15 : i32
          %c4_i32 = arith.constant 4 : i32
          %c8 = arith.constant 8 : index
          %cst = arith.constant 0.000000e+00 : f32
          %cst_0 = arith.constant dense<[0.000000e+00, 5.000000e-01, 1.000000e+00, 1.500000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 6.000000e+00, -0.000000e+00, -5.000000e-01, -1.000000e+00, -1.500000e+00, -2.000000e+00, -3.000000e+00, -4.000000e+00, -6.000000e+00]> : tensor<16xf32>
          %c0 = arith.constant 0 : index
          %c1 = arith.constant 1 : index
          %c32 = arith.constant 32 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:4 = util.assume.int 
              %19<umin = 0, umax = 9007199254740991>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index, index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %35#0, 1 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 2 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 5 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 6 : index
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%38}
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%36, %39, %37}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%38, %c1, %c32}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x?xf32>>{%38, %39}
          %44 = iree_tensor_ext.dispatch.workload.ordinal %14, 0 : index
          %45 = iree_tensor_ext.dispatch.tensor.load %40, offsets = [0], sizes = [%38], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%38} -> tensor<?xi32>
          %46 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0, 0], sizes = [%36, %39, %37], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%36, %39, %37} -> tensor<?x?x?xi32>
          %47 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0, 0], sizes = [%38, 1, 32], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%38, %c1, %c32} -> tensor<?x1x32xf32>
          %48 = tensor.empty(%38, %39) : tensor<?x?xf32>
          %49 = linalg.fill ins(%cst : f32) outs(%48 : tensor<?x?xf32>) -> tensor<?x?xf32>
          %50 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, 0, d2)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iterator_types = ["parallel", "parallel", "reduction"]} ins(%47 : tensor<?x1x32xf32>) outs(%49 : tensor<?x?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[1, 64], [1, 1]]>} {
          ^bb0(%in: f32, %out: f32):
            %51 = linalg.index 0 : index
            %52 = linalg.index 1 : index
            %53 = linalg.index 2 : index
            %54 = arith.addi %44, %53 : index
            %extracted = tensor.extract %45[%51] : tensor<?xi32>
            %55 = arith.index_cast %extracted : i32 to index
            %56 = arith.divui %54, %c8 : index
            %57 = arith.remui %54, %c8 : index
            %extracted_1 = tensor.extract %46[%55, %52, %56] : tensor<?x?x?xi32>
            %58 = arith.index_castui %57 : index to i32
            %59 = arith.muli %58, %c4_i32 : i32
            %60 = arith.shrui %extracted_1, %59 : i32
            %61 = arith.andi %60, %c15_i32 : i32
            %62 = arith.index_castui %61 : i32 to index
            %extracted_2 = tensor.extract %cst_0[%62] : tensor<16xf32>
            %63 = arith.mulf %in, %extracted_2 : f32
            %64 = arith.addf %out, %63 : f32
            linalg.yield %64 : f32
          } -> tensor<?x?xf32>
          iree_tensor_ext.dispatch.tensor.store %50, %43, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : tensor<?x?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x?xf32>>{%38, %39}
          return
        }
        iree_codegen.dispatch_config @grouped4_f32_dispatch_4_reduction_DxDxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @grouped4_f32_dispatch_5 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @grouped4_f32_dispatch_5_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @grouped4_f32_dispatch_5_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1 = arith.constant 1 : index
          %0 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = arith.extui %1 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %0 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 {stream.alignment = 64 : index} : i64 to index
          %29 = arith.extui %3 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %2 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %5 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %4 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %7 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %6 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %9 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %8 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49 = arith.extui %11 : i32 to i64
          %50 = arith.shli %49, %c32_i64 : i64
          %51 = arith.extui %10 : i32 to i64
          %52 = arith.ori %51, %50 : i64
          %53 = arith.index_castui %52 : i64 to index
          %54 = arith.extui %13 : i32 to i64
          %55 = arith.shli %54, %c32_i64 : i64
          %56 = arith.extui %12 : i32 to i64
          %57 = arith.ori %56, %55 : i64
          %58 = arith.index_castui %57 : i64 to index
          %59 = arith.extui %15 : i32 to i64
          %60 = arith.shli %59, %c32_i64 : i64
          %61 = arith.extui %14 : i32 to i64
          %62 = arith.ori %61, %60 : i64
          %63 = arith.index_castui %62 : i64 to index
          %64 = arith.extui %17 : i32 to i64
          %65 = arith.shli %64, %c32_i64 : i64
          %66 = arith.extui %16 : i32 to i64
          %67 = arith.ori %66, %65 : i64
          %68 = arith.index_castui %67 : i64 to index
          %69 = arith.extui %19 : i32 to i64
          %70 = arith.shli %69, %c32_i64 : i64
          %71 = arith.extui %18 : i32 to i64
          %72 = arith.ori %71, %70 : i64
          %73 = arith.index_castui %72 : i64 to index
          %74 = arith.extui %21 : i32 to i64
          %75 = arith.shli %74, %c32_i64 : i64
          %76 = arith.extui %20 : i32 to i64
          %77 = arith.ori %76, %75 : i64
          %78 = arith.index_castui %77 : i64 to index
          %79 = arith.extui %23 : i32 to i64
          %80 = arith.shli %79, %c32_i64 : i64
          %81 = arith.extui %22 : i32 to i64
          %82 = arith.ori %81, %80 : i64
          %83 = arith.index_castui %82 : i64 to index
          %84:8 = util.assume.int 
              %28<udiv = 64>, 
              %53<umin = 0, umax = 9007199254740991>, 
              %58<umin = 0, umax = 70368744177663>, 
              %63<umin = 0, umax = 9007199254740991>, 
              %68<umin = 0, umax = 9007199254740991>, 
              %73<umin = 0, umax = 9007199254740991>, 
              %78<umin = 0, umax = 9007199254740991>, 
              %83<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index
          %85 = iree_tensor_ext.dispatch.workload.ordinal %84#6, 9 : index
          %86 = iree_tensor_ext.dispatch.workload.ordinal %84#7, 10 : index
          %87 = iree_tensor_ext.dispatch.workload.ordinal %33, 0 : index
          %88 = iree_tensor_ext.dispatch.workload.ordinal %84#1, 4 : index
          %89 = iree_tensor_ext.dispatch.workload.ordinal %84#2, 5 : index
          %90 = iree_tensor_ext.dispatch.workload.ordinal %84#3, 6 : index
          %91 = iree_tensor_ext.dispatch.workload.ordinal %84#4, 7 : index
          %92 = iree_tensor_ext.dispatch.workload.ordinal %84#5, 8 : index
          %93 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%85}
          %94 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%88, %89}
          %95 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%90, %91, %92}
          %96 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86}
          %97 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%84#0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86}
          %98 = hal.interface.binding.subspan layout(<constants = 24, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%87}
          %99 = iree_tensor_ext.dispatch.workload.ordinal %38, 1 : index
          %100 = iree_tensor_ext.dispatch.workload.ordinal %43, 2 : index
          %101 = iree_tensor_ext.dispatch.workload.ordinal %48, 3 : index
          %102 = iree_tensor_ext.dispatch.tensor.load %93, offsets = [0], sizes = [%85], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%85} -> tensor<?xi32>
          %103 = iree_tensor_ext.dispatch.tensor.load %94, offsets = [0, 0], sizes = [%88, %89], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%88, %89} -> tensor<?x?xf32>
          %104 = iree_tensor_ext.dispatch.tensor.load %95, offsets = [0, 0, 0], sizes = [%90, %91, %92], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%90, %91, %92} -> tensor<?x?x?xf32>
          %105 = iree_tensor_ext.dispatch.tensor.load %96, offsets = [0, 0], sizes = [%85, %86], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86} -> tensor<?x?xf32>
          %106 = iree_tensor_ext.dispatch.tensor.load %97, offsets = [0, 0], sizes = [%85, %86], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%85, %86} -> tensor<?x?xf32>
          %107 = tensor.empty(%87) : tensor<?xf32>
          %108 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%107 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %109 = linalg.index 0 : index
            %110 = arith.remsi %109, %86 : index
            %111 = arith.divsi %109, %86 : index
            %112 = arith.divui %111, %99 : index
            %113 = arith.remui %111, %99 : index
            %114 = arith.cmpi eq, %100, %c1 : index
            %115 = arith.select %114, %c0, %113 : index
            %116 = arith.muli %112, %100 : index
            %117 = arith.addi %116, %115 : index
            %extracted = tensor.extract %102[%111] : tensor<?xi32>
            %118 = arith.index_cast %extracted : i32 to index
            %119 = arith.divui %101, %c4 : index
            %extracted_0 = tensor.extract %103[%117, %119] : tensor<?x?xf32>
            %extracted_1 = tensor.extract %104[%118, %110, %101] : tensor<?x?x?xf32>
            %extracted_2 = tensor.extract %105[%111, %110] : tensor<?x?xf32>
            %extracted_3 = tensor.extract %106[%111, %110] : tensor<?x?xf32>
            %120 = arith.mulf %extracted_2, %extracted_0 : f32
            %121 = arith.mulf %120, %extracted_1 : f32
            %122 = arith.addf %extracted_3, %121 : f32
            linalg.yield %122 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %108, %98, offsets = [0], sizes = [%87], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%87}
          return
        }
        iree_codegen.dispatch_config @grouped4_f32_dispatch_5_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @grouped4_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: f32, %arg7: !hal.fence, %arg8: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @grouped4_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf32>, %input3: tensor<?xi32>, %input4: i32, %input5: i32, %input6: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c32 = arith.constant 32 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f32) encoding(%dense_row_major)
    %16 = arith.muli %13, %c4 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20]) type(%element_type_i32) encoding(%dense_row_major)
    %21 = arith.muli %20, %c4 : index
    %22 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%20} in !stream.resource<external>{%21}
    %23 = arith.divui %1, %c32 : index
    %24 = arith.muli %0, %1 overflow<nsw> : index
    %25 = arith.divui %1, %c128 : index
    %26 = arith.muli %0, %25 overflow<nsw> : index
    %27 = arith.muli %26, %c4 : index
    %28 = arith.muli %21, %7 : index
    %29 = util.align %28, %c64 : index
    %30 = arith.addi %29, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%30} => !stream.timepoint
    %31 = stream.resource.subview %result[%c0] : !stream.resource<external>{%30} -> !stream.resource<external>{%c4}
    %32 = util.align %27, %c64 : index
    %33 = util.align %24, %c64 : index
    %34 = arith.addi %32, %33 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%34} => !stream.timepoint
    %35 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %36 = arith.index_castui %24 : index to i64
    %37 = arith.index_castui %24 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %26 : index to i64
    %41 = arith.index_castui %26 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.bitcast %arg6 : f32 to i32
    %45 = arith.index_castui %32 : index to i64
    %46 = arith.index_castui %32 : index to i32
    %47 = arith.shrui %45, %c32_i64 : i64
    %48 = arith.trunci %47 : i64 to i32
    %49 = arith.index_castui %0 : index to i64
    %50 = arith.index_castui %0 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %1 : index to i64
    %54 = arith.index_castui %1 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %25 : index to i64
    %58 = arith.index_castui %25 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%35) => with(%4 as %arg9: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg10: !stream.resource<constant>{%c512}, %result as %arg11: !stream.resource<external>{%30}, %result_0 as %arg12: !stream.resource<transient>{%34}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%24](%37, %39 : i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg11[%c0 for %30] : !stream.resource<external>{%30}
        }
        stream.cmd.dispatch @linear_power_f32_dispatch_1::@vulkan_spirv_fb::@linear_power_f32_dispatch_1_reduction_DxD_f32[%26, %c128](%41, %43, %44 : i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg12[%c0 for %34] : !stream.resource<transient>{%34}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_2::@vulkan_spirv_fb::@linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8[%24, %0, %1, %25](%46, %48, %37, %39, %50, %52, %54, %56, %58, %60 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg12[%c0 for %34] : !stream.resource<transient>{%34},
          ro %arg10[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg12[%c0 for %34] : !stream.resource<transient>{%34}
        }
        stream.cmd.fill %c0_i8, %arg11[%c64 for %28] : i8 -> !stream.resource<external>{%30}
      }
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %30, %c64, %28, %61 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%62: index, %63: !stream.resource<external>, %64: index, %65: index, %66: index, %67: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %68 = arith.cmpi slt, %62, %23 : index
    cf.cond_br %68, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %69 = arith.muli %62, %c32 : index
    %70 = arith.muli %20, %c32 overflow<nsw> : index
    %71 = arith.index_cast %arg5 : i32 to index
    %72 = arith.index_cast %arg4 : i32 to index
    %73 = arith.muli %20, %c128 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%61) => !stream.resource<transient>{%73} => !stream.timepoint
    %74 = arith.index_castui %70 : index to i64
    %75 = arith.index_castui %70 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = arith.index_castui %69 : index to i64
    %79 = arith.index_castui %69 : index to i32
    %80 = arith.shrui %78, %c32_i64 : i64
    %81 = arith.trunci %80 : i64 to i32
    %82 = arith.index_castui %72 : index to i64
    %83 = arith.index_castui %72 : index to i32
    %84 = arith.shrui %82, %c32_i64 : i64
    %85 = arith.trunci %84 : i64 to i32
    %86 = arith.index_castui %71 : index to i64
    %87 = arith.index_castui %71 : index to i32
    %88 = arith.shrui %86, %c32_i64 : i64
    %89 = arith.trunci %88 : i64 to i32
    %90 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%result_0 as %arg9: !stream.resource<transient>{%34}, %result_2 as %arg10: !stream.resource<transient>{%73}) {
      stream.cmd.dispatch @grouped4_f32_dispatch_3::@vulkan_spirv_fb::@grouped4_f32_dispatch_3_elementwise_broadcast_D_f32[%70, %69, %72, %71, %0, %1](%46, %48, %75, %77, %79, %81, %83, %85, %87, %89, %50, %52, %54, %56 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %34] : !stream.resource<transient>{%34},
        wo %arg10[%c0 for %73] : !stream.resource<transient>{%73}
      }
    } => !stream.timepoint
    %91 = stream.timepoint.await %90 => %result_2 : !stream.resource<transient>{%73}
    %92 = util.optimization_barrier %91 : !stream.resource<transient>
    %93 = arith.muli %20, %7 overflow<nsw> : index
    %94 = arith.muli %93, %c4 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%67) => !stream.resource<external>{%94} => !stream.timepoint
    %95 = arith.addi %29, %29 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%67) => !stream.resource<transient>{%95} => !stream.timepoint
    %96 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %97 = arith.index_castui %6 : index to i64
    %98 = arith.index_castui %6 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %8 : index to i64
    %102 = arith.index_castui %8 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %20 : index to i64
    %106 = arith.index_castui %20 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %7 : index to i64
    %110 = arith.index_castui %7 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %29 : index to i64
    %114 = arith.index_castui %29 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %93 : index to i64
    %118 = arith.index_castui %93 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = arith.index_castui %62 : index to i64
    %122 = arith.index_castui %62 : index to i32
    %123 = arith.shrui %121, %c32_i64 : i64
    %124 = arith.trunci %123 : i64 to i32
    %125 = arith.index_castui %13 : index to i64
    %126 = arith.index_castui %13 : index to i32
    %127 = arith.shrui %125, %c32_i64 : i64
    %128 = arith.trunci %127 : i64 to i32
    %129 = arith.index_castui %14 : index to i64
    %130 = arith.index_castui %14 : index to i32
    %131 = arith.shrui %129, %c32_i64 : i64
    %132 = arith.trunci %131 : i64 to i32
    %133 = arith.index_castui %15 : index to i64
    %134 = arith.index_castui %15 : index to i32
    %135 = arith.shrui %133, %c32_i64 : i64
    %136 = arith.trunci %135 : i64 to i32
    %137 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%96) => with(%22 as %arg9: !stream.resource<external>{%21}, %12 as %arg10: !stream.resource<external>{%11}, %92 as %arg11: !stream.resource<transient>{%73}, %63 as %arg12: !stream.resource<external>{%64}, %result_0 as %arg13: !stream.resource<transient>{%34}, %19 as %arg14: !stream.resource<external>{%18}, %result_4 as %arg15: !stream.resource<external>{%94}, %result_6 as %arg16: !stream.resource<transient>{%95}) {
      stream.cmd.dispatch @grouped4_f32_dispatch_4::@vulkan_spirv_fb::@grouped4_f32_dispatch_4_reduction_DxDxD_f32[%69, %6, %8, %c1, %c32, %20, %7](%79, %81, %98, %100, %102, %104, %106, %108, %110, %112 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg10[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg11[%c0 for %73] : !stream.resource<transient>{%73},
        wo %arg16[%c0 for %95] : !stream.resource<transient>{%95}
      }
      stream.cmd.copy %arg12[%65], %arg16[%29], %28 : !stream.resource<external>{%64} -> !stream.resource<transient>{%95}
      stream.cmd.dispatch @grouped4_f32_dispatch_5::@vulkan_spirv_fb::@grouped4_f32_dispatch_5_elementwise_broadcast_D_f32[%93, %72, %71, %62, %0, %25, %13, %14, %15, %20, %7](%114, %116, %118, %120, %83, %85, %87, %89, %122, %124, %50, %52, %58, %60, %126, %128, %130, %132, %134, %136, %106, %108, %110, %112 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg13[%c0 for %34] : !stream.resource<transient>{%34},
        ro %arg14[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg16[%c0 for %95] : !stream.resource<transient>{%95},
        wo %arg15[%c0 for %94] : !stream.resource<external>{%94}
      }
    } => !stream.timepoint
    %138 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%137) => %result_6 : !stream.resource<transient>{%95} => !stream.timepoint
    %139 = arith.addi %62, %c1 : index
    cf.br ^bb1(%139, %result_4, %94, %c0, %94, %138 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %140 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%67) => %result_0 : !stream.resource<transient>{%34} => !stream.timepoint
    %141 = stream.resource.subview %63[%65] : !stream.resource<external>{%64} -> !stream.resource<external>{%66}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %140 => (%arg8 : !hal.fence)
    %142 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %141 : tensor<?x?xf32>{%20, %7} in !stream.resource<external>{%28} -> !hal.buffer_view
    %143 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %31 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %142, %143 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @encoded_block128_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @encoded_block128_dispatch_3_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @encoded_block128_dispatch_3_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %0 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = arith.extui %1 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %0 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 {stream.alignment = 64 : index} : i64 to index
          %25 = arith.extui %3 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %2 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %5 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %4 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35 = arith.extui %7 : i32 to i64
          %36 = arith.shli %35, %c32_i64 : i64
          %37 = arith.extui %6 : i32 to i64
          %38 = arith.ori %37, %36 : i64
          %39 = arith.index_castui %38 : i64 to index
          %40 = arith.extui %9 : i32 to i64
          %41 = arith.shli %40, %c32_i64 : i64
          %42 = arith.extui %8 : i32 to i64
          %43 = arith.ori %42, %41 : i64
          %44 = arith.index_castui %43 : i64 to index
          %45 = arith.extui %11 : i32 to i64
          %46 = arith.shli %45, %c32_i64 : i64
          %47 = arith.extui %10 : i32 to i64
          %48 = arith.ori %47, %46 : i64
          %49 = arith.index_castui %48 : i64 to index
          %50 = arith.extui %13 : i32 to i64
          %51 = arith.shli %50, %c32_i64 : i64
          %52 = arith.extui %12 : i32 to i64
          %53 = arith.ori %52, %51 : i64
          %54 = arith.index_castui %53 : i64 to index
          %55 = arith.extui %15 : i32 to i64
          %56 = arith.shli %55, %c32_i64 : i64
          %57 = arith.extui %14 : i32 to i64
          %58 = arith.ori %57, %56 : i64
          %59 = arith.index_castui %58 : i64 to index
          %60 = arith.extui %17 : i32 to i64
          %61 = arith.shli %60, %c32_i64 : i64
          %62 = arith.extui %16 : i32 to i64
          %63 = arith.ori %62, %61 : i64
          %64 = arith.index_castui %63 : i64 to index
          %65 = arith.extui %19 : i32 to i64
          %66 = arith.shli %65, %c32_i64 : i64
          %67 = arith.extui %18 : i32 to i64
          %68 = arith.ori %67, %66 : i64
          %69 = arith.index_castui %68 : i64 to index
          %70:7 = util.assume.int 
              %39<umin = 0, umax = 9007199254740991>, 
              %44<umin = 0, umax = 9007199254740991>, 
              %49<umin = 0, umax = 9007199254740991>, 
              %54<umin = 0, umax = 9007199254740991>, 
              %59<umin = 0, umax = 9007199254740991>, 
              %64<umin = 0, umax = 9007199254740991>, 
              %69<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index
          %71 = iree_tensor_ext.dispatch.workload.ordinal %70#5, 7 : index
          %72 = iree_tensor_ext.dispatch.workload.ordinal %70#6, 8 : index
          %73 = iree_tensor_ext.dispatch.workload.ordinal %29, 0 : index
          %74 = iree_tensor_ext.dispatch.workload.ordinal %70#0, 2 : index
          %75 = iree_tensor_ext.dispatch.workload.ordinal %70#1, 3 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %70#2, 4 : index
          %77 = iree_tensor_ext.dispatch.workload.ordinal %70#3, 5 : index
          %78 = iree_tensor_ext.dispatch.workload.ordinal %70#4, 6 : index
          %79 = hal.interface.binding.subspan layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%74, %75}
          %80 = hal.interface.binding.subspan layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%76, %77, %78}
          %81 = hal.interface.binding.subspan layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%71, %72}
          %82 = hal.interface.binding.subspan layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%24) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%71, %72}
          %83 = hal.interface.binding.subspan layout(<constants = 20, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%73}
          %84 = iree_tensor_ext.dispatch.workload.ordinal %34, 1 : index
          %85 = iree_tensor_ext.dispatch.tensor.load %79, offsets = [0, 0], sizes = [%74, %75], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%74, %75} -> tensor<?x?xf32>
          %86 = iree_tensor_ext.dispatch.tensor.load %80, offsets = [0, 0, 0], sizes = [%76, %77, %78], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%76, %77, %78} -> tensor<?x?x?xf32>
          %87 = iree_tensor_ext.dispatch.tensor.load %81, offsets = [0, 0], sizes = [%71, %72], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%71, %72} -> tensor<?x?xf32>
          %88 = iree_tensor_ext.dispatch.tensor.load %82, offsets = [0, 0], sizes = [%71, %72], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%71, %72} -> tensor<?x?xf32>
          %89 = tensor.empty(%73) : tensor<?xf32>
          %90 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%89 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %91 = linalg.index 0 : index
            %92 = arith.remsi %91, %72 : index
            %93 = arith.divsi %91, %72 : index
            %94 = arith.divui %92, %c128 : index
            %extracted = tensor.extract %85[%93, %84] : tensor<?x?xf32>
            %extracted_0 = tensor.extract %86[%c0, %94, %84] : tensor<?x?x?xf32>
            %extracted_1 = tensor.extract %87[%93, %92] : tensor<?x?xf32>
            %extracted_2 = tensor.extract %88[%93, %92] : tensor<?x?xf32>
            %95 = arith.mulf %extracted_1, %extracted : f32
            %96 = arith.mulf %95, %extracted_0 : f32
            %97 = arith.addf %extracted_2, %96 : f32
            linalg.yield %97 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %90, %83, offsets = [0], sizes = [%73], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%73}
          return
        }
        iree_codegen.dispatch_config @encoded_block128_dispatch_3_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @encoded_block128(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @encoded_block128(%input0: tensor<?x?xi8>, %input1: tensor<?x?xf32>, %input2: tensor<?x?x?xi8>, %input3: tensor<?x?x?xf32>) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0_i32 = arith.constant 0 : i32
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c512 = arith.constant 512 : index
    %c4 = arith.constant 4 : index
    %c0_i8 = arith.constant 0 : i8
    %c128 = arith.constant 128 : index
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5, %6]) type(%element_type_f32) encoding(%dense_row_major)
    %7 = arith.muli %5, %c4 : index
    %8 = arith.muli %7, %6 : index
    %9 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf32>{%5, %6} in !stream.resource<external>{%8}
    %10 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%10, %11, %12]) type(%element_type_i8) encoding(%dense_row_major)
    %13 = arith.muli %10, %11 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%10, %11, %12} in !stream.resource<external>{%14}
    %16 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    %17 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[1] : index
    %18 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%16, %17, %18]) type(%element_type_f32) encoding(%dense_row_major)
    %19 = arith.muli %16, %c4 : index
    %20 = arith.muli %19, %17 : index
    %21 = arith.muli %20, %18 : index
    %22 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?x?x?xf32>{%16, %17, %18} in !stream.resource<external>{%21}
    %23 = arith.divui %1, %c128 : index
    %24 = arith.muli %0, %c4 : index
    %25 = arith.muli %24, %11 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%25} => !stream.timepoint
    %26 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg6: !stream.resource<external>{%25}) {
      stream.cmd.fill %c0_i8, %arg6[%c0 for %25] : i8 -> !stream.resource<external>{%25}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %26 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb1(%27: index, %28: !stream.resource<external>, %29: index, %30: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %31 = arith.cmpi slt, %27, %23 : index
    cf.cond_br %31, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %32 = arith.muli %27, %c128 : index
    %33 = arith.muli %0, %c128 overflow<nsw> : index
    %34 = arith.muli %0, %c512 : index
    %35 = arith.muli %11, %c128 overflow<nsw> : index
    %36 = arith.muli %11, %c512 : index
    %37 = arith.addi %34, %36 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<transient>{%37} => !stream.timepoint
    %38 = arith.index_castui %33 : index to i64
    %39 = arith.index_castui %33 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %32 : index to i64
    %43 = arith.index_castui %32 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %0 : index to i64
    %47 = arith.index_castui %0 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %1 : index to i64
    %51 = arith.index_castui %1 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %34 : index to i64
    %55 = arith.index_castui %34 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %35 : index to i64
    %59 = arith.index_castui %35 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = arith.index_castui %10 : index to i64
    %63 = arith.index_castui %10 : index to i32
    %64 = arith.shrui %62, %c32_i64 : i64
    %65 = arith.trunci %64 : i64 to i32
    %66 = arith.index_castui %11 : index to i64
    %67 = arith.index_castui %11 : index to i32
    %68 = arith.shrui %66, %c32_i64 : i64
    %69 = arith.trunci %68 : i64 to i32
    %70 = arith.index_castui %12 : index to i64
    %71 = arith.index_castui %12 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%3 as %arg6: !stream.resource<external>{%2}, %15 as %arg7: !stream.resource<external>{%14}, %result_0 as %arg8: !stream.resource<transient>{%37}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_3::@vulkan_spirv_fb::@linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32[%33, %32, %0, %1](%c0_i32, %c0_i32, %39, %41, %43, %45, %47, %49, %51, %53 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %2] : !stream.resource<external>{%2},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
      stream.cmd.dispatch @linear_normal_f32_dispatch_4::@vulkan_spirv_fb::@linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32[%35, %32, %10, %11, %12](%55, %57, %59, %61, %43, %45, %63, %65, %67, %69, %71, %73 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
    } => !stream.timepoint
    %75 = stream.timepoint.await %74 => %result_0 : !stream.resource<transient>{%37}
    %76 = stream.resource.subview %75[%c0] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%34}
    %77 = stream.resource.subview %75[%34] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%36}
    %78 = util.optimization_barrier %76 : !stream.resource<transient>
    %79 = util.optimization_barrier %77 : !stream.resource<transient>
    %80 = arith.muli %0, %11 overflow<nsw> : index
    %81 = arith.muli %80, %c4 : index
    %82 = stream.timepoint.join max(%4, %30) => !stream.timepoint
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%82) => !stream.resource<external>{%81} => !stream.timepoint
    %83 = util.align %25, %c64 : index
    %84 = arith.addi %83, %83 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%82) => !stream.resource<transient>{%84} => !stream.timepoint
    %85 = stream.timepoint.join max(%result_timepoint_3, %result_timepoint_5) => !stream.timepoint
    %86 = arith.index_castui %83 : index to i64
    %87 = arith.index_castui %83 : index to i32
    %88 = arith.shrui %86, %c32_i64 : i64
    %89 = arith.trunci %88 : i64 to i32
    %90 = arith.index_castui %80 : index to i64
    %91 = arith.index_castui %80 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %27 : index to i64
    %95 = arith.index_castui %27 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = arith.index_castui %5 : index to i64
    %99 = arith.index_castui %5 : index to i32
    %100 = arith.shrui %98, %c32_i64 : i64
    %101 = arith.trunci %100 : i64 to i32
    %102 = arith.index_castui %6 : index to i64
    %103 = arith.index_castui %6 : index to i32
    %104 = arith.shrui %102, %c32_i64 : i64
    %105 = arith.trunci %104 : i64 to i32
    %106 = arith.index_castui %16 : index to i64
    %107 = arith.index_castui %16 : index to i32
    %108 = arith.shrui %106, %c32_i64 : i64
    %109 = arith.trunci %108 : i64 to i32
    %110 = arith.index_castui %17 : index to i64
    %111 = arith.index_castui %17 : index to i32
    %112 = arith.shrui %110, %c32_i64 : i64
    %113 = arith.trunci %112 : i64 to i32
    %114 = arith.index_castui %18 : index to i64
    %115 = arith.index_castui %18 : index to i32
    %116 = arith.shrui %114, %c32_i64 : i64
    %117 = arith.trunci %116 : i64 to i32
    %118 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%85) => with(%78 as %arg6: !stream.resource<transient>{%34}, %79 as %arg7: !stream.resource<transient>{%36}, %28 as %arg8: !stream.resource<external>{%29}, %9 as %arg9: !stream.resource<external>{%8}, %22 as %arg10: !stream.resource<external>{%21}, %result_2 as %arg11: !stream.resource<external>{%81}, %result_4 as %arg12: !stream.resource<transient>{%84}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_5::@vulkan_spirv_fb::@linear_normal_f32_dispatch_5_matmul_DxDxD_f32[%c128, %0, %11](%47, %49, %67, %69 : i32, i32, i32, i32) {
        ro %arg6[%c0 for %34] : !stream.resource<transient>{%34},
        ro %arg7[%c0 for %36] : !stream.resource<transient>{%36},
        wo %arg12[%c0 for %84] : !stream.resource<transient>{%84}
      }
      stream.cmd.copy %arg8[%c0], %arg12[%83], %25 : !stream.resource<external>{%25} -> !stream.resource<transient>{%84}
      stream.cmd.dispatch @encoded_block128_dispatch_3::@vulkan_spirv_fb::@encoded_block128_dispatch_3_elementwise_broadcast_D_f32[%80, %27, %5, %6, %16, %17, %18, %0, %11](%87, %89, %91, %93, %95, %97, %99, %101, %103, %105, %107, %109, %111, %113, %115, %117, %47, %49, %67, %69 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %8] : !stream.resource<external>{%8},
        ro %arg10[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg12[%c0 for %84] : !stream.resource<transient>{%84},
        wo %arg11[%c0 for %81] : !stream.resource<external>{%81}
      }
    } => !stream.timepoint
    %119 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%118) => %result_4 : !stream.resource<transient>{%84} => !stream.timepoint
    %120 = arith.addi %27, %c1 : index
    cf.br ^bb1(%120, %result_2, %81, %119 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %30 => (%arg5 : !hal.fence)
    %121 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %28 : tensor<?x?xf32>{%0, %11} in !stream.resource<external>{%25} -> !hal.buffer_view
    util.return %121 : !hal.buffer_view
  }
  util.func public @grouped8_power_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: f32, %arg7: !hal.fence, %arg8: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @grouped8_power_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf32>, %input3: tensor<?xi32>, %input4: i32, %input5: i32, %input6: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f32) encoding(%dense_row_major)
    %16 = arith.muli %13, %c4 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20]) type(%element_type_i32) encoding(%dense_row_major)
    %21 = arith.muli %20, %c4 : index
    %22 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%20} in !stream.resource<external>{%21}
    %23 = arith.divui %1, %c128 : index
    %24 = arith.muli %0, %1 overflow<nsw> : index
    %25 = arith.muli %0, %23 overflow<nsw> : index
    %26 = arith.muli %25, %c4 : index
    %27 = arith.muli %21, %7 : index
    %28 = util.align %27, %c64 : index
    %29 = arith.addi %28, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%29} => !stream.timepoint
    %30 = stream.resource.subview %result[%c0] : !stream.resource<external>{%29} -> !stream.resource<external>{%c4}
    %31 = util.align %26, %c64 : index
    %32 = util.align %24, %c64 : index
    %33 = arith.addi %31, %32 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%33} => !stream.timepoint
    %34 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %35 = arith.index_castui %24 : index to i64
    %36 = arith.index_castui %24 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %25 : index to i64
    %40 = arith.index_castui %25 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = arith.bitcast %arg6 : f32 to i32
    %44 = arith.index_castui %31 : index to i64
    %45 = arith.index_castui %31 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %0 : index to i64
    %49 = arith.index_castui %0 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %1 : index to i64
    %53 = arith.index_castui %1 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %23 : index to i64
    %57 = arith.index_castui %23 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%34) => with(%4 as %arg9: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg10: !stream.resource<constant>{%c512}, %result as %arg11: !stream.resource<external>{%29}, %result_0 as %arg12: !stream.resource<transient>{%33}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%24](%36, %38 : i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg11[%c0 for %29] : !stream.resource<external>{%29}
        }
        stream.cmd.dispatch @linear_power_f32_dispatch_1::@vulkan_spirv_fb::@linear_power_f32_dispatch_1_reduction_DxD_f32[%25, %c128](%40, %42, %43 : i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg12[%c0 for %33] : !stream.resource<transient>{%33}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_2::@vulkan_spirv_fb::@linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8[%24, %0, %1, %23](%45, %47, %36, %38, %49, %51, %53, %55, %57, %59 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg12[%c0 for %33] : !stream.resource<transient>{%33},
          ro %arg10[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg12[%c0 for %33] : !stream.resource<transient>{%33}
        }
        stream.cmd.fill %c0_i8, %arg11[%c64 for %27] : i8 -> !stream.resource<external>{%29}
      }
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %29, %c64, %27, %60 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%61: index, %62: !stream.resource<external>, %63: index, %64: index, %65: index, %66: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %67 = arith.cmpi slt, %61, %23 : index
    cf.cond_br %67, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %68 = arith.muli %61, %c128 : index
    %69 = arith.muli %20, %c128 overflow<nsw> : index
    %70 = arith.index_cast %arg5 : i32 to index
    %71 = arith.index_cast %arg4 : i32 to index
    %72 = arith.muli %20, %c512 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%60) => !stream.resource<transient>{%72} => !stream.timepoint
    %73 = arith.index_castui %69 : index to i64
    %74 = arith.index_castui %69 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %68 : index to i64
    %78 = arith.index_castui %68 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %71 : index to i64
    %82 = arith.index_castui %71 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = arith.index_castui %70 : index to i64
    %86 = arith.index_castui %70 : index to i32
    %87 = arith.shrui %85, %c32_i64 : i64
    %88 = arith.trunci %87 : i64 to i32
    %89 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%result_0 as %arg9: !stream.resource<transient>{%33}, %result_2 as %arg10: !stream.resource<transient>{%72}) {
      stream.cmd.dispatch @grouped8_f32_dispatch_3::@vulkan_spirv_fb::@grouped8_f32_dispatch_3_elementwise_broadcast_D_f32[%69, %68, %71, %70, %0, %1](%45, %47, %74, %76, %78, %80, %82, %84, %86, %88, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %33] : !stream.resource<transient>{%33},
        wo %arg10[%c0 for %72] : !stream.resource<transient>{%72}
      }
    } => !stream.timepoint
    %90 = stream.timepoint.await %89 => %result_2 : !stream.resource<transient>{%72}
    %91 = util.optimization_barrier %90 : !stream.resource<transient>
    %92 = arith.muli %20, %7 overflow<nsw> : index
    %93 = arith.muli %92, %c4 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%66) => !stream.resource<external>{%93} => !stream.timepoint
    %94 = arith.addi %28, %28 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%66) => !stream.resource<transient>{%94} => !stream.timepoint
    %95 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %96 = arith.index_castui %6 : index to i64
    %97 = arith.index_castui %6 : index to i32
    %98 = arith.shrui %96, %c32_i64 : i64
    %99 = arith.trunci %98 : i64 to i32
    %100 = arith.index_castui %8 : index to i64
    %101 = arith.index_castui %8 : index to i32
    %102 = arith.shrui %100, %c32_i64 : i64
    %103 = arith.trunci %102 : i64 to i32
    %104 = arith.index_castui %20 : index to i64
    %105 = arith.index_castui %20 : index to i32
    %106 = arith.shrui %104, %c32_i64 : i64
    %107 = arith.trunci %106 : i64 to i32
    %108 = arith.index_castui %7 : index to i64
    %109 = arith.index_castui %7 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %28 : index to i64
    %113 = arith.index_castui %28 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %92 : index to i64
    %117 = arith.index_castui %92 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = arith.index_castui %61 : index to i64
    %121 = arith.index_castui %61 : index to i32
    %122 = arith.shrui %120, %c32_i64 : i64
    %123 = arith.trunci %122 : i64 to i32
    %124 = arith.index_castui %13 : index to i64
    %125 = arith.index_castui %13 : index to i32
    %126 = arith.shrui %124, %c32_i64 : i64
    %127 = arith.trunci %126 : i64 to i32
    %128 = arith.index_castui %14 : index to i64
    %129 = arith.index_castui %14 : index to i32
    %130 = arith.shrui %128, %c32_i64 : i64
    %131 = arith.trunci %130 : i64 to i32
    %132 = arith.index_castui %15 : index to i64
    %133 = arith.index_castui %15 : index to i32
    %134 = arith.shrui %132, %c32_i64 : i64
    %135 = arith.trunci %134 : i64 to i32
    %136 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%95) => with(%22 as %arg9: !stream.resource<external>{%21}, %12 as %arg10: !stream.resource<external>{%11}, %91 as %arg11: !stream.resource<transient>{%72}, %62 as %arg12: !stream.resource<external>{%63}, %result_0 as %arg13: !stream.resource<transient>{%33}, %19 as %arg14: !stream.resource<external>{%18}, %result_4 as %arg15: !stream.resource<external>{%93}, %result_6 as %arg16: !stream.resource<transient>{%94}) {
      stream.cmd.dispatch @grouped8_f32_dispatch_4::@vulkan_spirv_fb::@grouped8_f32_dispatch_4_reduction_DxDxD_f32[%68, %6, %8, %c1, %c128, %20, %7](%78, %80, %97, %99, %101, %103, %105, %107, %109, %111 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg10[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg11[%c0 for %72] : !stream.resource<transient>{%72},
        wo %arg16[%c0 for %94] : !stream.resource<transient>{%94}
      }
      stream.cmd.copy %arg12[%64], %arg16[%28], %27 : !stream.resource<external>{%63} -> !stream.resource<transient>{%94}
      stream.cmd.dispatch @grouped8_f32_dispatch_5::@vulkan_spirv_fb::@grouped8_f32_dispatch_5_elementwise_broadcast_D_f32[%92, %71, %70, %61, %0, %23, %13, %14, %15, %20, %7](%113, %115, %117, %119, %82, %84, %86, %88, %121, %123, %49, %51, %57, %59, %125, %127, %129, %131, %133, %135, %105, %107, %109, %111 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg13[%c0 for %33] : !stream.resource<transient>{%33},
        ro %arg14[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg16[%c0 for %94] : !stream.resource<transient>{%94},
        wo %arg15[%c0 for %93] : !stream.resource<external>{%93}
      }
    } => !stream.timepoint
    %137 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%136) => %result_6 : !stream.resource<transient>{%94} => !stream.timepoint
    %138 = arith.addi %61, %c1 : index
    cf.br ^bb1(%138, %result_4, %93, %c0, %93, %137 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %139 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%66) => %result_0 : !stream.resource<transient>{%33} => !stream.timepoint
    %140 = stream.resource.subview %62[%64] : !stream.resource<external>{%63} -> !stream.resource<external>{%65}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %139 => (%arg8 : !hal.fence)
    %141 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %140 : tensor<?x?xf32>{%20, %7} in !stream.resource<external>{%27} -> !hal.buffer_view
    %142 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %30 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %141, %142 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @linear_reciprocal_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_reciprocal_f32_dispatch_1_reduction_DxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_reciprocal_f32_dispatch_1_reduction_DxD_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c1 = arith.constant 1 : index
          %c23 = arith.constant 23 : index
          %c1_i32 = arith.constant 1 : i32
          %c253_i32 = arith.constant 253 : i32
          %c254_i32 = arith.constant 254 : i32
          %c16777216_i32 = arith.constant 16777216 : i32
          %c23_i32 = arith.constant 23 : i32
          %c8388608_i32 = arith.constant 8388608 : i32
          %c8388607_i32 = arith.constant 8388607 : i32
          %cst = arith.constant 0.00223214296 : f32
          %c128 = arith.constant 128 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = arith.extui %1 : i32 to i64
          %4 = arith.shli %3, %c32_i64 : i64
          %5 = arith.extui %0 : i32 to i64
          %6 = arith.ori %5, %4 : i64
          %7 = arith.index_castui %6 : i64 to index
          %8 = arith.bitcast %2 : i32 to f32
          %9 = util.assume.int %7<umin = 0, umax = 9223372036854775807> : index
          %10 = iree_tensor_ext.dispatch.workload.ordinal %9, 0 : index
          %11 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128}
          %12 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          %13 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          %14 = iree_tensor_ext.dispatch.tensor.load %11, offsets = [0, 0], sizes = [%10, 128], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128} -> tensor<?x128xf32>
          %15 = tensor.empty(%10) : tensor<?xf32>
          %16 = linalg.fill ins(%8 : f32) outs(%15 : tensor<?xf32>) -> tensor<?xf32>
          %17 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0)>], iterator_types = ["parallel", "reduction"]} ins(%14 : tensor<?x128xf32>) outs(%16 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: f32):
            %19 = math.absf %in : f32
            %20 = arith.maximumf %19, %out : f32
            linalg.yield %20 : f32
          } -> tensor<?xf32>
          %18:2 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%17 : tensor<?xf32>) outs(%15, %15 : tensor<?xf32>, tensor<?xf32>) {
          ^bb0(%in: f32, %out: f32, %out_0: f32):
            %19 = arith.mulf %in, %cst : f32
            %20 = arith.bitcast %19 : f32 to i32
            %21 = arith.andi %20, %c8388607_i32 : i32
            %22 = arith.ori %21, %c8388608_i32 : i32
            %23 = arith.shrui %20, %c23_i32 : i32
            %24 = arith.cmpi eq, %22, %c8388608_i32 : i32
            %25 = arith.select %24, %c8388608_i32, %c16777216_i32 : i32
            %26 = arith.select %24, %c254_i32, %c253_i32 : i32
            %27 = arith.subi %26, %23 : i32
            %28 = arith.subi %25, %22 : i32
            %29:2 = scf.for %arg0 = %c0 to %c23 step %c1 iter_args(%arg1 = %c1_i32, %arg2 = %28) -> (i32, i32) {
              %48 = arith.shli %arg2, %c1_i32 : i32
              %49 = arith.cmpi uge, %48, %22 : i32
              %50 = arith.select %49, %22, %c0_i32 : i32
              %51 = arith.subi %48, %50 : i32
              %52 = arith.shli %arg1, %c1_i32 : i32
              %53 = arith.extui %49 : i1 to i32
              %54 = arith.ori %52, %53 : i32
              scf.yield %54, %51 : i32, i32
            }
            %30 = arith.shli %29#1, %c1_i32 : i32
            %31 = arith.cmpi ugt, %30, %22 : i32
            %32 = arith.cmpi eq, %30, %22 : i32
            %33 = arith.andi %29#0, %c1_i32 : i32
            %34 = arith.cmpi ne, %33, %c0_i32 : i32
            %35 = arith.andi %32, %34 : i1
            %36 = arith.ori %31, %35 : i1
            %37 = arith.extui %36 : i1 to i32
            %38 = arith.addi %29#0, %37 : i32
            %39 = arith.cmpi uge, %38, %c16777216_i32 : i32
            %40 = arith.shrui %38, %c1_i32 : i32
            %41 = arith.select %39, %40, %38 : i32
            %42 = arith.extui %39 : i1 to i32
            %43 = arith.addi %27, %42 : i32
            %44 = arith.shli %43, %c23_i32 : i32
            %45 = arith.andi %41, %c8388607_i32 : i32
            %46 = arith.ori %44, %45 : i32
            %47 = arith.bitcast %46 : i32 to f32
            linalg.yield %19, %47 : f32, f32
          } -> (tensor<?xf32>, tensor<?xf32>)
          iree_tensor_ext.dispatch.tensor.store %18#0, %12, offsets = [0], sizes = [%10], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          iree_tensor_ext.dispatch.tensor.store %18#1, %13, offsets = [0], sizes = [%10], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          return
        }
        iree_codegen.dispatch_config @linear_reciprocal_f32_dispatch_1_reduction_DxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @linear_reciprocal_f32_dispatch_2 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c128_i32 = arith.constant 128 : i32
          %c24_i32 = arith.constant 24 : i32
          %c1_i32 = arith.constant 1 : i32
          %c126 = arith.constant 126 : index
          %c2 = arith.constant 2 : index
          %c1 = arith.constant 1 : index
          %c128 = arith.constant 128 : index
          %cst = arith.constant 4.480000e+02 : f32
          %cst_0 = arith.constant -4.480000e+02 : f32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 {stream.alignment = 64 : index} : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:5 = util.assume.int 
              %14<udiv = 64>, 
              %19<umin = 0, umax = 9223372036854775807>, 
              %24<umin = 0, umax = 9007199254740991>, 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 70368744177663>
            : index, index, index, index, index
          %36 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(ReadOnly) : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>>
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 0 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#2, 1 : index
          %39 = iree_tensor_ext.dispatch.workload.ordinal %35#3, 2 : index
          %40 = iree_tensor_ext.dispatch.workload.ordinal %35#4, 3 : index
          %41 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39}
          %42 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40}
          %43 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, ReadOnly>, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%35#0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          %44 = iree_tensor_ext.dispatch.tensor.load %41, offsets = [0, 0], sizes = [%38, %39], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %39} -> tensor<?x?xf32>
          %45 = iree_tensor_ext.dispatch.tensor.load %42, offsets = [0, 0], sizes = [%38, %40], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%38, %40} -> tensor<?x?xf32>
          %46 = iree_tensor_ext.dispatch.tensor.load %36, offsets = [0], sizes = [127], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<127xf32>> -> tensor<127xf32>
          %47 = tensor.empty(%37) : tensor<?xi8>
          %48 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%47 : tensor<?xi8>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i8):
            %49 = linalg.index 0 : index
            %50 = arith.remsi %49, %39 : index
            %51 = arith.divsi %49, %39 : index
            %52 = arith.divui %50, %c128 : index
            %extracted = tensor.extract %44[%51, %50] : tensor<?x?xf32>
            %extracted_1 = tensor.extract %45[%51, %52] : tensor<?x?xf32>
            %53 = arith.mulf %extracted, %extracted_1 : f32
            %54 = arith.maximumf %53, %cst_0 : f32
            %55 = arith.minimumf %54, %cst : f32
            %56 = math.absf %55 : f32
            %57 = arith.minimumf %56, %cst : f32
            %58:2 = scf.while (%arg0 = %c0, %arg1 = %c126) : (index, index) -> (index, index) {
              %82 = arith.cmpi ult, %arg0, %arg1 : index
              scf.condition(%82) %arg0, %arg1 : index, index
            } do {
            ^bb0(%arg0: index, %arg1: index):
              %82 = arith.addi %arg0, %arg1 : index
              %83 = arith.addi %82, %c1 : index
              %84 = arith.divui %83, %c2 : index
              %extracted_4 = tensor.extract %46[%84] : tensor<127xf32>
              %85 = arith.cmpf ole, %extracted_4, %57 : f32
              %86 = arith.subi %84, %c1 : index
              %87 = arith.select %85, %84, %arg0 : index
              %88 = arith.select %85, %arg1, %86 : index
              scf.yield %87, %88 : index, index
            }
            %59 = arith.addi %58#0, %c1 : index
            %60 = arith.minui %59, %c126 : index
            %extracted_2 = tensor.extract %46[%58#0] : tensor<127xf32>
            %extracted_3 = tensor.extract %46[%60] : tensor<127xf32>
            %61 = arith.subf %57, %extracted_2 : f32
            %62 = arith.subf %57, %extracted_3 : f32
            %63 = math.absf %61 : f32
            %64 = math.absf %62 : f32
            %65 = arith.cmpf olt, %64, %63 : f32
            %66 = arith.cmpf oeq, %64, %63 : f32
            %67 = arith.index_castui %58#0 : index to i32
            %68 = arith.index_castui %60 : index to i32
            %69 = arith.andi %67, %c1_i32 : i32
            %70 = arith.andi %68, %c1_i32 : i32
            %71 = arith.cmpi ne, %69, %c0_i32 : i32
            %72 = arith.cmpi eq, %70, %c0_i32 : i32
            %73 = arith.andi %66, %72 : i1
            %74 = arith.andi %73, %71 : i1
            %75 = arith.ori %65, %74 : i1
            %76 = arith.select %75, %68, %67 : i32
            %77 = arith.bitcast %55 : f32 to i32
            %78 = arith.shrui %77, %c24_i32 : i32
            %79 = arith.andi %78, %c128_i32 : i32
            %80 = arith.ori %76, %79 : i32
            %81 = arith.trunci %80 : i32 to i8
            linalg.yield %81 : i8
          } -> tensor<?xi8>
          iree_tensor_ext.dispatch.tensor.store %48, %43, offsets = [0], sizes = [%37], strides = [1] : tensor<?xi8> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi8>>{%37}
          return
        }
        iree_codegen.dispatch_config @linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @linear_reciprocal_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: f32, %arg4: !hal.fence, %arg5: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @linear_reciprocal_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi8>, %input2: tensor<?x?x?xf32>, %input3: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i8) encoding(%dense_row_major)
    %9 = arith.muli %6, %7 : index
    %10 = arith.muli %9, %8 : index
    %11 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi8>{%6, %7, %8} in !stream.resource<external>{%10}
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%12, %13, %14]) type(%element_type_f32) encoding(%dense_row_major)
    %15 = arith.muli %12, %c4 : index
    %16 = arith.muli %15, %13 : index
    %17 = arith.muli %16, %14 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%12, %13, %14} in !stream.resource<external>{%17}
    %19 = arith.divui %1, %c128 : index
    %20 = arith.muli %0, %1 overflow<nsw> : index
    %21 = arith.muli %0, %19 overflow<nsw> : index
    %22 = arith.muli %21, %c4 : index
    %23 = arith.muli %2, %7 : index
    %24 = util.align %23, %c64 : index
    %25 = arith.addi %24, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%25} => !stream.timepoint
    %26 = stream.resource.subview %result[%c0] : !stream.resource<external>{%25} -> !stream.resource<external>{%c4}
    %27 = util.align %22, %c64 : index
    %28 = util.align %20, %c64 : index
    %29 = arith.addi %27, %28 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%29} => !stream.timepoint
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%27} => !stream.timepoint
    %30 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1, %result_timepoint_3) => !stream.timepoint
    %31 = arith.index_castui %20 : index to i64
    %32 = arith.index_castui %20 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %21 : index to i64
    %36 = arith.index_castui %21 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.bitcast %arg3 : f32 to i32
    %40 = arith.index_castui %27 : index to i64
    %41 = arith.index_castui %27 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %0 : index to i64
    %45 = arith.index_castui %0 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %1 : index to i64
    %49 = arith.index_castui %1 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %19 : index to i64
    %53 = arith.index_castui %19 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%30) => with(%4 as %arg6: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg7: !stream.resource<constant>{%c512}, %result as %arg8: !stream.resource<external>{%25}, %result_0 as %arg9: !stream.resource<transient>{%29}, %result_2 as %arg10: !stream.resource<transient>{%27}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%20](%32, %34 : i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg8[%c0 for %25] : !stream.resource<external>{%25}
        }
        stream.cmd.dispatch @linear_reciprocal_f32_dispatch_1::@vulkan_spirv_fb::@linear_reciprocal_f32_dispatch_1_reduction_DxD_f32[%21, %c128](%36, %38, %39 : i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29},
          wo %arg10[%c0 for %27] : !stream.resource<transient>{%27}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_reciprocal_f32_dispatch_2::@vulkan_spirv_fb::@linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8[%20, %0, %1, %19](%41, %43, %32, %34, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg10[%c0 for %27] : !stream.resource<transient>{%27},
          ro %arg7[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29}
        }
        stream.cmd.fill %c0_i8, %arg8[%c64 for %23] : i8 -> !stream.resource<external>{%25}
      }
    } => !stream.timepoint
    %57 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%56) => %result_2 : !stream.resource<transient>{%27} => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %c64, %23, %57 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%58: index, %59: !stream.resource<external>, %60: index, %61: index, %62: index, %63: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %64 = arith.cmpi slt, %58, %19 : index
    cf.cond_br %64, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %65 = arith.muli %58, %c128 : index
    %66 = arith.muli %0, %c128 overflow<nsw> : index
    %67 = arith.muli %0, %c512 : index
    %68 = arith.muli %7, %c128 overflow<nsw> : index
    %69 = arith.muli %7, %c512 : index
    %70 = arith.addi %67, %69 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%57) => !stream.resource<transient>{%70} => !stream.timepoint
    %71 = arith.index_castui %66 : index to i64
    %72 = arith.index_castui %66 : index to i32
    %73 = arith.shrui %71, %c32_i64 : i64
    %74 = arith.trunci %73 : i64 to i32
    %75 = arith.index_castui %65 : index to i64
    %76 = arith.index_castui %65 : index to i32
    %77 = arith.shrui %75, %c32_i64 : i64
    %78 = arith.trunci %77 : i64 to i32
    %79 = arith.index_castui %67 : index to i64
    %80 = arith.index_castui %67 : index to i32
    %81 = arith.shrui %79, %c32_i64 : i64
    %82 = arith.trunci %81 : i64 to i32
    %83 = arith.index_castui %68 : index to i64
    %84 = arith.index_castui %68 : index to i32
    %85 = arith.shrui %83, %c32_i64 : i64
    %86 = arith.trunci %85 : i64 to i32
    %87 = arith.index_castui %6 : index to i64
    %88 = arith.index_castui %6 : index to i32
    %89 = arith.shrui %87, %c32_i64 : i64
    %90 = arith.trunci %89 : i64 to i32
    %91 = arith.index_castui %7 : index to i64
    %92 = arith.index_castui %7 : index to i32
    %93 = arith.shrui %91, %c32_i64 : i64
    %94 = arith.trunci %93 : i64 to i32
    %95 = arith.index_castui %8 : index to i64
    %96 = arith.index_castui %8 : index to i32
    %97 = arith.shrui %95, %c32_i64 : i64
    %98 = arith.trunci %97 : i64 to i32
    %99 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_5) => with(%result_0 as %arg6: !stream.resource<transient>{%29}, %11 as %arg7: !stream.resource<external>{%10}, %result_4 as %arg8: !stream.resource<transient>{%70}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_3::@vulkan_spirv_fb::@linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32[%66, %65, %0, %1](%41, %43, %72, %74, %76, %78, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %70] : !stream.resource<transient>{%70}
      }
      stream.cmd.dispatch @linear_normal_f32_dispatch_4::@vulkan_spirv_fb::@linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32[%68, %65, %6, %7, %8](%80, %82, %84, %86, %76, %78, %88, %90, %92, %94, %96, %98 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %10] : !stream.resource<external>{%10},
        wo %arg8[%c0 for %70] : !stream.resource<transient>{%70}
      }
    } => !stream.timepoint
    %100 = stream.timepoint.await %99 => %result_4 : !stream.resource<transient>{%70}
    %101 = stream.resource.subview %100[%c0] : !stream.resource<transient>{%70} -> !stream.resource<transient>{%67}
    %102 = stream.resource.subview %100[%67] : !stream.resource<transient>{%70} -> !stream.resource<transient>{%69}
    %103 = util.optimization_barrier %101 : !stream.resource<transient>
    %104 = util.optimization_barrier %102 : !stream.resource<transient>
    %105 = arith.muli %0, %7 overflow<nsw> : index
    %106 = arith.muli %105, %c4 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%63) => !stream.resource<external>{%106} => !stream.timepoint
    %107 = arith.addi %24, %24 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%63) => !stream.resource<transient>{%107} => !stream.timepoint
    %108 = stream.timepoint.join max(%result_timepoint_7, %result_timepoint_9) => !stream.timepoint
    %109 = arith.index_castui %24 : index to i64
    %110 = arith.index_castui %24 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %105 : index to i64
    %114 = arith.index_castui %105 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %58 : index to i64
    %118 = arith.index_castui %58 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = arith.index_castui %12 : index to i64
    %122 = arith.index_castui %12 : index to i32
    %123 = arith.shrui %121, %c32_i64 : i64
    %124 = arith.trunci %123 : i64 to i32
    %125 = arith.index_castui %13 : index to i64
    %126 = arith.index_castui %13 : index to i32
    %127 = arith.shrui %125, %c32_i64 : i64
    %128 = arith.trunci %127 : i64 to i32
    %129 = arith.index_castui %14 : index to i64
    %130 = arith.index_castui %14 : index to i32
    %131 = arith.shrui %129, %c32_i64 : i64
    %132 = arith.trunci %131 : i64 to i32
    %133 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%108) => with(%103 as %arg6: !stream.resource<transient>{%67}, %104 as %arg7: !stream.resource<transient>{%69}, %59 as %arg8: !stream.resource<external>{%60}, %result_0 as %arg9: !stream.resource<transient>{%29}, %18 as %arg10: !stream.resource<external>{%17}, %result_6 as %arg11: !stream.resource<external>{%106}, %result_8 as %arg12: !stream.resource<transient>{%107}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_5::@vulkan_spirv_fb::@linear_normal_f32_dispatch_5_matmul_DxDxD_f32[%c128, %0, %7](%45, %47, %92, %94 : i32, i32, i32, i32) {
        ro %arg6[%c0 for %67] : !stream.resource<transient>{%67},
        ro %arg7[%c0 for %69] : !stream.resource<transient>{%69},
        wo %arg12[%c0 for %107] : !stream.resource<transient>{%107}
      }
      stream.cmd.copy %arg8[%61], %arg12[%24], %23 : !stream.resource<external>{%60} -> !stream.resource<transient>{%107}
      stream.cmd.dispatch @linear_normal_f32_dispatch_6::@vulkan_spirv_fb::@linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32[%105, %58, %0, %19, %12, %13, %14, %7](%110, %112, %114, %116, %118, %120, %45, %47, %53, %55, %122, %124, %126, %128, %130, %132, %92, %94 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %29] : !stream.resource<transient>{%29},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg12[%c0 for %107] : !stream.resource<transient>{%107},
        wo %arg11[%c0 for %106] : !stream.resource<external>{%106}
      }
    } => !stream.timepoint
    %134 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%133) => %result_8 : !stream.resource<transient>{%107} => !stream.timepoint
    %135 = arith.addi %58, %c1 : index
    cf.br ^bb1(%135, %result_6, %106, %c0, %106, %134 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %136 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%63) => %result_0 : !stream.resource<transient>{%29} => !stream.timepoint
    %137 = stream.resource.subview %59[%61] : !stream.resource<external>{%60} -> !stream.resource<external>{%62}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %136 => (%arg5 : !hal.fence)
    %138 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %137 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%23} -> !hal.buffer_view
    %139 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %26 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %138, %139 : !hal.buffer_view, !hal.buffer_view
  }
  util.func public @grouped8_reciprocal_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: f32, %arg7: !hal.fence, %arg8: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @grouped8_reciprocal_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf32>, %input3: tensor<?xi32>, %input4: i32, %input5: i32, %input6: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f32) encoding(%dense_row_major)
    %16 = arith.muli %13, %c4 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20]) type(%element_type_i32) encoding(%dense_row_major)
    %21 = arith.muli %20, %c4 : index
    %22 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%20} in !stream.resource<external>{%21}
    %23 = arith.divui %1, %c128 : index
    %24 = arith.muli %0, %1 overflow<nsw> : index
    %25 = arith.muli %0, %23 overflow<nsw> : index
    %26 = arith.muli %25, %c4 : index
    %27 = arith.muli %21, %7 : index
    %28 = util.align %27, %c64 : index
    %29 = arith.addi %28, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%29} => !stream.timepoint
    %30 = stream.resource.subview %result[%c0] : !stream.resource<external>{%29} -> !stream.resource<external>{%c4}
    %31 = util.align %26, %c64 : index
    %32 = util.align %24, %c64 : index
    %33 = arith.addi %31, %32 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%33} => !stream.timepoint
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%31} => !stream.timepoint
    %34 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1, %result_timepoint_3) => !stream.timepoint
    %35 = arith.index_castui %24 : index to i64
    %36 = arith.index_castui %24 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %25 : index to i64
    %40 = arith.index_castui %25 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = arith.bitcast %arg6 : f32 to i32
    %44 = arith.index_castui %31 : index to i64
    %45 = arith.index_castui %31 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %0 : index to i64
    %49 = arith.index_castui %0 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %1 : index to i64
    %53 = arith.index_castui %1 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %23 : index to i64
    %57 = arith.index_castui %23 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%34) => with(%4 as %arg9: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg10: !stream.resource<constant>{%c512}, %result as %arg11: !stream.resource<external>{%29}, %result_0 as %arg12: !stream.resource<transient>{%33}, %result_2 as %arg13: !stream.resource<transient>{%31}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%24](%36, %38 : i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg11[%c0 for %29] : !stream.resource<external>{%29}
        }
        stream.cmd.dispatch @linear_reciprocal_f32_dispatch_1::@vulkan_spirv_fb::@linear_reciprocal_f32_dispatch_1_reduction_DxD_f32[%25, %c128](%40, %42, %43 : i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg12[%c0 for %33] : !stream.resource<transient>{%33},
          wo %arg13[%c0 for %31] : !stream.resource<transient>{%31}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_reciprocal_f32_dispatch_2::@vulkan_spirv_fb::@linear_reciprocal_f32_dispatch_2_elementwise_broadcast_D_i8[%24, %0, %1, %23](%45, %47, %36, %38, %49, %51, %53, %55, %57, %59 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg13[%c0 for %31] : !stream.resource<transient>{%31},
          ro %arg10[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg12[%c0 for %33] : !stream.resource<transient>{%33}
        }
        stream.cmd.fill %c0_i8, %arg11[%c64 for %27] : i8 -> !stream.resource<external>{%29}
      }
    } => !stream.timepoint
    %61 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%60) => %result_2 : !stream.resource<transient>{%31} => !stream.timepoint
    cf.br ^bb1(%c0, %result, %29, %c64, %27, %61 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%62: index, %63: !stream.resource<external>, %64: index, %65: index, %66: index, %67: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %68 = arith.cmpi slt, %62, %23 : index
    cf.cond_br %68, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %69 = arith.muli %62, %c128 : index
    %70 = arith.muli %20, %c128 overflow<nsw> : index
    %71 = arith.index_cast %arg5 : i32 to index
    %72 = arith.index_cast %arg4 : i32 to index
    %73 = arith.muli %20, %c512 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%61) => !stream.resource<transient>{%73} => !stream.timepoint
    %74 = arith.index_castui %70 : index to i64
    %75 = arith.index_castui %70 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = arith.index_castui %69 : index to i64
    %79 = arith.index_castui %69 : index to i32
    %80 = arith.shrui %78, %c32_i64 : i64
    %81 = arith.trunci %80 : i64 to i32
    %82 = arith.index_castui %72 : index to i64
    %83 = arith.index_castui %72 : index to i32
    %84 = arith.shrui %82, %c32_i64 : i64
    %85 = arith.trunci %84 : i64 to i32
    %86 = arith.index_castui %71 : index to i64
    %87 = arith.index_castui %71 : index to i32
    %88 = arith.shrui %86, %c32_i64 : i64
    %89 = arith.trunci %88 : i64 to i32
    %90 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_5) => with(%result_0 as %arg9: !stream.resource<transient>{%33}, %result_4 as %arg10: !stream.resource<transient>{%73}) {
      stream.cmd.dispatch @grouped8_f32_dispatch_3::@vulkan_spirv_fb::@grouped8_f32_dispatch_3_elementwise_broadcast_D_f32[%70, %69, %72, %71, %0, %1](%45, %47, %75, %77, %79, %81, %83, %85, %87, %89, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %33] : !stream.resource<transient>{%33},
        wo %arg10[%c0 for %73] : !stream.resource<transient>{%73}
      }
    } => !stream.timepoint
    %91 = stream.timepoint.await %90 => %result_4 : !stream.resource<transient>{%73}
    %92 = util.optimization_barrier %91 : !stream.resource<transient>
    %93 = arith.muli %20, %7 overflow<nsw> : index
    %94 = arith.muli %93, %c4 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%67) => !stream.resource<external>{%94} => !stream.timepoint
    %95 = arith.addi %28, %28 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%67) => !stream.resource<transient>{%95} => !stream.timepoint
    %96 = stream.timepoint.join max(%result_timepoint_7, %result_timepoint_9) => !stream.timepoint
    %97 = arith.index_castui %6 : index to i64
    %98 = arith.index_castui %6 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %8 : index to i64
    %102 = arith.index_castui %8 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %20 : index to i64
    %106 = arith.index_castui %20 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %7 : index to i64
    %110 = arith.index_castui %7 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %28 : index to i64
    %114 = arith.index_castui %28 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %93 : index to i64
    %118 = arith.index_castui %93 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = arith.index_castui %62 : index to i64
    %122 = arith.index_castui %62 : index to i32
    %123 = arith.shrui %121, %c32_i64 : i64
    %124 = arith.trunci %123 : i64 to i32
    %125 = arith.index_castui %13 : index to i64
    %126 = arith.index_castui %13 : index to i32
    %127 = arith.shrui %125, %c32_i64 : i64
    %128 = arith.trunci %127 : i64 to i32
    %129 = arith.index_castui %14 : index to i64
    %130 = arith.index_castui %14 : index to i32
    %131 = arith.shrui %129, %c32_i64 : i64
    %132 = arith.trunci %131 : i64 to i32
    %133 = arith.index_castui %15 : index to i64
    %134 = arith.index_castui %15 : index to i32
    %135 = arith.shrui %133, %c32_i64 : i64
    %136 = arith.trunci %135 : i64 to i32
    %137 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%96) => with(%22 as %arg9: !stream.resource<external>{%21}, %12 as %arg10: !stream.resource<external>{%11}, %92 as %arg11: !stream.resource<transient>{%73}, %63 as %arg12: !stream.resource<external>{%64}, %result_0 as %arg13: !stream.resource<transient>{%33}, %19 as %arg14: !stream.resource<external>{%18}, %result_6 as %arg15: !stream.resource<external>{%94}, %result_8 as %arg16: !stream.resource<transient>{%95}) {
      stream.cmd.dispatch @grouped8_f32_dispatch_4::@vulkan_spirv_fb::@grouped8_f32_dispatch_4_reduction_DxDxD_f32[%69, %6, %8, %c1, %c128, %20, %7](%79, %81, %98, %100, %102, %104, %106, %108, %110, %112 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg10[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg11[%c0 for %73] : !stream.resource<transient>{%73},
        wo %arg16[%c0 for %95] : !stream.resource<transient>{%95}
      }
      stream.cmd.copy %arg12[%65], %arg16[%28], %27 : !stream.resource<external>{%64} -> !stream.resource<transient>{%95}
      stream.cmd.dispatch @grouped8_f32_dispatch_5::@vulkan_spirv_fb::@grouped8_f32_dispatch_5_elementwise_broadcast_D_f32[%93, %72, %71, %62, %0, %23, %13, %14, %15, %20, %7](%114, %116, %118, %120, %83, %85, %87, %89, %122, %124, %49, %51, %57, %59, %126, %128, %130, %132, %134, %136, %106, %108, %110, %112 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %21] : !stream.resource<external>{%21},
        ro %arg13[%c0 for %33] : !stream.resource<transient>{%33},
        ro %arg14[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg16[%c0 for %95] : !stream.resource<transient>{%95},
        wo %arg15[%c0 for %94] : !stream.resource<external>{%94}
      }
    } => !stream.timepoint
    %138 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%137) => %result_8 : !stream.resource<transient>{%95} => !stream.timepoint
    %139 = arith.addi %62, %c1 : index
    cf.br ^bb1(%139, %result_6, %94, %c0, %94, %138 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %140 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%67) => %result_0 : !stream.resource<transient>{%33} => !stream.timepoint
    %141 = stream.resource.subview %63[%65] : !stream.resource<external>{%64} -> !stream.resource<external>{%66}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %140 => (%arg8 : !hal.fence)
    %142 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %141 : tensor<?x?xf32>{%20, %7} in !stream.resource<external>{%27} -> !hal.buffer_view
    %143 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %30 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %142, %143 : !hal.buffer_view, !hal.buffer_view
  }
}