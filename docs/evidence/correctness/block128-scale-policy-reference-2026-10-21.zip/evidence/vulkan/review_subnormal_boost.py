"""Finite exact-rational host check of only the new E4 normalization boost."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[3]
def power(e):return F(1<<e) if e>=0 else F(1,1<<(-e))
def value(bits):
    exponent=(bits>>23)&255;fraction=bits&0x7fffff
    assert exponent<255
    absolute=F(fraction)*power(-149) if exponent==0 else F(0x800000|fraction)*power(exponent-150)
    return -absolute if bits>>31 else absolute

def even(f):
    q,r=divmod(f.numerator,f.denominator)
    return q+int(r*2>f.denominator or (r*2==f.denominator and q&1))
def encode_f32(f,negative_zero=False):
    sign=0x80000000 if f<0 or (f==0 and negative_zero) else 0;f=abs(f)
    if not f:return sign
    exponent=f.numerator.bit_length()-f.denominator.bit_length()
    if f<power(exponent):exponent-=1
    if exponent < -126:
        return sign|even(f*power(149))
    mantissa=even(f*power(23-exponent))
    if mantissa==1<<24:mantissa>>=1;exponent+=1
    if exponent>127:return sign|0x7f800000
    return sign|((exponent+127)<<23)|(mantissa&0x7fffff)
def multiply(a,b,flush_result=False):
    sign=bool((a^b)&0x80000000);v=value(a)*value(b);bits=encode_f32(v,sign)
    if flush_result and 0<(bits&0x7fffffff)<0x800000:return bits&0x80000000
    return bits

def e4(bits):
    sign=0x80 if bits>>31 else 0;v=abs(value(bits));candidates=[]
    for code in range(127):
        exponent=code>>3;fraction=code&7
        decoded=F(fraction)*power(-9) if exponent==0 else F(8+fraction)*power(exponent-10)
        candidates.append((abs(decoded-v),code&1,code))
    return sign|min(candidates)[2]

def boost(a,inverse,flush_result=False):
    # Shader conversion and both powers are exactly representable normal F32.
    mantissa=encode_f32(F(a&0x7fffffff))
    normalized_mantissa=multiply(mantissa,encode_f32(power(-125)))|(a&0x80000000)
    return multiply(multiply(normalized_mantissa,inverse,flush_result),encode_f32(power(-24)),flush_result)

scales=[0x00800000,0x00800001,0x00ffffff,0x3b124925,0x3f7edb6e,0x3f809249]
maximum_scale=multiply(0x7f7fffff,0x3b124925);scales+=[maximum_scale]
floor_scale=multiply(encode_f32(F(1,10**10)),0x3b124925);scales+=[floor_scale]
inverses=[encode_f32(1/value(x)) for x in scales]
raw=[1,2,3,0x7f,0x80,0xff,0x100,0x7fff,0xffff,0x10000,0x20000,0x70000,0x3fffff,0x7f0000,0x7ffffe,0x7fffff]
count=0;nonzero=0;ftz_sensitive=[]
for absolute in raw:
 for sign in [0,0x80000000]:
  a=absolute|sign
  for inv in inverses:
   direct=multiply(a,inv);actual=boost(a,inv);flushed=boost(a,inv,True)
   assert e4(actual)==e4(direct),(a,inv,actual,direct)
   assert e4(flushed)==e4(direct),(a,inv,flushed,direct)
   count+=1;nonzero+=bool(e4(direct)&127)
   if e4(direct)!=(0x80 if sign else 0):ftz_sensitive.append({'A_bits':hex(a),'inverse_bits':hex(inv),'direct_F32_bits':hex(direct),'E4_code':hex(e4(direct))})
report={'status':'finite_exact_Fraction_E4_encode_check_passed_not_device_execution','samples':count,'nonzero_E4_samples':nonzero,'mismatches':0,'raw_subnormal_A_magnitudes':raw,'normal_group_scales':list(map(hex,scales)),'normal_inverses':list(map(hex,inverses)),'FTZ_sensitive_examples':ftz_sensitive[:4],
'proof':['For raw subnormal 0<m<2^23, converting m to F32 is exact. m*2^-125 equals the original magnitude*2^24 and is normal; restore sign with raw OR.','The public normal-SF floor yields inverse <=2^126; the maximum finite source A limits SA to F32(FLTMAX*F32(1/448)), so its reciprocal is also positive normal. For raw subnormal A the boosted product is <2^24, hence cannot overflow.','If the final E4 code is nonzero, the true magnitude is at least the minimum E4 midpoint2^-10. Both the boosted product and the final unboosted value are then normal. Scaling by powers of2 maps their F32 rounding lattices exactly, so normal-RNE multiplication followed by exact unboost has the same E4 decision as RN(A*inverse).','If either product underflows or is flushed, the final magnitude is far below the E4 zero midpoint. Signed zero follows the preserved sign and the unchanged E4 codec. The claim is E4 code equivalence, not bitwise equality of every tiny F32 intermediate.'],
'limits':'Finite boundary samples; not exhaustive F32 input/inverse proof, GPU validation, native FP8 throughput or AMD rcpf equivalence.',
'generator':{'path':str(R/'third_party/iree_vulkan_runtime/programs/generate_official.py'),'sha256':hashlib.sha256((R/'third_party/iree_vulkan_runtime/programs/generate_official.py').read_bytes()).hexdigest()},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'GPU_runs':0}
(S/'subnormal-boost-review.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps({'samples':count,'nonzero_E4':nonzero,'mismatches':0,'report':str(S/'subnormal-boost-review.json')}))
