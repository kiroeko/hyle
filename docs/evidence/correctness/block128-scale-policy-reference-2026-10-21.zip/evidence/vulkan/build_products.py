"""Compile five actual Vulkan owners over the current Y closure. No link/GPU."""
from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];R=A.parents[1]
spec=importlib.util.spec_from_file_location('outer_helpers',A/'quark-fp8-side-2026-10-21/windows/build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
basepath=A/'quark-fp8-side-2026-10-21/vulkan/checks/link4/link-plan.json';base=b.c.read(basepath);inputs={b.c.key(row['path']):row for row in base['inputs']}
recipes=[('native-program',A/'mlx-weight-orientation-2026-10-21/vulkan/checks/attempt1/native-program-identity.json'),('official',A/'grouped-fp8-power2-reference/vulkan/checks/products/official-identity.json'),('iree',A/'mlx-weight-orientation-2026-10-21/vulkan/checks/attempt1/iree-identity.json'),('program',A/'quark-fp8-side-2026-10-21/windows/checks/attempt1/vulkan-program/identity.json'),('embedded',A/'mlx-weight-orientation-2026-10-21/vulkan/checks/embedded2/embedded-identity.json')]
rows=[]
for tag,recipe in recipes:
 d=b.c.read(recipe);old=d['object'];assert b.c.key(old['path']) in inputs and b.b.same(old)
 source=S/'generated/programs.cc' if tag=='embedded' else Path(d['source']['path'])
 rows.append((dict(source=b.b.identity(source),old_object=old,command=d['command'],recipe=b.b.identity(recipe)),tag))
names=['include/hyle/compute/model_ops.h','src/compute_provider_iree_vulkan/native_program.h','src/compute_provider_iree_vulkan/native_program.cc','src/compute_route_vulkan/vulkan_official.cc','src/compute_route_vulkan/vulkan_iree.cc','src/compute_route_vulkan/vulkan_program.cc','third_party/iree_vulkan_runtime/programs/generate_official.py','third_party/iree_vulkan_runtime/programs/compile_official.py','third_party/iree_vulkan_runtime/programs/official.mlir','third_party/iree_vulkan_runtime/programs/manifest.json','third_party/iree_vulkan_runtime/programs/official.vmfb.b64','third_party/iree_vulkan_runtime/NOTICE.md']
frozen=[]
for name in names:
 p=R/name;out=S/'source-first'/name;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(p.read_bytes());frozen.append(b.b.identity(p))
frozen.append(b.b.identity(S/'generated/programs.cc'));b.c.save(S/'source-freeze-first.json',dict(sources=frozen,source_count=len(frozen),GPU_runs=0))
b.P=S;b.S=S
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 products=list(pool.map(lambda job:b.compile_job(job[0],job[1],'attempt1',frozen),rows))
assert all(b.b.same(row) for row in frozen)
b.c.save(S/'objects-ready.json',dict(status='five_actual_products_ready_no_link_no_GPU',records=products,CXX=5,official_VMFB_builds=2,first_offline_configuration_errors=1,other_VMFB_builds=0,SDK_builds=0,GPU_runs=0,actual_base=b.b.identity(basepath),ProgramSpec='V4 unchanged fields/layout; old ProgramKind values unchanged; append2',artifact_proof=b.b.identity(S/'artifact-proof.json')))
print(b.b.identity(S/'objects-ready.json'))
