from pathlib import Path
import difflib,hashlib,json,runpy,shutil,xml.etree.ElementTree as E
A=Path('.scratch/architecture-refactor-2026-10-18');P=A/'quark-block128-scale-2026-10-21/apple'
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
remote=json.loads((P/'mac/plan.json').read_text())['remote']
def identity(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=p.as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,v): (P/n).write_text(json.dumps(v,indent=2)+'\n')
code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(json.load(sys.stdin)['remote'])
def identity(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
p=r/'fp8-scale-policy.map';lines=p.read_text().splitlines()
objects=lines[lines.index('# Object files:')+1:lines.index('# Sections:')]
related=[x for x in objects if 'apple_mature_float.cc.o' in x or 'torch_cpu_program.cc.o' in x]
old=[x for x in related if '.a(' in x or '.a[' in x]
assert len(related)==2 and not old and all(str(r/'objects') in x for x in related)
map_audit=dict(map=identity(p),related_loaded_objects=related,related_old_archive_members=old,
  public_type_symbols=[x for x in lines if 'Float8BlockLinear' in x or 'GroupedFloat8Linear' in x],
  loaded_objects=objects,loaded_object_count=len(objects))
files=[];objects_retained=[]
for p in sorted(r.rglob('*')):
    if not p.is_file() or p.is_symlink():continue
    if p.suffix=='.o':objects_retained.append(identity(p));continue
    with p.open('rb') as f: magic=f.read(4)
    if p.suffix=='.map' or magic in [bytes.fromhex('cffaedfe'),bytes.fromhex('feedfacf'),bytes.fromhex('cafebabe')]:files.append(identity(p))
assert len(files)==2 and len(objects_retained)==3
images=[x['path'] for x in files if not x['path'].endswith('.map')]
ps=subprocess.run(['ps','-axo','pid=,args='],capture_output=True,text=True)
active=[x for x in ps.stdout.splitlines() if any(p in x for p in images)]
lsof=subprocess.run(['/usr/sbin/lsof','-Fn',*images],capture_output=True,text=True)
assert not r.is_symlink() and not active and not lsof.stdout.strip()
inventory=dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=files,
 retained_objects=objects_retained,dsym=[str(x) for x in r.rglob('*.dSYM')],
 active_image_processes=active,lsof_stdout=lsof.stdout,lsof_exit=lsof.returncode,deleted=False,
 policy='Read-only inventory; root test.ps1 may delete only the exact reviewed image/map files. All source/objects/SDK retained.')
print(json.dumps(dict(map_audit=map_audit,inventory=inventory)))
'''
result=ssh(code,dict(remote=remote))
save('link-map-audit.json',result['map_audit']);save('cleanup-inventory.json',result['inventory'])
revision=P/'revisions/template-rank-first-red';revision.mkdir(parents=True,exist_ok=True)
for rel in ['src/compute_route_apple/apple_mature_float.cc']:
    old=P/'source'/rel;dest=revision/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    assert hashlib.sha256(old.read_bytes()).hexdigest()=='4ba4847d6e0ca73116684fbcfdf0f2bc08caab8de38ea52e6f6f5b5e6ea7feeb'
    shutil.copyfile(old,dest)
    b=(P/'before'/rel).read_text();after=Path(rel).read_text()
    (P/'semantic.diff').write_text(''.join(difflib.unified_diff(b.splitlines(True),after.splitlines(True),fromfile='before/'+rel,tofile=rel)))
sources=['include/hyle/compute/model_ops.h','src/compute_shader_shared/nvfp4_f32.h',
 'src/compute_route_apple/apple_mature_float.cc','src/compute_provider_native/torch_cpu_program.cc',
 'tests/compute_models/grouped_fp8_power2_fixture.h','tests/compute_models/fp8_scale_policy_fixture.h',
 'tests/graph_route_apple/fp8_scale_policy_test.cc','tests/graph_route_apple/CMakeLists.txt']
for rel in sources:
    q=P/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(rel,q)
audit=json.loads((P/'actual-dependencies-canonical-audit.json').read_text())
assert audit['drift_count']==0 and audit['translation_units']==3
freeze=dict(status='final_actual_3TU_source_and_complete_MMD_dependencies_equal_canonical',
 sources=[identity(x) for x in sources],source_snapshot='source/',actual_whole_dep_drift=0,
 canonical_dep_audit=identity(P/'actual-dependencies-canonical-audit.json'),
 reused_objects='All unchanged SDK and unaffected Hyle products reused. Only current newID2/3 actual extractors Apple mature_float and torch_cpu_program plus wrapper refreshed; no claim old entire model_ops.h bytes are current in unrelated retained objects.',
 historical_first_compile=identity(P/'mac/first-compile/results/compile-summary.json'))
save('source-freeze.json',freeze)
old=(P/'before/src/compute_route_apple/apple_mature_float.cc').read_text()
new=Path('src/compute_route_apple/apple_mature_float.cc').read_text()
body=lambda x:x[x.index('  auto shape = input.shape();',x.index('Quantized quantize(')):x.index('Quantized weight(')]
assert body(old)==body(new)
proof=json.loads((P/'old-math-preservation-proof.json').read_text())
proof.update(no_build_or_gpu=False,current_source=identity('src/compute_route_apple/apple_mature_float.cc'),
  first_compile_fix='Only RANK template argument received explicit int cast; numeric policy unchanged.')
save('old-math-preservation-proof.json',proof)
base=P/'mac/final/results';cases=[];submits=0;expected_failed=0
for c in E.parse(base/'tests.xml').findall('.//testcase'):
    assert not c.findall('failure') and not c.findall('skipped')
    prop={p.get('name'):p.get('value') for p in c.findall('properties/property')}
    count=int(prop.get('successful_submissions',prop.get('actual_submissions','0')))
    submits+=count;failures=int(prop.get('expected_failed_completions','0'));expected_failed+=failures
    cases.append(dict(name=c.get('classname')+'.'+c.get('name'),successful_submissions=count,
      expected_failed_completions=failures,properties=prop))
assert len(cases)==6 and submits==43 and expected_failed==2
validation=json.loads((base/'validation.json').read_text());assert validation['exit']==0 and validation['tests']==6 and not validation['failed'] and not validation['skipped']
final_compiles=json.loads((base/'compile-summary.json').read_text())['compiles']
assert len(final_compiles)==3 and all(c['exit']==0 and not c['source_drifts'] for c in final_compiles)
first_compiles=json.loads((P/'mac/first-compile/results/compile-summary.json').read_text())['compiles']
assert len(first_compiles)==3 and sum(c['exit']==0 for c in first_compiles)==2
final=dict(status='actual_Apple_scale_policy_6of6_PASS',tests=6,new_tests=4,neighbors=2,
 successful_submissions=43,new_successful_submissions=27,neighbor_successful_submissions=16,
 expected_failed_completions=2,failed=0,skipped=0,cases=cases,
 source_freeze=identity(P/'source-freeze.json'),hardware=identity(P/'mac/final/hardware.json'),
 run=json.loads((base/'run.result.json').read_text()),validation=validation,
 compile_summary=identity(base/'compile-summary.json'),first_compile_summary=identity(P/'mac/first-compile/results/compile-summary.json'),
 CXX_attempts=6,CXX_successful_attempts=5,CXX_failed_attempts=1,current_distinct_CXX_objects=3,
 SDK_jobs=0,NVCC_jobs=0,actual_whole_dep_drift=0,actual_dep_refs=audit['actual_dependency_references'],
 canonical_unique=audit['unique_canonical_files'],map_audit=identity(P/'link-map-audit.json'),
 build_history='Initial Apple TU failed only size_t RANK versus MLX int template argument. CPU/wrapper passed. After int fix the existing helper conservatively invalidated all3 by aggregate manifest SHA, so all3 were rebuilt; not falsely recorded as reused. No SDK or unrelated product job.',
 numeric_scope='New kMultiplyReciprocal branch: F32 rawbit absmax/floor -> strict mul F32 literal1/448 -> strict reciprocal -> strict activation multiply -> signed saturated F32 -> original MLX to_fp8. Original Divide/Power graph/math body text-identical. Original packed_fp8_dot accumulation/scales/outputcast preserved; sparse oracle data does not prove all possible F32 reduction trees.',
 source_role='Catalog30 fixed layer45 expert0 gate geometry BF16A[1,4096], original E4W[2048,4096]+F32SF[16,32], finite artificial bytes; not downloaded checkpoint, complete model, typed BF16 QDQ reader or AMD approximate rcpf bit contract.',
 resources={'source_original_carrier_bytes':8390656,'full_floating_weight_bank':False,
  'new_normalized_A_F32_bytes_source_role':16384,'new_A_E4_bytes_source_role':4096,'new_A_group_scale_F32_bytes_source_role':128,
  'dense_existing_SF_path':'Original weight() repeats stored SF over128 output channels before packed_fp8_dot. Source logical repeated scale is [1,2048,32,1] (262144B) versus stored [1,16,32] (2048B). This is a repeat graph node; no physical allocation count was measured.',
  'grouped_existing_SF_path':'compact_scales=true preserves [E,ceil(N/128),K/128,1]; dot reads column/128 and selected expert directly; W/SF do not expand per selected slot.',
  'shared_A':'Existing A=1 quantizes before slot broadcast; no S-fold A QDQ work introduced.',
  'lifetime':'Shared actual tests retain two slots/results across updates and invocation teardown, and verify last-ID failures/fresh recovery; original Program/Invocation/Completion paths.'},
 cleanup_inventory=identity(P/'cleanup-inventory.json'),no_deletion=True)
save('final-validation.json',final)
print(json.dumps(dict(source_freeze=identity(P/'source-freeze.json'),final_validation=identity(P/'final-validation.json'),
 cleanup_inventory=identity(P/'cleanup-inventory.json'),deletable_bytes=sum(x['bytes'] for x in result['inventory']['deletable_files']),
 tests=6,successful_submissions=43,expected_failed_completions=2,drift=0),indent=2))
