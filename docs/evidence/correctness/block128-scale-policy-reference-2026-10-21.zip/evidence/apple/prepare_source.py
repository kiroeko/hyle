from pathlib import Path
import hashlib,json
R=Path.cwd();P=R/'.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/apple'
rel='src/compute_route_apple/apple_mature_float.cc'
b=(R/rel).read_bytes()
assert hashlib.sha256(b).hexdigest()=='408ecad6e532a332c3de1211e5bb6bf5de5ac9e7d7be131870ced65d9ae12b06'
q=P/'before'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(P/'before.json').write_text(json.dumps(dict(path=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),
 phase='after approved global mechanical enum/field rename, before Apple semantic policy implementation'),indent=2)+'\n')
