import difflib
import hashlib
import json
import re
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[3]
stage = Path(__file__).resolve().parent
prior = root / '.scratch/architecture-refactor-2026-10-18/quark-fp8-side-2026-10-21/scale-policy'
pending = json.loads((prior / 'pending-source-freeze.json').read_text())
allocated = {row['before']['path']: row for row in pending['files']}
paths = subprocess.check_output(['rg', '-l', 'Float8ScaleRounding|scale_rounding',
    'include', 'src', 'tests', '-g', '*.h', '-g', '*.cc', '-g', '*.cu', '-g', '*.cpp'], cwd=root, text=True).splitlines()
paths = sorted({p.replace('\\', '/') for p in paths} | set(allocated))
records, patches = [], []
for name in paths:
    target = root / name
    before = target.read_bytes()
    snapshot = stage / 'before' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    assert not snapshot.exists(), name
    snapshot.write_bytes(before)
    if name in allocated:
        expected = allocated[name]
        assert hashlib.sha256(before).hexdigest() == expected['before']['sha256'], name
        after = (prior / 'pending' / name).read_bytes()
        assert hashlib.sha256(after).hexdigest() == expected['pending']['sha256'], name
    else:
        text = before.decode('utf-8')
        text = text.replace('Float8ScaleRounding', 'Float8ScalePolicy').replace('scale_rounding', 'scale_policy')
        text = text.replace('Float8ScalePolicy::kNone', 'Float8ScalePolicy::kDivide')
        # Change kNone only on aliases whose declaration names this enum.
        aliases = re.findall(r'using\s+(\w+)\s*=\s*(?:\w+::)*Float8ScalePolicy\s*;', text)
        for alias in aliases:
            text = text.replace(alias + '::kNone', alias + '::kDivide')
        after = text.encode('utf-8')
    target.write_bytes(after)
    dest = stage / 'mechanical-source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(after)
    record = {'path': name,
              'before': {'bytes': len(before), 'sha256': hashlib.sha256(before).hexdigest()},
              'after': {'bytes': len(after), 'sha256': hashlib.sha256(after).hexdigest()},
              'kind': 'approved public/CPU/schema semantic patch' if name in allocated else 'mechanical enum/field/value rename only'}
    records.append(record)
    patches.extend(difflib.unified_diff(before.decode().replace('\r\n', '\n').splitlines(True),
        after.decode().replace('\r\n', '\n').splitlines(True), fromfile='before/' + name, tofile='after/' + name))
check = subprocess.run(['rg', '-n', 'Float8ScaleRounding|scale_rounding', 'include', 'src', 'tests',
    '-g', '*.h', '-g', '*.cc', '-g', '*.cu', '-g', '*.cpp'], cwd=root, capture_output=True, text=True)
assert check.returncode == 1, check.stdout + check.stderr
(stage / 'mechanical-and-common.diff').write_text(''.join(patches), encoding='utf-8')
report = {'status': 'global mechanical migration plus approved public/CPU/schema patch applied; no build/GPU',
          'files': records, 'file_count': len(records), 'old_live_names_remaining': 0,
          'enum': 'Float8ScalePolicy:uint32 {kDivide=0,kPowerOfTwo=1,kMultiplyReciprocal=2}',
          'field': 'scale_policy', 'public_descriptor_bytes': 8,
          'public_operation_revisions': {'Float8BlockLinear': 2, 'GroupedFloat8Linear': 3},
          'private_pair': 'field/enum migrated; private operation ID intentionally still1 until CUDA semantic owner updates it',
          'scope': 'Only include/src/tests current source. Historical evidence/docs/.scratch were not rewritten.',
          'next': 'Backend semantic owners may now edit their assigned files. No compilation until all backend/fixture source freezes.'}
(stage / 'mechanical-source-freeze.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'file_count': len(records), 'old_live_names_remaining': 0,
                  'public': next(x for x in records if x['path'] == 'include/hyle/compute/model_ops.h')['after'],
                  'apple': next(x for x in records if x['path'] == 'src/compute_route_apple/apple_mature_float.cc')['after']}, indent=2))
