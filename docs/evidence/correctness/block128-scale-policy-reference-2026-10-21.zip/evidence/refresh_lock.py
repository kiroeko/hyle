"""Update only the two changed vendored records with the CMake tree algorithm."""
from pathlib import Path
import hashlib,json
Z=Path(__file__).resolve().parent
R=Z.parents[2]
def normalized(path):return path.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def sha(raw):return hashlib.sha256(raw).hexdigest()
lock=R/'cmake/HyleDependencyLock.json'
before=Z/'before/cmake/HyleDependencyLock.json'
before.parent.mkdir(parents=True,exist_ok=True)
if not before.exists():before.write_bytes(lock.read_bytes())
data=json.loads(lock.read_text('utf-8'))
updates=[]
for dependency in data['dependencies']:
    if dependency.get('name') not in ('sglang_activation','iree_vulkan_runtime_patches'):continue
    root=R/dependency['vendored']['path']
    paths=sorted((p for p in root.rglob('*') if p.is_file()),
                 key=lambda p:p.relative_to(root).as_posix())
    assert paths and not any(p.is_symlink() or '__pycache__' in p.parts for p in paths)
    manifest=''.join(p.relative_to(root).as_posix()+'|'+sha(normalized(p))+'\n' for p in paths)
    old=dependency['vendored']['tree_sha256']
    dependency['vendored']['tree_sha256']=sha(manifest.encode())
    for item in dependency['license']['files']:
        if item['root']=='hyle':item['sha256']=sha(normalized(R/item['path']))
    updates.append(dict(name=dependency['name'],before=old,after=dependency['vendored']['tree_sha256'],files=len(paths)))
assert len(updates)==2
lock.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
(Z/'lock-update.json').write_text(json.dumps(dict(updates=updates),indent=2)+'\n',encoding='utf-8')
print(json.dumps(updates))
