// Thin dispatch only: the original canonical Model and existing cases.
#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_e4_cache_case.h"
#include "tests/tools/qwen_sampling_budget_case.h"

int main(int argc, char **argv) {
  try {
    if (argc != 3) throw std::runtime_error("usage: cold_cases --e4-cpu|--e4-cuda|--sampling-budget INPUT");
    const std::string_view mode(argv[1]);
    if (mode == "--e4-cpu") return qwen_e4_cache_case::run(argv[2], {.primary = qwen35::BackendKind::kCpu});
    if (mode == "--e4-cuda") return qwen_e4_cache_case::run(argv[2], {.primary = qwen35::BackendKind::kCuda});
    if (mode == "--sampling-budget") return qwen_sampling_budget_case::run(argv[2]);
    throw std::runtime_error("unknown cold-shape case");
  } catch (const std::exception &error) {
    std::cerr << "cold-shape consumer: " << error.what() << '\n'; return 1;
  }
}
