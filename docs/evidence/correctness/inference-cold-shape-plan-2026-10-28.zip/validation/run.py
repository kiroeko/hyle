"""One host + five existing model cases. Root runs explicitly; no retries."""
from pathlib import Path
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('current_cold_shape_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
TINY = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
E4 = R / '.scratch/inference-e4-model-20261025/fixture-preparation/ct-e4-aa'
BUDGET = R / '.scratch/inference-e4-model-20261025/fixture-preparation/bf16-original'
PACKED_PARSER = R / '.scratch/inference-execution-preparation-20261028/parse.py'
ARMS = {
    'policy': dict(unit='policy', kind='policy', backend='host', fixture=None, args=[]),
    'packed-cpu': dict(unit='tiny', kind='packed', backend='cpu', fixture=TINY, args=['--cpu', str(TINY), '--mtp-packed-prefill']),
    'packed-cuda': dict(unit='tiny', kind='packed', backend='cuda', fixture=TINY, args=['--cuda', str(TINY), '--mtp-packed-prefill']),
    'e4-cpu': dict(unit='cases', kind='e4', backend='cpu', fixture=E4, args=['--e4-cpu', str(E4)]),
    'e4-cuda': dict(unit='cases', kind='e4', backend='cuda', fixture=E4, args=['--e4-cuda', str(E4)]),
    'sampling-budget-cpu': dict(unit='cases', kind='budget', backend='cpu', fixture=BUDGET, args=['--sampling-budget', str(BUDGET)]),
}


def prepare():
    b.b.plan()
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', helper=t.pin(__file__),
        packed_parser=t.pin(PACKED_PARSER), fixtures={name: t.pin(path / 'weights.tsv') for name, path in
            (('tiny', TINY), ('e4', E4), ('budget', BUDGET))},
        arms={name: dict(unit=row['unit'], kind=row['kind'], backend=row['backend'], args=row['args'],
            fixture=None if row['fixture'] is None else t.pin(row['fixture'] / 'weights.tsv'),
            output=str(W / 'runs' / name)) for name, row in ARMS.items()},
        order=list(ARMS), native_processes=6, host_processes=1, model_processes=5, automatic_retries=0,
        scope='Existing host policy9+6 groups, Tiny MTP-packed CPU/CUDA, original E4 CPU/CUDA and original ordinary sampling-budget CPU. No new model or injected native fault.'))
    print('PLANNED:policy,packed-cpu,packed-cuda,e4-cpu,e4-cuda,sampling-budget-cpu;0native')


def admission_facts(stderr):
    freezes = [dict(planned_shapes=int(a), capacity=int(z)) for a, z in re.findall(
        r'^cold_shape_plan planned_shapes=(\d+) extra_capacity=(\d+)$', stderr, re.M)]
    admissions = [dict(requests=int(a), tokens=int(z), role=int(c), retained=int(d), capacity=int(e), seconds=float(f))
        for a, z, c, d, e, f in re.findall(
        r'^cold_exact_admission requests=(\d+) T=(\d+) role=(\d+) retained=(\d+) limit=(\d+) seconds=([^\s]+)$', stderr, re.M)]
    assert all(v['retained'] <= v['capacity'] for v in admissions)
    return dict(freeze_records=freezes, successful_admission_records=admissions,
        successful_admission_log_count=len(admissions), last_retained=None if not admissions else admissions[-1]['retained'],
        last_capacity=None if not admissions else admissions[-1]['capacity'],
        reached_extra_capacity=any(v['retained'] == v['capacity'] for v in admissions),
        final_counters_directly_reported=False,
        scope='Actual complete stderr records; report JSON does not expose final admission/eviction counters. No native eviction/fault claim is inferred from the host policy hooks.')


def parse(name):
    row = ARMS[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json'); command = t.read(out / 'command.json'); as_run = t.read(out / 'as-run.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and process['timed_out'] is False
    assert process == as_run['process'] and command['command'] == [as_run['image']['path'], *row['args']]
    stdout = (out / 'stdout.log').read_text(encoding='utf-8-sig')
    stderr = (out / 'stderr.log').read_text(encoding='utf-8-sig')
    reports = [json.loads(line) for line in stdout.splitlines() if line.startswith('{')]
    stats = dict(status='PASS', name=name, backend=row['backend'], process=process,
        performance_claim=False, trained_quality_claim=False, native_failure_injected=False)
    if row['kind'] == 'policy':
        assert not reports
        assert 'prefill plan: 9 host contract groups passed; no model/device loaded' in stdout
        assert 'cold shape plan: 6 host contract groups passed; no model/device loaded' in stdout
        report = dict(status='PASS', host_contract_groups=15, original_prefill_groups=9, new_cold_shape_groups=6,
            scope='Policy hook exceptions/retire-before-erase/build rollback order only; no GPU failure or unretired native owner was injected.')
    else:
        assert len(reports) == 1
        report = reports[0]; assert report['status'] == 'PASS' and report['backend'] == row['backend']
        if row['kind'] == 'packed':
            spec = importlib.util.spec_from_file_location('original_packed_preparation_parser', PACKED_PARSER)
            parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
            parser.check_report(report, row['backend'], 'mtp-packed')
            checks = parser.state_rows(report, 'mtp-packed')
            stats.update(state_checks=len(checks), byte_equal_state_checks=sum(v['payloads_byte_equal'] for v in checks),
                original_GDN_absolute_budget=report['gdn_state_absolute_budget'],
                maximum_GDN_absolute_difference=max((d['maximum_absolute'] for v in checks for d in v['differences']), default=0))
        elif row['kind'] == 'e4':
            assert report['generated_AA_fixture'] is True and report['original_scale_roles'] == 4
            assert report['physical_row_bytes'] == 64 and report['activation'] == 'BF16'
            assert report['prefill_rows'] == 2 and report['decode_rows'] == 1
            for key in ('fork_equal', 'old_readers_unchanged', 'single_member_discard', 'all_cancel_abort',
                        'idle_shape_warmup', 'admission_in_step'): assert report[key] is True, key
            assert report['final_versions'] == 0 and report['model_quality'] is False and report['HTTP'] == 0
            facts = admission_facts(stderr); assert len(facts['freeze_records']) == 1
            assert facts['successful_admission_log_count'] == 2 and [v['tokens'] for v in facts['successful_admission_records']] == [3, 5]
            assert [v['retained'] for v in facts['successful_admission_records']] == [1, 2]
            assert all(v['capacity'] == facts['freeze_records'][0]['capacity'] for v in facts['successful_admission_records'])
            assert facts['last_retained'] < facts['last_capacity']
            facts.update(native_FIFO_eviction_exercised=False,
                explanation='Two successful extra admissions retained1 then2 below the frozen capacity; actual idle warmup/on-step admission/warm reuse ran, but not a full FIFO eviction.')
            stats['native_admission_scope'] = facts
        else:
            assert row['kind'] == 'budget' and report['ordinary'] is True and report['backend'] == 'cpu'
            for key in ('initial_rejection_atomic', 'same_request_cursor_retry', 'MAX_minus_1_quota_1',
                        'full_hit_request_cursor', 'later_head_budget', 'evicted_ledger_budget', 'state_only_no_draw',
                        'raw_draw_preflight', 'greedy_unchanged', 'pending_only_single_consumption'): assert report[key] is True, key
            assert report['final_versions'] == 0 and report['GPU'] is False and report['HTTP'] == 0
    t.save(out / 'report.json', report)
    stats.update(report=t.pin(out / 'report.json'), source_freeze=t.pin(W / 'final-source-freeze.json'))
    t.save(out / 'summary.json', stats)
    print('PASS', name, 'PID', process['pid'])


def run(name):
    assert name in ARMS
    b.b.validate(); plan = t.read(W / 'run-plan.json')
    t.exact(plan['helper']); t.exact(plan['packed_parser'])
    row = ARMS[name]; ready_path = W / f"ready-{row['unit']}.json"; ready = t.read(ready_path)
    t.exact(ready['image']); t.exact(ready['inputs'])
    if row['fixture'] is not None: t.exact(plan['arms'][name]['fixture'])
    out = W / 'runs' / name; assert not out.exists(), 'Never repeat a successful native process or overwrite an attempt'
    process = t.execute([ready['image']['path'], *row['args']], out, 300)
    t.save(out / 'as-run.json', dict(ready=t.pin(ready_path), image=ready['image'], inputs=ready['inputs'],
        source_freeze=ready['source_freeze'], run_plan=t.pin(W / 'run-plan.json'), process=process))
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
