"""Three explicit CXX/links, reusing original driver and ON227. Root executes.

prepare/freeze are metadata only. Host policy links its sole OBJ and CRT;
Tiny/cases each link ON227 plus the single respective consumer object.
"""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
OLD = R / '.scratch/inference-prepared-program-family-20261028/validation'
spec = importlib.util.spec_from_file_location('original_prepared_family_build', OLD / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.W = W; b.__file__ = __file__; t = b.t; t.W = W
b.SOURCES = dict(policy='tests/tools/inference_prefill_plan_test.cc',
    tiny='tests/tools/qwen_host_image_test.cc',
    cases=str((W / 'cold_cases.cc').relative_to(R)))
b.SNAPSHOTS = ('engine/models/qwen35/main.cc', 'engine/inference/cold_shape_plan.h',
    'tests/tools/inference_prefill_plan_test.cc', 'tests/tools/qwen_host_image_test.cc',
    'tests/tools/qwen_e4_cache_case.h', 'tests/tools/qwen_sampling_budget_case.h')


def prepare():
    product = t.read(W.parent / 'product-source-freeze.json')
    # Source identities are frozen only after root and the product agent stop edits.
    for row in product['sources']: t.exact(row)
    original = t.read(OLD / 'ready-tiny.json')
    on = t.read(b.ON / 'ready-resident-graph.json'); t.exact(on['inputs'])
    rows = t.read(on['inputs']['path']); assert len(rows) == 228
    replaced = on['compiled']['resident-graph']['object']; assert rows.count(replaced) == 1
    retained = [row for row in rows if row != replaced]; assert len(retained) == 227
    stats = []
    for row in retained:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    t.save(W / 'retained-input-stats.json', stats)
    before = t.command(original['compiled']['command']['path'])
    source_before = t.read(original['compiled']['dependencies']['path'])['Data']['Source']
    compile_recipes = {}; link_recipes = {}
    for name, source in b.SOURCES.items():
        if name == 'policy':
            args = [before[0], '/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus',
                '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/permissive-', '/W4', '/WX', '/DNOMINMAX',
                '/I' + str(R / 'include'), '/I' + str(R), str(R / source),
                '/sourceDependencies', str(W / f'compile/{name}/dependencies.json'),
                '/Fo' + str(W / f'compile/{name}/unit.obj'), '/Fd' + str(W / f'compile/{name}/unit.pdb')]
        else:
            args = []
            for index, arg in enumerate(before):
                if t.key(arg) == t.key(source_before): arg = str(R / source)
                elif index and before[index - 1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
                elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
                elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
                args.append(arg)
            assert '/DHYLE_COMPUTE_CPU=1' in args and '/DHYLE_COMPUTE_CUDA=1' in args
        path = W / f'recipes/{name}.json'; t.save(path, dict(command=args, timeout_seconds=300)); compile_recipes[name] = t.pin(path)
        before_link = t.command(on['recipe']['path'])
        if name == 'policy':
            link = [before_link[0], '/nologo', '/INCREMENTAL:NO', '/MACHINE:X64', '/OPT:REF', '/OPT:ICF',
                '/OUT:' + str(W / 'bin/policy.exe'), '/PDB:' + str(W / 'bin/policy.pdb'), str(W / 'compile/policy/unit.obj')]
            assert not any(arg.lower().endswith(('.lib', '.dll')) for arg in link)
        else:
            link = []
            for arg in before_link:
                if t.key(arg) == t.key(replaced['path']): arg = str(W / f'compile/{name}/unit.obj')
                for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                    if arg.upper().startswith(prefix): arg = prefix + str((W / f'bin/{name}').with_suffix(suffix)); break
                link.append(arg)
            assert sum(t.key(arg) == t.key(W / f'compile/{name}/unit.obj') for arg in link) == 1
        path = W / f'link-recipes/{name}.json'; t.save(path, dict(command=link, timeout_seconds=240)); link_recipes[name] = t.pin(path)
    env = t.read(b.ON / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=t.read(on['runtime']['path'])['native']))
    weights = next(row for row in retained if 'inference-mtp-e4-20261028' in row['path'] and 'compile\\weights\\unit.obj' in row['path'])
    t.save(W / 'final-build-plan.json', dict(baseline=t.pin(b.ON / 'ready-resident-graph.json'), inputs=on['inputs'],
        original_object=replaced, source_dependencies=original['compiled']['dependencies'], sources=b.SOURCES,
        original_driver=t.pin(R / '.scratch/inference-indexed-store-20261028/build.py'),
        reused_build_helper=t.pin(OLD / 'build.py'), compile_template=original['compiled']['command'],
        product_source_freeze=t.pin(W.parent / 'product-source-freeze.json'),
        environment=t.pin(W / 'environment.json'), retained_stats=t.pin(W / 'retained-input-stats.json'),
        runtime=t.pin(W / 'runtime.json'), recipes=compile_recipes, links=link_recipes, weights_retained=weights,
        counts=dict(CXX=3, links=3, host_policy_inputs=1, model_inputs_each=228, retained_SDK_weights=227,
                    host_native=1, model_native=5, SDK_CXX=0, NVCC=0, downloads=0),
        scope='Host policy uses CRT only. Tiny packed CPU/CUDA and original E4 CPU/CUDA plus original sampling-budget CPU share ON227, no historical source copies/SDK builds/downloads/new test assertions.'))
    print('PREPARED:freeze; compile policy|tiny|cases; link policy|tiny|cases; root owns all native')


def freeze():
    value = b.plan()
    t.exact(value['reused_build_helper']); t.exact(value['product_source_freeze'])
    for row in t.read(value['product_source_freeze']['path'])['sources']: t.exact(row)
    b.freeze()


def link_unit(name):
    assert name in b.SOURCES
    if name != 'policy': return b.link_unit(name)
    value, _ = b.validate(); compiled = t.read(W / 'compile/policy/compiled.json'); t.exact(compiled['object'])
    (W / 'bin').mkdir(exist_ok=True); t.save(W / 'inputs-policy.json', [compiled['object']])
    process = t.execute(t.command(value['links']['policy']['path']), W / 'links/policy', 240)
    t.save(W / 'ready-policy.json', dict(image=t.pin(W / 'bin/policy.exe'), inputs=t.pin(W / 'inputs-policy.json'),
        compiled=compiled, process=process, recipe=t.pin(W / 'links/policy/command.json'),
        source_freeze=t.pin(W / 'final-source-freeze.json'), runtime_scope='CRT only; no explicit SDK import/library input'))
    print('LINK PASS policy:one OBJ+implicit CRT only')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'preflight': b.validate()
    elif action == 'compile': b.compile_unit(sys.argv[2])
    elif action == 'parse-compile': b.parse_compile(sys.argv[2])
    elif action == 'link': link_unit(sys.argv[2])
    else: raise ValueError(action)
