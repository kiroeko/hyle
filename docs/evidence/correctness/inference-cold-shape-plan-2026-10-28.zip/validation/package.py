"""Lean offline evidence only. Root invokes after reviewing all six results."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
A = W.parent
R = Path('C:/public/project-hyle/hyle')
DEST = R / 'docs/evidence/correctness/inference-cold-shape-plan-2026-10-28'
UNITS = ('policy', 'tiny', 'cases')
CASES = ('policy', 'packed-cpu', 'packed-cuda', 'e4-cpu', 'e4-cuda', 'sampling-budget-cpu')


def read(path): return json.loads(Path(path).read_bytes())
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def terminal(process):
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and process['timed_out'] is False, process


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Never overwrite evidence'
    plan = read(W / 'final-build-plan.json'); frozen = read(W / 'final-source-freeze.json'); runs = read(W / 'run-plan.json')
    assert plan['counts']['CXX'] == plan['counts']['links'] == 3
    assert plan['counts']['SDK_CXX'] == plan['counts']['NVCC'] == plan['counts']['downloads'] == 0
    assert runs['native_processes'] == 6 and runs['model_processes'] == 5 and runs['host_processes'] == 1
    assert set(runs['arms']) == set(CASES)
    for row in (frozen['helper'], frozen['expected'], frozen['dependencies'], runs['helper'], runs['packed_parser'],
                plan['reused_build_helper'], plan['product_source_freeze']): exact(row)
    for row in runs['fixtures'].values(): exact(row)
    archive = {}
    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert name not in archive and path.suffix.lower() not in ('.exe', '.obj', '.dll', '.lib', '.pdb', '.bf16', '.f32', '.bin', '.gguf', '.safetensors')
        archive[name] = path.read_bytes()
    for name in ('build.py', 'run.py', 'package.py', 'cold_cases.cc', 'run-plan.json', 'final-build-plan.json',
                 'final-source-freeze.json', 'expected-sources.json', 'frozen-project-dependencies.json',
                 'retained-input-stats.json', 'runtime.json'):
        add(W / name)
    add(A / 'changes.patch', 'source/changes.patch')
    add(A / 'product-source-freeze.json', 'source/product-source-freeze.json')
    add(plan['reused_build_helper']['path'], 'helpers/reused-prepared-family-build.py')
    add(plan['original_driver']['path'], 'helpers/original-windows-driver.py')
    add(runs['packed_parser']['path'], 'helpers/original-packed-parser.py')
    archive['identity/fixture-manifests.json'] = encoded(dict(fixtures=runs['fixtures'], fixture_bodies_included=False))
    sources = []
    for item in frozen['snapshots']:
        exact(item['original']); exact(item['snapshot'])
        relative = Path(item['original']['path']).relative_to(R).as_posix()
        name = 'source/cold_cases.cc' if relative.endswith('/validation/cold_cases.cc') else 'source/' + relative
        add(item['snapshot']['path'], name)
        sources.append(dict(relative_path=relative, identity=item['original']))
    ggml_header = R / 'include/hyle/compute/providers/ggml_cuda.h'
    add(ggml_header, 'source/include/hyle/compute/providers/ggml_cuda.h')
    add(W / 'package-attempt1.py')
    base = read(plan['inputs']['path']); assert len(base) == 228 and base.count(plan['original_object']) == 1
    archive['identity/base-model-link-inputs.json'] = encoded(base)
    builds = []
    for unit in UNITS:
        ready = read(W / f'ready-{unit}.json'); compiled = read(W / f'compile/{unit}/compiled.json')
        cxx = read(W / f'logs/{unit}/process.json'); link = read(W / f'links/{unit}/process.json')
        terminal(cxx); terminal(link)
        assert ready['compiled'] == compiled and compiled['process'] == cxx and ready['process'] == link
        exact(ready['inputs']); exact(ready['recipe']); exact(ready['source_freeze'])
        for key in ('command', 'dependencies', 'actual_dependencies'): exact(compiled[key])
        actual_inputs = read(ready['inputs']['path'])
        if unit == 'policy':
            assert actual_inputs == [compiled['object']]
            argv = read(ready['recipe']['path'])['command']
            assert not any(arg.lower().endswith(('.lib', '.dll')) for arg in argv)
            scope = 'One actual host policy object plus implicit CRT; no SDK input.'
        else:
            assert len(actual_inputs) == 228
            assert [(a, b) for a, b in zip(base, actual_inputs) if a != b] == [(plan['original_object'], compiled['object'])]
            scope = 'ON227 SDK/weights retained, one consumer object; no SDK recompilation.'
        builds.append(dict(unit=unit, compile_process=cxx, link_process=link, image=ready['image'],
            source=compiled['source'], compiled=compiled, inputs=ready['inputs'], input_count=len(actual_inputs), scope=scope))
        for name in (f'ready-{unit}.json', f'inputs-{unit}.json', f'recipes/{unit}.json', f'link-recipes/{unit}.json',
                     f'compile/{unit}/compiled.json', f'compile/{unit}/dependencies.json', f'compile/{unit}/actual-dependencies.json'):
            add(W / name)
        for category in ('logs', 'links'):
            for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(W / category / unit / name)
    cases = []; e4 = []; packed = []
    for name in CASES:
        directory = W / 'runs' / name; summary = read(directory / 'summary.json')
        process = read(directory / 'process.json'); command = read(directory / 'command.json'); as_run = read(directory / 'as-run.json')
        terminal(process)
        assert summary['status'] == 'PASS' and summary['name'] == name and summary['process'] == process == as_run['process']
        assert summary['performance_claim'] is False and summary['trained_quality_claim'] is False and summary['native_failure_injected'] is False
        exact(summary['report']); exact(summary['source_freeze']); exact(as_run['ready'])
        assert command['command'] == [as_run['image']['path'], *runs['arms'][name]['args']]
        report = read(summary['report']['path'])
        if name == 'policy':
            assert report['host_contract_groups'] == 15 and report['original_prefill_groups'] == 9 and report['new_cold_shape_groups'] == 6
        elif name.startswith('e4'):
            facts = summary['native_admission_scope']
            assert facts['successful_admission_log_count'] == 2 and facts['last_retained'] == 2 and facts['last_capacity'] == 4
            assert facts['native_FIFO_eviction_exercised'] is False and facts['final_counters_directly_reported'] is False
            e4.append(dict(case=name, **facts))
        elif name.startswith('packed'):
            assert summary['state_checks'] == 7 and summary['byte_equal_state_checks'] == 0
            assert summary['original_GDN_absolute_budget'] == 0.000003
            assert summary['maximum_GDN_absolute_difference'] <= summary['original_GDN_absolute_budget']
            packed.append(summary)
        cases.append(dict(name=name, backend=summary['backend'], process=process, report=summary['report']))
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'as-run.json', 'report.json', 'summary.json'):
            add(directory / filename)
    assert len(cases) == len({(v['process']['pid'], v['process']['started']) for v in cases}) == 6
    assert len(packed) == len(e4) == 2
    manifest = encoded(dict(members=[dict(name=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(archive.items())],
                            self_hash='External JSON archive.manifest_sha256'))
    archive['MANIFEST.json'] = manifest
    outzip, outjson = DEST.with_suffix('.zip'), DEST.with_suffix('.json')
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(archive.items()): z.writestr(name, raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, raw in archive.items(): assert sha(z.read(name)) == sha(raw), name
    result = dict(schema='hyle.correctness.cold-shape-plan.v1', date='2026-10-28', status='PASS_HOST_POLICY_AND_FIVE_FINITE_MODEL_CASES',
        change='Share checked cold usage counts, frozen extra-shape capacity, FIFO admission bookkeeping and rollback ordering in ColdShapePlan. Model retains actual native retirement/Family construction hooks.',
        counts=dict(CXX=3, links=3, host_processes=1, model_processes=5, total_native_processes=6, SDK_CXX=0, NVCC=0, downloads=0, native_retries=0),
        builds=builds, cases=cases, sources=sources, product_diff=pin(A / 'changes.patch'),
        ggml_cuda_header=dict(identity=pin(ggml_header), compiled_through_these_consumers=False,
            frozen_dependency_of_these_consumers=False,
            scope='Static comment-only correction included as source body. Root checked the Git diff is comments only; this header is outside the actual canonical ColdShapePlan/Tiny include closure and was not compiled through these consumers.'),
        package_metadata_amendment=dict(original_exception="KeyError: ggml_cuda.h absent from frozen project dependencies",
            preserved_helper=pin(W / 'package-attempt1.py'), native_retries=0, compiler_retries=0,
            correction='Remove false include-closure assertion; preserve original source freeze/build receipts and label the header static-only. First attempt failed before creating ZIP/JSON.'),
        host_policy=dict(original_prefill_groups=9, new_cold_shape_groups=6,
            scope='Real host executable checks count/overflow/freeze/duplicate/FIFO and retire-before-erase/build rollback hooks. Hook exceptions are synthetic policy checks, not injected GPU retirement or native construction failures.'),
        native_E4=e4,
        numerical=dict(packed_state_checks=14, packed_full_payload_byte_equal_checks=0,
            original_GDN_absolute_budget=0.000003,
            maximum_GDN_absolute_difference=max(v['maximum_GDN_absolute_difference'] for v in packed),
            scope='Original exact-versus-packed comparisons retain newly computed F32 GDN differences within3e-6; maximum9.31323e-10. Other original boundary/epoch/RNG/old-checkpoint assertions stay strict. No new tolerance.'),
        sampling_budget_scope='Original CPU ordinary sampling cursor rejection/atomic retry/state-only/no-draw/greedy and pending-only cases, unchanged model oracle.',
        preparation_scope_amendment='The build plan phrase no new test assertions refers only to existing model consumers. Host inference_prefill_plan_test.cc actually adds six policy groups, explicitly compiled and run here.',
        limitations=['Native E4 CPU/CUDA each successfully admitted T3 then T5, retained1 then2 below capacity4: idle warmup, in-step admission and warm reuse ran, but no native FIFO eviction was exercised. Final counters were not directly reported; raw admission logs are preserved.',
            'Original mathematical recipes, actual native owners/retirement hooks and hot map lookup remain with their prior contracts. This evidence contains no throughput measurement or speedup conclusion.',
            'Finite cached synthetic/calibration fixtures; no trained-model quality or exhaustive platform/function proof.',
            'This slice shares a cold policy algorithm; it does not finish extraction of the complete Model/inference architecture.',
            'Only required source/diff, metadata identities, actual recipes and raw six process results are archived; SDK, executable/object, model and tensor bodies are excluded.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', all_member_SHA256='PASS'))
    with outjson.open('xb') as stream: stream.write(encoded(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', all_member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as stream: stream.write(encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
