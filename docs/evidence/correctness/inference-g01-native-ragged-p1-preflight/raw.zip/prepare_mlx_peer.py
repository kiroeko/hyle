import subprocess
body='''from pathlib import Path
import subprocess
peer=Path('/Users/kiro/hyle-scratch/compute-unified/g01-original-mlx-peer')
pin='1f8e74e3f12f31365464a6867c6579f0e9b29d85'
if not(peer/'.git').exists():
 peer.mkdir(exist_ok=True)
 subprocess.run(['git','init',str(peer)],check=True)
 subprocess.run(['git','-C',str(peer),'remote','add','origin','https://github.com/ml-explore/mlx.git'],check=True)
 subprocess.run(['git','-C',str(peer),'fetch','--depth','1','origin',pin],check=True)
 subprocess.run(['git','-C',str(peer),'checkout','--detach',pin],check=True)
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()==pin
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
print('authenticated original MLX peer pin clean')
'''
subprocess.run(['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15','kiro@172.22.10.198','/usr/bin/python3 -'],input=body,text=True,check=True)
