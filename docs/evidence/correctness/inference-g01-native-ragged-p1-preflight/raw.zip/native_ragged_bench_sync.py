from pathlib import Path
import subprocess,tarfile,json,hashlib
root=Path.cwd();out=root/'.scratch/inference-gaps/g01';names=['bench/nanobench_impl.cc',*[f'bench/inference_resident_sdpa/{name}' for name in ['native_ragged_bench.cc','native_ragged_reference.cc','native_ragged_reference.h','apple_ragged_reference.cc','apple_ragged_reference.h','reference.cc','reference.h','reference_shaders.py']],'bench/common/perf_process.h']
archive=out/'native-ragged-bench-inputs.tar';manifest={'phase':'diagnostic preflight not qualified','source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':[{'path':n,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()} for n in names]}
with tarfile.open(archive,'w') as t:
 for n in names:t.add(root/n,arcname=n,recursive=False)
(out/'native-ragged-bench-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['scp',str(archive),'kiro@172.22.10.198:/Users/kiro/hyle-scratch/compute-unified/native-ragged-bench-inputs.tar'],check=True)
body='''from pathlib import Path
import tarfile
root=Path('/Users/kiro/hyle-scratch/compute-unified/source-c8874688');assert root.is_dir() and not(root/'.git').exists()
with tarfile.open(root.parent/'native-ragged-bench-inputs.tar') as t:
 for entry in t.getmembers():
  assert entry.isfile() and entry.name.startswith('bench/') and '..' not in Path(entry.name).parts
  p=root/entry.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(entry).read())
print('oneway private bench inputs copied into disposable validation source')
'''
subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -'],input=body,text=True,check=True)
