from pathlib import Path
import json,hashlib
root=Path.cwd();base=root/'bench/inference_resident_sdpa';original=json.loads((base/'contract.json').read_text())
cases=[([1,17],[1024,768],256,True),([64,128],[1024,768],256,True),([1,17],[31,47],64,False)]
ids=['mixed-d256','prefill-d256','holdout-d64']
for route in ['apple','vulkan']:
 dst=base/f'{route}_ragged_p1';label=route.title();old=json.dumps(original)
 replacements={'g01_resident_bench':'g01_native_ragged_bench','g01_perf_control':'g01_native_ragged_control','resident-aa':'native-ragged-aa','resident-decode-d256':'ragged-mixed-d256','resident-prefill-d256':'ragged-prefill-d256','resident-holdout-d64':'ragged-holdout-d64','# HYLE_RESIDENT_RUN ':'# HYLE_NATIVE_RAGGED_RUN '}
 for a,b in replacements.items():old=old.replace(a,b)
 d=json.loads(old);d['id']=f'inference-native-ragged-{route}-m1-p1-v1';d['module']='compute_route_'+route
 d['claim']=f'Finite {label} F16 packed NHD two-request ragged mixed decode/prefill, long prefill and noncausal holdout through the original native Program/Invocation/input owners/Completion/output result ownership versus independent original math, same one packed output. Actual Mac16,12 engineering only; not full G01 or token/s.'
 d['candidate'].update(component='compute_route_'+route,entrypoint='../native_ragged_bench.cc')
 peer_id='original-mlx-fast-sdpa' if route=='apple' else 'original-ggml-flash'
 pin='1f8e74e3f12f31365464a6867c6579f0e9b29d85' if route=='apple' else '456172ec733a135778adcd32d00e576a58232e45'
 d['peers']=[{'id':peer_id,'revision':pin,'configuration':{'delivery_shape':'source','role':'original MLX fast SDPA directly through the same original Program/Invocation lifecycle' if route=='apple' else 'independent original full-F32 flash shader recipes per request aggregated into one original Program; original tuning/mask/split-K preserved','precision':'F16 Q/K/V/output, original math precision; same causal and GQA','scope':'two-request packed NHD resident capacity, one packed output, two independent slots; native private storage UNKNOWN'}}]
 provenance={'kind':'PROVISIONAL_ARCHETYPE','consumer':'single-machine two-request full attention, Qwen3.5-2B GQA8/2 D256 plus noncausal D64 holdout','product_candidate':'280f6f92ea97bf3b424113346f0264fb7b20df16','backend':route,'actual_dtype':'F16 storage, original backend math','cases':[{'q':q,'kv':k,'d':depth,'causal':causal,'hq':8,'hkv':2,'requests':2,'capacity_tail':13} for q,k,depth,causal in cases],'model_scope_path':'docs/implementation/tasks/project/qwen35-2b-command-consumer-scope-2026-10.md','model_scope_sha256':hashlib.sha256((root/'docs/implementation/tasks/project/qwen35-2b-command-consumer-scope-2026-10.md').read_bytes()).hexdigest(),'whole_model_claim':False}
 (dst/'consumer-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');sha=hashlib.sha256((dst/'consumer-provenance.json').read_bytes()).hexdigest()
 for row,key,(q,k,depth,causal) in zip(d['workloads'],ids,cases):
  row['id']='ragged-'+key;row['consumer_key']=f'inference-native-ragged-{route}/'+row['id'];row['provenance']={'path':'consumer-provenance.json','sha256':sha};row['peer_id']=peer_id
  row['ownership_topology']={'candidate':'original native Program/Invocation, two slots, ready packed-capacity Q/K/V owners and one packed active output','peer':'same original native Program/Invocation/input owner/Completion/result return with independent original math','equivalence':'same ready bytes/capacity/lengths/GQA/causal/F16 output, two slots, independent contexts and checked completion with result/input owners retained'}
  row['semantic_contract']=f'F16 packed NHD requests2 GQA8/2 Q{q} KV{k} D{depth} causal={causal}, capacity tail13; all active packed outputs, original math, ready bind/checked completion/result owner release'
  row['material_contribution'].update(unit='complete-two-request-attention',denominator='one two-request episode through original checked completion and packed result owner return')
  row['input'].update(distribution='full-index deterministic powers-of-two finite F16, unused capacity sentinel128; independent double oracle absolute bound2e-3 and readonly/finite checks',scale={'query_rows':q,'key_rows':k,'depth':depth,'heads':8,'kv_heads':2,'requests':2})
  row['setup']='cold original compile/slot and resident input upload, independent double oracle/readonly/tail, four warm complete episodes per arm; private native storage upper UNKNOWN'
  row['charged_phases']=['original bind/output admission','all warm original native query/mask/SDPA/output conversion, request joining and runtime temporary allocation work','native submit, checked completion and one packed result owner return/release']
  row['pair']={'candidate':f'HYLE {label} ragged','peer':f'Original {label} ragged lifecycle'}
 runner=d['extensions']['runner'];runner['cmake']['cache']['HYLE_COMPUTE_ROUTES']=route
 runner['cmake']['peer_cache']={peer_id:'HYLE_MLX_ORIGINAL_REFERENCE_SOURCE' if route=='apple' else 'HYLE_RESIDENT_REFERENCE_SOURCE'}
 if route=='apple':runner['cmake']['cache'].pop('HYLE_RESIDENT_GLSLANG',None)
 for executable in runner['executables']:
  executable['id']=executable['id'].replace('resident','ragged')
  for workload,key,(q,k,depth,causal) in zip(executable['workloads'],ids,cases):workload.update(id='ragged-'+key,title=f'{label} ragged F16 Q={q[0]},{q[1]} KV={k[0]},{k[1]} D={depth} causal={int(causal)}')
 d['extensions']['measurement_recipe']={'paired_rounds':16,'minimum_epoch_iterations':1,'minimum_epoch_time_ms':4,'preflight_only':True,'reason':'fixed before qualified product sampling; double oracle and complete native ownership charged, original n15/31 and5% margin unchanged'}
 (dst/'contract.json').write_text(json.dumps(d,indent=2)+'\n')
 v=(base/'validate_aa.py').read_text();v=v.replace('parents[2]','parents[3]')
 for a,b in replacements.items():v=v.replace(a,b)
 v=v.replace("CASES = ((1, 1024, 256, 1), (128, 1024, 256, 1), (17, 257, 64, 0))","CASES = ((1, 17, 1024, 768, 256, 1), (64, 128, 1024, 768, 256, 1), (1, 17, 31, 47, 64, 0))")
 a=v.index('    generated = build /');b=v.index('    receipt_path =',a)
 block="    identity = {'artifacts': artifacts, 'validator': digest(Path(__file__)), 'machine': gate['physical_host_identity']}\n"
 if route=='vulkan':block+="    generated = build/'reference-shaders'\n    identity['original_shader_identity'] = digest(generated/'identity.json')\n    identity['generated_spirv'] = digest(generated/'reference_spirv.h')\n    shader_record = json.loads((generated/'identity.json').read_text())\n    if shader_record['revision'] != PIN: raise RuntimeError('wrong shader pin')\n    for shader in shader_record['outputs']:\n        if digest(generated/(shader['name']+'.spv')) != shader['sha256']: raise RuntimeError('original shader changed')\n"
 v=v[:a]+block+v[b:]
 v=v.replace("facts = [line for line in text.splitlines() if line.startswith('# RESIDENT_ENV ')]","facts = [line for line in text.splitlines() if line.startswith('# NATIVE_RAGGED_ENV ')]")
 start=v.index('                    if len(facts)');end=v.index('                    if environment_fact',start)
 required='device=Apple M4'
 check=f"                    if len(facts) != 6 or len(set(facts)) != 1 or '{required}' not in facts[0] or 'backend={label}' not in facts[0] or '{pin[:8]}' not in facts[0]:\n                        raise RuntimeError('actual native device/library facts missing or inconsistent')\n"
 v=v[:start]+check+v[end:]
 v=v.replace("'placement': '1' if variant == 'placement' else '0'}",f"'placement': '1' if variant == 'placement' else '0', 'backend': '{label}', 'paired_rounds': '16'}}")
 v=v.replace('for q, kv, d, causal in CASES:', 'for q1, q2, k1, k2, d, causal in CASES:')
 v=v.replace("title = f'Resident SDPA Q={q} KV={kv} D={d} causal={causal}'",f"title = f'{label} ragged F16 Q={{q1}},{{q2}} KV={{k1}},{{k2}} D={{d}} causal={{causal}}'")
 v=v.replace("'HYLE resident', 'Original flash lifecycle'",f"'HYLE {label} ragged', 'Original {label} ragged lifecycle'")
 v=v.replace('g01_resident_aa.ready','g01_native_ragged_aa.ready')
 if route=='apple':
  v=v.replace("PIN = '456172ec733a135778adcd32d00e576a58232e45'",f"PIN = '{pin}'")
  v=v.replace("'machine': gate['physical_host_identity']}","'machine': gate['physical_host_identity'], 'original_mlx_identity': digest(build/'mlx-peer-identity.json')}")
 (dst/'validate_aa.py').write_text(v)
print('native two-route contracts and unchanged-policy AA adapters generated; not qualified')
