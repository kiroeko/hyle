from pathlib import Path
import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path.cwd()
base = root / '.scratch/inference-gaps/g02'
out = base / 'vulkan-rope-reduction-diagnostic'
build = Path('C:/h7/inference-g02-impacted')
assert not (out / 'result.json').exists()
row = json.loads((out / 'compile-row.json').read_text())
source = Path(row['file'])
normal_dll = build / 'bin/hyle_compute_provider_ggml_vulkan.dll'
normal_exe = build / 'bin/hyle_graph_route_vulkan_test.exe'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

record = {
    'state': 'SETUP',
    'scope': 'Scratch-only split 2pi/FMA reduction for original sin_f32/cos_f32 shader arrays; no normal source, artifact, oracle or tolerance change; same failed public case.',
    'source_sha256': sha(source),
    'normal_dll_sha256': sha(normal_dll),
    'normal_exe_sha256': sha(normal_exe),
    'stages': [],
}

def save():
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')

save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
shell32 = ctypes.WinDLL('shell32', use_last_error=True)
shell32.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
shell32.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
kernel32.LocalFree.argtypes = [ctypes.c_void_p]
kernel32.LocalFree.restype = ctypes.c_void_p

def argv(command):
    count = ctypes.c_int()
    pointer = shell32.CommandLineToArgvW(command, ctypes.byref(count))
    assert pointer
    try:
        return [pointer[i] for i in range(count.value)]
    finally:
        kernel32.LocalFree(pointer)

env = {k.upper(): v for k, v in os.environ.items()}
for line in subprocess.check_output(['cmd', '/d', '/c', str(base / 'resume-windows-2/vs-env.cmd')], text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value
env['PATH'] = str(build / 'bin') + os.pathsep + env['PATH']
env['HYLE_D5_QWEN35_FIXTURE'] = json.loads((base / 'current-model-fixture.json').read_text())['root']

def run(stage, args):
    start = time.monotonic()
    with (out / (stage + '.log')).open('w') as log:
        child = subprocess.Popen(args, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT,
                                 creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        record.update(state='RUNNING', stage=stage, pid=child.pid)
        save()
        print(stage, child.pid, flush=True)
        code = child.wait()
    record['stages'].append({'stage': stage, 'command': args, 'exit_code': code,
                             'elapsed_seconds': time.monotonic() - start})
    save()
    return code

import re
import struct
from decimal import Decimal

shader_dir = build / 'src/compute_ggml_runtime/source-ada61b1e5d25c18c/src/ggml-vulkan/vulkan-shaders'
generated = build / 'src/compute_ggml_runtime/vendor/src/ggml-vulkan/unary.comp.cpp'
shader = out / 'unary.comp'
original_shader = (shader_dir / 'unary.comp').read_text(encoding='utf-8')
two_pi = Decimal('6.2831853071795864769252867665590057683943387987502')
high = Decimal('6.28125')
low = struct.unpack('f', struct.pack('f', float(two_pi - high)))[0]
tail = float(two_pi - high - Decimal(low))
reduction = '''float hyle_reduce_phase(float x) {
    // Finite inference phase domain, with a split 2pi and explicit FMA.
    if (abs(x) > 1048576.0f || isnan(x) || isinf(x)) return x;
    const float turns = roundEven(x * 0.15915494309189533577f);
    precise float reduced = fma(-turns, 6.28125f, x);
    reduced = fma(-turns, LOW, reduced);
    return fma(-turns, TAIL, reduced);
}

'''.replace('LOW', format(low, '.18g') + 'f').replace('TAIL', format(tail, '.18g') + 'f')
needle = 'float op_sin(float x) {\n    return sin(x);\n}\n\nfloat op_cos(float x) {\n    return cos(x);\n}'
assert original_shader.count(needle) == 1
shader.write_text(original_shader.replace(needle, reduction +
    'float op_sin(float x) {\n    return x == 0.0f ? x : sin(hyle_reduce_phase(x));\n}\n\n'
    'float op_cos(float x) {\n    return cos(hyle_reduce_phase(x));\n}'), encoding='utf-8')
cpp_text = generated.read_text()
glslc = 'C:/public/tools/hyle-vulkan/1.4.357.0/Bin/glslc.exe'
for operation in ['sin', 'cos']:
    spv = out / (operation + '.spv')
    code = run(operation + '-shader', [glslc, '-fshader-stage=compute', '--target-env=vulkan1.2',
         '-O', '-I' + str(shader_dir), '-DA_TYPE=float', '-DD_TYPE=float', '-DOP=op_' + operation,
         str(shader), '-o', str(spv)])
    if code:
        record['state'] = 'TERMINAL_SETUP_FAIL'; save(); raise SystemExit(code)
    data = spv.read_bytes()
    name = operation + '_f32'
    pattern = r'const uint64_t ' + name + r'_len = \d+;\s*const unsigned char ' + name + r'_data\[\d+\] = \{.*?\};'
    assert len(re.findall(pattern, cpp_text, re.S)) == 1
    byte_text = ','.join(hex(byte) for byte in data)
    cpp_text = re.sub(pattern, f'const uint64_t {name}_len = {len(data)};\nconst unsigned char {name}_data[{len(data)}] = {{' + byte_text + '};', cpp_text, flags=re.S)
cpp = out / 'unary-diagnostic.cpp'
cpp.write_text(cpp_text)
rows = json.loads((build / 'compile_commands.json').read_text())
shader_row = next(r for r in rows if Path(r['file']) == generated)
(out / 'shader-compile-row.json').write_text(json.dumps(shader_row, indent=2))
args = argv(shader_row['command'])
index = next(i for i, value in enumerate(args) if value.replace('\\', '/') == str(generated).replace('\\', '/'))
args[index] = str(cpp)
obj = out / 'unary-diagnostic.obj'
for i, value in enumerate(args):
    if value.startswith('/Fo'): args[i] = '/Fo' + str(obj)
    if value.startswith('/Fd'): args[i] = '/Fd' + str(out / 'shader.pdb')
if run('compile', args):
    record['state'] = 'TERMINAL_SETUP_FAIL'; save(); raise SystemExit(1)
link = (out / 'original-link-command.txt').read_text().strip()
args = argv(link[link.index('&& "') + 3:].rsplit(' && cd .', 1)[0])
assert args[1:3] == ['-E', 'vs_link_dll']
args.insert(args.index('/nologo'), str(obj))
binary_dir = out / 'bin'; binary_dir.mkdir()
binary = binary_dir / normal_dll.name
for i, value in enumerate(args):
    if value.startswith('--intdir='): args[i] = '--intdir=' + str(out / 'link')
    if value.lower().startswith('/out:'): args[i] = '/out:' + str(binary)
    if value.lower().startswith('/implib:'): args[i] = '/implib:' + str(out / 'diagnostic.lib')
    if value.lower().startswith('/pdb:'): args[i] = '/pdb:' + str(out / 'diagnostic.pdb')
(out / 'link').mkdir()
if run('link', args):
    record['state'] = 'TERMINAL_SETUP_FAIL'; save(); raise SystemExit(1)
shutil.copy2(normal_exe, binary_dir / normal_exe.name)
code = run('graph', [str(binary_dir / normal_exe.name), '--gtest_filter=VulkanGraphMoeFragments.D5DeepSeekFullAttentionChain',
    '--gtest_color=no', '--gtest_output=xml:' + str(out / 'graph.xml')])
phase_exe = build / 'bin/g02_vulkan_rope_phase_diagnostic.exe'
shutil.copy2(phase_exe, binary_dir / phase_exe.name)
phase_code = run('phase', [str(binary_dir / phase_exe.name), '--gtest_filter=G02PhaseDiagnostic.ActualExplicitF32RotaryAtConsumerPositions', '--gtest_color=no'])
assert sha(source) == record['source_sha256']
assert sha(normal_dll) == record['normal_dll_sha256']
assert sha(normal_exe) == record['normal_exe_sha256']
record.update(state='TERMINAL_DIAGNOSTIC_PASS' if code == 0 and phase_code == 0 else 'TERMINAL_DIAGNOSTIC_FAIL',
              diagnostic_dll_sha256=sha(binary), split_constants={'high':str(high),'low':low,'tail':tail},
              shader_before_sha256=sha(shader_dir / 'unary.comp'), shader_after_sha256=sha(shader))
save()
for name in ['graph', 'phase']:
    raw = (out / (name + '.log')).read_text(errors='replace')
    print('\n'.join(line for line in raw.splitlines() if 'G02_PHASE' in line or 'PASSED' in line or 'FAILED' in line), flush=True)

