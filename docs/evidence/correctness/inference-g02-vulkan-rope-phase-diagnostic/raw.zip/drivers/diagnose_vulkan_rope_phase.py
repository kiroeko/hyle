from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,time

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';out=base/'vulkan-rope-phase-diagnostic';build=Path('C:/h7/inference-g02-impacted')
old=json.loads((base/'remaining-windows-cases-1/vulkan/result.json').read_text());assert old['state']=='TERMINAL_FAIL' and len(old['cases'])==79
assert not (out/'result.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'state':'SETUP','scope':'One selected failed Graph fixture; scratch-only copy retains original independent F32 oracle and its stricter8e-5+4e-5 gate, prints F32/oldF16 differences. Product, original test source, oracles, shapes and normal executable unchanged. No product verdict from this diagnostic alone.','stages':[]}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
shell32=ctypes.WinDLL('shell32',use_last_error=True)
shell32.CommandLineToArgvW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
shell32.CommandLineToArgvW.restype=ctypes.POINTER(ctypes.c_wchar_p)
kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
kernel32.LocalFree.argtypes=[ctypes.c_void_p];kernel32.LocalFree.restype=ctypes.c_void_p
def argv(s):
 count=ctypes.c_int();pointer=shell32.CommandLineToArgvW(s,ctypes.byref(count));assert pointer
 try:return [pointer[i] for i in range(count.value)]
 finally:kernel32.LocalFree(pointer)
row=json.loads((out/'compile-row.json').read_text());source=Path(row['file']);cpp=out/'diagnostic.cc';obj=out/'diagnostic.obj'
s=source.read_text(encoding='utf-8');cpp.write_text('#include <cstdio>\n'+s+'\nTEST(G02PhaseDiagnostic, ActualExplicitF32RotaryAtConsumerPositions) {\n  using namespace vulkan_gate_norm_test;\n  namespace c=hyle::compute;namespace v=c::vulkan;\n  auto context=vulkan_test::context().value();\n  const auto desc=dense(c::DataType::kFloat32,{1,1,1,64});\n  const auto pdesc=dense(c::DataType::kInt32,{1});\n  const auto fdesc=dense(c::DataType::kFloat32,{32});\n  std::vector<float> host(64);for(std::size_t i=0;i<host.size();++i)host[i]=0.5F+float(i%11)/16;\n  const auto input=upload(context,desc,std::span<const float>(host));\n  for(bool compressed:{false,true}) {\n    const auto frequency=d5_deepseek_remaining_fragments::rope_frequencies(compressed);\n    const auto f=upload(context,fdesc,std::span<const float>(frequency));\n    for(std::int32_t position:{127,2052,2055,2303,65536,131071}) {\n      const std::array positions{position};const auto p=upload(context,pdesc,std::span(positions));\n      auto program=v::prepare(context,c::RoPE{.rotary_dimensions=64,.sequence_axis=1,.layout=c::RopeLayout::kInterleaved},desc,pdesc,fdesc);\n      ASSERT_TRUE(program)<<program.error().message();auto slot=program->create_invocation().value();\n      ASSERT_TRUE(slot.bind(input,p,f).ok());auto work=slot.submit().value();auto result=work.wait();ASSERT_TRUE(result);\n      const auto actual=float_values(context,result->get()->tensors()[0]);\n      const auto expected=d5_deepseek_remaining_fragments::rope_reference(host,64,position,compressed);\n      double error=0;std::size_t index=0;\n      for(std::size_t i=0;i<actual.size();++i)if(double e=std::abs(double(actual[i])-expected[i]);e>error){error=e;index=i;}\n      std::fprintf(stderr,"# G02_PHASE compressed=%d position=%d max_error=%.12g index=%zu phase=%.12g\\n",int(compressed),int(position),error,index,double(float(position)*frequency[index/2]));\n    }\n  }\n}\n',encoding='utf-8')
record.update(original_test_sha256=sha(source),diagnostic_source_sha256=sha(cpp),normal_exe_sha256=sha(build/'bin/hyle_graph_route_vulkan_test.exe'))
env={k.upper():v for k,v in os.environ.items()}
for line in subprocess.check_output(['cmd','/d','/c',str(base/'resume-windows-2/vs-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
fixture=json.loads((base/'current-model-fixture.json').read_text());env['HYLE_D5_QWEN35_FIXTURE']=fixture['root']
def run(stage,args,cwd=build):
 t=time.monotonic();log=out/(stage+'.log')
 with log.open('w',encoding='utf-8') as f:
  child=subprocess.Popen(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  record.update(state='RUNNING',stage=stage,pid=child.pid);save();print(stage,child.pid,flush=True);code=child.wait()
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-t});save()
 if code:
  record['state']='TERMINAL_FAIL';save();print(log.read_text(errors='replace')[-5000:]);raise SystemExit(code)
args=argv(row['command']);assert str(source) in args
args[args.index(str(source))]=str(cpp)
for i,a in enumerate(args):
 if a.startswith('/Fo'):args[i]='/Fo'+str(obj)
 if a.startswith('/Fd'):args[i]='/Fd'+str(out/'compile.pdb')
args.insert(1,'/I'+str(source.parent))
run('compile',args)
link=(out/'original-link-command.txt').read_text();part=link[link.index('&& "')+3:].rsplit(' && cd .',1)[0]
args=argv(part);assert args[1:3]==['-E','vs_link_exe']
old_obj=str(Path(row['output']).relative_to(build));assert args.count(old_obj)==1
args[args.index(old_obj)]=str(obj)
binary=build/'bin/g02_vulkan_rope_phase_diagnostic.exe'
assert not binary.exists()
for i,a in enumerate(args):
 if a.startswith('--intdir='):args[i]='--intdir='+str(out/'link')
 if a.lower().startswith('/out:'):args[i]='/out:'+str(binary)
 if a.lower().startswith('/implib:'):args[i]='/implib:'+str(out/'diagnostic.lib')
 if a.lower().startswith('/pdb:'):args[i]='/pdb:'+str(out/'diagnostic.pdb')
(out/'link').mkdir(exist_ok=False)
run('link',args)
run('test',[str(binary),'--gtest_filter=G02PhaseDiagnostic.ActualExplicitF32RotaryAtConsumerPositions','--gtest_color=no','--gtest_output=xml:'+str(out/'test.xml')])
assert sha(source)==record['original_test_sha256'] and sha(build/'bin/hyle_graph_route_vulkan_test.exe')==record['normal_exe_sha256']
record.update(state='TERMINAL_DIAGNOSTIC_PASS',binary_sha256=sha(binary));save()
print('\n'.join(l for l in (out/'test.log').read_text().splitlines() if 'G02_PHASE' in l or 'PASSED' in l),flush=True)
