from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,time

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';out=base/'vulkan-deepseek-output-diagnostic';build=Path('C:/h7/inference-g02-impacted')
old=json.loads((base/'remaining-windows-cases-1/vulkan/result.json').read_text());assert old['state']=='TERMINAL_FAIL' and len(old['cases'])==79
assert not (out/'result.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'state':'SETUP','scope':'One selected failed Graph fixture; scratch-only copy retains original independent F32 oracle and its stricter8e-5+4e-5 gate, prints F32/oldF16 differences. Product, original test source, oracles, shapes and normal executable unchanged. No product verdict from this diagnostic alone.','stages':[]}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
shell32=ctypes.WinDLL('shell32',use_last_error=True)
shell32.CommandLineToArgvW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
shell32.CommandLineToArgvW.restype=ctypes.POINTER(ctypes.c_wchar_p)
kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
kernel32.LocalFree.argtypes=[ctypes.c_void_p];kernel32.LocalFree.restype=ctypes.c_void_p
def argv(s):
 count=ctypes.c_int();pointer=shell32.CommandLineToArgvW(s,ctypes.byref(count));assert pointer
 try:return [pointer[i] for i in range(count.value)]
 finally:kernel32.LocalFree(pointer)
row=json.loads((out/'compile-row.json').read_text());source=Path(row['file']);cpp=out/'diagnostic.cc';obj=out/'diagnostic.obj'
s=source.read_text(encoding='utf-8');needle='      sem::expect_output(fixture, actual, expected.outputs[output],';assert s.count(needle)==1
probe='      if (fixture.region >= 0x08093404 && fixture.region <= 0x08093406) {\n        double max_error=0, peak=0, squares=0, ref_squares=0, gate_ratio=0;\n        std::size_t bad=0;\n        for (std::size_t i=0;i<actual.size();++i) {\n          const double ref=expected.outputs[output][i], e=std::abs(double(actual[i])-ref);\n          max_error=std::max(max_error,e);peak=std::max(peak,std::abs(ref));squares+=e*e;ref_squares+=ref*ref;\n          const double ratio=e/(2.0e-5+0.025*std::abs(ref));gate_ratio=std::max(gate_ratio,ratio);bad+=ratio>1;\n        }\n        std::fprintf(stderr,"# G02_DEEPSEEK region=%llu variant=%.*s step=%td output=%zu count=%zu max=%.12g peak=%.12g rms=%.12g ref_rms=%.12g bf16_gate_ratio=%.12g bad=%zu\\n",\n          static_cast<unsigned long long>(fixture.region),int(fixture.profile->variant.size()),fixture.profile->variant.data(),\n          &expected-fixture.replays.data(),output,actual.size(),max_error,peak,std::sqrt(squares/actual.size()),std::sqrt(ref_squares/actual.size()),gate_ratio,bad);\n      }\n'
s=s.replace(needle,probe+needle);cpp.write_text('#include <cstdio>\n'+s,encoding='utf-8')
record.update(original_test_sha256=sha(source),diagnostic_source_sha256=sha(cpp),normal_exe_sha256=sha(build/'bin/hyle_graph_route_vulkan_test.exe'))
env={k.upper():v for k,v in os.environ.items()}
for line in subprocess.check_output(['cmd','/d','/c',str(base/'resume-windows-2/vs-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
fixture=json.loads((base/'current-model-fixture.json').read_text());env['HYLE_D5_QWEN35_FIXTURE']=fixture['root']
def run(stage,args,cwd=build):
 t=time.monotonic();log=out/(stage+'.log')
 with log.open('w',encoding='utf-8') as f:
  child=subprocess.Popen(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  record.update(state='RUNNING',stage=stage,pid=child.pid);save();print(stage,child.pid,flush=True);code=child.wait()
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-t});save()
 if code and stage!='test':
  record['state']='TERMINAL_FAIL';save();print(log.read_text(errors='replace')[-5000:]);raise SystemExit(code)
args=argv(row['command']);assert str(source) in args
args[args.index(str(source))]=str(cpp)
for i,a in enumerate(args):
 if a.startswith('/Fo'):args[i]='/Fo'+str(obj)
 if a.startswith('/Fd'):args[i]='/Fd'+str(out/'compile.pdb')
args.insert(1,'/I'+str(source.parent))
run('compile',args)
link=(out/'original-link-command.txt').read_text();part=link[link.index('&& "')+3:].rsplit(' && cd .',1)[0]
args=argv(part);assert args[1:3]==['-E','vs_link_exe']
old_obj=str(Path(row['output']).relative_to(build));assert args.count(old_obj)==1
args[args.index(old_obj)]=str(obj)
binary=build/'bin/g02_vulkan_deepseek_output_diagnostic.exe'
assert not binary.exists()
for i,a in enumerate(args):
 if a.startswith('--intdir='):args[i]='--intdir='+str(out/'link')
 if a.lower().startswith('/out:'):args[i]='/out:'+str(binary)
 if a.lower().startswith('/implib:'):args[i]='/implib:'+str(out/'diagnostic.lib')
 if a.lower().startswith('/pdb:'):args[i]='/pdb:'+str(out/'diagnostic.pdb')
(out/'link').mkdir(exist_ok=False)
run('link',args)
run('test',[str(binary),'--gtest_filter=VulkanGraphMoeFragments.D5DeepSeekFullAttentionChain','--gtest_color=no','--gtest_output=xml:'+str(out/'test.xml')])
assert sha(source)==record['original_test_sha256'] and sha(build/'bin/hyle_graph_route_vulkan_test.exe')==record['normal_exe_sha256']
record.update(state='TERMINAL_DIAGNOSTIC_COLLECTED',binary_sha256=sha(binary));save()
print('\n'.join(l for l in (out/'test.log').read_text().splitlines() if 'G02_DEEPSEEK' in l and 'bad=0' not in l),flush=True)
