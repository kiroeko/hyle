"""Small offline source/recipe/results archive; no build or model execution."""
from pathlib import Path
import hashlib
import json
import zipfile
W=Path(__file__).resolve().parent
R=W.parents[1]
B=R/'.scratch/inference-prefill-facts-20261027'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(path):return dict(path=str(Path(path).resolve()),**digest(Path(path).read_bytes()))


def main():
    summary=read(W/'summary.json');ready=read(W/'ready.json')
    assert summary['status']=='REQUEST_ERROR_HOST_FOUR_AND_NORMAL_Q2_B2_PASS'
    assert summary['complete_nontime_report_differences']==0
    out=R/'docs/evidence/correctness/inference-request-error-identity-2026-10-27.json'
    archive=out.with_suffix('.zip');assert not out.exists() and not archive.exists()
    members,origins={},{}
    def add(name,path):
        path=Path(path);assert path.is_file() and name not in members
        assert path.suffix.lower() in {'.py','.json','.cc','.h','.log','.ids','.schedule','.tsv'}
        members[name]=path.read_bytes();origins[name]=str(path.resolve())
    for path in sorted(W.iterdir()):
        if path.is_file() and path.suffix.lower() in {'.py','.json','.cc','.h'}:add('records/'+path.name,path)
    for folder in ('compile','link','host/compile','host/link','host/run1','cli/run1'):
        for path in sorted((W/folder).iterdir()):
            if path.is_file() and path.suffix.lower() in {'.json','.log'}:add('records/'+path.relative_to(W).as_posix(),path)
    for path in (B/'ready.json',B/'run-plan.json',B/'cli/run1/report.json',B/'summary.json'):
        add('control/'+path.relative_to(B).as_posix(),path)
    add('records/host/reused-inputs.json',W/'host/reused-inputs.json')
    old_cli=R/'.scratch/inference-shape-policy-20261027/cli'
    for path in (old_cli/'run.py',old_cli/'inputs/weights.tsv',old_cli/'inputs/prompt.ids'):
        add('inputs/'+path.relative_to(old_cli).as_posix(),path)
    for path in sorted((old_cli/'cases/b2-multiturn').iterdir()):
        if path.is_file():add('inputs/cases/b2-multiturn/'+path.name,path)
    add('control/behavior.py',summary['normalizer']['path'])
    index=dict(members=[dict(member=name,original_path=origins[name],**digest(raw)) for name,raw in sorted(members.items())],
        exclusions='No EXE/OBJ/PDB/import/static library, SDK, model payload, or copied dependency tree. Cached objects/native runtime remain references.')
    index_bytes=(json.dumps(index,indent=2,ensure_ascii=False)+'\n').encode()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(members.items()):z.writestr(name,raw)
        z.writestr('member-sha256.json',index_bytes)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(members)+1
        assert z.read('member-sha256.json')==index_bytes
        for name,raw in members.items():assert digest(z.read(name))==digest(raw)
    report=dict(status='PASS_FINITE_REQUEST_ERROR_IDENTITY',date='2026-10-27',source=ready['source'],header=ready['header'],test=ready['test'],
        image=ready['image'],standalone=ready['standalone']['image'],ready=pin(W/'ready.json'),
        counts=summary['counts'],changes=['RequestExecutionFailure retains the original EvaluationFailure and separate retirement observation.',
            'Only the actual failed submitted bucket maps a qualified participant to its complete RequestKey. Unknown/out-of-range/native error facts remain batch-wide; normal success builds no identity table.'],
        results=dict(host=dict(process=summary['standalone_process'],groups=4,scope='Actual/reordered bucket complete identity including owner/generation, unknown/out-of-range, synthetic native Status facts, independent retirement observations.'),
            ordinary_planned_Q2_B2=dict(process=summary['CLI_process'],ledger=summary['ledger'],eligible_planned_shapes=summary['eligible_planned_shapes'],
                complete_nontime_report_differences=0,control=summary['control'],differences=pin(W/'nontime-differences.json'))),
        build=dict(model=ready['compile'],CLI_link=ready['link'],standalone_compile=ready['standalone']['compile'],standalone_link=ready['standalone']['link'],
            actual_dependencies=ready['actual_dependencies'],standalone_actual_dependencies=ready['standalone']['actual_dependencies'],
            retained_CLI_inputs=pin(W/'retained-inputs.json'),failed_compile_link_or_native_processes=0),
        reuse=dict(previous_evidence=pin(R/'docs/evidence/correctness/inference-prefill-facts-2026-10-27.json'),
            standalone_reused_libraries=read(W/'host/reused-inputs.json'),standalone_system_libraries=['kernel32.lib'],
            baseline_image=read(W/'plan.json')['baseline_image'],scope='223 prior CLI inputs and exact runtime reused. Standalone adds the existing hyle_error plus Kernel32. No SDK/native/NVCC/weights/report rebuild; no baseline or MTP re-execution.'),
        limits=['Four standalone error-fact groups and one normal cached untrained tiny CUDA ordinary Q2/B2 journey. Native faults in host checks are synthetic Status values, not device fault injection; no engine failure-path run was added.',
            'All prior nonclock JSON fields, ledger/RNG/IDs/cache/resource/work facts compared without new exclusions. Clock/rate normalization uses the recorded existing pure functions.',
            'No device-capture warmup, varlen/padding, cross-chunk bitwise quality, performance gain, full-model or all-platform claim.'],
        archive=dict(**pin(archive),members=len(members)+1,CRC_and_member_SHA256_verified=True))
    out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=pin(out),archive=report['archive']),indent=2))


if __name__=='__main__':main()
