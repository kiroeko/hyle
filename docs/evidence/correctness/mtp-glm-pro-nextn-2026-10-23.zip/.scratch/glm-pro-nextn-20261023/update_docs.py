"""Update the two existing progress references only after final native results."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def replace_once(text, old, new):
    assert text.count(old) == 1, old[:120]
    return text.replace(old, new, 1)


flash = read(S / 'checks1/summary.json')
pro = read(S / 'checks4/summary.json')
for result in (flash, pro):
    assert result['process']['exit'] == 0 and not result['process']['timed_out']
    assert result['tests'] == 2 and not any(result[k] for k in ('failures', 'errors', 'disabled', 'skips'))
pro_graphs = [int(case['properties']['actual_submissions']) for case in pro['cases']]
flash_graphs = sum(int(case['properties']['actual_submissions']) for case in flash['cases'])
for case in pro['cases']:
    props = case['properties']
    assert props['full_original_nextn_roles'] == '1571'
    assert props['full_original_nextn_source_bytes'] == '13838963840'
    assert int(props['peak_state_backing_bytes']) <= int(props['state_budget_bytes'])
    assert int(props['accepted_zero_draft_checkpoints']) > 0 and int(props['accepted_one_draft_checkpoints']) > 0
    assert int(props['actual_index_catchup_steps']) > 0
assert flash_graphs == 174 and pro_graphs == [24, 24]

current = R / 'docs/developer/current-work.md'
text = current.read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
protected = read(S / 'before.json')['protected_performance_tail_sha256']
assert hashlib.sha256(tail.encode()).hexdigest() == protected
start = text.index('## MTP当前剩项')
end = text.index('## 执行顺序与近期进度', start)
section = f'''## MTP当前剩项

**最近已验证进展：** [GLM Pro完整原NextN与接受后续算](../evidence/correctness/mtp-glm-pro-nextn-2026-10-23.json)已接官方layer78的1569份原角色及两份独立全词表，共1571份、13,838,963,840B。保留实际6144隐藏维、NoPE192＋RoPE64、完整CKV512＋KPE64缓存行、latent512 attention与原value256投影；非池化indexer复用原2048个绝对ID，skip不添加Flash尾窗。原256域Top8专家有界供给、原全V154880预测和实际pending反馈沿既有普通Graph／Invocation及一个StateHead执行。

CPU／CUDA各{pro_graphs[0]}次Graph；受共用执行函数和MoE几何改动影响的Flash回归{flash_graphs}次，共4项、{sum(pro_graphs) + flash_graphs}次，0失败／0跳过。11资源＋Epoch24完整保存主缓存、E4／F32scale、hidden、pending、位置／选中ID及待追赶journal；接受0／1、取消／旧读者、已接受lag1追赶和epoch8 fresh→skip0均已检查，跨epoch误用在提交前拒绝。上游target taps与初始历史仍是显式fixture，未据此证明完整训练模型、任务质量、真实任务接受率或TPS。

| 模型／制品 | 已验证的实际范围 | 仍需完成 |
| --- | --- | --- |
| Qwen3.5-2B BF16 | 原335权重的greedy K1，含多会话／多轮／B2、完整前缀、有界重建和列明三平台取消／退休／预算恢复；[8项QKV差异](../evidence/correctness/qwen-mtp-quality-prefix-2026-10-22.json)指向普通单／双行稳定浮点差异 | 最终普通／MTP性能复测与热点；不将有限数值检查外推为所有形状或任务质量 |
| Q27主UD-Q4_K_M | [原17角色](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)：完整NextN、原全V248320 embedding／head、实际ID／hidden及六资源同Head接受0／1／2后续算，CPU／CUDA通过 | 原target63、独立target norm和verifier；其它已确认量化；上游主干／初始历史仍保边界 |
| Q24主UD-IQ4_XS | [原22角色](../evidence/correctness/mtp-q24-original-nextn-2026-10-23.json)：完整NextN、两原词表、真实512域Top10及有界Q4_K专家，六资源接受后续算CPU／CUDA通过 | 原target91及norm／verifier；target专家实际IQ4_XS，不能代用NextN的Q4_K；其它已确认量化 |
| GLM Flash官方 | [完整原NextN1762角色](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)，以及[独立原43→44→NextN](../evidence/correctness/mtp-glm-original-target43-2026-10-23.json)、原全V双行验证、真实pending和34资源＋Epoch的K1接受／续算 | 其它适用producer／verifier、已确认量化；layer42输入与有限初始历史仍是fixture |
| GLM Pro官方 | 本轮完整原NextN1571角色、实际MLA／RoPE／非池化index、全V反馈与11资源＋Epoch接受后续算，CPU／CUDA通过 | 原target producer、其它已确认量化和必要后端检查；target taps仍是外部fixture |
| 正式DeepSeek V4 Flash／Pro | [Flash DSpark原83角色](../evidence/correctness/mtp-dspark-original-experts-2026-10-23.json)：全部81份sidecar及正式原BF16词表、256域router／MXFP4专家、三stage编码历史与完整draft接受后续算CPU／CUDA通过 | 原target captures／verifier、Pro实际组合、其它适用制品及主UD-Q4词表 |
| Kimi固定原制品 | 未确认NextN | 不凭名称新增MTP任务；Qwen3.5两个baseline GGUF明确排除MTP，发现记录也不自动等于已确认任务 |

**接下来的顺序：**

1. 补大packed全词表head的CUDA双行M2准入：保原压缩bank与有界native计算，避免整份F32展开；两次M1不能代替该缺口收尾。
2. 接Q27末target63和Q24末target91的实际参数、独立target norm及全V verifier。两末层均为完整attention；复用已有词表／head和共同状态机制，上游主干与历史边界明确保留。
3. 补DeepSeek原target／Pro组合及其它已确认MTP量化接线，不为每种制品复制执行器。
4. 做必要回归、普通／MTP完整性能对照与实测热点处理，之后进入图片完整链路。

动态E4 codes＋F32 scales已有四端逐bit、失败恢复与寿命检查；indexer采用PowerOfTwo／floor1e-4，原MLA／MoE采用Divide／floor1e-10。CUDA公共I32→F32 Cast边界、状态、页权限、只读租约、预算和原子发布继续共用，范围见[总表](../implementation/model-operators.md)。未执行的模型、系统、codec或完整质量不写成通过；角色数不作为完成百分比，页末AV仍是最新完整性能窗口。


'''
text = text[:start] + section + text[end:]
old = next(line for line in text.splitlines() if line.startswith('| 3 | MTP |'))
new = '| 3 | MTP | 当前优先；Q27／Q24、GLM Flash／Pro和DSpark的列明完整draft／状态已有CPU／CUDA检查。先补CUDA大packed head M2和Qwen实际target／verifier，再补DeepSeek／已确认量化，最后完整性能对照；详细边界见上表 |'
text = replace_once(text, old, new)
assert text[text.index('## 最新完整性能对比'):] == tail
current.write_text(text, encoding='utf-8', newline='\n')

catalog = R / 'docs/implementation/model-operators.md'
text = catalog.read_text(encoding='utf-8-sig')
old = next(line for line in text.splitlines() if line.startswith('| GLM-5.3 | MLA／DSA历史、'))
new = '| GLM-5.3 | CKV512＋旋转KPE64、非池化E4／F32scale index缓存、绝对位置／2048选中ID、待追赶journal及hidden／pending | [官方原NextN1571角色](../evidence/correctness/mtp-glm-pro-nextn-2026-10-23.json)含完整layer78与独立全V154880词表，CPU／CUDA普通两阶段Graph通过；真实576宽QK／512值再接value256投影、原256域Top8 FP8专家、11资源＋Epoch同Head接受0／1、skip／lag1追赶与epoch8续算。target taps和有限初始历史仍是显式fixture；原target producer及其它已确认量化／后端未完成 |'
text = replace_once(text, old, new)
text = text.replace('其它适用producer／verifier、Pro实际几何和已确认量化未完成', '其它适用producer／verifier和已确认量化未完成')
text = replace_once(text,
    '下一步是其它适用producer／verifier、Pro实际几何、已确认量化和最终普通／MTP性能对照。',
    '下一步是大packed全词表head的CUDA双行M2、Q27／Q24实际target／verifier、其它已确认量化和最终普通／MTP性能对照。')
marker = '## 正式版 DeepSeek：角色、存储与数值边界'
pro_section = f'''[GLM Pro原NextN](../evidence/correctness/mtp-glm-pro-nextn-2026-10-23.json)与Flash共用普通Graph运行函数、冷图切分、几何化MoE供给及StateHead。官方原KV_b整块E4／F32scale先冷解码为BF16，再拆每head448行中的NoPE192／value256；scale不能在非128对齐的head边界重置。只保留两份紧凑只读BF16布局，退掉device原KV临时bank。Pro缓存整行576保CKV512与旋转KPE64，QK576和V512来自同一组选中全局行，再由原value投影输出256；F32载体仅为实际BF16值扩宽。

Pro非池化indexer使用原FP8wk／wq_b、BF16 LayerNorm系数精确扩宽、first64 interleaved RoPE、Hadamard128／BF16／UE8M0及原BF16 weights_proj的F32输出。skip复用原2048个绝对ID，不追加Flash当前尾窗；接受后仅追赶实际journal记录，fresh前index位置必须追平。原MoE保持256域、Top8、route2.5且无Flash clip10，同代三原codes／scales bank＋map每槽302,064,640B。CPU／CUDA各{pro_graphs[0]}次Graph，加受影响Flash回归共4项{sum(pro_graphs) + flash_graphs}次，0失败／0跳过；完整原target、自然任务质量／接受率及TPS仍未代签。

'''
text = replace_once(text, marker, pro_section + marker)
catalog.write_text(text, encoding='utf-8', newline='\n')
print('Updated current-work and model-operators from actual final native results; AV performance unchanged')
