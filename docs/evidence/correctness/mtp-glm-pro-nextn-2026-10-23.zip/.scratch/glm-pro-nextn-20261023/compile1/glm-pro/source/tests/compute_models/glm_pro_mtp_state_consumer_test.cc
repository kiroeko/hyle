#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <functional>
#include <limits>
#include <memory>
#include <numeric>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "hyle/compute/model_ops.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/storage_owner.h"
#include "hyle/compute/state_versions.h"
#if defined(HYLE_TEST_GLM_STATE_CPU)
#include "hyle/graph/cpu.h"
#endif
#if defined(HYLE_TEST_GLM_STATE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#endif
#include "glm_pro_mtp_fragment.h"
#include "glm_pro_original_roles.h"
#include "glm_pro_mtp_reference.h"
#include "glm_original_moe_roles.h"
#include "glm_original_moe_reference.h"
#include "glm_original_moe_resident_weights.h"
#include "glm_shared_vocabulary.h"
#include "glm_target_verifier_fragment.h"
#include "model_graph_run.h"
#include "model_resident_fragment.h"

namespace {
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace model=glm_pro_mtp_fragment;
namespace own=glm_pro_original_roles;
namespace vocabulary=glm_shared_vocabulary;
namespace expert=glm_original_moe_roles;
namespace supply=glm_original_moe_resident_weights;
namespace cut=model_resident_fragment;
using Value=sem::ValueId;
using Bytes=std::vector<std::byte>;
using Readonly=vocabulary::ReadonlyRole;
inline constexpr auto kMoe=glm_moe_geometry::kPro;
inline constexpr std::int64_t kCapacity=2064,kBasePosition=2053,kSelected=2048,kJournalRows=3;

template<class T> T take(hyle::Result<T> result,const char *where) {
  if(!result)throw std::runtime_error(std::string(where)+": "+std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status,const char *where) {
  if(!status.ok())throw std::runtime_error(std::string(where)+": "+std::string(status.message()));
}
Bytes read(const c::ReadLease &lease) {
  Bytes bytes(lease.size());check(take(lease.view(),"read actual Pro lease").read(bytes),"read Pro bytes");return bytes;
}
template<class T> std::vector<T> values(const c::ReadLease &lease) {
  const auto raw=read(lease);
  if(raw.size()%sizeof(T))throw std::runtime_error("Pro typed lease byte extent");
  std::vector<T> result(raw.size()/sizeof(T));std::memcpy(result.data(),raw.data(),raw.size());return result;
}
c::ReadLease upload(const c::StorageOwner &owner,std::span<const std::byte> bytes) {
  auto buffer=take(m::Buffer::create(owner.ref(),bytes.size(),256),"initial/immutable Pro backing");
  check(buffer.view().write(bytes),"initial/immutable Pro upload");
  return take(owner.adopt_buffer(std::move(buffer)),"initial/immutable Pro permission");
}
std::string directory(const char *name) {
#if defined(_WIN32)
  char *value=nullptr;std::size_t count=0;
  if(_dupenv_s(&value,&count,name))throw std::runtime_error("original Pro directory environment");
  const std::unique_ptr<char,decltype(&std::free)> cleanup(value,&std::free);return value?value:"";
#else
  const auto *value=std::getenv(name);return value?value:"";
#endif
}

struct External final {std::size_t slot;Readonly role;};
struct Recipe final {
  sem::Fragment fragment;
  std::vector<External> external;
};
Value external(Recipe &recipe,const Readonly &role) {
  const auto slot=recipe.fragment.constants.size();
  const auto value=recipe.fragment.constant(role.description,{});
  recipe.external.push_back({slot,role});return value;
}

// This holder compiles ordinary public Graphs. The shared model_graph_run
// function owns their bind/prepare/submit/retire/reset procedure; model state,
// original roles and expert frontiers are not part of an alternate executor.
struct Native final {
  Recipe recipe;
  sem::GraphCase logical;
  std::vector<c::ReadLease> parameters;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool outputs;
  std::vector<model_graph_run::Port> input_ports,output_ports;
  std::size_t submissions=0;
  static Native create(Recipe recipe,c::Context &context,const c::StorageOwner &owner,
                       bool cuda,std::uint32_t generations=3) {
    Native result;result.recipe=std::move(recipe);result.logical=sem::make_graph(result.recipe.fragment);
    std::vector<g::ConstantBinding> constants;
    for(std::size_t slot=0;slot<result.logical.constants.size();++slot) {
      const auto found=std::find_if(result.recipe.external.begin(),result.recipe.external.end(),
          [&](const External &entry){return entry.slot==slot;});
      const auto &desc=result.recipe.fragment.description(result.recipe.fragment.constants[slot]);
      if(found!=result.recipe.external.end()) {
        if(found->role.description!=desc||found->role.owner.ref()!=owner.ref())
          throw std::runtime_error("Pro immutable constant changed description or actual owner");
        constants.push_back(take(found->role.binding(result.logical.constants[slot]),"actual ready Pro constant owner"));
      } else {
        result.parameters.push_back(upload(owner,result.recipe.fragment.constant_bytes[slot]));
        constants.push_back({result.logical.constants[slot],take(result.parameters.back().tensor(desc),"actual generated Pro constant")});
      }
    }
    const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*result.recipe.fragment.profile),"actual Pro artifact profile"),
        c::WorkloadPhase::kDecode,{0x48594c454d4f444cULL,result.recipe.fragment.region,1}};
    const g::CompileOptions options{.constants=constants,.workload=workload};
    const auto compile=[&]()->hyle::Result<g::CompiledGraph> {
#if defined(HYLE_TEST_GLM_STATE_CPU)
      if(!cuda)return g::cpu::compile(result.logical.graph,context,options);
#endif
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      if(cuda)return g::cuda::compile(result.logical.graph,context,owner,options);
#endif
      throw std::runtime_error("original Pro native backend is unavailable");
    };
    result.compiled=take(compile(),"ordinary original Pro Graph compile");
    for(std::size_t slot=0;slot<result.logical.inputs.size();++slot)
      result.input_ports.push_back({result.logical.inputs[slot],result.recipe.fragment.description(result.recipe.fragment.inputs[slot])});
    std::size_t capacity=0;
    for(std::size_t slot=0;slot<result.logical.outputs.size();++slot) {
      if(take(result.compiled.executable.output_ownership(slot),"Pro output ownership")!=g::OutputOwnership::kCaller)
        throw std::runtime_error("Pro results must retain independent caller-owned storage");
      const auto &desc=result.recipe.fragment.description(result.recipe.fragment.outputs[slot]);
      const auto bytes=take(desc.required_bytes(),"Pro output extent");
      if(bytes>std::numeric_limits<std::size_t>::max()-255||capacity>std::numeric_limits<std::size_t>::max()-(bytes+255)/256*256)
        throw std::runtime_error("Pro output backing capacity overflow");
      capacity+=(bytes+255)/256*256;
      result.output_ports.push_back({result.logical.outputs[slot],desc});
    }
    if(!generations||capacity>std::numeric_limits<std::size_t>::max()/generations||
        result.output_ports.size()>std::numeric_limits<std::uint32_t>::max()/generations)
      throw std::runtime_error("Pro result generations exceed representable capacity");
    result.invocation=take(result.compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"ordinary Pro Invocation");
    result.outputs=take(c::LeasePool::create(owner.ref(),capacity*generations,
        {.max_blocks=std::uint32_t(result.output_ports.size())*generations,.backing_alignment=256}),"bounded Pro result generations");
    return result;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue,std::span<const c::ReadLease> inputs,
      std::span<const std::size_t> externally_bound={},const std::function<void(g::Invocation&)> &binder={}) {
    return model_graph_run::execute(invocation,outputs,queue,input_ports,inputs,output_ports,submissions,externally_bound,binder);
  }
};

struct Source final {
  own::Bound parameters;
  vocabulary::Vocabulary words;
  std::array<Readonly,2> prepared;
  c::LeasePool prepared_pool;
  expert::Roles experts;
  std::unique_ptr<supply::CpuSupply> cpu_supply;
#if defined(HYLE_TEST_GLM_STATE_CUDA)
  std::unique_ptr<supply::CudaSupply> cuda_supply;
#endif
  bool full_checked=false,moe_full_checked=false;
  std::size_t cold_submissions=0,episodes=0,checked_steps=0;
  std::vector<expert::Selection> selections;
};

// Insert after Source in glm_pro_mtp_state_consumer_test.cc. This is observer
// wiring only: every mathematical gate uses its existing independent helper.
template<class ReadValue>
bool observe_moe(Source &source,const glm_original_moe_fragment::Result &result,
                 ReadValue actual) {
  namespace ref=glm_original_moe_reference;
  namespace boundary=glm_original_indexer_reference;
  namespace lm=glm_shared_vocabulary_reference;
  namespace bytes=glm_pro_mtp_reference::detail;
  constexpr auto geometry=glm_moe_geometry::kPro;
  if(!source.experts.source||source.experts.source->model()!=geometry||source.selections.empty()) {
    ADD_FAILURE()<<"original Pro MoE observer requires the actual Pro source and resident selection";
    return false;
  }
  const auto &data=*source.experts.source;
  const auto &ports=result.ports;
  const auto fp=[&](Value value){return bytes::floats(actual(value));};
  const auto bf=[&](Value value){return bytes::bfloats(actual(value));};
  const auto integer=[&](Value value){return bytes::integers(actual(value));};
  const auto input=bf(ports.input);
  const auto global=integer(ports.ids),local=integer(ports.local_ids),map=integer(ports.map);
  const auto logits=fp(ports.logits),scores=fp(ports.scores),selection=fp(ports.selection);
  const auto selected=fp(ports.selected_scores),sum=fp(ports.sum),denominator=fp(ports.denominator);
  const auto normalized=fp(ports.normalized),weights=fp(ports.weights);
  if(!ref::expect_router(logits,input,data.router_bytes(),geometry)||
      !ref::expect_routing({logits,scores,selection,selected,sum,denominator,normalized,weights,global},
          data.bias_bytes(),geometry))return false;
  const auto &resident=source.selections.back();
  if(map!=resident.map) {
    ADD_FAILURE()<<"original Pro MoE actual map differs from the same resident generation";
    return false;
  }
  if(!ref::expect_mapping(global,map,local,resident.globals,geometry))return false;
  const bool full=!source.moe_full_checked;
  const auto matrix=[&](expert::Leg leg,std::optional<std::int32_t> selected_expert=std::nullopt) {
    const auto [outputs,width]=expert::geometry(leg,geometry);
    return ref::Fp8Matrix{
        selected_expert?data.expert_bytes(leg,*selected_expert,false):data.shared_bytes(leg,false),
        selected_expert?data.expert_bytes(leg,*selected_expert,true):data.shared_bytes(leg,true),
        std::size_t(outputs),std::size_t(width)};
  };
  const auto branch=[&](const glm_original_moe_fragment::ProjectionPorts &projection,bool routed) {
    const auto gate=fp(projection.gate_raw),up=fp(projection.up_raw),down=fp(projection.down_raw);
    const auto stored_gate=bf(projection.gate_stored),stored_up=bf(projection.up_stored);
    const auto activated=bf(projection.activation_stored);
    if(routed) {
      if(!ref::expect_selected_projection(gate,input,global,
              [&](std::int32_t id){return matrix(expert::Leg::kGate,id);},
              "original Pro selected gate",full,geometry)||
          !ref::expect_selected_projection(up,input,global,
              [&](std::int32_t id){return matrix(expert::Leg::kUp,id);},
              "original Pro selected up",full,geometry)||
          !ref::expect_selected_projection(down,activated,global,
              [&](std::int32_t id){return matrix(expert::Leg::kDown,id);},
              "original Pro selected down",full,geometry))return false;
    } else {
      if(!ref::expect_fp8_projection(gate,input,matrix(expert::Leg::kGate),"original Pro shared gate",full)||
          !ref::expect_fp8_projection(up,input,matrix(expert::Leg::kUp),"original Pro shared up",full)||
          !ref::expect_fp8_projection(down,activated,matrix(expert::Leg::kDown),"original Pro shared down",full))return false;
    }
    const auto activation=fp(projection.activation_raw);
    // kPro has no SwiGLU limit: these ports must retain the un-clipped actual
    // BF16 predecessors. The same helper explicitly checks that profile.
    return boundary::expect_bfloat_store(stored_gate,gate,"Pro actual gate BF16 store")&&
        boundary::expect_bfloat_store(stored_up,up,"Pro actual up BF16 store")&&
        ref::expect_activation(fp(projection.gate_clipped),fp(projection.up_clipped),
            activation,stored_gate,stored_up,geometry)&&
        boundary::expect_bfloat_store(activated,activation,"Pro actual SwiGLU BF16 store");
  };
  if(!branch(ports.routed,true)||!branch(ports.shared,false))return false;
  const auto weighted=fp(ports.weighted_raw);
  const auto weighted_stored=bf(ports.weighted_stored);
  const auto routed_sum=fp(ports.routed_sum_raw);
  const auto routed_stored=bf(ports.routed_sum_stored);
  const auto shared_stored=bf(ports.shared_stored);
  const auto merged=fp(ports.merge_raw);
  const auto merged_stored=bf(ports.merge_stored);
  if(!ref::expect_weighted_down(weighted,fp(ports.routed.down_raw),weights,geometry)||
      !boundary::expect_bfloat_store(weighted_stored,weighted,"Pro actual weighted down BF16 store")||
      !ref::expect_routed_sum(routed_sum,weighted_stored,geometry)||
      !boundary::expect_bfloat_store(routed_stored,routed_sum,"Pro actual routed sum BF16 store")||
      !boundary::expect_bfloat_store(shared_stored,fp(ports.shared.down_raw),"Pro actual shared down BF16 store")||
      !lm::expect_sum(merged,bytes::widen(routed_stored),bytes::widen(shared_stored))||
      !boundary::expect_bfloat_store(merged_stored,merged,"Pro actual shared/routed merge BF16 store")||
      !bytes::same(bf(result.output),merged_stored,"Pro actual MoE returned BF16 merge"))return false;
  source.moe_full_checked=true;
  return true;
}

model::Parameters parameters(Recipe &recipe,const Source &source) {
  const auto bank=[&](own::Role role){return external(recipe,source.parameters.at(role));};
  return {.eh=bank(own::Role::kEh),.embedding_norm=bank(own::Role::kEmbeddingNorm),
      .hidden_norm=bank(own::Role::kHiddenNorm),.input_norm=bank(own::Role::kInputNorm),
      .post_norm=bank(own::Role::kPostNorm),.index_bias=bank(own::Role::kIndexBias),
      .index_norm=bank(own::Role::kIndexNorm),.index_weights=bank(own::Role::kIndexWeights),
      .index_key=bank(own::Role::kIndexKey),.index_query=bank(own::Role::kIndexQuery),
      .kv_norm=bank(own::Role::kKvNorm),.kv_a=bank(own::Role::kKvA),.output=bank(own::Role::kOutput),
      .query_norm=bank(own::Role::kQueryNorm),.query_a=bank(own::Role::kQueryA),.query_b=bank(own::Role::kQueryB),
      .shared_norm=external(recipe,source.words.at(vocabulary::Role::kNorm)),
      .head=external(recipe,source.words.at(vocabulary::Role::kHead)),
      .prepared_key=external(recipe,source.prepared[0]),.prepared_value=external(recipe,source.prepared[1])};
}

// One router frontier cuts a pure model Fragment into the same two ordinary
// native Graphs used by Flash. Only its actual8 global IDs reach the bounded
// supplier. Activations and state cross the cut as original producer leases.
struct Resident final {
  std::shared_ptr<Source> source;
  Recipe recipe;
  cut::ResidentDraft<glm_original_moe_fragment::Boundary,1> plan;
  std::vector<Native> phases;
  static Resident create(Recipe recipe,const glm_original_moe_fragment::Boundary &boundary,
      std::shared_ptr<Source> source,c::Context &context,const c::StorageOwner &owner,bool cuda,
      std::uint32_t generations=3) {
    Resident result;result.source=std::move(source);result.recipe=std::move(recipe);
    result.plan=cut::split(result.recipe.fragment,std::array{boundary},0x474c4d50524f5048ULL);
    std::vector<Readonly> ready;
    for(std::size_t slot=0;slot<result.recipe.fragment.constants.size();++slot) {
      const auto found=std::find_if(result.recipe.external.begin(),result.recipe.external.end(),
          [&](const External &entry){return entry.slot==slot;});
      if(found!=result.recipe.external.end())ready.push_back(found->role);
      else ready.push_back({"Pro cold component constant",
          result.recipe.fragment.description(result.recipe.fragment.constants[slot]),owner,
          upload(owner,result.recipe.fragment.constant_bytes[slot])});
    }
    for(const auto &phase:result.plan.phases) {
      Recipe local;local.fragment=phase.fragment;
      for(std::size_t slot=0;slot<phase.original_constants.size();++slot) {
        const auto original=phase.original_constants[slot];
        const auto found=std::find_if(result.recipe.fragment.constants.begin(),result.recipe.fragment.constants.end(),
            [&](Value value){return value.ordinal()==original.ordinal();});
        if(found==result.recipe.fragment.constants.end())throw std::runtime_error("Pro cold cut lost immutable constant");
        const auto index=std::size_t(found-result.recipe.fragment.constants.begin());
        local.external.push_back({slot,ready.at(index)});
      }
      result.phases.push_back(Native::create(std::move(local),context,owner,cuda,generations));
    }
    return result;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue,std::span<const c::ReadLease> inputs,bool cuda) {
    (void)cuda;
    if(inputs.size()+4!=recipe.fragment.inputs.size())throw std::runtime_error("Pro ordinary/resident input count");
    std::vector<c::ReadLease> live(recipe.fragment.descriptions.size());
    for(std::size_t i=0;i<inputs.size();++i)live.at(recipe.fragment.inputs[i].ordinal())=inputs[i];
    std::array<std::vector<c::ReadLease>,2> completed;
    for(std::size_t index=0;index<phases.size();++index) {
      const auto &phase=plan.phases[index];
      std::optional<supply::CpuBatch> cpu_batch;
      std::optional<expert::Selection> selection;
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      std::optional<c::cuda::WeightBatch> cuda_batch;
      std::array<g::WeightBinding,4> bindings;
#endif
      std::array<std::size_t,4> dynamic{};
      std::span<const std::size_t> external_ports;
      std::function<void(g::Invocation&)> binder;
      if(phase.resident_stage) {
        const auto &frontier=plan.routers.at(*phase.resident_stage);
        selection=expert::select(values<std::int32_t>(live.at(frontier.ids.ordinal())),kMoe);
        const std::array banks{frontier.banks[0],frontier.banks[1],frontier.banks[2],frontier.map};
        for(std::size_t bank=0;bank<banks.size();++bank) {
          const auto found=std::find_if(phase.original_inputs.begin(),phase.original_inputs.end(),
              [&](Value value){return value.ordinal()==banks[bank].ordinal();});
          if(found==phase.original_inputs.end())throw std::runtime_error("Pro cut lost actual compressed bank or map");
          dynamic[bank]=std::size_t(found-phase.original_inputs.begin());
#if defined(HYLE_TEST_GLM_STATE_CUDA)
          bindings[bank]={phases[index].logical.inputs.at(dynamic[bank]),supply::kBankIds[bank]};
#endif
        }
#if defined(HYLE_TEST_GLM_STATE_CUDA)
        if(cuda) {
          if(!source->cuda_supply)throw std::runtime_error("Pro needs its actual shared CUDA supply");
          cuda_batch.emplace(take(source->cuda_supply->upload(source->episodes%2,*selection,*source->experts.source,queue),
              "same-generation original Pro experts/map"));
          external_ports=dynamic;
          binder=[&](g::Invocation &active){check(g::cuda::bind(active,bindings,*cuda_batch),"bind actual Pro expert generation");};
        } else
#endif
        {
          if(!source->cpu_supply)throw std::runtime_error("Pro needs its actual shared CPU supply");
          cpu_batch.emplace(take(source->cpu_supply->upload(*selection,*source->experts.source),"actual Pro CPU expert generation"));
          for(std::size_t bank=0;bank<banks.size();++bank)live.at(banks[bank].ordinal())=cpu_batch->banks[bank];
        }
      }
      std::vector<c::ReadLease> arguments;
      for(const auto original:phase.original_inputs)arguments.push_back(live.at(original.ordinal()));
      completed[index]=phases[index].execute(queue,arguments,external_ports,binder);
      for(std::size_t slot=0;slot<phase.original_outputs.size();++slot)
        live.at(phase.original_outputs[slot].ordinal())=completed[index][slot];
      if(selection) {
        source->selections.push_back(std::move(*selection));
#if defined(HYLE_TEST_GLM_STATE_CUDA)
        if(cuda_batch) {
          const auto accounting=take(cuda_batch->report(),"actual Pro upload accounting");
          const auto layout=source->cuda_supply->layout();
          EXPECT_EQ(accounting.logical_bytes,layout.logical_bytes);EXPECT_EQ(accounting.staged_bytes,layout.logical_bytes);
          EXPECT_EQ(accounting.completed_bytes,accounting.submitted_bytes);EXPECT_FALSE(accounting.copied_bytes_unknown);
        }
#endif
      }
      // The shared ordinary run helper has waited/reset before the compact
      // generation can be dropped and either of the two slots reused.
    }
    std::vector<c::ReadLease> outputs;
    for(const auto location:plan.full_outputs)outputs.push_back(completed.at(location.phase).at(location.port));
    ++source->episodes;return outputs;
  }
  std::size_t native_submissions() const {
    std::size_t result=0;for(const auto &phase:phases)result+=phase.submissions;return result;
  }
  std::size_t backing_capacity() const {
    std::size_t result=0;for(const auto &phase:phases)result+=phase.outputs.stats().capacity_bytes;return result;
  }
};

enum Entry:std::size_t {
  kMain,kCodes,kScales,kHidden,kPending,kCursor,kIndexCursor,kSelection,
  kJournal,kJournalPositions,kLag,kResources,kEpoch=kResources,kEntries
};
std::array<c::TensorDesc,kResources> descriptions() {
  return {sem::dense({kCapacity,model::kCacheDepth}),
      sem::dense({kCapacity,model::kIndexDepth},c::DataType::kFloat8E4M3FN),sem::dense({kCapacity,1}),
      sem::dense({1,model::kHidden},c::DataType::kBFloat16),sem::dense({1},c::DataType::kInt32),
      sem::dense({1},c::DataType::kInt32),sem::dense({1},c::DataType::kInt32),
      sem::dense({kSelected},c::DataType::kInt32),
      sem::dense({kJournalRows,model::kHidden},c::DataType::kBFloat16),
      sem::dense({kJournalRows},c::DataType::kInt32),sem::dense({1},c::DataType::kInt32)};
}
Value increment(sem::Fragment &f,Value value) {
  const auto one=f.constant(sem::dense({1},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>{1}));
  const auto scan=f.one(c::Operation(c::Scan{.axis=0}),
      {f.one(c::Operation(c::Concat{.axis=0}),{value,one})});
  return f.one(c::Operation(c::Gather{}),{scan,one});
}
constexpr auto kAbsent=std::numeric_limits<std::size_t>::max();
struct Step final {
  Recipe recipe;
  std::optional<model::Result> model;
  std::optional<model::IndexHistory> catchup;
  std::vector<std::pair<Value,std::size_t>> observations;
  std::array<std::size_t,kResources> state_ports;
  std::size_t ordinary_inputs=0,target_hidden=kAbsent;
  std::int32_t position=0;
  bool fresh=false;
  Step(){state_ports.fill(kAbsent);}
};
std::size_t expose(Step &step,Value value) {
  const auto found=std::find_if(step.observations.begin(),step.observations.end(),
      [&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
  if(found!=step.observations.end())return found->second;
  auto &f=step.recipe.fragment;const auto port=f.outputs.size();
  f.outputs.push_back(f.one(c::Operation(c::Copy{}),{value}));
  step.observations.push_back({value,port});return port;
}
void observe_port(Step &step,Value &value) {
  const auto &inputs=step.recipe.fragment.inputs;
  const auto found=std::find_if(inputs.begin(),inputs.end(),[&](Value input){return input.ordinal()==value.ordinal();});
  if(found!=inputs.end()&&std::size_t(found-inputs.begin())<step.ordinary_inputs)return;
  (void)expose(step,value);
}
Step build_step(const Source &source,bool fresh,std::int32_t position) {
  if(position<kBasePosition||position>=kCapacity)throw std::runtime_error("Pro step is outside the finite prepared domain");
  Step result;result.fresh=fresh;result.position=position;
  auto &r=result.recipe;auto &f=r.fragment;
  f.profile=&d5_moe_semantic_fragments::profiles::glm53_official;
  f.region=0x474c4d50524f5354ULL+std::uint64_t(position-kBasePosition)*2+std::uint64_t(fresh);f.quantized=true;
  std::array<Value,kResources> state;
  const auto desc=descriptions();
  for(std::size_t i=0;i<state.size();++i)state[i]=f.input(desc[i]);
  Value hidden=state[kHidden];
  if(fresh){result.target_hidden=f.inputs.size();hidden=f.input(sem::dense({1,model::kHidden},c::DataType::kBFloat16));}
  result.ordinary_inputs=f.inputs.size();
  const auto p=parameters(r,source);
  const auto embedding=f.one(c::Operation(c::Gather{}),
      {external(r,source.words.at(vocabulary::Role::kEmbedding)),state[kPending]});
  const auto prefix=model::append_prefix(f,hidden,embedding,p);
  glm_original_moe_fragment::Parameters moe;
  moe.router=external(r,source.experts.router);moe.bias=external(r,source.experts.bias);
  for(std::size_t leg=0;leg<3;++leg) {
    moe.shared[leg]=external(r,source.experts.shared[leg]);
    moe.banks[leg]=f.input(expert::resident_description(static_cast<expert::Leg>(leg),kMoe));
  }
  moe.map=f.input(sem::dense({kMoe.experts},c::DataType::kInt32));
  result.model=model::append_step(f,prefix,
      {.main=state[kMain],.codes=state[kCodes],.scales=state[kScales],.selection=state[kSelection],.positions=state[kCursor]},
      p,moe,{.visible=std::int64_t(position)+1,.selected=kSelected,.fresh=fresh});
  const auto change=[&](Entry entry,Value value){result.state_ports[entry]=expose(result,value);};
  change(kMain,result.model->state.main);change(kHidden,result.model->hidden);change(kPending,result.model->pending);
  const auto next=increment(f,state[kCursor]);change(kCursor,next);
  if(fresh) {
    change(kCodes,result.model->state.codes);change(kScales,result.model->state.scales);
    change(kSelection,result.model->state.selection);change(kIndexCursor,next);
    change(kLag,f.constant(sem::dense({1},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>{0})));
  } else {
    change(kJournal,f.one(c::Operation(c::Scatter{}),{state[kJournal],state[kLag],prefix.input_norm.stored}));
    change(kJournalPositions,f.one(c::Operation(c::Scatter{}),{state[kJournalPositions],state[kLag],state[kCursor]}));
    change(kLag,increment(f,state[kLag]));
  }
  const auto probe=[&](Value &value){observe_port(result,value);};
  result.model->ports.visit_values(probe);
  result.model->feed_forward.ports.visit_values(probe);
  return result;
}
Step build_catchup(const Source &source) {
  Step result;
  auto &r=result.recipe;auto &f=r.fragment;
  f.profile=&d5_moe_semantic_fragments::profiles::glm53_official;f.region=0x474c4d50524f4348ULL;f.quantized=true;
  const auto desc=descriptions();
  std::array<Value,kResources> state;
  for(std::size_t i=0;i<state.size();++i)state[i]=f.input(desc[i]);
  result.ordinary_inputs=f.inputs.size();
  const auto zero=f.constant(sem::dense({1},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>{0}));
  const auto input=f.one(c::Operation(c::Gather{}),{state[kJournal],zero});
  const auto position=f.one(c::Operation(c::Gather{}),{state[kJournalPositions],zero});
  result.catchup=model::append_index_history(f,input,position,state[kCodes],state[kScales],parameters(r,source));
  result.state_ports[kCodes]=expose(result,result.catchup->codes);
  result.state_ports[kScales]=expose(result,result.catchup->scales);
  result.state_ports[kIndexCursor]=expose(result,increment(f,state[kIndexCursor]));
  result.state_ports[kLag]=expose(result,zero);
  const auto probe=[&](Value &value){observe_port(result,value);};result.catchup->visit_values(probe);
  return result;
}

struct Epoch final {std::uint64_t epoch,selection_position,reuses;};
static_assert(sizeof(Epoch)==24);
struct State final {
  c::StateSchema schema;
  c::StateStore store;
  std::array<c::StateEntryId,kEntries> entries;
  std::size_t peak_backing=0;
  static State create(const c::StorageOwner &owner,std::size_t budget) {
    State result;const auto desc=descriptions();
    std::array<c::StateEntrySpec,kEntries> specs;
    for(std::size_t i=0;i<kResources;++i)specs[i]={.description=desc[i],.resource=owner.ref()};
    specs[kEpoch]={.kind=c::StateEntryKind::kHostMetadata,.metadata_bytes=sizeof(Epoch)};
    result.schema=take(c::StateSchema::create(specs),"complete original Pro state schema");
    result.store=take(c::StateStore::create(result.schema,{.max_versions=20,.max_drafts=2,.max_retained_blocks=192,
        .max_backing_bytes=budget}),"bounded original Pro state store");
    for(std::size_t i=0;i<result.entries.size();++i)result.entries[i]=take(result.schema.entry(i),"Pro state entry");
    return result;
  }
  c::ReadLease member(const c::StateVersion &version,Entry entry) const {
    return take(version.member(entries[entry]),"actual Pro continuation member");
  }
  std::int32_t scalar(const c::StateVersion &version,Entry entry) const {return values<std::int32_t>(member(version,entry)).at(0);}
  Epoch epoch(const c::StateVersion &version) const {
    const auto raw=read(member(version,kEpoch));Epoch result{};
    if(raw.size()!=sizeof(result))throw std::runtime_error("Pro state metadata extent");
    std::memcpy(&result,raw.data(),raw.size());return result;
  }
  c::StateVersion stage(const c::StateVersion &from,const Step &step,std::span<const c::ReadLease> outputs,std::uint64_t iteration) {
    auto draft=take(store.begin(from),"complete Pro candidate state");
    for(std::size_t i=0;i<kResources;++i)
      if(step.state_ports[i]!=kAbsent)check(draft.replace(entries[i],outputs[step.state_ports[i]]),"stage actual Pro result");
    auto facts=epoch(from);
    if(step.fresh)facts={iteration,std::uint64_t(scalar(from,kCursor)),0};
    else if(step.model)++facts.reuses;
    check(draft.replace_metadata(entries[kEpoch],std::as_bytes(std::span(&facts,1))),"stage Pro iteration identity");
    auto result=take(draft.finalize(),"finalize complete Pro candidate");
    peak_backing=std::max(peak_backing,store.stats().backing_bytes);return result;
  }
};

void require_observed(bool passed,const char *where) {
  if(!passed)throw std::runtime_error(std::string("original Pro observation: ")+where);
}
void same_storage(const c::ReadLease &first,const c::ReadLease &second) {
  const auto a=take(first.view(),"first actual Pro storage"),b=take(second.view(),"second actual Pro storage");
  EXPECT_EQ(a.resource(),b.resource());EXPECT_EQ(a.native_handle(),b.native_handle());
  EXPECT_EQ(a.offset(),b.offset());EXPECT_EQ(a.size(),b.size());EXPECT_EQ(first.generation(),second.generation());
}
using Image=std::array<Bytes,kEntries>;
Image image(const State &state,const c::StateVersion &version) {
  Image result;for(std::size_t i=0;i<kEntries;++i)result[i]=read(state.member(version,static_cast<Entry>(i)));
  return result;
}
std::vector<std::uint16_t> fixture_bfloat(std::size_t count,std::size_t salt) {
  std::vector<std::uint16_t> result(count);
  for(std::size_t i=0;i<count;++i)result[i]=glm_original_indexer_reference::detail::bfloat(
      float(int((i*37+salt*17)%257)-128)/128.0F);
  return result;
}
void add_bound(std::size_t &total,std::size_t bytes) {
  if(bytes>std::numeric_limits<std::size_t>::max()-total)throw std::runtime_error("Pro bounded backing sum overflow");
  total+=bytes;
}
std::size_t aligned_bound(std::size_t bytes) {
  if(bytes>std::numeric_limits<std::size_t>::max()-255)throw std::runtime_error("Pro initial backing alignment overflow");
  return (bytes+255)/256*256;
}

std::shared_ptr<Source> prepare_source(c::Context &context,const c::StorageOwner &owner,c::Queue &queue,bool cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
    ,const c::cuda::MemoryResource *device
#endif
    ) {
  const auto static_directory=directory("HYLE_GLM_PRO_DIR");
  const auto moe_directory=directory("HYLE_GLM_PRO_MOE_DIR");
  if(static_directory.empty()||moe_directory.empty())
    throw std::runtime_error("set HYLE_GLM_PRO_DIR and HYLE_GLM_PRO_MOE_DIR to authenticated original Pro parameters");
  auto result=std::make_shared<Source>();
  auto original=std::make_shared<const own::Data>(own::Data::load(static_directory));
  result->parameters=own::bind(original,owner);
  result->words=vocabulary::Vocabulary::bind(
      std::shared_ptr<const vocabulary::Data>(original,&original->vocabulary),owner);
  auto experts=std::make_shared<const expert::Data>(expert::Data::load(moe_directory,own::kMoeIndexSha256,kMoe));
  result->experts=expert::bind(std::move(experts),owner);
  {
    Recipe recipe;auto &f=recipe.fragment;
    f.profile=&d5_moe_semantic_fragments::profiles::glm53_official;f.region=0x474c4d50524f4b56ULL;f.quantized=true;
    const auto raw=external(recipe,result->parameters.at(own::Role::kKvB));
    const auto prepared=model::append_prepare_kv(f,raw);
    f.outputs={prepared.key,prepared.value};
    auto cold=Native::create(std::move(recipe),context,owner,cuda,1);
    const auto output=cold.execute(queue,{});
    require_observed(glm_pro_mtp_reference::expect_prepared_kv(*original,
        values<std::uint16_t>(output[0]),values<std::uint16_t>(output[1])),"global-macroblock KV decode and BF16 preparation");
    result->prepared[0]={"original Pro prepared BF16 key",sem::dense({model::kHeads,model::kLatent,model::kNope},c::DataType::kBFloat16),owner,output[0]};
    result->prepared[1]={"original Pro prepared BF16 value",sem::dense({model::kHeads,model::kValue,model::kLatent},c::DataType::kBFloat16),owner,output[1]};
    result->cold_submissions=cold.submissions;result->prepared_pool=std::move(cold.outputs);
  }
  // All cold readers have retired; retain only the two compact BF16 layouts
  // on device. Original mapped E4/SF bytes remain for identity and the oracle.
  result->parameters.roles[own::index(own::Role::kKvB)].lease={};
#if defined(HYLE_TEST_GLM_STATE_CUDA)
  if(cuda) {
    if(!device)throw std::runtime_error("original Pro experts need the same actual typed CUDA resource");
    result->cuda_supply=std::make_unique<supply::CudaSupply>(take(
        supply::CudaSupply::create(context,owner,*device,kMoe),"bounded original Pro CUDA expert supply"));
  } else
#endif
  result->cpu_supply=std::make_unique<supply::CpuSupply>(take(supply::CpuSupply::create(owner,kMoe),
      "bounded original Pro CPU expert supply"));
  return result;
}

struct Initial final {
  Step step;
  glm_official_index_cache::Quantized encoded;
  std::size_t codes=0,scales=0;
};
Initial build_initial() {
  Initial result;auto &f=result.step.recipe.fragment;
  f.profile=&d5_moe_semantic_fragments::profiles::glm53_official;f.region=0x474c4d50524f494eULL;
  const auto input=f.input(sem::dense({kBasePosition,model::kIndexDepth},c::DataType::kBFloat16));
  result.step.ordinary_inputs=1;
  result.encoded=glm_official_index_cache::quantize(f,model::cast(f,input,c::DataType::kFloat32),kBasePosition);
  const auto old_codes=f.constant(sem::dense({kCapacity,model::kIndexDepth},c::DataType::kFloat8E4M3FN),
      sem::bytes(std::vector<std::uint8_t>(std::size_t(kCapacity*model::kIndexDepth),0x7f)));
  const auto old_scales=f.constant(sem::dense({kCapacity,1}),
      sem::bytes(std::vector<float>(std::size_t(kCapacity),std::numeric_limits<float>::quiet_NaN())));
  std::vector<std::int32_t> prefix(std::size_t(kBasePosition),0);std::iota(prefix.begin(),prefix.end(),0);
  const auto indices=f.constant(sem::dense({kBasePosition},c::DataType::kInt32),sem::bytes(prefix));
  result.codes=expose(result.step,f.one(c::Operation(c::Scatter{}),{old_codes,indices,result.encoded.codes}));
  result.scales=expose(result.step,f.one(c::Operation(c::Scatter{}),{old_scales,indices,result.encoded.scale}));
  for(const auto value:{result.encoded.codes,result.encoded.scale,result.encoded.rotated,
      result.encoded.transformed,result.encoded.input})(void)expose(result.step,value);
  return result;
}
std::array<c::ReadLease,kResources> initial_members(const c::StorageOwner &owner,
    const Initial &initial,std::span<const c::ReadLease> output) {
  std::array<c::ReadLease,kResources> result;
  const auto desc=descriptions();
  std::vector<float> main(std::size_t(kCapacity*model::kCacheDepth),std::numeric_limits<float>::quiet_NaN());
  const auto finite=fixture_bfloat(std::size_t(kBasePosition*model::kCacheDepth),3);
  for(std::size_t i=0;i<finite.size();++i)main[i]=glm_shared_vocabulary_reference::detail::finite_bfloat(finite[i]);
  result[kMain]=upload(owner,sem::bytes(main));result[kCodes]=output[initial.codes];result[kScales]=output[initial.scales];
  result[kHidden]=upload(owner,sem::bytes(fixture_bfloat(std::size_t(model::kHidden),5)));
  const auto scalar=[&](Entry entry,std::int32_t value){result[entry]=upload(owner,sem::bytes(std::vector<std::int32_t>{value}));};
  scalar(kPending,1);scalar(kCursor,std::int32_t(kBasePosition));scalar(kIndexCursor,std::int32_t(kBasePosition));
  std::vector<std::int32_t> selected(std::size_t(kSelected),0);std::iota(selected.begin(),selected.end(),0);
  result[kSelection]=upload(owner,sem::bytes(selected));
  result[kJournal]=upload(owner,sem::bytes(std::vector<std::uint16_t>(std::size_t(kJournalRows*model::kHidden),0)));
  result[kJournalPositions]=upload(owner,sem::bytes(std::vector<std::int32_t>(std::size_t(kJournalRows),-1)));
  scalar(kLag,0);
  for(std::size_t i=0;i<result.size();++i)EXPECT_EQ(result[i].size(),take(desc[i].required_bytes(),"initial Pro resource extent"));
  return result;
}

template<class Outputs>
Bytes observed(const Step &step,std::span<const c::ReadLease> input,const Outputs &output,Value value) {
  const auto found=std::find_if(step.observations.begin(),step.observations.end(),
      [&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
  if(found!=step.observations.end())return read(output.at(found->second));
  const auto argument=std::find_if(step.recipe.fragment.inputs.begin(),step.recipe.fragment.inputs.end(),
      [&](Value entry){return entry.ordinal()==value.ordinal();});
  if(argument==step.recipe.fragment.inputs.end()||std::size_t(argument-step.recipe.fragment.inputs.begin())>=input.size())
    throw std::runtime_error("Pro observation lost its actual ordinary input or independent Copy");
  return read(input[std::size_t(argument-step.recipe.fragment.inputs.begin())]);
}
void exact_row(State &state,const c::StateVersion &before,const c::StateVersion &after,
    Entry entry,std::size_t row,std::size_t row_bytes,std::span<const std::byte> actual_update) {
  auto expected=read(state.member(before,entry));
  if(row>=expected.size()/row_bytes||actual_update.size()!=row_bytes)throw std::runtime_error("Pro actual row update extent");
  std::copy(actual_update.begin(),actual_update.end(),expected.begin()+std::ptrdiff_t(row*row_bytes));
  EXPECT_EQ(read(state.member(after,entry)),expected)<<"only the actual produced absolute cache row may change";
}
std::vector<c::ReadLease> arguments(State &state,const c::StateVersion &version,const Step &step,
    const c::ReadLease &target={}) {
  std::vector<c::ReadLease> result;
  for(std::size_t i=0;i<kResources;++i)result.push_back(state.member(version,static_cast<Entry>(i)));
  if(step.fresh) {
    if(!target)throw std::runtime_error("fresh Pro consumes an explicit previous target tap fixture");
    result.push_back(target);
  }
  return result;
}
void validate_step(State &state,const c::StateVersion &version,const Step &step) {
  const auto cursor=state.scalar(version,kCursor),index=state.scalar(version,kIndexCursor),lag=state.scalar(version,kLag);
  if(step.catchup) {
    if(lag!=1||index+1!=cursor||values<std::int32_t>(state.member(version,kJournalPositions)).at(0)!=index)
      throw std::runtime_error("finite Pro catchup requires exactly one accepted pending index row");
  } else {
    if(cursor!=step.position||index+lag!=cursor||lag<0||lag>=kJournalRows)
      throw std::runtime_error("actual Pro cursor/index frontier differs from this cold step");
    if(step.fresh&&lag!=0)throw std::runtime_error("fresh Pro must catch up accepted journal rows first");
  }
}
template<class Execute>
c::StateVersion execute_step(State &state,const c::StateVersion &before,const Step &step,
    Source &source,std::uint64_t iteration,Execute execute,const c::ReadLease &target={}) {
  validate_step(state,before,step);
  const auto input=arguments(state,before,step,target);
  const auto output=execute(input);
  const auto actual=[&](Value value){return observed(step,input,output,value);};
  if(step.model) {
    const auto token=state.scalar(before,kPending);
    require_observed(glm_pro_mtp_reference::observe(*source.parameters.source,*step.model,actual,!source.full_checked,token),
        "original complete Pro NextN actual predecessors");
    require_observed(observe_moe(source,step.model->feed_forward,actual),"original complete Pro MoE");
    source.full_checked=true;++source.checked_steps;
  } else if(step.catchup) {
    require_observed(glm_pro_mtp_reference::observe_index_history(*source.parameters.source,*step.catchup,actual,false),
        "accepted actual Pro journal catchup");
  }
  auto after=state.stage(before,step,output,iteration);
  for(std::size_t i=0;i<kResources;++i) {
    const auto entry=static_cast<Entry>(i);
    if(step.state_ports[i]==kAbsent)same_storage(state.member(after,entry),state.member(before,entry));
    else same_storage(state.member(after,entry),output.at(step.state_ports[i]));
  }
  if(step.model) {
    const auto row=glm_pro_mtp_reference::detail::widen(
        glm_pro_mtp_reference::detail::bfloats(actual(step.model->ports.attention.row_stored)));
    exact_row(state,before,after,kMain,std::size_t(step.position),std::size_t(model::kCacheDepth)*4,sem::bytes(row));
    EXPECT_EQ(state.scalar(after,kCursor),step.position+1);
    if(step.fresh) {
      const auto &history=step.model->ports.index->history;
      exact_row(state,before,after,kCodes,std::size_t(step.position),std::size_t(model::kIndexDepth),actual(history.encoded.codes));
      exact_row(state,before,after,kScales,std::size_t(step.position),4,actual(history.encoded.scale));
      EXPECT_EQ(state.scalar(after,kIndexCursor),step.position+1);EXPECT_EQ(state.scalar(after,kLag),0);
      EXPECT_EQ(state.epoch(after).epoch,iteration);EXPECT_EQ(state.epoch(after).reuses,0u);
    } else {
      const auto slot=std::size_t(state.scalar(before,kLag));
      exact_row(state,before,after,kJournal,slot,std::size_t(model::kHidden)*2,actual(step.model->ports.prefix.input_norm.stored));
      const std::array<std::int32_t,1> position{step.position};
      exact_row(state,before,after,kJournalPositions,slot,4,std::as_bytes(std::span(position)));
      EXPECT_EQ(state.scalar(after,kLag),state.scalar(before,kLag)+1);
      EXPECT_EQ(state.epoch(after).reuses,state.epoch(before).reuses+1);
    }
    const auto selected=values<std::int32_t>(state.member(after,kSelection));
    EXPECT_EQ(selected.size(),std::size_t(kSelected));
    for(const auto id:selected)if(id<0||id>step.position)throw std::runtime_error("Pro selected a future/poison row or Flash-expanded ID");
  } else {
    const auto position=std::size_t(state.scalar(before,kIndexCursor));
    exact_row(state,before,after,kCodes,position,std::size_t(model::kIndexDepth),actual(step.catchup->encoded.codes));
    exact_row(state,before,after,kScales,position,4,actual(step.catchup->encoded.scale));
    EXPECT_EQ(state.scalar(after,kIndexCursor),state.scalar(before,kCursor));EXPECT_EQ(state.scalar(after,kLag),0);
    same_storage(state.member(after,kMain),state.member(before,kMain));
    same_storage(state.member(after,kSelection),state.member(before,kSelection));
  }
  return after;
}

struct Verifier final {
  Recipe recipe;
  std::array<std::size_t,2> pending{};
  std::size_t logits=0,scores=0,ids=0,reject=0;
};
Verifier build_verifier(const Source &source) {
  Verifier result;auto &f=result.recipe.fragment;
  f.profile=&d5_moe_semantic_fragments::profiles::glm53_official;f.region=0x474c4d50524f5646ULL;
  const auto taps=f.input(sem::dense({2,model::kHidden},c::DataType::kBFloat16));
  const auto p=glm_target_verifier_fragment::append(f,taps,
      external(result.recipe,source.words.at(vocabulary::Role::kHead)),model::kHidden,model::kVocabulary);
  const auto publish=[&](Value value) {
    const auto port=f.outputs.size();f.outputs.push_back(f.one(c::Operation(c::Copy{}),{value}));return port;
  };
  result.logits=publish(p.logits);result.scores=publish(p.scores);result.ids=publish(p.ids);
  for(std::size_t row=0;row<2;++row)result.pending[row]=publish(p.row_ids[row]);
  // The second ranked REAL target row supplies a distinct actual I32 proposal
  // only to the explicit rejection control. It is never a hand-uploaded ID.
  const auto first=model::slice(f,p.logits,0,0,1);
  const auto top2=f.append(c::Operation(c::TopK{.count=2,.stable=true}),{first},2);
  result.reject=publish(model::reshape(f,model::slice(f,top2[1],1,1,1),{1}));
  return result;
}

void report_head(const Native &program,const Source &source,bool cuda) {
  const auto &graph=program.logical.graph;
  std::size_t heads=0;
  for(const auto &constant:program.recipe.external) {
    if(constant.role.description!=sem::dense({model::kVocabulary,model::kHidden},c::DataType::kBFloat16))continue;
    same_storage(constant.role.lease,source.words.at(vocabulary::Role::kHead).lease);
    const auto head=program.logical.constants.at(constant.slot);
    for(std::size_t step=0;step<program.compiled.report.step_count();++step) {
      const auto selected=take(program.compiled.report.step(step),"original Pro head selected provider");
      for(std::size_t slot=0;slot<selected.node_count;++slot) {
        const auto node=take(program.compiled.report.step_node(step,slot),"actual Pro head implementation node");
        const auto operation=take(graph.operation(node),"actual Pro head operation");
        if(!operation.custom_as<c::model_ops::BFloatLinearF32>())continue;
        if(take(graph.node_input(node,1),"actual Pro head original readonly bank")!=head)continue;
        const auto activation=take(graph.node_input(node,0),"actual Pro normalized BF16 head input");
        const auto description=take(graph.value_description(activation),"actual Pro head BF16 input description");
        if(description.data_type()!=c::DataType::kBFloat16||description.rank()!=2||description.dimensions()[1]!=model::kHidden||
            (cuda&&selected.provider.name!="cublasLt"))
          throw std::runtime_error("original Pro head must retain BF16 operands and its native full-V provider");
        ++heads;::testing::Test::RecordProperty("head_provider",std::string(selected.provider.name));
      }
    }
  }
  if(heads!=1)throw std::runtime_error("each Pro prediction/verifier needs one shared full-V BF16 head implementation");
}

void run(c::Context &context,const c::StorageOwner &owner,bool cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
    ,const c::cuda::MemoryResource *device=nullptr
#endif
    ) {
  auto queue=take(context.create_queue(),"ordinary original Pro queue");
  auto source=prepare_source(context,owner,queue,cuda
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      ,device
#endif
      );
  // Hold every ordinary Invocation inside this scope, before closing the
  // shared bounded supplier. No completed Invocation retains a compact slot.
  [&] {
    auto initializer=build_initial();
    auto initial_program=Native::create(initializer.step.recipe,context,owner,cuda,1);
    const auto keys=fixture_bfloat(std::size_t(kBasePosition*model::kIndexDepth),7);
    const auto key_lease=upload(owner,sem::bytes(keys));
    const std::array initial_input{key_lease};
    auto initial_output=initial_program.execute(queue,initial_input);
    const auto initial_actual=[&](Value value){return observed(initializer.step,initial_input,initial_output,value);};
    require_observed(glm_pro_mtp_reference::detail::quantized(initializer.encoded,keys,
        std::size_t(kBasePosition),initial_actual),"actual initial prefix Hadamard/BF16/E4/UE8M0");
    auto members=initial_members(owner,initializer,initial_output);

    auto first_step=build_step(*source,true,std::int32_t(kBasePosition));
    auto second_step=build_step(*source,false,std::int32_t(kBasePosition+1));
    auto continuation_zero=build_step(*source,true,std::int32_t(kBasePosition+1));
    auto continuation_one=build_step(*source,true,std::int32_t(kBasePosition+2));
    auto skip_zero=build_step(*source,false,std::int32_t(kBasePosition+2));
    auto skip_one=build_step(*source,false,std::int32_t(kBasePosition+3));
    const auto resident=[&](const Step &step) {
      return Resident::create(step.recipe,step.model->feed_forward.boundary,source,context,owner,cuda);
    };
    auto first_program=resident(first_step),second_program=resident(second_step);
    auto continuation_zero_program=resident(continuation_zero),continuation_one_program=resident(continuation_one);
    auto skip_zero_program=resident(skip_zero),skip_one_program=resident(skip_one);
    std::array<Resident*,6> model_programs{&first_program,&second_program,&continuation_zero_program,
        &continuation_one_program,&skip_zero_program,&skip_one_program};
    for(const auto *program:model_programs) {
      std::size_t heads=0;
      for(const auto &phase:program->phases) {
        const auto contains=std::any_of(phase.recipe.external.begin(),phase.recipe.external.end(),[&](const External &entry) {
          return entry.role.description==source->words.at(vocabulary::Role::kHead).description;
        });
        if(contains){report_head(phase,*source,cuda);++heads;}
      }
      if(heads!=1)throw std::runtime_error("Pro cold cut changed full-V prediction ownership");
    }
    auto catchup_step=build_catchup(*source);
    auto catchup_program=Native::create(catchup_step.recipe,context,owner,cuda);
    auto verifier=build_verifier(*source);
    auto verifier_program=Native::create(verifier.recipe,context,owner,cuda,1);
    report_head(verifier_program,*source,cuda);

    std::size_t pools=initial_program.outputs.stats().capacity_bytes;
    for(const auto *program:model_programs)add_bound(pools,program->backing_capacity());
    add_bound(pools,catchup_program.outputs.stats().capacity_bytes);
    add_bound(pools,verifier_program.outputs.stats().capacity_bytes);
    std::size_t initial_bound=0;
    for(std::size_t i=0;i<kResources;++i)if(i!=kCodes&&i!=kScales)add_bound(initial_bound,aligned_bound(members[i].size()));
    // Charge each real Program pool root ONCE, including all generations and
    // diagnostic outputs in that root. The independent initial buffers have
    // an aligned conservative bound; two encoded initial states share the
    // initializer root already counted above. Readonly weights are not state.
    constexpr std::size_t metadata_bound=16384;
    std::size_t budget=pools;add_bound(budget,initial_bound);add_bound(budget,metadata_bound);
    auto state=State::create(owner,budget);
    const auto target_before=upload(owner,sem::bytes(fixture_bfloat(std::size_t(model::kHidden),11)));
    const std::array next_targets{
        upload(owner,sem::bytes(fixture_bfloat(std::size_t(model::kHidden),13))),
        upload(owner,sem::bytes(fixture_bfloat(std::size_t(model::kHidden),17)))};
    auto tap_bits=fixture_bfloat(std::size_t(2*model::kHidden),19);
    const auto target_taps=upload(owner,sem::bytes(tap_bits));
    const std::array verifier_input{target_taps};
    const auto checked=verifier_program.execute(queue,verifier_input);
    const auto target_logits=values<float>(checked[verifier.logits]);
    const auto target_scores=values<float>(checked[verifier.scores]);
    const auto target_ids=values<std::int32_t>(checked[verifier.ids]);
    require_observed(glm_shared_vocabulary_reference::expect_logits(target_logits,tap_bits,
        source->words.source->bytes(vocabulary::Role::kHead),std::size_t(model::kVocabulary),
        std::size_t(model::kHidden),true,target_ids),"actual full-V R2 target-tap projection");
    require_observed(glm_shared_vocabulary_reference::expect_greedy(target_logits,target_ids,
        std::size_t(model::kVocabulary),target_scores),"actual full-V R2 target greedy");
    for(std::size_t row=0;row<2;++row)EXPECT_EQ(values<std::int32_t>(checked[verifier.pending[row]]).at(0),target_ids.at(row));
    const auto reject_id=values<std::int32_t>(checked[verifier.reject]).at(0);
    const auto top2=glm_shared_vocabulary_reference::detail::candidates(std::span<const float>(target_logits).first(std::size_t(model::kVocabulary)));
    EXPECT_EQ(reject_id,std::int32_t(top2.at(1)));EXPECT_NE(reject_id,target_ids.at(0));
    std::size_t feedback=0,catchups=0,skips=0,cancelled=0,stale_publish=0;
    std::array<std::size_t,2> accepted{};
    std::uint32_t natural_accepted=0;std::int32_t natural_proposal=0;
    {
      Epoch initial_epoch{6,std::uint64_t(kBasePosition-1),0};
      std::array<c::StateMember,kEntries> initial;
      for(std::size_t i=0;i<kResources;++i)initial[i]={state.entries[i],members[i]};
      initial[kEpoch]={state.entries[kEpoch],{},std::as_bytes(std::span(&initial_epoch,1))};
      const auto base=take(state.store.import(initial),"import complete original Pro continuation");
      const auto base_image=image(state,base);
      EXPECT_THROW(validate_step(state,base,catchup_step),std::runtime_error);
      const auto first=execute_step(state,base,first_step,*source,7,
          [&](std::span<const c::ReadLease> input){return first_program.execute(queue,input,cuda);},target_before);
      ++feedback;
      const auto first_image=image(state,first);
      // One natural trial and two separately labelled controls. Matching uses
      // the actual full-V Top1 lease; rejection uses the actual distinct Top2
      // lease. The second real Graph consumes precisely that proposal lease.
      for(int scenario=0;scenario<3;++scenario) {
        {
          auto first_checkpoint=first;
          if(scenario) {
            auto controlled=take(state.store.begin(first),"explicit controlled proposal policy");
            check(controlled.replace(state.entries[kPending],checked[scenario==1?verifier.pending[0]:verifier.reject]),
                "controlled proposal retains actual target Top1/Top2 I32 output");
            first_checkpoint=take(controlled.finalize(),"controlled actual pending checkpoint");
          }
          const auto proposal=state.scalar(first_checkpoint,kPending);
          const auto first_checkpoint_image=image(state,first_checkpoint);
          const auto second=execute_step(state,first_checkpoint,second_step,*source,7,
              [&](std::span<const c::ReadLease> input){return second_program.execute(queue,input,cuda);});
          ++feedback;++skips;
          const auto second_image=image(state,second);
          const auto decision=glm_target_verifier_fragment::decide_k1(proposal,target_ids,model::kVocabulary);
          if(scenario==0){natural_proposal=proposal;natural_accepted=decision.accepted_drafts;}
          else EXPECT_EQ(decision.accepted_drafts,scenario==1?1u:0u);
          ++accepted.at(decision.accepted_drafts);
          const auto &checkpoint=decision.checkpoint==glm_target_verifier_fragment::Checkpoint::kAfterCurrent?
              first_checkpoint:second;
          auto head=take(c::StateHead::create(state.store,base),"one atomic Pro accepted Head");
          {
            auto discarded=take(state.store.begin(checkpoint),"cancelled Pro acceptance draft");
            check(discarded.replace(state.entries[kPending],checked[verifier.pending[decision.next_pending_row]]),"cancelled actual pending lease");
            check(discarded.cancel(),"cancel whole uncommitted Pro acceptance");++cancelled;
            EXPECT_EQ(image(state,take(head.current(),"cancelled Pro draft cannot change Head")),base_image);
          }
          auto acceptance=take(state.store.begin(checkpoint),"all-resource K1 Pro acceptance");
          check(acceptance.replace(state.entries[kPending],checked[verifier.pending[decision.next_pending_row]]),"direct actual target row pending lease");
          const auto published=take(acceptance.finalize(),"complete K1 Pro accepted checkpoint");
          check(head.publish(base.identity(),published),"atomically publish Pro accepted prefix and pending");
          EXPECT_FALSE(head.publish(base.identity(),second).ok());++stale_publish;
          const auto published_image=image(state,published);
          EXPECT_EQ(state.scalar(published,kCursor),std::int32_t(kBasePosition+1+decision.accepted_drafts));
          EXPECT_EQ(state.scalar(published,kIndexCursor),std::int32_t(kBasePosition+1));
          EXPECT_EQ(state.scalar(published,kLag),std::int32_t(decision.accepted_drafts));
          EXPECT_EQ(state.scalar(published,kPending),decision.next_pending);
          same_storage(state.member(published,kPending),checked[verifier.pending[decision.next_pending_row]]);
          for(std::size_t i=0;i<kResources;++i)if(i!=kPending)
            same_storage(state.member(published,static_cast<Entry>(i)),state.member(checkpoint,static_cast<Entry>(i)));
          auto caught=published;
          if(decision.accepted_drafts) {
            caught=execute_step(state,published,catchup_step,*source,7,
                [&](std::span<const c::ReadLease> input){return catchup_program.execute(queue,input);});
            ++catchups;check(head.publish(published.identity(),caught),"same accepted Head catches up its one journal row");
          } else EXPECT_THROW(validate_step(state,published,catchup_step),std::runtime_error);
          EXPECT_EQ(state.scalar(caught,kLag),0);EXPECT_EQ(state.scalar(caught,kCursor),state.scalar(caught,kIndexCursor));
          require_observed(glm_shared_vocabulary_reference::expect_feedback(values<std::int32_t>(state.member(caught,kPending)),
              values<std::int32_t>(checked[verifier.pending[decision.next_pending_row]])),"actual target pending enters next embedding");
          auto &next_step=decision.accepted_drafts?continuation_one:continuation_zero;
          auto &next_program=decision.accepted_drafts?continuation_one_program:continuation_zero_program;
          const auto continued=execute_step(state,caught,next_step,*source,8,
              [&](std::span<const c::ReadLease> input){return next_program.execute(queue,input,cuda);},next_targets[decision.accepted_drafts]);
          ++feedback;check(head.publish(caught.identity(),continued),"publish actual accepted-frontier fresh seed in the same Head");
          const auto continued_image=image(state,continued);
          const auto seed=take(head.current(),"actual accepted fresh Pro seed");
          EXPECT_EQ(seed.identity(),continued.identity());EXPECT_EQ(state.epoch(seed).epoch,8u);
          EXPECT_EQ(state.epoch(seed).selection_position,std::uint64_t(next_step.position));
          EXPECT_EQ(state.epoch(seed).reuses,0u);
          auto &step_zero=decision.accepted_drafts?skip_one:skip_zero;
          auto &zero_program=decision.accepted_drafts?skip_one_program:skip_zero_program;
          const auto skipped=execute_step(state,seed,step_zero,*source,8,
              [&](std::span<const c::ReadLease> input){return zero_program.execute(queue,input,cuda);});
          ++feedback;++skips;
          same_storage(state.member(skipped,kSelection),state.member(seed,kSelection));
          same_storage(state.member(skipped,kCodes),state.member(seed,kCodes));
          EXPECT_EQ(state.epoch(skipped).epoch,8u);EXPECT_EQ(state.epoch(skipped).reuses,1u);
          EXPECT_EQ(state.scalar(skipped,kLag),1);
          EXPECT_EQ(image(state,take(head.current(),"unverified step0 stays unpublished")),continued_image);
          EXPECT_EQ(image(state,published),published_image);EXPECT_EQ(image(state,first_checkpoint),first_checkpoint_image);
          EXPECT_EQ(image(state,second),second_image);EXPECT_EQ(image(state,base),base_image);EXPECT_EQ(image(state,first),first_image);
          EXPECT_FALSE(state.member(published,kPending).try_write());EXPECT_FALSE(state.member(continued,kMain).try_write());
          EXPECT_LE(state.peak_backing,budget);
          std::printf("GLM Pro K1 scenario=%d proposal=%d target0=%d target1=%d accepted=%u frontier=%d pending=%d\n",
              scenario,proposal,target_ids[0],target_ids[1],decision.accepted_drafts,state.scalar(published,kCursor),decision.next_pending);
        }
        check(state.store.collect(),"retire finite Pro scenario while retaining base/first readers");
        EXPECT_EQ(state.store.stats().versions,2u);EXPECT_EQ(state.store.stats().drafts,0u);
      }
    }
    members={};initial_output.clear();
    check(state.store.collect(),"retire complete Pro state journey");
    EXPECT_EQ(state.store.stats().versions,0u);EXPECT_EQ(state.store.stats().drafts,0u);
    EXPECT_GT(accepted[0],0u);EXPECT_GT(accepted[1],0u);
    EXPECT_EQ(source->checked_steps,source->episodes);EXPECT_EQ(feedback,source->checked_steps);
    EXPECT_TRUE(source->full_checked);EXPECT_TRUE(source->moe_full_checked);
    std::size_t submissions=source->cold_submissions;
    add_bound(submissions,initial_program.submissions);add_bound(submissions,catchup_program.submissions);
    add_bound(submissions,verifier_program.submissions);
    for(const auto *program:model_programs)add_bound(submissions,program->native_submissions());
    std::size_t ready=0;
    for(const auto &role:source->parameters.roles)if(role.lease) {
      add_bound(ready,role.lease.size());EXPECT_EQ(role.owner.ref(),owner.ref());EXPECT_FALSE(role.lease.try_write());
    }
    for(const auto &role:source->words.roles){add_bound(ready,role.lease.size());EXPECT_EQ(role.owner.ref(),owner.ref());EXPECT_FALSE(role.lease.try_write());}
    for(const auto &role:source->prepared){add_bound(ready,role.lease.size());EXPECT_FALSE(role.lease.try_write());}
    EXPECT_FALSE(source->parameters.at(own::Role::kKvB).lease);
    ::testing::Test::RecordProperty("actual_submissions",std::to_string(submissions));
    ::testing::Test::RecordProperty("full_original_nextn_roles",1571);
    ::testing::Test::RecordProperty("full_original_nextn_source_bytes","13838963840");
    ::testing::Test::RecordProperty("actual_nextn_steps",std::to_string(source->checked_steps));
    ::testing::Test::RecordProperty("actual_pending_embedding_feedback_checks",std::to_string(feedback));
    ::testing::Test::RecordProperty("actual_index_catchup_steps",std::to_string(catchups));
    ::testing::Test::RecordProperty("actual_skip_steps",std::to_string(skips));
    ::testing::Test::RecordProperty("accepted_zero_draft_checkpoints",std::to_string(accepted[0]));
    ::testing::Test::RecordProperty("accepted_one_draft_checkpoints",std::to_string(accepted[1]));
    ::testing::Test::RecordProperty("natural_k1_trials",1);
    ::testing::Test::RecordProperty("natural_k1_proposal",natural_proposal);
    ::testing::Test::RecordProperty("natural_k1_accepted_drafts",int(natural_accepted));
    ::testing::Test::RecordProperty("controlled_matching_trials",1);
    ::testing::Test::RecordProperty("controlled_rejection_trials",1);
    ::testing::Test::RecordProperty("cancelled_unpublished_drafts",std::to_string(cancelled));
    ::testing::Test::RecordProperty("rejected_stale_publishes",std::to_string(stale_publish));
    ::testing::Test::RecordProperty("first_full_nextn_head_reference_values",std::to_string(model::kVocabulary));
    ::testing::Test::RecordProperty("target_first_full_reference_values",std::to_string(2*model::kVocabulary));
    ::testing::Test::RecordProperty("target_verifier_submissions",std::to_string(verifier_program.submissions));
    ::testing::Test::RecordProperty("state_budget_bytes",std::to_string(budget));
    ::testing::Test::RecordProperty("state_pool_backing_bound",std::to_string(pools));
    ::testing::Test::RecordProperty("state_initial_backing_bound",std::to_string(initial_bound));
    ::testing::Test::RecordProperty("state_metadata_backing_bound",std::to_string(metadata_bound));
    ::testing::Test::RecordProperty("peak_state_backing_bytes",std::to_string(state.peak_backing));
    ::testing::Test::RecordProperty("ready_non_moe_bank_capacity_bytes",std::to_string(ready));
    ::testing::Test::RecordProperty("prepared_kv_capacity_bytes",std::to_string(source->prepared[0].lease.size()+source->prepared[1].lease.size()));
    ::testing::Test::RecordProperty("resident_expert_domain",int(kMoe.experts));
    ::testing::Test::RecordProperty("resident_expert_capacity",int(kMoe.slots));
    ::testing::Test::RecordProperty("resident_slot_capacity_bytes",std::to_string(glm_moe_geometry::layout(kMoe).slot_bytes));
    std::string unions;
    for(const auto &selected:source->selections){if(!unions.empty())unions+=",";unions+=std::to_string(selected.globals.size());}
    ::testing::Test::RecordProperty("actual_resident_union_sizes",unions);
    ::testing::Test::RecordProperty("component_schema","11 resources plus Epoch24 metadata: mainF32[2064,576] BF16widen CKV512+KPE64, unpooled E4[2064,128]+F32scale, BF16hidden6144, I32pending/cursors/2048absoluteIDs, BF16journal3 and positions/lag; one StateHead");
    ::testing::Test::RecordProperty("pending_policy","Natural K1 uses actual NextN proposal and full-V R2 target-tap head. Controlled match/reject consume real target Top1/Top2 proposal leases in the actual second Graph, separate from natural acceptance. accept0 retains after-current first; accept1 after-proposal second; pending directly retains target row[accepted]. Only accepted lag1 is caught up; next fresh epoch8 publishes before unverified skip0 remains unpublished.");
    ::testing::Test::RecordProperty("scope","Official original GLM-5.3 aca966 Pro layer78 complete1571 roles including untied full154880 BF16 vocabulary. Original H6144 Qrank2048 NoPE192+RoPE64/latent512/value256, unpooled indexTop2048 and non-fused Hadamard/BF16/UE8M0, BF16weights_proj F32acc, original256-domain Top8 MoE with actual selected E4/SF experts, scale2.5 and no Flash clip10. Ordinary two-phase Graphs, same native resource and bounded double-slot supply, direct activation/state leases, all actual store/route/merge/fullV gates. Initial prepared history and previous/final target taps are explicit synthetic external fixtures; not a complete78-layer trained target, vendor physical-cache ABI, quality/natural-acceptance benchmark or TPS. Capacity/upload accounting is not measured physical peak.");
  }();
#if defined(HYLE_TEST_GLM_STATE_CUDA)
  if(source->cuda_supply)check(source->cuda_supply->close(),"close original Pro uploads after all ordinary readers retire");
#endif
  if(source->cpu_supply) {
    EXPECT_EQ(source->cpu_supply->stats().live_blocks,0u);EXPECT_EQ(source->cpu_supply->stats().active_uses,0u);
  }
}

#if defined(HYLE_TEST_GLM_STATE_CUDA)
struct SharedCudaDevice final {
  std::shared_ptr<c::cuda::MemoryResource> resource;
  m::MemoryResourceRef ref() noexcept{return resource->ref();}
};
TEST(GlmProMtpStateConsumer,CudaOriginalNextNFullVocabularyPublishesAndCatchesUp) {
  auto context=take(g::cuda::create_context(),"original Pro CUDA Context");
  auto device=std::make_shared<c::cuda::MemoryResource>(take(c::cuda::MemoryResource::create(
      context,c::cuda::MemoryKind::kDevice),"same actual original Pro CUDA allocation domain"));
  const auto owner=take(c::StorageOwner::adopt(context,SharedCudaDevice{device}),"shared original Pro CUDA owner");
  run(context,owner,true,device.get());
}
#endif
#if defined(HYLE_TEST_GLM_STATE_CPU)
struct SystemResource final {m::MemoryResourceRef ref() noexcept{return m::system_resource();}};
TEST(GlmProMtpStateConsumer,CpuOriginalNextNFullVocabularyPublishesAndCatchesUp) {
  auto context=take(g::cpu::create_context(),"original Pro CPU Context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"shared original Pro CPU owner");
  run(context,owner,false);
}
#endif

} // namespace
