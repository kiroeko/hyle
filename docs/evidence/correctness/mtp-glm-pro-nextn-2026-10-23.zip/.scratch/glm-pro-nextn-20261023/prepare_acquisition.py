"""Reuse bounded exact-range protocols for the pinned original Pro roles."""
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[1]
BU = R / '.scratch/glm-original-target43-20261023'
moe = (BU / 'fetch_moe.py').read_text(encoding='utf-8')
moe = moe.replace('GLM layer43 MoE', 'GLM Pro layer78 MoE')
moe = moe.replace('1736', '1544').replace('7277059200', '9706940416')
moe = moe.replace('expert0..287', 'expert0..255').replace('assert len(index)==27840', "assert len(index)==64+16*plan['original_roles']")
(S / 'fetch_moe.py').write_text(moe, encoding='utf-8')
static = (BU / 'fetch_static.py').read_text(encoding='utf-8')
static = static.replace('26 pinned GLM Flash original target43 static roles',
                        '27 pinned GLM Pro original NextN and shared vocabulary roles')
static = static.replace('original-target43', 'original-static')
static = static.replace('150779608', '4132023424').replace('original_roles=26', 'original_roles=27')
(S / 'fetch_static.py').write_text(static, encoding='utf-8')
print('PREPARED original Pro exact-range fetchers; no acquisition started', flush=True)
