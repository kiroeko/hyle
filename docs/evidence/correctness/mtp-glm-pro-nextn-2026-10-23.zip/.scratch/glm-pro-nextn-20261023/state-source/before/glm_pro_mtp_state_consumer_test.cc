#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <functional>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "hyle/compute/model_ops.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/storage_owner.h"
#include "hyle/compute/state_versions.h"
#if defined(HYLE_TEST_GLM_STATE_CPU)
#include "hyle/graph/cpu.h"
#endif
#if defined(HYLE_TEST_GLM_STATE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#endif
#include "glm_pro_mtp_fragment.h"
#include "glm_pro_original_roles.h"
#include "glm_pro_mtp_reference.h"
#include "glm_original_moe_roles.h"
#include "glm_original_moe_reference.h"
#include "glm_original_moe_resident_weights.h"
#include "glm_shared_vocabulary.h"
#include "glm_target_verifier_fragment.h"
#include "model_graph_run.h"
#include "model_resident_fragment.h"

namespace {
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace model=glm_pro_mtp_fragment;
namespace own=glm_pro_original_roles;
namespace vocabulary=glm_shared_vocabulary;
namespace expert=glm_original_moe_roles;
namespace supply=glm_original_moe_resident_weights;
namespace cut=model_resident_fragment;
using Value=sem::ValueId;
using Bytes=std::vector<std::byte>;
using Readonly=vocabulary::ReadonlyRole;
inline constexpr auto kMoe=glm_moe_geometry::kPro;
inline constexpr std::int64_t kCapacity=2064,kBasePosition=2053,kSelected=2048,kJournalRows=3;

template<class T> T take(hyle::Result<T> result,const char *where) {
  if(!result)throw std::runtime_error(std::string(where)+": "+std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status,const char *where) {
  if(!status.ok())throw std::runtime_error(std::string(where)+": "+std::string(status.message()));
}
Bytes read(const c::ReadLease &lease) {
  Bytes bytes(lease.size());check(take(lease.view(),"read actual Pro lease").read(bytes),"read Pro bytes");return bytes;
}
template<class T> std::vector<T> values(const c::ReadLease &lease) {
  const auto raw=read(lease);
  if(raw.size()%sizeof(T))throw std::runtime_error("Pro typed lease byte extent");
  std::vector<T> result(raw.size()/sizeof(T));std::memcpy(result.data(),raw.data(),raw.size());return result;
}
c::ReadLease upload(const c::StorageOwner &owner,std::span<const std::byte> bytes) {
  auto buffer=take(m::Buffer::create(owner.ref(),bytes.size(),256),"initial/immutable Pro backing");
  check(buffer.view().write(bytes),"initial/immutable Pro upload");
  return take(owner.adopt_buffer(std::move(buffer)),"initial/immutable Pro permission");
}
std::string directory(const char *name) {
#if defined(_WIN32)
  char *value=nullptr;std::size_t count=0;
  if(_dupenv_s(&value,&count,name))throw std::runtime_error("original Pro directory environment");
  const std::unique_ptr<char,decltype(&std::free)> cleanup(value,&std::free);return value?value:"";
#else
  const auto *value=std::getenv(name);return value?value:"";
#endif
}

struct External final {std::size_t slot;Readonly role;};
struct Recipe final {
  sem::Fragment fragment;
  std::vector<External> external;
};
Value external(Recipe &recipe,const Readonly &role) {
  const auto slot=recipe.fragment.constants.size();
  const auto value=recipe.fragment.constant(role.description,{});
  recipe.external.push_back({slot,role});return value;
}

// This holder compiles ordinary public Graphs. The shared model_graph_run
// function owns their bind/prepare/submit/retire/reset procedure; model state,
// original roles and expert frontiers are not part of an alternate executor.
struct Native final {
  Recipe recipe;
  sem::GraphCase logical;
  std::vector<c::ReadLease> parameters;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool outputs;
  std::vector<model_graph_run::Port> input_ports,output_ports;
  std::size_t submissions=0;
  static Native create(Recipe recipe,c::Context &context,const c::StorageOwner &owner,
                       bool cuda,std::uint32_t generations=3) {
    Native result;result.recipe=std::move(recipe);result.logical=sem::make_graph(result.recipe.fragment);
    std::vector<g::ConstantBinding> constants;
    for(std::size_t slot=0;slot<result.logical.constants.size();++slot) {
      const auto found=std::find_if(result.recipe.external.begin(),result.recipe.external.end(),
          [&](const External &entry){return entry.slot==slot;});
      const auto &desc=result.recipe.fragment.description(result.recipe.fragment.constants[slot]);
      if(found!=result.recipe.external.end()) {
        if(found->role.description!=desc||found->role.owner.ref()!=owner.ref())
          throw std::runtime_error("Pro immutable constant changed description or actual owner");
        constants.push_back(take(found->role.binding(result.logical.constants[slot]),"actual ready Pro constant owner"));
      } else {
        result.parameters.push_back(upload(owner,result.recipe.fragment.constant_bytes[slot]));
        constants.push_back({result.logical.constants[slot],take(result.parameters.back().tensor(desc),"actual generated Pro constant")});
      }
    }
    const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*result.recipe.fragment.profile),"actual Pro artifact profile"),
        c::WorkloadPhase::kDecode,{0x48594c454d4f444cULL,result.recipe.fragment.region,1}};
    const g::CompileOptions options{.constants=constants,.workload=workload};
    const auto compile=[&]()->hyle::Result<g::CompiledGraph> {
#if defined(HYLE_TEST_GLM_STATE_CPU)
      if(!cuda)return g::cpu::compile(result.logical.graph,context,options);
#endif
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      if(cuda)return g::cuda::compile(result.logical.graph,context,owner,options);
#endif
      throw std::runtime_error("original Pro native backend is unavailable");
    };
    result.compiled=take(compile(),"ordinary original Pro Graph compile");
    for(std::size_t slot=0;slot<result.logical.inputs.size();++slot)
      result.input_ports.push_back({result.logical.inputs[slot],result.recipe.fragment.description(result.recipe.fragment.inputs[slot])});
    std::size_t capacity=0;
    for(std::size_t slot=0;slot<result.logical.outputs.size();++slot) {
      if(take(result.compiled.executable.output_ownership(slot),"Pro output ownership")!=g::OutputOwnership::kCaller)
        throw std::runtime_error("Pro results must retain independent caller-owned storage");
      const auto &desc=result.recipe.fragment.description(result.recipe.fragment.outputs[slot]);
      const auto bytes=take(desc.required_bytes(),"Pro output extent");
      if(bytes>std::numeric_limits<std::size_t>::max()-255||capacity>std::numeric_limits<std::size_t>::max()-(bytes+255)/256*256)
        throw std::runtime_error("Pro output backing capacity overflow");
      capacity+=(bytes+255)/256*256;
      result.output_ports.push_back({result.logical.outputs[slot],desc});
    }
    if(!generations||capacity>std::numeric_limits<std::size_t>::max()/generations||
        result.output_ports.size()>std::numeric_limits<std::uint32_t>::max()/generations)
      throw std::runtime_error("Pro result generations exceed representable capacity");
    result.invocation=take(result.compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"ordinary Pro Invocation");
    result.outputs=take(c::LeasePool::create(owner.ref(),capacity*generations,
        {.max_blocks=std::uint32_t(result.output_ports.size())*generations,.backing_alignment=256}),"bounded Pro result generations");
    return result;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue,std::span<const c::ReadLease> inputs,
      std::span<const std::size_t> externally_bound={},const std::function<void(g::Invocation&)> &binder={}) {
    return model_graph_run::execute(invocation,outputs,queue,input_ports,inputs,output_ports,submissions,externally_bound,binder);
  }
};

struct Source final {
  own::Bound parameters;
  vocabulary::Vocabulary words;
  std::array<Readonly,2> prepared;
  c::LeasePool prepared_pool;
  expert::Roles experts;
  std::unique_ptr<supply::CpuSupply> cpu_supply;
#if defined(HYLE_TEST_GLM_STATE_CUDA)
  std::unique_ptr<supply::CudaSupply> cuda_supply;
#endif
  bool full_checked=false,moe_full_checked=false;
  std::size_t cold_submissions=0,episodes=0,checked_steps=0;
  std::vector<expert::Selection> selections;
};

model::Parameters parameters(Recipe &recipe,const Source &source) {
  const auto bank=[&](own::Role role){return external(recipe,source.parameters.at(role));};
  return {.eh=bank(own::Role::kEh),.embedding_norm=bank(own::Role::kEmbeddingNorm),
      .hidden_norm=bank(own::Role::kHiddenNorm),.input_norm=bank(own::Role::kInputNorm),
      .post_norm=bank(own::Role::kPostNorm),.index_bias=bank(own::Role::kIndexBias),
      .index_norm=bank(own::Role::kIndexNorm),.index_weights=bank(own::Role::kIndexWeights),
      .index_key=bank(own::Role::kIndexKey),.index_query=bank(own::Role::kIndexQuery),
      .kv_norm=bank(own::Role::kKvNorm),.kv_a=bank(own::Role::kKvA),.output=bank(own::Role::kOutput),
      .query_norm=bank(own::Role::kQueryNorm),.query_a=bank(own::Role::kQueryA),.query_b=bank(own::Role::kQueryB),
      .shared_norm=external(recipe,source.words.at(vocabulary::Role::kNorm)),
      .head=external(recipe,source.words.at(vocabulary::Role::kHead)),
      .prepared_key=external(recipe,source.prepared[0]),.prepared_value=external(recipe,source.prepared[1])};
}

// One router frontier cuts a pure model Fragment into the same two ordinary
// native Graphs used by Flash. Only its actual8 global IDs reach the bounded
// supplier. Activations and state cross the cut as original producer leases.
struct Resident final {
  std::shared_ptr<Source> source;
  Recipe recipe;
  cut::ResidentDraft<glm_original_moe_fragment::Boundary,1> plan;
  std::vector<Native> phases;
  static Resident create(Recipe recipe,const glm_original_moe_fragment::Boundary &boundary,
      std::shared_ptr<Source> source,c::Context &context,const c::StorageOwner &owner,bool cuda,
      std::uint32_t generations=3) {
    Resident result;result.source=std::move(source);result.recipe=std::move(recipe);
    result.plan=cut::split(result.recipe.fragment,std::array{boundary},0x474c4d50524f5048ULL);
    std::vector<Readonly> ready;
    for(std::size_t slot=0;slot<result.recipe.fragment.constants.size();++slot) {
      const auto found=std::find_if(result.recipe.external.begin(),result.recipe.external.end(),
          [&](const External &entry){return entry.slot==slot;});
      if(found!=result.recipe.external.end())ready.push_back(found->role);
      else ready.push_back({"Pro cold component constant",
          result.recipe.fragment.description(result.recipe.fragment.constants[slot]),owner,
          upload(owner,result.recipe.fragment.constant_bytes[slot])});
    }
    for(const auto &phase:result.plan.phases) {
      Recipe local;local.fragment=phase.fragment;
      for(std::size_t slot=0;slot<phase.original_constants.size();++slot) {
        const auto original=phase.original_constants[slot];
        const auto found=std::find_if(result.recipe.fragment.constants.begin(),result.recipe.fragment.constants.end(),
            [&](Value value){return value.ordinal()==original.ordinal();});
        if(found==result.recipe.fragment.constants.end())throw std::runtime_error("Pro cold cut lost immutable constant");
        const auto index=std::size_t(found-result.recipe.fragment.constants.begin());
        local.external.push_back({slot,ready.at(index)});
      }
      result.phases.push_back(Native::create(std::move(local),context,owner,cuda,generations));
    }
    return result;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue,std::span<const c::ReadLease> inputs,bool cuda) {
    (void)cuda;
    if(inputs.size()+4!=recipe.fragment.inputs.size())throw std::runtime_error("Pro ordinary/resident input count");
    std::vector<c::ReadLease> live(recipe.fragment.descriptions.size());
    for(std::size_t i=0;i<inputs.size();++i)live.at(recipe.fragment.inputs[i].ordinal())=inputs[i];
    std::array<std::vector<c::ReadLease>,2> completed;
    for(std::size_t index=0;index<phases.size();++index) {
      const auto &phase=plan.phases[index];
      std::optional<supply::CpuBatch> cpu_batch;
      std::optional<expert::Selection> selection;
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      std::optional<c::cuda::WeightBatch> cuda_batch;
      std::array<g::WeightBinding,4> bindings;
#endif
      std::array<std::size_t,4> dynamic{};
      std::span<const std::size_t> external_ports;
      std::function<void(g::Invocation&)> binder;
      if(phase.resident_stage) {
        const auto &frontier=plan.routers.at(*phase.resident_stage);
        selection=expert::select(values<std::int32_t>(live.at(frontier.ids.ordinal())),kMoe);
        const std::array banks{frontier.banks[0],frontier.banks[1],frontier.banks[2],frontier.map};
        for(std::size_t bank=0;bank<banks.size();++bank) {
          const auto found=std::find_if(phase.original_inputs.begin(),phase.original_inputs.end(),
              [&](Value value){return value.ordinal()==banks[bank].ordinal();});
          if(found==phase.original_inputs.end())throw std::runtime_error("Pro cut lost actual compressed bank or map");
          dynamic[bank]=std::size_t(found-phase.original_inputs.begin());
#if defined(HYLE_TEST_GLM_STATE_CUDA)
          bindings[bank]={phases[index].logical.inputs.at(dynamic[bank]),supply::kBankIds[bank]};
#endif
        }
#if defined(HYLE_TEST_GLM_STATE_CUDA)
        if(cuda) {
          if(!source->cuda_supply)throw std::runtime_error("Pro needs its actual shared CUDA supply");
          cuda_batch.emplace(take(source->cuda_supply->upload(source->episodes%2,*selection,*source->experts.source,queue),
              "same-generation original Pro experts/map"));
          external_ports=dynamic;
          binder=[&](g::Invocation &active){check(g::cuda::bind(active,bindings,*cuda_batch),"bind actual Pro expert generation");};
        } else
#endif
        {
          if(!source->cpu_supply)throw std::runtime_error("Pro needs its actual shared CPU supply");
          cpu_batch.emplace(take(source->cpu_supply->upload(*selection,*source->experts.source),"actual Pro CPU expert generation"));
          for(std::size_t bank=0;bank<banks.size();++bank)live.at(banks[bank].ordinal())=cpu_batch->banks[bank];
        }
      }
      std::vector<c::ReadLease> arguments;
      for(const auto original:phase.original_inputs)arguments.push_back(live.at(original.ordinal()));
      completed[index]=phases[index].execute(queue,arguments,external_ports,binder);
      for(std::size_t slot=0;slot<phase.original_outputs.size();++slot)
        live.at(phase.original_outputs[slot].ordinal())=completed[index][slot];
      if(selection) {
        source->selections.push_back(std::move(*selection));
#if defined(HYLE_TEST_GLM_STATE_CUDA)
        if(cuda_batch) {
          const auto accounting=take(cuda_batch->report(),"actual Pro upload accounting");
          const auto layout=source->cuda_supply->layout();
          EXPECT_EQ(accounting.logical_bytes,layout.logical_bytes);EXPECT_EQ(accounting.staged_bytes,layout.logical_bytes);
          EXPECT_EQ(accounting.completed_bytes,accounting.submitted_bytes);EXPECT_FALSE(accounting.copied_bytes_unknown);
        }
#endif
      }
      // The shared ordinary run helper has waited/reset before the compact
      // generation can be dropped and either of the two slots reused.
    }
    std::vector<c::ReadLease> outputs;
    for(const auto location:plan.full_outputs)outputs.push_back(completed.at(location.phase).at(location.port));
    ++source->episodes;return outputs;
  }
  std::size_t native_submissions() const {
    std::size_t result=0;for(const auto &phase:phases)result+=phase.submissions;return result;
  }
  std::size_t backing_capacity() const {
    std::size_t result=0;for(const auto &phase:phases)result+=phase.outputs.stats().capacity_bytes;return result;
  }
};

enum Entry:std::size_t {
  kMain,kCodes,kScales,kHidden,kPending,kCursor,kIndexCursor,kSelection,
  kJournal,kJournalPositions,kLag,kResources,kEpoch=kResources,kEntries
};
std::array<c::TensorDesc,kResources> descriptions() {
  return {sem::dense({kCapacity,model::kCacheDepth}),
      sem::dense({kCapacity,model::kIndexDepth},c::DataType::kFloat8E4M3FN),sem::dense({kCapacity,1}),
      sem::dense({1,model::kHidden},c::DataType::kBFloat16),sem::dense({1},c::DataType::kInt32),
      sem::dense({1},c::DataType::kInt32),sem::dense({1},c::DataType::kInt32),
      sem::dense({kSelected},c::DataType::kInt32),
      sem::dense({kJournalRows,model::kHidden},c::DataType::kBFloat16),
      sem::dense({kJournalRows},c::DataType::kInt32),sem::dense({1},c::DataType::kInt32)};
}
Value increment(sem::Fragment &f,Value value) {
  const auto one=f.constant(sem::dense({1},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>{1}));
  const auto scan=f.one(c::Operation(c::Scan{.axis=0}),
      {f.one(c::Operation(c::Concat{.axis=0}),{value,one})});
  return f.one(c::Operation(c::Gather{}),{scan,one});
}
constexpr auto kAbsent=std::numeric_limits<std::size_t>::max();
struct Step final {
  Recipe recipe;
  std::optional<model::Result> model;
  std::optional<model::IndexHistory> catchup;
  std::vector<std::pair<Value,std::size_t>> observations;
  std::array<std::size_t,kResources> state_ports;
  std::size_t ordinary_inputs=0,target_hidden=kAbsent;
  std::int32_t position=0;
  bool fresh=false;
  Step(){state_ports.fill(kAbsent);}
};
std::size_t expose(Step &step,Value value) {
  const auto found=std::find_if(step.observations.begin(),step.observations.end(),
      [&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
  if(found!=step.observations.end())return found->second;
  auto &f=step.recipe.fragment;const auto port=f.outputs.size();
  f.outputs.push_back(f.one(c::Operation(c::Copy{}),{value}));
  step.observations.push_back({value,port});return port;
}
void observe_port(Step &step,Value &value) {
  const auto &inputs=step.recipe.fragment.inputs;
  const auto found=std::find_if(inputs.begin(),inputs.end(),[&](Value input){return input.ordinal()==value.ordinal();});
  if(found!=inputs.end()&&std::size_t(found-inputs.begin())<step.ordinary_inputs)return;
  (void)expose(step,value);
}
Step build_step(const Source &source,bool fresh,std::int32_t position) {
  if(position<kBasePosition||position>=kCapacity)throw std::runtime_error("Pro step is outside the finite prepared domain");
  Step result;result.fresh=fresh;result.position=position;
  auto &r=result.recipe;auto &f=r.fragment;
  f.profile=&d5_moe_semantic_fragments::profiles::glm53_official;
  f.region=0x474c4d50524f5354ULL+std::uint64_t(position-kBasePosition)*2+std::uint64_t(fresh);f.quantized=true;
  std::array<Value,kResources> state;
  const auto desc=descriptions();
  for(std::size_t i=0;i<state.size();++i)state[i]=f.input(desc[i]);
  Value hidden=state[kHidden];
  if(fresh){result.target_hidden=f.inputs.size();hidden=f.input(sem::dense({1,model::kHidden},c::DataType::kBFloat16));}
  result.ordinary_inputs=f.inputs.size();
  const auto p=parameters(r,source);
  const auto embedding=f.one(c::Operation(c::Gather{}),
      {external(r,source.words.at(vocabulary::Role::kEmbedding)),state[kPending]});
  const auto prefix=model::append_prefix(f,hidden,embedding,p);
  glm_original_moe_fragment::Parameters moe;
  moe.router=external(r,source.experts.router);moe.bias=external(r,source.experts.bias);
  for(std::size_t leg=0;leg<3;++leg) {
    moe.shared[leg]=external(r,source.experts.shared[leg]);
    moe.banks[leg]=f.input(expert::resident_description(static_cast<expert::Leg>(leg),kMoe));
  }
  moe.map=f.input(sem::dense({kMoe.experts},c::DataType::kInt32));
  result.model=model::append_step(f,prefix,
      {.main=state[kMain],.codes=state[kCodes],.scales=state[kScales],.selection=state[kSelection],.positions=state[kCursor]},
      p,moe,{.visible=std::int64_t(position)+1,.selected=kSelected,.fresh=fresh});
  const auto change=[&](Entry entry,Value value){result.state_ports[entry]=expose(result,value);};
  change(kMain,result.model->state.main);change(kHidden,result.model->hidden);change(kPending,result.model->pending);
  const auto next=increment(f,state[kCursor]);change(kCursor,next);
  if(fresh) {
    change(kCodes,result.model->state.codes);change(kScales,result.model->state.scales);
    change(kSelection,result.model->state.selection);change(kIndexCursor,next);
    change(kLag,f.constant(sem::dense({1},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>{0})));
  } else {
    change(kJournal,f.one(c::Operation(c::Scatter{}),{state[kJournal],state[kLag],prefix.input_norm.stored}));
    change(kJournalPositions,f.one(c::Operation(c::Scatter{}),{state[kJournalPositions],state[kLag],state[kCursor]}));
    change(kLag,increment(f,state[kLag]));
  }
  const auto probe=[&](Value &value){observe_port(result,value);};
  result.model->ports.visit_values(probe);
  result.model->feed_forward.ports.visit_values(probe);
  return result;
}
Step build_catchup(const Source &source) {
  Step result;
  auto &r=result.recipe;auto &f=r.fragment;
  f.profile=&d5_moe_semantic_fragments::profiles::glm53_official;f.region=0x474c4d50524f4348ULL;f.quantized=true;
  const auto desc=descriptions();
  std::array<Value,kResources> state;
  for(std::size_t i=0;i<state.size();++i)state[i]=f.input(desc[i]);
  result.ordinary_inputs=f.inputs.size();
  const auto zero=f.constant(sem::dense({1},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>{0}));
  const auto input=f.one(c::Operation(c::Gather{}),{state[kJournal],zero});
  const auto position=f.one(c::Operation(c::Gather{}),{state[kJournalPositions],zero});
  result.catchup=model::append_index_history(f,input,position,state[kCodes],state[kScales],parameters(r,source));
  result.state_ports[kCodes]=expose(result,result.catchup->codes);
  result.state_ports[kScales]=expose(result,result.catchup->scales);
  result.state_ports[kIndexCursor]=expose(result,increment(f,state[kIndexCursor]));
  result.state_ports[kLag]=expose(result,zero);
  const auto probe=[&](Value &value){observe_port(result,value);};result.catchup->visit_values(probe);
  return result;
}

struct Epoch final {std::uint64_t epoch,selection_position,reuses;};
static_assert(sizeof(Epoch)==24);
struct State final {
  c::StateSchema schema;
  c::StateStore store;
  std::array<c::StateEntryId,kEntries> entries;
  std::size_t peak_backing=0;
  static State create(const c::StorageOwner &owner,std::size_t budget) {
    State result;const auto desc=descriptions();
    std::array<c::StateEntrySpec,kEntries> specs;
    for(std::size_t i=0;i<kResources;++i)specs[i]={.description=desc[i],.resource=owner.ref()};
    specs[kEpoch]={.kind=c::StateEntryKind::kHostMetadata,.metadata_bytes=sizeof(Epoch)};
    result.schema=take(c::StateSchema::create(specs),"complete original Pro state schema");
    result.store=take(c::StateStore::create(result.schema,{.max_versions=20,.max_drafts=2,.max_retained_blocks=192,
        .max_backing_bytes=budget}),"bounded original Pro state store");
    for(std::size_t i=0;i<result.entries.size();++i)result.entries[i]=take(result.schema.entry(i),"Pro state entry");
    return result;
  }
  c::ReadLease member(const c::StateVersion &version,Entry entry) const {
    return take(version.member(entries[entry]),"actual Pro continuation member");
  }
  std::int32_t scalar(const c::StateVersion &version,Entry entry) const {return values<std::int32_t>(member(version,entry)).at(0);}
  Epoch epoch(const c::StateVersion &version) const {
    const auto raw=read(member(version,kEpoch));Epoch result{};
    if(raw.size()!=sizeof(result))throw std::runtime_error("Pro state metadata extent");
    std::memcpy(&result,raw.data(),raw.size());return result;
  }
  c::StateVersion stage(const c::StateVersion &from,const Step &step,std::span<const c::ReadLease> outputs,std::uint64_t iteration) {
    auto draft=take(store.begin(from),"complete Pro candidate state");
    for(std::size_t i=0;i<kResources;++i)
      if(step.state_ports[i]!=kAbsent)check(draft.replace(entries[i],outputs[step.state_ports[i]]),"stage actual Pro result");
    auto facts=epoch(from);
    if(step.fresh)facts={iteration,std::uint64_t(scalar(from,kCursor)),0};
    else if(step.model)++facts.reuses;
    check(draft.replace_metadata(entries[kEpoch],std::as_bytes(std::span(&facts,1))),"stage Pro iteration identity");
    auto result=take(draft.finalize(),"finalize complete Pro candidate");
    peak_backing=std::max(peak_backing,store.stats().backing_bytes);return result;
  }
};

} // namespace
