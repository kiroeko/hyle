#pragma once

#include <array>
#include <cstdint>

#include "d5_moe_semantic_fragments.h"
#include "hyle/compute/model_ops.h"

// Model-local GLM Flash hyper-connections shared by ordinary target layers.
// Fixed06992 torch/unfused contract: raw F32 mixing projection, model-RMS
// epsilon1e-5, HC/Sinkhorn epsilon1e-6 and20 iterations, BF16 collapse before
// learned RMS, and BF16 post expansion. No parameter supplier or execution.
namespace glm_hyper_connection_fragment {
namespace c=hyle::compute;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace core=d5_moe_semantic_fragments;
using Value=sem::ValueId;
inline constexpr std::int64_t kHidden=4096,kStreams=4;
inline constexpr float kNormEpsilon=1.0e-5F,kHcEpsilon=1.0e-6F;

struct NormPorts final {
  Value input,raw,stored,visible;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&input,&raw,&stored,&visible})visitor(*value);
  }
};
struct HcPorts final {
  Value residual,flat,projection,square,mean,inverse,mixes,pre,post,combination;
  Value collapsed_raw,collapsed_stored;
  NormPorts norm;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&residual,&flat,&projection,&square,&mean,&inverse,&mixes,&pre,&post,&combination,&collapsed_raw,&collapsed_stored})visitor(*value);
    norm.visit_values(visitor);
  }
};
struct PostPorts final {
  Value branch,residual,raw,stored,visible;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&branch,&residual,&raw,&stored,&visible})visitor(*value);
  }
};
inline Value cast(sem::Fragment &f,Value input,c::DataType type) {
  return f.one(c::Operation(c::Cast{.output_type=type}),{input});
}
inline Value slice(sem::Fragment &f,Value input,std::int32_t axis,std::int64_t begin,std::int64_t count) {
  return f.one(c::Operation(c::View::slice(axis,begin,count).value()),{input});
}
inline Value compact(sem::Fragment &f,Value input) {return f.one(c::Operation(c::Copy{}),{input});}
inline Value reduce(sem::Fragment &f,Value input,std::int32_t axis,c::ReductionKind kind,bool keep=true) {
  return f.one(c::Operation(c::Reduce{.kind=kind,.axes=c::Axes::from(std::array{axis}).value(),
      .keep_dimensions=keep,.accumulation_type=c::DataType::kFloat32}),{input});
}
inline NormPorts norm(sem::Fragment &f,Value actual_bf16,Value gamma) {
  NormPorts result;result.input=cast(f,actual_bf16,c::DataType::kFloat32);
  result.raw=f.one(c::Operation(c::RmsNorm{.epsilon=kNormEpsilon}),
      {result.input,cast(f,gamma,c::DataType::kFloat32)});
  result.stored=cast(f,result.raw,c::DataType::kBFloat16);
  result.visible=cast(f,result.stored,c::DataType::kFloat32);return result;
}
inline HcPorts hc_pre(sem::Fragment &f,Value residual,Value fn,Value scale,Value base,Value norm_weight) {
  HcPorts result;result.residual=residual;
  const auto visible=cast(f,residual,c::DataType::kFloat32);
  result.flat=core::reshape(f,visible,{1,kStreams*kHidden});
  // Original parameters are F32 at runtime, even though hc_fn is BF16 on disk.
  // Normalize the actual raw projection, not a separately rounded normalized
  // input. The inverse-RMS epsilon is model1e-5, not HC/Sinkhorn1e-6.
  const auto transpose=f.one(c::Operation(c::View::permute(std::array<std::int32_t,2>{1,0}).value()),{fn});
  result.projection=f.one(c::Operation(c::MatMul{}),{result.flat,transpose});
  result.square=core::binary(f,c::BinaryKind::kMultiply,result.flat,result.flat);
  result.mean=reduce(f,result.square,-1,c::ReductionKind::kMean);
  result.inverse=core::unary(f,c::UnaryKind::kRsqrt,
      core::binary(f,c::BinaryKind::kAdd,result.mean,core::filled(f,sem::dense({1}),kNormEpsilon)));
  result.mixes=core::binary(f,c::BinaryKind::kMultiply,result.projection,result.inverse);
  result.combination=f.one(c::model_ops::hyper_connection_combine(kHcEpsilon,20),{result.mixes,scale,base});
  const auto gate=[&](std::int64_t first,std::int64_t scale_index) {
    const auto affine=core::binary(f,c::BinaryKind::kAdd,
        core::binary(f,c::BinaryKind::kMultiply,slice(f,result.mixes,1,first,kStreams),slice(f,scale,0,scale_index,1)),
        core::reshape(f,slice(f,base,0,first,kStreams),{1,kStreams}));
    return core::unary(f,c::UnaryKind::kSigmoid,affine);
  };
  result.pre=core::binary(f,c::BinaryKind::kAdd,gate(0,0),core::filled(f,sem::dense({1}),kHcEpsilon));
  result.post=core::binary(f,c::BinaryKind::kMultiply,gate(kStreams,1),core::filled(f,sem::dense({1}),2.0F));
  result.collapsed_raw=f.one(c::model_ops::hyper_connection_pre(),{visible,result.pre});
  result.collapsed_stored=cast(f,result.collapsed_raw,c::DataType::kBFloat16);
  // Explicitly choose fixed06992 _mhc_pre_torch + separate learned RMS.
  // TileLang fused norm uses a different raw-square/rounded-numerator order.
  result.norm=norm(f,result.collapsed_stored,norm_weight);return result;
}
inline PostPorts hc_post(sem::Fragment &f,const HcPorts &pre,Value residual,Value branch) {
  PostPorts result;result.branch=branch;result.residual=residual;
  result.raw=f.one(c::model_ops::hyper_connection_post(),
      {cast(f,branch,c::DataType::kFloat32),cast(f,residual,c::DataType::kFloat32),pre.post,pre.combination});
  result.stored=cast(f,result.raw,c::DataType::kBFloat16);
  result.visible=cast(f,result.stored,c::DataType::kFloat32);return result;
}
} // namespace glm_hyper_connection_fragment
