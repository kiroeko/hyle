#pragma once

#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <stdexcept>

#include "glm_hyper_connection_fragment.h"
#include "glm_original_moe_fragment.h"
#include "glm_original_target44_roles.h"

// Pure original GLM Flash layer44 construction. The caller binds distinct
// authenticated44 constants, compact selected expert banks and actual state.
// HC uses fixed06992's explicit torch/unfused path, including BF16 collapse
// before learned RMS; it does not claim TileLang fused-norm bit equivalence.
// KDA normalization is F32 inside the recurrent boundary, with BF16 convolution
// and recurrent/output-gate stores. There is no loader/provider/executor here.
namespace glm_original_target44_fragment {
namespace c=hyle::compute;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace core=d5_moe_semantic_fragments;
namespace roles=glm_original_target44_roles;
namespace moe_fragment=glm_original_moe_fragment;
namespace hc=glm_hyper_connection_fragment;
using Value=sem::ValueId;
using Role=roles::Role;
using ParameterValues=std::array<Value,static_cast<std::size_t>(Role::kCount)>;
inline constexpr std::int64_t kHidden=4096,kStreams=4,kHeads=64,kDepth=128;
inline constexpr std::int64_t kWidth=kHeads*kDepth,kChannels=3*kWidth;
using hc::kNormEpsilon;
using hc::kHcEpsilon;
inline constexpr float kL2Epsilon=1.0e-6F;

using hc::NormPorts;
using hc::HcPorts;
using hc::PostPorts;
struct ProjectionPorts final {
  Value input,raw,stored;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&input,&raw,&stored})visitor(*value);
  }
};
struct ConvPorts final {
  Value samples,raw,activated_raw,stored;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&samples,&raw,&activated_raw,&stored})visitor(*value);
  }
};
struct L2Ports final {
  Value input,square,sum,denominator,inverse,output;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&input,&square,&sum,&denominator,&inverse,&output})visitor(*value);
  }
};
enum class Projection : std::size_t {kQuery,kKey,kValue,kForgetA,kForgetB,kBeta,kGateA,kGateB,kOutput,kCount};
struct KdaPorts final {
  std::array<ProjectionPorts,static_cast<std::size_t>(Projection::kCount)> projections;
  std::array<ConvPorts,3> conv; // Q,K,V in original checkpoint role order.
  Value history_input,history_bf16,window,next_history;
  L2Ports query,key;
  Value value,alpha,forget_add,forget_product,forget_sigmoid,decay,beta;
  Value state_input,recurrent_raw,recurrent_stored,state_output;
  Value output_norm_input,output_norm_raw,gate_sigmoid,gated_raw,gated_stored;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto &projection:projections)projection.visit_values(visitor);
    for(auto &part:conv)part.visit_values(visitor);
    for(auto *v:{&history_input,&history_bf16,&window,&next_history})visitor(*v);
    query.visit_values(visitor);key.visit_values(visitor);
    for(auto *v:{&value,&alpha,&forget_add,&forget_product,&forget_sigmoid,&decay,&beta,
        &state_input,&recurrent_raw,&recurrent_stored,&state_output,&output_norm_input,&output_norm_raw,&gate_sigmoid,&gated_raw,&gated_stored})visitor(*v);
  }
};
struct Ports final {
  HcPorts attention_hc,ffn_hc;
  PostPorts attention_post,ffn_post;
  KdaPorts kda;
  Value contract_raw,contract_stored;
  NormPorts model_norm;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    attention_hc.visit_values(visitor);ffn_hc.visit_values(visitor);
    attention_post.visit_values(visitor);ffn_post.visit_values(visitor);kda.visit_values(visitor);
    visitor(contract_raw);visitor(contract_stored);model_norm.visit_values(visitor);
  }
};
struct Result final {
  Value history,state,mhc,tap; // F32 ABI carriers; state itself is recurrentF32.
  Ports ports;
  moe_fragment::Result moe;
};
using hc::cast;
using hc::slice;
using hc::compact;
using hc::reduce;
using hc::norm;
using hc::hc_pre;
using hc::hc_post;
inline ProjectionPorts project(sem::Fragment &f,Value input,Value weight) {
  ProjectionPorts result;result.input=input;
  result.raw=f.one(c::model_ops::bfloat_linear_f32(),{input,weight});
  result.stored=cast(f,result.raw,c::DataType::kBFloat16);return result;
}
inline L2Ports l2(sem::Fragment &f,Value actual_bf16) {
  L2Ports result;result.input=cast(f,actual_bf16,c::DataType::kFloat32);
  result.square=core::binary(f,c::BinaryKind::kMultiply,result.input,result.input);
  result.sum=reduce(f,result.square,-1,c::ReductionKind::kSum);
  result.denominator=core::binary(f,c::BinaryKind::kAdd,result.sum,core::filled(f,sem::dense({1}),kL2Epsilon));
  result.inverse=core::unary(f,c::UnaryKind::kRsqrt,result.denominator);
  result.output=core::binary(f,c::BinaryKind::kMultiply,result.input,result.inverse);
  return result; // F32 in-kernel Q/K, deliberately no extra BF16 store.
}
inline KdaPorts kda(sem::Fragment &f,Value input,Value history,Value state,const ParameterValues &parameters) {
  const auto parameter=[&](Role role){return parameters[static_cast<std::size_t>(role)];};
  KdaPorts result;result.history_input=history;result.state_input=state;
  const auto projection=[&](Projection slot,Value source,Role role) {
    auto &port=result.projections[static_cast<std::size_t>(slot)];port=project(f,source,parameter(role));return port.stored;
  };
  const std::array qkv{projection(Projection::kQuery,input,Role::kQuery),projection(Projection::kKey,input,Role::kKey),projection(Projection::kValue,input,Role::kValue)};
  const auto forget_a=projection(Projection::kForgetA,input,Role::kForgetA);
  const auto forget_b=projection(Projection::kForgetB,forget_a,Role::kForgetB);
  const auto beta_raw=projection(Projection::kBeta,input,Role::kBeta);
  const auto gate_a=projection(Projection::kGateA,input,Role::kGateA);
  const auto gate_b=projection(Projection::kGateB,gate_a,Role::kGateB);
  result.history_bf16=cast(f,history,c::DataType::kBFloat16);
  const auto joined=f.one(c::Operation(c::Concat{.axis=1}),{qkv[0],qkv[1],qkv[2]});
  result.window=f.one(c::Operation(c::Concat{.axis=0}),{result.history_bf16,joined});
  result.next_history=compact(f,slice(f,result.window,0,1,3));
  const std::array convolution_roles{Role::kQueryConv,Role::kKeyConv,Role::kValueConv};
  for(std::size_t leg=0;leg<result.conv.size();++leg) {
    auto &conv=result.conv[leg];
    conv.samples=core::reshape(f,compact(f,slice(f,result.window,1,std::int64_t(leg)*kWidth,kWidth)),{1,4,kWidth});
    conv.raw=f.one(c::model_ops::causal_conv1d(),{cast(f,conv.samples,c::DataType::kFloat32),parameter(convolution_roles[leg])});
    conv.activated_raw=core::unary(f,c::UnaryKind::kSilu,conv.raw);
    conv.stored=core::reshape(f,cast(f,conv.activated_raw,c::DataType::kBFloat16),{1,1,kHeads,kDepth});
  }
  result.query=l2(f,result.conv[0].stored);result.key=l2(f,result.conv[1].stored);
  result.value=cast(f,result.conv[2].stored,c::DataType::kFloat32);
  result.alpha=core::reshape(f,core::unary(f,c::UnaryKind::kExp,parameter(Role::kALog)),{1,1,kHeads,1});
  const auto forget=core::reshape(f,cast(f,forget_b,c::DataType::kFloat32),{1,1,kHeads,kDepth});
  result.forget_add=core::binary(f,c::BinaryKind::kAdd,forget,core::reshape(f,parameter(Role::kDtBias),{1,1,kHeads,kDepth}));
  result.forget_product=core::binary(f,c::BinaryKind::kMultiply,result.forget_add,result.alpha);
  result.forget_sigmoid=core::unary(f,c::UnaryKind::kSigmoid,result.forget_product);
  result.decay=core::binary(f,c::BinaryKind::kMultiply,result.forget_sigmoid,core::filled(f,sem::dense({1}),-5.0F));
  result.beta=core::unary(f,c::UnaryKind::kSigmoid,core::reshape(f,cast(f,beta_raw,c::DataType::kFloat32),{1,1,kHeads,1}));
  // Public GDN and the selected fixed06992 kernel store [H,V,K]. Keep that
  // orientation across accepted states; an external format needs a transpose
  // only if it explicitly declares a different [H,K,V] layout. Q/K and the
  // recurrent accumulation remain F32.
  const auto recurrent=f.append(c::Operation(c::GatedDeltaNet{}),
      {result.query.output,result.key.output,result.value,result.decay,result.beta,state},2);
  result.recurrent_raw=recurrent[0];result.state_output=recurrent[1];
  result.recurrent_stored=cast(f,result.recurrent_raw,c::DataType::kBFloat16);
  result.output_norm_input=cast(f,result.recurrent_stored,c::DataType::kFloat32);
  result.output_norm_raw=f.one(c::Operation(c::RmsNorm{.epsilon=kNormEpsilon}),
      {result.output_norm_input,cast(f,parameter(Role::kOutputNorm),c::DataType::kFloat32)});
  result.gate_sigmoid=core::unary(f,c::UnaryKind::kSigmoid,core::reshape(f,cast(f,gate_b,c::DataType::kFloat32),{1,1,kHeads,kDepth}));
  // Fused source output RMS/sigmoid gate has one final BF16 store, not a
  // separately rounded intermediate RMS output.
  result.gated_raw=core::binary(f,c::BinaryKind::kMultiply,result.output_norm_raw,result.gate_sigmoid);
  result.gated_stored=cast(f,result.gated_raw,c::DataType::kBFloat16);
  projection(Projection::kOutput,core::reshape(f,result.gated_stored,{1,kWidth}),Role::kOutput);
  return result;
}
inline Result append(sem::Fragment &f,Value actual_four_stream_bf16,Value history_f32,Value matrix_f32,
                      const ParameterValues &parameters,const moe_fragment::Parameters &moe_parameters) {
  const auto require=[&](Value value,const c::TensorDesc &expected) {
    if(value.ordinal()>=f.descriptions.size()||f.description(value)!=expected)
      throw std::runtime_error("original GLM44 actual parameter/activation/state geometry differs");
  };
  require(actual_four_stream_bf16,sem::dense({1,kStreams,kHidden},c::DataType::kBFloat16));
  require(history_f32,sem::dense({3,kChannels}));require(matrix_f32,sem::dense({1,kHeads,kDepth,kDepth}));
  for(std::size_t slot=0;slot<parameters.size();++slot) {
    require(parameters[slot],roles::description(static_cast<Role>(slot)));
    bool immutable=false;for(auto value:f.constants)if(value.ordinal()==parameters[slot].ordinal())immutable=true;
    if(!immutable)throw std::runtime_error("original GLM44 parameters must be immutable already-bound Graph constants");
  }
  const auto parameter=[&](Role role){return parameters[static_cast<std::size_t>(role)];};
  Result result;auto &ports=result.ports;
  ports.attention_hc=hc_pre(f,actual_four_stream_bf16,parameter(Role::kHcAttnFn),parameter(Role::kHcAttnScale),parameter(Role::kHcAttnBase),parameter(Role::kInputNorm));
  ports.kda=kda(f,ports.attention_hc.norm.stored,history_f32,matrix_f32,parameters);
  const auto branch=ports.kda.projections[static_cast<std::size_t>(Projection::kOutput)].stored;
  ports.attention_post=hc_post(f,ports.attention_hc,actual_four_stream_bf16,branch);
  ports.ffn_hc=hc_pre(f,ports.attention_post.stored,parameter(Role::kHcFfnFn),parameter(Role::kHcFfnScale),parameter(Role::kHcFfnBase),parameter(Role::kPostNorm));
  result.moe=moe_fragment::append(f,ports.ffn_hc.norm.stored,moe_parameters);
  ports.ffn_post=hc_post(f,ports.ffn_hc,ports.attention_post.stored,result.moe.output);
  ports.contract_raw=reduce(f,ports.ffn_post.visible,1,c::ReductionKind::kMean,false);
  ports.contract_stored=cast(f,ports.contract_raw,c::DataType::kBFloat16);
  ports.model_norm=norm(f,ports.contract_stored,parameter(Role::kModelNorm));
  result.history=cast(f,ports.kda.next_history,c::DataType::kFloat32);
  result.state=ports.kda.state_output;result.mhc=ports.ffn_post.visible;result.tap=ports.model_norm.visible;
  return result;
}
} // namespace glm_original_target44_fragment
