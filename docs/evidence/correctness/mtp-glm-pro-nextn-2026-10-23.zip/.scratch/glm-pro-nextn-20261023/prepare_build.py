"""Reuse the actual BU compiler/link/runtime closure for both GLM consumers."""
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[1]
BU = R / '.scratch/glm-original-target43-20261023'
text = (BU / 'build.py').read_text(encoding='utf-8')
text = text.replace('Incremental original GLM target43/44/NextN complete K1 consumers.',
                    'Incremental original GLM Pro NextN and affected Flash consumers.')
text = text.replace("BASE = R / '.scratch/glm-original-target44-20261023/tests-link1'",
                    "BASE = R / '.scratch/glm-original-target43-20261023/tests-link1'")
text = text.replace("'glm-state': R / '.scratch/glm-original-target44-20261023/compile1/glm-state/identity.json',",
    "'glm-state': R / '.scratch/glm-original-target43-20261023/compile1/glm-state/identity.json',\n"
    "    'glm-pro': R / '.scratch/glm-original-target43-20261023/compile1/glm-state/identity.json',")
text = text.replace("'glm-state': R / 'tests/compute_models/glm_mtp_state_consumer_test.cc',",
    "'glm-state': R / 'tests/compute_models/glm_mtp_state_consumer_test.cc',\n"
    "    'glm-pro': R / 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc',")
text = text.replace('glm-original-target43-checks.exe', 'glm-pro-nextn-checks.exe')
text = text.replace("env['HYLE_GLM_MTP_TARGET43_DIR'] = str(S / 'original-target43')",
    "env['HYLE_GLM_MTP_TARGET43_DIR'] = str(R / '.scratch/glm-original-target43-20261023/original-target43')")
text = text.replace("env['HYLE_GLM_MTP_TARGET43_MOE_DIR'] = str(S / 'original-moe')",
    "env['HYLE_GLM_MTP_TARGET43_MOE_DIR'] = str(R / '.scratch/glm-original-target43-20261023/original-moe')\n"
    "    env['HYLE_GLM_PRO_DIR'] = str(S / 'original-static')\n"
    "    env['HYLE_GLM_PRO_MOE_DIR'] = str(S / 'original-moe')")
(S / 'build.py').write_text(text, encoding='utf-8')
print('PREPARED cached two-consumer build; no SDK/native worker/NVCC/shader rebuild', flush=True)
