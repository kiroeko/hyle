#pragma once

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>

#include "d5_moe_semantic_fragments.h"
#include "hyle/compute/low_precision.h"
#include "hyle/compute/model_ops.h"

// Pure Flash NextN MoE construction. All parameters are actual immutable
// Graph constants or explicit compact expert inputs supplied by the caller.
// No weight loading, provider routing, host callback or execution lives here.
namespace glm_original_moe_fragment {
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace core=d5_moe_semantic_fragments;
namespace c=hyle::compute;
using Value=sem::ValueId;
inline constexpr std::int64_t kHidden=4096,kIntermediate=2048,kExperts=288,kSlots=8;
struct Parameters final {
  Value router,bias;
  std::array<Value,3> shared,banks; // gate, up, down
  Value map;
};
struct Boundary final {
  Value input,ids,weights;
  std::array<Value,3> banks;
  Value map;
};
struct ProjectionPorts final {
  Value gate_raw,gate_stored,up_raw,up_stored,gate_clipped,up_clipped;
  Value activation_raw,activation_stored,down_raw;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&gate_raw,&gate_stored,&up_raw,&up_stored,&gate_clipped,&up_clipped,
        &activation_raw,&activation_stored,&down_raw})visitor(*value);
  }
};
struct Ports final {
  Value input,logits,scores,selection,ids,selected_scores,sum,denominator,normalized,weights,local_ids,map;
  ProjectionPorts routed,shared;
  Value weighted_raw,weighted_stored,routed_sum_raw,routed_sum_stored,shared_stored,merge_raw,merge_stored;
  template<class Visitor> void visit_values(Visitor &&visitor) {
    for(auto *value:{&input,&logits,&scores,&selection,&ids,&selected_scores,&sum,&denominator,&normalized,&weights,&local_ids,&map})visitor(*value);
    routed.visit_values(visitor);shared.visit_values(visitor);
    for(auto *value:{&weighted_raw,&weighted_stored,&routed_sum_raw,&routed_sum_stored,&shared_stored,&merge_raw,&merge_stored})visitor(*value);
  }
};
struct Result final {Value output;Ports ports;Boundary boundary;};
inline Value cast(sem::Fragment &f,Value input,c::DataType type) {
  return f.one(c::Operation(c::Cast{.output_type=type}),{input});
}
inline Value sum(sem::Fragment &f,Value input,std::int32_t axis) {
  return f.one(c::Operation(c::Reduce{.kind=c::ReductionKind::kSum,
      .axes=c::Axes::from(std::array{axis}).value(),.keep_dimensions=true,
      .accumulation_type=c::DataType::kFloat32}),{input});
}
inline Result append(sem::Fragment &f,Value input,const Parameters &parameters) {
  if(f.description(input)!=sem::dense({1,kHidden},c::DataType::kBFloat16)||
      f.description(parameters.router)!=sem::dense({kExperts,kHidden},c::DataType::kBFloat16)||
      f.description(parameters.bias)!=sem::dense({kExperts})||
      f.description(parameters.map)!=sem::dense({kExperts},c::DataType::kInt32))
    throw std::runtime_error("original Flash MoE requires full original router domain and actual BF16 input");
  for(std::size_t leg=0;leg<parameters.banks.size();++leg) {
    const auto n=leg==2?kHidden:kIntermediate,k=leg==2?kIntermediate:kHidden;
    if(f.description(parameters.banks[leg])!=c::float8_grouped_weight_description(kSlots,n,k).value()||
        f.description(parameters.shared[leg])!=c::float8_weight_description(k,n,c::Float8ScaleMode::kFloat32Block128).value())
      throw std::runtime_error("original Flash MoE requires canonical compact E4/F32 scales and shared banks");
    if(std::none_of(f.inputs.begin(),f.inputs.end(),[&](Value value){return value.ordinal()==parameters.banks[leg].ordinal();}))
      throw std::runtime_error("compact expert bank must be an explicit ordinary Graph input");
  }
  if(std::none_of(f.inputs.begin(),f.inputs.end(),[&](Value value){return value.ordinal()==parameters.map.ordinal();}))
    throw std::runtime_error("expert global-to-local map must be an explicit Graph input");
  Ports ports;ports.input=input;ports.map=parameters.map;
  // The fixed CUDA router path consumes BF16 operands and returns F32
  // logits. The same declared contract is used on every Hyle backend.
  ports.logits=f.one(c::model_ops::bfloat_linear_f32(),{input,parameters.router});
  ports.scores=core::unary(f,c::UnaryKind::kSigmoid,ports.logits);
  ports.selection=core::binary(f,c::BinaryKind::kAdd,ports.scores,parameters.bias);
  const auto top=f.append(c::Operation(c::TopK{.count=std::size_t(kSlots),.stable=true}),{ports.selection},2);
  ports.ids=top[1];
  ports.selected_scores=f.one(c::model_ops::gather_elements(-1,c::IndexBoundsPolicy::kChecked),{ports.scores,ports.ids});
  ports.sum=sum(f,ports.selected_scores,-1);
  ports.denominator=core::binary(f,c::BinaryKind::kAdd,ports.sum,core::filled(f,sem::dense({1,1}),1.0e-20F));
  ports.normalized=core::binary(f,c::BinaryKind::kDivide,ports.selected_scores,ports.denominator);
  ports.weights=core::binary(f,c::BinaryKind::kMultiply,ports.normalized,core::filled(f,sem::dense({1,kSlots}),2.5F));
  const Boundary boundary{input,ports.ids,ports.weights,parameters.banks,parameters.map};
  // The full global IDs remain visible; only the explicit checked map selects
  // compact local slots. No modulo, clamp or restriction of the expert domain.
  ports.local_ids=f.one(c::Operation(c::Gather{}),{parameters.map,ports.ids});
  const auto activate=[&](ProjectionPorts &branch) {
    const auto gate=cast(f,branch.gate_stored,c::DataType::kFloat32);
    const auto up=cast(f,branch.up_stored,c::DataType::kFloat32);
    branch.gate_clipped=f.one(c::model_ops::clamp(-std::numeric_limits<float>::infinity(),10.0F),{gate});
    branch.up_clipped=f.one(c::model_ops::clamp(-10.0F,10.0F),{up});
    branch.activation_raw=core::binary(f,c::BinaryKind::kMultiply,core::unary(f,c::UnaryKind::kSilu,branch.gate_clipped),branch.up_clipped);
    branch.activation_stored=cast(f,branch.activation_raw,c::DataType::kBFloat16);
  };
  const auto grouped=[&](Value activation,std::size_t leg) {
    return f.one(c::model_ops::grouped_float8_linear(c::model_ops::Float8ScalePolicy::kDivide,1.0e-10F),
        {parameters.banks[leg],activation,ports.local_ids});
  };
  const auto shared=[&](Value activation,std::size_t leg) {
    return f.one(c::model_ops::float8_block_linear(c::model_ops::Float8ScalePolicy::kDivide,1.0e-10F),
        {activation,parameters.shared[leg]});
  };
  const auto widened=cast(f,input,c::DataType::kFloat32);
  const auto slots=core::reshape(f,widened,{1,1,kHidden});
  ports.routed.gate_raw=grouped(slots,0);ports.routed.up_raw=grouped(slots,1);
  ports.routed.gate_stored=cast(f,ports.routed.gate_raw,c::DataType::kBFloat16);
  ports.routed.up_stored=cast(f,ports.routed.up_raw,c::DataType::kBFloat16);activate(ports.routed);
  ports.routed.down_raw=grouped(cast(f,ports.routed.activation_stored,c::DataType::kFloat32),2);
  // Match the selected fixed runner: down accumulates F32, applies the actual
  // route weight, then stores BF16. It does not quantize weighted activation.
  ports.weighted_raw=core::binary(f,c::BinaryKind::kMultiply,ports.routed.down_raw,core::reshape(f,ports.weights,{1,kSlots,1}));
  ports.weighted_stored=cast(f,ports.weighted_raw,c::DataType::kBFloat16);
  ports.routed_sum_raw=core::reshape(f,sum(f,cast(f,ports.weighted_stored,c::DataType::kFloat32),1),{1,kHidden});
  ports.routed_sum_stored=cast(f,ports.routed_sum_raw,c::DataType::kBFloat16);
  ports.shared.gate_raw=shared(widened,0);ports.shared.up_raw=shared(widened,1);
  ports.shared.gate_stored=cast(f,ports.shared.gate_raw,c::DataType::kBFloat16);
  ports.shared.up_stored=cast(f,ports.shared.up_raw,c::DataType::kBFloat16);activate(ports.shared);
  ports.shared.down_raw=shared(cast(f,ports.shared.activation_stored,c::DataType::kFloat32),2);
  ports.shared_stored=cast(f,ports.shared.down_raw,c::DataType::kBFloat16);
  ports.merge_raw=core::binary(f,c::BinaryKind::kAdd,cast(f,ports.routed_sum_stored,c::DataType::kFloat32),cast(f,ports.shared_stored,c::DataType::kFloat32));
  ports.merge_stored=cast(f,ports.merge_raw,c::DataType::kBFloat16);
  return {ports.merge_stored,ports,boundary};
}
} // namespace glm_original_moe_fragment
