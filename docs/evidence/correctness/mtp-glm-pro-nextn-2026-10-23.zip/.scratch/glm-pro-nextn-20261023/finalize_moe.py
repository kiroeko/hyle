"""Finish ONLY metadata after root records the terminal old fetch process.

Usage: python finalize_moe.py --terminal-evidence fetch-moe-terminal.json
That JSON must contain session_id=98737, its actual nonzero exit_code, and
stdout_log (repository-relative path of the preserved terminal stdout).
The original failed process remains failed. No payload body is read/rehashed.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import struct

import pin_roles as p


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terminal-evidence', type=Path, required=True)
    args = parser.parse_args()
    terminal_path = args.terminal_evidence
    if not terminal_path.is_absolute():
        terminal_path = p.S / terminal_path
    terminal_path = terminal_path.resolve()
    p.require(terminal_path.is_relative_to(p.R), 'terminal evidence must stay in this repository')
    terminal = p.read(terminal_path)
    p.require(terminal['session_id'] == 98737, 'terminal evidence is not the original MoE fetch handle')
    p.require(type(terminal['exit_code']) is int and terminal['exit_code'] != 0,
              'root must record the actual nonzero terminal exit; a live handle is not sufficient')
    stdout_path = p.local_path(terminal['stdout_log'])
    stdout_identity = p.identity(stdout_path)
    p.require(stdout_identity['bytes'] > 0, 'original failed stdout must be retained')

    # This validates the full small catalog, planned intervals and actual file
    # length without reading roles.bin or any other payload body.
    meta = p.validate_moe(complete=False, typed=False)
    record, plan, catalog = meta['receipt'], meta['plan'], meta['catalog']
    p.require(record['complete'] is False, 'repair expects the incomplete terminal old receipt')
    p.require(record['whole_shards_downloaded'] is False and record['unrequested_bytes'] == 0,
              'repair cannot expand the acquired range scope')
    groups = {row['index']: row for row in plan['groups']}
    p.require(len(groups) == len(plan['groups']), 'duplicate planned range group')
    successes = [row for row in record['requests'] if row['complete'] is True]
    p.require(sum(row['bytes'] for row in successes) == p.MOE_BYTES,
              'successful request bytes do not cover the original bundle')
    cursor = 0
    for chunk in record['chunks']:
        size = chunk['bytes']
        p.require(chunk['offset'] == cursor and 0 < size <= record['chunk_bytes'],
                  'verified chunks are not a contiguous complete prefix')
        group = groups[chunk['group']]
        p.require(group['bundle_offset'] <= cursor and
                  size <= group['bundle_offset'] + group['bytes'] - cursor,
                  'verified chunk crosses its planned source group')
        first = group['first'] + cursor - group['bundle_offset']
        last = first + size - 1
        p.require(chunk['absolute_inclusive'] == [first, last], 'chunk original-source range differs')
        p.digest(chunk['sha256'], 'verified chunk')
        matching = [row for row in successes if row['offset'] == cursor and row['bytes'] == size]
        p.require(len(matching) == 1, 'chunk has no unique successful original request')
        request = matching[0]
        shard = plan['shards'][group['source_shard']]
        p.require(request['http_status'] == 206 and request['group'] == group['index'] and
                  request['first'] == first and request['last'] == last and
                  request['sha256'] == chunk['sha256'] and request['etag'] == shard['etag'] and
                  request['content_range'] == f'bytes {first}-{last}/{shard["whole_file_bytes"]}',
                  'successful request identity differs from its verified chunk')
        cursor += size
    p.require(cursor == p.MOE_BYTES, 'verified chunks are still incomplete')

    repair = p.S / 'moe-metadata-finalization'
    repair.mkdir(exist_ok=False)
    p.atomic_bytes(repair / 'receipt-before.json', p.small_bytes(meta['receipt_path']))
    p.atomic_bytes(repair / 'catalog-before.json', p.small_bytes(meta['catalog_path']))
    p.atomic_bytes(repair / 'terminal-evidence.json', p.small_bytes(terminal_path))

    # Correct only the stale descriptive expert-count label from the old
    # running script. Authoritative ordered rows/ranges/hashes are unchanged.
    catalog['typed_order'] = ('router,bias,shared gate/up/down code/SF; '
                              'expert0..255 each gate/up/down code/SF')
    p.save(meta['catalog_path'], catalog)
    raw = struct.pack('<8sIIQQ32s', b'HYGLMM01', 1, p.MOE_ROLES,
                      p.MOE_BYTES, 0, bytes.fromhex(meta['bundle_sha256']))
    raw += b''.join(struct.pack('<QQ', row['bundle_offset'], row['bytes'])
                    for row in catalog['roles'])
    p.require(len(raw) == 64 + 16 * p.MOE_ROLES == 24768, 'typed index geometry differs')
    if meta['typed_path'].exists():
        p.require(p.small_bytes(meta['typed_path'], len(raw)) == raw, 'pre-existing typed index differs')
    else:
        p.atomic_bytes(meta['typed_path'], raw)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record.update(complete=True, role_payload_bytes=p.MOE_BYTES,
        successful_request_body_bytes=sum(row['bytes'] for row in successes),
        bundle=dict(path=(p.S / 'original-moe/roles.bin').relative_to(p.R).as_posix(),
                    bytes=p.MOE_BYTES, sha256=meta['bundle_sha256']),
        catalog=p.identity(meta['catalog_path']), typed_catalog=p.identity(meta['typed_path']),
        finished_utc=now,
        metadata_finalization=dict(scope='Terminal old fetch metadata repair only; original process did not exit successfully.',
            original_process=p.identity(terminal_path), original_session_id=terminal['session_id'],
            original_exit_code=terminal['exit_code'], original_stdout=stdout_identity,
            completed_utc=now, payload_bodies_read=False, payload_bodies_rehashed=False))
    p.save(meta['receipt_path'], record)
    p.validate_moe()  # Small metadata/index verification only.
    p.save(repair / 'result.json', dict(scope='Metadata completion after the preserved failed fetch process.',
        receipt=p.identity(meta['receipt_path']), catalog=p.identity(meta['catalog_path']),
        typed_catalog=p.identity(meta['typed_path']), terminal=p.identity(terminal_path),
        original_exit_code=terminal['exit_code'], original_stdout=stdout_identity,
        payload_bytes=p.MOE_BYTES, payload_bodies_read=False, payload_bodies_rehashed=False,
        download_started=False, native_run=False))
    print('FINALIZED small MoE metadata; original fetch exit remains', terminal['exit_code'],
          '; no payload body was read or rehashed', flush=True)


if __name__ == '__main__':
    main()
