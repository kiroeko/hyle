"""Verify the actual BV publication; do not infer broader MTP completion."""
from datetime import datetime, timezone
from pathlib import Path
import json
import sys
import zipfile
sys.dont_write_bytecode = True
import publish as p

S, R = p.S, p.R
publication = p.read(S / 'publication.json')
for row in publication.values():
    p.verify(row)
evidence = p.read(p.verify(publication['evidence']))
assert evidence['stage'] == 'BV' and evidence['goal_complete'] is False
validation = evidence['validation']
assert validation['tests'] == 4 and validation['final_host_translation_units'] == 2
assert not any(validation[key] for key in ('failures', 'errors', 'skips', 'SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
assert len(validation['batches']) == 2
graphs, tests = 0, 0
assert {batch['name'] for batch in validation['batches']} == {'affected_flash', 'original_pro'}
for batch in validation['batches']:
    p.verify(batch['image'])
    p.verify(batch['linked_inputs'])
    p.verify(batch['runtime_cache'])
    count, actual_cases = 0, []
    for row in batch['results']:
        run = p.read(p.verify(row))
        assert run['image'] == batch['image']
        assert run['process']['exit'] == 0 and not run['process']['timed_out']
        assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
        tests += run['tests']
        actual_cases.extend(run['cases'])
        count += sum(p.integer(case['properties'], 'actual_submissions') for case in run['cases'])
    assert actual_cases == batch['cases']
    if batch['name'] == 'affected_flash':
        p.flash_contract(actual_cases)
    else:
        p.pro_contract(actual_cases)
    assert count == batch['graph_submissions'] and count > 0
    graphs += count
assert tests == 4 and graphs == validation['graph_submissions']
assert validation['batches'][0]['image'] != validation['batches'][1]['image']
assert all(row['complete'] for row in evidence['artifact']['acquisitions'])
assert evidence['artifact']['original_roles'] == 1571 and evidence['artifact']['original_source_bytes'] == 13838963840
with zipfile.ZipFile(p.verify(publication['archive'])) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        member = Path(name)
        assert member.suffix.lower() not in {'.exe', '.obj', '.lib', '.dll', '.bf16', '.f32', '.e4m3', '.safetensors'}
        if member.suffix.lower() == '.bin':
            assert member.name == 'catalog.bin' and archive.getinfo(name).file_size == p.CATALOG_BYTES
p.protect(p.read(S / 'before.json'))
progress = dict(utc=datetime.now(timezone.utc).isoformat(), stage='BV', stage_complete=True, goal_complete=False,
    state='The original complete Pro NextN1571-role finite CPU/CUDA consumers and affected Flash regressions passed with their separate actual linked images; durable evidence was published.',
    tests=4, graph_submissions=graphs, failures=0, skips=0, native_checks_run=True,
    native_process_status='all included summary processes completed_exit0_not_timed_out',
    original_pro_roles=1571, original_pro_bytes=13838963840, publication=publication,
    actual_graph_submissions_by_batch=validation['graph_submissions_by_batch'],
    new_TPS=False, physical_memory_peak=False, protected_AV_tail_unchanged=True,
    scope='Original Pro NextN/readonly fullV154880 banks, finite accepted/skip/catchup state and actual pending feedback. Target-main hidden/history inputs remain explicitly synthetic; this is not full target/model quality, natural acceptance rate or throughput evidence.',
    next='Continue remaining confirmed target/verifier/artifact gaps and related checks, then compare ordinary/MTP performance before image projection. Full goal remains incomplete.')
(S / 'progress.json').write_text(json.dumps(progress, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PUBLISHED BV', tests, 'cases', graphs, 'Graphs; broader MTP remains incomplete')
