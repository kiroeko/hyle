"""Record the actual starting point for original GLM Pro NextN integration."""
from pathlib import Path
from datetime import datetime, timezone
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
BU = R / '.scratch/glm-original-target43-20261023'
before = json.loads((BU / 'before.json').read_text(encoding='utf-8'))
prior = json.loads((BU / 'publication.json').read_text(encoding='utf-8'))
def save(name, data):
    (S / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert not (S / 'before.json').exists()
save('before.json', dict(utc=datetime.now(timezone.utc).isoformat(),
    previous_goal_turn_classification='progress: BU original43/44/NextN full-V K1 integration passed four CPU/CUDA cases320Graphs and was published.',
    prior_publication=prior, protected_performance_tail_sha256=before['protected_performance_tail_sha256'],
    protected_qwen_image=before['protected_qwen_image'],
    source=json.loads((BU / 'source-final/freeze.json').read_text(encoding='utf-8'))['source']))
save('progress.json', dict(stage='BV', goal_complete=False, stage_complete=False,
    previous_goal_turn_classification='progress: BU actual original43/44/NextN source, acquisition, native checks and documentation published.',
    state='Preparing actual Pro geometry/codec, shared ordinary run helper and exact original-role acquisition.',
    target=dict(repository='zai-org/GLM-5.3', revision='aca966e4e02791568aa6a4ced368624b3d897f42',
        nextn_layer=78, original_roles=1571, original_bytes=13838963840,
        static_and_vocabulary_roles=27, static_and_vocabulary_bytes=4132023424,
        moe_roles=1544, moe_bytes=9706940416),
    scope='Actual Pro6144 NextN, complete576 CKV+KPE rows,512-latent attention values,RoPE,unpooled128 index cache,original256-domain MoE,full-V feedback and complete accepted continuation. Target trunk/initial prefix remain explicit boundaries.',
    native_checks_run=False, new_TPS=False,
    next='Fetch only four real shard headers, form exact-range role plans, acquire original payloads and connect pure model Graph/state to the existing ordinary native lifecycle.'))
print('PREPARED BV actual original Pro NextN; BU checked history preserved', flush=True)
