"""Publish actual BV Flash regression plus complete Pro NextN evidence.

Prepared before final results; root alone invokes this after both batches.
Each batch retains its own actual linked image and compile/cache identity.
Original weight bodies are never rehashed or archived by this publisher.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
PRO = 'OriginalNextNFullVocabularyPublishesAndCatchesUp'
FLASH = 'OriginalTarget43And44AndNextNFullVocabularyVerifier'
REPOSITORY = 'zai-org/GLM-5.3'
REVISION = 'aca966e4e02791568aa6a4ced368624b3d897f42'
STATIC_ROLES, STATIC_BYTES = 27, 4132023424
MOE_ROLES, MOE_BYTES = 1544, 9706940416
ALL_ROLES, ALL_BYTES = STATIC_ROLES + MOE_ROLES, STATIC_BYTES + MOE_BYTES
CATALOG_BYTES = 64 + 16 * MOE_ROLES
TEXT = {'.h', '.hh', '.hpp', '.c', '.cc', '.cpp', '.py', '.mjs', '.json',
        '.txt', '.log', '.xml', '.ps1', '.diff', '.rsp', '.cmd', '.md'}
# Locked from the final compiled Pro TU's RecordProperty calls. These are
# declared domains/coverage, never a guessed total Graph or natural result.
PRO_PROPERTIES_LOCKED = True
PRO_EXPECTED = dict(full_original_nextn_roles=1571, full_original_nextn_source_bytes=13838963840,
    first_full_nextn_head_reference_values=154880, target_first_full_reference_values=309760,
    resident_expert_domain=256, resident_expert_capacity=8,
    prepared_kv_capacity_bytes=2 * 64 * 512 * (192 + 256),
    natural_k1_trials=1, controlled_matching_trials=1, controlled_rejection_trials=1)
PRO_POSITIVE = ('actual_nextn_steps', 'actual_pending_embedding_feedback_checks',
    'actual_index_catchup_steps', 'actual_skip_steps', 'accepted_zero_draft_checkpoints',
    'accepted_one_draft_checkpoints', 'cancelled_unpublished_drafts',
    'rejected_stale_publishes', 'target_verifier_submissions')
verified = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def identity(path):
    path = resolve(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path),
                bytes=path.stat().st_size, sha256=digest)


def verify(row):
    path = resolve(row['path'])
    if path not in verified:
        verified[path] = identity(path)
    assert (verified[path]['bytes'], verified[path]['sha256']) == (row['bytes'], row['sha256']), row['path']
    return path


def integer(properties, key):
    value = int(properties[key])
    assert value >= 0, (key, value)
    return value


def protect(before):
    protected = before['protected_qwen_image']
    protected = protected.get('image', protected)
    actual = identity(protected['path'])
    assert (actual['bytes'], actual['sha256']) == (protected['bytes'], protected['sha256'])
    text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    tail = text[text.index('## 最新完整性能对比'):]
    digest = hashlib.sha256(tail.encode()).hexdigest()
    assert digest == before['protected_performance_tail_sha256']
    return digest


def acquisitions():
    """Authenticate small plans/receipts/catalogs; only stat large bodies."""
    plans = [read(S / 'static-plan.json'), read(S / 'roles-plan.json')]
    receipts = [read(S / 'original-static/acquisition.json'), read(S / 'original-moe/acquisition.json')]
    for plan, receipt, count, size in zip(plans, receipts, (STATIC_ROLES, MOE_ROLES), (STATIC_BYTES, MOE_BYTES)):
        assert plan['repository'] == receipt['repository'] == REPOSITORY
        assert plan['revision'] == receipt['revision'] == REVISION
        assert plan['original_roles'] == receipt['original_roles'] == count
        assert receipt['complete'] and receipt['role_payload_bytes'] == size
        assert receipt['successful_request_body_bytes'] == size
        assert receipt['source_plan_sha256'] == identity(receipt['source_plan'])['sha256']
        assert not receipt.get('whole_shard_downloaded', receipt.get('whole_shards_downloaded', False))
        assert len(plan['roles']) == count and sum(row['bytes'] for row in plan['roles']) == size
        verify(plan['header_receipt'])
        for shard_number, shard in enumerate(plan['shards']):
            raw = verify(shard['header']).read_bytes()
            assert shard['data_base'] == len(raw) + 8
            header = json.loads(raw)
            for row in plan['roles']:
                if row['source_shard'] != shard_number:
                    continue
                exact = header[row['name']]
                assert exact['dtype'] == row['dtype'] and exact['shape'] == row['shape']
                assert exact['data_offsets'] == row['data_relative_half_open']
                first, end = exact['data_offsets']
                assert row['bytes'] == end - first
                assert row['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
    static, moe = receipts
    planned = {row['name']: row for row in plans[0]['roles']}
    assert len(static['roles']) == STATIC_ROLES
    for row in static['roles']:
        expected = planned[row['name']]
        for key in ('filename', 'dtype', 'shape', 'bytes', 'data_relative_half_open', 'absolute_inclusive'):
            assert row[key] == expected[key], (row['name'], key)
        assert row['complete'] and row['payload']['bytes'] == row['bytes']
        assert resolve(row['payload']['path']).stat().st_size == row['bytes']
        assert len(row['payload']['sha256']) == 64
    assert moe['bundle']['bytes'] == MOE_BYTES and resolve(moe['bundle']['path']).stat().st_size == MOE_BYTES
    assert len(moe['bundle']['sha256']) == 64
    catalog_path, typed_path = verify(moe['catalog']), verify(moe['typed_catalog'])
    catalog = read(catalog_path)
    assert catalog['repository'] == REPOSITORY and catalog['revision'] == REVISION
    assert catalog['original_roles'] == MOE_ROLES and len(catalog['roles']) == MOE_ROLES
    assert catalog['bundle']['bytes'] == MOE_BYTES and catalog['bundle']['sha256'] == moe['bundle']['sha256']
    index = typed_path.read_bytes()
    assert len(index) == CATALOG_BYTES
    magic, version, count, size, reserved, digest = struct.unpack('<8sIIQQ32s', index[:64])
    assert (magic, version, count, size, reserved) == (b'HYGLMM01', 1, MOE_ROLES, MOE_BYTES, 0)
    assert digest.hex() == moe['bundle']['sha256']
    for ordinal, (planned_row, row) in enumerate(zip(plans[1]['roles'], catalog['roles'])):
        assert planned_row['ordinal'] == row['ordinal'] == ordinal
        for key in ('name', 'dtype', 'shape', 'bytes', 'source_shard', 'data_relative_half_open', 'absolute_inclusive', 'bundle_offset'):
            assert row[key] == planned_row[key], (ordinal, key)
        assert len(row['sha256']) == 64
        assert struct.unpack_from('<QQ', index, 64 + ordinal * 16) == (row['bundle_offset'], row['bytes'])
    assert len({row['name'] for plan in plans for row in plan['roles']}) == ALL_ROLES
    assert sum(receipt['role_payload_bytes'] for receipt in receipts) == ALL_BYTES == 13838963840
    assert sum(group['bytes'] for group in plans[1]['groups']) == MOE_BYTES and plans[1]['unrequested_bytes'] == 0
    provenance = []
    finalization = moe.get('metadata_finalization')
    if finalization is not None:
        # The old fetch script's terminal metadata error must remain a failed
        # process. Successful native consumers authenticate the real bodies;
        # publication must never rewrite the old exit as successful.
        terminal_path = verify(finalization['original_process'])
        stdout_path = verify(finalization['original_stdout'])
        terminal = read(terminal_path)
        assert terminal['session_id'] == finalization['original_session_id'] == 98737
        assert type(terminal['exit_code']) is int and terminal['exit_code'] != 0
        assert terminal['exit_code'] == finalization['original_exit_code']
        assert resolve(terminal['stdout_log']) == stdout_path and stdout_path.stat().st_size > 0
        assert finalization['payload_bodies_read'] is False and finalization['payload_bodies_rehashed'] is False
        provenance.extend((terminal_path, stdout_path))
    return receipts, typed_path, provenance


def source_freeze(folder):
    path = S / folder / 'freeze.json'
    record = read(path)
    frozen = {}
    for key in ('source', 'dependencies', 'fixed_dependencies', 'files'):
        for row in record.get(key, []):
            original = verify(row)
            assert original not in frozen or frozen[original]['sha256'] == row['sha256']
            frozen[original] = row
    required = {'glm_mtp_state_consumer_test.cc', 'glm_pro_mtp_state_consumer_test.cc',
        'model_graph_run.h', 'glm_pro_mtp_fragment.h', 'glm_pro_mtp_reference.h',
        'glm_pro_original_roles.h', 'glm_moe_geometry.h', 'glm_original_moe_fragment.h',
        'glm_original_moe_roles.h', 'glm_original_moe_resident_weights.h',
        'glm_original_moe_reference.h', 'glm_original_attention_reference.h'}
    assert required <= {item.name for item in frozen}
    return path, frozen


def successful_process(path):
    result = read(path)
    assert result['exit'] == 0 and result.get('terminal', True)
    assert not result.get('timed_out', False)
    return result


def linked(attempt, expected_tus, frozen):
    folder = S / f'tests-link{attempt}'
    paths = {name: folder / name for name in ('ready.json', 'link-plan.json', 'runtime-environment.json', 'link.result.json')}
    image = read(paths['ready.json'])['image']
    verify(image)
    successful_process(paths['link.result.json'])
    link, runtime = read(paths['link-plan.json']), read(paths['runtime-environment.json'])
    assert all(link[key] == 0 for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
    inputs = {verify(row): row for row in link['inputs']}
    host, metadata = {}, []
    for row in link['compiled_records']:
        path = verify(row)
        metadata.append(path)
        if not path.is_relative_to(S):
            continue
        compiled = read(path)
        source = verify(compiled['source'])
        assert source in frozen
        for item in (compiled['object'], *compiled['dependencies']):
            verify(item)
        assert resolve(compiled['object']['path']) in inputs
        successful_process(path.with_name('compile.result.json'))
        host[source.name] = (path, compiled)
    assert set(host) == set(expected_tus), set(host)
    for row in runtime['staged_dlls']:
        verify(row)
    return dict(image=image, paths=paths, link=link, runtime=runtime, host=host,
                metadata=metadata, inputs=inputs)


def batch(indices, linked_image, expected_class, suffix):
    summaries = [S / f'checks{index}/summary.json' for index in indices]
    runs = [read(path) for path in summaries]
    for run in runs:
        assert run['image'] == linked_image
        assert run['process']['exit'] == 0 and not run['process']['timed_out']
        assert run['tests'] == len(run['cases'])
        assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
        assert run.get('throughput_evidence') is False and run.get('physical_memory_evidence') is False
        assert run.get('whole_original_model') is False
        for case in run['cases']:
            assert case['attributes'].get('status') == 'run' and case['attributes'].get('result') == 'completed'
    cases = [case for run in runs for case in run['cases']]
    assert len(cases) == 2
    assert {case['attributes']['name'] for case in cases} == {f'Cpu{suffix}', f'Cuda{suffix}'}
    assert all(case['attributes']['classname'] == expected_class for case in cases)
    return summaries, cases


def flash_contract(cases):
    for case in cases:
        props = case['properties']
        for key, expected in dict(full_original_nextn_roles='1762', full_original_nextn_source_bytes='10030953088',
            original_target43_roles='1762', original_target43_source_bytes='7427838808',
            original_target44_roles='1760', original_target44_source_bytes='7554137944',
            target_full_vocabulary='154880', target_first_full_reference_values='309760',
            target_verifier_submissions='3', natural_k1_trials='1',
            controlled_matching_trials='1', controlled_rejection_trials='1').items():
            assert props[key] == expected, (case['attributes']['name'], key, props.get(key))
        assert integer(props, 'actual_submissions') > 0
        assert integer(props, 'actual_pending_embedding_feedback_checks') > 0
        assert integer(props, 'accepted_zero_draft_checkpoints') > 0 and integer(props, 'accepted_one_draft_checkpoints') > 0
        assert integer(props, 'peak_state_backing_bytes') <= integer(props, 'state_budget_bytes')


def pro_contract(cases):
    assert PRO_PROPERTIES_LOCKED, 'Root must finalize actual Pro property names/count contracts before publication'
    for case in cases:
        props = case['properties']
        for key, expected in PRO_EXPECTED.items():
            assert props[key] == str(expected), (case['attributes']['name'], key, props.get(key))
        for key in PRO_POSITIVE:
            assert integer(props, key) > 0, (case['attributes']['name'], key)
        assert integer(props, 'actual_submissions') > 0
        assert integer(props, 'natural_k1_accepted_drafts') in (0, 1)
        assert integer(props, 'natural_k1_proposal') < 154880
        assert integer(props, 'actual_nextn_steps') == integer(props, 'actual_pending_embedding_feedback_checks')
        assert integer(props, 'actual_index_catchup_steps') == integer(props, 'accepted_one_draft_checkpoints')
        trials = sum(integer(props, key) for key in ('natural_k1_trials', 'controlled_matching_trials', 'controlled_rejection_trials'))
        assert integer(props, 'accepted_zero_draft_checkpoints') + integer(props, 'accepted_one_draft_checkpoints') == trials
        assert integer(props, 'peak_state_backing_bytes') <= integer(props, 'state_budget_bytes')
        assert sum(integer(props, key) for key in ('state_pool_backing_bound', 'state_initial_backing_bound',
            'state_metadata_backing_bound')) == integer(props, 'state_budget_bytes')
        unions = [int(value) for value in props['actual_resident_union_sizes'].split(',')]
        assert len(unions) == integer(props, 'actual_nextn_steps') and all(0 < size <= 8 for size in unions)
        if case['attributes']['name'].startswith('Cuda'):
            assert props['head_provider'] == 'cublasLt'


def comparable(row):
    return row['bytes'], row['sha256']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--flash-runs', type=int, nargs='+', required=True)
    parser.add_argument('--pro-runs', type=int, nargs='+', required=True)
    parser.add_argument('--flash-link-attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=2)
    parser.add_argument('--freeze', default='source-final2')
    args = parser.parse_args()
    assert args.flash_link_attempt > 0 and args.link_attempt > args.flash_link_attempt
    assert args.flash_runs and args.pro_runs and all(i > 0 for i in args.flash_runs + args.pro_runs)
    assert len(set(args.flash_runs + args.pro_runs)) == len(args.flash_runs + args.pro_runs)
    freeze_path, frozen = source_freeze(args.freeze)
    flash = linked(args.flash_link_attempt, ('glm_mtp_state_consumer_test.cc',), frozen)
    final = linked(args.link_attempt, ('glm_mtp_state_consumer_test.cc', 'glm_pro_mtp_state_consumer_test.cc'), frozen)
    flash_summaries, flash_cases = batch(args.flash_runs, flash['image'], 'GlmMtpStateConsumer', FLASH)
    pro_summaries, pro_cases = batch(args.pro_runs, final['image'], 'GlmProMtpStateConsumer', PRO)
    flash_contract(flash_cases)
    pro_contract(pro_cases)
    # Link1 was genuinely used by the Flash batch; do not relabel its result
    # as a link2 run. Its same compiled TU/dependencies must survive unchanged.
    old_record = flash['host']['glm_mtp_state_consumer_test.cc']
    new_record = final['host']['glm_mtp_state_consumer_test.cc']
    assert old_record[1] == new_record[1]
    pro_object = resolve(final['host']['glm_pro_mtp_state_consumer_test.cc'][1]['object']['path'])
    assert pro_object not in flash['inputs']
    assert set(final['inputs']) == set(flash['inputs']) | {pro_object}
    assert all(comparable(final['inputs'][path]) == comparable(row) for path, row in flash['inputs'].items())
    dlls = lambda runtime: {Path(row['path']).name.lower(): comparable(row) for row in runtime['staged_dlls']}
    assert dlls(flash['runtime']) == dlls(final['runtime'])
    receipts, catalog_binary, acquisition_provenance = acquisitions()
    before = read(S / 'before.json')
    for row in before['prior_publication'].values():
        verify(row)
    tail_hash = protect(before)
    graph_counts = dict(flash=sum(integer(case['properties'], 'actual_submissions') for case in flash_cases),
                       pro=sum(integer(case['properties'], 'actual_submissions') for case in pro_cases))
    assert all(graph_counts.values())
    docs = [R / 'docs/developer/current-work.md', R / 'docs/implementation/model-operators.md']
    prior_evidence = verify(before['prior_publication']['evidence'])
    files = set(frozen) | set(docs) | {prior_evidence, catalog_binary} | set(acquisition_provenance)
    files.update(flash['metadata'] + final['metadata'])
    files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in TEXT)
    files.discard(S / 'publication.json')
    for path in files:
        assert path.resolve().is_relative_to(R)
        assert (path.suffix.lower() in TEXT or path == catalog_binary) and path.stat().st_size < 10_000_000, path
    destination = D / 'mtp-glm-pro-nextn-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert D.is_dir() and not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(files):
            zipped.write(path, path.relative_to(R).as_posix())
    batches = []
    for name, group, summaries, cases in (('affected_flash', flash, flash_summaries, flash_cases),
                                         ('original_pro', final, pro_summaries, pro_cases)):
        batches.append(dict(name=name, image=group['image'], results=[identity(path) for path in summaries],
            linked_inputs=identity(group['paths']['link-plan.json']), runtime_cache=identity(group['paths']['runtime-environment.json']),
            host_compile_records=[identity(path) for path, _ in group['host'].values()],
            cases=cases, graph_submissions=graph_counts['flash' if name == 'affected_flash' else 'pro']))
    record = dict(date='2026-10-23', stage='BV', goal_complete=False,
        conclusion='The listed Windows CPU/CUDA original Pro complete NextN consumers and affected Flash regression passed; each result retains its actual linked-image identity.',
        artifact=dict(repository=REPOSITORY, revision=REVISION, layer=78, original_roles=ALL_ROLES,
            original_source_bytes=ALL_BYTES, static_roles=STATIC_ROLES, static_bytes=STATIC_BYTES,
            moe_roles=MOE_ROLES, moe_bytes=MOE_BYTES, hidden=6144, query_rank=2048, vocabulary=154880,
            acquisitions=receipts, acquisition_process_provenance=[identity(path) for path in acquisition_provenance],
            weight_bodies_archived=False, extra_weight_hash_pass=False),
        implementation=dict(
            geometry='Original Pro64heads: NoPE192+RoPE64, latent512, value256/head. Main F32cache is an exactBF16widen carrier of CKV512+rotatedKPE64; selected same global rows supply QK576/V512, scale1/16, then original value projection.',
            preparation='One original E4KV_b[28672,512]/F32SF[224,4] is decoded cold toBF16 before head448-row split. Two compact readonly BF16key/value outputs are retained; original globalrow/128 scales do not reset at a head. Raw deviceKV bank is retired, with no persistent fullF32shadow. This is the declared preparedBF16BMM path, not vendor nativeFP8BMM bit-equivalence.',
            indexer='Explicit official non-fused indexer: original FP8wk/wq_b -> BF16, actual keyLayerNorm, first64 interleavedRoPE8M, normalizedHadamard128/BF16/UE8M0 and real separateE4/F32scale state. Original BF16weights_proj returnsF32. Unpooled token rows/global2048IDs; no FlashK4pool/APE/gate. Layerfrequency is not a four-token reselect clock.',
            ffn='Shared geometry carries ProH6144/I2048/full256domain/Top8/route2.5/noSwiGLUclip. Actual global IDs drive bounded E8 original compressed expert/code-scale-map supply over two ordinary Graph phases. Default Flash clip10 behavior and its original identities remain separately checked.',
            vocabulary='Actual untied full154880BF16embedding/head and original layer78shared-head norm share one lifetime. EH uses normalized embedding then hidden; actual raw residualsum and independent BF16residual return enter the source postnorm/sharednorm boundaries. FullV stablegreedy produces actual I32pending for the next original embedding row.',
            state='Existing ordinary Graph/Invocation lifecycle, leases, resident cold cut/supply and StateHead are reused. The Pro test declares its own unpooled/main576 schema and actual accepted-prefix/skip/journal/catchup boundaries; no new public operation or executor.',
            reference='Original-byte independent FP8/BF16local certificates use actual predecessors, exact BF16/E4 stores and same originalKVb scale grid. First new projections/BMM/fullVhead are checked completely; later fixed or actual candidate rows retain the same certificate. Every actual greedy/store/state seam remains checked, with no wider empirical tolerance or extra native-reference batches.',
            builds='One affected Flash hostTU is compiled for link1; final link2 adds the new Pro hostTU while preserving the exact Flash source/dependencies/object and shared cached native inputs. The two native result batches are not relabeled as one image. No SDK/CPUworker/NVCC/shader rebuild is included.'),
        validation=dict(tests=4, failures=0, errors=0, skips=0,
            graph_submissions=sum(graph_counts.values()), graph_submissions_by_batch=graph_counts,
            batches=batches, source_freeze=identity(freeze_path), final_host_translation_units=2,
            host_compile_attempts=len(list(S.glob('compile*/*/plan.json'))),
            SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0),
        limitations=['Finite declared original Pro NextN Windows CPU/CUDA consumers; no claim for every platform/input/provider or artifact.',
            'Pro target hidden inputs, upstream target/main-model computation and finite initial prefix/history remain explicit external synthetic boundaries. Original NextN is not an original complete trained target engine or prompt-to-output task-quality result.',
            'Non-fused indexer/preparedBF16BMM are explicit legal mathematical choices, not default vendor fusion/rounding or physical page ABI identity.',
            'Acceptance/state controls do not establish model task quality or natural acceptance rate. No new loading/TPS or measured physical memory/VRAM peak.',
            'The protected AV performance comparison and Qwen executable are unchanged. Broader MTP closure/image projection and the active goal are not declared complete.'],
        remaining='Actual target/verifier/confirmed artifact adapter work and necessary related checks, followed by complete ordinary/MTP performance comparison; no expansion to unconfirmed artifacts is inferred.',
        final_image=final['image'], sources=[identity(path) for path in sorted(frozen) + docs],
        plans=[identity(S / 'roles-plan.json'), identity(S / 'static-plan.json')],
        performance_tail_sha256=tail_hash, protected_qwen_image=before['protected_qwen_image'],
        reused_provenance=[identity(prior_evidence)], archive=identity(archive), archive_items=len(files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert protect(before) == tail_hash
    print(json.dumps(dict(**publication, tests=4, graphs=record['validation']['graph_submissions'])))


if __name__ == '__main__':
    main()
