"""Snapshot actual final BV sources after pin_roles.py; never compile or read payload bodies."""
from pathlib import Path
import argparse
import hashlib
import re

import pin_roles as p

BASELINE = p.R / '.scratch/glm-original-target43-20261023/source-final/freeze.json'
EXTRA_SOURCES = (
    'tests/compute_models/glm_pro_original_roles.h',
    'tests/compute_models/glm_pro_mtp_fragment.h',
    'tests/compute_models/glm_pro_mtp_reference.h',
    'tests/compute_models/glm_pro_mtp_state_consumer_test.cc',
    'tests/compute_models/model_graph_run.h',
    'tests/compute_models/glm_moe_geometry.h',
    'tests/graph_route_cpu/CMakeLists.txt',
    'tests/graph_route_cuda/CMakeLists.txt',
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('source-final'),
                        help='new output directory relative to this BV stage')
    args = parser.parse_args()
    output = args.output if args.output.is_absolute() else p.S / args.output
    output = output.resolve()
    p.require(output.is_relative_to(p.S) and output != p.S, 'snapshot output must stay below this stage')
    p.require(not output.exists(), 'snapshot output already exists; use a new explicit revision directory')

    # Metadata and existing file-size checks only. The large mapped original
    # bodies are deliberately not read or hashed by this publication step.
    static, moe = p.validate_static(), p.validate_moe()
    pins = p.read(p.S / 'pins.json')
    p.require(pins['after'] == p.identity(p.HEADER), 'current supplier differs from the final pin record')
    text = p.small_bytes(p.HEADER).decode('utf-8')
    p.verify_header(text, static, moe)
    for match in p.SPEC.finditer(text):
        p.require(match[4] == static['rows'][match[3]]['payload']['sha256'], 'static pin is incomplete')
    vocabulary = re.findall(r'"([^"\n]*)"', p.VOCAB.search(text)[2])
    p.require(vocabulary == [static['rows'][name]['payload']['sha256']
                            for name in ('embedding.bf16', 'head.bf16', 'norm.bf16')],
              'shared vocabulary pins are incomplete or out of order')
    p.require(p.MOE_PIN.search(text)[2] == p.identity(moe['typed_path'])['sha256'],
              'Pro MoE catalog pin differs')

    baseline = p.read(BASELINE)
    p.require(len(baseline['source']) == 26, 'BU baseline must contain exactly26 source inputs')
    old = {row['path']: row for row in baseline['source']}
    p.require(len(old) == 26, 'BU baseline has duplicate source paths')
    paths = list(old)
    for name in EXTRA_SOURCES:
        if name not in paths:
            paths.append(name)
    p.require(len(paths) == 34, 'expected BU26 plus BV6 and two CMake inputs')

    # Stage all small current sources in memory first. The previous BU
    # snapshots are only a path/provenance baseline, never a source fallback.
    sources = [(name, p.small_bytes(p.local_path(name))) for name in paths]
    for name, raw in sources:
        if name in ('tests/graph_route_cpu/CMakeLists.txt', 'tests/graph_route_cuda/CMakeLists.txt'):
            p.require(raw.decode('utf-8-sig').count('glm_pro_mtp_state_consumer_test.cc') == 1,
                      'finish the one Pro test registration before freezing: ' + name)
    metadata_paths = [BASELINE, static['plan_path'], static['receipt_path'], moe['plan_path'],
                      moe['receipt_path'], moe['catalog_path'], moe['typed_path'], p.S / 'pins.json',
                      p.S / 'pin_roles.py', p.S / 'finalize_moe.py', Path(__file__).resolve()]
    for relative in ('review/pro-source-math.json', 'graph-reference-source/freeze.json',
                     'roles-source/freeze-body.json', 'moe-source/freeze.json',
                     'execution-source/freeze.json', 'moe-metadata-finalization/result.json'):
        candidate = p.S / relative
        if candidate.exists():
            metadata_paths.append(candidate)
    metadata = [(path.resolve(), p.small_bytes(path)) for path in metadata_paths]

    output.mkdir(parents=True)
    entries = []
    for name, raw in sources:
        snapshot = output / 'frozen' / name
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        p.atomic_bytes(snapshot, raw)
        row = dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                   snapshot=snapshot.relative_to(p.R).as_posix())
        if name in old:
            row['BU_sha256'] = old[name]['sha256']
            row['changed_since_BU'] = row['sha256'] != old[name]['sha256']
        entries.append(row)
    evidence = []
    for path, raw in metadata:
        relative = path.relative_to(p.R)
        snapshot = output / 'metadata' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        p.atomic_bytes(snapshot, raw)
        evidence.append(dict(path=relative.as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                             snapshot=snapshot.relative_to(p.R).as_posix()))
    record = dict(stage='BV',
        scope='Actual current source inputs and authenticated acquisition metadata only. No build/run result implied.',
        source=entries, metadata=evidence, original_nextn_layer=78, original_layer_roles=1569,
        shared_embedding_head_roles=2, original_total_roles=1571,
        original_total_payload_bytes=p.STATIC_BYTES + p.MOE_BYTES,
        original_static27=static['receipt']['role_payload_bytes'], original_moe1544=p.MOE_BYTES,
        payload_bodies_read=False, payload_bodies_rehashed=False, native_run=False,
        semantics='Snapshot contains actual current files including the two CMake files, not the old BU bodies. '
                  'Original NextN weights do not certify a trained target producer or task quality.')
    p.save(output / 'freeze.json', record)
    print('FROZEN actual current BV34 source inputs; metadata only, no payload body read', flush=True)


if __name__ == '__main__':
    main()
