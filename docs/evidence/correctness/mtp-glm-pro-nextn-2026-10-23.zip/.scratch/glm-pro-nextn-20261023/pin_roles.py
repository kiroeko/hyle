"""Pin original Pro metadata after root's acquisitions finish; never read payload bodies."""
from pathlib import Path
import hashlib
import json
import os
import re
import struct

S = Path(__file__).resolve().parent
R = S.parents[1]
REPOSITORY = 'zai-org/GLM-5.3'
REVISION = 'aca966e4e02791568aa6a4ced368624b3d897f42'
STATIC_BYTES = 4_132_023_424
MOE_BYTES = 9_706_940_416
STATIC_ROLES, MOE_ROLES = 27, 1544
BODY_SHA256 = '15a355853aea060410706f5f9721b7bbaee1512e7d75109d100fdd4c516ef535'
HEADER = R / 'tests/compute_models/glm_pro_original_roles.h'
HEX = re.compile(r'[0-9a-f]{64}\Z')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def local_path(value):
    path = (R / value).resolve()
    require(path.is_relative_to(R), 'metadata path escapes the repository')
    return path


def small_bytes(path, limit=8 * 1024 * 1024):
    path = Path(path)
    require(path.stat().st_size <= limit, 'metadata read exceeds its bounded limit')
    return path.read_bytes()


def read(path):
    return json.loads(small_bytes(path).decode('utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    raw = small_bytes(path)
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def atomic_bytes(path, raw):
    path = Path(path)
    temporary = path.with_name(path.name + '.next')
    with temporary.open('wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def save(path, value):
    atomic_bytes(path, (json.dumps(value, indent=2) + '\n').encode('utf-8'))


def digest(value, label):
    require(isinstance(value, str) and HEX.fullmatch(value), label + ' is not a SHA256')
    return value


def check_identity(record, plan, plan_path):
    require(record['repository'] == plan['repository'] == REPOSITORY, 'repository differs')
    require(record['revision'] == plan['revision'] == REVISION, 'revision differs')
    require(local_path(record['source_plan']) == plan_path.resolve(), 'source plan path differs')
    require(record['source_plan_sha256'] == identity(plan_path)['sha256'], 'source plan identity differs')


def check_row(row, planned):
    for key in ('name', 'dtype', 'shape', 'bytes', 'source_shard',
                'data_relative_half_open', 'absolute_inclusive', 'ordinal'):
        require(row[key] == planned[key], 'role metadata differs: ' + planned['name'] + '/' + key)


def validate_static():
    plan_path = S / 'static-plan.json'
    receipt_path = S / 'original-static/acquisition.json'
    plan, receipt = read(plan_path), read(receipt_path)
    check_identity(receipt, plan, plan_path)
    require(receipt['complete'] is True and receipt['original_roles'] == STATIC_ROLES,
            'static acquisition is not complete27')
    require(receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] ==
            receipt['expected_role_payload_bytes'] == plan['expected_role_payload_bytes'] == STATIC_BYTES,
            'static original-byte count differs')
    require(len(receipt['roles']) == len(plan['roles']) == STATIC_ROLES, 'static row count differs')
    rows = {}
    for row, planned in zip(receipt['roles'], plan['roles']):
        check_row(row, planned)
        require(row['filename'] == planned['filename'] and row['complete'] is True,
                'static filename/completion differs')
        require(row['filename'] not in rows, 'duplicate static filename')
        payload = row['payload']
        path = local_path(payload['path'])
        require(path == (S / 'original-static' / row['filename']).resolve(), 'static payload location differs')
        require(payload['bytes'] == row['bytes'] == path.stat().st_size, 'static payload length differs')
        digest(payload['sha256'], row['name'])
        rows[row['filename']] = row
    require(sum(row['bytes'] for row in rows.values()) == STATIC_BYTES, 'static sum differs')
    return dict(plan=plan, receipt=receipt, rows=rows, plan_path=plan_path, receipt_path=receipt_path)


def validate_moe(*, complete=True, typed=True):
    plan_path = S / 'roles-plan.json'
    receipt_path = S / 'original-moe/acquisition.json'
    catalog_path = S / 'original-moe/catalog.json'
    plan, receipt, catalog = read(plan_path), read(receipt_path), read(catalog_path)
    check_identity(receipt, plan, plan_path)
    require(receipt['original_roles'] == plan['original_roles'] == catalog['original_roles'] == MOE_ROLES,
            'MoE original role count differs')
    require(receipt['bundle_bytes'] == plan['bundle_bytes'] == catalog['bundle']['bytes'] == MOE_BYTES,
            'MoE bundle size differs')
    require(catalog['repository'] == REPOSITORY and catalog['revision'] == REVISION,
            'MoE catalog identity differs')
    require(catalog['bundle']['file'] == 'roles.bin', 'MoE bundle filename differs')
    bundle_path = S / 'original-moe/roles.bin'
    require(bundle_path.stat().st_size == MOE_BYTES, 'MoE actual file length differs')
    bundle_sha = digest(catalog['bundle']['sha256'], 'MoE bundle')
    require(len(catalog['roles']) == len(plan['roles']) == MOE_ROLES, 'MoE catalog row count differs')
    ranges = []
    for row, planned in zip(catalog['roles'], plan['roles']):
        check_row(row, planned)
        require(row['bundle_offset'] == planned['bundle_offset'], 'MoE bundle role offset differs')
        digest(row['sha256'], row['name'])
        first, size = row['bundle_offset'], row['bytes']
        require(isinstance(first, int) and isinstance(size, int) and first >= 0 and size > 0 and
                first <= MOE_BYTES and size <= MOE_BYTES - first, 'MoE role is outside its bundle')
        ranges.append((first, first + size))
    cursor = 0
    for first, last in sorted(ranges):
        require(first == cursor, 'MoE original role intervals overlap or leave a hole')
        cursor = last
    require(cursor == MOE_BYTES, 'MoE role intervals do not cover the bundle')
    if complete:
        require(receipt['complete'] is True and receipt['role_payload_bytes'] ==
                receipt['successful_request_body_bytes'] == MOE_BYTES, 'MoE acquisition is incomplete')
        require(local_path(receipt['bundle']['path']) == bundle_path.resolve() and
                receipt['bundle']['bytes'] == MOE_BYTES and receipt['bundle']['sha256'] == bundle_sha,
                'MoE bundle receipt differs')
        require(receipt['catalog'] == identity(catalog_path), 'MoE JSON catalog receipt differs')
    typed_path = S / 'original-moe/catalog.bin'
    if typed:
        raw = small_bytes(typed_path, 64 + 16 * MOE_ROLES)
        require(len(raw) == 64 + 16 * MOE_ROLES, 'MoE typed catalog byte count differs')
        magic, version, count, size, reserved, expected_sha = struct.unpack_from('<8sIIQQ32s', raw)
        require((magic, version, count, size, reserved) == (b'HYGLMM01', 1, MOE_ROLES, MOE_BYTES, 0),
                'MoE typed header differs')
        require(expected_sha.hex() == bundle_sha, 'MoE typed bundle SHA differs')
        for i, row in enumerate(catalog['roles']):
            require(struct.unpack_from('<QQ', raw, 64 + 16 * i) == (row['bundle_offset'], row['bytes']),
                    'MoE typed role range differs')
        if complete:
            require(receipt['typed_catalog'] == identity(typed_path), 'MoE typed catalog receipt differs')
    return dict(plan=plan, receipt=receipt, catalog=catalog, plan_path=plan_path,
                receipt_path=receipt_path, catalog_path=catalog_path, typed_path=typed_path,
                bundle_sha256=bundle_sha)


SPEC = re.compile(r'(Spec\{"([^"\n]+)", "([^"\n]+)", ")([0-9a-f]{64}|)(", c::DataType::(\w+), (\d+), (\d+)\})')
VOCAB = re.compile(r'(inline constexpr shared::Pins kVocabularyPins\{kRepository, kRevision, \{)([^}]*)(\}\};)')
MOE_PIN = re.compile(r'(inline constexpr std::string_view kMoeIndexSha256 = ")([0-9a-f]{64}|)(";)')


def mask_pins(text):
    text, count = SPEC.subn(lambda match: match[1] + match[5], text)
    require(count == 24, 'expected exactly24 static Spec pins')
    text, count = VOCAB.subn(lambda match: match[1] + '"", "", ""' + match[3], text)
    require(count == 1, 'expected one vocabulary Pins group')
    text, count = MOE_PIN.subn(lambda match: match[1] + match[3], text)
    require(count == 1, 'expected one MoE catalogue pin')
    return text


def verify_header(text, static, moe):
    masked = mask_pins(text).encode('utf-8')
    require(hashlib.sha256(masked).hexdigest() == BODY_SHA256, 'supplier body changed outside authorized pins')
    used = set()
    mapping = {'BF16': 'kBFloat16', 'F32': 'kFloat32', 'F8_E4M3': 'kFloat8E4M3FN'}
    for match in SPEC.finditer(text):
        row = static['rows'][match[3]]
        require(row['name'] == match[2], 'Spec name differs from actual payload')
        shape = row['shape']
        require(match[6] == mapping[row['dtype']] and (int(match[7]), int(match[8])) ==
                (shape[0], shape[1] if len(shape) == 2 else 0), 'Spec geometry differs')
        expected = row['payload']['sha256']
        require(match[4] in ('', expected), 'existing static pin differs')
        used.add(match[3])
    filenames = ('embedding.bf16', 'head.bf16', 'norm.bf16')
    require(static['rows']['norm.bf16']['name'] == 'model.layers.78.shared_head.norm.weight',
            'shared norm is not the actual NextN78 norm')
    require(not used.intersection(filenames) and used.union(filenames) == set(static['rows']),
            'static27 roles were omitted or counted twice')
    pins = re.findall(r'"([^"\n]*)"', VOCAB.search(text)[2])
    require(len(pins) == 3, 'vocabulary pin count differs')
    for old, filename in zip(pins, filenames):
        require(old in ('', static['rows'][filename]['payload']['sha256']), 'existing vocabulary pin differs')
    require(MOE_PIN.search(text)[2] in ('', identity(moe['typed_path'])['sha256']), 'existing MoE pin differs')


def main():
    static, moe = validate_static(), validate_moe()
    before = small_bytes(HEADER)
    text = before.decode('utf-8')
    verify_header(text, static, moe)
    text = SPEC.sub(lambda match: match[1] + static['rows'][match[3]]['payload']['sha256'] + match[5], text)
    vocabulary_pins = ', '.join('"' + static['rows'][name]['payload']['sha256'] + '"'
                                for name in ('embedding.bf16', 'head.bf16', 'norm.bf16'))
    text = VOCAB.sub(lambda match: match[1] + vocabulary_pins + match[3], text)
    catalogue = identity(moe['typed_path'])
    text = MOE_PIN.sub(lambda match: match[1] + catalogue['sha256'] + match[3], text)
    verify_header(text, static, moe)
    for match in SPEC.finditer(text):
        require(HEX.fullmatch(match[4]), 'final static pin incomplete')
    require(all(HEX.fullmatch(pin) for pin in re.findall(r'"([^"\n]*)"', VOCAB.search(text)[2])),
            'final vocabulary pin incomplete')
    snapshots = S / 'pin-source'
    snapshots.mkdir(exist_ok=True)
    if not (snapshots / 'before.h').exists():
        atomic_bytes(snapshots / 'before.h', before)
    atomic_bytes(HEADER, text.encode('utf-8'))
    atomic_bytes(snapshots / 'after.h', text.encode('utf-8'))
    save(S / 'pins.json', dict(scope='Actual Pro static27 and distinct1544-role MoE catalog pins only; no math changed.',
        before=dict(path=HEADER.relative_to(R).as_posix(), bytes=len(before), sha256=hashlib.sha256(before).hexdigest()),
        after=identity(HEADER), original_static_roles=STATIC_ROLES, original_moe_roles=MOE_ROLES,
        original_total_roles=1571, original_total_payload_bytes=STATIC_BYTES + MOE_BYTES,
        static_receipt=identity(static['receipt_path']), moe_receipt=identity(moe['receipt_path']),
        original_static_pins=[dict(name=row['name'], payload=row['payload']) for row in static['rows'].values()],
        original_moe_catalogue_pin=catalogue, original_moe_bundle_sha256=moe['bundle_sha256'],
        payload_bodies_rehashed=False, metadata_only=True, native_run=False))
    print('PINNED static27 + original1544 MoE catalog; payload bodies were not read or rehashed', flush=True)


if __name__ == '__main__':
    main()
