"""Default-no-action consumer/test recipes; root freezes actual sources first.

plan cpu|cuda PRIVATE_WRAPPER.cc tests/tools/CASE.h
plan host tests/tools/TEST.cc
build cpu|cuda|host/TEST_STEM

Each target compiles one TU. Model wrappers are supplied after the actual case
signature is known. No SDK/model copying or native consumer execution occurs.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-request-control-20261026'
FIXTURE = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
spec = importlib.util.spec_from_file_location('host_image_build', W/'build.py')
product = importlib.util.module_from_spec(spec)
spec.loader.exec_module(product)
b = product.b


def plan(kind, source, case=None):
    source = (R/source).resolve()
    assert source.is_file() and kind in ('cpu', 'cuda', 'host')
    if kind == 'host':
        assert source.is_relative_to(R/'tests') and case is None
        target = 'host/'+source.stem
        seeds = [source]
    else:
        assert source.is_relative_to(W) and case is not None
        case = (R/case).resolve()
        assert case.is_file() and case.is_relative_to(R/'tests/tools')
        text = source.read_text(encoding='utf8')
        assert '#include "engine/models/qwen35/main.cc"' in text
        assert case.relative_to(R).as_posix() in text
        target = kind+'2'
        seeds = [R/'engine/models/qwen35/main.cc', case]
    out = W/target
    assert not (out/'plan.json').exists(), 'Preserve each frozen attempt'
    ready = b.read(B/'cpu2/ready.json')
    for field in ('image', 'runtime', 'link_inputs'): b.exact(ready[field])
    inputs = b.read(ready['link_inputs']['path']); old = ready['object']
    assert len(inputs) == 221 and sum(b.key(row['path']) == b.key(old['path']) for row in inputs) == 1
    for row in inputs:
        if b.key(row['path']) != b.key(old['path']): b.exact(row)
    shared = product.shared_arena(inputs)
    report = b.read(B/'reused-report-abi.json')
    checked = product.check_report(report)
    b.save(out/'reused-report-abi.json', report | dict(checked_current_dependencies=checked))
    frozen = product.source_closure(seeds)
    b.save(out/'source-freeze.json', frozen)
    recipe = B/('compile/command.json' if kind == 'cuda' else 'cpu2/compile/command.json')
    command = b.compile_command(recipe, source, out/'compile')
    image = out/'link'/(source.stem+'.exe' if kind == 'host' else 'host-image-consumer.exe')
    b.save(out/'link-inputs-before.json', inputs)
    b.save(out/'plan.json', dict(status='HOST_IMAGE_CONSUMER_FROZEN_NOT_BUILT_OR_RUN', kind=kind,
        target=target, source=b.pin(source), source_freeze=b.pin(out/'source-freeze.json'),
        recipe=b.pin(recipe), command=command, link_recipe=b.pin(B/'cpu2/link/command.json'),
        inputs=b.pin(out/'link-inputs-before.json'), replaced_object=old, shared_arena=shared,
        baseline_image=ready['image'], baseline_runtime=ready['runtime'],
        reused_report_abi=b.pin(out/'reused-report-abi.json'), image_path=str(image),
        fixture_manifest=b.pin(FIXTURE/'weights.tsv') if kind != 'host' else None,
        case=b.pin(case) if case else None,
        scope='One host contract TU' if kind == 'host' else 'One actual canonical Model plus private HostImage consumer wrapper TU',
        limits=['Retained CPU/GTest link closure has no separate CLI entry; replace only its Model/test TU and the shared arena OBJ.',
                'No other SDK, weights, provider, native or report compilation; no executable or SDK copy and no consumer run.']))
    print('HOST_IMAGE_CONSUMER_PLAN', json.dumps(b.pin(out/'plan.json')), flush=True)


def build(target):
    assert target in ('cpu2', 'cuda2') or target.startswith('host/')
    out = (W/target).resolve()
    assert out.is_relative_to(W) and not (out/'compile').exists() and not (out/'ready.json').exists()
    unit = b.read(out/'plan.json')
    assert unit['target'] == target
    for field in ('source', 'source_freeze', 'recipe', 'link_recipe', 'inputs', 'baseline_image',
                  'baseline_runtime', 'reused_report_abi'):
        b.exact(unit[field])
    for field in ('case', 'fixture_manifest'):
        if unit[field]: b.exact(unit[field])
    product.check_report(b.read(unit['reused_report_abi']['path']))
    b.exact(unit['shared_arena']['ready']); b.exact(unit['shared_arena']['object'])
    frozen = b.read(unit['source_freeze']['path'])
    for row in frozen: b.exact(row)
    inputs = b.read(unit['inputs']['path'])
    for row in inputs:
        if b.key(row['path']) != b.key(unit['replaced_object']['path']): b.exact(row)
    h = b.helper(); compiler = unit['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(unit['command'], env, out/'compile', timeout=120)
    dep = b.read(out/'compile/dependencies.json')['Data']
    actual = [b.pin(path) for path in dict.fromkeys([dep['Source'], *dep['Includes']])]
    by_key = {b.key(row['path']):row for row in [*frozen, unit['source']]}
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch') or b.key(path) == b.key(unit['source']['path']):
            assert b.key(path) in by_key and row['sha256'] == by_key[b.key(path)]['sha256'], str(path)
    for row in frozen: b.exact(row)
    b.save(out/'actual-dependencies.json', actual)
    obj = b.pin(out/'compile/unit.obj')
    command, replaced, arena_replaced = [], 0, 0
    for arg in b.read(unit['link_recipe']['path'])['command']:
        if b.key(arg) == b.key(unit['replaced_object']['path']): arg = obj['path']; replaced += 1
        elif b.key(arg) == b.key(unit['shared_arena']['replaces']['path']): arg = unit['shared_arena']['object']['path']; arena_replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+unit['image_path']
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(out/'link/consumer.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(out/'link/consumer.lib')
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    assert replaced == arena_replaced == 1
    linked = h.execute(command, env, out/'link', timeout=120)
    final = [obj if b.key(row['path']) == b.key(unit['replaced_object']['path']) else unit['shared_arena']['object']
        if b.key(row['path']) == b.key(unit['shared_arena']['replaces']['path']) else row for row in inputs]
    b.save(out/'link-inputs.json', final)
    runtime = b.read(unit['baseline_runtime']['path']); b.exact(runtime['native'])
    alias = out/'link'/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias); runtime['native_hardlink'] = b.pin(alias)
    b.save(out/'runtime.json', runtime)
    b.save(out/'ready.json', dict(status='HOST_IMAGE_'+unit['kind'].upper()+'_BUILT_NOT_RUN',
        image=b.pin(unit['image_path']), runtime=b.pin(out/'runtime.json'), source=unit['source'],
        source_freeze=unit['source_freeze'], actual_dependencies=b.pin(out/'actual-dependencies.json'),
        plan=b.pin(out/'plan.json'), link_inputs=b.pin(out/'link-inputs.json'), object=obj,
        compile=compiled, link=linked, shared_arena=unit['shared_arena'], compiled_TUs=1,
        Model_TUs=0 if unit['kind'] == 'host' else 1, unchanged_inputs=219,
        other_SDK_native_provider_report_builds=0, consumer_runs=0, scope=unit['scope'], limits=unit['limits']))
    print('HOST_IMAGE_CONSUMER_READY', json.dumps(b.pin(out/'ready.json')), flush=True)


if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1:3] == ['plan', 'host']: plan('host', Path(sys.argv[3]))
    elif len(sys.argv) == 5 and sys.argv[1] == 'plan' and sys.argv[2] in ('cpu', 'cuda'):
        plan(sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4]))
    elif len(sys.argv) == 3 and sys.argv[1] == 'build': build(sys.argv[2])
    else: print(__doc__)
