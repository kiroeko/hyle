"""Prepare two original-weight candidates; do not launch work or an analyzer."""
from pathlib import Path
import ast
import copy
import hashlib
import json

D = Path(__file__).resolve().parent
W = D.parent
R = W.parents[1]
OLD = R / '.scratch/inference-request-control-20261026/consumer-cases'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest)


old, previous, traces = [read(OLD / name) for name in ['manifest.json', 'comparisons.json', 'tracehashes.json']]
old_ready = read(OLD.parent / 'ready.json')
baseline = old_ready['image']
current = read(W/'ready.json')
for field in ('image','runtime','source','source_freeze'):
    assert pin(current[field]['path']) == current[field]
assert baseline['sha256'] == 'c31a44697ecd106b3dbd77db006e9cc3ad3e01a50c61c7104c536567f7e62401'
assert previous['status'] == 'PASS'
cases, baseline_observed = [], []
for mode, pid in [('ordinary', 62132), ('mtp-k1', 28616)]:
    original = next(case for case in old['cases'] if case['id'] == mode + '-candidate')
    process = read(original['process_record'])
    assert process['exit'] == 0 and not process['timeout'] and process['pid'] == pid
    assert process['image'] == baseline and process['command'] == original['argv']
    facts = next(pair for pair in previous['pairs'] if pair['mode'] == mode)
    trace = next(pair for pair in traces['pairs'] if pair['mode'] == mode)
    assert len(facts['ignored_time_rate_paths']) == 55
    control = copy.deepcopy(original)
    control.update(id=mode + '-baseline', arm='baseline', execution='REUSE_EXISTING_OBSERVED_PROCESS_ONLY',
        image=baseline, ready=pin(OLD.parent / 'ready.json'), runtime=old_ready['runtime'])
    control['observed'] = dict(pid=pid, process=pin(original['process_record']),
        stdout=pin(original['stdout']), stderr=pin(original['stderr']),
        non_time_report_sha256=facts['normalized_baseline_report_sha256'],
        trace_inventory_sha256=trace['inventory_sha256'], trace_file_count=facts['trace_file_count'],
        ignored_time_rate_paths=facts['ignored_time_rate_paths'])
    baseline_observed.append(control['observed'])
    candidate = copy.deepcopy(original)
    output = D / 'runs' / (mode + '-candidate')
    candidate.update(image=current['image'], ready=pin(W/'ready.json'), runtime=current['runtime'],
        stdout=str(output / 'stdout.json'), stderr=str(output / 'stderr.log'),
        process_record=str(output / 'process.json'), trace=str(output / 'trace'),
        execution='AUTHORIZED_ONCE_AFTER_SUCCESSFUL_FROZEN_BUILD', watchdog_seconds=60)
    candidate['argv'][0] = candidate['image']['path']
    candidate['argv'][candidate['argv'].index('--trace') + 1] = candidate['trace']
    candidate['environment']['PATH_prepend'] = str(W / 'link')
    candidate['environment']['runtime_PATH_from'] = str(W / 'runtime.json')
    assert candidate['argv'][1:-1] == original['argv'][1:-1]
    cases.extend([control, candidate])
manifest = copy.deepcopy(old)
manifest.update(status='READY_TWO_HOST_IMAGE_CLI_CANDIDATES_NOT_RUN',
    purpose='HostImage integration ordinary/K1 regression; fixed mathematics, weights, schedules and sampling; no speed ranking.',
    source_manifest=pin(OLD / 'manifest.json'), baseline=baseline, baseline_observed=baseline_observed,
    candidate=dict(path=str(W / 'link/hyle.exe'), ready_path=str(W / 'ready.json'),
        runtime_path=str(W / 'runtime.json'), image_pin_pending=False, image=current['image'], ready=pin(W/'ready.json')), cases=cases)
manifest['comparison'].update(reference_comparisons=pin(OLD / 'comparisons.json'),
    reference_trace_inventory=pin(OLD / 'tracehashes.json'),
    complete_JSON='Exactly the prior55 clock/rate paths per mode may be excluded; all remaining type/value/presence including resources, paths and ledgers are exact. No new exclusions.')
D.mkdir(parents=True, exist_ok=True)
with (D / 'manifest.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(manifest, stream, ensure_ascii=False, indent=2); stream.write('\n')
comparator = (OLD / 'compare.py').read_text(encoding='utf-8')
comparator = comparator.replace("reference['normalized_report_sha256']", "reference['normalized_baseline_report_sha256']")
ast.parse(comparator)
with (D / 'compare.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(comparator)
print(json.dumps(dict(manifest=pin(D / 'manifest.json'), comparator=pin(D / 'compare.py'))))
