"""Publish one bounded archive from completed local receipts; default no action.

Root calls `python -B collect-evidence.py publish` only after it has concluded
the explicit HostImage case attempts. This never builds, runs a consumer/analyzer,
downloads, walks SDK/weight/trace directories or deletes anything.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import subprocess
import sys
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
C = W / 'consumer-cases'
B = R / '.scratch/inference-request-control-20261026'
DEST = R / 'docs/evidence/correctness/inference-host-image-2026-10-26'
SOURCES = ('engine/inference/backend.h', 'engine/inference/host_state_storage.h',
    'engine/inference/state_transfer.h', 'engine/models/qwen35/host_image.h',
    'engine/models/qwen35/session_transfer.h', 'engine/models/qwen35/main.cc',
    'include/hyle/compute/paged_arena.h', 'src/compute_batch/paged_arena.cc',
    'src/compute_backend_cuda/cuda_memory.cc',
    'tests/compute_batch/paged_arena_test.cc', 'tests/compute_batch/row_cache_paged_test.cc',
    'tests/tools/qwen_host_image_case.h', 'tests/tools/qwen_request_lifecycle_test.cc')
COMPILES = ('arena/implementation', 'arena/paged-test', 'arena/row-test', 'compile',
    'cpu/compile', 'cuda/compile', 'cpu2/compile', 'cuda2/compile',
    'product2/compile', 'cpu3/compile', 'cuda4/compile')
CASES = (('cpu-tiny-before-coherence-fix', 'cpu2/run1', False),
    ('cuda-tiny', 'cuda3/run1', False),
    ('cuda-original-before-coherence-fix', 'cuda3/run2', False),
    ('cpu-tiny', 'cpu3/run1', True), ('cuda-original-335', 'cuda4/run1', True))


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def git(*args):
    return subprocess.run(['git', *args], cwd=R, capture_output=True, check=True).stdout


def provider_boundary():
    path = R / 'third_party/ggml_cuda_runtime/patches.json'
    patches = read(path)
    file = next(row for row in patches['files'] if row['path'] == 'src/ggml-cuda/ssm-conv.cu')
    after = next(row['after'] for row in file['edits'] if 'bool ggml_cuda_supports_ssm_conv(' in row['after'])
    start = after.index('bool ggml_cuda_supports_ssm_conv(')
    end = after.index('    // Prove the kernel', start)
    return dict(classification='CUDA_TINY_UNSUPPORTED_SHAPE_BEFORE_EVALUATION',
        source=pin(path), upstream_revision=patches['upstream_revision'],
        patch_target=file['path'], predicate_excerpt=after[start:end],
        tiny_QKV_channels=192, original335_QKV_channels=6144,
        condition='SSM_CONV CUDA support requires C % 128 == 0. Tiny C192 violates it; original335 C6144 satisfies this condition only, not proof of all other support or runtime success.',
        limit='The tiny CUDA process loaded 27 roles, then cold exact-variant compilation declined SSM_CONV F32 value2 before evaluation. It is neither a completed HostImage case nor evidence of a HostImage numerical failure.')


def publish():
    # Fixed final paths and exclusive creation preserve earlier failures/results.
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    files = {}

    def add(path, optional=False):
        path = Path(path)
        if optional and not path.exists(): return
        assert path.is_file() and path.is_relative_to(R), str(path)
        assert path.suffix.lower() in {'.h', '.cc', '.py', '.json', '.log', '.txt', '.xml', '.ids', '.schedule', '.tsv'}
        assert path.stat().st_size < 2_000_000, str(path)
        files[path.relative_to(R).as_posix()] = path

    def stage(folder):
        for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'):
            add(folder / name)
        add(folder / 'dependencies.json', optional=True)

    def run(folder, stdout='stdout.log', command=True):
        for name in ('process.json', stdout, 'stderr.log'): add(folder / name)
        if command: add(folder / 'command.json', optional=True)
        add(folder / 'summary.json', optional=True)

    for name in SOURCES: add(R / name)
    for name in ('collect-evidence.py', 'arena.py', 'build.py', 'consumer.py', 'consumer2.py',
                 'consumer-before-cuda-closure-fix.py', 'consumer2-before-cuda-closure-fix.py',
                 'relink-cuda3.py', 'run-case-before-cuda-closure-fix.py',
                 'run-case-before-pinned-host-fix.py',
                 'product2.py', 'consumer-next.py', 'pinned-host-visibility-correction.json',
                 'run-arena.py', 'run-case.py', 'run-models.py', 'inspect-fixtures.py',
                 'fixture-inventory.json', 'preparation.json', 'case-ctad-correction.json',
                 'cpu-consumer.cc', 'cuda-consumer.cc', 'plan.json', 'ready.json', 'runtime.json',
                 'source-freeze.json', 'actual-dependencies.json', 'reused-report-abi.json',
                 'link-inputs.json'):
        add(W / name)
    compile_attempts = []
    for name in COMPILES:
        folder = W / name
        stage(folder)
        process = read(folder / 'process.json')
        compile_attempts.append(dict(stage=name, process=process,
            command=pin(folder / 'command.json'), stdout=pin(folder / 'stdout.log'),
            stderr=pin(folder / 'stderr.log')))
    link_stages = ('link', 'arena/link', 'cpu2/link', 'cuda2/link', 'cuda3/link',
        'product2/link', 'cpu3/link', 'cuda4/link')
    for name in link_stages: stage(W / name)
    for target in ('arena', 'cpu', 'cuda', 'cpu2', 'cuda2', 'cuda3', 'product2', 'cpu3', 'cuda4'):
        for name in ('plan.json', 'source-freeze.json', 'ready.json', 'runtime.json',
                     'actual-dependencies.json', 'reused-report-abi.json'):
            add(W / target / name, optional=True)
        add(W / target / 'link-inputs.json', optional=True)
        add(W / target / 'link-inputs-before.json', optional=True)
    for name in ('link-inputs-before.json', 'link-inputs.json', 'closure-correction.json'):
        add(W / 'cuda3' / name)
    # The first CUDA wrapper linked successfully across different feature
    # macro sets. Both representative weights objects actually included CUDA.
    # Keep that actual runtime failure, rather than relabelling it as product
    # failure or silently replacing the first result after a link-only fix.
    run(W / 'cuda2/run1')
    failed_runtime = dict(process=read(W / 'cuda2/run1/process.json'),
        stdout=pin(W / 'cuda2/run1/stdout.log'), stderr=pin(W / 'cuda2/run1/stderr.log'),
        classification='PRIVATE_CONSUMER_CROSS_FEATURE_ODR_LINK_CLOSURE_MISMATCH',
        diagnosis='CUDA consumer TU used a CPU-representative engine link closure with additional HYLE_CPU/GGML_CPU/ONEDNN/GRAPH_ONEDNN feature macros. Both representative weights recipes included CUDA and used the same old backend.h SHA7fa40bcd91706096187d7c52387d29c97a79434a31083642cb58ff6374b9e8e2. The mismatch is across feature-dependent Backend inline/variant ODR closure; the earlier claim that the weights object lacked the CUDA branch is not supported.',
        correction='CUDA3 only relinks the identical CUDA2 Model object against the retained passing CUDA CLI closure, removing its original entry and Model object. No product/wrapper source or CUDA2 compile object changed for that correction; its compile-attempt subtotal remained eight. The recorded same-TU relink/run outcome is the bounded correction check, without an additional causal experiment. The later separate product coherence fix adds three Model TUs.',
        link_facts=read(W / 'cuda3/closure-correction.json'))
    add(W / 'arena/test-result.xml'); add(W / 'arena/run-summary.json')
    run(W / 'arena/run1')
    for name in ('prepare.py', 'compare.py', 'manifest.json', 'comparisons.json',
                 'tracehashes.json', 'process-summary.json'):
        add(C / name)
    for mode in ('ordinary-candidate', 'mtp-k1-candidate'):
        run(C / 'runs' / mode, 'stdout.json', command=False)
        # The observed controls are referenced/reused; no control rerun or raw
        # trace copy. Their small original reports make comparison reviewable.
        for name in ('process.json', 'stdout.json'):
            add(B / 'consumer-cases/runs' / mode / name)
    for name in ('ready.json', 'runtime.json'): add(B / name)
    case_results = []
    for label, relative, final in CASES:
        folder = W / relative
        if not (folder / 'process.json').exists():
            case_results.append(dict(id=label, final=final, passed=False, outcome='NOT_RUN',
                reason='No native process receipt exists; no case success or failure is inferred.'))
            continue
        run(folder)
        add(folder / 'running.json', optional=True)
        process = read(folder / 'process.json')
        try: result = read(folder / 'stdout.log')
        except (ValueError, UnicodeError): result = dict(status='NO_COMPLETE_JSON_REPORT')
        passed = process['exit'] == 0 and not process.get('timeout', False) and result.get('status') == 'PASS'
        stderr = (folder / 'stderr.log').read_text(encoding='utf-8-sig')
        outcome = 'PASS' if passed else 'FAILED'
        if label == 'cuda-tiny' and process['exit'] == 1 and 'SSM_CONV (f32), value 2' in stderr:
            outcome = 'FAILED_BEFORE_EVALUATION_UNSUPPORTED_PROVIDER_SHAPE'
        if process['exit'] == 1 and 'host-state storage must expose coherent host bytes' in stderr:
            outcome = 'PRODUCT_BUG_OVERSTRONG_HOST_COHERENCE_REQUIREMENT_AFTER_PREFILL'
        case_results.append(dict(id=label, final=final, passed=passed, outcome=outcome, process=process, result=result,
            process_receipt=pin(folder / 'process.json'), stdout=pin(folder / 'stdout.log'),
            stderr=pin(folder / 'stderr.log')))
    # Preserve the one fixed schedule set, not the prepared/weight input library.
    fixed = R / '.scratch/inference-working-state-20261026/consumer-cases'
    for name in ('alice.initial.ids', 'alice.suffix.ids', 'alice.schedule', 'bob.initial.ids',
                 'bob.suffix.ids', 'bob.schedule', 'empty.ids', 'sessions.tsv'):
        add(fixed / name)
    previous_path = R / 'docs/evidence/correctness/inference-request-controls-2026-10-26.json'
    previous = read(previous_path)
    original_page_suite = previous['page_exports']
    page_suite = read(W / 'arena/run-summary.json')
    comparison = read(C / 'comparisons.json')
    correction = read(W / 'case-ctad-correction.json')
    current_source = {row['path']: row for row in [pin(R / name) for name in SOURCES]}
    # Record source/ABI input identities and exact current tracked source diff;
    # untracked source bodies above are archived directly, never silently omitted.
    diff = git('diff', '--binary', '9682a3961', '--', *SOURCES)
    untracked = git('ls-files', '--others', '--exclude-standard', '--', *SOURCES).decode().splitlines()
    attempts_by_exit = Counter(str(row['process']['exit']) for row in compile_attempts)
    final_cases = [row for row in case_results if row['final']]
    required_pass = page_suite['status'] == 'PASS' and comparison['status'] == 'PASS' and all(
        row['passed'] for row in final_cases)
    status = 'PASS_WITH_DOCUMENTED_PROVIDER_LIMIT_AND_FIXED_FAILURES' if required_pass else 'HAS_FAILURE_OR_UNCOVERED_RESULT'
    summary = dict(status=status, required_CPU_tiny_and_CUDA_original_cases_pass=required_pass,
        baseline_commit='9682a3961',
        publication_head=git('rev-parse', 'HEAD').decode().strip(), sources=list(current_source.values()),
        source_diff=dict(bytes=len(diff), sha256=hashlib.sha256(diff).hexdigest(),
            archive_entry='publication/source.diff', untracked_source_files_archived=untracked),
        builds=dict(compile_attempts=len(compile_attempts), attempts_by_exit=dict(attempts_by_exit),
            attempts=compile_attempts,
            link_attempts=[dict(stage=name, process=read(W / name / 'process.json')) for name in link_stages],
            scope='Actual compiler process receipts: arena implementation + two existing page tests + original CLI Model + initial CPU/CUDA case failures + CTAD-corrected CPU2/CUDA2 case TUs (eight attempts), then coherence-corrected product2 CLI, CPU3 case and CUDA4 case (three more attempts). CUDA3 was link-only. No SDK/provider/native/report/weight rebuild.',
            correction=correction, preserved_private_link_failure=failed_runtime),
        page_exports=dict(reused_37_test_result=original_page_suite, reused_publication=pin(previous_path),
            new_bulk_suite=page_suite,
            scope='Original37 PagedArena/RowCache tests were already observed PASS; the new38-test suite adds bounded bulk initialized-prefix export. Host tests are not GPU pending-copy proof.'),
        ordinary_K1_CLI=dict(comparisons=comparison, processes=read(C / 'process-summary.json'),
            trace_inventory=pin(C / 'tracehashes.json'),
            scope='Two observed cached335-role BF16 CUDA CLI candidates from the original W/link/hyle.exe versus reused controls. Per-mode exactly55 clock/rate exclusions; every other JSON field is exact, including resources/paths/ledgers. 78+68 trace files independently hashed; no raw trace packaged. These runs precede the two-header coherence correction. The later product2 CLI is build-only; this comparison is not attributed to its new image.',
            existing_MTP_recompute_fact=comparison['important_existing_fact']),
        complete_host_image_cases=final_cases,
        preserved_host_image_attempts=[row for row in case_results if not row['final']],
        product_coherence_fix=dict(classification='PRODUCT_SOURCE_CORRECTION_APPLIED',
            verified_by_final_host_image_cases=all(row['passed'] for row in final_cases),
            correction_receipt=read(W / 'pinned-host-visibility-correction.json'),
            failed_process=pin(W / 'cuda3/run2/process.json'), failed_stderr=pin(W / 'cuda3/run2/stderr.log'),
            reason='CUDA pinnedHost intentionally declares HostAccessible/HostPinned/HostAddressIdentity without HostDeviceCoherent. Requiring the latter rejected valid same-context host storage after real prefill.',
            correction='Remove only the extra coherence-property conditions in HostStateStorage::create and HostImage payload validation. Preserve HostAccessible, exact bytes/ready leases, resource API host reads, and successful original CopyBatch wait before writer/payload publication.',
            source_basis=dict(cuda_memory=pin(R / 'src/compute_backend_cuda/cuda_memory.cc'),
                locations=['src/compute_backend_cuda/cuda_memory.cc:32 pinnedHost flags',
                    'src/compute_backend_cuda/cuda_memory.cc:59 map_host',
                    'src/compute_backend_cuda/cuda_memory.cc:92 invalidate',
                    'src/compute_backend_cuda/cuda_memory.cc:127 read',
                    'engine/models/qwen35/session_transfer.h:155 export wait before publish',
                    'engine/models/qwen35/session_transfer.h:225 import wait before publish']),
            final_product_CLI=dict(status='BUILT_ONLY_NOT_RUN', ready=read(W / 'product2/ready.json'))),
        provider_shape_boundary=provider_boundary(),
        case_scope='Final corrected HostImage cases are CPU3 tiny GA and CUDA4 original335 roles, each exercising ordinary and K1 modes only when its result is PASS. Preserve CPU2 earlier PASS, CUDA3 tiny unsupported-shape rejection, and CUDA3 original335 actual product coherence rejection; no CUDA tiny rerun. CUDA2 link-closure failure is preserved separately. Read actual per-role payload/byte/nonzero counts, boundary/old-alias/continuation/Model-expiry and budget-failure facts; do not infer nonzero from role presence or treat unsupported tiny shape as a HostImage numerical failure.',
        limits=['Finite correctness and ownership evidence, no quality, latency, throughput or speedup claim.',
            'Final MTP cases exercised lag0 with no prior-hidden payload. Lag1/prior-hidden transfer was not exercised in these cases.',
            'Tiny GA is untrained. Raw HF RMS zero has effective gamma one; direct GDN norm zero can mask its mixed contribution. Actual full-byte and zero/nonzero facts are recorded, not assumed.',
            'No physical-GPU pending gate/fault injection is introduced in these HostImage cases. Native failure/unknown-retirement safety is preserved by original ownership contracts; successful synchronous cases do not alone verify every fault path.',
            'Host parking returns reusable device slots, not an automatic reduction in fixed-bank allocated VRAM. Old checkpoint aliases remain valid retainers.',
            'Managed ResourceBudget rows/shared cap and image count are bounded; opaque driver/private native memory is explicitly outside the managed byte cap.',
            'Apple/Vulkan complete-state transfer remains unimplemented in this common CPU/CUDA adapter; no cross-platform claim.',
            'Archive contains only explicit small source/recipe/process/output/fixture-identity/comparison/hash metadata. No binary, SDK, model weights, full raw traces or copied prepared input library.'])
    inventory = [pin(path) | dict(entry=name) for name, path in sorted(files.items())]
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.writestr('publication/source.diff', diff)
        archive.writestr('publication/summary.json', encode(summary))
        archive.writestr('publication/files.json', encode(inventory))
        for name, path in sorted(files.items()): archive.write(path, name)
    summary['archive'] = pin(DEST.with_suffix('.zip'))
    summary['archive_members'] = len(files) + 3
    with DEST.with_suffix('.json').open('xb') as stream: stream.write(encode(summary))
    print(json.dumps(dict(report=pin(DEST.with_suffix('.json')), archive=summary['archive'], status=summary['status'])))


if __name__ == '__main__':
    if sys.argv[1:] == ['publish']: publish()
    else: print(__doc__)
