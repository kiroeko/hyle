"""Run only the two prepared candidates; reuse observed controls unchanged."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

work = Path(__file__).resolve().parent
root = work.parents[1]
manifest = json.loads((work / 'consumer-cases/manifest.json').read_text())
ready = json.loads((work / 'ready.json').read_text())
def exact(pin):
    path = Path(pin['path'])
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert path.stat().st_size == pin['bytes'] and digest == pin['sha256'], str(path)

for item in [ready['image'], ready['runtime'], manifest['input_source'], *manifest['fixed_files']]:
    exact(item)
cases = [row for row in manifest['cases'] if row['arm'] == 'candidate']
assert len(cases) == manifest['native_process_limit'] == 2
runtime = json.loads(Path(ready['runtime']['path']).read_text())
for row in cases:
    assert row['argv'][0] == row['image']['path'] == ready['image']['path']
    assert row['watchdog_seconds'] == 60
    env = os.environ.copy()
    env.update(runtime.get('configured_flags', {}))
    env.update(PATH=str(Path(ready['image']['path']).parent) + ';' + runtime['PATH'],
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    folder = Path(row['process_record']).parent
    folder.mkdir(parents=True)
    start = time.perf_counter()
    with Path(row['stdout']).open('xb') as out, Path(row['stderr']).open('xb') as err:
        child = subprocess.Popen(row['argv'], cwd=row['cwd'], env=env, stdout=out, stderr=err,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        (folder/'running.json').write_text(json.dumps(dict(pid=child.pid, command=row['argv'], image=ready['image'], source=ready['source']),indent=2)+'\n')
        print(row['id'], 'native_pid', child.pid, flush=True)
        timeout = False
        try:
            code = child.wait(timeout=row['watchdog_seconds'])
        except subprocess.TimeoutExpired:
            timeout = True
            child.kill()
            code = child.wait(timeout=10)
    result = dict(id=row['id'], mode=row['mode'], arm=row['arm'], pid=child.pid, exit=code,
                  timeout=timeout, seconds=time.perf_counter() - start, command=row['argv'],
                  image=ready['image'], runtime=ready['runtime'], input_source=manifest['input_source'], source=ready['source'], source_freeze=ready['source_freeze'])
    Path(row['process_record']).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(id=row['id'], pid=child.pid, exit=code, timeout=timeout, seconds=result['seconds'])), flush=True)
    assert code == 0 and not timeout, 'Preserve the actual failure; no automatic retry'
