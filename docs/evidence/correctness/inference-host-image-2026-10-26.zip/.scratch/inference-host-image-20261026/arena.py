"""Explicit three-TU page-export build; never runs GTest or inference.

Only canonical paged_arena.cc and the existing two test TUs are compiled.
The retained CPU closure has no separate entry: remove its Model wrapper,
replace its arena object and use its existing gtest_main. No archive rewrite.
"""
from pathlib import Path
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
A = W/'arena'
B = R/'.scratch/inference-request-control-20261026'
OLD = R/'.scratch/inference-f32-append-20261025/cpu1'
P = R/'.scratch/inference-review-fixes-20261026'
spec = importlib.util.spec_from_file_location('retained_recipe', P/'build-before-final.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
SOURCES = ('src/compute_batch/paged_arena.cc', 'tests/compute_batch/paged_arena_test.cc',
           'tests/compute_batch/row_cache_paged_test.cc')
EXPECTED = {'include/hyle/compute/paged_arena.h': '7bb855e5d19f21444f9e5550cafb854ee0c2e3b836c5930fa8569bf2a1c2cca2', 'src/compute_batch/paged_arena.cc': '79b05ed31b19dfad3e71a0e24211e55ccc7d32e294d708d6d124c2c48b45b0d3', 'tests/compute_batch/paged_arena_test.cc': '428be3a5131e258d6e96e78f2bd0fa36dc1bfd7fc65a2b09dee66fdc80db260e', 'tests/compute_batch/row_cache_paged_test.cc': '259e1463c9481735c3527e60f2f873b2abe90a9ae5667752e2f3aec80b745e79'}



def closure(seeds):
    todo, found = list(seeds), {}
    dirs = [R, R/'include', R/'src/compute_batch', R/'src/compute', R/'tests/compute_batch']
    while todo:
        path = Path(todo.pop()).resolve()
        if b.key(path) in found: continue
        assert path.is_relative_to(R) and not path.is_relative_to(R/'.scratch')
        found[b.key(path)] = b.pin(path)
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">\r\n]+)[">]', path.read_text(encoding='utf-8-sig'), re.M):
            for base in [path.parent, *dirs]:
                child = (base/include).resolve()
                if child.is_file():
                    if child.is_relative_to(R) and not child.is_relative_to(R/'.scratch'): todo.append(child)
                    break
    return list(found.values())


def command(recipe, source, folder):
    old = b.read(recipe)['command']
    old_source = next(x for x in old if x.lower().endswith(('.cc', '.cpp')))
    dep = old[old.index('/sourceDependencies')+1]
    result = []
    for arg in old:
        if arg == old_source: arg = str(source)
        elif arg == dep: arg = str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd'+str(folder/'unit.pdb')
        elif arg.startswith('/I'):
            path = Path(arg[2:])
            if path.is_relative_to(OLD/'source'): arg = '/I'+str(R/path.relative_to(OLD/'source'))
            assert str(R/'.scratch').casefold() not in arg.casefold(), arg
        result.append(arg)
    assert all(x in result for x in ('/c', '/O2', '/Ob2', '/MD', '/W4', '/WX'))
    return result


def plan():
    assert not (A/'plan.json').exists(), 'Preserve the frozen attempt'
    for path,digest in EXPECTED.items(): assert b.pin(R/path)['sha256'] == digest, path
    ready = b.read(B/'cpu2/ready.json')
    b.exact(ready['link_inputs']); b.exact(ready['runtime'])
    inputs = b.read(ready['link_inputs']['path'])
    removed = ready['object']  # Deleted old Model wrapper is a removal key only.
    arena = next(x for x in inputs if b.key(x['path']) == b.key(B/'arena/implementation/unit.obj'))
    for row in inputs:
        if b.key(row['path']) != b.key(removed['path']): b.exact(row)
    recipe = OLD/'compile/cpu-arena/command.json'
    units = [dict(name=name, source=b.pin(R/source),
        command=command(recipe, R/source, A/name))
        for name,source in zip(('implementation', 'paged-test', 'row-test'), SOURCES)]
    frozen = closure([R/source for source in SOURCES])
    b.save(A/'source-freeze.json', frozen)
    b.save(A/'plan.json', dict(status='HOST_IMAGE_PAGE_EXPORT_FROZEN_NOT_BUILT_OR_RUN', units=units,
        source_freeze=b.pin(A/'source-freeze.json'), recipe=b.pin(recipe),
        baseline_inputs=ready['link_inputs'], baseline_runtime=ready['runtime'],
        link_recipe=b.pin(B/'cpu2/link/command.json'), removed_model=removed, replaced_arena=arena,
        image_path=str(A/'link/page-export-test.exe'),
        scope='Bulk exact prefix export; original subleases are bounded copy sources, not automatic arena.read compatibility.'))
    print('HOST_IMAGE_PAGE_EXPORT_PLAN', json.dumps(b.pin(A/'plan.json')), flush=True)


def build():
    assert not (A/'implementation').exists() and not (A/'ready.json').exists()
    unit = b.read(A/'plan.json')
    for field in ('source_freeze', 'recipe', 'baseline_inputs', 'baseline_runtime', 'link_recipe'): b.exact(unit[field])
    frozen = b.read(unit['source_freeze']['path'])
    for row in frozen: b.exact(row)
    inputs = b.read(unit['baseline_inputs']['path'])
    for row in inputs:
        if b.key(row['path']) != b.key(unit['removed_model']['path']): b.exact(row)
    h = b.helper(); compiler = unit['units'][0]['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    results = []
    by_key = {b.key(row['path']):row for row in frozen}
    for item in unit['units']:
        b.exact(item['source'])
        folder = A/item['name']
        process = h.execute(item['command'], env, folder, timeout=120)
        dep = b.read(folder/'dependencies.json')['Data']
        actual = [b.pin(x) for x in dict.fromkeys([dep['Source'], *dep['Includes']])]
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
                assert b.key(path) in by_key and row['sha256'] == by_key[b.key(path)]['sha256'], str(path)
        b.save(folder/'actual-dependencies.json', actual)
        results.append(dict(name=item['name'], source=item['source'], object=b.pin(folder/'unit.obj'),
            compile=process, actual_dependencies=b.pin(folder/'actual-dependencies.json')))
    for row in frozen: b.exact(row)
    new_arena = results[0]['object']
    command, removed, replaced = [], 0, 0
    for arg in b.read(unit['link_recipe']['path'])['command']:
        if b.key(arg) == b.key(unit['removed_model']['path']): removed += 1; continue
        if b.key(arg) == b.key(unit['replaced_arena']['path']): arg = new_arena['path']; replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+unit['image_path']
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(A/'link/test.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(A/'link/test.lib')
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    assert removed == replaced == 1
    command.extend(item['object']['path'] for item in results[1:])
    linked = h.execute(command, env, A/'link', timeout=120)
    final = [new_arena if b.key(x['path']) == b.key(unit['replaced_arena']['path']) else x for x in inputs
             if b.key(x['path']) != b.key(unit['removed_model']['path'])]
    final.extend(item['object'] for item in results[1:])
    b.save(A/'link-inputs.json', final)
    runtime = b.read(unit['baseline_runtime']['path']); b.exact(runtime['native'])
    alias = A/'link'/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias); runtime['native_hardlink'] = b.pin(alias)
    b.save(A/'runtime.json', runtime)
    b.save(A/'ready.json', dict(status='HOST_IMAGE_PAGE_EXPORT_BUILT_NOT_RUN', image=b.pin(unit['image_path']),
        runtime=b.pin(A/'runtime.json'), object=new_arena, replaced_arena=unit['replaced_arena'],
        plan=b.pin(A/'plan.json'), source_freeze=unit['source_freeze'], units=results, link=linked,
        link_inputs=b.pin(A/'link-inputs.json'), compiled_TUs=3, unchanged_inputs=219,
        run=[unit['image_path'], '--gtest_filter=PagedArena.*:RowCachePaged.*'],
        archive_rewrites=0, other_SDK_native_provider_report_builds=0, consumer_runs=0, scope=unit['scope']))
    print('HOST_IMAGE_PAGE_EXPORT_READY', json.dumps(b.pin(A/'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    else: print('Prepared only. After root PAGE SOURCE_FROZEN: python -B '+str(__file__)+' plan | build')
