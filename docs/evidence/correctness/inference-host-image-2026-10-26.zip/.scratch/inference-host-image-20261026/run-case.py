"""One explicitly selected bounded HostImage process; never retries/builds.

cpu3 tiny | cuda4 original
Original is an independently authorized consumer after the tiny CUDA provider boundary was identified.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

W = Path(__file__).resolve().parent
R = W.parents[1]
target, inputs = sys.argv[1:]
assert (target, inputs) in (('cpu3', 'tiny'), ('cuda4', 'original'))
if inputs == 'original':
    assert json.loads((W/'cpu3/run1/summary.json').read_text())['status'] == 'PASS'
fixture = R/('.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture' if inputs == 'tiny'
    else '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')
out = W/target/'run1'
assert not out.exists(), 'Preserve the first attempt, never overwrite/retry'
ready_path = W/target/'ready.json'
ready = json.loads(ready_path.read_text())
def pin(path):
    path = Path(path)
    with path.open('rb') as stream: digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest)
def exact(row): assert pin(row['path']) == row, row['path']
for field in ('image', 'runtime', 'source', 'source_freeze', 'actual_dependencies'): exact(ready[field])
for row in json.loads(Path(ready['source_freeze']['path']).read_text()): exact(row)
manifest = pin(fixture/'weights.tsv')
runtime = json.loads(Path(ready['runtime']['path']).read_text())
env = os.environ.copy(); env.update(runtime.get('configured_flags', {}))
env.update(PATH=str(Path(ready['image']['path']).parent)+';'+runtime['PATH'],
    HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
command = [ready['image']['path'], str(fixture)]
timeout = 60 if inputs == 'tiny' else 180
out.mkdir(parents=True)
(out/'command.json').write_text(json.dumps(dict(command=command, cwd=str(R), timeout_seconds=timeout,
    ready=pin(ready_path), image=ready['image'], fixture_manifest=manifest),indent=2)+'\n')
started = time.perf_counter()
with (out/'stdout.log').open('xb') as stdout, (out/'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(command, cwd=R, env=env, stdout=stdout, stderr=stderr,
        creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'running.json').write_text(json.dumps(dict(pid=child.pid, command=command),indent=2)+'\n')
    print('HOST_IMAGE_CASE', target, inputs, 'native_pid', child.pid, flush=True)
    timed_out = False
    try: code = child.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True; child.kill(); code = child.wait(timeout=10)
process = dict(pid=child.pid, exit=code, timeout=timed_out, seconds=time.perf_counter()-started,
    command=command, image=ready['image'], runtime=ready['runtime'], ready=pin(ready_path),
    fixture_manifest=manifest, source=ready['source'], source_freeze=ready['source_freeze'])
(out/'process.json').write_text(json.dumps(process,indent=2)+'\n')
print(json.dumps(process),flush=True)
assert code == 0 and not timed_out, 'Keep the actual failure; stop subsequent cases'
result = json.loads((out/'stdout.log').read_text(encoding='utf8'))
assert result['status'] == 'PASS'
(out/'summary.json').write_text(json.dumps(dict(status='PASS',process=process,result=result,
    scope='One complete byte/lifetime HostImage case process, ordinary/MTP sequential; no quality or throughput claim.'),indent=2)+'\n')
print(json.dumps(result),flush=True)
