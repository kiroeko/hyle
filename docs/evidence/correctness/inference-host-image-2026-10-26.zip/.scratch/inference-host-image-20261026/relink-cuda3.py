"""Relink the existing CUDA2 case OBJ against the actual CUDA CLI closure.

No TU or library is compiled. All failed attempts remain untouched.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
C = W/'cuda3'
spec = importlib.util.spec_from_file_location('host_image_cli_recipe', W/'build.py')
product = importlib.util.module_from_spec(spec)
spec.loader.exec_module(product)
b = product.b
assert not C.exists(), 'Preserve every actual attempt'
cli = b.read(W/'ready.json')
case = b.read(W/'cuda2/ready.json')
for row in (cli['image'], cli['link_inputs'], cli['runtime'], case['object'], case['source'],
            case['source_freeze'], case['actual_dependencies']): b.exact(row)
for row in b.read(case['source_freeze']['path']): b.exact(row)
inputs = b.read(cli['link_inputs']['path'])
assert len(inputs) == 222
entry = next(row for row in inputs if b.key(row['path']).endswith('engine\\entry\\unit.obj'))
model = cli['object']
assert sum(row == model for row in inputs) == 1
weights = next(row for row in inputs if b.key(row['path']).endswith('engine\\weights\\unit.obj'))
for row in inputs: b.exact(row)
command, removed_entry, replaced_model = [], 0, 0
for arg in b.read(W/'link/command.json')['command']:
    if b.key(arg) == b.key(entry['path']): removed_entry += 1; continue
    if b.key(arg) == b.key(model['path']): arg = case['object']['path']; replaced_model += 1
    elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(C/'link/host-image-consumer.exe')
    elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(C/'link/consumer.pdb')
    elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(C/'link/consumer.lib')
    elif arg.upper().startswith('/MAP:'): continue
    command.append(arg)
assert removed_entry == replaced_model == 1
final = [case['object'] if row == model else row for row in inputs if row != entry]
assert len(final) == 221
assert sum(row == weights for row in final) == 1
bad_inputs = b.read(W/'cuda2/link-inputs.json')
bad_weights = next(row for row in bad_inputs if b.key(row['path']).endswith('inference-cpu-representative-20261026\\compile\\weights\\unit.obj'))
recipes = {'mixed_CPU_feature_weights': R/'.scratch/inference-cpu-representative-20261026/compile/weights/command.json',
           'CUDA_CLI_weights': R/'.scratch/inference-current-closure-20261026/engine/weights/command.json'}
macros = {name:dict(recipe=b.pin(path), definitions=[arg for arg in b.read(path)['command'] if arg.startswith('/D')])
          for name,path in recipes.items()}
b.save(C/'link-inputs-before.json', inputs)
b.save(C/'closure-correction.json', dict(status='VALIDATION_SCRIPT_CUDA_CLOSURE_CORRECTION_NOT_PRODUCT_FIX',
    previous_failure=b.pin(W/'cuda2/run1/process.json'), previous_stderr=b.pin(W/'cuda2/run1/stderr.log'),
    reason='consumer.py incorrectly selected the CPU-representative link closure for a CUDA-only-feature case TU. Backend inline/type definitions have different feature sets; use the exact successful CUDA CLI closure.',
    evidence=macros, wrong_weights=bad_weights, retained_CUDA_weights=weights,
    removed_CLI_entry=entry, removed_CLI_Model=model, reused_case_object=case['object'],
    before_inputs=b.pin(C/'link-inputs-before.json'), unchanged_inputs=220,
    notes=['Both weights recipes list CUDA definitions. The CPU-representative recipe additionally defines CPU/GGML_CPU/ONEDNN/GRAPH_ONEDNN, so this is a cross-feature inline/ODR mismatch, not an absence of every CUDA macro.',
        'This relink does not change product source, case input, seed, existing case object, native/provider/report or new arena object. No TU or archive rebuild.']))
b.save(C/'plan.json', dict(status='CUDA3_RELINK_ONLY_PLANNED', cli_ready=b.pin(W/'ready.json'),
    reused_case_ready=b.pin(W/'cuda2/ready.json'), source=case['source'], source_freeze=case['source_freeze'],
    actual_dependencies=case['actual_dependencies'], baseline_link=b.pin(W/'link/command.json'),
    command=command, before_inputs=b.pin(C/'link-inputs-before.json'),
    removed_entry=entry, removed_model=model, reused_object=case['object'],
    correction=b.pin(C/'closure-correction.json')))
h = b.helper(); compiler = b.read(W/'cuda2/compile/command.json')['command'][0]
env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
    'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
linked = h.execute(command, env, C/'link', timeout=120)
for row in final: b.exact(row)
b.save(C/'link-inputs.json', final)
runtime = b.read(cli['runtime']['path']); b.exact(runtime['native'])
alias = C/'link'/Path(runtime['native']['path']).name
os.link(runtime['native']['path'], alias); runtime['native_hardlink'] = b.pin(alias)
b.save(C/'runtime.json', runtime)
b.save(C/'ready.json', dict(status='CUDA3_RELINKED_NOT_RUN', image=b.pin(C/'link/host-image-consumer.exe'),
    runtime=b.pin(C/'runtime.json'), source=case['source'], source_freeze=case['source_freeze'],
    actual_dependencies=case['actual_dependencies'], object=case['object'],
    plan=b.pin(C/'plan.json'), correction=b.pin(C/'closure-correction.json'), link=linked,
    link_inputs=b.pin(C/'link-inputs.json'), compiled_TUs=0, reused_case_TUs=1,
    unchanged_inputs=220, consumer_runs=0,
    scope='Only link existing CUDA2 case object into the exact CUDA CLI closure without its two entry/Model objects; no product change or compilation.'))
print('CUDA3_RELINK_READY', json.dumps(b.pin(C/'ready.json')), flush=True)
