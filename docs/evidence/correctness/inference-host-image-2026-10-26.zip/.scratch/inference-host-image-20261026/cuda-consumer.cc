#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_host_image_case.h"
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("usage: host-image-consumer INPUTS");return qwen_host_image_case::run(argv[1],hyle::inference::BackendKind::kCuda);}catch(const std::exception&e){std::cerr<<"host_image_consumer_failure="<<e.what()<<"\n";return 1;}}
