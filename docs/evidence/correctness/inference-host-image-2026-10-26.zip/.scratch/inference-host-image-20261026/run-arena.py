"""One explicitly authorized bounded page suite process; no retry or build."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('page_build_recipe', W/'arena.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
b = module.b
A = W/'arena'
ready = b.read(A/'ready.json')
for field in ('image', 'runtime', 'source_freeze'): b.exact(ready[field])
for row in b.read(ready['source_freeze']['path']): b.exact(row)
runtime = b.read(ready['runtime']['path'])
env = os.environ.copy()
env.update(runtime.get('configured_flags', {}))
env['PATH'] = str(Path(ready['image']['path']).parent)+';'+runtime['PATH']
env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
xml = A/'test-result.xml'
assert not xml.exists() and not (A/'run1').exists()
command = [*ready['run'], '--gtest_output=xml:'+str(xml)]
ran = b.helper().execute(command, env, A/'run1', timeout=60)
root = ET.parse(xml).getroot()
facts = {name:int(root.attrib.get(name, 0)) for name in ('tests', 'failures', 'disabled', 'errors')}
facts['skipped'] = sum(int(suite.attrib.get('skipped', 0)) for suite in root.findall('testsuite'))
for row in b.read(ready['source_freeze']['path']): b.exact(row)
passed = ran['exit'] == 0 and facts['tests'] >= 37 and all(facts[name] == 0 for name in ('failures', 'disabled', 'errors', 'skipped'))
b.save(A/'run-summary.json', dict(status='PASS' if passed else 'FAILED', process=ran,
    image=ready['image'], ready=b.pin(A/'ready.json'), runtime=ready['runtime'],
    result_xml=b.pin(xml), observed_counts=facts, source_freeze=ready['source_freeze'],
    process_count=1, model_runs=0,
    scope='Existing PagedArena and RowCachePaged suites plus frozen bulk-export coverage; no Model/HostImage quality or GPU physical-pending claim.'))
print(json.dumps(b.read(A/'run-summary.json')), flush=True)
assert passed, 'Preserve the actual first failure; no retry'
