"""Finite existing-manifest/role-byte inspection; no build, model or download."""
from pathlib import Path
import hashlib
import json
import math
import shlex
import struct

W = Path(__file__).resolve().parent
R = W.parents[1]
TINY = ('.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture/weights.tsv',
        '.scratch/mtp-state-ports-20261024/gdn-regression/gdn2/shared-fixture/weights.tsv')
ORIGINAL = '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'
ROLES = ('model.language_model.embed_tokens.weight',
    'model.language_model.layers.0.input_layernorm.weight',
    'model.language_model.layers.0.linear_attn.conv1d.weight',
    'model.language_model.layers.0.linear_attn.in_proj_qkv.weight',
    'model.language_model.layers.0.linear_attn.norm.weight',
    'mtp.fc.weight', 'mtp.pre_fc_norm_hidden.weight')


def pin(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def inspect(name):
    manifest = R/name
    lines = manifest.read_text(encoding='utf-8-sig').splitlines()
    assert lines[0] == 'HYLE_QWEN_ROLE_FILES_V2'
    roles, selected, physical = [], [], {}
    for line in lines[3:]:
        fields = shlex.split(line)
        if not fields or fields[0] in ('ct_mixed', 'kv_cache'): continue
        rank = int(fields[2]); path = Path(fields[3+rank]); offset, size = map(int, fields[4+rank:6+rank])
        assert path.is_file() and 0 <= offset <= path.stat().st_size-size
        roles.append(fields[0]); physical[str(path)] = dict(path=str(path), bytes=path.stat().st_size)
        if fields[0] not in ROLES: continue
        take = min(size, 16384)
        with path.open('rb') as stream: stream.seek(offset); data = stream.read(take)
        if fields[1] == 'BF16':
            values = list(struct.iter_unpack('<H', data))
            nonzero = sum(bool(value[0] & 0x7fff) for value in values)
            finite = all((value[0] & 0x7f80) != 0x7f80 for value in values)
        elif fields[1] == 'F32':
            values = list(struct.iter_unpack('<f', data))
            nonzero = sum(value[0] != 0 for value in values)
            finite = all(math.isfinite(value[0]) for value in values)
        else: raise AssertionError(fields[1])
        selected.append(dict(role=fields[0], dtype=fields[1], shape=list(map(int, fields[3:3+rank])),
            declared_bytes=size, inspected_bytes=len(data), complete_range=len(data)==size,
            inspected_nonzero_values=nonzero, inspected_all_finite=finite,
            inspected_sha256=hashlib.sha256(data).hexdigest()))
    return dict(manifest=pin(manifest), declared_identity=lines[1], geometry=lines[2],
        roles=len(roles), mtp_roles=sum(name.startswith('mtp.') for name in roles),
        physical_files=list(physical.values()), selected_role_bytes=selected)


result = dict(status='EXISTING_CACHED_FIXTURE_BYTES_ONLY_NO_EXECUTION', tiny_GA=[inspect(name) for name in TINY],
    original_Qwen35_2B=inspect(ORIGINAL),
    interpretation=['Both tiny manifests use raw HF names and default kHfRaw meaning. Recipe::meaning defaults kHfRaw; norm_absolute adds 1 for non-kRmsEffectiveGamma. Raw RMS norm zero therefore means effective scale one.',
        'GDN linear_attn.norm.weight is multiplied directly and is zero in both tiny fixtures; this can zero its mixed contribution, but does not establish zero upstream convolution history/recurrent state.',
        'Embedding and GDN convolution weights are nonzero. The future actual byte-roundtrip case must assert nonzero history/recurrent/hidden per role before claiming nonzero state coverage.',
        'These are untrained finite resource/lifetime fixtures, not model-quality oracles. No activation/state output was computed by this inspection.'],
    suggested_fixture=str((R/TINY[0]).parent),
    source_facts=['engine/models/qwen35/main.cc Recipe::meaning and norm_absolute; GDN direct norm multiplication',
        'engine/models/qwen35/prepared_roles.h Role::meaning defaults kHfRaw'],
    limits=['Only named existing small manifests and bounded role ranges read; each role sample is at most16384 bytes.',
        'The original 4.5GB checkpoint is not rehashed, copied or downloaded; all manifest role ranges are checked against existing file sizes.',
        'No build, model, provider or native consumer run, no new fixture generation.'])
(W/'fixture-inventory.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf8')
print(json.dumps(dict(receipt=pin(W/'fixture-inventory.json'), tiny_GA=len(result['tiny_GA']),
    original_roles=result['original_Qwen35_2B']['roles'], suggested_fixture=result['suggested_fixture'])))
