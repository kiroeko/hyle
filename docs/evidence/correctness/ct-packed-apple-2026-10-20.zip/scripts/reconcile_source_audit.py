from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent;O=R/'results'
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
row=json.loads((O/'tests--graph_route_apple--ct_packed_linear_test.cc-identity.json').read_text())
assert row['exit']==0 and not row['source_drifts']
verified=[]
for item in row['foreign_project_includes']:
 relative='include/hyle/'+item['path'].split('/include/hyle/',1)[1]
 canonical=identity(R/relative)
 assert canonical['sha256']==item['sha256'],(item,canonical)
 verified.append(dict(actual=item,canonical=canonical,byte_equal=True))
assert len(verified)==2
(O/'first-foreign-source-audit-failure.json').write_text(json.dumps(dict(reason='missing two projected headers caused strict location audit to reject; compiler exited0; actual cached dependency bytes exactly match current canonical Windows sources',original_record=row,comparisons=verified),indent=2)+'\n')
row['foreign_project_includes_byte_equivalent']=verified
# The original actual paths and hashes remain recorded. No object or headers
# are rebuilt or relabeled as having been compiled from the new projection.
row['foreign_project_includes']=[]
(O/'compile-summary.json').write_text(json.dumps(dict(compiles=[row],passed=True,metadata_only_correction=True,extra_compilations=0,actual_cached_dependencies=verified),indent=2)+'\n')
print('METADATA_RECONCILED',len(verified),'exact bytes; 0 extra compiles')
