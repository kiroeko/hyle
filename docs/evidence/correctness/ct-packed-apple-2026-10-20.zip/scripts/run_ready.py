from pathlib import Path
import hashlib,json,subprocess,time,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent;O=R/'run-ready';O.mkdir(exist_ok=True)
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
source=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib')
link=R/'mlx.metallib'
if not link.exists():link.symlink_to(source.resolve())
save('metallib.json',dict(link=str(link),target=identity(link.resolve()),source=str(source),copied=False,compiled=False))
image=R/'cpu-ct-tests';command=[str(image),'--gtest_filter=AppleCtPackedLinear.*','--gtest_output=xml:'+str(O/'tests.xml')]
record=dict(argv=command,started=time.time());p=subprocess.run(command,cwd=R,capture_output=True,text=True)
(O/'run.stdout.log').write_text(p.stdout);(O/'run.stderr.log').write_text(p.stderr)
record.update(exit=p.returncode,seconds=time.time()-record['started']);save('run.json',record)
cases=E.parse(O/'tests.xml').findall('.//testcase')
save('validation.json',dict(image=identity(image),exit=p.returncode,tests=len(cases),failed=[x.attrib for x in cases if x.findall('failure')],skipped=[x.attrib for x in cases if x.findall('skipped')],names=[x.get('classname')+'.'+x.get('name')for x in cases]))
print(p.stdout);print(p.stderr);raise SystemExit(p.returncode)
