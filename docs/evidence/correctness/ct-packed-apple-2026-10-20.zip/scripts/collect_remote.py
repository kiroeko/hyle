from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent;zip_path=R/'validation-records.zip'
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
selected=[]
for p in R.rglob('*'):
 if not p.is_file()or p==zip_path or p.is_symlink():continue
 rel=p.relative_to(R);s=rel.as_posix()
 if p.suffix in ['.json','.log','.xml','.py','.d'] and (
     any(x in rel.parts for x in ['results','run-ready'])or p.name in ['plan.json','source-manifest.json','build_remote.py','run_ready.py','reconcile_source_audit.py','benchmark_remote.py']or p.suffix=='.d'):
  selected.append(p)
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(selected):z.write(p,p.relative_to(R).as_posix())
 assert z.testzip()is None
print(json.dumps(dict(archive=ident(zip_path),members=len(selected))))
