from pathlib import Path,PurePosixPath
import hashlib,json,zipfile
P=Path.cwd();A=P/'.scratch/architecture-refactor-2026-10-18';S=A/'ct-packed-cross-platform/apple-gpu'
D=P/'docs/evidence/correctness';D.mkdir(parents=True,exist_ok=True)
stem='ct-packed-apple-2026-10-20';Z=D/(stem+'.zip');J=D/(stem+'.json')
payload={}
def add(name,path):
 name=PurePosixPath(name).as_posix();p=PurePosixPath(name)
 assert not p.is_absolute()and '..'not in p.parts and '\\'not in name and ':'not in name,name
 assert name not in payload,name
 assert Path(name).suffix.lower()not in ['.o','.obj','.exe','.a','.lib','.dylib','.map','.metallib','.zip'],name
 payload[name]=Path(path).read_bytes()
for p in sorted((S/'source').rglob('*')):
 if p.is_file():add('source/'+p.relative_to(S/'source').as_posix(),p)
for p in sorted((S/'before').rglob('*')):
 if p.is_file():add('before/'+p.relative_to(S/'before').as_posix(),p)
for p in sorted((S/'remote').rglob('*')):
 if p.is_file():add('validation/'+p.relative_to(S/'remote').as_posix(),p)
for p in sorted(S.glob('*.py')):add('scripts/'+p.name,p)
for name in ['before.json','final-source-freeze.json','final-validation.json']:
 add('records/'+name,S/name)
add('records/implementation.diff',S/'implementation.diff')
initial=S/'revisions/attempt1/source'
for name in ['src/compute_route_apple/apple_ct_packed.cc','src/compute_route_apple/apple_ct_packed.h',
 'src/graph_route_apple/native_region.cc','src/graph_route_apple/native_region.h','src/graph_route_apple/apple_lowering.cc',
 'tests/graph_route_apple/ct_packed_linear_test.cc']:
 add('revisions/initial/'+name,initial/name)
add('revisions/constant-borrow-fix/tests/graph_route_apple/ct_packed_linear_test.cc',
 S/'revisions/attempt2/source/tests/graph_route_apple/ct_packed_linear_test.cc')
for name in ['src/compute_route_apple/apple_ct_packed.cc','tests/graph_route_apple/ct_packed_linear_test.cc']:
 add('revisions/before-bf16-pointwise/'+name,S/'revisions/pre-bf16-pointwise'/name)
with zipfile.ZipFile(S/'bf16-pointwise/source-bundle.zip')as z:
 name='revisions/before-plain-guard/src/compute_route_apple/apple_ct_packed.cc'
 payload[name]=z.read('src/compute_route_apple/apple_ct_packed.cc')
for p in sorted((A/'ct-packed-shader-math').iterdir()):
 if p.is_file()and p.suffix in ['.cc','.py','.json','.log']:
  add('shared-numeric-host/'+p.name,p)
files=[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(payload.items())]
manifest=dict(scope='Focused actual Apple native CT packed correctness and two separate paired performance windows; no SDK, weights or images',files=files)
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED)as z:
 for name,data in sorted(payload.items()):z.writestr(name,data)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(Z)as z:
 assert z.testzip()is None
 names=z.namelist();assert len(names)==len(set(names));assert len(names)==len(files)+1
 actual=json.loads(z.read('manifest.json'))['files'];assert actual==files
 for row in files:
  data=z.read(row['path']);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
result=json.loads((S/'final-validation.json').read_text())
validation=json.loads(payload['validation/after-artifact-closure/source-round-comparison/bf16-pointwise/plain-activation/results/validation.json'])
first=result['performance']['initial_window']['measurements']
second=result['performance']['final_window']['measurements']
record=dict(date='2026-10-20',status='implemented_focused_Apple_M4_passed_default_original_after_measured_regression',
 scope='Native MLX/Metal bounded packed CT symmetric/asymmetric INT4 Decode[/Cast]/Transpose/MatMul contraction, positive rank2 plain A, all positive M capability. Actual strides are used; no dense W array, second executor or hot hostwait was added.',
 contract='Original low-first codes along K and asymmetric zeros along N; source-scale product RNE, decode RNE, operand RNE, F32 dot and declared output RNE. Normal finite BF16 scale times integer[-15,15] uses Safe native F32 multiply with <=12 significant bits then the same three RNE boundaries. Other scales retain shared uint math. FTZ-sensitive/nonfinite native dot SIMDgroups are recomputed with the same reduction tree through shared uint IEEE helpers.',
 selection=dict(default_CT_preference=201,original_preference=200,ordinary_default='original route1 retained',bounded_capability='kept as a separate cold route4 candidate; directed tests select it through the actual source capability adapter',not_promised='RequirePrepared cannot distinguish these two Managed native routes; opaque private bounds/OOM do not guarantee automatic reselection.'),
 validation=dict(device='MacBook Air Mac16,12 / Apple M4; actual hardware/toolchain identity in validation/results/hardware.json',
  tests=4,failures=0,skipped=0,actual_submissions=21,names=validation['names'],
  source_round_profiles='same6profiles each forced CT and forced original route1, with exact one-hot independent scalar witnesses; one additional F32 NaN/Inf case for CT',
  lifetimes='two invocation slots and two actual updates, old GraphOutput blocking/reset and retained results after invocation teardown',
  escapes='published decoded value, extra data reader and control dependency use the original decomposition',
  constants='raw borrowed original packed banks and explicit caller-owned ready leases/resource retained for complete compiled-program lifetime; no fabricated generic Compute owner',
  final_summary='validation/after-artifact-closure/source-round-comparison/bf16-pointwise/plain-activation/results/validation.json',
  final_link='validation/after-artifact-closure/source-round-comparison/bf16-pointwise/plain-activation/results/link.json'),
 performance=dict(geometry='N512,K1024,g32,asymmetric BF16 A/scales/decode/operand; M1 andM128; same original packed constants and same public graph publishing onlyY',
  timing='2warmups per arm then4AB/BApairs; warm submit through original Completion.wait; prepare/bind/reset/oracle outside timer; independent oracle checks both arms',
  initial_window=first,final_optimized_window=second,pooled=False,
  conclusion='Both observed packed medians remain materially slower than original route1. The ordinary default therefore preserves original. The windows are independent and not pooled; no universal crossover or throughput claim.',
  summaries=['validation/after-artifact-closure/source-round-comparison/performance/results/summary.json','validation/after-artifact-closure/source-round-comparison/bf16-pointwise/performance/results/summary.json']),
 failures_and_corrections=[dict(x,path=x['path'].replace('remote/','validation/',1))
     for x in result['failures_retained']],counts=result['counts'],
 shared_numerical_host=dict(comparisons=1505524,mismatches=0,source='shared-numeric-host/check.cc',result='shared-numeric-host/run.stdout.log',boundary='Independent host strict arithmetic check only; not Metal execution or proof of the BF16 fast branch.'),
 limits=['No model payload, full artifact, quality or whole-model run.','Native MLX private/persistent/workspace allocation totals remain unknown. Known Graph workspace0 does not imply0 GPU memory.','Special GPU payload coverage is the fixed fixture, signed-zero scale payloads and F32 NaN/Inf, not an exhaustive subnormal/overflow corpus.','No other backend or all-model acceptance is inferred from this Apple evidence.'],
 evidence=dict(archive=Z.name,bytes=Z.stat().st_size,sha256=hashlib.sha256(Z.read_bytes()).hexdigest(),payload_files=len(files),archive_members=len(files)+1,CRC_verified=True,all_payload_SHA256_verified=True,manifest='manifest.json',files=files))
J.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
# Independently verify that the public JSON identities describe the archive.
public=json.loads(J.read_text());assert public['evidence']['files']==files
with zipfile.ZipFile(Z)as z:
 for row in public['evidence']['files']:
  assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
print(json.dumps(dict(json=dict(path=str(J.relative_to(P)),bytes=J.stat().st_size,sha256=hashlib.sha256(J.read_bytes()).hexdigest()),zip=public['evidence']|dict(files='omitted from stdout'))))
