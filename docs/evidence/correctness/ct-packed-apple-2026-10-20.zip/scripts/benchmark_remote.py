from pathlib import Path
import hashlib,json,shlex,subprocess,time,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent;P=R.parent;O=R/'results';O.mkdir(exist_ok=True)
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def execute(tag,cmd):
 record=dict(argv=cmd,started=time.time());save(tag+'.command.json',record)
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/(tag+'.stdout.log')).write_text(p.stdout);(O/(tag+'.stderr.log')).write_text(p.stderr)
 record.update(exit=p.returncode,seconds=time.time()-record['started']);save(tag+'.result.json',record);print(tag,p.returncode,record['seconds'],flush=True);return p
row=json.loads((P/'results/tests--graph_route_apple--ct_packed_linear_test.cc-identity.json').read_text());cmd=row['argv'].copy()
cmd[cmd.index('-c')+1]=str(R/'benchmark.cc');cmd[cmd.index('-o')+1]=str(R/'benchmark.o');cmd[cmd.index('-MF')+1]=str(R/'benchmark.d')
p=execute('compile',cmd)
if p.returncode:raise SystemExit(p.returncode)
deps=[ident(p)for p in dict.fromkeys(shlex.split((R/'benchmark.d').read_text().split(': ',1)[1].replace('\\\n',' ')))]
save('compile-identity.json',dict(source=ident(R/'benchmark.cc'),object=ident(R/'benchmark.o'),dependencies=deps,recipe='new same-target scratch benchmark CXX from actual current Apple CT test recipe'))
cmd=json.loads((P/'results/link.json').read_text())['argv'];old=str(P/'objects/tests--graph_route_apple--ct_packed_linear_test.cc.o');assert cmd.count(old)==1;cmd[cmd.index(old)]=str(R/'benchmark.o');cmd[cmd.index('-o')+1]=str(R/'benchmark');cmd=[('-Wl,-map,'+str(R/'benchmark.map'))if a.startswith('-Wl,-map,')else a for a in cmd]
save('link-inputs.json',[ident(a)for a in cmd if Path(a).is_file()and Path(a).suffix in ['.o','.a','.dylib']]);p=execute('link',cmd)
if p.returncode:raise SystemExit(p.returncode)
link=R/'mlx.metallib'
if not link.exists():link.symlink_to((P/'mlx.metallib').resolve())
p=execute('run',[str(R/'benchmark'),'--gtest_filter=AppleCtPackedBenchmark.*','--gtest_output=xml:'+str(O/'tests.xml')])
print(p.stdout);print(p.stderr)
cases=E.parse(O/'tests.xml').findall('.//testcase');measurements=[json.loads(s[len('CT_PAIRED '):])for s in p.stdout.splitlines()if s.startswith('CT_PAIRED ')]
save('summary.json',dict(image=ident(R/'benchmark'),exit=p.returncode,tests=len(cases),failures=sum(len(x.findall('failure'))for x in cases),skipped=sum(len(x.findall('skipped'))for x in cases),measurements=measurements,boundary='warm submit through original Completion.wait; prepare/bind/reset and oracle outside timer; same public graph only finalY published; same original packed constant bytes retained in caller; 2warmups then4AB/BApairs; managed private allocations remain unknown'))
raise SystemExit(p.returncode)
