from pathlib import Path
import hashlib,json,re,shutil,zipfile
P=Path.cwd(); A=P/'.scratch/architecture-refactor-2026-10-18'; S=A/'ct-packed-cross-platform/apple-gpu'
S.mkdir(exist_ok=True); source=S/'source'; source.mkdir(exist_ok=True)
R='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/ct-packed-apple-20261020'
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(A/'ct-packed-cross-platform/apple-cpu/final-source.zip')as z:
 for n in z.namelist():
  p=P/n
  if p.is_file():
   q=source/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
owners=['src/compute_route_apple/apple_ct_packed.cc','src/compute_route_apple/apple_mature_float.cc',
 'src/graph_route_apple/native_region.cc','src/graph_route_apple/apple_lowering.cc',
 'tests/graph_route_apple/ct_packed_linear_test.cc']
queue=owners+['src/graph_route_apple/native_region.h','src/compute_route_apple/CMakeLists.txt','tests/graph_route_apple/CMakeLists.txt']
seen=set()
while queue:
 n=queue.pop()
 if n in seen:continue
 seen.add(n);p=P/n;q=source/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 if p.suffix not in ['.cc','.h','.hpp']:continue
 for inc in re.findall(r'^\s*#\s*include\s+"([^"]+)"',p.read_text(encoding='utf8'),re.M):
  candidates=[p.parent/inc,P/'include'/inc,P/inc]
  found=next((x.resolve()for x in candidates if x.is_file()),None)
  if found and found.is_relative_to(P):queue.append(found.relative_to(P).as_posix())
manifest=[dict(ident(p),path=p.relative_to(source).as_posix())for p in sorted(source.rglob('*'))if p.is_file()]
save(S/'source-manifest.json',manifest)
save(S/'source-freeze.json',dict(owners=owners,files=manifest,root_owned_graph_frozen=True,compiled=False))
old=json.loads((A/'batch-query-extent/delegated/apple/results/summary.json').read_text())['compiles']
link=json.loads((A/'ct-packed-cross-platform/apple-cpu/final-run/remote/after-cold-pattern/results/link.json').read_text())['argv']
inputs=json.loads((A/'ct-packed-cross-platform/apple-cpu/final-run/remote/after-cold-pattern/results/link-inputs.json').read_text())
recipes=[]
nv=json.loads((A/'nvfp4-reference-linear/apple/v2/remote/results/src--compute_route_apple--apple_nvfp4.cc-identity.json').read_text())
test=json.loads((A/'nvfp4-reference-linear/apple/v1/remote/results/tests--graph_route_apple--nvfp4_reference_test.cc-identity.json').read_text())
for n in owners:
 if n.endswith('apple_ct_packed.cc'):row=nv;oldobj=None;fresh=True
 elif n.startswith('tests/'):row=test;oldobj=None;fresh=True
 else:
  row=next(x for x in old if x['source']==n)
  key=Path(n).stem
  candidates=[x for x in link if x.endswith('.o')and key in Path(x).name]
  assert len(candidates)==1,(n,candidates)
  oldobj=candidates[0];fresh=False
 recipes.append(dict(source=n,recipe=row['argv'],old_object=oldobj,
  recipe_source='existing Apple nvfp4 peer CXX recipe'if fresh else 'actual batch-query-extent same owner CXX recipe',new_test_recipe=n.startswith('tests/')))
plan=dict(remote=R,link=link,inputs=inputs,compile=recipes,run_filter='AppleCtPackedLinear.*',expected_test_count=4)
save(S/'plan.json',plan)
shutil.copyfile(A/'ct-packed-cross-platform/apple-cpu/build_remote.py',S/'build_remote.py')
with zipfile.ZipFile(S/'source-bundle.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(source.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(source).as_posix())
print(json.dumps(dict(remote=R,source_files=len(manifest),source_bytes=sum(x['bytes']for x in manifest),bundle=ident(S/'source-bundle.zip'),freeze=ident(S/'source-freeze.json'))))
