from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
A=S.parent
R=A.parents[1]
(S/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('ct_math_helpers', A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
headers=[R/'src/compute_shader_shared/nvfp4_f32.h',R/'src/compute_shader_shared/ct_packed.h']
source='''#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <immintrin.h>
using uint=std::uint32_t;
uint hyle_clz(uint x){return std::countl_zero(x);}
uint hyle_mul_hi(uint a,uint b){return uint((std::uint64_t(a)*b)>>32);}
'''
for path in headers:
    source+=path.read_text(encoding='utf-8').split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0]
source+='''
double decode(uint bits,uint type) {
  if(type==0) return std::bit_cast<float>(bits);
  if(type==2) return std::bit_cast<float>(bits<<16);
  unsigned exponent=(bits>>10)&31u,fraction=bits&1023u;
  double sign=(bits&0x8000u)?-1.:1.;
  if(exponent==31) return fraction?std::numeric_limits<double>::quiet_NaN():sign*std::numeric_limits<double>::infinity();
  return sign*(exponent==0?std::ldexp(double(fraction),-24):std::ldexp(1.+double(fraction)/1024.,int(exponent)-15));
}
uint encode(double value,uint type) {
  if(type==0) return std::bit_cast<uint>(float(value));
  uint sign=std::signbit(value)?0x8000u:0u;
  uint infinity=type==1?0x7c00u:0x7f80u,maximum=infinity-1;
  if(std::isnan(value)) return infinity|uint(type==1?0x200u:0x40u);
  double magnitude=std::abs(value),maxvalue=decode(maximum,type);
  double step=maxvalue-decode(maximum-1,type);
  if(magnitude>=maxvalue+step*.5) return sign|infinity;
  uint low=0,high=maximum;
  while(low<high){uint mid=(low+high+1)/2;if(decode(mid,type)<=magnitude)low=mid;else high=mid-1;}
  if(low!=maximum){double below=magnitude-decode(low,type),above=decode(low+1,type)-magnitude;
    if(above<below||(above==below&&(low&1u)))++low;}
  return sign|low;
}
float rounded(float v,uint type){return float(decode(encode(v,type),type));}
std::uint64_t comparisons=0,mismatches=0;
void compare(uint actual,uint expected,const char* tag) {
  ++comparisons;
  const bool an=(actual&0x7fffffffu)>0x7f800000u,en=(expected&0x7fffffffu)>0x7f800000u;
  if(actual!=expected&&!(an&&en)) {if(mismatches++<8)std::printf("%s %08x != %08x\\n",tag,actual,expected);}
}
void narrow(float value,uint type) {
  uint got=hyle_ct_widen(hyle_ct_narrow(std::bit_cast<uint>(value),type),type);
  compare(got,std::bit_cast<uint>(rounded(value,type)),"narrow");
}
int main() {
  _mm_setcsr(_mm_getcsr()&~0xe040u);
  for(uint type=1;type<=2;++type) {
    for(uint code=0;code<65536;++code) {
      compare(hyle_ct_widen(code,type),std::bit_cast<uint>(float(decode(code,type))),"widen");
      narrow(float(decode(code,type)),type);
    }
    uint maximum=type==1?0x7bffu:0x7f7fu;
    for(uint code=0;code<maximum;++code) {
      float mid=float((decode(code,type)+decode(code+1,type))*.5);
      for(float value : {std::nextafter(mid,-std::numeric_limits<float>::infinity()),mid,
                         std::nextafter(mid,std::numeric_limits<float>::infinity())}) {
        narrow(value,type);narrow(-value,type);
      }
    }
  }
  uint random=0x7381ab49u;
  for(unsigned sample=0;sample<1024;++sample) {
    random^=random<<13;random^=random>>17;random^=random<<5;
    for(uint scale=0;scale<3;++scale) {
      float sf=rounded(std::bit_cast<float>(random),scale);
      for(int center=-15;center<=15;++center) {
        volatile float product=float(center)*sf;
        for(uint decoded=0;decoded<3;++decoded)for(uint operand=0;operand<3;++operand) {
          float expected=rounded(rounded(rounded(product,scale),decoded),operand);
          uint actual=hyle_ct_product(std::bit_cast<uint>(float(center)),std::bit_cast<uint>(sf),scale,decoded,operand);
          compare(actual,std::bit_cast<uint>(expected),"product");
        }
      }
    }
  }
  std::printf("{\\"comparisons\\":%llu,\\"mismatches\\":%llu}\\n",comparisons,mismatches);
  return mismatches?1:0;
}
'''
# No shader edits: compile the exact raw bodies in a strict host dialect shim.
source=source.replace('#include <bit>','#include <initializer_list>\n#include <bit>',1)
path=S/'check.cc';path.write_text(source,encoding='utf-8',newline='\n')
old=c.read(A/'nvfp4-shader-math/compile.command.json')['command']
cmd=[old[0],'/nologo','/EHsc','/std:c++20','/O2','/MD','/W4','/WX','/fp:strict','/c',str(path),'/Fo'+str(S/'check.obj')]
base=c.read(A/'ct-packed-pattern-shared/cpu/link-plan.json')
env,runtime=b.environment(base['command'],[x['path']for x in base['inputs']],S)
c.execute('compile',cmd,env,S)
c.execute('link',[old[0],'/nologo',str(S/'check.obj'),'/Fe:'+str(S/'check.exe')],env,S)
c.execute('run',[str(S/'check.exe')],env,S)
c.save(S/'identity.json',dict(headers=[b.identity(p)for p in headers],source=b.identity(path),object=b.identity(S/'check.obj'),image=b.identity(S/'check.exe')))
print('CT_SHARED_SHADER_HOST_ORACLE_PASSED')
