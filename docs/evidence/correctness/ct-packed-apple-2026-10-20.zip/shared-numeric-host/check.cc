#include <initializer_list>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <immintrin.h>
using uint=std::uint32_t;
uint hyle_clz(uint x){return std::countl_zero(x);}
uint hyle_mul_hi(uint a,uint b){return uint((std::uint64_t(a)*b)>>32);}

uint hyle_shift_jam(uint value, uint distance) {
  if (distance == 0u) return value;
  if (distance >= 32u) return uint(value != 0u);
  return (value >> distance) | uint((value << (32u-distance)) != 0u);
}

uint hyle_f32_pack(uint sign, int exponent, uint significand) {
  if (significand == 0u) return sign;
  if (significand >= 0x08000000u) {
    significand = hyle_shift_jam(significand,1u);
    ++exponent;
  }
  while (significand < 0x04000000u && exponent > 1) {
    significand <<= 1u;
    --exponent;
  }
  if (exponent < 1) {
    significand = hyle_shift_jam(significand,uint(1-exponent));
    exponent = 1;
  }
  uint tail = significand & 7u;
  uint rounded = (significand >> 3u) +
      uint(tail > 4u || (tail == 4u && (significand & 8u) != 0u));
  if (rounded >= 0x01000000u) {
    rounded >>= 1u;
    ++exponent;
  }
  if (exponent >= 255) return sign | 0x7f800000u;
  uint field = exponent == 1 && rounded < 0x00800000u ? 0u : uint(exponent);
  return sign | (field << 23u) | (rounded & 0x007fffffu);
}

struct HyleF32Parts { uint significand; int exponent; };
HyleF32Parts hyle_f32_parts(uint bits) {
  HyleF32Parts value;
  value.significand = bits & 0x007fffffu;
  value.exponent = int((bits >> 23u) & 255u);
  if (value.exponent != 0) value.significand |= 0x00800000u;
  else {
    uint shift = hyle_clz(value.significand)-8u;
    value.significand <<= shift;
    value.exponent = 1-int(shift);
  }
  return value;
}

uint hyle_f32_nan(uint a, uint b) {
  if ((a & 0x7fffffffu) > 0x7f800000u) return a | 0x00400000u;
  if ((b & 0x7fffffffu) > 0x7f800000u) return b | 0x00400000u;
  return 0x7fc00000u;
}

uint hyle_f32_mul(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u || aa == 0u || bb == 0u)
      return hyle_f32_nan(a,b);
    return sign | 0x7f800000u;
  }
  if (aa == 0u || bb == 0u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  uint low = left.significand * right.significand;
  uint high = hyle_mul_hi(left.significand,right.significand);
  uint extended = (high << 12u) | (low >> 20u) | uint((low & 0x000fffffu) != 0u);
  return hyle_f32_pack(sign,left.exponent+right.exponent-127,extended);
}

uint hyle_f32_div(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa > 0x7f800000u || bb > 0x7f800000u ||
      (aa == 0x7f800000u && bb == 0x7f800000u) || (aa == 0u && bb == 0u))
    return hyle_f32_nan(a,b);
  if (aa == 0x7f800000u || bb == 0u) return sign | 0x7f800000u;
  if (aa == 0u || bb == 0x7f800000u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  int exponent = left.exponent-right.exponent+127;
  uint remainder = left.significand, quotient = 0u;
  if (remainder < right.significand) {
    remainder <<= 1u;
    --exponent;
  }
  for (uint bit = 0u; bit < 27u; ++bit) {
    uint next = uint(remainder >= right.significand);
    if (next != 0u) remainder -= right.significand;
    quotient = (quotient << 1u) | next;
    if (bit != 26u) remainder <<= 1u;
  }
  quotient |= uint(remainder != 0u);
  return hyle_f32_pack(sign,exponent,quotient);
}

uint hyle_f32_add(uint a, uint b) {
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u ||
        (aa == 0x7f800000u && bb == 0x7f800000u && ((a ^ b) & 0x80000000u) != 0u))
      return hyle_f32_nan(a,b);
    return aa == 0x7f800000u ? a : b;
  }
  if (aa == 0u && bb == 0u) return (a & b) & 0x80000000u;
  if (aa == 0u) return b;
  if (bb == 0u) return a;
  // Larger magnitude first keeps subtraction nonnegative, including zeros.
  if (aa < bb) { uint temporary=a; a=b; b=temporary; }
  uint ea = (a >> 23u) & 255u, eb = (b >> 23u) & 255u;
  uint left = (a & 0x007fffffu) | (ea == 0u ? 0u : 0x00800000u);
  uint right = (b & 0x007fffffu) | (eb == 0u ? 0u : 0x00800000u);
  ea = ea == 0u ? 1u : ea;
  eb = eb == 0u ? 1u : eb;
  left <<= 3u;
  right = hyle_shift_jam(right << 3u,ea-eb);
  uint result = ((a ^ b) & 0x80000000u) == 0u ? left+right : left-right;
  // Exact cancellation under round-to-nearest produces positive zero.
  if (result == 0u) return 0u;
  return hyle_f32_pack(a & 0x80000000u,int(ea),result);
}

uint hyle_ct_narrow(uint bits, uint type) {
  if (type == 0u) return bits;
  if (type == 2u) {
    if ((bits & 0x7fffffffu) > 0x7f800000u)
      return (bits >> 16u) | 0x40u;
    return (bits + 0x7fffu + ((bits >> 16u) & 1u)) >> 16u;
  }
  uint sign = (bits >> 16u) & 0x8000u;
  uint exponent = (bits >> 23u) & 255u;
  uint fraction = bits & 0x7fffffu;
  if (exponent == 255u)
    return sign | 0x7c00u | (fraction != 0u ? (fraction >> 13u) | 0x200u : 0u);
  if (exponent > 142u) return sign | 0x7c00u;
  if (exponent >= 113u) {
    uint result = ((exponent - 112u) << 10u) | (fraction >> 13u);
    uint tail = fraction & 0x1fffu;
    return sign | (result + uint(tail > 0x1000u ||
        (tail == 0x1000u && (result & 1u) != 0u)));
  }
  if (exponent < 102u) return sign;
  uint shift = 126u - exponent;
  uint significand = fraction | 0x800000u;
  uint result = significand >> shift;
  uint tail = significand & ((1u << shift) - 1u), halfway = 1u << (shift - 1u);
  return sign | (result + uint(tail > halfway ||
      (tail == halfway && (result & 1u) != 0u)));
}

uint hyle_ct_widen(uint bits, uint type) {
  if (type == 0u) return bits;
  if (type == 2u) return bits << 16u;
  uint sign = (bits & 0x8000u) << 16u;
  uint exponent = (bits >> 10u) & 31u, fraction = bits & 0x3ffu;
  if (exponent == 31u) return sign | 0x7f800000u | (fraction << 13u);
  if (exponent != 0u) return sign | ((exponent + 112u) << 23u) | (fraction << 13u);
  if (fraction == 0u) return sign;
  uint top = 31u - hyle_clz(fraction);
  return sign | ((top + 103u) << 23u) | ((fraction << (23u - top)) & 0x7fffffu);
}

uint hyle_ct_round(uint bits, uint type) {
  return hyle_ct_widen(hyle_ct_narrow(bits, type), type);
}

uint hyle_ct_product(uint centered_bits, uint scale_bits, uint scale_type,
                     uint decode_type, uint operand_type) {
  uint source = hyle_ct_round(hyle_f32_mul(centered_bits, scale_bits), scale_type);
  return hyle_ct_round(hyle_ct_round(source, decode_type), operand_type);
}

double decode(uint bits,uint type) {
  if(type==0) return std::bit_cast<float>(bits);
  if(type==2) return std::bit_cast<float>(bits<<16);
  unsigned exponent=(bits>>10)&31u,fraction=bits&1023u;
  double sign=(bits&0x8000u)?-1.:1.;
  if(exponent==31) return fraction?std::numeric_limits<double>::quiet_NaN():sign*std::numeric_limits<double>::infinity();
  return sign*(exponent==0?std::ldexp(double(fraction),-24):std::ldexp(1.+double(fraction)/1024.,int(exponent)-15));
}
uint encode(double value,uint type) {
  if(type==0) return std::bit_cast<uint>(float(value));
  uint sign=std::signbit(value)?0x8000u:0u;
  uint infinity=type==1?0x7c00u:0x7f80u,maximum=infinity-1;
  if(std::isnan(value)) return infinity|uint(type==1?0x200u:0x40u);
  double magnitude=std::abs(value),maxvalue=decode(maximum,type);
  double step=maxvalue-decode(maximum-1,type);
  if(magnitude>=maxvalue+step*.5) return sign|infinity;
  uint low=0,high=maximum;
  while(low<high){uint mid=(low+high+1)/2;if(decode(mid,type)<=magnitude)low=mid;else high=mid-1;}
  if(low!=maximum){double below=magnitude-decode(low,type),above=decode(low+1,type)-magnitude;
    if(above<below||(above==below&&(low&1u)))++low;}
  return sign|low;
}
float rounded(float v,uint type){return float(decode(encode(v,type),type));}
std::uint64_t comparisons=0,mismatches=0;
void compare(uint actual,uint expected,const char* tag) {
  ++comparisons;
  const bool an=(actual&0x7fffffffu)>0x7f800000u,en=(expected&0x7fffffffu)>0x7f800000u;
  if(actual!=expected&&!(an&&en)) {if(mismatches++<8)std::printf("%s %08x != %08x\n",tag,actual,expected);}
}
void narrow(float value,uint type) {
  uint got=hyle_ct_widen(hyle_ct_narrow(std::bit_cast<uint>(value),type),type);
  compare(got,std::bit_cast<uint>(rounded(value,type)),"narrow");
}
int main() {
  _mm_setcsr(_mm_getcsr()&~0xe040u);
  for(uint type=1;type<=2;++type) {
    for(uint code=0;code<65536;++code) {
      compare(hyle_ct_widen(code,type),std::bit_cast<uint>(float(decode(code,type))),"widen");
      narrow(float(decode(code,type)),type);
    }
    uint maximum=type==1?0x7bffu:0x7f7fu;
    for(uint code=0;code<maximum;++code) {
      float mid=float((decode(code,type)+decode(code+1,type))*.5);
      for(float value : {std::nextafter(mid,-std::numeric_limits<float>::infinity()),mid,
                         std::nextafter(mid,std::numeric_limits<float>::infinity())}) {
        narrow(value,type);narrow(-value,type);
      }
    }
  }
  uint random=0x7381ab49u;
  for(unsigned sample=0;sample<1024;++sample) {
    random^=random<<13;random^=random>>17;random^=random<<5;
    for(uint scale=0;scale<3;++scale) {
      float sf=rounded(std::bit_cast<float>(random),scale);
      for(int center=-15;center<=15;++center) {
        volatile float product=float(center)*sf;
        for(uint decoded=0;decoded<3;++decoded)for(uint operand=0;operand<3;++operand) {
          float expected=rounded(rounded(rounded(product,scale),decoded),operand);
          uint actual=hyle_ct_product(std::bit_cast<uint>(float(center)),std::bit_cast<uint>(sf),scale,decoded,operand);
          compare(actual,std::bit_cast<uint>(expected),"product");
        }
      }
    }
  }
  std::printf("{\"comparisons\":%llu,\"mismatches\":%llu}\n",comparisons,mismatches);
  return mismatches?1:0;
}
