"""Finite CPU metadata checks. Run only after the thirteen pinned sources are integrated."""
from pathlib import Path
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
spec = importlib.util.spec_from_file_location('cached_finite', ROOT / '.scratch/inference-e4-append-implementation-20261025/check_finite.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
read, save, pin, execute = h.read, h.save, h.pin, h.execute
HOST_RECIPE = ROOT / '.scratch/inference-gguf-nvfp4-binding-20261025/metadata1/compile/command.json'


def verify_sources():
    for item in read(WORK/'product-pins.json')['files']:
        assert pin(ROOT/item['path'])['sha256'] == item['after']['sha256'], item['path']


def freeze(out, sources):
    tree = out/'source'
    search = [ROOT/'include', ROOT, ROOT/'engine', ROOT/'engine/models/qwen35', ROOT/'tests/tools']
    pending, seen, records = list(sources), set(), []
    while pending:
        rel = pending.pop()
        if rel in seen: continue
        seen.add(rel)
        path = ROOT/rel; raw = path.read_bytes(); target = tree/rel
        target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
        records.append(dict(relative=rel, canonical=pin(path), frozen=pin(target)))
        for inc in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]', raw.decode('utf-8-sig'), re.M):
            for folder in [path.parent, *search]:
                child = (folder/inc).resolve()
                if child.is_file():
                    if h.project(child): pending.append(child.relative_to(ROOT).as_posix())
                    break
    save(out/'frozen-source.json', records)
    return tree


def canonical(path):
    path = path.resolve()
    if path.is_relative_to(ROOT/'.scratch') and 'source' in path.parts:
        original = ROOT.joinpath(*path.parts[path.parts.index('source')+1:])
        if original == ROOT or h.project(original): return original
    return path


def flags(recipe, tree):
    result, skip = [], False
    for arg in recipe[1:]:
        if skip: skip = False; continue
        if arg.lower() == '/link': break
        if arg.lower() == '/sourcedependencies': skip = True; continue
        if arg.lower().startswith(('/fo','/fd','/fe')) or arg.lower().endswith(('.cc','.cpp')): continue
        parsed = h.include_path(arg)
        if not parsed and arg.startswith('-I'): parsed = ('-I', Path(arg[2:]))
        if parsed:
            directory = canonical(parsed[1])
            if directory == ROOT or h.project(directory): directory = tree/directory.relative_to(ROOT)
            arg = parsed[0]+str(directory)
        result.append(arg)
    result = ['/I'+str(tree/'include'), '/I'+str(tree), '/I'+str(tree/'engine/models/qwen35'), *result]
    assert '/W4' in result and '/WX' in result
    return result


def environment(compiler):
    return h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':compiler,
        'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env


def dependencies(folder):
    data = read(folder/'dependencies.json')['Data']
    paths = [Path(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]
    assert not any(h.project(p) for p in paths), 'Unfrozen canonical source dependency'
    save(folder/'actual-dependencies.json',[pin(p) for p in paths])


def main():
    verify_sources()
    name = sys.argv[1] if len(sys.argv)==2 else 'host1'
    assert re.fullmatch(r'host[0-9]+',name)
    out = WORK/name; assert not out.exists(), 'Preserve previous attempts'
    tree = freeze(out,['tests/tools/qwen_prepared_roles_test.cc','tests/tools/qwen_precision_profile_test.cc',
        'tests/tooling/qwen_hf_roles_test.py','engine/models/qwen35/prepare.py',
        'engine/models/qwen35/geometry.py','engine/models/qwen35/nf4_state.py',
        'tests/tooling/fixtures/qwen_nf4_quant_state.json'])
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    results = {}
    results['python'] = execute([sys.executable,'-I',str(tree/'tests/tooling/qwen_hf_roles_test.py')],env,out/'python',timeout=120)
    if results['python']['exit']: save(out/'summary.json',dict(status='PYTHON_FAILED',checks=results));return 1
    recipe = read(HOST_RECIPE)['command']; compiler = recipe[0]; env = environment(compiler)
    for label,source in [('roles','tests/tools/qwen_prepared_roles_test.cc'),('precision','tests/tools/qwen_precision_profile_test.cc')]:
        folder = out/label; image = folder/'check.exe'
        command = [compiler,*flags(recipe,tree),str(tree/source),'/sourceDependencies',str(folder/'dependencies.json'),
            '/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb'),'/Fe'+str(image),'/link','/INCREMENTAL:NO']
        compiled = execute(command,env,folder)
        results[label] = dict(compile_link=compiled)
        if compiled['exit']: save(out/'summary.json',dict(status='COMPILE_FAILED',checks=results));return 1
        dependencies(folder)
        args = [str(image)]
        if label=='roles': args.append(str(out/'role-fixtures'))
        results[label]['run'] = execute(args,env,out/(label+'-run'),timeout=120)
        if results[label]['run']['exit']:save(out/'summary.json',dict(status='HOST_FAILED',checks=results));return 1
    verify_sources()
    save(out/'summary.json',dict(status='PASS',checks=results,core_SDK_provider_rebuilds=0,
        native_or_model_processes=0,HTTP=0,scope='source policy/role inventory and precision; no original tensor values'))
    return 0


if __name__=='__main__': sys.exit(main())
