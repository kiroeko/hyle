"""One actual Recipe projection probe TU/process, using the retained CPU closure."""
from pathlib import Path
import os
import re
import sys
import check_host as c

WORK,ROOT = c.WORK,c.ROOT
COMPILE = ROOT/'.scratch/inference-duplicate-session-20261025/current1/compile/command.json'
LINK = ROOT/'.scratch/inference-duplicate-session-20261025/current1/link/command.json'
OLD_APP = ROOT/'.scratch/inference-duplicate-session-20261025/current1/compile/unit.obj'
NATIVE = ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
SOURCE = 'tests/tools/qwen_mtp_projection_width_probe.cc'


def main():
    c.verify_sources()
    name = sys.argv[1] if len(sys.argv)==2 else 'projection1'
    assert re.fullmatch(r'projection[0-9]+',name)
    out = WORK/name; assert not out.exists(), 'Preserve previous attempts'
    tree = c.freeze(out,[SOURCE])
    original = c.read(COMPILE)['command']; compiler = original[0]
    flags = c.flags(original,tree)
    assert any('HYLE_COMPUTE_CPU=1' in a for a in flags)
    assert not any('HYLE_COMPUTE_CUDA=1' in a for a in flags)
    env = c.environment(compiler); obj=out/'compile/unit.obj'; image=out/'link/projection.exe'
    compiled = c.execute([compiler,*flags,str(tree/SOURCE),'/sourceDependencies',str(out/'compile/dependencies.json'),
        '/Fo'+str(obj),'/Fd'+str(obj.with_suffix('.pdb'))],env,out/'compile')
    if compiled['exit']:c.save(out/'summary.json',dict(status='COMPILE_FAILED',compile=compiled));return 1
    c.dependencies(out/'compile')
    original = c.read(LINK)['command']
    assert sum(str(Path(a))==str(OLD_APP) for a in original)==1
    args = [str(obj) if str(Path(a))==str(OLD_APP) else a for a in original
        if not a.lower().startswith(('/out:','/pdb:','/map:','/implib:'))]
    # The app owns main; no new gtest driver/provider or SDK is linked.
    c.save(out/'link-inputs.json',[c.pin(Path(a)) for a in args[1:]
        if Path(a).is_absolute() and Path(a).suffix.lower() in {'.obj','.lib'}])
    linked=c.execute([*args,'/OUT:'+str(image),'/PDB:'+str(image.with_suffix('.pdb'))],env,out/'link')
    if linked['exit']:c.save(out/'summary.json',dict(status='LINK_FAILED',compile=compiled,link=linked));return 1
    assert c.pin(NATIVE)['sha256']=='1066e80261cc58d1c0ea57e50475e2e38b7675b666eb2b639969e01e85916a46'
    os.link(NATIVE,image.parent/NATIVE.name)
    runtime=c.read(NATIVE.parents[1]/'runtime-environment.json')
    runenv=dict(env,PATH=str(image.parent)+';'+runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    c.save(out/'runtime.json',dict(native=c.pin(NATIVE),PATH=runenv['PATH']))
    ran=c.execute([str(image),'--ct-block128'],runenv,out/'run',timeout=120)
    c.verify_sources()
    c.save(out/'summary.json',dict(status='PASS' if ran['exit']==0 else 'PROBE_FAILED',compile=compiled,
        link=linked,run=ran,core_SDK_provider_rebuilds=0,HTTP=0,
        scope='generated nonzero Recipe T1/T3 N129/K256; local BF16 resolver only; not complete Model/generation/original18 values'))
    return int(ran['exit']!=0)


if __name__=='__main__':sys.exit(main())
