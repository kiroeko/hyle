#if defined(HYLE_PENDING_RECEIVER_APPLE)
#include <hyle/compute/apple_batch.h>
#include <hyle/compute/apple_memory.h>
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
#include <hyle/graph/apple.h>
#endif
#else
#include <hyle/compute/vulkan_batch.h>
#include <hyle/compute/vulkan_memory.h>
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
#include <hyle/graph/vulkan.h>
#endif
#endif
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <vector>

namespace {
namespace c=hyle::compute;
#if defined(HYLE_PENDING_RECEIVER_APPLE)
namespace n=c::apple;
#else
namespace n=c::vulkan;
#endif
using hyle::Status;
using hyle::Result;
Status require(bool v,const char* message){return v?Status::Ok():Status::Internal(message);}
double decode(std::uint16_t x,bool bf=false){
  if(bf)return std::bit_cast<float>(std::uint32_t(x)<<16);
  const unsigned e=(x>>10)&31U,f=x&1023U;
  return (x&0x8000U?-1.:1.)*(e?std::ldexp(1.+double(f)/1024.,int(e)-15):std::ldexp(double(f),-24));
}
Status exercise(n::Context& context,n::MemoryResource& device,n::MemoryResource& staging,bool bf=false){
  constexpr unsigned depth=256,heads=8,kv_heads=2;
  constexpr std::size_t row_elements=kv_heads*depth,row_bytes=row_elements*2;
  const c::BatchCapacity cap{.data_type=bf?c::DataType::kBFloat16:c::DataType::kFloat16,
      .max_requests=2,.max_query_rows=18,.max_kv_rows=160,
      .max_pages=10,.max_page_refs=8,.query_heads=heads,.kv_heads=kv_heads,.head_dim=depth};
  HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(cap));
  HYLE_ASSIGN_OR_RETURN(auto recipe,c::NativePagedBatchProgram::prepare(schema,
      {.max_host_metadata_bytes=32,.scale=1.F/16.F,.causal=true}));
  HYLE_ASSIGN_OR_RETURN(auto keys,c::PagedArena::create(schema,device.ref(),{.max_backing_bytes=1<<20}));
  HYLE_ASSIGN_OR_RETURN(auto values,c::PagedArena::create(schema,device.ref(),{.max_backing_bytes=1<<20}));
  const auto page_bytes=keys.page_bytes();
  constexpr std::size_t query_bytes=18*heads*depth*2;
  const auto init_bytes=std::max(page_bytes,query_bytes);
  HYLE_ASSIGN_OR_RETURN(auto host_pool,c::LeasePool::create(staging.ref(),2*init_bytes+512,{.max_blocks=2}));
  const std::array specs{c::CopyResourceSpec{staging.ref(),init_bytes},c::CopyResourceSpec{device.ref(),init_bytes}};
  HYLE_ASSIGN_OR_RETURN(auto init_program,n::CopyBatchProgram::prepare(context,specs));
  HYLE_ASSIGN_OR_RETURN(auto initialize,n::CopyBatchInvocation::create(init_program));
  const std::array<c::CopyPhase,1> phases{{{}}};
  const auto fill=[&](c::WriteLease&& writer,std::span<const std::uint16_t> data)->Result<c::ReadLease>{
    HYLE_RETURN_IF_ERROR(initialize.reset());
    HYLE_ASSIGN_OR_RETURN(auto hw,host_pool.allocate(data.size_bytes(),64));
    HYLE_RETURN_IF_ERROR(hw.view()->write(std::as_bytes(data)));
    HYLE_ASSIGN_OR_RETURN(auto host,hw.publish());
    HYLE_RETURN_IF_ERROR(initialize.bind_source({0},host));
    HYLE_RETURN_IF_ERROR(initialize.bind_mutable({1},std::move(writer)));
    const std::array<c::CopyRange,1> ranges{{{{0},{1},{0},0,0,data.size_bytes()}}};
    HYLE_RETURN_IF_ERROR(initialize.prepare_replay(phases,ranges));
    HYLE_ASSIGN_OR_RETURN(auto submitted,initialize.submit());HYLE_RETURN_IF_ERROR(submitted.wait());
    return submitted.output({0},{1},0,data.size_bytes());
  };
  std::vector<std::uint16_t> zeros(page_bytes/2,0),q(18*heads*depth,bf?0x3e00:0x3000);
  std::array<c::ReadLease,10> kr,vr;
  for(unsigned p=0;p<10;++p){
    HYLE_ASSIGN_OR_RETURN(auto k,keys.acquire(p));HYLE_ASSIGN_OR_RETURN(kr[p],fill(std::move(k.lease()),zeros));HYLE_RETURN_IF_ERROR(k.complete(kr[p],p==0 || p==5?cap.page_size:0));
    HYLE_ASSIGN_OR_RETURN(auto v,values.acquire(p));HYLE_ASSIGN_OR_RETURN(vr[p],fill(std::move(v.lease()),zeros));HYLE_RETURN_IF_ERROR(v.complete(vr[p],p==0 || p==5?cap.page_size:0));
  }
  HYLE_ASSIGN_OR_RETURN(auto query_pool,c::LeasePool::create(device.ref(),q.size()*2+512));
  HYLE_ASSIGN_OR_RETURN(auto qw,query_pool.allocate(q.size()*2,64));
  HYLE_ASSIGN_OR_RETURN(auto query,fill(std::move(qw),q));HYLE_RETURN_IF_ERROR(initialize.reset());
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
  HYLE_ASSIGN_OR_RETURN(auto source_desc,c::TensorDesc::dense(cap.data_type,std::array<std::int64_t,1>{4*row_elements}));
  HYLE_ASSIGN_OR_RETURN(auto row_desc,c::TensorDesc::dense(cap.data_type,std::array<std::int64_t,1>{row_elements}));
  HYLE_ASSIGN_OR_RETURN(auto builder,hyle::graph::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto input,builder.input(source_desc));
  HYLE_ASSIGN_OR_RETURN(auto positive,builder.add(c::Unary{c::UnaryKind::kAbs},input));
  for(unsigned port=0;port<4;++port){
    HYLE_ASSIGN_OR_RETURN(auto slice,c::View::slice(0,port*row_elements,row_elements));
    HYLE_ASSIGN_OR_RETURN(auto output,builder.add(slice,positive));HYLE_RETURN_IF_ERROR(builder.publish(output));
  }
  HYLE_ASSIGN_OR_RETURN(auto producer_graph,std::move(builder).finish());
#if defined(HYLE_PENDING_RECEIVER_APPLE)
  HYLE_ASSIGN_OR_RETURN(auto producer_program,hyle::graph::apple::compile(context,producer_graph));
  HYLE_ASSIGN_OR_RETURN(auto native_input,device.allocate(source_desc));
#else
  const auto source_resource=staging.ref();
  HYLE_ASSIGN_OR_RETURN(auto producer_program,hyle::graph::vulkan::compile(context,producer_graph));
#endif
  std::array<n::Invocation,2> producers;
  for(auto&producer:producers){HYLE_ASSIGN_OR_RETURN(producer,producer_program.create_invocation());}
  const std::array update_specs{c::CopyResourceSpec{device.ref(),row_bytes},c::CopyResourceSpec{device.ref(),row_bytes},
      c::CopyResourceSpec{device.ref(),row_bytes},c::CopyResourceSpec{device.ref(),row_bytes},
      c::CopyResourceSpec{device.ref(),page_bytes},c::CopyResourceSpec{device.ref(),page_bytes},
      c::CopyResourceSpec{device.ref(),page_bytes},c::CopyResourceSpec{device.ref(),page_bytes}};
#else
  const std::array update_specs{c::CopyResourceSpec{source_resource,4*row_bytes},
      c::CopyResourceSpec{device.ref(),page_bytes},c::CopyResourceSpec{device.ref(),page_bytes},
      c::CopyResourceSpec{device.ref(),page_bytes},c::CopyResourceSpec{device.ref(),page_bytes}};
#endif
  HYLE_ASSIGN_OR_RETURN(auto update_program,n::CopyBatchProgram::prepare(context,update_specs));
  std::array<n::CopyBatchInvocation,2> copy_slots;
  std::array<n::PagedBatchReceiver,2> slots;
  for(unsigned i=0;i<2;++i){
    HYLE_ASSIGN_OR_RETURN(copy_slots[i],n::CopyBatchInvocation::create(update_program));
    HYLE_ASSIGN_OR_RETURN(auto native,n::PagedBatchInvocation::create(context,recipe,device,staging,{.max_metadata_backing_bytes=4096}));
    HYLE_ASSIGN_OR_RETURN(slots[i],n::PagedBatchReceiver::create(std::move(native),4));
  }
  const std::array<c::CopyPhase,2> pending_phases{{{}, {.dependency_mask=1}}};
  const std::array<std::int32_t,3> decode_qp{0,1,2},first_prefill{0,17,18},second_prefill{0,1,18};
  const std::array<std::uint16_t,4> kbits=bf?std::array<std::uint16_t,4>{0x3c80,0x3d00,0x3d40,0x3d80}:std::array<std::uint16_t,4>{0x2400,0x2800,0x2a00,0x2c00},
      vbits=bf?std::array<std::uint16_t,4>{0x3e00,0x3e80,0x3ec0,0x3f00}:std::array<std::uint16_t,4>{0x3000,0x3400,0x3600,0x3800};
  std::array<std::array<std::uint16_t,128>,2> expected_k{},expected_v{};
  std::uint64_t dirty_total=0;
  for(unsigned step=0;step<64;++step){
    const std::array<unsigned,2> lengths{step+17,step/2+17};
    std::vector<std::int32_t> pages;
    std::array<std::int32_t,3> kp{0,0,0};std::array<std::int32_t,2> tails{};
    for(unsigned request=0;request<2;++request){
      const unsigned refs=(lengths[request]+15)/16;
      for(unsigned p=0;p<refs;++p)pages.push_back(std::int32_t(request*5+p));
      kp[request+1]=std::int32_t(pages.size());tails[request]=std::int32_t((lengths[request]-1)%16+1);
    }
    HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({step%3==0?second_prefill:step%3==1?first_prefill:decode_qp,kp,pages,tails}));
    // Explicit cold preparation must retire/drop all previous native imports
    // before we reacquire a ready page for this episode's exact update.
    for(auto&receiver:slots)HYLE_RETURN_IF_ERROR(receiver.prepare_batch(layout));
    auto&slot=slots[step%2];auto&update=copy_slots[step%2];
    const unsigned updates=step%2==0?2:1;
    HYLE_RETURN_IF_ERROR(update.reset());
    std::vector<std::uint16_t> incoming(4*row_elements);
    std::array<c::PagedPageWriter,4> writers;
    std::array<std::uint64_t,4> generations{};
    std::array<unsigned,2> destinations{};
    std::vector<c::CopyRange> ranges;
    for(unsigned request=0;request<updates;++request){
      const unsigned row=lengths[request]-1,page=request*5+row/16;
      destinations[request]=page;
      expected_k[request][row]=kbits[(step+request)%4];expected_v[request][row]=vbits[(step+2*request)%4];
      std::fill_n(incoming.begin()+2*request*row_elements,row_elements,expected_k[request][row]);
      std::fill_n(incoming.begin()+(2*request+1)*row_elements,row_elements,expected_v[request][row]);
      generations[2*request]=kr[page].generation();generations[2*request+1]=vr[page].generation();
      HYLE_ASSIGN_OR_RETURN(writers[2*request],keys.acquire(kr[page]));
      HYLE_ASSIGN_OR_RETURN(writers[2*request+1],values.acquire(vr[page]));
      for(unsigned type=0;type<2;++type){const unsigned port=2*request+type+1;
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
        const unsigned source=port-1;
        HYLE_RETURN_IF_ERROR(update.bind_mutable({source+4},std::move(writers[port-1].lease())));
        ranges.push_back({{source},{source+4},{1},0,(row%16)*row_bytes,row_bytes});
#else
        HYLE_RETURN_IF_ERROR(update.bind_mutable({port},std::move(writers[port-1].lease())));
        ranges.push_back({{0},{port},{1},(port-1)*row_bytes,(row%16)*row_bytes,row_bytes});
#endif
      }
    }
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
    for(auto&value:incoming)if(value)value|=0x8000U; // Actual Abs must change every nonzero input.
#endif
    HYLE_ASSIGN_OR_RETURN(auto hw,host_pool.allocate(incoming.size()*2,64));
    HYLE_RETURN_IF_ERROR(hw.view()->write(std::as_bytes(std::span(incoming))));
    HYLE_ASSIGN_OR_RETURN(auto host,hw.publish());
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
    // Input preparation is explicit. From accepted native producer through
    // F2 and attention, only the final original aggregate is host-observed.
#if defined(HYLE_PENDING_RECEIVER_APPLE)
    HYLE_ASSIGN_OR_RETURN(auto source_tensor,host.tensor(source_desc));
    HYLE_RETURN_IF_ERROR(device.copy_from_host(native_input,source_tensor));
#else
    HYLE_ASSIGN_OR_RETURN(auto native_input,context.upload(source_desc,std::as_bytes(std::span(incoming))));
#endif
    const std::array producer_inputs{native_input};auto&producer=producers[step%2];
    HYLE_RETURN_IF_ERROR(producer.bind(producer_inputs));HYLE_ASSIGN_OR_RETURN(auto produced,producer.submit());
    const std::array<n::ResultCopyBinding,4> source_bindings{{{{0},0,row_desc},{{1},1,row_desc},{{2},2,row_desc},{{3},3,row_desc}}};
    HYLE_RETURN_IF_ERROR(update.bind_source(source_bindings,std::move(produced)));
    HYLE_RETURN_IF_ERROR(require(!produced.valid(),"native source did not retain original result"));
#else
    HYLE_RETURN_IF_ERROR(update.bind_source({0},host));
#endif
    HYLE_RETURN_IF_ERROR(update.prepare_replay(pending_phases,ranges));
    HYLE_ASSIGN_OR_RETURN(auto copied,update.submit());
    HYLE_ASSIGN_OR_RETURN(auto owner,n::CopyBatchUpdate::take(std::move(update),std::move(copied)));
    std::vector<c::ReadLease> key_reads,value_reads;
    std::vector<c::PagedPageUpdate> key_updates,value_updates;
    for(auto page:pages){
      bool pending=false;
      for(unsigned request=0;request<updates;++request)if(unsigned(page)==destinations[request]){
        constexpr unsigned destination_base=
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
          4;
#else
          1;
#endif
        key_updates.push_back({&writers[2*request],{2*request+destination_base}});
        value_updates.push_back({&writers[2*request+1],{2*request+destination_base+1}});pending=true;break;
      }
      if(!pending){key_reads.push_back(kr[page]);value_reads.push_back(vr[page]);}
    }
    HYLE_ASSIGN_OR_RETURN(auto kframe,keys.pending_read(layout,key_reads,key_updates));
    HYLE_ASSIGN_OR_RETURN(auto vframe,values.pending_read(layout,value_reads,value_updates));
    HYLE_ASSIGN_OR_RETURN(auto submitted,slot.submit(query,kframe,vframe,std::move(owner)));
    HYLE_RETURN_IF_ERROR(require(!owner.valid() && !slot.take_update(),"pending source was not retained by original suffix"));
    HYLE_RETURN_IF_ERROR(require(!slot.prepare_batch(layout).ok(),"retained aggregate allowed receiver prepare"));
    {HYLE_ASSIGN_OR_RETURN(auto free,keys.acquire(kr[9]));HYLE_ASSIGN_OR_RETURN(kr[9],free.publish(0));}
    {HYLE_ASSIGN_OR_RETURN(auto result,submitted.wait());
      const auto active=layout.facts().query_rows;
      std::vector<std::uint16_t> actual(active*heads*depth);
#if defined(HYLE_PENDING_RECEIVER_APPLE)
      HYLE_ASSIGN_OR_RETURN(auto output_desc,c::TensorDesc::dense(cap.data_type,std::array<std::int64_t,3>{active,heads,depth}));
      HYLE_ASSIGN_OR_RETURN(auto output,device.import_readonly(result->arrays()[0],output_desc));
      HYLE_RETURN_IF_ERROR(output.view()->read(std::as_writable_bytes(std::span(actual))));
#else
      HYLE_RETURN_IF_ERROR(context.download(result->tensors()[0],std::as_writable_bytes(std::span(actual))));
#endif
      const auto ptr=layout.host().query_indptr;
      for(unsigned request=0;request<2;++request){
        const auto nq=unsigned(ptr[request+1]-ptr[request]);
        for(unsigned query_row=0;query_row<nq;++query_row){double sum=0,weighted=0;
          const auto visible=lengths[request]-nq+query_row+1;
          for(unsigned row=0;row<visible;++row){
            const double weight=std::exp(.125*depth*decode(expected_k[request][row],bf)/16.);
            sum+=weight;weighted+=weight*decode(expected_v[request][row],bf);
          }
          const double expected=weighted/sum;
          for(unsigned i=0;i<heads*depth;++i){const auto actual_value=decode(actual[(ptr[request]+query_row)*heads*depth+i],bf);
            HYLE_RETURN_IF_ERROR(require(std::isfinite(actual_value) && std::abs(actual_value-expected)<(bf?.008:.002),"native dirty attention independent oracle differs"));
          }
        }
      }
      HYLE_RETURN_IF_ERROR(require(!slot.prepare_batch(layout).ok(),"retained native result permitted prepare/update"));
    }
    // The mapped completion is the public/native result path; source need not
    // be separately waited. Recovery uses the two original update controls.
    HYLE_RETURN_IF_ERROR(submitted.completion().wait());
    submitted={};
    HYLE_ASSIGN_OR_RETURN(owner,slot.take_update());
    HYLE_RETURN_IF_ERROR(require(owner.report().logical_bytes==2*updates*row_bytes,"pending update copied history"));
    dirty_total+=owner.report().logical_bytes;
    for(unsigned request=0;request<updates;++request){
      const auto page=destinations[request];
      constexpr unsigned destination_base=
#if defined(HYLE_PENDING_NATIVE_RESULT_SOURCE)
        4;
#else
        1;
#endif
      HYLE_ASSIGN_OR_RETURN(writers[2*request].lease(),owner.take_mutable({2*request+destination_base}));
      HYLE_ASSIGN_OR_RETURN(writers[2*request+1].lease(),owner.take_mutable({2*request+destination_base+1}));
      HYLE_ASSIGN_OR_RETURN(kr[page],writers[2*request].publish(std::uint32_t(tails[request])));
      HYLE_ASSIGN_OR_RETURN(vr[page],writers[2*request+1].publish(std::uint32_t(tails[request])));
      HYLE_RETURN_IF_ERROR(require(kr[page].generation()==generations[2*request] && vr[page].generation()==generations[2*request+1],"pending update changed original generation"));
    }
    HYLE_ASSIGN_OR_RETURN(update,owner.release_invocation());
  }
  for(auto&update:copy_slots)HYLE_RETURN_IF_ERROR(update.close());
  for(auto&slot:slots)HYLE_RETURN_IF_ERROR(slot.drain());
  std::fprintf(stderr,"native pending receiver PASS:64 steps GQA8/2 D256, two requests growth17..80/17..48, mixed Q1/17 prefill/decode, crosspage, exact frame, untouched history, same generation, BF16=%d dirty total=%llu bytes, original prepare releases imports; cold metadata waits retained, no source wait before attention\n",bf,static_cast<unsigned long long>(dirty_total));
  return Status::Ok();
}
Status run(){HYLE_ASSIGN_OR_RETURN(auto context,n::Context::create());
#if defined(HYLE_PENDING_RECEIVER_APPLE)
  HYLE_ASSIGN_OR_RETURN(auto device,n::MemoryResource::create(context));
  HYLE_ASSIGN_OR_RETURN(auto staging,n::MemoryResource::create(context));
#else
  HYLE_RETURN_IF_ERROR(require(!context.environment().software_device,"dirty page requires actual Vulkan GPU"));
  HYLE_ASSIGN_OR_RETURN(auto device,n::MemoryResource::create(context,n::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto staging,n::MemoryResource::create(context,n::MemoryKind::kStaging));
#endif
  struct Close{n::Context& context;~Close(){context.close().IgnoreError();}}close{context};
  HYLE_RETURN_IF_ERROR(exercise(context,device,staging));
#if defined(HYLE_PENDING_RECEIVER_APPLE)
  HYLE_RETURN_IF_ERROR(exercise(context,device,staging,true));
#endif
  return Status::Ok();
}
}
int main(){const auto status=run();if(!status.ok())std::fprintf(stderr,"native dirty page: %.*s\n",int(status.message().size()),status.message().data());return status.ok()?0:1;}
