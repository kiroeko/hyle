from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path.cwd();task=root/'.scratch/inference-gaps/g03'
out=root/'evidence/correctness/inference-g03-graph-late-risks';out.mkdir(exist_ok=True)
san=json.loads((task/'graph-late-sanitizers/result.json').read_bytes())
latest={(r['route'],r['mode'],r['stage']):r for r in san['stages']}
cases=['g03_gl_graph_risks','g03_gl_source_risks','g03_gl_joint_risks','g03_gl_graph64','g03_gl_source64','g03_gl_joint64']
for route in ['apple','vulkan']:
    for mode in ['asan','ubsan','tsan']:
        for stage in ['compile',*cases]:
            assert latest[route,mode,stage]['exit_code']==0,(route,mode,stage)
for item in san['inputs']:
    if item['path'].startswith(('src/','include/','tests/')):
        assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
windows=json.loads((task/'graph-late-windows/result.json').read_bytes())
wl={r['stage']:r for r in windows['stages']}
assert wl['new-risk-compile']['exit_code']==0 and wl['new-graph-risks']['exit_code']==0
source=json.loads((task/'graph-late-air/result.json').read_bytes())
sl={(r['route'],r['stage']):r for r in source['stages']}
for route in ['apple','vulkan']:
    for stage in ['new-risk-compile','g03_native_result_risks','g03_native_joint_risks','g02_native_page_joint']:
        assert sl[route,stage]['exit_code']==0,(route,stage)
names=subprocess.check_output(['git','diff','--name-only','2bc71f56a'],text=True).splitlines()
names=[n for n in names if n.startswith(('src/','include/','tests/'))]
for folder in ['graph-late-sanitizers','graph-late-air','graph-late-windows']:
    directory=task/folder
    with zipfile.ZipFile(out/(folder+'-raw.zip'),'w',zipfile.ZIP_DEFLATED) as package:
        for path in directory.iterdir():
            if path.suffix in ('.json','.log'):
                package.write(path,path.name)
        for archive in directory.glob('source-*.zip'):
            with zipfile.ZipFile(archive) as old:
                for name in names:
                    if name in old.namelist():
                        package.writestr(archive.stem+'/'+name,old.read(name))
    (out/(folder+'-result.json')).write_bytes((directory/'result.json').read_bytes())
with zipfile.ZipFile(out/'current-draft-inputs.zip','w',zipfile.ZIP_DEFLATED) as package:
    for name in names:package.write(root/name,name)
(out/'current-inputs.json').write_text(json.dumps([dict(path=n,sha256=hashlib.sha256((root/n).read_bytes()).hexdigest()) for n in names],indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'runners.zip','w',zipfile.ZIP_DEFLATED) as package:
    for name in ['graph_late_san_air.py','run_graph_late_san_air.py','graph_late_windows.py','graph_late_air.py','run_graph_late_air.py','seal_graph_late_risks.py']:
        package.write(task/name,name)
result=dict(kind='PARTIAL_GRAPH_LATE_RISK_AND_HOST_SANITIZER_CHECKPOINT',state='AUDITED',whole_g03_completed=False,
    baseline='19413efdd0427cd21f4431dfa7561291e9034bde',audit='2bc71f56a',immutable_candidate=False,
    verified=['Common CPU pending Graph nine real coverage/layout/capacity/closed/budget/allocation/abandon cases',
        'Apple/Vulkan native accepted multi-output result source twelve original F2 risks each; real readonly alias/invalid IDs/index/dtype/foreign/cancel/abandon/cold OOM/shared budget',
        'Actual CPU+Apple pending joint eight cases and CPU+Vulkan ten including unknown and accepted native suffix refusal; two native nodes share original Update',
        'Both actual Air native routes: six selected host programs each under ASan/UBSan/TSan, including original source and joint64-step double-oracle consumers',
        'Directly affected original ready joint source consumers pass on both native routes'],
    fixes=['GL04 original Apple Copy slot observations lock now serializes source completion qualification/poll/retention attachment; native blocking wait runs outside that lock',
        'Concurrent fault allocator counters fix fixture race during true abandoned joint Graph progress'],
    limits=['No LSan/shader/driver/private-pool sanitizer certificate; original qualified TSan refcount/fence and Metal callback models retained with SHA receipts',
        'Earlier ordinary source tests preceded GL04 synchronization repair; final behavior verified by six sanitizer configurations and Windows, not fabricated as newly repeated original source math',
        'Vulkan unknown uses original accepted source fence observation; Apple accepted producer failure uses existing native checkpoint',
        'Readonly native alias tested; full illegal mutable native alias and new native-joint shared-budget qualification not claimed'],
    failures=[dict(route=r['route'],mode=r['mode'],stage=r['stage'],exit_code=r['exit_code'],log=Path(r['log']).name) for r in san['stages'] if r['exit_code']],
    retained='All stage failures and cumulative costs retained, including original fixture invalid closed status, submit-vs-bind reuse distinction, failed epoch status, Vulkan actual unknown observation timing, fault allocator TSan and actual GL04 lifetime race; no budget reset.',
    cumulative_seconds=dict(sanitizers=san['cumulative_seconds'],windows=windows['cumulative_seconds'],source=source['cumulative_seconds']),
    remaining=['New common Graph GPU/CPU+CUDA lifecycle risk and real async queue refusal',
        'Full source/static/shared installed new public API consumers and standalone headers',
        'CPU+CUDA complete factor/archive qualification, not cached diagnostic substitution',
        'Finite G03 remaining gates and original G01/G02 unresolved gates; G04-G10 remain'])
(out/'validation-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result['cumulative_seconds']))
