from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('build',S/'build.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
m=a.m
headers={
 'GGUF':'.scratch/qwen-gguf-selected-20261023/S01/generated/qwen_gguf_original_artifacts.h',
 'B07':'.scratch/qwen-gguf-selected-20261023/B07/generated/qwen_gguf_b07_artifacts.h',
 'B04':'.scratch/qwen-gguf-selected-20261023/B04/generated/qwen_gguf_b04_artifacts.h',
 'Q14':'.scratch/qwen-gguf-selected-20261023/Q14/generated/qwen_gguf_q14_artifacts.h',
 **{x:f'.scratch/qwen-bfloat-selected-20261023/derived/{x}/generated/qwen_{x.lower()}_original_pins.h' for x in ('Q03','Q01','Q09','Q10')}
}
for path in headers.values():assert (R/path).is_file(),path
source=R/'tests/compute_models/qwen_mtp_state_consumer_test.cc'
before=m.ident(source); results=[]
for endpoint,recipe in [('cpu',S/'cpu-syntax4/command.json'),('cpu-cuda',S/'compile2/command.json')]:
 out=S/('wrappers-'+endpoint+'-syntax1');command=[];skip=False
 for flag in m.read(recipe)['command']:
  if skip:skip=False;continue
  if flag=='/sourceDependencies':skip=True;continue
  if flag.startswith(('/Fo','/Fd')) or flag.endswith('qwen_mtp_state_consumer_test.cc'):continue
  command.append(flag)
 command+=['/Zs']+[f'/DHYLE_TEST_QWEN_{name}_ARTIFACTS_HEADER="{(R/path).as_posix()}"' for name,path in headers.items()]+[str(source)]
 env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 m.b.execute(command,env,out,timeout=120);assert m.ident(source)==before
 results.append(dict(endpoint=endpoint,result=m.read(out/'process.json'),authenticated_headers={k:m.ident(R/v) for k,v in headers.items()}))
m.save(S/'wrappers-syntax-result.json',dict(source=before,status='PASS',configured_original_families=list(headers),new_SDK_TUs=0,new_weight_bytes=0,device_runs=0,results=results))
print('PASS original wrapper CPU and CPU/CUDA strict syntax, all eight artifact gates enabled',flush=True)
