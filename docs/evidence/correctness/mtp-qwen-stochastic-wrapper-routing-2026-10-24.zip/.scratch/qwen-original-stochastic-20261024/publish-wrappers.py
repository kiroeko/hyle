from pathlib import Path
import json,hashlib,zipfile,difflib
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
p=Path('tests/compute_models/qwen_mtp_state_consumer_test.cc');text=(R/p).read_text(encoding='utf-8')
first=text.index('std::string bfloat_receipt_text(');last=text.index('\ntemplate<class Source,class ExpertSet>',first)
assert text[first:last]==read(S/'receipt-cwd-check/extraction.json')['fragment']
delta=''.join(difflib.unified_diff((S/'source2'/p).read_text().splitlines(True),text.splitlines(True),fromfile='image2/'+p.as_posix(),tofile='product/'+p.as_posix()))
(S/'wrappers-product-delta.patch').write_text(delta,encoding='utf-8')
records=[R/p,S/'check-wrappers.py',S/'publish-wrappers.py',S/'wrappers-product-delta.patch',S/'wrappers-syntax-result.json']
for name in ('wrappers-cpu-syntax1','wrappers-cpu-cuda-syntax1'):
 records.extend(x for x in (S/name).glob('*') if x.is_file() and x.suffix in ('.json','.log'))
out=R/'docs/evidence/correctness/mtp-qwen-stochastic-wrapper-routing-2026-10-24';archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(set(records)):z.write(file,file.relative_to(R))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
result=dict(date='2026-10-24',status='PASS optional mode propagation and strict source admission',
 changes=['run_packed_q27_target_verifier forwards explicit stochastic=false to the same original target/NextN controller; MAIN target and independent sidecar draft retain their source and vocabulary bindings.',
 'run_named_q27_target_verifier forwards the option for the existing B04/Q14 source adapters.',
 'run_bfloat_target_verifier forwards the option without changing its explicit BF16/NVFP4/GPTQ/CT projection arrays or activation/return precision.',
 'run_named_q24_target_verifier forwards the option before its optional native device handle; the existing greedy CUDA entry explicitly passes false. Existing BF16 MoE and mixed adapters already forward the same mode.'],
 verification=read(S/'wrappers-syntax-result.json'),image2_unchanged=read(S/'ready2.json'),
 limits=['This is actual optional adapter wiring and strict compilation of all eight authenticated artifact-gated CPU and CPU/CUDA entries, not a runtime result for each selected quantization or publisher.',
 'The prior original Q24 GGUF source is the actual quantized stochastic controller representative. The existing mixed BF16 CPU-vocabulary/CUDA-body journey remains incomplete at an explicitly reported source frontier; no extra model/bank acquisition was performed by this wrapper check.',
 'No new mathematics, executor, provider routing, compatibility layer, source quantization conversion or default greedy behavior change. Existing frozen runtime images remain reproducible.'],
 inherited_evidence=['docs/evidence/correctness/mtp-qwen24-original-stochastic-state-2026-10-24.json','docs/evidence/correctness/mtp-qwen24-mixed-stochastic-state-2026-10-24.json'],
 receipt_extracted_body_unchanged=True,archive=identity(archive),archive_records=len(set(records)))
out.with_suffix('.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(identity(archive))
