"""Fill target pins from the completed exact-range receipt; no body rehash."""
from pathlib import Path
import argparse
import hashlib
import json
import re

S = Path(__file__).resolve().parent
R = S.parents[1]
header = R / 'tests/compute_models/qwen24_original_target_roles.h'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-sha',required=True)
args=parser.parse_args()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    assert len(raw) < 10_000_000
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


receipt_path = S / 'original-target91/acquisition.json'
plan_path = S / 'roles-plan.json'
receipt, plan = read(receipt_path), read(plan_path)
assert receipt['complete'] and receipt['original_roles'] == len(receipt['roles']) == 17
assert receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == 14032308224
assert receipt['source_plan_sha256'] == identity(plan_path)['sha256']
assert receipt['repository'] == plan['repository'] and receipt['revision'] == plan['revision']
rows = {}
for row, planned in zip(receipt['roles'], plan['roles'], strict=True):
    assert row['complete']
    for key in ('name', 'file', 'dtype', 'dtype_code', 'gguf_shape_K_N_E', 'bytes', 'absolute_inclusive', 'data_relative_half_open'):
        assert row[key] == planned[key], (row['name'], key)
    payload = row['payload']
    assert (R / payload['path']).resolve() == (S / 'original-target91' / row['file']).resolve()
    assert (R / payload['path']).stat().st_size == payload['bytes'] == row['bytes']
    assert re.fullmatch('[0-9a-f]{64}', payload['sha256'])
    assert row['file'] not in rows
    rows[row['file']] = row
assert sum(row['bytes'] for row in rows.values()) == 14032308224
before = identity(header)
assert before['sha256'] == args.source_sha
source = header.read_text(encoding='utf-8')
pattern = re.compile(r'(Spec\{"[^"\n]+", "([^"\n]+)", ")("[,])')
seen = set()


def pin(match):
    name = match[2]
    assert name in rows and name not in seen
    seen.add(name)
    return match[1] + rows[name]['payload']['sha256'] + match[3]


source, count = pattern.subn(pin, source)
assert count == len(seen) == 17
header.write_text(source, encoding='utf-8', newline='\n')
record = dict(scope='Actual completed original target91 seventeen-role pins only.', before=before,
    after=identity(header), receipt=identity(receipt_path), plan=identity(plan_path),
    roles=17, bytes=14032308224, payload_bodies_read=False, payload_bodies_rehashed=False, native_run=False)
(S / 'pins.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print('Pinned all17 original target roles from actual complete receipt; no payload body read')
