"""Reuse the preceding receipt-pin and final-source recording scripts."""
from pathlib import Path
S=Path(__file__).resolve().parent
R=S.parents[1]
BX=R/'.scratch/qwen27-target-verifier-20261023'
pin=(BX/'pin_target.py').read_text(encoding='utf-8')
pin=pin.replace('import hashlib','import argparse\nimport hashlib',1)
pin=pin.replace("header = R / 'tests/compute_models/qwen27_original_target_roles.h'",
    "header = R / 'tests/compute_models/qwen24_original_target_roles.h'\nparser=argparse.ArgumentParser(description=__doc__)\nparser.add_argument('--source-sha',required=True)\nargs=parser.parse_args()")
pin=pin.replace('original-target63','original-target91').replace('gguf_shape_K_N','gguf_shape_K_N_E')
pin=pin.replace('282318848','14032308224').replace('== 12','== 17').replace('roles=12','roles=17')
pin=pin.replace("assert before['sha256'] == '92da4832ea862275963a5e7371e279fb73de9606f21f41d00cd81d0d6d110c9d'",
    "assert before['sha256'] == args.source_sha")
pin=pin.replace('target63 twelve-role','target91 seventeen-role').replace('all12 original','all17 original')
assert not (S/'pin_target.py').exists()
(S/'pin_target.py').write_text(pin,encoding='utf-8')
freeze=(BX/'freeze_final.py').read_text(encoding='utf-8')
freeze=freeze.replace('BX','BY').replace('BW cached','BX cached')
freeze=freeze.replace("'.scratch/mtp-packed-head-m2-20261023/source-final/freeze.json'",
    "'.scratch/qwen27-target-verifier-20261023/source-final/freeze.json'")
freeze=freeze.replace("('qwen27_original_target_roles.h', 'qwen_full_attention_fragment.h',",
    "('qwen24_original_target_roles.h', 'qwen_full_attention_fragment.h',")
start=freeze.index("    for row in data(S / 'attention-source/freeze.json')['files']:")
end=freeze.index("    pins = data(S / 'pins.json')",start)
freeze=freeze[:start]+freeze[end:]
freeze=freeze.replace("pins['roles'] == 12 and pins['bytes'] == 282318848",
    "pins['roles'] == 17 and pins['bytes'] == 14032308224")
assert not (S/'freeze_final.py').exists()
(S/'freeze_final.py').write_text(freeze,encoding='utf-8')
print('Prepared BY pin and final-source helpers; neither has run.')
