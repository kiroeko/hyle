"""Publish actual finite BY Q24/Q27 target-tail/NextN K1 checks; root invokes only."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
TEXT = {'.h','.hh','.hpp','.cc','.cpp','.c','.py','.json','.txt','.log','.xml','.ps1','.diff','.rsp','.cmd','.md'}
OLD = {f'{b}Q24OriginalNextNAndVocabularyPublishesAndContinues' for b in ('Cpu','Cuda')}
TARGETS = {f'{b}{m}OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'
           for b in ('Cpu','Cuda') for m in ('Q27','Q24')}
_seen = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R/path).resolve()


def identity(path):
    path = resolve(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path), bytes=path.stat().st_size, sha256=digest)


def verify(row):
    path = resolve(row['path'])
    if path not in _seen:
        _seen[path] = identity(path)
    assert (_seen[path]['bytes'],_seen[path]['sha256']) == (row['bytes'],row['sha256']), row['path']
    return path


def integer(props,key):
    value=int(props[key]);assert value>=0,(key,value)
    return value


def protect(before):
    verify(before['protected_qwen_image'])
    text=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    digest=hashlib.sha256(text[text.index('## 最新完整性能对比'):].encode()).hexdigest()
    assert digest==before['protected_performance_tail_sha256']
    return digest


def contracts(run):
    assert run['process']['exit']==0 and not run['process']['timed_out']
    assert run['tests']==len(run['cases'])==6
    assert not any(run[k] for k in ('failures','errors','disabled','skips'))
    assert run['throughput_evidence'] is False and run['physical_memory_evidence'] is False and run['whole_original_model'] is False
    assert {c['attributes']['name'] for c in run['cases']}==OLD|TARGETS
    counts={}
    for case in run['cases']:
        a,p=case['attributes'],case['properties'];name=a['name']
        assert a['classname']=='QwenMtpStateConsumer' and a['status']=='run' and a['result']=='completed'
        counts[name]=integer(p,'actual_submissions');assert counts[name]>0
        provider='ggml-cuda' if name.startswith('Cuda') else 'ggml-cpu'
        assert integer(p,'original_native_reference_submissions')==0
        if name in OLD:
            for key,value in dict(packed_head_m2_rows=2,packed_head_m2_matmuls=1,packed_head_m2_full_reference_values=496640,
                packed_head_m2_pending_feedback_rows=2,packed_head_m2_submissions=2,complete_draft_resources=6).items():
                assert p[key]==str(value),(name,key,p.get(key))
            assert p['packed_head_m2_provider']==provider
            continue
        q24='Q24' in name
        for key,value in dict(complete_target_draft_resources=12,original_target_roles=17 if q24 else 12,
            original_target_source_bytes=14032308224 if q24 else 282318848,
            first_full_target_projection_values=178689 if q24 else 59392,first_full_target_verifier_values=496640,
            first_full_nextn_head_values=248320,target_verifier_full_vocabulary=248320,
            target_verifier_matmuls=1,target_verifier_rows=2,natural_k1_trials=1,controlled_matching_trials=1,controlled_rejection_trials=1).items():
            assert p[key]==str(value),(name,key,p.get(key))
        assert p['target_verifier_provider']==provider
        accepted0,accepted1=integer(p,'accepted_zero_drafts'),integer(p,'accepted_one_draft')
        repairs=integer(p,'accepted_target_conditioned_repairs')
        assert accepted0>0 and accepted1>0 and accepted0+accepted1==3 and repairs==accepted1
        natural=integer(p,'natural_accepted_drafts');assert natural in (0,1) and accepted1==1+natural
        assert integer(p,'natural_proposal')<248320 and integer(p,'target_verifier_submissions')==3
        assert counts[name]==sum(integer(p,k) for k in ('target_submissions','nextn_submissions','target_verifier_submissions'))
        assert integer(p,'peak_state_backing_bytes')<=integer(p,'state_budget_bytes')
        for key in ('whole_state_publications','cancelled_unpublished_drafts','rejected_stale_publishes','actual_target_reseed_checks'):
            assert integer(p,key)>0
        if q24:
            assert integer(p,'actual_accepted_kv_repair_submissions')==2*repairs
            assert integer(p,'actual_pending_embedding_feedback_checks')==integer(p,'nextn_resident_episodes')
            assert integer(p,'nextn_submissions')==2*integer(p,'nextn_resident_episodes')
            assert integer(p,'target_submissions')==2*integer(p,'target_resident_episodes')
            assert p['target_expert_source_codec']=='IQ4_XS' and p['nextn_expert_source_codec']=='Q4_K'
            for key,value in dict(target_resident_slot_bytes=267388928,nextn_resident_slot_bytes=283117568,
                                  target_expert_domain=512,target_resident_capacity=10).items():
                assert p[key]==str(value),(name,key,p.get(key))
            for leg in range(3):assert p[f'target_expert_provider_{leg}']==provider
        else:
            assert integer(p,'actual_accepted_kv_repair_submissions')==repairs
            assert integer(p,'actual_pending_embedding_feedback_checks')==integer(p,'nextn_submissions')
    return counts


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--link-attempt',type=int,required=True)
    parser.add_argument('--run',type=int,default=1)
    parser.add_argument('--freeze',default='source-final')
    args=parser.parse_args();assert args.link_attempt>0 and args.run>0 and Path(args.freeze).name==args.freeze
    before=read(S/'before.json')
    for row in before['previous_publication'].values(): verify(row)
    protected=protect(before)
    plan_path,receipt_path=S/'roles-plan.json',S/'original-target91/acquisition.json'
    plan,receipt=read(plan_path),read(receipt_path)
    assert receipt['complete'] and receipt['original_roles']==len(receipt['roles'])==len(plan['roles'])==17
    assert receipt['source_plan_sha256']==identity(plan_path)['sha256']
    assert receipt['role_payload_bytes']==receipt['successful_request_body_bytes']==plan['new_payload_bytes']==14032308224
    assert not receipt['whole_shard_downloaded']
    changes=receipt.get('acquisition_process_changes',[])
    ranges=receipt.get('range_chunk_policies',[])
    assert any(change.get('old_session')==59046 and change.get('old_terminal_exit')==1 for change in changes)
    assert any(policy.get('old_bytes')==33554432 and policy.get('new_bytes')==134217728 for policy in ranges)
    assert (receipt['repository'],receipt['revision'])==(plan['repository'],plan['revision'])
    for row,wanted in zip(receipt['roles'],plan['roles'],strict=True):
        for key in ('name','file','dtype','dtype_code','gguf_shape_K_N_E','bytes','data_relative_half_open','absolute_inclusive'):
            assert row[key]==wanted[key]
        assert row['complete'] and row['payload']['bytes']==row['bytes']
        assert resolve(row['payload']['path']).stat().st_size==row['bytes'] and len(row['payload']['sha256'])==64
    freeze_path=S/args.freeze/'freeze.json';freeze=read(freeze_path)
    frozen={verify(row):row for row in freeze['source']}
    for row in freeze['source']:
        assert identity(row['snapshot'])['sha256']==row['sha256']
    verify(read(S/'pins.json')['after'])
    linkdir=S/f'tests-link{args.link_attempt}'
    image=read(linkdir/'ready.json')['image'];image_path=verify(image)
    link,runtime=read(linkdir/'link-plan.json'),read(linkdir/'runtime-environment.json')
    assert read(linkdir/'link.result.json')['exit']==0
    assert all(link[k]==0 for k in ('SDK_builds','native_CPU_builds','NVCC_builds','shaders'))
    host_path=verify(freeze['actual_host_compile']);host=read(host_path)
    assert host_path.is_relative_to(S) and verify(host['source']) in frozen
    assert read(host_path.with_name('compile.result.json'))['exit']==0
    assert any(resolve(row['path'])==host_path for row in link['compiled_records'])
    assert host['object'] in link['inputs']
    for row in (*link['inputs'],*runtime['staged_dlls']):
        assert resolve(row['path']).stat().st_size==row['bytes'] and len(row['sha256'])==64
    summary_path=S/f'checks{args.run}/summary.json';run=read(summary_path)
    assert run['image']==image and resolve(run['process']['command'][0])==image_path
    counts=contracts(run)
    docs=[R/'docs/developer/current-work.md',R/'docs/implementation/model-operators.md',R/'docs/architecture/compute-design.md']
    files=set(frozen)|set(docs)|{verify(before['previous_publication']['evidence'])}
    files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in TEXT)
    files.discard(S/'publication.json')
    for path in files:
        assert path.resolve().is_relative_to(R) and path.suffix.lower() in TEXT and path.stat().st_size<10_000_000,path
    destination=D/'mtp-qwen24-target-verifier-2026-10-23.json';archive=destination.with_suffix('.zip')
    assert D.is_dir() and not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
        for path in sorted(files):zipped.write(path,path.relative_to(R).as_posix())
    record=dict(date='2026-10-23',stage='BY',goal_complete=False,
        conclusion='The listed original Q24 target91/globalnorm and NextN92 K1 consumers passed, alongside Q27 target/NextN and original Q24 NextN regressions; actual fullV pending and accepted-prefix repair use immutable Graph leases.',
        artifact=dict(repository=plan['repository'],revision=plan['revision'],variant=plan['variant'],new_target_roles=17,new_target_bytes=14032308224,
            plan=identity(plan_path),acquisition=identity(receipt_path),acquisition_process_changes=changes,range_chunk_policies=ranges,existing_original_NextN_and_vocabulary='Reuses separately acquired original Q24 NextN92 Q4_K experts and untied Q4_K embedding/head; Q27 target/NextN/banks remain existing original inputs. No duplicate acquisition.',payloads_archived=False,extra_payload_hash_pass=False),
        implementation=dict(target='Original Q24 target91 Q5_K attention, full512-domain originalIQ4_XS routed experts, distinct Q6_K/Q5_K shared branches, F32 routers/norms and globalnorm. NextN92 keeps its distinct Q4_K experts/parameters. Shared actual Q/G/GQA/RoPE64/sigmoid/fullKV math and one12-member K1 runner are reused with Q27.',
            supply='One immutable cold PackedExpertLayout per actual source derives canonical codec, encoded per-expert stride, E10 operands, aligned bank/map offsets and two-slot capacity. TargetIQ4 slot267388928 differs from NextNQ4 slot283117568; all512 logical IDs and actualTop10 are retained. Three mapped source banks are never uploaded or decoded in full; no hot large allocations.',
            verifier='Two actual normalized target taps enter one fullF32M2 projection on the existing248320-row original packed head. Actual I32 correction/bonus and Top1/Top2 control leases feed the common accepted-prefix protocol and original embedding, without a host ID replacement.',
            acceptance='Accept0 chooses after-current first checkpoint. This runner eagerly repairs accept1 proposal KV/hidden using the actual first target tap, retaining second target six members before atomic12-member publish. Logical repairs and actual one/two-phase Graph submissions remain separately counted. A complete explicit-lag protocol is also valid; hidden-only replacement does not repair speculative KV.',
            reference='Actual-predecessor original-byte certificates retain Q5/Q6/Q8/Q4 rules and add independent IQ4_XS nonlinear signedLUT/6bit-scale decode. CPUAQ8_K and current tokenM1CUDAMMVQ AQ8_1 integer boundaries are source-bounded, with unchanged local tolerances and no native reference batches. FirstQ24 target178689 values and M2 verifier496640 values are checked fully.',
            acquisition='Bounded serial range acquisition was intentionally stopped twice after measured IO waits:32->128MiB ranges, then three role workers. Existing authenticated prefixes were reused; original request/process-change receipts preserve interrupted exits and reasons. Successful final role authentication is not a claim that the first download process succeeded.'),
        validation=dict(tests=run['tests'],failures=run['failures'],errors=run['errors'],skips=run['skips'],graph_submissions=sum(counts.values()),graph_submissions_by_case=counts,
            actual_native_summary=identity(summary_path),image=image,process=run['process'],cases=run['cases'],source_freeze=identity(freeze_path),host_translation_units=1,
            host_compile_record=identity(host_path),host_compile_attempts=len(list(S.glob('compile*/qwen-state/plan.json'))),link_identity_cache=identity(linkdir/'link-plan.json'),runtime_identity_cache=identity(linkdir/'runtime-environment.json'),
            cache_scope='Current repository sources/dependencies and executable identity are authenticated. Reused native binaries retain recorded cache hashes with current extents, without another SDK body hash sweep.',SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
        limitations=['Q24 layer90 and Q27 layer62 inputs and finite initial histories remain explicit fixtures. These execute original final target tails and NextN, not full92/64-layer prompt-to-output trained models or task quality.',
            'One finite natural trial/model/backend and explicit match/reject controls do not establish real workload acceptance rate. No TPS/loading speedup or physical RAM/VRAM peak is measured.',
            'The listed Windows CPU/CUDA cases do not sign all systems/codecs/shapes; the IQ4 certificate does not cover alternative MMQ arithmetic. Other confirmed MTP work remains, and protected AV/Q35 performance identity is unchanged.'],
        remaining='Complete remaining confirmed target/verifier/artifact wiring and necessary checks, then full ordinary/MTP performance comparison.',
        reused_publication=before['previous_publication'],source_review=identity(S/'review/layout-and-iq4-reference-independent.json'),
        protected_performance_tail_sha256=protected,protected_qwen_image=before['protected_qwen_image'],
        sources=[identity(path) for path in sorted(frozen)+docs],archive=identity(archive),archive_items=len(files))
    destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    publication=dict(evidence=identity(destination),archive=identity(archive))
    (S/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
    assert protect(before)==protected
    print(json.dumps(dict(**publication,tests=run['tests'],graphs=record['validation']['graph_submissions'])))


if __name__=='__main__':main()
