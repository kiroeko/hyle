"""Resume exact original Q24 roles with at most three independent role workers.

Root must stop the serial process and confirm its terminal exit before running
this script. It uses the same paths/plan/receipt; it never runs beside another
writer. Existing authenticated prefixes are verified locally and not fetched.
"""
from pathlib import Path
import datetime
import hashlib
import json
import math
import os
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import RLock

S = Path(__file__).resolve().parent
R = S.parents[1]
CHUNK, IO = 128 * 1024 * 1024, 1024 * 1024

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

plan_path = S / 'roles-plan.json'
plan = read(plan_path)
assert plan['new_roles'] == 17 and plan['new_payload_bytes'] == 14032308224
assert len(plan['roles']) == 17 and len({r['file'] for r in plan['roles']}) == 17
assert all(Path(r['file']).name == r['file'] for r in plan['roles'])
out = S / plan['output_directory']
out.mkdir(exist_ok=True)
receipt = out / 'acquisition.json'
headers = {}
for tag, source in plan['sources'].items():
    info = source['header']
    assert info, f'Actual header required: {tag}'
    raw = (R / info['path']).read_bytes()
    assert len(raw) == info['bytes'] and hashlib.sha256(raw).hexdigest() == info['sha256']
    headers[tag] = json.loads(raw)

assert {r['name'] for r in plan['roles']} == {r['name'] for r in headers['29']['tensors'] if r['name'].startswith('blk.91.')} | {'output_norm.weight'}
roles = []
for role in plan['roles']:
    source = plan['sources'][str(role['source_shard'])]
    header = headers[str(role['source_shard'])]
    assert (header['repository'], header['revision'], header['file']) == (plan['repository'], plan['revision'], source['file'])
    exact = next(t for t in header['tensors'] if t['name'] == role['name'])
    shape = list(map(int, exact['shape']))
    assert exact['dtype'] == role['dtype'] and exact['dtype_code'] == role['dtype_code']
    assert shape == role['gguf_shape_K_N_E']
    block, stored = {0:(1,4), 8:(32,34), 12:(256,144), 13:(256,176), 14:(256,210), 23:(256,136)}[exact['dtype_code']]
    elements = math.prod(shape)
    assert elements % block == 0 and elements // block * stored == role['bytes']
    first = int(header['tensor_data_offset']) + int(exact['offset'])
    assert role['absolute_inclusive'] == [first, first + role['bytes'] - 1]
    assert role['data_relative_half_open'] == [int(exact['offset']), int(exact['offset']) + role['bytes']]
    total = source.get('file_bytes', source.get('whole_file_bytes'))
    assert total and source['etag'] and first + role['bytes'] <= total
    roles.append(dict(**role, url=source['url'], etag=source['etag'], whole_file_bytes=total,
        complete=False, chunks=[], payload=dict(path=(out / role['file']).relative_to(R).as_posix(), bytes=role['bytes'], sha256=None)))
assert len(roles) == 17 and sum(r['bytes'] for r in roles) == plan['new_payload_bytes']
identity = dict(repository=plan['repository'], revision=plan['revision'],
    source_plan=plan_path.relative_to(R).as_posix(), source_plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
    expected_role_payload_bytes=plan['new_payload_bytes'])
if receipt.exists():
    record = read(receipt)
    assert all(record[k] == v for k,v in identity.items())
    for prior, wanted in zip(record['roles'], roles, strict=True):
        assert all(prior[k] == wanted[k] for k in wanted if k not in ('complete','chunks','payload'))
        assert prior['payload']['path'] == wanted['payload']['path']
        assert prior['payload']['bytes'] == wanted['payload']['bytes']
else:
    assert not any((R / row['payload']['path']).exists() for row in roles)
    record = dict(**identity, complete=False, original_roles=17, whole_shard_downloaded=False,
        reused_vocabulary_and_NextN=True, chunk_bytes=CHUNK, stream_buffer_bytes=IO, requests=[], roles=roles)


LOCK = RLock()
WORKERS = 3


def save():
    # This lock is reentrant: every shared mutation and its durable save is
    # also performed under LOCK by the caller, not merely the json dump.
    with LOCK:
        temporary = receipt.with_suffix('.json.next')
        with temporary.open('w', encoding='utf-8', newline='\n') as stream:
            json.dump(record, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, receipt)


def acquire_role(row):
    # Exactly one future owns this role/file. All of row remains part of the
    # shared record, so mutations still hold LOCK while other workers save.
    attempt = None
    path = R / row['payload']['path']
    try:
        with LOCK:
            chunks = [dict(part) for part in row['chunks']]
            completed = row['complete']
            saved_sha256 = row['payload']['sha256']
        offset = 0
        if path.exists():
            with path.open('rb') as stream:
                for part in chunks:
                    assert part['offset'] == offset and 0 < part['bytes'] <= CHUNK
                    assert offset + part['bytes'] <= row['bytes']
                    digest, remaining = hashlib.sha256(), part['bytes']
                    while remaining:
                        data = stream.read(min(IO, remaining))
                        assert data, 'Truncated authenticated prefix'
                        digest.update(data)
                        remaining -= len(data)
                    assert digest.hexdigest() == part['sha256']
                    offset += part['bytes']
            assert offset <= path.stat().st_size <= min(row['bytes'], offset + CHUNK)
        else:
            assert not chunks and not completed
        if completed:
            assert offset == path.stat().st_size == row['bytes']
            with path.open('rb') as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == saved_sha256
            print('REUSED', path.name, row['bytes'], flush=True)
            return
        while offset < row['bytes']:
            size = min(CHUNK, row['bytes'] - offset)
            first = row['absolute_inclusive'][0] + offset
            last = first + size - 1
            # Private construction; after append, every modification of this
            # same attempt object is serialized with the record snapshot.
            attempt = dict(role=row['name'], first=first, last=last, requested_bytes=size,
                complete=False, started_utc=now())
            with LOCK:
                record['requests'].append(attempt)
                save()
            print('REQUEST', path.name, offset, size, flush=True)
            request = urllib.request.Request(row['url'], headers={
                'Range': f'bytes={first}-{last}', 'If-Range': row['etag'],
                'Accept-Encoding': 'identity', 'User-Agent': 'hyle-original-role-consumer/1'})
            for retry in range(5):
                try:
                    response = urllib.request.urlopen(request, timeout=45)
                    break
                except (urllib.error.URLError, TimeoutError, OSError) as error:
                    with LOCK:
                        attempt.setdefault('transport_errors', []).append(dict(
                            error_type=type(error).__name__, error=str(error), utc=now()))
                        save()
                    if retry == 4:
                        raise
                    time.sleep(2)
            with response:
                expected_range = f'bytes {first}-{last}/{row["whole_file_bytes"]}'
                assert response.status == 206 and response.headers.get('Content-Range') == expected_range, (response.status, response.headers.get('Content-Range'))
                assert response.headers.get('ETag') == row['etag']
                assert response.headers.get('Content-Length') == str(size)
                assert response.headers.get('Content-Encoding') in (None, 'identity')
                digest = hashlib.sha256()
                with path.open('r+b' if path.exists() else 'x+b') as stream:
                    stream.seek(offset)
                    remaining = size
                    while remaining:
                        data = response.read(min(IO, remaining))
                        assert data, 'Early EOF'
                        digest.update(data)
                        stream.write(data)
                        remaining -= len(data)
                    assert not response.read(1), 'Overlong range'
                    # A stopped writer may leave only an unauthenticated
                    # suffix here. Retain exactly the just-verified prefix.
                    stream.truncate(offset + size)
                    stream.flush()
                    os.fsync(stream.fileno())
            assert path.stat().st_size == offset + size
            part = dict(offset=offset, bytes=size, sha256=digest.hexdigest(),
                absolute_range_inclusive=[first, last])
            with LOCK:
                row['chunks'].append(part)
                attempt.update(complete=True, http_status=206, bytes=size,
                    content_range=expected_range, etag=row['etag'],
                    sha256=part['sha256'], finished_utc=now())
                save()
            offset += size
            print('VERIFIED', path.name, offset, '/', row['bytes'], flush=True)
        with path.open('rb') as stream:
            whole_sha256 = hashlib.file_digest(stream, 'sha256').hexdigest()
        with LOCK:
            row['payload']['sha256'] = whole_sha256
            row['complete'] = True
            save()
        print('ACQUIRED', path.name, whole_sha256, flush=True)
    except Exception as error:
        with LOCK:
            if attempt is not None and not attempt['complete']:
                attempt.update(error_type=type(error).__name__, error=str(error), finished_utc=now())
            # Prefix-authentication or final-file errors also need a truthful
            # error record when no HTTP attempt is currently incomplete.
            record.setdefault('role_errors', []).append(dict(role=row['name'],
                error_type=type(error).__name__, error=str(error), utc=now()))
            save()
        raise


with LOCK:
    record['complete'] = False
    record['chunk_bytes'] = CHUNK
    record['stream_buffer_bytes'] = IO
    record['parallel_role_workers'] = WORKERS
    rows = tuple(record['roles'])
    assert len({row['name'] for row in rows}) == len({row['payload']['path'] for row in rows}) == 17
    save()
errors = []
with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='q24-role') as executor:
    futures = [executor.submit(acquire_role, row) for row in rows]
    for future in as_completed(futures):
        try:
            future.result()
        except Exception as error:
            errors.append(error)
# Every role future is terminal before the final counts/complete bit changes.
# A failed role does not make a partially acquired model look complete.
if errors:
    with LOCK:
        record['complete'] = False
        save()
    raise errors[0]
with LOCK:
    assert all(row['complete'] and row['payload']['sha256'] for row in record['roles'])
    payload_bytes = sum(row['payload']['bytes'] for row in record['roles'])
    request_bytes = sum(request['bytes'] for request in record['requests'] if request['complete'])
    assert payload_bytes == request_bytes == 14032308224
    record.update(complete=True, role_payload_bytes=payload_bytes,
        successful_request_body_bytes=request_bytes, finished_utc=now())
    save()
print('COMPLETE', payload_bytes, flush=True)
