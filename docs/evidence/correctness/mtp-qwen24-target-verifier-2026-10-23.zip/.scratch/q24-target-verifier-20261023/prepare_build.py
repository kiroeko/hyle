"""Reuse the BX host/native closure for the Q24 target consumer."""
from pathlib import Path
import hashlib
import json
S=Path(__file__).resolve().parent
R=S.parents[1]
BX=R/'.scratch/qwen27-target-verifier-20261023'
source=BX/'build.py'
text=source.read_text(encoding='utf-8')
text=text.replace('Incremental original Q27 target/NextN K1 verifier and affected Qwen consumers.',
                  'Incremental original Q24 target/NextN K1 verifier and affected Qwen consumers.')
text=text.replace("BASE = BH / 'tests-link1'", "BX = R / '.scratch/qwen27-target-verifier-20261023'\nBASE = BX / 'tests-link2'")
text=text.replace("R / '.scratch/mtp-packed-head-m2-20261023/compile1/qwen-state/identity.json'",
                  "BX / 'compile2/qwen-state/identity.json'")
text=text.replace('qwen27-target-verifier-checks.exe','q24-target-verifier-checks.exe')
text=text.replace('original Q27 target/NextN','original Q24 target/NextN')
text=text.replace("env['HYLE_QWEN27_ORIGINAL_TARGET_DIR'] = str(S / 'original-target63')",
                  "env['HYLE_QWEN27_ORIGINAL_TARGET_DIR'] = str(BX / 'original-target63')\n    env['HYLE_QWEN24_ORIGINAL_TARGET_DIR'] = str(S / 'original-target91')")
text=text.replace('timeout=900)', 'timeout=1800)')
assert "BASE = BX / 'tests-link2'" in text
assert "BX / 'compile2/qwen-state/identity.json'" in text
assert text.count("env['HYLE_QWEN24_ORIGINAL_TARGET_DIR']")==1
assert not (S/'build.py').exists()
(S/'build.py').write_text(text,encoding='utf-8')
(S/'build-origin.json').write_text(json.dumps(dict(source=str(source.relative_to(R)),
    sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    reuse='BX compiled providers/host/native closure; recompile only the Qwen consumer translation unit.'),indent=2)+'\n',encoding='utf-8')
print('Prepared BY one-host build and six-case native environment.')
