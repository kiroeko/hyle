"""Record BY inputs before the Q24 target/layout changes; root runs once."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]
BX=R/'.scratch/qwen27-target-verifier-20261023'
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    path=Path(path)
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,sha256=digest)
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert not (S/'before.json').exists()
source=[]
for name in ('qwen_mtp_state_consumer.h','qwen_mtp_state_consumer_test.cc',
             'qwen24_original_nextn_roles.h','qwen24_original_resident_weights.h',
             'qwen24_original_moe_fragment.h','qwen24_original_nextn_reference.h',
             'qwen_full_attention_fragment.h'):
    path=R/'tests/compute_models'/name
    row=identity(path)
    snapshot=S/'before'/row['path']
    snapshot.parent.mkdir(parents=True,exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    row['snapshot']=snapshot.relative_to(R).as_posix();source.append(row)
previous=read(BX/'publication.json')
assert read(BX/'progress.json')['stage_complete'] is True
assert all(identity(R/row['path'])==row for row in previous.values())
tail=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail=tail[tail.index('## 最新完整性能对比'):]
protected=read(BX/'before.json')
assert hashlib.sha256(tail.encode()).hexdigest()==protected['protected_performance_tail_sha256']
save(S/'before.json',dict(stage='BY',utc=datetime.now(timezone.utc).isoformat(),
    previous_goal_turn_classification='progress: BX original Q27 target/globalnorm, fullV verifier and accepted KV repair passed6cases84Graphs; shared math, docs and evidence published.',
    source=source,previous_publication=previous,
    protected_performance_tail_sha256=protected['protected_performance_tail_sha256'],
    protected_qwen_image=protected['protected_qwen_image']))
save(S/'progress.json',dict(stage='BY',stage_complete=False,goal_complete=False,
    state='Connect original Q24 target91/globalnorm to existing complete NextN92 and fullV verifier; derive expert supply from actual IQ4_XS/Q4_K descriptions.',
    new_TPS=False,native_checks_run=False,
    scope='Original final target and NextN with explicit upstream layer90 and initial-history boundaries.',
    next='Acquire only missing17 target roles, share cold expert layout/supply and ordinary K1 execution, then check original codec math and complete accepted continuation.'))
print('Prepared BY; prior goal turn is verified progress.')
