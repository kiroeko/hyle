#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <span>
#include <string>
#include <vector>

#include "hyle/compute/resource_leases.h"
#include "hyle/compute/state_versions.h"
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include "hyle/graph/cuda.h"
#include "cuda_sidecar_quant_reference.h"
// This TU contains both backends. Runtime reference selection below must not
// change the legacy Bank::dots definition or turn CPU checks into CUDA work.
#undef HYLE_C4_QUANTIZED_REFERENCE
#undef HYLE_C4_GROUPED_REFERENCE
#undef HYLE_C5_GGUF_DOT_REFERENCE
#endif
#if defined(HYLE_TEST_QWEN_STATE_CPU)
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/cpu.h"
#endif
#include "qwen_mtp_state_consumer.h"
#include "qwen27_original_nextn_reference.h"
#include "qwen24_original_nextn_reference.h"
#include "qwen24_original_resident_weights.h"
#include "model_resident_fragment.h"
#include "qwen27_original_target_reference.h"
#include "qwen24_original_target_roles.h"
#include "qwen24_original_target_fragment.h"
#include "qwen24_original_target_reference.h"

namespace {
using namespace qwen_mtp_state_consumer;
namespace numeric=d5_qwen35_gguf_fragment;
namespace original_reference=qwen27_original_nextn_reference;
namespace original24_reference=qwen24_original_nextn_reference;
namespace resident24=qwen24_original_resident_weights;
namespace resident_fragment=model_resident_fragment;
namespace target_roles=qwen27_original_target_roles;
namespace target_model=qwen_full_attention_fragment;
namespace target_reference=qwen27_original_target_reference;
namespace target24_roles=qwen24_original_target_roles;
namespace target24_model=qwen24_original_target_fragment;
namespace target24_reference=qwen24_original_target_reference;
namespace moe_reference=qwen24_moe_reference;

Bytes read(const c::ReadLease &lease) {
  Bytes bytes(lease.size());check(take(lease.view(),"actual readonly result").read(bytes),"retained result bytes");return bytes;
}
template<class T> std::vector<T> typed(const c::ReadLease &lease) {
  if(lease.size()%sizeof(T))throw std::runtime_error("actual typed lease extent");
  std::vector<T> values(lease.size()/sizeof(T));
  check(take(lease.view(),"actual typed permission").read(std::as_writable_bytes(std::span(values))),"actual typed result");return values;
}
std::string directory(const char *name) {
#if defined(_WIN32)
  char *value=nullptr;std::size_t bytes=0;
  if(_dupenv_s(&value,&bytes,name))throw std::runtime_error("cannot read original-role directory");
  const std::unique_ptr<char,decltype(&std::free)> owner(value,&std::free);return value?value:"";
#else
  const auto *value=std::getenv(name);return value?value:"";
#endif
}
struct State final {
  c::StateSchema schema;
  c::StateStore store;
  std::array<c::StateEntryId,kResources> entries;
  std::vector<c::StateEntryId> extra_entries;
  static State create(const Model &model,const c::StorageOwner &owner,std::size_t output_root_bytes,
                      std::span<const c::TensorDesc> extra_descriptions={}) {
    std::vector<c::StateEntrySpec> specs(kResources+extra_descriptions.size());
    const auto desc=descriptions(model);std::size_t bytes=0;
    for(std::size_t i=0;i<specs.size();++i) {
      const auto &description=i<desc.size()?desc[i]:extra_descriptions[i-desc.size()];
      specs[i]={.description=description,.resource=owner.ref()};
      const auto extent=take(description.required_bytes(),"complete draft state bytes");
      if(extent>std::numeric_limits<std::size_t>::max()-255||bytes>std::numeric_limits<std::size_t>::max()-(extent+255u)/256u*256u)
        throw std::runtime_error("complete state backing bound overflow");
      bytes+=(extent+255u)/256u*256u;
    }
    if(output_root_bytes>std::numeric_limits<std::size_t>::max()-bytes)throw std::runtime_error("complete state output backing bound overflow");
    State s;s.schema=take(c::StateSchema::create(specs),"complete NextN state schema");
    // A state member retains the WHOLE output-pool root, including diagnostic
    // generations. Count it once, plus the six separate initial roots; logical
    // member extents do not measure retained physical backing.
    s.store=take(c::StateStore::create(s.schema,{.max_versions=16,.max_drafts=2,
        .max_retained_blocks=96,.max_backing_bytes=output_root_bytes+bytes}),"bounded ordinary state store");
    for(std::size_t i=0;i<s.entries.size();++i)s.entries[i]=take(s.schema.entry(i),"actual complete state member");
    for(std::size_t i=0;i<extra_descriptions.size();++i)s.extra_entries.push_back(take(s.schema.entry(kResources+i),"actual additional target state member"));
    return s;
  }
  c::ReadLease member(const c::StateVersion &version,std::size_t entry) const {
    return take(version.member(entries.at(entry)),"actual immutable complete-state member");
  }
  std::array<c::ReadLease,kResources> inputs(const c::StateVersion &version) const {
    std::array<c::ReadLease,kResources> values;
    for(std::size_t i=0;i<values.size();++i)values[i]=member(version,i);return values;
  }
  c::StateVersion import(std::span<const c::ReadLease> values,std::span<const c::ReadLease> extra={}) {
    if(values.size()!=kResources||extra.size()!=extra_entries.size())throw std::runtime_error("complete imported NextN/target member count");
    std::vector<c::StateMember> members(kResources+extra.size());
    for(std::size_t i=0;i<values.size();++i)members[i]={entries[i],values[i]};
    for(std::size_t i=0;i<extra.size();++i)members[kResources+i]={extra_entries[i],extra[i]};
    return take(store.import(members),"explicit complete initial boundary");
  }
  c::StateVersion candidate(const c::StateVersion &from,const Recipe &recipe,std::span<const c::ReadLease> result,
      std::span<const c::ReadLease> extra={},const c::ReadLease &pending={}) {
    if(!extra.empty()&&extra.size()!=extra_entries.size())throw std::runtime_error("one complete target checkpoint needs every target member");
    auto draft=take(store.begin(from),"single complete NextN prefix draft");
    for(std::size_t i=0;i<entries.size();++i)
      check(draft.replace(entries[i],result[recipe.state_ports[i]]),"stage actual matching complete prefix member");
    for(std::size_t i=0;i<extra.size();++i)check(draft.replace(extra_entries[i],extra[i]),"stage actual matching target prefix member");
    if(pending)check(draft.replace(entries[kPending],pending),"stage actual verifier pending result lease");
    return take(draft.finalize(),"one complete hidden/KV/pending/position candidate");
  }
};
using Image=std::array<Bytes,kResources>;
Image image(const State &state,const c::StateVersion &version) {
  Image result;for(std::size_t i=0;i<result.size();++i)result[i]=read(state.member(version,i));return result;
}
struct NativeReferenceCount final {
  std::uint32_t submissions=0;
  ~NativeReferenceCount() {
    // Also report work if a numerical ASSERT exits the journey early.
    ::testing::Test::RecordProperty("original_native_reference_submissions",int(submissions));
  }
};
struct ExpertSource final {
  // Only immutable metadata/views are adapted. This strong owner keeps the
  // original mappings alive; there is no virtual source or payload copy.
  std::shared_ptr<const void> owner;
  std::array<c::TensorDesc,3> descriptions;
  std::array<std::span<const std::byte>,3> banks;
  std::array<m::ConstBufferView,3> views;
  c::TensorDesc expert_description(full24::Leg leg) const {return descriptions.at(std::size_t(leg));}
  std::span<const std::byte> expert_bytes(full24::Leg leg,std::int32_t global) const {
    const auto index=std::size_t(leg);const auto &description=descriptions.at(index);
    if(global<0||global>=description.dimensions()[0])throw std::runtime_error("actual expert source ID out of range");
    const auto stride=std::size_t(description.byte_strides()[0]);return banks.at(index).subspan(std::size_t(global)*stride,stride);
  }
  m::ConstBufferView expert_view(full24::Leg leg,std::int32_t global) const {
    const auto bytes=expert_bytes(leg,global);const auto stride=std::size_t(descriptions.at(std::size_t(leg)).byte_strides()[0]);
    return take(views.at(std::size_t(leg)).subview(std::size_t(global)*stride,bytes.size()),"actual selected expert mapping");
  }
};
template<class Data,class Role> ExpertSource expert_source(std::shared_ptr<const Data> source,const std::array<Role,3> &roles) {
  if(!source)throw std::runtime_error("actual expert source needs its original mapping owner");
  ExpertSource result;result.owner=source;
  for(std::size_t leg=0;leg<roles.size();++leg) {
    result.descriptions[leg]=source->expert_description(static_cast<full24::Leg>(leg));
    result.banks[leg]=source->bytes(roles[leg]);result.views[leg]=source->view(roles[leg]);
    if(take(result.descriptions[leg].required_bytes(),"actual original expert extent")!=result.banks[leg].size()||
        result.views[leg].size()!=result.banks[leg].size())throw std::runtime_error("original expert bytes/view/typed extent differs");
  }
  (void)take(resident24::PackedExpertLayout::create(result.descriptions),"actual original expert layout");return result;
}
struct ExpertSupply final {
  std::shared_ptr<const full24::Roles> roles;
  ExpertSource source;
  std::shared_ptr<resident24::CpuSupply> cpu;
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
  std::shared_ptr<resident24::CudaSupply> cuda;
#endif
  std::size_t episodes=0;
  std::vector<full24::Selection> selections;
  const resident24::PackedExpertLayout &layout() const {
    if(cpu)return cpu->layout();
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
    if(cuda)return cuda->layout();
#endif
    throw std::runtime_error("ordinary expert supply has no native backend");
  }
};
struct Program final {
  struct Phases final {
    resident_fragment::ResidentDraft<moe24::Boundary,1> plan;
    std::vector<std::shared_ptr<Program>> programs;
  };
  Recipe recipe;
  std::shared_ptr<ExpertSupply> supply; // outlives every ordinary child Invocation
  sem::GraphCase logical;
  std::vector<c::ReadLease> parameters;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool outputs;
  std::shared_ptr<Phases> resident;
  std::size_t output_root_bytes=0;
  std::uint32_t submissions=0;
  bool cuda_backend=false,original_full_checked=false;
  std::uint32_t original_episodes=0;
  std::uint64_t original_full_values=0,original_full_head_values=0;
  std::vector<std::int32_t> original_pending,original_predictions;
  static Program create(Recipe recipe,c::Context &context,const c::StorageOwner &owner,bool cuda,
                        bool phase=false,std::shared_ptr<ExpertSupply> supply={}) {
    Program p;p.recipe=std::move(recipe);p.supply=std::move(supply);p.logical=sem::make_graph(p.recipe.fragment);p.cuda_backend=cuda;
    std::vector<g::ConstantBinding> constants;
    for(std::size_t i=0;i<p.logical.constants.size();++i) {
      const auto binding=std::find_if(p.recipe.external.begin(),p.recipe.external.end(),[&](const auto &item){return item.constant==i;});
      if(binding!=p.recipe.external.end()) {
        if(binding->role.description!=p.recipe.fragment.description(p.recipe.fragment.constants[i]))throw std::runtime_error("external role descriptor changed");
        constants.push_back(take(binding->role.binding(p.logical.constants[i]),"original/shared vocabulary owner binding"));
      } else {
        const auto &desc=p.recipe.fragment.description(p.recipe.fragment.constants[i]);
        if(p.recipe.fragment.constant_bytes[i].size()!=take(desc.required_bytes(),"generated constant bytes"))throw std::runtime_error("missing generated constant payload");
        p.parameters.push_back(upload(owner,p.recipe.fragment.constant_bytes[i]));
        constants.push_back({.value=p.logical.constants[i],.tensor=take(p.parameters.back().tensor(desc),"generated immutable parameter"),.owner=owner,.lease=p.parameters.back()});
      }
    }
    const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*p.recipe.model.profile),"exact selected MAIN artifact"),
        c::WorkloadPhase::kDecode,{0x48594c454d4f444cULL,p.recipe.fragment.region,1}};
    const g::CompileOptions options{.constants=constants,.workload=workload};
    const auto compile=[&]() -> hyle::Result<g::CompiledGraph> {
#if defined(HYLE_TEST_QWEN_STATE_CPU)
      if(!cuda)return g::cpu::compile(p.logical.graph,context,options);
#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
      if(cuda)return g::cuda::compile(p.logical.graph,context,owner,options);
#endif
      throw std::runtime_error("requested NextN backend is not enabled");
    };
    if(p.recipe.moe) {
      if(!p.supply||!p.supply->source.owner||(p.recipe.original24&&p.supply->roles!=p.recipe.original24))
        throw std::runtime_error("complete Q24 needs its actual original resident source");
      for(std::size_t leg=0;leg<3;++leg)
        if(p.recipe.fragment.description(p.recipe.moe->boundary.banks[leg])!=p.supply->layout().resident(leg))
          throw std::runtime_error("actual expert supply differs from the cold Graph bank description");
      p.resident=std::make_shared<Phases>();
      p.resident->plan=resident_fragment::split(p.recipe.fragment,std::array{p.recipe.moe->boundary},0x5132344d4f455000ULL);
      // Full constants were prepared exactly once above; each cold phase
      // borrows those same immutable owners, including both distinct banks.
      std::vector<orig::ReadonlyRole> ready;std::size_t generated=0;
      for(std::size_t slot=0;slot<p.logical.constants.size();++slot) {
        const auto found=std::find_if(p.recipe.external.begin(),p.recipe.external.end(),[&](const auto &entry){return entry.constant==slot;});
        if(found!=p.recipe.external.end())ready.push_back(found->role);
        else ready.push_back({"shared ready Q24 constant",p.recipe.fragment.description(p.recipe.fragment.constants[slot]),owner,p.parameters.at(generated++)});
      }
      for(const auto &part:p.resident->plan.phases) {
        Recipe local{.model=p.recipe.model,.fragment=part.fragment};
        local.state_ports.fill(std::numeric_limits<std::size_t>::max());
        for(std::size_t slot=0;slot<part.original_constants.size();++slot) {
          const auto origin=part.original_constants[slot];
          const auto found=std::find_if(p.recipe.fragment.constants.begin(),p.recipe.fragment.constants.end(),[&](Value value){return value.ordinal()==origin.ordinal();});
          if(found==p.recipe.fragment.constants.end())throw std::runtime_error("Q24 phase constant lost original identity");
          local.external.push_back({slot,ready.at(std::size_t(found-p.recipe.fragment.constants.begin()))});
        }
        p.resident->programs.push_back(std::make_shared<Program>(Program::create(std::move(local),context,owner,cuda,true)));
        p.output_root_bytes+=p.resident->programs.back()->output_root_bytes;
      }
      p.report_original24_roles(owner);
      for(auto &payload:p.recipe.fragment.constant_bytes){Bytes empty;payload.swap(empty);}
      return p;
    }
    p.compiled=take(compile(),"one ordinary complete NextN Graph");
    if(!phase) {
    // This existing four-case consumer is also the full packed-RHS route
    // regression. Inspect the actual MatMul behind its independent Copy;
    // smaller internal shards cannot satisfy this descriptor or report gate.
    const auto copied_logits=take(p.logical.graph.producer(p.logical.outputs[p.recipe.logits]),"full logits observer");
    if(take(p.logical.graph.operation_kind(copied_logits),"full logits observer kind")!=c::OperationKind::kCopy)
      throw std::runtime_error("full logits observer must own an independent Copy");
    const auto full_logits=take(p.logical.graph.node_input(copied_logits,0),"actual full logits value");
    const auto full_head=take(p.logical.graph.producer(full_logits),"actual full head MatMul");
    const auto full_weight=take(p.logical.graph.node_input(full_head,1),"actual complete packed head");
    const auto wanted_weight=take(c::gguf_weight_description(p.recipe.model.head.quant,c::DataType::kFloat32,
        p.recipe.model.hidden,kVocabulary),"required complete packed head geometry");
    if(take(p.logical.graph.operation_kind(full_head),"full head kind")!=c::OperationKind::kMatMul ||
        take(p.logical.graph.value_description(full_weight),"full head actual weight geometry")!=wanted_weight ||
        take(p.logical.graph.value_description(full_logits),"full head actual logits geometry")!=sem::dense({1,kVocabulary}))
      throw std::runtime_error("complete vocabulary head must be one full-bank MatMul");
    std::size_t selected_head_steps=0;
    for(std::size_t step_index=0;step_index<p.compiled.report.step_count();++step_index) {
      const auto selected=take(p.compiled.report.step(step_index),"full head selected plan step");
      for(std::size_t node_index=0;node_index<selected.node_count;++node_index)
        if(take(p.compiled.report.step_node(step_index,node_index),"full head selected logical node")==full_head) {
          ++selected_head_steps;
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
          if(cuda && selected.provider.id!=c::ggml_cuda::kProviderId)
            throw std::runtime_error("full packed CUDA head must retain the native ggml CUDA route");
#endif
          ::testing::Test::RecordProperty("full_head_provider",std::string(selected.provider.name));
        }
    }
    if(selected_head_steps!=1)throw std::runtime_error("full head must belong to exactly one selected plan step");
    ::testing::Test::RecordProperty("full_head_encoded_bytes",int(take(wanted_weight.required_bytes(),"full head span")));
    p.report_original_roles(owner);
    }
    p.invocation=take(p.compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"one ordinary NextN Invocation");
    std::size_t bytes=0;
    for(std::size_t i=0;i<p.logical.outputs.size();++i) {
      if(take(p.compiled.executable.output_ownership(i),"actual NextN output ownership")!=g::OutputOwnership::kCaller)throw std::runtime_error("NextN fixture requires independent caller outputs");
      const auto extent=take(p.recipe.fragment.description(p.recipe.fragment.outputs[i]).required_bytes(),"actual NextN output span");
      bytes+=(extent+255u)/256u*256u;
    }
    constexpr std::uint32_t generations=6;
    p.output_root_bytes=bytes*generations;
    p.outputs=take(c::LeasePool::create(owner.ref(),p.output_root_bytes,
        {.max_blocks=std::uint32_t(p.logical.outputs.size()*generations),.backing_alignment=256}),"bounded retained NextN generations");
    // Cold generated bytes have native immutable owners now; references retain
    // only the eight decoded prototype rows, not a second full matrix bank.
    for(auto &payload:p.recipe.fragment.constant_bytes) {Bytes empty;payload.swap(empty);}
    return p;
  }
  std::uint32_t native_submissions() const {
    if(!resident)return submissions;
    std::uint32_t count=0;for(const auto &program:resident->programs)count+=program->native_submissions();return count;
  }
  std::size_t live_output_blocks() const {
    if(!resident)return outputs.stats().live_blocks;
    std::size_t count=0;for(const auto &program:resident->programs)count+=program->live_output_blocks();return count;
  }
  std::size_t active_output_uses() const {
    if(!resident)return outputs.stats().active_uses;
    std::size_t count=0;for(const auto &program:resident->programs)count+=program->active_output_uses();return count;
  }
  std::vector<c::ReadLease> execute_resident(c::Queue &queue,std::span<const c::ReadLease> inputs) {
    if(!resident||!recipe.moe||!supply||recipe.fragment.inputs.size()!=inputs.size()+4)
      throw std::runtime_error("complete original Q24 ordinary two-phase input contract");
    std::vector<c::ReadLease> live(recipe.fragment.descriptions.size());
    for(std::size_t i=0;i<inputs.size();++i)live.at(recipe.fragment.inputs[i].ordinal())=inputs[i];
    std::array<std::vector<c::ReadLease>,2> completed;
    for(std::size_t index=0;index<resident->programs.size();++index) {
      const auto &part=resident->plan.phases[index];auto &program=*resident->programs[index];
      std::optional<resident24::CpuBatch> cpu_batch;
      std::optional<full24::Selection> selected;
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
      std::optional<c::cuda::WeightBatch> cuda_batch;
      std::array<g::WeightBinding,4> weight_bindings{};
#endif
      std::array<std::size_t,4> dynamic_ports{};
      std::span<const std::size_t> externally_bound;
      std::function<void(g::Invocation&)> bind_external;
      if(part.resident_stage) {
        const auto &boundary=resident->plan.routers.at(*part.resident_stage);
        // Only these ten scheduling IDs cross to the host. Every activation,
        // router weight and state tensor remains its actual producer lease.
        selected=full24::select(typed<std::int32_t>(live.at(boundary.ids.ordinal())));
        const std::array bank_values{boundary.banks[0],boundary.banks[1],boundary.banks[2],boundary.map};
        for(std::size_t bank=0;bank<bank_values.size();++bank) {
          const auto found=std::find_if(part.original_inputs.begin(),part.original_inputs.end(),[&](Value value){return value.ordinal()==bank_values[bank].ordinal();});
          if(found==part.original_inputs.end())throw std::runtime_error("Q24 phase lost an expert/map generation input");
          dynamic_ports[bank]=std::size_t(found-part.original_inputs.begin());
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
          weight_bindings[bank]={program.logical.inputs.at(dynamic_ports[bank]),resident24::kBankIds[bank]};
#endif
        }
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
        if(cuda_backend) {
          if(!supply->cuda)throw std::runtime_error("original Q24 CUDA supply is missing");
          cuda_batch.emplace(take(supply->cuda->upload(supply->episodes%2,*selected,supply->source,queue),"actual original Q24 expert upload"));
          externally_bound=dynamic_ports;
          bind_external=[&](g::Invocation &active){check(g::cuda::bind(active,weight_bindings,*cuda_batch),"atomic original Q24 experts/map generation");};
        } else
#endif
        {
          if(!supply->cpu)throw std::runtime_error("original Q24 CPU supply is missing");
          cpu_batch.emplace(take(supply->cpu->upload(*selected,supply->source),"actual original Q24 CPU expert supply"));
          for(std::size_t bank=0;bank<bank_values.size();++bank)live.at(bank_values[bank].ordinal())=cpu_batch->banks[bank];
        }
      }
      std::vector<c::ReadLease> arguments;
      for(auto original:part.original_inputs)arguments.push_back(live.at(original.ordinal()));
      completed[index]=program.execute_inputs(queue,arguments,externally_bound,bind_external);
      for(std::size_t port=0;port<part.original_outputs.size();++port)
        live.at(part.original_outputs[port].ordinal())=completed[index][port];
      if(part.resident_stage) {
        supply->selections.push_back(std::move(*selected));
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
        if(cuda_batch) {
          const auto accounting=take(cuda_batch->report(),"retired Q24 expert upload accounting");
          EXPECT_EQ(accounting.logical_bytes,supply->layout().logical_bytes());EXPECT_EQ(accounting.staged_bytes,supply->layout().logical_bytes());
          EXPECT_EQ(accounting.completed_bytes,accounting.submitted_bytes);EXPECT_FALSE(accounting.copied_bytes_unknown);
          std::printf("Q24 original E10 episode=%zu slot=%zu union=%zu logical=%zu staged=%zu submitted=%zu completed=%zu unknown=%d (API upload accounting,not measured VRAM/bus traffic)\n",
              supply->episodes,supply->episodes%2,supply->selections.back().globals.size(),accounting.logical_bytes,accounting.staged_bytes,
              accounting.submitted_bytes,accounting.completed_bytes,int(accounting.copied_bytes_unknown));
        }
#endif
        const auto &boundary=resident->plan.routers.at(*part.resident_stage);
        for(auto bank:boundary.banks)live.at(bank.ordinal())={};live.at(boundary.map.ordinal())={};
      }
      // The ordinary Invocation already waited and reset. Its batch and all
      // dynamic input guards retire before the shared double slot is reused.
    }
    std::vector<c::ReadLease> result;
    for(const auto location:resident->plan.full_outputs)result.push_back(completed.at(location.phase).at(location.port));
    ++supply->episodes;++submissions;return result;
  }
  struct Actual final {const Program *program;g::ValueId value;};
  Actual observation(std::size_t port) const {
    const Program *consumer=this;std::size_t local_port=port;
    if(resident) {
      const auto location=resident->plan.full_outputs.at(port);
      consumer=resident->programs.at(location.phase).get();local_port=location.port;
    }
    const auto copy=take(consumer->logical.graph.producer(consumer->logical.outputs.at(local_port)),"actual observer producer");
    if(take(consumer->logical.graph.operation_kind(copy),"actual observer operation")!=c::OperationKind::kCopy)
      throw std::runtime_error("model observations require independent Copy backing");
    return {consumer,take(consumer->logical.graph.node_input(copy,0),"actual observed value")};
  }
  const resident_fragment::Phase &phase(const Actual &consumer) const {
    if(resident)for(std::size_t index=0;index<resident->programs.size();++index)
      if(resident->programs[index].get()==consumer.program)return resident->plan.phases[index];
    throw std::runtime_error("actual consumer is outside its ordinary resident phases");
  }
  g::ValueId phase_input(Value origin,const Actual &consumer) const {
    const auto &part=phase(consumer);
    const auto found=std::find_if(part.original_inputs.begin(),part.original_inputs.end(),[&](Value value){return value.ordinal()==origin.ordinal();});
    if(found==part.original_inputs.end())throw std::runtime_error("actual operand is absent from consumer phase");
    return consumer.program->logical.inputs.at(std::size_t(found-part.original_inputs.begin()));
  }
  g::ValueId observation_input(std::size_t port,const Actual &consumer) const {
    const auto producer=observation(port);if(producer.program==consumer.program)return producer.value;
    const auto published=recipe.fragment.outputs.at(port);
    const auto copy=std::find_if(recipe.fragment.nodes.begin(),recipe.fragment.nodes.end(),[&](const auto &node){
      return node.outputs.size()==1&&node.outputs[0].ordinal()==published.ordinal();
    });
    if(copy==recipe.fragment.nodes.end()||!copy->operation.get_if<c::Copy>()||copy->inputs.size()!=1)
      throw std::runtime_error("cross-phase observer lost its original Copy provenance");
    return phase_input(copy->inputs[0],consumer);
  }
  g::ValueId constant_operand(const orig::ReadonlyRole &expected,const Actual &consumer,const c::StorageOwner &owner) const {
    const auto found=std::find_if(recipe.external.begin(),recipe.external.end(),[&](const auto &entry){return entry.role.name==expected.name;});
    if(found==recipe.external.end()||found->role.description!=expected.description||found->role.identity!=expected.identity)
      throw std::runtime_error("original constant identity/descriptor differs");
    auto slot=found->constant;
    if(resident) {
      const auto origin=recipe.fragment.constants.at(slot);const auto &part=phase(consumer);
      const auto local=std::find_if(part.original_constants.begin(),part.original_constants.end(),[&](Value value){return value.ordinal()==origin.ordinal();});
      if(local==part.original_constants.end())throw std::runtime_error("original constant is absent in actual consumer phase");
      slot=std::size_t(local-part.original_constants.begin());
    } else if(consumer.program!=this)throw std::runtime_error("constant consumer is outside this ordinary Graph");
    const auto supplied=std::find_if(consumer.program->recipe.external.begin(),consumer.program->recipe.external.end(),[&](const auto &entry){return entry.constant==slot;});
    if(supplied==consumer.program->recipe.external.end()||supplied->role.owner.ref()!=owner.ref()||supplied->role.description!=expected.description||supplied->role.identity!=expected.identity)
      throw std::runtime_error("actual Graph lost its original readonly constant owner");
    const auto a=take(supplied->role.lease.view(),"actual readonly bank"),b=take(expected.lease.view(),"once-prepared original readonly bank");
    if(a.resource()!=b.resource()||a.native_handle()!=b.native_handle()||a.offset()!=b.offset()||a.size()!=b.size()||
        supplied->role.lease.generation()!=expected.lease.generation()||a.size()!=take(expected.description.required_bytes(),"original typed bank extent"))
      throw std::runtime_error("actual Graph copied or replaced its original immutable bank");
    return consumer.program->logical.constants.at(slot);
  }
  std::string selected_provider(const Actual &value,g::NodeId node,bool packed) const {
    std::size_t count=0;std::string name;
    for(std::size_t step=0;step<value.program->compiled.report.step_count();++step) {
      const auto selected=take(value.program->compiled.report.step(step),"actual model provider step");
      for(std::size_t index=0;index<selected.node_count;++index)
        if(take(value.program->compiled.report.step_node(step,index),"actual selected logical node")==node) {
          ++count;name=selected.provider.name;
#if defined(HYLE_TEST_QWEN_STATE_CPU)
          if(packed&&!cuda_backend&&selected.provider.id!=c::ggml_cpu::kProviderId)throw std::runtime_error("packed CPU certificate requires its actual ggml route");
#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
          if(packed&&cuda_backend&&selected.provider.id!=c::ggml_cuda::kProviderId)throw std::runtime_error("packed CUDA certificate requires its actual MMVQ route");
#endif
        }
    }
    if(count!=1)throw std::runtime_error("model operation needs exactly one actual compiled provider");return name;
  }
  void report_original24_roles(const c::StorageOwner &owner) const {
    if(!recipe.original24||!recipe.moe||!resident)return;
    if(recipe.external.size()!=19||recipe.embedding_bank||recipe.head_bank)
      throw std::runtime_error("complete original Q24 needs exactly19 static original banks and no generated vocabulary");
    const auto actual=[&](std::size_t port){return observation(port);};
    const auto local_input=[&](Value origin,const Actual &consumer){return phase_input(origin,consumer);};
    const auto operand=[&](std::size_t port,const Actual &consumer){return observation_input(port,consumer);};
    const auto bank=[&](const orig::ReadonlyRole &expected,const Actual &consumer){return constant_operand(expected,consumer,owner);};
    const auto provider=[&](const Actual &value,g::NodeId node,const char *label,bool packed) {
      auto name=selected_provider(value,node,packed);::testing::Test::RecordProperty(std::string("original24_provider_")+label,name);return name;
    };
    const auto probe=[&](Value origin) {
      const auto found=std::find_if(recipe.moe_ports.begin(),recipe.moe_ports.end(),[&](const auto &entry){return entry.first.ordinal()==origin.ordinal();});
      if(found==recipe.moe_ports.end())throw std::runtime_error("original Q24 MoE observer missing");return found->second;
    };
    const auto &ports=recipe.moe->ports;const auto &roles=*recipe.original24;
    struct Projection final {std::size_t port,input;const orig::ReadonlyRole *role;bool packed;};
    const auto old=[&](std::string_view name)->const orig::ReadonlyRole* {
      const auto found=std::find_if(recipe.external.begin(),recipe.external.end(),[&](const auto &entry){return entry.role.name==name;});
      if(found==recipe.external.end())throw std::runtime_error("original Q24 old K/V/norm supply missing");return &found->role;
    };
    const std::array projections{
      Projection{recipe.eh,recipe.joined,&roles.at(full24::Role::kProjection),true},
      Projection{recipe.qg,recipe.nx,&roles.at(full24::Role::kQuery),true},
      Projection{recipe.key,recipe.nx,old("blk.92.attn_k.weight"),true},Projection{recipe.value,recipe.nx,old("blk.92.attn_v.weight"),true},
      Projection{recipe.oproj,recipe.attended,&roles.at(full24::Role::kOutput),true},
      Projection{recipe.logits,recipe.state_ports[kHidden],&roles.at(full24::Role::kHead),true},
      Projection{probe(ports.logits),recipe.ffn_input,&roles.at(full24::Role::kRouter),false},
      Projection{probe(ports.shared_gate_raw),recipe.ffn_input,&roles.at(full24::Role::kSharedRouter),false},
      Projection{probe(ports.shared.gate),recipe.ffn_input,&roles.at(full24::Role::kSharedGate),true},
      Projection{probe(ports.shared.up),recipe.ffn_input,&roles.at(full24::Role::kSharedUp),true},
      Projection{probe(ports.shared.down),probe(ports.shared.activation),&roles.at(full24::Role::kSharedDown),true}};
    for(const auto &projection:projections) {
      const auto value=actual(projection.port);const auto &graph=value.program->logical.graph;
      const auto node=take(graph.producer(value.value),"original Q24 actual MatMul producer");
      const auto operation=take(graph.operation(node),"original Q24 actual MatMul operation");const auto *matmul=operation.get_if<c::MatMul>();
      auto input=take(graph.node_input(node,0),"original Q24 actual MatMul activation");
      if(projection.port==recipe.oproj) {
        const auto reshape=take(graph.producer(input),"Q24 output head flatten");
        const auto view=take(graph.operation(reshape),"Q24 output flatten operation");
        if(!view.get_if<c::View>()||view.get_if<c::View>()->kind()!=c::ViewKind::kReshape)throw std::runtime_error("Q24 output projection lost its actual head flatten");
        input=take(graph.node_input(reshape,0),"Q24 actual attended heads");
      }
      if(!matmul||matmul->accumulation_type!=c::DataType::kFloat32||input!=operand(projection.input,value)||
          take(graph.node_input(node,1),"original Q24 actual MatMul bank")!=bank(*projection.role,value)||
          take(graph.value_description(value.value),"Q24 projection actual dtype").data_type()!=c::DataType::kFloat32)
        throw std::runtime_error("Q24 original MatMul operands/accumulation/type differ");
      const auto selected_provider=provider(value,node,std::string(projection.role->name).c_str(),projection.packed);
      if(projection.port==recipe.logits)::testing::Test::RecordProperty("full_head_provider",selected_provider);
    }
    const auto head=actual(recipe.logits);
    if(take(head.program->logical.graph.value_description(head.value),"Q24 full head output extent")!=sem::dense({1,kVocabulary})||
        roles.at(full24::Role::kHead).description!=take(c::gguf_weight_description(c::GgufQuantizedType::kQ4K,c::DataType::kFloat32,8192,kVocabulary),"Q24 full original head"))
      throw std::runtime_error("Q24 head must be a single complete original vocabulary MatMul");
    const auto embedding=actual(recipe.embedding);const auto &embedding_graph=embedding.program->logical.graph;
    const auto lookup=take(embedding_graph.producer(embedding.value),"Q24 original embedding Gather");
    if(take(embedding_graph.operation_kind(lookup),"Q24 embedding operation")!=c::OperationKind::kGather||
        take(embedding_graph.node_input(lookup,0),"Q24 actual embedding table")!=bank(roles.at(full24::Role::kEmbedding),embedding)||
        take(embedding_graph.node_input(lookup,1),"Q24 actual pending ID")!=local_input(recipe.fragment.inputs[kPending],embedding))
      throw std::runtime_error("Q24 full embedding must consume its actual pending lease and independent original bank");
    const auto gamma=[&](std::size_t port,const orig::ReadonlyRole &expected,bool rotary=false) {
      const auto value=actual(port);const auto &graph=value.program->logical.graph;
      auto normalized=value.value;
      if(rotary) {
        const auto rope=take(graph.producer(normalized),"Q24 per-head RoPE producer");
        if(take(graph.operation_kind(rope),"Q24 actual RoPE operation")!=c::OperationKind::kRoPE)throw std::runtime_error("Q24 per-head norm lost actual RoPE boundary");
        normalized=take(graph.node_input(rope,0),"Q24 actual per-head norm");
      }
      const auto node=take(graph.producer(normalized),"Q24 actual original RMS producer");
      const auto operation=take(graph.operation(node),"Q24 actual original RMS operation");const auto *rms=operation.get_if<c::RmsNorm>();
      if(!rms||rms->epsilon!=1e-6F||take(graph.node_input(node,1),"Q24 actual original gamma")!=bank(expected,value))
        throw std::runtime_error("Q24 RMS must directly borrow its original GGUF gamma without adding1");
    };
    gamma(recipe.hn,roles.at(full24::Role::kHiddenNorm));gamma(recipe.en,roles.at(full24::Role::kEmbeddingNorm));
    gamma(recipe.nx,roles.at(full24::Role::kAttentionNorm));gamma(recipe.ffn_input,roles.at(full24::Role::kPostNorm));
    gamma(recipe.state_ports[kHidden],roles.at(full24::Role::kHeadNorm));
    gamma(recipe.query,roles.at(full24::Role::kQueryNorm),true);gamma(recipe.rotated_key,*old("blk.92.attn_k_norm.weight"),true);
    const auto local_ids=actual(probe(ports.local_ids));const auto &mapped_graph=local_ids.program->logical.graph;
    const auto gather=take(mapped_graph.producer(local_ids.value),"Q24 global-to-local mapping producer");
    if(take(mapped_graph.operation_kind(gather),"Q24 mapping operation")!=c::OperationKind::kGather||
        take(mapped_graph.node_input(gather,0),"Q24 actual generation map")!=local_input(recipe.moe->boundary.map,local_ids)||
        take(mapped_graph.node_input(gather,1),"Q24 actual full512 expert IDs")!=operand(probe(ports.ids),local_ids))
      throw std::runtime_error("Q24 mapping must consume actual global IDs without modulo or domain filtering");
    const std::array grouped_ports{ports.routed.gate,ports.routed.up,ports.routed.down};
    for(std::size_t leg=0;leg<3;++leg) {
      const auto value=actual(probe(grouped_ports[leg]));const auto &graph=value.program->logical.graph;
      const auto node=take(graph.producer(value.value),"Q24 original compact grouped producer");
      const auto operation=take(graph.operation(node),"Q24 original grouped operation");
      const auto grouped=operation.custom_as<c::model_ops::GroupedMatMul>();
      auto input=take(graph.node_input(node,1),"Q24 actual grouped activation");
      if(leg<2) {
        const auto reshape=take(graph.producer(input),"Q24 routed input slot reshape");
        const auto view=take(graph.operation(reshape),"Q24 routed input slot operation");
        if(!view.get_if<c::View>()||view.get_if<c::View>()->kind()!=c::ViewKind::kReshape)throw std::runtime_error("Q24 original routed input requires its actual shared activation");
        input=take(graph.node_input(reshape,0),"Q24 original routed source activation");
      }
      if(!grouped||take(graph.node_input(node,0),"Q24 actual compact original bank")!=local_input(recipe.moe->boundary.banks[leg],value)||
          input!=operand(probe(leg<2?ports.input:ports.routed.activation),value)||
          take(graph.node_input(node,2),"Q24 actual checked local IDs")!=operand(probe(ports.local_ids),value)||
          take(graph.value_description(take(graph.node_input(node,0),"Q24 compact descriptor operand")),"Q24 compact descriptor")!=full24::resident_description(static_cast<full24::Leg>(leg)))
        throw std::runtime_error("Q24 original experts must use canonical E10 inputs with actual checked mapping");
      provider(value,node,(std::string("expert_")+std::to_string(leg)).c_str(),true);
    }
    ::testing::Test::RecordProperty("full_head_encoded_bytes",std::to_string(take(roles.at(full24::Role::kHead).description.required_bytes(),"Q24 full packed head bytes")));
  }
  void report_original_roles(const c::StorageOwner &owner) const {
    if(!recipe.original)return;
    const auto &source=*recipe.original;
    if(recipe.external.size()!=17 || recipe.embedding_bank || recipe.head_bank)
      throw std::runtime_error("complete original Q27 must have exactly17 original banks and no generated vocabulary");
    const auto actual=[&](std::size_t port) {
      const auto copy=take(logical.graph.producer(logical.outputs.at(port)),"original Q27 independent observation");
      if(take(logical.graph.operation_kind(copy),"original Q27 observer kind")!=c::OperationKind::kCopy)
        throw std::runtime_error("original Q27 observations must own independent Copy outputs");
      return take(logical.graph.node_input(copy,0),"original Q27 actual observed value");
    };
    const auto ready=[&](const orig::ReadonlyRole &expected) {
      const auto found=std::find_if(recipe.external.begin(),recipe.external.end(),[&](const auto &entry){return entry.role.name==expected.name;});
      if(found==recipe.external.end()||found->role.description!=expected.description||found->role.owner.ref()!=owner.ref()||
          found->role.identity!=&orig::q27::kIdentity||!recipe.fragment.constant_bytes.at(found->constant).empty())
        throw std::runtime_error("original Q27 constant must borrow its one authenticated ready owner");
      const auto supplied=take(found->role.lease.view(),"original Q27 supplied readonly bank");
      const auto original=take(expected.lease.view(),"original Q27 once-bound readonly bank");
      if(supplied.resource()!=original.resource()||supplied.native_handle()!=original.native_handle()||
          supplied.offset()!=original.offset()||supplied.size()!=original.size()||
          found->role.lease.generation()!=expected.lease.generation()||
          supplied.size()!=take(expected.description.required_bytes(),"original Q27 compressed bank bytes"))
        throw std::runtime_error("original Q27 ready bank identity or compressed extent changed");
      return logical.constants.at(found->constant);
    };
    for(std::size_t index=0;index<full::kRoles;++index)(void)ready(source.roles[index]);
    const auto norm=[&](std::size_t port,full::Role role) {
      const auto node=take(logical.graph.producer(actual(port)),"original Q27 RMS producer");
      const auto op=take(logical.graph.operation(node),"original Q27 RMS operation");
      const auto *rms=op.get_if<c::RmsNorm>();
      if(!rms||rms->epsilon!=1e-6F||take(logical.graph.node_input(node,1),"original Q27 RMS gamma")!=ready(source.at(role)))
        throw std::runtime_error("original Q27 RMS must use its actual GGUF gamma without an offset");
    };
    norm(recipe.nx,full::Role::kAttentionNorm);norm(recipe.ffn_input,full::Role::kPostNorm);
    norm(recipe.state_ports[kHidden],full::Role::kHeadNorm);
    for(const auto &[port,role]:std::array{std::pair{recipe.query,full::Role::kQueryNorm},std::pair{recipe.rotated_key,full::Role::kKeyNorm}}) {
      const auto rope=take(logical.graph.producer(actual(port)),"original Q27 RoPE producer");
      const auto normalized=take(logical.graph.node_input(rope,0),"original Q27 actual per-head RMS value");
      const auto producer=take(logical.graph.producer(normalized),"original Q27 per-head RMS producer");
      const auto op=take(logical.graph.operation(producer),"original Q27 per-head RMS operation");
      const auto *rms=op.get_if<c::RmsNorm>();
      if(!rms||rms->epsilon!=1e-6F||take(logical.graph.node_input(producer,1),"original Q27 per-head original gamma")!=ready(source.at(role)))
        throw std::runtime_error("original Q27 Q/K RMS gamma source changed");
    }
    const auto lookup=take(logical.graph.producer(actual(recipe.embedding)),"original Q27 full embedding Gather");
    if(take(logical.graph.operation_kind(lookup),"original Q27 embedding operation")!=c::OperationKind::kGather||
        take(logical.graph.node_input(lookup,0),"original Q27 full embedding bank")!=ready(source.at(full::Role::kEmbedding))||
        take(logical.graph.node_input(lookup,1),"original Q27 actual pending input")!=logical.inputs[kPending])
      throw std::runtime_error("original Q27 Gather must consume the actual complete-vocabulary pending lease");
    const auto original_eh=std::find_if(recipe.external.begin(),recipe.external.end(),[](const auto &entry){
      return entry.role.name=="blk.64.nextn.eh_proj.weight";
    });
    if(original_eh==recipe.external.end())throw std::runtime_error("complete Q27 must keep its original Q6_K EH");
    struct Projection final {std::size_t port,input;const orig::ReadonlyRole *role;};
    const std::array projections{
      Projection{recipe.eh,recipe.joined,&original_eh->role},
      Projection{recipe.qg,recipe.nx,&source.at(full::Role::kQuery)},Projection{recipe.key,recipe.nx,&source.at(full::Role::kKey)},
      Projection{recipe.value,recipe.nx,&source.at(full::Role::kValue)},Projection{recipe.oproj,recipe.attended,&source.at(full::Role::kOutput)},
      Projection{recipe.dense_ffn_ports[0],recipe.ffn_input,&source.at(full::Role::kFfnGate)},
      Projection{recipe.dense_ffn_ports[1],recipe.ffn_input,&source.at(full::Role::kFfnUp)},
      Projection{recipe.ffn_output,recipe.dense_ffn_ports[2],&source.at(full::Role::kFfnDown)},
      Projection{recipe.logits,recipe.state_ports[kHidden],&source.at(full::Role::kHead)}};
    for(const auto &projection:projections) {
      const auto node=take(logical.graph.producer(actual(projection.port)),"original Q27 actual packed MatMul");
      auto input=take(logical.graph.node_input(node,0),"original Q27 projection actual input");
      if(projection.port==recipe.oproj) {
        const auto reshape=take(logical.graph.producer(input),"original Q27 head flatten producer");
        const auto op=take(logical.graph.operation(reshape),"original Q27 head flatten operation");
        const auto *view=op.get_if<c::View>();
        if(!view||view->kind()!=c::ViewKind::kReshape)throw std::runtime_error("original Q27 output projection must flatten actual heads");
        input=take(logical.graph.node_input(reshape,0),"original Q27 actual attended heads");
      }
      if(take(logical.graph.operation_kind(node),"original Q27 projection operation")!=c::OperationKind::kMatMul||
          input!=actual(projection.input)||take(logical.graph.node_input(node,1),"original Q27 actual original RHS")!=ready(*projection.role))
        throw std::runtime_error("original Q27 projection actual operand/bank wiring changed");
      std::size_t count=0;std::string provider;
      for(std::size_t step=0;step<compiled.report.step_count();++step) {
        const auto selected=take(compiled.report.step(step),"original Q27 selected projection provider");
        for(std::size_t index=0;index<selected.node_count;++index)
          if(take(compiled.report.step_node(step,index),"original Q27 selected projection node")==node) {
            ++count;provider=selected.provider.name;
#if defined(HYLE_TEST_QWEN_STATE_CPU)
            if(!cuda_backend&&selected.provider.id!=c::ggml_cpu::kProviderId)
              throw std::runtime_error("original Q27 CPU certificate requires its actual native ggml AVX2 projection route");
#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
            if(cuda_backend&&selected.provider.id!=c::ggml_cuda::kProviderId)
              throw std::runtime_error("original Q27 CUDA certificate requires its actual native ggml MMVQ projection route");
#endif
          }
      }
      if(count!=1)throw std::runtime_error("original Q27 projection must have one actual selected provider");
      ::testing::Test::RecordProperty(std::string("original_provider_")+std::string(projection.role->name),provider);
    }
  }
  std::vector<c::ReadLease> execute(c::Queue &queue,const State &state,const c::StateVersion &from) {
    const auto inputs=state.inputs(from);
    const auto cursor=typed<std::int32_t>(inputs[kCursor]).at(0),position=typed<std::int32_t>(inputs[kPosition]).at(0);
    const auto pending=typed<std::int32_t>(inputs[kPending]).at(0);
    if(cursor<0 || cursor>=kCapacity || position<0 || position==std::numeric_limits<std::int32_t>::max() || pending<0 || pending>=kVocabulary)
      throw std::runtime_error("complete NextN boundary exceeds prepared capacity/position/vocabulary");
    if(resident)return execute_resident(queue,inputs);
    return execute_inputs(queue,inputs);
  }
  std::vector<c::ReadLease> execute_inputs(c::Queue &queue,std::span<const c::ReadLease> inputs,
      std::span<const std::size_t> externally_bound={},const std::function<void(g::Invocation&)> &bind_external={}) {
    if(resident) {
      if(!externally_bound.empty()||bind_external)throw std::runtime_error("resident scheduling owns its actual batch binding");
      return execute_resident(queue,inputs);
    }
    if(inputs.size()!=logical.inputs.size())throw std::runtime_error("ordinary Qwen Graph input count");
    std::vector<bool> external_ports(inputs.size(),false);
    for(const auto index:externally_bound) {
      if(index>=inputs.size()||external_ports[index])throw std::runtime_error("resident Q24 input index");
      external_ports[index]=true;
    }
    if(!externally_bound.empty()&&!bind_external)throw std::runtime_error("resident Q24 generation binder missing");
    struct ResetOnFailure final {g::Invocation &active;bool done=false;~ResetOnFailure(){if(!done)active.reset().IgnoreError();}} reset{invocation};
    for(std::size_t i=0;i<inputs.size();++i)if(!external_ports[i])
      check(invocation.bind(logical.inputs[i],recipe.fragment.description(recipe.fragment.inputs[i]),inputs[i]),"bind actual state lease without host reconstruction");
    if(bind_external)bind_external(invocation);
    for(std::size_t i=0;i<logical.outputs.size();++i) {
      const auto &desc=recipe.fragment.description(recipe.fragment.outputs[i]);
      check(invocation.bind(logical.outputs[i],desc,take(outputs.allocate(take(desc.required_bytes(),"NextN output extent")),"new result generation writer")),"bind actual NextN output");
    }
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
    check(invocation.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}),"prepare connected NextN replay");
    {auto done=take(invocation.submit(queues),"complete NextN Graph submit");++submissions;check(done.wait(),"actual NextN retirement");}
    std::vector<c::ReadLease> values;
    for(const auto output:logical.outputs)values.push_back(take(take(invocation.result(output),"successful NextN Graph result").storage_lease(),"independent actual result backing"));
    check(invocation.reset(),"withdraw completed invocation permissions");reset.done=true;
    if(invocation.submit(queues))throw std::runtime_error("reset NextN invocation still prepared");
    return values;
  }
};

void quantized(std::span<const float> actual,std::span<const float> expected,const char *label) {
  SCOPED_TRACE(label);ASSERT_EQ(actual.size(),expected.size());
  float peak=0;for(const auto value:expected){ASSERT_TRUE(std::isfinite(value));peak=std::max(peak,std::abs(value));}
  for(const auto value:actual)ASSERT_TRUE(std::isfinite(value));
  if(peak==0){for(const auto value:actual)EXPECT_EQ(value,0.F);return;}
  std::vector<float> a(actual.size()),e(expected.size());
  for(std::size_t i=0;i<a.size();++i){a[i]=actual[i]/peak;e[i]=expected[i]/peak;}
  // Same peak-normalized quantized-chain contract as the original Q27/Q24
  // components and C5 consumers. Strict local F32 operations stay separate.
  d5_gguf_test::expect_quantized_chain_matmul_close(a,e);
}
std::vector<float> attention_reference(const Model &model,std::span<const float> query,
    std::span<const float> key,std::span<const float> value,std::span<const float> gate,int rows) {
  std::vector<float> result(std::size_t(model.heads*kDepth));
  for(std::int64_t head=0;head<model.heads;++head) {
    const auto kv=head/(model.heads/kKvHeads);std::vector<double> logits(std::size_t(rows),0);
    for(int row=0;row<rows;++row)for(std::int64_t d=0;d<kDepth;++d)
      logits[std::size_t(row)]+=double(query[std::size_t(head*kDepth+d)])*key[std::size_t((row*kKvHeads+kv)*kDepth+d)]/16.;
    const auto maximum=*std::max_element(logits.begin(),logits.end());double sum=0;
    for(auto &score:logits)sum+=score=std::exp(score-maximum);
    for(std::int64_t d=0;d<kDepth;++d) {
      double total=0;for(int row=0;row<rows;++row)total+=logits[std::size_t(row)]/sum*value[std::size_t((row*kKvHeads+kv)*kDepth+d)];
      const auto i=std::size_t(head*kDepth+d);result[i]=float(total/(1+std::exp(-double(gate[i]))));
    }
  }
  return result;
}
void observe_original24_moe(Program &program,std::span<const c::ReadLease> output,
    original24_reference::ActivationCodec codec,bool full_check) {
  const auto &r=program.recipe;const auto &ports=r.moe->ports;const auto &source=*r.original24->source;
  const auto port=[&](Value value) {
    const auto found=std::find_if(r.moe_ports.begin(),r.moe_ports.end(),[&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
    if(found==r.moe_ports.end())throw std::runtime_error("actual Q24 MoE observation missing");return found->second;
  };
  const auto get=[&](Value value){return typed<float>(output[port(value)]);};
  const auto matrix=[&](full24::Role role) {
    const auto &spec=full24::spec(role);return original24_reference::PackedMatrix{source.bytes(role),std::size_t(spec.n),std::size_t(spec.k),spec.native};
  };
  const moe_reference::Parameters parameters{source.bytes(full24::Role::kRouter),source.bytes(full24::Role::kSharedRouter),
      {matrix(full24::Role::kSharedGate),matrix(full24::Role::kSharedUp),matrix(full24::Role::kSharedDown)}};
  const auto integers=[&](Value value){return typed<std::int32_t>(output[port(value)]);};
  const auto expert=[&](std::size_t leg,std::int32_t global) {
    const auto value=static_cast<full24::Leg>(leg);const auto &spec=full24::spec(full24::expert_role(value));
    return original24_reference::PackedMatrix{source.expert_bytes(value,global),std::size_t(spec.n),std::size_t(spec.k),spec.native};
  };
  moe_reference::observe(parameters,ports,get,integers,expert,codec,full_check,program.original_full_values);
  ASSERT_FALSE(::testing::Test::HasFailure());
  const auto ids=integers(ports.ids),mapping=integers(ports.map);
  ASSERT_TRUE(program.supply);ASSERT_EQ(program.supply->episodes,std::size_t(program.original_episodes)+1);
  ASSERT_FALSE(program.supply->selections.empty());
  EXPECT_EQ(mapping,std::vector<std::int32_t>(program.supply->selections.back().map.begin(),program.supply->selections.back().map.end()));
  for(const auto global:ids)EXPECT_TRUE(std::binary_search(program.supply->selections.back().globals.begin(),program.supply->selections.back().globals.end(),global));
}
void observe(Program &program,const State &state,const c::StateVersion &from,
             std::span<const c::ReadLease> output) {
  const auto &r=program.recipe;const auto &model=r.model;
  const bool full_check=(r.original||r.original24)&&!program.original_full_checked;
  const auto codec=program.cuda_backend?original_reference::ActivationCodec::kCudaMmvqQ8_1:original_reference::ActivationCodec::kCpuAvx2;
  const auto get=[&](std::size_t port){return typed<float>(output[port]);};
  const auto original_projection=[&](full::Role role,std::span<const float> actual,std::span<const float> input,
                                    std::span<const std::size_t> extra=std::span<const std::size_t>{}) {
    const auto &spec=full::spec(role);
    const auto passed=original_reference::expect_projection(actual,r.original->source->bytes(role),std::size_t(spec.n),std::size_t(spec.k),
        spec.native,input,codec,std::string(spec.name).c_str(),full_check,extra);
    if(passed&&full_check)program.original_full_values+=actual.size();
    return passed;
  };
  const auto original24_projection=[&](full24::Role role,std::span<const float> actual,std::span<const float> input,
                                      std::span<const std::size_t> extra=std::span<const std::size_t>{}) {
    const auto &spec=full24::spec(role);
    const auto passed=original24_reference::expect_projection(actual,r.original24->source->bytes(role),std::size_t(spec.n),std::size_t(spec.k),
        spec.native,input,codec,std::string(spec.name).c_str(),full_check,extra);
    if(passed&&full_check)program.original_full_values+=actual.size();return passed;
  };
  const auto cursor=typed<std::int32_t>(state.member(from,kCursor)).at(0),position=typed<std::int32_t>(state.member(from,kPosition)).at(0);
  const auto token=typed<std::int32_t>(state.member(from,kPending)).at(0);
  const auto old_hidden=typed<float>(state.member(from,kHidden)),embedding=get(r.embedding);
  if(r.original24) {
    ASSERT_TRUE(original24_reference::expect_embedding(embedding,r.original24->source->bytes(full24::Role::kEmbedding),
        std::size_t(model.hidden),std::size_t(kVocabulary),token));
    program.original_pending.push_back(token);
  } else if(r.original) {
    ASSERT_TRUE(original_reference::expect_embedding(embedding,r.original->source->bytes(full::Role::kEmbedding),
        std::size_t(model.hidden),std::size_t(kVocabulary),token));
    program.original_pending.push_back(token);
  } else {
    const auto embedding_first=r.embedding_bank->decoded.begin()+std::ptrdiff_t((token%fixture::prototypes)*model.hidden);
    EXPECT_EQ(embedding,std::vector<float>(embedding_first,embedding_first+model.hidden));
  }
  numeric::expect_close(get(r.hn),sem::oracle::rms_norm_rows(old_hidden,r.hidden_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  numeric::expect_close(get(r.en),sem::oracle::rms_norm_rows(embedding,r.embedding_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  auto joined=get(r.en);const auto hn=get(r.hn);joined.insert(joined.end(),hn.begin(),hn.end());EXPECT_EQ(get(r.joined),joined);
  if(r.original24)ASSERT_TRUE(original24_projection(full24::Role::kProjection,get(r.eh),joined));
  else if(r.original) {
    ASSERT_TRUE(original_reference::expect_projection(get(r.eh),r.original_input->projection,std::size_t(model.hidden),
        std::size_t(2*model.hidden),GGML_TYPE_Q6_K,joined,codec,"blk.64.nextn.eh_proj.weight",full_check));
    if(full_check)program.original_full_values+=std::size_t(model.hidden);
  } else quantized(get(r.eh),r.eh_reference(joined),"actual input boundary -> original/generated EH");
  numeric::expect_close(get(r.nx),sem::oracle::rms_norm_rows(get(r.eh),r.attention_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  const auto nx=get(r.nx);
  if(r.original24) {
    ASSERT_TRUE(original24_projection(full24::Role::kQuery,get(r.qg),nx));
    ASSERT_TRUE(original24_reference::expect_projection(get(r.key),r.original_kv->key,1024,8192,GGML_TYPE_Q5_K,nx,codec,"original Q24 key",full_check));
    ASSERT_TRUE(original24_reference::expect_projection(get(r.value),r.original_kv->value,1024,8192,GGML_TYPE_Q5_K,nx,codec,"original Q24 value",full_check));
    if(full_check)program.original_full_values+=2048;
  } else if(r.original) {
    ASSERT_TRUE(original_projection(full::Role::kQuery,get(r.qg),nx));
    ASSERT_TRUE(original_projection(full::Role::kKey,get(r.key),nx));
    ASSERT_TRUE(original_projection(full::Role::kValue,get(r.value),nx));
  } else {
    quantized(get(r.qg),r.qg_reference(nx),"query/gate projection");
    quantized(get(r.key),r.key_reference(nx),"original/generated K projection");
    quantized(get(r.value),r.value_reference(nx),"original/generated V projection");
  }
  const auto qg=get(r.qg);std::vector<float> query(std::size_t(model.heads*kDepth)),gate(query.size());
  for(std::int64_t head=0;head<model.heads;++head)for(std::int64_t d=0;d<kDepth;++d) {
    const auto out=std::size_t(head*kDepth+d),in=std::size_t(head*2*kDepth+d);query[out]=qg[in];gate[out]=qg[in+std::size_t(kDepth)];
  }
  EXPECT_EQ(get(r.gate),gate);
  query=sem::oracle::rms_norm_rows(query,r.query_scale,kDepth,1e-6F);
  numeric::expect_close(get(r.query),cpu_c5_qwen_attention::rotate(query,position),8e-5F,4e-5F);
  const auto normalized_key=sem::oracle::rms_norm_rows(get(r.key),r.key_scale,kDepth,1e-6F);
  numeric::expect_close(get(r.rotated_key),cpu_c5_qwen_attention::rotate(normalized_key,position),8e-5F,4e-5F);
  for(std::size_t entry=0;entry<2;++entry) {
    auto expected=read(state.member(from,entry));
    const auto fresh=read(output[entry==kKey?r.rotated_key:r.value]);
    const auto row_bytes=std::size_t(kKvHeads*kDepth)*sizeof(float);
    std::copy(fresh.begin(),fresh.end(),expected.begin()+std::ptrdiff_t(std::size_t(cursor)*row_bytes));
    EXPECT_EQ(read(output[r.state_ports[entry]]),expected)<<"complete KV, exact prior rows and NaN tail";
  }
  const auto keys=get(r.state_ports[kKey]),values=get(r.state_ports[kValue]);
  if(r.original24) {
    numeric::expect_close(get(r.attended),attention_reference(model,get(r.query),keys,values,gate,cursor+1),8e-5F,4e-5F);
    ASSERT_TRUE(original24_projection(full24::Role::kOutput,get(r.oproj),get(r.attended)));
  } else if(r.original) {
    numeric::expect_close(get(r.attended),attention_reference(model,get(r.query),keys,values,gate,cursor+1),8e-5F,4e-5F);
    ASSERT_TRUE(original_projection(full::Role::kOutput,get(r.oproj),get(r.attended)));
  } else {
    quantized(get(r.attended),attention_reference(model,get(r.query),keys,values,gate,cursor+1),"finite valid-only full-history GQA and q gate");
    quantized(get(r.oproj),r.output_reference(get(r.attended)),"attention output projection");
  }
  auto residual=get(r.eh);const auto out=get(r.oproj);
  for(std::size_t i=0;i<residual.size();++i)residual[i]+=out[i];
  numeric::expect_close(get(r.residual),residual,1e-6F,1e-6F);
  numeric::expect_close(get(r.ffn_input),sem::oracle::rms_norm_rows(get(r.residual),r.ffn_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  if(r.original24) {observe_original24_moe(program,output,codec,full_check);ASSERT_FALSE(::testing::Test::HasFailure());}
  else if(r.original) {
    const auto actual_gate=get(r.dense_ffn_ports[0]),actual_up=get(r.dense_ffn_ports[1]),activation=get(r.dense_ffn_ports[2]);
    ASSERT_TRUE(original_projection(full::Role::kFfnGate,actual_gate,get(r.ffn_input)));
    ASSERT_TRUE(original_projection(full::Role::kFfnUp,actual_up,get(r.ffn_input)));
    numeric::expect_close(activation,nextn::gated(actual_gate,actual_up),8e-5F,4e-5F);
    ASSERT_TRUE(original_projection(full::Role::kFfnDown,get(r.ffn_output),activation));
  } else quantized(get(r.ffn_output),r.ffn_reference(get(r.ffn_input)),model.moe?"top10 routed plus gated shared MoE":"Q27 dense SwiGLU");
  auto post=get(r.residual);const auto ffn=get(r.ffn_output);for(std::size_t i=0;i<post.size();++i)post[i]+=ffn[i];
  numeric::expect_close(get(r.post_ffn),post,1e-6F,1e-6F);
  const auto hidden=get(r.state_ports[kHidden]);
  numeric::expect_close(hidden,sem::oracle::rms_norm_rows(get(r.post_ffn),r.head_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  EXPECT_EQ(typed<std::int32_t>(output[r.state_ports[kCursor]]),std::vector<std::int32_t>{cursor+1});
  EXPECT_EQ(typed<std::int32_t>(output[r.state_ports[kPosition]]),std::vector<std::int32_t>{position+1});
  if(r.original||r.original24) {
    const auto logits=get(r.logits),scores=get(r.head_score);
    const auto predicted=typed<std::int32_t>(output[r.state_ports[kPending]]);
    ASSERT_EQ(logits.size(),std::size_t(kVocabulary));ASSERT_EQ(scores.size(),1u);ASSERT_EQ(predicted.size(),1u);
    ASSERT_TRUE(original_reference::expect_greedy(logits,scores[0],predicted[0]));
    // Always include the actual stable top4 rows in the later bounded dot
    // checks. Selection still comes exclusively from the Graph's full-V TopK.
    std::array<std::size_t,4> candidates{};
    std::vector<std::size_t> order(logits.size());std::iota(order.begin(),order.end(),0);
    std::partial_sort(order.begin(),order.begin()+std::ptrdiff_t(candidates.size()),order.end(),[&](auto a,auto b){
      return logits[a]>logits[b]||(logits[a]==logits[b]&&a<b);
    });
    std::copy_n(order.begin(),candidates.size(),candidates.begin());
    if(r.original24)ASSERT_TRUE(original24_projection(full24::Role::kHead,logits,hidden,candidates));
    else ASSERT_TRUE(original_projection(full::Role::kHead,logits,hidden,candidates));
    if(full_check)program.original_full_head_values=logits.size();
    program.original_predictions.push_back(predicted[0]);++program.original_episodes;
    if(full_check)program.original_full_checked=true;
    return;
  }
  // Check every full-bank logit against the same matching-carrier reference,
  // and the actual TopK against the actual full vector. These observations
  // never replace the pending-ID lease consumed by the next Graph.
  float best=-std::numeric_limits<float>::infinity();std::int32_t best_id=-1;
  const auto reference=r.dot_reference?r.dot_reference(*r.head_bank,hidden):r.head_bank->dots(hidden);
  const auto peak=*std::max_element(reference.begin(),reference.end());
  const auto logits=get(r.logits),scores=get(r.head_score);
  ASSERT_EQ(logits.size(),std::size_t(kVocabulary));ASSERT_EQ(scores.size(),1u);
  std::vector<float> expected_logits(logits.size(),0.F);
  for(std::size_t vocabulary_token=0;vocabulary_token<logits.size();++vocabulary_token) {
    ASSERT_TRUE(std::isfinite(logits[vocabulary_token]));
    expected_logits[vocabulary_token]=reference[vocabulary_token%fixture::prototypes];
    if(logits[vocabulary_token]>best) {best=logits[vocabulary_token];best_id=std::int32_t(vocabulary_token);}
  }
  quantized(logits,expected_logits,"matching-carrier full-V generated head logits");
  const std::array<float,1> wanted{peak};
  quantized(scores,wanted,"matching-carrier full-V generated head maximum");
  EXPECT_EQ(scores[0],best);
  EXPECT_EQ(typed<std::int32_t>(output[r.state_ports[kPending]]),std::vector<std::int32_t>{best_id});
  EXPECT_GE(best_id,0);EXPECT_LT(best_id,kVocabulary);
}

struct PackedHead final {
  Program program;
  std::size_t logits,scores;
  std::array<std::size_t,2> pending;
  std::optional<std::size_t> alternate;
  std::size_t matmuls;
  std::string provider;
};
PackedHead prepare_packed_head(const Model &model,const orig::ReadonlyRole &head,
    c::Context &context,const c::StorageOwner &owner,bool cuda,bool with_alternate=false) {
  Recipe recipe{.model=model,.fragment={.profile=model.profile,.region=0x5157454e484d3201ULL}};
  auto &fragment=recipe.fragment;
  const auto first=fragment.input(sem::dense({1,model.hidden}));
  const auto second=fragment.input(sem::dense({1,model.hidden}));
  const auto joined=fragment.one(c::Operation(c::Concat{.axis=0}),{first,second});
  const auto head_value=external(recipe,head);
  const auto logits=fragment.one(c::Operation(c::MatMul{.accumulation_type=c::DataType::kFloat32}),{joined,head_value});
  const auto logits_port=expose(recipe,logits);
  const auto winner=fragment.append(c::Operation(c::TopK{.count=1,.stable=true}),{logits},2);
  const auto scores_port=expose(recipe,winner[0]);
  std::array<std::size_t,2> pending_ports;
  for(std::size_t row=0;row<pending_ports.size();++row) {
    const auto sliced=fragment.one(c::Operation(take(c::View::slice(0,std::int64_t(row),1),"M2 pending row slice")),{winner[1]});
    pending_ports[row]=expose(recipe,core::reshape(fragment,sliced,{1}));
  }
  std::optional<std::size_t> alternate_port;
  if(with_alternate) {
    const auto two=fragment.append(c::Operation(c::TopK{.count=2,.stable=true}),{logits},2);
    const auto row=fragment.one(c::Operation(take(c::View::slice(0,0,1),"K1 alternate first row")),{two[1]});
    const auto alternate=fragment.one(c::Operation(take(c::View::slice(1,1,1),"K1 alternate second candidate")),{row});
    alternate_port=expose(recipe,core::reshape(fragment,alternate,{1}));
  }
  auto batched=Program::create(std::move(recipe),context,owner,cuda,true);
  const auto &graph=batched.logical.graph;
  const auto observer=take(graph.producer(batched.logical.outputs[logits_port]),"M2 full logits Copy");
  if(take(graph.operation_kind(observer),"M2 logits observer kind")!=c::OperationKind::kCopy)
    throw std::runtime_error("M2 full logits must have independent caller storage");
  const auto full_logits=take(graph.node_input(observer,0),"M2 actual full logits");
  const auto projection=take(graph.producer(full_logits),"M2 actual full head");
  const auto projection_input=take(graph.node_input(projection,0),"M2 actual two-row head input");
  const auto concatenate=take(graph.producer(projection_input),"M2 actual hidden-row concatenation");
  std::size_t matmuls=0;
  for(std::size_t node_index=0;node_index<graph.node_count();++node_index)
    matmuls+=take(graph.operation_kind(take(graph.node_id(node_index),"M2 logical node")),"M2 logical node kind")==c::OperationKind::kMatMul;
  const auto operation=take(graph.operation(projection),"M2 actual projection operation");
  const auto *matmul=operation.get_if<c::MatMul>();
  if(matmuls!=1||!matmul||matmul->accumulation_type!=c::DataType::kFloat32||
      take(graph.value_description(full_logits),"M2 logits description")!=sem::dense({2,kVocabulary})||
      take(graph.value_description(projection_input),"M2 activation description")!=sem::dense({2,model.hidden})||
      take(graph.node_input(projection,1),"M2 exact original head operand")!=batched.logical.constants.at(0)||
      take(graph.constant_description(0),"M2 original head description")!=head.description||
      take(graph.operation_kind(concatenate),"M2 concatenate operation")!=c::OperationKind::kConcat||
      take(graph.node_input(concatenate,0),"M2 actual first tap")!=batched.logical.inputs.at(0)||
      take(graph.node_input(concatenate,1),"M2 actual second tap")!=batched.logical.inputs.at(1))
    throw std::runtime_error("M2 head must be one complete original-bank MatMul on two actual hidden rows");
  const auto &bound_head=batched.recipe.external.at(0).role;
  const auto original_view=take(head.lease.view(),"M2 once-bound original head view");
  const auto bound_view=take(bound_head.lease.view(),"M2 actual bound head view");
  if(bound_head.name!=head.name||bound_head.owner.ref()!=owner.ref()||
      original_view.resource()!=bound_view.resource()||original_view.native_handle()!=bound_view.native_handle()||
      original_view.offset()!=bound_view.offset()||original_view.size()!=bound_view.size()||head.lease.generation()!=bound_head.lease.generation())
    throw std::runtime_error("M2 head must retain the same original readonly bank and owner");
  std::size_t selected_steps=0;std::string selected_provider;
  for(std::size_t step=0;step<batched.compiled.report.step_count();++step) {
    const auto selected=take(batched.compiled.report.step(step),"M2 actual compiled step");
    for(std::size_t index=0;index<selected.node_count;++index)
      if(take(batched.compiled.report.step_node(step,index),"M2 selected logical node")==projection) {
        ++selected_steps;selected_provider=selected.provider.name;
#if defined(HYLE_TEST_QWEN_STATE_CPU)
        if(!cuda&&selected.provider.id!=c::ggml_cpu::kProviderId)
          throw std::runtime_error("M2 CPU numeric certificate requires its actual ggml CPU route");
#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
        if(cuda&&selected.provider.id!=c::ggml_cuda::kProviderId)
          throw std::runtime_error("M2 CUDA numeric certificate requires its actual native MMVQ route");
#endif
      }
  }
  if(selected_steps!=1)throw std::runtime_error("M2 full head needs exactly one selected provider step");

  return {std::move(batched),logits_port,scores_port,pending_ports,alternate_port,matmuls,std::move(selected_provider)};
}

void check_original_head_m2(const Program &single,c::Context &context,const c::StorageOwner &owner,
    c::Queue &queue,const std::array<c::ReadLease,2> &hidden_rows,std::size_t &additional_submissions) {
  const auto &source=single.recipe;const auto &model=source.model;
  if(bool(source.original)==bool(source.original24))throw std::runtime_error("M2 head needs exactly one authenticated original vocabulary");
  const auto &head=source.original24?source.original24->at(full24::Role::kHead):source.original->at(full::Role::kHead);
  const auto &embedding=source.original24?source.original24->at(full24::Role::kEmbedding):source.original->at(full::Role::kEmbedding);
  const auto packed_head=source.original24?source.original24->source->bytes(full24::Role::kHead):source.original->source->bytes(full::Role::kHead);
  const auto packed_embedding=source.original24?source.original24->source->bytes(full24::Role::kEmbedding):source.original->source->bytes(full::Role::kEmbedding);
  const auto codec=single.cuda_backend?original_reference::ActivationCodec::kCudaMmvqQ8_1:original_reference::ActivationCodec::kCpuAvx2;
  const std::array actual_hidden{typed<float>(hidden_rows[0]),typed<float>(hidden_rows[1])};
  for(const auto &row:actual_hidden)ASSERT_EQ(row.size(),std::size_t(model.hidden));
  ASSERT_NE(actual_hidden[0],actual_hidden[1]);

  // Both rows are genuine normalized hidden result leases from the M1 NextN
  // journey. Only their small activation matrix is concatenated; the original
  // complete packed head remains the same once-bound immutable bank.
  auto prepared=prepare_packed_head(model,head,context,owner,single.cuda_backend);
  auto &batched=prepared.program;const auto logits_port=prepared.logits,scores_port=prepared.scores;
  const auto pending_ports=prepared.pending;

  Recipe feedback_recipe{.model=model,.fragment={.profile=model.profile,.region=0x5157454e484d3202ULL}};
  auto &feedback_fragment=feedback_recipe.fragment;
  const auto embedding_value=external(feedback_recipe,embedding);
  for(std::size_t row=0;row<pending_ports.size();++row) {
    const auto pending=feedback_fragment.input(sem::dense({1},c::DataType::kInt32));
    expose(feedback_recipe,feedback_fragment.one(c::Operation(c::Gather{}),{embedding_value,pending}));
  }
  auto feedback=Program::create(std::move(feedback_recipe),context,owner,single.cuda_backend,true);
  {
    const auto result=batched.execute_inputs(queue,hidden_rows);
    const auto actual_logits=typed<float>(result[logits_port]);
    const auto actual_scores=typed<float>(result[scores_port]);
    ASSERT_EQ(actual_logits.size(),2*std::size_t(kVocabulary));ASSERT_EQ(actual_scores.size(),2u);
    std::array<c::ReadLease,2> actual_pending;
    std::array<std::int32_t,2> predicted;
    for(std::size_t row=0;row<pending_ports.size();++row) {
      actual_pending[row]=result[pending_ports[row]];
      const auto ids=typed<std::int32_t>(actual_pending[row]);ASSERT_EQ(ids.size(),1u);predicted[row]=ids[0];
      const auto values=std::span(actual_logits).subspan(row*std::size_t(kVocabulary),std::size_t(kVocabulary));
      ASSERT_TRUE(original_reference::expect_greedy(values,actual_scores[row],predicted[row]));
      // Two host row references observe one native M2 MatMul, not two M1
      // executions. The pinned native M2 MMVQ uses the same per-row AQ8_1
      // quantizer/dot as M1 on this validation GPU; CPU uses AQ8_K.
      if(source.original24)ASSERT_TRUE(original24_reference::expect_projection(values,packed_head,std::size_t(kVocabulary),
          std::size_t(model.hidden),model.head.native,actual_hidden[row],codec,"actual Q24 M2 full head",true));
      else ASSERT_TRUE(original_reference::expect_projection(values,packed_head,std::size_t(kVocabulary),
          std::size_t(model.hidden),model.head.native,actual_hidden[row],codec,"actual Q27 M2 full head",true));
    }
    const auto retained_logits=read(result[logits_port]);
    const auto embedded=feedback.execute_inputs(queue,actual_pending);
    for(std::size_t row=0;row<embedded.size();++row) {
      ASSERT_TRUE(original_reference::expect_embedding(typed<float>(embedded[row]),packed_embedding,
          std::size_t(model.hidden),std::size_t(kVocabulary),predicted[row]));
      auto pending_reader=actual_pending[row];EXPECT_FALSE(pending_reader.try_write());
    }
    EXPECT_EQ(read(result[logits_port]),retained_logits);
    for(std::size_t row=0;row<hidden_rows.size();++row)EXPECT_EQ(typed<float>(hidden_rows[row]),actual_hidden[row]);
  }
  EXPECT_EQ(batched.live_output_blocks(),0u);EXPECT_EQ(batched.active_output_uses(),0u);
  EXPECT_EQ(feedback.live_output_blocks(),0u);EXPECT_EQ(feedback.active_output_uses(),0u);
  additional_submissions+=batched.native_submissions()+feedback.native_submissions();
  EXPECT_EQ(batched.native_submissions(),1u);EXPECT_EQ(feedback.native_submissions(),1u);
  ::testing::Test::RecordProperty("packed_head_m2_rows",2);
  ::testing::Test::RecordProperty("packed_head_m2_matmuls",int(prepared.matmuls));
  ::testing::Test::RecordProperty("packed_head_m2_full_reference_values",std::to_string(2*std::size_t(kVocabulary)));
  ::testing::Test::RecordProperty("packed_head_m2_pending_feedback_rows",2);
  ::testing::Test::RecordProperty("packed_head_m2_submissions",int(batched.native_submissions()+feedback.native_submissions()));
  ::testing::Test::RecordProperty("packed_head_m2_provider",prepared.provider);
  ::testing::Test::RecordProperty("packed_head_m2_scope","one full packed M2 projection of two actual M1 normalized hidden leases; both actual row-ID leases feed original embedding Gather; no two-token NextN/target equivalence or TPS claim");
}

c::StateVersion initial(State &state,const Model &model,const c::StorageOwner &owner) {
  std::array<c::ReadLease,kResources> values;
  for(std::size_t entry=0;entry<2;++entry) {
    std::vector<float> cache(std::size_t(kCapacity*kKvHeads*kDepth));
    for(std::size_t i=0;i<cache.size();++i)cache[i]=i<2*std::size_t(kKvHeads*kDepth)
        ?float(int((i*7+entry*13)%31)-15)/32.F:std::bit_cast<float>(std::uint32_t(0x7fc00001u+entry));
    values[entry]=upload(owner,sem::bytes(cache));
  }
  values[kHidden]=upload(owner,sem::bytes(d5_gguf_test::activation(model.hidden,3)));
  values[kPending]=upload(owner,sem::bytes(std::vector<std::int32_t>{3}));
  values[kCursor]=upload(owner,sem::bytes(std::vector<std::int32_t>{2}));
  values[kPosition]=upload(owner,sem::bytes(std::vector<std::int32_t>{37}));
  return state.import(values);
}
void run(const Model &model,std::span<const orig::ReadonlyRole> originals,
    const orig::q27::Data *q27_data,const orig::q24::Data *q24_data,
    c::Context &context,const c::StorageOwner &owner,bool cuda,
    std::shared_ptr<const full::Roles> original={},std::shared_ptr<const full24::Roles> original24={},
    std::shared_ptr<ExpertSupply> expert_supply={}) {
  const bool complete=bool(original)||bool(original24);
  if(model.moe) {
    ASSERT_EQ(model.profile->artifact_repository,orig::q24::kIdentity.repository);
    ASSERT_EQ(model.profile->artifact_revision,orig::q24::kIdentity.revision);ASSERT_EQ(model.profile->variant,orig::q24::kIdentity.variant);
  } else {
    ASSERT_EQ(model.profile->artifact_repository,orig::q27::kIdentity.repository);
    ASSERT_EQ(model.profile->artifact_revision,orig::q27::kIdentity.revision);ASSERT_EQ(model.profile->variant,orig::q27::kIdentity.variant);
  }
  const auto native_reference_submissions=std::make_shared<NativeReferenceCount>();
  DotReference dot_reference;
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
  if(cuda&&!complete)dot_reference=[native_reference_submissions](const fixture::Bank &bank,std::span<const float> input) {
    const auto values=cuda_sidecar_quant_reference::catalogue_dots(
        bank.type,bank.k,bank.packed,bank.decoded,input,false);
    if(ggml_is_quantized(bank.type))++native_reference_submissions->submissions;
    return values;
  };
#endif
  auto program=Program::create(build(model,owner,originals,q27_data,q24_data,std::move(dot_reference),original,original24),context,owner,cuda,false,expert_supply);
  auto state=State::create(model,owner,program.output_root_bytes);auto queue=take(context.create_queue(),"one original complete NextN queue");
  std::size_t additional_submissions=0;
  {
    const auto base=initial(state,model,owner);
    const auto base_image=image(state,base);
    const auto first_outputs=program.execute(queue,state,base);observe(program,state,base,first_outputs);ASSERT_FALSE(::testing::Test::HasFailure());
    const auto first=state.candidate(base,program.recipe,first_outputs);
    const auto first_image=image(state,first);
    // Real pending ID, normalized hidden, entire KV and absolute position all
    // come from the first Graph. No observer vector is uploaded for step two.
    const auto second_outputs=program.execute(queue,state,first);observe(program,state,first,second_outputs);ASSERT_FALSE(::testing::Test::HasFailure());
    const auto second=state.candidate(first,program.recipe,second_outputs);
    const auto second_image=image(state,second);
    std::array<c::StateHead,3> heads;
    for(auto &head:heads)head=take(c::StateHead::create(state.store,base),"independent actual acceptance head");
    const std::array<c::StateVersion,3> prefixes{base,first,second};
    // Failure after staging a genuine K result cannot publish a mismatched V,
    // hidden, pending token or cursor. Every head still names complete base.
    {
      auto failed=take(state.store.begin(base),"failed whole-prefix draft");
      check(failed.replace(state.entries[kKey],first_outputs[program.recipe.state_ports[kKey]]),"stage genuine K candidate");
      const auto bad=take(first_outputs[program.recipe.state_ports[kValue]].subview(0,sizeof(float)),"genuine wrong-extent V reader");
      EXPECT_TRUE(failed.replace(state.entries[kValue],bad).IsInvalidArgument());
      check(failed.cancel(),"cancel unpublishable complete prefix");
      for(const auto &head:heads)EXPECT_TRUE(take(head.current(),"unchanged complete head").identity()==base.identity());
    }
    // accept0 preserves base exactly, accept1 excludes the second complete
    // generation, accept2 publishes both consumed inputs. This finite selector
    // is explicit; it does not claim original target/natural acceptance.
    for(std::size_t accepted=1;accepted<heads.size();++accepted)
      check(heads[accepted].publish(base.identity(),prefixes[accepted]),"one atomic complete accepted-prefix publication");
    EXPECT_TRUE(heads[1].publish(base.identity(),second).IsUnavailable());
    EXPECT_TRUE(image(state,take(heads[0].current(),"rejected-all head"))==base_image);
    EXPECT_TRUE(image(state,take(heads[1].current(),"accepted1 head"))==first_image);
    EXPECT_TRUE(image(state,take(heads[2].current(),"accepted2 head"))==second_image);
    std::array<c::StateVersion,3> continued;
    std::array<Image,3> continued_images;
    for(std::size_t accepted=0;accepted<heads.size();++accepted) {
      SCOPED_TRACE(accepted);
      const auto from=take(heads[accepted].current(),"ACTUAL accepted head for next step");
      const auto values=program.execute(queue,state,from);observe(program,state,from,values);ASSERT_FALSE(::testing::Test::HasFailure());
      continued[accepted]=state.candidate(from,program.recipe,values);
      check(heads[accepted].publish(from.identity(),continued[accepted]),"publish actual branch continuation");
      continued_images[accepted]=image(state,continued[accepted]);
      EXPECT_TRUE(image(state,base)==base_image);EXPECT_TRUE(image(state,first)==first_image);EXPECT_TRUE(image(state,second)==second_image);
      for(std::size_t i=0;i<=accepted;++i)EXPECT_TRUE(image(state,continued[i])==continued_images[i]);
    }
    // Same immutable plans and actual old heads replay exactly, while the
    // accepted2 branch alone advances its complete cursor/position to5/40.
    EXPECT_TRUE(continued_images[0]==first_image);EXPECT_TRUE(continued_images[1]==second_image);
    EXPECT_EQ(typed<std::int32_t>(state.member(continued[2],kCursor)),std::vector<std::int32_t>{5});
    EXPECT_EQ(typed<std::int32_t>(state.member(continued[2],kPosition)),std::vector<std::int32_t>{40});
    if(complete) {
      ASSERT_EQ(program.original_pending.size(),5u);ASSERT_EQ(program.original_predictions.size(),5u);
      const std::vector<std::int32_t> actual_feedback{3,program.original_predictions[0],3,program.original_predictions[0],program.original_predictions[1]};
      EXPECT_EQ(program.original_pending,actual_feedback);
      EXPECT_EQ(program.original_predictions[2],program.original_predictions[0]);
      EXPECT_EQ(program.original_predictions[3],program.original_predictions[1]);
      ASSERT_TRUE(program.original_full_checked);EXPECT_EQ(program.original_episodes,5u);
      check_original_head_m2(program,context,owner,queue,
          {first_outputs[program.recipe.state_ports[kHidden]],second_outputs[program.recipe.state_ports[kHidden]]},additional_submissions);
      ASSERT_FALSE(::testing::Test::HasFailure());
    }
    for(const auto &version:{base,first,second,continued[0],continued[1],continued[2]})
      for(std::size_t i=0;i<kResources;++i)EXPECT_FALSE(state.member(version,i).try_write());
  }
  check(state.store.collect(),"retire all complete NextN versions");
  EXPECT_EQ(state.store.stats().versions,0u);EXPECT_EQ(state.store.stats().drafts,0u);
  EXPECT_EQ(program.live_output_blocks(),0u);EXPECT_EQ(program.active_output_uses(),0u);
  EXPECT_EQ(program.submissions,5u);
  for(const auto &binding:program.recipe.external) {
    auto reader=binding.role.lease;EXPECT_FALSE(reader.try_write());
  }
  ::testing::Test::RecordProperty("backend",cuda?"ordinary CUDA Graph":"ordinary CPU Graph");
  ::testing::Test::RecordProperty("actual_submissions",int(program.native_submissions()+additional_submissions));
  ::testing::Test::RecordProperty("logical_nextn_steps",int(program.submissions));
  ::testing::Test::RecordProperty("quantized_reference",cuda?
      "existing original-native CUDA integration oracle with matching activation codec; independent original-role F64/decoded and strict F32 local gates retained":
      "unchanged CPU C5 native-codec dots; independent original-role F64/decoded and strict F32 local gates retained");
  if(complete) {
    ::testing::Test::RecordProperty("quantized_reference",original24?(cuda?
        "independent original Q4_K/Q5_K/Q6_K/Q8_0 bytes with actual F32 input and fixed native MMVQ Q8_1 integer-minimum correction; no MMQ or native reference submissions":
        "independent original Q4_K/Q5_K/Q6_K/Q8_0 bytes with actual F32 input and fixed native AVX2 activation codecs; no native reference submissions"):cuda?
        "independent original Q4_K/Q6_K/Q8_0 bytes with actual F32 input and bounded native MMVQ Q8_1 codec/strict-fast division envelope; no native reference submissions":
        "independent original Q4_K/Q6_K/Q8_0 bytes with actual F32 input and fixed native AVX2 Q8_K/Q8_0 codec; no native reference submissions");
    ::testing::Test::RecordProperty("original_role_count",original24?22:17);
    ::testing::Test::RecordProperty("original_role_bytes",std::to_string(original24?full24::kOriginalBytes+11535360ULL:full::kOriginalBytes+43048960ULL));
    ::testing::Test::RecordProperty("original_first_full_projection_values",std::to_string(program.original_full_values));
    ::testing::Test::RecordProperty("original_first_full_head_values",std::to_string(program.original_full_head_values));
    ::testing::Test::RecordProperty("original_prediction_embedding_observations",int(program.original_episodes));
    ::testing::Test::RecordProperty("original_shared_bank_capacity_bytes",std::to_string(original24?full24::kStaticBytes+11535360ULL:full::kOriginalBytes+43048960ULL));
    ::testing::Test::RecordProperty("original_feedback",std::to_string(program.original_pending.at(0))+","+
        std::to_string(program.original_pending.at(1))+","+std::to_string(program.original_pending.at(2))+","+
        std::to_string(program.original_pending.at(3))+","+std::to_string(program.original_pending.at(4)));
  }
  ::testing::Test::RecordProperty("complete_draft_resources",6);
  ::testing::Test::RecordProperty("full_vocabulary",int(kVocabulary));
  ::testing::Test::RecordProperty("head_matmuls",1);
  if(original24) {
    ASSERT_TRUE(expert_supply);EXPECT_EQ(expert_supply->episodes,5u);EXPECT_EQ(expert_supply->selections.size(),5u);
    EXPECT_EQ(program.native_submissions(),10u);
    ::testing::Test::RecordProperty("resident_expert_capacity",10);
    ::testing::Test::RecordProperty("expert_domain",512);
    ::testing::Test::RecordProperty("resident_slots",2);
    ::testing::Test::RecordProperty("resident_slot_bytes",std::to_string(expert_supply->layout().slot_bytes()));
    ::testing::Test::RecordProperty("expert_supply_scope","original compressed bytes plus I32 generation map; slot capacities/API upload accounting are not measured physical VRAM or bus traffic");
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
    if(cuda)check(expert_supply->cuda->close(),"close retired Q24 expert upload slots after every Invocation reset");
#endif
  }
  if(!complete)::testing::Test::RecordProperty("original_role_bytes",model.moe?11535360:43048960);
  ::testing::Test::RecordProperty("scope",original24?
      "Q24 MAIN UD-IQ4_XS all20 original blk92 NextN roles plus independent original fullV embedding/head; full512 expert domain/actual Top10 original selected experts supplied as compressed E10 banks; two ordinary Graph phases keep actual activations/state leases; complete prefix0/1/2 and eachhead continuation; fixture initial target hidden/history and explicit acceptance remain external, no92-layer target/natural acceptance/quality/TPS claim":original?
      "Q27 MAIN UD-Q4_K_M all15 original blk64 NextN roles plus original untied fullV embedding/head; actual pending/normalized hidden/fullKV/cursor/position prefix0/1/2 and eachhead continuation; fixture initial target hidden/history and explicit acceptance lengths remain external; no complete64-layer target, natural acceptance, quality or TPS claim":model.moe?
      "Q24 MAIN UD-IQ4_XS original blk92 K/V/knorm inside complete generated-parameter MoE NextN; generated8-resident expert mapping,shared embedding/head; actual pending/hidden/fullKV/cursor/position prefix0/1/2 and eachhead continuation; no original512-expert target or natural acceptance claim":
      "Q27 MAIN UD-Q4_K_M original blk64 EH/enorm/hnorm inside complete generated-parameter dense NextN; generated embedding and distinct-codec fullVhead; actual pending/hidden/fullKV/cursor/position prefix0/1/2 and eachhead continuation; no complete64-layer target or natural acceptance claim");
}

enum TargetEntry:std::size_t {kTargetKey,kTargetValue,kTargetCursor,kTargetPosition,kTargetRaw,kTargetTap,kTargetResources};
struct TargetPlan final {
  Program program;
  std::shared_ptr<const target_roles::Bound> parameters;
  std::shared_ptr<const target24_roles::Bound> parameters24;
  target_model::TargetResult result;
  std::optional<target24_model::Result> result24;
  std::vector<std::pair<Value,std::size_t>> observed;
  std::array<std::size_t,kTargetResources> members;
  bool full_checked=false;
  std::size_t full_projection_values=0;
  std::size_t role_count=target_roles::kRoles,source_bytes=target_roles::kOriginalBytes;
  std::size_t port(Value value) const {
    const auto found=std::find_if(observed.begin(),observed.end(),[&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
    if(found==observed.end())throw std::runtime_error("original target observation missing");return found->second;
  }
  std::array<c::ReadLease,kTargetResources> state(std::span<const c::ReadLease> output) const {
    std::array<c::ReadLease,kTargetResources> result_values;
    for(std::size_t entry=0;entry<result_values.size();++entry)result_values[entry]=output[members[entry]];return result_values;
  }
};
TargetPlan prepare_target(std::shared_ptr<const target_roles::Bound> parameters,c::Context &context,
    const c::StorageOwner &owner,bool cuda) {
  if(!parameters||!parameters->source)throw std::runtime_error("original target63 needs its authenticated parameters");
  Recipe recipe{.model=q27,.fragment={.profile=q27.profile,.region=0x5157454e54363301ULL}};auto &f=recipe.fragment;
  const auto input=f.input(sem::dense({1,q27.hidden}));
  const auto old_key=f.input(descriptions(q27)[kKey]),old_value=f.input(descriptions(q27)[kValue]);
  const auto cursor=f.input(sem::dense({1},c::DataType::kInt32)),position=f.input(sem::dense({1},c::DataType::kInt32));
  const auto role=[&](target_roles::Role value){return external(recipe,parameters->at(value));};
  const target_model::TargetParameters supplied{role(target_roles::Role::kAttentionNorm),role(target_roles::Role::kQuery),
      role(target_roles::Role::kKey),role(target_roles::Role::kValue),role(target_roles::Role::kQueryNorm),role(target_roles::Role::kKeyNorm),
      role(target_roles::Role::kOutput),role(target_roles::Role::kPostNorm),role(target_roles::Role::kFfnGate),role(target_roles::Role::kFfnUp),
      role(target_roles::Role::kFfnDown),role(target_roles::Role::kTargetNorm)};
  const auto frequency=f.constant(sem::dense({32}),sem::bytes(text_frequencies(q27)));
  TargetPlan plan;plan.parameters=std::move(parameters);
  plan.result=target_model::append_target(f,input,old_key,old_value,cursor,position,frequency,supplied,
      {q27.hidden,q27.heads,kKvHeads,kDepth,64,1e-6F,0.0625F});
  const auto expose_value=[&](Value value) {
    const auto found=std::find_if(plan.observed.begin(),plan.observed.end(),[&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
    if(found!=plan.observed.end())return found->second;
    const auto port=expose(recipe,value);plan.observed.push_back({value,port});return port;
  };
  plan.result.ports.visit_values([&](Value &value){(void)expose_value(value);});
  plan.members={expose_value(plan.result.key),expose_value(plan.result.value),expose_value(increment(f,cursor)),
      expose_value(increment(f,position)),expose_value(plan.result.raw_post_ffn),expose_value(plan.result.normalized_tap)};
  plan.program=Program::create(std::move(recipe),context,owner,cuda,true);
  const auto &graph=plan.program.logical.graph;
  const auto actual=[&](Value value) {
    const auto copy=take(graph.producer(plan.program.logical.outputs[plan.port(value)]),"target actual observer");
    if(take(graph.operation_kind(copy),"target observer kind")!=c::OperationKind::kCopy)throw std::runtime_error("target outputs need independent caller storage");
    return take(graph.node_input(copy,0),"target actual observed predecessor");
  };
  const auto constant=[&](target_roles::Role value) {
    const auto &expected=plan.parameters->at(value);
    const auto found=std::find_if(plan.program.recipe.external.begin(),plan.program.recipe.external.end(),[&](const auto &entry){return entry.role.name==expected.name;});
    if(found==plan.program.recipe.external.end()||found->role.description!=expected.description||found->role.owner.ref()!=owner.ref())
      throw std::runtime_error("target lost original constant identity/owner");
    const auto a=take(found->role.lease.view(),"target actual constant"),b=take(expected.lease.view(),"target original constant");
    if(a.resource()!=b.resource()||a.native_handle()!=b.native_handle()||a.offset()!=b.offset()||a.size()!=b.size()||
        found->role.lease.generation()!=expected.lease.generation())throw std::runtime_error("target copied or replaced an original readonly bank");
    return plan.program.logical.constants[found->constant];
  };
  const auto &ports=plan.result.ports;
  struct Projection final {target_roles::Role role;Value output,input;};
  const std::array projections{Projection{target_roles::Role::kQuery,ports.qg,ports.nx},
      Projection{target_roles::Role::kKey,ports.key,ports.nx},Projection{target_roles::Role::kValue,ports.value,ports.nx},
      Projection{target_roles::Role::kOutput,ports.oproj,ports.attended},Projection{target_roles::Role::kFfnGate,ports.ffn_gate,ports.ffn_input},
      Projection{target_roles::Role::kFfnUp,ports.ffn_up,ports.ffn_input},Projection{target_roles::Role::kFfnDown,ports.ffn_down,ports.ffn_activation}};
  for(const auto &expected:projections) {
    const auto node=take(graph.producer(actual(expected.output)),"target original projection");
    const auto operation=take(graph.operation(node),"target actual projection operation");const auto *matmul=operation.get_if<c::MatMul>();
    auto input_value=take(graph.node_input(node,0),"target projection actual input");
    if(expected.role==target_roles::Role::kOutput) {
      const auto flatten=take(graph.producer(input_value),"target attended flatten");
      const auto view=take(graph.operation(flatten),"target flatten operation");const auto *reshape=view.get_if<c::View>();
      if(!reshape||reshape->kind()!=c::ViewKind::kReshape)throw std::runtime_error("target O must flatten its actual attended heads");
      input_value=take(graph.node_input(flatten,0),"target actual attended heads");
    }
    if(!matmul||matmul->accumulation_type!=c::DataType::kFloat32||input_value!=actual(expected.input)||
        take(graph.node_input(node,1),"target actual original RHS")!=constant(expected.role))
      throw std::runtime_error("target projection must consume its actual predecessor and distinct original codec bank");
    std::size_t selected_count=0;std::string provider;
    for(std::size_t step=0;step<plan.program.compiled.report.step_count();++step) {
      const auto selected=take(plan.program.compiled.report.step(step),"target actual projection route");
      for(std::size_t index=0;index<selected.node_count;++index)
        if(take(plan.program.compiled.report.step_node(step,index),"target selected logical projection")==node) {
          ++selected_count;provider=selected.provider.name;
#if defined(HYLE_TEST_QWEN_STATE_CPU)
          if(!cuda&&selected.provider.id!=c::ggml_cpu::kProviderId)throw std::runtime_error("target AQ reference requires its fixed CPU ggml route");
#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
          if(cuda&&selected.provider.id!=c::ggml_cuda::kProviderId)throw std::runtime_error("target AQ reference requires its fixed CUDA MMVQ route");
#endif
        }
    }
    if(selected_count!=1)throw std::runtime_error("target projection needs exactly one actual compiled route");
    ::testing::Test::RecordProperty(std::string("target_provider_")+std::string(target_roles::spec(expected.role).name),provider);
  }
  const auto target_norm=take(graph.producer(actual(ports.tap)),"target global output norm");
  const auto norm_operation=take(graph.operation(target_norm),"target final norm operation");const auto *rms=norm_operation.get_if<c::RmsNorm>();
  if(!rms||rms->epsilon!=1e-6F||take(graph.node_input(target_norm,0),"target final norm input")!=actual(ports.post_ffn)||
      take(graph.node_input(target_norm,1),"target original global norm gamma")!=constant(target_roles::Role::kTargetNorm))
    throw std::runtime_error("Qwen target h_nextn must follow its distinct original global output_norm");
  return plan;
}
TargetPlan prepare_target24(std::shared_ptr<const target24_roles::Bound> parameters,std::shared_ptr<ExpertSupply> supply,
    c::Context &context,const c::StorageOwner &owner,bool cuda) {
  if(!parameters||!parameters->source||!supply||supply->source.owner.get()!=parameters->source.get())
    throw std::runtime_error("target91 needs its own original readonly expert source");
  for(std::size_t leg=0;leg<3;++leg) {
    const auto role=target24_roles::expert_role(static_cast<full24::Leg>(leg));
    const auto raw=parameters->source->bytes(role);const auto view=parameters->source->view(role);
    if(supply->source.banks[leg].data()!=raw.data()||supply->source.banks[leg].size()!=raw.size()||
        supply->source.views[leg].native_handle()!=view.native_handle()||supply->source.views[leg].offset()!=view.offset()||
        supply->layout().source(leg)!=target24_roles::description(role))
      throw std::runtime_error("target91 expert supply must retain the exact original IQ4 bank mapping");
  }
  Recipe recipe{.model=q24,.fragment={.profile=q24.profile,.region=0x5157454e54393101ULL}};auto &f=recipe.fragment;
  const auto input=f.input(sem::dense({1,q24.hidden}));
  const auto old_key=f.input(descriptions(q24)[kKey]),old_value=f.input(descriptions(q24)[kValue]);
  const auto cursor=f.input(sem::dense({1},c::DataType::kInt32)),position=f.input(sem::dense({1},c::DataType::kInt32));
  const auto role=[&](target24_roles::Role value){return external(recipe,parameters->at(value));};
  const target_model::TargetAttentionParameters attention{role(target24_roles::Role::kAttentionNorm),role(target24_roles::Role::kQuery),
      role(target24_roles::Role::kKey),role(target24_roles::Role::kValue),role(target24_roles::Role::kQueryNorm),role(target24_roles::Role::kKeyNorm),
      role(target24_roles::Role::kOutput),role(target24_roles::Role::kPostNorm)};
  const moe24::Parameters feed_forward{role(target24_roles::Role::kRouter),role(target24_roles::Role::kSharedRouter),
      {role(target24_roles::Role::kSharedGate),role(target24_roles::Role::kSharedUp),role(target24_roles::Role::kSharedDown)},
      {f.input(supply->layout().resident(0)),f.input(supply->layout().resident(1)),f.input(supply->layout().resident(2))},
      f.input(supply->layout().map_description())};
  const auto gamma=role(target24_roles::Role::kTargetNorm);
  const auto frequency=f.constant(sem::dense({32}),sem::bytes(text_frequencies(q24)));
  TargetPlan plan;plan.parameters24=std::move(parameters);plan.role_count=target24_roles::kRoles;plan.source_bytes=target24_roles::kOriginalBytes;
  plan.result24=target24_model::append(f,input,old_key,old_value,cursor,position,frequency,{attention,feed_forward,gamma},
      {q24.hidden,q24.heads,kKvHeads,kDepth,64,1e-6F,0.0625F});
  recipe.moe=plan.result24->feed_forward;
  const auto expose_value=[&](Value value) {
    const auto found=std::find_if(plan.observed.begin(),plan.observed.end(),[&](const auto &entry){return entry.first.ordinal()==value.ordinal();});
    if(found!=plan.observed.end())return found->second;
    const auto port=expose(recipe,value);plan.observed.push_back({value,port});return port;
  };
  plan.result24->visit_values([&](Value &value){(void)expose_value(value);});
  plan.members={expose_value(plan.result24->attention.key),expose_value(plan.result24->attention.value),expose_value(increment(f,cursor)),
      expose_value(increment(f,position)),expose_value(plan.result24->raw_post_ffn),expose_value(plan.result24->normalized_tap)};
  plan.program=Program::create(std::move(recipe),context,owner,cuda,true,std::move(supply));
  // Resolve each observation in its ACTUAL ordinary phase. The target never
  // attaches the distinct NextN92 Roles just to reuse a report or executor.
  const auto actual=[&](Value value){return plan.program.observation(plan.port(value));};
  const auto &ap=plan.result24->attention.ports;const auto &mp=plan.result24->feed_forward.ports;
  struct Projection final {target24_roles::Role role;Value output,input;};
  const std::array projections{Projection{target24_roles::Role::kQuery,ap.qg,ap.nx},Projection{target24_roles::Role::kKey,ap.key,ap.nx},
      Projection{target24_roles::Role::kValue,ap.value,ap.nx},Projection{target24_roles::Role::kOutput,ap.oproj,ap.attended},
      Projection{target24_roles::Role::kRouter,mp.logits,mp.input},Projection{target24_roles::Role::kSharedRouter,mp.shared_gate_raw,mp.input},
      Projection{target24_roles::Role::kSharedGate,mp.shared.gate,mp.input},Projection{target24_roles::Role::kSharedUp,mp.shared.up,mp.input},
      Projection{target24_roles::Role::kSharedDown,mp.shared.down,mp.shared.activation}};
  for(const auto &expected:projections) {
    const auto observed=actual(expected.output);const auto &graph=observed.program->logical.graph;
    const auto node=take(graph.producer(observed.value),"target91 actual static projection");
    const auto operation=take(graph.operation(node),"target91 projection operation");const auto *matmul=operation.get_if<c::MatMul>();
    auto input_value=take(graph.node_input(node,0),"target91 projection activation");
    if(expected.role==target24_roles::Role::kOutput) {
      const auto flatten=take(graph.producer(input_value),"target91 attended flatten");
      const auto view=take(graph.operation(flatten),"target91 attended flatten operation");const auto *reshape=view.get_if<c::View>();
      if(!reshape||reshape->kind()!=c::ViewKind::kReshape)throw std::runtime_error("target91 output must flatten its actual attended heads");
      input_value=take(graph.node_input(flatten,0),"target91 actual attended heads");
    }
    if(!matmul||matmul->accumulation_type!=c::DataType::kFloat32||input_value!=plan.program.observation_input(plan.port(expected.input),observed)||
        take(graph.node_input(node,1),"target91 original static RHS")!=plan.program.constant_operand(plan.parameters24->at(expected.role),observed,owner))
      throw std::runtime_error("target91 projection lost its actual predecessor or distinct original static bank");
    const auto provider=plan.program.selected_provider(observed,node,target24_roles::spec(expected.role).codec.has_value());
    ::testing::Test::RecordProperty(std::string("target_provider_")+std::string(target24_roles::spec(expected.role).name),provider);
  }
  const auto &boundary=plan.result24->feed_forward.boundary;
  for(std::size_t leg=0;leg<3;++leg) {
    const auto output=leg==0?mp.routed.gate:leg==1?mp.routed.up:mp.routed.down;
    const auto observed=actual(output);const auto &graph=observed.program->logical.graph;
    const auto node=take(graph.producer(observed.value),"target91 actual selected expert projection");
    const auto operation=take(graph.operation(node),"target91 actual grouped operation");
    const auto grouped=operation.custom_as<c::model_ops::GroupedMatMul>();
    auto input_value=take(graph.node_input(node,1),"target91 actual expert activation");
    if(leg<2) {
      const auto flatten=take(graph.producer(input_value),"target91 expert input reshape");
      const auto view=take(graph.operation(flatten),"target91 expert input view");const auto *reshape=view.get_if<c::View>();
      if(!reshape||reshape->kind()!=c::ViewKind::kReshape)throw std::runtime_error("target91 expert must use its actual shared activation");
      input_value=take(graph.node_input(flatten,0),"target91 shared expert activation");
    }
    const auto bank=take(graph.node_input(node,0),"target91 actual IQ4 resident bank");
    if(!grouped||bank!=plan.program.phase_input(boundary.banks[leg],observed)||
        take(graph.value_description(bank),"target91 IQ4 actual descriptor")!=plan.program.supply->layout().resident(leg)||
        input_value!=plan.program.observation_input(plan.port(leg<2?mp.input:mp.routed.activation),observed)||
        take(graph.node_input(node,2),"target91 actual local expert IDs")!=plan.program.observation_input(plan.port(mp.local_ids),observed))
      throw std::runtime_error("target91 experts require actual original IQ4 bytes and exact generation mapping");
    ::testing::Test::RecordProperty(std::string("target_expert_provider_")+std::to_string(leg),plan.program.selected_provider(observed,node,true));
  }
  const auto normalized=actual(plan.result24->normalized_tap);const auto &graph=normalized.program->logical.graph;
  const auto node=take(graph.producer(normalized.value),"target91 original global norm");
  const auto operation=take(graph.operation(node),"target91 global norm operation");const auto *rms=operation.get_if<c::RmsNorm>();
  if(!rms||rms->epsilon!=1e-6F||take(graph.node_input(node,0),"target91 global norm input")!=plan.program.observation_input(plan.port(plan.result24->raw_post_ffn),normalized)||
      take(graph.node_input(node,1),"target91 original global norm gamma")!=plan.program.constant_operand(plan.parameters24->at(target24_roles::Role::kTargetNorm),normalized,owner))
    throw std::runtime_error("target91 h_nextn must follow the distinct original global output_norm");
  return plan;
}
void observe_target(TargetPlan &plan,std::span<const c::ReadLease> input,std::span<const c::ReadLease> output) {
  ASSERT_EQ(input.size(),5u);
  const auto cursor=typed<std::int32_t>(input[3]).at(0),position=typed<std::int32_t>(input[4]).at(0);
  const auto read_value=[&](Value value){return typed<float>(output[plan.port(value)]);};
  const auto attention=[&](auto query,auto keys,auto values,auto gate,int rows){return attention_reference(plan.program.recipe.model,query,keys,values,gate,rows);};
  const auto codec=plan.program.cuda_backend?original_reference::ActivationCodec::kCudaMmvqQ8_1:original_reference::ActivationCodec::kCpuAvx2;
  if(plan.parameters24) {
    const auto integers=[&](Value value){return typed<std::int32_t>(output[plan.port(value)]);};
    target24_reference::observe(*plan.parameters24->source,*plan.result24,read_value,integers,typed<float>(input[1]),typed<float>(input[2]),cursor,position,
        codec,!plan.full_checked,attention,plan.full_projection_values);
    const auto ids=integers(plan.result24->feed_forward.ports.ids),mapping=integers(plan.result24->feed_forward.ports.map);
    ASSERT_TRUE(plan.program.supply);ASSERT_EQ(plan.program.supply->episodes,std::size_t(plan.program.submissions));
    ASSERT_FALSE(plan.program.supply->selections.empty());
    EXPECT_EQ(mapping,std::vector<std::int32_t>(plan.program.supply->selections.back().map.begin(),plan.program.supply->selections.back().map.end()));
    for(const auto global:ids)EXPECT_TRUE(std::binary_search(plan.program.supply->selections.back().globals.begin(),plan.program.supply->selections.back().globals.end(),global));
  } else target_reference::observe(*plan.parameters->source,plan.result,read_value,typed<float>(input[1]),typed<float>(input[2]),cursor,position,
      codec,!plan.full_checked,attention,plan.full_projection_values);
  EXPECT_EQ(typed<std::int32_t>(output[plan.members[kTargetCursor]]),std::vector<std::int32_t>{cursor+1});
  EXPECT_EQ(typed<std::int32_t>(output[plan.members[kTargetPosition]]),std::vector<std::int32_t>{position+1});
  if(!::testing::Test::HasFailure())plan.full_checked=true;
}
void same_state_storage(const c::ReadLease &actual,const c::ReadLease &expected) {
  const auto a=take(actual.view(),"actual whole-state lease"),b=take(expected.view(),"expected whole-state producer lease");
  EXPECT_EQ(a.resource(),b.resource());EXPECT_EQ(a.native_handle(),b.native_handle());EXPECT_EQ(a.offset(),b.offset());
  EXPECT_EQ(a.size(),b.size());EXPECT_EQ(actual.generation(),expected.generation());
}
std::vector<Bytes> whole_image(const State &state,const c::StateVersion &version) {
  std::vector<Bytes> result;for(std::size_t entry=0;entry<kResources;++entry)result.push_back(read(state.member(version,entry)));
  for(const auto entry:state.extra_entries)result.push_back(read(take(version.member(entry),"whole target state member")));return result;
}
std::vector<float> upstream_fixture(const Model &model,std::int32_t token,std::int32_t position) {
  // This remains an external input from the preceding layer (62 or90).
  // Choosing a row from the consumed ID does not compute that trained trunk.
  if(token<0||token>=kVocabulary||position<0)throw std::runtime_error("synthetic upstream boundary token/position");
  return d5_gguf_test::activation(model.hidden,101+int((std::int64_t(token)*13+position*7)%997));
}
std::vector<float> target_history(std::size_t valid,std::size_t variant) {
  std::vector<float> values(std::size_t(kCapacity*kKvHeads*kDepth));
  for(std::size_t index=0;index<values.size();++index)values[index]=index<valid*1024?
      float(int((index*7+variant*11)%31)-15)/64.F:std::bit_cast<float>(std::uint32_t(0x7fc00011u+variant));
  return values;
}
void run_original_target_verifier(Program draft,TargetPlan target,
    c::Context &context,const c::StorageOwner &owner,bool cuda) {
  const auto &model=draft.recipe.model;
  const auto &head_role=draft.recipe.original24?draft.recipe.original24->at(full24::Role::kHead):draft.recipe.original->at(full::Role::kHead);
  const auto packed_head=draft.recipe.original24?draft.recipe.original24->source->bytes(full24::Role::kHead):draft.recipe.original->source->bytes(full::Role::kHead);
  auto verifier=prepare_packed_head(model,head_role,context,owner,cuda,true);
  auto queue=take(context.create_queue(),"one target/NextN whole-state queue");
  std::array<c::ReadLease,5> warm_input{upload(owner,sem::bytes(upstream_fixture(model,2,36))),upload(owner,sem::bytes(target_history(1,2))),
      upload(owner,sem::bytes(target_history(1,3))),upload(owner,sem::bytes(std::vector<std::int32_t>{1})),
      upload(owner,sem::bytes(std::vector<std::int32_t>{36}))};
  auto warmup=target.program.execute_inputs(queue,warm_input);observe_target(target,warm_input,warmup);ASSERT_FALSE(::testing::Test::HasFailure());
  warm_input={};
  std::array<c::TensorDesc,kTargetResources> target_descriptions;
  for(std::size_t entry=0;entry<target_descriptions.size();++entry)
    target_descriptions[entry]=target.program.recipe.fragment.description(target.program.recipe.fragment.outputs[target.members[entry]]);
  std::size_t pool_bound=0;
  for(const auto *program:{&draft,&target.program,&verifier.program}) {
    if(pool_bound>std::numeric_limits<std::size_t>::max()-program->output_root_bytes)throw std::runtime_error("joint target output bound overflow");
    pool_bound+=program->output_root_bytes;
  }
  const auto codec=cuda?original_reference::ActivationCodec::kCudaMmvqQ8_1:original_reference::ActivationCodec::kCpuAvx2;
  std::size_t repairs=0,feedbacks=0,full_verifier_values=0,peak_backing=0,declared_budget=0;
  std::size_t repair_submissions=0;
  std::size_t publications=0,cancellations=0,stale_rejections=0,reseed_checks=0;
  std::array<std::size_t,2> accepted_counts{};
  bool full_verifier_checked=false;
  std::array<c::ReadLease,2> controlled_proposals;
  std::int32_t natural_proposal=-1;std::uint32_t natural_accepted=0;
  for(const int scenario:{0,1,2}) {
    SCOPED_TRACE(scenario); // natural, independently controlled match/reject.
    auto state=State::create(model,owner,pool_bound,target_descriptions);
    const auto target_member=[&](const c::StateVersion &version,TargetEntry entry) {
      return take(version.member(state.extra_entries.at(std::size_t(entry))),"actual target checkpoint member");
    };
    const auto target_snapshot=[&](const c::StateVersion &version) {
      std::array<c::ReadLease,kTargetResources> result;
      for(std::size_t entry=0;entry<result.size();++entry)result[entry]=target_member(version,static_cast<TargetEntry>(entry));return result;
    };
    {
      const auto warm_state=target.state(warmup);
      const std::array<c::ReadLease,kResources> initial_values{upload(owner,sem::bytes(target_history(2,0))),
          upload(owner,sem::bytes(target_history(2,1))),warm_state[kTargetTap],upload(owner,sem::bytes(std::vector<std::int32_t>{3})),
          warm_state[kTargetCursor],warm_state[kTargetPosition]};
      const auto base=state.import(initial_values,warm_state);const auto base_image=whole_image(state,base);
      auto head=take(c::StateHead::create(state.store,base),"one12-member target/NextN accepted Head");
      const auto reseed=[&](const c::StateVersion &from) {
        auto pending=take(state.store.begin(from),"fresh actual target-tap seed");
        check(pending.replace(state.entries[kHidden],target_member(from,kTargetTap)),"bind previous-position normalized target tap");
        ++reseed_checks;return take(pending.finalize(),"unpublished complete target-tap seed");
      };
      const auto combined=[&](const c::StateVersion &from) {
        const auto cursor=typed<std::int32_t>(state.member(from,kCursor)).at(0),position=typed<std::int32_t>(state.member(from,kPosition)).at(0);
        const auto token=typed<std::int32_t>(state.member(from,kPending)).at(0);
        if(cursor!=typed<std::int32_t>(target_member(from,kTargetCursor)).at(0)||position!=typed<std::int32_t>(target_member(from,kTargetPosition)).at(0))
          throw std::runtime_error("target/NextN token frontiers differ before execution");
        const auto before=whole_image(state,from);
        const std::array target_input{upload(owner,sem::bytes(upstream_fixture(model,token,position))),target_member(from,kTargetKey),
            target_member(from,kTargetValue),target_member(from,kTargetCursor),target_member(from,kTargetPosition)};
        const auto target_output=target.program.execute_inputs(queue,target_input);observe_target(target,target_input,target_output);
        if(::testing::Test::HasFailure())throw std::runtime_error("original target numerical gate failed before staging");
        const auto draft_output=draft.execute(queue,state,from);observe(draft,state,from,draft_output);
        if(::testing::Test::HasFailure())throw std::runtime_error("original NextN numerical gate failed before staging");
        const auto next=state.candidate(from,draft.recipe,draft_output,target.state(target_output));
        for(std::size_t entry=0;entry<kTargetResources;++entry)same_state_storage(target_member(next,static_cast<TargetEntry>(entry)),target_output[target.members[entry]]);
        EXPECT_EQ(whole_image(state,from),before);++feedbacks;
        peak_backing=std::max(peak_backing,state.store.stats().backing_bytes);
        return next;
      };
      const auto seeded=reseed(base);same_state_storage(state.member(seeded,kHidden),target_member(base,kTargetTap));
      const auto first=combined(seeded);const auto first_image=whole_image(state,first);
      c::StateVersion proposal_source=first;
      if(scenario!=0) {
        ASSERT_TRUE(controlled_proposals[std::size_t(scenario-1)]);
        auto policy=take(state.store.begin(first),"controlled actual Top1/Top2 proposal");
        check(policy.replace(state.entries[kPending],controlled_proposals[std::size_t(scenario-1)]),"actual target ID lease controls consumed proposal");
        proposal_source=take(policy.finalize(),"unpublished controlled proposal checkpoint");
        for(std::size_t entry=0;entry<kResources;++entry)if(entry!=kPending)same_state_storage(state.member(proposal_source,entry),state.member(first,entry));
      }
      const auto proposal=typed<std::int32_t>(state.member(proposal_source,kPending)).at(0);
      const auto second=combined(proposal_source);const auto second_image=whole_image(state,second);
      const std::array verifier_inputs{target_member(first,kTargetTap),target_member(second,kTargetTap)};
      const auto verified=verifier.program.execute_inputs(queue,verifier_inputs);
      const auto logits=typed<float>(verified[verifier.logits]),scores=typed<float>(verified[verifier.scores]);
      ASSERT_EQ(logits.size(),2*std::size_t(kVocabulary));ASSERT_EQ(scores.size(),2u);
      const auto alternate=typed<std::int32_t>(verified[*verifier.alternate]).at(0);
      ASSERT_GE(alternate,0);ASSERT_LT(alternate,kVocabulary);
      std::array<std::int32_t,2> target_ids;
      for(std::size_t row=0;row<2;++row) {
        const auto ids=typed<std::int32_t>(verified[verifier.pending[row]]);ASSERT_EQ(ids.size(),1u);target_ids[row]=ids[0];
        const auto values=std::span(logits).subspan(row*std::size_t(kVocabulary),std::size_t(kVocabulary));
        ASSERT_TRUE(original_reference::expect_greedy(values,scores[row],target_ids[row]));
        const std::array<std::size_t,2> selected{std::size_t(target_ids[row]),row==0?std::size_t(alternate):std::size_t(target_ids[row])};
        if(model.moe)ASSERT_TRUE(original24_reference::expect_projection(values,packed_head,std::size_t(kVocabulary),std::size_t(model.hidden),
            model.head.native,typed<float>(verifier_inputs[row]),codec,"actual target M2 full vocabulary verifier",!full_verifier_checked,selected));
        else ASSERT_TRUE(original_reference::expect_projection(values,packed_head,std::size_t(kVocabulary),std::size_t(model.hidden),
            model.head.native,typed<float>(verifier_inputs[row]),codec,"actual target M2 full vocabulary verifier",!full_verifier_checked,selected));
      }
      if(!full_verifier_checked){full_verifier_values=logits.size();full_verifier_checked=true;}
      std::array<std::size_t,2> top2{0,1};if(logits[1]>logits[0])std::swap(top2[0],top2[1]);
      for(std::size_t index=2;index<std::size_t(kVocabulary);++index) {
        if(logits[index]>logits[top2[0]]){top2[1]=top2[0];top2[0]=index;}
        else if(logits[index]>logits[top2[1]])top2[1]=index;
      }
      EXPECT_EQ(alternate,std::int32_t(top2[1]));EXPECT_NE(alternate,target_ids[0]);
      const std::uint32_t accepted=proposal==target_ids[0]?1u:0u;++accepted_counts[accepted];
      if(scenario==0) {
        controlled_proposals={verified[verifier.pending[0]],verified[*verifier.alternate]};
        natural_proposal=proposal;natural_accepted=accepted;
      } else EXPECT_EQ(accepted,scenario==1?1u:0u);
      const auto pending=verified[verifier.pending[accepted]];
      c::StateVersion accepted_version;
      if(accepted) {
        // Recursive second used draft hidden to speculate. Rebuild its row
        // with the TRUE target h[current] paired with proposal at current+1,
        // exactly the shifted-target process() cache repair, before publish.
        const auto repair_seed=reseed(proposal_source);
        same_state_storage(state.member(repair_seed,kHidden),target_member(first,kTargetTap));
        const auto repair_begin=draft.native_submissions();
        const auto repair_output=draft.execute(queue,state,repair_seed);observe(draft,state,repair_seed,repair_output);
        repair_submissions+=draft.native_submissions()-repair_begin;
        ASSERT_FALSE(::testing::Test::HasFailure());
        accepted_version=state.candidate(second,draft.recipe,repair_output,{},pending);++repairs;
        for(std::size_t entry=0;entry<kResources;++entry)
          same_state_storage(state.member(accepted_version,entry),entry==kPending?pending:repair_output[draft.recipe.state_ports[entry]]);
        for(std::size_t entry=0;entry<kTargetResources;++entry)
          same_state_storage(target_member(accepted_version,static_cast<TargetEntry>(entry)),target_member(second,static_cast<TargetEntry>(entry)));
      } else {
        auto policy=take(state.store.begin(first),"zero-draft correction keeps after-current checkpoint");
        check(policy.replace(state.entries[kPending],pending),"actual target correction pending lease");
        accepted_version=take(policy.finalize(),"whole after-current checkpoint with target correction");
        for(std::size_t entry=0;entry<kResources;++entry)if(entry!=kPending)same_state_storage(state.member(accepted_version,entry),state.member(first,entry));
        EXPECT_NE(accepted_version.identity(),base.identity());
      }
      same_state_storage(state.member(accepted_version,kPending),pending);
      EXPECT_EQ(typed<std::int32_t>(state.member(accepted_version,kCursor)).at(0),3+int(accepted));
      EXPECT_TRUE(take(head.current(),"unpublished repaired checkpoint").identity()==base.identity());
      check(head.publish(base.identity(),accepted_version),"atomic target and repaired NextN same-prefix publication");
      ++publications;
      EXPECT_TRUE(head.publish(base.identity(),second).IsUnavailable());
      ++stale_rejections;
      const auto accepted_image=whole_image(state,accepted_version);
      {
        auto cancelled=take(state.store.begin(accepted_version),"failed target-only splice");
        check(cancelled.replace(state.extra_entries[kTargetTap],target_member(second,kTargetTap)),"stage target-only producer");
        EXPECT_TRUE(cancelled.replace(state.extra_entries[kTargetKey],state.member(first,kPending)).IsInvalidArgument());
        check(cancelled.cancel(),"cancel incomplete target/NextN splice");
        ++cancellations;
      }
      EXPECT_EQ(whole_image(state,take(head.current(),"unchanged head after failed splice")),accepted_image);
      const auto continuing_seed=reseed(take(head.current(),"accepted whole prefix for continuation"));
      same_state_storage(state.member(continuing_seed,kHidden),target_member(accepted_version,kTargetTap));
      const auto continued=combined(continuing_seed);
      check(head.publish(accepted_version.identity(),continued),"publish actual target/draft continuation");
      ++publications;
      EXPECT_EQ(typed<std::int32_t>(state.member(continued,kPending)).size(),1u);
      EXPECT_EQ(whole_image(state,base),base_image);EXPECT_EQ(whole_image(state,first),first_image);EXPECT_EQ(whole_image(state,second),second_image);
      EXPECT_EQ(whole_image(state,accepted_version),accepted_image);
      for(const auto &version:{base,first,second,accepted_version,continued}) {
        for(std::size_t entry=0;entry<kResources;++entry){auto reader=state.member(version,entry);EXPECT_FALSE(reader.try_write());}
        for(const auto entry:state.extra_entries){auto reader=take(version.member(entry),"retained target reader");EXPECT_FALSE(reader.try_write());}
      }
      peak_backing=std::max(peak_backing,state.store.stats().backing_bytes);
      std::size_t initial_bound=0;
      for(const auto &desc:descriptions(model))initial_bound+=(take(desc.required_bytes(),"joint draft initial bound")+255u)/256u*256u;
      for(const auto &desc:target_descriptions)initial_bound+=(take(desc.required_bytes(),"joint target initial bound")+255u)/256u*256u;
      declared_budget=pool_bound+initial_bound;EXPECT_LE(state.store.stats().backing_bytes,declared_budget);
    }
    check(state.store.collect(),"retire complete12-member verifier checkpoints");
    EXPECT_EQ(state.store.stats().versions,0u);EXPECT_EQ(state.store.stats().drafts,0u);
  }
  controlled_proposals={};warmup.clear();
  for(const auto *program:{&draft,&target.program,&verifier.program}) {
    EXPECT_EQ(program->live_output_blocks(),0u);EXPECT_EQ(program->active_output_uses(),0u);
    if(program->supply) {
      if(program->supply->cpu) {
        EXPECT_EQ(program->supply->cpu->stats().live_blocks,0u);EXPECT_EQ(program->supply->cpu->stats().active_uses,0u);
      }
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
      if(program->supply->cuda)check(program->supply->cuda->close(),"close actual model expert slots after every ordinary phase reset");
#endif
    }
  }
  EXPECT_GT(repairs,0u);EXPECT_EQ(repairs,accepted_counts[1]);EXPECT_GT(accepted_counts[0],0u);EXPECT_GT(accepted_counts[1],0u);
  ::testing::Test::RecordProperty("actual_submissions",int(draft.native_submissions()+target.program.native_submissions()+verifier.program.native_submissions()));
  ::testing::Test::RecordProperty("target_submissions",int(target.program.native_submissions()));
  ::testing::Test::RecordProperty("nextn_submissions",int(draft.native_submissions()));
  ::testing::Test::RecordProperty("target_verifier_submissions",int(verifier.program.native_submissions()));
  ::testing::Test::RecordProperty("accepted_target_conditioned_repairs",int(repairs));
  ::testing::Test::RecordProperty("actual_accepted_kv_repair_submissions",int(repair_submissions));
  ::testing::Test::RecordProperty("accepted_zero_drafts",int(accepted_counts[0]));
  ::testing::Test::RecordProperty("accepted_one_draft",int(accepted_counts[1]));
  ::testing::Test::RecordProperty("actual_pending_embedding_feedback_checks",int(feedbacks+repairs));
  ::testing::Test::RecordProperty("whole_state_publications",int(publications));
  ::testing::Test::RecordProperty("cancelled_unpublished_drafts",int(cancellations));
  ::testing::Test::RecordProperty("rejected_stale_publishes",int(stale_rejections));
  ::testing::Test::RecordProperty("actual_target_reseed_checks",int(reseed_checks));
  ::testing::Test::RecordProperty("original_native_reference_submissions",0);
  ::testing::Test::RecordProperty("natural_k1_trials",1);::testing::Test::RecordProperty("controlled_matching_trials",1);::testing::Test::RecordProperty("controlled_rejection_trials",1);
  ::testing::Test::RecordProperty("natural_accepted_drafts",int(natural_accepted));::testing::Test::RecordProperty("natural_proposal",natural_proposal);
  ::testing::Test::RecordProperty("complete_target_draft_resources",int(std::size_t(kResources)+std::size_t(kTargetResources)));
  ::testing::Test::RecordProperty("original_target_roles",int(target.role_count));
  ::testing::Test::RecordProperty("original_target_source_bytes",std::to_string(target.source_bytes));
  ::testing::Test::RecordProperty("first_full_target_projection_values",std::to_string(target.full_projection_values));
  ::testing::Test::RecordProperty("first_full_target_verifier_values",std::to_string(full_verifier_values));
  ::testing::Test::RecordProperty("target_verifier_full_vocabulary",int(kVocabulary));
  ::testing::Test::RecordProperty("target_verifier_matmuls",int(verifier.matmuls));
  ::testing::Test::RecordProperty("target_verifier_rows",2);
  ::testing::Test::RecordProperty("target_verifier_provider",verifier.provider);
  if(model.moe) {
    ::testing::Test::RecordProperty("target_resident_slot_bytes",std::to_string(target.program.supply->layout().slot_bytes()));
    ::testing::Test::RecordProperty("nextn_resident_slot_bytes",std::to_string(draft.supply->layout().slot_bytes()));
    ::testing::Test::RecordProperty("target_expert_domain",int(target.program.supply->layout().domain()));
    ::testing::Test::RecordProperty("target_resident_capacity",int(target.program.supply->layout().capacity()));
    ::testing::Test::RecordProperty("target_resident_episodes",int(target.program.supply->episodes));
    ::testing::Test::RecordProperty("nextn_resident_episodes",int(draft.supply->episodes));
    ::testing::Test::RecordProperty("target_expert_source_codec","IQ4_XS");
    ::testing::Test::RecordProperty("nextn_expert_source_codec","Q4_K");
  }
  ::testing::Test::RecordProperty("first_full_nextn_head_values",std::to_string(draft.original_full_head_values));
  ::testing::Test::RecordProperty("state_budget_bytes",std::to_string(declared_budget));::testing::Test::RecordProperty("peak_state_backing_bytes",std::to_string(peak_backing));
  ::testing::Test::RecordProperty("scope",std::string(model.moe?
      "original Q24 MAIN target91 IQ4_XS experts and complete NextN92 Q4_K experts retain distinct original sources; layer90 input/history fixture,not92-layer target":
      "original Q27 MAIN target63 and complete NextN64 retain distinct original sources; layer62 input/history fixture,not64-layer target")+
      "; same existing original untied fullV head/embedding; targettap follows globalnorm and shifts to next-token NextN input; one M2 verifier,natural K1 and separate actualTop1/Top2 controls; accept0 keeps aftercurrent,accept1 repairs recursive draft KV with actualtargettap before12member sameHead publication; no full-model quality,natural acceptance-rate or TPS claim");
}

TEST(OriginalRoleInput, BoundedSha256AuthenticatesBlockAndPaddingBoundaries) {
  struct Case final { std::size_t bytes; const char *sha256; };
  constexpr std::array cases{
      Case{0, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},
      Case{55, "2900465fcb533e05a158fd2b3be0e5e3b03740d83060aa3580e0d98a96bf2384"},
      Case{56, "31454ff48ef36af2f08fd511bdc37d9d5855ac23e992e5ff5445cb6b7674a674"},
      Case{63, "5f6401b96532c36de4e65beec0409b69b1d181864c8009b7a04f43e5d56350d1"},
      Case{64, "94eb5de4943613fd048dc93393ab06877405faa39c11f53e9386083339833e7e"},
      Case{65, "fc518669b6eb4b4dd91827ecacef86689c725bd5bab888fd3b26dbb196eec954"},
      Case{4097, "042a02b55ba342cdd30322331816b6e4bca073f33bdb80149dc74a6f949802f4"},
  };
  for (const auto &entry : cases) {
    std::vector<std::byte> payload(entry.bytes);
    for (std::size_t i = 0; i < payload.size(); ++i)
      payload[i] = static_cast<std::byte>((i * 37u + 11u) & 255u);
    EXPECT_EQ(original_role_input::sha256(payload), entry.sha256) << "bytes=" << entry.bytes;
  }
  constexpr std::string_view abc = "abc";
  EXPECT_EQ(original_role_input::sha256(std::as_bytes(std::span(abc.data(), abc.size()))),
      "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
}

class QwenMtpStateConsumer:public ::testing::Test {
protected:
  static inline std::unique_ptr<const orig::q27::Data> data27;
  static inline std::unique_ptr<const orig::q24::Data> data24;
  static inline std::shared_ptr<const full::Data> data27_full;
  static inline std::shared_ptr<const full24::Data> data24_full;
  static inline std::shared_ptr<const target_roles::Data> data27_target;
  static inline std::shared_ptr<const target24_roles::Data> data24_target;
  static void SetUpTestSuite() {
    const auto path27=directory("HYLE_QWEN27_MTP_INPUT_DIR"),path24=directory("HYLE_QWEN24_MTP_KV_DIR");
    if(!path27.empty())data27=std::make_unique<const orig::q27::Data>(orig::q27::Data::load(path27));
    if(!path24.empty())data24=std::make_unique<const orig::q24::Data>(orig::q24::Data::load(path24));
    const auto complete27=directory("HYLE_QWEN27_ORIGINAL_NEXTN_DIR");
    if(!complete27.empty())data27_full=std::make_shared<const full::Data>(full::Data::load(complete27));
  }
  static bool prepare_original24_data() {
    // Only the two new complete-original cases need the17GB source. Legacy
    // regressions do not rehash/map it merely because the env remains set.
    if(data24_full)return true;
    const auto path=directory("HYLE_QWEN24_ORIGINAL_NEXTN_DIR");if(path.empty())return false;
    data24_full=std::make_shared<const full24::Data>(full24::Data::load(path));return true;
  }
  static bool prepare_original27_target() {
    if(data27_target)return true;
    const auto path=directory("HYLE_QWEN27_ORIGINAL_TARGET_DIR");if(path.empty())return false;
    data27_target=std::make_shared<const target_roles::Data>(target_roles::Data::load(path));return true;
  }
  static bool prepare_original24_target() {
    if(data24_target)return true;
    const auto path=directory("HYLE_QWEN24_ORIGINAL_TARGET_DIR");if(path.empty())return false;
    data24_target=std::make_shared<const target24_roles::Data>(target24_roles::Data::load(path));return true;
  }
  static void TearDownTestSuite(){data24_target.reset();data27_target.reset();data24_full.reset();data27_full.reset();data27.reset();data24.reset();}
};
#if defined(HYLE_TEST_QWEN_STATE_CPU)
struct SystemResource final {m::MemoryResourceRef ref() noexcept{return m::system_resource();}};
TEST_F(QwenMtpStateConsumer,CpuQ27WholeNextNPrefixPublishesAndContinues) {
  if(!data27)GTEST_SKIP()<<"Set HYLE_QWEN27_MTP_INPUT_DIR to authenticated MAIN Q27 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU storage owner");
  const auto roles=orig::q27::bind(*data27,owner);run(q27,roles,data27.get(),nullptr,context,owner,false);
}
TEST_F(QwenMtpStateConsumer,CpuQ27OriginalNextNAndVocabularyPublishesAndContinues) {
  if(!data27||!data27_full)GTEST_SKIP()<<"Set HYLE_QWEN27_MTP_INPUT_DIR and HYLE_QWEN27_ORIGINAL_NEXTN_DIR to authenticated MAIN Q27 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU storage owner");
  const auto roles=orig::q27::bind(*data27,owner);
  const auto complete=std::make_shared<const full::Roles>(full::bind(data27_full,owner));
  run(q27,roles,data27.get(),nullptr,context,owner,false,complete);
}
TEST_F(QwenMtpStateConsumer,CpuQ27OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix) {
  if(!data27||!data27_full||!prepare_original27_target())GTEST_SKIP()<<"Set original Q27 NextN directories and HYLE_QWEN27_ORIGINAL_TARGET_DIR to authenticated target63 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU target verifier context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU target verifier owner");
  const auto roles=orig::q27::bind(*data27,owner);
  const auto complete=std::make_shared<const full::Roles>(full::bind(data27_full,owner));
  const auto target=std::make_shared<const target_roles::Bound>(target_roles::bind(data27_target,owner));
  auto draft=Program::create(build(q27,owner,roles,data27.get(),nullptr,{},complete),context,owner,false);
  auto target_plan=prepare_target(target,context,owner,false);
  run_original_target_verifier(std::move(draft),std::move(target_plan),context,owner,false);
}
TEST_F(QwenMtpStateConsumer,CpuQ24WholeNextNPrefixPublishesAndContinues) {
  if(!data24)GTEST_SKIP()<<"Set HYLE_QWEN24_MTP_KV_DIR to authenticated MAIN Q24 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU storage owner");
  const auto roles=orig::q24::bind(*data24,owner);run(q24,roles,nullptr,data24.get(),context,owner,false);
}
TEST_F(QwenMtpStateConsumer,CpuQ24OriginalNextNAndVocabularyPublishesAndContinues) {
  if(!data24||!prepare_original24_data())GTEST_SKIP()<<"Set HYLE_QWEN24_MTP_KV_DIR and HYLE_QWEN24_ORIGINAL_NEXTN_DIR to authenticated MAIN Q24 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU storage owner");
  const auto roles=orig::q24::bind(*data24,owner);
  const auto complete=std::make_shared<const full24::Roles>(full24::bind(data24_full,owner));
  auto supply=std::make_shared<ExpertSupply>();supply->roles=complete;
  supply->source=expert_source(complete->source,std::array{full24::Role::kExpertGate,full24::Role::kExpertUp,full24::Role::kExpertDown});
  supply->cpu=std::make_shared<resident24::CpuSupply>(take(resident24::CpuSupply::create(owner,supply->source.descriptions),"bounded original Q24 CPU supply"));
  run(q24,roles,nullptr,data24.get(),context,owner,false,{},complete,supply);
}
TEST_F(QwenMtpStateConsumer,CpuQ24OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix) {
  if(!data24||!prepare_original24_data()||!prepare_original24_target())GTEST_SKIP()<<"Set original Q24 NextN directories and HYLE_QWEN24_ORIGINAL_TARGET_DIR to authenticated target91 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU Q24 target verifier context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU Q24 target verifier owner");
  const auto roles=orig::q24::bind(*data24,owner);
  const auto complete=std::make_shared<const full24::Roles>(full24::bind(data24_full,owner));
  const auto target=std::make_shared<const target24_roles::Bound>(target24_roles::bind(data24_target,owner));
  auto nextn_supply=std::make_shared<ExpertSupply>();nextn_supply->roles=complete;
  nextn_supply->source=expert_source(complete->source,std::array{full24::Role::kExpertGate,full24::Role::kExpertUp,full24::Role::kExpertDown});
  nextn_supply->cpu=std::make_shared<resident24::CpuSupply>(take(resident24::CpuSupply::create(owner,nextn_supply->source.descriptions),"bounded original Q24 NextN CPU supply"));
  auto target_supply=std::make_shared<ExpertSupply>();
  target_supply->source=expert_source(target->source,std::array{target24_roles::Role::kExpertGate,target24_roles::Role::kExpertUp,target24_roles::Role::kExpertDown});
  target_supply->cpu=std::make_shared<resident24::CpuSupply>(take(resident24::CpuSupply::create(owner,target_supply->source.descriptions),"bounded original Q24 target CPU supply"));
  auto draft=Program::create(build(q24,owner,roles,nullptr,data24.get(),{},{},complete),context,owner,false,false,nextn_supply);
  auto target_plan=prepare_target24(target,target_supply,context,owner,false);
  run_original_target_verifier(std::move(draft),std::move(target_plan),context,owner,false);
}

#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
TEST_F(QwenMtpStateConsumer,CudaQ27WholeNextNPrefixPublishesAndContinues) {
  if(!data27)GTEST_SKIP()<<"Set HYLE_QWEN27_MTP_INPUT_DIR to authenticated MAIN Q27 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA context");
  const auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual CUDA memory")),"ordinary CUDA storage owner");
  const auto roles=orig::q27::bind(*data27,owner);run(q27,roles,data27.get(),nullptr,context,owner,true);
}
TEST_F(QwenMtpStateConsumer,CudaQ27OriginalNextNAndVocabularyPublishesAndContinues) {
  if(!data27||!data27_full)GTEST_SKIP()<<"Set HYLE_QWEN27_MTP_INPUT_DIR and HYLE_QWEN27_ORIGINAL_NEXTN_DIR to authenticated MAIN Q27 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA context");
  const auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual CUDA memory")),"ordinary CUDA storage owner");
  const auto roles=orig::q27::bind(*data27,owner);
  const auto complete=std::make_shared<const full::Roles>(full::bind(data27_full,owner));
  run(q27,roles,data27.get(),nullptr,context,owner,true,complete);
}
TEST_F(QwenMtpStateConsumer,CudaQ27OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix) {
  if(!data27||!data27_full||!prepare_original27_target())GTEST_SKIP()<<"Set original Q27 NextN directories and HYLE_QWEN27_ORIGINAL_TARGET_DIR to authenticated target63 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA target verifier context");
  const auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual CUDA target verifier memory")),"ordinary CUDA target verifier owner");
  const auto roles=orig::q27::bind(*data27,owner);
  const auto complete=std::make_shared<const full::Roles>(full::bind(data27_full,owner));
  const auto target=std::make_shared<const target_roles::Bound>(target_roles::bind(data27_target,owner));
  auto draft=Program::create(build(q27,owner,roles,data27.get(),nullptr,{},complete),context,owner,true);
  auto target_plan=prepare_target(target,context,owner,true);
  run_original_target_verifier(std::move(draft),std::move(target_plan),context,owner,true);
}
TEST_F(QwenMtpStateConsumer,CudaQ24WholeNextNPrefixPublishesAndContinues) {
  if(!data24)GTEST_SKIP()<<"Set HYLE_QWEN24_MTP_KV_DIR to authenticated MAIN Q24 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA context");
  const auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual CUDA memory")),"ordinary CUDA storage owner");
  const auto roles=orig::q24::bind(*data24,owner);run(q24,roles,nullptr,data24.get(),context,owner,true);
}
struct SharedCudaResource final {
  std::shared_ptr<c::cuda::MemoryResource> storage;
  m::MemoryResourceRef ref() noexcept{return storage->ref();}
};
TEST_F(QwenMtpStateConsumer,CudaQ24OriginalNextNAndVocabularyPublishesAndContinues) {
  if(!data24||!prepare_original24_data())GTEST_SKIP()<<"Set HYLE_QWEN24_MTP_KV_DIR and HYLE_QWEN24_ORIGINAL_NEXTN_DIR to authenticated MAIN Q24 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA context");
  const auto device=std::make_shared<c::cuda::MemoryResource>(take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual shared CUDA memory"));
  const auto owner=take(c::StorageOwner::adopt(context,SharedCudaResource{device}),"ordinary shared CUDA storage owner");
  const auto roles=orig::q24::bind(*data24,owner);
  const auto complete=std::make_shared<const full24::Roles>(full24::bind(data24_full,owner));
  auto supply=std::make_shared<ExpertSupply>();supply->roles=complete;
  supply->source=expert_source(complete->source,std::array{full24::Role::kExpertGate,full24::Role::kExpertUp,full24::Role::kExpertDown});
  supply->cuda=std::make_shared<resident24::CudaSupply>(take(resident24::CudaSupply::create(context,owner,*device,supply->source.descriptions),"bounded original Q24 CUDA supply"));
  run(q24,roles,nullptr,data24.get(),context,owner,true,{},complete,supply);
}
TEST_F(QwenMtpStateConsumer,CudaQ24OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix) {
  if(!data24||!prepare_original24_data()||!prepare_original24_target())GTEST_SKIP()<<"Set original Q24 NextN directories and HYLE_QWEN24_ORIGINAL_TARGET_DIR to authenticated target91 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA Q24 target verifier context");
  const auto device=std::make_shared<c::cuda::MemoryResource>(take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual shared CUDA target memory"));
  const auto owner=take(c::StorageOwner::adopt(context,SharedCudaResource{device}),"ordinary shared CUDA Q24 target owner");
  const auto roles=orig::q24::bind(*data24,owner);
  const auto complete=std::make_shared<const full24::Roles>(full24::bind(data24_full,owner));
  const auto target=std::make_shared<const target24_roles::Bound>(target24_roles::bind(data24_target,owner));
  auto nextn_supply=std::make_shared<ExpertSupply>();nextn_supply->roles=complete;
  nextn_supply->source=expert_source(complete->source,std::array{full24::Role::kExpertGate,full24::Role::kExpertUp,full24::Role::kExpertDown});
  nextn_supply->cuda=std::make_shared<resident24::CudaSupply>(take(resident24::CudaSupply::create(context,owner,*device,nextn_supply->source.descriptions),"bounded original Q24 NextN CUDA supply"));
  auto target_supply=std::make_shared<ExpertSupply>();
  target_supply->source=expert_source(target->source,std::array{target24_roles::Role::kExpertGate,target24_roles::Role::kExpertUp,target24_roles::Role::kExpertDown});
  target_supply->cuda=std::make_shared<resident24::CudaSupply>(take(resident24::CudaSupply::create(context,owner,*device,target_supply->source.descriptions),"bounded original Q24 target CUDA supply"));
  auto draft=Program::create(build(q24,owner,roles,nullptr,data24.get(),{},{},complete),context,owner,true,false,nextn_supply);
  auto target_plan=prepare_target24(target,target_supply,context,owner,true);
  run_original_target_verifier(std::move(draft),std::move(target_plan),context,owner,true);
}

#endif
} // namespace
