#pragma once

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <limits>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "qwen24_original_nextn_roles.h"
#include "hyle/mem/mapping.h"

// Original MAIN Q24 UD-IQ4_XS final target91 and independent global norm.
// All512 expert rows remain mapped in their real IQ4_XS encoding. Only actual
// selected rows enter bounded resident Graph inputs; these trained roles are
// distinct from NextN92 Q4_K experts. Existing vocabulary/NextN are borrowed.
namespace qwen24_original_target_roles {
namespace original = qwen_original_mtp_roles;
namespace input = original_role_input;
namespace nextn = qwen24_original_nextn_roles;
namespace c = hyle::compute;
namespace m = hyle::mem;
inline constexpr auto &kIdentity = original::q24::kIdentity;
inline constexpr std::int64_t kHidden = 8192, kIntermediate = 2048, kVocabulary = 248320;
inline constexpr std::int32_t kExpertDomain = 512;
inline constexpr std::size_t kResidentCapacity = 10, kExpertBytes = 8912896;
inline constexpr std::size_t kOriginalBytes = 14032308224ULL;
inline constexpr std::size_t kStaticBytes = 342099968ULL;
using Leg = nextn::Leg;
inline constexpr std::int64_t kBlock = 91, kHeads = 64, kKvHeads = 4, kDepth = 256;
inline constexpr float kEpsilon = 1.0e-6F, kRopeTheta = 1.0e7F;
enum class Role : std::size_t {
  kKey, kKeyNorm, kAttentionNorm, kOutput, kQuery, kQueryNorm, kValue,
  kExpertDown, kSharedDown, kExpertGate, kRouter, kSharedRouter, kSharedGate,
  kExpertUp, kSharedUp, kPostNorm, kTargetNorm, kCount
};
inline constexpr std::size_t kRoles = static_cast<std::size_t>(Role::kCount);
struct Spec final {
  std::string_view name, file, sha256;
  std::optional<c::GgufQuantizedType> codec;
  ggml_type native;
  std::int64_t k, n, e; // k0 is a plain F32[n] norm; e512 is a mapped source bank.
  std::size_t bytes;
};
// Only real completed acquisition hashes may fill these pins. Empty rejects
// loading instead of accepting unverified or generated data.
inline constexpr std::array<Spec, kRoles> kSpecs{
    Spec{"blk.91.attn_k.weight", "attn_k.weight.q5_k", "", c::GgufQuantizedType::kQ5K, GGML_TYPE_Q5_K, 8192, 1024, 1, 5767168ULL},
    Spec{"blk.91.attn_k_norm.weight", "attn_k_norm.weight.f32", "", std::nullopt, GGML_TYPE_F32, 0, 256, 1, 1024ULL},
    Spec{"blk.91.attn_norm.weight", "attn_norm.weight.f32", "", std::nullopt, GGML_TYPE_F32, 0, 8192, 1, 32768ULL},
    Spec{"blk.91.attn_output.weight", "attn_output.weight.q5_k", "", c::GgufQuantizedType::kQ5K, GGML_TYPE_Q5_K, 16384, 8192, 1, 92274688ULL},
    Spec{"blk.91.attn_q.weight", "attn_q.weight.q5_k", "", c::GgufQuantizedType::kQ5K, GGML_TYPE_Q5_K, 8192, 32768, 1, 184549376ULL},
    Spec{"blk.91.attn_q_norm.weight", "attn_q_norm.weight.f32", "", std::nullopt, GGML_TYPE_F32, 0, 256, 1, 1024ULL},
    Spec{"blk.91.attn_v.weight", "attn_v.weight.q5_k", "", c::GgufQuantizedType::kQ5K, GGML_TYPE_Q5_K, 8192, 1024, 1, 5767168ULL},
    Spec{"blk.91.ffn_down_exps.weight", "ffn_down_exps.weight.iq4_xs", "", c::GgufQuantizedType::kIq4Xs, GGML_TYPE_IQ4_XS, 2048, 8192, 512, 4563402752ULL},
    Spec{"blk.91.ffn_down_shexp.weight", "ffn_down_shexp.weight.q6_k", "", c::GgufQuantizedType::kQ6K, GGML_TYPE_Q6_K, 2048, 8192, 1, 13762560ULL},
    Spec{"blk.91.ffn_gate_exps.weight", "ffn_gate_exps.weight.iq4_xs", "", c::GgufQuantizedType::kIq4Xs, GGML_TYPE_IQ4_XS, 8192, 2048, 512, 4563402752ULL},
    Spec{"blk.91.ffn_gate_inp.weight", "ffn_gate_inp.weight.f32", "", std::nullopt, GGML_TYPE_F32, 8192, 512, 1, 16777216ULL},
    Spec{"blk.91.ffn_gate_inp_shexp.weight", "ffn_gate_inp_shexp.weight.f32", "", std::nullopt, GGML_TYPE_F32, 8192, 1, 1, 32768ULL},
    Spec{"blk.91.ffn_gate_shexp.weight", "ffn_gate_shexp.weight.q5_k", "", c::GgufQuantizedType::kQ5K, GGML_TYPE_Q5_K, 8192, 2048, 1, 11534336ULL},
    Spec{"blk.91.ffn_up_exps.weight", "ffn_up_exps.weight.iq4_xs", "", c::GgufQuantizedType::kIq4Xs, GGML_TYPE_IQ4_XS, 8192, 2048, 512, 4563402752ULL},
    Spec{"blk.91.ffn_up_shexp.weight", "ffn_up_shexp.weight.q5_k", "", c::GgufQuantizedType::kQ5K, GGML_TYPE_Q5_K, 8192, 2048, 1, 11534336ULL},
    Spec{"blk.91.post_attention_norm.weight", "post_attention_norm.weight.f32", "", std::nullopt, GGML_TYPE_F32, 0, 8192, 1, 32768ULL},
    Spec{"output_norm.weight", "output_norm.weight.f32", "", std::nullopt, GGML_TYPE_F32, 0, 8192, 1, 32768ULL}
};
inline constexpr std::array<Role, 14> kStaticRoles{
    Role::kKey, Role::kKeyNorm, Role::kAttentionNorm, Role::kOutput,
    Role::kQuery, Role::kQueryNorm, Role::kValue, Role::kSharedDown,
    Role::kRouter, Role::kSharedRouter, Role::kSharedGate, Role::kSharedUp,
    Role::kPostNorm, Role::kTargetNorm};
inline std::size_t index(Role role) {
  const auto result = static_cast<std::size_t>(role);
  if (result >= kRoles) throw std::runtime_error("unknown original Q24 target role");
  return result;
}
inline const Spec &spec(Role role) { return kSpecs[index(role)]; }
inline Role expert_role(Leg leg) {
  switch (leg) {
  case Leg::kGate: return Role::kExpertGate;
  case Leg::kUp: return Role::kExpertUp;
  case Leg::kDown: return Role::kExpertDown;
  default: throw std::runtime_error("unknown original Q24 expert leg");
  }
}
inline c::TensorDesc description(Role role) {
  const auto &s = spec(role);
  if (s.e > 1)
    return original::detail::take(c::gguf_grouped_weight_description(*s.codec,
        c::DataType::kFloat32, s.e, s.n, s.k), "original Q24 mapped grouped source description");
  if (s.k == 0)
    return original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,
        std::array{s.n}), "original Q24 norm description");
  return s.codec ? original::detail::take(c::gguf_weight_description(*s.codec,
      c::DataType::kFloat32, s.k, s.n), "original Q24 packed matrix description") :
      original::detail::take(original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,
          std::array{s.n, s.k}), "original Q24 F32 row matrix").transposed(), "original Q24 F32 MatMul RHS");
}
inline c::TensorDesc resident_description(Leg leg) {
  const auto &s = spec(expert_role(leg));
  return original::detail::take(c::gguf_grouped_weight_description(*s.codec,
      c::DataType::kFloat32, std::int64_t(kResidentCapacity), s.n, s.k), "original Q24 resident E10 description");
}

class Data final {
 public:
  static Data load(const std::filesystem::path &directory) {
    for (const auto &s : kSpecs)
      if (s.sha256.size() != 64) throw std::runtime_error("original Q24 target role is not pinned");
    Data result;
    for (std::size_t slot = 0; slot < kRoles; ++slot) {
      const auto &s = kSpecs[slot];
      if (original::detail::take(description(static_cast<Role>(slot)).required_bytes(), "original Q24 typed extent") != s.bytes)
        throw std::runtime_error("original Q24 codec/geometry extent differs");
      const auto path = directory / std::string(s.file);
      auto mapped = original::detail::take(m::FileMapping::open(path.string().c_str()), "map original Q24 role");
      if (mapped.size() != s.bytes) throw std::runtime_error("original Q24 role extent differs: " + path.string());
      const auto raw = original::detail::take(mapped.bytes(), "original Q24 mapped bytes");
      if (input::sha256(raw) != s.sha256) throw std::runtime_error("original Q24 SHA256 differs: " + path.string());
      result.mappings_[slot] = std::move(mapped);
      if (s.k == 0) {
        auto &values = result.norms_[slot]; values.resize(std::size_t(s.n));
        for (std::size_t i = 0; i < values.size(); ++i) {
          std::uint32_t bits = 0;
          for (std::size_t byte = 0; byte < 4; ++byte)
            bits |= std::to_integer<std::uint32_t>(raw[i * 4 + byte]) << (8 * byte);
          values[i] = std::bit_cast<float>(bits);
          if (!std::isfinite(values[i])) throw std::runtime_error("original Q24 norm is nonfinite");
        }
      }
    }
    return result;
  }
  std::span<const std::byte> bytes(Role role) const {
    return original::detail::take(mappings_[index(role)].bytes(), "original Q24 mapped role bytes");
  }
  m::ConstBufferView view(Role role) const {
    return original::detail::take(mappings_[index(role)].view(), "original Q24 readonly mapped role");
  }
  std::span<const float> norm(Role role) const {
    if (spec(role).k != 0) throw std::runtime_error("original Q24 requested matrix as norm");
    return norms_[index(role)];
  }
  c::TensorDesc expert_description(Leg leg) const {
    return description(expert_role(leg));
  }
  std::span<const std::byte> expert_bytes(Leg leg, std::int32_t global) const {
    const auto range = expert_range(leg, global);
    return bytes(expert_role(leg)).subspan(range[0], range[1]);
  }
  m::ConstBufferView expert_view(Leg leg, std::int32_t global) const {
    const auto range = expert_range(leg, global);
    return original::detail::take(mappings_[index(expert_role(leg))].view(
        range[0], range[1]), "original Q24 readonly selected expert");
  }
 private:
  std::array<std::size_t, 2> expert_range(Leg leg, std::int32_t global) const {
    if (global < 0 || global >= kExpertDomain)
      throw std::runtime_error("original Q24 expert outside full source domain");
    const auto desc = expert_description(leg);
    if (desc.rank() != 3 || desc.dimensions()[0] != kExpertDomain)
      throw std::runtime_error("original Q24 expert source geometry is not canonical");
    const auto encoded_stride = desc.byte_strides()[0];
    if (encoded_stride <= 0)
      throw std::runtime_error("original Q24 expert source stride is not positive");
    const auto stride = static_cast<std::size_t>(encoded_stride);
    if (std::uint64_t(stride) != std::uint64_t(encoded_stride) ||
        std::size_t(global) > std::numeric_limits<std::size_t>::max() / stride)
      throw std::runtime_error("original Q24 expert address exceeds size_t");
    const auto offset = std::size_t(global) * stride;
    const auto source_bytes = mappings_[index(expert_role(leg))].size();
    if (offset > source_bytes || stride > source_bytes - offset)
      throw std::runtime_error("original Q24 selected expert exceeds mapped source");
    return {offset, stride};
  }

  // All borrowed original spans/views keep this Data's strong owner in Bound
  // or their reference closure. No full expert decode/expanded bank is held.
  std::array<m::FileMapping, kRoles> mappings_;
  std::array<std::vector<float>, kRoles> norms_;
};
struct Bound final {
  std::shared_ptr<const Data> source;
  std::array<original::ReadonlyRole, kStaticRoles.size()> roles;
  const original::ReadonlyRole &at(Role role) const {
    const auto found = std::find(kStaticRoles.begin(), kStaticRoles.end(), role);
    if (found == kStaticRoles.end()) throw std::runtime_error("full original Q24 expert banks are source-only; bind the actual E10 generation");
    return roles[std::size_t(found - kStaticRoles.begin())];
  }
};
inline Bound bind(std::shared_ptr<const Data> source, const c::StorageOwner &owner) {
  if (!source || !owner) throw std::runtime_error("original Q24 target needs original data and its actual storage owner");
  Bound result; result.source = std::move(source);
  for (std::size_t slot = 0; slot < kStaticRoles.size(); ++slot) {
    const auto role = kStaticRoles[slot];
    result.roles[slot] = original::detail::bind(spec(role).name, description(role),
        owner, result.source->bytes(role), &kIdentity);
  }
  return result;
}
} // namespace qwen24_original_target_roles
