"""Record the root-confirmed terminal serial process before its parallel resume."""
from pathlib import Path
from datetime import datetime,timezone
import json
import os
S=Path(__file__).resolve().parent
p=S/'original-target91/acquisition.json'
d=json.loads(p.read_text(encoding='utf-8'))
assert not d['complete'] and not d.get('parallel_role_workers')
at=datetime.now(timezone.utc).isoformat()
for request in d['requests']:
    if not request['complete'] and 'finished_utc' not in request:
        request.update(finished_utc=at,error_type='IntentionalRoleParallelization',
            error='Root stopped exact serial process43784 and confirmed session59046 terminal exit1; resume independent roles concurrently without redownloading authenticated prefixes.')
d.setdefault('acquisition_process_changes',[]).append(dict(utc=at,
    old_pid=43784,old_session=59046,old_terminal_exit=1,
    reason='Measured128MiB ranges took17-20s each; three bounded role workers reuse authenticated source files and reduce serial network waits.',
    new_script='.scratch/q24-target-verifier-20261023/fetch_target_parallel.py',
    original_role_copies_added=0,stream_buffer_bytes_per_worker=1048576))
t=p.with_suffix('.json.next')
with t.open('w',encoding='utf-8',newline='\n') as stream:
    json.dump(d,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
os.replace(t,p)
print('Recorded intentional serial-to-parallel resume after confirmed terminal process.')
