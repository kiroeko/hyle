"""Verify actual BY publication; broader MTP goal remains incomplete."""
from datetime import datetime,timezone
from pathlib import Path
import json
import sys
import zipfile
sys.dont_write_bytecode=True
import publish as p
publication=p.read(p.S/'publication.json')
for row in publication.values():p.verify(row)
evidence=p.read(p.verify(publication['evidence']));v=evidence['validation']
assert evidence['stage']=='BY' and evidence['goal_complete'] is False and v['tests']==6
assert not any(v[k] for k in ('failures','errors','skips','SDK_builds','native_CPU_builds','NVCC_builds','shaders'))
run=p.read(p.verify(v['actual_native_summary']));assert run['image']==v['image'] and run['cases']==v['cases']
p.verify(run['image']);assert p.resolve(run['process']['command'][0])==p.resolve(run['image']['path'])
plan=p.read(p.verify(evidence['artifact']['plan']))
counts=p.contracts(run);assert counts==v['graph_submissions_by_case'] and sum(counts.values())==v['graph_submissions']
assert evidence['artifact']['new_target_roles']==17 and evidence['artifact']['new_target_bytes']==14032308224
assert evidence['artifact']['payloads_archived'] is False and evidence['artifact']['extra_payload_hash_pass'] is False
with zipfile.ZipFile(p.verify(publication['archive'])) as archive:
    assert archive.testzip() is None and len(archive.namelist())==evidence['archive_items']
    assert all(Path(i.filename).suffix.lower() in p.TEXT and i.file_size<10_000_000 for i in archive.infolist())
p.protect(p.read(p.S/'before.json'))
progress=dict(utc=datetime.now(timezone.utc).isoformat(),stage='BY',stage_complete=True,goal_complete=False,
    state='The listed original Q24 target91/NextN92 K1 consumers, Q27 target/NextN and Q24 original NextN regressions passed; actual evidence published.',
    tests=6,graph_submissions=v['graph_submissions'],actual_graph_submissions_by_case=counts,failures=0,skips=0,native_checks_run=True,
    publication=publication,new_TPS=False,physical_memory_peak=False,protected_AV_tail_unchanged=True,protected_Q35_image_unchanged=True,
    scope='Original Q24 target91 IQ4_XS and NextN92 Q4_K distinct experts share original fullV banks and common12-state K1 protocol; actualtargettap/M2 pending and full accepted-proposal repair. Q27 remains checked. Layer90/62 and initial history are fixtures, not whole92/64-layer quality or workload acceptance-rate evidence.',
    next='Continue remaining confirmed target-verifier/artifact gaps and necessary checks, then final ordinary/MTP performance comparison.')
(p.S/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PUBLISHED BY',v['tests'],'cases',v['graph_submissions'],'Graphs; broader MTP remains incomplete')
