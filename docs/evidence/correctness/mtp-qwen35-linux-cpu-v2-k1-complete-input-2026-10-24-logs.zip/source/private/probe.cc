#include "engine/models/qwen35/main.cc"
int main(int argc,char **argv){return qwen35::run(argc,argv);}
