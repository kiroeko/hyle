"""Incremental CPU endpoint proof using the existing cpu,cuda SDK, not a pure CPU SDK build."""
from pathlib import Path
import concurrent.futures,hashlib,json,os,shlex,subprocess,sys,time
R=Path('/mnt/c/public/project-hyle/hyle');W=Path('/root/hyle-scratch/compute-unified');A=W/'qwen-v2-cpu-functional-20261024';A.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def save(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def ident(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def execute(command,folder,timeout=180,env=None,trace_runtime=False):
 folder.mkdir(parents=True,exist_ok=False);save(folder/'command.json',dict(command=command,cwd=str(A),timeout=timeout));start=time.monotonic()
 with (folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
  if not trace_runtime:p=subprocess.run(command,cwd=A,stdout=out,stderr=err,env=env,timeout=timeout)
  else:
   p=subprocess.Popen(command,cwd=A,stdout=out,stderr=err,env=env);peak=0;native_seen=False;maps_path=Path('/proc')/str(p.pid)/'maps'
   while p.poll()is None:
    if time.monotonic()-start>timeout:p.kill();p.wait();raise subprocess.TimeoutExpired(command,timeout)
    try:
     status=(Path('/proc')/str(p.pid)/'status').read_text()
     for line in status.splitlines():
      if line.startswith('VmHWM:'):peak=max(peak,int(line.split()[1])*1024)
     if not native_seen:
      mappings=maps_path.read_text()
      if 'libhyle_ggml_cpu_mtp_current_v3.so'in mappings:
       (folder/'runtime-maps.log').write_text(mappings);native_seen=True
    except FileNotFoundError:pass
    time.sleep(.2)
   save(folder/'runtime-observation.json',dict(pid=p.pid,peak_RSS_sampled_bytes=peak,current_native_mapping_seen=native_seen,selected_environment={k:env[k]for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','LD_LIBRARY_PATH')}))
 result=dict(exit=p.returncode,seconds=time.monotonic()-start);save(folder/'process.json',result)
 if p.returncode:raise RuntimeError(str(folder)+' failed: '+(folder/'stderr.log').read_text()[-2500:])
 return result
base=W/'linux-current-graph';old=read(base/'compile-plan.json');link=read(base/'link-plan.json')
catalog={x['relative']:x['compiled_snapshot']for x in read(base/'final-source-identities.json')}
modules={'compute','compute_ops','compute_batch','compute_state','compute_ggml_runtime','compute_provider_ggml','compute_provider_native','compute_provider_torch_cpu','compute_provider_onednn','compute_route_cpu','compute_backend_cpu','graph','graph_batch','graph_progress','graph_route_cpu','graph_provider_onednn','container','error','mem','mem_vm','platform','platform_fs','platform_thread','sched','time'}
entries={x['source']:x for x in old['entries']if x['module']in modules}
# Current graph CPU owns one additional packed region absent from that snapshot.
ct=read(W/'linux-ct-packed-linear/compile-plan.json')
ctentries=ct['entries']if isinstance(ct,dict)else ct
for x in ctentries:
 if 'ct_packed_linear_region.cc' in x.get('source',''):
  entries['src/graph_route_cpu/ct_packed_linear_region.cc']=dict(x,source='src/graph_route_cpu/ct_packed_linear_region.cc',module='graph_route_cpu')
for module,names in {'compute_batch':['paged_append_program.cc'],'graph_batch':['paged_append.cc'],'compute_provider_native':['blockwise_w4a8.cc','ct_packed.cc','static_fp8.cc','nvfp4.cc']}.items():
 for name in names:
  source='src/'+module+'/'+name
  if source not in entries:
   recipe=next(x for x in entries.values()if x['module']==module)
   entries[source]=dict(recipe,source=source,module=module)
def flags(command,source,obj,dep,extra=()):
 args=[];skip=False
 for x in command[1:]:
  if skip:skip=False;continue
  if x in ('-o','-MF','-MT','-MQ'):skip=True;continue
  if x in ('-MMD','-MD','-c')or x.endswith(('.cc','.cpp','.c','.S'))or x.startswith('-DHYLE_GGML_CPU_PROGRAM_LIBRARY='):continue
  args.append(x)
 return [command[0],'-I'+str(R/'include'),'-I'+str(R/'src/compute'),'-I'+str(R/'src/graph'),'-I'+str(R/'src/compute_ggml_runtime'),*args,*extra,'-MMD','-MF',str(dep),'-c',str(source),'-o',str(obj)]
def compile_job(job):
 out=A/'host'/job['source'].replace('/','--');source=R/job['source'];obj=out/'unit.o';before=ident(source)
 extra=('-DHYLE_GGML_CPU_PROGRAM_LIBRARY="libhyle_ggml_cpu_mtp_current_v3.so"',)if job['source'].endswith('/cpu_program.cc')else ()
 cmd=flags(job['command'],source,obj,out/'unit.d',extra)
 for previous_out in [out,*sorted(out.parent.glob(out.name+'-attempt*'))]:
  if not (previous_out/'identity.json').exists():continue
  previous=read(previous_out/'identity.json');previous_cmd=flags(job['command'],source,previous_out/'unit.o',previous_out/'unit.d',extra)
  if previous['source']==before and previous['command']==previous_cmd and previous['object']==ident(previous_out/'unit.o'):
   print('REUSED_FRESH',job['source'],flush=True);return previous
 if out.exists():
  attempt=1
  while Path(str(out)+'-attempt'+str(attempt)).exists():attempt+=1
  out=Path(str(out)+'-attempt'+str(attempt));obj=out/'unit.o';cmd=flags(job['command'],source,obj,out/'unit.d',extra)
 result=execute(cmd,out,240);assert ident(source)==before
 record=dict(source=before,object=ident(obj),command=cmd,process=result);save(out/'identity.json',record);print('COMPILED',job['source'],flush=True);return record
def host():
 freshness={'compute_ops','compute_batch','graph_batch','compute_backend_cpu','compute_route_cpu','graph_route_cpu'}
 fresh=[];borrow=[];header_checks=[];digest_cache={}
 def header_changes(recipe):
  if recipe['source'].endswith('.S'):return [] # Original standalone assembly has no project headers; its full source hash is checked.
  command=recipe['command'];dependency=Path(command[command.index('-MF')+1])if '-MF'in command else Path(recipe['object']+'.d')
  if not dependency.exists():return ['missing dependency inventory']
  changed=[]
  for item in shlex.split(dependency.read_text().replace('\\\n',' ')):
   rel=None
   for prefix in (str(base/'source')+'/',str(R)+'/'):
    if item.startswith(prefix):rel=item[len(prefix):];break
   if rel is None and '/include/hyle/'in item:rel='include/hyle/'+item.split('/include/hyle/',1)[1]
   if rel is None or not (R/rel).is_file():continue
   if rel not in digest_cache:digest_cache[rel]=ident(R/rel)['sha256']
   prior=catalog.get(rel)
   if prior is None or prior['sha256']!=digest_cache[rel]:changed.append(rel)
  return sorted(set(changed))
 for rel,e in entries.items():
  actual=ident(R/rel);prior=catalog.get(rel)
  changed=header_changes(e)if e['module']not in freshness and prior is not None and actual['sha256']==prior['sha256']else []
  if changed:header_checks.append(dict(source=rel,changed_dependencies=changed))
  if e['module']in freshness or prior is None or actual['sha256']!=prior['sha256']or changed:fresh.append(e)
  else:
   observed=ident(e['object']);expected=next(x for x in link['current_objects']if x['path']==e['object']);assert observed==expected
   borrow.append(dict(source=actual,object=observed,source_catalog=prior))
 save(A/'host-plan.json',dict(fresh=fresh,borrowed=borrow,header_driven_refresh=header_checks,SDK_builds=0,backends_compiled='cached cpu,cuda SDK; final engine selects CPU endpoint only'))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:records=list(pool.map(compile_job,fresh))
 # Generic file IO facade and CPU loading are small current owners absent from the graph-only snapshot.
 core=next(x for x in entries.values()if x['module']=='compute')
 for rel in ('src/compute_stream/file_stream.cc','src/compute_stream/stream_sources.cc','src/compute_stream_cpu/file_stream.cc'):
  records.append(compile_job(dict(source=rel,command=core['command'])))
 save(A/'host-ready.json',dict(fresh=records,borrowed=borrow))
 print('HOST_READY',len(records),'fresh',len(borrow),'borrowed',flush=True)
def native():
 native_old=read(base/'native/compile-plan.json');avx=read(base/'native/avx2/compile-plan.json')['entries'];fresh=[]
 for tag,recipe in [('baseline',next(x for x in native_old if x['source']=='src/ggml-cpu/ops.cpp')),
                    ('avx2',next(x for x in avx if x['logical_source']=='src/ggml-cpu/ops.cpp')),
                    ('export',next(x for x in avx if x['logical_source']=='src/compute_ggml_runtime/cpu_program_export.cc'))]:
  out=A/('native-'+tag);source=R/'src/compute_ggml_runtime/cpu_program_export.cc'if tag=='export'else A/'native-source/src/ggml-cpu/ops.cpp';obj=out/'unit.o';before=ident(source)
  extra=('-I'+str(base/'source/src/compute_provider_ggml'),'-I'+str(W/'l-cuda/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-f99368c68335266b/src/ggml-cpu'))
  cmd=flags(recipe['command'],source,obj,out/'unit.d',extra);execute(cmd,out,240);assert ident(source)==before
  rec=dict(tag=tag,source=before,object=ident(obj),command=cmd);save(out/'identity.json',rec);fresh.append(rec)
 old_link=read(base/'native/avx2/link-result.json')['command'];cmd=[];skip=False
 for x in old_link:
  if skip:skip=False;continue
  if x=='-o':skip=True;continue
  if x.startswith('-Wl,-Map,'):continue
  if x.endswith('/ops.cpp.o'):x=fresh[1]['object']['path']
  if x.endswith('/cpu_program_export.cc.o'):x=fresh[2]['object']['path']
  cmd.append(x)
 image=A/'libhyle_ggml_cpu_mtp_current_v3.so';cmd+=['-Wl,-Map,'+str(A/'native-link/native.map'),'-o',str(image)]
 save(A/'native-link-plan.json',dict(command=cmd,source_records=fresh,current_mixed_manifest=ident(A/'current-mixed-manifest.json')));execute(cmd,A/'native-link',120)
 save(A/'native-ready.json',dict(records=fresh,image=ident(image),native_TUs=3,SDK_builds=0))
 print('NATIVE_READY',flush=True)
if __name__=='__main__':
 phase=sys.argv[1]
 if phase=='host':host()
 elif phase=='native':native()
 else:raise ValueError('host or native only; model requires a separately frozen source')
