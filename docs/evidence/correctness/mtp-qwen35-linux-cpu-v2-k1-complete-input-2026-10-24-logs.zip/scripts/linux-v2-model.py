from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,os,subprocess,sys
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('build',Path(__file__).with_name('build-linux-v2.py'));b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
R,A,W=b.R,b.A,b.W
F=R/'.scratch/qwen-multi-draft-20261024/geometry-cpu-check2/source'
sdk=W/'l-cpu-cuda/selected-graph/static-sdk-relocated/lib'
torch=Path('/root/.cache/hyle/dependencies/v1/sdks/torch-cpu/Linux-8dea5bcfed4b53ca0f6852517bea4b4d1f3ff1cc0c21da662e834d34af1ec824/libtorch/lib')
core=next(x for x in b.entries.values()if x['module']=='compute')
def io():
 jobs=[]
 for name in ('proactor','endpoint','operation','io_uring','io_context','tcp','udp','file','file_region','local','signal','dns'):
  jobs.append(dict(source='src/io_core/'+name+'.cc',command=[*core['command'],'-DHYLE_IO_HAS_COROUTINE_TRANSPORT=1']))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:records=list(pool.map(b.compile_job,jobs))
 b.save(A/'io-ready.json',records)
def model():
 overlay=A/'portable-source';owner=overlay/'engine/models/qwen35';owner.mkdir(parents=True,exist_ok=True)
 # One coherent private source directory: mixing two physical #pragma-once copies
 # through relative includes would define the format twice in a single TU.
 for path in (F/'engine/models/qwen35').glob('*.h'):(owner/path.name).write_bytes(path.read_bytes())
 replacements={
  'main.cc':[
   ('  cache::SamplingCursor sampling;','  cache::SamplingCursor sampling{};'),
   ('  std::shared_ptr<cache::Snapshot> next;','  std::shared_ptr<cache::Snapshot> next{};'),
   ('  hyle::container::SmallVector<c::PagedPageAppender, 32> next_tails;','  hyle::container::SmallVector<c::PagedPageAppender, 32> next_tails{};'),
   ('  std::array<c::PagedPageAppender, 2> next_draft_tails;','  std::array<c::PagedPageAppender, 2> next_draft_tails{};'),
   ('  c::BatchLayoutVersion layout;','  c::BatchLayoutVersion layout{};'),
   ('  c::BatchLayoutVersion draft_layout;','  c::BatchLayoutVersion draft_layout{};'),
   ('  std::vector<std::int32_t> verification_inputs;','  std::vector<std::int32_t> verification_inputs{};'),
   ('  std::vector<c::ReadLease> carry_prefix;','  std::vector<c::ReadLease> carry_prefix{};'),
   ('  std::string_view probe_subdirectory;','  std::string_view probe_subdirectory{};'),
   ('  std::span<const c::ReadLease> draft_log_probabilities;','  std::span<const c::ReadLease> draft_log_probabilities{};'),
   ('    for (auto &tail : session.tails) tail = {}; session.draft_tails = {};','    for (auto &tail : session.tails) tail = {};\n    session.draft_tails = {};')],
  'prepared_roles.h':[('  ModelGeometry geometry;','  ModelGeometry geometry{};')]}
 patches=[]
 for name,pairs in replacements.items():
  original=F/'engine/models/qwen35'/name;text=original.read_text()
  for before,after in pairs:
   if before in ('  c::BatchLayoutVersion layout;','  c::BatchLayoutVersion draft_layout;'):
    start=text.index('struct StepMember final {');end=text.index('\n};',start);part=text[start:end];assert part.count(before)==1;new=part.replace(before,after);text=text[:start]+new+text[end:]
   else:assert text.count(before)==1,(name,before,text.count(before));text=text.replace(before,after)
  destination=owner/name;destination.write_text(text);patches.append(dict(original=b.ident(original),modified=b.ident(destination),replacements=pairs))
 src=overlay/'probe.cc';src.write_text('#include "engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 out=A/'model-check2-portability-coherent';obj=out/'unit.o'
 args=[]
 for x in core['command']:
  if any(x.startswith('-D'+n)for n in ('HYLE_COMPUTE_CUDA','HYLE_COMPUTE_GGML_CUDA','HYLE_COMPUTE_TORCH_CUDA','HYLE_COMPUTE_FLASHINFER','HYLE_GGML_CUDA_IQ1_EXTENSIONS')):continue
  if x.startswith('-DHYLE_')and x.endswith('_BUILD'):continue
  args.append(x)
 cmd=b.flags(args,src,obj,out/'unit.d',('-I'+str(overlay),'-I'+str(F/'engine/models/qwen35'),'-I'+str(F),'-DHYLE_IO_HAS_COROUTINE_TRANSPORT=1'))
 # Freeze is owned by the model agent; verify its supplied identity before compilation.
 expected=b.read(F.parent/'sources.json');identities=[]
 for record in expected:
  path=F/record['path'].replace('\\','/');observed=b.ident(path);assert observed['sha256']==record['sha256'];identities.append(observed)
 result=b.execute(cmd,out,300)
 for item in identities:assert b.ident(item['path'])==item
 b.save(A/'model-ready.json',dict(object=b.ident(obj),command=cmd,result=result,sources=identities,portability_patches=patches,engine_backends=['cpu'],library_native_family='cached cpu,cuda GGML456 CPU endpoint; not pure CPU ffa4 SDK'))
def link():
 host=b.read(A/'host-ready.json');native=b.read(A/'native-ready.json');model=b.read(A/'model-ready.json');ios=b.read(A/'io-ready.json')
 objects=[model['object']['path']]+[x['object']['path']for x in host['fresh']+host['borrowed']+ios]
 # Assembly has a module label inherited from its preceding recipe, not consumer code.
 for e in b.old['entries']:
  if e['source'].endswith('.S'):
   observed=b.ident(e['object']);expected=next(x for x in b.link['current_objects']if x['path']==e['object']);assert observed==expected;objects.append(e['object'])
 objects.append(str(b.base/'native/ggml-alloc.c.o'));objects.append(native['records'][0]['object']['path'])
 objects=list(dict.fromkeys(objects))
 libraries=[str(sdk/('lib'+x+'.a'))for x in ('hyle_container','hyle_simd','ggml','ggml-cpu','ggml-base','dnnl','mimalloc_static')]
 cmd=['/usr/bin/g++-14','-O3','-DNDEBUG','-pthread','-Wl,--disable-new-dtags','-Wl,-rpath,'+str(A)+':'+str(torch),*objects,'-Wl,--start-group',*libraries,'-Wl,--end-group',str(torch/'libtorch.so'),str(torch/'libtorch_cpu.so'),str(torch/'libc10.so'),'-ldl','-lm','-Wl,-Map,'+str(A/'image.map'),'-o',str(A/'hyle-linux-cpu')]
 for obj in objects:assert Path(obj).is_file()
 b.save(A/'engine-link-plan.json',dict(command=cmd,objects=[b.ident(p)for p in objects],libraries=[b.ident(p)for p in libraries],SDK_builds=0,CUDA_libraries=False))
 folder=A/'engine-link';attempt=1
 while folder.exists():folder=A/('engine-link-attempt'+str(attempt));attempt+=1
 b.execute(cmd,folder,180)
 b.save(A/'engine-ready.json',dict(image=b.ident(A/'hyle-linux-cpu'),native=native['image'],model=model,CUDA_libraries=False))
 print('ENGINE_READY',flush=True)
def inputs():
 src=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original';out=A/'inputs';out.mkdir(exist_ok=True)
 original=(src/'weights.tsv').read_text();assert 'C:/Users/kiro/Downloads/'in original
 remap=original.replace('C:/Users/kiro/Downloads/','/mnt/c/Users/kiro/Downloads/')
 (out/'weights.tsv').write_text(remap);(out/'prompt.ids').write_bytes((src/'prompt.ids').read_bytes())
 b.save(A/'input-remap.json',dict(source=b.ident(src/'weights.tsv'),destination=b.ident(out/'weights.tsv'),roles=335,weight_copies=0,HTTP=0,only_path_prefix_replaced=True))
def run():
 inputs();records=[]
 env=dict(os.environ,LD_LIBRARY_PATH=str(A)+':'+str(torch),OMP_NUM_THREADS='8',MKL_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8')
 for tag,mtp,sampling in [('ordinary','off','greedy'),('mtp-K1','on','greedy'),('mtp-K1-random','on','random')]:
  cmd=[str(A/'hyle-linux-cpu'),'--inputs',str(A/'inputs'),'--capacity','256','--steps','4','--prefix-cache','off','--replay','commands','--mtp',mtp,'--sampling',sampling,'--cpu-ffn-layers','0']
  if mtp=='on':cmd+=['--mtp-max-drafts','1']
  if sampling=='random':cmd+=['--temperature','1','--top-k','40','--top-p','0.9','--seed','424242']
  folder=A/'runs'/tag;attempt=1
  while folder.exists():folder=A/'runs'/(tag+'-attempt'+str(attempt));attempt+=1
  result=b.execute(cmd,folder,240,env,trace_runtime=True)
  output=json.loads((folder/'stdout.log').read_text());records.append(dict(name=tag,folder=str(folder),process=result,output=output,image=b.ident(A/'hyle-linux-cpu')))
  b.save(A/'functional-results.json',dict(cases=records,scope='Linux CPU endpoint of existing cpu,cuda SDK',HTTP=0,weight_copies=0,SDK_builds=0))
  print('RAN',tag,flush=True)
phase=sys.argv[1]
{'io':io,'model':model,'link':link,'run':run}[phase]()
