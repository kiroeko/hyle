from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,zipfile
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('build',Path(__file__).with_name('build-linux-v2.py'));b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
R,A=b.R,b.A
facts=b.read(A/'functional-results.json');ready=b.read(A/'engine-ready.json');host=b.read(A/'host-ready.json');native=b.read(A/'native-ready.json');ios=b.read(A/'io-ready.json')
assert len(facts['cases'])==3
assert b.ident(ready['image']['path'])==ready['image'] and b.ident(native['image']['path'])==native['image']
summary=[]
for case in facts['cases']:
 o=case['output'];folder=Path(case['folder']);observation=b.read(folder/'runtime-observation.json');maps=(folder/'runtime-maps.log').read_text()
 assert case['process']['exit']==0 and o['backend']=='cpu'and o['original_device_weight_bytes']==0
 assert o['generated_tokens']==4 and o['visible_tokens']==157 and o['prefill_target_rows']==154
 assert observation['current_native_mapping_seen'] and str(A/'libhyle_ggml_cpu_mtp_current_v3.so')in maps
 assert not any(x in maps.lower()for x in ('libcuda.','libcudart.','libcublas.','libtorch_cuda.','libc10_cuda.'))
 assert all(x['known_peak_bytes']<=x['limit_bytes']for x in o['workspace_domains'])
 if o['sampling']=='greedy':assert o['generated_ids']==[71093,12305,198,464]
 if o['mtp']:assert o['draft_frontier']==157 and o['draft_lag']==0 and o['committed_target_rows']==157
 if o['sampling']=='random':assert o['sampling_draw_cursor']==5 and o['generated_ids']==[71093,12305,198,727]
 summary.append(dict(name=case['name'],generated_ids=o['generated_ids'],target_rows=o['committed_target_rows'],draft_frontier=o.get('draft_frontier'),draft_lag=o.get('draft_lag'),sampling_draw_cursor=o['sampling_draw_cursor'],host_weight_bytes=o['original_host_weight_bytes'],device_weight_bytes=o['original_device_weight_bytes'],known_workspace=o['workspace_domains'],native_private_unknown=o['native_execution_private_bytes_unknown'],runtime=observation))
diagnostics=[]
for command in (['ldd',str(A/'hyle-linux-cpu')],['ldd',str(A/'libhyle_ggml_cpu_mtp_current_v3.so')],['nm','-D','--defined-only',str(A/'libhyle_ggml_cpu_mtp_current_v3.so')]):
 p=subprocess.run(command,text=True,capture_output=True,timeout=20);assert p.returncode==0
 output=p.stdout if command[0]=='ldd'else '\n'.join(x for x in p.stdout.splitlines()if 'hyle_ggml_cpu_program_v3'in x or 'gdn_output_scale_contract'in x)
 assert 'not found'not in output
 diagnostics.append(dict(command=command,exit=p.returncode,stdout=output,stderr=p.stderr))
b.save(A/'final-runtime-checks.json',dict(cases=summary,diagnostics=diagnostics,source_only_portability_changes=['Explicit default initialization in main/prepared_roles/Graph append aggregates.','Split misleading same-line for/if statements without changing control flow.'],
 manual_closure_drift=['Old host objects were rejected by the genuine provider-version gate; refresh uses actual GNU.d project-header hashes as well as source hashes.','Current mixed CPU native ops plus descriptor-v3 export are rebuilt against the matching source-derived manifest; no fake contract or version symbol.'],
 limits=['CPU-only executable and endpoint reuse a cpu,cuda SDK whose GGML peer is456172ec; this is not a pure-CPU ffa4 SDK proof.','Frozen geometry-cpu-check2 plus the listed equivalent GCC fixes; later MTP0 source preflight is not represented.','Only P154+4 C256 N1R1 ordinary greedy/K1 greedy/K1 random; not multi-K, multi-session, checkpoints, cancel/failure or all quantized models.','Functional checks, not repeated fair performance comparison or complete task quality.','Graph known workspace is finite, shared cache request limit and execution shared tracking are not capped here; native private memory remains unknown and no physical total-memory cap is claimed.']))
files={}
def add(label,path):
 path=Path(path);assert path.is_file();files[label]=path
for rel in ('host-plan.json','host-ready.json','io-ready.json','native-ready.json','native-link-plan.json','engine-link-plan.json','engine-ready.json','model-ready.json','input-remap.json','functional-results.json','final-runtime-checks.json','current-mixed-manifest.json'):
 add('metadata/'+rel,A/rel)
for x in host['fresh']+ios+native['records']:
 folder=Path(x['object']['path']).parent
 for filename in ('command.json','process.json','stdout.log','stderr.log','identity.json'):
  if(folder/filename).exists():add('commands/'+folder.relative_to(A).as_posix()+'/'+filename,folder/filename)
for folder in (A/'model-check2-portability-coherent',A/'engine-link-attempt2'):
 if not folder.exists():continue
 for path in folder.iterdir():
  if path.suffix in ('.json','.log'):add('commands/'+folder.name+'/'+path.name,path)
for case in facts['cases']:
 folder=Path(case['folder'])
 for path in folder.iterdir():
  if path.suffix in ('.json','.log'):add('runs/'+case['name']+'/'+path.name,path)
for path in (A/'portable-source').rglob('*'):
 if path.is_file():add('source/private/'+path.relative_to(A/'portable-source').as_posix(),path)
for path in (A/'native-source').rglob('*'):
 if path.is_file():add('source/native/'+path.relative_to(A/'native-source').as_posix(),path)
for rel in ('src/graph_batch/batch.cc','src/graph_batch/paged_append.cc','src/compute_ggml_runtime/cpu_program_export.cc','src/compute_ggml_runtime/gated_delta_scale.h'):
 add('source/product/'+rel,R/rel)
for rel in ('weights.tsv','prompt.ids'):add('inputs/'+rel,A/'inputs'/rel)
for filename in ('build-linux-v2.py','linux-v2-model.py','publish-linux-v2.py'):add('scripts/'+filename,Path(__file__).with_name(filename))
for rel in ('model-check2/stderr.log','host/src--graph_batch--paged_append.cc/stderr.log','runs/ordinary-attempt1/stderr.log'):
 add('diagnostics/'+rel,A/rel)
name='mtp-qwen35-linux-cpu-v2-k1-complete-input-2026-10-24';dest=R/'docs/evidence/correctness';archive=dest/(name+'-logs.zip');record=dest/(name+'.json')
assert not archive.exists()and not record.exists()
identities=[dict(archive_path=label,**b.ident(path))for label,path in sorted(files.items())]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for label,path in sorted(files.items()):z.write(path,label)
 z.writestr('manifest.json',json.dumps(identities,indent=2)+'\n')
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for x in identities:assert hashlib.sha256(z.read(x['archive_path'])).hexdigest()==x['sha256']
report=dict(date='2026-10-24',scope='Complete original Qwen3.5-2B BF16 target and NextN input, source-derived GeometryV2, Linux CPU endpoint.',
 system='WSL Ubuntu24.04 x86_64, GCC14.2; i9-13900K; WSL33505357824B memory, not the entire Windows64GiB.',
 cases=summary,checks=dict(passed=3,failed=0,actual_v3_native_mapping_each_case=True,CUDA_runtime_mappings=False,strict_compile_flags=['-Wall','-Wextra','-Wpedantic','-Werror']),
 source=dict(base='geometry-cpu-check2',equivalent_GCC_fixes=ready['model']['portability_patches'],prepared_identity=facts['cases'][0]['output']['source_id'],native_family='cached cpu,cuda SDK GGML456172ec CPU endpoint',native_image=native['image'],current_mixed_manifest=b.ident(A/'current-mixed-manifest.json'),image=ready['image']),
 build=dict(fresh_host_TUs=len(host['fresh']),borrowed_source_and_header_checked_objects=len(host['borrowed']),fresh_IO_TUs=len(ios),fresh_native_TUs=3,successful_model_TUs=1,SDK_builds=0,SDK_copies=0,weight_copies=0,HTTP=0),
 boundaries=b.read(A/'final-runtime-checks.json')['limits'],archive=b.ident(archive))
b.save(record,report);print(json.dumps(dict(record=str(record),archive=b.ident(archive),cases=summary),indent=2))
