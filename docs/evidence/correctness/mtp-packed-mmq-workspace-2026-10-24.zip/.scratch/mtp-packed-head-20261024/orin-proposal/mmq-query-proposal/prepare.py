"""Offline private native packed-route query; derive through the owning manifest."""
import difflib
import hashlib
import json
from pathlib import Path

S=Path(__file__).resolve().parent
R=S.parents[3]
NATIVE='src/ggml-cuda/mmq.cu'
MANIFEST='third_party/ggml_cuda_runtime/iq1-patches.json'
LOCK='cmake/HyleDependencyLock.json'
RAW=R/'.scratch/validation/cpu-final-f1/mixed-iq1/source'/NATIVE
def sha(raw): return hashlib.sha256(raw).hexdigest()
def identity(path):
    raw=path.read_bytes();return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=sha(raw))
def compose(text,edits):
    for change in edits:
        assert text.count(change['before'])==1,change['before'][:160]
        text=text.replace(change['before'],change['after'],1)
    return text
def encode(text,original):
    return text.encode().replace(b'\n',b'\r\n') if b'\r\n'in original else text.encode()
def modified(rel,change):
    old=(R/rel).read_bytes();text=old.decode().replace('\r\n','\n');new=change(text)
    assert new!=text
    return old,encode(new,old)
def replace(text,old,new):
    assert text.count(old)==1,(old[:160],text.count(old));return text.replace(old,new,1)

header=(S/'closure-header.h').read_text()
wrapper='\n\nbool ggml_cuda_should_use_mmq(enum ggml_type type, int cc, int64_t ne11, int64_t n_experts) {\n#ifdef GGML_CUDA_FORCE_CUBLAS\n    GGML_UNUSED_VARS(type, cc, ne11, n_experts);\n    return false;\n#else\n    const int id = ggml_cuda_get_device();\n    return ggml_cuda_should_use_mmq_for_device(type, cc, ne11, n_experts, ggml_cuda_info().devices[id].smpbo);\n#endif\n}\n'
manifest_before=(R/MANIFEST).read_bytes();manifest=json.loads(manifest_before)
entry=next(row for row in manifest['files']if row['path']==NATIVE)
raw=RAW.read_bytes().replace(b'\r\n',b'\n')
assert sha(raw)==entry['before_sha256']
native_before=compose(raw.decode(),entry['edits'])
assert sha(native_before.encode())==entry['after_sha256']
native_edits=[
    dict(before='#include "mmq.cuh"\n',after='#include "mmq.cuh"\n#include "mmvq.cuh"\n#include "packed_matmul_native.h"\n'),
    dict(before='bool ggml_cuda_should_use_mmq(enum ggml_type type, int cc, int64_t ne11, int64_t n_experts) {',
         after='static bool ggml_cuda_should_use_mmq_for_device(enum ggml_type type, int cc, int64_t ne11, int64_t n_experts, size_t smpbo) {'),
    dict(before='''    {
        const int    id    = ggml_cuda_get_device();
        const size_t smpbo = ggml_cuda_info().devices[id].smpbo;
        if (smpbo < 48 * 1024) {
            return false;
        }
    }
''',after='''    if (smpbo < 48 * 1024) {
        return false;
    }
'''),
    dict(before='    return (!GGML_CUDA_CC_IS_CDNA(cc)) || ne11 < MMQ_DP4A_MAX_BATCH_SIZE;\n}\n',
         after='    return (!GGML_CUDA_CC_IS_CDNA(cc)) || ne11 < MMQ_DP4A_MAX_BATCH_SIZE;\n}\n'+wrapper),
]
native_edits[0]['after'] += '#include "ggml-backend-impl.h"\n#include <atomic>\n#include <stdexcept>\n'
native_edits[1]['after'] += '\n    (void) smpbo;'
native_edits.extend([
    dict(before='static void ggml_cuda_mul_mat_q_switch_type',
         after='static bool ggml_cuda_should_use_mmq_for_device(ggml_type, int, int64_t, int64_t, size_t);\n\n'+(S/'closure-native.inc').read_text()+'\nstatic void ggml_cuda_mul_mat_q_switch_type'),
    dict(before='        ggml_backend_cuda_context & ctx, const ggml_tensor * src0, const ggml_tensor * src1, const ggml_tensor * ids, ggml_tensor * dst) {\n    GGML_ASSERT(        src1->type == GGML_TYPE_F32);', after='        ggml_backend_cuda_context & ctx, const ggml_tensor * src0, const ggml_tensor * src1, const ggml_tensor * ids, ggml_tensor * dst) {\n    hyle::compute::ggml_cuda::internal::PackedMmqPoolScope owned_scratch(ctx, src0, src1, ids, dst);\n    GGML_ASSERT(        src1->type == GGML_TYPE_F32);'),
    dict(before='        const size_t nbytes_src1_q8_1 = ne13*ne12 * ne11*ne10_padded * y_block_size/y_values_per_block +\n            ggml_cuda_mmq_get_J_max(src0->type, fallback, cc, ne11) * sizeof(block_q8_1_mmq);', after='        const size_t nbytes_src1_q8_1 = hyle_mmq_activation_bytes(\n            src0->type, cc, fallback, ne10_padded, ne11, ne12, ne13);'),
])
native_after=compose(native_before,native_edits)
entry['edits'].extend(native_edits);entry['after_sha256']=sha(native_after.encode())
changes={MANIFEST:(manifest_before,encode(json.dumps(manifest,indent=2)+'\n',manifest_before)),
         'src/compute_provider_ggml_cuda/packed_matmul_native.h':(b'',header.encode())}

def tensor_header(text):
    start=text.index('// Two cold facts from the fixed native MMVQ selector.')
    end=text.index('bool tensor_operation_supports',start)
    text=text[:start]+'''// Native device is nominated by the actual provider Context. Unknown callers
// decline the large packed exception; ordinary bounded MatMul is unchanged.
'''+text[end:]
    text=replace(text,'PackedMmvqRows packed_mmvq_rows = {}','int native_device = -1')
    return replace(text,'#include "program.h"','#include "program.h"\n#include "packed_matmul_native.h"')
changes['src/compute_provider_ggml_cuda/tensor_program.h']=modified('src/compute_provider_ggml_cuda/tensor_program.h',tensor_header)
def tensor_source(text):
    start=text.index('// The fixed native MMVQ switch covers every codec in native_quantized_type.')
    end=text.index('bool native_packed_small_batch_rhs',start)
    text=text[:start]+'''// A canonical packed bank can retain its original storage when the actual
// native device selects MMVQ, or selects MMQ with at least one legal tile.
// Both paths quantize only A; a cuBLAS/full-W decode fallback is declined.
'''+text[end:]
    assert text.count('PackedMmvqRows packed_mmvq_rows')==2
    text=text.replace('PackedMmvqRows packed_mmvq_rows','int native_device')
    text=replace(text,'''      activation.dimensions()[0] >
          packed_mmvq_rows.for_type(native_quantized_type(weight)) ||
''','')
    old='''  return canonical && *canonical == weight && native_matmul_rhs(weight) &&
         std::ranges::all_of(weight.byte_strides(), [](auto stride) {
           return stride > 0 && stride <= INT32_MAX;
         });
'''
    new='''  if (!canonical || *canonical != weight || !native_matmul_rhs(weight) ||
      !std::ranges::all_of(weight.byte_strides(), [](auto stride) {
        return stride > 0 && stride <= INT32_MAX;
      }))
    return false;
  try {
    return packed_matmul_route(native_device, native_quantized_type(weight),
        reduction, output_columns, activation.dimensions()[0]) != PackedMatmulRoute::kDeclined;
  } catch (...) {
    // A native cold-initialization failure cannot qualify an allocation.
    return false;
  }
'''
    text=replace(text,old,new)
    return replace(text,'                                    packed_mmvq_rows);','                                    native_device);')
changes['src/compute_provider_ggml_cuda/tensor_program.cc']=modified('src/compute_provider_ggml_cuda/tensor_program.cc',tensor_source)
def provider(text):
    text=replace(text,'  internal::PackedMmvqRows packed_mmvq_rows;\n','')
    old='''                // Bind K/non-K MMVQ facts once. Known Orin keeps K-quants
                // at M1 while its other mapped codecs admit M<=4. Unknown
                // device facts stay at M1; no MMQ/cuBLAS fallback is assumed.
                internal::packed_mmvq_rows_for_device(
                    environment->sm_major, environment->sm_minor),
'''
    text=replace(text,old,'')
    text=replace(text,'static_cast<Context *>(value)->packed_mmvq_rows);','static_cast<Context *>(value)->device);')
    import importlib.util
    spec=importlib.util.spec_from_file_location('closure_provider',S/'closure-provider.py')
    closure=importlib.util.module_from_spec(spec);spec.loader.exec_module(closure)
    return closure.closure_provider(text,replace)
changes['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc']=modified('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',provider)

def bounds(text):
    text=replace(text,'#include "hyle/compute/providers/ggml_cuda.h"',
                 '#include "hyle/compute/providers/ggml_cuda.h"\n#include "native_bridge.h"\n#include "packed_matmul_native.h"')
    text=text.replace('  const bool orin = environment.sm_major == 8 && environment.sm_minor == 7;',
                      '  const int native_device = c::ggml_cuda::bridge::device_index(environment.device_ordinal);')
    text=replace(text,'    std::int64_t orin_rows;','    ggml_type native;')
    for old,new in [('1042944000, 1','1042944000, GGML_TYPE_Q6_K'),('1144258560, 1','1144258560, GGML_TYPE_Q4_K'),('2161377280ULL, 4','2161377280ULL, GGML_TYPE_Q8_0')]:text=replace(text,old,new)
    text=replace(text,'''      // The source-fixed Orin MMVQ selector limits K-quants to M1, while
      // Q8_0 keeps the same M<=4 public range as other NVIDIA devices.
      if(orin && batch > head.orin_rows) {''','''      // Expectations come from the nominated native device and its actual
      // selector/tile configuration, not a copied model/device codec table.
      const auto route = c::ggml_cuda::internal::packed_matmul_route(
          native_device, head.native, head.width, vocabulary, batch);
      if(route == c::ggml_cuda::internal::PackedMatmulRoute::kDeclined) {''')
    text=replace(text,'  const std::int64_t beyond = orin ? 2 : 5;','  const std::int64_t beyond = 5;')
    text=replace(text,'  // The first row outside the uniform device-qualified MMVQ domain cannot',
                 '  // The first row outside the bounded packed small-batch domain cannot')
    text=replace(text,'''  // Native row guards handle an odd final output row. Orin's independent
  // K-quant MMVQ row limit still declines M2.''','''  // Native row guards handle an odd final output row. The packed exception
  // still requires the nominated device's actual MMVQ or legal MMQ route.''')
    return replace(text,'  if (orin) {','''  if (c::ggml_cuda::internal::packed_matmul_route(native_device, GGML_TYPE_Q4_K,
      width, vocabulary - 1, 2) == c::ggml_cuda::internal::PackedMatmulRoute::kDeclined) {''')
changes['tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc']=modified('tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc',bounds)
changes['tests/compute_provider_ggml_cuda/CMakeLists.txt']=modified('tests/compute_provider_ggml_cuda/CMakeLists.txt',lambda text:replace(text,
    '  target_include_directories(hyle_compute_provider_ggml_cuda_test PRIVATE "${HYLE_GGML_SOURCE_DIR}/src")',
    '  target_include_directories(hyle_compute_provider_ggml_cuda_test PRIVATE\n    "${HYLE_GGML_SOURCE_DIR}/src" "${HYLE_SOURCE_DIR}/src/compute_provider_ggml_cuda")'))
lock_before=(R/LOCK).read_bytes();lock=json.loads(lock_before)
dependency=next(row for row in lock['dependencies']if row['name']=='ggml_cuda_runtime_patches')
root=R/dependency['vendored']['path']
def tree(replaced):
    rows=[]
    for path in sorted(root.rglob('*'),key=lambda p:p.relative_to(root).as_posix()):
        if not path.is_file():continue
        raw=changes[MANIFEST][1]if replaced and path==R/MANIFEST else path.read_bytes()
        raw=raw.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
        rows.append(path.relative_to(root).as_posix()+'|'+sha(raw)+'\n')
    return sha(''.join(rows).encode())
assert tree(False)==dependency['vendored']['tree_sha256']
dependency['version']='hyle-ggml-cuda-resource-iq1-inference-v36'
dependency['vendored']['tree_sha256']=tree(True)
changes[LOCK]=(lock_before,encode(json.dumps(lock,indent=2)+'\n',lock_before))
patch=[];facts=[]
for rel,(old,new)in changes.items():
    for folder,data in [('before',old),('next-source',new)]:
        if folder=='before'and not old:continue
        path=S/folder/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    facts.append(dict(path=rel,before=None if not old else dict(bytes=len(old),sha256=sha(old)),after=dict(bytes=len(new),sha256=sha(new))))
    patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel if old else'/dev/null',tofile='b/'+rel))
(S/'source.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
for folder,text in [('native-before',native_before),('generated',native_after)]:
    path=S/folder/NATIVE;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8',newline='\n')
(S/'native.diff').write_text(''.join(difflib.unified_diff(native_before.splitlines(True),native_after.splitlines(True),fromfile='a/'+NATIVE,tofile='b/'+NATIVE)),encoding='utf-8',newline='\n')
result=dict(status='Unapplied complete source proposal; C++/NVCC and actual MMQ validation not run',patch=identity(S/'source.patch'),changed=facts,
    generated=identity(S/'generated'/NATIVE),raw=identity(RAW),native_diff=identity(S/'native.diff'),
    math='Original selectors, MMQ kernels, A quantization and launch optimizer remain unchanged. Ordinary native AQ sizing is factored once and used by runtime plus cold planner; original ctx.pool allocation calls are bound to a fixed Invocation-owned slice for covered nodes.',
    nominated_device='Context.device from bridge::device_index(physical ordinal); query never uses current-device selection or changes CUDA contexts.',
    guard='Canonical F32 A/Y, original packed RHS, M1..4, K%512, logical/block/byte/stride bounds remain. UINT32 encoded bytes only on MMVQ; MMQ additionally requires total encoded bytes <=INT32_MAX. Query declines native cuBLAS/no-tile paths.',
    apply_ready=False,source_complete=True,blockers=[],validation_pending=['No C++17/NVCC or host compile was run.', 'No actual MMQ execution, allocation-failure recovery/capture/concurrency validation was run.', 'No Orin hardware or real-weight MMQ numerical certificate is claimed.'],
    required_closure_plan='scratch-closure-plan.json',
    refresh=dict(native=['src/ggml-cuda/mmq.cu'],host=['src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'],test=['tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc']),
    unchanged_native_headers=['mmq.cuh','common.cuh','native_bridge.h'],new_private_header='src/compute_provider_ggml_cuda/packed_matmul_native.h',
    tests='Bounds use actual nominated native route. Independent D4/Q6_K M16 test and reference are a separate portable-owned successor, not duplicated here. Existing Q8 tail fixtures unchanged. No test has been run.',
    HTTP=0,builds=0,native_runs=0,canonical_edits=0)
result.update(
    closure_plan=identity(S/'scratch-closure-plan.json'),
    compile_commands=identity(S/'compile-commands.json'),
    independent_review='Portable independently checked backend/Invocation/stream ownership, scope/destructor ordering and actual-slot matching; no lifetime blocker found. Source inspection only.',
    canonical_unchanged=all(sha((R/row['path']).read_bytes())==row['before']['sha256'] if row['before'] else not(R/row['path']).exists() for row in facts),
    production_changed_files=len(facts),
    test_successor='Separate portable-owned nonuniform Q6_K D4 M16 reference/test; duplicate convenience fixture excluded from patch.')
assert result['canonical_unchanged']
(S/'ready.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(patch=result['patch'],files=len(facts),generated=result['generated']),indent=2))
