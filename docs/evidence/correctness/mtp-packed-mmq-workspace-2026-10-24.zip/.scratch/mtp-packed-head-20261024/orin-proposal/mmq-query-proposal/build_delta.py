"""Root-only exact two-host/one-native delta. Default is metadata inspection.

Run --execute only after root has applied/reviewed the source proposal. This
does not link, run any fixture, fetch anything or rebuild/copy the SDK.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def require(row):
    actual = identity(row['path'])
    if any(actual[key] != row[key] for key in ('bytes', 'sha256')):
        raise ValueError('Changed input: ' + row['path'])
    return actual

def command(job, attempt):
    native = job['kind'] == 'native'
    old = str(S / ('native1' if native else 'compile1/' + job['tag']))
    out = S / (f'native{attempt}' if native else f'compile{attempt}/' + job['tag'])
    overlay = str(S / 'next-source/src/compute_provider_ggml_cuda')
    canonical = str(R / 'src/compute_provider_ggml_cuda')
    args = [arg.replace(old, str(out)).replace(overlay, canonical) for arg in job['command']]
    source = Path(args[args.index('-c') + 1]) if native else R / 'src/compute_provider_ggml_cuda' / Path(job['source']['path']).name
    return out, source, args

def dependencies(job, args, source):
    if job['kind'] == 'host':
        path = Path(args[args.index('/sourceDependencies') + 1])
        paths = read(path)['Data']['Includes']
    else:
        path = Path(args[args.index('-MF') + 1])
        text = path.read_text(encoding='utf-8').replace('\\\n', ' ')
        body = text.split(' : ', 1)[1]
        paths = [token.replace('\\ ', ' ').replace('\\#', '#')
                 for token in re.findall(r'(?:\\.|[^\s])+', body)]
    local, external = [], []
    seen = set()
    for value in [str(source), *paths]:
        candidate = Path(value).resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        if not candidate.is_file():
            raise ValueError('Compiler dependency is missing or misparsed: ' + str(candidate))
        if candidate.is_relative_to(R):
            local.append(identity(candidate))
        else:
            external.append(str(candidate))
    return path, local, external

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--only', choices=('host', 'native', 'all'), default='all')
    options = parser.parse_args()
    if options.attempt < 1:
        raise ValueError('Positive immutable attempt required')
    plan = read(S / 'compile-commands.json')
    ready = read(S / 'ready.json')
    jobs = [job for job in plan['jobs'] if options.only == 'all' or job['kind'] == options.only]
    for job in jobs:
        require(job['recipe'])
        require(job['source'])
    if not options.execute:
        print(json.dumps(dict(status='PREPARED ONLY', jobs=[dict(tag=j['tag'], command=command(j, options.attempt)[2]) for j in jobs]), indent=2))
        return
    # Only compiled inputs and the owning native pipeline must be applied.
    # Reference/test CMake may already have its separate exact successor.
    for row in ready['changed']:
        if row['path'].startswith('src/') or row['path'] in (
                'third_party/ggml_cuda_runtime/iq1-patches.json', 'cmake/HyleDependencyLock.json'):
            actual = identity(R / row['path'])
            if any(actual[key] != row['after'][key] for key in ('bytes', 'sha256')):
                raise ValueError('Proposal not applied exactly: ' + row['path'])
    h = module('_mmq_host_environment', R / '.scratch/native-paged-effects-20261022/build_windows.py')
    q = module('_mmq_compile_process', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    host_command = next(job['command'] for job in plan['jobs'] if job['kind'] == 'host')
    records = []
    for job in jobs:
        out, source, args = command(job, options.attempt)
        observed = identity(source)
        if any(observed[key] != job['source'][key] for key in ('bytes', 'sha256')):
            raise ValueError('Compile source differs from reviewed proposal')
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        save(out / 'plan.json', dict(command=args, recipe=job['recipe'], source=observed,
            proposal=identity(S / 'source.patch'), only_two_hosts_one_native=True))
        # Existing helper parses CL flags. For NVCC reuse its verified MSVC
        # environment, then prepend the actual CUDA13.3 compiler bin.
        environment_command = args if job['kind'] == 'host' else host_command
        env, _ = h.b.environment(environment_command, [], out)
        env.update(TEMP=str(out / 'tmp'), TMP=str(out / 'tmp'))
        if job['kind'] == 'native':
            env['PATH'] = str(Path(args[0]).parent) + os.pathsep + env['PATH']
        print('COMPILING ' + job['tag'], flush=True)
        result = q.execute(args, env, out / 'run', timeout=1800)
        if result['exit'] != 0 or result['timed_out']:
            raise SystemExit(result['exit'] or 1)
        if identity(source) != observed:
            raise ValueError('Compile source changed during process')
        depfile, local, external = dependencies(job, args, source)
        save(out / 'dependencies.json', dict(depfile=identity(depfile), local=local, external=external))
        object_path = Path(args[args.index('-o') + 1]) if job['kind'] == 'native' else Path(next(arg[3:] for arg in args if arg.lower().startswith('/fo')))
        record = dict(source=observed, object=identity(object_path), command=args,
            recipe=job['recipe'], dependencies=local, dependencies_file=identity(depfile),
            dependency_record=identity(out / 'dependencies.json'), process=identity(out / 'run/process.json'))
        if job['kind'] == 'native':
            record['overrides_native_archive_member'] = dict(
                library=str(R / '.scratch/validation/cuda-final-u3-delivery/reference-windows/lib/ggml-cuda.lib'),
                member='mmq.cu.obj', map_provenance=str(R / '.scratch/mtp-packed-head-20261024/parity-current-integration/current-link1/hyle-current-flash.map'))
        save(out / 'identity.json', record)
        records.append(identity(out / 'identity.json'))
        print('COMPILED ' + job['tag'], flush=True)
    save(S / f'build{options.attempt}-{options.only}.json', dict(records=records,
        host_TUs=sum(job['kind'] == 'host' for job in jobs), native_TUs=sum(job['kind'] == 'native' for job in jobs),
        SDK_rebuilds=0, model_runs=0, HTTP=0))

if __name__ == '__main__':
    main()
