"""Actual flat MMQ closure; the fourth five-tuple item is explicitly None.

The focused image has no model consumer. A subsequent model helper appends its
one new consumer object to plan['command']; it does not replace a dummy/old TU.
"""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
F = S / 'focused-link1'
spec = importlib.util.spec_from_file_location('_mmq_flat_focused_helpers', S / 'build_focused.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
read, save, identity, require = helper.read, helper.save, helper.identity, helper.require


def resolve(path):
    path = Path(path)
    return path.resolve() if path.is_absolute() else (R / path).resolve()


def check_record(path):
    return helper.current_record(identity(path))


def native_inputs():
    ready = read(F / 'ready.json')
    row = ready['native_records']
    require(row)
    native = read(row['path'])
    result = list(native['objects'])
    for entry in result:
        for key in ('object', 'source', 'plan', 'process', 'dependency_record'):
            require(entry[key])
        for dependency in entry['dependencies']:
            require(dependency)
    for key in ('tail', 'mmq'):
        entry = native[key]
        record = helper.current_record(entry['record'])
        if record['object'] != entry['object']:
            raise ValueError('Actual native record/object mismatch')
        result.append(dict(name=key, object=record['object'], source=record['source'], record=entry['record']))
    return result


def closure():
    helper.cached.clear()
    ready = read(F / 'ready.json')
    for key in ('image', 'link_plan', 'host_records', 'native_records', 'runtime_environment', 'link_result'):
        require(ready[key])
    actual = read(ready['link_plan']['path'])
    process = read(ready['link_result']['path'])
    if process['exit'] != 0 or process['timed_out'] or process['command'] != actual['command']:
        raise ValueError('Focused image must have its actual successful flat link')
    host_rows = read(ready['host_records']['path'])['records']
    if len(host_rows) != 131 or len({resolve(row['path']) for row in host_rows}) != 131:
        raise ValueError('Expected exact131 current flat host records')
    paths = []
    for row in host_rows:
        helper.current_record(row)
        paths.append(resolve(row['path']))
    native = native_inputs()
    for row in actual['retained_inputs']:
        require(row)
    runtime = read(ready['runtime_environment']['path'])
    for row in runtime['staged_dlls']:
        require(row)
    removed = {resolve(read(row['path'])['object']['path']) for row in actual['test_records']}
    if len(removed) != 3:
        raise ValueError('Expected exactly three focused test objects to omit')
    command, counts = [], dict.fromkeys(removed, 0)
    for arg in actual['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        path = resolve(arg) if arg.lower().endswith('.obj') else None
        if path in removed:
            counts[path] += 1
        else:
            command.append(arg)
    if set(counts.values()) != {1}:
        raise ValueError('Focused test objects must each be omitted exactly once')
    plan = dict(command=command, actual_flat_link=ready['link_plan'],
        host_records=ready['host_records'], retained_inputs=actual['retained_inputs'],
        native_inputs=ready['native_records'], native_objects=[row['object'] for row in native],
        consumer_record=None, pending_consumer=True, append_consumer=True,
        removed_focused_test_records=actual['test_records'], current_host_count=131,
        note='Prepared product closure derived from the actual focused link; append a new consumer before linking.')
    return plan, ready, resolve(ready['runtime_environment']['path']), None, paths


if __name__ == '__main__':
    plan, ready, runtime, consumer, hosts = closure()
    print(json.dumps(dict(prepared_only=True, current_hosts=len(hosts), native_objects=len(plan['native_objects']),
        consumer=consumer, append_consumer=True, actual_focused_image=ready['image'], runtime=str(runtime)), indent=2))
