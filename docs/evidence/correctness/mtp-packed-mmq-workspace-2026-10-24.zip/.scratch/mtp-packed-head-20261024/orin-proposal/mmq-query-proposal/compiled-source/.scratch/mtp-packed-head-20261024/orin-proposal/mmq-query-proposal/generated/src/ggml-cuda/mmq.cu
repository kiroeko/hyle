#include "common.cuh"
#include "mmq.cuh"
#include "mmvq.cuh"
#include "packed_matmul_native.h"
#include "ggml-backend-impl.h"
#include <atomic>
#include <stdexcept>
#include "quantize.cuh"
#include "mmid.cuh"

#include <cstdint>

static bool ggml_cuda_should_use_mmq_for_device(ggml_type, int, int64_t, int64_t, size_t);

// Kept in the owning mmq.cu: exact native types/helpers and pool interface.
static size_t hyle_mmq_mul(size_t a, size_t b) {
    if (b && a > SIZE_MAX / b) { throw std::overflow_error("MMQ scratch size overflow"); }
    return a * b;
}
static size_t hyle_mmq_add(size_t a, size_t b) {
    if (b > SIZE_MAX - a) { throw std::overflow_error("MMQ scratch size overflow"); }
    return a + b;
}
static size_t hyle_mmq_align(size_t a) {
    return hyle_mmq_add(a, 255) & ~size_t(255);
}
// This replaces the original ordinary-branch allocation expression as well
// as serving the planner. Native FP4 choice, tail and J-max are unchanged.
static size_t hyle_mmq_activation_bytes(ggml_type type, int cc, bool fallback,
        int64_t Kpad, int64_t M, int64_t channels, int64_t samples) {
    if (Kpad <= 0 || M <= 0 || channels <= 0 || samples <= 0) {
        throw std::invalid_argument("MMQ activation dimensions are invalid");
    }
    const bool fp4 = blackwell_mma_available(cc) && (type == GGML_TYPE_MXFP4 || type == GGML_TYPE_NVFP4);
    const size_t block_bytes = fp4 ? sizeof(block_fp4_mmq) : sizeof(block_q8_1_mmq);
    const size_t block_values = fp4 ? QK_FP4_MMQ : QK8_1_MMQ;
    const size_t count = hyle_mmq_mul(hyle_mmq_mul(size_t(samples), size_t(channels)),
                                    hyle_mmq_mul(size_t(M), size_t(Kpad)));
    if (count % block_values) { throw std::invalid_argument("MMQ activation block mismatch"); }
    return hyle_mmq_add(hyle_mmq_mul(count / block_values, block_bytes),
        hyle_mmq_mul(size_t(ggml_cuda_mmq_get_J_max(type, fallback, cc, M)), sizeof(block_q8_1_mmq)));
}

namespace hyle::compute::ggml_cuda::internal {
namespace {
constexpr int64_t logical_limit = INT32_MAX - 1024;
bool hyle_large_mmq(const ggml_tensor * w, const ggml_tensor * a, const ggml_tensor * y) {
    return w && a && y && ggml_is_quantized(w->type) && a->type == GGML_TYPE_F32 && y->type == GGML_TYPE_F32 &&
        w->ne[0] > 0 && w->ne[0] <= logical_limit && w->ne[1] > 0 && w->ne[1] <= logical_limit / w->ne[0] &&
        w->ne[0] * w->ne[1] > logical_limit / int64_t(sizeof(float)) &&
        w->ne[0] % MATRIX_ROW_PADDING == 0 && a->ne[0] == w->ne[0] &&
        a->ne[1] >= 1 && a->ne[1] <= 4 && y->ne[0] == w->ne[1] && y->ne[1] == a->ne[1] &&
        w->ne[2] == 1 && w->ne[3] == 1 && a->ne[2] == 1 && a->ne[3] == 1 && y->ne[2] == 1 && y->ne[3] == 1 &&
        ggml_is_contiguous(w) && ggml_is_contiguous(a) && ggml_is_contiguous(y);
}
bool hyle_plain_mmq(const ggml_tensor * w, const ggml_tensor * a, const ggml_tensor * y) {
    return w && a && y && ggml_is_quantized(w->type) && a->type == GGML_TYPE_F32 && y->type == GGML_TYPE_F32 &&
        w->ne[0] > 0 && w->ne[0] % MATRIX_ROW_PADDING == 0 && w->ne[1] > 0 && a->ne[1] > 0 &&
        a->ne[0] == w->ne[0] && y->ne[0] == w->ne[1] && y->ne[1] == a->ne[1] &&
        w->ne[2] == 1 && w->ne[3] == 1 && a->ne[2] == 1 && a->ne[3] == 1 && y->ne[2] == 1 && y->ne[3] == 1 &&
        ggml_is_contiguous(w) && ggml_is_contiguous(a) && ggml_is_contiguous(y);
}
}
PackedScratchPlan packed_matmul_plan(int device_index, ggml_type type, int64_t K, int64_t N, int64_t M) {
    PackedScratchPlan p;
    if (device_index < 0 || static_cast<unsigned>(type) >= static_cast<unsigned>(GGML_TYPE_COUNT) ||
        K <= 0 || K % MATRIX_ROW_PADDING || K > logical_limit || N <= 0 || N > logical_limit / K || M < 1 || M > logical_limit ||
        K > (logical_limit / int64_t(sizeof(float))) / M || N > (logical_limit / int64_t(sizeof(float))) / M) {
        return p;
    }
    const auto & info = ggml_cuda_info();
    if (device_index >= info.device_count || !ggml_is_quantized(type)) { return p; }
    const auto & device = info.devices[device_index];
    if (device.cc <= 0) { return p; }
    const size_t rb = ggml_row_size(type, K);
    if (!rb || rb > size_t(UINT32_MAX) / size_t(N)) { return p; }
    p.device = device_index; p.type = type; p.width = K; p.columns = N; p.rows = M;
    if (ggml_cuda_should_use_mmvq(type, device.cc, M)) { p.route = PackedMatmulRoute::kMmvq; return p; }
    // MMQ's signed offsets do not inherit MMVQ's typed-block UINT32 proof.
    if (rb > size_t(INT32_MAX) / size_t(N) || device.nsm <= 0 ||
        !ggml_cuda_should_use_mmq_for_device(type, device.cc, M, 0, device.smpbo)) { return {}; }
    const bool fallback = N % 128 != 0;
    bool any = false;
    size_t fixup = 0;
    for (int J = 8; J <= 128; J += 8) {
        const auto c = ggml_cuda_mmq_get_config(type, J, fallback, device.cc);
        if (c.type == GGML_TYPE_COUNT || mmq_get_nbytes_shared(c, device.cc) > device.smpbo) { continue; }
        // Original J_best is unchanged. Every legal candidate must be safe.
        // Also binds ordinary bounded MMQ nodes (M may exceed the MMVQ
        // threshold), without changing large-bank admission's M<=4 limit.
        if (c.I <= 0 || c.J != J || device.warp_size <= 0 || c.I % device.warp_size ||
            c.nthreads <= 0 || c.nthreads % device.warp_size) { return {}; }
        const int64_t nty = (N + c.I - 1) / c.I;
        const int64_t ntx = (M + c.J - 1) / c.J;
        if (N + c.I - 1 > INT32_MAX || M + c.J - 1 > INT32_MAX || ntx > INT32_MAX / nty) { return {}; }
        const int64_t nt = nty * ntx;
        const int64_t waves = (nt + device.nsm - 1) / device.nsm;
        // K conservatively bounds the launcher's K/qk without a codec table.
        if (nt + device.nsm - 1 > INT32_MAX ||
            int64_t(device.nsm) * waves > INT32_MAX || nt > INT32_MAX / 100 ||
            nt >= (int64_t(1) << 30) / K) { return {}; }
        if (ggml_cuda_mmq_get_stream_k(type, J, fallback, device.cc)) {
            const size_t elems = hyle_mmq_mul(hyle_mmq_mul(size_t(device.nsm), size_t(c.I)), size_t(c.J));
            if (elems > INT32_MAX) { return {}; }
            fixup = std::max(fixup, hyle_mmq_mul(elems, sizeof(float)));
        }
        any = true;
    }
    if (!any) { return {}; }
    p.activation_bytes = hyle_mmq_activation_bytes(type, device.cc, fallback, K, M, 1, 1);
    if (type == GGML_TYPE_NVFP4 && blackwell_mma_available(device.cc)) {
        p.scale_bytes = hyle_mmq_mul(size_t(M), sizeof(float));
    }
    p.fixup_bytes = fixup;
    // Native graph chunks use 128-byte alignment. Include room to align the
    // borrowed inner slots to 256 without changing the gallocr partition.
    p.bytes = hyle_mmq_add(255, hyle_mmq_add(hyle_mmq_add(hyle_mmq_align(p.activation_bytes), hyle_mmq_align(p.scale_bytes)), hyle_mmq_align(fixup)));
    p.route = PackedMatmulRoute::kMmq;
    return p;
}
PackedMatmulRoute packed_matmul_route(int device, ggml_type type, int64_t K, int64_t N, int64_t M) {
    if (M < 1 || M > 4) { return PackedMatmulRoute::kDeclined; }
    return packed_matmul_plan(device, type, K, N, M).route;
}
PackedScratchPlan packed_mmq_node_plan(int device, const ggml_tensor * node) {
    if (!node || node->op != GGML_OP_MUL_MAT || !hyle_plain_mmq(node->src[0], node->src[1], node)) { return {}; }
    const auto * w = node->src[0]; const auto * a = node->src[1];
    auto p = packed_matmul_plan(device, w->type, w->ne[0], w->ne[1], a->ne[1]);
    return p.route == PackedMatmulRoute::kMmq ? p : PackedScratchPlan{};
}
uint64_t packed_mmq_stream_mask(ggml_backend * backend, const ggml_tensor * node) {
    if (!backend || !node) { throw std::invalid_argument("MMQ stream mapping backend/node missing"); }
    auto * ctx = static_cast<ggml_backend_cuda_context *>(backend->context);
    uint64_t mask = 1; // Native encode may clear invalid concurrent events and use root0.
    for (const auto & item : ctx->stream_context().concurrent_events) {
        const auto found = item.second.stream_mapping.find(node);
        if (found == item.second.stream_mapping.end()) { continue; }
        const int stream = found->second;
        if (stream < 0 || stream >= GGML_CUDA_MAX_STREAMS || stream >= 64) {
            throw std::invalid_argument("MMQ cold stream mapping is invalid");
        }
        mask |= uint64_t(1) << stream;
    }
    return mask;
}
namespace {
// One fixed maximum-op arena per actual stream. No cudaMalloc/free, grow or
// delegation. Reconfigure only CPU slot metadata; GPU FIFO on that same stream
// orders the next node's writes after the preceding node's last fixup read.
class BoundedMmqPool final : public ggml_cuda_pool {
public:
    BoundedMmqPool(void * data, size_t bytes) : data_(data), bytes_(bytes) {}
    void configure(const PackedScratchPlan & p) {
        if (poisoned_ || busy() || p.bytes > bytes_) {
            throw std::length_error("MMQ plan exceeds its prepared stream arena");
        }
        const uintptr_t raw = reinterpret_cast<uintptr_t>(data_);
        if (raw > UINTPTR_MAX - 255) { throw std::invalid_argument("MMQ scratch address overflow"); }
        auto * aligned = reinterpret_cast<char *>((raw + 255) & ~uintptr_t(255));
        const size_t sizes[3] = {p.activation_bytes, p.scale_bytes, p.fixup_bytes};
        size_t at = 0;
        for (int i = 0; i != 3; ++i) {
            slots_[i].data = aligned + at;
            slots_[i].capacity = sizes[i];
            at = hyle_mmq_add(at, hyle_mmq_align(sizes[i]));
        }
        if (hyle_mmq_add(at, size_t(reinterpret_cast<uintptr_t>(aligned) - raw)) > bytes_) {
            throw std::length_error("MMQ stream arena partition mismatch");
        }
        next_ = 0;
    }
    void * alloc(size_t size, size_t * actual) override {
        while (next_ < 3 && slots_[next_].capacity == 0) { ++next_; }
        if (!actual || !size || next_ == 3 || slots_[next_].busy || size > slots_[next_].capacity ||
            (next_ < 2 && size != slots_[next_].capacity)) {
            throw std::length_error("MMQ request exceeds its prepared workspace slot");
        }
        auto & slot = slots_[next_++];
        slot.busy = true; *actual = slot.capacity;
        return slot.data;
    }
    void free(void * ptr, size_t size) override {
        // Called by noexcept native allocation destructors. Poison rather
        // than throw across their destructor; the outer scope checks it.
        for (auto & slot : slots_) {
            if (slot.capacity && ptr == slot.data) {
                if (!slot.busy || size != slot.capacity) { poisoned_ = true; }
                slot.busy = false; return;
            }
        }
        poisoned_ = true;
    }
    bool valid() const noexcept { return !poisoned_ && !busy(); }
private:
    struct Slot { void * data = nullptr; size_t capacity = 0; bool busy = false; };
    bool busy() const noexcept { return slots_[0].busy || slots_[1].busy || slots_[2].busy; }
    Slot slots_[3]; int next_ = 0; bool poisoned_ = false;
    void * data_; size_t bytes_;
};
struct ScratchEntry {
    const ggml_tensor * node;
    PackedScratchPlan plan;
    uint64_t streams;
};
struct ScratchArena {
    int stream;
    std::unique_ptr<ggml_cuda_pool> pool;
};
struct ScratchState {
    ggml_backend_cuda_context * context;
    std::vector<ScratchEntry> entries;
    std::vector<ScratchArena> arenas;
    std::atomic_flag encoding = ATOMIC_FLAG_INIT;
    bool poisoned = false;
};
// Borrowed CPU encode state only. No registry, payload key or GPU lifetime.
thread_local ScratchState * active_scratch = nullptr;
}
void * create_packed_scratch(ggml_backend * backend, const PackedScratchBinding * bindings, size_t count,
                            const PackedScratchArena * arenas, size_t arena_count) {
    if (!count && !arena_count) { return nullptr; }
    if (!backend || !bindings || !count || !arenas || !arena_count) {
        throw std::invalid_argument("MMQ scratch backend/bindings/arenas missing");
    }
    auto state = std::make_unique<ScratchState>();
    state->context = static_cast<ggml_backend_cuda_context *>(backend->context);
    state->entries.reserve(count); state->arenas.reserve(arena_count);
    uint64_t used_streams = 0, supplied_streams = 0;
    for (size_t i = 0; i < count; ++i) {
        const auto & b = bindings[i];
        if (b.plan.route != PackedMatmulRoute::kMmq || state->context->device != b.plan.device ||
            packed_mmq_node_plan(b.plan.device, b.node) != b.plan ||
            b.streams != packed_mmq_stream_mask(backend, b.node)) {
            throw std::invalid_argument("MMQ scratch binding/signature/streams mismatch");
        }
        for (const auto & old : state->entries) {
            if (old.node == b.node) { throw std::invalid_argument("MMQ scratch node repeated"); }
        }
        used_streams |= b.streams;
        state->entries.push_back({b.node, b.plan, b.streams});
    }
    for (size_t i = 0; i < arena_count; ++i) {
        const auto & a = arenas[i];
        const uintptr_t address = reinterpret_cast<uintptr_t>(a.data);
        if (a.stream < 0 || a.stream >= GGML_CUDA_MAX_STREAMS || a.stream >= 64 || !a.data || !a.bytes ||
            a.bytes > UINTPTR_MAX - address || (supplied_streams & (uint64_t(1) << a.stream))) {
            throw std::invalid_argument("MMQ stream arena address/slot mismatch");
        }
        supplied_streams |= uint64_t(1) << a.stream;
        size_t required = 0;
        for (const auto & e : state->entries) {
            if (e.streams & (uint64_t(1) << a.stream)) { required = std::max(required, e.plan.bytes); }
        }
        if (required != a.bytes) { throw std::invalid_argument("MMQ stream arena differs from cold maximum"); }
        for (size_t j = 0; j < i; ++j) {
            const uintptr_t other = reinterpret_cast<uintptr_t>(arenas[j].data);
            if (address < other + arenas[j].bytes && other < address + a.bytes) {
                throw std::invalid_argument("MMQ distinct stream arenas overlap");
            }
        }
        state->arenas.push_back({a.stream, std::make_unique<BoundedMmqPool>(a.data, a.bytes)});
    }
    if (used_streams != supplied_streams) { throw std::invalid_argument("MMQ stream arenas are incomplete"); }
    return state.release();
}
void destroy_packed_scratch(void * value) noexcept { delete static_cast<ScratchState *>(value); }
void begin_packed_scratch(void * value) {
    if (!value) { return; }
    auto * state = static_cast<ScratchState *>(value);
    if (active_scratch || state->encoding.test_and_set(std::memory_order_acquire)) {
        throw std::logic_error("MMQ scratch encoder is already active");
    }
    if (state->poisoned) {
        state->encoding.clear(std::memory_order_release);
        throw std::logic_error("MMQ scratch release validation failed");
    }
    active_scratch = state;
}
void check_packed_scratch(void * value) {
    if (value && static_cast<ScratchState *>(value)->poisoned) {
        throw std::logic_error("MMQ scratch release validation failed");
    }
}
void end_packed_scratch(void * value) noexcept {
    if (!value) { return; }
    auto * state = static_cast<ScratchState *>(value);
    if (active_scratch != state) { state->poisoned = true; return; }
    active_scratch = nullptr;
    state->encoding.clear(std::memory_order_release);
}
// Declared before all original ggml_cuda_pool_alloc locals in mul_mat_q.
// Each original local frees its slot before this restores the actual slot.
class PackedMmqPoolScope {
public:
    PackedMmqPoolScope(ggml_backend_cuda_context & ctx, const ggml_tensor * w,
            const ggml_tensor * a, const ggml_tensor * ids, const ggml_tensor * dst) : context_(ctx) {
        state_ = active_scratch;
        if (state_ && state_->context == &ctx) {
            for (auto & e : state_->entries) { if (e.node == dst) { entry_ = &e; break; } }
        }
        if (!entry_ && (ids || !hyle_large_mmq(w, a, dst))) { return; }
        if (!state_ || state_->context != &ctx || state_->poisoned) {
            throw std::logic_error("large MMQ has no Invocation-owned workspace binding");
        }
        if (ids || !hyle_plain_mmq(w, a, dst) || !entry_ || entry_->plan.device != ctx.device || entry_->plan.type != w->type ||
            entry_->plan.width != w->ne[0] || entry_->plan.columns != w->ne[1] || entry_->plan.rows != a->ne[1] ||
            ctx.curr_stream_no < 0 || ctx.curr_stream_no >= GGML_CUDA_MAX_STREAMS ||
            ctx.curr_stream_no >= 64 || ggml_cuda_get_device() != ctx.device) {
            throw std::logic_error("large MMQ Invocation node/signature/stream mismatch");
        }
        for (auto & a_pool : state_->arenas) {
            if (a_pool.stream == ctx.curr_stream_no) { arena_ = &a_pool; break; }
        }
        if (!arena_ || !arena_->pool || !(entry_->streams & (uint64_t(1) << ctx.curr_stream_no))) {
            throw std::logic_error("MMQ actual stream has no cold workspace arena");
        }
        static_cast<BoundedMmqPool *>(arena_->pool.get())->configure(entry_->plan);
        stream_ = ctx.curr_stream_no;
        auto & target = ctx.pools[ctx.device][stream_];
        saved_ = std::move(target);
        target = std::move(arena_->pool);
    }
    ~PackedMmqPoolScope() noexcept {
        if (stream_ < 0) { return; }
        auto & target = context_.pools[context_.device][stream_];
        if (!target || !static_cast<BoundedMmqPool *>(target.get())->valid()) { state_->poisoned = true; }
        arena_->pool = std::move(target);
        target = std::move(saved_);
    }
    PackedMmqPoolScope(const PackedMmqPoolScope &) = delete;
    PackedMmqPoolScope & operator=(const PackedMmqPoolScope &) = delete;
private:
    ggml_backend_cuda_context & context_;
    ScratchState * state_ = nullptr; ScratchEntry * entry_ = nullptr; ScratchArena * arena_ = nullptr;
    std::unique_ptr<ggml_cuda_pool> saved_; int stream_ = -1;
};
} // namespace hyle::compute::ggml_cuda::internal

static void ggml_cuda_mul_mat_q_switch_type(ggml_backend_cuda_context & ctx, const mmq_args & args, cudaStream_t stream) {
    switch (args.type_x) {
        case GGML_TYPE_Q1_0:
            mul_mat_q_case<GGML_TYPE_Q1_0>(ctx, args, stream);
            break;
        case GGML_TYPE_Q2_0:
            mul_mat_q_case<GGML_TYPE_Q2_0>(ctx, args, stream);
            break;
        case GGML_TYPE_Q4_0:
            mul_mat_q_case<GGML_TYPE_Q4_0>(ctx, args, stream);
            break;
        case GGML_TYPE_Q4_1:
            mul_mat_q_case<GGML_TYPE_Q4_1>(ctx, args, stream);
            break;
        case GGML_TYPE_Q5_0:
            mul_mat_q_case<GGML_TYPE_Q5_0>(ctx, args, stream);
            break;
        case GGML_TYPE_Q5_1:
            mul_mat_q_case<GGML_TYPE_Q5_1>(ctx, args, stream);
            break;
        case GGML_TYPE_Q8_0:
            mul_mat_q_case<GGML_TYPE_Q8_0>(ctx, args, stream);
            break;
// -----------------------------------------------------------------------
        case GGML_TYPE_Q2_K:
            mul_mat_q_case<GGML_TYPE_Q2_K>(ctx, args, stream);
            break;
        case GGML_TYPE_Q3_K:
            mul_mat_q_case<GGML_TYPE_Q3_K>(ctx, args, stream);
            break;
        case GGML_TYPE_Q4_K:
            mul_mat_q_case<GGML_TYPE_Q4_K>(ctx, args, stream);
            break;
        case GGML_TYPE_Q5_K:
            mul_mat_q_case<GGML_TYPE_Q5_K>(ctx, args, stream);
            break;
        case GGML_TYPE_Q6_K:
            mul_mat_q_case<GGML_TYPE_Q6_K>(ctx, args, stream);
            break;
// -----------------------------------------------------------------------
        case GGML_TYPE_IQ1_S:
            mul_mat_q_case<GGML_TYPE_IQ1_S>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ2_XXS:
            mul_mat_q_case<GGML_TYPE_IQ2_XXS>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ2_XS:
            mul_mat_q_case<GGML_TYPE_IQ2_XS>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ2_S:
            mul_mat_q_case<GGML_TYPE_IQ2_S>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ3_XXS:
            mul_mat_q_case<GGML_TYPE_IQ3_XXS>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ3_S:
            mul_mat_q_case<GGML_TYPE_IQ3_S>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ1_XS:
            mul_mat_q_case<GGML_TYPE_IQ1_XS>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ1_XXS:
            mul_mat_q_case<GGML_TYPE_IQ1_XXS>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ1_XXXS:
            mul_mat_q_case<GGML_TYPE_IQ1_XXXS>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ4_XS:
            mul_mat_q_case<GGML_TYPE_IQ4_XS>(ctx, args, stream);
            break;
        case GGML_TYPE_IQ4_NL:
            mul_mat_q_case<GGML_TYPE_IQ4_NL>(ctx, args, stream);
            break;
// -----------------------------------------------------------------------
        case GGML_TYPE_MXFP4:
            mul_mat_q_case<GGML_TYPE_MXFP4>(ctx, args, stream);
            break;
        case GGML_TYPE_NVFP4:
            mul_mat_q_case<GGML_TYPE_NVFP4>(ctx, args, stream);
            break;
        default:
            GGML_ABORT("fatal error");
            break;
    }
}

void ggml_cuda_mul_mat_q(
        ggml_backend_cuda_context & ctx, const ggml_tensor * src0, const ggml_tensor * src1, const ggml_tensor * ids, ggml_tensor * dst) {
    hyle::compute::ggml_cuda::internal::PackedMmqPoolScope owned_scratch(ctx, src0, src1, ids, dst);
    GGML_ASSERT(        src1->type == GGML_TYPE_F32);
    GGML_ASSERT(        dst->type  == GGML_TYPE_F32);
    GGML_ASSERT(!ids || ids->type  == GGML_TYPE_I32); // Optional, used for batched GGML_MUL_MAT_ID.

    GGML_TENSOR_BINARY_OP_LOCALS;

    cudaStream_t stream = ctx.stream();
    const int cc = ggml_cuda_info().devices[ggml_cuda_get_device()].cc;

    const size_t ts_src0 = ggml_type_size(src0->type);
    const size_t ts_src1 = ggml_type_size(src1->type);
    const size_t ts_dst  = ggml_type_size(dst->type);

    GGML_ASSERT(        nb00       == ts_src0);
    GGML_ASSERT(        nb10       == ts_src1);
    GGML_ASSERT(        nb0        == ts_dst);
    GGML_ASSERT(!ids || ids->nb[0] == ggml_type_size(ids->type));

    const char  * src0_d = (const char  *) src0->data;
    const float * src1_d = (const float *) src1->data;
    float       *  dst_d = (float       *)  dst->data;

    // If src0 is a temporary compute buffer, clear any potential padding.
    if (ggml_backend_buffer_get_usage(src0->buffer) == GGML_BACKEND_BUFFER_USAGE_COMPUTE) {
        const size_t size_data  = ggml_nbytes(src0);
        const size_t size_alloc = ggml_backend_buffer_get_alloc_size(src0->buffer, src0);
        if (size_alloc > size_data) {
            GGML_ASSERT(ggml_is_contiguously_allocated(src0));
            GGML_ASSERT(!src0->view_src);
            CUDA_CHECK(cudaMemsetAsync((char *) src0->data + size_data, 0, size_alloc - size_data, stream));
        }
    }

    const int64_t ne10_padded = GGML_PAD(ne10, MATRIX_ROW_PADDING);

    const int64_t s01 = src0->nb[1] / ts_src0;
    const int64_t s1  =  dst->nb[1] / ts_dst;
    const int64_t s02 = src0->nb[2] / ts_src0;
    const int64_t s2  =  dst->nb[2] / ts_dst;
    const int64_t s03 = src0->nb[3] / ts_src0;
    const int64_t s3  =  dst->nb[3] / ts_dst;

    const bool fallback = ne01 % 128 != 0;

    const bool use_native_fp4 = blackwell_mma_available(cc) && (src0->type == GGML_TYPE_MXFP4 || src0->type == GGML_TYPE_NVFP4);
    const size_t y_block_size       = use_native_fp4 ? sizeof(block_fp4_mmq) : sizeof(block_q8_1_mmq);
    const size_t y_values_per_block = use_native_fp4 ? QK_FP4_MMQ            : QK8_1_MMQ;

    if (!ids) {
        const size_t nbytes_src1_q8_1 = hyle_mmq_activation_bytes(
            src0->type, cc, fallback, ne10_padded, ne11, ne12, ne13);
        ggml_cuda_pool_alloc<char> src1_q8_1(ctx.pool(), nbytes_src1_q8_1);
        ggml_cuda_pool_alloc<float> src1_scale(ctx.pool());
        if (src0->type == GGML_TYPE_NVFP4 && use_native_fp4) {
            src1_scale.alloc(ne13*ne12*ne11);
        }

        {
            const int64_t s11 = src1->nb[1] / ts_src1;
            const int64_t s12 = src1->nb[2] / ts_src1;
            const int64_t s13 = src1->nb[3] / ts_src1;
            if (use_native_fp4) {
                static constexpr size_t align_float8 = 32;
                const bool use_aligned_float8 = ggml_cuda_is_aligned(src1, align_float8);
                static_assert(sizeof(block_fp4_mmq) == 4 * sizeof(block_q8_1));
                quantize_mmq_fp4_cuda(src1_d, nullptr, src1_q8_1.get(), src1_scale.ptr, src0->type, use_aligned_float8, ne10, s11, s12, s13, ne10_padded,
                                        ne11, ne12, ne13, stream);

            } else {
                quantize_mmq_q8_1_cuda(src1_d, nullptr, src1_q8_1.get(), src0->type, ne10, s11, s12, s13, ne10_padded,
                                       ne11, ne12, ne13, stream);
            }
            CUDA_CHECK(cudaGetLastError());
        }

        // Stride depends on quantization format
        const int64_t s12 = use_native_fp4 ?
                                ne11 * ne10_padded * sizeof(block_fp4_mmq) / (QK_FP4_MMQ * sizeof(int)) :
                                ne11 * ne10_padded * sizeof(block_q8_1) / (QK8_1 * sizeof(int));
        const int64_t s13 = ne12*s12;

        const mmq_args args = {
            src0_d, src0->type, (const int *) src1_q8_1.ptr, nullptr, nullptr, dst_d,
            src0->type == GGML_TYPE_NVFP4 && use_native_fp4 ? src1_scale.ptr : nullptr,
            ne00, ne01, ne1, s01, ne11, s1,
            ne02, ne12, s02, s12, s2,
            ne03, ne13, s03, s13, s3,
            ne1, ne1};
        ggml_cuda_mul_mat_q_switch_type(ctx, args, stream);
        return;
    }

    GGML_ASSERT(ne13 == 1);
    GGML_ASSERT(nb12 % nb11 == 0);
    GGML_ASSERT(nb2  % nb1  == 0);

    const int64_t n_expert_used = ids->ne[0];
    const int64_t ne_get_rows = ne12 * n_expert_used;
    GGML_ASSERT(ne1 == n_expert_used);

    ggml_cuda_pool_alloc<int32_t> ids_src1(ctx.pool(), ne_get_rows);
    ggml_cuda_pool_alloc<int32_t> ids_dst(ctx.pool(), ne_get_rows);
    ggml_cuda_pool_alloc<int32_t> expert_bounds(ctx.pool(), ne02 + 1);

    // gate/up activations are broadcast across experts (ne11 == 1): quantize each token once and
    // scatter to its slots. ids_src1 then holds the inverse map (token slot -> compact row).
    const bool dedup_bcast = ne11 == 1 && n_expert_used > 1;

    {
        GGML_ASSERT(ids->nb[0] == ggml_element_size(ids));
        const int si1  = ids->nb[1] / ggml_element_size(ids);
        const int sis1 = nb12 / nb11;

        ggml_cuda_launch_mm_ids_helper((const int32_t *) ids->data, ids_src1.get(), ids_dst.get(), expert_bounds.get(),
            ne02, ne12, n_expert_used, ne11, si1, sis1, /*write_inverse =*/ dedup_bcast, stream);
        CUDA_CHECK(cudaGetLastError());
    }

    const size_t nbytes_src1_q8_1 = ne12*n_expert_used*ne10_padded * y_block_size/y_values_per_block +
        ggml_cuda_mmq_get_J_max(src0->type, fallback, cc, ne11) * sizeof(block_q8_1_mmq);
    ggml_cuda_pool_alloc<char> src1_q8_1(ctx.pool(), nbytes_src1_q8_1);
    ggml_cuda_pool_alloc<float> src1_scale(ctx.pool());
    if (src0->type == GGML_TYPE_NVFP4 && use_native_fp4) {
        src1_scale.alloc(ne12*n_expert_used);
    }

    const int64_t ne11_flat = ne12*n_expert_used;
    const int64_t ne12_flat = 1;
    const int64_t ne13_flat = 1;

    {
        const int64_t s11 = src1->nb[1] / ts_src1;
        const int64_t s12 = src1->nb[2] / ts_src1;
        const int64_t s13 = src1->nb[3] / ts_src1;

        if (use_native_fp4) {
            static constexpr size_t align_float8 = 32;
            const bool use_aligned_float8 = ggml_cuda_is_aligned(src1, align_float8);
            if (dedup_bcast) {
                quantize_scatter_mmq_fp4_cuda(src1_d, ids_src1.get(), src1_q8_1.get(), src1_scale.ptr, src0->type, use_aligned_float8, ne10,
                                        /*stride_token=*/s12, ne10_padded, ne12, ne11_flat, n_expert_used, stream);
            } else {
                quantize_mmq_fp4_cuda(src1_d, ids_src1.get(), src1_q8_1.get(), src1_scale.ptr, src0->type, use_aligned_float8, ne10, s11, s12, s13,
                                        ne10_padded, ne11_flat, ne12_flat, ne13_flat, stream);
            }
        } else if (dedup_bcast) {
            quantize_scatter_mmq_q8_1_cuda(src1_d, ids_src1.get(), src1_q8_1.get(), src0->type, ne10,
                                    /*stride_token=*/s12, ne10_padded, ne12, ne11_flat, n_expert_used, stream);
        } else {
            quantize_mmq_q8_1_cuda(src1_d, ids_src1.get(), src1_q8_1.get(), src0->type, ne10, s11, s12, s13,
                                   ne10_padded, ne11_flat, ne12_flat, ne13_flat, stream);
        }
        CUDA_CHECK(cudaGetLastError());
    }

    static_assert(QK_FP4_MMQ == 8 * QK_MXFP4, "QK_FP4_MMQ needs to be 8 * QK_MXFP4");
    const int64_t s12 = use_native_fp4 ? ne11 * ne10_padded * sizeof(block_fp4_mmq) / (QK_FP4_MMQ * sizeof(int)) :
                                         ne11 * ne10_padded * sizeof(block_q8_1) / (QK8_1 * sizeof(int));
    const int64_t s13 = ne12*s12;

    // Each expert only sees ne12*n_expert_used/ne02 tokens on average.
    // On RDNA3 and RDNA4 it is faster to pick the tile size against this value instead of ne12.
    int64_t ncols_opt = ne12;
    if (GGML_CUDA_CC_IS_RDNA3_0(cc) || GGML_CUDA_CC_IS_RDNA4(cc)) {
        ncols_opt = (ne12*n_expert_used + ne02 - 1) / ne02;
    }

    // Note that ne02 is used instead of ne12 because the number of y channels determines the z dimension of the CUDA grid.
    const mmq_args args = {
        src0_d, src0->type, (const int *) src1_q8_1.get(), ids_dst.get(), expert_bounds.get(), dst_d,
        src1_scale.ptr,
        ne00, ne01, ne_get_rows, s01, ne_get_rows, s1,
        ne02, ne02, s02, s12, s2,
        ne03, ne13, s03, s13, s3,
        ne12, ncols_opt};

    ggml_cuda_mul_mat_q_switch_type(ctx, args, stream);
}

static bool ggml_cuda_should_use_mmq_for_device(enum ggml_type type, int cc, int64_t ne11, int64_t n_experts, size_t smpbo) {
    (void) smpbo;
#ifdef GGML_CUDA_FORCE_CUBLAS
    return false;
#endif // GGML_CUDA_FORCE_CUBLAS

    bool mmq_supported;

    switch (type) {
        case GGML_TYPE_Q1_0:
        case GGML_TYPE_Q2_0:
        case GGML_TYPE_Q4_0:
        case GGML_TYPE_Q4_1:
        case GGML_TYPE_Q5_0:
        case GGML_TYPE_Q5_1:
        case GGML_TYPE_Q8_0:
// -------------------------------------------------
        case GGML_TYPE_Q2_K:
        case GGML_TYPE_Q3_K:
        case GGML_TYPE_Q4_K:
        case GGML_TYPE_Q5_K:
        case GGML_TYPE_Q6_K:
// -------------------------------------------------
        case GGML_TYPE_IQ1_S:
        case GGML_TYPE_IQ2_XXS:
        case GGML_TYPE_IQ2_XS:
        case GGML_TYPE_IQ2_S:
        case GGML_TYPE_IQ3_XXS:
        case GGML_TYPE_IQ3_S:
        case GGML_TYPE_IQ1_XS:
        case GGML_TYPE_IQ1_XXS:
        case GGML_TYPE_IQ1_XXXS:
        case GGML_TYPE_IQ4_XS:
        case GGML_TYPE_IQ4_NL:
// -------------------------------------------------
        case GGML_TYPE_MXFP4:
        case GGML_TYPE_NVFP4:
            mmq_supported = true;
            break;
        default:
            mmq_supported = false;
            break;
    }

    if (!mmq_supported) {
        return false;
    }

    // MMQ tiles require at least 48 KiB per-block shared memory; fall back to BLAS otherwise.
    if (smpbo < 48 * 1024) {
        return false;
    }

    if (turing_mma_available(cc)) {
        return true;
    }

    if (ggml_cuda_highest_compiled_arch(cc) < GGML_CUDA_CC_DP4A) {
        // for MoE, mmq is faster even without native dp4a
        // TODO: check if cards older than pascal might benefit from this as well
        return cc >= GGML_CUDA_CC_PASCAL && n_experts > 0;
    }

#ifdef GGML_CUDA_FORCE_MMQ
    return true;
#endif //GGML_CUDA_FORCE_MMQ

    if (GGML_CUDA_CC_IS_NVIDIA(cc)) {
        return !fp16_mma_hardware_available(cc) || ne11 < MMQ_DP4A_MAX_BATCH_SIZE;
    }

    if (amd_mfma_available(cc)) {
        // As of ROCM 7.0 rocblas/tensile performs very poorly on CDNA3 and hipblaslt (via ROCBLAS_USE_HIPBLASLT)
        // performs better but is currently suffering from a crash on this architecture.
        // TODO: Revisit when hipblaslt is fixed on CDNA3
        if (GGML_CUDA_CC_IS_CDNA3(cc)) {
            return true;
        }
        if (n_experts > 64 || ne11 <= 128) {
            return true;
        }
        if (type == GGML_TYPE_Q4_0 || type == GGML_TYPE_Q4_1 || type == GGML_TYPE_Q5_0 || type == GGML_TYPE_Q5_1) {
            return true;
        }
        if (ne11 <= 256 && (type == GGML_TYPE_Q4_K || type == GGML_TYPE_Q5_K)) {
            return true;
        }
        return false;
    }

    if (amd_wmma_available(cc)) {
        if (GGML_CUDA_CC_IS_RDNA3(cc)) {
            // High expert counts are almost always better on MMQ due to
            //     the synchronization overhead in the cuBLAS/hipBLAS path:
            // https://github.com/ggml-org/llama.cpp/pull/18202
            if (n_experts >= 64) {
                return true;
            }

            // For some quantization types MMQ can have lower peak TOPS than hipBLAS
            //     so it's only faster for sufficiently small batch sizes:
            switch (type) {
                case GGML_TYPE_Q2_K:
                    return ne11 <= 128;
                case GGML_TYPE_Q6_K:
                    return ne11 <= (GGML_CUDA_CC_IS_RDNA3_0(cc) ? 128 : 256);
                case GGML_TYPE_IQ2_XS:
                case GGML_TYPE_IQ2_S:
                    return GGML_CUDA_CC_IS_RDNA3_5(cc) || ne11 <= 128;
                default:
                    return true;
            }
        }

        // For RDNA4 MMQ is consistently faster than dequantization + hipBLAS:
        // https://github.com/ggml-org/llama.cpp/pull/18537#issuecomment-3706422301
        return true;
    }

    // gfx900 (Vega 10), gfx909, and gfx90c lack native dp4a, losing to dequant + hipBLAS
    // for dense matrices; keep MMQ only for MoE, where the
    // hipBLAS path is much slower.
    if (cc == GGML_CUDA_CC_VEGA || GGML_CUDA_CC_IS_GCN_APU(cc)) {
        return n_experts > 0;
    }

    return (!GGML_CUDA_CC_IS_CDNA(cc)) || ne11 < MMQ_DP4A_MAX_BATCH_SIZE;
}


bool ggml_cuda_should_use_mmq(enum ggml_type type, int cc, int64_t ne11, int64_t n_experts) {
#ifdef GGML_CUDA_FORCE_CUBLAS
    GGML_UNUSED_VARS(type, cc, ne11, n_experts);
    return false;
#else
    const int id = ggml_cuda_get_device();
    return ggml_cuda_should_use_mmq_for_device(type, cc, ne11, n_experts, ggml_cuda_info().devices[id].smpbo);
#endif
}
