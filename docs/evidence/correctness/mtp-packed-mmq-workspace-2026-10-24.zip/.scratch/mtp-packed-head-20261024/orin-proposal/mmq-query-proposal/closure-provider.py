"""Offline edits only: join native algorithm scratch to the existing partition."""
def closure_provider(text, replace):
    text=replace(text,'''// Keep small attention nodes unchanged.''','''// Device adapters resolve BufferView offsets before this comparison. Inspect
// only the actual used workspace prefix, not unused backing capacity. Equal
// allocation handles alone neither prove overlap nor cover external aliases.
bool overlaps_workspace(const void *workspace, std::size_t used,
                        const void *data, std::size_t bytes) noexcept {
  if (used == 0 || bytes == 0)
    return false;
  const auto scratch = reinterpret_cast<std::uintptr_t>(workspace);
  const auto port = reinterpret_cast<std::uintptr_t>(data);
  return scratch <= port ? port - scratch < used : scratch - port < bytes;
}

// Keep small attention nodes unchanged.''')
    text=replace(text,'''  WorkspaceRequirement workspace{};
};''','''  WorkspaceRequirement workspace{};
  struct PackedNode final {
    std::size_t ordinal = 0;
    internal::PackedScratchPlan plan;
    std::uint64_t streams = 0;
  };
  struct PackedArena final { int stream = -1; std::size_t bytes = 0; };
  std::vector<PackedNode> packed_nodes;
  std::vector<PackedArena> packed_arenas;
};''')
    text=replace(text,'''  bool failed = false;

  Invocation()''','''  bool failed = false;
  void * packed_scratch = nullptr; // Metadata only; payload is caller workspace.

  Invocation()''')
    text=replace(text,'''    if (backend)
      (void)bridge::drain(backend);
    ggml_gallocr_free(graph_allocator);''','''    if (backend)
      (void)bridge::drain(backend);
    // Completion retires every participating stream before this destruction.
    // Pool metadata must retire before the graph/backend and borrowed backing.
    internal::destroy_packed_scratch(packed_scratch);
    ggml_gallocr_free(graph_allocator);''')
    point='''  Status initialize(const Program &program, mem::AllocatorRef allocator,
                     mem::BufferView backing) {'''
    functions='  Status measure_packed_scratch(Program &program) {\n    std::vector<std::size_t> stream_bytes;\n    for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {\n      auto *node = ggml_graph_node(graph, i);\n      const auto plan = internal::packed_mmq_node_plan(program.device, node);\n      if (plan.route != internal::PackedMatmulRoute::kMmq)\n        continue;\n      const auto streams = internal::packed_mmq_stream_mask(backend, node);\n      program.packed_nodes.push_back({static_cast<std::size_t>(i), plan, streams});\n      // Native cold metadata supplies actual slots; root0 is the native\n      // fallback if invalid concurrency metadata is discarded at encode.\n      auto mask = streams;\n      for (std::size_t slot = 0; mask; ++slot, mask >>= 1) {\n        if (!(mask & 1)) continue;\n        if (stream_bytes.size() <= slot) stream_bytes.resize(slot + 1);\n        stream_bytes[slot] = std::max(stream_bytes[slot], plan.bytes);\n      }\n    }\n    for (std::size_t slot = 0; slot < stream_bytes.size(); ++slot) {\n      if (!stream_bytes[slot]) continue;\n      auto *metadata = NativeWorkspace::allocate(&workspace, stream_bytes[slot]);\n      if (!metadata)\n        return Status::ResourceExhausted("ggml CUDA MMQ workspace measurement failed");\n      ggml_backend_buffer_free(metadata);\n      program.packed_arenas.push_back({static_cast<int>(slot), stream_bytes[slot]});\n    }\n    return Status::Ok();\n  }\n\n  Status bind_packed_scratch(const Program &program) {\n    std::vector<internal::PackedScratchBinding> bindings;\n    std::vector<internal::PackedScratchArena> arenas;\n    bindings.reserve(program.packed_nodes.size());\n    arenas.reserve(program.packed_arenas.size());\n    for (const auto &entry : program.packed_nodes) {\n      if (entry.ordinal >= static_cast<std::size_t>(ggml_graph_n_nodes(graph)))\n        return Status::FailedPrecondition("ggml CUDA MMQ native node changed");\n      auto *node = ggml_graph_node(graph, static_cast<int>(entry.ordinal));\n      if (internal::packed_mmq_node_plan(program.device, node) != entry.plan ||\n          internal::packed_mmq_stream_mask(backend, node) != entry.streams)\n        return Status::FailedPrecondition("ggml CUDA MMQ native signature/streams changed");\n      bindings.push_back({node, entry.plan, entry.streams});\n    }\n    for (const auto &entry : program.packed_arenas) {\n      auto *metadata = NativeWorkspace::allocate(&workspace, entry.bytes);\n      if (!metadata)\n        return Status::ResourceExhausted("ggml CUDA MMQ workspace binding failed");\n      ggml_backend_buffer_free(metadata);\n      const auto offset = workspace.span - entry.bytes;\n      arenas.push_back({entry.stream, workspace.base + offset, entry.bytes});\n    }\n    // Metadata only. Same-stream GPU FIFO/capture edges permit max-op arena\n    // reuse; different native streams have disjoint caller-workspace claims.\n    // Node pointers stay stable even if native graph ordering changes.\n    packed_scratch = internal::create_packed_scratch(\n        backend, bindings.data(), bindings.size(), arenas.data(), arenas.size());\n    return Status::Ok();\n  }\n\n'
    text=replace(text,point,functions+point)
    text=replace(text,'''    HYLE_RETURN_IF_ERROR(build(program, allocator, false));
    workspace.expected = program.workspace_chunks;''','''    // Constants can be actual readonly device bindings. Reject overlap before
    // native construction, binding or any constant upload/graph enqueue.
    for (const auto &constant : program.recipe.constants) {
      HYLE_ASSIGN_OR_RETURN(auto pointer, cuda::detail::const_pointer(
          constant.binding.storage(), program.alignments[constant.value], 1));
      HYLE_ASSIGN_OR_RETURN(auto bytes,
          program.recipe.values[constant.value].required_bytes());
      if (overlaps_workspace(workspace.base, program.workspace.size, pointer, bytes))
        return Status::InvalidArgument("ggml CUDA immutable constant overlaps caller workspace");
    }
    HYLE_RETURN_IF_ERROR(build(program, allocator, false));
    workspace.expected = program.workspace_chunks;''')
    text=replace(text,'''    auto *address = const_cast<void *>(*pointer);
    if (invocation.pointers[i] != address) {''','''    HYLE_ASSIGN_OR_RETURN(auto bytes,
        recipe.values[recipe.inputs[i]].required_bytes());
    if (overlaps_workspace(invocation.workspace.base, program.workspace.size, *pointer, bytes))
      return Status::InvalidArgument("ggml CUDA input overlaps caller workspace");
    auto *address = const_cast<void *>(*pointer);
    if (invocation.pointers[i] != address) {''')
    text=replace(text,'''    const auto index = inputs.size() + i;
    if (invocation.pointers[index] != *pointer) {''','''    HYLE_ASSIGN_OR_RETURN(auto bytes,
        recipe.values[recipe.outputs[i]].required_bytes());
    if (overlaps_workspace(invocation.workspace.base, program.workspace.size, *pointer, bytes))
      return Status::InvalidArgument("ggml CUDA output overlaps caller workspace");
    const auto index = inputs.size() + i;
    if (invocation.pointers[index] != *pointer) {''')
    text=replace(text,'''    HYLE_RETURN_IF_ERROR(reserved);
    if (workspace.next != workspace.expected.size() ||''','''    HYLE_RETURN_IF_ERROR(reserved);
    HYLE_RETURN_IF_ERROR(bind_packed_scratch(program));
    if (workspace.next != workspace.expected.size() ||''')
    text=replace(text,'''  cudaError_t retirement_error = cudaSuccess;
  try {
    if (sequence.recording()) {''','''  cudaError_t retirement_error = cudaSuccess;
  try {
    // Shared Program plans are immutable. Invocation/backend/workspace are
    // exclusive until Completion; TLS borrows only this CPU encoder's table.
    internal::PackedScratchEncodeScope packed_scope(invocation.packed_scratch);
    if (sequence.recording()) {''')
    text=replace(text,'''              *stream, &retirement_error);
    if (result != GGML_STATUS_SUCCESS)''','''              *stream, &retirement_error);
    packed_scope.check();
    if (result != GGML_STATUS_SUCCESS)''')
    text=replace(text,'''    status = measurement.reserve(&measurement.workspace);
    if (!status.ok())
      return ProviderPrepareOutcome::error(std::move(status));
    program->workspace = {''','''    status = measurement.reserve(&measurement.workspace);
    if (status.ok())
      status = measurement.measure_packed_scratch(*program);
    if (!status.ok())
      return ProviderPrepareOutcome::error(std::move(status));
    program->workspace = {''')
    return text
