"""Publish only the actual seven-case MMQ workspace focused result."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
D = R / 'docs/evidence/correctness'
NAME = 'mtp-packed-mmq-workspace-2026-10-24'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


tool_path = R / '.scratch/glm-quark-selected-20261024/Q30/publish.py'
tool = load('_existing_small_correctness_archive', tool_path)
# This owning native source fragment is C++, not a payload or binary.
tool.SMALL_SUFFIXES.update({'.inc', '.diff'})
read, identity, require = tool.read, tool.identity, tool.require


def main():
    proof_path, zip_path = D / (NAME + '.json'), D / (NAME + '.zip')
    if proof_path.exists() or zip_path.exists():
        raise ValueError('New proof paths must not overwrite existing evidence')
    run, linked = S / 'checks-focused1', S / 'focused-link1'
    summary, ready = read(run / 'summary.json'), read(linked / 'ready.json')
    expected = {
        'GgmlCudaPackedBounds.FullVocabularySmallBatchPreparesWithoutWeightStorage',
        'GgmlCudaPackedBounds.LargeHeadsDeclineFallbackAndPaddedLayouts',
        'GgmlCudaPackedBounds.EncodedAndLogicalLimitsKeepOtherPortsBounded',
        'GgmlCudaPackedMmqWorkspace.OriginalQ6KD4UsesMeasuredCallerWorkspace',
        'GgmlCudaPackedTail.Q8K512N1M1', 'GgmlCudaPackedTail.Q8K512N3M1',
        'GgmlCudaPackedTail.Q8K512N3M2'}
    tree = ET.parse(run / 'results.xml').getroot()
    cases = list(tree.iter('testcase'))
    names = {case.get('classname') + '.' + case.get('name') for case in cases}
    if (not summary['passed'] or summary['process']['exit'] != 0 or summary['process']['timed_out'] or
            len(cases) != 7 or names != expected or any(int(tree.get(k, 0)) for k in ('failures', 'errors', 'disabled')) or
            list(tree.iter('skipped')) or any(case.get('status') != 'run' or case.get('result') != 'completed' for case in cases)):
        raise ValueError('Exactly the actual seven passing unskipped cases are required')
    require(summary['ready']); require(summary['runtime'])
    if summary['image'] != ready['image'] or Path(ready['image']['path']).stat().st_size != ready['image']['bytes']:
        raise ValueError('Actual executed image identity differs')
    require(ready['link_plan']); require(ready['link_result'])
    plan, process = read(ready['link_plan']['path']), read(ready['link_result']['path'])
    if process['exit'] != 0 or process['timed_out'] or process['command'] != plan['command']:
        raise ValueError('Actual focused link did not pass')
    map_proof = read(linked / 'link-verified.json')
    if map_proof['old_mmq_archive_member_selected'] or not map_proof['mmq_explicit_object_definitions']:
        raise ValueError('MAP must select the new MMQ owning object')
    require(map_proof['excerpt'])
    metadata = read(S / 'combined-ready.json')
    for row in metadata['changed']:
        actual = identity(R / row['path'])
        if any(actual[k] != row['after'][k] for k in ('bytes', 'sha256')):
            raise ValueError('Published source changed after focused run: ' + row['path'])
    mmq_case = next(case for case in cases if case.get('classname') == 'GgmlCudaPackedMmqWorkspace')
    properties = {p.get('name'): p.get('value') for p in mmq_case.findall('./properties/property')}
    if int(properties['workspace_alias_rejections']) != 3 or properties['workspace_unused_tail_ports'] != 'same allocation, disjoint used prefix':
        raise ValueError('Required alias rejection and disjoint same-backing checks absent')
    runtime = read(ready['runtime_environment']['path'])
    if runtime['cpu_runtime_override']['module']['sha256'] != 'fcb2b57d8aad1453c8dde3468986d4f0120edcd71ef3e6edfd86870c6c1914fa':
        raise ValueError('Expected actual corrected same-family AVX2 worker')
    archive = tool.Archive([])
    for row in metadata['changed']:
        archive.add(R / row['path'])
    for filename in ('publish.py', 'build_delta.py', 'build_focused.py', 'current_closure.py', 'run_focused.py',
        'prepare.py', 'closure-header.h', 'closure-native.inc', 'closure-provider.py', 'combined-source.patch',
        'combined-ready.json', 'compile-commands.json', 'build-result.json', 'link-replacements-ready.json',
        'native.diff', 'reference-proposal/ready.json', 'generated/src/ggml-cuda/mmq.cu',
        'native-before/src/ggml-cuda/mmq.cu'):
        archive.add(S / filename)
    archive.add(R / 'tests/compute_provider_ggml_cuda/packed_matmul_tail_test.cc')
    # Keep the original small source/math helpers used by the independent
    # oracle; this is not a copy of native SDK sources or the host closure.
    for filename in ('dspark_original_shared_reference.h', 'qwen27_original_nextn_reference.h'):
        archive.add(R / 'tests/compute_models' / filename)
    for directory in (S / 'compile1', S / 'native2', S / 'test-compile1', linked, run, S / 'native1/run'):
        archive.metadata_tree(directory)
    for path in (S / 'native2/mmq.d', S / 'native1/compile-commands-before.json', linked / 'mmq-map-excerpt.txt'):
        archive.add(path)
    for path in (S / 'compiled-source').rglob('*'):
        if path.is_file():
            archive.add(path)
    for row in plan['retired']:
        archive.add(row['source_snapshot']['path'])
    for row in ready['test_records']:
        archive.add(row['path'])
    for row in read(S / 'build-result.json')['records']:
        archive.add(row['record']['path'])
    license_path = R / 'third_party/ggml_cuda_runtime/LICENSE'
    if not license_path.is_file():
        raise ValueError('Owning native license is absent')
    archive.files[license_path.relative_to(R).as_posix()] = license_path
    dependencies = [D / (name + '.json') for name in (
        'mtp-gdn-output-scale-2026-10-24', 'mtp-packed-head-current-2026-10-24',
        'mtp-packed-mmvq-tail-read-2026-10-24', 'mtp-packed-mmvq-tail-integration-2026-10-24')]
    prior = [identity(path) for path in dependencies]
    for path in dependencies:
        archive.add(path)
    if any(path.stat().st_size > 5_000_000 for path in archive.files.values()):
        raise ValueError('Only small source/metadata/log files are archived')
    with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name, path in sorted(archive.files.items()):
            target.write(path, name)
    result = dict(schema='hyle-focused-correctness-v1', date='2026-10-24', status='passed',
        scope='One generated nonuniform Q6_K/D4 M16 K512 N3 ordinary default MMQ workspace fixture, three packed descriptor-bound cases, and three small Q8 numeric tail regressions on RTX 4070.',
        tests=dict(total=7, passed=7, failures=0, skipped=0, descriptor=3, mmq=1, tail=3),
        cases=sorted(expected), properties=properties,
        hardware=dict(device='NVIDIA GeForce RTX 4070', compute_capability='8.9', source=identity(run / 'run/stderr.log')),
        execution=dict(summary=identity(run / 'summary.json'), XML=identity(run / 'results.xml'),
            process=identity(run / 'run/process.json'), image=ready['image'], runtime=ready['runtime_environment']),
        product=dict(patch=metadata['patch'], changed_files=metadata['changed'],
            workspace='Original native AQ sizing and bounded stream-K fixup upper bounds enter the existing caller NativeWorkspace. One maximum arena per actually used native stream; per-node signatures retain metadata only.',
            alias_guard='Before enqueue, compare only the used workspace prefix against actual immutable/port pointer spans with view offsets; zero spans skip, subtraction avoids endpoint overflow and disjoint same-allocation views remain legal.',
            admission='Actual nominated native selectors/configurations; large-bank M1..4 domain retained. UINT32 encoded bytes is MMVQ-only; covered MMQ retains signed-I32 encoded/index bounds.'),
        independent_reference=dict(path=identity(R / 'tests/compute_models/mmq_q6k_reference.h'),
            contract=read(S / 'reference-proposal/ready.json')['reference_contract'],
            generated_fixture=dict(A=[16,512], W=[3,512], Y=[16,3], original_packed_weight_bytes=1260)),
        compile=dict(result=identity(S / 'build-result.json'), host_TUs=2, new_test_TUs=2, reused_tail_test_TUs=1,
            NVCC_commands=2, successful_native_TUs=1, SDK_builds=0,
            retained_failure='First NVCC attempt lacked the unchanged leaf mmid.cuh in the sparse cached header subset. Same-revision fallback was appended after patched includes; actual deps show only mmid.cuh came from raw fallback.'),
        link=dict(ready=identity(linked / 'ready.json'), plan=ready['link_plan'], MAP=map_proof['map'],
            excerpt=map_proof['excerpt'], host_records=ready['host_records'], native_records=ready['native_records'],
            old_mmq_archive_member_selected=False, flat_closure_entry=identity(S / 'current_closure.py')),
        limitations=['Only the recorded RTX4070 fixture executed; Orin hardware remains unverified.',
            'No full model, original-model weight, throughput, physical-memory peak or memcheck claim.',
            'The D4 Q6_K certificate does not certify all MMQ codecs, Q4/Q5 minimum compensation or Q2 D2S6.',
            'Ordinary uncovered/batched/MMVQ native private allocations remain outside this owned-MMQ migration; invocation_private_bytes remains unknown where it was unknown.',
            'The seven cases do not exhaust capture replay, forced allocation-failure retirement, multistream or parallel-Invocation behavior.'],
        Orin_native_verified=False, model_inference=False, memcheck=False, TPS=False, HTTP=0,
        prior_shared_evidence=prior, archive=identity(zip_path),
        files=[dict(archive_path=name, **identity(path)) for name, path in sorted(archive.files.items())])
    proof_path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
    finished = dict(proof=identity(proof_path), archive=identity(zip_path), tests=7, passed=7)
    (S / 'published.json').write_text(json.dumps(finished, indent=2) + '\n')
    print(json.dumps(finished, indent=2), flush=True)


if __name__ == '__main__':
    main()
