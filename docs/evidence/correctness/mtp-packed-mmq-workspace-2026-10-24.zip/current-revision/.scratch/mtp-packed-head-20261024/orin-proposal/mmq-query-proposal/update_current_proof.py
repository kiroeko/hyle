"""Append the actual default-initializer portability revision, without new tests."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

R = Path(__file__).resolve().parents[4]
S = Path(__file__).resolve().parent
D = R / 'docs/evidence/correctness'


def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def text(path):
    return Path(path).read_text(encoding='utf-8-sig')


def require(row):
    actual = identity(row['path'])
    assert all(actual[key] == row[key] for key in ('bytes', 'sha256')), row['path']


def main():
    proof = D / 'mtp-packed-mmq-workspace-2026-10-24.json'
    archive = proof.with_suffix('.zip')
    previous = read(proof)
    assert 'current_revision' not in previous
    before = S / 'default-init-revision/before/mtp-packed-mmq-workspace-2026-10-24.json'
    if before.exists():
        assert before.read_bytes() == proof.read_bytes()
    else:
        before.write_bytes(proof.read_bytes())
    old_archive = identity(archive)
    run, linked = S / 'checks-focused2', S / 'focused-link2'
    summary, ready = read(run / 'summary.json'), read(linked / 'ready.json')
    assert summary['passed'] and summary['process']['exit'] == 0 and not summary['process']['timed_out']
    assert summary['image'] == ready['image']
    require(summary['ready']); require(summary['runtime'])
    tree = ET.parse(run / 'results.xml').getroot()
    cases = list(tree.iter('testcase'))
    assert len(cases) == 7 and not list(tree.iter('skipped'))
    assert all(tree.get(key, '0') == '0' for key in ('failures', 'errors', 'disabled'))
    assert {case.get('classname') + '.' + case.get('name') for case in cases} == set(previous['cases'])
    assert all(case.get('result') == 'completed' for case in cases)
    plan, process = read(ready['link_plan']['path']), read(ready['link_result']['path'])
    assert process['exit'] == 0 and process['command'] == plan['command']
    provider = read(S / 'compile2/provider/identity.json')
    assert 'packed_nodes{};' in text(provider['source']['path'])
    assert 'packed_arenas{};' in text(provider['source']['path'])
    require(provider['source'])
    provider_record = identity(S / 'compile2/provider/identity.json')
    assert any(row['sha256'] == provider_record['sha256'] for row in read(ready['host_records']['path'])['records'])
    link_map = linked / 'packed-mmq-workspace-checks.map'
    lines = text(link_map).splitlines()
    selected = [line for line in lines if any(key in line for key in (
        '?ggml_cuda_mul_mat_q@@', '?ggml_cuda_should_use_mmq@@', '?packed_matmul_plan@',
        '?create_packed_scratch@', '?ggml_cuda_mul_mat_vec_q@@')) and
        not any(key in line for key in ('dtor$', '$unwind$', '$cppxdata$', '$ip2state$', '$stateUnwindMap$'))]
    assert all('mmq.obj' in line for line in selected if 'ggml_cuda_mul_mat_vec_q' not in line)
    assert all('mmvq.obj' in line for line in selected if 'ggml_cuda_mul_mat_vec_q' in line)
    assert not any('ggml-cuda:mmq.cu.obj' in line for line in lines)
    excerpt = linked / 'mmq-map-excerpt.txt'
    excerpt.write_text('\n'.join(selected) + '\n', encoding='utf-8')
    linux = S / 'default-init-revision/linux'
    linux_result = read(linux / 'result.json')
    assert linux_result['status'].startswith('PASS') and linux_result['link'] == linux_result['native_runs'] == 0
    for folder in ('compile2/provider', 'compile1/tensor-program', 'compile1/mmq'):
        directory = linux / folder
        assert read(directory / 'process.json')['exit'] == 0
        deps = read(directory / 'dependency-record.json')
        assert deps['no_old_product_headers']
        assert not any('/root/hyle-scratch/active-cpu-z/source/' in row['path']
            for row in deps.get('local', deps.get('current_product', [])))
    assert read(linux / 'compile1/provider/process.json')['exit'] != 0
    assert 'missing-field-initializers' in text(linux / 'compile1/provider/stderr.log')
    files = [Path(__file__), before, S / 'default-init-revision/source.patch',
        S / 'default-init-revision/linux-files.json', S / 'current_closure.py', S / 'build_focused.py',
        S / 'run_focused.py', R / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc']
    for directory in (S / 'default-init-revision/before', linux, S / 'compile2/provider', linked, run):
        files += [path for path in directory.rglob('*') if path.is_file() and path.suffix.lower() in
            {'.json', '.xml', '.log', '.txt', '.py', '.h', '.cc', '.cu', '.d', '.patch'} and path.name != 'CMakeCache.txt']
    files = sorted(set(files))
    assert all(path.stat().st_size < 5_000_000 for path in files)
    additions = []
    with zipfile.ZipFile(archive, 'a', compression=zipfile.ZIP_DEFLATED) as target:
        old_names = set(target.namelist())
        assert len(old_names) == len(target.namelist()) and not any(name.startswith('current-revision/') for name in old_names)
        for path in files:
            name = 'current-revision/' + path.relative_to(R).as_posix()
            target.write(path, name)
            additions.append(dict(archive_path=name, **identity(path)))
    current = dict(source_patch=identity(S / 'default-init-revision/source.patch'),
        reason='GCC14 -Werror requires explicit defaults for new aggregate vector fields; only packed_nodes{} and packed_arenas{} were added. No ABI/math change.',
        source=provider['source'], windows=dict(provider_record=provider_record, provider_TUs=1,
            NVCC_commands=0, other_host_native_and_test_objects_reused=True,
            execution=dict(summary=identity(run / 'summary.json'), XML=identity(run / 'results.xml'),
                process=identity(run / 'run/process.json'), image=ready['image'], runtime=ready['runtime_environment']),
            link_ready=identity(linked / 'ready.json'), link_plan=ready['link_plan'], MAP=identity(link_map),
            MAP_excerpt=identity(excerpt), same_seven_cases_passed=True),
        linux=dict(scope='Current product 2 host + 1 native compile-only; no link or focused/model execution',
            copied_records=identity(linux / 'result.json'), original_result=linux_result,
            inventory=identity(linux / 'inventory.json'), first_provider_failure=identity(linux / 'compile1/provider/process.json'),
            first_provider_stderr=identity(linux / 'compile1/provider/stderr.log'), no_ABI17_product_headers=True,
            old_Linux_host_closure_not_linked=True, SDK_rebuilds=0, HTTP=0),
        flat_closure_entry=identity(S / 'current_closure.py'), Orin_native_verified=False, TPS=False)
    previous['initial_revision'] = dict(proof_snapshot=identity(before), archive_before_append=old_archive,
        execution=previous['execution'], link=previous['link'],
        note='Initial focused1 facts and source payloads remain in the existing archive entries; this container appends the current revision without a second SDK/binary archive.')
    previous['execution'] = current['windows']['execution']
    previous['current_revision'] = current
    previous['link'] = dict(ready=identity(linked / 'ready.json'), plan=ready['link_plan'], MAP=identity(link_map),
        excerpt=identity(excerpt), host_records=ready['host_records'], native_records=ready['native_records'],
        old_mmq_archive_member_selected=False, flat_closure_entry=identity(S / 'current_closure.py'))
    for row in previous['product']['changed_files']:
        if row['path'] == 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc':
            row['initial_after'] = row['after']
            row['after'] = {key: provider['source'][key] for key in ('bytes', 'sha256')}
    previous['product']['subsequent_source_patch'] = current['source_patch']
    previous['compile']['current_revision'] = dict(Windows_provider_TUs=1, Windows_NVCC_commands=0,
        Linux_host_compile_attempts=3, Linux_successful_host_TUs=2, Linux_NVCC_commands=1, Linux_link_or_native_execution=0)
    previous['limitations'].append('Linux GCC14/NVCC13.3 compiled only against current product headers and the exact cached native family; no Linux ABI18 image was linked or executed.')
    previous['archive'] = identity(archive)
    previous['files'] += additions
    proof.write_text(json.dumps(previous, indent=2) + '\n', encoding='utf-8', newline='\n')
    result = dict(proof=identity(proof), archive=identity(archive), tests=7, passed=7,
        initial_focused_run_preserved=True, Linux_compile_only=True, flat_helper=identity(S / 'current_closure.py'))
    (S / 'published-current-revision.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
