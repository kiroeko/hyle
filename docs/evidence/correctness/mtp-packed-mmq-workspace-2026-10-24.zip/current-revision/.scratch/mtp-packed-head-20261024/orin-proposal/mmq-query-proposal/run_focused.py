"""Run the seven actual packed bounds, MMQ workspace and MMVQ tail checks."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = next(p for p in S.parents if (p / 'AGENTS.md').is_file())
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
spec = importlib.util.spec_from_file_location('_focused_mmq_execute', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
q = importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--attempt', type=int, default=1)
args = parser.parse_args(); assert args.attempt > 0
stage = S / f'focused-link{args.attempt}'; ready = read(stage / 'ready.json')
assert identity(ready['image']['path']) == ready['image']
runtime = read(stage / 'runtime-environment.json')
for module in runtime['staged_dlls']: assert identity(module['path']) == module
out = S / f'checks-focused{args.attempt}'
assert not out.exists()
env = os.environ.copy(); env['PATH'] = runtime['PATH']
process = q.execute([ready['image']['path'], '--gtest_filter=' + ready['expected_filter'], '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'results.xml')], env, out / 'run', timeout=180)
result = dict(passed=False, process=process, image=ready['image'], ready=identity(stage / 'ready.json'), runtime=identity(stage / 'runtime-environment.json'), HTTP=0, Orin_native_verified=False, throughput_evidence=False, memory_evidence=False)
try:
    tree = ET.parse(out / 'results.xml').getroot()
    counts = {k: int(tree.get(k, '0')) for k in ('tests', 'failures', 'errors', 'disabled')}
    result['counts'] = counts
    result['cases'] = [dict(x.attrib) for x in tree.iter('testcase')]
    result['skips'] = len(list(tree.iter('skipped')))
    result['passed'] = process['exit'] == 0 and not process['timed_out'] and counts['tests'] == ready['expected_cases'] == 7 and all(counts[k] == 0 for k in ('failures', 'errors', 'disabled')) and result['skips'] == 0
except Exception as error: result['error'] = str(error)
q.save(out / 'summary.json', result)
print(json.dumps(dict(passed=result['passed'], counts=result.get('counts'), process_exit=process['exit'], Orin_native_verified=False)), flush=True)
sys.exit(0 if result['passed'] else 1)
