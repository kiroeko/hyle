"""Compile two focused test TUs and flatten the actually linked host/native closure.

No model execution or acquisition. The historical Flash consumer and two host
records are retired by exact object identity, never asserted current.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
P = R / '.scratch/mtp-packed-head-20261024'
BASE = P / 'parity-current-integration/current-link1'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


d = module('_mmq_compiled_delta', S / 'build_delta.py')
read, save, identity = d.read, d.save, d.identity
h = module('_mmq_focused_host_env', R / '.scratch/native-paged-effects-20261022/build_windows.py')
q = module('_mmq_focused_process', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
cached = {}


def require(row):
    path = Path(row['path']).resolve()
    if path not in cached:
        cached[path] = identity(path)
    observed = cached[path]
    if any(observed[key] != row[key] for key in ('bytes', 'sha256')):
        raise ValueError('Changed actual input: ' + str(path))
    return path


def current_record(row):
    path = require(row)
    record = read(path)
    dependencies = record.get('dependencies')
    if dependencies is None:
        dependency_path = path.parent / 'dependencies.json'
        dependencies = read(dependency_path)['local']
        require(record['dependencies_file'])
    for value in [record['source'], record['object'], *dependencies]:
        require(value)
    return record


def compile_tests(attempt):
    recipe = P / 'tail-read-proposal/test1/identity.json'
    prior = read(recipe)
    result = []
    for tag, filename in [('bounds-test', 'packed_matmul_bounds_test.cc'),
                          ('mmq-test', 'packed_mmq_workspace_test.cc')]:
        source = R / 'tests/compute_provider_ggml_cuda' / filename
        out = S / f'test-compile{attempt}' / tag
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        command = []
        for arg in prior['command']:
            if arg == prior['source']['path']:
                arg = str(source)
            elif arg.startswith('/Fo'):
                arg = '/Fo' + str(out / (tag + '.obj'))
            elif arg.startswith('/Fd'):
                arg = '/Fd' + str(out / (tag + '.pdb'))
            command.append(arg)
        command[command.index('/sourceDependencies') + 1] = str(out / 'source-deps.json')
        observed = identity(source)
        snapshot = out / 'source' / source.relative_to(R)
        snapshot.parent.mkdir(parents=True)
        snapshot.write_bytes(source.read_bytes())
        save(out / 'plan.json', dict(command=command, source=observed, recipe=identity(recipe)))
        env, _ = h.b.environment(command, [], out)
        env.update(TEMP=str(out / 'tmp'), TMP=str(out / 'tmp'))
        print('COMPILING ' + tag, flush=True)
        process = q.execute(command, env, out / 'run', timeout=1800)
        if process['exit'] != 0 or process['timed_out']:
            raise SystemExit(process['exit'] or 1)
        if identity(source) != observed:
            raise ValueError('Test source changed during compilation')
        deps = read(out / 'source-deps.json')['Data']
        dependencies = [identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
        save(out / 'identity.json', dict(source=observed, object=identity(out / (tag + '.obj')),
            command=command, dependencies=dependencies, recipe=identity(recipe),
            process=identity(out / 'run/process.json'), source_snapshot=identity(snapshot)))
        result.append(identity(out / 'identity.json'))
        print('COMPILED ' + tag, flush=True)
    save(S / f'test-compile{attempt}/ready.json', dict(records=result, test_TUs=2, product_TUs=0,
        NVCC=0, SDK_builds=0, native_runs=0))


def retired(row, snapshot):
    record = read(require(row))
    require(record['object'])
    proof = identity(snapshot)
    if any(proof[k] != record['source'][k] for k in ('bytes', 'sha256')):
        raise ValueError('Retired source snapshot differs from actual compile')
    return dict(record=row, object=record['object'], original_source=record['source'],
        source_snapshot=proof, retired_only=True, source_is_current=False)


def link(attempt, compile_attempt, provider_attempt):
    ready = read(BASE / 'ready.json')
    for key in ('image', 'link_plan', 'runtime_environment', 'host_records', 'consumer_record', 'link_result'):
        require(ready[key])
    original = read(ready['link_plan']['path'])
    actual = read(ready['link_result']['path'])
    if actual['exit'] != 0 or actual['command'] != original['command']:
        raise ValueError('Base actual link was not successful')
    replacements = read(S / 'link-replacements-ready.json')
    # The one later GCC portability edit has its own actual provider record;
    # tensor_program, MMQ and focused test objects remain the same inputs.
    provider_record = identity(S / f'compile{provider_attempt}/provider/identity.json')
    provider = current_record(provider_record)
    provider_rows = [row for row in replacements['replace_objects']
                     if Path(read(row['old_record']['path'])['source']['path']).name == 'ggml_cuda_provider.cc']
    if len(provider_rows) != 1:
        raise ValueError('Expected exactly one provider owner replacement')
    provider_rows[0].update(new_record=provider_record, new_object=provider['object'])
    retired_paths = {Path(row['old_record']['path']).resolve(): row for row in replacements['replace_objects']}
    hosts, retirement = [], []
    for row in read(ready['host_records']['path'])['records']:
        key = Path(row['path']).resolve()
        if key in retired_paths:
            new = retired_paths[key]
            source = read(require(row))['source']['path']
            retirement.append(retired(row, S / 'before' / Path(source).relative_to(R)))
            current_record(new['new_record'])
            hosts.append(new['new_record'])
        else:
            current_record(row)
            hosts.append(row)
    if len(hosts) != 131 or len(retirement) != 2:
        raise ValueError('Expected exact131 host records and two replacements')
    consumer_path = require(ready['consumer_record'])
    consumer = read(consumer_path)
    consumer_snapshot = consumer_path.parent / 'source' / Path(consumer['source']['path']).relative_to(R)
    retirement.append(retired(ready['consumer_record'], consumer_snapshot))
    compiled = read(consumer_path.parent / 'compile.result.json')
    if compiled['exit'] != 0 or compiled['command'] != consumer['command']:
        raise ValueError('Retired Flash must have actual successful source compile')
    tests = [identity(S / f'test-compile{compile_attempt}' / tag / 'identity.json')
             for tag in ('bounds-test', 'mmq-test')]
    tail_test = P / 'tail-read-proposal/test1/identity.json'
    if identity(R / 'tests/compute_provider_ggml_cuda/packed_matmul_tail_test.cc')['sha256'] != read(tail_test)['source']['sha256']:
        raise ValueError('Reused tail test differs from canonical source')
    tests.append(identity(tail_test))
    test_records = [current_record(row) for row in tests]
    native = replacements['add_native_object_before_libraries']
    mmq = current_record(native['record'])
    for row in original['retained_inputs']:
        require(row)
    require(original['native_inputs'])
    native_inputs = read(original['native_inputs']['path'])
    for entry in native_inputs['objects']:
        for key in ('object', 'source', 'plan', 'process', 'dependency_record'):
            require(entry[key])
        for row in entry['dependencies']:
            require(row)
    require(original['tail_native_input'])
    tail = read(original['tail_native_input']['path'])
    current_record(tail['record'])
    old_to_new = {Path(x['old_object']['path']).resolve(): x['new_object']['path']
                  for x in replacements['replace_objects']}
    old_consumer = Path(consumer['object']['path']).resolve()
    counts = dict.fromkeys(old_to_new, 0)
    removed, command = 0, []
    for arg in original['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        path = Path(arg).resolve() if arg.lower().endswith('.obj') else None
        if path == old_consumer:
            command.extend(record['object']['path'] for record in test_records)
            removed += 1
        elif path in old_to_new:
            command.append(old_to_new[path])
            counts[path] += 1
        else:
            command.append(arg)
    if removed != 1 or set(counts.values()) != {1}:
        raise ValueError('Exact two-host/one-consumer replacement required')
    first_library = next(i for i, arg in enumerate(command) if arg.lower().endswith('.lib'))
    command.insert(first_library, mmq['object']['path'])
    wanted = [*old_to_new.values(), mmq['object']['path'], tail['object']['path'],
              *(entry['object']['path'] for entry in native_inputs['objects']),
              *(entry['object']['path'] for entry in test_records)]
    for path in wanted:
        if sum(arg.casefold() == path.casefold() for arg in command) != 1:
            raise ValueError('Required object must appear exactly once: ' + path)
    known = {Path(read(row['path'])['object']['path']).resolve() for row in hosts}
    known |= {Path(row['path']).resolve() for row in original['retained_inputs']}
    known |= {Path(path).resolve() for path in wanted}
    if any(Path(arg).resolve() not in known for arg in command if arg.lower().endswith('.obj')):
        raise ValueError('Unaccounted link object')
    if any(Path(arg).resolve() in {*old_to_new, old_consumer} for arg in command if arg.lower().endswith('.obj')):
        raise ValueError('Retired object remains')
    out = S / f'focused-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'packed-mmq-workspace-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    if not any(arg.upper().startswith('/SUBSYSTEM:') for arg in command):
        command.append('/SUBSYSTEM:CONSOLE')
    save(out / 'host-records.json', dict(records=hosts, count=131, current_source_dependencies_checked=True))
    save(out / 'native-records.json', dict(objects=native_inputs['objects'], tail=tail, mmq=native))
    save(out / 'link-plan.json', dict(command=command, base_actual_link=ready['link_plan'],
        host_records=identity(out / 'host-records.json'), native_records=identity(out / 'native-records.json'),
        test_records=tests, retained_inputs=original['retained_inputs'], retired=retirement,
        inputs=[identity(arg) for arg in command if arg.lower().endswith(('.obj', '.lib')) and Path(arg).is_file()],
        system_libraries=[arg for arg in command if arg.lower().endswith('.lib') and not Path(arg).is_file()],
        source_current=True, removed_Flash_consumer=True, product_host_TUs=2, test_TUs=2,
        native_TUs=1, SDK_builds=0, expected_cases=7, reused_test_TUs=1, native_executed=False))
    env, _ = h.b.environment(command, [], out)
    env.update(TEMP=str(out / 'tmp'), TMP=str(out / 'tmp'))
    print('LINKING focused current MMQ closure', flush=True)
    process = q.execute(command, env, out / 'link', timeout=1800)
    if process['exit'] != 0 or process['timed_out']:
        raise SystemExit(process['exit'] or 1)
    runtime_path = R / '.scratch/glm-gguf-selected-20261023/B10/native-current-proposal/runtime-avx2.json'
    runtime = read(runtime_path)
    corrected = runtime['cpu_runtime_override']['module']
    require(corrected)
    if corrected['sha256'] != 'fcb2b57d8aad1453c8dde3468986d4f0120edcd71ef3e6edfd86870c6c1914fa':
        raise ValueError('Expected actual corrected same-family15-TU AVX2 module')
    for row in runtime['staged_dlls']:
        source = require(row)
        os.link(source, out / source.name)
    runtime['PATH'] = str(out) + os.pathsep + runtime['PATH']
    runtime['staged_dlls'] = [identity(path) for path in out.glob('*.dll')]
    runtime['previous'] = identity(runtime_path)
    save(out / 'runtime-environment.json', runtime)
    save(out / 'ready.json', dict(image=identity(image), link_plan=identity(out / 'link-plan.json'),
        host_records=identity(out / 'host-records.json'), native_records=identity(out / 'native-records.json'),
        runtime_environment=identity(out / 'runtime-environment.json'), test_records=tests,
        link_result=identity(out / 'link/process.json'), native_result=False,
        Orin_native_verified=False, expected_cases=7,
        expected_filter='GgmlCudaPackedBounds.*:GgmlCudaPackedMmqWorkspace.*:GgmlCudaPackedTail.*'))
    print('LINKED ' + str(image), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('compile', 'link'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--provider-attempt', type=int, default=1)
    args = parser.parse_args()
    if args.attempt < 1 or args.compile_attempt < 1 or args.provider_attempt < 1:
        raise ValueError('Positive immutable attempt required')
    if args.action == 'compile':
        compile_tests(args.attempt)
    else:
        link(args.attempt, args.compile_attempt, args.provider_attempt)
