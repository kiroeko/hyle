import ctypes,json,os,shutil,subprocess,time
from pathlib import Path
ctypes.windll.kernel32.SetErrorMode(0x8003);flags={'creationflags':subprocess.CREATE_NO_WINDOW}
vs='C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\Common7\\Tools\\VsDevCmd.bat'
s=subprocess.check_output('"'+os.environ['ComSpec']+'" /d /s /c "call "'+vs+'" -arch=x64 >nul && set"',text=True,**flags)
for line in s.splitlines():
 n,sep,v=line.partition('=')
 if sep and n and (n.lower()!='path' or '\\VC\\Tools\\MSVC\\' in v):os.environ[n]=v
root=Path('C:/hv/v4w');out=root/'receipts/off-consumer-correction';out.mkdir();receipt={'steps':[]}
def run(label,args):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,**flags)
 receipt['steps'].append({'label':label,'argv':list(map(str,args)),'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
producer=root/'off';prefix=root/'off-sdk';build=root/'off-consumer'

commands=subprocess.check_output(['ninja','-C',str(producer),'-t','commands'],text=True,**flags)
(out/'commands.log').write_text(commands)
for forbidden in ('glslang','glslc','/ggml-vulkan/','iree_runtime','compute_route_vulkan.dir','compute_provider_iree_vulkan.dir'):
 if forbidden in commands.replace('\\','/').lower():raise SystemExit('OFF artifact leakage: '+forbidden)

run('off-consumer-configure',[shutil.which('cmake'),'-S','evidence/correctness/vulkan-parity-v4-delivery/platform','-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DV4_ENABLE_VULKAN=OFF','-DCMAKE_PREFIX_PATH='+str(prefix)])
run('off-consumer-build',[shutil.which('cmake'),'--build',build,'--parallel','2'])
run('off-consumer-run',[build/'v4_platform.exe'])
receipt['verdict']='PASS';receipt['vulkan_probe_and_artifact_leakage']=False
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
