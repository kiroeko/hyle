from pathlib import Path
import hashlib,json
A=Path('.scratch/architecture-refactor-2026-10-18')
Z=A/'quark-block128-scale-2026-10-21/apple'
P=A/'apple-compact-fp8-scales-2026-10-21/apple'
P.mkdir(parents=True,exist_ok=True)
old=Z/'mac/final'
link=json.loads((old/'results/link.command.json').read_text())['argv']
inputs=json.loads((old/'results/link-inputs.json').read_text())
source='src/compute_route_apple/apple_mature_float.cc'
obj=next(x for x in inputs if x['path'].endswith('src--compute_route_apple--apple_mature_float.cc.o'))
recipe=old/'results/src--compute_route_apple--apple_mature_float.cc-compile.command.json'
b=Path(source).read_bytes()
plan=dict(status='focused_original_native_paths_only_no_SDK_rebuild',linked_owners=[dict(
    source=source,source_bytes=len(b),source_sha256=hashlib.sha256(b).hexdigest(),old_object=obj,recipe=recipe.as_posix())],
 retained_test='Z fp8_scale_policy wrapper exact object remains linked; only new tiletest object is added',
 retained_CPU='Z torch_cpu_program current ID2/3 object remains linked')
(P/'affected-owner-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(Z/'prepare_mac.py').read_text()
s=s.replace("P=A/'quark-block128-scale-2026-10-21/apple'","P=A/'apple-compact-fp8-scales-2026-10-21/apple'")
s=s.replace("OLD=A/'quark-fp8-side-2026-10-21/apple/mac/current7'","OLD=A/'quark-block128-scale-2026-10-21/apple/mac/final'")
s=s.replace("remote=oldroot.replace('/quark-fp8-side-2026-10-21/apple','/quark-block128-scale-2026-10-21/apple')", "remote=oldroot.replace('/quark-block128-scale-2026-10-21/apple','/apple-compact-fp8-scales-2026-10-21/apple')")
s=s.replace("sources=['tests/graph_route_apple/fp8_scale_policy_test.cc']", "sources=['tests/compute_route_apple/fp8_tile_test.cc']")
s=s.replace("recipe=read(OLD/'results/tests--graph_route_apple--fp8_outer_scale_test.cc-compile.command.json')['argv']", "recipe=read(A/'ga-bf16-indexer-state-2026-10-21/apple/mac/remote/results/tests--compute_route_apple--reduction_test.cc-compile.command.json')['argv']")
s=s.replace("excluded_tests=[x for x in link if x.endswith('.o') and ('/tests--' in x or '/tests/' in x or x.endswith('/static_fp8_test.o'))]", "excluded_tests=[]")
s=s.replace("image='fp8-scale-policy',filter='AppleFp8ScalePolicy.*'", "image='compact-fp8-scales',filter='AppleFp8ScalePolicy.*:ApplePackedFp8.EncodedDotAndExplicitDecodeKeepMacroblockScaleAxes:ApplePackedFp8.AllCodesPreserveFiniteValuesAndReservedNan'")
s=s.replace("OLD.parent.parent/'source-role-actual-dependencies-canonical-audit.json'", "OLD.parent.parent/'actual-dependencies-canonical-audit.json'")
(P/'prepare_mac.py').write_text(s)
(P/'build_mac.py').write_bytes((Z/'build_mac.py').read_bytes())
s=(Z/'collect_mac.py').read_text().replace('quark-block128-scale-2026-10-21/apple','apple-compact-fp8-scales-2026-10-21/apple')
s=s.replace("r/'tests/graph_route_apple/fp8_scale_policy_test.cc'", "r/'tests/graph_route_apple/fp8_scale_policy_test.cc',r/'tests/compute_route_apple/fp8_tile_test.cc'")
(P/'collect_mac.py').write_text(s)
s=(Z/'audit_dependencies.py').read_text().replace('quark-block128-scale-2026-10-21/apple','apple-compact-fp8-scales-2026-10-21/apple').replace('current three CXX invocations','current two CXX invocations')
(P/'audit_dependencies.py').write_text(s)
print('AA2TU scripts and exact Z closure plan prepared')
