from pathlib import Path
import difflib,hashlib,json,runpy,zipfile,xml.etree.ElementTree as E
A=Path('.scratch/architecture-refactor-2026-10-18');P=A/'apple-compact-fp8-scales-2026-10-21/apple'
ROOT=Path.cwd();STAGE=P.parent
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
remote=json.loads((P/'mac/plan.json').read_text())['remote']
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(p):
    p=Path(p);b=p.read_bytes();return dict(path=p.as_posix(),bytes=len(b),sha256=sha(b))
def save(name,data):
    p=P/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n')
code=r'''
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(json.load(sys.stdin)['remote'])
def ident(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
p=r/'compact-fp8-scales.map';lines=p.read_text().splitlines()
objects=lines[lines.index('# Object files:')+1:lines.index('# Sections:')]
names=['apple_mature_float.cc.o','fp8_tile_test.cc.o','torch_cpu_program.cc.o','fp8_scale_policy_test.cc.o']
related=[x for x in objects if any(n in x for n in names)]
assert len(related)==4
assert sum(str(r/'objects') in x for x in related)==2
assert not any('.a(' in x or '.a[' in x for x in related)
assert all('quark-block128-scale-2026-10-21/apple/objects' in x for x in related if str(r/'objects') not in x)
map_audit=dict(map=ident(p),related_loaded_objects=related,related_old_archive_members=[],
 loaded_object_count=len(objects),scope='Two AA fresh objects replace/add original paths; exact Z torchCPU and scale-policy wrapper remain linked. No old related fallback archive member.')
files=[];objs=[]
for p in sorted(r.rglob('*')):
    if not p.is_file() or p.is_symlink():continue
    if p.suffix=='.o':objs.append(ident(p));continue
    with p.open('rb') as f:magic=f.read(4)
    if p.suffix=='.map' or magic in [bytes.fromhex('cffaedfe'),bytes.fromhex('feedfacf'),bytes.fromhex('cafebabe')]:files.append(ident(p))
assert len(files)==2 and len(objs)==2
images=[x['path'] for x in files if not x['path'].endswith('.map')]
ps=subprocess.run(['ps','-axo','pid=,args='],capture_output=True,text=True)
active=[x for x in ps.stdout.splitlines() if any(p in x for p in images)]
lsof=subprocess.run(['/usr/sbin/lsof','-Fn',*images],capture_output=True,text=True)
assert not r.is_symlink() and not active and not lsof.stdout.strip()
inventory=dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=files,retained_objects=objs,
 dsym=[str(x) for x in r.rglob('*.dSYM')],active_image_processes=active,lsof_stdout=lsof.stdout,
 lsof_exit=lsof.returncode,deleted=False)
records=json.loads((r/'results/compile-summary.json').read_text())['compiles']
md=[ident(Path(row['dependency'])) for row in records]
print(json.dumps(dict(map_audit=map_audit,inventory=inventory,dependency_files=md)))
'''
remote_facts=ssh(code,dict(remote=remote));save('link-map-audit.json',remote_facts['map_audit']);save('cleanup-inventory.json',remote_facts['inventory'])
sources=['src/compute_route_apple/apple_mature_float.cc','tests/compute_route_apple/fp8_tile_test.cc']
for rel in sources:
    b=Path(rel).read_bytes();q=STAGE/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    before=(STAGE/'before'/rel).read_text();current=b.decode()
    target=P/('diff-'+Path(rel).name+'.patch')
    target.write_text(''.join(difflib.unified_diff(before.splitlines(True),current.splitlines(True),fromfile='before/'+rel,tofile=rel)))
audit=json.loads((P/'actual-dependencies-canonical-audit.json').read_text())
assert audit['translation_units']==2 and audit['drift_count']==0
canonical={}
for row in audit['compiles']:
    for item in row['canonical']:
        assert item['equal'];canonical[item['current']['path']]=item['current']
summary=json.loads((P/'mac/final/results/compile-summary.json').read_text())
assert len(summary['compiles'])==2 and all(x['exit']==0 and not x['source_drifts'] for x in summary['compiles'])
records=[]
for row in summary['compiles']:
    records.append({k:row[k] for k in ['source','object_identity','dependency','exit','seconds','source_drifts']})
dep=dict(status='actual_current_two_translation_units_complete_MMD_audit_zero_drift',
 actual_MMD_files=remote_facts['dependency_files'],actual_dependency_references=audit['actual_dependency_references'],
 canonical_dependency_references=audit['canonical_dependency_references'],external_dependency_references=audit['external_dependency_references'],
 unique_canonical_files=audit['unique_canonical_files'],current_canonical_identities=list(canonical.values()),
 compile_records=records,source_audit=identity(P/'actual-dependencies-canonical-audit.json'),
 note='No repeated full SDK dependency JSON is stored in this package. Commands and actual MD path text are retained; full current canonical identities are listed once. Unchanged SDK identity comes from the explicitly referenced Z baseline.')
save('dependency-facts.json',dep)
source_freeze=dict(status='actual_source_current_two_fresh_CXX_and_bounded_Z_reuse',sources=[identity(p) for p in sources],
 before=[identity(STAGE/'before'/p) for p in sources],dependency_facts=identity(P/'dependency-facts.json'),
 baseline=identity(ROOT/'docs/evidence/correctness/block128-scale-policy-reference-2026-10-21.json'))
save('source-freeze.json',source_freeze)
cases=[];xml=P/'mac/final/results/tests.xml';submits=0;failed_completions=0
for c in E.parse(xml).findall('.//testcase'):
    assert not c.findall('failure') and not c.findall('skipped')
    prop={p.get('name'):p.get('value') for p in c.findall('properties/property')}
    count=prop.get('successful_submissions',prop.get('actual_submissions'))
    count=int(count) if count is not None else None
    name=c.get('classname')+'.'+c.get('name')
    kind='Z_neighbor' if c.get('classname')=='AppleFp8ScalePolicy' else 'new_macroblock_axes' if c.get('name')=='EncodedDotAndExplicitDecodeKeepMacroblockScaleAxes' else 'all_codes_neighbor'
    if kind=='all_codes_neighbor':assert name=='ApplePackedFp8.AllCodesPreserveFiniteValuesAndReservedNan' and count is None
    submits+=count or 0;failed_completions+=int(prop.get('expected_failed_completions','0'))
    cases.append(dict(name=name,classification=kind,XML_successful_submissions=count,
      source_counted_submissions=1 if kind=='all_codes_neighbor' else None,properties=prop))
assert len(cases)==8 and submits==45 and failed_completions==2
validation=json.loads((P/'mac/final/results/validation.json').read_text())
assert validation['exit']==0 and validation['tests']==8 and not validation['failed'] and not validation['skipped']
structural=dict(status='source_and_actual_native_route_structure_not_allocation_or_speed_measurement',
 dense_call='The encoded-A MatMul and Float8BlockLinear shared tail calls weight(...,compact_scales=true).',
 original_weight_helper='compact_scales returns before mx::repeat and mx::slice; packed kernel uses (!FOUR ? column/128 : column) for SF row selection.',
 explicit_decode='Float8WeightDecode still calls the original noncompact path, preserving full requested decoded-W output.',
 source_role=dict(N=2048,K=4096,groups=32,old_repeated_SF_shape=[1,2048,32,1],old_logical_bytes=262144,
  new_compact_SF_shape=[1,16,32,1],new_logical_bytes=2048,reduction_factor=128),
 new_test='M1N129K256 has distinct macroblock and K-group scales; encoded dot and explicit full decoding each submit once.',
 unchanged='Original QDQ policies, scale multiplication/addition boundaries, grouped compact path, FP4 per-row scales and output casts.',
 not_measured=['Physical MTLBuffer allocations','Dispatch counts after fusion','Peak memory','Time or throughput'])
save('structural-space-proof.json',structural)
report=dict(passed=True,tests=8,new_cases=1,Z_neighbors=6,all_codes_neighbors=1,failed=0,skipped=0,
 XML_successful_submissions=45,source_counted_additional_submissions=1,expected_failed_completions=2,
 cases=cases,CXX_jobs=2,SDK_jobs=0,new_links=1,actual_GPU_runs=1,
 source_freeze=identity(P/'source-freeze.json'),actual_dependency_drift=0,
 hardware=identity(P/'mac/final/hardware.json'),run=json.loads((P/'mac/final/results/run.result.json').read_text()),validation=validation,
 structural_space=structural,link_map_audit=identity(P/'link-map-audit.json'),cleanup_inventory=identity(P/'cleanup-inventory.json'),
 scope='Apple-only dense packed block128 SF address/layout correction.8 actual distinct cases; Z6 neighbors use the same exact retained wrapper/object and original fixtures. No whole-artifact/payload, Linux, quality, physical allocation or throughput claim.',
 no_product_docs_edited=True,no_cleanup_performed=True)
save('final-validation.json',report)
files={}
def put(name,p):
    p=Path(p);assert p.is_file() and not p.is_symlink();files[name]=p.read_bytes()
for rel in sources:
    put('source/'+rel,Path(rel));put('before/'+rel,STAGE/'before'/rel)
for name in ['finalize_package.py','setup_scripts.py','prepare_mac.py','build_mac.py','collect_mac.py','audit_dependencies.py',
             'source-freeze.json','dependency-facts.json','link-map-audit.json','cleanup-inventory.json',
             'structural-space-proof.json','final-validation.json','affected-owner-plan.json',
             'diff-apple_mature_float.cc.patch','diff-fp8_tile_test.cc.patch']:
    put('evidence/'+name,P/name)
for name in ['plan.json','source-manifest.json','reused-source-manifest.json','hardware.json']:
    # plan includes exact source and link recipes, without SDK code/payload.
    put('evidence/mac/'+name,P/'mac/final'/name)
for path in sorted((P/'mac/final/results').iterdir()):
    if not path.is_file():continue
    if path.name.endswith('-identity.json') or path.name in ['compile-summary.json','link-inputs.json']:continue
    put('evidence/results/'+path.name,path)
manifest=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())]
files['manifest.json']=(json.dumps(dict(files=manifest),indent=2)+'\n').encode()
out=ROOT/'docs/evidence/correctness';name='apple-compact-fp8-scales-reference-2026-10-21'
archive=out/(name+'.zip');target=out/(name+'.json')
assert not archive.exists() and not target.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(files) and z.testzip() is None
    for row in manifest:assert sha(z.read(row['path']))==row['sha256']
result=dict(report,archive=identity(archive),manifest_members=len(manifest),source_members=2)
target.write_text(json.dumps(result,indent=2)+'\n')
published=dict(summary=identity(target),archive=identity(archive),members=len(files),
 cleanup_inventory=identity(P/'cleanup-inventory.json'),deletable_bytes=sum(x['bytes'] for x in remote_facts['inventory']['deletable_files']))
save('archive-result.json',published);print(json.dumps(published,indent=2))
