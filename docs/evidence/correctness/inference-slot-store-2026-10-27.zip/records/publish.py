"""Publish the bounded Store correctness check; no build or execution."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1];D=W/'attempt2'
SOURCES=['src/graph/resources.cc','include/hyle/graph/detail/region_access.h',
 'tests/graph/region_provider_test.cc','include/hyle/graph/slots.h',
 'src/graph/slots_region.h','src/graph/slots_region.cc','src/graph_batch/batch.cc',
 'src/graph/CMakeLists.txt','tests/graph/slots_execution_test.cc',
 'tests/graph/slots_cuda_execution_test.cc','tests/graph/CMakeLists.txt']
GLUE={'src/graph/CMakeLists.txt':'9440e356a42fbd8433815ef97c717b3a8c72d09258025972758fbd4c95248472',
 'tests/graph/CMakeLists.txt':'8107121127c726c6254f54d65887dd0ae8de29f9639d08ca4fb197bcbfe448ae'}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=sha(raw))
def check(row):assert pin(Path(row['path']))==row,row['path']
def publish():
 receipt=R/'docs/evidence/correctness/inference-slot-store-2026-10-27.json'
 archive=receipt.with_suffix('.zip');assert not receipt.exists() and not archive.exists()
 summary=read(D/'summary.json');ready=read(D/'ready.json');plan=read(D/'plan.json')
 assert summary['tests']==13 and summary['failures']==0
 assert len(ready['compiled'])==6 and ready['link']['exit']==0
 frozen=read(D/'source-freeze.json');own={str(Path(x['path'])).casefold():x for x in frozen}
 for row in frozen:check(row)
 for unit in ready['compiled']:
  assert unit['process']['exit']==0;check(unit['source']);check(unit['object'])
  for row in read(Path(unit['actual_dependencies']['path'])):check(row)
 check(ready['image'])
 payload={};sources=[]
 for name in SOURCES:
  path=R/name;raw=path.read_bytes();key=str(path).casefold()
  expected=GLUE[name] if name in GLUE else own[key]['sha256']
  assert sha(raw)==expected,name
  payload['source/'+name]=raw;sources.append(dict(path=name,bytes=len(raw),sha256=expected,
   basis='pre-build glue freeze; manually linked, not CMake configured' if name in GLUE else 'frozen compiler source/header closure'))
 records=['build.py','publish.py']
 for attempt in ['attempt1','attempt2']:
  records += [attempt+'/'+x for x in ['plan.json','source-freeze.json','canonical-recipes.json']]
  for folder in sorted((W/attempt/'compile').iterdir()):
   records += [p.relative_to(W).as_posix() for p in sorted(folder.iterdir())
    if p.suffix in ['.json','.log']]
 records += ['attempt2/'+x for x in ['ready.json','link-inputs.json','runtime.json',
  'summary.json','partial-results.json','results-cpu.xml','results-cuda.xml','results-region.xml']]
 for stage in ['link','run-cpu','run-cuda','run-region']:
  records += ['attempt2/'+stage+'/'+x for x in ['command.json','process.json','running.json','stdout.log','stderr.log']]
 for name in dict.fromkeys(records):payload['records/'+name]=(W/name).read_bytes()
 # Preserve the exact unchanged leaf/closure identities without copying caches.
 for label,path in [('baseline-ready',Path(plan['baseline']['ready']['path'])),
  ('baseline-inputs',Path(plan['baseline']['inputs']['path'])),
  ('reused-slots-ready',R/'.scratch/inference-slot-bindings-20261027/ready.json')]:
  payload['records/reuse/'+label+'.json']=path.read_bytes()
 failed=read(W/'attempt1/compile/cuda-test/process.json');assert failed['exit']==2
 # Keep original compiler bytes; localized MSVC diagnostics need not be UTF-8.
 assert b'cuda.h' in (W/'attempt1/compile/cuda-test/stdout.log').read_bytes()
 tests=[]
 for name,count in [('cpu',4),('cuda',1),('region',8)]:
  tree=ET.parse(D/('results-'+name+'.xml')).getroot()
  cases=tree.findall('./testsuite/testcase')
  assert len(cases)==count and int(tree.attrib['failures'])==0
  assert all(x.attrib['status']=='run' and not list(x) for x in cases)
  tests.append(dict(group=name,process=read(D/('run-'+name)/'process.json'),
   tests=[x.attrib for x in cases],results=pin(D/('results-'+name+'.xml'))))
 assert all(x['process']['exit']==0 for x in tests)
 assert not any(Path(n).suffix.lower() in ('.obj','.exe','.dll','.pdb','.lib','.bin') for n in payload)
 manifest=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(payload.items())]
 payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
 archive.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,raw in sorted(payload.items()):z.writestr(name,raw)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  assert sorted(z.namelist())==sorted(payload)
  for row in manifest:
   raw=z.read(row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 result=dict(schema=1,batch='inference-slot-store-20261027',status='THIRTEEN_RELEVANT_STORE_GRAPH_TESTS_PASS',
  recorded_at=datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8))).isoformat(),
  scope='Five new actual CPU/CUDA writer-only SlotStore execution cases and eight adjacent nominated-writer/projected-read contracts, all using original Graph/Queue/Completion/lease lifetimes.',
  final_sources=sources,image=ready['image'],ready=pin(D/'ready.json'),summary=pin(D/'summary.json'),
  actual_results=dict(tests=13,new_Store_tests=5,adjacent_contract_tests=8,failures=0,skipped=0,
   distinct_compiled_TUs=6,compile_processes=7,successful_compile_processes=6,link_processes=1,
   test_processes=3,images=1,groups=tests),
  compile_contract='Windows x64; cached MSVC 14.50.35717; /O2 /W4 /WX; six actual CXX sources only. Final actual dependencies checked byte-for-byte against the frozen source/header closure. No source repair was necessary.',
  reuse=dict(original_inputs=221,final_inputs=225,baseline=plan['baseline'],
   changes='Replace resources.cc and graph_batch/batch.cc; remove old CUDA Gather GTest object; add unchanged passed slots.cc object plus new slots_region.cc and three GTest objects.',
   reused_slots_object=plan['old_slots_object'],
   four_passed_objects_reused_after_recipe_failure=['resources','store','batch','cpu-test'],
   no_Store_graphs='Only the existing cold custom-node scan gains a Store type check; no adapter is added without Store presence.',
   runtime='Existing pinned dependency search paths, plus one hardlink of the exact CPU ggml DLL beside the one image. No DLL/SDK tree copied.'),
  retained_failures=[dict(stage='First CUDA GTest compile, attempt1',process=failed,
   cause='The initial CPU-only compile recipe lacked the CUDA Toolkit include needed by public backends/cuda.h; C1083 could not open cuda.h.',
   correction='Use the already passed cuda-gather CXX recipe for that one GTest. Reuse the four already successful objects and compile only the CUDA and not-yet-built region test TUs. No product source change.',
   original_logs='records/attempt1/compile/cuda-test/')],
  verified_boundaries=['F32 CPU/CUDA stores write only the actual selected destinations, preserve the sentinel, and update the same private I32 carrier while reversing writer order on the second episode.',
   'Source/destination overlap and arbitrary replacement ID carriers are rejected before Store execution. Actual unobserved Completion and GraphOutput retention block take.',
   'Reset may succeed but removes the original write effect. Rebinding the same private carrier cannot revive that authority; retired take still recovers the original untouched writers.',
   'The original ResourceEpisode query validates stable InvocationState identity, selected node/step/artifact and complete original ordinary-writer pointer sequence. It grants neither admission nor retirement.'],
  limits=['This is a correctness fallback. It has capture_compatible=false and may wait for each Store metadata upload; it is not wired into the engine or claimed as the final fast path.',
   'No indexed GDN/causal-conv native fusion, automatic projected source-Gather chain binding, model/MTP execution, throughput/latency/memory benchmark, or quality claim.',
   'Only Windows CPU and CUDA device-0 cases ran. No Apple/Linux/Vulkan run or broader test matrix.',
   'The new CMake source/target wiring is archived but not separately configured; no SDK/native dependency rebuild, package/install check, download or server run.'],
  performance_claim=False,model_runs=0,engine_runs=0,SDK_native_builds=0,reconfigure_runs=0,HTTP=0,
  archive=dict(**pin(archive),archive_path=archive.relative_to(R).as_posix(),members=len(payload),
   excludes=['EXE','OBJ','DLL','LIB','PDB','SDK','model payload'],files=manifest))
 receipt.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(dict(receipt=pin(receipt),archive=pin(archive),sources=len(sources),tests=13),indent=2))
if __name__=='__main__':
 if sys.argv[1:]==['publish']:publish()
 else:print(__doc__)
