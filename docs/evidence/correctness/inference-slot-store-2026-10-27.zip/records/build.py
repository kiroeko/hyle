"""Six explicit CXX TUs, one retained closure/image, three finite test groups."""
from pathlib import Path
import importlib.util,json,os,sys,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('cached_frame',R/'.scratch/inference-paged-frame-20261026/build.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);m,b=f.m,f.b
B=R/'.scratch/inference-cuda-slot-gather-20261026'
CPU=R/'.scratch/inference-slot-bindings-20261027'
CPU_RECIPE=R/'.scratch/inference-fused-writer-20261026/empty-rejection-final/compile/test/command.json'
RESOURCE_RECIPE=R/'.scratch/inference-fused-writer-20261026/compile/resources/command.json'
BATCH_OLD=R/'.scratch/inference-current-closure-20261026/unresolved-host/compile/graph_batch--batch_cc/unit.obj'
RESOURCE_OLD=R/'.scratch/inference-bulk-append-20261026/compile/resources/unit.obj'
TEST_OLD=B/'compile2/test/unit.obj'
SLOTS_OLD=CPU/'compile/slots/unit.obj'
SPECS=[('resources','src/graph/resources.cc',RESOURCE_RECIPE),
 ('store','src/graph/slots_region.cc',RESOURCE_RECIPE),
 ('batch','src/graph_batch/batch.cc',BATCH_OLD.parent/'command.json'),
 ('cpu-test','tests/graph/slots_execution_test.cc',CPU_RECIPE),
 ('cuda-test','tests/graph/slots_cuda_execution_test.cc',B/'compile2/test/command.json'),
 ('region-test','tests/graph/region_provider_test.cc',CPU_RECIPE)]
GROUPS=[('cpu','GraphSlotsExecution.*',4),('cuda','GraphSlotsCudaExecution.*',1),
 ('region','GraphRouteBoundary.ProjectedWrite*:GraphRouteBoundary.ProjectedRegion*:GraphRouteBoundary.ProjectedInput*:GraphRouteBoundary.ProjectedReadRelease*',8)]

def environment(p):
 h=b.helper();cl=p['units'][0]['command'][0]
 return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env

def plan(attempt):
 d=W/('attempt'+str(attempt));assert not (d/'plan.json').exists()
 ready=b.read(B/'ready2.json');inputs=b.read(ready['inputs']['path']);assert len(inputs)==221
 for row in inputs:b.exact(row)
 for old in [BATCH_OLD,RESOURCE_OLD,TEST_OLD]:assert sum(b.key(x['path'])==b.key(old) for x in inputs)==1,str(old)
 old_slots=b.read(CPU/'ready.json')['compiled'][0]
 assert old_slots['name']=='slots' and old_slots['source']['sha256']==b.pin(R/'src/graph/slots.cc')['sha256']
 b.exact(old_slots['object'])
 units=[]
 for name,source,recipe in SPECS:
  command=m.command(recipe,R/source,d/'compile'/name)
  if '/I'+str(R/'src/graph') not in command:command.insert(1,'/I'+str(R/'src/graph'))
  assert all(x in command for x in ['/O2','/W4','/WX','/DHYLE_STATIC'])
  units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),command=command))
 canonical=d/'canonical-recipes.json';b.save(canonical,dict(command=[x for u in units for x in u['command']]))
 frozen=m.c.closure([u['source']['path'] for u in units],[canonical]);b.save(d/'source-freeze.json',frozen)
 b.save(d/'plan.json',dict(status='FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(d/'source-freeze.json'),
  baseline=dict(ready=b.pin(B/'ready2.json'),inputs=ready['inputs'],command=b.pin(B/'link2/command.json'),runtime=ready['runtime']),
  old_slots_object=old_slots,compiled_TUs=6,images=1,groups=GROUPS,
  scope='CPU4 / CUDA1 Store actual execution plus 8 adjacent selected-region/projected-release tests. No engine/perf/native/SDK build or download. Shared original 221-input CUDA closure; additive Graph API headers do not alter reused object ABI. slots.cc body/object unchanged and explicitly retained.'))
 print('PLAN',json.dumps(b.pin(d/'plan.json')),flush=True)

def build(attempt):
 d=W/('attempt'+str(attempt));p=b.read(d/'plan.json');assert not (d/'ready.json').exists()
 frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
 for row in frozen:b.exact(row)
 for row in b.read(p['baseline']['inputs']['path']):b.exact(row)
 h,env=environment(p);results=[];objects={}
 for unit in p['units']:
  out=d/'compile'/unit['name'];record=None
  # Only successful exact previous-TU inputs can be reused after a minimal fix.
  for prior in range(attempt-1,0,-1):
   q=W/('attempt'+str(prior))/'compile'/unit['name']
   if not (q/'success.json').exists():continue
   candidate=b.read(q/'success.json')
   if candidate['source']['sha256']!=unit['source']['sha256']:continue
   try:
    for row in b.read(candidate['actual_dependencies']['path']):b.exact(row)
    b.exact(candidate['object'])
   except (AssertionError,FileNotFoundError):continue
   record=dict(candidate,reused_compile=True);break
  if record is None:
   process=h.execute(unit['command'],env,out,timeout=180)
   deps=b.read(out/'dependencies.json')['Data']
   actual=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
   for row in actual:
    path=Path(row['path'])
    if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
     assert own[b.key(path)]['sha256']==row['sha256'],str(path)
   b.save(out/'actual-dependencies.json',actual)
   record=dict(name=unit['name'],source=unit['source'],object=b.pin(out/'unit.obj'),process=process,
    actual_dependencies=b.pin(out/'actual-dependencies.json'),reused_compile=False)
   b.save(out/'success.json',record)
  objects[unit['name']]=record['object'];results.append(record)
  for row in frozen:b.exact(row)
  print('COMPILED',unit['name'],json.dumps(record['process']), 'reused='+str(record['reused_compile']),flush=True)
 replace={b.key(RESOURCE_OLD):objects['resources']['path'],b.key(BATCH_OLD):objects['batch']['path']}
 image=d/'bin/slot-store-test.exe';args=[];changed=dropped=0
 for arg in b.read(p['baseline']['command']['path'])['command']:
  if b.key(arg)==b.key(TEST_OLD):dropped+=1;continue
  if b.key(arg) in replace:arg=replace[b.key(arg)];changed+=1
  elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
  elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
  elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
  elif arg.upper().startswith('/MAP:'):continue
  args.append(arg)
 assert changed==2 and dropped==1
 additions=[p['old_slots_object']['object'],objects['store'],objects['cpu-test'],objects['cuda-test'],objects['region-test']]
 args.extend(x['path'] for x in additions);image.parent.mkdir(parents=True,exist_ok=True)
 linked=h.execute(args,env,d/'link',timeout=120)
 inputs=[b.pin(replace.get(b.key(x['path']),x['path'])) for x in b.read(p['baseline']['inputs']['path']) if b.key(x['path'])!=b.key(TEST_OLD)]+additions
 assert len(inputs)==225;b.save(d/'link-inputs.json',inputs)
 rt=b.read(p['baseline']['runtime']['path']);cpu_rt=b.read(CPU/'runtime.json')
 b.exact(cpu_rt['native']);alias=image.parent/Path(cpu_rt['native']['path']).name
 assert not alias.exists();os.link(cpu_rt['native']['path'],alias)
 rt['native_cpu']=cpu_rt['native'];rt['native_cpu_hardlink']=b.pin(alias)
 rt['PATH']=rt['PATH']+';'+cpu_rt['PATH']+';'+env['PATH'];b.save(d/'runtime.json',rt)
 b.save(d/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=linked,
  inputs=b.pin(d/'link-inputs.json'),runtime=b.pin(d/'runtime.json'),plan=b.pin(d/'plan.json'),native_SDK_engine_builds=0))
 print('READY',json.dumps(b.pin(d/'ready.json')),flush=True)

def run(attempt):
 d=W/('attempt'+str(attempt));p=b.read(d/'plan.json');ready=b.read(d/'ready.json');b.exact(ready['image'])
 h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH'];results=[]
 for name,filter,count in GROUPS:
  xml=d/('results-'+name+'.xml')
  process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(xml)],env,d/('run-'+name),timeout=90)
  tree=ET.parse(xml).getroot();cases=tree.findall('./testsuite/testcase')
  assert int(tree.attrib['tests'])==count and len(cases)==count and int(tree.attrib['failures'])==0
  assert all(x.attrib.get('status')=='run' and not list(x) for x in cases)
  results.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)))
  b.save(d/'partial-results.json',results);print('PASSED',name,count,flush=True)
 b.save(d/'summary.json',dict(status='THIRTEEN_RELEVANT_STORE_GRAPH_TESTS_PASS',ready=b.pin(d/'ready.json'),groups=results,
  tests=13,failures=0,compiled_distinct_TUs=6,images=1,processes=3,SDK_native_engine_perf_runs=0,HTTP=0,scope=p['scope']))
 print('SUMMARY',json.dumps(b.pin(d/'summary.json')),flush=True)

if __name__=='__main__':
 attempt=int(sys.argv[2]) if len(sys.argv)>2 else 1
 try:{'plan':plan,'build':build,'run':run}[sys.argv[1]](attempt)
 except BaseException:
  print(traceback.format_exc(),flush=True)
  raise
