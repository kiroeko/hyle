from pathlib import Path
import json,os,sys,subprocess,time,hashlib
R=Path.cwd();O=R/'.scratch/dspark-random-mtp-20261024';L=O/'pro-natural';L.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
cc=json.loads((O/'compile-command.json').read_text(encoding='utf-8'))[0]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
base=json.loads((R/'.scratch/dspark-block5-tail-20261024/short-verifier/link-command.json').read_text(encoding='utf-8'))
cmd=[];replaced=0
for a in base:
 if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
 if a.replace('\\','/').endswith('/short-verifier/consumer.obj'):a=str(O/'consumer.obj');replaced+=1
 cmd.append(a)
assert replaced==1
cmd+=['/OUT:'+str(O/'checks.exe'),'/IMPLIB:'+str(O/'checks.lib')]
(L/'link-command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8');start=time.monotonic()
with (L/'link.log').open('wb')as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
(L/'link-process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8')
print('link',p.returncode,(L/'link.log').read_text(encoding='utf-8',errors='replace')[-3000:]);assert not p.returncode
ready=json.loads((R/'.scratch/engine-product-20261024/cpu-budget-fix1/engine-ready.json').read_text(encoding='utf-8'))
worker=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll';staged=O/worker.name
if not staged.exists():os.link(worker,staged)
S=R/'.scratch/dspark-pro-target-draft-20261023'
for k in list(env):
 if k.startswith('HYLE_DSPARK_') and ('WAIT' in k or 'FRONTIER' in k):env.pop(k,None)
env.update(PATH=str(O)+';'+ready['PATH'],HYLE_DSPARK_FORMAL_FLASH_DIR=str(S/'formal-flash/original-dense'),HYLE_DSPARK_FLASH_EXPERT_DIR=str(S/'formal-flash/original-experts'),HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS='0',HYLE_DSPARK_FLASH_FRONTIER_FILE=str(O/'missing-frontier.json'),HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR=str(R/'.scratch/dspark-original-target-tail-20261023/original-target'),HYLE_DSPARK_SHARED_VOCAB_DIR=str(R/'.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary'))
env.update(HYLE_DSPARK_PRO_DIR=str(S/'original-dense'),HYLE_DSPARK_PRO_EXPERT_DIR=str(S/'original-experts'),HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS='0',HYLE_DSPARK_PRO_FRONTIER_FILE=str(L/'missing-frontier.json'))
(L/'runtime.json').write_text(json.dumps({k:v for k,v in env.items()if k.startswith('HYLE_DSPARK_')or k=='PATH'},indent=2),encoding='utf-8')
cmd=[str(O/'checks.exe'),'--gtest_color=no','--gtest_filter='+(sys.argv[1] if len(sys.argv)>1 else 'DSparkFlashFormalState.CpuRandomMarkovPrefixCommitsActualStateAndCursor'),'--gtest_output=xml:'+str(L/'results.xml')]
(L/'run-command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8');start=time.monotonic()
with (L/'run.log').open('wb')as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=600)
(L/'run-process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8')
print('run',p.returncode,(L/'run.log').read_text(encoding='utf-8',errors='replace')[-10000:])
