#pragma once

#include <array>
#include <bit>
#include <initializer_list>
#include <stdexcept>
#include <vector>

#include "d5_qwen38_24t_semantic_fragments.h"
#include "../../engine/inference/sampling_graph.h"

// Only fixed-shape recipe declaration adaption. Local fragment identities stay
// local; no Graph generation is forged and no sampling mathematics is copied.
namespace model_sampling_fragment {
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace c = hyle::compute;
namespace g = hyle::graph;
using Value = sem::ValueId;

class Builder final {
  sem::Fragment &fragment_;
public:
  explicit Builder(sem::Fragment &fragment) noexcept : fragment_(fragment) {}
  Value value(Value original) const noexcept { return original; }
  Value local(Value original) const noexcept { return original; }
  g::TensorSpec spec(Value value) const {
    auto result = g::TensorSpec::concrete(fragment_.description(value));
    if (!result) throw std::runtime_error(std::string(result.error().message()));
    return std::move(*result);
  }
  Value input(c::TensorDesc description) { return fragment_.input(std::move(description)); }
  Value constant(c::TensorDesc description, std::vector<std::byte> bytes) {
    return fragment_.constant(std::move(description), std::move(bytes));
  }
  Value scalar(float value) {
    return constant(sem::dense({1}), sem::bytes(std::vector{value}));
  }
  std::vector<Value> op(c::Operation operation, std::initializer_list<Value> ports) {
    const auto count = c::operation_traits(operation).outputs;
    return fragment_.append(std::move(operation), ports, count);
  }
  template<class Operation>
  Value one(Operation operation, std::initializer_list<Value> ports) {
    return fragment_.one(c::Operation(std::move(operation)), ports);
  }
  Value copy(Value value) { return one(c::Copy{}, {value}); }
  Value cast(Value value, c::DataType type) { return one(c::Cast{.output_type=type}, {value}); }
  Value unary(c::UnaryKind kind, Value value) { return one(c::Unary{kind}, {value}); }
  Value binary(c::BinaryKind kind, Value a, Value b) { return one(c::Binary{kind}, {a,b}); }
  Value reshape(Value value, std::initializer_list<g::Dimension> shape) {
    std::vector<std::int64_t> extents;
    for (const auto dimension : shape) {
      if (!dimension.is_fixed()) throw std::runtime_error("sampling fragment shape must be fixed");
      extents.push_back(dimension.fixed_value());
    }
    auto actual = c::TensorShape::create(extents);
    if (!actual) throw std::runtime_error(std::string(actual.error().message()));
    auto view = c::View::reshape(*actual);
    if (!view) throw std::runtime_error(std::string(view.error().message()));
    return one(*view,{value});
  }
  Value slice(Value value, std::uint32_t axis, g::Dimension offset, g::Dimension count) {
    if (!offset.is_fixed() || !count.is_fixed())
      throw std::runtime_error("sampling fragment slice must be fixed");
    auto view = c::View::slice(axis,offset.fixed_value(),count.fixed_value());
    if (!view) throw std::runtime_error(std::string(view.error().message()));
    return one(*view,{value});
  }
  std::size_t publish(Value value) {
    fragment_.outputs.push_back(value);
    return fragment_.outputs.size()-1;
  }
};
} // namespace model_sampling_fragment
