#pragma once

#include "dspark_original_draft_program.h"
#include "model_sampling_fragment.h"

// Source-specific Markov head wiring only. All distribution, draws and
// speculative acceptance mathematics are shared with the inference engine.
namespace dspark_stochastic_head {
namespace own = dspark_original_formal_roles;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace c = hyle::compute;
namespace s = hyle::inference::sampling;
using Value = sem::ValueId;
using s::fixed;
struct Proposal final {
  sem::Fragment fragment;
  std::vector<dspark_original_draft_program::Constant> constants;
  std::size_t ids = 0;
  std::vector<std::size_t> q, valid, adjusted, markov, confidence;
};
inline Proposal proposal(const own::Bound &bound, std::size_t count, s::Policy policy,
    const c::ModelArtifactProfileDescription *profile) {
  if (!count || count > 5) throw std::runtime_error("DSpark stochastic head needs1..5 trained draft rows");
  if(!bound.source) throw std::runtime_error("DSpark stochastic head needs its authenticated original source");
  bound.source->geometry().validate();
  Proposal result;
  result.fragment.profile = dspark_original_draft_program::checked_profile(*bound.source,profile);
  result.fragment.region = 0x0ca34000 + count;
  result.fragment.phase = c::WorkloadPhase::kDecode;
  auto &f = result.fragment;
  model_sampling_fragment::Builder r(f);
  const auto &geometry = bound.source->geometry();
  const auto base = r.input(sem::dense({5,dspark_original_draft_fragment::kVocabulary}));
  auto previous = r.input(sem::dense({1},c::DataType::kInt32));
  const auto keys = r.input(sem::dense({std::int64_t(count),4},c::DataType::kUInt32));
  const auto hidden = r.input(sem::dense({5,geometry.hidden},c::DataType::kBFloat16));
  const auto &first=bound.at(own::Section::kDraft,2,"markov_head.markov_w1.weight");
  if(first.description.rank()!=2)throw std::runtime_error("DSpark Markov source must be a rank2 BF16 vocabulary table");
  const auto rank=first.description.dimensions()[1];
  if(rank<=0||rank>(std::numeric_limits<std::int32_t>::max)()-geometry.hidden)
    throw std::runtime_error("DSpark Markov/confidence source geometry exceeds I32");
  const auto parameter = [&](std::string_view suffix,const c::TensorDesc &expected) {
    const auto &role = bound.at(own::Section::kDraft,2,suffix);
    return dspark_original_draft_program::immutable(f,result.constants,role,expected);
  };
  const auto markov_shape=sem::dense({dspark_original_draft_fragment::kVocabulary,rank},c::DataType::kBFloat16);
  const auto w1=parameter("markov_head.markov_w1.weight",markov_shape),w2=parameter("markov_head.markov_w2.weight",markov_shape);
  const auto confidence=parameter("confidence_head.proj.weight",sem::dense({1,geometry.hidden+rank},c::DataType::kBFloat16));
  auto ids=previous;
  const auto publish=[&](Value value) {return r.publish(r.copy(value));};
  for(std::size_t row=0;row<count;++row) {
    // This is the sampled preceding ID, never the old greedy head's ID.
    const auto markov=r.one(c::Gather{}, {w1,previous});
    const auto bias=r.one(c::model_ops::dense_linear_f32(), {markov,w2});
    const auto logits=r.binary(c::BinaryKind::kAdd,
        r.copy(r.slice(base,0,fixed(std::int64_t(row)),fixed(1))),bias);
    const auto distribution=s::distribution(r,logits,policy);
    const auto identity=r.copy(r.slice(keys,0,fixed(std::int64_t(row)),fixed(1)));
    previous=r.one(c::sampling_ops::categorical(), {distribution.log_probabilities,identity});
    ids=r.one(c::Concat{.axis=0}, {ids,previous});
    const auto confidence_input=r.one(c::Concat{.axis=1},
        {r.copy(r.slice(hidden,0,fixed(std::int64_t(row)),fixed(1))),markov});
    result.confidence.push_back(publish(r.one(c::model_ops::dense_linear_f32(), {confidence_input,confidence})));
    result.q.push_back(publish(distribution.log_probabilities));result.valid.push_back(publish(distribution.valid));
    result.adjusted.push_back(publish(logits));result.markov.push_back(publish(markov));
  }
  result.ids=publish(ids);
  return result;
}
struct Verification final {
  sem::Fragment fragment;
  std::vector<dspark_original_draft_program::Constant> constants;
  std::vector<std::size_t> accepted, final_ids, valid;
};
inline Verification verification(std::size_t count,s::Policy policy,
    const c::ModelArtifactProfileDescription *profile) {
  if(count>5) throw std::runtime_error("DSpark stochastic verifier exceeds trained block5");
  Verification result;auto &f=result.fragment;f.profile=profile;f.region=0x0ca35000+count;
  f.phase=c::WorkloadPhase::kDecode;model_sampling_fragment::Builder r(f);
  const auto logits=r.input(sem::dense({std::int64_t(count+1),dspark_original_draft_fragment::kVocabulary}));
  const auto keys=r.input(sem::dense({std::int64_t(count+1),4},c::DataType::kUInt32));
  const auto ids=count?r.input(sem::dense({std::int64_t(count)},c::DataType::kInt32)):Value{};
  const auto decision=s::speculative_prefix(r,logits,keys,ids,policy);
  for(const auto value:decision.accepted)result.accepted.push_back(r.publish(r.copy(value)));
  for(const auto value:decision.final_ids)result.final_ids.push_back(r.publish(r.copy(value)));
  for(const auto value:decision.valid)result.valid.push_back(r.publish(r.copy(value)));
  return result;
}
} // namespace dspark_stochastic_head
