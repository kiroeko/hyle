from pathlib import Path
import hashlib, json, os, subprocess, sys, time, zipfile

base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
out = base / 'g02-native-page-joint-long-stage'
out.mkdir(exist_ok=True)
identity = {name: subprocess.check_output(args, text=True).strip() for name, args in [
    ('model', ['/usr/sbin/sysctl', '-n', 'hw.model']), ('arch', ['uname', '-m']),
    ('os', ['sw_vers']), ('compiler', ['xcrun', 'clang', '--version']),
    ('cpu', ['/usr/sbin/sysctl', '-n', 'hw.ncpu']), ('memory', ['/usr/sbin/sysctl', '-n', 'hw.memsize'])]}
assert identity['model'] == 'Mac16,12' and identity['arch'] == 'arm64'
assert source.is_dir() and not (source / '.git').exists()
# The immutable G01 performance source is a different directory. Do not edit it.
job = base / 'g01-native-page-vulkan-p1-job/job.json'
while json.loads(job.read_bytes())['state'] != 'TERMINAL':
    print('WAIT existing Vulkan P1; no overlapping heavy job', flush=True)
    time.sleep(15)
input_name=sys.argv[1]
with zipfile.ZipFile(out / input_name) as archive:
    manifest = json.loads(archive.read('input-manifest.json'))
    changed = []
    for item in manifest:
        relative = Path(item['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        data = archive.read(item['path'])
        assert hashlib.sha256(data).hexdigest() == item['sha256']
        destination = source / relative
        if not destination.exists() or destination.read_bytes() != data:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            changed.append(item['path'])
        assert hashlib.sha256(destination.read_bytes()).hexdigest() == item['sha256']
(out / 'synced-inputs.json').write_text(json.dumps({'one_way': True, 'source': str(source),
    'base': '06d8a394e', 'candidate': 'AUDITED WORKTREE draft', 'inputs': manifest, 'changed': changed}, indent=2)+'\n')
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']
record = out / 'result.json'
previous = json.loads(record.read_bytes()) if record.exists() else {}
rows = previous.get('stages', [])
old_digest = hashlib.sha256(json.dumps(previous.get('inputs', []), sort_keys=True).encode()).hexdigest()
new_digest = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
for row in rows:
    row.setdefault('input_manifest_sha256', old_digest)
def run(route, stage, args):
    attempt = 1 + sum(r['route'] == route and r['stage'] == stage for r in rows)
    log = out / f'{route}-{stage}-{attempt}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        result = subprocess.run(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
    row = {'route': route, 'stage': stage, 'attempt': attempt, 'command': args,
           'exit_code': result.returncode, 'input_manifest_sha256': new_digest, 'elapsed_seconds': time.monotonic()-start, 'log': str(log)}
    rows.append(row)
    record.write_text(json.dumps({'identity': identity, 'candidate': 'AUDITED WORKTREE draft',
        'scope': 'actual CPU/native page/CPU, public hyle::graph; original ordinary contracts',
        'inputs': manifest, 'stages': rows,
        'cumulative_seconds': sum(r['elapsed_seconds'] for r in rows)}, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-7000:], flush=True)
        raise SystemExit(result.returncode)

for route, contract in [('apple', 'hyle_h2_contracts'), ('vulkan', 'hyle_h3_cpu_vulkan_contracts')]:
    if len(sys.argv) > 2 and route != sys.argv[2]:
        continue
    parent = base / f'a-cpu-{route}/selected-graph/source-parent'
    build = base / f'a-cpu-{route}/selected-graph/source-build'
    cmake = parent / 'CMakeLists.txt'
    addition = '\nadd_executable(g02_native_page_joint_long "'+str(source/'tests/graph_batch/native_paged_joint_consumer.cc')+'")\n'
    addition += 'target_compile_features(g02_native_page_joint_long PRIVATE cxx_std_23)\n'
    addition += 'target_compile_options(g02_native_page_joint_long PRIVATE -Wall -Wextra -Wpedantic -Werror)\n'
    addition += 'target_link_libraries(g02_native_page_joint_long PRIVATE hyle::graph)\n'
    if route == 'apple':
        addition += 'target_compile_definitions(g02_native_page_joint_long PRIVATE HYLE_JOINT_PAGE_APPLE=1)\n'
    addition += 'hyle_stage_runtime(g02_native_page_joint_long)\n'
    old = cmake.read_text()
    if 'add_executable(g02_native_page_joint_long ' not in old:
        cmake.write_text(old + addition)
    cache = (build/'CMakeCache.txt').read_text().splitlines()
    assert str(parent) == next(s.split('=',1)[1] for s in cache if s.startswith('CMAKE_HOME_DIRECTORY:'))
    run(route, 'configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build)])
    reference = 'hyle_f5_materialized_native'
    risks = 'hyle_g01_native_page_' + route + '_risks'
    run(route, 'build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', 'g02_native_page_joint_long', '--parallel', '4'])
    run(route, 'joint', [str(build/'g02_native_page_joint_long')])
    commands = json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],text=True))
    selected = []
    for suffix in [f'src/graph_route_cpu_{route}/compile.cc', f'src/graph_route_cpu_{route}/invocation.cc',
                   'src/graph_batch/native_paged_node.cc', 'tests/graph_batch/native_paged_joint_consumer.cc']:
        found = [item for item in commands if item['file'].endswith(suffix)]
        assert found, suffix
        selected.extend(found)
    (out/f'{route}-compiled-inputs.json').write_text(json.dumps(selected,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in out.iterdir():
        if path.is_file() and path.suffix in ['.json','.log','.py']:
            archive.write(path,path.name)
