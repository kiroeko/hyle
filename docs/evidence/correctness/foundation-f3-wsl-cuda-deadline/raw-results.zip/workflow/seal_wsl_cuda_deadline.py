from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'
cuda = scratch / 'wsl-cuda-logs'; job = json.loads((cuda / 'job.json').read_text())
assert job['verdict'] == 'PASS_WSL_F3_CUDA_SIX_RISKS_ONLY'
for row in job['stages']:
    assert row['state'] == 'terminal'
    assert row['exit_code'] == (1 if row['name'] == 'configure' else 0)
    assert hashlib.sha256((cuda / row['log']).read_bytes()).hexdigest() == row['sha256']
tests = ET.parse(cuda / 'files.xml').getroot()
assert tests.attrib['tests'] == '6' and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
cpu = scratch / 'cpu-subject-windows-1'; cpu_job = json.loads((cpu / 'job.json').read_text())
attempt = 'deadline-close-warning'
resume = next(row for row in cpu_job['resumes'] if row['attempt'] == attempt)
for row in resume['inputs']:
    assert hashlib.sha256((repo / row['path']).read_bytes()).hexdigest() == row['sha256']
for row in cpu_job['stages']:
    if row['name'] not in ['build-' + attempt, 'files-' + attempt]: continue
    assert row['state'] == 'terminal' and row['exit_code'] == 0
    assert hashlib.sha256((cpu / row['log']).read_bytes()).hexdigest() == row['sha256']
tests = ET.parse(cpu / ('files-' + attempt + '.xml')).getroot()
assert tests.attrib['tests'] == '12' and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
out = repo / 'evidence/correctness/foundation-f3-wsl-cuda-deadline'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for path in sorted(cuda.iterdir()):
        if path.is_file(): packed.writestr('wsl-cuda/' + path.name, path.read_bytes())
    for name in ['job.json', 'build-' + attempt + '.log', 'files-' + attempt + '.log', 'files-' + attempt + '.xml']:
        packed.writestr('windows-cpu/' + name, (cpu / name).read_bytes())
    packed.writestr('warning-equivalence.json', (scratch / 'warning-equivalence.json').read_bytes())
    for name in ['run_wsl_gates.py', 'resume_wsl_cuda_configuration.py', 'resume_cpu_subject_windows.py', 'seal_wsl_cuda_deadline.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1,
    'wsl_cuda': {'fixture_commit': job['candidate'], 'product_commit': 'f3d931c47777f7fbfd35dedf1f5e0734fa28ef6c',
                 'identity': job['identity'], 'tests_passed': 6, 'parallel': 4,
                 'risks': 'Real two-slot read/write/replay/EOF, pending original native producer ordering, cancel/abandon retention, normal and empty hard error.'},
    'windows_cpu': {'fixture_commit': '332026e43164e285ea890e92487bcfb9844aebab',
                    'product_commit': '3b7b9b9b8f0e99205de0c43ce29b4467bdae46d5',
                    'compiler': cpu_job['compiler'], 'inputs': resume['inputs'], 'tests_passed': 12,
                    'risks': 'Original eleven Windows risks plus expired monotonic deadline before IO/native acceptance and repeat stop/close/drain without closing borrowed user resources.'},
    'original_failures': 'WSL initial configure mutual-exclusion failure retained; fixed verification argv in same build tree, no product repair/budget reset.',
    'scope': 'Only F3 WSL CUDA native six risks and current Windows CPU twelve risks, no installed/full closure claim.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_WSL_CUDA_SIX_WINDOWS_CPU_TWELVE_F3_RISKS_ONLY',
    'unproven': ['Air CPU thirteen risks', 'Remaining current route formatting regressions', 'Installed deliveries/new heads/absence/relocation', 'Final red team/closure']}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('Actual WSL CUDA six and current Windows CPU twelve terminal tests verified and archived.')
