from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess

root = Path('/root/hyle-scratch/compute-unified/foundation-f3-cuda-c36c40bed')
job = json.loads((root / 'job.json').read_text())
assert job['stages'][-1]['exit_code'] == 1
assert 'HYLE_DEV_FACTORS and HYLE_COMPONENTS are mutually exclusive' in (root / 'configure.log').read_text()
assert not (root / 'configure-factors.log').exists()
source, build = Path(job['source']), Path(job['build'])
env = os.environ.copy()
env.update(PATH='/usr/local/cuda-13.3/bin:/usr/lib/wsl/lib:/usr/bin:/bin:/usr/sbin:/sbin',
           CUDA_HOME='/usr/local/cuda-13.3', CUDA_PATH='/usr/local/cuda-13.3',
           CUDAToolkit_ROOT='/usr/local/cuda-13.3', CUDACXX='/usr/local/cuda-13.3/bin/nvcc')
commands = [
    ('configure-factors', ['/usr/bin/cmake', '-S', str(source), '-B', str(build),
        '-DHYLE_DEV_FACTORS=compute_route_cuda;compute_stream', '-UHYLE_COMPONENTS', '-UHYLE_COMPUTE_ROUTES',
        '-DHYLE_BUILD_TESTS=ON', '-DHYLE_INSTALL=OFF'], 300),
    ('build', ['/usr/bin/cmake', '--build', str(build), '--target', 'hyle_compute_route_cuda_file_stream_test',
               '--parallel', '4'], 1800),
    ('files', [str(build / 'bin/hyle_compute_route_cuda_file_stream_test'), '--gtest_filter=CudaFileStream.*',
               '--gtest_output=xml:' + str(root / 'files.xml')], 120)]
for name, command, timeout in commands:
    available = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
    assert available >= 4 * 1024**3
    if '--parallel' in command:
        command[command.index('--parallel') + 1] = str(4 if available >= 12 * 1024**3 else 2 if available >= 8 * 1024**3 else 1)
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=source, env=env, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running',
               'available_bytes': available, 'log': log.name, 'budget_seconds': timeout}
        job['stages'].append(row)
        (root / 'job.json').write_text(json.dumps(job, indent=2))
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            row.update(state='terminal', verdict='TIMEOUT')
            (root / 'job.json').write_text(json.dumps(job, indent=2))
            raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL',
                   sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(job, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
job['verdict'] = 'PASS_WSL_F3_CUDA_SIX_RISKS_ONLY'
(root / 'job.json').write_text(json.dumps(job, indent=2))
