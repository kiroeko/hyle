from pathlib import Path
import base64,json,subprocess,time,hashlib
W=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-native-host-image-20261026'
names=['hardware.json','ready.json','summary.json','actual-dependencies.json','test.o.d','leases.o.d']
for stage in ['compile-test','compile-leases','link','run-apple','run-cpu']:
 names += [stage+'/'+name for name in ['command.json','running.json','process.json','stdout.log','stderr.log']]
code=f'''from pathlib import Path\nimport json,base64,hashlib\nw=Path({REMOTE!r});p=json.loads((w/'plan.json').read_text())\nargs=p['jobs'][-1]['command'];rows=[]\nfor x in args:\n q=Path(x)\n if q.is_absolute() and q.suffix in ('.o','.a','.dylib'):\n  s=q.stat();rows.append({{'path':x,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns}})\nr={{'actual_link_files':len(rows),'inputs':rows,'replacement':p['replacements'],'force_load_or_all_load':[x for x in args if 'force_load' in x or 'all_load' in x],'scope':'Actual102 path/stat inventory; no claim that retained SDK archives are rebuilt current. Exact current test/leases objects and image hashes are in ready.json; replacement budget source/symbol proof is in budget-abi.json.'}}\n(w/'link-inputs.json').write_text(json.dumps(r,indent=2)+'\\n')\nfiles={{n:base64.b64encode((w/n).read_bytes()).decode() for n in {names+['link-inputs.json']!r}}}\nprint(json.dumps(files))\n'''
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -'];start=time.perf_counter()
p=subprocess.run(cmd,input=code,text=True,capture_output=True,timeout=30)
(W/'collect-process.json').write_text(json.dumps(dict(command=cmd,exit=p.returncode,seconds=time.perf_counter()-start,stderr=p.stderr),indent=2)+'\n')
assert p.returncode==0,p.stderr
files=json.loads(p.stdout)
for name,data in files.items():
 target=W/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists(),name
 target.write_bytes(base64.b64decode(data))
inventory=[dict(path=name,bytes=(W/name).stat().st_size,sha256=hashlib.sha256((W/name).read_bytes()).hexdigest()) for name in sorted(files)]
(W/'collected-files.json').write_text(json.dumps(inventory,indent=2)+'\n')
print((W/'summary.json').read_text())
for name in ['run-apple/stdout.log','run-apple/stderr.log','run-cpu/stdout.log','run-cpu/stderr.log']:print(name,repr((W/name).read_text()))
print('ready',json.loads((W/'ready.json').read_text())['image'])
print('link_inputs',json.loads((W/'link-inputs.json').read_text())['actual_link_files'])
