"""Reuse portability Model/weights; replace the last two old API callers."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'vulkan-model-attempt3';A=W/'vulkan-model-attempt4'
spec=importlib.util.spec_from_file_location('model_build',W/'vulkan-model.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b
p=b.read(P/'plan.json');inputs=b.read(p['inputs']['path'])
for x in b.read(p['source_freeze']['path']):b.exact(x)
regions=b.read(W/'current-vulkan-regions/ready.json')['units'];pairs=[]
for unit in regions:
    old=next(x for x in inputs if x['path'].endswith('src--graph_route_vulkan--'+unit['name']+'-cc\\unit.obj'))
    b.exact(unit['object']);pairs.append(dict(old=old,new=unit['object']))
replace={b.key(x['old']['path']):x['new'] for x in pairs};command=[];count=0
image=A/'link/host-image-vulkan-test.exe'
for arg in b.read(P/'link/command.json')['command']:
    if b.key(arg) in replace:arg=replace[b.key(arg)]['path'];count+=1
    elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
    elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
    command.append(arg)
assert count==2
objects=[b.pin(P/'compile'/name/'unit.obj') for name in ['model','weights']]
b.save(A/'plan.json',dict(prior_plan=b.pin(P/'plan.json'),source_freeze=p['source_freeze'],
    reused_Model_weights=objects,replacements=pairs,compiled_TUs=0,SDK_native_shader_builds=0,
    API_correction='Removed public schema() name is now origin_schema(), still by-value; detail access has its separate const-reference accessor. Previous inference that a return-type-only change caused this is superseded.',
    initial_failures_preserved=['windows-attempt1 compile','windows-attempt2 link','vulkan-model-attempt1 link','vulkan-model-attempt2 link','vulkan-layout-diagnostic3 link','vulkan-model-attempt3 link']))
h=b.helper();compiler=p['units'][0]['command'][0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
linked=h.execute(command,env,image.parent,timeout=120)
allreplace={b.key(x['old']['path']):x['new'] for x in p['replacements']+pairs}
final=[allreplace.get(b.key(x['path']),x) for x in inputs if x!=p['removed_model']]+objects+[p['added_report']]
b.save(A/'link-inputs.json',final);b.save(A/'runtime.json',b.read(p['runtime']['path']))
native=Path(p['native']['path']);os.link(native,image.parent/native.name)
b.save(A/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),runtime=b.pin(A/'runtime.json'),
    inputs=b.pin(A/'link-inputs.json'),plan=b.pin(A/'plan.json'),compiled_TUs=0,link=linked,
    current_Model_weights_compile_receipts=[b.pin(P/'compile'/name/'process.json') for name in ['model','weights']]))
print('VULKAN_FINAL_READY',json.dumps(b.pin(A/'ready.json')),flush=True)
