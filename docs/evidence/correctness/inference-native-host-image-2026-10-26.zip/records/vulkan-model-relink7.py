"""Relink current Model/weights, supplying the exact verbose-identified program owner."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'vulkan-model-attempt6';A=W/'vulkan-model-attempt7'
spec=importlib.util.spec_from_file_location('model_build',W/'vulkan-model.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b
base=b.read(W/'vulkan-model-attempt3/plan.json')
for x in b.read(base['source_freeze']['path']):b.exact(x)
added=[x['object'] for x in b.read(W/'current-vulkan-program/ready.json')['units']]
image=A/'link/host-image-vulkan-test.exe';command=[]
for arg in b.read(P/'link/command.json')['command']:
    if arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
    elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
    command.append(arg)
command[1:1]=[x['path'] for x in added]
b.save(A/'plan.json',dict(prior_failed_link=b.pin(P/'link/command.json'),source_freeze=base['source_freeze'],
    added_direct_objects=added,compiled_TUs=0,archive_rewrites=0,
    origin='Exact /VERBOSE trigger route.lib(route--vulkan_program.obj) requires removed public schema(). Supply current vulkan_program.cc; no member-order inference or archive change.'))
h=b.helper();compiler=base['units'][0]['command'][0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
linked=h.execute(command,env,image.parent,timeout=120)
inputs=[b.pin(x) for x in command if Path(x).is_absolute() and x.endswith(('.obj','.lib'))]
b.save(A/'link-inputs.json',inputs);b.save(A/'runtime.json',b.read(base['runtime']['path']))
native=Path(base['native']['path']);os.link(native,image.parent/native.name)
b.save(A/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),runtime=b.pin(A/'runtime.json'),
    inputs=b.pin(A/'link-inputs.json'),plan=b.pin(A/'plan.json'),compiled_TUs=0,link=linked))
print('VULKAN_FINAL_READY',json.dumps(b.pin(A/'ready.json')),flush=True)
