"""Reuse the successful attempt2 test OBJ; replace stale direct budget only."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'windows-attempt2';A=W/'windows-attempt3'
spec=importlib.util.spec_from_file_location('transfer_build',W/'windows.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b
p=b.read(P/'plan.json');b.exact(p['source'])
old=next(x for x in b.read(p['inputs']['path']) if x['path'].endswith('cpu-budget-fix1\\budget\\budget.obj'))
new=b.pin(R/'.scratch/inference-cache-shared-source-20261025/attempt1/budget/unit.obj')
obj=b.pin(P/'compile/unit.obj');image=A/'link/state-transfer-test.exe'
command=[];count=0
for arg in b.read(P/'link/command.json')['command']:
    if b.key(arg)==b.key(old['path']):arg=new['path'];count+=1
    elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
    elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
    command.append(arg)
assert count==1
b.save(A/'plan.json',dict(source=p['source'],prior_plan=b.pin(P/'plan.json'),
    prior_failed_link=b.pin(P/'link/command.json'),reused_test_object=obj,
    budget_old=old,budget_new=new,symbol_check=b.pin(W/'budget-symbol-check.json'),
    reason='Old Vulkan direct resource_budget OBJ lacked six current ABI definitions. Current existing CUDA closure budget defines them; feature-independent core object, no recompile.',
    compiled_TUs=0,archive_rewrites=0,Model_weights_report_native_SDK_builds=0))
h=b.helper();compiler=p['compile_command'][0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
linked=h.execute(command,env,image.parent,timeout=120)
replacement={b.key(x['old']['path']):x['new'] for x in p['replacements']};replacement[b.key(old['path'])]=new
inputs=[replacement.get(b.key(x['path']),x) for x in b.read(p['inputs']['path']) if x not in p['removed']]+[obj]
b.save(A/'link-inputs.json',inputs)
native=Path(p['native']['path']);os.link(native,image.parent/native.name)
b.save(A/'runtime.json',b.read(p['runtime']['path']))
b.save(A/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),object=obj,
    plan=b.pin(A/'plan.json'),runtime=b.pin(A/'runtime.json'),link_inputs=b.pin(A/'link-inputs.json'),
    reused_compile=b.pin(P/'compile/process.json'),link=linked,compiled_TUs=0))
print('RELINK_READY',json.dumps(b.pin(A/'ready.json')),flush=True)
