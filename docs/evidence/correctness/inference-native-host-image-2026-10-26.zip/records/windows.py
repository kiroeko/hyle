"""Single canonical typed transfer test TU; reuse exact native closures.

plan vulkan|cuda, build vulkan|cuda, run vulkan|cuda. Default does nothing.
No Model/weights/report compilation, SDK build or model downloads.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
C = R/'.scratch/inference-causal-conv-20261026'
S = R/'.scratch/inference-storage-freeze-20261026'
V = R/'.scratch/qwen-cpu-vulkan-20261024/smoke-attempt6'
spec = importlib.util.spec_from_file_location('causal_helpers', C/'build.py')
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c); b = c.b
SOURCE = R/'tests/tools/inference_state_transfer_test.cc'


ATTEMPT = int(sys.argv[3]) if len(sys.argv) == 4 else 1
def paths(kind): return W/(('windows-attempt' if kind == 'vulkan' else 'cuda-attempt')+str(ATTEMPT))


def plan(kind):
    A = paths(kind); assert not (A/'plan.json').exists()
    recipe = V/'compile/command.json' if kind == 'vulkan' else R/'.scratch/inference-host-image-20261026/cuda4/compile/command.json'
    old = b.read(recipe)['command']; original_source = next(x for x in old if x.endswith('.cc'))
    command = []
    for arg in old:
        if arg.startswith('/I') and str(R/'.scratch').casefold() in arg.casefold(): continue
        if arg == original_source: arg = str(SOURCE)
        elif arg == old[old.index('/sourceDependencies')+1]: arg = str(A/'compile/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo'+str(A/'compile/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd'+str(A/'compile/unit.pdb')
        command.append(arg)
    for flag in ('/O2','/Ob2','/MD','/W4','/WX'): assert flag in command
    frozen = c.closure([SOURCE], [recipe]); b.save(A/'source-freeze.json', frozen)
    link_recipe = V/'link/command.json' if kind == 'vulkan' else S/'case/link/command.json'
    link = b.read(link_recipe)['command']
    inputs = [b.pin(x) for x in link if Path(x).is_absolute() and x.lower().endswith(('.obj','.lib'))]
    if kind == 'vulkan':
        remove = [next(row for row in inputs if b.key(row['path']) == b.key(V/'compile/unit.obj'))]
        core = next(row for row in inputs if row['path'].endswith('cpu-budget-fix1\\leases\\leases.obj'))
        replacement = [dict(old=core, new=b.pin(S/'compile/core/unit.obj'))]
        runtime = b.pin(V/'runtime.json'); native = b.read(V/'ready.json')['native']
    else:
        model = b.read(R/'.scratch/inference-host-image-lag1-20261026/ready.json')['object']
        weights = next(row['object'] for row in b.read(S/'ready.json')['compiled'] if row['name'] == 'weights')
        remove = [row for row in inputs if b.key(row['path']) in (b.key(model['path']), b.key(weights['path'])) or
            row['path'].endswith('product2\\report\\unit.obj')]
        assert len(remove) == 3
        replacement = []; runtime = b.pin(S/'case/runtime.json'); native = b.read(runtime['path'])['native']
    assert not any('wholearchive' in x.lower() for x in link)
    b.save(A/'inputs-before.json', inputs)
    b.save(A/'plan.json', dict(status='FROZEN_NOT_BUILT_OR_RUN', kind=kind, source=b.pin(SOURCE),
        compile_recipe=b.pin(recipe), compile_command=command, source_freeze=b.pin(A/'source-freeze.json'),
        link_recipe=b.pin(link_recipe), inputs=b.pin(A/'inputs-before.json'), removed=remove,
        replacements=replacement, runtime=runtime, native=native, compiled_TUs=1,
        Model_weights_report_native_SDK_builds=0,
        adaptation='Only historical project /I shadow removed; canonical test source. Native closure and original feature macros retained; no engine Backend variant remains in linked Model/weights objects.'))
    print('TEST_PLAN', json.dumps(b.pin(A/'plan.json')), flush=True)


def build(kind):
    A = paths(kind); p = b.read(A/'plan.json'); assert not (A/'compile').exists()
    for field in ('source','compile_recipe','source_freeze','link_recipe','inputs','runtime','native'): b.exact(p[field])
    frozen = b.read(p['source_freeze']['path']); expected = {b.key(x['path']): x for x in frozen}
    for row in [*frozen,*b.read(p['inputs']['path'])]: b.exact(row)
    for row in p['replacements']: b.exact(row['new'])
    h = b.helper(); compiler = p['compile_command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    compiled = h.execute(p['compile_command'],env,A/'compile',timeout=120)
    dep = b.read(A/'compile/dependencies.json')['Data']
    actual = [b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
            assert b.key(path) in expected and row['sha256'] == expected[b.key(path)]['sha256'], str(path)
    b.save(A/'actual-dependencies.json',actual)
    for row in frozen: b.exact(row)
    obj=b.pin(A/'compile/unit.obj'); image=A/'link/state-transfer-test.exe'
    replacement={b.key(x['old']['path']):x['new'] for x in p['replacements']}
    command=[]; removed=0; replaced=0
    for arg in b.read(p['link_recipe']['path'])['command']:
        if any(b.key(arg)==b.key(x['path']) for x in p['removed']):removed+=1;continue
        if b.key(arg) in replacement:arg=replacement[b.key(arg)]['path'];replaced+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        command.append(arg)
    assert removed==len(p['removed']) and replaced==len(p['replacements'])
    command.append(obj['path']); linked=h.execute(command,env,image.parent,timeout=120)
    inputs=[replacement.get(b.key(x['path']),x) for x in b.read(p['inputs']['path']) if x not in p['removed']]+[obj]
    b.save(A/'link-inputs.json',inputs)
    native=Path(p['native']['path']);os.link(native,image.parent/native.name)
    runtime=b.read(p['runtime']['path']);b.save(A/'runtime.json',runtime)
    b.save(A/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),object=obj,plan=b.pin(A/'plan.json'),
        runtime=b.pin(A/'runtime.json'),link_inputs=b.pin(A/'link-inputs.json'),compile=compiled,link=linked,
        compiled_TUs=1,Model_weights_report_native_SDK_builds=0))
    print('TEST_READY',json.dumps(b.pin(A/'ready.json')),flush=True)


def run(kind):
    A=paths(kind);ready=b.read(A/'ready.json');b.exact(ready['image']);runtime=b.read(ready['runtime']['path'])
    env=os.environ.copy();env['PATH']=runtime['PATH'];h=b.helper();results=[]
    for selected in (['vulkan','cpu'] if kind=='vulkan' else ['cuda']):
        folder=A/('run-'+selected)
        try:h.execute([ready['image']['path'],'--'+selected],env,folder,timeout=60)
        except RuntimeError as error:print(str(error),flush=True)
        process=b.read(folder/'process.json');results.append(dict(backend=selected,process=process))
    b.save(A/'run-summary.json',dict(results=results,model_runs=0,HTTP=0,source=b.read(A/'plan.json')['source']))
    print('TEST_RUN_SUMMARY',json.dumps(b.pin(A/'run-summary.json')),flush=True)


if __name__=='__main__':
    if len(sys.argv) in (3,4) and sys.argv[2] in ('vulkan','cuda') and sys.argv[1] in ('plan','build','run'):
        globals()[sys.argv[1]](sys.argv[2])
    else:print(__doc__)
