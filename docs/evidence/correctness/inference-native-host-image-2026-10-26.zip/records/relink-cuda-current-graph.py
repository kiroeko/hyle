from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();B=R/'.scratch/inference-native-host-image-20261026';W=B/'cuda-model-attempt3';A=B/'cuda-model-attempt2'
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-storage-freeze-20261026/build.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);b=s.b;h=b.helper()
ready=b.read(A/'ready.json');inputs=b.read(ready['link_inputs']['path']);gr=b.read(B/'current-graph-resources/ready.json');print(gr.keys(),flush=True)
obj=gr['object'];b.exact(obj)
old=next(row for row in inputs if 'graph--resources_cc' in row['path'])
compiler=b.read(A/'compile/model/command.json')['command'][0];env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
image=W/'link/host-image-consumer.exe';command=[];count=0
for arg in b.read(A/'link/command.json')['command']:
    if b.key(arg)==b.key(old['path']):arg=obj['path'];count+=1
    elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
    elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
    command.append(arg)
assert count==1 and not W.exists()
for row in inputs:b.exact(row)
linked=h.execute(command,env,image.parent,timeout=120);final=[obj if row==old else row for row in inputs];b.save(W/'link-inputs.json',final)
runtime=b.read(ready['runtime']['path']);b.exact(runtime['native']);alias=image.parent/Path(runtime['native']['path']).name;os.link(runtime['native']['path'],alias);runtime['native_hardlink']=b.pin(alias);b.save(W/'runtime.json',runtime)
b.save(W/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),runtime=b.pin(W/'runtime.json'),link_inputs=b.pin(W/'link-inputs.json'),link=linked,source_freeze=ready['source_freeze'],replaced_graph_core=old,current_graph_core=b.pin(B/'current-graph-resources/ready.json'),compiled_TUs=0))
runenv=os.environ.copy();runenv['PATH']=str(image.parent)+';'+runtime['PATH'];path=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
for name,extra in [('run-ordinary-mtp',[]),('run-lag1',['--mtp-lag1'])]:
    result=h.execute([str(image),'--cuda',str(path),*extra],runenv,W/name,timeout=240)
    b.save(W/(name+'-receipt.json'),dict(result=result,image=b.pin(image),manifest=b.pin(path/'weights.tsv'),throughput_evidence=False));print(name,result,flush=True)
