from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
R=Path.cwd(); W=R/'.scratch/inference-native-host-image-20261026/cuda-model-attempt3'; W.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-storage-freeze-20261026/build.py'); s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
b=s.b;c=s.c
ready=b.read(s.W/'case/ready.json'); inputs=b.read(ready['link_inputs']['path'])
old_model=b.pin(R/'.scratch/inference-host-image-lag1-20261026/compile/unit.obj');old_weights=b.pin(s.W/'compile/weights/unit.obj')
for row in inputs:b.exact(row)
source=R/'tests/tools/qwen_host_image_test.cc';weights=R/'engine/models/qwen35/weights.cc'
model_recipe=R/'.scratch/inference-host-image-lag1-20261026/compile/command.json';weights_recipe=s.W/'compile/weights/command.json'
frozen=c.closure([source,weights],[model_recipe,weights_recipe]); b.save(W/'source-freeze.json',frozen)
h=b.helper();compiler=b.read(model_recipe)['command'][0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
new={};compiles=[]
for name,src,rec,old in [('model',source,model_recipe,old_model),('weights',weights,weights_recipe,old_weights)]:
    folder=W/'compile'/name;assert not folder.exists()
    command=s.compile_command(src,rec,folder)
    result=h.execute(command,env,folder,timeout=180)
    obj=b.pin(folder/'unit.obj');new[b.key(old['path'])]=obj
    dep=b.read(folder/'dependencies.json')['Data'];actual=[b.pin(path) for path in dict.fromkeys([dep['Source'],*dep['Includes']])]
    bykey={b.key(row['path']):row for row in frozen}
    for row in actual:
        path=Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):assert b.key(path) in bykey and row['sha256']==bykey[b.key(path)]['sha256'],path
    b.save(folder/'actual-dependencies.json',actual);compiles.append(dict(name=name,process=result,object=obj))
    print('COMPILED',name,result,flush=True)
image=W/'link/host-image-consumer.exe';command=[];count=0
for arg in b.read(s.W/'case/link/command.json')['command']:
    if b.key(arg) in new:arg=new[b.key(arg)]['path'];count+=1
    elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
    elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
    elif arg.upper().startswith('/MAP:'):continue
    command.append(arg)
assert count==2
linked=h.execute(command,env,image.parent,timeout=120)
final=[new.get(b.key(row['path']),row) for row in inputs];b.save(W/'link-inputs.json',final)
runtime=b.read(ready['runtime']['path']);b.exact(runtime['native']);alias=image.parent/Path(runtime['native']['path']).name;os.link(runtime['native']['path'],alias);runtime['native_hardlink']=b.pin(alias);b.save(W/'runtime.json',runtime)
for row in frozen:b.exact(row)
b.save(W/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),runtime=b.pin(W/'runtime.json'),link_inputs=b.pin(W/'link-inputs.json'),compiles=compiles,link=linked,source_freeze=b.pin(W/'source-freeze.json'),SDK_native_report_builds=0))
print('READY',b.pin(W/'ready.json'),flush=True)

