param([switch]$Delete)
$ErrorActionPreference = 'Stop'
# Default is a read-only identity check. No deletion was performed by Codex:
# the automatic tool review rejected the previous cleanup command.
$scope = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch')).TrimEnd('\') + '\'
$targets = @(
  @{ path='.scratch/inference-storage-freeze-20261026/case/link/host-image-lagged-consumer.exe'; bytes=141243904; sha256='a964f455d93dac622210425fc345ca0e51aaea59747bf88bf718cfd1b647dccd' },
  @{ path='.scratch/inference-native-host-image-20261026/cuda-model-attempt2/link/host-image-consumer.exe'; bytes=141245952; sha256='dff58199927096d42870cee7ae450d46cec4f5165c250c1fee24cef8097614ff' }
)
foreach ($row in $targets) {
  $resolved = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot $row.path)).ProviderPath
  if (-not $resolved.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes repository scratch' }
  $file = Get-Item -LiteralPath $resolved
  if ($file.PSIsContainer -or $file.Length -ne $row.bytes) { throw 'Target identity mismatch' }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ine $row.sha256) { throw 'Target digest changed' }
}
if (-not $Delete) {
  $targets | ForEach-Object { [pscustomobject]$_ } | Format-Table path,bytes
  Write-Output 'Read-only check completed. No files deleted.'
  return
}
foreach ($row in $targets) { Remove-Item -LiteralPath (Join-Path $PSScriptRoot $row.path) -Force }
