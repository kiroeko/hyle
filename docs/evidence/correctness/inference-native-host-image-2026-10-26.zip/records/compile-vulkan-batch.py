"""Compile only the current Vulkan batch CXX ABI adapter; no shader/vendor build."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];A=W/'current-vulkan-batch'
spec=importlib.util.spec_from_file_location('local_helpers',W/'windows.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b;c=m.c
source=R/'src/compute_route_vulkan/vulkan_batch.cc'
recipe=R/'.scratch/qwen-vulkan-k1-20261024/build1/src--compute_route_vulkan--vulkan_batch-cc/command.json'
old=b.read(recipe)['command'];folder=A/'compile';command=[]
for arg in old:
    if arg==old[old.index('/sourceDependencies')+1]:arg=str(folder/'dependencies.json')
    elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
    elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
    command.append(arg)
for flag in ['/O2','/Ob2','/MD','/W4','/WX','/DHYLE_COMPUTE_VULKAN=1']:assert flag in command
frozen=c.closure([source],[recipe]);b.save(A/'source-freeze.json',frozen)
b.save(A/'plan.json',dict(source=b.pin(source),recipe=b.pin(recipe),command=command,
    source_freeze=b.pin(A/'source-freeze.json'),compiled_TUs=1,SDK_shader_vendor_builds=0,
    note='Keep actual generated-header/third-party cache include locations and canonical Hyle source/include precedence; retain all actual dependencies.'))
h=b.helper();compiler=command[0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
process=h.execute(command,env,folder,timeout=180)
dep=b.read(folder/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
expected={b.key(x['path']):x for x in frozen}
for x in actual:
    path=Path(x['path'])
    if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
        assert b.key(path) in expected and x['sha256']==expected[b.key(path)]['sha256'],str(path)
for x in frozen:b.exact(x)
b.save(A/'actual-dependencies.json',actual)
cached=[x for x in actual if Path(x['path']).is_relative_to(R/'.scratch')]
b.save(A/'ready.json',dict(object=b.pin(folder/'unit.obj'),source=b.pin(source),
    source_freeze=b.pin(A/'source-freeze.json'),actual_dependencies=b.pin(A/'actual-dependencies.json'),
    cached_generated_or_vendor_inputs=cached,compiled_TUs=1,process=process))
print('CURRENT_VULKAN_BATCH_READY',json.dumps(b.pin(A/'ready.json')),flush=True)
