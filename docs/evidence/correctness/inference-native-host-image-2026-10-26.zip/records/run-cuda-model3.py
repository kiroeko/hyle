from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-native-host-image-20261026/cuda-model-attempt3'
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-storage-freeze-20261026/build.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);b=s.b;h=b.helper()
ready=b.read(W/'ready.json')
for field in ('image','runtime','link_inputs','source_freeze'):b.exact(ready[field])
for row in b.read(ready['link_inputs']['path']):b.exact(row)
runtime=b.read(ready['runtime']['path']);env=os.environ.copy();env['PATH']=str(Path(ready['image']['path']).parent)+';'+runtime['PATH']
inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
for name,extra in [('run-ordinary-mtp',[]),('run-lag1',['--mtp-lag1'])]:
    command=[ready['image']['path'],'--cuda',str(inputs),*extra]
    result=h.execute(command,env,W/name,timeout=240)
    b.save(W/(name+'-receipt.json'),dict(result=result,image=ready['image'],source_freeze=ready['source_freeze'],manifest=b.pin(inputs/'weights.tsv'),throughput_evidence=False))
    print(name,result,flush=True)

