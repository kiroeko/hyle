"""Explicit current generic Graph resources TU only; no model execution."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];A=W/'current-graph-resources'
spec=importlib.util.spec_from_file_location('local_helpers',W/'windows.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b;c=m.c
source=R/'src/graph/resources.cc'
recipe=R/'.scratch/inference-current-closure-20261026/unresolved-host/compile/graph--resources_cc/command.json'
frozen=c.closure([source],[recipe]);b.save(A/'source-freeze.json',frozen)
old=b.read(recipe)['command'];original_source=next(x for x in old if x.endswith('.cc'))
command=[]
for arg in old:
    if arg.startswith('/I') and str(R/'.scratch').casefold() in arg.casefold():continue
    if arg==original_source:arg=str(source)
    elif arg==old[old.index('/sourceDependencies')+1]:arg=str(A/'compile/dependencies.json')
    elif arg.lower().startswith('/fo'):arg='/Fo'+str(A/'compile/unit.obj')
    elif arg.lower().startswith('/fd'):arg='/Fd'+str(A/'compile/unit.pdb')
    command.append(arg)
b.save(A/'plan.json',dict(source=b.pin(source),recipe=b.pin(recipe),command=command,
    source_freeze=b.pin(A/'source-freeze.json'),compiled_TUs=1,Model_native_SDK_builds=0,
    adaptation='Prior generic helper correctly rejected old project /I shadow before starting compiler. Remove that shadow and compile only canonical source/header paths; no warning reduction.'))
h=b.helper();compiler=command[0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
process=h.execute(command,env,A/'compile',timeout=120)
dep=b.read(A/'compile/dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
expected={b.key(x['path']):x for x in frozen}
for x in actual:
    path=Path(x['path'])
    if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
        assert b.key(path) in expected and x['sha256']==expected[b.key(path)]['sha256'],str(path)
for x in frozen:b.exact(x)
b.save(A/'actual-dependencies.json',actual)
b.save(A/'ready.json',dict(object=b.pin(A/'compile/unit.obj'),source=b.pin(source),
    source_freeze=b.pin(A/'source-freeze.json'),actual_dependencies=b.pin(A/'actual-dependencies.json'),
    compiled_TUs=1,process=process,scope='Current generic Graph resource publication implementation; no engine Backend variant or GPU/native code generation.'))
print('CURRENT_RESOURCES_READY',json.dumps(b.pin(A/'ready.json')),flush=True)
