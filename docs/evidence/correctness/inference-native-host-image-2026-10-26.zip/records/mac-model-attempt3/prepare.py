from pathlib import Path
import hashlib,json,re,subprocess,time,base64,io,tarfile

W=Path(__file__).resolve().parent
R=W.parents[2]
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-native-host-image-20261026/model-attempt3'
HOST='kiro@172.22.10.198'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',HOST,'python3 -']
def write(p,j): Path(p).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def remote(code,name,timeout=45):
 t=time.perf_counter();p=subprocess.run(SSH,input=code,text=True,capture_output=True,timeout=timeout)
 write(W/(name+'-process.json'),dict(command=SSH,exit=p.returncode,seconds=time.perf_counter()-t,stdout=p.stdout,stderr=p.stderr))
 if p.returncode: raise RuntimeError(p.stderr or p.stdout)
 return json.loads(p.stdout)
recipes=json.loads((W/'original-recipes.json').read_text())
compile=next(v for k,v in recipes.items() if k.endswith('/compile/model/command.json'))
link=next(v for k,v in recipes.items() if k.endswith('/link5/command.json'))
flags=[];a=compile['command'];i=1
while i<len(a):
 x=a[i]
 if x in ('-o','-MF','-MT','-MQ'):i+=2;continue
 if x in ('-c','-MMD','-MD') or x.endswith(('.cc','.cpp','.cxx')):i+=1;continue
 flags.append(x);i+=1
flags=['-I'+REMOTE+'/source/include','-I'+REMOTE+'/source/src/compute','-I'+REMOTE+'/source']+flags
entries=['src/compute_batch/batch_layout.cc','src/compute_batch/paged_arena.cc','src/graph/resources.cc']
seed=set(entries+['include/hyle/compute/storage_owner.h','include/hyle/compute/detail/lease_access.h',
 'include/hyle/compute/detail/context_ref.h','include/hyle/compute/detail/copy_stream_access.h',
 'include/hyle/compute/detail/apple_copy_stream_access.h','include/hyle/compute/detail/vulkan_copy_stream_access.h',
 'include/hyle/compute/resource_leases.h','include/hyle/compute/detail/resource_budget_access.h','include/hyle/compute/batch_transfer.h'])
# Local engine/internal quoted includes, keeping their actual relative layout.
queue=list(entries)
while queue:
 name=queue.pop();p=R/name
 for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"',p.read_text(encoding='utf-8'),re.M):
  target=(p.parent/include).resolve()
  if target.is_file() and target.is_relative_to(R):
   rel=target.relative_to(R).as_posix()
   if rel not in seed:seed.add(rel);queue.append(rel)
synced={}
def sync(names,tag):
 changed=[];stream=io.BytesIO()
 with tarfile.open(fileobj=stream,mode='w:gz') as tar:
  for name in sorted(names):
   p=R/name;b=p.read_bytes();sha=hashlib.sha256(b).hexdigest()
   if synced.get(name)==sha:continue
   info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
   synced[name]=sha;changed.append(dict(path=name,bytes=len(b),sha256=sha))
 data=stream.getvalue();(W/(tag+'.tar.gz')).write_bytes(data)
 payload=base64.b64encode(data).decode()
 code=f'''from pathlib import Path\nimport json,base64,tarfile,io\nw=Path({REMOTE!r});root=w/'source';root.mkdir(parents=True,exist_ok=True)\nwith tarfile.open(fileobj=io.BytesIO(base64.b64decode({payload!r})),mode='r:gz') as t:\n for member in t.getmembers():\n  p=(root/member.name).resolve()\n  assert p.is_relative_to(root.resolve()) and member.isfile()\n  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(member).read())\nprint(json.dumps({{'files':{len(changed)},'compressed_bytes':{len(data)}}}))\n'''
 remote(code,tag);write(W/(tag+'-pins.json'),changed)
sync(seed,'sync-seed')
all_dependencies=[]
for iteration in range(1,5):
 commands=[[a[0],*flags,'-MM','-MT','dependency',REMOTE+'/source/'+name] for name in entries]
 code=f'''from pathlib import Path\nimport subprocess,json,shlex,time\nw=Path({REMOTE!r});rows=[]\nfor n,cmd in enumerate({commands!r}):\n p=subprocess.run(cmd,cwd=w,capture_output=True,text=True,timeout=60)\n rows.append({{'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'dependencies':shlex.split(p.stdout.replace('\\\\\\n',' '))[1:] if p.returncode==0 else []}})\nprint(json.dumps(rows))\n'''
 rows=remote(code,'dependencies'+str(iteration),75)
 write(W/('dependencies'+str(iteration)+'.json'),rows)
 if any(row['exit'] for row in rows):raise RuntimeError('dependency preprocessing rejected; inspect raw receipts')
 all_dependencies=sorted(set(d for row in rows for d in row['dependencies']))
 more=set()
 for dep in all_dependencies:
  if '/include/hyle/' in dep:rel='include/hyle/'+dep.split('/include/hyle/',1)[1]
  elif '/src/compute/' in dep:rel='src/compute/'+dep.split('/src/compute/',1)[1]
  elif dep.startswith(REMOTE+'/source/'):rel=dep[len(REMOTE+'/source/'):]
  else:continue
  p=R/rel
  if p.is_file() and synced.get(rel)!=hashlib.sha256(p.read_bytes()).hexdigest():more.add(rel)
 if not more:break
 sync(more,'sync-deps'+str(iteration))
else:raise RuntimeError('finite source include closure did not settle')
assert all(synced[n]==hashlib.sha256((R/n).read_bytes()).hexdigest() for n in synced)
write(W/'source-freeze.json',[dict(path=n,sha256=h,bytes=(R/n).stat().st_size) for n,h in sorted(synced.items())])
prior=json.loads((W.with_name('mac-model-attempt2')/'plan.json').read_text())
old_layout='/Users/kiro/hyle-scratch/compute-unified/qwen-k1-functional-20261024/attempt1/objects/src--compute_batch--batch_layout.cc.o'
old_arena='/Users/kiro/hyle-scratch/compute-unified/qwen-k1-functional-20261024/attempt1/objects/src--compute_batch--paged_arena.cc.o'
objects=[REMOTE+'/layout.o',REMOTE+'/arena.o',REMOTE+'/resources.o'];image=REMOTE+'/host-image'
jobs=[]
for label,name,obj in zip(['compile-layout','compile-arena','compile-resources'],entries,objects):
 jobs.append(dict(tag=label,command=[a[0],*flags,'-MMD','-MF',obj+'.d','-c',REMOTE+'/source/'+name,'-o',obj],timeout=120))
cmd=prior['jobs'][-1]['command'].copy();assert cmd.count(old_layout)==1 and cmd.count(old_arena)==1
cmd=[{old_layout:objects[0],old_arena:objects[1]}.get(x,x) for x in cmd]
cmd.insert(1,objects[2])
for n,x in enumerate(cmd):
 if x=='-o':cmd[n+1]=image
 elif x.startswith('-Wl,-map,'):cmd[n]='-Wl,-map,'+REMOTE+'/image.map'
assert not any('force_load' in x or 'all_load' in x for x in cmd)
jobs.append(dict(tag='link',command=cmd,timeout=120))
plan=dict(remote=REMOTE,jobs=jobs,environment=prior['environment'],source_files=len(synced),
 replacements={old_layout:objects[0],old_arena:objects[1]},added_direct_object=objects[2],
 reused_model_objects=[str(Path('/Users/kiro/hyle-scratch/compute-unified/inference-native-host-image-20261026/model-attempt2')/n) for n in ['model.o','weights.o','report.o']],
 scope='Exactly3 current batch_layout/paged_arena/graph-resources leaf TUs replacing old cached leaves, then relink unchanged PASS Model/weights/report objects from attempt2; retained native SDK and libraries unchanged. No compatibility shim, duplicate-ignore flag, model download or body copy.')
write(W/'plan.json',plan)
print(json.dumps(dict(status='PLAN_READY',source_files=len(synced),compressed_bytes=sum(p.stat().st_size for p in W.glob('sync-*.tar.gz')))))
