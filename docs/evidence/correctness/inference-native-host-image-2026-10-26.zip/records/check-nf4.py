from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-native-host-image-20261026/nf4-parser-check';assert not W.exists()
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-storage-freeze-20261026/build.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);b=s.b;h=b.helper()
compiler=b.read(s.W/'compile/weights/command.json')['command'][0];env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
source=R/'tests/tools/qwen_prepared_roles_test.cc';folder=W/'compile'
command=[compiler,'/nologo','/c','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/Ob2','/MD','/DNDEBUG','/permissive-','/W4','/WX','/DNOMINMAX','/I'+str(R/'include'),'/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
compiled=h.execute(command,env,folder,timeout=120)
dep=b.read(folder/'dependencies.json')['Data'];actual=[b.pin(path) for path in dict.fromkeys([dep['Source'],*dep['Includes']])];b.save(W/'actual-dependencies.json',actual)
image=W/'link/prepared-roles-test.exe';link=[str(Path(compiler).with_name('link.exe')),'/NOLOGO','/INCREMENTAL:NO','/MACHINE:X64','/SUBSYSTEM:CONSOLE',str(folder/'unit.obj'),'/OUT:'+str(image)]
linked=h.execute(link,env,image.parent,timeout=60)
result=h.execute([str(image),str(W/'fixtures')],env,W/'run',timeout=60)
b.save(W/'summary.json',dict(compile=compiled,link=linked,run=result,image=b.pin(image),source=b.pin(source),actual_dependencies=b.pin(W/'actual-dependencies.json'),SDK_builds=0,downloads=0))
print('NF4_TEST_PASS',result,flush=True)
