from pathlib import Path
import base64,json,subprocess
W=Path(__file__).resolve().parent;P=json.loads((W/'plan.json').read_text());remote=P['remote']
files=['summary.json','actual-dependencies.json','hardware.json','ready.json']
for tag in [j['tag'] for j in P['jobs']]+['run-apple','run-apple-lag1']:
 files += [tag+'/'+n for n in ['command.json','running.json','process.json','stdout.log','stderr.log']]
code=f"""from pathlib import Path
import base64,json
w=Path({remote!r})
print(json.dumps({{n:base64.b64encode((w/n).read_bytes()).decode() for n in {files!r} if (w/n).is_file()}}))
"""
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -'],input=code,text=True,capture_output=True,timeout=30)
assert p.returncode==0,p.stderr
rows=json.loads(p.stdout)
for name,b in rows.items():
 dest=W/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(base64.b64decode(b))
print(json.dumps({'collected':len(rows),'summary':json.loads((W/'summary.json').read_text())},indent=2))
