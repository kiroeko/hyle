"""Current canonical HostImage test + matching CPU/Vulkan weights, two TUs.

plan, build, tiny, original are separate explicit steps; no SDK/model download.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
ATTEMPT=int(sys.argv[2]) if len(sys.argv)==3 else 1
A=W/('vulkan-model-attempt'+str(ATTEMPT))
V=R/'.scratch/qwen-cpu-vulkan-20261024/engine-attempt1'
S=R/'.scratch/inference-storage-freeze-20261026'
spec=importlib.util.spec_from_file_location('local_helpers',W/'windows.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b;c=m.c


def plan():
    assert not (A/'plan.json').exists()
    recipe=V/'compile/command.json';old=b.read(recipe)['command'];origin=next(x for x in old if x.endswith('.cc'))
    units=[]
    for name,relative in [('model','tests/tools/qwen_host_image_test.cc'),('weights','engine/models/qwen35/weights.cc')]:
        source=R/relative;folder=A/'compile'/name;command=[]
        for arg in old:
            if arg.startswith('/I') and str(R/'.scratch').casefold() in arg.casefold():continue
            if arg==origin:arg=str(source)
            elif arg==old[old.index('/sourceDependencies')+1]:arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            command.append(arg)
        for flag in ['/O2','/Ob2','/MD','/W4','/WX','/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_VULKAN=1']:assert flag in command
        units.append(dict(name=name,source=b.pin(source),command=command))
    frozen=c.closure([x['source']['path'] for x in units],[recipe]);b.save(A/'source-freeze.json',frozen)
    link_recipe=V/'link3/command.json';link=b.read(link_recipe)['command']
    inputs=[b.pin(x) for x in link if Path(x).is_absolute() and x.lower().endswith(('.obj','.lib'))]
    oldmodel=next(x for x in inputs if b.key(x['path'])==b.key(V/'compile/unit.obj'))
    replacement=[]
    for suffix,new in [('cpu-budget-fix1\\budget\\budget.obj',R/'.scratch/inference-cache-shared-source-20261025/attempt1/budget/unit.obj'),('cpu-budget-fix1\\leases\\leases.obj',S/'compile/core/unit.obj')]:
        replacement.append(dict(old=next(x for x in inputs if x['path'].endswith(suffix)),new=b.pin(new)))
    current_inputs=b.read(S/'case/link-inputs.json')
    leaves=[('f32-paged-check\\attempt2\\layout\\layout.obj',next(x['path'] for x in current_inputs if 'compute_batch--batch_layout' in x['path'])),
        ('src--compute_batch--paged_arena-cc\\unit.obj',R/'.scratch/inference-host-image-20261026/arena/implementation/unit.obj'),
        ('host1\\graph--resources.obj',W/'current-graph-resources/compile/unit.obj'),
        ('f32-paged-check\\attempt2\\native-batch\\native-batch.obj',next(x['path'] for x in current_inputs if 'cpu-native-batch' in x['path'])),
        ('graph-batch-batch-current1\\unit.obj',next(x['path'] for x in current_inputs if 'graph_batch--batch_cc' in x['path'])),
        ('src--graph_batch--native_batch_regions-cc\\unit.obj',next(x['path'] for x in current_inputs if 'graph_batch--native_batch_regions_cc' in x['path'])),
        ('host1\\graph_batch--native_paged_node.obj',next(x['path'] for x in current_inputs if 'graph_batch--native_paged_node_cc' in x['path'])),
        ('graph-batch-paged_append-current1\\unit.obj',next(x['path'] for x in current_inputs if 'cpu-append' in x['path'])),
        ('src--compute_route_vulkan--vulkan_batch-cc\\unit.obj',W/'current-vulkan-batch/compile/unit.obj')]
    for suffix,new in leaves:
        found=[x for x in inputs if x['path'].endswith(suffix)];assert len(found)==1,suffix
        replacement.append(dict(old=found[0],new=b.pin(new)))
    assert len({b.key(x['old']['path']) for x in replacement})==len(replacement)
    report=next(x for x in b.read(S/'case/link-inputs.json') if x['path'].endswith('product2\\report\\unit.obj'))
    b.save(A/'inputs-before.json',inputs)
    b.save(A/'plan.json',dict(units=units,compile_recipe=b.pin(recipe),source_freeze=b.pin(A/'source-freeze.json'),
        link_recipe=b.pin(link_recipe),inputs=b.pin(A/'inputs-before.json'),removed_model=oldmodel,
        replacements=replacement,added_report=report,
        cached_caller_source_check=b.pin(W/'vulkan-batch-callers-cached.json'),
        prior_resource_attribution_correction=b.pin(W/'graph-resources-attribution-correction.json'),
        runtime=b.pin(R/'.scratch/qwen-cpu-vulkan-20261024/smoke-attempt6/runtime.json'),
        native=b.read(R/'.scratch/qwen-cpu-vulkan-20261024/smoke-attempt6/ready.json')['native'],
        compiled_TUs=2,SDK_native_builds=0,
        scope='Canonical HostImage ordinary+MTP test. Current Model and weights compile under identical CPU+Vulkan flags; old project shadows removed; exact current core/budget/report cache reuse. No numerical quality or speed claim.'))
    print('VULKAN_MODEL_PLAN',json.dumps(b.pin(A/'plan.json')),flush=True)


def build():
    p=b.read(A/'plan.json');assert not (A/'compile').exists()
    for field in ['compile_recipe','source_freeze','link_recipe','inputs','added_report','runtime','native']:b.exact(p[field])
    frozen=b.read(p['source_freeze']['path']);expected={b.key(x['path']):x for x in frozen}
    for x in [*frozen,*b.read(p['inputs']['path'])]:b.exact(x)
    for x in p['replacements']:b.exact(x['new'])
    h=b.helper();compiler=p['units'][0]['command'][0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    objects=[];compiled=[]
    for unit in p['units']:
        folder=A/'compile'/unit['name'];process=h.execute(unit['command'],env,folder,timeout=180)
        dep=b.read(folder/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for x in actual:
            path=Path(x['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
                assert b.key(path) in expected and x['sha256']==expected[b.key(path)]['sha256'],str(path)
        b.save(folder/'actual-dependencies.json',actual);objects.append(b.pin(folder/'unit.obj'));compiled.append(process)
        for x in frozen:b.exact(x)
    image=A/'link/host-image-vulkan-test.exe';command=[];removed=0;replaced=0
    replacements={b.key(x['old']['path']):x['new'] for x in p['replacements']}
    for arg in b.read(p['link_recipe']['path'])['command']:
        if b.key(arg)==b.key(p['removed_model']['path']):removed+=1;continue
        if b.key(arg) in replacements:arg=replacements[b.key(arg)]['path'];replaced+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        command.append(arg)
    assert removed==1 and replaced==len(p['replacements'])
    command += [x['path'] for x in objects]+[p['added_report']['path']]
    linked=h.execute(command,env,image.parent,timeout=120)
    inputs=[replacements.get(b.key(x['path']),x) for x in b.read(p['inputs']['path']) if x!=p['removed_model']]+objects+[p['added_report']]
    b.save(A/'link-inputs.json',inputs);b.save(A/'runtime.json',b.read(p['runtime']['path']))
    native=Path(p['native']['path']);os.link(native,image.parent/native.name)
    b.save(A/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),runtime=b.pin(A/'runtime.json'),
        inputs=b.pin(A/'link-inputs.json'),plan=b.pin(A/'plan.json'),compiled=compiled,link=linked,
        compiled_TUs=2,SDK_native_builds=0))
    print('VULKAN_MODEL_READY',json.dumps(b.pin(A/'ready.json')),flush=True)


def run(which):
    ready=b.read(A/'ready.json');b.exact(ready['image'])
    fixture=R/('.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture' if which=='tiny' else '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')
    b.save(A/('run-'+which+'-inputs.json'),dict(weights=b.pin(fixture/'weights.tsv'),fixture=str(fixture),physical_model_rehash_or_copy=False))
    env=os.environ.copy();env['PATH']=b.read(ready['runtime']['path'])['PATH']
    command=[ready['image']['path'],'--vulkan',str(fixture)]
    if which=='lagged':command.append('--mtp-lag1')
    b.helper().execute(command,env,A/('run-'+which),timeout=60 if which=='tiny' else 180)


if __name__=='__main__':
    if len(sys.argv) in (2,3) and sys.argv[1]=='plan':plan()
    elif len(sys.argv) in (2,3) and sys.argv[1]=='build':build()
    elif len(sys.argv) in (2,3) and sys.argv[1] in ('tiny','original','lagged'):run(sys.argv[1])
    else:print(__doc__)
