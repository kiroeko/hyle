"""Current ComputeRouteVulkan program adapter from exact linker trigger; no native kernel build."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];A=W/'current-vulkan-program'
spec=importlib.util.spec_from_file_location('local_helpers',W/'windows.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b;c=m.c
units=[]
for name in ['vulkan_program']:
    source=R/('src/compute_route_vulkan/'+name+'.cc')
    recipe=R/('.scratch/gdn-vulkan-output-scale-20261024/compile1/route--'+name+'/run/command.json')
    folder=A/'compile'/name;old=b.read(recipe)['command'];command=[]
    for arg in old:
        if arg==old[old.index('/sourceDependencies')+1]:arg=str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
        command.append(arg)
    for flag in ['/O2','/Ob2','/MD','/W4','/WX']:assert flag in command
    units.append(dict(name=name,source=b.pin(source),recipe=b.pin(recipe),command=command))
frozen=c.closure([x['source']['path'] for x in units],[x['recipe']['path'] for x in units])
b.save(A/'source-freeze.json',frozen)
b.save(A/'plan.json',dict(units=units,source_freeze=b.pin(A/'source-freeze.json'),compiled_TUs=1,
    reason='Old compiled adapters require removed public BatchLayoutVersion::schema(); current public method is origin_schema() returning by value. No compatibility shim.',SDK_shader_vendor_builds=0))
h=b.helper();compiler=units[0]['command'][0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
expected={b.key(x['path']):x for x in frozen};results=[]
for unit in units:
    folder=A/'compile'/unit['name'];process=h.execute(unit['command'],env,folder,timeout=180)
    dep=b.read(folder/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    for x in actual:
        path=Path(x['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
            assert b.key(path) in expected and x['sha256']==expected[b.key(path)]['sha256'],str(path)
    for x in frozen:b.exact(x)
    b.save(folder/'actual-dependencies.json',actual)
    results.append(dict(name=unit['name'],source=unit['source'],object=b.pin(folder/'unit.obj'),compile=process,
        actual_dependencies=b.pin(folder/'actual-dependencies.json')))
b.save(A/'ready.json',dict(units=results,compiled_TUs=1,plan=b.pin(A/'plan.json'),SDK_shader_vendor_builds=0))
print('CURRENT_VULKAN_PROGRAM_READY',json.dumps(b.pin(A/'ready.json')),flush=True)
