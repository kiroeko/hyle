
from pathlib import Path
import json,subprocess,csv
S=Path('/Users/kiro/hyle-scratch/compute-unified');P=S/'cpu-region-views-20261026/attempt1'
out={'recent_cpu_region_files':[str(x) for x in P.iterdir()] if P.is_dir() else []}
for p in [P/'ready.json',P/'plan.json',P/'link/command.json',P/'link/command.json',S/'mtp-runtime-backend-20261024/product-check1/summary.json']:
 if p.is_file():
  try:out[str(p)]=json.loads(p.read_text())
  except ValueError:pass
rows=csv.reader((S/'qwen-pure-cpu-functional-20261024/attempt1/inputs/weights.tsv').read_text().splitlines(),delimiter='\t')
paths={field for row in rows for field in row if field.startswith('/') and '.safetensors' in field}
out['physical_weights']=[{'path':p,'exists':Path(p).exists(),'bytes':Path(p).stat().st_size if Path(p).exists() else None} for p in paths]
F=S/'mtp-runtime-backend-20261024/product-check1'
out['backend_productcheck_files']=[str(p) for p in F.iterdir()] if F.is_dir() else []
lib=S/'architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/libhyle_compute_gdn_scale.a'
a=subprocess.run(['/usr/bin/ar','-t',str(lib)],text=True,capture_output=True,timeout=10)
out['core_archive_members']={'path':str(lib),'exit':a.returncode,'relevant':[x for x in a.stdout.splitlines() if any(y in x for y in ['resource_leases','copy','transfer','storage','memory'])],'stderr':a.stderr}
print(json.dumps(out))
