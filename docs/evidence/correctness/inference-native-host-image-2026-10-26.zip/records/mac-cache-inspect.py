
from pathlib import Path
import json,subprocess
S=Path('/Users/kiro/hyle-scratch/compute-unified');R=Path('/Users/kiro/hyle')
out={}
for rel in ['cpu-region-views-20261026','mtp-runtime-backend-20261024','qwen-cpu-apple-functional-20261024/attempt1','qwen-pure-cpu-functional-20261024/attempt1/inputs']:
 p=S/rel;out[rel]=[str(q) for q in p.iterdir()][:35] if p.is_dir() else []
P=S/'qwen-cpu-apple-functional-20261024/attempt1'
for rel in ['compile/model/command.json','link5/command.json']:
 p=P/rel;d=json.loads(p.read_text());a=d.get('command',d.get('argv',[]));out[rel]={'keys':list(d),'command':a}
 a=[x for x in a if isinstance(x,str) and x.startswith('/') and x.endswith(('.a','.o','.dylib'))]
 out[rel]['absolute_link_input_count']=len(a);out[rel]['missing']=[x for x in a if not Path(x).exists()]
weights=S/'qwen-pure-cpu-functional-20261024/attempt1/inputs/weights.tsv'
lines=weights.read_text().splitlines();out['weights_tsv_header']=lines[:4]
paths=set()
for line in lines:
 for field in line.split('\t'):
  if field.startswith('/') and ('.safetensors' in field or field.endswith(('.bin','.bf16','.f32'))):paths.add(field)
out['physical_model_paths']=[dict(path=x,exists=Path(x).exists(),bytes=Path(x).stat().st_size if Path(x).exists() else None) for x in sorted(paths)]
print(json.dumps(out))
