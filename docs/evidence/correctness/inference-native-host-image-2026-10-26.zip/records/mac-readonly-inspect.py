
from pathlib import Path
import json,subprocess,shutil
R=Path('/Users/kiro/hyle');S=Path('/Users/kiro/hyle-scratch/compute-unified')
def call(args):
 p=subprocess.run(args,text=True,capture_output=True,timeout=15);return dict(argv=args,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
model=call(['sysctl','-n','hw.model']);assert model['stdout'].strip()=='Mac16,12',model
out=dict(model=model,chip=call(['sysctl','-n','machdep.cpu.brand_string']),memory=call(['sysctl','-n','hw.memsize']),os=call(['sw_vers']),clang=call(['/usr/bin/clang++','--version']),sdk=call(['xcrun','--show-sdk-path']),disk=call(['df','-k',str(R),str(S)]),checkout_exists=R.is_dir(),work_exists=S.is_dir())
for key,base in [('checkout_recent',R/'.scratch'),('fixed_cache_recent',S)]:
 out[key]=[str(p) for p in sorted(base.iterdir(),key=lambda p:p.stat().st_mtime,reverse=True)[:20] if p.is_dir()] if base.is_dir() else []
paths=[S/'qwen-cpu-apple-functional-20261024/attempt1/plan.json',S/'qwen-cpu-apple-functional-20261024/attempt1/delta2-plan.json',S/'qwen-cpu-apple-functional-20261024/attempt1/compile/model/command.json',S/'qwen-cpu-apple-functional-20261024/attempt1/link5/command.json',S/'qwen-cpu-apple-functional-20261024/attempt1/hyle-cpu-apple-current5',S/'qwen-pure-cpu-functional-20261024/attempt1/inputs/weights.tsv',S/'qwen-k1-functional-20261024/attempt1/mlx.metallib',R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture',R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture/weights.tsv']
out['paths']=[dict(path=str(p),exists=p.exists(),bytes=p.stat().st_size if p.is_file() else None) for p in paths]
print(json.dumps(out))
