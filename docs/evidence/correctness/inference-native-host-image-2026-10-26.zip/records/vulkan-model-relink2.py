"""Relink successful Model/weights objects with three exact cached ABI leaves."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];P=W/'vulkan-model-attempt1';A=W/'vulkan-model-attempt2'
spec=importlib.util.spec_from_file_location('model_build',W/'vulkan-model.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b=m.b
p=b.read(P/'plan.json')
for row in b.read(p['source_freeze']['path']):b.exact(row)
old_inputs=b.read(p['inputs']['path']);pairs=[]
for suffix,new in [('f32-paged-check\\attempt2\\layout\\layout.obj',R/'.scratch/inference-layout-storage-validation-20261025/cpu1/compile/compute_batch--batch_layout/unit.obj'),('src--compute_batch--paged_arena-cc\\unit.obj',R/'.scratch/inference-host-image-20261026/arena/implementation/unit.obj'),('host1\\graph--resources.obj',R/'.scratch/inference-current-closure-20261026/unresolved-host/compile/graph--resources_cc/unit.obj')]:
    found=[x for x in old_inputs if x['path'].endswith(suffix)];assert len(found)==1
    pairs.append(dict(old=found[0],new=b.pin(new)))
objects=[b.pin(P/'compile'/name/'unit.obj') for name in ['model','weights']]
image=A/'link/host-image-vulkan-test.exe';command=[];count=0
replace={b.key(x['old']['path']):x['new'] for x in pairs}
for arg in b.read(P/'link/command.json')['command']:
    if b.key(arg) in replace:arg=replace[b.key(arg)]['path'];count+=1
    elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
    elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
    command.append(arg)
assert count==3
b.save(A/'plan.json',dict(prior_plan=b.pin(P/'plan.json'),prior_failed_link=b.pin(P/'link/command.json'),
    source_freeze=p['source_freeze'],reused_Model_weights=objects,replacements=pairs,
    source_and_symbol_check=b.pin(W/'vulkan-model-cache-leaves.json'),compiled_TUs=0,
    graph_resources_note='Reuse exactly the object already in current S/case; recorded source47ef5fa is git7d0c64626, current235b5f is498c6e346 writer publication optimization; ABI symbol set retained, no current-source compile claim.'))
h=b.helper();compiler=p['units'][0]['command'][0]
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
linked=h.execute(command,env,image.parent,timeout=120)
allreplace={b.key(x['old']['path']):x['new'] for x in p['replacements']+pairs}
inputs=[allreplace.get(b.key(x['path']),x) for x in old_inputs if x!=p['removed_model']]+objects+[p['added_report']]
b.save(A/'link-inputs.json',inputs);b.save(A/'runtime.json',b.read(p['runtime']['path']))
native=Path(p['native']['path']);os.link(native,image.parent/native.name)
b.save(A/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),runtime=b.pin(A/'runtime.json'),
    inputs=b.pin(A/'link-inputs.json'),plan=b.pin(A/'plan.json'),compiled_TUs=0,
    reused_compile_processes=[b.pin(P/'compile'/name/'process.json') for name in ['model','weights']],link=linked))
print('MODEL_RELINK_READY',json.dumps(b.pin(A/'ready.json')),flush=True)
