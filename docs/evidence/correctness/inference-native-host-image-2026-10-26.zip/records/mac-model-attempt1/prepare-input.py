from pathlib import Path
import hashlib,json,base64,subprocess,time
W=Path(__file__).resolve().parent;R=W.parents[2]
original=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'
old=b'"C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors"'
new=b'"/Users/kiro/hyle-scratch/compute-unified/models/qwen35-2b/model.safetensors"'
before=original.read_bytes();assert before.count(old)==335
after=before.replace(old,new);assert after.replace(new,old)==before
(W/'original-weights.tsv').write_bytes(before);(W/'adapted-weights.tsv').write_bytes(after)
remote='/Users/kiro/hyle-scratch/compute-unified/inference-native-host-image-20261026/model-attempt1'
payload=base64.b64encode(after).decode()
code=f'''from pathlib import Path\nimport base64,json,struct,hashlib,shlex\nw=Path({remote!r});d=w/'inputs';d.mkdir(exist_ok=True);p=d/'weights.tsv';assert not p.exists();p.write_bytes(base64.b64decode({payload!r}))\nphysical=Path('/Users/kiro/hyle-scratch/compute-unified/models/qwen35-2b/model.safetensors')\nwith physical.open('rb') as stream:\n length=struct.unpack('<Q',stream.read(8))[0];assert length<2000000;raw=stream.read(length);header=json.loads(raw)\nrows=[]\nfor line in p.read_text().splitlines()[3:]:\n t=shlex.split(line);rank=int(t[2]);shape=list(map(int,t[3:3+rank]));off=int(t[4+rank]);size=int(t[5+rank]);h=header[t[0]]\n assert h['dtype']==t[1] and h['shape']==shape and off==8+length+h['data_offsets'][0] and size==h['data_offsets'][1]-h['data_offsets'][0],t[0]\n rows.append(t[0])\nprint(json.dumps({{'status':'PASS_PATH_ONLY_ADAPTATION_AND_335_ROLE_HEADER_IDENTITY','roles':len(rows),'source_id':p.read_text().splitlines()[1],'physical':{{'path':str(physical),'bytes':physical.stat().st_size,'header_bytes':length,'header_sha256':hashlib.sha256(raw).hexdigest()}},'manifest':{{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}},'limit':'Read only8-byte length and existing safetensors header; no model body copied/downloaded/rehash.'}}))\n'''
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -'];start=time.perf_counter();p=subprocess.run(cmd,input=code,text=True,capture_output=True,timeout=30)
(W/'input-process.json').write_text(json.dumps(dict(command=cmd,exit=p.returncode,seconds=time.perf_counter()-start,stdout=p.stdout,stderr=p.stderr),indent=2)+'\n')
assert p.returncode==0,p.stderr
result=json.loads(p.stdout);result['original_manifest']=dict(path=str(original.resolve()),bytes=len(before),sha256=hashlib.sha256(before).hexdigest());result['adaptation']='Exactly one quoted physical path per335 role replaced; inverse replacement reproduces every original byte, including source ID/dtype/shape/offset/byte count.'
(W/'input-identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
