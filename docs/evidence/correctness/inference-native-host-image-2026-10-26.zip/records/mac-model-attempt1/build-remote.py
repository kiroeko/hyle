from pathlib import Path
import hashlib,json,os,signal,subprocess,time
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-native-host-image-20261026/model-attempt1')
P=json.loads((W/'plan.json').read_text())
def save(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(tag,cmd,timeout):
 d=W/tag;d.mkdir(exist_ok=False);save(d/'command.json',dict(command=cmd,cwd=str(W),environment=P['environment']))
 env=os.environ.copy();env.update(P['environment']);start=time.perf_counter()
 with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
  proc=subprocess.Popen(cmd,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True)
  save(d/'running.json',dict(pid=proc.pid,command=cmd));expired=False
  try:code=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;os.killpg(proc.pid,signal.SIGTERM)
   try:code=proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
 row=dict(tag=tag,pid=proc.pid,exit=code,timeout=expired,seconds=time.perf_counter()-start)
 save(d/'process.json',row);print(json.dumps(row),flush=True);return row
save(W/'hardware.json',dict(model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),
 chip=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),
 compiler=subprocess.check_output(['/usr/bin/clang++','--version'],text=True)))
rows=[]
for job in P['jobs']:
 row=run(job['tag'],job['command'],job['timeout']);rows.append(row)
 if row['exit'] or row['timeout']:break
if len(rows)==4 and all(r['exit']==0 for r in rows):
 image=W/'host-image'
 save(W/'ready.json',dict(image=pin(image),model_object=pin(W/'model.o'),weights_object=pin(W/'weights.o'),report_object=pin(W/'report.o'),
  plan=pin(W/'plan.json'),source_freeze=pin(W/'source-freeze.json'),
  budget_abi=pin(W/'budget-abi.json'),scope=P['scope']))
 for tag,option in [('run-apple',[]),('run-apple-lag1',['--mtp-lag1'])]:
  row=run(tag,[str(image),'--apple',str(W/'inputs'),*option],90);rows.append(row)
  if row['exit'] or row['timeout']:break
dependencies={}
for name in ['model.o.d','weights.o.d','report.o.d']:
 if (W/name).exists():dependencies[name]=(W/name).read_text()
save(W/'actual-dependencies.json',dependencies)
summary=dict(status='PASS' if len(rows)==6 and all(r['exit']==0 and not r['timeout'] for r in rows) else 'FAILED_OR_UNCOVERED',
 processes=rows,compiled_TUs=sum(r['tag'].startswith('compile-') for r in rows),model_runs=sum(r['tag'].startswith('run-') for r in rows),SDK_builds=0,HTTP=0,
 scope=P['scope'],limits=['Canonical full335 original BF16 Model consumer: ordinary+MTP HostImage path and independent explicit-prefix lag1 mode only; read actual run reports for completed scope.',
 'No quality/performance claim, no controlled physical GPU pending/fault injection; full HostImage pass is claimed only for actual exit0 PASS reports.',
 'No Apple device fault/unknown-retirement injection; successful original completions only. Retained SDK/native closure uses original source/ABI boundaries, not a claim every library was rebuilt from current source.'])
save(W/'summary.json',summary);print(json.dumps(dict(summary=summary)),flush=True)
