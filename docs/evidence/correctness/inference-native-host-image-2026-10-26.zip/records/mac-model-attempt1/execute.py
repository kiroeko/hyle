from pathlib import Path
import base64,hashlib,json,subprocess,time
W=Path(__file__).resolve().parent;R=W.parents[2]
remote='/Users/kiro/hyle-scratch/compute-unified/inference-native-host-image-20261026/model-attempt1'
files={n:base64.b64encode((W/n).read_bytes()).decode() for n in ['plan.json','source-freeze.json','budget-abi.json','build-remote.py']}
code=f'''from pathlib import Path\nimport base64,runpy\nw=Path({remote!r})\nfor name,data in {files!r}.items():\n p=w/name;assert not p.exists(),str(p);p.write_bytes(base64.b64decode(data))\nrunpy.run_path(str(w/'build-remote.py'),run_name='__main__')\n'''
freeze=json.loads((W/'source-freeze.json').read_text())
assert all(hashlib.sha256((R/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in freeze),'canonical source changed before build'
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -']
start=time.perf_counter()
with (W/'driver.stdout.log').open('wb') as out,(W/'driver.stderr.log').open('wb') as err:
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=out,stderr=err)
 (W/'driver-running.json').write_text(json.dumps(dict(pid=p.pid,command=cmd),indent=2)+'\n')
 p.communicate(code.encode('utf-8'))
(W/'driver-process.json').write_text(json.dumps(dict(pid=p.pid,exit=p.returncode,seconds=time.perf_counter()-start,command=cmd),indent=2)+'\n')
print((W/'driver.stdout.log').read_text())
print((W/'driver.stderr.log').read_text())
