from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path.cwd();W=R/'.scratch/inference-native-host-image-20261026';D=R/'docs/evidence/correctness'
def pin(p):
    p=Path(p);raw=p.read_bytes()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
win=read(W/'windows-final-summary.json');mac=read(W/'mac-model-attempt4/final-summary.json')
assert win['full_model']['result']=='PASS' and mac['ordinary_and_mtp']['status']=='PASS'
for name in ['run-ordinary-mtp','run-lag1']:
    assert read(W/'cuda-model-attempt3'/name/'process.json')['exit']==0
    assert read(W/'cuda-model-attempt3'/name/'stdout.log')['status']=='PASS'
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
code=[R/p for p in dict.fromkeys(changed+new) if (R/p).is_file() and not p.startswith('docs/')]
for p in code:assert p.suffix in ('.h','.cc','.inc','.cmake','.txt'),p
codepins=[pin(p) for p in code]
archive=D/'inference-native-host-image-2026-10-26.zip'
assert not archive.exists()
records=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in code:z.write(p,'source/'+p.relative_to(R).as_posix())
    for p in sorted(W.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(W)
        if any(part in ('fixtures','source','build','__pycache__') for part in rel.parts):continue
        if p.suffix not in ('.json','.log','.py','.d','.h','.cc'):continue
        if p.stat().st_size>3_000_000:continue
        z.write(p,'records/'+rel.as_posix());records.append(pin(p))
    z.writestr('sources.json',json.dumps(codepins,ensure_ascii=False,indent=2))
    z.writestr('record-index.json',json.dumps(records,ensure_ascii=False,indent=2))
    z.writestr('source.diff',subprocess.check_output(['git','diff','--binary','HEAD']))
    z.writestr('scope.txt','Bounded current inference state-transfer and consumer checks. Raw failed attempts retained. SDK/native inputs are reused with exact recorded object/ABI replacements, not a full rebuild. Native test output backend label was cpu for Apple/Vulkan; argv and loader determine actual backend. Display-only helper fixed after runs, no numerical/ownership code changed by that final fix.\n')
output=dict(date='2026-10-26',status='CPU_NATIVE_TRANSFER_AND_CUDA_APPLE_VULKAN_COMPLETE_IMAGES_PASSED_WITH_OPEN_VULKAN_STREAM_GAP',baseline_commit='86cf305dc',sources=codepins,archive=pin(archive),
 changes=['Independent HostStorage retains only real common StorageOwner or typed host resource and stable empty Backend identity. Apple shared Metal and Vulkan staging preserve original native resource ownership; no Model or Backend State is retained.',
 'StateTransfer selects original common/Apple/Vulkan Program/Invocation/Update. Apple original observation lock covers retirement source lookup and attachment. No duplicate executor or common Queue shell.',
 'ScopeAllocator preserves the actual allocator owner until allocate_shared control-block deallocation. Preparation failure recovers every successfully bound original writer; successful wait and real retirement precede complete writer recovery.',
 'Two native CopyStreamAccess declaration headers moved to installed route-owned detail headers; all old includes updated, no shim or native implementation/symbol change. Configure-only component ownership check passed.',
 'Full HostImage test accepts all four compiled backends. Fix Clang dependent-template syntax, complete aggregate initializers, and bounded locale-independent NF4 decimal parsing at existing macOS14.4 deployment floor.',
 'Fix test-only Apple/Vulkan output labels after measured runs. Raw reports and their incorrect cpu labels remain unchanged; actual native argv/loader and source snapshots are retained. No new run for display-only edit.'],
 checks=dict(small_windows=pin(W/'windows-final-summary.json'),small_apple=pin(W/'mac-attempt1/summary.json'),full_apple=pin(W/'mac-model-attempt4/final-summary.json'),
 full_cuda=dict(ready=pin(W/'cuda-model-attempt3/ready.json'),ordinary_mtp=read(W/'cuda-model-attempt3/run-ordinary-mtp/stdout.log'),lag1=read(W/'cuda-model-attempt3/run-lag1/stdout.log'),processes=[read(W/'cuda-model-attempt3'/n/'process.json') for n in ('run-ordinary-mtp','run-lag1')]),
 full_vulkan=dict(summary=pin(W/'windows-final-summary.json'),ready=pin(W/'vulkan-model-attempt7/ready.json'),ordinary_mtp_process=win['full_model']['process'],actual_backend='vulkan',raw_backend_label='cpu'),
 nf4_and_prepared_roles=dict(summary=pin(W/'nf4-parser-check/summary.json'),stdout=(W/'nf4-parser-check/run/stdout.log').read_text()),header_ownership=dict(process=read(W/'header-owner/process.json'),stdout=(W/'header-owner/stdout.log').read_text())),
 build_scope=['Incremental matching-feature Model/weights and specific stale core/caller leaves only; original SDK/vendor/native binaries reused. No shader/vendor/SDK rebuild or model download.',
 'Windows and Apple cache ABI changes were diagnosed from exact symbols/linker extraction, including removed public schema() and current origin_schema(). Not a mere return-type claim; no compatibility thunk or duplicate-ignore option.',
 'Source-identical current CUDA Graph resources was already selected from the publication-screen candidate object; an initial assumption that it used the older unresolved-host object was corrected before any CUDA relink.',
 'Windows COFF symbol-table ordering was not archive-member ordering. That attribution was corrected; final actual public.lib pull was identified through /VERBOSE:LIB as vulkan_program.cc.',
 'Apple original335 manifest changes only the physical path to existing local safetensors; all335 role/dtype/shape/offset/bytes and source identity checked against local header. No model body copied or downloaded.'],
 retained_failures=['MSVC small test initially used unsupported no-argument Status::ToString; fixed and recompiled.',
 'Common-only StateTransfer compile exposed an unused backend parameter under /WX; fixed without changing native behavior.',
 'Apple full consumer exposed floating from_chars availability and three strict Clang errors; repaired at unchanged platform floor.',
 'Old validation cache link failures and setup-script path/lookup mistakes are preserved. Their logs do not prove product failure or a passing runtime.',
 'Unchanged tiny GA/MTP Vulkan consumer failed before inference: stream native range/chunk alignment is unsupported. Full335 was checked separately; tiny failure remains open and was not replaced with a different fixture.'],
 new_gap=dict(name='Vulkan non-four-byte file input ranges',status='OPEN',failure=pin(W/'vulkan-model-attempt7/run-tiny/stderr.log'),
 exact_failing_role_from_runtime='NOT_REPORTED',
 source_basis=['src/compute_stream/file_stream.cc check_range requires physical range/chunk to satisfy original endpoint alignment.',
 'load_selected_weight_roles presently allocates and submits only exact role.bytes, leaving StreamReadRange.physical_bytes unset.',
 'Original FileResourcePipeline already supports explicit initialized tail padding and publishes only logical bytes. Next check should reuse this facility with actual owned padded allocation and budget, not widen an arbitrary lease or alter source/model math.']),
 limits=['Successful real native pending observations are not a controlled pending gate, device-fault or unknown-retirement injection.',
 'CPU lag1 not newly run; full quality, cross-backend bit identity and complete throughput comparison not claimed.',
 'Host image restore checks cover unchanged original335 short-context ordinary/MTP/lag1 on CUDA/Apple/Vulkan. Tiny Vulkan remains failed; no all-fixtures or all-models completion claim.',
 'Fixed device banks return logical slots, not necessarily physical VRAM. Public general retirement-attachment SDK contract remains unfinished.',
 'Current label helper is a display-only follow-up to archived runs. No raw evidence relabeling.'],HTTP_model_or_dependency_download_bytes=0,quality_claim=False,performance_claim=False)
path=D/'inference-native-host-image-2026-10-26.json';path.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=pin(path),archive=pin(archive),records=len(records),sources=len(codepins)),ensure_ascii=False))
