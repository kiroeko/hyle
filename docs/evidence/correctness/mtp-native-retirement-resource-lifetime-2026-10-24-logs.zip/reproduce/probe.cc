#include <array>
#include <chrono>
#include <cstdio>
#include <stdexcept>
#include <thread>
#include <vector>
#include "hyle/graph/vulkan.h"
#include "hyle/graph/executable.h"
#include "hyle/compute/vulkan_memory.h"
#include "src/compute_route_vulkan/vulkan_internal.h"

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace v = c::vulkan;
namespace d = v::detail;
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
void require(bool ok, const char *message) { if (!ok) throw std::runtime_error(message); }
struct Fault {
  d::Device &device;
  d::DeviceFunctions original;
  unsigned submits=0, idle_waits=0;
  bool fail_idle=false;
  static inline Fault *active=nullptr;
  explicit Fault(v::Context &context):device(*d::Access::runtime(context)->device),original(device.fn) {
    active=this; device.fn.QueueSubmit=submit; device.fn.QueueWaitIdle=idle;
  }
  ~Fault() { device.fn=original; active=nullptr; }
  static VKAPI_ATTR VkResult VKAPI_CALL submit(VkQueue queue,std::uint32_t count,const VkSubmitInfo *infos,VkFence fence) {
    if (++active->submits==2) return VK_ERROR_OUT_OF_HOST_MEMORY;
    return active->original.QueueSubmit(queue,count,infos,fence);
  }
  static VKAPI_ATTR VkResult VKAPI_CALL idle(VkQueue queue) {
    ++active->idle_waits;
    if (std::exchange(active->fail_idle,false)) return VK_ERROR_OUT_OF_HOST_MEMORY;
    return active->original.QueueWaitIdle(queue);
  }
};
int main() {
  std::setvbuf(stdout,nullptr,_IONBF,0);
  try {
    auto context=v::Context::create().value();
    std::printf("device=%s\n",context.environment().device_name.c_str());
    auto memory=v::MemoryResource::create(context,v::MemoryKind::kDevice).value();
    const auto description=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{17,2048}).value();
    std::vector<float> values(17*2048); for(std::size_t i=0;i<values.size();++i)values[i]=float(int(i%31)-15)*.1f;
    auto tensor=context.upload(description,std::as_bytes(std::span(values))).value();
    auto input=memory.import_readonly(tensor).value();
    auto builder=g::GraphBuilder::create().value();
    const auto x=builder.input(description).value();
    const auto a=builder.add(c::Unary{c::UnaryKind::kRelu},x).value();
    const auto b=builder.add(c::RmsNorm{},a).value();
    const auto y=builder.add(c::Unary{c::UnaryKind::kRelu},b).value();
    check(builder.publish(y));
    auto graph=std::move(builder).finish().value();
    const std::array domains{g::StorageDomain{memory.ref()}};
    const std::array targets{g::ExecutionTarget{g::vulkan::execution_source(context).value(),g::StorageDomainId{0}}};
    auto compiled=g::compile(graph,{domains,targets}).value();
    std::printf("regions=%zu\n",compiled.executable.region_count());
    auto slot=compiled.executable.create_invocation().value();
    check(slot.prepare_resources()); check(slot.bind(x,description,input)); check(slot.prepare_replay({}));
    Fault fault(context);
    auto done=slot.submit(); require(done.has_value(),"partial acceptance must return actual completion");
    std::printf("submits=%u inflight=%u pending=%u\n",fault.submits,unsigned(slot.in_flight()),unsigned(d::Access::runtime(context)->pending!=nullptr));
    require(fault.submits==2,"fixture did not reach native suffix");
    require(slot.in_flight(),"accepted prefix lost in-flight guard");
    auto observed=done->poll(); require(observed.has_value()&&*observed==c::CompletionPoll::kPending,"partial failure poll must not invent retirement");
    done=c::Completion{};
    const auto close=slot.close();
    require(close.IsUnavailable(),"Graph close must retain actual in-flight work");
    for(unsigned i=0;i<5;++i){const auto status=context.collect();require(status.IsResourceExhausted(),"collect must preserve original submit failure");std::this_thread::sleep_for(std::chrono::milliseconds(1));}
    require(slot.in_flight(),"nonblocking collection unexpectedly proved partial-prefix retirement");
    require(fault.idle_waits==0,"nonblocking collection performed a queue drain");
    std::printf("after_collect inflight=1 idle_waits=0\n");
    const auto recovered=context.close();
    require(recovered.IsResourceExhausted(),"must preserve rejected suffix diagnosis");
    require(!slot.in_flight(),"original Context drain must release graph guard");
    require(d::Access::runtime(context)->pending==nullptr,"drain left known-retired run pending");
    std::printf("after_close inflight=0 idle_waits=%u original_failure=%s\n",fault.idle_waits,recovered.message().data());
    return 0;
  } catch(const std::exception &e) { std::fprintf(stderr,"FAIL %s\n",e.what()); return 1; }
}
