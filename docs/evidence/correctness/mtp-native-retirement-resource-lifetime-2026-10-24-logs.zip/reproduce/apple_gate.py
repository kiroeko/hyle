from pathlib import Path
import json,subprocess,hashlib
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent
base='/Users/kiro/hyle-scratch/compute-unified/qwen-native-lifetime-audit-20261024'
files={p:(R/p).read_text(encoding='utf8') for p in ('engine/models/qwen35/native_gate_apple.mm','engine/models/qwen35/native_gate.h','engine/models/qwen35/backend.h','src/compute_route_apple/apple_runtime_internal.h')}
recipe=json.loads((R/'.scratch/qwen-apple-k1-20261024/results/compile17-macos144.json').read_text(encoding='utf8'))
command=[];skip=False
for flag in recipe['command']:
 if skip:skip=False;continue
 if flag in ('-o','-MF'):skip=True;continue
 if flag.endswith('.cc'):continue
 command.append(flag)
command[1:1]=['-I'+base+'/source/include','-I'+base+'/source/engine/models/qwen35']
command+=['-MF',base+'/gate.d',base+'/source/engine/models/qwen35/native_gate_apple.mm','-o',base+'/gate.o']
payload=json.dumps({'base':base,'files':files,'command':command})
remote='''import json,sys,subprocess,time,hashlib,platform
from pathlib import Path
d=json.loads(%r);base=Path(d['base']);base.mkdir(parents=True,exist_ok=True)
for p,s in d['files'].items():
 q=base/'source'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s,encoding='utf8')
start=time.time();p=subprocess.run(d['command'],cwd=base,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
(base/'stdout.log').write_bytes(p.stdout);(base/'stderr.log').write_bytes(p.stderr)
r={'command':d['command'],'cwd':str(base),'exit':p.returncode,'seconds':time.time()-start,'source_sha256':{k:hashlib.sha256((base/'source'/k).read_bytes()).hexdigest() for k in d['files']},'hardware':subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),'toolchain':subprocess.check_output(['/usr/bin/c++','--version'],text=True).strip(),'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}
(base/'result.json').write_text(json.dumps(r,indent=2)+'\\n');print(json.dumps(r));sys.exit(p.returncode)
'''%payload
p=subprocess.run(['ssh','kiro@172.22.10.198','python3','-'],input=remote.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=150,creationflags=subprocess.CREATE_NO_WINDOW)
(S/'apple-gate-ssh.stderr').write_bytes(p.stderr)
(S/'apple-gate-result.json').write_bytes(p.stdout)
print('apple gate exit',p.returncode);print(p.stdout.decode(errors='replace')[-2000:]);raise SystemExit(p.returncode)
