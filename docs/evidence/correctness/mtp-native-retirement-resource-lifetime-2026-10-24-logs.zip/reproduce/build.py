from pathlib import Path
import json,os,subprocess,sys,time,hashlib
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2]
S=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
recipe=read(R/'.scratch/qwen-vulkan-k1-20261024/build1/model-compile/command.json')['command']
compiler=recipe[0]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def execute(command,out,timeout=240):
 out.mkdir(parents=True,exist_ok=True);save(out/'command.json',{'command':command,'cwd':str(R),'timeout':timeout})
 started=time.time()
 with (out/'stdout.log').open('wb') as a,(out/'stderr.log').open('wb') as b:
  p=subprocess.run(command,cwd=R,env=env,stdout=a,stderr=b,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
 save(out/'process.json',{'exit':p.returncode,'seconds':time.time()-started});print(out.name,p.returncode,flush=True)
 if p.returncode:raise SystemExit('failed '+str(out))
def compile(source,out,extra=()):
 flags=[];skip=False
 for item in recipe[1:]:
  if skip:skip=False;continue
  if item=='/sourceDependencies':skip=True;continue
  if item.lower().startswith(('/fo','/fd')) or item.lower().endswith('.cc'):continue
  flags.append(item)
 command=[compiler,*flags,*extra,'/I'+str(R),'/I'+str(R/'engine/models/qwen35'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb'),'/sourceDependencies',str(out/'deps.json'),str(source)]
 execute(command,out)
 save(out/'source.json',{'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
def link(obj,out,extra=()):
 command=read(R/'.scratch/qwen-vulkan-k1-20261024/build1/ready.json')['command']
 flags=[]
 for item in command[1:]:
  low=item.lower()
  if low.endswith('entry.obj') or 'model-compile' in low or low.startswith(('/out:','/pdb:','/map:')):continue
  if low.endswith('graph--executable.obj'):item=str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj')
  flags.append(item)
 execute([command[0],str(obj),*extra,*flags,'/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb'),'/MAP:'+str(out/'probe.map')],out)
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='gate':compile(R/'engine/models/qwen35/native_gate.cc',S/'gate-vulkan')
 elif mode=='probe':
  compile(S/'probe.cc',S/'probe-compile');link(S/'probe-compile/unit.obj',S/'probe-link')
 elif mode=='run':execute([str(S/'probe-link/probe.exe')],S/'probe-run',60)
 elif mode=='regression':
  compile(R/'src/compute_route_vulkan/vulkan_device.cc',S/'device')
  compile(R/'src/compute_route_vulkan/vulkan_memory.cc',S/'memory')
  compile(R/'src/compute_route_vulkan/vulkan_run.cc',S/'run')
  compile(R/'tests/graph_route_vulkan/retirement_test.cc',S/'regression-compile',('/IC:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include',))
  link(S/'regression-compile/unit.obj',S/'regression-link',(str(S/'device/unit.obj'),str(S/'memory/unit.obj'),str(S/'run/unit.obj'),str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')))
 elif mode=='regression-run':execute([str(S/'regression-link/probe.exe')],S/'regression-run',60)
 elif mode=='regression-final':
  compile(R/'src/compute_route_vulkan/vulkan_memory.cc',S/'memory')
  compile(R/'tests/graph_route_vulkan/retirement_test.cc',S/'regression-compile',('/IC:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include',))
  link(S/'regression-compile/unit.obj',S/'regression-link',(str(S/'device/unit.obj'),str(S/'memory/unit.obj'),str(S/'run/unit.obj'),str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')))
 elif mode=='syntax':
  compile(R/'engine/models/qwen35/main.cc',S/'main-vulkan-syntax',('/Zs',))
 elif mode=='syntax-cpu':
  recipe=read(R/'.scratch/qwen-multi-draft-20261024/geometry-cpu-check2/compile-command.json')
  if isinstance(recipe,dict):recipe=recipe['command']
  compile(R/'engine/models/qwen35/main.cc',S/'main-cpu-syntax',('/Zs',))
 elif mode=='gate-selection':execute([sys.executable,str(R/'tests/tooling/engine_components_test.py'),'EngineComponentsTest.test_retirement_gate_follows_the_selected_route_on_macos'],S/'gate-selection',90)
 elif mode=='model-test':
  compile(R/'tests/tools/qwen_resource_retirement_test.cc',S/'model-test-compile',('/IC:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include',))
  link(S/'model-test-compile/unit.obj',S/'model-test-link',(str(S/'device/unit.obj'),str(S/'memory/unit.obj'),str(S/'run/unit.obj'),str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')))
 elif mode=='model-test-run':execute([str(S/'model-test-link/probe.exe')],S/'model-test-run',90)
