"""Authorized finite current-source component build/run, one backend per call.

No SDK/core/provider rebuild, downloading, route forcing, profiling or retries.
"""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
kind=sys.argv[1];attempt=sys.argv[2] if len(sys.argv)>2 else 'attempt1'
assert kind in ('cpu','cuda') and attempt.replace('-','').isalnum()
T=D/('original-'+kind)/attempt;T.mkdir(parents=True,exist_ok=False)
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
source=D/'source/original_component.cc'
checked=b.read(D/'private-source-pins.json')['private_sources']
for row in checked:
    actual=b.pin(R/row['path']);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']
assert b.pin(R/'engine/models/qwen35/main.cc')['sha256']=='f8fbb80d369cc8a2c1dfcc5e6442b57af21047cef0be9de2b32ce74111c3cd7b'
b.save(T/'checked-source-pins.json',checked)
base=R/'.scratch/inference-prefix-admission-20261025/attempt3' if kind=='cpu' else R/'.scratch/inference-kimi-original-binding-20261025/native-case/compile-check2'
original=b.args(base/'compile/command.json');flags=[];skip=False
for word in original[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    lower=word.lower().replace('\\','/')
    if lower.startswith(('/fo','/fd')) or lower.endswith(('.cc','.cpp')):continue
    if lower.startswith(('/i','-i')) and '/.scratch/' in lower and (
        'inference-prefix-admission-20261025/source' in lower or
        'inference-kimi-original-binding-20261025' in lower):continue
    if lower.startswith(('/dhyle_test_','-dhyle_test_')):continue
    flags.append(word)
assert '/W4' in flags and '/WX' in flags
assert any('HYLE_COMPUTE_'+kind.upper()+'=1' in word for word in flags),('wrong backend macros',flags)
env=b.environment(original[0])
b.execute([original[0],'/I'+str(D/'source'),'/I'+str(R),*flags,str(source),
    '/sourceDependencies',str(T/'dependencies.json'),'/Fo'+str(T/'consumer.obj'),'/Fd'+str(T/'consumer.pdb')],T/'compile',env,120)
deps=b.read(T/'dependencies.json')['Data'];paths=[Path(name).resolve() for name in [deps['Source'],*deps['Includes']]]
selected={str(path).lower() for path in paths}
for row in checked:assert str((R/row['path']).resolve()).lower() in selected,('not compiled',row)
for name in ['engine/models/qwen35/main.cc','engine/models/qwen35/projection_binding.h',
             'engine/inference/backend.h','tests/compute_models/static_fp8_reference_fixture.h']:
    assert str((R/name).resolve()).lower() in selected,('not canonical',name)
assert not any(path.is_relative_to(D/'source/engine') or path.is_relative_to(D/'source/tests') for path in paths),'old shadow selected'
b.save(T/'actual-repository-dependencies.json',[b.pin(path) for path in paths if path.is_relative_to(R)])
old=b.args(base/'link/command.json');old_app=base/('compile/unit.obj' if kind=='cpu' else 'consumer.obj')
link=[];count=0
for word in old[1:]:
    if word.lower()==str(old_app).lower():link.append(str(T/'consumer.obj'));count+=1
    elif not word.lower().startswith(('/out:','/pdb:','/implib:','/map:')):link.append(word)
assert count==1,('old app mismatch',old_app)
b.execute([old[0],*link,'/OUT:'+str(T/'component.exe'),'/IMPLIB:'+str(T/'component.lib'),
           '/PDB:'+str(T/'component.pdb')],T/'link',env,120)
libraries=[Path(word[len('/LIBPATH:'):].strip('"')) for word in link if word.upper().startswith('/LIBPATH:')]
libraries += [Path(word) for word in env.get('LIB','').split(';') if word]
def resolve(word):
    path=Path(word)
    if path.is_file():return path
    for folder in libraries:
        if (folder/path).is_file():return folder/path
    raise RuntimeError('Retained input missing: '+word)
inputs=[dict(argument=word,**b.pin(resolve(word))) for word in link if not word.startswith('/') and word.lower().endswith(('.obj','.lib'))]
assert len(inputs)==(153 if kind=='cpu' else 232)
b.save(T/'actual-link-inputs.json',inputs)
if kind=='cpu':
    runtime=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json'
    env['PATH']=b.read(runtime)['PATH']
    native=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
else:
    runtime=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json'
    env['PATH']=b.read(runtime)['PATH']
    native=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
os.link(native,T/native.name)
ready={'image':b.pin(T/'component.exe'),'object':b.pin(T/'consumer.obj'),'native':b.pin(native),
       'runtime':b.pin(runtime),'sources':checked,'link_inputs':len(inputs),'new_TUs':1,'SDK_core_provider_builds':0}
b.save(T/'ready.json',ready)
complete=D/'original-payload/attempt1/complete.json'
b.save(T/'run-inputs.json',{'original_complete':b.pin(complete),'image':ready['image'],
    'native':ready['native'],'GPU_window':'root explicitly authorized, no idle gate' if kind=='cuda' else 'CPU only',
    'source_payload_bytes':5242888,'whole_shard_body_verified':False,'no_new_HTTP':True})
b.execute([str(T/'component.exe'),str(complete.parent),str(T/'results'),kind],T/'run',env,120)
result=b.read(T/'results/summary.json');assert result['status']=='PASS_ORIGINAL_STATIC_FP8_COMPONENT'
assert result['graph_submissions']==2 and result['checked_output_values']==4096
print(json.dumps({'status':'PASS','backend':kind,'results':result,'directory':str(T.relative_to(R))}))
