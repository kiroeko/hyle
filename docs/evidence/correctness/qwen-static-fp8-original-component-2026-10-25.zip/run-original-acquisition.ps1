$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
if ($taskRoot -ne 'C:\public\project-hyle\hyle') { throw 'Unexpected workspace' }
$taskLogs=Join-Path $PSScriptRoot 'original-payload'
New-Item -ItemType Directory -Path $taskLogs -ErrorAction Stop | Out-Null
$taskArguments=@('.scratch/mtp-download-budget-20261023/budget.py','run','.scratch/inference-qwen-static-fp8-20261025/acquire-original-component.py')
$taskCommand=[ordered]@{program=(Get-Command python).Source;arguments=$taskArguments;cwd=$taskRoot;scope='One original static FP8 projection, exact5,242,888B,3parts, mirror-only, no retries';pause_owner='Existing live Kimi batch session42867, re-polled live immediately before this explicit small batch; no marker mutation by this wrapper'}
$taskCommand | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $taskLogs 'command.json') -Encoding utf8
$taskStart=[DateTimeOffset]::UtcNow
Push-Location -LiteralPath $taskRoot
try {
  & python @taskArguments 1> (Join-Path $taskLogs 'stdout.log') 2> (Join-Path $taskLogs 'stderr.log')
  $taskExit=$LASTEXITCODE
} finally {
  Pop-Location
}
$taskResult=[ordered]@{exit=$taskExit;started_utc=$taskStart.ToString('o');finished_utc=[DateTimeOffset]::UtcNow.ToString('o');seconds=([DateTimeOffset]::UtcNow-$taskStart).TotalSeconds;PAUSED_modified=$false}
$taskResult | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskLogs 'process.json') -Encoding utf8
$taskResult | ConvertTo-Json
exit $taskExit
