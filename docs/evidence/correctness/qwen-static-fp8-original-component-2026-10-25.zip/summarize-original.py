"""Offline summary of the two authorized original component processes."""
from pathlib import Path
import hashlib,json,struct
R=Path.cwd();D=Path(__file__).resolve().parent
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def pin(path):return {'path':str(path.relative_to(R)),'bytes':path.stat().st_size,
                      'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
complete=read(D/'original-payload/attempt1/complete.json')
paths={kind:D/('original-'+kind)/'attempt1' for kind in ('cpu','cuda')}
cases={}
for kind,path in paths.items():
    result=read(path/'results/summary.json')
    assert read(path/'run/process.json')['exit']==0
    assert result['graph_submissions']==2 and result['checked_output_values']==4096
    deps=read(path/'actual-repository-dependencies.json')
    main=next(row for row in deps if row['path'].replace('\\','/').endswith('/engine/models/qwen35/main.cc'))
    assert main['sha256']=='f8fbb80d369cc8a2c1dfcc5e6442b57af21047cef0be9de2b32ce74111c3cd7b'
    results=path/'results'
    assert (results/'input0.bf16').read_bytes()!=(results/'input1.bf16').read_bytes()
    assert (results/'output0.bf16').read_bytes()!=(results/'output1.bf16').read_bytes()
    assert len((results/'numeric.tsv').read_text().splitlines())-1==4096
    stages=['compile','link','run'] if kind=='cpu' else ['compile','link','link2','run']
    cases[kind]={'result':result,'actual_main_dependency':main,
        'processes':{stage:read(path/stage/'process.json') for stage in stages},
        'actual_link_inputs':read(path/'ready.json')['link_inputs'],
        'runtime_image':read(path/'ready.json')['image'],
        'inputs_different':True,'outputs_different':True,
        'route':pin(results/'route.tsv'),'numeric_intervals':pin(results/'numeric.tsv'),
        'actual_sources':str((path/'actual-repository-dependencies.json').relative_to(R)),
        'raw_command_folders':[str((path/stage).relative_to(R)) for stage in stages]}
assert cases['cuda']['processes']['link']['exit']==1120
assert cases['cuda']['processes']['link2']['exit']==0
source=read(D/'private-source-pins.json')['private_sources']
for row in source:
    actual=pin(R/row['path']);assert actual==row
summary={'status':'PASS_ORIGINAL_STATIC_FP8_CPU_DEFAULT_DECOMPOSITION_AND_CUDA_DEFAULT_PACKED',
    'original_source':complete,'source_pins':source,'cases':cases,
    'new_app_TUs':2,'new_SDK_core_provider_TUs':0,'actual_consumer_processes':2,
    'actual_submissions':4,'total_checked_output_values':8192,
    'original_acquisition_requests':3,'original_acquisition_bytes':5242888,
    'new_HTTP_by_build_or_consumers':0,'canonical_edits':0,'GPU':'RELEASED',
    'first_failure':'CUDA app link omitted cached formatter OBJ from Kimi-only template; fixed by link-only addition of the identical existing CPU formatter leaf; no source/math/oracle change.',
    'limits':[
      'One real k_proj component, BF16 A/Y and original E4 W plus independent original F32 SA/SW; no full Q27 model/quality/LM-token claim.',
      'No provider was forced. CPU uses6 decomposition steps and may have transient F32 weight cast workspace; CUDA uses1 original-artifacts-cuda packed static step.',
      'Numeric acceptance follows the public F32-dot analytic interval then separate F32 SA/SW multiplies and final BF16 rounding; no empirical tolerance widening or sequential-F32 dense bit-identity requirement.',
      'Current actual scales are finite positive and tests stay within the finite certificate domain; exceptional-scale semantics retain the existing independent generic fixtures, not a new actual-domain run.',
      'No new Apple/Vulkan, cancellation/unknown-retirement fault injection, benchmark/throughput or provider private physical-memory-cap claim.',
      'Partial exact source ranges verified; whole shard LFS body was not downloaded or validated.',
      'Original Kimi23-role download/numeric work remains separate and is not qualified by these static FP8 processes.'
    ]}
(D/'original-component-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':summary['status'],'summary':str((D/'original-component-summary.json').relative_to(R)),
                  'CPU_packed_steps':cases['cpu']['result']['actual_packed_static_steps'],
                  'CUDA_packed_steps':cases['cuda']['result']['actual_packed_static_steps']}))
