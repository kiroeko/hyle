"""Offline source/command provenance only; no compile/link/native/HTTP."""
from pathlib import Path
import hashlib,json
R=Path.cwd();D=Path(__file__).resolve().parent
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def pin(path):return {'path':str(path.relative_to(R)),'bytes':path.stat().st_size,
                      'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def command(path):
    row=read(path);return row['command'] if isinstance(row,dict) else row
source=[pin(D/'source'/name) for name in ['original_component.cc','original_input.h','original_reference.h']]
canonical=[R/path for path in ['engine/models/qwen35/main.cc','engine/models/qwen35/projection_binding.h',
    'engine/inference/backend.h','engine/inference/prepared_output.h','engine/inference/execution_resources.h',
    'tests/tools/qwen_geometry_fixture.h','tests/compute_models/static_fp8_reference_fixture.h',
    'tests/compute_provider_native/half_test_support.h']]
compile_cpu=R/'.scratch/inference-prefix-admission-20261025/attempt3/compile/command.json'
link_cpu=R/'.scratch/inference-prefix-admission-20261025/attempt3/link/command.json'
compile_cuda=R/'.scratch/inference-kimi-original-binding-20261025/native-case/compile-check2/compile/command.json'
link_cuda=R/'.scratch/inference-kimi-original-binding-20261025/native-case/compile-check2/link/command.json'
closure={}
for kind,compile_path,link_path in [('cpu',compile_cpu,link_cpu),('cuda',compile_cuda,link_cuda)]:
    inputs=[arg for arg in command(link_path)[1:] if not arg.startswith('/') and arg.lower().endswith(('.obj','.lib'))]
    closure[kind]={'compile_recipe':pin(compile_path),'link_recipe':pin(link_path),
        'original_object_library_inputs':len(inputs),'one_app_object_replacement':True,
        'new_SDK_core_provider_TUs':0}
complete_path=D/'original-payload/attempt1/complete.json'
complete=read(complete_path)
assert complete['repository']=='nvidia/Qwen3.8-27B-NVFP4' and complete['revision']=='482ca0f3832238542f8f5295dde86b5f22711d80'
assert complete['payload_bytes']==5242888 and len(complete['roles'])==3 and len(complete['parts'])==3
out={'status':'PRIVATE_SOURCE_AND_RECIPE_ONLY_NOT_COMPILED_OR_RUN',
    'private_sources':source,'observed_canonical_not_compile_freeze':[pin(path) for path in canonical],
    'exact_acquisition':pin(complete_path),'original_bytes':5242888,
    'source_body_LFS_whole_file_verified':False,'future_closure':closure,
    'no_forced_packed_route':True,'new_compiles':0,'new_runs':0,'new_HTTP_by_source_preparation':0,
    'canonical_product_edits':0,'Kimi_READY_unchanged':True}
(D/'private-source-pins.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':out['status'],'sources':source,'closure_input_counts':
                  {kind:value['original_object_library_inputs'] for kind,value in closure.items()}}))
