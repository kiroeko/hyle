"""Counted, exact original 5MiB static projection; no retries or pause changes."""
from pathlib import Path
import hashlib
import importlib.util
import inspect
import json
import sys
import urllib.request

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
R=HERE.parents[1]
SCRIPT=Path(__file__).resolve().relative_to(R).as_posix()
COUNTER=R/'.scratch/mtp-download-budget-20261023/budget.py'
TRANSPORT=R/'.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py'
OUT=HERE/'original-payload/attempt1'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))

def run():
    plan=read(HERE/'original-component-plan.json')
    assert plan['repository']=='nvidia/Qwen3.8-27B-NVFP4'
    assert plan['revision']=='482ca0f3832238542f8f5295dde86b5f22711d80'
    assert plan['total_payload_bytes']==5242888
    assert plan['unions']==[[126712,126719],[3898001984,3903244863]]
    assert sha(COUNTER.read_bytes())=='24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17'
    assert sha(TRANSPORT.read_bytes())=='3dc89fb1efc369615d7a3132bd08b3aabcf125259498b5f8581cec83d559a7da'
    guard=urllib.request.urlopen
    assert Path(guard.__code__.co_filename).resolve()==COUNTER.resolve()
    assert inspect.getclosurevars(guard).nonlocals.get('script')==SCRIPT
    spec=importlib.util.spec_from_file_location('retained_static_range_reader',TRANSPORT)
    transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport)
    transport.SCRIPT=SCRIPT;budget=transport.module()
    budget.require_enabled()
    cache=R/'.scratch/mtp-metadata-offline-20261024/indexes/cat07'
    raw_api=(cache/'expanded-api.json').read_bytes();raw_tree=(cache/'tree-api.json').read_bytes()
    assert sha(raw_api)=='fb4d87a30f827aa7e02286044178ba5697b949e30ead5792df593beb2eba42c4'
    assert sha(raw_tree)=='4c7409ce555bb1c66683452fb5faf63a2c37a29f844e7d04f2d0c5e4f9c6f9f7'
    row=dict(repository=plan['repository'],revision=plan['revision'],file=plan['file'],
             uri=f'https://hf-mirror.net/{plan["repository"]}/resolve/{plan["revision"]}/{plan["file"]}')
    source=transport.crosscheck_tree_identity(row,raw_api,raw_tree)
    assert source['size']==plan['source_bytes']
    assert plan['original_header_etag'].strip('"') in (source['lfs_sha256'],source['api_xet_hash'])
    assert sha(Path(plan['header']['path']).read_bytes())==plan['header']['sha256']
    OUT.mkdir(parents=True,exist_ok=False)
    transport.save(OUT/'source.json',source)
    fetch=transport.Fetch(budget,row,timeout=45,receipt_dir=OUT)
    with budget.locked() as ledger:start=len(ledger['requests'])
    admitted=written=0;parts=[];complete=None
    try:
        for index,((first,last),name) in enumerate(zip(plan['unions'],['scales.f32','weight.e4m3'])):
            with (OUT/name).open('xb') as output:
                for a in range(first,last+1,4194304):
                    b=min(a+4194303,last);amount=b-a+1
                    assert 0<amount<=5242888-admitted
                    admitted+=amount
                    raw,receipt=fetch.get(a,b,source=source)
                    assert len(raw)==amount
                    output.write(raw);output.flush();written+=amount
                    parts.append(dict(path=name,offset=a-first,range=[a,b],bytes=amount,
                                      sha256=sha(raw),receipt_id=receipt['budget_request_id']))
        roles=[]
        for role in plan['roles']:
            name='weight.e4m3' if role['dtype']=='F8_E4M3' else 'scales.f32'
            offset=0 if name=='weight.e4m3' else role['absolute_range'][0]-plan['unions'][0][0]
            with (OUT/name).open('rb') as f:
                f.seek(offset);raw=f.read(role['bytes'])
            assert len(raw)==role['bytes']
            roles.append(dict(role,path=name,offset=offset,sha256=sha(raw)))
        assert admitted==written==5242888 and len(parts)==3
        complete=dict(status='ACQUIRED_ONLY_ONE_ORIGINAL_STATIC_FP8_PROJECTION',
            repository=plan['repository'],revision=plan['revision'],source=source,
            base=plan['base'],roles=roles,parts=parts,payload_bytes=written,
            numeric_checked=False,whole_file_LFS_body_verified=False,automatic_retries=0)
        transport.save(OUT/'complete.json',complete)
    finally:
        with budget.locked() as ledger:
            rows=[x for x in ledger['requests'][start:] if x['script']==SCRIPT]
        received=sum(x.get('received_bytes') or 0 for x in rows)
        assert received<=admitted<=5242888
        result=dict(status='PASS' if complete else 'FAILED_NO_RETRY',requests=len(rows),
            request_ids=[x['id'] for x in rows],received_bytes=received,verified_written_bytes=written,
            received_bytes_by_final_host={host:sum((x.get('received_bytes') or 0) for x in rows if x.get('final_host')==host)
                for host in {x.get('final_host') for x in rows}},
            PAUSED_modified=False,automatic_retries=0,original_numeric_checked=False)
        transport.save(OUT/'transfer-summary.json',result)
        print(json.dumps(result),flush=True)
if __name__=='__main__':run()
