// Private original component consumer, not product lifecycle instrumentation.
// Only these three original roles are loaded; no Model/full bank is created.
#include "../../../engine/models/qwen35/main.cc"
#include "../../../tests/tools/qwen_geometry_fixture.h"
#include <gtest/gtest.h> // Existing test oracle declarations only, after product code.
#include "original_reference.h"
#include "original_input.h"

namespace q=qwen35;
namespace ref=qwen_static_fp8_original_reference;
namespace source=qwen_static_fp8_original_input;
namespace {
void require(bool condition,const char *message) {if(!condition)throw std::runtime_error(message);}
std::vector<std::byte> read(const q::Backend &backend,const q::c::ReadLease &lease) {
  std::vector<std::byte> bytes(lease.size());q::check(backend.read(q::take(lease.view()),bytes));return bytes;
}
void save(const std::filesystem::path &path,std::span<const std::byte> raw) {
  std::ofstream output(path,std::ios::binary);output.write(reinterpret_cast<const char*>(raw.data()),std::streamsize(raw.size()));
  if(!output)throw std::runtime_error("cannot write original static FP8 observation");
}
void check_output(std::span<const std::byte> bytes,std::span<const std::uint16_t> input,
    const source::Data &data,std::ostream &numeric) {
  require(bytes.size()==2*1024*2,"original static FP8 BF16 output extent changed");
  const auto qcodes=ref::codes(input,data.sa);const auto weight=data.weights();
  for(std::size_t m=0;m<2;++m)for(std::size_t n=0;n<1024;++n) {
    const auto interval=ref::row(std::span(qcodes).subspan(m*5120,5120),weight.subspan(n*5120,5120),data.sa,data.sw);
    std::uint16_t bits=0;std::memcpy(&bits,bytes.data()+2*(m*1024+n),2);
    const auto actual=half_test::decode_bits<ref::f::BF16>(bits);
    if(!std::isfinite(actual)||actual<interval.low||actual>interval.high)
      throw std::runtime_error("original dense static FP8 output is outside the public F32-dot/ordered-scales/BF16 interval");
    numeric<<m<<'\t'<<n<<'\t'<<std::setprecision(17)<<actual<<'\t'<<interval.low<<'\t'<<interval.high
        <<'\t'<<interval.center<<'\t'<<interval.bound<<'\t'<<interval.sumabs<<'\n';
  }
}
}
int main(int argc,char **argv) {try {
  if(argc!=4)throw std::runtime_error("original_component SOURCE_DIR OUTPUT_DIR cpu|cuda");
  const std::filesystem::path directory=argv[1],output=argv[2];
  const auto kind=std::string_view(argv[3])=="cpu"?q::BackendKind::kCpu:
      std::string_view(argv[3])=="cuda"?q::BackendKind::kCuda:q::BackendKind::kDefault;
  require(kind!=q::BackendKind::kDefault,"select cpu or cuda explicitly");
  const auto data=source::load(directory);
  auto backend=q::take(q::Backend::create({kind,false}));
  std::filesystem::create_directories(output);
  std::array<q::c::ReadLease,2> escaped;
  q::c::ReadLease escaped_weight;
  std::array<std::vector<std::byte>,2> observations;
  std::array<std::vector<std::uint16_t>,2> input_values;
  std::size_t packed=0,steps=0,workspace=0;
  {
    std::map<std::string,q::LoadedWeight> bank;
    const auto add=[&](std::string name,q::c::TensorDesc description,std::span<const std::byte> raw) {
      auto &value=bank.try_emplace(name,q::LoadedWeight{q::Tensor(backend.device(),description)}).first->second;
      value.tensor.write<std::byte>(raw);
    };
    const auto name=std::string(source::base)+".weight";
    add(name,q::dense(q::Type::kFloat8E4M3FN,{1024,5120}),data.weights());
    add(std::string(source::base)+".input_scale",q::dense(q::Type::kFloat32,{}),data.scale_bytes().first(4));
    add(std::string(source::base)+".weight_scale",q::dense(q::Type::kFloat32,{}),data.scale_bytes().subspan(4,4));
    bank.at(name).codec=q::prepared::ProjectionCodec::kModelOptStaticFp8;
    q::ProjectionBindings projections;projections.emplace(name,q::resolve_projection(bank,name));
    require(std::holds_alternative<q::ModelOptStaticFp8Projection>(projections.at(name)),"cold resolver changed original source codec");
    const auto geometry=qwen_test::q27(false);
    q::GraphAssembly assembly(backend);
    q::Recipe recipe(bank,projections,assembly,geometry,2);
    const auto x=recipe.input(q::dense(q::Type::kBFloat16,{2,5120}));
    const auto y=recipe.linear_absolute(x,name);recipe.publish(y);
    require(bank.size()==3&&assembly.constants.size()==3,"original W/SA/SW must stay three separate source operands");
    const auto graph=q::take(std::move(recipe.builder).finish());
    const std::array shape{q::g::ShapeBinding{recipe.last_row,1}};
    const std::array variants{q::g::ExactShapeVariant{shape}};
    auto compiled=q::take(backend.compile(graph,assembly.constants,assembly.options({
        .shape_policy=q::g::CompileShapePolicy::kFiniteExact,.exact_variants=variants,.constants=assembly.constants})));
    compiled.executable=q::take(compiled.executable.exact_variant(0));compiled.report=q::take(compiled.report.exact_variant(0));
    const auto facts=q::take(hyle::inference::prepare_output(compiled,y));
    require(facts.description==q::dense(q::Type::kBFloat16,{2,1024}),"static FP8 projection output is not original BF16[2,1024]");
    auto queues=q::take(hyle::inference::prepare_queue_bindings(backend.queue_bindings(),compiled.report));
    const auto bindings=hyle::inference::queue_span(queues);
    std::ofstream route(output/"route.tsv");route<<"step\tprovider\timplementation\tpolicy\tlogical_ops\n";
    require(bool(route),"cannot write original static FP8 route report");
    for(std::size_t i=0;i<compiled.report.step_count();++i) {
      const auto step=q::take(compiled.report.step(i));packed+=step.policy==ref::f::kPackedPolicy;
      route<<i<<'\t'<<step.provider.name<<'\t'<<step.implementation.value()<<'\t'<<(step.policy==ref::f::kPackedPolicy);
      for(std::size_t n=0;n<step.node_count;++n)
        route<<'\t'<<q::c::operation_name(q::take(graph.operation_kind(q::take(compiled.report.step_node(i,n)))));
      route<<'\n';
    }
    steps=compiled.report.step_count();workspace=compiled.report.workspace_bytes();
    route.flush();require(bool(route),"original static FP8 route write failed");
    escaped_weight=bank.at(name).tensor.ready;
    require(bool(escaped_weight),"Recipe did not retain the original E4 code lease");
    std::array<q::Tensor,2> inputs;
    q::c::LeasePool outputs;
    if(facts.caller_owned())outputs=q::take(q::c::LeasePool::create(q::take(backend.resource_for(facts.storage)),8192,
        {.max_blocks=2,.backing_alignment=256}));
    std::array<q::g::Invocation,2> runs;
    for(std::size_t i=0;i<runs.size();++i) {
      input_values[i]=ref::input(data.sa,static_cast<unsigned>(i));
      inputs[i]=q::Tensor(backend.device(),q::dense(q::Type::kBFloat16,{2,5120}));
      inputs[i].write<std::uint16_t>(input_values[i]);inputs[i].freeze(backend);
      runs[i]=q::take(compiled.executable.create_invocation());q::check(runs[i].prepare_resources());
      q::check(runs[i].bind(x,inputs[i].description,inputs[i].ready));
      if(facts.caller_owned())q::check(runs[i].bind(y,facts.description,q::take(outputs.allocate(4096))));
      q::check(runs[i].prepare_replay(bindings,{.mode=q::g::ReplayMode::kCommands,.host_wait=q::g::HostWaitPolicy::kAllow}));
    }
    require(input_values[0]!=input_values[1],"two original-weight invocations need genuinely changed inputs");
    std::ofstream numeric(output/"numeric.tsv");numeric<<"m\tn\tactual\tlow\thigh\tcode_dot_F64\tF32_bound\tsumabs\n";
    require(bool(numeric),"cannot write original static FP8 interval report");
    for(std::size_t i=0;i<runs.size();++i) {
      auto done=q::take(runs[i].submit(bindings));q::check(done.wait());
      escaped[i]=q::take(hyle::inference::retain_output(runs[i],facts));observations[i]=read(backend,escaped[i]);
      check_output(observations[i],input_values[i],data,numeric);
      if(i)require(read(backend,escaped[0])==observations[0],"second input changed the retained first output");
      save(output/("input"+std::to_string(i)+".bf16"),std::as_bytes(std::span(input_values[i])));
      save(output/("output"+std::to_string(i)+".bf16"),observations[i]);
    }
    numeric.flush();require(bool(numeric),"original static FP8 interval write failed");
    runs={};
  }
  for(std::size_t i=0;i<escaped.size();++i)
    require(read(backend,escaped[i])==observations[i],"output lost original owner after Graph/Invocation/bank destruction");
  require(hyle::inference::artifact::sha256(read(backend,escaped_weight))==hyle::inference::artifact::sha256(data.weights()),
      "original E4 code lease changed after both invocations");
  std::ofstream summary(output/"summary.json");
  summary<<"{\"status\":\"PASS_ORIGINAL_STATIC_FP8_COMPONENT\",\"backend\":"<<std::quoted(std::string(argv[3]))
      <<",\"repository\":"<<std::quoted(std::string(source::repository))<<",\"revision\":"<<std::quoted(std::string(source::revision))
      <<",\"source_file\":"<<std::quoted(std::string(source::file))<<",\"header_sha256\":"<<std::quoted(std::string(source::header_sha))
      <<",\"weight_sha256\":"<<std::quoted(std::string(source::weight_sha))<<",\"scales_sha256\":"<<std::quoted(std::string(source::scales_sha))
      <<",\"scale_f32_bits\":["<<std::bit_cast<std::uint32_t>(data.sa)<<','<<std::bit_cast<std::uint32_t>(data.sw)<<']'
      <<",\"original_roles\":3,\"original_bytes\":5242888,\"shape\":[1024,5120],\"graph_submissions\":2,\"checked_output_values\":4096"
      <<",\"actual_packed_static_steps\":"<<packed<<",\"actual_steps\":"<<steps<<",\"workspace_bytes\":"<<workspace
      <<",\"old_output_retained\":true,\"old_weight_retained\":true,\"permanent_f32_weight_bank\":false,\"full_model\":false}\n";
  summary.flush();require(bool(summary),"original static FP8 summary write failed");
  std::cout<<"original static FP8 component PASS; actual packed steps="<<packed<<" total steps="<<steps<<'\n';return 0;
}catch(const std::exception &error){std::cerr<<"original static FP8 component: "<<error.what()<<'\n';return 1;}}
