#pragma once

#include "../../../engine/inference/artifact_digest.h"
#include "hyle/mem/mapping.h"

namespace qwen_static_fp8_original_input {
namespace q=qwen35;
inline constexpr std::string_view repository="nvidia/Qwen3.8-27B-NVFP4";
inline constexpr std::string_view revision="482ca0f3832238542f8f5295dde86b5f22711d80";
inline constexpr std::string_view file="model-00001-of-00003.safetensors";
inline constexpr std::string_view header_sha="60f09f862dd9fc8c2594641081613cc3f12f162419cfa06f2e6ee3feac7bc5f5";
inline constexpr std::string_view scales_sha="94e6ff660f8d0e393da329462f60936323ae5e7e320dc312c277c47be1600723";
inline constexpr std::string_view weight_sha="98ec9cec46ee5dfe71a75f899bc89457430ee2af342ef18d6be0bc03cf86ed67";
inline constexpr std::string_view sa_sha="2e412a25091ca0bc493ffc89623938480bf8d21cb426e35eb9dcb5918fc30b4a";
inline constexpr std::string_view sw_sha="0f8452b8b63c44a581a0ece0fc8cf4f7c0b78b038538e318d616ab26aedc8d90";
inline constexpr std::string_view base="model.language_model.layers.11.self_attn.k_proj";
struct Data final {
  q::mem::FileMapping scales,weight;
  float sa=0,sw=0;
  std::span<const std::byte> weights() const {return q::take(weight.bytes());}
  std::span<const std::byte> scale_bytes() const {return q::take(scales.bytes());}
};
inline Data load(const std::filesystem::path &directory) {
  Data result;
  result.scales=q::take(q::mem::FileMapping::open((directory/"scales.f32").string().c_str()));
  result.weight=q::take(q::mem::FileMapping::open((directory/"weight.e4m3").string().c_str()));
  const auto scales=result.scale_bytes(),weight=result.weights();
  if(scales.size()!=8||weight.size()!=5242880||hyle::inference::artifact::sha256(scales)!=scales_sha||
      hyle::inference::artifact::sha256(weight)!=weight_sha||
      hyle::inference::artifact::sha256(scales.first(4))!=sa_sha||
      hyle::inference::artifact::sha256(scales.subspan(4,4))!=sw_sha)
    throw std::runtime_error("original static FP8 exact union size/SHA differs");
  std::memcpy(&result.sa,scales.data(),4);std::memcpy(&result.sw,scales.data()+4,4);
  return result;
}
} // namespace qwen_static_fp8_original_input
