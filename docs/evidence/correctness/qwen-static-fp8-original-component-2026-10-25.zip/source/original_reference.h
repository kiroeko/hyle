#pragma once

// Test-only reuse of the independent E4 decoder/nearest-even encoder and F32
// store helpers. Nothing is injected into the product model's lifecycle.
#include "../../../tests/compute_models/static_fp8_reference_fixture.h"

namespace qwen_static_fp8_original_reference {
namespace f=static_fp8_reference_test;
struct Interval final {float low,high;double center,bound,sumabs;};
inline float lower_float(double x) {
  auto y=static_cast<float>(x);
  if(double(y)>x)y=std::nextafter(y,-std::numeric_limits<float>::infinity());
  return y;
}
inline float upper_float(double x) {
  auto y=static_cast<float>(x);
  if(double(y)<x)y=std::nextafter(y,std::numeric_limits<float>::infinity());
  return y;
}
inline std::pair<float,float> scaled(float low,float high,float scale) {
  const auto a=f::multiply(low,scale),b=f::multiply(high,scale);
  if(!std::isfinite(a)||!std::isfinite(b))
    throw std::runtime_error("original static FP8 interval reached an unqualified overflow/nonfinite scale domain");
  return {std::min(a,b),std::max(a,b)};
}
inline std::vector<std::uint8_t> codes(std::span<const std::uint16_t> input,float sa) {
  if(!std::isfinite(sa)||sa==0||!std::isfinite(f::reciprocal(sa)))
    throw std::runtime_error("original SA is outside this finite dense-dot certificate domain; source unchanged");
  const auto inverse=f::reciprocal(sa);std::vector<std::uint8_t> result(input.size());
  for(std::size_t i=0;i<input.size();++i) {
    const auto value=half_test::decode_bits<f::BF16>(input[i]);
    if(!std::isfinite(value))throw std::runtime_error("original static FP8 test input is nonfinite");
    result[i]=f::encode_e4m3(f::multiply(float(value),inverse));
  }
  return result;
}
inline Interval row(std::span<const std::uint8_t> q,std::span<const std::byte> w,float sa,float sw) {
  if(q.size()!=5120||w.size()!=q.size()||!std::isfinite(sa)||!std::isfinite(sw))
    throw std::runtime_error("original static FP8 dot extent/scales differ");
  double center=0,sumabs=0;
  for(std::size_t k=0;k<q.size();++k) {
    const auto a=f::e4m3(q[k]),b=f::e4m3(std::to_integer<std::uint8_t>(w[k]));
    if(!std::isfinite(a)||!std::isfinite(b))
      throw std::runtime_error("original static FP8 source has a NaN code; finite-dot certificate unavailable");
    const auto product=double(a)*double(b);center+=product;sumabs+=std::abs(product);
  }
  // Every finite E4 value is an integer multiple of2^-9. Products are exact
  // F32 multiples of2^-18. Even5120*448^2*2^18 <2^48, so both ordinary FP64
  // sums above are exact; no sequential-F32 answer is imposed on MatMul.
  constexpr double ku=5120.0*0x1p-24;
  const auto gamma=std::nextafter(ku/(1-ku),std::numeric_limits<double>::infinity());
  const auto bound=sumabs==0?0:std::nextafter(gamma*sumabs,std::numeric_limits<double>::infinity());
  const auto low64=std::nextafter(center-bound,-std::numeric_limits<double>::infinity());
  const auto high64=std::nextafter(center+bound,std::numeric_limits<double>::infinity());
  auto low=bound==0?float(center):lower_float(low64);
  auto high=bound==0?float(center):upper_float(high64);
  const auto first=scaled(low,high,sa);const auto second=scaled(first.first,first.second,sw);
  low=float(f::round(f::Type::kBFloat16,second.first));
  high=float(f::round(f::Type::kBFloat16,second.second));
  if(!std::isfinite(low)||!std::isfinite(high))
    throw std::runtime_error("original static FP8 final BF16 is outside the finite certificate domain");
  return {low,high,center,bound,sumabs};
}
inline std::vector<std::uint16_t> input(float sa,unsigned phase) {
  if(!std::isfinite(sa)||sa==0)throw std::runtime_error("original SA cannot prepare this finite input fixture");
  std::vector<std::uint16_t> result(2*5120);
  for(std::size_t i=0;i<result.size();++i) {
    const auto target=float(int((i*17+phase*11)%31)-15)/4.F;
    const auto value=f::multiply(sa,target);
    if(!std::isfinite(value))throw std::runtime_error("original SA overflowed fixture generation; source unchanged");
    result[i]=half_test::encode<f::BF16>(double(value)).bits;
  }
  return result;
}
} // namespace qwen_static_fp8_original_reference
