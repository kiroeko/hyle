"""Only add the already-used cached formatter leaf; no source recompilation."""
from pathlib import Path
import importlib.util,os,sys,json
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent;T=D/'original-cuda/attempt1'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
assert b.read(T/'compile/process.json')['exit']==0
assert b.read(T/'link/process.json')['exit']==1120
report=R/'.scratch/mtp-performance-convergence-20261025/current-cuda/report/unit.obj'
cpu_inputs=b.read(D/'original-cpu/attempt1/actual-link-inputs.json')
actual=b.pin(report);assert actual==next({k:row[k] for k in ('path','bytes','sha256')} for row in cpu_inputs if row['path']==str(report))
assert b.pin(R/'engine/reporting/execution_report.cc')['sha256']=='069a735b7e1f760d27bf427cddb63aba8850972caaa52790435be428049843ce'
old=b.args(T/'link/command.json')
args=[word for word in old[1:] if not word.lower().startswith(('/out:','/pdb:','/implib:','/map:'))]
assert str(report) not in args
args.append(str(report));env=b.environment(old[0])
L=T/'link2'
b.execute([old[0],*args,'/OUT:'+str(L/'component.exe'),'/IMPLIB:'+str(L/'component.lib'),
           '/PDB:'+str(L/'component.pdb')],L,env,120)
libraries=[Path(word[len('/LIBPATH:'):].strip('"')) for word in args if word.upper().startswith('/LIBPATH:')]
libraries += [Path(word) for word in env.get('LIB','').split(';') if word]
def resolve(word):
    p=Path(word)
    if p.is_file():return p
    for directory in libraries:
        if (directory/p).is_file():return directory/p
    raise RuntimeError('Missing retained input: '+word)
inputs=[dict(argument=word,**b.pin(resolve(word))) for word in args if not word.startswith('/') and word.lower().endswith(('.obj','.lib'))]
assert len(inputs)==233
b.save(T/'actual-link-inputs.json',inputs)
runtime=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json';env['PATH']=b.read(runtime)['PATH']
native=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
os.link(native,L/native.name)
ready={'image':b.pin(L/'component.exe'),'object':b.pin(T/'consumer.obj'),'native':b.pin(native),
    'runtime':b.pin(runtime),'sources':b.read(T/'checked-source-pins.json'),'link_inputs':233,'new_TUs':1,
    'new_SDK_core_provider_TUs':0,'link_only_delta':actual,'first_failure':'link/process.json'}
b.save(T/'ready.json',ready)
complete=D/'original-payload/attempt1/complete.json'
b.save(T/'run-inputs.json',{'original_complete':b.pin(complete),'image':ready['image'],'native':ready['native'],
    'GPU_window':'Root explicit bounded authorization, no idle qualification','source_payload_bytes':5242888,
    'whole_shard_body_verified':False,'no_new_HTTP':True})
b.execute([str(L/'component.exe'),str(complete.parent),str(T/'results'),'cuda'],T/'run',env,120)
result=b.read(T/'results/summary.json');assert result['status']=='PASS_ORIGINAL_STATIC_FP8_COMPONENT'
assert result['graph_submissions']==2 and result['checked_output_values']==4096
print(json.dumps({'status':'PASS','backend':'cuda','results':result,'directory':str(T.relative_to(R))}))
