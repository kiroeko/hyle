"""Select the smallest already-header-authenticated static projection; offline."""
from pathlib import Path
import hashlib
import json
import math

R=Path.cwd()
W=R/'.scratch/inference-qwen-static-fp8-20261025'
audit=json.loads((W/'header-source-audit.json').read_text(encoding='utf-8-sig'))
row=min((x for x in audit['modules'] if x['complete_header']),
        key=lambda x:(math.prod(x['roles'][0]['shape']),x['base']))
assert row['base']=='model.language_model.layers.11.self_attn.k_proj'
header_info=next(x for x in audit['headers'] if x['file']==row['roles'][0]['file'])
p=Path(header_info['path']);raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()==header_info['sha256']
header=json.loads(raw)
receipt=json.loads(p.with_name('header.json.http.json').read_text(encoding='utf-8-sig'))
assert receipt['status']==206
assert receipt['headers']['content-range']==f'bytes 8-{len(raw)+7}/9965652544'
data_base=8+len(raw)
roles=[]
for x in row['roles']:
    r=header[x['name']]
    assert all(r[key]==x[key] for key in ['dtype','shape','data_offsets'])
    a,b=r['data_offsets']
    roles.append(dict(name=x['name'],dtype=x['dtype'],shape=x['shape'],
                      absolute_range=[data_base+a,data_base+b-1],bytes=b-a))
ranges=sorted((r['absolute_range'] for r in roles))
unions=[]
for a,b in ranges:
    if unions and a==unions[-1][1]+1:unions[-1][1]=b
    else:unions.append([a,b])
plan=dict(status='OFFLINE_MINIMAL_RANGE_PLAN_ONLY_NOT_ACQUIRED',
    repository=audit['repository'],revision=audit['revision'],file=row['roles'][0]['file'],
    base=row['base'],logical_shape=row['expected_shape'],header=header_info,
    source_bytes=9965652544,data_base=data_base,original_header_etag=receipt['headers']['etag'],
    roles=roles,unions=unions,total_payload_bytes=sum(r['bytes'] for r in roles),
    acquisition='Wait for the currently active Kimi batch to terminate and restore PAUSED. Then obtain the fixed-source file identity and only these two union ranges using the existing counted mirror-only reader. Do not execute as part of this plan.',
    transport='HTTPS hf-mirror.net initial and every redirect only; no HF/CAS fallback, automatic retry or complete shard.',
    component='One genuine original E4[N=1024,K=5120] projection and independent F32 SA/SW through current cold binding/Recipe, with BF16 input and BF16 output. No complete Q27 or quantized artifact claim.',
    checks='Finite original CPU/CUDA component after acquisition, two changed inputs, original-code independent oracle and old output lease; record actual packed/decomposed route rather than force a favorable route.',
    HTTP_requests=0,payload_acquired=False)
assert plan['total_payload_bytes']==5242888 and len(unions)==2
out=W/'original-component-plan.json'
out.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=plan['status'],base=plan['base'],roles=roles,unions=unions,total_payload_bytes=plan['total_payload_bytes'],HTTP_requests=0),indent=2))
