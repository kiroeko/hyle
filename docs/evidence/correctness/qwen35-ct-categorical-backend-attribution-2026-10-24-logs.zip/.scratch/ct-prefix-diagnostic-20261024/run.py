from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];B=R/'.scratch/qwen35-unsloth-mtp-20261024'
spec=importlib.util.spec_from_file_location('cpu_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
p=argparse.ArgumentParser();p.add_argument('kind',choices=['cpu','cuda']);p.add_argument('observation',choices=['ids','rows']);a=p.parse_args();out=S/a.kind;run=out/(a.observation+'-run');assert not run.exists()
plan=read(B/'original-run-plans/CT.json');case=next(c for c in plan['cases']if c['name']==a.kind+'-k4-random');command=list(case['command']);command[0]=str(out/'hyle-observed.exe')
record=read(R/plan['runtime'][a.kind]['environment']['path']);env=dict(os.environ,PATH=str(out)+';'+record['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HYLE_CT_PREFIX_PROBE=str(run));env.pop('HYLE_CT_PREFIX_ROW_VALUES',None)
if a.observation=='rows':env['HYLE_CT_PREFIX_ROW_VALUES']='1'
save(out/(a.observation+'-inputs.json'),dict(command=command,image=ident(out/'hyle-observed.exe'),original_case=case,observation_mode=a.observation,default_graph_ports_unchanged=True,default_math_sampling_unchanged=True))
b.execute(command,env,run,timeout=600)
report=[json.loads(x)for x in(run/'stdout.log').read_text().splitlines()if x.startswith('{')][-1];baseline=[json.loads(x)for x in(B/'complete-v2/CT'/('retained-'+case['name'])/'stdout.log').read_text().splitlines()if x.startswith('{')][-1]
keys=['source_id','generated_ids','sampling_draw_cursor','actual_target_rows','actual_draft_rows','consumed_drafts','draft_rounds','rounds']
assert all(report[k]==baseline[k]for k in keys),[(k,report[k],baseline[k])for k in keys if report[k]!=baseline[k]]
metadata=read(run/'metadata.json');assert metadata['row2_values_read']==(a.observation=='rows')
save(run/'observation-result.json',dict(native_exit=0,all_compared_default_outputs_identical=True,baseline_fields_compared=keys,metadata=metadata,HTTP=0,SDK_builds=0,throughput_evidence=False));print(json.dumps(metadata))
