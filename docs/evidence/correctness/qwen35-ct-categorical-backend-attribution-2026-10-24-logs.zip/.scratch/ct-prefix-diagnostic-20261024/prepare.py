from pathlib import Path
import hashlib,json,shutil
S=Path(__file__).resolve().parent;R=S.parents[1]
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for kind,folder in [('cpu','qwen-pure-cpu-deployment-20261024'),('cuda','qwen-multi-draft-20261024/geometry-cuda-check2')]:
 base=R/'.scratch'/folder/'source';out=S/kind;out.mkdir(exist_ok=False);source=out/'source';local=source/'engine/models/qwen35';local.mkdir(parents=True)
 records=[]
 for p in (base/'engine/models/qwen35').glob('*.h'):
  dest=local/p.name;shutil.copyfile(p,dest);records.append(ident(dest))
 before=base/'engine/models/qwen35/main.cc';text=before.read_text();original=text
 marker='    check(run.unbind(program.resource_ports));\n    return result;\n    } catch (...) {\n      // Failed p/q validation'
 assert text.count(marker)==1
 text=text.replace(marker,(S/'probe-snippet.inc').read_text()+'\n'+marker)
 text=text.replace('#include <fstream>','#include <fstream>\n#include <cstdlib>')
 (local/'main.cc').write_text(text,encoding='utf8');(source/'probe.cc').write_text('#include "engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv); }\n',encoding='utf8')
 (out/'source-identity.json').write_text(json.dumps(dict(base=ident(before),observed=ident(local/'main.cc'),headers=records,math_graph_sampling_unchanged=True,delta='cstdlib include plus one gated host observation after original sampling wait/result reads, before unbind; optional original row reads only'),indent=2)+'\n')
 (out/'source-delta.diff').write_text(''.join(__import__('difflib').unified_diff(original.splitlines(True),text.splitlines(True),fromfile='original-frozen-main.cc',tofile='observed-frozen-main.cc')))
print('two old-source-consistent private observations prepared; current product untouched')
