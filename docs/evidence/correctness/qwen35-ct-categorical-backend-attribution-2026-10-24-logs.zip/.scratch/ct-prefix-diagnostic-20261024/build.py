from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shlex,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
spec=importlib.util.spec_from_file_location('cpu_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def build(kind):
 out=S/kind;assert not(out/'ready.json').exists();src=out/'source/engine/models/qwen35/main.cc'if kind=='cpu'else out/'source/probe.cc'
 old=read(R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2/compile-command.json');command=[];skip=False
 for x in old:
  if skip:skip=False;continue
  if x=='/sourceDependencies':skip=True;continue
  if x.startswith(('/Fo','/Fd'))or x.endswith('probe.cc'):continue
  if kind=='cpu'and x.startswith(('/DHYLE_COMPUTE_CUDA=','/DHYLE_COMPUTE_GGML_CUDA=')):continue
  command.append(x)
 if kind=='cpu':command+=['/DWIN32','/D_WINDOWS','/DHYLE_COMPUTE_CPU=1']
 command+=['/I'+str(out/'source'),'/sourceDependencies',str(out/'deps.json'),str(src),'/Fo'+str(out/'model.obj')]
 env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 compile_dir=out/'compile' if not(out/'compile').exists() else out/'compile2';b.execute(command,env,compile_dir,timeout=600)
 save(out/'compile-identity.json',dict(source=ident(src),object=ident(out/'model.obj'),includes=[ident(Path(p))for p in read(out/'deps.json')['Data']['Includes']]))
 if kind=='cuda':
  old=read(R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2/link-command.json');command=[x for x in old if not x.upper().startswith(('/OUT:','/IMPLIB:','/PDB:','/MAP:'))and not x.endswith('geometry-cuda-check2\\test.obj')];assert len(command)<len(old);command.insert(1,str(out/'model.obj'));command+=['/OUT:'+str(out/'hyle-observed.exe')]
  dll=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
 else:
  old_build=R/'.scratch/qwen-pure-cpu-deployment-20261024/build';lines=(old_build/'build.ninja').read_text().splitlines();index=next(i for i,x in enumerate(lines)if x.startswith('build bin\\hyle.exe:'))
  line=lines[index];tokens=line.split(' CXX_EXECUTABLE_LINKER__hyle_cpu_Release ',1)[1].split(' | ',1)[0].replace('$:',':').split()
  objects=[];replaced=[]
  for token in tokens:
   p=Path(token);p=p if p.is_absolute()else old_build/p
   if str(p).endswith('engine\\models\\qwen35\\main.cc.obj'):replaced.append(str(p));continue
   assert p.is_file()and p.suffix=='.obj',p
   objects.append(str(p))
  assert len(replaced)==1,replaced;objects.append(str(out/'model.obj'))
  libline=next(x for x in lines[index+1:]if x.startswith('  LINK_LIBRARIES = ')).split(' = ',1)[1]
  libraries=[x.strip('"')for x in shlex.split(libline,posix=False)]
  flags=next(x for x in lines[index+1:]if x.startswith('  LINK_FLAGS = ')).split(' = ',1)[1].split()
  command=[str(Path(command[0]).with_name('link.exe')),'/NOLOGO','/OUT:'+str(out/'hyle-observed.exe'),*objects,*libraries,*flags]
  save(out/'cpu-reuse.json',dict(original_link_rule='CXX_EXECUTABLE_LINKER__hyle_cpu_Release',replaced_only=replaced,reused_objects=len(objects)-1,new_objects=1,objects=objects,libraries=libraries))
  dll=R/'.scratch/qwen-pure-cpu-deployment-20261024/build/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
 save(out/'link-expanded.json',command);rsp=out/'link.rsp';rsp.write_text('\n'.join('"'+x+'"'for x in command[1:])+'\n',encoding='utf8');b.execute([command[0],'@'+str(rsp)],env,out/'link',timeout=600)
 os.link(dll,out/dll.name);save(out/'ready.json',dict(image=ident(out/'hyle-observed.exe'),native_dll=ident(out/dll.name),new_model_TUs=1,SDK_builds=0,current_product_unchanged=True))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('kind',choices=['cpu','cuda']);build(p.parse_args().kind)
