from pathlib import Path
import hashlib,json,zipfile,datetime
S=Path(__file__).resolve().parent;R=S.parents[1];E=R/'docs/evidence/correctness';B=R/'.scratch/qwen35-unsloth-mtp-20261024'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
analysis=read(S/'analysis.json');observations={};comparisons=[]
for backend in ['cpu','cuda']:
 baseline=[json.loads(x)for x in(B/'complete-v2/CT'/('retained-'+backend+'-k4-random')/'stdout.log').read_text().splitlines()if x.startswith('{')][-1]
 observations[backend]={}
 for stage in ['ids','rows']:
  p=S/backend/(stage+'-run');process=read(p/'process.json');native=[json.loads(x)for x in(p/'stdout.log').read_text().splitlines()if x.startswith('{')][-1]
  assert process['exit']==0 and not process['timed_out']
  keys=['source_id','generated_ids','sampling_draw_cursor','actual_target_rows','actual_draft_rows','consumed_drafts','draft_rounds','actual_graph_calls','draft_program_graph_calls','prefix_decision_graph_calls','prefill_graph_calls','decode_graph_calls','rounds']
  assert all(native[k]==baseline[k]for k in keys)
  observations[backend][stage]=dict(process=ident(p/'process.json'),command=ident(p/'command.json'),metadata=read(p/'metadata.json'),all_default_report_fields_identical=True,compared_fields=keys)
  comparisons.append(dict(backend=backend,stage=stage,native_exit=0,default_graph_call_counts=[native['actual_graph_calls'],native['draft_program_graph_calls'],native['prefix_decision_graph_calls']]))
name='qwen35-ct-categorical-backend-attribution-2026-10-24'
result=dict(schema='hyle.ct.backend-categorical-attribution.v1',updated=datetime.datetime.now().isoformat(timespec='seconds'),default_functional_evidence=ident(E/'qwen35-original-ct-mtp-2026-10-24.json'),conclusion=analysis['finite_conclusion'],qualification='A finite causal explanation of this stochastic sequence difference, not a full CT numerical/task qualification.',actual_cross_matrix={k:{alg:v['selected']for alg,v in row.items()}for k,row in analysis['cross_algorithm_by_actual_q'].items()},key_facts=dict(first_changed_draft_index_zero_based=2,CPU_proposal=1445,CUDA_proposal=464,proposal_key=[123,0,5,0],accept_key=[123,0,6,0],same_all_proposal_accept_and_final_addresses=True,default_prefix_accepted_drafts={'CPU':2,'CUDA':3},q_probability_L1=analysis['q_comparison']['probability_L1']),observations=observations,analysis=analysis,build_delta=dict(new_model_TUs=2,new_SDK_TUs=0,product_files_changed=0,default_Graph_ports_or_operations_changed=0,private_observation='After original sampling wait and original scalar result reads, before unbind: record host proposals/identities/accepted/final IDs. Optional row mode copies original target-logits row2 and retained q[2] into two binary diagnostic files; no graph math or sampler execution is inserted.',private_compile_warning='First CPU observer TU failed only MSVC C4996/WX for getenv. Changed the private logger to safe CRT _dupenv_s; original failure retained, same two final model TUs compiled and linked.',sources={k:read(S/k/'source-identity.json')for k in ['cpu','cuda']}),primary_contracts=[dict(path='include/hyle/compute/sampling_ops.h',lines=[45,49],fact='Different qualified CPU/GPU draw algorithms and selected IDs are explicitly permitted; only RandomBits has cross-backend bit equality.'),dict(path='src/compute_provider_native/sampling.cc',lines=[155,174],fact='One52-bit midpoint uniform followed by ascending-token cumulative probability.'),dict(path='src/compute_provider_cuda/sampling_kernel.cu',lines=[88,93],fact='One independent addressed Gumbel per token followed by max and stable-index tie break.')],limits=analysis['limitations']+['The observed CPU/CUDA q2 probabilities differ by L1~0.02423; this proof records but does not fully classify every source of that distribution difference. Both actual q rows independently give the same per-algorithm winners, so that difference is unnecessary to explain this native token split.','This proof keeps original default outputs distinct from privately instrumented observations, which reproduce the default IDs, RNG cursor, state row counts, rounds and graph-call counts exactly.','No new HTTP, SDK rebuild, publisher/model/task matrix, seed adjustment or TPS measurement.'])
archive=E/(name+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in S.rglob('*'):
  if not p.is_file():continue
  if p.suffix not in ['.py','.inc','.json','.diff','.log','.f32','.rsp','.h','.cc']:continue
  z.write(p,p.relative_to(R).as_posix())
 for rel in ['include/hyle/compute/sampling_ops.h','src/compute_provider_native/sampling.cc','src/compute_provider_cuda/sampling_kernel.cu','src/compute_provider_cuda/sampling_math.cuh','tests/compute_models/sampling_fixture.h','tests/compute_ops/sampling_test.cc']:
  z.write(R/rel,'math-reference/'+rel)
result['archive']=ident(archive);p=E/(name+'.json');p.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8');print(ident(p));print(ident(archive));print(comparisons)
