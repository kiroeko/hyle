from pathlib import Path
from array import array
import hashlib,heapq,json,math,sys
S=Path(__file__).resolve().parent;R=S.parents[1];MASK=(1<<32)-1
# Independent scalar reference from sampling_fixture.h / Random123 KAT equations.
def philox(counter,key):
 c=list(counter);k=list(key)
 for _ in range(10):
  a=c[0]*0xd2511f53;b=c[2]*0xcd9e8d57
  c=[((b>>32)^c[1]^k[0])&MASK,b&MASK,((a>>32)^c[3]^k[1])&MASK,a&MASK]
  k=[(k[0]+0x9e3779b9)&MASK,(k[1]+0xbb67ae85)&MASK]
 return c
for c,k,expected in [([0]*4,[0]*2,[0x6627e8d5,0xe169c58d,0xbc57ac4c,0x9b00dbd8]),([MASK]*4,[MASK]*2,[0x408f276d,0x41c83b0e,0xa20bc7c6,0x6d5451fd]),([0x243f6a88,0x85a308d3,0x13198a2e,0x03707344],[0xa4093822,0x299f31d0],[0xd16cfe09,0x94fdcceb,0x5001e420,0x24126ea1])]:assert philox(c,k)==expected

def block(identity,index):return philox([index&MASK,index>>32,identity[2],identity[3]],identity[:2])
def uniform(identity):
 b=block(identity,0);return (b[0]*(2.**20)+(b[1]>>12)+.5)*(2.**-52)
def gumbel(hi,lo):
 upper=bool(hi&0x80000000)
 if upper:hi^=MASK;lo^=MASK
 small=math.ldexp(float(hi),-32)+math.ldexp(float(lo)+.5,-64)
 return -math.log(-math.log1p(-small)if upper else -math.log(small))
def cdf(q,key):
 maximum=max(q.values());weights={i:math.exp(x-maximum)for i,x in q.items()};mass=math.fsum(weights.values());u=uniform(key);threshold=u*mass;prior=0
 for i,w in sorted(weights.items()):
  after=prior+w
  if after>threshold:return dict(selected=i,uniform=u,cdf_lower=prior/mass,cdf_upper=after/mass,boundary_margin=min(u-prior/mass,after/mass-u))
  prior=after
 raise ValueError('no positive cumulative bucket')
def gumbel_draw(q,key):
 scores=[]
 for i,x in q.items():
  b=block(key,i//2);lane=(i%2)*2;noise=gumbel(b[lane],b[lane+1]);scores.append((x+noise,i,noise))
 scores.sort(key=lambda x:(-x[0],x[1]));a,b=scores[:2]
 return dict(selected=a[1],winner_score=a[0],runner_up=b[1],runner_up_score=b[0],score_margin=a[0]-b[0],gumbel=a[2])
def read(p):return json.loads(Path(p).read_text())
def vector(p):
 assert sys.byteorder=='little';a=array('f');a.frombytes(Path(p).read_bytes());assert len(a)==248320;assert all(not math.isnan(x)and x!=math.inf for x in a);return a

def policy(logits):
 assert all(math.isfinite(x)for x in logits)
 top=heapq.nsmallest(8,range(len(logits)),key=lambda i:(-logits[i],i));maximum=logits[top[0]];weights=[math.exp(logits[i]-maximum)for i in top];mass=math.fsum(weights);prior=0;kept=[];priors=[]
 for i,w in zip(top,weights):
  priors.append(prior)
  if not kept or prior<.9:kept.append((i,w))
  prior+=w/mass
 kept_mass=math.fsum(w for i,w in kept)
 return dict(probabilities={i:w/kept_mass for i,w in kept},top8=[dict(id=i,logit=logits[i],prior_cdf=c)for i,c in zip(top,priors)],policy='independent F64 interpretation of T1 -> stable K8 -> P0.9 on observed original F32 logits; not an exported default-graph internal p')

def ident(p):p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
metadata={k:read(S/k/'rows-run/metadata.json')for k in ['cpu','cuda']}
assert metadata['cpu']['proposal_identity_rows']==metadata['cuda']['proposal_identity_rows']
key=metadata['cpu']['proposal_identity_rows'][2];q={};p={};rows={}
for k in ['cpu','cuda']:
 row=vector(S/k/'rows-run/draft-logq-row2.f32');q[k]={i:float(x)for i,x in enumerate(row)if math.isfinite(x)};p[k]=policy(vector(S/k/'rows-run/target-row2.f32'))
 prop=metadata[k]['proposals'][2];rows[k]=dict(native_proposal=prop,native_accept=metadata[k]['accepted'][2],support=[dict(id=i,logq=x,probability=math.exp(x))for i,x in sorted(q[k].items())],sum_exp_logq=math.fsum(math.exp(x)for x in q[k].values()),F64_target_policy=p[k],selected_original_q=ident(S/k/'rows-run/draft-logq-row2.f32'),selected_original_raw_p_logits=ident(S/k/'rows-run/target-row2.f32'))
 pp=p[k]['probabilities'].get(prop,0.);qq=math.exp(q[k][prop]);rows[k]['at_native_proposal']=dict(q=qq,p_F64=pp,alpha_F64=min(1.,pp/qq))
cross={k:dict(cpu_cdf=cdf(q[k],key),cuda_gumbel_max=gumbel_draw(q[k],key))for k in ['cpu','cuda']}
assert cross['cpu']['cpu_cdf']['selected']==metadata['cpu']['proposals'][2]
assert cross['cuda']['cuda_gumbel_max']['selected']==metadata['cuda']['proposals'][2]
all_ids=set(q['cpu'])|set(q['cuda']);common=set(q['cpu'])&set(q['cuda']);l1=math.fsum(abs(math.exp(q['cpu'].get(i,-math.inf))-math.exp(q['cuda'].get(i,-math.inf)))for i in all_ids)
accept_key=metadata['cpu']['accept_identity_rows_and_final'][8:12];b=block(accept_key,0);g0=gumbel(b[0],b[1]);g1=gumbel(b[2],b[3]);effective=1/(1+math.exp(g0-g1))
result=dict(schema='hyle.ct.single-prefix-categorical-attribution.v1',raw_default_graph_unchanged=True,private_observations_only=True,original_random_case='P154 C256 steps6 K4 temperature1 topK8 topP0.9 seed123',proposal_identity=key,metadata=metadata,rows=rows,cross_algorithm_by_actual_q=cross,q_comparison=dict(supports_equal=set(q['cpu'])==set(q['cuda']),common_support=len(common),probability_L1=l1,max_abs_common_logq=max(abs(q['cpu'][i]-q['cuda'][i])for i in common)),accept_key=accept_key,accept_draw=dict(cpu_CDF_uniform=uniform(accept_key),cuda_two_gumbel_effective_uniform=effective),finite_conclusion=dict(native_choices_both_match_their_independent_F64_recipe=True,changing_draw_algorithm_alone_reproduces_both_native_choices_on_each_actual_q=all(x['cpu_cdf']['selected']==1445 and x['cuda_gumbel_max']['selected']==464 for x in cross.values()),claim='This one cross-backend stochastic divergence is consistent with the explicit distinct-Categorical-algorithm contract. It is not evidence of CT miswiring; this does not certify every CT tensor or task.'),limitations=['F64 oracles use original F32 q inputs; CPU SIMD exp and CUDA F32 logs differ from scalar F64, so margins are reported rather than claiming intermediate bit equality.','The target p summary is an F64 reconstruction from an existing exported logits row; it is not a new graph port and is not claimed to equal hidden default-graph F32 p bitwise.','Only the first row2 prefix of one fixed CT random request is inspected. No new publisher, task, seed search or performance matrix was run.'])
(S/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(cross=cross,q_comparison=result['q_comparison'],at_native_proposals={k:rows[k]['at_native_proposal']for k in rows},conclusion=result['finite_conclusion']),indent=2))
