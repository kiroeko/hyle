"""Source-only PDL ordering and real native-contract refinement."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
U=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def norm(raw):return raw.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def once(text,a,b):assert text.count(a)==1,(text.count(a),a[:100]);return text.replace(a,b,1)
def refine():
    manifest_path=R/'third_party/ggml_cuda_runtime/patches.json';m=read(manifest_path)
    entries={e['path']:e for e in m['files']};names=['src/ggml-cuda/gated_delta_net.cu','src/ggml-cuda/gated_delta_net.cuh','src/ggml-cuda/ggml-cuda.cu']
    text={}
    for n in names:
        s=norm((U/n).read_bytes()).decode()
        for e in entries[n]['edits']:s=once(s,e['before'],e['after'])
        assert sha(s.encode())==entries[n]['after_sha256'];text[n]=s
    cu,cuh,_=names;additions={cu:[],cuh:[]}
    def change(n,a,b):text[n]=once(text[n],a,b);additions[n].append(dict(before=a,after=b))
    change(cuh,'bool ggml_cuda_supports_gated_delta_net_indexed(const ggml_tensor * dst);',
      '// The C++ lowering must check this real linked native symbol before using the mode.\nextern "C" int32_t ggml_hyle_cuda_gdn_indexed_state_contract();\nbool ggml_cuda_supports_gated_delta_net_indexed(const ggml_tensor * dst);')
    change(cu,'''extern "C" std::int32_t ggml_hyle_cuda_gdn_output_scale_contract() {
    return hyle::compute::ggml_runtime::kGdnOutputScaleContract;
}
''','''extern "C" std::int32_t ggml_hyle_cuda_gdn_output_scale_contract() {
    return hyle::compute::ggml_runtime::kGdnOutputScaleContract;
}

extern "C" std::int32_t ggml_hyle_cuda_gdn_indexed_state_contract() {
    return ggml_cuda_gdn_indexed_contract;
}
''')
    change(cu,'    const uint32_t sequence = blockIdx.y;\n',
      '    const uint32_t sequence = blockIdx.y;\n    // Index tables are inputs too: observe the original PDL producer before reading them.\n    if constexpr (Indexed) ggml_cuda_pdl_sync();\n')
    change(cu,'    ggml_cuda_pdl_sync();\n#pragma unroll\n',
      '    if constexpr (!Indexed) ggml_cuda_pdl_sync();\n#pragma unroll\n')
    for n,changes in additions.items():entries[n]['edits'].extend(changes);entries[n]['after_sha256']=sha(text[n].encode())
    def math(s):a=s.index('    for (int t = 0; t < n_tokens; t++) {');return s[a:s.index('        attn_data += S_v * H;',a)]
    first=read(W/'native-implementation.json');assert sha(math(text[cu]).encode())==first['arithmetic_body_sha256']
    iq1=read(R/'third_party/ggml_cuda_runtime/iq1-patches.json');combined={}
    for n,s in text.items():
        for e in next((x['edits'] for x in iq1['files'] if x['path']==n),[]):s=once(s,e['before'],e['after'])
        combined[n]=s
    manifest_path.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
    notice=R/'third_party/ggml_cuda_runtime/NOTICE.md'
    notice.write_text(notice.read_text(encoding='utf-8').rstrip()+'''

The indexed C++ lowering must also check the real linked native
ggml_hyle_cuda_gdn_indexed_state_contract symbol, not infer kernel support from
a header or a provider name. Indexed ID reads observe the original CUDA PDL
producer before touching tables; the legacy synchronization position remains.
''',encoding='utf-8')
    lock_path=R/'cmake/HyleDependencyLock.json';lock=read(lock_path)
    entry=next(x for x in lock['dependencies'] if x['name']=='ggml_cuda_runtime_patches');assert entry['version'].endswith('-v37')
    port=R/entry['vendored']['path']
    tree=''.join(p.relative_to(port).as_posix()+'|'+sha(norm(p.read_bytes()))+'\n' for p in sorted(port.rglob('*'),key=lambda p:p.relative_to(port).as_posix()) if p.is_file())
    entry['vendored']['tree_sha256']=sha(tree.encode())
    next(x for x in entry['license']['files'] if x['path']=='third_party/ggml_cuda_runtime/NOTICE.md')['sha256']=sha(norm(notice.read_bytes()))
    lock_path.write_text(json.dumps(lock,indent=2)+'\n',encoding='utf-8')
    overlay=[]
    for n,s in combined.items():
        p=W/'native-overlay'/n;p.write_text(s,encoding='utf-8');overlay.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
    receipt=dict(status='SOURCE_READY_FOR_REVIEW_NOT_COMPILED',canonical=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in [manifest_path,notice,lock_path]],
      native_sources=overlay,arithmetic_body_sha256=first['arithmetic_body_sha256'],arithmetic_body_identical=True,
      mode_slot=4,mode_marker='0x47444931',native_contract='extern "C" int32_t ggml_hyle_cuda_gdn_indexed_state_contract()',
      support='bool ggml_cuda_supports_gated_delta_net_indexed(const ggml_tensor*)',entry='void ggml_cuda_op_gated_delta_net_indexed(ggml_backend_cuda_context&,ggml_tensor*)',
      pool='src5 F32 ggml [S,S,H,P], real nb3 in bytes',source_ids='src6 I32 [B,1,1,1]',destination_ids='src7 I32 [K,B,1,1], memory dst[b*K+c]',
      activation='dst F32 [S,H,T,B], actual V shape; no state tail',snapshot='1<=K<=T; K1 final; K>1 last K boundaries c=t-(T-K)',
      proof_precondition='Admitted immutable actual lease->I32 encoding: all IDs in [0,P), destinations pairwise distinct and disjoint from all sources; selected pool writes are Graph effects. Native metadata qualification/defensive guards do not validate arbitrary user ID contents.',
      frozen_legacy='GGML enums/tensor/backend layouts, old entries, old fused-cache struct, op_params0..3 and original F32 update/reduction/scale expression order unchanged.',
      dispatcher='New mode has explicit native supports/device-bound execution and is excluded from both old dense-state-output and cache-copy fusion.',
      lock_version=entry['version'],vendored_tree_sha256=entry['vendored']['tree_sha256'],builds=0,SDK_or_active_cache_changes=0,downloads=0)
    out=W/'native-interface.json';out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(path=str(out),sha256=sha(out.read_bytes()),canonical=receipt['canonical'])))
if __name__=='__main__':
    if sys.argv[1:]==['refine']:refine()
    else:print(__doc__)
