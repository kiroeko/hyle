"""Preserve run1 and exclude indexed mode from the whole old fusion preflight."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
U=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def norm(raw):return raw.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def once(s,a,b):assert s.count(a)==1,(s.count(a),a[:90]);return s.replace(a,b,1)
def fix():
    assert not (W/'native-freeze2.json').exists()
    path=R/'third_party/ggml_cuda_runtime/patches.json';manifest=read(path);name='src/ggml-cuda/ggml-cuda.cu'
    entry=next(x for x in manifest['files'] if x['path']==name)
    previous=W/'native-overlay'/name;old_source=previous.read_bytes();(W/'dispatcher-attempt1.cu').write_bytes(old_source)
    before=read(W/'native-interface.json')
    assert sha(old_source)==next(x['sha256'] for x in before['native_sources'] if x['path']==str(previous))
    old='''    if (node->op == GGML_OP_GATED_DELTA_NET) {
        ggml_cuda_gdn_state_output_match direct_state;'''
    new='''    if (node->op == GGML_OP_GATED_DELTA_NET && !ggml_cuda_gdn_is_indexed(node)) {
        ggml_cuda_gdn_state_output_match direct_state;'''
    source=norm((U/name).read_bytes()).decode()
    for e in entry['edits']:source=once(source,e['before'],e['after'])
    source=once(source,old,new);entry['edits'].append(dict(before=old,after=new));entry['after_sha256']=sha(source.encode())
    iq1=read(R/'third_party/ggml_cuda_runtime/iq1-patches.json')
    for e in next(x['edits'] for x in iq1['files'] if x['path']==name):source=once(source,e['before'],e['after'])
    assert source==once(norm(old_source).decode(),old,new)
    path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');previous.write_text(source,encoding='utf-8')
    lock_path=R/'cmake/HyleDependencyLock.json';lock=read(lock_path);locked=next(x for x in lock['dependencies'] if x['name']=='ggml_cuda_runtime_patches')
    port=R/locked['vendored']['path'];tree=''.join(p.relative_to(port).as_posix()+'|'+sha(norm(p.read_bytes()))+'\n' for p in sorted(port.rglob('*'),key=lambda p:p.relative_to(port).as_posix()) if p.is_file())
    locked['vendored']['tree_sha256']=sha(tree.encode());lock_path.write_text(json.dumps(lock,indent=2)+'\n',encoding='utf-8')
    frozen=read(W/'native-freeze.json');contract=frozen['private_contract']
    for row in contract['canonical']:
        p=R/row['path'];row.update(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
    for row in contract['native_sources']:
        p=Path(row['path']);row.update(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
    contract['vendored_tree_sha256']=locked['vendored']['tree_sha256'];contract['dispatcher']='Indexed mode skips the whole old GDN fusion preflight, including its legacy typed-bound check; regular indexed execution performs its own bound qualification.'
    frozen['correction']=dict(prior_run='run1',prior_process=read(W/'run1/process.json'),prior_dispatcher_source=dict(path=str(W/'dispatcher-attempt1.cu'),sha256=sha(old_source)),
      reason='BF16 indexed mode reached a legacy typed_bound check inside the old fusion preflight, before regular indexed dispatch. Skip the whole old fusion block for the new mode. GDN/test objects and all arithmetic unchanged.')
    (W/'native-freeze2.json').write_text(json.dumps(frozen,indent=2)+'\n')
    plan=read(W/'build-plan.json');plan['native_freeze']=dict(path=str(W/'native-freeze2.json'),bytes=(W/'native-freeze2.json').stat().st_size,sha256=sha((W/'native-freeze2.json').read_bytes()))
    d=next(x for x in plan['native'] if x['name']=='dispatcher');d['source'].update(bytes=previous.stat().st_size,sha256=sha(previous.read_bytes()))
    d['command']=[a.replace(str(W/'compile/dispatcher'),str(W/'compile2/dispatcher')) for a in d['command']]
    plan['status']='DISPATCHER_ONLY_RETRY';plan['previous_plan']=str(W/'build-plan.json');plan['correction']=frozen['correction']
    (W/'build-plan2.json').write_text(json.dumps(plan,indent=2)+'\n')
    print(json.dumps(dict(plan_sha256=sha((W/'build-plan2.json').read_bytes()),canonical=contract['canonical'],dispatcher_sha256=sha(previous.read_bytes()))))
if __name__=='__main__':
    if sys.argv[1:]==['fix']:fix()
    else:print(__doc__)
