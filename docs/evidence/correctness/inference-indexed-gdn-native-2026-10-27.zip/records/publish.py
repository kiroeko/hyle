"""Publish the completed private native experiment; never build or run it."""
from pathlib import Path
import hashlib,json,sys,zipfile

W=Path(__file__).resolve().parent
R=W.parents[1]
OUT=R/'docs/evidence/correctness/inference-indexed-gdn-native-2026-10-27'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def publish():
    final=read(W/'native-final.json');members={}
    def add(p,name=None,expected=None):
        p=Path(p);data=p.read_bytes()
        if expected:assert sha(data)==expected,(str(p),'source identity changed')
        if name is None:name='records/'+p.relative_to(W).as_posix()
        assert name not in members,name
        members[name]=data
    for row in final['canonical']:
        p=Path(row['path'])
        if not p.is_absolute():p=R/p
        add(p,'source/'+p.relative_to(R).as_posix(),row['sha256'])
    frozen=read(W/'native-freeze2.json')
    for row in frozen['private_contract']['native_sources']:
        add(row['path'],'native/'+Path(row['path']).name,row['sha256'])
    add(W/'dispatcher-attempt1.cu','native/dispatcher-attempt1.cu',final['prior_dispatcher_source']['sha256'])
    # Only essential actual native contract headers; system/SDK headers stay hash receipts.
    wanted=['src/ggml-cuda/common.cuh','include/ggml.h','src/ggml-impl.h',
            'include/gguf.h','include/ggml-cuda.h','include/ggml-backend.h',
            'include/ggml-alloc.h','src/ggml-common.h','src/ggml-cuda/vendors/cuda.h',
            'src/ggml-cuda/convert.cuh','src/compute_provider_ggml_cuda/native_bridge.h',
            'src/compute_provider_ggml_cuda/native_bridge_impl.h',
            'src/compute_ggml_runtime/gated_delta_scale.h']
    deps=[]
    for tag in ['compile/gdn','compile2/dispatcher','compile/test']:
        deps+=read(W/tag/'actual-dependencies.json')
    for suffix in wanted:
        rows=[x for x in deps if x['path'].replace('\\','/').lower().endswith('/'+suffix.lower())]
        assert rows,suffix
        assert len({x['sha256'] for x in rows})==1,suffix
        add(rows[0]['path'],'native-headers/'+suffix,rows[0]['sha256'])
    for name in ['publish.py','build.py','prepare.py','implement.py','refine.py','fix_dispatch.py',
                 'preparation.json','native-implementation.json','native-freeze.json','native-freeze2.json',
                 'test-source-freeze.json','build-plan.json','build-plan2.json','native-final.json',
                 'link-inputs.json','link2-inputs.json','runtime.json','runtime2.json',
                 'ready.json','ready2.json','summary2.json','results.xml','results2.xml']:
        add(W/name)
    for tag in ['compile/gdn','compile/dispatcher','compile/test','compile2/dispatcher']:
        for name in ['command.json','process.json','stdout.log','stderr.log','actual-dependencies.json']:
            add(W/tag/name)
    for tag in ['link','link2','run1','run2']:
        for name in ['command.json','process.json','stdout.log','stderr.log']:add(W/tag/name)
    manifest=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())]
    OUT.parent.mkdir(parents=True,exist_ok=True)
    zpath=OUT.with_suffix('.zip')
    assert not zpath.exists() and not OUT.with_suffix('.json').exists()
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(members.items()):z.writestr(name,data)
    with zipfile.ZipFile(zpath) as z:
        assert z.namelist()==[x['path'] for x in manifest]
        for x in manifest:
            data=z.read(x['path']);assert len(data)==x['bytes'] and sha(data)==x['sha256']
    assert zpath.stat().st_size<2_000_000
    summary=dict(
      status='PRIVATE_NATIVE_INDEXED_GDN_3_PASS',batch_date='2026-10-27',
      scope='Direct private GGML CUDA native numerical/address contract; not public provider, Graph or engine integration.',
      hardware='NVIDIA GeForce RTX 4070; hardware and toolchain raw output retained',
      final=final,
      attempts=[dict(run='run1',pid=15136,exit=1,passed=2,failed=1,
                     reason='BF16 indexed state entered old dense typed-bound fusion preflight.'),
                dict(run='run2',pid=62180,exit=0,passed=3,failed=0,
                     correction='Exclude indexed mode from entire old fusion preflight; only dispatcher recompiled.')],
      coverage=['K1 final state; B2 noncontiguous source/destination slots and padded pool stride',
                'T4>K2 last-K chronological snapshots',
                'BF16 V/beta compared with rounded original dense F32 path',
                'Activation/state bits, full pool including source/unused slots/padding, immutable inputs'],
      exclusions=['No public Compute/provider/Graph effect/engine connection claim',
                  'No arbitrary device ID validation claim: caller must prove admitted immutable lease-to-I32 IDs',
                  'No performance, model-quality or broad shape/platform claim',
                  'No current uncompiled Compute program/tensor/provider source included',
                  'No SDK rebuild, downloads or model inference runs'],
      archive=dict(path=zpath.relative_to(R).as_posix(),bytes=zpath.stat().st_size,
                   sha256=sha(zpath.read_bytes()),members=len(manifest)),
      members=manifest)
    OUT.with_suffix('.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    for p in [OUT.with_suffix('.json'),zpath]:print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))))
if __name__=='__main__':
    if sys.argv[1:]!=['publish']:raise SystemExit('Explicit action required: publish')
    publish()
