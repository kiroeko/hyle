"""Explicit two native CUDA leaves + one direct private regression TU, no SDK build."""
from pathlib import Path
import importlib.util,json,os,shlex,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/inference-cuda-slot-gather-20261026'
spec=importlib.util.spec_from_file_location('cached_gather',B/'build.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);m,b=g.m,g.b
TEST=R/'tests/compute_provider_ggml_cuda/indexed_gdn_test.cc'
def plan():
    assert not (W/'build-plan.json').exists()
    frozen=b.read(W/'native-freeze.json')
    for row in frozen['private_contract']['canonical']:b.exact(dict(row,path=str(R/row['path'])))
    for row in frozen['private_contract']['native_sources']:b.exact(row)
    ready=b.read(B/'ready2.json');inputs=b.read(ready['inputs']['path'])
    assert len(inputs)==221
    for row in inputs:b.exact(row)
    native=[]
    for unit in frozen['compile_templates']:
        command=unit['command'];source=Path(command[command.index('-c')+1]);out=Path(command[command.index('-o')+1]).parent
        assert out==W/'compile'/unit['tag']
        assert sum(b.key(x['path'])==b.key(unit['replaces']['path']) for x in inputs)==1
        native.append(dict(name=unit['tag'],source=b.pin(source),command=command,replaces=unit['replaces']))
    recipe=B/'compile2/test/command.json';test=dict(name='test',source=b.pin(TEST),recipe=b.pin(recipe),command=m.command(recipe,TEST,W/'compile/test'))
    own=m.c.closure([TEST],[recipe]);b.save(W/'test-source-freeze.json',own)
    b.save(W/'build-plan.json',dict(status='FROZEN_NOT_BUILT',native_freeze=b.pin(W/'native-freeze.json'),native=native,test=test,
      test_freeze=b.pin(W/'test-source-freeze.json'),test_CMake=b.pin(R/'tests/compute_provider_ggml_cuda/CMakeLists.txt'),
      baseline=dict(command=b.pin(B/'link2/command.json'),inputs=ready['inputs'],runtime=ready['runtime'],test=ready['compiled'][1]['object']),
      native_TUs=2,CXX_test_TUs=1,images=1,SDK_builds=0,model_runs=0,
      scope='Three direct private GGML CUDA indexed-state numerical/address tests; no claim that public Compute/Graph/provider model wiring is complete.'))
    print('BUILD_PLAN',json.dumps(b.pin(W/'build-plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['test']['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def check(p):
    f=b.read(p['native_freeze']['path'])
    for x in f['private_contract']['canonical']:b.exact(dict(x,path=str(R/x['path'])))
    for x in f['private_contract']['native_sources']:b.exact(x)
    for x in b.read(p['test_freeze']['path']):b.exact(x)
    b.exact(p['test_CMake'])
def build(second=False):
    p=b.read(W/('build-plan2.json' if second else 'build-plan.json'));assert not (W/('ready2.json' if second else 'ready.json')).exists();check(p)
    if not second:assert not (W/'compile').exists()
    for row in b.read(p['baseline']['inputs']['path']):b.exact(row)
    h,env=environment(p);objects={};results=[]
    for unit in p['native']:
        out=W/('compile2' if second and unit['name']=='dispatcher' else 'compile')/unit['name']
        if second and unit['name']=='gdn':
            result=b.read(out/'process.json');assert result['exit']==0 and b.read(out/'command.json')['command']==unit['command']
            for row in b.read(out/'actual-dependencies.json'):b.exact(row)
            objects[unit['name']]=b.pin(out/'unit.obj');results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],process=result,actual_dependencies=b.pin(out/'actual-dependencies.json'),reused_compile=True));continue
        temp=W/('tmp2' if second else 'tmp')/unit['name'];temp.mkdir(parents=True,exist_ok=False)
        native_env=env.copy();native_env['PATH']=str(Path(unit['command'][0]).parent)+';'+native_env['PATH'];native_env['TEMP']=str(temp);native_env['TMP']=str(temp)
        result=h.execute(unit['command'],native_env,out,timeout=1800)
        dep=out/'unit.d';body=dep.read_text().split(' : ',1)[1].replace('\\\n',' ')
        paths=list(dict.fromkeys(shlex.split(body)));actual=[b.pin(Path(x)) for x in paths];b.save(out/'actual-dependencies.json',actual)
        objects[unit['name']]=b.pin(out/'unit.obj');results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],process=result,actual_dependencies=b.pin(out/'actual-dependencies.json')));check(p)
    unit=p['test'];out=W/'compile/test'
    if second:
        result=b.read(out/'process.json');assert result['exit']==0 and b.read(out/'command.json')['command']==unit['command']
        for row in b.read(out/'actual-dependencies.json'):b.exact(row)
    else:result=h.execute(unit['command'],env,out,timeout=180)
    dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    if not second:b.save(out/'actual-dependencies.json',actual)
    own={b.key(x['path']):x for x in b.read(p['test_freeze']['path'])}
    for row in actual:
        q=Path(row['path'])
        if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):assert own[b.key(q)]['sha256']==row['sha256']
    objects['test']=b.pin(out/'unit.obj');results.append(dict(name='test',source=unit['source'],object=objects['test'],process=result,actual_dependencies=b.pin(out/'actual-dependencies.json')));check(p)
    replace={b.key(x['replaces']['path']):objects[x['name']]['path'] for x in p['native']}
    replace[b.key(p['baseline']['test']['path'])]=objects['test']['path']
    link_folder=W/('link2' if second else 'link');image=link_folder/'indexed-gdn-test.exe';args=[];count=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in replace:arg=replace[b.key(arg)];count+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert count==3
    result=h.execute(args,env,link_folder,timeout=120)
    inputs_path=W/('link2-inputs.json' if second else 'link-inputs.json');runtime_path=W/('runtime2.json' if second else 'runtime.json')
    inputs=[b.pin(replace.get(b.key(x['path']),x['path'])) for x in b.read(p['baseline']['inputs']['path'])];b.save(inputs_path,inputs)
    b.save(runtime_path,b.read(p['baseline']['runtime']['path']))
    ready_path=W/('ready2.json' if second else 'ready.json')
    b.save(ready_path,dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=result,inputs=b.pin(inputs_path),runtime=b.pin(runtime_path),plan=b.pin(W/('build-plan2.json' if second else 'build-plan.json')),SDK_builds=0,model_runs=0))
    print('READY',json.dumps(b.pin(ready_path)),flush=True)
def run(second=False):
    p=b.read(W/('build-plan2.json' if second else 'build-plan.json'));check(p);ready_path=W/('ready2.json' if second else 'ready.json');ready=b.read(ready_path);b.exact(ready['image']);h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH']
    xml=W/('results2.xml' if second else 'results.xml');out=W/('run2' if second else 'run1')
    result=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter=GgmlCudaIndexedGdn.*','--gtest_output=xml:'+str(xml)],env,out,timeout=120)
    root=ET.parse(xml).getroot();assert int(root.attrib['tests'])==3 and int(root.attrib['failures'])==0
    assert all(x.attrib['result']=='completed' and x.find('skipped') is None for x in root.iter('testcase'))
    summary=W/('summary2.json' if second else 'summary.json')
    b.save(summary,dict(status='THREE_DIRECT_NATIVE_INDEXED_GDN_CASES_PASS',process=result,tests=3,failures=0,ready=b.pin(ready_path),results=b.pin(xml),scope=p['scope'],SDK_builds=0,model_runs=0))
    print('SUMMARY',json.dumps(b.pin(summary)),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    elif sys.argv[1:]==['build2']:build(True)
    elif sys.argv[1:]==['run2']:run(True)
    else:print(__doc__)
