"""Implement indexed-state addressing as authenticated edits of the original GDN body.

Explicit source-only action. Does not compile, configure, or change shared cache.
"""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
U=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MANIFEST=R/'third_party/ggml_cuda_runtime/patches.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def norm(raw):return raw.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def once(text,old,new):
    assert text.count(old)==1,(text.count(old),old[:120])
    return text.replace(old,new,1)
def implement():
    assert not (W/'native-implementation.json').exists()
    manifest=read(MANIFEST);entries={x['path']:x for x in manifest['files']}
    names=['src/ggml-cuda/gated_delta_net.cu','src/ggml-cuda/gated_delta_net.cuh','src/ggml-cuda/ggml-cuda.cu']
    originals={}
    for name in names:
        entry=entries[name];raw=norm((U/name).read_bytes());assert sha(raw)==entry['before_sha256']
        text=raw.decode()
        for e in entry['edits']:text=once(text,e['before'],e['after'])
        assert sha(text.encode())==entry['after_sha256'];originals[name]=text
    before={str(p.relative_to(R)):sha(p.read_bytes()) for p in [MANIFEST,R/'third_party/ggml_cuda_runtime/NOTICE.md',R/'cmake/HyleDependencyLock.json']}
    edits={name:[] for name in names}
    def change(name,old,new):
        text=originals[name]
        for e in edits[name]:text=once(text,e['before'],e['after'])
        once(text,old,new);edits[name].append(dict(before=old,after=new))
    cu,cuh,dispatch=names
    declarations=r'''
// Private indexed-state v1 carrier. This does not change ggml op/tensor/backend
// layout or the legacy fused-cache struct. op_params 0/1/2/3 retain K, direct-
// state planning and the output-scale contract; only slot 4 selects this mode.
inline constexpr int ggml_cuda_gdn_indexed_parameter = 4;
inline constexpr int32_t ggml_cuda_gdn_indexed_contract = 0x47444931;
inline bool ggml_cuda_gdn_is_indexed(const ggml_tensor * node) {
    return node && node->op == GGML_OP_GATED_DELTA_NET &&
        ggml_get_op_params_i32(node, ggml_cuda_gdn_indexed_parameter) == ggml_cuda_gdn_indexed_contract;
}

// src[0..4]: original Q/K/V/log-decay/beta and their original types/strides.
// src[5]: one actual F32 pool [S,S,H,P], with its real outer slot stride.
// src[6]: contiguous I32[B] source slots.
// src[7]: contiguous I32[K,B] in ggml order, dst_slots[b*K+c] in memory.
// dst: contiguous F32 activation [S,H,T,B], no packed state tail.
// K=1 writes the final state; K>1 writes the last K post-token boundaries in
// chronological order: c=t-(T-K). K remains in [1,T], as in the public schema.
// Metadata qualification DOES NOT inspect device index values or grant pool
// permissions. The sole caller is an admitted Hyle indexed-state lowering:
// it must encode stable actual lease addresses, prove 0<=IDs<P, unique whole
// destination slots disjoint from every source slot, retain the exact pools/
// tables, and declare the selected pool writes as the original Graph effect.
// Arbitrary mutable I32 tensors are not a checked-index capability. No ordinary
// Compute Gather guard may be skipped on account of this private contract.
bool ggml_cuda_supports_gated_delta_net_indexed(const ggml_tensor * dst);
void ggml_cuda_op_gated_delta_net_indexed(ggml_backend_cuda_context & ctx, ggml_tensor * dst);
'''
    change(cuh,'bool ggml_cuda_supports_gated_delta_net_typed(const ggml_tensor * dst);',
      'bool ggml_cuda_supports_gated_delta_net_typed(const ggml_tensor * dst);\n'+declarations)
    qualification=r'''
bool ggml_cuda_supports_gated_delta_net_indexed(const ggml_tensor * dst) {
    if (!ggml_cuda_gdn_is_indexed(dst) || dst->type != GGML_TYPE_F32) return false;
    const auto * q = dst->src[0], * k = dst->src[1], * v = dst->src[2];
    const auto * g = dst->src[3], * beta = dst->src[4], * pool = dst->src[5];
    const auto * sources = dst->src[6], * destinations = dst->src[7];
    if (!q || !k || !v || !g || !beta || !pool || !sources || !destinations ||
        q->type != GGML_TYPE_F32 || k->type != GGML_TYPE_F32 || g->type != GGML_TYPE_F32 ||
        pool->type != GGML_TYPE_F32 || sources->type != GGML_TYPE_I32 || destinations->type != GGML_TYPE_I32 ||
        (v->type != GGML_TYPE_F32 && v->type != GGML_TYPE_BF16) ||
        (beta->type != GGML_TYPE_F32 && beta->type != GGML_TYPE_BF16)) return false;
    for (int port = 8; port < GGML_MAX_SRC; ++port) if (dst->src[port]) return false;
    const int64_t S = v->ne[0], H = v->ne[1], T = v->ne[2], B = v->ne[3], P = pool->ne[3];
    const int K = ggml_get_op_params_i32(dst, 0);
    if ((S != 16 && S != 32 && S != 64 && S != 128) || H <= 0 || H > INT32_MAX ||
        T <= 0 || T > INT32_MAX || B <= 0 || B > UINT32_MAX || P <= 0 || P > INT32_MAX ||
        K < 1 || K > T || !ggml_are_same_shape(q, k) || !ggml_are_same_stride(q, k) ||
        q->ne[0] != S || q->ne[1] <= 0 || H % q->ne[1] || q->ne[2] != T ||
        q->ne[3] <= 0 || B % q->ne[3] ||
        (g->ne[0] != 1 && g->ne[0] != S) || beta->ne[0] != 1 ||
        g->ne[1] != H || g->ne[2] != T || g->ne[3] != B ||
        beta->ne[1] != H || beta->ne[2] != T || beta->ne[3] != B ||
        pool->ne[0] != S || pool->ne[1] != S || pool->ne[2] != H ||
        sources->ne[0] != B || sources->ne[1] != 1 || sources->ne[2] != 1 || sources->ne[3] != 1 ||
        destinations->ne[0] != K || destinations->ne[1] != B || destinations->ne[2] != 1 || destinations->ne[3] != 1 ||
        !ggml_are_same_shape(dst, v)) return false;
    // Prove every byte/element offset before calling contiguous/byte helpers.
    const ggml_tensor * tensors[] = {q, k, v, g, beta, pool, sources, destinations, dst};
    for (const auto * tensor : tensors) {
        const size_t element = ggml_type_size(tensor->type);
        if (tensor->nb[0] != element) return false;
        size_t bytes = element;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0 ||
                (tensor->ne[axis] > 1 && tensor->nb[axis] % element)) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
    }
    const uint64_t item_bytes = uint64_t(S) * S * H * sizeof(float);
    return pool->nb[1] == uint64_t(S) * sizeof(float) &&
        pool->nb[2] == uint64_t(S) * S * sizeof(float) &&
        pool->nb[3] >= item_bytes && pool->nb[3] % sizeof(float) == 0 &&
        ggml_is_contiguous_rows(q) && ggml_is_contiguous_rows(k) && ggml_is_contiguous_rows(v) &&
        ggml_is_contiguous(g) && ggml_is_contiguous(beta) &&
        ggml_is_contiguous(sources) && ggml_is_contiguous(destinations) && ggml_is_contiguous(dst);
}

// Only addressing facts vary. The original GDN arithmetic below is shared by
// legacy and indexed instantiations; no second recurrent algorithm is added.
struct ggml_cuda_gdn_indexed_state {
    const int32_t * sources = nullptr;
    const int32_t * destinations = nullptr;
    int64_t slot_stride = 0; // F32 elements, actual outer pool stride
    int32_t slots = 0;
};
'''
    change(cu,'template <int S_v, bool KDA, bool keep_rs_t, typename TV, typename TB>\n',
      qualification+'\ntemplate <int S_v, bool KDA, bool keep_rs_t, typename TV, typename TB, bool Indexed = false>\n')
    change(cu,'                                     int           K) {','                                     int           K,\n                                     ggml_cuda_gdn_indexed_state indexed) {')
    change(cu,'''    const int64_t state_in_offset      = sequence * H * S_v * S_v + h_idx * S_v * S_v;
    const int64_t state_out_offset     = (sequence * H + h_idx) * S_v * S_v;
''',r'''    int64_t state_in_offset;
    int64_t state_out_offset;
    if constexpr (Indexed) {
        // These tables are a stable lease-address encoding, not arbitrary user
        // IDs. Defensive range guards do not confer checked-index authority or
        // report a user-visible result for a violated private precondition.
        const int32_t source = indexed.sources[sequence];
        if (source < 0 || source >= indexed.slots) return;
        for (int c = 0; c < K; ++c) {
            const int32_t destination = indexed.destinations[int64_t(sequence) * K + c];
            if (destination < 0 || destination >= indexed.slots) return;
        }
        state_in_offset = int64_t(source) * indexed.slot_stride + int64_t(h_idx) * S_v * S_v;
        state_out_offset = int64_t(h_idx) * S_v * S_v;
        if constexpr (!keep_rs_t) {
            state_out_offset += int64_t(indexed.destinations[sequence]) * indexed.slot_stride;
        }
    } else {
        state_in_offset = sequence * H * S_v * S_v + h_idx * S_v * S_v;
        state_out_offset = (sequence * H + h_idx) * S_v * S_v;
    }
''')
    change(cu,'''            const int target_slot = (int) n_tokens - 1 - t;
            if (target_slot >= 0 && target_slot < K) {
                float * curr_state = state + target_slot * state_slot_stride;
''',r'''            const int target_slot = Indexed ? t - (int(n_tokens) - K) : (int) n_tokens - 1 - t;
            if (target_slot >= 0 && target_slot < K) {
                float * curr_state;
                if constexpr (Indexed) {
                    const int32_t destination = indexed.destinations[int64_t(sequence) * K + target_slot];
                    curr_state = state + int64_t(destination) * indexed.slot_stride;
                } else {
                    curr_state = state + target_slot * state_slot_stride;
                }
''')
    change(cu,'template <bool KDA, bool keep_rs_t, typename TV, typename TB>\n',
      'template <bool KDA, bool keep_rs_t, typename TV, typename TB, bool Indexed = false>\n')
    change(cu,'        float scale, int64_t state_slot_stride, int K, cudaStream_t stream) {',
      '        float scale, int64_t state_slot_stride, int K, cudaStream_t stream,\n        ggml_cuda_gdn_indexed_state indexed = {}) {')
    for size in (16,32,64,128):
        change(cu,f'gated_delta_net_cuda<{size}, KDA, keep_rs_t, TV, TB>',f'gated_delta_net_cuda<{size}, KDA, keep_rs_t, TV, TB, Indexed>')
    # The same four launch sites append the address carrier, no arithmetic flags change.
    for i in range(4):
        # Select the complete occurrence by its switch case rather than a repeated context.
        size=(16,32,64,128)[i]
        old=f'''            ggml_cuda_kernel_launch(gated_delta_net_cuda<{size}, KDA, keep_rs_t, TV, TB, Indexed>, launch_params,
                q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d, H,
                n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1_magic, rq3_magic, scale, state_slot_stride, K);'''
        change(cu,old,old[:-2]+', indexed);')
    change(cu,'template <typename TV, typename TB>\nstatic void ggml_cuda_op_gated_delta_net_impl(',
      'template <typename TV, typename TB, bool Indexed = false>\nstatic void ggml_cuda_op_gated_delta_net_impl(')
    change(cu,'    GGML_ASSERT(ggml_is_contiguous(src_state));',
      '    if constexpr (!Indexed) GGML_ASSERT(ggml_is_contiguous(src_state));')
    change(cu,'''    // recurrent state -> gdn_out tail (after attention scores), or the cache when fusing
    float * state_d           = dst_d + S_v * H * n_tokens * n_seqs;
    int64_t state_slot_stride = S_v * S_v * H * n_seqs;
    if (cache != nullptr) {
        state_d           = cache->data;
        state_slot_stride = cache->slot_stride;
    }
''',r'''    float * state_d;
    int64_t state_slot_stride;
    ggml_cuda_gdn_indexed_state indexed;
    if constexpr (Indexed) {
        // The selected original writes are admitted by the outer Graph effect.
        // The real pool is neither relabelled as B states nor copied/compacted.
        state_d = static_cast<float *>(src_state->data);
        state_slot_stride = 0;
        indexed.sources = static_cast<const int32_t *>(dst->src[6]->data);
        indexed.destinations = static_cast<const int32_t *>(dst->src[7]->data);
        indexed.slot_stride = int64_t(src_state->nb[3] / sizeof(float));
        indexed.slots = int32_t(src_state->ne[3]);
    } else {
        // Original packed tail/cache output and reverse snapshot order.
        state_d = dst_d + S_v * H * n_tokens * n_seqs;
        state_slot_stride = S_v * S_v * H * n_seqs;
        if (cache != nullptr) {
            state_d = cache->data;
            state_slot_stride = cache->slot_stride;
        }
    }
''')
    for a,b in [('true','true'),('true','false'),('false','true'),('false','false')]:
        old=f'''            launch_gated_delta_net<{a}, {b}>(q_d, k_d, v_d, g_d, b_d, s_d, dst_d, state_d,
                S_v, H, n_tokens, n_seqs, sq1, sq2, sq3, sv1, sv2, sv3,
                sg1, sg2, sg3, sb1, sb2, sb3, neqk1, rq3, scale, state_slot_stride, K, stream);'''
        new=old.replace(f'<{a}, {b}>',f'<{a}, {b}, TV, TB, Indexed>').replace('K, stream);','K, stream, indexed);')
        change(cu,old,new)
    change(cu,'static void ggml_cuda_dispatch_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst,',
      'template <bool Indexed = false>\nstatic void ggml_cuda_dispatch_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst,')
    change(cu,'''    if (dst->src[2]->type != GGML_TYPE_F32 || dst->src[4]->type != GGML_TYPE_F32) {
        if (!ggml_cuda_supports_gated_delta_net_typed(dst)) {''',r'''    if constexpr (Indexed) {
        if (cache || !ggml_cuda_supports_gated_delta_net_indexed(dst)) {
            hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid indexed GDN metadata");
        }
    }
    if (dst->src[2]->type != GGML_TYPE_F32 || dst->src[4]->type != GGML_TYPE_F32) {
        if (!(Indexed ? ggml_cuda_supports_gated_delta_net_indexed(dst) : ggml_cuda_supports_gated_delta_net_typed(dst))) {''')
    for a,b in [('nv_bfloat16','nv_bfloat16'),('nv_bfloat16','float'),('float','nv_bfloat16'),('float','float')]:
        change(cu,f'ggml_cuda_op_gated_delta_net_impl<{a}, {b}>(ctx, dst, cache);',
          f'ggml_cuda_op_gated_delta_net_impl<{a}, {b}, Indexed>(ctx, dst, cache);')
    change(cu,'''void ggml_cuda_op_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_dispatch_gated_delta_net(ctx, dst, nullptr);
}''',r'''void ggml_cuda_op_gated_delta_net_indexed(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_dispatch_gated_delta_net<true>(ctx, dst, nullptr);
}

void ggml_cuda_op_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    if (ggml_cuda_gdn_is_indexed(dst)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "indexed GDN requires its private entry");
    }
    ggml_cuda_dispatch_gated_delta_net(ctx, dst, nullptr);
}''')
    change(cu,'''        ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_cuda_gated_delta_net_fused_cache cache) {
    ggml_cuda_dispatch_gated_delta_net(ctx, dst, &cache);''',r'''        ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_cuda_gated_delta_net_fused_cache cache) {
    if (ggml_cuda_gdn_is_indexed(dst)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "indexed GDN cannot use dense fused cache");
    }
    ggml_cuda_dispatch_gated_delta_net(ctx, dst, &cache);''')
    bound=r'''
// Real native buffers and complete original pool/ID/Y extents only. Device ID
// contents are the admitted upper-layer lease encoding, not validated here.
static bool ggml_cuda_gdn_indexed_bound(const ggml_tensor * dst, int device) {
    if (!ggml_cuda_supports_gated_delta_net_indexed(dst) ||
        !GGML_CUDA_CC_IS_NVIDIA(ggml_cuda_info().devices[device].cc) ||
        dst->src[2]->ne[3] > ggml_cuda_mmvq_grid_y[device]) return false;
    const auto bounded = [device](const ggml_tensor * tensor) {
        if (!tensor || !tensor->data || !tensor->buffer || !ggml_backend_buffer_is_cuda(tensor->buffer)) return false;
        const auto * owner = static_cast<const ggml_backend_cuda_buffer_context *>(tensor->buffer->context);
        if (owner->device != device || !owner->dev_ptr) return false;
        const uintptr_t base = reinterpret_cast<uintptr_t>(owner->dev_ptr);
        const uintptr_t begin = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t capacity = ggml_backend_buffer_get_size(tensor->buffer);
        const size_t bytes = ggml_nbytes(tensor); // qualification already proved all products/strides
        return begin % ggml_type_size(tensor->type) == 0 && begin >= base &&
            begin - base <= capacity && bytes <= capacity - (begin - base) && bytes <= UINTPTR_MAX - begin;
    };
    const auto overlap = [](const ggml_tensor * a, const ggml_tensor * b) {
        const uintptr_t x = reinterpret_cast<uintptr_t>(a->data), y = reinterpret_cast<uintptr_t>(b->data);
        return x < y + ggml_nbytes(b) && y < x + ggml_nbytes(a);
    };
    if (!bounded(dst)) return false;
    for (int port = 0; port < 8; ++port) {
        if (!bounded(dst->src[port]) || overlap(dst, dst->src[port])) return false;
    }
    // Only the explicit pool may be mutated; protect all original math and
    // index payloads. Selected source/destination slot disjointness remains the
    // actual LeaseSlotLayout/Graph proof, not a guessed whole-pool alias rule.
    for (int port = 0; port < 8; ++port) {
        if (port != 5 && overlap(dst->src[5], dst->src[port])) return false;
    }
    return true;
}
'''
    anchor='// No CUDA pointer query on the hot path: resource admission already binds\n'
    change(dispatch,anchor,bound+'\n'+anchor)
    change(dispatch,'''        case GGML_OP_GATED_DELTA_NET:
            if (ggml_cuda_gdn_uses_typed_loads(dst) && !ggml_cuda_gdn_typed_bound(dst, ctx.device)) {''',r'''        case GGML_OP_GATED_DELTA_NET:
            if (ggml_cuda_gdn_is_indexed(dst)) {
                if (!ggml_cuda_gdn_indexed_bound(dst, ctx.device)) {
                    hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid bound indexed GDN pool/indices/output");
                }
                ggml_cuda_op_gated_delta_net_indexed(ctx, dst);
                break;
            }
            if (ggml_cuda_gdn_uses_typed_loads(dst) && !ggml_cuda_gdn_typed_bound(dst, ctx.device)) {''')
    change(dispatch,'''    if (gdn->op != GGML_OP_GATED_DELTA_NET || gdn->view_src ||
''','''    if (gdn->op != GGML_OP_GATED_DELTA_NET || ggml_cuda_gdn_is_indexed(gdn) || gdn->view_src ||
''')
    change(dispatch,'''    if (gdn->op != GGML_OP_GATED_DELTA_NET || gdn->type != GGML_TYPE_F32 ||
''','''    if (gdn->op != GGML_OP_GATED_DELTA_NET || ggml_cuda_gdn_is_indexed(gdn) || gdn->type != GGML_TYPE_F32 ||
''')
    change(dispatch,'''#else
            if (ggml_cuda_gdn_uses_typed_loads(op)) {
''',r'''#else
            if (ggml_cuda_gdn_is_indexed(op)) {
                return ggml_cuda_supports_gated_delta_net_indexed(op) &&
                    GGML_CUDA_CC_IS_NVIDIA(ggml_cuda_info().devices[dev_ctx->device].cc) &&
                    op->src[2]->ne[3] <= ggml_cuda_mmvq_grid_y[dev_ctx->device];
            }
            if (ggml_cuda_gdn_uses_typed_loads(op)) {
''')
    results={}
    for name in names:
        text=originals[name]
        for e in edits[name]:text=once(text,e['before'],e['after'])
        entries[name]['edits'].extend(edits[name]);entries[name]['after_sha256']=sha(text.encode());results[name]=text
    # The scalar state-update/reduction/scale body is literally unchanged.
    def arithmetic(text):
        a=text.index('    for (int t = 0; t < n_tokens; t++) {')
        b=text.index('        attn_data += S_v * H;',a)
        return text[a:b]
    assert arithmetic(originals[cu])==arithmetic(results[cu])
    # Only private declaration additions: the complete existing fused struct is retained.
    old_struct=originals[cuh].split('struct ggml_cuda_gated_delta_net_fused_cache {',1)[1].split('};',1)[0]
    assert results[cuh].split('struct ggml_cuda_gated_delta_net_fused_cache {',1)[1].split('};',1)[0]==old_struct
    # Validate canonical CUDA + IQ1 composition in memory before any product write.
    iq1=read(R/'third_party/ggml_cuda_runtime/iq1-patches.json')
    composed={}
    for name,text in results.items():
        for e in next((x['edits'] for x in iq1['files'] if x['path']==name),[]):text=once(text,e['before'],e['after'])
        composed[name]=text
    MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    notice=R/'third_party/ggml_cuda_runtime/NOTICE.md'
    notice.write_text(notice.read_text(encoding='utf-8').rstrip()+r'''

The original GDN kernel also supports an explicit private indexed-state v1
carrier. The real F32 pool keeps its physical slot capacity/outer stride;
separate I32 source and chronological destination tables encode original
admitted lease slots. K=1 writes only the final boundary; K>1 writes the last K
post-token boundaries chronologically. The activation output has V's original
four-dimensional shape and no packed state tail. This reuses the original
register update, F32 reductions, typed V/beta loads and output-scale math.

The mode occupies only private op-parameter slot four. Snapshot count (zero),
cold direct-state qualification (one) and output-scale bits (two/three) retain
their contracts. Existing ggml enum/tensor/backend layouts, legacy GDN entry
signatures and the fused-cache struct are unchanged. Indexed mode has explicit
metadata/device-buffer qualification and execution dispatch, and is excluded
from both old dense-state-output and rollback-cache copy fusion. It neither
compacts the pool nor grants generic permission to mutate an input tensor.

Device index contents are not validated by a metadata predicate. The private
caller must retain immutable actual lease-to-I32 encodings with in-range source
IDs and unique destinations disjoint from every source, and nominate the pool
write as the original Graph effect. Defensive kernel range guards are not an
arbitrary-device-ID validation/status protocol or a generic Gather exemption.
'''.replace('\r\n','\n'),encoding='utf-8')
    lock_path=R/'cmake/HyleDependencyLock.json';lock=read(lock_path)
    entry=next(x for x in lock['dependencies'] if x['name']=='ggml_cuda_runtime_patches')
    assert entry['version']=='hyle-ggml-cuda-resource-iq1-inference-v36'
    entry['version']='hyle-ggml-cuda-resource-iq1-inference-v37'
    port=R/entry['vendored']['path']
    tree=''.join(p.relative_to(port).as_posix()+'|'+sha(norm(p.read_bytes()))+'\n'
      for p in sorted(port.rglob('*'),key=lambda p:p.relative_to(port).as_posix()) if p.is_file())
    entry['vendored']['tree_sha256']=sha(tree.encode())
    next(x for x in entry['license']['files'] if x['path']=='third_party/ggml_cuda_runtime/NOTICE.md')['sha256']=sha(norm(notice.read_bytes()))
    lock_path.write_text(json.dumps(lock,indent=2)+'\n',encoding='utf-8')
    for name,text in composed.items():
        out=W/'native-overlay'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(text,encoding='utf-8')
    receipt=dict(status='SOURCE_IMPLEMENTED_NOT_COMPILED',before=before,
      after={str(p.relative_to(R)):sha(p.read_bytes()) for p in [MANIFEST,notice,lock_path]},
      patch_paths=[dict(path=n,new_edits=len(edits[n]),cuda_after_sha256=entries[n]['after_sha256'],combined_after_sha256=sha(composed[n].encode())) for n in names],
      arithmetic_body_sha256=sha(arithmetic(originals[cu]).encode()),arithmetic_body_identical=True,
      legacy_fused_struct_identical=True,lock_entry=entry,
      contract=dict(mode_slot=4,mode_marker='0x47444931',pool='F32 [S,S,H,P], real nb3',source_ids='I32 [B]',destination_ids='I32 ggml [K,B], memory [B,K]',activation='F32 [S,H,T,B]',snapshot='K1 final; K>1 last K boundaries chronological c=t-(T-K)',proof='Caller owns exact immutable lease encoding; metadata/buffer bounds do not validate arbitrary device IDs'),
      builds=0,SDK_or_active_cache_modifications=0,downloads=0)
    (W/'native-implementation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(receipt=str(W/'native-implementation.json'),sha256=sha((W/'native-implementation.json').read_bytes()),files=receipt['after'])),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['implement']:implement()
    else:print(__doc__)
