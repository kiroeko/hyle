"""Read-only source/cache inspection; writes this small plan, never builds/patches."""
from pathlib import Path
import hashlib,json,shlex,sys
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
U=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
G=R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation'
D=R/'.scratch/architecture-refactor-2026-10-18/gdn-direct-state-output/checks/native1'
L=R/'.scratch/inference-cuda-slot-gather-20261026'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(p):p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=sha(raw))
def normalize(raw):return raw.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def prepare():
    assert not (W/'preparation.json').exists()
    lock=read(R/'cmake/HyleDependencyLock.json');deps={x['name']:x for x in lock['dependencies']}
    manifests=[('base',R/'third_party/ggml_runtime/patches.json'),('cpu',R/'third_party/ggml_cpu_runtime/patches.json'),
      ('cuda',R/'third_party/ggml_cuda_runtime/patches.json'),('iq1',R/'third_party/ggml_cuda_runtime/iq1-patches.json')]
    kernel=next(x for x in read(G/'recipe-preparation/native-commands.json')['jobs'] if x['name']=='cuda-gated-delta')
    dispatcher=read(D/'native-main-identity.json')
    assert pin(kernel['source']['path'])==kernel['source']
    assert pin(dispatcher['source']['path'])==dispatcher['source']
    selected=['src/ggml-cuda/gated_delta_net.cu','src/ggml-cuda/gated_delta_net.cuh',
      'src/ggml-cuda/ggml-cuda.cu','src/ggml-cuda/common.cuh','include/ggml.h']
    composition=[]
    for name in selected:
        original=normalize((U/name).read_bytes());raw=original;used=[]
        for label,p in manifests:
            for entry in read(p)['files']:
                if entry['path']!=name:continue
                for edit in entry['edits']:
                    before=edit['before'].encode();assert raw.count(before)==1,(name,label)
                    raw=raw.replace(before,edit['after'].encode(),1)
                used.append(label)
        composition.append(dict(path=name,upstream_sha256=sha(original),combined_sha256=sha(raw),manifests=used))
    assert composition[0]['combined_sha256']==kernel['source']['sha256']
    assert composition[2]['combined_sha256']==dispatcher['source']['sha256']
    actual_kernel_body=(G/'native1/cuda-gated-delta.d').read_text().split(' : ',1)[1].replace('\\\n',' ')
    kernel_headers=list(dict.fromkeys(Path(x) for x in shlex.split(actual_kernel_body)
      if '/project-hyle/hyle/' in x and x.endswith(('.h','.cuh'))))
    assert all(p.is_file() for p in kernel_headers)
    direct_inputs=read(L/'link-inputs.json');gobj=G/'native1/cuda-gated-delta.obj';dobj=D/'native-main.obj'
    for obj in (gobj,dobj):assert sum(Path(x['path'])==obj for x in direct_inputs)==1
    archives=[x for x in direct_inputs if Path(x['path']).name in ('ggml-cuda.lib','ggml-base.lib','ggml.lib')]
    cuda=deps['ggml_cuda_runtime_patches'];port=R/cuda['vendored']['path']
    tree=''.join(p.relative_to(port).as_posix()+'|'+sha(normalize(p.read_bytes()))+'\n' for p in sorted(port.rglob('*'),key=lambda p:p.relative_to(port).as_posix()) if p.is_file())
    assert sha(tree.encode())==cuda['vendored']['tree_sha256']
    commands=[]
    for tag,old,source,obj in [('gdn',kernel['command'],'src/ggml-cuda/gated_delta_net.cu',gobj),
      ('dispatcher',dispatcher['command'],'src/ggml-cuda/ggml-cuda.cu',dobj)]:
        args=[];removed=[]
        for arg in old:
            if arg.startswith('-I') and not Path(arg[2:]).is_dir():removed.append(arg);continue
            args.append(arg)
        args[1:1]=['-I'+str(W/'native-overlay/src/ggml-cuda'),'-I'+str(W/'native-overlay/src'),'-I'+str(W/'native-overlay/include')]
        old_obj=args[args.index('-o')+1];new_obj=str(W/'compile'/tag/'unit.obj')
        args[args.index('-c')+1]=str(W/'native-overlay'/source)
        args[args.index('-o')+1]=new_obj;args[args.index('-MT')+1]=new_obj
        args[args.index('-MF')+1]=str(W/'compile'/tag/'unit.d')
        args=[a.replace(str(Path(old_obj).with_suffix('.pdb')),str(W/'compile'/tag/'unit.pdb')) for a in args]
        assert '-use_fast_math' in args and '--generate-code=arch=compute_89,code=[sm_89]' in args
        commands.append(dict(tag=tag,status='TEMPLATE_NOT_EXECUTED',command=args,replaces=pin(obj),removed_dead_include_directories=removed))
    data=dict(status='READ_ONLY_PREPARATION_NOT_BUILT',upstream_cache=str(U),upstream_lock=deps['ggml'],
      canonical_inputs=[pin(R/'cmake/HyleDependencyLock.json'),*[pin(p) for _,p in manifests],
        pin(R/'src/compute_ggml_runtime/CMakeLists.txt'),pin(R/'src/compute_ggml_runtime/prepare_source.py'),
        pin(R/'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py')],
      patch_entry=cuda,selected_composition=composition,composition_matches_actual_kernel_and_dispatcher=True,
      actual_kernel=dict(source=kernel['source'],object=pin(gobj),recipe=pin(G/'recipe-preparation/native-commands.json'),dependency_file=pin(G/'native1/cuda-gated-delta.d'),project_headers=[pin(p) for p in kernel_headers]),
      actual_dispatcher=dict(source=dispatcher['source'],object=pin(dobj),recipe=pin(D/'native-main-identity.json'),
        header_contract=[x for x in dispatcher['dependencies'] if Path(x['path']).name in ('ggml.h','common.cuh','gated_delta_net.cuh')]),
      static_archives=archives,link_recipe=pin(L/'link2/command.json'),link_inputs=pin(L/'link-inputs.json'),
      command_templates=commands,
      native_TUs=dict(minimum=1,with_dispatcher_guard=2,conditions='One GDN TU only if indexed mode stays behind existing GGML_OP_GATED_DELTA_NET entry and all support/fusion dispatch paths are proven safe. Compile dispatcher too if qualification or fusion guards require it.'),
      integration_guidance=[
        'Extend existing gated_delta_net.cu/.cuh patch entries; preserve old entry signatures/fused-cache struct, GGML enum and tensor/backend layouts. This avoids rebuilding other cached CUDA units.',
        'Keep GdnIndexedState a Hyle operation/lowering distinction; pass source/destination pool and I32 slot-table facts through an explicit private indexed carrier. Reserve op params only after checking current contracts: snapshot count slot0 and cold direct-state qualifier slot1 are already occupied.',
        'Preserve output-scale contract, current math/typed loads and K-snapshot/MTP accepted-prefix semantics. Indexed mode must not accidentally enter the existing dense-state-copy/fused-cache matcher.',
        'Do not add an upstream GGML enum/ggml_tensor field or widen a public native header layout for this change. New optional declarations/types in the GDN-private header can preserve existing callers.',
        'Before compiling, materialize only changed private source/header files into this new native-overlay using canonical manifest unique-context/before+after SHA semantics; reuse unchanged already-matching cached headers. Never patch active shared source/cache or run full CMake configure for this finite experiment.',
        'The general prepare_source.py materializer copies its input tree; do not invoke it on the entire SDK just for this leaf experiment. Reuse the existing per-stage controlled patch-overlay approach with the same authenticated manifest edits, then record actual dependencies.',
        'The existing CUDA manifest composer currently expects edits entries; keeping indexed helpers in existing GDN files avoids needing a new content-file composition feature.',
        'Replace the exact current direct GDN object (and dispatcher only if rebuilt) in the existing link command; do not leave old+new direct definitions or mutate ggml-cuda.lib. Existing static archive members remain lazily suppressed as in the successful current closure.'
      ],
      future_lock_updates=[
        'third_party/ggml_cuda_runtime/patches.json: retain upstream before_sha256, append exact edits, recompute after_sha256 for changed GDN .cu/.cuh and dispatcher only if changed.',
        'third_party/ggml_cuda_runtime/NOTICE.md: describe the indexed-state extension; update only its license.files[] sha256 in the owning lock entry if NOTICE changes.',
        'cmake/HyleDependencyLock.json dependencies[name=ggml_cuda_runtime_patches]: bump local patch version v36, recompute vendored.tree_sha256 using _hyle_dependency_tree_sha256 (sorted relative|normalized-file-SHA LF manifest). Upstream revision/git_tree/archive SHA and LICENSE stay unchanged.',
        'Generated mixed/CUDA-IQ1 manifests, source identity hash and HYLE_GGML_CUDA_PROVIDER_VERSION are derived by current CMake/helpers; do not hand-edit them. prepare_cuda_iq1_manifest.py or gated_delta_scale.h hashes need changes only if those files actually change.'
      ],
      safety_boundaries=['This preparation performs no compiler/linker/patch/cache writes, downloads or GPU/model run.',
        'Existing actual kernel+dispatcher source and shared header identities are verified against in-memory canonical composition, not guessed from filenames.',
        'Slot index bounds/generation, destination disjointness and projected lease permissions still need implementation/tests; this build plan does not grant them.'],
      builds=0,downloads=0,SDK_copies=0,performance_runs=0)
    (W/'preparation.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(pin(W/'preparation.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['prepare']:prepare()
    else:print(__doc__)
