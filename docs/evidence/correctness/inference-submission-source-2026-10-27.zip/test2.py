from pathlib import Path
import importlib.util,sys,os,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('batch_recipe',W/'build.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
b,h,m=q.b,q.h,q.m

def build():
    assert not (W/'source-freeze2.json').exists()
    before=b.read(W/'ready.json');plan=b.read(W/'plan.json');units=plan['units']
    for row in b.read(W/'source-freeze.json'):
        if Path(row['path']).name!='output_source_cuda_test.cc':b.exact(row)
    pins=[b.pin(q.R/s) for s in q.SOURCES];b.save(W/'source-freeze2.json',pins)
    for s in q.SOURCES:
        target=W/'source2'/s;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((q.R/s).read_bytes())
    for u in before['compiled']:
        b.exact(u['object'])
        if u['name']!='test':
            for row in b.read(u['dependencies']['path']):b.exact(row)
    unit=units[-1];assert unit['name']=='test'
    command=[];out=W/'compile2/test'
    for i,a in enumerate(unit['command']):
        if i and unit['command'][i-1].lower()=='/sourcedependencies':a=str(out/'dependencies.json')
        elif a.lower().startswith('/fo'):a='/Fo'+str(out/'unit.obj')
        elif a.lower().startswith('/fd'):a='/Fd'+str(out/'unit.pdb')
        command.append(a)
    closure=m.c.closure([u['source']['path'] for u in units],[u['template']['path'] for u in units]);b.save(W/'closure2.json',closure);own={b.key(x['path']):x for x in closure}
    environment=q.env(plan);process=h.execute(command,environment,out,timeout=180)
    d=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([d['Source'],*d['Includes']])];b.save(out/'actual-dependencies.json',actual)
    for row in actual:
        if Path(row['path']).is_relative_to(q.R) and not Path(row['path']).is_relative_to(q.R/'.scratch'):assert own[b.key(row['path'])]['sha256']==row['sha256']
    for row in pins:b.exact(row)
    compiled=dict(name='test',source=b.pin(q.R/'tests/graph/output_source_cuda_test.cc'),object=b.pin(out/'unit.obj'),process=process,dependencies=b.pin(out/'actual-dependencies.json'))
    inputs=b.read(W/'link-inputs.json');old_test=before['compiled'][-1]['object'];assert inputs.count(old_test)==1
    inputs=[compiled['object'] if b.key(x['path'])==b.key(old_test['path']) else x for x in inputs];b.save(W/'link-inputs2.json',inputs)
    image=W/'bin2/submission-source-test.exe';image.parent.mkdir(exist_ok=True);command=[]
    for a in b.read(W/'link/command.json')['command']:
        if b.key(a)==b.key(old_test['path']):a=compiled['object']['path']
        elif a.lower().startswith('/out:'):a='/OUT:'+str(image)
        elif a.lower().startswith('/pdb:'):a='/PDB:'+str(image.with_suffix('.pdb'))
        command.append(a)
    linked=h.execute(command,environment,W/'link2',timeout=120)
    runtime=b.read(W/'runtime.json');native=runtime['native_cpu'];b.exact(native);os.link(native['path'],image.parent/Path(native['path']).name);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(W/'runtime2.json',runtime)
    b.save(W/'ready2.json',dict(image=b.pin(image),compiled=before['compiled'][:-1]+[compiled],link=linked,inputs=b.pin(W/'link-inputs2.json'),runtime=b.pin(W/'runtime2.json'),plan=b.pin(W/'plan.json'),source_freeze=b.pin(W/'source-freeze2.json'),first_unrun_image=before['image'],test_refinement='Additional failed-but-actually-retired control detach assertion in an existing case; no product change or failed compile.'))
    print('READY2',flush=True)

def run():
    ready=b.read(W/'ready2.json');b.exact(ready['image'])
    for row in b.read(W/'source-freeze2.json'):b.exact(row)
    environment=q.env(b.read(W/'plan.json'));environment['PATH']=b.read(W/'runtime2.json')['PATH'];xml=W/'results2.xml'
    process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter=GraphOutputSourceCuda.*','--gtest_output=xml:'+str(xml)],environment,W/'run2',timeout=90)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase');assert len(cases)==6 and int(root.attrib['tests'])==6
    assert all(c.attrib.get('status')=='run' and not c.findall('failure') and not c.findall('error') and not c.findall('skipped') for c in cases)
    b.save(W/'summary.json',dict(status='PASS',process=process,tests=[c.attrib for c in cases],image=ready['image'],ready=b.pin(W/'ready2.json'),source_freeze=ready['source_freeze'],scope='Original one-submission proxy/Queue/full-status owner with typed I32 views and atomic bundle; one two-output CUDA consumer has one deduplicated dependency. Existing pending, logical error/actual retirement, explicit detach/reuse, region and capture-reuse cases migrated. No Store/KV pending tickets, managed producer, multi-segment/model/full rotating pipeline, native fault injection or speed claim.'))
    print('PASS 6',flush=True)

if __name__=='__main__':
    try:{'build':build,'run':run}[sys.argv[1]]()
    except Exception:
        b.save(W/(sys.argv[1]+'2-failure.json'),dict(error=traceback.format_exc(),note='Original processes, source snapshots, logs and XML preserved; no automatic retry.'));raise
