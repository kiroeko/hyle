from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def pin(p):
 p=Path(p);v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
ready=read(W/'ready2.json');first=read(W/'ready.json');summary=read(W/'summary.json');sources=read(W/'source-freeze2.json')
for row in sources:assert pin(row['path'])==row
for row in read(W/'link-inputs2.json'):assert pin(row['path'])==row
assert pin(ready['image']['path'])==ready['image']
assert summary['status']=='PASS' and len(summary['tests'])==6
before=read(R/'.scratch/inference-graph-output-capture-20261027/link-inputs.json');after=read(W/'link-inputs2.json')
retained=[x for x in after if x in before];assert len(before)==len(after)==230 and len(retained)==226
files=[W/name for name in ['build.py','test2.py','archive.py','plan.json','closure.json','closure2.json','source-freeze.json','source-freeze2.json','compiled-partial.json','link-inputs.json','link-inputs2.json','runtime.json','runtime2.json','ready.json','ready2.json','summary.json','results2.xml']]
files += [p for folder in ['source','source2'] for p in (W/folder).rglob('*') if p.is_file()]
for folder in ['compile/executable','compile/resources','compile/inputs','compile/test','compile2/test','link','link2','run2']:
 files += [W/folder/name for name in ['command.json','process.json','stdout.log','stderr.log','dependencies.json','actual-dependencies.json'] if (W/folder/name).is_file()]
files=list(dict.fromkeys(files));members=[dict(member=p.relative_to(W).as_posix(),**pin(p)) for p in files]
old=R/'docs/evidence/correctness/inference-graph-output-capture-2026-10-27.json'
receipt=dict(schema='hyle.inference.submission-source.correctness.v1',date='2026-10-27',status='PASS',head_observed_after_validation='8c6005c01ce9b93fc614cf7584d7d5848b808f9b',
 scope='One original nonblocking shared-Queue Graph submission owns its exact proxy, Queue and whole terminal contract once. Independent fixed caller-owned I32 output views compose into one atomic consumer bundle. Six finite CUDA component cases; no pending Store/KV ticket or model pipeline.',
 implementation=dict(api=[
 'detail::SubmissionSource::create(Invocation&, Completion&& exact_proxy, const StorageOwner& metadata_owner)',
 'SubmissionSource::poll/wait observe the one original Completion under one ordinary mutex',
 'SubmissionSource::detach explicitly closes export and returns the original producer pin only after all view borrows end and actual producer retirement',
 'detail::OutputSource::create(const SubmissionSource&, ValueId output, const StorageOwner&, const LeasePool&)',
 'OutputSource::detach preserves a real original ready ReadLease only after whole success AND actual retirement',
 'bind_outputs/prepare_outputs/submit_outputs(Invocation&, span<const OutputBinding>, ...)',
 'ReplayAccess::can_reuse_capture(const Invocation&, span<const ReplayInputBinding>) checks the complete final replacement tuple' ],facts=[
 'The old OutputSource::create Completion argument and the old three singular output adapters are removed, without compatibility overloads. Public Invocation/Completion layouts, provider runtime facts and ReplayOptions are unchanged.',
 'SubmissionSource keeps one exact original RetainedCompletion proxy, one actual Queue and one results pin; typed views do not move or observe separate Completions. A separate existing CompletionRetention node keeps metadata StorageOwner through true native retirement without a source/Completion self-cycle.',
 'Each typed view separately validates its original published value, dense I32 description, exact full original writer, real LeasePool domain, compiled StorageDomain resource owner, allocator lifetime and same actual Context. No whole-pool read permission or pending ReadLease is invented.',
 'One binding bundle strongly retains every typed view and its actual storage owner. Each InputSource attachment uses the same immutable SubmissionSource identity, so original dependency dedup does not lose the second view or create a second status observer.',
 'Atomic InputAccess::bind validates the complete incoming bundle before committing original bindings. View identities/pending authority markers change only after successful commit. Exact adapter matching checks both source identity and the actual retained bundle state; dedup still uses original (vtable, identity).',
 'Distinct consumer inputs are required. Readonly fanout from the same source value is allowed by the API, with real per-entry lease admission. That extra fanout variant was not independently executed in this finite window.',
 'Ordinary Invocation::submit cannot bypass the missing pending-read authority. Original OrderedGraphSubmission admits each actual lease and InputSources reconciles the full original producer status after consumer retirement.',
 'Capture-only qualification checks all replacement inputs together against existing full physical records. Missing artifacts/alias proof or tuple changes cannot record pending values or fall back to managed Commands.',
 'poll/wait do not implicitly close export, even when no views exist. OutputSource::detach only makes its own permission independent. Explicit SubmissionSource::detach returns a control-operation status: a failed-but-actually-retired submission can close successfully, while its poll/wait still report the original mathematical error.',
 'Borrow/ref teardown uses the common ordinary mutex only for borrowed pointers/counts, then destroys retained view/common refs outside that lock. Local StorageOwners cover allocator deallocation and original producer release. The original compiled domain retains its actual output resource through eventual allocation destruction.' ]),
 checks=dict(process=summary['process'],tests=summary['tests'],passed=6,failed=0,skipped=0,assertions=[
 'An actual CUDA host gate proves the original producer and consumer are pending, with watchdog release on all exits. The pending I32->checked Gather chain uses the original Queue and original lease domains.',
 'A genuine selected Store region exercises its existing metadata-only prepare/seal hooks while consuming the pending token, then take returns its original actual writer after retirement.',
 'A controlled original checked-index error prevents consumer publication. Typed detach preserves that error; after true retirement and release of borrowed views, common detach returns Ok, original outcome_available is true, and common wait still has exactly the original error code/message. This is not a native/driver fault injection.',
 'After successful view detach followed by explicit common detach, the producer can bind another genuine writer and submit a new generation while the original consumer is still gated. The old source remains immutable and preserves its old terminal verdict.',
 'A native Gather+Add consumer legally reuses its real existing capture: recorded count zero, reused count one, one source wait and zero host waits. Physical tuple misses reject and preserve the original recording; managed producer support is not claimed.',
 'The new producer has two real independent I32 output writers at different original offsets; the consumer has two checked Gather inputs. A late foreign-input bundle rejects without replacing the first old ready input or claiming either view. The complete retry succeeds.',
 'The two-value bundle reports source_count=1, device_wait_count=1 and host_wait_count=0, while both outputs retain independent resource proofs. Final values are [30,31] and [20,21], actual native uses return to zero and final release returns all output blocks.' ]),
 counts=dict(distinct_CXX_TUs=4,compiler_attempts=5,successful_compiles=5,failed_compiles=0,links=2,images=2,first_image_runs=0,final_image_runs=1,test_processes=1,test_cases=6,NVCC=0,SDK_rebuilds=0,downloads=0,model_processes=0,benchmarks=0),
 refinements=[dict(reason='Root added failed-but-actually-retired common detach assertions to an existing case after the first successful compile/link had completed. No product source changed and no first image ran.',first_test=read(W/'source-freeze.json')[-1],final_test=sources[-1],compile=ready['compiled'][-1]['process'],not_a_failure=True)],failures=[],
 sources=sources,source_freezes=[pin(W/'source-freeze.json'),pin(W/'source-freeze2.json')],image=ready['image'],first_unrun_image=ready['first_unrun_image'],ready=pin(W/'ready2.json'),compiled=ready['compiled'],first_compiles=first['compiled'],links=[first['link'],ready['link']],retained_inputs=ready['inputs'],
 baseline=dict(receipt=pin(old),archive=pin(old.with_suffix('.zip')),ready=pin(R/'.scratch/inference-graph-output-capture-20261027/ready.json'),replacement_count=4,retained_inputs=226,total_inputs=230,note='Original 230-input closure, replacing executable/resources/input_sources/test only. Both link identities and exact actual dependencies are retained. No SDK, model, EXE, OBJ or full header tree is archived.'),
 environment=dict(runtime=ready['runtime'],note='Same local Windows CUDA/toolchain/native runtime closure as the referenced prior evidence. No new hardware/toolchain measurement, SDK or shader/kernel compilation in this batch.'),
 limits=[
 'Only one actual shared Queue, prepared/nonblocking producers and fixed dense caller-owned I32 views are implemented in this slice. Complete existing-capture consumers qualify without changing global provider runtime declarations.',
 'No Store or paged-append pending ticket, MTP/KV correction or engine integration is implemented here. A regular non-pending Store consumer regression is not pending state relay.',
 'One readonly value exported twice or one common source used by two distinct consumers is permitted by the architecture but was not independently executed in this six-case window.',
 'Failure typed recovery is not added: a failed token view does not become ready; its borrow must be released before common control detach. Closing source export and mathematical success remain independent facts.',
 'No multi-segment/managed-island producer, sustained finite-slot rotation, complete model quality/throughput claim, driver/native-fault injection, GPU spin kernel or download.',
 'Original caller-owned Graph metadata allocator and external pool root lifetime contracts remain. Detach does not wait for pending work but ordinary final allocator/provider destruction can synchronize; it is not an unconditional nonblocking API.' ],archive_members=members)
local=W/'receipt.json';local.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive=W/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for path in files:z.write(path,path.relative_to(W).as_posix())
 z.write(local,'receipt.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in members:assert hashlib.sha256(z.read(row['member'])).hexdigest()==row['sha256']
public=R/'docs/evidence/correctness/inference-submission-source-2026-10-27.json';assert not public.exists() and not public.with_suffix('.zip').exists()
public.with_suffix('.zip').write_bytes(archive.read_bytes());receipt['archive']=pin(public.with_suffix('.zip'));local.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');public.write_bytes(local.read_bytes())
publication=dict(receipt=pin(public),archive=pin(public.with_suffix('.zip')),members=len(files)+1,image=ready['image'],first_unrun_image=ready['first_unrun_image'],ready=pin(W/'ready2.json'))
(W/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8');print(json.dumps(publication,indent=2))
