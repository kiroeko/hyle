from pathlib import Path
import hashlib, json, zipfile
R = Path(__file__).resolve().parents[4]
S = Path(__file__).resolve().parent
def identity(p):
    p = Path(p)
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
old = read(S/'checks1-cpu/frontier.driver.json')
assert old['native']['exit'] != 0 and len(old['fetches']) == 4
assert all(x['exit'] == 0 for x in old['fetches'])
for name, count in [('fixture-hc',1), ('focused-gdn',3)]:
    check = read(S/'runtime-checks2'/name/'summary.json')
    assert check['tests'] == count and check['failures'] == check['skips'] == 0
files = [S/'mixed-native-preparation/native-plan.json', S/'mixed-native-preparation/compile-native.cmd',
         S/'native-mixed1/root-build-result.json', S/'native-mixed1/cpu-avx2-mixed-deps.json',
         S/'native-mixed1/cpu-program-export-mixed-deps.json', S/'tests-link1/ready.json',
         S/'tests-link1/runtime-environment.json', S/'tests-link2/ready.json',
         S/'tests-link2/runtime-environment.json', S/'checks1-cpu/frontier.driver.json',
         S/'checks1-cpu/run/process.json', S/'checks1-cpu/run/stdout.log',
         Path(__file__), S/'run_runtime_checks.py',
         R/'src/compute_ggml_runtime/CMakeLists.txt', R/'src/compute_ggml_runtime/cpu_program.cmake',
         R/'src/compute_ggml_runtime/cpu_program_export.cc', R/'src/compute_ggml_runtime/gated_delta_scale.h']
plan = read(S/'mixed-native-preparation/native-plan.json')
files += [Path(x['source']['path']) for x in plan['jobs'] if 'source' in x]
files += [R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-proposal/native-after/cpu-current-avx2/src/ggml-cpu/ops.cpp']
for name in ('fixture-hc','focused-gdn'):
    base=S/'runtime-checks2'/name
    files += [base/'summary.json',base/'results.xml',base/'run/process.json',
              base/'run/stdout.log',base/'run/stderr.log',base/'run/command.json']
out=R/'docs/evidence/correctness/mtp-cpu-native-family-2026-10-24'
with zipfile.ZipFile(out.with_suffix('.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in dict.fromkeys(files): z.write(p,arcname=p.relative_to(R).as_posix())
document=dict(status='Validation assembly corrected; existing four CPU checks passed. Original Q30 run remains pending.',
    root_cause='Manual incremental validation paired mixed-revision ggml-base constructors with the newer ffa4 AVX2 CPU implementation. That HCpre implementation reads scale from op_params[0], while the mixed constructor leaves that slot zero. Normal project CMake derives baseline and AVX2 sources from the same owning ggml-cpu target.',
    correction='Recompiled two small owning mixed-family CPU translation units and linked with its own cached objects/base. Kept the exact same Flash executable, model graph, reference math and numerical bounds; replaced only its native CPU module.',
    failed_attempt=dict(native=old['native'],finished_bounded_fetches=4,
        reason='Stopped the invalid native run after observing HC collapse zero; waited for the active approved fetch to finish before stopping. Does not establish a product HC or Q30 numerical defect.'),
    checks=dict(cases=4,failures=0,skips=0,
        fixture='Existing target43->44->NextN finite Graph journey: 41 NextN plus 12 target44 and 12 target43 submissions; generated inputs, not original Q30 identity.',
        gdn='Three existing direct CPU explicit/default output-scale and state-snapshot checks.'),
    archive=identity(out.with_suffix('.zip')),files=[identity(p) for p in dict.fromkeys(files)],
    full_model_quality=False,throughput_evidence=False,physical_memory_evidence=False,
    original_Q30_complete=False,product_source_changes_for_this_correction=0)
out.with_suffix('.json').write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identity(out.with_suffix('.json'))))
