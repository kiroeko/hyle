"""Use the corrected same-family module with the existing focused consumers."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
spec = importlib.util.spec_from_file_location('runtime_check_execute', R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
stage = S/'tests-link2'
ready = read(stage/'ready.json')
assert identity(ready['image']['path']) == ready['image']
runtime = read(stage/'runtime-environment.json')
for item in runtime['staged_dlls']: assert identity(item['path']) == item
env = os.environ.copy()
env['PATH'] = runtime['PATH']
focused = R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/focused-cpu-link1/gdn-scale-checks.exe'
target = stage/'gdn-scale-checks.exe'
assert not target.exists()
os.link(focused, target)
jobs = [(Path(ready['image']['path']), 'GlmMtpStateConsumer.CpuTarget43MlaFlowsThroughTarget44AndNextN', 1, 'fixture-hc'),
        (target, 'GdnOutputScale.*', 3, 'focused-gdn')]
for image, case, count, name in jobs:
    out = S/'runtime-checks2'/name
    result = q.execute([str(image), '--gtest_filter='+case, '--gtest_throw_on_failure=1',
                        '--gtest_output=xml:'+str(out/'results.xml')], env, out/'run', timeout=1800)
    assert result['exit'] == 0 and not result['timed_out'], result
    tree = ET.parse(out/'results.xml').getroot()
    assert int(tree.get('tests')) == count
    assert all(int(tree.get(k, '0')) == 0 for k in ('failures', 'errors', 'disabled'))
    assert not list(tree.iter('skipped'))
    (out/'summary.json').write_text(json.dumps(dict(tests=count, failures=0, skips=0,
        image=identity(image), runtime=identity(stage/'runtime-environment.json'),
        scope='Existing finite fixture or direct GDN checks; not original Q30 identity, quality or throughput.'), indent=2)+'\n', encoding='utf-8')
    print('PASSED corrected mixed runtime', name, flush=True)
