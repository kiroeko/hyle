from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-multimodel-observation-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    base_path = R / '.scratch/inference-cold-family-publication-20261030/model-link-base.json'
    base = read(base_path)
    for item in [*base['retained'], base['runtime'], base['sdk_engine_dependencies']]:
        exact(item)
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']:
            exact(item)
    old_source = base['consumer_source']['path']
    old_object = read(base['previous_consumer']['path'])['object']['path']
    old_wrapper = (R / '.scratch/inference-continuation-control-20261030/model.cc').read_text()
    head = old_wrapper[:old_wrapper.index('int main(')]
    current = (W / 'model.cc').read_text()
    (W / 'model.cc').write_text(head + '#include "qwen_publication_retirement_case.h"\n'
        '#include "qwen_mtp_group_return_case.h"\n\n' + current[current.index('int main('):])
    units = {}
    for name, source in [('model', W / 'model.cc'),
                         ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        command = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index - 1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(old_source):
                arg = str(source)
            command.append(arg)
        link = []
        for arg in base['link']:
            if key(arg) == key(old_object):
                arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link.append(arg)
        assert sum(key(arg) == key(source) for arg in command) == 1
        assert sum(key(arg) == key(folder / 'unit.obj') for arg in link) == 1
        units[name] = dict(source=str(source), compile=command, link=link)
    host = read(R / '.scratch/inference-continuation-control-20261030/plan.json')['units']['ledger']
    folder = W / 'compile/ledger'
    folder.mkdir(parents=True, exist_ok=True)
    command = []
    for index, arg in enumerate(host['compile']):
        if index and host['compile'][index - 1].lower() == '/sourcedependencies':
            arg = str(folder / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(folder / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(folder / 'unit.pdb')
        command.append(arg)
    old_host_object = str(R / '.scratch/inference-continuation-control-20261030/compile/ledger/unit.obj')
    link = []
    for arg in host['link']:
        if key(arg) == key(old_host_object):
            arg = str(folder / 'unit.obj')
        if arg.upper().startswith('/OUT:'):
            arg = '/OUT:' + str(W / 'bin/ledger.exe')
        link.append(arg)
    units['ledger'] = dict(source=host['source'], compile=command, link=link)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    tiny = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    original = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    source_continuous = R / '.scratch/inference-continuous-wave-20261027/inputs/context32'
    continuous = W / 'continuous-input'
    continuous.mkdir(exist_ok=True)
    for metadata in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(source_continuous / metadata, continuous / metadata)
    fixtures = {}
    for name, directory in [('tiny', tiny), ('original', original), ('continuous', continuous)]:
        fixtures[name] = dict(directory=str(directory), manifest=pin(directory / 'weights.tsv'), prompt=pin(directory / 'prompt.ids'))
    cases = {
        'publication-cpu': dict(unit='model', args=['publication', 'cpu', str(tiny)]),
        'publication-cuda': dict(unit='model', args=['publication', 'cuda', str(tiny)]),
        'commit-cpu': dict(unit='model', args=['commit', 'cpu', str(tiny)]),
        'group-cuda': dict(unit='model', args=['group', 'cuda', str(tiny)]),
        'natural-cuda': dict(unit='model', args=['natural', 'cuda', str(original)]),
        'continuous-cuda': dict(unit='ordinary', args=['--cuda-continuous', str(continuous)]),
        'ledger': dict(unit='ledger', args=[]),
    }
    save(W / 'plan.json', dict(base=pin(base_path), units=units, retained=base['retained'], runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'], fixtures=fixtures, cases=cases))
    print('Prepared 3 bounded consumers; 227 SDK/engine inputs reused; no native process started.')


def run(name, attempt):
    plan = read(W / 'plan.json')
    case = plan['cases'][name]
    b.receipt(case['unit'])
    image = read(W / ('ready-' + case['unit'] + '.json'))
    exact(image)
    folder = W / 'runs' / name / attempt
    save(folder / 'image.json', image)
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    b.b.execute([image['path'], *case['args']], folder, 600)
    report = read(folder / 'stdout.log')
    assert report['status'] == 'PASS'
    if name == 'ledger':
        assert report['groups'] == 9 and not report['device_execution']
    save(folder / 'report.json', report)
    print('PASS', name)


if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare()
    elif sys.argv[1] == 'run':
        run(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else 'attempt1')
    else:
        b.main()
