from pathlib import Path
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact = b.read, b.save, b.pin, b.exact

plan = read(W / 'plan.json')
for item in [*plan['retained'], plan['runtime'], plan['sdk']]:
    exact(item)
for unit in read(plan['sdk']['path'])['engine_consumers']:
    for item in unit['source_identities']:
        exact(item)
builds = []
for name, attempt in [('model', 'reviewed'), ('ordinary', 'reviewed'), ('ledger', 'current')]:
    receipt = b.b.receipt(name)
    assert read(receipt['process']['path']) == read(W / 'compile' / name / attempt / 'process.json')
    builds.append(dict(unit=name, object=receipt['object'], receipt=pin(W / 'compile' / name / 'receipt.json')))
runs = []
for name in plan['cases']:
    attempt = {'ledger': 'current', 'continuous-cuda': 'reviewed2'}.get(name, 'reviewed')
    folder = W / 'runs' / name / attempt
    process = read(folder / 'process.json')
    report = read(folder / 'report.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out'] and report['status'] == 'PASS'
    summary = {key: value for key, value in report.items() if isinstance(value, (str, int, float, bool))}
    runs.append(dict(case=name, process=process, summary=summary, report=pin(folder / 'report.json'), image=read(folder / 'image.json')))

baseline = read(W / 'baseline.json')
failure = read(W / 'runs/publication-cpu/baseline/process.json')
assert failure['state'] == 'TERMINAL' and failure['exit'] == 1 and not failure['timed_out']
assert 'retired refusal did not clear only its exact original uncommitted record' in (W / 'runs/publication-cpu/baseline/stderr.log').read_text()
comparisons = []
previous = R / '.scratch/inference-cold-family-publication-20261030/runs'
for name in ['continuous-cuda', 'natural-cuda']:
    old = previous / name / 'attempt1/report.json'
    current = W / 'runs' / name / ('reviewed2' if name == 'continuous-cuda' else 'reviewed') / 'report.json'
    assert read(old) == read(current)
    comparisons.append(dict(case=name, original_report=pin(old), current_report=pin(current), complete_report_equal=True))

all_processes = [read(path) for path in sorted(W.rglob('process.json'))]
assert all(process['state'] == 'TERMINAL' and not process['timed_out'] for process in all_processes)
compile_attempts = list((W / 'compile').glob('*/*/process.json'))
link_attempts = list((W / 'link').glob('*/*/process.json'))
native_attempts = list((W / 'runs').glob('*/*/process.json'))
files = sorted(path for path in (W / 'bin').iterdir() if path.is_file())
assert files and all(path.suffix in {'.exe', '.dll', '.exp', '.lib', '.map', '.pdb'} for path in files)
save(W / 'cleanup-plan.json', dict(root=str(W / 'bin'), files=[pin(path) for path in files],
    bytes=sum(path.stat().st_size for path in files)))
base = read(plan['base']['path'])
model = plan['units']['model']
save(W / 'model-link-base.json', dict(schema='hyle.publication-retirement.current-link-base.v1', base=plan['base'],
    compile=model['compile'], link=model['link'], consumer_source=pin(model['source']),
    previous_consumer=pin(W / 'compile/model/receipt.json'), retained=base['retained'], runtime=base['runtime'],
    sdk_engine_dependencies=base['sdk_engine_dependencies']))
sources = ['engine/inference/program_carrier.h', 'engine/models/qwen35/generation_ledger.h',
    'engine/models/qwen35/main.cc', 'tests/tools/qwen_generation_ledger_test.cc',
    'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_publication_retirement_case.h']
record = dict(schema='hyle.correctness.publication-retirement.v1', date='2026-10-30', status='PASS_WITH_PRESERVED_PRODUCT_FAILURE',
    base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    changes=[
        'Typed and non-std publication failures share original abort and exact still-uncommitted record cleanup.',
        'Private NextN, prefix sampler and frontier use original Invocation/retention retirement facts; known negative retirement vetoes cleanup.',
        'Continuation recovery and request-wave retirement no longer substitute empty target/successor for private retirement.',
        'Host pending cleanup consults private retirement on unwind; successful continuation avoids an added private-inventory scan.',
        'All failed Step ledger borrows/tickets are withdrawn before the synchronous caller returns, with no later cleanup callback.',
        'Original Status, unknown exception, Head/RNG, committed peers, future records and delayed ordinal observation remain intact.'
    ], sources=[pin(R / path) for path in sources],
    counts=dict(CXX_attempts=len(compile_attempts), link_attempts=len(link_attempts), native_attempts=len(native_attempts),
        current_passed_processes=len(runs), current_host_groups=9, preserved_product_failures=1,
        preserved_fixture_precondition_failures=1, superseded_passed_native_processes=1,
        retained_SDK_engine_inputs=227, SDK_CXX=0, NVCC=0, downloads=0, whole_builds=0, throughput_windows=0),
    current_builds=builds, current_runs=runs,
    baseline=dict(record=pin(W / 'baseline.json'), process=failure,
        assertion='retired refusal did not clear only its exact original uncommitted record',
        scope='Original Model/SDK, minimal case wrapper. Current official test consumer adds an explicit borrowed-pointer withdrawal assertion; no math or thresholds changed.'),
    previous_reports=comparisons, fixtures=plan['fixtures'],
    boundaries=[
        'Baseline and new CPU/CUDA cases use untrained cached GA/H64 weights and real R2 Graph submissions; this is a publication/retirement regression, not model quality or TPS.',
        'Each repaired publication case performs four R2 submits: prefill, unpublished Complete refusal, same-input successful retry, and post-publication observer refusal. Observation retry submits nothing.',
        'Private MTP group-return and original BF16 Qwen P154/40-output paths exercise existing accepted/rejected state, ledger, RNG and native retirement contracts.',
        'Persistent unretired private native failure, hardware faults and a mid-head-swap failure were not injected. Existing original Invocation/retention proof is inspected without adding wait or permission authority.',
        'Intermediate CXX consumers were superseded when review found outer cleanup gates; one intermediate ordinary CUDA run passed, but current claims use the final reviewed objects.',
        'The final ordinary rerun first refused an already-generated fixture before Model creation. A new directory copied only weights.tsv/prompt.ids and reused original payloads; the refused attempt is preserved.',
        'No CMake configure/install, Apple/Vulkan process, complete large model or throughput comparison was run.'
    ])
evidence = R / 'docs/evidence/correctness/inference-publication-retirement-2026-10-30.json'
save(evidence, record)
bundle = evidence.with_suffix('.zip')
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(W.rglob('*')):
        if not path.is_file() or any(part in {'bin', 'tmp', '__pycache__'} for part in path.relative_to(W).parts):
            continue
        if path.suffix in {'.obj', '.pdb'}:
            continue
        archive.write(path, str(path.relative_to(W)))
    archive.write(evidence, evidence.name)
record['archive'] = pin(bundle)
save(evidence, record)
print(dict(status=record['status'], current_processes=len(runs), CXX=len(compile_attempts),
    links=len(link_attempts), native_attempts=len(native_attempts), archive_bytes=bundle.stat().st_size))
