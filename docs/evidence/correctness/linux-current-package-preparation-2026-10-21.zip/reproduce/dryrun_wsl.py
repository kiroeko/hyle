from pathlib import Path
import json,subprocess,time,re,collections,shutil,hashlib
S=Path('/mnt/c/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21')
build=Path('/root/hyle-scratch/active-cpu-z/build')
command=['ninja','-C',str(build),'-n','hyle_graph','hyle_graph_progress']
started=time.time();result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
(S/'ninja-dryrun.stdout.log').write_text(result.stdout);(S/'ninja-dryrun.stderr.log').write_text(result.stderr)
rows=[]
for line in result.stdout.splitlines():
 m=re.match(r'\[(\d+)/(\d+)\] (.*)',line)
 if not m:continue
 text=m.group(3);kind='other';source='other'
 if 'Building CXX object ' in text:kind='CXX'
 elif 'Building CUDA object ' in text:kind='CUDA'
 elif 'Building C object ' in text:kind='C'
 elif 'Building ASM object ' in text:kind='ASM'
 elif 'Linking ' in text:kind='link'
 if 'hyle_ggml_cpu_avx2_' in text:source='ggml_cpu_program'
 elif 'CMakeFiles/hyle_' in text:source='Hyle'
 elif '/vendor/' in text or 'ggml-cuda-precise-unary' in text:source='ggml'
 elif 'onednn' in text or '/dnnl' in text:source='oneDNN'
 rows.append(dict(description=text,kind=kind,owner=source))
record=dict(command=command,exit_code=result.returncode,seconds=time.time()-started,planned_jobs=len(rows),counts=dict(collections.Counter(x['kind'] for x in rows)),owner_counts={owner:dict(collections.Counter(x['kind'] for x in rows if x['owner']==owner)) for owner in sorted({x['owner'] for x in rows})},disk_free=shutil.disk_usage(build).free,jobs=rows,builds_executed=0,gpu_runs=0)
(S/'ninja-dryrun.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='jobs'},indent=2))
