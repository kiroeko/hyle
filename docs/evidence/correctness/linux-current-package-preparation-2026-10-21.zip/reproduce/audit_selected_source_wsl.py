from pathlib import Path
import hashlib,json
R=Path('/mnt/c/public/project-hyle/hyle');S=R/'.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21';plan=json.loads((S/'sync-plan.json').read_text());root=Path(plan['destination']);rows=[]
for item in plan['files']:
 rel=item['relative'];a=(R/rel).read_bytes();b=(root/rel).read_bytes()
 rows.append(dict(relative=rel,bytes=len(a),sha256=hashlib.sha256(a).hexdigest(),matches=b==a))
extras=[]
for p in (root/'include/hyle').rglob('*'):
 if p.is_file() and not (R/p.relative_to(root)).exists():extras.append(str(p.relative_to(root)))
record=dict(source_truth=str(R),destination=str(root),selected_files=len(rows),selected_source_bytes=sum(x['bytes'] for x in rows),drift=[x for x in rows if not x['matches']],extra_validation_public_headers=extras,files=rows)
(S/'current-selected-source-audit.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
