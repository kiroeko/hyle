from pathlib import Path
import json,hashlib
R=Path('/mnt/c/public/project-hyle/hyle');S=R/'.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21';plan=json.loads((S/'sync-plan.json').read_text());root=Path(plan['destination']);rows=[];conflicts=[]
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\x00'+b).hexdigest()
for item in plan['files']:
 p=root/item['relative'];row=dict(relative=item['relative'],destination=str(p),action='create' if not p.exists() else 'same')
 if p.exists():
  if p.is_symlink():row['action']='symlink_conflict'
  elif not p.is_file():row['action']='nonfile_conflict'
  else:
   old=p.read_bytes();current=hashlib.sha256(old).hexdigest();row.update(old_sha256=current,old_bytes=len(old))
   if current!=item['sha256']:
    normalized=old.replace(b'\r\n',b'\n');matches=item['baseline_git_blob'] in [blob(old),blob(normalized)]
    row['action']='update_known_baseline' if matches else 'local_modification_conflict'
 if 'conflict' in row['action']:conflicts.append(row)
 rows.append(row)
record=dict(destination=str(root),counts={k:sum(x['action']==k for x in rows) for k in sorted({x['action'] for x in rows})},conflicts=conflicts,files=rows,applied=False)
(S/'sync-preflight.json').write_text(json.dumps(record,indent=2));print(json.dumps({'counts':record['counts'],'conflict_sources':[x['relative'] for x in conflicts]},indent=2))
