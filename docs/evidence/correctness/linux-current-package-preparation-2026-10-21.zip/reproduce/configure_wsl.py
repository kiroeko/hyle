from pathlib import Path
import json,shutil,hashlib,subprocess,time
S=Path('/mnt/c/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21')
work=Path('/root/hyle-scratch/active-cpu-z');build=work/'build';source=work/'source'
before=work/'delivery1-linux-current-2026-10-21/before-configure'
assert not before.exists()
before.mkdir(parents=True)
for rel in ['CMakeCache.txt','build.ninja','CMakeFiles/rules.ninja','compile_commands.json']:
 p=build/rel
 if p.exists():
  q=before/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
command=['cmake','-S',str(source),'-B',str(build),'-G','Ninja',
 '-UHYLE_COMPUTE_CPU','-UHYLE_COMPUTE_CUDA','-UHYLE_COMPUTE_APPLE','-UHYLE_COMPUTE_VULKAN',
 '-UHYLE_COMPUTE_ONEDNN','-UHYLE_COMPUTE_TORCH_CPU',
 '-DHYLE_COMPONENTS=graph;graph_progress','-DHYLE_COMPUTE_ROUTES=cpu;cuda',
 '-DHYLE_STATIC=ON','-DHYLE_INSTALL=ON','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF',
 '-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DFETCHCONTENT_UPDATES_DISCONNECTED=ON',
 '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
 '-DCMAKE_INSTALL_PREFIX=/root/hyle-scratch/active-cpu-z/delivery1-linux-current-2026-10-21/static-sdk-installed']
record=dict(command=command,cwd=str(work),before=str(before),sdk_builds=0,gpu_runs=0,started=time.time())
(S/'configure.command.json').write_text(json.dumps(record,indent=2))
with (S/'configure.stdout.log').open('w') as out,(S/'configure.stderr.log').open('w') as err:
 result=subprocess.run(command,cwd=work,stdout=out,stderr=err)
record.update(exit_code=result.returncode,seconds=time.time()-record['started'])
for rel in ['CMakeCache.txt','build.ninja']:
 p=build/rel
 if p.exists():record[rel]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(S/'configure.result.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
