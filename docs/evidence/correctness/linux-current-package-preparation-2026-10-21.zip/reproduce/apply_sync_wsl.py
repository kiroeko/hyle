from pathlib import Path
import json,hashlib,shutil,datetime
R=Path('/mnt/c/public/project-hyle/hyle')
S=R/'.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21'
plan=json.loads((S/'sync-plan.json').read_text())
pre=json.loads((S/'sync-preflight.json').read_text())
root=Path(plan['destination'])
backup=Path('/root/hyle-scratch/active-cpu-z/delivery1-linux-current-2026-10-21/before-overlay')
assert root.resolve()==Path('/root/hyle-scratch/active-cpu-z/source')
assert not backup.exists(), 'Do not replace an existing backup'
initial={x['relative']:x for x in pre['files']}
# Check all current sources and validation-copy files before any mutation.
for item in plan['files']:
 p=R/item['relative']; dest=root/item['relative']; old=initial[item['relative']]
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],str(p)
 if 'old_sha256' in old:
  assert dest.is_file() and not dest.is_symlink(),str(dest)
  assert hashlib.sha256(dest.read_bytes()).hexdigest()==old['old_sha256'],str(dest)
 else: assert not dest.exists(),str(dest)
backup.mkdir(parents=True)
rows=[]
for name in ['SOURCE-MANIFEST.txt','hyle-offline-deps.cmake']:
 p=root/name
 if p.exists():shutil.copy2(p,backup/name)
for item in plan['files']:
 rel=item['relative']; dest=root/rel; old=initial[rel]
 if old['action']=='same': continue
 if dest.exists():
  saved=backup/rel;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,saved)
 dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(R/rel,dest)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==item['sha256']
 rows.append(dict(relative=rel,old_sha256=old.get('old_sha256'),new_sha256=item['sha256'],bytes=item['bytes'],action=old['action']))
record=dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_truth=str(R),destination=str(root),backup=str(backup),files=rows,changed_files=len(rows),copied_bytes=sum(x['bytes'] for x in rows),conflicting_validation_files_backed_up=sum('conflict' in x['action'] for x in rows),unchanged=len(plan['files'])-len(rows),deleted_files=0,sdk_copies=0,reverse_sync=False,authorization='Root authorized current Windows source overlay after preserving all 20 validation-copy conflicts and SOURCE-MANIFEST.')
(backup.parent/'sync-result.json').write_text(json.dumps(record,indent=2))
(S/'sync-result.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
