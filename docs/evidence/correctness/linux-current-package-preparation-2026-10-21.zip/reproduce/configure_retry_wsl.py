from pathlib import Path
import json,hashlib,shutil,subprocess,time,sys
R=Path('/mnt/c/public/project-hyle/hyle');S=R/'.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21'
attempt=sys.argv[1]; prior=json.loads((S/'configure.command.json').read_text());work=Path(prior['cwd']);source=work/'source'
rows=[]
for rel in sys.argv[2:]:
 p=source/rel;before=p.read_bytes();b=R/rel;after=b.read_bytes();saved=work/'delivery1-linux-current-2026-10-21'/attempt/'before'/rel
 saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(before);shutil.copy2(b,p)
 rows.append(dict(relative=rel,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest()))
command=prior['command']; started=time.time()
with (S/(attempt+'.stdout.log')).open('w') as out,(S/(attempt+'.stderr.log')).open('w') as err:
 result=subprocess.run(command,cwd=work,stdout=out,stderr=err)
record=dict(command=command,cwd=str(work),source_updates=rows,exit_code=result.returncode,seconds=time.time()-started,builds=0,gpu_runs=0)
(S/(attempt+'.result.json')).write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
