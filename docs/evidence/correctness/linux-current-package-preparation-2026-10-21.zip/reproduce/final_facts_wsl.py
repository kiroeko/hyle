from pathlib import Path
import hashlib,json,re,shutil,subprocess
R=Path('/mnt/c/public/project-hyle/hyle');S=R/'.scratch/architecture-refactor-2026-10-18/delivery1-linux-current-2026-10-21';build=Path('/root/hyle-scratch/active-cpu-z/build')
index=build/'HylePackageIndex.cmake';install=build/'cmake_install.cmake'
def value(name):
 m=re.search(r'set\('+re.escape(name)+r' \[==\[(.*?)\]==\]\)',index.read_text())
 assert m,name
 return m.group(1).split(';')
groups=value('_Hyle_package_group_order');graph=value('_Hyle_product_graph_groups');lines=install.read_text().splitlines()
record=dict(index=dict(path=str(index),sha256=hashlib.sha256(index.read_bytes()).hexdigest()),install_script=dict(path=str(install),sha256=hashlib.sha256(install.read_bytes()).hexdigest()),mlx_group_count=groups.count('dependency_mlx_cuda_quant'),graph_mlx_group_count=graph.count('dependency_mlx_cuda_quant'),graph_has_both_consumers=all('factor_'+x in graph for x in ['compute_provider_cuda','compute_provider_torch_cuda']),license_install_lines=[dict(line=i+1,text=x) for i,x in enumerate(lines) if 'RENAME "mlx_cuda_quant-' in x],build_ninja_sha256=hashlib.sha256((build/'build.ninja').read_bytes()).hexdigest(),disk_free_bytes=shutil.disk_usage(build).free,installed_current_sdk_verified=False)
assert record['mlx_group_count']==1 and record['graph_mlx_group_count']==1 and record['graph_has_both_consumers']
assert len(record['license_install_lines'])==2
(S/'generated-package-projection.json').write_text(json.dumps(record,indent=2))
p=subprocess.run(['ps','-eo','pid,args'],capture_output=True,text=True)
record['running_build_processes']=[x for x in p.stdout.splitlines() if any(k in x for k in ['ninja -C','cmake -S','/bin/nvcc','cc1plus']) and 'final_facts' not in x]
(S/'final-runtime-facts.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
