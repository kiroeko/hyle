"""Finite extraction regression using current consumers and retained closures."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
SOURCE = D
sys.path.insert(0, str(R / 'scripts'))
from hyle_environment import discover_environment

CPU = R / '.scratch/mtp-q27-fp8-20261024/engine-cpu-current1'
VK = R / '.scratch/qwen-cpu-vulkan-20261024/engine-attempt1'
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def args(path):
    value = read(path)
    return value['command'] if isinstance(value, dict) else value
def pin(path):
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')
def environment(compiler):
    return discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
def execute(command, folder, env, timeout=240):
    folder.mkdir(parents=True, exist_ok=False)
    save(folder / 'command.json', {'command': command, 'cwd': str(R), 'timeout_seconds': timeout})
    start = time.monotonic()
    with (folder / 'stdout.log').open('wb') as out, (folder / 'stderr.log').open('wb') as err:
        process = subprocess.Popen(command, cwd=R, env=env, stdout=out, stderr=err,
            creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder / 'live.json', {'pid': process.pid})
        try:
            code = process.wait(timeout=timeout)
            result = {'exit': code, 'seconds': time.monotonic() - start, 'timeout': False}
        except subprocess.TimeoutExpired:
            process.kill(); process.wait()
            result = {'exit': process.returncode, 'seconds': time.monotonic() - start, 'timeout': True}
    save(folder / 'process.json', result)
    print(folder.name, json.dumps(result), flush=True)
    if result['exit'] or result['timeout']:
        print((folder / 'stdout.log').read_text(errors='replace')[-8000:])
        print((folder / 'stderr.log').read_text(errors='replace')[-8000:])
        raise SystemExit(1)
def compile(source, folder, vulkan=False, syntax=False):
    original = args(VK / 'compile/command.json') if vulkan else args(CPU / 'compile-command.json')
    env = environment(original[0]); flags = []; skip = False
    frozen = str(VK / 'source' if vulkan else CPU / 'source').lower().replace('\\', '/')
    for word in original[1:]:
        if skip: skip = False; continue
        if word == '/sourceDependencies': skip = True; continue
        lower = word.lower()
        if lower.startswith(('/fo', '/fd')) or lower.endswith(('.cc', '.cpp')): continue
        if lower.replace('\\', '/') in {'/i' + frozen, '-i' + frozen}: continue
        flags.append(word)
    if syntax: flags.append('/Zs')
    if source.name == 'retirement.cc':
        gtest_include = Path('C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
        if not (gtest_include / 'gtest/gtest.h').is_file(): raise RuntimeError('Existing gtest header cache is absent')
        flags.append('/external:I' + str(gtest_include))
    folder.parent.mkdir(parents=True, exist_ok=True)
    command = [original[0], *flags, '/I' + str(R), '/I' + str(R / 'include'),
        '/sourceDependencies', str(folder / 'dependencies.json'), str(source),
        '/Fo' + str(folder / 'unit.obj'), '/Fd' + str(folder / 'unit.pdb')]
    execute(command, folder, env)
    save(folder / 'sources.json', [pin(p) for p in [source,
        R / 'engine/inference/execution_resources.h',
        R / 'engine/models/qwen35/main.cc'] if p.exists()])
    return env
def link(obj, folder, env, vulkan=False, gtest=False):
    original = args(VK / 'link-plan.json') if vulkan else args(CPU / 'link-command.json')
    removed = [str(VK / 'compile/unit.obj')] if vulkan else [str(CPU / 'main.obj'),
        str(R / '.scratch/qwen-pure-cpu-deployment-20261024/build/CMakeFiles/hyle_cpu.dir/C_/public/project-hyle/hyle/engine/main.cc.obj')]
    normalized = {p.lower().replace('\\', '/') for p in removed}
    filtered = [x for x in original[1:] if x.lower().replace('\\', '/') not in normalized
        and not x.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:'))]
    for item in removed:
        if item.lower().replace('\\', '/') not in {x.lower().replace('\\', '/') for x in original}:
            raise RuntimeError('Pinned old entry is absent: ' + item)
    if gtest:
        filtered.extend(str(R / ('.scratch/build-compute-v2-dev/lib/' + name))
            for name in ['gtest.lib', 'gtest_main.lib'])
    execute([original[0], str(obj), *filtered, '/OUT:' + str(folder / 'probe.exe'),
        '/PDB:' + str(folder / 'probe.pdb')], folder, env, 120)
    native = VK / 'hyle_ggml_cpu_gdn_scale_v3.dll' if vulkan else CPU / 'bin/hyle_ggml_cpu_pure_ffa4_current.dll'
    os.link(native, folder / native.name)
    save(folder / 'native.json', pin(native))
    return folder / 'probe.exe'

if __name__ == '__main__':
    mode = sys.argv[1]
    if len(sys.argv) > 2:
        if not sys.argv[2].isalnum(): raise SystemExit('attempt must be alphanumeric')
        D = D / sys.argv[2]
    if mode == 'syntax':
        compile(R / 'engine/models/qwen35/main.cc', D / 'syntax', syntax=True)
    elif mode == 'queue':
        env = compile(SOURCE / 'queue.cc', D / 'queue-compile')
        image = link(D / 'queue-compile/unit.obj', D / 'queue-link', env)
        env.update({k: v for k, v in read(CPU / 'runtime-environment.json').items() if isinstance(v, str)})
        execute([str(image)], D / 'queue-run', env, 30)
    elif mode in {'retirement', 'readback'}:
        env = compile(SOURCE / 'retirement.cc', D / 'retirement-compile', vulkan=True)
        image = link(D / 'retirement-compile/unit.obj', D / 'retirement-link', env, vulkan=True, gtest=True)
        env.update({k: v for k, v in read(VK / 'runtime.json').items() if isinstance(v, str)})
        selected = 'InferenceExtraction.*' if mode == 'readback' else 'QwenResourceRetirement.*:InferenceExtraction.*'
        execute([str(image), '--gtest_filter=' + selected], D / 'retirement-run', env, 60)
    else:
        raise SystemExit('syntax | queue | retirement')
