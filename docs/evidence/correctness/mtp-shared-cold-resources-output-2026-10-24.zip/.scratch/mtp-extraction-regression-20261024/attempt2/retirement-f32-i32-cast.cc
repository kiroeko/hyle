#include "tests/tools/qwen_resource_retirement_test.cc"

TEST(InferenceExtraction, ActualPreparedReadbackScalarPorts) {
  auto backend = q::take(q::Backend::create());
  std::map<std::string, q::Tensor> bank;
  const auto shape = geometry();
  q::Recipe recipe(bank, backend, shape, 1);
  const auto input = recipe.input(q::dense(q::Type::kFloat32, {1}));
  const auto valid = recipe.host_predicate(recipe.cast(input, q::Type::kBool));
  const auto id = recipe.cast(input, q::Type::kInt32);
  recipe.publish(valid); recipe.publish(id);
  auto graph = q::take(std::move(recipe.builder).finish());
  const std::array shape_bindings{q::g::ShapeBinding{recipe.last_row, 0}};
  const std::array variants{q::g::ExactShapeVariant{shape_bindings}};
  auto compiled = q::take(backend.compile(graph, recipe.constants,
      recipe.options({.shape_policy = q::g::CompileShapePolicy::kFiniteExact,
          .exact_variants = variants, .constants = recipe.constants})));
  compiled.executable = q::take(compiled.executable.exact_variant(0));
  compiled.report = q::take(compiled.report.exact_variant(0));
  auto valid_readback = q::PreparedReadback::prepare(compiled, valid, backend);
  auto id_readback = q::PreparedReadback::prepare(compiled, id, backend);
  EXPECT_EQ(valid_readback.facts.description.data_type(), q::Type::kFloat32);
  EXPECT_EQ(id_readback.facts.description.data_type(), q::Type::kInt32);
  EXPECT_FALSE(valid_readback.facts.caller_owned());
  EXPECT_FALSE(id_readback.facts.caller_owned());
  auto run = q::take(compiled.executable.create_invocation());
  q::check(run.prepare_resources());
  q::Tensor value(backend.device(), q::dense(q::Type::kFloat32, {1}));
  const std::array<float, 1> original{19.F}; value.write<float>(original);
  q::check(run.bind(input, value.read()));
  valid_readback.bind(run); id_readback.bind(run);
  auto selected = q::take(hyle::inference::prepare_queue_bindings(backend.queue_bindings(), compiled.report));
  const auto queues = hyle::inference::queue_span(selected);
  EXPECT_TRUE(queues.empty()); // Delegated native Vulkan lane has its own endpoint.
  q::check(run.prepare_replay(queues, {.mode = q::g::ReplayMode::kCommands}));
  auto completion = q::take(run.submit(queues)); q::check(completion.wait());
  EXPECT_EQ(valid_readback.predicate(backend, run), 1);
  std::int32_t actual = -1;
  id_readback.read(backend, run, std::as_writable_bytes(std::span(&actual, 1)));
  EXPECT_EQ(actual, 19);
}
