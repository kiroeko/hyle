#include <array>
#include <cstdio>
#include <stdexcept>
#include "engine/inference/execution_resources.h"
#include "engine/inference/prepared_output.h"
#include "hyle/graph/cpu.h"

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace i = hyle::inference;
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
void require(bool ok, const char *message) { if (!ok) throw std::runtime_error(message); }
int main() {
  try {
    auto context = g::cpu::create_context().value();
    auto queue = context.create_queue().value();
    const auto description = c::TensorDesc::dense(c::DataType::kFloat32,
        std::array<std::int64_t, 1>{17}).value();
    auto builder = g::GraphBuilder::create().value();
    const auto x = builder.input(description).value();
    const auto y = builder.add(c::Unary{c::UnaryKind::kNeg}, x).value();
    check(builder.publish(y));
    auto graph = std::move(builder).finish().value();
    auto compiled = g::cpu::compile(graph, context).value();
    require(compiled.report.lane_count() == 1, "CPU tiny should have one actual lane");
    require(compiled.report.lane(0).value().queue_required, "CPU tiny must require its real Queue");
    auto missing = i::prepare_queue_bindings({}, compiled.report);
    require(!missing && missing.error().IsFailedPrecondition(), "missing required Queue accepted");
    const std::array available{g::QueueBinding{g::ExecutionLaneId{7}, &queue},
        g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
    auto selected = i::prepare_queue_bindings(available, compiled.report).value();
    require(selected.size() == 1 && selected[0].lane == g::ExecutionLaneId{0},
        "extra Queue was selected or required lane changed");
    std::array<float, 17> values{};
    for (std::size_t n = 0; n < values.size(); ++n) values[n] = float(n) - 8.F;
    auto backing = hyle::mem::Buffer::create(hyle::mem::system_resource(), sizeof(values)).value();
    check(backing.view().write(std::as_bytes(std::span(values))));
    auto input = c::ReadLease::adopt(std::move(backing)).value();
    auto invocation = compiled.executable.create_invocation().value();
    check(invocation.prepare_resources());
    check(invocation.bind(x, description, input));
    auto facts = i::prepare_output(compiled, y).value();
    hyle::mem::Buffer output_backing;
    if (facts.caller_owned()) {
      output_backing = hyle::mem::Buffer::create(hyle::mem::system_resource(),
          facts.description.required_bytes().value()).value();
      check(invocation.bind(y, c::TensorView::create(facts.description, output_backing.view()).value()));
    }
    const auto queues = i::queue_span(selected);
    check(invocation.prepare_replay(queues, {.mode = g::ReplayMode::kCommands}));
    auto completion = invocation.submit(queues).value();
    check(completion.wait());
    auto output = invocation.result(y).value();
    std::array<float, 17> actual{};
    if (auto tensor = output.tensor(); tensor) {
      check(tensor->storage().read(std::as_writable_bytes(std::span(actual))));
    } else {
      auto ready = output.storage_lease().value();
      check(ready.view().value().read(std::as_writable_bytes(std::span(actual))));
    }
    for (std::size_t n = 0; n < values.size(); ++n)
      require(actual[n] == -values[n], "CPU tiny output differs");
    std::puts("PASS shared queue bindings: missing rejects, extra ignored, actual required lane executes 17 exact values");
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "FAIL %s\n", error.what()); return 1;
  }
}
