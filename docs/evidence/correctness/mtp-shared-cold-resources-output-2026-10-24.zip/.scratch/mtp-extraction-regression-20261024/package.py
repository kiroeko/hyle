"""Keep only this finite refactor's source, commands and observed results."""
from pathlib import Path
import difflib
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
OUT = R / 'docs/evidence/correctness/mtp-shared-cold-resources-output-2026-10-24'

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def identity(path):
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def main():
    syntax = load(D / 'syntax/process.json')
    queue = load(D / 'attempt4/queue-run/process.json')
    retirement = load(D / 'attempt2/retirement-run/process.json')
    native_readback = load(D / 'attempt3/retirement-run/process.json')
    output = load(R / '.scratch/prepared-output-20261024/cpu1/summary.json')
    if any(x.get('exit') != 0 or x.get('timeout') for x in (syntax, queue, native_readback)):
        raise RuntimeError('Finite consumer checks must actually pass')
    logs = (D / 'attempt2/retirement-run/stdout.log').read_text(encoding='utf8')
    cases = ['SessionRetiresOriginalWorkAfterItsModelWasDestroyed',
             'LastOriginalCallbackReleasesScopeWithoutApplicationOwners']
    if any('[       OK ] QwenResourceRetirement.' + case not in logs for case in cases):
        raise RuntimeError('Require the two original retirement cases to actually pass')
    if retirement['exit'] != 1 or 'Vulkan Cast requires F32/F16/BF16/Bool' not in logs:
        raise RuntimeError('Retain and accurately identify the initial private-fixture failure')
    native_logs = (D / 'attempt3/retirement-run/stdout.log').read_text(encoding='utf8')
    if '[       OK ] InferenceExtraction.ActualPreparedReadbackScalarPorts' not in native_logs:
        raise RuntimeError('Require the actual provider-owned scalar readback check')
    output_run = load(R / '.scratch/prepared-output-20261024/cpu1/run/process.json')
    if output_run['exit'] != 0:
        raise RuntimeError('Actual output facts probe failed')
    sources = [R / name for name in (
        'engine/inference/execution_resources.h',
        'engine/inference/prepared_output.h',
        'engine/models/qwen35/main.cc',
        'engine/models/qwen35/backend.h',
        'tests/tools/qwen_mtp_projection_width_probe.cc',
        'tests/tools/qwen_resource_retirement_test.cc',
        'tests/graph_route_vulkan/retirement_test.cc')]
    old = R / '.scratch/qwen-cpu-vulkan-20261024/engine-attempt1/source/engine/models/qwen35/main.cc'
    diff = ''.join(difflib.unified_diff(old.read_text(encoding='utf8').splitlines(True),
        (R / 'engine/models/qwen35/main.cc').read_text(encoding='utf8').splitlines(True),
        fromfile='frozen-pre-extraction/main.cc', tofile='current/main.cc'))
    (D / 'main.diff').write_text(diff, encoding='utf8')
    folders = [D / 'syntax', D / 'attempt4', D / 'attempt2', D / 'attempt3',
        R / '.scratch/prepared-output-20261024/cpu1']
    records = [p for folder in folders for p in folder.rglob('*')
        if p.is_file() and p.suffix in {'.json', '.log'}]
    records += [D / 'check.py', D / 'queue.cc', D / 'retirement.cc', D / 'main.diff',
        D / 'attempt2/retirement-f32-i32-cast.cc', Path(__file__),
        R / '.scratch/prepared-output-20261024/cpu-probe.cc']
    with zipfile.ZipFile(OUT.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(sources + records)):
            z.write(p, p.relative_to(R).as_posix())
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:
        if z.testzip() is not None:
            raise RuntimeError('Evidence archive CRC failed')
        entries = len(z.namelist())
    result = dict(date='2026-10-24', status='PASS finite behavior-preserving extraction',
        sources=[identity(p) for p in sources], archive=identity(OUT.with_suffix('.zip')),
        archive_entries=entries,
        changes=['Move the original completion-retention node into engine/inference unchanged',
            'Select required queue bindings using real compiled lane IDs',
            'Prepare actual published output description, storage domain and ownership',
            'Migrate Qwen prefix sampling and frontier scalar bindings/readback',
            'Remove the old private header and its stale unused Vulkan-test include'],
        checks=dict(cpu_consumer_strict_syntax=syntax,
            cpu_queue_selection_and_17_exact_values=queue,
            output_facts='Four real ownerships, static route, two exact children and rejected mismatches',
            vulkan_original_retirement_cases=dict(passed=2, names=cases,
                original_process=retirement,
                process_scope='Both original cases passed; process exit1 from a subsequent private-fixture unsupported Cast. The corrected fixture was run separately.'),
            vulkan_native_readback=native_readback,
            independent_review='No definite m0/multi-proposal, readback lifetime or publication regression found'),
        limits=['Not the complete backend-assembly or model-architecture refactor',
            'Model scalar readback retains its explicit primary-domain external-output contract',
            'No model mathematics, graph sampling policy, precision or fusion changes',
            'No full model, throughput, memory-comparison or cross-platform runtime claim',
            'CPU strict syntax predates only the equivalent lane ordinal-to-reported-ID change; runtime probes use current header',
            'Pending Qwen27 FP8 complete journeys use their separate frozen image'],
        SDK_builds=0, HTTP_requests=0, trained_model_download_bytes=0)
    with OUT.with_suffix('.json').open('x', encoding='utf8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
        f.write('\n')
    print(json.dumps(dict(evidence=identity(OUT.with_suffix('.json')),
        archive=result['archive'], entries=entries)))

if __name__ == '__main__':
    main()
