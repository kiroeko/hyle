#pragma once

#include <array>
#include <cstddef>
#include <span>
#include <utility>

#include "hyle/compute/file_stream.h"
#include "hyle/compute/storage_owner.h"
#include "hyle/graph/batch.h"
#include "hyle/mem/buffer.h"

#if defined(HYLE_COMPUTE_CPU)
#include "hyle/compute/cpu_file_stream.h"
#include "hyle/graph/cpu.h"
#endif

#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
#include "hyle/compute/apple_file_stream.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/graph/apple.h"
#elif defined(HYLE_COMPUTE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/cuda_file_stream.h"
#include "hyle/graph/cuda.h"
#elif defined(HYLE_COMPUTE_VULKAN)
#include "hyle/compute/vulkan_file_stream.h"
#include "hyle/compute/vulkan_memory.h"
#include "hyle/graph/vulkan.h"
#elif !defined(HYLE_COMPUTE_CPU)
#error "Hyle inference requires a CPU, Apple, CUDA or Vulkan backend"
#endif

namespace qwen35 {

struct WorkspaceBudgets final {
  std::size_t device = SIZE_MAX, host = SIZE_MAX, staging = SIZE_MAX;
};

// One cold environment for this consumer. It owns the real allocation domains
// and endpoint; Graph/Compute retain their existing executors and retirement.
// In particular, native Apple resources remain borrowed by Buffer/LeasePool:
// this owner must outlive every tensor, executable, invocation and native use.
class Backend final {
public:
#if (defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN)
  static constexpr bool host_only = false;
#else
  static constexpr bool host_only = true;
#endif
#if defined(HYLE_COMPUTE_CPU)
  static constexpr bool supports_cpu_gpu = !host_only;
#else
  static constexpr bool supports_cpu_gpu = false;
#endif
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
  static constexpr bool native_generated_storage = true;
  static constexpr const char *name() noexcept { return "apple"; }
  // Cold test interop only: the retirement probe uses this original Context,
  // never a replacement device, stream or execution source.
  hyle::compute::apple::Context &native_probe_context() noexcept { return context_; }
#elif defined(HYLE_COMPUTE_CUDA)
  static constexpr bool native_generated_storage = false;
  static constexpr const char *name() noexcept { return "cuda"; }
  // Existing CUDA-only native queue diagnostics borrow these original owners.
  hyle::compute::Context &common_context() noexcept { return context_; }
  hyle::compute::Queue &common_queue() noexcept { return queue_; }
#elif defined(HYLE_COMPUTE_VULKAN)
  static constexpr bool native_generated_storage = true;
  static constexpr const char *name() noexcept { return "vulkan"; }
  hyle::compute::vulkan::Context &native_probe_context() noexcept { return context_; }
#else
  static constexpr bool native_generated_storage = false;
  static constexpr const char *name() noexcept { return "cpu"; }
  hyle::compute::Context &common_context() noexcept { return context_; }
  hyle::compute::Queue &common_queue() noexcept { return queue_; }
#endif
  Backend() noexcept = default;
  Backend(const Backend &) = delete;
  Backend &operator=(const Backend &) = delete;
  Backend(Backend &&) noexcept = default;
  Backend &operator=(Backend &&) noexcept = default;

  static hyle::Result<Backend> create(WorkspaceBudgets budgets = {}) noexcept {
    Backend result;
    result.workspace_budgets_ = budgets;
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
    HYLE_ASSIGN_OR_RETURN(result.context_, hyle::compute::apple::Context::create());
    HYLE_ASSIGN_OR_RETURN(result.memory_, hyle::compute::apple::MemoryResource::create(result.context_));
    HYLE_ASSIGN_OR_RETURN(result.staging_, hyle::compute::apple::MemoryResource::create(result.context_));
    HYLE_ASSIGN_OR_RETURN(result.source_, hyle::graph::apple::execution_source(result.context_));
#elif defined(HYLE_COMPUTE_CUDA)
    HYLE_ASSIGN_OR_RETURN(result.context_, hyle::graph::cuda::create_context());
    HYLE_ASSIGN_OR_RETURN(auto resource, hyle::compute::cuda::MemoryResource::create(
        result.context_, hyle::compute::cuda::MemoryKind::kDevice));
    HYLE_ASSIGN_OR_RETURN(result.memory_, hyle::compute::StorageOwner::adopt(result.context_, std::move(resource)));
    HYLE_ASSIGN_OR_RETURN(result.staging_, hyle::compute::cuda::MemoryResource::create(
        result.context_, hyle::compute::cuda::MemoryKind::kPinnedHost));
    HYLE_ASSIGN_OR_RETURN(result.queue_, result.context_.create_queue());
    HYLE_ASSIGN_OR_RETURN(result.source_, hyle::graph::ExecutionSource::acquire(result.context_));
#elif defined(HYLE_COMPUTE_VULKAN)
    HYLE_ASSIGN_OR_RETURN(result.context_, hyle::compute::vulkan::Context::create());
    HYLE_ASSIGN_OR_RETURN(result.memory_, hyle::compute::vulkan::MemoryResource::create(
        result.context_, hyle::compute::vulkan::MemoryKind::kDevice));
    HYLE_ASSIGN_OR_RETURN(result.staging_, hyle::compute::vulkan::MemoryResource::create(
        result.context_, hyle::compute::vulkan::MemoryKind::kStaging));
    HYLE_ASSIGN_OR_RETURN(result.source_, hyle::graph::vulkan::execution_source(result.context_));
#else
    HYLE_ASSIGN_OR_RETURN(result.context_, hyle::graph::cpu::create_context());
    HYLE_ASSIGN_OR_RETURN(result.cpu_memory_, hyle::compute::cpu::memory_resource(
        hyle::compute::cpu::device()));
    HYLE_ASSIGN_OR_RETURN(result.queue_, result.context_.create_queue());
    HYLE_ASSIGN_OR_RETURN(result.source_, hyle::graph::ExecutionSource::acquire(result.context_));
#endif
    return result;
  }

  // Optional cold assembly only. Ordinary create() retains its single native
  // endpoint. Both endpoints and all domains are the original real owners.
  static hyle::Result<Backend> create_cpu_gpu(WorkspaceBudgets budgets = {}) noexcept {
#if defined(HYLE_COMPUTE_CPU) && ((defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN))
    HYLE_ASSIGN_OR_RETURN(auto result, create(budgets));
    HYLE_ASSIGN_OR_RETURN(result.cpu_context_, hyle::graph::cpu::create_context());
    HYLE_ASSIGN_OR_RETURN(result.cpu_memory_, hyle::compute::cpu::memory_resource(
        hyle::compute::cpu::device()));
    HYLE_ASSIGN_OR_RETURN(result.cpu_queue_, result.cpu_context_.create_queue());
    HYLE_ASSIGN_OR_RETURN(result.cpu_source_, hyle::graph::ExecutionSource::acquire(result.cpu_context_));
#if defined(HYLE_COMPUTE_CUDA) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
    // Preserve the exact-context pinned domain's existing retained ownership.
    HYLE_ASSIGN_OR_RETURN(result.mixed_staging_, hyle::compute::StorageOwner::adopt(
        result.context_, std::move(result.staging_)));
#endif
    return result;
#else
    (void)budgets;
    return std::unexpected(hyle::Status::Unimplemented("CPU+GPU assembly requires both CPU and native GPU routes in this SDK"));
#endif
  }
  bool has_cpu_endpoint() const noexcept {
#if defined(HYLE_COMPUTE_CPU) && ((defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN))
    return bool(cpu_source_);
#else
    return false;
#endif
  }
  hyle::mem::MemoryResourceRef host_device() const noexcept {
#if defined(HYLE_COMPUTE_CPU)
    return cpu_memory_;
#else
    return {};
#endif
  }

  hyle::mem::MemoryResourceRef device() const noexcept {
#if (defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN)
    return memory_.ref();
#else
    return cpu_memory_;
#endif
  }
  hyle::mem::MemoryResourceRef staging() const noexcept {
#if defined(HYLE_COMPUTE_CUDA) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
    return mixed_staging_ ? mixed_staging_.ref() : staging_.ref();
#elif (defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_VULKAN)
    return staging_.ref();
#else
    return cpu_memory_;
#endif
  }

  // Engine-private format/loader seam: immutable constants use their actual
  // allocation-domain owner. CPU's process-lifetime resource needs no owner.
  hyle::Result<hyle::compute::StorageOwner> storage_owner_for(
      hyle::mem::MemoryResourceRef resource) const noexcept {
    if (!resource.valid())
      return std::unexpected(hyle::Status::InvalidArgument("Qwen resource is empty"));
    if (resource == device()) return storage_owner();
    if (has_cpu_endpoint() && resource == host_device()) return hyle::compute::StorageOwner{};
#if defined(HYLE_COMPUTE_CUDA) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
    if (mixed_staging_ && resource == staging()) return mixed_staging_;
#elif (defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_VULKAN)
    if (resource == staging()) return borrowed_storage_;
#endif
    return std::unexpected(hyle::Status::InvalidArgument("Qwen resource is outside its configured allocation domains"));
  }
  const hyle::compute::StorageOwner &storage_owner() const noexcept {
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
    // ConstantBinding/StorageDomain accept caller-owned native resources.
    return borrowed_storage_;
#elif defined(HYLE_COMPUTE_CUDA)
    return memory_;
#else
    return borrowed_storage_;
#endif
  }

  hyle::Result<hyle::compute::ReadLease> adopt_buffer(hyle::mem::Buffer &&buffer,
      hyle::compute::ResourceBudget budget = {}) const noexcept {
    if (buffer.valid() && has_cpu_endpoint() && buffer.resource() == host_device())
      return hyle::compute::ReadLease::adopt(std::move(buffer), {.resource_budget = std::move(budget)});
    if (!buffer.valid() || buffer.resource() != device())
      return std::unexpected(hyle::Status::InvalidArgument("Qwen buffer belongs to another backend resource"));
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
    return hyle::compute::ReadLease::adopt(std::move(buffer), {.resource_budget = std::move(budget)});
#elif defined(HYLE_COMPUTE_CUDA)
    return memory_.adopt_buffer(std::move(buffer), std::move(budget));
#else
    return hyle::compute::ReadLease::adopt(std::move(buffer), {.resource_budget = std::move(budget)});
#endif
  }
  hyle::Status freeze(hyle::mem::Buffer &buffer, hyle::compute::ReadLease &ready) const noexcept {
    if (ready.valid()) return hyle::Status::Ok();
    HYLE_ASSIGN_OR_RETURN(ready, adopt_buffer(std::move(buffer)));
    return hyle::Status::Ok();
  }

  // External I/O only. Callers must already have exclusive/retired access;
  // shared Apple storage does not manufacture a GPU completion or permission.
  hyle::Status write(hyle::mem::BufferView target, std::span<const std::byte> bytes) const noexcept {
    return target.write(bytes);
  }
  hyle::Status read(hyle::mem::ConstBufferView source, std::span<std::byte> bytes) const noexcept {
    return source.read(bytes);
  }
  hyle::Status fill(hyle::mem::BufferView target, std::byte value = {}) const noexcept {
    return target.fill(value);
  }

  hyle::Result<hyle::graph::CompiledGraph> compile(const hyle::graph::Graph &graph,
      std::span<const hyle::graph::ConstantBinding> constants,
      hyle::graph::CompileOptions options = {}) const noexcept {
    options.constants = constants;
#if defined(HYLE_COMPUTE_CPU) && ((defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN))
    if (has_cpu_endpoint()) {
      namespace g = hyle::graph;
      hyle::compute::StorageOwner staging_owner;
#if defined(HYLE_COMPUTE_CUDA) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
      staging_owner = mixed_staging_;
#endif
      const std::array domains{
          g::StorageDomain{.resource=device(), .workspace_budget_bytes=workspace_budgets_.device, .owner=storage_owner()},
          g::StorageDomain{.resource=host_device(), .workspace_budget_bytes=workspace_budgets_.host},
          g::StorageDomain{.resource=staging(), .workspace_budget_bytes=workspace_budgets_.staging, .owner=staging_owner}};
      const std::array targets{
          g::ExecutionTarget{source_,g::StorageDomainId{0}},
          g::ExecutionTarget{cpu_source_,g::StorageDomainId{1}}};
      const std::array lanes{
          g::ExecutionLane{g::ExecutionTargetId{0}},g::ExecutionLane{g::ExecutionTargetId{1}}};
      if (options.resource_budget) for (const auto &domain : domains) {
        auto usage=options.resource_budget.usage(domain.resource);
        if (!usage) return std::unexpected(std::move(usage).error());
      }
      return g::batch::compile(graph,{.storage_domains=domains,.targets=targets,.lanes=lanes},options);
    }
#endif
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
    const std::array domains{
        hyle::graph::StorageDomain{.resource = device(), .workspace_budget_bytes = workspace_budgets_.device, .owner = storage_owner()},
        hyle::graph::StorageDomain{.resource = staging(), .workspace_budget_bytes = workspace_budgets_.staging}};
#elif defined(HYLE_COMPUTE_CUDA) || (!defined(HYLE_COMPUTE_VULKAN) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)))
    // Preserve the original CUDA placement domain. Pinned staging is supplied
    // only to the loader and explicit host-workspace preparation. CPU likewise
    // uses one host domain; its staging resource is the same real allocation domain.
    const std::array domains{
        hyle::graph::StorageDomain{.resource = device(),
            .workspace_budget_bytes = host_only ? workspace_budgets_.host : workspace_budgets_.device,
            .owner = storage_owner()}};
#else
    const std::array domains{
        hyle::graph::StorageDomain{.resource = device(), .workspace_budget_bytes = workspace_budgets_.device, .owner = storage_owner()},
        hyle::graph::StorageDomain{.resource = staging(), .workspace_budget_bytes = workspace_budgets_.staging}};
#endif
    const std::array targets{hyle::graph::ExecutionTarget{source_, hyle::graph::StorageDomainId{0}}};
    return hyle::graph::batch::compile(graph, {.storage_domains = domains, .targets = targets}, options);
  }

  std::span<const hyle::graph::QueueBinding> queue_bindings() noexcept {
    // Refresh each borrow after a Backend move. Delegated native sources have
    // no Compute Queue; only their actual CPU lane receives a Queue binding.
#if defined(HYLE_COMPUTE_CPU) && ((defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN))
    if (has_cpu_endpoint()) {
      bindings_[1] = {.lane=hyle::graph::ExecutionLaneId{1},.queue=&cpu_queue_};
#if defined(HYLE_COMPUTE_CUDA) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
      bindings_[0] = {.lane=hyle::graph::ExecutionLaneId{0},.queue=&queue_};
      return bindings_;
#else
      return std::span(bindings_).subspan(1, 1);
#endif
    }
#endif
#if defined(HYLE_COMPUTE_CUDA) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
    bindings_[0] = {.lane = hyle::graph::ExecutionLaneId{0}, .queue = &queue_};
    return std::span(bindings_).first(1);
#elif !defined(HYLE_COMPUTE_VULKAN) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
    bindings_[0] = {.lane = hyle::graph::ExecutionLaneId{0}, .queue = &queue_};
    return bindings_;
#else
    return {};
#endif
  }

  // Nonblocking progress for abandoned native work. Vulkan deliberately uses
  // explicit collection; Apple/CUDA already retire through their original
  // workers. This keeps native collection out of session/state logic.
  hyle::Status collect_retired() noexcept {
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
    return hyle::Status::Ok();
#elif defined(HYLE_COMPUTE_CUDA)
    return hyle::Status::Ok();
#elif defined(HYLE_COMPUTE_VULKAN)
    return context_.collect();
#else
    return hyle::Status::Ok();
#endif
  }

  // Explicit blocking error/shutdown handoff to the original owner. Graph's
  // observer can already have been abandoned, so Vulkan must first drive its
  // owning Context's exceptional native-prefix drain. A returned error alone
  // does not prove retirement; callers still check the original typed guards.
  hyle::Status drain_retired(hyle::graph::Invocation &run) noexcept {
#if defined(HYLE_COMPUTE_VULKAN) && !defined(HYLE_COMPUTE_CUDA) && !(defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__))
    (void)run;
    return context_.drain();
#else
    // These endpoints retire on their original workers. Joining the original
    // Graph observation also joins its callback tail before owner destruction.
    return run.drain();
#endif
  }

  hyle::Result<hyle::compute::FileResourcePipeline> create_file_pipeline(
      hyle::io::IoContext &io, std::span<const hyle::compute::CopyResourceSpec> targets,
      hyle::compute::FileStreamOptions options = {}) noexcept {
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
    return hyle::compute::apple::create_file_pipeline(io, context_, staging(), targets, options);
#elif defined(HYLE_COMPUTE_CUDA)
    return hyle::compute::cuda::create_file_pipeline(io, context_, queue_, staging(), targets, options);
#elif defined(HYLE_COMPUTE_VULKAN)
    return hyle::compute::vulkan::create_file_pipeline(io, context_, staging(), targets, options);
#else
    return hyle::compute::cpu::create_file_pipeline(io, context_, queue_, staging(), targets, options);
#endif
  }

  // Explicit CPU-resident input preparation for mixed mode. This borrows the
  // same CPU endpoint as compile(); it never creates another Context/Queue or
  // routes host input through the native staging/copy endpoint.
  hyle::Result<hyle::compute::FileResourcePipeline> create_host_file_pipeline(
      hyle::io::IoContext &io, std::span<const hyle::compute::CopyResourceSpec> targets,
      hyle::compute::FileStreamOptions options = {}) noexcept {
#if defined(HYLE_COMPUTE_CPU) && ((defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN))
    if (!has_cpu_endpoint())
      return std::unexpected(hyle::Status::FailedPrecondition("CPU file input requires create_cpu_gpu()"));
    for (const auto &target : targets)
      if (target.resource != host_device())
        return std::unexpected(hyle::Status::InvalidArgument("CPU file target must use this Backend's host resource"));
    return hyle::compute::cpu::create_file_pipeline(io, cpu_context_, cpu_queue_, host_device(), targets, options);
#else
    (void)io; (void)targets; (void)options;
#if defined(HYLE_COMPUTE_CPU)
    return std::unexpected(hyle::Status::FailedPrecondition("CPU file input requires a mixed CPU+GPU Backend"));
#else
    return std::unexpected(hyle::Status::Unimplemented("CPU file input requires the CPU route in this SDK"));
#endif
#endif
  }

private:
  // Destruction reverses this order: endpoints disappear before their native
  // Context/resource owners. The Model drains its borrowed work first.
#if defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)
  hyle::compute::apple::Context context_;
  hyle::compute::apple::MemoryResource memory_, staging_;
  hyle::compute::StorageOwner borrowed_storage_;
  std::array<hyle::graph::QueueBinding, 2> bindings_{};
#elif defined(HYLE_COMPUTE_CUDA)
  hyle::compute::Context context_;
  hyle::compute::StorageOwner memory_, mixed_staging_;
  hyle::compute::cuda::MemoryResource staging_;
  hyle::compute::Queue queue_;
  std::array<hyle::graph::QueueBinding, 2> bindings_{};
#elif defined(HYLE_COMPUTE_VULKAN)
  hyle::compute::vulkan::Context context_;
  hyle::compute::vulkan::MemoryResource memory_, staging_;
  hyle::compute::StorageOwner borrowed_storage_;
  std::array<hyle::graph::QueueBinding, 2> bindings_{};
#else
  hyle::compute::Context context_;
  hyle::mem::MemoryResourceRef cpu_memory_;
  hyle::compute::StorageOwner borrowed_storage_;
  hyle::compute::Queue queue_;
  std::array<hyle::graph::QueueBinding, 1> bindings_{};
#endif
#if defined(HYLE_COMPUTE_CPU) && ((defined(HYLE_COMPUTE_APPLE) && defined(__APPLE__)) || defined(HYLE_COMPUTE_CUDA) || defined(HYLE_COMPUTE_VULKAN))
  hyle::compute::Context cpu_context_;
  hyle::mem::MemoryResourceRef cpu_memory_;
  hyle::compute::Queue cpu_queue_;
  hyle::graph::ExecutionSource cpu_source_;
#endif
  WorkspaceBudgets workspace_budgets_;
  hyle::graph::ExecutionSource source_;
};
} // namespace qwen35
