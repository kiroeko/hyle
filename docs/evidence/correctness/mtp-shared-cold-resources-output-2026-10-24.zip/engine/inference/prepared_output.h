#pragma once

#include <cstddef>
#include <expected>

#include "hyle/graph/executable.h"

namespace hyle::inference {

// Cold facts for one concrete published output. Resources and their owners
// remain with the original compile environment; generated output addresses
// are still obtained from GraphOutput after successful completion.
struct PreparedOutputFacts final {
  graph::ValueId value{};
  compute::TensorDesc description{};
  graph::StorageDomainId storage{};
  graph::OutputOwnership ownership = graph::OutputOwnership::kCaller;

  bool caller_owned() const noexcept {
    return ownership == graph::OutputOwnership::kCaller;
  }
};

// Pass the Executable and report from the same compile result, or the same
// selected exact child. Static default-route compilation is already exact.
// A shape-domain parent has no single concrete output description. Neither
// the backend name nor workspace/output flags determine output ownership.
inline Result<PreparedOutputFacts>
prepare_output(const graph::CompiledGraph &compiled,
               graph::ValueId value) noexcept {
  const auto &executable = compiled.executable;
  const auto &report = compiled.report;
  if (!executable || !report)
    return std::unexpected(Status::FailedPrecondition(
        "prepared output requires a valid executable and compile report"));
  if (!value)
    return std::unexpected(
        Status::InvalidArgument("prepared output value is invalid"));
  if (!executable.has_execution_route() || !report.has_execution_route() ||
      executable.is_shape_domain() || report.is_shape_domain())
    return std::unexpected(Status::FailedPrecondition(
        "prepared output requires a concrete execution route"));
  const auto signature = executable.specialization();
  const auto reported_signature = report.specialization();
  if (!signature || !reported_signature || signature != reported_signature)
    return std::unexpected(Status::InvalidArgument(
        "prepared output executable and report specializations differ"));

  PreparedOutputFacts result;
  result.value = value;
  bool published = false;
  for (std::size_t index = 0; index < executable.output_count(); ++index) {
    auto output = executable.output_id(index);
    if (!output) return std::unexpected(output.error());
    if (*output != value) continue;
    if (published)
      return std::unexpected(Status::InvalidArgument(
          "prepared output value has ambiguous published outputs"));
    auto ownership = executable.output_ownership(index);
    if (!ownership) return std::unexpected(ownership.error());
    result.ownership = *ownership;
    published = true;
  }
  if (!published)
    return std::unexpected(
        Status::NotFound("value is not a prepared executable output"));

  bool found = false;
  for (std::size_t index = 0; index < report.physical_value_count(); ++index) {
    auto physical = report.physical_value(index);
    if (!physical) return std::unexpected(physical.error());
    if (physical->value != value || !physical->external_output) continue;
    if (found)
      return std::unexpected(Status::InvalidArgument(
          "prepared output value has ambiguous physical outputs"));
    result.description = physical->description;
    result.storage = physical->storage;
    found = true;
  }
  if (!found)
    return std::unexpected(
        Status::NotFound("prepared output has no physical output report"));
  return result;
}

} // namespace hyle::inference
