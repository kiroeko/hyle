#pragma once

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "glm_shared_vocabulary.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/weight_import.h"

// Model-local original Flash layer45 MoE input. One read-only mapping retains
// all288 experts, without decoding them or keeping a full floating shadow.
// The private binary catalogue is emitted beside its authoritative JSON by
// exact-range acquisition; its compile-time identity authenticates role order.
namespace glm_original_moe_roles {
namespace c = hyle::compute;
namespace m = hyle::mem;
namespace shared = glm_shared_vocabulary;
inline constexpr std::string_view kRepository = shared::kRepository;
inline constexpr std::string_view kRevision = shared::kRevision;
inline constexpr std::int32_t kExpertDomain = 288;
inline constexpr std::size_t kResidentCapacity = 8, kRawRoles = 1736;
inline constexpr std::int64_t kHidden = 4096, kIntermediate = 2048;
inline constexpr std::size_t kCodeBytes = 8388608, kScaleBytes = 2048;
inline constexpr std::size_t kOriginalBytes = 7277059200ULL;
inline constexpr std::size_t kIndexBytes = 64 + kRawRoles * 16;
// Filled only after root's completed acquisition. Empty never accepts input.
inline constexpr std::string_view kIndexSha256 = "";
enum class Leg : std::size_t { kGate, kUp, kDown };
inline std::size_t index(Leg leg) {
  const auto result = static_cast<std::size_t>(leg);
  if (result >= 3) throw std::runtime_error("unknown original GLM MoE leg");
  return result;
}
inline std::pair<std::int64_t, std::int64_t> geometry(Leg leg) {
  (void)index(leg);
  return leg == Leg::kDown ? std::pair{kHidden, kIntermediate} : std::pair{kIntermediate, kHidden};
}
inline c::TensorDesc shared_description(Leg leg) {
  const auto [outputs, reduction] = geometry(leg);
  return shared::take(c::float8_weight_description(reduction, outputs,
      c::Float8ScaleMode::kFloat32Block128), "original GLM shared FP8 description");
}
inline c::TensorDesc resident_description(Leg leg) {
  const auto [outputs, reduction] = geometry(leg);
  return shared::take(c::float8_grouped_weight_description(kResidentCapacity, outputs, reduction),
      "original GLM resident FP8 description");
}
inline c::TensorDesc router_description() {
  return shared::take(c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t, 2>{kExpertDomain, kHidden}), "original GLM router description");
}
inline c::TensorDesc bias_description() {
  return shared::take(c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 1>{kExpertDomain}), "original GLM bias description");
}
struct Selection final {
  std::vector<std::int32_t> globals;
  std::array<std::int32_t, kExpertDomain> map;
};
inline Selection select(std::span<const std::int32_t> actual_ids) {
  if (actual_ids.empty() || actual_ids.size() > kResidentCapacity)
    throw std::runtime_error("original GLM selection needs actual1x8 global IDs");
  Selection result;
  result.map.fill(-1);
  result.globals.reserve(actual_ids.size());
  for (const auto global : actual_ids) {
    if (global < 0 || global >= kExpertDomain)
      throw std::runtime_error("actual GLM expert ID outside original0..287 domain");
    result.globals.push_back(global);
  }
  std::ranges::sort(result.globals);
  result.globals.erase(std::unique(result.globals.begin(), result.globals.end()), result.globals.end());
  for (std::size_t local = 0; local < result.globals.size(); ++local)
    result.map[std::size_t(result.globals[local])] = std::int32_t(local);
  return result;
}

class Data final {
 public:
  static Data load(const std::filesystem::path &directory) {
    if (kIndexSha256.size() != 64)
      throw std::runtime_error("original GLM MoE catalogue is not pinned");
    auto catalogue = shared::take(m::FileMapping::open((directory / "catalog.bin").string().c_str()),
        "map original GLM MoE catalogue");
    if (catalogue.size() != kIndexBytes)
      throw std::runtime_error("original GLM MoE catalogue extent differs");
    const auto raw = shared::take(catalogue.bytes(), "original GLM MoE catalogue bytes");
    if (shared::detail::mapped_sha256(raw) != kIndexSha256)
      throw std::runtime_error("original GLM MoE catalogue SHA256 differs");
    constexpr std::string_view magic = "HYGLMM01";
    for (std::size_t i = 0; i < magic.size(); ++i)
      if (raw[i] != std::byte(static_cast<unsigned char>(magic[i])))
        throw std::runtime_error("original GLM MoE catalogue magic differs");
    if (u32(raw, 8) != 1 || u32(raw, 12) != kRawRoles ||
        u64(raw, 16) != kOriginalBytes || u64(raw, 24) != 0)
      throw std::runtime_error("original GLM MoE catalogue version/count/extent differs");
    Data result;
    for (std::size_t role = 0; role < kRawRoles; ++role) {
      const auto offset = u64(raw, 64 + role * 16);
      const auto bytes = u64(raw, 72 + role * 16);
      if (offset > kOriginalBytes || bytes > kOriginalBytes - offset || bytes != expected_bytes(role))
        throw std::runtime_error("original GLM MoE role geometry/range differs");
      result.ranges_[role] = {static_cast<std::size_t>(offset), static_cast<std::size_t>(bytes)};
    }
    // Exact coverage rules out overlaps, holes, unrelated payload and offset
    // aliasing, while the pinned order gives every range its original role.
    auto ordered = result.ranges_;
    std::ranges::sort(ordered, {}, &Range::offset);
    std::size_t covered = 0;
    for (const auto &range : ordered) {
      if (range.offset != covered) throw std::runtime_error("original GLM MoE catalogue has overlap or holes");
      covered += range.bytes;
    }
    if (covered != kOriginalBytes) throw std::runtime_error("original GLM MoE catalogue does not cover the bundle");
    result.mapping_ = shared::take(m::FileMapping::open((directory / "roles.bin").string().c_str()),
        "map original GLM MoE bundle");
    if (result.mapping_.size() != kOriginalBytes)
      throw std::runtime_error("original GLM MoE bundle extent differs");
    constexpr char hex[] = "0123456789abcdef";
    std::string expected(64, '0');
    for (std::size_t i = 0; i < 32; ++i) {
      const auto byte = std::to_integer<unsigned>(raw[32 + i]);
      expected[i * 2] = hex[byte >> 4u];
      expected[i * 2 + 1] = hex[byte & 15u];
    }
    // One bounded-memory whole-bundle pass. Per-role payload hashes live in
    // acquisition's JSON; do not read/hash the same7.28GB a second time here.
    if (shared::detail::mapped_sha256(shared::take(result.mapping_.bytes(), "original GLM MoE bundle bytes")) != expected)
      throw std::runtime_error("original GLM MoE bundle SHA256 differs");
    result.decode_small();
    result.prepare_shared();
    return result;
  }
  const std::vector<std::uint16_t> &router() const noexcept { return router_; }
  const std::vector<float> &bias() const noexcept { return bias_; }
  std::span<const std::byte> router_bytes() const { return bytes(0); }
  std::span<const std::byte> bias_bytes() const { return bytes(1); }
  std::span<const std::byte> shared_bytes(Leg leg, bool scales) const {
    return bytes(2 + index(leg) * 2 + std::size_t(scales));
  }
  m::ConstBufferView shared_view(Leg leg, bool scales) const {
    return view(2 + index(leg) * 2 + std::size_t(scales));
  }
  std::span<const std::byte> expert_bytes(Leg leg, std::int32_t global, bool scales) const {
    return bytes(expert_index(leg, global, scales));
  }
  m::ConstBufferView expert_view(Leg leg, std::int32_t global, bool scales) const {
    return view(expert_index(leg, global, scales));
  }
  std::span<const std::byte> shared_payload(Leg leg) const {
    auto mapped = shared::take(shared_[index(leg)].view().map_host(), "map original GLM shared canonical bytes");
    const auto result = mapped.bytes();
    shared::check(mapped.close(), "close original GLM shared canonical mapping");
    return result;
  }
 private:
  struct Range final { std::size_t offset = 0, bytes = 0; };
  m::FileMapping mapping_;
  std::array<Range, kRawRoles> ranges_;
  std::vector<std::uint16_t> router_;
  std::vector<float> bias_;
  std::array<m::Buffer, 3> shared_;

  static std::uint32_t u32(std::span<const std::byte> raw, std::size_t offset) {
    std::uint32_t value = 0;
    for (std::size_t byte = 0; byte < 4; ++byte)
      value |= std::to_integer<std::uint32_t>(raw[offset + byte]) << (8 * byte);
    return value;
  }
  static std::uint64_t u64(std::span<const std::byte> raw, std::size_t offset) {
    std::uint64_t value = 0;
    for (std::size_t byte = 0; byte < 8; ++byte)
      value |= std::to_integer<std::uint64_t>(raw[offset + byte]) << (8 * byte);
    return value;
  }
  static std::size_t expected_bytes(std::size_t role) {
    if (role == 0) return std::size_t(kExpertDomain) * std::size_t(kHidden) * 2;
    if (role == 1) return std::size_t(kExpertDomain) * 4;
    return role % 2 == 0 ? kCodeBytes : kScaleBytes;
  }
  static std::size_t expert_index(Leg leg, std::int32_t global, bool scales) {
    if (global < 0 || global >= kExpertDomain)
      throw std::runtime_error("original GLM expert view outside0..287 domain");
    return 8 + std::size_t(global) * 6 + index(leg) * 2 + std::size_t(scales);
  }
  std::span<const std::byte> bytes(std::size_t role) const {
    const auto &range = ranges_.at(role);
    return shared::take(mapping_.bytes(), "original GLM MoE mapped bytes").subspan(range.offset, range.bytes);
  }
  m::ConstBufferView view(std::size_t role) const {
    const auto &range = ranges_.at(role);
    return shared::take(mapping_.view(range.offset, range.bytes), "original GLM MoE mapped role view");
  }
  void decode_small() {
    const auto raw_router = router_bytes(), raw_bias = bias_bytes();
    router_.resize(raw_router.size() / 2);
    for (std::size_t i = 0; i < router_.size(); ++i) {
      router_[i] = std::uint16_t(std::to_integer<unsigned>(raw_router[2 * i]) |
          (std::to_integer<unsigned>(raw_router[2 * i + 1]) << 8u));
      if (!std::isfinite(std::bit_cast<float>(std::uint32_t{router_[i]} << 16u)))
        throw std::runtime_error("original GLM BF16 router is nonfinite");
    }
    bias_.resize(kExpertDomain);
    for (std::size_t i = 0; i < bias_.size(); ++i) {
      bias_[i] = std::bit_cast<float>(u32(raw_bias, i * 4));
      if (!std::isfinite(bias_[i])) throw std::runtime_error("original GLM routing bias is nonfinite");
    }
  }
  void prepare_shared() {
    for (std::size_t slot = 0; slot < 3; ++slot) {
      const auto leg = static_cast<Leg>(slot);
      const auto [outputs, reduction] = geometry(leg);
      const auto code_type = shared::take(c::TensorDesc::dense(c::DataType::kFloat8E4M3FN,
          std::array{outputs, reduction}), "original GLM shared codes");
      const auto scale_type = shared::take(c::TensorDesc::dense(c::DataType::kFloat32,
          std::array{outputs / 128, reduction / 128}), "original GLM shared scales");
      const auto description = shared_description(leg);
      const auto extent = shared::take(description.required_bytes(), "original GLM shared canonical extent");
      shared_[slot] = shared::take(m::Buffer::create(m::system_resource(), extent, 64),
          "original GLM shared canonical host bank");
      const auto codes = shared::take(c::ConstTensorView::create(code_type, shared_view(leg, false)),
          "original GLM shared code source");
      const auto scales = shared::take(c::ConstTensorView::create(scale_type, shared_view(leg, true)),
          "original GLM shared scale source");
      auto target = shared::take(c::TensorView::create(description, shared_[slot].view()),
          "original GLM shared canonical destination");
      shared::check(c::import_float8_block128_weight(codes, scales, target), "import original GLM shared FP8");
      const auto packed = shared_payload(leg), code_bytes = shared_bytes(leg, false), scale_bytes = shared_bytes(leg, true);
      if (packed.size() != code_bytes.size() + scale_bytes.size() ||
          !std::equal(code_bytes.begin(), code_bytes.end(), packed.begin()) ||
          !std::equal(scale_bytes.begin(), scale_bytes.end(), packed.begin() + std::ptrdiff_t(code_bytes.size())))
        throw std::runtime_error("original GLM shared import changed code/scale bytes");
    }
  }
};
using ReadonlyRole = shared::ReadonlyRole;
struct Roles final {
  std::shared_ptr<const Data> source;
  ReadonlyRole router, bias;
  std::array<ReadonlyRole, 3> shared;
};
inline Roles bind(std::shared_ptr<const Data> source, const c::StorageOwner &owner) {
  if (!source || !owner) throw std::runtime_error("original GLM MoE needs original data and actual storage owner");
  Roles result;
  result.source = std::move(source);
  const auto ready = [&](std::string_view name, const c::TensorDesc &description,
      std::span<const std::byte> raw) {
    const auto extent = shared::take(description.required_bytes(), "original GLM MoE immutable extent");
    if (raw.size() != extent) throw std::runtime_error("original GLM MoE immutable payload extent differs");
    auto bank = shared::take(m::Buffer::create(owner.ref(), extent, 256), "original GLM MoE immutable bank");
    shared::check(bank.view().write(raw), "original GLM MoE once-only upload");
    return ReadonlyRole{name, description, owner,
        shared::take(owner.adopt_buffer(std::move(bank)), "original GLM MoE readonly lease")};
  };
  result.router = ready("original GLM BF16 router", router_description(), result.source->router_bytes());
  result.bias = ready("original GLM F32 correction bias", bias_description(), result.source->bias_bytes());
  constexpr std::array<std::string_view, 3> names{
      "original GLM shared gate", "original GLM shared up", "original GLM shared down"};
  for (std::size_t leg = 0; leg < 3; ++leg)
    result.shared[leg] = ready(names[leg], shared_description(static_cast<Leg>(leg)),
        result.source->shared_payload(static_cast<Leg>(leg)));
  return result;
}
} // namespace glm_original_moe_roles
