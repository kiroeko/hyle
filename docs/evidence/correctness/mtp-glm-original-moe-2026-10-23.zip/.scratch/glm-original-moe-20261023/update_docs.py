"""Update current MTP facts only after the six related cases pass."""
from pathlib import Path
import argparse
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
p=argparse.ArgumentParser();p.add_argument('--runs',type=int,nargs='+',required=True);args=p.parse_args()
runs=[read(S/f'checks{i}/summary.json') for i in args.runs]
assert sum(r['tests'] for r in runs)==6
assert all(r['process']['exit']==0 and not r['process']['timed_out'] and
    not any(r[k] for k in ('failures','errors','disabled','skips')) for r in runs)
cases=[case for run in runs for case in run['cases']]
assert sorted((case['properties'].get('original_roles',case['properties'].get('original_role_count')),case['properties']['actual_submissions']) for case in cases)==[
    ('1762','49'),('1762','49'),('26','29'),('26','29'),('83','37'),('83','37')]
assert sum(int(case['properties']['actual_submissions']) for case in cases)==230
path=R/'docs/developer/current-work.md';text=path.read_text(encoding='utf-8-sig')
def change(old,new):
    global text
    assert text.count(old)==1,old
    text=text.replace(old,new)
change('GLM显式选PowerOfTwo／floor1e-4。','GLM indexer选PowerOfTwo／floor1e-4，原MLA／MoE选Divide／floor1e-10。')
change('GLM官方26原角色已进入完整NextN输入／query／indexer、原attention／postnorm及共享全词表embedding／head／norm，真实预测ID反馈和接受后追赶CPU／CUDA通过；',
       'GLM Flash官方layer45全部1760原角色及共享embedding／head2角色已进入完整NextN，含原MoE／FFN；完整288域路由、所选原FP8专家有界供给、真实预测ID反馈和接受后追赶CPU／CUDA通过；')
change('Q27／Q24单次完整量化head、GLM Flash原26参数、attention及全词表预测反馈、DSpark全部81份sidecar原角色已有列明检查。下一步继续GLM原MoE／FFN等剩余角色、真实target taps、Pro实际几何与已确认适用量化组合。',
       'Q27／Q24单次完整量化head、GLM Flash完整原NextN与共享全词表、DSpark全部81份sidecar原角色已有列明检查。下一步继续真实target taps／verifier、Q27／Q24剩余原角色、Pro实际几何与已确认适用量化组合。')
start=text.index('**最近已验证进展**：');end=text.index('前批[DSpark原专家]',start)
text=text[:start]+'''**最近已验证进展**：[GLM原MoE／FFN](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)新增1736份原角色，补齐layer45全部1760份，加共享embedding／head共1762份、10,030,953,088B原始参数。实际288域sigmoid＋bias选Top8，以无bias分数除sum＋1e-20、乘一次2.5；原E4／F32 block128专家保down后施加路由权重及各处BF16存储边界。只读原文件保留完整专家域，CPU双代／CUDA双槽仅供给实际所选8专家；每槽201,377,024B，无整份F32专家权重副本。

CPU／CUDA新旅程各49次实际Graph（28次逻辑调用、20次额外专家阶段、1次冷K/V准备）；前批26角色与DSpark83角色回归各一对，共6项、230次Graph，全通过且无跳过。GLM与DSpark共用纯冷图切分，均沿普通Graph／Invocation和实际租约执行，没有新增执行器或公共算子类型。首轮全量局部MoE投影74,016值、原attention和全词表参考及各次真实BF16边界继续检查；后续投影固定采样。target hidden／verifier、初始历史仍为显式生成边界，完整target、任务质量及自然接受率未代签；本轮没有新TPS或物理内存／显存峰值，页末AV表保持原样。[前批原attention](../evidence/correctness/mtp-glm-original-attention-2026-10-23.json)的BF16吸收bank和一次冷准备继续复用。

'''+text[end:]
start=text.index('- **GLM-Flash**：');end=text.index('- **DSpark**：',start)
text=text[:start]+'''- **GLM-Flash**：[1762原角色](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)覆盖完整layer45 NextN与共享全词表，原input／query／indexer／MLA／postnorm／MoE／sharednorm均接入。实际全288域Top8经同代三原FP8 bank＋map供给；两阶段普通Graph成功后，沿17状态＋epoch和一个StateHead发布接受0／1／2，skip／catchup／epoch8 seed及真实ID反馈已有CPU／CUDA检查。indexer保PowerOfTwo／floor1e-4，MLA／MoE保Divide／floor1e-10；原BF16 K/V只冷准备一次，F32 cache载体仅存实际BF16 latent扩宽。生成参数的[43→44→NextN](../evidence/correctness/mtp-encoded-state-2026-10-23.json)34资源＋epoch组合旧证据保留。target hidden／verifier与初始历史仍生成，原45层target、Pro几何、其它量化及自然接受率未完成，不把载体等同vendor页ABI。
'''+text[end:]
change('原GLM26角色与attention／共享LM反馈、DSpark83角色已接，下一步MoE／FFN等剩余角色／真实target taps／Pro几何与已确认量化组合，最后完整性能对照',
       'GLM完整原NextN＋共享词表1762角色与DSpark83角色已接，下一步真实target taps／其余原角色／Pro几何与已确认量化组合，最后完整性能对照')
tail=text[text.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest()==read(S/'before.json')['protected_performance_tail_sha256']
path.write_text(text,encoding='utf-8',newline='\n')

path=R/'docs/implementation/model-operators.md';text=path.read_text(encoding='utf-8-sig')
start=text.index('| GLM-5.3-Flash | KDA／conv');end=text.index('\n',start)
text=text[:start]+'''| GLM-5.3-Flash | KDA／conv、NoPE MLA、index keys／gates、已pool缓存和未pool尾窗、偏移／位置 | [完整原NextN](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)已接layer45全部1760原角色及全V154880共享embedding／head，共1762份。原input／indexer／MLA／原288域MoE保真实存储边界；两阶段普通Graph与原17状态＋epoch、接受0／1／2、skip／catchup／epoch8 seed及实际ID反馈CPU／CUDA通过。默认ue8m0 cache及生成参数的target43→44→NextN共34资源＋epoch组合保留；真实target taps／verifier、Pro几何和其它确认量化未完成 |'''+text[end:]
start=text.index('GLM官方14原参数共');end=text.index('\n\n## 正式版 DeepSeek',start)
text=text[:start]+'''GLM Flash [完整原NextN接线](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)与固定官方两份header逐角色差集为空：layer45为1760份、7,493,399,168B，另有全V154880 BF16 embedding／独立head两份，共1762份、10,030,953,088B。角色数包含量化scale，不是算子或kernel数；本轮只实际执行各次路由所选专家，不把完整288域等同288专家均已计算。

原indexer的wk／wq_b／compress_gate保BF16，norm／bias／APE／weights_proj精确扩宽；cache保PowerOfTwo／floor1e-4。原MLA与MoE投影保动态A128 Divide／floor1e-10及原E4／F32 block128权重。原kv_b只做一次普通冷Graph准备共享BF16 K／V，退掉原device临时bank；64头／NoPE256／latent512／value256、scale1/16不变。F32 cache载体只写BF16 latent精确扩宽；postnorm用实际F32残差和，另存BF16残差返回，见[原attention](../evidence/correctness/mtp-glm-original-attention-2026-10-23.json)。

原MoE为288域Top8：BF16输入／router→F32 logits→sigmoid；原F32 bias只影响选择，无bias分数除以sum＋1e-20并乘一次2.5。选定scale-in-topk合同，不宣称与所有vendor runner逐bit等价。原gate／up、clip10／SiLU activation、down后乘路由权重、sum8与shared merge保BF16存储边界。每代最多8个原专家的codes／scales原样组成三bank＋global map，CPU两代／CUDA两device与pinned槽每槽201,377,024B；同实际资源、owner及queue，只有8个I32 ID回读以安排供给，激活和状态通过实际租约传递。GLM与DSpark共用纯冷图切分；不复制执行器、逐token构图或展开整份F32专家权重。

CPU／CUDA新旅程各49次Graph，前批26角色各29及DSpark83角色各37回归通过，共6项230次。完整词表sharednorm→BF16store→单次BFloatLinearF32→TopK→pending反馈继续复用[共享LM](../evidence/correctness/mtp-glm-shared-lm-2026-10-23.json)。17状态＋epoch接受0／1／2、旧结果及seed／skip／catchup已核；生成参数的34资源target组合见[编码状态证据](../evidence/correctness/mtp-encoded-state-2026-10-23.json)。真实target taps／verifier与初始历史仍为显式生成边界；有限局部数值和容量检查不代签完整原模型、全部量化、任务质量、自然接受率、TPS或物理显存峰值。'''+text[end:]
path.write_text(text,encoding='utf-8',newline='\n')
print('UPDATED MTP current facts; protected AV performance tail unchanged')
