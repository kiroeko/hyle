"""Publish actual original-MoE results; never archive the weight bundle."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
D=R/'docs/evidence/correctness'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p)
    with p.open('rb') as stream: sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),bytes=p.stat().st_size,sha256=sha)
def verify(row):
    actual=identity(R/row['path'])
    assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],row['path']

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--new-runs',type=int,nargs='+',required=True)
p.add_argument('--regression-runs',type=int,nargs='+',required=True)
p.add_argument('--link-attempt',type=int,required=True)
p.add_argument('--freeze',default='source')
args=p.parse_args()
indices=[*args.new_runs,*args.regression_runs]
runs=[read(S/f'checks{i}/summary.json') for i in indices]
image=read(S/f'tests-link{args.link_attempt}/ready.json')['image'];verify(image)
for run in runs:
    assert run['image']==image and run['process']['exit']==0 and not run['process']['timed_out']
    assert not any(run[k] for k in ('failures','errors','disabled','skips'))
new=[case for run in runs[:len(args.new_runs)] for case in run['cases']]
related=[case for run in runs[len(args.new_runs):] for case in run['cases']]
assert len(new)==2 and len(related)==4
for case in new:
    props=case['properties']
    assert props['original_roles']=='1762' and props['original_role_bytes']=='10030953088'
    assert props['actual_submissions']=='49'
assert sorted((case['properties'].get('original_roles',case['properties'].get('original_role_count')),case['properties']['actual_submissions']) for case in related)==[
    ('26','29'),('26','29'),('83','37'),('83','37')]
graph_count=sum(int(case['properties']['actual_submissions']) for case in [*new,*related])
assert graph_count==230
freeze_path=S/args.freeze/'freeze.json';freeze=read(freeze_path)
frozen=[*freeze.get('source',[]),*freeze.get('dependencies',[]),*freeze.get('files',[])]
assert len(frozen)>=8
for row in frozen:verify(row)
link_path=S/f'tests-link{args.link_attempt}/link-plan.json';link=read(link_path)
for row in link['inputs']:verify(row)
for row in link['compiled_records']:
    verify(row)
    if Path(row['path']).is_relative_to(S):
        compiled=read(row['path'])
        for row in (compiled['source'],compiled['object'],*compiled['dependencies']):verify(row)
acquisition=read(S/'original-moe/acquisition.json')
assert acquisition['complete'] and acquisition['original_roles']==1736
assert acquisition['role_payload_bytes']==acquisition['successful_request_body_bytes']==7277059200
verify(acquisition['typed_catalog']);verify(acquisition['catalog'])
before=read(S/'before.json');protected=before['protected_qwen_image'];verify(protected.get('image',protected))
text=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail=text[text.index('## 最新完整性能对比'):]
tail_hash=hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash==before['protected_performance_tail_sha256']
sources=[R/row['path'] for row in frozen]
sources.extend(R/rel for rel in ('docs/developer/current-work.md','docs/implementation/model-operators.md'))
metadata=[R/row['header']['path'] for row in acquisition['shards']]
files=set(sources+metadata)
files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in
    ('.h','.cc','.py','.json','.txt','.log','.xml','.ps1','.diff'))
files.add(S/'original-moe/catalog.bin')
files.discard(S/'publication.json')
archive=D/'mtp-glm-original-moe-2026-10-23.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
    for path in sorted(files):
        assert path.name!='roles.bin'
        zipped.write(path,path.relative_to(R).as_posix())
prior=[]
for folder in sorted(S.glob('checks*')):
    if (folder/'summary.json').is_file() and int(folder.name[6:]) not in indices:prior.append(read(folder/'summary.json'))
record=dict(date='2026-10-23',stage='BP',goal_complete=False,
    conclusion='Original Flash NextN layer45 MoE/FFN now joins the original input, indexer, attention and full vocabulary in the complete accepted-state journey on CPU/CUDA.',
    artifact=dict(repository=acquisition['repository'],revision=acquisition['revision'],original_roles=1762,
        original_role_bytes=10030953088,additional_original_roles=1736,additional_original_payload_bytes=7277059200,
        layer45_roles=1760,layer45_original_bytes=7493399168,shared_embedding_head_roles=2,
        acquisition=acquisition,weight_bodies_archived=False),
    implementation=dict(
        routing='Original BF16 router and F32 correction bias select top8 across the full288 domain. Weights use unbiased sigmoid scores divided by sum+1e-20 and one explicit routed scale2.5. Hyle stable sorted ties and selected scale-in-topk storage contract are explicit; no universal vendor bit-identity claim.',
        math='Original E4/F32 block128 shared and routed weights consume actual BF16 predecessors through dynamic A128 Divide/floor1e-10. Gate/up, clipping/SiLU activation, down post-weight, sum8 and shared merge keep explicit original BF16 stores. Route weight is applied after down, not before activation quantization.',
        supply='One read-only original mapping. Shared/router/bias banks bind once; actual IDs choose unchanged original code/scale subranges for E8 compact banks and I32 global map. Two-generation CPU supply or two CUDA device/pinned slots are bounded; no whole F32 weight expansion.',
        capacity=dict(expert_domain=288,resident_capacity=8,slot_bytes=201377024,two_slot_device_bytes=402754048,two_slot_pinned_bytes=402754048,physical_peak_measured=False),
        graph='One semantic Fragment is cold-cut at the actual router frontier into2 ordinary Graphs, using the same Context/queue and direct immutable leases. The pure splitter is shared with the existing3-frontier DSpark consumer. No additional executor, host activation computation, provider branch or per-token graph construction.',
        state='All phases finish before publishing the complete state through the existing atomic Head; accepted0/1/2, target bonus, skip, seed, direct/journal catchup and old-result retention remain.'),
    validation=dict(tests=6,failures=0,errors=0,skips=0,graph_submissions=graph_count,
        new_graph_submissions=98,related_graph_submissions=132,new_cases=new,related_cases=related,
        results=[identity(S/f'checks{i}/summary.json') for i in indices],
        source_freeze=identity(freeze_path),linked_inputs=identity(link_path),
        host_translation_units=2,host_compile_attempts=len(list(S.glob('compile*/*/plan.json'))),
        prior_attempts=prior,SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
    limitations=['Finite Windows CPU/CUDA integration, not all systems/shapes/codecs.',
        'Target hidden/taps/verifier and initial history remain explicit generated boundaries; not the full trained45-layer target model.',
        'Local numerical checks use authenticated weights and actual stored predecessors; not full task quality or natural acceptance evidence.',
        'Full first-episode projections and deterministic later sampling do not prove all possible inputs.',
        'Other original target taps, actual Pro geometry and confirmed quantization combinations remain unfinished.',
        'No new TPS/loading or physical memory/VRAM peak claim; latest AV comparison is unchanged.',
        'MTP, images and the broader goal remain incomplete.'],
    remaining='Real target taps/verifier, remaining Q27/Q24 original roles, actual Pro geometry and confirmed applicable quantization combinations; final necessary regressions and complete ordinary/MTP performance comparison before images.',
    prior_attempts=prior,final_image=image,sources=[identity(path) for path in sources],
    performance_tail_sha256=tail_hash,archive=identity(archive),archive_items=len(files))
destination=D/'mtp-glm-original-moe-2026-10-23.json';assert not destination.exists()
destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
publication=dict(evidence=identity(destination),archive=identity(archive))
(S/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(**publication,tests=6,graphs=graph_count)))
