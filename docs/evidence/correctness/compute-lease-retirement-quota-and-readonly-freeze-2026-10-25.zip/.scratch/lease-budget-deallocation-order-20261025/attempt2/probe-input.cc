#include <array>
#include <cstdio>
#include <utility>
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/detail/lease_access.h"

namespace c = hyle::compute;
namespace m = hyle::mem;
class ObservedResource final : public m::MemoryResource {
public:
  const c::ResourceBudget *budget = nullptr;
  std::size_t observed = SIZE_MAX;
  bool admitted_during_free = false;
  std::string_view name() const noexcept override { return "deallocation-order-witness"; }
  m::MemoryProperties properties() const noexcept override { return m::system_resource().properties(); }
  hyle::Result<m::ResourceAllocation> allocate(std::size_t bytes, std::size_t alignment) noexcept override {
    return m::system_resource().resource().allocate(bytes, alignment);
  }
  void deallocate(m::ResourceAllocation allocation) noexcept override {
    // The original backing has not yet been returned to the upstream resource.
    const auto ref = m::MemoryResourceRef(*this);
    observed = budget->usage(ref)->live_bytes;
    auto nested = budget->reserve(ref, 512);
    admitted_during_free = bool(nested);
    m::system_resource().resource().deallocate(allocation);
  }
};
int main() {
  bool correct = true;
  for (const bool retain : {false, true}) {
    ObservedResource resource;
    const auto ref = m::MemoryResourceRef(resource);
    const std::array limits{c::ResourceBudgetLimit{ref, 512}, c::ResourceBudgetLimit{m::system_resource()}};
    const std::array nominated{ref};
    auto budget = c::ResourceBudget::create({.limits = limits}, nominated, 512);
    if (!budget) return 2;
    resource.budget = &*budget;
    auto pool = c::LeasePool::create(ref, 512, {.max_blocks = 1, .resource_budget = *budget});
    if (!pool) return 3;
    auto writer = pool->allocate(16);
    if (!writer) return 4;
    auto ready = writer->publish();
    if (!ready) return 5;
    if (retain) {
      const auto status = c::detail::LeaseAccess::retain_budget(*ready, ref, *budget);
      if (!status.ok()) {
        std::printf("retain setup rejected: %.*s\n", int(status.message().size()), status.message().data());
        return 6;
      }
    }
    *pool = {};
    ready->reset();
    std::printf("retained=%d live_at_original_deallocate=%zu nested_admitted=%d after=%zu\n",
        int(retain), resource.observed, int(resource.admitted_during_free), budget->usage(ref)->live_bytes);
    correct = correct && resource.observed == 512 && !resource.admitted_during_free && budget->usage(ref)->live_bytes == 0;
  }
  return correct ? 0 : 1;
}
