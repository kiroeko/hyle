# Retire identity before storage; retire charge after storage

2026-10-25, root, proposal only. No product edits or claim of correction.

The corrected host resource delegates its real allocation/map/unmap to the
system resource. Both direct LeasePool charge and same-scope retained/imported
charge fail the finite witness: at entry to actual backing deallocate, live is
already zero and another full 512-byte reservation succeeds. QuotaAllocator's
Reservation contract explicitly requires external storage to die first.
Initial attempts preserve the fixture's missing host mapping error separately.

The current LeaseDomain order intentionally destroys retained accounting before
backing so a recycled canonical address is not mistaken for the old allocation.
Only reordering charge/backing fixes the direct case, leaving SharedBackingRecord
and native retained-owner destruction wrong. Do not weaken backing deduplication.

Minimum proposed private mechanism:

1. Add an internal move-only retired accounting handle, retaining the existing
   SharedBackingRecord and quota without its lookup authority. No allocation at
   retirement; existing active SharedBackingReservation remains one pointer.
2. A record counts active accounting holders and retiring holders separately.
   Domain teardown transfers each active token into a retiring token under the
   original lookup lock. When active count reaches zero, unlink the identity.
   Keep the quota until both active and retiring counts are zero. Never hold
   that lock while freeing storage or a provider owner.
3. Move the existing retained entries/direct charge into local guards without
   new allocation, and withdraw lookup authority first. Preserve the original
   order: destroy backing/domain and sized-free domain metadata while its
   resource owner is still retained, then release that owner (Apple can keep
   the actual array here), and only then release direct/deferred charges.
   The moved vector's allocator still follows its original borrowed lifetime;
   its budgeted backing retains its scope until sized-free completion.
4. Existing retained entries can hold their retiring handle at teardown so no
   fallible allocation or vector growth is introduced. Concurrent aliases
   entering teardown must each retain their charge until their actual owner
   release completes; taking the charge only from the last active token is
   insufficient when another alias is still in a slow deallocator.

Finite checks: direct and retained same-scope deallocator witness; two aliases
with controlled overlapping retirement plus original address reuse; provider
owner release callback still sees charge; original same-scope dedup, quota
rejection, actual Completion retirement and default lease neighbors. No GPU,
SDK rebuild, broad model matrix, physical-VRAM or throughput claim.
