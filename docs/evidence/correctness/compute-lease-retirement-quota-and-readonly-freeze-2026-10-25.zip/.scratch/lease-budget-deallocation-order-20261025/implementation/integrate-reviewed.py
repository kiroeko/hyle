from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent
root = base.parents[2]
before = json.loads((base / 'before-pins.json').read_text('utf-8-sig'))
after = json.loads((base / 'after-pins.json').read_text('utf-8-sig'))
summary = json.loads((base / 'summary.json').read_text('utf-8-sig'))
assert summary['status'] == 'PASS_PRIVATE_FOUNDATION'
assert summary['results']['tests'] == '36' and summary['results']['failures'] == '0'
assert summary['results']['errors'] == '0'

def key(name):
    return name.replace('\\', '/')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def lf(data):
    return data.replace(b'\r\n', b'\n')

old_pins = {key(item['path']): item for item in before}
new_pins = {key(item['path']): item for item in after}
assert len(old_pins) == len(new_pins) == 10 and old_pins.keys() == new_pins.keys()
assert {key(item['path']): item['sha256'] for item in summary['changed']} == {
    name: item['sha256'] for name, item in new_pins.items()}
changes = []
for name, pin in old_pins.items():
    destination = root / name
    original = destination.read_bytes()
    assert len(original) == pin['bytes'] and digest(original) == pin['sha256'], name
    selected = (base / 'source' / name).read_bytes()
    assert len(selected) == new_pins[name]['bytes'] and digest(selected) == new_pins[name]['sha256'], name
    ending = b'\r\n' if b'\r\n' in original else b'\n'
    output = lf(selected).replace(b'\n', ending)
    changes.append((destination, output, dict(path=name,
        before_sha256=digest(original), after_sha256=digest(output), bytes=len(output),
        checked_private_raw_sha256=digest(selected),
        same_normalized_source_as_host_checked_private=True)))
for destination, output, _ in changes:
    destination.write_bytes(output)
result = dict(status='EXACT_REVIEWED_FOUNDATION_INTEGRATION',
              files=[item for _, _, item in changes],
              independently_reviewed='Domain destruction/allocator and payload owners, active-retiring record concurrency/ABA, immutable full-block freeze, original default and failure paths.',
              additional_build_or_GPU_run=False,
              limits='The two changed core TUs and four existing test TUs passed 36 selected host tests; no GPU/platform matrix or new throughput result. Preserve each canonical file line ending; all normalized sources match the checked frozen closure.')
(base / 'root-integration.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=result['status'], files=len(changes),
                     matched_checked_source=True, new_model_runs=0), indent=2))
