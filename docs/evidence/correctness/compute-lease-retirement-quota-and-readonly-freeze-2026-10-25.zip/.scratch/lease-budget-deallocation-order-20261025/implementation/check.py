from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
out=D/(sys.argv[1] if len(sys.argv)>1 else 'attempt1');out.mkdir(exist_ok=False)
a=b.args(R/'.scratch/inference-shared-requested-budget-20261025/attempt1/core/command.json');flags=[];skip=False
for f in a[1:]:
 if skip:skip=False;continue
 if f=='/sourceDependencies':skip=True;continue
 if f.lower().startswith(('/fo','/fd')) or f.lower().endswith(('.cc','.cpp')):continue
 flags.append(f)
flags=['/I'+str(D/'source/include'),*flags,'/I'+str(R/'tests/graph')]
env=b.environment(a[0]);objs=[]
sources=[('budget','src/compute/resource_budget.cc'),('leases','src/compute/resource_leases.cc'),
 ('lease-tests','tests/compute/resource_leases_test.cc'),('shared-tests','tests/compute/shared_backing_budget_test.cc'),
 ('retained-tests','tests/compute/retained_lease_budget_test.cc'),('owner-tests','tests/graph/constant_artifact_cache_test.cc')]
before=[b.pin(D/'source'/f) for _,f in sources];b.save(out/'before-source.json',before)
for label,name in sources:
 folder=out/label
 b.execute([a[0],*flags,'/Gy',str(D/'source'/name),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(folder/'unit.obj')],folder,env,120)
 objs.append(str(folder/'unit.obj'))
assert before==[b.pin(D/'source'/f) for _,f in sources]
old=b.args(R/'.scratch/inference-request-sampling-20261025/host3/link/command.json');args=[];removed=[]
for f in old[1:]:
 n=f.lower().replace('\\','/')
 if n.endswith(('/cpu-budget-fix1/budget/budget.obj','/cpu-budget-fix1/leases/leases.obj','/host3/host.obj')):removed.append(f);continue
 if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
 args.append(f)
assert len(removed)==3,removed
args+=objs+[str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib')]
b.execute([old[0],*args,'/OPT:REF','/OUT:'+str(out/'link/checks.exe'),'/IMPLIB:'+str(out/'link/checks.lib')],out/'link',env,120)
native=R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,out/'link'/native.name)
env=os.environ.copy();env['PATH']=b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
b.execute([str(out/'link/checks.exe'),'--gtest_filter=ResourceLeases.*:SharedBackingBudget.*:SharedRequestedBudget.*:RetainedLeaseBudget.*:StorageOwner.*','--gtest_output=xml:'+str(out/'results.xml')],out/'run',env,60)
b.save(out/'ready.json',dict(image=b.pin(out/'link/checks.exe'),native=b.pin(native),refreshed_core_TUs=2,test_TUs=4,removed=removed,source=before,GPU=0,SDK_full_build=0))
