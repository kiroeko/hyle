"""Package the finite host proof; never builds or runs a consumer."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

R = Path.cwd()
D = Path(__file__).resolve().parent
H = D.parent
PUBLIC = R / 'docs/evidence/correctness'
STEM = 'compute-lease-retirement-quota-and-readonly-freeze-2026-10-25'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def digest(data):
    return hashlib.sha256(data).hexdigest()

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=digest(p.read_bytes()))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')

sources = read(D / 'after-pins.json')
integration = read(D / 'root-integration.json')
for item in sources:
    p = D / 'source' / item['path']
    assert pin(p)['sha256'] == item['sha256'] and p.stat().st_size == item['bytes']
for item in integration['files']:
    actual = R / item['path']
    private = D / 'source' / item['path']
    assert digest(actual.read_bytes()) == item['after_sha256']
    assert actual.read_bytes().replace(b'\r\n', b'\n') == private.read_bytes().replace(b'\r\n', b'\n')

result = ET.parse(D / 'attempt1/results.xml').getroot()
assert result.attrib['tests'] == '36' and result.attrib['failures'] == '0'
assert read(D / 'attempt1/run/process.json')['exit'] == 0
negative = []
for label in ('', 'attempt2', 'attempt3'):
    p = H / label / 'run'
    negative.append(dict(attempt=label or 'initial', process=read(p / 'process.json'),
                         stdout=(p / 'stdout.log').read_text()))
assert negative[2]['process']['exit'] == 1
assert 'retained=1 live_at_original_deallocate=0 nested_admitted=1' in negative[2]['stdout']

files = set()
for folder in ('before', 'source'):
    files.update(p for p in (D / folder).rglob('*') if p.is_file())
for name in ('before-pins.json', 'after-pins.json', 'source.patch', 'summary.json',
             'check.py', 'integrate-reviewed.py', 'root-integration.json', 'publish.py'):
    files.add(D / name)
for folder in (D / 'attempt1', H / 'compile', H / 'link', H / 'run',
               H / 'attempt2', H / 'attempt3'):
    files.update(p for p in folder.rglob('*') if p.is_file()
                 and p.suffix in ('.json', '.log', '.xml', '.cc'))
for name in ('initial-probe.cc', 'probe.cc', 'check.py', 'design.md'):
    files.add(H / name)
review = R / '.scratch/lease-readonly-freeze-20261025/independent-review.md'
if review.is_file():
    files.add(review)
assert not any(p.suffix.lower() in ('.exe', '.obj', '.dll', '.lib', '.exp', '.pdb') for p in files)
manifest = [pin(p) for p in sorted(files)]
manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
archive = PUBLIC / (STEM + '.zip')
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files):
        z.write(p, p.relative_to(R).as_posix())
    z.writestr('archive-manifest.json', manifest_data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        data = z.read(item['path'])
        assert len(data) == item['bytes'] and digest(data) == item['sha256']

proof = dict(
    schema_version=1,
    status='PASS_FINITE_CORE_CONTRACTS',
    scope='Actual backing retirement quota order and immutable full-block LeasePool::freeze; host core foundation only.',
    problem=dict(bytes=512, old_direct_and_retained='Both actual deallocator callbacks observed budget.live=0 before freeing original backing and successfully reserved another 512 bytes.',
                 original_failures=negative,
                 fixture_boundary='Initial and attempt2 retained paths lacked host-map support; their direct path is a valid negative witness. Only corrected attempt3 establishes both direct and retained failures.'),
    implementation=[
        'Last active shared-backing holder removes lookup identity; separate retiring holders retain charge until actual payload owners finish.',
        'Domain teardown preserves allocator lifetime: backing and Domain metadata, native payload owner, deferred charges/spill metadata, then independent actual allocator owner.',
        'Ordinary accounting token copy/reset semantics are unchanged. No lock is held across native/resource/allocator destruction.',
        'LeasePool::freeze consumes one unique full-block writer and pool root only on successful preflight, retains original identity and budget, leaves future read admission open and permanently rejects writer promotion.',
        'SharedBackingReservation remains one pointer; active and retiring generations cannot unlink each other.'
    ],
    validation=dict(tests=36, failures=0, skipped=0, suites=[dict(name=s.attrib['name'],tests=int(s.attrib['tests'])) for s in result],
                    core_translation_units=2, existing_test_translation_units=4,
                    run=pin(D / 'attempt1/run/process.json'), xml=pin(D / 'attempt1/results.xml'),
                    closure=read(D / 'attempt1/ready.json'), checked_sources=sources,
                    checks=read(D / 'summary.json')['checks']),
    integration=dict(record=pin(D / 'root-integration.json'), normalized_sources_match=True,
                     additional_build_or_run=False,
                     note='Root preserved canonical line endings; two test files have different raw line endings but identical normalized checked source.'),
    limits=[
        'No GPU, platform matrix, SDK rebuild, HTTP, trained-model quality or throughput measurement belongs to this core proof.',
        'Copies of one ResourceBudget scope aggregate selected actual resource rows; independent scopes are not implicitly merged.',
        'Engine shared-source wiring remains a separate private Batch1 slice. Original finite cache scope and cross-Model aggregate cache-source accounting are not complete in this proof.',
        'The later generic-freeze engine host/CUDA revalidation is separate from these 36 host checks.'
    ],
    archive={**pin(archive), 'crc_verified':True, 'member_hashes_verified':True,
             'members':len(manifest)+1, 'logical_bytes':sum(i['bytes'] for i in manifest)+len(manifest_data),
             'contains_binaries_or_model_payload':False})
target = PUBLIC / (STEM + '.json')
assert not target.exists()
save(target, proof)
save(D / 'publication.json', dict(json=pin(target), archive=pin(archive), members=len(manifest)+1,
                                crc_verified=True, member_hashes_verified=True))
print(json.dumps(read(D / 'publication.json'), indent=2))
