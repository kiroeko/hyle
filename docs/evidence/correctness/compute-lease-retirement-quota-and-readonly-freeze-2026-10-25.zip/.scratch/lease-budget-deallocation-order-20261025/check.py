from pathlib import Path
import importlib.util
import os

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_build',root/'.scratch/mtp-extraction-regression-20261024/check.py')
build = importlib.util.module_from_spec(spec); spec.loader.exec_module(build)
old = root/'.scratch/inference-shared-requested-budget-20261025/attempt1'
out = base/'attempt3'
out.mkdir(exist_ok=False)
original = build.args(old/'retained/command.json')
flags, skip = [], False
for arg in original[1:]:
    if skip: skip=False; continue
    if arg == '/sourceDependencies': skip=True; continue
    if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')): continue
    flags.append(arg)
env = build.environment(original[0])
build.execute([original[0],*flags,str(base/'probe.cc'),'/Fo'+str(out/'compile/probe.obj'),
    '/sourceDependencies',str(out/'compile/dependencies.json')],out/'compile',env,90)
command = build.args(old/'link/command.json')
args = []
for arg in command[1:]:
    normalized = arg.lower().replace('\\','/')
    if normalized.startswith(('/out:','/pdb:','/map:','/implib:')): continue
    if normalized.endswith(('/attempt1/backing/unit.obj','/attempt1/retained/unit.obj','/gtest_main.lib')): continue
    args.append(arg)
args.append(str(out/'compile/probe.obj'))
build.execute([command[0],*args,'/OUT:'+str(out/'link/probe.exe'),
    '/IMPLIB:'+str(out/'link/probe.lib')],out/'link',env,90)
env = os.environ.copy()
env['PATH'] = build.read(root/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
build.execute([str(out/'link/probe.exe')],out/'run',env,30)
