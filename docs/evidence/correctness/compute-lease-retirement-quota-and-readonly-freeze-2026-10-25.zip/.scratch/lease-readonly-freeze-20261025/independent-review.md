# Independent bounded source review

The proposed `LeasePool::freeze(WriteLease&&)` is the appropriate natural operation for Batch1, rather than a BackendKind restriction or another owner wrapper. No source mutation, compilation or execution in this review.

The implementation checks the original same domain, open domain, one live allocation, full backing range, ordinary writer, uniqueness/actual write retirement and terminal write success before any mutation. Success changes that original block to permanently readonly, removes both caller handles, releases only the pool root without closing future read admission, and preserves the original backing, budget and attached owner. Rejection keeps both arguments intact. A pool configured for more blocks is still safe when exactly one full-backing allocation is live; no remaining range can survive this transfer.

The new friendship grants the existing pool implementation access without changing object layout. No payload copy, allocation at freeze, permission inventory or extra executor is needed. The existing resource/context/allocator borrowing contract remains explicit, including cessation of all untracked writable aliases before freezing. Existing typed resource-owner attachments can still remain on the same domain.

This can replace the private Tensor system/CUDA detach branches and remove its provisional CPU/CUDA shared-entry guard. It must be combined with the separately reviewed deallocation-order fix before claiming quota remains charged throughout backing/provider-owner release. The three new tests are source-reviewed only here; they still need the planned combined host build.
