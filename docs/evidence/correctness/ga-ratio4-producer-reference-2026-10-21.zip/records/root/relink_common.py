from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];spec=importlib.util.spec_from_file_location('ratio4_link_helpers',P/'windows/build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];base_path=P/arm/'checks/link1/link-plan.json';base=c.read(base_path);patch=c.read(P/'common/checks/root-resources1/identity.json')
assert all(b.same(x) for x in base['inputs']);assert b.same(patch['source']) and b.same(patch['object'])
old=c.key(patch['replaced_object']['path']);assert sum(c.key(x['path'])==old for x in base['inputs'])==1
inputs=[patch['object'] if c.key(x['path'])==old else x for x in base['inputs']]
command=[patch['object']['path'] if c.key(x)==old else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
out=P/arm/'checks/link2';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'link.result.json').exists();image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),replacement=patch['object'],replaced=patch['replaced_object'],SDK_builds=0,NVCC_compiles=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print(arm,'LINKED',flush=True)
