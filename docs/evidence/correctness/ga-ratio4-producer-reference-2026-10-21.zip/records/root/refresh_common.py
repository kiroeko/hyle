from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('ratio4_common_helpers',P/'windows/build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
recipe_path=A/'decode-prepare-cost/cpu-regression/graph-resources-identity.json'
recipe=c.read(recipe_path);source=R/'src/graph/resources.cc';out=P/'common/checks/root-resources1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'compile.result.json').exists()
command=b.host_command(recipe['command'],source,'graph-resources',out)
frozen=b.identity(source)
c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe_path),replaced_object=recipe['object']))
env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
data=c.read(out/'graph-resources-deps.json')['Data'];deps=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]
assert all(b.same(x) for x in [frozen,*deps])
record=dict(source=frozen,object=b.identity(out/'graph-resources.obj'),command=command,replaced_object=recipe['object'],recipe=b.identity(recipe_path),dependencies=deps)
c.save(out/'identity.json',record);print(record['object'],flush=True)
