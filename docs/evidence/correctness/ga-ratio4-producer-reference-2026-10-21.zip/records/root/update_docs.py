from pathlib import Path
import json
R=Path.cwd();P=Path(__file__).resolve().parents[1];backup=P/'root/docs-before';backup.mkdir(exist_ok=True)
for arm in ('cpu','cuda','vulkan'):
 d=json.loads((P/arm/'validation/final2/receipt.json').read_text());assert d['passed'] and d['cases']==2
apple=json.loads((P/'apple/final-validation.json').read_text());assert apple['tests']==2 and apple['failed']==apple['skipped']==0
paths=['docs/developer/current-work.md','docs/user/compute.md','docs/implementation/model-operators.md']
updates={}
for name in paths:
 path=R/name;assert not (backup/path.name).exists();s=path.read_text(encoding='utf8');(backup/path.name).write_text(s,encoding='utf8');updates[name]=s
name=paths[0];s=updates[name]
s=s.replace('第8包进行中；GA BF16缓存评分／Top512／I32映射与同代状态已四端消费；下一项补ratio4 F32重叠压缩生产者','第8包进行中；GA ratio4 F32生产者→BF16缓存→评分选择／接受前缀已四端闭环；下一项补正式GA typed mHC组合')
old='**当前下一动作**：补正式GA ratio4的F32重叠压缩生产者，衔接真实BF16 indexcache与已有score／TopK消费者；核增量窗口、跨压缩边界与接受前缀后续算，随后继续mHC／路由／专家等精确组合。'
new='''**当前下一动作**：补正式GA typed mHC pre／post／head组合，再核route权重在down投影前施加的routed＋shared FFN。
第8能力包余项已收敛为四项：上述两项、GLM Flash混合MLX角色与资源、Quark FP8 side角色的精确轴／数学绑定；
依据与完成边界见本轮归档的`review/remaining-role-actions.json`。不把33条整制品未执行扩大为33个完整模型任务。
[ratio4生产者旅程](../evidence/correctness/ga-ratio4-producer-reference-2026-10-21.json)四端共8项通过、0跳过：4项新增、4项原四维RoPE邻居，60次成功Graph提交。
F32 KV／score窗口→BF16 pooling／norm／F32 suffix RoPE／Hadamard／FP4-QAT→实际BF16缓存→score／TopK／I32映射，
覆盖prefill3、两次压缩、无产出阶段与接受4个token后续算；每端一次emit只发布状态，保留普通闭合图。
修CUDA／Vulkan自然三维RoPE、共同输出租约误循可选alias、Apple拥有租约的实际stride、Vulkan singleton行距误选转换。
旧StateVersion仍占其背存；统一冷预建10个独立代Invocation，不绕过原生固定输出保护，也不承诺旧lease在世时同producer槽可重放。
有限F32状态与最终QAT／cache逐字检查，四处BF16中间最多1ULP；未验证完整投影／模型、prefill8分支、Linux、capture或吞吐。
本轮清理镜像并保增量对象／共享缓存的范围见[实录](../evidence/correctness/ga-ratio4-producer-reference-2026-10-21.cleanup.json)。'''
assert old in s;s=s.replace(old,new)
s=s.replace('这些是固定正式源的post-QAT角色边界，未签F32 compressor、完整attention／模型、Pro Top1024整链、Linux或吞吐。','上述17项是post-QAT消费者证据；其前置F32 compressor另由本轮ratio4旅程覆盖。完整attention／模型、Pro Top1024整链、Linux与吞吐仍未验证。')
updates[name]=s
name=paths[1];s=updates[name]
old='''bind、prepare_replay 和 submit；不另建执行器。`GraphOutput` 及其复制保留原 slot 和结果 backing，
阻止同槽 reset、rebind 或重放。`storage_lease()` 只可导出调用方或来源 alias 的外部 backing；
私有 workspace 和 Executable 常量仍由原 Graph owner 保留，不伪装为独立外部租约。'''
new='''bind、prepare_replay 和 submit；不另建执行器。`GraphOutput` 及其复制保留原 slot 和结果 backing，
阻止同槽 reset、rebind 或重放。`storage_lease()` 导出调用者拥有或执行来源明确允许导出的实际 backing，
范围仍受原租约约束；私有 workspace 和 Executable 常量不能凭地址导出独立租约。
独立 `ReadLease` 继续保护背存，固定输出程序在旧 lease 存活时会拒绝准备覆盖；`reset()` 成功不表示背存已可写。
同时保留多代状态时，冷预建独立 `Invocation` 承载所需代数，按实际读者退休复用，无需判断 Provider。'''
assert old in s;s=s.replace(old,new)
anchor='## View、Copy、Fill 与 Cast'
text='''`RoPE` 可自然表达单head `[B,S,D]` 与多head `[B,S,H,D]`，序列轴分别可用1／-2与1／-3；
不必为压缩器人为增加head轴。只旋转尾部时先切出尾部再拼回；模型明确要求F32旋转时，
以`Cast`表达升至F32、旋转后回到原存储类型的数值边界。

'''
assert anchor in s;s=s.replace(anchor,text+anchor,1);updates[name]=s
name=paths[2];s=updates[name]
old='F32重叠压缩生产者、完整attention／GA模型、Pro Top1024整链、Linux、质量及吞吐仍未签；不是所选权重payload执行。'
new='''后续[ratio4生产者](../evidence/correctness/ga-ratio4-producer-reference-2026-10-21.json)已把F32窗口／APE／pooling经明确BF16边界、suffix F32 RoPE、Hadamard及group32 FP4-QAT接入实际BF16缓存，沿原StateVersion消费评分／选择。
四端8项含4项新增与4项原RoPE邻居通过、0跳过，共60次提交；涵盖prefill3→p3…7、接受4token续算及一条仅发布状态的闭合emit图。
统一冷预建10代原Invocation保护仍被旧版本保留的输出；不承诺旧ReadLease在世时可重放同一个固定背存producer槽。
修三维RoPE准入、输出实际租约、Apple拥有租约的步长与Vulkan singleton行距；完整投影／attention／GA模型、prefill8、Pro Top1024整链、Linux、质量及吞吐未验证，未执行所选权重payload。'''
assert old in s;s=s.replace(old,new);updates[name]=s
for name,s in updates.items():(R/name).write_text(s,encoding='utf8')
print('Updated current work, public lifetime/shape guide and model role table.')
