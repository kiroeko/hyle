from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];R=P.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(d):
 p=resolve(d['path']);assert p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+chr(10),encoding='utf8')
config=read(P/'root/final-results.json');cases=[];receipts=[]
def collect(arm,p):
 for x in ET.parse(p).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name')
  cases.append(dict(backend=arm,name=name,neighbor=name.endswith('.ExistingMultiheadRopeKeepsOriginalGeometry'),
    properties={i.get('name'):i.get('value') for i in x.findall('./properties/property')}))
for arm in ('cpu','cuda','vulkan'):
 p=resolve(config[arm]);d=read(p)
 assert d['passed'] and d['cases']==2 and not d['skipped'] and not d['failed']
 for k in ('image','link_plan','xml'):check(d[k])
 for row in read(resolve(d['link_plan']['path']))['inputs']:check(row)
 for row in read(p.parent/'runtime-environment.json').get('private_modules',[]):
  check(row['source']);check(row['destination']);assert row['hardlink'] and row['source']['sha256']==row['destination']['sha256']
 collect(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
ap=resolve(config['apple']);a=read(ap);assert a['tests']==2 and a['failed']==a['skipped']==0
check(a['source_freeze'])
for row in a['artifacts'].values():check(row)
assert a['run']['exit']==0 and read(resolve(a['artifacts']['link.result.json']['path']))['exit']==0
collect('apple',resolve(a['artifacts']['tests.xml']['path']))
assert len(cases)==8 and sum(not x['neighbor'] for x in cases)==4
roles=[x for x in cases if not x['neighbor']]
assert all(x['properties']['successful_submissions']=='14' and x['properties']['producer_submissions']=='10' and x['properties']['consumer_submissions']=='4' and x['properties']['private_intermediate_emissions']=='1' for x in roles)
assert all(int(x['properties'][f'maximum_bf16_ulp_stage{i}'])<=1 for x in roles for i in range(4))
assert sum(int(x['properties']['successful_submissions']) for x in cases)==60
catalog=read(R/'docs/implementation/model-quantizations.json');assert len(catalog['artifacts'])==33
assert all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
sources=['src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_vulkan/region.cc',
 'src/graph/resources.cc','src/compute_route_apple/apple_memory.mm',
 'include/hyle/compute/state_versions.h','include/hyle/compute/model_ops.h','include/hyle/compute/operation.h',
 'include/hyle/compute/resource_leases.h','include/hyle/graph/result.h',
 'src/compute_route_vulkan/vulkan_program.cc','src/compute_ggml_runtime/explicit_rope.h','docs/architecture/compute-design.md',
 'tests/compute_models/ga_ratio4_producer_fixture.h','tests/compute_models/ga_ratio4_reference_fixture.h',
 'tests/compute_models/ga_indexer_state_fixture.h','tests/compute_models/nvfp4_reference_fixture.h',
 'tests/compute_models/batched_rope_fixture.h','docs/developer/current-work.md','docs/user/compute.md',
 'docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
sources += [f'tests/graph_route_{arm}/{name}' for arm in ('cpu','cuda','vulkan','apple') for name in ('ga_ratio4_producer_test.cc','CMakeLists.txt')]
entries={'source/'+s:R/s for s in sources}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.md','.mm','.ps1','.cmake','.in','.d'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
entries['provenance/deepseek-v4-ga-2026-10-19.zip']=R/'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'
for n in ('ratio4-producer-design.json','compressor-next-design.json'):
 entries['provenance/'+n]=P.parent/'ga-bf16-indexer-state-2026-10-21/review'/n
archive=R/'docs/evidence/correctness/ga-ratio4-producer-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='four_backend_projected_F32_ratio4_producer_to_BF16_cache_and_accepted_prefix_passed',
 scope='Fixed formal GA ratio4 indexer. B2,128channels,64suffixRoPE, F32 windows[2,8,256], BF16 cache capacity3 active0->1->2. Start at original F32 projected KV/gate; no whole projection/checkpoint/model claim.',
 mathematics='Gate+APE once, F32 channelwise8-row softmax/product/sum using previous first128/current last128, BF16 pool, mixed F32-gamma RMS thenBF16, suffixBF16->F32 explicit RoPE at block starts0/4->BF16, normalizedHadamard128 BF16, original group32FP4 QAT to decodedBF16 cache. Full256 KV/score state rolls at each boundary; current half stays intact.',
 oracle='Independent scalar source formula, F32/BF16 rounding helpers and FP4 enumeration. Fixed finite low-rank asymmetric halves chosen before GPU execution; normalized FP4 midpoint margin0.205810546875. Original state words and final QAT/cache compare exactly; pooledF32 tolerance2e-6+2e-6*abs; typed intermediate stages allow oneBF16 ULP and record actual deviation. Formal compressed frequency configuration supplied, but this finite payload only activates its first suffix pair and does not certify all frequencies/input domain.',
 journey='Main prefill3 then decodep3..7; first-empty selection, two emissions and actual produced-cache BF16 score/weighted sum/TopK/I32 map. Restore completed accepted4 generation and continuep4..7 with the same immutable plans. Main emit publishes stage audit outputs; accepted branch emit keeps all intermediates private, publishing only F32 windows/BF16 cache. No CPU payload readback feeds subsequent graph inputs.',
 ownership='Original GraphOutput.storage_lease resources enter one StateVersion with F16 mask/I32 map/host geometry only after original successful Completion. StateHead CAS checks retained versions; first GraphOutput blocks its slot reset, ten independently precreated original producer Invocations preserve every retained generation; native fixed-backing reuse remains gated. Consumer plans without retained output leases still replay their original slot. Old windows/cache survive later emissions, branch continuation and caller owner teardown.',
 fixes=config['fixes'],build=config['build'],
 regression=dict(total=8,new_cases=4,neighbors=4,failed=0,skipped=0,successful_Graph_submissions=60,
  producer_submissions=40,consumer_submissions=16,neighbor_submissions=4,windows=receipts,apple=ident(ap),cases=cases),
 limitations=['Finite projected-boundary journey, not full checkpoint payload/model or projection. Full positive-length prefill8 branch, arbitrary IEEE inputs, other ratios/depths, ProTop1024 complete chain and Linux are not signed.',
  'No capture/quality/throughput/zero-copy/fused-kernel claim. Out-of-place state/cache updates here are ordinary functional reference consumers; this finite capacity3 journey does not claim scalable large dense-cache append performance.',
  'Explicit no-emission graph avoids invalid zero-row QAT; this is not a general lazy Select/control-flow implementation.',
  'Capability7/8, delivery0/3 remain incomplete. All33 whole artifact_execution_verified flags remainfalse. Remaining finite required role actions are recorded in review/remaining-role-actions.json.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],sources=len(sources),cases=8)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
