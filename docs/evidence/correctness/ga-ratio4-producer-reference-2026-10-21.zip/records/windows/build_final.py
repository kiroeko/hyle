"""Refresh only the final three wrappers and retain the actual fixed product closures."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import re
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
spec = importlib.util.spec_from_file_location('ratio4_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASES = dict(cpu=P/'cpu/checks/link2/link-plan.json', cuda=P/'cuda/checks/link2/link-plan.json',
             vulkan=P/'vulkan/checks/rowpitch-fix1/link-plan.json')

def link(arm, record, folder):
    base_path = BASES[arm]
    base = c.read(base_path)
    assert all(b.same(x) for x in base['inputs'])
    old = c.key(P / arm / 'checks/attempt2/ga-ratio4-test.obj')
    assert sum(c.key(x['path']) == old for x in base['inputs']) == 1
    inputs = [record['object'] if c.key(x['path']) == old else x for x in base['inputs']]
    assert b.same(record['source']) and b.same(record['fixture']) and b.same(record['oracle'])
    assert all(b.same(x) for x in inputs)
    # The parent fixed GraphOutput alias storage. Never relink the original owner.
    expected = c.read(P / 'common/checks/root-resources1/identity.json')
    assert sum(c.key(x['path']) == c.key(expected['object']['path']) for x in inputs) == 1
    assert not any(c.key(x['path']).endswith('decode-prepare-cost\\cpu-regression\\graph-resources.obj') for x in inputs)
    command = [record['object']['path'] if c.key(x) == old else x for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = P / arm / 'checks' / folder
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    object_paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
    assert list(map(c.key, object_paths)) == [c.key(x['path']) for x in inputs]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path),
        replaced_test=next(x for x in base['inputs'] if c.key(x['path']) == old), new_test=record['object'],
        root_resources=b.identity(P / 'common/checks/root-resources1/identity.json'),
        new_product_CXX=0, SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    tests = re.findall(r'TEST\(\s*(\w+)\s*,\s*(\w+)\s*\)', Path(record['source']['path']).read_text())
    return dict(arm=arm, image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
                runtime_environment=b.identity(out / 'runtime-environment.json'),
                filter=':'.join(a+'.'+n for a,n in tests))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixture-sha', required=True)
    parser.add_argument('--attempt', default='attempt3')
    parser.add_argument('--link-dir', default='final-link1')
    args=parser.parse_args()
    fixture=h.R/'tests/compute_models/ga_ratio4_producer_fixture.h'
    assert b.identity(fixture)['sha256'] == args.fixture_sha
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records=dict(pool.map(lambda arm:h.compile_one(arm,args.attempt),BASES))
    assert b.identity(fixture)['sha256'] == args.fixture_sha
    arms=[link(arm,records[arm],args.link_dir) for arm in BASES]
    c.save(S/'ready-for-root-final-run.json',dict(status='compiled_linked_not_executed',arms=arms,
        fixture=b.identity(fixture), test_CXX=3, new_product_CXX=0, SDK_builds=0, NVCC_compiles=0,
        agent_CPU_runs=0,agent_GPU_runs=0))
    print(b.identity(S/'ready-for-root-final-run.json'))

if __name__=='__main__':
    main()
