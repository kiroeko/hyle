"""Normalize only contiguous native matrix metadata; compile and link without running."""
from pathlib import Path
import importlib.util
import difflib
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
spec = importlib.util.spec_from_file_location('ratio4_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R = h.b, h.c, h.R
source = R / 'src/compute_provider_ggml_vulkan/region.cc'
revision = P / 'vulkan/revisions/first-native-assert'
revision.mkdir(parents=True, exist_ok=True)
before = source.read_bytes().decode('utf-8')
needle = '''          else if (ggml_is_transposed(right))
            // A unit axis can be contiguous despite its inherited transpose
            // stride. Rebuild dense unit strides with the original zero-copy
            // view before ggml_mul_mat checks its stronger input contract.
'''
replacement = '''          else if (ggml_is_transposed(right) ||
                   right->nb[1] != right->nb[0] * std::size_t(right->ne[0]) ||
                   (right->ne[3] != 1 &&
                    right->nb[3] != right->nb[2] * std::size_t(right->ne[2])))
            // Contiguity ignores singleton-axis strides, while the native
            // matrix pipeline also requires canonical row and batch pitches.
            // Normalize only metadata; retain the original bytes and precision.
'''
assert before.count(needle) == 1
assert not (revision / 'region.cc').exists()
(revision / 'region.cc').write_bytes(before.encode('utf-8'))
c.save(revision / 'source.json', b.identity(source))
after = before.replace(needle, replacement)
source.write_bytes(after.encode('utf-8'))
out = P / 'vulkan/checks/rowpitch-fix1'
out.mkdir(parents=True, exist_ok=True)
(out / 'tmp').mkdir(exist_ok=True)
(out / 'implementation.diff').write_text(''.join(difflib.unified_diff(
    before.splitlines(True), after.splitlines(True), 'before/region.cc', 'after/region.cc')), encoding='utf-8', newline='')
recipe_path = P / 'common/checks/attempt1/vulkan-provider-region/identity.json'
recipe = c.read(recipe_path)
command = b.host_command(recipe['command'], source, 'vulkan-provider-region', out)
c.save(out / 'compile-plan.json', dict(command=command, source=b.identity(source),
    recipe=b.identity(recipe_path), replaced_object=recipe['object'], SDK_builds=0, NVCC_compiles=0, GPU_runs=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
data = c.read(out / 'vulkan-provider-region-deps.json')['Data']
record = dict(source=b.identity(source), object=b.identity(out / 'vulkan-provider-region.obj'), command=command,
    dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])],
    recipe=b.identity(recipe_path), replaced_object=recipe['object'])
c.save(out / 'identity.json', record)
base_path = P / 'vulkan/checks/link1/link-plan.json'
base = c.read(base_path)
resources_path = P / 'common/checks/root-resources1/identity.json'
resources = c.read(resources_path)
old_resources = [x for x in base['inputs'] if c.key(x['path']).endswith('decode-prepare-cost\\cpu-regression\\graph-resources.obj')]
assert len(old_resources) == 1
replacements = {c.key(recipe['object']['path']): record['object'], c.key(old_resources[0]['path']): resources['object']}
assert all(sum(c.key(x['path']) == key for x in base['inputs']) == 1 for key in replacements)
inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
assert all(b.same(x) for x in inputs)
assert b.same(resources['source']) and b.same(record['source'])
command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x
           for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
image = out / 'vulkan.exe'
command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path), replacements=replacements,
    current_resources=b.identity(resources_path), source=record['source'], SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
env, runtime = b.environment(command, [x['path'] for x in inputs], out)
c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
c.execute('link', command, env, out)
c.save(out / 'image.json', b.identity(image))
c.save(out / 'ready.json', dict(image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
    filter='VulkanGaRatio4.*', status='compiled_linked_not_executed', SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
print(str(out / 'ready.json'), flush=True)
print(b.identity(image), flush=True)
