"""Compile only the three ordinary ratio4 consumer wrappers; inherit current products."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import re
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
P = S.parent
A = P.parent
R = A.parents[1]
PREVIOUS = A / 'ga-bf16-indexer-state-2026-10-21'
spec = importlib.util.spec_from_file_location('ratio4_host_helpers', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASES = {arm: PREVIOUS / arm / 'checks/link1/link-plan.json'
         for arm in ['cpu', 'cuda', 'vulkan']}
PRODUCTS = {'cuda-tensor': 'cuda', 'vulkan-provider-region': 'vulkan'}


def compile_product(tag, attempt):
    path = PREVIOUS / 'common/checks/attempt1' / tag / 'identity.json'
    recipe = c.read(path)
    source = Path(recipe['source']['path'])
    out = P / 'common/checks' / attempt / tag
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), out
    command = b.host_command(recipe['command'], source, tag, out)
    frozen = b.identity(source)
    c.save(out / 'compile-plan.json', dict(source=frozen, command=command,
        recipe=b.identity(path), replaced_object=recipe['object'], SDK_builds=0, NVCC_compiles=0, GPU_runs=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / (tag + '-deps.json'))['Data']
    deps = [b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    assert all(b.same(x) for x in [frozen, *deps])
    record = dict(source=frozen, object=b.identity(out / (tag + '.obj')), command=command,
        recipe=b.identity(path), replaced_object=recipe['object'], dependencies=deps,
        source_dependencies=b.identity(out / (tag + '-deps.json')))
    c.save(out / 'identity.json', record)
    print('COMPILED', tag, flush=True)
    return record


def compile_one(arm, attempt):
    path = PREVIOUS / arm / 'checks/attempt1/identity.json'
    recipe = c.read(path)
    source = R / ('tests/graph_route_' + arm + '/ga_ratio4_producer_test.cc')
    out = P / arm / 'checks' / attempt
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), out
    command = b.host_command(recipe['command'], source, 'ga-ratio4-test', out)
    identities = [b.identity(source), b.identity(R / 'tests/compute_models/ga_ratio4_producer_fixture.h'),
                  b.identity(R / 'tests/compute_models/ga_ratio4_reference_fixture.h')]
    c.save(out / 'compile-plan.json', dict(command=command, source=identities[0],
        fixture=identities[1], oracle=identities[2], recipe=b.identity(path), replaced_test=recipe['object'],
        product_compiles=0, SDK_builds=0, NVCC_compiles=0, GPU_runs=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / 'ga-ratio4-test-deps.json')['Data']
    deps = [b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    assert all(b.same(x) for x in [*identities, *deps])
    record = dict(command=command, source=identities[0], fixture=identities[1], oracle=identities[2],
        recipe=b.identity(path), object=b.identity(out / 'ga-ratio4-test.obj'),
        replaced_test=recipe['object'], dependencies=deps,
        source_dependencies=b.identity(out / 'ga-ratio4-test-deps.json'))
    c.save(out / 'identity.json', record)
    print('COMPILED', arm, flush=True)
    return arm, record


def link_one(arm, record, product_attempt, link_dir):
    base = c.read(BASES[arm])
    assert all(b.same(x) for x in base['inputs'])
    old = c.key(record['replaced_test']['path'])
    assert sum(c.key(x['path']) == old for x in base['inputs']) == 1
    assert b.same(record['source']) and b.same(record['fixture']) and b.same(record['object'])
    replacements = {old: record['object']}
    for tag, owner_arm in PRODUCTS.items():
        if owner_arm != arm:
            continue
        product = c.read(P / 'common/checks' / product_attempt / tag / 'identity.json')
        assert b.same(product['source']) and b.same(product['object'])
        product_old = c.key(product['replaced_object']['path'])
        assert sum(c.key(x['path']) == product_old for x in base['inputs']) == 1
        replacements[product_old] = product['object']
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x
               for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = P / arm / 'checks' / link_dir
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists(), out
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert [c.key(x) for x in paths] == [c.key(x['path']) for x in inputs]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(BASES[arm]), replaced_test=record['replaced_test'], new_test=record['object'],
        replacements=replacements, reused_inputs=len(inputs) - len(replacements),
        current_inline_owner_audit=b.identity(PREVIOUS / 'windows/gather-defined-owner-audit.json'),
        retained_product_source_proof=b.identity(PREVIOUS / 'windows/actual-source-dependency-audit.json'),
        product_compiles=int(arm in PRODUCTS.values()), SDK_builds=0, NVCC_compiles=0, GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    image_identity = b.identity(image)
    c.save(out / 'image.json', image_identity)
    tests = re.findall(r'TEST\(\s*(\w+)\s*,\s*(\w+)\s*\)', Path(record['source']['path']).read_text())
    return dict(arm=arm, image=image_identity, link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        filter=':'.join(a + '.' + n for a, n in tests))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--products', action='store_true')
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--attempt', default='attempt1')
    parser.add_argument('--product-attempt', default='attempt1')
    parser.add_argument('--link-dir', default='link1')
    args = parser.parse_args()
    if args.products:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda tag: compile_product(tag, args.product_attempt), PRODUCTS))
    if args.compile:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            records = dict(pool.map(lambda arm: compile_one(arm, args.attempt), BASES))
    elif args.link:
        records = {arm: c.read(P / arm / 'checks' / args.attempt / 'identity.json') for arm in BASES}
    else:
        records = {}
    if args.link:
        rows = [link_one(arm, records[arm], args.product_attempt, args.link_dir) for arm in BASES]
        c.save(S / 'ready-for-root-run.json', dict(status='compiled_linked_not_executed', arms=rows,
            product_compiles=2, SDK_builds=0, NVCC_compiles=0, agent_CPU_runs=0, agent_GPU_runs=0))


if __name__ == '__main__':
    main()
