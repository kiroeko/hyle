"""Build a diagnostic-only region TU and current resources; no runtime execution."""
from pathlib import Path
import importlib.util
import difflib
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
spec = importlib.util.spec_from_file_location('ratio4_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R = h.b, h.c, h.R
out = P / 'vulkan/checks/diagnostic2'
out.mkdir(parents=True, exist_ok=True)
(out / 'tmp').mkdir(exist_ok=True)
assert not (out / 'compile.result.json').exists()
canonical = R / 'src/compute_provider_ggml_vulkan/region.cc'
original = canonical.read_bytes().decode('utf-8')
source = original.replace('#include <cmath>\n', '#include <cmath>\n#include <cstdio>\n', 1)
marker = 'constexpr int kBatchRuntimeRequestSlot = 11;'
helper = r'''

void hyle_ratio4_dump(const char *stage, ggml_cgraph *graph) {
  std::fprintf(stderr, "HYLE_RATIO4 %s graph=%p nodes=%d\n", stage,
               static_cast<const void *>(graph), ggml_graph_n_nodes(graph));
  for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {
    const auto *n = ggml_graph_node(graph, i);
    std::fprintf(stderr, "HYLE_RATIO4 node=%d op=%s type=%s ne=%lld,%lld,%lld,%lld params=%d,%d,%d\n",
      i, ggml_op_name(n->op), ggml_type_name(n->type),
      static_cast<long long>(n->ne[0]), static_cast<long long>(n->ne[1]),
      static_cast<long long>(n->ne[2]), static_cast<long long>(n->ne[3]),
      n->op_params[0], n->op_params[1], n->op_params[3]);
    if (n->op == GGML_OP_MUL_MAT) {
      for (int k = 0; k < 2; ++k) {
        const auto *s = n->src[k];
        std::fprintf(stderr, "HYLE_RATIO4 src=%d type=%s ne=%lld,%lld,%lld,%lld nb=%zu,%zu,%zu,%zu contiguous=%d\n",
          k, ggml_type_name(s->type), static_cast<long long>(s->ne[0]),
          static_cast<long long>(s->ne[1]), static_cast<long long>(s->ne[2]),
          static_cast<long long>(s->ne[3]), s->nb[0], s->nb[1], s->nb[2], s->nb[3],
          int(ggml_is_contiguous(s)));
      }
    }
  }
  std::fflush(stderr);
}
'''
assert source.count(marker) == 1
source = source.replace(marker, marker + helper, 1)
needle = '    HYLE_ASSIGN_OR_RETURN(state.graph,\n'
assert source.count(needle) == 1
source = source.replace(needle, '    hyle_ratio4_dump("before-native-allocate", graph);\n' + needle)
needle = '  const auto result =\n      state_->work.submit(state_->graph.get(), state_->graph.lease());'
assert source.count(needle) == 1
source = source.replace(needle, '  hyle_ratio4_dump("before-native-submit", state_->graph.get());\n' + needle)
diag = out / 'region.cc'
diag.write_bytes(source.encode('utf-8'))
(out / 'diagnostic.diff').write_text(''.join(difflib.unified_diff(
    original.splitlines(True), source.splitlines(True), 'canonical/region.cc', 'diagnostic/region.cc')), encoding='utf-8', newline='')
recipe_path = P / 'common/checks/attempt1/vulkan-provider-region/identity.json'
recipe = c.read(recipe_path)
command = b.host_command(recipe['command'], diag, 'vulkan-region-diagnostic', out)
c.save(out / 'compile-plan.json', dict(command=command, source=b.identity(diag),
    canonical_source=b.identity(canonical), recipe=b.identity(recipe_path),
    SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
data = c.read(out / 'vulkan-region-diagnostic-deps.json')['Data']
identity = dict(source=b.identity(diag), object=b.identity(out / 'vulkan-region-diagnostic.obj'),
    command=command, dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])])
c.save(out / 'identity.json', identity)
base_path = P / 'vulkan/checks/link1/link-plan.json'
base = c.read(base_path)
resources_path = P / 'common/checks/root-resources1/identity.json'
resources = c.read(resources_path)
old_resources = [x for x in base['inputs'] if c.key(x['path']).endswith('decode-prepare-cost\\cpu-regression\\graph-resources.obj')]
assert len(old_resources) == 1
replacements = {c.key(recipe['object']['path']): identity['object'],
                c.key(old_resources[0]['path']): resources['object']}
assert all(sum(c.key(x['path']) == key for x in base['inputs']) == 1 for key in replacements)
inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
assert all(b.same(x) for x in inputs)
assert b.same(resources['source'])
command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x
           for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
image = out / 'vulkan-diagnostic.exe'
command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
            '/IMPLIB:' + str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path),
    replacements=replacements, current_resources=b.identity(resources_path),
    source=identity['source'], diagnostics_only=True, agent_GPU_runs=0))
env, runtime = b.environment(command, [x['path'] for x in inputs], out)
c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
c.execute('link', command, env, out)
c.save(out / 'image.json', b.identity(image))
print(str(out / 'link-plan.json'), flush=True)
print(b.identity(image), flush=True)
