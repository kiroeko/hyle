"""Record the bounded native-layout diagnosis and exact product identities."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
spec = importlib.util.spec_from_file_location('ratio4_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R = h.b, h.c, h.R
out = P / 'vulkan'
record = c.read(out / 'checks/rowpitch-fix1/identity.json')
assert b.same(record['source']) and b.same(record['object'])
assert all(b.same(x) for x in record['dependencies'])
native = P.parent / 'compact-mla-e4-reference/vulkan/current-patch-source/src/ggml-vulkan/ggml-vulkan.cpp'
ggml = R / '.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/source-bdb6226828f5304e/src/ggml.c'
c.save(out / 'rowpitch-root-cause.json', dict(
    status='source_and_actual_diagnostic_confirmed_fix_compiled_runtime_pending',
    first_failure='GGML_ASSERT(mmp_map != nullptr), native ggml-vulkan.cpp:9671',
    failing_node=dict(operation='MUL_MAT', output_ne=[1,64,1,2], params_0_1_3=[10,0,10],
        src0=dict(type='F32', ne=[128,1,1,2], byte_strides=[4,4,512,512], ggml_is_contiguous=True),
        src1=dict(type='F32', ne=[128,64,1,2], byte_strides=[4,512,32768,32768], ggml_is_contiguous=True)),
    diagnosis=[
        'Hadamard width128 F32 FWHT completed before the downstream score MatMul; rank3 RoPE was not the aborting native operation.',
        'ggml_is_contiguous ignores singleton-axis strides; ggml_is_transposed tests nb0>nb1, hence 4>4 is false.',
        'ggml_vk_dim01_contiguous requires nb1=nb0*ne0, hence source0 row pitch4 differs from512 despite generic contiguity.',
        'x_non_contig triggered conversion map lookup F16/F32 although params[3] already requests F32 operands; that native map is absent and the backend asserted.'
    ],
    correction='Extend the existing contiguous-RHS metadata reshape predicate to noncanonical native row/outer-batch pitches. The reshape retains original allocation, shape, bytes and F32 precision; no payload Copy or conversion is added.',
    domain='Ordinary nonquantized MatMul existing adapter only; other layouts keep the established typed Copy/native route. No vendor SDK source or shader changes.',
    source=record['source'], object=record['object'], build_identity=b.identity(out / 'checks/rowpitch-fix1/identity.json'),
    before_source=b.identity(out / 'revisions/first-native-assert/region.cc'),
    implementation_diff=b.identity(out / 'checks/rowpitch-fix1/implementation.diff'),
    diagnostic_source=b.identity(out / 'checks/diagnostic2/region.cc'),
    diagnostic_stderr=b.identity(out / 'validation/diagnostic2/tests.stderr.log'),
    native_source=b.identity(native), generic_layout_source=b.identity(ggml),
    final_link=b.identity(out / 'checks/rowpitch-fix1/link-plan.json'),
    root_resources_identity=b.identity(P / 'common/checks/root-resources1/identity.json'),
    SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
c.save(out / 'source-freeze-rowpitch1.json', dict(
    status='compiled_linked_waiting_root_runtime', sources=[record['source']],
    dependencies=record['dependencies'], object=record['object'],
    link_plan=b.identity(out / 'checks/rowpitch-fix1/link-plan.json'),
    diagnostics_not_in_product=True, SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
print(b.identity(out / 'rowpitch-root-cause.json'))
print(b.identity(out / 'source-freeze-rowpitch1.json'))
