"""Freeze the exact bounded Windows closure and retain previous report revisions."""
from pathlib import Path
import importlib.util
import difflib
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
spec = importlib.util.spec_from_file_location('ratio4_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R = h.b, h.c, h.R
owners = [P/'common/checks/attempt1/cuda-tensor/identity.json',
          P/'vulkan/checks/rowpitch-fix1/identity.json',
          P/'common/checks/root-resources1/identity.json',
          *[P/arm/'checks/attempt3/identity.json' for arm in ['cpu','cuda','vulkan']]]
entries=[]
unique={}
for path in owners:
    record=c.read(path)
    assert b.same(record['source']) and b.same(record['object'])
    for item in record['dependencies']:
        assert b.same(item), item
        unique[c.key(item['path'])]=item
    entries.append(dict(identity=b.identity(path),source=record['source'],object=record['object'],
                        dependency_entries=len(record['dependencies'])))
c.save(S/'actual-source-dependency-audit.json', dict(status='all_six_final_owner_dependencies_match',
    scope='Only six freshly compiled actual owners; retained product objects keep their prior scoped identity proof. No whole-project current-build claim.',
    owners=entries, dependency_entries=sum(x['dependency_entries'] for x in entries),
    unique_dependencies=len(unique), drift=0, dependencies=list(unique.values())))
files=['src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_vulkan/region.cc',
       'src/graph/resources.cc','tests/compute_models/ga_ratio4_producer_fixture.h',
       'tests/compute_models/ga_ratio4_reference_fixture.h',
       *[f'tests/graph_route_{arm}/{name}' for arm in ['cpu','cuda','vulkan']
         for name in ['ga_ratio4_producer_test.cc','CMakeLists.txt']]]
snapshot=S/'final-source'
items=[]
for name in files:
    source=R/name
    target=snapshot/name
    target.parent.mkdir(parents=True,exist_ok=True)
    payload=source.read_bytes()
    if target.exists(): assert target.read_bytes()==payload
    else: target.write_bytes(payload)
    items.append(dict(source=b.identity(source),snapshot=b.identity(target)))
c.save(S/'final-source-freeze.json',dict(status='final_three_wrapper_closures_compiled_linked_root_execution_external',
    files=items,actual_source_audit=b.identity(S/'actual-source-dependency-audit.json'),
    ready=b.identity(S/'ready-for-root-final-run.json'),agent_CPU_runs=0,agent_GPU_runs=0))
revisions=S/'revisions/pre-final-metadata'
revisions.mkdir(parents=True,exist_ok=True)
for name in ['build-report.json','product-source-freeze.json']:
    old=S/name
    dst=revisions/name
    if old.exists() and not dst.exists(): dst.write_bytes(old.read_bytes())
compile_rows=[]
for path in sorted(P.rglob('compile.result.json')):
    if path.relative_to(P).parts[0] not in ('common','cpu','cuda','vulkan'): continue
    result=c.read(path)
    compile_rows.append(dict(result=b.identity(path),exit=result.get('exit_code',result.get('exit'))))
link_rows=[]
for path in sorted(P.rglob('link.result.json')):
    if path.relative_to(P).parts[0] not in ('common','cpu','cuda','vulkan'): continue
    result=c.read(path)
    link_rows.append(dict(result=b.identity(path),exit=result.get('exit_code',result.get('exit'))))
c.save(S/'build-report.json',dict(status='bounded_windows_builds_complete_root_execution_recorded_separately',
    CXX_attempts=len(compile_rows),CXX_success=sum(x['exit']==0 for x in compile_rows),
    CXX_failure=sum(x['exit']!=0 for x in compile_rows),
    links=len(link_rows),link_success=sum(x['exit']==0 for x in link_rows),
    compile_results=compile_rows,link_results=link_rows,
    final_ready=b.identity(S/'ready-for-root-final-run.json'),
    historical_failures=[
      'Initial three wrappers failed /WX on one double-to-float neighbor vector constructor; mechanical explicit cast preserved dyadic data and oracle.',
      'Diagnostic-only first provider TU used const ggml_cgraph*, incompatible with the cached API; corrected diagnostic TU compiled without canonical source change.',
      'First runtime native abort was contiguous singleton RHS noncanonical row pitch; actual diagnostic excluded Hadamard and confirmed native pipeline-map failure.',
      'Retained ReadLease pins fixed native generated output storage. Native reuse rejection is a valid contract, not a math failure. The shared finite journey cold-reserves independent invocation storage for each retained generation.'
    ],
    scope='Counts include parent root-resources1 CXX and parent CPU/CUDA link2 inside this stage. Actual runtime commands, errors and results are parent-owned.',
    SDK_builds=0,NVCC_compiles=0,agent_CPU_runs=0,agent_GPU_runs=0))
c.save(S/'product-source-freeze.json',dict(status='actual_final_sources_compiled_linked',
    files=[b.identity(R/name) for name in files[:3]],
    changes=['Dense rank3 BSD RoPE metadata adapter on CUDA/Vulkan; existing rank4 branch retained.',
             'Vulkan contiguous RHS singleton row/batch pitch canonicalization uses metadata only.',
             'Parent GraphOutput alias storage lease projection fix; exact source and owner identity retained.'],
    final_owners=entries[:3],SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
before=(P/'before/src/compute_provider_ggml_vulkan/region.cc')
if before.exists():
    (S/'product-final-vulkan.diff').write_text(''.join(difflib.unified_diff(
        before.read_bytes().decode().splitlines(True),
        (R/'src/compute_provider_ggml_vulkan/region.cc').read_bytes().decode().splitlines(True),
        'before/region.cc','after/region.cc')),encoding='utf-8',newline='')
receipts=[]
for arm in ['cpu','cuda','vulkan']:
    path=P/arm/'validation/final2/receipt.json'
    result=c.read(path)
    assert result['passed'] and result['cases']==2 and not result['failed'] and not result['skipped']
    assert b.same(result['image']) and b.same(result['link_plan']) and b.same(result['xml'])
    receipts.append(dict(arm=arm,receipt=b.identity(path),image=result['image'],link_plan=result['link_plan'],
                         xml=result['xml'],cases=result['cases'],failed=0,skipped=0,executor='parent /root'))
modules=[]
for arm in ['cpu','cuda','vulkan']:
    for path in sorted((P/arm/'validation').glob('*/runtime-environment.json')):
        record=c.read(path)
        for module in record.get('private_modules',[]):
            assert b.same(module['source']) and b.same(module['destination'])
            assert os.path.samefile(module['source']['path'],module['destination']['path'])
            modules.append(dict(arm=arm,record=b.identity(path),**module,
                                observed_hardlink_count=os.stat(module['destination']['path']).st_nlink))
c.save(S/'private-module-staging-proof.json',dict(status='actual_runtime_records_and_files_match',
    scope='Exact cached image-selected AVX2 module staged by parent runner beside each scratch executable. Same-file hardlinks, no SDK copy; source retained.',
    final_cuda_environment=b.identity(P/'cuda/validation/final2/runtime-environment.json'),
    records=modules,unique_staged_targets=sorted({x['destination']['path'] for x in modules}),
    canonical_deployment='Existing hyle_stage_runtime and install deployment already register the private module; focused manual scratch links use explicit application-directory staging.',
    loader_flags_unchanged=True,agent_runtime=0))
c.save(P/'vulkan/native-generated-output-contract.json',dict(status='contract_retention_rejection_preserved_final_journey_passed',
    facts=[
      'RegionOutputKind::kStableGenerated provides backing at slot creation; Vulkan Program invocation owns fixed output buffers.',
      'native_region::lease exports the same original buffer in an independent ReadLease. The lease pins storage even after GraphOutput is dropped.',
      'GraphOutput observers prevent Graph reset. Independent storage leases no longer count as GraphOutput observers; native reuse gate still refuses rewriting their pinned backing.',
      'The intermediate prepare rejection Vulkan batch native output retained is correct and remains unchanged; no native output rebind, hidden copy or pool was introduced.',
      'The final shared finite journey cold-creates generation counts1/6/2/1 from four immutable compiled producer plans. Every retained producer generation gets original independent Invocation output storage; consumers still reuse when permitted.'
    ],
    source_paths=['include/hyle/graph/region_provider.h:313','src/graph_route_vulkan/native_region.cc:408',
                  'src/compute_route_vulkan/vulkan_memory.cc:295','src/compute_route_vulkan/vulkan_program.cc:882'],
    original_rejection=b.identity(P/'vulkan/validation/final1/tests.stdout.log'),
    final_shared=b.identity(R/'tests/compute_models/ga_ratio4_producer_fixture.h'),
    final_validation=b.identity(P/'vulkan/validation/final2/receipt.json'),
    no_universal_lease_replay_claim=True,agent_GPU_runs=0))
cause_path=P/'vulkan/rowpitch-root-cause.json'
cause=c.read(cause_path)
cause.update(status='source_and_actual_diagnostic_confirmed_final_root_runtime_passed',
             final_validation=b.identity(P/'vulkan/validation/final2/receipt.json'))
c.save(cause_path,cause)
freeze_path=P/'vulkan/source-freeze-rowpitch1.json'
freeze=c.read(freeze_path)
freeze.update(status='compiled_linked_parent_final_runtime_passed',
              final_link=b.identity(P/'vulkan/checks/final-link1/link-plan.json'),
              final_validation=b.identity(P/'vulkan/validation/final2/receipt.json'))
c.save(freeze_path,freeze)
c.save(S/'final-validation.json',dict(status='parent_actual_windows_six_distinct_tests_passed',
    arms=receipts,distinct_tests=6,failed=0,skipped=0,
    submissions_per_arm=dict(producer=10,consumer=4,existing_multihead_rope=1),
    fixture=b.identity(R/'tests/compute_models/ga_ratio4_producer_fixture.h'),
    final_source_freeze=b.identity(S/'final-source-freeze.json'),
    source_dependency_audit=b.identity(S/'actual-source-dependency-audit.json'),
    rowpitch_diagnosis=b.identity(cause_path),
    fixed_storage_contract=b.identity(P/'vulkan/native-generated-output-contract.json'),
    private_module_staging=b.identity(S/'private-module-staging-proof.json'),
    scope='Finite projected F32 ratio4 overlap producer, original BF16 cache state feedback and accepted-prefix continuation plus existing4D RoPE neighbor; not complete model/projection, prefill8, throughput, capture or Linux proof.',
    SDK_builds=0,NVCC_compiles=0,agent_CPU_runs=0,agent_GPU_runs=0))
print('Counts',len(compile_rows),sum(x['exit']==0 for x in compile_rows),'CXX;',len(link_rows),'links')
print('Dependencies',sum(x['dependency_entries'] for x in entries),len(unique),'unique; source files',len(files))
print(b.identity(S/'final-source-freeze.json'))
print(b.identity(S/'build-report.json'))
