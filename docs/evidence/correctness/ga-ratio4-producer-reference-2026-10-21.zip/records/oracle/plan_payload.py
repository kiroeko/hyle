import json, math, pathlib, struct

def f32(x): return struct.unpack('<f', struct.pack('<f', x))[0]
def bits(x): return struct.unpack('<I', struct.pack('<f', x))[0]
def bf(x):
    b = bits(x)
    return ((b + 0x7fff + ((b >> 16) & 1)) >> 16) & 0xffff
def wide(x): return struct.unpack('<f', struct.pack('<I', x << 16))[0]
def rnd(x): return wide(bf(x))
def mul(a,b): return f32(a*b)
def add(a,b): return f32(a+b)
TABLE = [0., .5, 1., 1.5, 2., 3., 4., 6.]
CUTS = [.25, .75, 1.25, 1.75, 2.5, 3.5, 5.]

def run(seed):
    state = [[[0.] * 256 for _ in range(8)] for _ in range(2)]
    scores = [[[-math.inf] * 256 for _ in range(8)] for _ in range(2)]
    margin = math.inf
    all_bf = []
    norm_early_diffs = 0
    gamma = f32((143 + seed % 7) / 128.)
    for pos in range(8):
        phase = pos % 4
        for b in range(2):
            for h in range(2):
                alpha = f32((1049 + b * 211 + pos * 37 + h * 503 + seed * 13) / 1024.)
                beta = f32((73 + b * 19 + pos * 11 - h * 23 + seed * 3) / 1024.)
                delta = f32((-91 + b * 13 - pos * 7 + h * 17 - seed * 2) / 1024.)
                for d in range(128):
                    channel = h * 128 + d
                    local = 0 if d < 64 else d - 63
                    state[b][4+phase][channel] = alpha if d < 64 else beta if d == 64 else delta if d == 65 else 0.
                    gate = f32(((pos*73 + b*31 + h*97 + local*7 + seed*5) % 733 - 366) / 1024.)
                    ape = f32(((phase*149 + h*211 + local*13 + seed*17) % 1031 - 515) / 1024.)
                    scores[b][4+phase][channel] = add(gate, ape)
        if phase != 3: continue
        for b in range(2):
            pooled = []
            for d in range(128):
                v = [state[b][r][d] for r in range(4)] + [state[b][4+r][128+d] for r in range(4)]
                s = [scores[b][r][d] for r in range(4)] + [scores[b][4+r][128+d] for r in range(4)]
                maximum = max(s)
                e = [f32(math.exp(f32(x-maximum))) for x in s]
                den = 0.
                for x in e: den = add(den, x)
                total = 0.
                for x, ex in zip(v, e): total = add(total, mul(x, f32(ex/den)))
                pooled.append(rnd(total))
            sq = 0.
            for x in pooled: sq = add(sq,mul(x,x))
            var = f32(sq/128.)
            inv = f32(1./math.sqrt(add(var, f32(1.e-6))))
            n = [rnd(mul(gamma, mul(x, inv))) for x in pooled]
            norm_early_diffs += sum(bf(mul(gamma, rnd(mul(x, inv)))) != bf(y) for x,y in zip(pooled,n))
            co, si = f32(math.cos(pos-3)), f32(math.sin(pos-3))
            a, z = n[64], n[65]
            n[64] = rnd(f32(mul(a,co)-mul(z,si)))
            n[65] = rnd(add(mul(a,si),mul(z,co)))
            width = 1
            while width < 128:
                for base in range(0,128,width*2):
                    for j in range(width):
                        a,z = n[base+j], n[base+j+width]
                        n[base+j],n[base+j+width] = add(a,z),f32(a-z)
                width *= 2
            n = [rnd(mul(x,f32(1./math.sqrt(128.)))) for x in n]
            all_bf.append([bf(x) for x in n])
            for base in range(0,128,32):
                maximum = max(max(abs(x) for x in n[base:base+32]),f32(6*2**-126))
                raw_scale = mul(maximum,f32(1./6.))
                word = bits(raw_scale)
                power = ((word>>23)&255)-127 + bool(word&0x7fffff)
                scale = math.ldexp(1.,power)
                for x in n[base:base+32]:
                    normalized = abs(x)/scale
                    margin = min(margin, min(abs(normalized-cut) for cut in CUTS))
            state[b][:4] = [x.copy() for x in state[b][4:]]
            scores[b][:4] = [x.copy() for x in scores[b][4:]]
    return {'seed':seed,'gamma':gamma,'minimum_normalized_fp4_midpoint_distance':margin,
            'norm_early_bf16_rounding_differences':norm_early_diffs,'hadamard_bf16':all_bf}

if __name__ == '__main__':
    results = [run(seed) for seed in range(64)]
    selected = max(results,key=lambda r:r['minimum_normalized_fp4_midpoint_distance'])
    p=pathlib.Path(__file__).with_name('payload-plan.json')
    p.write_text(json.dumps({'scope':'Independent host-only scalar design of a fixed input; no product/backend execution',
                            'selected':selected,
                            'candidate_margins':[{'seed':r['seed'],'margin':r['minimum_normalized_fp4_midpoint_distance']} for r in results]},indent=2)+'\n')
    print({k:v for k,v in selected.items() if k!='hadamard_bf16'})
