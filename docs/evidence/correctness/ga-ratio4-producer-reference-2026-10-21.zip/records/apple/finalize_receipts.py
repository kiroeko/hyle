"""Read-only audit of actual dependencies and remote artifacts; write local receipts."""
from pathlib import Path
import hashlib
import json
import posixpath
import runpy
import shutil
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
A = ROOT / ".scratch/architecture-refactor-2026-10-18"
P = A / "ga-ratio4-producer-2026-10-21/apple"
OUT = P / "mac/final"
RESULTS = OUT / "results"


def read(p):
    return json.loads(p.read_text())


def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n")


def identity(p):
    b = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), bytes=len(b),
                sha256=hashlib.sha256(b).hexdigest())


def canonical(remote):
    normal = posixpath.normpath(remote)
    for prefix in ("include/hyle/", "tests/", "src/", "third_party/"):
        marker = "/" + prefix
        start = normal.find(marker)
        while start >= 0:
            local = ROOT / normal[start + 1:]
            if local.is_file():
                return local
            start = normal.find(marker, start + 1)
    return None


compiles = read(RESULTS / "compile-summary.json")["compiles"]
audits, drifts, unique = [], [], {}
for c in compiles:
    own, external = [], []
    for dep in c["dependencies"]:
        local = canonical(dep["path"])
        if local is None:
            external.append(dep)
            continue
        current = identity(local)
        equal = current["sha256"] == dep["sha256"] and current["bytes"] == dep["bytes"]
        row = dict(actual=dep, current=current, equal=equal)
        own.append(row)
        unique[current["path"]] = current
        if not equal:
            drifts.append(row)
    actual_source = c["source"]
    assert identity(canonical(actual_source["path"]))["sha256"] == actual_source["sha256"]
    assert c["exit"] == 0 and c["source_drifts"] == []
    audits.append(dict(source=actual_source, exit=c["exit"],
                       dependencies=len(c["dependencies"]), canonical_count=len(own),
                       external_count=len(external), canonical=own, external=external))
audit = dict(status="all_actual_dependency_files_classified_and_canonical_bytes_equal" if not drifts else "drift",
             scope="Every actual -MMD dependency of final three CXX invocations; SDK/system/generated paths retained by identity without copying SDK text.",
             translation_units=len(compiles), actual_dependency_references=sum(x["dependencies"] for x in audits),
             canonical_dependency_references=sum(x["canonical_count"] for x in audits),
             external_dependency_references=sum(x["external_count"] for x in audits),
             unique_canonical_files=len(unique), drift_count=len(drifts), drifts=drifts, compiles=audits)
save(P / "actual-dependencies-canonical-audit.json", audit)
assert not drifts

ssh = runpy.run_path(str(A / "batch-query-extent/delegated/apple/validate.py"))["ssh"]
remote = read(OUT / "plan.json")["remote"]
inventory = ssh('''from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['root']);assert r.is_absolute() and r.exists() and not r.is_symlink()
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
images=[];objects=[];dsym=[]
for q in sorted(r.rglob('*')):
 if q.is_symlink():continue
 if q.is_dir():
  if q.suffix=='.dSYM':dsym.append(str(q))
  continue
 if q.suffix=='.o':objects.append(ident(q))
 elif q.suffix=='.map':images.append(ident(q))
 else:
  with q.open('rb')as f:magic=f.read(4)
  if magic in [bytes.fromhex(x)for x in ('cffaedfe','feedfacf','cafebabe','bebafeca')]:images.append(ident(q))
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
active=[s for s in ps.splitlines()if str(r)in s and 'python3 -c'not in s and '/usr/bin/ssh'not in s]
lsof=subprocess.run(['lsof','--',*[x['path']for x in images]],capture_output=True,text=True)
print(json.dumps(dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=images,retained_objects=objects,dsym=dsym,active_image_processes=active,lsof_stdout=lsof.stdout,lsof_stderr=lsof.stderr,lsof_exit=lsof.returncode,deleted=False)))
''', dict(root=remote))
assert not inventory["active_image_processes"] and not inventory["lsof_stdout"]
save(P / "cleanup-readonly-inventory.json", inventory)

for rel, row in unique.items():
    assert identity(ROOT / rel) == row
    target = P / "source" / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / rel, target)
registration = "tests/graph_route_apple/CMakeLists.txt"
shutil.copyfile(ROOT / registration, P / "source" / registration)
freeze = dict(status="actual_three_CXX_sources_and_all_actual_canonical_dependencies_equal_final_Windows_bytes",
              sources=sorted(unique.values(), key=lambda r:r["path"]),
              registration=identity(ROOT / registration),
              compiled_translation_units=[c["source"] for c in compiles],
              canonical_dependency_audit=identity(P / "actual-dependencies-canonical-audit.json"),
              actual_dependency_references=audit["actual_dependency_references"],
              canonical_dependency_references=audit["canonical_dependency_references"],
              unique_canonical_files=audit["unique_canonical_files"], actual_whole_dependencies_drift=0,
              source_snapshot="source/", SDK_source_copied=False,
              common_resources_owner="root", Apple_product_change=identity(P / "apple-memory-product-change.json"),
              uniform_producer_generation_reservation=[1, 6, 2, 1],
              prior_reuse_fixture="prior-reuse-fixture/preservation.json")
save(P / "source-freeze.json", freeze)

cases = [dict(name=t.attrib["classname"]+"."+t.attrib["name"],
              properties={v.attrib["name"]:v.attrib["value"] for v in t.findall("./properties/property")})
         for t in ET.parse(RESULTS / "tests.xml").iter("testcase")]
assert len(cases) == len({x["name"] for x in cases}) == 2
assert sum(int(c["properties"]["successful_submissions"]) for c in cases) == 15
assert cases[0]["properties"]["cold_producer_generations"] == "10"
validation = read(RESULTS / "validation.json")
assert validation["tests"] == 2 and validation["exit"] == 0 and not validation["failed"] and not validation["skipped"]
final = dict(status="actual_Mac16_12_Metal_pass", source_freeze=identity(P / "source-freeze.json"),
             hardware=identity(OUT / "hardware.json"), tests=2, new_cases=1, original_neighbors=1,
             failed=0, skipped=0, cases=cases, successful_submissions=15,
             producer_submissions=10, consumer_submissions=4, neighbor_submissions=1,
             expected_failure_submissions=0, CXX_jobs_in_final_image=3,
             Apple_product_CXX_jobs=1, common_product_CXX_jobs=1, test_CXX_jobs=1,
             last_fixture_revision_CXX_jobs=1, last_fixture_revision_product_CXX_jobs=0,
             exact_retained_product_objects=2, SDK_jobs=0,
             compiles=[dict(source=c["source"], exit=c["exit"], object=c["object_identity"],
                            dependency_count=len(c["dependencies"]), source_drifts=c["source_drifts"])
                       for c in compiles],
             actual_whole_dependencies_drift=0, actual_dependency_references=audit["actual_dependency_references"],
             unique_canonical_files=audit["unique_canonical_files"], run=read(RESULTS / "run.result.json"),
             image=validation["image"],
             artifacts={name:identity(RESULTS / name) for name in ("compile-summary.json", "link-inputs.json", "link.command.json", "link.result.json", "run.command.json", "run.result.json", "tests.xml", "validation.json")},
             prior_reuse_fixture=identity(P / "prior-reuse-fixture/preservation.json"),
             source_attempts_preserved=["attempt1 overlay duplicate header physical paths", "attempt2 stale overlay model_ops.h", "attempt3 canonical dependency guard caught old Apple header before link", "attempt4 current-source runtime exposed original owned strided lease bridge", "prior-reuse-fixture actual 2/2 green with earlier producer slot reuse", "final ten cold producer generations preserve all historical StateVersions on every backend"],
             scope="Projected F32 KV/gate overlapping ratio4 producer feeds BF16 typed score/selection/cache through original StateVersion/GraphOutput storage leases and accepted-prefix continuation. Includes private closed emit and original 4D RoPE neighbor. Does not sign full model/projection/prefill8/throughput or exhaustive IEEE Hadamard behavior.",
             numerics=dict(maximum_bf16_ulp_stages=[0,0,0,1], minimum_fp4_midpoint_distance="0.205811", norm_early_rounding_differences=2, oracle_or_tolerance_relaxed=False),
             cleanup_inventory=identity(P / "cleanup-readonly-inventory.json"), no_deletion_performed=True)
save(P / "final-validation.json", final)
for q in (P / "source-freeze.json", P / "final-validation.json", P / "actual-dependencies-canonical-audit.json", P / "cleanup-readonly-inventory.json"):
    print(json.dumps(identity(q)))
