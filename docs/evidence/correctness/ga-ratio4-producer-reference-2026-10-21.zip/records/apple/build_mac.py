"""Run only the exact retained-cache incremental Apple closure."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import shlex
import subprocess
import sys
import time
import xml.etree.ElementTree as E
R = Path(__file__).resolve().parent
O = R / "results"
O.mkdir(exist_ok=True)
(R / "objects").mkdir(exist_ok=True)
plan = json.loads((R / "plan.json").read_text())
manifest = json.loads((R / "source-manifest.json").read_text())
expected = {x["path"]: x for x in [*manifest, *json.loads((R / "reused-source-manifest.json").read_text())]}


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + "\n")


def execute(tag, command):
    record = dict(argv=command, started=time.time())
    save(tag + ".command.json", record)
    env = dict(__import__("os").environ)
    if tag == "run":
        env.update(plan.get("run_environment", {}))
        record["environment"] = plan.get("run_environment", {})
        save(tag + ".command.json", record)
    p = subprocess.run(command, cwd=R, capture_output=True, text=True, env=env)
    (O / (tag + ".stdout.log")).write_text(p.stdout)
    (O / (tag + ".stderr.log")).write_text(p.stderr)
    record.update(exit=p.returncode, seconds=time.time() - record["started"])
    save(tag + ".result.json", record)
    print(tag, p.returncode, round(record["seconds"], 2), flush=True)
    return record


for row in manifest:
    assert identity(R / row["path"])["sha256"] == row["sha256"], row["path"]
for row in plan["inputs"]:
    assert identity(row["path"]) == row, row["path"]
first = ["-I" + str(R / name) for name in plan["include_roots"]]
for name in plan.get("system_include_roots", []): first += ["-isystem", name]



def compile_one(row):
    rel = row["source"]
    tag = rel.replace("/", "--")
    obj = R / "objects" / (tag + ".o")
    dep = Path(str(obj) + ".d")
    command = row["recipe"].copy()
    for flag in ["-MF", "-MT", "-MQ"]:
        while flag in command:
            i = command.index(flag)
            del command[i:i + 2]
    command = [x for x in command if x not in ["-MD", "-MMD"]]
    command[command.index("-c") + 1] = str(R / rel)
    command[command.index("-o") + 1] = str(obj)
    command[1:1] = first
    command += ["-MD", "-MF", str(dep)]
    prior = O / (tag + "-identity.json")
    if prior.exists():
        cached = json.loads(prior.read_text())
        if cached.get("exit") == 0 and not cached.get("source_drifts") and cached.get("source_manifest_sha256") == identity(R / "source-manifest.json")["sha256"] and cached.get("reused_source_manifest_sha256") == identity(R / "reused-source-manifest.json")["sha256"] and cached["argv"] == command and all(
            Path(x["path"]).exists() and identity(x["path"]) == x
            for x in cached.get("dependencies", [])):
            print(tag, "reused current exact command/source/dependency hashes", flush=True)
            return cached
    result = execute(tag + "-compile", command)
    record = dict(result, source=identity(R / rel), old_object=row["old_object"],
                  source_manifest_sha256=identity(R / "source-manifest.json")["sha256"],
                  reused_source_manifest_sha256=identity(R / "reused-source-manifest.json")["sha256"],
                  object=str(obj), dependency=str(dep))
    if result["exit"]:
        save(tag + "-identity.json", record)
        return record
    paths = list(dict.fromkeys(shlex.split(
        dep.read_text().split(": ", 1)[1].replace("\\\n", " "))))
    deps = [identity(path) for path in paths]
    drift = []
    for item in deps:
        path = Path(item["path"])
        normalized = path.resolve().as_posix()
        key = next((x for x in sorted(expected, key=len, reverse=True)
                    if normalized.endswith("/" + x)), None)
        if key is not None and expected[key]["sha256"] != item["sha256"]:
            drift.append(dict(item, canonical_path=key,
                              expected_sha256=expected[key]["sha256"]))
    record.update(object_identity=identity(obj), dependencies=deps, source_drifts=drift)
    save(tag + "-identity.json", record)
    assert not drift
    return record


if "--generate" in sys.argv:
    env = dict(__import__('os').environ, PATH=plan['metal_path'])
    command = ['bash',plan['native_generator'],str(R/'native-jit'),'/usr/bin/clang',str(R/'native'),'steel/attn/kernels/steel_attention']
    save('generate-steel.command.json',dict(argv=command,PATH=env['PATH'],generator=identity(plan['native_generator'])))
    result = subprocess.run(command,cwd=R,capture_output=True,text=True,env=env)
    (O/'generate-steel.stdout.log').write_text(result.stdout)
    (O/'generate-steel.stderr.log').write_text(result.stderr)
    save('generate-steel.result.json',dict(exit=result.returncode,output=identity(R/'native-jit/steel_attention.cpp') if result.returncode==0 else None))
    raise SystemExit(result.returncode)
if "--compile" in sys.argv:
    retained = []
    if "--products" in sys.argv or "--tests" in sys.argv:
        previous = json.loads((O / "compile-summary.json").read_text())["compiles"]
        for row in previous:
            is_test = "/tests/" in row["source"]["path"]
            if ("--products" in sys.argv and not is_test) or ("--tests" in sys.argv and is_test):
                continue
            assert row["exit"] == 0 and not row["source_drifts"]
            assert identity(row["source"]["path"]) == row["source"]
            assert all(identity(x["path"]) == x for x in row["dependencies"])
            retained.append(row)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        requested = [r for r in plan["compile"]
                     if ("--products" not in sys.argv or not r["source"].startswith("tests/"))
                     and ("--tests" not in sys.argv or r["source"].startswith("tests/"))]
        records = retained + list(pool.map(compile_one, requested))
    save("compile-summary.json", dict(compiles=records,
         passed=all(x["exit"] == 0 for x in records), SDK=False, NVCC=False))
    raise SystemExit(int(any(x["exit"] for x in records)))
records = json.loads((O / "compile-summary.json").read_text())["compiles"]
assert all(x["exit"] == 0 for x in records)
command = plan["link"].copy()
for row in records:
    if row["old_object"]:
        assert command.count(row["old_object"]) == 1
        command[command.index(row["old_object"])] = row["object"]
    else:
        command.insert(1, row["object"])
image = R / plan["image"]
command[command.index("-o") + 1] = str(image)
command = [("-Wl,-map," + str(image) + ".map")
           if x.startswith("-Wl,-map,") else x for x in command]
save("link-inputs.json", [identity(x) for x in command
     if Path(x).is_file() and Path(x).suffix in [".o", ".a", ".dylib"]])
result = execute("link", command)
if result["exit"]:
    raise SystemExit(2)
if "--link-only" in sys.argv:
    raise SystemExit(0)
metallib = R / "mlx.metallib"
if not metallib.exists():
    metallib.symlink_to(Path(plan["metallib"]).resolve())
result = execute("run", [str(image), "--gtest_filter=" + next((x.split("=",1)[1] for x in sys.argv if x.startswith("--filter=")), plan["filter"]),
                        "--gtest_output=xml:" + str(O / "tests.xml")])
cases = E.parse(O / "tests.xml").findall(".//testcase")
failed = [x.attrib for x in cases if x.findall("failure")]
skipped = [x.attrib for x in cases if x.findall("skipped")]
save("validation.json", dict(image=identity(image), tests=len(cases),
     failed=failed, skipped=skipped, exit=result["exit"],
     names=[x.get("classname") + "." + x.get("name") for x in cases],
     source_manifest=identity(R / "source-manifest.json")))
print("VALIDATION", len(cases), "failed", len(failed), "skipped", len(skipped), flush=True)
raise SystemExit(result["exit"])
