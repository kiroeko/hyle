from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path.cwd();O=R/'.scratch/dspark-stochastic-tails-20261024'
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
base=json.loads((R/'.scratch/dspark-random-mtp-20261024/link-command.json').read_text(encoding='utf-8'))
cc=json.loads((O/'formal/command.json').read_text(encoding='utf-8'))[0]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[];replaced=0
for a in base:
 if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
 if a.replace('\\','/').endswith('/dspark-random-mtp-20261024/consumer.obj'):a=str(O/'formal/consumer.obj');replaced+=1
 cmd.append(a)
assert replaced==1
cmd += [str(O/'policy/consumer.obj'),str(O/'prefix/consumer.obj'),'/OUT:'+str(O/'checks.exe'),'/IMPLIB:'+str(O/'checks.lib')]
reuse=(O/'image.json').exists()and json.loads((O/'image.json').read_text(encoding='utf-8'))['sha256']==hashlib.sha256((O/'checks.exe').read_bytes()).hexdigest()
if not reuse:
 (O/'link-command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8');start=time.monotonic()
 with(O/'link.log').open('wb')as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
 (O/'link-process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8');assert p.returncode==0,(O/'link.log').read_text(errors='replace')[-3000:]
runtime=json.loads((R/'.scratch/dspark-random-mtp-20261024/runtime.json').read_text(encoding='utf-8'))
env.update(runtime);env['PATH']=str(O)+';'+env['PATH']
worker=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
if not(O/worker.name).exists():os.link(worker,O/worker.name)
for k in list(env):
 if k.startswith('HYLE_DSPARK_')and'WAIT'in k:env[k]='0'
env['HYLE_DSPARK_FLASH_FRONTIER_FILE']=str(O/'missing-frontier.json')
(O/'runtime.json').write_text(json.dumps({k:v for k,v in env.items()if k.startswith('HYLE_DSPARK_')or k=='PATH'},indent=2),encoding='utf-8')
mode=sys.argv[1]if len(sys.argv)>1 else'policy';D=O/mode/'run';D.mkdir(exist_ok=True)
case='DSparkFlashFormalState.CpuRandomMarkovPrefixCommitsActualStateAndCursor'if mode=='formal'else'DSparkBlock5Policy.*:QwenMtpPrefix.*:QwenBatchSchedule.*:QwenSessionState.*:QwenPrefixCache.*'
cmd=[str(O/'checks.exe'),'--gtest_color=no','--gtest_filter='+case,'--gtest_output=xml:'+str(D/'results.xml')]
(D/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8')
sources=['tests/compute_models/dspark_pro_mtp_state_consumer_test.cc','tests/compute_models/dspark_stochastic_head.h','tests/compute_models/dspark_block5_policy.h','engine/inference/mtp_acceptance.h','engine/inference/sampling_graph.h','engine/inference/sampling_cursor.h']
identities=[]
for rel in sources:
 p=R/rel;q=O/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());identities.append(dict(path=rel,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(O/'sources.json').write_text(json.dumps(identities,indent=2),encoding='utf-8')
(O/'image.json').write_text(json.dumps(dict(path=str(O/'checks.exe'),bytes=(O/'checks.exe').stat().st_size,sha256=hashlib.sha256((O/'checks.exe').read_bytes()).hexdigest()),indent=2),encoding='utf-8')
start=time.monotonic()
with(D/'stdout.log').open('wb')as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=600)
(D/'process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8')
print(mode,p.returncode,(D/'stdout.log').read_text(encoding='utf-8',errors='replace')[-3000:])
