from pathlib import Path
import json,subprocess,sys,time
R=Path.cwd();O=R/'.scratch/dspark-stochastic-tails-20261024';O.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
mode=sys.argv[1]if len(sys.argv)>1 else'formal'
templates={'formal':'.scratch/dspark-random-mtp-20261024/compile-command.json','formal-syntax':'.scratch/dspark-random-mtp-20261024/compile-command.json','sidecar-syntax':'.scratch/dspark-sidecar-random-20261024/compile-command.json','policy':'.scratch/dspark-random-mtp-20261024/compile-command.json','prefix':'.scratch/dspark-random-mtp-20261024/compile-command.json'}
sources={'formal':'tests/compute_models/dspark_pro_mtp_state_consumer_test.cc','formal-syntax':'tests/compute_models/dspark_pro_mtp_state_consumer_test.cc','sidecar-syntax':'tests/compute_models/dspark_original_state_consumer_test.cc','policy':'tests/compute_models/dspark_block5_policy_test.cc','prefix':'tests/tools/qwen_prefix_cache_test.cc'}
base=json.loads((R/templates[mode]).read_text(encoding='utf-8'));D=O/mode;D.mkdir(exist_ok=True)
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':base[0],'CMAKE_CXX_COMPILER':base[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[];skip=False
for a in base:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.startswith(('/Fo','/Fd'))or a=='/Zs'or a.endswith('.cc'):continue
 cmd.append(a)
cmd+=[str(R/sources[mode])]
cmd+=['/Zs']if mode.endswith('-syntax')else['/Fo'+str(D/'consumer.obj'),'/Fd'+str(D/'consumer.pdb'),'/sourceDependencies',str(D/'dependencies.json')]
(D/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8');start=time.monotonic()
with(D/'stdout.log').open('wb')as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
(D/'process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8')
print(mode,p.returncode,(D/'stdout.log').read_text(encoding='utf-8',errors='replace')[-6000:])
