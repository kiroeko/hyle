"""Archive existing root-run CUDA Q8 results; never run a model or build."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[2]
B=Path(__file__).resolve().parent
S=R/'.scratch/qwen35-unsloth-mtp-20261024/Qwen3.5-2B-UD-Q8_K_XL'
I=R/'.scratch/qwen35-unsloth-mtp-20261024/complete-v2/Q8'
C=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1'
P=R/'.scratch/qwen-multi-draft-20261024/current-runtime-plans/Q8.json'
D=R/'docs/evidence/correctness/mtp-qwen35-q8-original-cuda-complete-input-2026-10-24.json'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
plan=load(P);runtime=load(C/'current-image.json');source=load(S/'payload-role-files.json');prepared=load(I/'input.json');receipt=load(S/'payload-acquisition.json')
assert source['complete']and source['source']['full_file_sha256_verified']and receipt['complete']and len(source['roles'])==335
inventory=load(R/plan['report_inventory']['path'])
head=next(x for x in inventory['roles']if x['physical_name']=='token_embd.weight')
assert head['storage']['dtype']=='F16'and prepared['geometry']['tied_head']
cases=[]
for name in ['cuda-ordinary','cuda-k4-random']:
 folder=I/'current-runtime-runs'/name
 report=[json.loads(x)for x in(folder/'stdout.log').read_text().splitlines()if x.startswith('{')][-1]
 process=load(folder/'process.json');result=load(folder/'functional-result.json');command=load(folder/'command.json')
 assert process['exit']==0 and result['native_exit']==0 and result['image']==runtime['runtime']['image']
 assert report['backend']=='cuda'and report['original_host_weight_bytes']==0 and report['cache_peak_requested_bytes']<=268435456
 assert report['weight_count_scope']=='selected_physical_roles'and report['text_tensors']==320 and report['mtp_tensors']==(15 if name=='cuda-k4-random'else 0)
 assert report['source_id']==prepared['source_id']and report['score_dtype']=='F32'
 cases.append(dict(case=name,status='PASS',process=process,functional_result=result,score_dtype=report['score_dtype'],committed_target_rows=report['committed_target_rows'],sampling_draw_cursor=report['sampling_draw_cursor'],draft_frontier=report.get('draft_frontier'),draft_lag=report.get('draft_lag'),consumed_drafts=report['consumed_drafts'],native_execution_private_bytes_unknown=report['native_execution_private_bytes_unknown'],actual_report=ident(folder/'stdout.log')))
assert cases[1]['consumed_drafts']==4 and cases[1]['sampling_draw_cursor']==10 and cases[1]['draft_lag']==1
proof=dict(status='PASS',date='2026-10-24',scope='Two existing root-run complete original Qwen3.5-2B UD-Q8_K_XL CUDA functional journeys: ordinary greedy and natural K4 random MTP.',source=source['source'],original_role_count=335,original_payload_bytes=2882151680,prepared=ident(I/'input.json'),manifest=ident(I/'weights.tsv'),runtime=runtime['runtime'],frozen_main=runtime['main'],geometry=dict(prompt_tokens=154,context_capacity=256,cache_requested_byte_limit=268435456,ordinary_maximum_outputs=4,mtp_maximum_outputs=6,mtp_maximum_drafts=4,random_top_k=8,random_top_p=0.9,random_seed=123),score_contract=dict(actual_report_policy=cases[0]['functional_result']['score_policy'],output_dtype='F32',tied_head=True,original_physical_head='token_embd.weight',original_head_storage=head['storage'],arithmetic='Recipe::scores starts from BF16 model activations; for the original F16 tied head it explicitly casts activation rows to F32, uses DenseLinearF32 with original F16 weights and publishes F32 logits. No whole-bank head conversion is asserted.',frozen_source=runtime['main'],source_lines=[633,635,645,651,657,658,659]),cases=cases,role_counts=dict(scope='selected_physical_roles',main=320,mtp_when_enabled=15),cache_limit_is_total_physical_VRAM_limit=False,model_runs_represented=2,new_model_runs_by_archivist=0,additional_HTTP_by_archivist=0,additional_builds_by_archivist=0,additional_SDK_builds=0,automatic_model_retry=False,performance_claim=False,limitations=['These are two finite complete-input functional journeys, not throughput measurements or complete generation-task quality validation.','The executable was already frozen and built from one current application TU with the retained SDK/object closure; this archive task performed no build and does not certify a fresh full SDK/install.','The finite requested cache-byte cap is distinct from total physical VRAM occupancy.','Source and prepared-role identities are shared with the separately published pure CPU Q8 journeys; this evidence covers the two CUDA cases only.'])
files=[]
def add(p):
 if p.is_file()and p not in files:files.append(p)
for name in ['payload-role-files.json','payload-acquisition.json']:add(S/name)
for name in ['input.json','weights.tsv','prompt.ids']:add(I/name)
for case in ['cuda-ordinary','cuda-k4-random']:
 for name in ['command.json','process.json','stdout.log','stderr.log','functional-result.json']:add(I/'current-runtime-runs'/case/name)
for name in ['current-image.json','sources.json','shared-object-dependencies.json','compile-command.json','compile-process.json','link-command.json','link-process.json','future-plan-audit.json']:add(C/name)
for p in sorted((C/'source').rglob('*')):
 if p.is_file()and p.suffix in ['.h','.cc']:add(p)
for p in [Path(__file__).resolve(),P,R/'.scratch/qwen-multi-draft-20261024/current-runtime-ready.py',R/'.scratch/qwen35-unsloth-mtp-20261024/run-original-ready.py',R/'.scratch/qwen35-unsloth-mtp-20261024/run-ready-v2.py',R/plan['report_inventory']['path'],R/runtime['builder']['path'],R/runtime['runtime']['environment']['path'],R/'docs/evidence/correctness/mtp-qwen35-q8-original-pure-cpu-complete-input-2026-10-24.json']:add(p)
proof['files']=[ident(p)for p in files]
archive=D.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 z.writestr('result.json',json.dumps(proof,indent=2,allow_nan=False)+'\n')
 for p in files:
  assert p.stat().st_size<4000000
  z.write(p,p.relative_to(R).as_posix())
proof['archive']=ident(archive)
with D.open('x')as f:json.dump(proof,f,indent=2,allow_nan=False);f.write('\n')
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 assert not any(Path(x).suffix.lower()in ['.exe','.dll','.obj','.lib','.bin','.safetensors','.gguf']for x in z.namelist())
print(json.dumps(dict(evidence=str(D),archive=proof['archive'],cases=[dict(name=x['case'],status=x['status'],ids=x['functional_result']['generated_ids'],draw_cursor=x['sampling_draw_cursor'])for x in cases],files=len(files),zip_CRC='PASS')))
