"""Compile one existing CPU test TU and run one composed MLA producer case."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
BASE = ROOT / '.scratch/inference-f32-append-20261025/cpu1'
spec = importlib.util.spec_from_file_location('finite_helpers', ROOT / '.scratch/inference-e4-append-implementation-20261025/check_finite.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
read, save, pin, execute = helper.read, helper.save, helper.pin, helper.execute
SOURCE = 'tests/graph_batch/typed_capability_graph_test.cc'
FILTER = 'TypedCapabilityGraph.EncodedCompactMlaAppendKeepsSingleBankStrideAndOriginalReaders'

def project(path):
    try:
        return path.resolve().relative_to(ROOT).parts[0] in {'include', 'src', 'tests', 'engine'}
    except (ValueError, IndexError):
        return False

def canonical(path):
    path = path.resolve()
    if path.is_relative_to(ROOT / '.scratch') and 'source' in path.parts:
        candidate = ROOT.joinpath(*path.parts[path.parts.index('source') + 1:])
        if candidate == ROOT or project(candidate):
            return candidate
    return path

def main():
    out = WORK / (sys.argv[1] if len(sys.argv) == 2 else 'cpu1')
    assert out.parent == WORK and re.fullmatch(r'cpu[0-9]+', out.name)
    assert not out.exists(), 'Do not overwrite an actual attempt'
    # These are the existing source-matched arena/append objects in the link.
    for item in read(BASE.parent / 'source-pins.json')['files']:
        if item['path'] != SOURCE:
            assert pin(ROOT / item['path'])['sha256'] == item['after']['sha256'], item['path']
    original = read(BASE / 'compile/cpu-test/command.json')['command']
    search = [ROOT / 'include', ROOT, ROOT / 'tests/graph_batch', ROOT / 'tests/compute_models']
    for arg in original:
        parsed = helper.include_path(arg)
        if parsed:
            search.append(canonical(parsed[1]))
    tree = out / 'source'
    pending, seen, frozen = [SOURCE], set(), []
    while pending:
        rel = pending.pop()
        if rel in seen:
            continue
        seen.add(rel)
        source = ROOT / rel
        raw = source.read_bytes()
        target = tree / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        frozen.append({'relative': rel, 'canonical': pin(source), 'frozen': pin(target)})
        for inc in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]', raw.decode('utf-8-sig'), re.M):
            for directory in [source.parent, *search]:
                child = (directory / inc).resolve()
                if child.is_file():
                    if project(child):
                        pending.append(child.relative_to(ROOT).as_posix())
                    break
    save(out / 'frozen-project.json', frozen)
    compiler, flags, skip = original[0], [], False
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        parsed = helper.include_path(arg)
        if parsed:
            path = canonical(parsed[1])
            if path == ROOT or project(path):
                path = tree / path.relative_to(ROOT)
            arg = parsed[0] + str(path)
        flags.append(arg)
    flags = ['/I' + str(tree / 'include'), '/I' + str(tree), *flags]
    assert '/W4' in flags and '/WX' in flags
    env = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    obj = out / 'compile/unit.obj'
    command = [compiler, *flags, str(tree / SOURCE), '/sourceDependencies', str(out / 'compile/dependencies.json'), '/Fo' + str(obj)]
    compiled = execute(command, env, out / 'compile')
    if compiled['exit']:
        save(out / 'summary.json', {'status': 'COMPILE_FAILED_NO_RUN', 'compile': compiled})
        return 1
    deps = read(out / 'compile/dependencies.json')['Data']
    paths = [Path(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    assert not any(project(p) for p in paths), 'Unfrozen canonical source dependency'
    save(out / 'actual-dependencies.json', [pin(p) for p in paths])
    link = read(BASE / 'link/command.json')['command']
    old = str(BASE / 'compile/cpu-test/unit.obj')
    assert link.count(old) == 1
    args = [str(obj) if a == old else a for a in link if not a.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
    save(out / 'link-inputs.json', [pin(Path(a)) for a in args[1:] if Path(a).is_absolute() and Path(a).suffix.lower() in {'.obj', '.lib'}])
    image = out / 'link/component.exe'
    linked = execute([*args, '/OUT:' + str(image), '/PDB:' + str(image.with_suffix('.pdb'))], env, image.parent)
    if linked['exit']:
        save(out / 'summary.json', {'status': 'LINK_FAILED_NO_RUN', 'compile': compiled, 'link': linked})
        return 1
    native = ROOT / '.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
    assert pin(native)['sha256'] == '1066e80261cc58d1c0ea57e50475e2e38b7675b666eb2b639969e01e85916a46'
    os.link(native, image.parent / native.name)
    runtime = read(native.parents[1] / 'runtime-environment.json')
    runenv = dict(env, PATH=str(image.parent) + ';' + runtime['PATH'], HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    save(out / 'runtime.json', {'PATH': runenv['PATH'], 'native': pin(native)})
    ran = execute([str(image), '--gtest_filter=' + FILTER, '--gtest_output=xml:' + str(out / 'tests.xml')], runenv, out / 'run')
    facts = {}
    if (out / 'tests.xml').exists():
        xml = ET.parse(out / 'tests.xml').getroot()
        facts = {k: int(xml.attrib.get(k, '0')) for k in ('tests', 'failures', 'errors')}
        facts['skipped'] = sum(int(s.attrib.get('skipped', '0')) for s in xml.findall('testsuite'))
    passed = ran['exit'] == 0 and facts == dict(tests=1, failures=0, errors=0, skipped=0)
    for entry in frozen:
        assert pin(ROOT / entry['relative']) == entry['canonical'], 'Sources changed during check'
    summary = {'status': 'PASS' if passed else 'TEST_FAILED', 'compile': compiled, 'link': linked,
        'run': ran, 'xml': facts, 'frozen_files': len(frozen), 'native': pin(native),
        'new_CPU_test_TUs': 1, 'core_provider_SDK_rebuilds': 0, 'GPU_or_model_runs': 0, 'HTTP': 0}
    save(out / 'summary.json', summary)
    print(json.dumps(summary), flush=True)
    return int(not passed)

if __name__ == '__main__':
    sys.exit(main())
