"""Publish the completed finite CT21 CPU check; no compilation or inference."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/correctness'
STEM = 'ct21-selected-source-2026-10-25'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def pin(path):
    return {'path': path.relative_to(ROOT).as_posix(), **digest(path.read_bytes())}

scope = read(WORK / 'scope.json')
pins = read(WORK / 'source-pins.json')
cpu1 = read(WORK / 'cpu1/summary.json')
cpu2 = read(WORK / 'cpu2/summary.json')
review = read(WORK / 'independent-review-architecture.json')
assert pins['revision'] == 3 and cpu2['source_revision'] == 3
assert cpu1['source_revision'] == 2 and cpu1['status'] == 'TEST_FAILED'
assert cpu1['compile']['exit'] == cpu1['link']['exit'] == 0
assert cpu1['run']['exit'] == 1 and cpu1['xml']['failures'] == 1
assert b'graph-owned or borrowed output has no independent storage lease' in (WORK / 'cpu1/run/stdout.log').read_bytes()
assert cpu2['status'] == 'PASS'
assert cpu2['xml'] == {'tests': 1, 'failures': 0, 'errors': 0, 'skipped': 0}
assert all(cpu2[stage]['exit'] == 0 for stage in ('compile', 'link', 'run'))
command = read(WORK / 'cpu2/compile/command.json')['command']
assert '/W4' in command and '/WX' in command
case = ET.parse(WORK / 'cpu2/tests.xml').getroot().find('testsuite/testcase')
assert case.attrib['name'] == 'IndependentKimiSourceBanksMapBeforeSharedProjectionAndKeepOldResults'
properties = {p.attrib['name']: p.attrib['value'] for p in case.findall('properties/property')}
assert properties['successful_graph_submissions'] == '2'
assert properties['expected_missing_global_map_completion_failures'] == '1'
assert 'generated fixture only' in properties['source_value_scope']
frozen = {p['relative']: p for p in read(WORK / 'cpu2/frozen-project.json')}
base_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
for item in pins['files']:
    path = item['path']
    assert digest((ROOT / path).read_bytes()) == item['after']
    assert digest(Path(frozen[path]['frozen']['path']).read_bytes()) == item['after']
    if item['before']['exists']:
        before = subprocess.check_output(['git', 'show', base_commit + ':' + path], cwd=ROOT)
        assert digest(before) == {k: item['before'][k] for k in ('bytes', 'sha256')}
    else:
        found = subprocess.run(['git', 'cat-file', '-e', base_commit + ':' + path], cwd=ROOT, capture_output=True)
        assert found.returncode != 0
assert cpu2['candidate_pins']['sha256'] == digest((WORK / 'source-pins.json').read_bytes())['sha256']
assert review['status'] == 'SOURCE_ONLY_NO_BLOCKER_FOUND' and review['revision'] == 2

header = ROOT / '.scratch/architecture-refactor-2026-10-18/fixed-role-binding-2026-10-21/kimi/21/headers/model-00002-of-000096.safetensors/header.json'
assert digest(header.read_bytes()) == scope['source']['header']
original = read(header)
excerpt = {'repository': scope['source']['repository'], 'revision': scope['source']['revision'],
           'file': scope['source']['file'], 'header': pin(header), 'data_start': 794592,
           'value_scope': 'Cached original header metadata only; all tested bodies are explicitly generated fixture values.',
           'roles': []}
for role in scope['source']['roles']:
    entry = original[role['name']]
    assert entry == {k: role[k] for k in ('dtype', 'shape', 'data_offsets')}
    assert role['file_offsets'] == [x + excerpt['data_start'] for x in entry['data_offsets']]
    excerpt['roles'].append(role)

members, origins = {}, {}
def add_raw(name, raw, origin):
    assert name not in members
    assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})', raw), name
    members[name] = raw
    origins[name] = origin

def add(name, path):
    assert path.is_file(), path
    assert path.suffix.lower() not in {'.obj', '.lib', '.dll', '.exe', '.pdb', '.bin', '.safetensors', '.gguf', '.tar', '.gz'}
    add_raw(name, path.read_bytes(), path.relative_to(ROOT).as_posix())

for label, directory in [('r2', WORK / 'r2'), ('r3', WORK)]:
    for filename in ('source.patch', 'source-pins.json', 'scope.json'):
        add('candidate/' + label + '/' + filename, directory / filename)
add('candidate/r2-to-r3.patch', WORK / 'r2-to-r3.patch')
add('review/independent-review-architecture-r2.json', WORK / 'independent-review-architecture.json')
for item in pins['files']:
    add('final-source/' + item['path'], ROOT / item['path'])
add('commands/check_cpu.py', WORK / 'check_cpu.py')
add('commands/check_finite.py', ROOT / '.scratch/inference-e4-append-implementation-20261025/check_finite.py')
add('commands/archive-proof.py', Path(__file__).resolve())
add('commands/runner-plan.json', WORK / 'runner-plan.json')
add_raw('source/original-header-eight-role-excerpt.json', (json.dumps(excerpt, indent=2) + '\n').encode(), pin(header)['path'] + ' (eight named roles only)')
for attempt in ('cpu1', 'cpu2'):
    for path in sorted((WORK / attempt).rglob('*')):
        if not path.is_file() or 'source' in path.relative_to(WORK / attempt).parts:
            continue
        if path.suffix.lower() in {'.json', '.log', '.xml'}:
            add('actual/' + attempt + '/' + path.relative_to(WORK / attempt).as_posix(), path)
index = (json.dumps({'members': [{'member': name, 'original_path': origins[name], **digest(raw)}
                                for name, raw in sorted(members.items())],
                     'exclusions': 'No SDK, binary, model body, credentials or full frozen include tree.'}, indent=2) + '\n').encode()
archive = DEST / (STEM + '.zip')
report_path = DEST / (STEM + '.json')
assert not archive.exists() and not report_path.exists(), 'Do not silently overwrite published proof'
DEST.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, raw in sorted({**members, 'member-sha256.json': index}.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        output.writestr(info, raw, compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    assert len(output.namelist()) == len(members) + 1
    assert output.read('member-sha256.json') == index
    for name, raw in members.items():
        assert digest(output.read(name)) == digest(raw), name
assert archive.stat().st_size < 1024 * 1024

report = {
    'status': 'CT21_SELECTED_SOURCE_SHARED_PROJECTION_TWO_GENERATIONS_CPU_FIXTURE_PASS',
    'date': '2026-10-25', 'base_commit': base_commit,
    'sources_scope': 'Original baseline commit to r3 final two-path diff; r2 preparation and original failed run remain separately labelled in ZIP.',
    'sources': pins['files'],
    'change': 'Finite caller-side adapter binds independent ready E4 W and BF16 SF source roles to existing same-generation CpuSupply W/SF/map banks and unchanged shared CT block128 projection. Checked global-to-local Gather precedes selected decode. No new op, owner, loader, registry or executor.',
    'source': {'repository': excerpt['repository'], 'revision': excerpt['revision'], 'shard': excerpt['file'],
               'header': excerpt['header'], 'roles': 8, 'experts': [0, 1, 2, 3],
               'spans': 'source/original-header-eight-role-excerpt.json in ZIP records exact original names, dtypes, shapes, data-relative and file-relative spans.',
               'body_qualification': 'Original publisher W/SF body bytes were not cached or numerically qualified; generated fixture identity remains explicit.'},
    'geometry': {'projection': 'Layer1 expert W1 only; full N3072/K3584, E4 W[3072,3584], BF16 SF[24,28], block128.',
                 'tokens': 1, 'slots_per_token': 2, 'global_domain': 896, 'selected_capacity': 2,
                 'generations': [[0, 1], [2, 3]], 'output': 'BF16[1,2,3072], 12288 bytes per result.',
                 'precision': 'Existing activation group128 CT E4 QDQ; BF16 E4*SF weight product and original BF16 operand/store boundaries; existing projection accumulation/output policy.'},
    'actual_CPU': {**cpu2, 'gtest_case_seconds': float(case.attrib['time']),
                   'successful_Graph_submissions': 2, 'expected_missing_global_Completion_failures': 1,
                   'compile_contract': '/W4 /WX; one existing test TU replaced, cached current core/provider/native closure reused.',
                   'numeric_oracle': 'Independent scalar activation group128 reference plus per-row BF16 E4*SF, existing full-K F64 dot/F32 certificate and BF16 output interval. All28 K groups and24 N blocks participate; no whole-domain floating bank.',
                   'source_and_generation': 'Exact W/SF byte equality after upload; original host mappings/roles close before execution. Each Invocation binds W/SF/map readers from one CpuBatch; reversed global IDs exercise map selection.',
                   'retirement': 'Six bank blocks before release, six after CpuBatch handles drop, zero after Invocation reset; independent old/new outputs remain byte-identical after constants/compiled owners reset.',
                   'negative': 'Global0 is valid in the domain but absent from generation1. Checked map yields a Completion failure, no result and no allowed resubmit; saved old results remain unchanged.'},
    'first_attempt': {**cpu1,
                      'reason': 'The shared projection ends in a Graph-owned reshape; storage_lease correctly refused independent export before the numeric oracle. This was a consumer export error, not a numeric or Compute/Graph defect.',
                      'preservation': 'Original r2 patch/pins, commands, raw stdout/stderr, XML, actual dependencies and frozen-project pins are retained in ZIP.'},
    'r3_export_fix': {'change': 'One explicit terminal Copy materializes the 12KiB BF16 consumer result so an independent output lease survives bank/Invocation teardown.',
                      'scope': 'Caller export boundary only. Shared mathematics, GraphOutput permissions, precision and routing are unchanged; no performance optimization or speedup claim.',
                      'delta': pin(WORK / 'r2-to-r3.patch')},
    'review': {'status': review['status'], 'revision': 2, 'pin': pin(WORK / 'independent-review-architecture.json'),
               'scope': 'Independent r2 source/shape/span/same-generation/math/ownership review. The later root-reviewed r3 delta is separately recorded as terminal Copy only; r2 review alone is not evidence of r3 execution.',
               'shared_math_unchanged': review['shared_math']},
    'not_claimed': ['Original publisher numeric bodies, complete artifact/FFN/router or whole-Model qualification.',
                    'T>1, S other than2, additional source experts or new GPU/Apple/Vulkan execution.',
                    'Quality, native device faults, TPS, speedup or measured peak RAM/VRAM.'],
    'archive': {**pin(archive), 'members': len(members) + 1,
                'CRC_and_member_SHA256_verified': True, 'index': 'member-sha256.json',
                'no_SDK_binary_model_or_full_frozen_tree_payloads': True}}
report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'report': pin(report_path), 'archive': pin(archive), 'members': len(members) + 1,
                  'actual_tests': cpu2['xml'], 'first_failure_preserved': True}, indent=2))
