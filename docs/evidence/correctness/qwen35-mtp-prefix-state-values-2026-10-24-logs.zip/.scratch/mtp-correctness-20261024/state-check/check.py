from pathlib import Path
import importlib.util,json,os,subprocess,sys,time
O=Path(__file__).resolve().parent;R=O.parents[2];W=R/'.scratch/qwen-multi-draft-20261024';E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check'
spec=importlib.util.spec_from_file_location('focused_local_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def execute(command,env,folder,timeout):
 folder.mkdir(parents=True,exist_ok=True);(folder/'tmp').mkdir(exist_ok=True);env=dict(env,TEMP=str(folder/'tmp'),TMP=str(folder/'tmp'))
 b.save(folder/'command.json',command);print('START',folder.relative_to(R),flush=True);start=time.time()
 with (folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:p=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt'else 0)
 b.save(folder/'process.json',dict(exit=p.returncode,seconds=time.time()-start));print('END',folder.name,p.returncode,flush=True)
 if p.returncode:raise RuntimeError('Failed; see '+str(folder))
def build(backend):
 previous=W/('geometry-'+backend+'-check'+('2'if backend=='cpu'else'1'));command=b.read(previous/'compile-command.json');native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=())
 folder=O/backend;source=R/'tests/tools/qwen_mtp_prefix_value_probe.cc';obj=folder/'test.obj';flags=[];skip=False
 for a in command:
  if skip:skip=False;continue
  if a=='/sourceDependencies':skip=True;continue
  if a.startswith(('/Fo','/Fd'))or a.lower().endswith('.cc'):continue
  flags.append(a)
 snapshot=[b.identity(p)for p in [source,R/'engine/models/qwen35/main.cc',R/'engine/models/qwen35/mtp_session_probe.cc',*sorted((R/'engine/models/qwen35').glob('*.h'))]]
 execute([*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(folder/'test.pdb')],native.env,folder/'compile',180)
 for p in snapshot:b.require(p)
 link=[]
 for a in b.read(previous/'link-command.json'):
  if a.startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))or Path(a).resolve()==(previous/'test.obj').resolve():continue
  if Path(a).name=='graph--executable.obj':a=str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj')
  link.append(a)
 image=folder/'prefix-values.exe';link +=[str(obj),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 execute(link,native.env,folder/'link',120);ready=b.read(E/('ready-'+backend+'.json'));runtime=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll';staged=folder/runtime.name
 if not staged.exists():os.link(runtime,staged)
 if b.identity(runtime)['sha256']!='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f' or b.identity(staged)['sha256']!=b.identity(runtime)['sha256']:raise ValueError('Wrong staged CPU runtime')
 b.save(folder/'ready.json',dict(image=b.identity(image),PATH=str(folder)+os.pathsep+ready['PATH'],sources=snapshot,prior_closure=b.identity(previous/'link-command.json'),SDK_builds=0,HTTP=0))
def run(backend):
 folder=O/backend;ready=b.read(folder/'ready.json');b.require(ready['image']);inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
 execute([ready['image']['path'],str(inputs)],dict(os.environ,PATH=ready['PATH']),folder/'run',240)
 print((folder/'run/stdout.log').read_text(encoding='utf8',errors='replace')[-5000:],flush=True)
if __name__=='__main__':
 action,backend=sys.argv[1:3]
 if action in('build','all'):build(backend)
 if action in('run','all'):run(backend)
