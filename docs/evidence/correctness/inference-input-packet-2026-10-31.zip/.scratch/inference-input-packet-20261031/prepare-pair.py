"""Prepare the two authorized normal CLI correctness commands, execute none."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=W.parent.parent;B=R/'.scratch/build-compute-v2-dev'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve();raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
original=R/'.scratch/inference-default-product-window-20261031/peer-window/two-turn-timing-plan.json'
row=next(x for x in read(original)['commands'] if x['arm']=='hyle_auto')
control=read(W/'control/control-ready.json')['image'];actual=read(W/'build/attempt2/receipt.json')['image']
for image in (control,actual):assert pin(image['path'])==image
commands=[]
for name,image in [('control',control),('candidate',actual)]:
    trace=W/'normal-pair'/name/'trace'
    command=[image['path'],*row['command'][1:],'--trace',str(trace),'--trace-level','full']
    commands.append({'arm':name,'image':image,'command':command,'trace':str(trace)})
value={'status':'PREPARED_ONLY_RUN_CONDITION_ALL_SEVEN_TINY_PASS','source_command_plan':pin(original),
       'commands':commands,'normal_shared_environment':pin(R/'.scratch/inference-default-product-build-20261031/environment.json'),
       'control_ready':pin(W/'control/control-ready.json'),'candidate_receipt':pin(W/'build/attempt2/receipt.json'),
       'product_freeze':pin(W/'source-freeze.json'),'native_processes':2,'automatic_retries':0,'downloads':0,'peer_runs':0,
       'comparison':'All non-time JSON fields including sampling_stream/draw_cursor; complete logits/hidden/GDN/conv file bytes and KV-layout metadata. Preserve actual work/capture/relay differences, do not hide them.',
       'state_scope_limit':'CLI full trace does not export complete logical KV, carry/prior or RNG raw Session blobs. It cannot establish full 2B Session-byte equality; tiny history/HostImage tests separately check their original complete state/RNG contracts.',
       'measurement_limit':'Traced finite correctness and coarse obvious-regression observation only, not an uninstrumented throughput or peer comparison.',
       'runtime_scope':'Normal bin first PATH; actual module snapshots and current control37 pin readback, not assumed relocated CPU support.'}
(W/'normal-pair-plan.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'native_processes':2,'runs_started':0,'full_2B_Session_blob_claim':False}))
