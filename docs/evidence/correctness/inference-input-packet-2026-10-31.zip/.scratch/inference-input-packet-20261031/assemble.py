from pathlib import Path
import hashlib, json, zipfile

W = Path(__file__).resolve().parent
R = W.parent.parent
P = R / '.scratch/inference-input-packet-review-20261031'
DEST = R / 'docs/evidence/correctness/inference-input-packet-2026-10-31'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

assert read(W / 'root-readback.json')['status'] == 'PASS_INDEPENDENT_ROOT_READBACK'
assert read(W / 'tiny-summary.json')['status'] == 'PASS_SEVEN_SERIAL'
assert read(W / 'normal-pair/summary.json')['status'] == 'PASS_TWO_NORMAL_CLI_LIMITED_STATE_BYTES'
assert (W / 'finite-results.json').is_file()

files = []
for base in (W, P):
    for path in base.rglob('*'):
        if not path.is_file() or path.suffix not in ('.json', '.log', '.patch', '.md', '.py', '.txt'):
            continue
        parts = path.relative_to(base).parts
        if any(part in ('trace', 'tmp', '__pycache__') for part in parts):
            continue
        if path.name == 'archive-manifest.json':
            continue
        files.append(path)
files += [R / '.scratch/inference-default-product-build-20261031/environment.json',
          R / '.scratch/inference-default-product-build-20261031/inspect-smoke.py']
files = sorted(set(files))
archive_manifest = [pin(path) for path in files]
save(W / 'archive-manifest.json', archive_manifest)
files.append(W / 'archive-manifest.json')
archive = DEST.with_suffix('.zip')
if archive.exists():
    assert pin(archive) == {k: v for k, v in read(DEST.with_suffix('.json'))['archive'].items()
                            if k in ('path', 'bytes', 'sha256')}
archive_work = W / 'evidence-next.zip'
assert not archive_work.exists()
with zipfile.ZipFile(archive_work, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in files:
        output.write(path, path.relative_to(R).as_posix())
archive_work.replace(archive)

source_paths = ['engine/models/qwen35/main.cc', 'engine/models/qwen35/phase.h',
    'engine/models/qwen35/phase_preparation.cc', 'engine/models/qwen35/input_packet.h',
    'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_input_packet_case.h', 'tests/CMakeLists.txt']
result = {
    'schema': 'hyle.inference.input-packet.v1',
    'status': 'CURRENT_FINITE_CHECKS_PASS',
    'base_commit': 'f3173816059d6023af3958d276b8521a77ed4b3e',
    'full_goal_complete': False,
    'source_pins': [pin(R / name) for name in source_paths],
    'change': 'One original per-Phase/slot Tensor packet with exact token/position views and one synchronous write; private non-imported ordinary dense CPU/CUDA path only.',
    'ownership': 'Original carrier borrow, Source, transactions and actual retirement remain authoritative. No second execution/retirement authority, SDK contract or public engine option added.',
    'memory': 'Padding and system-resource host staging are real charges: R1/T1 packet requests 260 bytes instead of two payloads totaling 8 bytes, plus 260 host-staging bytes. Physical allocation rounding/VRAM is not established.',
    'fallback': 'Only nonnative cold allocation ResourceExhausted can select the original independent Tensor path; runtime/native/map errors propagate. Candidate charges are released before mandatory allocations.',
    'checks': {
        'tiny_current_passes': 7, 'tiny_historical_failures': 2,
        'normal_2B_CLI_passes': 2, 'normal_2B_outputs_per_arm': 128,
        'non_time_differences': 0,
        'trace_files_per_arm': 4998, 'trace_bytes_per_arm': 2628644941,
        'all_exported_trace_bytes_equal': True,
        'independent_root_readback': pin(W / 'root-readback.json'),
        'finite_results': pin(W / 'finite-results.json'),
        'normal_product_SDK_CXX': 0, 'NVCC': 0, 'downloads': 0},
    'history': [
        'First normal CXX failed on two unqualified BackendKind enumerators; exact narrow qualification fixed them.',
        'First large host-test CXX exceeded COFF sections; MSVC /bigobj now belongs to the formal test target and passed in the real fixture.',
        'First CPU native failed on relocated fixture runtime lookup; the same EXE was staged beside existing runtime DLLs without copying the SDK.',
        'Second CPU native exposed missing original cold-use plans in the new fixture; plans were added before any Phase. Core behavior and assertions were retained.',
        'Phony Ninja dry-run prediction, unsupported debug-option attempt and pre-link wrapper guard incidents remain in archived receipts.'],
    'limits': [
        'The new packet case submits no Graph; actual ordinary/packed/HostImage consumers are separate finite checks.',
        'Injected partial writes and native-bearing statuses use a CPU MemoryResource seam, not a real CUDA driver-fault injection.',
        'System map/flush/close faults were not injected.',
        'CLI full trace omits complete logical KV, carry/prior and raw RNG Session blobs; full 2B Session-byte equality is not claimed.',
        'Tiny complete HostImage/RNG checks do not extend the complete-state claim to the full 2B model.',
        'MSVC target option and CPU/CUDA CTest registration were statically reviewed; the normal cache keeps tests OFF, so formal CTest configuration was not rerun.',
        'Live module snapshots retain EnumProcessModulesEx errors; post-exit file hashes are not loader-event or mapped-byte tracing.',
        'Default R1 steady relay already uploads positions once; this slice proves no steady relay speedup. Other metadata/readback and cross-turn capture remain open.'],
    'performance_claim': False,
    'measurement_scope': 'Two traced normal CLI correctness runs and coarse regression observation; no uninstrumented throughput or peer window.',
    'patch': pin(W / 'verified-source.patch'),
    'archive': {**pin(archive), 'members': len(files), 'raw_trace_payloads_included': False}
}
save(DEST.with_suffix('.json'), result)
print(json.dumps({'evidence': str(DEST.with_suffix('.json')), 'archive': result['archive']}, ensure_ascii=False))
