"""Exactly two authorized normal CLI correctness runs, after seven tiny pass."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parent.parent;B=R/'.scratch/build-compute-v2-dev'
spec=importlib.util.spec_from_file_location('packet_current_driver',W/'run.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
read,save,pin=driver.read,driver.save,driver.pin
def non_time(v):
    if isinstance(v,dict):return {k:non_time(x) for k,x in v.items() if not k.endswith(('_seconds','_tokens_per_second'))}
    if isinstance(v,list):return [non_time(x) for x in v]
    return v
def delta(a,b,path='$'):
    if isinstance(a,dict) and isinstance(b,dict):
        return [row for key in sorted(a.keys()|b.keys()) for row in delta(a.get(key),b.get(key),path+'.'+key)]
    if isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b):return [{'path':path,'old_length':len(a),'new_length':len(b)}]
        return [row for i,(x,y) in enumerate(zip(a,b)) for row in delta(x,y,path+f'[{i}]')]
    return [] if a==b else [{'path':path,'old':a,'new':b}]
def run():
    assert read(W/'tiny-summary.json')['status']=='PASS_SEVEN_SERIAL'
    plan=read(W/'normal-pair-plan.json');driver.check_product();driver.check_tests()
    spec=importlib.util.spec_from_file_location('packet_normal_observer',R/'.scratch/inference-default-product-build-20261031/inspect-smoke.py')
    sample=importlib.util.module_from_spec(spec);spec.loader.exec_module(sample)
    sample.HERE=W/'normal-pair';sample.ROOT=R
    reports={};receipts=[]
    for arm in plan['commands']:
        assert pin(arm['image']['path'])==arm['image'];driver.check_product();driver.check_tests()
        sample.IMAGE=Path(arm['image']['path'])
        folder,process=sample.execute(arm['arm'],arm['command'],driver.environment())
        actual=[]
        for name in process['observed_modules']:
            p=Path(name)
            if p.suffix.lower()=='.dll' and p.name.lower().startswith(('hyle_','ggml')):
                assert p.parent.resolve()==(B/'bin').resolve(),str(p)
                actual.append(pin(p))
        save(folder/'runtime-pins.json',{'actual_observed_Hyle_GGML_DLLs':actual,'scope':process['scope'],'module_sample_errors':process['module_sample_errors']})
        report=json.loads((folder/'stdout.log').read_text(encoding='utf-8-sig'));save(folder/'report.json',report)
        assert report['generated_tokens']==128 and all(report[k]==0 for k in
            ('draft_vocabulary_requested_rows','draft_vocabulary_rows','draft_vocabulary_weight_bytes','draft_vocabulary_map_bytes'))
        reports[arm['arm']]=report;save(folder/'non-time.json',non_time(report))
        receipts.append({'arm':arm['arm'],'report':pin(folder/'report.json'),'process':pin(folder/'process.json'),'runtime':pin(folder/'runtime-pins.json')})
        print(json.dumps({'arm':arm['arm'],'status':'NATIVE_PASS','generated_tokens':report['generated_tokens']}),flush=True)
    differences=delta(non_time(reports['control']),non_time(reports['candidate']))
    save(W/'normal-pair/non-time-differences.json',differences)
    assert not differences,'Real non-time differences retained; stop offline rather than hiding them'
    roots={arm['arm']:Path(arm['trace']) for arm in plan['commands']}
    files={arm:{p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()} for arm,root in roots.items()}
    assert files['control'].keys()==files['candidate'].keys(),'Trace file inventory differs'
    manifest=[]
    for relative,old in sorted(files['control'].items()):
        new=files['candidate'][relative];a,b=pin(old),pin(new);equal=True
        with old.open('rb') as x,new.open('rb') as y:
            while True:
                first,second=x.read(1<<20),y.read(1<<20)
                if first!=second:equal=False;break
                if not first:break
        manifest.append({'relative':relative,'control':a,'candidate':b,'byte_equal':equal})
    save(W/'normal-pair/trace-manifest.json',manifest)
    assert all(x['byte_equal'] for x in manifest),'Real trace byte differences retained'
    result={'status':'PASS_TWO_NORMAL_CLI_LIMITED_STATE_BYTES','native_processes':2,'receipts':receipts,'non_time_differences':0,
        'trace_files_per_arm':len(manifest),'trace_bytes_per_arm':sum(x['control']['bytes'] for x in manifest),
        'all_trace_file_bytes_equal':True,'full_2B_Session_blob_equality_claim':False,
        'state_scope':plan['state_scope_limit'],'performance_claim':False,'measurement_scope':plan['measurement_limit']}
    save(W/'normal-pair/summary.json',result)
    print(json.dumps({k:result[k] for k in ('status','native_processes','non_time_differences','trace_files_per_arm','trace_bytes_per_arm')}),flush=True)
if __name__=='__main__':run()
