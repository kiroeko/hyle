"""Offline finite result receipt. Preserve all failures; no native/build."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess
W=Path(__file__).resolve().parent;R=W.parent.parent;P=R/'.scratch/inference-input-packet-review-20261031'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve();raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tiny=read(W/'tiny-summary.json');pair=read(W/'normal-pair/summary.json')
assert tiny['status']=='PASS_SEVEN_SERIAL' and pair['status']=='PASS_TWO_NORMAL_CLI_LIMITED_STATE_BYTES'
source_files=['engine/models/qwen35/main.cc','engine/models/qwen35/phase.h','engine/models/qwen35/phase_preparation.cc',
              'engine/models/qwen35/input_packet.h','tests/tools/qwen_input_packet_case.h','tests/tools/qwen_host_image_test.cc','tests/CMakeLists.txt']
sources=[pin(R/p) for p in source_files]
failed=[]
for name,path,reason in [
    ('normal-CXX-first',W/'build/attempt1/process.json','Independent Phase TU used main-local BackendKind alias; only two type qualifications fixed it.'),
    ('host-CXX-first',W/'host-compile/attempt1/process.json','C1128 COFF section limit; only the test TU gained /bigobj, also reflected in the formal MSVC target.'),
    ('packet-CPU-first',W/'runs/packet-cpu/attempt1/process.json','Hand-linked relocated fixture lacked normal app-directory CPU fingerprint resolution. Only the test EXE was staged beside existing normal DLLs; no SDK copied.'),
    ('packet-CPU-second',W/'runs/packet-cpu/attempt2/process.json','New fixture omitted required original cold use-plan keys; narrow test-only fix prepared every actual key before the first Phase.')]:
    row=read(path);assert row['exit_code']!=0
    failed.append({'name':name,'process':pin(path),'exit_code':row['exit_code'],'reason':reason,'status':'FAILED_HISTORICAL_NOT_RELABELED_PASS'})
wrapper=[
    {'name':'first-dry-run-strict-guard','native_tool_exit':0,'process':pin(W/'dry-run/attempt1/process.json'),'stdout':pin(W/'dry-run/attempt1/stdout.log'),
     'error':'Wrapper expected three CXX/one link, while Ninja -n only predicted its phony glob/manifest check. No CXX/CMake regeneration was executed by this dry-run.'},
    {'name':'unsupported-ninja-debug-switch','native_tool_exit':1,'process':pin(W/'dry-run-after-globs/attempt1/process.json'),'stderr':pin(W/'dry-run-after-globs/attempt1/stderr.log'),
     'error':'norebuild is not supported by this Ninja. Preserved; no repeated empty dry-run. Root authorized actual deps/commands plus build monitoring.'},
    {'name':'pre-link-input-guard','native_processes_started':0,
     'error':'Before first link, the Python guard incorrectly required CUDA import libraries to be inside the build tree. Corrected to bound app objects and compare every import library against its exact normal prebuild pin. No link was started by the rejected wrapper invocation.'}]
save(W/'wrapper-events.json',wrapper)
compile_lines=[];link_lines=[]
for file in sorted((W/'build').glob('attempt*/stdout.log')):
    for line in file.read_text(errors='replace').splitlines():
        if 'Building CXX object' in line:compile_lines.append(line)
        if 'Linking CXX executable' in line:link_lines.append(line)
assert len(compile_lines)==4 and len(link_lines)==1
assert not any('src\\' in x or 'CUDA' in x for x in compile_lines)
processes=[read(W/'normal-pair/checks'/arm/'attempt1/process.json') for arm in ('control','candidate')]
walls=[(datetime.datetime.fromisoformat(p['end_utc'])-datetime.datetime.fromisoformat(p['start_utc'])).total_seconds() for p in processes]
module_errors={}
for p in list((W/'runs').glob('*/attempt*/process.json'))+list((W/'normal-pair/checks').glob('*/attempt*/process.json')):
    v=read(p)
    if v.get('module_sample_errors'):module_errors[str(p.relative_to(W))]=v['module_sample_errors']
dependencies=read(P/'host-image/attempt3/dependencies.json')
v={'status':'PASS_FINITE_PACKET_SLICE_WITH_PRESERVED_FAILURES',
   'source_pins':sources,'product_freeze':pin(W/'source-freeze.json'),'test_freeze':pin(W/'test-source-freeze.json'),
   'control':pin(W/'control/control-ready.json'),'normal_product':read(W/'build/attempt2/receipt.json')['image'],
   'host_fixture':read(W/'host-fixture-ready.json')['image'],
   'builds':{'normal_app_CXX_attempts':4,'normal_app_CXX_successes':3,'normal_link_successes':1,
             'changed_normal_app_objects':3,'retained_normal_app_objects':6,'SDK_CXX':0,'NVCC':0,
             'host_CXX_attempts':3,'host_CXX_successes':2,'host_link_successes':2,'SDK_copies':0,
             'normal_receipt':pin(W/'build/attempt2/receipt.json'),'actual_host_dependencies':pin(P/'host-image/attempt3/dependencies.json')},
   'native':{'successful_tiny_processes':7,'prior_failed_tiny_processes':2,'total_tiny_processes':9,
             'successful_normal_CLI_processes':2,'total_native_processes':11,'automatic_retries':0,
             'tiny_summary':pin(W/'tiny-summary.json'),'normal_pair_summary':pin(W/'normal-pair/summary.json')},
   'normal_pair':{'all_non_time_fields_equal':True,'sampling_stream_and_draw_cursor_equal':True,
                 'trace_files_per_arm':pair['trace_files_per_arm'],'trace_bytes_per_arm':pair['trace_bytes_per_arm'],
                 'all_trace_bytes_directly_equal':True,'manifest':pin(W/'normal-pair/trace-manifest.json'),
                 'observed_traced_wall_seconds':{'control':walls[0],'candidate':walls[1]},
                 'observation':'No obvious wall-time regression in this one traced pair; not an uninstrumented throughput/speedup conclusion.'},
   'historical_failures':failed,'wrapper_events':pin(W/'wrapper-events.json'),
   'module_snapshot_errors':module_errors,'runtime_scope':'Actual finite 10ms module snapshots, not a complete loader-event trace. Current original 37 DLL identities were checked before actions; SDK files were not copied.',
   'limits':['The new packet applies only to ordinary Text rectangular nonimported nondiagnostic CPU/CUDA; original imported relay three slots and other excluded inputs keep their original owners.',
             'R1 uses default and explicit allocation budgets on CPU/CUDA. R2 packet positive checks use default allocation; shared-budget R2 is not claimed.',
             'Injected partial/native-bearing writes use a delegated CPU MemoryResource; system map/flush/close injection and real CUDA driver-fault recovery remain unverified.',
             'Full 2B logical KV/carry/prior/RNG raw Session blobs were not exported. Tiny HostImage/history tests check their own full-state/RNG contracts; they do not prove whole 2B Session-byte equality.',
             'CTest registrations were statically reviewed; normal cache remains HYLE_BUILD_TESTS=OFF. No CTest configure/run claim.',
             'This finite upload field group does not complete the ordinary pipeline or the overall architecture/performance goal.'],
   'downloads':0,'new_profiles':0,'peer_runs':0,'commits':0}
save(W/'finite-results.json',v)
print(json.dumps({'status':v['status'],'tiny_pass':7,'tiny_historical_fail':2,'normal_CLI_pass':2,'SDK_CXX':0,'NVCC':0,
                  'trace_files_per_arm':pair['trace_files_per_arm'],'trace_bytes_per_arm':pair['trace_bytes_per_arm']}))
