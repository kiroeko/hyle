"""Read normal Ninja metadata only; no CXX/link/model invocation."""
from pathlib import Path
import hashlib,json,re,subprocess

W=Path(__file__).resolve().parent
R=W.parent.parent
B=R/'.scratch/build-compute-v2-dev'
def pin(p):
    p=Path(p).resolve(); data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def save(name,data):
    (W/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
text=(B/'build.ninja').read_text(encoding='utf-8-sig')
blocks=text.split('\n\n')
edges=[]
for block in blocks:
    lines=block.splitlines()
    if lines and lines[0].startswith('build engine\\CMakeFiles\\hyle_engine.dir\\') and ': CXX_COMPILER_' in lines[0]:
        edges.append(lines)
assert len(edges)==9,len(edges)
cache=(B/'CMakeCache.txt').read_text(encoding='utf-8-sig')
ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.*)$',cache,re.M).group(1)
rows=[]
for lines in edges:
    obj=lines[0].split(': CXX_COMPILER_',1)[0][6:]
    result=subprocess.run([ninja,'-C',str(B),'-t','deps',obj],capture_output=True,text=True)
    assert result.returncode==0,(obj,result.stderr)
    deps=[s.strip() for s in result.stdout.splitlines()[1:] if s.startswith('    ')]
    hits=[s for s in deps if s.replace('\\','/').endswith(('/phase.h','/episode_state.h','/phase_preparation.cc'))]
    rows.append({'object':pin(B/obj),'dependency_count':len(deps),'phase_dependency_hits':hits,'compile_edge':lines})
    (W/(Path(obj).name+'.deps.txt')).write_text(result.stdout,encoding='utf-8')
link=next(b.splitlines() for b in blocks if b.startswith('build bin\\hyle.exe: CXX_EXECUTABLE_LINKER_'))
rules=(B/'CMakeFiles/rules.ninja').read_text(encoding='utf-8-sig').split('\n\n')
rule_names={row['compile_edge'][0].split(': ',1)[1].split()[0] for row in rows}
rule_names.add(link[0].split(': ',1)[1].split()[0])
selected_rules=[b.splitlines() for b in rules if b.splitlines() and b.splitlines()[0].removeprefix('rule ') in rule_names]
save('normal-ninja-metadata.json',{'status':'PREPARATION_ONLY_NO_BUILD','head_observed':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'ninja_inputs':[pin(B/'build.ninja'),pin(B/'CMakeFiles/rules.ninja'),pin(B/'CMakeCache.txt')],'objects':rows,'link_edge':link,'rules':selected_rules,'configuration':{'HYLE_STATIC':'OFF','HYLE_BUILD_TESTS':'OFF','HYLE_COMPUTE_ROUTES':'cpu;cuda','build_type':'Release'},'sdk_cxx':0,'nvcc':0,'native':0})
print(json.dumps({'status':'PREPARED','objects':len(rows),'phase_dependent':[Path(x['object']['path']).name for x in rows if x['phase_dependency_hits']],'build':0,'native':0}))
