"""Seal independent finite static review; no build or consumer execution."""
from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent; R=W.parent.parent
F=R/'.scratch/inference-input-packet-20261031/source-freeze.json'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve(); raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
freeze=read(F)
for row in freeze['source_pins']:
    p=pin(R/row['relative']); assert p['bytes']==row['bytes'] and p['sha256']==row['sha256'],row['relative']
assert pin(freeze['patch']['path'])==freeze['patch']
check=subprocess.run(['git','diff','--check'],cwd=R,capture_output=True,text=True)
assert check.returncode==0,check.stderr
result={'status':'PASS_FINITE_STATIC_REVIEW_NOT_CXX_OR_NATIVE',
        'freeze':pin(F),'source_pins':freeze['source_pins'],'patch':freeze['patch'],
        'reviewed':['Original selected-carrier borrow precedes upload; pending/inflight/closing and predecessor slot exclusion unchanged.',
                    'Text rectangular nonimported nondiagnostic CPU/CUDA gate; original relay/MTP/packed/diagnostic owners and write branch retained.',
                    'Exact same-root narrow token/position views, checked padded extents, original Tensor budget/nonbudget branches, stable nonmovable per-slot owner.',
                    'Only local cold allocation nonnative ResourceExhausted allows old Tensor path; map/layout/native/runtime write statuses not converted to fallback.',
                    'Both input extents checked before mutation; entire staging including padding initialized; flush then one synchronous payload write then close; first error retained.',
                    'ProgramIo registration order/descriptions and original Graph/session/publication/recovery/retirement algorithms unchanged.',
                    'Actual normal Ninja dependency evidence selects three changed private-layout app TUs; no SDK source/API changes.'],
        'limits':['No actual compile/native performed by this reviewer. Finite test plan in README remains pending.',
                  'Ordinary packet default uses one slot; original three-slot imported relay is negative gate/retirement regression scope.',
                  'Host staging is system memory, not a pinned staging claim. CPU partial-write injection does not prove CUDA native error recovery.',
                  'This field-group upload slice does not complete the ordinary continuous pipeline or full architecture/performance goal.'],
        'commands':pin(W/'commands.json'),'normal_dependencies':pin(W/'normal-ninja-metadata.json'),
        'control_ready':pin(R/'.scratch/inference-input-packet-20261031/control/control-ready.json'),
        'CXX':0,'link':0,'native':0,'GPU':0,'SDK_copied':0}
(W/'independent-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'source_files':len(freeze['source_pins']),'patch_sha256':freeze['patch']['sha256'],'CXX':0,'native':0}))
