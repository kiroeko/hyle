"""Preserve only the authorized normal control EXE; do not copy any SDK."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent; R=W.parent.parent
D=R/'.scratch/inference-input-packet-20261031/control'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve(); raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
source=R/'.scratch/inference-default-product-window-20261031/normal-product-ready.json'
ready=read(source); original=ready['image']
assert original['bytes']==1797120 and original['sha256']=='80ab6462bb54ed4c2f8f1d66117095959a6ce4dcdb6f5c5f1998d099eeb141a3'
assert pin(original['path'])==original
for key in ('build','runtime_environment','loaded_runtime'):
    assert pin(ready[key]['path'])==ready[key]
observed=read(ready['loaded_runtime']['path']); runtime={}
def scan(value):
    if isinstance(value,dict):
        if {'path','bytes','sha256'}<=value.keys() and str(value['path']).lower().endswith('.dll'):
            actual=pin(value['path']); assert actual==value,actual['path']; runtime[actual['path'].lower()]=actual
        else:
            for child in value.values():scan(child)
    elif isinstance(value,list):
        for child in value:scan(child)
scan(observed)
assert runtime
D.mkdir(parents=True,exist_ok=True); copied=D/'hyle.exe'
if copied.exists():
    assert pin(copied)['sha256']==original['sha256']
else:
    with copied.open('xb') as f:f.write(Path(original['path']).read_bytes())
copypin=pin(copied); assert (copypin['bytes'],copypin['sha256'])==(original['bytes'],original['sha256'])
result={'status':'RELOCATED_CONTROL_EXE_READBACK_AND_OBSERVED_NORMAL_RUNTIME_PINS_EXACT',
        'image':copypin,'original_normal_ready':pin(source),'original_image':original,
        'build':ready['build'],'source_pins':ready['source_pins'],'source_pins_scope':'Historical control compilation inputs, not current modified worktree.',
        'runtime_environment':ready['runtime_environment'],'loaded_runtime_provenance':ready['loaded_runtime'],
        'observed_runtime_current_readback':list(runtime.values()),
        'runtime_bin_first':str(R/'.scratch/build-compute-v2-dev/bin'),
        'runtime_note':'DLL identities were observed in the original smoke; all currently exact. Future relocated process must record its own actual loaded-runtime observation. No SDK DLL copied.',
        'instrumented':False,'historical_smoke_passed':ready['smoke_passed'],'relocated_native_runs':0,'SDK_copied':0}
dest=D/'control-ready.json'
if dest.exists():assert read(dest)==result
else:dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'image':copypin,'observed_DLL_pins_exact':len(runtime),'SDK_copied':0,'native_runs':0}))
