"""Prepare normal-shared incremental/host-fixture commands; execute none."""
from pathlib import Path
import ctypes,hashlib,json,re
from ctypes import wintypes

W=Path(__file__).resolve().parent; R=W.parent.parent; B=R/'.scratch/build-compute-v2-dev'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def vars(lines):return dict(x.strip().split(' = ',1) for x in lines[1:] if ' = ' in x)
def args(text):
    shell=ctypes.WinDLL('shell32',use_last_error=True)
    shell.CommandLineToArgvW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype=ctypes.POINTER(wintypes.LPWSTR)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True); kernel.LocalFree.argtypes=[ctypes.c_void_p]
    count=ctypes.c_int(); pointer=shell.CommandLineToArgvW('argument-zero '+text,ctypes.byref(count))
    if not pointer:raise ctypes.WinError(ctypes.get_last_error())
    try:return [pointer[i] for i in range(1,count.value)]
    finally:kernel.LocalFree(pointer)
def pin(p):
    p=Path(p).resolve(); raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
m=read(W/'normal-ninja-metadata.json')
for p in m['ninja_inputs']:
    assert pin(p['path'])==p,'Normal Ninja inputs changed; re-read first'
row=next(x for x in m['objects'] if '\\models\\qwen35\\main.cc.obj' in x['object']['path'])
ce=row['compile_edge']; cv=vars(ce); le=m['link_edge']; lv=vars(le)
cr=vars(next(x for x in m['rules'] if x[0]=='rule '+ce[0].split(': ',1)[1].split()[0]))['command']
lr=vars(next(x for x in m['rules'] if x[0]=='rule '+le[0].split(': ',1)[1].split()[0]))['command']
cl=re.search(r'"([^"]*cl\.exe)"',cr,re.I).group(1)
cmake=re.search(r'"([^"]*cmake\.exe)"',lr,re.I).group(1)
linker=re.search(r'"([^"]*link\.exe)"',lr,re.I).group(1)
rc=re.search(r'--rc="([^"]+)"',lr).group(1); mt=re.search(r'--mt="([^"]+)"',lr).group(1)
version=re.search(r'--msvc-ver=[0-9]+',lr).group()
assert lv['PRE_LINK']==lv['POST_BUILD']=='cd .'
out=W/'host-image'/'attempt1'; unit=out/'qwen_host_image_test.cc.obj'; image=out/'qwen-host-image.exe'
cxx=[cl,'/nologo','/TP',*args(cv['DEFINES']),*args(cv['INCLUDES']),*args(cv['FLAGS']),'/showIncludes',
     '/Fo'+str(unit),'/Fd'+str(out/'compile.pdb'),'/FS','/sourceDependencies',str(out/'dependencies.json'),'-c',
     str(R/'tests/tools/qwen_host_image_test.cc')]
original=le[0].split('Release ',1)[1].split(' | ',1)[0].split()
removed=[x for x in original if x.endswith('\\main.cc.obj')]
assert len(original)==9 and len(removed)==2
retained=[B/x for x in original if x not in removed]
assert len(retained)==7
libs=[]
for x in args(lv['LINK_LIBRARIES']):
    p=Path(x); libs.append(str(p if p.is_absolute() else B/p) if ('/' in x or '\\' in x) else x)
link=[cmake,'-E','vs_link_exe',version,'--intdir='+str(out/'intdir'),'--rc='+rc,'--mt='+mt,'--manifests','--',
      linker,'/nologo',str(unit),*map(str,retained),'/out:'+str(image),'/implib:'+str(image.with_suffix('.lib')),
      '/pdb:'+str(image.with_suffix('.pdb')),'/version:0.0',*args(lv['LINK_FLAGS']),*libs]
cache=(B/'CMakeCache.txt').read_text(encoding='utf-8-sig')
ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.*)$',cache,re.M).group(1)
plan={'status':'PREPARED_COMMANDS_ONLY_NOT_SEALED_OR_EXECUTED','script':pin(Path(__file__)),
      'normal_metadata':pin(W/'normal-ninja-metadata.json'),
      'environment':pin(R/'.scratch/inference-default-product-build-20261031/environment.json'),
      'cwd':str(B),'TEMP_TMP':str(W/'tmp'),
      'prebuild_dry_run_command':[ninja,'-C',str(B),'-n','bin/hyle.exe'],
      'prebuild_condition':'Inspect dry-run: only the three Phase-dependent app CXX and one link are allowed. Stop and report if any SDK/NVCC work is selected.',
      'incremental_product_command':[ninja,'-C',str(B),'-j2','bin/hyle.exe'],
      'expected_product_cxx':['models/qwen35/main.cc','models/qwen35/phase_preparation.cc','models/qwen35/auxiliary_programs.cc'],
      'host_fixture_cxx':cxx,'host_fixture_link':link,'host_fixture_image':str(image),
      'host_fixture_app_objects':8,'retained_current_cold_objects':6,'sdk_cxx':0,'nvcc':0,
      'execution_condition':'Root authorizes after final source review; product incremental success required before host link. Seal actual current source/deps/object/importlib then. Do not import older static or pre-Phase-layout fixture objects.',
      'runtime_rule':'Normal bin first PATH; no DLL copy. No model or test process authorized by this preparation.'}
(W/'commands.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PREPARED_ONLY','product_cxx_expected':3,'product_link':1,'host_cxx':1,'host_link':1,'sdk':0,'executed_tools':0}))
