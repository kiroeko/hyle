"""Pin distinct target44 bodies only after completed authenticated acquisition."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
static = json.loads((S / 'original-target44/acquisition.json').read_text(encoding='utf-8'))
moe = json.loads((S / 'original-moe/acquisition.json').read_text(encoding='utf-8'))
assert static['complete'] and static['original_roles'] == 24
assert static['role_payload_bytes'] == static['successful_request_body_bytes'] == 277078744
assert moe['complete'] and moe['original_roles'] == 1736
assert moe['role_payload_bytes'] == moe['successful_request_body_bytes'] == 7277059200
header = R / 'tests/compute_models/glm_original_target44_roles.h'
payload = header.read_bytes()
text = payload.decode('utf-8')
before = dict(path=header.relative_to(R).as_posix(), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())
pins = []
for row in static['roles']:
    pinned = row['payload']
    assert row['complete'] and len(pinned['sha256']) == 64
    assert (R / pinned['path']).stat().st_size == row['bytes']
    old = f'Spec{{"{row["name"]}", "{row["filename"]}", ""'
    new = f'Spec{{"{row["name"]}", "{row["filename"]}", "{pinned["sha256"]}"'
    assert text.count(old) == 1, row['name']
    text = text.replace(old, new, 1)
    pins.append(dict(name=row['name'], payload=pinned))
catalog = moe['typed_catalog']
catalog_path = R / catalog['path']
assert hashlib.sha256(catalog_path.read_bytes()).hexdigest() == catalog['sha256']
old = 'kMoeIndexSha256 = "";'
assert text.count(old) == 1
text = text.replace(old, f'kMoeIndexSha256 = "{catalog["sha256"]}";', 1)
header.write_bytes(text.encode('utf-8'))
final = header.read_bytes()
record = dict(before=before, after=dict(path=before['path'], bytes=len(final), sha256=hashlib.sha256(final).hexdigest()),
              original_static_pins=pins, original_moe_catalog_pin=catalog,
              scope='Actual original target44 static role and catalogue hashes only; no math or scope changes.')
(S / 'pins.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print('PINNED', len(pins), 'original target44 static roles and distinct MoE catalogue')
