"""Build only exact local target44 metadata plans from authenticated headers."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    cached = read(S / 'cached-roles.json')
    receipt = read(S / 'headers/summary.json')
    assert receipt['complete'] and not receipt['whole_shards_downloaded']
    shards, headers = [], []
    for source in receipt['shards']:
        assert source['complete'] and source['repository'] == cached['repository']
        assert source['revision'] == cached['revision']
        assert identity(R / source['header']['path']) == source['header']
        assert identity(R / source['length_prefix']['path']) == source['length_prefix']
        raw = (R / source['header']['path']).read_bytes()
        assert source['data_base'] == 8 + len(raw)
        shards.append({key: source[key] for key in ('file', 'url', 'etag', 'whole_file_bytes', 'data_base', 'header')})
        headers.append(json.loads(raw))
    shard_ids = {row['file']: i for i, row in enumerate(shards)}
    audit = {row['name']: row for row in [*cached['roles'], cached['finalnorm']]}

    def role(name):
        previous = audit[name]
        shard_index = shard_ids[previous['shard']]
        exact = headers[shard_index][name]
        for key in ('dtype', 'shape', 'data_offsets'):
            assert exact[key] == previous[key], (name, key)
        first, end = exact['data_offsets']
        base = shards[shard_index]['data_base']
        return dict(name=name, dtype=exact['dtype'], shape=exact['shape'], bytes=end-first,
                    source_shard=shard_index, data_relative_half_open=[first, end],
                    absolute_inclusive=[base+first, base+end-1])

    # Preserve exactly the proven BP typed catalog's logical order, changing
    # only the distinct layer identity and its real raw-header byte ranges.
    bp = read(R / '.scratch/glm-original-moe-20261023/roles-plan.json')
    moe = []
    for ordinal, previous in enumerate(bp['roles']):
        row = role(previous['name'].replace('.layers.45.', '.layers.44.'))
        assert row['dtype'] == previous['dtype'] and row['shape'] == previous['shape']
        assert row['bytes'] == previous['bytes'] and previous['ordinal'] == ordinal
        row['ordinal'] = ordinal
        moe.append(row)
    assert len(moe) == 1736 and sum(row['bytes'] for row in moe) == 7277059200
    # These roles use only shards53/54. Retain BP's source_shard indices and
    # physically contiguous, zero-extra-byte bundle layout for fetch_moe.py.
    assert {row['source_shard'] for row in moe} == {0, 1}
    groups = []
    for index in (0, 1):
        for row in sorted((row for row in moe if row['source_shard'] == index),
                          key=lambda row: row['absolute_inclusive'][0]):
            first, last = row['absolute_inclusive']
            if groups and groups[-1]['source_shard'] == index and groups[-1]['last'] + 1 == first:
                group = groups[-1]
                group['last'] = last
                group['bytes'] += row['bytes']
                group['roles'].append(row['ordinal'])
            else:
                groups.append(dict(source_shard=index, first=first, last=last,
                                   bytes=row['bytes'], roles=[row['ordinal']]))
    offset = 0
    for index, group in enumerate(groups):
        group.update(index=index, bundle_offset=offset)
        assert group['last'] - group['first'] + 1 == group['bytes']
        for ordinal in group['roles']:
            row = moe[ordinal]
            row['bundle_offset'] = offset + row['absolute_inclusive'][0] - group['first']
        offset += group['bytes']
    assert offset == 7277059200
    provenance = dict(repository=cached['repository'], revision=cached['revision'],
                      header_receipt=identity(S / 'headers/summary.json'),
                      cached_audit_extract=identity(S / 'cached-roles.json'))
    save(S / 'roles-plan.json', dict(**provenance, original_roles=1736,
         bundle_bytes=offset, shards=shards[:2], roles=moe, groups=groups,
         typed_order='router,bias,shared gate/up/down code/SF; expert0..287 each gate/up/down code/SF',
         layer=44, output_directory='original-moe', whole_shards_downloaded=False, unrequested_bytes=0))

    prefix = 'model.language_model.layers.44.'
    suffixes = [f'self_attn.{name}.weight' for name in
                ('q_proj', 'k_proj', 'v_proj', 'f_a_proj', 'f_b_proj',
                 'g_a_proj', 'g_b_proj', 'b_proj', 'o_proj')]
    suffixes += [f'self_attn.{name}_conv1d.weight' for name in ('q', 'k', 'v')]
    suffixes += ['self_attn.A_log', 'self_attn.dt_bias', 'self_attn.o_norm.weight',
                 'hc_attn_fn', 'hc_attn_scale', 'hc_attn_base',
                 'hc_ffn_fn', 'hc_ffn_scale', 'hc_ffn_base',
                 'input_layernorm.weight', 'post_attention_layernorm.weight']
    dense = []
    for suffix in suffixes:
        row = role(prefix + suffix)
        row['filename'] = suffix + ('.bf16' if row['dtype'] == 'BF16' else '.f32')
        row['cold_transform'] = ('exact BF16->F32 widening once; retain no generated coefficient'
                                 if suffix in ('hc_attn_fn', 'hc_ffn_fn') else 'none; preserve original storage')
        dense.append(row)
    norm = role('model.language_model.norm.weight')
    norm.update(filename='model_norm.weight.bf16', cold_transform='none; distinct final target norm, not NextN shared_head.norm')
    dense.append(norm)
    assert len(dense) == 24 and sum(row['bytes'] for row in dense) == 277078744
    assert len({row['name'] for row in dense+moe}) == 1760
    assert {row['name'] for row in dense+moe} == audit.keys()
    for row in dense:
        row['ordinal'] = dense.index(row)
    save(S / 'static-plan.json', dict(**provenance, layer=44, original_roles=24,
         expected_role_payload_bytes=277078744, shards=shards, roles=dense,
         output_directory='original-target44', whole_shards_downloaded=False))
    save(S / 'plan-summary.json', dict(**provenance, layer44_roles=1759,
         layer44_bytes=7554129752, distinct_model_norm_roles=1,
         distinct_model_norm_bytes=8192, complete_original_roles=1760,
         complete_payload_bytes=7554137944, moe_roles=1736, moe_bytes=7277059200,
         non_moe_and_finalnorm_roles=24, non_moe_and_finalnorm_bytes=277078744,
         source_shards=shards, moe_range_groups=len(groups),
         plans=[identity(S / 'roles-plan.json'), identity(S / 'static-plan.json')],
         no_download_by_metadata_agent=True, no_native=True,
         reuse='Existing original shared embedding/head and runtime typed-loader machinery are reused; layer44 and final target norm bytes are distinct. No copied original45 weights, generated tensor substitution, whole-shard body or F32 weight shadow.',
         pending='Root authenticates actual response identities and payload SHA after exact-range acquisition; source metadata is not a payload SHA receipt.'))
    print(json.dumps(dict(moe_roles=len(moe), moe_groups=len(groups), moe_bytes=offset,
                          remaining_roles=len(dense), remaining_bytes=277078744,
                          complete_roles=1760, complete_bytes=7554137944)))


if __name__ == '__main__':
    main()
