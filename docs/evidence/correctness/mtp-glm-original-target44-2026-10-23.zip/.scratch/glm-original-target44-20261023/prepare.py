"""Prepare one-TU original GLM target44 integration using the current cached closure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
BS = R / '.scratch/glm-target-verifier-20261023'

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path, data): path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')

before = read(BS / 'before.json')
freeze = read(BS / 'source-final/freeze.json')
save(S / 'before.json', dict(utc=datetime.now(timezone.utc).isoformat(),
    previous_goal_turn_classification='progress: BS original full-V target verifier with actual pending/complete state passed four native cases218Graphs and published evidence.',
    prior_publication=read(BS / 'publication.json'),
    protected_performance_tail_sha256=before['protected_performance_tail_sha256'],
    protected_qwen_image=before['protected_qwen_image'], source=freeze['source']))
build = (BS / 'build.py').read_text(encoding='utf-8')
build = build.replace('Incremental GLM actual target shared-head K1 verification and related state consumers.',
                      'Incremental original GLM target44 and shared K1 complete-state consumers.')
build = build.replace("BASE = R / '.scratch/q24-original-nextn-20261023/tests-link3'",
                      "BASE = R / '.scratch/glm-target-verifier-20261023/tests-link1'")
build = build.replace("R / '.scratch/glm-original-moe-20261023/compile1/glm-state/identity.json'",
                      "R / '.scratch/glm-target-verifier-20261023/compile1/glm-state/identity.json'")
build = build.replace('glm-target-verifier-checks.exe', 'glm-original-target44-checks.exe')
build = build.replace("    env['HYLE_GLM_MTP_INPUT_DIR']", "    env['HYLE_GLM_MTP_TARGET44_DIR'] = str(S / 'original-target44')\n    env['HYLE_GLM_MTP_TARGET44_MOE_DIR'] = str(S / 'original-moe')\n    env['HYLE_GLM_MTP_INPUT_DIR']", 1)
(S / 'build.py').write_text(build, encoding='utf-8')
save(S / 'progress.json', dict(stage='BT', state='Source and original role acquisition implementation in progress; no BT native checks yet.',
    goal_complete=False, native_checks_run=False, new_TPS=False,
    previous_goal_turn_classification='progress: BS four native cases218Graphs and durable evidence completed',
    scope='Replace generated GLM target44 KDA, HC, MoE and final norm with distinct original roles while reusing existing cold split, ordinary Graphs, output leases and one StateHead. Target43 and upstream remain explicit boundaries.',
    next='Authenticated target44 headers/ranges and payloads, pure model component and original-byte references; one TU incremental build, focused CPU/CUDA K1 journeys and existing regression, current documentation and durable evidence.'))
print('PREPARED BT cached one-TU integration; no validation claim')
