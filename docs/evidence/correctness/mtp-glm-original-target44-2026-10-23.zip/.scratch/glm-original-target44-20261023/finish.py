"""Record completed original-target44 implementation after actual publication."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
publication = json.loads((S / 'publication.json').read_text(encoding='utf-8'))
evidence = json.loads((R / publication['evidence']['path']).read_text(encoding='utf-8'))
run = json.loads((S / 'checks1/summary.json').read_text(encoding='utf-8'))
assert run['process']['exit'] == 0 and run['tests'] == 4
assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
for row in publication.values():
    path = R / row['path']
    assert path.stat().st_size == row['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
with zipfile.ZipFile(R / publication['archive']['path']) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        path = Path(name)
        assert path.suffix.lower() not in {'.exe', '.obj', '.lib', '.dll', '.bf16', '.f32', '.e4m3'}
        if path.suffix.lower() == '.bin':
            assert path.name == 'catalog.bin' and archive.getinfo(name).file_size == 27840
progress = dict(utc=datetime.now(timezone.utc).isoformat(), stage='BT', stage_complete=True, goal_complete=False,
    previous_goal_turn_classification='progress: BS full-V K1 verifier actual leases and full-state checks completed.',
    state='Distinct original target44 roles acquired and pinned, reusable component and existing K1 journey integrated, one host TU built, four focused native cases passed, docs and durable evidence updated.',
    native_checks_run=True, tests=run['tests'], graph_submissions=evidence['validation']['graph_submissions'],
    failures=0, skips=0, native_process_status='completed_exit0_not_live', exec_session_status='completed',
    download_process_status='both_static_and_moe_completed_exit0_not_live',
    original_target44_roles=1760, original_target44_bytes=7554137944, publication=publication,
    new_TPS=False, physical_memory_peak=False, protected_AV_tail_unchanged=True,
    scope='Distinct target44 HC/KDA/MoE/finalnorm plus complete original NextN and original full-V K1 verification; original target43, upstream42 and initial prefix still not supplied.',
    next='Original target43 producer and other applicable verifier adapters; Pro actual geometry and confirmed quantization; final ordinary/MTP performance before image projection. Goal remains active.')
(S / 'progress.json').write_text(json.dumps(progress, indent=2) + '\n', encoding='utf-8')
print('PUBLISHED BT', run['tests'], 'cases', evidence['validation']['graph_submissions'], 'Graphs; full MTP stays incomplete')
