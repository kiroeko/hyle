"""Root-only acquisition of three pinned GLM headers, never shard bodies.

Prepared source-only by the metadata agent. Each uncached shard requires its
8-byte safetensors length and exactly that header, with matching HTTP identity.
"""
from pathlib import Path
import hashlib
import json
import re
import struct
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
REPOSITORY = 'zai-org/GLM-5.3-Flash'
REVISION = 'eb9eb208eb0d988989d07a6a12d0fdeb5f52574a'
SHARDS = (53, 54, 62)


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def request(url, first, last, etag=None, whole=None):
    headers = {'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity',
               'User-Agent': 'hyle-original-target-header/1'}
    if etag is not None:
        headers['If-Range'] = etag
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=60) as response:
        assert response.status == 206, 'Refuse an unbounded whole-shard HTTP response'
        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
        assert match and [int(match[1]), int(match[2])] == [first, last]
        total = int(match[3])
        assert whole is None or total == whole
        actual_etag = response.headers.get('ETag')
        assert actual_etag and (etag is None or actual_etag == etag)
        assert response.headers.get('Content-Encoding') in (None, 'identity')
        size = last - first + 1
        assert response.headers.get('Content-Length') in (None, str(size))
        raw = response.read(size + 1)
        assert len(raw) == size
        return raw, dict(http_status=206, absolute_inclusive=[first, last],
                         bytes=size, whole_file_bytes=total, etag=actual_etag,
                         sha256=hashlib.sha256(raw).hexdigest())


def main():
    records = []
    for index in SHARDS:
        file = f'model-{index:05d}-of-00062.safetensors'
        folder = S / 'headers' / file.removesuffix('.safetensors')
        folder.mkdir(parents=True, exist_ok=True)
        receipt = folder / 'receipt.json'
        if receipt.exists():
            record = json.loads(receipt.read_text(encoding='utf-8-sig'))
            assert record['repository'] == REPOSITORY and record['revision'] == REVISION
            assert record['file'] == file and record['complete']
            for key in ('length_prefix', 'header'):
                assert identity(R / record[key]['path']) == record[key]
            records.append(record)
            continue
        prefix_path, header_path = folder / 'header-length.bin', folder / 'header.json'
        assert not prefix_path.exists() and not header_path.exists(), 'Keep partial acquisition visible to root'
        url = f'https://huggingface.co/{REPOSITORY}/resolve/{REVISION}/{file}'
        prefix, first = request(url, 0, 7)
        length, = struct.unpack('<Q', prefix)
        assert 0 < length <= 16 * 1024 * 1024 and 8 + length <= first['whole_file_bytes']
        raw, second = request(url, 8, 7 + length, first['etag'], first['whole_file_bytes'])
        header = json.loads(raw)
        assert isinstance(header, dict) and header
        for name, value in header.items():
            if name == '__metadata__':
                continue
            start, end = value['data_offsets']
            assert 0 <= start <= end <= first['whole_file_bytes'] - 8 - length
        prefix_path.write_bytes(prefix)
        header_path.write_bytes(raw)
        record = dict(repository=REPOSITORY, revision=REVISION, file=file, url=url,
                      complete=True, whole_shard_downloaded=False,
                      whole_file_bytes=first['whole_file_bytes'], etag=first['etag'],
                      data_base=8 + length, length_prefix=identity(prefix_path),
                      header=identity(header_path), tensor_count=len(header) - ('__metadata__' in header),
                      requests=[first, second])
        save(receipt, record)
        records.append(record)
        print('HEADER', file, length, 'bytes; no tensor payload', flush=True)
    save(S / 'headers/summary.json', dict(repository=REPOSITORY, revision=REVISION,
         complete=True, whole_shards_downloaded=False,
         successful_request_body_bytes=sum(sum(request['bytes'] for request in row['requests']) for row in records),
         shards=records))


if __name__ == '__main__':
    main()
