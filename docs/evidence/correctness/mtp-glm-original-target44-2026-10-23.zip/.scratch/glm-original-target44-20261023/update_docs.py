"""Update current MTP facts after the four focused target44 native cases pass."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
run = json.loads((S / 'checks1/summary.json').read_text(encoding='utf-8'))
assert run['tests'] == 4 and run['process']['exit'] == 0
assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
new = [case for case in run['cases'] if case['attributes']['name'].endswith('OriginalTarget44AndNextNFullVocabularyVerifier')]
assert len(new) == 2
graphs = sum(int(case['properties']['actual_submissions']) for case in run['cases'])
new_graphs = sum(int(case['properties']['actual_submissions']) for case in new)
before = json.loads((S / 'before.json').read_text(encoding='utf-8'))

def once(text, old, new):
    assert text.count(old) == 1, (old[:120], text.count(old))
    return text.replace(old, new, 1)

path = R / 'docs/developer/current-work.md'
text = path.read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest() == before['protected_performance_tail_sha256']
start = text.index('**正在推进：** 将GLM target44')
end = text.index('\n\n', start)
text = text[:start] + text[end + 2:]
text = once(text, 'target43／44参数仍生成。DSpark', 'target44已接独立原参数；target43仍生成。DSpark')
text = once(text,
    'GLM已接实际计算target taps和原全词表verifier，但target43／44参数仍生成；下一步接原target参数和其它适用模型的producer／verifier，适配Pro实际几何与其它已确认量化。',
    'GLM已接原target44的HC／KDA／MoE及独立model.norm，沿同一原全词表verifier和34资源＋epoch接受流程；下一步替换target43生成参数，并接其它适用模型的producer／verifier、Pro实际几何与确认量化。')
start = text.index('**最近已验证进展：**')
end = text.index('已取得的实际边界：', start)
text = text[:start] + (
    '**最近已验证进展：** [GLM原target44与完整K1续算](../evidence/correctness/mtp-glm-original-target44-2026-10-23.json)已将第44层的生成参数替换为独立原HC、KDA、norm、真实288域MoE及最终model.norm，共1760角色、7,554,137,944B；原NextN的1762角色继续复用。大密集矩阵保BF16，只有参考加载器要求的两小HC矩阵和三短卷积冷扩宽F32；专家按实际Top8有界供给，没有整份F32专家副本。MoE运行源和输入／输出观察端口已从NextN身份解耦，第44层复用同一冷图切分、Program／Invocation和StateHead。\n\n'
    f'CPU／CUDA新两项共{new_graphs}次Graph，加原全词表验证链回归共4项、{graphs}次，0失败／0跳过。原字节局部参考核9份BF16投影、两份HC、卷积、Q/K归一化、F32 KDA状态、BF16存储及原MoE；全V154880双行验证、真实纠正／bonus租约、接受0／1、追赶与fresh seed→skip0继续检查。HC明确选官方torch／unfused顺序，不代签TileLang融合分支逐bit。target43参数、layer42输入与初始历史仍生成；未完成原target尾部，不作完整任务质量或真实任务接受率结论，没有新TPS／物理显存峰。\n\n'
    '前批[原全词表验证](../evidence/correctness/mtp-glm-target-verifier-2026-10-23.json)、[Q27原17角色](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)、[Q24原22角色](../evidence/correctness/mtp-q24-original-nextn-2026-10-23.json)、[GLM原NextN](../evidence/correctness/mtp-glm-original-moe-2026-10-23.json)及[DSpark原83角色](../evidence/correctness/mtp-dspark-original-experts-2026-10-23.json)的有效实现与证据保留。各模型实际边界见下；Pro的完整576维缓存已有typed MLA承载，实际接入和已确认量化仍待完成。页末AV性能表不变。\n\n'
) + text[end:]
text = once(text,
    'target taps由实际数学产生，但43／44参数、layer42输入和初始历史仍生成；原target参数、Pro几何、其它量化及真实任务自然接受率未完成，',
    '[原target44](../evidence/correctness/mtp-glm-original-target44-2026-10-23.json)的1760角色及明确BF16／F32边界已进入同一全词表K1状态流程；target43参数、layer42输入和初始历史仍生成。原target43、Pro几何、其它量化及真实任务自然接受率未完成，')
text = once(text,
    'GLM计算tap／原全词表verifier及完整K1状态已接；下一步原target参数、其它适用producer／verifier、Pro几何与确认量化，',
    'GLM原target44、原全词表verifier及完整K1状态已接；下一步原target43、其它适用producer／verifier、Pro几何与确认量化，')
assert text[text.index('## 最新完整性能对比'):] == tail
path.write_text(text, encoding='utf-8')

path = R / 'docs/implementation/model-operators.md'
text = path.read_text(encoding='utf-8-sig')
text = once(text,
    'target43／44参数及初始历史仍生成，原target参数、Pro几何和其它确认量化未完成',
    '[原target44的1760角色](../evidence/correctness/mtp-glm-original-target44-2026-10-23.json)已进入同一34资源＋epoch和K1流程；target43参数及初始历史仍生成，原target43、Pro几何和其它确认量化未完成')
text = once(text,
    'target43／44参数、layer42输入与初始历史仍生成；有限局部数值和容量检查不代签完整原模型、其它量化、任务质量、真实任务自然接受率、TPS或物理显存峰值。',
    '后续[原target44](../evidence/correctness/mtp-glm-original-target44-2026-10-23.json)已接全部1759层内原角色及独立model.norm，共1760份、7,554,137,944B。原HC采用torch／unfused顺序，KDA保明确BF16投影／卷积／输出边界、F32归一化和[V,K]矩阵；原288域MoE复用同一有界Top8供给和Program，通用MoE观察端口与NextN身份已分离。target43参数、layer42输入与初始历史仍生成；有限局部数值和容量检查不代签完整原模型、其它量化、任务质量、真实任务自然接受率、TPS或物理显存峰值。')
path.write_text(text, encoding='utf-8')
print('UPDATED BT current facts:', run['tests'], 'cases,', graphs, 'Graphs; AV tail unchanged')
