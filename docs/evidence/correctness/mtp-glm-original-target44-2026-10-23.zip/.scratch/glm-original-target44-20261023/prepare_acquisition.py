"""Reuse exact bounded range protocols for distinct original target44 roles."""
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[1]
moe = (R / '.scratch/glm-original-moe-20261023/fetch_moe.py').read_text(encoding='utf-8')
moe = moe.replace('layer45 MoE', 'layer44 MoE')
(S / 'fetch_moe.py').write_text(moe, encoding='utf-8')
static = (R / '.scratch/glm-original-attention-20261023/fetch_attention.py').read_text(encoding='utf-8')
static = static.replace('nine pinned GLM Flash original attention/postnorm roles', '24 pinned GLM Flash original target44 static roles')
old = """plan_path = S / 'roles-plan.json'
plan = read(plan_path)
header_raw = (R / plan['header']['path']).read_bytes()
assert hashlib.sha256(header_raw).hexdigest() == plan['header']['sha256']
header = json.loads(header_raw)
out = S / 'original-attention'"""
new = """plan_path = S / 'static-plan.json'
plan = read(plan_path)
headers = []
for shard in plan['shards']:
    header_raw = (R / shard['header']['path']).read_bytes()
    assert hashlib.sha256(header_raw).hexdigest() == shard['header']['sha256']
    headers.append(json.loads(header_raw))
out = S / 'original-target44'"""
assert static.count(old) == 1
static = static.replace(old, new)
static = static.replace("    exact = header[role['name']]", "    shard = plan['shards'][role['source_shard']]\n    exact = headers[role['source_shard']][role['name']]")
static = static.replace("first = plan['data_base']", "first = shard['data_base']")
static = static.replace("url=plan['url'], etag=plan['etag'], whole_file_bytes=plan['whole_file_bytes']",
                        "url=shard['url'], etag=shard['etag'], whole_file_bytes=shard['whole_file_bytes']")
static = static.replace('127958528', '277078744').replace('original_roles=9', 'original_roles=24')
static = static.replace("source_plan=plan_path.relative_to(R).as_posix(), expected_role_payload_bytes=277078744",
                        "source_plan=plan_path.relative_to(R).as_posix(), source_plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(), expected_role_payload_bytes=277078744")
(S / 'fetch_static.py').write_text(static, encoding='utf-8')
print('PREPARED existing bounded protocols for distinct target44 MoE and static roles')
