"""Shared Backend extraction: retained toolchains/objects; no SDK or model work."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[1]
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value
b = module('previous_extraction_tools', R / '.scratch/mtp-extraction-regression-20261024/check.py')
OLD = R / '.scratch/qwen-cpu-gpu-backend-20261024'
CUDA = OLD / 'cuda-regression1'

def freeze():
    out = D / 'source'
    out.mkdir(exist_ok=False)
    pins = []
    for relative in ['engine/inference/backend.h', 'engine/inference/execution_resources.h',
            'engine/inference/prepared_output.h', 'tests/tools/qwen_backend_cpu_cuda_test.cc']:
        source = R / relative; frozen = out / relative
        frozen.parent.mkdir(parents=True, exist_ok=True); frozen.write_bytes(source.read_bytes())
        pins.append({'canonical': b.pin(source), 'frozen': b.pin(frozen)})
    b.save(D / 'source-pins.json', pins)

def headers():
    if not (D / 'source-pins.json').exists(): freeze()
    checks = []
    for name in ['cpu', 'cuda', 'cpu-cuda', 'vulkan', 'cpu-vulkan']:
        previous = OLD / ('header-check2' if 'vulkan' in name else 'header-check1') / name / 'command.json'
        original = b.args(previous)
        command = [original[0], '/I' + str(D / 'source')]
        for word in original[1:]:
            if word.lower().endswith(('.cc', '.cpp')) or word.lower().startswith(('/fo', '/fd')): continue
            command.append(word)
        command.extend(['/sourceDependencies', str(D / 'headers' / name / 'dependencies.json'), str(D / 'header.cc')])
        b.execute(command, D / 'headers' / name, b.environment(command[0]), 60)
        checks.append({'configuration': name, 'process': b.read(D / 'headers' / name / 'process.json')})
    b.save(D / 'headers/summary.json', {'checks': checks, 'HTTP': 0, 'SDK_builds': 0})

def cuda():
    if not (D / 'source-pins.json').exists(): freeze()
    source = D / 'source/tests/tools/qwen_backend_cpu_cuda_test.cc'
    original = b.args(CUDA / 'compile/command.json')
    command = [original[0], '/I' + str(D / 'source')]; skip = False
    for word in original[1:]:
        if skip: skip = False; continue
        if word == '/sourceDependencies': skip = True; continue
        if word.lower().startswith(('/fo', '/fd')) or word.lower().endswith(('.cc', '.cpp')): continue
        command.append(word)
    command += ['/sourceDependencies', str(D / 'cuda-compile/dependencies.json'), str(source),
        '/Fo' + str(D / 'cuda-compile/backend-test.obj'), '/Fd' + str(D / 'cuda-compile/backend-test.pdb')]
    env = b.environment(command[0]); b.execute(command, D / 'cuda-compile', env, 120)
    previous = b.args(CUDA / 'link/command.json'); link = []
    old_object = str(CUDA / 'compile/backend-test.obj')
    assert old_object in previous
    for word in previous:
        if word.upper().startswith(('/OUT:', '/MAP:', '/PDB:', '/IMPLIB:')): continue
        link.append(str(D / 'cuda-compile/backend-test.obj') if word == old_object else word)
    image = D / 'cuda-link/backend-check.exe'; link.append('/OUT:' + str(image))
    b.execute(link, D / 'cuda-link', env, 120)
    native = []
    for source_dll in (CUDA / 'link').glob('*.dll'):
        os.link(source_dll, D / 'cuda-link' / source_dll.name); native.append(b.pin(source_dll))
    b.save(D / 'cuda-link/native.json', native)
    env['PATH'] = b.read(CUDA / 'ready.json')['PATH']
    # The original file-endpoint fixture uses one relative temporary filename.
    # Keep that file in this new private run directory rather than the repo root.
    run = D / 'cuda-run'; b.R = run
    b.execute([str(image), '--gtest_filter=QwenBackendCpuCuda.*',
        '--gtest_output=json:' + str(D / 'cuda-gtests.json')], run, env, 60)

def retirement():
    source = D / 'retirement.cc'
    source.write_bytes((R / '.scratch/mtp-extraction-regression-20261024/retirement.cc').read_bytes())
    env = b.compile(source, D / 'retirement-compile', vulkan=True)
    image = b.link(D / 'retirement-compile/unit.obj', D / 'retirement-link', env, vulkan=True, gtest=True)
    env.update({k: v for k, v in b.read(b.VK / 'runtime.json').items() if isinstance(v, str)})
    b.execute([str(image), '--gtest_filter=QwenResourceRetirement.*:InferenceExtraction.*',
        '--gtest_output=json:' + str(D / 'retirement-gtests.json')], D / 'retirement-run', env, 60)

if __name__ == '__main__':
    {'headers': headers, 'cuda': cuda, 'retirement': retirement}[sys.argv[1]]()
