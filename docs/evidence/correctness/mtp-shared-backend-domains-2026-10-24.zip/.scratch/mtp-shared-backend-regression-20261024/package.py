"""Retain this cold-backend migration's finite checks without build binaries."""
from pathlib import Path
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
OUT = R / 'docs/evidence/correctness/mtp-shared-backend-domains-2026-10-24'

def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def identity(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def main():
    headers = load(D / 'headers/summary.json')['checks']
    checks = {name: load(D / name / 'process.json') for name in (
        'cuda-run', 'retirement-run', 'gate-syntax', 'mac-check1')}
    for row in [x['process'] for x in headers] + list(checks.values()):
        if row['exit'] != 0 or row.get('timeout', row.get('timed_out', False)):
            raise RuntimeError('Require actual successful terminal checks')
    for name, count in [('cuda', 4), ('retirement', 3)]:
        tests = load(D / (name + '-gtests.json'))
        if tests['tests'] != count or tests['failures'] or tests['errors']:
            raise RuntimeError('Actual finite test set differs')
    sources = [R / name for name in (
        'engine/inference/backend.h', 'engine/inference/execution_resources.h',
        'engine/inference/prepared_output.h', 'engine/models/qwen35/main.cc',
        'engine/models/qwen35/native_gate.h', 'engine/models/qwen35/native_gate.cc',
        'engine/models/qwen35/native_gate_apple.mm',
        'tests/tools/qwen_backend_cpu_cuda_test.cc',
        'tests/tools/qwen_resource_retirement_test.cc')]
    if (R / 'engine/models/qwen35/backend.h').exists():
        raise RuntimeError('Old model-private backend must be removed')
    for record in load(D / 'source-pins.json'):
        p = Path(record['canonical']['path'])
        if hashlib.sha256(p.read_bytes()).hexdigest() != record['canonical']['sha256']:
            raise RuntimeError('Canonical source changed after the checked freeze')
    records = [p for p in D.rglob('*') if p.is_file()
        and p.suffix in {'.json', '.log', '.py', '.cc', '.d'}]
    with zipfile.ZipFile(OUT.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(sources + records)):
            z.write(p, p.relative_to(R).as_posix())
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:
        if z.testzip() is not None:
            raise RuntimeError('Evidence archive CRC failed')
        count = len(z.namelist())
    result = dict(date='2026-10-24', status='PASS finite shared Backend/domain-table migration',
        previous=identity(R / 'docs/evidence/correctness/mtp-shared-cold-resources-output-2026-10-24.json'),
        sources=[identity(p) for p in sources], archive=identity(OUT.with_suffix('.zip')),
        archive_entries=count,
        changes=['Move model-independent Backend and WorkspaceBudgets into engine/inference',
            'Use one fixed cold table for compile, resource_for and storage_owner_for',
            'Prepare scalar caller storage using the actual reported domain',
            'Migrate model/native-gate/test consumers and delete the old private header'],
        checks=dict(windows_strict_header_configurations=headers,
            cuda_four_existing_cases_and_moved_domain_mapping=checks['cuda-run'],
            vulkan_two_original_retirement_cases_and_provider_owned_readback=checks['retirement-run'],
            windows_native_gate_strict_syntax=checks['gate-syntax'],
            mac_air_cpu_apple_strict_header_syntax=checks['mac-check1'],
            independent_review='Domain counts, budgets, original owners, control-block addresses and destruction order remain consistent'),
        limits=['The existing compile-time backend priority is preserved; runtime backend selection remains pending',
            'No full-model, throughput, memory-comparison or complete cross-platform runtime claim',
            'No model mathematics, sampling policy, precision or fusion changes',
            'The pending complete FP8 journeys continue to use their separate frozen image'],
        SDK_builds=0, model_runs=0, model_download_bytes=0)
    with OUT.with_suffix('.json').open('x', encoding='utf8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
        f.write('\n')
    print(json.dumps(dict(evidence=identity(OUT.with_suffix('.json')),
        archive=result['archive'], entries=count)))

if __name__ == '__main__':
    main()
