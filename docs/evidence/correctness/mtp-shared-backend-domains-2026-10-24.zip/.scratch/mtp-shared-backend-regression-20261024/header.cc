#include <type_traits>
#include <utility>
#include "engine/inference/backend.h"
using hyle::inference::Backend;
static_assert(Backend::supports_cpu_gpu == EXPECT_MIXED);
static_assert(Backend::host_only == EXPECT_HOST);
static_assert(std::is_same_v<decltype(std::declval<const Backend &>().resource_for(
    hyle::graph::StorageDomainId{0})), hyle::Result<hyle::mem::MemoryResourceRef>>);
void check(Backend &backend) {
  (void)backend.has_cpu_endpoint();
  (void)backend.host_device();
  (void)backend.queue_bindings();
  (void)backend.resource_for(hyle::graph::StorageDomainId{0});
}
