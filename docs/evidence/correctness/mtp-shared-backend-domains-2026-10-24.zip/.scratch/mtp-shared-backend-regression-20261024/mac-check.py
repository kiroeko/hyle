from pathlib import Path
import hashlib
import json
import subprocess
import time

D = Path('/Users/kiro/hyle-scratch/compute-unified/mtp-shared-backend-20261024')
B = Path('/Users/kiro/hyle-scratch/compute-unified/qwen-cpu-apple-functional-20261024/attempt1')
out = D / 'check1'
out.mkdir(exist_ok=False)
header = D / 'source/engine/inference/backend.h'
assert hashlib.sha256(header.read_bytes()).hexdigest() == '12b7222b3bdf03eb327796e5a6619a98db17c392196dd3c28814b7458f733b89'
old = next(x['command'] for x in json.loads((B / 'plan.json').read_text())['jobs'] if x['tag'] == 'model')
command = [old[0], '-I' + str(D / 'source')]
skip = False
for word in old[1:]:
    if skip:
        skip = False
        continue
    if word in {'-MF', '-o'}:
        skip = True
        continue
    if word == '-c' or word.endswith(('.cc', '.cpp')):
        continue
    command.append(word)
command += ['-DEXPECT_MIXED=1', '-DEXPECT_HOST=0', '-fsyntax-only',
    '-MF', str(out / 'header.d'), str(D / 'header.cc')]
(out / 'command.json').write_text(json.dumps({'command': command, 'cwd': str(D),
    'scope': 'one strict CPU+Apple shared Backend header check; no SDK/link/model/HTTP'}, indent=2))
pins = []
for source in [header, D / 'header.cc', D / 'mac-check.py']:
    pins.append({'path': str(source), 'bytes': source.stat().st_size,
        'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
(out / 'source-pins.json').write_text(json.dumps(pins, indent=2))
start = time.monotonic()
with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
    process = subprocess.run(command, cwd=D, stdout=stdout, stderr=stderr, timeout=60)
result = {'exit': process.returncode, 'seconds': time.monotonic() - start,
    'SDK_builds': 0, 'model_runs': 0, 'HTTP': 0}
(out / 'process.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result), flush=True)
if process.returncode:
    print((out / 'stderr.log').read_text(errors='replace'), flush=True)
raise SystemExit(process.returncode)
