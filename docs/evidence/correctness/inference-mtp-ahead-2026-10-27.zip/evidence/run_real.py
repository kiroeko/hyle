from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('mtp_ahead_real_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
m, h = b.m, b.h
spec2 = importlib.util.spec_from_file_location('mtp_ahead_real_facts', W / 'run_cli.py')
oracle_module = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(oracle_module)

def main():
    images = {'baseline': m.read(R / '.scratch/inference-alias-role-filter-20261027/ready-cli.json')['image'],
              'candidate': m.read(W / 'ready-cli1.json')['image']}
    for image in images.values(): b.exact(image)
    fixture = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    case = W / 'real-case'; case.mkdir(exist_ok=True)
    (case / 'prompt.ids').write_bytes((fixture / 'prompt.ids').read_bytes())
    (case / 'turn.schedule').write_text('prompt prompt.ids\ngenerate 12\n', encoding='utf-8')
    (case / 'sessions.tsv').write_text('A turn.schedule\nB turn.schedule\n', encoding='utf-8')
    results, oracles = [], {}
    for arm, mode in [('baseline', 'off'), ('candidate', 'off'), ('candidate', 'on'), ('baseline', 'on')]:
        name = arm + '-mtp-' + mode; out = W / 'real2' / name
        command = [images[arm]['path'], '--inputs', str(fixture), '--backend', 'cuda',
                   '--session-schedules', str(case / 'sessions.tsv'), '--capacity', '256',
                   '--max-sessions', '2', '--active-sequences', '2', '--prefix-cache', 'off',
                   '--sampling', 'greedy', '--mtp', mode, '--progress', 'direct']
        if mode == 'on': command += ['--mtp-max-drafts', '3']
        process = h.execute(command, b.environment(), out, timeout=240)
        report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
        m.save(out / 'report.json', report)
        selected = oracle_module.facts(report)
        if mode not in oracles: oracles[mode] = selected
        if selected != oracles[mode]:
            changed = [k for k in selected if selected[k] != oracles[mode].get(k)]
            m.save(out / 'comparison-failure.json', dict(changed=changed))
            raise AssertionError((name, 'complete non-time/non-ahead-counter report changed', changed))
        assert report['generated_tokens'] == 24 and report['live_committed_versions'] == 0
        row = dict(name=name, arm=arm, mode=mode, process=process, image=images[arm],
                   report=m.pin(out / 'report.json'), actual_graph_calls=report['actual_graph_calls'],
                   generated_tokens=report['generated_tokens'],
                   ahead={k: report[k] for k in ['cpu_ahead_prepared', 'cpu_ahead_hits', 'cpu_ahead_discarded']})
        results.append(row); m.save(W / 'real-partial.json', results)
        print('PASS ' + name + ' ' + json.dumps(row['ahead']), flush=True)
    m.save(W / 'real-summary.json', dict(status='PASS', results=results, exact_reports_equal_per_mode_except_named_ahead_counters=True,
            scope='Four real Qwen3.5-2B CUDA correctness processes: R2, two P154 prompts,12 outputs/member, C256; multiple target pages. No timing/peer/quality claim.'))

if __name__ == '__main__': main()
