from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
A = R / '.scratch/inference-alias-role-filter-20261027'
F = R / '.scratch/inference-generation-batch-facts-20261027'
spec = importlib.util.spec_from_file_location('mtp_ahead_reuse', A / 'build.py')
reuse = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reuse)
m, h, exact = reuse.m, reuse.h, reuse.exact
m.W = W


def environment():
    result = dict(os.environ)
    result.update(m.read(A / 'environment.json'))
    paths = [str(W / 'bin'), *result['PATH'].split(';')]
    seen = set()
    result['PATH'] = ';'.join(x for x in paths if x and not (x.casefold() in seen or seen.add(x.casefold())))
    for key in ['HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE']:
        result[key] = '1'
    return result


def freeze_model():
    assert not (W / 'source-freeze-model1.json').exists(), 'Do not overwrite a frozen attempt'
    plan = m.read(W / 'build-plan.json')
    for field in ['ready', 'image', 'closure', 'weights_actual_dependencies']:
        exact(plan['baseline'][field])
    for row in m.read(plan['baseline']['closure']['path']):
        exact(row)
    for row in m.read(plan['baseline']['weights_actual_dependencies']['path']):
        exact(row)
    source = R / 'engine/models/qwen35/main.cc'
    pinned = m.pin(source)
    assert pinned['sha256'] == '5033f0c59c3b6b882065ded2899f8ba503b08d52b702b5abe452887e20cfe8f5'
    snapshot = W / 'source/model1/main.cc'
    snapshot.parent.mkdir(parents=True, exist_ok=False)
    snapshot.write_bytes(source.read_bytes())
    before = {}
    baseline_deps = F / 'compile/model1/actual-dependencies.json'
    for row in m.read(baseline_deps):
        before[m.key(row['path'])] = m.pin(row['path'])
    # Fixed metadata-only pins; no SDK/header copies. This covers newly named
    # local headers as well as the previous actual compiler include closure.
    for root in [R / 'include', R / 'engine/inference', R / 'engine/models/qwen35']:
        for header in root.rglob('*.h'):
            before[m.key(header)] = m.pin(header)
    before[m.key(source)] = pinned
    m.save(W / 'model1-precompile-dependencies.json', list(before.values()))
    recipe = m.read(plan['compilation']['Model']['recipe']['path'])['command']
    out = W / 'compile/model1'
    command = []
    for index, arg in enumerate(recipe):
        if index and recipe[index - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        command.append(arg)
    assert m.build_contract(command) == m.build_contract(recipe)
    m.save(W / 'source-freeze-model1.json', {
        'status': 'SOURCE_FROZEN_NOT_COMPILED', 'source': pinned, 'snapshot': m.pin(snapshot),
        'baseline': plan['baseline'], 'recipe': plan['compilation']['Model']['recipe'],
        'command': command, 'dependencies': m.pin(W / 'model1-precompile-dependencies.json'),
        'scope': 'One main Model CXX only; weights/session_state actual dependencies unchanged; probe awaits independent freeze.'
    })
    print('FROZEN Model ' + pinned['sha256'], flush=True)


def model():
    frozen = m.read(W / 'source-freeze-model1.json')
    for key in ['source', 'snapshot', 'recipe', 'dependencies']:
        exact(frozen[key])
    out = W / 'compile/model1'
    out.mkdir(parents=True, exist_ok=False)
    before = {m.key(x['path']): x for x in m.read(frozen['dependencies']['path'])}
    process = h.execute(frozen['command'], environment(), W / 'logs/model1', timeout=240)
    exact(frozen['source'])
    exact(frozen['snapshot'])
    data = m.read(out / 'dependencies.json')['Data']
    assert m.key(data['Source']) == m.key(frozen['source']['path'])
    dependencies = [m.pin(path) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    for row in dependencies:
        previous = before.get(m.key(row['path']))
        if previous:
            assert row == previous, ('dependency changed during CXX', row['path'])
        else:
            assert not Path(row['path']).resolve().is_relative_to(R), ('unfrozen local header', row['path'])
    m.save(out / 'actual-dependencies.json', dependencies)
    compiled = {
        'source': frozen['source'], 'snapshot': frozen['snapshot'], 'object': m.pin(out / 'unit.obj'),
        'process': process, 'command': m.pin(W / 'logs/model1/command.json'),
        'compiler_dependencies': m.pin(out / 'dependencies.json'),
        'actual_dependencies': m.pin(out / 'actual-dependencies.json')
    }
    m.save(out / 'compiled.json', compiled)
    print('MODEL_CXX_PASS ' + compiled['object']['sha256'], flush=True)


def link_cli():
    frozen = m.read(W / 'source-freeze-model1.json')
    compiled = m.read(W / 'compile/model1/compiled.json')
    for key in ['source', 'snapshot', 'object', 'actual_dependencies']:
        exact(compiled[key])
    for row in m.read(compiled['actual_dependencies']['path']):
        exact(row)
    rows = m.read(frozen['baseline']['closure']['path'])
    original = frozen['baseline']['Model']['object']
    assert len(rows) == 224 and sum(x == original for x in rows) == 1
    rows = [compiled['object'] if row == original else row for row in rows]
    for row in rows:
        exact(row)
    (W / 'bin').mkdir(exist_ok=True)
    runtime = m.read(A / 'runtime.json')
    exact(runtime['original_native_cpu'])
    alias = W / 'bin' / Path(runtime['original_native_cpu']['path']).name
    if not alias.exists():
        os.link(runtime['original_native_cpu']['path'], alias)
    env = environment()
    m.save(W / 'environment.json', {key: env.get(key, '') for key in ['PATH', 'INCLUDE', 'LIB', 'LIBPATH']})
    m.save(W / 'runtime.json', dict(original=m.pin(A / 'runtime.json'),
                                   original_native_cpu=runtime['original_native_cpu'],
                                   alias=m.pin(alias), PATH=env['PATH']))
    image = W / 'bin/hyle.exe'
    command = m.link_command(m.read(A / 'link-cli/command.json')['command'],
                            {m.key(original['path']): compiled['object']['path']}, [], image)
    m.save(W / 'cli-link-inputs.json', rows)
    process = h.execute(command, env, W / 'link-cli1', timeout=180)
    for row in rows:
        exact(row)
    ready = {
        'status': 'CLI_LINKED_NOT_RUN_PROBE_NOT_BUILT',
        'compiled': compiled, 'image': m.pin(image), 'link': process,
        'inputs': m.pin(W / 'cli-link-inputs.json'), 'runtime': m.pin(W / 'runtime.json'),
        'freeze': m.pin(W / 'source-freeze-model1.json'),
        'counts': dict(CXX=1, links=1, model_processes=0, probe_processes=0, SDK=0, NVCC=0, downloads=0)
    }
    m.save(W / 'ready-cli1.json', ready)
    print(json.dumps(ready, indent=2), flush=True)


def freeze_probe():
    assert not (W / 'source-freeze-probe1.json').exists()
    model_freeze = m.read(W / 'source-freeze-model1.json')
    exact(model_freeze['source'])
    exact(model_freeze['snapshot'])
    expected = {
        'tests/tools/qwen_mtp_ahead_test.cc': (16565, '6b643468215739e2eedab447f42b627903508ea215fc014fe4c0df2fb6f8b0b3'),
        'tests/tools/qwen_cpu_ahead_case.h': (7510, 'a6c9cd67213b376e5f131b24ff8c286cbb3b386b755caa3391176ad35a7aad8e')
    }
    sources = []
    for relative in [*expected, 'tests/tools/qwen_host_image_case.h', 'tests/tools/qwen_mtp_batch_state_case.h']:
        source = m.pin(R / relative)
        if relative in expected:
            assert (source['bytes'], source['sha256']) == expected[relative]
        snapshot = W / 'source/probe1' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(Path(source['path']).read_bytes())
        sources.append(dict(source=source, snapshot=m.pin(snapshot)))
    before = {m.key(x['path']): x for x in m.read(W / 'model1-precompile-dependencies.json')}
    for header in (R / 'tests/tools').rglob('*.h'):
        before[m.key(header)] = m.pin(header)
    for row in sources:
        before[m.key(row['source']['path'])] = row['source']
    m.save(W / 'probe1-precompile-dependencies.json', list(before.values()))
    out = W / 'compile/probe1'
    template = model_freeze['command']
    command = []
    for index, arg in enumerate(template):
        if index and template[index - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        elif m.key(arg) == m.key(model_freeze['source']['path']):
            arg = str(R / 'tests/tools/qwen_mtp_ahead_test.cc')
        command.append(arg)
    assert m.build_contract(command) == m.build_contract(template)
    m.save(W / 'source-freeze-probe1.json', {
        'sources': sources, 'main': model_freeze['source'], 'main_snapshot': model_freeze['snapshot'],
        'command': command, 'dependencies': m.pin(W / 'probe1-precompile-dependencies.json'),
        'scope': 'One combined ordinary/MTP host-ahead consumer TU; no separate Model object or engine entry at link.'
    })
    print('FROZEN probe1 and exact main/helpers', flush=True)


def probe():
    frozen = m.read(W / 'source-freeze-probe1.json')
    for row in frozen['sources']:
        exact(row['source'])
        exact(row['snapshot'])
    exact(frozen['main'])
    exact(frozen['main_snapshot'])
    out = W / 'compile/probe1'
    out.mkdir(parents=True, exist_ok=False)
    before = {m.key(x['path']): x for x in m.read(frozen['dependencies']['path'])}
    process = h.execute(frozen['command'], environment(), W / 'logs/probe1', timeout=240)
    data = m.read(out / 'dependencies.json')['Data']
    dependencies = [m.pin(path) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    assert m.key(data['Source']) == m.key(frozen['sources'][0]['source']['path'])
    assert m.key(frozen['main']['path']) in {m.key(x) for x in data['Includes']}
    for row in dependencies:
        previous = before.get(m.key(row['path']))
        if previous:
            assert row == previous, ('probe dependency changed during CXX', row['path'])
        else:
            assert not Path(row['path']).resolve().is_relative_to(R), ('unfrozen local probe header', row['path'])
    for row in frozen['sources']:
        exact(row['source'])
    exact(frozen['main'])
    m.save(out / 'actual-dependencies.json', dependencies)
    compiled = dict(sources=frozen['sources'], main=frozen['main'], object=m.pin(out / 'unit.obj'),
                    process=process, command=m.pin(W / 'logs/probe1/command.json'),
                    compiler_dependencies=m.pin(out / 'dependencies.json'),
                    actual_dependencies=m.pin(out / 'actual-dependencies.json'))
    m.save(out / 'compiled.json', compiled)
    print('PROBE_CXX_PASS ' + compiled['object']['sha256'], flush=True)


def link_probe():
    plan = m.read(W / 'build-plan.json')
    compiled = m.read(W / 'compile/probe1/compiled.json')
    for row in compiled['sources']:
        exact(row['source'])
        exact(row['snapshot'])
    exact(compiled['main'])
    exact(compiled['object'])
    for row in m.read(compiled['actual_dependencies']['path']):
        exact(row)
    original = plan['baseline']['Model']['object']
    entry = plan['baseline']['entry']['object']
    baseline = m.read(plan['baseline']['closure']['path'])
    assert sum(x == original for x in baseline) == sum(x == entry for x in baseline) == 1
    rows = [compiled['object'] if x == original else x for x in baseline if x != entry]
    assert len(rows) == 223 and not any(x in [entry, original] for x in rows)
    for row in rows:
        exact(row)
    image = W / 'bin/qwen-mtp-ahead-probe.exe'
    template = m.read(A / 'link-cli/command.json')['command']
    template = [arg for arg in template if m.key(arg) != m.key(entry['path'])]
    command = m.link_command(template, {m.key(original['path']): compiled['object']['path']}, [], image)
    m.save(W / 'probe-link-inputs.json', rows)
    process = h.execute(command, environment(), W / 'link-probe1', timeout=180)
    for row in rows:
        exact(row)
    ready = dict(status='PROBE_LINKED_NOT_RUN', compiled=compiled, image=m.pin(image), link=process,
                 inputs=m.pin(W / 'probe-link-inputs.json'), runtime=m.pin(W / 'runtime.json'),
                 freeze=m.pin(W / 'source-freeze-probe1.json'),
                 single_main='Current 224 CLI minus engine entry and separate Model plus combined probe = 223')
    m.save(W / 'ready-probe1.json', ready)
    print('PROBE_READY ' + image.as_posix() + ' ' + ready['image']['sha256'], flush=True)


def finalize_probe():
    """Finish metadata after the original successful CXX; never invoke CL."""
    out = W / 'compile/probe1'
    assert not (out / 'compiled.json').exists()
    frozen = m.read(W / 'source-freeze-probe1.json')
    review = m.read(W / 'probe1-late-dependency-review.json')
    assert len(review['missing']) == 1
    expected = review['missing'][0]
    assert Path(expected['path']).name == 'slots_region.h'
    assert expected['sha256'] == '6a7c833379136dea6f1c92dfc32c28a02d446bf06b37463570f273393a80d4ef'
    exact(expected)
    baseline = m.read(W / 'cli-link-inputs.json')
    proofs = []
    for proof in review['proof']:
        assert proof['match'] and proof['consumer_obj'] in baseline
        exact(proof['consumer_obj'])
        exact(proof['original'])
        manifest = m.read(proof['actual_manifest'])
        assert any(m.key(row['path']) == m.key(expected['path']) and
                   (row['bytes'], row['sha256']) == (expected['bytes'], expected['sha256']) for row in manifest)
        proofs.append(dict(object=proof['consumer_obj'], manifest=m.pin(proof['actual_manifest'])))
    assert len(proofs) == 3
    process = m.read(W / 'logs/probe1/process.json')
    assert process['exit'] == 0
    before = {m.key(row['path']): row for row in m.read(frozen['dependencies']['path'])}
    before[m.key(expected['path'])] = expected
    data = m.read(out / 'dependencies.json')['Data']
    dependencies = [m.pin(path) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    assert m.key(data['Source']) == m.key(frozen['sources'][0]['source']['path'])
    assert m.key(frozen['main']['path']) in {m.key(x) for x in data['Includes']}
    for row in dependencies:
        if m.key(row['path']) in before:
            exact(before[m.key(row['path'])])
        else:
            assert not Path(row['path']).resolve().is_relative_to(R)
    for row in frozen['sources']:
        exact(row['source'])
        exact(row['snapshot'])
    exact(frozen['main'])
    supplement = dict(
        header=expected, original_fixed_consumer_proofs=proofs,
        original_failure=m.pin(W / 'failure-probe.log'),
        scope='Preparation script omitted one private header; original CL succeeded. '
              'Its exact bytes match three original fixed Graph compiler manifests; no source drift or recompile.')
    m.save(W / 'probe1-dependency-supplement.json', supplement)
    m.save(out / 'actual-dependencies.json', dependencies)
    compiled = dict(sources=frozen['sources'], main=frozen['main'], object=m.pin(out / 'unit.obj'),
                    process=process, command=m.pin(W / 'logs/probe1/command.json'),
                    compiler_dependencies=m.pin(out / 'dependencies.json'),
                    actual_dependencies=m.pin(out / 'actual-dependencies.json'),
                    late_dependency_supplement=m.pin(W / 'probe1-dependency-supplement.json'))
    m.save(out / 'compiled.json', compiled)
    print('PROBE_METADATA_FINALIZED_NO_RECOMPILE', flush=True)


def run_probe(backend):
    assert backend in ['cpu', 'cuda']
    ready = m.read(W / 'ready-probe1.json')
    exact(ready['image'])
    exact(ready['inputs'])
    exact(ready['runtime'])
    for row in m.read(ready['inputs']['path']):
        exact(row)
    fixture = Path(m.read(W / 'build-plan.json')['validation']['fixture']['path'])
    command = [ready['image']['path'], '--' + backend, str(fixture)]
    out = W / ('run-' + backend)
    assert not out.exists(), 'No automatic successful-process rerun'
    process = h.execute(command, environment(), out, timeout=180)
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    m.save(out / 'report.json', report)
    assert report['status'] == 'PASS' and report['backend'] == backend
    ordinary, mtp = report['ordinary'], report['mtp']
    assert ordinary['status'] == 'PASS' and ordinary['backend'] == backend
    assert ordinary['candidate_hits'] == 3 and ordinary['control_hits'] == 0 and ordinary['final_versions'] == 0
    assert mtp['candidate_hits'] == 2 and mtp['control_hits'] == 0 and mtp['final_versions'] == 0
    assert mtp['prefixes_by_original_member'] == [[1, 3], [3, 1]]
    for key in ['reorder_consumed', 'survivor_subset_consumed', 'stopped_peer_rejected',
                'actual_t3_to_t2_lag1', 'complete_initialized_state_equal', 'old_checkpoints_unchanged']:
        assert mtp[key]
    assert not mtp['natural_recursive_acceptance_claim'] and not mtp['performance_claim']
    assert mtp['gpu_successor_submissions'] == 0 and mtp['selected_bytes'] > 0
    result = dict(status='PASS', backend=backend, process=process, report=m.pin(out / 'report.json'),
                  image=ready['image'], ready=m.pin(W / 'ready-probe1.json'),
                  boundary='Controlled prefix/host-metadata ahead, no pending GPU successor or performance claim')
    m.save(out / 'summary.json', result)
    summaries = [m.read(W / ('run-' + name) / 'summary.json') for name in ['cpu', 'cuda']
                 if (W / ('run-' + name) / 'summary.json').exists()]
    m.save(W / 'probe-run-summary.json', dict(status='PASS' if len(summaries) == 2 else 'CPU_PASS_CUDA_NOT_RUN',
           processes=summaries, process_count=len(summaries), CLI_runs=0))
    print('PROBE_PASS ' + backend + ' ' + json.dumps(report), flush=True)


if __name__ == '__main__':
    try:
        {'freeze-model': freeze_model, 'model': model, 'link-cli': link_cli,
         'freeze-probe': freeze_probe, 'probe': probe, 'link-probe': link_probe,
         'finalize-probe': finalize_probe,
         'run-cpu': lambda: run_probe('cpu'), 'run-cuda': lambda: run_probe('cuda')}[sys.argv[1]]()
    except BaseException:
        (W / ('failure-' + sys.argv[1] + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
