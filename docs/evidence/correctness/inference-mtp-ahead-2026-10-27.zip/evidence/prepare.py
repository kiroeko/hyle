from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
A = R / '.scratch/inference-alias-role-filter-20261027'
F = R / '.scratch/inference-generation-batch-facts-20261027'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def pin(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def contract(path):
    args = read(path)['command']
    return {
        'compiler': args[0],
        'definitions': sorted(x for x in args if x.lower().startswith('/d')),
        'flags': [x for x in args if x in ['/O2', '/Ob2', '/MD', '/std:c++latest',
                                          '/EHsc', '/WX', '/W4', '/permissive-', '/bigobj']]
    }


rows = read(A / 'cli-link-inputs.json')
assert len(rows) == 224
for row in rows:
    exact(row)
ready = read(A / 'ready-cli.json')
exact(ready['image'])
assert ready['image']['sha256'] == 'd31045416935e34c857bbb19ea79cd96f86f3a997b1b782a7919ae601b5a5367'
selected = {}
for row in rows:
    dep = Path(row['path']).parent / 'dependencies.json'
    if dep.exists():
        data = read(dep).get('Data', {})
        if data.get('Source'):
            selected[key(data['Source'])] = {
                'source': data['Source'], 'object': row, 'compiler_dependencies': pin(dep),
                'private_headers': [pin(x) for x in data['Includes']
                                    if Path(x).name in ['session_state.h', 'readback.h']]
            }
model = selected[key(R / 'engine/models/qwen35/main.cc')]
entry = selected[key(R / 'engine/main.cc')]
weights = selected[key(R / 'engine/models/qwen35/weights.cc')]
model_recipe = F / 'logs/model1/command.json'
weights_recipe = Path(weights['object']['path']).parent / 'command.json'
assert contract(model_recipe) == contract(weights_recipe)
weight_deps = Path(weights['object']['path']).parent / 'actual-dependencies.json'
for row in read(weight_deps):
    exact(row)
assert any(Path(x['path']).name == 'session_state.h' for x in weights['private_headers'])

plan = {
    'status': 'PREPARED_ONLY_AWAIT_ROOT_API_AND_SOURCE_FREEZE',
    'workdir': str(W),
    'baseline': {
        'ready': pin(A / 'ready-cli.json'), 'image': ready['image'],
        'closure': pin(A / 'cli-link-inputs.json'), 'inputs': 224,
        'Model': model, 'entry': entry, 'weights': weights,
        'actual_compile_contract': contract(model_recipe), 'weights_recipe': pin(weights_recipe),
        'weights_actual_dependencies': pin(weight_deps), 'weights_actual_dependencies_match': True,
        'ABI_boundary': 'Current Model and weights have identical CPU+CUDA compile contract. '
                        'Weights actually includes session_state.h; recheck exact dependency bytes '
                        'at source freeze, otherwise report a necessary weights rebuild.'
    },
    'compilation': {
        'Model': {'source': str(R / 'engine/models/qwen35/main.cc'), 'source_pin': None,
                  'recipe': pin(model_recipe), 'out': str(W / 'compile/model')},
        'combined_probe': {'source': None, 'source_pin': None, 'recipe': pin(model_recipe),
                           'out': str(W / 'compile/probe')},
        'action': 'After root freeze only: snapshot/pin main and final probe. Derive current mixed '
                  'Model command, replace sourceDependencies/Fo/Fd. No old CUDA-only probe macros.'
    },
    'linking': {
        'recipe': pin(A / 'link-cli/command.json'),
        'CLI': {'inputs': 224, 'replace': model['object'], 'with': str(W / 'compile/model/unit.obj')},
        'probe': {'inputs': 223, 'remove': [model['object'], entry['object']],
                  'add': str(W / 'compile/probe/unit.obj')},
        'outputs': {
            kind: {option: str(W / ('bin/' + stem + suffix))
                   for option, suffix in [('OUT', '.exe'), ('PDB', '.pdb'), ('IMPLIB', '.lib')]}
            for kind, stem in [('CLI', 'hyle'), ('probe', 'qwen-mtp-ahead-probe')]
        },
        'rule': 'Preserve every other current object/library pin. Combined probe has exactly '
                'one main and neither the separate product Model nor engine entry.'
    },
    'references': {},
    'validation': {
        'controlled_processes': [{'backend': x, 'command_pending_final_API': True}
                                 for x in ['cpu', 'cuda']],
        'desired_checks': [
            'Actual B2 K>=3 unequal acceptance against same-width no-ahead control',
            'reorder/pause/cancel/mismatch discard stale metadata without changing results',
            'ordinary ahead regression in the same two combined-backend processes',
            'exact owner/epoch/length/T1/sampler/order, positions written on actual prepare',
            'real state-bank bytes, KV/pending/RNG, old snapshots and actual retirement'
        ],
        'CLI_processes': [],
        'rules': 'One process per selected backend/arm after freeze. Stop on first actual failure. '
                 'Exit77/skip is not PASS. Save stdout/stderr/command/process/reports. No timing samples.'
    },
    'environment': {
        'template': pin(A / 'environment.json'), 'runtime': pin(A / 'runtime.json'),
        'rule': 'Use saved INCLUDE/LIB/LIBPATH and runtime PATH. Optional exact native_cpu DLL '
                'hardlink into this W/bin. Set offline flags; no SDK/model copying.'
    },
    'counts': {'now_CXX': 0, 'now_link': 0, 'now_process': 0, 'planned_Model_CXX': 1,
               'planned_combined_probe_CXX': 1, 'planned_links': 2,
               'planned_controlled_processes': 2, 'planned_CLI_processes': 4,
               'SDK': 0, 'NVCC': 0, 'downloads': 0},
    'freeze_requirements': [
        'Root final API and frozen main/probe: no active canonical main freeze was taken here',
        'Recheck weights/session_state exact actual dependencies and macro contract',
        'All compiler/link output paths inside this W',
        'Probe actual Includes must name frozen main; link removes both previous main owners'
    ]
}
for name, relative in {
    'ordinary_ahead_source': 'tests/tools/qwen_cpu_ahead_test.cc',
    'ordinary_prior_recipe': '.scratch/inference-cpu-ahead-20261027/attempt2/compile/command.json',
    'ordinary_prior_ready': '.scratch/inference-cpu-ahead-20261027/attempt2/ready.json',
    'controlled_MTP_helper': 'tests/tools/qwen_mtp_batch_state_case.h',
    'controlled_MTP_host_entry': 'tests/tools/qwen_host_image_test.cc',
    'controlled_MTP_prior_recipe': '.scratch/inference-engine-slot-state-20261027/b2-mtp-state/attempt3/compile/command.json',
    'controlled_MTP_prior_ready': '.scratch/inference-engine-slot-state-20261027/b2-mtp-state/attempt3/ready.json'
}.items():
    plan['references'][name] = pin(R / relative)
plan['references']['actual_existing_scope'] = (
    'qwen_cpu_ahead_test.cc is CUDA ordinary-only: consume/discard same-width oracle, B2 reorder, '
    'paused-cancelled subset. qwen_mtp_batch_state_case.h has K3 rounds [1,3] then [3,1], '
    'independent bank IDs/bytes, original snapshots/KV/pending/RNG. Neither old binary proves new main.'
)
for backend in ['cpu', 'cuda']:
    for mode in ['ordinary', 'mtp-k3']:
        recipe = F / 'runs' / ('regression-' + backend + '-' + mode + '-b2') / 'command.json'
        command = read(recipe)['command']
        command[0] = str(W / 'bin/hyle.exe')
        plan['validation']['CLI_processes'].append({
            'name': backend + '-' + mode + '-b2', 'recipe': pin(recipe),
            'command': command, 'cwd': str(R), 'timeout_seconds': 180
        })
fixture = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
plan['validation']['fixture'] = {'path': str(fixture), 'weights_manifest': pin(fixture / 'weights.tsv')}
plan['validation']['schedule'] = pin(R / '.scratch/inference-relay-carriers-20261027/attempt2/case/sessions.tsv')
target = W / 'build-plan.json'
target.write_text(json.dumps(plan, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'status': plan['status'], 'plan': pin(target), 'counts': plan['counts']}, indent=2))
