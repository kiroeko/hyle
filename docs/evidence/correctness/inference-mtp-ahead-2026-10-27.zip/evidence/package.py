from pathlib import Path
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
DEST = R / 'docs/evidence/correctness/inference-mtp-ahead-2026-10-27.json'
CACHE = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path).resolve()
    key = str(path).casefold()
    if key not in CACHE:
        data = path.read_bytes()
        CACHE[key] = dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return dict(CACHE[key])


def exact(row):
    current = pin(row['path'])
    assert (current['bytes'], current['sha256']) == (row['bytes'], row['sha256']), (row, current)
    return current


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def compact(value, depth=0):
    if depth >= 2 or not isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    if isinstance(value, dict):
        if not value:
            return '{}'
        body = ['  ' * (depth + 1) + json.dumps(k) + ': ' + compact(v, depth + 1) for k, v in value.items()]
        return '{\n' + ',\n'.join(body) + '\n' + '  ' * depth + '}'
    if not value:
        return '[]'
    body = ['  ' * (depth + 1) + compact(v, depth + 1) for v in value]
    return '[\n' + ',\n'.join(body) + '\n' + '  ' * depth + ']'


def facts(value):
    # Exactly run_cli.py/run_real.py: no new post-hoc exclusions.
    if isinstance(value, list):
        return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k: facts(v) for k, v in value.items()
                if k not in {'cpu_ahead_prepared', 'cpu_ahead_hits', 'cpu_ahead_discarded'}
                and not any(x in k for x in ['seconds', 'per_second', 'capture', 'replay', 'trace_name'])}
    return value


def facts_hash(report):
    return hashlib.sha256(json.dumps(facts(report), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def checked_report(row):
    exact(row['report'])
    directory = Path(row['report']['path']).parent
    report = read(directory / 'report.json')
    assert read(directory / 'stdout.log') == report
    assert read(directory / 'process.json') == row['process'] and row['process']['exit'] == 0
    command = read(directory / 'command.json')['command']
    assert report.get('live_committed_versions', 0) == 0
    return report, command


def main():
    assert not DEST.exists() and not DEST.with_suffix('.zip').exists(), 'Do not overwrite published evidence'
    plan = read(W / 'build-plan.json')
    ready_cli, ready_probe = read(W / 'ready-cli1.json'), read(W / 'ready-probe1.json')
    model, probe = ready_cli['compiled'], ready_probe['compiled']
    expected_main = '5033f0c59c3b6b882065ded2899f8ba503b08d52b702b5abe452887e20cfe8f5'
    assert model['source']['sha256'] == probe['main']['sha256'] == expected_main
    assert probe['sources'][0]['source']['sha256'] == '6b643468215739e2eedab447f42b627903508ea215fc014fe4c0df2fb6f8b0b3'
    assert probe['sources'][1]['source']['sha256'] == 'a6c9cd67213b376e5f131b24ff8c286cbb3b386b755caa3391176ad35a7aad8e'
    for unit in [model, probe]:
        assert unit['process']['exit'] == 0
        for key in ['object', 'command', 'compiler_dependencies', 'actual_dependencies']:
            exact(unit[key])
        for dep in read(unit['actual_dependencies']['path']):
            exact(dep)
    assert model['source']['sha256'] == model['snapshot']['sha256']
    exact(model['snapshot'])
    for row in probe['sources']:
        assert row['source']['sha256'] == row['snapshot']['sha256']
        exact(row['source'])
        exact(row['snapshot'])
    baseline = read(plan['baseline']['closure']['path'])
    exact(plan['baseline']['closure'])
    assert len(baseline) == 224
    for row in baseline:
        exact(row)
    exact(plan['baseline']['weights_actual_dependencies'])
    for row in read(plan['baseline']['weights_actual_dependencies']['path']):
        exact(row)
    original = plan['baseline']['Model']['object']
    entry = plan['baseline']['entry']['object']
    for kind, ready in [('cli', ready_cli), ('probe', ready_probe)]:
        for field in ['image', 'inputs', 'runtime', 'freeze']:
            exact(ready[field])
        assert ready['link']['exit'] == 0
        rows = read(ready['inputs']['path'])
        expected = [model['object'] if row == original else row for row in baseline] if kind == 'cli' else [
            probe['object'] if row == original else row for row in baseline if row != entry]
        assert rows == expected and len(rows) == (224 if kind == 'cli' else 223)
        for row in rows:
            exact(row)
        link = read(W / ('link-' + kind + '1') / 'command.json')['command']
        outputs = [x for x in link if x.lower().startswith(('/out:', '/pdb:', '/implib:'))]
        assert len(outputs) == 3 and all(Path(x.split(':', 1)[1]).resolve().is_relative_to(W) for x in outputs)
    runtime = read(W / 'runtime.json')
    for field in ['original', 'original_native_cpu', 'alias']:
        exact(runtime[field])
    supplement = read(W / 'probe1-dependency-supplement.json')
    exact(probe['late_dependency_supplement'])
    exact(supplement['header'])
    exact(supplement['original_failure'])
    assert supplement['header']['sha256'] == '6a7c833379136dea6f1c92dfc32c28a02d446bf06b37463570f273393a80d4ef'
    for row in supplement['original_fixed_consumer_proofs']:
        exact(row['object'])
        exact(row['manifest'])
    probe_runs, cli_runs, real_runs = (read(W / name) for name in [
        'probe-run-summary.json', 'cli-summary.json', 'real-summary.json'])
    assert probe_runs['status'] == cli_runs['status'] == real_runs['status'] == 'PASS'
    assert len(probe_runs['processes']) == 2 and len(cli_runs['results']) == len(real_runs['results']) == 4
    all_runs, tiny_reports = [], {}
    for row in probe_runs['processes']:
        report, command = checked_report(row)
        assert command[0] == ready_probe['image']['path'] and command[1] == '--' + row['backend']
        assert report['status'] == 'PASS' and report['backend'] == row['backend']
        assert report['ordinary']['candidate_hits'] == 3 and report['ordinary']['control_hits'] == 0
        mtp = report['mtp']
        assert mtp['prefixes_by_original_member'] == [[1, 3], [3, 1]]
        assert mtp['candidate_hits'] == 2 and mtp['selected_bytes'] == 70144 and mtp['final_versions'] == 0
        assert mtp['complete_initialized_state_equal'] and mtp['old_checkpoints_unchanged']
        assert not mtp['natural_recursive_acceptance_claim'] and not mtp['performance_claim']
        assert mtp['gpu_successor_submissions'] == 0
        tiny_reports[row['backend']] = report
        all_runs.append(dict(group='tiny_controlled', name=row['backend'], process=row['process'], report=row['report']))
    for row in cli_runs['results']:
        report, command = checked_report(row)
        exact(row['original'])
        assert command[0] == ready_cli['image']['path']
        assert facts(report) == facts(read(row['original']['path']))
        assert report['generated_tokens'] == 16 and report['overlap_successor_submissions'] == 0
        assert row['complete_non_time_report_equal_except_named_ahead_counters']
        all_runs.append(dict(group='tiny_CLI_B2', name=row['name'], process=row['process'],
                             report=row['report'], original=row['original'], facts_sha256=facts_hash(report),
                             ahead=row['ahead']))
    real_oracle = {}
    for row in real_runs['results']:
        report, command = checked_report(row)
        exact(row['image'])
        assert row['image'] == (plan['baseline']['image'] if row['arm'] == 'baseline' else ready_cli['image'])
        assert command[0] == row['image']['path']
        assert command[command.index('--mtp') + 1] == row['mode']
        assert ('--mtp-max-drafts' in command) == (row['mode'] == 'on')
        assert report['generated_tokens'] == 24 and report['overlap_successor_submissions'] == 0
        if row['mode'] not in real_oracle:
            real_oracle[row['mode']] = facts(report)
        assert facts(report) == real_oracle[row['mode']]
        if row['name'] == 'candidate-mtp-on':
            assert row['ahead'] == dict(cpu_ahead_prepared=4, cpu_ahead_hits=3, cpu_ahead_discarded=2)
        all_runs.append(dict(group='real2B_CUDA_B2', name=row['name'], process=row['process'],
                             image=row['image'], report=row['report'], facts_sha256=facts_hash(report), ahead=row['ahead']))
    assert real_runs['exact_reports_equal_per_mode_except_named_ahead_counters']
    assert len(all_runs) == len({row['process']['pid'] for row in all_runs}) == 10
    rejected = W / 'real/baseline-mtp-off'
    reject_process = read(rejected / 'process.json')
    reject_command = read(rejected / 'command.json')['command']
    reject_stderr = (rejected / 'stderr.log').read_text(encoding='utf-8-sig')
    assert reject_process['exit'] == 1 and '--mtp-max-drafts' in reject_command
    assert reject_command[reject_command.index('--mtp') + 1] == 'off'
    assert '--mtp-max-drafts requires --mtp on' in reject_stderr
    assert not (rejected / 'stdout.log').read_text(encoding='utf-8-sig').strip()
    assert len((W / 'real-case/prompt.ids').read_text().split()) == 154
    files = []
    allowed_roots = {'source', 'compile', 'logs', 'link-cli1', 'link-probe1', 'run-cpu', 'run-cuda',
                     'runs', 'real', 'real2', 'real-case'}
    allowed_suffixes = {'.py', '.json', '.log', '.cc', '.h', '.txt', '.ids', '.schedule', '.tsv'}
    for path in W.rglob('*'):
        rel = path.relative_to(W)
        if not path.is_file() or '__pycache__' in rel.parts or path.name in [
                'ahead_methods.cc', 'archive-manifest.json', 'package-result.json']:
            continue
        if path.suffix.lower() not in allowed_suffixes or (len(rel.parts) > 1 and rel.parts[0] not in allowed_roots):
            continue
        files.append(path)
    manifest = [dict(archive_path='evidence/' + p.relative_to(W).as_posix(), **pin(p)) for p in sorted(files)]
    save(W / 'archive-manifest.json', manifest)
    files.append(W / 'archive-manifest.json')
    receipt = {
        'schema': 'hyle.inference-mtp-host-ahead.v1', 'date': '2026-10-27', 'status': 'PASS',
        'scope': 'Per-member ordinary/MTP CPU metadata-ahead; original Graph execution, resource permissions and retirement unchanged.',
        'counts': dict(CXX_attempts=2, distinct_TU=2, links=2, successful_processes=10, command_rejections=1,
                       probe_processes=2, tiny_CLI_processes=4, real2B_CLI_processes=4, SDK=0, NVCC=0, downloads=0),
        'source': dict(Model=model['source'], Model_snapshot=model['snapshot'],
                       probe=probe['sources'][0], ordinary_helper=probe['sources'][1],
                       all_frozen_helpers=probe['sources'], source_freezes=[pin(W / 'source-freeze-model1.json'), pin(W / 'source-freeze-probe1.json')]),
        'build': dict(Model_object=model['object'], probe_object=probe['object'],
                      compiler_processes=[model['process'], probe['process']], linker_processes=[ready_cli['link'], ready_probe['link']],
                      actual_dependencies=[model['actual_dependencies'], probe['actual_dependencies']],
                      CLI=dict(image=ready_cli['image'], inputs=ready_cli['inputs'], count=224, sole_replacement='Model'),
                      probe=dict(image=ready_probe['image'], inputs=ready_probe['inputs'], count=223,
                                 main='Baseline CLI minus separate Model and engine entry plus combined probe'),
                      reused_weights=plan['baseline']['weights']['object'],
                      output_paths_isolated=True, baseline=plan['baseline']['closure'],
                      baseline_evidence='docs/evidence/performance/inference-alias-role-filter-2026-10-27.json'),
        'tiny_controlled': dict(summary=pin(W / 'probe-run-summary.json'), backends=tiny_reports,
                               boundary='Full initialized state-byte and old-checkpoint comparison against same-width no-ahead control per backend; not CPU-vs-CUDA bit equality. Controlled K3 prefixes are not natural acceptance quality.'),
        'tiny_complete_CLI': dict(summary=pin(W / 'cli-summary.json'), scope=cli_runs['scope']),
        'real2B_complete_CLI': dict(summary=pin(W / 'real-summary.json'),
                                   scope='CUDA R2, two P154 prompts, 12 outputs/member, C256, ordinary and recursive MTP baseline/candidate.',
                                   candidate_MTP=dict(outputs=24, prepared=4, hits=3, discarded=2),
                                   boundary='Complete report/IDs/decisions/state-accounting facts compared per mode; no independent full-state payload-byte oracle for real2B.'),
        'report_comparison': dict(ignored_exact_keys=['cpu_ahead_prepared', 'cpu_ahead_hits', 'cpu_ahead_discarded'],
                                  original_ignored_key_substrings=['seconds', 'per_second', 'capture', 'replay', 'trace_name'],
                                  applies_recursively=True, additional_exclusions=False,
                                  tiny='Against four retained original reports', real='Baseline/candidate complete facts equal separately for MTP off/on'),
        'successful_processes': all_runs,
        'retained_failures': dict(command=dict(process=reject_process, command=pin(rejected / 'command.json'), stderr=pin(rejected / 'stderr.log'),
                                               note='First baseline off command wrongly passed --mtp-max-drafts; CLI rejected before loading. Corrected run_real.py uses real2; attempt1 script retained.'),
                                 preparation=dict(record=probe['late_dependency_supplement'],
                                                  note='Probe CL exit0; post-CXX script omitted slots_region.h pre-pin. Exact header matched three fixed Graph compiler manifests, metadata finalized without recompilation.')),
        'runtime': pin(W / 'runtime.json'),
        'limits': ['CPU host metadata ahead only; no GPU successor submissions or MTP depth-two device relay.',
                   'No new TPS/performance/peer/model-quality claim; process wall times are reproduction metadata.',
                   'Raw ready status describes build time; the ten process records establish later execution.'],
        'archive': dict(path=str(DEST.with_suffix('.zip')), files=len(files) + 1, manifest=pin(W / 'archive-manifest.json'),
                        excluded='EXE/OBJ/PDB/LIB/EXP/DLL/SDK/models and uncompiled ahead_methods.cc draft')
    }
    text = compact(receipt) + '\n'
    assert len(text.splitlines()) < 200
    DEST.parent.mkdir(parents=True, exist_ok=True)
    DEST.write_text(text, encoding='utf-8')
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.write(DEST, 'receipt.json')
        for path in sorted(files):
            archive.write(path, 'evidence/' + path.relative_to(W).as_posix())
    assert read(DEST) == receipt
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None and json.loads(archive.read('receipt.json')) == receipt
        assert len(archive.namelist()) == receipt['archive']['files']
        assert not any('ahead_methods.cc' in name or Path(name).suffix.lower() in [
            '.exe', '.obj', '.pdb', '.lib', '.exp', '.dll', '.gguf', '.safetensors'] for name in archive.namelist())
        for row in manifest:
            data = archive.read(row['archive_path'])
            assert (len(data), hashlib.sha256(data).hexdigest()) == (row['bytes'], row['sha256'])
    result = dict(status='ARCHIVED_AND_READ_BACK', receipt=pin(DEST), archive=pin(DEST.with_suffix('.zip')),
                  json_lines=len(text.splitlines()), files=len(files) + 1, new_build_or_execution=0)
    save(W / 'package-result.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
