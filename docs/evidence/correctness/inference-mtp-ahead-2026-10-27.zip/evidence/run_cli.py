from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('mtp_ahead_cli_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
m, h = b.m, b.h

def facts(value):
    if isinstance(value, list):
        return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k: facts(v) for k, v in value.items()
                if k not in {'cpu_ahead_prepared', 'cpu_ahead_hits', 'cpu_ahead_discarded'}
                and not any(x in k for x in ['seconds', 'per_second', 'capture', 'replay', 'trace_name'])}
    return value

def main():
    ready = m.read(W / 'ready-cli1.json')
    b.exact(ready['image'])
    plan = m.read(W / 'build-plan.json')
    results = []
    for row in plan['validation']['CLI_processes']:
        command = row['command'][:]
        command[0] = ready['image']['path']
        name = row['name']
        out = W / 'runs' / ('cli-' + name)
        process = h.execute(command, b.environment(), out, timeout=180)
        report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
        m.save(out / 'report.json', report)
        before_path = R / '.scratch/inference-generation-batch-facts-20261027/runs' / ('regression-' + name) / 'report.json'
        before = m.read(before_path)
        if facts(report) != facts(before):
            changed = [k for k in facts(report) if facts(report)[k] != facts(before).get(k)]
            m.save(out / 'comparison-failure.json', dict(changed=changed, original=m.pin(before_path)))
            raise AssertionError((name, 'non-time/non-ahead-counter report changed', changed))
        assert report['live_committed_versions'] == 0
        result = dict(name=name, process=process, report=m.pin(out / 'report.json'), original=m.pin(before_path),
                      complete_non_time_report_equal_except_named_ahead_counters=True,
                      actual_graph_calls=report['actual_graph_calls'], generated_tokens=report['generated_tokens'],
                      ahead={k: report[k] for k in ['cpu_ahead_prepared', 'cpu_ahead_hits', 'cpu_ahead_discarded']})
        results.append(result)
        m.save(W / 'cli-partial.json', results)
        print('PASS ' + name + ' ' + json.dumps(result['ahead']), flush=True)
    m.save(W / 'cli-summary.json', dict(status='PASS', image=ready['image'], results=results,
           scope='Four CPU/CUDA ordinary/MTP B2 regressions; only named ahead counters excluded in addition to original time/replay keys; no throughput claim'))

if __name__ == '__main__':
    main()
