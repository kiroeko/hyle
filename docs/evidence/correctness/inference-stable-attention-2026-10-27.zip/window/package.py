"""Offline correctness receipt; run only after the independent timing window.

No build, inference, dependency acquisition, object copying or cleanup. The
archive contains bounded project changes and receipts, never SDK/model payload.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-stable-attention-2026-10-27'
PRODUCTS = (
    'src/compute_provider_flashinfer/native_batch.cu',
    'src/compute_provider_flashinfer/native_batch.h',
    'src/compute_provider_flashinfer/flashinfer_provider.cc',
    'src/compute_batch/batch_execution.cc',
    'include/hyle/compute/batch_execution.h',
    'include/hyle/compute/detail/batch_provider.h')
TEST = 'tests/graph_batch/batch_capture_test.cc'
ARMS = ('two-turn-off', 'two-turn-auto', 'single-mtp')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def short(row):
    path = Path(row['path'])
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path),
                bytes=row['bytes'], sha256=row['sha256'])


def record_rows(stderr):
    pattern = r'^prepared T=(\d+) visible=(\d+).*capture_recorded=(\d+) capture_reused=(\d+)$'
    return [dict(T=int(m[1]), visible=int(m[2]), recorded=int(m[3]), reused=int(m[4]))
            for m in re.finditer(pattern, stderr, re.M) if int(m[3])]


def main():
    assert not OUT.with_suffix('.zip').exists(), 'Preserve any published archive'
    ready = read(W / 'ready-cli.json')
    component = read(W / 'ready-component.json')
    outcome = read(W / 'component-summary.json')
    assert outcome['status'] == 'PASS_ONE_GTEST' and outcome['executions'] == 96
    assert outcome['process']['exit'] == 0
    # These two images have distinct paths and have not been replaced. Pin them
    # once outside the timing window; their bytes never enter the archive.
    exact(ready['image']); exact(component['image'])
    frozen = read(W / 'frozen-plan.json')
    rows = read(W / 'source-freeze.json')
    products = []
    for relative in PRODUCTS:
        row = next(row for row in rows if Path(row['original']['path']) == R / relative)
        exact(row['original']); exact(row['snapshot'])
        products.append(dict(path=relative, bytes=row['snapshot']['bytes'], sha256=row['snapshot']['sha256']))
    current_test = next(row for row in read(W / 'component-source-freeze3.json')
                        if Path(row['original']['path']) == R / TEST)
    exact(current_test['original']); exact(current_test['snapshot'])
    assert current_test['snapshot']['sha256'] == outcome['source']['sha256']
    models = []
    old_paths = set()
    for arm in ARMS:
        directory = W / 'model-checks' / arm
        result = read(directory / 'summary.json')
        assert result['status'] == 'FINITE_FUNCTIONAL_FACTS_PASS' and result['process']['exit'] == 0
        exact(result['original'])
        original = Path(result['original']['path'])
        old_stderr = original.with_name('stderr.log')
        old_paths.update((original, old_stderr, original.with_name('command.json')))
        previous_records = record_rows(old_stderr.read_text(encoding='utf-8-sig'))
        new_records = record_rows((directory / 'stderr.log').read_text(encoding='utf-8-sig'))
        assert sum(x['recorded'] for x in new_records) == sum(x['recorded'] for x in result['recorded'])
        original_data, actual = read(original), read(directory / 'stdout.log')
        models.append(dict(arm=arm, process=result['process'],
            recorded_ranges_before=sum(x['recorded'] for x in previous_records),
            recorded_ranges_after=sum(x['recorded'] for x in new_records),
            new_recorded_visible=[x['visible'] for x in new_records],
            publications_before=original_data['overlap_successor_publications'],
            publications_after=actual['overlap_successor_publications'],
            refusals_before=original_data['overlap_successor_refusals'],
            refusals_after=actual['overlap_successor_refusals'],
            complete_non_time_differences=result['complete_non_time_differences']))
    assert [(x['recorded_ranges_before'], x['recorded_ranges_after']) for x in models] == [(3, 1), (15, 7), (11, 11)]
    assert models[1]['publications_after'] == 110 and models[1]['refusals_after'] == 0
    compiles = {name: read(W / 'logs' / name / 'process.json') for name in ('native', 'provider', 'batch', 'component2', 'component3')}
    assert compiles['component2']['exit'] == 2
    assert all(compiles[name]['exit'] == 0 for name in ('native', 'provider', 'batch', 'component3'))
    assert all(read(W / directory / 'process.json')['exit'] == 0 for directory in ('link-cli', 'link-component'))
    # The first metadata freeze had an unchecked Result member access found by
    # source review; no compiler consumed it. Preserve it separately from the
    # one actual macro-name compilation failure and the final successful TU.
    changes = subprocess.run(['git', 'diff', '--no-ext-diff', '--', *PRODUCTS, TEST],
                             cwd=R, check=True, capture_output=True).stdout
    assert changes, 'Expected this prototype working-tree diff'
    (W / 'design.diff').write_bytes(changes)
    vendor = read(W / 'preparation-plan.json')['vendor']
    assert vendor['version'] == 'hyle-flashinfer-msvc-portability-v16'
    old_header = R / '.scratch/inference-layout-storage-native-20261025/host1/source/src/compute_provider_flashinfer/native_batch.h'
    current_header = W / 'source/src/compute_provider_flashinfer/native_batch.h'
    declarations = {}
    token_text = lambda text: re.sub(r'\s+', '', re.sub(r'//[^\n]*|/\*.*?\*/', '', text, flags=re.S))
    for name in ('BatchSpec', 'BatchFacts'):
        pattern = r'struct ' + name + r' final \{.*?\n\};'
        previous = re.search(pattern, old_header.read_text(encoding='utf-8-sig'), re.S).group()
        current = re.search(pattern, current_header.read_text(encoding='utf-8-sig'), re.S).group()
        assert token_text(previous) == token_text(current)
        declarations[name] = dict(previous=previous, current=current,
            tokens_identical=True, token_sha256=hashlib.sha256(token_text(current).encode()).hexdigest())
    (W / 'struct-declaration-proof.json').write_text(json.dumps(dict(old_header=pin(old_header),
        current_header=pin(current_header), declarations=declarations), indent=2) + '\n', encoding='utf-8')
    receipt = dict(
        schema='hyle.correctness.stable-attention.v1', date='2026-10-27', status='PASS_FINITE_PROTOTYPE',
        scope='Real Graph capture/numerical matrix plus three existing natural CUDA model checks; performance is a separate window.',
        implementation=dict(
            native_domain='Paged plain F16/BF16; uniform T1/T2; causal, window=-1; equal QK/V depth 64/128/256.',
            mechanism='Original FlashInfer scheduler query compares all recorded plan fields; original planning/upload/true retirement and BeforeCommandChange remain.',
            ABI='BatchSpec and BatchFacts exact declaration tokens equal the original compiled headers. Other native TUs are retained; no public runtime flags changed.',
            products=products, test=dict(path=TEST, bytes=outcome['source']['bytes'], sha256=outcome['source']['sha256'])),
        toolchain=dict(OS='Windows x64', CUDA='13.3', SM='89', NVCC_optimization='-O2', host_runtime='/MD',
            dependency=vendor, verified_header_count=len(frozen['vendor_headers']),
            note='Original actual v16 verified-header overlay/recipe reused; not v21. No vendor tree copied or rebuilt.'),
        builds=dict(attempts=dict(NVCC=1, host_CXX=4, successful_host_CXX=3, failed_test_CXX=1, links=2),
            process=compiles, cli_inputs=224, component_inputs=225,
            failures=[dict(stage='component2 CXX', exit=2, reason='Four same-line SCOPED_TRACE macros generated gtest_trace_614 redefinitions; no link or GPU followed that failed TU.'),
                      dict(stage='metadata-only source review', reason='replay_report Result access corrected before any CXX; initial frozen snapshot retained.')],
            reuse='Both images use the three new product objects. Component removes actual Model/CLI entry TUs and adds one test TU plus existing /MD GTest support.'),
        component=dict(name=component['filter'], process=outcome['process'], R=[1, 2], T=[1, 2],
            KV=[127, 128, 129, 383, 384, 385, 1023], dtype='BF16', page_size=16, D=256,
            query_heads=4, kv_heads=2, independent_invocations=2, executions=96,
            recorded_capture_ranges=outcome['recorded_capture_ranges'], reused_capture_ranges=outcome['reused_capture_ranges'],
            plan_host_waits=outcome['plan_host_waits'], maximum_absolute_error=outcome['maximum_absolute_error'], allowed_absolute_error=.007,
            checked=['FP64 dot/softmax/value reference from original BF16 words for every active output; bottom-right causal mask and permuted physical pages.',
                     'Inactive output words zero; both adjacent caller guard regions unchanged after poison-before-each-submit.',
                     '127→128 and 383→384 retain capture; all growing-prefix plan outcomes reported, not assumed.',
                     'Explicit fresh and R/T changes invalidate/re-record; peer Invocation recordings can be replayed after peer preparation.',
                     'Each original metadata Queue owner remains stable and distinct from its execution stream.'],
            wait_caveat='112 is the sum over actual 64 preparations; replay-only rows repeat prior reports and are excluded. Reused capture does not imply zero host waits.'),
        model_checks=models,
        artifacts=dict(cli_image=short(ready['image']), component_image=short(component['image']),
            original_cli_ready=short(pin(W / 'ready-cli.json')), component_ready=short(pin(W / 'ready-component.json'))),
        reuse_references=[dict(path='docs/evidence/correctness/inference-wave-recovery-2026-10-27.json',
            receipt=short(pin(R / 'docs/evidence/correctness/inference-wave-recovery-2026-10-27.json')),
            archive=read(R / 'docs/evidence/correctness/inference-wave-recovery-2026-10-27.json')['archive'],
            purpose='Original Model/SDK closure and complete two-turn default/off controls; actual retained object/dependency identities remain in this package.'),
            dict(path='.scratch/inference-feature-completion-2026-10-18/windows-batch/current-replay-identities.json',
            purpose='Seven verified v16 header hashes and original native source provenance.')],
        exclusions=['No SDK, dependency, model download or full rebuild; no binary/object/PDB/DLL/library/model payload in archive.',
            'Only finite BF16 D256 Graph R1/R2 T1/T2 cases were exercised here; no universal dtype/head/ragged/mask/concurrency proof.',
            'Natural-model complete non-time CLI reports match except exact continuation counter changes. This does not assert all hidden intermediates are bitwise identical.',
            'MTP still records 11 ranges; no claim that all remaining model captures were eliminated.',
            'No fault injection, new platform proof, throughput conclusion, or no-wait claim. Functional process seconds are receipts, not benchmark samples.'])
    # Keep the human receipt compact; detailed commands, dependency lists and
    # every actual observation stay in the archive rather than expanding JSON.
    entries = {}
    def add(path, name=None):
        p = Path(path).resolve()
        assert p.is_file(), p
        assert p.suffix.lower() not in ('.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.safetensors', '.gguf')
        arc = name or ('window/' + p.relative_to(W).as_posix())
        assert arc not in entries, arc
        entries[arc] = p
    for name in ('package.py', 'build.py', 'component.py', 'model_check.py', 'design.diff', 'struct-declaration-proof.json', 'preparation-plan.json',
                 'frozen-plan.json', 'source-freeze.json', 'environment.json', 'runtime-plan.json', 'ready-cli.json',
                 'cli-link-inputs.json', 'component-plan.json', 'component-frozen.json', 'component-frozen2.json',
                 'component-frozen3.json', 'component-source-freeze.json', 'component-source-freeze2.json',
                 'component-source-freeze3.json', 'ready-component.json', 'component-link-inputs.json', 'component-summary.json'):
        add(W / name)
    for path in W.glob('component-failure-*.log'):
        add(path)
    for relative in PRODUCTS:
        add(W / 'source' / relative, 'source/' + relative)
    for attempt in ('component-source', 'component-source2', 'component-source3'):
        add(W / attempt / TEST, 'source/' + attempt + '/' + TEST)
    for directory in ('recipes', 'logs', 'link-cli', 'link-component', 'run-component', 'model-checks'):
        for p in sorted((W / directory).rglob('*')):
            if p.is_file() and p.suffix.lower() in ('.json', '.log', '.xml', '.d'):
                add(p)
    for unit in ('native', 'provider', 'batch', 'component2', 'component3'):
        for p in sorted((W / 'compile' / unit).glob('*')):
            if p.is_file() and p.suffix.lower() in ('.json', '.log', '.d'):
                add(p)
    for path in sorted(old_paths):
        add(path, 'baseline/' + path.relative_to(R / '.scratch').as_posix())
    add(old_header, 'baseline/original-compiled-native_batch.h')
    fi = R / '.scratch/inference-feature-completion-2026-10-18/windows-batch'
    for name in ('summary.json', 'current-replay-identities.json', 'current-vs-compiled-headers.json',
                 'native-batch-portable-llp64-posenc-command.json', 'native_cache_encoder.cu.current.command.json'):
        add(fi / name, 'v16-receipts/' + name)
    manifest = []
    for arc, p in sorted(entries.items()):
        identity = pin(p)
        manifest.append(dict(member=arc, bytes=identity['bytes'], sha256=identity['sha256']))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for arc, p in sorted(entries.items()):
            archive.write(p, arc)
        archive.writestr('manifest.json', json.dumps(dict(members=manifest, self_hash_excluded=True), indent=2) + '\n')
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as archive:
        assert set(archive.namelist()) == set(entries) | {'manifest.json'}
        for row in manifest:
            data = archive.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], row['member']
        assert read_manifest(archive.read('manifest.json')) == manifest
    receipt['archive'] = dict(**short(pin(OUT.with_suffix('.zip'))), members=len(manifest) + 1, verified_every_member=True)
    text = compact(receipt)
    OUT.with_suffix('.json').write_text(text, encoding='utf-8')
    result = dict(receipt=pin(OUT.with_suffix('.json')), archive=pin(OUT.with_suffix('.zip')),
                  members=len(manifest) + 1, bytes_uncompressed=sum(row['bytes'] for row in manifest),
                  runtime_processes=4, actual_compile_attempts=5, links=2,
                  status='VERIFIED_ALL_ARCHIVE_MEMBERS')
    (W / 'package-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


def read_manifest(data):
    return json.loads(data)['members']


def compact(value, level=0):
    # Expand mappings for scanability and keep parallel lists as compact rows.
    if not isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    lines = []
    for key, item in value.items():
        encoded = compact(item, level + 1)
        lines.append('  ' * (level + 1) + json.dumps(key) + ': ' + encoded)
    return '{\n' + ',\n'.join(lines) + '\n' + '  ' * level + '}' + ('\n' if level == 0 else '')


if __name__ == '__main__':
    main()
