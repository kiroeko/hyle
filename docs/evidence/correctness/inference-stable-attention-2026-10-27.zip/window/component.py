"""One Graph numerical/capture group; each action is explicit, with no retry.

Reuse this window's successfully linked CLI product objects. Only compile the
new batch_capture_test TU and replace the two CLI entry units by that TU plus
the already linked /MD GTest support. Never build a dependency or start a model.
"""
from pathlib import Path
import importlib.util
import json
import re
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('stable_attention_product_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
OLD = R / '.scratch/inference-metadata-queue-20261027'
OLD_UNIT = OLD / 'compile/06-batch_capture_test'
SOURCE = Path('tests/graph_batch/batch_capture_test.cc')
FILTER = 'GraphBatchCapture.UniformDecodePlansKeepCaptureAcrossGrowingPagedPrefixes'
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    ready = read(W / 'ready-cli.json')
    inputs = read(ready['inputs']['path'])
    assert len(inputs) == 224
    # These are actual compiler Source records, not guesses from OBJ names.
    model = read(b.BASE / 'ready-model.json')['compiled']['object']
    entry = next(row for row in inputs if key(row['path']) == key(
        R / '.scratch/inference-current-closure-20261026/engine/entry/unit.obj'))
    exclusions = []
    for obj, expected in ((model, 'engine/models/qwen35/main.cc'), (entry, 'engine/main.cc')):
        deps = Path(obj['path']).parent / 'dependencies.json'
        actual = read(deps)['Data']['Source'].replace('\\', '/').casefold()
        assert actual.endswith('/' + expected.casefold()), actual
        assert sum(key(row['path']) == key(obj['path']) for row in inputs) == 1
        exclusions.append(dict(object=obj, compiler_source=actual, dependencies=pin(deps)))
    old_inputs = read(OLD / 'test-link-inputs.json')
    support = [row for row in old_inputs if Path(row['path']).name.lower() in ('gtest_main.lib', 'gtest.lib')]
    assert len(support) == 2
    recipe = read(OLD_UNIT / 'command.json')['command']
    assert all(x in recipe for x in ('/MD', '/O2', '/std:c++latest', '/DHYLE_STATIC', '/WX'))
    assert key(read(OLD_UNIT / 'dependencies.json')['Data']['Source']) == key(R / SOURCE)
    save(W / 'component-plan.json', dict(status='PREPARED_NOT_COMPILED', source=str(R / SOURCE),
        baseline=pin(W / 'ready-cli.json'), inputs=ready['inputs'], link_recipe=ready['recipe'],
        template=pin(OLD_UNIT / 'command.json'), old_dependencies=pin(OLD_UNIT / 'dependencies.json'),
        exclusions=exclusions, gtest_support=support, expected_inputs=225, filter=FILTER,
        counts=dict(CXX=1, links=1, test_processes=1, GTests=1, model_processes=0),
        matrix=dict(R=[1, 2], T=[1, 2], KV=[127, 128, 129, 383, 384, 385, 1023],
                    dtype='BF16', page_size=16, D=256, query_heads=4, kv_heads=2,
                    invocations=2, executions=96, CPU_reference='FP64 over decoded original BF16 values'),
        scope='Keep current224 product inputs except exact Model/CLI entry; add one test TU and original GTest libraries. No native/provider/batch recompilation.'))
    print('PREPARED Graph component: 1CXX/1link/1new GTest process; no execution', flush=True)


def freeze():
    product = b.validate()
    plan = read(W / 'component-plan.json')
    exact(plan['baseline']); exact(plan['template']); exact(plan['old_dependencies'])
    files = {R / SOURCE}
    for path in read(plan['old_dependencies']['path'])['Data']['Includes']:
        if b.project(path):
            files.add(Path(path).resolve())
    # Direct quoted dependencies are recursively included if this new test
    # adds a project header. The original old source itself is not reused.
    todo = list(files)
    while todo:
        p = todo.pop()
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"', p.read_text(encoding='utf-8-sig'), re.M):
            found = next((q.resolve() for parent in (p.parent, R / 'include', R)
                          if (q := parent / include).is_file()), None)
            if found is not None and b.project(found) and found not in files:
                files.add(found); todo.append(found)
    rows = []
    for p in sorted(files):
        snapshot = W / 'component-source3' / p.relative_to(R)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        with snapshot.open('xb') as stream:
            stream.write(p.read_bytes())
        original, frozen = pin(p), pin(snapshot)
        assert (original['sha256'], original['bytes']) == (frozen['sha256'], frozen['bytes'])
        rows.append(dict(original=original, snapshot=frozen))
    save(W / 'component-source-freeze3.json', rows)
    out = W / 'compile/component3'
    template = read(plan['template']['path'])['command']
    command = [template[0], '/I' + str(W / 'component-source3/include'), '/I' + str(W / 'component-source3')]
    for at, arg in enumerate(template[1:], 1):
        if template[at - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        elif arg.lower().endswith(('.cc', '.cpp', '.cxx')):
            arg = str(W / 'component-source3' / SOURCE)
        elif arg.lower().startswith(('/i', '/external:i')):
            lead = '/external:I' if arg.lower().startswith('/external:i') else '/I'
            p = Path(arg[len(lead):]).resolve()
            if p == R or b.project(p):
                arg = lead + str(W / 'component-source3' / p.relative_to(R))
        command.append(arg)
    save(W / 'recipes/compile-component3.json', dict(command=command, template=plan['template']))
    save(W / 'component-frozen3.json', dict(plan=pin(W / 'component-plan.json'),
        product_frozen_plan=pin(W / 'frozen-plan.json'), source_freeze=pin(W / 'component-source-freeze3.json'),
        command=pin(W / 'recipes/compile-component3.json')))
    print('FROZEN one Graph TU and actual project-header dependencies; no compilation/run', flush=True)


def validate():
    b.validate()
    frozen = read(W / 'component-frozen3.json')
    for name in ('plan', 'product_frozen_plan', 'source_freeze', 'command'):
        exact(frozen[name])
    for row in read(frozen['source_freeze']['path']):
        exact(row['original']); exact(row['snapshot'])
    return read(frozen['plan']['path'])


def compile_unit():
    validate()
    out = W / 'compile/component3'
    out.mkdir(parents=True, exist_ok=False)
    process = b.b.b.h.execute(read(W / 'recipes/compile-component3.json')['command'], b.environment(),
                             W / 'logs/component3', timeout=240)
    data = read(out / 'dependencies.json')['Data']
    assert key(data['Source']) == key(W / 'component-source3' / SOURCE)
    assert not any(b.project(p) for p in data['Includes']), 'live project header leak'
    allowed = {key(row['snapshot']['path']): row['snapshot'] for row in read(W / 'component-source-freeze3.json')}
    dependencies = []
    for p in dict.fromkeys([data['Source'], *data['Includes']]):
        row = pin(p)
        if Path(p).is_relative_to(W / 'component-source3'):
            assert row == allowed[key(p)], p
        dependencies.append(row)
    save(out / 'actual-dependencies.json', dependencies)
    validate()
    save(out / 'compiled.json', dict(source=pin(R / SOURCE), snapshot=pin(W / 'component-source3' / SOURCE),
        object=pin(out / 'unit.obj'), process=process, compiler_dependencies=pin(out / 'dependencies.json'),
        actual_dependencies=pin(out / 'actual-dependencies.json'), command=pin(W / 'logs/component3/command.json')))
    print('COMPILE_PASS component', flush=True)


def link():
    plan = validate()
    exact(plan['inputs']); exact(plan['link_recipe'])
    compiled = read(W / 'compile/component3/compiled.json')
    exact(compiled['object'])
    omitted = {key(row['object']['path']) for row in plan['exclusions']}
    inputs = [row for row in read(plan['inputs']['path']) if key(row['path']) not in omitted]
    inputs += [compiled['object'], *plan['gtest_support']]
    assert len(inputs) == plan['expected_inputs']
    assert len({key(row['path']) for row in inputs}) == len(inputs)
    for row in inputs:
        exact(row)
    image = W / 'bin/stable-attention-component.exe'
    assert not image.exists()
    command = []
    for arg in read(plan['link_recipe']['path'])['command']:
        if key(arg) in omitted:
            continue
        for option, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(option):
                arg = option + str(image.with_suffix(suffix))
                break
        command.append(arg)
    command += [compiled['object']['path'], *(row['path'] for row in plan['gtest_support'])]
    save(W / 'component-link-inputs.json', inputs)
    process = b.b.b.h.execute(command, b.environment(), W / 'link-component', timeout=180)
    save(W / 'ready-component.json', dict(status='LINKED_NOT_RUN', image=pin(image), link=process,
        compiled=compiled, inputs=pin(W / 'component-link-inputs.json'), recipe=pin(W / 'link-component/command.json'),
        runtime=pin(W / 'runtime-plan.json'), plan=pin(W / 'component-frozen3.json'), filter=FILTER))
    print('LINK_PASS component225, no test execution', flush=True)


def run():
    validate()
    ready = read(W / 'ready-component.json')
    exact(ready['image']); exact(ready['runtime'])
    report = W / 'run-component/results.xml'
    command = [ready['image']['path'], '--gtest_filter=' + FILTER, '--gtest_fail_fast', '--gtest_output=xml:' + str(report)]
    process = b.b.b.h.execute(command, b.environment(), W / 'run-component', timeout=180)
    xml = ET.parse(report).getroot()
    assert int(xml.attrib['tests']) == 1 and int(xml.attrib['failures']) == 0 and int(xml.attrib.get('disabled', 0)) == 0
    stdout = (W / 'run-component/stdout.log').read_text(encoding='utf-8-sig')
    records = re.findall(r'^stable_attention slot=.*$', stdout, re.M)
    assert len(records) == 96, len(records)
    totals = re.search(r'^stable_attention totals recorded=(\d+) reused=(\d+) plan_waits=(\d+) max_abs_error=(\S+)', stdout, re.M)
    assert totals
    save(W / 'component-summary.json', dict(status='PASS_ONE_GTEST', process=process, image=ready['image'],
        source=ready['compiled']['source'], xml=pin(report), executions=len(records),
        recorded_capture_ranges=int(totals[1]), reused_capture_ranges=int(totals[2]),
        plan_host_waits=int(totals[3]), maximum_absolute_error=float(totals[4]),
        scope='96 finite executions of one Graph group; waits are observed, not equated with capture reuse.'))
    print('PASS Graph component finite matrix', flush=True)


if __name__ == '__main__':
    try:
        {'prepare': prepare, 'freeze': freeze, 'compile': compile_unit, 'link': link, 'run': run}[sys.argv[1]]()
    except BaseException:
        (W / ('component-failure-' + '-'.join(sys.argv[1:2]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
