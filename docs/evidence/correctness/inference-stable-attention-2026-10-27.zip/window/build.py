"""Bounded native Batch prototype: prepare/freeze/compile/link are separate.

One retained CUDA13.3/SM89/v16 native TU, two current host TUs, original224 CLI
closure. No action starts a model, test, dependency build or download.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
import traceback

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-wave-recovery-final-20261027'
FI=R/'.scratch/inference-feature-completion-2026-10-18/windows-batch'
PROVIDER=R/'.scratch/inference-layout-storage-native-20261025/host1'
BATCH=R/'.scratch/inference-metadata-queue-20261027/compile/00-batch_execution'
VERIFIED=FI/'verified-headers'
spec=importlib.util.spec_from_file_location('stable_attention_cached_tools',BASE/'check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
SOURCES=dict(native='src/compute_provider_flashinfer/native_batch.cu',
             provider='src/compute_provider_flashinfer/flashinfer_provider.cc',batch='src/compute_batch/batch_execution.cc')
ROOTS=('include','src','engine','tests')


def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(path,value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as stream:stream.write(json.dumps(value,indent=2)+'\n')


def pin(path):
    p=Path(path).resolve();sha=hashlib.sha256()
    with p.open('rb') as stream:
        while data:=stream.read(1<<20):sha.update(data)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=sha.hexdigest())


def exact(row):
    v=pin(row['path']);assert (v['bytes'],v['sha256'])==(row['bytes'],row['sha256']),row['path']


def key(path):return str(path).replace('/','\\').casefold()


def project(path):
    p=Path(path).resolve();return p.is_relative_to(R) and bool(p.relative_to(R).parts) and p.relative_to(R).parts[0] in ROOTS


def canonical(path):
    p=Path(path).resolve()
    if p.is_relative_to(PROVIDER/'source'):return R/p.relative_to(PROVIDER/'source')
    return p


def environment():
    value=b.environment();value['PATH']=str(W/'bin')+';'+read(BASE/'runtime-plan.json')['PATH']
    return value


def prepare():
    assert not (W/'preparation-plan.json').exists(),'Preserve prior prepared attempt'
    ready=read(BASE/'ready-model.json');inputs=read(ready['inputs']['path']);assert len(inputs)==224
    native_recipe=FI/'native-batch-portable-llp64-posenc-command.json'
    # The final v16 replay command is actually compiled by the existing encoder
    # TU. Preserve its exact validated seven-header overlay and all native flags;
    # change only the unit/output and request an as-run dependency file later.
    verified_recipe=FI/'native_cache_encoder.cu.current.command.json'
    native=read(native_recipe)['command'];final=read(verified_recipe)['command']
    for flag in ('--std=c++17','--gpu-architecture=sm_89','-O2','-DNDEBUG','-DFLASHINFER_ENABLE_BF16','-DFLASHINFER_ENABLE_F16'):
        assert flag in native and flag in final
    assert 'CUDA\\v13.3' in final[0] and any(str(VERIFIED) in x for x in final)
    old_native=next(row for row in inputs if key(row['path'])==key(FI/'native-batch-portable-llp64-posenc.obj'))
    units={
        'native':dict(source=str(R/SOURCES['native']),recipe=pin(verified_recipe),original_recipe=pin(native_recipe),old_object=old_native),
        'provider':dict(source=str(R/SOURCES['provider']),recipe=pin(PROVIDER/'flashinfer/command.json'),deps=pin(PROVIDER/'flashinfer/dependencies.json')),
        'batch':dict(source=str(R/SOURCES['batch']),recipe=pin(BATCH/'command.json'),deps=pin(BATCH/'dependencies.json'))}
    for name in ('provider','batch'):
        data=read(units[name]['deps']['path'])['Data'];assert key(canonical(data['Source']))==key(R/SOURCES[name])
        old_path=PROVIDER/'flashinfer/unit.obj' if name=='provider' else BATCH/'unit.obj'
        units[name]['old_object']=next(row for row in inputs if key(row['path'])==key(old_path))
    vendor=read(FI/'summary.json')['dependency'];assert vendor['version']=='hyle-flashinfer-msvc-portability-v16'
    save(W/'preparation-plan.json',dict(status='METADATA_ONLY_NOT_FROZEN',units=units,baseline=pin(BASE/'ready-model.json'),
        original_link_inputs=ready['inputs'],original_link_recipe=ready['recipe'],input_count=224,
        vendor=vendor,v16_replay=pin(FI/'current-replay-identities.json'),
        effective_header_comparison=pin(FI/'current-vs-compiled-headers.json'),
        verified_header_root=str(VERIFIED),counts=dict(NVCC=1,CXX=2,links=1,model_runs=0,SDK_builds=0,downloads=0),
        policy='Use existing v16 verified headers and originalCUDA13.3 -O2 SM89 /MD. Never select v21 or rebuild/copy a vendor/SDK tree. Freeze current product sources only after root signals stability.'))
    runtime=read(BASE/'runtime-plan.json')
    save(W/'runtime-plan.json',dict(original_native_cpu=runtime['original_native_cpu'],
        alias=str(W/'bin'/Path(runtime['original_native_cpu']['path']).name),PATH=environment()['PATH']))
    save(W/'environment.json',{k:environment().get(k,'') for k in ('PATH','INCLUDE','LIB','LIBPATH')})
    print('PREPARED only:1NVCC+2CXX+224inputlink, no source freeze/build/run',flush=True)


def tokens(text):return re.sub(r'\s+','',re.sub(r'//[^\n]*|/\*.*?\*/','',text,flags=re.S))


def freeze():
    assert not (W/'frozen-plan.json').exists(),'Preserve prior freeze'
    plan=read(W/'preparation-plan.json');files={R/p for p in SOURCES.values()}
    files.add(R/'src/compute_provider_flashinfer/native_batch.h')
    for name in ('provider','batch'):
        for path in read(plan['units'][name]['deps']['path'])['Data']['Includes']:
            p=canonical(path)
            if project(p):files.add(p)
    include_dirs=[R/'include',R,R/'src/compute_provider_flashinfer',R/'src/compute_batch',R/'src/compute']
    todo=list(files)
    while todo:
        p=todo.pop()
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"',p.read_text(encoding='utf-8-sig'),re.M):
            found=next((q.resolve() for parent in (p.parent,*include_dirs) if (q:=parent/include).is_file()),None)
            if found is not None and project(found) and found not in files:files.add(found);todo.append(found)
    snapshots=[]
    for p in sorted(files):
        original=pin(p);snapshot=W/'source'/p.relative_to(R)
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        with snapshot.open('xb') as stream:stream.write(p.read_bytes())
        frozen=pin(snapshot);assert (original['bytes'],original['sha256'])==(frozen['bytes'],frozen['sha256'])
        snapshots.append(dict(original=original,snapshot=frozen))
    # Other native TUs pass these two private structs by value. Verify their
    # exact original declaration tokens; the new query declaration is separate.
    previous=(PROVIDER/'source/src/compute_provider_flashinfer/native_batch.h').read_text()
    current=(W/'source/src/compute_provider_flashinfer/native_batch.h').read_text()
    struct_proof={}
    for name in ('BatchSpec','BatchFacts'):
        pattern=r'struct '+name+r' final \{.*?\n\};'
        a=re.search(pattern,previous,re.S).group();z=re.search(pattern,current,re.S).group()
        assert tokens(a)==tokens(z),name+' layout declaration changed: review required'
        struct_proof[name]=dict(declaration_tokens_identical=True,sha256=hashlib.sha256(tokens(z).encode()).hexdigest())
    vendor=read(plan['v16_replay']['path']);vendor_pins=[]
    assert vendor['upstream_revision']==plan['vendor']['revision']
    for row in vendor['headers']:
        item=pin(VERIFIED/row['path']);assert item['sha256']==row['sha256'];vendor_pins.append(item)
    save(W/'source-freeze.json',snapshots)
    commands={}
    for name,unit in plan['units'].items():
        exact(unit['recipe']);source=W/'source'/SOURCES[name];out=W/'compile'/name
        template=read(unit['recipe']['path'])['command'];command=[]
        if name=='native':
            for i,arg in enumerate(template):
                if i and template[i-1]=='-o':arg=str(out/'unit.obj')
                elif arg.lower().endswith('.cu'):arg=str(source)
                command.append(arg)
            command+=['--generate-dependencies-with-compile','--dependency-output',str(out/'dependencies.d')]
        else:
            command=[template[0],*('/I'+str(W/'source'/p) for p in ('include','','src/compute_provider_flashinfer','src/compute_batch','src/compute','src/compute_backend_cuda'))]
            for i,arg in enumerate(template[1:],1):
                if template[i-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
                elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
                elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
                elif arg.lower().endswith(('.cc','.cpp','.cxx')):arg=str(source)
                elif arg.lower().startswith(('/i','/external:i')):
                    lead='/external:I' if arg.lower().startswith('/external:i') else '/I'
                    p=canonical(arg[len(lead):])
                    if p==R or project(p):arg=lead+str(W/'source'/p.relative_to(R))
                command.append(arg)
        commands[name]=command;save(W/'recipes'/('compile-'+name+'.json'),dict(command=command,template=unit['recipe']))
    save(W/'frozen-plan.json',dict(prepared=pin(W/'preparation-plan.json'),source_freeze=pin(W/'source-freeze.json'),
        vendor_headers=vendor_pins,private_struct_ABI_proof=struct_proof,commands=commands,units=plan['units'],baseline=plan['baseline']))
    print('FROZEN bounded actual project dependencies; no SDK copy/CXX/NVCC/run',flush=True)


def validate():
    plan=read(W/'frozen-plan.json');exact(plan['source_freeze'])
    for row in read(plan['source_freeze']['path']):exact(row['original']);exact(row['snapshot'])
    for row in plan['vendor_headers']:exact(row)
    return plan


def compile_unit(name):
    plan=validate();assert name in SOURCES
    out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
    process=b.b.h.execute(plan['commands'][name],environment(),W/'logs'/name,timeout=600 if name=='native' else 240)
    if name=='native':
        dep=pin(out/'dependencies.d')
        actual=dict(native_dependency_makefile=dep,locked_v16_header_pins=plan['vendor_headers'],
            source=pin(W/'source'/SOURCES[name]),header=pin(W/'source/src/compute_provider_flashinfer/native_batch.h'),
            scope='Original NVCC-generated full dependency listing retained; vendor/SDK trees not copied.')
    else:
        dep=pin(out/'dependencies.json');data=read(dep['path'])['Data']
        assert key(data['Source'])==key(W/'source'/SOURCES[name])
        assert not any(project(p) or Path(p).is_relative_to(PROVIDER/'source') for p in data['Includes']),'old/live project header leak'
        allowed={key(row['snapshot']['path']):row['snapshot'] for row in read(plan['source_freeze']['path'])}
        actual=[]
        for p in dict.fromkeys([data['Source'],*data['Includes']]):
            item=pin(p)
            if Path(p).is_relative_to(W/'source'):assert item==allowed[key(p)]
            actual.append(item)
    validate();save(out/'actual-dependencies.json',actual)
    save(out/'compiled.json',dict(source=pin(R/SOURCES[name]),snapshot=pin(W/'source'/SOURCES[name]),
        object=pin(out/'unit.obj'),process=process,command=pin(W/'logs'/name/'command.json'),
        compiler_dependencies=dep,actual_dependencies=pin(out/'actual-dependencies.json')))
    print('COMPILE_PASS '+name,flush=True)


def link():
    plan=validate();prep=read(W/'preparation-plan.json');baseline=read(plan['baseline']['path'])
    exact(prep['original_link_inputs']);exact(prep['original_link_recipe'])
    inputs=read(prep['original_link_inputs']['path']);assert len(inputs)==224
    replacements={}
    compiled={name:read(W/'compile'/name/'compiled.json') for name in SOURCES}
    for name,row in compiled.items():
        exact(row['object']);old=prep['units'][name]['old_object']['path']
        assert sum(key(p['path'])==key(old) for p in inputs)==1
        replacements[key(old)]=row['object']
    inputs=[replacements.get(key(row['path']),row) for row in inputs]
    for row in inputs:exact(row)
    image=W/'bin/hyle-stable-attention.exe';image.parent.mkdir(parents=True,exist_ok=True)
    assert not image.exists() and not (W/'link-cli').exists(),'Preserve actual link attempt'
    command=[]
    for arg in read(prep['original_link_recipe']['path'])['command']:
        if key(arg) in replacements:arg=replacements[key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):arg='/MAP:'+str(image.with_suffix('.map'))
        command.append(arg)
    for option,suffix in (('/PDB:','.pdb'),('/IMPLIB:','.lib')):
        if not any(x.upper().startswith(option) for x in command):command.append(option+str(image.with_suffix(suffix)))
    runtime=read(W/'runtime-plan.json');cpu=runtime['original_native_cpu'];exact(cpu)
    if not Path(runtime['alias']).exists():os.link(cpu['path'],runtime['alias'])
    save(W/'cli-link-inputs.json',inputs)
    process=b.b.h.execute(command,environment(),W/'link-cli',timeout=180)
    save(W/'ready-cli.json',dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,link=process,
        inputs=pin(W/'cli-link-inputs.json'),recipe=pin(W/'link-cli/command.json'),runtime=pin(W/'runtime-plan.json'),plan=pin(W/'frozen-plan.json')))
    print('LINK_PASS CLI224, no model execution',flush=True)


if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='freeze':freeze()
        elif action=='compile':compile_unit(sys.argv[2])
        elif action=='link':link()
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
