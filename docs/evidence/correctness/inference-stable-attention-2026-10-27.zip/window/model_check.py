"""One explicit functional consumer per arm. Timings are not a new benchmark."""
from pathlib import Path
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

b=module('stable_attention_build',W/'build.py')
prior=module('retained_recovery_facts',R/'.scratch/inference-wave-recovery-final-20261027/run.py')

def main(name):
    assert name in ('two-turn-auto','two-turn-off','single-mtp')
    ready=b.read(W/'ready-cli.json');b.exact(ready['image']);b.validate()
    base=R/'.scratch/inference-wave-recovery-final-20261027/runs'
    if name=='single-mtp':
        source=R/'.scratch/inference-mtp-capture-causes-20261027/current-w17/run'
    else: source=base/('two-turn-default' if name=='two-turn-auto' else 'two-turn-off')
    command=[ready['image']['path'],*b.read(source/'command.json')['command'][1:]]
    out=W/'model-checks'/name;assert not out.exists(),'Preserve every actual attempt'
    process=b.b.b.h.execute(command,b.environment(),out,timeout=180)
    actual=b.read(out/'stdout.log');expected=b.read(source/'stdout.log')
    b.save(out/'consumer-result.json',actual)
    differences=prior.changed(prior.facts.non_time(expected),prior.facts.non_time(actual))
    b.save(out/'complete-non-time-differences.json',differences)
    # All differences remain visible. Only the explicitly changed continuation
    # facts may differ; no IDs, RNG, state, history, work or resource field is
    # removed from comparison to call a numerical change a pass.
    allowed={'/decode_overlap_available','/overlap_successor_submissions',
             '/overlap_successor_publications','/overlap_successor_refusals'}
    assert all(d['path'] in allowed for d in differences),differences[:6]
    assert actual['live_committed_versions']==0
    stderr=(out/'stderr.log').read_text(encoding='utf-8-sig')
    records=[]
    for match in re.finditer(r'^prepared T=(\d+) visible=(\d+).*capture_recorded=(\d+) capture_reused=(\d+)$',stderr,re.M):
        rows,visible,recorded,reused=map(int,match.groups())
        if recorded:records.append(dict(rows=rows,visible=visible,recorded=recorded))
    if name=='two-turn-auto':
        assert actual['overlap_successor_refusals']==0,'Do not silently qualify a remaining gap'
        assert actual['overlap_successor_publications']>=102
    b.save(out/'summary.json',dict(status='FINITE_FUNCTIONAL_FACTS_PASS',process=process,
        ready=b.pin(W/'ready-cli.json'),original=b.pin(source/'stdout.log'),
        complete_non_time_differences=differences,recorded=records,
        continuation={k:v for k,v in actual.items() if k.startswith('overlap_')},
        performance_claim=False,scope='Natural model functional/capture check; numerical component oracle is separate.'))
    print(json.dumps(dict(arm=name,status='PASS',recorded=records,differences=differences,
        continuation={k:v for k,v in actual.items() if k.startswith('overlap_')})))

if __name__=='__main__':main(sys.argv[1])
