from pathlib import Path
import urllib.request,json,time,hashlib
S=Path('.scratch/architecture-refactor-2026-10-18/gptq-contract-review').resolve();rec=[]
def get(url,path,limit=1000000,range_=None):
 headers={'User-Agent':'Hyle-contract-review'}
 if range_:headers['Range']=f'bytes={range_[0]}-{range_[1]}'
 for attempt in range(2):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30) as r:
    status=r.status;hd=dict(r.headers);data=r.read(limit+1)
   assert len(data)<=limit
   if range_:assert status==206 and len(data)==range_[1]-range_[0]+1
   p=S/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);rec.append(dict(url=url,path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),status=status,headers={k:v for k,v in hd.items() if k.lower() in ['content-range','content-length','etag','x-repo-commit']}));return data
  except Exception as e:
   rec.append(dict(url=url,path=path,attempt=attempt,error=repr(e)))
 return None
get('https://api.github.com/repos/intel/auto-round/commits/v0.15.0','primary/autoround-commit.json')
for f in ['auto_round/export/utils.py','auto_round/export/export_to_autogptq/export.py','auto_round/export/export_to_autoround/qlinear_triton.py','auto_round/export/export_to_autoround/qlinear_tritonv2.py']:
 get('https://raw.githubusercontent.com/intel/auto-round/v0.15.0/'+f,'primary/autoround/'+f)
repo='Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ';rev='1b9d56b428e9f841d7ad566f87660b5f47553c97';url=f'https://huggingface.co/{repo}/resolve/{rev}/model-00002-of-00005.safetensors'
b=get(url+'?hyle_gptq_prefix=0-7','q27/shard2-header-length.bin',8,(0,7))
if b:
 import struct
 n=struct.unpack('<Q',b)[0];assert n<1000000
 get(url+f'?hyle_gptq_prefix=8-{n+7}','q27/shard2-header.json',n,(8,n+7))
(S/'http-producer-receipts.json').write_text(json.dumps(rec,indent=2)+'\n')
print([(r['path'],r.get('bytes'),r.get('error')) for r in rec])
