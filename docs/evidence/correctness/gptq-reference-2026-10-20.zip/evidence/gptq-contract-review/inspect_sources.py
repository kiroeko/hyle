from pathlib import Path
import urllib.request,json,struct,hashlib,time
S=Path('.scratch/architecture-refactor-2026-10-18/gptq-contract-review').resolve();rec=[]
def get(url,path,limit=2000000,range_=None):
 req=urllib.request.Request(url,headers={'User-Agent':'Hyle-contract-review','Accept':'application/json'})
 if range_:req.add_header('Range',f'bytes={range_[0]}-{range_[1]}')
 t=time.time()
 try:
  with urllib.request.urlopen(req,timeout=45) as r:
   status=r.status;headers=dict(r.headers);payload=r.read(limit+1)
  assert len(payload)<=limit,(len(payload),limit)
  if range_:assert status==206 and len(payload)==range_[1]-range_[0]+1,(status,len(payload),headers.get('Content-Range'))
  p=S/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(payload)
  row=dict(url=url,path=str(p.relative_to(S)),status=status,headers={k:v for k,v in headers.items() if k.lower() in ['content-range','content-length','etag','x-repo-commit','last-modified']},bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest(),seconds=time.time()-t);rec.append(row);return payload
 except Exception as e:
  rec.append(dict(url=url,path=path,error=repr(e)));return None
for name,repo,rev,filename in [
 ('q35','Vishva007/Qwen3.5-2B-W4A16-AutoRound-GPTQ','8ec79a3b08636bc68fd40d69df80e97ff1263995','model.safetensors'),
 ('q27','Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ','1b9d56b428e9f841d7ad566f87660b5f47553c97','model-00001-of-00005.safetensors')]:
 url=f'https://huggingface.co/{repo}/resolve/{rev}/{filename}'
 first=get(url+'?hyle_gptq_prefix=0-7',name+'/header-length.bin',8,(0,7))
 if first:
  size=struct.unpack('<Q',first)[0];assert size<2000000,size
  payload=get(url+f'?hyle_gptq_prefix=8-{size+7}',name+'/header.json',size,(8,size+7))
  if payload:
   d=json.loads(payload);print(name,'headerbytes',size,'tensors',len(d)-('__metadata__' in d))
   keys=[(k,v) for k,v in d.items() if any(x in k for x in ['qweight','qzeros','scales','g_idx'])];print('roles',len(keys));print(keys[:6])
 get(f'https://huggingface.co/{repo}/resolve/{rev}/model.safetensors.index.json',name+'/index.json')
get('https://api.github.com/repos/intel/auto-round/git/ref/tags/v0.15.0','primary/autoround-tag.json')
(S/'http-receipts.json').write_text(json.dumps(rec,indent=2)+'\n')
print('HTTP',[(r['path'],r.get('status'),r.get('error')) for r in rec])
