from pathlib import Path
import subprocess,hashlib,json,struct
S=Path('.scratch/architecture-refactor-2026-10-18/gptq-contract-review').resolve();rows=[]
def fetch(url,rel,range_=None):
 p=S/rel;p.parent.mkdir(parents=True,exist_ok=True)
 cmd=['curl.exe','-L','--fail','--connect-timeout','8','--max-time','22','--silent','--show-error',url,'--output',str(p),'--write-out','%{http_code} %{size_download}']
 if range_:cmd+=['--range',f'{range_[0]}-{range_[1]}']
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);rec=dict(url=url,command=cmd,exit=r.returncode,stdout=r.stdout,stderr=r.stderr,path=rel)
 if r.returncode==0:
  b=p.read_bytes();rec.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  if range_:assert r.stdout.startswith('206 ') and len(b)==range_[1]-range_[0]+1,(r.stdout,len(b))
  rows.append(rec);return b
 rows.append(rec);return None
fetch('https://api.github.com/repos/intel/auto-round/git/ref/tags/v0.15.0','primary/curl-autoround-tag.json')
repo='Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ';rev='1b9d56b428e9f841d7ad566f87660b5f47553c97';url=f'https://huggingface.co/{repo}/resolve/{rev}/model-00002-of-00005.safetensors'
b=fetch(url+'?hyle_gptq_prefix=0-7','q27/shard2-length-curl.bin',(0,7))
if b:
 n=struct.unpack('<Q',b)[0];assert n<1000000
 b=fetch(url+f'?hyle_gptq_prefix=8-{n+7}','q27/shard2-header-curl.json',(8,n+7))
 if b:
  h=json.loads(b);print('q27 shard2header',len(b),'tensors',len(h)-('__metadata__' in h));print([(k,v) for k,v in h.items() if any(x in k for x in ['qweight','qzeros','g_idx','scales'])][:6])
(S/'curl-http-receipts.json').write_text(json.dumps(rows,indent=2)+'\n');print('FETCHES',[(r['path'],r['exit'],r['stdout']) for r in rows])
