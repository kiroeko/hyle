from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path.cwd()
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
Q = A / 'gptq-reference'
RESEARCH = A / 'gptq-contract-review'
DEST = ROOT / 'docs/evidence/correctness/gptq-reference-2026-10-20'
PUBLISH = '--publish' in sys.argv
VALIDATION = {
    'windows_cpu': Q / 'common-cpu/checks/mapped-helper-refresh2/tests.xml',
    'windows_cuda_gptq_ct': Q / 'cuda/tests-mapped/tests.xml',
    'windows_cuda_mapped_neighbors': Q / 'cuda/tests-mapped/mapped-neighbors/tests.xml',
    'windows_vulkan': Q / 'vulkan/validation/tests.xml',
    'macos_apple': Q / 'apple/mac/remote/results/tests.xml',
}


def load(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8')


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


entries, provenance, projections = {}, {}, []


def add(path, member=None):
    path = Path(path)
    member = member or ('evidence/' + path.relative_to(A).as_posix())
    data = path.read_bytes()
    assert member not in entries or entries[member] == data, member
    entries[member] = data
    provenance[member] = identity(path)


def project_receipt(path):
    data = load(path)
    # Actual command/source/object/link inputs are retained. Repeated transitive
    # SDK header inventories remain locally hash-addressed, without SDK payload.
    if isinstance(data, dict):
        compact = {k: v for k, v in data.items() if k != 'dependencies'}
        if 'dependencies' in data:
            compact['dependency_inventory'] = dict(count=len(data['dependencies']),
                original_receipt=identity(path), omitted='Repeated SDK/header identities only.')
    else:
        compact = data
    member = 'receipts/' + path.relative_to(A).as_posix()
    entries[member] = encoded(compact)
    provenance[member] = identity(path)
    projections.append(dict(original=identity(path), compact_member=member))


# Include scoped before/after sources, source-freezes, command logs, actual red
# tests/compile failures and final tests. Exclude every executable/object/library,
# generated full SPIR-V C++ array, raw source-dependency list and temporary probe.
allowed = {'.json', '.py', '.diff', '.xml', '.txt', '.log', '.h', '.cc', '.cuh', '.cu', '.comp', '.md'}
for path in sorted(Q.rglob('*')):
    if not path.is_file() or path in (Q / 'package-plan.json', Q / 'package-receipt.json'):
        continue
    relative = path.relative_to(Q)
    if '__pycache__' in relative.parts or path.suffix.lower() not in allowed:
        continue
    if path.name.endswith(('-deps.json', '.d')) or path.name in ('live.json', 'vulkan_shaders.cc'):
        continue
    if path.name in ('compile-summary.json', 'objects-ready.json') and path.stat().st_size > 500000:
        projections.append(dict(original=identity(path), omitted='Duplicated aggregate per-TU dependency recipes; individual compact identities and commands retained.'))
        continue
    if path.name.endswith('-identity.json'):
        project_receipt(path)
    else:
        add(path)

# Retain original researched artifact headers/indices/configs and the exact small
# producer implementation. These are header-only facts, never tensor payloads.
for path in sorted(RESEARCH.rglob('*')):
    if path.is_file() and (path.suffix.lower() in allowed or
                          (path.suffix == '.bin' and path.stat().st_size == 8)):
        add(path)

# Current final shared sources are explicit, including the variable-arity fix.
# Old frozen snapshots above remain unchanged as the real chronology.
source_paths = {
    'include/hyle/compute/model_ops.h',
    'src/compute_ops/weight_decode.cc',
    'src/compute_packed_shared/artifact_packed_linear.h',
    'src/graph/artifact_packed_region.h',
    'src/graph/mapped_native_region.h',
    'src/compute_shader_shared/ct_packed.h',
    'src/compute_shader_shared/nvfp4_f32.h',
    'tests/compute_models/gptq_reference_fixture.h',
}
for path in [Q / 'common-cpu/source-freeze.json', Q / 'root/shared-source-freeze.json',
             Q / 'root/cuda-source-freeze.json', Q / 'root/mapped-source-freeze.json',
             Q / 'apple/source-freeze.json', Q / 'vulkan/source-freeze.json']:
    data = load(path)
    for entry in data.get('files', data.get('sources', [])):
        record = entry.get('original', entry)
        candidate = Path(record['path'])
        if not candidate.is_absolute():
            candidate = ROOT / candidate
        if candidate.is_relative_to(ROOT) and candidate.is_file():
            relative = candidate.relative_to(ROOT)
            if relative.parts[0] != '.scratch':
                source_paths.add(relative.as_posix())
final_freeze = Q / 'root/final-source-freeze.json'
if final_freeze.is_file():
    data = load(final_freeze)
    for entry in data.get('files', data.get('sources', [])):
        record = entry.get('original', entry)
        candidate = Path(record['path'])
        if not candidate.is_absolute():
            candidate = ROOT / candidate
        actual = identity(candidate)
        assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], candidate
        if candidate.is_relative_to(ROOT) and candidate.relative_to(ROOT).parts[0] != '.scratch':
            source_paths.add(candidate.relative_to(ROOT).as_posix())
for relative in sorted(source_paths):
    add(ROOT / relative, 'source/' + relative)
add(Q / 'vulkan/shaders/gptq_v1.spv')
entries['recipe-provenance.json'] = encoded(projections)


def parse_xml(path):
    document = ET.parse(path).getroot()
    cases = []
    for case in document.findall('.//testcase'):
        assert not any(case.findall(tag) for tag in ('failure', 'error', 'skipped')), path
        assert case.attrib.get('status') == 'run' and case.attrib.get('result') == 'completed', path
        cases.append(dict(suite=case.attrib['classname'], name=case.attrib['name'],
            properties={p.attrib['name']: p.attrib['value']
                        for p in case.findall('./properties/property')}))
    assert int(document.attrib['failures']) == 0 and int(document.attrib['errors']) == 0, path
    assert int(document.attrib['tests']) == len(cases), path
    return dict(tests=len(cases), failures=0, errors=0, skipped=0,
                cases=cases, xml=identity(path))


missing = [str(path) for path in [*VALIDATION.values(), final_freeze] if not path.is_file()]
plan = dict(status='prepared_not_published', missing_final_validation=missing,
            members=len(entries), uncompressed_bytes=sum(map(len, entries.values())),
            final_sources=len(source_paths), target=str(DEST), projections=len(projections))
if not PUBLISH:
    (Q / 'package-plan.json').write_bytes(encoded(plan))
    print(json.dumps(plan, indent=2))
    raise SystemExit(0)

# --publish is used only after root has finished the required CUDA neighbors.
# Merely creating this skeleton never writes the public files.
assert not missing, missing
validation = {backend: parse_xml(path) for backend, path in VALIDATION.items()}
assert validation['windows_cpu']['tests'] == 14
assert validation['windows_vulkan']['tests'] == 12
assert validation['macos_apple']['tests'] == 7
assert validation['windows_cuda_gptq_ct']['tests'] == 7
assert validation['windows_cuda_mapped_neighbors']['tests'] == 8
cuda_suites = {case['suite'] for name in ('windows_cuda_gptq_ct', 'windows_cuda_mapped_neighbors')
               for case in validation[name]['cases']}
assert any('Gptq' in name for name in cuda_suites), cuda_suites
assert any('CtPacked' in name for name in cuda_suites), cuda_suites
assert any('Fp8SharedPrologue' in name for name in cuda_suites), cuda_suites
assert any('DenseIndexer' in name for name in cuda_suites), cuda_suites
process_results = {
    'windows_cpu': Q / 'common-cpu/checks/mapped-helper-refresh2/tests.result.json',
    'windows_cuda_gptq_ct': Q / 'cuda/tests-mapped/result.json',
    'windows_cuda_mapped_neighbors': Q / 'cuda/tests-mapped/mapped-neighbors/result.json',
    'windows_vulkan': Q / 'vulkan/validation/result.json',
    'macos_apple': Q / 'apple/mac/remote/results/validation.json',
}
for path in process_results.values():
    result = load(path)
    assert result.get('exit_code', result.get('exit')) == 0, path
cuda_processes = {name: validation.pop(name) for name in ('windows_cuda_gptq_ct', 'windows_cuda_mapped_neighbors')}
validation['windows_cuda'] = dict(tests=15, failures=0, errors=0, skipped=0,
                                  processes=cuda_processes)
report = dict(
    scope='Bounded GPTQ-v1 INT4 original decode and same-Graph packed linear capability with four typed carriers; synthetic math/lifetime regression only.',
    contract=dict(inputs=['I32 Q[K/8,N]', 'I32 Z[G,N/8]', 'F16 SF[G,N]', 'I32 g_idx[K]'],
        index_validation='All K indices are validated on each execution before any indexed Z/SF source access; invalid index fails Completion.',
        numerical='Unsigned Q nibble minus (unsigned raw Z nibble + 1), including 15->16; exact integer subtraction, F16 product, then decode and operand rounding; F32 accumulation.',
        storage='Bounded packed region consumes original banks without a persistent N*K decoded bank. Published decode escapes keep the checked original decomposition.'),
    validation=validation,
    process_results={name: identity(path) for name, path in process_results.items()},
    final_source_freeze=identity(final_freeze),
    total_passed=sum(value['tests'] for value in validation.values()),
    test_breakdown=dict(new_GPTQ_cases=15, CT_neighbors=21, NVFP4_neighbors=4,
                        mapped_adapter_FP8_and_scores_neighbors=8),
    header_only_target_artifacts=load(RESEARCH / 'review.json')['exact_target_artifacts'],
    corrections=['Actual old three-port inline ArtifactWeightDecode traits COMDAT selected from a historical test object; actual emitting owners were refreshed or unrelated old test owners omitted, not a codec arithmetic change.',
                 'Existing mapped_native_region fixed four-port metadata rejected GPTQ A+four-bank boundary; cold-sized SmallVector mapping replaces that private adapter limit, with original submission and tracked allocator.',
                 'First helper refresh compile error and both genuine CPU red test processes are retained alongside successful corrections.',
                 'CUDA first link failed because a task-local temporary directory did not exist; original LNK1104 log and corrected link command remain. This was not a product or numerical failure.',
                 'Actual emitting mapped-adapter owners were refreshed on CPU/CUDA. Vulkan only uses the non-template packed discovery and its own whole-region native path; the adapter is neither defined nor referenced in its actual objects. Apple follows its independent native lowering; source and symbol audits retain this boundary.'],
    backend_scope=['Windows CPU, CUDA and Vulkan and macOS Apple M4 on the actual retained toolchains; exact commands, original process logs and image identities retained.',
                   'Positive packed tests choose existing region proposals through test-only source/provider selection. Vulkan/Apple conservatively retain original-route priority for GPTQ; CPU/CUDA inherit their existing provider and row-dependent candidate ranking. No GPTQ throughput benefit was measured.'],
    limits=['No full model weight payload execution, end-to-end model quality, performance, Linux, all installed configurations or native tensor-core INT4 claim.',
            'No SDK rebuild or payload download. No validation-layer claim for the standard Vulkan run.',
            'Backend actual address, native integer and storage-buffer limits remain; no blanket multi-GiB packed-bank claim.',
            'Opaque backend private allocations remain unknown. Actual runtime OOM does not cause automatic route reselection.',
            'Source/header-only artifact research does not certify uninspected shards or payload values.'])
entries['report-core.json'] = encoded(report)
inventory = dict(schema='gptq-reference-archive-members-v1',
    members=[dict(member=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                  original=provenance.get(name)) for name, data in sorted(entries.items())],
    note='Inventory lists every member except itself; public report gives inventory identity. Repeated dependency arrays are projected with original-receipt hashes.')
entries['inventory.json'] = encoded(inventory)
for name in entries:
    assert Path(name).suffix.lower() not in ('.exe', '.obj', '.o', '.lib', '.a', '.dll', '.pdb', '.map', '.zip', '.tar', '.metallib'), name
DEST.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 20, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data, compresslevel=9)
with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(entries)
    for name, data in entries.items():
        assert archive.read(name) == data, name
report['archive'] = dict(identity=identity(DEST.with_suffix('.zip')),
    members=len(entries), uncompressed_bytes=sum(len(data) for data in entries.values()),
    inventory=dict(member='inventory.json', bytes=len(entries['inventory.json']),
                   sha256=hashlib.sha256(entries['inventory.json']).hexdigest()),
    verification='CRC plus every member exact bytes/SHA inventory verified after writing.')
DEST.with_suffix('.json').write_bytes(encoded(report))
receipt = dict(report=identity(DEST.with_suffix('.json')),
    archive=identity(DEST.with_suffix('.zip')), tests=report['total_passed'],
    members=len(entries), current_source_files=len(source_paths),
    all_member_bytes_verified=True, compact_recipe_projections=len(projections))
(Q / 'package-receipt.json').write_bytes(encoded(receipt))
print(json.dumps(receipt, indent=2))
