from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent.parent;A=Q.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('gptq_host',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
out=Q/'cuda/checks/mapped-refresh';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
base=c.read(A/'grouped-nvfp4/cuda/tests/link-plan.json');meta=h.metadata({'cuda':base})
names=['ct_packed_linear_region.cc','dense_bfloat_scores_region.cc','fp8_shared_prologue_region.cc']
rows=[]
for name in names:
 matches=[(x,meta[c.key(x['path'])]) for x in base['inputs'] if c.key(x['path']) in meta and Path(meta[c.key(x['path'])]['source_path']).name==name]
 assert len(matches)==1,(name,len(matches))
 old,recipe=matches[0];source=Path(recipe['source_path']);tag=source.stem.replace('_','-')
 rows.append(dict(source=b.identity(source),old_object=old,tag=tag,recipe=b.identity(recipe['recipe']),command=b.host_command(recipe['command'],source,tag,out)))
frozen=[b.identity(ROOT/p) for p in ['src/graph/mapped_native_region.h','src/graph/artifact_packed_region.h']]
c.save(out/'plan.json',dict(owners=rows,frozen=frozen,scope='Three actual same-helper CUDA owners; no SDK/NVCC/GPU'))
env,runtime=b.environment(rows[0]['command'],[],out)
def run(row):
 tag=row['tag'];job=out/'commands'/tag;job.mkdir(parents=True)
 result=c.execute(tag+'-compile',row['command'],env,job)
 dep=out/(tag+'-deps.json');d=c.read(dep)['Data'];paths=list(dict.fromkeys([d['Source'],*d['Includes']]))
 r=dict(row,result=result,object=b.identity(out/(tag+'.obj')),source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in paths])
 assert all(b.same(x) for x in frozen)
 c.save(out/(tag+'-identity.json'),r);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(run,rows))
c.save(out/'objects-ready.json',dict(owners=records))
print('MAPPED_CUDA_REFRESHED',len(records),flush=True)
