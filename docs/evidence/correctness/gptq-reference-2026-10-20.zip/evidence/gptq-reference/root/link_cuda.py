from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
Q=S.parent; A=Q.parent; ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('gptq_host',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=Q/'cuda/tests-mapped';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
base_path=A/'grouped-nvfp4/cuda/tests/link-plan.json';base=c.read(base_path)
meta=h.metadata({'cuda':base})
fresh=c.read(Q/'cuda/checks/attempt1/objects-ready.json')['owners']
fresh += c.read(Q/'cuda/checks/mapped-refresh/objects-ready.json')['owners']
cpu=[c.read(p) for p in (Q/'common-cpu/checks/attempt1').glob('*-identity.json')]
cpu = [x for x in cpu if Path(x.get('source',{}).get('path','')).name != 'ct_packed_linear_region.cc']
cpu.append(c.read(Q/'common-cpu/checks/mapped-helper-refresh2/cpu-region-identity.json'))
assert all(b.same(row['object']) and b.same(row['source']) for row in fresh+cpu)
replacements={c.key(row['old_object']['path']):row['object']['path'] for row in fresh if row['old_object']}
added=[];mapped=[]
for row in cpu:
 source=row.get('source',{}).get('path','')
 if Path(source).name not in ['weight_decode.cc','native_provider.cc','torch_cpu_program.cc','ct_packed.cc','ct_packed_linear_region.cc']:
  continue
 found=[old for old in base['inputs'] if c.key(old['path']) in meta and
        c.key(meta[c.key(old['path'])]['source_path'])==c.key(source)]
 if found:
  assert len(found)==1,(source,len(found))
  old=found[0];replacements[c.key(old['path'])]=row['object']['path']
  mapped.append(dict(old=old,new=row['object'],source=row['source']))
 elif Path(source).name=='ct_packed.cc':
  added.append(row['object']['path'])
assert any(Path(x['source']['path']).name=='weight_decode.cc' for x in mapped)
# The actual native provider references its current NVFP4 leaf. Add it only
# when absent from this retained closure, reusing its unchanged source object.
if not any(c.key(x['path']) in meta and Path(meta[c.key(x['path'])]['source_path']).as_posix().endswith('compute_provider_native/nvfp4.cc') for x in base['inputs']):
 p=A/'grouped-nvfp4/common-cpu/checks/native-nvfp4-identity.json'
 if not p.exists():
  candidates=[]
  plan=c.read(A/'grouped-nvfp4/common-cpu/checks/link-plan.json')
  cm=h.metadata({'cpu':plan})
  for old in plan['inputs']:
   rec=cm.get(c.key(old['path']))
   if rec and Path(rec['source_path']).as_posix().endswith('compute_provider_native/nvfp4.cc'):
    assert b.same(old);candidates.append((old,rec))
  assert len(candidates)==1,candidates
  old,rec=candidates[0]
  assert b.same(rec['source'])
  added.append(old['path'])
 else:
  r=c.read(p);assert b.same(r['source']) and b.same(r['object']);added.append(r['object']['path'])
added.append(next(row['object']['path'] for row in fresh if row['tag']=='gptq-test'))
command=[]
for arg in base['command']:
 value=replacements.get(c.key(arg),arg)
 for flag,suffix in [('/OUT:','.exe'),('/MAP:','.map'),('/IMPLIB:','.lib'),('/PDB:','.pdb'),('/ILK:','.ilk')]:
  if arg.upper().startswith(flag):value=flag+str(out/('gptq'+suffix))
 command.append(value)
command[1:1]=added
all_inputs=[replacements.get(c.key(x['path']),x['path']) for x in base['inputs']]+added
identities=[b.identity(p) for p in all_inputs]
env,runtime=b.environment(command,all_inputs,out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.save(out/'link-plan.json',dict(command=command,inputs=identities,base=b.identity(base_path),
    mapped_CPU_owners=mapped,additional_real_inputs=[b.identity(p) for p in added],
    scope='Actual cached closure with fresh CUDA pair/region/two wrappers and current CPU leaf glue; no SDK rebuild'))
c.execute('gptq-link',command,env,out)
assert all(b.same(x) for x in identities)
image=out/'gptq.exe'
c.save(out/'image.json',b.identity(image))
test=[str(image),'--gtest_filter=CudaGptqReferenceGraph.*:CudaCtPackedLinear.*',
      '--gtest_output=xml:'+str(out/'tests.xml')]
c.save(out/'run-plan.json',dict(command=test,expected_cases=7,not_executed=True))
print('CUDA_LINK_READY',len(identities),'inputs',flush=True)
