from pathlib import Path
import hashlib, json, os, re, struct, subprocess, sys, time

root = Path.cwd()
a = root / '.scratch/architecture-refactor-2026-10-18'
stage = a / 'gptq-reference/vulkan'
checks, shaders = stage / 'checks', stage / 'shaders'
phase = sys.argv[1]
plan = json.loads((checks / 'proposed-plan.json').read_bytes())
env = os.environ.copy()
setup = subprocess.run(['cmd', '/d', '/c', str(a / 'bf16-nan-cast-contract/compiler-env.bat')],
                       capture_output=True, text=True, check=True)
for line in setup.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        name, value = line.split('=', 1)
        env[name.upper()] = value
records = []

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def load(path):
    return json.loads(Path(path).read_bytes())

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')

def run(label, command):
    start = time.time()
    result = subprocess.run(command, cwd=root, env=env, capture_output=True,
                            text=True, encoding='utf8', errors='replace')
    (checks / (label + '.stdout.log')).write_text(result.stdout, encoding='utf8')
    (checks / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    records.append(dict(label=label, command=command, exit_code=result.returncode,
                        seconds=time.time() - start))
    save(checks / ('commands-' + phase + '.json'), records)
    print(label, result.returncode, flush=True)
    if result.returncode:
        print((result.stdout + result.stderr)[-9000:])
        raise SystemExit(result.returncode)

def compile_one(item):
    run(item['tag'] + '-compile', item['command'])
    deps = load(checks / (item['tag'] + '-deps.json'))['Data']
    paths = dict.fromkeys([deps['Source'], *deps['Includes']])
    save(checks / (item['tag'] + '-identity.json'), dict(
        command=item['command'], source=identity(item['source']), object=identity(item['object']),
        recipe=item['recipe'], dependencies=[identity(path) for path in paths]))

def spirv(data):
    assert len(data) >= 20 and len(data) % 4 == 0
    words = struct.unpack('<' + 'I' * (len(data) // 4), data)
    assert words[0] == 0x07230203 and words[1] <= 0x00010500
    at = 5
    while at < len(words):
        count, opcode = words[at] >> 16, words[at] & 65535
        assert count and at + count <= len(words)
        if opcode == 17:
            assert count == 2 and words[at + 1] == 1
        at += count
    return words

if phase == 'shaders':
    shaders.mkdir(exist_ok=True)
    previous = a / 'grouped-nvfp4-vulkan/shaders'
    names = re.findall(r'uint32_t> (\w+)\(\) noexcept;',
                       (previous / 'vulkan_shaders.h').read_text())
    assert len(names) == 15
    names.insert(names.index('ct_packed') + 1, 'gptq_v1')
    old_artifacts = load(a / 'grouped-nvfp4-vulkan/checks/shader-artifacts.json')
    old_paths = {x['name']: Path(x['artifact']['path']) for x in old_artifacts['artifacts']}
    core = []
    for header in ['nvfp4_f32.h', 'ct_packed.h']:
        text = (root / 'src/compute_shader_shared' / header).read_text()
        core.append(text.split('R"HYLE_SHADER(', 1)[1].split(')HYLE_SHADER"', 1)[0])
    source = (root / 'src/compute_route_vulkan/shaders/ct_packed.comp').read_text()
    expanded = source.replace('// HYLE_CT_F32_SOURCE', '\n'.join(core))
    for name in ['ct_packed', 'gptq_v1']:
        generated = shaders / (name + '.generated.comp')
        generated.write_bytes(expanded.encode())
        command = ['C:/public/tools/glslang/glslangValidator.exe', '-V', '--target-env',
                   'vulkan1.2', '--preamble-text',
                   '#extension GL_GOOGLE_include_directive : require\n',
                   '-I' + str(root / 'third_party/ggml_vulkan_shaders/shaders'), '-S', 'comp']
        if name == 'gptq_v1':
            command.append('-DHYLE_GPTQ_V1=1')
        command += ['-o', str(shaders / (name + '.spv')), str(generated)]
        run(name + '-shader', command)
    header = ['#pragma once', '#include <cstdint>', '#include <span>',
              'namespace hyle::compute::vulkan::detail::shaders {']
    cpp = ['#include "vulkan_shaders.h"',
           'namespace hyle::compute::vulkan::detail::shaders {']
    artifacts = []
    for name in names:
        path = shaders / (name + '.spv') if name in ('ct_packed', 'gptq_v1') else old_paths[name]
        words = spirv(path.read_bytes())
        header.append('std::span<const std::uint32_t> ' + name + '() noexcept;')
        cpp.append('namespace { constexpr std::uint32_t ' + name + '_words[] = {')
        for offset in range(0, len(words), 8):
            cpp.append('  ' + ', '.join(f'0x{x:08x}u' for x in words[offset:offset + 8]) + ',')
        cpp += ['}; }', 'std::span<const std::uint32_t> ' + name + '() noexcept { return ' + name + '_words; }']
        artifacts.append(dict(name=name, artifact=identity(path),
                              compiled=name in ('ct_packed', 'gptq_v1')))
    header.append('} // namespace hyle::compute::vulkan::detail::shaders')
    cpp.append('} // namespace hyle::compute::vulkan::detail::shaders')
    (shaders / 'vulkan_shaders.h').write_bytes(('\n'.join(header) + '\n').encode())
    (shaders / 'vulkan_shaders.cc').write_bytes(('\n'.join(cpp) + '\n').encode())
    old_ct = old_paths['ct_packed']
    comparison = dict(previous=identity(old_ct), current=identity(shaders / 'ct_packed.spv'),
                      byte_equal=old_ct.read_bytes() == (shaders / 'ct_packed.spv').read_bytes())
    assert comparison['byte_equal'], comparison
    save(checks / 'shader-artifacts.json', dict(artifacts=artifacts,
        old_CT_comparison=comparison, reused=14, compiled=2,
        shared_math=[identity(root / 'src/compute_shader_shared' / name)
                     for name in ['nvfp4_f32.h', 'ct_packed.h']],
        generated_source=identity(shaders / 'vulkan_shaders.cc'),
        generated_header=identity(shaders / 'vulkan_shaders.h')))
elif phase in ('product', 'test'):
    for item in plan['compile']:
        if (item['tag'] in ('ct-test', 'gptq-test')) == (phase == 'test'):
            compile_one(item)
elif phase == 'link':
    base = load(a / 'grouped-nvfp4-vulkan/checks/link-plan.json')
    replacements = {str(Path(x['previous_object']['path'])).lower(): x['object']
                    for x in plan['compile'] if x['tag'] != 'gptq-test'}
    drop = {str(Path(x['path'])).lower() for x in plan['drop_unrelated_old_tests']}
    # Current common CPU products are reused once where this retained closure
    # already has their sources. Required new native-provider leaves are added.
    shared = a / 'gptq-reference/common-cpu/checks/attempt1'
    pairs = [('weight-decode', 'weight-decode.obj'),
             ('native-provider', 'compute_provider_native-native_provider.obj'),
             ('torch-cpu', 'torch-cpu.obj')]
    overlay = []
    for name, previous_name in pairs:
        current = load(shared / (name + '-identity.json'))
        old = next(x for x in base['inputs'] if Path(x['path']).name == previous_name)
        replacements[str(Path(old['path'])).lower()] = current['object']['path']
        overlay.append(dict(receipt=identity(shared / (name + '-identity.json')),
                            source=current['source'], object=current['object']))
    leaves = [shared / 'ct-packed-identity.json',
              a / 'grouped-nvfp4/common-cpu/checks/native-nvfp4-identity.json']
    leaf_objects = []
    for receipt in leaves:
        current = load(receipt)
        assert identity(current['source']['path'])['sha256'] == current['source']['sha256']
        assert identity(current['object']['path'])['sha256'] == current['object']['sha256']
        leaf_objects.append(current['object']['path'])
        overlay.append(dict(receipt=identity(receipt), source=current['source'], object=current['object']))
    command, seen, dropped = [], set(), set()
    for arg in base['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:')):
            continue
        key = str(Path(arg)).lower()
        if key in drop:
            dropped.add(key)
            continue
        if key in replacements:
            seen.add(key)
            command.append(replacements[key])
        else:
            command.append(arg)
    assert seen == set(replacements) and dropped == drop
    command[1:1] = [str(checks / 'gptq-test.obj'), *leaf_objects]
    command += ['/OUT:' + str(checks / 'gptq-test.exe'), '/MAP:' + str(checks / 'gptq-test.map'),
                '/IMPLIB:' + str(checks / 'gptq-test.lib')]
    run('link', command)
    save(checks / 'link-plan.json', dict(command=command, shared_CPU_overlay=overlay,
        inputs=[identity(p) for p in command[1:] if Path(p).is_file()],
        dropped_old_tests=plan['drop_unrelated_old_tests'],
        executable=identity(checks / 'gptq-test.exe')))
else:
    raise ValueError(phase)
