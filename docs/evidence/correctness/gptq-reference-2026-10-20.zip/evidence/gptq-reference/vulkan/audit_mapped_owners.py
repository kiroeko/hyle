from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import subprocess

root = Path.cwd()
q = root / '.scratch/architecture-refactor-2026-10-18/gptq-reference'
dumpbin = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/dumpbin.exe')
plans = {name: q / relative for name, relative in {
    'Vulkan': 'vulkan/checks/link-plan.json',
    'CUDA': 'cuda/tests-mapped/link-plan.json'}.items()}


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


members = {}
for backend, path in plans.items():
    plan = json.loads(path.read_bytes())
    for item in plan['inputs']:
        p = Path(item['path'])
        if p.suffix.lower() == '.obj':
            members.setdefault(str(p), []).append(backend)


def scan(item):
    path, backends = item
    run = subprocess.run([str(dumpbin), '/symbols', path], capture_output=True,
                         text=True, encoding='utf8', errors='replace')
    assert run.returncode == 0, path
    hits = [line.strip() for line in run.stdout.splitlines()
            if 'mapped_native_region' in line]
    defined = [line for line in hits if 'UNDEF' not in line and ' SECT' in line]
    undefined = [line for line in hits if 'UNDEF' in line]
    return dict(object=identity(path), backends=backends,
                defined=defined, undefined=undefined)


with ThreadPoolExecutor(max_workers=4) as pool:
    scans = list(pool.map(scan, members.items()))
owners = [item for item in scans if item['defined'] or item['undefined']]
new = q / 'vulkan/checks'
new_vulkan = [x for x in scans if Path(x['object']['path']).parent == new]
assert len(new_vulkan) == 7
assert not any(x['defined'] or x['undefined'] for x in new_vulkan)
report = dict(
    status='read_only_symbols_scan_no_compilation_or_GPU',
    method=[str(dumpbin), '/symbols', '<each actual explicit .obj input>'],
    plans={name: identity(path) for name, path in plans.items()},
    objects_scanned=len(scans),
    per_backend={name: sum(name in x['backends'] for x in scans) for name in plans},
    owners=owners,
    new_Vulkan_objects=[dict(object=x['object'], defined_count=len(x['defined']),
                             undefined_count=len(x['undefined'])) for x in new_vulkan],
    conclusion='The seven newly compiled Vulkan owners define and reference no mapped_native_region symbols. Vulkan uses only the non-template ArtifactPackedPattern discovery and its own whole-region native implementation. The common adapter header changed after compilation, but no old adapter implementation is emitted or called by these objects; its new SmallVector layout does not enter Vulkan private Program or public ABI. Existing Vulkan 12-case execution remains applicable. CUDA actual adapter owners are listed explicitly below; any old test owner would appear here.',
    limits='Explicit .obj link inputs only; no SDK or unrelated archive scan. This does not certify a full installed build.')
(q / 'vulkan/mapped-owner-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(objects=len(scans), owners=[dict(path=x['object']['path'], backends=x['backends'],
    defined=len(x['defined']), undefined=len(x['undefined'])) for x in owners],
    receipt=identity(q / 'vulkan/mapped-owner-audit.json')), indent=2))
