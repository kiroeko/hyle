from pathlib import Path
import hashlib
import json

root = Path.cwd()
stage = root / '.scratch/architecture-refactor-2026-10-18/gptq-reference/vulkan'
checks = stage / 'checks'


def load(path):
    return json.loads(Path(path).read_bytes())


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


freeze = load(stage / 'source-freeze.json')
for entry in freeze['files']:
    assert identity(entry['original']['path']) == entry['original']
    assert identity(entry['snapshot']['path']) == entry['snapshot']
assert identity(freeze['fixture']['path']) == freeze['fixture']
dependency_count = 0
receipts = []
for path in sorted(checks.glob('*-identity.json')):
    record = load(path)
    assert identity(record['source']['path']) == record['source']
    assert identity(record['object']['path']) == record['object']
    for dep in record['dependencies']:
        assert identity(dep['path']) == dep, dep['path']
        dependency_count += 1
    receipts.append(identity(path))
commands = []
for phase in ('shaders', 'product', 'test', 'link'):
    path = checks / ('commands-' + phase + '.json')
    data = load(path)
    assert all(x['exit_code'] == 0 for x in data)
    commands.append(dict(receipt=identity(path), count=len(data), exit_codes=[x['exit_code'] for x in data]))
link = load(checks / 'link-plan.json')
for entry in link['inputs']:
    assert identity(entry['path']) == entry, entry['path']
final = dict(status='compiled_and_linked_GPU_not_run_by_this_agent',
             original_freeze=identity(stage / 'source-freeze.json'),
             files=freeze['files'], fixture=freeze['fixture'],
             shared_source_freeze_at_compile=freeze['shared'],
             compiler_receipts=receipts,
             dependency_checks=dict(entries=dependency_count, mismatches=0),
             commands=commands,
             shader_proof=identity(checks / 'shader-artifacts.json'),
             link_plan=identity(checks / 'link-plan.json'),
             executable=identity(checks / 'gptq-test.exe'),
             old_inline_arity_owner_audit=identity(stage / 'inline-traits-owner-audit.json'),
             proposed_GPU_filter='VulkanGptqReferenceGraph.*:VulkanCtPackedLinear.*:VulkanGroupedNvfp4ReferenceGraph.*:VulkanNvfp4ReferenceGraph.*',
             proposed_GPU_cases=12,
             scope=['2 shader compilations; original CT SPIR-V byte-identical and 14 prior SPIR-V artifacts reused',
                    '7 strict C++ compilations: 5 Vulkan products plus 2 wrappers; 1 link',
                    'Fresh public inference, native CPU provider and Torch CPU owners overlaid once; required CT/NVFP4 native leaves reused',
                    'Unrelated stale IREE test owners removed from this focused image to exclude old inline ArtifactWeightDecode 3-port COMDAT definitions',
                    'No SDK, whole current build, GPU execution, validation layer, performance or full model claim'])
(stage / 'final-build-receipt.json').write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps(dict(receipt=identity(stage / 'final-build-receipt.json'), executable=final['executable'], dependencies_checked=dependency_count), indent=2))
