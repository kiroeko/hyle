#include "vulkan_tensor.h"

#include <algorithm>
#include <array>
#include <new>

#include "../compute_packed_shared/ct_packed_linear.h"
#include "vulkan_shaders.h"

namespace hyle::compute::vulkan::detail {
Status lower_ct_packed(ProgramState &program, const PlanStep &step) noexcept try {
  const auto descriptor = step.operation.custom_as<packed::internal::CtPackedLinear>();
  if (!descriptor || step.outputs.size() != 1 ||
      step.inputs.size() != descriptor->operation_traits().inputs.minimum)
    return Status::InvalidArgument("Vulkan CT packed ports differ");
  std::array<TensorDesc, 4> inputs;
  for (std::size_t port = 0; port < step.inputs.size(); ++port)
    inputs[port] = program.values[step.inputs[port]].description;
  std::array<TensorDesc, 1> output;
  HYLE_RETURN_IF_ERROR(descriptor->infer_output_descriptions(
      std::span(inputs).first(step.inputs.size()), output));
  if (output[0] != program.values[step.outputs[0]].description ||
      !inputs[0].is_plain() || !inputs[0].is_dense() || !output[0].is_dense())
    return Status::Unimplemented("Vulkan CT packed requires dense original operands/output");
  const auto &limits = program.runtime->device->properties.limits;
  const auto depth = std::uint64_t(inputs[1].dimensions()[1]) * 8;
  const auto columns = std::uint64_t(inputs[1].dimensions()[0]);
  const auto rows = *inputs[0].element_count() / depth;
  if (rows == 0 || columns > UINT32_MAX || depth > UINT32_MAX - 31U || rows > UINT32_MAX ||
      limits.maxComputeWorkGroupInvocations < 64 || limits.maxComputeWorkGroupSize[0] < 64 ||
      !limits.maxComputeWorkGroupCount[0] || !limits.maxComputeWorkGroupCount[1])
    return Status::Unimplemented("Vulkan CT packed indexing/dispatch domain");
  // Only real byte carriers are bounded. There is no dense N*K allocation.
  const auto check = [&](const TensorDesc &description) -> Status {
    HYLE_ASSIGN_OR_RETURN(auto bytes, description.required_bytes());
    HYLE_ASSIGN_OR_RETURN(auto capacity, buffer_capacity(bytes));
    if (capacity > UINT32_MAX || capacity > limits.maxStorageBufferRange)
      return Status::Unimplemented("Vulkan CT packed actual storage exceeds device limits");
    return Status::Ok();
  };
  for (const auto &input : std::span(inputs).first(step.inputs.size())) HYLE_RETURN_IF_ERROR(check(input));
  HYLE_RETURN_IF_ERROR(check(output[0]));
  const auto asymmetric = descriptor->format ==
      model_ops::WeightArtifactFormat::kCompressedTensorsAsymmetric4;
  const auto scale = step.inputs.back();
  const std::array<SpecializationConstant, 8> constants{{
      {0, std::uint32_t(rows)}, {1, std::uint32_t(columns)}, {2, std::uint32_t(depth)},
      {3, descriptor->group_size}, {4, asymmetric ? 1U : 0U},
      {5, *tensor_storage_type(program.values[scale].description.data_type())},
      {6, *tensor_storage_type(descriptor->decode_type)},
      {7, *tensor_storage_type(descriptor->operand_type)}}};
  Dispatch dispatch;
  HYLE_ASSIGN_OR_RETURN(dispatch.pipeline, create_pipeline(program.runtime->device,
      {shaders::ct_packed(), 5, 16, constants}));
  dispatch.values = {step.inputs[0], step.inputs[1],
      asymmetric ? step.inputs[2] : step.inputs[1], scale, step.outputs[0]};
  dispatch.tensor_byte_origins = true;
  dispatch.push.resize(16); // Four input origins; output is an aligned owned word span.
  const auto pairs = (*output[0].element_count() + 1) / 2;
  const auto x = (std::min)(pairs, std::uint64_t(limits.maxComputeWorkGroupCount[0]));
  const auto y = (pairs + x - 1) / x;
  if (y > limits.maxComputeWorkGroupCount[1])
    return Status::Unimplemented("Vulkan CT packed grid exceeds native limits");
  dispatch.groups = {std::uint32_t(x), std::uint32_t(y), 1};
  program.dispatches.push_back(std::move(dispatch));
  return Status::Ok();
} catch (const std::bad_alloc &) {
  return Status::ResourceExhausted("Vulkan CT packed preparation metadata");
}
} // namespace hyle::compute::vulkan::detail
