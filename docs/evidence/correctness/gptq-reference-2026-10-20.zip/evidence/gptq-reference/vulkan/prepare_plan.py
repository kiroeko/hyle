from pathlib import Path
import hashlib, json, difflib, ast

root = Path.cwd()
a = root / '.scratch/architecture-refactor-2026-10-18'
stage = a / 'gptq-reference/vulkan'
checks = stage / 'checks'
checks.mkdir(exist_ok=True)

def load(p):
    return json.loads(Path(p).read_bytes())

def identity(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

base_path = a / 'grouped-nvfp4-vulkan/checks/link-plan.json'
base = load(base_path)
items = [
    ('vulkan_ct_packed', 'src/compute_route_vulkan/vulkan_ct_packed.cc',
     a / 'ct-packed-vulkan/checks/vulkan_ct_packed-identity.json'),
    ('native_region', 'src/graph_route_vulkan/native_region.cc',
     a / 'ct-packed-vulkan/checks/native_region-identity.json'),
    ('vulkan_operations', 'src/compute_route_vulkan/vulkan_operations.cc',
     a / 'grouped-nvfp4-vulkan/checks/vulkan_operations-identity.json'),
    ('vulkan_iree', 'src/compute_route_vulkan/vulkan_iree.cc', None),
    ('vulkan_shaders', stage / 'shaders/vulkan_shaders.cc',
     a / 'grouped-nvfp4-vulkan/checks/vulkan_shaders-identity.json'),
    ('ct-test', 'tests/graph_route_vulkan/ct_packed_linear_test.cc',
     a / 'ct-packed-vulkan/checks/ct-test-identity.json'),
    ('gptq-test', 'tests/graph_route_vulkan/gptq_reference_test.cc',
     a / 'grouped-nvfp4-vulkan/checks/grouped-nvfp4-test-identity.json'),
]
old_iree = next(Path(x['path']) for x in base['inputs']
                if Path(x['path']).name.endswith('compute_route_vulkan-vulkan_iree.obj'))
iree_recipe = None
for candidate in old_iree.parent.glob('*identity.json'):
    data = load(candidate)
    if str(Path(data.get('object', {}).get('path', ''))).lower() == str(old_iree).lower():
        iree_recipe = candidate
        break
assert iree_recipe, old_iree
items[3] = (items[3][0], items[3][1], iree_recipe)
compiles = []
for tag, source, recipe in items:
    record = load(recipe)
    command, skip = [], False
    for arg in record['command']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        command.append(arg)
    command.insert(1, '-I' + str(stage / 'shaders'))
    command += ['/W4', '/WX', '/sourceDependencies', str(checks / (tag + '-deps.json')),
                str(root / source), '/Fo' + str(checks / (tag + '.obj')),
                '/Fd' + str(checks / (tag + '.pdb'))]
    compiles.append(dict(tag=tag, source=str(root / source), recipe=identity(recipe),
                         previous_object=record['object'], command=command,
                         object=str(checks / (tag + '.obj'))))
drop = [x for x in base['inputs'] if Path(x['path']).name in
        ('bank-test.obj', 'test-graph_route_vulkan-iree_test.obj')]
assert len(drop) == 2
verified = []
for record in base['inputs']:
    if not record['path'].lower().endswith('.obj'):
        continue
    actual = identity(record['path'])
    assert record['bytes'] == actual['bytes'] and record['sha256'] == actual['sha256']
    verified.append(actual)

abi_headers = ['src/compute_route_vulkan/vulkan_internal.h',
               'src/compute_route_vulkan/vulkan_program_internal.h',
               'src/compute_provider_iree_vulkan/native_program.h',
               'include/hyle/compute/detail/vulkan_plan.h',
               'include/hyle/compute/tensor.h', 'include/hyle/compute/operation.h']
previous = load(a / 'grouped-nvfp4-vulkan/checks/vulkan_program-identity.json')
old = {str(Path(x['path'])).lower(): x for x in previous['dependencies']}
abi = []
for name in abi_headers:
    current = identity(root / name)
    retained = old[str(root / name).lower()]
    assert current['bytes'] == retained['bytes'] and current['sha256'] == retained['sha256']
    abi.append(dict(current=current, previous=retained, byte_equal=True))

files = [x['path'] for x in load(stage / 'before.json')]
files.append('tests/graph_route_vulkan/gptq_reference_test.cc')
freeze, changes = [], []
for relative in files:
    path = root / relative
    copied = stage / 'source' / relative
    copied.parent.mkdir(parents=True, exist_ok=True)
    copied.write_bytes(path.read_bytes())
    freeze.append(dict(original=identity(path), snapshot=identity(copied)))
    before = stage / 'before' / relative
    old_text = before.read_text(encoding='utf8') if before.exists() else ''
    changes += list(difflib.unified_diff(old_text.splitlines(True),
        path.read_text(encoding='utf8').splitlines(True),
        fromfile='before/' + relative, tofile='after/' + relative))
(stage / 'implementation.diff').write_text(''.join(changes), encoding='utf8', newline='')
for p in ['build_shaders.py']:
    ast.parse((root / 'src/compute_route_vulkan' / p).read_text())
frozen = dict(status='source_frozen_not_compiled_or_run', files=freeze,
              shared=identity(a / 'gptq-reference/root/shared-source-freeze.json'),
              fixture=identity(root / 'tests/compute_models/gptq_reference_fixture.h'))
(stage / 'source-freeze.json').write_text(json.dumps(frozen, indent=2) + '\n')
plan = dict(status='planned_only_no_build_or_GPU', baseline=identity(base_path),
            verified_objects=verified, private_abi_unchanged=abi,
            compile=compiles, drop_unrelated_old_tests=drop,
            public_infer=identity(a / 'gptq-reference/common-cpu/checks/attempt1/weight-decode-identity.json'),
            arity_audit=identity(stage / 'inline-traits-owner-audit.json'),
            shader_compile=['ct_packed', 'gptq_v1'], other_SPV_reused=14,
            limits='Actual typed carrier and output byte ranges bound U32 addressing; no hypothetical dense N*K bank capacity restriction on the bounded packed route. General INT32 plan limits remain. No SDK build or GPU.')
(checks / 'proposed-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps(dict(plan=identity(checks / 'proposed-plan.json'),
                      source_freeze=identity(stage / 'source-freeze.json'),
                      compile_count=len(compiles), old_tests_dropped=len(drop)), indent=2))
