"""GPTQ: five current product owners, two new tests, one renamed-header CT test."""
from pathlib import Path
import importlib.util,json,sys,argparse,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
G=Path(__file__).resolve().parent;A=G.parents[1];ROOT=A.parents[1];S=G/'checks/attempt1'
spec=importlib.util.spec_from_file_location('gptq_cpu_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'grouped-nvfp4/common-cpu/checks/link-plan.json';READY=G/'source-freeze.json';SHARED=A/'gptq-reference/root/shared-source-freeze.json'
OWNERS=[('weight-decode','src/compute_ops/weight_decode.cc'),('torch-cpu','src/compute_provider_native/torch_cpu_program.cc'),('ct-packed','src/compute_provider_native/ct_packed.cc'),('native-provider','src/compute_provider_native/native_provider.cc'),('cpu-region','src/graph_route_cpu/ct_packed_linear_region.cc'),('ct-direct-test','tests/compute_provider_native/ct_packed_test.cc')]
FILTER='NativeGptq.*:CpuGptqReferenceGraph.*:NativeCtPackedLinear.*:CpuCtPackedLinear.*'
def same(row):
 p=Path(row['path']);p=p if p.is_absolute() else ROOT/p;actual=b.identity(p);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],str(p)
def frozen():
 for row in c.read(READY)['files']:same(row)
 for row in c.read(SHARED)['sources']:same(row)
def proposal():
 base=c.read(BASE);meta=h.metadata({'cpu':base});rows=[]
 for tag,source in OWNERS:
  match=[(x,meta.get(c.key(x['path']))) for x in base['inputs'] if c.key(meta.get(c.key(x['path']),{}).get('source_path',''))==c.key(ROOT/source)]
  assert len(match)==1,(source,len(match));old,record=match[0];cmd=b.host_command(record['command'],ROOT/source,tag,S)
  if '/test' in '/'+source and not any(x.startswith('/DHYLE_TEST_TORCH_CPU') for x in cmd):cmd.insert(1,'/DHYLE_TEST_TORCH_CPU=1')
  rows.append(dict(tag=tag,source_path=str(ROOT/source),old_object=old,recipe=b.identity(record['recipe']),command=cmd,object_path=str(S/(tag+'.obj'))))
 for tag,source,recipe in [('direct-test','tests/compute_provider_native/gptq_test.cc','grouped-nvfp4/common-cpu/checks/direct-test-identity.json'),('graph-test','tests/graph_route_cpu/gptq_reference_test.cc','grouped-nvfp4/common-cpu/checks/graph-test-identity.json')]:
  record=c.read(A/recipe);cmd=b.host_command(record['command'],ROOT/source,tag,S)
  if not any(x.startswith('/DHYLE_TEST_TORCH_CPU') for x in cmd):cmd.insert(1,'/DHYLE_TEST_TORCH_CPU=1')
  rows.append(dict(tag=tag,source_path=str(ROOT/source),old_object=None,recipe=b.identity(A/recipe),command=cmd,object_path=str(S/(tag+'.obj'))))
 return dict(base=b.identity(BASE),source_freeze=b.identity(READY),shared_freeze=b.identity(SHARED),compile=rows,counts=dict(product_CXX=5,test_CXX=3,links=1,NVCC=0,SDK=0,GPU=0),flags_scope='HYLE_TEST_TORCH_CPU=1 matches actual current CMake native/Graph targets with already-linked torch_cpu capability; registers original-codec tests instead of silently excluding them.',filter=FILTER)
def compileall():
 frozen();plan=proposal();c.save(S/'plan.json',plan)
 for r in plan['compile']:
  if (S/(r['tag']+'-identity.json')).exists():
   rec=c.read(S/(r['tag']+'-identity.json'));same(rec['source']);same(rec['object']);continue
  assert not (S/(r['tag']+'-compile.result.json')).exists(),'preserve first failure before new attempt'
  frozen();env,_=b.environment(r['command'],[],S);c.execute(r['tag']+'-compile',r['command'],env,S)
  dep=S/(r['tag']+'-deps.json');d=c.read(dep)['Data'];rec=dict(source=b.identity(r['source_path']),object=b.identity(r['object_path']),command=r['command'],recipe=r['recipe'],old_object=r['old_object'],source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in dict.fromkeys([d['Source'],*d['Includes']])],source_freeze=b.identity(READY),shared_freeze=b.identity(SHARED));c.save(S/(r['tag']+'-identity.json'),rec);print('COMPILED',r['tag'],rec['object']['sha256'],flush=True)
 frozen();c.save(S/'compile-summary.json',dict(passed=True,product_CXX=5,test_CXX=3,NVCC=0,SDK=0,GPU=0))
def link():
 assert not (S/'link.result.json').exists();frozen();base=c.read(BASE);plan=c.read(S/'plan.json');records=[c.read(S/(r['tag']+'-identity.json')) for r in plan['compile']];swaps={c.key(r['old_object']['path']):r['object'] for r in records if r['old_object']};extra=[r['object'] for r in records if not r['old_object']]
 inputs=[swaps.get(c.key(r['path']),r) for r in base['inputs']]+extra
 for row in inputs:same(row)
 image=S/'cpu.exe';command=[swaps[c.key(x)]['path'] if c.key(x) in swaps else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];command += [r['path'] for r in extra]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 lp=dict(command=command,inputs=inputs,base=b.identity(BASE),replacements=[dict(before=r['old_object'],after=r['object']) for r in records if r['old_object']],new_tests=extra,source_freeze=b.identity(READY),shared_freeze=b.identity(SHARED));c.save(S/'link-plan.json',lp);env,runtime=b.environment(command,[r['path'] for r in inputs],S);c.save(S/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,S);c.save(S/'image.json',b.identity(image))
def run():
 assert not (S/'tests.result.json').exists();lp=c.read(S/'link-plan.json');image=c.read(S/'image.json');same(image)
 for r in lp['inputs']:same(r)
 env,_=b.environment(lp['command'],[r['path'] for r in lp['inputs']],S);result=c.execute('tests',[image['path'],'--gtest_filter='+FILTER,'--gtest_output=xml:'+str(S/'tests.xml')],env,S)
 cases=ET.parse(S/'tests.xml').findall('.//testcase');failed=[x.attrib for x in cases if x.find('failure') is not None];skipped=[x.attrib for x in cases if x.find('skipped') is not None]
 c.save(S/'summary.json',dict(passed=not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,names=[x.get('classname')+'.'+x.get('name') for x in cases],properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],process=result,counts=c.read(S/'plan.json')['counts'],image=image,link_plan=b.identity(S/'link-plan.json'),source_freeze=b.identity(READY),shared_freeze=b.identity(SHARED)));assert not failed and not skipped
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['compile','link','run']);args=p.parse_args();S.mkdir(parents=True,exist_ok=True);(S/'tmp').mkdir(exist_ok=True);{'compile':compileall,'link':link,'run':run}[args.mode]()
