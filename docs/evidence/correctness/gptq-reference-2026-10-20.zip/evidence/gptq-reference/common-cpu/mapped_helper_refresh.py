from pathlib import Path
import sys,importlib.util,json,xml.etree.ElementTree as ET,argparse
sys.dont_write_bytecode=True
G=Path(__file__).resolve().parent;A=G.parents[1];ROOT=A.parents[1];S=G/'checks/mapped-helper-refresh';BASE=G/'checks/schema-owner-refresh/link-plan.json';RECIPE=G/'checks/attempt1/cpu-region-identity.json';HEADER=ROOT/'src/graph/mapped_native_region.h'
spec=importlib.util.spec_from_file_location('gptq_mapped_refresh_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('--helper-sha',required=True);p.add_argument('--freeze',required=True);p.add_argument('--attempt',default='mapped-helper-refresh');args=p.parse_args();S=G/'checks'/args.attempt
S.mkdir(parents=True,exist_ok=True);(S/'tmp').mkdir(exist_ok=True)
freeze=Path(args.freeze).resolve();assert freeze.is_file();assert b.identity(HEADER)['sha256']==args.helper_sha
assert not (S/'compile.result.json').exists(),'preserve existing attempt'
base=c.read(BASE);rec=c.read(RECIPE);source=ROOT/'src/graph_route_cpu/ct_packed_linear_region.cc';old=rec['object'];assert sum(c.key(x['path'])==c.key(old['path']) for x in base['inputs'])==1
cmd=b.host_command(rec['command'],source,'cpu-region',S);plan=dict(command=cmd,source=b.identity(source),helper=b.identity(HEADER),shared_freeze=b.identity(freeze),recipe=b.identity(RECIPE),base=b.identity(BASE),old_object=old,counts_total=dict(product_CXX_success=6,product_CXX_failed=1,test_CXX_success=4,links=3,CPU_processes=3,GPU=0,SDK=0,NVCC=0),reason='Root removes historical fixed-four mapped native input limit using cold variable arity; refresh only actual CPU consumer, keep existing exact test objects and schema-owner correction.')
c.save(S/'plan.json',plan);(S/'mapped_native_region.h').write_bytes(HEADER.read_bytes());env,_=b.environment(cmd,[],S);c.execute('compile',cmd,env,S)
assert b.identity(HEADER)['sha256']==args.helper_sha;d=c.read(S/'cpu-region-deps.json')['Data'];obj=b.identity(S/'cpu-region.obj');c.save(S/'cpu-region-identity.json',dict(source=b.identity(source),object=obj,command=cmd,dependencies=[b.identity(x) for x in dict.fromkeys([d['Source'],*d['Includes']])],source_dependencies=b.identity(S/'cpu-region-deps.json'),old_object=old,recipe=b.identity(RECIPE),shared_freeze=b.identity(freeze)))
image=S/'cpu.exe';command=[obj['path'] if c.key(x)==c.key(old['path']) else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))];inputs=[obj if c.key(x['path'])==c.key(old['path']) else x for x in base['inputs']]
for x in inputs:
 actual=b.identity(x['path']);assert actual['sha256']==x['sha256'] and actual['bytes']==x['bytes']
c.save(S/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(BASE),replacement=dict(before=old,after=obj),shared_freeze=b.identity(freeze)));env,runtime=b.environment(command,[x['path'] for x in inputs],S);c.save(S/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,S);c.save(S/'image.json',b.identity(image))
command=[str(image),'--gtest_filter=NativeGptq.*:CpuGptqReferenceGraph.*:NativeCtPackedLinear.*:CpuCtPackedLinear.*','--gtest_output=xml:'+str(S/'tests.xml')]
try:c.execute('tests',command,env,S)
finally:
 if (S/'tests.xml').exists():
  cases=ET.parse(S/'tests.xml').findall('.//testcase');failed=[x.attrib for x in cases if x.find('failure') is not None];skipped=[x.attrib for x in cases if x.find('skipped') is not None];c.save(S/'summary.json',dict(passed=not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,names=[x.get('classname')+'.'+x.get('name') for x in cases],properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],total_counts=plan['counts_total'],image=b.identity(image),link_plan=b.identity(S/'link-plan.json'),exact_same_test_objects=True))
