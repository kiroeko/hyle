"""Summarize the exact completed Mac incremental validation, without executing tests."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as E

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
R = S / "mac/remote"


def read(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def identity(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


freeze = read(S / "source-freeze.json")
for row in freeze["files"] + freeze["common_read_basis_not_owned"]:
    current = identity(ROOT / row["path"])
    assert (current["bytes"], current["sha256"]) == (row["bytes"], row["sha256"]), row["path"]
manifest = read(R / "source-manifest.json")
for row in manifest:
    assert identity(ROOT / row["path"])["sha256"] == row["sha256"], row["path"]
compiles = read(R / "results/compile-summary.json")["compiles"]
assert len(compiles) == 9 and all(x["exit"] == 0 for x in compiles)
link = read(R / "results/link.result.json")
run = read(R / "results/run.result.json")
assert link["exit"] == run["exit"] == 0
tests = E.parse(R / "results/tests.xml").findall(".//testcase")
assert len(tests) == 7
assert not any(x.findall("failure") or x.findall("skipped") for x in tests)
plan = read(S / "mac/plan.json")
inputs = read(R / "results/link-inputs.json")
assert len(inputs) == 153
result = dict(
    status="passed_bounded_Apple_GPTQ_reference_and_CT_neighbors",
    source_freeze=identity(S / "source-freeze.json"),
    actual_hardware=read(R / "hardware.json"),
    validation=identity(R / "results/validation.json"),
    tests_xml=identity(R / "results/tests.xml"),
    stdout=identity(R / "results/run.stdout.log"),
    stderr=identity(R / "results/run.stderr.log"),
    counts=dict(product_CXX=7, test_CXX=2, CXX_attempts=9, CXX_failed=0,
                link_attempts=1, link_failed=0, test_processes=1,
                cases_passed=7, cases_failed=0, cases_skipped=0,
                GPTQ_cases=3, CT_neighbor_cases=4,
                GPTQ_lifetime_submissions=12, GPTQ_runtime_success=10,
                GPTQ_runtime_failed_completions=4, GPTQ_escape_submissions=2,
                SDK_builds=0, NVCC=0, Windows_GPU=0),
    actual_test_cases=[dict(name=x.get("classname") + "." + x.get("name"),
        properties={p.get("name"):p.get("value") for p in x.findall("./properties/property")})
        for x in tests],
    closure=dict(
        base_retained_inputs=162, final_inputs=153,
        omitted_historical_test_objects=plan["removed_historical_tests"],
        archive_override="New loose apple_mature_artifact.cc.o precedes old static archive member; both checked Result-returning implementation and caller apple_tensor refreshed.",
        copied_files=len(manifest), copied_source_bytes=sum(x["bytes"] for x in manifest),
        no_SDK_copy=True, existing_D1_graph_core_reused=True,
        link_command=identity(R / "results/link.command.json"),
        link_inputs=identity(R / "results/link-inputs.json"),
        source_manifest=identity(R / "source-manifest.json"),
        compile_summary=identity(R / "results/compile-summary.json"),
        actual_objects=[dict(source=x["source"], object=x["object_identity"],
                            receipt=identity(R / "results" / (
                                x["source"]["path"].split("/gptq-reference/apple/", 1)[1]
                                .replace("/", "--") + "-identity.json"))) for x in compiles],
        inline_traits_audit=[identity(S / p) for p in ["mac-thunk-inventory.json",
            "mac-thunk-all-symbols.json", "mac-archive-thunk-inventory.json"]]),
    mathematical_scope=[
        "Four original GPTQ packed ports, all g_idx validated on device before indexed Z/SF access.",
        "raw zero nibble +1 retains 15->16; exact integer difference, F16 product, then decode and operand rounds.",
        "Closed unpublished Decode[/Cast]/Transpose[/Cast]/MatMul reads original banks without an N*K decoded bank.",
        "Published decode escape keeps the original checked F16 product path and D+Y publication.",
        "IEEE scale zero/nonfinite behavior is preserved; no scale positivity or finite policy added."],
    limits=[
        "No full GPTQ model artifact/payload, quality, throughput, CUDA/Windows GPU or other Mac hardware tested by this task.",
        "Positive packed tests force the existing cold region proposal through the test adapter; production default preference is unchanged.",
        "MLX allocation reports remain opaque; no zero native workspace or whole-device peak-memory claim.",
        "No Apple old-source red process was run; this is new capability validation plus four unchanged CT neighbor journeys.",
        "The 12 omitted historical test owners were not recompiled or executed; retained core/library inputs were hash-checked against the actual previous 162-input receipt."],
    cleanup="No files deleted and repository test.ps1 unchanged; current objects, commands, sources and logs retained in the existing fixed Hyle workspace.")
(S / "final-validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(report=identity(S / "final-validation.json"), counts=result["counts"])))
