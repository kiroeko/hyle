"""Small frozen GPTQ overlay on the actual retained Grouped NVFP4 Mac closure."""
from pathlib import Path
import base64
import hashlib
import json
import re
import shlex
import subprocess

S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
O = S / "mac"
O.mkdir(exist_ok=True)
BASE = A / "grouped-nvfp4/apple/mac/remote/status-carrier-v2/results"
REMOTE = ("/Users/kiro/hyle-scratch/compute-unified/"
          "architecture-refactor-20261019-apple-page-invocation/gptq-reference/apple")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def identity(path):
    p = Path(path)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def main():
    original_link = read(BASE / "link.command.json")["argv"]
    inputs = read(BASE / "link-inputs.json")
    removed_tests = [x["path"] for x in inputs
                     if "tests--" in x["path"] and x["path"].endswith(".o")]
    assert len(removed_tests) == 12
    link = [x for x in original_link if x not in removed_tests]
    recipes = {}
    for row in read(A / "batch-query-extent/delegated/apple/results/summary.json")["compiles"]:
        recipes[row["source"]] = row["argv"]
    for row in read(A / "grouped-nvfp4/apple/mac/remote/results/compile-summary.json")["compiles"]:
        recipes[row["source"]["path"].split("/grouped-nvfp4/apple/", 1)[1]] = row["argv"]
    for path in ["ct-packed-cross-platform/apple-gpu/plain-activation/plan.json",
                 "ct-packed-cross-platform/apple-gpu/bf16-pointwise/plan.json"]:
        for row in read(A / path)["compile"]:
            recipes[row["source"]] = row["recipe"]
    artifact = read(S / "mac-original-artifact-recipe.json")[0]
    recipes["src/compute_route_apple/apple_mature_artifact.cc"] = shlex.split(
        artifact["rows"][0]["command"])
    sources = [
        "src/compute_route_apple/apple_mature_artifact.cc",
        "src/compute_route_apple/apple_tensor.cc",
        "src/compute_route_apple/apple_ct_packed.cc",
        "src/compute_route_apple/apple_mature_float.cc",
        "src/graph_route_apple/apple_lowering.cc",
        "src/graph_route_apple/native_region.cc",
        "src/compute_ops/weight_decode.cc",
        "tests/graph_route_apple/gptq_reference_test.cc",
        "tests/graph_route_apple/ct_packed_linear_test.cc"]
    rows = []
    for source in sources:
        recipe_source = source
        if source.endswith("gptq_reference_test.cc"):
            recipe_source = "tests/graph_route_apple/ct_packed_linear_test.cc"
        stem = source.replace(".cc", "").replace("/", "--")
        matches = [r["path"] for r in inputs
                   if stem in r["path"] and r["path"].endswith(".o")]
        if source.startswith("tests/") or source.endswith("apple_mature_artifact.cc"):
            old = ""
        else:
            assert len(matches) == 1, (source, matches)
            old = matches[0]
        rows.append(dict(source=source, recipe=recipes[recipe_source], old_object=old,
                         recipe_source=recipe_source))
    # Local includes only; the SDK and dependency trees remain in-place.
    search = [ROOT, ROOT / "include",
              *(p for p in (ROOT / "src").iterdir() if p.is_dir()),
              *(p for p in (ROOT / "third_party").iterdir() if p.is_dir())]
    seen = set()
    pattern = re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]', re.M)

    def visit(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or not path.is_file():
            return
        if path.suffix not in [".h", ".hpp", ".hh", ".cc", ".mm", ".inc", ".inl", ".cuh"]:
            return
        seen.add(path)
        for inc in pattern.findall(path.read_text(encoding="utf-8", errors="replace")):
            candidate = next((base / inc for base in [path.parent, *search]
                              if (base / inc).is_file()), None)
            if candidate is not None:
                visit(candidate)
    for source in sources:
        visit(ROOT / source)
    files = []
    for path in sorted(seen):
        row = identity(path)
        row["path"] = path.relative_to(ROOT).as_posix()
        row["data"] = base64.b64encode(path.read_bytes()).decode()
        files.append(row)
    save(O / "source-manifest.json", [{k:v for k,v in row.items() if k != "data"}
                                       for row in files])
    plan = dict(remote=REMOTE, compile=rows, link=link, inputs=inputs,
                removed_historical_tests=removed_tests,
                source_basis=dict(base_link=identity(BASE / "link.command.json"),
                    apple=identity(S / "source-freeze.json"),
                    common=identity(A / "gptq-reference/common-cpu/source-freeze.json"),
                    shared=identity(A / "gptq-reference/root/shared-source-freeze.json")),
                artifact_archive_owner="libhyle_compute_route_apple.a:apple_mature_artifact.cc.o",
                metallib=("/Users/kiro/hyle-scratch/compute-unified/"
                          "architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib"),
                filter="AppleGptqReferenceGraph.*:AppleCtPackedLinear.*")
    save(O / "plan.json", plan)
    payload = dict(plan=plan, files=files,
                   script=base64.b64encode((S / "build_mac.py").read_bytes()).decode())
    code = r'''
from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p["plan"]["remote"]);r.mkdir(parents=True,exist_ok=True)
assert not (r/"plan.json").exists(),"Do not overwrite an existing attempt"
for row in p["files"]:
 b=base64.b64decode(row["data"]);assert hashlib.sha256(b).hexdigest()==row["sha256"]
 q=r/row["path"];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/"source-manifest.json").write_text(json.dumps([{k:v for k,v in x.items() if k!="data"}for x in p["files"]],indent=2)+"\n")
(r/"plan.json").write_text(json.dumps(p["plan"],indent=2)+"\n")
(r/"build_mac.py").write_bytes(base64.b64decode(p["script"]))
for row in p["plan"]["inputs"]:
 q=Path(row["path"]);assert q.stat().st_size==row["bytes"]
 assert hashlib.sha256(q.read_bytes()).hexdigest()==row["sha256"],row["path"]
h={k:subprocess.check_output(v,text=True).strip()for k,v in{
 "model":["sysctl","-n","hw.model"],"cpu":["sysctl","-n","machdep.cpu.brand_string"],
 "memory":["sysctl","-n","hw.memsize"],"os":["sw_vers"],"compiler":["clang++","--version"],
 "space":["df","-h",str(r)]}.items()}
assert h["model"]=="Mac16,12"
(r/"hardware.json").write_text(json.dumps(h,indent=2)+"\n")
print(json.dumps(dict(remote=str(r),files=len(p["files"]),bytes=sum(x["bytes"]for x in p["files"]),
 retained_inputs=len(p["plan"]["inputs"]),compile_owners=len(p["plan"]["compile"]),hardware=h)))
'''
    encoded = base64.b64encode(code.encode()).decode()
    command = ["ssh", "-o", "BatchMode=yes", "kiro@172.22.10.198",
               'python3 -c "import base64;exec(base64.b64decode(\'' + encoded + '\'))"']
    save(O / "sync.command.json", command)
    result = subprocess.run(command, input=json.dumps(payload).encode(), capture_output=True)
    (O / "sync.stdout.log").write_bytes(result.stdout)
    (O / "sync.stderr.log").write_bytes(result.stderr)
    save(O / "sync.result.json", dict(exit=result.returncode))
    print(result.stdout.decode(), result.stderr.decode())
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
