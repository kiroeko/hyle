"""Only the two proven AutoRound GPTQ coverage entries and exact renamed code paths."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
S = ROOT / ".scratch/architecture-refactor-2026-10-18/gptq-reference/apple"
Q = S.parent
path = ROOT / "docs/implementation/model-quantizations.json"
original = path.read_text(encoding="utf-8")
before = json.loads(original)
after = copy.deepcopy(before)
research = json.loads((Q.parent / "gptq-contract-review/review.json").read_text(encoding="utf-8"))
assert [a["group_size"] for a in research["exact_target_artifacts"]] == [32,64]
xmls = [Q / "common-cpu/checks/mapped-helper-refresh2/tests.xml",
        Q / "cuda/tests-mapped/tests.xml", Q / "cuda/tests-mapped/mapped-neighbors/tests.xml",
        Q / "vulkan/validation/tests.xml", Q / "apple/mac/remote/results/tests.xml"]
counts = []
for p in xmls:
    document = ET.parse(p).getroot()
    cases = document.findall(".//testcase")
    assert not any(case.findall(tag) for case in cases for tag in ["failure","error","skipped"])
    counts.append(len(cases))
assert counts == [14,7,8,12,7] and sum(counts) == 48
evidence = "../evidence/correctness/gptq-reference-2026-10-20.json"
sources = [
    "include/hyle/compute/model_ops.h", "src/compute_ops/weight_decode.cc",
    "src/compute_packed_shared/artifact_packed_linear.h", "src/graph/artifact_packed_region.h",
    "src/graph/mapped_native_region.h", "src/compute_provider_native/torch_cpu_program.cc",
    "src/compute_provider_native/ct_packed.cc", "src/graph_route_cpu/ct_packed_linear_region.cc",
    "src/compute_provider_torch_cuda/artifact_provider.cc",
    "src/compute_provider_torch_cuda/mlx_packed_kernel.cu",
    "src/graph_route_cuda/ct_packed_linear_region.cc",
    "src/compute_route_apple/apple_mature_artifact.cc", "src/compute_route_apple/apple_ct_packed.cc",
    "src/graph_route_apple/apple_lowering.cc", "src/graph_route_apple/native_region.cc",
    "src/compute_route_vulkan/vulkan_ct_packed.cc", "src/compute_route_vulkan/shaders/ct_packed.comp",
    "src/graph_route_vulkan/native_region.cc", "src/compute_shader_shared/ct_packed.h"]
for p in sources:
    assert (ROOT / p).is_file(), p
for index, group, header in [
    (1,32,"Q35 exact-revision complete safetensors header has 150 complete quantized roles with all four carriers; no tensor payload was read."),
    (10,64,"Q27 exact-revision index lists 400 quantized roles; only shard2 header was read, with 73 complete matching four-carrier roles. Other shard headers and all tensor payloads remain unread.")]:
    a = after["artifacts"][index]
    expected = research["exact_target_artifacts"][0 if index == 1 else 1]
    assert a["repository"] == expected["repository"] and a["revision"] == expected["revision"]
    coverage = dict(
        review="exact_header_source_contract_and_four_backend_operator_regressions",
        artifact_execution_verified=False,
        review_scope="Pinned tensor-header/index and primary producer-source research plus synthetic checked-decode and ordinary packed Graph math/lifetime regressions on Windows CPU/CUDA/Vulkan and macOS Apple M4. The evidence has 48 passing cases, 0 skips: 15 new GPTQ cases plus 33 neighbors. This does not execute a publisher artifact, importer, full model, quality or performance benchmark.",
        mapping_status="Exact GPTQ-v1 INT4 four-port descriptor and checked original decoder implemented on CPU/CUDA/Apple/Vulkan; bounded same-Graph packed linear candidate available. Whole artifact execution remains unverified.",
        required_format_domain=f"kGptqV1Int4, group_size={group}; plain dense I32 Q[K/8,N], I32 Z[G,N/8], F16 SF[G,N], I32 g_idx[K], G=K/group_size, positive complete groups and K and N divisible by 8. Signed I32 words carry unsigned low-first nibbles; symmetric/desc_act=false metadata does not remove Z or g_idx.",
        numerical_contract="Q nibble minus (raw Z nibble+1), including stored 15->16 without a second mask; exact integer subtraction, F16 scale product, then requested decode dtype and actual operand Cast rounding. Default decoded output is F16[N,K]; MatMul uses declared F32 accumulation. IEEE scale signed-zero/NaN/Inf behavior is retained without a new finite/positive guard.",
        index_contract="g_idx[k] selects the scale/zero group for the original k, not a permutation of A or Q. Validate all K indices on every execution before any indexed Z/SF access, including mutable replay updates; an invalid index fails Completion before invalid source access.",
        header_review=header,
        reachable_entry_points=[dict(provider=name,
            descriptor=f"ArtifactWeightDecode{{kGptqV1Int4,group_size={group},output_type=explicit_or_F16}}",
            execution="Checked original four-port decode and ordinary closed Decode[/Cast]/exact transpose View[/Cast]/MatMul packed contraction.",
            qualification="Synthetic group32/group64 independent nibble/F16-round oracle, dynamic g_idx, two slots, retained results, constant ownership, full-index failures and published-decode escapes. Positive packed tests select existing cold candidates through test-only route/provider selection; production defaults are unchanged.",
            evidence=evidence) for name in ["CPU native", "CUDA native artifact provider", "Apple native Metal", "Vulkan native"]],
        artifact_unaligned_or_unverified=[
            "No Q/Z/SF/g_idx payload values, actual importer binding or full model execution were checked; metadata does not prove stored zero values or natural g_idx contents.",
            "MTP/visual/lm_head module exclusions and extra-tensor payloads are not accepted by these operator tests; saved MTP carrier inventory does not certify an MTP engine.",
            "Primary producer packing and pointwise F16 codec are the source contract; its complete non-square forward/output-slicing behavior was not executed or used as a whole-model oracle.",
            "No performance/default-selection crossover, mature INT4 tensor-core GEMM, complete FFN/expert fusion or unrestricted multi-GiB backend-carrier claim follows from the bounded cases."],
        missing_capabilities=[],
        code=sources,
        fusion_coverage="One shared cold closure/reader/control proof contracts only the unpublished ordinary decode/Cast/transpose/MatMul recipe; the selected backend reads the original packed quartet without a persistent N*K decoded bank. Published/intermediate/control escapes keep the original checked decoder. Backend F32 reduction trees and address/carrier limits remain explicit.",
        evidence=evidence)
    a["provider_coverage"] = coverage

def normalize_headers(text):
    return text.replace("src/compute_packed_shared/ct_packed_linear.h", "src/compute_packed_shared/artifact_packed_linear.h").replace("src/graph/ct_packed_region.h", "src/graph/artifact_packed_region.h")

updated = original
for i in [1,10]:
    old = json.dumps(before["artifacts"][i]["provider_coverage"], ensure_ascii=False, indent=2).replace("\n", "\n      ")
    new = json.dumps(after["artifacts"][i]["provider_coverage"], ensure_ascii=False, indent=2).replace("\n", "\n      ")
    assert updated.count(old) == 1
    updated = updated.replace(old,new)
updated = normalize_headers(updated)
actual = json.loads(updated)
expected = json.loads(normalize_headers(json.dumps(after, ensure_ascii=False)))
assert actual == expected
for i, a in enumerate(actual["artifacts"]):
    old = json.loads(normalize_headers(json.dumps(before["artifacts"][i],ensure_ascii=False)))
    if i in [1,10]:
        old["provider_coverage"] = a["provider_coverage"]
    assert old == a, i
assert actual["artifacts"][1]["provider_coverage"]["artifact_execution_verified"] is False
assert actual["artifacts"][10]["provider_coverage"]["artifact_execution_verified"] is False
(S / "model-quantizations-update.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(True),updated.splitlines(True),
    fromfile="before/docs/implementation/model-quantizations.json",tofile="docs/implementation/model-quantizations.json")),encoding="utf-8")
path.write_text(updated,encoding="utf-8")
print(json.dumps(dict(updated=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                     changed_provider_coverage=[1,10], test_counts=counts,
                     old_header_references=original.count("src/compute_packed_shared/ct_packed_linear.h")+original.count("src/graph/ct_packed_region.h"))))
