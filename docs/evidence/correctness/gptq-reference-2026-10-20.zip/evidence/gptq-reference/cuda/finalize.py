from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path.cwd()
q = root / '.scratch/architecture-refactor-2026-10-18/gptq-reference'
stage = q / 'cuda'


def load(path):
    return json.loads(Path(path).read_bytes())


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


compile_results = sorted((stage / 'checks').rglob('*.result.json'))
assert len(compile_results) == 8
assert all(load(path)['exit'] == 0 for path in compile_results)
final_receipts = [stage / ('checks/attempt1/' + name + '-identity.json')
                  for name in ('artifact-provider', 'artifact-kernel', 'ct-test', 'gptq-test')]
final_receipts += sorted((stage / 'checks/mapped-refresh').glob('*-identity.json'))
assert len(final_receipts) == 7
link_path = stage / 'tests-mapped/link-plan.json'
link = load(link_path)
linked = {str(Path(row['path'])).lower(): row for row in link['inputs']}
owners = []
for path in final_receipts:
    record = load(path)
    source, obj = record['source'], record['object']
    assert identity(source['path']) == source
    assert identity(obj['path']) == obj
    assert linked[str(Path(obj['path'])).lower()] == obj
    owners.append(dict(receipt=identity(path), source=source, object=obj))
links = [stage / 'tests/gptq-link.result.json', stage / 'tests-mapped/gptq-link.result.json']
assert [load(path)['exit'] for path in links] == [1104, 0]
validations = []
for folder, expected in [(stage / 'tests-mapped', 7), (stage / 'tests-mapped/mapped-neighbors', 8)]:
    result = load(folder / 'result.json')
    xml = ET.parse(folder / 'tests.xml').getroot()
    assert result['exit_code'] == 0 and result['skipped'] == 0
    assert int(xml.attrib['tests']) == expected and int(xml.attrib['failures']) == 0
    assert int(xml.attrib['errors']) == 0
    assert not xml.findall('.//skipped')
    validations.append(dict(result=identity(folder / 'result.json'), xml=identity(folder / 'tests.xml'),
                            cases=expected, failed=0, skipped=0))
image = load(stage / 'tests-mapped/result.json')['image']
assert identity(image['path']) == image
report = dict(status='passed_bounded_GPTQ_CT_and_changed_adapter_neighbors',
    final_source_freeze=identity(q / 'root/final-source-freeze.json'),
    compile_invocations=dict(product_CXX=5, test_CXX=2, NVCC=1, failed=0,
        note='Includes the first packed-region CXX subsequently superseded by its variable-arity mapped-helper refresh. Final image has four current product CXX owners plus one NVCC owner and two test owners.'),
    compile_results=[identity(path) for path in compile_results],
    final_cuda_owners=owners, link_plan=identity(link_path),
    actual_link_inputs=len(link['inputs']),
    links=[dict(result=identity(path), exit=load(path)['exit']) for path in links],
    first_link_failure='LNK1104 missing task-local temporary directory; original command/log preserved. New task tmp directory and final link succeeded; no product numerical workaround.',
    image=image, validation=validations, total_passed=15, skipped=0,
    mapped_helper_owner_proof=identity(q / 'vulkan/mapped-owner-audit.json'),
    scope=['Same original packed quartet, exact F16 product boundary, full g_idx validation on device before indexed addresses, original checked decode escape.',
           'Test-only positive packed proposal selection; no new user configuration, executor or model whitelist.',
           'Four FP8-shared-prologue and four dense-indexer neighbor cases cover the other changed mapped-adapter owners.'],
    limits=['No full artifact/model, performance, quality, Linux, full installed build or whole-device memory claim.',
            'Actual CUDA private memory and original runtime/address limits remain; no automatic runtime-OOM route fallback.',
            'Current native CPU leaves and common inference are reused once in this bounded image; no SDK build.'])
(stage / 'final-validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(identity(stage / 'final-validation.json'), indent=2))
