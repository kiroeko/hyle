from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-system-review-20261025/deepseek-early-history'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
original=b.args(R/'.scratch/inference-ds-greedy-20261024/actual/attempt3/compile/command.json');flags=[];skip=False
for flag in original[1:]:
 if skip:skip=False;continue
 if flag=='/sourceDependencies':skip=True;continue
 lower=flag.lower().replace('\\','/')
 if lower.startswith(('/fo','/fd')) or lower.endswith(('.cc','.cpp')) or '/inference-ds-greedy-20261024/actual/attempt3/source'in lower:continue
 flags.append(flag)
env=b.environment(original[0]);out=[]
for name in ['dspark_original_state_consumer_test.cc','dspark_pro_mtp_state_consumer_test.cc']:
 folder=D/'warm-syntax'/Path(name).stem;source=R/'tests/compute_models'/name
 b.execute([original[0],*flags,'/Zs',str(source)],folder,env,120)
 out.append(dict(source=b.pin(source),process=b.read(folder/'process.json')))
b.save(D/'warm-syntax/summary.json',dict(status='PASS_strict_syntax_only',consumers=out,SDK_builds=0,model_runs=0))
