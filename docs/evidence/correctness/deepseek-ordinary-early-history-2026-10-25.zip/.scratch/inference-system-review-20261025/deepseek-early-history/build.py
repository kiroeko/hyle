from pathlib import Path
import importlib.util,sys,json,hashlib,os
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-system-review-20261025/deepseek-early-history'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=R/'.scratch/inference-ds-greedy-20261024/actual/attempt3';target=D/(sys.argv[1] if len(sys.argv)>1 else 'attempt1');target.mkdir(exist_ok=False)
original=b.args(old/'compile/command.json');flags=[];skip=False
for flag in original[1:]:
 if skip:skip=False;continue
 if flag=='/sourceDependencies':skip=True;continue
 lower=flag.lower().replace('\\','/')
 if lower.startswith(('/fo','/fd')) or lower.endswith(('.cc','.cpp')):continue
 if '/inference-ds-greedy-20261024/actual/attempt3/source'in lower:continue
 flags.append(flag)
source=R/'tests/compute_models/dspark_original_early_history_test.cc'
paths=[source,*[R/'tests/compute_models'/n for n in ['dspark_original_target_fragment.h','dspark_original_target_reference.h','dspark_original_target_program.h']]]
before=[b.pin(p)for p in paths];b.save(target/'before-pins.json',before)
command=[original[0],*flags,str(source),'/sourceDependencies',str(target/'dependencies.json'),'/Fo'+str(target/'consumer.obj')]
env=b.environment(original[0]);b.execute(command,target/'compile',env,120)
assert before==[b.pin(p)for p in paths],'Edited source changed during compilation'
deps=b.read(target/'dependencies.json')['Data'];pins=[]
for name in [deps['Source'],*deps['Includes']]:
 p=Path(name).resolve()
 if p.is_relative_to(R/'tests') or p.is_relative_to(R/'engine'):
  record=b.pin(p);q=target/'source'/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());pins.append(record)
b.save(target/'actual-source-pins.json',pins)
link=b.args(old/'link/command.json');args=[];replace=0
for x in link[1:]:
 if x.lower()==str(old/'consumer.obj').lower():args.append(str(target/'consumer.obj'));replace+=1
 elif not x.lower().startswith(('/out:','/pdb:','/implib:','/map:')):args.append(x)
assert replace==1
b.execute([link[0],*args,'/OUT:'+str(target/'checks.exe'),'/IMPLIB:'+str(target/'checks.lib')],target/'link',env,120)
native=b.read(old/'native.json');print('native record keys',list(native))
# Runtime dependency directories are reused; no SDK is rebuilt or copied.
b.save(target/'ready.json',dict(image=b.pin(target/'checks.exe'),object=b.pin(target/'consumer.obj'),sources=pins,native_reuse=native,SDK_builds=0,HTTP=0))
print(json.dumps(dict(status='compiled_linked',image=b.pin(target/'checks.exe'),project_sources=len(pins))))
